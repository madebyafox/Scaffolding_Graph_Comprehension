var MF = MF || {};MF.RecordingData = MF.RecordingData || {};MF.RecordingData["0604113303e5e9bd3a8ac080ec63e2983e823e42"] = {
  "startTime": "2018-06-04T20:22:10.9549676Z",
  "websitePageUrl": "/16",
  "visitTime": 90396,
  "engagementTime": 89761,
  "pageTitle": "FOX2YP",
  "url": "https://warm-citadel-75324.herokuapp.com/",
  "viewportWidth": 1920,
  "viewportHeight": 1200,
  "tags": [
    "form-interact",
    "submit"
  ],
  "session": {
    "id": "266087bca1fcdf3c2751920577189cbd",
    "created": "2018-06-04T20:22:10.9549676+00:00",
    "lastActivity": "0001-01-01T00:00:00+00:00",
    "pages": 1,
    "duration": 0,
    "engagementTime": 0,
    "totalFriction": 0,
    "country": "us",
    "region": "CA",
    "city": "La Jolla",
    "isp": "University of California, San Diego",
    "ip": "###.###.###.###",
    "lang": "en-US",
    "userAgent": "Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/67.0.3396.62 Safari/537.36",
    "browser": "Chrome",
    "browserVersion": "67.0.3396.62",
    "os": "Windows",
    "osVersion": "7",
    "device": "Desktop",
    "referrer": "",
    "referrerType": "",
    "screenRes": "1920x1200",
    "entryPage": "/16",
    "tags": [
      "form-interact",
      "submit"
    ],
    "variables": [
      "SID=06217",
      "CONDITION=211"
    ],
    "watched": false,
    "starred": false,
    "lng": 32.8807,
    "lat": 32.8807,
    "visitorId": "86b89d3aa88af5cfb92b06048b5a0fad",
    "gdpr": false,
    "visitorName": null,
    "playbackUrl": "https://us.mouseflow.com/websites/e0c9ff05-6fcb-4c4a-8173-e5a0724987b1/recordings/266087bca1fcdf3c2751920577189cbd/play"
  },
  "events": [
    {
      "t": 0,
      "e": 0,
      "ty": 14,
      "x": 0,
      "y": 1199
    },
    {
      "t": 202,
      "e": 202,
      "ty": 0,
      "x": 1920,
      "y": 1200
    },
    {
      "t": 202,
      "e": 202,
      "ty": 1,
      "x": 0,
      "y": 16
    },
    {
      "t": 1000,
      "e": 1000,
      "ty": 2,
      "x": 539,
      "y": 735
    },
    {
      "t": 1001,
      "e": 1001,
      "ty": 41,
      "x": 49674,
      "y": 40273,
      "ta": "> div.stimulus > div"
    },
    {
      "t": 1100,
      "e": 1100,
      "ty": 2,
      "x": 569,
      "y": 637
    },
    {
      "t": 1127,
      "e": 1127,
      "ty": 6,
      "x": 568,
      "y": 586,
      "ta": "#strategyAnswer"
    },
    {
      "t": 1200,
      "e": 1200,
      "ty": 2,
      "x": 568,
      "y": 560
    },
    {
      "t": 1250,
      "e": 1250,
      "ty": 41,
      "x": 52934,
      "y": 30150,
      "ta": "#strategyAnswer"
    },
    {
      "t": 1500,
      "e": 1500,
      "ty": 2,
      "x": 564,
      "y": 559
    },
    {
      "t": 1501,
      "e": 1501,
      "ty": 41,
      "x": 52484,
      "y": 29341,
      "ta": "#strategyAnswer"
    },
    {
      "t": 1546,
      "e": 1546,
      "ty": 3,
      "x": 564,
      "y": 559,
      "ta": "#strategyAnswer"
    },
    {
      "t": 1547,
      "e": 1547,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 1688,
      "e": 1688,
      "ty": 4,
      "x": 52484,
      "y": 29341,
      "ta": "#strategyAnswer"
    },
    {
      "t": 1689,
      "e": 1689,
      "ty": 5,
      "x": 564,
      "y": 559,
      "ta": "#strategyAnswer"
    },
    {
      "t": 3545,
      "e": 3545,
      "ty": 7,
      "x": 614,
      "y": 618,
      "ta": "#strategyAnswer"
    },
    {
      "t": 3600,
      "e": 3600,
      "ty": 2,
      "x": 638,
      "y": 633
    },
    {
      "t": 3751,
      "e": 3751,
      "ty": 41,
      "x": 60803,
      "y": 34623,
      "ta": "> div.stimulus > div"
    },
    {
      "t": 4400,
      "e": 4400,
      "ty": 2,
      "x": 1000,
      "y": 798
    },
    {
      "t": 4500,
      "e": 4500,
      "ty": 2,
      "x": 1338,
      "y": 941
    },
    {
      "t": 4500,
      "e": 4500,
      "ty": 41,
      "x": 38899,
      "y": 57513,
      "ta": "> div.stimulus > div:[2] > svg"
    },
    {
      "t": 4600,
      "e": 4600,
      "ty": 2,
      "x": 1314,
      "y": 975
    },
    {
      "t": 4700,
      "e": 4700,
      "ty": 2,
      "x": 1246,
      "y": 1025
    },
    {
      "t": 4751,
      "e": 4751,
      "ty": 41,
      "x": 23985,
      "y": 0,
      "ta": "> div.stimulus > div:[2] > svg > g > g:[3] > g:[26] > text"
    },
    {
      "t": 4801,
      "e": 4801,
      "ty": 2,
      "x": 1242,
      "y": 1027
    },
    {
      "t": 4900,
      "e": 4900,
      "ty": 2,
      "x": 1173,
      "y": 987
    },
    {
      "t": 5000,
      "e": 5000,
      "ty": 2,
      "x": 1146,
      "y": 974
    },
    {
      "t": 5001,
      "e": 5001,
      "ty": 41,
      "x": 21170,
      "y": 20735,
      "ta": "> div.stimulus > div:[2] > svg > g > g:[3] > g:[9] > text"
    },
    {
      "t": 5101,
      "e": 5101,
      "ty": 2,
      "x": 1127,
      "y": 970
    },
    {
      "t": 5200,
      "e": 5200,
      "ty": 2,
      "x": 1125,
      "y": 970
    },
    {
      "t": 5251,
      "e": 5251,
      "ty": 41,
      "x": 24101,
      "y": 59303,
      "ta": "> div.stimulus > div:[2] > svg"
    },
    {
      "t": 5300,
      "e": 5300,
      "ty": 2,
      "x": 1137,
      "y": 962
    },
    {
      "t": 5400,
      "e": 5400,
      "ty": 2,
      "x": 1138,
      "y": 961
    },
    {
      "t": 5500,
      "e": 5500,
      "ty": 41,
      "x": 24805,
      "y": 58945,
      "ta": "> div.stimulus > div:[2] > svg"
    },
    {
      "t": 6100,
      "e": 6100,
      "ty": 2,
      "x": 1144,
      "y": 959
    },
    {
      "t": 6201,
      "e": 6201,
      "ty": 2,
      "x": 1147,
      "y": 957
    },
    {
      "t": 6251,
      "e": 6251,
      "ty": 41,
      "x": 25439,
      "y": 58659,
      "ta": "> div.stimulus > div:[2] > svg"
    },
    {
      "t": 6900,
      "e": 6900,
      "ty": 2,
      "x": 1150,
      "y": 956
    },
    {
      "t": 7001,
      "e": 7001,
      "ty": 41,
      "x": 25651,
      "y": 58587,
      "ta": "> div.stimulus > div:[2] > svg"
    },
    {
      "t": 7100,
      "e": 7100,
      "ty": 2,
      "x": 1151,
      "y": 955
    },
    {
      "t": 7200,
      "e": 7200,
      "ty": 2,
      "x": 1151,
      "y": 953
    },
    {
      "t": 7250,
      "e": 7250,
      "ty": 41,
      "x": 26215,
      "y": 58157,
      "ta": "> div.stimulus > div:[2] > svg"
    },
    {
      "t": 7301,
      "e": 7301,
      "ty": 2,
      "x": 1163,
      "y": 942
    },
    {
      "t": 7400,
      "e": 7400,
      "ty": 2,
      "x": 1171,
      "y": 930
    },
    {
      "t": 7500,
      "e": 7500,
      "ty": 2,
      "x": 1176,
      "y": 919
    },
    {
      "t": 7501,
      "e": 7501,
      "ty": 41,
      "x": 27483,
      "y": 55937,
      "ta": "> div.stimulus > div:[2] > svg"
    },
    {
      "t": 7601,
      "e": 7601,
      "ty": 2,
      "x": 1178,
      "y": 915
    },
    {
      "t": 7700,
      "e": 7700,
      "ty": 2,
      "x": 1178,
      "y": 914
    },
    {
      "t": 7751,
      "e": 7751,
      "ty": 41,
      "x": 27694,
      "y": 55507,
      "ta": "> div.stimulus > div:[2] > svg"
    },
    {
      "t": 7801,
      "e": 7801,
      "ty": 2,
      "x": 1179,
      "y": 913
    },
    {
      "t": 9900,
      "e": 9900,
      "ty": 2,
      "x": 1167,
      "y": 919
    },
    {
      "t": 10000,
      "e": 10000,
      "ty": 2,
      "x": 1135,
      "y": 951
    },
    {
      "t": 10000,
      "e": 10000,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 10002,
      "e": 10002,
      "ty": 41,
      "x": 24594,
      "y": 58229,
      "ta": "> div.stimulus > div:[2] > svg"
    },
    {
      "t": 10200,
      "e": 10200,
      "ty": 2,
      "x": 1129,
      "y": 956
    },
    {
      "t": 10250,
      "e": 10250,
      "ty": 41,
      "x": 23184,
      "y": 59805,
      "ta": "> div.stimulus > div:[2] > svg"
    },
    {
      "t": 10300,
      "e": 10300,
      "ty": 2,
      "x": 1115,
      "y": 977
    },
    {
      "t": 10400,
      "e": 10400,
      "ty": 2,
      "x": 1115,
      "y": 981
    },
    {
      "t": 10501,
      "e": 10501,
      "ty": 2,
      "x": 1141,
      "y": 995
    },
    {
      "t": 10501,
      "e": 10501,
      "ty": 41,
      "x": 25017,
      "y": 61380,
      "ta": "> div.stimulus > div:[2] > svg"
    },
    {
      "t": 10600,
      "e": 10600,
      "ty": 2,
      "x": 1143,
      "y": 995
    },
    {
      "t": 10700,
      "e": 10700,
      "ty": 2,
      "x": 432,
      "y": 700
    },
    {
      "t": 10718,
      "e": 10718,
      "ty": 6,
      "x": 358,
      "y": 657,
      "ta": "#strategyButton"
    },
    {
      "t": 10732,
      "e": 10732,
      "ty": 7,
      "x": 309,
      "y": 616,
      "ta": "#strategyButton"
    },
    {
      "t": 10750,
      "e": 10750,
      "ty": 6,
      "x": 292,
      "y": 600,
      "ta": "#strategyAnswer"
    },
    {
      "t": 10750,
      "e": 10750,
      "ty": 41,
      "x": 21909,
      "y": 62513,
      "ta": "#strategyAnswer"
    },
    {
      "t": 10801,
      "e": 10801,
      "ty": 2,
      "x": 291,
      "y": 599
    },
    {
      "t": 10900,
      "e": 10900,
      "ty": 2,
      "x": 297,
      "y": 589
    },
    {
      "t": 11000,
      "e": 11000,
      "ty": 2,
      "x": 306,
      "y": 569
    },
    {
      "t": 11001,
      "e": 11001,
      "ty": 41,
      "x": 23483,
      "y": 37432,
      "ta": "#strategyAnswer"
    },
    {
      "t": 11101,
      "e": 11101,
      "ty": 2,
      "x": 307,
      "y": 568
    },
    {
      "t": 11137,
      "e": 11137,
      "ty": 3,
      "x": 307,
      "y": 568,
      "ta": "#strategyAnswer"
    },
    {
      "t": 11201,
      "e": 11201,
      "ty": 4,
      "x": 23595,
      "y": 36623,
      "ta": "#strategyAnswer"
    },
    {
      "t": 11201,
      "e": 11201,
      "ty": 5,
      "x": 307,
      "y": 568,
      "ta": "#strategyAnswer"
    },
    {
      "t": 11251,
      "e": 11251,
      "ty": 41,
      "x": 23595,
      "y": 36623,
      "ta": "#strategyAnswer"
    },
    {
      "t": 13181,
      "e": 13181,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "16"
    },
    {
      "t": 13428,
      "e": 13428,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "89"
    },
    {
      "t": 13429,
      "e": 13429,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 13476,
      "e": 13476,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "y"
    },
    {
      "t": 13548,
      "e": 13548,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "y"
    },
    {
      "t": 13572,
      "e": 13572,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "79"
    },
    {
      "t": 13572,
      "e": 13572,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 13749,
      "e": 13749,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "85"
    },
    {
      "t": 13749,
      "e": 13749,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 13781,
      "e": 13781,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "yOU"
    },
    {
      "t": 13845,
      "e": 13845,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 13845,
      "e": 13845,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 13853,
      "e": 13853,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "yOU "
    },
    {
      "t": 13932,
      "e": 13932,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 13973,
      "e": 13973,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "76"
    },
    {
      "t": 13973,
      "e": 13973,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 14068,
      "e": 14068,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||L"
    },
    {
      "t": 14253,
      "e": 14253,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 14308,
      "e": 14308,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "yOU "
    },
    {
      "t": 14388,
      "e": 14388,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 14436,
      "e": 14436,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "yOU"
    },
    {
      "t": 14508,
      "e": 14508,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 14581,
      "e": 14581,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "yO"
    },
    {
      "t": 14637,
      "e": 14637,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 14701,
      "e": 14701,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "y"
    },
    {
      "t": 14757,
      "e": 14757,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 14836,
      "e": 14836,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": ""
    },
    {
      "t": 14998,
      "e": 14998,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "89"
    },
    {
      "t": 14999,
      "e": 14999,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 15092,
      "e": 15092,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Y"
    },
    {
      "t": 15220,
      "e": 15220,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "20"
    },
    {
      "t": 15293,
      "e": 15293,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Y"
    },
    {
      "t": 15333,
      "e": 15333,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "79"
    },
    {
      "t": 15334,
      "e": 15334,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 15396,
      "e": 15396,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "85"
    },
    {
      "t": 15397,
      "e": 15397,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 15444,
      "e": 15444,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "You"
    },
    {
      "t": 15500,
      "e": 15500,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "You"
    },
    {
      "t": 15501,
      "e": 15501,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 15501,
      "e": 15501,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 15604,
      "e": 15604,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "You "
    },
    {
      "t": 15604,
      "e": 15604,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "You "
    },
    {
      "t": 15629,
      "e": 15629,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "76"
    },
    {
      "t": 15629,
      "e": 15629,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 15692,
      "e": 15692,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||l"
    },
    {
      "t": 15780,
      "e": 15780,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "79"
    },
    {
      "t": 15780,
      "e": 15780,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 15844,
      "e": 15844,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||o"
    },
    {
      "t": 15933,
      "e": 15933,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "79"
    },
    {
      "t": 15934,
      "e": 15934,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 16012,
      "e": 16012,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||o"
    },
    {
      "t": 16076,
      "e": 16076,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "75"
    },
    {
      "t": 16077,
      "e": 16077,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 16164,
      "e": 16164,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||k"
    },
    {
      "t": 16173,
      "e": 16173,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 16173,
      "e": 16173,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 16252,
      "e": 16252,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 16252,
      "e": 16252,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 16276,
      "e": 16276,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| a"
    },
    {
      "t": 16324,
      "e": 16324,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 16429,
      "e": 16429,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 16430,
      "e": 16430,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 16492,
      "e": 16492,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 16492,
      "e": 16492,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 16493,
      "e": 16493,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 16556,
      "e": 16556,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 16596,
      "e": 16596,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 16596,
      "e": 16596,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 16652,
      "e": 16652,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "72"
    },
    {
      "t": 16653,
      "e": 16653,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 16676,
      "e": 16676,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||th"
    },
    {
      "t": 16725,
      "e": 16725,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 16757,
      "e": 16757,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 16757,
      "e": 16757,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 16820,
      "e": 16820,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||e"
    },
    {
      "t": 16835,
      "e": 16835,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 16836,
      "e": 16836,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 16924,
      "e": 16924,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 17989,
      "e": 17989,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "66"
    },
    {
      "t": 17990,
      "e": 17990,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 18068,
      "e": 18068,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||b"
    },
    {
      "t": 18108,
      "e": 18108,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "79"
    },
    {
      "t": 18109,
      "e": 18109,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 18229,
      "e": 18229,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 18229,
      "e": 18229,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 18236,
      "e": 18236,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||ot"
    },
    {
      "t": 18268,
      "e": 18268,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 18389,
      "e": 18389,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "79"
    },
    {
      "t": 18389,
      "e": 18389,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 18500,
      "e": 18500,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||o"
    },
    {
      "t": 18701,
      "e": 18701,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 18803,
      "e": 18803,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "You look at the bot"
    },
    {
      "t": 18813,
      "e": 18813,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "You look at the bot"
    },
    {
      "t": 18837,
      "e": 18837,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 18837,
      "e": 18837,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 18924,
      "e": 18924,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 18956,
      "e": 18956,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "79"
    },
    {
      "t": 18956,
      "e": 18956,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 19069,
      "e": 19069,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||o"
    },
    {
      "t": 19165,
      "e": 19165,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "77"
    },
    {
      "t": 19166,
      "e": 19166,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 19220,
      "e": 19220,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||m"
    },
    {
      "t": 19277,
      "e": 19277,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 19277,
      "e": 19277,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 19356,
      "e": 19356,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 19420,
      "e": 19420,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 19421,
      "e": 19421,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 19517,
      "e": 19421,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||a"
    },
    {
      "t": 19637,
      "e": 19541,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "88"
    },
    {
      "t": 19638,
      "e": 19542,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 19724,
      "e": 19628,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||x"
    },
    {
      "t": 19740,
      "e": 19644,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "73"
    },
    {
      "t": 19740,
      "e": 19644,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 19804,
      "e": 19708,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||i"
    },
    {
      "t": 19916,
      "e": 19820,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "83"
    },
    {
      "t": 19917,
      "e": 19821,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 20012,
      "e": 19916,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||s"
    },
    {
      "t": 20060,
      "e": 19964,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 20060,
      "e": 19964,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 20124,
      "e": 20028,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 20164,
      "e": 20068,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 20165,
      "e": 20069,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 20284,
      "e": 20188,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||a"
    },
    {
      "t": 20285,
      "e": 20189,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "78"
    },
    {
      "t": 20285,
      "e": 20189,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 20372,
      "e": 20276,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||n"
    },
    {
      "t": 20397,
      "e": 20301,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "68"
    },
    {
      "t": 20398,
      "e": 20302,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 20500,
      "e": 20404,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||d"
    },
    {
      "t": 20516,
      "e": 20420,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 20516,
      "e": 20420,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 20588,
      "e": 20492,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 20917,
      "e": 20821,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "76"
    },
    {
      "t": 20918,
      "e": 20822,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 20980,
      "e": 20884,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||l"
    },
    {
      "t": 21068,
      "e": 20972,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "79"
    },
    {
      "t": 21069,
      "e": 20973,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 21132,
      "e": 21036,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||o"
    },
    {
      "t": 21213,
      "e": 21117,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "79"
    },
    {
      "t": 21214,
      "e": 21118,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 21299,
      "e": 21203,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||o"
    },
    {
      "t": 21340,
      "e": 21244,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "75"
    },
    {
      "t": 21340,
      "e": 21244,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 21429,
      "e": 21333,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 21429,
      "e": 21333,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 21437,
      "e": 21341,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||k "
    },
    {
      "t": 21525,
      "e": 21429,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 21557,
      "e": 21461,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "70"
    },
    {
      "t": 21557,
      "e": 21461,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 21604,
      "e": 21508,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "79"
    },
    {
      "t": 21604,
      "e": 21508,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 21652,
      "e": 21556,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||fo"
    },
    {
      "t": 21708,
      "e": 21612,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 21732,
      "e": 21636,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "82"
    },
    {
      "t": 21733,
      "e": 21637,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 21797,
      "e": 21701,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||r"
    },
    {
      "t": 21861,
      "e": 21765,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 21861,
      "e": 21765,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 21948,
      "e": 21852,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 22389,
      "e": 22293,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "49"
    },
    {
      "t": 22390,
      "e": 22294,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 22501,
      "e": 22405,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||1"
    },
    {
      "t": 22502,
      "e": 22406,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "50"
    },
    {
      "t": 22502,
      "e": 22406,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 22612,
      "e": 22516,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||2"
    },
    {
      "t": 22725,
      "e": 22629,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 22726,
      "e": 22630,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 22796,
      "e": 22700,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 23124,
      "e": 23028,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 23220,
      "e": 23124,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "You look at the bottom axis and look for 12"
    },
    {
      "t": 23333,
      "e": 23237,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "80"
    },
    {
      "t": 23333,
      "e": 23237,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 23445,
      "e": 23349,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||p"
    },
    {
      "t": 23518,
      "e": 23422,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "77"
    },
    {
      "t": 23518,
      "e": 23422,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 23572,
      "e": 23476,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||m"
    },
    {
      "t": 24011,
      "e": 23915,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "190"
    },
    {
      "t": 24013,
      "e": 23917,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 24068,
      "e": 23972,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||."
    },
    {
      "t": 24188,
      "e": 24092,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 24188,
      "e": 24092,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 24287,
      "e": 24191,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 24415,
      "e": 24319,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "16"
    },
    {
      "t": 24496,
      "e": 24400,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "79"
    },
    {
      "t": 24497,
      "e": 24401,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 24551,
      "e": 24455,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||O"
    },
    {
      "t": 24568,
      "e": 24472,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "78"
    },
    {
      "t": 24568,
      "e": 24472,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 24591,
      "e": 24495,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||n"
    },
    {
      "t": 24664,
      "e": 24568,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 24720,
      "e": 24624,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "67"
    },
    {
      "t": 24720,
      "e": 24624,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 24800,
      "e": 24704,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||c"
    },
    {
      "t": 24856,
      "e": 24760,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 24857,
      "e": 24761,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 24959,
      "e": 24863,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||e"
    },
    {
      "t": 24959,
      "e": 24863,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 24959,
      "e": 24863,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 25024,
      "e": 24928,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 25048,
      "e": 24952,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "89"
    },
    {
      "t": 25048,
      "e": 24952,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 25120,
      "e": 25024,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "79"
    },
    {
      "t": 25121,
      "e": 25025,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 25143,
      "e": 25047,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||yo"
    },
    {
      "t": 25176,
      "e": 25080,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "85"
    },
    {
      "t": 25176,
      "e": 25080,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 25224,
      "e": 25128,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||u"
    },
    {
      "t": 25272,
      "e": 25176,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 25953,
      "e": 25857,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "222"
    },
    {
      "t": 25953,
      "e": 25857,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 26008,
      "e": 25912,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "86"
    },
    {
      "t": 26008,
      "e": 25912,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 26031,
      "e": 25935,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||'v"
    },
    {
      "t": 26080,
      "e": 25984,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 26200,
      "e": 26104,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 26201,
      "e": 26105,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 26288,
      "e": 26192,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||e"
    },
    {
      "t": 26288,
      "e": 26192,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 26288,
      "e": 26192,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 26383,
      "e": 26287,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "68"
    },
    {
      "t": 26384,
      "e": 26288,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 26392,
      "e": 26296,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| d"
    },
    {
      "t": 26496,
      "e": 26400,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 26592,
      "e": 26496,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 26593,
      "e": 26497,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 26679,
      "e": 26583,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 26736,
      "e": 26640,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 26736,
      "e": 26640,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 26815,
      "e": 26719,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "82"
    },
    {
      "t": 26816,
      "e": 26720,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 26832,
      "e": 26736,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||er"
    },
    {
      "t": 26904,
      "e": 26808,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 26930,
      "e": 26810,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "77"
    },
    {
      "t": 26931,
      "e": 26811,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 27000,
      "e": 26880,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||m"
    },
    {
      "t": 27071,
      "e": 26951,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "73"
    },
    {
      "t": 27072,
      "e": 26952,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 27176,
      "e": 27056,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "78"
    },
    {
      "t": 27176,
      "e": 27056,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 27183,
      "e": 27063,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||in"
    },
    {
      "t": 27208,
      "e": 27088,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 27208,
      "e": 27088,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 27280,
      "e": 27160,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||e"
    },
    {
      "t": 27296,
      "e": 27176,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 27368,
      "e": 27248,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "68"
    },
    {
      "t": 27369,
      "e": 27249,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 27448,
      "e": 27328,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||d"
    },
    {
      "t": 27463,
      "e": 27343,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 27463,
      "e": 27343,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 27544,
      "e": 27424,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 27608,
      "e": 27488,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 27608,
      "e": 27488,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 27688,
      "e": 27568,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 27696,
      "e": 27576,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "72"
    },
    {
      "t": 27696,
      "e": 27576,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 27776,
      "e": 27656,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 27776,
      "e": 27656,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 27784,
      "e": 27664,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||ha"
    },
    {
      "t": 27856,
      "e": 27736,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 27952,
      "e": 27832,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 27953,
      "e": 27833,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 28016,
      "e": 27896,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 28016,
      "e": 27896,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 28031,
      "e": 27911,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t "
    },
    {
      "t": 28064,
      "e": 27944,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "80"
    },
    {
      "t": 28064,
      "e": 27944,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 28096,
      "e": 27976,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||p"
    },
    {
      "t": 28127,
      "e": 28007,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "79"
    },
    {
      "t": 28128,
      "e": 28008,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 28192,
      "e": 28072,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||o"
    },
    {
      "t": 28216,
      "e": 28096,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 28328,
      "e": 28208,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "73"
    },
    {
      "t": 28329,
      "e": 28209,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 28416,
      "e": 28296,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||i"
    },
    {
      "t": 28432,
      "e": 28312,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "78"
    },
    {
      "t": 28432,
      "e": 28312,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 28519,
      "e": 28399,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 28520,
      "e": 28400,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 28527,
      "e": 28407,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||nt"
    },
    {
      "t": 28608,
      "e": 28488,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 28623,
      "e": 28503,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 28623,
      "e": 28503,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 28711,
      "e": 28591,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 28720,
      "e": 28600,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "89"
    },
    {
      "t": 28720,
      "e": 28600,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 28808,
      "e": 28688,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||y"
    },
    {
      "t": 28815,
      "e": 28695,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "79"
    },
    {
      "t": 28816,
      "e": 28696,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 28855,
      "e": 28735,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "85"
    },
    {
      "t": 28855,
      "e": 28735,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 28920,
      "e": 28800,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||ou"
    },
    {
      "t": 28984,
      "e": 28864,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 29017,
      "e": 28897,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 29017,
      "e": 28897,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 29087,
      "e": 28967,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 29205,
      "e": 29085,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "You look at the bottom axis and look for 12pm. Once you've dtermined that point you "
    },
    {
      "t": 31024,
      "e": 30904,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "70"
    },
    {
      "t": 31025,
      "e": 30905,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 31119,
      "e": 30999,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "79"
    },
    {
      "t": 31119,
      "e": 30999,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 31135,
      "e": 31015,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||fo"
    },
    {
      "t": 31200,
      "e": 31080,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 31304,
      "e": 31184,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "76"
    },
    {
      "t": 31306,
      "e": 31186,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 31360,
      "e": 31240,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||l"
    },
    {
      "t": 31440,
      "e": 31320,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "76"
    },
    {
      "t": 31441,
      "e": 31321,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 31496,
      "e": 31376,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||l"
    },
    {
      "t": 31592,
      "e": 31472,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "79"
    },
    {
      "t": 31593,
      "e": 31473,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 31672,
      "e": 31552,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "87"
    },
    {
      "t": 31672,
      "e": 31552,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 31695,
      "e": 31575,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||ow"
    },
    {
      "t": 31759,
      "e": 31639,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 31760,
      "e": 31640,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 31767,
      "e": 31647,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 31808,
      "e": 31688,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "73"
    },
    {
      "t": 31808,
      "e": 31688,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 31840,
      "e": 31720,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||i"
    },
    {
      "t": 31911,
      "e": 31791,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 31919,
      "e": 31799,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 31919,
      "e": 31799,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 31983,
      "e": 31863,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 31983,
      "e": 31863,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 32032,
      "e": 31912,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t "
    },
    {
      "t": 32047,
      "e": 31927,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "85"
    },
    {
      "t": 32048,
      "e": 31928,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 32055,
      "e": 31935,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||u"
    },
    {
      "t": 32143,
      "e": 32023,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 32248,
      "e": 32128,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "80"
    },
    {
      "t": 32248,
      "e": 32128,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 32344,
      "e": 32224,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||p"
    },
    {
      "t": 32448,
      "e": 32328,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 32449,
      "e": 32329,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 32543,
      "e": 32423,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 32904,
      "e": 32784,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 32905,
      "e": 32785,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 33023,
      "e": 32903,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||a"
    },
    {
      "t": 33160,
      "e": 33040,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "76"
    },
    {
      "t": 33161,
      "e": 33041,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 33256,
      "e": 33136,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||l"
    },
    {
      "t": 33352,
      "e": 33232,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "79"
    },
    {
      "t": 33353,
      "e": 33233,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 33447,
      "e": 33327,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||o"
    },
    {
      "t": 33519,
      "e": 33399,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "78"
    },
    {
      "t": 33520,
      "e": 33400,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 33616,
      "e": 33496,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "71"
    },
    {
      "t": 33617,
      "e": 33497,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 33624,
      "e": 33504,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||ng"
    },
    {
      "t": 33712,
      "e": 33592,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 33728,
      "e": 33608,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 33728,
      "e": 33608,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 33799,
      "e": 33679,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 33823,
      "e": 33703,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 33825,
      "e": 33704,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 33895,
      "e": 33774,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "72"
    },
    {
      "t": 33895,
      "e": 33774,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 33911,
      "e": 33790,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||th"
    },
    {
      "t": 33983,
      "e": 33862,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 33999,
      "e": 33878,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 33999,
      "e": 33878,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 34103,
      "e": 33982,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||e"
    },
    {
      "t": 34120,
      "e": 33999,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 34120,
      "e": 33999,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 34199,
      "e": 34078,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 34256,
      "e": 34135,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "82"
    },
    {
      "t": 34256,
      "e": 34135,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 34343,
      "e": 34222,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||r"
    },
    {
      "t": 34391,
      "e": 34270,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "73"
    },
    {
      "t": 34391,
      "e": 34270,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 34463,
      "e": 34342,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "71"
    },
    {
      "t": 34464,
      "e": 34343,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 34487,
      "e": 34366,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||ig"
    },
    {
      "t": 34553,
      "e": 34432,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 34600,
      "e": 34479,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "72"
    },
    {
      "t": 34600,
      "e": 34479,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 34671,
      "e": 34550,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 34671,
      "e": 34550,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 34695,
      "e": 34574,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||ht"
    },
    {
      "t": 34751,
      "e": 34630,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 34816,
      "e": 34695,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 34816,
      "e": 34695,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 34928,
      "e": 34807,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 35152,
      "e": 35031,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "72"
    },
    {
      "t": 35153,
      "e": 35032,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 35247,
      "e": 35126,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||h"
    },
    {
      "t": 35271,
      "e": 35150,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 35271,
      "e": 35150,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 35375,
      "e": 35254,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||a"
    },
    {
      "t": 35377,
      "e": 35256,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "78"
    },
    {
      "t": 35377,
      "e": 35256,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 35464,
      "e": 35343,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||n"
    },
    {
      "t": 35504,
      "e": 35383,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "68"
    },
    {
      "t": 35504,
      "e": 35383,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 35599,
      "e": 35478,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||d"
    },
    {
      "t": 35615,
      "e": 35494,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 35615,
      "e": 35494,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 35679,
      "e": 35558,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 35687,
      "e": 35566,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "83"
    },
    {
      "t": 35687,
      "e": 35566,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 35784,
      "e": 35663,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||s"
    },
    {
      "t": 35785,
      "e": 35664,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "73"
    },
    {
      "t": 35785,
      "e": 35664,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 35855,
      "e": 35734,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||i"
    },
    {
      "t": 35895,
      "e": 35774,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "68"
    },
    {
      "t": 35895,
      "e": 35774,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 36000,
      "e": 35879,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||d"
    },
    {
      "t": 36136,
      "e": 36015,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 36136,
      "e": 36015,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 36207,
      "e": 36086,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||e"
    },
    {
      "t": 36368,
      "e": 36247,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 36369,
      "e": 36248,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 36439,
      "e": 36318,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 36656,
      "e": 36535,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "76"
    },
    {
      "t": 36656,
      "e": 36535,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 36719,
      "e": 36598,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||l"
    },
    {
      "t": 36823,
      "e": 36702,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "73"
    },
    {
      "t": 36823,
      "e": 36702,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 36903,
      "e": 36782,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||i"
    },
    {
      "t": 37006,
      "e": 36885,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "You look at the bottom axis and look for 12pm. Once you've dtermined that point you follow it up along the right hand side li"
    },
    {
      "t": 37016,
      "e": 36895,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "78"
    },
    {
      "t": 37017,
      "e": 36896,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 37120,
      "e": 36999,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||n"
    },
    {
      "t": 37215,
      "e": 37094,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 37215,
      "e": 37094,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 37296,
      "e": 37175,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||e"
    },
    {
      "t": 37376,
      "e": 37255,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 37377,
      "e": 37256,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 37479,
      "e": 37358,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 37488,
      "e": 37367,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 37488,
      "e": 37367,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 37567,
      "e": 37446,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||a"
    },
    {
      "t": 37576,
      "e": 37455,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "78"
    },
    {
      "t": 37576,
      "e": 37455,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 37656,
      "e": 37535,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "68"
    },
    {
      "t": 37657,
      "e": 37536,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 37663,
      "e": 37542,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||nd"
    },
    {
      "t": 37735,
      "e": 37614,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 37759,
      "e": 37638,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 37760,
      "e": 37639,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 37831,
      "e": 37710,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 37839,
      "e": 37718,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "87"
    },
    {
      "t": 37840,
      "e": 37719,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 37919,
      "e": 37798,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||w"
    },
    {
      "t": 37927,
      "e": 37806,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "72"
    },
    {
      "t": 37927,
      "e": 37806,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 37991,
      "e": 37870,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "73"
    },
    {
      "t": 37991,
      "e": 37870,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 38039,
      "e": 37918,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||hi"
    },
    {
      "t": 38103,
      "e": 37982,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 38104,
      "e": 37983,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "67"
    },
    {
      "t": 38104,
      "e": 37983,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 38151,
      "e": 38030,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "72"
    },
    {
      "t": 38152,
      "e": 38031,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 38176,
      "e": 38055,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||ch"
    },
    {
      "t": 38240,
      "e": 38119,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 38256,
      "e": 38135,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 38256,
      "e": 38135,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 38344,
      "e": 38223,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 38344,
      "e": 38223,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 38351,
      "e": 38230,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| e"
    },
    {
      "t": 38424,
      "e": 38303,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 38560,
      "e": 38439,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "86"
    },
    {
      "t": 38561,
      "e": 38440,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 38664,
      "e": 38543,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||v"
    },
    {
      "t": 38679,
      "e": 38558,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 38679,
      "e": 38558,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 38744,
      "e": 38623,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "82"
    },
    {
      "t": 38745,
      "e": 38624,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 38791,
      "e": 38670,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||er"
    },
    {
      "t": 38839,
      "e": 38670,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 38863,
      "e": 38694,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 38864,
      "e": 38695,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 38935,
      "e": 38766,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "80"
    },
    {
      "t": 38936,
      "e": 38767,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 38967,
      "e": 38798,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| p"
    },
    {
      "t": 39056,
      "e": 38887,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "79"
    },
    {
      "t": 39057,
      "e": 38888,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 39087,
      "e": 38918,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||o"
    },
    {
      "t": 39095,
      "e": 38926,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 39207,
      "e": 39038,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "You look at the bottom axis and look for 12pm. Once you've dtermined that point you follow it up along the right hand side line and which ever po"
    },
    {
      "t": 39256,
      "e": 39087,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "73"
    },
    {
      "t": 39257,
      "e": 39088,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 39392,
      "e": 39223,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||i"
    },
    {
      "t": 39408,
      "e": 39239,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "78"
    },
    {
      "t": 39408,
      "e": 39239,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 39495,
      "e": 39326,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||n"
    },
    {
      "t": 39519,
      "e": 39350,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 39519,
      "e": 39350,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 39583,
      "e": 39414,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 39616,
      "e": 39447,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 39616,
      "e": 39447,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 39703,
      "e": 39534,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 39712,
      "e": 39543,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "89"
    },
    {
      "t": 39712,
      "e": 39543,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 39800,
      "e": 39631,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||y"
    },
    {
      "t": 39808,
      "e": 39639,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "79"
    },
    {
      "t": 39808,
      "e": 39639,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 39871,
      "e": 39702,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "85"
    },
    {
      "t": 39871,
      "e": 39702,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 39903,
      "e": 39734,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||ou"
    },
    {
      "t": 39967,
      "e": 39798,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 39976,
      "e": 39807,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 39976,
      "e": 39807,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 40079,
      "e": 39910,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 40184,
      "e": 40015,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 40184,
      "e": 40015,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 40272,
      "e": 40103,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||e"
    },
    {
      "t": 40416,
      "e": 40247,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "78"
    },
    {
      "t": 40417,
      "e": 40248,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 40511,
      "e": 40342,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||n"
    },
    {
      "t": 40688,
      "e": 40519,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "67"
    },
    {
      "t": 40688,
      "e": 40519,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 40806,
      "e": 40637,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "You look at the bottom axis and look for 12pm. Once you've dtermined that point you follow it up along the right hand side line and which ever point you enc"
    },
    {
      "t": 40823,
      "e": 40654,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||c"
    },
    {
      "t": 40855,
      "e": 40686,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "79"
    },
    {
      "t": 40856,
      "e": 40687,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 40887,
      "e": 40718,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "85"
    },
    {
      "t": 40887,
      "e": 40718,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 40967,
      "e": 40798,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||ou"
    },
    {
      "t": 40992,
      "e": 40823,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 41080,
      "e": 40911,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "78"
    },
    {
      "t": 41081,
      "e": 40912,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 41151,
      "e": 40982,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 41152,
      "e": 40983,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 41191,
      "e": 41022,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||nt"
    },
    {
      "t": 41239,
      "e": 41070,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 41313,
      "e": 41144,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 41314,
      "e": 41145,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 41351,
      "e": 41182,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "82"
    },
    {
      "t": 41352,
      "e": 41183,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 41407,
      "e": 41238,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||er"
    },
    {
      "t": 41440,
      "e": 41271,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 41455,
      "e": 41286,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 41456,
      "e": 41287,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 41544,
      "e": 41375,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 41551,
      "e": 41382,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 41552,
      "e": 41383,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 41631,
      "e": 41462,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||a"
    },
    {
      "t": 41671,
      "e": 41502,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "76"
    },
    {
      "t": 41672,
      "e": 41503,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 41743,
      "e": 41574,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||l"
    },
    {
      "t": 41839,
      "e": 41670,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "79"
    },
    {
      "t": 41841,
      "e": 41672,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 41927,
      "e": 41758,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "78"
    },
    {
      "t": 41927,
      "e": 41758,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 41975,
      "e": 41806,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||on"
    },
    {
      "t": 42024,
      "e": 41855,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "71"
    },
    {
      "t": 42024,
      "e": 41855,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 42031,
      "e": 41862,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||g"
    },
    {
      "t": 42087,
      "e": 41918,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 42151,
      "e": 41982,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 42151,
      "e": 41982,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 42216,
      "e": 42047,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 42224,
      "e": 42055,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 42224,
      "e": 42055,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 42304,
      "e": 42135,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 42320,
      "e": 42151,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "72"
    },
    {
      "t": 42321,
      "e": 42152,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 42416,
      "e": 42247,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 42416,
      "e": 42247,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 42423,
      "e": 42254,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||ha"
    },
    {
      "t": 42487,
      "e": 42318,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 42585,
      "e": 42319,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 42586,
      "e": 42320,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 42679,
      "e": 42413,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 42712,
      "e": 42446,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 42713,
      "e": 42447,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 42799,
      "e": 42533,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 42887,
      "e": 42621,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "76"
    },
    {
      "t": 42887,
      "e": 42621,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 42960,
      "e": 42694,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||l"
    },
    {
      "t": 43048,
      "e": 42782,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "73"
    },
    {
      "t": 43048,
      "e": 42782,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 43127,
      "e": 42861,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||i"
    },
    {
      "t": 43224,
      "e": 42958,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "78"
    },
    {
      "t": 43224,
      "e": 42958,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 43303,
      "e": 43037,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||n"
    },
    {
      "t": 43319,
      "e": 43053,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 43319,
      "e": 43053,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 43394,
      "e": 43128,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||e"
    },
    {
      "t": 43424,
      "e": 43158,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 43424,
      "e": 43158,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 43479,
      "e": 43213,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "73"
    },
    {
      "t": 43479,
      "e": 43213,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 43503,
      "e": 43237,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| i"
    },
    {
      "t": 43575,
      "e": 43309,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 43623,
      "e": 43357,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "83"
    },
    {
      "t": 43623,
      "e": 43357,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 43696,
      "e": 43430,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||s"
    },
    {
      "t": 43720,
      "e": 43454,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 43720,
      "e": 43454,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 43791,
      "e": 43525,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 43855,
      "e": 43589,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "87"
    },
    {
      "t": 43856,
      "e": 43590,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 43952,
      "e": 43686,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||w"
    },
    {
      "t": 43968,
      "e": 43702,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "72"
    },
    {
      "t": 43969,
      "e": 43703,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 44031,
      "e": 43765,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 44031,
      "e": 43765,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 44046,
      "e": 43780,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||ha"
    },
    {
      "t": 44087,
      "e": 43821,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 44192,
      "e": 43926,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 44193,
      "e": 43927,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 44271,
      "e": 44005,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 44295,
      "e": 44029,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 44295,
      "e": 44029,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 44405,
      "e": 44139,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "You look at the bottom axis and look for 12pm. Once you've dtermined that point you follow it up along the right hand side line and which ever point you encounter along that line is what "
    },
    {
      "t": 44408,
      "e": 44142,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 44432,
      "e": 44166,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 44432,
      "e": 44166,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 44503,
      "e": 44237,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||e"
    },
    {
      "t": 44605,
      "e": 44339,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "You look at the bottom axis and look for 12pm. Once you've dtermined that point you follow it up along the right hand side line and which ever point you encounter along that line is what e"
    },
    {
      "t": 44648,
      "e": 44382,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "86"
    },
    {
      "t": 44648,
      "e": 44382,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 44711,
      "e": 44445,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||v"
    },
    {
      "t": 44832,
      "e": 44566,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 44832,
      "e": 44566,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 44920,
      "e": 44654,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||e"
    },
    {
      "t": 44928,
      "e": 44662,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "78"
    },
    {
      "t": 44928,
      "e": 44662,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 44999,
      "e": 44733,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 44999,
      "e": 44733,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 45039,
      "e": 44773,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||nt"
    },
    {
      "t": 45087,
      "e": 44821,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 45184,
      "e": 44918,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "83"
    },
    {
      "t": 45185,
      "e": 44919,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 45239,
      "e": 44973,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||s"
    },
    {
      "t": 45263,
      "e": 44997,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 45263,
      "e": 44997,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 45359,
      "e": 45093,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "83"
    },
    {
      "t": 45359,
      "e": 45093,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 45367,
      "e": 45101,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| s"
    },
    {
      "t": 45447,
      "e": 45181,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 45504,
      "e": 45238,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 45504,
      "e": 45238,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 45575,
      "e": 45309,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 45655,
      "e": 45389,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 45655,
      "e": 45389,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 45727,
      "e": 45461,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "82"
    },
    {
      "t": 45727,
      "e": 45461,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 45767,
      "e": 45501,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||ar"
    },
    {
      "t": 45823,
      "e": 45557,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 45911,
      "e": 45645,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 45912,
      "e": 45646,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 45992,
      "e": 45726,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 46015,
      "e": 45726,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 46017,
      "e": 45728,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 46095,
      "e": 45806,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 46096,
      "e": 45807,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 46103,
      "e": 45814,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| a"
    },
    {
      "t": 46175,
      "e": 45886,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 46255,
      "e": 45966,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 46255,
      "e": 45966,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 46328,
      "e": 46039,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 46328,
      "e": 46039,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 46329,
      "e": 46040,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 46398,
      "e": 46109,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 46520,
      "e": 46231,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "49"
    },
    {
      "t": 46520,
      "e": 46231,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 46631,
      "e": 46342,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||1"
    },
    {
      "t": 46704,
      "e": 46415,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "50"
    },
    {
      "t": 46704,
      "e": 46415,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 46791,
      "e": 46502,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||2"
    },
    {
      "t": 46823,
      "e": 46534,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "80"
    },
    {
      "t": 46823,
      "e": 46534,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 46920,
      "e": 46631,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||p"
    },
    {
      "t": 46967,
      "e": 46678,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "77"
    },
    {
      "t": 46968,
      "e": 46679,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 47063,
      "e": 46774,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||m"
    },
    {
      "t": 47144,
      "e": 46855,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "190"
    },
    {
      "t": 47144,
      "e": 46855,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 47215,
      "e": 46926,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||."
    },
    {
      "t": 47368,
      "e": 47079,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 47369,
      "e": 47080,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 47431,
      "e": 47142,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 48004,
      "e": 47715,
      "ty": 2,
      "x": 339,
      "y": 553
    },
    {
      "t": 48004,
      "e": 47715,
      "ty": 41,
      "x": 27192,
      "y": 24487,
      "ta": "#strategyAnswer"
    },
    {
      "t": 48015,
      "e": 47726,
      "ty": 7,
      "x": 463,
      "y": 518,
      "ta": "#strategyAnswer"
    },
    {
      "t": 48104,
      "e": 47815,
      "ty": 2,
      "x": 1022,
      "y": 557
    },
    {
      "t": 48205,
      "e": 47916,
      "ty": 2,
      "x": 1021,
      "y": 557
    },
    {
      "t": 48255,
      "e": 47966,
      "ty": 41,
      "x": 12755,
      "y": 30941,
      "ta": "> div.stimulus > div:[2] > svg"
    },
    {
      "t": 48301,
      "e": 48012,
      "ty": 6,
      "x": 678,
      "y": 571,
      "ta": "#strategyAnswer"
    },
    {
      "t": 48304,
      "e": 48015,
      "ty": 2,
      "x": 678,
      "y": 571
    },
    {
      "t": 48404,
      "e": 48115,
      "ty": 2,
      "x": 636,
      "y": 563
    },
    {
      "t": 48505,
      "e": 48216,
      "ty": 2,
      "x": 595,
      "y": 536
    },
    {
      "t": 48505,
      "e": 48216,
      "ty": 41,
      "x": 55969,
      "y": 10732,
      "ta": "#strategyAnswer"
    },
    {
      "t": 48605,
      "e": 48316,
      "ty": 2,
      "x": 560,
      "y": 526
    },
    {
      "t": 48717,
      "e": 48428,
      "ty": 3,
      "x": 560,
      "y": 526,
      "ta": "#strategyAnswer"
    },
    {
      "t": 48755,
      "e": 48466,
      "ty": 41,
      "x": 52035,
      "y": 2642,
      "ta": "#strategyAnswer"
    },
    {
      "t": 48803,
      "e": 48514,
      "ty": 4,
      "x": 52035,
      "y": 2642,
      "ta": "#strategyAnswer"
    },
    {
      "t": 50255,
      "e": 49966,
      "ty": 41,
      "x": 55632,
      "y": 13969,
      "ta": "#strategyAnswer"
    },
    {
      "t": 50304,
      "e": 50015,
      "ty": 2,
      "x": 592,
      "y": 540
    },
    {
      "t": 50405,
      "e": 50116,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "You look at the bottom axis and look for 12pm. Once you've determined that point you follow it up along the right hand side line and which ever point you encounter along that line is what events start at 12pm. "
    },
    {
      "t": 50504,
      "e": 50215,
      "ty": 2,
      "x": 502,
      "y": 599
    },
    {
      "t": 50505,
      "e": 50216,
      "ty": 41,
      "x": 45515,
      "y": 61704,
      "ta": "#strategyAnswer"
    },
    {
      "t": 50537,
      "e": 50248,
      "ty": 7,
      "x": 489,
      "y": 604,
      "ta": "#strategyAnswer"
    },
    {
      "t": 50605,
      "e": 50316,
      "ty": 2,
      "x": 474,
      "y": 612
    },
    {
      "t": 50705,
      "e": 50416,
      "ty": 2,
      "x": 429,
      "y": 632
    },
    {
      "t": 50754,
      "e": 50465,
      "ty": 41,
      "x": 49809,
      "y": 7382,
      "ta": "> div.stimulus > div > div:[3]"
    },
    {
      "t": 50805,
      "e": 50516,
      "ty": 2,
      "x": 412,
      "y": 640
    },
    {
      "t": 50903,
      "e": 50614,
      "ty": 6,
      "x": 399,
      "y": 654,
      "ta": "#strategyButton"
    },
    {
      "t": 50904,
      "e": 50615,
      "ty": 2,
      "x": 399,
      "y": 654
    },
    {
      "t": 51004,
      "e": 50715,
      "ty": 2,
      "x": 393,
      "y": 665
    },
    {
      "t": 51004,
      "e": 50715,
      "ty": 41,
      "x": 29712,
      "y": 19786,
      "ta": "#strategyButton"
    },
    {
      "t": 51105,
      "e": 50816,
      "ty": 2,
      "x": 393,
      "y": 672
    },
    {
      "t": 51109,
      "e": 50820,
      "ty": 3,
      "x": 393,
      "y": 672,
      "ta": "#strategyButton"
    },
    {
      "t": 51111,
      "e": 50822,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "You look at the bottom axis and look for 12pm. Once you've determined that point you follow it up along the right hand side line and which ever point you encounter along that line is what events start at 12pm. "
    },
    {
      "t": 51121,
      "e": 50832,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 51122,
      "e": 50833,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#strategyButton"
    },
    {
      "t": 51219,
      "e": 50930,
      "ty": 4,
      "x": 29712,
      "y": 33279,
      "ta": "#strategyButton"
    },
    {
      "t": 51229,
      "e": 50940,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#strategyButton"
    },
    {
      "t": 51230,
      "e": 50941,
      "ty": 5,
      "x": 393,
      "y": 672,
      "ta": "#strategyButton"
    },
    {
      "t": 51236,
      "e": 50947,
      "ty": 38,
      "x": 1,
      "y": 0
    },
    {
      "t": 51255,
      "e": 50966,
      "ty": 41,
      "x": 13258,
      "y": 36783,
      "ta": "html > body"
    },
    {
      "t": 51403,
      "e": 51114,
      "ty": 2,
      "x": 395,
      "y": 672
    },
    {
      "t": 51504,
      "e": 51215,
      "ty": 41,
      "x": 13327,
      "y": 36783,
      "ta": "html > body"
    },
    {
      "t": 52238,
      "e": 51949,
      "ty": 38,
      "x": 2,
      "y": 0
    },
    {
      "t": 52803,
      "e": 52514,
      "ty": 2,
      "x": 694,
      "y": 591
    },
    {
      "t": 52821,
      "e": 52532,
      "ty": 6,
      "x": 847,
      "y": 568,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 52837,
      "e": 52548,
      "ty": 7,
      "x": 967,
      "y": 547,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 52904,
      "e": 52548,
      "ty": 2,
      "x": 1033,
      "y": 537
    },
    {
      "t": 53004,
      "e": 52648,
      "ty": 2,
      "x": 1015,
      "y": 551
    },
    {
      "t": 53004,
      "e": 52648,
      "ty": 41,
      "x": 44771,
      "y": 42985,
      "ta": "#jspsych-survey-text-0"
    },
    {
      "t": 53021,
      "e": 52665,
      "ty": 6,
      "x": 1004,
      "y": 556,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 53104,
      "e": 52748,
      "ty": 2,
      "x": 998,
      "y": 559
    },
    {
      "t": 53204,
      "e": 52848,
      "ty": 2,
      "x": 977,
      "y": 571
    },
    {
      "t": 53212,
      "e": 52856,
      "ty": 3,
      "x": 977,
      "y": 571,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 53213,
      "e": 52857,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 53254,
      "e": 52898,
      "ty": 41,
      "x": 36552,
      "y": 53052,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 53348,
      "e": 52992,
      "ty": 4,
      "x": 36552,
      "y": 53052,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 53348,
      "e": 52992,
      "ty": 5,
      "x": 977,
      "y": 571,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 53876,
      "e": 53520,
      "ty": 7,
      "x": 974,
      "y": 586,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 53904,
      "e": 53548,
      "ty": 2,
      "x": 973,
      "y": 597
    },
    {
      "t": 53939,
      "e": 53583,
      "ty": 6,
      "x": 962,
      "y": 663,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 53956,
      "e": 53600,
      "ty": 7,
      "x": 959,
      "y": 678,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 53956,
      "e": 53600,
      "ty": 6,
      "x": 959,
      "y": 678,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 54003,
      "e": 53647,
      "ty": 2,
      "x": 959,
      "y": 680
    },
    {
      "t": 54004,
      "e": 53648,
      "ty": 41,
      "x": 32509,
      "y": 7943,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 54060,
      "e": 53704,
      "ty": 7,
      "x": 958,
      "y": 675,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 54104,
      "e": 53748,
      "ty": 2,
      "x": 956,
      "y": 671
    },
    {
      "t": 54107,
      "e": 53751,
      "ty": 6,
      "x": 956,
      "y": 666,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 54168,
      "e": 53812,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "50"
    },
    {
      "t": 54169,
      "e": 53813,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 54204,
      "e": 53848,
      "ty": 2,
      "x": 952,
      "y": 651
    },
    {
      "t": 54254,
      "e": 53898,
      "ty": 41,
      "x": 30929,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 54303,
      "e": 53947,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "2"
    },
    {
      "t": 54304,
      "e": 53948,
      "ty": 2,
      "x": 948,
      "y": 647
    },
    {
      "t": 54311,
      "e": 53955,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "49"
    },
    {
      "t": 54311,
      "e": 53955,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 54404,
      "e": 54048,
      "ty": 2,
      "x": 938,
      "y": 654
    },
    {
      "t": 54424,
      "e": 54068,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "21"
    },
    {
      "t": 54504,
      "e": 54148,
      "ty": 2,
      "x": 937,
      "y": 655
    },
    {
      "t": 54504,
      "e": 54148,
      "ty": 41,
      "x": 27901,
      "y": 24965,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 54580,
      "e": 54224,
      "ty": 3,
      "x": 936,
      "y": 656,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 54581,
      "e": 54225,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "21"
    },
    {
      "t": 54581,
      "e": 54225,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 54583,
      "e": 54227,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 54604,
      "e": 54248,
      "ty": 2,
      "x": 936,
      "y": 656
    },
    {
      "t": 54706,
      "e": 54350,
      "ty": 4,
      "x": 27684,
      "y": 28086,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 54707,
      "e": 54351,
      "ty": 5,
      "x": 936,
      "y": 656,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 54754,
      "e": 54398,
      "ty": 41,
      "x": 27684,
      "y": 28086,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 55248,
      "e": 54892,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "9"
    },
    {
      "t": 55248,
      "e": 54892,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 55249,
      "e": 54893,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 55343,
      "e": 54987,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-next",
      "v": ""
    },
    {
      "t": 55520,
      "e": 55164,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-next",
      "v": "85"
    },
    {
      "t": 55520,
      "e": 55164,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 55592,
      "e": 55236,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-next",
      "v": ""
    },
    {
      "t": 55624,
      "e": 55268,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-next",
      "v": "83"
    },
    {
      "t": 55625,
      "e": 55269,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 55718,
      "e": 55362,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-next",
      "v": ""
    },
    {
      "t": 55839,
      "e": 55483,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-next",
      "v": "65"
    },
    {
      "t": 55840,
      "e": 55484,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 55952,
      "e": 55596,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-next",
      "v": ""
    },
    {
      "t": 56956,
      "e": 56600,
      "ty": 3,
      "x": 936,
      "y": 656,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 56958,
      "e": 56602,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 56958,
      "e": 56602,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 57067,
      "e": 56711,
      "ty": 4,
      "x": 27684,
      "y": 28086,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 57067,
      "e": 56711,
      "ty": 5,
      "x": 936,
      "y": 656,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 57624,
      "e": 57268,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "20"
    },
    {
      "t": 57768,
      "e": 57412,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": ""
    },
    {
      "t": 57952,
      "e": 57596,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "85"
    },
    {
      "t": 57953,
      "e": 57597,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 58039,
      "e": 57683,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "U"
    },
    {
      "t": 58047,
      "e": 57691,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "83"
    },
    {
      "t": 58047,
      "e": 57691,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 58143,
      "e": 57787,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "US"
    },
    {
      "t": 58159,
      "e": 57803,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "65"
    },
    {
      "t": 58160,
      "e": 57804,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 58263,
      "e": 57907,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "USA"
    },
    {
      "t": 58368,
      "e": 58012,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "20"
    },
    {
      "t": 58439,
      "e": 58083,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "USA"
    },
    {
      "t": 58732,
      "e": 58376,
      "ty": 7,
      "x": 904,
      "y": 631,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 58754,
      "e": 58398,
      "ty": 41,
      "x": 13193,
      "y": 21064,
      "ta": "#jspsych-survey-text-1 > p"
    },
    {
      "t": 58804,
      "e": 58448,
      "ty": 2,
      "x": 854,
      "y": 612
    },
    {
      "t": 58826,
      "e": 58470,
      "ty": 6,
      "x": 838,
      "y": 651,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 58859,
      "e": 58503,
      "ty": 7,
      "x": 837,
      "y": 671,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 58904,
      "e": 58548,
      "ty": 2,
      "x": 849,
      "y": 677
    },
    {
      "t": 58993,
      "e": 58637,
      "ty": 6,
      "x": 902,
      "y": 694,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 59004,
      "e": 58648,
      "ty": 2,
      "x": 902,
      "y": 694
    },
    {
      "t": 59004,
      "e": 58648,
      "ty": 41,
      "x": 3132,
      "y": 35746,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 59104,
      "e": 58748,
      "ty": 2,
      "x": 916,
      "y": 694
    },
    {
      "t": 59204,
      "e": 58848,
      "ty": 2,
      "x": 917,
      "y": 694
    },
    {
      "t": 59254,
      "e": 58898,
      "ty": 41,
      "x": 10863,
      "y": 35746,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 59304,
      "e": 58948,
      "ty": 2,
      "x": 917,
      "y": 695
    },
    {
      "t": 59356,
      "e": 59000,
      "ty": 3,
      "x": 917,
      "y": 695,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 59357,
      "e": 59001,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "USA"
    },
    {
      "t": 59358,
      "e": 59002,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 59359,
      "e": 59003,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 59475,
      "e": 59119,
      "ty": 4,
      "x": 10863,
      "y": 37732,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 59476,
      "e": 59120,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 59476,
      "e": 59120,
      "ty": 5,
      "x": 917,
      "y": 695,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 59476,
      "e": 59120,
      "ty": 38,
      "x": 3,
      "y": 0
    },
    {
      "t": 59504,
      "e": 59148,
      "ty": 41,
      "x": 31303,
      "y": 38057,
      "ta": "html > body"
    },
    {
      "t": 60004,
      "e": 59648,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 60204,
      "e": 59848,
      "ty": 2,
      "x": 908,
      "y": 746
    },
    {
      "t": 60254,
      "e": 59898,
      "ty": 41,
      "x": 30993,
      "y": 40883,
      "ta": "html > body"
    },
    {
      "t": 60501,
      "e": 60145,
      "ty": 38,
      "x": 4,
      "y": 0
    },
    {
      "t": 61004,
      "e": 60648,
      "ty": 2,
      "x": 907,
      "y": 747
    },
    {
      "t": 61004,
      "e": 60648,
      "ty": 41,
      "x": 20309,
      "y": 4681,
      "ta": "#jspsych-survey-multi-choice-option-2-3"
    },
    {
      "t": 61205,
      "e": 60849,
      "ty": 2,
      "x": 897,
      "y": 740
    },
    {
      "t": 61254,
      "e": 60898,
      "ty": 41,
      "x": 26005,
      "y": 0,
      "ta": "#jspsych-survey-multi-choice-2 > p"
    },
    {
      "t": 61304,
      "e": 60948,
      "ty": 2,
      "x": 985,
      "y": 257
    },
    {
      "t": 61404,
      "e": 61048,
      "ty": 2,
      "x": 959,
      "y": 16
    },
    {
      "t": 61504,
      "e": 61148,
      "ty": 2,
      "x": 914,
      "y": 154
    },
    {
      "t": 61504,
      "e": 61148,
      "ty": 41,
      "x": 31200,
      "y": 8088,
      "ta": "html > body"
    },
    {
      "t": 61604,
      "e": 61248,
      "ty": 2,
      "x": 896,
      "y": 231
    },
    {
      "t": 61704,
      "e": 61348,
      "ty": 2,
      "x": 892,
      "y": 237
    },
    {
      "t": 61754,
      "e": 61398,
      "ty": 41,
      "x": 56156,
      "y": 29490,
      "ta": "#jspsych-survey-multi-choice-option-0-0 > label"
    },
    {
      "t": 61804,
      "e": 61448,
      "ty": 2,
      "x": 890,
      "y": 238
    },
    {
      "t": 62005,
      "e": 61649,
      "ty": 2,
      "x": 884,
      "y": 238
    },
    {
      "t": 62005,
      "e": 61649,
      "ty": 41,
      "x": 51243,
      "y": 29490,
      "ta": "#jspsych-survey-multi-choice-option-0-0 > label"
    },
    {
      "t": 62060,
      "e": 61704,
      "ty": 3,
      "x": 884,
      "y": 238,
      "ta": "#jspsych-survey-multi-choice-option-0-0 > label"
    },
    {
      "t": 62179,
      "e": 61823,
      "ty": 4,
      "x": 51243,
      "y": 29490,
      "ta": "#jspsych-survey-multi-choice-option-0-0 > label"
    },
    {
      "t": 62179,
      "e": 61823,
      "ty": 5,
      "x": 884,
      "y": 238,
      "ta": "#jspsych-survey-multi-choice-option-0-0 > label"
    },
    {
      "t": 62180,
      "e": 61824,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-0[0]_mf"
    },
    {
      "t": 62181,
      "e": 61825,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-0[0]_mf",
      "v": "English"
    },
    {
      "t": 62704,
      "e": 62348,
      "ty": 2,
      "x": 873,
      "y": 297
    },
    {
      "t": 62754,
      "e": 62398,
      "ty": 41,
      "x": 11766,
      "y": 53832,
      "ta": "#jspsych-survey-multi-choice-1 > p"
    },
    {
      "t": 62804,
      "e": 62448,
      "ty": 2,
      "x": 871,
      "y": 447
    },
    {
      "t": 62904,
      "e": 62548,
      "ty": 2,
      "x": 871,
      "y": 467
    },
    {
      "t": 63004,
      "e": 62648,
      "ty": 2,
      "x": 866,
      "y": 487
    },
    {
      "t": 63004,
      "e": 62648,
      "ty": 41,
      "x": 10579,
      "y": 4681,
      "ta": "#jspsych-survey-multi-choice-option-1-3"
    },
    {
      "t": 63105,
      "e": 62749,
      "ty": 2,
      "x": 861,
      "y": 497
    },
    {
      "t": 63204,
      "e": 62848,
      "ty": 2,
      "x": 860,
      "y": 501
    },
    {
      "t": 63254,
      "e": 62898,
      "ty": 41,
      "x": 33728,
      "y": 45874,
      "ta": "#jspsych-survey-multi-choice-option-1-3 > label"
    },
    {
      "t": 63304,
      "e": 62948,
      "ty": 2,
      "x": 859,
      "y": 503
    },
    {
      "t": 63504,
      "e": 63148,
      "ty": 2,
      "x": 859,
      "y": 498
    },
    {
      "t": 63505,
      "e": 63149,
      "ty": 41,
      "x": 33728,
      "y": 29490,
      "ta": "#jspsych-survey-multi-choice-option-1-3 > label"
    },
    {
      "t": 63573,
      "e": 63217,
      "ty": 3,
      "x": 859,
      "y": 498,
      "ta": "#jspsych-survey-multi-choice-option-1-3 > label"
    },
    {
      "t": 63574,
      "e": 63218,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-0[0]_mf"
    },
    {
      "t": 63699,
      "e": 63343,
      "ty": 4,
      "x": 33728,
      "y": 29490,
      "ta": "#jspsych-survey-multi-choice-option-1-3 > label"
    },
    {
      "t": 63699,
      "e": 63343,
      "ty": 5,
      "x": 859,
      "y": 498,
      "ta": "#jspsych-survey-multi-choice-option-1-3 > label"
    },
    {
      "t": 63699,
      "e": 63343,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-1[3]_mf"
    },
    {
      "t": 63700,
      "e": 63344,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-1[3]_mf",
      "v": "Fourth"
    },
    {
      "t": 64204,
      "e": 63848,
      "ty": 2,
      "x": 863,
      "y": 549
    },
    {
      "t": 64254,
      "e": 63898,
      "ty": 41,
      "x": 6544,
      "y": 33851,
      "ta": "#jspsych-survey-multi-choice-form"
    },
    {
      "t": 64304,
      "e": 63948,
      "ty": 2,
      "x": 846,
      "y": 622
    },
    {
      "t": 64404,
      "e": 64048,
      "ty": 2,
      "x": 846,
      "y": 625
    },
    {
      "t": 64505,
      "e": 64149,
      "ty": 2,
      "x": 843,
      "y": 645
    },
    {
      "t": 64505,
      "e": 64149,
      "ty": 41,
      "x": 5121,
      "y": 8124,
      "ta": "#jspsych-survey-multi-choice-2"
    },
    {
      "t": 64604,
      "e": 64248,
      "ty": 2,
      "x": 848,
      "y": 683
    },
    {
      "t": 64705,
      "e": 64349,
      "ty": 2,
      "x": 851,
      "y": 692
    },
    {
      "t": 64754,
      "e": 64398,
      "ty": 41,
      "x": 8209,
      "y": 32767,
      "ta": "#jspsych-survey-multi-choice-option-2-1 > label"
    },
    {
      "t": 64805,
      "e": 64449,
      "ty": 2,
      "x": 855,
      "y": 712
    },
    {
      "t": 65004,
      "e": 64648,
      "ty": 41,
      "x": 8461,
      "y": 62258,
      "ta": "#jspsych-survey-multi-choice-option-2-1 > label"
    },
    {
      "t": 65255,
      "e": 64649,
      "ty": 41,
      "x": 7968,
      "y": 56172,
      "ta": "#jspsych-survey-multi-choice-option-2-1"
    },
    {
      "t": 65304,
      "e": 64698,
      "ty": 2,
      "x": 852,
      "y": 722
    },
    {
      "t": 65404,
      "e": 64798,
      "ty": 2,
      "x": 847,
      "y": 747
    },
    {
      "t": 65505,
      "e": 64899,
      "ty": 2,
      "x": 843,
      "y": 766
    },
    {
      "t": 65505,
      "e": 64899,
      "ty": 41,
      "x": 9003,
      "y": 55704,
      "ta": "#jspsych-survey-multi-choice-option-2-3 > label"
    },
    {
      "t": 65605,
      "e": 64999,
      "ty": 2,
      "x": 842,
      "y": 769
    },
    {
      "t": 65665,
      "e": 65059,
      "ty": 6,
      "x": 839,
      "y": 780,
      "ta": "jspsych-survey-multi-choice-response-2[4]_mf"
    },
    {
      "t": 65704,
      "e": 65098,
      "ty": 2,
      "x": 839,
      "y": 783
    },
    {
      "t": 65754,
      "e": 65148,
      "ty": 41,
      "x": 63408,
      "y": 50411,
      "ta": "jspsych-survey-multi-choice-response-2[4]_mf"
    },
    {
      "t": 65765,
      "e": 65159,
      "ty": 7,
      "x": 839,
      "y": 793,
      "ta": "jspsych-survey-multi-choice-response-2[4]_mf"
    },
    {
      "t": 65804,
      "e": 65198,
      "ty": 2,
      "x": 839,
      "y": 801
    },
    {
      "t": 65904,
      "e": 65298,
      "ty": 2,
      "x": 841,
      "y": 814
    },
    {
      "t": 66004,
      "e": 65398,
      "ty": 2,
      "x": 843,
      "y": 823
    },
    {
      "t": 66005,
      "e": 65399,
      "ty": 41,
      "x": 12736,
      "y": 58981,
      "ta": "#jspsych-survey-multi-choice-option-2-5 > label"
    },
    {
      "t": 66104,
      "e": 65498,
      "ty": 2,
      "x": 844,
      "y": 818
    },
    {
      "t": 66196,
      "e": 65590,
      "ty": 3,
      "x": 846,
      "y": 816,
      "ta": "#jspsych-survey-multi-choice-option-2-5 > label"
    },
    {
      "t": 66197,
      "e": 65591,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-1[3]_mf"
    },
    {
      "t": 66204,
      "e": 65598,
      "ty": 2,
      "x": 846,
      "y": 816
    },
    {
      "t": 66254,
      "e": 65648,
      "ty": 41,
      "x": 15097,
      "y": 36044,
      "ta": "#jspsych-survey-multi-choice-option-2-5 > label"
    },
    {
      "t": 66304,
      "e": 65698,
      "ty": 2,
      "x": 847,
      "y": 816
    },
    {
      "t": 66307,
      "e": 65701,
      "ty": 4,
      "x": 15097,
      "y": 36044,
      "ta": "#jspsych-survey-multi-choice-option-2-5 > label"
    },
    {
      "t": 66307,
      "e": 65701,
      "ty": 5,
      "x": 847,
      "y": 816,
      "ta": "#jspsych-survey-multi-choice-option-2-5 > label"
    },
    {
      "t": 66307,
      "e": 65701,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-2[5]_mf"
    },
    {
      "t": 66308,
      "e": 65702,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-2[5]_mf",
      "v": "Humanities"
    },
    {
      "t": 66704,
      "e": 66098,
      "ty": 2,
      "x": 838,
      "y": 822
    },
    {
      "t": 66732,
      "e": 66126,
      "ty": 6,
      "x": 829,
      "y": 841,
      "ta": "jspsych-survey-multi-choice-response-2[6]_mf"
    },
    {
      "t": 66749,
      "e": 66143,
      "ty": 7,
      "x": 824,
      "y": 862,
      "ta": "jspsych-survey-multi-choice-response-2[6]_mf"
    },
    {
      "t": 66754,
      "e": 66148,
      "ty": 41,
      "x": 611,
      "y": 52383,
      "ta": "#jspsych-survey-multi-choice-form"
    },
    {
      "t": 66804,
      "e": 66198,
      "ty": 2,
      "x": 824,
      "y": 870
    },
    {
      "t": 66904,
      "e": 66298,
      "ty": 2,
      "x": 824,
      "y": 890
    },
    {
      "t": 67005,
      "e": 66399,
      "ty": 41,
      "x": 611,
      "y": 35108,
      "ta": "#jspsych-survey-multi-choice-3 > p"
    },
    {
      "t": 67404,
      "e": 66798,
      "ty": 2,
      "x": 831,
      "y": 882
    },
    {
      "t": 67504,
      "e": 66898,
      "ty": 41,
      "x": 2273,
      "y": 16383,
      "ta": "#jspsych-survey-multi-choice-3 > p"
    },
    {
      "t": 67704,
      "e": 67098,
      "ty": 2,
      "x": 841,
      "y": 909
    },
    {
      "t": 67755,
      "e": 67149,
      "ty": 41,
      "x": 5121,
      "y": 21676,
      "ta": "#jspsych-survey-multi-choice-3"
    },
    {
      "t": 67804,
      "e": 67198,
      "ty": 2,
      "x": 842,
      "y": 923
    },
    {
      "t": 67904,
      "e": 67298,
      "ty": 2,
      "x": 842,
      "y": 930
    },
    {
      "t": 68005,
      "e": 67399,
      "ty": 2,
      "x": 843,
      "y": 943
    },
    {
      "t": 68005,
      "e": 67399,
      "ty": 41,
      "x": 23568,
      "y": 58981,
      "ta": "#jspsych-survey-multi-choice-option-3-0 > label"
    },
    {
      "t": 68104,
      "e": 67498,
      "ty": 2,
      "x": 843,
      "y": 950
    },
    {
      "t": 68204,
      "e": 67598,
      "ty": 2,
      "x": 842,
      "y": 953
    },
    {
      "t": 68255,
      "e": 67649,
      "ty": 41,
      "x": 16646,
      "y": 3276,
      "ta": "#jspsych-survey-multi-choice-option-3-1 > label"
    },
    {
      "t": 68285,
      "e": 67650,
      "ty": 6,
      "x": 839,
      "y": 958,
      "ta": "jspsych-survey-multi-choice-response-3[1]_mf"
    },
    {
      "t": 68304,
      "e": 67669,
      "ty": 2,
      "x": 837,
      "y": 959
    },
    {
      "t": 68379,
      "e": 67744,
      "ty": 3,
      "x": 835,
      "y": 962,
      "ta": "jspsych-survey-multi-choice-response-3[1]_mf"
    },
    {
      "t": 68379,
      "e": 67744,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-2[5]_mf"
    },
    {
      "t": 68379,
      "e": 67744,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-3[1]_mf"
    },
    {
      "t": 68404,
      "e": 67769,
      "ty": 2,
      "x": 835,
      "y": 962
    },
    {
      "t": 68483,
      "e": 67848,
      "ty": 4,
      "x": 43243,
      "y": 30246,
      "ta": "jspsych-survey-multi-choice-response-3[1]_mf"
    },
    {
      "t": 68484,
      "e": 67849,
      "ty": 5,
      "x": 835,
      "y": 962,
      "ta": "jspsych-survey-multi-choice-response-3[1]_mf"
    },
    {
      "t": 68484,
      "e": 67849,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-3[1]_mf",
      "v": "Female"
    },
    {
      "t": 68504,
      "e": 67869,
      "ty": 41,
      "x": 43243,
      "y": 30246,
      "ta": "jspsych-survey-multi-choice-response-3[1]_mf"
    },
    {
      "t": 68604,
      "e": 67969,
      "ty": 2,
      "x": 835,
      "y": 963
    },
    {
      "t": 68635,
      "e": 68000,
      "ty": 7,
      "x": 837,
      "y": 971,
      "ta": "jspsych-survey-multi-choice-response-3[1]_mf"
    },
    {
      "t": 68705,
      "e": 68070,
      "ty": 2,
      "x": 837,
      "y": 971
    },
    {
      "t": 68754,
      "e": 68119,
      "ty": 41,
      "x": 12601,
      "y": 58981,
      "ta": "#jspsych-survey-multi-choice-option-3-1 > label"
    },
    {
      "t": 69201,
      "e": 68566,
      "ty": 6,
      "x": 836,
      "y": 957,
      "ta": "jspsych-survey-multi-choice-response-3[1]_mf"
    },
    {
      "t": 69204,
      "e": 68569,
      "ty": 2,
      "x": 836,
      "y": 957
    },
    {
      "t": 69218,
      "e": 68583,
      "ty": 7,
      "x": 832,
      "y": 946,
      "ta": "jspsych-survey-multi-choice-response-3[1]_mf"
    },
    {
      "t": 69255,
      "e": 68620,
      "ty": 41,
      "x": 2510,
      "y": 58513,
      "ta": "#jspsych-survey-multi-choice-option-3-0"
    },
    {
      "t": 69305,
      "e": 68670,
      "ty": 2,
      "x": 832,
      "y": 946
    },
    {
      "t": 69505,
      "e": 68870,
      "ty": 2,
      "x": 832,
      "y": 949
    },
    {
      "t": 69505,
      "e": 68870,
      "ty": 41,
      "x": 2510,
      "y": 0,
      "ta": "#jspsych-survey-multi-choice-option-3-1"
    },
    {
      "t": 69518,
      "e": 68883,
      "ty": 6,
      "x": 839,
      "y": 966,
      "ta": "jspsych-survey-multi-choice-response-3[1]_mf"
    },
    {
      "t": 69535,
      "e": 68900,
      "ty": 7,
      "x": 848,
      "y": 975,
      "ta": "jspsych-survey-multi-choice-response-3[1]_mf"
    },
    {
      "t": 69604,
      "e": 68969,
      "ty": 2,
      "x": 880,
      "y": 992
    },
    {
      "t": 69668,
      "e": 69033,
      "ty": 6,
      "x": 896,
      "y": 1007,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 69704,
      "e": 69069,
      "ty": 2,
      "x": 908,
      "y": 1021
    },
    {
      "t": 69754,
      "e": 69119,
      "ty": 41,
      "x": 40498,
      "y": 31774,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 69804,
      "e": 69169,
      "ty": 2,
      "x": 908,
      "y": 1023
    },
    {
      "t": 69905,
      "e": 69270,
      "ty": 2,
      "x": 908,
      "y": 1028
    },
    {
      "t": 70004,
      "e": 69369,
      "ty": 2,
      "x": 911,
      "y": 1028
    },
    {
      "t": 70005,
      "e": 69370,
      "ty": 41,
      "x": 42044,
      "y": 45675,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 70100,
      "e": 69465,
      "ty": 3,
      "x": 911,
      "y": 1028,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 70101,
      "e": 69466,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-3[1]_mf"
    },
    {
      "t": 70102,
      "e": 69467,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 70219,
      "e": 69584,
      "ty": 4,
      "x": 42044,
      "y": 45675,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 70219,
      "e": 69584,
      "ty": 5,
      "x": 911,
      "y": 1028,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 70222,
      "e": 69587,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 70223,
      "e": 69588,
      "ty": 13,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-multi-choice-form"
    },
    {
      "t": 70224,
      "e": 69589,
      "ty": 38,
      "x": 5,
      "y": 0
    },
    {
      "t": 70405,
      "e": 69770,
      "ty": 2,
      "x": 910,
      "y": 1028
    },
    {
      "t": 70505,
      "e": 69870,
      "ty": 41,
      "x": 31062,
      "y": 56505,
      "ta": "html > body"
    },
    {
      "t": 71105,
      "e": 70470,
      "ty": 2,
      "x": 909,
      "y": 1028
    },
    {
      "t": 71255,
      "e": 70620,
      "ty": 41,
      "x": 31028,
      "y": 56505,
      "ta": "html > body"
    },
    {
      "t": 71565,
      "e": 70930,
      "ty": 38,
      "x": 6,
      "y": 0
    },
    {
      "t": 71805,
      "e": 71170,
      "ty": 2,
      "x": 904,
      "y": 1031
    },
    {
      "t": 71905,
      "e": 71270,
      "ty": 2,
      "x": 902,
      "y": 1032
    },
    {
      "t": 72004,
      "e": 71369,
      "ty": 2,
      "x": 899,
      "y": 1034
    },
    {
      "t": 72005,
      "e": 71370,
      "ty": 41,
      "x": 29791,
      "y": 62855,
      "ta": "> div.masterdiv > div:[2]"
    },
    {
      "t": 75605,
      "e": 74970,
      "ty": 2,
      "x": 901,
      "y": 1031
    },
    {
      "t": 75754,
      "e": 75119,
      "ty": 41,
      "x": 29889,
      "y": 62648,
      "ta": "> div.masterdiv > div:[2]"
    },
    {
      "t": 76505,
      "e": 75870,
      "ty": 2,
      "x": 896,
      "y": 979
    },
    {
      "t": 76505,
      "e": 75870,
      "ty": 41,
      "x": 29643,
      "y": 59047,
      "ta": "> div.masterdiv > div:[2]"
    },
    {
      "t": 76605,
      "e": 75970,
      "ty": 2,
      "x": 889,
      "y": 937
    },
    {
      "t": 76705,
      "e": 76070,
      "ty": 2,
      "x": 877,
      "y": 940
    },
    {
      "t": 76755,
      "e": 76120,
      "ty": 41,
      "x": 28708,
      "y": 56346,
      "ta": "> div.masterdiv > div:[2]"
    },
    {
      "t": 76904,
      "e": 76269,
      "ty": 2,
      "x": 874,
      "y": 941
    },
    {
      "t": 77004,
      "e": 76369,
      "ty": 2,
      "x": 755,
      "y": 929
    },
    {
      "t": 77005,
      "e": 76370,
      "ty": 41,
      "x": 22706,
      "y": 55585,
      "ta": "> div.masterdiv > div:[2]"
    },
    {
      "t": 77505,
      "e": 76870,
      "ty": 2,
      "x": 754,
      "y": 925
    },
    {
      "t": 77505,
      "e": 76870,
      "ty": 41,
      "x": 22657,
      "y": 55308,
      "ta": "> div.masterdiv > div:[2]"
    },
    {
      "t": 77604,
      "e": 76969,
      "ty": 2,
      "x": 753,
      "y": 921
    },
    {
      "t": 77754,
      "e": 77119,
      "ty": 41,
      "x": 22608,
      "y": 55031,
      "ta": "> div.masterdiv > div:[2]"
    },
    {
      "t": 78004,
      "e": 77369,
      "ty": 2,
      "x": 753,
      "y": 920
    },
    {
      "t": 78004,
      "e": 77369,
      "ty": 41,
      "x": 22608,
      "y": 54961,
      "ta": "> div.masterdiv > div:[2]"
    },
    {
      "t": 78103,
      "e": 77468,
      "ty": 2,
      "x": 755,
      "y": 914
    },
    {
      "t": 78254,
      "e": 77619,
      "ty": 41,
      "x": 22706,
      "y": 54546,
      "ta": "> div.masterdiv > div:[2]"
    },
    {
      "t": 80004,
      "e": 79369,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 80203,
      "e": 79568,
      "ty": 2,
      "x": 763,
      "y": 913
    },
    {
      "t": 80254,
      "e": 79619,
      "ty": 41,
      "x": 23395,
      "y": 54338,
      "ta": "> div.masterdiv > div:[2]"
    },
    {
      "t": 80303,
      "e": 79668,
      "ty": 2,
      "x": 770,
      "y": 910
    },
    {
      "t": 80404,
      "e": 79769,
      "ty": 2,
      "x": 771,
      "y": 910
    },
    {
      "t": 80503,
      "e": 79868,
      "ty": 2,
      "x": 773,
      "y": 910
    },
    {
      "t": 80505,
      "e": 79870,
      "ty": 41,
      "x": 23592,
      "y": 54269,
      "ta": "> div.masterdiv > div:[2]"
    },
    {
      "t": 80703,
      "e": 80068,
      "ty": 2,
      "x": 776,
      "y": 909
    },
    {
      "t": 80754,
      "e": 80119,
      "ty": 41,
      "x": 23739,
      "y": 54200,
      "ta": "> div.masterdiv > div:[2]"
    },
    {
      "t": 85408,
      "e": 84773,
      "ty": 2,
      "x": 777,
      "y": 908
    },
    {
      "t": 85509,
      "e": 84874,
      "ty": 41,
      "x": 23789,
      "y": 54130,
      "ta": "> div.masterdiv > div:[2]"
    },
    {
      "t": 86208,
      "e": 85573,
      "ty": 2,
      "x": 781,
      "y": 908
    },
    {
      "t": 86259,
      "e": 85624,
      "ty": 41,
      "x": 24084,
      "y": 54130,
      "ta": "> div.masterdiv > div:[2]"
    },
    {
      "t": 86309,
      "e": 85674,
      "ty": 2,
      "x": 861,
      "y": 981
    },
    {
      "t": 86408,
      "e": 85773,
      "ty": 2,
      "x": 981,
      "y": 1056
    },
    {
      "t": 86509,
      "e": 85874,
      "ty": 2,
      "x": 987,
      "y": 1065
    },
    {
      "t": 86509,
      "e": 85874,
      "ty": 41,
      "x": 34120,
      "y": 65002,
      "ta": "> div.masterdiv > div:[2]"
    },
    {
      "t": 86536,
      "e": 85901,
      "ty": 6,
      "x": 993,
      "y": 1075,
      "ta": "#start"
    },
    {
      "t": 86608,
      "e": 85973,
      "ty": 2,
      "x": 1006,
      "y": 1087
    },
    {
      "t": 86759,
      "e": 86124,
      "ty": 41,
      "x": 53247,
      "y": 27587,
      "ta": "#start"
    },
    {
      "t": 86808,
      "e": 86173,
      "ty": 2,
      "x": 1007,
      "y": 1087
    },
    {
      "t": 87209,
      "e": 86574,
      "ty": 2,
      "x": 996,
      "y": 1075
    },
    {
      "t": 87258,
      "e": 86623,
      "ty": 41,
      "x": 46693,
      "y": 2529,
      "ta": "#start"
    },
    {
      "t": 87309,
      "e": 86674,
      "ty": 2,
      "x": 995,
      "y": 1074
    },
    {
      "t": 87392,
      "e": 86757,
      "ty": 7,
      "x": 996,
      "y": 1071,
      "ta": "#start"
    },
    {
      "t": 87408,
      "e": 86773,
      "ty": 2,
      "x": 997,
      "y": 1071
    },
    {
      "t": 87509,
      "e": 86874,
      "ty": 41,
      "x": 34612,
      "y": 65418,
      "ta": "> div.masterdiv > div:[2]"
    },
    {
      "t": 87513,
      "e": 86878,
      "ty": 6,
      "x": 997,
      "y": 1072,
      "ta": "#start"
    },
    {
      "t": 87609,
      "e": 86974,
      "ty": 2,
      "x": 997,
      "y": 1078
    },
    {
      "t": 87708,
      "e": 87073,
      "ty": 2,
      "x": 999,
      "y": 1080
    },
    {
      "t": 87758,
      "e": 87123,
      "ty": 41,
      "x": 50516,
      "y": 19877,
      "ta": "#start"
    },
    {
      "t": 87809,
      "e": 87174,
      "ty": 2,
      "x": 1003,
      "y": 1089
    },
    {
      "t": 87908,
      "e": 87273,
      "ty": 2,
      "x": 1003,
      "y": 1090
    },
    {
      "t": 88009,
      "e": 87374,
      "ty": 41,
      "x": 51062,
      "y": 33369,
      "ta": "#start"
    },
    {
      "t": 88066,
      "e": 87431,
      "ty": 3,
      "x": 1004,
      "y": 1090,
      "ta": "#start"
    },
    {
      "t": 88066,
      "e": 87431,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#start"
    },
    {
      "t": 88109,
      "e": 87474,
      "ty": 2,
      "x": 1004,
      "y": 1090
    },
    {
      "t": 88200,
      "e": 87565,
      "ty": 4,
      "x": 51608,
      "y": 33369,
      "ta": "#start"
    },
    {
      "t": 88202,
      "e": 87567,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#start"
    },
    {
      "t": 88202,
      "e": 87567,
      "ty": 5,
      "x": 1004,
      "y": 1090,
      "ta": "#start"
    },
    {
      "t": 88203,
      "e": 87568,
      "ty": 38,
      "x": 7,
      "y": 0
    },
    {
      "t": 88259,
      "e": 87624,
      "ty": 41,
      "x": 34334,
      "y": 59884,
      "ta": "html > body"
    },
    {
      "t": 88309,
      "e": 87674,
      "ty": 2,
      "x": 1005,
      "y": 1089
    },
    {
      "t": 89232,
      "e": 88597,
      "ty": 38,
      "x": 8,
      "y": 0
    },
    {
      "t": 90009,
      "e": 89374,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 90396,
      "e": 89761,
      "ty": 20,
      "x": 0,
      "y": 0
    }
  ],
  "domMutations": [
    {
      "sequence": 1,
      "data": "{\"f\":\"applyChanged\",\"args\":[[{\"id\":56},{\"id\":57},{\"id\":58},{\"id\":59},{\"id\":60},{\"id\":61},{\"id\":62},{\"id\":63},{\"id\":64},{\"id\":65},{\"id\":66},{\"id\":67},{\"id\":68},{\"id\":69},{\"id\":70},{\"id\":71},{\"id\":72},{\"id\":73},{\"id\":74},{\"id\":75},{\"id\":76},{\"id\":77},{\"id\":78},{\"id\":79},{\"id\":80},{\"id\":81},{\"id\":82},{\"id\":83},{\"id\":84},{\"id\":85},{\"id\":86},{\"id\":87},{\"id\":88},{\"id\":89},{\"id\":90},{\"id\":91},{\"id\":92},{\"id\":93},{\"id\":94},{\"id\":95},{\"id\":96},{\"id\":97},{\"id\":98},{\"id\":99},{\"id\":100},{\"id\":101},{\"id\":102},{\"id\":103},{\"id\":104},{\"id\":105},{\"id\":106},{\"id\":107},{\"id\":108},{\"id\":109},{\"id\":110},{\"id\":111},{\"id\":112},{\"id\":113},{\"id\":114},{\"id\":115},{\"id\":116},{\"id\":117},{\"id\":118},{\"id\":119},{\"id\":120},{\"id\":121},{\"id\":122},{\"id\":123},{\"id\":124},{\"id\":125},{\"id\":126},{\"id\":127},{\"id\":128},{\"id\":129},{\"id\":130},{\"id\":131},{\"id\":132},{\"id\":133},{\"id\":134},{\"id\":135},{\"id\":136},{\"id\":137},{\"id\":138},{\"id\":139},{\"id\":140},{\"id\":141},{\"id\":142},{\"id\":143},{\"id\":144},{\"id\":145},{\"id\":146},{\"id\":147},{\"id\":148},{\"id\":149},{\"id\":150},{\"id\":151},{\"id\":152},{\"id\":153},{\"id\":154},{\"id\":155},{\"id\":156},{\"id\":157},{\"id\":158},{\"id\":159},{\"id\":160},{\"id\":161},{\"id\":162},{\"id\":163},{\"id\":164},{\"id\":165},{\"id\":166},{\"id\":167},{\"id\":168},{\"id\":169},{\"id\":170},{\"id\":171},{\"id\":172},{\"id\":173},{\"id\":174},{\"id\":175},{\"id\":176},{\"id\":177},{\"id\":178},{\"id\":179},{\"id\":180},{\"id\":181},{\"id\":182},{\"id\":183},{\"id\":184},{\"id\":185},{\"id\":186},{\"id\":187},{\"id\":188},{\"id\":189},{\"id\":190},{\"id\":191},{\"id\":192},{\"id\":193},{\"id\":194},{\"id\":195},{\"id\":196},{\"id\":197},{\"id\":198},{\"id\":199},{\"id\":200},{\"id\":201},{\"id\":202},{\"id\":203},{\"id\":204},{\"id\":205},{\"id\":206},{\"id\":207},{\"id\":208},{\"id\":209},{\"id\":210},{\"id\":211},{\"id\":212},{\"id\":213},{\"id\":214},{\"id\":215},{\"id\":216},{\"id\":217},{\"id\":218},{\"id\":219},{\"id\":220},{\"id\":221},{\"id\":222},{\"id\":223},{\"id\":224},{\"id\":225},{\"id\":226},{\"id\":227},{\"id\":228},{\"id\":229},{\"id\":230},{\"id\":231},{\"id\":232},{\"id\":233},{\"id\":234},{\"id\":235},{\"id\":236},{\"id\":237},{\"id\":238},{\"id\":239},{\"id\":240},{\"id\":241},{\"id\":242},{\"id\":243},{\"id\":244},{\"id\":245},{\"id\":246},{\"id\":247},{\"id\":248},{\"id\":249},{\"id\":250},{\"id\":251},{\"id\":252},{\"id\":253},{\"id\":254},{\"id\":255},{\"id\":256},{\"id\":257},{\"id\":258},{\"id\":259},{\"id\":260},{\"id\":261},{\"id\":262},{\"id\":263},{\"id\":264},{\"id\":265},{\"id\":266},{\"id\":267},{\"id\":268},{\"id\":269},{\"id\":270},{\"id\":271},{\"id\":272},{\"id\":273},{\"id\":274},{\"id\":275},{\"id\":276},{\"id\":277},{\"id\":278},{\"id\":279},{\"id\":280},{\"id\":281},{\"id\":282},{\"id\":283},{\"id\":284},{\"id\":285},{\"id\":286},{\"id\":287},{\"id\":288},{\"id\":289},{\"id\":290},{\"id\":291},{\"id\":292},{\"id\":293},{\"id\":294},{\"id\":295},{\"id\":296},{\"id\":297},{\"id\":298},{\"id\":299},{\"id\":300},{\"id\":301},{\"id\":302},{\"id\":303},{\"id\":304},{\"id\":305},{\"id\":306},{\"id\":307},{\"id\":308},{\"id\":309},{\"id\":310},{\"id\":311},{\"id\":312},{\"id\":313},{\"id\":314},{\"id\":315},{\"id\":316},{\"id\":317},{\"id\":318},{\"id\":319},{\"id\":320},{\"id\":321},{\"id\":322},{\"id\":323},{\"id\":324},{\"id\":325},{\"id\":326},{\"id\":327},{\"id\":328},{\"id\":329},{\"id\":330},{\"id\":331},{\"id\":332},{\"id\":333},{\"id\":334},{\"id\":335},{\"id\":336},{\"id\":337},{\"id\":338},{\"id\":339},{\"id\":340},{\"id\":341},{\"id\":342},{\"id\":343},{\"id\":344},{\"id\":345},{\"id\":346},{\"id\":347},{\"id\":348},{\"id\":349},{\"id\":350},{\"id\":351},{\"id\":352},{\"id\":353},{\"id\":354},{\"id\":355},{\"id\":356},{\"id\":357},{\"id\":358},{\"id\":359},{\"id\":360},{\"id\":361},{\"id\":362},{\"id\":363},{\"id\":364},{\"id\":365},{\"id\":366},{\"id\":367},{\"id\":368},{\"id\":369},{\"id\":370},{\"id\":371},{\"id\":372},{\"id\":373},{\"id\":374},{\"id\":375},{\"id\":376},{\"id\":377},{\"id\":378},{\"id\":379},{\"id\":380},{\"id\":381},{\"id\":382},{\"id\":383},{\"id\":384},{\"id\":385},{\"id\":386},{\"id\":387},{\"id\":388},{\"id\":389},{\"id\":390},{\"id\":391},{\"id\":392},{\"id\":393},{\"id\":394},{\"id\":395},{\"id\":396},{\"id\":397},{\"id\":398},{\"id\":399},{\"id\":400},{\"id\":401},{\"id\":402},{\"id\":403},{\"id\":404},{\"id\":405},{\"id\":406},{\"id\":407},{\"id\":408},{\"id\":409},{\"id\":410},{\"id\":411},{\"id\":412},{\"id\":413},{\"id\":414},{\"id\":415},{\"id\":416},{\"id\":417},{\"id\":418},{\"id\":419},{\"id\":420},{\"id\":421},{\"id\":422},{\"id\":423},{\"id\":424},{\"id\":425},{\"id\":426},{\"id\":427},{\"id\":428},{\"id\":429},{\"id\":430},{\"id\":431},{\"id\":432},{\"id\":433},{\"id\":434},{\"id\":435},{\"id\":436},{\"id\":437},{\"id\":438},{\"id\":439},{\"id\":440},{\"id\":441},{\"id\":442},{\"id\":443},{\"id\":444},{\"id\":445},{\"id\":446},{\"id\":447},{\"id\":448},{\"id\":449},{\"id\":450},{\"id\":451},{\"id\":452},{\"id\":453},{\"id\":454},{\"id\":455},{\"id\":456},{\"id\":457},{\"id\":458},{\"id\":459},{\"id\":460},{\"id\":461},{\"id\":462},{\"id\":463},{\"id\":464},{\"id\":465},{\"id\":466},{\"id\":467},{\"id\":468},{\"id\":469},{\"id\":470},{\"id\":471},{\"id\":472},{\"id\":473},{\"id\":474},{\"id\":475},{\"id\":476},{\"id\":477},{\"id\":478},{\"id\":479},{\"id\":480},{\"id\":481},{\"id\":482},{\"id\":483},{\"id\":484},{\"id\":485},{\"id\":486},{\"id\":487},{\"id\":488},{\"id\":489},{\"id\":490},{\"id\":491},{\"id\":492},{\"id\":493},{\"id\":494},{\"id\":495},{\"id\":496},{\"id\":497},{\"id\":498},{\"id\":499},{\"id\":500},{\"id\":501},{\"id\":502},{\"id\":503},{\"id\":504},{\"id\":505},{\"id\":506},{\"id\":507},{\"id\":508},{\"id\":509},{\"id\":510},{\"id\":511},{\"id\":512},{\"id\":513},{\"id\":514},{\"id\":515},{\"id\":516},{\"id\":517},{\"id\":518},{\"id\":519},{\"id\":520},{\"id\":521},{\"id\":522},{\"id\":523},{\"id\":524},{\"id\":525},{\"id\":526},{\"id\":527},{\"id\":528},{\"id\":529},{\"id\":530},{\"id\":531},{\"id\":532},{\"id\":533},{\"id\":534},{\"id\":535},{\"id\":536},{\"id\":537},{\"id\":538},{\"id\":539},{\"id\":540},{\"id\":541},{\"id\":542},{\"id\":543},{\"id\":544},{\"id\":545},{\"id\":546},{\"id\":547},{\"id\":548},{\"id\":549},{\"id\":550},{\"id\":551},{\"id\":552},{\"id\":553},{\"id\":554},{\"id\":555},{\"id\":556},{\"id\":557},{\"id\":558},{\"id\":559},{\"id\":560},{\"id\":561},{\"id\":562},{\"id\":563},{\"id\":564},{\"id\":565},{\"id\":566},{\"id\":567},{\"id\":568},{\"id\":569},{\"id\":570},{\"id\":571},{\"id\":572},{\"id\":573},{\"id\":574},{\"id\":575},{\"id\":576},{\"id\":577},{\"id\":578},{\"id\":579},{\"id\":580},{\"id\":581},{\"id\":582},{\"id\":583},{\"id\":584},{\"id\":585},{\"id\":586},{\"id\":587},{\"id\":588},{\"id\":589},{\"id\":590},{\"id\":591},{\"id\":592},{\"id\":593},{\"id\":594},{\"id\":595},{\"id\":596},{\"id\":597},{\"id\":598},{\"id\":599},{\"id\":600},{\"id\":601},{\"id\":602},{\"id\":603},{\"id\":604},{\"id\":605},{\"id\":606},{\"id\":607},{\"id\":608},{\"id\":609},{\"id\":610},{\"id\":611},{\"id\":612},{\"id\":613},{\"id\":614},{\"id\":615},{\"id\":616},{\"id\":617},{\"id\":618},{\"id\":619},{\"id\":620},{\"id\":621},{\"id\":622},{\"id\":623},{\"id\":624},{\"id\":625},{\"id\":626},{\"id\":627},{\"id\":628},{\"id\":629},{\"id\":630},{\"id\":631},{\"id\":632},{\"id\":633},{\"id\":634},{\"id\":635},{\"id\":636},{\"id\":637},{\"id\":638},{\"id\":639},{\"id\":640},{\"id\":641},{\"id\":642},{\"id\":643},{\"id\":644},{\"id\":645},{\"id\":646},{\"id\":647},{\"id\":648},{\"id\":649},{\"id\":650},{\"id\":651},{\"id\":652},{\"id\":653},{\"id\":654},{\"id\":655},{\"id\":656},{\"id\":657},{\"id\":658},{\"id\":659},{\"id\":660},{\"id\":661},{\"id\":662},{\"id\":663},{\"id\":664},{\"id\":665},{\"id\":666},{\"id\":667},{\"id\":668},{\"id\":669},{\"id\":670},{\"id\":671},{\"id\":672},{\"id\":673},{\"id\":674},{\"id\":675},{\"id\":676},{\"id\":677},{\"id\":678},{\"id\":679},{\"id\":680},{\"id\":681},{\"id\":682},{\"id\":683},{\"id\":684},{\"id\":685},{\"id\":686},{\"id\":687},{\"id\":688},{\"id\":689},{\"id\":690},{\"id\":691},{\"id\":692},{\"id\":693},{\"id\":694},{\"id\":695},{\"id\":696},{\"id\":697},{\"id\":698},{\"id\":699},{\"id\":700},{\"id\":701},{\"id\":702},{\"id\":703},{\"id\":704},{\"id\":705},{\"id\":706},{\"id\":707},{\"id\":708},{\"id\":709},{\"id\":710},{\"id\":711},{\"id\":712},{\"id\":713},{\"id\":714},{\"id\":715},{\"id\":716},{\"id\":717},{\"id\":718},{\"id\":719},{\"id\":720},{\"id\":721},{\"id\":722},{\"id\":723},{\"id\":724},{\"id\":725},{\"id\":726},{\"id\":727},{\"id\":728},{\"id\":729},{\"id\":730},{\"id\":731},{\"id\":732},{\"id\":733},{\"id\":734},{\"id\":735},{\"id\":736},{\"id\":737},{\"id\":738},{\"id\":739},{\"id\":740},{\"id\":741},{\"id\":742},{\"id\":743},{\"id\":744},{\"id\":745},{\"id\":746},{\"id\":747},{\"id\":748},{\"id\":749},{\"id\":750},{\"id\":751},{\"id\":752},{\"id\":753},{\"id\":754},{\"id\":755},{\"id\":756},{\"id\":757},{\"id\":758},{\"id\":759},{\"id\":760},{\"id\":761},{\"id\":762},{\"id\":763},{\"id\":764},{\"id\":765},{\"id\":766},{\"id\":767},{\"id\":768},{\"id\":769},{\"id\":770},{\"id\":771},{\"id\":772},{\"id\":773},{\"id\":774},{\"id\":775},{\"id\":776},{\"id\":777},{\"id\":778},{\"id\":779},{\"id\":780},{\"id\":781},{\"id\":782},{\"id\":783},{\"id\":784},{\"id\":785},{\"id\":786},{\"id\":787},{\"id\":788},{\"id\":789},{\"id\":790},{\"id\":791},{\"id\":792},{\"id\":793},{\"id\":794},{\"id\":795},{\"id\":796},{\"id\":797},{\"id\":798},{\"id\":799},{\"id\":800},{\"id\":801},{\"id\":802},{\"id\":803},{\"id\":804},{\"id\":805},{\"id\":806},{\"id\":807},{\"id\":808},{\"id\":809},{\"id\":810},{\"id\":811},{\"id\":812},{\"id\":813},{\"id\":814},{\"id\":815},{\"id\":816},{\"id\":817},{\"id\":818},{\"id\":819},{\"id\":820},{\"id\":821},{\"id\":822},{\"id\":823},{\"id\":824},{\"id\":825},{\"id\":826},{\"id\":827},{\"id\":828},{\"id\":829},{\"id\":830},{\"id\":831},{\"id\":832},{\"id\":833},{\"id\":834},{\"id\":835},{\"id\":836},{\"id\":837},{\"id\":838},{\"id\":839},{\"id\":840},{\"id\":841},{\"id\":842},{\"id\":843},{\"id\":844},{\"id\":845},{\"id\":846},{\"id\":847},{\"id\":848},{\"id\":849},{\"id\":850},{\"id\":851},{\"id\":852},{\"id\":853},{\"id\":854},{\"id\":855},{\"id\":856},{\"id\":857},{\"id\":858},{\"id\":859},{\"id\":860},{\"id\":861},{\"id\":862},{\"id\":863},{\"id\":864},{\"id\":865},{\"id\":866},{\"id\":867},{\"id\":868},{\"id\":869},{\"id\":870},{\"id\":871},{\"id\":872},{\"id\":873},{\"id\":874},{\"id\":875},{\"id\":876},{\"id\":877},{\"id\":878},{\"id\":879},{\"id\":880},{\"id\":881},{\"id\":882},{\"id\":883},{\"id\":884},{\"id\":885},{\"id\":886},{\"id\":887},{\"id\":888},{\"id\":889},{\"id\":890},{\"id\":891},{\"id\":892},{\"id\":893},{\"id\":894},{\"id\":895},{\"id\":896},{\"id\":897},{\"id\":898},{\"id\":899},{\"id\":900},{\"id\":901},{\"id\":902},{\"id\":903},{\"id\":904},{\"id\":905},{\"id\":906},{\"id\":907},{\"id\":908},{\"id\":909},{\"id\":910},{\"id\":911},{\"id\":912},{\"id\":913},{\"id\":914},{\"id\":915},{\"id\":916},{\"id\":917},{\"id\":918},{\"id\":919},{\"id\":920},{\"id\":921},{\"id\":922},{\"id\":923},{\"id\":924},{\"id\":925},{\"id\":926},{\"id\":927},{\"id\":928},{\"id\":929},{\"id\":930},{\"id\":931},{\"id\":932},{\"id\":933},{\"id\":934},{\"id\":935},{\"id\":936},{\"id\":937},{\"id\":938},{\"id\":939},{\"id\":940},{\"id\":941},{\"id\":942},{\"id\":943},{\"id\":944},{\"id\":945},{\"id\":946},{\"id\":947},{\"id\":948},{\"id\":949},{\"id\":950},{\"id\":951},{\"id\":952},{\"id\":953},{\"id\":954},{\"id\":955},{\"id\":956},{\"id\":957},{\"id\":958},{\"id\":959},{\"id\":960},{\"id\":961},{\"id\":962},{\"id\":963},{\"id\":964},{\"id\":965},{\"id\":966},{\"id\":967},{\"id\":968},{\"id\":969},{\"id\":970},{\"id\":971},{\"id\":972},{\"id\":973},{\"id\":974},{\"id\":975},{\"id\":976},{\"id\":977},{\"id\":978},{\"id\":979},{\"id\":980},{\"id\":981},{\"id\":982},{\"id\":983},{\"id\":984},{\"id\":985},{\"id\":986},{\"id\":987},{\"id\":988},{\"id\":989},{\"id\":990},{\"id\":991},{\"id\":992},{\"id\":993},{\"id\":994},{\"id\":995},{\"id\":996},{\"id\":997},{\"id\":998},{\"id\":999},{\"id\":1000},{\"id\":1001},{\"id\":1002},{\"id\":1003},{\"id\":1004},{\"id\":1005},{\"id\":1006},{\"id\":1007},{\"id\":1008},{\"id\":1009},{\"id\":1010},{\"id\":1011},{\"id\":1012},{\"id\":1013},{\"id\":1014},{\"id\":1015},{\"id\":1016},{\"id\":1017},{\"id\":1018},{\"id\":1019},{\"id\":1020},{\"id\":1021},{\"id\":1022},{\"id\":1023},{\"id\":1024},{\"id\":1025},{\"id\":1026},{\"id\":1027},{\"id\":1028},{\"id\":1029},{\"id\":1030},{\"id\":1031},{\"id\":1032},{\"id\":1033},{\"id\":1034},{\"id\":1035},{\"id\":1036},{\"id\":1037},{\"id\":1038},{\"id\":1039},{\"id\":1040},{\"id\":1041},{\"id\":1042},{\"id\":1043},{\"id\":1044},{\"id\":1045},{\"id\":1046},{\"id\":1047},{\"id\":1048},{\"id\":1049},{\"id\":1050},{\"id\":1051},{\"id\":1052},{\"id\":1053},{\"id\":1054},{\"id\":1055},{\"id\":1056},{\"id\":1057},{\"id\":1058},{\"id\":1059},{\"id\":1060},{\"id\":1061},{\"id\":1062},{\"id\":1063},{\"id\":1064},{\"id\":1065},{\"id\":1066},{\"id\":1067},{\"id\":1068},{\"id\":1069},{\"id\":1070},{\"id\":1071},{\"id\":1072},{\"id\":1073},{\"id\":1074},{\"id\":1075},{\"id\":1076},{\"id\":1077},{\"id\":1078},{\"id\":1079},{\"id\":1080},{\"id\":1081},{\"id\":1082},{\"id\":1083},{\"id\":1084},{\"id\":1085},{\"id\":1086},{\"id\":1087},{\"id\":1088},{\"id\":1089},{\"id\":1090},{\"id\":1091},{\"id\":1092},{\"id\":1093},{\"id\":1094},{\"id\":1095},{\"id\":1096},{\"id\":1097},{\"id\":1098},{\"id\":1099},{\"id\":1100},{\"id\":1101},{\"id\":1102},{\"id\":1103},{\"id\":1104},{\"id\":1105},{\"id\":1106},{\"id\":1107},{\"id\":1108},{\"id\":1109},{\"id\":1110},{\"id\":1111},{\"id\":1112},{\"id\":1113},{\"id\":1114},{\"id\":1115},{\"id\":1116},{\"id\":1117},{\"id\":1118},{\"id\":1119},{\"id\":1120},{\"id\":1121},{\"id\":1122},{\"id\":1123},{\"id\":1124},{\"id\":1125},{\"id\":1126},{\"id\":1127},{\"id\":1128},{\"id\":1129},{\"id\":1130},{\"id\":1131},{\"id\":1132},{\"id\":1133},{\"id\":1134},{\"id\":1135},{\"id\":1136},{\"id\":1137},{\"id\":1138},{\"id\":1139},{\"id\":1140},{\"id\":1141},{\"id\":1142},{\"id\":1143},{\"id\":1144},{\"id\":1145},{\"id\":1146},{\"id\":1147},{\"id\":1148},{\"id\":1149},{\"id\":1150},{\"id\":1151},{\"id\":1152},{\"id\":1153},{\"id\":1154},{\"id\":1155},{\"id\":1156},{\"id\":1157},{\"id\":1158},{\"id\":1159},{\"id\":1160},{\"id\":1161},{\"id\":1162},{\"id\":1163},{\"id\":1164},{\"id\":1165},{\"id\":1166},{\"id\":1167},{\"id\":1168},{\"id\":1169},{\"id\":1170},{\"id\":1171},{\"id\":1172},{\"id\":1173},{\"id\":1174},{\"id\":1175},{\"id\":1176},{\"id\":1177},{\"id\":1178},{\"id\":1179},{\"id\":1180},{\"id\":1181},{\"id\":1182},{\"id\":1183},{\"id\":1184},{\"id\":1185},{\"id\":1186},{\"id\":1187},{\"id\":1188},{\"id\":1189},{\"id\":1190},{\"id\":1191},{\"id\":1192},{\"id\":1193},{\"id\":1194},{\"id\":1195},{\"id\":1196},{\"id\":1197},{\"id\":1198},{\"id\":1199},{\"id\":1200},{\"id\":1201},{\"id\":1202},{\"id\":1203},{\"id\":1204},{\"id\":1205},{\"id\":1206},{\"id\":1207},{\"id\":1208},{\"id\":1209},{\"id\":1210},{\"id\":1211},{\"id\":1212},{\"id\":1213},{\"id\":1214},{\"id\":1215},{\"id\":1216},{\"id\":1217},{\"id\":1218},{\"id\":1219},{\"id\":1220},{\"id\":1221},{\"id\":1222},{\"id\":1223},{\"id\":1224},{\"id\":1225},{\"id\":1226},{\"id\":1227},{\"id\":1228},{\"id\":1229},{\"id\":1230},{\"id\":1231},{\"id\":1232},{\"id\":1233},{\"id\":1234},{\"id\":1235},{\"id\":1236},{\"id\":1237},{\"id\":1238},{\"id\":1239},{\"id\":1240},{\"id\":1241},{\"id\":1242},{\"id\":1243},{\"id\":1244},{\"id\":1245},{\"id\":1246},{\"id\":1247},{\"id\":1248},{\"id\":1249},{\"id\":1250},{\"id\":1251},{\"id\":1252},{\"id\":1253},{\"id\":1254},{\"id\":1255},{\"id\":1256},{\"id\":1257},{\"id\":1258},{\"id\":1259},{\"id\":1260},{\"id\":1261},{\"id\":1262},{\"id\":1263},{\"id\":1264},{\"id\":1265},{\"id\":1266},{\"id\":1267},{\"id\":1268},{\"id\":1269},{\"id\":1270},{\"id\":1271},{\"id\":1272},{\"id\":1273},{\"id\":1274},{\"id\":1275},{\"id\":1276},{\"id\":1277},{\"id\":1278},{\"id\":1279},{\"id\":1280},{\"id\":1281},{\"id\":1282},{\"id\":1283},{\"id\":1284},{\"id\":1285},{\"id\":1286},{\"id\":1287},{\"id\":1288},{\"id\":1289},{\"id\":1290},{\"id\":1291},{\"id\":1292},{\"id\":1293},{\"id\":1294},{\"id\":1295},{\"id\":1296},{\"id\":1297},{\"id\":1298},{\"id\":1299},{\"id\":1300},{\"id\":1301},{\"id\":1302},{\"id\":1303},{\"id\":1304},{\"id\":1305},{\"id\":1306},{\"id\":1307},{\"id\":1308},{\"id\":1309},{\"id\":1310},{\"id\":1311},{\"id\":1312},{\"id\":1313},{\"id\":1314},{\"id\":1315},{\"id\":1316},{\"id\":1317},{\"id\":1318},{\"id\":1319},{\"id\":1320},{\"id\":1321},{\"id\":1322},{\"id\":1323},{\"id\":1324},{\"id\":1325},{\"id\":1326},{\"id\":1327},{\"id\":1328},{\"id\":1329},{\"id\":1330},{\"id\":1331},{\"id\":1332},{\"id\":1333},{\"id\":1334},{\"id\":1335},{\"id\":1336},{\"id\":1337},{\"id\":1338},{\"id\":1339},{\"id\":1340},{\"id\":1341},{\"id\":1342},{\"id\":1343},{\"id\":1344},{\"id\":1345},{\"id\":1346},{\"id\":1347},{\"id\":1348},{\"id\":1349},{\"id\":1350},{\"id\":1351},{\"id\":1352},{\"id\":1353},{\"id\":1354},{\"id\":1355},{\"id\":1356},{\"id\":1357},{\"id\":1358},{\"id\":1359},{\"id\":1360},{\"id\":1361},{\"id\":1362},{\"id\":1363},{\"id\":1364},{\"id\":1365},{\"id\":1366},{\"id\":1367},{\"id\":1368},{\"id\":1369},{\"id\":1370},{\"id\":1371},{\"id\":1372},{\"id\":1373},{\"id\":1374},{\"id\":1375},{\"id\":1376},{\"id\":1377},{\"id\":1378},{\"id\":1379},{\"id\":1380},{\"id\":1381},{\"id\":1382},{\"id\":1383},{\"id\":1384},{\"id\":1385},{\"id\":1386},{\"id\":1387},{\"id\":1388},{\"id\":1389},{\"id\":1390},{\"id\":1391},{\"id\":1392},{\"id\":1393},{\"id\":1394},{\"id\":1395},{\"id\":1396},{\"id\":1397},{\"id\":1398},{\"id\":1399},{\"id\":1400},{\"id\":1401},{\"id\":1402},{\"id\":1403},{\"id\":1404},{\"id\":1405},{\"id\":1406},{\"id\":1407},{\"id\":1408},{\"id\":1409},{\"id\":1410},{\"id\":1411},{\"id\":1412},{\"id\":1413},{\"id\":1414},{\"id\":1415},{\"id\":1416},{\"id\":1417},{\"id\":1418},{\"id\":1419},{\"id\":1420},{\"id\":1421},{\"id\":1422},{\"id\":1423},{\"id\":1424},{\"id\":1425},{\"id\":1426},{\"id\":1427},{\"id\":1428},{\"id\":1429},{\"id\":1430},{\"id\":1431},{\"id\":1432},{\"id\":1433},{\"id\":1434},{\"id\":1435},{\"id\":1436},{\"id\":1437},{\"id\":1438},{\"id\":1439},{\"id\":1440},{\"id\":1441},{\"id\":1442},{\"id\":1443},{\"id\":1444},{\"id\":1445},{\"id\":1446},{\"id\":1447},{\"id\":1448},{\"id\":1449},{\"id\":1450},{\"id\":1451},{\"id\":1452},{\"id\":1453},{\"id\":1454},{\"id\":1455},{\"id\":1456},{\"id\":1457},{\"id\":1458},{\"id\":1459},{\"id\":1460},{\"id\":1461},{\"id\":1462},{\"id\":1463},{\"id\":1464},{\"id\":1465},{\"id\":1466},{\"id\":1467},{\"id\":1468},{\"id\":1469},{\"id\":1470},{\"id\":1471},{\"id\":1472},{\"id\":1473},{\"id\":1474},{\"id\":1475},{\"id\":1476},{\"id\":1477},{\"id\":1478},{\"id\":1479},{\"id\":1480},{\"id\":1481},{\"id\":1482},{\"id\":1483},{\"id\":1484},{\"id\":1485},{\"id\":1486},{\"id\":1487},{\"id\":1488},{\"id\":1489},{\"id\":1490},{\"id\":1491},{\"id\":1492},{\"id\":1493},{\"id\":1494},{\"id\":1495},{\"id\":1496},{\"id\":1497},{\"id\":1498},{\"id\":1499},{\"id\":1500},{\"id\":1501},{\"id\":1502},{\"id\":1503},{\"id\":1504},{\"id\":1505},{\"id\":1506},{\"id\":1507},{\"id\":1508},{\"id\":1509},{\"id\":1510},{\"id\":1511},{\"id\":1512},{\"id\":1513},{\"id\":1514},{\"id\":1515},{\"id\":1516},{\"id\":1517},{\"id\":1518},{\"id\":1519},{\"id\":1520},{\"id\":1521},{\"id\":1522},{\"id\":1523},{\"id\":1524},{\"id\":1525},{\"id\":1526},{\"id\":1527},{\"id\":1528},{\"id\":1529},{\"id\":1530},{\"id\":1531},{\"id\":1532},{\"id\":1533},{\"id\":1534},{\"id\":1535},{\"id\":1536},{\"id\":1537},{\"id\":1538},{\"id\":1539},{\"id\":1540},{\"id\":1541},{\"id\":1542},{\"id\":1543},{\"id\":1544},{\"id\":1545},{\"id\":1546},{\"id\":1547},{\"id\":1548},{\"id\":1549},{\"id\":1550},{\"id\":1551},{\"id\":1552},{\"id\":1553},{\"id\":1554},{\"id\":1555},{\"id\":1556},{\"id\":1557},{\"id\":1558},{\"id\":1559},{\"id\":1560},{\"id\":1561},{\"id\":1562},{\"id\":1563},{\"id\":1564},{\"id\":1565},{\"id\":1566},{\"id\":1567},{\"id\":1568},{\"id\":1569},{\"id\":1570},{\"id\":1571},{\"id\":1572},{\"id\":1573},{\"id\":1574},{\"id\":1575},{\"id\":1576},{\"id\":1577},{\"id\":1578},{\"id\":1579},{\"id\":1580},{\"id\":1581},{\"id\":1582},{\"id\":1583},{\"id\":1584},{\"id\":1585},{\"id\":1586},{\"id\":1587},{\"id\":1588},{\"id\":1589},{\"id\":1590},{\"id\":1591},{\"id\":1592},{\"id\":1593},{\"id\":1594},{\"id\":1595},{\"id\":1596},{\"id\":1597},{\"id\":1598},{\"id\":1599},{\"id\":1600},{\"id\":1601},{\"id\":1602},{\"id\":1603},{\"id\":1604},{\"id\":1605},{\"id\":1606},{\"id\":1607},{\"id\":1608},{\"id\":1609},{\"id\":1610},{\"id\":1611},{\"id\":1612},{\"id\":1613},{\"id\":1614},{\"id\":1615},{\"id\":1616},{\"id\":1617},{\"id\":1618},{\"id\":1619},{\"id\":1620},{\"id\":1621},{\"id\":1622},{\"id\":1623},{\"id\":1624},{\"id\":1625},{\"id\":1626},{\"id\":1627},{\"id\":1628},{\"id\":1629},{\"id\":1630},{\"id\":1631},{\"id\":1632},{\"id\":1633},{\"id\":1634},{\"id\":1635},{\"id\":1636},{\"id\":1637},{\"id\":1638},{\"id\":1639},{\"id\":1640},{\"id\":1641},{\"id\":1642},{\"id\":1643},{\"id\":1644},{\"id\":1645},{\"id\":1646},{\"id\":1647},{\"id\":1648},{\"id\":1649},{\"id\":1650},{\"id\":1651},{\"id\":1652},{\"id\":1653},{\"id\":1654},{\"id\":1655},{\"id\":1656},{\"id\":1657},{\"id\":1658},{\"id\":1659},{\"id\":1660},{\"id\":1661},{\"id\":1662},{\"id\":1663},{\"id\":1664},{\"id\":1665},{\"id\":1666},{\"id\":1667},{\"id\":1668},{\"id\":1669},{\"id\":1670},{\"id\":1671},{\"id\":1672},{\"id\":1673},{\"id\":1674},{\"id\":1675},{\"id\":1676},{\"id\":1677},{\"id\":1678},{\"id\":1679},{\"id\":1680},{\"id\":1681},{\"id\":1682},{\"id\":1683},{\"id\":1684},{\"id\":1685},{\"id\":1686},{\"id\":1687},{\"id\":1688},{\"id\":1689},{\"id\":1690},{\"id\":1691},{\"id\":1692},{\"id\":1693},{\"id\":1694},{\"id\":1695},{\"id\":1696},{\"id\":1697},{\"id\":1698},{\"id\":1699},{\"id\":1700},{\"id\":1701},{\"id\":1702},{\"id\":1703},{\"id\":1704},{\"id\":1705},{\"id\":1706},{\"id\":1707},{\"id\":1708},{\"id\":1709},{\"id\":1710},{\"id\":1711},{\"id\":1712},{\"id\":1713},{\"id\":1714},{\"id\":1715},{\"id\":1716},{\"id\":1717},{\"id\":1718},{\"id\":1719},{\"id\":1720},{\"id\":1721},{\"id\":1722},{\"id\":1723},{\"id\":1724},{\"id\":1725},{\"id\":1726},{\"id\":1727},{\"id\":1728},{\"id\":1729},{\"id\":1730},{\"id\":1731},{\"id\":1732},{\"id\":1733},{\"id\":1734},{\"id\":1735},{\"id\":1736},{\"id\":1737},{\"id\":1738},{\"id\":1739},{\"id\":1740},{\"id\":1741},{\"id\":1742},{\"id\":1743},{\"id\":1744},{\"id\":1745},{\"id\":1746},{\"id\":1747},{\"id\":1748},{\"id\":1749},{\"id\":1750},{\"id\":1751},{\"id\":1752},{\"id\":1753},{\"id\":1754},{\"id\":1755},{\"id\":1756},{\"id\":1757},{\"id\":1758},{\"id\":1759},{\"id\":1760},{\"id\":1761},{\"id\":1762},{\"id\":1763},{\"id\":1764},{\"id\":1765},{\"id\":1766},{\"id\":1767},{\"id\":1768},{\"id\":1769},{\"id\":1770},{\"id\":1771},{\"id\":1772},{\"id\":1773},{\"id\":1774},{\"id\":1775},{\"id\":1776},{\"id\":1777},{\"id\":1778},{\"id\":1779},{\"id\":1780},{\"id\":1781},{\"id\":1782},{\"id\":1783},{\"id\":1784},{\"id\":1785},{\"id\":1786},{\"id\":1787},{\"id\":1788},{\"id\":1789},{\"id\":1790},{\"id\":1791},{\"id\":1792},{\"id\":1793},{\"id\":1794},{\"id\":1795},{\"id\":1796},{\"id\":1797},{\"id\":1798},{\"id\":1799},{\"id\":1800},{\"id\":1801},{\"id\":1802},{\"id\":1803},{\"id\":1804},{\"id\":1805},{\"id\":1806},{\"id\":1807},{\"id\":1808},{\"id\":1809},{\"id\":1810},{\"id\":1811},{\"id\":1812},{\"id\":1813},{\"id\":1814},{\"id\":1815},{\"id\":1816},{\"id\":1817},{\"id\":1818},{\"id\":1819},{\"id\":1820},{\"id\":1821},{\"id\":1822},{\"id\":1823},{\"id\":1824},{\"id\":1825},{\"id\":1826},{\"id\":1827},{\"id\":1828},{\"id\":1829},{\"id\":1830},{\"id\":1831},{\"id\":1832},{\"id\":1833},{\"id\":1834},{\"id\":1835},{\"id\":1836},{\"id\":1837},{\"id\":1838},{\"id\":1839},{\"id\":1840},{\"id\":1841},{\"id\":1842},{\"id\":1843},{\"id\":1844},{\"id\":1845},{\"id\":1846},{\"id\":1847},{\"id\":1848},{\"id\":1849},{\"id\":1850},{\"id\":1851},{\"id\":1852},{\"id\":1853},{\"id\":1854},{\"id\":1855},{\"id\":1856},{\"id\":1857},{\"id\":1858},{\"id\":1859},{\"id\":1860},{\"id\":1861},{\"id\":1862},{\"id\":1863},{\"id\":1864},{\"id\":1865},{\"id\":1866},{\"id\":1867},{\"id\":1868},{\"id\":1869},{\"id\":1870},{\"id\":1871},{\"id\":1872},{\"id\":1873},{\"id\":1874},{\"id\":1875},{\"id\":1876},{\"id\":1877},{\"id\":1878},{\"id\":1879},{\"id\":1880},{\"id\":1881},{\"id\":1882},{\"id\":1883},{\"id\":1884},{\"id\":1885},{\"id\":1886},{\"id\":1887},{\"id\":1888},{\"id\":1889},{\"id\":1890},{\"id\":1891},{\"id\":1892},{\"id\":1893},{\"id\":1894},{\"id\":1895},{\"id\":1896},{\"id\":1897},{\"id\":1898},{\"id\":1899},{\"id\":1900},{\"id\":1901},{\"id\":1902},{\"id\":1903},{\"id\":1904},{\"id\":1905},{\"id\":1906},{\"id\":1907},{\"id\":1908},{\"id\":1909},{\"id\":1910},{\"id\":1911},{\"id\":1912},{\"id\":1913},{\"id\":1914},{\"id\":1915},{\"id\":1916},{\"id\":1917},{\"id\":1918},{\"id\":1919},{\"id\":1920},{\"id\":1921},{\"id\":1922},{\"id\":1923},{\"id\":1924},{\"id\":1925},{\"id\":1926},{\"id\":1927},{\"id\":1928},{\"id\":1929},{\"id\":1930},{\"id\":1931},{\"id\":1932},{\"id\":1933},{\"id\":1934},{\"id\":1935},{\"id\":1936},{\"id\":1937},{\"id\":1938},{\"id\":1939},{\"id\":1940},{\"id\":1941},{\"id\":1942},{\"id\":1943},{\"id\":1944},{\"id\":1945},{\"id\":1946},{\"id\":1947},{\"id\":1948},{\"id\":1949},{\"id\":1950},{\"id\":1951},{\"id\":1952},{\"id\":1953},{\"id\":1954},{\"id\":1955},{\"id\":1956},{\"id\":1957},{\"id\":1958},{\"id\":1959},{\"id\":1960},{\"id\":1961},{\"id\":1962},{\"id\":1963},{\"id\":1964},{\"id\":1965},{\"id\":1966},{\"id\":1967},{\"id\":1968},{\"id\":1969},{\"id\":1970},{\"id\":1971},{\"id\":1972},{\"id\":1973},{\"id\":1974},{\"id\":1975},{\"id\":1976},{\"id\":1977},{\"id\":1978},{\"id\":1979},{\"id\":1980},{\"id\":1981},{\"id\":1982},{\"id\":1983},{\"id\":1984},{\"id\":1985},{\"id\":1986},{\"id\":1987},{\"id\":1988},{\"id\":1989},{\"id\":1990},{\"id\":1991},{\"id\":1992},{\"id\":1993},{\"id\":1994},{\"id\":1995},{\"id\":1996},{\"id\":1997},{\"id\":1998},{\"id\":1999},{\"id\":2000},{\"id\":2001},{\"id\":2002},{\"id\":2003},{\"id\":2004},{\"id\":2005},{\"id\":2006},{\"id\":2007},{\"id\":2008},{\"id\":2009},{\"id\":2010},{\"id\":2011},{\"id\":2012},{\"id\":2013},{\"id\":2014},{\"id\":2015},{\"id\":2016},{\"id\":2017},{\"id\":2018},{\"id\":2019},{\"id\":2020},{\"id\":2021},{\"id\":2022},{\"id\":2023},{\"id\":2024},{\"id\":2025},{\"id\":2026},{\"id\":2027},{\"id\":2028},{\"id\":2029},{\"id\":2030},{\"id\":2031},{\"id\":2032},{\"id\":2033},{\"id\":2034},{\"id\":2035},{\"id\":2036},{\"id\":2037},{\"id\":2038},{\"id\":2039},{\"id\":2040},{\"id\":2041},{\"id\":2042},{\"id\":2043},{\"id\":2044},{\"id\":2045},{\"id\":2046},{\"id\":2047},{\"id\":2048},{\"id\":2049},{\"id\":2050},{\"id\":2051},{\"id\":2052},{\"id\":2053},{\"id\":2054},{\"id\":2055},{\"id\":2056},{\"id\":2057},{\"id\":2058},{\"id\":2059},{\"id\":2060},{\"id\":2061},{\"id\":2062},{\"id\":2063},{\"id\":2064},{\"id\":2065},{\"id\":2066},{\"id\":2067},{\"id\":2068},{\"id\":2069},{\"id\":2070},{\"id\":2071},{\"id\":2072},{\"id\":2073},{\"id\":2074},{\"id\":2075},{\"id\":2076},{\"id\":2077},{\"id\":2078},{\"id\":2079},{\"id\":2080},{\"id\":2081},{\"id\":2082},{\"id\":2083},{\"id\":2084},{\"id\":2085},{\"id\":2086},{\"id\":2087},{\"id\":2088},{\"id\":2089},{\"id\":2090},{\"id\":2091},{\"id\":2092},{\"id\":2093},{\"id\":2094},{\"id\":2095},{\"id\":2096},{\"id\":2097},{\"id\":2098},{\"id\":2099},{\"id\":2100},{\"id\":2101},{\"id\":2102},{\"id\":2103},{\"id\":2104},{\"id\":2105},{\"id\":2106},{\"id\":2107},{\"id\":2108},{\"id\":2109},{\"id\":2110},{\"id\":2111},{\"id\":2112},{\"id\":2113},{\"id\":2114},{\"id\":2115},{\"id\":2116},{\"id\":2117},{\"id\":2118},{\"id\":2119},{\"id\":2120},{\"id\":2121},{\"id\":2122},{\"id\":2123},{\"id\":2124},{\"id\":2125},{\"id\":2126},{\"id\":2127},{\"id\":2128},{\"id\":2129},{\"id\":2130},{\"id\":2131},{\"id\":2132},{\"id\":2133},{\"id\":2134},{\"id\":2135},{\"id\":2136},{\"id\":2137},{\"id\":2138},{\"id\":2139},{\"id\":2140},{\"id\":2141},{\"id\":2142},{\"id\":2143},{\"id\":2144},{\"id\":2145},{\"id\":2146},{\"id\":2147},{\"id\":2148},{\"id\":2149},{\"id\":2150},{\"id\":2151},{\"id\":2152},{\"id\":2153},{\"id\":2154},{\"id\":2155},{\"id\":2156},{\"id\":2157},{\"id\":2158},{\"id\":2159},{\"id\":2160},{\"id\":2161},{\"id\":2162},{\"id\":2163},{\"id\":2164},{\"id\":2165},{\"id\":2166},{\"id\":2167},{\"id\":2168},{\"id\":2169},{\"id\":2170},{\"id\":2171},{\"id\":2172},{\"id\":2173},{\"id\":2174},{\"id\":2175},{\"id\":2176},{\"id\":2177},{\"id\":2178},{\"id\":2179},{\"id\":2180},{\"id\":2181},{\"id\":2182},{\"id\":2183},{\"id\":2184},{\"id\":2185},{\"id\":2186},{\"id\":2187},{\"id\":2188},{\"id\":2189},{\"id\":2190},{\"id\":2191},{\"id\":2192},{\"id\":2193},{\"id\":2194},{\"id\":2195},{\"id\":2196},{\"id\":2197},{\"id\":2198},{\"id\":2199},{\"id\":2200},{\"id\":2201},{\"id\":2202},{\"id\":2203},{\"id\":2204},{\"id\":2205},{\"id\":2206},{\"id\":2207},{\"id\":2208},{\"id\":2209},{\"id\":2210},{\"id\":2211},{\"id\":2212},{\"id\":2213},{\"id\":2214},{\"id\":2215},{\"id\":2216},{\"id\":2217},{\"id\":2218},{\"id\":2219},{\"id\":2220},{\"id\":2221},{\"id\":2222},{\"id\":2223},{\"id\":2224},{\"id\":2225},{\"id\":2226},{\"id\":2227},{\"id\":2228},{\"id\":2229},{\"id\":2230},{\"id\":2231},{\"id\":2232},{\"id\":2233},{\"id\":2234},{\"id\":2235},{\"id\":2236},{\"id\":2237},{\"id\":2238},{\"id\":2239},{\"id\":2240},{\"id\":2241},{\"id\":2242},{\"id\":2243},{\"id\":2244},{\"id\":2245},{\"id\":2246},{\"id\":2247},{\"id\":2248},{\"id\":2249},{\"id\":2250},{\"id\":2251},{\"id\":2252},{\"id\":2253},{\"id\":2254},{\"id\":2255},{\"id\":2256},{\"id\":2257},{\"id\":2258},{\"id\":2259},{\"id\":2260},{\"id\":2261},{\"id\":2262},{\"id\":2263},{\"id\":2264},{\"id\":2265},{\"id\":2266},{\"id\":2267},{\"id\":2268},{\"id\":2269},{\"id\":2270},{\"id\":2271},{\"id\":2272},{\"id\":2273},{\"id\":2274},{\"id\":2275},{\"id\":2276},{\"id\":2277},{\"id\":2278},{\"id\":2279},{\"id\":2280},{\"id\":2281},{\"id\":2282},{\"id\":2283},{\"id\":2284},{\"id\":2285},{\"id\":2286},{\"id\":2287},{\"id\":2288},{\"id\":2289},{\"id\":2290},{\"id\":2291},{\"id\":2292},{\"id\":2293},{\"id\":2294},{\"id\":2295},{\"id\":2296},{\"id\":2297},{\"id\":2298},{\"id\":2299},{\"id\":2300},{\"id\":2301},{\"id\":2302},{\"id\":2303},{\"id\":2304},{\"id\":2305},{\"id\":2306},{\"id\":2307},{\"id\":2308},{\"id\":2309},{\"id\":2310},{\"id\":2311},{\"id\":2312},{\"id\":2313},{\"id\":2314},{\"id\":2315},{\"id\":2316},{\"id\":2317},{\"id\":2318},{\"id\":2319},{\"id\":2320},{\"id\":2321},{\"id\":2322},{\"id\":2323},{\"id\":2324},{\"id\":2325},{\"id\":2326},{\"id\":2327},{\"id\":2328},{\"id\":2329},{\"id\":2330},{\"id\":2331},{\"id\":2332},{\"id\":2333},{\"id\":2334},{\"id\":2335},{\"id\":2336},{\"id\":2337},{\"id\":2338},{\"id\":2339},{\"id\":2340},{\"id\":2341},{\"id\":2342},{\"id\":2343},{\"id\":2344},{\"id\":2345},{\"id\":2346},{\"id\":2347},{\"id\":2348},{\"id\":2349},{\"id\":2350},{\"id\":2351},{\"id\":2352},{\"id\":2353},{\"id\":2354},{\"id\":2355},{\"id\":2356},{\"id\":2357},{\"id\":2358},{\"id\":2359},{\"id\":2360},{\"id\":2361},{\"id\":2362},{\"id\":2363},{\"id\":2364},{\"id\":2365},{\"id\":2366},{\"id\":2367},{\"id\":2368},{\"id\":2369},{\"id\":2370},{\"id\":2371},{\"id\":2372},{\"id\":2373},{\"id\":2374},{\"id\":2375},{\"id\":2376},{\"id\":2377},{\"id\":2378},{\"id\":2379},{\"id\":2380},{\"id\":2381},{\"id\":2382},{\"id\":2383},{\"id\":2384},{\"id\":2385},{\"id\":2386},{\"id\":2387},{\"id\":2388},{\"id\":2389},{\"id\":2390},{\"id\":2391},{\"id\":2392},{\"id\":2393},{\"id\":2394},{\"id\":2395},{\"id\":2396},{\"id\":2397},{\"id\":2398},{\"id\":2399},{\"id\":2400},{\"id\":2401},{\"id\":2402},{\"id\":2403},{\"id\":2404},{\"id\":2405},{\"id\":2406},{\"id\":2407},{\"id\":2408},{\"id\":2409},{\"id\":2410},{\"id\":2411},{\"id\":2412},{\"id\":2413},{\"id\":2414},{\"id\":2415},{\"id\":2416},{\"id\":2417},{\"id\":2418},{\"id\":2419},{\"id\":2420},{\"id\":2421},{\"id\":2422},{\"id\":2423},{\"id\":2424},{\"id\":2425},{\"id\":2426},{\"id\":2427},{\"id\":2428},{\"id\":2429},{\"id\":2430},{\"id\":2431},{\"id\":2432},{\"id\":2433},{\"id\":2434},{\"id\":2435},{\"id\":2436},{\"id\":2437},{\"id\":2438},{\"id\":2439},{\"id\":2440},{\"id\":2441},{\"id\":2442},{\"id\":2443},{\"id\":2444},{\"id\":2445},{\"id\":2446},{\"id\":2447},{\"id\":2448},{\"id\":2449},{\"id\":2450},{\"id\":2451},{\"id\":2452},{\"id\":2453},{\"id\":2454},{\"id\":2455},{\"id\":2456},{\"id\":2457},{\"id\":2458},{\"id\":2459},{\"id\":2460},{\"id\":2461},{\"id\":2462},{\"id\":2463},{\"id\":2464},{\"id\":2465},{\"id\":2466},{\"id\":2467},{\"id\":2468},{\"id\":2469},{\"id\":2470},{\"id\":2471},{\"id\":2472},{\"id\":2473},{\"id\":2474},{\"id\":2475},{\"id\":2476},{\"id\":2477},{\"id\":2478},{\"id\":2479},{\"id\":2480},{\"id\":2481},{\"id\":2482},{\"id\":2483},{\"id\":2484},{\"id\":2485},{\"id\":2486},{\"id\":2487},{\"id\":2488},{\"id\":2489},{\"id\":2490},{\"id\":2491},{\"id\":2492},{\"id\":2493},{\"id\":2494},{\"id\":2495},{\"id\":2496},{\"id\":2497},{\"id\":2498},{\"id\":2499},{\"id\":2500},{\"id\":2501},{\"id\":2502},{\"id\":2503},{\"id\":2504},{\"id\":2505},{\"id\":2506},{\"id\":2507},{\"id\":2508},{\"id\":2509},{\"id\":2510},{\"id\":2511},{\"id\":2512},{\"id\":2513},{\"id\":2514},{\"id\":2515},{\"id\":2516},{\"id\":2517},{\"id\":2518},{\"id\":2519},{\"id\":2520},{\"id\":2521},{\"id\":2522},{\"id\":2523},{\"id\":2524},{\"id\":2525},{\"id\":2526},{\"id\":2527},{\"id\":2528},{\"id\":2529},{\"id\":2530},{\"id\":2531},{\"id\":2532},{\"id\":2533},{\"id\":2534},{\"id\":2535},{\"id\":2536},{\"id\":2537},{\"id\":2538},{\"id\":2539},{\"id\":2540},{\"id\":2541},{\"id\":2542},{\"id\":2543},{\"id\":2544},{\"id\":2545},{\"id\":2546},{\"id\":2547},{\"id\":2548},{\"id\":2549},{\"id\":2550},{\"id\":2551},{\"id\":2552},{\"id\":2553},{\"id\":2554},{\"id\":2555},{\"id\":2556},{\"id\":2557},{\"id\":2558},{\"id\":2559},{\"id\":2560},{\"id\":2561},{\"id\":2562},{\"id\":2563},{\"id\":2564},{\"id\":2565},{\"id\":2566},{\"id\":2567},{\"id\":2568},{\"id\":2569},{\"id\":2570},{\"id\":2571},{\"id\":2572},{\"id\":2573},{\"id\":2574},{\"id\":2575},{\"id\":2576},{\"id\":2577},{\"id\":2578},{\"id\":2579},{\"id\":2580},{\"id\":2581},{\"id\":2582},{\"id\":2583},{\"id\":2584},{\"id\":2585},{\"id\":2586},{\"id\":2587},{\"id\":2588},{\"id\":2589},{\"id\":2590},{\"id\":2591},{\"id\":2592},{\"nodeType\":3,\"id\":2596,\"textContent\":\" // Track clicks on page $(document).ready(function() { $(\\\".control\\\").click(function(e) { e.stopImmediatePropagation(); clicks = clicks + 1; console.log(clicks); }); }); $('.userid').html(sid); // console.log(\\\"start of clicked array: \\\"+clicked); // console.log(\\\"start of hovered string: \\\"+hovered); //set correct answers for each question var triangular_answers = { \\\"acme.starttime.1\\\" : [\\\"F\\\"], \\\"acme.starts.1\\\" : [\\\"K\\\"], \\\"acme.meets.1\\\" : [\\\"F\\\"], \\\"acme.endtime.1\\\" : [\\\"H\\\"], \\\"acme.midpoint.1\\\" : [\\\"O\\\"], \\\"acme.starttime.2\\\" : [\\\"F\\\"], \\\"acme.starts.2\\\" : [\\\"K\\\"], \\\"acme.meets.2\\\" : [\\\"F\\\"], \\\"acme.endtime.2\\\" : [\\\"H\\\"], \\\"acme.midpoint.2\\\" : [\\\"A\\\"], \\\"bigset.duration.1\\\" : [\\\"E\\\",\\\"G\\\"], \\\"bigset.duration+starts.1\\\" : [\\\"X\\\",\\\"O\\\"], \\\"bigset.duration+contained.1\\\" : [\\\"G\\\"], \\\"bigset.starttime+before+endtime+during.1\\\": [\\\"I\\\"], \\\"bigset.ends.1\\\" : [\\\"E\\\"], \\\"bigset.duration.2\\\" : [\\\"E\\\",\\\"G\\\"], \\\"bigset.duration+starts.2\\\" : [\\\"X\\\",\\\"O\\\"], \\\"bigset.duration+contained.2\\\" : [\\\"G\\\"], \\\"bigset.starttime+before+endtime+during.2\\\":[\\\"I\\\"], \\\"bigset.ends.2\\\" : [\\\"E\\\"], \\\"bigset.starttime.1\\\" : [\\\"M\\\",\\\"L\\\"], \\\"bigset.starts.1\\\" : [\\\"G\\\"], \\\"bigset.meets.1\\\" : [\\\"E\\\",\\\"F\\\"], \\\"bigset.endtime.1\\\" : [\\\"X\\\"], \\\"bigset.midpoint.1\\\" : [\\\"K\\\",\\\"X\\\"], \\\"bigset.starttime.2\\\" : [\\\"M\\\",\\\"L\\\"], \\\"bigset.starts.2\\\" : [\\\"G\\\"], \\\"bigset.meets.2\\\" : [\\\"E\\\",\\\"F\\\"], \\\"bigset.endtime.2\\\" : [\\\"X\\\"], \\\"bigset.midpoint.2\\\" : [\\\"K\\\",\\\"X\\\"] } var orthogonal_answers = { \\\"acme.starttime.1\\\" : [\\\"A\\\"], \\\"acme.starts.1\\\" : [\\\"E\\\"], \\\"acme.meets.1\\\" : [\\\"Z\\\"], \\\"acme.endtime.1\\\" : [\\\"U\\\"], \\\"acme.midpoint.1\\\" : [\\\"U\\\"], \\\"acme.starttime.2\\\" : [\\\"0\\\"], \\\"acme.starts.2\\\" : [\\\"0\\\"], \\\"acme.meets.2\\\" : [\\\"0\\\"], \\\"acme.endtime.2\\\" : [\\\"0\\\"], \\\"acme.midpoint.2\\\" : [\\\"0\\\"], \\\"bigset.duration.1\\\" : [\\\"E\\\",\\\"G\\\"], \\\"bigset.duration+starts.1\\\" : [\\\"F\\\",\\\"B\\\"], \\\"bigset.duration+contained.1\\\" : [\\\"E\\\"], \\\"bigset.starttime+before+endtime+during.1\\\": [\\\"I\\\"], \\\"bigset.ends.1\\\" : [\\\"X\\\"], \\\"bigset.duration.2\\\" : [\\\"E\\\",\\\"G\\\"], \\\"bigset.duration+starts.2\\\" : [\\\"F\\\",\\\"B\\\"], \\\"bigset.duration+contained.2\\\" : [\\\"E\\\"], \\\"bigset.starttime+before+endtime+during.2\\\":[\\\"I\\\"], \\\"bigset.ends.2\\\" : [\\\"X\\\"], \\\"bigset.starttime.1\\\" : [\\\"F\\\",\\\"B\\\"], \\\"bigset.starts.1\\\" : [\\\"B\\\"], \\\"bigset.meets.1\\\" : [\\\"F\\\",\\\"X\\\"], \\\"bigset.endtime.1\\\" : [\\\"B\\\"], \\\"bigset.midpoint.1\\\" : [\\\"E\\\",\\\"F\\\"], \\\"bigset.starttime.2\\\" : [\\\"F\\\",\\\"B\\\"], \\\"bigset.starts.2\\\" : [\\\"B\\\"], \\\"bigset.meets.2\\\" : [\\\"F\\\",\\\"X\\\"], \\\"bigset.endtime.2\\\" : [\\\"B\\\"], \\\"bigset.midpoint.2\\\" : [\\\"E\\\",\\\"F\\\"] } //display the question and answer buttons based on input values from jsPsych document.getElementById(scenario+\\\".\\\"+question).style.display = \\\"block\\\"; if (question == \\\"strategy\\\") {document.getElementById(\\\"strategyButton\\\").style.display = \\\"block\\\";} else {document.getElementById(\\\"testingButton\\\").style.display = \\\"block\\\";} //---------SET PROPERTIES OF THE GRAPH -------------// // set the dimensions and margins of the graph var margin = {top: 25, right: 30, bottom: 90, left: 100}, width = 800, height = 800; var intersects = false; //default value for intersects scaffold var xAxisTitle, yAxisTitle; var datafile =\\\"\\\"; // SET AXIS VALUES if (axis == 1){ axis = \\\"Orthogonal-XInside-YFull\\\"; } else if (axis == 2){ axis = \\\"Orthogonal-XInside-YPartial\\\"; } else if (axis ==3){ axis = \\\"Triangular-XInside-YInside\\\"; } else if (axis ==4){ axis = \\\"Orthogonal-XInside-YInside\\\"; } else if (axis ==5){ axis = \\\"Orthogonal-XFull-YFull\\\"; } // SET EXPLICIT SCAFFOLD FEATURES if (explicit ==2 && axis != \\\"diagonal\\\"){ scaffold = 2; intersects = false; } else if (explicit == 2 && axis == \\\"diagonal\\\"){ scaffold = 2; intersects = false; } //TODO: not sure if above two lines are still valid since leaders are now generated on the fly else if (explicit == 3){ $('#hint-interactive').css(\\\"display\\\",\\\"block\\\"); //display textimage scaffold intersects = true; } //SET DATA FILE FOR IMPLICIT SCAFFOLD if (impasse == 1){ datafile = \\\"../views/src/data/acme_nonimpasse.csv\\\"; } else if (impasse == 2){ datafile = \\\"../views/src/data/acme_impasse.csv\\\"; } //OVERRIDE DATA FILE FOR NON-SCAFFOLD QUESTIONS if (q > 5) { //override data file if q# is greater than 5 datafile = \\\"../views/src/data/bigset.csv\\\"; console.log(\\\"override data file\\\"); $('#orthogonal-image').css(\\\"display\\\",\\\"none\\\"); //display textimage scaffold $('#diagonal-image').css(\\\"display\\\",\\\"none\\\"); //display textimage scaffold $('#hint-interactive').css(\\\"display\\\",\\\"none\\\"); //display textimage scaffold intersects = false; } // //---------CREATE THE SVG ------------------------// var svg = d3.select(\\\".d3container\\\").append(\\\"svg\\\") .attr(\\\"width\\\", width + margin.left + margin.right) .attr(\\\"height\\\", height + margin.top + margin.bottom) .append(\\\"g\\\") .attr(\\\"transform\\\", \\\"translate(\\\" + margin.left + \\\",\\\" + margin.top + \\\")\\\"); //---------DRAW THE GRAPH ------------------------// xAxisTitle = \\\"START & END TIME (time of day)\\\"; yAxisTitle = \\\"DURATION (in hours)\\\"; drawTriangleModel(datafile,intersects,axis,scaffold,q); \"},{\"id\":2593},{\"id\":2594},{\"nodeType\":3,\"id\":2597,\"textContent\":\" //MOUSE LOGGING SCRIPT var mouseLog = [] var xwidth = $(document).width(); var xheight = $(document).width(); mouseLog.push(\\\"{x:\\\"+xwidth+\\\",y:\\\"+xheight+\\\",t:\\\"+\\\"0};\\\") document.onmousemove = function(e){ var pageCoords = \\\"{x:\\\" + e.pageX + \\\",y:\\\"+ e.pageY +\\\",t:\\\"+ Date.now()+ \\\"};\\\" ; mouseLog.push(pageCoords); // console.log(pageCoords); }; \"},{\"id\":2595}],[],[],[]]}"
    },
    {
      "sequence": 2,
      "data": "{\"f\":\"applyChanged\",\"args\":[[],[{\"nodeType\":1,\"id\":2598,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-text-preamble\",\"class\":\"jspsych-survey-text-preamble\"},\"parentNode\":{\"id\":55}},{\"nodeType\":1,\"id\":2599,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-text-0\",\"class\":\"jspsych-survey-text-question\"},\"previousSibling\":{\"id\":2598},\"parentNode\":{\"id\":55}},{\"nodeType\":1,\"id\":2600,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-text-1\",\"class\":\"jspsych-survey-text-question\"},\"previousSibling\":{\"id\":2599},\"parentNode\":{\"id\":55}},{\"nodeType\":1,\"id\":2601,\"tagName\":\"BUTTON\",\"attributes\":{\"id\":\"jspsych-survey-text-next\",\"class\":\"jspsych-btn jspsych-survey-text\"},\"previousSibling\":{\"id\":2600},\"parentNode\":{\"id\":55}},{\"nodeType\":1,\"id\":2602,\"tagName\":\"P\",\"attributes\":{\"class\":\"jspsych-survey-text\"},\"parentNode\":{\"id\":2599}},{\"nodeType\":1,\"id\":2603,\"tagName\":\"TEXTAREA\",\"attributes\":{\"name\":\"#jspsych-survey-text-response-0\",\"cols\":\"40\",\"rows\":\"1\"},\"previousSibling\":{\"id\":2602},\"parentNode\":{\"id\":2599}},{\"nodeType\":3,\"id\":2604,\"textContent\":\"What is your age?\",\"parentNode\":{\"id\":2602}},{\"nodeType\":1,\"id\":2605,\"tagName\":\"P\",\"attributes\":{\"class\":\"jspsych-survey-text\"},\"parentNode\":{\"id\":2600}},{\"nodeType\":1,\"id\":2606,\"tagName\":\"TEXTAREA\",\"attributes\":{\"name\":\"#jspsych-survey-text-response-1\",\"cols\":\"40\",\"rows\":\"1\"},\"previousSibling\":{\"id\":2605},\"parentNode\":{\"id\":2600}},{\"nodeType\":3,\"id\":2607,\"textContent\":\"In what country were you born?\",\"parentNode\":{\"id\":2605}},{\"nodeType\":3,\"id\":2608,\"textContent\":\"Submit Answers\",\"parentNode\":{\"id\":2601}}],[],[]]}"
    },
    {
      "sequence": 3,
      "data": "{\"f\":\"applyChanged\",\"args\":[[{\"id\":2598},{\"id\":2599},{\"id\":2602},{\"id\":2604},{\"id\":2603},{\"id\":2600},{\"id\":2605},{\"id\":2607},{\"id\":2606},{\"id\":2601},{\"id\":2608}],[],[],[]]}"
    },
    {
      "sequence": 4,
      "data": "{\"f\":\"applyChanged\",\"args\":[[],[{\"nodeType\":1,\"id\":2609,\"tagName\":\"FORM\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-form\"},\"parentNode\":{\"id\":55}},{\"nodeType\":1,\"id\":2610,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-preamble\",\"class\":\"jspsych-survey-multi-choice-preamble\"},\"parentNode\":{\"id\":2609}},{\"nodeType\":1,\"id\":2611,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-0\",\"class\":\"jspsych-survey-multi-choice-question jspsych-survey-multi-choice-horizontal\"},\"previousSibling\":{\"id\":2610},\"parentNode\":{\"id\":2609}},{\"nodeType\":1,\"id\":2612,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-1\",\"class\":\"jspsych-survey-multi-choice-question jspsych-survey-multi-choice-horizontal\"},\"previousSibling\":{\"id\":2611},\"parentNode\":{\"id\":2609}},{\"nodeType\":1,\"id\":2613,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-2\",\"class\":\"jspsych-survey-multi-choice-question jspsych-survey-multi-choice-horizontal\"},\"previousSibling\":{\"id\":2612},\"parentNode\":{\"id\":2609}},{\"nodeType\":1,\"id\":2614,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-3\",\"class\":\"jspsych-survey-multi-choice-question jspsych-survey-multi-choice-horizontal\"},\"previousSibling\":{\"id\":2613},\"parentNode\":{\"id\":2609}},{\"nodeType\":1,\"id\":2615,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"submit\",\"id\":\"jspsych-survey-multi-choice-next\",\"class\":\"jspsych-survey-multi-choice jspsych-btn\",\"value\":\"Submit Answers\"},\"previousSibling\":{\"id\":2614},\"parentNode\":{\"id\":2609}},{\"nodeType\":1,\"id\":2616,\"tagName\":\"P\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text survey-multi-choice\"},\"parentNode\":{\"id\":2611}},{\"nodeType\":1,\"id\":2617,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-0-0\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2616},\"parentNode\":{\"id\":2611}},{\"nodeType\":1,\"id\":2618,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-0-1\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2617},\"parentNode\":{\"id\":2611}},{\"nodeType\":1,\"id\":2619,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-0-2\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2618},\"parentNode\":{\"id\":2611}},{\"nodeType\":1,\"id\":2620,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-0-3\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2619},\"parentNode\":{\"id\":2611}},{\"nodeType\":3,\"id\":2621,\"textContent\":\"What is your first language?\",\"parentNode\":{\"id\":2616}},{\"nodeType\":1,\"id\":2622,\"tagName\":\"SPAN\",\"attributes\":{\"class\":\"required\"},\"previousSibling\":{\"id\":2621},\"parentNode\":{\"id\":2616}},{\"nodeType\":1,\"id\":2623,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2617}},{\"nodeType\":1,\"id\":2624,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-0\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2623}},{\"nodeType\":3,\"id\":2625,\"textContent\":\"English\",\"previousSibling\":{\"id\":2624},\"parentNode\":{\"id\":2623}},{\"nodeType\":1,\"id\":2626,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2618}},{\"nodeType\":1,\"id\":2627,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-0\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2626}},{\"nodeType\":3,\"id\":2628,\"textContent\":\"Spanish\",\"previousSibling\":{\"id\":2627},\"parentNode\":{\"id\":2626}},{\"nodeType\":1,\"id\":2629,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2619}},{\"nodeType\":1,\"id\":2630,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-0\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2629}},{\"nodeType\":3,\"id\":2631,\"textContent\":\"Mandarin or Cantonese\",\"previousSibling\":{\"id\":2630},\"parentNode\":{\"id\":2629}},{\"nodeType\":1,\"id\":2632,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2620}},{\"nodeType\":1,\"id\":2633,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-0\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2632}},{\"nodeType\":3,\"id\":2634,\"textContent\":\"Other\",\"previousSibling\":{\"id\":2633},\"parentNode\":{\"id\":2632}},{\"nodeType\":3,\"id\":2635,\"textContent\":\"*\",\"parentNode\":{\"id\":2622}},{\"nodeType\":1,\"id\":2636,\"tagName\":\"P\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text survey-multi-choice\"},\"parentNode\":{\"id\":2612}},{\"nodeType\":1,\"id\":2637,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-1-0\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2636},\"parentNode\":{\"id\":2612}},{\"nodeType\":1,\"id\":2638,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-1-1\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2637},\"parentNode\":{\"id\":2612}},{\"nodeType\":1,\"id\":2639,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-1-2\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2638},\"parentNode\":{\"id\":2612}},{\"nodeType\":1,\"id\":2640,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-1-3\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2639},\"parentNode\":{\"id\":2612}},{\"nodeType\":1,\"id\":2641,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-1-4\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2640},\"parentNode\":{\"id\":2612}},{\"nodeType\":1,\"id\":2642,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-1-5\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2641},\"parentNode\":{\"id\":2612}},{\"nodeType\":1,\"id\":2643,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-1-6\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2642},\"parentNode\":{\"id\":2612}},{\"nodeType\":3,\"id\":2644,\"textContent\":\"What is your year in school?\",\"parentNode\":{\"id\":2636}},{\"nodeType\":1,\"id\":2645,\"tagName\":\"SPAN\",\"attributes\":{\"class\":\"required\"},\"previousSibling\":{\"id\":2644},\"parentNode\":{\"id\":2636}},{\"nodeType\":1,\"id\":2646,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2637}},{\"nodeType\":1,\"id\":2647,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-1\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2646}},{\"nodeType\":3,\"id\":2648,\"textContent\":\"First\",\"previousSibling\":{\"id\":2647},\"parentNode\":{\"id\":2646}},{\"nodeType\":1,\"id\":2649,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2638}},{\"nodeType\":1,\"id\":2650,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-1\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2649}},{\"nodeType\":3,\"id\":2651,\"textContent\":\"Second\",\"previousSibling\":{\"id\":2650},\"parentNode\":{\"id\":2649}},{\"nodeType\":1,\"id\":2652,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2639}},{\"nodeType\":1,\"id\":2653,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-1\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2652}},{\"nodeType\":3,\"id\":2654,\"textContent\":\"Third\",\"previousSibling\":{\"id\":2653},\"parentNode\":{\"id\":2652}},{\"nodeType\":1,\"id\":2655,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2640}},{\"nodeType\":1,\"id\":2656,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-1\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2655}},{\"nodeType\":3,\"id\":2657,\"textContent\":\"Fourth\",\"previousSibling\":{\"id\":2656},\"parentNode\":{\"id\":2655}},{\"nodeType\":1,\"id\":2658,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2641}},{\"nodeType\":1,\"id\":2659,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-1\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2658}},{\"nodeType\":3,\"id\":2660,\"textContent\":\"Fifth\",\"previousSibling\":{\"id\":2659},\"parentNode\":{\"id\":2658}},{\"nodeType\":1,\"id\":2661,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2642}},{\"nodeType\":1,\"id\":2662,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-1\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2661}},{\"nodeType\":3,\"id\":2663,\"textContent\":\"Graduate\",\"previousSibling\":{\"id\":2662},\"parentNode\":{\"id\":2661}},{\"nodeType\":1,\"id\":2664,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2643}},{\"nodeType\":1,\"id\":2665,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-1\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2664}},{\"nodeType\":3,\"id\":2666,\"textContent\":\"Other\",\"previousSibling\":{\"id\":2665},\"parentNode\":{\"id\":2664}},{\"nodeType\":3,\"id\":2667,\"textContent\":\"*\",\"parentNode\":{\"id\":2645}},{\"nodeType\":1,\"id\":2668,\"tagName\":\"P\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text survey-multi-choice\"},\"parentNode\":{\"id\":2613}},{\"nodeType\":1,\"id\":2669,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-2-0\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2668},\"parentNode\":{\"id\":2613}},{\"nodeType\":1,\"id\":2670,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-2-1\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2669},\"parentNode\":{\"id\":2613}},{\"nodeType\":1,\"id\":2671,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-2-2\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2670},\"parentNode\":{\"id\":2613}},{\"nodeType\":1,\"id\":2672,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-2-3\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2671},\"parentNode\":{\"id\":2613}},{\"nodeType\":1,\"id\":2673,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-2-4\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2672},\"parentNode\":{\"id\":2613}},{\"nodeType\":1,\"id\":2674,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-2-5\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2673},\"parentNode\":{\"id\":2613}},{\"nodeType\":1,\"id\":2675,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-2-6\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2674},\"parentNode\":{\"id\":2613}},{\"nodeType\":3,\"id\":2676,\"textContent\":\"What is your major area of study?\",\"parentNode\":{\"id\":2668}},{\"nodeType\":1,\"id\":2677,\"tagName\":\"SPAN\",\"attributes\":{\"class\":\"required\"},\"previousSibling\":{\"id\":2676},\"parentNode\":{\"id\":2668}},{\"nodeType\":1,\"id\":2678,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2669}},{\"nodeType\":1,\"id\":2679,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-2\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2678}},{\"nodeType\":3,\"id\":2680,\"textContent\":\"Math or Computer Sciences\",\"previousSibling\":{\"id\":2679},\"parentNode\":{\"id\":2678}},{\"nodeType\":1,\"id\":2681,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2670}},{\"nodeType\":1,\"id\":2682,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-2\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2681}},{\"nodeType\":3,\"id\":2683,\"textContent\":\"Social Sciences (incl. CogSci)\",\"previousSibling\":{\"id\":2682},\"parentNode\":{\"id\":2681}},{\"nodeType\":1,\"id\":2684,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2671}},{\"nodeType\":1,\"id\":2685,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-2\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2684}},{\"nodeType\":3,\"id\":2686,\"textContent\":\"Biomedical & Health Sciences\",\"previousSibling\":{\"id\":2685},\"parentNode\":{\"id\":2684}},{\"nodeType\":1,\"id\":2687,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2672}},{\"nodeType\":1,\"id\":2688,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-2\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2687}},{\"nodeType\":3,\"id\":2689,\"textContent\":\"Natural Sciences\",\"previousSibling\":{\"id\":2688},\"parentNode\":{\"id\":2687}},{\"nodeType\":1,\"id\":2690,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2673}},{\"nodeType\":1,\"id\":2691,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-2\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2690}},{\"nodeType\":3,\"id\":2692,\"textContent\":\"Engineering\",\"previousSibling\":{\"id\":2691},\"parentNode\":{\"id\":2690}},{\"nodeType\":1,\"id\":2693,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2674}},{\"nodeType\":1,\"id\":2694,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-2\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2693}},{\"nodeType\":3,\"id\":2695,\"textContent\":\"Humanities\",\"previousSibling\":{\"id\":2694},\"parentNode\":{\"id\":2693}},{\"nodeType\":1,\"id\":2696,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2675}},{\"nodeType\":1,\"id\":2697,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-2\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2696}},{\"nodeType\":3,\"id\":2698,\"textContent\":\"Fine Arts\",\"previousSibling\":{\"id\":2697},\"parentNode\":{\"id\":2696}},{\"nodeType\":3,\"id\":2699,\"textContent\":\"*\",\"parentNode\":{\"id\":2677}},{\"nodeType\":1,\"id\":2700,\"tagName\":\"P\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text survey-multi-choice\"},\"parentNode\":{\"id\":2614}},{\"nodeType\":1,\"id\":2701,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-3-0\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2700},\"parentNode\":{\"id\":2614}},{\"nodeType\":1,\"id\":2702,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-3-1\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2701},\"parentNode\":{\"id\":2614}},{\"nodeType\":1,\"id\":2703,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-3-2\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2702},\"parentNode\":{\"id\":2614}},{\"nodeType\":3,\"id\":2704,\"textContent\":\"What is your gender?\",\"parentNode\":{\"id\":2700}},{\"nodeType\":1,\"id\":2705,\"tagName\":\"SPAN\",\"attributes\":{\"class\":\"required\"},\"previousSibling\":{\"id\":2704},\"parentNode\":{\"id\":2700}},{\"nodeType\":1,\"id\":2706,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2701}},{\"nodeType\":1,\"id\":2707,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-3\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2706}},{\"nodeType\":3,\"id\":2708,\"textContent\":\"Male\",\"previousSibling\":{\"id\":2707},\"parentNode\":{\"id\":2706}},{\"nodeType\":1,\"id\":2709,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2702}},{\"nodeType\":1,\"id\":2710,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-3\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2709}},{\"nodeType\":3,\"id\":2711,\"textContent\":\"Female\",\"previousSibling\":{\"id\":2710},\"parentNode\":{\"id\":2709}},{\"nodeType\":1,\"id\":2712,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2703}},{\"nodeType\":1,\"id\":2713,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-3\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2712}},{\"nodeType\":3,\"id\":2714,\"textContent\":\"Other\",\"previousSibling\":{\"id\":2713},\"parentNode\":{\"id\":2712}},{\"nodeType\":3,\"id\":2715,\"textContent\":\"*\",\"parentNode\":{\"id\":2705}}],[],[]]}"
    },
    {
      "sequence": 5,
      "data": "{\"f\":\"applyChanged\",\"args\":[[{\"id\":2609},{\"id\":2610},{\"id\":2611},{\"id\":2616},{\"id\":2621},{\"id\":2622},{\"id\":2635},{\"id\":2617},{\"id\":2623},{\"id\":2624},{\"id\":2625},{\"id\":2618},{\"id\":2626},{\"id\":2627},{\"id\":2628},{\"id\":2619},{\"id\":2629},{\"id\":2630},{\"id\":2631},{\"id\":2620},{\"id\":2632},{\"id\":2633},{\"id\":2634},{\"id\":2612},{\"id\":2636},{\"id\":2644},{\"id\":2645},{\"id\":2667},{\"id\":2637},{\"id\":2646},{\"id\":2647},{\"id\":2648},{\"id\":2638},{\"id\":2649},{\"id\":2650},{\"id\":2651},{\"id\":2639},{\"id\":2652},{\"id\":2653},{\"id\":2654},{\"id\":2640},{\"id\":2655},{\"id\":2656},{\"id\":2657},{\"id\":2641},{\"id\":2658},{\"id\":2659},{\"id\":2660},{\"id\":2642},{\"id\":2661},{\"id\":2662},{\"id\":2663},{\"id\":2643},{\"id\":2664},{\"id\":2665},{\"id\":2666},{\"id\":2613},{\"id\":2668},{\"id\":2676},{\"id\":2677},{\"id\":2699},{\"id\":2669},{\"id\":2678},{\"id\":2679},{\"id\":2680},{\"id\":2670},{\"id\":2681},{\"id\":2682},{\"id\":2683},{\"id\":2671},{\"id\":2684},{\"id\":2685},{\"id\":2686},{\"id\":2672},{\"id\":2687},{\"id\":2688},{\"id\":2689},{\"id\":2673},{\"id\":2690},{\"id\":2691},{\"id\":2692},{\"id\":2674},{\"id\":2693},{\"id\":2694},{\"id\":2695},{\"id\":2675},{\"id\":2696},{\"id\":2697},{\"id\":2698},{\"id\":2614},{\"id\":2700},{\"id\":2704},{\"id\":2705},{\"id\":2715},{\"id\":2701},{\"id\":2706},{\"id\":2707},{\"id\":2708},{\"id\":2702},{\"id\":2709},{\"id\":2710},{\"id\":2711},{\"id\":2703},{\"id\":2712},{\"id\":2713},{\"id\":2714},{\"id\":2615}],[],[],[]]}"
    },
    {
      "sequence": 6,
      "data": "{\"f\":\"applyChanged\",\"args\":[[],[{\"nodeType\":1,\"id\":2716,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"masterdiv\"},\"parentNode\":{\"id\":55}},{\"nodeType\":3,\"id\":2717,\"textContent\":\" \",\"previousSibling\":{\"id\":2716},\"parentNode\":{\"id\":55}},{\"nodeType\":3,\"id\":2718,\"textContent\":\" \",\"parentNode\":{\"id\":2716}},{\"nodeType\":1,\"id\":2719,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"top\"},\"previousSibling\":{\"id\":2718},\"parentNode\":{\"id\":2716}},{\"nodeType\":3,\"id\":2720,\"textContent\":\" \",\"previousSibling\":{\"id\":2719},\"parentNode\":{\"id\":2716}},{\"nodeType\":1,\"id\":2721,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"instructions\"},\"previousSibling\":{\"id\":2720},\"parentNode\":{\"id\":2716}},{\"nodeType\":3,\"id\":2722,\"textContent\":\" \",\"previousSibling\":{\"id\":2721},\"parentNode\":{\"id\":2716}},{\"nodeType\":1,\"id\":2723,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bottom\"},\"previousSibling\":{\"id\":2722},\"parentNode\":{\"id\":2716}},{\"nodeType\":3,\"id\":2724,\"textContent\":\" \",\"previousSibling\":{\"id\":2723},\"parentNode\":{\"id\":2716}},{\"nodeType\":3,\"id\":2725,\"textContent\":\" \",\"parentNode\":{\"id\":2719}},{\"nodeType\":1,\"id\":2726,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bcent\"},\"previousSibling\":{\"id\":2725},\"parentNode\":{\"id\":2719}},{\"nodeType\":3,\"id\":2727,\"textContent\":\" \",\"previousSibling\":{\"id\":2726},\"parentNode\":{\"id\":2719}},{\"nodeType\":3,\"id\":2728,\"textContent\":\" \",\"parentNode\":{\"id\":2726}},{\"nodeType\":1,\"id\":2729,\"tagName\":\"H3\",\"attributes\":{},\"previousSibling\":{\"id\":2728},\"parentNode\":{\"id\":2726}},{\"nodeType\":3,\"id\":2730,\"textContent\":\" \",\"previousSibling\":{\"id\":2729},\"parentNode\":{\"id\":2726}},{\"nodeType\":3,\"id\":2731,\"textContent\":\"DEBRIEFING\",\"parentNode\":{\"id\":2729}},{\"nodeType\":3,\"id\":2732,\"textContent\":\" \",\"parentNode\":{\"id\":2721}},{\"nodeType\":1,\"id\":2733,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"vcent\"},\"previousSibling\":{\"id\":2732},\"parentNode\":{\"id\":2721}},{\"nodeType\":3,\"id\":2734,\"textContent\":\" \",\"previousSibling\":{\"id\":2733},\"parentNode\":{\"id\":2721}},{\"nodeType\":3,\"id\":2735,\"textContent\":\" \",\"parentNode\":{\"id\":2733}},{\"nodeType\":1,\"id\":2736,\"tagName\":\"P\",\"attributes\":{\"style\":\"font-style:italic\"},\"previousSibling\":{\"id\":2735},\"parentNode\":{\"id\":2733}},{\"nodeType\":1,\"id\":2737,\"tagName\":\"P\",\"attributes\":{},\"previousSibling\":{\"id\":2736},\"parentNode\":{\"id\":2733}},{\"nodeType\":3,\"id\":2738,\"textContent\":\" \",\"previousSibling\":{\"id\":2737},\"parentNode\":{\"id\":2733}},{\"nodeType\":1,\"id\":2739,\"tagName\":\"P\",\"attributes\":{},\"previousSibling\":{\"id\":2738},\"parentNode\":{\"id\":2733}},{\"nodeType\":3,\"id\":2740,\"textContent\":\" \",\"previousSibling\":{\"id\":2739},\"parentNode\":{\"id\":2733}},{\"nodeType\":1,\"id\":2741,\"tagName\":\"P\",\"attributes\":{},\"previousSibling\":{\"id\":2740},\"parentNode\":{\"id\":2733}},{\"nodeType\":3,\"id\":2742,\"textContent\":\" \",\"previousSibling\":{\"id\":2741},\"parentNode\":{\"id\":2733}},{\"nodeType\":1,\"id\":2743,\"tagName\":\"P\",\"attributes\":{\"style\":\"font-style:bold;\"},\"previousSibling\":{\"id\":2742},\"parentNode\":{\"id\":2733}},{\"nodeType\":3,\"id\":2744,\"textContent\":\" \",\"previousSibling\":{\"id\":2743},\"parentNode\":{\"id\":2733}},{\"nodeType\":1,\"id\":2745,\"tagName\":\"P\",\"attributes\":{\"style\":\"font-style:italic;\"},\"previousSibling\":{\"id\":2744},\"parentNode\":{\"id\":2733}},{\"nodeType\":3,\"id\":2746,\"textContent\":\" \",\"previousSibling\":{\"id\":2745},\"parentNode\":{\"id\":2733}},{\"nodeType\":3,\"id\":2747,\"textContent\":\"Thank you very much for your participation! This debriefing will tell you more about the study, what you did, and why. \",\"parentNode\":{\"id\":2736}},{\"nodeType\":3,\"id\":2748,\"textContent\":\" \",\"parentNode\":{\"id\":2737}},{\"nodeType\":1,\"id\":2749,\"tagName\":\"B\",\"attributes\":{},\"previousSibling\":{\"id\":2748},\"parentNode\":{\"id\":2737}},{\"nodeType\":3,\"id\":2750,\"textContent\":\" You have just used a series of pictures (charts, graphs and diagrams) accompanied by different types of instructions to answer a series of problem solving questions. While you were using the pictures, we measured where you clicked, scrolled and pointed with the computer mouse. We also measured the accuracy of your responses and the time it took to complete each question.\",\"previousSibling\":{\"id\":2749},\"parentNode\":{\"id\":2737}},{\"nodeType\":3,\"id\":2751,\"textContent\":\"What did you just do?\",\"parentNode\":{\"id\":2749}},{\"nodeType\":3,\"id\":2752,\"textContent\":\" \",\"parentNode\":{\"id\":2739}},{\"nodeType\":1,\"id\":2753,\"tagName\":\"B\",\"attributes\":{},\"previousSibling\":{\"id\":2752},\"parentNode\":{\"id\":2739}},{\"nodeType\":3,\"id\":2754,\"textContent\":\" Researchers of learning and cognition have long been interested in how graphic displays of information can be used to communicate, solve problems, and generate insights. As powerful as graphics may be in their communicative efficiency, they're not always immediately intuitive to understand. In short, we know a great deal more about learning with representations than we do about the learning of representations. In this project we are building upon previous research on reading and graph comprehension to explore how readers make sense of unfamiliar representations. The instructions you saw for each type of graph are known as “scaffolding techniques”, and we will compare your performance with the scaffolding techniques you saw with the performance of other participants to determine which types of instructions are most effective in helping humans to make sense of unfamiliar graphs. \",\"previousSibling\":{\"id\":2753},\"parentNode\":{\"id\":2739}},{\"nodeType\":3,\"id\":2755,\"textContent\":\"Why did we have you do it?\",\"parentNode\":{\"id\":2753}},{\"nodeType\":1,\"id\":2756,\"tagName\":\"B\",\"attributes\":{},\"parentNode\":{\"id\":2741}},{\"nodeType\":3,\"id\":2757,\"textContent\":\" We expect that you will have found some of the graphics more difficult to use than others. We also expect that with the assistance of the instructions, after solving several problems you will learn to use the difficult graphics so that you can answer the questions even more quickly than without. If you would like to receive a copy of the results of the study, or have any further questions, please contact the researchers Primary Researcher: Amy Fox : a2fox@ucsd.edu Faculty Advisor : Dr. Jim Hollan : hollan@ucsd.edu \",\"previousSibling\":{\"id\":2756},\"parentNode\":{\"id\":2741}},{\"nodeType\":3,\"id\":2758,\"textContent\":\"What do we expect to find?\",\"parentNode\":{\"id\":2756}},{\"nodeType\":3,\"id\":2759,\"textContent\":\"It is important that you do not discuss this experiment with other students who might participate after you. They must participate in the same way as you did, without any knowledge of what the experiment entails, or the reasoning behind it.\",\"parentNode\":{\"id\":2743}},{\"nodeType\":3,\"id\":2760,\"textContent\":\"Thank you for your time! We hope you enjoyed participating in this study as much as we enjoyed designing it.\",\"parentNode\":{\"id\":2745}},{\"nodeType\":3,\"id\":2761,\"textContent\":\" \",\"parentNode\":{\"id\":2723}},{\"nodeType\":1,\"id\":2762,\"tagName\":\"BUTTON\",\"attributes\":{\"class\":\"btn\",\"type\":\"button\",\"id\":\"start\"},\"previousSibling\":{\"id\":2761},\"parentNode\":{\"id\":2723}},{\"nodeType\":3,\"id\":2763,\"textContent\":\" \",\"previousSibling\":{\"id\":2762},\"parentNode\":{\"id\":2723}},{\"nodeType\":3,\"id\":2764,\"textContent\":\"FINISH\",\"parentNode\":{\"id\":2762}}],[],[]]}"
    },
    {
      "sequence": 7,
      "data": "{\"f\":\"applyChanged\",\"args\":[[{\"id\":2716},{\"id\":2718},{\"id\":2719},{\"id\":2725},{\"id\":2726},{\"id\":2728},{\"id\":2729},{\"id\":2731},{\"id\":2730},{\"id\":2727},{\"id\":2720},{\"id\":2721},{\"id\":2732},{\"id\":2733},{\"id\":2735},{\"id\":2736},{\"id\":2747},{\"id\":2737},{\"id\":2748},{\"id\":2749},{\"id\":2751},{\"id\":2750},{\"id\":2738},{\"id\":2739},{\"id\":2752},{\"id\":2753},{\"id\":2755},{\"id\":2754},{\"id\":2740},{\"id\":2741},{\"id\":2756},{\"id\":2758},{\"id\":2757},{\"id\":2742},{\"id\":2743},{\"id\":2759},{\"id\":2744},{\"id\":2745},{\"id\":2760},{\"id\":2746},{\"id\":2734},{\"id\":2722},{\"id\":2723},{\"id\":2761},{\"id\":2762},{\"id\":2764},{\"id\":2763},{\"id\":2724},{\"id\":2717}],[],[],[]]}"
    },
    {
      "sequence": 8,
      "data": "{\"f\":\"applyChanged\",\"args\":[[],[{\"nodeType\":1,\"id\":2765,\"tagName\":\"PRE\",\"attributes\":{\"id\":\"jspsych-data-display\"},\"parentNode\":{\"id\":55}},{\"nodeType\":3,\"id\":2766,\"textContent\":\"[ { \\\"rt\\\": 41173, \\\"stimulus\\\": \\\"img/phone.png\\\", \\\"key_press\\\": 32, \\\"block\\\": \\\"phone\\\", \\\"trial_type\\\": \\\"single-stim\\\", \\\"trial_index\\\": 0, \\\"time_elapsed\\\": 41178, \\\"internal_node_id\\\": \\\"0.0-0.0\\\", \\\"subject\\\": \\\"06217\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"zulu\\\", \\\"condition\\\": \\\"211\\\" }, { \\\"rt\\\": 405828, \\\"url\\\": \\\"../views/src/external/consent.html\\\", \\\"block\\\": \\\"consent\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 1, \\\"time_elapsed\\\": 448101, \\\"internal_node_id\\\": \\\"0.0-1.0\\\", \\\"subject\\\": \\\"06217\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"zulu\\\", \\\"condition\\\": \\\"211\\\" }, { \\\"rt\\\": 7800, \\\"responses\\\": \\\"{\\\\\\\"Q0\\\\\\\":\\\\\\\"ZULU\\\\\\\",\\\\\\\"Q1\\\\\\\":\\\\\\\"211\\\\\\\"}\\\", \\\"block\\\": \\\"codes\\\", \\\"trial_type\\\": \\\"survey-text\\\", \\\"trial_index\\\": 2, \\\"time_elapsed\\\": 456908, \\\"internal_node_id\\\": \\\"0.0-2.0\\\", \\\"subject\\\": \\\"06217\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"zulu\\\", \\\"condition\\\": \\\"211\\\" }, { \\\"rt\\\": 7924, \\\"url\\\": \\\"../views/src/external/instructions_lab.html\\\", \\\"block\\\": \\\"instructions_lab\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 3, \\\"time_elapsed\\\": 466164, \\\"internal_node_id\\\": \\\"0.0-3.0\\\", \\\"subject\\\": \\\"06217\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"zulu\\\", \\\"condition\\\": \\\"211\\\" }, { \\\"rt\\\": 11297, \\\"stimulus\\\": \\\"img/acme.png\\\", \\\"key_press\\\": 13, \\\"block\\\": \\\"scenario\\\", \\\"trial_type\\\": \\\"single-stim\\\", \\\"trial_index\\\": 4, \\\"time_elapsed\\\": 478465, \\\"internal_node_id\\\": \\\"0.0-4.0\\\", \\\"subject\\\": \\\"06217\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"zulu\\\", \\\"condition\\\": \\\"211\\\" }, { \\\"rt\\\": 23937, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 5, \\\"time_elapsed\\\": 503833, \\\"internal_node_id\\\": \\\"0.0-5.0-0.0\\\", \\\"subject\\\": \\\"06217\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"zulu\\\", \\\"condition\\\": \\\"211\\\", \\\"scenario\\\": \\\"acme\\\", \\\"question\\\": \\\"starttime\\\", \\\"q\\\": 1, \\\"clicks\\\": 1, \\\"explicit\\\": 2, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XInside-YFull\\\", \\\"correct\\\": 1, \\\"orth_correct\\\": 0, \\\"answer\\\": [ \\\"F\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"X \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"U \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-11 AM-11 AM-F -11 AM-11 AM\\\", \\\"block\\\": \\\"triangular_scaffolded\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:976,y:1024,t:1528143399765};\\\", \\\"{x:978,y:1024,t:1528143399779};\\\", \\\"{x:995,y:1026,t:1528143399795};\\\", \\\"{x:1018,y:1029,t:1528143399813};\\\", \\\"{x:1040,y:1031,t:1528143399829};\\\", \\\"{x:1054,y:1031,t:1528143399845};\\\", \\\"{x:1058,y:1031,t:1528143399862};\\\", \\\"{x:1062,y:1031,t:1528143399878};\\\", \\\"{x:1066,y:1031,t:1528143399896};\\\", \\\"{x:1068,y:1031,t:1528143399924};\\\", \\\"{x:1069,y:1031,t:1528143399931};\\\", \\\"{x:1071,y:1031,t:1528143399946};\\\", \\\"{x:1077,y:1034,t:1528143399963};\\\", \\\"{x:1085,y:1036,t:1528143399979};\\\", \\\"{x:1110,y:1039,t:1528143399996};\\\", \\\"{x:1126,y:1047,t:1528143400013};\\\", \\\"{x:1127,y:1052,t:1528143400029};\\\", \\\"{x:1127,y:1053,t:1528143400708};\\\", \\\"{x:1128,y:1054,t:1528143401069};\\\", \\\"{x:1131,y:1055,t:1528143401080};\\\", \\\"{x:1139,y:1060,t:1528143401097};\\\", \\\"{x:1140,y:1060,t:1528143401113};\\\", \\\"{x:1140,y:1059,t:1528143401508};\\\", \\\"{x:1141,y:1059,t:1528143401516};\\\", \\\"{x:1141,y:1057,t:1528143401741};\\\", \\\"{x:1141,y:1055,t:1528143401747};\\\", \\\"{x:1141,y:1054,t:1528143401763};\\\", \\\"{x:1141,y:1052,t:1528143401781};\\\", \\\"{x:1141,y:1051,t:1528143401845};\\\", \\\"{x:1140,y:1051,t:1528143401933};\\\", \\\"{x:1141,y:1051,t:1528143402668};\\\", \\\"{x:1143,y:1050,t:1528143402692};\\\", \\\"{x:1144,y:1049,t:1528143402700};\\\", \\\"{x:1146,y:1047,t:1528143402716};\\\", \\\"{x:1147,y:1046,t:1528143402732};\\\", \\\"{x:1156,y:1043,t:1528143402748};\\\", \\\"{x:1170,y:1040,t:1528143402765};\\\", \\\"{x:1197,y:1037,t:1528143402781};\\\", \\\"{x:1234,y:1032,t:1528143402798};\\\", \\\"{x:1258,y:1027,t:1528143402816};\\\", \\\"{x:1279,y:1025,t:1528143402832};\\\", \\\"{x:1293,y:1022,t:1528143402848};\\\", \\\"{x:1295,y:1021,t:1528143402865};\\\", \\\"{x:1296,y:1020,t:1528143402981};\\\", \\\"{x:1296,y:1019,t:1528143402999};\\\", \\\"{x:1296,y:1018,t:1528143403015};\\\", \\\"{x:1296,y:1016,t:1528143403036};\\\", \\\"{x:1295,y:1015,t:1528143403052};\\\", \\\"{x:1295,y:1013,t:1528143403069};\\\", \\\"{x:1295,y:1012,t:1528143403083};\\\", \\\"{x:1295,y:1010,t:1528143403097};\\\", \\\"{x:1295,y:1009,t:1528143403115};\\\", \\\"{x:1299,y:1001,t:1528143403131};\\\", \\\"{x:1306,y:995,t:1528143403148};\\\", \\\"{x:1315,y:986,t:1528143403165};\\\", \\\"{x:1319,y:977,t:1528143403181};\\\", \\\"{x:1319,y:973,t:1528143403198};\\\", \\\"{x:1319,y:970,t:1528143403214};\\\", \\\"{x:1319,y:969,t:1528143403231};\\\", \\\"{x:1319,y:968,t:1528143403248};\\\", \\\"{x:1318,y:966,t:1528143403265};\\\", \\\"{x:1317,y:966,t:1528143403282};\\\", \\\"{x:1315,y:964,t:1528143403298};\\\", \\\"{x:1311,y:964,t:1528143403315};\\\", \\\"{x:1300,y:964,t:1528143403332};\\\", \\\"{x:1297,y:964,t:1528143403348};\\\", \\\"{x:1296,y:964,t:1528143403405};\\\", \\\"{x:1294,y:964,t:1528143403428};\\\", \\\"{x:1289,y:964,t:1528143403436};\\\", \\\"{x:1286,y:964,t:1528143403449};\\\", \\\"{x:1276,y:965,t:1528143403466};\\\", \\\"{x:1269,y:967,t:1528143403482};\\\", \\\"{x:1262,y:969,t:1528143403499};\\\", \\\"{x:1261,y:969,t:1528143403517};\\\", \\\"{x:1262,y:969,t:1528143404012};\\\", \\\"{x:1263,y:969,t:1528143404068};\\\", \\\"{x:1263,y:968,t:1528143404084};\\\", \\\"{x:1265,y:968,t:1528143404156};\\\", \\\"{x:1267,y:966,t:1528143404172};\\\", \\\"{x:1268,y:966,t:1528143404196};\\\", \\\"{x:1269,y:965,t:1528143404220};\\\", \\\"{x:1270,y:965,t:1528143404236};\\\", \\\"{x:1272,y:964,t:1528143404249};\\\", \\\"{x:1274,y:962,t:1528143404267};\\\", \\\"{x:1276,y:962,t:1528143404282};\\\", \\\"{x:1276,y:961,t:1528143404299};\\\", \\\"{x:1278,y:960,t:1528143404317};\\\", \\\"{x:1279,y:959,t:1528143404332};\\\", \\\"{x:1280,y:958,t:1528143407277};\\\", \\\"{x:1282,y:957,t:1528143407579};\\\", \\\"{x:1284,y:953,t:1528143407595};\\\", \\\"{x:1287,y:950,t:1528143407603};\\\", \\\"{x:1291,y:947,t:1528143407618};\\\", \\\"{x:1295,y:943,t:1528143407635};\\\", \\\"{x:1297,y:941,t:1528143407651};\\\", \\\"{x:1298,y:940,t:1528143407667};\\\", \\\"{x:1299,y:939,t:1528143407685};\\\", \\\"{x:1301,y:937,t:1528143407701};\\\", \\\"{x:1302,y:936,t:1528143407718};\\\", \\\"{x:1306,y:930,t:1528143407735};\\\", \\\"{x:1312,y:925,t:1528143407751};\\\", \\\"{x:1317,y:921,t:1528143407769};\\\", \\\"{x:1321,y:919,t:1528143407786};\\\", \\\"{x:1322,y:915,t:1528143407801};\\\", \\\"{x:1323,y:913,t:1528143407819};\\\", \\\"{x:1324,y:912,t:1528143407836};\\\", \\\"{x:1324,y:909,t:1528143407852};\\\", \\\"{x:1326,y:906,t:1528143407869};\\\", \\\"{x:1327,y:900,t:1528143407885};\\\", \\\"{x:1327,y:897,t:1528143407902};\\\", \\\"{x:1327,y:892,t:1528143407919};\\\", \\\"{x:1327,y:889,t:1528143407936};\\\", \\\"{x:1327,y:884,t:1528143407952};\\\", \\\"{x:1327,y:880,t:1528143407969};\\\", \\\"{x:1328,y:874,t:1528143407985};\\\", \\\"{x:1329,y:868,t:1528143408002};\\\", \\\"{x:1331,y:862,t:1528143408018};\\\", \\\"{x:1332,y:854,t:1528143408035};\\\", \\\"{x:1336,y:843,t:1528143408052};\\\", \\\"{x:1338,y:834,t:1528143408068};\\\", \\\"{x:1343,y:825,t:1528143408085};\\\", \\\"{x:1346,y:818,t:1528143408101};\\\", \\\"{x:1349,y:814,t:1528143408117};\\\", \\\"{x:1351,y:809,t:1528143408134};\\\", \\\"{x:1355,y:803,t:1528143408152};\\\", \\\"{x:1358,y:798,t:1528143408167};\\\", \\\"{x:1363,y:792,t:1528143408185};\\\", \\\"{x:1369,y:785,t:1528143408202};\\\", \\\"{x:1373,y:780,t:1528143408219};\\\", \\\"{x:1376,y:777,t:1528143408235};\\\", \\\"{x:1379,y:773,t:1528143408251};\\\", \\\"{x:1380,y:771,t:1528143408348};\\\", \\\"{x:1380,y:770,t:1528143408581};\\\", \\\"{x:1380,y:769,t:1528143408588};\\\", \\\"{x:1380,y:767,t:1528143408607};\\\", \\\"{x:1380,y:766,t:1528143408650};\\\", \\\"{x:1354,y:771,t:1528143409470};\\\", \\\"{x:1249,y:783,t:1528143409486};\\\", \\\"{x:1088,y:807,t:1528143409503};\\\", \\\"{x:904,y:825,t:1528143409519};\\\", \\\"{x:700,y:825,t:1528143409536};\\\", \\\"{x:572,y:825,t:1528143409553};\\\", \\\"{x:543,y:823,t:1528143409569};\\\", \\\"{x:543,y:822,t:1528143409586};\\\", \\\"{x:543,y:821,t:1528143409604};\\\", \\\"{x:543,y:761,t:1528143409620};\\\", \\\"{x:519,y:690,t:1528143409636};\\\", \\\"{x:462,y:612,t:1528143409655};\\\", \\\"{x:380,y:542,t:1528143409671};\\\", \\\"{x:311,y:499,t:1528143409686};\\\", \\\"{x:276,y:485,t:1528143409703};\\\", \\\"{x:269,y:485,t:1528143409720};\\\", \\\"{x:268,y:485,t:1528143409803};\\\", \\\"{x:266,y:485,t:1528143409821};\\\", \\\"{x:264,y:485,t:1528143409837};\\\", \\\"{x:263,y:489,t:1528143409892};\\\", \\\"{x:265,y:498,t:1528143409904};\\\", \\\"{x:283,y:518,t:1528143409922};\\\", \\\"{x:310,y:541,t:1528143409938};\\\", \\\"{x:350,y:560,t:1528143409954};\\\", \\\"{x:388,y:574,t:1528143409971};\\\", \\\"{x:393,y:575,t:1528143409988};\\\", \\\"{x:401,y:577,t:1528143410004};\\\", \\\"{x:404,y:577,t:1528143410060};\\\", \\\"{x:404,y:576,t:1528143410076};\\\", \\\"{x:404,y:573,t:1528143410088};\\\", \\\"{x:404,y:567,t:1528143410104};\\\", \\\"{x:400,y:559,t:1528143410120};\\\", \\\"{x:395,y:554,t:1528143410138};\\\", \\\"{x:394,y:553,t:1528143410155};\\\", \\\"{x:394,y:552,t:1528143410171};\\\", \\\"{x:392,y:552,t:1528143410188};\\\", \\\"{x:397,y:555,t:1528143411228};\\\", \\\"{x:422,y:580,t:1528143411240};\\\", \\\"{x:513,y:641,t:1528143411256};\\\", \\\"{x:624,y:715,t:1528143411271};\\\", \\\"{x:726,y:760,t:1528143411288};\\\", \\\"{x:817,y:785,t:1528143411305};\\\", \\\"{x:911,y:809,t:1528143411322};\\\", \\\"{x:1052,y:834,t:1528143411339};\\\", \\\"{x:1124,y:852,t:1528143411355};\\\", \\\"{x:1168,y:862,t:1528143411372};\\\", \\\"{x:1202,y:868,t:1528143411389};\\\", \\\"{x:1228,y:872,t:1528143411405};\\\", \\\"{x:1245,y:875,t:1528143411422};\\\", \\\"{x:1253,y:876,t:1528143411439};\\\", \\\"{x:1254,y:876,t:1528143411579};\\\", \\\"{x:1254,y:877,t:1528143411590};\\\", \\\"{x:1254,y:878,t:1528143411605};\\\", \\\"{x:1255,y:879,t:1528143411623};\\\", \\\"{x:1255,y:880,t:1528143411644};\\\", \\\"{x:1255,y:881,t:1528143411676};\\\", \\\"{x:1255,y:882,t:1528143411708};\\\", \\\"{x:1255,y:883,t:1528143411723};\\\", \\\"{x:1255,y:884,t:1528143412892};\\\", \\\"{x:1255,y:890,t:1528143412906};\\\", \\\"{x:1264,y:908,t:1528143412924};\\\", \\\"{x:1267,y:912,t:1528143412940};\\\", \\\"{x:1270,y:917,t:1528143412956};\\\", \\\"{x:1273,y:921,t:1528143412974};\\\", \\\"{x:1274,y:924,t:1528143412991};\\\", \\\"{x:1274,y:927,t:1528143413007};\\\", \\\"{x:1276,y:933,t:1528143413024};\\\", \\\"{x:1276,y:938,t:1528143413041};\\\", \\\"{x:1276,y:944,t:1528143413056};\\\", \\\"{x:1276,y:948,t:1528143413073};\\\", \\\"{x:1275,y:953,t:1528143413091};\\\", \\\"{x:1271,y:960,t:1528143413107};\\\", \\\"{x:1268,y:965,t:1528143413124};\\\", \\\"{x:1265,y:969,t:1528143413140};\\\", \\\"{x:1262,y:974,t:1528143413157};\\\", \\\"{x:1259,y:978,t:1528143413174};\\\", \\\"{x:1256,y:982,t:1528143413191};\\\", \\\"{x:1254,y:984,t:1528143413207};\\\", \\\"{x:1254,y:985,t:1528143413223};\\\", \\\"{x:1253,y:985,t:1528143413240};\\\", \\\"{x:1254,y:983,t:1528143414116};\\\", \\\"{x:1258,y:980,t:1528143414124};\\\", \\\"{x:1261,y:977,t:1528143414141};\\\", \\\"{x:1263,y:975,t:1528143414158};\\\", \\\"{x:1266,y:972,t:1528143414174};\\\", \\\"{x:1267,y:971,t:1528143414192};\\\", \\\"{x:1268,y:971,t:1528143414208};\\\", \\\"{x:1269,y:970,t:1528143414225};\\\", \\\"{x:1269,y:969,t:1528143414241};\\\", \\\"{x:1271,y:968,t:1528143414258};\\\", \\\"{x:1272,y:967,t:1528143414276};\\\", \\\"{x:1273,y:965,t:1528143414292};\\\", \\\"{x:1274,y:965,t:1528143414388};\\\", \\\"{x:1275,y:965,t:1528143414396};\\\", \\\"{x:1276,y:965,t:1528143414412};\\\", \\\"{x:1277,y:965,t:1528143414924};\\\", \\\"{x:1282,y:959,t:1528143414941};\\\", \\\"{x:1289,y:948,t:1528143414959};\\\", \\\"{x:1301,y:932,t:1528143414976};\\\", \\\"{x:1313,y:910,t:1528143414991};\\\", \\\"{x:1329,y:877,t:1528143415009};\\\", \\\"{x:1342,y:851,t:1528143415026};\\\", \\\"{x:1351,y:829,t:1528143415042};\\\", \\\"{x:1354,y:818,t:1528143415059};\\\", \\\"{x:1357,y:808,t:1528143415078};\\\", \\\"{x:1359,y:804,t:1528143415091};\\\", \\\"{x:1360,y:802,t:1528143415108};\\\", \\\"{x:1361,y:800,t:1528143415125};\\\", \\\"{x:1361,y:799,t:1528143415141};\\\", \\\"{x:1361,y:796,t:1528143415158};\\\", \\\"{x:1361,y:795,t:1528143415175};\\\", \\\"{x:1362,y:792,t:1528143415191};\\\", \\\"{x:1363,y:787,t:1528143415208};\\\", \\\"{x:1364,y:783,t:1528143415225};\\\", \\\"{x:1364,y:779,t:1528143415242};\\\", \\\"{x:1366,y:772,t:1528143415258};\\\", \\\"{x:1367,y:769,t:1528143415275};\\\", \\\"{x:1367,y:767,t:1528143415291};\\\", \\\"{x:1367,y:766,t:1528143415308};\\\", \\\"{x:1370,y:763,t:1528143415326};\\\", \\\"{x:1370,y:762,t:1528143415342};\\\", \\\"{x:1372,y:759,t:1528143415358};\\\", \\\"{x:1372,y:758,t:1528143415375};\\\", \\\"{x:1373,y:756,t:1528143415393};\\\", \\\"{x:1371,y:761,t:1528143418212};\\\", \\\"{x:1317,y:803,t:1528143418228};\\\", \\\"{x:1225,y:836,t:1528143418244};\\\", \\\"{x:1121,y:875,t:1528143418261};\\\", \\\"{x:1035,y:911,t:1528143418277};\\\", \\\"{x:986,y:941,t:1528143418294};\\\", \\\"{x:959,y:961,t:1528143418311};\\\", \\\"{x:954,y:966,t:1528143418327};\\\", \\\"{x:952,y:971,t:1528143418344};\\\", \\\"{x:950,y:977,t:1528143418361};\\\", \\\"{x:942,y:988,t:1528143418377};\\\", \\\"{x:935,y:994,t:1528143418395};\\\", \\\"{x:922,y:996,t:1528143418410};\\\", \\\"{x:897,y:996,t:1528143418428};\\\", \\\"{x:879,y:992,t:1528143418445};\\\", \\\"{x:850,y:980,t:1528143418462};\\\", \\\"{x:810,y:961,t:1528143418477};\\\", \\\"{x:769,y:947,t:1528143418494};\\\", \\\"{x:729,y:933,t:1528143418512};\\\", \\\"{x:683,y:906,t:1528143418527};\\\", \\\"{x:651,y:884,t:1528143418545};\\\", \\\"{x:615,y:849,t:1528143418562};\\\", \\\"{x:563,y:820,t:1528143418578};\\\", \\\"{x:495,y:793,t:1528143418595};\\\", \\\"{x:393,y:756,t:1528143418612};\\\", \\\"{x:360,y:741,t:1528143418628};\\\", \\\"{x:356,y:738,t:1528143418645};\\\", \\\"{x:356,y:735,t:1528143418662};\\\", \\\"{x:357,y:733,t:1528143418678};\\\", \\\"{x:361,y:729,t:1528143418694};\\\", \\\"{x:365,y:724,t:1528143418712};\\\", \\\"{x:369,y:722,t:1528143418728};\\\", \\\"{x:371,y:720,t:1528143418744};\\\", \\\"{x:377,y:717,t:1528143418762};\\\", \\\"{x:390,y:712,t:1528143418777};\\\", \\\"{x:406,y:707,t:1528143418795};\\\", \\\"{x:424,y:706,t:1528143418812};\\\", \\\"{x:433,y:706,t:1528143418828};\\\", \\\"{x:435,y:706,t:1528143418844};\\\", \\\"{x:436,y:706,t:1528143418862};\\\", \\\"{x:437,y:706,t:1528143418980};\\\", \\\"{x:438,y:706,t:1528143418994};\\\", \\\"{x:440,y:708,t:1528143419012};\\\", \\\"{x:443,y:709,t:1528143419028};\\\", \\\"{x:449,y:709,t:1528143419046};\\\", \\\"{x:454,y:710,t:1528143419061};\\\", \\\"{x:460,y:710,t:1528143419078};\\\", \\\"{x:462,y:710,t:1528143419089};\\\", \\\"{x:466,y:710,t:1528143419106};\\\", \\\"{x:473,y:710,t:1528143419123};\\\", \\\"{x:476,y:710,t:1528143419140};\\\", \\\"{x:477,y:710,t:1528143419156};\\\", \\\"{x:478,y:711,t:1528143419340};\\\", \\\"{x:478,y:711,t:1528143419433};\\\" ] }, { \\\"rt\\\": 7307, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 6, \\\"time_elapsed\\\": 512482, \\\"internal_node_id\\\": \\\"0.0-5.0-1.0\\\", \\\"subject\\\": \\\"06217\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"zulu\\\", \\\"condition\\\": \\\"211\\\", \\\"scenario\\\": \\\"acme\\\", \\\"question\\\": \\\"starts\\\", \\\"q\\\": 2, \\\"clicks\\\": 1.5, \\\"explicit\\\": 2, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XInside-YFull\\\", \\\"correct\\\": 1, \\\"orth_correct\\\": 0, \\\"answer\\\": [ \\\"K\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"X \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"U \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-K -5\\\", \\\"block\\\": \\\"triangular_scaffolded\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:480,y:711,t:1528143422684};\\\", \\\"{x:500,y:711,t:1528143422700};\\\", \\\"{x:520,y:716,t:1528143422714};\\\", \\\"{x:587,y:726,t:1528143422731};\\\", \\\"{x:728,y:734,t:1528143422747};\\\", \\\"{x:831,y:736,t:1528143422764};\\\", \\\"{x:953,y:736,t:1528143422780};\\\", \\\"{x:1069,y:736,t:1528143422797};\\\", \\\"{x:1169,y:736,t:1528143422814};\\\", \\\"{x:1250,y:733,t:1528143422831};\\\", \\\"{x:1304,y:725,t:1528143422847};\\\", \\\"{x:1331,y:724,t:1528143422864};\\\", \\\"{x:1352,y:721,t:1528143422881};\\\", \\\"{x:1357,y:719,t:1528143422897};\\\", \\\"{x:1358,y:719,t:1528143422915};\\\", \\\"{x:1360,y:719,t:1528143422947};\\\", \\\"{x:1362,y:717,t:1528143422956};\\\", \\\"{x:1364,y:716,t:1528143422965};\\\", \\\"{x:1368,y:713,t:1528143422983};\\\", \\\"{x:1372,y:711,t:1528143422998};\\\", \\\"{x:1375,y:707,t:1528143423015};\\\", \\\"{x:1377,y:704,t:1528143423031};\\\", \\\"{x:1378,y:699,t:1528143423049};\\\", \\\"{x:1378,y:693,t:1528143423065};\\\", \\\"{x:1368,y:686,t:1528143423082};\\\", \\\"{x:1361,y:679,t:1528143423099};\\\", \\\"{x:1352,y:673,t:1528143423113};\\\", \\\"{x:1343,y:667,t:1528143423131};\\\", \\\"{x:1339,y:664,t:1528143423148};\\\", \\\"{x:1336,y:663,t:1528143423164};\\\", \\\"{x:1335,y:662,t:1528143423181};\\\", \\\"{x:1333,y:662,t:1528143423198};\\\", \\\"{x:1332,y:661,t:1528143423306};\\\", \\\"{x:1332,y:660,t:1528143423314};\\\", \\\"{x:1332,y:663,t:1528143423452};\\\", \\\"{x:1330,y:669,t:1528143423465};\\\", \\\"{x:1326,y:674,t:1528143423482};\\\", \\\"{x:1325,y:674,t:1528143423499};\\\", \\\"{x:1326,y:676,t:1528143423811};\\\", \\\"{x:1329,y:674,t:1528143423931};\\\", \\\"{x:1337,y:666,t:1528143423950};\\\", \\\"{x:1350,y:659,t:1528143423965};\\\", \\\"{x:1361,y:650,t:1528143423983};\\\", \\\"{x:1374,y:641,t:1528143423999};\\\", \\\"{x:1385,y:633,t:1528143424016};\\\", \\\"{x:1391,y:630,t:1528143424033};\\\", \\\"{x:1394,y:628,t:1528143424050};\\\", \\\"{x:1395,y:627,t:1528143424066};\\\", \\\"{x:1396,y:626,t:1528143424084};\\\", \\\"{x:1397,y:626,t:1528143424108};\\\", \\\"{x:1399,y:626,t:1528143424132};\\\", \\\"{x:1400,y:626,t:1528143424150};\\\", \\\"{x:1403,y:625,t:1528143424167};\\\", \\\"{x:1410,y:623,t:1528143424182};\\\", \\\"{x:1420,y:621,t:1528143424199};\\\", \\\"{x:1431,y:616,t:1528143424217};\\\", \\\"{x:1451,y:608,t:1528143424233};\\\", \\\"{x:1477,y:595,t:1528143424250};\\\", \\\"{x:1508,y:574,t:1528143424267};\\\", \\\"{x:1544,y:545,t:1528143424284};\\\", \\\"{x:1557,y:531,t:1528143424300};\\\", \\\"{x:1562,y:520,t:1528143424317};\\\", \\\"{x:1565,y:513,t:1528143424333};\\\", \\\"{x:1565,y:508,t:1528143424350};\\\", \\\"{x:1566,y:504,t:1528143424367};\\\", \\\"{x:1567,y:499,t:1528143424383};\\\", \\\"{x:1567,y:496,t:1528143424400};\\\", \\\"{x:1570,y:491,t:1528143424417};\\\", \\\"{x:1570,y:486,t:1528143424433};\\\", \\\"{x:1572,y:483,t:1528143424450};\\\", \\\"{x:1575,y:477,t:1528143424467};\\\", \\\"{x:1581,y:469,t:1528143424484};\\\", \\\"{x:1583,y:465,t:1528143424500};\\\", \\\"{x:1585,y:463,t:1528143424517};\\\", \\\"{x:1585,y:462,t:1528143424534};\\\", \\\"{x:1586,y:460,t:1528143424550};\\\", \\\"{x:1587,y:458,t:1528143424567};\\\", \\\"{x:1588,y:456,t:1528143424584};\\\", \\\"{x:1589,y:454,t:1528143424600};\\\", \\\"{x:1589,y:452,t:1528143424617};\\\", \\\"{x:1592,y:449,t:1528143424634};\\\", \\\"{x:1595,y:444,t:1528143424650};\\\", \\\"{x:1600,y:439,t:1528143424667};\\\", \\\"{x:1605,y:431,t:1528143424684};\\\", \\\"{x:1608,y:427,t:1528143424700};\\\", \\\"{x:1609,y:426,t:1528143424717};\\\", \\\"{x:1607,y:428,t:1528143424787};\\\", \\\"{x:1605,y:434,t:1528143424800};\\\", \\\"{x:1600,y:446,t:1528143424817};\\\", \\\"{x:1594,y:467,t:1528143424834};\\\", \\\"{x:1590,y:493,t:1528143424851};\\\", \\\"{x:1586,y:518,t:1528143424867};\\\", \\\"{x:1575,y:552,t:1528143424884};\\\", \\\"{x:1569,y:566,t:1528143424902};\\\", \\\"{x:1558,y:579,t:1528143424917};\\\", \\\"{x:1549,y:585,t:1528143424934};\\\", \\\"{x:1539,y:593,t:1528143424951};\\\", \\\"{x:1532,y:596,t:1528143424967};\\\", \\\"{x:1532,y:597,t:1528143424984};\\\", \\\"{x:1531,y:597,t:1528143425020};\\\", \\\"{x:1530,y:599,t:1528143425035};\\\", \\\"{x:1528,y:600,t:1528143425051};\\\", \\\"{x:1520,y:609,t:1528143425068};\\\", \\\"{x:1518,y:611,t:1528143425084};\\\", \\\"{x:1515,y:615,t:1528143425101};\\\", \\\"{x:1513,y:616,t:1528143425332};\\\", \\\"{x:1512,y:616,t:1528143425347};\\\", \\\"{x:1511,y:617,t:1528143425364};\\\", \\\"{x:1510,y:617,t:1528143425372};\\\", \\\"{x:1506,y:619,t:1528143425384};\\\", \\\"{x:1493,y:620,t:1528143425401};\\\", \\\"{x:1459,y:621,t:1528143425417};\\\", \\\"{x:1408,y:622,t:1528143425435};\\\", \\\"{x:1333,y:622,t:1528143425451};\\\", \\\"{x:1208,y:622,t:1528143425467};\\\", \\\"{x:1127,y:622,t:1528143425484};\\\", \\\"{x:1063,y:622,t:1528143425500};\\\", \\\"{x:999,y:622,t:1528143425517};\\\", \\\"{x:940,y:622,t:1528143425534};\\\", \\\"{x:898,y:622,t:1528143425550};\\\", \\\"{x:871,y:622,t:1528143425567};\\\", \\\"{x:851,y:622,t:1528143425584};\\\", \\\"{x:825,y:619,t:1528143425601};\\\", \\\"{x:781,y:618,t:1528143425617};\\\", \\\"{x:725,y:618,t:1528143425635};\\\", \\\"{x:655,y:624,t:1528143425652};\\\", \\\"{x:606,y:629,t:1528143425668};\\\", \\\"{x:577,y:630,t:1528143425684};\\\", \\\"{x:549,y:630,t:1528143425699};\\\", \\\"{x:520,y:630,t:1528143425716};\\\", \\\"{x:506,y:630,t:1528143425733};\\\", \\\"{x:499,y:630,t:1528143425749};\\\", \\\"{x:494,y:627,t:1528143425767};\\\", \\\"{x:491,y:624,t:1528143425783};\\\", \\\"{x:485,y:620,t:1528143425799};\\\", \\\"{x:481,y:616,t:1528143425817};\\\", \\\"{x:478,y:614,t:1528143425833};\\\", \\\"{x:475,y:609,t:1528143425851};\\\", \\\"{x:473,y:606,t:1528143425866};\\\", \\\"{x:468,y:601,t:1528143425883};\\\", \\\"{x:464,y:599,t:1528143425900};\\\", \\\"{x:461,y:598,t:1528143425917};\\\", \\\"{x:455,y:598,t:1528143425934};\\\", \\\"{x:442,y:598,t:1528143425950};\\\", \\\"{x:432,y:599,t:1528143425966};\\\", \\\"{x:426,y:599,t:1528143425983};\\\", \\\"{x:424,y:600,t:1528143426000};\\\", \\\"{x:423,y:600,t:1528143426396};\\\", \\\"{x:422,y:604,t:1528143426403};\\\", \\\"{x:425,y:615,t:1528143426419};\\\", \\\"{x:439,y:635,t:1528143426435};\\\", \\\"{x:453,y:658,t:1528143426450};\\\", \\\"{x:469,y:674,t:1528143426467};\\\", \\\"{x:473,y:676,t:1528143426483};\\\", \\\"{x:474,y:677,t:1528143426500};\\\", \\\"{x:475,y:677,t:1528143426523};\\\", \\\"{x:471,y:677,t:1528143426571};\\\", \\\"{x:459,y:675,t:1528143426583};\\\", \\\"{x:413,y:660,t:1528143426600};\\\", \\\"{x:361,y:641,t:1528143426618};\\\", \\\"{x:327,y:624,t:1528143426634};\\\", \\\"{x:300,y:610,t:1528143426651};\\\", \\\"{x:297,y:601,t:1528143426667};\\\", \\\"{x:299,y:594,t:1528143426685};\\\", \\\"{x:303,y:591,t:1528143426700};\\\", \\\"{x:308,y:587,t:1528143426717};\\\", \\\"{x:312,y:584,t:1528143426735};\\\", \\\"{x:316,y:581,t:1528143426751};\\\", \\\"{x:319,y:581,t:1528143426767};\\\", \\\"{x:331,y:579,t:1528143426785};\\\", \\\"{x:352,y:577,t:1528143426800};\\\", \\\"{x:374,y:577,t:1528143426817};\\\", \\\"{x:392,y:577,t:1528143426834};\\\", \\\"{x:402,y:580,t:1528143426851};\\\", \\\"{x:406,y:583,t:1528143426869};\\\", \\\"{x:406,y:584,t:1528143426884};\\\", \\\"{x:406,y:585,t:1528143426901};\\\", \\\"{x:405,y:587,t:1528143426917};\\\", \\\"{x:405,y:588,t:1528143426934};\\\", \\\"{x:405,y:590,t:1528143426951};\\\", \\\"{x:405,y:591,t:1528143426987};\\\", \\\"{x:404,y:591,t:1528143427002};\\\", \\\"{x:404,y:592,t:1528143427017};\\\", \\\"{x:403,y:593,t:1528143427034};\\\", \\\"{x:402,y:593,t:1528143427051};\\\", \\\"{x:401,y:593,t:1528143427067};\\\", \\\"{x:399,y:593,t:1528143427091};\\\", \\\"{x:398,y:594,t:1528143427101};\\\", \\\"{x:397,y:594,t:1528143427117};\\\", \\\"{x:396,y:594,t:1528143427134};\\\", \\\"{x:395,y:595,t:1528143427152};\\\", \\\"{x:393,y:596,t:1528143427220};\\\", \\\"{x:392,y:597,t:1528143427251};\\\", \\\"{x:392,y:597,t:1528143427354};\\\", \\\"{x:394,y:602,t:1528143427515};\\\", \\\"{x:402,y:607,t:1528143427523};\\\", \\\"{x:408,y:611,t:1528143427535};\\\", \\\"{x:423,y:624,t:1528143427552};\\\", \\\"{x:453,y:648,t:1528143427568};\\\", \\\"{x:492,y:674,t:1528143427585};\\\", \\\"{x:520,y:699,t:1528143427601};\\\", \\\"{x:546,y:714,t:1528143427618};\\\", \\\"{x:552,y:716,t:1528143427634};\\\", \\\"{x:556,y:719,t:1528143427651};\\\", \\\"{x:557,y:719,t:1528143427731};\\\", \\\"{x:557,y:718,t:1528143427739};\\\", \\\"{x:555,y:717,t:1528143427751};\\\", \\\"{x:553,y:715,t:1528143427768};\\\", \\\"{x:551,y:712,t:1528143427784};\\\", \\\"{x:550,y:712,t:1528143427836};\\\", \\\"{x:548,y:712,t:1528143427859};\\\", \\\"{x:546,y:712,t:1528143427892};\\\", \\\"{x:546,y:713,t:1528143427923};\\\" ] }, { \\\"rt\\\": 16478, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 7, \\\"time_elapsed\\\": 530309, \\\"internal_node_id\\\": \\\"0.0-5.0-2.0\\\", \\\"subject\\\": \\\"06217\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"zulu\\\", \\\"condition\\\": \\\"211\\\", \\\"scenario\\\": \\\"acme\\\", \\\"question\\\": \\\"meets\\\", \\\"q\\\": 3, \\\"clicks\\\": 1.5, \\\"explicit\\\": 2, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XInside-YFull\\\", \\\"correct\\\": 1, \\\"orth_correct\\\": 0, \\\"answer\\\": [ \\\"F\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"X \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"U \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-C -Z -Z \\\", \\\"block\\\": \\\"triangular_scaffolded\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:551,y:715,t:1528143430556};\\\", \\\"{x:572,y:714,t:1528143430574};\\\", \\\"{x:596,y:714,t:1528143430589};\\\", \\\"{x:641,y:706,t:1528143430603};\\\", \\\"{x:691,y:700,t:1528143430620};\\\", \\\"{x:752,y:694,t:1528143430637};\\\", \\\"{x:807,y:694,t:1528143430654};\\\", \\\"{x:872,y:692,t:1528143430670};\\\", \\\"{x:929,y:689,t:1528143430687};\\\", \\\"{x:991,y:685,t:1528143430704};\\\", \\\"{x:1052,y:681,t:1528143430721};\\\", \\\"{x:1114,y:669,t:1528143430737};\\\", \\\"{x:1177,y:664,t:1528143430753};\\\", \\\"{x:1244,y:658,t:1528143430771};\\\", \\\"{x:1278,y:653,t:1528143430787};\\\", \\\"{x:1294,y:649,t:1528143430803};\\\", \\\"{x:1303,y:646,t:1528143430820};\\\", \\\"{x:1308,y:644,t:1528143430837};\\\", \\\"{x:1308,y:643,t:1528143432852};\\\", \\\"{x:1309,y:643,t:1528143432860};\\\", \\\"{x:1312,y:643,t:1528143432872};\\\", \\\"{x:1313,y:643,t:1528143432889};\\\", \\\"{x:1315,y:643,t:1528143432906};\\\", \\\"{x:1317,y:643,t:1528143433028};\\\", \\\"{x:1318,y:643,t:1528143433039};\\\", \\\"{x:1319,y:641,t:1528143433056};\\\", \\\"{x:1321,y:641,t:1528143433074};\\\", \\\"{x:1322,y:641,t:1528143433089};\\\", \\\"{x:1326,y:641,t:1528143433107};\\\", \\\"{x:1338,y:641,t:1528143433123};\\\", \\\"{x:1355,y:640,t:1528143433140};\\\", \\\"{x:1382,y:640,t:1528143433157};\\\", \\\"{x:1409,y:640,t:1528143433173};\\\", \\\"{x:1437,y:640,t:1528143433189};\\\", \\\"{x:1460,y:640,t:1528143433206};\\\", \\\"{x:1486,y:640,t:1528143433224};\\\", \\\"{x:1508,y:636,t:1528143433239};\\\", \\\"{x:1524,y:634,t:1528143433256};\\\", \\\"{x:1533,y:632,t:1528143433273};\\\", \\\"{x:1543,y:631,t:1528143433289};\\\", \\\"{x:1553,y:627,t:1528143433306};\\\", \\\"{x:1558,y:624,t:1528143433324};\\\", \\\"{x:1561,y:623,t:1528143433340};\\\", \\\"{x:1563,y:622,t:1528143433357};\\\", \\\"{x:1564,y:621,t:1528143433373};\\\", \\\"{x:1567,y:618,t:1528143433390};\\\", \\\"{x:1569,y:617,t:1528143433406};\\\", \\\"{x:1570,y:615,t:1528143433423};\\\", \\\"{x:1573,y:614,t:1528143433441};\\\", \\\"{x:1576,y:611,t:1528143433457};\\\", \\\"{x:1578,y:610,t:1528143433473};\\\", \\\"{x:1581,y:609,t:1528143433491};\\\", \\\"{x:1581,y:608,t:1528143433506};\\\", \\\"{x:1582,y:608,t:1528143433523};\\\", \\\"{x:1584,y:607,t:1528143433540};\\\", \\\"{x:1584,y:606,t:1528143433556};\\\", \\\"{x:1586,y:606,t:1528143433595};\\\", \\\"{x:1587,y:606,t:1528143433606};\\\", \\\"{x:1592,y:608,t:1528143433623};\\\", \\\"{x:1601,y:617,t:1528143433640};\\\", \\\"{x:1612,y:629,t:1528143433655};\\\", \\\"{x:1623,y:642,t:1528143433673};\\\", \\\"{x:1635,y:652,t:1528143433690};\\\", \\\"{x:1643,y:657,t:1528143433705};\\\", \\\"{x:1647,y:660,t:1528143433723};\\\", \\\"{x:1649,y:665,t:1528143433740};\\\", \\\"{x:1649,y:668,t:1528143433756};\\\", \\\"{x:1647,y:676,t:1528143433772};\\\", \\\"{x:1638,y:683,t:1528143433790};\\\", \\\"{x:1628,y:689,t:1528143433806};\\\", \\\"{x:1620,y:690,t:1528143433823};\\\", \\\"{x:1612,y:691,t:1528143433840};\\\", \\\"{x:1606,y:691,t:1528143433858};\\\", \\\"{x:1599,y:691,t:1528143433872};\\\", \\\"{x:1593,y:693,t:1528143433890};\\\", \\\"{x:1584,y:700,t:1528143433907};\\\", \\\"{x:1577,y:705,t:1528143433923};\\\", \\\"{x:1574,y:707,t:1528143433941};\\\", \\\"{x:1571,y:710,t:1528143433957};\\\", \\\"{x:1564,y:715,t:1528143433974};\\\", \\\"{x:1557,y:718,t:1528143433991};\\\", \\\"{x:1551,y:719,t:1528143434008};\\\", \\\"{x:1543,y:723,t:1528143434023};\\\", \\\"{x:1541,y:724,t:1528143434051};\\\", \\\"{x:1533,y:729,t:1528143434060};\\\", \\\"{x:1518,y:732,t:1528143434074};\\\", \\\"{x:1511,y:734,t:1528143434090};\\\", \\\"{x:1505,y:737,t:1528143434108};\\\", \\\"{x:1500,y:741,t:1528143434124};\\\", \\\"{x:1497,y:744,t:1528143434140};\\\", \\\"{x:1494,y:748,t:1528143434157};\\\", \\\"{x:1485,y:754,t:1528143434173};\\\", \\\"{x:1474,y:763,t:1528143434191};\\\", \\\"{x:1459,y:774,t:1528143434207};\\\", \\\"{x:1444,y:784,t:1528143434223};\\\", \\\"{x:1430,y:794,t:1528143434240};\\\", \\\"{x:1421,y:801,t:1528143434258};\\\", \\\"{x:1410,y:809,t:1528143434274};\\\", \\\"{x:1397,y:817,t:1528143434291};\\\", \\\"{x:1383,y:828,t:1528143434308};\\\", \\\"{x:1370,y:839,t:1528143434324};\\\", \\\"{x:1355,y:851,t:1528143434340};\\\", \\\"{x:1338,y:866,t:1528143434357};\\\", \\\"{x:1322,y:874,t:1528143434374};\\\", \\\"{x:1314,y:877,t:1528143434390};\\\", \\\"{x:1313,y:878,t:1528143434407};\\\", \\\"{x:1312,y:878,t:1528143434460};\\\", \\\"{x:1310,y:878,t:1528143434475};\\\", \\\"{x:1305,y:878,t:1528143434491};\\\", \\\"{x:1287,y:875,t:1528143434507};\\\", \\\"{x:1267,y:871,t:1528143434524};\\\", \\\"{x:1250,y:868,t:1528143434540};\\\", \\\"{x:1235,y:865,t:1528143434558};\\\", \\\"{x:1225,y:862,t:1528143434574};\\\", \\\"{x:1217,y:860,t:1528143434590};\\\", \\\"{x:1213,y:859,t:1528143434608};\\\", \\\"{x:1210,y:857,t:1528143434624};\\\", \\\"{x:1208,y:856,t:1528143434640};\\\", \\\"{x:1206,y:855,t:1528143434657};\\\", \\\"{x:1206,y:854,t:1528143434674};\\\", \\\"{x:1205,y:851,t:1528143434691};\\\", \\\"{x:1203,y:848,t:1528143434707};\\\", \\\"{x:1202,y:847,t:1528143434723};\\\", \\\"{x:1202,y:845,t:1528143434748};\\\", \\\"{x:1202,y:844,t:1528143434758};\\\", \\\"{x:1202,y:840,t:1528143434774};\\\", \\\"{x:1202,y:839,t:1528143434796};\\\", \\\"{x:1202,y:838,t:1528143434844};\\\", \\\"{x:1202,y:837,t:1528143434857};\\\", \\\"{x:1202,y:836,t:1528143434892};\\\", \\\"{x:1203,y:834,t:1528143434907};\\\", \\\"{x:1203,y:833,t:1528143434924};\\\", \\\"{x:1204,y:833,t:1528143434941};\\\", \\\"{x:1206,y:831,t:1528143434957};\\\", \\\"{x:1208,y:829,t:1528143434974};\\\", \\\"{x:1210,y:828,t:1528143434994};\\\", \\\"{x:1210,y:827,t:1528143435007};\\\", \\\"{x:1212,y:826,t:1528143435023};\\\", \\\"{x:1213,y:827,t:1528143435411};\\\", \\\"{x:1214,y:830,t:1528143435424};\\\", \\\"{x:1216,y:837,t:1528143435443};\\\", \\\"{x:1217,y:840,t:1528143435458};\\\", \\\"{x:1218,y:843,t:1528143435474};\\\", \\\"{x:1219,y:845,t:1528143435491};\\\", \\\"{x:1219,y:846,t:1528143435515};\\\", \\\"{x:1220,y:846,t:1528143435525};\\\", \\\"{x:1220,y:847,t:1528143435541};\\\", \\\"{x:1221,y:847,t:1528143435558};\\\", \\\"{x:1222,y:848,t:1528143435574};\\\", \\\"{x:1223,y:850,t:1528143435591};\\\", \\\"{x:1224,y:852,t:1528143435608};\\\", \\\"{x:1225,y:853,t:1528143435624};\\\", \\\"{x:1227,y:854,t:1528143435641};\\\", \\\"{x:1227,y:856,t:1528143435658};\\\", \\\"{x:1228,y:857,t:1528143435674};\\\", \\\"{x:1230,y:860,t:1528143435691};\\\", \\\"{x:1233,y:864,t:1528143435709};\\\", \\\"{x:1236,y:868,t:1528143435725};\\\", \\\"{x:1237,y:869,t:1528143435741};\\\", \\\"{x:1238,y:869,t:1528143435758};\\\", \\\"{x:1238,y:870,t:1528143435775};\\\", \\\"{x:1239,y:871,t:1528143435791};\\\", \\\"{x:1240,y:872,t:1528143435820};\\\", \\\"{x:1241,y:873,t:1528143435828};\\\", \\\"{x:1241,y:874,t:1528143435844};\\\", \\\"{x:1242,y:875,t:1528143435858};\\\", \\\"{x:1242,y:876,t:1528143435908};\\\", \\\"{x:1244,y:879,t:1528143435925};\\\", \\\"{x:1246,y:881,t:1528143435941};\\\", \\\"{x:1246,y:882,t:1528143435959};\\\", \\\"{x:1247,y:883,t:1528143435975};\\\", \\\"{x:1248,y:886,t:1528143435991};\\\", \\\"{x:1249,y:887,t:1528143436008};\\\", \\\"{x:1249,y:888,t:1528143436026};\\\", \\\"{x:1249,y:889,t:1528143436041};\\\", \\\"{x:1250,y:890,t:1528143436058};\\\", \\\"{x:1250,y:891,t:1528143436107};\\\", \\\"{x:1250,y:893,t:1528143436126};\\\", \\\"{x:1250,y:895,t:1528143436141};\\\", \\\"{x:1252,y:898,t:1528143436158};\\\", \\\"{x:1252,y:900,t:1528143436175};\\\", \\\"{x:1253,y:902,t:1528143436192};\\\", \\\"{x:1254,y:903,t:1528143436208};\\\", \\\"{x:1255,y:905,t:1528143436225};\\\", \\\"{x:1256,y:907,t:1528143436242};\\\", \\\"{x:1256,y:908,t:1528143436258};\\\", \\\"{x:1257,y:911,t:1528143436275};\\\", \\\"{x:1259,y:914,t:1528143436292};\\\", \\\"{x:1259,y:915,t:1528143436315};\\\", \\\"{x:1260,y:915,t:1528143436326};\\\", \\\"{x:1261,y:919,t:1528143436342};\\\", \\\"{x:1262,y:921,t:1528143436358};\\\", \\\"{x:1263,y:922,t:1528143436375};\\\", \\\"{x:1264,y:924,t:1528143436393};\\\", \\\"{x:1266,y:927,t:1528143436409};\\\", \\\"{x:1268,y:930,t:1528143436425};\\\", \\\"{x:1269,y:933,t:1528143436442};\\\", \\\"{x:1270,y:936,t:1528143436458};\\\", \\\"{x:1273,y:940,t:1528143436475};\\\", \\\"{x:1274,y:941,t:1528143436492};\\\", \\\"{x:1274,y:943,t:1528143436507};\\\", \\\"{x:1275,y:944,t:1528143436525};\\\", \\\"{x:1275,y:945,t:1528143436563};\\\", \\\"{x:1276,y:946,t:1528143436575};\\\", \\\"{x:1277,y:949,t:1528143436592};\\\", \\\"{x:1277,y:950,t:1528143436607};\\\", \\\"{x:1278,y:952,t:1528143436625};\\\", \\\"{x:1279,y:954,t:1528143436641};\\\", \\\"{x:1281,y:956,t:1528143436659};\\\", \\\"{x:1281,y:957,t:1528143436675};\\\", \\\"{x:1281,y:959,t:1528143436692};\\\", \\\"{x:1282,y:960,t:1528143436709};\\\", \\\"{x:1283,y:962,t:1528143436725};\\\", \\\"{x:1284,y:962,t:1528143436742};\\\", \\\"{x:1284,y:963,t:1528143436796};\\\", \\\"{x:1286,y:962,t:1528143438380};\\\", \\\"{x:1289,y:957,t:1528143438393};\\\", \\\"{x:1293,y:951,t:1528143438410};\\\", \\\"{x:1305,y:939,t:1528143438427};\\\", \\\"{x:1315,y:926,t:1528143438444};\\\", \\\"{x:1327,y:915,t:1528143438460};\\\", \\\"{x:1334,y:907,t:1528143438477};\\\", \\\"{x:1342,y:896,t:1528143438493};\\\", \\\"{x:1349,y:890,t:1528143438511};\\\", \\\"{x:1352,y:884,t:1528143438528};\\\", \\\"{x:1357,y:877,t:1528143438544};\\\", \\\"{x:1362,y:869,t:1528143438560};\\\", \\\"{x:1366,y:858,t:1528143438578};\\\", \\\"{x:1371,y:847,t:1528143438593};\\\", \\\"{x:1376,y:838,t:1528143438610};\\\", \\\"{x:1380,y:827,t:1528143438627};\\\", \\\"{x:1383,y:820,t:1528143438643};\\\", \\\"{x:1385,y:814,t:1528143438661};\\\", \\\"{x:1386,y:809,t:1528143438678};\\\", \\\"{x:1389,y:802,t:1528143438693};\\\", \\\"{x:1390,y:798,t:1528143438710};\\\", \\\"{x:1392,y:793,t:1528143438727};\\\", \\\"{x:1393,y:789,t:1528143438744};\\\", \\\"{x:1394,y:786,t:1528143438761};\\\", \\\"{x:1395,y:782,t:1528143438777};\\\", \\\"{x:1395,y:780,t:1528143438828};\\\", \\\"{x:1395,y:779,t:1528143438843};\\\", \\\"{x:1396,y:775,t:1528143438860};\\\", \\\"{x:1396,y:771,t:1528143438878};\\\", \\\"{x:1397,y:769,t:1528143438894};\\\", \\\"{x:1397,y:767,t:1528143438911};\\\", \\\"{x:1398,y:765,t:1528143438928};\\\", \\\"{x:1399,y:765,t:1528143438943};\\\", \\\"{x:1399,y:764,t:1528143438971};\\\", \\\"{x:1399,y:763,t:1528143438987};\\\", \\\"{x:1399,y:762,t:1528143439186};\\\", \\\"{x:1398,y:762,t:1528143439195};\\\", \\\"{x:1397,y:762,t:1528143439210};\\\", \\\"{x:1392,y:762,t:1528143439226};\\\", \\\"{x:1390,y:761,t:1528143439250};\\\", \\\"{x:1388,y:761,t:1528143440428};\\\", \\\"{x:1268,y:766,t:1528143440445};\\\", \\\"{x:1074,y:768,t:1528143440461};\\\", \\\"{x:871,y:765,t:1528143440479};\\\", \\\"{x:670,y:737,t:1528143440495};\\\", \\\"{x:470,y:705,t:1528143440512};\\\", \\\"{x:351,y:687,t:1528143440528};\\\", \\\"{x:312,y:671,t:1528143440544};\\\", \\\"{x:297,y:659,t:1528143440563};\\\", \\\"{x:292,y:648,t:1528143440579};\\\", \\\"{x:292,y:647,t:1528143440595};\\\", \\\"{x:292,y:644,t:1528143440612};\\\", \\\"{x:292,y:638,t:1528143440629};\\\", \\\"{x:291,y:634,t:1528143440644};\\\", \\\"{x:291,y:628,t:1528143440661};\\\", \\\"{x:288,y:616,t:1528143440679};\\\", \\\"{x:283,y:604,t:1528143440696};\\\", \\\"{x:278,y:593,t:1528143440711};\\\", \\\"{x:277,y:587,t:1528143440729};\\\", \\\"{x:274,y:582,t:1528143440745};\\\", \\\"{x:272,y:576,t:1528143440762};\\\", \\\"{x:270,y:569,t:1528143440779};\\\", \\\"{x:269,y:564,t:1528143440795};\\\", \\\"{x:269,y:560,t:1528143440812};\\\", \\\"{x:272,y:553,t:1528143440828};\\\", \\\"{x:279,y:546,t:1528143440848};\\\", \\\"{x:294,y:540,t:1528143440862};\\\", \\\"{x:308,y:535,t:1528143440879};\\\", \\\"{x:320,y:531,t:1528143440896};\\\", \\\"{x:322,y:531,t:1528143440912};\\\", \\\"{x:323,y:531,t:1528143440929};\\\", \\\"{x:323,y:532,t:1528143440995};\\\", \\\"{x:323,y:534,t:1528143441003};\\\", \\\"{x:323,y:535,t:1528143441012};\\\", \\\"{x:324,y:537,t:1528143441029};\\\", \\\"{x:326,y:539,t:1528143441046};\\\", \\\"{x:327,y:542,t:1528143441115};\\\", \\\"{x:329,y:542,t:1528143441132};\\\", \\\"{x:330,y:543,t:1528143441146};\\\", \\\"{x:334,y:544,t:1528143441162};\\\", \\\"{x:336,y:545,t:1528143441178};\\\", \\\"{x:341,y:548,t:1528143441196};\\\", \\\"{x:347,y:550,t:1528143441211};\\\", \\\"{x:350,y:551,t:1528143441229};\\\", \\\"{x:351,y:551,t:1528143441246};\\\", \\\"{x:353,y:552,t:1528143441262};\\\", \\\"{x:354,y:552,t:1528143441279};\\\", \\\"{x:357,y:552,t:1528143441296};\\\", \\\"{x:358,y:553,t:1528143441312};\\\", \\\"{x:359,y:553,t:1528143441364};\\\", \\\"{x:361,y:553,t:1528143441435};\\\", \\\"{x:362,y:553,t:1528143441467};\\\", \\\"{x:363,y:553,t:1528143441490};\\\", \\\"{x:364,y:553,t:1528143441507};\\\", \\\"{x:365,y:553,t:1528143441547};\\\", \\\"{x:366,y:553,t:1528143441562};\\\", \\\"{x:367,y:553,t:1528143441595};\\\", \\\"{x:369,y:553,t:1528143442852};\\\", \\\"{x:371,y:553,t:1528143442864};\\\", \\\"{x:374,y:554,t:1528143442880};\\\", \\\"{x:376,y:555,t:1528143442897};\\\", \\\"{x:377,y:555,t:1528143442914};\\\", \\\"{x:382,y:563,t:1528143443954};\\\", \\\"{x:396,y:588,t:1528143443965};\\\", \\\"{x:429,y:631,t:1528143443981};\\\", \\\"{x:465,y:667,t:1528143443998};\\\", \\\"{x:495,y:685,t:1528143444015};\\\", \\\"{x:516,y:695,t:1528143444031};\\\", \\\"{x:528,y:701,t:1528143444048};\\\", \\\"{x:538,y:709,t:1528143444065};\\\", \\\"{x:545,y:721,t:1528143444081};\\\", \\\"{x:553,y:735,t:1528143444098};\\\", \\\"{x:561,y:750,t:1528143444115};\\\", \\\"{x:568,y:764,t:1528143444132};\\\", \\\"{x:574,y:773,t:1528143444148};\\\", \\\"{x:576,y:781,t:1528143444165};\\\", \\\"{x:580,y:789,t:1528143444182};\\\", \\\"{x:589,y:801,t:1528143444198};\\\", \\\"{x:596,y:813,t:1528143444216};\\\", \\\"{x:601,y:822,t:1528143444233};\\\", \\\"{x:605,y:825,t:1528143444249};\\\", \\\"{x:607,y:826,t:1528143444265};\\\", \\\"{x:607,y:827,t:1528143444282};\\\", \\\"{x:607,y:828,t:1528143444307};\\\", \\\"{x:608,y:829,t:1528143444332};\\\", \\\"{x:608,y:830,t:1528143444363};\\\", \\\"{x:609,y:831,t:1528143444371};\\\", \\\"{x:610,y:832,t:1528143444396};\\\", \\\"{x:611,y:834,t:1528143444411};\\\", \\\"{x:611,y:836,t:1528143444443};\\\", \\\"{x:612,y:837,t:1528143444739};\\\", \\\"{x:613,y:842,t:1528143444749};\\\", \\\"{x:638,y:859,t:1528143444766};\\\", \\\"{x:676,y:873,t:1528143444783};\\\", \\\"{x:714,y:883,t:1528143444800};\\\", \\\"{x:748,y:892,t:1528143444815};\\\", \\\"{x:776,y:899,t:1528143444833};\\\", \\\"{x:797,y:904,t:1528143444849};\\\", \\\"{x:807,y:909,t:1528143444865};\\\", \\\"{x:812,y:911,t:1528143444883};\\\", \\\"{x:814,y:911,t:1528143444899};\\\", \\\"{x:813,y:911,t:1528143444995};\\\", \\\"{x:811,y:911,t:1528143445004};\\\", \\\"{x:808,y:908,t:1528143445017};\\\", \\\"{x:802,y:904,t:1528143445032};\\\", \\\"{x:792,y:897,t:1528143445050};\\\", \\\"{x:781,y:884,t:1528143445067};\\\", \\\"{x:761,y:859,t:1528143445082};\\\", \\\"{x:751,y:841,t:1528143445099};\\\", \\\"{x:743,y:825,t:1528143445117};\\\", \\\"{x:738,y:814,t:1528143445132};\\\", \\\"{x:737,y:810,t:1528143445150};\\\", \\\"{x:735,y:808,t:1528143445171};\\\", \\\"{x:735,y:807,t:1528143445182};\\\", \\\"{x:731,y:802,t:1528143445200};\\\", \\\"{x:725,y:799,t:1528143445217};\\\", \\\"{x:714,y:793,t:1528143445233};\\\", \\\"{x:695,y:788,t:1528143445249};\\\", \\\"{x:679,y:783,t:1528143445266};\\\", \\\"{x:654,y:776,t:1528143445283};\\\", \\\"{x:621,y:765,t:1528143445299};\\\", \\\"{x:609,y:761,t:1528143445316};\\\", \\\"{x:597,y:756,t:1528143445332};\\\", \\\"{x:590,y:751,t:1528143445350};\\\", \\\"{x:585,y:748,t:1528143445367};\\\", \\\"{x:582,y:747,t:1528143445383};\\\", \\\"{x:578,y:744,t:1528143445400};\\\", \\\"{x:575,y:744,t:1528143445417};\\\", \\\"{x:571,y:741,t:1528143445434};\\\", \\\"{x:566,y:740,t:1528143445450};\\\", \\\"{x:561,y:739,t:1528143445467};\\\", \\\"{x:547,y:737,t:1528143445483};\\\", \\\"{x:539,y:736,t:1528143445499};\\\", \\\"{x:535,y:735,t:1528143445518};\\\", \\\"{x:533,y:734,t:1528143445533};\\\", \\\"{x:529,y:733,t:1528143445549};\\\", \\\"{x:526,y:732,t:1528143445566};\\\", \\\"{x:521,y:730,t:1528143445583};\\\", \\\"{x:519,y:730,t:1528143445599};\\\", \\\"{x:514,y:728,t:1528143445616};\\\", \\\"{x:511,y:728,t:1528143445633};\\\", \\\"{x:510,y:727,t:1528143445649};\\\", \\\"{x:509,y:726,t:1528143445666};\\\" ] }, { \\\"rt\\\": 6742, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 8, \\\"time_elapsed\\\": 538313, \\\"internal_node_id\\\": \\\"0.0-5.0-3.0\\\", \\\"subject\\\": \\\"06217\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"zulu\\\", \\\"condition\\\": \\\"211\\\", \\\"scenario\\\": \\\"acme\\\", \\\"question\\\": \\\"endtime\\\", \\\"q\\\": 4, \\\"clicks\\\": 1, \\\"explicit\\\": 2, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XInside-YFull\\\", \\\"correct\\\": 1, \\\"orth_correct\\\": 0, \\\"answer\\\": [ \\\"H\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"X \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"U \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-01 PM-03 PM-04 PM\\\", \\\"block\\\": \\\"triangular_scaffolded\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:510,y:725,t:1528143448052};\\\", \\\"{x:517,y:722,t:1528143448066};\\\", \\\"{x:532,y:720,t:1528143448083};\\\", \\\"{x:544,y:723,t:1528143448099};\\\", \\\"{x:559,y:728,t:1528143448115};\\\", \\\"{x:572,y:731,t:1528143448134};\\\", \\\"{x:585,y:734,t:1528143448150};\\\", \\\"{x:597,y:735,t:1528143448168};\\\", \\\"{x:604,y:736,t:1528143448185};\\\", \\\"{x:611,y:737,t:1528143448201};\\\", \\\"{x:624,y:739,t:1528143448218};\\\", \\\"{x:635,y:741,t:1528143448235};\\\", \\\"{x:648,y:744,t:1528143448251};\\\", \\\"{x:662,y:751,t:1528143448268};\\\", \\\"{x:673,y:757,t:1528143448286};\\\", \\\"{x:674,y:757,t:1528143448301};\\\", \\\"{x:675,y:757,t:1528143448318};\\\", \\\"{x:677,y:758,t:1528143448675};\\\", \\\"{x:681,y:760,t:1528143448686};\\\", \\\"{x:686,y:762,t:1528143448703};\\\", \\\"{x:691,y:763,t:1528143448719};\\\", \\\"{x:698,y:766,t:1528143448735};\\\", \\\"{x:713,y:771,t:1528143448752};\\\", \\\"{x:734,y:777,t:1528143448769};\\\", \\\"{x:756,y:783,t:1528143448786};\\\", \\\"{x:803,y:794,t:1528143448803};\\\", \\\"{x:822,y:800,t:1528143448819};\\\", \\\"{x:894,y:818,t:1528143448835};\\\", \\\"{x:946,y:831,t:1528143448852};\\\", \\\"{x:988,y:841,t:1528143448870};\\\", \\\"{x:1017,y:850,t:1528143448886};\\\", \\\"{x:1040,y:856,t:1528143448903};\\\", \\\"{x:1067,y:863,t:1528143448920};\\\", \\\"{x:1093,y:871,t:1528143448936};\\\", \\\"{x:1121,y:879,t:1528143448952};\\\", \\\"{x:1150,y:888,t:1528143448970};\\\", \\\"{x:1183,y:899,t:1528143448986};\\\", \\\"{x:1232,y:912,t:1528143449003};\\\", \\\"{x:1257,y:916,t:1528143449019};\\\", \\\"{x:1282,y:921,t:1528143449036};\\\", \\\"{x:1301,y:923,t:1528143449053};\\\", \\\"{x:1321,y:927,t:1528143449071};\\\", \\\"{x:1337,y:933,t:1528143449086};\\\", \\\"{x:1350,y:938,t:1528143449103};\\\", \\\"{x:1362,y:942,t:1528143449120};\\\", \\\"{x:1373,y:947,t:1528143449136};\\\", \\\"{x:1387,y:953,t:1528143449153};\\\", \\\"{x:1398,y:960,t:1528143449170};\\\", \\\"{x:1409,y:967,t:1528143449186};\\\", \\\"{x:1422,y:976,t:1528143449203};\\\", \\\"{x:1426,y:979,t:1528143449219};\\\", \\\"{x:1427,y:980,t:1528143449237};\\\", \\\"{x:1428,y:980,t:1528143449253};\\\", \\\"{x:1429,y:981,t:1528143449282};\\\", \\\"{x:1429,y:982,t:1528143449290};\\\", \\\"{x:1430,y:984,t:1528143449306};\\\", \\\"{x:1431,y:985,t:1528143449320};\\\", \\\"{x:1432,y:987,t:1528143449336};\\\", \\\"{x:1434,y:987,t:1528143449352};\\\", \\\"{x:1435,y:987,t:1528143449370};\\\", \\\"{x:1437,y:987,t:1528143449402};\\\", \\\"{x:1443,y:987,t:1528143449419};\\\", \\\"{x:1453,y:990,t:1528143449437};\\\", \\\"{x:1466,y:990,t:1528143449452};\\\", \\\"{x:1476,y:990,t:1528143449469};\\\", \\\"{x:1484,y:990,t:1528143449486};\\\", \\\"{x:1493,y:991,t:1528143449503};\\\", \\\"{x:1500,y:991,t:1528143449519};\\\", \\\"{x:1504,y:991,t:1528143449537};\\\", \\\"{x:1508,y:991,t:1528143449553};\\\", \\\"{x:1510,y:991,t:1528143449570};\\\", \\\"{x:1511,y:990,t:1528143449587};\\\", \\\"{x:1513,y:989,t:1528143449603};\\\", \\\"{x:1517,y:988,t:1528143449619};\\\", \\\"{x:1526,y:986,t:1528143449636};\\\", \\\"{x:1535,y:985,t:1528143449654};\\\", \\\"{x:1545,y:982,t:1528143449670};\\\", \\\"{x:1555,y:981,t:1528143449687};\\\", \\\"{x:1565,y:980,t:1528143449704};\\\", \\\"{x:1571,y:979,t:1528143449720};\\\", \\\"{x:1575,y:978,t:1528143449737};\\\", \\\"{x:1577,y:978,t:1528143449754};\\\", \\\"{x:1578,y:977,t:1528143449769};\\\", \\\"{x:1580,y:977,t:1528143449787};\\\", \\\"{x:1584,y:975,t:1528143449803};\\\", \\\"{x:1588,y:975,t:1528143449820};\\\", \\\"{x:1591,y:975,t:1528143449837};\\\", \\\"{x:1595,y:974,t:1528143449854};\\\", \\\"{x:1599,y:974,t:1528143449870};\\\", \\\"{x:1602,y:973,t:1528143449886};\\\", \\\"{x:1606,y:973,t:1528143449904};\\\", \\\"{x:1609,y:972,t:1528143449921};\\\", \\\"{x:1613,y:972,t:1528143449936};\\\", \\\"{x:1617,y:970,t:1528143449953};\\\", \\\"{x:1619,y:970,t:1528143449969};\\\", \\\"{x:1621,y:969,t:1528143449986};\\\", \\\"{x:1622,y:968,t:1528143450004};\\\", \\\"{x:1623,y:968,t:1528143450204};\\\", \\\"{x:1623,y:965,t:1528143450221};\\\", \\\"{x:1623,y:964,t:1528143450237};\\\", \\\"{x:1622,y:963,t:1528143450254};\\\", \\\"{x:1620,y:961,t:1528143450271};\\\", \\\"{x:1619,y:961,t:1528143450436};\\\", \\\"{x:1617,y:959,t:1528143450444};\\\", \\\"{x:1616,y:957,t:1528143450454};\\\", \\\"{x:1610,y:953,t:1528143450471};\\\", \\\"{x:1604,y:949,t:1528143450488};\\\", \\\"{x:1599,y:943,t:1528143450504};\\\", \\\"{x:1592,y:931,t:1528143450521};\\\", \\\"{x:1584,y:918,t:1528143450538};\\\", \\\"{x:1579,y:905,t:1528143450554};\\\", \\\"{x:1574,y:887,t:1528143450572};\\\", \\\"{x:1571,y:883,t:1528143450587};\\\", \\\"{x:1569,y:878,t:1528143450604};\\\", \\\"{x:1568,y:876,t:1528143450621};\\\", \\\"{x:1567,y:873,t:1528143450638};\\\", \\\"{x:1566,y:871,t:1528143450654};\\\", \\\"{x:1564,y:870,t:1528143450671};\\\", \\\"{x:1563,y:869,t:1528143450688};\\\", \\\"{x:1560,y:866,t:1528143450704};\\\", \\\"{x:1558,y:864,t:1528143450721};\\\", \\\"{x:1556,y:862,t:1528143450738};\\\", \\\"{x:1548,y:854,t:1528143450755};\\\", \\\"{x:1537,y:840,t:1528143450771};\\\", \\\"{x:1527,y:826,t:1528143450788};\\\", \\\"{x:1514,y:809,t:1528143450806};\\\", \\\"{x:1500,y:792,t:1528143450821};\\\", \\\"{x:1484,y:768,t:1528143450839};\\\", \\\"{x:1474,y:748,t:1528143450855};\\\", \\\"{x:1462,y:725,t:1528143450871};\\\", \\\"{x:1453,y:700,t:1528143450888};\\\", \\\"{x:1447,y:681,t:1528143450905};\\\", \\\"{x:1444,y:671,t:1528143450921};\\\", \\\"{x:1440,y:663,t:1528143450938};\\\", \\\"{x:1437,y:654,t:1528143450955};\\\", \\\"{x:1437,y:653,t:1528143450979};\\\", \\\"{x:1437,y:650,t:1528143450988};\\\", \\\"{x:1437,y:647,t:1528143451005};\\\", \\\"{x:1436,y:644,t:1528143451021};\\\", \\\"{x:1436,y:641,t:1528143451038};\\\", \\\"{x:1435,y:636,t:1528143451055};\\\", \\\"{x:1433,y:631,t:1528143451071};\\\", \\\"{x:1430,y:623,t:1528143451088};\\\", \\\"{x:1423,y:613,t:1528143451105};\\\", \\\"{x:1418,y:606,t:1528143451121};\\\", \\\"{x:1416,y:603,t:1528143451138};\\\", \\\"{x:1412,y:594,t:1528143451155};\\\", \\\"{x:1409,y:587,t:1528143451172};\\\", \\\"{x:1405,y:581,t:1528143451189};\\\", \\\"{x:1404,y:579,t:1528143451205};\\\", \\\"{x:1401,y:575,t:1528143451222};\\\", \\\"{x:1400,y:572,t:1528143451238};\\\", \\\"{x:1399,y:571,t:1528143451255};\\\", \\\"{x:1398,y:568,t:1528143451272};\\\", \\\"{x:1398,y:567,t:1528143451288};\\\", \\\"{x:1398,y:564,t:1528143451305};\\\", \\\"{x:1398,y:563,t:1528143451322};\\\", \\\"{x:1398,y:561,t:1528143451338};\\\", \\\"{x:1398,y:559,t:1528143451355};\\\", \\\"{x:1398,y:558,t:1528143451379};\\\", \\\"{x:1390,y:559,t:1528143451947};\\\", \\\"{x:1356,y:565,t:1528143451955};\\\", \\\"{x:1227,y:578,t:1528143451972};\\\", \\\"{x:1086,y:580,t:1528143451989};\\\", \\\"{x:911,y:582,t:1528143452008};\\\", \\\"{x:770,y:586,t:1528143452021};\\\", \\\"{x:674,y:584,t:1528143452039};\\\", \\\"{x:634,y:577,t:1528143452055};\\\", \\\"{x:613,y:574,t:1528143452072};\\\", \\\"{x:600,y:573,t:1528143452088};\\\", \\\"{x:596,y:573,t:1528143452104};\\\", \\\"{x:591,y:573,t:1528143452121};\\\", \\\"{x:585,y:573,t:1528143452137};\\\", \\\"{x:578,y:574,t:1528143452154};\\\", \\\"{x:571,y:575,t:1528143452172};\\\", \\\"{x:561,y:575,t:1528143452188};\\\", \\\"{x:548,y:577,t:1528143452205};\\\", \\\"{x:534,y:577,t:1528143452222};\\\", \\\"{x:519,y:577,t:1528143452238};\\\", \\\"{x:497,y:577,t:1528143452255};\\\", \\\"{x:474,y:577,t:1528143452271};\\\", \\\"{x:450,y:577,t:1528143452288};\\\", \\\"{x:438,y:577,t:1528143452305};\\\", \\\"{x:426,y:577,t:1528143452321};\\\", \\\"{x:418,y:577,t:1528143452339};\\\", \\\"{x:414,y:577,t:1528143452355};\\\", \\\"{x:413,y:577,t:1528143452371};\\\", \\\"{x:413,y:576,t:1528143452427};\\\", \\\"{x:414,y:576,t:1528143452438};\\\", \\\"{x:425,y:572,t:1528143452457};\\\", \\\"{x:447,y:571,t:1528143452471};\\\", \\\"{x:477,y:571,t:1528143452488};\\\", \\\"{x:511,y:571,t:1528143452506};\\\", \\\"{x:540,y:571,t:1528143452522};\\\", \\\"{x:574,y:571,t:1528143452538};\\\", \\\"{x:589,y:571,t:1528143452556};\\\", \\\"{x:596,y:568,t:1528143452571};\\\", \\\"{x:597,y:567,t:1528143452588};\\\", \\\"{x:599,y:567,t:1528143452605};\\\", \\\"{x:600,y:566,t:1528143452626};\\\", \\\"{x:602,y:564,t:1528143452650};\\\", \\\"{x:603,y:562,t:1528143452667};\\\", \\\"{x:604,y:561,t:1528143452683};\\\", \\\"{x:606,y:560,t:1528143452691};\\\", \\\"{x:607,y:558,t:1528143452706};\\\", \\\"{x:610,y:557,t:1528143452721};\\\", \\\"{x:609,y:557,t:1528143453090};\\\", \\\"{x:607,y:559,t:1528143453106};\\\", \\\"{x:595,y:572,t:1528143453123};\\\", \\\"{x:586,y:585,t:1528143453139};\\\", \\\"{x:572,y:601,t:1528143453155};\\\", \\\"{x:561,y:620,t:1528143453173};\\\", \\\"{x:550,y:638,t:1528143453188};\\\", \\\"{x:539,y:655,t:1528143453206};\\\", \\\"{x:529,y:669,t:1528143453223};\\\", \\\"{x:524,y:675,t:1528143453238};\\\", \\\"{x:519,y:682,t:1528143453255};\\\", \\\"{x:515,y:689,t:1528143453272};\\\", \\\"{x:510,y:697,t:1528143453288};\\\", \\\"{x:507,y:701,t:1528143453306};\\\", \\\"{x:505,y:706,t:1528143453322};\\\", \\\"{x:502,y:708,t:1528143453338};\\\", \\\"{x:501,y:710,t:1528143453355};\\\" ] }, { \\\"rt\\\": 13245, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 9, \\\"time_elapsed\\\": 552905, \\\"internal_node_id\\\": \\\"0.0-5.0-4.0\\\", \\\"subject\\\": \\\"06217\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"zulu\\\", \\\"condition\\\": \\\"211\\\", \\\"scenario\\\": \\\"acme\\\", \\\"question\\\": \\\"midpoint\\\", \\\"q\\\": 5, \\\"clicks\\\": 1, \\\"explicit\\\": 2, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XInside-YFull\\\", \\\"correct\\\": 1, \\\"orth_correct\\\": 0, \\\"answer\\\": [ \\\"O\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"X \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"U \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-I -O -O \\\", \\\"block\\\": \\\"triangular_scaffolded\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:502,y:710,t:1528143461142};\\\", \\\"{x:514,y:708,t:1528143461163};\\\", \\\"{x:516,y:707,t:1528143461171};\\\", \\\"{x:518,y:706,t:1528143461188};\\\", \\\"{x:522,y:706,t:1528143461205};\\\", \\\"{x:543,y:709,t:1528143461222};\\\", \\\"{x:572,y:714,t:1528143461238};\\\", \\\"{x:597,y:715,t:1528143461254};\\\", \\\"{x:623,y:718,t:1528143461272};\\\", \\\"{x:638,y:719,t:1528143461287};\\\", \\\"{x:642,y:719,t:1528143461305};\\\", \\\"{x:646,y:720,t:1528143461322};\\\", \\\"{x:650,y:720,t:1528143461337};\\\", \\\"{x:656,y:720,t:1528143461355};\\\", \\\"{x:676,y:720,t:1528143461372};\\\", \\\"{x:685,y:720,t:1528143461388};\\\", \\\"{x:722,y:720,t:1528143461405};\\\", \\\"{x:775,y:720,t:1528143461422};\\\", \\\"{x:848,y:720,t:1528143461438};\\\", \\\"{x:923,y:720,t:1528143461455};\\\", \\\"{x:1003,y:720,t:1528143461472};\\\", \\\"{x:1084,y:720,t:1528143461489};\\\", \\\"{x:1159,y:720,t:1528143461504};\\\", \\\"{x:1226,y:720,t:1528143461522};\\\", \\\"{x:1276,y:720,t:1528143461539};\\\", \\\"{x:1321,y:720,t:1528143461555};\\\", \\\"{x:1352,y:720,t:1528143461572};\\\", \\\"{x:1393,y:720,t:1528143461589};\\\", \\\"{x:1418,y:720,t:1528143461605};\\\", \\\"{x:1442,y:720,t:1528143461622};\\\", \\\"{x:1460,y:720,t:1528143461639};\\\", \\\"{x:1472,y:720,t:1528143461655};\\\", \\\"{x:1477,y:720,t:1528143461672};\\\", \\\"{x:1473,y:720,t:1528143462157};\\\", \\\"{x:1463,y:715,t:1528143462172};\\\", \\\"{x:1425,y:681,t:1528143462189};\\\", \\\"{x:1398,y:641,t:1528143462206};\\\", \\\"{x:1383,y:609,t:1528143462222};\\\", \\\"{x:1369,y:578,t:1528143462240};\\\", \\\"{x:1358,y:556,t:1528143462257};\\\", \\\"{x:1352,y:542,t:1528143462272};\\\", \\\"{x:1344,y:532,t:1528143462290};\\\", \\\"{x:1340,y:528,t:1528143462306};\\\", \\\"{x:1336,y:526,t:1528143462323};\\\", \\\"{x:1335,y:526,t:1528143462477};\\\", \\\"{x:1335,y:524,t:1528143462490};\\\", \\\"{x:1334,y:519,t:1528143462506};\\\", \\\"{x:1328,y:512,t:1528143462523};\\\", \\\"{x:1325,y:507,t:1528143462540};\\\", \\\"{x:1323,y:499,t:1528143462556};\\\", \\\"{x:1323,y:489,t:1528143462573};\\\", \\\"{x:1321,y:485,t:1528143462589};\\\", \\\"{x:1320,y:483,t:1528143462606};\\\", \\\"{x:1320,y:482,t:1528143462623};\\\", \\\"{x:1320,y:481,t:1528143462749};\\\", \\\"{x:1319,y:481,t:1528143462765};\\\", \\\"{x:1317,y:481,t:1528143462781};\\\", \\\"{x:1315,y:481,t:1528143462813};\\\", \\\"{x:1314,y:481,t:1528143462823};\\\", \\\"{x:1313,y:482,t:1528143463149};\\\", \\\"{x:1312,y:484,t:1528143463189};\\\", \\\"{x:1311,y:484,t:1528143463237};\\\", \\\"{x:1310,y:485,t:1528143463253};\\\", \\\"{x:1310,y:486,t:1528143463269};\\\", \\\"{x:1310,y:490,t:1528143463276};\\\", \\\"{x:1308,y:493,t:1528143463292};\\\", \\\"{x:1308,y:496,t:1528143463307};\\\", \\\"{x:1308,y:500,t:1528143463324};\\\", \\\"{x:1308,y:502,t:1528143463340};\\\", \\\"{x:1308,y:505,t:1528143463357};\\\", \\\"{x:1308,y:509,t:1528143463373};\\\", \\\"{x:1308,y:516,t:1528143463391};\\\", \\\"{x:1308,y:524,t:1528143463407};\\\", \\\"{x:1308,y:532,t:1528143463424};\\\", \\\"{x:1308,y:537,t:1528143463440};\\\", \\\"{x:1308,y:541,t:1528143463457};\\\", \\\"{x:1308,y:545,t:1528143463473};\\\", \\\"{x:1308,y:550,t:1528143463490};\\\", \\\"{x:1308,y:555,t:1528143463508};\\\", \\\"{x:1308,y:565,t:1528143463523};\\\", \\\"{x:1308,y:580,t:1528143463541};\\\", \\\"{x:1308,y:594,t:1528143463557};\\\", \\\"{x:1309,y:601,t:1528143463573};\\\", \\\"{x:1310,y:608,t:1528143463590};\\\", \\\"{x:1310,y:612,t:1528143463607};\\\", \\\"{x:1310,y:617,t:1528143463624};\\\", \\\"{x:1310,y:620,t:1528143463640};\\\", \\\"{x:1311,y:621,t:1528143463657};\\\", \\\"{x:1311,y:622,t:1528143463673};\\\", \\\"{x:1312,y:623,t:1528143463773};\\\", \\\"{x:1312,y:625,t:1528143463793};\\\", \\\"{x:1312,y:626,t:1528143463807};\\\", \\\"{x:1312,y:628,t:1528143463823};\\\", \\\"{x:1313,y:629,t:1528143463840};\\\", \\\"{x:1313,y:632,t:1528143463857};\\\", \\\"{x:1313,y:634,t:1528143463874};\\\", \\\"{x:1313,y:635,t:1528143463890};\\\", \\\"{x:1313,y:636,t:1528143464591};\\\", \\\"{x:1303,y:637,t:1528143464607};\\\", \\\"{x:1284,y:637,t:1528143464624};\\\", \\\"{x:1259,y:639,t:1528143464642};\\\", \\\"{x:1231,y:641,t:1528143464657};\\\", \\\"{x:1186,y:645,t:1528143464674};\\\", \\\"{x:1130,y:647,t:1528143464691};\\\", \\\"{x:1068,y:647,t:1528143464707};\\\", \\\"{x:1018,y:647,t:1528143464724};\\\", \\\"{x:971,y:647,t:1528143464741};\\\", \\\"{x:951,y:647,t:1528143464758};\\\", \\\"{x:932,y:647,t:1528143464774};\\\", \\\"{x:914,y:647,t:1528143464791};\\\", \\\"{x:896,y:647,t:1528143464808};\\\", \\\"{x:877,y:647,t:1528143464824};\\\", \\\"{x:862,y:647,t:1528143464842};\\\", \\\"{x:848,y:647,t:1528143464858};\\\", \\\"{x:834,y:647,t:1528143464874};\\\", \\\"{x:829,y:647,t:1528143464891};\\\", \\\"{x:827,y:647,t:1528143464908};\\\", \\\"{x:827,y:646,t:1528143464940};\\\", \\\"{x:831,y:644,t:1528143464957};\\\", \\\"{x:848,y:638,t:1528143464974};\\\", \\\"{x:874,y:631,t:1528143464991};\\\", \\\"{x:909,y:626,t:1528143465008};\\\", \\\"{x:942,y:620,t:1528143465023};\\\", \\\"{x:966,y:617,t:1528143465041};\\\", \\\"{x:981,y:615,t:1528143465058};\\\", \\\"{x:990,y:613,t:1528143465075};\\\", \\\"{x:994,y:612,t:1528143465092};\\\", \\\"{x:995,y:611,t:1528143465109};\\\", \\\"{x:995,y:608,t:1528143465148};\\\", \\\"{x:993,y:607,t:1528143465159};\\\", \\\"{x:980,y:603,t:1528143465175};\\\", \\\"{x:948,y:596,t:1528143465192};\\\", \\\"{x:890,y:587,t:1528143465211};\\\", \\\"{x:842,y:580,t:1528143465225};\\\", \\\"{x:814,y:575,t:1528143465242};\\\", \\\"{x:806,y:573,t:1528143465258};\\\", \\\"{x:806,y:571,t:1528143465276};\\\", \\\"{x:810,y:566,t:1528143465292};\\\", \\\"{x:814,y:561,t:1528143465307};\\\", \\\"{x:817,y:558,t:1528143465325};\\\", \\\"{x:818,y:557,t:1528143465343};\\\", \\\"{x:819,y:555,t:1528143465358};\\\", \\\"{x:822,y:552,t:1528143465375};\\\", \\\"{x:822,y:550,t:1528143465393};\\\", \\\"{x:824,y:548,t:1528143465409};\\\", \\\"{x:825,y:547,t:1528143465425};\\\", \\\"{x:827,y:545,t:1528143465443};\\\", \\\"{x:828,y:545,t:1528143465525};\\\", \\\"{x:829,y:543,t:1528143465542};\\\", \\\"{x:828,y:543,t:1528143466757};\\\", \\\"{x:826,y:545,t:1528143466767};\\\", \\\"{x:824,y:553,t:1528143466777};\\\", \\\"{x:814,y:563,t:1528143466793};\\\", \\\"{x:797,y:573,t:1528143466809};\\\", \\\"{x:775,y:582,t:1528143466825};\\\", \\\"{x:749,y:594,t:1528143466843};\\\", \\\"{x:716,y:607,t:1528143466861};\\\", \\\"{x:694,y:615,t:1528143466876};\\\", \\\"{x:675,y:624,t:1528143466893};\\\", \\\"{x:662,y:630,t:1528143466910};\\\", \\\"{x:650,y:637,t:1528143466928};\\\", \\\"{x:637,y:645,t:1528143466943};\\\", \\\"{x:626,y:652,t:1528143466960};\\\", \\\"{x:620,y:656,t:1528143466977};\\\", \\\"{x:614,y:658,t:1528143466994};\\\", \\\"{x:610,y:659,t:1528143467010};\\\", \\\"{x:602,y:661,t:1528143467028};\\\", \\\"{x:580,y:667,t:1528143467045};\\\", \\\"{x:573,y:669,t:1528143467060};\\\", \\\"{x:566,y:672,t:1528143467076};\\\", \\\"{x:561,y:674,t:1528143467093};\\\", \\\"{x:555,y:678,t:1528143467110};\\\", \\\"{x:553,y:680,t:1528143467128};\\\", \\\"{x:546,y:684,t:1528143467143};\\\", \\\"{x:543,y:685,t:1528143467160};\\\", \\\"{x:539,y:688,t:1528143467177};\\\", \\\"{x:537,y:690,t:1528143467193};\\\", \\\"{x:533,y:692,t:1528143467210};\\\", \\\"{x:526,y:697,t:1528143467228};\\\", \\\"{x:520,y:701,t:1528143467243};\\\", \\\"{x:509,y:706,t:1528143467260};\\\", \\\"{x:507,y:708,t:1528143467277};\\\", \\\"{x:505,y:709,t:1528143467293};\\\", \\\"{x:504,y:712,t:1528143467310};\\\", \\\"{x:503,y:714,t:1528143467327};\\\", \\\"{x:502,y:717,t:1528143467345};\\\", \\\"{x:501,y:718,t:1528143467360};\\\", \\\"{x:501,y:720,t:1528143467405};\\\", \\\"{x:500,y:722,t:1528143467421};\\\", \\\"{x:500,y:724,t:1528143467437};\\\", \\\"{x:499,y:725,t:1528143467444};\\\", \\\"{x:499,y:727,t:1528143467468};\\\", \\\"{x:498,y:727,t:1528143467485};\\\", \\\"{x:498,y:728,t:1528143467501};\\\", \\\"{x:498,y:729,t:1528143468117};\\\" ] }, { \\\"rt\\\": 21919, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 10, \\\"time_elapsed\\\": 576186, \\\"internal_node_id\\\": \\\"0.0-6.0-0.0\\\", \\\"subject\\\": \\\"06217\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"zulu\\\", \\\"condition\\\": \\\"211\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"duration\\\", \\\"q\\\": 6, \\\"clicks\\\": 2, \\\"explicit\\\": 2, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XInside-YFull\\\", \\\"correct\\\": 1, \\\"orth_correct\\\": 1, \\\"answer\\\": [ \\\"E\\\", \\\"G\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-10 AM-09 AM-11 AM-E -G \\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:498,y:731,t:1528143471069};\\\", \\\"{x:508,y:738,t:1528143471079};\\\", \\\"{x:536,y:757,t:1528143471097};\\\", \\\"{x:571,y:783,t:1528143471113};\\\", \\\"{x:625,y:812,t:1528143471129};\\\", \\\"{x:690,y:849,t:1528143471145};\\\", \\\"{x:762,y:882,t:1528143471162};\\\", \\\"{x:878,y:925,t:1528143471179};\\\", \\\"{x:930,y:946,t:1528143471197};\\\", \\\"{x:963,y:965,t:1528143471213};\\\", \\\"{x:983,y:979,t:1528143471230};\\\", \\\"{x:1002,y:993,t:1528143471247};\\\", \\\"{x:1010,y:997,t:1528143471263};\\\", \\\"{x:1011,y:998,t:1528143471789};\\\", \\\"{x:1012,y:999,t:1528143472317};\\\", \\\"{x:1012,y:1000,t:1528143472653};\\\", \\\"{x:1012,y:1002,t:1528143472669};\\\", \\\"{x:1012,y:1003,t:1528143472682};\\\", \\\"{x:1012,y:1005,t:1528143472699};\\\", \\\"{x:1012,y:1007,t:1528143472717};\\\", \\\"{x:1012,y:1008,t:1528143472749};\\\", \\\"{x:1012,y:1010,t:1528143472765};\\\", \\\"{x:1012,y:1011,t:1528143472813};\\\", \\\"{x:1013,y:1012,t:1528143472821};\\\", \\\"{x:1013,y:1013,t:1528143472845};\\\", \\\"{x:1015,y:1015,t:1528143472853};\\\", \\\"{x:1017,y:1016,t:1528143472868};\\\", \\\"{x:1018,y:1017,t:1528143472883};\\\", \\\"{x:1023,y:1018,t:1528143472900};\\\", \\\"{x:1043,y:1022,t:1528143472917};\\\", \\\"{x:1056,y:1023,t:1528143472933};\\\", \\\"{x:1076,y:1026,t:1528143472949};\\\", \\\"{x:1096,y:1028,t:1528143472966};\\\", \\\"{x:1116,y:1029,t:1528143472983};\\\", \\\"{x:1138,y:1029,t:1528143473000};\\\", \\\"{x:1158,y:1029,t:1528143473016};\\\", \\\"{x:1173,y:1029,t:1528143473033};\\\", \\\"{x:1183,y:1029,t:1528143473050};\\\", \\\"{x:1188,y:1029,t:1528143473067};\\\", \\\"{x:1194,y:1027,t:1528143473083};\\\", \\\"{x:1200,y:1024,t:1528143473100};\\\", \\\"{x:1205,y:1020,t:1528143473117};\\\", \\\"{x:1208,y:1016,t:1528143473133};\\\", \\\"{x:1213,y:1011,t:1528143473150};\\\", \\\"{x:1216,y:1007,t:1528143473167};\\\", \\\"{x:1220,y:1003,t:1528143473183};\\\", \\\"{x:1220,y:999,t:1528143473200};\\\", \\\"{x:1222,y:996,t:1528143473217};\\\", \\\"{x:1222,y:993,t:1528143473232};\\\", \\\"{x:1224,y:990,t:1528143473250};\\\", \\\"{x:1224,y:987,t:1528143473267};\\\", \\\"{x:1225,y:984,t:1528143473284};\\\", \\\"{x:1225,y:983,t:1528143473300};\\\", \\\"{x:1223,y:979,t:1528143473317};\\\", \\\"{x:1222,y:979,t:1528143473333};\\\", \\\"{x:1220,y:976,t:1528143473350};\\\", \\\"{x:1220,y:974,t:1528143473367};\\\", \\\"{x:1219,y:971,t:1528143473384};\\\", \\\"{x:1218,y:969,t:1528143473400};\\\", \\\"{x:1216,y:969,t:1528143473420};\\\", \\\"{x:1215,y:969,t:1528143473493};\\\", \\\"{x:1214,y:969,t:1528143473549};\\\", \\\"{x:1213,y:969,t:1528143474229};\\\", \\\"{x:1212,y:969,t:1528143474245};\\\", \\\"{x:1211,y:969,t:1528143474261};\\\", \\\"{x:1212,y:969,t:1528143474573};\\\", \\\"{x:1213,y:969,t:1528143474585};\\\", \\\"{x:1214,y:969,t:1528143474621};\\\", \\\"{x:1215,y:969,t:1528143474635};\\\", \\\"{x:1216,y:968,t:1528143474654};\\\", \\\"{x:1218,y:967,t:1528143474709};\\\", \\\"{x:1221,y:967,t:1528143474719};\\\", \\\"{x:1227,y:966,t:1528143474735};\\\", \\\"{x:1229,y:966,t:1528143474752};\\\", \\\"{x:1236,y:966,t:1528143474769};\\\", \\\"{x:1239,y:966,t:1528143474785};\\\", \\\"{x:1240,y:966,t:1528143474802};\\\", \\\"{x:1241,y:966,t:1528143474819};\\\", \\\"{x:1242,y:965,t:1528143474835};\\\", \\\"{x:1243,y:965,t:1528143474853};\\\", \\\"{x:1244,y:965,t:1528143474869};\\\", \\\"{x:1245,y:965,t:1528143474885};\\\", \\\"{x:1247,y:965,t:1528143474908};\\\", \\\"{x:1250,y:965,t:1528143474919};\\\", \\\"{x:1255,y:965,t:1528143474935};\\\", \\\"{x:1265,y:965,t:1528143474952};\\\", \\\"{x:1272,y:965,t:1528143474969};\\\", \\\"{x:1279,y:965,t:1528143474986};\\\", \\\"{x:1283,y:965,t:1528143475002};\\\", \\\"{x:1284,y:965,t:1528143475018};\\\", \\\"{x:1285,y:965,t:1528143475124};\\\", \\\"{x:1287,y:965,t:1528143475136};\\\", \\\"{x:1289,y:963,t:1528143475151};\\\", \\\"{x:1290,y:963,t:1528143475168};\\\", \\\"{x:1288,y:963,t:1528143475301};\\\", \\\"{x:1285,y:963,t:1528143475308};\\\", \\\"{x:1284,y:964,t:1528143475319};\\\", \\\"{x:1279,y:965,t:1528143475335};\\\", \\\"{x:1276,y:967,t:1528143475353};\\\", \\\"{x:1266,y:968,t:1528143475369};\\\", \\\"{x:1251,y:968,t:1528143475386};\\\", \\\"{x:1228,y:968,t:1528143475403};\\\", \\\"{x:1196,y:968,t:1528143475420};\\\", \\\"{x:1156,y:968,t:1528143475436};\\\", \\\"{x:1106,y:968,t:1528143475453};\\\", \\\"{x:1090,y:968,t:1528143475469};\\\", \\\"{x:1084,y:967,t:1528143475485};\\\", \\\"{x:1084,y:966,t:1528143475518};\\\", \\\"{x:1085,y:966,t:1528143475644};\\\", \\\"{x:1086,y:966,t:1528143475660};\\\", \\\"{x:1086,y:965,t:1528143475670};\\\", \\\"{x:1088,y:965,t:1528143475686};\\\", \\\"{x:1089,y:964,t:1528143475702};\\\", \\\"{x:1089,y:963,t:1528143475724};\\\", \\\"{x:1091,y:963,t:1528143475736};\\\", \\\"{x:1095,y:963,t:1528143475753};\\\", \\\"{x:1102,y:963,t:1528143475770};\\\", \\\"{x:1111,y:963,t:1528143475787};\\\", \\\"{x:1119,y:963,t:1528143475803};\\\", \\\"{x:1123,y:963,t:1528143475820};\\\", \\\"{x:1127,y:963,t:1528143475837};\\\", \\\"{x:1128,y:963,t:1528143475949};\\\", \\\"{x:1130,y:963,t:1528143475957};\\\", \\\"{x:1133,y:963,t:1528143475970};\\\", \\\"{x:1139,y:963,t:1528143475987};\\\", \\\"{x:1145,y:963,t:1528143476003};\\\", \\\"{x:1148,y:962,t:1528143476020};\\\", \\\"{x:1149,y:961,t:1528143476037};\\\", \\\"{x:1148,y:961,t:1528143476157};\\\", \\\"{x:1147,y:961,t:1528143476170};\\\", \\\"{x:1146,y:961,t:1528143476187};\\\", \\\"{x:1145,y:962,t:1528143476220};\\\", \\\"{x:1147,y:962,t:1528143476318};\\\", \\\"{x:1149,y:963,t:1528143476333};\\\", \\\"{x:1153,y:963,t:1528143476341};\\\", \\\"{x:1156,y:963,t:1528143476354};\\\", \\\"{x:1156,y:964,t:1528143476371};\\\", \\\"{x:1156,y:965,t:1528143476388};\\\", \\\"{x:1158,y:967,t:1528143476404};\\\", \\\"{x:1158,y:968,t:1528143476445};\\\", \\\"{x:1153,y:968,t:1528143476453};\\\", \\\"{x:1150,y:970,t:1528143476471};\\\", \\\"{x:1149,y:970,t:1528143476492};\\\", \\\"{x:1150,y:970,t:1528143476556};\\\", \\\"{x:1151,y:970,t:1528143476571};\\\", \\\"{x:1155,y:968,t:1528143476589};\\\", \\\"{x:1158,y:966,t:1528143476604};\\\", \\\"{x:1159,y:966,t:1528143476620};\\\", \\\"{x:1160,y:966,t:1528143476637};\\\", \\\"{x:1161,y:965,t:1528143476654};\\\", \\\"{x:1162,y:965,t:1528143476671};\\\", \\\"{x:1163,y:964,t:1528143476688};\\\", \\\"{x:1164,y:964,t:1528143476703};\\\", \\\"{x:1166,y:964,t:1528143476720};\\\", \\\"{x:1173,y:964,t:1528143476738};\\\", \\\"{x:1182,y:964,t:1528143476753};\\\", \\\"{x:1186,y:964,t:1528143476770};\\\", \\\"{x:1190,y:964,t:1528143476788};\\\", \\\"{x:1192,y:963,t:1528143476804};\\\", \\\"{x:1193,y:963,t:1528143476828};\\\", \\\"{x:1194,y:962,t:1528143476845};\\\", \\\"{x:1195,y:962,t:1528143476876};\\\", \\\"{x:1197,y:962,t:1528143476900};\\\", \\\"{x:1198,y:962,t:1528143476917};\\\", \\\"{x:1199,y:962,t:1528143476932};\\\", \\\"{x:1201,y:962,t:1528143476941};\\\", \\\"{x:1204,y:962,t:1528143476955};\\\", \\\"{x:1208,y:962,t:1528143476971};\\\", \\\"{x:1209,y:962,t:1528143476988};\\\", \\\"{x:1210,y:962,t:1528143477005};\\\", \\\"{x:1211,y:962,t:1528143477149};\\\", \\\"{x:1212,y:962,t:1528143477277};\\\", \\\"{x:1215,y:962,t:1528143477288};\\\", \\\"{x:1224,y:964,t:1528143477305};\\\", \\\"{x:1238,y:966,t:1528143477322};\\\", \\\"{x:1249,y:968,t:1528143477339};\\\", \\\"{x:1259,y:970,t:1528143477355};\\\", \\\"{x:1263,y:971,t:1528143477373};\\\", \\\"{x:1265,y:971,t:1528143477429};\\\", \\\"{x:1266,y:971,t:1528143477439};\\\", \\\"{x:1269,y:971,t:1528143477455};\\\", \\\"{x:1272,y:971,t:1528143477472};\\\", \\\"{x:1273,y:971,t:1528143477644};\\\", \\\"{x:1273,y:970,t:1528143477676};\\\", \\\"{x:1274,y:969,t:1528143477688};\\\", \\\"{x:1275,y:969,t:1528143477705};\\\", \\\"{x:1275,y:968,t:1528143477748};\\\", \\\"{x:1275,y:967,t:1528143477797};\\\", \\\"{x:1276,y:967,t:1528143477812};\\\", \\\"{x:1276,y:966,t:1528143477870};\\\", \\\"{x:1277,y:966,t:1528143478126};\\\", \\\"{x:1278,y:966,t:1528143478139};\\\", \\\"{x:1282,y:966,t:1528143478156};\\\", \\\"{x:1294,y:966,t:1528143478173};\\\", \\\"{x:1303,y:966,t:1528143478190};\\\", \\\"{x:1310,y:966,t:1528143478206};\\\", \\\"{x:1314,y:966,t:1528143478223};\\\", \\\"{x:1315,y:965,t:1528143478373};\\\", \\\"{x:1316,y:965,t:1528143478413};\\\", \\\"{x:1317,y:965,t:1528143478501};\\\", \\\"{x:1317,y:964,t:1528143478509};\\\", \\\"{x:1319,y:963,t:1528143478523};\\\", \\\"{x:1325,y:961,t:1528143478541};\\\", \\\"{x:1329,y:961,t:1528143478557};\\\", \\\"{x:1330,y:961,t:1528143478573};\\\", \\\"{x:1331,y:961,t:1528143478853};\\\", \\\"{x:1334,y:961,t:1528143478861};\\\", \\\"{x:1338,y:961,t:1528143478874};\\\", \\\"{x:1344,y:961,t:1528143478890};\\\", \\\"{x:1351,y:961,t:1528143478908};\\\", \\\"{x:1359,y:961,t:1528143478924};\\\", \\\"{x:1361,y:961,t:1528143478941};\\\", \\\"{x:1362,y:961,t:1528143478957};\\\", \\\"{x:1363,y:961,t:1528143479045};\\\", \\\"{x:1366,y:961,t:1528143479057};\\\", \\\"{x:1371,y:961,t:1528143479073};\\\", \\\"{x:1373,y:962,t:1528143479090};\\\", \\\"{x:1375,y:962,t:1528143479260};\\\", \\\"{x:1381,y:964,t:1528143479274};\\\", \\\"{x:1396,y:965,t:1528143479291};\\\", \\\"{x:1411,y:966,t:1528143479308};\\\", \\\"{x:1412,y:966,t:1528143479332};\\\", \\\"{x:1413,y:966,t:1528143479725};\\\", \\\"{x:1416,y:966,t:1528143479741};\\\", \\\"{x:1417,y:966,t:1528143479758};\\\", \\\"{x:1432,y:966,t:1528143479775};\\\", \\\"{x:1445,y:966,t:1528143479792};\\\", \\\"{x:1459,y:966,t:1528143479808};\\\", \\\"{x:1464,y:966,t:1528143479825};\\\", \\\"{x:1467,y:966,t:1528143479925};\\\", \\\"{x:1469,y:966,t:1528143479942};\\\", \\\"{x:1470,y:966,t:1528143479959};\\\", \\\"{x:1473,y:966,t:1528143479975};\\\", \\\"{x:1475,y:966,t:1528143479992};\\\", \\\"{x:1476,y:966,t:1528143480085};\\\", \\\"{x:1477,y:966,t:1528143480108};\\\", \\\"{x:1478,y:966,t:1528143480180};\\\", \\\"{x:1478,y:957,t:1528143481789};\\\", \\\"{x:1468,y:931,t:1528143481796};\\\", \\\"{x:1454,y:902,t:1528143481811};\\\", \\\"{x:1411,y:833,t:1528143481827};\\\", \\\"{x:1353,y:769,t:1528143481844};\\\", \\\"{x:1288,y:702,t:1528143481861};\\\", \\\"{x:1257,y:670,t:1528143481878};\\\", \\\"{x:1237,y:647,t:1528143481894};\\\", \\\"{x:1217,y:624,t:1528143481911};\\\", \\\"{x:1199,y:600,t:1528143481927};\\\", \\\"{x:1176,y:570,t:1528143481944};\\\", \\\"{x:1160,y:552,t:1528143481961};\\\", \\\"{x:1147,y:542,t:1528143481978};\\\", \\\"{x:1128,y:532,t:1528143481994};\\\", \\\"{x:1101,y:524,t:1528143482011};\\\", \\\"{x:1004,y:510,t:1528143482028};\\\", \\\"{x:954,y:508,t:1528143482044};\\\", \\\"{x:763,y:508,t:1528143482062};\\\", \\\"{x:649,y:508,t:1528143482080};\\\", \\\"{x:572,y:508,t:1528143482093};\\\", \\\"{x:555,y:508,t:1528143482105};\\\", \\\"{x:530,y:508,t:1528143482121};\\\", \\\"{x:516,y:509,t:1528143482138};\\\", \\\"{x:512,y:510,t:1528143482155};\\\", \\\"{x:511,y:510,t:1528143482171};\\\", \\\"{x:509,y:511,t:1528143482188};\\\", \\\"{x:495,y:513,t:1528143482206};\\\", \\\"{x:469,y:519,t:1528143482223};\\\", \\\"{x:413,y:527,t:1528143482240};\\\", \\\"{x:363,y:533,t:1528143482255};\\\", \\\"{x:315,y:539,t:1528143482273};\\\", \\\"{x:273,y:544,t:1528143482288};\\\", \\\"{x:243,y:548,t:1528143482307};\\\", \\\"{x:221,y:551,t:1528143482323};\\\", \\\"{x:206,y:553,t:1528143482338};\\\", \\\"{x:198,y:554,t:1528143482356};\\\", \\\"{x:195,y:555,t:1528143482372};\\\", \\\"{x:190,y:556,t:1528143482390};\\\", \\\"{x:183,y:556,t:1528143482405};\\\", \\\"{x:178,y:556,t:1528143482422};\\\", \\\"{x:174,y:556,t:1528143482439};\\\", \\\"{x:170,y:556,t:1528143482455};\\\", \\\"{x:168,y:556,t:1528143482472};\\\", \\\"{x:168,y:555,t:1528143482636};\\\", \\\"{x:169,y:554,t:1528143482684};\\\", \\\"{x:171,y:553,t:1528143482700};\\\", \\\"{x:176,y:550,t:1528143482708};\\\", \\\"{x:180,y:548,t:1528143482723};\\\", \\\"{x:192,y:541,t:1528143482739};\\\", \\\"{x:210,y:533,t:1528143482756};\\\", \\\"{x:216,y:529,t:1528143482773};\\\", \\\"{x:223,y:526,t:1528143482788};\\\", \\\"{x:231,y:522,t:1528143482805};\\\", \\\"{x:247,y:517,t:1528143482824};\\\", \\\"{x:264,y:511,t:1528143482840};\\\", \\\"{x:281,y:506,t:1528143482857};\\\", \\\"{x:289,y:504,t:1528143482873};\\\", \\\"{x:297,y:502,t:1528143482890};\\\", \\\"{x:306,y:500,t:1528143482907};\\\", \\\"{x:309,y:499,t:1528143482923};\\\", \\\"{x:325,y:493,t:1528143482939};\\\", \\\"{x:337,y:490,t:1528143482955};\\\", \\\"{x:357,y:487,t:1528143482973};\\\", \\\"{x:390,y:482,t:1528143482991};\\\", \\\"{x:437,y:477,t:1528143483006};\\\", \\\"{x:482,y:470,t:1528143483022};\\\", \\\"{x:517,y:470,t:1528143483039};\\\", \\\"{x:535,y:470,t:1528143483056};\\\", \\\"{x:546,y:470,t:1528143483073};\\\", \\\"{x:552,y:470,t:1528143483090};\\\", \\\"{x:556,y:470,t:1528143483106};\\\", \\\"{x:559,y:470,t:1528143483122};\\\", \\\"{x:564,y:470,t:1528143483139};\\\", \\\"{x:565,y:470,t:1528143483164};\\\", \\\"{x:566,y:470,t:1528143483173};\\\", \\\"{x:571,y:471,t:1528143483189};\\\", \\\"{x:578,y:474,t:1528143483207};\\\", \\\"{x:582,y:476,t:1528143483222};\\\", \\\"{x:585,y:477,t:1528143483240};\\\", \\\"{x:588,y:479,t:1528143483257};\\\", \\\"{x:590,y:480,t:1528143483273};\\\", \\\"{x:593,y:483,t:1528143483290};\\\", \\\"{x:595,y:485,t:1528143483306};\\\", \\\"{x:601,y:488,t:1528143483323};\\\", \\\"{x:603,y:490,t:1528143483339};\\\", \\\"{x:605,y:490,t:1528143483356};\\\", \\\"{x:606,y:491,t:1528143483412};\\\", \\\"{x:606,y:492,t:1528143483422};\\\", \\\"{x:606,y:494,t:1528143483440};\\\", \\\"{x:606,y:496,t:1528143483456};\\\", \\\"{x:607,y:497,t:1528143483474};\\\", \\\"{x:614,y:498,t:1528143483780};\\\", \\\"{x:631,y:498,t:1528143483789};\\\", \\\"{x:703,y:498,t:1528143483807};\\\", \\\"{x:831,y:497,t:1528143483825};\\\", \\\"{x:972,y:497,t:1528143483840};\\\", \\\"{x:1105,y:497,t:1528143483856};\\\", \\\"{x:1200,y:493,t:1528143483873};\\\", \\\"{x:1258,y:493,t:1528143483890};\\\", \\\"{x:1275,y:494,t:1528143483907};\\\", \\\"{x:1277,y:496,t:1528143483924};\\\", \\\"{x:1277,y:497,t:1528143483941};\\\", \\\"{x:1277,y:503,t:1528143483957};\\\", \\\"{x:1278,y:513,t:1528143483974};\\\", \\\"{x:1280,y:527,t:1528143483991};\\\", \\\"{x:1281,y:536,t:1528143484007};\\\", \\\"{x:1278,y:542,t:1528143484024};\\\", \\\"{x:1275,y:547,t:1528143484041};\\\", \\\"{x:1275,y:550,t:1528143484057};\\\", \\\"{x:1275,y:555,t:1528143484074};\\\", \\\"{x:1273,y:558,t:1528143484091};\\\", \\\"{x:1272,y:562,t:1528143484108};\\\", \\\"{x:1272,y:563,t:1528143484124};\\\", \\\"{x:1271,y:565,t:1528143484142};\\\", \\\"{x:1273,y:566,t:1528143485213};\\\", \\\"{x:1275,y:566,t:1528143485226};\\\", \\\"{x:1279,y:567,t:1528143485245};\\\", \\\"{x:1284,y:569,t:1528143485259};\\\", \\\"{x:1290,y:569,t:1528143485275};\\\", \\\"{x:1302,y:570,t:1528143485292};\\\", \\\"{x:1312,y:571,t:1528143485309};\\\", \\\"{x:1321,y:573,t:1528143485324};\\\", \\\"{x:1331,y:573,t:1528143485341};\\\", \\\"{x:1339,y:573,t:1528143485358};\\\", \\\"{x:1348,y:573,t:1528143485375};\\\", \\\"{x:1354,y:573,t:1528143485392};\\\", \\\"{x:1361,y:573,t:1528143485409};\\\", \\\"{x:1368,y:573,t:1528143485424};\\\", \\\"{x:1378,y:570,t:1528143485442};\\\", \\\"{x:1386,y:569,t:1528143485458};\\\", \\\"{x:1392,y:568,t:1528143485475};\\\", \\\"{x:1398,y:566,t:1528143485492};\\\", \\\"{x:1399,y:566,t:1528143485509};\\\", \\\"{x:1400,y:565,t:1528143485525};\\\", \\\"{x:1402,y:565,t:1528143485541};\\\", \\\"{x:1406,y:564,t:1528143485559};\\\", \\\"{x:1411,y:562,t:1528143485576};\\\", \\\"{x:1418,y:561,t:1528143485592};\\\", \\\"{x:1417,y:561,t:1528143486204};\\\", \\\"{x:1410,y:561,t:1528143486213};\\\", \\\"{x:1399,y:561,t:1528143486227};\\\", \\\"{x:1366,y:563,t:1528143486244};\\\", \\\"{x:1291,y:563,t:1528143486259};\\\", \\\"{x:1166,y:563,t:1528143486276};\\\", \\\"{x:1091,y:563,t:1528143486292};\\\", \\\"{x:1010,y:563,t:1528143486310};\\\", \\\"{x:918,y:563,t:1528143486327};\\\", \\\"{x:835,y:563,t:1528143486342};\\\", \\\"{x:749,y:563,t:1528143486358};\\\", \\\"{x:688,y:563,t:1528143486376};\\\", \\\"{x:626,y:565,t:1528143486393};\\\", \\\"{x:593,y:571,t:1528143486408};\\\", \\\"{x:571,y:575,t:1528143486425};\\\", \\\"{x:557,y:577,t:1528143486443};\\\", \\\"{x:544,y:577,t:1528143486459};\\\", \\\"{x:536,y:579,t:1528143486475};\\\", \\\"{x:532,y:579,t:1528143486492};\\\", \\\"{x:529,y:580,t:1528143486508};\\\", \\\"{x:527,y:580,t:1528143486526};\\\", \\\"{x:524,y:580,t:1528143486543};\\\", \\\"{x:521,y:580,t:1528143486559};\\\", \\\"{x:520,y:581,t:1528143486575};\\\", \\\"{x:518,y:581,t:1528143486593};\\\", \\\"{x:515,y:583,t:1528143486608};\\\", \\\"{x:512,y:583,t:1528143486625};\\\", \\\"{x:507,y:584,t:1528143486643};\\\", \\\"{x:504,y:585,t:1528143486659};\\\", \\\"{x:500,y:586,t:1528143486676};\\\", \\\"{x:499,y:586,t:1528143486692};\\\", \\\"{x:498,y:586,t:1528143486716};\\\", \\\"{x:497,y:587,t:1528143486732};\\\", \\\"{x:496,y:587,t:1528143486764};\\\", \\\"{x:495,y:587,t:1528143486796};\\\", \\\"{x:491,y:580,t:1528143487172};\\\", \\\"{x:489,y:572,t:1528143487180};\\\", \\\"{x:488,y:567,t:1528143487193};\\\", \\\"{x:484,y:557,t:1528143487211};\\\", \\\"{x:480,y:549,t:1528143487226};\\\", \\\"{x:478,y:546,t:1528143487243};\\\", \\\"{x:476,y:543,t:1528143487259};\\\", \\\"{x:474,y:538,t:1528143487277};\\\", \\\"{x:473,y:535,t:1528143487293};\\\", \\\"{x:470,y:535,t:1528143487310};\\\", \\\"{x:467,y:535,t:1528143487326};\\\", \\\"{x:466,y:535,t:1528143487429};\\\", \\\"{x:463,y:535,t:1528143487443};\\\", \\\"{x:456,y:535,t:1528143487460};\\\", \\\"{x:451,y:535,t:1528143487476};\\\", \\\"{x:444,y:539,t:1528143487493};\\\", \\\"{x:445,y:539,t:1528143487540};\\\", \\\"{x:448,y:538,t:1528143487548};\\\", \\\"{x:453,y:535,t:1528143487560};\\\", \\\"{x:458,y:534,t:1528143487577};\\\", \\\"{x:466,y:530,t:1528143487593};\\\", \\\"{x:487,y:529,t:1528143487610};\\\", \\\"{x:540,y:523,t:1528143487629};\\\", \\\"{x:631,y:511,t:1528143487644};\\\", \\\"{x:783,y:501,t:1528143487660};\\\", \\\"{x:833,y:501,t:1528143487677};\\\", \\\"{x:848,y:501,t:1528143487693};\\\", \\\"{x:849,y:501,t:1528143487772};\\\", \\\"{x:849,y:502,t:1528143487787};\\\", \\\"{x:849,y:503,t:1528143487804};\\\", \\\"{x:849,y:505,t:1528143487812};\\\", \\\"{x:849,y:506,t:1528143487826};\\\", \\\"{x:847,y:512,t:1528143487844};\\\", \\\"{x:845,y:515,t:1528143487859};\\\", \\\"{x:843,y:518,t:1528143487878};\\\", \\\"{x:841,y:520,t:1528143487893};\\\", \\\"{x:838,y:522,t:1528143487910};\\\", \\\"{x:836,y:524,t:1528143487926};\\\", \\\"{x:834,y:525,t:1528143487944};\\\", \\\"{x:834,y:526,t:1528143487960};\\\", \\\"{x:834,y:527,t:1528143487996};\\\", \\\"{x:834,y:529,t:1528143488010};\\\", \\\"{x:834,y:533,t:1528143488027};\\\", \\\"{x:834,y:537,t:1528143488044};\\\", \\\"{x:834,y:538,t:1528143488140};\\\", \\\"{x:834,y:539,t:1528143488156};\\\", \\\"{x:834,y:539,t:1528143488262};\\\", \\\"{x:834,y:542,t:1528143489188};\\\", \\\"{x:836,y:557,t:1528143489198};\\\", \\\"{x:839,y:574,t:1528143489212};\\\", \\\"{x:850,y:601,t:1528143489227};\\\", \\\"{x:852,y:610,t:1528143489244};\\\", \\\"{x:853,y:617,t:1528143489261};\\\", \\\"{x:853,y:627,t:1528143489278};\\\", \\\"{x:850,y:639,t:1528143489295};\\\", \\\"{x:843,y:653,t:1528143489310};\\\", \\\"{x:830,y:667,t:1528143489328};\\\", \\\"{x:818,y:675,t:1528143489345};\\\", \\\"{x:806,y:682,t:1528143489362};\\\", \\\"{x:800,y:686,t:1528143489378};\\\", \\\"{x:797,y:690,t:1528143489395};\\\", \\\"{x:794,y:696,t:1528143489411};\\\", \\\"{x:793,y:704,t:1528143489428};\\\", \\\"{x:791,y:711,t:1528143489445};\\\", \\\"{x:788,y:719,t:1528143489462};\\\", \\\"{x:787,y:726,t:1528143489478};\\\", \\\"{x:783,y:734,t:1528143489495};\\\", \\\"{x:782,y:736,t:1528143489512};\\\", \\\"{x:780,y:739,t:1528143489528};\\\", \\\"{x:777,y:745,t:1528143489545};\\\", \\\"{x:770,y:752,t:1528143489562};\\\", \\\"{x:757,y:762,t:1528143489578};\\\", \\\"{x:740,y:770,t:1528143489595};\\\", \\\"{x:708,y:778,t:1528143489612};\\\", \\\"{x:688,y:780,t:1528143489628};\\\", \\\"{x:673,y:780,t:1528143489645};\\\", \\\"{x:658,y:780,t:1528143489662};\\\", \\\"{x:644,y:780,t:1528143489678};\\\", \\\"{x:629,y:778,t:1528143489694};\\\", \\\"{x:614,y:773,t:1528143489711};\\\", \\\"{x:605,y:769,t:1528143489729};\\\", \\\"{x:597,y:765,t:1528143489745};\\\", \\\"{x:589,y:761,t:1528143489762};\\\", \\\"{x:586,y:760,t:1528143489778};\\\", \\\"{x:584,y:760,t:1528143489795};\\\", \\\"{x:583,y:759,t:1528143489812};\\\", \\\"{x:581,y:758,t:1528143489829};\\\", \\\"{x:577,y:758,t:1528143489845};\\\", \\\"{x:573,y:758,t:1528143489862};\\\", \\\"{x:567,y:758,t:1528143489880};\\\", \\\"{x:561,y:758,t:1528143489896};\\\", \\\"{x:552,y:758,t:1528143489913};\\\", \\\"{x:538,y:756,t:1528143489929};\\\", \\\"{x:523,y:751,t:1528143489946};\\\", \\\"{x:510,y:748,t:1528143489962};\\\", \\\"{x:500,y:743,t:1528143489978};\\\", \\\"{x:488,y:738,t:1528143489995};\\\", \\\"{x:476,y:736,t:1528143490011};\\\", \\\"{x:470,y:733,t:1528143490029};\\\", \\\"{x:465,y:732,t:1528143490045};\\\", \\\"{x:463,y:731,t:1528143490062};\\\", \\\"{x:463,y:730,t:1528143490124};\\\", \\\"{x:462,y:729,t:1528143490197};\\\", \\\"{x:461,y:728,t:1528143490293};\\\", \\\"{x:460,y:727,t:1528143490301};\\\", \\\"{x:460,y:726,t:1528143490316};\\\", \\\"{x:460,y:725,t:1528143490329};\\\", \\\"{x:458,y:725,t:1528143490346};\\\", \\\"{x:458,y:724,t:1528143490362};\\\", \\\"{x:457,y:723,t:1528143490379};\\\", \\\"{x:457,y:722,t:1528143490412};\\\", \\\"{x:456,y:722,t:1528143490693};\\\", \\\"{x:456,y:721,t:1528143490709};\\\", \\\"{x:455,y:720,t:1528143490717};\\\", \\\"{x:455,y:719,t:1528143490734};\\\", \\\"{x:454,y:719,t:1528143491389};\\\", \\\"{x:453,y:719,t:1528143491428};\\\", \\\"{x:452,y:719,t:1528143491444};\\\", \\\"{x:452,y:720,t:1528143491453};\\\", \\\"{x:452,y:722,t:1528143491463};\\\", \\\"{x:455,y:724,t:1528143491479};\\\", \\\"{x:458,y:726,t:1528143491497};\\\", \\\"{x:461,y:728,t:1528143491513};\\\", \\\"{x:462,y:729,t:1528143491530};\\\", \\\"{x:464,y:731,t:1528143491546};\\\", \\\"{x:465,y:732,t:1528143491562};\\\", \\\"{x:466,y:733,t:1528143491580};\\\", \\\"{x:466,y:734,t:1528143491597};\\\" ] }, { \\\"rt\\\": 30299, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 11, \\\"time_elapsed\\\": 607802, \\\"internal_node_id\\\": \\\"0.0-6.0-1.0\\\", \\\"subject\\\": \\\"06217\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"zulu\\\", \\\"condition\\\": \\\"211\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"duration+starts\\\", \\\"q\\\": 7, \\\"clicks\\\": 2, \\\"explicit\\\": 2, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XInside-YFull\\\", \\\"correct\\\": 1, \\\"orth_correct\\\": 0, \\\"answer\\\": [ \\\"X\\\", \\\"O\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-5-10 AM-O -X \\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:465,y:735,t:1528143495989};\\\", \\\"{x:464,y:735,t:1528143496003};\\\", \\\"{x:463,y:737,t:1528143496075};\\\", \\\"{x:463,y:739,t:1528143496083};\\\", \\\"{x:470,y:742,t:1528143496100};\\\", \\\"{x:480,y:745,t:1528143496117};\\\", \\\"{x:502,y:748,t:1528143496132};\\\", \\\"{x:531,y:751,t:1528143496150};\\\", \\\"{x:561,y:753,t:1528143496167};\\\", \\\"{x:592,y:753,t:1528143496183};\\\", \\\"{x:624,y:753,t:1528143496200};\\\", \\\"{x:653,y:753,t:1528143496217};\\\", \\\"{x:686,y:753,t:1528143496233};\\\", \\\"{x:720,y:753,t:1528143496250};\\\", \\\"{x:751,y:753,t:1528143496267};\\\", \\\"{x:781,y:753,t:1528143496283};\\\", \\\"{x:822,y:753,t:1528143496300};\\\", \\\"{x:844,y:749,t:1528143496317};\\\", \\\"{x:864,y:743,t:1528143496333};\\\", \\\"{x:885,y:733,t:1528143496350};\\\", \\\"{x:903,y:723,t:1528143496368};\\\", \\\"{x:920,y:713,t:1528143496384};\\\", \\\"{x:935,y:702,t:1528143496400};\\\", \\\"{x:948,y:692,t:1528143496418};\\\", \\\"{x:963,y:679,t:1528143496434};\\\", \\\"{x:976,y:658,t:1528143496450};\\\", \\\"{x:993,y:640,t:1528143496468};\\\", \\\"{x:1015,y:621,t:1528143496484};\\\", \\\"{x:1025,y:611,t:1528143496500};\\\", \\\"{x:1033,y:605,t:1528143496517};\\\", \\\"{x:1035,y:604,t:1528143496534};\\\", \\\"{x:1035,y:603,t:1528143496550};\\\", \\\"{x:1036,y:604,t:1528143496676};\\\", \\\"{x:1037,y:605,t:1528143496684};\\\", \\\"{x:1040,y:614,t:1528143496700};\\\", \\\"{x:1042,y:620,t:1528143496718};\\\", \\\"{x:1043,y:622,t:1528143496735};\\\", \\\"{x:1044,y:624,t:1528143496750};\\\", \\\"{x:1045,y:627,t:1528143496767};\\\", \\\"{x:1045,y:629,t:1528143496785};\\\", \\\"{x:1045,y:630,t:1528143496800};\\\", \\\"{x:1047,y:630,t:1528143497124};\\\", \\\"{x:1048,y:630,t:1528143497149};\\\", \\\"{x:1049,y:630,t:1528143497157};\\\", \\\"{x:1050,y:630,t:1528143497167};\\\", \\\"{x:1051,y:630,t:1528143497184};\\\", \\\"{x:1052,y:630,t:1528143497202};\\\", \\\"{x:1053,y:630,t:1528143497220};\\\", \\\"{x:1054,y:630,t:1528143497429};\\\", \\\"{x:1055,y:630,t:1528143497437};\\\", \\\"{x:1056,y:629,t:1528143497452};\\\", \\\"{x:1057,y:628,t:1528143497484};\\\", \\\"{x:1057,y:632,t:1528143499140};\\\", \\\"{x:1057,y:639,t:1528143499154};\\\", \\\"{x:1057,y:645,t:1528143499170};\\\", \\\"{x:1058,y:648,t:1528143499186};\\\", \\\"{x:1058,y:650,t:1528143499202};\\\", \\\"{x:1058,y:651,t:1528143499228};\\\", \\\"{x:1058,y:652,t:1528143499268};\\\", \\\"{x:1059,y:655,t:1528143499287};\\\", \\\"{x:1059,y:657,t:1528143499303};\\\", \\\"{x:1061,y:661,t:1528143499320};\\\", \\\"{x:1061,y:665,t:1528143499337};\\\", \\\"{x:1066,y:676,t:1528143499353};\\\", \\\"{x:1075,y:687,t:1528143499370};\\\", \\\"{x:1106,y:705,t:1528143499387};\\\", \\\"{x:1178,y:725,t:1528143499403};\\\", \\\"{x:1278,y:734,t:1528143499420};\\\", \\\"{x:1433,y:734,t:1528143499436};\\\", \\\"{x:1522,y:734,t:1528143499453};\\\", \\\"{x:1608,y:734,t:1528143499469};\\\", \\\"{x:1686,y:734,t:1528143499487};\\\", \\\"{x:1725,y:734,t:1528143499503};\\\", \\\"{x:1748,y:734,t:1528143499520};\\\", \\\"{x:1760,y:734,t:1528143499537};\\\", \\\"{x:1765,y:734,t:1528143499553};\\\", \\\"{x:1769,y:734,t:1528143499570};\\\", \\\"{x:1776,y:732,t:1528143499587};\\\", \\\"{x:1786,y:730,t:1528143499602};\\\", \\\"{x:1797,y:726,t:1528143499620};\\\", \\\"{x:1800,y:723,t:1528143499636};\\\", \\\"{x:1800,y:722,t:1528143499669};\\\", \\\"{x:1799,y:719,t:1528143499677};\\\", \\\"{x:1790,y:716,t:1528143499687};\\\", \\\"{x:1780,y:714,t:1528143499703};\\\", \\\"{x:1765,y:713,t:1528143499720};\\\", \\\"{x:1740,y:713,t:1528143499737};\\\", \\\"{x:1712,y:713,t:1528143499754};\\\", \\\"{x:1681,y:713,t:1528143499770};\\\", \\\"{x:1655,y:713,t:1528143499787};\\\", \\\"{x:1634,y:713,t:1528143499804};\\\", \\\"{x:1624,y:713,t:1528143499820};\\\", \\\"{x:1621,y:713,t:1528143499837};\\\", \\\"{x:1620,y:713,t:1528143499900};\\\", \\\"{x:1617,y:713,t:1528143499907};\\\", \\\"{x:1614,y:713,t:1528143499919};\\\", \\\"{x:1601,y:713,t:1528143499936};\\\", \\\"{x:1585,y:715,t:1528143499953};\\\", \\\"{x:1568,y:716,t:1528143499969};\\\", \\\"{x:1552,y:716,t:1528143499986};\\\", \\\"{x:1522,y:716,t:1528143500004};\\\", \\\"{x:1499,y:716,t:1528143500019};\\\", \\\"{x:1483,y:716,t:1528143500036};\\\", \\\"{x:1472,y:716,t:1528143500053};\\\", \\\"{x:1463,y:716,t:1528143500069};\\\", \\\"{x:1457,y:716,t:1528143500087};\\\", \\\"{x:1449,y:716,t:1528143500104};\\\", \\\"{x:1436,y:716,t:1528143500120};\\\", \\\"{x:1421,y:716,t:1528143500136};\\\", \\\"{x:1408,y:716,t:1528143500154};\\\", \\\"{x:1391,y:716,t:1528143500170};\\\", \\\"{x:1380,y:716,t:1528143500187};\\\", \\\"{x:1369,y:716,t:1528143500203};\\\", \\\"{x:1365,y:716,t:1528143500219};\\\", \\\"{x:1358,y:716,t:1528143500236};\\\", \\\"{x:1350,y:716,t:1528143500254};\\\", \\\"{x:1339,y:716,t:1528143500270};\\\", \\\"{x:1325,y:716,t:1528143500286};\\\", \\\"{x:1316,y:716,t:1528143500304};\\\", \\\"{x:1310,y:716,t:1528143500320};\\\", \\\"{x:1306,y:716,t:1528143500336};\\\", \\\"{x:1304,y:716,t:1528143500353};\\\", \\\"{x:1303,y:716,t:1528143500412};\\\", \\\"{x:1303,y:715,t:1528143500420};\\\", \\\"{x:1303,y:714,t:1528143500469};\\\", \\\"{x:1302,y:713,t:1528143500508};\\\", \\\"{x:1301,y:713,t:1528143500525};\\\", \\\"{x:1299,y:713,t:1528143500537};\\\", \\\"{x:1288,y:712,t:1528143500554};\\\", \\\"{x:1265,y:712,t:1528143500571};\\\", \\\"{x:1231,y:710,t:1528143500587};\\\", \\\"{x:1189,y:710,t:1528143500603};\\\", \\\"{x:1149,y:710,t:1528143500620};\\\", \\\"{x:1128,y:710,t:1528143500636};\\\", \\\"{x:1113,y:710,t:1528143500653};\\\", \\\"{x:1108,y:710,t:1528143500671};\\\", \\\"{x:1107,y:710,t:1528143500687};\\\", \\\"{x:1105,y:709,t:1528143500704};\\\", \\\"{x:1104,y:708,t:1528143500721};\\\", \\\"{x:1098,y:705,t:1528143500738};\\\", \\\"{x:1085,y:701,t:1528143500753};\\\", \\\"{x:1065,y:695,t:1528143500771};\\\", \\\"{x:1054,y:693,t:1528143500788};\\\", \\\"{x:1051,y:692,t:1528143500804};\\\", \\\"{x:1051,y:691,t:1528143500916};\\\", \\\"{x:1051,y:689,t:1528143500949};\\\", \\\"{x:1054,y:688,t:1528143500964};\\\", \\\"{x:1057,y:688,t:1528143500972};\\\", \\\"{x:1072,y:688,t:1528143500988};\\\", \\\"{x:1094,y:688,t:1528143501005};\\\", \\\"{x:1121,y:688,t:1528143501021};\\\", \\\"{x:1149,y:688,t:1528143501038};\\\", \\\"{x:1181,y:688,t:1528143501054};\\\", \\\"{x:1205,y:688,t:1528143501071};\\\", \\\"{x:1228,y:688,t:1528143501088};\\\", \\\"{x:1249,y:688,t:1528143501103};\\\", \\\"{x:1264,y:688,t:1528143501121};\\\", \\\"{x:1272,y:687,t:1528143501137};\\\", \\\"{x:1281,y:686,t:1528143501155};\\\", \\\"{x:1290,y:686,t:1528143501171};\\\", \\\"{x:1296,y:686,t:1528143501188};\\\", \\\"{x:1304,y:685,t:1528143501204};\\\", \\\"{x:1308,y:685,t:1528143501221};\\\", \\\"{x:1310,y:685,t:1528143501237};\\\", \\\"{x:1311,y:685,t:1528143501268};\\\", \\\"{x:1312,y:685,t:1528143501292};\\\", \\\"{x:1313,y:685,t:1528143501309};\\\", \\\"{x:1314,y:685,t:1528143501923};\\\", \\\"{x:1315,y:686,t:1528143501939};\\\", \\\"{x:1316,y:687,t:1528143501954};\\\", \\\"{x:1317,y:687,t:1528143501971};\\\", \\\"{x:1317,y:688,t:1528143501988};\\\", \\\"{x:1318,y:689,t:1528143502004};\\\", \\\"{x:1319,y:690,t:1528143502052};\\\", \\\"{x:1312,y:691,t:1528143503916};\\\", \\\"{x:1300,y:691,t:1528143503924};\\\", \\\"{x:1261,y:691,t:1528143503941};\\\", \\\"{x:1209,y:686,t:1528143503957};\\\", \\\"{x:1144,y:676,t:1528143503973};\\\", \\\"{x:1090,y:666,t:1528143503990};\\\", \\\"{x:1067,y:658,t:1528143504007};\\\", \\\"{x:1063,y:656,t:1528143504023};\\\", \\\"{x:1063,y:655,t:1528143504040};\\\", \\\"{x:1063,y:654,t:1528143504057};\\\", \\\"{x:1063,y:652,t:1528143504084};\\\", \\\"{x:1063,y:651,t:1528143504141};\\\", \\\"{x:1063,y:649,t:1528143504180};\\\", \\\"{x:1063,y:647,t:1528143504204};\\\", \\\"{x:1063,y:646,t:1528143504220};\\\", \\\"{x:1063,y:645,t:1528143504228};\\\", \\\"{x:1064,y:644,t:1528143504253};\\\", \\\"{x:1064,y:643,t:1528143504260};\\\", \\\"{x:1065,y:642,t:1528143504272};\\\", \\\"{x:1066,y:642,t:1528143504290};\\\", \\\"{x:1067,y:641,t:1528143504306};\\\", \\\"{x:1070,y:641,t:1528143504322};\\\", \\\"{x:1070,y:639,t:1528143504339};\\\", \\\"{x:1072,y:639,t:1528143504356};\\\", \\\"{x:1073,y:638,t:1528143504372};\\\", \\\"{x:1075,y:637,t:1528143504390};\\\", \\\"{x:1074,y:637,t:1528143505005};\\\", \\\"{x:1073,y:637,t:1528143505028};\\\", \\\"{x:1072,y:638,t:1528143505044};\\\", \\\"{x:1072,y:639,t:1528143505060};\\\", \\\"{x:1070,y:643,t:1528143505073};\\\", \\\"{x:1070,y:646,t:1528143505091};\\\", \\\"{x:1070,y:649,t:1528143505107};\\\", \\\"{x:1070,y:652,t:1528143505124};\\\", \\\"{x:1070,y:653,t:1528143505140};\\\", \\\"{x:1070,y:655,t:1528143505157};\\\", \\\"{x:1070,y:656,t:1528143505174};\\\", \\\"{x:1070,y:658,t:1528143505191};\\\", \\\"{x:1070,y:661,t:1528143505207};\\\", \\\"{x:1070,y:662,t:1528143505224};\\\", \\\"{x:1070,y:663,t:1528143505252};\\\", \\\"{x:1072,y:663,t:1528143507820};\\\", \\\"{x:1082,y:667,t:1528143507828};\\\", \\\"{x:1091,y:674,t:1528143507843};\\\", \\\"{x:1152,y:695,t:1528143507859};\\\", \\\"{x:1306,y:729,t:1528143507876};\\\", \\\"{x:1395,y:746,t:1528143507892};\\\", \\\"{x:1463,y:757,t:1528143507910};\\\", \\\"{x:1491,y:761,t:1528143507926};\\\", \\\"{x:1499,y:765,t:1528143507943};\\\", \\\"{x:1494,y:765,t:1528143508100};\\\", \\\"{x:1483,y:763,t:1528143508110};\\\", \\\"{x:1461,y:761,t:1528143508127};\\\", \\\"{x:1440,y:758,t:1528143508143};\\\", \\\"{x:1416,y:756,t:1528143508159};\\\", \\\"{x:1397,y:756,t:1528143508177};\\\", \\\"{x:1388,y:756,t:1528143508193};\\\", \\\"{x:1385,y:756,t:1528143508209};\\\", \\\"{x:1383,y:756,t:1528143508228};\\\", \\\"{x:1381,y:757,t:1528143508243};\\\", \\\"{x:1377,y:759,t:1528143508259};\\\", \\\"{x:1367,y:763,t:1528143508276};\\\", \\\"{x:1363,y:765,t:1528143508293};\\\", \\\"{x:1362,y:766,t:1528143508310};\\\", \\\"{x:1360,y:766,t:1528143508326};\\\", \\\"{x:1359,y:766,t:1528143508573};\\\", \\\"{x:1358,y:766,t:1528143508900};\\\", \\\"{x:1358,y:764,t:1528143509364};\\\", \\\"{x:1358,y:761,t:1528143509377};\\\", \\\"{x:1358,y:754,t:1528143509394};\\\", \\\"{x:1358,y:748,t:1528143509410};\\\", \\\"{x:1364,y:738,t:1528143509427};\\\", \\\"{x:1375,y:721,t:1528143509444};\\\", \\\"{x:1380,y:711,t:1528143509460};\\\", \\\"{x:1384,y:704,t:1528143509477};\\\", \\\"{x:1385,y:702,t:1528143509494};\\\", \\\"{x:1385,y:701,t:1528143509511};\\\", \\\"{x:1384,y:701,t:1528143513860};\\\", \\\"{x:1373,y:706,t:1528143513868};\\\", \\\"{x:1349,y:715,t:1528143513880};\\\", \\\"{x:1303,y:740,t:1528143513897};\\\", \\\"{x:1243,y:778,t:1528143513914};\\\", \\\"{x:1203,y:804,t:1528143513930};\\\", \\\"{x:1193,y:814,t:1528143513947};\\\", \\\"{x:1184,y:828,t:1528143513963};\\\", \\\"{x:1182,y:852,t:1528143513980};\\\", \\\"{x:1183,y:865,t:1528143513997};\\\", \\\"{x:1183,y:882,t:1528143514014};\\\", \\\"{x:1181,y:893,t:1528143514030};\\\", \\\"{x:1172,y:903,t:1528143514047};\\\", \\\"{x:1156,y:914,t:1528143514065};\\\", \\\"{x:1149,y:923,t:1528143514081};\\\", \\\"{x:1147,y:925,t:1528143514097};\\\", \\\"{x:1145,y:926,t:1528143514341};\\\", \\\"{x:1146,y:931,t:1528143514629};\\\", \\\"{x:1154,y:935,t:1528143514636};\\\", \\\"{x:1158,y:938,t:1528143514648};\\\", \\\"{x:1159,y:939,t:1528143514664};\\\", \\\"{x:1160,y:939,t:1528143514709};\\\", \\\"{x:1160,y:941,t:1528143514740};\\\", \\\"{x:1160,y:943,t:1528143514756};\\\", \\\"{x:1160,y:945,t:1528143514764};\\\", \\\"{x:1160,y:948,t:1528143514782};\\\", \\\"{x:1160,y:951,t:1528143514797};\\\", \\\"{x:1160,y:952,t:1528143514814};\\\", \\\"{x:1161,y:955,t:1528143514832};\\\", \\\"{x:1163,y:959,t:1528143514847};\\\", \\\"{x:1165,y:963,t:1528143514865};\\\", \\\"{x:1167,y:966,t:1528143514882};\\\", \\\"{x:1170,y:969,t:1528143514898};\\\", \\\"{x:1172,y:971,t:1528143514915};\\\", \\\"{x:1174,y:973,t:1528143514931};\\\", \\\"{x:1175,y:973,t:1528143514947};\\\", \\\"{x:1175,y:974,t:1528143514972};\\\", \\\"{x:1177,y:975,t:1528143514988};\\\", \\\"{x:1178,y:976,t:1528143515077};\\\", \\\"{x:1179,y:976,t:1528143515156};\\\", \\\"{x:1180,y:976,t:1528143515164};\\\", \\\"{x:1183,y:976,t:1528143515181};\\\", \\\"{x:1186,y:976,t:1528143515198};\\\", \\\"{x:1192,y:976,t:1528143515214};\\\", \\\"{x:1193,y:975,t:1528143515241};\\\", \\\"{x:1196,y:974,t:1528143515259};\\\", \\\"{x:1198,y:973,t:1528143515274};\\\", \\\"{x:1200,y:972,t:1528143515291};\\\", \\\"{x:1203,y:971,t:1528143515308};\\\", \\\"{x:1205,y:970,t:1528143515324};\\\", \\\"{x:1207,y:969,t:1528143515342};\\\", \\\"{x:1209,y:968,t:1528143515359};\\\", \\\"{x:1210,y:967,t:1528143515390};\\\", \\\"{x:1212,y:962,t:1528143515409};\\\", \\\"{x:1212,y:961,t:1528143515426};\\\", \\\"{x:1213,y:959,t:1528143515441};\\\", \\\"{x:1214,y:959,t:1528143515458};\\\", \\\"{x:1215,y:957,t:1528143515478};\\\", \\\"{x:1218,y:956,t:1528143515492};\\\", \\\"{x:1221,y:955,t:1528143515509};\\\", \\\"{x:1223,y:954,t:1528143515525};\\\", \\\"{x:1224,y:954,t:1528143515541};\\\", \\\"{x:1227,y:954,t:1528143515558};\\\", \\\"{x:1229,y:954,t:1528143515575};\\\", \\\"{x:1233,y:952,t:1528143515591};\\\", \\\"{x:1238,y:951,t:1528143515608};\\\", \\\"{x:1245,y:951,t:1528143515625};\\\", \\\"{x:1254,y:950,t:1528143515641};\\\", \\\"{x:1258,y:948,t:1528143515658};\\\", \\\"{x:1265,y:947,t:1528143515675};\\\", \\\"{x:1267,y:947,t:1528143515691};\\\", \\\"{x:1268,y:947,t:1528143515709};\\\", \\\"{x:1269,y:946,t:1528143515887};\\\", \\\"{x:1269,y:945,t:1528143515951};\\\", \\\"{x:1270,y:945,t:1528143515958};\\\", \\\"{x:1270,y:944,t:1528143516086};\\\", \\\"{x:1271,y:944,t:1528143516477};\\\", \\\"{x:1275,y:946,t:1528143516492};\\\", \\\"{x:1292,y:951,t:1528143516508};\\\", \\\"{x:1312,y:955,t:1528143516525};\\\", \\\"{x:1330,y:957,t:1528143516542};\\\", \\\"{x:1345,y:960,t:1528143516559};\\\", \\\"{x:1351,y:961,t:1528143516574};\\\", \\\"{x:1353,y:961,t:1528143516677};\\\", \\\"{x:1356,y:963,t:1528143516701};\\\", \\\"{x:1357,y:964,t:1528143516725};\\\", \\\"{x:1357,y:963,t:1528143517125};\\\", \\\"{x:1357,y:960,t:1528143517142};\\\", \\\"{x:1365,y:957,t:1528143517159};\\\", \\\"{x:1377,y:955,t:1528143517176};\\\", \\\"{x:1395,y:953,t:1528143517192};\\\", \\\"{x:1409,y:951,t:1528143517209};\\\", \\\"{x:1419,y:950,t:1528143517226};\\\", \\\"{x:1423,y:949,t:1528143517242};\\\", \\\"{x:1424,y:948,t:1528143517302};\\\", \\\"{x:1425,y:948,t:1528143517309};\\\", \\\"{x:1425,y:947,t:1528143517327};\\\", \\\"{x:1426,y:947,t:1528143517463};\\\", \\\"{x:1426,y:948,t:1528143517608};\\\", \\\"{x:1425,y:949,t:1528143517614};\\\", \\\"{x:1423,y:951,t:1528143517626};\\\", \\\"{x:1421,y:952,t:1528143517644};\\\", \\\"{x:1418,y:954,t:1528143517660};\\\", \\\"{x:1416,y:954,t:1528143517695};\\\", \\\"{x:1416,y:955,t:1528143517711};\\\", \\\"{x:1415,y:956,t:1528143517742};\\\", \\\"{x:1415,y:957,t:1528143517791};\\\", \\\"{x:1414,y:957,t:1528143517813};\\\", \\\"{x:1418,y:953,t:1528143518630};\\\", \\\"{x:1422,y:947,t:1528143518644};\\\", \\\"{x:1433,y:932,t:1528143518662};\\\", \\\"{x:1460,y:892,t:1528143518678};\\\", \\\"{x:1483,y:860,t:1528143518694};\\\", \\\"{x:1498,y:839,t:1528143518711};\\\", \\\"{x:1513,y:822,t:1528143518727};\\\", \\\"{x:1522,y:810,t:1528143518744};\\\", \\\"{x:1526,y:801,t:1528143518761};\\\", \\\"{x:1527,y:797,t:1528143518778};\\\", \\\"{x:1527,y:793,t:1528143518794};\\\", \\\"{x:1528,y:791,t:1528143518811};\\\", \\\"{x:1528,y:789,t:1528143518828};\\\", \\\"{x:1528,y:788,t:1528143518862};\\\", \\\"{x:1528,y:787,t:1528143518911};\\\", \\\"{x:1528,y:784,t:1528143518928};\\\", \\\"{x:1528,y:780,t:1528143518944};\\\", \\\"{x:1528,y:777,t:1528143518961};\\\", \\\"{x:1528,y:773,t:1528143518978};\\\", \\\"{x:1528,y:771,t:1528143518994};\\\", \\\"{x:1528,y:770,t:1528143519014};\\\", \\\"{x:1528,y:769,t:1528143519063};\\\", \\\"{x:1528,y:768,t:1528143519127};\\\", \\\"{x:1528,y:767,t:1528143519950};\\\", \\\"{x:1528,y:764,t:1528143519962};\\\", \\\"{x:1526,y:762,t:1528143519978};\\\", \\\"{x:1526,y:760,t:1528143519994};\\\", \\\"{x:1524,y:758,t:1528143520012};\\\", \\\"{x:1523,y:757,t:1528143520029};\\\", \\\"{x:1521,y:756,t:1528143520159};\\\", \\\"{x:1519,y:758,t:1528143520174};\\\", \\\"{x:1518,y:763,t:1528143520185};\\\", \\\"{x:1516,y:765,t:1528143520195};\\\", \\\"{x:1512,y:771,t:1528143520211};\\\", \\\"{x:1511,y:777,t:1528143520228};\\\", \\\"{x:1508,y:783,t:1528143520245};\\\", \\\"{x:1508,y:786,t:1528143520261};\\\", \\\"{x:1507,y:791,t:1528143520278};\\\", \\\"{x:1503,y:798,t:1528143520295};\\\", \\\"{x:1499,y:804,t:1528143520311};\\\", \\\"{x:1497,y:807,t:1528143520328};\\\", \\\"{x:1496,y:810,t:1528143520345};\\\", \\\"{x:1495,y:812,t:1528143520362};\\\", \\\"{x:1493,y:814,t:1528143520379};\\\", \\\"{x:1492,y:816,t:1528143520396};\\\", \\\"{x:1490,y:820,t:1528143520412};\\\", \\\"{x:1489,y:823,t:1528143520429};\\\", \\\"{x:1488,y:825,t:1528143520446};\\\", \\\"{x:1488,y:827,t:1528143520462};\\\", \\\"{x:1486,y:829,t:1528143520479};\\\", \\\"{x:1486,y:831,t:1528143520495};\\\", \\\"{x:1485,y:832,t:1528143520512};\\\", \\\"{x:1484,y:834,t:1528143520529};\\\", \\\"{x:1483,y:834,t:1528143520546};\\\", \\\"{x:1483,y:835,t:1528143520565};\\\", \\\"{x:1482,y:836,t:1528143520616};\\\", \\\"{x:1481,y:837,t:1528143520630};\\\", \\\"{x:1480,y:837,t:1528143520647};\\\", \\\"{x:1480,y:839,t:1528143520662};\\\", \\\"{x:1478,y:839,t:1528143520679};\\\", \\\"{x:1476,y:840,t:1528143520711};\\\", \\\"{x:1475,y:840,t:1528143520751};\\\", \\\"{x:1473,y:842,t:1528143520763};\\\", \\\"{x:1464,y:846,t:1528143520779};\\\", \\\"{x:1450,y:849,t:1528143520795};\\\", \\\"{x:1422,y:849,t:1528143520813};\\\", \\\"{x:1378,y:849,t:1528143520829};\\\", \\\"{x:1183,y:822,t:1528143520846};\\\", \\\"{x:1020,y:800,t:1528143520862};\\\", \\\"{x:840,y:776,t:1528143520879};\\\", \\\"{x:673,y:744,t:1528143520895};\\\", \\\"{x:544,y:708,t:1528143520913};\\\", \\\"{x:476,y:683,t:1528143520929};\\\", \\\"{x:449,y:667,t:1528143520947};\\\", \\\"{x:442,y:654,t:1528143520962};\\\", \\\"{x:442,y:648,t:1528143520978};\\\", \\\"{x:443,y:643,t:1528143520997};\\\", \\\"{x:443,y:641,t:1528143521013};\\\", \\\"{x:443,y:637,t:1528143521031};\\\", \\\"{x:433,y:632,t:1528143521047};\\\", \\\"{x:422,y:626,t:1528143521063};\\\", \\\"{x:415,y:621,t:1528143521081};\\\", \\\"{x:415,y:620,t:1528143521097};\\\", \\\"{x:415,y:618,t:1528143521114};\\\", \\\"{x:419,y:617,t:1528143521131};\\\", \\\"{x:425,y:613,t:1528143521147};\\\", \\\"{x:444,y:605,t:1528143521164};\\\", \\\"{x:483,y:599,t:1528143521181};\\\", \\\"{x:560,y:589,t:1528143521198};\\\", \\\"{x:604,y:584,t:1528143521214};\\\", \\\"{x:632,y:583,t:1528143521231};\\\", \\\"{x:646,y:583,t:1528143521248};\\\", \\\"{x:651,y:583,t:1528143521264};\\\", \\\"{x:654,y:583,t:1528143521281};\\\", \\\"{x:663,y:587,t:1528143521297};\\\", \\\"{x:674,y:590,t:1528143521314};\\\", \\\"{x:685,y:591,t:1528143521332};\\\", \\\"{x:696,y:592,t:1528143521348};\\\", \\\"{x:709,y:592,t:1528143521364};\\\", \\\"{x:716,y:593,t:1528143521382};\\\", \\\"{x:721,y:593,t:1528143521398};\\\", \\\"{x:726,y:593,t:1528143521417};\\\", \\\"{x:734,y:593,t:1528143521431};\\\", \\\"{x:744,y:593,t:1528143521447};\\\", \\\"{x:749,y:593,t:1528143521464};\\\", \\\"{x:750,y:593,t:1528143521481};\\\", \\\"{x:752,y:593,t:1528143521498};\\\", \\\"{x:752,y:595,t:1528143521515};\\\", \\\"{x:752,y:596,t:1528143521531};\\\", \\\"{x:753,y:596,t:1528143521565};\\\", \\\"{x:765,y:593,t:1528143521582};\\\", \\\"{x:777,y:588,t:1528143521597};\\\", \\\"{x:786,y:585,t:1528143521614};\\\", \\\"{x:792,y:582,t:1528143521631};\\\", \\\"{x:795,y:580,t:1528143521648};\\\", \\\"{x:802,y:576,t:1528143521664};\\\", \\\"{x:808,y:572,t:1528143521681};\\\", \\\"{x:814,y:571,t:1528143521697};\\\", \\\"{x:819,y:569,t:1528143521714};\\\", \\\"{x:821,y:569,t:1528143521732};\\\", \\\"{x:822,y:569,t:1528143521748};\\\", \\\"{x:823,y:569,t:1528143521766};\\\", \\\"{x:826,y:569,t:1528143521782};\\\", \\\"{x:831,y:571,t:1528143521797};\\\", \\\"{x:834,y:573,t:1528143521815};\\\", \\\"{x:837,y:575,t:1528143521831};\\\", \\\"{x:839,y:577,t:1528143521849};\\\", \\\"{x:841,y:579,t:1528143521865};\\\", \\\"{x:841,y:580,t:1528143521893};\\\", \\\"{x:841,y:581,t:1528143521908};\\\", \\\"{x:841,y:582,t:1528143521917};\\\", \\\"{x:841,y:583,t:1528143522045};\\\", \\\"{x:841,y:584,t:1528143522053};\\\", \\\"{x:841,y:584,t:1528143522063};\\\", \\\"{x:841,y:585,t:1528143522081};\\\", \\\"{x:832,y:586,t:1528143522098};\\\", \\\"{x:817,y:588,t:1528143522114};\\\", \\\"{x:794,y:588,t:1528143522131};\\\", \\\"{x:768,y:588,t:1528143522148};\\\", \\\"{x:742,y:588,t:1528143522164};\\\", \\\"{x:724,y:588,t:1528143522180};\\\", \\\"{x:720,y:588,t:1528143522199};\\\", \\\"{x:717,y:588,t:1528143522215};\\\", \\\"{x:709,y:588,t:1528143522231};\\\", \\\"{x:687,y:584,t:1528143522248};\\\", \\\"{x:668,y:581,t:1528143522264};\\\", \\\"{x:651,y:580,t:1528143522281};\\\", \\\"{x:642,y:580,t:1528143522299};\\\", \\\"{x:638,y:580,t:1528143522315};\\\", \\\"{x:637,y:579,t:1528143522331};\\\", \\\"{x:634,y:579,t:1528143522348};\\\", \\\"{x:631,y:579,t:1528143522365};\\\", \\\"{x:630,y:579,t:1528143522390};\\\", \\\"{x:629,y:579,t:1528143522399};\\\", \\\"{x:628,y:579,t:1528143522415};\\\", \\\"{x:619,y:587,t:1528143522725};\\\", \\\"{x:601,y:610,t:1528143522734};\\\", \\\"{x:571,y:646,t:1528143522749};\\\", \\\"{x:514,y:714,t:1528143522765};\\\", \\\"{x:495,y:739,t:1528143522781};\\\", \\\"{x:489,y:746,t:1528143522798};\\\", \\\"{x:488,y:747,t:1528143522816};\\\", \\\"{x:487,y:748,t:1528143522894};\\\", \\\"{x:486,y:748,t:1528143523014};\\\", \\\"{x:485,y:748,t:1528143523038};\\\", \\\"{x:487,y:748,t:1528143523117};\\\", \\\"{x:487,y:747,t:1528143523131};\\\", \\\"{x:488,y:744,t:1528143523148};\\\", \\\"{x:488,y:740,t:1528143523165};\\\", \\\"{x:489,y:739,t:1528143523253};\\\" ] }, { \\\"rt\\\": 61168, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 12, \\\"time_elapsed\\\": 670241, \\\"internal_node_id\\\": \\\"0.0-6.0-2.0\\\", \\\"subject\\\": \\\"06217\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"zulu\\\", \\\"condition\\\": \\\"211\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"duration+contained\\\", \\\"q\\\": 8, \\\"clicks\\\": 1.5, \\\"explicit\\\": 2, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XInside-YFull\\\", \\\"correct\\\": 1, \\\"orth_correct\\\": 0, \\\"answer\\\": [ \\\"G\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-B -F -F -E -G -C -G -G -E -E -X -C -C -C -O -G -G -B -B -B -F -F -F -F -B -F \\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:490,y:739,t:1528143527663};\\\", \\\"{x:490,y:738,t:1528143527691};\\\", \\\"{x:490,y:737,t:1528143527702};\\\", \\\"{x:490,y:736,t:1528143527765};\\\", \\\"{x:490,y:735,t:1528143527781};\\\", \\\"{x:491,y:734,t:1528143527789};\\\", \\\"{x:493,y:733,t:1528143527802};\\\", \\\"{x:506,y:728,t:1528143527819};\\\", \\\"{x:534,y:721,t:1528143527836};\\\", \\\"{x:562,y:713,t:1528143527853};\\\", \\\"{x:616,y:693,t:1528143527870};\\\", \\\"{x:693,y:661,t:1528143527887};\\\", \\\"{x:785,y:612,t:1528143527903};\\\", \\\"{x:860,y:567,t:1528143527919};\\\", \\\"{x:900,y:544,t:1528143527936};\\\", \\\"{x:916,y:536,t:1528143527952};\\\", \\\"{x:919,y:536,t:1528143527969};\\\", \\\"{x:919,y:535,t:1528143527986};\\\", \\\"{x:922,y:534,t:1528143528069};\\\", \\\"{x:926,y:533,t:1528143528086};\\\", \\\"{x:928,y:531,t:1528143528102};\\\", \\\"{x:929,y:531,t:1528143528120};\\\", \\\"{x:932,y:530,t:1528143528136};\\\", \\\"{x:934,y:530,t:1528143528153};\\\", \\\"{x:936,y:529,t:1528143528170};\\\", \\\"{x:941,y:528,t:1528143528187};\\\", \\\"{x:951,y:527,t:1528143528204};\\\", \\\"{x:969,y:527,t:1528143528219};\\\", \\\"{x:986,y:527,t:1528143528236};\\\", \\\"{x:996,y:529,t:1528143528252};\\\", \\\"{x:1013,y:538,t:1528143528269};\\\", \\\"{x:1024,y:540,t:1528143528286};\\\", \\\"{x:1032,y:542,t:1528143528303};\\\", \\\"{x:1034,y:543,t:1528143528319};\\\", \\\"{x:1035,y:543,t:1528143528336};\\\", \\\"{x:1037,y:542,t:1528143528381};\\\", \\\"{x:1042,y:537,t:1528143528390};\\\", \\\"{x:1048,y:528,t:1528143528404};\\\", \\\"{x:1064,y:515,t:1528143528419};\\\", \\\"{x:1080,y:500,t:1528143528436};\\\", \\\"{x:1092,y:487,t:1528143528454};\\\", \\\"{x:1095,y:482,t:1528143528470};\\\", \\\"{x:1095,y:480,t:1528143528487};\\\", \\\"{x:1096,y:479,t:1528143528504};\\\", \\\"{x:1097,y:478,t:1528143528727};\\\", \\\"{x:1097,y:477,t:1528143528737};\\\", \\\"{x:1098,y:477,t:1528143528806};\\\", \\\"{x:1098,y:476,t:1528143528820};\\\", \\\"{x:1099,y:475,t:1528143528837};\\\", \\\"{x:1100,y:474,t:1528143529446};\\\", \\\"{x:1100,y:475,t:1528143529614};\\\", \\\"{x:1100,y:476,t:1528143529622};\\\", \\\"{x:1100,y:479,t:1528143529638};\\\", \\\"{x:1101,y:481,t:1528143529654};\\\", \\\"{x:1101,y:482,t:1528143529671};\\\", \\\"{x:1101,y:483,t:1528143529688};\\\", \\\"{x:1101,y:485,t:1528143529704};\\\", \\\"{x:1101,y:488,t:1528143529721};\\\", \\\"{x:1100,y:489,t:1528143529738};\\\", \\\"{x:1100,y:490,t:1528143529755};\\\", \\\"{x:1100,y:491,t:1528143529774};\\\", \\\"{x:1098,y:492,t:1528143529959};\\\", \\\"{x:1098,y:493,t:1528143530014};\\\", \\\"{x:1097,y:493,t:1528143530118};\\\", \\\"{x:1096,y:501,t:1528143531007};\\\", \\\"{x:1111,y:545,t:1528143531022};\\\", \\\"{x:1144,y:605,t:1528143531039};\\\", \\\"{x:1176,y:645,t:1528143531055};\\\", \\\"{x:1203,y:669,t:1528143531072};\\\", \\\"{x:1243,y:693,t:1528143531089};\\\", \\\"{x:1273,y:718,t:1528143531106};\\\", \\\"{x:1303,y:739,t:1528143531123};\\\", \\\"{x:1327,y:757,t:1528143531140};\\\", \\\"{x:1341,y:769,t:1528143531156};\\\", \\\"{x:1350,y:776,t:1528143531172};\\\", \\\"{x:1350,y:780,t:1528143531189};\\\", \\\"{x:1353,y:785,t:1528143531206};\\\", \\\"{x:1356,y:790,t:1528143531222};\\\", \\\"{x:1357,y:794,t:1528143531239};\\\", \\\"{x:1357,y:793,t:1528143531381};\\\", \\\"{x:1357,y:791,t:1528143531389};\\\", \\\"{x:1357,y:779,t:1528143531405};\\\", \\\"{x:1356,y:770,t:1528143531422};\\\", \\\"{x:1356,y:765,t:1528143531438};\\\", \\\"{x:1355,y:761,t:1528143531456};\\\", \\\"{x:1355,y:760,t:1528143531472};\\\", \\\"{x:1355,y:759,t:1528143531489};\\\", \\\"{x:1354,y:759,t:1528143531646};\\\", \\\"{x:1353,y:759,t:1528143531655};\\\", \\\"{x:1350,y:761,t:1528143531673};\\\", \\\"{x:1350,y:762,t:1528143531689};\\\", \\\"{x:1349,y:762,t:1528143531709};\\\", \\\"{x:1348,y:762,t:1528143531773};\\\", \\\"{x:1347,y:762,t:1528143531788};\\\", \\\"{x:1346,y:762,t:1528143531805};\\\", \\\"{x:1345,y:763,t:1528143531823};\\\", \\\"{x:1344,y:763,t:1528143531838};\\\", \\\"{x:1343,y:763,t:1528143531856};\\\", \\\"{x:1342,y:763,t:1528143531894};\\\", \\\"{x:1341,y:765,t:1528143531912};\\\", \\\"{x:1340,y:765,t:1528143531934};\\\", \\\"{x:1338,y:759,t:1528143533864};\\\", \\\"{x:1338,y:755,t:1528143533873};\\\", \\\"{x:1338,y:744,t:1528143533890};\\\", \\\"{x:1338,y:737,t:1528143533908};\\\", \\\"{x:1340,y:733,t:1528143533924};\\\", \\\"{x:1340,y:729,t:1528143533940};\\\", \\\"{x:1340,y:727,t:1528143533957};\\\", \\\"{x:1340,y:723,t:1528143533974};\\\", \\\"{x:1340,y:720,t:1528143533991};\\\", \\\"{x:1340,y:719,t:1528143534008};\\\", \\\"{x:1340,y:717,t:1528143534023};\\\", \\\"{x:1340,y:715,t:1528143534041};\\\", \\\"{x:1340,y:714,t:1528143534058};\\\", \\\"{x:1340,y:713,t:1528143534075};\\\", \\\"{x:1340,y:712,t:1528143534091};\\\", \\\"{x:1341,y:712,t:1528143534109};\\\", \\\"{x:1341,y:711,t:1528143534125};\\\", \\\"{x:1342,y:710,t:1528143534295};\\\", \\\"{x:1343,y:709,t:1528143534308};\\\", \\\"{x:1344,y:708,t:1528143534350};\\\", \\\"{x:1344,y:707,t:1528143534366};\\\", \\\"{x:1345,y:706,t:1528143534469};\\\", \\\"{x:1345,y:705,t:1528143534613};\\\", \\\"{x:1347,y:704,t:1528143534624};\\\", \\\"{x:1349,y:703,t:1528143534645};\\\", \\\"{x:1350,y:703,t:1528143534658};\\\", \\\"{x:1350,y:702,t:1528143534822};\\\", \\\"{x:1351,y:702,t:1528143535342};\\\", \\\"{x:1352,y:702,t:1528143535390};\\\", \\\"{x:1353,y:702,t:1528143535422};\\\", \\\"{x:1355,y:702,t:1528143535502};\\\", \\\"{x:1356,y:702,t:1528143535542};\\\", \\\"{x:1356,y:699,t:1528143536654};\\\", \\\"{x:1356,y:698,t:1528143536662};\\\", \\\"{x:1356,y:697,t:1528143536676};\\\", \\\"{x:1356,y:696,t:1528143536694};\\\", \\\"{x:1356,y:695,t:1528143536710};\\\", \\\"{x:1356,y:694,t:1528143537438};\\\", \\\"{x:1356,y:693,t:1528143537822};\\\", \\\"{x:1355,y:693,t:1528143539942};\\\", \\\"{x:1352,y:693,t:1528143539951};\\\", \\\"{x:1348,y:693,t:1528143539962};\\\", \\\"{x:1345,y:693,t:1528143539979};\\\", \\\"{x:1343,y:693,t:1528143539997};\\\", \\\"{x:1342,y:693,t:1528143540013};\\\", \\\"{x:1342,y:694,t:1528143540103};\\\", \\\"{x:1342,y:695,t:1528143540206};\\\", \\\"{x:1342,y:697,t:1528143540229};\\\", \\\"{x:1342,y:698,t:1528143540430};\\\", \\\"{x:1342,y:697,t:1528143542286};\\\", \\\"{x:1340,y:691,t:1528143542299};\\\", \\\"{x:1340,y:689,t:1528143542315};\\\", \\\"{x:1338,y:685,t:1528143542332};\\\", \\\"{x:1338,y:682,t:1528143542348};\\\", \\\"{x:1338,y:678,t:1528143542365};\\\", \\\"{x:1340,y:674,t:1528143542382};\\\", \\\"{x:1340,y:672,t:1528143543902};\\\", \\\"{x:1340,y:669,t:1528143543916};\\\", \\\"{x:1337,y:663,t:1528143543932};\\\", \\\"{x:1333,y:653,t:1528143543950};\\\", \\\"{x:1331,y:646,t:1528143543965};\\\", \\\"{x:1327,y:639,t:1528143543982};\\\", \\\"{x:1322,y:630,t:1528143544000};\\\", \\\"{x:1320,y:623,t:1528143544015};\\\", \\\"{x:1314,y:613,t:1528143544033};\\\", \\\"{x:1309,y:604,t:1528143544049};\\\", \\\"{x:1304,y:597,t:1528143544066};\\\", \\\"{x:1297,y:587,t:1528143544082};\\\", \\\"{x:1289,y:581,t:1528143544099};\\\", \\\"{x:1284,y:577,t:1528143544116};\\\", \\\"{x:1283,y:575,t:1528143544132};\\\", \\\"{x:1283,y:573,t:1528143544150};\\\", \\\"{x:1283,y:572,t:1528143544166};\\\", \\\"{x:1282,y:572,t:1528143544182};\\\", \\\"{x:1282,y:570,t:1528143544629};\\\", \\\"{x:1282,y:569,t:1528143544637};\\\", \\\"{x:1282,y:568,t:1528143544654};\\\", \\\"{x:1282,y:567,t:1528143544666};\\\", \\\"{x:1282,y:565,t:1528143544683};\\\", \\\"{x:1282,y:562,t:1528143544699};\\\", \\\"{x:1282,y:560,t:1528143544716};\\\", \\\"{x:1282,y:559,t:1528143544749};\\\", \\\"{x:1283,y:559,t:1528143549366};\\\", \\\"{x:1285,y:559,t:1528143549373};\\\", \\\"{x:1294,y:560,t:1528143549387};\\\", \\\"{x:1331,y:567,t:1528143549404};\\\", \\\"{x:1381,y:575,t:1528143549420};\\\", \\\"{x:1431,y:575,t:1528143549437};\\\", \\\"{x:1488,y:575,t:1528143549453};\\\", \\\"{x:1505,y:575,t:1528143549470};\\\", \\\"{x:1509,y:575,t:1528143549487};\\\", \\\"{x:1503,y:575,t:1528143549702};\\\", \\\"{x:1496,y:576,t:1528143549709};\\\", \\\"{x:1486,y:578,t:1528143549721};\\\", \\\"{x:1471,y:580,t:1528143549737};\\\", \\\"{x:1461,y:581,t:1528143549754};\\\", \\\"{x:1457,y:583,t:1528143549771};\\\", \\\"{x:1456,y:583,t:1528143550150};\\\", \\\"{x:1455,y:583,t:1528143550158};\\\", \\\"{x:1454,y:582,t:1528143550171};\\\", \\\"{x:1454,y:581,t:1528143550188};\\\", \\\"{x:1452,y:581,t:1528143550204};\\\", \\\"{x:1451,y:580,t:1528143550221};\\\", \\\"{x:1449,y:579,t:1528143550238};\\\", \\\"{x:1448,y:578,t:1528143550255};\\\", \\\"{x:1447,y:578,t:1528143550271};\\\", \\\"{x:1446,y:577,t:1528143550288};\\\", \\\"{x:1445,y:577,t:1528143550310};\\\", \\\"{x:1444,y:577,t:1528143550321};\\\", \\\"{x:1442,y:575,t:1528143550338};\\\", \\\"{x:1439,y:574,t:1528143550355};\\\", \\\"{x:1438,y:573,t:1528143550371};\\\", \\\"{x:1437,y:573,t:1528143550390};\\\", \\\"{x:1436,y:573,t:1528143550413};\\\", \\\"{x:1434,y:571,t:1528143550429};\\\", \\\"{x:1433,y:571,t:1528143550438};\\\", \\\"{x:1432,y:570,t:1528143550470};\\\", \\\"{x:1431,y:570,t:1528143550494};\\\", \\\"{x:1430,y:569,t:1528143550505};\\\", \\\"{x:1428,y:568,t:1528143550521};\\\", \\\"{x:1427,y:567,t:1528143550558};\\\", \\\"{x:1426,y:566,t:1528143550589};\\\", \\\"{x:1425,y:565,t:1528143550605};\\\", \\\"{x:1424,y:564,t:1528143550621};\\\", \\\"{x:1423,y:564,t:1528143550638};\\\", \\\"{x:1422,y:564,t:1528143550662};\\\", \\\"{x:1419,y:563,t:1528143550711};\\\", \\\"{x:1418,y:561,t:1528143550738};\\\", \\\"{x:1417,y:561,t:1528143550798};\\\", \\\"{x:1416,y:561,t:1528143550829};\\\", \\\"{x:1415,y:561,t:1528143550837};\\\", \\\"{x:1414,y:561,t:1528143550855};\\\", \\\"{x:1412,y:561,t:1528143552254};\\\", \\\"{x:1398,y:563,t:1528143552263};\\\", \\\"{x:1370,y:567,t:1528143552274};\\\", \\\"{x:1279,y:581,t:1528143552289};\\\", \\\"{x:1118,y:583,t:1528143552306};\\\", \\\"{x:940,y:590,t:1528143552324};\\\", \\\"{x:793,y:592,t:1528143552338};\\\", \\\"{x:698,y:589,t:1528143552355};\\\", \\\"{x:646,y:589,t:1528143552372};\\\", \\\"{x:637,y:589,t:1528143552388};\\\", \\\"{x:635,y:589,t:1528143552405};\\\", \\\"{x:634,y:589,t:1528143552477};\\\", \\\"{x:633,y:589,t:1528143552589};\\\", \\\"{x:626,y:590,t:1528143552606};\\\", \\\"{x:600,y:593,t:1528143552623};\\\", \\\"{x:544,y:593,t:1528143552640};\\\", \\\"{x:466,y:593,t:1528143552658};\\\", \\\"{x:372,y:593,t:1528143552672};\\\", \\\"{x:294,y:593,t:1528143552688};\\\", \\\"{x:249,y:593,t:1528143552705};\\\", \\\"{x:225,y:593,t:1528143552722};\\\", \\\"{x:218,y:593,t:1528143552739};\\\", \\\"{x:216,y:590,t:1528143552756};\\\", \\\"{x:215,y:585,t:1528143552772};\\\", \\\"{x:211,y:579,t:1528143552790};\\\", \\\"{x:201,y:573,t:1528143552807};\\\", \\\"{x:185,y:569,t:1528143552823};\\\", \\\"{x:166,y:565,t:1528143552840};\\\", \\\"{x:155,y:560,t:1528143552857};\\\", \\\"{x:151,y:558,t:1528143552872};\\\", \\\"{x:151,y:556,t:1528143552892};\\\", \\\"{x:151,y:554,t:1528143552909};\\\", \\\"{x:151,y:553,t:1528143552924};\\\", \\\"{x:151,y:552,t:1528143552973};\\\", \\\"{x:151,y:551,t:1528143553014};\\\", \\\"{x:151,y:550,t:1528143553022};\\\", \\\"{x:149,y:549,t:1528143553039};\\\", \\\"{x:148,y:548,t:1528143553058};\\\", \\\"{x:148,y:547,t:1528143553073};\\\", \\\"{x:147,y:545,t:1528143553089};\\\", \\\"{x:146,y:544,t:1528143553106};\\\", \\\"{x:145,y:543,t:1528143553124};\\\", \\\"{x:145,y:538,t:1528143553139};\\\", \\\"{x:144,y:536,t:1528143553157};\\\", \\\"{x:143,y:533,t:1528143553173};\\\", \\\"{x:143,y:532,t:1528143553197};\\\", \\\"{x:143,y:530,t:1528143553214};\\\", \\\"{x:144,y:529,t:1528143553228};\\\", \\\"{x:145,y:528,t:1528143553244};\\\", \\\"{x:146,y:528,t:1528143553260};\\\", \\\"{x:146,y:527,t:1528143553273};\\\", \\\"{x:147,y:527,t:1528143553290};\\\", \\\"{x:149,y:527,t:1528143553309};\\\", \\\"{x:151,y:527,t:1528143553323};\\\", \\\"{x:154,y:528,t:1528143553340};\\\", \\\"{x:159,y:534,t:1528143553356};\\\", \\\"{x:162,y:547,t:1528143553373};\\\", \\\"{x:164,y:559,t:1528143553391};\\\", \\\"{x:165,y:576,t:1528143553407};\\\", \\\"{x:166,y:590,t:1528143553424};\\\", \\\"{x:167,y:598,t:1528143553440};\\\", \\\"{x:168,y:607,t:1528143553456};\\\", \\\"{x:170,y:610,t:1528143553474};\\\", \\\"{x:178,y:616,t:1528143553490};\\\", \\\"{x:188,y:619,t:1528143553506};\\\", \\\"{x:215,y:620,t:1528143553524};\\\", \\\"{x:299,y:620,t:1528143553541};\\\", \\\"{x:385,y:620,t:1528143553556};\\\", \\\"{x:479,y:620,t:1528143553573};\\\", \\\"{x:552,y:610,t:1528143553592};\\\", \\\"{x:596,y:606,t:1528143553606};\\\", \\\"{x:619,y:601,t:1528143553623};\\\", \\\"{x:628,y:598,t:1528143553641};\\\", \\\"{x:630,y:597,t:1528143553656};\\\", \\\"{x:637,y:596,t:1528143553725};\\\", \\\"{x:661,y:591,t:1528143553742};\\\", \\\"{x:674,y:590,t:1528143553756};\\\", \\\"{x:689,y:586,t:1528143553773};\\\", \\\"{x:709,y:583,t:1528143553791};\\\", \\\"{x:730,y:576,t:1528143553807};\\\", \\\"{x:739,y:572,t:1528143553824};\\\", \\\"{x:747,y:570,t:1528143553841};\\\", \\\"{x:750,y:568,t:1528143553857};\\\", \\\"{x:751,y:567,t:1528143553874};\\\", \\\"{x:752,y:567,t:1528143553891};\\\", \\\"{x:755,y:565,t:1528143553907};\\\", \\\"{x:755,y:564,t:1528143553981};\\\", \\\"{x:755,y:563,t:1528143554086};\\\", \\\"{x:757,y:561,t:1528143554151};\\\", \\\"{x:761,y:560,t:1528143554157};\\\", \\\"{x:766,y:557,t:1528143554174};\\\", \\\"{x:772,y:556,t:1528143554190};\\\", \\\"{x:777,y:554,t:1528143554208};\\\", \\\"{x:784,y:553,t:1528143554224};\\\", \\\"{x:792,y:550,t:1528143554241};\\\", \\\"{x:802,y:549,t:1528143554258};\\\", \\\"{x:810,y:548,t:1528143554273};\\\", \\\"{x:817,y:547,t:1528143554290};\\\", \\\"{x:821,y:547,t:1528143554308};\\\", \\\"{x:822,y:547,t:1528143554325};\\\", \\\"{x:822,y:546,t:1528143554709};\\\", \\\"{x:830,y:545,t:1528143554726};\\\", \\\"{x:835,y:544,t:1528143554742};\\\", \\\"{x:840,y:542,t:1528143554757};\\\", \\\"{x:859,y:549,t:1528143554775};\\\", \\\"{x:902,y:564,t:1528143554794};\\\", \\\"{x:1001,y:574,t:1528143554809};\\\", \\\"{x:1121,y:578,t:1528143554824};\\\", \\\"{x:1240,y:578,t:1528143554841};\\\", \\\"{x:1343,y:578,t:1528143554858};\\\", \\\"{x:1420,y:578,t:1528143554875};\\\", \\\"{x:1441,y:578,t:1528143554890};\\\", \\\"{x:1440,y:579,t:1528143554940};\\\", \\\"{x:1437,y:579,t:1528143554957};\\\", \\\"{x:1436,y:580,t:1528143555030};\\\", \\\"{x:1433,y:581,t:1528143555042};\\\", \\\"{x:1427,y:582,t:1528143555058};\\\", \\\"{x:1423,y:582,t:1528143555075};\\\", \\\"{x:1422,y:582,t:1528143555150};\\\", \\\"{x:1421,y:582,t:1528143555158};\\\", \\\"{x:1421,y:581,t:1528143555176};\\\", \\\"{x:1419,y:579,t:1528143555192};\\\", \\\"{x:1419,y:578,t:1528143555208};\\\", \\\"{x:1419,y:575,t:1528143555226};\\\", \\\"{x:1419,y:574,t:1528143555242};\\\", \\\"{x:1419,y:572,t:1528143555258};\\\", \\\"{x:1418,y:572,t:1528143555275};\\\", \\\"{x:1418,y:570,t:1528143555302};\\\", \\\"{x:1418,y:578,t:1528143555990};\\\", \\\"{x:1420,y:588,t:1528143555997};\\\", \\\"{x:1426,y:598,t:1528143556009};\\\", \\\"{x:1437,y:619,t:1528143556026};\\\", \\\"{x:1448,y:632,t:1528143556043};\\\", \\\"{x:1452,y:639,t:1528143556060};\\\", \\\"{x:1456,y:645,t:1528143556076};\\\", \\\"{x:1456,y:647,t:1528143556093};\\\", \\\"{x:1457,y:649,t:1528143556109};\\\", \\\"{x:1458,y:650,t:1528143556126};\\\", \\\"{x:1458,y:649,t:1528143556281};\\\", \\\"{x:1452,y:644,t:1528143556292};\\\", \\\"{x:1434,y:634,t:1528143556309};\\\", \\\"{x:1427,y:629,t:1528143556326};\\\", \\\"{x:1422,y:624,t:1528143556342};\\\", \\\"{x:1420,y:620,t:1528143556358};\\\", \\\"{x:1417,y:614,t:1528143556376};\\\", \\\"{x:1413,y:608,t:1528143556392};\\\", \\\"{x:1409,y:601,t:1528143556408};\\\", \\\"{x:1400,y:595,t:1528143556426};\\\", \\\"{x:1392,y:591,t:1528143556442};\\\", \\\"{x:1389,y:589,t:1528143556459};\\\", \\\"{x:1388,y:588,t:1528143556476};\\\", \\\"{x:1386,y:586,t:1528143556492};\\\", \\\"{x:1382,y:584,t:1528143556509};\\\", \\\"{x:1381,y:582,t:1528143556525};\\\", \\\"{x:1381,y:581,t:1528143556542};\\\", \\\"{x:1379,y:580,t:1528143556598};\\\", \\\"{x:1379,y:579,t:1528143556796};\\\", \\\"{x:1379,y:578,t:1528143556813};\\\", \\\"{x:1379,y:576,t:1528143556845};\\\", \\\"{x:1380,y:576,t:1528143556885};\\\", \\\"{x:1381,y:576,t:1528143556942};\\\", \\\"{x:1382,y:575,t:1528143556966};\\\", \\\"{x:1386,y:574,t:1528143556976};\\\", \\\"{x:1391,y:572,t:1528143556993};\\\", \\\"{x:1394,y:571,t:1528143557009};\\\", \\\"{x:1395,y:570,t:1528143557470};\\\", \\\"{x:1397,y:569,t:1528143557477};\\\", \\\"{x:1398,y:568,t:1528143557493};\\\", \\\"{x:1399,y:568,t:1528143557510};\\\", \\\"{x:1399,y:567,t:1528143557526};\\\", \\\"{x:1400,y:567,t:1528143557543};\\\", \\\"{x:1402,y:567,t:1528143557566};\\\", \\\"{x:1402,y:566,t:1528143557576};\\\", \\\"{x:1403,y:565,t:1528143557685};\\\", \\\"{x:1406,y:565,t:1528143557701};\\\", \\\"{x:1410,y:564,t:1528143557710};\\\", \\\"{x:1417,y:561,t:1528143557726};\\\", \\\"{x:1419,y:560,t:1528143557743};\\\", \\\"{x:1420,y:560,t:1528143557761};\\\", \\\"{x:1422,y:559,t:1528143557777};\\\", \\\"{x:1418,y:559,t:1528143558078};\\\", \\\"{x:1408,y:562,t:1528143558094};\\\", \\\"{x:1400,y:566,t:1528143558111};\\\", \\\"{x:1396,y:567,t:1528143558127};\\\", \\\"{x:1394,y:568,t:1528143558143};\\\", \\\"{x:1393,y:568,t:1528143558165};\\\", \\\"{x:1392,y:568,t:1528143558198};\\\", \\\"{x:1391,y:569,t:1528143558210};\\\", \\\"{x:1390,y:569,t:1528143558227};\\\", \\\"{x:1388,y:570,t:1528143558243};\\\", \\\"{x:1385,y:570,t:1528143558261};\\\", \\\"{x:1374,y:570,t:1528143558278};\\\", \\\"{x:1369,y:570,t:1528143558293};\\\", \\\"{x:1362,y:570,t:1528143558310};\\\", \\\"{x:1359,y:570,t:1528143558327};\\\", \\\"{x:1357,y:570,t:1528143558366};\\\", \\\"{x:1355,y:570,t:1528143558377};\\\", \\\"{x:1352,y:569,t:1528143558393};\\\", \\\"{x:1341,y:565,t:1528143558411};\\\", \\\"{x:1323,y:560,t:1528143558428};\\\", \\\"{x:1301,y:558,t:1528143558445};\\\", \\\"{x:1282,y:555,t:1528143558460};\\\", \\\"{x:1270,y:554,t:1528143558477};\\\", \\\"{x:1269,y:554,t:1528143558501};\\\", \\\"{x:1269,y:553,t:1528143558510};\\\", \\\"{x:1268,y:552,t:1528143558638};\\\", \\\"{x:1271,y:552,t:1528143558830};\\\", \\\"{x:1281,y:561,t:1528143558845};\\\", \\\"{x:1314,y:590,t:1528143558862};\\\", \\\"{x:1410,y:653,t:1528143558878};\\\", \\\"{x:1458,y:677,t:1528143558894};\\\", \\\"{x:1488,y:694,t:1528143558911};\\\", \\\"{x:1508,y:718,t:1528143558928};\\\", \\\"{x:1529,y:754,t:1528143558944};\\\", \\\"{x:1541,y:780,t:1528143558960};\\\", \\\"{x:1551,y:800,t:1528143558977};\\\", \\\"{x:1555,y:813,t:1528143558995};\\\", \\\"{x:1556,y:814,t:1528143559012};\\\", \\\"{x:1557,y:817,t:1528143559028};\\\", \\\"{x:1557,y:818,t:1528143559044};\\\", \\\"{x:1554,y:820,t:1528143559061};\\\", \\\"{x:1544,y:820,t:1528143559078};\\\", \\\"{x:1528,y:820,t:1528143559094};\\\", \\\"{x:1514,y:820,t:1528143559111};\\\", \\\"{x:1503,y:821,t:1528143559127};\\\", \\\"{x:1494,y:821,t:1528143559145};\\\", \\\"{x:1489,y:821,t:1528143559162};\\\", \\\"{x:1487,y:821,t:1528143559177};\\\", \\\"{x:1486,y:822,t:1528143559237};\\\", \\\"{x:1484,y:823,t:1528143559245};\\\", \\\"{x:1480,y:824,t:1528143559261};\\\", \\\"{x:1476,y:826,t:1528143559278};\\\", \\\"{x:1472,y:827,t:1528143559295};\\\", \\\"{x:1470,y:827,t:1528143559311};\\\", \\\"{x:1470,y:823,t:1528143559374};\\\", \\\"{x:1470,y:815,t:1528143559382};\\\", \\\"{x:1474,y:804,t:1528143559394};\\\", \\\"{x:1484,y:764,t:1528143559413};\\\", \\\"{x:1493,y:703,t:1528143559427};\\\", \\\"{x:1493,y:655,t:1528143559444};\\\", \\\"{x:1487,y:593,t:1528143559462};\\\", \\\"{x:1484,y:576,t:1528143559477};\\\", \\\"{x:1474,y:559,t:1528143559495};\\\", \\\"{x:1458,y:545,t:1528143559512};\\\", \\\"{x:1432,y:532,t:1528143559527};\\\", \\\"{x:1403,y:525,t:1528143559544};\\\", \\\"{x:1388,y:519,t:1528143559562};\\\", \\\"{x:1383,y:515,t:1528143559578};\\\", \\\"{x:1382,y:514,t:1528143559594};\\\", \\\"{x:1382,y:512,t:1528143559612};\\\", \\\"{x:1381,y:511,t:1528143559629};\\\", \\\"{x:1379,y:511,t:1528143559678};\\\", \\\"{x:1377,y:517,t:1528143559695};\\\", \\\"{x:1383,y:542,t:1528143559711};\\\", \\\"{x:1394,y:559,t:1528143559728};\\\", \\\"{x:1411,y:571,t:1528143559744};\\\", \\\"{x:1426,y:581,t:1528143559762};\\\", \\\"{x:1443,y:599,t:1528143559778};\\\", \\\"{x:1459,y:628,t:1528143559794};\\\", \\\"{x:1486,y:688,t:1528143559814};\\\", \\\"{x:1498,y:709,t:1528143559828};\\\", \\\"{x:1508,y:728,t:1528143559844};\\\", \\\"{x:1518,y:740,t:1528143559861};\\\", \\\"{x:1522,y:746,t:1528143559877};\\\", \\\"{x:1524,y:751,t:1528143559894};\\\", \\\"{x:1525,y:755,t:1528143559911};\\\", \\\"{x:1527,y:764,t:1528143559928};\\\", \\\"{x:1532,y:775,t:1528143559944};\\\", \\\"{x:1538,y:784,t:1528143559961};\\\", \\\"{x:1542,y:793,t:1528143559978};\\\", \\\"{x:1545,y:799,t:1528143559993};\\\", \\\"{x:1546,y:805,t:1528143560011};\\\", \\\"{x:1547,y:810,t:1528143560027};\\\", \\\"{x:1549,y:814,t:1528143560043};\\\", \\\"{x:1549,y:810,t:1528143560118};\\\", \\\"{x:1546,y:801,t:1528143560128};\\\", \\\"{x:1535,y:776,t:1528143560145};\\\", \\\"{x:1510,y:721,t:1528143560161};\\\", \\\"{x:1479,y:664,t:1528143560178};\\\", \\\"{x:1460,y:636,t:1528143560195};\\\", \\\"{x:1450,y:622,t:1528143560212};\\\", \\\"{x:1446,y:611,t:1528143560228};\\\", \\\"{x:1443,y:605,t:1528143560246};\\\", \\\"{x:1442,y:601,t:1528143560261};\\\", \\\"{x:1441,y:600,t:1528143560278};\\\", \\\"{x:1441,y:601,t:1528143560414};\\\", \\\"{x:1441,y:605,t:1528143560428};\\\", \\\"{x:1443,y:613,t:1528143560446};\\\", \\\"{x:1444,y:617,t:1528143560461};\\\", \\\"{x:1446,y:620,t:1528143560478};\\\", \\\"{x:1446,y:622,t:1528143560558};\\\", \\\"{x:1447,y:623,t:1528143560565};\\\", \\\"{x:1447,y:624,t:1528143560581};\\\", \\\"{x:1447,y:625,t:1528143560596};\\\", \\\"{x:1448,y:626,t:1528143560612};\\\", \\\"{x:1448,y:627,t:1528143560628};\\\", \\\"{x:1449,y:628,t:1528143560645};\\\", \\\"{x:1449,y:629,t:1528143560701};\\\", \\\"{x:1449,y:634,t:1528143562782};\\\", \\\"{x:1460,y:653,t:1528143562797};\\\", \\\"{x:1476,y:675,t:1528143562813};\\\", \\\"{x:1480,y:678,t:1528143562830};\\\", \\\"{x:1481,y:679,t:1528143562886};\\\", \\\"{x:1482,y:681,t:1528143562897};\\\", \\\"{x:1484,y:684,t:1528143562914};\\\", \\\"{x:1488,y:689,t:1528143562930};\\\", \\\"{x:1492,y:695,t:1528143562946};\\\", \\\"{x:1496,y:700,t:1528143562963};\\\", \\\"{x:1498,y:706,t:1528143562980};\\\", \\\"{x:1500,y:710,t:1528143562996};\\\", \\\"{x:1501,y:712,t:1528143563013};\\\", \\\"{x:1502,y:714,t:1528143563029};\\\", \\\"{x:1502,y:716,t:1528143563046};\\\", \\\"{x:1502,y:720,t:1528143563064};\\\", \\\"{x:1504,y:726,t:1528143563080};\\\", \\\"{x:1505,y:733,t:1528143563096};\\\", \\\"{x:1506,y:738,t:1528143563114};\\\", \\\"{x:1506,y:740,t:1528143563130};\\\", \\\"{x:1506,y:744,t:1528143563146};\\\", \\\"{x:1507,y:747,t:1528143563164};\\\", \\\"{x:1508,y:749,t:1528143563180};\\\", \\\"{x:1509,y:753,t:1528143563196};\\\", \\\"{x:1511,y:758,t:1528143563214};\\\", \\\"{x:1512,y:760,t:1528143563230};\\\", \\\"{x:1514,y:762,t:1528143563246};\\\", \\\"{x:1514,y:763,t:1528143563598};\\\", \\\"{x:1514,y:764,t:1528143565077};\\\", \\\"{x:1510,y:767,t:1528143565085};\\\", \\\"{x:1506,y:774,t:1528143565098};\\\", \\\"{x:1502,y:781,t:1528143565114};\\\", \\\"{x:1501,y:785,t:1528143565132};\\\", \\\"{x:1500,y:788,t:1528143565148};\\\", \\\"{x:1498,y:792,t:1528143565165};\\\", \\\"{x:1497,y:801,t:1528143565181};\\\", \\\"{x:1494,y:810,t:1528143565198};\\\", \\\"{x:1493,y:817,t:1528143565214};\\\", \\\"{x:1492,y:826,t:1528143565231};\\\", \\\"{x:1490,y:831,t:1528143565247};\\\", \\\"{x:1489,y:836,t:1528143565265};\\\", \\\"{x:1488,y:840,t:1528143565282};\\\", \\\"{x:1483,y:850,t:1528143565298};\\\", \\\"{x:1472,y:858,t:1528143565314};\\\", \\\"{x:1454,y:866,t:1528143565331};\\\", \\\"{x:1430,y:869,t:1528143565349};\\\", \\\"{x:1383,y:871,t:1528143565365};\\\", \\\"{x:1277,y:871,t:1528143565382};\\\", \\\"{x:1194,y:871,t:1528143565398};\\\", \\\"{x:1135,y:864,t:1528143565415};\\\", \\\"{x:1100,y:858,t:1528143565431};\\\", \\\"{x:1083,y:854,t:1528143565448};\\\", \\\"{x:1075,y:852,t:1528143565465};\\\", \\\"{x:1067,y:852,t:1528143565481};\\\", \\\"{x:1057,y:850,t:1528143565499};\\\", \\\"{x:1035,y:849,t:1528143565514};\\\", \\\"{x:996,y:843,t:1528143565531};\\\", \\\"{x:935,y:835,t:1528143565548};\\\", \\\"{x:844,y:826,t:1528143565564};\\\", \\\"{x:698,y:806,t:1528143565581};\\\", \\\"{x:611,y:791,t:1528143565598};\\\", \\\"{x:572,y:786,t:1528143565614};\\\", \\\"{x:556,y:781,t:1528143565632};\\\", \\\"{x:549,y:776,t:1528143565648};\\\", \\\"{x:544,y:774,t:1528143565665};\\\", \\\"{x:541,y:770,t:1528143565681};\\\", \\\"{x:535,y:766,t:1528143565698};\\\", \\\"{x:526,y:760,t:1528143565715};\\\", \\\"{x:520,y:756,t:1528143565731};\\\", \\\"{x:509,y:749,t:1528143565749};\\\", \\\"{x:498,y:743,t:1528143565763};\\\", \\\"{x:486,y:739,t:1528143565781};\\\", \\\"{x:485,y:739,t:1528143565795};\\\", \\\"{x:482,y:739,t:1528143565811};\\\", \\\"{x:481,y:738,t:1528143565828};\\\", \\\"{x:481,y:736,t:1528143565876};\\\", \\\"{x:484,y:734,t:1528143565884};\\\", \\\"{x:488,y:732,t:1528143565895};\\\", \\\"{x:492,y:728,t:1528143565912};\\\", \\\"{x:496,y:722,t:1528143565929};\\\", \\\"{x:500,y:718,t:1528143565946};\\\", \\\"{x:502,y:713,t:1528143565962};\\\", \\\"{x:503,y:711,t:1528143565982};\\\", \\\"{x:507,y:711,t:1528143566221};\\\", \\\"{x:514,y:711,t:1528143566234};\\\", \\\"{x:533,y:711,t:1528143566251};\\\", \\\"{x:548,y:711,t:1528143566267};\\\", \\\"{x:564,y:711,t:1528143566284};\\\", \\\"{x:576,y:708,t:1528143566300};\\\", \\\"{x:591,y:704,t:1528143566317};\\\", \\\"{x:607,y:699,t:1528143566334};\\\", \\\"{x:629,y:693,t:1528143566350};\\\", \\\"{x:675,y:680,t:1528143566368};\\\", \\\"{x:750,y:662,t:1528143566385};\\\", \\\"{x:836,y:649,t:1528143566401};\\\", \\\"{x:958,y:630,t:1528143566418};\\\", \\\"{x:1090,y:620,t:1528143566435};\\\", \\\"{x:1218,y:615,t:1528143566451};\\\", \\\"{x:1338,y:607,t:1528143566468};\\\", \\\"{x:1438,y:596,t:1528143566485};\\\", \\\"{x:1481,y:590,t:1528143566500};\\\", \\\"{x:1490,y:589,t:1528143566518};\\\", \\\"{x:1491,y:589,t:1528143566581};\\\", \\\"{x:1492,y:585,t:1528143566598};\\\", \\\"{x:1493,y:583,t:1528143566606};\\\", \\\"{x:1494,y:581,t:1528143566617};\\\", \\\"{x:1495,y:577,t:1528143566635};\\\", \\\"{x:1498,y:572,t:1528143566652};\\\", \\\"{x:1501,y:569,t:1528143566668};\\\", \\\"{x:1502,y:567,t:1528143566684};\\\", \\\"{x:1502,y:566,t:1528143566702};\\\", \\\"{x:1502,y:565,t:1528143566717};\\\", \\\"{x:1502,y:562,t:1528143566735};\\\", \\\"{x:1495,y:562,t:1528143566751};\\\", \\\"{x:1487,y:562,t:1528143566768};\\\", \\\"{x:1479,y:562,t:1528143566784};\\\", \\\"{x:1472,y:561,t:1528143566802};\\\", \\\"{x:1467,y:561,t:1528143566818};\\\", \\\"{x:1461,y:561,t:1528143566835};\\\", \\\"{x:1455,y:561,t:1528143566852};\\\", \\\"{x:1444,y:561,t:1528143566867};\\\", \\\"{x:1434,y:561,t:1528143566885};\\\", \\\"{x:1409,y:561,t:1528143566901};\\\", \\\"{x:1384,y:561,t:1528143566918};\\\", \\\"{x:1339,y:561,t:1528143566935};\\\", \\\"{x:1267,y:561,t:1528143566952};\\\", \\\"{x:1164,y:547,t:1528143566968};\\\", \\\"{x:1056,y:533,t:1528143566984};\\\", \\\"{x:944,y:525,t:1528143567002};\\\", \\\"{x:855,y:512,t:1528143567020};\\\", \\\"{x:807,y:496,t:1528143567034};\\\", \\\"{x:782,y:489,t:1528143567051};\\\", \\\"{x:774,y:488,t:1528143567068};\\\", \\\"{x:771,y:488,t:1528143567125};\\\", \\\"{x:766,y:487,t:1528143567134};\\\", \\\"{x:749,y:486,t:1528143567152};\\\", \\\"{x:729,y:486,t:1528143567168};\\\", \\\"{x:704,y:486,t:1528143567184};\\\", \\\"{x:681,y:486,t:1528143567201};\\\", \\\"{x:662,y:488,t:1528143567219};\\\", \\\"{x:646,y:491,t:1528143567234};\\\", \\\"{x:633,y:494,t:1528143567251};\\\", \\\"{x:629,y:495,t:1528143567268};\\\", \\\"{x:626,y:497,t:1528143567284};\\\", \\\"{x:624,y:498,t:1528143567301};\\\", \\\"{x:622,y:498,t:1528143567318};\\\", \\\"{x:620,y:500,t:1528143567334};\\\", \\\"{x:619,y:501,t:1528143567351};\\\", \\\"{x:618,y:501,t:1528143567368};\\\", \\\"{x:618,y:502,t:1528143567385};\\\", \\\"{x:618,y:504,t:1528143567421};\\\", \\\"{x:620,y:507,t:1528143567435};\\\", \\\"{x:630,y:514,t:1528143567452};\\\", \\\"{x:650,y:518,t:1528143567470};\\\", \\\"{x:677,y:522,t:1528143567484};\\\", \\\"{x:707,y:526,t:1528143567502};\\\", \\\"{x:714,y:528,t:1528143567517};\\\", \\\"{x:715,y:529,t:1528143567573};\\\", \\\"{x:715,y:530,t:1528143567585};\\\", \\\"{x:707,y:534,t:1528143567601};\\\", \\\"{x:694,y:542,t:1528143567618};\\\", \\\"{x:690,y:543,t:1528143567635};\\\", \\\"{x:692,y:542,t:1528143567701};\\\", \\\"{x:702,y:539,t:1528143567719};\\\", \\\"{x:709,y:535,t:1528143567735};\\\", \\\"{x:717,y:533,t:1528143567751};\\\", \\\"{x:724,y:533,t:1528143567769};\\\", \\\"{x:729,y:533,t:1528143567785};\\\", \\\"{x:742,y:533,t:1528143567801};\\\", \\\"{x:757,y:534,t:1528143567819};\\\", \\\"{x:774,y:539,t:1528143567835};\\\", \\\"{x:782,y:540,t:1528143567851};\\\", \\\"{x:787,y:542,t:1528143567868};\\\", \\\"{x:791,y:542,t:1528143567884};\\\", \\\"{x:793,y:542,t:1528143567925};\\\", \\\"{x:794,y:542,t:1528143567949};\\\", \\\"{x:796,y:542,t:1528143567957};\\\", \\\"{x:797,y:542,t:1528143567969};\\\", \\\"{x:800,y:542,t:1528143567985};\\\", \\\"{x:804,y:542,t:1528143568002};\\\", \\\"{x:809,y:542,t:1528143568018};\\\", \\\"{x:818,y:541,t:1528143568035};\\\", \\\"{x:824,y:540,t:1528143568053};\\\", \\\"{x:827,y:539,t:1528143568068};\\\", \\\"{x:828,y:539,t:1528143568085};\\\", \\\"{x:833,y:538,t:1528143568348};\\\", \\\"{x:840,y:536,t:1528143568356};\\\", \\\"{x:845,y:533,t:1528143568369};\\\", \\\"{x:878,y:528,t:1528143568385};\\\", \\\"{x:978,y:528,t:1528143568402};\\\", \\\"{x:1122,y:528,t:1528143568419};\\\", \\\"{x:1266,y:528,t:1528143568435};\\\", \\\"{x:1396,y:528,t:1528143568452};\\\", \\\"{x:1493,y:528,t:1528143568468};\\\", \\\"{x:1499,y:528,t:1528143568486};\\\", \\\"{x:1497,y:528,t:1528143568510};\\\", \\\"{x:1489,y:528,t:1528143568519};\\\", \\\"{x:1474,y:528,t:1528143568535};\\\", \\\"{x:1461,y:530,t:1528143568552};\\\", \\\"{x:1455,y:533,t:1528143568569};\\\", \\\"{x:1453,y:533,t:1528143568585};\\\", \\\"{x:1453,y:534,t:1528143568603};\\\", \\\"{x:1451,y:536,t:1528143568620};\\\", \\\"{x:1446,y:541,t:1528143568636};\\\", \\\"{x:1435,y:551,t:1528143568652};\\\", \\\"{x:1416,y:562,t:1528143568669};\\\", \\\"{x:1409,y:564,t:1528143568686};\\\", \\\"{x:1408,y:564,t:1528143568704};\\\", \\\"{x:1405,y:566,t:1528143573965};\\\", \\\"{x:1400,y:575,t:1528143573974};\\\", \\\"{x:1388,y:615,t:1528143573991};\\\", \\\"{x:1379,y:653,t:1528143574008};\\\", \\\"{x:1375,y:669,t:1528143574024};\\\", \\\"{x:1370,y:678,t:1528143574041};\\\", \\\"{x:1365,y:688,t:1528143574057};\\\", \\\"{x:1364,y:692,t:1528143574075};\\\", \\\"{x:1364,y:697,t:1528143574091};\\\", \\\"{x:1363,y:702,t:1528143574108};\\\", \\\"{x:1360,y:710,t:1528143574125};\\\", \\\"{x:1357,y:716,t:1528143574141};\\\", \\\"{x:1353,y:720,t:1528143574159};\\\", \\\"{x:1349,y:727,t:1528143574175};\\\", \\\"{x:1345,y:731,t:1528143574191};\\\", \\\"{x:1341,y:735,t:1528143574207};\\\", \\\"{x:1338,y:739,t:1528143574225};\\\", \\\"{x:1338,y:740,t:1528143574241};\\\", \\\"{x:1338,y:742,t:1528143574258};\\\", \\\"{x:1337,y:745,t:1528143574275};\\\", \\\"{x:1337,y:746,t:1528143574292};\\\", \\\"{x:1337,y:748,t:1528143574308};\\\", \\\"{x:1337,y:749,t:1528143574420};\\\", \\\"{x:1337,y:751,t:1528143574468};\\\", \\\"{x:1337,y:752,t:1528143574500};\\\", \\\"{x:1337,y:753,t:1528143574604};\\\", \\\"{x:1339,y:754,t:1528143574636};\\\", \\\"{x:1340,y:755,t:1528143574644};\\\", \\\"{x:1342,y:755,t:1528143574660};\\\", \\\"{x:1344,y:755,t:1528143574674};\\\", \\\"{x:1345,y:755,t:1528143578919};\\\", \\\"{x:1348,y:746,t:1528143578926};\\\", \\\"{x:1349,y:739,t:1528143578939};\\\", \\\"{x:1349,y:732,t:1528143578955};\\\", \\\"{x:1349,y:729,t:1528143578971};\\\", \\\"{x:1349,y:726,t:1528143578988};\\\", \\\"{x:1349,y:728,t:1528143579367};\\\", \\\"{x:1348,y:732,t:1528143579374};\\\", \\\"{x:1347,y:737,t:1528143579388};\\\", \\\"{x:1345,y:742,t:1528143579405};\\\", \\\"{x:1344,y:751,t:1528143579422};\\\", \\\"{x:1344,y:754,t:1528143579438};\\\", \\\"{x:1344,y:757,t:1528143579455};\\\", \\\"{x:1342,y:759,t:1528143579473};\\\", \\\"{x:1342,y:760,t:1528143579488};\\\", \\\"{x:1342,y:762,t:1528143579519};\\\", \\\"{x:1342,y:763,t:1528143579550};\\\", \\\"{x:1342,y:761,t:1528143580023};\\\", \\\"{x:1342,y:750,t:1528143580039};\\\", \\\"{x:1342,y:727,t:1528143580056};\\\", \\\"{x:1344,y:700,t:1528143580072};\\\", \\\"{x:1348,y:680,t:1528143580090};\\\", \\\"{x:1348,y:667,t:1528143580106};\\\", \\\"{x:1348,y:657,t:1528143580122};\\\", \\\"{x:1348,y:650,t:1528143580140};\\\", \\\"{x:1349,y:647,t:1528143580156};\\\", \\\"{x:1349,y:645,t:1528143580173};\\\", \\\"{x:1349,y:646,t:1528143580319};\\\", \\\"{x:1349,y:648,t:1528143580326};\\\", \\\"{x:1349,y:653,t:1528143580340};\\\", \\\"{x:1349,y:660,t:1528143580357};\\\", \\\"{x:1349,y:664,t:1528143580373};\\\", \\\"{x:1349,y:668,t:1528143580389};\\\", \\\"{x:1349,y:670,t:1528143580406};\\\", \\\"{x:1349,y:672,t:1528143580423};\\\", \\\"{x:1349,y:673,t:1528143580439};\\\", \\\"{x:1349,y:674,t:1528143580470};\\\", \\\"{x:1349,y:675,t:1528143580502};\\\", \\\"{x:1349,y:676,t:1528143580854};\\\", \\\"{x:1349,y:677,t:1528143580935};\\\", \\\"{x:1348,y:679,t:1528143581262};\\\", \\\"{x:1348,y:680,t:1528143581273};\\\", \\\"{x:1348,y:685,t:1528143581290};\\\", \\\"{x:1348,y:689,t:1528143581307};\\\", \\\"{x:1348,y:693,t:1528143581324};\\\", \\\"{x:1348,y:697,t:1528143581340};\\\", \\\"{x:1348,y:701,t:1528143581357};\\\", \\\"{x:1349,y:704,t:1528143581374};\\\", \\\"{x:1349,y:706,t:1528143581390};\\\", \\\"{x:1349,y:707,t:1528143581407};\\\", \\\"{x:1349,y:710,t:1528143581470};\\\", \\\"{x:1349,y:711,t:1528143581478};\\\", \\\"{x:1349,y:712,t:1528143581490};\\\", \\\"{x:1349,y:714,t:1528143581507};\\\", \\\"{x:1349,y:716,t:1528143581524};\\\", \\\"{x:1349,y:718,t:1528143581540};\\\", \\\"{x:1348,y:721,t:1528143581557};\\\", \\\"{x:1348,y:724,t:1528143581575};\\\", \\\"{x:1348,y:727,t:1528143581590};\\\", \\\"{x:1348,y:730,t:1528143581607};\\\", \\\"{x:1348,y:731,t:1528143581624};\\\", \\\"{x:1348,y:733,t:1528143581640};\\\", \\\"{x:1348,y:734,t:1528143581657};\\\", \\\"{x:1348,y:737,t:1528143581674};\\\", \\\"{x:1348,y:739,t:1528143581690};\\\", \\\"{x:1348,y:742,t:1528143581708};\\\", \\\"{x:1348,y:743,t:1528143581725};\\\", \\\"{x:1348,y:745,t:1528143581757};\\\", \\\"{x:1347,y:746,t:1528143581845};\\\", \\\"{x:1347,y:747,t:1528143581857};\\\", \\\"{x:1346,y:749,t:1528143581874};\\\", \\\"{x:1345,y:750,t:1528143581890};\\\", \\\"{x:1344,y:752,t:1528143581934};\\\", \\\"{x:1343,y:753,t:1528143581950};\\\", \\\"{x:1343,y:755,t:1528143582110};\\\", \\\"{x:1343,y:756,t:1528143583238};\\\", \\\"{x:1342,y:755,t:1528143583319};\\\", \\\"{x:1342,y:754,t:1528143583342};\\\", \\\"{x:1342,y:752,t:1528143583359};\\\", \\\"{x:1342,y:750,t:1528143583375};\\\", \\\"{x:1342,y:745,t:1528143583392};\\\", \\\"{x:1342,y:738,t:1528143583409};\\\", \\\"{x:1343,y:733,t:1528143583426};\\\", \\\"{x:1344,y:727,t:1528143583442};\\\", \\\"{x:1345,y:723,t:1528143583459};\\\", \\\"{x:1346,y:719,t:1528143583475};\\\", \\\"{x:1346,y:716,t:1528143583492};\\\", \\\"{x:1347,y:712,t:1528143583509};\\\", \\\"{x:1347,y:711,t:1528143583526};\\\", \\\"{x:1347,y:710,t:1528143583550};\\\", \\\"{x:1347,y:709,t:1528143583575};\\\", \\\"{x:1347,y:708,t:1528143583638};\\\", \\\"{x:1347,y:707,t:1528143583646};\\\", \\\"{x:1347,y:706,t:1528143583660};\\\", \\\"{x:1347,y:705,t:1528143583675};\\\", \\\"{x:1347,y:704,t:1528143583692};\\\", \\\"{x:1347,y:703,t:1528143583709};\\\", \\\"{x:1347,y:702,t:1528143583742};\\\", \\\"{x:1347,y:701,t:1528143583759};\\\", \\\"{x:1347,y:700,t:1528143583798};\\\", \\\"{x:1347,y:699,t:1528143583838};\\\", \\\"{x:1346,y:699,t:1528143584254};\\\", \\\"{x:1344,y:699,t:1528143584262};\\\", \\\"{x:1342,y:702,t:1528143584277};\\\", \\\"{x:1341,y:709,t:1528143584294};\\\", \\\"{x:1340,y:716,t:1528143584310};\\\", \\\"{x:1340,y:728,t:1528143584326};\\\", \\\"{x:1339,y:733,t:1528143584344};\\\", \\\"{x:1339,y:738,t:1528143584360};\\\", \\\"{x:1339,y:742,t:1528143584376};\\\", \\\"{x:1339,y:743,t:1528143584394};\\\", \\\"{x:1339,y:744,t:1528143584424};\\\", \\\"{x:1339,y:745,t:1528143584429};\\\", \\\"{x:1339,y:746,t:1528143584442};\\\", \\\"{x:1339,y:748,t:1528143584459};\\\", \\\"{x:1339,y:750,t:1528143584475};\\\", \\\"{x:1339,y:751,t:1528143584493};\\\", \\\"{x:1339,y:752,t:1528143584508};\\\", \\\"{x:1338,y:754,t:1528143584589};\\\", \\\"{x:1337,y:754,t:1528143584597};\\\", \\\"{x:1335,y:755,t:1528143584610};\\\", \\\"{x:1324,y:758,t:1528143584625};\\\", \\\"{x:1304,y:762,t:1528143584643};\\\", \\\"{x:1275,y:764,t:1528143584660};\\\", \\\"{x:1233,y:764,t:1528143584676};\\\", \\\"{x:1153,y:764,t:1528143584693};\\\", \\\"{x:1002,y:801,t:1528143584710};\\\", \\\"{x:900,y:843,t:1528143584727};\\\", \\\"{x:848,y:864,t:1528143584743};\\\", \\\"{x:823,y:869,t:1528143584760};\\\", \\\"{x:818,y:869,t:1528143584776};\\\", \\\"{x:817,y:869,t:1528143584793};\\\", \\\"{x:814,y:869,t:1528143584810};\\\", \\\"{x:802,y:869,t:1528143584826};\\\", \\\"{x:767,y:869,t:1528143584843};\\\", \\\"{x:689,y:860,t:1528143584860};\\\", \\\"{x:595,y:844,t:1528143584877};\\\", \\\"{x:497,y:827,t:1528143584893};\\\", \\\"{x:388,y:807,t:1528143584910};\\\", \\\"{x:350,y:799,t:1528143584926};\\\", \\\"{x:332,y:795,t:1528143584943};\\\", \\\"{x:327,y:793,t:1528143584960};\\\", \\\"{x:326,y:792,t:1528143584982};\\\", \\\"{x:326,y:791,t:1528143584993};\\\", \\\"{x:326,y:786,t:1528143585010};\\\", \\\"{x:324,y:781,t:1528143585027};\\\", \\\"{x:320,y:774,t:1528143585043};\\\", \\\"{x:316,y:768,t:1528143585060};\\\", \\\"{x:313,y:763,t:1528143585077};\\\", \\\"{x:313,y:759,t:1528143585093};\\\", \\\"{x:312,y:756,t:1528143585110};\\\", \\\"{x:312,y:755,t:1528143585127};\\\", \\\"{x:312,y:754,t:1528143585143};\\\", \\\"{x:317,y:753,t:1528143585198};\\\", \\\"{x:323,y:753,t:1528143585210};\\\", \\\"{x:331,y:752,t:1528143585228};\\\", \\\"{x:341,y:752,t:1528143585243};\\\", \\\"{x:354,y:749,t:1528143585260};\\\", \\\"{x:368,y:747,t:1528143585277};\\\", \\\"{x:384,y:744,t:1528143585293};\\\", \\\"{x:392,y:743,t:1528143585310};\\\", \\\"{x:398,y:744,t:1528143585327};\\\", \\\"{x:403,y:744,t:1528143585344};\\\", \\\"{x:413,y:744,t:1528143585361};\\\", \\\"{x:425,y:744,t:1528143585378};\\\", \\\"{x:430,y:744,t:1528143585394};\\\", \\\"{x:431,y:744,t:1528143585410};\\\", \\\"{x:432,y:744,t:1528143585446};\\\", \\\"{x:434,y:744,t:1528143585460};\\\", \\\"{x:438,y:745,t:1528143585478};\\\", \\\"{x:447,y:745,t:1528143585495};\\\", \\\"{x:453,y:745,t:1528143585510};\\\", \\\"{x:459,y:744,t:1528143585527};\\\", \\\"{x:462,y:744,t:1528143585539};\\\", \\\"{x:464,y:743,t:1528143585556};\\\", \\\"{x:465,y:743,t:1528143585571};\\\", \\\"{x:467,y:742,t:1528143585589};\\\", \\\"{x:473,y:740,t:1528143585605};\\\", \\\"{x:475,y:739,t:1528143585623};\\\", \\\"{x:476,y:739,t:1528143585638};\\\", \\\"{x:477,y:739,t:1528143585655};\\\" ] }, { \\\"rt\\\": 81238, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 13, \\\"time_elapsed\\\": 753065, \\\"internal_node_id\\\": \\\"0.0-6.0-3.0\\\", \\\"subject\\\": \\\"06217\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"zulu\\\", \\\"condition\\\": \\\"211\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"starttime+before+endtime+during\\\", \\\"q\\\": 9, \\\"clicks\\\": 1, \\\"explicit\\\": 2, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XInside-YFull\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 0, \\\"answer\\\": [ \\\"E\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-E -E -E -E -J -I -E -J -A -A -11 AM-11 AM-B -M -M -B -B -J -J -08 AM-I -E -E -E -08 AM-E -E -E -F -F -M -12 PM-M -M -M -M -I \\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:484,y:738,t:1528143591471};\\\", \\\"{x:493,y:731,t:1528143591477};\\\", \\\"{x:500,y:729,t:1528143591491};\\\", \\\"{x:502,y:728,t:1528143591507};\\\", \\\"{x:504,y:726,t:1528143591694};\\\", \\\"{x:510,y:723,t:1528143591708};\\\", \\\"{x:526,y:718,t:1528143591724};\\\", \\\"{x:550,y:717,t:1528143591741};\\\", \\\"{x:577,y:717,t:1528143591757};\\\", \\\"{x:627,y:717,t:1528143591780};\\\", \\\"{x:695,y:717,t:1528143591797};\\\", \\\"{x:731,y:721,t:1528143591813};\\\", \\\"{x:771,y:733,t:1528143591830};\\\", \\\"{x:796,y:741,t:1528143591847};\\\", \\\"{x:817,y:747,t:1528143591863};\\\", \\\"{x:831,y:754,t:1528143591880};\\\", \\\"{x:846,y:766,t:1528143591897};\\\", \\\"{x:865,y:782,t:1528143591913};\\\", \\\"{x:901,y:803,t:1528143591930};\\\", \\\"{x:947,y:820,t:1528143591947};\\\", \\\"{x:993,y:837,t:1528143591963};\\\", \\\"{x:1035,y:848,t:1528143591980};\\\", \\\"{x:1110,y:870,t:1528143591997};\\\", \\\"{x:1152,y:883,t:1528143592013};\\\", \\\"{x:1195,y:897,t:1528143592031};\\\", \\\"{x:1229,y:907,t:1528143592048};\\\", \\\"{x:1247,y:910,t:1528143592063};\\\", \\\"{x:1255,y:912,t:1528143592081};\\\", \\\"{x:1256,y:912,t:1528143592097};\\\", \\\"{x:1257,y:912,t:1528143592134};\\\", \\\"{x:1259,y:912,t:1528143592148};\\\", \\\"{x:1262,y:900,t:1528143592165};\\\", \\\"{x:1263,y:888,t:1528143592180};\\\", \\\"{x:1266,y:869,t:1528143592197};\\\", \\\"{x:1266,y:863,t:1528143592214};\\\", \\\"{x:1266,y:858,t:1528143592230};\\\", \\\"{x:1266,y:854,t:1528143592247};\\\", \\\"{x:1265,y:852,t:1528143592265};\\\", \\\"{x:1263,y:852,t:1528143592326};\\\", \\\"{x:1262,y:852,t:1528143592334};\\\", \\\"{x:1254,y:853,t:1528143592347};\\\", \\\"{x:1251,y:855,t:1528143592365};\\\", \\\"{x:1246,y:857,t:1528143592382};\\\", \\\"{x:1245,y:857,t:1528143592398};\\\", \\\"{x:1244,y:857,t:1528143592590};\\\", \\\"{x:1243,y:857,t:1528143592598};\\\", \\\"{x:1241,y:854,t:1528143592615};\\\", \\\"{x:1241,y:853,t:1528143592632};\\\", \\\"{x:1240,y:852,t:1528143592719};\\\", \\\"{x:1239,y:849,t:1528143592732};\\\", \\\"{x:1236,y:844,t:1528143592747};\\\", \\\"{x:1232,y:837,t:1528143592764};\\\", \\\"{x:1229,y:829,t:1528143592782};\\\", \\\"{x:1227,y:821,t:1528143592798};\\\", \\\"{x:1224,y:815,t:1528143592815};\\\", \\\"{x:1224,y:811,t:1528143592832};\\\", \\\"{x:1224,y:806,t:1528143592849};\\\", \\\"{x:1224,y:802,t:1528143592865};\\\", \\\"{x:1224,y:801,t:1528143592881};\\\", \\\"{x:1225,y:799,t:1528143592898};\\\", \\\"{x:1225,y:798,t:1528143592914};\\\", \\\"{x:1225,y:797,t:1528143592932};\\\", \\\"{x:1225,y:795,t:1528143593374};\\\", \\\"{x:1225,y:793,t:1528143593383};\\\", \\\"{x:1219,y:789,t:1528143593399};\\\", \\\"{x:1215,y:787,t:1528143593416};\\\", \\\"{x:1214,y:786,t:1528143593518};\\\", \\\"{x:1213,y:786,t:1528143593542};\\\", \\\"{x:1212,y:785,t:1528143593558};\\\", \\\"{x:1212,y:784,t:1528143593566};\\\", \\\"{x:1211,y:782,t:1528143593582};\\\", \\\"{x:1210,y:780,t:1528143593599};\\\", \\\"{x:1209,y:780,t:1528143593616};\\\", \\\"{x:1205,y:779,t:1528143594007};\\\", \\\"{x:1205,y:778,t:1528143594016};\\\", \\\"{x:1202,y:778,t:1528143594033};\\\", \\\"{x:1201,y:778,t:1528143594054};\\\", \\\"{x:1200,y:778,t:1528143594069};\\\", \\\"{x:1199,y:778,t:1528143594086};\\\", \\\"{x:1198,y:778,t:1528143594099};\\\", \\\"{x:1196,y:778,t:1528143594116};\\\", \\\"{x:1194,y:779,t:1528143594133};\\\", \\\"{x:1192,y:781,t:1528143594150};\\\", \\\"{x:1191,y:781,t:1528143594166};\\\", \\\"{x:1190,y:781,t:1528143594183};\\\", \\\"{x:1190,y:782,t:1528143594200};\\\", \\\"{x:1189,y:782,t:1528143594230};\\\", \\\"{x:1188,y:782,t:1528143594246};\\\", \\\"{x:1187,y:783,t:1528143594294};\\\", \\\"{x:1187,y:784,t:1528143594310};\\\", \\\"{x:1187,y:788,t:1528143594318};\\\", \\\"{x:1187,y:795,t:1528143594333};\\\", \\\"{x:1189,y:807,t:1528143594349};\\\", \\\"{x:1189,y:810,t:1528143594366};\\\", \\\"{x:1190,y:812,t:1528143594383};\\\", \\\"{x:1191,y:814,t:1528143594400};\\\", \\\"{x:1192,y:814,t:1528143594454};\\\", \\\"{x:1193,y:817,t:1528143594467};\\\", \\\"{x:1195,y:820,t:1528143594483};\\\", \\\"{x:1198,y:822,t:1528143594499};\\\", \\\"{x:1201,y:824,t:1528143594516};\\\", \\\"{x:1202,y:824,t:1528143594550};\\\", \\\"{x:1203,y:824,t:1528143594566};\\\", \\\"{x:1204,y:824,t:1528143594590};\\\", \\\"{x:1204,y:819,t:1528143598862};\\\", \\\"{x:1211,y:797,t:1528143598870};\\\", \\\"{x:1226,y:764,t:1528143598887};\\\", \\\"{x:1232,y:739,t:1528143598904};\\\", \\\"{x:1244,y:715,t:1528143598921};\\\", \\\"{x:1249,y:674,t:1528143598936};\\\", \\\"{x:1250,y:652,t:1528143598953};\\\", \\\"{x:1256,y:632,t:1528143598970};\\\", \\\"{x:1261,y:619,t:1528143598986};\\\", \\\"{x:1262,y:612,t:1528143599003};\\\", \\\"{x:1263,y:605,t:1528143599021};\\\", \\\"{x:1265,y:599,t:1528143599036};\\\", \\\"{x:1268,y:591,t:1528143599053};\\\", \\\"{x:1272,y:586,t:1528143599071};\\\", \\\"{x:1274,y:584,t:1528143599086};\\\", \\\"{x:1276,y:583,t:1528143599104};\\\", \\\"{x:1277,y:581,t:1528143599125};\\\", \\\"{x:1278,y:581,t:1528143599142};\\\", \\\"{x:1279,y:581,t:1528143599165};\\\", \\\"{x:1279,y:573,t:1528143599790};\\\", \\\"{x:1278,y:562,t:1528143599808};\\\", \\\"{x:1278,y:552,t:1528143599821};\\\", \\\"{x:1278,y:542,t:1528143599837};\\\", \\\"{x:1278,y:539,t:1528143599854};\\\", \\\"{x:1278,y:538,t:1528143599871};\\\", \\\"{x:1278,y:537,t:1528143599925};\\\", \\\"{x:1278,y:536,t:1528143599937};\\\", \\\"{x:1278,y:534,t:1528143599955};\\\", \\\"{x:1278,y:529,t:1528143599972};\\\", \\\"{x:1278,y:527,t:1528143599988};\\\", \\\"{x:1278,y:525,t:1528143600005};\\\", \\\"{x:1278,y:523,t:1528143600021};\\\", \\\"{x:1278,y:522,t:1528143600037};\\\", \\\"{x:1278,y:521,t:1528143600070};\\\", \\\"{x:1277,y:521,t:1528143600510};\\\", \\\"{x:1275,y:522,t:1528143600522};\\\", \\\"{x:1276,y:530,t:1528143600539};\\\", \\\"{x:1278,y:536,t:1528143600555};\\\", \\\"{x:1279,y:540,t:1528143600572};\\\", \\\"{x:1280,y:543,t:1528143600589};\\\", \\\"{x:1280,y:544,t:1528143600605};\\\", \\\"{x:1281,y:546,t:1528143600622};\\\", \\\"{x:1282,y:548,t:1528143600639};\\\", \\\"{x:1282,y:551,t:1528143600655};\\\", \\\"{x:1283,y:552,t:1528143600672};\\\", \\\"{x:1283,y:554,t:1528143600689};\\\", \\\"{x:1283,y:555,t:1528143600705};\\\", \\\"{x:1283,y:557,t:1528143600726};\\\", \\\"{x:1283,y:558,t:1528143600742};\\\", \\\"{x:1283,y:560,t:1528143600789};\\\", \\\"{x:1283,y:564,t:1528143600958};\\\", \\\"{x:1283,y:584,t:1528143600973};\\\", \\\"{x:1283,y:654,t:1528143600989};\\\", \\\"{x:1283,y:762,t:1528143601005};\\\", \\\"{x:1280,y:811,t:1528143601022};\\\", \\\"{x:1278,y:840,t:1528143601039};\\\", \\\"{x:1275,y:856,t:1528143601056};\\\", \\\"{x:1273,y:864,t:1528143601072};\\\", \\\"{x:1270,y:867,t:1528143601089};\\\", \\\"{x:1268,y:871,t:1528143601106};\\\", \\\"{x:1267,y:872,t:1528143601122};\\\", \\\"{x:1266,y:872,t:1528143601141};\\\", \\\"{x:1265,y:872,t:1528143601155};\\\", \\\"{x:1263,y:872,t:1528143601173};\\\", \\\"{x:1258,y:872,t:1528143601189};\\\", \\\"{x:1250,y:871,t:1528143601206};\\\", \\\"{x:1244,y:868,t:1528143601223};\\\", \\\"{x:1233,y:860,t:1528143601240};\\\", \\\"{x:1226,y:849,t:1528143601256};\\\", \\\"{x:1219,y:840,t:1528143601273};\\\", \\\"{x:1211,y:833,t:1528143601289};\\\", \\\"{x:1208,y:832,t:1528143601306};\\\", \\\"{x:1207,y:832,t:1528143604854};\\\", \\\"{x:1207,y:833,t:1528143605558};\\\", \\\"{x:1207,y:832,t:1528143605693};\\\", \\\"{x:1207,y:830,t:1528143605710};\\\", \\\"{x:1208,y:829,t:1528143605728};\\\", \\\"{x:1208,y:827,t:1528143605744};\\\", \\\"{x:1208,y:826,t:1528143605760};\\\", \\\"{x:1208,y:824,t:1528143605777};\\\", \\\"{x:1208,y:821,t:1528143605793};\\\", \\\"{x:1208,y:820,t:1528143605814};\\\", \\\"{x:1208,y:819,t:1528143605827};\\\", \\\"{x:1208,y:817,t:1528143605843};\\\", \\\"{x:1208,y:815,t:1528143605861};\\\", \\\"{x:1208,y:811,t:1528143605877};\\\", \\\"{x:1208,y:808,t:1528143605893};\\\", \\\"{x:1208,y:804,t:1528143605910};\\\", \\\"{x:1205,y:796,t:1528143605927};\\\", \\\"{x:1200,y:790,t:1528143605943};\\\", \\\"{x:1197,y:787,t:1528143605960};\\\", \\\"{x:1189,y:780,t:1528143605977};\\\", \\\"{x:1182,y:776,t:1528143605993};\\\", \\\"{x:1180,y:774,t:1528143606010};\\\", \\\"{x:1179,y:773,t:1528143606027};\\\", \\\"{x:1178,y:772,t:1528143606043};\\\", \\\"{x:1177,y:771,t:1528143606060};\\\", \\\"{x:1176,y:770,t:1528143606086};\\\", \\\"{x:1174,y:770,t:1528143606262};\\\", \\\"{x:1177,y:767,t:1528143606733};\\\", \\\"{x:1185,y:762,t:1528143606743};\\\", \\\"{x:1200,y:754,t:1528143606761};\\\", \\\"{x:1216,y:738,t:1528143606777};\\\", \\\"{x:1226,y:720,t:1528143606793};\\\", \\\"{x:1231,y:704,t:1528143606810};\\\", \\\"{x:1237,y:686,t:1528143606827};\\\", \\\"{x:1242,y:670,t:1528143606843};\\\", \\\"{x:1251,y:644,t:1528143606861};\\\", \\\"{x:1254,y:628,t:1528143606877};\\\", \\\"{x:1258,y:615,t:1528143606893};\\\", \\\"{x:1261,y:606,t:1528143606910};\\\", \\\"{x:1261,y:603,t:1528143606927};\\\", \\\"{x:1263,y:600,t:1528143606943};\\\", \\\"{x:1263,y:597,t:1528143606961};\\\", \\\"{x:1264,y:595,t:1528143606978};\\\", \\\"{x:1266,y:591,t:1528143606994};\\\", \\\"{x:1270,y:586,t:1528143607010};\\\", \\\"{x:1272,y:582,t:1528143607028};\\\", \\\"{x:1274,y:578,t:1528143607043};\\\", \\\"{x:1281,y:573,t:1528143607061};\\\", \\\"{x:1284,y:570,t:1528143607078};\\\", \\\"{x:1287,y:568,t:1528143607094};\\\", \\\"{x:1288,y:567,t:1528143607110};\\\", \\\"{x:1290,y:565,t:1528143607128};\\\", \\\"{x:1292,y:563,t:1528143607144};\\\", \\\"{x:1293,y:562,t:1528143607161};\\\", \\\"{x:1293,y:561,t:1528143607998};\\\", \\\"{x:1291,y:561,t:1528143608110};\\\", \\\"{x:1287,y:561,t:1528143611414};\\\", \\\"{x:1280,y:565,t:1528143611433};\\\", \\\"{x:1277,y:566,t:1528143611448};\\\", \\\"{x:1276,y:566,t:1528143611901};\\\", \\\"{x:1276,y:565,t:1528143611915};\\\", \\\"{x:1276,y:564,t:1528143611932};\\\", \\\"{x:1276,y:563,t:1528143611949};\\\", \\\"{x:1275,y:562,t:1528143612151};\\\", \\\"{x:1273,y:565,t:1528143612165};\\\", \\\"{x:1275,y:571,t:1528143612182};\\\", \\\"{x:1280,y:577,t:1528143612199};\\\", \\\"{x:1283,y:581,t:1528143612216};\\\", \\\"{x:1286,y:586,t:1528143612233};\\\", \\\"{x:1287,y:589,t:1528143612250};\\\", \\\"{x:1291,y:596,t:1528143612266};\\\", \\\"{x:1295,y:601,t:1528143612282};\\\", \\\"{x:1298,y:606,t:1528143612300};\\\", \\\"{x:1300,y:610,t:1528143612317};\\\", \\\"{x:1303,y:613,t:1528143612332};\\\", \\\"{x:1310,y:621,t:1528143612350};\\\", \\\"{x:1311,y:623,t:1528143612365};\\\", \\\"{x:1313,y:625,t:1528143612383};\\\", \\\"{x:1314,y:626,t:1528143612399};\\\", \\\"{x:1315,y:628,t:1528143612416};\\\", \\\"{x:1319,y:635,t:1528143612431};\\\", \\\"{x:1327,y:645,t:1528143612449};\\\", \\\"{x:1332,y:653,t:1528143612466};\\\", \\\"{x:1340,y:658,t:1528143612482};\\\", \\\"{x:1343,y:661,t:1528143612499};\\\", \\\"{x:1346,y:664,t:1528143612515};\\\", \\\"{x:1348,y:667,t:1528143612533};\\\", \\\"{x:1349,y:668,t:1528143612549};\\\", \\\"{x:1351,y:671,t:1528143612566};\\\", \\\"{x:1352,y:672,t:1528143612584};\\\", \\\"{x:1352,y:675,t:1528143612600};\\\", \\\"{x:1354,y:677,t:1528143612616};\\\", \\\"{x:1354,y:678,t:1528143612633};\\\", \\\"{x:1355,y:680,t:1528143612650};\\\", \\\"{x:1356,y:682,t:1528143612666};\\\", \\\"{x:1357,y:683,t:1528143612685};\\\", \\\"{x:1357,y:684,t:1528143612699};\\\", \\\"{x:1357,y:686,t:1528143612717};\\\", \\\"{x:1357,y:688,t:1528143612741};\\\", \\\"{x:1357,y:689,t:1528143612758};\\\", \\\"{x:1357,y:692,t:1528143612774};\\\", \\\"{x:1358,y:692,t:1528143612783};\\\", \\\"{x:1358,y:696,t:1528143612800};\\\", \\\"{x:1359,y:699,t:1528143612817};\\\", \\\"{x:1360,y:702,t:1528143612834};\\\", \\\"{x:1361,y:705,t:1528143612850};\\\", \\\"{x:1362,y:709,t:1528143612866};\\\", \\\"{x:1364,y:714,t:1528143612884};\\\", \\\"{x:1365,y:716,t:1528143612901};\\\", \\\"{x:1365,y:719,t:1528143612917};\\\", \\\"{x:1365,y:721,t:1528143612934};\\\", \\\"{x:1365,y:722,t:1528143612951};\\\", \\\"{x:1365,y:723,t:1528143612966};\\\", \\\"{x:1365,y:724,t:1528143612984};\\\", \\\"{x:1365,y:725,t:1528143613006};\\\", \\\"{x:1365,y:726,t:1528143613030};\\\", \\\"{x:1366,y:727,t:1528143613037};\\\", \\\"{x:1366,y:728,t:1528143613054};\\\", \\\"{x:1366,y:729,t:1528143613069};\\\", \\\"{x:1366,y:730,t:1528143613084};\\\", \\\"{x:1366,y:733,t:1528143613101};\\\", \\\"{x:1368,y:736,t:1528143613116};\\\", \\\"{x:1369,y:742,t:1528143613134};\\\", \\\"{x:1371,y:745,t:1528143613150};\\\", \\\"{x:1372,y:747,t:1528143613166};\\\", \\\"{x:1372,y:751,t:1528143613184};\\\", \\\"{x:1373,y:753,t:1528143613200};\\\", \\\"{x:1373,y:754,t:1528143613217};\\\", \\\"{x:1373,y:756,t:1528143613233};\\\", \\\"{x:1373,y:757,t:1528143613254};\\\", \\\"{x:1374,y:757,t:1528143613267};\\\", \\\"{x:1374,y:758,t:1528143613285};\\\", \\\"{x:1375,y:759,t:1528143613300};\\\", \\\"{x:1375,y:762,t:1528143613318};\\\", \\\"{x:1376,y:763,t:1528143613350};\\\", \\\"{x:1376,y:765,t:1528143613368};\\\", \\\"{x:1376,y:767,t:1528143613406};\\\", \\\"{x:1377,y:767,t:1528143613437};\\\", \\\"{x:1374,y:768,t:1528143614101};\\\", \\\"{x:1359,y:769,t:1528143614118};\\\", \\\"{x:1351,y:769,t:1528143614134};\\\", \\\"{x:1347,y:770,t:1528143614152};\\\", \\\"{x:1346,y:770,t:1528143614302};\\\", \\\"{x:1341,y:770,t:1528143614318};\\\", \\\"{x:1340,y:770,t:1528143614334};\\\", \\\"{x:1339,y:769,t:1528143614352};\\\", \\\"{x:1338,y:768,t:1528143614373};\\\", \\\"{x:1338,y:770,t:1528143614566};\\\", \\\"{x:1342,y:777,t:1528143614573};\\\", \\\"{x:1346,y:787,t:1528143614584};\\\", \\\"{x:1355,y:805,t:1528143614602};\\\", \\\"{x:1362,y:818,t:1528143614619};\\\", \\\"{x:1368,y:830,t:1528143614635};\\\", \\\"{x:1370,y:841,t:1528143614652};\\\", \\\"{x:1372,y:851,t:1528143614669};\\\", \\\"{x:1372,y:854,t:1528143614684};\\\", \\\"{x:1372,y:860,t:1528143614701};\\\", \\\"{x:1372,y:864,t:1528143614718};\\\", \\\"{x:1372,y:865,t:1528143614734};\\\", \\\"{x:1371,y:867,t:1528143614752};\\\", \\\"{x:1370,y:869,t:1528143614768};\\\", \\\"{x:1369,y:870,t:1528143614786};\\\", \\\"{x:1368,y:872,t:1528143614801};\\\", \\\"{x:1368,y:877,t:1528143614819};\\\", \\\"{x:1368,y:882,t:1528143614836};\\\", \\\"{x:1368,y:884,t:1528143614852};\\\", \\\"{x:1368,y:888,t:1528143614869};\\\", \\\"{x:1368,y:889,t:1528143614885};\\\", \\\"{x:1368,y:890,t:1528143614934};\\\", \\\"{x:1368,y:891,t:1528143614941};\\\", \\\"{x:1368,y:892,t:1528143614952};\\\", \\\"{x:1368,y:893,t:1528143614969};\\\", \\\"{x:1368,y:894,t:1528143614986};\\\", \\\"{x:1368,y:895,t:1528143615002};\\\", \\\"{x:1368,y:896,t:1528143615110};\\\", \\\"{x:1368,y:897,t:1528143615559};\\\", \\\"{x:1368,y:898,t:1528143615573};\\\", \\\"{x:1369,y:899,t:1528143615597};\\\", \\\"{x:1371,y:899,t:1528143615662};\\\", \\\"{x:1371,y:900,t:1528143615669};\\\", \\\"{x:1372,y:900,t:1528143615685};\\\", \\\"{x:1374,y:901,t:1528143616557};\\\", \\\"{x:1374,y:900,t:1528143616878};\\\", \\\"{x:1374,y:899,t:1528143617470};\\\", \\\"{x:1374,y:898,t:1528143617797};\\\", \\\"{x:1373,y:897,t:1528143617805};\\\", \\\"{x:1372,y:896,t:1528143617821};\\\", \\\"{x:1371,y:895,t:1528143617838};\\\", \\\"{x:1369,y:895,t:1528143618150};\\\", \\\"{x:1367,y:894,t:1528143618157};\\\", \\\"{x:1363,y:894,t:1528143618172};\\\", \\\"{x:1355,y:893,t:1528143618189};\\\", \\\"{x:1346,y:893,t:1528143618204};\\\", \\\"{x:1340,y:893,t:1528143618221};\\\", \\\"{x:1336,y:893,t:1528143618239};\\\", \\\"{x:1334,y:893,t:1528143618254};\\\", \\\"{x:1333,y:893,t:1528143618271};\\\", \\\"{x:1330,y:893,t:1528143618289};\\\", \\\"{x:1325,y:895,t:1528143618304};\\\", \\\"{x:1318,y:896,t:1528143618322};\\\", \\\"{x:1306,y:898,t:1528143618339};\\\", \\\"{x:1296,y:900,t:1528143618355};\\\", \\\"{x:1287,y:901,t:1528143618372};\\\", \\\"{x:1277,y:903,t:1528143618389};\\\", \\\"{x:1267,y:904,t:1528143618405};\\\", \\\"{x:1259,y:905,t:1528143618421};\\\", \\\"{x:1252,y:905,t:1528143618439};\\\", \\\"{x:1245,y:905,t:1528143618455};\\\", \\\"{x:1235,y:904,t:1528143618471};\\\", \\\"{x:1218,y:896,t:1528143618489};\\\", \\\"{x:1198,y:889,t:1528143618504};\\\", \\\"{x:1179,y:884,t:1528143618521};\\\", \\\"{x:1166,y:880,t:1528143618538};\\\", \\\"{x:1159,y:877,t:1528143618554};\\\", \\\"{x:1157,y:877,t:1528143618572};\\\", \\\"{x:1156,y:876,t:1528143618588};\\\", \\\"{x:1156,y:874,t:1528143618604};\\\", \\\"{x:1156,y:871,t:1528143618621};\\\", \\\"{x:1156,y:868,t:1528143618638};\\\", \\\"{x:1156,y:864,t:1528143618655};\\\", \\\"{x:1159,y:859,t:1528143618671};\\\", \\\"{x:1162,y:856,t:1528143618688};\\\", \\\"{x:1166,y:852,t:1528143618706};\\\", \\\"{x:1168,y:851,t:1528143618721};\\\", \\\"{x:1172,y:849,t:1528143618738};\\\", \\\"{x:1175,y:847,t:1528143618756};\\\", \\\"{x:1183,y:841,t:1528143618772};\\\", \\\"{x:1193,y:835,t:1528143618788};\\\", \\\"{x:1203,y:829,t:1528143618805};\\\", \\\"{x:1208,y:825,t:1528143618821};\\\", \\\"{x:1216,y:820,t:1528143618838};\\\", \\\"{x:1222,y:815,t:1528143618855};\\\", \\\"{x:1229,y:809,t:1528143618872};\\\", \\\"{x:1238,y:802,t:1528143618889};\\\", \\\"{x:1247,y:795,t:1528143618905};\\\", \\\"{x:1252,y:789,t:1528143618922};\\\", \\\"{x:1258,y:781,t:1528143618939};\\\", \\\"{x:1262,y:776,t:1528143618955};\\\", \\\"{x:1266,y:769,t:1528143618973};\\\", \\\"{x:1271,y:758,t:1528143618989};\\\", \\\"{x:1282,y:733,t:1528143619006};\\\", \\\"{x:1292,y:710,t:1528143619023};\\\", \\\"{x:1305,y:688,t:1528143619039};\\\", \\\"{x:1317,y:668,t:1528143619056};\\\", \\\"{x:1327,y:648,t:1528143619073};\\\", \\\"{x:1338,y:629,t:1528143619089};\\\", \\\"{x:1347,y:611,t:1528143619105};\\\", \\\"{x:1353,y:594,t:1528143619123};\\\", \\\"{x:1361,y:574,t:1528143619139};\\\", \\\"{x:1371,y:554,t:1528143619155};\\\", \\\"{x:1382,y:538,t:1528143619173};\\\", \\\"{x:1388,y:525,t:1528143619189};\\\", \\\"{x:1397,y:509,t:1528143619206};\\\", \\\"{x:1402,y:498,t:1528143619223};\\\", \\\"{x:1406,y:490,t:1528143619238};\\\", \\\"{x:1407,y:483,t:1528143619255};\\\", \\\"{x:1410,y:476,t:1528143619272};\\\", \\\"{x:1410,y:473,t:1528143619290};\\\", \\\"{x:1413,y:467,t:1528143619306};\\\", \\\"{x:1414,y:462,t:1528143619323};\\\", \\\"{x:1415,y:457,t:1528143619340};\\\", \\\"{x:1417,y:452,t:1528143619356};\\\", \\\"{x:1417,y:446,t:1528143619372};\\\", \\\"{x:1423,y:433,t:1528143619390};\\\", \\\"{x:1427,y:423,t:1528143619406};\\\", \\\"{x:1430,y:416,t:1528143619423};\\\", \\\"{x:1432,y:411,t:1528143619440};\\\", \\\"{x:1432,y:408,t:1528143619456};\\\", \\\"{x:1434,y:404,t:1528143619473};\\\", \\\"{x:1434,y:401,t:1528143619490};\\\", \\\"{x:1434,y:399,t:1528143619506};\\\", \\\"{x:1435,y:397,t:1528143619523};\\\", \\\"{x:1436,y:393,t:1528143619540};\\\", \\\"{x:1437,y:391,t:1528143619556};\\\", \\\"{x:1439,y:390,t:1528143619573};\\\", \\\"{x:1442,y:387,t:1528143619589};\\\", \\\"{x:1444,y:386,t:1528143619606};\\\", \\\"{x:1445,y:386,t:1528143619749};\\\", \\\"{x:1448,y:383,t:1528143619781};\\\", \\\"{x:1451,y:374,t:1528143619789};\\\", \\\"{x:1457,y:367,t:1528143619807};\\\", \\\"{x:1460,y:363,t:1528143619823};\\\", \\\"{x:1462,y:360,t:1528143619840};\\\", \\\"{x:1465,y:355,t:1528143619857};\\\", \\\"{x:1467,y:353,t:1528143619873};\\\", \\\"{x:1468,y:352,t:1528143619925};\\\", \\\"{x:1468,y:351,t:1528143619973};\\\", \\\"{x:1468,y:348,t:1528143619990};\\\", \\\"{x:1468,y:343,t:1528143620007};\\\", \\\"{x:1468,y:339,t:1528143620023};\\\", \\\"{x:1470,y:332,t:1528143620040};\\\", \\\"{x:1471,y:323,t:1528143620057};\\\", \\\"{x:1474,y:317,t:1528143620073};\\\", \\\"{x:1475,y:314,t:1528143620090};\\\", \\\"{x:1475,y:312,t:1528143620126};\\\", \\\"{x:1476,y:312,t:1528143620140};\\\", \\\"{x:1476,y:311,t:1528143620166};\\\", \\\"{x:1474,y:311,t:1528143620429};\\\", \\\"{x:1473,y:311,t:1528143620440};\\\", \\\"{x:1473,y:312,t:1528143620457};\\\", \\\"{x:1471,y:312,t:1528143620474};\\\", \\\"{x:1469,y:313,t:1528143620491};\\\", \\\"{x:1467,y:318,t:1528143620507};\\\", \\\"{x:1463,y:329,t:1528143620524};\\\", \\\"{x:1461,y:338,t:1528143620541};\\\", \\\"{x:1461,y:340,t:1528143620557};\\\", \\\"{x:1461,y:341,t:1528143620598};\\\", \\\"{x:1460,y:342,t:1528143620622};\\\", \\\"{x:1458,y:343,t:1528143620630};\\\", \\\"{x:1457,y:348,t:1528143620640};\\\", \\\"{x:1454,y:353,t:1528143620657};\\\", \\\"{x:1451,y:357,t:1528143620674};\\\", \\\"{x:1450,y:360,t:1528143620691};\\\", \\\"{x:1449,y:361,t:1528143620718};\\\", \\\"{x:1449,y:362,t:1528143620734};\\\", \\\"{x:1447,y:364,t:1528143620742};\\\", \\\"{x:1447,y:365,t:1528143620757};\\\", \\\"{x:1443,y:373,t:1528143620773};\\\", \\\"{x:1441,y:378,t:1528143620791};\\\", \\\"{x:1440,y:381,t:1528143620807};\\\", \\\"{x:1439,y:384,t:1528143620824};\\\", \\\"{x:1438,y:390,t:1528143620841};\\\", \\\"{x:1433,y:404,t:1528143620857};\\\", \\\"{x:1430,y:413,t:1528143620874};\\\", \\\"{x:1428,y:423,t:1528143620891};\\\", \\\"{x:1425,y:431,t:1528143620908};\\\", \\\"{x:1420,y:443,t:1528143620924};\\\", \\\"{x:1413,y:461,t:1528143620941};\\\", \\\"{x:1406,y:479,t:1528143620958};\\\", \\\"{x:1401,y:491,t:1528143620973};\\\", \\\"{x:1399,y:497,t:1528143620991};\\\", \\\"{x:1396,y:502,t:1528143621008};\\\", \\\"{x:1393,y:508,t:1528143621024};\\\", \\\"{x:1389,y:516,t:1528143621040};\\\", \\\"{x:1384,y:526,t:1528143621058};\\\", \\\"{x:1378,y:536,t:1528143621074};\\\", \\\"{x:1372,y:547,t:1528143621091};\\\", \\\"{x:1366,y:556,t:1528143621108};\\\", \\\"{x:1359,y:569,t:1528143621123};\\\", \\\"{x:1349,y:584,t:1528143621140};\\\", \\\"{x:1336,y:602,t:1528143621157};\\\", \\\"{x:1326,y:621,t:1528143621174};\\\", \\\"{x:1319,y:639,t:1528143621191};\\\", \\\"{x:1311,y:657,t:1528143621208};\\\", \\\"{x:1308,y:670,t:1528143621225};\\\", \\\"{x:1303,y:680,t:1528143621240};\\\", \\\"{x:1299,y:692,t:1528143621258};\\\", \\\"{x:1295,y:701,t:1528143621274};\\\", \\\"{x:1285,y:720,t:1528143621291};\\\", \\\"{x:1279,y:736,t:1528143621308};\\\", \\\"{x:1271,y:753,t:1528143621325};\\\", \\\"{x:1262,y:770,t:1528143621340};\\\", \\\"{x:1245,y:797,t:1528143621357};\\\", \\\"{x:1235,y:811,t:1528143621375};\\\", \\\"{x:1224,y:822,t:1528143621391};\\\", \\\"{x:1208,y:836,t:1528143621408};\\\", \\\"{x:1195,y:844,t:1528143621425};\\\", \\\"{x:1187,y:853,t:1528143621441};\\\", \\\"{x:1178,y:862,t:1528143621458};\\\", \\\"{x:1174,y:868,t:1528143621474};\\\", \\\"{x:1171,y:870,t:1528143621491};\\\", \\\"{x:1171,y:871,t:1528143621557};\\\", \\\"{x:1171,y:872,t:1528143621575};\\\", \\\"{x:1173,y:872,t:1528143621630};\\\", \\\"{x:1175,y:872,t:1528143621641};\\\", \\\"{x:1184,y:860,t:1528143621657};\\\", \\\"{x:1197,y:845,t:1528143621675};\\\", \\\"{x:1214,y:824,t:1528143621692};\\\", \\\"{x:1231,y:807,t:1528143621709};\\\", \\\"{x:1245,y:792,t:1528143621725};\\\", \\\"{x:1256,y:773,t:1528143621742};\\\", \\\"{x:1260,y:761,t:1528143621757};\\\", \\\"{x:1262,y:747,t:1528143621774};\\\", \\\"{x:1262,y:729,t:1528143621791};\\\", \\\"{x:1265,y:701,t:1528143621807};\\\", \\\"{x:1268,y:678,t:1528143621824};\\\", \\\"{x:1274,y:652,t:1528143621841};\\\", \\\"{x:1287,y:609,t:1528143621857};\\\", \\\"{x:1290,y:586,t:1528143621874};\\\", \\\"{x:1296,y:566,t:1528143621891};\\\", \\\"{x:1298,y:553,t:1528143621908};\\\", \\\"{x:1302,y:542,t:1528143621924};\\\", \\\"{x:1306,y:527,t:1528143621941};\\\", \\\"{x:1310,y:519,t:1528143621959};\\\", \\\"{x:1312,y:512,t:1528143621975};\\\", \\\"{x:1316,y:505,t:1528143621992};\\\", \\\"{x:1320,y:497,t:1528143622008};\\\", \\\"{x:1326,y:490,t:1528143622025};\\\", \\\"{x:1333,y:483,t:1528143622042};\\\", \\\"{x:1340,y:474,t:1528143622058};\\\", \\\"{x:1348,y:470,t:1528143622074};\\\", \\\"{x:1352,y:467,t:1528143622092};\\\", \\\"{x:1356,y:464,t:1528143622109};\\\", \\\"{x:1360,y:460,t:1528143622125};\\\", \\\"{x:1369,y:453,t:1528143622141};\\\", \\\"{x:1373,y:451,t:1528143622159};\\\", \\\"{x:1376,y:449,t:1528143622174};\\\", \\\"{x:1378,y:447,t:1528143622191};\\\", \\\"{x:1379,y:446,t:1528143622208};\\\", \\\"{x:1382,y:444,t:1528143622225};\\\", \\\"{x:1385,y:442,t:1528143622242};\\\", \\\"{x:1389,y:441,t:1528143622259};\\\", \\\"{x:1391,y:439,t:1528143622275};\\\", \\\"{x:1392,y:439,t:1528143622292};\\\", \\\"{x:1394,y:439,t:1528143622309};\\\", \\\"{x:1397,y:438,t:1528143622325};\\\", \\\"{x:1397,y:437,t:1528143622373};\\\", \\\"{x:1398,y:436,t:1528143622398};\\\", \\\"{x:1400,y:436,t:1528143622470};\\\", \\\"{x:1403,y:435,t:1528143622477};\\\", \\\"{x:1404,y:434,t:1528143622491};\\\", \\\"{x:1406,y:431,t:1528143622509};\\\", \\\"{x:1409,y:428,t:1528143622525};\\\", \\\"{x:1411,y:426,t:1528143622542};\\\", \\\"{x:1412,y:425,t:1528143622574};\\\", \\\"{x:1414,y:424,t:1528143625862};\\\", \\\"{x:1416,y:407,t:1528143625879};\\\", \\\"{x:1420,y:399,t:1528143625894};\\\", \\\"{x:1421,y:395,t:1528143625911};\\\", \\\"{x:1423,y:392,t:1528143625928};\\\", \\\"{x:1423,y:388,t:1528143625945};\\\", \\\"{x:1428,y:381,t:1528143625961};\\\", \\\"{x:1439,y:363,t:1528143625978};\\\", \\\"{x:1455,y:339,t:1528143625994};\\\", \\\"{x:1470,y:320,t:1528143626012};\\\", \\\"{x:1490,y:302,t:1528143626028};\\\", \\\"{x:1497,y:297,t:1528143626045};\\\", \\\"{x:1498,y:296,t:1528143626061};\\\", \\\"{x:1499,y:295,t:1528143626101};\\\", \\\"{x:1500,y:295,t:1528143626117};\\\", \\\"{x:1500,y:294,t:1528143626142};\\\", \\\"{x:1501,y:294,t:1528143632758};\\\", \\\"{x:1501,y:295,t:1528143632781};\\\", \\\"{x:1501,y:296,t:1528143632805};\\\", \\\"{x:1495,y:335,t:1528143632818};\\\", \\\"{x:1484,y:510,t:1528143632835};\\\", \\\"{x:1467,y:656,t:1528143632852};\\\", \\\"{x:1442,y:727,t:1528143632868};\\\", \\\"{x:1431,y:748,t:1528143632885};\\\", \\\"{x:1427,y:754,t:1528143632901};\\\", \\\"{x:1417,y:773,t:1528143632918};\\\", \\\"{x:1404,y:805,t:1528143632936};\\\", \\\"{x:1387,y:846,t:1528143632952};\\\", \\\"{x:1368,y:879,t:1528143632968};\\\", \\\"{x:1354,y:900,t:1528143632985};\\\", \\\"{x:1346,y:908,t:1528143633002};\\\", \\\"{x:1343,y:911,t:1528143633018};\\\", \\\"{x:1339,y:913,t:1528143633035};\\\", \\\"{x:1334,y:918,t:1528143633052};\\\", \\\"{x:1329,y:925,t:1528143633068};\\\", \\\"{x:1316,y:940,t:1528143633085};\\\", \\\"{x:1308,y:956,t:1528143633102};\\\", \\\"{x:1296,y:978,t:1528143633118};\\\", \\\"{x:1289,y:992,t:1528143633135};\\\", \\\"{x:1287,y:994,t:1528143633152};\\\", \\\"{x:1286,y:994,t:1528143633341};\\\", \\\"{x:1283,y:992,t:1528143633353};\\\", \\\"{x:1281,y:987,t:1528143633369};\\\", \\\"{x:1278,y:981,t:1528143633385};\\\", \\\"{x:1275,y:977,t:1528143633402};\\\", \\\"{x:1274,y:976,t:1528143633421};\\\", \\\"{x:1273,y:976,t:1528143633453};\\\", \\\"{x:1272,y:976,t:1528143633469};\\\", \\\"{x:1271,y:976,t:1528143633485};\\\", \\\"{x:1268,y:976,t:1528143633509};\\\", \\\"{x:1264,y:977,t:1528143633525};\\\", \\\"{x:1259,y:979,t:1528143633535};\\\", \\\"{x:1250,y:982,t:1528143633552};\\\", \\\"{x:1243,y:983,t:1528143633569};\\\", \\\"{x:1239,y:985,t:1528143633585};\\\", \\\"{x:1238,y:983,t:1528143633694};\\\", \\\"{x:1238,y:982,t:1528143633702};\\\", \\\"{x:1238,y:977,t:1528143633718};\\\", \\\"{x:1236,y:975,t:1528143633736};\\\", \\\"{x:1236,y:974,t:1528143633756};\\\", \\\"{x:1236,y:973,t:1528143633788};\\\", \\\"{x:1236,y:972,t:1528143633802};\\\", \\\"{x:1236,y:970,t:1528143633828};\\\", \\\"{x:1237,y:969,t:1528143633949};\\\", \\\"{x:1237,y:967,t:1528143634269};\\\", \\\"{x:1239,y:966,t:1528143634286};\\\", \\\"{x:1243,y:962,t:1528143634303};\\\", \\\"{x:1246,y:959,t:1528143634319};\\\", \\\"{x:1248,y:955,t:1528143634336};\\\", \\\"{x:1250,y:953,t:1528143634352};\\\", \\\"{x:1251,y:952,t:1528143634369};\\\", \\\"{x:1251,y:950,t:1528143634386};\\\", \\\"{x:1252,y:949,t:1528143634403};\\\", \\\"{x:1253,y:947,t:1528143634418};\\\", \\\"{x:1254,y:946,t:1528143634435};\\\", \\\"{x:1255,y:944,t:1528143634453};\\\", \\\"{x:1256,y:941,t:1528143634469};\\\", \\\"{x:1257,y:941,t:1528143634509};\\\", \\\"{x:1257,y:939,t:1528143634524};\\\", \\\"{x:1257,y:938,t:1528143634536};\\\", \\\"{x:1258,y:936,t:1528143634552};\\\", \\\"{x:1259,y:934,t:1528143634570};\\\", \\\"{x:1260,y:931,t:1528143634586};\\\", \\\"{x:1261,y:928,t:1528143634603};\\\", \\\"{x:1264,y:924,t:1528143634620};\\\", \\\"{x:1264,y:921,t:1528143634636};\\\", \\\"{x:1267,y:916,t:1528143634653};\\\", \\\"{x:1271,y:911,t:1528143634670};\\\", \\\"{x:1272,y:907,t:1528143634686};\\\", \\\"{x:1276,y:902,t:1528143634703};\\\", \\\"{x:1279,y:897,t:1528143634720};\\\", \\\"{x:1283,y:891,t:1528143634737};\\\", \\\"{x:1288,y:884,t:1528143634753};\\\", \\\"{x:1291,y:880,t:1528143634770};\\\", \\\"{x:1295,y:876,t:1528143634787};\\\", \\\"{x:1299,y:872,t:1528143634803};\\\", \\\"{x:1300,y:870,t:1528143634820};\\\", \\\"{x:1303,y:867,t:1528143634836};\\\", \\\"{x:1304,y:866,t:1528143634852};\\\", \\\"{x:1305,y:864,t:1528143634870};\\\", \\\"{x:1306,y:863,t:1528143634887};\\\", \\\"{x:1307,y:861,t:1528143634903};\\\", \\\"{x:1308,y:860,t:1528143634920};\\\", \\\"{x:1308,y:859,t:1528143634937};\\\", \\\"{x:1309,y:858,t:1528143634953};\\\", \\\"{x:1311,y:855,t:1528143634970};\\\", \\\"{x:1312,y:855,t:1528143634987};\\\", \\\"{x:1313,y:854,t:1528143635004};\\\", \\\"{x:1314,y:852,t:1528143635021};\\\", \\\"{x:1316,y:851,t:1528143635037};\\\", \\\"{x:1317,y:848,t:1528143635053};\\\", \\\"{x:1318,y:847,t:1528143635077};\\\", \\\"{x:1319,y:845,t:1528143635088};\\\", \\\"{x:1321,y:841,t:1528143635103};\\\", \\\"{x:1322,y:840,t:1528143635121};\\\", \\\"{x:1322,y:838,t:1528143635137};\\\", \\\"{x:1324,y:834,t:1528143635153};\\\", \\\"{x:1324,y:833,t:1528143635170};\\\", \\\"{x:1326,y:831,t:1528143635188};\\\", \\\"{x:1327,y:829,t:1528143635204};\\\", \\\"{x:1328,y:828,t:1528143635220};\\\", \\\"{x:1328,y:826,t:1528143635238};\\\", \\\"{x:1328,y:825,t:1528143635254};\\\", \\\"{x:1329,y:823,t:1528143635271};\\\", \\\"{x:1329,y:820,t:1528143635287};\\\", \\\"{x:1330,y:817,t:1528143635305};\\\", \\\"{x:1331,y:815,t:1528143635321};\\\", \\\"{x:1332,y:811,t:1528143635337};\\\", \\\"{x:1335,y:806,t:1528143635354};\\\", \\\"{x:1338,y:802,t:1528143635371};\\\", \\\"{x:1339,y:799,t:1528143635388};\\\", \\\"{x:1341,y:796,t:1528143635404};\\\", \\\"{x:1341,y:795,t:1528143635420};\\\", \\\"{x:1342,y:794,t:1528143635448};\\\", \\\"{x:1342,y:792,t:1528143635479};\\\", \\\"{x:1343,y:790,t:1528143635498};\\\", \\\"{x:1345,y:789,t:1528143635515};\\\", \\\"{x:1346,y:787,t:1528143635530};\\\", \\\"{x:1346,y:786,t:1528143635547};\\\", \\\"{x:1346,y:785,t:1528143635574};\\\", \\\"{x:1348,y:783,t:1528143635623};\\\", \\\"{x:1349,y:782,t:1528143635631};\\\", \\\"{x:1349,y:781,t:1528143635655};\\\", \\\"{x:1350,y:781,t:1528143635664};\\\", \\\"{x:1350,y:780,t:1528143635681};\\\", \\\"{x:1350,y:779,t:1528143635703};\\\", \\\"{x:1350,y:778,t:1528143635719};\\\", \\\"{x:1350,y:777,t:1528143635731};\\\", \\\"{x:1351,y:776,t:1528143635747};\\\", \\\"{x:1351,y:775,t:1528143635764};\\\", \\\"{x:1351,y:774,t:1528143635832};\\\", \\\"{x:1349,y:773,t:1528143636072};\\\", \\\"{x:1347,y:771,t:1528143636082};\\\", \\\"{x:1346,y:771,t:1528143636099};\\\", \\\"{x:1345,y:770,t:1528143636114};\\\", \\\"{x:1344,y:770,t:1528143636136};\\\", \\\"{x:1344,y:769,t:1528143636207};\\\", \\\"{x:1344,y:768,t:1528143636215};\\\", \\\"{x:1342,y:767,t:1528143636232};\\\", \\\"{x:1342,y:766,t:1528143636255};\\\", \\\"{x:1341,y:765,t:1528143636288};\\\", \\\"{x:1341,y:763,t:1528143636352};\\\", \\\"{x:1342,y:763,t:1528143636790};\\\", \\\"{x:1350,y:776,t:1528143636816};\\\", \\\"{x:1357,y:787,t:1528143636832};\\\", \\\"{x:1360,y:792,t:1528143636848};\\\", \\\"{x:1363,y:796,t:1528143636865};\\\", \\\"{x:1363,y:797,t:1528143636882};\\\", \\\"{x:1364,y:799,t:1528143636898};\\\", \\\"{x:1366,y:803,t:1528143636915};\\\", \\\"{x:1366,y:804,t:1528143636932};\\\", \\\"{x:1368,y:808,t:1528143636948};\\\", \\\"{x:1370,y:811,t:1528143636965};\\\", \\\"{x:1370,y:814,t:1528143636983};\\\", \\\"{x:1371,y:815,t:1528143636998};\\\", \\\"{x:1371,y:817,t:1528143637015};\\\", \\\"{x:1373,y:820,t:1528143637033};\\\", \\\"{x:1374,y:822,t:1528143637048};\\\", \\\"{x:1375,y:827,t:1528143637065};\\\", \\\"{x:1377,y:831,t:1528143637083};\\\", \\\"{x:1378,y:834,t:1528143637099};\\\", \\\"{x:1379,y:836,t:1528143637116};\\\", \\\"{x:1381,y:839,t:1528143637133};\\\", \\\"{x:1382,y:841,t:1528143637149};\\\", \\\"{x:1384,y:844,t:1528143637166};\\\", \\\"{x:1385,y:847,t:1528143637183};\\\", \\\"{x:1387,y:850,t:1528143637200};\\\", \\\"{x:1388,y:852,t:1528143637215};\\\", \\\"{x:1390,y:855,t:1528143637233};\\\", \\\"{x:1392,y:858,t:1528143637249};\\\", \\\"{x:1394,y:862,t:1528143637266};\\\", \\\"{x:1396,y:863,t:1528143637283};\\\", \\\"{x:1398,y:867,t:1528143637299};\\\", \\\"{x:1402,y:871,t:1528143637316};\\\", \\\"{x:1406,y:877,t:1528143637332};\\\", \\\"{x:1407,y:879,t:1528143637350};\\\", \\\"{x:1409,y:883,t:1528143637366};\\\", \\\"{x:1412,y:886,t:1528143637383};\\\", \\\"{x:1414,y:891,t:1528143637400};\\\", \\\"{x:1416,y:894,t:1528143637416};\\\", \\\"{x:1416,y:896,t:1528143637432};\\\", \\\"{x:1418,y:899,t:1528143637450};\\\", \\\"{x:1420,y:902,t:1528143637465};\\\", \\\"{x:1420,y:905,t:1528143637482};\\\", \\\"{x:1421,y:909,t:1528143637500};\\\", \\\"{x:1423,y:913,t:1528143637517};\\\", \\\"{x:1424,y:919,t:1528143637533};\\\", \\\"{x:1426,y:922,t:1528143637550};\\\", \\\"{x:1428,y:927,t:1528143637567};\\\", \\\"{x:1430,y:929,t:1528143637582};\\\", \\\"{x:1431,y:936,t:1528143637599};\\\", \\\"{x:1432,y:940,t:1528143637617};\\\", \\\"{x:1435,y:945,t:1528143637632};\\\", \\\"{x:1438,y:950,t:1528143637649};\\\", \\\"{x:1439,y:950,t:1528143637667};\\\", \\\"{x:1440,y:951,t:1528143637683};\\\", \\\"{x:1441,y:955,t:1528143637699};\\\", \\\"{x:1443,y:958,t:1528143637717};\\\", \\\"{x:1443,y:959,t:1528143637732};\\\", \\\"{x:1444,y:960,t:1528143637749};\\\", \\\"{x:1445,y:960,t:1528143637767};\\\", \\\"{x:1445,y:961,t:1528143637782};\\\", \\\"{x:1446,y:961,t:1528143637888};\\\", \\\"{x:1443,y:959,t:1528143637900};\\\", \\\"{x:1439,y:954,t:1528143637917};\\\", \\\"{x:1428,y:947,t:1528143637934};\\\", \\\"{x:1421,y:941,t:1528143637949};\\\", \\\"{x:1407,y:934,t:1528143637967};\\\", \\\"{x:1392,y:927,t:1528143637983};\\\", \\\"{x:1391,y:925,t:1528143638000};\\\", \\\"{x:1391,y:924,t:1528143638016};\\\", \\\"{x:1389,y:920,t:1528143638034};\\\", \\\"{x:1388,y:916,t:1528143638050};\\\", \\\"{x:1386,y:913,t:1528143638067};\\\", \\\"{x:1385,y:912,t:1528143638084};\\\", \\\"{x:1384,y:911,t:1528143638120};\\\", \\\"{x:1383,y:909,t:1528143638143};\\\", \\\"{x:1382,y:908,t:1528143638167};\\\", \\\"{x:1381,y:906,t:1528143638191};\\\", \\\"{x:1380,y:906,t:1528143638200};\\\", \\\"{x:1380,y:905,t:1528143638217};\\\", \\\"{x:1379,y:904,t:1528143638233};\\\", \\\"{x:1378,y:901,t:1528143638250};\\\", \\\"{x:1378,y:897,t:1528143638267};\\\", \\\"{x:1378,y:894,t:1528143638283};\\\", \\\"{x:1376,y:893,t:1528143638302};\\\", \\\"{x:1376,y:891,t:1528143638316};\\\", \\\"{x:1373,y:891,t:1528143639544};\\\", \\\"{x:1368,y:891,t:1528143639551};\\\", \\\"{x:1364,y:891,t:1528143639576};\\\", \\\"{x:1360,y:891,t:1528143639585};\\\", \\\"{x:1356,y:891,t:1528143639601};\\\", \\\"{x:1355,y:891,t:1528143639631};\\\", \\\"{x:1354,y:891,t:1528143639647};\\\", \\\"{x:1352,y:890,t:1528143639656};\\\", \\\"{x:1349,y:885,t:1528143639668};\\\", \\\"{x:1347,y:875,t:1528143639685};\\\", \\\"{x:1343,y:859,t:1528143639702};\\\", \\\"{x:1335,y:837,t:1528143639718};\\\", \\\"{x:1331,y:816,t:1528143639735};\\\", \\\"{x:1328,y:797,t:1528143639751};\\\", \\\"{x:1328,y:790,t:1528143639769};\\\", \\\"{x:1328,y:786,t:1528143639785};\\\", \\\"{x:1328,y:782,t:1528143639802};\\\", \\\"{x:1328,y:781,t:1528143639819};\\\", \\\"{x:1328,y:778,t:1528143639834};\\\", \\\"{x:1328,y:774,t:1528143639852};\\\", \\\"{x:1328,y:771,t:1528143639868};\\\", \\\"{x:1328,y:769,t:1528143639885};\\\", \\\"{x:1329,y:768,t:1528143639902};\\\", \\\"{x:1330,y:766,t:1528143639919};\\\", \\\"{x:1331,y:765,t:1528143639936};\\\", \\\"{x:1331,y:763,t:1528143639952};\\\", \\\"{x:1333,y:761,t:1528143639969};\\\", \\\"{x:1335,y:759,t:1528143639985};\\\", \\\"{x:1336,y:757,t:1528143640002};\\\", \\\"{x:1337,y:755,t:1528143640019};\\\", \\\"{x:1338,y:753,t:1528143640035};\\\", \\\"{x:1340,y:752,t:1528143640051};\\\", \\\"{x:1342,y:749,t:1528143640069};\\\", \\\"{x:1345,y:746,t:1528143640084};\\\", \\\"{x:1348,y:745,t:1528143640101};\\\", \\\"{x:1351,y:743,t:1528143640120};\\\", \\\"{x:1353,y:742,t:1528143640136};\\\", \\\"{x:1351,y:742,t:1528143640263};\\\", \\\"{x:1348,y:744,t:1528143640272};\\\", \\\"{x:1342,y:747,t:1528143640286};\\\", \\\"{x:1328,y:753,t:1528143640301};\\\", \\\"{x:1305,y:769,t:1528143640319};\\\", \\\"{x:1223,y:813,t:1528143640335};\\\", \\\"{x:1146,y:847,t:1528143640352};\\\", \\\"{x:1074,y:878,t:1528143640369};\\\", \\\"{x:1027,y:894,t:1528143640386};\\\", \\\"{x:1006,y:900,t:1528143640401};\\\", \\\"{x:993,y:905,t:1528143640419};\\\", \\\"{x:986,y:909,t:1528143640435};\\\", \\\"{x:976,y:915,t:1528143640452};\\\", \\\"{x:968,y:919,t:1528143640468};\\\", \\\"{x:958,y:926,t:1528143640485};\\\", \\\"{x:943,y:932,t:1528143640501};\\\", \\\"{x:929,y:937,t:1528143640518};\\\", \\\"{x:902,y:948,t:1528143640535};\\\", \\\"{x:882,y:954,t:1528143640553};\\\", \\\"{x:866,y:959,t:1528143640569};\\\", \\\"{x:852,y:964,t:1528143640586};\\\", \\\"{x:849,y:966,t:1528143640603};\\\", \\\"{x:848,y:966,t:1528143640618};\\\", \\\"{x:852,y:966,t:1528143640679};\\\", \\\"{x:860,y:964,t:1528143640687};\\\", \\\"{x:870,y:960,t:1528143640703};\\\", \\\"{x:893,y:951,t:1528143640719};\\\", \\\"{x:923,y:938,t:1528143640735};\\\", \\\"{x:946,y:930,t:1528143640753};\\\", \\\"{x:959,y:923,t:1528143640768};\\\", \\\"{x:961,y:923,t:1528143640785};\\\", \\\"{x:962,y:922,t:1528143640960};\\\", \\\"{x:967,y:921,t:1528143640970};\\\", \\\"{x:1004,y:919,t:1528143640986};\\\", \\\"{x:1054,y:919,t:1528143641003};\\\", \\\"{x:1099,y:919,t:1528143641020};\\\", \\\"{x:1149,y:919,t:1528143641035};\\\", \\\"{x:1188,y:917,t:1528143641053};\\\", \\\"{x:1204,y:917,t:1528143641070};\\\", \\\"{x:1208,y:919,t:1528143641086};\\\", \\\"{x:1213,y:926,t:1528143641103};\\\", \\\"{x:1213,y:937,t:1528143641119};\\\", \\\"{x:1213,y:941,t:1528143641136};\\\", \\\"{x:1213,y:944,t:1528143641153};\\\", \\\"{x:1213,y:948,t:1528143641170};\\\", \\\"{x:1213,y:951,t:1528143641186};\\\", \\\"{x:1213,y:956,t:1528143641203};\\\", \\\"{x:1213,y:958,t:1528143641220};\\\", \\\"{x:1213,y:960,t:1528143641288};\\\", \\\"{x:1212,y:960,t:1528143641376};\\\", \\\"{x:1211,y:960,t:1528143641399};\\\", \\\"{x:1209,y:959,t:1528143641664};\\\", \\\"{x:1209,y:956,t:1528143641671};\\\", \\\"{x:1209,y:947,t:1528143641687};\\\", \\\"{x:1209,y:936,t:1528143641703};\\\", \\\"{x:1209,y:927,t:1528143641720};\\\", \\\"{x:1209,y:913,t:1528143641737};\\\", \\\"{x:1212,y:898,t:1528143641753};\\\", \\\"{x:1215,y:889,t:1528143641769};\\\", \\\"{x:1216,y:884,t:1528143641786};\\\", \\\"{x:1216,y:882,t:1528143641803};\\\", \\\"{x:1216,y:881,t:1528143641838};\\\", \\\"{x:1216,y:879,t:1528143641853};\\\", \\\"{x:1216,y:878,t:1528143641869};\\\", \\\"{x:1216,y:876,t:1528143641887};\\\", \\\"{x:1216,y:875,t:1528143641903};\\\", \\\"{x:1216,y:874,t:1528143641919};\\\", \\\"{x:1216,y:872,t:1528143641936};\\\", \\\"{x:1216,y:871,t:1528143641953};\\\", \\\"{x:1217,y:869,t:1528143641969};\\\", \\\"{x:1217,y:868,t:1528143641987};\\\", \\\"{x:1217,y:866,t:1528143642003};\\\", \\\"{x:1217,y:865,t:1528143642020};\\\", \\\"{x:1217,y:864,t:1528143642036};\\\", \\\"{x:1217,y:863,t:1528143642054};\\\", \\\"{x:1217,y:862,t:1528143642070};\\\", \\\"{x:1216,y:862,t:1528143642184};\\\", \\\"{x:1215,y:862,t:1528143642207};\\\", \\\"{x:1214,y:862,t:1528143642887};\\\", \\\"{x:1214,y:857,t:1528143642905};\\\", \\\"{x:1214,y:852,t:1528143642921};\\\", \\\"{x:1214,y:849,t:1528143642938};\\\", \\\"{x:1214,y:846,t:1528143642954};\\\", \\\"{x:1214,y:845,t:1528143642971};\\\", \\\"{x:1214,y:844,t:1528143642988};\\\", \\\"{x:1214,y:843,t:1528143643005};\\\", \\\"{x:1214,y:840,t:1528143643021};\\\", \\\"{x:1213,y:837,t:1528143643037};\\\", \\\"{x:1213,y:829,t:1528143643056};\\\", \\\"{x:1213,y:824,t:1528143643072};\\\", \\\"{x:1213,y:822,t:1528143643127};\\\", \\\"{x:1212,y:822,t:1528143643840};\\\", \\\"{x:1206,y:826,t:1528143643855};\\\", \\\"{x:1195,y:832,t:1528143643872};\\\", \\\"{x:1182,y:840,t:1528143643889};\\\", \\\"{x:1170,y:856,t:1528143643905};\\\", \\\"{x:1159,y:874,t:1528143643921};\\\", \\\"{x:1152,y:887,t:1528143643939};\\\", \\\"{x:1148,y:895,t:1528143643956};\\\", \\\"{x:1146,y:899,t:1528143643972};\\\", \\\"{x:1144,y:903,t:1528143643989};\\\", \\\"{x:1140,y:907,t:1528143644006};\\\", \\\"{x:1138,y:913,t:1528143644022};\\\", \\\"{x:1135,y:920,t:1528143644039};\\\", \\\"{x:1132,y:923,t:1528143644056};\\\", \\\"{x:1128,y:928,t:1528143644071};\\\", \\\"{x:1121,y:932,t:1528143644089};\\\", \\\"{x:1116,y:933,t:1528143644106};\\\", \\\"{x:1103,y:936,t:1528143644122};\\\", \\\"{x:1087,y:939,t:1528143644139};\\\", \\\"{x:1076,y:941,t:1528143644156};\\\", \\\"{x:1069,y:942,t:1528143644172};\\\", \\\"{x:1067,y:942,t:1528143644189};\\\", \\\"{x:1066,y:943,t:1528143644206};\\\", \\\"{x:1065,y:944,t:1528143644288};\\\", \\\"{x:1065,y:947,t:1528143644305};\\\", \\\"{x:1066,y:952,t:1528143644323};\\\", \\\"{x:1066,y:955,t:1528143644339};\\\", \\\"{x:1067,y:960,t:1528143644356};\\\", \\\"{x:1067,y:963,t:1528143644374};\\\", \\\"{x:1068,y:966,t:1528143644389};\\\", \\\"{x:1068,y:967,t:1528143644406};\\\", \\\"{x:1068,y:969,t:1528143644423};\\\", \\\"{x:1068,y:970,t:1528143644447};\\\", \\\"{x:1069,y:970,t:1528143644455};\\\", \\\"{x:1069,y:971,t:1528143644680};\\\", \\\"{x:1070,y:968,t:1528143645008};\\\", \\\"{x:1079,y:944,t:1528143645023};\\\", \\\"{x:1092,y:918,t:1528143645039};\\\", \\\"{x:1104,y:900,t:1528143645057};\\\", \\\"{x:1114,y:883,t:1528143645073};\\\", \\\"{x:1121,y:866,t:1528143645090};\\\", \\\"{x:1132,y:847,t:1528143645107};\\\", \\\"{x:1146,y:828,t:1528143645122};\\\", \\\"{x:1159,y:805,t:1528143645140};\\\", \\\"{x:1165,y:790,t:1528143645157};\\\", \\\"{x:1174,y:774,t:1528143645173};\\\", \\\"{x:1179,y:763,t:1528143645190};\\\", \\\"{x:1183,y:751,t:1528143645208};\\\", \\\"{x:1188,y:741,t:1528143645223};\\\", \\\"{x:1193,y:732,t:1528143645240};\\\", \\\"{x:1198,y:720,t:1528143645256};\\\", \\\"{x:1199,y:713,t:1528143645273};\\\", \\\"{x:1199,y:708,t:1528143645290};\\\", \\\"{x:1200,y:703,t:1528143645307};\\\", \\\"{x:1201,y:700,t:1528143645323};\\\", \\\"{x:1203,y:696,t:1528143645340};\\\", \\\"{x:1205,y:692,t:1528143645358};\\\", \\\"{x:1209,y:685,t:1528143645373};\\\", \\\"{x:1213,y:678,t:1528143645390};\\\", \\\"{x:1219,y:670,t:1528143645406};\\\", \\\"{x:1223,y:665,t:1528143645423};\\\", \\\"{x:1230,y:660,t:1528143645439};\\\", \\\"{x:1234,y:657,t:1528143645457};\\\", \\\"{x:1235,y:656,t:1528143645473};\\\", \\\"{x:1238,y:646,t:1528143646112};\\\", \\\"{x:1242,y:634,t:1528143646124};\\\", \\\"{x:1252,y:613,t:1528143646141};\\\", \\\"{x:1259,y:600,t:1528143646157};\\\", \\\"{x:1262,y:596,t:1528143646174};\\\", \\\"{x:1264,y:592,t:1528143646191};\\\", \\\"{x:1265,y:590,t:1528143646207};\\\", \\\"{x:1265,y:589,t:1528143646231};\\\", \\\"{x:1266,y:588,t:1528143646241};\\\", \\\"{x:1267,y:586,t:1528143646258};\\\", \\\"{x:1268,y:584,t:1528143646274};\\\", \\\"{x:1269,y:582,t:1528143646291};\\\", \\\"{x:1271,y:578,t:1528143646308};\\\", \\\"{x:1272,y:576,t:1528143646328};\\\", \\\"{x:1273,y:574,t:1528143646341};\\\", \\\"{x:1276,y:570,t:1528143646358};\\\", \\\"{x:1280,y:562,t:1528143646375};\\\", \\\"{x:1289,y:549,t:1528143646392};\\\", \\\"{x:1290,y:548,t:1528143646407};\\\", \\\"{x:1290,y:546,t:1528143646424};\\\", \\\"{x:1291,y:545,t:1528143646441};\\\", \\\"{x:1289,y:546,t:1528143646816};\\\", \\\"{x:1282,y:551,t:1528143646825};\\\", \\\"{x:1276,y:554,t:1528143646841};\\\", \\\"{x:1273,y:555,t:1528143646858};\\\", \\\"{x:1272,y:555,t:1528143646875};\\\", \\\"{x:1271,y:556,t:1528143647151};\\\", \\\"{x:1271,y:557,t:1528143647167};\\\", \\\"{x:1273,y:558,t:1528143647175};\\\", \\\"{x:1274,y:558,t:1528143647192};\\\", \\\"{x:1275,y:559,t:1528143647215};\\\", \\\"{x:1277,y:560,t:1528143647232};\\\", \\\"{x:1275,y:560,t:1528143647577};\\\", \\\"{x:1227,y:568,t:1528143647592};\\\", \\\"{x:1139,y:579,t:1528143647609};\\\", \\\"{x:997,y:581,t:1528143647625};\\\", \\\"{x:812,y:581,t:1528143647644};\\\", \\\"{x:643,y:581,t:1528143647659};\\\", \\\"{x:555,y:581,t:1528143647675};\\\", \\\"{x:538,y:581,t:1528143647684};\\\", \\\"{x:528,y:581,t:1528143647701};\\\", \\\"{x:528,y:580,t:1528143647742};\\\", \\\"{x:529,y:574,t:1528143647839};\\\", \\\"{x:532,y:568,t:1528143647851};\\\", \\\"{x:545,y:549,t:1528143647871};\\\", \\\"{x:551,y:537,t:1528143647885};\\\", \\\"{x:558,y:527,t:1528143647903};\\\", \\\"{x:561,y:523,t:1528143647919};\\\", \\\"{x:562,y:522,t:1528143647942};\\\", \\\"{x:563,y:521,t:1528143647974};\\\", \\\"{x:565,y:520,t:1528143647998};\\\", \\\"{x:566,y:520,t:1528143648007};\\\", \\\"{x:569,y:520,t:1528143648019};\\\", \\\"{x:572,y:520,t:1528143648036};\\\", \\\"{x:576,y:520,t:1528143648053};\\\", \\\"{x:583,y:520,t:1528143648069};\\\", \\\"{x:588,y:520,t:1528143648086};\\\", \\\"{x:600,y:518,t:1528143648103};\\\", \\\"{x:606,y:516,t:1528143648120};\\\", \\\"{x:610,y:514,t:1528143648135};\\\", \\\"{x:615,y:511,t:1528143648153};\\\", \\\"{x:620,y:509,t:1528143648169};\\\", \\\"{x:622,y:507,t:1528143648187};\\\", \\\"{x:623,y:506,t:1528143648911};\\\", \\\"{x:630,y:506,t:1528143648919};\\\", \\\"{x:663,y:493,t:1528143648938};\\\", \\\"{x:761,y:485,t:1528143648954};\\\", \\\"{x:891,y:485,t:1528143648970};\\\", \\\"{x:1024,y:485,t:1528143648987};\\\", \\\"{x:1132,y:485,t:1528143649004};\\\", \\\"{x:1191,y:485,t:1528143649020};\\\", \\\"{x:1218,y:485,t:1528143649037};\\\", \\\"{x:1227,y:486,t:1528143649055};\\\", \\\"{x:1227,y:487,t:1528143649079};\\\", \\\"{x:1227,y:489,t:1528143649096};\\\", \\\"{x:1227,y:490,t:1528143649103};\\\", \\\"{x:1228,y:496,t:1528143649120};\\\", \\\"{x:1228,y:500,t:1528143649137};\\\", \\\"{x:1231,y:513,t:1528143649154};\\\", \\\"{x:1233,y:531,t:1528143649170};\\\", \\\"{x:1243,y:548,t:1528143649187};\\\", \\\"{x:1252,y:567,t:1528143649204};\\\", \\\"{x:1262,y:586,t:1528143649220};\\\", \\\"{x:1277,y:602,t:1528143649237};\\\", \\\"{x:1295,y:616,t:1528143649254};\\\", \\\"{x:1303,y:623,t:1528143649270};\\\", \\\"{x:1305,y:624,t:1528143649287};\\\", \\\"{x:1306,y:624,t:1528143649496};\\\", \\\"{x:1305,y:624,t:1528143650135};\\\", \\\"{x:1300,y:626,t:1528143650143};\\\", \\\"{x:1292,y:638,t:1528143650154};\\\", \\\"{x:1276,y:672,t:1528143650171};\\\", \\\"{x:1251,y:716,t:1528143650187};\\\", \\\"{x:1224,y:755,t:1528143650204};\\\", \\\"{x:1211,y:774,t:1528143650221};\\\", \\\"{x:1202,y:788,t:1528143650238};\\\", \\\"{x:1199,y:794,t:1528143650254};\\\", \\\"{x:1190,y:815,t:1528143650271};\\\", \\\"{x:1185,y:832,t:1528143650287};\\\", \\\"{x:1181,y:845,t:1528143650304};\\\", \\\"{x:1170,y:864,t:1528143650321};\\\", \\\"{x:1159,y:880,t:1528143650339};\\\", \\\"{x:1148,y:893,t:1528143650355};\\\", \\\"{x:1143,y:901,t:1528143650371};\\\", \\\"{x:1133,y:911,t:1528143650388};\\\", \\\"{x:1126,y:919,t:1528143650404};\\\", \\\"{x:1121,y:924,t:1528143650421};\\\", \\\"{x:1117,y:929,t:1528143650438};\\\", \\\"{x:1113,y:932,t:1528143650455};\\\", \\\"{x:1103,y:945,t:1528143650471};\\\", \\\"{x:1095,y:954,t:1528143650488};\\\", \\\"{x:1086,y:963,t:1528143650504};\\\", \\\"{x:1076,y:969,t:1528143650522};\\\", \\\"{x:1070,y:973,t:1528143650538};\\\", \\\"{x:1066,y:975,t:1528143650554};\\\", \\\"{x:1063,y:978,t:1528143650571};\\\", \\\"{x:1059,y:980,t:1528143650589};\\\", \\\"{x:1058,y:982,t:1528143650605};\\\", \\\"{x:1055,y:984,t:1528143650621};\\\", \\\"{x:1052,y:985,t:1528143650638};\\\", \\\"{x:1051,y:986,t:1528143650655};\\\", \\\"{x:1051,y:987,t:1528143650671};\\\", \\\"{x:1050,y:988,t:1528143650744};\\\", \\\"{x:1050,y:986,t:1528143650903};\\\", \\\"{x:1052,y:971,t:1528143650911};\\\", \\\"{x:1060,y:945,t:1528143650921};\\\", \\\"{x:1084,y:897,t:1528143650938};\\\", \\\"{x:1120,y:835,t:1528143650955};\\\", \\\"{x:1153,y:775,t:1528143650971};\\\", \\\"{x:1172,y:742,t:1528143650989};\\\", \\\"{x:1188,y:719,t:1528143651005};\\\", \\\"{x:1202,y:700,t:1528143651022};\\\", \\\"{x:1213,y:685,t:1528143651038};\\\", \\\"{x:1227,y:662,t:1528143651055};\\\", \\\"{x:1236,y:647,t:1528143651071};\\\", \\\"{x:1245,y:635,t:1528143651089};\\\", \\\"{x:1254,y:625,t:1528143651104};\\\", \\\"{x:1261,y:617,t:1528143651122};\\\", \\\"{x:1263,y:614,t:1528143651137};\\\", \\\"{x:1265,y:613,t:1528143651155};\\\", \\\"{x:1265,y:612,t:1528143651171};\\\", \\\"{x:1265,y:611,t:1528143651206};\\\", \\\"{x:1266,y:610,t:1528143651222};\\\", \\\"{x:1267,y:607,t:1528143651238};\\\", \\\"{x:1269,y:601,t:1528143651254};\\\", \\\"{x:1270,y:596,t:1528143651271};\\\", \\\"{x:1270,y:593,t:1528143651288};\\\", \\\"{x:1270,y:588,t:1528143651305};\\\", \\\"{x:1273,y:584,t:1528143651321};\\\", \\\"{x:1273,y:581,t:1528143651338};\\\", \\\"{x:1273,y:578,t:1528143651355};\\\", \\\"{x:1273,y:575,t:1528143651372};\\\", \\\"{x:1273,y:571,t:1528143651388};\\\", \\\"{x:1274,y:570,t:1528143651405};\\\", \\\"{x:1274,y:569,t:1528143651422};\\\", \\\"{x:1275,y:568,t:1528143651439};\\\", \\\"{x:1275,y:567,t:1528143651455};\\\", \\\"{x:1276,y:565,t:1528143651472};\\\", \\\"{x:1277,y:563,t:1528143651489};\\\", \\\"{x:1278,y:562,t:1528143651505};\\\", \\\"{x:1278,y:560,t:1528143651522};\\\", \\\"{x:1279,y:559,t:1528143651538};\\\", \\\"{x:1280,y:558,t:1528143651555};\\\", \\\"{x:1280,y:557,t:1528143651572};\\\", \\\"{x:1280,y:556,t:1528143651607};\\\", \\\"{x:1280,y:557,t:1528143651918};\\\", \\\"{x:1279,y:557,t:1528143651925};\\\", \\\"{x:1279,y:558,t:1528143651938};\\\", \\\"{x:1279,y:559,t:1528143652311};\\\", \\\"{x:1279,y:561,t:1528143652322};\\\", \\\"{x:1280,y:564,t:1528143652339};\\\", \\\"{x:1280,y:565,t:1528143652356};\\\", \\\"{x:1280,y:566,t:1528143652372};\\\", \\\"{x:1281,y:568,t:1528143652389};\\\", \\\"{x:1283,y:571,t:1528143652407};\\\", \\\"{x:1283,y:572,t:1528143652423};\\\", \\\"{x:1284,y:575,t:1528143652439};\\\", \\\"{x:1285,y:576,t:1528143652456};\\\", \\\"{x:1286,y:577,t:1528143652472};\\\", \\\"{x:1286,y:578,t:1528143652489};\\\", \\\"{x:1286,y:579,t:1528143652506};\\\", \\\"{x:1287,y:581,t:1528143652522};\\\", \\\"{x:1289,y:585,t:1528143652539};\\\", \\\"{x:1290,y:587,t:1528143652556};\\\", \\\"{x:1292,y:589,t:1528143652572};\\\", \\\"{x:1294,y:591,t:1528143652589};\\\", \\\"{x:1296,y:596,t:1528143652606};\\\", \\\"{x:1296,y:598,t:1528143652622};\\\", \\\"{x:1300,y:604,t:1528143652640};\\\", \\\"{x:1303,y:611,t:1528143652656};\\\", \\\"{x:1308,y:619,t:1528143652673};\\\", \\\"{x:1311,y:627,t:1528143652689};\\\", \\\"{x:1315,y:634,t:1528143652706};\\\", \\\"{x:1317,y:639,t:1528143652723};\\\", \\\"{x:1318,y:642,t:1528143652739};\\\", \\\"{x:1319,y:647,t:1528143652756};\\\", \\\"{x:1322,y:651,t:1528143652774};\\\", \\\"{x:1324,y:656,t:1528143652789};\\\", \\\"{x:1325,y:660,t:1528143652806};\\\", \\\"{x:1328,y:665,t:1528143652824};\\\", \\\"{x:1328,y:666,t:1528143652840};\\\", \\\"{x:1331,y:670,t:1528143652857};\\\", \\\"{x:1332,y:671,t:1528143652873};\\\", \\\"{x:1332,y:673,t:1528143652889};\\\", \\\"{x:1334,y:676,t:1528143652906};\\\", \\\"{x:1335,y:677,t:1528143652922};\\\", \\\"{x:1336,y:681,t:1528143652938};\\\", \\\"{x:1339,y:683,t:1528143652956};\\\", \\\"{x:1341,y:687,t:1528143652973};\\\", \\\"{x:1343,y:690,t:1528143652989};\\\", \\\"{x:1346,y:693,t:1528143653006};\\\", \\\"{x:1350,y:699,t:1528143653022};\\\", \\\"{x:1353,y:703,t:1528143653039};\\\", \\\"{x:1357,y:709,t:1528143653056};\\\", \\\"{x:1361,y:714,t:1528143653073};\\\", \\\"{x:1365,y:719,t:1528143653089};\\\", \\\"{x:1367,y:722,t:1528143653106};\\\", \\\"{x:1369,y:724,t:1528143653123};\\\", \\\"{x:1369,y:725,t:1528143653139};\\\", \\\"{x:1372,y:727,t:1528143653156};\\\", \\\"{x:1373,y:731,t:1528143653174};\\\", \\\"{x:1376,y:735,t:1528143653189};\\\", \\\"{x:1376,y:737,t:1528143653215};\\\", \\\"{x:1376,y:738,t:1528143653223};\\\", \\\"{x:1376,y:740,t:1528143653240};\\\", \\\"{x:1377,y:741,t:1528143653257};\\\", \\\"{x:1377,y:742,t:1528143653279};\\\", \\\"{x:1377,y:743,t:1528143653327};\\\", \\\"{x:1377,y:744,t:1528143653376};\\\", \\\"{x:1378,y:744,t:1528143653390};\\\", \\\"{x:1379,y:748,t:1528143653406};\\\", \\\"{x:1379,y:751,t:1528143653423};\\\", \\\"{x:1381,y:753,t:1528143653440};\\\", \\\"{x:1381,y:755,t:1528143653457};\\\", \\\"{x:1382,y:758,t:1528143653473};\\\", \\\"{x:1383,y:760,t:1528143653491};\\\", \\\"{x:1383,y:762,t:1528143653506};\\\", \\\"{x:1386,y:765,t:1528143653523};\\\", \\\"{x:1386,y:768,t:1528143653541};\\\", \\\"{x:1388,y:770,t:1528143653556};\\\", \\\"{x:1389,y:775,t:1528143653573};\\\", \\\"{x:1390,y:778,t:1528143653591};\\\", \\\"{x:1392,y:783,t:1528143653606};\\\", \\\"{x:1394,y:789,t:1528143653623};\\\", \\\"{x:1396,y:793,t:1528143653640};\\\", \\\"{x:1397,y:794,t:1528143653657};\\\", \\\"{x:1398,y:798,t:1528143653673};\\\", \\\"{x:1400,y:801,t:1528143653690};\\\", \\\"{x:1401,y:802,t:1528143653707};\\\", \\\"{x:1401,y:804,t:1528143653723};\\\", \\\"{x:1401,y:805,t:1528143653741};\\\", \\\"{x:1402,y:806,t:1528143653757};\\\", \\\"{x:1402,y:807,t:1528143653773};\\\", \\\"{x:1403,y:808,t:1528143653791};\\\", \\\"{x:1406,y:813,t:1528143653807};\\\", \\\"{x:1406,y:815,t:1528143653823};\\\", \\\"{x:1407,y:818,t:1528143653840};\\\", \\\"{x:1408,y:819,t:1528143653857};\\\", \\\"{x:1408,y:821,t:1528143653874};\\\", \\\"{x:1409,y:822,t:1528143653890};\\\", \\\"{x:1410,y:824,t:1528143653908};\\\", \\\"{x:1410,y:826,t:1528143653923};\\\", \\\"{x:1411,y:827,t:1528143653940};\\\", \\\"{x:1412,y:829,t:1528143653957};\\\", \\\"{x:1413,y:830,t:1528143653983};\\\", \\\"{x:1413,y:832,t:1528143654047};\\\", \\\"{x:1414,y:832,t:1528143654058};\\\", \\\"{x:1414,y:833,t:1528143654079};\\\", \\\"{x:1415,y:835,t:1528143654103};\\\", \\\"{x:1415,y:836,t:1528143654111};\\\", \\\"{x:1416,y:837,t:1528143654127};\\\", \\\"{x:1416,y:838,t:1528143654143};\\\", \\\"{x:1417,y:839,t:1528143654158};\\\", \\\"{x:1417,y:842,t:1528143654173};\\\", \\\"{x:1420,y:846,t:1528143654190};\\\", \\\"{x:1421,y:848,t:1528143654206};\\\", \\\"{x:1423,y:852,t:1528143654223};\\\", \\\"{x:1425,y:856,t:1528143654240};\\\", \\\"{x:1426,y:859,t:1528143654257};\\\", \\\"{x:1428,y:865,t:1528143654273};\\\", \\\"{x:1429,y:868,t:1528143654290};\\\", \\\"{x:1431,y:874,t:1528143654307};\\\", \\\"{x:1434,y:881,t:1528143654324};\\\", \\\"{x:1434,y:887,t:1528143654340};\\\", \\\"{x:1438,y:894,t:1528143654357};\\\", \\\"{x:1441,y:898,t:1528143654374};\\\", \\\"{x:1444,y:903,t:1528143654390};\\\", \\\"{x:1448,y:910,t:1528143654406};\\\", \\\"{x:1449,y:912,t:1528143654424};\\\", \\\"{x:1451,y:914,t:1528143654439};\\\", \\\"{x:1453,y:919,t:1528143654457};\\\", \\\"{x:1454,y:921,t:1528143654474};\\\", \\\"{x:1455,y:923,t:1528143654490};\\\", \\\"{x:1457,y:927,t:1528143654508};\\\", \\\"{x:1459,y:930,t:1528143654524};\\\", \\\"{x:1461,y:934,t:1528143654541};\\\", \\\"{x:1462,y:937,t:1528143654557};\\\", \\\"{x:1464,y:939,t:1528143654574};\\\", \\\"{x:1465,y:942,t:1528143654591};\\\", \\\"{x:1467,y:947,t:1528143654607};\\\", \\\"{x:1468,y:947,t:1528143654625};\\\", \\\"{x:1468,y:950,t:1528143654640};\\\", \\\"{x:1469,y:953,t:1528143654657};\\\", \\\"{x:1469,y:958,t:1528143654675};\\\", \\\"{x:1470,y:963,t:1528143654691};\\\", \\\"{x:1471,y:965,t:1528143654707};\\\", \\\"{x:1471,y:967,t:1528143655055};\\\", \\\"{x:1465,y:967,t:1528143655063};\\\", \\\"{x:1453,y:967,t:1528143655074};\\\", \\\"{x:1430,y:967,t:1528143655091};\\\", \\\"{x:1409,y:968,t:1528143655107};\\\", \\\"{x:1391,y:969,t:1528143655124};\\\", \\\"{x:1386,y:969,t:1528143655142};\\\", \\\"{x:1384,y:970,t:1528143655157};\\\", \\\"{x:1384,y:968,t:1528143655247};\\\", \\\"{x:1384,y:965,t:1528143655258};\\\", \\\"{x:1384,y:956,t:1528143655275};\\\", \\\"{x:1385,y:948,t:1528143655291};\\\", \\\"{x:1387,y:937,t:1528143655309};\\\", \\\"{x:1390,y:930,t:1528143655324};\\\", \\\"{x:1392,y:926,t:1528143655342};\\\", \\\"{x:1393,y:925,t:1528143655359};\\\", \\\"{x:1393,y:924,t:1528143655375};\\\", \\\"{x:1393,y:923,t:1528143655392};\\\", \\\"{x:1393,y:922,t:1528143655408};\\\", \\\"{x:1394,y:921,t:1528143655511};\\\", \\\"{x:1394,y:919,t:1528143655727};\\\", \\\"{x:1394,y:910,t:1528143655742};\\\", \\\"{x:1390,y:901,t:1528143655759};\\\", \\\"{x:1388,y:893,t:1528143655775};\\\", \\\"{x:1387,y:892,t:1528143655791};\\\", \\\"{x:1384,y:892,t:1528143655984};\\\", \\\"{x:1381,y:892,t:1528143655991};\\\", \\\"{x:1376,y:892,t:1528143656010};\\\", \\\"{x:1372,y:894,t:1528143656026};\\\", \\\"{x:1371,y:896,t:1528143656041};\\\", \\\"{x:1368,y:897,t:1528143656059};\\\", \\\"{x:1366,y:899,t:1528143656075};\\\", \\\"{x:1364,y:902,t:1528143656092};\\\", \\\"{x:1361,y:907,t:1528143656108};\\\", \\\"{x:1356,y:914,t:1528143656125};\\\", \\\"{x:1353,y:922,t:1528143656141};\\\", \\\"{x:1348,y:930,t:1528143656158};\\\", \\\"{x:1347,y:936,t:1528143656175};\\\", \\\"{x:1347,y:938,t:1528143656191};\\\", \\\"{x:1344,y:941,t:1528143656208};\\\", \\\"{x:1344,y:944,t:1528143656226};\\\", \\\"{x:1341,y:951,t:1528143656241};\\\", \\\"{x:1339,y:958,t:1528143656258};\\\", \\\"{x:1335,y:964,t:1528143656276};\\\", \\\"{x:1332,y:968,t:1528143656292};\\\", \\\"{x:1331,y:970,t:1528143656309};\\\", \\\"{x:1332,y:970,t:1528143656846};\\\", \\\"{x:1337,y:970,t:1528143656859};\\\", \\\"{x:1343,y:970,t:1528143656874};\\\", \\\"{x:1346,y:969,t:1528143656892};\\\", \\\"{x:1348,y:968,t:1528143656909};\\\", \\\"{x:1349,y:967,t:1528143656982};\\\", \\\"{x:1349,y:966,t:1528143657791};\\\", \\\"{x:1349,y:961,t:1528143657809};\\\", \\\"{x:1349,y:959,t:1528143657827};\\\", \\\"{x:1350,y:957,t:1528143657842};\\\", \\\"{x:1351,y:956,t:1528143657859};\\\", \\\"{x:1351,y:955,t:1528143657877};\\\", \\\"{x:1351,y:953,t:1528143657894};\\\", \\\"{x:1352,y:951,t:1528143657911};\\\", \\\"{x:1352,y:949,t:1528143657927};\\\", \\\"{x:1353,y:947,t:1528143657943};\\\", \\\"{x:1354,y:945,t:1528143657960};\\\", \\\"{x:1355,y:943,t:1528143657977};\\\", \\\"{x:1357,y:941,t:1528143657993};\\\", \\\"{x:1359,y:938,t:1528143658009};\\\", \\\"{x:1361,y:935,t:1528143658026};\\\", \\\"{x:1364,y:931,t:1528143658044};\\\", \\\"{x:1366,y:928,t:1528143658060};\\\", \\\"{x:1368,y:923,t:1528143658077};\\\", \\\"{x:1371,y:919,t:1528143658095};\\\", \\\"{x:1372,y:918,t:1528143658110};\\\", \\\"{x:1375,y:915,t:1528143658127};\\\", \\\"{x:1377,y:911,t:1528143658143};\\\", \\\"{x:1380,y:907,t:1528143658160};\\\", \\\"{x:1381,y:905,t:1528143658176};\\\", \\\"{x:1383,y:903,t:1528143658193};\\\", \\\"{x:1383,y:902,t:1528143658215};\\\", \\\"{x:1385,y:900,t:1528143658227};\\\", \\\"{x:1385,y:899,t:1528143658244};\\\", \\\"{x:1387,y:898,t:1528143658261};\\\", \\\"{x:1387,y:897,t:1528143658328};\\\", \\\"{x:1389,y:901,t:1528143658719};\\\", \\\"{x:1390,y:904,t:1528143658727};\\\", \\\"{x:1390,y:908,t:1528143658743};\\\", \\\"{x:1392,y:910,t:1528143658760};\\\", \\\"{x:1392,y:912,t:1528143658777};\\\", \\\"{x:1393,y:915,t:1528143658793};\\\", \\\"{x:1393,y:916,t:1528143658810};\\\", \\\"{x:1393,y:917,t:1528143658826};\\\", \\\"{x:1394,y:918,t:1528143658844};\\\", \\\"{x:1395,y:920,t:1528143658861};\\\", \\\"{x:1395,y:922,t:1528143658876};\\\", \\\"{x:1396,y:923,t:1528143658895};\\\", \\\"{x:1396,y:924,t:1528143658911};\\\", \\\"{x:1396,y:925,t:1528143658928};\\\", \\\"{x:1396,y:926,t:1528143658951};\\\", \\\"{x:1397,y:928,t:1528143658967};\\\", \\\"{x:1398,y:929,t:1528143658984};\\\", \\\"{x:1398,y:930,t:1528143658994};\\\", \\\"{x:1400,y:933,t:1528143659011};\\\", \\\"{x:1400,y:935,t:1528143659027};\\\", \\\"{x:1401,y:937,t:1528143659044};\\\", \\\"{x:1402,y:939,t:1528143659060};\\\", \\\"{x:1403,y:941,t:1528143659077};\\\", \\\"{x:1404,y:945,t:1528143659095};\\\", \\\"{x:1406,y:946,t:1528143659111};\\\", \\\"{x:1407,y:951,t:1528143659127};\\\", \\\"{x:1409,y:954,t:1528143659144};\\\", \\\"{x:1411,y:956,t:1528143659160};\\\", \\\"{x:1412,y:957,t:1528143659178};\\\", \\\"{x:1412,y:958,t:1528143659194};\\\", \\\"{x:1413,y:961,t:1528143659211};\\\", \\\"{x:1414,y:962,t:1528143659227};\\\", \\\"{x:1414,y:963,t:1528143659263};\\\", \\\"{x:1415,y:963,t:1528143659278};\\\", \\\"{x:1415,y:964,t:1528143659296};\\\", \\\"{x:1416,y:964,t:1528143659311};\\\", \\\"{x:1417,y:966,t:1528143659370};\\\", \\\"{x:1418,y:966,t:1528143659377};\\\", \\\"{x:1414,y:962,t:1528143660751};\\\", \\\"{x:1414,y:960,t:1528143660762};\\\", \\\"{x:1410,y:957,t:1528143660778};\\\", \\\"{x:1408,y:950,t:1528143660795};\\\", \\\"{x:1404,y:942,t:1528143660812};\\\", \\\"{x:1404,y:938,t:1528143660829};\\\", \\\"{x:1401,y:932,t:1528143660844};\\\", \\\"{x:1400,y:929,t:1528143660862};\\\", \\\"{x:1400,y:924,t:1528143660878};\\\", \\\"{x:1398,y:922,t:1528143660895};\\\", \\\"{x:1398,y:921,t:1528143660911};\\\", \\\"{x:1397,y:917,t:1528143660929};\\\", \\\"{x:1394,y:910,t:1528143660945};\\\", \\\"{x:1392,y:899,t:1528143660962};\\\", \\\"{x:1391,y:886,t:1528143660979};\\\", \\\"{x:1382,y:863,t:1528143660995};\\\", \\\"{x:1382,y:854,t:1528143661012};\\\", \\\"{x:1382,y:853,t:1528143661028};\\\", \\\"{x:1382,y:851,t:1528143661046};\\\", \\\"{x:1381,y:853,t:1528143661176};\\\", \\\"{x:1378,y:856,t:1528143661183};\\\", \\\"{x:1378,y:859,t:1528143661196};\\\", \\\"{x:1372,y:873,t:1528143661211};\\\", \\\"{x:1371,y:883,t:1528143661229};\\\", \\\"{x:1370,y:891,t:1528143661246};\\\", \\\"{x:1369,y:896,t:1528143661261};\\\", \\\"{x:1369,y:901,t:1528143661279};\\\", \\\"{x:1368,y:903,t:1528143661295};\\\", \\\"{x:1368,y:904,t:1528143661311};\\\", \\\"{x:1367,y:906,t:1528143661328};\\\", \\\"{x:1367,y:907,t:1528143661391};\\\", \\\"{x:1366,y:910,t:1528143661399};\\\", \\\"{x:1366,y:911,t:1528143661412};\\\", \\\"{x:1365,y:913,t:1528143661428};\\\", \\\"{x:1365,y:915,t:1528143661446};\\\", \\\"{x:1365,y:917,t:1528143661462};\\\", \\\"{x:1365,y:921,t:1528143661479};\\\", \\\"{x:1362,y:923,t:1528143661496};\\\", \\\"{x:1362,y:925,t:1528143661512};\\\", \\\"{x:1362,y:926,t:1528143661529};\\\", \\\"{x:1362,y:927,t:1528143661546};\\\", \\\"{x:1362,y:928,t:1528143661563};\\\", \\\"{x:1361,y:928,t:1528143661579};\\\", \\\"{x:1361,y:929,t:1528143661607};\\\", \\\"{x:1361,y:930,t:1528143661671};\\\", \\\"{x:1361,y:932,t:1528143661751};\\\", \\\"{x:1361,y:933,t:1528143661762};\\\", \\\"{x:1361,y:935,t:1528143661779};\\\", \\\"{x:1358,y:939,t:1528143661795};\\\", \\\"{x:1358,y:942,t:1528143661812};\\\", \\\"{x:1355,y:946,t:1528143661828};\\\", \\\"{x:1355,y:948,t:1528143661845};\\\", \\\"{x:1354,y:949,t:1528143661862};\\\", \\\"{x:1354,y:950,t:1528143661878};\\\", \\\"{x:1354,y:951,t:1528143661895};\\\", \\\"{x:1354,y:952,t:1528143661951};\\\", \\\"{x:1354,y:950,t:1528143662127};\\\", \\\"{x:1357,y:946,t:1528143662135};\\\", \\\"{x:1358,y:943,t:1528143662145};\\\", \\\"{x:1362,y:938,t:1528143662163};\\\", \\\"{x:1365,y:931,t:1528143662180};\\\", \\\"{x:1369,y:925,t:1528143662196};\\\", \\\"{x:1373,y:917,t:1528143662213};\\\", \\\"{x:1376,y:911,t:1528143662229};\\\", \\\"{x:1379,y:907,t:1528143662246};\\\", \\\"{x:1381,y:902,t:1528143662263};\\\", \\\"{x:1382,y:899,t:1528143662279};\\\", \\\"{x:1383,y:897,t:1528143662295};\\\", \\\"{x:1384,y:896,t:1528143662327};\\\", \\\"{x:1385,y:895,t:1528143662359};\\\", \\\"{x:1385,y:894,t:1528143662423};\\\", \\\"{x:1385,y:895,t:1528143662696};\\\", \\\"{x:1387,y:898,t:1528143662713};\\\", \\\"{x:1387,y:899,t:1528143662729};\\\", \\\"{x:1388,y:900,t:1528143662808};\\\", \\\"{x:1389,y:901,t:1528143662815};\\\", \\\"{x:1389,y:902,t:1528143662831};\\\", \\\"{x:1390,y:904,t:1528143662847};\\\", \\\"{x:1390,y:905,t:1528143662863};\\\", \\\"{x:1391,y:906,t:1528143662887};\\\", \\\"{x:1391,y:907,t:1528143662911};\\\", \\\"{x:1392,y:908,t:1528143662935};\\\", \\\"{x:1390,y:908,t:1528143664407};\\\", \\\"{x:1384,y:902,t:1528143664415};\\\", \\\"{x:1379,y:896,t:1528143664431};\\\", \\\"{x:1374,y:892,t:1528143664448};\\\", \\\"{x:1371,y:890,t:1528143664464};\\\", \\\"{x:1370,y:889,t:1528143664481};\\\", \\\"{x:1369,y:889,t:1528143664719};\\\", \\\"{x:1369,y:890,t:1528143664815};\\\", \\\"{x:1369,y:893,t:1528143664831};\\\", \\\"{x:1369,y:894,t:1528143664847};\\\", \\\"{x:1369,y:895,t:1528143664865};\\\", \\\"{x:1369,y:896,t:1528143664881};\\\", \\\"{x:1369,y:897,t:1528143664899};\\\", \\\"{x:1369,y:898,t:1528143665095};\\\", \\\"{x:1369,y:897,t:1528143665159};\\\", \\\"{x:1369,y:896,t:1528143665167};\\\", \\\"{x:1371,y:896,t:1528143665181};\\\", \\\"{x:1372,y:896,t:1528143665198};\\\", \\\"{x:1374,y:896,t:1528143665263};\\\", \\\"{x:1375,y:896,t:1528143665282};\\\", \\\"{x:1376,y:896,t:1528143665312};\\\", \\\"{x:1375,y:895,t:1528143665480};\\\", \\\"{x:1363,y:893,t:1528143665498};\\\", \\\"{x:1356,y:892,t:1528143665515};\\\", \\\"{x:1349,y:892,t:1528143665532};\\\", \\\"{x:1343,y:892,t:1528143665547};\\\", \\\"{x:1339,y:892,t:1528143665565};\\\", \\\"{x:1337,y:893,t:1528143665582};\\\", \\\"{x:1334,y:894,t:1528143665598};\\\", \\\"{x:1329,y:896,t:1528143665615};\\\", \\\"{x:1323,y:897,t:1528143665631};\\\", \\\"{x:1312,y:898,t:1528143665648};\\\", \\\"{x:1304,y:901,t:1528143665665};\\\", \\\"{x:1295,y:905,t:1528143665682};\\\", \\\"{x:1286,y:910,t:1528143665699};\\\", \\\"{x:1281,y:913,t:1528143665715};\\\", \\\"{x:1274,y:916,t:1528143665732};\\\", \\\"{x:1272,y:917,t:1528143665749};\\\", \\\"{x:1271,y:918,t:1528143665765};\\\", \\\"{x:1269,y:918,t:1528143665791};\\\", \\\"{x:1268,y:918,t:1528143665798};\\\", \\\"{x:1249,y:917,t:1528143665815};\\\", \\\"{x:1230,y:909,t:1528143665832};\\\", \\\"{x:1213,y:901,t:1528143665849};\\\", \\\"{x:1199,y:898,t:1528143665865};\\\", \\\"{x:1183,y:894,t:1528143665881};\\\", \\\"{x:1177,y:893,t:1528143665899};\\\", \\\"{x:1173,y:893,t:1528143665915};\\\", \\\"{x:1173,y:894,t:1528143666095};\\\", \\\"{x:1173,y:895,t:1528143666103};\\\", \\\"{x:1173,y:897,t:1528143666115};\\\", \\\"{x:1174,y:898,t:1528143666132};\\\", \\\"{x:1174,y:899,t:1528143666149};\\\", \\\"{x:1174,y:896,t:1528143666240};\\\", \\\"{x:1174,y:893,t:1528143666249};\\\", \\\"{x:1170,y:886,t:1528143666266};\\\", \\\"{x:1166,y:881,t:1528143666281};\\\", \\\"{x:1164,y:877,t:1528143666299};\\\", \\\"{x:1162,y:876,t:1528143666315};\\\", \\\"{x:1161,y:875,t:1528143666332};\\\", \\\"{x:1161,y:874,t:1528143666349};\\\", \\\"{x:1157,y:875,t:1528143666543};\\\", \\\"{x:1155,y:875,t:1528143666551};\\\", \\\"{x:1154,y:875,t:1528143666566};\\\", \\\"{x:1150,y:876,t:1528143666582};\\\", \\\"{x:1146,y:876,t:1528143666599};\\\", \\\"{x:1145,y:876,t:1528143666639};\\\", \\\"{x:1145,y:875,t:1528143667152};\\\", \\\"{x:1145,y:871,t:1528143667166};\\\", \\\"{x:1151,y:854,t:1528143667183};\\\", \\\"{x:1157,y:845,t:1528143667199};\\\", \\\"{x:1162,y:833,t:1528143667216};\\\", \\\"{x:1166,y:826,t:1528143667233};\\\", \\\"{x:1167,y:822,t:1528143667249};\\\", \\\"{x:1169,y:819,t:1528143667266};\\\", \\\"{x:1169,y:816,t:1528143667282};\\\", \\\"{x:1170,y:813,t:1528143667300};\\\", \\\"{x:1171,y:812,t:1528143667316};\\\", \\\"{x:1173,y:809,t:1528143667333};\\\", \\\"{x:1173,y:808,t:1528143667350};\\\", \\\"{x:1173,y:807,t:1528143667366};\\\", \\\"{x:1174,y:805,t:1528143667455};\\\", \\\"{x:1175,y:805,t:1528143667712};\\\", \\\"{x:1176,y:805,t:1528143667719};\\\", \\\"{x:1177,y:804,t:1528143667732};\\\", \\\"{x:1180,y:802,t:1528143667750};\\\", \\\"{x:1195,y:783,t:1528143667767};\\\", \\\"{x:1206,y:762,t:1528143667783};\\\", \\\"{x:1216,y:743,t:1528143667800};\\\", \\\"{x:1224,y:728,t:1528143667816};\\\", \\\"{x:1225,y:724,t:1528143667832};\\\", \\\"{x:1226,y:723,t:1528143667850};\\\", \\\"{x:1225,y:723,t:1528143667878};\\\", \\\"{x:1216,y:728,t:1528143667886};\\\", \\\"{x:1205,y:736,t:1528143667900};\\\", \\\"{x:1176,y:763,t:1528143667918};\\\", \\\"{x:1121,y:821,t:1528143667933};\\\", \\\"{x:1057,y:865,t:1528143667950};\\\", \\\"{x:973,y:921,t:1528143667967};\\\", \\\"{x:871,y:949,t:1528143667983};\\\", \\\"{x:808,y:956,t:1528143668000};\\\", \\\"{x:749,y:956,t:1528143668017};\\\", \\\"{x:696,y:942,t:1528143668033};\\\", \\\"{x:656,y:928,t:1528143668050};\\\", \\\"{x:623,y:909,t:1528143668067};\\\", \\\"{x:587,y:894,t:1528143668083};\\\", \\\"{x:568,y:883,t:1528143668100};\\\", \\\"{x:561,y:877,t:1528143668116};\\\", \\\"{x:559,y:871,t:1528143668133};\\\", \\\"{x:559,y:859,t:1528143668150};\\\", \\\"{x:559,y:838,t:1528143668167};\\\", \\\"{x:559,y:828,t:1528143668183};\\\", \\\"{x:559,y:822,t:1528143668199};\\\", \\\"{x:558,y:815,t:1528143668216};\\\", \\\"{x:557,y:806,t:1528143668233};\\\", \\\"{x:556,y:796,t:1528143668249};\\\", \\\"{x:556,y:788,t:1528143668267};\\\", \\\"{x:552,y:776,t:1528143668284};\\\", \\\"{x:546,y:764,t:1528143668300};\\\", \\\"{x:542,y:758,t:1528143668317};\\\", \\\"{x:540,y:755,t:1528143668334};\\\", \\\"{x:536,y:752,t:1528143668351};\\\", \\\"{x:529,y:747,t:1528143668366};\\\", \\\"{x:529,y:746,t:1528143668383};\\\", \\\"{x:527,y:745,t:1528143668402};\\\", \\\"{x:526,y:744,t:1528143668418};\\\", \\\"{x:525,y:743,t:1528143668486};\\\" ] }, { \\\"rt\\\": 6066, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 14, \\\"time_elapsed\\\": 760684, \\\"internal_node_id\\\": \\\"0.0-6.0-4.0\\\", \\\"subject\\\": \\\"06217\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"zulu\\\", \\\"condition\\\": \\\"211\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"ends\\\", \\\"q\\\": 10, \\\"clicks\\\": 1, \\\"explicit\\\": 2, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XInside-YFull\\\", \\\"correct\\\": 1, \\\"orth_correct\\\": 0, \\\"answer\\\": [ \\\"E\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-3-F -F \\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:524,y:743,t:1528143670968};\\\", \\\"{x:523,y:743,t:1528143671990};\\\", \\\"{x:523,y:742,t:1528143672021};\\\", \\\"{x:523,y:741,t:1528143672046};\\\", \\\"{x:523,y:740,t:1528143672079};\\\", \\\"{x:523,y:739,t:1528143672118};\\\", \\\"{x:523,y:738,t:1528143672136};\\\", \\\"{x:523,y:737,t:1528143672279};\\\", \\\"{x:524,y:736,t:1528143672286};\\\", \\\"{x:530,y:736,t:1528143672302};\\\", \\\"{x:538,y:736,t:1528143672320};\\\", \\\"{x:549,y:736,t:1528143672336};\\\", \\\"{x:569,y:740,t:1528143672354};\\\", \\\"{x:588,y:743,t:1528143672369};\\\", \\\"{x:609,y:748,t:1528143672385};\\\", \\\"{x:629,y:756,t:1528143672404};\\\", \\\"{x:661,y:766,t:1528143672421};\\\", \\\"{x:674,y:768,t:1528143672437};\\\", \\\"{x:691,y:769,t:1528143672455};\\\", \\\"{x:700,y:769,t:1528143672472};\\\", \\\"{x:712,y:771,t:1528143672488};\\\", \\\"{x:723,y:771,t:1528143672505};\\\", \\\"{x:731,y:771,t:1528143672521};\\\", \\\"{x:734,y:771,t:1528143672539};\\\", \\\"{x:739,y:770,t:1528143672556};\\\", \\\"{x:743,y:769,t:1528143672571};\\\", \\\"{x:764,y:765,t:1528143672589};\\\", \\\"{x:774,y:765,t:1528143672606};\\\", \\\"{x:778,y:765,t:1528143672622};\\\", \\\"{x:785,y:766,t:1528143672638};\\\", \\\"{x:798,y:769,t:1528143672656};\\\", \\\"{x:811,y:770,t:1528143672672};\\\", \\\"{x:821,y:770,t:1528143672689};\\\", \\\"{x:835,y:770,t:1528143672705};\\\", \\\"{x:850,y:770,t:1528143672722};\\\", \\\"{x:864,y:770,t:1528143672739};\\\", \\\"{x:880,y:770,t:1528143672755};\\\", \\\"{x:904,y:770,t:1528143672771};\\\", \\\"{x:937,y:770,t:1528143672789};\\\", \\\"{x:963,y:770,t:1528143672806};\\\", \\\"{x:994,y:770,t:1528143672822};\\\", \\\"{x:1038,y:770,t:1528143672838};\\\", \\\"{x:1062,y:770,t:1528143672856};\\\", \\\"{x:1084,y:767,t:1528143672872};\\\", \\\"{x:1101,y:762,t:1528143672889};\\\", \\\"{x:1117,y:759,t:1528143672905};\\\", \\\"{x:1131,y:755,t:1528143672922};\\\", \\\"{x:1151,y:750,t:1528143672939};\\\", \\\"{x:1173,y:744,t:1528143672956};\\\", \\\"{x:1197,y:740,t:1528143672972};\\\", \\\"{x:1215,y:737,t:1528143672989};\\\", \\\"{x:1229,y:732,t:1528143673006};\\\", \\\"{x:1246,y:728,t:1528143673022};\\\", \\\"{x:1272,y:719,t:1528143673039};\\\", \\\"{x:1289,y:712,t:1528143673056};\\\", \\\"{x:1301,y:707,t:1528143673075};\\\", \\\"{x:1310,y:704,t:1528143673089};\\\", \\\"{x:1326,y:701,t:1528143673106};\\\", \\\"{x:1342,y:696,t:1528143673125};\\\", \\\"{x:1354,y:695,t:1528143673139};\\\", \\\"{x:1362,y:694,t:1528143673156};\\\", \\\"{x:1364,y:693,t:1528143673172};\\\", \\\"{x:1366,y:692,t:1528143673188};\\\", \\\"{x:1367,y:692,t:1528143673206};\\\", \\\"{x:1369,y:691,t:1528143673221};\\\", \\\"{x:1371,y:690,t:1528143673239};\\\", \\\"{x:1373,y:689,t:1528143673256};\\\", \\\"{x:1375,y:689,t:1528143673273};\\\", \\\"{x:1374,y:689,t:1528143673392};\\\", \\\"{x:1373,y:689,t:1528143673406};\\\", \\\"{x:1372,y:689,t:1528143673430};\\\", \\\"{x:1371,y:689,t:1528143673439};\\\", \\\"{x:1370,y:689,t:1528143673463};\\\", \\\"{x:1370,y:690,t:1528143673474};\\\", \\\"{x:1369,y:690,t:1528143673489};\\\", \\\"{x:1367,y:691,t:1528143673506};\\\", \\\"{x:1365,y:692,t:1528143673523};\\\", \\\"{x:1363,y:693,t:1528143673558};\\\", \\\"{x:1362,y:694,t:1528143673581};\\\", \\\"{x:1361,y:694,t:1528143673598};\\\", \\\"{x:1360,y:694,t:1528143673622};\\\", \\\"{x:1357,y:694,t:1528143673727};\\\", \\\"{x:1356,y:694,t:1528143673759};\\\", \\\"{x:1355,y:696,t:1528143673773};\\\", \\\"{x:1354,y:696,t:1528143673790};\\\", \\\"{x:1353,y:696,t:1528143673807};\\\", \\\"{x:1347,y:698,t:1528143673822};\\\", \\\"{x:1345,y:700,t:1528143673840};\\\", \\\"{x:1344,y:700,t:1528143673856};\\\", \\\"{x:1344,y:701,t:1528143674023};\\\", \\\"{x:1337,y:705,t:1528143674041};\\\", \\\"{x:1314,y:707,t:1528143674056};\\\", \\\"{x:1260,y:708,t:1528143674074};\\\", \\\"{x:1120,y:701,t:1528143674090};\\\", \\\"{x:957,y:678,t:1528143674106};\\\", \\\"{x:788,y:647,t:1528143674122};\\\", \\\"{x:630,y:603,t:1528143674141};\\\", \\\"{x:491,y:573,t:1528143674157};\\\", \\\"{x:414,y:543,t:1528143674173};\\\", \\\"{x:372,y:523,t:1528143674190};\\\", \\\"{x:369,y:519,t:1528143674207};\\\", \\\"{x:368,y:514,t:1528143674224};\\\", \\\"{x:360,y:503,t:1528143674241};\\\", \\\"{x:343,y:492,t:1528143674256};\\\", \\\"{x:313,y:487,t:1528143674273};\\\", \\\"{x:284,y:484,t:1528143674291};\\\", \\\"{x:271,y:483,t:1528143674306};\\\", \\\"{x:270,y:481,t:1528143674323};\\\", \\\"{x:285,y:475,t:1528143674340};\\\", \\\"{x:302,y:469,t:1528143674358};\\\", \\\"{x:348,y:465,t:1528143674373};\\\", \\\"{x:399,y:465,t:1528143674390};\\\", \\\"{x:441,y:465,t:1528143674407};\\\", \\\"{x:511,y:466,t:1528143674425};\\\", \\\"{x:570,y:476,t:1528143674441};\\\", \\\"{x:609,y:481,t:1528143674457};\\\", \\\"{x:634,y:487,t:1528143674476};\\\", \\\"{x:642,y:487,t:1528143674492};\\\", \\\"{x:641,y:489,t:1528143674518};\\\", \\\"{x:638,y:490,t:1528143674525};\\\", \\\"{x:636,y:492,t:1528143674540};\\\", \\\"{x:633,y:493,t:1528143674558};\\\", \\\"{x:632,y:494,t:1528143674573};\\\", \\\"{x:630,y:495,t:1528143674590};\\\", \\\"{x:626,y:495,t:1528143674607};\\\", \\\"{x:624,y:496,t:1528143674623};\\\", \\\"{x:623,y:497,t:1528143674641};\\\", \\\"{x:622,y:498,t:1528143674657};\\\", \\\"{x:622,y:499,t:1528143675055};\\\", \\\"{x:621,y:508,t:1528143675062};\\\", \\\"{x:601,y:527,t:1528143675076};\\\", \\\"{x:560,y:579,t:1528143675090};\\\", \\\"{x:532,y:618,t:1528143675107};\\\", \\\"{x:515,y:640,t:1528143675125};\\\", \\\"{x:508,y:650,t:1528143675140};\\\", \\\"{x:505,y:657,t:1528143675157};\\\", \\\"{x:500,y:666,t:1528143675174};\\\", \\\"{x:496,y:675,t:1528143675190};\\\", \\\"{x:491,y:686,t:1528143675207};\\\", \\\"{x:485,y:698,t:1528143675225};\\\", \\\"{x:480,y:715,t:1528143675240};\\\", \\\"{x:471,y:727,t:1528143675258};\\\", \\\"{x:464,y:737,t:1528143675275};\\\", \\\"{x:460,y:746,t:1528143675291};\\\", \\\"{x:455,y:754,t:1528143675308};\\\", \\\"{x:453,y:762,t:1528143675325};\\\", \\\"{x:451,y:771,t:1528143675342};\\\", \\\"{x:448,y:777,t:1528143675358};\\\", \\\"{x:447,y:779,t:1528143675374};\\\", \\\"{x:452,y:779,t:1528143675519};\\\", \\\"{x:455,y:778,t:1528143675527};\\\", \\\"{x:459,y:774,t:1528143675542};\\\", \\\"{x:463,y:771,t:1528143675558};\\\", \\\"{x:467,y:768,t:1528143675575};\\\", \\\"{x:468,y:766,t:1528143675592};\\\", \\\"{x:469,y:762,t:1528143675607};\\\", \\\"{x:471,y:758,t:1528143675625};\\\", \\\"{x:474,y:753,t:1528143675643};\\\", \\\"{x:475,y:750,t:1528143675657};\\\", \\\"{x:477,y:748,t:1528143675674};\\\", \\\"{x:479,y:747,t:1528143675691};\\\", \\\"{x:479,y:748,t:1528143675822};\\\", \\\"{x:479,y:749,t:1528143675830};\\\", \\\"{x:480,y:750,t:1528143675854};\\\", \\\"{x:481,y:750,t:1528143675870};\\\", \\\"{x:482,y:750,t:1528143675878};\\\", \\\"{x:484,y:750,t:1528143675892};\\\", \\\"{x:487,y:747,t:1528143675908};\\\", \\\"{x:491,y:742,t:1528143675926};\\\", \\\"{x:495,y:737,t:1528143675941};\\\", \\\"{x:499,y:730,t:1528143675958};\\\", \\\"{x:501,y:728,t:1528143675976};\\\", \\\"{x:501,y:727,t:1528143675992};\\\", \\\"{x:502,y:727,t:1528143676718};\\\" ] }, { \\\"rt\\\": 7889, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 15, \\\"time_elapsed\\\": 769802, \\\"internal_node_id\\\": \\\"0.0-6.0-5.0\\\", \\\"subject\\\": \\\"06217\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"zulu\\\", \\\"condition\\\": \\\"211\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"starttime\\\", \\\"q\\\": 11, \\\"clicks\\\": 2.5, \\\"explicit\\\": 2, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XInside-YFull\\\", \\\"correct\\\": 1, \\\"orth_correct\\\": 0, \\\"answer\\\": [ \\\"M\\\", \\\"L\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-09 AM-10 AM-12 PM\\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:505,y:725,t:1528143678255};\\\", \\\"{x:508,y:723,t:1528143678262};\\\", \\\"{x:509,y:723,t:1528143678275};\\\", \\\"{x:510,y:722,t:1528143678292};\\\", \\\"{x:511,y:722,t:1528143678308};\\\", \\\"{x:513,y:722,t:1528143678334};\\\", \\\"{x:521,y:723,t:1528143678343};\\\", \\\"{x:578,y:738,t:1528143678359};\\\", \\\"{x:665,y:751,t:1528143678374};\\\", \\\"{x:678,y:749,t:1528143678393};\\\", \\\"{x:678,y:748,t:1528143678410};\\\", \\\"{x:680,y:748,t:1528143679095};\\\", \\\"{x:681,y:748,t:1528143679142};\\\", \\\"{x:682,y:748,t:1528143679151};\\\", \\\"{x:685,y:748,t:1528143679162};\\\", \\\"{x:692,y:748,t:1528143679178};\\\", \\\"{x:713,y:752,t:1528143679195};\\\", \\\"{x:746,y:765,t:1528143679212};\\\", \\\"{x:788,y:784,t:1528143679228};\\\", \\\"{x:828,y:805,t:1528143679245};\\\", \\\"{x:890,y:839,t:1528143679263};\\\", \\\"{x:930,y:858,t:1528143679278};\\\", \\\"{x:952,y:870,t:1528143679295};\\\", \\\"{x:965,y:880,t:1528143679312};\\\", \\\"{x:974,y:887,t:1528143679328};\\\", \\\"{x:979,y:894,t:1528143679345};\\\", \\\"{x:987,y:902,t:1528143679363};\\\", \\\"{x:991,y:909,t:1528143679378};\\\", \\\"{x:997,y:915,t:1528143679395};\\\", \\\"{x:1003,y:922,t:1528143679413};\\\", \\\"{x:1010,y:927,t:1528143679429};\\\", \\\"{x:1023,y:935,t:1528143679445};\\\", \\\"{x:1049,y:945,t:1528143679462};\\\", \\\"{x:1067,y:949,t:1528143679479};\\\", \\\"{x:1084,y:954,t:1528143679495};\\\", \\\"{x:1097,y:958,t:1528143679512};\\\", \\\"{x:1116,y:964,t:1528143679529};\\\", \\\"{x:1137,y:968,t:1528143679545};\\\", \\\"{x:1158,y:974,t:1528143679562};\\\", \\\"{x:1175,y:979,t:1528143679580};\\\", \\\"{x:1192,y:983,t:1528143679595};\\\", \\\"{x:1204,y:984,t:1528143679612};\\\", \\\"{x:1215,y:988,t:1528143679630};\\\", \\\"{x:1225,y:990,t:1528143679646};\\\", \\\"{x:1236,y:993,t:1528143679662};\\\", \\\"{x:1239,y:994,t:1528143679679};\\\", \\\"{x:1242,y:996,t:1528143679696};\\\", \\\"{x:1243,y:996,t:1528143679712};\\\", \\\"{x:1245,y:996,t:1528143679729};\\\", \\\"{x:1248,y:996,t:1528143679746};\\\", \\\"{x:1253,y:996,t:1528143679762};\\\", \\\"{x:1262,y:997,t:1528143679780};\\\", \\\"{x:1268,y:997,t:1528143679796};\\\", \\\"{x:1275,y:997,t:1528143679813};\\\", \\\"{x:1283,y:997,t:1528143679829};\\\", \\\"{x:1297,y:997,t:1528143679847};\\\", \\\"{x:1311,y:997,t:1528143679862};\\\", \\\"{x:1321,y:996,t:1528143679879};\\\", \\\"{x:1328,y:995,t:1528143679896};\\\", \\\"{x:1333,y:992,t:1528143679912};\\\", \\\"{x:1337,y:991,t:1528143679929};\\\", \\\"{x:1340,y:989,t:1528143679946};\\\", \\\"{x:1343,y:987,t:1528143679962};\\\", \\\"{x:1347,y:985,t:1528143679979};\\\", \\\"{x:1347,y:984,t:1528143679997};\\\", \\\"{x:1349,y:984,t:1528143680012};\\\", \\\"{x:1350,y:983,t:1528143680029};\\\", \\\"{x:1352,y:981,t:1528143680047};\\\", \\\"{x:1354,y:978,t:1528143680063};\\\", \\\"{x:1355,y:976,t:1528143680080};\\\", \\\"{x:1357,y:975,t:1528143680096};\\\", \\\"{x:1358,y:974,t:1528143680114};\\\", \\\"{x:1359,y:971,t:1528143680129};\\\", \\\"{x:1360,y:970,t:1528143680159};\\\", \\\"{x:1361,y:969,t:1528143680174};\\\", \\\"{x:1361,y:968,t:1528143680191};\\\", \\\"{x:1362,y:967,t:1528143680215};\\\", \\\"{x:1362,y:965,t:1528143680238};\\\", \\\"{x:1363,y:962,t:1528143680255};\\\", \\\"{x:1363,y:960,t:1528143680263};\\\", \\\"{x:1364,y:958,t:1528143680279};\\\", \\\"{x:1365,y:955,t:1528143680296};\\\", \\\"{x:1365,y:953,t:1528143680313};\\\", \\\"{x:1367,y:950,t:1528143680330};\\\", \\\"{x:1367,y:949,t:1528143680346};\\\", \\\"{x:1369,y:945,t:1528143680363};\\\", \\\"{x:1370,y:940,t:1528143680380};\\\", \\\"{x:1373,y:936,t:1528143680396};\\\", \\\"{x:1377,y:931,t:1528143680413};\\\", \\\"{x:1379,y:926,t:1528143680430};\\\", \\\"{x:1381,y:922,t:1528143680446};\\\", \\\"{x:1382,y:920,t:1528143680463};\\\", \\\"{x:1382,y:918,t:1528143680480};\\\", \\\"{x:1383,y:915,t:1528143680496};\\\", \\\"{x:1384,y:913,t:1528143680514};\\\", \\\"{x:1384,y:911,t:1528143680530};\\\", \\\"{x:1384,y:909,t:1528143680546};\\\", \\\"{x:1384,y:908,t:1528143680575};\\\", \\\"{x:1384,y:907,t:1528143680590};\\\", \\\"{x:1384,y:906,t:1528143680599};\\\", \\\"{x:1384,y:905,t:1528143680671};\\\", \\\"{x:1383,y:905,t:1528143681783};\\\", \\\"{x:1383,y:906,t:1528143681799};\\\", \\\"{x:1381,y:906,t:1528143681814};\\\", \\\"{x:1378,y:906,t:1528143681831};\\\", \\\"{x:1376,y:905,t:1528143681848};\\\", \\\"{x:1370,y:903,t:1528143681865};\\\", \\\"{x:1354,y:903,t:1528143681880};\\\", \\\"{x:1326,y:903,t:1528143681897};\\\", \\\"{x:1266,y:898,t:1528143681914};\\\", \\\"{x:1163,y:882,t:1528143681930};\\\", \\\"{x:1015,y:849,t:1528143681947};\\\", \\\"{x:841,y:797,t:1528143681964};\\\", \\\"{x:657,y:721,t:1528143681981};\\\", \\\"{x:446,y:624,t:1528143681999};\\\", \\\"{x:392,y:584,t:1528143682015};\\\", \\\"{x:376,y:570,t:1528143682031};\\\", \\\"{x:376,y:567,t:1528143682046};\\\", \\\"{x:376,y:562,t:1528143682063};\\\", \\\"{x:385,y:555,t:1528143682080};\\\", \\\"{x:398,y:549,t:1528143682097};\\\", \\\"{x:416,y:541,t:1528143682112};\\\", \\\"{x:424,y:538,t:1528143682129};\\\", \\\"{x:428,y:536,t:1528143682146};\\\", \\\"{x:431,y:536,t:1528143682205};\\\", \\\"{x:438,y:536,t:1528143682214};\\\", \\\"{x:455,y:536,t:1528143682230};\\\", \\\"{x:460,y:536,t:1528143682247};\\\", \\\"{x:461,y:536,t:1528143682302};\\\", \\\"{x:461,y:537,t:1528143682326};\\\", \\\"{x:457,y:540,t:1528143682334};\\\", \\\"{x:455,y:540,t:1528143682347};\\\", \\\"{x:452,y:541,t:1528143682362};\\\", \\\"{x:451,y:541,t:1528143682422};\\\", \\\"{x:450,y:541,t:1528143682439};\\\", \\\"{x:449,y:541,t:1528143682446};\\\", \\\"{x:446,y:541,t:1528143682463};\\\", \\\"{x:445,y:541,t:1528143682480};\\\", \\\"{x:443,y:541,t:1528143682497};\\\", \\\"{x:440,y:541,t:1528143682513};\\\", \\\"{x:436,y:539,t:1528143682530};\\\", \\\"{x:435,y:539,t:1528143682547};\\\", \\\"{x:434,y:539,t:1528143682574};\\\", \\\"{x:433,y:539,t:1528143682599};\\\", \\\"{x:432,y:539,t:1528143682613};\\\", \\\"{x:431,y:539,t:1528143682630};\\\", \\\"{x:429,y:539,t:1528143682646};\\\", \\\"{x:427,y:539,t:1528143682663};\\\", \\\"{x:426,y:540,t:1528143682934};\\\", \\\"{x:423,y:541,t:1528143682945};\\\", \\\"{x:412,y:541,t:1528143682963};\\\", \\\"{x:407,y:541,t:1528143682979};\\\", \\\"{x:405,y:541,t:1528143682996};\\\", \\\"{x:402,y:541,t:1528143683013};\\\", \\\"{x:400,y:541,t:1528143683199};\\\", \\\"{x:399,y:541,t:1528143683247};\\\", \\\"{x:397,y:541,t:1528143683271};\\\", \\\"{x:396,y:541,t:1528143683294};\\\", \\\"{x:394,y:541,t:1528143683311};\\\", \\\"{x:393,y:541,t:1528143683351};\\\", \\\"{x:391,y:541,t:1528143683455};\\\", \\\"{x:390,y:541,t:1528143683502};\\\", \\\"{x:390,y:542,t:1528143683789};\\\", \\\"{x:390,y:543,t:1528143683797};\\\", \\\"{x:389,y:544,t:1528143683814};\\\", \\\"{x:387,y:549,t:1528143683831};\\\", \\\"{x:386,y:554,t:1528143683848};\\\", \\\"{x:385,y:557,t:1528143683866};\\\", \\\"{x:383,y:560,t:1528143683880};\\\", \\\"{x:381,y:566,t:1528143683899};\\\", \\\"{x:376,y:578,t:1528143683915};\\\", \\\"{x:369,y:595,t:1528143683931};\\\", \\\"{x:366,y:606,t:1528143683949};\\\", \\\"{x:365,y:611,t:1528143683965};\\\", \\\"{x:364,y:614,t:1528143683981};\\\", \\\"{x:365,y:614,t:1528143684238};\\\", \\\"{x:367,y:614,t:1528143684248};\\\", \\\"{x:371,y:614,t:1528143684265};\\\", \\\"{x:377,y:614,t:1528143684283};\\\", \\\"{x:379,y:616,t:1528143684298};\\\", \\\"{x:382,y:617,t:1528143684315};\\\", \\\"{x:383,y:618,t:1528143684318};\\\", \\\"{x:385,y:618,t:1528143684349};\\\", \\\"{x:385,y:618,t:1528143684457};\\\", \\\"{x:387,y:620,t:1528143684654};\\\", \\\"{x:395,y:622,t:1528143684664};\\\", \\\"{x:449,y:653,t:1528143684682};\\\", \\\"{x:535,y:709,t:1528143684697};\\\", \\\"{x:628,y:745,t:1528143684714};\\\", \\\"{x:709,y:783,t:1528143684732};\\\", \\\"{x:748,y:795,t:1528143684748};\\\", \\\"{x:762,y:799,t:1528143684765};\\\", \\\"{x:761,y:799,t:1528143684790};\\\", \\\"{x:750,y:797,t:1528143684799};\\\", \\\"{x:711,y:790,t:1528143684814};\\\", \\\"{x:663,y:783,t:1528143684831};\\\", \\\"{x:620,y:768,t:1528143684849};\\\", \\\"{x:586,y:756,t:1528143684865};\\\", \\\"{x:555,y:742,t:1528143684883};\\\", \\\"{x:531,y:733,t:1528143684899};\\\", \\\"{x:516,y:727,t:1528143684915};\\\", \\\"{x:515,y:726,t:1528143684932};\\\", \\\"{x:515,y:728,t:1528143685063};\\\", \\\"{x:516,y:729,t:1528143685070};\\\", \\\"{x:516,y:730,t:1528143685082};\\\", \\\"{x:517,y:731,t:1528143685099};\\\", \\\"{x:518,y:731,t:1528143685115};\\\", \\\"{x:518,y:732,t:1528143685191};\\\", \\\"{x:518,y:733,t:1528143685199};\\\", \\\"{x:518,y:734,t:1528143685230};\\\" ] }, { \\\"rt\\\": 9964, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 16, \\\"time_elapsed\\\": 781057, \\\"internal_node_id\\\": \\\"0.0-6.0-6.0\\\", \\\"subject\\\": \\\"06217\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"zulu\\\", \\\"condition\\\": \\\"211\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"starts\\\", \\\"q\\\": 12, \\\"clicks\\\": 1, \\\"explicit\\\": 2, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XInside-YFull\\\", \\\"correct\\\": 1, \\\"orth_correct\\\": 0, \\\"answer\\\": [ \\\"G\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-J -F -F -G -G \\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:520,y:734,t:1528143687391};\\\", \\\"{x:525,y:734,t:1528143687400};\\\", \\\"{x:554,y:758,t:1528143687417};\\\", \\\"{x:606,y:769,t:1528143687434};\\\", \\\"{x:666,y:780,t:1528143687451};\\\", \\\"{x:746,y:791,t:1528143687468};\\\", \\\"{x:816,y:800,t:1528143687484};\\\", \\\"{x:882,y:809,t:1528143687501};\\\", \\\"{x:953,y:816,t:1528143687518};\\\", \\\"{x:977,y:819,t:1528143687535};\\\", \\\"{x:1002,y:822,t:1528143687552};\\\", \\\"{x:1024,y:824,t:1528143687569};\\\", \\\"{x:1048,y:824,t:1528143687585};\\\", \\\"{x:1072,y:824,t:1528143687601};\\\", \\\"{x:1096,y:822,t:1528143687618};\\\", \\\"{x:1116,y:820,t:1528143687636};\\\", \\\"{x:1135,y:819,t:1528143687652};\\\", \\\"{x:1150,y:816,t:1528143687669};\\\", \\\"{x:1163,y:815,t:1528143687686};\\\", \\\"{x:1178,y:815,t:1528143687702};\\\", \\\"{x:1192,y:815,t:1528143687719};\\\", \\\"{x:1197,y:815,t:1528143687736};\\\", \\\"{x:1203,y:814,t:1528143687752};\\\", \\\"{x:1211,y:814,t:1528143687769};\\\", \\\"{x:1222,y:814,t:1528143687787};\\\", \\\"{x:1240,y:814,t:1528143687802};\\\", \\\"{x:1255,y:814,t:1528143687818};\\\", \\\"{x:1274,y:814,t:1528143687836};\\\", \\\"{x:1298,y:814,t:1528143687852};\\\", \\\"{x:1319,y:814,t:1528143687869};\\\", \\\"{x:1337,y:814,t:1528143687886};\\\", \\\"{x:1353,y:809,t:1528143687902};\\\", \\\"{x:1359,y:807,t:1528143687919};\\\", \\\"{x:1362,y:807,t:1528143687936};\\\", \\\"{x:1363,y:806,t:1528143687953};\\\", \\\"{x:1365,y:805,t:1528143687982};\\\", \\\"{x:1369,y:802,t:1528143688043};\\\", \\\"{x:1370,y:801,t:1528143688061};\\\", \\\"{x:1370,y:800,t:1528143688069};\\\", \\\"{x:1371,y:800,t:1528143688093};\\\", \\\"{x:1371,y:799,t:1528143688102};\\\", \\\"{x:1373,y:797,t:1528143688118};\\\", \\\"{x:1376,y:794,t:1528143688135};\\\", \\\"{x:1378,y:792,t:1528143688152};\\\", \\\"{x:1381,y:789,t:1528143688169};\\\", \\\"{x:1384,y:786,t:1528143688185};\\\", \\\"{x:1386,y:783,t:1528143688202};\\\", \\\"{x:1389,y:780,t:1528143688219};\\\", \\\"{x:1392,y:776,t:1528143688236};\\\", \\\"{x:1396,y:771,t:1528143688252};\\\", \\\"{x:1401,y:764,t:1528143688269};\\\", \\\"{x:1404,y:759,t:1528143688286};\\\", \\\"{x:1404,y:756,t:1528143688302};\\\", \\\"{x:1404,y:753,t:1528143688319};\\\", \\\"{x:1404,y:750,t:1528143688337};\\\", \\\"{x:1404,y:749,t:1528143688352};\\\", \\\"{x:1404,y:745,t:1528143688369};\\\", \\\"{x:1404,y:743,t:1528143688386};\\\", \\\"{x:1403,y:739,t:1528143688403};\\\", \\\"{x:1403,y:737,t:1528143688420};\\\", \\\"{x:1401,y:734,t:1528143688436};\\\", \\\"{x:1393,y:722,t:1528143688452};\\\", \\\"{x:1390,y:711,t:1528143688469};\\\", \\\"{x:1387,y:701,t:1528143688487};\\\", \\\"{x:1386,y:696,t:1528143688503};\\\", \\\"{x:1385,y:693,t:1528143688519};\\\", \\\"{x:1384,y:692,t:1528143688537};\\\", \\\"{x:1382,y:690,t:1528143688554};\\\", \\\"{x:1381,y:689,t:1528143688574};\\\", \\\"{x:1379,y:689,t:1528143688599};\\\", \\\"{x:1377,y:690,t:1528143688614};\\\", \\\"{x:1375,y:690,t:1528143688622};\\\", \\\"{x:1372,y:690,t:1528143688637};\\\", \\\"{x:1371,y:690,t:1528143688654};\\\", \\\"{x:1370,y:690,t:1528143688670};\\\", \\\"{x:1369,y:690,t:1528143688686};\\\", \\\"{x:1368,y:691,t:1528143688704};\\\", \\\"{x:1367,y:691,t:1528143688720};\\\", \\\"{x:1366,y:691,t:1528143688750};\\\", \\\"{x:1365,y:691,t:1528143688766};\\\", \\\"{x:1364,y:691,t:1528143688775};\\\", \\\"{x:1363,y:691,t:1528143688787};\\\", \\\"{x:1361,y:691,t:1528143688804};\\\", \\\"{x:1356,y:691,t:1528143688820};\\\", \\\"{x:1353,y:692,t:1528143688836};\\\", \\\"{x:1352,y:692,t:1528143688863};\\\", \\\"{x:1351,y:692,t:1528143688873};\\\", \\\"{x:1350,y:692,t:1528143688886};\\\", \\\"{x:1348,y:693,t:1528143688903};\\\", \\\"{x:1346,y:693,t:1528143688920};\\\", \\\"{x:1344,y:694,t:1528143688935};\\\", \\\"{x:1343,y:694,t:1528143689029};\\\", \\\"{x:1341,y:694,t:1528143689054};\\\", \\\"{x:1340,y:694,t:1528143689070};\\\", \\\"{x:1339,y:695,t:1528143689088};\\\", \\\"{x:1341,y:690,t:1528143690510};\\\", \\\"{x:1347,y:681,t:1528143690523};\\\", \\\"{x:1356,y:669,t:1528143690540};\\\", \\\"{x:1366,y:655,t:1528143690556};\\\", \\\"{x:1376,y:645,t:1528143690573};\\\", \\\"{x:1384,y:635,t:1528143690589};\\\", \\\"{x:1390,y:623,t:1528143690606};\\\", \\\"{x:1402,y:603,t:1528143690622};\\\", \\\"{x:1408,y:594,t:1528143690639};\\\", \\\"{x:1412,y:583,t:1528143690657};\\\", \\\"{x:1417,y:575,t:1528143690672};\\\", \\\"{x:1420,y:569,t:1528143690689};\\\", \\\"{x:1422,y:564,t:1528143690706};\\\", \\\"{x:1423,y:563,t:1528143690722};\\\", \\\"{x:1425,y:560,t:1528143690740};\\\", \\\"{x:1427,y:557,t:1528143690756};\\\", \\\"{x:1428,y:556,t:1528143690773};\\\", \\\"{x:1429,y:554,t:1528143690789};\\\", \\\"{x:1429,y:553,t:1528143690855};\\\", \\\"{x:1429,y:552,t:1528143690862};\\\", \\\"{x:1429,y:551,t:1528143690873};\\\", \\\"{x:1428,y:551,t:1528143690943};\\\", \\\"{x:1427,y:551,t:1528143690959};\\\", \\\"{x:1425,y:551,t:1528143690974};\\\", \\\"{x:1424,y:552,t:1528143690989};\\\", \\\"{x:1423,y:552,t:1528143691006};\\\", \\\"{x:1421,y:552,t:1528143691143};\\\", \\\"{x:1418,y:554,t:1528143691157};\\\", \\\"{x:1408,y:561,t:1528143691175};\\\", \\\"{x:1384,y:591,t:1528143691190};\\\", \\\"{x:1368,y:613,t:1528143691206};\\\", \\\"{x:1351,y:631,t:1528143691224};\\\", \\\"{x:1338,y:645,t:1528143691240};\\\", \\\"{x:1323,y:663,t:1528143691257};\\\", \\\"{x:1308,y:681,t:1528143691273};\\\", \\\"{x:1277,y:709,t:1528143691291};\\\", \\\"{x:1230,y:740,t:1528143691307};\\\", \\\"{x:1168,y:770,t:1528143691323};\\\", \\\"{x:1128,y:777,t:1528143691341};\\\", \\\"{x:1072,y:778,t:1528143691358};\\\", \\\"{x:1024,y:778,t:1528143691374};\\\", \\\"{x:915,y:756,t:1528143691390};\\\", \\\"{x:824,y:735,t:1528143691408};\\\", \\\"{x:738,y:708,t:1528143691423};\\\", \\\"{x:657,y:684,t:1528143691441};\\\", \\\"{x:593,y:665,t:1528143691458};\\\", \\\"{x:550,y:652,t:1528143691473};\\\", \\\"{x:528,y:643,t:1528143691491};\\\", \\\"{x:507,y:634,t:1528143691507};\\\", \\\"{x:483,y:621,t:1528143691525};\\\", \\\"{x:455,y:615,t:1528143691540};\\\", \\\"{x:373,y:598,t:1528143691558};\\\", \\\"{x:338,y:593,t:1528143691571};\\\", \\\"{x:287,y:583,t:1528143691587};\\\", \\\"{x:265,y:579,t:1528143691605};\\\", \\\"{x:257,y:576,t:1528143691621};\\\", \\\"{x:255,y:575,t:1528143691636};\\\", \\\"{x:255,y:573,t:1528143691661};\\\", \\\"{x:255,y:572,t:1528143691671};\\\", \\\"{x:261,y:566,t:1528143691687};\\\", \\\"{x:267,y:561,t:1528143691705};\\\", \\\"{x:277,y:554,t:1528143691722};\\\", \\\"{x:293,y:548,t:1528143691737};\\\", \\\"{x:312,y:540,t:1528143691754};\\\", \\\"{x:327,y:535,t:1528143691771};\\\", \\\"{x:340,y:532,t:1528143691787};\\\", \\\"{x:346,y:530,t:1528143691804};\\\", \\\"{x:350,y:529,t:1528143691821};\\\", \\\"{x:351,y:529,t:1528143691870};\\\", \\\"{x:353,y:527,t:1528143691877};\\\", \\\"{x:360,y:527,t:1528143691889};\\\", \\\"{x:383,y:527,t:1528143691904};\\\", \\\"{x:399,y:527,t:1528143691921};\\\", \\\"{x:420,y:530,t:1528143691939};\\\", \\\"{x:450,y:530,t:1528143691955};\\\", \\\"{x:480,y:530,t:1528143691971};\\\", \\\"{x:513,y:530,t:1528143691991};\\\", \\\"{x:558,y:527,t:1528143692004};\\\", \\\"{x:602,y:522,t:1528143692022};\\\", \\\"{x:638,y:515,t:1528143692038};\\\", \\\"{x:643,y:515,t:1528143692054};\\\", \\\"{x:643,y:514,t:1528143692085};\\\", \\\"{x:644,y:514,t:1528143692133};\\\", \\\"{x:646,y:514,t:1528143692141};\\\", \\\"{x:650,y:511,t:1528143692154};\\\", \\\"{x:654,y:510,t:1528143692171};\\\", \\\"{x:659,y:507,t:1528143692188};\\\", \\\"{x:665,y:506,t:1528143692204};\\\", \\\"{x:666,y:506,t:1528143692221};\\\", \\\"{x:667,y:506,t:1528143692238};\\\", \\\"{x:671,y:506,t:1528143692254};\\\", \\\"{x:680,y:506,t:1528143692271};\\\", \\\"{x:696,y:506,t:1528143692288};\\\", \\\"{x:719,y:506,t:1528143692305};\\\", \\\"{x:750,y:501,t:1528143692324};\\\", \\\"{x:775,y:496,t:1528143692337};\\\", \\\"{x:795,y:496,t:1528143692355};\\\", \\\"{x:804,y:496,t:1528143692371};\\\", \\\"{x:808,y:497,t:1528143692388};\\\", \\\"{x:811,y:501,t:1528143692405};\\\", \\\"{x:816,y:506,t:1528143692421};\\\", \\\"{x:823,y:514,t:1528143692437};\\\", \\\"{x:827,y:517,t:1528143692455};\\\", \\\"{x:828,y:518,t:1528143692472};\\\", \\\"{x:828,y:519,t:1528143692526};\\\", \\\"{x:828,y:521,t:1528143692538};\\\", \\\"{x:831,y:527,t:1528143692556};\\\", \\\"{x:831,y:530,t:1528143692571};\\\", \\\"{x:832,y:531,t:1528143692588};\\\", \\\"{x:832,y:532,t:1528143692605};\\\", \\\"{x:833,y:535,t:1528143692621};\\\", \\\"{x:834,y:536,t:1528143692638};\\\", \\\"{x:835,y:537,t:1528143692655};\\\", \\\"{x:836,y:538,t:1528143692672};\\\", \\\"{x:837,y:538,t:1528143692749};\\\", \\\"{x:837,y:538,t:1528143692858};\\\", \\\"{x:838,y:538,t:1528143692965};\\\", \\\"{x:844,y:538,t:1528143692974};\\\", \\\"{x:852,y:537,t:1528143692988};\\\", \\\"{x:887,y:537,t:1528143693005};\\\", \\\"{x:1020,y:537,t:1528143693022};\\\", \\\"{x:1117,y:537,t:1528143693038};\\\", \\\"{x:1203,y:537,t:1528143693055};\\\", \\\"{x:1279,y:537,t:1528143693072};\\\", \\\"{x:1340,y:537,t:1528143693089};\\\", \\\"{x:1355,y:537,t:1528143693105};\\\", \\\"{x:1357,y:537,t:1528143693123};\\\", \\\"{x:1358,y:537,t:1528143693215};\\\", \\\"{x:1361,y:538,t:1528143693222};\\\", \\\"{x:1375,y:547,t:1528143693240};\\\", \\\"{x:1398,y:554,t:1528143693256};\\\", \\\"{x:1426,y:560,t:1528143693273};\\\", \\\"{x:1448,y:563,t:1528143693290};\\\", \\\"{x:1454,y:563,t:1528143693306};\\\", \\\"{x:1453,y:563,t:1528143693359};\\\", \\\"{x:1451,y:563,t:1528143693373};\\\", \\\"{x:1448,y:564,t:1528143693391};\\\", \\\"{x:1448,y:566,t:1528143693479};\\\", \\\"{x:1446,y:567,t:1528143693490};\\\", \\\"{x:1441,y:571,t:1528143693506};\\\", \\\"{x:1430,y:586,t:1528143693522};\\\", \\\"{x:1420,y:617,t:1528143693540};\\\", \\\"{x:1404,y:651,t:1528143693556};\\\", \\\"{x:1390,y:675,t:1528143693573};\\\", \\\"{x:1378,y:692,t:1528143693590};\\\", \\\"{x:1369,y:706,t:1528143693606};\\\", \\\"{x:1363,y:717,t:1528143693623};\\\", \\\"{x:1357,y:727,t:1528143693639};\\\", \\\"{x:1343,y:739,t:1528143693657};\\\", \\\"{x:1329,y:755,t:1528143693672};\\\", \\\"{x:1316,y:769,t:1528143693690};\\\", \\\"{x:1300,y:787,t:1528143693707};\\\", \\\"{x:1285,y:805,t:1528143693723};\\\", \\\"{x:1272,y:822,t:1528143693740};\\\", \\\"{x:1257,y:843,t:1528143693757};\\\", \\\"{x:1245,y:863,t:1528143693773};\\\", \\\"{x:1235,y:883,t:1528143693790};\\\", \\\"{x:1216,y:913,t:1528143693806};\\\", \\\"{x:1204,y:926,t:1528143693823};\\\", \\\"{x:1198,y:935,t:1528143693840};\\\", \\\"{x:1194,y:939,t:1528143693856};\\\", \\\"{x:1191,y:941,t:1528143693873};\\\", \\\"{x:1189,y:943,t:1528143693889};\\\", \\\"{x:1187,y:945,t:1528143693907};\\\", \\\"{x:1186,y:946,t:1528143693922};\\\", \\\"{x:1186,y:947,t:1528143693943};\\\", \\\"{x:1186,y:948,t:1528143693958};\\\", \\\"{x:1185,y:948,t:1528143693973};\\\", \\\"{x:1184,y:951,t:1528143693989};\\\", \\\"{x:1183,y:954,t:1528143694007};\\\", \\\"{x:1182,y:957,t:1528143694023};\\\", \\\"{x:1182,y:961,t:1528143694040};\\\", \\\"{x:1182,y:969,t:1528143694057};\\\", \\\"{x:1182,y:973,t:1528143694074};\\\", \\\"{x:1183,y:977,t:1528143694090};\\\", \\\"{x:1183,y:979,t:1528143694106};\\\", \\\"{x:1183,y:980,t:1528143694124};\\\", \\\"{x:1183,y:981,t:1528143694140};\\\", \\\"{x:1184,y:983,t:1528143694166};\\\", \\\"{x:1187,y:980,t:1528143694198};\\\", \\\"{x:1190,y:972,t:1528143694207};\\\", \\\"{x:1201,y:953,t:1528143694224};\\\", \\\"{x:1215,y:930,t:1528143694239};\\\", \\\"{x:1235,y:900,t:1528143694256};\\\", \\\"{x:1258,y:864,t:1528143694274};\\\", \\\"{x:1276,y:829,t:1528143694290};\\\", \\\"{x:1295,y:778,t:1528143694306};\\\", \\\"{x:1313,y:736,t:1528143694324};\\\", \\\"{x:1325,y:710,t:1528143694339};\\\", \\\"{x:1334,y:694,t:1528143694356};\\\", \\\"{x:1341,y:678,t:1528143694374};\\\", \\\"{x:1348,y:667,t:1528143694389};\\\", \\\"{x:1350,y:651,t:1528143694407};\\\", \\\"{x:1353,y:641,t:1528143694424};\\\", \\\"{x:1358,y:628,t:1528143694440};\\\", \\\"{x:1364,y:615,t:1528143694457};\\\", \\\"{x:1370,y:605,t:1528143694474};\\\", \\\"{x:1377,y:592,t:1528143694490};\\\", \\\"{x:1384,y:584,t:1528143694507};\\\", \\\"{x:1393,y:573,t:1528143694524};\\\", \\\"{x:1399,y:567,t:1528143694541};\\\", \\\"{x:1406,y:562,t:1528143694557};\\\", \\\"{x:1415,y:557,t:1528143694574};\\\", \\\"{x:1416,y:557,t:1528143694590};\\\", \\\"{x:1416,y:556,t:1528143694662};\\\", \\\"{x:1416,y:549,t:1528143694999};\\\", \\\"{x:1422,y:539,t:1528143695008};\\\", \\\"{x:1431,y:516,t:1528143695024};\\\", \\\"{x:1445,y:493,t:1528143695040};\\\", \\\"{x:1463,y:468,t:1528143695058};\\\", \\\"{x:1474,y:448,t:1528143695074};\\\", \\\"{x:1482,y:432,t:1528143695091};\\\", \\\"{x:1488,y:417,t:1528143695108};\\\", \\\"{x:1492,y:400,t:1528143695124};\\\", \\\"{x:1493,y:385,t:1528143695141};\\\", \\\"{x:1497,y:363,t:1528143695158};\\\", \\\"{x:1500,y:353,t:1528143695173};\\\", \\\"{x:1519,y:323,t:1528143695230};\\\", \\\"{x:1522,y:320,t:1528143695240};\\\", \\\"{x:1527,y:309,t:1528143695257};\\\", \\\"{x:1535,y:294,t:1528143695273};\\\", \\\"{x:1544,y:279,t:1528143695290};\\\", \\\"{x:1548,y:273,t:1528143695307};\\\", \\\"{x:1551,y:270,t:1528143695323};\\\", \\\"{x:1551,y:272,t:1528143695406};\\\", \\\"{x:1543,y:280,t:1528143695413};\\\", \\\"{x:1530,y:301,t:1528143695424};\\\", \\\"{x:1493,y:364,t:1528143695440};\\\", \\\"{x:1442,y:429,t:1528143695464};\\\", \\\"{x:1396,y:465,t:1528143695480};\\\", \\\"{x:1350,y:491,t:1528143695497};\\\", \\\"{x:1314,y:507,t:1528143695513};\\\", \\\"{x:1276,y:523,t:1528143695531};\\\", \\\"{x:1235,y:539,t:1528143695547};\\\", \\\"{x:1166,y:563,t:1528143695564};\\\", \\\"{x:1137,y:579,t:1528143695580};\\\", \\\"{x:1110,y:590,t:1528143695596};\\\", \\\"{x:1076,y:601,t:1528143695613};\\\", \\\"{x:1016,y:621,t:1528143695630};\\\", \\\"{x:925,y:647,t:1528143695646};\\\", \\\"{x:850,y:668,t:1528143695663};\\\", \\\"{x:806,y:680,t:1528143695680};\\\", \\\"{x:776,y:686,t:1528143695696};\\\", \\\"{x:749,y:692,t:1528143695713};\\\", \\\"{x:732,y:697,t:1528143695730};\\\", \\\"{x:717,y:705,t:1528143695746};\\\", \\\"{x:702,y:713,t:1528143695764};\\\", \\\"{x:696,y:717,t:1528143695780};\\\", \\\"{x:689,y:719,t:1528143695796};\\\", \\\"{x:674,y:721,t:1528143695813};\\\", \\\"{x:544,y:727,t:1528143695880};\\\", \\\"{x:473,y:721,t:1528143695896};\\\", \\\"{x:433,y:721,t:1528143695913};\\\", \\\"{x:412,y:721,t:1528143695930};\\\", \\\"{x:404,y:721,t:1528143695947};\\\", \\\"{x:403,y:721,t:1528143696108};\\\", \\\"{x:403,y:722,t:1528143696132};\\\", \\\"{x:403,y:723,t:1528143696148};\\\", \\\"{x:404,y:725,t:1528143696172};\\\", \\\"{x:405,y:725,t:1528143696180};\\\", \\\"{x:411,y:728,t:1528143696197};\\\", \\\"{x:418,y:729,t:1528143696213};\\\", \\\"{x:433,y:733,t:1528143696230};\\\", \\\"{x:451,y:735,t:1528143696249};\\\", \\\"{x:460,y:735,t:1528143696264};\\\", \\\"{x:470,y:735,t:1528143696280};\\\", \\\"{x:473,y:735,t:1528143696297};\\\", \\\"{x:474,y:735,t:1528143696468};\\\", \\\"{x:475,y:735,t:1528143696482};\\\", \\\"{x:477,y:737,t:1528143696498};\\\", \\\"{x:478,y:737,t:1528143696508};\\\", \\\"{x:479,y:737,t:1528143696539};\\\", \\\"{x:479,y:737,t:1528143696657};\\\" ] }, { \\\"rt\\\": 11448, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 17, \\\"time_elapsed\\\": 793821, \\\"internal_node_id\\\": \\\"0.0-6.0-7.0\\\", \\\"subject\\\": \\\"06217\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"zulu\\\", \\\"condition\\\": \\\"211\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"meets\\\", \\\"q\\\": 13, \\\"clicks\\\": 2, \\\"explicit\\\": 2, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XInside-YFull\\\", \\\"correct\\\": 1, \\\"orth_correct\\\": 0, \\\"answer\\\": [ \\\"E\\\", \\\"F\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-X -Z -E -E -E \\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:479,y:738,t:1528143699148};\\\", \\\"{x:476,y:741,t:1528143699156};\\\", \\\"{x:472,y:746,t:1528143699170};\\\", \\\"{x:461,y:753,t:1528143699186};\\\", \\\"{x:451,y:760,t:1528143699203};\\\", \\\"{x:445,y:762,t:1528143699220};\\\", \\\"{x:444,y:763,t:1528143699232};\\\", \\\"{x:442,y:764,t:1528143699249};\\\", \\\"{x:442,y:765,t:1528143699265};\\\", \\\"{x:440,y:766,t:1528143699282};\\\", \\\"{x:438,y:771,t:1528143699299};\\\", \\\"{x:437,y:773,t:1528143699315};\\\", \\\"{x:437,y:774,t:1528143699332};\\\", \\\"{x:437,y:776,t:1528143699349};\\\", \\\"{x:437,y:778,t:1528143699366};\\\", \\\"{x:439,y:780,t:1528143699383};\\\", \\\"{x:442,y:781,t:1528143699399};\\\", \\\"{x:451,y:785,t:1528143699416};\\\", \\\"{x:464,y:788,t:1528143699433};\\\", \\\"{x:469,y:789,t:1528143699450};\\\", \\\"{x:488,y:791,t:1528143699465};\\\", \\\"{x:514,y:795,t:1528143699482};\\\", \\\"{x:555,y:798,t:1528143699499};\\\", \\\"{x:580,y:800,t:1528143699516};\\\", \\\"{x:601,y:802,t:1528143699532};\\\", \\\"{x:618,y:802,t:1528143699550};\\\", \\\"{x:642,y:807,t:1528143699565};\\\", \\\"{x:668,y:812,t:1528143699582};\\\", \\\"{x:695,y:815,t:1528143699600};\\\", \\\"{x:724,y:820,t:1528143699616};\\\", \\\"{x:760,y:823,t:1528143699632};\\\", \\\"{x:789,y:825,t:1528143699649};\\\", \\\"{x:827,y:830,t:1528143699666};\\\", \\\"{x:872,y:837,t:1528143699682};\\\", \\\"{x:942,y:839,t:1528143699700};\\\", \\\"{x:1012,y:839,t:1528143699716};\\\", \\\"{x:1071,y:842,t:1528143699732};\\\", \\\"{x:1123,y:845,t:1528143699750};\\\", \\\"{x:1177,y:848,t:1528143699766};\\\", \\\"{x:1212,y:848,t:1528143699783};\\\", \\\"{x:1240,y:848,t:1528143699799};\\\", \\\"{x:1264,y:849,t:1528143699815};\\\", \\\"{x:1281,y:849,t:1528143699832};\\\", \\\"{x:1296,y:849,t:1528143699849};\\\", \\\"{x:1308,y:849,t:1528143699866};\\\", \\\"{x:1318,y:849,t:1528143699883};\\\", \\\"{x:1337,y:851,t:1528143699901};\\\", \\\"{x:1346,y:851,t:1528143699916};\\\", \\\"{x:1354,y:851,t:1528143699933};\\\", \\\"{x:1357,y:851,t:1528143699951};\\\", \\\"{x:1357,y:837,t:1528143699966};\\\", \\\"{x:1358,y:837,t:1528143700540};\\\", \\\"{x:1361,y:837,t:1528143700550};\\\", \\\"{x:1371,y:837,t:1528143700566};\\\", \\\"{x:1389,y:837,t:1528143700583};\\\", \\\"{x:1412,y:837,t:1528143700600};\\\", \\\"{x:1436,y:837,t:1528143700616};\\\", \\\"{x:1461,y:831,t:1528143700634};\\\", \\\"{x:1481,y:823,t:1528143700650};\\\", \\\"{x:1493,y:816,t:1528143700667};\\\", \\\"{x:1506,y:807,t:1528143700683};\\\", \\\"{x:1535,y:790,t:1528143700700};\\\", \\\"{x:1550,y:781,t:1528143700716};\\\", \\\"{x:1566,y:769,t:1528143700733};\\\", \\\"{x:1584,y:758,t:1528143700750};\\\", \\\"{x:1599,y:749,t:1528143700766};\\\", \\\"{x:1611,y:741,t:1528143700783};\\\", \\\"{x:1620,y:735,t:1528143700800};\\\", \\\"{x:1624,y:732,t:1528143700816};\\\", \\\"{x:1627,y:729,t:1528143700833};\\\", \\\"{x:1631,y:726,t:1528143700850};\\\", \\\"{x:1635,y:722,t:1528143700866};\\\", \\\"{x:1638,y:720,t:1528143700883};\\\", \\\"{x:1638,y:719,t:1528143700900};\\\", \\\"{x:1639,y:719,t:1528143700916};\\\", \\\"{x:1639,y:717,t:1528143700933};\\\", \\\"{x:1639,y:716,t:1528143700951};\\\", \\\"{x:1639,y:715,t:1528143700966};\\\", \\\"{x:1639,y:713,t:1528143700983};\\\", \\\"{x:1638,y:712,t:1528143701000};\\\", \\\"{x:1637,y:711,t:1528143701016};\\\", \\\"{x:1637,y:710,t:1528143701033};\\\", \\\"{x:1636,y:708,t:1528143701049};\\\", \\\"{x:1635,y:707,t:1528143701068};\\\", \\\"{x:1634,y:705,t:1528143701100};\\\", \\\"{x:1633,y:704,t:1528143701180};\\\", \\\"{x:1632,y:704,t:1528143701188};\\\", \\\"{x:1631,y:703,t:1528143701200};\\\", \\\"{x:1630,y:702,t:1528143701216};\\\", \\\"{x:1629,y:701,t:1528143701233};\\\", \\\"{x:1628,y:701,t:1528143701250};\\\", \\\"{x:1626,y:701,t:1528143701267};\\\", \\\"{x:1625,y:700,t:1528143701283};\\\", \\\"{x:1622,y:699,t:1528143701299};\\\", \\\"{x:1618,y:699,t:1528143701318};\\\", \\\"{x:1616,y:699,t:1528143701332};\\\", \\\"{x:1615,y:699,t:1528143701370};\\\", \\\"{x:1613,y:699,t:1528143701492};\\\", \\\"{x:1612,y:699,t:1528143701499};\\\", \\\"{x:1609,y:699,t:1528143701515};\\\", \\\"{x:1609,y:700,t:1528143701534};\\\", \\\"{x:1608,y:700,t:1528143701549};\\\", \\\"{x:1606,y:700,t:1528143701566};\\\", \\\"{x:1605,y:701,t:1528143701583};\\\", \\\"{x:1604,y:701,t:1528143701600};\\\", \\\"{x:1603,y:702,t:1528143701617};\\\", \\\"{x:1602,y:703,t:1528143701633};\\\", \\\"{x:1602,y:705,t:1528143701650};\\\", \\\"{x:1602,y:707,t:1528143701667};\\\", \\\"{x:1602,y:708,t:1528143701683};\\\", \\\"{x:1601,y:712,t:1528143701700};\\\", \\\"{x:1600,y:715,t:1528143701716};\\\", \\\"{x:1599,y:717,t:1528143701733};\\\", \\\"{x:1598,y:721,t:1528143701749};\\\", \\\"{x:1598,y:723,t:1528143701767};\\\", \\\"{x:1596,y:726,t:1528143701783};\\\", \\\"{x:1596,y:729,t:1528143701800};\\\", \\\"{x:1595,y:732,t:1528143701817};\\\", \\\"{x:1592,y:737,t:1528143701833};\\\", \\\"{x:1591,y:740,t:1528143701850};\\\", \\\"{x:1590,y:743,t:1528143701867};\\\", \\\"{x:1589,y:744,t:1528143701883};\\\", \\\"{x:1589,y:745,t:1528143702028};\\\", \\\"{x:1587,y:746,t:1528143702036};\\\", \\\"{x:1586,y:747,t:1528143702050};\\\", \\\"{x:1584,y:748,t:1528143702068};\\\", \\\"{x:1583,y:751,t:1528143702083};\\\", \\\"{x:1581,y:752,t:1528143702100};\\\", \\\"{x:1580,y:753,t:1528143702116};\\\", \\\"{x:1579,y:755,t:1528143702133};\\\", \\\"{x:1578,y:756,t:1528143702150};\\\", \\\"{x:1578,y:757,t:1528143702166};\\\", \\\"{x:1577,y:760,t:1528143702183};\\\", \\\"{x:1575,y:763,t:1528143702200};\\\", \\\"{x:1574,y:767,t:1528143702217};\\\", \\\"{x:1572,y:771,t:1528143702233};\\\", \\\"{x:1572,y:773,t:1528143702252};\\\", \\\"{x:1571,y:774,t:1528143702266};\\\", \\\"{x:1570,y:776,t:1528143702283};\\\", \\\"{x:1569,y:780,t:1528143702299};\\\", \\\"{x:1568,y:783,t:1528143702316};\\\", \\\"{x:1567,y:785,t:1528143702333};\\\", \\\"{x:1567,y:787,t:1528143702350};\\\", \\\"{x:1565,y:788,t:1528143702367};\\\", \\\"{x:1565,y:790,t:1528143702383};\\\", \\\"{x:1564,y:793,t:1528143702400};\\\", \\\"{x:1563,y:796,t:1528143702417};\\\", \\\"{x:1561,y:799,t:1528143702433};\\\", \\\"{x:1561,y:802,t:1528143702450};\\\", \\\"{x:1558,y:805,t:1528143702467};\\\", \\\"{x:1558,y:808,t:1528143702483};\\\", \\\"{x:1557,y:811,t:1528143702500};\\\", \\\"{x:1557,y:812,t:1528143702523};\\\", \\\"{x:1557,y:814,t:1528143702533};\\\", \\\"{x:1556,y:818,t:1528143702550};\\\", \\\"{x:1555,y:824,t:1528143702567};\\\", \\\"{x:1554,y:830,t:1528143702583};\\\", \\\"{x:1554,y:834,t:1528143702600};\\\", \\\"{x:1553,y:837,t:1528143702617};\\\", \\\"{x:1552,y:840,t:1528143702633};\\\", \\\"{x:1551,y:843,t:1528143702650};\\\", \\\"{x:1551,y:845,t:1528143702667};\\\", \\\"{x:1550,y:847,t:1528143702683};\\\", \\\"{x:1549,y:852,t:1528143702701};\\\", \\\"{x:1547,y:855,t:1528143702717};\\\", \\\"{x:1547,y:858,t:1528143702733};\\\", \\\"{x:1545,y:860,t:1528143702750};\\\", \\\"{x:1544,y:863,t:1528143702767};\\\", \\\"{x:1543,y:866,t:1528143702783};\\\", \\\"{x:1541,y:869,t:1528143702800};\\\", \\\"{x:1540,y:872,t:1528143702817};\\\", \\\"{x:1538,y:874,t:1528143702833};\\\", \\\"{x:1537,y:877,t:1528143702850};\\\", \\\"{x:1537,y:880,t:1528143702867};\\\", \\\"{x:1534,y:883,t:1528143702883};\\\", \\\"{x:1533,y:887,t:1528143702900};\\\", \\\"{x:1531,y:890,t:1528143702917};\\\", \\\"{x:1530,y:892,t:1528143702932};\\\", \\\"{x:1527,y:896,t:1528143702950};\\\", \\\"{x:1527,y:897,t:1528143702968};\\\", \\\"{x:1526,y:899,t:1528143702983};\\\", \\\"{x:1523,y:906,t:1528143702999};\\\", \\\"{x:1522,y:910,t:1528143703016};\\\", \\\"{x:1520,y:915,t:1528143703034};\\\", \\\"{x:1519,y:917,t:1528143703050};\\\", \\\"{x:1518,y:918,t:1528143703067};\\\", \\\"{x:1516,y:921,t:1528143703084};\\\", \\\"{x:1514,y:925,t:1528143703099};\\\", \\\"{x:1512,y:929,t:1528143703116};\\\", \\\"{x:1509,y:933,t:1528143703133};\\\", \\\"{x:1508,y:935,t:1528143703149};\\\", \\\"{x:1507,y:937,t:1528143703166};\\\", \\\"{x:1505,y:938,t:1528143703182};\\\", \\\"{x:1503,y:942,t:1528143703201};\\\", \\\"{x:1501,y:943,t:1528143703217};\\\", \\\"{x:1501,y:945,t:1528143703234};\\\", \\\"{x:1499,y:946,t:1528143703250};\\\", \\\"{x:1498,y:948,t:1528143703267};\\\", \\\"{x:1496,y:948,t:1528143703356};\\\", \\\"{x:1495,y:949,t:1528143703380};\\\", \\\"{x:1494,y:949,t:1528143703421};\\\", \\\"{x:1494,y:950,t:1528143703433};\\\", \\\"{x:1493,y:950,t:1528143703452};\\\", \\\"{x:1492,y:951,t:1528143703468};\\\", \\\"{x:1491,y:951,t:1528143703492};\\\", \\\"{x:1489,y:952,t:1528143703516};\\\", \\\"{x:1489,y:953,t:1528143703534};\\\", \\\"{x:1488,y:953,t:1528143703550};\\\", \\\"{x:1486,y:955,t:1528143703567};\\\", \\\"{x:1484,y:955,t:1528143703584};\\\", \\\"{x:1483,y:956,t:1528143703600};\\\", \\\"{x:1482,y:957,t:1528143703617};\\\", \\\"{x:1481,y:958,t:1528143703636};\\\", \\\"{x:1480,y:958,t:1528143703702};\\\", \\\"{x:1479,y:958,t:1528143703717};\\\", \\\"{x:1478,y:959,t:1528143703734};\\\", \\\"{x:1477,y:957,t:1528143704069};\\\", \\\"{x:1476,y:953,t:1528143704084};\\\", \\\"{x:1473,y:949,t:1528143704100};\\\", \\\"{x:1473,y:942,t:1528143704117};\\\", \\\"{x:1472,y:939,t:1528143704134};\\\", \\\"{x:1470,y:935,t:1528143704150};\\\", \\\"{x:1469,y:933,t:1528143704172};\\\", \\\"{x:1468,y:932,t:1528143704229};\\\", \\\"{x:1468,y:931,t:1528143704244};\\\", \\\"{x:1468,y:929,t:1528143704252};\\\", \\\"{x:1466,y:928,t:1528143704268};\\\", \\\"{x:1466,y:927,t:1528143704284};\\\", \\\"{x:1465,y:925,t:1528143704300};\\\", \\\"{x:1462,y:922,t:1528143704317};\\\", \\\"{x:1461,y:919,t:1528143704340};\\\", \\\"{x:1461,y:918,t:1528143704350};\\\", \\\"{x:1455,y:910,t:1528143704368};\\\", \\\"{x:1449,y:899,t:1528143704384};\\\", \\\"{x:1442,y:887,t:1528143704400};\\\", \\\"{x:1437,y:877,t:1528143704417};\\\", \\\"{x:1431,y:866,t:1528143704434};\\\", \\\"{x:1425,y:856,t:1528143704451};\\\", \\\"{x:1418,y:842,t:1528143704467};\\\", \\\"{x:1403,y:818,t:1528143704484};\\\", \\\"{x:1388,y:797,t:1528143704500};\\\", \\\"{x:1375,y:781,t:1528143704517};\\\", \\\"{x:1369,y:771,t:1528143704534};\\\", \\\"{x:1363,y:762,t:1528143704550};\\\", \\\"{x:1360,y:752,t:1528143704567};\\\", \\\"{x:1355,y:739,t:1528143704584};\\\", \\\"{x:1349,y:727,t:1528143704600};\\\", \\\"{x:1341,y:711,t:1528143704617};\\\", \\\"{x:1338,y:703,t:1528143704634};\\\", \\\"{x:1338,y:697,t:1528143704651};\\\", \\\"{x:1338,y:688,t:1528143704667};\\\", \\\"{x:1338,y:677,t:1528143704684};\\\", \\\"{x:1338,y:675,t:1528143704703};\\\", \\\"{x:1339,y:671,t:1528143704717};\\\", \\\"{x:1339,y:669,t:1528143704733};\\\", \\\"{x:1339,y:667,t:1528143704750};\\\", \\\"{x:1339,y:666,t:1528143704876};\\\", \\\"{x:1339,y:664,t:1528143704884};\\\", \\\"{x:1339,y:657,t:1528143704900};\\\", \\\"{x:1338,y:653,t:1528143704917};\\\", \\\"{x:1334,y:643,t:1528143704934};\\\", \\\"{x:1332,y:640,t:1528143704950};\\\", \\\"{x:1332,y:636,t:1528143704967};\\\", \\\"{x:1332,y:632,t:1528143704983};\\\", \\\"{x:1332,y:629,t:1528143704999};\\\", \\\"{x:1332,y:627,t:1528143705016};\\\", \\\"{x:1332,y:626,t:1528143705033};\\\", \\\"{x:1332,y:624,t:1528143705050};\\\", \\\"{x:1332,y:621,t:1528143705066};\\\", \\\"{x:1330,y:615,t:1528143705083};\\\", \\\"{x:1327,y:609,t:1528143705099};\\\", \\\"{x:1326,y:607,t:1528143705117};\\\", \\\"{x:1321,y:604,t:1528143705134};\\\", \\\"{x:1318,y:601,t:1528143705151};\\\", \\\"{x:1316,y:598,t:1528143705167};\\\", \\\"{x:1312,y:593,t:1528143705184};\\\", \\\"{x:1311,y:588,t:1528143705200};\\\", \\\"{x:1308,y:585,t:1528143705216};\\\", \\\"{x:1303,y:581,t:1528143705234};\\\", \\\"{x:1301,y:580,t:1528143705250};\\\", \\\"{x:1297,y:577,t:1528143705267};\\\", \\\"{x:1287,y:573,t:1528143705284};\\\", \\\"{x:1283,y:571,t:1528143705301};\\\", \\\"{x:1280,y:569,t:1528143705317};\\\", \\\"{x:1278,y:568,t:1528143705334};\\\", \\\"{x:1277,y:566,t:1528143705349};\\\", \\\"{x:1276,y:566,t:1528143705367};\\\", \\\"{x:1275,y:564,t:1528143705385};\\\", \\\"{x:1274,y:564,t:1528143705401};\\\", \\\"{x:1274,y:563,t:1528143705417};\\\", \\\"{x:1274,y:560,t:1528143705435};\\\", \\\"{x:1274,y:559,t:1528143705451};\\\", \\\"{x:1274,y:557,t:1528143705467};\\\", \\\"{x:1274,y:554,t:1528143705484};\\\", \\\"{x:1274,y:551,t:1528143705500};\\\", \\\"{x:1274,y:548,t:1528143705517};\\\", \\\"{x:1273,y:547,t:1528143705534};\\\", \\\"{x:1272,y:545,t:1528143705551};\\\", \\\"{x:1272,y:543,t:1528143705567};\\\", \\\"{x:1272,y:544,t:1528143706316};\\\", \\\"{x:1272,y:545,t:1528143706334};\\\", \\\"{x:1272,y:546,t:1528143706351};\\\", \\\"{x:1272,y:547,t:1528143706367};\\\", \\\"{x:1273,y:548,t:1528143706453};\\\", \\\"{x:1274,y:548,t:1528143706476};\\\", \\\"{x:1276,y:550,t:1528143706484};\\\", \\\"{x:1278,y:552,t:1528143706502};\\\", \\\"{x:1280,y:553,t:1528143706517};\\\", \\\"{x:1282,y:555,t:1528143706540};\\\", \\\"{x:1286,y:560,t:1528143706551};\\\", \\\"{x:1299,y:574,t:1528143706568};\\\", \\\"{x:1311,y:591,t:1528143706584};\\\", \\\"{x:1322,y:603,t:1528143706601};\\\", \\\"{x:1325,y:607,t:1528143706617};\\\", \\\"{x:1327,y:609,t:1528143706634};\\\", \\\"{x:1327,y:610,t:1528143706684};\\\", \\\"{x:1327,y:611,t:1528143706851};\\\", \\\"{x:1328,y:613,t:1528143706866};\\\", \\\"{x:1328,y:615,t:1528143707084};\\\", \\\"{x:1305,y:616,t:1528143707102};\\\", \\\"{x:1290,y:617,t:1528143707117};\\\", \\\"{x:1273,y:615,t:1528143707134};\\\", \\\"{x:1239,y:608,t:1528143707151};\\\", \\\"{x:1215,y:599,t:1528143707167};\\\", \\\"{x:1191,y:591,t:1528143707184};\\\", \\\"{x:1174,y:586,t:1528143707201};\\\", \\\"{x:1152,y:580,t:1528143707218};\\\", \\\"{x:1130,y:578,t:1528143707234};\\\", \\\"{x:1121,y:575,t:1528143707251};\\\", \\\"{x:1116,y:573,t:1528143707267};\\\", \\\"{x:1113,y:570,t:1528143707284};\\\", \\\"{x:1109,y:568,t:1528143707303};\\\", \\\"{x:1104,y:567,t:1528143707318};\\\", \\\"{x:1093,y:562,t:1528143707334};\\\", \\\"{x:1076,y:558,t:1528143707351};\\\", \\\"{x:1046,y:551,t:1528143707368};\\\", \\\"{x:1004,y:545,t:1528143707384};\\\", \\\"{x:980,y:538,t:1528143707401};\\\", \\\"{x:964,y:533,t:1528143707418};\\\", \\\"{x:943,y:525,t:1528143707436};\\\", \\\"{x:920,y:522,t:1528143707451};\\\", \\\"{x:893,y:516,t:1528143707468};\\\", \\\"{x:878,y:514,t:1528143707489};\\\", \\\"{x:874,y:514,t:1528143707505};\\\", \\\"{x:872,y:513,t:1528143707522};\\\", \\\"{x:872,y:512,t:1528143707555};\\\", \\\"{x:870,y:512,t:1528143707579};\\\", \\\"{x:868,y:512,t:1528143707589};\\\", \\\"{x:860,y:512,t:1528143707607};\\\", \\\"{x:845,y:512,t:1528143707622};\\\", \\\"{x:838,y:512,t:1528143707639};\\\", \\\"{x:836,y:511,t:1528143707656};\\\", \\\"{x:834,y:511,t:1528143707691};\\\", \\\"{x:832,y:510,t:1528143707707};\\\", \\\"{x:830,y:510,t:1528143707722};\\\", \\\"{x:829,y:510,t:1528143707739};\\\", \\\"{x:828,y:510,t:1528143707955};\\\", \\\"{x:827,y:510,t:1528143707963};\\\", \\\"{x:824,y:510,t:1528143707974};\\\", \\\"{x:803,y:510,t:1528143707991};\\\", \\\"{x:778,y:510,t:1528143708006};\\\", \\\"{x:750,y:510,t:1528143708024};\\\", \\\"{x:731,y:510,t:1528143708040};\\\", \\\"{x:719,y:508,t:1528143708057};\\\", \\\"{x:716,y:508,t:1528143708073};\\\", \\\"{x:713,y:508,t:1528143708089};\\\", \\\"{x:711,y:507,t:1528143708107};\\\", \\\"{x:703,y:507,t:1528143708123};\\\", \\\"{x:692,y:507,t:1528143708140};\\\", \\\"{x:681,y:507,t:1528143708156};\\\", \\\"{x:672,y:507,t:1528143708174};\\\", \\\"{x:667,y:507,t:1528143708190};\\\", \\\"{x:658,y:507,t:1528143708206};\\\", \\\"{x:655,y:507,t:1528143708223};\\\", \\\"{x:654,y:507,t:1528143708275};\\\", \\\"{x:652,y:507,t:1528143708290};\\\", \\\"{x:647,y:507,t:1528143708307};\\\", \\\"{x:639,y:508,t:1528143708324};\\\", \\\"{x:636,y:508,t:1528143708340};\\\", \\\"{x:631,y:508,t:1528143708357};\\\", \\\"{x:630,y:508,t:1528143708374};\\\", \\\"{x:629,y:510,t:1528143708764};\\\", \\\"{x:621,y:517,t:1528143708774};\\\", \\\"{x:607,y:539,t:1528143708791};\\\", \\\"{x:584,y:577,t:1528143708808};\\\", \\\"{x:555,y:613,t:1528143708824};\\\", \\\"{x:530,y:643,t:1528143708841};\\\", \\\"{x:517,y:660,t:1528143708858};\\\", \\\"{x:513,y:667,t:1528143708873};\\\", \\\"{x:511,y:670,t:1528143708890};\\\", \\\"{x:510,y:673,t:1528143708907};\\\", \\\"{x:509,y:675,t:1528143708923};\\\", \\\"{x:507,y:680,t:1528143708941};\\\", \\\"{x:506,y:686,t:1528143708957};\\\", \\\"{x:504,y:689,t:1528143708974};\\\", \\\"{x:504,y:690,t:1528143708990};\\\", \\\"{x:503,y:694,t:1528143709008};\\\", \\\"{x:500,y:701,t:1528143709023};\\\", \\\"{x:498,y:710,t:1528143709041};\\\", \\\"{x:495,y:718,t:1528143709058};\\\", \\\"{x:495,y:721,t:1528143709075};\\\", \\\"{x:495,y:722,t:1528143709091};\\\", \\\"{x:495,y:725,t:1528143709107};\\\", \\\"{x:495,y:729,t:1528143709124};\\\", \\\"{x:495,y:733,t:1528143709140};\\\", \\\"{x:495,y:734,t:1528143709164};\\\" ] }, { \\\"rt\\\": 7204, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 18, \\\"time_elapsed\\\": 802342, \\\"internal_node_id\\\": \\\"0.0-6.0-8.0\\\", \\\"subject\\\": \\\"06217\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"zulu\\\", \\\"condition\\\": \\\"211\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"endtime\\\", \\\"q\\\": 14, \\\"clicks\\\": 1, \\\"explicit\\\": 2, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XInside-YFull\\\", \\\"correct\\\": 1, \\\"orth_correct\\\": 0, \\\"answer\\\": [ \\\"X\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-03 PM\\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:495,y:735,t:1528143711620};\\\", \\\"{x:498,y:734,t:1528143711628};\\\", \\\"{x:512,y:728,t:1528143711643};\\\", \\\"{x:520,y:725,t:1528143711659};\\\", \\\"{x:532,y:726,t:1528143711676};\\\", \\\"{x:535,y:733,t:1528143711693};\\\", \\\"{x:537,y:737,t:1528143711709};\\\", \\\"{x:539,y:739,t:1528143711726};\\\", \\\"{x:541,y:741,t:1528143711743};\\\", \\\"{x:542,y:742,t:1528143711759};\\\", \\\"{x:543,y:742,t:1528143711776};\\\", \\\"{x:545,y:744,t:1528143711793};\\\", \\\"{x:547,y:745,t:1528143711809};\\\", \\\"{x:547,y:746,t:1528143711835};\\\", \\\"{x:551,y:746,t:1528143712436};\\\", \\\"{x:555,y:746,t:1528143712443};\\\", \\\"{x:573,y:760,t:1528143712460};\\\", \\\"{x:616,y:792,t:1528143712475};\\\", \\\"{x:668,y:822,t:1528143712492};\\\", \\\"{x:714,y:858,t:1528143712509};\\\", \\\"{x:776,y:906,t:1528143712527};\\\", \\\"{x:857,y:965,t:1528143712544};\\\", \\\"{x:953,y:1044,t:1528143712559};\\\", \\\"{x:1069,y:1117,t:1528143712577};\\\", \\\"{x:1177,y:1165,t:1528143712593};\\\", \\\"{x:1251,y:1183,t:1528143712610};\\\", \\\"{x:1300,y:1188,t:1528143712627};\\\", \\\"{x:1320,y:1188,t:1528143712643};\\\", \\\"{x:1337,y:1188,t:1528143712660};\\\", \\\"{x:1350,y:1188,t:1528143712677};\\\", \\\"{x:1359,y:1187,t:1528143712694};\\\", \\\"{x:1363,y:1186,t:1528143712710};\\\", \\\"{x:1365,y:1185,t:1528143712727};\\\", \\\"{x:1367,y:1183,t:1528143712744};\\\", \\\"{x:1374,y:1178,t:1528143712760};\\\", \\\"{x:1384,y:1173,t:1528143712777};\\\", \\\"{x:1398,y:1168,t:1528143712794};\\\", \\\"{x:1414,y:1161,t:1528143712810};\\\", \\\"{x:1438,y:1154,t:1528143712827};\\\", \\\"{x:1474,y:1141,t:1528143712843};\\\", \\\"{x:1495,y:1128,t:1528143712860};\\\", \\\"{x:1510,y:1119,t:1528143712877};\\\", \\\"{x:1523,y:1108,t:1528143712894};\\\", \\\"{x:1531,y:1101,t:1528143712910};\\\", \\\"{x:1542,y:1088,t:1528143712926};\\\", \\\"{x:1554,y:1072,t:1528143712944};\\\", \\\"{x:1568,y:1056,t:1528143712960};\\\", \\\"{x:1583,y:1039,t:1528143712978};\\\", \\\"{x:1593,y:1029,t:1528143712994};\\\", \\\"{x:1602,y:1022,t:1528143713011};\\\", \\\"{x:1612,y:1018,t:1528143713027};\\\", \\\"{x:1620,y:1013,t:1528143713043};\\\", \\\"{x:1623,y:1012,t:1528143713060};\\\", \\\"{x:1622,y:1011,t:1528143713140};\\\", \\\"{x:1619,y:1011,t:1528143713147};\\\", \\\"{x:1615,y:1010,t:1528143713161};\\\", \\\"{x:1605,y:1007,t:1528143713177};\\\", \\\"{x:1584,y:1005,t:1528143713195};\\\", \\\"{x:1567,y:1002,t:1528143713212};\\\", \\\"{x:1567,y:1001,t:1528143713227};\\\", \\\"{x:1566,y:1001,t:1528143713244};\\\", \\\"{x:1564,y:998,t:1528143713261};\\\", \\\"{x:1561,y:994,t:1528143713277};\\\", \\\"{x:1557,y:990,t:1528143713294};\\\", \\\"{x:1551,y:986,t:1528143713311};\\\", \\\"{x:1547,y:983,t:1528143713327};\\\", \\\"{x:1543,y:978,t:1528143713344};\\\", \\\"{x:1539,y:974,t:1528143713362};\\\", \\\"{x:1537,y:972,t:1528143713378};\\\", \\\"{x:1536,y:970,t:1528143713395};\\\", \\\"{x:1534,y:969,t:1528143713412};\\\", \\\"{x:1534,y:968,t:1528143713429};\\\", \\\"{x:1535,y:966,t:1528143713444};\\\", \\\"{x:1535,y:965,t:1528143713460};\\\", \\\"{x:1536,y:964,t:1528143713477};\\\", \\\"{x:1537,y:964,t:1528143713498};\\\", \\\"{x:1537,y:962,t:1528143713531};\\\", \\\"{x:1539,y:962,t:1528143713547};\\\", \\\"{x:1540,y:962,t:1528143713684};\\\", \\\"{x:1540,y:961,t:1528143714205};\\\", \\\"{x:1540,y:960,t:1528143714211};\\\", \\\"{x:1529,y:943,t:1528143714228};\\\", \\\"{x:1522,y:930,t:1528143714246};\\\", \\\"{x:1516,y:918,t:1528143714261};\\\", \\\"{x:1511,y:911,t:1528143714279};\\\", \\\"{x:1508,y:904,t:1528143714295};\\\", \\\"{x:1506,y:899,t:1528143714311};\\\", \\\"{x:1505,y:892,t:1528143714329};\\\", \\\"{x:1504,y:887,t:1528143714346};\\\", \\\"{x:1503,y:882,t:1528143714361};\\\", \\\"{x:1503,y:878,t:1528143714378};\\\", \\\"{x:1503,y:874,t:1528143714396};\\\", \\\"{x:1502,y:869,t:1528143714412};\\\", \\\"{x:1501,y:867,t:1528143714428};\\\", \\\"{x:1501,y:865,t:1528143714445};\\\", \\\"{x:1500,y:864,t:1528143714461};\\\", \\\"{x:1500,y:863,t:1528143714484};\\\", \\\"{x:1500,y:862,t:1528143714540};\\\", \\\"{x:1499,y:861,t:1528143714612};\\\", \\\"{x:1498,y:861,t:1528143714652};\\\", \\\"{x:1498,y:859,t:1528143714661};\\\", \\\"{x:1496,y:858,t:1528143714679};\\\", \\\"{x:1494,y:856,t:1528143714696};\\\", \\\"{x:1493,y:854,t:1528143714711};\\\", \\\"{x:1492,y:854,t:1528143714728};\\\", \\\"{x:1492,y:852,t:1528143714746};\\\", \\\"{x:1491,y:851,t:1528143714762};\\\", \\\"{x:1490,y:851,t:1528143714779};\\\", \\\"{x:1489,y:850,t:1528143714795};\\\", \\\"{x:1488,y:849,t:1528143714812};\\\", \\\"{x:1488,y:848,t:1528143714868};\\\", \\\"{x:1488,y:846,t:1528143715636};\\\", \\\"{x:1490,y:844,t:1528143715645};\\\", \\\"{x:1491,y:843,t:1528143715668};\\\", \\\"{x:1491,y:842,t:1528143715679};\\\", \\\"{x:1490,y:842,t:1528143715696};\\\", \\\"{x:1489,y:841,t:1528143715715};\\\", \\\"{x:1488,y:840,t:1528143715729};\\\", \\\"{x:1486,y:838,t:1528143715745};\\\", \\\"{x:1476,y:834,t:1528143715763};\\\", \\\"{x:1438,y:821,t:1528143715780};\\\", \\\"{x:1357,y:799,t:1528143715796};\\\", \\\"{x:1231,y:767,t:1528143715812};\\\", \\\"{x:1083,y:741,t:1528143715830};\\\", \\\"{x:942,y:722,t:1528143715845};\\\", \\\"{x:809,y:698,t:1528143715862};\\\", \\\"{x:706,y:683,t:1528143715879};\\\", \\\"{x:614,y:669,t:1528143715895};\\\", \\\"{x:555,y:666,t:1528143715912};\\\", \\\"{x:527,y:666,t:1528143715929};\\\", \\\"{x:517,y:666,t:1528143715945};\\\", \\\"{x:512,y:666,t:1528143715962};\\\", \\\"{x:504,y:666,t:1528143715979};\\\", \\\"{x:492,y:666,t:1528143715997};\\\", \\\"{x:471,y:666,t:1528143716012};\\\", \\\"{x:446,y:663,t:1528143716029};\\\", \\\"{x:430,y:659,t:1528143716046};\\\", \\\"{x:425,y:658,t:1528143716063};\\\", \\\"{x:417,y:654,t:1528143716080};\\\", \\\"{x:411,y:652,t:1528143716095};\\\", \\\"{x:405,y:650,t:1528143716113};\\\", \\\"{x:401,y:649,t:1528143716129};\\\", \\\"{x:401,y:648,t:1528143716145};\\\", \\\"{x:400,y:648,t:1528143716171};\\\", \\\"{x:400,y:647,t:1528143716203};\\\", \\\"{x:401,y:646,t:1528143716213};\\\", \\\"{x:413,y:641,t:1528143716231};\\\", \\\"{x:446,y:631,t:1528143716247};\\\", \\\"{x:504,y:622,t:1528143716263};\\\", \\\"{x:596,y:611,t:1528143716280};\\\", \\\"{x:690,y:597,t:1528143716297};\\\", \\\"{x:768,y:587,t:1528143716313};\\\", \\\"{x:800,y:582,t:1528143716329};\\\", \\\"{x:808,y:581,t:1528143716347};\\\", \\\"{x:807,y:581,t:1528143716564};\\\", \\\"{x:805,y:581,t:1528143716580};\\\", \\\"{x:802,y:582,t:1528143716597};\\\", \\\"{x:797,y:585,t:1528143716615};\\\", \\\"{x:792,y:586,t:1528143716630};\\\", \\\"{x:781,y:590,t:1528143716647};\\\", \\\"{x:764,y:591,t:1528143716664};\\\", \\\"{x:744,y:591,t:1528143716681};\\\", \\\"{x:721,y:591,t:1528143716699};\\\", \\\"{x:694,y:591,t:1528143716714};\\\", \\\"{x:664,y:591,t:1528143716730};\\\", \\\"{x:628,y:591,t:1528143716746};\\\", \\\"{x:618,y:591,t:1528143716764};\\\", \\\"{x:615,y:591,t:1528143716781};\\\", \\\"{x:614,y:591,t:1528143716811};\\\", \\\"{x:613,y:592,t:1528143716818};\\\", \\\"{x:612,y:592,t:1528143716843};\\\", \\\"{x:613,y:592,t:1528143716915};\\\", \\\"{x:615,y:592,t:1528143716931};\\\", \\\"{x:616,y:588,t:1528143716949};\\\", \\\"{x:615,y:588,t:1528143717291};\\\", \\\"{x:614,y:590,t:1528143717300};\\\", \\\"{x:610,y:599,t:1528143717315};\\\", \\\"{x:598,y:628,t:1528143717331};\\\", \\\"{x:587,y:654,t:1528143717348};\\\", \\\"{x:573,y:677,t:1528143717364};\\\", \\\"{x:562,y:696,t:1528143717381};\\\", \\\"{x:558,y:703,t:1528143717398};\\\", \\\"{x:556,y:705,t:1528143717413};\\\", \\\"{x:555,y:706,t:1528143717430};\\\", \\\"{x:554,y:707,t:1528143717447};\\\", \\\"{x:553,y:707,t:1528143717464};\\\", \\\"{x:552,y:707,t:1528143717531};\\\", \\\"{x:552,y:708,t:1528143717604};\\\", \\\"{x:549,y:711,t:1528143717614};\\\", \\\"{x:541,y:718,t:1528143717633};\\\", \\\"{x:530,y:729,t:1528143717649};\\\", \\\"{x:525,y:734,t:1528143717664};\\\", \\\"{x:523,y:735,t:1528143717681};\\\", \\\"{x:523,y:736,t:1528143717698};\\\" ] }, { \\\"rt\\\": 11002, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 19, \\\"time_elapsed\\\": 814626, \\\"internal_node_id\\\": \\\"0.0-6.0-9.0\\\", \\\"subject\\\": \\\"06217\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"zulu\\\", \\\"condition\\\": \\\"211\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"midpoint\\\", \\\"q\\\": 15, \\\"clicks\\\": 2, \\\"explicit\\\": 2, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XInside-YFull\\\", \\\"correct\\\": 1, \\\"orth_correct\\\": 0, \\\"answer\\\": [ \\\"K\\\", \\\"X\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-11 AM-03 PM-02 PM\\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:522,y:736,t:1528143721332};\\\", \\\"{x:522,y:745,t:1528143721340};\\\", \\\"{x:522,y:756,t:1528143721352};\\\", \\\"{x:526,y:775,t:1528143721369};\\\", \\\"{x:532,y:790,t:1528143721384};\\\", \\\"{x:535,y:796,t:1528143721401};\\\", \\\"{x:538,y:800,t:1528143721417};\\\", \\\"{x:543,y:805,t:1528143721433};\\\", \\\"{x:571,y:830,t:1528143721450};\\\", \\\"{x:600,y:860,t:1528143721466};\\\", \\\"{x:633,y:894,t:1528143721482};\\\", \\\"{x:677,y:930,t:1528143721500};\\\", \\\"{x:724,y:958,t:1528143721516};\\\", \\\"{x:770,y:986,t:1528143721533};\\\", \\\"{x:834,y:1018,t:1528143721550};\\\", \\\"{x:911,y:1048,t:1528143721567};\\\", \\\"{x:988,y:1078,t:1528143721583};\\\", \\\"{x:1049,y:1108,t:1528143721600};\\\", \\\"{x:1105,y:1126,t:1528143721617};\\\", \\\"{x:1150,y:1139,t:1528143721633};\\\", \\\"{x:1168,y:1148,t:1528143721651};\\\", \\\"{x:1177,y:1151,t:1528143721667};\\\", \\\"{x:1177,y:1152,t:1528143721683};\\\", \\\"{x:1177,y:1156,t:1528143722068};\\\", \\\"{x:1174,y:1167,t:1528143722084};\\\", \\\"{x:1173,y:1169,t:1528143722100};\\\", \\\"{x:1176,y:1167,t:1528143722252};\\\", \\\"{x:1181,y:1161,t:1528143722267};\\\", \\\"{x:1185,y:1155,t:1528143722284};\\\", \\\"{x:1188,y:1151,t:1528143722300};\\\", \\\"{x:1190,y:1146,t:1528143722317};\\\", \\\"{x:1194,y:1139,t:1528143722334};\\\", \\\"{x:1198,y:1130,t:1528143722350};\\\", \\\"{x:1204,y:1118,t:1528143722367};\\\", \\\"{x:1211,y:1102,t:1528143722384};\\\", \\\"{x:1217,y:1086,t:1528143722401};\\\", \\\"{x:1223,y:1061,t:1528143722417};\\\", \\\"{x:1230,y:1040,t:1528143722435};\\\", \\\"{x:1244,y:1019,t:1528143722452};\\\", \\\"{x:1255,y:1004,t:1528143722468};\\\", \\\"{x:1260,y:995,t:1528143722484};\\\", \\\"{x:1262,y:988,t:1528143722501};\\\", \\\"{x:1264,y:983,t:1528143722518};\\\", \\\"{x:1267,y:979,t:1528143722534};\\\", \\\"{x:1270,y:975,t:1528143722550};\\\", \\\"{x:1275,y:970,t:1528143722567};\\\", \\\"{x:1281,y:966,t:1528143722585};\\\", \\\"{x:1288,y:962,t:1528143722601};\\\", \\\"{x:1293,y:959,t:1528143722618};\\\", \\\"{x:1299,y:956,t:1528143722635};\\\", \\\"{x:1304,y:955,t:1528143722651};\\\", \\\"{x:1313,y:952,t:1528143722667};\\\", \\\"{x:1315,y:952,t:1528143722684};\\\", \\\"{x:1318,y:951,t:1528143722701};\\\", \\\"{x:1323,y:950,t:1528143722718};\\\", \\\"{x:1331,y:948,t:1528143722735};\\\", \\\"{x:1342,y:944,t:1528143722751};\\\", \\\"{x:1356,y:942,t:1528143722768};\\\", \\\"{x:1372,y:942,t:1528143722784};\\\", \\\"{x:1398,y:943,t:1528143722802};\\\", \\\"{x:1422,y:945,t:1528143722818};\\\", \\\"{x:1437,y:948,t:1528143722835};\\\", \\\"{x:1444,y:949,t:1528143722852};\\\", \\\"{x:1445,y:950,t:1528143722876};\\\", \\\"{x:1446,y:950,t:1528143722885};\\\", \\\"{x:1448,y:951,t:1528143722901};\\\", \\\"{x:1452,y:952,t:1528143722918};\\\", \\\"{x:1463,y:954,t:1528143722934};\\\", \\\"{x:1475,y:956,t:1528143722953};\\\", \\\"{x:1486,y:958,t:1528143722968};\\\", \\\"{x:1494,y:962,t:1528143722985};\\\", \\\"{x:1510,y:966,t:1528143723002};\\\", \\\"{x:1525,y:967,t:1528143723018};\\\", \\\"{x:1541,y:969,t:1528143723035};\\\", \\\"{x:1548,y:971,t:1528143723051};\\\", \\\"{x:1547,y:971,t:1528143723084};\\\", \\\"{x:1545,y:971,t:1528143723102};\\\", \\\"{x:1544,y:971,t:1528143723118};\\\", \\\"{x:1542,y:971,t:1528143723135};\\\", \\\"{x:1541,y:971,t:1528143723171};\\\", \\\"{x:1539,y:971,t:1528143723227};\\\", \\\"{x:1536,y:971,t:1528143723243};\\\", \\\"{x:1532,y:971,t:1528143723252};\\\", \\\"{x:1517,y:971,t:1528143723268};\\\", \\\"{x:1498,y:971,t:1528143723285};\\\", \\\"{x:1480,y:971,t:1528143723302};\\\", \\\"{x:1465,y:971,t:1528143723318};\\\", \\\"{x:1454,y:971,t:1528143723335};\\\", \\\"{x:1451,y:971,t:1528143723353};\\\", \\\"{x:1450,y:970,t:1528143723367};\\\", \\\"{x:1450,y:969,t:1528143723396};\\\", \\\"{x:1450,y:968,t:1528143723404};\\\", \\\"{x:1450,y:967,t:1528143723419};\\\", \\\"{x:1450,y:966,t:1528143723435};\\\", \\\"{x:1450,y:963,t:1528143723452};\\\", \\\"{x:1450,y:961,t:1528143723468};\\\", \\\"{x:1451,y:959,t:1528143723485};\\\", \\\"{x:1452,y:957,t:1528143723502};\\\", \\\"{x:1455,y:955,t:1528143723517};\\\", \\\"{x:1458,y:954,t:1528143723535};\\\", \\\"{x:1460,y:954,t:1528143723553};\\\", \\\"{x:1461,y:954,t:1528143723668};\\\", \\\"{x:1463,y:956,t:1528143723685};\\\", \\\"{x:1463,y:957,t:1528143723702};\\\", \\\"{x:1463,y:958,t:1528143723718};\\\", \\\"{x:1463,y:959,t:1528143723739};\\\", \\\"{x:1463,y:960,t:1528143723753};\\\", \\\"{x:1463,y:959,t:1528143723954};\\\", \\\"{x:1464,y:952,t:1528143723967};\\\", \\\"{x:1466,y:932,t:1528143723984};\\\", \\\"{x:1470,y:914,t:1528143724001};\\\", \\\"{x:1472,y:901,t:1528143724018};\\\", \\\"{x:1474,y:894,t:1528143724033};\\\", \\\"{x:1474,y:885,t:1528143724051};\\\", \\\"{x:1474,y:881,t:1528143724068};\\\", \\\"{x:1474,y:877,t:1528143724084};\\\", \\\"{x:1475,y:871,t:1528143724101};\\\", \\\"{x:1475,y:867,t:1528143724118};\\\", \\\"{x:1475,y:863,t:1528143724134};\\\", \\\"{x:1475,y:862,t:1528143724152};\\\", \\\"{x:1475,y:860,t:1528143724168};\\\", \\\"{x:1475,y:859,t:1528143724187};\\\", \\\"{x:1475,y:858,t:1528143724210};\\\", \\\"{x:1475,y:857,t:1528143724243};\\\", \\\"{x:1475,y:856,t:1528143724340};\\\", \\\"{x:1475,y:854,t:1528143724380};\\\", \\\"{x:1475,y:850,t:1528143724748};\\\", \\\"{x:1474,y:844,t:1528143724755};\\\", \\\"{x:1473,y:841,t:1528143724769};\\\", \\\"{x:1472,y:835,t:1528143724786};\\\", \\\"{x:1472,y:833,t:1528143724801};\\\", \\\"{x:1472,y:831,t:1528143724819};\\\", \\\"{x:1472,y:830,t:1528143724836};\\\", \\\"{x:1472,y:829,t:1528143724852};\\\", \\\"{x:1472,y:828,t:1528143726356};\\\", \\\"{x:1465,y:827,t:1528143726370};\\\", \\\"{x:1410,y:795,t:1528143726386};\\\", \\\"{x:1303,y:750,t:1528143726402};\\\", \\\"{x:1075,y:665,t:1528143726420};\\\", \\\"{x:934,y:631,t:1528143726437};\\\", \\\"{x:832,y:603,t:1528143726453};\\\", \\\"{x:747,y:582,t:1528143726469};\\\", \\\"{x:660,y:565,t:1528143726489};\\\", \\\"{x:587,y:554,t:1528143726505};\\\", \\\"{x:535,y:549,t:1528143726521};\\\", \\\"{x:507,y:549,t:1528143726538};\\\", \\\"{x:491,y:548,t:1528143726555};\\\", \\\"{x:485,y:548,t:1528143726570};\\\", \\\"{x:483,y:548,t:1528143726588};\\\", \\\"{x:482,y:548,t:1528143726691};\\\", \\\"{x:482,y:549,t:1528143726732};\\\", \\\"{x:483,y:551,t:1528143726738};\\\", \\\"{x:486,y:554,t:1528143726755};\\\", \\\"{x:492,y:560,t:1528143726773};\\\", \\\"{x:504,y:565,t:1528143726790};\\\", \\\"{x:522,y:569,t:1528143726806};\\\", \\\"{x:542,y:572,t:1528143726823};\\\", \\\"{x:557,y:575,t:1528143726838};\\\", \\\"{x:566,y:576,t:1528143726855};\\\", \\\"{x:568,y:578,t:1528143726872};\\\", \\\"{x:568,y:580,t:1528143726907};\\\", \\\"{x:566,y:583,t:1528143726922};\\\", \\\"{x:558,y:589,t:1528143726938};\\\", \\\"{x:536,y:599,t:1528143726955};\\\", \\\"{x:528,y:599,t:1528143726973};\\\", \\\"{x:521,y:599,t:1528143726989};\\\", \\\"{x:511,y:599,t:1528143727006};\\\", \\\"{x:495,y:597,t:1528143727024};\\\", \\\"{x:479,y:594,t:1528143727038};\\\", \\\"{x:459,y:586,t:1528143727055};\\\", \\\"{x:447,y:582,t:1528143727072};\\\", \\\"{x:439,y:579,t:1528143727088};\\\", \\\"{x:434,y:576,t:1528143727105};\\\", \\\"{x:432,y:576,t:1528143727122};\\\", \\\"{x:431,y:576,t:1528143727138};\\\", \\\"{x:426,y:576,t:1528143727155};\\\", \\\"{x:422,y:576,t:1528143727172};\\\", \\\"{x:416,y:576,t:1528143727188};\\\", \\\"{x:409,y:576,t:1528143727205};\\\", \\\"{x:407,y:576,t:1528143727222};\\\", \\\"{x:406,y:576,t:1528143727238};\\\", \\\"{x:405,y:574,t:1528143727255};\\\", \\\"{x:401,y:570,t:1528143727273};\\\", \\\"{x:399,y:565,t:1528143727290};\\\", \\\"{x:398,y:558,t:1528143727306};\\\", \\\"{x:397,y:553,t:1528143727322};\\\", \\\"{x:395,y:545,t:1528143727339};\\\", \\\"{x:396,y:539,t:1528143727356};\\\", \\\"{x:404,y:532,t:1528143727373};\\\", \\\"{x:420,y:521,t:1528143727390};\\\", \\\"{x:439,y:511,t:1528143727405};\\\", \\\"{x:469,y:499,t:1528143727422};\\\", \\\"{x:503,y:487,t:1528143727439};\\\", \\\"{x:526,y:480,t:1528143727455};\\\", \\\"{x:543,y:475,t:1528143727472};\\\", \\\"{x:550,y:474,t:1528143727489};\\\", \\\"{x:551,y:474,t:1528143727530};\\\", \\\"{x:551,y:478,t:1528143727539};\\\", \\\"{x:551,y:489,t:1528143727556};\\\", \\\"{x:548,y:505,t:1528143727573};\\\", \\\"{x:539,y:525,t:1528143727589};\\\", \\\"{x:527,y:539,t:1528143727606};\\\", \\\"{x:500,y:556,t:1528143727622};\\\", \\\"{x:448,y:574,t:1528143727639};\\\", \\\"{x:367,y:588,t:1528143727656};\\\", \\\"{x:292,y:599,t:1528143727672};\\\", \\\"{x:259,y:604,t:1528143727691};\\\", \\\"{x:255,y:604,t:1528143727705};\\\", \\\"{x:253,y:604,t:1528143727722};\\\", \\\"{x:253,y:603,t:1528143727747};\\\", \\\"{x:251,y:603,t:1528143727762};\\\", \\\"{x:246,y:601,t:1528143727772};\\\", \\\"{x:237,y:601,t:1528143727789};\\\", \\\"{x:224,y:601,t:1528143727806};\\\", \\\"{x:209,y:601,t:1528143727822};\\\", \\\"{x:202,y:601,t:1528143727839};\\\", \\\"{x:200,y:601,t:1528143727856};\\\", \\\"{x:199,y:601,t:1528143727872};\\\", \\\"{x:205,y:601,t:1528143727907};\\\", \\\"{x:220,y:602,t:1528143727922};\\\", \\\"{x:374,y:602,t:1528143727941};\\\", \\\"{x:515,y:602,t:1528143727956};\\\", \\\"{x:659,y:602,t:1528143727972};\\\", \\\"{x:767,y:602,t:1528143727990};\\\", \\\"{x:803,y:602,t:1528143728006};\\\", \\\"{x:806,y:602,t:1528143728022};\\\", \\\"{x:803,y:605,t:1528143728039};\\\", \\\"{x:793,y:608,t:1528143728057};\\\", \\\"{x:778,y:612,t:1528143728073};\\\", \\\"{x:774,y:613,t:1528143728089};\\\", \\\"{x:773,y:614,t:1528143728106};\\\", \\\"{x:770,y:614,t:1528143728138};\\\", \\\"{x:765,y:615,t:1528143728147};\\\", \\\"{x:757,y:615,t:1528143728156};\\\", \\\"{x:733,y:615,t:1528143728172};\\\", \\\"{x:708,y:615,t:1528143728190};\\\", \\\"{x:683,y:615,t:1528143728207};\\\", \\\"{x:661,y:615,t:1528143728222};\\\", \\\"{x:652,y:615,t:1528143728239};\\\", \\\"{x:651,y:615,t:1528143728256};\\\", \\\"{x:650,y:615,t:1528143728273};\\\", \\\"{x:649,y:615,t:1528143728324};\\\", \\\"{x:649,y:614,t:1528143728341};\\\", \\\"{x:648,y:611,t:1528143728356};\\\", \\\"{x:648,y:609,t:1528143728373};\\\", \\\"{x:648,y:607,t:1528143728389};\\\", \\\"{x:647,y:605,t:1528143728406};\\\", \\\"{x:645,y:603,t:1528143728423};\\\", \\\"{x:642,y:601,t:1528143728439};\\\", \\\"{x:636,y:598,t:1528143728456};\\\", \\\"{x:634,y:597,t:1528143728474};\\\", \\\"{x:633,y:596,t:1528143728490};\\\", \\\"{x:632,y:596,t:1528143728802};\\\", \\\"{x:627,y:596,t:1528143728810};\\\", \\\"{x:613,y:596,t:1528143728823};\\\", \\\"{x:569,y:596,t:1528143728841};\\\", \\\"{x:507,y:596,t:1528143728856};\\\", \\\"{x:435,y:596,t:1528143728874};\\\", \\\"{x:396,y:593,t:1528143728890};\\\", \\\"{x:386,y:591,t:1528143728907};\\\", \\\"{x:385,y:590,t:1528143728923};\\\", \\\"{x:384,y:589,t:1528143728940};\\\", \\\"{x:383,y:589,t:1528143729020};\\\", \\\"{x:382,y:589,t:1528143729035};\\\", \\\"{x:383,y:589,t:1528143729099};\\\", \\\"{x:386,y:588,t:1528143729108};\\\", \\\"{x:386,y:587,t:1528143729123};\\\", \\\"{x:388,y:593,t:1528143729427};\\\", \\\"{x:394,y:625,t:1528143729441};\\\", \\\"{x:417,y:690,t:1528143729458};\\\", \\\"{x:455,y:768,t:1528143729473};\\\", \\\"{x:486,y:804,t:1528143729491};\\\", \\\"{x:488,y:805,t:1528143729507};\\\", \\\"{x:489,y:806,t:1528143729524};\\\", \\\"{x:489,y:807,t:1528143729635};\\\", \\\"{x:488,y:807,t:1528143729643};\\\", \\\"{x:487,y:806,t:1528143729658};\\\", \\\"{x:486,y:800,t:1528143729675};\\\", \\\"{x:486,y:792,t:1528143729691};\\\", \\\"{x:486,y:789,t:1528143729708};\\\", \\\"{x:486,y:785,t:1528143729725};\\\", \\\"{x:487,y:780,t:1528143729741};\\\", \\\"{x:489,y:775,t:1528143729758};\\\", \\\"{x:490,y:773,t:1528143729774};\\\", \\\"{x:492,y:771,t:1528143729791};\\\", \\\"{x:492,y:770,t:1528143729811};\\\", \\\"{x:494,y:769,t:1528143729825};\\\", \\\"{x:494,y:768,t:1528143729843};\\\", \\\"{x:494,y:767,t:1528143729857};\\\", \\\"{x:495,y:765,t:1528143729875};\\\", \\\"{x:495,y:763,t:1528143729890};\\\", \\\"{x:498,y:759,t:1528143729908};\\\", \\\"{x:499,y:756,t:1528143729924};\\\", \\\"{x:499,y:755,t:1528143729940};\\\", \\\"{x:500,y:754,t:1528143729958};\\\", \\\"{x:500,y:753,t:1528143729979};\\\", \\\"{x:501,y:753,t:1528143730011};\\\" ] }, { \\\"rt\\\": 51019, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 20, \\\"time_elapsed\\\": 866875, \\\"internal_node_id\\\": \\\"0.0-7.0-0.0\\\", \\\"subject\\\": \\\"06217\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"zulu\\\", \\\"condition\\\": \\\"211\\\", \\\"q\\\": 16, \\\"answer\\\": \\\"You look at the bottom axis and look for 12pm. Once you've determined that point you follow it up along the right hand side line and which ever point you encounter along that line is what events start at 12pm. \\\", \\\"block\\\": \\\"triangular_testing\\\" }, { \\\"rt\\\": 7240, \\\"responses\\\": \\\"{\\\\\\\"Q0\\\\\\\":\\\\\\\"21\\\\\\\",\\\\\\\"Q1\\\\\\\":\\\\\\\"USA\\\\\\\"}\\\", \\\"block\\\": \\\"demo-1\\\", \\\"trial_type\\\": \\\"survey-text\\\", \\\"trial_index\\\": 21, \\\"time_elapsed\\\": 875121, \\\"internal_node_id\\\": \\\"0.0-8.0\\\", \\\"subject\\\": \\\"06217\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"zulu\\\", \\\"condition\\\": \\\"211\\\" }, { \\\"rt\\\": 9722, \\\"responses\\\": \\\"{\\\\\\\"Q0\\\\\\\":\\\\\\\"English\\\\\\\",\\\\\\\"Q1\\\\\\\":\\\\\\\"Fourth\\\\\\\",\\\\\\\"Q2\\\\\\\":\\\\\\\"Humanities\\\\\\\",\\\\\\\"Q3\\\\\\\":\\\\\\\"Female\\\\\\\"}\\\", \\\"block\\\": \\\"demo-2\\\", \\\"trial_type\\\": \\\"survey-multi-choice\\\", \\\"trial_index\\\": 22, \\\"time_elapsed\\\": 885867, \\\"internal_node_id\\\": \\\"0.0-9.0\\\", \\\"subject\\\": \\\"06217\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"zulu\\\", \\\"condition\\\": \\\"211\\\" }, { \\\"rt\\\": 16640, \\\"url\\\": \\\"../views/src/external/debrief.html\\\", \\\"block\\\": \\\"debrief\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 23, \\\"time_elapsed\\\": 903847, \\\"internal_node_id\\\": \\\"0.0-10.0\\\", \\\"subject\\\": \\\"06217\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"zulu\\\", \\\"condition\\\": \\\"211\\\" } ]\",\"parentNode\":{\"id\":2765}}],[],[]]}"
    }
  ],
  "initialDom": "{\"f\":\"initialize\",\"args\":[1,[{\"nodeType\":10,\"id\":2,\"name\":\"html\",\"publicId\":\"\",\"systemId\":\"\"},{\"nodeType\":1,\"id\":3,\"tagName\":\"HTML\",\"attributes\":{\"class\":\"fa-events-icons-ready\"},\"childNodes\":[{\"nodeType\":1,\"id\":4,\"tagName\":\"HEAD\",\"attributes\":{},\"childNodes\":[{\"nodeType\":3,\"id\":5,\"textContent\":\" \"},{\"nodeType\":1,\"id\":6,\"tagName\":\"TITLE\",\"attributes\":{},\"childNodes\":[{\"nodeType\":3,\"id\":7,\"textContent\":\"FOX2YP\"}]},{\"nodeType\":3,\"id\":8,\"textContent\":\" \"},{\"nodeType\":8,\"id\":9},{\"nodeType\":3,\"id\":10,\"textContent\":\" \"},{\"nodeType\":1,\"id\":11,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":12,\"textContent\":\" \"},{\"nodeType\":1,\"id\":13,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":14,\"textContent\":\" \"},{\"nodeType\":1,\"id\":15,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":16,\"textContent\":\" \"},{\"nodeType\":1,\"id\":17,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":18,\"textContent\":\" \"},{\"nodeType\":1,\"id\":19,\"tagName\":\"SCRIPT\"},{\"nodeType\":1,\"id\":20,\"tagName\":\"LINK\",\"attributes\":{\"href\":\"https://use.fontawesome.com/945539d961.css\",\"media\":\"all\",\"rel\":\"stylesheet\"}},{\"nodeType\":3,\"id\":21,\"textContent\":\" \"},{\"nodeType\":8,\"id\":22},{\"nodeType\":3,\"id\":23,\"textContent\":\" \"},{\"nodeType\":1,\"id\":24,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":25,\"textContent\":\" \"},{\"nodeType\":1,\"id\":26,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":27,\"textContent\":\" \"},{\"nodeType\":1,\"id\":28,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":29,\"textContent\":\" \"},{\"nodeType\":1,\"id\":30,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":31,\"textContent\":\" \"},{\"nodeType\":1,\"id\":32,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":33,\"textContent\":\" \"},{\"nodeType\":1,\"id\":34,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":35,\"textContent\":\" \"},{\"nodeType\":1,\"id\":36,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":37,\"textContent\":\" \"},{\"nodeType\":8,\"id\":38},{\"nodeType\":3,\"id\":39,\"textContent\":\" \"},{\"nodeType\":1,\"id\":40,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":41,\"textContent\":\" \"},{\"nodeType\":8,\"id\":42},{\"nodeType\":3,\"id\":43,\"textContent\":\" \"},{\"nodeType\":8,\"id\":44},{\"nodeType\":3,\"id\":45,\"textContent\":\" \"},{\"nodeType\":1,\"id\":46,\"tagName\":\"LINK\",\"attributes\":{\"href\":\"../views/jsPsych/css/jspsych.css\",\"rel\":\"stylesheet\",\"type\":\"text/css\"}},{\"nodeType\":3,\"id\":47,\"textContent\":\" \"},{\"nodeType\":1,\"id\":48,\"tagName\":\"LINK\",\"attributes\":{\"href\":\"../css/styles.css\",\"rel\":\"stylesheet\",\"type\":\"text/css\"}},{\"nodeType\":3,\"id\":49,\"textContent\":\" \"},{\"nodeType\":1,\"id\":50,\"tagName\":\"SCRIPT\"},{\"nodeType\":1,\"id\":51,\"tagName\":\"SCRIPT\"}]},{\"nodeType\":3,\"id\":52,\"textContent\":\" \"},{\"nodeType\":8,\"id\":53},{\"nodeType\":3,\"id\":54,\"textContent\":\" \"},{\"nodeType\":1,\"id\":55,\"tagName\":\"BODY\",\"attributes\":{\"class\":\"jspsych-display-element\"},\"childNodes\":[{\"nodeType\":3,\"id\":56,\"textContent\":\" \"},{\"nodeType\":1,\"id\":57,\"tagName\":\"META\",\"attributes\":{\"charset\":\"utf-8\"}},{\"nodeType\":3,\"id\":58,\"textContent\":\" \"},{\"nodeType\":8,\"id\":59},{\"nodeType\":3,\"id\":60,\"textContent\":\" \"},{\"nodeType\":1,\"id\":61,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":62,\"textContent\":\" \"},{\"nodeType\":1,\"id\":63,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":64,\"textContent\":\" \"},{\"nodeType\":1,\"id\":65,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":66,\"textContent\":\" \"},{\"nodeType\":1,\"id\":67,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":68,\"textContent\":\" \"},{\"nodeType\":1,\"id\":69,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":70,\"textContent\":\" \"},{\"nodeType\":1,\"id\":71,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":72,\"textContent\":\" \"},{\"nodeType\":1,\"id\":73,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"stimulus\"},\"childNodes\":[{\"nodeType\":3,\"id\":74,\"textContent\":\" \"},{\"nodeType\":1,\"id\":75,\"tagName\":\"P\",\"attributes\":{\"class\":\"userid\",\"id\":\"userid\"},\"childNodes\":[{\"nodeType\":3,\"id\":76,\"textContent\":\"06217\"}]},{\"nodeType\":3,\"id\":77,\"textContent\":\" \"},{\"nodeType\":1,\"id\":78,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"userinput\"},\"childNodes\":[{\"nodeType\":3,\"id\":79,\"textContent\":\" \"},{\"nodeType\":8,\"id\":80},{\"nodeType\":3,\"id\":81,\"textContent\":\" \"},{\"nodeType\":1,\"id\":82,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"legend\",\"id\":\"hint-interactive\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":83,\"textContent\":\" \"},{\"nodeType\":1,\"id\":84,\"tagName\":\"P\",\"attributes\":{},\"childNodes\":[{\"nodeType\":3,\"id\":85,\"textContent\":\"Hint: Hover your mouse over the data points in the graph\"}]},{\"nodeType\":3,\"id\":86,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":87,\"textContent\":\" \"},{\"nodeType\":8,\"id\":88},{\"nodeType\":3,\"id\":89,\"textContent\":\" \"},{\"nodeType\":8,\"id\":90},{\"nodeType\":3,\"id\":91,\"textContent\":\" \"},{\"nodeType\":1,\"id\":92,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"test\"},\"childNodes\":[{\"nodeType\":3,\"id\":93,\"textContent\":\" \"},{\"nodeType\":1,\"id\":94,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"acme\",\"id\":\"acme.starttime\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":95,\"textContent\":\" \"},{\"nodeType\":1,\"id\":96,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":97,\"textContent\":\"Which shift(s) start at 11 am? \"}]},{\"nodeType\":3,\"id\":98,\"textContent\":\" \"},{\"nodeType\":1,\"id\":99,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":100,\"textContent\":\" \"},{\"nodeType\":1,\"id\":101,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":102,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":103,\"textContent\":\" \"},{\"nodeType\":1,\"id\":104,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":105,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":106,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":107,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":108,\"textContent\":\" \"},{\"nodeType\":1,\"id\":109,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":110,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":111,\"textContent\":\" \"},{\"nodeType\":1,\"id\":112,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":113,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":114,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":115,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":116,\"textContent\":\" \"},{\"nodeType\":1,\"id\":117,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":118,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":119,\"textContent\":\" \"},{\"nodeType\":1,\"id\":120,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":121,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":122,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":123,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":124,\"textContent\":\" \"},{\"nodeType\":1,\"id\":125,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":126,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":127,\"textContent\":\" \"},{\"nodeType\":1,\"id\":128,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":129,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":130,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":131,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":132,\"textContent\":\" \"},{\"nodeType\":1,\"id\":133,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":134,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":135,\"textContent\":\" \"},{\"nodeType\":1,\"id\":136,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":137,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":138,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":139,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":140,\"textContent\":\" \"},{\"nodeType\":1,\"id\":141,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":142,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":143,\"textContent\":\" \"},{\"nodeType\":1,\"id\":144,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":145,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":146,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":147,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":148,\"textContent\":\" \"},{\"nodeType\":1,\"id\":149,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":150,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":151,\"textContent\":\" \"},{\"nodeType\":1,\"id\":152,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":153,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":154,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":155,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":156,\"textContent\":\" \"},{\"nodeType\":1,\"id\":157,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":158,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":159,\"textContent\":\" \"},{\"nodeType\":1,\"id\":160,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":161,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":162,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":163,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":164,\"textContent\":\" \"},{\"nodeType\":1,\"id\":165,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":166,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":167,\"textContent\":\" \"},{\"nodeType\":1,\"id\":168,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":169,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":170,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":171,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":172,\"textContent\":\" \"},{\"nodeType\":1,\"id\":173,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":174,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":175,\"textContent\":\" \"},{\"nodeType\":1,\"id\":176,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":177,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":178,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":179,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":180,\"textContent\":\" \"},{\"nodeType\":1,\"id\":181,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":182,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":183,\"textContent\":\" \"},{\"nodeType\":1,\"id\":184,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"U\",\"value\":\"\"}},{\"nodeType\":3,\"id\":185,\"textContent\":\"U \"},{\"nodeType\":1,\"id\":186,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":187,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":188,\"textContent\":\" \"},{\"nodeType\":1,\"id\":189,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":190,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":191,\"textContent\":\" \"},{\"nodeType\":1,\"id\":192,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":193,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":194,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":195,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":196,\"textContent\":\" \"},{\"nodeType\":1,\"id\":197,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":198,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":199,\"textContent\":\" \"},{\"nodeType\":1,\"id\":200,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":201,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":202,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":203,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":204,\"textContent\":\" \"},{\"nodeType\":1,\"id\":205,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":206,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":207,\"textContent\":\" \"},{\"nodeType\":1,\"id\":208,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":209,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":210,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":211,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":212,\"textContent\":\" \"},{\"nodeType\":1,\"id\":213,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":214,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":215,\"textContent\":\" \"},{\"nodeType\":1,\"id\":216,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":217,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":218,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":219,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":220,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":221,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":222,\"textContent\":\" \"},{\"nodeType\":1,\"id\":223,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"acme\",\"id\":\"acme.starts\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":224,\"textContent\":\" \"},{\"nodeType\":1,\"id\":225,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":226,\"textContent\":\"Which shift(s) start at the same time as D?\"}]},{\"nodeType\":3,\"id\":227,\"textContent\":\" \"},{\"nodeType\":1,\"id\":228,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":229,\"textContent\":\" \"},{\"nodeType\":1,\"id\":230,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":231,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":232,\"textContent\":\" \"},{\"nodeType\":1,\"id\":233,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":234,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":235,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":236,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":237,\"textContent\":\" \"},{\"nodeType\":1,\"id\":238,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":239,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":240,\"textContent\":\" \"},{\"nodeType\":1,\"id\":241,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":242,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":243,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":244,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":245,\"textContent\":\" \"},{\"nodeType\":1,\"id\":246,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":247,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":248,\"textContent\":\" \"},{\"nodeType\":1,\"id\":249,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":250,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":251,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":252,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":253,\"textContent\":\" \"},{\"nodeType\":1,\"id\":254,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":255,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":256,\"textContent\":\" \"},{\"nodeType\":1,\"id\":257,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":258,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":259,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":260,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":261,\"textContent\":\" \"},{\"nodeType\":1,\"id\":262,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":263,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":264,\"textContent\":\" \"},{\"nodeType\":1,\"id\":265,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":266,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":267,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":268,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":269,\"textContent\":\" \"},{\"nodeType\":1,\"id\":270,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":271,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":272,\"textContent\":\" \"},{\"nodeType\":1,\"id\":273,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":274,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":275,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":276,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":277,\"textContent\":\" \"},{\"nodeType\":1,\"id\":278,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":279,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":280,\"textContent\":\" \"},{\"nodeType\":1,\"id\":281,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":282,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":283,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":284,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":285,\"textContent\":\" \"},{\"nodeType\":1,\"id\":286,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":287,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":288,\"textContent\":\" \"},{\"nodeType\":1,\"id\":289,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":290,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":291,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":292,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":293,\"textContent\":\" \"},{\"nodeType\":1,\"id\":294,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":295,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":296,\"textContent\":\" \"},{\"nodeType\":1,\"id\":297,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":298,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":299,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":300,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":301,\"textContent\":\" \"},{\"nodeType\":1,\"id\":302,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":303,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":304,\"textContent\":\" \"},{\"nodeType\":1,\"id\":305,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":306,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":307,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":308,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":309,\"textContent\":\" \"},{\"nodeType\":1,\"id\":310,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":311,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":312,\"textContent\":\" \"},{\"nodeType\":1,\"id\":313,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"U\",\"value\":\"\"}},{\"nodeType\":3,\"id\":314,\"textContent\":\"U \"},{\"nodeType\":1,\"id\":315,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":316,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":317,\"textContent\":\" \"},{\"nodeType\":1,\"id\":318,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":319,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":320,\"textContent\":\" \"},{\"nodeType\":1,\"id\":321,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":322,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":323,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":324,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":325,\"textContent\":\" \"},{\"nodeType\":1,\"id\":326,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":327,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":328,\"textContent\":\" \"},{\"nodeType\":1,\"id\":329,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":330,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":331,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":332,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":333,\"textContent\":\" \"},{\"nodeType\":1,\"id\":334,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":335,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":336,\"textContent\":\" \"},{\"nodeType\":1,\"id\":337,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":338,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":339,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":340,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":341,\"textContent\":\" \"},{\"nodeType\":1,\"id\":342,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":343,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":344,\"textContent\":\" \"},{\"nodeType\":1,\"id\":345,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":346,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":347,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":348,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":349,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":350,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":351,\"textContent\":\" \"},{\"nodeType\":1,\"id\":352,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"acme\",\"id\":\"acme.meets\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":353,\"textContent\":\" \"},{\"nodeType\":1,\"id\":354,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":355,\"textContent\":\"Which shift(s) begin when C ends?\"}]},{\"nodeType\":3,\"id\":356,\"textContent\":\" \"},{\"nodeType\":1,\"id\":357,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":358,\"textContent\":\" \"},{\"nodeType\":1,\"id\":359,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":360,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":361,\"textContent\":\" \"},{\"nodeType\":1,\"id\":362,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":363,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":364,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":365,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":366,\"textContent\":\" \"},{\"nodeType\":1,\"id\":367,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":368,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":369,\"textContent\":\" \"},{\"nodeType\":1,\"id\":370,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":371,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":372,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":373,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":374,\"textContent\":\" \"},{\"nodeType\":1,\"id\":375,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":376,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":377,\"textContent\":\" \"},{\"nodeType\":1,\"id\":378,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":379,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":380,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":381,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":382,\"textContent\":\" \"},{\"nodeType\":1,\"id\":383,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":384,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":385,\"textContent\":\" \"},{\"nodeType\":1,\"id\":386,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":387,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":388,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":389,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":390,\"textContent\":\" \"},{\"nodeType\":1,\"id\":391,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":392,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":393,\"textContent\":\" \"},{\"nodeType\":1,\"id\":394,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":395,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":396,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":397,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":398,\"textContent\":\" \"},{\"nodeType\":1,\"id\":399,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":400,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":401,\"textContent\":\" \"},{\"nodeType\":1,\"id\":402,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":403,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":404,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":405,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":406,\"textContent\":\" \"},{\"nodeType\":1,\"id\":407,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":408,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":409,\"textContent\":\" \"},{\"nodeType\":1,\"id\":410,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":411,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":412,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":413,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":414,\"textContent\":\" \"},{\"nodeType\":1,\"id\":415,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":416,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":417,\"textContent\":\" \"},{\"nodeType\":1,\"id\":418,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":419,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":420,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":421,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":422,\"textContent\":\" \"},{\"nodeType\":1,\"id\":423,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":424,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":425,\"textContent\":\" \"},{\"nodeType\":1,\"id\":426,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":427,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":428,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":429,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":430,\"textContent\":\" \"},{\"nodeType\":1,\"id\":431,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":432,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":433,\"textContent\":\" \"},{\"nodeType\":1,\"id\":434,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":435,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":436,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":437,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":438,\"textContent\":\" \"},{\"nodeType\":1,\"id\":439,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":440,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":441,\"textContent\":\" \"},{\"nodeType\":1,\"id\":442,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"U\",\"value\":\"\"}},{\"nodeType\":3,\"id\":443,\"textContent\":\"U \"},{\"nodeType\":1,\"id\":444,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":445,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":446,\"textContent\":\" \"},{\"nodeType\":1,\"id\":447,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":448,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":449,\"textContent\":\" \"},{\"nodeType\":1,\"id\":450,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":451,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":452,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":453,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":454,\"textContent\":\" \"},{\"nodeType\":1,\"id\":455,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":456,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":457,\"textContent\":\" \"},{\"nodeType\":1,\"id\":458,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":459,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":460,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":461,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":462,\"textContent\":\" \"},{\"nodeType\":1,\"id\":463,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":464,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":465,\"textContent\":\" \"},{\"nodeType\":1,\"id\":466,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":467,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":468,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":469,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":470,\"textContent\":\" \"},{\"nodeType\":1,\"id\":471,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":472,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":473,\"textContent\":\" \"},{\"nodeType\":1,\"id\":474,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":475,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":476,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":477,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":478,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":479,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":480,\"textContent\":\" \"},{\"nodeType\":1,\"id\":481,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"acme\",\"id\":\"acme.endtime\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":482,\"textContent\":\" \"},{\"nodeType\":1,\"id\":483,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":484,\"textContent\":\" Which shift(s) end at 4 pm?\"}]},{\"nodeType\":3,\"id\":485,\"textContent\":\" \"},{\"nodeType\":1,\"id\":486,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":487,\"textContent\":\" \"},{\"nodeType\":1,\"id\":488,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":489,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":490,\"textContent\":\" \"},{\"nodeType\":1,\"id\":491,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":492,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":493,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":494,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":495,\"textContent\":\" \"},{\"nodeType\":1,\"id\":496,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":497,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":498,\"textContent\":\" \"},{\"nodeType\":1,\"id\":499,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":500,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":501,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":502,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":503,\"textContent\":\" \"},{\"nodeType\":1,\"id\":504,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":505,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":506,\"textContent\":\" \"},{\"nodeType\":1,\"id\":507,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":508,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":509,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":510,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":511,\"textContent\":\" \"},{\"nodeType\":1,\"id\":512,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":513,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":514,\"textContent\":\" \"},{\"nodeType\":1,\"id\":515,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":516,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":517,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":518,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":519,\"textContent\":\" \"},{\"nodeType\":1,\"id\":520,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":521,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":522,\"textContent\":\" \"},{\"nodeType\":1,\"id\":523,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":524,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":525,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":526,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":527,\"textContent\":\" \"},{\"nodeType\":1,\"id\":528,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":529,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":530,\"textContent\":\" \"},{\"nodeType\":1,\"id\":531,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":532,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":533,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":534,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":535,\"textContent\":\" \"},{\"nodeType\":1,\"id\":536,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":537,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":538,\"textContent\":\" \"},{\"nodeType\":1,\"id\":539,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":540,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":541,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":542,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":543,\"textContent\":\" \"},{\"nodeType\":1,\"id\":544,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":545,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":546,\"textContent\":\" \"},{\"nodeType\":1,\"id\":547,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":548,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":549,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":550,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":551,\"textContent\":\" \"},{\"nodeType\":1,\"id\":552,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":553,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":554,\"textContent\":\" \"},{\"nodeType\":1,\"id\":555,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":556,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":557,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":558,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":559,\"textContent\":\" \"},{\"nodeType\":1,\"id\":560,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":561,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":562,\"textContent\":\" \"},{\"nodeType\":1,\"id\":563,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":564,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":565,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":566,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":567,\"textContent\":\" \"},{\"nodeType\":1,\"id\":568,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":569,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":570,\"textContent\":\" \"},{\"nodeType\":1,\"id\":571,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"U\",\"value\":\"\"}},{\"nodeType\":3,\"id\":572,\"textContent\":\"U \"},{\"nodeType\":1,\"id\":573,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":574,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":575,\"textContent\":\" \"},{\"nodeType\":1,\"id\":576,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":577,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":578,\"textContent\":\" \"},{\"nodeType\":1,\"id\":579,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":580,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":581,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":582,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":583,\"textContent\":\" \"},{\"nodeType\":1,\"id\":584,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":585,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":586,\"textContent\":\" \"},{\"nodeType\":1,\"id\":587,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":588,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":589,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":590,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":591,\"textContent\":\" \"},{\"nodeType\":1,\"id\":592,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":593,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":594,\"textContent\":\" \"},{\"nodeType\":1,\"id\":595,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":596,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":597,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":598,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":599,\"textContent\":\" \"},{\"nodeType\":1,\"id\":600,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":601,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":602,\"textContent\":\" \"},{\"nodeType\":1,\"id\":603,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":604,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":605,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":606,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":607,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":608,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":609,\"textContent\":\" \"},{\"nodeType\":1,\"id\":610,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"acme\",\"id\":\"acme.midpoint\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":611,\"textContent\":\" \"},{\"nodeType\":1,\"id\":612,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":613,\"textContent\":\"Coffee breaks happen halfway through a shift.\"},{\"nodeType\":1,\"id\":614,\"tagName\":\"BR\",\"attributes\":{}},{\"nodeType\":3,\"id\":615,\"textContent\":\" Which shift(s) share a break with I?\"}]},{\"nodeType\":3,\"id\":616,\"textContent\":\" \"},{\"nodeType\":1,\"id\":617,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":618,\"textContent\":\" \"},{\"nodeType\":1,\"id\":619,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":620,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":621,\"textContent\":\" \"},{\"nodeType\":1,\"id\":622,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":623,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":624,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":625,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":626,\"textContent\":\" \"},{\"nodeType\":1,\"id\":627,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":628,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":629,\"textContent\":\" \"},{\"nodeType\":1,\"id\":630,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":631,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":632,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":633,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":634,\"textContent\":\" \"},{\"nodeType\":1,\"id\":635,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":636,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":637,\"textContent\":\" \"},{\"nodeType\":1,\"id\":638,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":639,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":640,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":641,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":642,\"textContent\":\" \"},{\"nodeType\":1,\"id\":643,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":644,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":645,\"textContent\":\" \"},{\"nodeType\":1,\"id\":646,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":647,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":648,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":649,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":650,\"textContent\":\" \"},{\"nodeType\":1,\"id\":651,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":652,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":653,\"textContent\":\" \"},{\"nodeType\":1,\"id\":654,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":655,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":656,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":657,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":658,\"textContent\":\" \"},{\"nodeType\":1,\"id\":659,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":660,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":661,\"textContent\":\" \"},{\"nodeType\":1,\"id\":662,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":663,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":664,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":665,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":666,\"textContent\":\" \"},{\"nodeType\":1,\"id\":667,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":668,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":669,\"textContent\":\" \"},{\"nodeType\":1,\"id\":670,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":671,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":672,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":673,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":674,\"textContent\":\" \"},{\"nodeType\":1,\"id\":675,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":676,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":677,\"textContent\":\" \"},{\"nodeType\":1,\"id\":678,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":679,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":680,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":681,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":682,\"textContent\":\" \"},{\"nodeType\":1,\"id\":683,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":684,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":685,\"textContent\":\" \"},{\"nodeType\":1,\"id\":686,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":687,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":688,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":689,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":690,\"textContent\":\" \"},{\"nodeType\":1,\"id\":691,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":692,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":693,\"textContent\":\" \"},{\"nodeType\":1,\"id\":694,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":695,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":696,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":697,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":698,\"textContent\":\" \"},{\"nodeType\":1,\"id\":699,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":700,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":701,\"textContent\":\" \"},{\"nodeType\":1,\"id\":702,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"U\",\"value\":\"\"}},{\"nodeType\":3,\"id\":703,\"textContent\":\"U \"},{\"nodeType\":1,\"id\":704,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":705,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":706,\"textContent\":\" \"},{\"nodeType\":1,\"id\":707,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":708,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":709,\"textContent\":\" \"},{\"nodeType\":1,\"id\":710,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":711,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":712,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":713,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":714,\"textContent\":\" \"},{\"nodeType\":1,\"id\":715,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":716,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":717,\"textContent\":\" \"},{\"nodeType\":1,\"id\":718,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":719,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":720,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":721,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":722,\"textContent\":\" \"},{\"nodeType\":1,\"id\":723,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":724,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":725,\"textContent\":\" \"},{\"nodeType\":1,\"id\":726,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":727,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":728,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":729,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":730,\"textContent\":\" \"},{\"nodeType\":1,\"id\":731,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":732,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":733,\"textContent\":\" \"},{\"nodeType\":1,\"id\":734,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":735,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":736,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":737,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":738,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":739,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":740,\"textContent\":\" \"},{\"nodeType\":1,\"id\":741,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.duration\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":742,\"textContent\":\" \"},{\"nodeType\":1,\"id\":743,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":744,\"textContent\":\"Which shift(s) are six hours long?\"}]},{\"nodeType\":3,\"id\":745,\"textContent\":\" \"},{\"nodeType\":1,\"id\":746,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":747,\"textContent\":\" \"},{\"nodeType\":1,\"id\":748,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":749,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":750,\"textContent\":\" \"},{\"nodeType\":1,\"id\":751,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":752,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":753,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":754,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":755,\"textContent\":\" \"},{\"nodeType\":1,\"id\":756,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":757,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":758,\"textContent\":\" \"},{\"nodeType\":1,\"id\":759,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":760,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":761,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":762,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":763,\"textContent\":\" \"},{\"nodeType\":1,\"id\":764,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":765,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":766,\"textContent\":\" \"},{\"nodeType\":1,\"id\":767,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":768,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":769,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":770,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":771,\"textContent\":\" \"},{\"nodeType\":1,\"id\":772,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":773,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":774,\"textContent\":\" \"},{\"nodeType\":1,\"id\":775,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":776,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":777,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":778,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":779,\"textContent\":\" \"},{\"nodeType\":1,\"id\":780,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":781,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":782,\"textContent\":\" \"},{\"nodeType\":1,\"id\":783,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":784,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":785,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":786,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":787,\"textContent\":\" \"},{\"nodeType\":1,\"id\":788,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":789,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":790,\"textContent\":\" \"},{\"nodeType\":1,\"id\":791,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":792,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":793,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":794,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":795,\"textContent\":\" \"},{\"nodeType\":1,\"id\":796,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":797,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":798,\"textContent\":\" \"},{\"nodeType\":1,\"id\":799,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":800,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":801,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":802,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":803,\"textContent\":\" \"},{\"nodeType\":1,\"id\":804,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":805,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":806,\"textContent\":\" \"},{\"nodeType\":1,\"id\":807,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":808,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":809,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":810,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":811,\"textContent\":\" \"},{\"nodeType\":1,\"id\":812,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":813,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":814,\"textContent\":\" \"},{\"nodeType\":1,\"id\":815,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":816,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":817,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":818,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":819,\"textContent\":\" \"},{\"nodeType\":1,\"id\":820,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":821,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":822,\"textContent\":\" \"},{\"nodeType\":1,\"id\":823,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":824,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":825,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":826,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":827,\"textContent\":\" \"},{\"nodeType\":1,\"id\":828,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":829,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":830,\"textContent\":\" \"},{\"nodeType\":1,\"id\":831,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":832,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":833,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":834,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":835,\"textContent\":\" \"},{\"nodeType\":1,\"id\":836,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":837,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":838,\"textContent\":\" \"},{\"nodeType\":1,\"id\":839,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":840,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":841,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":842,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":843,\"textContent\":\" \"},{\"nodeType\":1,\"id\":844,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":845,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":846,\"textContent\":\" \"},{\"nodeType\":1,\"id\":847,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":848,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":849,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":850,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":851,\"textContent\":\" \"},{\"nodeType\":1,\"id\":852,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":853,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":854,\"textContent\":\" \"},{\"nodeType\":1,\"id\":855,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":856,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":857,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":858,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":859,\"textContent\":\" \"},{\"nodeType\":1,\"id\":860,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":861,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":862,\"textContent\":\" \"},{\"nodeType\":1,\"id\":863,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":864,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":865,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":866,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":867,\"textContent\":\" \"},{\"nodeType\":1,\"id\":868,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":869,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":870,\"textContent\":\" \"},{\"nodeType\":1,\"id\":871,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":872,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":873,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":874,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":875,\"textContent\":\" \"},{\"nodeType\":1,\"id\":876,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":877,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":878,\"textContent\":\" \"},{\"nodeType\":1,\"id\":879,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":880,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":881,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":882,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":883,\"textContent\":\" \"},{\"nodeType\":1,\"id\":884,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":885,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":886,\"textContent\":\" \"},{\"nodeType\":1,\"id\":887,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":888,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":889,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":890,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":891,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":892,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":893,\"textContent\":\" \"},{\"nodeType\":1,\"id\":894,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.duration+starts\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":895,\"textContent\":\" \"},{\"nodeType\":1,\"id\":896,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":897,\"textContent\":\"Which 2 shifts less than 5 hours long start at the same time?\"}]},{\"nodeType\":3,\"id\":898,\"textContent\":\" \"},{\"nodeType\":1,\"id\":899,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":900,\"textContent\":\" \"},{\"nodeType\":1,\"id\":901,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":902,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":903,\"textContent\":\" \"},{\"nodeType\":1,\"id\":904,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":905,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":906,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":907,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":908,\"textContent\":\" \"},{\"nodeType\":1,\"id\":909,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":910,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":911,\"textContent\":\" \"},{\"nodeType\":1,\"id\":912,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":913,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":914,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":915,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":916,\"textContent\":\" \"},{\"nodeType\":1,\"id\":917,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":918,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":919,\"textContent\":\" \"},{\"nodeType\":1,\"id\":920,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":921,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":922,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":923,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":924,\"textContent\":\" \"},{\"nodeType\":1,\"id\":925,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":926,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":927,\"textContent\":\" \"},{\"nodeType\":1,\"id\":928,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":929,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":930,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":931,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":932,\"textContent\":\" \"},{\"nodeType\":1,\"id\":933,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":934,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":935,\"textContent\":\" \"},{\"nodeType\":1,\"id\":936,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":937,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":938,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":939,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":940,\"textContent\":\" \"},{\"nodeType\":1,\"id\":941,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":942,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":943,\"textContent\":\" \"},{\"nodeType\":1,\"id\":944,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":945,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":946,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":947,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":948,\"textContent\":\" \"},{\"nodeType\":1,\"id\":949,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":950,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":951,\"textContent\":\" \"},{\"nodeType\":1,\"id\":952,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":953,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":954,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":955,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":956,\"textContent\":\" \"},{\"nodeType\":1,\"id\":957,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":958,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":959,\"textContent\":\" \"},{\"nodeType\":1,\"id\":960,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":961,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":962,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":963,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":964,\"textContent\":\" \"},{\"nodeType\":1,\"id\":965,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":966,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":967,\"textContent\":\" \"},{\"nodeType\":1,\"id\":968,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":969,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":970,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":971,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":972,\"textContent\":\" \"},{\"nodeType\":1,\"id\":973,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":974,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":975,\"textContent\":\" \"},{\"nodeType\":1,\"id\":976,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":977,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":978,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":979,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":980,\"textContent\":\" \"},{\"nodeType\":1,\"id\":981,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":982,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":983,\"textContent\":\" \"},{\"nodeType\":1,\"id\":984,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":985,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":986,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":987,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":988,\"textContent\":\" \"},{\"nodeType\":1,\"id\":989,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":990,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":991,\"textContent\":\" \"},{\"nodeType\":1,\"id\":992,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":993,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":994,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":995,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":996,\"textContent\":\" \"},{\"nodeType\":1,\"id\":997,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":998,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":999,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1000,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1001,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":1002,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1003,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1004,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1005,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1006,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1007,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1008,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1009,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":1010,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1011,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1012,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1013,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1014,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1015,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1016,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1017,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":1018,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1019,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1020,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1021,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1022,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1023,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1024,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1025,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":1026,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1027,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1028,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1029,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1030,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1031,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1032,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1033,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":1034,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1035,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1036,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1037,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1038,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1039,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1040,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1041,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":1042,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1043,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1044,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1045,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1046,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1047,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.duration+contained\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":1048,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1049,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":1050,\"textContent\":\"Which shift(s) under 7 hours long starts before B starts, and ends after X ends?\"}]},{\"nodeType\":3,\"id\":1051,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1052,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":1053,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1054,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1055,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1056,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1057,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1058,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":1059,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1060,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1061,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1062,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1063,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1064,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1065,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1066,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":1067,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1068,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1069,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1070,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1071,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1072,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1073,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1074,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":1075,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1076,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1077,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1078,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1079,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1080,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1081,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1082,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":1083,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1084,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1085,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1086,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1087,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1088,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1089,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1090,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":1091,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1092,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1093,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1094,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1095,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1096,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1097,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1098,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":1099,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1100,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1101,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1102,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1103,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1104,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1105,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1106,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":1107,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1108,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1109,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1110,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1111,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1112,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1113,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1114,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":1115,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1116,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1117,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1118,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1119,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1120,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1121,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1122,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":1123,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1124,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1125,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1126,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1127,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1128,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1129,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1130,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":1131,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1132,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1133,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1134,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1135,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1136,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1137,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1138,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":1139,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1140,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1141,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1142,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1143,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1144,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1145,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1146,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":1147,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1148,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1149,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1150,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1151,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1152,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1153,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1154,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":1155,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1156,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1157,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1158,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1159,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1160,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1161,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1162,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":1163,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1164,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1165,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1166,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1167,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1168,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1169,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1170,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":1171,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1172,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1173,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1174,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1175,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1176,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1177,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1178,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":1179,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1180,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1181,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1182,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1183,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1184,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1185,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1186,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":1187,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1188,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1189,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1190,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1191,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1192,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1193,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1194,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":1195,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1196,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1197,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1198,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1199,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1200,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.starttime+before+endtime+during\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":1201,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1202,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":1203,\"textContent\":\"Which shift(s) begins before J begins and ends during B?\"}]},{\"nodeType\":3,\"id\":1204,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1205,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":1206,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1207,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1208,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1209,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1210,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1211,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":1212,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1213,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1214,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1215,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1216,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1217,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1218,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1219,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":1220,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1221,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1222,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1223,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1224,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1225,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1226,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1227,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":1228,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1229,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1230,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1231,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1232,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1233,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1234,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1235,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":1236,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1237,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1238,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1239,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1240,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1241,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1242,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1243,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":1244,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1245,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1246,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1247,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1248,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1249,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1250,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1251,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":1252,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1253,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1254,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1255,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1256,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1257,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1258,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1259,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":1260,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1261,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1262,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1263,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1264,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1265,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1266,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1267,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":1268,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1269,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1270,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1271,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1272,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1273,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1274,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1275,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":1276,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1277,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1278,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1279,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1280,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1281,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1282,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1283,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":1284,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1285,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1286,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1287,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1288,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1289,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1290,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1291,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":1292,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1293,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1294,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1295,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1296,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1297,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1298,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1299,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":1300,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1301,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1302,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1303,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1304,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1305,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1306,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1307,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":1308,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1309,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1310,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1311,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1312,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1313,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1314,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1315,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":1316,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1317,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1318,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1319,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1320,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1321,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1322,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1323,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":1324,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1325,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1326,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1327,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1328,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1329,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1330,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1331,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":1332,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1333,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1334,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1335,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1336,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1337,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1338,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1339,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":1340,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1341,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1342,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1343,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1344,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1345,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1346,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1347,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":1348,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1349,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1350,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1351,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1352,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1353,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.ends\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":1354,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1355,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":1356,\"textContent\":\"Which shift(s) end at the same time as F?\"}]},{\"nodeType\":3,\"id\":1357,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1358,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":1359,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1360,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1361,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1362,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1363,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1364,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":1365,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1366,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1367,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1368,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1369,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1370,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1371,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1372,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":1373,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1374,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1375,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1376,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1377,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1378,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1379,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1380,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":1381,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1382,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1383,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1384,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1385,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1386,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1387,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1388,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":1389,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1390,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1391,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1392,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1393,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1394,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1395,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1396,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":1397,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1398,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1399,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1400,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1401,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1402,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1403,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1404,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":1405,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1406,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1407,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1408,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1409,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1410,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1411,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1412,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":1413,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1414,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1415,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1416,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1417,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1418,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1419,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1420,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":1421,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1422,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1423,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1424,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1425,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1426,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1427,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1428,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":1429,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1430,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1431,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1432,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1433,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1434,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1435,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1436,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":1437,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1438,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1439,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1440,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1441,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1442,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1443,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1444,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":1445,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1446,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1447,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1448,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1449,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1450,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1451,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1452,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":1453,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1454,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1455,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1456,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1457,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1458,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1459,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1460,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":1461,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1462,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1463,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1464,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1465,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1466,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1467,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1468,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":1469,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1470,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1471,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1472,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1473,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1474,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1475,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1476,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":1477,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1478,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1479,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1480,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1481,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1482,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1483,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1484,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":1485,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1486,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1487,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1488,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1489,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1490,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1491,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1492,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":1493,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1494,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1495,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1496,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1497,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1498,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1499,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1500,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":1501,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1502,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1503,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1504,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1505,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1506,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.starttime\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":1507,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1508,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":1509,\"textContent\":\"Which shift(s) start at 12pm?\"}]},{\"nodeType\":3,\"id\":1510,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1511,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":1512,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1513,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1514,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1515,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1516,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1517,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":1518,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1519,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1520,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1521,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1522,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1523,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1524,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1525,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":1526,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1527,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1528,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1529,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1530,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1531,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1532,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1533,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":1534,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1535,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1536,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1537,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1538,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1539,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1540,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1541,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":1542,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1543,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1544,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1545,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1546,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1547,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1548,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1549,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":1550,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1551,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1552,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1553,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1554,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1555,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1556,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1557,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":1558,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1559,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1560,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1561,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1562,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1563,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1564,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1565,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":1566,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1567,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1568,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1569,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1570,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1571,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1572,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1573,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":1574,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1575,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1576,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1577,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1578,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1579,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1580,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1581,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":1582,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1583,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1584,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1585,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1586,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1587,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1588,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1589,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":1590,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1591,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1592,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1593,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1594,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1595,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1596,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1597,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":1598,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1599,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1600,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1601,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1602,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1603,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1604,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1605,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":1606,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1607,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1608,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1609,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1610,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1611,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1612,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1613,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":1614,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1615,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1616,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1617,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1618,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1619,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1620,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1621,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":1622,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1623,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1624,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1625,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1626,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1627,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1628,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1629,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":1630,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1631,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1632,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1633,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1634,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1635,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1636,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1637,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":1638,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1639,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1640,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1641,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1642,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1643,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1644,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1645,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":1646,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1647,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1648,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1649,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1650,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1651,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1652,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1653,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":1654,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1655,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1656,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1657,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1658,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1659,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.starts\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":1660,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1661,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":1662,\"textContent\":\"Which shift(s) start at the same time as F?\"}]},{\"nodeType\":3,\"id\":1663,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1664,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":1665,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1666,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1667,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1668,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1669,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1670,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":1671,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1672,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1673,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1674,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1675,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1676,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1677,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1678,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":1679,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1680,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1681,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1682,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1683,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1684,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1685,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1686,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":1687,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1688,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1689,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1690,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1691,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1692,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1693,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1694,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":1695,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1696,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1697,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1698,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1699,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1700,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1701,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1702,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":1703,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1704,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1705,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1706,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1707,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1708,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1709,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1710,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":1711,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1712,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1713,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1714,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1715,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1716,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1717,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1718,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":1719,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1720,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1721,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1722,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1723,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1724,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1725,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1726,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":1727,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1728,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1729,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1730,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1731,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1732,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1733,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1734,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":1735,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1736,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1737,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1738,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1739,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1740,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1741,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1742,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":1743,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1744,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1745,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1746,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1747,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1748,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1749,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1750,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":1751,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1752,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1753,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1754,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1755,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1756,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1757,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1758,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":1759,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1760,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1761,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1762,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1763,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1764,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1765,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1766,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":1767,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1768,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1769,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1770,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1771,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1772,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1773,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1774,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":1775,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1776,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1777,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1778,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1779,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1780,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1781,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1782,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":1783,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1784,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1785,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1786,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1787,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1788,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1789,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1790,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":1791,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1792,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1793,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1794,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1795,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1796,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1797,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1798,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":1799,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1800,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1801,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1802,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1803,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1804,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1805,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1806,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":1807,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1808,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1809,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1810,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1811,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1812,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.meets\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":1813,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1814,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":1815,\"textContent\":\"Which 2 shifts end when Z begins?\"}]},{\"nodeType\":3,\"id\":1816,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1817,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":1818,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1819,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1820,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1821,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1822,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1823,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":1824,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1825,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1826,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1827,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1828,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1829,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1830,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1831,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":1832,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1833,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1834,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1835,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1836,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1837,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1838,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1839,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":1840,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1841,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1842,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1843,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1844,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1845,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1846,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1847,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":1848,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1849,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1850,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1851,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1852,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1853,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1854,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1855,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":1856,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1857,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1858,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1859,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1860,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1861,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1862,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1863,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":1864,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1865,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1866,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1867,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1868,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1869,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1870,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1871,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":1872,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1873,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1874,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1875,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1876,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1877,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1878,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1879,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":1880,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1881,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1882,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1883,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1884,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1885,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1886,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1887,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":1888,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1889,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1890,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1891,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1892,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1893,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1894,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1895,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":1896,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1897,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1898,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1899,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1900,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1901,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1902,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1903,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":1904,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1905,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1906,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1907,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1908,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1909,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1910,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1911,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":1912,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1913,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1914,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1915,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1916,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1917,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1918,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1919,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":1920,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1921,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1922,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1923,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1924,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1925,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1926,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1927,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":1928,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1929,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1930,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1931,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1932,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1933,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1934,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1935,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":1936,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1937,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1938,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1939,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1940,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1941,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1942,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1943,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":1944,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1945,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1946,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1947,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1948,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1949,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1950,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1951,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":1952,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1953,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1954,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1955,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1956,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1957,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1958,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1959,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":1960,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1961,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1962,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1963,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1964,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1965,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.endtime\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":1966,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1967,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":1968,\"textContent\":\"Which shift(s) end at 3pm?\"}]},{\"nodeType\":3,\"id\":1969,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1970,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":1971,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1972,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1973,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1974,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1975,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1976,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":1977,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1978,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1979,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1980,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1981,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1982,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1983,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1984,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":1985,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1986,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1987,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1988,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1989,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1990,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1991,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1992,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":1993,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1994,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1995,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1996,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1997,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1998,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1999,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2000,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":2001,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2002,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2003,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2004,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2005,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2006,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2007,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2008,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":2009,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2010,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2011,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2012,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2013,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2014,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2015,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2016,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":2017,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2018,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2019,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2020,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2021,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2022,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2023,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2024,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":2025,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2026,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2027,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2028,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2029,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2030,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2031,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2032,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":2033,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2034,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2035,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2036,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2037,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2038,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2039,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2040,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":2041,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2042,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2043,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2044,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2045,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2046,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2047,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2048,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":2049,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2050,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2051,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2052,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2053,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2054,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2055,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2056,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":2057,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2058,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2059,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2060,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2061,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2062,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2063,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2064,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":2065,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2066,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2067,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2068,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2069,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2070,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2071,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2072,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":2073,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2074,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2075,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2076,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2077,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2078,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2079,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2080,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":2081,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2082,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2083,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2084,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2085,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2086,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2087,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2088,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":2089,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2090,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2091,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2092,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2093,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2094,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2095,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2096,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":2097,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2098,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2099,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2100,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2101,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2102,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2103,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2104,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":2105,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2106,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2107,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2108,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2109,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2110,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2111,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2112,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":2113,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2114,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2115,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2116,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2117,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2118,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.midpoint\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":2119,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2120,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":2121,\"textContent\":\"Coffee breaks happen halfway through a shift. \"},{\"nodeType\":1,\"id\":2122,\"tagName\":\"BR\",\"attributes\":{}},{\"nodeType\":3,\"id\":2123,\"textContent\":\"Which shifts share a break at 2pm?\"}]},{\"nodeType\":3,\"id\":2124,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2125,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":2126,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2127,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2128,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2129,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2130,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2131,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":2132,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2133,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2134,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2135,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2136,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2137,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2138,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2139,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":2140,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2141,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2142,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2143,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2144,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2145,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2146,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2147,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":2148,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2149,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2150,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2151,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2152,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2153,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2154,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2155,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":2156,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2157,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2158,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2159,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2160,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2161,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2162,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2163,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":2164,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2165,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2166,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2167,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2168,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2169,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2170,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2171,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":2172,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2173,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2174,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2175,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2176,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2177,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2178,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2179,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":2180,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2181,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2182,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2183,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2184,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2185,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2186,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2187,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":2188,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2189,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2190,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2191,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2192,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2193,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2194,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2195,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":2196,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2197,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2198,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2199,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2200,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2201,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2202,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2203,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":2204,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2205,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2206,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2207,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2208,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2209,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2210,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2211,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":2212,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2213,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2214,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2215,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2216,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2217,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2218,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2219,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":2220,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2221,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2222,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2223,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2224,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2225,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2226,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2227,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":2228,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2229,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2230,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2231,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2232,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2233,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2234,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2235,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":2236,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2237,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2238,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2239,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2240,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2241,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2242,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2243,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":2244,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2245,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2246,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2247,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2248,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2249,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2250,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2251,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":2252,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2253,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2254,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2255,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2256,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2257,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2258,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2259,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":2260,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2261,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2262,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2263,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2264,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2265,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2266,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2267,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":2268,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2269,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2270,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2271,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2272,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2273,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\".strategy\",\"style\":\"display: block;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2274,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2275,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":2276,\"textContent\":\"Please describe how to determine what event(s) start at 12pm?\"}]},{\"nodeType\":3,\"id\":2277,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2278,\"tagName\":\"TEXTAREA\",\"attributes\":{\"id\":\"strategyAnswer\",\"rows\":\"5\",\"cols\":\"80\"}},{\"nodeType\":3,\"id\":2279,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2280,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2281,\"textContent\":\" \"},{\"nodeType\":8,\"id\":2282},{\"nodeType\":3,\"id\":2283,\"textContent\":\" \"},{\"nodeType\":8,\"id\":2284},{\"nodeType\":3,\"id\":2285,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2286,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"fixbottom\"},\"childNodes\":[{\"nodeType\":3,\"id\":2287,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2288,\"tagName\":\"BUTTON\",\"attributes\":{\"type\":\"button\",\"id\":\"testingButton\",\"style\":\"display:none;\",\"class\":\"btn\"},\"childNodes\":[{\"nodeType\":3,\"id\":2289,\"textContent\":\"SUBMIT\"}]},{\"nodeType\":3,\"id\":2290,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2291,\"tagName\":\"BUTTON\",\"attributes\":{\"type\":\"button\",\"id\":\"strategyButton\",\"style\":\"display: block;\",\"class\":\"btn\"},\"childNodes\":[{\"nodeType\":3,\"id\":2292,\"textContent\":\"SUBMIT\"}]},{\"nodeType\":3,\"id\":2293,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2294,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2295,\"textContent\":\" \"},{\"nodeType\":8,\"id\":2296},{\"nodeType\":3,\"id\":2297,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2298,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"d3container\"},\"childNodes\":[{\"nodeType\":1,\"id\":2299,\"tagName\":\"svg\",\"attributes\":{\"width\":\"930\",\"height\":\"915\"},\"childNodes\":[{\"nodeType\":1,\"id\":2300,\"tagName\":\"g\",\"attributes\":{\"transform\":\"translate(100,25)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2301,\"tagName\":\"g\",\"attributes\":{\"class\":\"leaders\"}},{\"nodeType\":1,\"id\":2302,\"tagName\":\"g\",\"attributes\":{\"class\":\"static-scaffold\"}},{\"nodeType\":1,\"id\":2303,\"tagName\":\"g\",\"attributes\":{\"class\":\"xaxis\",\"transform\":\"translate(0,800)\",\"fill\":\"none\",\"font-size\":\"10\",\"font-family\":\"sans-serif\",\"text-anchor\":\"middle\"},\"childNodes\":[{\"nodeType\":1,\"id\":2304,\"tagName\":\"path\",\"attributes\":{\"class\":\"domain\",\"stroke\":\"#000\",\"d\":\"M0.5,6V0.5H800.5V6\"}},{\"nodeType\":1,\"id\":2305,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0.5,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2306,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2307,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2308,\"textContent\":\"08 AM\"}]}]},{\"nodeType\":1,\"id\":2309,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(33.83333333333333,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2310,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2311,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2312,\"textContent\":\"08:30\"}]}]},{\"nodeType\":1,\"id\":2313,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(67.16666666666666,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2314,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2315,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2316,\"textContent\":\"09 AM\"}]}]},{\"nodeType\":1,\"id\":2317,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(100.5,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2318,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2319,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2320,\"textContent\":\"09:30\"}]}]},{\"nodeType\":1,\"id\":2321,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(133.83333333333331,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2322,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2323,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2324,\"textContent\":\"10 AM\"}]}]},{\"nodeType\":1,\"id\":2325,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(167.16666666666669,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2326,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2327,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2328,\"textContent\":\"10:30\"}]}]},{\"nodeType\":1,\"id\":2329,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(200.5,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2330,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2331,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2332,\"textContent\":\"11 AM\"}]}]},{\"nodeType\":1,\"id\":2333,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(233.83333333333334,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2334,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2335,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2336,\"textContent\":\"11:30\"}]}]},{\"nodeType\":1,\"id\":2337,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(267.16666666666663,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2338,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2339,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2340,\"textContent\":\"12 PM\"}]}]},{\"nodeType\":1,\"id\":2341,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(300.5,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2342,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2343,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2344,\"textContent\":\"12:30\"}]}]},{\"nodeType\":1,\"id\":2345,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(333.83333333333337,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2346,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2347,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2348,\"textContent\":\"01 PM\"}]}]},{\"nodeType\":1,\"id\":2349,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(367.16666666666663,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2350,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2351,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2352,\"textContent\":\"01:30\"}]}]},{\"nodeType\":1,\"id\":2353,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(400.5,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2354,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2355,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2356,\"textContent\":\"02 PM\"}]}]},{\"nodeType\":1,\"id\":2357,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(433.8333333333333,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2358,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2359,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2360,\"textContent\":\"02:30\"}]}]},{\"nodeType\":1,\"id\":2361,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(467.1666666666667,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2362,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2363,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2364,\"textContent\":\"03 PM\"}]}]},{\"nodeType\":1,\"id\":2365,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(500.5,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2366,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2367,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2368,\"textContent\":\"03:30\"}]}]},{\"nodeType\":1,\"id\":2369,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(533.8333333333333,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2370,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2371,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2372,\"textContent\":\"04 PM\"}]}]},{\"nodeType\":1,\"id\":2373,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(567.1666666666667,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2374,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2375,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2376,\"textContent\":\"04:30\"}]}]},{\"nodeType\":1,\"id\":2377,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(600.5,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2378,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2379,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2380,\"textContent\":\"05 PM\"}]}]},{\"nodeType\":1,\"id\":2381,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(633.8333333333333,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2382,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2383,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2384,\"textContent\":\"05:30\"}]}]},{\"nodeType\":1,\"id\":2385,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(667.1666666666667,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2386,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2387,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2388,\"textContent\":\"06 PM\"}]}]},{\"nodeType\":1,\"id\":2389,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(700.5,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2390,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2391,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2392,\"textContent\":\"06:30\"}]}]},{\"nodeType\":1,\"id\":2393,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(733.8333333333333,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2394,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2395,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2396,\"textContent\":\"07 PM\"}]}]},{\"nodeType\":1,\"id\":2397,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(767.1666666666667,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2398,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2399,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2400,\"textContent\":\"07:30\"}]}]},{\"nodeType\":1,\"id\":2401,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(800.5,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2402,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2403,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2404,\"textContent\":\"08 PM\"}]}]},{\"nodeType\":1,\"id\":2405,\"tagName\":\"g\",\"attributes\":{\"class\":\"axisTitle\"},\"childNodes\":[{\"nodeType\":1,\"id\":2406,\"tagName\":\"text\",\"attributes\":{\"x\":\"533.3333333333334\",\"y\":\"80\",\"style\":\"text-anchor: end;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2407,\"textContent\":\"START & END TIME (time of day)\"}]}]}]},{\"nodeType\":1,\"id\":2408,\"tagName\":\"g\",\"attributes\":{\"class\":\"yaxis\",\"fill\":\"none\",\"font-size\":\"10\",\"font-family\":\"sans-serif\",\"text-anchor\":\"end\"},\"childNodes\":[{\"nodeType\":1,\"id\":2409,\"tagName\":\"path\",\"attributes\":{\"class\":\"domain\",\"stroke\":\"#000\",\"d\":\"M-15,800.5H0.5V0.5H-15\"}},{\"nodeType\":1,\"id\":2410,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,800.5)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2411,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2412,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2413,\"textContent\":\"0\"}]}]},{\"nodeType\":1,\"id\":2414,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,733.8333333333334)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2415,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2416,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2417,\"textContent\":\"1\"}]}]},{\"nodeType\":1,\"id\":2418,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,667.1666666666667)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2419,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2420,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2421,\"textContent\":\"2\"}]}]},{\"nodeType\":1,\"id\":2422,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,600.5)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2423,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2424,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2425,\"textContent\":\"3\"}]}]},{\"nodeType\":1,\"id\":2426,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,533.8333333333334)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2427,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2428,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2429,\"textContent\":\"4\"}]}]},{\"nodeType\":1,\"id\":2430,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,467.16666666666663)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2431,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2432,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2433,\"textContent\":\"5\"}]}]},{\"nodeType\":1,\"id\":2434,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,400.5)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2435,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2436,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2437,\"textContent\":\"6\"}]}]},{\"nodeType\":1,\"id\":2438,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,333.8333333333333)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2439,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2440,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2441,\"textContent\":\"7\"}]}]},{\"nodeType\":1,\"id\":2442,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,267.16666666666674)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2443,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2444,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2445,\"textContent\":\"8\"}]}]},{\"nodeType\":1,\"id\":2446,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,200.5)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2447,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2448,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2449,\"textContent\":\"9\"}]}]},{\"nodeType\":1,\"id\":2450,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,133.83333333333326)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2451,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2452,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2453,\"textContent\":\"10\"}]}]},{\"nodeType\":1,\"id\":2454,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,67.16666666666674)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2455,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2456,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2457,\"textContent\":\"11\"}]}]},{\"nodeType\":1,\"id\":2458,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,0.5)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2459,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2460,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2461,\"textContent\":\"12\"}]}]},{\"nodeType\":1,\"id\":2462,\"tagName\":\"g\",\"attributes\":{\"class\":\"axisTitle\"},\"childNodes\":[{\"nodeType\":1,\"id\":2463,\"tagName\":\"text\",\"attributes\":{\"transform\":\"rotate(-90)\",\"x\":\"-350\",\"y\":\"-60\",\"style\":\"text-anchor: end;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2464,\"textContent\":\"DURATION (in hours)\"}]}]}]},{\"nodeType\":1,\"id\":2465,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2466,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2467,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"733.3333333333334\",\"y2\":\"733.3333333333334\"}}]},{\"nodeType\":1,\"id\":2468,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2469,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"666.6666666666667\",\"y2\":\"666.6666666666667\"}}]},{\"nodeType\":1,\"id\":2470,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2471,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"600\",\"y2\":\"600\"}}]},{\"nodeType\":1,\"id\":2472,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2473,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"533.3333333333334\",\"y2\":\"533.3333333333334\"}}]},{\"nodeType\":1,\"id\":2474,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2475,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"466.66666666666663\",\"y2\":\"466.66666666666663\"}}]},{\"nodeType\":1,\"id\":2476,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2477,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"400\",\"y2\":\"400\"}}]},{\"nodeType\":1,\"id\":2478,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2479,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"333.3333333333333\",\"y2\":\"333.3333333333333\"}}]},{\"nodeType\":1,\"id\":2480,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2481,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"266.66666666666674\",\"y2\":\"266.66666666666674\"}}]},{\"nodeType\":1,\"id\":2482,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2483,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"200\",\"y2\":\"200\"}}]},{\"nodeType\":1,\"id\":2484,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2485,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"133.33333333333326\",\"y2\":\"133.33333333333326\"}}]},{\"nodeType\":1,\"id\":2486,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2487,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"66.66666666666674\",\"y2\":\"66.66666666666674\"}}]},{\"nodeType\":1,\"id\":2488,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2489,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"0\",\"y2\":\"0\"}}]}]},{\"nodeType\":1,\"id\":2490,\"tagName\":\"g\",\"attributes\":{\"class\":\"xgrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2491,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"0\",\"y1\":\"800\",\"x2\":\"400\",\"y2\":\"0\"}},{\"nodeType\":1,\"id\":2492,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"800\",\"y1\":\"800\",\"x2\":\"400\",\"y2\":\"0\"}},{\"nodeType\":1,\"id\":2493,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"66.66666666666666\",\"y1\":\"800\",\"x2\":\"433.3333333333333\",\"y2\":\"66.66666666666674\"}},{\"nodeType\":1,\"id\":2494,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"733.3333333333333\",\"y1\":\"800\",\"x2\":\"366.66666666666663\",\"y2\":\"66.66666666666674\"}},{\"nodeType\":1,\"id\":2495,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"133.33333333333331\",\"y1\":\"800\",\"x2\":\"466.6666666666667\",\"y2\":\"133.33333333333326\"}},{\"nodeType\":1,\"id\":2496,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"666.6666666666667\",\"y1\":\"800\",\"x2\":\"333.33333333333337\",\"y2\":\"133.33333333333326\"}},{\"nodeType\":1,\"id\":2497,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"200\",\"y1\":\"800\",\"x2\":\"500\",\"y2\":\"200\"}},{\"nodeType\":1,\"id\":2498,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"600\",\"y1\":\"800\",\"x2\":\"300\",\"y2\":\"200\"}},{\"nodeType\":1,\"id\":2499,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"266.66666666666663\",\"y1\":\"800\",\"x2\":\"533.3333333333333\",\"y2\":\"266.66666666666674\"}},{\"nodeType\":1,\"id\":2500,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"533.3333333333333\",\"y1\":\"800\",\"x2\":\"266.66666666666663\",\"y2\":\"266.66666666666674\"}},{\"nodeType\":1,\"id\":2501,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"333.33333333333337\",\"y1\":\"800\",\"x2\":\"566.6666666666667\",\"y2\":\"333.3333333333333\"}},{\"nodeType\":1,\"id\":2502,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"466.6666666666667\",\"y1\":\"800\",\"x2\":\"233.33333333333334\",\"y2\":\"333.3333333333333\"}},{\"nodeType\":1,\"id\":2503,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"400\",\"y1\":\"800\",\"x2\":\"600\",\"y2\":\"400\"}},{\"nodeType\":1,\"id\":2504,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"400\",\"y1\":\"800\",\"x2\":\"200\",\"y2\":\"400\"}},{\"nodeType\":1,\"id\":2505,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"466.6666666666667\",\"y1\":\"800\",\"x2\":\"633.3333333333333\",\"y2\":\"466.66666666666663\"}},{\"nodeType\":1,\"id\":2506,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"333.33333333333337\",\"y1\":\"800\",\"x2\":\"166.66666666666669\",\"y2\":\"466.66666666666663\"}},{\"nodeType\":1,\"id\":2507,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"533.3333333333333\",\"y1\":\"800\",\"x2\":\"666.6666666666667\",\"y2\":\"533.3333333333334\"}},{\"nodeType\":1,\"id\":2508,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"266.66666666666663\",\"y1\":\"800\",\"x2\":\"133.33333333333331\",\"y2\":\"533.3333333333334\"}},{\"nodeType\":1,\"id\":2509,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"600\",\"y1\":\"800\",\"x2\":\"700\",\"y2\":\"600\"}},{\"nodeType\":1,\"id\":2510,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"200\",\"y1\":\"800\",\"x2\":\"100\",\"y2\":\"600\"}},{\"nodeType\":1,\"id\":2511,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"666.6666666666667\",\"y1\":\"800\",\"x2\":\"733.3333333333333\",\"y2\":\"666.6666666666667\"}},{\"nodeType\":1,\"id\":2512,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"133.33333333333331\",\"y1\":\"800\",\"x2\":\"66.66666666666666\",\"y2\":\"666.6666666666667\"}},{\"nodeType\":1,\"id\":2513,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"733.3333333333333\",\"y1\":\"800\",\"x2\":\"766.6666666666667\",\"y2\":\"733.3333333333334\"}},{\"nodeType\":1,\"id\":2514,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"66.66666666666666\",\"y1\":\"800\",\"x2\":\"33.33333333333333\",\"y2\":\"733.3333333333334\"}}]},{\"nodeType\":1,\"id\":2515,\"tagName\":\"g\",\"attributes\":{\"class\":\"data\"},\"childNodes\":[{\"nodeType\":1,\"id\":2516,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2517,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"333.33333333333337\",\"cy\":\"266.66666666666674\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2518,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"328.33333333333337\",\"y\":\"258.66666666666674\"},\"childNodes\":[{\"nodeType\":3,\"id\":2519,\"textContent\":\"A \"}]}]},{\"nodeType\":1,\"id\":2520,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2521,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"266.66666666666663\",\"cy\":\"600\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2522,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"261.66666666666663\",\"y\":\"592\"},\"childNodes\":[{\"nodeType\":3,\"id\":2523,\"textContent\":\"B \"}]}]},{\"nodeType\":1,\"id\":2524,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2525,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"366.66666666666663\",\"cy\":\"466.66666666666663\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2526,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"361.66666666666663\",\"y\":\"458.66666666666663\"},\"childNodes\":[{\"nodeType\":3,\"id\":2527,\"textContent\":\"C \"}]}]},{\"nodeType\":1,\"id\":2528,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2529,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"666.6666666666667\",\"cy\":\"666.6666666666667\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2530,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"661.6666666666667\",\"y\":\"658.6666666666667\"},\"childNodes\":[{\"nodeType\":3,\"id\":2531,\"textContent\":\"D \"}]}]},{\"nodeType\":1,\"id\":2532,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2533,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"200\",\"cy\":\"400\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2534,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"195\",\"y\":\"392\"},\"childNodes\":[{\"nodeType\":3,\"id\":2535,\"textContent\":\"E \"}]}]},{\"nodeType\":1,\"id\":2536,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2537,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"266.66666666666663\",\"cy\":\"533.3333333333334\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2538,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"261.66666666666663\",\"y\":\"525.3333333333334\"},\"childNodes\":[{\"nodeType\":3,\"id\":2539,\"textContent\":\"F \"}]}]},{\"nodeType\":1,\"id\":2540,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2541,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"333.33333333333337\",\"cy\":\"400\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2542,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"328.33333333333337\",\"y\":\"392\"},\"childNodes\":[{\"nodeType\":3,\"id\":2543,\"textContent\":\"G \"}]}]},{\"nodeType\":1,\"id\":2544,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2545,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"500\",\"cy\":\"466.66666666666663\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2546,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"495\",\"y\":\"458.66666666666663\"},\"childNodes\":[{\"nodeType\":3,\"id\":2547,\"textContent\":\"H \"}]}]},{\"nodeType\":1,\"id\":2548,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2549,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"100\",\"cy\":\"600\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2550,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"95\",\"y\":\"592\"},\"childNodes\":[{\"nodeType\":3,\"id\":2551,\"textContent\":\"I \"}]}]},{\"nodeType\":1,\"id\":2552,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2553,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"133.33333333333331\",\"cy\":\"666.6666666666667\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2554,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"128.33333333333331\",\"y\":\"658.6666666666667\"},\"childNodes\":[{\"nodeType\":3,\"id\":2555,\"textContent\":\"J \"}]}]},{\"nodeType\":1,\"id\":2556,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2557,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"400\",\"cy\":\"133.33333333333326\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2558,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"395\",\"y\":\"125.33333333333326\"},\"childNodes\":[{\"nodeType\":3,\"id\":2559,\"textContent\":\"K \"}]}]},{\"nodeType\":1,\"id\":2560,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2561,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"500\",\"cy\":\"333.3333333333333\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2562,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"495\",\"y\":\"325.3333333333333\"},\"childNodes\":[{\"nodeType\":3,\"id\":2563,\"textContent\":\"L \"}]}]},{\"nodeType\":1,\"id\":2564,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2565,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"300\",\"cy\":\"733.3333333333334\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2566,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"295\",\"y\":\"725.3333333333334\"},\"childNodes\":[{\"nodeType\":3,\"id\":2567,\"textContent\":\"M \"}]}]},{\"nodeType\":1,\"id\":2568,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2569,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"600\",\"cy\":\"666.6666666666667\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2570,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"595\",\"y\":\"658.6666666666667\"},\"childNodes\":[{\"nodeType\":3,\"id\":2571,\"textContent\":\"N \"}]}]},{\"nodeType\":1,\"id\":2572,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2573,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"433.3333333333333\",\"cy\":\"600\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2574,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"428.3333333333333\",\"y\":\"592\"},\"childNodes\":[{\"nodeType\":3,\"id\":2575,\"textContent\":\"O \"}]}]},{\"nodeType\":1,\"id\":2576,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2577,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"500\",\"cy\":\"200\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2578,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"495\",\"y\":\"192\"},\"childNodes\":[{\"nodeType\":3,\"id\":2579,\"textContent\":\"P \"}]}]},{\"nodeType\":1,\"id\":2580,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2581,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"533.3333333333333\",\"cy\":\"533.3333333333334\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2582,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"528.3333333333333\",\"y\":\"525.3333333333334\"},\"childNodes\":[{\"nodeType\":3,\"id\":2583,\"textContent\":\"Z \"}]}]},{\"nodeType\":1,\"id\":2584,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2585,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"400\",\"cy\":\"666.6666666666667\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2586,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"395\",\"y\":\"658.6666666666667\"},\"childNodes\":[{\"nodeType\":3,\"id\":2587,\"textContent\":\"X \"}]}]}]}]}]}]},{\"nodeType\":3,\"id\":2588,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2589,\"textContent\":\" \"},{\"nodeType\":8,\"id\":2590},{\"nodeType\":3,\"id\":2591,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2592,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":2593,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2594,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":2595,\"textContent\":\" \"}]}]}]]}",
  "useCssProxy": true,
  "loadTimes": "es: 293, dom: 931, initialDom: 1048",
  "javascriptErrors": []
}