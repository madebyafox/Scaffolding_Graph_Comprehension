var MF = MF || {};MF.RecordingData = MF.RecordingData || {};MF.RecordingData["session"] = {
  "id": "062e44a9f7d7088d80aaa8d2d063b519",
  "created": "2018-06-01T10:16:46.1447205-07:00",
  "lastActivity": "2018-06-01T10:18:02.6397205-07:00",
  "pageViews": [
    {
      "id": "0601461038d2eb7d6e82c4f6b356fe1f872a6391",
      "startTime": "2018-06-01T10:16:46.1447205-07:00",
      "endTime": "2018-06-01T10:18:02.6397205-07:00",
      "title": "FOX2YP",
      "uri": "https://warm-citadel-75324.herokuapp.com/",
      "websitePage": "/16",
      "visitTime": 76495,
      "engagementTime": 64598,
      "scroll": 100.0,
      "tags": [
        "form-interact",
        "submit"
      ],
      "friction": 0,
      "annotations": []
    }
  ],
  "duration": 76495,
  "engagementTime": 64598,
  "totalFriction": 0,
  "country": "us",
  "region": "CA",
  "city": "La Jolla",
  "isp": "University of California, San Diego",
  "ip": "128.54.68.41",
  "lang": "en-US",
  "userAgent": "Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/66.0.3359.181 Safari/537.36",
  "browser": "Chrome",
  "browserVersion": "66.0.3359.181",
  "os": "Windows",
  "osVersion": "7",
  "device": "Desktop",
  "referrer": "",
  "referrerType": "",
  "screenRes": "1920x1200",
  "tags": [
    "form-interact",
    "submit"
  ],
  "variables": [
    "SID=2OEC4",
    "CONDITION=115"
  ],
  "watched": false,
  "starred": false,
  "lng": -117.2359,
  "lat": 32.8807,
  "visitorId": "a524fe5172e628033b9f3fd62a10d529",
  "gdpr": false
}