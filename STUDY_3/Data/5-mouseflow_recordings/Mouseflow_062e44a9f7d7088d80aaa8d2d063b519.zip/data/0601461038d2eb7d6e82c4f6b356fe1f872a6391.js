var MF = MF || {};MF.RecordingData = MF.RecordingData || {};MF.RecordingData["0601461038d2eb7d6e82c4f6b356fe1f872a6391"] = {
  "startTime": "2018-06-01T17:16:46.1447205Z",
  "websitePageUrl": "/16",
  "visitTime": 76495,
  "engagementTime": 64598,
  "pageTitle": "FOX2YP",
  "url": "https://warm-citadel-75324.herokuapp.com/",
  "viewportWidth": 1920,
  "viewportHeight": 1200,
  "tags": [
    "form-interact",
    "submit"
  ],
  "session": {
    "id": "062e44a9f7d7088d80aaa8d2d063b519",
    "created": "2018-06-01T17:16:46.1447205+00:00",
    "lastActivity": "0001-01-01T00:00:00+00:00",
    "pages": 1,
    "duration": 0,
    "engagementTime": 0,
    "totalFriction": 0,
    "country": "us",
    "region": "CA",
    "city": "La Jolla",
    "isp": "University of California, San Diego",
    "ip": "###.###.###.###",
    "lang": "en-US",
    "userAgent": "Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/66.0.3359.181 Safari/537.36",
    "browser": "Chrome",
    "browserVersion": "66.0.3359.181",
    "os": "Windows",
    "osVersion": "7",
    "device": "Desktop",
    "referrer": "",
    "referrerType": "",
    "screenRes": "1920x1200",
    "entryPage": "/16",
    "tags": [
      "form-interact",
      "submit"
    ],
    "variables": [
      "SID=2OEC4",
      "CONDITION=115"
    ],
    "watched": false,
    "starred": false,
    "lng": 32.8807,
    "lat": 32.8807,
    "visitorId": "a524fe5172e628033b9f3fd62a10d529",
    "gdpr": false,
    "visitorName": null,
    "playbackUrl": "https://us.mouseflow.com/websites/e0c9ff05-6fcb-4c4a-8173-e5a0724987b1/recordings/062e44a9f7d7088d80aaa8d2d063b519/play"
  },
  "events": [
    {
      "t": 1,
      "e": 1,
      "ty": 14,
      "x": 0,
      "y": 1199
    },
    {
      "t": 100,
      "e": 100,
      "ty": 0,
      "x": 1920,
      "y": 1200
    },
    {
      "t": 678,
      "e": 678,
      "ty": 2,
      "x": 552,
      "y": 759
    },
    {
      "t": 751,
      "e": 751,
      "ty": 41,
      "x": 51135,
      "y": 41603,
      "ta": "> div.stimulus > div"
    },
    {
      "t": 800,
      "e": 800,
      "ty": 2,
      "x": 543,
      "y": 745
    },
    {
      "t": 900,
      "e": 900,
      "ty": 2,
      "x": 479,
      "y": 671
    },
    {
      "t": 1000,
      "e": 1000,
      "ty": 2,
      "x": 447,
      "y": 627
    },
    {
      "t": 1000,
      "e": 1000,
      "ty": 41,
      "x": 60107,
      "y": 3450,
      "ta": "> div.stimulus > div > div:[3]"
    },
    {
      "t": 1100,
      "e": 1100,
      "ty": 2,
      "x": 443,
      "y": 613
    },
    {
      "t": 1200,
      "e": 1200,
      "ty": 2,
      "x": 443,
      "y": 608
    },
    {
      "t": 1250,
      "e": 1250,
      "ty": 41,
      "x": 38883,
      "y": 61762,
      "ta": "#.strategy"
    },
    {
      "t": 1300,
      "e": 1300,
      "ty": 2,
      "x": 443,
      "y": 605
    },
    {
      "t": 1518,
      "e": 1518,
      "ty": 6,
      "x": 443,
      "y": 603,
      "ta": "#strategyAnswer"
    },
    {
      "t": 1599,
      "e": 1599,
      "ty": 2,
      "x": 443,
      "y": 599
    },
    {
      "t": 1700,
      "e": 1700,
      "ty": 2,
      "x": 443,
      "y": 598
    },
    {
      "t": 1750,
      "e": 1750,
      "ty": 41,
      "x": 38883,
      "y": 60895,
      "ta": "#strategyAnswer"
    },
    {
      "t": 1935,
      "e": 1935,
      "ty": 3,
      "x": 443,
      "y": 598,
      "ta": "#strategyAnswer"
    },
    {
      "t": 1935,
      "e": 1935,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 2102,
      "e": 2102,
      "ty": 4,
      "x": 38883,
      "y": 60895,
      "ta": "#strategyAnswer"
    },
    {
      "t": 2102,
      "e": 2102,
      "ty": 5,
      "x": 443,
      "y": 598,
      "ta": "#strategyAnswer"
    },
    {
      "t": 5135,
      "e": 5135,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "16"
    },
    {
      "t": 5270,
      "e": 5270,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "73"
    },
    {
      "t": 5271,
      "e": 5271,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 5342,
      "e": 5342,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "I"
    },
    {
      "t": 5350,
      "e": 5350,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "I"
    },
    {
      "t": 5414,
      "e": 5414,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 5415,
      "e": 5415,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 5502,
      "e": 5502,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "I "
    },
    {
      "t": 5606,
      "e": 5606,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "I "
    },
    {
      "t": 6534,
      "e": 6534,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "16"
    },
    {
      "t": 6695,
      "e": 6695,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "71"
    },
    {
      "t": 6695,
      "e": 6695,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 6758,
      "e": 6758,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "I G"
    },
    {
      "t": 6798,
      "e": 6798,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "I G"
    },
    {
      "t": 7022,
      "e": 7022,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 7102,
      "e": 7102,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "I "
    },
    {
      "t": 7174,
      "e": 7174,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "71"
    },
    {
      "t": 7174,
      "e": 7174,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 7254,
      "e": 7254,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "79"
    },
    {
      "t": 7254,
      "e": 7254,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 7270,
      "e": 7270,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "I go"
    },
    {
      "t": 7342,
      "e": 7342,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 7398,
      "e": 7398,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 7398,
      "e": 7398,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 7486,
      "e": 7486,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 7510,
      "e": 7510,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 7510,
      "e": 7510,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 7590,
      "e": 7590,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "79"
    },
    {
      "t": 7591,
      "e": 7591,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 7630,
      "e": 7630,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||to"
    },
    {
      "t": 7710,
      "e": 7710,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 7766,
      "e": 7766,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 7766,
      "e": 7766,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 7782,
      "e": 7782,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 7783,
      "e": 7783,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 7830,
      "e": 7830,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| t"
    },
    {
      "t": 7894,
      "e": 7894,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 7918,
      "e": 7918,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "72"
    },
    {
      "t": 7918,
      "e": 7918,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 8030,
      "e": 8030,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||h"
    },
    {
      "t": 8078,
      "e": 8078,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 8079,
      "e": 8079,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 8150,
      "e": 8150,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||e"
    },
    {
      "t": 8158,
      "e": 8158,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 8158,
      "e": 8158,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 8230,
      "e": 8230,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 8430,
      "e": 8430,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "49"
    },
    {
      "t": 8430,
      "e": 8430,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 8582,
      "e": 8582,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||1"
    },
    {
      "t": 8583,
      "e": 8583,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "50"
    },
    {
      "t": 8583,
      "e": 8583,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 8686,
      "e": 8686,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||2"
    },
    {
      "t": 8967,
      "e": 8967,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "16"
    },
    {
      "t": 9062,
      "e": 9062,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "80"
    },
    {
      "t": 9062,
      "e": 9062,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 9174,
      "e": 9174,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||P"
    },
    {
      "t": 9358,
      "e": 9358,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "77"
    },
    {
      "t": 9358,
      "e": 9358,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 9463,
      "e": 9463,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||M"
    },
    {
      "t": 9510,
      "e": 9510,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 9638,
      "e": 9638,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 9638,
      "e": 9638,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 9750,
      "e": 9750,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 9886,
      "e": 9886,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "79"
    },
    {
      "t": 9886,
      "e": 9886,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 9950,
      "e": 9950,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||o"
    },
    {
      "t": 10004,
      "e": 10004,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 10022,
      "e": 10022,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "78"
    },
    {
      "t": 10022,
      "e": 10022,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 10094,
      "e": 10094,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||n"
    },
    {
      "t": 10158,
      "e": 10158,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 10159,
      "e": 10159,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 10246,
      "e": 10246,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 10262,
      "e": 10262,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 10262,
      "e": 10262,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 10334,
      "e": 10334,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "72"
    },
    {
      "t": 10335,
      "e": 10335,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 10367,
      "e": 10367,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||th"
    },
    {
      "t": 10414,
      "e": 10414,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 10614,
      "e": 10614,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 10614,
      "e": 10614,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 10678,
      "e": 10678,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 10806,
      "e": 10806,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "I go to the 12PM on th "
    },
    {
      "t": 10958,
      "e": 10958,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 11022,
      "e": 11022,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "I go to the 12PM on th"
    },
    {
      "t": 11062,
      "e": 11062,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 11062,
      "e": 11062,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 11174,
      "e": 11174,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||e"
    },
    {
      "t": 11182,
      "e": 11182,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 11182,
      "e": 11182,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 11230,
      "e": 11230,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 11358,
      "e": 11358,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "88"
    },
    {
      "t": 11359,
      "e": 11359,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 11470,
      "e": 11470,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||x"
    },
    {
      "t": 12390,
      "e": 12390,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "189"
    },
    {
      "t": 12390,
      "e": 12390,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 12502,
      "e": 12502,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||-"
    },
    {
      "t": 12566,
      "e": 12566,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 12566,
      "e": 12566,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 12654,
      "e": 12654,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||a"
    },
    {
      "t": 12838,
      "e": 12838,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "88"
    },
    {
      "t": 12838,
      "e": 12838,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 12950,
      "e": 12950,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||x"
    },
    {
      "t": 13014,
      "e": 13014,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "73"
    },
    {
      "t": 13014,
      "e": 13014,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 13086,
      "e": 13086,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||i"
    },
    {
      "t": 13142,
      "e": 13142,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "83"
    },
    {
      "t": 13142,
      "e": 13142,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 13246,
      "e": 13246,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||s"
    },
    {
      "t": 13318,
      "e": 13318,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 13318,
      "e": 13318,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 13414,
      "e": 13414,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 13526,
      "e": 13526,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 13526,
      "e": 13526,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 13614,
      "e": 13614,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "78"
    },
    {
      "t": 13614,
      "e": 13614,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 13638,
      "e": 13638,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||an"
    },
    {
      "t": 13702,
      "e": 13702,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 13773,
      "e": 13773,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "68"
    },
    {
      "t": 13773,
      "e": 13773,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 13854,
      "e": 13854,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||d"
    },
    {
      "t": 13862,
      "e": 13862,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 13862,
      "e": 13862,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 13950,
      "e": 13950,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 14030,
      "e": 14030,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 14030,
      "e": 14030,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 14110,
      "e": 14110,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "72"
    },
    {
      "t": 14110,
      "e": 14110,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 14150,
      "e": 14150,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||th"
    },
    {
      "t": 14181,
      "e": 14181,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 14230,
      "e": 14230,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 14230,
      "e": 14230,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 14294,
      "e": 14294,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "78"
    },
    {
      "t": 14294,
      "e": 14294,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 14350,
      "e": 14350,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||en"
    },
    {
      "t": 14398,
      "e": 14398,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 14462,
      "e": 14462,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 14463,
      "e": 14463,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 14542,
      "e": 14542,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 14638,
      "e": 14638,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "83"
    },
    {
      "t": 14639,
      "e": 14639,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 14734,
      "e": 14734,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||s"
    },
    {
      "t": 14766,
      "e": 14766,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 14767,
      "e": 14767,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 14901,
      "e": 14901,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||e"
    },
    {
      "t": 15038,
      "e": 15038,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 15038,
      "e": 15038,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 15142,
      "e": 15142,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||e"
    },
    {
      "t": 15214,
      "e": 15214,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 15214,
      "e": 15214,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 15310,
      "e": 15310,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 15526,
      "e": 15526,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "73"
    },
    {
      "t": 15526,
      "e": 15526,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 15614,
      "e": 15614,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||i"
    },
    {
      "t": 15662,
      "e": 15662,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "70"
    },
    {
      "t": 15662,
      "e": 15662,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 15758,
      "e": 15758,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||f"
    },
    {
      "t": 15790,
      "e": 15790,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 15790,
      "e": 15790,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 15862,
      "e": 15862,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 15982,
      "e": 15982,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 15982,
      "e": 15982,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 16078,
      "e": 16078,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "72"
    },
    {
      "t": 16078,
      "e": 16078,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 16094,
      "e": 16094,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||th"
    },
    {
      "t": 16166,
      "e": 16166,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 16214,
      "e": 16214,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 16214,
      "e": 16214,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 16310,
      "e": 16310,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "82"
    },
    {
      "t": 16310,
      "e": 16310,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 16326,
      "e": 16326,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||er"
    },
    {
      "t": 16422,
      "e": 16422,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 16423,
      "e": 16423,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 16438,
      "e": 16438,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||e"
    },
    {
      "t": 16517,
      "e": 16517,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 16638,
      "e": 16638,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 16638,
      "e": 16638,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 16733,
      "e": 16733,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 16918,
      "e": 16918,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 16918,
      "e": 16918,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 17054,
      "e": 17054,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||a"
    },
    {
      "t": 17086,
      "e": 17086,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "82"
    },
    {
      "t": 17086,
      "e": 17086,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 17166,
      "e": 17166,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 17166,
      "e": 17166,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 17198,
      "e": 17198,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||re"
    },
    {
      "t": 17246,
      "e": 17246,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 17262,
      "e": 17262,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 17262,
      "e": 17262,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 17350,
      "e": 17350,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 17461,
      "e": 17461,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 17462,
      "e": 17462,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 17542,
      "e": 17542,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "78"
    },
    {
      "t": 17542,
      "e": 17542,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 17559,
      "e": 17543,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||an"
    },
    {
      "t": 17582,
      "e": 17566,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 17710,
      "e": 17694,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "89"
    },
    {
      "t": 17710,
      "e": 17694,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 17814,
      "e": 17798,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||y"
    },
    {
      "t": 17886,
      "e": 17870,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 17886,
      "e": 17870,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 17950,
      "e": 17934,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 18102,
      "e": 18086,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "68"
    },
    {
      "t": 18102,
      "e": 18086,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 18206,
      "e": 18190,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "I go to the 12PM on the x-axis and then see if there are any d"
    },
    {
      "t": 18206,
      "e": 18190,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||d"
    },
    {
      "t": 18254,
      "e": 18238,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "79"
    },
    {
      "t": 18254,
      "e": 18238,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 18366,
      "e": 18350,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||o"
    },
    {
      "t": 18518,
      "e": 18502,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 18518,
      "e": 18502,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 18630,
      "e": 18614,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 18878,
      "e": 18862,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "83"
    },
    {
      "t": 18879,
      "e": 18863,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 19006,
      "e": 18990,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "I go to the 12PM on the x-axis and then see if there are any dots"
    },
    {
      "t": 19006,
      "e": 18990,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||s"
    },
    {
      "t": 19150,
      "e": 19134,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 19150,
      "e": 19134,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 19230,
      "e": 19214,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 30004,
      "e": 24214,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 35941,
      "e": 24214,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "79"
    },
    {
      "t": 35942,
      "e": 24215,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 36029,
      "e": 24302,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||o"
    },
    {
      "t": 36134,
      "e": 24407,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "78"
    },
    {
      "t": 36134,
      "e": 24407,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 36213,
      "e": 24486,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||n"
    },
    {
      "t": 36317,
      "e": 24590,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 36318,
      "e": 24591,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 36390,
      "e": 24663,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 36509,
      "e": 24782,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 36510,
      "e": 24783,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 36590,
      "e": 24863,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "72"
    },
    {
      "t": 36590,
      "e": 24863,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 36614,
      "e": 24887,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||th"
    },
    {
      "t": 36678,
      "e": 24951,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 36726,
      "e": 24999,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 36726,
      "e": 24999,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 36757,
      "e": 25030,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 36757,
      "e": 25030,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 36797,
      "e": 25070,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||at"
    },
    {
      "t": 36861,
      "e": 25134,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 36861,
      "e": 25134,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 36878,
      "e": 25151,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 36949,
      "e": 25222,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 37830,
      "e": 26103,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 37909,
      "e": 26182,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "I go to the 12PM on the x-axis and then see if there are any dots on that"
    },
    {
      "t": 38038,
      "e": 26311,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 38101,
      "e": 26374,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "I go to the 12PM on the x-axis and then see if there are any dots on tha"
    },
    {
      "t": 38206,
      "e": 26479,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "I go to the 12PM on the x-axis and then see if there are any dots on tha"
    },
    {
      "t": 38214,
      "e": 26487,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 38277,
      "e": 26550,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "I go to the 12PM on the x-axis and then see if there are any dots on th"
    },
    {
      "t": 38390,
      "e": 26663,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 38454,
      "e": 26727,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "I go to the 12PM on the x-axis and then see if there are any dots on t"
    },
    {
      "t": 39165,
      "e": 27438,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "72"
    },
    {
      "t": 39165,
      "e": 27438,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 39261,
      "e": 27534,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||h"
    },
    {
      "t": 39277,
      "e": 27550,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 39278,
      "e": 27551,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 39349,
      "e": 27622,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 39349,
      "e": 27622,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 39398,
      "e": 27671,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||e "
    },
    {
      "t": 39438,
      "e": 27711,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 39614,
      "e": 27887,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "89"
    },
    {
      "t": 39615,
      "e": 27888,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 39710,
      "e": 27983,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||y"
    },
    {
      "t": 40062,
      "e": 28335,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "189"
    },
    {
      "t": 40063,
      "e": 28336,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 40182,
      "e": 28455,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||-"
    },
    {
      "t": 40342,
      "e": 28615,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 40343,
      "e": 28616,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 40430,
      "e": 28703,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||a"
    },
    {
      "t": 40582,
      "e": 28855,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "90"
    },
    {
      "t": 40583,
      "e": 28856,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 40669,
      "e": 28942,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||z"
    },
    {
      "t": 40709,
      "e": 28982,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "73"
    },
    {
      "t": 40710,
      "e": 28983,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 40774,
      "e": 29047,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||i"
    },
    {
      "t": 40838,
      "e": 29111,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "83"
    },
    {
      "t": 40839,
      "e": 29112,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 40951,
      "e": 29224,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||s"
    },
    {
      "t": 41118,
      "e": 29391,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 41182,
      "e": 29455,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "I go to the 12PM on the x-axis and then see if there are any dots on the y-azi"
    },
    {
      "t": 41270,
      "e": 29543,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 41333,
      "e": 29606,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "I go to the 12PM on the x-axis and then see if there are any dots on the y-az"
    },
    {
      "t": 41422,
      "e": 29695,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 41494,
      "e": 29696,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "I go to the 12PM on the x-axis and then see if there are any dots on the y-a"
    },
    {
      "t": 41605,
      "e": 29807,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "I go to the 12PM on the x-axis and then see if there are any dots on the y-a"
    },
    {
      "t": 41630,
      "e": 29832,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "88"
    },
    {
      "t": 41630,
      "e": 29832,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 41734,
      "e": 29936,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||x"
    },
    {
      "t": 41790,
      "e": 29992,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "73"
    },
    {
      "t": 41791,
      "e": 29993,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 41869,
      "e": 30071,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||i"
    },
    {
      "t": 41950,
      "e": 30152,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "83"
    },
    {
      "t": 41950,
      "e": 30152,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 42054,
      "e": 30256,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||s"
    },
    {
      "t": 42966,
      "e": 31168,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 42967,
      "e": 31169,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 43053,
      "e": 31255,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 43582,
      "e": 31784,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "67"
    },
    {
      "t": 43583,
      "e": 31785,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 43677,
      "e": 31879,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||c"
    },
    {
      "t": 43798,
      "e": 32000,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 43799,
      "e": 32001,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 43870,
      "e": 32072,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||e"
    },
    {
      "t": 43901,
      "e": 32103,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "78"
    },
    {
      "t": 43901,
      "e": 32103,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 43974,
      "e": 32176,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||n"
    },
    {
      "t": 44029,
      "e": 32231,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 44029,
      "e": 32231,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 44125,
      "e": 32327,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 44198,
      "e": 32400,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 44198,
      "e": 32400,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 44285,
      "e": 32487,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "82"
    },
    {
      "t": 44285,
      "e": 32487,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 44325,
      "e": 32527,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||er"
    },
    {
      "t": 44430,
      "e": 32632,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 44430,
      "e": 32632,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 44445,
      "e": 32647,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||e"
    },
    {
      "t": 44518,
      "e": 32720,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 44614,
      "e": 32816,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "68"
    },
    {
      "t": 44615,
      "e": 32817,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 44718,
      "e": 32920,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||d"
    },
    {
      "t": 44734,
      "e": 32936,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 44734,
      "e": 32936,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 44821,
      "e": 33023,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 44846,
      "e": 33048,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 44846,
      "e": 33048,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 44934,
      "e": 33136,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||a"
    },
    {
      "t": 44990,
      "e": 33192,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 44992,
      "e": 33194,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 45085,
      "e": 33287,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 45109,
      "e": 33311,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 45109,
      "e": 33311,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 45198,
      "e": 33400,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 46078,
      "e": 34280,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "49"
    },
    {
      "t": 46078,
      "e": 34280,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 46205,
      "e": 34407,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "50"
    },
    {
      "t": 46206,
      "e": 34408,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 46214,
      "e": 34416,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||12"
    },
    {
      "t": 46310,
      "e": 34512,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 46510,
      "e": 34712,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "16"
    },
    {
      "t": 46622,
      "e": 34824,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "80"
    },
    {
      "t": 46623,
      "e": 34825,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 46701,
      "e": 34903,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||P"
    },
    {
      "t": 46806,
      "e": 35008,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "77"
    },
    {
      "t": 46806,
      "e": 35008,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 46902,
      "e": 35104,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||M"
    },
    {
      "t": 46909,
      "e": 35111,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 47904,
      "e": 36106,
      "ty": 2,
      "x": 441,
      "y": 598
    },
    {
      "t": 47908,
      "e": 36110,
      "ty": 7,
      "x": 438,
      "y": 605,
      "ta": "#strategyAnswer"
    },
    {
      "t": 48005,
      "e": 36207,
      "ty": 2,
      "x": 424,
      "y": 632
    },
    {
      "t": 48005,
      "e": 36207,
      "ty": 41,
      "x": 49341,
      "y": 6727,
      "ta": "> div.stimulus > div > div:[3]"
    },
    {
      "t": 48630,
      "e": 36832,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "190"
    },
    {
      "t": 48631,
      "e": 36833,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 48765,
      "e": 36967,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||."
    },
    {
      "t": 48892,
      "e": 37094,
      "ty": 6,
      "x": 412,
      "y": 654,
      "ta": "#strategyButton"
    },
    {
      "t": 48905,
      "e": 37107,
      "ty": 2,
      "x": 412,
      "y": 654
    },
    {
      "t": 49005,
      "e": 37207,
      "ty": 2,
      "x": 403,
      "y": 674
    },
    {
      "t": 49005,
      "e": 37207,
      "ty": 41,
      "x": 35173,
      "y": 37134,
      "ta": "#strategyButton"
    },
    {
      "t": 49043,
      "e": 37245,
      "ty": 3,
      "x": 403,
      "y": 674,
      "ta": "#strategyButton"
    },
    {
      "t": 49044,
      "e": 37246,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "I go to the 12PM on the x-axis and then see if there are any dots on the y-axis centered at 12PM."
    },
    {
      "t": 49045,
      "e": 37247,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 49046,
      "e": 37248,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#strategyButton"
    },
    {
      "t": 49185,
      "e": 37387,
      "ty": 4,
      "x": 35173,
      "y": 37134,
      "ta": "#strategyButton"
    },
    {
      "t": 49200,
      "e": 37402,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#strategyButton"
    },
    {
      "t": 49201,
      "e": 37403,
      "ty": 5,
      "x": 403,
      "y": 674,
      "ta": "#strategyButton"
    },
    {
      "t": 49206,
      "e": 37408,
      "ty": 38,
      "x": 1,
      "y": 0
    },
    {
      "t": 49404,
      "e": 37606,
      "ty": 2,
      "x": 402,
      "y": 683
    },
    {
      "t": 49504,
      "e": 37706,
      "ty": 2,
      "x": 396,
      "y": 737
    },
    {
      "t": 49505,
      "e": 37707,
      "ty": 41,
      "x": 13361,
      "y": 40384,
      "ta": "html > body"
    },
    {
      "t": 50004,
      "e": 38206,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 50208,
      "e": 38410,
      "ty": 38,
      "x": 2,
      "y": 0
    },
    {
      "t": 50255,
      "e": 38457,
      "ty": 41,
      "x": 13637,
      "y": 40993,
      "ta": "html > body"
    },
    {
      "t": 50305,
      "e": 38507,
      "ty": 2,
      "x": 412,
      "y": 759
    },
    {
      "t": 50505,
      "e": 38707,
      "ty": 41,
      "x": 13912,
      "y": 41603,
      "ta": "html > body"
    },
    {
      "t": 50755,
      "e": 38957,
      "ty": 41,
      "x": 13912,
      "y": 41714,
      "ta": "html > body"
    },
    {
      "t": 50804,
      "e": 39006,
      "ty": 2,
      "x": 430,
      "y": 760
    },
    {
      "t": 50905,
      "e": 39107,
      "ty": 2,
      "x": 460,
      "y": 756
    },
    {
      "t": 51004,
      "e": 39206,
      "ty": 2,
      "x": 468,
      "y": 752
    },
    {
      "t": 51005,
      "e": 39207,
      "ty": 41,
      "x": 15841,
      "y": 41215,
      "ta": "html > body"
    },
    {
      "t": 51105,
      "e": 39307,
      "ty": 2,
      "x": 780,
      "y": 634
    },
    {
      "t": 51205,
      "e": 39407,
      "ty": 2,
      "x": 896,
      "y": 590
    },
    {
      "t": 51255,
      "e": 39457,
      "ty": 41,
      "x": 19249,
      "y": 4932,
      "ta": "#jspsych-survey-text-1"
    },
    {
      "t": 51305,
      "e": 39507,
      "ty": 2,
      "x": 897,
      "y": 590
    },
    {
      "t": 51377,
      "e": 39579,
      "ty": 6,
      "x": 908,
      "y": 572,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 51404,
      "e": 39606,
      "ty": 2,
      "x": 909,
      "y": 570
    },
    {
      "t": 51442,
      "e": 39644,
      "ty": 3,
      "x": 909,
      "y": 569,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 51444,
      "e": 39646,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 51504,
      "e": 39706,
      "ty": 2,
      "x": 909,
      "y": 569
    },
    {
      "t": 51505,
      "e": 39707,
      "ty": 41,
      "x": 21845,
      "y": 46810,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 51569,
      "e": 39771,
      "ty": 4,
      "x": 21845,
      "y": 46810,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 51569,
      "e": 39771,
      "ty": 5,
      "x": 909,
      "y": 569,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 52518,
      "e": 40720,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "50"
    },
    {
      "t": 52518,
      "e": 40720,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 52685,
      "e": 40887,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "2"
    },
    {
      "t": 52830,
      "e": 41032,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "48"
    },
    {
      "t": 52831,
      "e": 41033,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 52893,
      "e": 41095,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "20"
    },
    {
      "t": 53005,
      "e": 41207,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "20"
    },
    {
      "t": 53486,
      "e": 41688,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "9"
    },
    {
      "t": 53487,
      "e": 41689,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "20"
    },
    {
      "t": 53487,
      "e": 41689,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 53489,
      "e": 41691,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 53565,
      "e": 41767,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": ""
    },
    {
      "t": 57263,
      "e": 45465,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "16"
    },
    {
      "t": 57350,
      "e": 45552,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "80"
    },
    {
      "t": 57351,
      "e": 45553,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 57485,
      "e": 45687,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "P"
    },
    {
      "t": 57485,
      "e": 45687,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "P"
    },
    {
      "t": 57637,
      "e": 45839,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "65"
    },
    {
      "t": 57638,
      "e": 45840,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 57741,
      "e": 45943,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "Pa"
    },
    {
      "t": 57797,
      "e": 45999,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "78"
    },
    {
      "t": 57797,
      "e": 45999,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 57869,
      "e": 46071,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "Pan"
    },
    {
      "t": 57918,
      "e": 46120,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "65"
    },
    {
      "t": 57918,
      "e": 46120,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 58021,
      "e": 46223,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "Pana"
    },
    {
      "t": 58853,
      "e": 47055,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "77"
    },
    {
      "t": 58854,
      "e": 47056,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 58909,
      "e": 47111,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "+||m"
    },
    {
      "t": 58940,
      "e": 47142,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "65"
    },
    {
      "t": 58941,
      "e": 47143,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 59029,
      "e": 47231,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "+||a"
    },
    {
      "t": 59504,
      "e": 47706,
      "ty": 2,
      "x": 911,
      "y": 570
    },
    {
      "t": 59505,
      "e": 47707,
      "ty": 41,
      "x": 22277,
      "y": 49931,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 59506,
      "e": 47708,
      "ty": 7,
      "x": 917,
      "y": 580,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 59604,
      "e": 47806,
      "ty": 2,
      "x": 937,
      "y": 641
    },
    {
      "t": 59650,
      "e": 47852,
      "ty": 6,
      "x": 940,
      "y": 647,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 59704,
      "e": 47906,
      "ty": 2,
      "x": 941,
      "y": 648
    },
    {
      "t": 59754,
      "e": 47956,
      "ty": 41,
      "x": 29415,
      "y": 49931,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 59767,
      "e": 47969,
      "ty": 7,
      "x": 945,
      "y": 672,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 59784,
      "e": 47986,
      "ty": 6,
      "x": 946,
      "y": 680,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 59804,
      "e": 48006,
      "ty": 2,
      "x": 946,
      "y": 687
    },
    {
      "t": 59904,
      "e": 48106,
      "ty": 2,
      "x": 946,
      "y": 695
    },
    {
      "t": 59947,
      "e": 48149,
      "ty": 3,
      "x": 946,
      "y": 695,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 59947,
      "e": 48149,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "Panama"
    },
    {
      "t": 59948,
      "e": 48150,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 59949,
      "e": 48151,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 60004,
      "e": 48206,
      "ty": 41,
      "x": 25809,
      "y": 37732,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 60004,
      "e": 48206,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 60073,
      "e": 48275,
      "ty": 4,
      "x": 25809,
      "y": 37732,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 60074,
      "e": 48276,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 60074,
      "e": 48276,
      "ty": 5,
      "x": 946,
      "y": 695,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 60074,
      "e": 48276,
      "ty": 38,
      "x": 3,
      "y": 0
    },
    {
      "t": 60254,
      "e": 48456,
      "ty": 41,
      "x": 32302,
      "y": 38501,
      "ta": "html > body"
    },
    {
      "t": 60304,
      "e": 48506,
      "ty": 2,
      "x": 924,
      "y": 724
    },
    {
      "t": 60404,
      "e": 48606,
      "ty": 2,
      "x": 905,
      "y": 726
    },
    {
      "t": 60504,
      "e": 48706,
      "ty": 41,
      "x": 30890,
      "y": 39775,
      "ta": "html > body"
    },
    {
      "t": 61099,
      "e": 49301,
      "ty": 38,
      "x": 4,
      "y": 0
    },
    {
      "t": 61904,
      "e": 50106,
      "ty": 2,
      "x": 907,
      "y": 659
    },
    {
      "t": 62004,
      "e": 50206,
      "ty": 2,
      "x": 790,
      "y": 360
    },
    {
      "t": 62004,
      "e": 50206,
      "ty": 41,
      "x": 26930,
      "y": 19499,
      "ta": "html > body"
    },
    {
      "t": 62104,
      "e": 50306,
      "ty": 2,
      "x": 783,
      "y": 331
    },
    {
      "t": 62204,
      "e": 50406,
      "ty": 2,
      "x": 820,
      "y": 282
    },
    {
      "t": 62258,
      "e": 50460,
      "ty": 41,
      "x": 5771,
      "y": 62258,
      "ta": "#jspsych-survey-multi-choice-option-0-1 > label"
    },
    {
      "t": 62308,
      "e": 50510,
      "ty": 2,
      "x": 832,
      "y": 276
    },
    {
      "t": 62509,
      "e": 50711,
      "ty": 2,
      "x": 834,
      "y": 274
    },
    {
      "t": 62509,
      "e": 50711,
      "ty": 41,
      "x": 9579,
      "y": 55704,
      "ta": "#jspsych-survey-multi-choice-option-0-1 > label"
    },
    {
      "t": 62525,
      "e": 50727,
      "ty": 6,
      "x": 834,
      "y": 271,
      "ta": "jspsych-survey-multi-choice-response-0[1]_mf"
    },
    {
      "t": 62609,
      "e": 50811,
      "ty": 2,
      "x": 834,
      "y": 261
    },
    {
      "t": 62692,
      "e": 50894,
      "ty": 7,
      "x": 834,
      "y": 258,
      "ta": "jspsych-survey-multi-choice-response-0[1]_mf"
    },
    {
      "t": 62710,
      "e": 50912,
      "ty": 2,
      "x": 834,
      "y": 256
    },
    {
      "t": 62759,
      "e": 50961,
      "ty": 41,
      "x": 2985,
      "y": 4681,
      "ta": "#jspsych-survey-multi-choice-option-0-1"
    },
    {
      "t": 62809,
      "e": 51011,
      "ty": 2,
      "x": 834,
      "y": 253
    },
    {
      "t": 62908,
      "e": 51110,
      "ty": 2,
      "x": 834,
      "y": 250
    },
    {
      "t": 63008,
      "e": 51210,
      "ty": 41,
      "x": 2985,
      "y": 58513,
      "ta": "#jspsych-survey-multi-choice-option-0-0"
    },
    {
      "t": 63074,
      "e": 51276,
      "ty": 6,
      "x": 837,
      "y": 262,
      "ta": "jspsych-survey-multi-choice-response-0[1]_mf"
    },
    {
      "t": 63109,
      "e": 51311,
      "ty": 2,
      "x": 838,
      "y": 267
    },
    {
      "t": 63141,
      "e": 51343,
      "ty": 7,
      "x": 838,
      "y": 273,
      "ta": "jspsych-survey-multi-choice-response-0[1]_mf"
    },
    {
      "t": 63208,
      "e": 51410,
      "ty": 2,
      "x": 840,
      "y": 292
    },
    {
      "t": 63259,
      "e": 51461,
      "ty": 41,
      "x": 5822,
      "y": 42597,
      "ta": "#jspsych-survey-multi-choice-option-0-2 > label"
    },
    {
      "t": 63308,
      "e": 51510,
      "ty": 2,
      "x": 840,
      "y": 306
    },
    {
      "t": 63409,
      "e": 51611,
      "ty": 2,
      "x": 840,
      "y": 318
    },
    {
      "t": 63509,
      "e": 51711,
      "ty": 2,
      "x": 840,
      "y": 321
    },
    {
      "t": 63509,
      "e": 51711,
      "ty": 41,
      "x": 18442,
      "y": 26214,
      "ta": "#jspsych-survey-multi-choice-option-0-3 > label"
    },
    {
      "t": 63534,
      "e": 51736,
      "ty": 3,
      "x": 840,
      "y": 321,
      "ta": "#jspsych-survey-multi-choice-option-0-3 > label"
    },
    {
      "t": 63670,
      "e": 51872,
      "ty": 4,
      "x": 18442,
      "y": 26214,
      "ta": "#jspsych-survey-multi-choice-option-0-3 > label"
    },
    {
      "t": 63670,
      "e": 51872,
      "ty": 5,
      "x": 840,
      "y": 321,
      "ta": "#jspsych-survey-multi-choice-option-0-3 > label"
    },
    {
      "t": 63671,
      "e": 51873,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-0[3]_mf"
    },
    {
      "t": 63674,
      "e": 51876,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-0[3]_mf",
      "v": "Other"
    },
    {
      "t": 63822,
      "e": 52024,
      "ty": 6,
      "x": 838,
      "y": 322,
      "ta": "jspsych-survey-multi-choice-response-0[3]_mf"
    },
    {
      "t": 63909,
      "e": 52111,
      "ty": 2,
      "x": 837,
      "y": 322
    },
    {
      "t": 64009,
      "e": 52211,
      "ty": 7,
      "x": 834,
      "y": 329,
      "ta": "jspsych-survey-multi-choice-response-0[3]_mf"
    },
    {
      "t": 64009,
      "e": 52211,
      "ty": 2,
      "x": 834,
      "y": 329
    },
    {
      "t": 64009,
      "e": 52211,
      "ty": 41,
      "x": 12486,
      "y": 52428,
      "ta": "#jspsych-survey-multi-choice-option-0-3 > label"
    },
    {
      "t": 64109,
      "e": 52311,
      "ty": 2,
      "x": 814,
      "y": 334
    },
    {
      "t": 64259,
      "e": 52461,
      "ty": 41,
      "x": 27756,
      "y": 18059,
      "ta": "html > body"
    },
    {
      "t": 64909,
      "e": 53111,
      "ty": 2,
      "x": 830,
      "y": 364
    },
    {
      "t": 65008,
      "e": 53210,
      "ty": 2,
      "x": 847,
      "y": 422
    },
    {
      "t": 65008,
      "e": 53210,
      "ty": 41,
      "x": 29941,
      "y": 55704,
      "ta": "#jspsych-survey-multi-choice-option-1-0 > label"
    },
    {
      "t": 65108,
      "e": 53310,
      "ty": 2,
      "x": 860,
      "y": 463
    },
    {
      "t": 65209,
      "e": 53411,
      "ty": 2,
      "x": 859,
      "y": 473
    },
    {
      "t": 65259,
      "e": 53412,
      "ty": 41,
      "x": 39720,
      "y": 58981,
      "ta": "#jspsych-survey-multi-choice-option-1-2 > label"
    },
    {
      "t": 65309,
      "e": 53462,
      "ty": 2,
      "x": 859,
      "y": 479
    },
    {
      "t": 65408,
      "e": 53561,
      "ty": 2,
      "x": 856,
      "y": 473
    },
    {
      "t": 65508,
      "e": 53661,
      "ty": 2,
      "x": 845,
      "y": 457
    },
    {
      "t": 65509,
      "e": 53662,
      "ty": 41,
      "x": 5595,
      "y": 0,
      "ta": "#jspsych-survey-multi-choice-option-1-2"
    },
    {
      "t": 65593,
      "e": 53746,
      "ty": 6,
      "x": 833,
      "y": 447,
      "ta": "jspsych-survey-multi-choice-response-1[1]_mf"
    },
    {
      "t": 65608,
      "e": 53761,
      "ty": 2,
      "x": 833,
      "y": 447
    },
    {
      "t": 65759,
      "e": 53912,
      "ty": 41,
      "x": 33161,
      "y": 55452,
      "ta": "jspsych-survey-multi-choice-response-1[1]_mf"
    },
    {
      "t": 65798,
      "e": 53951,
      "ty": 3,
      "x": 833,
      "y": 447,
      "ta": "jspsych-survey-multi-choice-response-1[1]_mf"
    },
    {
      "t": 65799,
      "e": 53952,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-0[3]_mf"
    },
    {
      "t": 65800,
      "e": 53953,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-1[1]_mf"
    },
    {
      "t": 65901,
      "e": 54054,
      "ty": 4,
      "x": 33161,
      "y": 55452,
      "ta": "jspsych-survey-multi-choice-response-1[1]_mf"
    },
    {
      "t": 65901,
      "e": 54054,
      "ty": 5,
      "x": 833,
      "y": 447,
      "ta": "jspsych-survey-multi-choice-response-1[1]_mf"
    },
    {
      "t": 65902,
      "e": 54055,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-1[1]_mf",
      "v": "Second"
    },
    {
      "t": 66009,
      "e": 54162,
      "ty": 2,
      "x": 832,
      "y": 447
    },
    {
      "t": 66009,
      "e": 54162,
      "ty": 41,
      "x": 28120,
      "y": 55452,
      "ta": "jspsych-survey-multi-choice-response-1[1]_mf"
    },
    {
      "t": 66027,
      "e": 54180,
      "ty": 7,
      "x": 831,
      "y": 452,
      "ta": "jspsych-survey-multi-choice-response-1[1]_mf"
    },
    {
      "t": 66060,
      "e": 54213,
      "ty": 6,
      "x": 831,
      "y": 475,
      "ta": "jspsych-survey-multi-choice-response-1[2]_mf"
    },
    {
      "t": 66076,
      "e": 54229,
      "ty": 7,
      "x": 833,
      "y": 488,
      "ta": "jspsych-survey-multi-choice-response-1[2]_mf"
    },
    {
      "t": 66094,
      "e": 54247,
      "ty": 6,
      "x": 838,
      "y": 499,
      "ta": "jspsych-survey-multi-choice-response-1[3]_mf"
    },
    {
      "t": 66108,
      "e": 54261,
      "ty": 2,
      "x": 838,
      "y": 499
    },
    {
      "t": 66110,
      "e": 54263,
      "ty": 7,
      "x": 844,
      "y": 508,
      "ta": "jspsych-survey-multi-choice-response-1[3]_mf"
    },
    {
      "t": 66208,
      "e": 54361,
      "ty": 2,
      "x": 895,
      "y": 556
    },
    {
      "t": 66259,
      "e": 54412,
      "ty": 41,
      "x": 18411,
      "y": 7021,
      "ta": "#jspsych-survey-multi-choice-option-1-6"
    },
    {
      "t": 66309,
      "e": 54462,
      "ty": 2,
      "x": 901,
      "y": 586
    },
    {
      "t": 66408,
      "e": 54561,
      "ty": 2,
      "x": 902,
      "y": 592
    },
    {
      "t": 66509,
      "e": 54662,
      "ty": 41,
      "x": 19123,
      "y": 53832,
      "ta": "#jspsych-survey-multi-choice-option-1-6"
    },
    {
      "t": 66709,
      "e": 54862,
      "ty": 2,
      "x": 903,
      "y": 591
    },
    {
      "t": 66758,
      "e": 54911,
      "ty": 41,
      "x": 18648,
      "y": 51491,
      "ta": "#jspsych-survey-multi-choice-option-1-6"
    },
    {
      "t": 66808,
      "e": 54961,
      "ty": 2,
      "x": 900,
      "y": 591
    },
    {
      "t": 66808,
      "e": 54961,
      "ty": 1,
      "x": 0,
      "y": 1
    },
    {
      "t": 66908,
      "e": 55061,
      "ty": 2,
      "x": 910,
      "y": 601
    },
    {
      "t": 66908,
      "e": 55061,
      "ty": 1,
      "x": 0,
      "y": 14
    },
    {
      "t": 67009,
      "e": 55162,
      "ty": 2,
      "x": 924,
      "y": 601
    },
    {
      "t": 67009,
      "e": 55162,
      "ty": 1,
      "x": 0,
      "y": 16
    },
    {
      "t": 67009,
      "e": 55162,
      "ty": 41,
      "x": 24344,
      "y": 32879,
      "ta": "#jspsych-survey-multi-choice-form"
    },
    {
      "t": 67108,
      "e": 55261,
      "ty": 2,
      "x": 930,
      "y": 601
    },
    {
      "t": 67209,
      "e": 55362,
      "ty": 2,
      "x": 931,
      "y": 631
    },
    {
      "t": 67259,
      "e": 55412,
      "ty": 41,
      "x": 23157,
      "y": 9478,
      "ta": "#jspsych-survey-multi-choice-2"
    },
    {
      "t": 67309,
      "e": 55462,
      "ty": 2,
      "x": 909,
      "y": 659
    },
    {
      "t": 67409,
      "e": 55562,
      "ty": 2,
      "x": 880,
      "y": 681
    },
    {
      "t": 67509,
      "e": 55662,
      "ty": 2,
      "x": 858,
      "y": 695
    },
    {
      "t": 67509,
      "e": 55662,
      "ty": 41,
      "x": 9217,
      "y": 6553,
      "ta": "#jspsych-survey-multi-choice-option-2-1 > label"
    },
    {
      "t": 67595,
      "e": 55748,
      "ty": 6,
      "x": 839,
      "y": 706,
      "ta": "jspsych-survey-multi-choice-response-2[1]_mf"
    },
    {
      "t": 67609,
      "e": 55762,
      "ty": 2,
      "x": 839,
      "y": 706
    },
    {
      "t": 67708,
      "e": 55861,
      "ty": 2,
      "x": 831,
      "y": 698
    },
    {
      "t": 67711,
      "e": 55864,
      "ty": 7,
      "x": 829,
      "y": 693,
      "ta": "jspsych-survey-multi-choice-response-2[1]_mf"
    },
    {
      "t": 67759,
      "e": 55912,
      "ty": 41,
      "x": 1798,
      "y": 0,
      "ta": "#jspsych-survey-multi-choice-option-2-1"
    },
    {
      "t": 67810,
      "e": 55914,
      "ty": 2,
      "x": 829,
      "y": 685
    },
    {
      "t": 67861,
      "e": 55965,
      "ty": 6,
      "x": 828,
      "y": 680,
      "ta": "jspsych-survey-multi-choice-response-2[0]_mf"
    },
    {
      "t": 67909,
      "e": 56013,
      "ty": 2,
      "x": 828,
      "y": 679
    },
    {
      "t": 68009,
      "e": 56113,
      "ty": 2,
      "x": 828,
      "y": 677
    },
    {
      "t": 68009,
      "e": 56113,
      "ty": 41,
      "x": 7955,
      "y": 45370,
      "ta": "jspsych-survey-multi-choice-response-2[0]_mf"
    },
    {
      "t": 68023,
      "e": 56127,
      "ty": 3,
      "x": 829,
      "y": 675,
      "ta": "jspsych-survey-multi-choice-response-2[0]_mf"
    },
    {
      "t": 68023,
      "e": 56127,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-1[1]_mf"
    },
    {
      "t": 68024,
      "e": 56128,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-2[0]_mf"
    },
    {
      "t": 68109,
      "e": 56213,
      "ty": 2,
      "x": 831,
      "y": 675
    },
    {
      "t": 68158,
      "e": 56262,
      "ty": 4,
      "x": 23079,
      "y": 35288,
      "ta": "jspsych-survey-multi-choice-response-2[0]_mf"
    },
    {
      "t": 68159,
      "e": 56263,
      "ty": 5,
      "x": 831,
      "y": 675,
      "ta": "jspsych-survey-multi-choice-response-2[0]_mf"
    },
    {
      "t": 68159,
      "e": 56263,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-2[0]_mf",
      "v": "Math or Computer Sciences"
    },
    {
      "t": 68259,
      "e": 56363,
      "ty": 41,
      "x": 23079,
      "y": 35288,
      "ta": "jspsych-survey-multi-choice-response-2[0]_mf"
    },
    {
      "t": 68382,
      "e": 56486,
      "ty": 7,
      "x": 832,
      "y": 682,
      "ta": "jspsych-survey-multi-choice-response-2[0]_mf"
    },
    {
      "t": 68408,
      "e": 56512,
      "ty": 2,
      "x": 833,
      "y": 685
    },
    {
      "t": 68428,
      "e": 56532,
      "ty": 6,
      "x": 837,
      "y": 706,
      "ta": "jspsych-survey-multi-choice-response-2[1]_mf"
    },
    {
      "t": 68444,
      "e": 56548,
      "ty": 7,
      "x": 841,
      "y": 721,
      "ta": "jspsych-survey-multi-choice-response-2[1]_mf"
    },
    {
      "t": 68508,
      "e": 56612,
      "ty": 2,
      "x": 848,
      "y": 753
    },
    {
      "t": 68509,
      "e": 56613,
      "ty": 41,
      "x": 11089,
      "y": 13107,
      "ta": "#jspsych-survey-multi-choice-option-2-3 > label"
    },
    {
      "t": 68608,
      "e": 56712,
      "ty": 2,
      "x": 844,
      "y": 772
    },
    {
      "t": 68759,
      "e": 56863,
      "ty": 41,
      "x": 5358,
      "y": 63194,
      "ta": "#jspsych-survey-multi-choice-option-2-3"
    },
    {
      "t": 69008,
      "e": 57112,
      "ty": 2,
      "x": 843,
      "y": 785
    },
    {
      "t": 69009,
      "e": 57113,
      "ty": 41,
      "x": 12080,
      "y": 26214,
      "ta": "#jspsych-survey-multi-choice-option-2-4 > label"
    },
    {
      "t": 69109,
      "e": 57213,
      "ty": 2,
      "x": 844,
      "y": 824
    },
    {
      "t": 69209,
      "e": 57313,
      "ty": 2,
      "x": 839,
      "y": 865
    },
    {
      "t": 69259,
      "e": 57363,
      "ty": 41,
      "x": 3934,
      "y": 18724,
      "ta": "#jspsych-survey-multi-choice-3 > p"
    },
    {
      "t": 69308,
      "e": 57412,
      "ty": 2,
      "x": 837,
      "y": 897
    },
    {
      "t": 69409,
      "e": 57513,
      "ty": 2,
      "x": 833,
      "y": 921
    },
    {
      "t": 69469,
      "e": 57573,
      "ty": 6,
      "x": 833,
      "y": 929,
      "ta": "jspsych-survey-multi-choice-response-3[0]_mf"
    },
    {
      "t": 69509,
      "e": 57613,
      "ty": 2,
      "x": 833,
      "y": 929
    },
    {
      "t": 69509,
      "e": 57613,
      "ty": 41,
      "x": 33161,
      "y": 5041,
      "ta": "jspsych-survey-multi-choice-response-3[0]_mf"
    },
    {
      "t": 69609,
      "e": 57713,
      "ty": 2,
      "x": 833,
      "y": 933
    },
    {
      "t": 69742,
      "e": 57846,
      "ty": 3,
      "x": 833,
      "y": 933,
      "ta": "jspsych-survey-multi-choice-response-3[0]_mf"
    },
    {
      "t": 69743,
      "e": 57847,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-2[0]_mf"
    },
    {
      "t": 69744,
      "e": 57848,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-3[0]_mf"
    },
    {
      "t": 69759,
      "e": 57863,
      "ty": 41,
      "x": 33161,
      "y": 25205,
      "ta": "jspsych-survey-multi-choice-response-3[0]_mf"
    },
    {
      "t": 69821,
      "e": 57925,
      "ty": 4,
      "x": 33161,
      "y": 25205,
      "ta": "jspsych-survey-multi-choice-response-3[0]_mf"
    },
    {
      "t": 69821,
      "e": 57925,
      "ty": 5,
      "x": 833,
      "y": 933,
      "ta": "jspsych-survey-multi-choice-response-3[0]_mf"
    },
    {
      "t": 69822,
      "e": 57926,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-3[0]_mf",
      "v": "Male"
    },
    {
      "t": 69863,
      "e": 57967,
      "ty": 7,
      "x": 834,
      "y": 941,
      "ta": "jspsych-survey-multi-choice-response-3[0]_mf"
    },
    {
      "t": 69909,
      "e": 58013,
      "ty": 2,
      "x": 839,
      "y": 955
    },
    {
      "t": 70009,
      "e": 58113,
      "ty": 2,
      "x": 853,
      "y": 991
    },
    {
      "t": 70009,
      "e": 58113,
      "ty": 41,
      "x": 31348,
      "y": 32767,
      "ta": "#jspsych-survey-multi-choice-option-3-2 > label"
    },
    {
      "t": 70096,
      "e": 58200,
      "ty": 6,
      "x": 858,
      "y": 1005,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 70108,
      "e": 58212,
      "ty": 2,
      "x": 858,
      "y": 1005
    },
    {
      "t": 70208,
      "e": 58312,
      "ty": 2,
      "x": 861,
      "y": 1009
    },
    {
      "t": 70259,
      "e": 58363,
      "ty": 41,
      "x": 16790,
      "y": 7943,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 70308,
      "e": 58412,
      "ty": 2,
      "x": 862,
      "y": 1009
    },
    {
      "t": 70374,
      "e": 58478,
      "ty": 3,
      "x": 862,
      "y": 1009,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 70375,
      "e": 58479,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-3[0]_mf"
    },
    {
      "t": 70376,
      "e": 58480,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 70509,
      "e": 58613,
      "ty": 4,
      "x": 16790,
      "y": 7943,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 70510,
      "e": 58614,
      "ty": 5,
      "x": 862,
      "y": 1009,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 70513,
      "e": 58617,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 70513,
      "e": 58617,
      "ty": 13,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-multi-choice-form"
    },
    {
      "t": 70515,
      "e": 58619,
      "ty": 38,
      "x": 5,
      "y": 0
    },
    {
      "t": 71902,
      "e": 60006,
      "ty": 38,
      "x": 6,
      "y": 0
    },
    {
      "t": 71909,
      "e": 60013,
      "ty": 2,
      "x": 866,
      "y": 1010
    },
    {
      "t": 72008,
      "e": 60112,
      "ty": 2,
      "x": 840,
      "y": 810
    },
    {
      "t": 72009,
      "e": 60112,
      "ty": 41,
      "x": 26888,
      "y": 13476,
      "ta": "> div.masterdiv > div:[2] > div > p:[5]"
    },
    {
      "t": 72109,
      "e": 60212,
      "ty": 2,
      "x": 807,
      "y": 769
    },
    {
      "t": 72259,
      "e": 60362,
      "ty": 41,
      "x": 25264,
      "y": 58815,
      "ta": "> div.masterdiv > div:[2] > div > p:[4]"
    },
    {
      "t": 72409,
      "e": 60512,
      "ty": 2,
      "x": 807,
      "y": 758
    },
    {
      "t": 72509,
      "e": 60612,
      "ty": 2,
      "x": 804,
      "y": 655
    },
    {
      "t": 72510,
      "e": 60613,
      "ty": 41,
      "x": 25117,
      "y": 37111,
      "ta": "> div.masterdiv > div:[2] > div"
    },
    {
      "t": 72609,
      "e": 60712,
      "ty": 2,
      "x": 700,
      "y": 589
    },
    {
      "t": 72708,
      "e": 60811,
      "ty": 2,
      "x": 695,
      "y": 588
    },
    {
      "t": 72759,
      "e": 60862,
      "ty": 41,
      "x": 19754,
      "y": 41160,
      "ta": "> div.masterdiv > div:[2] > div > p:[3]"
    },
    {
      "t": 73009,
      "e": 61112,
      "ty": 2,
      "x": 750,
      "y": 682
    },
    {
      "t": 73009,
      "e": 61112,
      "ty": 41,
      "x": 22460,
      "y": 7908,
      "ta": "> div.masterdiv > div:[2] > div > p:[4]"
    },
    {
      "t": 73108,
      "e": 61211,
      "ty": 2,
      "x": 813,
      "y": 749
    },
    {
      "t": 73209,
      "e": 61312,
      "ty": 2,
      "x": 872,
      "y": 889
    },
    {
      "t": 73259,
      "e": 61362,
      "ty": 41,
      "x": 29741,
      "y": 56208,
      "ta": "> div.masterdiv > div:[2]"
    },
    {
      "t": 73309,
      "e": 61412,
      "ty": 2,
      "x": 913,
      "y": 967
    },
    {
      "t": 73409,
      "e": 61512,
      "ty": 2,
      "x": 928,
      "y": 1002
    },
    {
      "t": 73509,
      "e": 61612,
      "ty": 2,
      "x": 969,
      "y": 1055
    },
    {
      "t": 73509,
      "e": 61612,
      "ty": 41,
      "x": 33234,
      "y": 64310,
      "ta": "> div.masterdiv > div:[2]"
    },
    {
      "t": 73533,
      "e": 61636,
      "ty": 6,
      "x": 1005,
      "y": 1075,
      "ta": "#start"
    },
    {
      "t": 73609,
      "e": 61712,
      "ty": 2,
      "x": 1028,
      "y": 1092
    },
    {
      "t": 73617,
      "e": 61720,
      "ty": 7,
      "x": 1032,
      "y": 1098,
      "ta": "#start"
    },
    {
      "t": 73708,
      "e": 61811,
      "ty": 2,
      "x": 1039,
      "y": 1110
    },
    {
      "t": 73759,
      "e": 61862,
      "ty": 41,
      "x": 35505,
      "y": 61103,
      "ta": "> div.masterdiv"
    },
    {
      "t": 73809,
      "e": 61912,
      "ty": 2,
      "x": 1026,
      "y": 1108
    },
    {
      "t": 73832,
      "e": 61935,
      "ty": 6,
      "x": 1013,
      "y": 1105,
      "ta": "#start"
    },
    {
      "t": 73909,
      "e": 62012,
      "ty": 2,
      "x": 997,
      "y": 1100
    },
    {
      "t": 74008,
      "e": 62111,
      "ty": 2,
      "x": 990,
      "y": 1095
    },
    {
      "t": 74010,
      "e": 62113,
      "ty": 41,
      "x": 43963,
      "y": 43007,
      "ta": "#start"
    },
    {
      "t": 74109,
      "e": 62212,
      "ty": 2,
      "x": 987,
      "y": 1090
    },
    {
      "t": 74158,
      "e": 62261,
      "ty": 3,
      "x": 987,
      "y": 1090,
      "ta": "#start"
    },
    {
      "t": 74159,
      "e": 62262,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#start"
    },
    {
      "t": 74258,
      "e": 62361,
      "ty": 41,
      "x": 42324,
      "y": 33369,
      "ta": "#start"
    },
    {
      "t": 74277,
      "e": 62380,
      "ty": 4,
      "x": 42324,
      "y": 33369,
      "ta": "#start"
    },
    {
      "t": 74278,
      "e": 62381,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#start"
    },
    {
      "t": 74279,
      "e": 62382,
      "ty": 5,
      "x": 987,
      "y": 1090,
      "ta": "#start"
    },
    {
      "t": 74279,
      "e": 62382,
      "ty": 38,
      "x": 7,
      "y": 0
    },
    {
      "t": 75304,
      "e": 63407,
      "ty": 38,
      "x": 8,
      "y": 0
    },
    {
      "t": 75841,
      "e": 63944,
      "ty": 2,
      "x": 986,
      "y": 1090
    },
    {
      "t": 75841,
      "e": 63944,
      "ty": 41,
      "x": 34334,
      "y": 32920,
      "ta": "#jspsych-data-display"
    },
    {
      "t": 76009,
      "e": 64112,
      "ty": 2,
      "x": 981,
      "y": 1085
    },
    {
      "t": 76009,
      "e": 64112,
      "ty": 41,
      "x": 34038,
      "y": 32919,
      "ta": "#jspsych-data-display"
    },
    {
      "t": 76109,
      "e": 64212,
      "ty": 2,
      "x": 971,
      "y": 1078
    },
    {
      "t": 76209,
      "e": 64312,
      "ty": 2,
      "x": 934,
      "y": 1061
    },
    {
      "t": 76259,
      "e": 64362,
      "ty": 41,
      "x": 30018,
      "y": 32908,
      "ta": "#jspsych-data-display"
    },
    {
      "t": 76308,
      "e": 64411,
      "ty": 2,
      "x": 899,
      "y": 1044
    },
    {
      "t": 76408,
      "e": 64511,
      "ty": 2,
      "x": 876,
      "y": 1028
    },
    {
      "t": 76495,
      "e": 64598,
      "ty": 20,
      "x": 0,
      "y": 0
    }
  ],
  "domMutations": [
    {
      "sequence": 1,
      "data": "{\"f\":\"applyChanged\",\"args\":[[{\"id\":56},{\"id\":57},{\"id\":58},{\"id\":59},{\"id\":60},{\"id\":61},{\"id\":62},{\"id\":63},{\"id\":64},{\"id\":65},{\"id\":66},{\"id\":67},{\"id\":68},{\"id\":69},{\"id\":70},{\"id\":71},{\"id\":72},{\"id\":73},{\"id\":74},{\"id\":75},{\"id\":76},{\"id\":77},{\"id\":78},{\"id\":79},{\"id\":80},{\"id\":81},{\"id\":82},{\"id\":83},{\"id\":84},{\"id\":85},{\"id\":86},{\"id\":87},{\"id\":88},{\"id\":89},{\"id\":90},{\"id\":91},{\"id\":92},{\"id\":93},{\"id\":94},{\"id\":95},{\"id\":96},{\"id\":97},{\"id\":98},{\"id\":99},{\"id\":100},{\"id\":101},{\"id\":102},{\"id\":103},{\"id\":104},{\"id\":105},{\"id\":106},{\"id\":107},{\"id\":108},{\"id\":109},{\"id\":110},{\"id\":111},{\"id\":112},{\"id\":113},{\"id\":114},{\"id\":115},{\"id\":116},{\"id\":117},{\"id\":118},{\"id\":119},{\"id\":120},{\"id\":121},{\"id\":122},{\"id\":123},{\"id\":124},{\"id\":125},{\"id\":126},{\"id\":127},{\"id\":128},{\"id\":129},{\"id\":130},{\"id\":131},{\"id\":132},{\"id\":133},{\"id\":134},{\"id\":135},{\"id\":136},{\"id\":137},{\"id\":138},{\"id\":139},{\"id\":140},{\"id\":141},{\"id\":142},{\"id\":143},{\"id\":144},{\"id\":145},{\"id\":146},{\"id\":147},{\"id\":148},{\"id\":149},{\"id\":150},{\"id\":151},{\"id\":152},{\"id\":153},{\"id\":154},{\"id\":155},{\"id\":156},{\"id\":157},{\"id\":158},{\"id\":159},{\"id\":160},{\"id\":161},{\"id\":162},{\"id\":163},{\"id\":164},{\"id\":165},{\"id\":166},{\"id\":167},{\"id\":168},{\"id\":169},{\"id\":170},{\"id\":171},{\"id\":172},{\"id\":173},{\"id\":174},{\"id\":175},{\"id\":176},{\"id\":177},{\"id\":178},{\"id\":179},{\"id\":180},{\"id\":181},{\"id\":182},{\"id\":183},{\"id\":184},{\"id\":185},{\"id\":186},{\"id\":187},{\"id\":188},{\"id\":189},{\"id\":190},{\"id\":191},{\"id\":192},{\"id\":193},{\"id\":194},{\"id\":195},{\"id\":196},{\"id\":197},{\"id\":198},{\"id\":199},{\"id\":200},{\"id\":201},{\"id\":202},{\"id\":203},{\"id\":204},{\"id\":205},{\"id\":206},{\"id\":207},{\"id\":208},{\"id\":209},{\"id\":210},{\"id\":211},{\"id\":212},{\"id\":213},{\"id\":214},{\"id\":215},{\"id\":216},{\"id\":217},{\"id\":218},{\"id\":219},{\"id\":220},{\"id\":221},{\"id\":222},{\"id\":223},{\"id\":224},{\"id\":225},{\"id\":226},{\"id\":227},{\"id\":228},{\"id\":229},{\"id\":230},{\"id\":231},{\"id\":232},{\"id\":233},{\"id\":234},{\"id\":235},{\"id\":236},{\"id\":237},{\"id\":238},{\"id\":239},{\"id\":240},{\"id\":241},{\"id\":242},{\"id\":243},{\"id\":244},{\"id\":245},{\"id\":246},{\"id\":247},{\"id\":248},{\"id\":249},{\"id\":250},{\"id\":251},{\"id\":252},{\"id\":253},{\"id\":254},{\"id\":255},{\"id\":256},{\"id\":257},{\"id\":258},{\"id\":259},{\"id\":260},{\"id\":261},{\"id\":262},{\"id\":263},{\"id\":264},{\"id\":265},{\"id\":266},{\"id\":267},{\"id\":268},{\"id\":269},{\"id\":270},{\"id\":271},{\"id\":272},{\"id\":273},{\"id\":274},{\"id\":275},{\"id\":276},{\"id\":277},{\"id\":278},{\"id\":279},{\"id\":280},{\"id\":281},{\"id\":282},{\"id\":283},{\"id\":284},{\"id\":285},{\"id\":286},{\"id\":287},{\"id\":288},{\"id\":289},{\"id\":290},{\"id\":291},{\"id\":292},{\"id\":293},{\"id\":294},{\"id\":295},{\"id\":296},{\"id\":297},{\"id\":298},{\"id\":299},{\"id\":300},{\"id\":301},{\"id\":302},{\"id\":303},{\"id\":304},{\"id\":305},{\"id\":306},{\"id\":307},{\"id\":308},{\"id\":309},{\"id\":310},{\"id\":311},{\"id\":312},{\"id\":313},{\"id\":314},{\"id\":315},{\"id\":316},{\"id\":317},{\"id\":318},{\"id\":319},{\"id\":320},{\"id\":321},{\"id\":322},{\"id\":323},{\"id\":324},{\"id\":325},{\"id\":326},{\"id\":327},{\"id\":328},{\"id\":329},{\"id\":330},{\"id\":331},{\"id\":332},{\"id\":333},{\"id\":334},{\"id\":335},{\"id\":336},{\"id\":337},{\"id\":338},{\"id\":339},{\"id\":340},{\"id\":341},{\"id\":342},{\"id\":343},{\"id\":344},{\"id\":345},{\"id\":346},{\"id\":347},{\"id\":348},{\"id\":349},{\"id\":350},{\"id\":351},{\"id\":352},{\"id\":353},{\"id\":354},{\"id\":355},{\"id\":356},{\"id\":357},{\"id\":358},{\"id\":359},{\"id\":360},{\"id\":361},{\"id\":362},{\"id\":363},{\"id\":364},{\"id\":365},{\"id\":366},{\"id\":367},{\"id\":368},{\"id\":369},{\"id\":370},{\"id\":371},{\"id\":372},{\"id\":373},{\"id\":374},{\"id\":375},{\"id\":376},{\"id\":377},{\"id\":378},{\"id\":379},{\"id\":380},{\"id\":381},{\"id\":382},{\"id\":383},{\"id\":384},{\"id\":385},{\"id\":386},{\"id\":387},{\"id\":388},{\"id\":389},{\"id\":390},{\"id\":391},{\"id\":392},{\"id\":393},{\"id\":394},{\"id\":395},{\"id\":396},{\"id\":397},{\"id\":398},{\"id\":399},{\"id\":400},{\"id\":401},{\"id\":402},{\"id\":403},{\"id\":404},{\"id\":405},{\"id\":406},{\"id\":407},{\"id\":408},{\"id\":409},{\"id\":410},{\"id\":411},{\"id\":412},{\"id\":413},{\"id\":414},{\"id\":415},{\"id\":416},{\"id\":417},{\"id\":418},{\"id\":419},{\"id\":420},{\"id\":421},{\"id\":422},{\"id\":423},{\"id\":424},{\"id\":425},{\"id\":426},{\"id\":427},{\"id\":428},{\"id\":429},{\"id\":430},{\"id\":431},{\"id\":432},{\"id\":433},{\"id\":434},{\"id\":435},{\"id\":436},{\"id\":437},{\"id\":438},{\"id\":439},{\"id\":440},{\"id\":441},{\"id\":442},{\"id\":443},{\"id\":444},{\"id\":445},{\"id\":446},{\"id\":447},{\"id\":448},{\"id\":449},{\"id\":450},{\"id\":451},{\"id\":452},{\"id\":453},{\"id\":454},{\"id\":455},{\"id\":456},{\"id\":457},{\"id\":458},{\"id\":459},{\"id\":460},{\"id\":461},{\"id\":462},{\"id\":463},{\"id\":464},{\"id\":465},{\"id\":466},{\"id\":467},{\"id\":468},{\"id\":469},{\"id\":470},{\"id\":471},{\"id\":472},{\"id\":473},{\"id\":474},{\"id\":475},{\"id\":476},{\"id\":477},{\"id\":478},{\"id\":479},{\"id\":480},{\"id\":481},{\"id\":482},{\"id\":483},{\"id\":484},{\"id\":485},{\"id\":486},{\"id\":487},{\"id\":488},{\"id\":489},{\"id\":490},{\"id\":491},{\"id\":492},{\"id\":493},{\"id\":494},{\"id\":495},{\"id\":496},{\"id\":497},{\"id\":498},{\"id\":499},{\"id\":500},{\"id\":501},{\"id\":502},{\"id\":503},{\"id\":504},{\"id\":505},{\"id\":506},{\"id\":507},{\"id\":508},{\"id\":509},{\"id\":510},{\"id\":511},{\"id\":512},{\"id\":513},{\"id\":514},{\"id\":515},{\"id\":516},{\"id\":517},{\"id\":518},{\"id\":519},{\"id\":520},{\"id\":521},{\"id\":522},{\"id\":523},{\"id\":524},{\"id\":525},{\"id\":526},{\"id\":527},{\"id\":528},{\"id\":529},{\"id\":530},{\"id\":531},{\"id\":532},{\"id\":533},{\"id\":534},{\"id\":535},{\"id\":536},{\"id\":537},{\"id\":538},{\"id\":539},{\"id\":540},{\"id\":541},{\"id\":542},{\"id\":543},{\"id\":544},{\"id\":545},{\"id\":546},{\"id\":547},{\"id\":548},{\"id\":549},{\"id\":550},{\"id\":551},{\"id\":552},{\"id\":553},{\"id\":554},{\"id\":555},{\"id\":556},{\"id\":557},{\"id\":558},{\"id\":559},{\"id\":560},{\"id\":561},{\"id\":562},{\"id\":563},{\"id\":564},{\"id\":565},{\"id\":566},{\"id\":567},{\"id\":568},{\"id\":569},{\"id\":570},{\"id\":571},{\"id\":572},{\"id\":573},{\"id\":574},{\"id\":575},{\"id\":576},{\"id\":577},{\"id\":578},{\"id\":579},{\"id\":580},{\"id\":581},{\"id\":582},{\"id\":583},{\"id\":584},{\"id\":585},{\"id\":586},{\"id\":587},{\"id\":588},{\"id\":589},{\"id\":590},{\"id\":591},{\"id\":592},{\"id\":593},{\"id\":594},{\"id\":595},{\"id\":596},{\"id\":597},{\"id\":598},{\"id\":599},{\"id\":600},{\"id\":601},{\"id\":602},{\"id\":603},{\"id\":604},{\"id\":605},{\"id\":606},{\"id\":607},{\"id\":608},{\"id\":609},{\"id\":610},{\"id\":611},{\"id\":612},{\"id\":613},{\"id\":614},{\"id\":615},{\"id\":616},{\"id\":617},{\"id\":618},{\"id\":619},{\"id\":620},{\"id\":621},{\"id\":622},{\"id\":623},{\"id\":624},{\"id\":625},{\"id\":626},{\"id\":627},{\"id\":628},{\"id\":629},{\"id\":630},{\"id\":631},{\"id\":632},{\"id\":633},{\"id\":634},{\"id\":635},{\"id\":636},{\"id\":637},{\"id\":638},{\"id\":639},{\"id\":640},{\"id\":641},{\"id\":642},{\"id\":643},{\"id\":644},{\"id\":645},{\"id\":646},{\"id\":647},{\"id\":648},{\"id\":649},{\"id\":650},{\"id\":651},{\"id\":652},{\"id\":653},{\"id\":654},{\"id\":655},{\"id\":656},{\"id\":657},{\"id\":658},{\"id\":659},{\"id\":660},{\"id\":661},{\"id\":662},{\"id\":663},{\"id\":664},{\"id\":665},{\"id\":666},{\"id\":667},{\"id\":668},{\"id\":669},{\"id\":670},{\"id\":671},{\"id\":672},{\"id\":673},{\"id\":674},{\"id\":675},{\"id\":676},{\"id\":677},{\"id\":678},{\"id\":679},{\"id\":680},{\"id\":681},{\"id\":682},{\"id\":683},{\"id\":684},{\"id\":685},{\"id\":686},{\"id\":687},{\"id\":688},{\"id\":689},{\"id\":690},{\"id\":691},{\"id\":692},{\"id\":693},{\"id\":694},{\"id\":695},{\"id\":696},{\"id\":697},{\"id\":698},{\"id\":699},{\"id\":700},{\"id\":701},{\"id\":702},{\"id\":703},{\"id\":704},{\"id\":705},{\"id\":706},{\"id\":707},{\"id\":708},{\"id\":709},{\"id\":710},{\"id\":711},{\"id\":712},{\"id\":713},{\"id\":714},{\"id\":715},{\"id\":716},{\"id\":717},{\"id\":718},{\"id\":719},{\"id\":720},{\"id\":721},{\"id\":722},{\"id\":723},{\"id\":724},{\"id\":725},{\"id\":726},{\"id\":727},{\"id\":728},{\"id\":729},{\"id\":730},{\"id\":731},{\"id\":732},{\"id\":733},{\"id\":734},{\"id\":735},{\"id\":736},{\"id\":737},{\"id\":738},{\"id\":739},{\"id\":740},{\"id\":741},{\"id\":742},{\"id\":743},{\"id\":744},{\"id\":745},{\"id\":746},{\"id\":747},{\"id\":748},{\"id\":749},{\"id\":750},{\"id\":751},{\"id\":752},{\"id\":753},{\"id\":754},{\"id\":755},{\"id\":756},{\"id\":757},{\"id\":758},{\"id\":759},{\"id\":760},{\"id\":761},{\"id\":762},{\"id\":763},{\"id\":764},{\"id\":765},{\"id\":766},{\"id\":767},{\"id\":768},{\"id\":769},{\"id\":770},{\"id\":771},{\"id\":772},{\"id\":773},{\"id\":774},{\"id\":775},{\"id\":776},{\"id\":777},{\"id\":778},{\"id\":779},{\"id\":780},{\"id\":781},{\"id\":782},{\"id\":783},{\"id\":784},{\"id\":785},{\"id\":786},{\"id\":787},{\"id\":788},{\"id\":789},{\"id\":790},{\"id\":791},{\"id\":792},{\"id\":793},{\"id\":794},{\"id\":795},{\"id\":796},{\"id\":797},{\"id\":798},{\"id\":799},{\"id\":800},{\"id\":801},{\"id\":802},{\"id\":803},{\"id\":804},{\"id\":805},{\"id\":806},{\"id\":807},{\"id\":808},{\"id\":809},{\"id\":810},{\"id\":811},{\"id\":812},{\"id\":813},{\"id\":814},{\"id\":815},{\"id\":816},{\"id\":817},{\"id\":818},{\"id\":819},{\"id\":820},{\"id\":821},{\"id\":822},{\"id\":823},{\"id\":824},{\"id\":825},{\"id\":826},{\"id\":827},{\"id\":828},{\"id\":829},{\"id\":830},{\"id\":831},{\"id\":832},{\"id\":833},{\"id\":834},{\"id\":835},{\"id\":836},{\"id\":837},{\"id\":838},{\"id\":839},{\"id\":840},{\"id\":841},{\"id\":842},{\"id\":843},{\"id\":844},{\"id\":845},{\"id\":846},{\"id\":847},{\"id\":848},{\"id\":849},{\"id\":850},{\"id\":851},{\"id\":852},{\"id\":853},{\"id\":854},{\"id\":855},{\"id\":856},{\"id\":857},{\"id\":858},{\"id\":859},{\"id\":860},{\"id\":861},{\"id\":862},{\"id\":863},{\"id\":864},{\"id\":865},{\"id\":866},{\"id\":867},{\"id\":868},{\"id\":869},{\"id\":870},{\"id\":871},{\"id\":872},{\"id\":873},{\"id\":874},{\"id\":875},{\"id\":876},{\"id\":877},{\"id\":878},{\"id\":879},{\"id\":880},{\"id\":881},{\"id\":882},{\"id\":883},{\"id\":884},{\"id\":885},{\"id\":886},{\"id\":887},{\"id\":888},{\"id\":889},{\"id\":890},{\"id\":891},{\"id\":892},{\"id\":893},{\"id\":894},{\"id\":895},{\"id\":896},{\"id\":897},{\"id\":898},{\"id\":899},{\"id\":900},{\"id\":901},{\"id\":902},{\"id\":903},{\"id\":904},{\"id\":905},{\"id\":906},{\"id\":907},{\"id\":908},{\"id\":909},{\"id\":910},{\"id\":911},{\"id\":912},{\"id\":913},{\"id\":914},{\"id\":915},{\"id\":916},{\"id\":917},{\"id\":918},{\"id\":919},{\"id\":920},{\"id\":921},{\"id\":922},{\"id\":923},{\"id\":924},{\"id\":925},{\"id\":926},{\"id\":927},{\"id\":928},{\"id\":929},{\"id\":930},{\"id\":931},{\"id\":932},{\"id\":933},{\"id\":934},{\"id\":935},{\"id\":936},{\"id\":937},{\"id\":938},{\"id\":939},{\"id\":940},{\"id\":941},{\"id\":942},{\"id\":943},{\"id\":944},{\"id\":945},{\"id\":946},{\"id\":947},{\"id\":948},{\"id\":949},{\"id\":950},{\"id\":951},{\"id\":952},{\"id\":953},{\"id\":954},{\"id\":955},{\"id\":956},{\"id\":957},{\"id\":958},{\"id\":959},{\"id\":960},{\"id\":961},{\"id\":962},{\"id\":963},{\"id\":964},{\"id\":965},{\"id\":966},{\"id\":967},{\"id\":968},{\"id\":969},{\"id\":970},{\"id\":971},{\"id\":972},{\"id\":973},{\"id\":974},{\"id\":975},{\"id\":976},{\"id\":977},{\"id\":978},{\"id\":979},{\"id\":980},{\"id\":981},{\"id\":982},{\"id\":983},{\"id\":984},{\"id\":985},{\"id\":986},{\"id\":987},{\"id\":988},{\"id\":989},{\"id\":990},{\"id\":991},{\"id\":992},{\"id\":993},{\"id\":994},{\"id\":995},{\"id\":996},{\"id\":997},{\"id\":998},{\"id\":999},{\"id\":1000},{\"id\":1001},{\"id\":1002},{\"id\":1003},{\"id\":1004},{\"id\":1005},{\"id\":1006},{\"id\":1007},{\"id\":1008},{\"id\":1009},{\"id\":1010},{\"id\":1011},{\"id\":1012},{\"id\":1013},{\"id\":1014},{\"id\":1015},{\"id\":1016},{\"id\":1017},{\"id\":1018},{\"id\":1019},{\"id\":1020},{\"id\":1021},{\"id\":1022},{\"id\":1023},{\"id\":1024},{\"id\":1025},{\"id\":1026},{\"id\":1027},{\"id\":1028},{\"id\":1029},{\"id\":1030},{\"id\":1031},{\"id\":1032},{\"id\":1033},{\"id\":1034},{\"id\":1035},{\"id\":1036},{\"id\":1037},{\"id\":1038},{\"id\":1039},{\"id\":1040},{\"id\":1041},{\"id\":1042},{\"id\":1043},{\"id\":1044},{\"id\":1045},{\"id\":1046},{\"id\":1047},{\"id\":1048},{\"id\":1049},{\"id\":1050},{\"id\":1051},{\"id\":1052},{\"id\":1053},{\"id\":1054},{\"id\":1055},{\"id\":1056},{\"id\":1057},{\"id\":1058},{\"id\":1059},{\"id\":1060},{\"id\":1061},{\"id\":1062},{\"id\":1063},{\"id\":1064},{\"id\":1065},{\"id\":1066},{\"id\":1067},{\"id\":1068},{\"id\":1069},{\"id\":1070},{\"id\":1071},{\"id\":1072},{\"id\":1073},{\"id\":1074},{\"id\":1075},{\"id\":1076},{\"id\":1077},{\"id\":1078},{\"id\":1079},{\"id\":1080},{\"id\":1081},{\"id\":1082},{\"id\":1083},{\"id\":1084},{\"id\":1085},{\"id\":1086},{\"id\":1087},{\"id\":1088},{\"id\":1089},{\"id\":1090},{\"id\":1091},{\"id\":1092},{\"id\":1093},{\"id\":1094},{\"id\":1095},{\"id\":1096},{\"id\":1097},{\"id\":1098},{\"id\":1099},{\"id\":1100},{\"id\":1101},{\"id\":1102},{\"id\":1103},{\"id\":1104},{\"id\":1105},{\"id\":1106},{\"id\":1107},{\"id\":1108},{\"id\":1109},{\"id\":1110},{\"id\":1111},{\"id\":1112},{\"id\":1113},{\"id\":1114},{\"id\":1115},{\"id\":1116},{\"id\":1117},{\"id\":1118},{\"id\":1119},{\"id\":1120},{\"id\":1121},{\"id\":1122},{\"id\":1123},{\"id\":1124},{\"id\":1125},{\"id\":1126},{\"id\":1127},{\"id\":1128},{\"id\":1129},{\"id\":1130},{\"id\":1131},{\"id\":1132},{\"id\":1133},{\"id\":1134},{\"id\":1135},{\"id\":1136},{\"id\":1137},{\"id\":1138},{\"id\":1139},{\"id\":1140},{\"id\":1141},{\"id\":1142},{\"id\":1143},{\"id\":1144},{\"id\":1145},{\"id\":1146},{\"id\":1147},{\"id\":1148},{\"id\":1149},{\"id\":1150},{\"id\":1151},{\"id\":1152},{\"id\":1153},{\"id\":1154},{\"id\":1155},{\"id\":1156},{\"id\":1157},{\"id\":1158},{\"id\":1159},{\"id\":1160},{\"id\":1161},{\"id\":1162},{\"id\":1163},{\"id\":1164},{\"id\":1165},{\"id\":1166},{\"id\":1167},{\"id\":1168},{\"id\":1169},{\"id\":1170},{\"id\":1171},{\"id\":1172},{\"id\":1173},{\"id\":1174},{\"id\":1175},{\"id\":1176},{\"id\":1177},{\"id\":1178},{\"id\":1179},{\"id\":1180},{\"id\":1181},{\"id\":1182},{\"id\":1183},{\"id\":1184},{\"id\":1185},{\"id\":1186},{\"id\":1187},{\"id\":1188},{\"id\":1189},{\"id\":1190},{\"id\":1191},{\"id\":1192},{\"id\":1193},{\"id\":1194},{\"id\":1195},{\"id\":1196},{\"id\":1197},{\"id\":1198},{\"id\":1199},{\"id\":1200},{\"id\":1201},{\"id\":1202},{\"id\":1203},{\"id\":1204},{\"id\":1205},{\"id\":1206},{\"id\":1207},{\"id\":1208},{\"id\":1209},{\"id\":1210},{\"id\":1211},{\"id\":1212},{\"id\":1213},{\"id\":1214},{\"id\":1215},{\"id\":1216},{\"id\":1217},{\"id\":1218},{\"id\":1219},{\"id\":1220},{\"id\":1221},{\"id\":1222},{\"id\":1223},{\"id\":1224},{\"id\":1225},{\"id\":1226},{\"id\":1227},{\"id\":1228},{\"id\":1229},{\"id\":1230},{\"id\":1231},{\"id\":1232},{\"id\":1233},{\"id\":1234},{\"id\":1235},{\"id\":1236},{\"id\":1237},{\"id\":1238},{\"id\":1239},{\"id\":1240},{\"id\":1241},{\"id\":1242},{\"id\":1243},{\"id\":1244},{\"id\":1245},{\"id\":1246},{\"id\":1247},{\"id\":1248},{\"id\":1249},{\"id\":1250},{\"id\":1251},{\"id\":1252},{\"id\":1253},{\"id\":1254},{\"id\":1255},{\"id\":1256},{\"id\":1257},{\"id\":1258},{\"id\":1259},{\"id\":1260},{\"id\":1261},{\"id\":1262},{\"id\":1263},{\"id\":1264},{\"id\":1265},{\"id\":1266},{\"id\":1267},{\"id\":1268},{\"id\":1269},{\"id\":1270},{\"id\":1271},{\"id\":1272},{\"id\":1273},{\"id\":1274},{\"id\":1275},{\"id\":1276},{\"id\":1277},{\"id\":1278},{\"id\":1279},{\"id\":1280},{\"id\":1281},{\"id\":1282},{\"id\":1283},{\"id\":1284},{\"id\":1285},{\"id\":1286},{\"id\":1287},{\"id\":1288},{\"id\":1289},{\"id\":1290},{\"id\":1291},{\"id\":1292},{\"id\":1293},{\"id\":1294},{\"id\":1295},{\"id\":1296},{\"id\":1297},{\"id\":1298},{\"id\":1299},{\"id\":1300},{\"id\":1301},{\"id\":1302},{\"id\":1303},{\"id\":1304},{\"id\":1305},{\"id\":1306},{\"id\":1307},{\"id\":1308},{\"id\":1309},{\"id\":1310},{\"id\":1311},{\"id\":1312},{\"id\":1313},{\"id\":1314},{\"id\":1315},{\"id\":1316},{\"id\":1317},{\"id\":1318},{\"id\":1319},{\"id\":1320},{\"id\":1321},{\"id\":1322},{\"id\":1323},{\"id\":1324},{\"id\":1325},{\"id\":1326},{\"id\":1327},{\"id\":1328},{\"id\":1329},{\"id\":1330},{\"id\":1331},{\"id\":1332},{\"id\":1333},{\"id\":1334},{\"id\":1335},{\"id\":1336},{\"id\":1337},{\"id\":1338},{\"id\":1339},{\"id\":1340},{\"id\":1341},{\"id\":1342},{\"id\":1343},{\"id\":1344},{\"id\":1345},{\"id\":1346},{\"id\":1347},{\"id\":1348},{\"id\":1349},{\"id\":1350},{\"id\":1351},{\"id\":1352},{\"id\":1353},{\"id\":1354},{\"id\":1355},{\"id\":1356},{\"id\":1357},{\"id\":1358},{\"id\":1359},{\"id\":1360},{\"id\":1361},{\"id\":1362},{\"id\":1363},{\"id\":1364},{\"id\":1365},{\"id\":1366},{\"id\":1367},{\"id\":1368},{\"id\":1369},{\"id\":1370},{\"id\":1371},{\"id\":1372},{\"id\":1373},{\"id\":1374},{\"id\":1375},{\"id\":1376},{\"id\":1377},{\"id\":1378},{\"id\":1379},{\"id\":1380},{\"id\":1381},{\"id\":1382},{\"id\":1383},{\"id\":1384},{\"id\":1385},{\"id\":1386},{\"id\":1387},{\"id\":1388},{\"id\":1389},{\"id\":1390},{\"id\":1391},{\"id\":1392},{\"id\":1393},{\"id\":1394},{\"id\":1395},{\"id\":1396},{\"id\":1397},{\"id\":1398},{\"id\":1399},{\"id\":1400},{\"id\":1401},{\"id\":1402},{\"id\":1403},{\"id\":1404},{\"id\":1405},{\"id\":1406},{\"id\":1407},{\"id\":1408},{\"id\":1409},{\"id\":1410},{\"id\":1411},{\"id\":1412},{\"id\":1413},{\"id\":1414},{\"id\":1415},{\"id\":1416},{\"id\":1417},{\"id\":1418},{\"id\":1419},{\"id\":1420},{\"id\":1421},{\"id\":1422},{\"id\":1423},{\"id\":1424},{\"id\":1425},{\"id\":1426},{\"id\":1427},{\"id\":1428},{\"id\":1429},{\"id\":1430},{\"id\":1431},{\"id\":1432},{\"id\":1433},{\"id\":1434},{\"id\":1435},{\"id\":1436},{\"id\":1437},{\"id\":1438},{\"id\":1439},{\"id\":1440},{\"id\":1441},{\"id\":1442},{\"id\":1443},{\"id\":1444},{\"id\":1445},{\"id\":1446},{\"id\":1447},{\"id\":1448},{\"id\":1449},{\"id\":1450},{\"id\":1451},{\"id\":1452},{\"id\":1453},{\"id\":1454},{\"id\":1455},{\"id\":1456},{\"id\":1457},{\"id\":1458},{\"id\":1459},{\"id\":1460},{\"id\":1461},{\"id\":1462},{\"id\":1463},{\"id\":1464},{\"id\":1465},{\"id\":1466},{\"id\":1467},{\"id\":1468},{\"id\":1469},{\"id\":1470},{\"id\":1471},{\"id\":1472},{\"id\":1473},{\"id\":1474},{\"id\":1475},{\"id\":1476},{\"id\":1477},{\"id\":1478},{\"id\":1479},{\"id\":1480},{\"id\":1481},{\"id\":1482},{\"id\":1483},{\"id\":1484},{\"id\":1485},{\"id\":1486},{\"id\":1487},{\"id\":1488},{\"id\":1489},{\"id\":1490},{\"id\":1491},{\"id\":1492},{\"id\":1493},{\"id\":1494},{\"id\":1495},{\"id\":1496},{\"id\":1497},{\"id\":1498},{\"id\":1499},{\"id\":1500},{\"id\":1501},{\"id\":1502},{\"id\":1503},{\"id\":1504},{\"id\":1505},{\"id\":1506},{\"id\":1507},{\"id\":1508},{\"id\":1509},{\"id\":1510},{\"id\":1511},{\"id\":1512},{\"id\":1513},{\"id\":1514},{\"id\":1515},{\"id\":1516},{\"id\":1517},{\"id\":1518},{\"id\":1519},{\"id\":1520},{\"id\":1521},{\"id\":1522},{\"id\":1523},{\"id\":1524},{\"id\":1525},{\"id\":1526},{\"id\":1527},{\"id\":1528},{\"id\":1529},{\"id\":1530},{\"id\":1531},{\"id\":1532},{\"id\":1533},{\"id\":1534},{\"id\":1535},{\"id\":1536},{\"id\":1537},{\"id\":1538},{\"id\":1539},{\"id\":1540},{\"id\":1541},{\"id\":1542},{\"id\":1543},{\"id\":1544},{\"id\":1545},{\"id\":1546},{\"id\":1547},{\"id\":1548},{\"id\":1549},{\"id\":1550},{\"id\":1551},{\"id\":1552},{\"id\":1553},{\"id\":1554},{\"id\":1555},{\"id\":1556},{\"id\":1557},{\"id\":1558},{\"id\":1559},{\"id\":1560},{\"id\":1561},{\"id\":1562},{\"id\":1563},{\"id\":1564},{\"id\":1565},{\"id\":1566},{\"id\":1567},{\"id\":1568},{\"id\":1569},{\"id\":1570},{\"id\":1571},{\"id\":1572},{\"id\":1573},{\"id\":1574},{\"id\":1575},{\"id\":1576},{\"id\":1577},{\"id\":1578},{\"id\":1579},{\"id\":1580},{\"id\":1581},{\"id\":1582},{\"id\":1583},{\"id\":1584},{\"id\":1585},{\"id\":1586},{\"id\":1587},{\"id\":1588},{\"id\":1589},{\"id\":1590},{\"id\":1591},{\"id\":1592},{\"id\":1593},{\"id\":1594},{\"id\":1595},{\"id\":1596},{\"id\":1597},{\"id\":1598},{\"id\":1599},{\"id\":1600},{\"id\":1601},{\"id\":1602},{\"id\":1603},{\"id\":1604},{\"id\":1605},{\"id\":1606},{\"id\":1607},{\"id\":1608},{\"id\":1609},{\"id\":1610},{\"id\":1611},{\"id\":1612},{\"id\":1613},{\"id\":1614},{\"id\":1615},{\"id\":1616},{\"id\":1617},{\"id\":1618},{\"id\":1619},{\"id\":1620},{\"id\":1621},{\"id\":1622},{\"id\":1623},{\"id\":1624},{\"id\":1625},{\"id\":1626},{\"id\":1627},{\"id\":1628},{\"id\":1629},{\"id\":1630},{\"id\":1631},{\"id\":1632},{\"id\":1633},{\"id\":1634},{\"id\":1635},{\"id\":1636},{\"id\":1637},{\"id\":1638},{\"id\":1639},{\"id\":1640},{\"id\":1641},{\"id\":1642},{\"id\":1643},{\"id\":1644},{\"id\":1645},{\"id\":1646},{\"id\":1647},{\"id\":1648},{\"id\":1649},{\"id\":1650},{\"id\":1651},{\"id\":1652},{\"id\":1653},{\"id\":1654},{\"id\":1655},{\"id\":1656},{\"id\":1657},{\"id\":1658},{\"id\":1659},{\"id\":1660},{\"id\":1661},{\"id\":1662},{\"id\":1663},{\"id\":1664},{\"id\":1665},{\"id\":1666},{\"id\":1667},{\"id\":1668},{\"id\":1669},{\"id\":1670},{\"id\":1671},{\"id\":1672},{\"id\":1673},{\"id\":1674},{\"id\":1675},{\"id\":1676},{\"id\":1677},{\"id\":1678},{\"id\":1679},{\"id\":1680},{\"id\":1681},{\"id\":1682},{\"id\":1683},{\"id\":1684},{\"id\":1685},{\"id\":1686},{\"id\":1687},{\"id\":1688},{\"id\":1689},{\"id\":1690},{\"id\":1691},{\"id\":1692},{\"id\":1693},{\"id\":1694},{\"id\":1695},{\"id\":1696},{\"id\":1697},{\"id\":1698},{\"id\":1699},{\"id\":1700},{\"id\":1701},{\"id\":1702},{\"id\":1703},{\"id\":1704},{\"id\":1705},{\"id\":1706},{\"id\":1707},{\"id\":1708},{\"id\":1709},{\"id\":1710},{\"id\":1711},{\"id\":1712},{\"id\":1713},{\"id\":1714},{\"id\":1715},{\"id\":1716},{\"id\":1717},{\"id\":1718},{\"id\":1719},{\"id\":1720},{\"id\":1721},{\"id\":1722},{\"id\":1723},{\"id\":1724},{\"id\":1725},{\"id\":1726},{\"id\":1727},{\"id\":1728},{\"id\":1729},{\"id\":1730},{\"id\":1731},{\"id\":1732},{\"id\":1733},{\"id\":1734},{\"id\":1735},{\"id\":1736},{\"id\":1737},{\"id\":1738},{\"id\":1739},{\"id\":1740},{\"id\":1741},{\"id\":1742},{\"id\":1743},{\"id\":1744},{\"id\":1745},{\"id\":1746},{\"id\":1747},{\"id\":1748},{\"id\":1749},{\"id\":1750},{\"id\":1751},{\"id\":1752},{\"id\":1753},{\"id\":1754},{\"id\":1755},{\"id\":1756},{\"id\":1757},{\"id\":1758},{\"id\":1759},{\"id\":1760},{\"id\":1761},{\"id\":1762},{\"id\":1763},{\"id\":1764},{\"id\":1765},{\"id\":1766},{\"id\":1767},{\"id\":1768},{\"id\":1769},{\"id\":1770},{\"id\":1771},{\"id\":1772},{\"id\":1773},{\"id\":1774},{\"id\":1775},{\"id\":1776},{\"id\":1777},{\"id\":1778},{\"id\":1779},{\"id\":1780},{\"id\":1781},{\"id\":1782},{\"id\":1783},{\"id\":1784},{\"id\":1785},{\"id\":1786},{\"id\":1787},{\"id\":1788},{\"id\":1789},{\"id\":1790},{\"id\":1791},{\"id\":1792},{\"id\":1793},{\"id\":1794},{\"id\":1795},{\"id\":1796},{\"id\":1797},{\"id\":1798},{\"id\":1799},{\"id\":1800},{\"id\":1801},{\"id\":1802},{\"id\":1803},{\"id\":1804},{\"id\":1805},{\"id\":1806},{\"id\":1807},{\"id\":1808},{\"id\":1809},{\"id\":1810},{\"id\":1811},{\"id\":1812},{\"id\":1813},{\"id\":1814},{\"id\":1815},{\"id\":1816},{\"id\":1817},{\"id\":1818},{\"id\":1819},{\"id\":1820},{\"id\":1821},{\"id\":1822},{\"id\":1823},{\"id\":1824},{\"id\":1825},{\"id\":1826},{\"id\":1827},{\"id\":1828},{\"id\":1829},{\"id\":1830},{\"id\":1831},{\"id\":1832},{\"id\":1833},{\"id\":1834},{\"id\":1835},{\"id\":1836},{\"id\":1837},{\"id\":1838},{\"id\":1839},{\"id\":1840},{\"id\":1841},{\"id\":1842},{\"id\":1843},{\"id\":1844},{\"id\":1845},{\"id\":1846},{\"id\":1847},{\"id\":1848},{\"id\":1849},{\"id\":1850},{\"id\":1851},{\"id\":1852},{\"id\":1853},{\"id\":1854},{\"id\":1855},{\"id\":1856},{\"id\":1857},{\"id\":1858},{\"id\":1859},{\"id\":1860},{\"id\":1861},{\"id\":1862},{\"id\":1863},{\"id\":1864},{\"id\":1865},{\"id\":1866},{\"id\":1867},{\"id\":1868},{\"id\":1869},{\"id\":1870},{\"id\":1871},{\"id\":1872},{\"id\":1873},{\"id\":1874},{\"id\":1875},{\"id\":1876},{\"id\":1877},{\"id\":1878},{\"id\":1879},{\"id\":1880},{\"id\":1881},{\"id\":1882},{\"id\":1883},{\"id\":1884},{\"id\":1885},{\"id\":1886},{\"id\":1887},{\"id\":1888},{\"id\":1889},{\"id\":1890},{\"id\":1891},{\"id\":1892},{\"id\":1893},{\"id\":1894},{\"id\":1895},{\"id\":1896},{\"id\":1897},{\"id\":1898},{\"id\":1899},{\"id\":1900},{\"id\":1901},{\"id\":1902},{\"id\":1903},{\"id\":1904},{\"id\":1905},{\"id\":1906},{\"id\":1907},{\"id\":1908},{\"id\":1909},{\"id\":1910},{\"id\":1911},{\"id\":1912},{\"id\":1913},{\"id\":1914},{\"id\":1915},{\"id\":1916},{\"id\":1917},{\"id\":1918},{\"id\":1919},{\"id\":1920},{\"id\":1921},{\"id\":1922},{\"id\":1923},{\"id\":1924},{\"id\":1925},{\"id\":1926},{\"id\":1927},{\"id\":1928},{\"id\":1929},{\"id\":1930},{\"id\":1931},{\"id\":1932},{\"id\":1933},{\"id\":1934},{\"id\":1935},{\"id\":1936},{\"id\":1937},{\"id\":1938},{\"id\":1939},{\"id\":1940},{\"id\":1941},{\"id\":1942},{\"id\":1943},{\"id\":1944},{\"id\":1945},{\"id\":1946},{\"id\":1947},{\"id\":1948},{\"id\":1949},{\"id\":1950},{\"id\":1951},{\"id\":1952},{\"id\":1953},{\"id\":1954},{\"id\":1955},{\"id\":1956},{\"id\":1957},{\"id\":1958},{\"id\":1959},{\"id\":1960},{\"id\":1961},{\"id\":1962},{\"id\":1963},{\"id\":1964},{\"id\":1965},{\"id\":1966},{\"id\":1967},{\"id\":1968},{\"id\":1969},{\"id\":1970},{\"id\":1971},{\"id\":1972},{\"id\":1973},{\"id\":1974},{\"id\":1975},{\"id\":1976},{\"id\":1977},{\"id\":1978},{\"id\":1979},{\"id\":1980},{\"id\":1981},{\"id\":1982},{\"id\":1983},{\"id\":1984},{\"id\":1985},{\"id\":1986},{\"id\":1987},{\"id\":1988},{\"id\":1989},{\"id\":1990},{\"id\":1991},{\"id\":1992},{\"id\":1993},{\"id\":1994},{\"id\":1995},{\"id\":1996},{\"id\":1997},{\"id\":1998},{\"id\":1999},{\"id\":2000},{\"id\":2001},{\"id\":2002},{\"id\":2003},{\"id\":2004},{\"id\":2005},{\"id\":2006},{\"id\":2007},{\"id\":2008},{\"id\":2009},{\"id\":2010},{\"id\":2011},{\"id\":2012},{\"id\":2013},{\"id\":2014},{\"id\":2015},{\"id\":2016},{\"id\":2017},{\"id\":2018},{\"id\":2019},{\"id\":2020},{\"id\":2021},{\"id\":2022},{\"id\":2023},{\"id\":2024},{\"id\":2025},{\"id\":2026},{\"id\":2027},{\"id\":2028},{\"id\":2029},{\"id\":2030},{\"id\":2031},{\"id\":2032},{\"id\":2033},{\"id\":2034},{\"id\":2035},{\"id\":2036},{\"id\":2037},{\"id\":2038},{\"id\":2039},{\"id\":2040},{\"id\":2041},{\"id\":2042},{\"id\":2043},{\"id\":2044},{\"id\":2045},{\"id\":2046},{\"id\":2047},{\"id\":2048},{\"id\":2049},{\"id\":2050},{\"id\":2051},{\"id\":2052},{\"id\":2053},{\"id\":2054},{\"id\":2055},{\"id\":2056},{\"id\":2057},{\"id\":2058},{\"id\":2059},{\"id\":2060},{\"id\":2061},{\"id\":2062},{\"id\":2063},{\"id\":2064},{\"id\":2065},{\"id\":2066},{\"id\":2067},{\"id\":2068},{\"id\":2069},{\"id\":2070},{\"id\":2071},{\"id\":2072},{\"id\":2073},{\"id\":2074},{\"id\":2075},{\"id\":2076},{\"id\":2077},{\"id\":2078},{\"id\":2079},{\"id\":2080},{\"id\":2081},{\"id\":2082},{\"id\":2083},{\"id\":2084},{\"id\":2085},{\"id\":2086},{\"id\":2087},{\"id\":2088},{\"id\":2089},{\"id\":2090},{\"id\":2091},{\"id\":2092},{\"id\":2093},{\"id\":2094},{\"id\":2095},{\"id\":2096},{\"id\":2097},{\"id\":2098},{\"id\":2099},{\"id\":2100},{\"id\":2101},{\"id\":2102},{\"id\":2103},{\"id\":2104},{\"id\":2105},{\"id\":2106},{\"id\":2107},{\"id\":2108},{\"id\":2109},{\"id\":2110},{\"id\":2111},{\"id\":2112},{\"id\":2113},{\"id\":2114},{\"id\":2115},{\"id\":2116},{\"id\":2117},{\"id\":2118},{\"id\":2119},{\"id\":2120},{\"id\":2121},{\"id\":2122},{\"id\":2123},{\"id\":2124},{\"id\":2125},{\"id\":2126},{\"id\":2127},{\"id\":2128},{\"id\":2129},{\"id\":2130},{\"id\":2131},{\"id\":2132},{\"id\":2133},{\"id\":2134},{\"id\":2135},{\"id\":2136},{\"id\":2137},{\"id\":2138},{\"id\":2139},{\"id\":2140},{\"id\":2141},{\"id\":2142},{\"id\":2143},{\"id\":2144},{\"id\":2145},{\"id\":2146},{\"id\":2147},{\"id\":2148},{\"id\":2149},{\"id\":2150},{\"id\":2151},{\"id\":2152},{\"id\":2153},{\"id\":2154},{\"id\":2155},{\"id\":2156},{\"id\":2157},{\"id\":2158},{\"id\":2159},{\"id\":2160},{\"id\":2161},{\"id\":2162},{\"id\":2163},{\"id\":2164},{\"id\":2165},{\"id\":2166},{\"id\":2167},{\"id\":2168},{\"id\":2169},{\"id\":2170},{\"id\":2171},{\"id\":2172},{\"id\":2173},{\"id\":2174},{\"id\":2175},{\"id\":2176},{\"id\":2177},{\"id\":2178},{\"id\":2179},{\"id\":2180},{\"id\":2181},{\"id\":2182},{\"id\":2183},{\"id\":2184},{\"id\":2185},{\"id\":2186},{\"id\":2187},{\"id\":2188},{\"id\":2189},{\"id\":2190},{\"id\":2191},{\"id\":2192},{\"id\":2193},{\"id\":2194},{\"id\":2195},{\"id\":2196},{\"id\":2197},{\"id\":2198},{\"id\":2199},{\"id\":2200},{\"id\":2201},{\"id\":2202},{\"id\":2203},{\"id\":2204},{\"id\":2205},{\"id\":2206},{\"id\":2207},{\"id\":2208},{\"id\":2209},{\"id\":2210},{\"id\":2211},{\"id\":2212},{\"id\":2213},{\"id\":2214},{\"id\":2215},{\"id\":2216},{\"id\":2217},{\"id\":2218},{\"id\":2219},{\"id\":2220},{\"id\":2221},{\"id\":2222},{\"id\":2223},{\"id\":2224},{\"id\":2225},{\"id\":2226},{\"id\":2227},{\"id\":2228},{\"id\":2229},{\"id\":2230},{\"id\":2231},{\"id\":2232},{\"id\":2233},{\"id\":2234},{\"id\":2235},{\"id\":2236},{\"id\":2237},{\"id\":2238},{\"id\":2239},{\"id\":2240},{\"id\":2241},{\"id\":2242},{\"id\":2243},{\"id\":2244},{\"id\":2245},{\"id\":2246},{\"id\":2247},{\"id\":2248},{\"id\":2249},{\"id\":2250},{\"id\":2251},{\"id\":2252},{\"id\":2253},{\"id\":2254},{\"id\":2255},{\"id\":2256},{\"id\":2257},{\"id\":2258},{\"id\":2259},{\"id\":2260},{\"id\":2261},{\"id\":2262},{\"id\":2263},{\"id\":2264},{\"id\":2265},{\"id\":2266},{\"id\":2267},{\"id\":2268},{\"id\":2269},{\"id\":2270},{\"id\":2271},{\"id\":2272},{\"id\":2273},{\"id\":2274},{\"id\":2275},{\"id\":2276},{\"id\":2277},{\"id\":2278},{\"id\":2279},{\"id\":2280},{\"id\":2281},{\"id\":2282},{\"id\":2283},{\"id\":2284},{\"id\":2285},{\"id\":2286},{\"id\":2287},{\"id\":2288},{\"id\":2289},{\"id\":2290},{\"id\":2291},{\"id\":2292},{\"id\":2293},{\"id\":2294},{\"id\":2295},{\"id\":2296},{\"id\":2297},{\"id\":2298},{\"id\":2299},{\"id\":2300},{\"id\":2301},{\"id\":2302},{\"id\":2303},{\"id\":2304},{\"id\":2305},{\"id\":2306},{\"id\":2307},{\"id\":2308},{\"id\":2309},{\"id\":2310},{\"id\":2311},{\"id\":2312},{\"id\":2313},{\"id\":2314},{\"id\":2315},{\"id\":2316},{\"id\":2317},{\"id\":2318},{\"id\":2319},{\"id\":2320},{\"id\":2321},{\"id\":2322},{\"id\":2323},{\"id\":2324},{\"id\":2325},{\"id\":2326},{\"id\":2327},{\"id\":2328},{\"id\":2329},{\"id\":2330},{\"id\":2331},{\"id\":2332},{\"id\":2333},{\"id\":2334},{\"id\":2335},{\"id\":2336},{\"id\":2337},{\"id\":2338},{\"id\":2339},{\"id\":2340},{\"id\":2341},{\"id\":2342},{\"id\":2343},{\"id\":2344},{\"id\":2345},{\"id\":2346},{\"id\":2347},{\"id\":2348},{\"id\":2349},{\"id\":2350},{\"id\":2351},{\"id\":2352},{\"id\":2353},{\"id\":2354},{\"id\":2355},{\"id\":2356},{\"id\":2357},{\"id\":2358},{\"id\":2359},{\"id\":2360},{\"id\":2361},{\"id\":2362},{\"id\":2363},{\"id\":2364},{\"id\":2365},{\"id\":2366},{\"id\":2367},{\"id\":2368},{\"id\":2369},{\"id\":2370},{\"id\":2371},{\"id\":2372},{\"id\":2373},{\"id\":2374},{\"id\":2375},{\"id\":2376},{\"id\":2377},{\"id\":2378},{\"id\":2379},{\"id\":2380},{\"id\":2381},{\"id\":2382},{\"id\":2383},{\"id\":2384},{\"id\":2385},{\"id\":2386},{\"id\":2387},{\"id\":2388},{\"id\":2389},{\"id\":2390},{\"id\":2391},{\"id\":2392},{\"id\":2393},{\"id\":2394},{\"id\":2395},{\"id\":2396},{\"id\":2397},{\"id\":2398},{\"id\":2399},{\"id\":2400},{\"id\":2401},{\"id\":2402},{\"id\":2403},{\"id\":2404},{\"id\":2405},{\"id\":2406},{\"id\":2407},{\"id\":2408},{\"id\":2409},{\"id\":2410},{\"id\":2411},{\"id\":2412},{\"id\":2413},{\"id\":2414},{\"id\":2415},{\"id\":2416},{\"id\":2417},{\"id\":2418},{\"id\":2419},{\"id\":2420},{\"id\":2421},{\"id\":2422},{\"id\":2423},{\"id\":2424},{\"id\":2425},{\"id\":2426},{\"id\":2427},{\"id\":2428},{\"id\":2429},{\"id\":2430},{\"id\":2431},{\"id\":2432},{\"id\":2433},{\"id\":2434},{\"id\":2435},{\"id\":2436},{\"id\":2437},{\"id\":2438},{\"id\":2439},{\"id\":2440},{\"id\":2441},{\"id\":2442},{\"id\":2443},{\"id\":2444},{\"id\":2445},{\"id\":2446},{\"id\":2447},{\"id\":2448},{\"id\":2449},{\"id\":2450},{\"id\":2451},{\"id\":2452},{\"id\":2453},{\"id\":2454},{\"id\":2455},{\"id\":2456},{\"id\":2457},{\"id\":2458},{\"id\":2459},{\"id\":2460},{\"id\":2461},{\"id\":2462},{\"id\":2463},{\"id\":2464},{\"id\":2465},{\"id\":2466},{\"id\":2467},{\"id\":2468},{\"id\":2469},{\"id\":2470},{\"id\":2471},{\"id\":2472},{\"id\":2473},{\"id\":2474},{\"id\":2475},{\"id\":2476},{\"id\":2477},{\"id\":2478},{\"id\":2479},{\"id\":2480},{\"id\":2481},{\"id\":2482},{\"id\":2483},{\"id\":2484},{\"id\":2485},{\"id\":2486},{\"id\":2487},{\"id\":2488},{\"id\":2489},{\"id\":2490},{\"id\":2491},{\"id\":2492},{\"id\":2493},{\"id\":2494},{\"id\":2495},{\"id\":2496},{\"id\":2497},{\"id\":2498},{\"id\":2499},{\"id\":2500},{\"id\":2501},{\"id\":2502},{\"id\":2503},{\"id\":2504},{\"id\":2505},{\"id\":2506},{\"id\":2507},{\"id\":2508},{\"id\":2509},{\"id\":2510},{\"id\":2511},{\"id\":2512},{\"id\":2513},{\"id\":2514},{\"id\":2515},{\"id\":2516},{\"id\":2517},{\"id\":2518},{\"id\":2519},{\"id\":2520},{\"id\":2521},{\"id\":2522},{\"id\":2523},{\"id\":2524},{\"id\":2525},{\"id\":2526},{\"id\":2527},{\"id\":2528},{\"id\":2529},{\"id\":2530},{\"id\":2531},{\"id\":2532},{\"id\":2533},{\"id\":2534},{\"id\":2535},{\"id\":2536},{\"id\":2537},{\"id\":2538},{\"id\":2539},{\"id\":2540},{\"id\":2541},{\"id\":2542},{\"id\":2543},{\"id\":2544},{\"id\":2545},{\"id\":2546},{\"id\":2547},{\"id\":2548},{\"id\":2549},{\"id\":2550},{\"id\":2551},{\"id\":2552},{\"id\":2553},{\"id\":2554},{\"id\":2555},{\"id\":2556},{\"id\":2557},{\"id\":2558},{\"id\":2559},{\"id\":2560},{\"id\":2561},{\"id\":2562},{\"id\":2563},{\"id\":2564},{\"id\":2565},{\"id\":2566},{\"id\":2567},{\"id\":2568},{\"id\":2569},{\"id\":2570},{\"id\":2571},{\"id\":2572},{\"id\":2573},{\"id\":2574},{\"id\":2575},{\"id\":2576},{\"id\":2577},{\"id\":2578},{\"id\":2579},{\"id\":2580},{\"id\":2581},{\"id\":2582},{\"id\":2583},{\"id\":2584},{\"id\":2585},{\"id\":2586},{\"id\":2587},{\"id\":2588},{\"id\":2589},{\"id\":2590},{\"id\":2591},{\"id\":2592},{\"nodeType\":3,\"id\":2596,\"textContent\":\" // Track clicks on page $(document).ready(function() { $(\\\".control\\\").click(function(e) { e.stopImmediatePropagation(); clicks = clicks + 1; console.log(clicks); }); }); $('.userid').html(sid); // console.log(\\\"start of clicked array: \\\"+clicked); // console.log(\\\"start of hovered string: \\\"+hovered); //set correct answers for each question var triangular_answers = { \\\"acme.starttime.1\\\" : [\\\"F\\\"], \\\"acme.starts.1\\\" : [\\\"K\\\"], \\\"acme.meets.1\\\" : [\\\"F\\\"], \\\"acme.endtime.1\\\" : [\\\"H\\\"], \\\"acme.midpoint.1\\\" : [\\\"O\\\"], \\\"acme.starttime.2\\\" : [\\\"F\\\"], \\\"acme.starts.2\\\" : [\\\"K\\\"], \\\"acme.meets.2\\\" : [\\\"F\\\"], \\\"acme.endtime.2\\\" : [\\\"H\\\"], \\\"acme.midpoint.2\\\" : [\\\"A\\\"], \\\"bigset.duration.1\\\" : [\\\"E\\\",\\\"G\\\"], \\\"bigset.duration+starts.1\\\" : [\\\"X\\\",\\\"O\\\"], \\\"bigset.duration+contained.1\\\" : [\\\"G\\\"], \\\"bigset.starttime+before+endtime+during.1\\\": [\\\"I\\\"], \\\"bigset.ends.1\\\" : [\\\"E\\\"], \\\"bigset.duration.2\\\" : [\\\"E\\\",\\\"G\\\"], \\\"bigset.duration+starts.2\\\" : [\\\"X\\\",\\\"O\\\"], \\\"bigset.duration+contained.2\\\" : [\\\"G\\\"], \\\"bigset.starttime+before+endtime+during.2\\\":[\\\"I\\\"], \\\"bigset.ends.2\\\" : [\\\"E\\\"], \\\"bigset.starttime.1\\\" : [\\\"M\\\",\\\"L\\\"], \\\"bigset.starts.1\\\" : [\\\"G\\\"], \\\"bigset.meets.1\\\" : [\\\"E\\\",\\\"F\\\"], \\\"bigset.endtime.1\\\" : [\\\"X\\\"], \\\"bigset.midpoint.1\\\" : [\\\"K\\\",\\\"X\\\"], \\\"bigset.starttime.2\\\" : [\\\"M\\\",\\\"L\\\"], \\\"bigset.starts.2\\\" : [\\\"G\\\"], \\\"bigset.meets.2\\\" : [\\\"E\\\",\\\"F\\\"], \\\"bigset.endtime.2\\\" : [\\\"X\\\"], \\\"bigset.midpoint.2\\\" : [\\\"K\\\",\\\"X\\\"] } var orthogonal_answers = { \\\"acme.starttime.1\\\" : [\\\"A\\\"], \\\"acme.starts.1\\\" : [\\\"E\\\"], \\\"acme.meets.1\\\" : [\\\"Z\\\"], \\\"acme.endtime.1\\\" : [\\\"U\\\"], \\\"acme.midpoint.1\\\" : [\\\"U\\\"], \\\"acme.starttime.2\\\" : [\\\"0\\\"], \\\"acme.starts.2\\\" : [\\\"0\\\"], \\\"acme.meets.2\\\" : [\\\"0\\\"], \\\"acme.endtime.2\\\" : [\\\"0\\\"], \\\"acme.midpoint.2\\\" : [\\\"0\\\"], \\\"bigset.duration.1\\\" : [\\\"E\\\",\\\"G\\\"], \\\"bigset.duration+starts.1\\\" : [\\\"F\\\",\\\"B\\\"], \\\"bigset.duration+contained.1\\\" : [\\\"E\\\"], \\\"bigset.starttime+before+endtime+during.1\\\": [\\\"I\\\"], \\\"bigset.ends.1\\\" : [\\\"X\\\"], \\\"bigset.duration.2\\\" : [\\\"E\\\",\\\"G\\\"], \\\"bigset.duration+starts.2\\\" : [\\\"F\\\",\\\"B\\\"], \\\"bigset.duration+contained.2\\\" : [\\\"E\\\"], \\\"bigset.starttime+before+endtime+during.2\\\":[\\\"I\\\"], \\\"bigset.ends.2\\\" : [\\\"X\\\"], \\\"bigset.starttime.1\\\" : [\\\"F\\\",\\\"B\\\"], \\\"bigset.starts.1\\\" : [\\\"B\\\"], \\\"bigset.meets.1\\\" : [\\\"F\\\",\\\"X\\\"], \\\"bigset.endtime.1\\\" : [\\\"B\\\"], \\\"bigset.midpoint.1\\\" : [\\\"E\\\",\\\"F\\\"], \\\"bigset.starttime.2\\\" : [\\\"F\\\",\\\"B\\\"], \\\"bigset.starts.2\\\" : [\\\"B\\\"], \\\"bigset.meets.2\\\" : [\\\"F\\\",\\\"X\\\"], \\\"bigset.endtime.2\\\" : [\\\"B\\\"], \\\"bigset.midpoint.2\\\" : [\\\"E\\\",\\\"F\\\"] } //display the question and answer buttons based on input values from jsPsych document.getElementById(scenario+\\\".\\\"+question).style.display = \\\"block\\\"; if (question == \\\"strategy\\\") {document.getElementById(\\\"strategyButton\\\").style.display = \\\"block\\\";} else {document.getElementById(\\\"testingButton\\\").style.display = \\\"block\\\";} //---------SET PROPERTIES OF THE GRAPH -------------// // set the dimensions and margins of the graph var margin = {top: 25, right: 30, bottom: 90, left: 100}, width = 800, height = 800; var intersects = false; //default value for intersects scaffold var xAxisTitle, yAxisTitle; var datafile =\\\"\\\"; // SET AXIS VALUES if (axis == 1){ axis = \\\"Orthogonal-XInside-YFull\\\"; } else if (axis == 2){ axis = \\\"Orthogonal-XInside-YPartial\\\"; } else if (axis ==3){ axis = \\\"Triangular-XInside-YInside\\\"; } else if (axis ==4){ axis = \\\"Orthogonal-XInside-YInside\\\"; } else if (axis ==5){ axis = \\\"Orthogonal-XFull-YFull\\\"; } // SET EXPLICIT SCAFFOLD FEATURES if (explicit ==2 && axis != \\\"diagonal\\\"){ scaffold = 2; intersects = false; } else if (explicit == 2 && axis == \\\"diagonal\\\"){ scaffold = 2; intersects = false; } //TODO: not sure if above two lines are still valid since leaders are now generated on the fly else if (explicit == 3){ $('#hint-interactive').css(\\\"display\\\",\\\"block\\\"); //display textimage scaffold intersects = true; } //SET DATA FILE FOR IMPLICIT SCAFFOLD if (impasse == 1){ datafile = \\\"../views/src/data/acme_nonimpasse.csv\\\"; } else if (impasse == 2){ datafile = \\\"../views/src/data/acme_impasse.csv\\\"; } //OVERRIDE DATA FILE FOR NON-SCAFFOLD QUESTIONS if (q > 5) { //override data file if q# is greater than 5 datafile = \\\"../views/src/data/bigset.csv\\\"; console.log(\\\"override data file\\\"); $('#orthogonal-image').css(\\\"display\\\",\\\"none\\\"); //display textimage scaffold $('#diagonal-image').css(\\\"display\\\",\\\"none\\\"); //display textimage scaffold $('#hint-interactive').css(\\\"display\\\",\\\"none\\\"); //display textimage scaffold intersects = false; } // //---------CREATE THE SVG ------------------------// var svg = d3.select(\\\".d3container\\\").append(\\\"svg\\\") .attr(\\\"width\\\", width + margin.left + margin.right) .attr(\\\"height\\\", height + margin.top + margin.bottom) .append(\\\"g\\\") .attr(\\\"transform\\\", \\\"translate(\\\" + margin.left + \\\",\\\" + margin.top + \\\")\\\"); //---------DRAW THE GRAPH ------------------------// xAxisTitle = \\\"START & END TIME (time of day)\\\"; yAxisTitle = \\\"DURATION (in hours)\\\"; drawTriangleModel(datafile,intersects,axis,scaffold,q); \"},{\"id\":2593},{\"id\":2594},{\"nodeType\":3,\"id\":2597,\"textContent\":\" //MOUSE LOGGING SCRIPT var mouseLog = [] var xwidth = $(document).width(); var xheight = $(document).width(); mouseLog.push(\\\"{x:\\\"+xwidth+\\\",y:\\\"+xheight+\\\",t:\\\"+\\\"0};\\\") document.onmousemove = function(e){ var pageCoords = \\\"{x:\\\" + e.pageX + \\\",y:\\\"+ e.pageY +\\\",t:\\\"+ Date.now()+ \\\"};\\\" ; mouseLog.push(pageCoords); // console.log(pageCoords); }; \"},{\"id\":2595}],[],[],[]]}"
    },
    {
      "sequence": 2,
      "data": "{\"f\":\"applyChanged\",\"args\":[[],[{\"nodeType\":1,\"id\":2598,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-text-preamble\",\"class\":\"jspsych-survey-text-preamble\"},\"parentNode\":{\"id\":55}},{\"nodeType\":1,\"id\":2599,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-text-0\",\"class\":\"jspsych-survey-text-question\"},\"previousSibling\":{\"id\":2598},\"parentNode\":{\"id\":55}},{\"nodeType\":1,\"id\":2600,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-text-1\",\"class\":\"jspsych-survey-text-question\"},\"previousSibling\":{\"id\":2599},\"parentNode\":{\"id\":55}},{\"nodeType\":1,\"id\":2601,\"tagName\":\"BUTTON\",\"attributes\":{\"id\":\"jspsych-survey-text-next\",\"class\":\"jspsych-btn jspsych-survey-text\"},\"previousSibling\":{\"id\":2600},\"parentNode\":{\"id\":55}},{\"nodeType\":1,\"id\":2602,\"tagName\":\"P\",\"attributes\":{\"class\":\"jspsych-survey-text\"},\"parentNode\":{\"id\":2599}},{\"nodeType\":1,\"id\":2603,\"tagName\":\"TEXTAREA\",\"attributes\":{\"name\":\"#jspsych-survey-text-response-0\",\"cols\":\"40\",\"rows\":\"1\"},\"previousSibling\":{\"id\":2602},\"parentNode\":{\"id\":2599}},{\"nodeType\":3,\"id\":2604,\"textContent\":\"What is your age?\",\"parentNode\":{\"id\":2602}},{\"nodeType\":1,\"id\":2605,\"tagName\":\"P\",\"attributes\":{\"class\":\"jspsych-survey-text\"},\"parentNode\":{\"id\":2600}},{\"nodeType\":1,\"id\":2606,\"tagName\":\"TEXTAREA\",\"attributes\":{\"name\":\"#jspsych-survey-text-response-1\",\"cols\":\"40\",\"rows\":\"1\"},\"previousSibling\":{\"id\":2605},\"parentNode\":{\"id\":2600}},{\"nodeType\":3,\"id\":2607,\"textContent\":\"In what country were you born?\",\"parentNode\":{\"id\":2605}},{\"nodeType\":3,\"id\":2608,\"textContent\":\"Submit Answers\",\"parentNode\":{\"id\":2601}}],[],[]]}"
    },
    {
      "sequence": 3,
      "data": "{\"f\":\"applyChanged\",\"args\":[[{\"id\":2598},{\"id\":2599},{\"id\":2602},{\"id\":2604},{\"id\":2603},{\"id\":2600},{\"id\":2605},{\"id\":2607},{\"id\":2606},{\"id\":2601},{\"id\":2608}],[],[],[]]}"
    },
    {
      "sequence": 4,
      "data": "{\"f\":\"applyChanged\",\"args\":[[],[{\"nodeType\":1,\"id\":2609,\"tagName\":\"FORM\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-form\"},\"parentNode\":{\"id\":55}},{\"nodeType\":1,\"id\":2610,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-preamble\",\"class\":\"jspsych-survey-multi-choice-preamble\"},\"parentNode\":{\"id\":2609}},{\"nodeType\":1,\"id\":2611,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-0\",\"class\":\"jspsych-survey-multi-choice-question jspsych-survey-multi-choice-horizontal\"},\"previousSibling\":{\"id\":2610},\"parentNode\":{\"id\":2609}},{\"nodeType\":1,\"id\":2612,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-1\",\"class\":\"jspsych-survey-multi-choice-question jspsych-survey-multi-choice-horizontal\"},\"previousSibling\":{\"id\":2611},\"parentNode\":{\"id\":2609}},{\"nodeType\":1,\"id\":2613,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-2\",\"class\":\"jspsych-survey-multi-choice-question jspsych-survey-multi-choice-horizontal\"},\"previousSibling\":{\"id\":2612},\"parentNode\":{\"id\":2609}},{\"nodeType\":1,\"id\":2614,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-3\",\"class\":\"jspsych-survey-multi-choice-question jspsych-survey-multi-choice-horizontal\"},\"previousSibling\":{\"id\":2613},\"parentNode\":{\"id\":2609}},{\"nodeType\":1,\"id\":2615,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"submit\",\"id\":\"jspsych-survey-multi-choice-next\",\"class\":\"jspsych-survey-multi-choice jspsych-btn\",\"value\":\"Submit Answers\"},\"previousSibling\":{\"id\":2614},\"parentNode\":{\"id\":2609}},{\"nodeType\":1,\"id\":2616,\"tagName\":\"P\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text survey-multi-choice\"},\"parentNode\":{\"id\":2611}},{\"nodeType\":1,\"id\":2617,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-0-0\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2616},\"parentNode\":{\"id\":2611}},{\"nodeType\":1,\"id\":2618,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-0-1\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2617},\"parentNode\":{\"id\":2611}},{\"nodeType\":1,\"id\":2619,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-0-2\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2618},\"parentNode\":{\"id\":2611}},{\"nodeType\":1,\"id\":2620,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-0-3\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2619},\"parentNode\":{\"id\":2611}},{\"nodeType\":3,\"id\":2621,\"textContent\":\"What is your first language?\",\"parentNode\":{\"id\":2616}},{\"nodeType\":1,\"id\":2622,\"tagName\":\"SPAN\",\"attributes\":{\"class\":\"required\"},\"previousSibling\":{\"id\":2621},\"parentNode\":{\"id\":2616}},{\"nodeType\":1,\"id\":2623,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2617}},{\"nodeType\":1,\"id\":2624,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-0\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2623}},{\"nodeType\":3,\"id\":2625,\"textContent\":\"English\",\"previousSibling\":{\"id\":2624},\"parentNode\":{\"id\":2623}},{\"nodeType\":1,\"id\":2626,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2618}},{\"nodeType\":1,\"id\":2627,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-0\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2626}},{\"nodeType\":3,\"id\":2628,\"textContent\":\"Spanish\",\"previousSibling\":{\"id\":2627},\"parentNode\":{\"id\":2626}},{\"nodeType\":1,\"id\":2629,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2619}},{\"nodeType\":1,\"id\":2630,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-0\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2629}},{\"nodeType\":3,\"id\":2631,\"textContent\":\"Mandarin or Cantonese\",\"previousSibling\":{\"id\":2630},\"parentNode\":{\"id\":2629}},{\"nodeType\":1,\"id\":2632,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2620}},{\"nodeType\":1,\"id\":2633,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-0\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2632}},{\"nodeType\":3,\"id\":2634,\"textContent\":\"Other\",\"previousSibling\":{\"id\":2633},\"parentNode\":{\"id\":2632}},{\"nodeType\":3,\"id\":2635,\"textContent\":\"*\",\"parentNode\":{\"id\":2622}},{\"nodeType\":1,\"id\":2636,\"tagName\":\"P\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text survey-multi-choice\"},\"parentNode\":{\"id\":2612}},{\"nodeType\":1,\"id\":2637,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-1-0\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2636},\"parentNode\":{\"id\":2612}},{\"nodeType\":1,\"id\":2638,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-1-1\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2637},\"parentNode\":{\"id\":2612}},{\"nodeType\":1,\"id\":2639,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-1-2\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2638},\"parentNode\":{\"id\":2612}},{\"nodeType\":1,\"id\":2640,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-1-3\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2639},\"parentNode\":{\"id\":2612}},{\"nodeType\":1,\"id\":2641,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-1-4\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2640},\"parentNode\":{\"id\":2612}},{\"nodeType\":1,\"id\":2642,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-1-5\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2641},\"parentNode\":{\"id\":2612}},{\"nodeType\":1,\"id\":2643,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-1-6\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2642},\"parentNode\":{\"id\":2612}},{\"nodeType\":3,\"id\":2644,\"textContent\":\"What is your year in school?\",\"parentNode\":{\"id\":2636}},{\"nodeType\":1,\"id\":2645,\"tagName\":\"SPAN\",\"attributes\":{\"class\":\"required\"},\"previousSibling\":{\"id\":2644},\"parentNode\":{\"id\":2636}},{\"nodeType\":1,\"id\":2646,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2637}},{\"nodeType\":1,\"id\":2647,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-1\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2646}},{\"nodeType\":3,\"id\":2648,\"textContent\":\"First\",\"previousSibling\":{\"id\":2647},\"parentNode\":{\"id\":2646}},{\"nodeType\":1,\"id\":2649,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2638}},{\"nodeType\":1,\"id\":2650,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-1\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2649}},{\"nodeType\":3,\"id\":2651,\"textContent\":\"Second\",\"previousSibling\":{\"id\":2650},\"parentNode\":{\"id\":2649}},{\"nodeType\":1,\"id\":2652,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2639}},{\"nodeType\":1,\"id\":2653,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-1\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2652}},{\"nodeType\":3,\"id\":2654,\"textContent\":\"Third\",\"previousSibling\":{\"id\":2653},\"parentNode\":{\"id\":2652}},{\"nodeType\":1,\"id\":2655,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2640}},{\"nodeType\":1,\"id\":2656,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-1\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2655}},{\"nodeType\":3,\"id\":2657,\"textContent\":\"Fourth\",\"previousSibling\":{\"id\":2656},\"parentNode\":{\"id\":2655}},{\"nodeType\":1,\"id\":2658,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2641}},{\"nodeType\":1,\"id\":2659,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-1\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2658}},{\"nodeType\":3,\"id\":2660,\"textContent\":\"Fifth\",\"previousSibling\":{\"id\":2659},\"parentNode\":{\"id\":2658}},{\"nodeType\":1,\"id\":2661,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2642}},{\"nodeType\":1,\"id\":2662,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-1\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2661}},{\"nodeType\":3,\"id\":2663,\"textContent\":\"Graduate\",\"previousSibling\":{\"id\":2662},\"parentNode\":{\"id\":2661}},{\"nodeType\":1,\"id\":2664,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2643}},{\"nodeType\":1,\"id\":2665,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-1\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2664}},{\"nodeType\":3,\"id\":2666,\"textContent\":\"Other\",\"previousSibling\":{\"id\":2665},\"parentNode\":{\"id\":2664}},{\"nodeType\":3,\"id\":2667,\"textContent\":\"*\",\"parentNode\":{\"id\":2645}},{\"nodeType\":1,\"id\":2668,\"tagName\":\"P\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text survey-multi-choice\"},\"parentNode\":{\"id\":2613}},{\"nodeType\":1,\"id\":2669,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-2-0\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2668},\"parentNode\":{\"id\":2613}},{\"nodeType\":1,\"id\":2670,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-2-1\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2669},\"parentNode\":{\"id\":2613}},{\"nodeType\":1,\"id\":2671,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-2-2\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2670},\"parentNode\":{\"id\":2613}},{\"nodeType\":1,\"id\":2672,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-2-3\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2671},\"parentNode\":{\"id\":2613}},{\"nodeType\":1,\"id\":2673,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-2-4\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2672},\"parentNode\":{\"id\":2613}},{\"nodeType\":1,\"id\":2674,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-2-5\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2673},\"parentNode\":{\"id\":2613}},{\"nodeType\":1,\"id\":2675,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-2-6\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2674},\"parentNode\":{\"id\":2613}},{\"nodeType\":3,\"id\":2676,\"textContent\":\"What is your major area of study?\",\"parentNode\":{\"id\":2668}},{\"nodeType\":1,\"id\":2677,\"tagName\":\"SPAN\",\"attributes\":{\"class\":\"required\"},\"previousSibling\":{\"id\":2676},\"parentNode\":{\"id\":2668}},{\"nodeType\":1,\"id\":2678,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2669}},{\"nodeType\":1,\"id\":2679,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-2\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2678}},{\"nodeType\":3,\"id\":2680,\"textContent\":\"Math or Computer Sciences\",\"previousSibling\":{\"id\":2679},\"parentNode\":{\"id\":2678}},{\"nodeType\":1,\"id\":2681,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2670}},{\"nodeType\":1,\"id\":2682,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-2\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2681}},{\"nodeType\":3,\"id\":2683,\"textContent\":\"Social Sciences (incl. CogSci)\",\"previousSibling\":{\"id\":2682},\"parentNode\":{\"id\":2681}},{\"nodeType\":1,\"id\":2684,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2671}},{\"nodeType\":1,\"id\":2685,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-2\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2684}},{\"nodeType\":3,\"id\":2686,\"textContent\":\"Biomedical & Health Sciences\",\"previousSibling\":{\"id\":2685},\"parentNode\":{\"id\":2684}},{\"nodeType\":1,\"id\":2687,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2672}},{\"nodeType\":1,\"id\":2688,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-2\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2687}},{\"nodeType\":3,\"id\":2689,\"textContent\":\"Natural Sciences\",\"previousSibling\":{\"id\":2688},\"parentNode\":{\"id\":2687}},{\"nodeType\":1,\"id\":2690,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2673}},{\"nodeType\":1,\"id\":2691,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-2\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2690}},{\"nodeType\":3,\"id\":2692,\"textContent\":\"Engineering\",\"previousSibling\":{\"id\":2691},\"parentNode\":{\"id\":2690}},{\"nodeType\":1,\"id\":2693,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2674}},{\"nodeType\":1,\"id\":2694,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-2\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2693}},{\"nodeType\":3,\"id\":2695,\"textContent\":\"Humanities\",\"previousSibling\":{\"id\":2694},\"parentNode\":{\"id\":2693}},{\"nodeType\":1,\"id\":2696,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2675}},{\"nodeType\":1,\"id\":2697,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-2\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2696}},{\"nodeType\":3,\"id\":2698,\"textContent\":\"Fine Arts\",\"previousSibling\":{\"id\":2697},\"parentNode\":{\"id\":2696}},{\"nodeType\":3,\"id\":2699,\"textContent\":\"*\",\"parentNode\":{\"id\":2677}},{\"nodeType\":1,\"id\":2700,\"tagName\":\"P\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text survey-multi-choice\"},\"parentNode\":{\"id\":2614}},{\"nodeType\":1,\"id\":2701,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-3-0\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2700},\"parentNode\":{\"id\":2614}},{\"nodeType\":1,\"id\":2702,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-3-1\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2701},\"parentNode\":{\"id\":2614}},{\"nodeType\":1,\"id\":2703,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-3-2\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2702},\"parentNode\":{\"id\":2614}},{\"nodeType\":3,\"id\":2704,\"textContent\":\"What is your gender?\",\"parentNode\":{\"id\":2700}},{\"nodeType\":1,\"id\":2705,\"tagName\":\"SPAN\",\"attributes\":{\"class\":\"required\"},\"previousSibling\":{\"id\":2704},\"parentNode\":{\"id\":2700}},{\"nodeType\":1,\"id\":2706,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2701}},{\"nodeType\":1,\"id\":2707,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-3\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2706}},{\"nodeType\":3,\"id\":2708,\"textContent\":\"Male\",\"previousSibling\":{\"id\":2707},\"parentNode\":{\"id\":2706}},{\"nodeType\":1,\"id\":2709,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2702}},{\"nodeType\":1,\"id\":2710,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-3\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2709}},{\"nodeType\":3,\"id\":2711,\"textContent\":\"Female\",\"previousSibling\":{\"id\":2710},\"parentNode\":{\"id\":2709}},{\"nodeType\":1,\"id\":2712,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2703}},{\"nodeType\":1,\"id\":2713,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-3\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2712}},{\"nodeType\":3,\"id\":2714,\"textContent\":\"Other\",\"previousSibling\":{\"id\":2713},\"parentNode\":{\"id\":2712}},{\"nodeType\":3,\"id\":2715,\"textContent\":\"*\",\"parentNode\":{\"id\":2705}}],[],[]]}"
    },
    {
      "sequence": 5,
      "data": "{\"f\":\"applyChanged\",\"args\":[[{\"id\":2609},{\"id\":2610},{\"id\":2611},{\"id\":2616},{\"id\":2621},{\"id\":2622},{\"id\":2635},{\"id\":2617},{\"id\":2623},{\"id\":2624},{\"id\":2625},{\"id\":2618},{\"id\":2626},{\"id\":2627},{\"id\":2628},{\"id\":2619},{\"id\":2629},{\"id\":2630},{\"id\":2631},{\"id\":2620},{\"id\":2632},{\"id\":2633},{\"id\":2634},{\"id\":2612},{\"id\":2636},{\"id\":2644},{\"id\":2645},{\"id\":2667},{\"id\":2637},{\"id\":2646},{\"id\":2647},{\"id\":2648},{\"id\":2638},{\"id\":2649},{\"id\":2650},{\"id\":2651},{\"id\":2639},{\"id\":2652},{\"id\":2653},{\"id\":2654},{\"id\":2640},{\"id\":2655},{\"id\":2656},{\"id\":2657},{\"id\":2641},{\"id\":2658},{\"id\":2659},{\"id\":2660},{\"id\":2642},{\"id\":2661},{\"id\":2662},{\"id\":2663},{\"id\":2643},{\"id\":2664},{\"id\":2665},{\"id\":2666},{\"id\":2613},{\"id\":2668},{\"id\":2676},{\"id\":2677},{\"id\":2699},{\"id\":2669},{\"id\":2678},{\"id\":2679},{\"id\":2680},{\"id\":2670},{\"id\":2681},{\"id\":2682},{\"id\":2683},{\"id\":2671},{\"id\":2684},{\"id\":2685},{\"id\":2686},{\"id\":2672},{\"id\":2687},{\"id\":2688},{\"id\":2689},{\"id\":2673},{\"id\":2690},{\"id\":2691},{\"id\":2692},{\"id\":2674},{\"id\":2693},{\"id\":2694},{\"id\":2695},{\"id\":2675},{\"id\":2696},{\"id\":2697},{\"id\":2698},{\"id\":2614},{\"id\":2700},{\"id\":2704},{\"id\":2705},{\"id\":2715},{\"id\":2701},{\"id\":2706},{\"id\":2707},{\"id\":2708},{\"id\":2702},{\"id\":2709},{\"id\":2710},{\"id\":2711},{\"id\":2703},{\"id\":2712},{\"id\":2713},{\"id\":2714},{\"id\":2615}],[],[],[]]}"
    },
    {
      "sequence": 6,
      "data": "{\"f\":\"applyChanged\",\"args\":[[],[{\"nodeType\":1,\"id\":2716,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"masterdiv\"},\"parentNode\":{\"id\":55}},{\"nodeType\":3,\"id\":2717,\"textContent\":\" \",\"previousSibling\":{\"id\":2716},\"parentNode\":{\"id\":55}},{\"nodeType\":3,\"id\":2718,\"textContent\":\" \",\"parentNode\":{\"id\":2716}},{\"nodeType\":1,\"id\":2719,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"top\"},\"previousSibling\":{\"id\":2718},\"parentNode\":{\"id\":2716}},{\"nodeType\":3,\"id\":2720,\"textContent\":\" \",\"previousSibling\":{\"id\":2719},\"parentNode\":{\"id\":2716}},{\"nodeType\":1,\"id\":2721,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"instructions\"},\"previousSibling\":{\"id\":2720},\"parentNode\":{\"id\":2716}},{\"nodeType\":3,\"id\":2722,\"textContent\":\" \",\"previousSibling\":{\"id\":2721},\"parentNode\":{\"id\":2716}},{\"nodeType\":1,\"id\":2723,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bottom\"},\"previousSibling\":{\"id\":2722},\"parentNode\":{\"id\":2716}},{\"nodeType\":3,\"id\":2724,\"textContent\":\" \",\"previousSibling\":{\"id\":2723},\"parentNode\":{\"id\":2716}},{\"nodeType\":3,\"id\":2725,\"textContent\":\" \",\"parentNode\":{\"id\":2719}},{\"nodeType\":1,\"id\":2726,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bcent\"},\"previousSibling\":{\"id\":2725},\"parentNode\":{\"id\":2719}},{\"nodeType\":3,\"id\":2727,\"textContent\":\" \",\"previousSibling\":{\"id\":2726},\"parentNode\":{\"id\":2719}},{\"nodeType\":3,\"id\":2728,\"textContent\":\" \",\"parentNode\":{\"id\":2726}},{\"nodeType\":1,\"id\":2729,\"tagName\":\"H3\",\"attributes\":{},\"previousSibling\":{\"id\":2728},\"parentNode\":{\"id\":2726}},{\"nodeType\":3,\"id\":2730,\"textContent\":\" \",\"previousSibling\":{\"id\":2729},\"parentNode\":{\"id\":2726}},{\"nodeType\":3,\"id\":2731,\"textContent\":\"DEBRIEFING\",\"parentNode\":{\"id\":2729}},{\"nodeType\":3,\"id\":2732,\"textContent\":\" \",\"parentNode\":{\"id\":2721}},{\"nodeType\":1,\"id\":2733,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"vcent\"},\"previousSibling\":{\"id\":2732},\"parentNode\":{\"id\":2721}},{\"nodeType\":3,\"id\":2734,\"textContent\":\" \",\"previousSibling\":{\"id\":2733},\"parentNode\":{\"id\":2721}},{\"nodeType\":3,\"id\":2735,\"textContent\":\" \",\"parentNode\":{\"id\":2733}},{\"nodeType\":1,\"id\":2736,\"tagName\":\"P\",\"attributes\":{\"style\":\"font-style:italic\"},\"previousSibling\":{\"id\":2735},\"parentNode\":{\"id\":2733}},{\"nodeType\":1,\"id\":2737,\"tagName\":\"P\",\"attributes\":{},\"previousSibling\":{\"id\":2736},\"parentNode\":{\"id\":2733}},{\"nodeType\":3,\"id\":2738,\"textContent\":\" \",\"previousSibling\":{\"id\":2737},\"parentNode\":{\"id\":2733}},{\"nodeType\":1,\"id\":2739,\"tagName\":\"P\",\"attributes\":{},\"previousSibling\":{\"id\":2738},\"parentNode\":{\"id\":2733}},{\"nodeType\":3,\"id\":2740,\"textContent\":\" \",\"previousSibling\":{\"id\":2739},\"parentNode\":{\"id\":2733}},{\"nodeType\":1,\"id\":2741,\"tagName\":\"P\",\"attributes\":{},\"previousSibling\":{\"id\":2740},\"parentNode\":{\"id\":2733}},{\"nodeType\":3,\"id\":2742,\"textContent\":\" \",\"previousSibling\":{\"id\":2741},\"parentNode\":{\"id\":2733}},{\"nodeType\":1,\"id\":2743,\"tagName\":\"P\",\"attributes\":{\"style\":\"font-style:bold;\"},\"previousSibling\":{\"id\":2742},\"parentNode\":{\"id\":2733}},{\"nodeType\":3,\"id\":2744,\"textContent\":\" \",\"previousSibling\":{\"id\":2743},\"parentNode\":{\"id\":2733}},{\"nodeType\":1,\"id\":2745,\"tagName\":\"P\",\"attributes\":{\"style\":\"font-style:italic;\"},\"previousSibling\":{\"id\":2744},\"parentNode\":{\"id\":2733}},{\"nodeType\":3,\"id\":2746,\"textContent\":\" \",\"previousSibling\":{\"id\":2745},\"parentNode\":{\"id\":2733}},{\"nodeType\":3,\"id\":2747,\"textContent\":\"Thank you very much for your participation! This debriefing will tell you more about the study, what you did, and why. \",\"parentNode\":{\"id\":2736}},{\"nodeType\":3,\"id\":2748,\"textContent\":\" \",\"parentNode\":{\"id\":2737}},{\"nodeType\":1,\"id\":2749,\"tagName\":\"B\",\"attributes\":{},\"previousSibling\":{\"id\":2748},\"parentNode\":{\"id\":2737}},{\"nodeType\":3,\"id\":2750,\"textContent\":\" You have just used a series of pictures (charts, graphs and diagrams) accompanied by different types of instructions to answer a series of problem solving questions. While you were using the pictures, we measured where you clicked, scrolled and pointed with the computer mouse. We also measured the accuracy of your responses and the time it took to complete each question.\",\"previousSibling\":{\"id\":2749},\"parentNode\":{\"id\":2737}},{\"nodeType\":3,\"id\":2751,\"textContent\":\"What did you just do?\",\"parentNode\":{\"id\":2749}},{\"nodeType\":3,\"id\":2752,\"textContent\":\" \",\"parentNode\":{\"id\":2739}},{\"nodeType\":1,\"id\":2753,\"tagName\":\"B\",\"attributes\":{},\"previousSibling\":{\"id\":2752},\"parentNode\":{\"id\":2739}},{\"nodeType\":3,\"id\":2754,\"textContent\":\" Researchers of learning and cognition have long been interested in how graphic displays of information can be used to communicate, solve problems, and generate insights. As powerful as graphics may be in their communicative efficiency, they're not always immediately intuitive to understand. In short, we know a great deal more about learning with representations than we do about the learning of representations. In this project we are building upon previous research on reading and graph comprehension to explore how readers make sense of unfamiliar representations. The instructions you saw for each type of graph are known as “scaffolding techniques”, and we will compare your performance with the scaffolding techniques you saw with the performance of other participants to determine which types of instructions are most effective in helping humans to make sense of unfamiliar graphs. \",\"previousSibling\":{\"id\":2753},\"parentNode\":{\"id\":2739}},{\"nodeType\":3,\"id\":2755,\"textContent\":\"Why did we have you do it?\",\"parentNode\":{\"id\":2753}},{\"nodeType\":1,\"id\":2756,\"tagName\":\"B\",\"attributes\":{},\"parentNode\":{\"id\":2741}},{\"nodeType\":3,\"id\":2757,\"textContent\":\" We expect that you will have found some of the graphics more difficult to use than others. We also expect that with the assistance of the instructions, after solving several problems you will learn to use the difficult graphics so that you can answer the questions even more quickly than without. If you would like to receive a copy of the results of the study, or have any further questions, please contact the researchers Primary Researcher: Amy Fox : a2fox@ucsd.edu Faculty Advisor : Dr. Jim Hollan : hollan@ucsd.edu \",\"previousSibling\":{\"id\":2756},\"parentNode\":{\"id\":2741}},{\"nodeType\":3,\"id\":2758,\"textContent\":\"What do we expect to find?\",\"parentNode\":{\"id\":2756}},{\"nodeType\":3,\"id\":2759,\"textContent\":\"It is important that you do not discuss this experiment with other students who might participate after you. They must participate in the same way as you did, without any knowledge of what the experiment entails, or the reasoning behind it.\",\"parentNode\":{\"id\":2743}},{\"nodeType\":3,\"id\":2760,\"textContent\":\"Thank you for your time! We hope you enjoyed participating in this study as much as we enjoyed designing it.\",\"parentNode\":{\"id\":2745}},{\"nodeType\":3,\"id\":2761,\"textContent\":\" \",\"parentNode\":{\"id\":2723}},{\"nodeType\":1,\"id\":2762,\"tagName\":\"BUTTON\",\"attributes\":{\"class\":\"btn\",\"type\":\"button\",\"id\":\"start\"},\"previousSibling\":{\"id\":2761},\"parentNode\":{\"id\":2723}},{\"nodeType\":3,\"id\":2763,\"textContent\":\" \",\"previousSibling\":{\"id\":2762},\"parentNode\":{\"id\":2723}},{\"nodeType\":3,\"id\":2764,\"textContent\":\"FINISH\",\"parentNode\":{\"id\":2762}}],[],[]]}"
    },
    {
      "sequence": 7,
      "data": "{\"f\":\"applyChanged\",\"args\":[[{\"id\":2716},{\"id\":2718},{\"id\":2719},{\"id\":2725},{\"id\":2726},{\"id\":2728},{\"id\":2729},{\"id\":2731},{\"id\":2730},{\"id\":2727},{\"id\":2720},{\"id\":2721},{\"id\":2732},{\"id\":2733},{\"id\":2735},{\"id\":2736},{\"id\":2747},{\"id\":2737},{\"id\":2748},{\"id\":2749},{\"id\":2751},{\"id\":2750},{\"id\":2738},{\"id\":2739},{\"id\":2752},{\"id\":2753},{\"id\":2755},{\"id\":2754},{\"id\":2740},{\"id\":2741},{\"id\":2756},{\"id\":2758},{\"id\":2757},{\"id\":2742},{\"id\":2743},{\"id\":2759},{\"id\":2744},{\"id\":2745},{\"id\":2760},{\"id\":2746},{\"id\":2734},{\"id\":2722},{\"id\":2723},{\"id\":2761},{\"id\":2762},{\"id\":2764},{\"id\":2763},{\"id\":2724},{\"id\":2717}],[],[],[]]}"
    },
    {
      "sequence": 8,
      "data": "{\"f\":\"applyChanged\",\"args\":[[],[{\"nodeType\":1,\"id\":2765,\"tagName\":\"PRE\",\"attributes\":{\"id\":\"jspsych-data-display\"},\"parentNode\":{\"id\":55}},{\"nodeType\":3,\"id\":2766,\"textContent\":\"[ { \\\"rt\\\": 44650, \\\"stimulus\\\": \\\"img/phone.png\\\", \\\"key_press\\\": 13, \\\"block\\\": \\\"phone\\\", \\\"trial_type\\\": \\\"single-stim\\\", \\\"trial_index\\\": 0, \\\"time_elapsed\\\": 44653, \\\"internal_node_id\\\": \\\"0.0-0.0\\\", \\\"subject\\\": \\\"2OEC4\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"whiskey\\\", \\\"condition\\\": \\\"115\\\" }, { \\\"rt\\\": 3411, \\\"url\\\": \\\"../views/src/external/consent.html\\\", \\\"block\\\": \\\"consent\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 1, \\\"time_elapsed\\\": 49150, \\\"internal_node_id\\\": \\\"0.0-1.0\\\", \\\"subject\\\": \\\"2OEC4\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"whiskey\\\", \\\"condition\\\": \\\"115\\\" }, { \\\"rt\\\": 25424, \\\"responses\\\": \\\"{\\\\\\\"Q0\\\\\\\":\\\\\\\"WHISKEY\\\\\\\",\\\\\\\"Q1\\\\\\\":\\\\\\\"115\\\\\\\"}\\\", \\\"block\\\": \\\"codes\\\", \\\"trial_type\\\": \\\"survey-text\\\", \\\"trial_index\\\": 2, \\\"time_elapsed\\\": 75584, \\\"internal_node_id\\\": \\\"0.0-2.0\\\", \\\"subject\\\": \\\"2OEC4\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"whiskey\\\", \\\"condition\\\": \\\"115\\\" }, { \\\"rt\\\": 14385, \\\"url\\\": \\\"../views/src/external/instructions_lab.html\\\", \\\"block\\\": \\\"instructions_lab\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 3, \\\"time_elapsed\\\": 91054, \\\"internal_node_id\\\": \\\"0.0-3.0\\\", \\\"subject\\\": \\\"2OEC4\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"whiskey\\\", \\\"condition\\\": \\\"115\\\" }, { \\\"rt\\\": 9270, \\\"stimulus\\\": \\\"img/acme.png\\\", \\\"key_press\\\": 13, \\\"block\\\": \\\"scenario\\\", \\\"trial_type\\\": \\\"single-stim\\\", \\\"trial_index\\\": 4, \\\"time_elapsed\\\": 101326, \\\"internal_node_id\\\": \\\"0.0-4.0\\\", \\\"subject\\\": \\\"2OEC4\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"whiskey\\\", \\\"condition\\\": \\\"115\\\" }, { \\\"rt\\\": 19626, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 5, \\\"time_elapsed\\\": 122187, \\\"internal_node_id\\\": \\\"0.0-5.0-0.0\\\", \\\"subject\\\": \\\"2OEC4\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"whiskey\\\", \\\"condition\\\": \\\"115\\\", \\\"scenario\\\": \\\"acme\\\", \\\"question\\\": \\\"starttime\\\", \\\"q\\\": 1, \\\"clicks\\\": 1, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XFull-YFull\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 1, \\\"answer\\\": [ \\\"A\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"X \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"U \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-9\\\", \\\"block\\\": \\\"triangular_scaffolded\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:989,y:62,t:1527872911762};\\\", \\\"{x:987,y:63,t:1527872911772};\\\", \\\"{x:979,y:67,t:1527872911789};\\\", \\\"{x:970,y:71,t:1527872911804};\\\", \\\"{x:966,y:72,t:1527872911821};\\\", \\\"{x:963,y:73,t:1527872911838};\\\", \\\"{x:963,y:75,t:1527872912324};\\\", \\\"{x:963,y:78,t:1527872912339};\\\", \\\"{x:962,y:79,t:1527872912357};\\\", \\\"{x:962,y:81,t:1527872912372};\\\", \\\"{x:962,y:85,t:1527872912389};\\\", \\\"{x:962,y:91,t:1527872912406};\\\", \\\"{x:964,y:102,t:1527872912422};\\\", \\\"{x:965,y:117,t:1527872912439};\\\", \\\"{x:969,y:133,t:1527872912456};\\\", \\\"{x:972,y:154,t:1527872912473};\\\", \\\"{x:976,y:176,t:1527872912489};\\\", \\\"{x:986,y:203,t:1527872912506};\\\", \\\"{x:994,y:215,t:1527872912523};\\\", \\\"{x:1003,y:220,t:1527872912539};\\\", \\\"{x:1009,y:220,t:1527872912557};\\\", \\\"{x:1010,y:220,t:1527872912572};\\\", \\\"{x:1012,y:222,t:1527872913234};\\\", \\\"{x:1012,y:223,t:1527872913258};\\\", \\\"{x:1012,y:224,t:1527872913273};\\\", \\\"{x:1012,y:226,t:1527872913290};\\\", \\\"{x:1011,y:226,t:1527872913322};\\\", \\\"{x:1010,y:226,t:1527872913787};\\\", \\\"{x:1009,y:226,t:1527872913803};\\\", \\\"{x:1008,y:226,t:1527872913811};\\\", \\\"{x:1008,y:227,t:1527872914019};\\\", \\\"{x:1008,y:228,t:1527872914027};\\\", \\\"{x:1008,y:231,t:1527872914040};\\\", \\\"{x:1009,y:238,t:1527872914057};\\\", \\\"{x:1012,y:244,t:1527872914073};\\\", \\\"{x:1021,y:262,t:1527872914089};\\\", \\\"{x:1027,y:276,t:1527872914106};\\\", \\\"{x:1032,y:285,t:1527872914123};\\\", \\\"{x:1037,y:296,t:1527872914140};\\\", \\\"{x:1039,y:302,t:1527872914157};\\\", \\\"{x:1042,y:311,t:1527872914174};\\\", \\\"{x:1044,y:319,t:1527872914190};\\\", \\\"{x:1047,y:329,t:1527872914207};\\\", \\\"{x:1052,y:340,t:1527872914224};\\\", \\\"{x:1058,y:353,t:1527872914239};\\\", \\\"{x:1063,y:363,t:1527872914257};\\\", \\\"{x:1080,y:388,t:1527872914274};\\\", \\\"{x:1092,y:407,t:1527872914290};\\\", \\\"{x:1108,y:429,t:1527872914306};\\\", \\\"{x:1125,y:451,t:1527872914324};\\\", \\\"{x:1143,y:475,t:1527872914340};\\\", \\\"{x:1157,y:496,t:1527872914357};\\\", \\\"{x:1168,y:518,t:1527872914374};\\\", \\\"{x:1178,y:538,t:1527872914390};\\\", \\\"{x:1187,y:558,t:1527872914407};\\\", \\\"{x:1198,y:577,t:1527872914424};\\\", \\\"{x:1207,y:594,t:1527872914440};\\\", \\\"{x:1212,y:606,t:1527872914457};\\\", \\\"{x:1217,y:630,t:1527872914474};\\\", \\\"{x:1219,y:644,t:1527872914491};\\\", \\\"{x:1220,y:655,t:1527872914507};\\\", \\\"{x:1220,y:667,t:1527872914524};\\\", \\\"{x:1220,y:679,t:1527872914540};\\\", \\\"{x:1220,y:695,t:1527872914557};\\\", \\\"{x:1222,y:710,t:1527872914574};\\\", \\\"{x:1222,y:725,t:1527872914590};\\\", \\\"{x:1225,y:744,t:1527872914607};\\\", \\\"{x:1225,y:760,t:1527872914624};\\\", \\\"{x:1226,y:769,t:1527872914641};\\\", \\\"{x:1226,y:779,t:1527872914658};\\\", \\\"{x:1228,y:787,t:1527872914675};\\\", \\\"{x:1230,y:790,t:1527872914692};\\\", \\\"{x:1233,y:795,t:1527872914707};\\\", \\\"{x:1236,y:798,t:1527872914724};\\\", \\\"{x:1238,y:800,t:1527872914742};\\\", \\\"{x:1240,y:803,t:1527872914758};\\\", \\\"{x:1241,y:805,t:1527872914774};\\\", \\\"{x:1243,y:808,t:1527872914791};\\\", \\\"{x:1244,y:813,t:1527872914807};\\\", \\\"{x:1245,y:820,t:1527872914825};\\\", \\\"{x:1248,y:827,t:1527872914842};\\\", \\\"{x:1249,y:835,t:1527872914857};\\\", \\\"{x:1258,y:850,t:1527872914875};\\\", \\\"{x:1259,y:852,t:1527872914890};\\\", \\\"{x:1261,y:854,t:1527872914908};\\\", \\\"{x:1263,y:855,t:1527872914939};\\\", \\\"{x:1264,y:856,t:1527872914963};\\\", \\\"{x:1265,y:856,t:1527872914979};\\\", \\\"{x:1266,y:857,t:1527872914992};\\\", \\\"{x:1267,y:858,t:1527872915059};\\\", \\\"{x:1267,y:860,t:1527872915076};\\\", \\\"{x:1271,y:869,t:1527872915091};\\\", \\\"{x:1275,y:882,t:1527872915108};\\\", \\\"{x:1281,y:891,t:1527872915123};\\\", \\\"{x:1282,y:893,t:1527872915141};\\\", \\\"{x:1282,y:896,t:1527872915157};\\\", \\\"{x:1282,y:898,t:1527872915174};\\\", \\\"{x:1282,y:901,t:1527872915379};\\\", \\\"{x:1282,y:902,t:1527872915391};\\\", \\\"{x:1283,y:904,t:1527872915408};\\\", \\\"{x:1284,y:906,t:1527872915424};\\\", \\\"{x:1285,y:910,t:1527872915441};\\\", \\\"{x:1285,y:920,t:1527872915458};\\\", \\\"{x:1285,y:925,t:1527872915474};\\\", \\\"{x:1281,y:935,t:1527872915492};\\\", \\\"{x:1276,y:942,t:1527872915508};\\\", \\\"{x:1274,y:947,t:1527872915525};\\\", \\\"{x:1274,y:948,t:1527872915587};\\\", \\\"{x:1274,y:947,t:1527872915643};\\\", \\\"{x:1274,y:946,t:1527872915658};\\\", \\\"{x:1274,y:943,t:1527872915675};\\\", \\\"{x:1274,y:940,t:1527872915691};\\\", \\\"{x:1273,y:937,t:1527872915708};\\\", \\\"{x:1273,y:935,t:1527872915891};\\\", \\\"{x:1264,y:922,t:1527872915908};\\\", \\\"{x:1250,y:898,t:1527872915926};\\\", \\\"{x:1195,y:830,t:1527872915942};\\\", \\\"{x:1099,y:755,t:1527872915959};\\\", \\\"{x:955,y:656,t:1527872915975};\\\", \\\"{x:802,y:570,t:1527872915993};\\\", \\\"{x:670,y:509,t:1527872916009};\\\", \\\"{x:585,y:476,t:1527872916025};\\\", \\\"{x:496,y:440,t:1527872916042};\\\", \\\"{x:451,y:418,t:1527872916059};\\\", \\\"{x:433,y:410,t:1527872916074};\\\", \\\"{x:426,y:407,t:1527872916092};\\\", \\\"{x:418,y:405,t:1527872916109};\\\", \\\"{x:413,y:404,t:1527872916125};\\\", \\\"{x:411,y:404,t:1527872916142};\\\", \\\"{x:408,y:404,t:1527872916178};\\\", \\\"{x:406,y:404,t:1527872916192};\\\", \\\"{x:391,y:405,t:1527872916209};\\\", \\\"{x:353,y:412,t:1527872916225};\\\", \\\"{x:334,y:418,t:1527872916242};\\\", \\\"{x:322,y:427,t:1527872916259};\\\", \\\"{x:314,y:435,t:1527872916276};\\\", \\\"{x:303,y:440,t:1527872916292};\\\", \\\"{x:293,y:444,t:1527872916309};\\\", \\\"{x:292,y:444,t:1527872916326};\\\", \\\"{x:291,y:444,t:1527872916342};\\\", \\\"{x:292,y:445,t:1527872916435};\\\", \\\"{x:296,y:445,t:1527872916442};\\\", \\\"{x:307,y:445,t:1527872916459};\\\", \\\"{x:321,y:447,t:1527872916477};\\\", \\\"{x:336,y:452,t:1527872916493};\\\", \\\"{x:341,y:455,t:1527872916510};\\\", \\\"{x:342,y:457,t:1527872916526};\\\", \\\"{x:343,y:459,t:1527872916543};\\\", \\\"{x:344,y:462,t:1527872916559};\\\", \\\"{x:345,y:464,t:1527872916577};\\\", \\\"{x:348,y:469,t:1527872916593};\\\", \\\"{x:351,y:473,t:1527872916609};\\\", \\\"{x:354,y:480,t:1527872916627};\\\", \\\"{x:356,y:485,t:1527872916642};\\\", \\\"{x:357,y:491,t:1527872916659};\\\", \\\"{x:359,y:495,t:1527872916677};\\\", \\\"{x:361,y:500,t:1527872916694};\\\", \\\"{x:363,y:503,t:1527872916709};\\\", \\\"{x:365,y:506,t:1527872916728};\\\", \\\"{x:366,y:508,t:1527872916742};\\\", \\\"{x:368,y:510,t:1527872916759};\\\", \\\"{x:370,y:510,t:1527872916842};\\\", \\\"{x:374,y:511,t:1527872916850};\\\", \\\"{x:380,y:515,t:1527872916860};\\\", \\\"{x:384,y:516,t:1527872916876};\\\", \\\"{x:385,y:516,t:1527872916893};\\\", \\\"{x:386,y:517,t:1527872917126};\\\", \\\"{x:386,y:518,t:1527872917153};\\\", \\\"{x:386,y:519,t:1527872917162};\\\", \\\"{x:387,y:519,t:1527872917175};\\\", \\\"{x:387,y:520,t:1527872917193};\\\", \\\"{x:389,y:524,t:1527872917209};\\\", \\\"{x:390,y:527,t:1527872917226};\\\", \\\"{x:394,y:533,t:1527872917244};\\\", \\\"{x:400,y:542,t:1527872917261};\\\", \\\"{x:407,y:550,t:1527872917276};\\\", \\\"{x:414,y:558,t:1527872917293};\\\", \\\"{x:421,y:564,t:1527872917310};\\\", \\\"{x:427,y:569,t:1527872917326};\\\", \\\"{x:434,y:578,t:1527872917344};\\\", \\\"{x:439,y:585,t:1527872917361};\\\", \\\"{x:444,y:592,t:1527872917376};\\\", \\\"{x:452,y:603,t:1527872917393};\\\", \\\"{x:463,y:619,t:1527872917411};\\\", \\\"{x:470,y:627,t:1527872917428};\\\", \\\"{x:477,y:635,t:1527872917443};\\\", \\\"{x:484,y:644,t:1527872917460};\\\", \\\"{x:488,y:647,t:1527872917476};\\\", \\\"{x:490,y:649,t:1527872917493};\\\", \\\"{x:491,y:651,t:1527872917510};\\\", \\\"{x:491,y:652,t:1527872917530};\\\", \\\"{x:492,y:654,t:1527872917543};\\\", \\\"{x:493,y:656,t:1527872917559};\\\", \\\"{x:494,y:657,t:1527872917577};\\\", \\\"{x:495,y:662,t:1527872917593};\\\", \\\"{x:498,y:670,t:1527872917610};\\\", \\\"{x:500,y:677,t:1527872917626};\\\", \\\"{x:501,y:685,t:1527872917643};\\\", \\\"{x:501,y:688,t:1527872917660};\\\", \\\"{x:501,y:693,t:1527872917677};\\\", \\\"{x:502,y:700,t:1527872917693};\\\", \\\"{x:502,y:710,t:1527872917712};\\\", \\\"{x:505,y:719,t:1527872917727};\\\", \\\"{x:505,y:722,t:1527872917743};\\\", \\\"{x:506,y:724,t:1527872917759};\\\", \\\"{x:506,y:725,t:1527872917777};\\\", \\\"{x:505,y:725,t:1527872917922};\\\", \\\"{x:505,y:723,t:1527872918035};\\\", \\\"{x:505,y:722,t:1527872918067};\\\", \\\"{x:505,y:720,t:1527872918090};\\\", \\\"{x:505,y:719,t:1527872918163};\\\", \\\"{x:509,y:711,t:1527872931470};\\\", \\\"{x:514,y:687,t:1527872931478};\\\", \\\"{x:522,y:671,t:1527872931492};\\\", \\\"{x:522,y:665,t:1527872931509};\\\", \\\"{x:522,y:663,t:1527872931526};\\\" ] }, { \\\"rt\\\": 13163, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 6, \\\"time_elapsed\\\": 136595, \\\"internal_node_id\\\": \\\"0.0-5.0-1.0\\\", \\\"subject\\\": \\\"2OEC4\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"whiskey\\\", \\\"condition\\\": \\\"115\\\", \\\"scenario\\\": \\\"acme\\\", \\\"question\\\": \\\"starts\\\", \\\"q\\\": 2, \\\"clicks\\\": 1, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XFull-YFull\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 1, \\\"answer\\\": [ \\\"E\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"X \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"U \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-H -D \\\", \\\"block\\\": \\\"triangular_scaffolded\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:527,y:672,t:1527872932772};\\\", \\\"{x:528,y:672,t:1527872932783};\\\", \\\"{x:529,y:672,t:1527872932885};\\\", \\\"{x:532,y:672,t:1527872932909};\\\", \\\"{x:535,y:672,t:1527872932927};\\\", \\\"{x:537,y:672,t:1527872932943};\\\", \\\"{x:538,y:669,t:1527872932959};\\\", \\\"{x:540,y:665,t:1527872932977};\\\", \\\"{x:541,y:665,t:1527872933598};\\\", \\\"{x:542,y:665,t:1527872933611};\\\", \\\"{x:545,y:665,t:1527872933627};\\\", \\\"{x:547,y:665,t:1527872933643};\\\", \\\"{x:553,y:665,t:1527872933661};\\\", \\\"{x:558,y:665,t:1527872933677};\\\", \\\"{x:566,y:665,t:1527872933694};\\\", \\\"{x:574,y:666,t:1527872933709};\\\", \\\"{x:583,y:668,t:1527872933727};\\\", \\\"{x:590,y:670,t:1527872933744};\\\", \\\"{x:600,y:672,t:1527872933760};\\\", \\\"{x:613,y:676,t:1527872933777};\\\", \\\"{x:625,y:678,t:1527872933793};\\\", \\\"{x:640,y:680,t:1527872933810};\\\", \\\"{x:654,y:682,t:1527872933826};\\\", \\\"{x:666,y:683,t:1527872933843};\\\", \\\"{x:673,y:685,t:1527872933860};\\\", \\\"{x:677,y:685,t:1527872933876};\\\", \\\"{x:678,y:685,t:1527872933893};\\\", \\\"{x:678,y:684,t:1527872933910};\\\", \\\"{x:678,y:683,t:1527872934278};\\\", \\\"{x:678,y:682,t:1527872934293};\\\", \\\"{x:681,y:682,t:1527872934391};\\\", \\\"{x:683,y:682,t:1527872934398};\\\", \\\"{x:685,y:682,t:1527872934410};\\\", \\\"{x:688,y:682,t:1527872934428};\\\", \\\"{x:692,y:682,t:1527872934444};\\\", \\\"{x:697,y:682,t:1527872934460};\\\", \\\"{x:706,y:682,t:1527872934478};\\\", \\\"{x:712,y:682,t:1527872934494};\\\", \\\"{x:719,y:681,t:1527872934511};\\\", \\\"{x:727,y:681,t:1527872934528};\\\", \\\"{x:734,y:679,t:1527872934545};\\\", \\\"{x:741,y:679,t:1527872934560};\\\", \\\"{x:747,y:679,t:1527872934577};\\\", \\\"{x:753,y:679,t:1527872934595};\\\", \\\"{x:758,y:679,t:1527872934610};\\\", \\\"{x:761,y:679,t:1527872934627};\\\", \\\"{x:766,y:679,t:1527872934645};\\\", \\\"{x:771,y:679,t:1527872934661};\\\", \\\"{x:777,y:678,t:1527872934678};\\\", \\\"{x:780,y:678,t:1527872934694};\\\", \\\"{x:784,y:678,t:1527872934710};\\\", \\\"{x:789,y:677,t:1527872934728};\\\", \\\"{x:794,y:677,t:1527872934744};\\\", \\\"{x:804,y:676,t:1527872934761};\\\", \\\"{x:811,y:675,t:1527872934777};\\\", \\\"{x:821,y:675,t:1527872934795};\\\", \\\"{x:832,y:675,t:1527872934811};\\\", \\\"{x:840,y:675,t:1527872934827};\\\", \\\"{x:856,y:672,t:1527872934845};\\\", \\\"{x:874,y:663,t:1527872934861};\\\", \\\"{x:912,y:653,t:1527872934878};\\\", \\\"{x:933,y:646,t:1527872934895};\\\", \\\"{x:954,y:641,t:1527872934911};\\\", \\\"{x:975,y:635,t:1527872934928};\\\", \\\"{x:996,y:630,t:1527872934945};\\\", \\\"{x:1017,y:624,t:1527872934963};\\\", \\\"{x:1043,y:622,t:1527872934978};\\\", \\\"{x:1080,y:618,t:1527872934994};\\\", \\\"{x:1113,y:618,t:1527872935011};\\\", \\\"{x:1143,y:618,t:1527872935027};\\\", \\\"{x:1170,y:618,t:1527872935044};\\\", \\\"{x:1207,y:618,t:1527872935061};\\\", \\\"{x:1226,y:618,t:1527872935077};\\\", \\\"{x:1237,y:618,t:1527872935094};\\\", \\\"{x:1243,y:618,t:1527872935111};\\\", \\\"{x:1247,y:618,t:1527872935127};\\\", \\\"{x:1249,y:617,t:1527872935145};\\\", \\\"{x:1253,y:617,t:1527872935162};\\\", \\\"{x:1259,y:614,t:1527872935178};\\\", \\\"{x:1266,y:612,t:1527872935195};\\\", \\\"{x:1271,y:610,t:1527872935211};\\\", \\\"{x:1275,y:608,t:1527872935228};\\\", \\\"{x:1276,y:607,t:1527872935470};\\\", \\\"{x:1277,y:602,t:1527872935478};\\\", \\\"{x:1281,y:594,t:1527872935495};\\\", \\\"{x:1289,y:586,t:1527872935512};\\\", \\\"{x:1300,y:578,t:1527872935529};\\\", \\\"{x:1313,y:570,t:1527872935545};\\\", \\\"{x:1329,y:558,t:1527872935562};\\\", \\\"{x:1341,y:547,t:1527872935579};\\\", \\\"{x:1350,y:541,t:1527872935595};\\\", \\\"{x:1358,y:531,t:1527872935612};\\\", \\\"{x:1363,y:524,t:1527872935629};\\\", \\\"{x:1366,y:520,t:1527872935645};\\\", \\\"{x:1372,y:516,t:1527872935662};\\\", \\\"{x:1376,y:514,t:1527872935678};\\\", \\\"{x:1379,y:511,t:1527872935695};\\\", \\\"{x:1380,y:509,t:1527872935712};\\\", \\\"{x:1382,y:508,t:1527872935729};\\\", \\\"{x:1385,y:506,t:1527872935745};\\\", \\\"{x:1388,y:505,t:1527872935762};\\\", \\\"{x:1389,y:505,t:1527872935779};\\\", \\\"{x:1392,y:504,t:1527872935795};\\\", \\\"{x:1395,y:502,t:1527872935812};\\\", \\\"{x:1397,y:502,t:1527872935829};\\\", \\\"{x:1402,y:502,t:1527872935845};\\\", \\\"{x:1406,y:502,t:1527872935862};\\\", \\\"{x:1412,y:502,t:1527872935879};\\\", \\\"{x:1418,y:502,t:1527872935896};\\\", \\\"{x:1424,y:502,t:1527872935912};\\\", \\\"{x:1428,y:502,t:1527872935929};\\\", \\\"{x:1433,y:502,t:1527872935946};\\\", \\\"{x:1435,y:502,t:1527872935962};\\\", \\\"{x:1438,y:502,t:1527872935979};\\\", \\\"{x:1439,y:502,t:1527872935996};\\\", \\\"{x:1439,y:501,t:1527872936206};\\\", \\\"{x:1438,y:500,t:1527872936447};\\\", \\\"{x:1438,y:499,t:1527872939638};\\\", \\\"{x:1436,y:499,t:1527872939648};\\\", \\\"{x:1432,y:502,t:1527872939665};\\\", \\\"{x:1428,y:507,t:1527872939682};\\\", \\\"{x:1425,y:512,t:1527872939698};\\\", \\\"{x:1424,y:516,t:1527872939715};\\\", \\\"{x:1423,y:519,t:1527872939732};\\\", \\\"{x:1423,y:522,t:1527872939748};\\\", \\\"{x:1423,y:524,t:1527872939765};\\\", \\\"{x:1422,y:527,t:1527872939782};\\\", \\\"{x:1422,y:529,t:1527872939798};\\\", \\\"{x:1422,y:532,t:1527872939816};\\\", \\\"{x:1422,y:536,t:1527872939832};\\\", \\\"{x:1420,y:541,t:1527872939848};\\\", \\\"{x:1420,y:546,t:1527872939866};\\\", \\\"{x:1420,y:553,t:1527872939882};\\\", \\\"{x:1418,y:561,t:1527872939901};\\\", \\\"{x:1418,y:567,t:1527872939914};\\\", \\\"{x:1416,y:577,t:1527872939932};\\\", \\\"{x:1414,y:588,t:1527872939947};\\\", \\\"{x:1410,y:604,t:1527872939964};\\\", \\\"{x:1390,y:623,t:1527872939981};\\\", \\\"{x:1389,y:623,t:1527872939997};\\\", \\\"{x:1389,y:624,t:1527872940527};\\\", \\\"{x:1389,y:625,t:1527872940534};\\\", \\\"{x:1389,y:626,t:1527872940549};\\\", \\\"{x:1389,y:627,t:1527872940566};\\\", \\\"{x:1389,y:628,t:1527872940630};\\\", \\\"{x:1389,y:629,t:1527872940638};\\\", \\\"{x:1389,y:630,t:1527872940663};\\\", \\\"{x:1389,y:632,t:1527872940678};\\\", \\\"{x:1391,y:637,t:1527872940686};\\\", \\\"{x:1393,y:640,t:1527872940699};\\\", \\\"{x:1395,y:647,t:1527872940715};\\\", \\\"{x:1395,y:655,t:1527872940732};\\\", \\\"{x:1399,y:663,t:1527872940749};\\\", \\\"{x:1399,y:668,t:1527872940765};\\\", \\\"{x:1399,y:669,t:1527872940781};\\\", \\\"{x:1399,y:671,t:1527872940799};\\\", \\\"{x:1398,y:671,t:1527872940903};\\\", \\\"{x:1398,y:670,t:1527872940918};\\\", \\\"{x:1398,y:669,t:1527872940934};\\\", \\\"{x:1398,y:667,t:1527872940949};\\\", \\\"{x:1398,y:665,t:1527872940966};\\\", \\\"{x:1401,y:661,t:1527872940983};\\\", \\\"{x:1403,y:658,t:1527872940999};\\\", \\\"{x:1405,y:653,t:1527872941016};\\\", \\\"{x:1407,y:650,t:1527872941033};\\\", \\\"{x:1409,y:645,t:1527872941050};\\\", \\\"{x:1410,y:640,t:1527872941066};\\\", \\\"{x:1413,y:636,t:1527872941083};\\\", \\\"{x:1415,y:633,t:1527872941099};\\\", \\\"{x:1416,y:628,t:1527872941116};\\\", \\\"{x:1418,y:623,t:1527872941133};\\\", \\\"{x:1421,y:616,t:1527872941150};\\\", \\\"{x:1424,y:609,t:1527872941166};\\\", \\\"{x:1427,y:601,t:1527872941183};\\\", \\\"{x:1432,y:594,t:1527872941199};\\\", \\\"{x:1434,y:590,t:1527872941216};\\\", \\\"{x:1438,y:585,t:1527872941232};\\\", \\\"{x:1440,y:582,t:1527872941248};\\\", \\\"{x:1443,y:578,t:1527872941265};\\\", \\\"{x:1447,y:572,t:1527872941283};\\\", \\\"{x:1450,y:569,t:1527872941299};\\\", \\\"{x:1452,y:566,t:1527872941316};\\\", \\\"{x:1454,y:564,t:1527872941332};\\\", \\\"{x:1457,y:559,t:1527872941348};\\\", \\\"{x:1461,y:552,t:1527872941366};\\\", \\\"{x:1467,y:543,t:1527872941383};\\\", \\\"{x:1474,y:536,t:1527872941399};\\\", \\\"{x:1479,y:529,t:1527872941416};\\\", \\\"{x:1484,y:521,t:1527872941432};\\\", \\\"{x:1492,y:511,t:1527872941448};\\\", \\\"{x:1498,y:504,t:1527872941466};\\\", \\\"{x:1503,y:495,t:1527872941483};\\\", \\\"{x:1511,y:484,t:1527872941500};\\\", \\\"{x:1516,y:478,t:1527872941516};\\\", \\\"{x:1522,y:470,t:1527872941533};\\\", \\\"{x:1535,y:448,t:1527872941549};\\\", \\\"{x:1537,y:446,t:1527872941566};\\\", \\\"{x:1540,y:443,t:1527872941582};\\\", \\\"{x:1542,y:439,t:1527872941600};\\\", \\\"{x:1546,y:434,t:1527872941617};\\\", \\\"{x:1547,y:433,t:1527872941634};\\\", \\\"{x:1550,y:432,t:1527872941650};\\\", \\\"{x:1556,y:430,t:1527872941666};\\\", \\\"{x:1560,y:430,t:1527872941683};\\\", \\\"{x:1563,y:430,t:1527872941700};\\\", \\\"{x:1569,y:434,t:1527872941716};\\\", \\\"{x:1575,y:439,t:1527872941733};\\\", \\\"{x:1582,y:446,t:1527872941750};\\\", \\\"{x:1586,y:450,t:1527872941766};\\\", \\\"{x:1590,y:455,t:1527872941783};\\\", \\\"{x:1592,y:458,t:1527872941800};\\\", \\\"{x:1595,y:462,t:1527872941816};\\\", \\\"{x:1598,y:466,t:1527872941833};\\\", \\\"{x:1600,y:469,t:1527872941850};\\\", \\\"{x:1601,y:471,t:1527872941866};\\\", \\\"{x:1603,y:471,t:1527872941958};\\\", \\\"{x:1604,y:470,t:1527872941967};\\\", \\\"{x:1606,y:464,t:1527872941983};\\\", \\\"{x:1608,y:460,t:1527872941999};\\\", \\\"{x:1611,y:454,t:1527872942016};\\\", \\\"{x:1612,y:450,t:1527872942033};\\\", \\\"{x:1612,y:449,t:1527872942049};\\\", \\\"{x:1612,y:447,t:1527872942066};\\\", \\\"{x:1613,y:446,t:1527872942093};\\\", \\\"{x:1613,y:444,t:1527872942124};\\\", \\\"{x:1614,y:443,t:1527872942133};\\\", \\\"{x:1615,y:442,t:1527872942149};\\\", \\\"{x:1616,y:440,t:1527872942342};\\\", \\\"{x:1616,y:439,t:1527872942373};\\\", \\\"{x:1616,y:438,t:1527872942405};\\\", \\\"{x:1616,y:437,t:1527872942437};\\\", \\\"{x:1616,y:436,t:1527872942461};\\\", \\\"{x:1616,y:435,t:1527872942486};\\\", \\\"{x:1616,y:436,t:1527872942791};\\\", \\\"{x:1616,y:441,t:1527872942801};\\\", \\\"{x:1605,y:458,t:1527872942817};\\\", \\\"{x:1585,y:472,t:1527872942834};\\\", \\\"{x:1529,y:491,t:1527872942850};\\\", \\\"{x:1428,y:513,t:1527872942867};\\\", \\\"{x:1273,y:533,t:1527872942885};\\\", \\\"{x:1036,y:533,t:1527872942900};\\\", \\\"{x:785,y:533,t:1527872942919};\\\", \\\"{x:632,y:533,t:1527872942934};\\\", \\\"{x:628,y:531,t:1527872942950};\\\", \\\"{x:624,y:531,t:1527872943191};\\\", \\\"{x:617,y:531,t:1527872943201};\\\", \\\"{x:594,y:534,t:1527872943218};\\\", \\\"{x:560,y:535,t:1527872943235};\\\", \\\"{x:537,y:535,t:1527872943252};\\\", \\\"{x:518,y:535,t:1527872943267};\\\", \\\"{x:508,y:535,t:1527872943285};\\\", \\\"{x:503,y:536,t:1527872943301};\\\", \\\"{x:501,y:536,t:1527872943317};\\\", \\\"{x:497,y:538,t:1527872943335};\\\", \\\"{x:491,y:542,t:1527872943351};\\\", \\\"{x:480,y:544,t:1527872943368};\\\", \\\"{x:474,y:545,t:1527872943385};\\\", \\\"{x:466,y:549,t:1527872943401};\\\", \\\"{x:454,y:556,t:1527872943418};\\\", \\\"{x:439,y:562,t:1527872943434};\\\", \\\"{x:425,y:567,t:1527872943452};\\\", \\\"{x:414,y:569,t:1527872943469};\\\", \\\"{x:404,y:571,t:1527872943485};\\\", \\\"{x:396,y:573,t:1527872943501};\\\", \\\"{x:392,y:575,t:1527872943518};\\\", \\\"{x:389,y:576,t:1527872943534};\\\", \\\"{x:388,y:577,t:1527872943551};\\\", \\\"{x:387,y:578,t:1527872943589};\\\", \\\"{x:386,y:578,t:1527872943602};\\\", \\\"{x:386,y:579,t:1527872943621};\\\", \\\"{x:385,y:579,t:1527872943635};\\\", \\\"{x:383,y:581,t:1527872943652};\\\", \\\"{x:379,y:583,t:1527872943669};\\\", \\\"{x:373,y:587,t:1527872943685};\\\", \\\"{x:365,y:589,t:1527872943702};\\\", \\\"{x:353,y:592,t:1527872943719};\\\", \\\"{x:336,y:592,t:1527872943735};\\\", \\\"{x:313,y:592,t:1527872943752};\\\", \\\"{x:282,y:592,t:1527872943769};\\\", \\\"{x:245,y:592,t:1527872943788};\\\", \\\"{x:202,y:584,t:1527872943801};\\\", \\\"{x:183,y:580,t:1527872943819};\\\", \\\"{x:174,y:579,t:1527872943835};\\\", \\\"{x:173,y:579,t:1527872943851};\\\", \\\"{x:174,y:580,t:1527872944030};\\\", \\\"{x:174,y:581,t:1527872944037};\\\", \\\"{x:174,y:583,t:1527872944053};\\\", \\\"{x:174,y:588,t:1527872944068};\\\", \\\"{x:174,y:596,t:1527872944085};\\\", \\\"{x:173,y:600,t:1527872944101};\\\", \\\"{x:172,y:604,t:1527872944118};\\\", \\\"{x:168,y:611,t:1527872944136};\\\", \\\"{x:164,y:618,t:1527872944152};\\\", \\\"{x:161,y:622,t:1527872944169};\\\", \\\"{x:160,y:624,t:1527872944186};\\\", \\\"{x:159,y:626,t:1527872944202};\\\", \\\"{x:158,y:628,t:1527872944219};\\\", \\\"{x:157,y:629,t:1527872944235};\\\", \\\"{x:157,y:630,t:1527872944253};\\\", \\\"{x:156,y:631,t:1527872944277};\\\", \\\"{x:156,y:632,t:1527872944292};\\\", \\\"{x:155,y:633,t:1527872944309};\\\", \\\"{x:160,y:634,t:1527872944604};\\\", \\\"{x:173,y:638,t:1527872944618};\\\", \\\"{x:204,y:646,t:1527872944636};\\\", \\\"{x:246,y:659,t:1527872944653};\\\", \\\"{x:297,y:675,t:1527872944669};\\\", \\\"{x:375,y:696,t:1527872944685};\\\", \\\"{x:410,y:706,t:1527872944703};\\\", \\\"{x:434,y:712,t:1527872944718};\\\", \\\"{x:449,y:717,t:1527872944737};\\\", \\\"{x:457,y:719,t:1527872944753};\\\", \\\"{x:458,y:719,t:1527872944797};\\\", \\\"{x:458,y:718,t:1527872944821};\\\", \\\"{x:458,y:717,t:1527872944836};\\\", \\\"{x:459,y:713,t:1527872944853};\\\", \\\"{x:459,y:710,t:1527872944870};\\\", \\\"{x:459,y:709,t:1527872944886};\\\", \\\"{x:461,y:708,t:1527872944903};\\\", \\\"{x:461,y:707,t:1527872944920};\\\", \\\"{x:462,y:707,t:1527872944950};\\\", \\\"{x:463,y:707,t:1527872944958};\\\", \\\"{x:465,y:707,t:1527872945022};\\\", \\\"{x:465,y:708,t:1527872945036};\\\", \\\"{x:466,y:708,t:1527872945053};\\\", \\\"{x:468,y:712,t:1527872945070};\\\", \\\"{x:470,y:714,t:1527872945086};\\\", \\\"{x:470,y:715,t:1527872945103};\\\", \\\"{x:471,y:715,t:1527872945678};\\\", \\\"{x:472,y:715,t:1527872945686};\\\", \\\"{x:474,y:715,t:1527872945703};\\\", \\\"{x:476,y:715,t:1527872945720};\\\", \\\"{x:479,y:715,t:1527872945737};\\\", \\\"{x:480,y:715,t:1527872945753};\\\", \\\"{x:481,y:715,t:1527872945780};\\\" ] }, { \\\"rt\\\": 22309, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 7, \\\"time_elapsed\\\": 160135, \\\"internal_node_id\\\": \\\"0.0-5.0-2.0\\\", \\\"subject\\\": \\\"2OEC4\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"whiskey\\\", \\\"condition\\\": \\\"115\\\", \\\"scenario\\\": \\\"acme\\\", \\\"question\\\": \\\"meets\\\", \\\"q\\\": 3, \\\"clicks\\\": 3, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XFull-YFull\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 1, \\\"answer\\\": [ \\\"Z\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"X \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"U \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"\\\", \\\"block\\\": \\\"triangular_scaffolded\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:482,y:714,t:1527872946805};\\\", \\\"{x:483,y:712,t:1527872946821};\\\", \\\"{x:483,y:710,t:1527872946837};\\\", \\\"{x:484,y:707,t:1527872946854};\\\", \\\"{x:485,y:706,t:1527872946870};\\\", \\\"{x:485,y:704,t:1527872946888};\\\", \\\"{x:486,y:702,t:1527872946905};\\\", \\\"{x:487,y:700,t:1527872946922};\\\", \\\"{x:488,y:700,t:1527872946938};\\\", \\\"{x:496,y:683,t:1527872947038};\\\", \\\"{x:498,y:677,t:1527872947054};\\\", \\\"{x:500,y:671,t:1527872947070};\\\", \\\"{x:502,y:667,t:1527872947088};\\\", \\\"{x:503,y:663,t:1527872947105};\\\", \\\"{x:504,y:660,t:1527872947122};\\\", \\\"{x:506,y:656,t:1527872947138};\\\", \\\"{x:506,y:654,t:1527872947155};\\\", \\\"{x:507,y:652,t:1527872947171};\\\", \\\"{x:507,y:651,t:1527872947213};\\\", \\\"{x:507,y:650,t:1527872947760};\\\", \\\"{x:507,y:648,t:1527872947772};\\\", \\\"{x:507,y:647,t:1527872947837};\\\", \\\"{x:507,y:645,t:1527872948958};\\\", \\\"{x:508,y:644,t:1527872948982};\\\", \\\"{x:508,y:643,t:1527872949014};\\\", \\\"{x:509,y:641,t:1527872949023};\\\", \\\"{x:509,y:639,t:1527872949039};\\\", \\\"{x:509,y:637,t:1527872949056};\\\", \\\"{x:509,y:634,t:1527872949073};\\\", \\\"{x:509,y:633,t:1527872949088};\\\", \\\"{x:509,y:631,t:1527872949105};\\\", \\\"{x:509,y:627,t:1527872949123};\\\", \\\"{x:508,y:624,t:1527872949138};\\\", \\\"{x:507,y:622,t:1527872949156};\\\", \\\"{x:506,y:620,t:1527872949173};\\\", \\\"{x:506,y:619,t:1527872949301};\\\", \\\"{x:506,y:618,t:1527872949308};\\\", \\\"{x:506,y:614,t:1527872949323};\\\", \\\"{x:507,y:608,t:1527872949341};\\\", \\\"{x:509,y:603,t:1527872949356};\\\", \\\"{x:512,y:595,t:1527872949372};\\\", \\\"{x:512,y:594,t:1527872949390};\\\", \\\"{x:512,y:592,t:1527872949407};\\\", \\\"{x:516,y:595,t:1527872952782};\\\", \\\"{x:524,y:604,t:1527872952792};\\\", \\\"{x:546,y:622,t:1527872952810};\\\", \\\"{x:569,y:639,t:1527872952826};\\\", \\\"{x:591,y:653,t:1527872952840};\\\", \\\"{x:615,y:666,t:1527872952855};\\\", \\\"{x:638,y:675,t:1527872952876};\\\", \\\"{x:674,y:683,t:1527872952893};\\\", \\\"{x:695,y:684,t:1527872952909};\\\", \\\"{x:713,y:684,t:1527872952926};\\\", \\\"{x:734,y:684,t:1527872952943};\\\", \\\"{x:754,y:682,t:1527872952959};\\\", \\\"{x:776,y:681,t:1527872952976};\\\", \\\"{x:793,y:679,t:1527872952992};\\\", \\\"{x:804,y:679,t:1527872953009};\\\", \\\"{x:813,y:679,t:1527872953026};\\\", \\\"{x:819,y:680,t:1527872953043};\\\", \\\"{x:826,y:683,t:1527872953058};\\\", \\\"{x:834,y:686,t:1527872953076};\\\", \\\"{x:846,y:692,t:1527872953093};\\\", \\\"{x:852,y:694,t:1527872953109};\\\", \\\"{x:854,y:694,t:1527872953126};\\\", \\\"{x:855,y:694,t:1527872953143};\\\", \\\"{x:856,y:694,t:1527872953189};\\\", \\\"{x:857,y:694,t:1527872953204};\\\", \\\"{x:858,y:694,t:1527872953575};\\\", \\\"{x:860,y:694,t:1527872953593};\\\", \\\"{x:862,y:693,t:1527872953621};\\\", \\\"{x:863,y:693,t:1527872953654};\\\", \\\"{x:864,y:693,t:1527872953661};\\\", \\\"{x:865,y:693,t:1527872953677};\\\", \\\"{x:866,y:692,t:1527872953694};\\\", \\\"{x:867,y:691,t:1527872953710};\\\", \\\"{x:869,y:690,t:1527872953765};\\\", \\\"{x:867,y:690,t:1527872954246};\\\", \\\"{x:866,y:690,t:1527872954260};\\\", \\\"{x:852,y:691,t:1527872954277};\\\", \\\"{x:834,y:691,t:1527872954294};\\\", \\\"{x:815,y:691,t:1527872954310};\\\", \\\"{x:793,y:691,t:1527872954328};\\\", \\\"{x:773,y:691,t:1527872954345};\\\", \\\"{x:752,y:686,t:1527872954360};\\\", \\\"{x:726,y:678,t:1527872954378};\\\", \\\"{x:698,y:669,t:1527872954393};\\\", \\\"{x:671,y:662,t:1527872954411};\\\", \\\"{x:650,y:652,t:1527872954427};\\\", \\\"{x:635,y:645,t:1527872954445};\\\", \\\"{x:628,y:643,t:1527872954461};\\\", \\\"{x:625,y:642,t:1527872954476};\\\", \\\"{x:618,y:642,t:1527872954494};\\\", \\\"{x:600,y:637,t:1527872954510};\\\", \\\"{x:573,y:634,t:1527872954527};\\\", \\\"{x:545,y:629,t:1527872954544};\\\", \\\"{x:521,y:626,t:1527872954561};\\\", \\\"{x:499,y:623,t:1527872954577};\\\", \\\"{x:488,y:620,t:1527872954595};\\\", \\\"{x:481,y:617,t:1527872954611};\\\", \\\"{x:479,y:616,t:1527872954627};\\\", \\\"{x:479,y:615,t:1527872954668};\\\", \\\"{x:483,y:615,t:1527872954677};\\\", \\\"{x:503,y:615,t:1527872954694};\\\", \\\"{x:523,y:615,t:1527872954711};\\\", \\\"{x:551,y:615,t:1527872954727};\\\", \\\"{x:585,y:615,t:1527872954744};\\\", \\\"{x:615,y:615,t:1527872954761};\\\", \\\"{x:638,y:618,t:1527872954777};\\\", \\\"{x:652,y:618,t:1527872954794};\\\", \\\"{x:655,y:618,t:1527872954811};\\\", \\\"{x:656,y:618,t:1527872954829};\\\", \\\"{x:657,y:618,t:1527872954845};\\\", \\\"{x:659,y:617,t:1527872954861};\\\", \\\"{x:662,y:614,t:1527872954877};\\\", \\\"{x:664,y:612,t:1527872954895};\\\", \\\"{x:666,y:610,t:1527872954911};\\\", \\\"{x:668,y:608,t:1527872954927};\\\", \\\"{x:674,y:605,t:1527872954944};\\\", \\\"{x:680,y:602,t:1527872954961};\\\", \\\"{x:687,y:599,t:1527872954977};\\\", \\\"{x:693,y:598,t:1527872954994};\\\", \\\"{x:700,y:595,t:1527872955011};\\\", \\\"{x:709,y:593,t:1527872955028};\\\", \\\"{x:722,y:591,t:1527872955044};\\\", \\\"{x:745,y:591,t:1527872955063};\\\", \\\"{x:757,y:591,t:1527872955078};\\\", \\\"{x:764,y:591,t:1527872955093};\\\", \\\"{x:766,y:591,t:1527872955111};\\\", \\\"{x:770,y:589,t:1527872955128};\\\", \\\"{x:777,y:586,t:1527872955144};\\\", \\\"{x:786,y:582,t:1527872955161};\\\", \\\"{x:794,y:579,t:1527872955179};\\\", \\\"{x:802,y:576,t:1527872955194};\\\", \\\"{x:804,y:574,t:1527872955212};\\\", \\\"{x:806,y:573,t:1527872955228};\\\", \\\"{x:807,y:573,t:1527872955244};\\\", \\\"{x:808,y:572,t:1527872955261};\\\", \\\"{x:805,y:572,t:1527872955309};\\\", \\\"{x:801,y:572,t:1527872955317};\\\", \\\"{x:794,y:574,t:1527872955328};\\\", \\\"{x:778,y:576,t:1527872955346};\\\", \\\"{x:757,y:576,t:1527872955361};\\\", \\\"{x:732,y:576,t:1527872955378};\\\", \\\"{x:710,y:576,t:1527872955395};\\\", \\\"{x:693,y:576,t:1527872955411};\\\", \\\"{x:680,y:576,t:1527872955428};\\\", \\\"{x:675,y:576,t:1527872955445};\\\", \\\"{x:666,y:579,t:1527872955461};\\\", \\\"{x:658,y:580,t:1527872955478};\\\", \\\"{x:649,y:580,t:1527872955495};\\\", \\\"{x:635,y:581,t:1527872955511};\\\", \\\"{x:621,y:581,t:1527872955528};\\\", \\\"{x:611,y:581,t:1527872955546};\\\", \\\"{x:608,y:581,t:1527872955561};\\\", \\\"{x:606,y:582,t:1527872955579};\\\", \\\"{x:604,y:583,t:1527872955595};\\\", \\\"{x:602,y:584,t:1527872955611};\\\", \\\"{x:598,y:585,t:1527872955628};\\\", \\\"{x:591,y:587,t:1527872955644};\\\", \\\"{x:585,y:588,t:1527872955662};\\\", \\\"{x:579,y:588,t:1527872955678};\\\", \\\"{x:576,y:589,t:1527872955695};\\\", \\\"{x:572,y:591,t:1527872955712};\\\", \\\"{x:568,y:592,t:1527872955728};\\\", \\\"{x:565,y:594,t:1527872955745};\\\", \\\"{x:560,y:595,t:1527872955762};\\\", \\\"{x:554,y:598,t:1527872955778};\\\", \\\"{x:547,y:599,t:1527872955795};\\\", \\\"{x:540,y:600,t:1527872955812};\\\", \\\"{x:531,y:602,t:1527872955828};\\\", \\\"{x:512,y:603,t:1527872955845};\\\", \\\"{x:494,y:603,t:1527872955864};\\\", \\\"{x:469,y:603,t:1527872955878};\\\", \\\"{x:448,y:603,t:1527872955894};\\\", \\\"{x:437,y:603,t:1527872955912};\\\", \\\"{x:430,y:603,t:1527872955928};\\\", \\\"{x:427,y:603,t:1527872955945};\\\", \\\"{x:424,y:604,t:1527872955962};\\\", \\\"{x:417,y:606,t:1527872955978};\\\", \\\"{x:415,y:606,t:1527872955995};\\\", \\\"{x:411,y:607,t:1527872956012};\\\", \\\"{x:406,y:608,t:1527872956029};\\\", \\\"{x:400,y:609,t:1527872956044};\\\", \\\"{x:397,y:610,t:1527872956062};\\\", \\\"{x:393,y:612,t:1527872956078};\\\", \\\"{x:388,y:614,t:1527872956095};\\\", \\\"{x:385,y:615,t:1527872956112};\\\", \\\"{x:383,y:616,t:1527872956128};\\\", \\\"{x:381,y:616,t:1527872956145};\\\", \\\"{x:379,y:617,t:1527872956162};\\\", \\\"{x:375,y:617,t:1527872956179};\\\", \\\"{x:366,y:618,t:1527872956195};\\\", \\\"{x:352,y:618,t:1527872956213};\\\", \\\"{x:340,y:618,t:1527872956229};\\\", \\\"{x:324,y:620,t:1527872956245};\\\", \\\"{x:320,y:622,t:1527872956262};\\\", \\\"{x:316,y:623,t:1527872956279};\\\", \\\"{x:307,y:626,t:1527872956295};\\\", \\\"{x:287,y:627,t:1527872956312};\\\", \\\"{x:266,y:628,t:1527872956330};\\\", \\\"{x:257,y:630,t:1527872956345};\\\", \\\"{x:253,y:630,t:1527872956361};\\\", \\\"{x:250,y:630,t:1527872956379};\\\", \\\"{x:246,y:631,t:1527872956395};\\\", \\\"{x:240,y:631,t:1527872956412};\\\", \\\"{x:224,y:631,t:1527872956429};\\\", \\\"{x:216,y:630,t:1527872956445};\\\", \\\"{x:213,y:629,t:1527872956462};\\\", \\\"{x:210,y:627,t:1527872956541};\\\", \\\"{x:209,y:626,t:1527872956549};\\\", \\\"{x:207,y:625,t:1527872956562};\\\", \\\"{x:202,y:623,t:1527872956579};\\\", \\\"{x:199,y:622,t:1527872956595};\\\", \\\"{x:196,y:620,t:1527872956612};\\\", \\\"{x:193,y:618,t:1527872956630};\\\", \\\"{x:187,y:614,t:1527872956645};\\\", \\\"{x:178,y:609,t:1527872956662};\\\", \\\"{x:168,y:602,t:1527872956679};\\\", \\\"{x:161,y:598,t:1527872956696};\\\", \\\"{x:159,y:597,t:1527872956712};\\\", \\\"{x:160,y:596,t:1527872956756};\\\", \\\"{x:164,y:596,t:1527872956764};\\\", \\\"{x:171,y:594,t:1527872956779};\\\", \\\"{x:189,y:594,t:1527872956796};\\\", \\\"{x:216,y:594,t:1527872956813};\\\", \\\"{x:247,y:594,t:1527872956829};\\\", \\\"{x:263,y:594,t:1527872956846};\\\", \\\"{x:268,y:593,t:1527872956863};\\\", \\\"{x:268,y:592,t:1527872956893};\\\", \\\"{x:268,y:591,t:1527872956909};\\\", \\\"{x:267,y:589,t:1527872956917};\\\", \\\"{x:263,y:588,t:1527872956930};\\\", \\\"{x:247,y:584,t:1527872956946};\\\", \\\"{x:218,y:574,t:1527872956965};\\\", \\\"{x:178,y:563,t:1527872956981};\\\", \\\"{x:142,y:552,t:1527872956997};\\\", \\\"{x:129,y:545,t:1527872957012};\\\", \\\"{x:129,y:543,t:1527872957036};\\\", \\\"{x:131,y:543,t:1527872957052};\\\", \\\"{x:132,y:542,t:1527872957101};\\\", \\\"{x:132,y:543,t:1527872957197};\\\", \\\"{x:133,y:544,t:1527872957213};\\\", \\\"{x:137,y:546,t:1527872957229};\\\", \\\"{x:139,y:548,t:1527872957246};\\\", \\\"{x:141,y:550,t:1527872957262};\\\", \\\"{x:143,y:551,t:1527872957279};\\\", \\\"{x:145,y:552,t:1527872957296};\\\", \\\"{x:146,y:553,t:1527872957312};\\\", \\\"{x:146,y:554,t:1527872957329};\\\", \\\"{x:147,y:555,t:1527872957346};\\\", \\\"{x:150,y:557,t:1527872957363};\\\", \\\"{x:152,y:559,t:1527872957379};\\\", \\\"{x:153,y:561,t:1527872957397};\\\", \\\"{x:154,y:561,t:1527872957414};\\\", \\\"{x:154,y:562,t:1527872957629};\\\", \\\"{x:154,y:563,t:1527872957646};\\\", \\\"{x:154,y:566,t:1527872957663};\\\", \\\"{x:154,y:569,t:1527872957679};\\\", \\\"{x:157,y:573,t:1527872957696};\\\", \\\"{x:160,y:576,t:1527872957714};\\\", \\\"{x:160,y:577,t:1527872957730};\\\", \\\"{x:161,y:579,t:1527872957746};\\\", \\\"{x:161,y:580,t:1527872957763};\\\", \\\"{x:161,y:582,t:1527872957789};\\\", \\\"{x:161,y:583,t:1527872957821};\\\", \\\"{x:161,y:585,t:1527872957837};\\\", \\\"{x:161,y:586,t:1527872957847};\\\", \\\"{x:161,y:589,t:1527872957864};\\\", \\\"{x:161,y:590,t:1527872957880};\\\", \\\"{x:161,y:591,t:1527872957896};\\\", \\\"{x:161,y:592,t:1527872957913};\\\", \\\"{x:160,y:593,t:1527872957948};\\\", \\\"{x:160,y:594,t:1527872958061};\\\", \\\"{x:160,y:594,t:1527872958077};\\\", \\\"{x:160,y:593,t:1527872958285};\\\", \\\"{x:160,y:592,t:1527872958301};\\\", \\\"{x:161,y:592,t:1527872958314};\\\", \\\"{x:161,y:587,t:1527872958330};\\\", \\\"{x:163,y:583,t:1527872958349};\\\", \\\"{x:163,y:582,t:1527872958364};\\\", \\\"{x:163,y:579,t:1527872958382};\\\", \\\"{x:163,y:578,t:1527872958397};\\\", \\\"{x:163,y:577,t:1527872958414};\\\", \\\"{x:163,y:576,t:1527872958430};\\\", \\\"{x:163,y:575,t:1527872958453};\\\", \\\"{x:162,y:575,t:1527872958533};\\\", \\\"{x:162,y:576,t:1527872958548};\\\", \\\"{x:161,y:578,t:1527872958565};\\\", \\\"{x:161,y:581,t:1527872958581};\\\", \\\"{x:160,y:583,t:1527872958598};\\\", \\\"{x:159,y:585,t:1527872958615};\\\", \\\"{x:159,y:586,t:1527872958630};\\\", \\\"{x:159,y:587,t:1527872958648};\\\", \\\"{x:159,y:589,t:1527872958665};\\\", \\\"{x:159,y:591,t:1527872958681};\\\", \\\"{x:157,y:592,t:1527872958697};\\\", \\\"{x:157,y:593,t:1527872958892};\\\", \\\"{x:156,y:593,t:1527872958908};\\\", \\\"{x:158,y:595,t:1527872958941};\\\", \\\"{x:167,y:598,t:1527872958949};\\\", \\\"{x:178,y:600,t:1527872958964};\\\", \\\"{x:219,y:612,t:1527872958981};\\\", \\\"{x:247,y:619,t:1527872958997};\\\", \\\"{x:273,y:623,t:1527872959014};\\\", \\\"{x:297,y:630,t:1527872959031};\\\", \\\"{x:314,y:637,t:1527872959047};\\\", \\\"{x:326,y:640,t:1527872959064};\\\", \\\"{x:337,y:646,t:1527872959082};\\\", \\\"{x:346,y:651,t:1527872959098};\\\", \\\"{x:354,y:656,t:1527872959114};\\\", \\\"{x:360,y:661,t:1527872959131};\\\", \\\"{x:365,y:664,t:1527872959148};\\\", \\\"{x:368,y:667,t:1527872959164};\\\", \\\"{x:371,y:670,t:1527872959182};\\\", \\\"{x:373,y:672,t:1527872959198};\\\", \\\"{x:378,y:675,t:1527872959214};\\\", \\\"{x:384,y:678,t:1527872959231};\\\", \\\"{x:390,y:680,t:1527872959248};\\\", \\\"{x:398,y:682,t:1527872959264};\\\", \\\"{x:407,y:684,t:1527872959282};\\\", \\\"{x:416,y:689,t:1527872959299};\\\", \\\"{x:425,y:691,t:1527872959314};\\\", \\\"{x:434,y:693,t:1527872959331};\\\", \\\"{x:443,y:695,t:1527872959348};\\\", \\\"{x:451,y:698,t:1527872959364};\\\", \\\"{x:468,y:705,t:1527872959381};\\\", \\\"{x:480,y:707,t:1527872959399};\\\", \\\"{x:485,y:709,t:1527872959414};\\\", \\\"{x:489,y:710,t:1527872959431};\\\", \\\"{x:490,y:710,t:1527872959718};\\\", \\\"{x:490,y:711,t:1527872959749};\\\", \\\"{x:490,y:713,t:1527872968580};\\\", \\\"{x:491,y:714,t:1527872968589};\\\", \\\"{x:493,y:715,t:1527872968606};\\\", \\\"{x:493,y:716,t:1527872968622};\\\", \\\"{x:494,y:716,t:1527872968640};\\\", \\\"{x:495,y:716,t:1527872968655};\\\" ] }, { \\\"rt\\\": 70831, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 8, \\\"time_elapsed\\\": 232234, \\\"internal_node_id\\\": \\\"0.0-5.0-3.0\\\", \\\"subject\\\": \\\"2OEC4\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"whiskey\\\", \\\"condition\\\": \\\"115\\\", \\\"scenario\\\": \\\"acme\\\", \\\"question\\\": \\\"endtime\\\", \\\"q\\\": 4, \\\"clicks\\\": 1, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XFull-YFull\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 1, \\\"answer\\\": [ \\\"U\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"X \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"U \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-O -12 PM-12 PM-U -U -U -F -Z \\\", \\\"block\\\": \\\"triangular_scaffolded\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:498,y:715,t:1527872971830};\\\", \\\"{x:506,y:704,t:1527872971847};\\\", \\\"{x:510,y:695,t:1527872971856};\\\", \\\"{x:520,y:676,t:1527872971873};\\\", \\\"{x:520,y:675,t:1527872971891};\\\", \\\"{x:522,y:676,t:1527872972301};\\\", \\\"{x:525,y:679,t:1527872972310};\\\", \\\"{x:533,y:679,t:1527872972326};\\\", \\\"{x:544,y:679,t:1527872972342};\\\", \\\"{x:562,y:681,t:1527872972359};\\\", \\\"{x:583,y:684,t:1527872972376};\\\", \\\"{x:608,y:689,t:1527872972392};\\\", \\\"{x:654,y:696,t:1527872972409};\\\", \\\"{x:726,y:705,t:1527872972426};\\\", \\\"{x:802,y:716,t:1527872972443};\\\", \\\"{x:879,y:726,t:1527872972459};\\\", \\\"{x:957,y:737,t:1527872972476};\\\", \\\"{x:1048,y:751,t:1527872972493};\\\", \\\"{x:1091,y:758,t:1527872972510};\\\", \\\"{x:1122,y:762,t:1527872972526};\\\", \\\"{x:1127,y:762,t:1527872972543};\\\", \\\"{x:1127,y:761,t:1527872972559};\\\", \\\"{x:1129,y:761,t:1527872973045};\\\", \\\"{x:1136,y:764,t:1527872973060};\\\", \\\"{x:1170,y:781,t:1527872973077};\\\", \\\"{x:1197,y:786,t:1527872973094};\\\", \\\"{x:1218,y:791,t:1527872973110};\\\", \\\"{x:1245,y:797,t:1527872973127};\\\", \\\"{x:1283,y:806,t:1527872973143};\\\", \\\"{x:1312,y:811,t:1527872973160};\\\", \\\"{x:1344,y:819,t:1527872973178};\\\", \\\"{x:1367,y:825,t:1527872973193};\\\", \\\"{x:1392,y:831,t:1527872973210};\\\", \\\"{x:1412,y:837,t:1527872973228};\\\", \\\"{x:1432,y:843,t:1527872973243};\\\", \\\"{x:1450,y:848,t:1527872973260};\\\", \\\"{x:1473,y:856,t:1527872973277};\\\", \\\"{x:1486,y:859,t:1527872973293};\\\", \\\"{x:1503,y:864,t:1527872973310};\\\", \\\"{x:1511,y:868,t:1527872973327};\\\", \\\"{x:1520,y:872,t:1527872973344};\\\", \\\"{x:1526,y:876,t:1527872973360};\\\", \\\"{x:1531,y:881,t:1527872973377};\\\", \\\"{x:1535,y:887,t:1527872973394};\\\", \\\"{x:1536,y:890,t:1527872973410};\\\", \\\"{x:1538,y:893,t:1527872973427};\\\", \\\"{x:1540,y:896,t:1527872973444};\\\", \\\"{x:1540,y:897,t:1527872973460};\\\", \\\"{x:1542,y:900,t:1527872973477};\\\", \\\"{x:1544,y:902,t:1527872973495};\\\", \\\"{x:1547,y:905,t:1527872973510};\\\", \\\"{x:1551,y:910,t:1527872973528};\\\", \\\"{x:1557,y:914,t:1527872973544};\\\", \\\"{x:1559,y:916,t:1527872973561};\\\", \\\"{x:1561,y:917,t:1527872973577};\\\", \\\"{x:1565,y:920,t:1527872973594};\\\", \\\"{x:1567,y:921,t:1527872973611};\\\", \\\"{x:1571,y:924,t:1527872973628};\\\", \\\"{x:1576,y:928,t:1527872973644};\\\", \\\"{x:1582,y:932,t:1527872973661};\\\", \\\"{x:1585,y:935,t:1527872973677};\\\", \\\"{x:1591,y:939,t:1527872973694};\\\", \\\"{x:1595,y:940,t:1527872973711};\\\", \\\"{x:1598,y:942,t:1527872973727};\\\", \\\"{x:1598,y:943,t:1527872973745};\\\", \\\"{x:1599,y:943,t:1527872973761};\\\", \\\"{x:1600,y:945,t:1527872973777};\\\", \\\"{x:1601,y:945,t:1527872973794};\\\", \\\"{x:1603,y:947,t:1527872973811};\\\", \\\"{x:1604,y:947,t:1527872973837};\\\", \\\"{x:1604,y:948,t:1527872973853};\\\", \\\"{x:1605,y:949,t:1527872973870};\\\", \\\"{x:1606,y:951,t:1527872973885};\\\", \\\"{x:1606,y:953,t:1527872973894};\\\", \\\"{x:1609,y:955,t:1527872973912};\\\", \\\"{x:1609,y:957,t:1527872973928};\\\", \\\"{x:1611,y:959,t:1527872973944};\\\", \\\"{x:1612,y:961,t:1527872973961};\\\", \\\"{x:1612,y:962,t:1527872974013};\\\", \\\"{x:1614,y:963,t:1527872974028};\\\", \\\"{x:1614,y:964,t:1527872974044};\\\", \\\"{x:1614,y:963,t:1527872975277};\\\", \\\"{x:1614,y:962,t:1527872975301};\\\", \\\"{x:1614,y:954,t:1527872982741};\\\", \\\"{x:1614,y:950,t:1527872982755};\\\", \\\"{x:1612,y:934,t:1527872982771};\\\", \\\"{x:1591,y:906,t:1527872982789};\\\", \\\"{x:1576,y:888,t:1527872982805};\\\", \\\"{x:1560,y:879,t:1527872982822};\\\", \\\"{x:1546,y:868,t:1527872982838};\\\", \\\"{x:1531,y:854,t:1527872982855};\\\", \\\"{x:1520,y:839,t:1527872982872};\\\", \\\"{x:1514,y:827,t:1527872982889};\\\", \\\"{x:1508,y:813,t:1527872982905};\\\", \\\"{x:1498,y:789,t:1527872982922};\\\", \\\"{x:1491,y:772,t:1527872982939};\\\", \\\"{x:1489,y:766,t:1527872982954};\\\", \\\"{x:1489,y:763,t:1527872982971};\\\", \\\"{x:1486,y:746,t:1527872982989};\\\", \\\"{x:1484,y:740,t:1527872983005};\\\", \\\"{x:1479,y:729,t:1527872983021};\\\", \\\"{x:1471,y:710,t:1527872983039};\\\", \\\"{x:1460,y:686,t:1527872983054};\\\", \\\"{x:1449,y:669,t:1527872983072};\\\", \\\"{x:1435,y:653,t:1527872983088};\\\", \\\"{x:1416,y:639,t:1527872983106};\\\", \\\"{x:1390,y:621,t:1527872983122};\\\", \\\"{x:1365,y:603,t:1527872983139};\\\", \\\"{x:1348,y:593,t:1527872983155};\\\", \\\"{x:1336,y:588,t:1527872983172};\\\", \\\"{x:1335,y:588,t:1527872983189};\\\", \\\"{x:1334,y:588,t:1527872983205};\\\", \\\"{x:1329,y:589,t:1527872983222};\\\", \\\"{x:1327,y:592,t:1527872983239};\\\", \\\"{x:1324,y:598,t:1527872983256};\\\", \\\"{x:1321,y:612,t:1527872983272};\\\", \\\"{x:1317,y:629,t:1527872983292};\\\", \\\"{x:1314,y:649,t:1527872983307};\\\", \\\"{x:1313,y:673,t:1527872983321};\\\", \\\"{x:1313,y:698,t:1527872983338};\\\", \\\"{x:1313,y:725,t:1527872983356};\\\", \\\"{x:1313,y:757,t:1527872983372};\\\", \\\"{x:1326,y:803,t:1527872983388};\\\", \\\"{x:1338,y:829,t:1527872983405};\\\", \\\"{x:1346,y:850,t:1527872983422};\\\", \\\"{x:1350,y:867,t:1527872983438};\\\", \\\"{x:1354,y:878,t:1527872983456};\\\", \\\"{x:1356,y:885,t:1527872983472};\\\", \\\"{x:1358,y:891,t:1527872983488};\\\", \\\"{x:1358,y:894,t:1527872983506};\\\", \\\"{x:1358,y:896,t:1527872983622};\\\", \\\"{x:1358,y:897,t:1527872983639};\\\", \\\"{x:1358,y:899,t:1527872983656};\\\", \\\"{x:1358,y:902,t:1527872983673};\\\", \\\"{x:1357,y:907,t:1527872983689};\\\", \\\"{x:1355,y:910,t:1527872983705};\\\", \\\"{x:1354,y:912,t:1527872983722};\\\", \\\"{x:1354,y:914,t:1527872983738};\\\", \\\"{x:1353,y:916,t:1527872983754};\\\", \\\"{x:1350,y:922,t:1527872983771};\\\", \\\"{x:1348,y:926,t:1527872983788};\\\", \\\"{x:1347,y:928,t:1527872983805};\\\", \\\"{x:1346,y:931,t:1527872983822};\\\", \\\"{x:1346,y:932,t:1527872983839};\\\", \\\"{x:1344,y:934,t:1527872983855};\\\", \\\"{x:1344,y:935,t:1527872983965};\\\", \\\"{x:1344,y:937,t:1527872983973};\\\", \\\"{x:1344,y:939,t:1527872983989};\\\", \\\"{x:1344,y:943,t:1527872984007};\\\", \\\"{x:1343,y:947,t:1527872984022};\\\", \\\"{x:1340,y:954,t:1527872984039};\\\", \\\"{x:1334,y:963,t:1527872984056};\\\", \\\"{x:1329,y:972,t:1527872984073};\\\", \\\"{x:1326,y:981,t:1527872984089};\\\", \\\"{x:1324,y:987,t:1527872984106};\\\", \\\"{x:1322,y:991,t:1527872984122};\\\", \\\"{x:1321,y:995,t:1527872984139};\\\", \\\"{x:1320,y:996,t:1527872984156};\\\", \\\"{x:1319,y:998,t:1527872984171};\\\", \\\"{x:1319,y:996,t:1527872984277};\\\", \\\"{x:1319,y:995,t:1527872984289};\\\", \\\"{x:1323,y:989,t:1527872984306};\\\", \\\"{x:1324,y:985,t:1527872984323};\\\", \\\"{x:1326,y:982,t:1527872984339};\\\", \\\"{x:1327,y:979,t:1527872984356};\\\", \\\"{x:1328,y:977,t:1527872984373};\\\", \\\"{x:1330,y:977,t:1527872984501};\\\", \\\"{x:1330,y:974,t:1527872991234};\\\", \\\"{x:1330,y:971,t:1527872991248};\\\", \\\"{x:1323,y:963,t:1527872991257};\\\", \\\"{x:1308,y:953,t:1527872991269};\\\", \\\"{x:1270,y:937,t:1527872991285};\\\", \\\"{x:1251,y:927,t:1527872991302};\\\", \\\"{x:1244,y:923,t:1527872991319};\\\", \\\"{x:1238,y:919,t:1527872991335};\\\", \\\"{x:1231,y:914,t:1527872991351};\\\", \\\"{x:1215,y:906,t:1527872991368};\\\", \\\"{x:1201,y:905,t:1527872991384};\\\", \\\"{x:1185,y:905,t:1527872991401};\\\", \\\"{x:1168,y:911,t:1527872991418};\\\", \\\"{x:1141,y:922,t:1527872991435};\\\", \\\"{x:1114,y:924,t:1527872991451};\\\", \\\"{x:1092,y:919,t:1527872991468};\\\", \\\"{x:1068,y:901,t:1527872991485};\\\", \\\"{x:1025,y:870,t:1527872991502};\\\", \\\"{x:976,y:840,t:1527872991519};\\\", \\\"{x:951,y:821,t:1527872991535};\\\", \\\"{x:929,y:802,t:1527872991551};\\\", \\\"{x:910,y:781,t:1527872991568};\\\", \\\"{x:895,y:759,t:1527872991585};\\\", \\\"{x:880,y:735,t:1527872991601};\\\", \\\"{x:870,y:724,t:1527872991618};\\\", \\\"{x:862,y:713,t:1527872991636};\\\", \\\"{x:852,y:702,t:1527872991651};\\\", \\\"{x:839,y:686,t:1527872991668};\\\", \\\"{x:816,y:670,t:1527872991685};\\\", \\\"{x:789,y:654,t:1527872991703};\\\", \\\"{x:764,y:646,t:1527872991719};\\\", \\\"{x:737,y:639,t:1527872991735};\\\", \\\"{x:707,y:623,t:1527872991753};\\\", \\\"{x:695,y:618,t:1527872991769};\\\", \\\"{x:694,y:618,t:1527872991785};\\\", \\\"{x:694,y:617,t:1527872991795};\\\", \\\"{x:693,y:616,t:1527872991811};\\\", \\\"{x:693,y:615,t:1527872991828};\\\", \\\"{x:690,y:612,t:1527872991846};\\\", \\\"{x:680,y:606,t:1527872991861};\\\", \\\"{x:670,y:602,t:1527872991878};\\\", \\\"{x:661,y:598,t:1527872991895};\\\", \\\"{x:653,y:595,t:1527872991912};\\\", \\\"{x:649,y:594,t:1527872991928};\\\", \\\"{x:641,y:591,t:1527872991946};\\\", \\\"{x:633,y:589,t:1527872991962};\\\", \\\"{x:629,y:588,t:1527872991978};\\\", \\\"{x:626,y:588,t:1527872991996};\\\", \\\"{x:623,y:588,t:1527872992013};\\\", \\\"{x:622,y:588,t:1527872992048};\\\", \\\"{x:620,y:588,t:1527872992064};\\\", \\\"{x:618,y:588,t:1527872992079};\\\", \\\"{x:613,y:588,t:1527872992096};\\\", \\\"{x:608,y:590,t:1527872992113};\\\", \\\"{x:607,y:590,t:1527872992128};\\\", \\\"{x:614,y:590,t:1527873009585};\\\", \\\"{x:641,y:588,t:1527873009594};\\\", \\\"{x:706,y:586,t:1527873009611};\\\", \\\"{x:759,y:586,t:1527873009627};\\\", \\\"{x:790,y:581,t:1527873009643};\\\", \\\"{x:803,y:580,t:1527873009654};\\\", \\\"{x:834,y:577,t:1527873009671};\\\", \\\"{x:857,y:577,t:1527873009688};\\\", \\\"{x:873,y:578,t:1527873009705};\\\", \\\"{x:888,y:584,t:1527873009722};\\\", \\\"{x:904,y:589,t:1527873009738};\\\", \\\"{x:912,y:594,t:1527873009760};\\\", \\\"{x:915,y:596,t:1527873009776};\\\", \\\"{x:917,y:599,t:1527873009793};\\\", \\\"{x:919,y:604,t:1527873009810};\\\", \\\"{x:924,y:620,t:1527873009828};\\\", \\\"{x:939,y:652,t:1527873009843};\\\", \\\"{x:966,y:696,t:1527873009860};\\\", \\\"{x:1016,y:732,t:1527873009877};\\\", \\\"{x:1102,y:771,t:1527873009893};\\\", \\\"{x:1184,y:789,t:1527873009910};\\\", \\\"{x:1255,y:793,t:1527873009927};\\\", \\\"{x:1316,y:793,t:1527873009943};\\\", \\\"{x:1411,y:793,t:1527873009960};\\\", \\\"{x:1464,y:793,t:1527873009977};\\\", \\\"{x:1528,y:793,t:1527873009993};\\\", \\\"{x:1579,y:796,t:1527873010011};\\\", \\\"{x:1611,y:801,t:1527873010026};\\\", \\\"{x:1631,y:807,t:1527873010043};\\\", \\\"{x:1641,y:813,t:1527873010060};\\\", \\\"{x:1645,y:817,t:1527873010077};\\\", \\\"{x:1645,y:818,t:1527873010096};\\\", \\\"{x:1645,y:819,t:1527873010110};\\\", \\\"{x:1645,y:821,t:1527873010128};\\\", \\\"{x:1645,y:823,t:1527873010144};\\\", \\\"{x:1644,y:826,t:1527873010160};\\\", \\\"{x:1641,y:829,t:1527873010177};\\\", \\\"{x:1633,y:833,t:1527873010194};\\\", \\\"{x:1617,y:836,t:1527873010210};\\\", \\\"{x:1595,y:836,t:1527873010227};\\\", \\\"{x:1575,y:836,t:1527873010244};\\\", \\\"{x:1561,y:836,t:1527873010260};\\\", \\\"{x:1558,y:836,t:1527873010277};\\\", \\\"{x:1556,y:836,t:1527873010293};\\\", \\\"{x:1556,y:835,t:1527873010312};\\\", \\\"{x:1554,y:835,t:1527873010327};\\\", \\\"{x:1552,y:834,t:1527873010343};\\\", \\\"{x:1551,y:834,t:1527873010360};\\\", \\\"{x:1550,y:833,t:1527873010392};\\\", \\\"{x:1548,y:833,t:1527873010416};\\\", \\\"{x:1547,y:833,t:1527873010448};\\\", \\\"{x:1545,y:833,t:1527873010472};\\\", \\\"{x:1543,y:833,t:1527873010488};\\\", \\\"{x:1541,y:833,t:1527873010496};\\\", \\\"{x:1540,y:833,t:1527873010510};\\\", \\\"{x:1535,y:833,t:1527873010527};\\\", \\\"{x:1525,y:833,t:1527873010544};\\\", \\\"{x:1514,y:833,t:1527873010561};\\\", \\\"{x:1504,y:833,t:1527873010577};\\\", \\\"{x:1498,y:833,t:1527873010595};\\\", \\\"{x:1495,y:833,t:1527873010611};\\\", \\\"{x:1493,y:833,t:1527873010648};\\\", \\\"{x:1491,y:834,t:1527873010904};\\\", \\\"{x:1488,y:836,t:1527873010912};\\\", \\\"{x:1483,y:837,t:1527873010928};\\\", \\\"{x:1480,y:837,t:1527873010944};\\\", \\\"{x:1479,y:835,t:1527873012778};\\\", \\\"{x:1479,y:834,t:1527873012816};\\\", \\\"{x:1477,y:833,t:1527873012873};\\\", \\\"{x:1477,y:832,t:1527873012896};\\\", \\\"{x:1476,y:831,t:1527873012927};\\\", \\\"{x:1475,y:831,t:1527873012936};\\\", \\\"{x:1473,y:831,t:1527873012946};\\\", \\\"{x:1467,y:831,t:1527873012962};\\\", \\\"{x:1462,y:831,t:1527873012979};\\\", \\\"{x:1455,y:831,t:1527873012996};\\\", \\\"{x:1451,y:831,t:1527873013012};\\\", \\\"{x:1448,y:831,t:1527873013028};\\\", \\\"{x:1445,y:831,t:1527873013045};\\\", \\\"{x:1441,y:831,t:1527873013062};\\\", \\\"{x:1437,y:831,t:1527873013079};\\\", \\\"{x:1431,y:831,t:1527873013096};\\\", \\\"{x:1428,y:831,t:1527873013113};\\\", \\\"{x:1427,y:831,t:1527873013129};\\\", \\\"{x:1426,y:831,t:1527873013146};\\\", \\\"{x:1425,y:831,t:1527873013192};\\\", \\\"{x:1423,y:831,t:1527873013296};\\\", \\\"{x:1422,y:831,t:1527873013314};\\\", \\\"{x:1421,y:831,t:1527873013329};\\\", \\\"{x:1420,y:830,t:1527873013505};\\\", \\\"{x:1419,y:830,t:1527873013536};\\\", \\\"{x:1418,y:830,t:1527873013552};\\\", \\\"{x:1417,y:830,t:1527873013696};\\\", \\\"{x:1416,y:830,t:1527873013728};\\\", \\\"{x:1415,y:830,t:1527873013864};\\\", \\\"{x:1414,y:830,t:1527873013993};\\\", \\\"{x:1412,y:830,t:1527873014049};\\\", \\\"{x:1411,y:830,t:1527873014063};\\\", \\\"{x:1406,y:830,t:1527873014080};\\\", \\\"{x:1401,y:830,t:1527873014097};\\\", \\\"{x:1389,y:830,t:1527873014113};\\\", \\\"{x:1372,y:835,t:1527873014131};\\\", \\\"{x:1357,y:837,t:1527873014148};\\\", \\\"{x:1346,y:837,t:1527873014163};\\\", \\\"{x:1342,y:837,t:1527873014181};\\\", \\\"{x:1341,y:837,t:1527873014198};\\\", \\\"{x:1341,y:838,t:1527873014297};\\\", \\\"{x:1342,y:838,t:1527873014320};\\\", \\\"{x:1343,y:838,t:1527873014331};\\\", \\\"{x:1346,y:839,t:1527873014348};\\\", \\\"{x:1349,y:839,t:1527873014363};\\\", \\\"{x:1353,y:839,t:1527873014380};\\\", \\\"{x:1355,y:839,t:1527873014397};\\\", \\\"{x:1356,y:839,t:1527873014414};\\\", \\\"{x:1359,y:839,t:1527873014665};\\\", \\\"{x:1364,y:839,t:1527873014681};\\\", \\\"{x:1371,y:838,t:1527873014698};\\\", \\\"{x:1378,y:837,t:1527873014715};\\\", \\\"{x:1384,y:837,t:1527873014730};\\\", \\\"{x:1392,y:835,t:1527873014748};\\\", \\\"{x:1393,y:835,t:1527873014764};\\\", \\\"{x:1394,y:834,t:1527873014781};\\\", \\\"{x:1395,y:834,t:1527873014848};\\\", \\\"{x:1396,y:834,t:1527873014864};\\\", \\\"{x:1397,y:834,t:1527873014888};\\\", \\\"{x:1398,y:834,t:1527873014914};\\\", \\\"{x:1399,y:834,t:1527873014932};\\\", \\\"{x:1400,y:834,t:1527873014948};\\\", \\\"{x:1402,y:834,t:1527873014965};\\\", \\\"{x:1404,y:834,t:1527873014982};\\\", \\\"{x:1406,y:834,t:1527873014998};\\\", \\\"{x:1408,y:834,t:1527873015015};\\\", \\\"{x:1412,y:836,t:1527873015032};\\\", \\\"{x:1418,y:837,t:1527873015048};\\\", \\\"{x:1423,y:838,t:1527873015065};\\\", \\\"{x:1425,y:838,t:1527873015081};\\\", \\\"{x:1426,y:838,t:1527873015185};\\\", \\\"{x:1426,y:837,t:1527873015197};\\\", \\\"{x:1427,y:836,t:1527873015215};\\\", \\\"{x:1427,y:833,t:1527873015232};\\\", \\\"{x:1427,y:832,t:1527873015248};\\\", \\\"{x:1427,y:831,t:1527873015272};\\\", \\\"{x:1428,y:831,t:1527873015288};\\\", \\\"{x:1428,y:830,t:1527873015305};\\\", \\\"{x:1429,y:830,t:1527873015314};\\\", \\\"{x:1429,y:829,t:1527873015332};\\\", \\\"{x:1431,y:828,t:1527873015349};\\\", \\\"{x:1434,y:826,t:1527873015365};\\\", \\\"{x:1440,y:826,t:1527873015382};\\\", \\\"{x:1446,y:826,t:1527873015399};\\\", \\\"{x:1455,y:826,t:1527873015414};\\\", \\\"{x:1463,y:830,t:1527873015432};\\\", \\\"{x:1469,y:832,t:1527873015448};\\\", \\\"{x:1471,y:832,t:1527873015465};\\\", \\\"{x:1472,y:832,t:1527873015488};\\\", \\\"{x:1473,y:832,t:1527873015514};\\\", \\\"{x:1474,y:832,t:1527873015552};\\\", \\\"{x:1474,y:833,t:1527873015593};\\\", \\\"{x:1475,y:833,t:1527873015673};\\\", \\\"{x:1475,y:832,t:1527873015696};\\\", \\\"{x:1475,y:831,t:1527873015720};\\\", \\\"{x:1476,y:830,t:1527873015732};\\\", \\\"{x:1476,y:829,t:1527873015848};\\\", \\\"{x:1476,y:828,t:1527873016345};\\\", \\\"{x:1476,y:827,t:1527873016351};\\\", \\\"{x:1476,y:825,t:1527873016366};\\\", \\\"{x:1476,y:824,t:1527873016383};\\\", \\\"{x:1476,y:823,t:1527873016398};\\\", \\\"{x:1476,y:822,t:1527873016480};\\\", \\\"{x:1476,y:821,t:1527873016488};\\\", \\\"{x:1476,y:820,t:1527873016498};\\\", \\\"{x:1476,y:816,t:1527873016516};\\\", \\\"{x:1474,y:812,t:1527873016533};\\\", \\\"{x:1472,y:808,t:1527873016549};\\\", \\\"{x:1463,y:800,t:1527873016566};\\\", \\\"{x:1449,y:788,t:1527873016583};\\\", \\\"{x:1439,y:776,t:1527873016599};\\\", \\\"{x:1432,y:768,t:1527873016616};\\\", \\\"{x:1432,y:764,t:1527873016632};\\\", \\\"{x:1432,y:761,t:1527873016650};\\\", \\\"{x:1432,y:757,t:1527873016666};\\\", \\\"{x:1432,y:754,t:1527873016683};\\\", \\\"{x:1432,y:752,t:1527873016699};\\\", \\\"{x:1432,y:750,t:1527873016715};\\\", \\\"{x:1432,y:747,t:1527873016732};\\\", \\\"{x:1432,y:745,t:1527873016750};\\\", \\\"{x:1432,y:742,t:1527873016765};\\\", \\\"{x:1432,y:741,t:1527873016783};\\\", \\\"{x:1432,y:737,t:1527873016800};\\\", \\\"{x:1432,y:735,t:1527873016815};\\\", \\\"{x:1430,y:731,t:1527873016832};\\\", \\\"{x:1429,y:728,t:1527873016849};\\\", \\\"{x:1427,y:724,t:1527873016866};\\\", \\\"{x:1423,y:717,t:1527873016883};\\\", \\\"{x:1421,y:714,t:1527873016900};\\\", \\\"{x:1420,y:713,t:1527873016915};\\\", \\\"{x:1418,y:711,t:1527873016932};\\\", \\\"{x:1417,y:709,t:1527873016949};\\\", \\\"{x:1416,y:707,t:1527873016966};\\\", \\\"{x:1415,y:706,t:1527873016983};\\\", \\\"{x:1414,y:705,t:1527873017000};\\\", \\\"{x:1414,y:704,t:1527873017015};\\\", \\\"{x:1414,y:702,t:1527873017480};\\\", \\\"{x:1414,y:700,t:1527873017521};\\\", \\\"{x:1413,y:699,t:1527873017985};\\\", \\\"{x:1413,y:702,t:1527873018000};\\\", \\\"{x:1413,y:712,t:1527873018017};\\\", \\\"{x:1413,y:715,t:1527873018034};\\\", \\\"{x:1413,y:722,t:1527873018051};\\\", \\\"{x:1413,y:725,t:1527873018067};\\\", \\\"{x:1413,y:727,t:1527873018084};\\\", \\\"{x:1413,y:729,t:1527873018101};\\\", \\\"{x:1413,y:730,t:1527873018128};\\\", \\\"{x:1413,y:731,t:1527873018144};\\\", \\\"{x:1413,y:732,t:1527873018152};\\\", \\\"{x:1413,y:734,t:1527873018176};\\\", \\\"{x:1413,y:735,t:1527873018192};\\\", \\\"{x:1413,y:736,t:1527873018200};\\\", \\\"{x:1413,y:737,t:1527873018216};\\\", \\\"{x:1413,y:739,t:1527873018234};\\\", \\\"{x:1414,y:741,t:1527873018251};\\\", \\\"{x:1414,y:742,t:1527873018267};\\\", \\\"{x:1414,y:744,t:1527873018284};\\\", \\\"{x:1414,y:745,t:1527873018300};\\\", \\\"{x:1414,y:747,t:1527873018317};\\\", \\\"{x:1414,y:748,t:1527873018334};\\\", \\\"{x:1414,y:750,t:1527873018352};\\\", \\\"{x:1414,y:751,t:1527873018368};\\\", \\\"{x:1414,y:753,t:1527873018384};\\\", \\\"{x:1414,y:755,t:1527873018400};\\\", \\\"{x:1415,y:758,t:1527873018418};\\\", \\\"{x:1415,y:760,t:1527873018434};\\\", \\\"{x:1415,y:761,t:1527873018450};\\\", \\\"{x:1415,y:762,t:1527873018468};\\\", \\\"{x:1415,y:763,t:1527873018545};\\\", \\\"{x:1415,y:764,t:1527873018793};\\\", \\\"{x:1414,y:764,t:1527873018945};\\\", \\\"{x:1413,y:764,t:1527873019001};\\\", \\\"{x:1412,y:765,t:1527873019017};\\\", \\\"{x:1410,y:765,t:1527873020024};\\\", \\\"{x:1408,y:765,t:1527873020034};\\\", \\\"{x:1405,y:765,t:1527873020051};\\\", \\\"{x:1400,y:765,t:1527873020068};\\\", \\\"{x:1395,y:763,t:1527873020086};\\\", \\\"{x:1392,y:763,t:1527873020101};\\\", \\\"{x:1386,y:763,t:1527873020119};\\\", \\\"{x:1383,y:763,t:1527873020135};\\\", \\\"{x:1382,y:763,t:1527873020167};\\\", \\\"{x:1381,y:763,t:1527873020216};\\\", \\\"{x:1380,y:762,t:1527873020264};\\\", \\\"{x:1382,y:766,t:1527873021376};\\\", \\\"{x:1384,y:769,t:1527873021387};\\\", \\\"{x:1388,y:773,t:1527873021403};\\\", \\\"{x:1390,y:775,t:1527873021420};\\\", \\\"{x:1392,y:778,t:1527873021437};\\\", \\\"{x:1393,y:779,t:1527873021453};\\\", \\\"{x:1394,y:781,t:1527873021470};\\\", \\\"{x:1395,y:781,t:1527873021488};\\\", \\\"{x:1396,y:781,t:1527873021568};\\\", \\\"{x:1397,y:781,t:1527873021587};\\\", \\\"{x:1398,y:781,t:1527873021603};\\\", \\\"{x:1399,y:781,t:1527873021620};\\\", \\\"{x:1400,y:781,t:1527873021637};\\\", \\\"{x:1401,y:781,t:1527873021656};\\\", \\\"{x:1402,y:780,t:1527873021688};\\\", \\\"{x:1403,y:780,t:1527873021713};\\\", \\\"{x:1404,y:780,t:1527873021720};\\\", \\\"{x:1405,y:779,t:1527873021905};\\\", \\\"{x:1406,y:778,t:1527873021944};\\\", \\\"{x:1407,y:777,t:1527873021968};\\\", \\\"{x:1408,y:777,t:1527873021992};\\\", \\\"{x:1408,y:776,t:1527873022008};\\\", \\\"{x:1408,y:775,t:1527873022048};\\\", \\\"{x:1408,y:774,t:1527873022056};\\\", \\\"{x:1409,y:774,t:1527873022088};\\\", \\\"{x:1410,y:773,t:1527873022104};\\\", \\\"{x:1411,y:772,t:1527873022144};\\\", \\\"{x:1411,y:771,t:1527873022233};\\\", \\\"{x:1412,y:771,t:1527873022264};\\\", \\\"{x:1413,y:770,t:1527873022296};\\\", \\\"{x:1413,y:769,t:1527873024865};\\\", \\\"{x:1414,y:769,t:1527873025248};\\\", \\\"{x:1414,y:771,t:1527873027209};\\\", \\\"{x:1414,y:773,t:1527873027224};\\\", \\\"{x:1414,y:774,t:1527873027241};\\\", \\\"{x:1414,y:776,t:1527873027258};\\\", \\\"{x:1414,y:777,t:1527873027274};\\\", \\\"{x:1414,y:778,t:1527873027291};\\\", \\\"{x:1412,y:778,t:1527873027314};\\\", \\\"{x:1412,y:779,t:1527873027729};\\\", \\\"{x:1412,y:781,t:1527873027752};\\\", \\\"{x:1412,y:783,t:1527873027760};\\\", \\\"{x:1416,y:785,t:1527873027775};\\\", \\\"{x:1425,y:791,t:1527873027791};\\\", \\\"{x:1449,y:796,t:1527873027808};\\\", \\\"{x:1465,y:799,t:1527873027825};\\\", \\\"{x:1487,y:803,t:1527873027841};\\\", \\\"{x:1515,y:806,t:1527873027858};\\\", \\\"{x:1544,y:810,t:1527873027875};\\\", \\\"{x:1570,y:814,t:1527873027892};\\\", \\\"{x:1592,y:816,t:1527873027908};\\\", \\\"{x:1610,y:819,t:1527873027924};\\\", \\\"{x:1624,y:821,t:1527873027941};\\\", \\\"{x:1631,y:823,t:1527873027957};\\\", \\\"{x:1635,y:824,t:1527873027974};\\\", \\\"{x:1637,y:825,t:1527873027991};\\\", \\\"{x:1637,y:826,t:1527873028088};\\\", \\\"{x:1637,y:827,t:1527873028095};\\\", \\\"{x:1637,y:828,t:1527873028120};\\\", \\\"{x:1636,y:830,t:1527873028136};\\\", \\\"{x:1635,y:831,t:1527873028152};\\\", \\\"{x:1634,y:832,t:1527873028160};\\\", \\\"{x:1633,y:833,t:1527873028175};\\\", \\\"{x:1630,y:836,t:1527873028192};\\\", \\\"{x:1629,y:836,t:1527873028208};\\\", \\\"{x:1628,y:837,t:1527873028232};\\\", \\\"{x:1624,y:836,t:1527873029408};\\\", \\\"{x:1620,y:835,t:1527873029426};\\\", \\\"{x:1613,y:835,t:1527873029443};\\\", \\\"{x:1604,y:835,t:1527873029459};\\\", \\\"{x:1599,y:834,t:1527873029476};\\\", \\\"{x:1595,y:834,t:1527873029493};\\\", \\\"{x:1594,y:834,t:1527873029509};\\\", \\\"{x:1593,y:833,t:1527873029584};\\\", \\\"{x:1592,y:833,t:1527873029672};\\\", \\\"{x:1592,y:832,t:1527873029680};\\\", \\\"{x:1591,y:832,t:1527873029977};\\\", \\\"{x:1590,y:832,t:1527873029993};\\\", \\\"{x:1589,y:832,t:1527873030010};\\\", \\\"{x:1587,y:832,t:1527873030027};\\\", \\\"{x:1583,y:832,t:1527873030042};\\\", \\\"{x:1577,y:832,t:1527873030059};\\\", \\\"{x:1573,y:832,t:1527873030076};\\\", \\\"{x:1568,y:832,t:1527873030093};\\\", \\\"{x:1562,y:832,t:1527873030109};\\\", \\\"{x:1553,y:832,t:1527873030126};\\\", \\\"{x:1545,y:832,t:1527873030143};\\\", \\\"{x:1527,y:831,t:1527873030159};\\\", \\\"{x:1517,y:831,t:1527873030177};\\\", \\\"{x:1514,y:831,t:1527873030193};\\\", \\\"{x:1513,y:831,t:1527873030383};\\\", \\\"{x:1512,y:831,t:1527873030407};\\\", \\\"{x:1511,y:831,t:1527873030495};\\\", \\\"{x:1509,y:831,t:1527873033008};\\\", \\\"{x:1505,y:830,t:1527873033016};\\\", \\\"{x:1503,y:828,t:1527873033029};\\\", \\\"{x:1490,y:825,t:1527873033046};\\\", \\\"{x:1470,y:819,t:1527873033062};\\\", \\\"{x:1451,y:819,t:1527873033079};\\\", \\\"{x:1437,y:817,t:1527873033095};\\\", \\\"{x:1436,y:817,t:1527873033114};\\\", \\\"{x:1434,y:817,t:1527873033200};\\\", \\\"{x:1433,y:817,t:1527873033212};\\\", \\\"{x:1429,y:820,t:1527873033229};\\\", \\\"{x:1426,y:823,t:1527873033246};\\\", \\\"{x:1424,y:825,t:1527873033262};\\\", \\\"{x:1418,y:829,t:1527873033279};\\\", \\\"{x:1410,y:834,t:1527873033296};\\\", \\\"{x:1402,y:839,t:1527873033313};\\\", \\\"{x:1396,y:843,t:1527873033329};\\\", \\\"{x:1390,y:847,t:1527873033346};\\\", \\\"{x:1385,y:851,t:1527873033363};\\\", \\\"{x:1379,y:856,t:1527873033379};\\\", \\\"{x:1369,y:866,t:1527873033396};\\\", \\\"{x:1359,y:877,t:1527873033412};\\\", \\\"{x:1354,y:883,t:1527873033430};\\\", \\\"{x:1350,y:892,t:1527873033446};\\\", \\\"{x:1345,y:900,t:1527873033462};\\\", \\\"{x:1343,y:903,t:1527873033480};\\\", \\\"{x:1341,y:906,t:1527873033496};\\\", \\\"{x:1341,y:908,t:1527873033513};\\\", \\\"{x:1340,y:908,t:1527873033530};\\\", \\\"{x:1340,y:910,t:1527873033546};\\\", \\\"{x:1339,y:911,t:1527873033563};\\\", \\\"{x:1338,y:914,t:1527873033579};\\\", \\\"{x:1336,y:918,t:1527873033596};\\\", \\\"{x:1335,y:920,t:1527873033613};\\\", \\\"{x:1333,y:923,t:1527873033629};\\\", \\\"{x:1331,y:925,t:1527873033646};\\\", \\\"{x:1330,y:928,t:1527873033664};\\\", \\\"{x:1327,y:934,t:1527873033679};\\\", \\\"{x:1324,y:939,t:1527873033696};\\\", \\\"{x:1322,y:942,t:1527873033712};\\\", \\\"{x:1321,y:948,t:1527873033729};\\\", \\\"{x:1320,y:954,t:1527873033745};\\\", \\\"{x:1320,y:955,t:1527873033767};\\\", \\\"{x:1320,y:957,t:1527873033779};\\\", \\\"{x:1320,y:961,t:1527873033795};\\\", \\\"{x:1320,y:965,t:1527873033813};\\\", \\\"{x:1318,y:970,t:1527873033829};\\\", \\\"{x:1318,y:973,t:1527873033846};\\\", \\\"{x:1318,y:975,t:1527873033863};\\\", \\\"{x:1318,y:976,t:1527873033879};\\\", \\\"{x:1317,y:977,t:1527873034000};\\\", \\\"{x:1315,y:976,t:1527873034016};\\\", \\\"{x:1314,y:975,t:1527873034030};\\\", \\\"{x:1314,y:973,t:1527873034046};\\\", \\\"{x:1314,y:972,t:1527873034104};\\\", \\\"{x:1314,y:970,t:1527873034169};\\\", \\\"{x:1314,y:969,t:1527873034256};\\\", \\\"{x:1310,y:968,t:1527873039897};\\\", \\\"{x:1272,y:963,t:1527873039904};\\\", \\\"{x:1221,y:955,t:1527873039917};\\\", \\\"{x:1205,y:953,t:1527873039934};\\\", \\\"{x:1204,y:953,t:1527873039951};\\\", \\\"{x:1203,y:953,t:1527873040111};\\\", \\\"{x:1202,y:951,t:1527873040119};\\\", \\\"{x:1200,y:949,t:1527873040134};\\\", \\\"{x:1194,y:944,t:1527873040151};\\\", \\\"{x:1180,y:935,t:1527873040168};\\\", \\\"{x:1143,y:914,t:1527873040184};\\\", \\\"{x:1070,y:879,t:1527873040200};\\\", \\\"{x:935,y:824,t:1527873040218};\\\", \\\"{x:794,y:779,t:1527873040234};\\\", \\\"{x:712,y:737,t:1527873040251};\\\", \\\"{x:698,y:728,t:1527873040268};\\\", \\\"{x:691,y:724,t:1527873040285};\\\", \\\"{x:690,y:718,t:1527873040301};\\\", \\\"{x:690,y:714,t:1527873040318};\\\", \\\"{x:690,y:713,t:1527873040334};\\\", \\\"{x:689,y:713,t:1527873040480};\\\", \\\"{x:687,y:713,t:1527873040488};\\\", \\\"{x:683,y:713,t:1527873040501};\\\", \\\"{x:674,y:713,t:1527873040519};\\\", \\\"{x:654,y:713,t:1527873040535};\\\", \\\"{x:632,y:713,t:1527873040551};\\\", \\\"{x:606,y:714,t:1527873040569};\\\", \\\"{x:570,y:719,t:1527873040585};\\\", \\\"{x:529,y:723,t:1527873040603};\\\", \\\"{x:515,y:723,t:1527873040618};\\\", \\\"{x:513,y:725,t:1527873040635};\\\", \\\"{x:512,y:725,t:1527873040679};\\\", \\\"{x:511,y:725,t:1527873040703};\\\", \\\"{x:511,y:726,t:1527873041126};\\\", \\\"{x:509,y:727,t:1527873041135};\\\", \\\"{x:509,y:728,t:1527873041152};\\\", \\\"{x:509,y:729,t:1527873041182};\\\" ] }, { \\\"rt\\\": 69424, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 9, \\\"time_elapsed\\\": 303181, \\\"internal_node_id\\\": \\\"0.0-5.0-4.0\\\", \\\"subject\\\": \\\"2OEC4\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"whiskey\\\", \\\"condition\\\": \\\"115\\\", \\\"scenario\\\": \\\"acme\\\", \\\"question\\\": \\\"midpoint\\\", \\\"q\\\": 5, \\\"clicks\\\": 1, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XFull-YFull\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 1, \\\"answer\\\": [ \\\"U\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"X \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"U \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-I -I -F -F \\\", \\\"block\\\": \\\"triangular_scaffolded\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:509,y:728,t:1527873043536};\\\", \\\"{x:509,y:724,t:1527873043544};\\\", \\\"{x:509,y:717,t:1527873043556};\\\", \\\"{x:505,y:706,t:1527873043575};\\\", \\\"{x:500,y:693,t:1527873043588};\\\", \\\"{x:494,y:681,t:1527873043604};\\\", \\\"{x:490,y:672,t:1527873043620};\\\", \\\"{x:488,y:667,t:1527873043637};\\\", \\\"{x:488,y:665,t:1527873043654};\\\", \\\"{x:485,y:660,t:1527873043671};\\\", \\\"{x:484,y:653,t:1527873043687};\\\", \\\"{x:484,y:652,t:1527873043919};\\\", \\\"{x:485,y:649,t:1527873043927};\\\", \\\"{x:491,y:642,t:1527873043938};\\\", \\\"{x:505,y:626,t:1527873043957};\\\", \\\"{x:518,y:617,t:1527873043971};\\\", \\\"{x:530,y:604,t:1527873043987};\\\", \\\"{x:540,y:591,t:1527873044005};\\\", \\\"{x:546,y:586,t:1527873044022};\\\", \\\"{x:548,y:586,t:1527873044038};\\\", \\\"{x:549,y:586,t:1527873044062};\\\", \\\"{x:547,y:588,t:1527873044071};\\\", \\\"{x:542,y:592,t:1527873044088};\\\", \\\"{x:532,y:597,t:1527873044105};\\\", \\\"{x:527,y:599,t:1527873044120};\\\", \\\"{x:525,y:599,t:1527873044138};\\\", \\\"{x:525,y:598,t:1527873044223};\\\", \\\"{x:525,y:594,t:1527873044239};\\\", \\\"{x:526,y:589,t:1527873044254};\\\", \\\"{x:541,y:564,t:1527873044271};\\\", \\\"{x:553,y:545,t:1527873044289};\\\", \\\"{x:581,y:506,t:1527873044305};\\\", \\\"{x:617,y:450,t:1527873044321};\\\", \\\"{x:640,y:398,t:1527873044338};\\\", \\\"{x:645,y:389,t:1527873044354};\\\", \\\"{x:647,y:384,t:1527873044371};\\\", \\\"{x:647,y:383,t:1527873044388};\\\", \\\"{x:647,y:382,t:1527873044760};\\\", \\\"{x:646,y:382,t:1527873044772};\\\", \\\"{x:642,y:384,t:1527873044789};\\\", \\\"{x:632,y:389,t:1527873044805};\\\", \\\"{x:615,y:394,t:1527873044822};\\\", \\\"{x:597,y:401,t:1527873044839};\\\", \\\"{x:595,y:402,t:1527873044856};\\\", \\\"{x:595,y:403,t:1527873044872};\\\", \\\"{x:600,y:399,t:1527873052268};\\\", \\\"{x:617,y:395,t:1527873052283};\\\", \\\"{x:634,y:391,t:1527873052300};\\\", \\\"{x:654,y:388,t:1527873052317};\\\", \\\"{x:669,y:386,t:1527873052334};\\\", \\\"{x:681,y:378,t:1527873052350};\\\", \\\"{x:692,y:373,t:1527873052367};\\\", \\\"{x:703,y:368,t:1527873052384};\\\", \\\"{x:719,y:363,t:1527873052401};\\\", \\\"{x:737,y:360,t:1527873052416};\\\", \\\"{x:763,y:356,t:1527873052434};\\\", \\\"{x:799,y:355,t:1527873052451};\\\", \\\"{x:872,y:355,t:1527873052467};\\\", \\\"{x:925,y:355,t:1527873052483};\\\", \\\"{x:982,y:357,t:1527873052501};\\\", \\\"{x:1036,y:367,t:1527873052518};\\\", \\\"{x:1079,y:374,t:1527873052534};\\\", \\\"{x:1109,y:381,t:1527873052550};\\\", \\\"{x:1130,y:388,t:1527873052567};\\\", \\\"{x:1144,y:394,t:1527873052584};\\\", \\\"{x:1150,y:396,t:1527873052601};\\\", \\\"{x:1151,y:397,t:1527873052619};\\\", \\\"{x:1151,y:398,t:1527873052652};\\\", \\\"{x:1152,y:400,t:1527873052668};\\\", \\\"{x:1155,y:404,t:1527873052684};\\\", \\\"{x:1157,y:405,t:1527873052700};\\\", \\\"{x:1157,y:406,t:1527873052718};\\\", \\\"{x:1158,y:408,t:1527873052734};\\\", \\\"{x:1160,y:409,t:1527873052751};\\\", \\\"{x:1164,y:415,t:1527873052768};\\\", \\\"{x:1170,y:422,t:1527873052784};\\\", \\\"{x:1177,y:431,t:1527873052801};\\\", \\\"{x:1188,y:441,t:1527873052818};\\\", \\\"{x:1199,y:450,t:1527873052834};\\\", \\\"{x:1204,y:453,t:1527873052851};\\\", \\\"{x:1209,y:455,t:1527873052867};\\\", \\\"{x:1211,y:456,t:1527873052885};\\\", \\\"{x:1212,y:456,t:1527873052901};\\\", \\\"{x:1214,y:457,t:1527873052918};\\\", \\\"{x:1215,y:458,t:1527873052947};\\\", \\\"{x:1216,y:459,t:1527873052963};\\\", \\\"{x:1217,y:460,t:1527873052979};\\\", \\\"{x:1218,y:461,t:1527873052987};\\\", \\\"{x:1219,y:462,t:1527873053001};\\\", \\\"{x:1221,y:465,t:1527873053017};\\\", \\\"{x:1225,y:470,t:1527873053035};\\\", \\\"{x:1227,y:472,t:1527873053050};\\\", \\\"{x:1239,y:482,t:1527873053068};\\\", \\\"{x:1251,y:491,t:1527873053085};\\\", \\\"{x:1263,y:500,t:1527873053101};\\\", \\\"{x:1271,y:506,t:1527873053118};\\\", \\\"{x:1282,y:513,t:1527873053135};\\\", \\\"{x:1291,y:519,t:1527873053151};\\\", \\\"{x:1293,y:521,t:1527873053168};\\\", \\\"{x:1294,y:521,t:1527873053404};\\\", \\\"{x:1294,y:520,t:1527873053418};\\\", \\\"{x:1294,y:513,t:1527873053435};\\\", \\\"{x:1294,y:509,t:1527873053452};\\\", \\\"{x:1294,y:506,t:1527873053468};\\\", \\\"{x:1294,y:504,t:1527873053485};\\\", \\\"{x:1295,y:502,t:1527873053502};\\\", \\\"{x:1296,y:502,t:1527873053780};\\\", \\\"{x:1297,y:502,t:1527873053787};\\\", \\\"{x:1299,y:502,t:1527873053802};\\\", \\\"{x:1303,y:502,t:1527873053820};\\\", \\\"{x:1304,y:502,t:1527873053836};\\\", \\\"{x:1306,y:502,t:1527873053907};\\\", \\\"{x:1307,y:501,t:1527873053939};\\\", \\\"{x:1307,y:500,t:1527873053980};\\\", \\\"{x:1308,y:499,t:1527873053988};\\\", \\\"{x:1309,y:498,t:1527873054030};\\\", \\\"{x:1309,y:496,t:1527873062114};\\\", \\\"{x:1310,y:487,t:1527873062127};\\\", \\\"{x:1315,y:466,t:1527873062143};\\\", \\\"{x:1318,y:441,t:1527873062160};\\\", \\\"{x:1324,y:422,t:1527873062177};\\\", \\\"{x:1325,y:420,t:1527873062192};\\\", \\\"{x:1325,y:419,t:1527873062226};\\\", \\\"{x:1325,y:420,t:1527873062291};\\\", \\\"{x:1328,y:429,t:1527873062299};\\\", \\\"{x:1337,y:439,t:1527873062310};\\\", \\\"{x:1371,y:451,t:1527873062327};\\\", \\\"{x:1425,y:467,t:1527873062343};\\\", \\\"{x:1457,y:480,t:1527873062360};\\\", \\\"{x:1463,y:483,t:1527873062376};\\\", \\\"{x:1463,y:484,t:1527873062755};\\\", \\\"{x:1464,y:484,t:1527873062827};\\\", \\\"{x:1465,y:484,t:1527873062844};\\\", \\\"{x:1466,y:484,t:1527873062861};\\\", \\\"{x:1469,y:488,t:1527873062891};\\\", \\\"{x:1472,y:496,t:1527873062899};\\\", \\\"{x:1477,y:505,t:1527873062911};\\\", \\\"{x:1486,y:526,t:1527873062928};\\\", \\\"{x:1495,y:555,t:1527873062944};\\\", \\\"{x:1505,y:591,t:1527873062962};\\\", \\\"{x:1514,y:637,t:1527873062977};\\\", \\\"{x:1530,y:688,t:1527873062994};\\\", \\\"{x:1560,y:758,t:1527873063011};\\\", \\\"{x:1577,y:794,t:1527873063027};\\\", \\\"{x:1587,y:820,t:1527873063044};\\\", \\\"{x:1597,y:838,t:1527873063061};\\\", \\\"{x:1602,y:847,t:1527873063077};\\\", \\\"{x:1602,y:848,t:1527873063094};\\\", \\\"{x:1602,y:850,t:1527873063111};\\\", \\\"{x:1602,y:852,t:1527873063128};\\\", \\\"{x:1602,y:854,t:1527873063145};\\\", \\\"{x:1602,y:861,t:1527873063162};\\\", \\\"{x:1602,y:871,t:1527873063178};\\\", \\\"{x:1601,y:883,t:1527873063194};\\\", \\\"{x:1599,y:895,t:1527873063211};\\\", \\\"{x:1595,y:901,t:1527873063228};\\\", \\\"{x:1592,y:904,t:1527873063244};\\\", \\\"{x:1591,y:909,t:1527873063262};\\\", \\\"{x:1588,y:914,t:1527873063278};\\\", \\\"{x:1584,y:922,t:1527873063294};\\\", \\\"{x:1581,y:929,t:1527873063311};\\\", \\\"{x:1578,y:932,t:1527873063328};\\\", \\\"{x:1576,y:934,t:1527873063344};\\\", \\\"{x:1572,y:935,t:1527873063362};\\\", \\\"{x:1569,y:937,t:1527873063378};\\\", \\\"{x:1568,y:938,t:1527873063419};\\\", \\\"{x:1567,y:938,t:1527873063451};\\\", \\\"{x:1566,y:939,t:1527873063462};\\\", \\\"{x:1565,y:939,t:1527873063478};\\\", \\\"{x:1564,y:941,t:1527873063495};\\\", \\\"{x:1562,y:941,t:1527873063515};\\\", \\\"{x:1562,y:942,t:1527873063539};\\\", \\\"{x:1561,y:943,t:1527873063563};\\\", \\\"{x:1561,y:944,t:1527873063619};\\\", \\\"{x:1560,y:944,t:1527873063635};\\\", \\\"{x:1559,y:945,t:1527873063651};\\\", \\\"{x:1557,y:947,t:1527873063675};\\\", \\\"{x:1556,y:948,t:1527873063772};\\\", \\\"{x:1554,y:948,t:1527873063787};\\\", \\\"{x:1554,y:949,t:1527873063796};\\\", \\\"{x:1552,y:950,t:1527873063811};\\\", \\\"{x:1551,y:953,t:1527873063829};\\\", \\\"{x:1550,y:954,t:1527873063845};\\\", \\\"{x:1550,y:955,t:1527873063923};\\\", \\\"{x:1548,y:956,t:1527873066843};\\\", \\\"{x:1541,y:954,t:1527873066851};\\\", \\\"{x:1525,y:944,t:1527873066864};\\\", \\\"{x:1459,y:899,t:1527873066881};\\\", \\\"{x:1348,y:847,t:1527873066898};\\\", \\\"{x:1207,y:785,t:1527873066914};\\\", \\\"{x:997,y:705,t:1527873066932};\\\", \\\"{x:923,y:687,t:1527873066948};\\\", \\\"{x:890,y:674,t:1527873066965};\\\", \\\"{x:873,y:666,t:1527873066981};\\\", \\\"{x:868,y:665,t:1527873066998};\\\", \\\"{x:867,y:664,t:1527873067092};\\\", \\\"{x:866,y:664,t:1527873067115};\\\", \\\"{x:864,y:664,t:1527873067131};\\\", \\\"{x:854,y:664,t:1527873067148};\\\", \\\"{x:838,y:658,t:1527873067165};\\\", \\\"{x:811,y:651,t:1527873067181};\\\", \\\"{x:764,y:638,t:1527873067198};\\\", \\\"{x:714,y:625,t:1527873067216};\\\", \\\"{x:668,y:615,t:1527873067231};\\\", \\\"{x:642,y:611,t:1527873067248};\\\", \\\"{x:635,y:609,t:1527873067257};\\\", \\\"{x:629,y:608,t:1527873067274};\\\", \\\"{x:628,y:607,t:1527873067290};\\\", \\\"{x:627,y:607,t:1527873067691};\\\", \\\"{x:627,y:609,t:1527873068091};\\\", \\\"{x:636,y:615,t:1527873068098};\\\", \\\"{x:650,y:621,t:1527873068112};\\\", \\\"{x:696,y:636,t:1527873068130};\\\", \\\"{x:752,y:652,t:1527873068145};\\\", \\\"{x:827,y:676,t:1527873068161};\\\", \\\"{x:941,y:707,t:1527873068178};\\\", \\\"{x:1026,y:728,t:1527873068195};\\\", \\\"{x:1108,y:745,t:1527873068212};\\\", \\\"{x:1177,y:763,t:1527873068229};\\\", \\\"{x:1228,y:772,t:1527873068245};\\\", \\\"{x:1263,y:784,t:1527873068261};\\\", \\\"{x:1284,y:790,t:1527873068278};\\\", \\\"{x:1302,y:796,t:1527873068294};\\\", \\\"{x:1322,y:806,t:1527873068312};\\\", \\\"{x:1336,y:814,t:1527873068329};\\\", \\\"{x:1346,y:822,t:1527873068345};\\\", \\\"{x:1349,y:824,t:1527873068362};\\\", \\\"{x:1348,y:823,t:1527873087508};\\\", \\\"{x:1340,y:800,t:1527873087514};\\\", \\\"{x:1325,y:760,t:1527873087525};\\\", \\\"{x:1324,y:760,t:1527873090595};\\\", \\\"{x:1323,y:761,t:1527873090626};\\\", \\\"{x:1322,y:762,t:1527873090644};\\\", \\\"{x:1322,y:763,t:1527873090661};\\\", \\\"{x:1322,y:764,t:1527873090678};\\\", \\\"{x:1323,y:766,t:1527873090694};\\\", \\\"{x:1323,y:767,t:1527873090711};\\\", \\\"{x:1323,y:769,t:1527873090731};\\\", \\\"{x:1324,y:769,t:1527873090744};\\\", \\\"{x:1324,y:770,t:1527873090762};\\\", \\\"{x:1325,y:772,t:1527873090779};\\\", \\\"{x:1326,y:774,t:1527873090794};\\\", \\\"{x:1326,y:775,t:1527873090811};\\\", \\\"{x:1327,y:777,t:1527873090828};\\\", \\\"{x:1329,y:778,t:1527873090844};\\\", \\\"{x:1331,y:779,t:1527873090861};\\\", \\\"{x:1332,y:780,t:1527873090877};\\\", \\\"{x:1333,y:780,t:1527873090893};\\\", \\\"{x:1334,y:780,t:1527873090910};\\\", \\\"{x:1335,y:781,t:1527873090994};\\\", \\\"{x:1336,y:782,t:1527873091011};\\\", \\\"{x:1337,y:783,t:1527873091027};\\\", \\\"{x:1337,y:784,t:1527873091050};\\\", \\\"{x:1338,y:785,t:1527873091066};\\\", \\\"{x:1339,y:785,t:1527873091451};\\\", \\\"{x:1340,y:785,t:1527873091466};\\\", \\\"{x:1342,y:785,t:1527873091491};\\\", \\\"{x:1343,y:785,t:1527873091507};\\\", \\\"{x:1344,y:785,t:1527873091522};\\\", \\\"{x:1345,y:785,t:1527873091539};\\\", \\\"{x:1346,y:785,t:1527873091547};\\\", \\\"{x:1347,y:785,t:1527873091562};\\\", \\\"{x:1349,y:785,t:1527873091579};\\\", \\\"{x:1350,y:785,t:1527873091634};\\\", \\\"{x:1351,y:785,t:1527873091645};\\\", \\\"{x:1352,y:785,t:1527873091673};\\\", \\\"{x:1353,y:785,t:1527873091681};\\\", \\\"{x:1355,y:785,t:1527873091695};\\\", \\\"{x:1356,y:784,t:1527873091711};\\\", \\\"{x:1358,y:784,t:1527873091728};\\\", \\\"{x:1359,y:784,t:1527873091744};\\\", \\\"{x:1361,y:784,t:1527873091760};\\\", \\\"{x:1363,y:782,t:1527873091778};\\\", \\\"{x:1365,y:782,t:1527873091794};\\\", \\\"{x:1366,y:782,t:1527873091810};\\\", \\\"{x:1368,y:781,t:1527873091828};\\\", \\\"{x:1370,y:781,t:1527873091844};\\\", \\\"{x:1371,y:781,t:1527873091861};\\\", \\\"{x:1372,y:780,t:1527873091955};\\\", \\\"{x:1373,y:780,t:1527873092307};\\\", \\\"{x:1373,y:779,t:1527873092482};\\\", \\\"{x:1374,y:778,t:1527873092499};\\\", \\\"{x:1374,y:777,t:1527873092555};\\\", \\\"{x:1374,y:776,t:1527873092570};\\\", \\\"{x:1374,y:775,t:1527873092611};\\\", \\\"{x:1374,y:774,t:1527873092626};\\\", \\\"{x:1374,y:773,t:1527873092650};\\\", \\\"{x:1374,y:771,t:1527873093003};\\\", \\\"{x:1374,y:770,t:1527873093178};\\\", \\\"{x:1376,y:765,t:1527873107803};\\\", \\\"{x:1376,y:729,t:1527873107824};\\\", \\\"{x:1376,y:711,t:1527873107838};\\\", \\\"{x:1376,y:700,t:1527873107855};\\\", \\\"{x:1379,y:706,t:1527873109278};\\\", \\\"{x:1402,y:745,t:1527873109294};\\\", \\\"{x:1410,y:768,t:1527873109311};\\\", \\\"{x:1413,y:778,t:1527873109328};\\\", \\\"{x:1407,y:782,t:1527873109344};\\\", \\\"{x:1405,y:782,t:1527873109630};\\\", \\\"{x:1405,y:781,t:1527873109645};\\\", \\\"{x:1402,y:772,t:1527873109660};\\\", \\\"{x:1397,y:766,t:1527873109678};\\\", \\\"{x:1391,y:763,t:1527873109694};\\\", \\\"{x:1376,y:763,t:1527873109711};\\\", \\\"{x:1333,y:763,t:1527873109729};\\\", \\\"{x:1253,y:763,t:1527873109744};\\\", \\\"{x:1142,y:763,t:1527873109761};\\\", \\\"{x:1012,y:763,t:1527873109778};\\\", \\\"{x:893,y:763,t:1527873109795};\\\", \\\"{x:798,y:759,t:1527873109811};\\\", \\\"{x:745,y:759,t:1527873109827};\\\", \\\"{x:713,y:759,t:1527873109845};\\\", \\\"{x:691,y:759,t:1527873109861};\\\", \\\"{x:674,y:759,t:1527873109878};\\\", \\\"{x:665,y:761,t:1527873109894};\\\", \\\"{x:659,y:764,t:1527873109911};\\\", \\\"{x:655,y:770,t:1527873109927};\\\", \\\"{x:654,y:776,t:1527873109945};\\\", \\\"{x:654,y:779,t:1527873109961};\\\", \\\"{x:654,y:780,t:1527873110871};\\\", \\\"{x:655,y:780,t:1527873110894};\\\", \\\"{x:656,y:779,t:1527873111046};\\\", \\\"{x:657,y:776,t:1527873111061};\\\", \\\"{x:660,y:769,t:1527873111078};\\\", \\\"{x:661,y:764,t:1527873111095};\\\", \\\"{x:661,y:761,t:1527873111111};\\\", \\\"{x:661,y:758,t:1527873111128};\\\", \\\"{x:661,y:756,t:1527873111145};\\\", \\\"{x:661,y:754,t:1527873111162};\\\", \\\"{x:661,y:753,t:1527873111190};\\\", \\\"{x:660,y:752,t:1527873111197};\\\", \\\"{x:659,y:752,t:1527873111212};\\\", \\\"{x:650,y:751,t:1527873111229};\\\", \\\"{x:630,y:746,t:1527873111246};\\\", \\\"{x:609,y:743,t:1527873111262};\\\", \\\"{x:586,y:738,t:1527873111279};\\\", \\\"{x:571,y:733,t:1527873111296};\\\", \\\"{x:565,y:732,t:1527873111312};\\\", \\\"{x:557,y:729,t:1527873111330};\\\", \\\"{x:551,y:728,t:1527873111345};\\\", \\\"{x:549,y:728,t:1527873111361};\\\", \\\"{x:547,y:727,t:1527873111382};\\\", \\\"{x:546,y:726,t:1527873111399};\\\", \\\"{x:545,y:726,t:1527873111416};\\\", \\\"{x:544,y:725,t:1527873111432};\\\", \\\"{x:540,y:717,t:1527873112862};\\\", \\\"{x:535,y:705,t:1527873112869};\\\", \\\"{x:520,y:683,t:1527873112886};\\\", \\\"{x:493,y:642,t:1527873112903};\\\", \\\"{x:482,y:620,t:1527873112919};\\\" ] }, { \\\"rt\\\": 8023, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 10, \\\"time_elapsed\\\": 312801, \\\"internal_node_id\\\": \\\"0.0-6.0-0.0\\\", \\\"subject\\\": \\\"2OEC4\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"whiskey\\\", \\\"condition\\\": \\\"115\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"duration\\\", \\\"q\\\": 6, \\\"clicks\\\": 2.5, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XFull-YFull\\\", \\\"correct\\\": 1, \\\"orth_correct\\\": 1, \\\"answer\\\": [ \\\"E\\\", \\\"G\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"\\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:483,y:619,t:1527873114175};\\\", \\\"{x:484,y:618,t:1527873114186};\\\", \\\"{x:484,y:616,t:1527873114203};\\\", \\\"{x:485,y:613,t:1527873114221};\\\", \\\"{x:485,y:612,t:1527873114236};\\\", \\\"{x:485,y:609,t:1527873114253};\\\", \\\"{x:485,y:607,t:1527873114270};\\\", \\\"{x:485,y:603,t:1527873114287};\\\", \\\"{x:485,y:596,t:1527873114305};\\\", \\\"{x:480,y:587,t:1527873114321};\\\", \\\"{x:477,y:585,t:1527873114336};\\\", \\\"{x:476,y:585,t:1527873115197};\\\", \\\"{x:477,y:584,t:1527873115285};\\\", \\\"{x:482,y:584,t:1527873115294};\\\", \\\"{x:485,y:584,t:1527873115304};\\\", \\\"{x:493,y:584,t:1527873115320};\\\", \\\"{x:504,y:584,t:1527873115338};\\\", \\\"{x:516,y:584,t:1527873115354};\\\", \\\"{x:532,y:584,t:1527873115370};\\\", \\\"{x:543,y:584,t:1527873115386};\\\", \\\"{x:564,y:584,t:1527873115404};\\\", \\\"{x:593,y:584,t:1527873115420};\\\", \\\"{x:623,y:584,t:1527873115437};\\\", \\\"{x:671,y:584,t:1527873115453};\\\", \\\"{x:703,y:584,t:1527873115472};\\\", \\\"{x:732,y:584,t:1527873115488};\\\", \\\"{x:761,y:582,t:1527873115504};\\\", \\\"{x:784,y:575,t:1527873115522};\\\", \\\"{x:793,y:567,t:1527873115537};\\\", \\\"{x:793,y:566,t:1527873116758};\\\", \\\"{x:790,y:566,t:1527873116774};\\\", \\\"{x:787,y:566,t:1527873116789};\\\", \\\"{x:773,y:564,t:1527873116805};\\\", \\\"{x:761,y:563,t:1527873116823};\\\", \\\"{x:747,y:560,t:1527873116840};\\\", \\\"{x:733,y:558,t:1527873116855};\\\", \\\"{x:711,y:555,t:1527873116873};\\\", \\\"{x:671,y:546,t:1527873116887};\\\", \\\"{x:596,y:526,t:1527873116904};\\\", \\\"{x:548,y:519,t:1527873116922};\\\", \\\"{x:528,y:512,t:1527873116937};\\\", \\\"{x:522,y:510,t:1527873116956};\\\", \\\"{x:520,y:509,t:1527873116972};\\\", \\\"{x:519,y:508,t:1527873117004};\\\", \\\"{x:517,y:508,t:1527873117022};\\\", \\\"{x:515,y:507,t:1527873117038};\\\", \\\"{x:511,y:504,t:1527873117056};\\\", \\\"{x:509,y:503,t:1527873117072};\\\", \\\"{x:508,y:503,t:1527873117088};\\\", \\\"{x:504,y:501,t:1527873117105};\\\", \\\"{x:502,y:501,t:1527873117121};\\\", \\\"{x:500,y:501,t:1527873117138};\\\", \\\"{x:496,y:501,t:1527873117157};\\\", \\\"{x:491,y:504,t:1527873117171};\\\", \\\"{x:479,y:509,t:1527873117189};\\\", \\\"{x:451,y:516,t:1527873117206};\\\", \\\"{x:432,y:522,t:1527873117224};\\\", \\\"{x:422,y:525,t:1527873117240};\\\", \\\"{x:415,y:526,t:1527873117255};\\\", \\\"{x:408,y:528,t:1527873117272};\\\", \\\"{x:403,y:529,t:1527873117289};\\\", \\\"{x:400,y:529,t:1527873117305};\\\", \\\"{x:397,y:529,t:1527873117322};\\\", \\\"{x:402,y:529,t:1527873117373};\\\", \\\"{x:422,y:528,t:1527873117389};\\\", \\\"{x:456,y:526,t:1527873117405};\\\", \\\"{x:497,y:521,t:1527873117423};\\\", \\\"{x:543,y:514,t:1527873117439};\\\", \\\"{x:570,y:514,t:1527873117456};\\\", \\\"{x:587,y:512,t:1527873117472};\\\", \\\"{x:590,y:512,t:1527873117490};\\\", \\\"{x:591,y:511,t:1527873117506};\\\", \\\"{x:590,y:510,t:1527873117522};\\\", \\\"{x:589,y:510,t:1527873117549};\\\", \\\"{x:588,y:509,t:1527873117565};\\\", \\\"{x:587,y:508,t:1527873117572};\\\", \\\"{x:585,y:507,t:1527873117589};\\\", \\\"{x:584,y:506,t:1527873117646};\\\", \\\"{x:584,y:505,t:1527873117670};\\\", \\\"{x:586,y:504,t:1527873117726};\\\", \\\"{x:587,y:504,t:1527873117740};\\\", \\\"{x:590,y:504,t:1527873117757};\\\", \\\"{x:592,y:503,t:1527873117774};\\\", \\\"{x:594,y:503,t:1527873117790};\\\", \\\"{x:596,y:503,t:1527873117862};\\\", \\\"{x:598,y:502,t:1527873117886};\\\", \\\"{x:598,y:501,t:1527873117894};\\\", \\\"{x:601,y:501,t:1527873118151};\\\", \\\"{x:614,y:502,t:1527873118157};\\\", \\\"{x:670,y:519,t:1527873118173};\\\", \\\"{x:742,y:539,t:1527873118191};\\\", \\\"{x:830,y:556,t:1527873118207};\\\", \\\"{x:890,y:571,t:1527873118223};\\\", \\\"{x:925,y:576,t:1527873118240};\\\", \\\"{x:939,y:578,t:1527873118256};\\\", \\\"{x:941,y:579,t:1527873118274};\\\", \\\"{x:939,y:579,t:1527873118341};\\\", \\\"{x:935,y:579,t:1527873118357};\\\", \\\"{x:911,y:573,t:1527873118372};\\\", \\\"{x:892,y:568,t:1527873118390};\\\", \\\"{x:870,y:562,t:1527873118407};\\\", \\\"{x:853,y:558,t:1527873118424};\\\", \\\"{x:840,y:552,t:1527873118441};\\\", \\\"{x:830,y:548,t:1527873118458};\\\", \\\"{x:826,y:545,t:1527873118473};\\\", \\\"{x:826,y:543,t:1527873118490};\\\", \\\"{x:826,y:540,t:1527873118506};\\\", \\\"{x:826,y:539,t:1527873118523};\\\", \\\"{x:826,y:538,t:1527873118541};\\\", \\\"{x:826,y:537,t:1527873118557};\\\", \\\"{x:827,y:536,t:1527873118581};\\\", \\\"{x:829,y:536,t:1527873118678};\\\", \\\"{x:832,y:536,t:1527873118691};\\\", \\\"{x:835,y:539,t:1527873118707};\\\", \\\"{x:838,y:540,t:1527873118724};\\\", \\\"{x:841,y:542,t:1527873118741};\\\", \\\"{x:841,y:543,t:1527873118758};\\\", \\\"{x:839,y:542,t:1527873118949};\\\", \\\"{x:836,y:541,t:1527873118956};\\\", \\\"{x:828,y:539,t:1527873118974};\\\", \\\"{x:826,y:539,t:1527873118990};\\\", \\\"{x:822,y:539,t:1527873119007};\\\", \\\"{x:817,y:539,t:1527873119024};\\\", \\\"{x:810,y:538,t:1527873119040};\\\", \\\"{x:798,y:537,t:1527873119057};\\\", \\\"{x:780,y:534,t:1527873119074};\\\", \\\"{x:765,y:532,t:1527873119090};\\\", \\\"{x:753,y:529,t:1527873119108};\\\", \\\"{x:743,y:528,t:1527873119124};\\\", \\\"{x:730,y:524,t:1527873119142};\\\", \\\"{x:705,y:519,t:1527873119157};\\\", \\\"{x:691,y:515,t:1527873119176};\\\", \\\"{x:678,y:512,t:1527873119190};\\\", \\\"{x:665,y:508,t:1527873119208};\\\", \\\"{x:654,y:507,t:1527873119225};\\\", \\\"{x:647,y:504,t:1527873119240};\\\", \\\"{x:644,y:502,t:1527873119257};\\\", \\\"{x:641,y:500,t:1527873119275};\\\", \\\"{x:640,y:500,t:1527873119290};\\\", \\\"{x:639,y:500,t:1527873119342};\\\", \\\"{x:638,y:500,t:1527873119357};\\\", \\\"{x:635,y:500,t:1527873119374};\\\", \\\"{x:633,y:500,t:1527873119391};\\\", \\\"{x:630,y:500,t:1527873119408};\\\", \\\"{x:627,y:500,t:1527873119425};\\\", \\\"{x:622,y:500,t:1527873119441};\\\", \\\"{x:620,y:500,t:1527873119458};\\\", \\\"{x:619,y:500,t:1527873119474};\\\", \\\"{x:618,y:500,t:1527873119710};\\\", \\\"{x:617,y:500,t:1527873119724};\\\", \\\"{x:616,y:500,t:1527873119846};\\\", \\\"{x:616,y:501,t:1527873120462};\\\", \\\"{x:616,y:503,t:1527873120477};\\\", \\\"{x:618,y:504,t:1527873120492};\\\", \\\"{x:620,y:507,t:1527873120509};\\\", \\\"{x:621,y:511,t:1527873120526};\\\", \\\"{x:622,y:514,t:1527873120542};\\\", \\\"{x:623,y:518,t:1527873120558};\\\", \\\"{x:624,y:524,t:1527873120575};\\\", \\\"{x:624,y:529,t:1527873120591};\\\", \\\"{x:624,y:534,t:1527873120609};\\\", \\\"{x:624,y:539,t:1527873120625};\\\", \\\"{x:622,y:543,t:1527873120642};\\\", \\\"{x:621,y:548,t:1527873120658};\\\", \\\"{x:614,y:559,t:1527873120676};\\\", \\\"{x:603,y:571,t:1527873120692};\\\", \\\"{x:596,y:584,t:1527873120708};\\\", \\\"{x:581,y:601,t:1527873120727};\\\", \\\"{x:572,y:611,t:1527873120743};\\\", \\\"{x:568,y:617,t:1527873120759};\\\", \\\"{x:565,y:622,t:1527873120775};\\\", \\\"{x:560,y:629,t:1527873120791};\\\", \\\"{x:553,y:640,t:1527873120809};\\\", \\\"{x:544,y:653,t:1527873120826};\\\", \\\"{x:537,y:664,t:1527873120842};\\\", \\\"{x:533,y:669,t:1527873120859};\\\", \\\"{x:531,y:671,t:1527873120876};\\\", \\\"{x:530,y:673,t:1527873120893};\\\", \\\"{x:529,y:674,t:1527873120909};\\\", \\\"{x:528,y:676,t:1527873120925};\\\", \\\"{x:528,y:678,t:1527873120949};\\\", \\\"{x:528,y:679,t:1527873120960};\\\", \\\"{x:527,y:680,t:1527873120975};\\\", \\\"{x:527,y:681,t:1527873120993};\\\", \\\"{x:527,y:683,t:1527873121010};\\\", \\\"{x:527,y:686,t:1527873121026};\\\", \\\"{x:527,y:688,t:1527873121043};\\\", \\\"{x:527,y:690,t:1527873121060};\\\", \\\"{x:527,y:691,t:1527873121077};\\\", \\\"{x:527,y:694,t:1527873121093};\\\", \\\"{x:527,y:702,t:1527873121110};\\\", \\\"{x:527,y:708,t:1527873121127};\\\", \\\"{x:527,y:712,t:1527873121144};\\\", \\\"{x:527,y:713,t:1527873121160};\\\", \\\"{x:527,y:715,t:1527873121177};\\\", \\\"{x:527,y:716,t:1527873121195};\\\", \\\"{x:526,y:718,t:1527873121210};\\\", \\\"{x:524,y:722,t:1527873121228};\\\", \\\"{x:523,y:729,t:1527873121246};\\\", \\\"{x:521,y:732,t:1527873121259};\\\", \\\"{x:520,y:734,t:1527873121276};\\\", \\\"{x:519,y:735,t:1527873121292};\\\", \\\"{x:519,y:737,t:1527873121381};\\\", \\\"{x:518,y:737,t:1527873121733};\\\", \\\"{x:518,y:736,t:1527873121745};\\\", \\\"{x:518,y:734,t:1527873121769};\\\" ] }, { \\\"rt\\\": 16274, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 11, \\\"time_elapsed\\\": 330328, \\\"internal_node_id\\\": \\\"0.0-6.0-1.0\\\", \\\"subject\\\": \\\"2OEC4\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"whiskey\\\", \\\"condition\\\": \\\"115\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"duration+starts\\\", \\\"q\\\": 7, \\\"clicks\\\": 2, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XFull-YFull\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 1, \\\"answer\\\": [ \\\"F\\\", \\\"B\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-F -F \\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:518,y:733,t:1527873122789};\\\", \\\"{x:518,y:732,t:1527873123134};\\\", \\\"{x:517,y:732,t:1527873123143};\\\", \\\"{x:517,y:731,t:1527873123606};\\\", \\\"{x:517,y:728,t:1527873123613};\\\", \\\"{x:517,y:723,t:1527873124830};\\\", \\\"{x:517,y:720,t:1527873124845};\\\", \\\"{x:517,y:719,t:1527873125671};\\\", \\\"{x:519,y:718,t:1527873125693};\\\", \\\"{x:520,y:717,t:1527873125700};\\\", \\\"{x:521,y:717,t:1527873125712};\\\", \\\"{x:523,y:716,t:1527873125729};\\\", \\\"{x:525,y:715,t:1527873125744};\\\", \\\"{x:526,y:714,t:1527873125761};\\\", \\\"{x:529,y:713,t:1527873125779};\\\", \\\"{x:532,y:713,t:1527873125795};\\\", \\\"{x:536,y:713,t:1527873125812};\\\", \\\"{x:545,y:711,t:1527873125829};\\\", \\\"{x:548,y:710,t:1527873125844};\\\", \\\"{x:551,y:710,t:1527873125861};\\\", \\\"{x:552,y:710,t:1527873125879};\\\", \\\"{x:554,y:710,t:1527873125894};\\\", \\\"{x:555,y:710,t:1527873125917};\\\", \\\"{x:556,y:709,t:1527873125929};\\\", \\\"{x:558,y:709,t:1527873125945};\\\", \\\"{x:561,y:709,t:1527873125962};\\\", \\\"{x:562,y:709,t:1527873125979};\\\", \\\"{x:565,y:708,t:1527873125996};\\\", \\\"{x:567,y:708,t:1527873126012};\\\", \\\"{x:571,y:708,t:1527873126030};\\\", \\\"{x:575,y:708,t:1527873126045};\\\", \\\"{x:577,y:708,t:1527873126062};\\\", \\\"{x:581,y:708,t:1527873126079};\\\", \\\"{x:582,y:708,t:1527873126095};\\\", \\\"{x:583,y:708,t:1527873127070};\\\", \\\"{x:584,y:707,t:1527873127085};\\\", \\\"{x:585,y:707,t:1527873127109};\\\", \\\"{x:586,y:707,t:1527873127125};\\\", \\\"{x:587,y:707,t:1527873127134};\\\", \\\"{x:588,y:707,t:1527873127149};\\\", \\\"{x:589,y:707,t:1527873127162};\\\", \\\"{x:590,y:707,t:1527873127179};\\\", \\\"{x:594,y:706,t:1527873127197};\\\", \\\"{x:596,y:706,t:1527873127212};\\\", \\\"{x:600,y:706,t:1527873127229};\\\", \\\"{x:604,y:704,t:1527873127246};\\\", \\\"{x:608,y:703,t:1527873127262};\\\", \\\"{x:615,y:702,t:1527873127279};\\\", \\\"{x:631,y:698,t:1527873127296};\\\", \\\"{x:663,y:692,t:1527873127312};\\\", \\\"{x:714,y:689,t:1527873127329};\\\", \\\"{x:759,y:689,t:1527873127346};\\\", \\\"{x:789,y:689,t:1527873127362};\\\", \\\"{x:807,y:689,t:1527873127380};\\\", \\\"{x:817,y:692,t:1527873127397};\\\", \\\"{x:824,y:694,t:1527873127413};\\\", \\\"{x:825,y:695,t:1527873127429};\\\", \\\"{x:825,y:696,t:1527873127846};\\\", \\\"{x:829,y:698,t:1527873127864};\\\", \\\"{x:832,y:699,t:1527873127879};\\\", \\\"{x:834,y:699,t:1527873127896};\\\", \\\"{x:841,y:699,t:1527873127913};\\\", \\\"{x:848,y:698,t:1527873127929};\\\", \\\"{x:856,y:695,t:1527873127946};\\\", \\\"{x:871,y:693,t:1527873127963};\\\", \\\"{x:891,y:690,t:1527873127979};\\\", \\\"{x:911,y:690,t:1527873127996};\\\", \\\"{x:952,y:690,t:1527873128013};\\\", \\\"{x:976,y:690,t:1527873128029};\\\", \\\"{x:1001,y:690,t:1527873128047};\\\", \\\"{x:1023,y:690,t:1527873128064};\\\", \\\"{x:1035,y:688,t:1527873128080};\\\", \\\"{x:1043,y:687,t:1527873128096};\\\", \\\"{x:1045,y:685,t:1527873128113};\\\", \\\"{x:1046,y:685,t:1527873128133};\\\", \\\"{x:1048,y:684,t:1527873128149};\\\", \\\"{x:1049,y:684,t:1527873128165};\\\", \\\"{x:1051,y:682,t:1527873128179};\\\", \\\"{x:1059,y:678,t:1527873128196};\\\", \\\"{x:1068,y:674,t:1527873128213};\\\", \\\"{x:1079,y:668,t:1527873128229};\\\", \\\"{x:1093,y:663,t:1527873128246};\\\", \\\"{x:1107,y:658,t:1527873128263};\\\", \\\"{x:1120,y:654,t:1527873128279};\\\", \\\"{x:1133,y:651,t:1527873128297};\\\", \\\"{x:1145,y:646,t:1527873128313};\\\", \\\"{x:1155,y:641,t:1527873128329};\\\", \\\"{x:1163,y:637,t:1527873128346};\\\", \\\"{x:1169,y:636,t:1527873128363};\\\", \\\"{x:1173,y:634,t:1527873128381};\\\", \\\"{x:1175,y:633,t:1527873128397};\\\", \\\"{x:1176,y:633,t:1527873128438};\\\", \\\"{x:1177,y:633,t:1527873128453};\\\", \\\"{x:1178,y:633,t:1527873128464};\\\", \\\"{x:1179,y:633,t:1527873128481};\\\", \\\"{x:1182,y:633,t:1527873128497};\\\", \\\"{x:1184,y:635,t:1527873128514};\\\", \\\"{x:1188,y:638,t:1527873128531};\\\", \\\"{x:1194,y:643,t:1527873128546};\\\", \\\"{x:1203,y:649,t:1527873128563};\\\", \\\"{x:1216,y:657,t:1527873128581};\\\", \\\"{x:1229,y:663,t:1527873128597};\\\", \\\"{x:1249,y:669,t:1527873128612};\\\", \\\"{x:1269,y:672,t:1527873128630};\\\", \\\"{x:1289,y:672,t:1527873128646};\\\", \\\"{x:1308,y:672,t:1527873128663};\\\", \\\"{x:1323,y:672,t:1527873128679};\\\", \\\"{x:1331,y:672,t:1527873128696};\\\", \\\"{x:1337,y:669,t:1527873128712};\\\", \\\"{x:1339,y:667,t:1527873128729};\\\", \\\"{x:1343,y:664,t:1527873128746};\\\", \\\"{x:1344,y:663,t:1527873128762};\\\", \\\"{x:1347,y:659,t:1527873128780};\\\", \\\"{x:1349,y:657,t:1527873128796};\\\", \\\"{x:1350,y:656,t:1527873128813};\\\", \\\"{x:1350,y:655,t:1527873128829};\\\", \\\"{x:1351,y:654,t:1527873128862};\\\", \\\"{x:1352,y:654,t:1527873128894};\\\", \\\"{x:1353,y:654,t:1527873129214};\\\", \\\"{x:1354,y:655,t:1527873129294};\\\", \\\"{x:1354,y:656,t:1527873129350};\\\", \\\"{x:1355,y:656,t:1527873129398};\\\", \\\"{x:1355,y:658,t:1527873129413};\\\", \\\"{x:1356,y:659,t:1527873129430};\\\", \\\"{x:1356,y:660,t:1527873129447};\\\", \\\"{x:1357,y:662,t:1527873129463};\\\", \\\"{x:1357,y:663,t:1527873129550};\\\", \\\"{x:1357,y:664,t:1527873129598};\\\", \\\"{x:1357,y:666,t:1527873129630};\\\", \\\"{x:1357,y:667,t:1527873129662};\\\", \\\"{x:1357,y:669,t:1527873129702};\\\", \\\"{x:1357,y:670,t:1527873129718};\\\", \\\"{x:1357,y:671,t:1527873129730};\\\", \\\"{x:1357,y:672,t:1527873129748};\\\", \\\"{x:1357,y:673,t:1527873129763};\\\", \\\"{x:1355,y:676,t:1527873129781};\\\", \\\"{x:1354,y:677,t:1527873129798};\\\", \\\"{x:1354,y:678,t:1527873129822};\\\", \\\"{x:1353,y:679,t:1527873129854};\\\", \\\"{x:1353,y:680,t:1527873129878};\\\", \\\"{x:1353,y:681,t:1527873129886};\\\", \\\"{x:1352,y:682,t:1527873129897};\\\", \\\"{x:1351,y:683,t:1527873129913};\\\", \\\"{x:1351,y:684,t:1527873129930};\\\", \\\"{x:1351,y:685,t:1527873129947};\\\", \\\"{x:1350,y:686,t:1527873129964};\\\", \\\"{x:1350,y:688,t:1527873129990};\\\", \\\"{x:1349,y:689,t:1527873129997};\\\", \\\"{x:1348,y:689,t:1527873130012};\\\", \\\"{x:1348,y:690,t:1527873130030};\\\", \\\"{x:1348,y:692,t:1527873130048};\\\", \\\"{x:1348,y:694,t:1527873130093};\\\", \\\"{x:1347,y:695,t:1527873130132};\\\", \\\"{x:1347,y:697,t:1527873130246};\\\", \\\"{x:1346,y:697,t:1527873130269};\\\", \\\"{x:1346,y:698,t:1527873130280};\\\", \\\"{x:1346,y:700,t:1527873130366};\\\", \\\"{x:1346,y:701,t:1527873130438};\\\", \\\"{x:1345,y:702,t:1527873130463};\\\", \\\"{x:1345,y:703,t:1527873130481};\\\", \\\"{x:1345,y:704,t:1527873130501};\\\", \\\"{x:1345,y:706,t:1527873130526};\\\", \\\"{x:1345,y:707,t:1527873130550};\\\", \\\"{x:1345,y:709,t:1527873130581};\\\", \\\"{x:1345,y:710,t:1527873130622};\\\", \\\"{x:1345,y:711,t:1527873130637};\\\", \\\"{x:1345,y:712,t:1527873130654};\\\", \\\"{x:1345,y:713,t:1527873130685};\\\", \\\"{x:1344,y:714,t:1527873130697};\\\", \\\"{x:1344,y:715,t:1527873130714};\\\", \\\"{x:1344,y:716,t:1527873130731};\\\", \\\"{x:1343,y:717,t:1527873130748};\\\", \\\"{x:1343,y:718,t:1527873130765};\\\", \\\"{x:1343,y:719,t:1527873130798};\\\", \\\"{x:1342,y:720,t:1527873130829};\\\", \\\"{x:1342,y:721,t:1527873131094};\\\", \\\"{x:1342,y:722,t:1527873131190};\\\", \\\"{x:1342,y:724,t:1527873131254};\\\", \\\"{x:1342,y:726,t:1527873131364};\\\", \\\"{x:1342,y:727,t:1527873131388};\\\", \\\"{x:1342,y:728,t:1527873131413};\\\", \\\"{x:1342,y:729,t:1527873131420};\\\", \\\"{x:1342,y:730,t:1527873131431};\\\", \\\"{x:1342,y:731,t:1527873131453};\\\", \\\"{x:1342,y:732,t:1527873131464};\\\", \\\"{x:1342,y:734,t:1527873131481};\\\", \\\"{x:1342,y:737,t:1527873131497};\\\", \\\"{x:1340,y:742,t:1527873131514};\\\", \\\"{x:1339,y:747,t:1527873131530};\\\", \\\"{x:1339,y:748,t:1527873131547};\\\", \\\"{x:1339,y:749,t:1527873131564};\\\", \\\"{x:1339,y:751,t:1527873131581};\\\", \\\"{x:1338,y:754,t:1527873131597};\\\", \\\"{x:1337,y:758,t:1527873131614};\\\", \\\"{x:1333,y:764,t:1527873131631};\\\", \\\"{x:1332,y:764,t:1527873131822};\\\", \\\"{x:1326,y:764,t:1527873131831};\\\", \\\"{x:1296,y:762,t:1527873131847};\\\", \\\"{x:1225,y:744,t:1527873131865};\\\", \\\"{x:1177,y:737,t:1527873131882};\\\", \\\"{x:1123,y:729,t:1527873131897};\\\", \\\"{x:1024,y:717,t:1527873131915};\\\", \\\"{x:912,y:693,t:1527873131931};\\\", \\\"{x:789,y:674,t:1527873131948};\\\", \\\"{x:698,y:663,t:1527873131964};\\\", \\\"{x:640,y:652,t:1527873131981};\\\", \\\"{x:626,y:650,t:1527873131998};\\\", \\\"{x:622,y:648,t:1527873132014};\\\", \\\"{x:621,y:647,t:1527873132032};\\\", \\\"{x:620,y:646,t:1527873132047};\\\", \\\"{x:619,y:646,t:1527873132064};\\\", \\\"{x:618,y:645,t:1527873132081};\\\", \\\"{x:615,y:642,t:1527873132097};\\\", \\\"{x:613,y:638,t:1527873132114};\\\", \\\"{x:606,y:630,t:1527873132133};\\\", \\\"{x:599,y:622,t:1527873132148};\\\", \\\"{x:586,y:614,t:1527873132164};\\\", \\\"{x:564,y:604,t:1527873132185};\\\", \\\"{x:543,y:593,t:1527873132201};\\\", \\\"{x:528,y:586,t:1527873132217};\\\", \\\"{x:513,y:582,t:1527873132234};\\\", \\\"{x:497,y:577,t:1527873132252};\\\", \\\"{x:473,y:570,t:1527873132268};\\\", \\\"{x:430,y:557,t:1527873132285};\\\", \\\"{x:402,y:549,t:1527873132302};\\\", \\\"{x:378,y:541,t:1527873132318};\\\", \\\"{x:367,y:538,t:1527873132335};\\\", \\\"{x:366,y:538,t:1527873132352};\\\", \\\"{x:366,y:537,t:1527873132389};\\\", \\\"{x:368,y:537,t:1527873132437};\\\", \\\"{x:369,y:537,t:1527873132452};\\\", \\\"{x:372,y:540,t:1527873132468};\\\", \\\"{x:374,y:542,t:1527873132486};\\\", \\\"{x:375,y:542,t:1527873132509};\\\", \\\"{x:375,y:543,t:1527873132661};\\\", \\\"{x:374,y:543,t:1527873132773};\\\", \\\"{x:371,y:543,t:1527873132786};\\\", \\\"{x:365,y:543,t:1527873132801};\\\", \\\"{x:360,y:543,t:1527873132819};\\\", \\\"{x:355,y:543,t:1527873132836};\\\", \\\"{x:353,y:543,t:1527873132852};\\\", \\\"{x:351,y:544,t:1527873132869};\\\", \\\"{x:351,y:545,t:1527873132901};\\\", \\\"{x:351,y:546,t:1527873132919};\\\", \\\"{x:351,y:547,t:1527873132937};\\\", \\\"{x:351,y:549,t:1527873132952};\\\", \\\"{x:352,y:550,t:1527873132969};\\\", \\\"{x:356,y:550,t:1527873132986};\\\", \\\"{x:358,y:551,t:1527873133002};\\\", \\\"{x:359,y:551,t:1527873133019};\\\", \\\"{x:361,y:551,t:1527873133036};\\\", \\\"{x:362,y:551,t:1527873133053};\\\", \\\"{x:363,y:551,t:1527873133077};\\\", \\\"{x:364,y:551,t:1527873133094};\\\", \\\"{x:366,y:552,t:1527873133109};\\\", \\\"{x:366,y:553,t:1527873133158};\\\", \\\"{x:365,y:553,t:1527873133229};\\\", \\\"{x:367,y:553,t:1527873133612};\\\", \\\"{x:371,y:554,t:1527873133621};\\\", \\\"{x:375,y:554,t:1527873133636};\\\", \\\"{x:391,y:554,t:1527873133652};\\\", \\\"{x:397,y:554,t:1527873133670};\\\", \\\"{x:403,y:555,t:1527873133686};\\\", \\\"{x:407,y:556,t:1527873133704};\\\", \\\"{x:409,y:556,t:1527873133796};\\\", \\\"{x:412,y:556,t:1527873133805};\\\", \\\"{x:415,y:556,t:1527873133819};\\\", \\\"{x:419,y:556,t:1527873133836};\\\", \\\"{x:430,y:556,t:1527873133853};\\\", \\\"{x:435,y:556,t:1527873133869};\\\", \\\"{x:440,y:556,t:1527873133886};\\\", \\\"{x:443,y:556,t:1527873133903};\\\", \\\"{x:448,y:556,t:1527873133918};\\\", \\\"{x:450,y:556,t:1527873133936};\\\", \\\"{x:451,y:556,t:1527873133952};\\\", \\\"{x:453,y:556,t:1527873133970};\\\", \\\"{x:454,y:556,t:1527873133986};\\\", \\\"{x:456,y:556,t:1527873134003};\\\", \\\"{x:459,y:556,t:1527873134019};\\\", \\\"{x:461,y:556,t:1527873134036};\\\", \\\"{x:469,y:556,t:1527873134052};\\\", \\\"{x:475,y:556,t:1527873134069};\\\", \\\"{x:482,y:556,t:1527873134086};\\\", \\\"{x:492,y:556,t:1527873134103};\\\", \\\"{x:503,y:556,t:1527873134119};\\\", \\\"{x:517,y:556,t:1527873134136};\\\", \\\"{x:529,y:556,t:1527873134153};\\\", \\\"{x:540,y:556,t:1527873134170};\\\", \\\"{x:555,y:556,t:1527873134187};\\\", \\\"{x:570,y:556,t:1527873134203};\\\", \\\"{x:583,y:556,t:1527873134219};\\\", \\\"{x:594,y:555,t:1527873134238};\\\", \\\"{x:613,y:552,t:1527873134252};\\\", \\\"{x:623,y:551,t:1527873134270};\\\", \\\"{x:639,y:551,t:1527873134286};\\\", \\\"{x:658,y:550,t:1527873134303};\\\", \\\"{x:679,y:550,t:1527873134320};\\\", \\\"{x:703,y:550,t:1527873134336};\\\", \\\"{x:729,y:550,t:1527873134353};\\\", \\\"{x:752,y:550,t:1527873134370};\\\", \\\"{x:767,y:550,t:1527873134387};\\\", \\\"{x:781,y:550,t:1527873134402};\\\", \\\"{x:786,y:550,t:1527873134420};\\\", \\\"{x:788,y:550,t:1527873134437};\\\", \\\"{x:789,y:550,t:1527873134453};\\\", \\\"{x:790,y:549,t:1527873134485};\\\", \\\"{x:791,y:548,t:1527873134501};\\\", \\\"{x:793,y:547,t:1527873134509};\\\", \\\"{x:795,y:547,t:1527873134520};\\\", \\\"{x:800,y:544,t:1527873134538};\\\", \\\"{x:806,y:540,t:1527873134553};\\\", \\\"{x:808,y:539,t:1527873134570};\\\", \\\"{x:809,y:538,t:1527873134587};\\\", \\\"{x:810,y:537,t:1527873134603};\\\", \\\"{x:811,y:536,t:1527873134620};\\\", \\\"{x:812,y:534,t:1527873134637};\\\", \\\"{x:812,y:531,t:1527873134653};\\\", \\\"{x:813,y:530,t:1527873134670};\\\", \\\"{x:813,y:527,t:1527873134687};\\\", \\\"{x:814,y:527,t:1527873134703};\\\", \\\"{x:814,y:526,t:1527873134720};\\\", \\\"{x:817,y:523,t:1527873134738};\\\", \\\"{x:819,y:519,t:1527873134753};\\\", \\\"{x:820,y:516,t:1527873134771};\\\", \\\"{x:822,y:514,t:1527873134786};\\\", \\\"{x:823,y:513,t:1527873134803};\\\", \\\"{x:824,y:512,t:1527873134819};\\\", \\\"{x:825,y:512,t:1527873134836};\\\", \\\"{x:827,y:512,t:1527873134860};\\\", \\\"{x:828,y:510,t:1527873134885};\\\", \\\"{x:829,y:510,t:1527873135157};\\\", \\\"{x:827,y:510,t:1527873135212};\\\", \\\"{x:825,y:511,t:1527873135229};\\\", \\\"{x:823,y:511,t:1527873135252};\\\", \\\"{x:822,y:511,t:1527873135261};\\\", \\\"{x:821,y:511,t:1527873135271};\\\", \\\"{x:819,y:513,t:1527873135287};\\\", \\\"{x:815,y:514,t:1527873135304};\\\", \\\"{x:810,y:515,t:1527873135321};\\\", \\\"{x:798,y:516,t:1527873135337};\\\", \\\"{x:778,y:516,t:1527873135354};\\\", \\\"{x:748,y:516,t:1527873135372};\\\", \\\"{x:706,y:516,t:1527873135388};\\\", \\\"{x:664,y:516,t:1527873135404};\\\", \\\"{x:594,y:516,t:1527873135420};\\\", \\\"{x:547,y:516,t:1527873135436};\\\", \\\"{x:505,y:516,t:1527873135454};\\\", \\\"{x:475,y:516,t:1527873135472};\\\", \\\"{x:458,y:516,t:1527873135487};\\\", \\\"{x:445,y:516,t:1527873135504};\\\", \\\"{x:441,y:517,t:1527873135521};\\\", \\\"{x:434,y:518,t:1527873135538};\\\", \\\"{x:427,y:519,t:1527873135554};\\\", \\\"{x:421,y:520,t:1527873135571};\\\", \\\"{x:416,y:521,t:1527873135587};\\\", \\\"{x:410,y:523,t:1527873135604};\\\", \\\"{x:402,y:525,t:1527873135621};\\\", \\\"{x:396,y:525,t:1527873135638};\\\", \\\"{x:386,y:526,t:1527873135654};\\\", \\\"{x:375,y:529,t:1527873135672};\\\", \\\"{x:367,y:531,t:1527873135689};\\\", \\\"{x:363,y:533,t:1527873135704};\\\", \\\"{x:357,y:535,t:1527873135721};\\\", \\\"{x:346,y:538,t:1527873135738};\\\", \\\"{x:333,y:538,t:1527873135754};\\\", \\\"{x:326,y:539,t:1527873135771};\\\", \\\"{x:321,y:539,t:1527873135788};\\\", \\\"{x:320,y:541,t:1527873135804};\\\", \\\"{x:318,y:542,t:1527873135821};\\\", \\\"{x:311,y:544,t:1527873135838};\\\", \\\"{x:305,y:547,t:1527873135854};\\\", \\\"{x:295,y:551,t:1527873135871};\\\", \\\"{x:285,y:555,t:1527873135888};\\\", \\\"{x:275,y:556,t:1527873135905};\\\", \\\"{x:261,y:556,t:1527873135921};\\\", \\\"{x:250,y:556,t:1527873135938};\\\", \\\"{x:239,y:556,t:1527873135955};\\\", \\\"{x:228,y:556,t:1527873135971};\\\", \\\"{x:219,y:556,t:1527873135988};\\\", \\\"{x:211,y:556,t:1527873136005};\\\", \\\"{x:206,y:556,t:1527873136021};\\\", \\\"{x:201,y:556,t:1527873136038};\\\", \\\"{x:194,y:556,t:1527873136055};\\\", \\\"{x:189,y:555,t:1527873136073};\\\", \\\"{x:181,y:552,t:1527873136088};\\\", \\\"{x:177,y:551,t:1527873136105};\\\", \\\"{x:177,y:550,t:1527873136121};\\\", \\\"{x:176,y:550,t:1527873136157};\\\", \\\"{x:176,y:549,t:1527873136174};\\\", \\\"{x:174,y:549,t:1527873136188};\\\", \\\"{x:173,y:548,t:1527873136205};\\\", \\\"{x:173,y:547,t:1527873136357};\\\", \\\"{x:173,y:546,t:1527873136869};\\\", \\\"{x:174,y:545,t:1527873136878};\\\", \\\"{x:175,y:544,t:1527873136888};\\\", \\\"{x:182,y:540,t:1527873136906};\\\", \\\"{x:183,y:539,t:1527873136922};\\\", \\\"{x:186,y:539,t:1527873137357};\\\", \\\"{x:196,y:540,t:1527873137373};\\\", \\\"{x:221,y:547,t:1527873137388};\\\", \\\"{x:230,y:547,t:1527873137406};\\\", \\\"{x:236,y:548,t:1527873137422};\\\", \\\"{x:240,y:548,t:1527873137439};\\\", \\\"{x:243,y:550,t:1527873137456};\\\", \\\"{x:244,y:550,t:1527873137476};\\\", \\\"{x:245,y:550,t:1527873137489};\\\", \\\"{x:246,y:550,t:1527873137506};\\\", \\\"{x:250,y:553,t:1527873137523};\\\", \\\"{x:254,y:555,t:1527873137539};\\\", \\\"{x:263,y:559,t:1527873137557};\\\", \\\"{x:269,y:559,t:1527873137572};\\\", \\\"{x:271,y:559,t:1527873137909};\\\", \\\"{x:278,y:561,t:1527873137923};\\\", \\\"{x:288,y:565,t:1527873137941};\\\", \\\"{x:296,y:568,t:1527873137956};\\\", \\\"{x:300,y:568,t:1527873137972};\\\", \\\"{x:306,y:569,t:1527873137988};\\\", \\\"{x:313,y:573,t:1527873138006};\\\", \\\"{x:328,y:578,t:1527873138023};\\\", \\\"{x:342,y:582,t:1527873138039};\\\", \\\"{x:357,y:589,t:1527873138056};\\\", \\\"{x:374,y:600,t:1527873138074};\\\", \\\"{x:386,y:608,t:1527873138091};\\\", \\\"{x:391,y:616,t:1527873138106};\\\", \\\"{x:398,y:620,t:1527873138123};\\\", \\\"{x:403,y:623,t:1527873138139};\\\", \\\"{x:406,y:624,t:1527873138156};\\\", \\\"{x:407,y:625,t:1527873138173};\\\", \\\"{x:407,y:627,t:1527873138198};\\\", \\\"{x:410,y:629,t:1527873138206};\\\", \\\"{x:419,y:635,t:1527873138224};\\\", \\\"{x:434,y:640,t:1527873138241};\\\", \\\"{x:450,y:644,t:1527873138256};\\\", \\\"{x:464,y:648,t:1527873138273};\\\", \\\"{x:473,y:653,t:1527873138290};\\\", \\\"{x:475,y:654,t:1527873138305};\\\", \\\"{x:478,y:656,t:1527873138323};\\\", \\\"{x:480,y:658,t:1527873138340};\\\", \\\"{x:483,y:660,t:1527873138356};\\\", \\\"{x:486,y:663,t:1527873138373};\\\", \\\"{x:488,y:667,t:1527873138390};\\\", \\\"{x:489,y:670,t:1527873138407};\\\", \\\"{x:492,y:680,t:1527873138422};\\\", \\\"{x:493,y:683,t:1527873138440};\\\", \\\"{x:493,y:687,t:1527873138457};\\\", \\\"{x:493,y:696,t:1527873138473};\\\", \\\"{x:493,y:705,t:1527873138490};\\\", \\\"{x:496,y:710,t:1527873138507};\\\", \\\"{x:497,y:712,t:1527873138523};\\\", \\\"{x:499,y:713,t:1527873138540};\\\", \\\"{x:500,y:713,t:1527873138557};\\\", \\\"{x:500,y:714,t:1527873138573};\\\", \\\"{x:500,y:715,t:1527873138590};\\\", \\\"{x:500,y:716,t:1527873138607};\\\", \\\"{x:500,y:717,t:1527873138645};\\\", \\\"{x:500,y:718,t:1527873138661};\\\", \\\"{x:500,y:720,t:1527873138678};\\\", \\\"{x:500,y:721,t:1527873138690};\\\", \\\"{x:500,y:723,t:1527873138707};\\\", \\\"{x:500,y:725,t:1527873138723};\\\", \\\"{x:500,y:726,t:1527873138740};\\\", \\\"{x:500,y:728,t:1527873138757};\\\", \\\"{x:500,y:730,t:1527873138773};\\\", \\\"{x:500,y:734,t:1527873138790};\\\", \\\"{x:500,y:737,t:1527873138807};\\\", \\\"{x:501,y:737,t:1527873139573};\\\", \\\"{x:502,y:737,t:1527873139591};\\\", \\\"{x:503,y:736,t:1527873139629};\\\", \\\"{x:504,y:736,t:1527873139701};\\\", \\\"{x:505,y:736,t:1527873139709};\\\", \\\"{x:506,y:735,t:1527873139725};\\\", \\\"{x:506,y:734,t:1527873139741};\\\", \\\"{x:507,y:734,t:1527873139758};\\\", \\\"{x:508,y:733,t:1527873139775};\\\", \\\"{x:509,y:731,t:1527873139791};\\\", \\\"{x:510,y:727,t:1527873139808};\\\", \\\"{x:510,y:726,t:1527873139825};\\\", \\\"{x:510,y:725,t:1527873139841};\\\" ] }, { \\\"rt\\\": 43340, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 12, \\\"time_elapsed\\\": 374948, \\\"internal_node_id\\\": \\\"0.0-6.0-2.0\\\", \\\"subject\\\": \\\"2OEC4\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"whiskey\\\", \\\"condition\\\": \\\"115\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"duration+contained\\\", \\\"q\\\": 8, \\\"clicks\\\": 1, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XFull-YFull\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 1, \\\"answer\\\": [ \\\"E\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-X -X \\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:513,y:724,t:1527873144046};\\\", \\\"{x:525,y:719,t:1527873144065};\\\", \\\"{x:543,y:715,t:1527873144077};\\\", \\\"{x:573,y:706,t:1527873144094};\\\", \\\"{x:604,y:697,t:1527873144111};\\\", \\\"{x:642,y:681,t:1527873144128};\\\", \\\"{x:675,y:666,t:1527873144144};\\\", \\\"{x:701,y:657,t:1527873144161};\\\", \\\"{x:722,y:649,t:1527873144178};\\\", \\\"{x:739,y:642,t:1527873144194};\\\", \\\"{x:750,y:636,t:1527873144211};\\\", \\\"{x:759,y:631,t:1527873144229};\\\", \\\"{x:767,y:626,t:1527873144245};\\\", \\\"{x:772,y:623,t:1527873144261};\\\", \\\"{x:775,y:620,t:1527873144278};\\\", \\\"{x:780,y:616,t:1527873144295};\\\", \\\"{x:784,y:612,t:1527873144311};\\\", \\\"{x:786,y:611,t:1527873144328};\\\", \\\"{x:787,y:610,t:1527873144345};\\\", \\\"{x:789,y:608,t:1527873144362};\\\", \\\"{x:786,y:608,t:1527873144549};\\\", \\\"{x:784,y:609,t:1527873144565};\\\", \\\"{x:784,y:611,t:1527873144589};\\\", \\\"{x:783,y:611,t:1527873144605};\\\", \\\"{x:782,y:612,t:1527873144613};\\\", \\\"{x:782,y:613,t:1527873144694};\\\", \\\"{x:783,y:614,t:1527873144734};\\\", \\\"{x:783,y:615,t:1527873144748};\\\", \\\"{x:784,y:615,t:1527873144761};\\\", \\\"{x:780,y:612,t:1527873144805};\\\", \\\"{x:784,y:617,t:1527873145421};\\\", \\\"{x:793,y:619,t:1527873145429};\\\", \\\"{x:812,y:624,t:1527873145446};\\\", \\\"{x:824,y:626,t:1527873145462};\\\", \\\"{x:838,y:630,t:1527873145479};\\\", \\\"{x:854,y:631,t:1527873145496};\\\", \\\"{x:863,y:631,t:1527873145512};\\\", \\\"{x:876,y:631,t:1527873145530};\\\", \\\"{x:884,y:631,t:1527873145545};\\\", \\\"{x:886,y:631,t:1527873145563};\\\", \\\"{x:889,y:631,t:1527873145579};\\\", \\\"{x:891,y:631,t:1527873145595};\\\", \\\"{x:902,y:630,t:1527873145612};\\\", \\\"{x:916,y:628,t:1527873145629};\\\", \\\"{x:925,y:626,t:1527873145645};\\\", \\\"{x:935,y:624,t:1527873145661};\\\", \\\"{x:943,y:621,t:1527873145679};\\\", \\\"{x:951,y:620,t:1527873145696};\\\", \\\"{x:960,y:619,t:1527873145712};\\\", \\\"{x:973,y:616,t:1527873145729};\\\", \\\"{x:988,y:612,t:1527873145746};\\\", \\\"{x:1007,y:605,t:1527873145762};\\\", \\\"{x:1024,y:600,t:1527873145779};\\\", \\\"{x:1044,y:595,t:1527873145796};\\\", \\\"{x:1055,y:590,t:1527873145812};\\\", \\\"{x:1060,y:588,t:1527873145830};\\\", \\\"{x:1064,y:586,t:1527873145846};\\\", \\\"{x:1068,y:582,t:1527873145863};\\\", \\\"{x:1072,y:580,t:1527873145879};\\\", \\\"{x:1079,y:575,t:1527873145896};\\\", \\\"{x:1089,y:570,t:1527873145912};\\\", \\\"{x:1098,y:568,t:1527873145930};\\\", \\\"{x:1109,y:564,t:1527873145947};\\\", \\\"{x:1128,y:560,t:1527873145962};\\\", \\\"{x:1145,y:557,t:1527873145979};\\\", \\\"{x:1174,y:547,t:1527873145996};\\\", \\\"{x:1189,y:542,t:1527873146012};\\\", \\\"{x:1200,y:539,t:1527873146029};\\\", \\\"{x:1208,y:536,t:1527873146046};\\\", \\\"{x:1216,y:532,t:1527873146062};\\\", \\\"{x:1225,y:529,t:1527873146080};\\\", \\\"{x:1240,y:522,t:1527873146097};\\\", \\\"{x:1253,y:516,t:1527873146114};\\\", \\\"{x:1268,y:511,t:1527873146129};\\\", \\\"{x:1281,y:507,t:1527873146146};\\\", \\\"{x:1290,y:503,t:1527873146163};\\\", \\\"{x:1294,y:502,t:1527873146180};\\\", \\\"{x:1296,y:500,t:1527873146197};\\\", \\\"{x:1297,y:500,t:1527873146213};\\\", \\\"{x:1298,y:500,t:1527873157301};\\\", \\\"{x:1304,y:502,t:1527873157309};\\\", \\\"{x:1307,y:506,t:1527873157323};\\\", \\\"{x:1309,y:507,t:1527873157340};\\\", \\\"{x:1311,y:511,t:1527873157356};\\\", \\\"{x:1316,y:522,t:1527873157373};\\\", \\\"{x:1321,y:531,t:1527873157390};\\\", \\\"{x:1322,y:535,t:1527873157407};\\\", \\\"{x:1323,y:537,t:1527873157423};\\\", \\\"{x:1323,y:538,t:1527873157441};\\\", \\\"{x:1324,y:540,t:1527873157456};\\\", \\\"{x:1325,y:543,t:1527873157474};\\\", \\\"{x:1328,y:551,t:1527873157491};\\\", \\\"{x:1332,y:562,t:1527873157506};\\\", \\\"{x:1337,y:573,t:1527873157522};\\\", \\\"{x:1339,y:580,t:1527873157540};\\\", \\\"{x:1342,y:586,t:1527873157556};\\\", \\\"{x:1347,y:594,t:1527873157573};\\\", \\\"{x:1349,y:602,t:1527873157590};\\\", \\\"{x:1353,y:608,t:1527873157606};\\\", \\\"{x:1354,y:614,t:1527873157623};\\\", \\\"{x:1357,y:616,t:1527873157639};\\\", \\\"{x:1357,y:618,t:1527873157656};\\\", \\\"{x:1357,y:620,t:1527873157672};\\\", \\\"{x:1357,y:626,t:1527873157690};\\\", \\\"{x:1356,y:631,t:1527873157706};\\\", \\\"{x:1358,y:630,t:1527873157723};\\\", \\\"{x:1361,y:626,t:1527873157740};\\\", \\\"{x:1362,y:625,t:1527873160158};\\\", \\\"{x:1365,y:625,t:1527873160165};\\\", \\\"{x:1365,y:624,t:1527873160176};\\\", \\\"{x:1366,y:623,t:1527873160244};\\\", \\\"{x:1366,y:625,t:1527873160268};\\\", \\\"{x:1366,y:631,t:1527873160276};\\\", \\\"{x:1366,y:642,t:1527873160292};\\\", \\\"{x:1366,y:656,t:1527873160308};\\\", \\\"{x:1366,y:668,t:1527873160325};\\\", \\\"{x:1366,y:680,t:1527873160341};\\\", \\\"{x:1366,y:693,t:1527873160359};\\\", \\\"{x:1369,y:702,t:1527873160375};\\\", \\\"{x:1370,y:713,t:1527873160392};\\\", \\\"{x:1373,y:724,t:1527873160409};\\\", \\\"{x:1373,y:730,t:1527873160425};\\\", \\\"{x:1374,y:738,t:1527873160442};\\\", \\\"{x:1375,y:744,t:1527873160459};\\\", \\\"{x:1375,y:748,t:1527873160475};\\\", \\\"{x:1377,y:750,t:1527873160492};\\\", \\\"{x:1377,y:751,t:1527873160524};\\\", \\\"{x:1377,y:752,t:1527873160542};\\\", \\\"{x:1378,y:755,t:1527873160559};\\\", \\\"{x:1378,y:756,t:1527873160575};\\\", \\\"{x:1381,y:760,t:1527873160592};\\\", \\\"{x:1381,y:762,t:1527873160609};\\\", \\\"{x:1381,y:763,t:1527873160625};\\\", \\\"{x:1382,y:764,t:1527873160652};\\\", \\\"{x:1384,y:767,t:1527873160660};\\\", \\\"{x:1385,y:769,t:1527873160677};\\\", \\\"{x:1389,y:774,t:1527873160692};\\\", \\\"{x:1396,y:779,t:1527873160708};\\\", \\\"{x:1407,y:784,t:1527873160726};\\\", \\\"{x:1414,y:788,t:1527873160742};\\\", \\\"{x:1422,y:791,t:1527873160759};\\\", \\\"{x:1429,y:795,t:1527873160777};\\\", \\\"{x:1432,y:798,t:1527873160792};\\\", \\\"{x:1435,y:800,t:1527873160809};\\\", \\\"{x:1437,y:802,t:1527873160826};\\\", \\\"{x:1438,y:803,t:1527873160842};\\\", \\\"{x:1441,y:805,t:1527873160859};\\\", \\\"{x:1444,y:806,t:1527873160876};\\\", \\\"{x:1447,y:808,t:1527873160892};\\\", \\\"{x:1449,y:809,t:1527873160908};\\\", \\\"{x:1452,y:810,t:1527873160925};\\\", \\\"{x:1454,y:811,t:1527873160942};\\\", \\\"{x:1458,y:812,t:1527873160959};\\\", \\\"{x:1459,y:813,t:1527873160977};\\\", \\\"{x:1462,y:815,t:1527873160992};\\\", \\\"{x:1465,y:818,t:1527873161009};\\\", \\\"{x:1468,y:820,t:1527873161027};\\\", \\\"{x:1470,y:821,t:1527873161042};\\\", \\\"{x:1472,y:823,t:1527873161059};\\\", \\\"{x:1476,y:824,t:1527873161076};\\\", \\\"{x:1477,y:824,t:1527873161108};\\\", \\\"{x:1478,y:825,t:1527873161144};\\\", \\\"{x:1478,y:826,t:1527873161159};\\\", \\\"{x:1479,y:826,t:1527873161188};\\\", \\\"{x:1479,y:827,t:1527873161227};\\\", \\\"{x:1479,y:828,t:1527873161244};\\\", \\\"{x:1479,y:829,t:1527873161258};\\\", \\\"{x:1479,y:830,t:1527873161308};\\\", \\\"{x:1479,y:831,t:1527873161324};\\\", \\\"{x:1480,y:832,t:1527873161348};\\\", \\\"{x:1481,y:834,t:1527873161372};\\\", \\\"{x:1482,y:834,t:1527873161509};\\\", \\\"{x:1483,y:834,t:1527873161526};\\\", \\\"{x:1485,y:834,t:1527873161556};\\\", \\\"{x:1486,y:834,t:1527873161654};\\\", \\\"{x:1488,y:834,t:1527873161678};\\\", \\\"{x:1489,y:834,t:1527873161694};\\\", \\\"{x:1491,y:834,t:1527873161740};\\\", \\\"{x:1492,y:834,t:1527873161765};\\\", \\\"{x:1493,y:833,t:1527873161776};\\\", \\\"{x:1494,y:833,t:1527873161794};\\\", \\\"{x:1495,y:833,t:1527873161811};\\\", \\\"{x:1498,y:832,t:1527873161828};\\\", \\\"{x:1502,y:832,t:1527873161844};\\\", \\\"{x:1512,y:831,t:1527873161861};\\\", \\\"{x:1517,y:829,t:1527873161876};\\\", \\\"{x:1521,y:828,t:1527873161893};\\\", \\\"{x:1528,y:828,t:1527873161910};\\\", \\\"{x:1535,y:828,t:1527873161927};\\\", \\\"{x:1540,y:828,t:1527873161943};\\\", \\\"{x:1544,y:828,t:1527873161961};\\\", \\\"{x:1550,y:828,t:1527873161977};\\\", \\\"{x:1554,y:828,t:1527873161994};\\\", \\\"{x:1555,y:828,t:1527873162010};\\\", \\\"{x:1558,y:828,t:1527873162027};\\\", \\\"{x:1560,y:828,t:1527873162045};\\\", \\\"{x:1561,y:828,t:1527873162069};\\\", \\\"{x:1563,y:828,t:1527873162077};\\\", \\\"{x:1565,y:828,t:1527873162093};\\\", \\\"{x:1567,y:828,t:1527873162111};\\\", \\\"{x:1569,y:828,t:1527873162127};\\\", \\\"{x:1570,y:828,t:1527873162143};\\\", \\\"{x:1571,y:828,t:1527873162165};\\\", \\\"{x:1572,y:828,t:1527873162189};\\\", \\\"{x:1573,y:828,t:1527873162197};\\\", \\\"{x:1574,y:828,t:1527873162213};\\\", \\\"{x:1576,y:829,t:1527873162228};\\\", \\\"{x:1581,y:831,t:1527873162245};\\\", \\\"{x:1584,y:832,t:1527873162261};\\\", \\\"{x:1586,y:832,t:1527873162277};\\\", \\\"{x:1587,y:832,t:1527873162295};\\\", \\\"{x:1588,y:832,t:1527873162333};\\\", \\\"{x:1589,y:832,t:1527873162345};\\\", \\\"{x:1592,y:832,t:1527873162361};\\\", \\\"{x:1596,y:832,t:1527873162377};\\\", \\\"{x:1598,y:832,t:1527873162397};\\\", \\\"{x:1599,y:832,t:1527873162410};\\\", \\\"{x:1600,y:832,t:1527873162501};\\\", \\\"{x:1602,y:833,t:1527873162707};\\\", \\\"{x:1603,y:833,t:1527873162739};\\\", \\\"{x:1604,y:833,t:1527873162780};\\\", \\\"{x:1605,y:833,t:1527873162804};\\\", \\\"{x:1607,y:833,t:1527873164574};\\\", \\\"{x:1608,y:833,t:1527873164605};\\\", \\\"{x:1609,y:833,t:1527873164645};\\\", \\\"{x:1603,y:833,t:1527873174616};\\\", \\\"{x:1572,y:833,t:1527873174624};\\\", \\\"{x:1465,y:822,t:1527873174641};\\\", \\\"{x:1324,y:803,t:1527873174658};\\\", \\\"{x:1146,y:774,t:1527873174674};\\\", \\\"{x:967,y:751,t:1527873174692};\\\", \\\"{x:812,y:727,t:1527873174708};\\\", \\\"{x:695,y:709,t:1527873174725};\\\", \\\"{x:609,y:686,t:1527873174741};\\\", \\\"{x:553,y:659,t:1527873174758};\\\", \\\"{x:543,y:654,t:1527873174775};\\\", \\\"{x:542,y:654,t:1527873175439};\\\", \\\"{x:541,y:654,t:1527873175447};\\\", \\\"{x:540,y:653,t:1527873175471};\\\", \\\"{x:540,y:652,t:1527873175535};\\\", \\\"{x:539,y:652,t:1527873176024};\\\", \\\"{x:544,y:651,t:1527873176656};\\\", \\\"{x:555,y:650,t:1527873176664};\\\", \\\"{x:569,y:647,t:1527873176677};\\\", \\\"{x:619,y:633,t:1527873176693};\\\", \\\"{x:687,y:619,t:1527873176711};\\\", \\\"{x:762,y:610,t:1527873176727};\\\", \\\"{x:804,y:605,t:1527873176742};\\\", \\\"{x:829,y:599,t:1527873176758};\\\", \\\"{x:845,y:594,t:1527873176774};\\\", \\\"{x:851,y:589,t:1527873176792};\\\", \\\"{x:852,y:587,t:1527873176809};\\\", \\\"{x:854,y:584,t:1527873176825};\\\", \\\"{x:859,y:581,t:1527873176842};\\\", \\\"{x:865,y:579,t:1527873176858};\\\", \\\"{x:878,y:576,t:1527873176875};\\\", \\\"{x:893,y:575,t:1527873176892};\\\", \\\"{x:911,y:575,t:1527873176908};\\\", \\\"{x:933,y:581,t:1527873176925};\\\", \\\"{x:960,y:589,t:1527873176942};\\\", \\\"{x:993,y:597,t:1527873176958};\\\", \\\"{x:1041,y:608,t:1527873176976};\\\", \\\"{x:1084,y:615,t:1527873176992};\\\", \\\"{x:1134,y:621,t:1527873177008};\\\", \\\"{x:1188,y:624,t:1527873177026};\\\", \\\"{x:1249,y:633,t:1527873177043};\\\", \\\"{x:1285,y:635,t:1527873177058};\\\", \\\"{x:1308,y:635,t:1527873177075};\\\", \\\"{x:1322,y:635,t:1527873177093};\\\", \\\"{x:1327,y:635,t:1527873177109};\\\", \\\"{x:1328,y:635,t:1527873177125};\\\", \\\"{x:1330,y:635,t:1527873177142};\\\", \\\"{x:1335,y:634,t:1527873177160};\\\", \\\"{x:1335,y:633,t:1527873177176};\\\", \\\"{x:1335,y:632,t:1527873177192};\\\", \\\"{x:1335,y:629,t:1527873177210};\\\", \\\"{x:1335,y:627,t:1527873177225};\\\", \\\"{x:1333,y:624,t:1527873177242};\\\", \\\"{x:1330,y:621,t:1527873177259};\\\", \\\"{x:1327,y:619,t:1527873177276};\\\", \\\"{x:1322,y:617,t:1527873177292};\\\", \\\"{x:1319,y:616,t:1527873177310};\\\", \\\"{x:1319,y:615,t:1527873177327};\\\", \\\"{x:1318,y:615,t:1527873177369};\\\", \\\"{x:1318,y:614,t:1527873177392};\\\", \\\"{x:1317,y:614,t:1527873177410};\\\", \\\"{x:1316,y:612,t:1527873177427};\\\", \\\"{x:1315,y:612,t:1527873177443};\\\", \\\"{x:1315,y:611,t:1527873177472};\\\", \\\"{x:1314,y:611,t:1527873177488};\\\", \\\"{x:1313,y:609,t:1527873177496};\\\", \\\"{x:1312,y:608,t:1527873177527};\\\", \\\"{x:1312,y:607,t:1527873177576};\\\", \\\"{x:1312,y:606,t:1527873177608};\\\", \\\"{x:1311,y:606,t:1527873178585};\\\", \\\"{x:1310,y:606,t:1527873178648};\\\", \\\"{x:1309,y:605,t:1527873178660};\\\", \\\"{x:1307,y:605,t:1527873178696};\\\", \\\"{x:1306,y:604,t:1527873178720};\\\", \\\"{x:1304,y:604,t:1527873178776};\\\", \\\"{x:1304,y:603,t:1527873178799};\\\", \\\"{x:1302,y:605,t:1527873181345};\\\", \\\"{x:1291,y:607,t:1527873181352};\\\", \\\"{x:1284,y:607,t:1527873181364};\\\", \\\"{x:1269,y:609,t:1527873181381};\\\", \\\"{x:1252,y:613,t:1527873181398};\\\", \\\"{x:1237,y:614,t:1527873181414};\\\", \\\"{x:1225,y:615,t:1527873181431};\\\", \\\"{x:1202,y:615,t:1527873181448};\\\", \\\"{x:1184,y:615,t:1527873181463};\\\", \\\"{x:1165,y:612,t:1527873181481};\\\", \\\"{x:1139,y:604,t:1527873181498};\\\", \\\"{x:1105,y:594,t:1527873181515};\\\", \\\"{x:1058,y:580,t:1527873181530};\\\", \\\"{x:990,y:566,t:1527873181548};\\\", \\\"{x:915,y:557,t:1527873181565};\\\", \\\"{x:839,y:545,t:1527873181582};\\\", \\\"{x:751,y:533,t:1527873181597};\\\", \\\"{x:700,y:532,t:1527873181615};\\\", \\\"{x:665,y:531,t:1527873181629};\\\", \\\"{x:643,y:527,t:1527873181645};\\\", \\\"{x:629,y:526,t:1527873181662};\\\", \\\"{x:624,y:526,t:1527873181679};\\\", \\\"{x:623,y:526,t:1527873181727};\\\", \\\"{x:622,y:526,t:1527873181735};\\\", \\\"{x:622,y:528,t:1527873181747};\\\", \\\"{x:621,y:531,t:1527873181762};\\\", \\\"{x:618,y:535,t:1527873181780};\\\", \\\"{x:617,y:535,t:1527873181796};\\\", \\\"{x:617,y:537,t:1527873181813};\\\", \\\"{x:616,y:535,t:1527873181830};\\\", \\\"{x:618,y:528,t:1527873181846};\\\", \\\"{x:622,y:522,t:1527873181865};\\\", \\\"{x:623,y:522,t:1527873182128};\\\", \\\"{x:624,y:522,t:1527873182146};\\\", \\\"{x:625,y:522,t:1527873182163};\\\", \\\"{x:625,y:519,t:1527873182297};\\\", \\\"{x:630,y:509,t:1527873182315};\\\", \\\"{x:641,y:500,t:1527873182330};\\\", \\\"{x:653,y:491,t:1527873182346};\\\", \\\"{x:662,y:485,t:1527873182363};\\\", \\\"{x:668,y:481,t:1527873182379};\\\", \\\"{x:671,y:480,t:1527873182396};\\\", \\\"{x:669,y:480,t:1527873182503};\\\", \\\"{x:663,y:480,t:1527873182514};\\\", \\\"{x:648,y:480,t:1527873182530};\\\", \\\"{x:638,y:480,t:1527873182547};\\\", \\\"{x:629,y:483,t:1527873182563};\\\", \\\"{x:626,y:484,t:1527873182580};\\\", \\\"{x:625,y:484,t:1527873182597};\\\", \\\"{x:625,y:485,t:1527873182656};\\\", \\\"{x:625,y:486,t:1527873182671};\\\", \\\"{x:625,y:487,t:1527873182687};\\\", \\\"{x:625,y:489,t:1527873182718};\\\", \\\"{x:625,y:490,t:1527873182735};\\\", \\\"{x:625,y:491,t:1527873182746};\\\", \\\"{x:625,y:493,t:1527873182763};\\\", \\\"{x:624,y:495,t:1527873182780};\\\", \\\"{x:624,y:496,t:1527873182796};\\\", \\\"{x:623,y:497,t:1527873183040};\\\", \\\"{x:620,y:499,t:1527873183055};\\\", \\\"{x:617,y:503,t:1527873183063};\\\", \\\"{x:608,y:515,t:1527873183081};\\\", \\\"{x:590,y:540,t:1527873183098};\\\", \\\"{x:572,y:571,t:1527873183114};\\\", \\\"{x:558,y:595,t:1527873183131};\\\", \\\"{x:545,y:611,t:1527873183148};\\\", \\\"{x:542,y:617,t:1527873183163};\\\", \\\"{x:540,y:622,t:1527873183181};\\\", \\\"{x:539,y:628,t:1527873183196};\\\", \\\"{x:534,y:644,t:1527873183214};\\\", \\\"{x:531,y:658,t:1527873183230};\\\", \\\"{x:528,y:667,t:1527873183246};\\\", \\\"{x:525,y:677,t:1527873183264};\\\", \\\"{x:524,y:679,t:1527873183281};\\\", \\\"{x:524,y:681,t:1527873183297};\\\", \\\"{x:524,y:682,t:1527873183313};\\\", \\\"{x:524,y:684,t:1527873183335};\\\", \\\"{x:524,y:685,t:1527873183360};\\\", \\\"{x:524,y:687,t:1527873183368};\\\", \\\"{x:524,y:689,t:1527873183380};\\\", \\\"{x:524,y:695,t:1527873183398};\\\", \\\"{x:524,y:700,t:1527873183414};\\\", \\\"{x:523,y:707,t:1527873183431};\\\", \\\"{x:521,y:719,t:1527873183448};\\\", \\\"{x:521,y:723,t:1527873183465};\\\", \\\"{x:521,y:728,t:1527873183480};\\\", \\\"{x:521,y:731,t:1527873183498};\\\", \\\"{x:521,y:735,t:1527873183513};\\\", \\\"{x:521,y:737,t:1527873183530};\\\", \\\"{x:521,y:738,t:1527873183547};\\\", \\\"{x:521,y:740,t:1527873183751};\\\", \\\"{x:520,y:741,t:1527873183799};\\\", \\\"{x:519,y:741,t:1527873183847};\\\" ] }, { \\\"rt\\\": 47261, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 13, \\\"time_elapsed\\\": 423479, \\\"internal_node_id\\\": \\\"0.0-6.0-3.0\\\", \\\"subject\\\": \\\"2OEC4\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"whiskey\\\", \\\"condition\\\": \\\"115\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"starttime+before+endtime+during\\\", \\\"q\\\": 9, \\\"clicks\\\": 1, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XFull-YFull\\\", \\\"correct\\\": 1, \\\"orth_correct\\\": 1, \\\"answer\\\": [ \\\"I\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-I -J -3\\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:518,y:739,t:1527873185408};\\\", \\\"{x:518,y:736,t:1527873185416};\\\", \\\"{x:517,y:730,t:1527873185433};\\\", \\\"{x:517,y:723,t:1527873185450};\\\", \\\"{x:527,y:702,t:1527873185525};\\\", \\\"{x:529,y:701,t:1527873185533};\\\", \\\"{x:533,y:698,t:1527873185549};\\\", \\\"{x:534,y:697,t:1527873185567};\\\", \\\"{x:535,y:697,t:1527873185792};\\\", \\\"{x:536,y:695,t:1527873185807};\\\", \\\"{x:538,y:695,t:1527873185824};\\\", \\\"{x:539,y:695,t:1527873185833};\\\", \\\"{x:543,y:695,t:1527873185850};\\\", \\\"{x:546,y:695,t:1527873185866};\\\", \\\"{x:550,y:694,t:1527873185883};\\\", \\\"{x:553,y:694,t:1527873185899};\\\", \\\"{x:555,y:694,t:1527873185916};\\\", \\\"{x:556,y:693,t:1527873185933};\\\", \\\"{x:557,y:693,t:1527873186320};\\\", \\\"{x:559,y:692,t:1527873186333};\\\", \\\"{x:561,y:691,t:1527873186350};\\\", \\\"{x:565,y:690,t:1527873186367};\\\", \\\"{x:569,y:687,t:1527873186383};\\\", \\\"{x:578,y:683,t:1527873186400};\\\", \\\"{x:580,y:682,t:1527873186416};\\\", \\\"{x:581,y:682,t:1527873186433};\\\", \\\"{x:582,y:681,t:1527873186480};\\\", \\\"{x:582,y:680,t:1527873186512};\\\", \\\"{x:583,y:680,t:1527873186520};\\\", \\\"{x:584,y:680,t:1527873186536};\\\", \\\"{x:585,y:680,t:1527873186568};\\\", \\\"{x:588,y:680,t:1527873186583};\\\", \\\"{x:592,y:680,t:1527873186600};\\\", \\\"{x:604,y:680,t:1527873186617};\\\", \\\"{x:623,y:684,t:1527873186634};\\\", \\\"{x:650,y:688,t:1527873186650};\\\", \\\"{x:680,y:693,t:1527873186666};\\\", \\\"{x:709,y:693,t:1527873186683};\\\", \\\"{x:710,y:694,t:1527873186700};\\\", \\\"{x:711,y:694,t:1527873187240};\\\", \\\"{x:731,y:695,t:1527873187250};\\\", \\\"{x:808,y:704,t:1527873187267};\\\", \\\"{x:887,y:719,t:1527873187284};\\\", \\\"{x:965,y:730,t:1527873187301};\\\", \\\"{x:1039,y:739,t:1527873187318};\\\", \\\"{x:1096,y:748,t:1527873187334};\\\", \\\"{x:1129,y:751,t:1527873187352};\\\", \\\"{x:1150,y:751,t:1527873187368};\\\", \\\"{x:1152,y:751,t:1527873187384};\\\", \\\"{x:1153,y:751,t:1527873187424};\\\", \\\"{x:1154,y:751,t:1527873187448};\\\", \\\"{x:1156,y:750,t:1527873187464};\\\", \\\"{x:1157,y:750,t:1527873187480};\\\", \\\"{x:1160,y:750,t:1527873187488};\\\", \\\"{x:1162,y:748,t:1527873187501};\\\", \\\"{x:1167,y:748,t:1527873187518};\\\", \\\"{x:1176,y:747,t:1527873187535};\\\", \\\"{x:1186,y:746,t:1527873187552};\\\", \\\"{x:1203,y:744,t:1527873187568};\\\", \\\"{x:1213,y:743,t:1527873187584};\\\", \\\"{x:1223,y:742,t:1527873187601};\\\", \\\"{x:1233,y:739,t:1527873187618};\\\", \\\"{x:1246,y:738,t:1527873187634};\\\", \\\"{x:1256,y:738,t:1527873187651};\\\", \\\"{x:1267,y:737,t:1527873187668};\\\", \\\"{x:1274,y:735,t:1527873187684};\\\", \\\"{x:1282,y:734,t:1527873187701};\\\", \\\"{x:1289,y:733,t:1527873187718};\\\", \\\"{x:1292,y:733,t:1527873187734};\\\", \\\"{x:1293,y:733,t:1527873187752};\\\", \\\"{x:1295,y:733,t:1527873187768};\\\", \\\"{x:1296,y:731,t:1527873187784};\\\", \\\"{x:1298,y:731,t:1527873187801};\\\", \\\"{x:1302,y:731,t:1527873187818};\\\", \\\"{x:1306,y:731,t:1527873187835};\\\", \\\"{x:1313,y:731,t:1527873187851};\\\", \\\"{x:1321,y:731,t:1527873187868};\\\", \\\"{x:1327,y:731,t:1527873187886};\\\", \\\"{x:1334,y:731,t:1527873187901};\\\", \\\"{x:1338,y:730,t:1527873187919};\\\", \\\"{x:1341,y:729,t:1527873187936};\\\", \\\"{x:1346,y:728,t:1527873187952};\\\", \\\"{x:1349,y:727,t:1527873187968};\\\", \\\"{x:1351,y:726,t:1527873187986};\\\", \\\"{x:1353,y:726,t:1527873188008};\\\", \\\"{x:1355,y:726,t:1527873188024};\\\", \\\"{x:1356,y:724,t:1527873188040};\\\", \\\"{x:1357,y:724,t:1527873188052};\\\", \\\"{x:1358,y:724,t:1527873188068};\\\", \\\"{x:1360,y:724,t:1527873188085};\\\", \\\"{x:1361,y:724,t:1527873188102};\\\", \\\"{x:1362,y:724,t:1527873188120};\\\", \\\"{x:1363,y:724,t:1527873188135};\\\", \\\"{x:1366,y:724,t:1527873188152};\\\", \\\"{x:1369,y:724,t:1527873188168};\\\", \\\"{x:1371,y:724,t:1527873188185};\\\", \\\"{x:1373,y:724,t:1527873188202};\\\", \\\"{x:1374,y:724,t:1527873188219};\\\", \\\"{x:1376,y:724,t:1527873188235};\\\", \\\"{x:1377,y:724,t:1527873188252};\\\", \\\"{x:1379,y:725,t:1527873188268};\\\", \\\"{x:1384,y:728,t:1527873188285};\\\", \\\"{x:1388,y:728,t:1527873188302};\\\", \\\"{x:1391,y:731,t:1527873188319};\\\", \\\"{x:1395,y:734,t:1527873188335};\\\", \\\"{x:1399,y:736,t:1527873188352};\\\", \\\"{x:1400,y:738,t:1527873188368};\\\", \\\"{x:1401,y:739,t:1527873188400};\\\", \\\"{x:1402,y:739,t:1527873188408};\\\", \\\"{x:1402,y:740,t:1527873188419};\\\", \\\"{x:1404,y:743,t:1527873188435};\\\", \\\"{x:1405,y:744,t:1527873188453};\\\", \\\"{x:1406,y:745,t:1527873188469};\\\", \\\"{x:1407,y:748,t:1527873188486};\\\", \\\"{x:1408,y:749,t:1527873188502};\\\", \\\"{x:1408,y:750,t:1527873188518};\\\", \\\"{x:1409,y:751,t:1527873188535};\\\", \\\"{x:1409,y:752,t:1527873188552};\\\", \\\"{x:1409,y:753,t:1527873188569};\\\", \\\"{x:1409,y:754,t:1527873188585};\\\", \\\"{x:1409,y:756,t:1527873188602};\\\", \\\"{x:1409,y:757,t:1527873188618};\\\", \\\"{x:1408,y:759,t:1527873188635};\\\", \\\"{x:1407,y:760,t:1527873188652};\\\", \\\"{x:1406,y:762,t:1527873188669};\\\", \\\"{x:1405,y:763,t:1527873188685};\\\", \\\"{x:1403,y:765,t:1527873188703};\\\", \\\"{x:1403,y:766,t:1527873188720};\\\", \\\"{x:1401,y:767,t:1527873188734};\\\", \\\"{x:1400,y:768,t:1527873188759};\\\", \\\"{x:1399,y:769,t:1527873188769};\\\", \\\"{x:1398,y:770,t:1527873188785};\\\", \\\"{x:1397,y:771,t:1527873188801};\\\", \\\"{x:1395,y:773,t:1527873188818};\\\", \\\"{x:1394,y:774,t:1527873188834};\\\", \\\"{x:1393,y:774,t:1527873188852};\\\", \\\"{x:1392,y:774,t:1527873188868};\\\", \\\"{x:1391,y:775,t:1527873188895};\\\", \\\"{x:1390,y:776,t:1527873188911};\\\", \\\"{x:1389,y:776,t:1527873188927};\\\", \\\"{x:1388,y:776,t:1527873188944};\\\", \\\"{x:1388,y:777,t:1527873188951};\\\", \\\"{x:1386,y:778,t:1527873188969};\\\", \\\"{x:1385,y:779,t:1527873188984};\\\", \\\"{x:1385,y:780,t:1527873189007};\\\", \\\"{x:1384,y:780,t:1527873189023};\\\", \\\"{x:1383,y:780,t:1527873189081};\\\", \\\"{x:1382,y:781,t:1527873189120};\\\", \\\"{x:1381,y:781,t:1527873189136};\\\", \\\"{x:1380,y:782,t:1527873189152};\\\", \\\"{x:1379,y:783,t:1527873189176};\\\", \\\"{x:1378,y:783,t:1527873189192};\\\", \\\"{x:1377,y:783,t:1527873189203};\\\", \\\"{x:1376,y:784,t:1527873189264};\\\", \\\"{x:1375,y:784,t:1527873189320};\\\", \\\"{x:1374,y:785,t:1527873189336};\\\", \\\"{x:1372,y:786,t:1527873189368};\\\", \\\"{x:1371,y:786,t:1527873189387};\\\", \\\"{x:1370,y:788,t:1527873189401};\\\", \\\"{x:1369,y:788,t:1527873189419};\\\", \\\"{x:1368,y:788,t:1527873189439};\\\", \\\"{x:1367,y:788,t:1527873189456};\\\", \\\"{x:1367,y:789,t:1527873189469};\\\", \\\"{x:1366,y:789,t:1527873189486};\\\", \\\"{x:1365,y:789,t:1527873189502};\\\", \\\"{x:1363,y:791,t:1527873189519};\\\", \\\"{x:1360,y:791,t:1527873189536};\\\", \\\"{x:1358,y:793,t:1527873189554};\\\", \\\"{x:1355,y:794,t:1527873189569};\\\", \\\"{x:1354,y:795,t:1527873189587};\\\", \\\"{x:1351,y:796,t:1527873189604};\\\", \\\"{x:1349,y:796,t:1527873189624};\\\", \\\"{x:1348,y:796,t:1527873189647};\\\", \\\"{x:1347,y:798,t:1527873189656};\\\", \\\"{x:1346,y:798,t:1527873189672};\\\", \\\"{x:1344,y:799,t:1527873189687};\\\", \\\"{x:1342,y:800,t:1527873189703};\\\", \\\"{x:1340,y:800,t:1527873189719};\\\", \\\"{x:1337,y:802,t:1527873189736};\\\", \\\"{x:1335,y:803,t:1527873189753};\\\", \\\"{x:1334,y:803,t:1527873189769};\\\", \\\"{x:1333,y:804,t:1527873189786};\\\", \\\"{x:1331,y:805,t:1527873189803};\\\", \\\"{x:1329,y:805,t:1527873189820};\\\", \\\"{x:1328,y:805,t:1527873189836};\\\", \\\"{x:1326,y:806,t:1527873189853};\\\", \\\"{x:1324,y:807,t:1527873189869};\\\", \\\"{x:1323,y:808,t:1527873189886};\\\", \\\"{x:1321,y:809,t:1527873189905};\\\", \\\"{x:1320,y:809,t:1527873189919};\\\", \\\"{x:1317,y:811,t:1527873189935};\\\", \\\"{x:1315,y:811,t:1527873189952};\\\", \\\"{x:1313,y:812,t:1527873189976};\\\", \\\"{x:1312,y:812,t:1527873190000};\\\", \\\"{x:1310,y:813,t:1527873190015};\\\", \\\"{x:1309,y:813,t:1527873190032};\\\", \\\"{x:1306,y:813,t:1527873190040};\\\", \\\"{x:1306,y:814,t:1527873190054};\\\", \\\"{x:1303,y:815,t:1527873190070};\\\", \\\"{x:1299,y:815,t:1527873190087};\\\", \\\"{x:1289,y:819,t:1527873190104};\\\", \\\"{x:1285,y:819,t:1527873190120};\\\", \\\"{x:1279,y:822,t:1527873190136};\\\", \\\"{x:1274,y:823,t:1527873190153};\\\", \\\"{x:1271,y:825,t:1527873190170};\\\", \\\"{x:1268,y:827,t:1527873190186};\\\", \\\"{x:1265,y:828,t:1527873190203};\\\", \\\"{x:1263,y:829,t:1527873190220};\\\", \\\"{x:1263,y:830,t:1527873190236};\\\", \\\"{x:1261,y:831,t:1527873190254};\\\", \\\"{x:1259,y:832,t:1527873190270};\\\", \\\"{x:1258,y:833,t:1527873190286};\\\", \\\"{x:1256,y:833,t:1527873190303};\\\", \\\"{x:1253,y:835,t:1527873190319};\\\", \\\"{x:1252,y:836,t:1527873190336};\\\", \\\"{x:1250,y:837,t:1527873190353};\\\", \\\"{x:1249,y:837,t:1527873190370};\\\", \\\"{x:1248,y:837,t:1527873190386};\\\", \\\"{x:1247,y:837,t:1527873190402};\\\", \\\"{x:1246,y:837,t:1527873190439};\\\", \\\"{x:1245,y:837,t:1527873190520};\\\", \\\"{x:1244,y:838,t:1527873190544};\\\", \\\"{x:1243,y:838,t:1527873190576};\\\", \\\"{x:1243,y:839,t:1527873190592};\\\", \\\"{x:1242,y:839,t:1527873190624};\\\", \\\"{x:1241,y:839,t:1527873190689};\\\", \\\"{x:1240,y:840,t:1527873190703};\\\", \\\"{x:1239,y:840,t:1527873190935};\\\", \\\"{x:1238,y:840,t:1527873190952};\\\", \\\"{x:1237,y:840,t:1527873190998};\\\", \\\"{x:1236,y:840,t:1527873191055};\\\", \\\"{x:1235,y:840,t:1527873191111};\\\", \\\"{x:1234,y:840,t:1527873191208};\\\", \\\"{x:1232,y:841,t:1527873191240};\\\", \\\"{x:1231,y:842,t:1527873191264};\\\", \\\"{x:1230,y:842,t:1527873191393};\\\", \\\"{x:1229,y:843,t:1527873191407};\\\", \\\"{x:1228,y:843,t:1527873191472};\\\", \\\"{x:1227,y:843,t:1527873191529};\\\", \\\"{x:1226,y:843,t:1527873191584};\\\", \\\"{x:1225,y:844,t:1527873191592};\\\", \\\"{x:1224,y:845,t:1527873191792};\\\", \\\"{x:1223,y:845,t:1527873191808};\\\", \\\"{x:1222,y:845,t:1527873191864};\\\", \\\"{x:1222,y:846,t:1527873191920};\\\", \\\"{x:1221,y:846,t:1527873191968};\\\", \\\"{x:1220,y:846,t:1527873192160};\\\", \\\"{x:1219,y:846,t:1527873192184};\\\", \\\"{x:1218,y:846,t:1527873192216};\\\", \\\"{x:1217,y:846,t:1527873192224};\\\", \\\"{x:1216,y:846,t:1527873192239};\\\", \\\"{x:1215,y:846,t:1527873192256};\\\", \\\"{x:1214,y:846,t:1527873192271};\\\", \\\"{x:1210,y:846,t:1527873192288};\\\", \\\"{x:1207,y:846,t:1527873192305};\\\", \\\"{x:1206,y:846,t:1527873192322};\\\", \\\"{x:1204,y:846,t:1527873192338};\\\", \\\"{x:1201,y:846,t:1527873192355};\\\", \\\"{x:1200,y:846,t:1527873192372};\\\", \\\"{x:1199,y:846,t:1527873192389};\\\", \\\"{x:1198,y:846,t:1527873192406};\\\", \\\"{x:1197,y:846,t:1527873192421};\\\", \\\"{x:1196,y:846,t:1527873192456};\\\", \\\"{x:1195,y:846,t:1527873192471};\\\", \\\"{x:1193,y:846,t:1527873192488};\\\", \\\"{x:1192,y:846,t:1527873192505};\\\", \\\"{x:1190,y:846,t:1527873192521};\\\", \\\"{x:1187,y:846,t:1527873192539};\\\", \\\"{x:1185,y:846,t:1527873192555};\\\", \\\"{x:1179,y:846,t:1527873192571};\\\", \\\"{x:1173,y:846,t:1527873192588};\\\", \\\"{x:1168,y:846,t:1527873192605};\\\", \\\"{x:1159,y:846,t:1527873192622};\\\", \\\"{x:1155,y:848,t:1527873192638};\\\", \\\"{x:1152,y:848,t:1527873192654};\\\", \\\"{x:1149,y:848,t:1527873192671};\\\", \\\"{x:1148,y:848,t:1527873192719};\\\", \\\"{x:1147,y:848,t:1527873193105};\\\", \\\"{x:1145,y:849,t:1527873193122};\\\", \\\"{x:1147,y:849,t:1527873203184};\\\", \\\"{x:1157,y:849,t:1527873203196};\\\", \\\"{x:1176,y:848,t:1527873203214};\\\", \\\"{x:1198,y:848,t:1527873203231};\\\", \\\"{x:1217,y:848,t:1527873203247};\\\", \\\"{x:1240,y:846,t:1527873203263};\\\", \\\"{x:1243,y:845,t:1527873203280};\\\", \\\"{x:1244,y:845,t:1527873203297};\\\", \\\"{x:1245,y:844,t:1527873203375};\\\", \\\"{x:1245,y:843,t:1527873203656};\\\", \\\"{x:1245,y:839,t:1527873203663};\\\", \\\"{x:1244,y:830,t:1527873203681};\\\", \\\"{x:1241,y:822,t:1527873203698};\\\", \\\"{x:1239,y:818,t:1527873203714};\\\", \\\"{x:1238,y:815,t:1527873203731};\\\", \\\"{x:1236,y:813,t:1527873203748};\\\", \\\"{x:1236,y:812,t:1527873203764};\\\", \\\"{x:1234,y:812,t:1527873203992};\\\", \\\"{x:1233,y:812,t:1527873204008};\\\", \\\"{x:1232,y:812,t:1527873204031};\\\", \\\"{x:1231,y:812,t:1527873204055};\\\", \\\"{x:1230,y:812,t:1527873204064};\\\", \\\"{x:1228,y:814,t:1527873204081};\\\", \\\"{x:1226,y:816,t:1527873204097};\\\", \\\"{x:1224,y:816,t:1527873204115};\\\", \\\"{x:1222,y:818,t:1527873204131};\\\", \\\"{x:1220,y:818,t:1527873204148};\\\", \\\"{x:1219,y:819,t:1527873204192};\\\", \\\"{x:1217,y:820,t:1527873204232};\\\", \\\"{x:1217,y:821,t:1527873204248};\\\", \\\"{x:1216,y:822,t:1527873204264};\\\", \\\"{x:1216,y:823,t:1527873204768};\\\", \\\"{x:1216,y:824,t:1527873204784};\\\", \\\"{x:1216,y:825,t:1527873204814};\\\", \\\"{x:1215,y:827,t:1527873204831};\\\", \\\"{x:1214,y:829,t:1527873204848};\\\", \\\"{x:1214,y:830,t:1527873204864};\\\", \\\"{x:1214,y:831,t:1527873204881};\\\", \\\"{x:1213,y:834,t:1527873204898};\\\", \\\"{x:1213,y:837,t:1527873204914};\\\", \\\"{x:1213,y:839,t:1527873204931};\\\", \\\"{x:1213,y:840,t:1527873204949};\\\", \\\"{x:1213,y:841,t:1527873204964};\\\", \\\"{x:1213,y:843,t:1527873204991};\\\", \\\"{x:1213,y:844,t:1527873205007};\\\", \\\"{x:1213,y:846,t:1527873205030};\\\", \\\"{x:1213,y:844,t:1527873205711};\\\", \\\"{x:1212,y:843,t:1527873205719};\\\", \\\"{x:1212,y:842,t:1527873205743};\\\", \\\"{x:1212,y:841,t:1527873205752};\\\", \\\"{x:1211,y:840,t:1527873205765};\\\", \\\"{x:1210,y:840,t:1527873205790};\\\", \\\"{x:1210,y:839,t:1527873205823};\\\", \\\"{x:1210,y:838,t:1527873205832};\\\", \\\"{x:1209,y:837,t:1527873205871};\\\", \\\"{x:1209,y:836,t:1527873205887};\\\", \\\"{x:1207,y:835,t:1527873205903};\\\", \\\"{x:1207,y:834,t:1527873205927};\\\", \\\"{x:1206,y:834,t:1527873205935};\\\", \\\"{x:1206,y:833,t:1527873205948};\\\", \\\"{x:1206,y:832,t:1527873205965};\\\", \\\"{x:1205,y:831,t:1527873205983};\\\", \\\"{x:1204,y:831,t:1527873205998};\\\", \\\"{x:1203,y:829,t:1527873206016};\\\", \\\"{x:1202,y:828,t:1527873206040};\\\", \\\"{x:1201,y:828,t:1527873206049};\\\", \\\"{x:1200,y:827,t:1527873206112};\\\", \\\"{x:1198,y:826,t:1527873206135};\\\", \\\"{x:1197,y:825,t:1527873206151};\\\", \\\"{x:1196,y:825,t:1527873206168};\\\", \\\"{x:1195,y:825,t:1527873206183};\\\", \\\"{x:1194,y:825,t:1527873206216};\\\", \\\"{x:1193,y:824,t:1527873206247};\\\", \\\"{x:1192,y:824,t:1527873206271};\\\", \\\"{x:1190,y:822,t:1527873206288};\\\", \\\"{x:1189,y:822,t:1527873206305};\\\", \\\"{x:1188,y:821,t:1527873206316};\\\", \\\"{x:1186,y:820,t:1527873206332};\\\", \\\"{x:1184,y:818,t:1527873206350};\\\", \\\"{x:1180,y:815,t:1527873206366};\\\", \\\"{x:1178,y:814,t:1527873206383};\\\", \\\"{x:1175,y:811,t:1527873206399};\\\", \\\"{x:1174,y:810,t:1527873206416};\\\", \\\"{x:1173,y:809,t:1527873206433};\\\", \\\"{x:1170,y:803,t:1527873206450};\\\", \\\"{x:1169,y:800,t:1527873206466};\\\", \\\"{x:1168,y:797,t:1527873206483};\\\", \\\"{x:1167,y:796,t:1527873206500};\\\", \\\"{x:1167,y:795,t:1527873206515};\\\", \\\"{x:1167,y:793,t:1527873206533};\\\", \\\"{x:1167,y:792,t:1527873206549};\\\", \\\"{x:1167,y:788,t:1527873206566};\\\", \\\"{x:1167,y:787,t:1527873206583};\\\", \\\"{x:1167,y:781,t:1527873206600};\\\", \\\"{x:1167,y:778,t:1527873206616};\\\", \\\"{x:1167,y:777,t:1527873206640};\\\", \\\"{x:1167,y:775,t:1527873206655};\\\", \\\"{x:1167,y:774,t:1527873206680};\\\", \\\"{x:1168,y:772,t:1527873207047};\\\", \\\"{x:1169,y:771,t:1527873207055};\\\", \\\"{x:1170,y:770,t:1527873207067};\\\", \\\"{x:1171,y:770,t:1527873207084};\\\", \\\"{x:1173,y:770,t:1527873207100};\\\", \\\"{x:1166,y:770,t:1527873208560};\\\", \\\"{x:1155,y:772,t:1527873208568};\\\", \\\"{x:1123,y:776,t:1527873208584};\\\", \\\"{x:1049,y:783,t:1527873208601};\\\", \\\"{x:966,y:783,t:1527873208617};\\\", \\\"{x:899,y:783,t:1527873208634};\\\", \\\"{x:838,y:783,t:1527873208650};\\\", \\\"{x:796,y:783,t:1527873208667};\\\", \\\"{x:759,y:783,t:1527873208684};\\\", \\\"{x:733,y:783,t:1527873208701};\\\", \\\"{x:714,y:783,t:1527873208717};\\\", \\\"{x:692,y:783,t:1527873208734};\\\", \\\"{x:681,y:786,t:1527873208750};\\\", \\\"{x:663,y:786,t:1527873208767};\\\", \\\"{x:636,y:786,t:1527873208785};\\\", \\\"{x:611,y:786,t:1527873208801};\\\", \\\"{x:592,y:785,t:1527873208817};\\\", \\\"{x:576,y:780,t:1527873208835};\\\", \\\"{x:565,y:776,t:1527873208851};\\\", \\\"{x:561,y:775,t:1527873208868};\\\", \\\"{x:556,y:773,t:1527873208885};\\\", \\\"{x:555,y:772,t:1527873208901};\\\", \\\"{x:553,y:770,t:1527873208918};\\\", \\\"{x:553,y:769,t:1527873208934};\\\", \\\"{x:552,y:765,t:1527873208952};\\\", \\\"{x:552,y:763,t:1527873208967};\\\", \\\"{x:551,y:758,t:1527873208984};\\\", \\\"{x:551,y:755,t:1527873209001};\\\", \\\"{x:551,y:753,t:1527873209018};\\\", \\\"{x:551,y:752,t:1527873209034};\\\", \\\"{x:551,y:750,t:1527873209051};\\\", \\\"{x:551,y:749,t:1527873209068};\\\", \\\"{x:551,y:747,t:1527873209085};\\\", \\\"{x:551,y:746,t:1527873209101};\\\", \\\"{x:551,y:745,t:1527873209118};\\\", \\\"{x:549,y:743,t:1527873209134};\\\", \\\"{x:549,y:742,t:1527873209191};\\\", \\\"{x:548,y:742,t:1527873209207};\\\", \\\"{x:548,y:741,t:1527873209218};\\\", \\\"{x:548,y:739,t:1527873209235};\\\", \\\"{x:547,y:739,t:1527873209464};\\\", \\\"{x:549,y:737,t:1527873209471};\\\", \\\"{x:556,y:736,t:1527873209485};\\\", \\\"{x:597,y:736,t:1527873209505};\\\", \\\"{x:616,y:736,t:1527873209518};\\\", \\\"{x:689,y:736,t:1527873209535};\\\", \\\"{x:737,y:736,t:1527873209552};\\\", \\\"{x:767,y:736,t:1527873209568};\\\", \\\"{x:790,y:736,t:1527873209585};\\\", \\\"{x:809,y:736,t:1527873209602};\\\", \\\"{x:820,y:736,t:1527873209618};\\\", \\\"{x:827,y:736,t:1527873209636};\\\", \\\"{x:834,y:736,t:1527873209653};\\\", \\\"{x:839,y:736,t:1527873209668};\\\", \\\"{x:847,y:736,t:1527873209686};\\\", \\\"{x:873,y:736,t:1527873209704};\\\", \\\"{x:885,y:736,t:1527873209718};\\\", \\\"{x:934,y:743,t:1527873209736};\\\", \\\"{x:969,y:746,t:1527873209752};\\\", \\\"{x:1000,y:751,t:1527873209769};\\\", \\\"{x:1022,y:756,t:1527873209786};\\\", \\\"{x:1041,y:757,t:1527873209803};\\\", \\\"{x:1056,y:760,t:1527873209819};\\\", \\\"{x:1067,y:763,t:1527873209836};\\\", \\\"{x:1080,y:766,t:1527873209852};\\\", \\\"{x:1089,y:768,t:1527873209870};\\\", \\\"{x:1098,y:771,t:1527873209886};\\\", \\\"{x:1107,y:773,t:1527873209902};\\\", \\\"{x:1117,y:775,t:1527873209919};\\\", \\\"{x:1124,y:776,t:1527873209936};\\\", \\\"{x:1133,y:777,t:1527873209954};\\\", \\\"{x:1142,y:778,t:1527873209970};\\\", \\\"{x:1148,y:779,t:1527873209986};\\\", \\\"{x:1154,y:780,t:1527873210002};\\\", \\\"{x:1157,y:781,t:1527873210020};\\\", \\\"{x:1159,y:782,t:1527873210035};\\\", \\\"{x:1157,y:784,t:1527873230492};\\\", \\\"{x:1127,y:785,t:1527873230508};\\\", \\\"{x:1041,y:758,t:1527873230524};\\\", \\\"{x:941,y:709,t:1527873230540};\\\", \\\"{x:854,y:680,t:1527873230557};\\\", \\\"{x:803,y:668,t:1527873230574};\\\", \\\"{x:771,y:662,t:1527873230590};\\\", \\\"{x:717,y:654,t:1527873230606};\\\", \\\"{x:651,y:646,t:1527873230624};\\\", \\\"{x:595,y:638,t:1527873230640};\\\", \\\"{x:556,y:628,t:1527873230658};\\\", \\\"{x:534,y:619,t:1527873230673};\\\", \\\"{x:486,y:591,t:1527873230690};\\\", \\\"{x:448,y:569,t:1527873230706};\\\", \\\"{x:425,y:555,t:1527873230723};\\\", \\\"{x:421,y:551,t:1527873230740};\\\", \\\"{x:420,y:548,t:1527873230756};\\\", \\\"{x:420,y:547,t:1527873230774};\\\", \\\"{x:420,y:544,t:1527873230790};\\\", \\\"{x:419,y:538,t:1527873230807};\\\", \\\"{x:416,y:536,t:1527873230824};\\\", \\\"{x:414,y:535,t:1527873230840};\\\", \\\"{x:412,y:535,t:1527873230858};\\\", \\\"{x:411,y:536,t:1527873230874};\\\", \\\"{x:410,y:539,t:1527873230890};\\\", \\\"{x:409,y:543,t:1527873230906};\\\", \\\"{x:407,y:544,t:1527873230923};\\\", \\\"{x:407,y:545,t:1527873230946};\\\", \\\"{x:406,y:545,t:1527873230963};\\\", \\\"{x:403,y:545,t:1527873230974};\\\", \\\"{x:386,y:548,t:1527873230990};\\\", \\\"{x:360,y:550,t:1527873231008};\\\", \\\"{x:330,y:554,t:1527873231024};\\\", \\\"{x:297,y:554,t:1527873231040};\\\", \\\"{x:263,y:554,t:1527873231058};\\\", \\\"{x:211,y:546,t:1527873231074};\\\", \\\"{x:193,y:544,t:1527873231090};\\\", \\\"{x:186,y:542,t:1527873231108};\\\", \\\"{x:182,y:541,t:1527873231124};\\\", \\\"{x:181,y:541,t:1527873231140};\\\", \\\"{x:179,y:541,t:1527873231157};\\\", \\\"{x:177,y:541,t:1527873231174};\\\", \\\"{x:174,y:539,t:1527873231190};\\\", \\\"{x:172,y:537,t:1527873231207};\\\", \\\"{x:169,y:535,t:1527873231224};\\\", \\\"{x:167,y:533,t:1527873231240};\\\", \\\"{x:166,y:533,t:1527873231266};\\\", \\\"{x:166,y:532,t:1527873231274};\\\", \\\"{x:166,y:528,t:1527873231291};\\\", \\\"{x:165,y:524,t:1527873231308};\\\", \\\"{x:164,y:521,t:1527873231324};\\\", \\\"{x:163,y:518,t:1527873231341};\\\", \\\"{x:162,y:517,t:1527873231357};\\\", \\\"{x:161,y:515,t:1527873231386};\\\", \\\"{x:161,y:514,t:1527873231402};\\\", \\\"{x:161,y:512,t:1527873231411};\\\", \\\"{x:161,y:511,t:1527873231424};\\\", \\\"{x:161,y:507,t:1527873231440};\\\", \\\"{x:161,y:505,t:1527873231458};\\\", \\\"{x:163,y:510,t:1527873231634};\\\", \\\"{x:168,y:519,t:1527873231643};\\\", \\\"{x:173,y:526,t:1527873231658};\\\", \\\"{x:196,y:552,t:1527873231674};\\\", \\\"{x:212,y:565,t:1527873231691};\\\", \\\"{x:230,y:579,t:1527873231707};\\\", \\\"{x:250,y:597,t:1527873231724};\\\", \\\"{x:279,y:618,t:1527873231741};\\\", \\\"{x:308,y:637,t:1527873231758};\\\", \\\"{x:335,y:653,t:1527873231775};\\\", \\\"{x:356,y:663,t:1527873231791};\\\", \\\"{x:375,y:674,t:1527873231807};\\\", \\\"{x:388,y:683,t:1527873231824};\\\", \\\"{x:406,y:695,t:1527873231841};\\\", \\\"{x:423,y:704,t:1527873231858};\\\", \\\"{x:451,y:716,t:1527873231875};\\\", \\\"{x:473,y:727,t:1527873231891};\\\", \\\"{x:488,y:734,t:1527873231908};\\\", \\\"{x:493,y:739,t:1527873231924};\\\", \\\"{x:493,y:740,t:1527873231941};\\\", \\\"{x:494,y:740,t:1527873231978};\\\", \\\"{x:494,y:741,t:1527873231992};\\\", \\\"{x:495,y:746,t:1527873232009};\\\", \\\"{x:499,y:751,t:1527873232024};\\\", \\\"{x:500,y:751,t:1527873232042};\\\", \\\"{x:501,y:751,t:1527873232282};\\\", \\\"{x:501,y:750,t:1527873232298};\\\", \\\"{x:500,y:750,t:1527873232443};\\\", \\\"{x:498,y:750,t:1527873232459};\\\", \\\"{x:497,y:750,t:1527873232482};\\\" ] }, { \\\"rt\\\": 36784, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 14, \\\"time_elapsed\\\": 461579, \\\"internal_node_id\\\": \\\"0.0-6.0-4.0\\\", \\\"subject\\\": \\\"2OEC4\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"whiskey\\\", \\\"condition\\\": \\\"115\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"ends\\\", \\\"q\\\": 10, \\\"clicks\\\": 1, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XFull-YFull\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 1, \\\"answer\\\": [ \\\"X\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-Z -F \\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:497,y:747,t:1527873235499};\\\", \\\"{x:498,y:746,t:1527873235515};\\\", \\\"{x:500,y:746,t:1527873235530};\\\", \\\"{x:502,y:746,t:1527873235546};\\\", \\\"{x:504,y:746,t:1527873235564};\\\", \\\"{x:509,y:744,t:1527873235581};\\\", \\\"{x:514,y:744,t:1527873235597};\\\", \\\"{x:520,y:744,t:1527873235614};\\\", \\\"{x:525,y:743,t:1527873235630};\\\", \\\"{x:528,y:743,t:1527873235648};\\\", \\\"{x:529,y:743,t:1527873235664};\\\", \\\"{x:529,y:742,t:1527873235681};\\\", \\\"{x:530,y:740,t:1527873236636};\\\", \\\"{x:535,y:739,t:1527873236650};\\\", \\\"{x:551,y:734,t:1527873236666};\\\", \\\"{x:597,y:721,t:1527873236684};\\\", \\\"{x:674,y:699,t:1527873236699};\\\", \\\"{x:777,y:683,t:1527873236716};\\\", \\\"{x:829,y:675,t:1527873236728};\\\", \\\"{x:925,y:665,t:1527873236745};\\\", \\\"{x:1020,y:663,t:1527873236761};\\\", \\\"{x:1140,y:660,t:1527873236778};\\\", \\\"{x:1203,y:655,t:1527873236795};\\\", \\\"{x:1269,y:648,t:1527873236812};\\\", \\\"{x:1320,y:640,t:1527873236829};\\\", \\\"{x:1379,y:621,t:1527873236844};\\\", \\\"{x:1429,y:607,t:1527873236861};\\\", \\\"{x:1459,y:602,t:1527873236878};\\\", \\\"{x:1477,y:598,t:1527873236894};\\\", \\\"{x:1480,y:597,t:1527873236911};\\\", \\\"{x:1481,y:596,t:1527873236929};\\\", \\\"{x:1480,y:599,t:1527873237027};\\\", \\\"{x:1475,y:605,t:1527873237037};\\\", \\\"{x:1473,y:609,t:1527873237044};\\\", \\\"{x:1466,y:621,t:1527873237062};\\\", \\\"{x:1454,y:633,t:1527873237078};\\\", \\\"{x:1445,y:640,t:1527873237094};\\\", \\\"{x:1438,y:647,t:1527873237112};\\\", \\\"{x:1435,y:651,t:1527873237128};\\\", \\\"{x:1433,y:652,t:1527873237144};\\\", \\\"{x:1430,y:655,t:1527873237161};\\\", \\\"{x:1428,y:658,t:1527873237178};\\\", \\\"{x:1425,y:661,t:1527873237195};\\\", \\\"{x:1422,y:665,t:1527873237212};\\\", \\\"{x:1419,y:667,t:1527873237229};\\\", \\\"{x:1416,y:669,t:1527873237245};\\\", \\\"{x:1411,y:670,t:1527873237261};\\\", \\\"{x:1409,y:671,t:1527873237279};\\\", \\\"{x:1408,y:672,t:1527873237295};\\\", \\\"{x:1406,y:673,t:1527873237312};\\\", \\\"{x:1405,y:674,t:1527873237329};\\\", \\\"{x:1403,y:675,t:1527873237346};\\\", \\\"{x:1400,y:677,t:1527873237362};\\\", \\\"{x:1397,y:679,t:1527873237379};\\\", \\\"{x:1394,y:681,t:1527873237395};\\\", \\\"{x:1392,y:682,t:1527873237411};\\\", \\\"{x:1391,y:683,t:1527873237429};\\\", \\\"{x:1390,y:684,t:1527873237446};\\\", \\\"{x:1389,y:685,t:1527873237462};\\\", \\\"{x:1387,y:687,t:1527873237479};\\\", \\\"{x:1385,y:688,t:1527873237496};\\\", \\\"{x:1384,y:689,t:1527873237512};\\\", \\\"{x:1383,y:690,t:1527873237529};\\\", \\\"{x:1382,y:691,t:1527873237546};\\\", \\\"{x:1381,y:691,t:1527873237562};\\\", \\\"{x:1379,y:692,t:1527873237579};\\\", \\\"{x:1377,y:694,t:1527873237596};\\\", \\\"{x:1376,y:695,t:1527873237619};\\\", \\\"{x:1374,y:696,t:1527873237644};\\\", \\\"{x:1373,y:696,t:1527873237651};\\\", \\\"{x:1373,y:697,t:1527873237667};\\\", \\\"{x:1372,y:697,t:1527873237682};\\\", \\\"{x:1371,y:697,t:1527873237699};\\\", \\\"{x:1370,y:698,t:1527873237712};\\\", \\\"{x:1368,y:699,t:1527873237729};\\\", \\\"{x:1366,y:700,t:1527873237746};\\\", \\\"{x:1364,y:701,t:1527873237762};\\\", \\\"{x:1361,y:701,t:1527873237778};\\\", \\\"{x:1358,y:701,t:1527873238068};\\\", \\\"{x:1357,y:701,t:1527873238079};\\\", \\\"{x:1355,y:701,t:1527873238096};\\\", \\\"{x:1354,y:701,t:1527873238113};\\\", \\\"{x:1352,y:701,t:1527873238491};\\\", \\\"{x:1356,y:701,t:1527873240316};\\\", \\\"{x:1369,y:703,t:1527873240331};\\\", \\\"{x:1378,y:705,t:1527873240347};\\\", \\\"{x:1388,y:706,t:1527873240364};\\\", \\\"{x:1399,y:706,t:1527873240381};\\\", \\\"{x:1413,y:708,t:1527873240397};\\\", \\\"{x:1420,y:708,t:1527873240414};\\\", \\\"{x:1425,y:708,t:1527873240431};\\\", \\\"{x:1431,y:708,t:1527873240448};\\\", \\\"{x:1435,y:708,t:1527873240464};\\\", \\\"{x:1438,y:708,t:1527873240482};\\\", \\\"{x:1443,y:708,t:1527873240497};\\\", \\\"{x:1451,y:708,t:1527873240515};\\\", \\\"{x:1460,y:708,t:1527873240531};\\\", \\\"{x:1465,y:708,t:1527873240547};\\\", \\\"{x:1470,y:708,t:1527873240564};\\\", \\\"{x:1477,y:708,t:1527873240581};\\\", \\\"{x:1484,y:708,t:1527873240597};\\\", \\\"{x:1495,y:708,t:1527873240614};\\\", \\\"{x:1508,y:708,t:1527873240631};\\\", \\\"{x:1524,y:708,t:1527873240647};\\\", \\\"{x:1543,y:708,t:1527873240664};\\\", \\\"{x:1557,y:708,t:1527873240682};\\\", \\\"{x:1571,y:708,t:1527873240699};\\\", \\\"{x:1584,y:708,t:1527873240715};\\\", \\\"{x:1597,y:708,t:1527873240731};\\\", \\\"{x:1604,y:708,t:1527873240748};\\\", \\\"{x:1608,y:708,t:1527873240765};\\\", \\\"{x:1609,y:708,t:1527873240781};\\\", \\\"{x:1610,y:708,t:1527873240811};\\\", \\\"{x:1610,y:707,t:1527873240819};\\\", \\\"{x:1611,y:707,t:1527873240831};\\\", \\\"{x:1612,y:707,t:1527873240848};\\\", \\\"{x:1613,y:705,t:1527873240864};\\\", \\\"{x:1614,y:705,t:1527873240881};\\\", \\\"{x:1616,y:704,t:1527873240899};\\\", \\\"{x:1617,y:704,t:1527873240915};\\\", \\\"{x:1618,y:703,t:1527873240931};\\\", \\\"{x:1619,y:702,t:1527873240948};\\\", \\\"{x:1619,y:701,t:1527873241668};\\\", \\\"{x:1619,y:699,t:1527873241684};\\\", \\\"{x:1617,y:698,t:1527873241697};\\\", \\\"{x:1613,y:696,t:1527873241715};\\\", \\\"{x:1610,y:695,t:1527873241730};\\\", \\\"{x:1608,y:695,t:1527873241748};\\\", \\\"{x:1608,y:694,t:1527873241765};\\\", \\\"{x:1606,y:694,t:1527873244611};\\\", \\\"{x:1599,y:698,t:1527873244619};\\\", \\\"{x:1592,y:701,t:1527873244634};\\\", \\\"{x:1576,y:705,t:1527873244650};\\\", \\\"{x:1565,y:708,t:1527873244666};\\\", \\\"{x:1561,y:710,t:1527873244683};\\\", \\\"{x:1559,y:710,t:1527873244844};\\\", \\\"{x:1557,y:711,t:1527873244850};\\\", \\\"{x:1550,y:712,t:1527873244867};\\\", \\\"{x:1540,y:715,t:1527873244884};\\\", \\\"{x:1523,y:716,t:1527873244900};\\\", \\\"{x:1505,y:717,t:1527873244917};\\\", \\\"{x:1491,y:720,t:1527873244934};\\\", \\\"{x:1474,y:720,t:1527873244950};\\\", \\\"{x:1463,y:720,t:1527873244967};\\\", \\\"{x:1451,y:720,t:1527873244984};\\\", \\\"{x:1442,y:721,t:1527873245000};\\\", \\\"{x:1435,y:723,t:1527873245018};\\\", \\\"{x:1429,y:725,t:1527873245034};\\\", \\\"{x:1426,y:725,t:1527873245051};\\\", \\\"{x:1423,y:725,t:1527873245067};\\\", \\\"{x:1423,y:726,t:1527873245083};\\\", \\\"{x:1420,y:726,t:1527873245100};\\\", \\\"{x:1415,y:726,t:1527873245117};\\\", \\\"{x:1409,y:726,t:1527873245133};\\\", \\\"{x:1403,y:726,t:1527873245150};\\\", \\\"{x:1394,y:726,t:1527873245167};\\\", \\\"{x:1381,y:723,t:1527873245184};\\\", \\\"{x:1368,y:719,t:1527873245200};\\\", \\\"{x:1357,y:716,t:1527873245218};\\\", \\\"{x:1347,y:712,t:1527873245235};\\\", \\\"{x:1346,y:711,t:1527873245259};\\\", \\\"{x:1345,y:710,t:1527873245290};\\\", \\\"{x:1345,y:709,t:1527873245420};\\\", \\\"{x:1345,y:708,t:1527873245434};\\\", \\\"{x:1345,y:707,t:1527873245451};\\\", \\\"{x:1345,y:706,t:1527873245475};\\\", \\\"{x:1345,y:705,t:1527873245499};\\\", \\\"{x:1345,y:706,t:1527873246211};\\\", \\\"{x:1345,y:707,t:1527873246219};\\\", \\\"{x:1345,y:709,t:1527873246234};\\\", \\\"{x:1345,y:711,t:1527873246251};\\\", \\\"{x:1345,y:713,t:1527873246268};\\\", \\\"{x:1345,y:716,t:1527873246285};\\\", \\\"{x:1345,y:717,t:1527873246331};\\\", \\\"{x:1345,y:718,t:1527873246338};\\\", \\\"{x:1345,y:719,t:1527873246355};\\\", \\\"{x:1345,y:720,t:1527873246387};\\\", \\\"{x:1345,y:721,t:1527873246419};\\\", \\\"{x:1345,y:722,t:1527873246491};\\\", \\\"{x:1347,y:725,t:1527873246502};\\\", \\\"{x:1347,y:728,t:1527873246518};\\\", \\\"{x:1348,y:731,t:1527873246535};\\\", \\\"{x:1348,y:732,t:1527873246843};\\\", \\\"{x:1347,y:732,t:1527873246859};\\\", \\\"{x:1346,y:732,t:1527873246868};\\\", \\\"{x:1343,y:731,t:1527873246885};\\\", \\\"{x:1342,y:730,t:1527873246902};\\\", \\\"{x:1341,y:729,t:1527873246918};\\\", \\\"{x:1340,y:728,t:1527873246935};\\\", \\\"{x:1340,y:727,t:1527873247155};\\\", \\\"{x:1340,y:726,t:1527873247187};\\\", \\\"{x:1340,y:725,t:1527873247219};\\\", \\\"{x:1340,y:724,t:1527873247242};\\\", \\\"{x:1340,y:723,t:1527873247251};\\\", \\\"{x:1340,y:722,t:1527873247330};\\\", \\\"{x:1340,y:721,t:1527873247362};\\\", \\\"{x:1341,y:719,t:1527873247699};\\\", \\\"{x:1342,y:718,t:1527873247707};\\\", \\\"{x:1343,y:716,t:1527873247719};\\\", \\\"{x:1344,y:714,t:1527873247735};\\\", \\\"{x:1346,y:713,t:1527873247753};\\\", \\\"{x:1347,y:712,t:1527873247769};\\\", \\\"{x:1347,y:711,t:1527873247995};\\\", \\\"{x:1347,y:709,t:1527873248011};\\\", \\\"{x:1347,y:708,t:1527873248019};\\\", \\\"{x:1347,y:706,t:1527873248035};\\\", \\\"{x:1347,y:705,t:1527873248052};\\\", \\\"{x:1347,y:703,t:1527873248069};\\\", \\\"{x:1347,y:702,t:1527873248580};\\\", \\\"{x:1347,y:701,t:1527873249723};\\\", \\\"{x:1347,y:700,t:1527873249746};\\\", \\\"{x:1347,y:701,t:1527873259747};\\\", \\\"{x:1343,y:707,t:1527873259760};\\\", \\\"{x:1338,y:719,t:1527873259776};\\\", \\\"{x:1328,y:733,t:1527873259793};\\\", \\\"{x:1311,y:743,t:1527873259810};\\\", \\\"{x:1282,y:746,t:1527873259826};\\\", \\\"{x:1162,y:746,t:1527873259842};\\\", \\\"{x:1062,y:746,t:1527873259859};\\\", \\\"{x:966,y:739,t:1527873259876};\\\", \\\"{x:897,y:728,t:1527873259893};\\\", \\\"{x:867,y:725,t:1527873259909};\\\", \\\"{x:857,y:723,t:1527873259926};\\\", \\\"{x:856,y:721,t:1527873259942};\\\", \\\"{x:856,y:719,t:1527873259960};\\\", \\\"{x:858,y:718,t:1527873259976};\\\", \\\"{x:858,y:716,t:1527873259993};\\\", \\\"{x:860,y:713,t:1527873260010};\\\", \\\"{x:860,y:703,t:1527873260026};\\\", \\\"{x:852,y:693,t:1527873260043};\\\", \\\"{x:839,y:684,t:1527873260060};\\\", \\\"{x:824,y:674,t:1527873260077};\\\", \\\"{x:805,y:660,t:1527873260092};\\\", \\\"{x:791,y:655,t:1527873260110};\\\", \\\"{x:778,y:653,t:1527873260126};\\\", \\\"{x:766,y:650,t:1527873260143};\\\", \\\"{x:750,y:648,t:1527873260159};\\\", \\\"{x:722,y:642,t:1527873260177};\\\", \\\"{x:697,y:635,t:1527873260192};\\\", \\\"{x:677,y:632,t:1527873260210};\\\", \\\"{x:648,y:620,t:1527873260226};\\\", \\\"{x:629,y:610,t:1527873260243};\\\", \\\"{x:620,y:604,t:1527873260264};\\\", \\\"{x:615,y:599,t:1527873260282};\\\", \\\"{x:603,y:582,t:1527873260297};\\\", \\\"{x:600,y:579,t:1527873260314};\\\", \\\"{x:599,y:577,t:1527873260331};\\\", \\\"{x:597,y:572,t:1527873260348};\\\", \\\"{x:596,y:568,t:1527873260364};\\\", \\\"{x:596,y:565,t:1527873260381};\\\", \\\"{x:596,y:559,t:1527873260398};\\\", \\\"{x:596,y:558,t:1527873260474};\\\", \\\"{x:597,y:558,t:1527873260481};\\\", \\\"{x:599,y:558,t:1527873260497};\\\", \\\"{x:602,y:558,t:1527873260514};\\\", \\\"{x:603,y:558,t:1527873260531};\\\", \\\"{x:605,y:558,t:1527873260548};\\\", \\\"{x:607,y:558,t:1527873260569};\\\", \\\"{x:607,y:559,t:1527873260649};\\\", \\\"{x:609,y:560,t:1527873260665};\\\", \\\"{x:609,y:561,t:1527873260681};\\\", \\\"{x:610,y:563,t:1527873260698};\\\", \\\"{x:610,y:565,t:1527873260729};\\\", \\\"{x:610,y:566,t:1527873260762};\\\", \\\"{x:610,y:568,t:1527873260769};\\\", \\\"{x:610,y:569,t:1527873260786};\\\", \\\"{x:610,y:570,t:1527873260798};\\\", \\\"{x:610,y:571,t:1527873260815};\\\", \\\"{x:610,y:572,t:1527873260831};\\\", \\\"{x:610,y:572,t:1527873260907};\\\", \\\"{x:610,y:573,t:1527873262123};\\\", \\\"{x:610,y:575,t:1527873262135};\\\", \\\"{x:608,y:575,t:1527873262151};\\\", \\\"{x:607,y:574,t:1527873262168};\\\", \\\"{x:605,y:573,t:1527873262185};\\\", \\\"{x:604,y:573,t:1527873262201};\\\", \\\"{x:604,y:571,t:1527873262410};\\\", \\\"{x:604,y:570,t:1527873262419};\\\", \\\"{x:604,y:567,t:1527873262437};\\\", \\\"{x:604,y:566,t:1527873262452};\\\", \\\"{x:604,y:564,t:1527873262986};\\\", \\\"{x:604,y:561,t:1527873263004};\\\", \\\"{x:603,y:558,t:1527873263017};\\\", \\\"{x:603,y:557,t:1527873263033};\\\", \\\"{x:603,y:555,t:1527873263050};\\\", \\\"{x:602,y:555,t:1527873263066};\\\", \\\"{x:602,y:554,t:1527873263083};\\\", \\\"{x:601,y:552,t:1527873263354};\\\", \\\"{x:601,y:551,t:1527873263377};\\\", \\\"{x:601,y:550,t:1527873263385};\\\", \\\"{x:601,y:548,t:1527873263401};\\\", \\\"{x:600,y:547,t:1527873263482};\\\", \\\"{x:599,y:547,t:1527873263490};\\\", \\\"{x:599,y:546,t:1527873263500};\\\", \\\"{x:599,y:542,t:1527873263517};\\\", \\\"{x:599,y:541,t:1527873263554};\\\", \\\"{x:598,y:540,t:1527873263618};\\\", \\\"{x:598,y:539,t:1527873263642};\\\", \\\"{x:597,y:537,t:1527873264170};\\\", \\\"{x:597,y:536,t:1527873264185};\\\", \\\"{x:596,y:535,t:1527873265353};\\\", \\\"{x:595,y:534,t:1527873265369};\\\", \\\"{x:595,y:533,t:1527873266370};\\\", \\\"{x:595,y:535,t:1527873267937};\\\", \\\"{x:596,y:540,t:1527873267954};\\\", \\\"{x:600,y:547,t:1527873267971};\\\", \\\"{x:603,y:551,t:1527873267987};\\\", \\\"{x:608,y:556,t:1527873268005};\\\", \\\"{x:610,y:558,t:1527873268021};\\\", \\\"{x:611,y:558,t:1527873268037};\\\", \\\"{x:612,y:559,t:1527873268073};\\\", \\\"{x:613,y:559,t:1527873268098};\\\", \\\"{x:614,y:559,t:1527873268113};\\\", \\\"{x:615,y:559,t:1527873268137};\\\", \\\"{x:616,y:559,t:1527873268154};\\\", \\\"{x:617,y:559,t:1527873268185};\\\", \\\"{x:617,y:560,t:1527873268193};\\\", \\\"{x:618,y:561,t:1527873268204};\\\", \\\"{x:617,y:564,t:1527873269513};\\\", \\\"{x:609,y:571,t:1527873269522};\\\", \\\"{x:586,y:586,t:1527873269538};\\\", \\\"{x:569,y:602,t:1527873269555};\\\", \\\"{x:558,y:613,t:1527873269572};\\\", \\\"{x:548,y:627,t:1527873269588};\\\", \\\"{x:531,y:652,t:1527873269605};\\\", \\\"{x:522,y:664,t:1527873269622};\\\", \\\"{x:519,y:670,t:1527873269638};\\\", \\\"{x:519,y:671,t:1527873269655};\\\", \\\"{x:519,y:672,t:1527873269673};\\\", \\\"{x:519,y:673,t:1527873269688};\\\", \\\"{x:519,y:674,t:1527873269818};\\\", \\\"{x:520,y:674,t:1527873269825};\\\", \\\"{x:521,y:675,t:1527873269839};\\\", \\\"{x:522,y:681,t:1527873269855};\\\", \\\"{x:524,y:684,t:1527873269872};\\\", \\\"{x:525,y:693,t:1527873269889};\\\", \\\"{x:527,y:696,t:1527873269906};\\\", \\\"{x:527,y:702,t:1527873269922};\\\", \\\"{x:527,y:707,t:1527873269939};\\\", \\\"{x:527,y:710,t:1527873269956};\\\", \\\"{x:527,y:720,t:1527873269972};\\\", \\\"{x:527,y:727,t:1527873269990};\\\", \\\"{x:527,y:732,t:1527873270005};\\\", \\\"{x:527,y:734,t:1527873270023};\\\", \\\"{x:527,y:736,t:1527873270129};\\\", \\\"{x:527,y:737,t:1527873270138};\\\", \\\"{x:527,y:737,t:1527873270187};\\\", \\\"{x:527,y:736,t:1527873270594};\\\", \\\"{x:527,y:735,t:1527873270921};\\\", \\\"{x:527,y:733,t:1527873270945};\\\" ] }, { \\\"rt\\\": 11216, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 15, \\\"time_elapsed\\\": 474026, \\\"internal_node_id\\\": \\\"0.0-6.0-5.0\\\", \\\"subject\\\": \\\"2OEC4\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"whiskey\\\", \\\"condition\\\": \\\"115\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"starttime\\\", \\\"q\\\": 11, \\\"clicks\\\": 3, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XFull-YFull\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 1, \\\"answer\\\": [ \\\"F\\\", \\\"B\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"\\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:527,y:732,t:1527873271572};\\\", \\\"{x:527,y:731,t:1527873271594};\\\", \\\"{x:527,y:730,t:1527873271705};\\\", \\\"{x:526,y:729,t:1527873271729};\\\", \\\"{x:526,y:727,t:1527873271785};\\\", \\\"{x:526,y:726,t:1527873271817};\\\", \\\"{x:525,y:724,t:1527873271849};\\\", \\\"{x:525,y:723,t:1527873271856};\\\", \\\"{x:525,y:721,t:1527873271881};\\\", \\\"{x:524,y:721,t:1527873271890};\\\", \\\"{x:524,y:720,t:1527873271913};\\\", \\\"{x:523,y:718,t:1527873272027};\\\", \\\"{x:523,y:717,t:1527873272089};\\\", \\\"{x:523,y:716,t:1527873272097};\\\", \\\"{x:523,y:715,t:1527873272129};\\\", \\\"{x:523,y:714,t:1527873272161};\\\", \\\"{x:523,y:713,t:1527873272177};\\\", \\\"{x:523,y:712,t:1527873272190};\\\", \\\"{x:523,y:711,t:1527873272225};\\\", \\\"{x:522,y:710,t:1527873272240};\\\", \\\"{x:522,y:709,t:1527873272265};\\\", \\\"{x:522,y:707,t:1527873272305};\\\", \\\"{x:521,y:704,t:1527873272313};\\\", \\\"{x:520,y:702,t:1527873272553};\\\", \\\"{x:519,y:701,t:1527873272561};\\\", \\\"{x:518,y:700,t:1527873272573};\\\", \\\"{x:517,y:698,t:1527873272590};\\\", \\\"{x:515,y:697,t:1527873272607};\\\", \\\"{x:512,y:695,t:1527873272624};\\\", \\\"{x:505,y:690,t:1527873272640};\\\", \\\"{x:502,y:689,t:1527873272657};\\\", \\\"{x:502,y:688,t:1527873272673};\\\", \\\"{x:507,y:691,t:1527873272913};\\\", \\\"{x:511,y:693,t:1527873272923};\\\", \\\"{x:523,y:696,t:1527873272940};\\\", \\\"{x:540,y:698,t:1527873272957};\\\", \\\"{x:564,y:701,t:1527873272973};\\\", \\\"{x:588,y:703,t:1527873272990};\\\", \\\"{x:610,y:708,t:1527873273006};\\\", \\\"{x:620,y:709,t:1527873273023};\\\", \\\"{x:625,y:709,t:1527873273040};\\\", \\\"{x:626,y:709,t:1527873273057};\\\", \\\"{x:630,y:709,t:1527873273242};\\\", \\\"{x:632,y:708,t:1527873273257};\\\", \\\"{x:643,y:702,t:1527873273273};\\\", \\\"{x:649,y:701,t:1527873273290};\\\", \\\"{x:654,y:698,t:1527873273306};\\\", \\\"{x:661,y:697,t:1527873273323};\\\", \\\"{x:665,y:695,t:1527873273340};\\\", \\\"{x:669,y:695,t:1527873273356};\\\", \\\"{x:671,y:695,t:1527873273373};\\\", \\\"{x:673,y:695,t:1527873273391};\\\", \\\"{x:675,y:694,t:1527873273406};\\\", \\\"{x:675,y:688,t:1527873273423};\\\", \\\"{x:675,y:687,t:1527873273439};\\\", \\\"{x:674,y:688,t:1527873274034};\\\", \\\"{x:674,y:689,t:1527873274209};\\\", \\\"{x:673,y:689,t:1527873274257};\\\", \\\"{x:673,y:690,t:1527873274273};\\\", \\\"{x:673,y:691,t:1527873274289};\\\", \\\"{x:673,y:692,t:1527873274321};\\\", \\\"{x:673,y:693,t:1527873274337};\\\", \\\"{x:673,y:694,t:1527873274369};\\\", \\\"{x:673,y:695,t:1527873275145};\\\", \\\"{x:675,y:695,t:1527873275157};\\\", \\\"{x:680,y:695,t:1527873275173};\\\", \\\"{x:681,y:695,t:1527873275190};\\\", \\\"{x:680,y:695,t:1527873275473};\\\", \\\"{x:678,y:696,t:1527873275490};\\\", \\\"{x:677,y:696,t:1527873275513};\\\", \\\"{x:676,y:696,t:1527873275537};\\\", \\\"{x:673,y:696,t:1527873275545};\\\", \\\"{x:667,y:694,t:1527873275557};\\\", \\\"{x:645,y:682,t:1527873275572};\\\", \\\"{x:605,y:661,t:1527873275590};\\\", \\\"{x:558,y:639,t:1527873275606};\\\", \\\"{x:531,y:626,t:1527873275622};\\\", \\\"{x:525,y:623,t:1527873275639};\\\", \\\"{x:524,y:622,t:1527873275660};\\\", \\\"{x:524,y:621,t:1527873275745};\\\", \\\"{x:524,y:620,t:1527873275761};\\\", \\\"{x:524,y:619,t:1527873275776};\\\", \\\"{x:524,y:618,t:1527873275793};\\\", \\\"{x:525,y:617,t:1527873275811};\\\", \\\"{x:528,y:615,t:1527873275826};\\\", \\\"{x:531,y:614,t:1527873275843};\\\", \\\"{x:533,y:612,t:1527873275860};\\\", \\\"{x:537,y:610,t:1527873275877};\\\", \\\"{x:539,y:609,t:1527873275893};\\\", \\\"{x:542,y:605,t:1527873275910};\\\", \\\"{x:543,y:603,t:1527873275927};\\\", \\\"{x:546,y:601,t:1527873275943};\\\", \\\"{x:549,y:596,t:1527873275961};\\\", \\\"{x:555,y:589,t:1527873275977};\\\", \\\"{x:562,y:577,t:1527873275994};\\\", \\\"{x:569,y:566,t:1527873276010};\\\", \\\"{x:575,y:553,t:1527873276028};\\\", \\\"{x:579,y:542,t:1527873276043};\\\", \\\"{x:581,y:531,t:1527873276060};\\\", \\\"{x:583,y:525,t:1527873276078};\\\", \\\"{x:583,y:522,t:1527873276094};\\\", \\\"{x:583,y:521,t:1527873276111};\\\", \\\"{x:583,y:522,t:1527873276257};\\\", \\\"{x:584,y:523,t:1527873276281};\\\", \\\"{x:584,y:525,t:1527873276295};\\\", \\\"{x:584,y:529,t:1527873276311};\\\", \\\"{x:584,y:533,t:1527873276327};\\\", \\\"{x:583,y:537,t:1527873276343};\\\", \\\"{x:572,y:541,t:1527873276361};\\\", \\\"{x:535,y:544,t:1527873276376};\\\", \\\"{x:506,y:544,t:1527873276393};\\\", \\\"{x:484,y:544,t:1527873276411};\\\", \\\"{x:468,y:544,t:1527873276428};\\\", \\\"{x:458,y:545,t:1527873276444};\\\", \\\"{x:453,y:546,t:1527873276460};\\\", \\\"{x:449,y:546,t:1527873276477};\\\", \\\"{x:445,y:547,t:1527873276494};\\\", \\\"{x:435,y:549,t:1527873276511};\\\", \\\"{x:428,y:550,t:1527873276528};\\\", \\\"{x:420,y:551,t:1527873276544};\\\", \\\"{x:415,y:553,t:1527873276560};\\\", \\\"{x:411,y:553,t:1527873276577};\\\", \\\"{x:408,y:554,t:1527873276594};\\\", \\\"{x:407,y:555,t:1527873276610};\\\", \\\"{x:404,y:555,t:1527873276627};\\\", \\\"{x:398,y:556,t:1527873276645};\\\", \\\"{x:388,y:557,t:1527873276661};\\\", \\\"{x:379,y:559,t:1527873276677};\\\", \\\"{x:371,y:562,t:1527873276694};\\\", \\\"{x:363,y:563,t:1527873276711};\\\", \\\"{x:355,y:565,t:1527873276728};\\\", \\\"{x:343,y:567,t:1527873276745};\\\", \\\"{x:329,y:568,t:1527873276761};\\\", \\\"{x:307,y:572,t:1527873276777};\\\", \\\"{x:286,y:575,t:1527873276795};\\\", \\\"{x:273,y:578,t:1527873276810};\\\", \\\"{x:263,y:580,t:1527873276828};\\\", \\\"{x:254,y:581,t:1527873276845};\\\", \\\"{x:247,y:582,t:1527873276861};\\\", \\\"{x:239,y:583,t:1527873276877};\\\", \\\"{x:234,y:584,t:1527873276894};\\\", \\\"{x:231,y:585,t:1527873276912};\\\", \\\"{x:228,y:586,t:1527873276928};\\\", \\\"{x:226,y:586,t:1527873276944};\\\", \\\"{x:223,y:587,t:1527873276961};\\\", \\\"{x:222,y:588,t:1527873277018};\\\", \\\"{x:222,y:589,t:1527873277041};\\\", \\\"{x:221,y:589,t:1527873277049};\\\", \\\"{x:220,y:590,t:1527873277062};\\\", \\\"{x:220,y:591,t:1527873277077};\\\", \\\"{x:220,y:592,t:1527873277113};\\\", \\\"{x:220,y:593,t:1527873277137};\\\", \\\"{x:220,y:594,t:1527873277178};\\\", \\\"{x:220,y:595,t:1527873277209};\\\", \\\"{x:221,y:595,t:1527873277217};\\\", \\\"{x:225,y:595,t:1527873277228};\\\", \\\"{x:241,y:595,t:1527873277244};\\\", \\\"{x:261,y:595,t:1527873277262};\\\", \\\"{x:282,y:598,t:1527873277279};\\\", \\\"{x:300,y:600,t:1527873277295};\\\", \\\"{x:315,y:602,t:1527873277312};\\\", \\\"{x:328,y:604,t:1527873277328};\\\", \\\"{x:338,y:606,t:1527873277345};\\\", \\\"{x:346,y:608,t:1527873277362};\\\", \\\"{x:348,y:608,t:1527873277378};\\\", \\\"{x:349,y:608,t:1527873277394};\\\", \\\"{x:350,y:608,t:1527873277412};\\\", \\\"{x:352,y:608,t:1527873277429};\\\", \\\"{x:362,y:609,t:1527873277445};\\\", \\\"{x:378,y:612,t:1527873277462};\\\", \\\"{x:396,y:612,t:1527873277479};\\\", \\\"{x:417,y:612,t:1527873277495};\\\", \\\"{x:439,y:612,t:1527873277512};\\\", \\\"{x:463,y:612,t:1527873277529};\\\", \\\"{x:491,y:612,t:1527873277545};\\\", \\\"{x:536,y:612,t:1527873277562};\\\", \\\"{x:561,y:612,t:1527873277578};\\\", \\\"{x:581,y:610,t:1527873277595};\\\", \\\"{x:598,y:605,t:1527873277612};\\\", \\\"{x:607,y:600,t:1527873277629};\\\", \\\"{x:615,y:596,t:1527873277645};\\\", \\\"{x:625,y:590,t:1527873277662};\\\", \\\"{x:637,y:581,t:1527873277679};\\\", \\\"{x:652,y:571,t:1527873277696};\\\", \\\"{x:668,y:565,t:1527873277712};\\\", \\\"{x:685,y:558,t:1527873277729};\\\", \\\"{x:705,y:546,t:1527873277745};\\\", \\\"{x:713,y:541,t:1527873277762};\\\", \\\"{x:720,y:535,t:1527873277779};\\\", \\\"{x:725,y:531,t:1527873277796};\\\", \\\"{x:730,y:527,t:1527873277812};\\\", \\\"{x:739,y:522,t:1527873277829};\\\", \\\"{x:747,y:519,t:1527873277845};\\\", \\\"{x:751,y:519,t:1527873277862};\\\", \\\"{x:752,y:519,t:1527873277878};\\\", \\\"{x:754,y:518,t:1527873277895};\\\", \\\"{x:759,y:517,t:1527873277914};\\\", \\\"{x:764,y:515,t:1527873277929};\\\", \\\"{x:788,y:506,t:1527873277945};\\\", \\\"{x:800,y:504,t:1527873277962};\\\", \\\"{x:809,y:501,t:1527873277978};\\\", \\\"{x:816,y:501,t:1527873277995};\\\", \\\"{x:818,y:499,t:1527873278012};\\\", \\\"{x:819,y:499,t:1527873278028};\\\", \\\"{x:820,y:498,t:1527873278045};\\\", \\\"{x:820,y:497,t:1527873278073};\\\", \\\"{x:821,y:496,t:1527873278097};\\\", \\\"{x:821,y:495,t:1527873278153};\\\", \\\"{x:822,y:495,t:1527873278449};\\\", \\\"{x:821,y:497,t:1527873278473};\\\", \\\"{x:820,y:498,t:1527873278480};\\\", \\\"{x:818,y:499,t:1527873278495};\\\", \\\"{x:809,y:502,t:1527873278513};\\\", \\\"{x:794,y:507,t:1527873278528};\\\", \\\"{x:768,y:512,t:1527873278545};\\\", \\\"{x:753,y:513,t:1527873278562};\\\", \\\"{x:739,y:513,t:1527873278579};\\\", \\\"{x:729,y:513,t:1527873278595};\\\", \\\"{x:725,y:514,t:1527873278612};\\\", \\\"{x:722,y:514,t:1527873278629};\\\", \\\"{x:722,y:515,t:1527873278646};\\\", \\\"{x:721,y:515,t:1527873278662};\\\", \\\"{x:719,y:517,t:1527873278680};\\\", \\\"{x:715,y:519,t:1527873278696};\\\", \\\"{x:709,y:521,t:1527873278713};\\\", \\\"{x:703,y:523,t:1527873278729};\\\", \\\"{x:702,y:524,t:1527873278745};\\\", \\\"{x:701,y:525,t:1527873278763};\\\", \\\"{x:703,y:526,t:1527873278779};\\\", \\\"{x:707,y:526,t:1527873278796};\\\", \\\"{x:714,y:526,t:1527873278813};\\\", \\\"{x:724,y:524,t:1527873278830};\\\", \\\"{x:738,y:522,t:1527873278845};\\\", \\\"{x:753,y:520,t:1527873278862};\\\", \\\"{x:766,y:519,t:1527873278879};\\\", \\\"{x:792,y:519,t:1527873278896};\\\", \\\"{x:802,y:519,t:1527873278913};\\\", \\\"{x:820,y:519,t:1527873278930};\\\", \\\"{x:827,y:519,t:1527873278946};\\\", \\\"{x:834,y:519,t:1527873278963};\\\", \\\"{x:841,y:517,t:1527873278979};\\\", \\\"{x:849,y:517,t:1527873278996};\\\", \\\"{x:858,y:516,t:1527873279012};\\\", \\\"{x:867,y:516,t:1527873279029};\\\", \\\"{x:871,y:515,t:1527873279046};\\\", \\\"{x:873,y:515,t:1527873279063};\\\", \\\"{x:874,y:514,t:1527873279080};\\\", \\\"{x:874,y:513,t:1527873279137};\\\", \\\"{x:874,y:512,t:1527873279146};\\\", \\\"{x:873,y:509,t:1527873279163};\\\", \\\"{x:865,y:505,t:1527873279180};\\\", \\\"{x:857,y:502,t:1527873279197};\\\", \\\"{x:847,y:500,t:1527873279213};\\\", \\\"{x:837,y:498,t:1527873279230};\\\", \\\"{x:833,y:498,t:1527873279247};\\\", \\\"{x:830,y:498,t:1527873279262};\\\", \\\"{x:827,y:497,t:1527873279279};\\\", \\\"{x:824,y:497,t:1527873279296};\\\", \\\"{x:823,y:497,t:1527873279312};\\\", \\\"{x:824,y:497,t:1527873279649};\\\", \\\"{x:825,y:497,t:1527873279673};\\\", \\\"{x:826,y:498,t:1527873279681};\\\", \\\"{x:827,y:499,t:1527873279721};\\\", \\\"{x:828,y:499,t:1527873279785};\\\", \\\"{x:830,y:500,t:1527873279797};\\\", \\\"{x:830,y:501,t:1527873279813};\\\", \\\"{x:832,y:501,t:1527873279830};\\\", \\\"{x:835,y:502,t:1527873279846};\\\", \\\"{x:836,y:502,t:1527873279873};\\\", \\\"{x:836,y:503,t:1527873280161};\\\", \\\"{x:837,y:504,t:1527873280168};\\\", \\\"{x:837,y:505,t:1527873280217};\\\", \\\"{x:837,y:506,t:1527873280230};\\\", \\\"{x:837,y:507,t:1527873280247};\\\", \\\"{x:837,y:510,t:1527873280263};\\\", \\\"{x:837,y:516,t:1527873280281};\\\", \\\"{x:837,y:517,t:1527873280297};\\\", \\\"{x:834,y:525,t:1527873280314};\\\", \\\"{x:828,y:530,t:1527873280331};\\\", \\\"{x:819,y:534,t:1527873280348};\\\", \\\"{x:806,y:535,t:1527873280363};\\\", \\\"{x:785,y:536,t:1527873280380};\\\", \\\"{x:754,y:536,t:1527873280398};\\\", \\\"{x:717,y:536,t:1527873280413};\\\", \\\"{x:678,y:536,t:1527873280430};\\\", \\\"{x:652,y:536,t:1527873280448};\\\", \\\"{x:641,y:536,t:1527873280464};\\\", \\\"{x:628,y:536,t:1527873280480};\\\", \\\"{x:617,y:536,t:1527873280498};\\\", \\\"{x:602,y:536,t:1527873280514};\\\", \\\"{x:583,y:536,t:1527873280531};\\\", \\\"{x:558,y:536,t:1527873280547};\\\", \\\"{x:532,y:531,t:1527873280564};\\\", \\\"{x:505,y:528,t:1527873280580};\\\", \\\"{x:484,y:525,t:1527873280598};\\\", \\\"{x:466,y:525,t:1527873280614};\\\", \\\"{x:451,y:525,t:1527873280631};\\\", \\\"{x:433,y:525,t:1527873280647};\\\", \\\"{x:421,y:525,t:1527873280665};\\\", \\\"{x:406,y:525,t:1527873280680};\\\", \\\"{x:389,y:525,t:1527873280698};\\\", \\\"{x:375,y:525,t:1527873280714};\\\", \\\"{x:360,y:525,t:1527873280730};\\\", \\\"{x:343,y:525,t:1527873280747};\\\", \\\"{x:322,y:525,t:1527873280765};\\\", \\\"{x:306,y:525,t:1527873280780};\\\", \\\"{x:293,y:525,t:1527873280798};\\\", \\\"{x:290,y:525,t:1527873280814};\\\", \\\"{x:289,y:525,t:1527873280830};\\\", \\\"{x:287,y:525,t:1527873280848};\\\", \\\"{x:281,y:525,t:1527873280864};\\\", \\\"{x:272,y:525,t:1527873280881};\\\", \\\"{x:252,y:525,t:1527873280898};\\\", \\\"{x:238,y:522,t:1527873280915};\\\", \\\"{x:226,y:522,t:1527873280931};\\\", \\\"{x:213,y:522,t:1527873280948};\\\", \\\"{x:191,y:522,t:1527873280965};\\\", \\\"{x:164,y:522,t:1527873280981};\\\", \\\"{x:126,y:522,t:1527873280998};\\\", \\\"{x:108,y:522,t:1527873281014};\\\", \\\"{x:102,y:524,t:1527873281031};\\\", \\\"{x:101,y:525,t:1527873281048};\\\", \\\"{x:101,y:526,t:1527873281073};\\\", \\\"{x:102,y:527,t:1527873281089};\\\", \\\"{x:103,y:528,t:1527873281105};\\\", \\\"{x:105,y:530,t:1527873281121};\\\", \\\"{x:106,y:530,t:1527873281136};\\\", \\\"{x:107,y:530,t:1527873281153};\\\", \\\"{x:109,y:531,t:1527873281164};\\\", \\\"{x:111,y:532,t:1527873281181};\\\", \\\"{x:112,y:533,t:1527873281198};\\\", \\\"{x:117,y:534,t:1527873281214};\\\", \\\"{x:119,y:536,t:1527873281231};\\\", \\\"{x:125,y:537,t:1527873281248};\\\", \\\"{x:128,y:539,t:1527873281265};\\\", \\\"{x:130,y:540,t:1527873281282};\\\", \\\"{x:131,y:540,t:1527873281305};\\\", \\\"{x:132,y:540,t:1527873281314};\\\", \\\"{x:135,y:541,t:1527873281331};\\\", \\\"{x:137,y:541,t:1527873281348};\\\", \\\"{x:138,y:541,t:1527873281365};\\\", \\\"{x:140,y:541,t:1527873281381};\\\", \\\"{x:141,y:541,t:1527873281399};\\\", \\\"{x:143,y:541,t:1527873281415};\\\", \\\"{x:145,y:541,t:1527873281432};\\\", \\\"{x:147,y:541,t:1527873281448};\\\", \\\"{x:148,y:541,t:1527873281513};\\\", \\\"{x:149,y:541,t:1527873281537};\\\", \\\"{x:151,y:541,t:1527873281785};\\\", \\\"{x:152,y:542,t:1527873281798};\\\", \\\"{x:153,y:543,t:1527873281816};\\\", \\\"{x:154,y:543,t:1527873281848};\\\", \\\"{x:159,y:546,t:1527873281865};\\\", \\\"{x:174,y:553,t:1527873281882};\\\", \\\"{x:187,y:558,t:1527873281899};\\\", \\\"{x:194,y:562,t:1527873281916};\\\", \\\"{x:202,y:564,t:1527873281932};\\\", \\\"{x:211,y:570,t:1527873281949};\\\", \\\"{x:220,y:577,t:1527873281966};\\\", \\\"{x:239,y:588,t:1527873281981};\\\", \\\"{x:263,y:599,t:1527873281999};\\\", \\\"{x:291,y:612,t:1527873282016};\\\", \\\"{x:311,y:620,t:1527873282032};\\\", \\\"{x:341,y:634,t:1527873282049};\\\", \\\"{x:354,y:642,t:1527873282066};\\\", \\\"{x:364,y:649,t:1527873282081};\\\", \\\"{x:371,y:654,t:1527873282098};\\\", \\\"{x:374,y:656,t:1527873282116};\\\", \\\"{x:379,y:660,t:1527873282132};\\\", \\\"{x:386,y:667,t:1527873282149};\\\", \\\"{x:396,y:676,t:1527873282166};\\\", \\\"{x:403,y:684,t:1527873282181};\\\", \\\"{x:410,y:694,t:1527873282199};\\\", \\\"{x:412,y:697,t:1527873282216};\\\", \\\"{x:416,y:701,t:1527873282232};\\\", \\\"{x:417,y:702,t:1527873282248};\\\", \\\"{x:418,y:702,t:1527873282265};\\\", \\\"{x:420,y:705,t:1527873282282};\\\", \\\"{x:426,y:712,t:1527873282298};\\\", \\\"{x:430,y:718,t:1527873282315};\\\", \\\"{x:435,y:721,t:1527873282333};\\\", \\\"{x:438,y:723,t:1527873282348};\\\", \\\"{x:441,y:725,t:1527873282366};\\\", \\\"{x:443,y:726,t:1527873282383};\\\", \\\"{x:444,y:726,t:1527873282399};\\\", \\\"{x:445,y:726,t:1527873282417};\\\", \\\"{x:446,y:726,t:1527873282432};\\\", \\\"{x:448,y:728,t:1527873282448};\\\", \\\"{x:450,y:728,t:1527873282465};\\\", \\\"{x:453,y:729,t:1527873282483};\\\", \\\"{x:454,y:730,t:1527873283537};\\\", \\\"{x:454,y:732,t:1527873283550};\\\", \\\"{x:451,y:733,t:1527873283567};\\\", \\\"{x:446,y:736,t:1527873283584};\\\", \\\"{x:440,y:739,t:1527873283599};\\\", \\\"{x:428,y:744,t:1527873283616};\\\", \\\"{x:419,y:748,t:1527873283634};\\\", \\\"{x:415,y:749,t:1527873283649};\\\", \\\"{x:411,y:752,t:1527873283667};\\\", \\\"{x:405,y:753,t:1527873283683};\\\", \\\"{x:404,y:753,t:1527873283699};\\\", \\\"{x:403,y:759,t:1527873283753};\\\", \\\"{x:402,y:774,t:1527873283767};\\\", \\\"{x:390,y:814,t:1527873283815};\\\", \\\"{x:390,y:821,t:1527873283817};\\\", \\\"{x:392,y:827,t:1527873283834};\\\", \\\"{x:410,y:831,t:1527873283849};\\\", \\\"{x:436,y:831,t:1527873283866};\\\", \\\"{x:462,y:824,t:1527873283883};\\\", \\\"{x:463,y:823,t:1527873283901};\\\" ] }, { \\\"rt\\\": 10942, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 16, \\\"time_elapsed\\\": 486207, \\\"internal_node_id\\\": \\\"0.0-6.0-6.0\\\", \\\"subject\\\": \\\"2OEC4\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"whiskey\\\", \\\"condition\\\": \\\"115\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"starts\\\", \\\"q\\\": 12, \\\"clicks\\\": 1, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XFull-YFull\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 1, \\\"answer\\\": [ \\\"B\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"\\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:464,y:823,t:1527873284297};\\\", \\\"{x:465,y:822,t:1527873284304};\\\", \\\"{x:466,y:821,t:1527873284337};\\\", \\\"{x:466,y:819,t:1527873284488};\\\", \\\"{x:466,y:818,t:1527873284501};\\\", \\\"{x:467,y:818,t:1527873284517};\\\", \\\"{x:468,y:811,t:1527873284533};\\\", \\\"{x:469,y:810,t:1527873284550};\\\", \\\"{x:469,y:806,t:1527873284785};\\\", \\\"{x:469,y:800,t:1527873284800};\\\", \\\"{x:469,y:794,t:1527873284818};\\\", \\\"{x:471,y:786,t:1527873284834};\\\", \\\"{x:473,y:780,t:1527873284850};\\\", \\\"{x:475,y:776,t:1527873284867};\\\", \\\"{x:476,y:773,t:1527873284884};\\\", \\\"{x:477,y:772,t:1527873284901};\\\", \\\"{x:478,y:771,t:1527873284918};\\\", \\\"{x:478,y:770,t:1527873284935};\\\", \\\"{x:480,y:769,t:1527873284950};\\\", \\\"{x:481,y:769,t:1527873284967};\\\", \\\"{x:485,y:769,t:1527873284985};\\\", \\\"{x:490,y:769,t:1527873285000};\\\", \\\"{x:498,y:767,t:1527873285017};\\\", \\\"{x:514,y:759,t:1527873285034};\\\", \\\"{x:516,y:759,t:1527873285050};\\\", \\\"{x:518,y:759,t:1527873285768};\\\", \\\"{x:518,y:760,t:1527873285864};\\\", \\\"{x:518,y:761,t:1527873287073};\\\", \\\"{x:516,y:761,t:1527873287553};\\\", \\\"{x:515,y:762,t:1527873287665};\\\", \\\"{x:514,y:763,t:1527873287672};\\\", \\\"{x:513,y:763,t:1527873287686};\\\", \\\"{x:512,y:764,t:1527873287704};\\\", \\\"{x:510,y:764,t:1527873287904};\\\", \\\"{x:509,y:764,t:1527873288273};\\\", \\\"{x:508,y:766,t:1527873288286};\\\", \\\"{x:506,y:769,t:1527873288304};\\\", \\\"{x:506,y:771,t:1527873288325};\\\", \\\"{x:506,y:772,t:1527873288341};\\\", \\\"{x:506,y:773,t:1527873289181};\\\", \\\"{x:506,y:774,t:1527873289254};\\\", \\\"{x:507,y:774,t:1527873289526};\\\", \\\"{x:508,y:772,t:1527873289543};\\\", \\\"{x:509,y:771,t:1527873289629};\\\", \\\"{x:509,y:770,t:1527873289677};\\\", \\\"{x:509,y:769,t:1527873289692};\\\", \\\"{x:510,y:767,t:1527873289717};\\\", \\\"{x:511,y:766,t:1527873289733};\\\", \\\"{x:511,y:765,t:1527873289749};\\\", \\\"{x:512,y:764,t:1527873289759};\\\", \\\"{x:513,y:762,t:1527873289775};\\\", \\\"{x:514,y:760,t:1527873289821};\\\", \\\"{x:515,y:760,t:1527873289885};\\\", \\\"{x:515,y:759,t:1527873289893};\\\", \\\"{x:516,y:759,t:1527873289909};\\\", \\\"{x:518,y:757,t:1527873289926};\\\", \\\"{x:519,y:756,t:1527873289943};\\\", \\\"{x:521,y:755,t:1527873289959};\\\", \\\"{x:522,y:755,t:1527873289975};\\\", \\\"{x:524,y:755,t:1527873290197};\\\", \\\"{x:524,y:754,t:1527873290694};\\\", \\\"{x:524,y:753,t:1527873290710};\\\", \\\"{x:524,y:749,t:1527873290726};\\\", \\\"{x:524,y:736,t:1527873290743};\\\", \\\"{x:526,y:714,t:1527873290761};\\\", \\\"{x:537,y:681,t:1527873290778};\\\", \\\"{x:554,y:649,t:1527873290794};\\\", \\\"{x:570,y:624,t:1527873290811};\\\", \\\"{x:581,y:607,t:1527873290828};\\\", \\\"{x:586,y:599,t:1527873290844};\\\", \\\"{x:587,y:596,t:1527873290860};\\\", \\\"{x:588,y:595,t:1527873290877};\\\", \\\"{x:589,y:595,t:1527873290957};\\\", \\\"{x:590,y:595,t:1527873290965};\\\", \\\"{x:591,y:595,t:1527873290981};\\\", \\\"{x:592,y:595,t:1527873290994};\\\", \\\"{x:594,y:595,t:1527873291010};\\\", \\\"{x:597,y:595,t:1527873291027};\\\", \\\"{x:598,y:594,t:1527873291044};\\\", \\\"{x:600,y:593,t:1527873291060};\\\", \\\"{x:604,y:591,t:1527873291077};\\\", \\\"{x:605,y:589,t:1527873291093};\\\", \\\"{x:607,y:586,t:1527873291111};\\\", \\\"{x:609,y:583,t:1527873291127};\\\", \\\"{x:610,y:577,t:1527873291143};\\\", \\\"{x:611,y:575,t:1527873291161};\\\", \\\"{x:612,y:574,t:1527873291178};\\\", \\\"{x:613,y:570,t:1527873291193};\\\", \\\"{x:613,y:568,t:1527873291211};\\\", \\\"{x:613,y:566,t:1527873291227};\\\", \\\"{x:613,y:563,t:1527873291245};\\\", \\\"{x:613,y:562,t:1527873291261};\\\", \\\"{x:613,y:561,t:1527873291278};\\\", \\\"{x:613,y:560,t:1527873291294};\\\", \\\"{x:613,y:559,t:1527873291310};\\\", \\\"{x:613,y:558,t:1527873291333};\\\", \\\"{x:614,y:557,t:1527873291344};\\\", \\\"{x:615,y:552,t:1527873291361};\\\", \\\"{x:617,y:550,t:1527873291378};\\\", \\\"{x:619,y:549,t:1527873291394};\\\", \\\"{x:621,y:547,t:1527873291411};\\\", \\\"{x:627,y:545,t:1527873291428};\\\", \\\"{x:633,y:540,t:1527873291443};\\\", \\\"{x:640,y:536,t:1527873291461};\\\", \\\"{x:652,y:534,t:1527873291478};\\\", \\\"{x:669,y:528,t:1527873291493};\\\", \\\"{x:680,y:526,t:1527873291511};\\\", \\\"{x:693,y:526,t:1527873291528};\\\", \\\"{x:705,y:526,t:1527873291544};\\\", \\\"{x:713,y:526,t:1527873291562};\\\", \\\"{x:720,y:526,t:1527873291579};\\\", \\\"{x:726,y:526,t:1527873291595};\\\", \\\"{x:730,y:526,t:1527873291611};\\\", \\\"{x:733,y:526,t:1527873291627};\\\", \\\"{x:735,y:526,t:1527873291645};\\\", \\\"{x:737,y:526,t:1527873291662};\\\", \\\"{x:735,y:526,t:1527873291774};\\\", \\\"{x:730,y:526,t:1527873291781};\\\", \\\"{x:722,y:526,t:1527873291795};\\\", \\\"{x:702,y:526,t:1527873291812};\\\", \\\"{x:677,y:526,t:1527873291828};\\\", \\\"{x:652,y:526,t:1527873291844};\\\", \\\"{x:623,y:524,t:1527873291862};\\\", \\\"{x:617,y:523,t:1527873291877};\\\", \\\"{x:611,y:521,t:1527873291894};\\\", \\\"{x:610,y:521,t:1527873291911};\\\", \\\"{x:609,y:521,t:1527873291927};\\\", \\\"{x:608,y:521,t:1527873291966};\\\", \\\"{x:606,y:521,t:1527873291981};\\\", \\\"{x:603,y:521,t:1527873291995};\\\", \\\"{x:600,y:522,t:1527873292012};\\\", \\\"{x:592,y:522,t:1527873292029};\\\", \\\"{x:587,y:523,t:1527873292045};\\\", \\\"{x:576,y:525,t:1527873292062};\\\", \\\"{x:571,y:526,t:1527873292079};\\\", \\\"{x:560,y:527,t:1527873292095};\\\", \\\"{x:551,y:527,t:1527873292112};\\\", \\\"{x:541,y:527,t:1527873292128};\\\", \\\"{x:527,y:527,t:1527873292145};\\\", \\\"{x:511,y:527,t:1527873292162};\\\", \\\"{x:494,y:527,t:1527873292178};\\\", \\\"{x:479,y:527,t:1527873292194};\\\", \\\"{x:465,y:527,t:1527873292211};\\\", \\\"{x:455,y:527,t:1527873292229};\\\", \\\"{x:445,y:529,t:1527873292245};\\\", \\\"{x:436,y:530,t:1527873292261};\\\", \\\"{x:431,y:531,t:1527873292279};\\\", \\\"{x:428,y:533,t:1527873292295};\\\", \\\"{x:428,y:534,t:1527873292312};\\\", \\\"{x:428,y:535,t:1527873292333};\\\", \\\"{x:427,y:536,t:1527873292346};\\\", \\\"{x:427,y:538,t:1527873292366};\\\", \\\"{x:425,y:540,t:1527873292378};\\\", \\\"{x:424,y:541,t:1527873292398};\\\", \\\"{x:424,y:542,t:1527873292412};\\\", \\\"{x:423,y:543,t:1527873292430};\\\", \\\"{x:422,y:543,t:1527873292454};\\\", \\\"{x:422,y:544,t:1527873292462};\\\", \\\"{x:421,y:544,t:1527873292479};\\\", \\\"{x:418,y:545,t:1527873292496};\\\", \\\"{x:414,y:546,t:1527873292511};\\\", \\\"{x:407,y:547,t:1527873292529};\\\", \\\"{x:403,y:547,t:1527873292546};\\\", \\\"{x:396,y:548,t:1527873292562};\\\", \\\"{x:386,y:550,t:1527873292579};\\\", \\\"{x:375,y:551,t:1527873292595};\\\", \\\"{x:362,y:552,t:1527873292612};\\\", \\\"{x:348,y:552,t:1527873292628};\\\", \\\"{x:324,y:552,t:1527873292645};\\\", \\\"{x:299,y:552,t:1527873292662};\\\", \\\"{x:273,y:547,t:1527873292679};\\\", \\\"{x:247,y:541,t:1527873292696};\\\", \\\"{x:224,y:537,t:1527873292712};\\\", \\\"{x:207,y:532,t:1527873292728};\\\", \\\"{x:206,y:532,t:1527873292746};\\\", \\\"{x:204,y:532,t:1527873292773};\\\", \\\"{x:203,y:532,t:1527873292781};\\\", \\\"{x:201,y:532,t:1527873292795};\\\", \\\"{x:195,y:532,t:1527873292811};\\\", \\\"{x:188,y:532,t:1527873292829};\\\", \\\"{x:183,y:533,t:1527873292845};\\\", \\\"{x:181,y:533,t:1527873292862};\\\", \\\"{x:179,y:533,t:1527873292909};\\\", \\\"{x:178,y:533,t:1527873292916};\\\", \\\"{x:177,y:533,t:1527873292929};\\\", \\\"{x:173,y:534,t:1527873292945};\\\", \\\"{x:172,y:535,t:1527873292962};\\\", \\\"{x:170,y:536,t:1527873293269};\\\", \\\"{x:169,y:536,t:1527873293279};\\\", \\\"{x:168,y:536,t:1527873293295};\\\", \\\"{x:167,y:536,t:1527873293313};\\\", \\\"{x:166,y:537,t:1527873293333};\\\", \\\"{x:166,y:538,t:1527873293349};\\\", \\\"{x:165,y:538,t:1527873293365};\\\", \\\"{x:165,y:539,t:1527873293389};\\\", \\\"{x:165,y:541,t:1527873293405};\\\", \\\"{x:165,y:543,t:1527873293413};\\\", \\\"{x:169,y:548,t:1527873293429};\\\", \\\"{x:181,y:556,t:1527873293446};\\\", \\\"{x:204,y:568,t:1527873293463};\\\", \\\"{x:239,y:588,t:1527873293480};\\\", \\\"{x:281,y:608,t:1527873293497};\\\", \\\"{x:323,y:636,t:1527873293513};\\\", \\\"{x:354,y:656,t:1527873293530};\\\", \\\"{x:385,y:679,t:1527873293546};\\\", \\\"{x:407,y:694,t:1527873293563};\\\", \\\"{x:423,y:708,t:1527873293580};\\\", \\\"{x:435,y:720,t:1527873293596};\\\", \\\"{x:444,y:729,t:1527873293613};\\\", \\\"{x:454,y:738,t:1527873293629};\\\", \\\"{x:458,y:742,t:1527873293645};\\\", \\\"{x:463,y:744,t:1527873293662};\\\", \\\"{x:467,y:746,t:1527873293679};\\\", \\\"{x:472,y:749,t:1527873293696};\\\", \\\"{x:478,y:754,t:1527873293712};\\\", \\\"{x:483,y:757,t:1527873293730};\\\", \\\"{x:489,y:762,t:1527873293747};\\\", \\\"{x:496,y:764,t:1527873293762};\\\", \\\"{x:502,y:768,t:1527873293780};\\\", \\\"{x:509,y:770,t:1527873293796};\\\", \\\"{x:512,y:772,t:1527873293812};\\\", \\\"{x:515,y:774,t:1527873293830};\\\", \\\"{x:517,y:774,t:1527873293847};\\\", \\\"{x:519,y:774,t:1527873293863};\\\", \\\"{x:520,y:775,t:1527873293879};\\\", \\\"{x:522,y:775,t:1527873293901};\\\", \\\"{x:523,y:776,t:1527873294005};\\\", \\\"{x:525,y:776,t:1527873294133};\\\", \\\"{x:525,y:775,t:1527873294190};\\\", \\\"{x:525,y:774,t:1527873294214};\\\", \\\"{x:525,y:770,t:1527873294229};\\\", \\\"{x:525,y:768,t:1527873294247};\\\", \\\"{x:525,y:766,t:1527873294264};\\\", \\\"{x:525,y:765,t:1527873294279};\\\", \\\"{x:524,y:764,t:1527873294501};\\\", \\\"{x:523,y:764,t:1527873294549};\\\", \\\"{x:522,y:763,t:1527873294564};\\\", \\\"{x:522,y:761,t:1527873294581};\\\", \\\"{x:521,y:759,t:1527873294597};\\\", \\\"{x:519,y:750,t:1527873294613};\\\", \\\"{x:518,y:742,t:1527873294630};\\\", \\\"{x:518,y:736,t:1527873294646};\\\", \\\"{x:518,y:734,t:1527873294664};\\\", \\\"{x:518,y:733,t:1527873294681};\\\", \\\"{x:519,y:733,t:1527873295165};\\\", \\\"{x:521,y:734,t:1527873295181};\\\", \\\"{x:530,y:736,t:1527873295197};\\\", \\\"{x:537,y:736,t:1527873295213};\\\", \\\"{x:541,y:736,t:1527873295230};\\\", \\\"{x:542,y:736,t:1527873295247};\\\", \\\"{x:543,y:736,t:1527873295646};\\\", \\\"{x:543,y:737,t:1527873295653};\\\", \\\"{x:543,y:738,t:1527873295877};\\\", \\\"{x:544,y:738,t:1527873295901};\\\", \\\"{x:545,y:738,t:1527873295924};\\\", \\\"{x:545,y:739,t:1527873296021};\\\" ] }, { \\\"rt\\\": 34459, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 17, \\\"time_elapsed\\\": 521919, \\\"internal_node_id\\\": \\\"0.0-6.0-7.0\\\", \\\"subject\\\": \\\"2OEC4\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"whiskey\\\", \\\"condition\\\": \\\"115\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"meets\\\", \\\"q\\\": 13, \\\"clicks\\\": 2, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XFull-YFull\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 1, \\\"answer\\\": [ \\\"F\\\", \\\"X\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"\\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:545,y:743,t:1527873296194};\\\", \\\"{x:545,y:741,t:1527873296373};\\\", \\\"{x:545,y:740,t:1527873296381};\\\", \\\"{x:545,y:739,t:1527873297766};\\\", \\\"{x:546,y:738,t:1527873297798};\\\", \\\"{x:546,y:737,t:1527873297806};\\\", \\\"{x:547,y:736,t:1527873297816};\\\", \\\"{x:548,y:736,t:1527873297833};\\\", \\\"{x:549,y:734,t:1527873297850};\\\", \\\"{x:550,y:732,t:1527873297865};\\\", \\\"{x:551,y:731,t:1527873297883};\\\", \\\"{x:552,y:730,t:1527873297900};\\\", \\\"{x:552,y:729,t:1527873299733};\\\", \\\"{x:550,y:727,t:1527873299742};\\\", \\\"{x:548,y:727,t:1527873299751};\\\", \\\"{x:548,y:726,t:1527873300501};\\\", \\\"{x:548,y:725,t:1527873306917};\\\", \\\"{x:553,y:719,t:1527873306925};\\\", \\\"{x:559,y:713,t:1527873306940};\\\", \\\"{x:584,y:696,t:1527873306957};\\\", \\\"{x:598,y:685,t:1527873306974};\\\", \\\"{x:604,y:681,t:1527873306990};\\\", \\\"{x:608,y:678,t:1527873307007};\\\", \\\"{x:609,y:678,t:1527873307024};\\\", \\\"{x:610,y:677,t:1527873307041};\\\", \\\"{x:611,y:677,t:1527873307069};\\\", \\\"{x:612,y:675,t:1527873307076};\\\", \\\"{x:615,y:673,t:1527873307090};\\\", \\\"{x:622,y:666,t:1527873307107};\\\", \\\"{x:626,y:662,t:1527873307124};\\\", \\\"{x:643,y:646,t:1527873307140};\\\", \\\"{x:662,y:636,t:1527873307157};\\\", \\\"{x:693,y:625,t:1527873307175};\\\", \\\"{x:722,y:618,t:1527873307191};\\\", \\\"{x:746,y:611,t:1527873307208};\\\", \\\"{x:760,y:606,t:1527873307224};\\\", \\\"{x:769,y:601,t:1527873307240};\\\", \\\"{x:773,y:597,t:1527873307258};\\\", \\\"{x:780,y:590,t:1527873307274};\\\", \\\"{x:786,y:584,t:1527873307290};\\\", \\\"{x:793,y:581,t:1527873307307};\\\", \\\"{x:802,y:580,t:1527873307323};\\\", \\\"{x:810,y:582,t:1527873307340};\\\", \\\"{x:819,y:587,t:1527873307356};\\\", \\\"{x:832,y:600,t:1527873307374};\\\", \\\"{x:853,y:612,t:1527873307392};\\\", \\\"{x:871,y:622,t:1527873307407};\\\", \\\"{x:887,y:629,t:1527873307423};\\\", \\\"{x:908,y:635,t:1527873307441};\\\", \\\"{x:936,y:640,t:1527873307457};\\\", \\\"{x:962,y:640,t:1527873307474};\\\", \\\"{x:982,y:640,t:1527873307491};\\\", \\\"{x:1001,y:641,t:1527873307507};\\\", \\\"{x:1017,y:644,t:1527873307524};\\\", \\\"{x:1045,y:650,t:1527873307541};\\\", \\\"{x:1064,y:653,t:1527873307557};\\\", \\\"{x:1081,y:658,t:1527873307574};\\\", \\\"{x:1098,y:663,t:1527873307591};\\\", \\\"{x:1115,y:666,t:1527873307608};\\\", \\\"{x:1128,y:667,t:1527873307624};\\\", \\\"{x:1136,y:668,t:1527873307641};\\\", \\\"{x:1148,y:671,t:1527873307658};\\\", \\\"{x:1163,y:673,t:1527873307674};\\\", \\\"{x:1180,y:674,t:1527873307691};\\\", \\\"{x:1196,y:677,t:1527873307708};\\\", \\\"{x:1211,y:679,t:1527873307724};\\\", \\\"{x:1233,y:682,t:1527873307741};\\\", \\\"{x:1243,y:683,t:1527873307758};\\\", \\\"{x:1256,y:683,t:1527873307774};\\\", \\\"{x:1262,y:683,t:1527873307791};\\\", \\\"{x:1265,y:683,t:1527873307808};\\\", \\\"{x:1266,y:683,t:1527873307824};\\\", \\\"{x:1267,y:683,t:1527873307841};\\\", \\\"{x:1268,y:683,t:1527873307876};\\\", \\\"{x:1271,y:683,t:1527873307891};\\\", \\\"{x:1279,y:683,t:1527873307908};\\\", \\\"{x:1289,y:683,t:1527873307924};\\\", \\\"{x:1294,y:683,t:1527873307941};\\\", \\\"{x:1300,y:683,t:1527873307958};\\\", \\\"{x:1307,y:683,t:1527873307975};\\\", \\\"{x:1311,y:684,t:1527873307991};\\\", \\\"{x:1315,y:686,t:1527873308008};\\\", \\\"{x:1317,y:686,t:1527873308045};\\\", \\\"{x:1318,y:686,t:1527873308085};\\\", \\\"{x:1320,y:687,t:1527873308100};\\\", \\\"{x:1322,y:687,t:1527873308116};\\\", \\\"{x:1325,y:689,t:1527873308124};\\\", \\\"{x:1327,y:689,t:1527873308142};\\\", \\\"{x:1329,y:690,t:1527873308158};\\\", \\\"{x:1330,y:691,t:1527873308175};\\\", \\\"{x:1333,y:693,t:1527873308192};\\\", \\\"{x:1334,y:693,t:1527873308208};\\\", \\\"{x:1335,y:694,t:1527873308541};\\\", \\\"{x:1335,y:695,t:1527873308548};\\\", \\\"{x:1335,y:696,t:1527873308565};\\\", \\\"{x:1335,y:697,t:1527873308575};\\\", \\\"{x:1336,y:698,t:1527873309509};\\\", \\\"{x:1338,y:700,t:1527873309517};\\\", \\\"{x:1339,y:702,t:1527873309540};\\\", \\\"{x:1341,y:702,t:1527873309548};\\\", \\\"{x:1342,y:703,t:1527873309597};\\\", \\\"{x:1343,y:703,t:1527873309620};\\\", \\\"{x:1344,y:704,t:1527873309636};\\\", \\\"{x:1344,y:705,t:1527873309653};\\\", \\\"{x:1345,y:705,t:1527873309685};\\\", \\\"{x:1345,y:707,t:1527873309733};\\\", \\\"{x:1343,y:709,t:1527873309744};\\\", \\\"{x:1330,y:711,t:1527873309760};\\\", \\\"{x:1290,y:713,t:1527873309777};\\\", \\\"{x:1176,y:710,t:1527873309794};\\\", \\\"{x:1032,y:688,t:1527873309810};\\\", \\\"{x:901,y:669,t:1527873309827};\\\", \\\"{x:791,y:655,t:1527873309844};\\\", \\\"{x:712,y:642,t:1527873309860};\\\", \\\"{x:647,y:628,t:1527873309877};\\\", \\\"{x:626,y:620,t:1527873309895};\\\", \\\"{x:617,y:619,t:1527873309908};\\\", \\\"{x:601,y:614,t:1527873309925};\\\", \\\"{x:596,y:613,t:1527873309942};\\\", \\\"{x:592,y:612,t:1527873309958};\\\", \\\"{x:588,y:612,t:1527873309976};\\\", \\\"{x:579,y:610,t:1527873309993};\\\", \\\"{x:568,y:607,t:1527873310009};\\\", \\\"{x:556,y:605,t:1527873310026};\\\", \\\"{x:548,y:604,t:1527873310043};\\\", \\\"{x:544,y:603,t:1527873310059};\\\", \\\"{x:538,y:600,t:1527873310076};\\\", \\\"{x:530,y:598,t:1527873310093};\\\", \\\"{x:518,y:595,t:1527873310109};\\\", \\\"{x:503,y:592,t:1527873310126};\\\", \\\"{x:486,y:589,t:1527873310144};\\\", \\\"{x:475,y:588,t:1527873310159};\\\", \\\"{x:464,y:584,t:1527873310176};\\\", \\\"{x:455,y:582,t:1527873310194};\\\", \\\"{x:446,y:580,t:1527873310209};\\\", \\\"{x:440,y:578,t:1527873310226};\\\", \\\"{x:434,y:576,t:1527873310243};\\\", \\\"{x:429,y:575,t:1527873310259};\\\", \\\"{x:426,y:573,t:1527873310276};\\\", \\\"{x:425,y:572,t:1527873310292};\\\", \\\"{x:423,y:570,t:1527873310310};\\\", \\\"{x:422,y:569,t:1527873310326};\\\", \\\"{x:421,y:567,t:1527873310343};\\\", \\\"{x:421,y:565,t:1527873310360};\\\", \\\"{x:421,y:563,t:1527873310376};\\\", \\\"{x:422,y:558,t:1527873310394};\\\", \\\"{x:434,y:554,t:1527873310411};\\\", \\\"{x:451,y:552,t:1527873310426};\\\", \\\"{x:470,y:552,t:1527873310443};\\\", \\\"{x:494,y:552,t:1527873310460};\\\", \\\"{x:513,y:552,t:1527873310476};\\\", \\\"{x:542,y:552,t:1527873310494};\\\", \\\"{x:554,y:552,t:1527873310510};\\\", \\\"{x:563,y:552,t:1527873310526};\\\", \\\"{x:571,y:552,t:1527873310543};\\\", \\\"{x:576,y:552,t:1527873310560};\\\", \\\"{x:580,y:552,t:1527873310576};\\\", \\\"{x:582,y:553,t:1527873310593};\\\", \\\"{x:582,y:554,t:1527873310997};\\\", \\\"{x:582,y:556,t:1527873311021};\\\", \\\"{x:582,y:557,t:1527873311197};\\\", \\\"{x:582,y:559,t:1527873311237};\\\", \\\"{x:582,y:560,t:1527873311645};\\\", \\\"{x:583,y:561,t:1527873311661};\\\", \\\"{x:585,y:561,t:1527873311781};\\\", \\\"{x:586,y:561,t:1527873311805};\\\", \\\"{x:586,y:560,t:1527873311820};\\\", \\\"{x:589,y:559,t:1527873311837};\\\", \\\"{x:591,y:559,t:1527873311853};\\\", \\\"{x:593,y:558,t:1527873311860};\\\", \\\"{x:599,y:556,t:1527873311877};\\\", \\\"{x:605,y:556,t:1527873311894};\\\", \\\"{x:612,y:556,t:1527873311911};\\\", \\\"{x:619,y:556,t:1527873311927};\\\", \\\"{x:622,y:556,t:1527873311944};\\\", \\\"{x:623,y:556,t:1527873311961};\\\", \\\"{x:625,y:555,t:1527873312029};\\\", \\\"{x:626,y:554,t:1527873312053};\\\", \\\"{x:627,y:554,t:1527873312061};\\\", \\\"{x:628,y:553,t:1527873312078};\\\", \\\"{x:630,y:552,t:1527873312094};\\\", \\\"{x:632,y:551,t:1527873312124};\\\", \\\"{x:635,y:550,t:1527873312141};\\\", \\\"{x:636,y:549,t:1527873312149};\\\", \\\"{x:640,y:548,t:1527873312161};\\\", \\\"{x:649,y:546,t:1527873312179};\\\", \\\"{x:663,y:539,t:1527873312194};\\\", \\\"{x:670,y:537,t:1527873312211};\\\", \\\"{x:676,y:534,t:1527873312228};\\\", \\\"{x:679,y:530,t:1527873312244};\\\", \\\"{x:681,y:529,t:1527873312261};\\\", \\\"{x:682,y:529,t:1527873312300};\\\", \\\"{x:683,y:529,t:1527873312316};\\\", \\\"{x:683,y:528,t:1527873312328};\\\", \\\"{x:684,y:528,t:1527873312365};\\\", \\\"{x:685,y:527,t:1527873312380};\\\", \\\"{x:688,y:527,t:1527873312395};\\\", \\\"{x:696,y:527,t:1527873312411};\\\", \\\"{x:717,y:527,t:1527873312428};\\\", \\\"{x:756,y:523,t:1527873312445};\\\", \\\"{x:773,y:522,t:1527873312462};\\\", \\\"{x:790,y:518,t:1527873312478};\\\", \\\"{x:801,y:516,t:1527873312495};\\\", \\\"{x:806,y:513,t:1527873312511};\\\", \\\"{x:811,y:512,t:1527873312528};\\\", \\\"{x:813,y:512,t:1527873312545};\\\", \\\"{x:814,y:512,t:1527873312677};\\\", \\\"{x:815,y:512,t:1527873312700};\\\", \\\"{x:816,y:512,t:1527873312716};\\\", \\\"{x:817,y:512,t:1527873312749};\\\", \\\"{x:818,y:512,t:1527873312761};\\\", \\\"{x:821,y:512,t:1527873312778};\\\", \\\"{x:823,y:512,t:1527873312795};\\\", \\\"{x:824,y:512,t:1527873312813};\\\", \\\"{x:826,y:511,t:1527873312828};\\\", \\\"{x:827,y:509,t:1527873312845};\\\", \\\"{x:830,y:506,t:1527873312861};\\\", \\\"{x:831,y:504,t:1527873312878};\\\", \\\"{x:830,y:504,t:1527873328669};\\\", \\\"{x:819,y:499,t:1527873328676};\\\", \\\"{x:800,y:488,t:1527873328690};\\\", \\\"{x:765,y:470,t:1527873328708};\\\", \\\"{x:749,y:466,t:1527873328724};\\\", \\\"{x:748,y:466,t:1527873328916};\\\", \\\"{x:745,y:466,t:1527873328924};\\\", \\\"{x:741,y:474,t:1527873328941};\\\", \\\"{x:734,y:484,t:1527873328958};\\\", \\\"{x:726,y:493,t:1527873328975};\\\", \\\"{x:721,y:498,t:1527873328991};\\\", \\\"{x:713,y:504,t:1527873329007};\\\", \\\"{x:705,y:512,t:1527873329025};\\\", \\\"{x:702,y:516,t:1527873329042};\\\", \\\"{x:697,y:519,t:1527873329059};\\\", \\\"{x:695,y:521,t:1527873329075};\\\", \\\"{x:691,y:525,t:1527873329092};\\\", \\\"{x:688,y:530,t:1527873329108};\\\", \\\"{x:686,y:532,t:1527873329125};\\\", \\\"{x:686,y:533,t:1527873329142};\\\", \\\"{x:685,y:535,t:1527873329173};\\\", \\\"{x:683,y:538,t:1527873329188};\\\", \\\"{x:681,y:540,t:1527873329196};\\\", \\\"{x:679,y:546,t:1527873329209};\\\", \\\"{x:672,y:553,t:1527873329225};\\\", \\\"{x:662,y:567,t:1527873329242};\\\", \\\"{x:656,y:572,t:1527873329259};\\\", \\\"{x:654,y:572,t:1527873329275};\\\", \\\"{x:654,y:573,t:1527873329452};\\\", \\\"{x:655,y:574,t:1527873329460};\\\", \\\"{x:655,y:575,t:1527873329532};\\\", \\\"{x:654,y:576,t:1527873329541};\\\", \\\"{x:647,y:579,t:1527873329559};\\\", \\\"{x:639,y:582,t:1527873329576};\\\", \\\"{x:634,y:586,t:1527873329592};\\\", \\\"{x:625,y:592,t:1527873329609};\\\", \\\"{x:619,y:597,t:1527873329626};\\\", \\\"{x:617,y:600,t:1527873329642};\\\", \\\"{x:615,y:601,t:1527873329659};\\\", \\\"{x:613,y:602,t:1527873329675};\\\", \\\"{x:611,y:603,t:1527873329700};\\\", \\\"{x:611,y:602,t:1527873329805};\\\", \\\"{x:611,y:601,t:1527873329812};\\\", \\\"{x:611,y:600,t:1527873329826};\\\", \\\"{x:611,y:598,t:1527873329843};\\\", \\\"{x:611,y:594,t:1527873329859};\\\", \\\"{x:611,y:587,t:1527873329876};\\\", \\\"{x:611,y:584,t:1527873329893};\\\", \\\"{x:611,y:583,t:1527873329909};\\\", \\\"{x:611,y:582,t:1527873329997};\\\", \\\"{x:607,y:585,t:1527873330204};\\\", \\\"{x:600,y:590,t:1527873330212};\\\", \\\"{x:594,y:595,t:1527873330227};\\\", \\\"{x:580,y:604,t:1527873330243};\\\", \\\"{x:568,y:615,t:1527873330260};\\\", \\\"{x:558,y:631,t:1527873330276};\\\", \\\"{x:539,y:660,t:1527873330293};\\\", \\\"{x:529,y:676,t:1527873330310};\\\", \\\"{x:523,y:692,t:1527873330326};\\\", \\\"{x:516,y:707,t:1527873330342};\\\", \\\"{x:512,y:718,t:1527873330360};\\\", \\\"{x:507,y:725,t:1527873330376};\\\", \\\"{x:505,y:730,t:1527873330393};\\\", \\\"{x:504,y:734,t:1527873330410};\\\", \\\"{x:503,y:737,t:1527873330425};\\\", \\\"{x:502,y:739,t:1527873330443};\\\", \\\"{x:501,y:740,t:1527873330628};\\\", \\\"{x:501,y:740,t:1527873330668};\\\", \\\"{x:497,y:747,t:1527873330956};\\\", \\\"{x:495,y:751,t:1527873330964};\\\", \\\"{x:488,y:756,t:1527873330977};\\\", \\\"{x:476,y:761,t:1527873330993};\\\", \\\"{x:474,y:761,t:1527873331009};\\\", \\\"{x:472,y:761,t:1527873331027};\\\", \\\"{x:472,y:760,t:1527873331724};\\\", \\\"{x:472,y:759,t:1527873331732};\\\", \\\"{x:473,y:756,t:1527873331744};\\\", \\\"{x:477,y:751,t:1527873331761};\\\" ] }, { \\\"rt\\\": 32723, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 18, \\\"time_elapsed\\\": 555882, \\\"internal_node_id\\\": \\\"0.0-6.0-8.0\\\", \\\"subject\\\": \\\"2OEC4\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"whiskey\\\", \\\"condition\\\": \\\"115\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"endtime\\\", \\\"q\\\": 14, \\\"clicks\\\": 1.5, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XFull-YFull\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 1, \\\"answer\\\": [ \\\"B\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-B \\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:492,y:731,t:1527873331895};\\\", \\\"{x:494,y:728,t:1527873331910};\\\", \\\"{x:495,y:727,t:1527873331927};\\\", \\\"{x:495,y:726,t:1527873331949};\\\", \\\"{x:496,y:726,t:1527873332149};\\\", \\\"{x:497,y:724,t:1527873332161};\\\", \\\"{x:498,y:724,t:1527873332178};\\\", \\\"{x:499,y:723,t:1527873332194};\\\", \\\"{x:501,y:721,t:1527873332330};\\\", \\\"{x:501,y:720,t:1527873332346};\\\", \\\"{x:502,y:719,t:1527873332365};\\\", \\\"{x:503,y:718,t:1527873332380};\\\", \\\"{x:504,y:717,t:1527873332396};\\\", \\\"{x:505,y:717,t:1527873332411};\\\", \\\"{x:506,y:715,t:1527873332428};\\\", \\\"{x:507,y:715,t:1527873332652};\\\", \\\"{x:507,y:716,t:1527873332668};\\\", \\\"{x:507,y:718,t:1527873332678};\\\", \\\"{x:507,y:722,t:1527873332696};\\\", \\\"{x:507,y:726,t:1527873332712};\\\", \\\"{x:506,y:730,t:1527873332728};\\\", \\\"{x:506,y:733,t:1527873332745};\\\", \\\"{x:505,y:737,t:1527873332761};\\\", \\\"{x:504,y:741,t:1527873332778};\\\", \\\"{x:502,y:744,t:1527873332795};\\\", \\\"{x:501,y:747,t:1527873332812};\\\", \\\"{x:501,y:748,t:1527873332828};\\\", \\\"{x:499,y:749,t:1527873332845};\\\", \\\"{x:499,y:750,t:1527873333748};\\\", \\\"{x:499,y:751,t:1527873333762};\\\", \\\"{x:500,y:751,t:1527873333779};\\\", \\\"{x:501,y:751,t:1527873333795};\\\", \\\"{x:503,y:751,t:1527873333812};\\\", \\\"{x:504,y:751,t:1527873333828};\\\", \\\"{x:506,y:751,t:1527873333845};\\\", \\\"{x:507,y:751,t:1527873333892};\\\", \\\"{x:508,y:751,t:1527873333901};\\\", \\\"{x:509,y:750,t:1527873333912};\\\", \\\"{x:511,y:750,t:1527873333932};\\\", \\\"{x:512,y:750,t:1527873333989};\\\", \\\"{x:512,y:749,t:1527873334285};\\\", \\\"{x:513,y:748,t:1527873334300};\\\", \\\"{x:514,y:748,t:1527873334312};\\\", \\\"{x:515,y:747,t:1527873334405};\\\", \\\"{x:516,y:746,t:1527873334444};\\\", \\\"{x:517,y:746,t:1527873334452};\\\", \\\"{x:518,y:746,t:1527873334540};\\\", \\\"{x:519,y:746,t:1527873335373};\\\", \\\"{x:519,y:745,t:1527873335389};\\\", \\\"{x:520,y:745,t:1527873335396};\\\", \\\"{x:521,y:744,t:1527873335413};\\\", \\\"{x:522,y:743,t:1527873335444};\\\", \\\"{x:523,y:743,t:1527873336869};\\\", \\\"{x:524,y:743,t:1527873336908};\\\", \\\"{x:525,y:743,t:1527873336917};\\\", \\\"{x:526,y:742,t:1527873337100};\\\", \\\"{x:528,y:742,t:1527873337116};\\\", \\\"{x:529,y:742,t:1527873337131};\\\", \\\"{x:534,y:740,t:1527873337147};\\\", \\\"{x:548,y:737,t:1527873337164};\\\", \\\"{x:565,y:737,t:1527873337181};\\\", \\\"{x:589,y:737,t:1527873337197};\\\", \\\"{x:631,y:737,t:1527873337215};\\\", \\\"{x:736,y:737,t:1527873337232};\\\", \\\"{x:900,y:741,t:1527873337248};\\\", \\\"{x:1071,y:763,t:1527873337265};\\\", \\\"{x:1250,y:788,t:1527873337282};\\\", \\\"{x:1383,y:807,t:1527873337298};\\\", \\\"{x:1467,y:818,t:1527873337315};\\\", \\\"{x:1505,y:824,t:1527873337332};\\\", \\\"{x:1507,y:824,t:1527873337349};\\\", \\\"{x:1508,y:826,t:1527873337581};\\\", \\\"{x:1508,y:828,t:1527873337596};\\\", \\\"{x:1508,y:829,t:1527873337604};\\\", \\\"{x:1508,y:830,t:1527873337615};\\\", \\\"{x:1508,y:832,t:1527873337633};\\\", \\\"{x:1508,y:834,t:1527873337649};\\\", \\\"{x:1508,y:835,t:1527873337665};\\\", \\\"{x:1508,y:836,t:1527873337682};\\\", \\\"{x:1508,y:837,t:1527873337701};\\\", \\\"{x:1508,y:839,t:1527873337837};\\\", \\\"{x:1505,y:839,t:1527873337860};\\\", \\\"{x:1504,y:840,t:1527873337868};\\\", \\\"{x:1501,y:840,t:1527873337882};\\\", \\\"{x:1494,y:840,t:1527873337899};\\\", \\\"{x:1484,y:840,t:1527873337916};\\\", \\\"{x:1479,y:840,t:1527873337933};\\\", \\\"{x:1475,y:840,t:1527873337949};\\\", \\\"{x:1471,y:841,t:1527873337966};\\\", \\\"{x:1470,y:841,t:1527873338012};\\\", \\\"{x:1469,y:841,t:1527873338036};\\\", \\\"{x:1467,y:840,t:1527873338050};\\\", \\\"{x:1460,y:838,t:1527873338066};\\\", \\\"{x:1443,y:832,t:1527873338082};\\\", \\\"{x:1425,y:825,t:1527873338100};\\\", \\\"{x:1409,y:819,t:1527873338116};\\\", \\\"{x:1399,y:813,t:1527873338134};\\\", \\\"{x:1389,y:809,t:1527873338150};\\\", \\\"{x:1375,y:803,t:1527873338166};\\\", \\\"{x:1367,y:799,t:1527873338183};\\\", \\\"{x:1354,y:793,t:1527873338199};\\\", \\\"{x:1344,y:789,t:1527873338216};\\\", \\\"{x:1334,y:785,t:1527873338233};\\\", \\\"{x:1329,y:783,t:1527873338249};\\\", \\\"{x:1326,y:780,t:1527873338266};\\\", \\\"{x:1326,y:779,t:1527873338284};\\\", \\\"{x:1326,y:778,t:1527873338300};\\\", \\\"{x:1326,y:774,t:1527873338316};\\\", \\\"{x:1326,y:773,t:1527873338333};\\\", \\\"{x:1326,y:772,t:1527873338349};\\\", \\\"{x:1326,y:771,t:1527873338366};\\\", \\\"{x:1327,y:770,t:1527873338388};\\\", \\\"{x:1328,y:770,t:1527873338404};\\\", \\\"{x:1328,y:769,t:1527873338484};\\\", \\\"{x:1329,y:769,t:1527873338500};\\\", \\\"{x:1334,y:769,t:1527873338516};\\\", \\\"{x:1337,y:769,t:1527873338533};\\\", \\\"{x:1340,y:769,t:1527873338550};\\\", \\\"{x:1342,y:769,t:1527873338566};\\\", \\\"{x:1343,y:769,t:1527873338644};\\\", \\\"{x:1344,y:769,t:1527873340204};\\\", \\\"{x:1345,y:769,t:1527873340218};\\\", \\\"{x:1345,y:768,t:1527873341869};\\\", \\\"{x:1326,y:764,t:1527873341887};\\\", \\\"{x:1297,y:760,t:1527873341903};\\\", \\\"{x:1273,y:753,t:1527873341920};\\\", \\\"{x:1247,y:751,t:1527873341937};\\\", \\\"{x:1217,y:746,t:1527873341952};\\\", \\\"{x:1171,y:739,t:1527873341969};\\\", \\\"{x:1094,y:730,t:1527873341986};\\\", \\\"{x:1004,y:715,t:1527873342002};\\\", \\\"{x:904,y:699,t:1527873342020};\\\", \\\"{x:764,y:664,t:1527873342037};\\\", \\\"{x:707,y:652,t:1527873342052};\\\", \\\"{x:677,y:642,t:1527873342069};\\\", \\\"{x:660,y:638,t:1527873342086};\\\", \\\"{x:649,y:632,t:1527873342102};\\\", \\\"{x:640,y:626,t:1527873342120};\\\", \\\"{x:630,y:618,t:1527873342137};\\\", \\\"{x:618,y:611,t:1527873342152};\\\", \\\"{x:606,y:601,t:1527873342170};\\\", \\\"{x:590,y:592,t:1527873342186};\\\", \\\"{x:570,y:581,t:1527873342202};\\\", \\\"{x:547,y:568,t:1527873342219};\\\", \\\"{x:517,y:553,t:1527873342236};\\\", \\\"{x:505,y:546,t:1527873342253};\\\", \\\"{x:490,y:537,t:1527873342270};\\\", \\\"{x:472,y:525,t:1527873342286};\\\", \\\"{x:454,y:516,t:1527873342303};\\\", \\\"{x:445,y:513,t:1527873342320};\\\", \\\"{x:441,y:512,t:1527873342336};\\\", \\\"{x:440,y:512,t:1527873342356};\\\", \\\"{x:438,y:512,t:1527873342370};\\\", \\\"{x:426,y:512,t:1527873342386};\\\", \\\"{x:406,y:510,t:1527873342403};\\\", \\\"{x:377,y:508,t:1527873342420};\\\", \\\"{x:325,y:506,t:1527873342436};\\\", \\\"{x:283,y:506,t:1527873342452};\\\", \\\"{x:238,y:506,t:1527873342470};\\\", \\\"{x:220,y:506,t:1527873342486};\\\", \\\"{x:211,y:512,t:1527873342502};\\\", \\\"{x:209,y:516,t:1527873342520};\\\", \\\"{x:207,y:519,t:1527873342537};\\\", \\\"{x:207,y:522,t:1527873342552};\\\", \\\"{x:206,y:524,t:1527873342569};\\\", \\\"{x:206,y:525,t:1527873342587};\\\", \\\"{x:205,y:526,t:1527873342612};\\\", \\\"{x:203,y:527,t:1527873342628};\\\", \\\"{x:203,y:528,t:1527873342636};\\\", \\\"{x:201,y:529,t:1527873342653};\\\", \\\"{x:199,y:531,t:1527873342669};\\\", \\\"{x:197,y:532,t:1527873342686};\\\", \\\"{x:194,y:534,t:1527873342703};\\\", \\\"{x:191,y:535,t:1527873342720};\\\", \\\"{x:184,y:536,t:1527873342737};\\\", \\\"{x:178,y:538,t:1527873342753};\\\", \\\"{x:170,y:538,t:1527873342769};\\\", \\\"{x:164,y:538,t:1527873342786};\\\", \\\"{x:158,y:538,t:1527873342803};\\\", \\\"{x:153,y:538,t:1527873342819};\\\", \\\"{x:148,y:538,t:1527873342836};\\\", \\\"{x:147,y:538,t:1527873342854};\\\", \\\"{x:146,y:538,t:1527873342869};\\\", \\\"{x:146,y:539,t:1527873343373};\\\", \\\"{x:148,y:540,t:1527873343420};\\\", \\\"{x:149,y:541,t:1527873343452};\\\", \\\"{x:150,y:541,t:1527873343556};\\\", \\\"{x:151,y:541,t:1527873343570};\\\", \\\"{x:152,y:542,t:1527873343596};\\\", \\\"{x:153,y:542,t:1527873343620};\\\", \\\"{x:154,y:542,t:1527873343637};\\\", \\\"{x:156,y:542,t:1527873343916};\\\", \\\"{x:160,y:542,t:1527873343924};\\\", \\\"{x:167,y:542,t:1527873343938};\\\", \\\"{x:184,y:542,t:1527873343955};\\\", \\\"{x:202,y:539,t:1527873343972};\\\", \\\"{x:220,y:539,t:1527873343987};\\\", \\\"{x:240,y:539,t:1527873344004};\\\", \\\"{x:253,y:539,t:1527873344020};\\\", \\\"{x:263,y:539,t:1527873344037};\\\", \\\"{x:268,y:539,t:1527873344055};\\\", \\\"{x:270,y:539,t:1527873344071};\\\", \\\"{x:272,y:539,t:1527873344087};\\\", \\\"{x:273,y:539,t:1527873344105};\\\", \\\"{x:275,y:539,t:1527873344124};\\\", \\\"{x:276,y:539,t:1527873344149};\\\", \\\"{x:278,y:539,t:1527873344164};\\\", \\\"{x:279,y:539,t:1527873344188};\\\", \\\"{x:281,y:539,t:1527873344221};\\\", \\\"{x:282,y:539,t:1527873344236};\\\", \\\"{x:284,y:539,t:1527873344252};\\\", \\\"{x:285,y:539,t:1527873344284};\\\", \\\"{x:287,y:539,t:1527873344948};\\\", \\\"{x:292,y:539,t:1527873344956};\\\", \\\"{x:303,y:539,t:1527873344971};\\\", \\\"{x:344,y:543,t:1527873344988};\\\", \\\"{x:397,y:550,t:1527873345005};\\\", \\\"{x:473,y:563,t:1527873345022};\\\", \\\"{x:540,y:573,t:1527873345039};\\\", \\\"{x:599,y:581,t:1527873345054};\\\", \\\"{x:640,y:589,t:1527873345072};\\\", \\\"{x:662,y:596,t:1527873345089};\\\", \\\"{x:673,y:603,t:1527873345105};\\\", \\\"{x:676,y:606,t:1527873345122};\\\", \\\"{x:677,y:611,t:1527873345138};\\\", \\\"{x:681,y:618,t:1527873345155};\\\", \\\"{x:684,y:627,t:1527873345172};\\\", \\\"{x:695,y:648,t:1527873345189};\\\", \\\"{x:707,y:664,t:1527873345205};\\\", \\\"{x:722,y:678,t:1527873345222};\\\", \\\"{x:741,y:689,t:1527873345238};\\\", \\\"{x:758,y:695,t:1527873345255};\\\", \\\"{x:777,y:701,t:1527873345272};\\\", \\\"{x:805,y:707,t:1527873345288};\\\", \\\"{x:836,y:712,t:1527873345305};\\\", \\\"{x:880,y:718,t:1527873345321};\\\", \\\"{x:931,y:725,t:1527873345338};\\\", \\\"{x:977,y:734,t:1527873345356};\\\", \\\"{x:1028,y:745,t:1527873345371};\\\", \\\"{x:1080,y:754,t:1527873345389};\\\", \\\"{x:1112,y:759,t:1527873345405};\\\", \\\"{x:1141,y:763,t:1527873345422};\\\", \\\"{x:1163,y:766,t:1527873345438};\\\", \\\"{x:1185,y:771,t:1527873345455};\\\", \\\"{x:1202,y:771,t:1527873345471};\\\", \\\"{x:1216,y:771,t:1527873345488};\\\", \\\"{x:1227,y:773,t:1527873345505};\\\", \\\"{x:1239,y:775,t:1527873345521};\\\", \\\"{x:1251,y:776,t:1527873345538};\\\", \\\"{x:1263,y:778,t:1527873345556};\\\", \\\"{x:1277,y:778,t:1527873345572};\\\", \\\"{x:1284,y:778,t:1527873345589};\\\", \\\"{x:1292,y:779,t:1527873345606};\\\", \\\"{x:1297,y:780,t:1527873345622};\\\", \\\"{x:1304,y:781,t:1527873345638};\\\", \\\"{x:1311,y:782,t:1527873345655};\\\", \\\"{x:1316,y:782,t:1527873345672};\\\", \\\"{x:1320,y:782,t:1527873345688};\\\", \\\"{x:1324,y:782,t:1527873345706};\\\", \\\"{x:1332,y:782,t:1527873345723};\\\", \\\"{x:1345,y:782,t:1527873345739};\\\", \\\"{x:1359,y:782,t:1527873345755};\\\", \\\"{x:1365,y:782,t:1527873345772};\\\", \\\"{x:1365,y:781,t:1527873345877};\\\", \\\"{x:1365,y:778,t:1527873345889};\\\", \\\"{x:1358,y:775,t:1527873345906};\\\", \\\"{x:1345,y:770,t:1527873345922};\\\", \\\"{x:1339,y:766,t:1527873345938};\\\", \\\"{x:1335,y:764,t:1527873345955};\\\", \\\"{x:1333,y:764,t:1527873345972};\\\", \\\"{x:1332,y:763,t:1527873345988};\\\", \\\"{x:1331,y:762,t:1527873346006};\\\", \\\"{x:1330,y:762,t:1527873346022};\\\", \\\"{x:1328,y:761,t:1527873346040};\\\", \\\"{x:1327,y:761,t:1527873346056};\\\", \\\"{x:1326,y:761,t:1527873346073};\\\", \\\"{x:1325,y:760,t:1527873346140};\\\", \\\"{x:1324,y:760,t:1527873346316};\\\", \\\"{x:1323,y:760,t:1527873346324};\\\", \\\"{x:1321,y:760,t:1527873346340};\\\", \\\"{x:1318,y:760,t:1527873346355};\\\", \\\"{x:1317,y:760,t:1527873346373};\\\", \\\"{x:1315,y:760,t:1527873346452};\\\", \\\"{x:1314,y:760,t:1527873346492};\\\", \\\"{x:1312,y:760,t:1527873346524};\\\", \\\"{x:1311,y:761,t:1527873346548};\\\", \\\"{x:1310,y:761,t:1527873346588};\\\", \\\"{x:1309,y:761,t:1527873346604};\\\", \\\"{x:1308,y:761,t:1527873346628};\\\", \\\"{x:1308,y:762,t:1527873346639};\\\", \\\"{x:1306,y:762,t:1527873346657};\\\", \\\"{x:1304,y:762,t:1527873346673};\\\", \\\"{x:1302,y:763,t:1527873346689};\\\", \\\"{x:1300,y:763,t:1527873346707};\\\", \\\"{x:1298,y:763,t:1527873346722};\\\", \\\"{x:1296,y:764,t:1527873346740};\\\", \\\"{x:1295,y:764,t:1527873346765};\\\", \\\"{x:1294,y:764,t:1527873346780};\\\", \\\"{x:1293,y:764,t:1527873346797};\\\", \\\"{x:1292,y:764,t:1527873346820};\\\", \\\"{x:1291,y:764,t:1527873346836};\\\", \\\"{x:1290,y:764,t:1527873346844};\\\", \\\"{x:1289,y:764,t:1527873346868};\\\", \\\"{x:1288,y:764,t:1527873346876};\\\", \\\"{x:1287,y:764,t:1527873346890};\\\", \\\"{x:1286,y:764,t:1527873346906};\\\", \\\"{x:1283,y:764,t:1527873346923};\\\", \\\"{x:1281,y:764,t:1527873346939};\\\", \\\"{x:1280,y:763,t:1527873347028};\\\", \\\"{x:1279,y:763,t:1527873354856};\\\", \\\"{x:1278,y:763,t:1527873354866};\\\", \\\"{x:1278,y:764,t:1527873354888};\\\", \\\"{x:1278,y:763,t:1527873355192};\\\", \\\"{x:1277,y:763,t:1527873355344};\\\", \\\"{x:1274,y:763,t:1527873355352};\\\", \\\"{x:1268,y:764,t:1527873355366};\\\", \\\"{x:1249,y:764,t:1527873355383};\\\", \\\"{x:1236,y:764,t:1527873355400};\\\", \\\"{x:1222,y:762,t:1527873355417};\\\", \\\"{x:1203,y:758,t:1527873355433};\\\", \\\"{x:1174,y:753,t:1527873355450};\\\", \\\"{x:1127,y:746,t:1527873355467};\\\", \\\"{x:1089,y:742,t:1527873355483};\\\", \\\"{x:1040,y:731,t:1527873355499};\\\", \\\"{x:992,y:724,t:1527873355516};\\\", \\\"{x:944,y:716,t:1527873355533};\\\", \\\"{x:897,y:712,t:1527873355549};\\\", \\\"{x:854,y:705,t:1527873355566};\\\", \\\"{x:794,y:696,t:1527873355583};\\\", \\\"{x:747,y:690,t:1527873355599};\\\", \\\"{x:697,y:684,t:1527873355616};\\\", \\\"{x:670,y:684,t:1527873355633};\\\", \\\"{x:651,y:684,t:1527873355650};\\\", \\\"{x:625,y:684,t:1527873355667};\\\", \\\"{x:607,y:684,t:1527873355683};\\\", \\\"{x:595,y:684,t:1527873355699};\\\", \\\"{x:585,y:684,t:1527873355716};\\\", \\\"{x:579,y:684,t:1527873355733};\\\", \\\"{x:573,y:684,t:1527873355750};\\\", \\\"{x:569,y:684,t:1527873355767};\\\", \\\"{x:567,y:684,t:1527873355784};\\\", \\\"{x:566,y:684,t:1527873355831};\\\", \\\"{x:564,y:683,t:1527873355840};\\\", \\\"{x:563,y:681,t:1527873355850};\\\", \\\"{x:562,y:675,t:1527873355866};\\\", \\\"{x:560,y:673,t:1527873355883};\\\", \\\"{x:560,y:670,t:1527873355900};\\\", \\\"{x:560,y:666,t:1527873355916};\\\", \\\"{x:560,y:664,t:1527873355933};\\\", \\\"{x:560,y:663,t:1527873355992};\\\", \\\"{x:559,y:663,t:1527873356000};\\\", \\\"{x:556,y:663,t:1527873356016};\\\", \\\"{x:552,y:668,t:1527873356034};\\\", \\\"{x:549,y:673,t:1527873356051};\\\", \\\"{x:547,y:677,t:1527873356066};\\\", \\\"{x:545,y:680,t:1527873356083};\\\", \\\"{x:543,y:683,t:1527873356100};\\\", \\\"{x:541,y:684,t:1527873356116};\\\", \\\"{x:540,y:686,t:1527873356133};\\\", \\\"{x:534,y:687,t:1527873356151};\\\", \\\"{x:529,y:689,t:1527873356166};\\\", \\\"{x:524,y:690,t:1527873356184};\\\", \\\"{x:523,y:691,t:1527873356200};\\\", \\\"{x:521,y:691,t:1527873356217};\\\", \\\"{x:518,y:691,t:1527873356233};\\\", \\\"{x:516,y:693,t:1527873356250};\\\", \\\"{x:514,y:693,t:1527873356266};\\\", \\\"{x:511,y:694,t:1527873356283};\\\", \\\"{x:510,y:694,t:1527873356300};\\\", \\\"{x:507,y:696,t:1527873356316};\\\", \\\"{x:505,y:696,t:1527873356351};\\\", \\\"{x:504,y:697,t:1527873356367};\\\", \\\"{x:501,y:697,t:1527873356383};\\\", \\\"{x:498,y:697,t:1527873356400};\\\", \\\"{x:494,y:697,t:1527873356418};\\\", \\\"{x:489,y:697,t:1527873356433};\\\", \\\"{x:481,y:695,t:1527873356451};\\\", \\\"{x:470,y:689,t:1527873356467};\\\", \\\"{x:456,y:684,t:1527873356484};\\\", \\\"{x:440,y:675,t:1527873356501};\\\", \\\"{x:424,y:668,t:1527873356517};\\\", \\\"{x:414,y:661,t:1527873356534};\\\", \\\"{x:411,y:659,t:1527873356550};\\\", \\\"{x:410,y:657,t:1527873356567};\\\", \\\"{x:410,y:655,t:1527873356736};\\\", \\\"{x:412,y:653,t:1527873356751};\\\", \\\"{x:423,y:648,t:1527873356768};\\\", \\\"{x:424,y:648,t:1527873356784};\\\", \\\"{x:424,y:647,t:1527873356801};\\\", \\\"{x:426,y:649,t:1527873356992};\\\", \\\"{x:428,y:649,t:1527873357002};\\\", \\\"{x:427,y:649,t:1527873357096};\\\", \\\"{x:425,y:648,t:1527873357111};\\\", \\\"{x:421,y:645,t:1527873357119};\\\", \\\"{x:410,y:639,t:1527873357135};\\\", \\\"{x:393,y:633,t:1527873357152};\\\", \\\"{x:371,y:625,t:1527873357169};\\\", \\\"{x:351,y:617,t:1527873357185};\\\", \\\"{x:330,y:612,t:1527873357201};\\\", \\\"{x:316,y:605,t:1527873357218};\\\", \\\"{x:307,y:603,t:1527873357235};\\\", \\\"{x:300,y:600,t:1527873357252};\\\", \\\"{x:296,y:600,t:1527873357269};\\\", \\\"{x:293,y:598,t:1527873357286};\\\", \\\"{x:291,y:597,t:1527873357302};\\\", \\\"{x:289,y:596,t:1527873357319};\\\", \\\"{x:279,y:589,t:1527873357336};\\\", \\\"{x:272,y:587,t:1527873357351};\\\", \\\"{x:271,y:586,t:1527873357369};\\\", \\\"{x:266,y:584,t:1527873357385};\\\", \\\"{x:262,y:583,t:1527873357402};\\\", \\\"{x:258,y:581,t:1527873357419};\\\", \\\"{x:253,y:578,t:1527873357436};\\\", \\\"{x:248,y:573,t:1527873357452};\\\", \\\"{x:243,y:570,t:1527873357468};\\\", \\\"{x:242,y:569,t:1527873357485};\\\", \\\"{x:241,y:568,t:1527873357502};\\\", \\\"{x:240,y:566,t:1527873357518};\\\", \\\"{x:238,y:563,t:1527873357535};\\\", \\\"{x:236,y:558,t:1527873357553};\\\", \\\"{x:235,y:556,t:1527873357568};\\\", \\\"{x:235,y:554,t:1527873357586};\\\", \\\"{x:235,y:553,t:1527873357607};\\\", \\\"{x:235,y:552,t:1527873357656};\\\", \\\"{x:235,y:551,t:1527873357671};\\\", \\\"{x:234,y:551,t:1527873357685};\\\", \\\"{x:228,y:548,t:1527873357702};\\\", \\\"{x:213,y:545,t:1527873357719};\\\", \\\"{x:201,y:545,t:1527873357735};\\\", \\\"{x:185,y:544,t:1527873357753};\\\", \\\"{x:172,y:544,t:1527873357769};\\\", \\\"{x:163,y:544,t:1527873357786};\\\", \\\"{x:161,y:544,t:1527873357802};\\\", \\\"{x:162,y:544,t:1527873358495};\\\", \\\"{x:164,y:545,t:1527873358511};\\\", \\\"{x:165,y:545,t:1527873358520};\\\", \\\"{x:168,y:547,t:1527873358536};\\\", \\\"{x:170,y:548,t:1527873358553};\\\", \\\"{x:171,y:549,t:1527873358570};\\\", \\\"{x:173,y:550,t:1527873358587};\\\", \\\"{x:177,y:552,t:1527873358602};\\\", \\\"{x:182,y:553,t:1527873358619};\\\", \\\"{x:189,y:557,t:1527873358637};\\\", \\\"{x:195,y:558,t:1527873358653};\\\", \\\"{x:203,y:561,t:1527873358670};\\\", \\\"{x:210,y:562,t:1527873358687};\\\", \\\"{x:220,y:564,t:1527873358704};\\\", \\\"{x:223,y:564,t:1527873358719};\\\", \\\"{x:229,y:565,t:1527873358736};\\\", \\\"{x:234,y:566,t:1527873358754};\\\", \\\"{x:237,y:566,t:1527873358770};\\\", \\\"{x:242,y:566,t:1527873358786};\\\", \\\"{x:246,y:566,t:1527873358803};\\\", \\\"{x:250,y:566,t:1527873358820};\\\", \\\"{x:253,y:566,t:1527873358837};\\\", \\\"{x:258,y:566,t:1527873358854};\\\", \\\"{x:260,y:566,t:1527873358869};\\\", \\\"{x:265,y:568,t:1527873358887};\\\", \\\"{x:271,y:569,t:1527873358903};\\\", \\\"{x:277,y:572,t:1527873358920};\\\", \\\"{x:280,y:573,t:1527873358937};\\\", \\\"{x:285,y:574,t:1527873358953};\\\", \\\"{x:289,y:575,t:1527873358971};\\\", \\\"{x:293,y:577,t:1527873358986};\\\", \\\"{x:294,y:578,t:1527873359003};\\\", \\\"{x:297,y:579,t:1527873359021};\\\", \\\"{x:299,y:580,t:1527873359037};\\\", \\\"{x:301,y:581,t:1527873359054};\\\", \\\"{x:303,y:582,t:1527873359070};\\\", \\\"{x:305,y:584,t:1527873359086};\\\", \\\"{x:307,y:586,t:1527873359103};\\\", \\\"{x:308,y:587,t:1527873359121};\\\", \\\"{x:310,y:589,t:1527873359136};\\\", \\\"{x:311,y:590,t:1527873359154};\\\", \\\"{x:313,y:590,t:1527873359170};\\\", \\\"{x:314,y:591,t:1527873359186};\\\", \\\"{x:316,y:592,t:1527873359203};\\\", \\\"{x:316,y:593,t:1527873359220};\\\", \\\"{x:317,y:593,t:1527873359236};\\\", \\\"{x:319,y:594,t:1527873359255};\\\", \\\"{x:319,y:595,t:1527873359271};\\\", \\\"{x:320,y:595,t:1527873359286};\\\", \\\"{x:322,y:597,t:1527873359304};\\\", \\\"{x:326,y:598,t:1527873359320};\\\", \\\"{x:330,y:600,t:1527873359336};\\\", \\\"{x:334,y:601,t:1527873359354};\\\", \\\"{x:337,y:603,t:1527873359370};\\\", \\\"{x:340,y:604,t:1527873359386};\\\", \\\"{x:343,y:606,t:1527873359403};\\\", \\\"{x:347,y:610,t:1527873359421};\\\", \\\"{x:354,y:615,t:1527873359437};\\\", \\\"{x:361,y:620,t:1527873359454};\\\", \\\"{x:368,y:625,t:1527873359471};\\\", \\\"{x:375,y:630,t:1527873359488};\\\", \\\"{x:377,y:633,t:1527873359504};\\\", \\\"{x:380,y:635,t:1527873359520};\\\", \\\"{x:381,y:636,t:1527873359538};\\\", \\\"{x:382,y:637,t:1527873359553};\\\", \\\"{x:383,y:638,t:1527873359575};\\\", \\\"{x:384,y:641,t:1527873359631};\\\", \\\"{x:385,y:642,t:1527873359664};\\\", \\\"{x:385,y:644,t:1527873359671};\\\", \\\"{x:387,y:645,t:1527873359687};\\\", \\\"{x:389,y:649,t:1527873359704};\\\", \\\"{x:393,y:654,t:1527873359720};\\\", \\\"{x:396,y:658,t:1527873359738};\\\", \\\"{x:398,y:661,t:1527873359753};\\\", \\\"{x:401,y:664,t:1527873359771};\\\", \\\"{x:405,y:667,t:1527873359788};\\\", \\\"{x:406,y:667,t:1527873359804};\\\", \\\"{x:407,y:668,t:1527873359821};\\\", \\\"{x:408,y:669,t:1527873359838};\\\", \\\"{x:409,y:669,t:1527873359854};\\\", \\\"{x:410,y:670,t:1527873359871};\\\", \\\"{x:412,y:673,t:1527873359887};\\\", \\\"{x:416,y:677,t:1527873359904};\\\", \\\"{x:419,y:678,t:1527873359920};\\\", \\\"{x:421,y:678,t:1527873359944};\\\", \\\"{x:423,y:679,t:1527873359955};\\\", \\\"{x:425,y:679,t:1527873359970};\\\", \\\"{x:428,y:680,t:1527873359988};\\\", \\\"{x:432,y:681,t:1527873360004};\\\", \\\"{x:438,y:682,t:1527873360022};\\\", \\\"{x:445,y:684,t:1527873360037};\\\", \\\"{x:456,y:688,t:1527873360055};\\\", \\\"{x:467,y:690,t:1527873360071};\\\", \\\"{x:472,y:692,t:1527873360087};\\\", \\\"{x:474,y:693,t:1527873360104};\\\", \\\"{x:475,y:693,t:1527873360215};\\\", \\\"{x:476,y:693,t:1527873360239};\\\", \\\"{x:477,y:693,t:1527873360255};\\\", \\\"{x:477,y:694,t:1527873360271};\\\", \\\"{x:479,y:696,t:1527873360288};\\\", \\\"{x:479,y:698,t:1527873360305};\\\", \\\"{x:481,y:701,t:1527873360322};\\\", \\\"{x:481,y:703,t:1527873360338};\\\", \\\"{x:482,y:705,t:1527873360355};\\\", \\\"{x:484,y:708,t:1527873360372};\\\", \\\"{x:485,y:709,t:1527873360389};\\\", \\\"{x:485,y:711,t:1527873360405};\\\", \\\"{x:486,y:713,t:1527873360422};\\\", \\\"{x:486,y:714,t:1527873360439};\\\", \\\"{x:487,y:716,t:1527873360456};\\\", \\\"{x:488,y:717,t:1527873360472};\\\", \\\"{x:488,y:718,t:1527873360488};\\\", \\\"{x:488,y:719,t:1527873360520};\\\", \\\"{x:488,y:720,t:1527873360536};\\\", \\\"{x:488,y:721,t:1527873360551};\\\", \\\"{x:489,y:722,t:1527873360575};\\\", \\\"{x:489,y:723,t:1527873360599};\\\", \\\"{x:489,y:724,t:1527873360608};\\\", \\\"{x:490,y:724,t:1527873360624};\\\", \\\"{x:490,y:725,t:1527873360637};\\\", \\\"{x:490,y:726,t:1527873360672};\\\", \\\"{x:491,y:727,t:1527873360712};\\\", \\\"{x:491,y:728,t:1527873361136};\\\", \\\"{x:491,y:729,t:1527873361159};\\\", \\\"{x:491,y:730,t:1527873361175};\\\", \\\"{x:493,y:730,t:1527873361952};\\\", \\\"{x:494,y:730,t:1527873361992};\\\", \\\"{x:495,y:730,t:1527873362016};\\\", \\\"{x:496,y:730,t:1527873362104};\\\", \\\"{x:497,y:730,t:1527873362903};\\\", \\\"{x:497,y:731,t:1527873363888};\\\", \\\"{x:499,y:731,t:1527873363936};\\\", \\\"{x:500,y:731,t:1527873363951};\\\", \\\"{x:502,y:731,t:1527873363975};\\\", \\\"{x:503,y:731,t:1527873364279};\\\", \\\"{x:503,y:732,t:1527873365079};\\\", \\\"{x:504,y:733,t:1527873365092};\\\", \\\"{x:503,y:733,t:1527873365119};\\\", \\\"{x:502,y:734,t:1527873365135};\\\" ] }, { \\\"rt\\\": 39441, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 19, \\\"time_elapsed\\\": 596560, \\\"internal_node_id\\\": \\\"0.0-6.0-9.0\\\", \\\"subject\\\": \\\"2OEC4\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"whiskey\\\", \\\"condition\\\": \\\"115\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"midpoint\\\", \\\"q\\\": 15, \\\"clicks\\\": 2, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XFull-YFull\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 1, \\\"answer\\\": [ \\\"E\\\", \\\"F\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-F \\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:502,y:735,t:1527873366119};\\\", \\\"{x:502,y:737,t:1527873366135};\\\", \\\"{x:502,y:736,t:1527873366305};\\\", \\\"{x:503,y:734,t:1527873366353};\\\", \\\"{x:503,y:733,t:1527873366361};\\\", \\\"{x:504,y:727,t:1527873366376};\\\", \\\"{x:504,y:724,t:1527873366393};\\\", \\\"{x:504,y:723,t:1527873366410};\\\", \\\"{x:506,y:722,t:1527873366728};\\\", \\\"{x:510,y:718,t:1527873366742};\\\", \\\"{x:515,y:706,t:1527873366759};\\\", \\\"{x:520,y:698,t:1527873366777};\\\", \\\"{x:525,y:688,t:1527873366793};\\\", \\\"{x:530,y:680,t:1527873366810};\\\", \\\"{x:535,y:673,t:1527873366827};\\\", \\\"{x:540,y:665,t:1527873366843};\\\", \\\"{x:546,y:658,t:1527873366860};\\\", \\\"{x:548,y:651,t:1527873366876};\\\", \\\"{x:550,y:651,t:1527873367056};\\\", \\\"{x:557,y:651,t:1527873367063};\\\", \\\"{x:566,y:651,t:1527873367077};\\\", \\\"{x:574,y:649,t:1527873367093};\\\", \\\"{x:582,y:645,t:1527873367110};\\\", \\\"{x:595,y:640,t:1527873367127};\\\", \\\"{x:605,y:632,t:1527873367143};\\\", \\\"{x:613,y:622,t:1527873367159};\\\", \\\"{x:618,y:615,t:1527873367177};\\\", \\\"{x:623,y:609,t:1527873367194};\\\", \\\"{x:628,y:602,t:1527873367210};\\\", \\\"{x:632,y:597,t:1527873367227};\\\", \\\"{x:635,y:589,t:1527873367244};\\\", \\\"{x:638,y:584,t:1527873367260};\\\", \\\"{x:640,y:578,t:1527873367277};\\\", \\\"{x:642,y:575,t:1527873367294};\\\", \\\"{x:643,y:574,t:1527873367309};\\\", \\\"{x:643,y:573,t:1527873367327};\\\", \\\"{x:643,y:571,t:1527873367344};\\\", \\\"{x:643,y:570,t:1527873367623};\\\", \\\"{x:641,y:571,t:1527873367744};\\\", \\\"{x:640,y:571,t:1527873367775};\\\", \\\"{x:639,y:572,t:1527873367783};\\\", \\\"{x:638,y:573,t:1527873367799};\\\", \\\"{x:637,y:574,t:1527873367831};\\\", \\\"{x:636,y:574,t:1527873367845};\\\", \\\"{x:635,y:575,t:1527873367862};\\\", \\\"{x:635,y:576,t:1527873367878};\\\", \\\"{x:633,y:577,t:1527873367904};\\\", \\\"{x:632,y:579,t:1527873367943};\\\", \\\"{x:632,y:580,t:1527873367967};\\\", \\\"{x:631,y:582,t:1527873367983};\\\", \\\"{x:630,y:583,t:1527873367994};\\\", \\\"{x:629,y:584,t:1527873368011};\\\", \\\"{x:629,y:585,t:1527873368028};\\\", \\\"{x:627,y:588,t:1527873368044};\\\", \\\"{x:627,y:589,t:1527873368061};\\\", \\\"{x:626,y:591,t:1527873368078};\\\", \\\"{x:625,y:593,t:1527873368094};\\\", \\\"{x:624,y:596,t:1527873368111};\\\", \\\"{x:623,y:597,t:1527873368135};\\\", \\\"{x:623,y:598,t:1527873368144};\\\", \\\"{x:623,y:599,t:1527873368160};\\\", \\\"{x:622,y:600,t:1527873368178};\\\", \\\"{x:622,y:601,t:1527873368194};\\\", \\\"{x:621,y:602,t:1527873368212};\\\", \\\"{x:621,y:604,t:1527873368228};\\\", \\\"{x:620,y:605,t:1527873368244};\\\", \\\"{x:620,y:607,t:1527873368261};\\\", \\\"{x:620,y:608,t:1527873368432};\\\", \\\"{x:619,y:608,t:1527873368444};\\\", \\\"{x:619,y:607,t:1527873368584};\\\", \\\"{x:620,y:606,t:1527873368599};\\\", \\\"{x:620,y:605,t:1527873368615};\\\", \\\"{x:620,y:604,t:1527873368655};\\\", \\\"{x:620,y:603,t:1527873368671};\\\", \\\"{x:621,y:602,t:1527873368687};\\\", \\\"{x:621,y:601,t:1527873368728};\\\", \\\"{x:623,y:601,t:1527873370160};\\\", \\\"{x:624,y:602,t:1527873370191};\\\", \\\"{x:627,y:603,t:1527873370199};\\\", \\\"{x:629,y:605,t:1527873370215};\\\", \\\"{x:630,y:605,t:1527873370392};\\\", \\\"{x:632,y:605,t:1527873370399};\\\", \\\"{x:633,y:604,t:1527873370411};\\\", \\\"{x:635,y:601,t:1527873370429};\\\", \\\"{x:638,y:597,t:1527873370446};\\\", \\\"{x:640,y:596,t:1527873370462};\\\", \\\"{x:642,y:596,t:1527873370479};\\\", \\\"{x:643,y:596,t:1527873370496};\\\", \\\"{x:645,y:596,t:1527873370513};\\\", \\\"{x:648,y:596,t:1527873370530};\\\", \\\"{x:652,y:597,t:1527873370546};\\\", \\\"{x:656,y:598,t:1527873370563};\\\", \\\"{x:658,y:598,t:1527873370580};\\\", \\\"{x:658,y:600,t:1527873372047};\\\", \\\"{x:664,y:599,t:1527873382047};\\\", \\\"{x:672,y:591,t:1527873382055};\\\", \\\"{x:685,y:574,t:1527873382072};\\\", \\\"{x:700,y:554,t:1527873382089};\\\", \\\"{x:713,y:539,t:1527873382105};\\\", \\\"{x:726,y:521,t:1527873382122};\\\", \\\"{x:733,y:510,t:1527873382139};\\\", \\\"{x:734,y:506,t:1527873382156};\\\", \\\"{x:734,y:502,t:1527873382172};\\\", \\\"{x:734,y:501,t:1527873382190};\\\", \\\"{x:734,y:499,t:1527873382206};\\\", \\\"{x:734,y:498,t:1527873382223};\\\", \\\"{x:734,y:497,t:1527873382239};\\\", \\\"{x:734,y:496,t:1527873382255};\\\", \\\"{x:735,y:496,t:1527873382279};\\\", \\\"{x:745,y:494,t:1527873382289};\\\", \\\"{x:769,y:491,t:1527873382306};\\\", \\\"{x:803,y:491,t:1527873382323};\\\", \\\"{x:848,y:491,t:1527873382339};\\\", \\\"{x:888,y:499,t:1527873382356};\\\", \\\"{x:928,y:508,t:1527873382372};\\\", \\\"{x:981,y:522,t:1527873382389};\\\", \\\"{x:1031,y:528,t:1527873382405};\\\", \\\"{x:1082,y:536,t:1527873382423};\\\", \\\"{x:1151,y:540,t:1527873382438};\\\", \\\"{x:1176,y:542,t:1527873382455};\\\", \\\"{x:1188,y:543,t:1527873382472};\\\", \\\"{x:1200,y:547,t:1527873382489};\\\", \\\"{x:1208,y:549,t:1527873382506};\\\", \\\"{x:1218,y:553,t:1527873382522};\\\", \\\"{x:1226,y:556,t:1527873382539};\\\", \\\"{x:1235,y:560,t:1527873382556};\\\", \\\"{x:1246,y:567,t:1527873382572};\\\", \\\"{x:1256,y:572,t:1527873382589};\\\", \\\"{x:1266,y:579,t:1527873382607};\\\", \\\"{x:1273,y:585,t:1527873382623};\\\", \\\"{x:1283,y:598,t:1527873382639};\\\", \\\"{x:1293,y:610,t:1527873382657};\\\", \\\"{x:1306,y:634,t:1527873382672};\\\", \\\"{x:1318,y:662,t:1527873382690};\\\", \\\"{x:1335,y:694,t:1527873382706};\\\", \\\"{x:1341,y:708,t:1527873382723};\\\", \\\"{x:1345,y:716,t:1527873382739};\\\", \\\"{x:1346,y:720,t:1527873382757};\\\", \\\"{x:1349,y:722,t:1527873382772};\\\", \\\"{x:1352,y:724,t:1527873382790};\\\", \\\"{x:1354,y:725,t:1527873382807};\\\", \\\"{x:1357,y:725,t:1527873382822};\\\", \\\"{x:1358,y:725,t:1527873382839};\\\", \\\"{x:1358,y:722,t:1527873382903};\\\", \\\"{x:1358,y:721,t:1527873382910};\\\", \\\"{x:1358,y:720,t:1527873382922};\\\", \\\"{x:1358,y:717,t:1527873382939};\\\", \\\"{x:1358,y:716,t:1527873382956};\\\", \\\"{x:1358,y:714,t:1527873382972};\\\", \\\"{x:1358,y:713,t:1527873382991};\\\", \\\"{x:1358,y:712,t:1527873383006};\\\", \\\"{x:1358,y:711,t:1527873383023};\\\", \\\"{x:1358,y:708,t:1527873383039};\\\", \\\"{x:1358,y:707,t:1527873383056};\\\", \\\"{x:1358,y:706,t:1527873383073};\\\", \\\"{x:1358,y:705,t:1527873383127};\\\", \\\"{x:1358,y:703,t:1527873383151};\\\", \\\"{x:1358,y:702,t:1527873383223};\\\", \\\"{x:1357,y:701,t:1527873383247};\\\", \\\"{x:1357,y:700,t:1527873383263};\\\", \\\"{x:1356,y:699,t:1527873383279};\\\", \\\"{x:1354,y:698,t:1527873383289};\\\", \\\"{x:1351,y:696,t:1527873383307};\\\", \\\"{x:1348,y:695,t:1527873383324};\\\", \\\"{x:1347,y:695,t:1527873383687};\\\", \\\"{x:1346,y:695,t:1527873383743};\\\", \\\"{x:1345,y:696,t:1527873383767};\\\", \\\"{x:1339,y:696,t:1527873394160};\\\", \\\"{x:1303,y:671,t:1527873394167};\\\", \\\"{x:1235,y:636,t:1527873394178};\\\", \\\"{x:1087,y:560,t:1527873394194};\\\", \\\"{x:982,y:491,t:1527873394210};\\\", \\\"{x:917,y:437,t:1527873394228};\\\", \\\"{x:833,y:398,t:1527873394245};\\\", \\\"{x:754,y:377,t:1527873394260};\\\", \\\"{x:690,y:369,t:1527873394278};\\\", \\\"{x:631,y:369,t:1527873394294};\\\", \\\"{x:606,y:375,t:1527873394310};\\\", \\\"{x:587,y:384,t:1527873394327};\\\", \\\"{x:573,y:394,t:1527873394344};\\\", \\\"{x:562,y:404,t:1527873394361};\\\", \\\"{x:552,y:409,t:1527873394378};\\\", \\\"{x:544,y:414,t:1527873394394};\\\", \\\"{x:537,y:426,t:1527873394411};\\\", \\\"{x:531,y:441,t:1527873394428};\\\", \\\"{x:524,y:459,t:1527873394445};\\\", \\\"{x:518,y:471,t:1527873394461};\\\", \\\"{x:511,y:480,t:1527873394477};\\\", \\\"{x:506,y:486,t:1527873394494};\\\", \\\"{x:504,y:489,t:1527873394511};\\\", \\\"{x:503,y:492,t:1527873394528};\\\", \\\"{x:500,y:500,t:1527873394544};\\\", \\\"{x:498,y:505,t:1527873394561};\\\", \\\"{x:494,y:509,t:1527873394578};\\\", \\\"{x:487,y:514,t:1527873394600};\\\", \\\"{x:478,y:517,t:1527873394615};\\\", \\\"{x:461,y:517,t:1527873394633};\\\", \\\"{x:433,y:517,t:1527873394648};\\\", \\\"{x:402,y:514,t:1527873394666};\\\", \\\"{x:371,y:514,t:1527873394683};\\\", \\\"{x:349,y:514,t:1527873394699};\\\", \\\"{x:338,y:514,t:1527873394716};\\\", \\\"{x:334,y:514,t:1527873394732};\\\", \\\"{x:331,y:514,t:1527873394749};\\\", \\\"{x:331,y:512,t:1527873394765};\\\", \\\"{x:331,y:509,t:1527873394782};\\\", \\\"{x:332,y:512,t:1527873394999};\\\", \\\"{x:335,y:513,t:1527873395015};\\\", \\\"{x:343,y:516,t:1527873395031};\\\", \\\"{x:352,y:521,t:1527873395049};\\\", \\\"{x:360,y:524,t:1527873395065};\\\", \\\"{x:368,y:527,t:1527873395081};\\\", \\\"{x:376,y:532,t:1527873395099};\\\", \\\"{x:387,y:541,t:1527873395116};\\\", \\\"{x:400,y:551,t:1527873395133};\\\", \\\"{x:413,y:561,t:1527873395149};\\\", \\\"{x:430,y:575,t:1527873395168};\\\", \\\"{x:437,y:585,t:1527873395183};\\\", \\\"{x:443,y:592,t:1527873395200};\\\", \\\"{x:450,y:599,t:1527873395217};\\\", \\\"{x:456,y:604,t:1527873395233};\\\", \\\"{x:462,y:607,t:1527873395250};\\\", \\\"{x:468,y:608,t:1527873395267};\\\", \\\"{x:477,y:609,t:1527873395283};\\\", \\\"{x:488,y:609,t:1527873395300};\\\", \\\"{x:503,y:609,t:1527873395316};\\\", \\\"{x:515,y:609,t:1527873395333};\\\", \\\"{x:530,y:609,t:1527873395350};\\\", \\\"{x:548,y:609,t:1527873395366};\\\", \\\"{x:574,y:609,t:1527873395383};\\\", \\\"{x:592,y:606,t:1527873395400};\\\", \\\"{x:611,y:603,t:1527873395416};\\\", \\\"{x:629,y:598,t:1527873395434};\\\", \\\"{x:645,y:593,t:1527873395450};\\\", \\\"{x:656,y:589,t:1527873395466};\\\", \\\"{x:666,y:585,t:1527873395483};\\\", \\\"{x:674,y:582,t:1527873395500};\\\", \\\"{x:681,y:579,t:1527873395517};\\\", \\\"{x:686,y:577,t:1527873395534};\\\", \\\"{x:695,y:573,t:1527873395550};\\\", \\\"{x:710,y:567,t:1527873395566};\\\", \\\"{x:722,y:566,t:1527873395584};\\\", \\\"{x:733,y:561,t:1527873395600};\\\", \\\"{x:741,y:558,t:1527873395617};\\\", \\\"{x:743,y:556,t:1527873395633};\\\", \\\"{x:741,y:554,t:1527873395650};\\\", \\\"{x:732,y:554,t:1527873395667};\\\", \\\"{x:720,y:554,t:1527873395684};\\\", \\\"{x:710,y:554,t:1527873395700};\\\", \\\"{x:702,y:554,t:1527873395717};\\\", \\\"{x:694,y:554,t:1527873395734};\\\", \\\"{x:690,y:555,t:1527873395750};\\\", \\\"{x:686,y:556,t:1527873395767};\\\", \\\"{x:683,y:557,t:1527873395784};\\\", \\\"{x:682,y:558,t:1527873395800};\\\", \\\"{x:681,y:558,t:1527873395817};\\\", \\\"{x:680,y:559,t:1527873395887};\\\", \\\"{x:679,y:560,t:1527873396119};\\\", \\\"{x:679,y:561,t:1527873396135};\\\", \\\"{x:679,y:563,t:1527873396150};\\\", \\\"{x:681,y:565,t:1527873396166};\\\", \\\"{x:682,y:567,t:1527873396183};\\\", \\\"{x:684,y:568,t:1527873396201};\\\", \\\"{x:684,y:569,t:1527873396216};\\\", \\\"{x:685,y:570,t:1527873396234};\\\", \\\"{x:686,y:571,t:1527873396251};\\\", \\\"{x:687,y:571,t:1527873396267};\\\", \\\"{x:689,y:572,t:1527873396284};\\\", \\\"{x:690,y:572,t:1527873396301};\\\", \\\"{x:692,y:572,t:1527873396343};\\\", \\\"{x:693,y:572,t:1527873396366};\\\", \\\"{x:695,y:572,t:1527873396391};\\\", \\\"{x:696,y:572,t:1527873396401};\\\", \\\"{x:699,y:572,t:1527873396418};\\\", \\\"{x:701,y:572,t:1527873396434};\\\", \\\"{x:703,y:571,t:1527873396450};\\\", \\\"{x:704,y:570,t:1527873396467};\\\", \\\"{x:706,y:570,t:1527873396483};\\\", \\\"{x:708,y:569,t:1527873396501};\\\", \\\"{x:711,y:567,t:1527873396518};\\\", \\\"{x:713,y:566,t:1527873396534};\\\", \\\"{x:718,y:565,t:1527873396550};\\\", \\\"{x:722,y:565,t:1527873396568};\\\", \\\"{x:727,y:565,t:1527873396584};\\\", \\\"{x:731,y:565,t:1527873396601};\\\", \\\"{x:735,y:565,t:1527873396618};\\\", \\\"{x:739,y:565,t:1527873396633};\\\", \\\"{x:744,y:565,t:1527873396651};\\\", \\\"{x:747,y:565,t:1527873396668};\\\", \\\"{x:751,y:565,t:1527873396683};\\\", \\\"{x:756,y:565,t:1527873396701};\\\", \\\"{x:763,y:565,t:1527873396718};\\\", \\\"{x:769,y:565,t:1527873396734};\\\", \\\"{x:781,y:565,t:1527873396751};\\\", \\\"{x:789,y:565,t:1527873396768};\\\", \\\"{x:800,y:565,t:1527873396784};\\\", \\\"{x:810,y:565,t:1527873396801};\\\", \\\"{x:818,y:565,t:1527873396818};\\\", \\\"{x:827,y:563,t:1527873396834};\\\", \\\"{x:833,y:563,t:1527873396851};\\\", \\\"{x:839,y:562,t:1527873396868};\\\", \\\"{x:843,y:561,t:1527873396885};\\\", \\\"{x:845,y:560,t:1527873396901};\\\", \\\"{x:847,y:559,t:1527873396918};\\\", \\\"{x:848,y:557,t:1527873396934};\\\", \\\"{x:848,y:554,t:1527873396950};\\\", \\\"{x:849,y:552,t:1527873396968};\\\", \\\"{x:850,y:547,t:1527873396984};\\\", \\\"{x:850,y:544,t:1527873397001};\\\", \\\"{x:850,y:539,t:1527873397018};\\\", \\\"{x:850,y:536,t:1527873397035};\\\", \\\"{x:850,y:534,t:1527873397051};\\\", \\\"{x:851,y:532,t:1527873397068};\\\", \\\"{x:851,y:531,t:1527873397085};\\\", \\\"{x:851,y:530,t:1527873397101};\\\", \\\"{x:851,y:529,t:1527873397191};\\\", \\\"{x:851,y:528,t:1527873397207};\\\", \\\"{x:851,y:526,t:1527873397218};\\\", \\\"{x:850,y:525,t:1527873397234};\\\", \\\"{x:848,y:525,t:1527873397251};\\\", \\\"{x:847,y:525,t:1527873397268};\\\", \\\"{x:845,y:525,t:1527873403759};\\\", \\\"{x:837,y:527,t:1527873403772};\\\", \\\"{x:818,y:532,t:1527873403790};\\\", \\\"{x:782,y:529,t:1527873403806};\\\", \\\"{x:731,y:521,t:1527873403822};\\\", \\\"{x:691,y:515,t:1527873403841};\\\", \\\"{x:667,y:507,t:1527873403857};\\\", \\\"{x:655,y:503,t:1527873403873};\\\", \\\"{x:648,y:499,t:1527873403891};\\\", \\\"{x:643,y:496,t:1527873403907};\\\", \\\"{x:642,y:495,t:1527873403923};\\\", \\\"{x:641,y:495,t:1527873403940};\\\", \\\"{x:642,y:497,t:1527873403975};\\\", \\\"{x:643,y:500,t:1527873403990};\\\", \\\"{x:644,y:508,t:1527873404007};\\\", \\\"{x:641,y:513,t:1527873404024};\\\", \\\"{x:632,y:518,t:1527873404040};\\\", \\\"{x:619,y:523,t:1527873404057};\\\", \\\"{x:605,y:529,t:1527873404074};\\\", \\\"{x:598,y:535,t:1527873404090};\\\", \\\"{x:596,y:536,t:1527873404107};\\\", \\\"{x:595,y:536,t:1527873404124};\\\", \\\"{x:595,y:535,t:1527873404239};\\\", \\\"{x:595,y:534,t:1527873404246};\\\", \\\"{x:595,y:533,t:1527873404257};\\\", \\\"{x:595,y:532,t:1527873404274};\\\", \\\"{x:595,y:531,t:1527873404292};\\\", \\\"{x:595,y:530,t:1527873404307};\\\", \\\"{x:596,y:528,t:1527873404351};\\\", \\\"{x:597,y:528,t:1527873404398};\\\", \\\"{x:598,y:528,t:1527873404414};\\\", \\\"{x:601,y:526,t:1527873404423};\\\", \\\"{x:603,y:525,t:1527873404439};\\\", \\\"{x:605,y:525,t:1527873404457};\\\", \\\"{x:606,y:525,t:1527873404474};\\\", \\\"{x:607,y:525,t:1527873404491};\\\", \\\"{x:607,y:524,t:1527873404507};\\\", \\\"{x:608,y:524,t:1527873404534};\\\", \\\"{x:608,y:525,t:1527873404759};\\\", \\\"{x:608,y:533,t:1527873404774};\\\", \\\"{x:608,y:544,t:1527873404792};\\\", \\\"{x:608,y:563,t:1527873404807};\\\", \\\"{x:608,y:578,t:1527873404825};\\\", \\\"{x:605,y:596,t:1527873404841};\\\", \\\"{x:600,y:618,t:1527873404858};\\\", \\\"{x:598,y:638,t:1527873404874};\\\", \\\"{x:595,y:653,t:1527873404891};\\\", \\\"{x:593,y:663,t:1527873404909};\\\", \\\"{x:587,y:680,t:1527873404924};\\\", \\\"{x:581,y:694,t:1527873404941};\\\", \\\"{x:573,y:707,t:1527873404959};\\\", \\\"{x:566,y:717,t:1527873404974};\\\", \\\"{x:556,y:731,t:1527873404991};\\\", \\\"{x:552,y:738,t:1527873405009};\\\", \\\"{x:548,y:744,t:1527873405024};\\\", \\\"{x:543,y:751,t:1527873405041};\\\", \\\"{x:540,y:754,t:1527873405058};\\\", \\\"{x:539,y:755,t:1527873405074};\\\", \\\"{x:539,y:756,t:1527873405694};\\\", \\\"{x:539,y:757,t:1527873405718};\\\", \\\"{x:539,y:758,t:1527873405734};\\\", \\\"{x:540,y:758,t:1527873405758};\\\", \\\"{x:541,y:758,t:1527873405776};\\\", \\\"{x:542,y:757,t:1527873405791};\\\", \\\"{x:543,y:757,t:1527873405838};\\\", \\\"{x:544,y:757,t:1527873405846};\\\", \\\"{x:546,y:757,t:1527873405862};\\\", \\\"{x:547,y:757,t:1527873405875};\\\", \\\"{x:548,y:757,t:1527873405902};\\\", \\\"{x:549,y:757,t:1527873405910};\\\", \\\"{x:550,y:757,t:1527873405925};\\\", \\\"{x:551,y:758,t:1527873405942};\\\", \\\"{x:551,y:759,t:1527873405990};\\\" ] }, { \\\"rt\\\": 48966, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 20, \\\"time_elapsed\\\": 646769, \\\"internal_node_id\\\": \\\"0.0-7.0-0.0\\\", \\\"subject\\\": \\\"2OEC4\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"whiskey\\\", \\\"condition\\\": \\\"115\\\", \\\"q\\\": 16, \\\"answer\\\": \\\"I go to the 12PM on the x-axis and then see if there are any dots on the y-axis centered at 12PM.\\\", \\\"block\\\": \\\"triangular_testing\\\" }, { \\\"rt\\\": 9867, \\\"responses\\\": \\\"{\\\\\\\"Q0\\\\\\\":\\\\\\\"20\\\\\\\",\\\\\\\"Q1\\\\\\\":\\\\\\\"Panama\\\\\\\"}\\\", \\\"block\\\": \\\"demo-1\\\", \\\"trial_type\\\": \\\"survey-text\\\", \\\"trial_index\\\": 21, \\\"time_elapsed\\\": 657642, \\\"internal_node_id\\\": \\\"0.0-8.0\\\", \\\"subject\\\": \\\"2OEC4\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"whiskey\\\", \\\"condition\\\": \\\"115\\\" }, { \\\"rt\\\": 9415, \\\"responses\\\": \\\"{\\\\\\\"Q0\\\\\\\":\\\\\\\"Other\\\\\\\",\\\\\\\"Q1\\\\\\\":\\\\\\\"Second\\\\\\\",\\\\\\\"Q2\\\\\\\":\\\\\\\"Math or Computer Sciences\\\\\\\",\\\\\\\"Q3\\\\\\\":\\\\\\\"Male\\\\\\\"}\\\", \\\"block\\\": \\\"demo-2\\\", \\\"trial_type\\\": \\\"survey-multi-choice\\\", \\\"trial_index\\\": 22, \\\"time_elapsed\\\": 668081, \\\"internal_node_id\\\": \\\"0.0-9.0\\\", \\\"subject\\\": \\\"2OEC4\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"whiskey\\\", \\\"condition\\\": \\\"115\\\" }, { \\\"rt\\\": 2379, \\\"url\\\": \\\"../views/src/external/debrief.html\\\", \\\"block\\\": \\\"debrief\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 23, \\\"time_elapsed\\\": 671846, \\\"internal_node_id\\\": \\\"0.0-10.0\\\", \\\"subject\\\": \\\"2OEC4\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"whiskey\\\", \\\"condition\\\": \\\"115\\\" } ]\",\"parentNode\":{\"id\":2765}}],[],[]]}"
    }
  ],
  "initialDom": "{\"f\":\"initialize\",\"args\":[1,[{\"nodeType\":10,\"id\":2,\"name\":\"html\",\"publicId\":\"\",\"systemId\":\"\"},{\"nodeType\":1,\"id\":3,\"tagName\":\"HTML\",\"attributes\":{\"class\":\"fa-events-icons-ready\"},\"childNodes\":[{\"nodeType\":1,\"id\":4,\"tagName\":\"HEAD\",\"attributes\":{},\"childNodes\":[{\"nodeType\":3,\"id\":5,\"textContent\":\" \"},{\"nodeType\":1,\"id\":6,\"tagName\":\"TITLE\",\"attributes\":{},\"childNodes\":[{\"nodeType\":3,\"id\":7,\"textContent\":\"FOX2YP\"}]},{\"nodeType\":3,\"id\":8,\"textContent\":\" \"},{\"nodeType\":8,\"id\":9},{\"nodeType\":3,\"id\":10,\"textContent\":\" \"},{\"nodeType\":1,\"id\":11,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":12,\"textContent\":\" \"},{\"nodeType\":1,\"id\":13,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":14,\"textContent\":\" \"},{\"nodeType\":1,\"id\":15,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":16,\"textContent\":\" \"},{\"nodeType\":1,\"id\":17,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":18,\"textContent\":\" \"},{\"nodeType\":1,\"id\":19,\"tagName\":\"SCRIPT\"},{\"nodeType\":1,\"id\":20,\"tagName\":\"LINK\",\"attributes\":{\"href\":\"https://use.fontawesome.com/945539d961.css\",\"media\":\"all\",\"rel\":\"stylesheet\"}},{\"nodeType\":3,\"id\":21,\"textContent\":\" \"},{\"nodeType\":8,\"id\":22},{\"nodeType\":3,\"id\":23,\"textContent\":\" \"},{\"nodeType\":1,\"id\":24,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":25,\"textContent\":\" \"},{\"nodeType\":1,\"id\":26,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":27,\"textContent\":\" \"},{\"nodeType\":1,\"id\":28,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":29,\"textContent\":\" \"},{\"nodeType\":1,\"id\":30,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":31,\"textContent\":\" \"},{\"nodeType\":1,\"id\":32,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":33,\"textContent\":\" \"},{\"nodeType\":1,\"id\":34,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":35,\"textContent\":\" \"},{\"nodeType\":1,\"id\":36,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":37,\"textContent\":\" \"},{\"nodeType\":8,\"id\":38},{\"nodeType\":3,\"id\":39,\"textContent\":\" \"},{\"nodeType\":1,\"id\":40,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":41,\"textContent\":\" \"},{\"nodeType\":8,\"id\":42},{\"nodeType\":3,\"id\":43,\"textContent\":\" \"},{\"nodeType\":8,\"id\":44},{\"nodeType\":3,\"id\":45,\"textContent\":\" \"},{\"nodeType\":1,\"id\":46,\"tagName\":\"LINK\",\"attributes\":{\"href\":\"../views/jsPsych/css/jspsych.css\",\"rel\":\"stylesheet\",\"type\":\"text/css\"}},{\"nodeType\":3,\"id\":47,\"textContent\":\" \"},{\"nodeType\":1,\"id\":48,\"tagName\":\"LINK\",\"attributes\":{\"href\":\"../css/styles.css\",\"rel\":\"stylesheet\",\"type\":\"text/css\"}},{\"nodeType\":3,\"id\":49,\"textContent\":\" \"},{\"nodeType\":1,\"id\":50,\"tagName\":\"SCRIPT\"},{\"nodeType\":1,\"id\":51,\"tagName\":\"SCRIPT\"}]},{\"nodeType\":3,\"id\":52,\"textContent\":\" \"},{\"nodeType\":8,\"id\":53},{\"nodeType\":3,\"id\":54,\"textContent\":\" \"},{\"nodeType\":1,\"id\":55,\"tagName\":\"BODY\",\"attributes\":{\"class\":\"jspsych-display-element\"},\"childNodes\":[{\"nodeType\":3,\"id\":56,\"textContent\":\" \"},{\"nodeType\":1,\"id\":57,\"tagName\":\"META\",\"attributes\":{\"charset\":\"utf-8\"}},{\"nodeType\":3,\"id\":58,\"textContent\":\" \"},{\"nodeType\":8,\"id\":59},{\"nodeType\":3,\"id\":60,\"textContent\":\" \"},{\"nodeType\":1,\"id\":61,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":62,\"textContent\":\" \"},{\"nodeType\":1,\"id\":63,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":64,\"textContent\":\" \"},{\"nodeType\":1,\"id\":65,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":66,\"textContent\":\" \"},{\"nodeType\":1,\"id\":67,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":68,\"textContent\":\" \"},{\"nodeType\":1,\"id\":69,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":70,\"textContent\":\" \"},{\"nodeType\":1,\"id\":71,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":72,\"textContent\":\" \"},{\"nodeType\":1,\"id\":73,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"stimulus\"},\"childNodes\":[{\"nodeType\":3,\"id\":74,\"textContent\":\" \"},{\"nodeType\":1,\"id\":75,\"tagName\":\"P\",\"attributes\":{\"class\":\"userid\",\"id\":\"userid\"},\"childNodes\":[{\"nodeType\":3,\"id\":76,\"textContent\":\"2OEC4\"}]},{\"nodeType\":3,\"id\":77,\"textContent\":\" \"},{\"nodeType\":1,\"id\":78,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"userinput\"},\"childNodes\":[{\"nodeType\":3,\"id\":79,\"textContent\":\" \"},{\"nodeType\":8,\"id\":80},{\"nodeType\":3,\"id\":81,\"textContent\":\" \"},{\"nodeType\":1,\"id\":82,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"legend\",\"id\":\"hint-interactive\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":83,\"textContent\":\" \"},{\"nodeType\":1,\"id\":84,\"tagName\":\"P\",\"attributes\":{},\"childNodes\":[{\"nodeType\":3,\"id\":85,\"textContent\":\"Hint: Hover your mouse over the data points in the graph\"}]},{\"nodeType\":3,\"id\":86,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":87,\"textContent\":\" \"},{\"nodeType\":8,\"id\":88},{\"nodeType\":3,\"id\":89,\"textContent\":\" \"},{\"nodeType\":8,\"id\":90},{\"nodeType\":3,\"id\":91,\"textContent\":\" \"},{\"nodeType\":1,\"id\":92,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"test\"},\"childNodes\":[{\"nodeType\":3,\"id\":93,\"textContent\":\" \"},{\"nodeType\":1,\"id\":94,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"acme\",\"id\":\"acme.starttime\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":95,\"textContent\":\" \"},{\"nodeType\":1,\"id\":96,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":97,\"textContent\":\"Which shift(s) start at 11 am? \"}]},{\"nodeType\":3,\"id\":98,\"textContent\":\" \"},{\"nodeType\":1,\"id\":99,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":100,\"textContent\":\" \"},{\"nodeType\":1,\"id\":101,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":102,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":103,\"textContent\":\" \"},{\"nodeType\":1,\"id\":104,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":105,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":106,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":107,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":108,\"textContent\":\" \"},{\"nodeType\":1,\"id\":109,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":110,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":111,\"textContent\":\" \"},{\"nodeType\":1,\"id\":112,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":113,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":114,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":115,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":116,\"textContent\":\" \"},{\"nodeType\":1,\"id\":117,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":118,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":119,\"textContent\":\" \"},{\"nodeType\":1,\"id\":120,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":121,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":122,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":123,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":124,\"textContent\":\" \"},{\"nodeType\":1,\"id\":125,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":126,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":127,\"textContent\":\" \"},{\"nodeType\":1,\"id\":128,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":129,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":130,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":131,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":132,\"textContent\":\" \"},{\"nodeType\":1,\"id\":133,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":134,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":135,\"textContent\":\" \"},{\"nodeType\":1,\"id\":136,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":137,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":138,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":139,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":140,\"textContent\":\" \"},{\"nodeType\":1,\"id\":141,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":142,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":143,\"textContent\":\" \"},{\"nodeType\":1,\"id\":144,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":145,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":146,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":147,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":148,\"textContent\":\" \"},{\"nodeType\":1,\"id\":149,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":150,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":151,\"textContent\":\" \"},{\"nodeType\":1,\"id\":152,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":153,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":154,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":155,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":156,\"textContent\":\" \"},{\"nodeType\":1,\"id\":157,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":158,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":159,\"textContent\":\" \"},{\"nodeType\":1,\"id\":160,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":161,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":162,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":163,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":164,\"textContent\":\" \"},{\"nodeType\":1,\"id\":165,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":166,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":167,\"textContent\":\" \"},{\"nodeType\":1,\"id\":168,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":169,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":170,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":171,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":172,\"textContent\":\" \"},{\"nodeType\":1,\"id\":173,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":174,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":175,\"textContent\":\" \"},{\"nodeType\":1,\"id\":176,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":177,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":178,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":179,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":180,\"textContent\":\" \"},{\"nodeType\":1,\"id\":181,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":182,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":183,\"textContent\":\" \"},{\"nodeType\":1,\"id\":184,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"U\",\"value\":\"\"}},{\"nodeType\":3,\"id\":185,\"textContent\":\"U \"},{\"nodeType\":1,\"id\":186,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":187,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":188,\"textContent\":\" \"},{\"nodeType\":1,\"id\":189,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":190,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":191,\"textContent\":\" \"},{\"nodeType\":1,\"id\":192,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":193,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":194,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":195,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":196,\"textContent\":\" \"},{\"nodeType\":1,\"id\":197,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":198,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":199,\"textContent\":\" \"},{\"nodeType\":1,\"id\":200,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":201,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":202,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":203,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":204,\"textContent\":\" \"},{\"nodeType\":1,\"id\":205,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":206,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":207,\"textContent\":\" \"},{\"nodeType\":1,\"id\":208,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":209,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":210,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":211,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":212,\"textContent\":\" \"},{\"nodeType\":1,\"id\":213,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":214,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":215,\"textContent\":\" \"},{\"nodeType\":1,\"id\":216,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":217,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":218,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":219,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":220,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":221,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":222,\"textContent\":\" \"},{\"nodeType\":1,\"id\":223,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"acme\",\"id\":\"acme.starts\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":224,\"textContent\":\" \"},{\"nodeType\":1,\"id\":225,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":226,\"textContent\":\"Which shift(s) start at the same time as D?\"}]},{\"nodeType\":3,\"id\":227,\"textContent\":\" \"},{\"nodeType\":1,\"id\":228,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":229,\"textContent\":\" \"},{\"nodeType\":1,\"id\":230,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":231,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":232,\"textContent\":\" \"},{\"nodeType\":1,\"id\":233,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":234,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":235,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":236,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":237,\"textContent\":\" \"},{\"nodeType\":1,\"id\":238,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":239,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":240,\"textContent\":\" \"},{\"nodeType\":1,\"id\":241,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":242,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":243,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":244,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":245,\"textContent\":\" \"},{\"nodeType\":1,\"id\":246,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":247,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":248,\"textContent\":\" \"},{\"nodeType\":1,\"id\":249,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":250,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":251,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":252,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":253,\"textContent\":\" \"},{\"nodeType\":1,\"id\":254,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":255,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":256,\"textContent\":\" \"},{\"nodeType\":1,\"id\":257,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":258,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":259,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":260,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":261,\"textContent\":\" \"},{\"nodeType\":1,\"id\":262,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":263,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":264,\"textContent\":\" \"},{\"nodeType\":1,\"id\":265,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":266,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":267,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":268,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":269,\"textContent\":\" \"},{\"nodeType\":1,\"id\":270,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":271,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":272,\"textContent\":\" \"},{\"nodeType\":1,\"id\":273,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":274,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":275,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":276,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":277,\"textContent\":\" \"},{\"nodeType\":1,\"id\":278,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":279,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":280,\"textContent\":\" \"},{\"nodeType\":1,\"id\":281,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":282,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":283,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":284,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":285,\"textContent\":\" \"},{\"nodeType\":1,\"id\":286,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":287,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":288,\"textContent\":\" \"},{\"nodeType\":1,\"id\":289,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":290,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":291,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":292,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":293,\"textContent\":\" \"},{\"nodeType\":1,\"id\":294,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":295,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":296,\"textContent\":\" \"},{\"nodeType\":1,\"id\":297,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":298,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":299,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":300,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":301,\"textContent\":\" \"},{\"nodeType\":1,\"id\":302,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":303,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":304,\"textContent\":\" \"},{\"nodeType\":1,\"id\":305,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":306,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":307,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":308,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":309,\"textContent\":\" \"},{\"nodeType\":1,\"id\":310,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":311,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":312,\"textContent\":\" \"},{\"nodeType\":1,\"id\":313,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"U\",\"value\":\"\"}},{\"nodeType\":3,\"id\":314,\"textContent\":\"U \"},{\"nodeType\":1,\"id\":315,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":316,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":317,\"textContent\":\" \"},{\"nodeType\":1,\"id\":318,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":319,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":320,\"textContent\":\" \"},{\"nodeType\":1,\"id\":321,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":322,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":323,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":324,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":325,\"textContent\":\" \"},{\"nodeType\":1,\"id\":326,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":327,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":328,\"textContent\":\" \"},{\"nodeType\":1,\"id\":329,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":330,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":331,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":332,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":333,\"textContent\":\" \"},{\"nodeType\":1,\"id\":334,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":335,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":336,\"textContent\":\" \"},{\"nodeType\":1,\"id\":337,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":338,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":339,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":340,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":341,\"textContent\":\" \"},{\"nodeType\":1,\"id\":342,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":343,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":344,\"textContent\":\" \"},{\"nodeType\":1,\"id\":345,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":346,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":347,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":348,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":349,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":350,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":351,\"textContent\":\" \"},{\"nodeType\":1,\"id\":352,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"acme\",\"id\":\"acme.meets\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":353,\"textContent\":\" \"},{\"nodeType\":1,\"id\":354,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":355,\"textContent\":\"Which shift(s) begin when C ends?\"}]},{\"nodeType\":3,\"id\":356,\"textContent\":\" \"},{\"nodeType\":1,\"id\":357,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":358,\"textContent\":\" \"},{\"nodeType\":1,\"id\":359,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":360,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":361,\"textContent\":\" \"},{\"nodeType\":1,\"id\":362,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":363,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":364,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":365,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":366,\"textContent\":\" \"},{\"nodeType\":1,\"id\":367,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":368,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":369,\"textContent\":\" \"},{\"nodeType\":1,\"id\":370,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":371,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":372,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":373,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":374,\"textContent\":\" \"},{\"nodeType\":1,\"id\":375,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":376,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":377,\"textContent\":\" \"},{\"nodeType\":1,\"id\":378,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":379,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":380,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":381,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":382,\"textContent\":\" \"},{\"nodeType\":1,\"id\":383,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":384,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":385,\"textContent\":\" \"},{\"nodeType\":1,\"id\":386,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":387,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":388,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":389,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":390,\"textContent\":\" \"},{\"nodeType\":1,\"id\":391,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":392,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":393,\"textContent\":\" \"},{\"nodeType\":1,\"id\":394,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":395,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":396,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":397,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":398,\"textContent\":\" \"},{\"nodeType\":1,\"id\":399,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":400,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":401,\"textContent\":\" \"},{\"nodeType\":1,\"id\":402,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":403,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":404,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":405,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":406,\"textContent\":\" \"},{\"nodeType\":1,\"id\":407,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":408,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":409,\"textContent\":\" \"},{\"nodeType\":1,\"id\":410,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":411,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":412,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":413,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":414,\"textContent\":\" \"},{\"nodeType\":1,\"id\":415,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":416,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":417,\"textContent\":\" \"},{\"nodeType\":1,\"id\":418,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":419,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":420,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":421,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":422,\"textContent\":\" \"},{\"nodeType\":1,\"id\":423,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":424,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":425,\"textContent\":\" \"},{\"nodeType\":1,\"id\":426,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":427,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":428,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":429,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":430,\"textContent\":\" \"},{\"nodeType\":1,\"id\":431,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":432,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":433,\"textContent\":\" \"},{\"nodeType\":1,\"id\":434,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":435,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":436,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":437,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":438,\"textContent\":\" \"},{\"nodeType\":1,\"id\":439,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":440,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":441,\"textContent\":\" \"},{\"nodeType\":1,\"id\":442,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"U\",\"value\":\"\"}},{\"nodeType\":3,\"id\":443,\"textContent\":\"U \"},{\"nodeType\":1,\"id\":444,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":445,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":446,\"textContent\":\" \"},{\"nodeType\":1,\"id\":447,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":448,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":449,\"textContent\":\" \"},{\"nodeType\":1,\"id\":450,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":451,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":452,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":453,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":454,\"textContent\":\" \"},{\"nodeType\":1,\"id\":455,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":456,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":457,\"textContent\":\" \"},{\"nodeType\":1,\"id\":458,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":459,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":460,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":461,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":462,\"textContent\":\" \"},{\"nodeType\":1,\"id\":463,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":464,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":465,\"textContent\":\" \"},{\"nodeType\":1,\"id\":466,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":467,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":468,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":469,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":470,\"textContent\":\" \"},{\"nodeType\":1,\"id\":471,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":472,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":473,\"textContent\":\" \"},{\"nodeType\":1,\"id\":474,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":475,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":476,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":477,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":478,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":479,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":480,\"textContent\":\" \"},{\"nodeType\":1,\"id\":481,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"acme\",\"id\":\"acme.endtime\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":482,\"textContent\":\" \"},{\"nodeType\":1,\"id\":483,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":484,\"textContent\":\" Which shift(s) end at 4 pm?\"}]},{\"nodeType\":3,\"id\":485,\"textContent\":\" \"},{\"nodeType\":1,\"id\":486,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":487,\"textContent\":\" \"},{\"nodeType\":1,\"id\":488,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":489,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":490,\"textContent\":\" \"},{\"nodeType\":1,\"id\":491,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":492,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":493,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":494,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":495,\"textContent\":\" \"},{\"nodeType\":1,\"id\":496,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":497,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":498,\"textContent\":\" \"},{\"nodeType\":1,\"id\":499,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":500,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":501,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":502,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":503,\"textContent\":\" \"},{\"nodeType\":1,\"id\":504,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":505,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":506,\"textContent\":\" \"},{\"nodeType\":1,\"id\":507,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":508,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":509,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":510,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":511,\"textContent\":\" \"},{\"nodeType\":1,\"id\":512,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":513,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":514,\"textContent\":\" \"},{\"nodeType\":1,\"id\":515,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":516,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":517,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":518,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":519,\"textContent\":\" \"},{\"nodeType\":1,\"id\":520,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":521,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":522,\"textContent\":\" \"},{\"nodeType\":1,\"id\":523,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":524,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":525,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":526,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":527,\"textContent\":\" \"},{\"nodeType\":1,\"id\":528,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":529,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":530,\"textContent\":\" \"},{\"nodeType\":1,\"id\":531,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":532,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":533,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":534,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":535,\"textContent\":\" \"},{\"nodeType\":1,\"id\":536,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":537,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":538,\"textContent\":\" \"},{\"nodeType\":1,\"id\":539,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":540,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":541,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":542,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":543,\"textContent\":\" \"},{\"nodeType\":1,\"id\":544,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":545,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":546,\"textContent\":\" \"},{\"nodeType\":1,\"id\":547,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":548,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":549,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":550,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":551,\"textContent\":\" \"},{\"nodeType\":1,\"id\":552,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":553,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":554,\"textContent\":\" \"},{\"nodeType\":1,\"id\":555,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":556,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":557,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":558,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":559,\"textContent\":\" \"},{\"nodeType\":1,\"id\":560,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":561,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":562,\"textContent\":\" \"},{\"nodeType\":1,\"id\":563,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":564,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":565,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":566,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":567,\"textContent\":\" \"},{\"nodeType\":1,\"id\":568,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":569,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":570,\"textContent\":\" \"},{\"nodeType\":1,\"id\":571,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"U\",\"value\":\"\"}},{\"nodeType\":3,\"id\":572,\"textContent\":\"U \"},{\"nodeType\":1,\"id\":573,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":574,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":575,\"textContent\":\" \"},{\"nodeType\":1,\"id\":576,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":577,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":578,\"textContent\":\" \"},{\"nodeType\":1,\"id\":579,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":580,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":581,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":582,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":583,\"textContent\":\" \"},{\"nodeType\":1,\"id\":584,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":585,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":586,\"textContent\":\" \"},{\"nodeType\":1,\"id\":587,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":588,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":589,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":590,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":591,\"textContent\":\" \"},{\"nodeType\":1,\"id\":592,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":593,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":594,\"textContent\":\" \"},{\"nodeType\":1,\"id\":595,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":596,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":597,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":598,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":599,\"textContent\":\" \"},{\"nodeType\":1,\"id\":600,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":601,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":602,\"textContent\":\" \"},{\"nodeType\":1,\"id\":603,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":604,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":605,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":606,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":607,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":608,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":609,\"textContent\":\" \"},{\"nodeType\":1,\"id\":610,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"acme\",\"id\":\"acme.midpoint\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":611,\"textContent\":\" \"},{\"nodeType\":1,\"id\":612,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":613,\"textContent\":\"Coffee breaks happen halfway through a shift.\"},{\"nodeType\":1,\"id\":614,\"tagName\":\"BR\",\"attributes\":{}},{\"nodeType\":3,\"id\":615,\"textContent\":\" Which shift(s) share a break with I?\"}]},{\"nodeType\":3,\"id\":616,\"textContent\":\" \"},{\"nodeType\":1,\"id\":617,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":618,\"textContent\":\" \"},{\"nodeType\":1,\"id\":619,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":620,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":621,\"textContent\":\" \"},{\"nodeType\":1,\"id\":622,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":623,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":624,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":625,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":626,\"textContent\":\" \"},{\"nodeType\":1,\"id\":627,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":628,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":629,\"textContent\":\" \"},{\"nodeType\":1,\"id\":630,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":631,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":632,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":633,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":634,\"textContent\":\" \"},{\"nodeType\":1,\"id\":635,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":636,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":637,\"textContent\":\" \"},{\"nodeType\":1,\"id\":638,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":639,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":640,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":641,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":642,\"textContent\":\" \"},{\"nodeType\":1,\"id\":643,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":644,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":645,\"textContent\":\" \"},{\"nodeType\":1,\"id\":646,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":647,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":648,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":649,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":650,\"textContent\":\" \"},{\"nodeType\":1,\"id\":651,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":652,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":653,\"textContent\":\" \"},{\"nodeType\":1,\"id\":654,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":655,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":656,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":657,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":658,\"textContent\":\" \"},{\"nodeType\":1,\"id\":659,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":660,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":661,\"textContent\":\" \"},{\"nodeType\":1,\"id\":662,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":663,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":664,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":665,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":666,\"textContent\":\" \"},{\"nodeType\":1,\"id\":667,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":668,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":669,\"textContent\":\" \"},{\"nodeType\":1,\"id\":670,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":671,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":672,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":673,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":674,\"textContent\":\" \"},{\"nodeType\":1,\"id\":675,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":676,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":677,\"textContent\":\" \"},{\"nodeType\":1,\"id\":678,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":679,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":680,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":681,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":682,\"textContent\":\" \"},{\"nodeType\":1,\"id\":683,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":684,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":685,\"textContent\":\" \"},{\"nodeType\":1,\"id\":686,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":687,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":688,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":689,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":690,\"textContent\":\" \"},{\"nodeType\":1,\"id\":691,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":692,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":693,\"textContent\":\" \"},{\"nodeType\":1,\"id\":694,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":695,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":696,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":697,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":698,\"textContent\":\" \"},{\"nodeType\":1,\"id\":699,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":700,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":701,\"textContent\":\" \"},{\"nodeType\":1,\"id\":702,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"U\",\"value\":\"\"}},{\"nodeType\":3,\"id\":703,\"textContent\":\"U \"},{\"nodeType\":1,\"id\":704,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":705,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":706,\"textContent\":\" \"},{\"nodeType\":1,\"id\":707,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":708,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":709,\"textContent\":\" \"},{\"nodeType\":1,\"id\":710,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":711,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":712,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":713,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":714,\"textContent\":\" \"},{\"nodeType\":1,\"id\":715,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":716,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":717,\"textContent\":\" \"},{\"nodeType\":1,\"id\":718,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":719,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":720,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":721,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":722,\"textContent\":\" \"},{\"nodeType\":1,\"id\":723,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":724,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":725,\"textContent\":\" \"},{\"nodeType\":1,\"id\":726,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":727,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":728,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":729,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":730,\"textContent\":\" \"},{\"nodeType\":1,\"id\":731,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":732,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":733,\"textContent\":\" \"},{\"nodeType\":1,\"id\":734,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":735,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":736,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":737,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":738,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":739,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":740,\"textContent\":\" \"},{\"nodeType\":1,\"id\":741,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.duration\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":742,\"textContent\":\" \"},{\"nodeType\":1,\"id\":743,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":744,\"textContent\":\"Which shift(s) are six hours long?\"}]},{\"nodeType\":3,\"id\":745,\"textContent\":\" \"},{\"nodeType\":1,\"id\":746,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":747,\"textContent\":\" \"},{\"nodeType\":1,\"id\":748,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":749,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":750,\"textContent\":\" \"},{\"nodeType\":1,\"id\":751,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":752,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":753,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":754,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":755,\"textContent\":\" \"},{\"nodeType\":1,\"id\":756,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":757,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":758,\"textContent\":\" \"},{\"nodeType\":1,\"id\":759,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":760,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":761,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":762,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":763,\"textContent\":\" \"},{\"nodeType\":1,\"id\":764,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":765,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":766,\"textContent\":\" \"},{\"nodeType\":1,\"id\":767,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":768,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":769,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":770,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":771,\"textContent\":\" \"},{\"nodeType\":1,\"id\":772,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":773,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":774,\"textContent\":\" \"},{\"nodeType\":1,\"id\":775,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":776,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":777,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":778,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":779,\"textContent\":\" \"},{\"nodeType\":1,\"id\":780,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":781,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":782,\"textContent\":\" \"},{\"nodeType\":1,\"id\":783,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":784,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":785,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":786,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":787,\"textContent\":\" \"},{\"nodeType\":1,\"id\":788,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":789,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":790,\"textContent\":\" \"},{\"nodeType\":1,\"id\":791,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":792,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":793,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":794,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":795,\"textContent\":\" \"},{\"nodeType\":1,\"id\":796,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":797,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":798,\"textContent\":\" \"},{\"nodeType\":1,\"id\":799,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":800,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":801,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":802,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":803,\"textContent\":\" \"},{\"nodeType\":1,\"id\":804,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":805,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":806,\"textContent\":\" \"},{\"nodeType\":1,\"id\":807,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":808,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":809,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":810,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":811,\"textContent\":\" \"},{\"nodeType\":1,\"id\":812,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":813,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":814,\"textContent\":\" \"},{\"nodeType\":1,\"id\":815,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":816,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":817,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":818,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":819,\"textContent\":\" \"},{\"nodeType\":1,\"id\":820,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":821,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":822,\"textContent\":\" \"},{\"nodeType\":1,\"id\":823,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":824,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":825,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":826,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":827,\"textContent\":\" \"},{\"nodeType\":1,\"id\":828,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":829,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":830,\"textContent\":\" \"},{\"nodeType\":1,\"id\":831,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":832,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":833,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":834,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":835,\"textContent\":\" \"},{\"nodeType\":1,\"id\":836,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":837,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":838,\"textContent\":\" \"},{\"nodeType\":1,\"id\":839,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":840,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":841,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":842,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":843,\"textContent\":\" \"},{\"nodeType\":1,\"id\":844,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":845,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":846,\"textContent\":\" \"},{\"nodeType\":1,\"id\":847,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":848,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":849,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":850,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":851,\"textContent\":\" \"},{\"nodeType\":1,\"id\":852,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":853,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":854,\"textContent\":\" \"},{\"nodeType\":1,\"id\":855,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":856,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":857,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":858,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":859,\"textContent\":\" \"},{\"nodeType\":1,\"id\":860,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":861,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":862,\"textContent\":\" \"},{\"nodeType\":1,\"id\":863,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":864,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":865,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":866,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":867,\"textContent\":\" \"},{\"nodeType\":1,\"id\":868,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":869,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":870,\"textContent\":\" \"},{\"nodeType\":1,\"id\":871,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":872,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":873,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":874,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":875,\"textContent\":\" \"},{\"nodeType\":1,\"id\":876,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":877,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":878,\"textContent\":\" \"},{\"nodeType\":1,\"id\":879,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":880,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":881,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":882,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":883,\"textContent\":\" \"},{\"nodeType\":1,\"id\":884,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":885,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":886,\"textContent\":\" \"},{\"nodeType\":1,\"id\":887,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":888,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":889,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":890,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":891,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":892,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":893,\"textContent\":\" \"},{\"nodeType\":1,\"id\":894,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.duration+starts\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":895,\"textContent\":\" \"},{\"nodeType\":1,\"id\":896,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":897,\"textContent\":\"Which 2 shifts less than 5 hours long start at the same time?\"}]},{\"nodeType\":3,\"id\":898,\"textContent\":\" \"},{\"nodeType\":1,\"id\":899,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":900,\"textContent\":\" \"},{\"nodeType\":1,\"id\":901,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":902,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":903,\"textContent\":\" \"},{\"nodeType\":1,\"id\":904,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":905,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":906,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":907,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":908,\"textContent\":\" \"},{\"nodeType\":1,\"id\":909,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":910,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":911,\"textContent\":\" \"},{\"nodeType\":1,\"id\":912,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":913,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":914,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":915,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":916,\"textContent\":\" \"},{\"nodeType\":1,\"id\":917,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":918,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":919,\"textContent\":\" \"},{\"nodeType\":1,\"id\":920,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":921,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":922,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":923,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":924,\"textContent\":\" \"},{\"nodeType\":1,\"id\":925,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":926,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":927,\"textContent\":\" \"},{\"nodeType\":1,\"id\":928,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":929,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":930,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":931,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":932,\"textContent\":\" \"},{\"nodeType\":1,\"id\":933,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":934,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":935,\"textContent\":\" \"},{\"nodeType\":1,\"id\":936,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":937,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":938,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":939,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":940,\"textContent\":\" \"},{\"nodeType\":1,\"id\":941,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":942,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":943,\"textContent\":\" \"},{\"nodeType\":1,\"id\":944,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":945,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":946,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":947,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":948,\"textContent\":\" \"},{\"nodeType\":1,\"id\":949,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":950,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":951,\"textContent\":\" \"},{\"nodeType\":1,\"id\":952,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":953,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":954,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":955,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":956,\"textContent\":\" \"},{\"nodeType\":1,\"id\":957,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":958,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":959,\"textContent\":\" \"},{\"nodeType\":1,\"id\":960,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":961,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":962,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":963,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":964,\"textContent\":\" \"},{\"nodeType\":1,\"id\":965,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":966,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":967,\"textContent\":\" \"},{\"nodeType\":1,\"id\":968,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":969,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":970,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":971,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":972,\"textContent\":\" \"},{\"nodeType\":1,\"id\":973,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":974,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":975,\"textContent\":\" \"},{\"nodeType\":1,\"id\":976,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":977,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":978,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":979,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":980,\"textContent\":\" \"},{\"nodeType\":1,\"id\":981,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":982,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":983,\"textContent\":\" \"},{\"nodeType\":1,\"id\":984,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":985,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":986,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":987,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":988,\"textContent\":\" \"},{\"nodeType\":1,\"id\":989,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":990,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":991,\"textContent\":\" \"},{\"nodeType\":1,\"id\":992,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":993,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":994,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":995,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":996,\"textContent\":\" \"},{\"nodeType\":1,\"id\":997,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":998,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":999,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1000,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1001,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":1002,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1003,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1004,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1005,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1006,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1007,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1008,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1009,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":1010,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1011,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1012,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1013,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1014,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1015,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1016,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1017,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":1018,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1019,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1020,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1021,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1022,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1023,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1024,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1025,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":1026,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1027,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1028,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1029,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1030,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1031,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1032,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1033,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":1034,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1035,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1036,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1037,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1038,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1039,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1040,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1041,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":1042,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1043,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1044,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1045,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1046,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1047,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.duration+contained\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":1048,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1049,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":1050,\"textContent\":\"Which shift(s) under 7 hours long starts before B starts, and ends after X ends?\"}]},{\"nodeType\":3,\"id\":1051,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1052,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":1053,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1054,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1055,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1056,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1057,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1058,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":1059,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1060,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1061,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1062,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1063,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1064,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1065,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1066,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":1067,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1068,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1069,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1070,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1071,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1072,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1073,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1074,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":1075,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1076,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1077,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1078,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1079,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1080,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1081,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1082,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":1083,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1084,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1085,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1086,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1087,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1088,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1089,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1090,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":1091,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1092,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1093,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1094,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1095,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1096,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1097,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1098,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":1099,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1100,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1101,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1102,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1103,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1104,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1105,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1106,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":1107,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1108,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1109,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1110,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1111,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1112,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1113,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1114,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":1115,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1116,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1117,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1118,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1119,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1120,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1121,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1122,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":1123,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1124,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1125,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1126,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1127,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1128,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1129,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1130,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":1131,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1132,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1133,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1134,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1135,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1136,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1137,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1138,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":1139,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1140,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1141,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1142,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1143,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1144,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1145,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1146,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":1147,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1148,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1149,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1150,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1151,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1152,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1153,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1154,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":1155,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1156,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1157,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1158,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1159,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1160,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1161,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1162,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":1163,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1164,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1165,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1166,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1167,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1168,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1169,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1170,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":1171,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1172,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1173,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1174,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1175,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1176,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1177,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1178,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":1179,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1180,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1181,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1182,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1183,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1184,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1185,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1186,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":1187,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1188,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1189,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1190,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1191,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1192,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1193,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1194,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":1195,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1196,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1197,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1198,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1199,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1200,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.starttime+before+endtime+during\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":1201,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1202,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":1203,\"textContent\":\"Which shift(s) begins before J begins and ends during B?\"}]},{\"nodeType\":3,\"id\":1204,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1205,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":1206,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1207,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1208,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1209,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1210,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1211,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":1212,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1213,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1214,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1215,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1216,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1217,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1218,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1219,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":1220,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1221,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1222,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1223,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1224,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1225,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1226,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1227,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":1228,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1229,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1230,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1231,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1232,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1233,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1234,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1235,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":1236,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1237,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1238,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1239,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1240,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1241,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1242,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1243,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":1244,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1245,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1246,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1247,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1248,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1249,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1250,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1251,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":1252,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1253,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1254,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1255,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1256,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1257,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1258,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1259,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":1260,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1261,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1262,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1263,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1264,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1265,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1266,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1267,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":1268,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1269,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1270,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1271,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1272,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1273,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1274,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1275,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":1276,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1277,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1278,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1279,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1280,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1281,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1282,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1283,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":1284,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1285,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1286,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1287,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1288,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1289,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1290,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1291,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":1292,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1293,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1294,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1295,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1296,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1297,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1298,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1299,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":1300,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1301,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1302,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1303,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1304,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1305,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1306,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1307,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":1308,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1309,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1310,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1311,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1312,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1313,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1314,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1315,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":1316,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1317,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1318,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1319,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1320,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1321,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1322,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1323,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":1324,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1325,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1326,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1327,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1328,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1329,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1330,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1331,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":1332,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1333,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1334,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1335,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1336,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1337,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1338,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1339,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":1340,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1341,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1342,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1343,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1344,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1345,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1346,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1347,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":1348,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1349,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1350,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1351,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1352,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1353,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.ends\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":1354,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1355,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":1356,\"textContent\":\"Which shift(s) end at the same time as F?\"}]},{\"nodeType\":3,\"id\":1357,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1358,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":1359,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1360,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1361,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1362,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1363,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1364,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":1365,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1366,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1367,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1368,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1369,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1370,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1371,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1372,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":1373,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1374,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1375,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1376,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1377,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1378,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1379,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1380,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":1381,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1382,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1383,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1384,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1385,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1386,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1387,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1388,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":1389,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1390,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1391,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1392,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1393,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1394,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1395,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1396,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":1397,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1398,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1399,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1400,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1401,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1402,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1403,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1404,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":1405,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1406,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1407,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1408,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1409,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1410,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1411,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1412,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":1413,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1414,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1415,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1416,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1417,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1418,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1419,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1420,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":1421,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1422,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1423,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1424,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1425,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1426,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1427,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1428,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":1429,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1430,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1431,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1432,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1433,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1434,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1435,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1436,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":1437,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1438,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1439,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1440,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1441,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1442,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1443,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1444,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":1445,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1446,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1447,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1448,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1449,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1450,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1451,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1452,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":1453,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1454,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1455,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1456,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1457,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1458,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1459,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1460,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":1461,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1462,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1463,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1464,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1465,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1466,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1467,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1468,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":1469,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1470,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1471,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1472,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1473,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1474,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1475,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1476,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":1477,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1478,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1479,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1480,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1481,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1482,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1483,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1484,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":1485,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1486,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1487,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1488,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1489,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1490,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1491,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1492,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":1493,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1494,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1495,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1496,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1497,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1498,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1499,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1500,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":1501,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1502,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1503,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1504,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1505,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1506,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.starttime\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":1507,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1508,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":1509,\"textContent\":\"Which shift(s) start at 12pm?\"}]},{\"nodeType\":3,\"id\":1510,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1511,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":1512,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1513,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1514,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1515,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1516,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1517,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":1518,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1519,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1520,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1521,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1522,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1523,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1524,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1525,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":1526,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1527,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1528,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1529,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1530,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1531,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1532,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1533,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":1534,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1535,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1536,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1537,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1538,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1539,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1540,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1541,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":1542,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1543,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1544,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1545,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1546,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1547,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1548,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1549,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":1550,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1551,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1552,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1553,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1554,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1555,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1556,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1557,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":1558,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1559,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1560,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1561,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1562,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1563,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1564,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1565,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":1566,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1567,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1568,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1569,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1570,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1571,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1572,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1573,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":1574,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1575,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1576,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1577,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1578,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1579,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1580,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1581,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":1582,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1583,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1584,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1585,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1586,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1587,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1588,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1589,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":1590,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1591,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1592,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1593,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1594,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1595,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1596,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1597,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":1598,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1599,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1600,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1601,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1602,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1603,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1604,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1605,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":1606,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1607,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1608,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1609,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1610,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1611,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1612,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1613,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":1614,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1615,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1616,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1617,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1618,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1619,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1620,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1621,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":1622,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1623,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1624,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1625,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1626,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1627,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1628,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1629,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":1630,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1631,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1632,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1633,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1634,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1635,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1636,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1637,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":1638,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1639,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1640,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1641,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1642,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1643,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1644,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1645,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":1646,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1647,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1648,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1649,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1650,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1651,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1652,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1653,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":1654,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1655,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1656,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1657,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1658,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1659,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.starts\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":1660,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1661,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":1662,\"textContent\":\"Which shift(s) start at the same time as F?\"}]},{\"nodeType\":3,\"id\":1663,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1664,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":1665,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1666,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1667,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1668,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1669,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1670,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":1671,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1672,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1673,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1674,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1675,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1676,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1677,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1678,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":1679,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1680,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1681,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1682,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1683,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1684,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1685,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1686,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":1687,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1688,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1689,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1690,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1691,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1692,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1693,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1694,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":1695,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1696,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1697,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1698,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1699,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1700,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1701,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1702,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":1703,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1704,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1705,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1706,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1707,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1708,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1709,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1710,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":1711,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1712,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1713,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1714,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1715,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1716,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1717,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1718,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":1719,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1720,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1721,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1722,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1723,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1724,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1725,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1726,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":1727,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1728,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1729,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1730,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1731,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1732,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1733,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1734,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":1735,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1736,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1737,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1738,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1739,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1740,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1741,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1742,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":1743,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1744,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1745,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1746,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1747,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1748,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1749,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1750,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":1751,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1752,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1753,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1754,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1755,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1756,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1757,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1758,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":1759,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1760,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1761,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1762,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1763,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1764,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1765,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1766,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":1767,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1768,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1769,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1770,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1771,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1772,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1773,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1774,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":1775,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1776,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1777,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1778,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1779,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1780,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1781,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1782,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":1783,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1784,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1785,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1786,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1787,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1788,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1789,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1790,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":1791,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1792,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1793,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1794,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1795,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1796,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1797,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1798,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":1799,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1800,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1801,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1802,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1803,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1804,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1805,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1806,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":1807,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1808,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1809,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1810,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1811,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1812,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.meets\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":1813,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1814,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":1815,\"textContent\":\"Which 2 shifts end when Z begins?\"}]},{\"nodeType\":3,\"id\":1816,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1817,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":1818,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1819,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1820,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1821,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1822,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1823,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":1824,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1825,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1826,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1827,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1828,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1829,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1830,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1831,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":1832,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1833,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1834,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1835,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1836,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1837,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1838,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1839,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":1840,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1841,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1842,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1843,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1844,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1845,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1846,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1847,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":1848,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1849,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1850,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1851,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1852,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1853,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1854,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1855,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":1856,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1857,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1858,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1859,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1860,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1861,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1862,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1863,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":1864,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1865,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1866,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1867,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1868,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1869,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1870,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1871,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":1872,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1873,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1874,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1875,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1876,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1877,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1878,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1879,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":1880,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1881,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1882,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1883,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1884,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1885,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1886,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1887,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":1888,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1889,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1890,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1891,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1892,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1893,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1894,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1895,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":1896,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1897,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1898,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1899,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1900,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1901,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1902,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1903,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":1904,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1905,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1906,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1907,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1908,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1909,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1910,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1911,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":1912,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1913,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1914,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1915,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1916,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1917,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1918,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1919,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":1920,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1921,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1922,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1923,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1924,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1925,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1926,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1927,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":1928,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1929,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1930,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1931,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1932,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1933,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1934,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1935,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":1936,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1937,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1938,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1939,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1940,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1941,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1942,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1943,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":1944,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1945,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1946,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1947,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1948,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1949,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1950,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1951,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":1952,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1953,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1954,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1955,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1956,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1957,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1958,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1959,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":1960,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1961,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1962,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1963,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1964,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1965,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.endtime\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":1966,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1967,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":1968,\"textContent\":\"Which shift(s) end at 3pm?\"}]},{\"nodeType\":3,\"id\":1969,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1970,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":1971,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1972,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1973,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1974,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1975,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1976,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":1977,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1978,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1979,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1980,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1981,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1982,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1983,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1984,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":1985,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1986,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1987,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1988,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1989,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1990,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1991,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1992,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":1993,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1994,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1995,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1996,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1997,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1998,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1999,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2000,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":2001,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2002,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2003,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2004,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2005,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2006,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2007,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2008,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":2009,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2010,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2011,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2012,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2013,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2014,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2015,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2016,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":2017,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2018,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2019,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2020,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2021,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2022,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2023,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2024,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":2025,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2026,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2027,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2028,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2029,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2030,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2031,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2032,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":2033,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2034,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2035,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2036,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2037,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2038,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2039,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2040,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":2041,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2042,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2043,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2044,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2045,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2046,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2047,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2048,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":2049,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2050,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2051,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2052,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2053,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2054,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2055,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2056,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":2057,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2058,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2059,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2060,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2061,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2062,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2063,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2064,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":2065,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2066,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2067,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2068,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2069,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2070,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2071,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2072,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":2073,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2074,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2075,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2076,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2077,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2078,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2079,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2080,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":2081,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2082,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2083,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2084,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2085,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2086,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2087,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2088,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":2089,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2090,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2091,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2092,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2093,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2094,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2095,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2096,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":2097,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2098,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2099,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2100,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2101,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2102,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2103,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2104,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":2105,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2106,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2107,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2108,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2109,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2110,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2111,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2112,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":2113,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2114,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2115,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2116,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2117,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2118,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.midpoint\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":2119,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2120,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":2121,\"textContent\":\"Coffee breaks happen halfway through a shift. \"},{\"nodeType\":1,\"id\":2122,\"tagName\":\"BR\",\"attributes\":{}},{\"nodeType\":3,\"id\":2123,\"textContent\":\"Which shifts share a break at 2pm?\"}]},{\"nodeType\":3,\"id\":2124,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2125,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":2126,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2127,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2128,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2129,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2130,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2131,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":2132,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2133,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2134,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2135,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2136,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2137,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2138,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2139,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":2140,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2141,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2142,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2143,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2144,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2145,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2146,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2147,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":2148,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2149,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2150,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2151,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2152,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2153,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2154,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2155,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":2156,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2157,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2158,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2159,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2160,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2161,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2162,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2163,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":2164,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2165,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2166,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2167,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2168,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2169,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2170,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2171,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":2172,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2173,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2174,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2175,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2176,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2177,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2178,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2179,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":2180,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2181,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2182,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2183,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2184,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2185,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2186,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2187,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":2188,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2189,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2190,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2191,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2192,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2193,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2194,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2195,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":2196,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2197,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2198,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2199,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2200,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2201,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2202,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2203,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":2204,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2205,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2206,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2207,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2208,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2209,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2210,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2211,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":2212,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2213,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2214,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2215,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2216,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2217,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2218,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2219,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":2220,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2221,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2222,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2223,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2224,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2225,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2226,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2227,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":2228,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2229,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2230,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2231,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2232,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2233,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2234,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2235,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":2236,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2237,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2238,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2239,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2240,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2241,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2242,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2243,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":2244,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2245,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2246,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2247,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2248,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2249,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2250,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2251,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":2252,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2253,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2254,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2255,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2256,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2257,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2258,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2259,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":2260,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2261,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2262,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2263,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2264,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2265,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2266,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2267,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":2268,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2269,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2270,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2271,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2272,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2273,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\".strategy\",\"style\":\"display: block;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2274,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2275,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":2276,\"textContent\":\"Please describe how to determine what event(s) start at 12pm?\"}]},{\"nodeType\":3,\"id\":2277,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2278,\"tagName\":\"TEXTAREA\",\"attributes\":{\"id\":\"strategyAnswer\",\"rows\":\"5\",\"cols\":\"80\"}},{\"nodeType\":3,\"id\":2279,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2280,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2281,\"textContent\":\" \"},{\"nodeType\":8,\"id\":2282},{\"nodeType\":3,\"id\":2283,\"textContent\":\" \"},{\"nodeType\":8,\"id\":2284},{\"nodeType\":3,\"id\":2285,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2286,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"fixbottom\"},\"childNodes\":[{\"nodeType\":3,\"id\":2287,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2288,\"tagName\":\"BUTTON\",\"attributes\":{\"type\":\"button\",\"id\":\"testingButton\",\"style\":\"display:none;\",\"class\":\"btn\"},\"childNodes\":[{\"nodeType\":3,\"id\":2289,\"textContent\":\"SUBMIT\"}]},{\"nodeType\":3,\"id\":2290,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2291,\"tagName\":\"BUTTON\",\"attributes\":{\"type\":\"button\",\"id\":\"strategyButton\",\"style\":\"display: block;\",\"class\":\"btn\"},\"childNodes\":[{\"nodeType\":3,\"id\":2292,\"textContent\":\"SUBMIT\"}]},{\"nodeType\":3,\"id\":2293,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2294,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2295,\"textContent\":\" \"},{\"nodeType\":8,\"id\":2296},{\"nodeType\":3,\"id\":2297,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2298,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"d3container\"},\"childNodes\":[{\"nodeType\":1,\"id\":2299,\"tagName\":\"svg\",\"attributes\":{\"width\":\"930\",\"height\":\"915\"},\"childNodes\":[{\"nodeType\":1,\"id\":2300,\"tagName\":\"g\",\"attributes\":{\"transform\":\"translate(100,25)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2301,\"tagName\":\"g\",\"attributes\":{\"class\":\"leaders\"}},{\"nodeType\":1,\"id\":2302,\"tagName\":\"g\",\"attributes\":{\"class\":\"static-scaffold\"}},{\"nodeType\":1,\"id\":2303,\"tagName\":\"g\",\"attributes\":{\"class\":\"xaxis\",\"transform\":\"translate(0,800)\",\"fill\":\"none\",\"font-size\":\"10\",\"font-family\":\"sans-serif\",\"text-anchor\":\"middle\"},\"childNodes\":[{\"nodeType\":1,\"id\":2304,\"tagName\":\"path\",\"attributes\":{\"class\":\"domain\",\"stroke\":\"#000\",\"d\":\"M0.5,6V0.5H800.5V6\"}},{\"nodeType\":1,\"id\":2305,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0.5,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2306,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2307,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2308,\"textContent\":\"08 AM\"}]}]},{\"nodeType\":1,\"id\":2309,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(33.83333333333333,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2310,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2311,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2312,\"textContent\":\"08:30\"}]}]},{\"nodeType\":1,\"id\":2313,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(67.16666666666666,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2314,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2315,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2316,\"textContent\":\"09 AM\"}]}]},{\"nodeType\":1,\"id\":2317,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(100.5,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2318,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2319,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2320,\"textContent\":\"09:30\"}]}]},{\"nodeType\":1,\"id\":2321,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(133.83333333333331,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2322,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2323,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2324,\"textContent\":\"10 AM\"}]}]},{\"nodeType\":1,\"id\":2325,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(167.16666666666669,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2326,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2327,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2328,\"textContent\":\"10:30\"}]}]},{\"nodeType\":1,\"id\":2329,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(200.5,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2330,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2331,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2332,\"textContent\":\"11 AM\"}]}]},{\"nodeType\":1,\"id\":2333,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(233.83333333333334,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2334,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2335,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2336,\"textContent\":\"11:30\"}]}]},{\"nodeType\":1,\"id\":2337,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(267.16666666666663,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2338,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2339,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2340,\"textContent\":\"12 PM\"}]}]},{\"nodeType\":1,\"id\":2341,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(300.5,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2342,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2343,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2344,\"textContent\":\"12:30\"}]}]},{\"nodeType\":1,\"id\":2345,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(333.83333333333337,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2346,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2347,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2348,\"textContent\":\"01 PM\"}]}]},{\"nodeType\":1,\"id\":2349,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(367.16666666666663,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2350,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2351,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2352,\"textContent\":\"01:30\"}]}]},{\"nodeType\":1,\"id\":2353,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(400.5,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2354,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2355,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2356,\"textContent\":\"02 PM\"}]}]},{\"nodeType\":1,\"id\":2357,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(433.8333333333333,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2358,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2359,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2360,\"textContent\":\"02:30\"}]}]},{\"nodeType\":1,\"id\":2361,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(467.1666666666667,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2362,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2363,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2364,\"textContent\":\"03 PM\"}]}]},{\"nodeType\":1,\"id\":2365,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(500.5,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2366,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2367,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2368,\"textContent\":\"03:30\"}]}]},{\"nodeType\":1,\"id\":2369,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(533.8333333333333,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2370,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2371,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2372,\"textContent\":\"04 PM\"}]}]},{\"nodeType\":1,\"id\":2373,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(567.1666666666667,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2374,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2375,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2376,\"textContent\":\"04:30\"}]}]},{\"nodeType\":1,\"id\":2377,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(600.5,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2378,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2379,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2380,\"textContent\":\"05 PM\"}]}]},{\"nodeType\":1,\"id\":2381,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(633.8333333333333,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2382,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2383,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2384,\"textContent\":\"05:30\"}]}]},{\"nodeType\":1,\"id\":2385,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(667.1666666666667,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2386,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2387,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2388,\"textContent\":\"06 PM\"}]}]},{\"nodeType\":1,\"id\":2389,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(700.5,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2390,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2391,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2392,\"textContent\":\"06:30\"}]}]},{\"nodeType\":1,\"id\":2393,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(733.8333333333333,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2394,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2395,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2396,\"textContent\":\"07 PM\"}]}]},{\"nodeType\":1,\"id\":2397,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(767.1666666666667,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2398,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2399,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2400,\"textContent\":\"07:30\"}]}]},{\"nodeType\":1,\"id\":2401,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(800.5,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2402,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2403,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2404,\"textContent\":\"08 PM\"}]}]},{\"nodeType\":1,\"id\":2405,\"tagName\":\"g\",\"attributes\":{\"class\":\"axisTitle\"},\"childNodes\":[{\"nodeType\":1,\"id\":2406,\"tagName\":\"text\",\"attributes\":{\"x\":\"533.3333333333334\",\"y\":\"80\",\"style\":\"text-anchor: end;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2407,\"textContent\":\"START & END TIME (time of day)\"}]}]}]},{\"nodeType\":1,\"id\":2408,\"tagName\":\"g\",\"attributes\":{\"class\":\"yaxis\",\"fill\":\"none\",\"font-size\":\"10\",\"font-family\":\"sans-serif\",\"text-anchor\":\"end\"},\"childNodes\":[{\"nodeType\":1,\"id\":2409,\"tagName\":\"path\",\"attributes\":{\"class\":\"domain\",\"stroke\":\"#000\",\"d\":\"M-15,800.5H0.5V0.5H-15\"}},{\"nodeType\":1,\"id\":2410,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,800.5)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2411,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2412,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2413,\"textContent\":\"0\"}]}]},{\"nodeType\":1,\"id\":2414,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,733.8333333333334)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2415,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2416,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2417,\"textContent\":\"1\"}]}]},{\"nodeType\":1,\"id\":2418,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,667.1666666666667)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2419,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2420,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2421,\"textContent\":\"2\"}]}]},{\"nodeType\":1,\"id\":2422,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,600.5)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2423,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2424,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2425,\"textContent\":\"3\"}]}]},{\"nodeType\":1,\"id\":2426,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,533.8333333333334)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2427,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2428,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2429,\"textContent\":\"4\"}]}]},{\"nodeType\":1,\"id\":2430,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,467.16666666666663)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2431,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2432,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2433,\"textContent\":\"5\"}]}]},{\"nodeType\":1,\"id\":2434,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,400.5)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2435,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2436,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2437,\"textContent\":\"6\"}]}]},{\"nodeType\":1,\"id\":2438,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,333.8333333333333)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2439,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2440,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2441,\"textContent\":\"7\"}]}]},{\"nodeType\":1,\"id\":2442,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,267.16666666666674)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2443,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2444,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2445,\"textContent\":\"8\"}]}]},{\"nodeType\":1,\"id\":2446,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,200.5)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2447,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2448,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2449,\"textContent\":\"9\"}]}]},{\"nodeType\":1,\"id\":2450,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,133.83333333333326)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2451,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2452,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2453,\"textContent\":\"10\"}]}]},{\"nodeType\":1,\"id\":2454,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,67.16666666666674)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2455,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2456,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2457,\"textContent\":\"11\"}]}]},{\"nodeType\":1,\"id\":2458,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,0.5)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2459,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2460,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2461,\"textContent\":\"12\"}]}]},{\"nodeType\":1,\"id\":2462,\"tagName\":\"g\",\"attributes\":{\"class\":\"axisTitle\"},\"childNodes\":[{\"nodeType\":1,\"id\":2463,\"tagName\":\"text\",\"attributes\":{\"transform\":\"rotate(-90)\",\"x\":\"-350\",\"y\":\"-60\",\"style\":\"text-anchor: end;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2464,\"textContent\":\"DURATION (in hours)\"}]}]}]},{\"nodeType\":1,\"id\":2465,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2466,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2467,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"733.3333333333334\",\"y2\":\"733.3333333333334\"}}]},{\"nodeType\":1,\"id\":2468,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2469,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"666.6666666666667\",\"y2\":\"666.6666666666667\"}}]},{\"nodeType\":1,\"id\":2470,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2471,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"600\",\"y2\":\"600\"}}]},{\"nodeType\":1,\"id\":2472,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2473,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"533.3333333333334\",\"y2\":\"533.3333333333334\"}}]},{\"nodeType\":1,\"id\":2474,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2475,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"466.66666666666663\",\"y2\":\"466.66666666666663\"}}]},{\"nodeType\":1,\"id\":2476,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2477,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"400\",\"y2\":\"400\"}}]},{\"nodeType\":1,\"id\":2478,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2479,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"333.3333333333333\",\"y2\":\"333.3333333333333\"}}]},{\"nodeType\":1,\"id\":2480,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2481,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"266.66666666666674\",\"y2\":\"266.66666666666674\"}}]},{\"nodeType\":1,\"id\":2482,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2483,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"200\",\"y2\":\"200\"}}]},{\"nodeType\":1,\"id\":2484,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2485,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"133.33333333333326\",\"y2\":\"133.33333333333326\"}}]},{\"nodeType\":1,\"id\":2486,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2487,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"66.66666666666674\",\"y2\":\"66.66666666666674\"}}]},{\"nodeType\":1,\"id\":2488,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2489,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"0\",\"y2\":\"0\"}}]}]},{\"nodeType\":1,\"id\":2490,\"tagName\":\"g\",\"attributes\":{\"class\":\"xgrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2491,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"0\",\"y1\":\"800\",\"x2\":\"400\",\"y2\":\"0\"}},{\"nodeType\":1,\"id\":2492,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"800\",\"y1\":\"800\",\"x2\":\"400\",\"y2\":\"0\"}},{\"nodeType\":1,\"id\":2493,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"66.66666666666666\",\"y1\":\"800\",\"x2\":\"466.6666666666667\",\"y2\":\"0\"}},{\"nodeType\":1,\"id\":2494,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"733.3333333333333\",\"y1\":\"800\",\"x2\":\"333.33333333333337\",\"y2\":\"0\"}},{\"nodeType\":1,\"id\":2495,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"133.33333333333331\",\"y1\":\"800\",\"x2\":\"533.3333333333333\",\"y2\":\"0\"}},{\"nodeType\":1,\"id\":2496,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"666.6666666666667\",\"y1\":\"800\",\"x2\":\"266.66666666666663\",\"y2\":\"0\"}},{\"nodeType\":1,\"id\":2497,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"200\",\"y1\":\"800\",\"x2\":\"600\",\"y2\":\"0\"}},{\"nodeType\":1,\"id\":2498,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"600\",\"y1\":\"800\",\"x2\":\"200\",\"y2\":\"0\"}},{\"nodeType\":1,\"id\":2499,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"266.66666666666663\",\"y1\":\"800\",\"x2\":\"666.6666666666667\",\"y2\":\"0\"}},{\"nodeType\":1,\"id\":2500,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"533.3333333333333\",\"y1\":\"800\",\"x2\":\"133.33333333333331\",\"y2\":\"0\"}},{\"nodeType\":1,\"id\":2501,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"333.33333333333337\",\"y1\":\"800\",\"x2\":\"733.3333333333333\",\"y2\":\"0\"}},{\"nodeType\":1,\"id\":2502,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"466.6666666666667\",\"y1\":\"800\",\"x2\":\"66.66666666666666\",\"y2\":\"0\"}},{\"nodeType\":1,\"id\":2503,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"400\",\"y1\":\"800\",\"x2\":\"800\",\"y2\":\"0\"}},{\"nodeType\":1,\"id\":2504,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"400\",\"y1\":\"800\",\"x2\":\"0\",\"y2\":\"0\"}},{\"nodeType\":1,\"id\":2505,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"466.6666666666667\",\"y1\":\"800\",\"x2\":\"800\",\"y2\":\"133.33333333333326\"}},{\"nodeType\":1,\"id\":2506,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"333.33333333333337\",\"y1\":\"800\",\"x2\":\"0\",\"y2\":\"133.33333333333326\"}},{\"nodeType\":1,\"id\":2507,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"533.3333333333333\",\"y1\":\"800\",\"x2\":\"800\",\"y2\":\"266.66666666666674\"}},{\"nodeType\":1,\"id\":2508,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"266.66666666666663\",\"y1\":\"800\",\"x2\":\"0\",\"y2\":\"266.66666666666674\"}},{\"nodeType\":1,\"id\":2509,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"600\",\"y1\":\"800\",\"x2\":\"800\",\"y2\":\"400\"}},{\"nodeType\":1,\"id\":2510,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"200\",\"y1\":\"800\",\"x2\":\"0\",\"y2\":\"400\"}},{\"nodeType\":1,\"id\":2511,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"666.6666666666667\",\"y1\":\"800\",\"x2\":\"800\",\"y2\":\"533.3333333333334\"}},{\"nodeType\":1,\"id\":2512,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"133.33333333333331\",\"y1\":\"800\",\"x2\":\"0\",\"y2\":\"533.3333333333334\"}},{\"nodeType\":1,\"id\":2513,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"733.3333333333333\",\"y1\":\"800\",\"x2\":\"800\",\"y2\":\"666.6666666666667\"}},{\"nodeType\":1,\"id\":2514,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"66.66666666666666\",\"y1\":\"800\",\"x2\":\"0\",\"y2\":\"666.6666666666667\"}}]},{\"nodeType\":1,\"id\":2515,\"tagName\":\"g\",\"attributes\":{\"class\":\"data\"},\"childNodes\":[{\"nodeType\":1,\"id\":2516,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2517,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"333.33333333333337\",\"cy\":\"266.66666666666674\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2518,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"328.33333333333337\",\"y\":\"258.66666666666674\"},\"childNodes\":[{\"nodeType\":3,\"id\":2519,\"textContent\":\"A \"}]}]},{\"nodeType\":1,\"id\":2520,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2521,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"266.66666666666663\",\"cy\":\"600\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2522,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"261.66666666666663\",\"y\":\"592\"},\"childNodes\":[{\"nodeType\":3,\"id\":2523,\"textContent\":\"B \"}]}]},{\"nodeType\":1,\"id\":2524,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2525,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"366.66666666666663\",\"cy\":\"466.66666666666663\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2526,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"361.66666666666663\",\"y\":\"458.66666666666663\"},\"childNodes\":[{\"nodeType\":3,\"id\":2527,\"textContent\":\"C \"}]}]},{\"nodeType\":1,\"id\":2528,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2529,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"666.6666666666667\",\"cy\":\"666.6666666666667\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2530,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"661.6666666666667\",\"y\":\"658.6666666666667\"},\"childNodes\":[{\"nodeType\":3,\"id\":2531,\"textContent\":\"D \"}]}]},{\"nodeType\":1,\"id\":2532,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2533,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"200\",\"cy\":\"400\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2534,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"195\",\"y\":\"392\"},\"childNodes\":[{\"nodeType\":3,\"id\":2535,\"textContent\":\"E \"}]}]},{\"nodeType\":1,\"id\":2536,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2537,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"266.66666666666663\",\"cy\":\"533.3333333333334\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2538,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"261.66666666666663\",\"y\":\"525.3333333333334\"},\"childNodes\":[{\"nodeType\":3,\"id\":2539,\"textContent\":\"F \"}]}]},{\"nodeType\":1,\"id\":2540,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2541,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"333.33333333333337\",\"cy\":\"400\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2542,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"328.33333333333337\",\"y\":\"392\"},\"childNodes\":[{\"nodeType\":3,\"id\":2543,\"textContent\":\"G \"}]}]},{\"nodeType\":1,\"id\":2544,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2545,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"500\",\"cy\":\"466.66666666666663\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2546,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"495\",\"y\":\"458.66666666666663\"},\"childNodes\":[{\"nodeType\":3,\"id\":2547,\"textContent\":\"H \"}]}]},{\"nodeType\":1,\"id\":2548,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2549,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"100\",\"cy\":\"600\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2550,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"95\",\"y\":\"592\"},\"childNodes\":[{\"nodeType\":3,\"id\":2551,\"textContent\":\"I \"}]}]},{\"nodeType\":1,\"id\":2552,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2553,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"133.33333333333331\",\"cy\":\"666.6666666666667\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2554,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"128.33333333333331\",\"y\":\"658.6666666666667\"},\"childNodes\":[{\"nodeType\":3,\"id\":2555,\"textContent\":\"J \"}]}]},{\"nodeType\":1,\"id\":2556,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2557,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"400\",\"cy\":\"133.33333333333326\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2558,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"395\",\"y\":\"125.33333333333326\"},\"childNodes\":[{\"nodeType\":3,\"id\":2559,\"textContent\":\"K \"}]}]},{\"nodeType\":1,\"id\":2560,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2561,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"500\",\"cy\":\"333.3333333333333\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2562,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"495\",\"y\":\"325.3333333333333\"},\"childNodes\":[{\"nodeType\":3,\"id\":2563,\"textContent\":\"L \"}]}]},{\"nodeType\":1,\"id\":2564,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2565,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"300\",\"cy\":\"733.3333333333334\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2566,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"295\",\"y\":\"725.3333333333334\"},\"childNodes\":[{\"nodeType\":3,\"id\":2567,\"textContent\":\"M \"}]}]},{\"nodeType\":1,\"id\":2568,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2569,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"600\",\"cy\":\"666.6666666666667\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2570,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"595\",\"y\":\"658.6666666666667\"},\"childNodes\":[{\"nodeType\":3,\"id\":2571,\"textContent\":\"N \"}]}]},{\"nodeType\":1,\"id\":2572,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2573,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"433.3333333333333\",\"cy\":\"600\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2574,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"428.3333333333333\",\"y\":\"592\"},\"childNodes\":[{\"nodeType\":3,\"id\":2575,\"textContent\":\"O \"}]}]},{\"nodeType\":1,\"id\":2576,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2577,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"500\",\"cy\":\"200\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2578,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"495\",\"y\":\"192\"},\"childNodes\":[{\"nodeType\":3,\"id\":2579,\"textContent\":\"P \"}]}]},{\"nodeType\":1,\"id\":2580,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2581,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"533.3333333333333\",\"cy\":\"533.3333333333334\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2582,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"528.3333333333333\",\"y\":\"525.3333333333334\"},\"childNodes\":[{\"nodeType\":3,\"id\":2583,\"textContent\":\"Z \"}]}]},{\"nodeType\":1,\"id\":2584,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2585,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"400\",\"cy\":\"666.6666666666667\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2586,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"395\",\"y\":\"658.6666666666667\"},\"childNodes\":[{\"nodeType\":3,\"id\":2587,\"textContent\":\"X \"}]}]}]}]}]}]},{\"nodeType\":3,\"id\":2588,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2589,\"textContent\":\" \"},{\"nodeType\":8,\"id\":2590},{\"nodeType\":3,\"id\":2591,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2592,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":2593,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2594,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":2595,\"textContent\":\" \"}]}]}]]}",
  "useCssProxy": true,
  "loadTimes": "es: 274, dom: 1334, initialDom: 1396",
  "javascriptErrors": []
}