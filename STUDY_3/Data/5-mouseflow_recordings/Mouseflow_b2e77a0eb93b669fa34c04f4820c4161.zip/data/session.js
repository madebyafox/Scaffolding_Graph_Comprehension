var MF = MF || {};MF.RecordingData = MF.RecordingData || {};MF.RecordingData["session"] = {
  "id": "b2e77a0eb93b669fa34c04f4820c4161",
  "created": "2018-06-04T12:16:12.8533641-07:00",
  "lastActivity": "2018-06-04T12:16:34.9063641-07:00",
  "pageViews": [
    {
      "id": "0604135291b2ff5a9fcb2afe3b5233b7c8da6627",
      "startTime": "2018-06-04T12:16:12.8533641-07:00",
      "endTime": "2018-06-04T12:16:34.9063641-07:00",
      "title": "FOX2YP",
      "uri": "https://warm-citadel-75324.herokuapp.com/",
      "websitePage": "/9",
      "visitTime": 22053,
      "engagementTime": 21802,
      "scroll": 100.0,
      "tags": [
        "form-interact"
      ],
      "friction": 0,
      "annotations": []
    }
  ],
  "duration": 22053,
  "engagementTime": 21802,
  "totalFriction": 0,
  "country": "us",
  "region": "CA",
  "city": "La Jolla",
  "isp": "University of California, San Diego",
  "ip": "128.54.68.40",
  "lang": "en-US",
  "userAgent": "Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/66.0.3359.181 Safari/537.36",
  "browser": "Chrome",
  "browserVersion": "66.0.3359.181",
  "os": "Windows",
  "osVersion": "7",
  "device": "Desktop",
  "referrer": "",
  "referrerType": "",
  "screenRes": "1920x1200",
  "tags": [
    "form-interact"
  ],
  "variables": [
    "SID=QBCLV",
    "CONDITION=311"
  ],
  "watched": false,
  "starred": false,
  "lng": -117.2359,
  "lat": 32.8807,
  "visitorId": "32aba948669d4f8d6562ecec0934b878",
  "gdpr": false
}