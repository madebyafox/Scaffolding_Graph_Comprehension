var MF = MF || {};MF.RecordingData = MF.RecordingData || {};MF.RecordingData["session"] = {
  "id": "553bdf653f932ff9a15a1f850e73f4e0",
  "created": "2018-05-15T17:01:01.2043984-07:00",
  "lastActivity": "2018-05-15T17:03:00.730567-07:00",
  "pageViews": [
    {
      "id": "0515004255c8a71f9380f939ec06f0752c027736",
      "startTime": "2018-05-15T17:01:01.474796-07:00",
      "endTime": "2018-05-15T17:03:00.730567-07:00",
      "title": "FOX2YP",
      "uri": "https://warm-citadel-75324.herokuapp.com/",
      "websitePage": "/",
      "visitTime": 120310,
      "engagementTime": 65270,
      "scroll": 100.0,
      "tags": [
        "form-interact"
      ],
      "friction": 0,
      "annotations": []
    }
  ],
  "duration": 120310,
  "engagementTime": 65270,
  "totalFriction": 0,
  "country": "us",
  "region": "CA",
  "city": "La Jolla",
  "isp": "University of California, San Diego",
  "ip": "128.54.68.37",
  "lang": "en-US",
  "userAgent": "Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/66.0.3359.170 Safari/537.36",
  "browser": "Chrome",
  "browserVersion": "66.0.3359.170",
  "os": "Windows",
  "osVersion": "7",
  "device": "Desktop",
  "referrer": "",
  "referrerType": "",
  "screenRes": "1920x1200",
  "tags": [
    "form-interact"
  ],
  "variables": [],
  "watched": false,
  "starred": false,
  "lng": -117.2359,
  "lat": 32.8807,
  "visitorId": "413a3d13e3434adcddf207b6e69e5ea3",
  "gdpr": false
}