var MF = MF || {};MF.RecordingData = MF.RecordingData || {};MF.RecordingData["session"] = {
  "id": "2b26f1c49647095ebb57dc2945d8526a",
  "created": "2018-05-14T13:11:50.4383446-07:00",
  "lastActivity": "2018-05-14T13:12:28.7613446-07:00",
  "pageViews": [
    {
      "id": "0514501942405b50eb1c52a221a34d936fbf8f13",
      "startTime": "2018-05-14T13:11:50.4383446-07:00",
      "endTime": "2018-05-14T13:12:28.7613446-07:00",
      "title": "FOX2YP",
      "uri": "https://warm-citadel-75324.herokuapp.com/",
      "websitePage": "/9",
      "visitTime": 38323,
      "engagementTime": 34533,
      "scroll": 100.0,
      "tags": [
        "form-interact"
      ],
      "friction": 0,
      "annotations": []
    }
  ],
  "duration": 38323,
  "engagementTime": 34533,
  "totalFriction": 0,
  "country": "us",
  "region": "CA",
  "city": "La Jolla",
  "isp": "University of California, San Diego",
  "ip": "128.54.68.39",
  "lang": "en-US",
  "userAgent": "Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/66.0.3359.170 Safari/537.36",
  "browser": "Chrome",
  "browserVersion": "66.0.3359.170",
  "os": "Windows",
  "osVersion": "7",
  "device": "Desktop",
  "referrer": "",
  "referrerType": "",
  "screenRes": "1920x1200",
  "tags": [
    "form-interact"
  ],
  "variables": [
    "SID=9393C",
    "CONDITION=121",
    "TRI_CORRECT=1",
    "ORTH_CORRECT=1"
  ],
  "watched": false,
  "starred": false,
  "lng": -117.2359,
  "lat": 32.8807,
  "visitorId": "bc3d730d7be4e8382362618da05ca69e",
  "gdpr": false
}