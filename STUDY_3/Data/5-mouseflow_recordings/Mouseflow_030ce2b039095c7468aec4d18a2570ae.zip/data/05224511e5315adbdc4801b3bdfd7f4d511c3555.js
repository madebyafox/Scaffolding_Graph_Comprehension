var MF = MF || {};MF.RecordingData = MF.RecordingData || {};MF.RecordingData["05224511e5315adbdc4801b3bdfd7f4d511c3555"] = {
  "startTime": "2018-05-22T17:16:45.7241146Z",
  "websitePageUrl": "/16",
  "visitTime": 74778,
  "engagementTime": 72074,
  "pageTitle": "FOX2YP",
  "url": "https://warm-citadel-75324.herokuapp.com/",
  "viewportWidth": 1920,
  "viewportHeight": 1200,
  "tags": [
    "form-interact",
    "submit"
  ],
  "session": {
    "id": "030ce2b039095c7468aec4d18a2570ae",
    "created": "2018-05-22T17:16:45.7241146+00:00",
    "lastActivity": "0001-01-01T00:00:00+00:00",
    "pages": 1,
    "duration": 0,
    "engagementTime": 0,
    "totalFriction": 0,
    "country": "us",
    "region": "CA",
    "city": "La Jolla",
    "isp": "University of California, San Diego",
    "ip": "###.###.###.###",
    "lang": "en-US",
    "userAgent": "Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/66.0.3359.181 Safari/537.36",
    "browser": "Chrome",
    "browserVersion": "66.0.3359.181",
    "os": "Windows",
    "osVersion": "7",
    "device": "Desktop",
    "referrer": "",
    "referrerType": "",
    "screenRes": "1920x1200",
    "entryPage": "/16",
    "tags": [
      "form-interact",
      "submit"
    ],
    "variables": [
      "SID=R06S6",
      "CONDITION=121"
    ],
    "watched": false,
    "starred": false,
    "lng": 32.8807,
    "lat": 32.8807,
    "visitorId": "8d98994cafe1136e315260ebcb1869cd",
    "gdpr": false,
    "visitorName": null,
    "playbackUrl": "https://us.mouseflow.com/websites/e0c9ff05-6fcb-4c4a-8173-e5a0724987b1/recordings/030ce2b039095c7468aec4d18a2570ae/play"
  },
  "events": [
    {
      "t": 1,
      "e": 1,
      "ty": 14,
      "x": 0,
      "y": 1199
    },
    {
      "t": 208,
      "e": 208,
      "ty": 0,
      "x": 1920,
      "y": 1200
    },
    {
      "t": 208,
      "e": 208,
      "ty": 1,
      "x": 0,
      "y": 16
    },
    {
      "t": 1000,
      "e": 1000,
      "ty": 2,
      "x": 546,
      "y": 689
    },
    {
      "t": 1001,
      "e": 1001,
      "ty": 41,
      "x": 50461,
      "y": 37725,
      "ta": "> div.stimulus > div"
    },
    {
      "t": 1054,
      "e": 1054,
      "ty": 6,
      "x": 499,
      "y": 592,
      "ta": "#strategyAnswer"
    },
    {
      "t": 1100,
      "e": 1100,
      "ty": 2,
      "x": 451,
      "y": 566
    },
    {
      "t": 1188,
      "e": 1188,
      "ty": 7,
      "x": 316,
      "y": 510,
      "ta": "#strategyAnswer"
    },
    {
      "t": 1201,
      "e": 1201,
      "ty": 2,
      "x": 316,
      "y": 510
    },
    {
      "t": 1250,
      "e": 1250,
      "ty": 41,
      "x": 19323,
      "y": 5302,
      "ta": "#.strategy > p"
    },
    {
      "t": 1301,
      "e": 1301,
      "ty": 2,
      "x": 269,
      "y": 497
    },
    {
      "t": 1400,
      "e": 1400,
      "ty": 2,
      "x": 271,
      "y": 499
    },
    {
      "t": 1501,
      "e": 1501,
      "ty": 2,
      "x": 285,
      "y": 506
    },
    {
      "t": 1501,
      "e": 1501,
      "ty": 41,
      "x": 21122,
      "y": 26367,
      "ta": "#.strategy > p"
    },
    {
      "t": 1600,
      "e": 1600,
      "ty": 2,
      "x": 285,
      "y": 509
    },
    {
      "t": 1654,
      "e": 1654,
      "ty": 6,
      "x": 269,
      "y": 524,
      "ta": "#strategyAnswer"
    },
    {
      "t": 1701,
      "e": 1701,
      "ty": 2,
      "x": 265,
      "y": 529
    },
    {
      "t": 1751,
      "e": 1751,
      "ty": 41,
      "x": 18761,
      "y": 5069,
      "ta": "#strategyAnswer"
    },
    {
      "t": 1800,
      "e": 1800,
      "ty": 2,
      "x": 264,
      "y": 529
    },
    {
      "t": 1900,
      "e": 1900,
      "ty": 2,
      "x": 264,
      "y": 530
    },
    {
      "t": 2000,
      "e": 2000,
      "ty": 2,
      "x": 271,
      "y": 532
    },
    {
      "t": 2000,
      "e": 2000,
      "ty": 41,
      "x": 19548,
      "y": 7496,
      "ta": "#strategyAnswer"
    },
    {
      "t": 2101,
      "e": 2101,
      "ty": 2,
      "x": 286,
      "y": 527
    },
    {
      "t": 2123,
      "e": 2123,
      "ty": 7,
      "x": 296,
      "y": 521,
      "ta": "#strategyAnswer"
    },
    {
      "t": 2200,
      "e": 2200,
      "ty": 2,
      "x": 336,
      "y": 512
    },
    {
      "t": 2250,
      "e": 2250,
      "ty": 41,
      "x": 28766,
      "y": 38070,
      "ta": "#.strategy > p"
    },
    {
      "t": 2300,
      "e": 2300,
      "ty": 2,
      "x": 383,
      "y": 511
    },
    {
      "t": 2400,
      "e": 2400,
      "ty": 2,
      "x": 419,
      "y": 511
    },
    {
      "t": 2501,
      "e": 2501,
      "ty": 2,
      "x": 450,
      "y": 514
    },
    {
      "t": 2501,
      "e": 2501,
      "ty": 41,
      "x": 39670,
      "y": 45091,
      "ta": "#.strategy > p"
    },
    {
      "t": 2601,
      "e": 2601,
      "ty": 2,
      "x": 461,
      "y": 516
    },
    {
      "t": 2701,
      "e": 2701,
      "ty": 2,
      "x": 462,
      "y": 516
    },
    {
      "t": 2751,
      "e": 2751,
      "ty": 41,
      "x": 41356,
      "y": 49772,
      "ta": "#.strategy > p"
    },
    {
      "t": 2801,
      "e": 2801,
      "ty": 2,
      "x": 467,
      "y": 516
    },
    {
      "t": 2901,
      "e": 2901,
      "ty": 2,
      "x": 471,
      "y": 516
    },
    {
      "t": 3000,
      "e": 3000,
      "ty": 2,
      "x": 478,
      "y": 517
    },
    {
      "t": 3001,
      "e": 3001,
      "ty": 41,
      "x": 42817,
      "y": 52113,
      "ta": "#.strategy > p"
    },
    {
      "t": 3100,
      "e": 3100,
      "ty": 2,
      "x": 486,
      "y": 519
    },
    {
      "t": 3200,
      "e": 3200,
      "ty": 2,
      "x": 487,
      "y": 519
    },
    {
      "t": 3251,
      "e": 3251,
      "ty": 41,
      "x": 43829,
      "y": 56794,
      "ta": "#.strategy > p"
    },
    {
      "t": 3500,
      "e": 3500,
      "ty": 2,
      "x": 487,
      "y": 520
    },
    {
      "t": 3500,
      "e": 3500,
      "ty": 41,
      "x": 43829,
      "y": 59135,
      "ta": "#.strategy > p"
    },
    {
      "t": 3527,
      "e": 3527,
      "ty": 6,
      "x": 487,
      "y": 522,
      "ta": "#strategyAnswer"
    },
    {
      "t": 3600,
      "e": 3600,
      "ty": 2,
      "x": 486,
      "y": 525
    },
    {
      "t": 3700,
      "e": 3700,
      "ty": 2,
      "x": 471,
      "y": 528
    },
    {
      "t": 3751,
      "e": 3751,
      "ty": 41,
      "x": 41581,
      "y": 4260,
      "ta": "#strategyAnswer"
    },
    {
      "t": 3801,
      "e": 3801,
      "ty": 2,
      "x": 467,
      "y": 528
    },
    {
      "t": 4001,
      "e": 4001,
      "ty": 2,
      "x": 475,
      "y": 532
    },
    {
      "t": 4001,
      "e": 4001,
      "ty": 41,
      "x": 42480,
      "y": 7496,
      "ta": "#strategyAnswer"
    },
    {
      "t": 4100,
      "e": 4100,
      "ty": 2,
      "x": 485,
      "y": 532
    },
    {
      "t": 4200,
      "e": 4200,
      "ty": 2,
      "x": 486,
      "y": 532
    },
    {
      "t": 4251,
      "e": 4251,
      "ty": 41,
      "x": 43716,
      "y": 7496,
      "ta": "#strategyAnswer"
    },
    {
      "t": 4300,
      "e": 4300,
      "ty": 2,
      "x": 486,
      "y": 533
    },
    {
      "t": 4401,
      "e": 4401,
      "ty": 2,
      "x": 485,
      "y": 533
    },
    {
      "t": 4500,
      "e": 4500,
      "ty": 41,
      "x": 43604,
      "y": 8305,
      "ta": "#strategyAnswer"
    },
    {
      "t": 4700,
      "e": 4700,
      "ty": 2,
      "x": 485,
      "y": 535
    },
    {
      "t": 4750,
      "e": 4750,
      "ty": 41,
      "x": 43604,
      "y": 11541,
      "ta": "#strategyAnswer"
    },
    {
      "t": 4800,
      "e": 4800,
      "ty": 2,
      "x": 485,
      "y": 537
    },
    {
      "t": 4874,
      "e": 4874,
      "ty": 7,
      "x": 756,
      "y": 577,
      "ta": "#strategyAnswer"
    },
    {
      "t": 4901,
      "e": 4901,
      "ty": 2,
      "x": 844,
      "y": 601
    },
    {
      "t": 5000,
      "e": 5000,
      "ty": 2,
      "x": 1349,
      "y": 889
    },
    {
      "t": 5001,
      "e": 5001,
      "ty": 41,
      "x": 39674,
      "y": 53788,
      "ta": "> div.stimulus > div:[2] > svg"
    },
    {
      "t": 5100,
      "e": 5100,
      "ty": 2,
      "x": 1332,
      "y": 1003
    },
    {
      "t": 5201,
      "e": 5201,
      "ty": 2,
      "x": 1325,
      "y": 1011
    },
    {
      "t": 5251,
      "e": 5251,
      "ty": 41,
      "x": 37419,
      "y": 62670,
      "ta": "> div.stimulus > div:[2] > svg"
    },
    {
      "t": 5300,
      "e": 5300,
      "ty": 2,
      "x": 1294,
      "y": 1008
    },
    {
      "t": 5401,
      "e": 5401,
      "ty": 2,
      "x": 1217,
      "y": 976
    },
    {
      "t": 5500,
      "e": 5500,
      "ty": 2,
      "x": 1205,
      "y": 974
    },
    {
      "t": 5501,
      "e": 5501,
      "ty": 41,
      "x": 8749,
      "y": 20735,
      "ta": "> div.stimulus > div:[2] > svg > g > g:[3] > g:[11] > text"
    },
    {
      "t": 5601,
      "e": 5601,
      "ty": 2,
      "x": 1193,
      "y": 976
    },
    {
      "t": 5699,
      "e": 5699,
      "ty": 2,
      "x": 1181,
      "y": 984
    },
    {
      "t": 5751,
      "e": 5751,
      "ty": 41,
      "x": 27272,
      "y": 60807,
      "ta": "> div.stimulus > div:[2] > svg"
    },
    {
      "t": 5801,
      "e": 5801,
      "ty": 2,
      "x": 1161,
      "y": 987
    },
    {
      "t": 5901,
      "e": 5901,
      "ty": 2,
      "x": 1156,
      "y": 987
    },
    {
      "t": 6000,
      "e": 6000,
      "ty": 2,
      "x": 1155,
      "y": 987
    },
    {
      "t": 6001,
      "e": 6001,
      "ty": 41,
      "x": 26003,
      "y": 60807,
      "ta": "> div.stimulus > div:[2] > svg"
    },
    {
      "t": 6101,
      "e": 6101,
      "ty": 2,
      "x": 1163,
      "y": 986
    },
    {
      "t": 6201,
      "e": 6201,
      "ty": 2,
      "x": 1320,
      "y": 977
    },
    {
      "t": 6251,
      "e": 6251,
      "ty": 41,
      "x": 37912,
      "y": 60020,
      "ta": "> div.stimulus > div:[2] > svg"
    },
    {
      "t": 6300,
      "e": 6300,
      "ty": 2,
      "x": 1324,
      "y": 976
    },
    {
      "t": 6599,
      "e": 6599,
      "ty": 2,
      "x": 1243,
      "y": 993
    },
    {
      "t": 6700,
      "e": 6700,
      "ty": 2,
      "x": 1239,
      "y": 994
    },
    {
      "t": 6751,
      "e": 6751,
      "ty": 41,
      "x": 31218,
      "y": 61309,
      "ta": "> div.stimulus > div:[2] > svg"
    },
    {
      "t": 6800,
      "e": 6800,
      "ty": 2,
      "x": 1202,
      "y": 991
    },
    {
      "t": 6900,
      "e": 6900,
      "ty": 2,
      "x": 1189,
      "y": 989
    },
    {
      "t": 7000,
      "e": 7000,
      "ty": 2,
      "x": 1163,
      "y": 985
    },
    {
      "t": 7000,
      "e": 7000,
      "ty": 41,
      "x": 26567,
      "y": 60664,
      "ta": "> div.stimulus > div:[2] > svg"
    },
    {
      "t": 7400,
      "e": 7400,
      "ty": 2,
      "x": 1152,
      "y": 981
    },
    {
      "t": 7500,
      "e": 7500,
      "ty": 2,
      "x": 1144,
      "y": 975
    },
    {
      "t": 7500,
      "e": 7500,
      "ty": 41,
      "x": 17930,
      "y": 24831,
      "ta": "> div.stimulus > div:[2] > svg > g > g:[3] > g:[9] > text"
    },
    {
      "t": 8200,
      "e": 8200,
      "ty": 2,
      "x": 1144,
      "y": 974
    },
    {
      "t": 8250,
      "e": 8250,
      "ty": 41,
      "x": 17930,
      "y": 16639,
      "ta": "> div.stimulus > div:[2] > svg > g > g:[3] > g:[9] > text"
    },
    {
      "t": 8300,
      "e": 8300,
      "ty": 2,
      "x": 1144,
      "y": 970
    },
    {
      "t": 8500,
      "e": 8500,
      "ty": 41,
      "x": 17930,
      "y": 4351,
      "ta": "> div.stimulus > div:[2] > svg > g > g:[3] > g:[9] > text"
    },
    {
      "t": 8700,
      "e": 8700,
      "ty": 2,
      "x": 1103,
      "y": 930
    },
    {
      "t": 8750,
      "e": 8750,
      "ty": 41,
      "x": 15997,
      "y": 53573,
      "ta": "> div.stimulus > div:[2] > svg"
    },
    {
      "t": 8844,
      "e": 8844,
      "ty": 2,
      "x": 803,
      "y": 820
    },
    {
      "t": 8900,
      "e": 8900,
      "ty": 2,
      "x": 564,
      "y": 760
    },
    {
      "t": 8999,
      "e": 8999,
      "ty": 2,
      "x": 513,
      "y": 665
    },
    {
      "t": 9000,
      "e": 9000,
      "ty": 41,
      "x": 46752,
      "y": 36396,
      "ta": "> div.stimulus > div"
    },
    {
      "t": 9100,
      "e": 9100,
      "ty": 2,
      "x": 486,
      "y": 626
    },
    {
      "t": 9200,
      "e": 9200,
      "ty": 2,
      "x": 486,
      "y": 627
    },
    {
      "t": 9250,
      "e": 9250,
      "ty": 41,
      "x": 43716,
      "y": 34567,
      "ta": "> div.stimulus > div"
    },
    {
      "t": 9300,
      "e": 9300,
      "ty": 2,
      "x": 486,
      "y": 633
    },
    {
      "t": 9394,
      "e": 9394,
      "ty": 6,
      "x": 481,
      "y": 603,
      "ta": "#strategyAnswer"
    },
    {
      "t": 9400,
      "e": 9400,
      "ty": 2,
      "x": 481,
      "y": 603
    },
    {
      "t": 9500,
      "e": 9500,
      "ty": 2,
      "x": 477,
      "y": 557
    },
    {
      "t": 9500,
      "e": 9500,
      "ty": 41,
      "x": 42705,
      "y": 27723,
      "ta": "#strategyAnswer"
    },
    {
      "t": 9654,
      "e": 9654,
      "ty": 3,
      "x": 477,
      "y": 557,
      "ta": "#strategyAnswer"
    },
    {
      "t": 9655,
      "e": 9655,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 9742,
      "e": 9742,
      "ty": 4,
      "x": 42705,
      "y": 27723,
      "ta": "#strategyAnswer"
    },
    {
      "t": 9742,
      "e": 9742,
      "ty": 5,
      "x": 477,
      "y": 557,
      "ta": "#strategyAnswer"
    },
    {
      "t": 9900,
      "e": 9900,
      "ty": 2,
      "x": 483,
      "y": 559
    },
    {
      "t": 9944,
      "e": 9944,
      "ty": 7,
      "x": 707,
      "y": 632,
      "ta": "#strategyAnswer"
    },
    {
      "t": 9999,
      "e": 9999,
      "ty": 2,
      "x": 1282,
      "y": 805
    },
    {
      "t": 10000,
      "e": 10000,
      "ty": 41,
      "x": 34953,
      "y": 47772,
      "ta": "> div.stimulus > div:[2] > svg"
    },
    {
      "t": 10001,
      "e": 10001,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 10099,
      "e": 10099,
      "ty": 2,
      "x": 1919,
      "y": 1215
    },
    {
      "t": 16658,
      "e": 15099,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "76"
    },
    {
      "t": 16659,
      "e": 15100,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 16761,
      "e": 15202,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "l"
    },
    {
      "t": 16890,
      "e": 15331,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "79"
    },
    {
      "t": 16891,
      "e": 15332,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 16905,
      "e": 15346,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "lo"
    },
    {
      "t": 16985,
      "e": 15426,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "79"
    },
    {
      "t": 16985,
      "e": 15426,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 17073,
      "e": 15514,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "75"
    },
    {
      "t": 17074,
      "e": 15515,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 17090,
      "e": 15531,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "look"
    },
    {
      "t": 17170,
      "e": 15611,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 17178,
      "e": 15619,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 17178,
      "e": 15619,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 17265,
      "e": 15706,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 17368,
      "e": 15809,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 17369,
      "e": 15810,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 17457,
      "e": 15898,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 17457,
      "e": 15898,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 17497,
      "e": 15938,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||at"
    },
    {
      "t": 17570,
      "e": 16011,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 17585,
      "e": 16026,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 17586,
      "e": 16027,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 17705,
      "e": 16146,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 17850,
      "e": 16291,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "72"
    },
    {
      "t": 17851,
      "e": 16292,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 17969,
      "e": 16410,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||h"
    },
    {
      "t": 18041,
      "e": 16482,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 18042,
      "e": 16483,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 18146,
      "e": 16587,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 18147,
      "e": 16588,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 18169,
      "e": 16610,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||e "
    },
    {
      "t": 18225,
      "e": 16666,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 18482,
      "e": 16923,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 18529,
      "e": 16970,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "look at he"
    },
    {
      "t": 18609,
      "e": 17050,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 18657,
      "e": 17098,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "look at h"
    },
    {
      "t": 18738,
      "e": 17179,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 18850,
      "e": 17291,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "look at "
    },
    {
      "t": 18873,
      "e": 17314,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 18873,
      "e": 17314,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 18937,
      "e": 17378,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 19034,
      "e": 17475,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "72"
    },
    {
      "t": 19035,
      "e": 17476,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 19105,
      "e": 17546,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 19105,
      "e": 17546,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 19129,
      "e": 17570,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||he"
    },
    {
      "t": 19217,
      "e": 17658,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 19298,
      "e": 17739,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 19299,
      "e": 17740,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 19369,
      "e": 17810,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 19850,
      "e": 18291,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "88"
    },
    {
      "t": 19852,
      "e": 18293,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 19953,
      "e": 18394,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||x"
    },
    {
      "t": 20000,
      "e": 18441,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 20025,
      "e": 18466,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 20025,
      "e": 18466,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 20106,
      "e": 18547,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 20169,
      "e": 18610,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 20169,
      "e": 18610,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 20265,
      "e": 18706,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||a"
    },
    {
      "t": 20554,
      "e": 18995,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "88"
    },
    {
      "t": 20554,
      "e": 18995,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 20641,
      "e": 19082,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||x"
    },
    {
      "t": 21170,
      "e": 19611,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "73"
    },
    {
      "t": 21170,
      "e": 19611,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 21266,
      "e": 19707,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||i"
    },
    {
      "t": 21273,
      "e": 19714,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "83"
    },
    {
      "t": 21273,
      "e": 19714,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 21403,
      "e": 19844,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "look at the x axis"
    },
    {
      "t": 21403,
      "e": 19844,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||s"
    },
    {
      "t": 21458,
      "e": 19899,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 21458,
      "e": 19899,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 21530,
      "e": 19971,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 25177,
      "e": 23618,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "85"
    },
    {
      "t": 25179,
      "e": 23620,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 25321,
      "e": 23762,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||u"
    },
    {
      "t": 25722,
      "e": 24163,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "78"
    },
    {
      "t": 25722,
      "e": 24163,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 25849,
      "e": 24290,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||n"
    },
    {
      "t": 25946,
      "e": 24387,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 25946,
      "e": 24387,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 26049,
      "e": 24490,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "73"
    },
    {
      "t": 26049,
      "e": 24490,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 26057,
      "e": 24498,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||ti"
    },
    {
      "t": 26145,
      "e": 24586,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 26266,
      "e": 24707,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "76"
    },
    {
      "t": 26266,
      "e": 24707,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 26369,
      "e": 24810,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 26370,
      "e": 24811,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 26393,
      "e": 24834,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||l "
    },
    {
      "t": 26473,
      "e": 24914,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 26538,
      "e": 24979,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "89"
    },
    {
      "t": 26538,
      "e": 24979,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 26601,
      "e": 25042,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "79"
    },
    {
      "t": 26601,
      "e": 25042,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 26633,
      "e": 25074,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||yo"
    },
    {
      "t": 26713,
      "e": 25154,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 26754,
      "e": 25195,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "85"
    },
    {
      "t": 26754,
      "e": 25195,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 26802,
      "e": 25243,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||u"
    },
    {
      "t": 26850,
      "e": 25291,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 26850,
      "e": 25291,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 26920,
      "e": 25361,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 27082,
      "e": 25523,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "72"
    },
    {
      "t": 27082,
      "e": 25523,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 27193,
      "e": 25634,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "73"
    },
    {
      "t": 27193,
      "e": 25634,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 27217,
      "e": 25658,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||hi"
    },
    {
      "t": 27281,
      "e": 25722,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 27281,
      "e": 25722,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 27329,
      "e": 25770,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 27417,
      "e": 25858,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 27610,
      "e": 26051,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 27610,
      "e": 26051,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 27682,
      "e": 26123,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 27802,
      "e": 26243,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "look at the x axis until you hit "
    },
    {
      "t": 28081,
      "e": 26522,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "49"
    },
    {
      "t": 28082,
      "e": 26523,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 28193,
      "e": 26634,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "50"
    },
    {
      "t": 28193,
      "e": 26634,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 28233,
      "e": 26674,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||12"
    },
    {
      "t": 28313,
      "e": 26754,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 28562,
      "e": 27003,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "80"
    },
    {
      "t": 28563,
      "e": 27004,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 28777,
      "e": 27218,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||p"
    },
    {
      "t": 28786,
      "e": 27227,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "77"
    },
    {
      "t": 28786,
      "e": 27227,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 28921,
      "e": 27362,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||m"
    },
    {
      "t": 28953,
      "e": 27394,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 28953,
      "e": 27394,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 29033,
      "e": 27474,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 29197,
      "e": 27638,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 29198,
      "e": 27639,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 29316,
      "e": 27757,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||a"
    },
    {
      "t": 29348,
      "e": 27789,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "78"
    },
    {
      "t": 29348,
      "e": 27789,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 29436,
      "e": 27877,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||n"
    },
    {
      "t": 29525,
      "e": 27966,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "68"
    },
    {
      "t": 29526,
      "e": 27967,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 29660,
      "e": 28101,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 29660,
      "e": 28101,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 29668,
      "e": 28109,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||d "
    },
    {
      "t": 29772,
      "e": 28213,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 29894,
      "e": 28335,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 29894,
      "e": 28335,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 29988,
      "e": 28429,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 29996,
      "e": 28437,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "72"
    },
    {
      "t": 29996,
      "e": 28437,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 30004,
      "e": 28445,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 30076,
      "e": 28517,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||h"
    },
    {
      "t": 30132,
      "e": 28573,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 30133,
      "e": 28574,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 30236,
      "e": 28677,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "78"
    },
    {
      "t": 30236,
      "e": 28677,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 30260,
      "e": 28701,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||en"
    },
    {
      "t": 30292,
      "e": 28733,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 30292,
      "e": 28733,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 30324,
      "e": 28765,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 30436,
      "e": 28877,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 31301,
      "e": 29742,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "76"
    },
    {
      "t": 31302,
      "e": 29743,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 31365,
      "e": 29806,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||l"
    },
    {
      "t": 31501,
      "e": 29942,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "79"
    },
    {
      "t": 31502,
      "e": 29943,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 31556,
      "e": 29997,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||o"
    },
    {
      "t": 31644,
      "e": 30085,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "79"
    },
    {
      "t": 31644,
      "e": 30085,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 31732,
      "e": 30173,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||o"
    },
    {
      "t": 31781,
      "e": 30222,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "75"
    },
    {
      "t": 31782,
      "e": 30223,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 31893,
      "e": 30334,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||k"
    },
    {
      "t": 32109,
      "e": 30550,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 32110,
      "e": 30551,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 32164,
      "e": 30605,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 32300,
      "e": 30741,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "85"
    },
    {
      "t": 32300,
      "e": 30741,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 32372,
      "e": 30813,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||u"
    },
    {
      "t": 32524,
      "e": 30965,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "80"
    },
    {
      "t": 32524,
      "e": 30965,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 32613,
      "e": 31054,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||p"
    },
    {
      "t": 32637,
      "e": 31078,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 32637,
      "e": 31078,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 32708,
      "e": 31149,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 33141,
      "e": 31582,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "20"
    },
    {
      "t": 33236,
      "e": 31677,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 33389,
      "e": 31830,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 33390,
      "e": 31831,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 33484,
      "e": 31925,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||T"
    },
    {
      "t": 33907,
      "e": 32348,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 33980,
      "e": 32421,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "look at the x axis until you hit 12pm and then look up "
    },
    {
      "t": 34565,
      "e": 33006,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 34565,
      "e": 33006,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 34675,
      "e": 33116,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||A"
    },
    {
      "t": 35381,
      "e": 33822,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "20"
    },
    {
      "t": 35484,
      "e": 33925,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 35700,
      "e": 34141,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 35701,
      "e": 34142,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 35772,
      "e": 34213,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||a"
    },
    {
      "t": 35772,
      "e": 34213,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 35884,
      "e": 34325,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "look at the x axis until you hit 12pm and then look up A"
    },
    {
      "t": 36125,
      "e": 34566,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 36204,
      "e": 34645,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "look at the x axis until you hit 12pm and then look up "
    },
    {
      "t": 36308,
      "e": 34749,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 36309,
      "e": 34750,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 36412,
      "e": 34853,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||a"
    },
    {
      "t": 36477,
      "e": 34918,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 36477,
      "e": 34918,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 36588,
      "e": 35029,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 36684,
      "e": 35125,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 36685,
      "e": 35126,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 36780,
      "e": 35221,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 37013,
      "e": 35454,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "72"
    },
    {
      "t": 37014,
      "e": 35455,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 37123,
      "e": 35564,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||h"
    },
    {
      "t": 37189,
      "e": 35630,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 37189,
      "e": 35630,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 37285,
      "e": 35726,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||e"
    },
    {
      "t": 37565,
      "e": 36006,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 37612,
      "e": 36053,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "look at the x axis until you hit 12pm and then look up at h"
    },
    {
      "t": 37741,
      "e": 36182,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 37764,
      "e": 36205,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "look at the x axis until you hit 12pm and then look up at "
    },
    {
      "t": 37989,
      "e": 36430,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 37989,
      "e": 36430,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 38068,
      "e": 36509,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 38108,
      "e": 36549,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "72"
    },
    {
      "t": 38108,
      "e": 36549,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 38228,
      "e": 36669,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||h"
    },
    {
      "t": 38236,
      "e": 36677,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 38237,
      "e": 36678,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 38380,
      "e": 36821,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||e"
    },
    {
      "t": 38421,
      "e": 36862,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 38421,
      "e": 36862,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 38476,
      "e": 36917,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 38605,
      "e": 37046,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "look at the x axis until you hit 12pm and then look up at the "
    },
    {
      "t": 38878,
      "e": 37048,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "68"
    },
    {
      "t": 38879,
      "e": 37049,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 38996,
      "e": 37166,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||d"
    },
    {
      "t": 39012,
      "e": 37182,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "79"
    },
    {
      "t": 39013,
      "e": 37183,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 39133,
      "e": 37303,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||o"
    },
    {
      "t": 39159,
      "e": 37329,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 39160,
      "e": 37330,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 39236,
      "e": 37406,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 39413,
      "e": 37583,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "83"
    },
    {
      "t": 39413,
      "e": 37583,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 39500,
      "e": 37670,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||s"
    },
    {
      "t": 39500,
      "e": 37670,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 39500,
      "e": 37670,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 39580,
      "e": 37750,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 39829,
      "e": 37999,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 39830,
      "e": 38000,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 39900,
      "e": 38070,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 39924,
      "e": 38094,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "72"
    },
    {
      "t": 39924,
      "e": 38094,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 40012,
      "e": 38182,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||h"
    },
    {
      "t": 40093,
      "e": 38263,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 40094,
      "e": 38264,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 40165,
      "e": 38335,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 40167,
      "e": 38337,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 40212,
      "e": 38382,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||at"
    },
    {
      "t": 40252,
      "e": 38422,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 40268,
      "e": 38438,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 40268,
      "e": 38438,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 40348,
      "e": 38518,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 41125,
      "e": 39295,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "76"
    },
    {
      "t": 41126,
      "e": 39296,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 41204,
      "e": 39374,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||l"
    },
    {
      "t": 41388,
      "e": 39558,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "73"
    },
    {
      "t": 41389,
      "e": 39559,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 41491,
      "e": 39661,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||i"
    },
    {
      "t": 41548,
      "e": 39718,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 41548,
      "e": 39718,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 41660,
      "e": 39830,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||e"
    },
    {
      "t": 41932,
      "e": 40102,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 41934,
      "e": 40104,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 42012,
      "e": 40182,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 42180,
      "e": 40350,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "79"
    },
    {
      "t": 42181,
      "e": 40351,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 42324,
      "e": 40494,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||o"
    },
    {
      "t": 42332,
      "e": 40502,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "78"
    },
    {
      "t": 42332,
      "e": 40502,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 42372,
      "e": 40542,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 42373,
      "e": 40543,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 42404,
      "e": 40574,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||n "
    },
    {
      "t": 42493,
      "e": 40663,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 42693,
      "e": 40863,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "73"
    },
    {
      "t": 42694,
      "e": 40864,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 42771,
      "e": 40941,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 42771,
      "e": 40941,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 42780,
      "e": 40950,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||it"
    },
    {
      "t": 42868,
      "e": 41038,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 43403,
      "e": 41573,
      "ty": 2,
      "x": 1917,
      "y": 1215
    },
    {
      "t": 43503,
      "e": 41673,
      "ty": 2,
      "x": 1731,
      "y": 1186
    },
    {
      "t": 43504,
      "e": 41674,
      "ty": 41,
      "x": 59336,
      "y": 65258,
      "ta": "> div.stimulus"
    },
    {
      "t": 43603,
      "e": 41773,
      "ty": 2,
      "x": 1228,
      "y": 1215
    },
    {
      "t": 43703,
      "e": 41873,
      "ty": 2,
      "x": 1091,
      "y": 1215
    },
    {
      "t": 43753,
      "e": 41923,
      "ty": 41,
      "x": 36503,
      "y": 64704,
      "ta": "> div.stimulus"
    },
    {
      "t": 43803,
      "e": 41973,
      "ty": 2,
      "x": 597,
      "y": 452
    },
    {
      "t": 43903,
      "e": 42073,
      "ty": 2,
      "x": 0,
      "y": 16
    },
    {
      "t": 44003,
      "e": 42173,
      "ty": 41,
      "x": 0,
      "y": 886,
      "ta": "html"
    },
    {
      "t": 44103,
      "e": 42273,
      "ty": 2,
      "x": 109,
      "y": 58
    },
    {
      "t": 44191,
      "e": 42361,
      "ty": 6,
      "x": 544,
      "y": 556,
      "ta": "#strategyAnswer"
    },
    {
      "t": 44203,
      "e": 42373,
      "ty": 2,
      "x": 544,
      "y": 556
    },
    {
      "t": 44253,
      "e": 42423,
      "ty": 41,
      "x": 50686,
      "y": 30150,
      "ta": "#strategyAnswer"
    },
    {
      "t": 44303,
      "e": 42473,
      "ty": 2,
      "x": 548,
      "y": 560
    },
    {
      "t": 44358,
      "e": 42528,
      "ty": 7,
      "x": 421,
      "y": 626,
      "ta": "#strategyAnswer"
    },
    {
      "t": 44403,
      "e": 42573,
      "ty": 2,
      "x": 330,
      "y": 664
    },
    {
      "t": 44503,
      "e": 42673,
      "ty": 2,
      "x": 308,
      "y": 688
    },
    {
      "t": 44503,
      "e": 42673,
      "ty": 41,
      "x": 23707,
      "y": 37670,
      "ta": "> div.stimulus > div"
    },
    {
      "t": 44603,
      "e": 42773,
      "ty": 2,
      "x": 308,
      "y": 689
    },
    {
      "t": 44659,
      "e": 42829,
      "ty": 6,
      "x": 347,
      "y": 686,
      "ta": "#strategyButton"
    },
    {
      "t": 44703,
      "e": 42873,
      "ty": 2,
      "x": 349,
      "y": 685
    },
    {
      "t": 44753,
      "e": 42923,
      "ty": 41,
      "x": 7867,
      "y": 56409,
      "ta": "#strategyButton"
    },
    {
      "t": 44803,
      "e": 42973,
      "ty": 2,
      "x": 357,
      "y": 684
    },
    {
      "t": 44840,
      "e": 43010,
      "ty": 3,
      "x": 360,
      "y": 684,
      "ta": "#strategyButton"
    },
    {
      "t": 44842,
      "e": 43012,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "look at the x axis until you hit 12pm and then look up at the dots that lie on it"
    },
    {
      "t": 44842,
      "e": 43012,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 44842,
      "e": 43012,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#strategyButton"
    },
    {
      "t": 44903,
      "e": 43073,
      "ty": 2,
      "x": 360,
      "y": 684
    },
    {
      "t": 44920,
      "e": 43090,
      "ty": 4,
      "x": 11690,
      "y": 56409,
      "ta": "#strategyButton"
    },
    {
      "t": 44929,
      "e": 43099,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#strategyButton"
    },
    {
      "t": 44932,
      "e": 43102,
      "ty": 5,
      "x": 360,
      "y": 684,
      "ta": "#strategyButton"
    },
    {
      "t": 44941,
      "e": 43111,
      "ty": 38,
      "x": 1,
      "y": 0
    },
    {
      "t": 45003,
      "e": 43173,
      "ty": 41,
      "x": 12122,
      "y": 37448,
      "ta": "html > body"
    },
    {
      "t": 45204,
      "e": 43374,
      "ty": 2,
      "x": 387,
      "y": 646
    },
    {
      "t": 45253,
      "e": 43423,
      "ty": 41,
      "x": 13051,
      "y": 35343,
      "ta": "html > body"
    },
    {
      "t": 45939,
      "e": 44109,
      "ty": 38,
      "x": 2,
      "y": 0
    },
    {
      "t": 46103,
      "e": 44273,
      "ty": 2,
      "x": 387,
      "y": 648
    },
    {
      "t": 46203,
      "e": 44373,
      "ty": 2,
      "x": 390,
      "y": 649
    },
    {
      "t": 46253,
      "e": 44423,
      "ty": 41,
      "x": 13155,
      "y": 35509,
      "ta": "html > body"
    },
    {
      "t": 46403,
      "e": 44573,
      "ty": 2,
      "x": 420,
      "y": 630
    },
    {
      "t": 46503,
      "e": 44673,
      "ty": 2,
      "x": 856,
      "y": 510
    },
    {
      "t": 46503,
      "e": 44673,
      "ty": 41,
      "x": 10381,
      "y": 4681,
      "ta": "#jspsych-survey-text-0 > p"
    },
    {
      "t": 46603,
      "e": 44773,
      "ty": 2,
      "x": 1169,
      "y": 454
    },
    {
      "t": 46703,
      "e": 44873,
      "ty": 2,
      "x": 1186,
      "y": 452
    },
    {
      "t": 46753,
      "e": 44923,
      "ty": 41,
      "x": 39706,
      "y": 27089,
      "ta": "html > body"
    },
    {
      "t": 46803,
      "e": 44973,
      "ty": 2,
      "x": 1142,
      "y": 525
    },
    {
      "t": 46903,
      "e": 45073,
      "ty": 2,
      "x": 1110,
      "y": 532
    },
    {
      "t": 47003,
      "e": 45173,
      "ty": 2,
      "x": 1078,
      "y": 550
    },
    {
      "t": 47003,
      "e": 45173,
      "ty": 41,
      "x": 58397,
      "y": 42280,
      "ta": "#jspsych-survey-text-0"
    },
    {
      "t": 47045,
      "e": 45215,
      "ty": 6,
      "x": 1067,
      "y": 555,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 47103,
      "e": 45273,
      "ty": 2,
      "x": 1057,
      "y": 561
    },
    {
      "t": 47203,
      "e": 45373,
      "ty": 2,
      "x": 1050,
      "y": 565
    },
    {
      "t": 47253,
      "e": 45423,
      "ty": 41,
      "x": 52125,
      "y": 34327,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 47265,
      "e": 45435,
      "ty": 3,
      "x": 1049,
      "y": 565,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 47265,
      "e": 45435,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 47304,
      "e": 45474,
      "ty": 2,
      "x": 1049,
      "y": 565
    },
    {
      "t": 47336,
      "e": 45506,
      "ty": 4,
      "x": 52125,
      "y": 34327,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 47336,
      "e": 45506,
      "ty": 5,
      "x": 1049,
      "y": 565,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 48069,
      "e": 45508,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "50"
    },
    {
      "t": 48069,
      "e": 45508,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 48124,
      "e": 45563,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "49"
    },
    {
      "t": 48124,
      "e": 45563,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 48205,
      "e": 45644,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "21"
    },
    {
      "t": 48269,
      "e": 45708,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "21"
    },
    {
      "t": 48379,
      "e": 45818,
      "ty": 7,
      "x": 1043,
      "y": 575,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 48403,
      "e": 45842,
      "ty": 2,
      "x": 1034,
      "y": 594
    },
    {
      "t": 48504,
      "e": 45943,
      "ty": 2,
      "x": 1018,
      "y": 635
    },
    {
      "t": 48504,
      "e": 45943,
      "ty": 41,
      "x": 45420,
      "y": 36643,
      "ta": "#jspsych-survey-text-1"
    },
    {
      "t": 48603,
      "e": 46042,
      "ty": 2,
      "x": 1015,
      "y": 644
    },
    {
      "t": 48681,
      "e": 46120,
      "ty": 6,
      "x": 1015,
      "y": 647,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 48704,
      "e": 46143,
      "ty": 2,
      "x": 1015,
      "y": 647
    },
    {
      "t": 48754,
      "e": 46193,
      "ty": 41,
      "x": 44771,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 48804,
      "e": 46243,
      "ty": 2,
      "x": 1013,
      "y": 653
    },
    {
      "t": 48812,
      "e": 46251,
      "ty": 7,
      "x": 1007,
      "y": 668,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 48828,
      "e": 46267,
      "ty": 6,
      "x": 1001,
      "y": 684,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 48903,
      "e": 46342,
      "ty": 2,
      "x": 1000,
      "y": 685
    },
    {
      "t": 49004,
      "e": 46443,
      "ty": 2,
      "x": 997,
      "y": 679
    },
    {
      "t": 49004,
      "e": 46443,
      "ty": 41,
      "x": 52094,
      "y": 5957,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 49045,
      "e": 46484,
      "ty": 7,
      "x": 997,
      "y": 673,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 49094,
      "e": 46533,
      "ty": 6,
      "x": 995,
      "y": 666,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 49104,
      "e": 46543,
      "ty": 2,
      "x": 995,
      "y": 666
    },
    {
      "t": 49203,
      "e": 46642,
      "ty": 2,
      "x": 995,
      "y": 650
    },
    {
      "t": 49253,
      "e": 46692,
      "ty": 41,
      "x": 40445,
      "y": 3120,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 49265,
      "e": 46704,
      "ty": 3,
      "x": 995,
      "y": 648,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 49266,
      "e": 46705,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "21"
    },
    {
      "t": 49266,
      "e": 46705,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 49266,
      "e": 46705,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 49303,
      "e": 46742,
      "ty": 2,
      "x": 995,
      "y": 648
    },
    {
      "t": 49384,
      "e": 46823,
      "ty": 4,
      "x": 40445,
      "y": 3120,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 49384,
      "e": 46823,
      "ty": 5,
      "x": 995,
      "y": 648,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 49503,
      "e": 46942,
      "ty": 2,
      "x": 996,
      "y": 648
    },
    {
      "t": 49504,
      "e": 46943,
      "ty": 41,
      "x": 40661,
      "y": 3120,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 49957,
      "e": 47396,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "16"
    },
    {
      "t": 50228,
      "e": 47667,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "85"
    },
    {
      "t": 50229,
      "e": 47668,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 50315,
      "e": 47754,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "83"
    },
    {
      "t": 50316,
      "e": 47755,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 50340,
      "e": 47779,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "US"
    },
    {
      "t": 50388,
      "e": 47827,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "US"
    },
    {
      "t": 50468,
      "e": 47907,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "65"
    },
    {
      "t": 50469,
      "e": 47908,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 50564,
      "e": 48003,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "USA"
    },
    {
      "t": 50611,
      "e": 48050,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "USA"
    },
    {
      "t": 50797,
      "e": 48236,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "13"
    },
    {
      "t": 50797,
      "e": 48236,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 50859,
      "e": 48298,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "USA\n"
    },
    {
      "t": 52404,
      "e": 49843,
      "ty": 2,
      "x": 996,
      "y": 666
    },
    {
      "t": 52413,
      "e": 49852,
      "ty": 7,
      "x": 996,
      "y": 672,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 52431,
      "e": 49870,
      "ty": 6,
      "x": 996,
      "y": 676,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 52503,
      "e": 49942,
      "ty": 2,
      "x": 996,
      "y": 680
    },
    {
      "t": 52503,
      "e": 49942,
      "ty": 41,
      "x": 51579,
      "y": 7943,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 52603,
      "e": 50042,
      "ty": 2,
      "x": 998,
      "y": 701
    },
    {
      "t": 52640,
      "e": 50079,
      "ty": 3,
      "x": 998,
      "y": 702,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 52641,
      "e": 50080,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "USA\n"
    },
    {
      "t": 52642,
      "e": 50081,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 52643,
      "e": 50082,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 52704,
      "e": 50143,
      "ty": 2,
      "x": 998,
      "y": 702
    },
    {
      "t": 52711,
      "e": 50150,
      "ty": 4,
      "x": 52609,
      "y": 51633,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 52713,
      "e": 50152,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 52713,
      "e": 50152,
      "ty": 5,
      "x": 998,
      "y": 702,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 52714,
      "e": 50153,
      "ty": 38,
      "x": 3,
      "y": 0
    },
    {
      "t": 52753,
      "e": 50192,
      "ty": 41,
      "x": 34093,
      "y": 38445,
      "ta": "html > body"
    },
    {
      "t": 53203,
      "e": 50642,
      "ty": 2,
      "x": 998,
      "y": 696
    },
    {
      "t": 53253,
      "e": 50692,
      "ty": 41,
      "x": 34127,
      "y": 37005,
      "ta": "html > body"
    },
    {
      "t": 53304,
      "e": 50743,
      "ty": 2,
      "x": 999,
      "y": 672
    },
    {
      "t": 53404,
      "e": 50843,
      "ty": 2,
      "x": 999,
      "y": 666
    },
    {
      "t": 53504,
      "e": 50943,
      "ty": 2,
      "x": 999,
      "y": 663
    },
    {
      "t": 53504,
      "e": 50943,
      "ty": 41,
      "x": 34127,
      "y": 36285,
      "ta": "html > body"
    },
    {
      "t": 53735,
      "e": 51174,
      "ty": 38,
      "x": 4,
      "y": 0
    },
    {
      "t": 53754,
      "e": 51193,
      "ty": 41,
      "x": 42143,
      "y": 11915,
      "ta": "#jspsych-survey-multi-choice-2"
    },
    {
      "t": 53804,
      "e": 51243,
      "ty": 2,
      "x": 1002,
      "y": 652
    },
    {
      "t": 53903,
      "e": 51342,
      "ty": 2,
      "x": 1004,
      "y": 646
    },
    {
      "t": 54004,
      "e": 51443,
      "ty": 2,
      "x": 1005,
      "y": 645
    },
    {
      "t": 54004,
      "e": 51443,
      "ty": 41,
      "x": 43567,
      "y": 8124,
      "ta": "#jspsych-survey-multi-choice-2"
    },
    {
      "t": 54254,
      "e": 51693,
      "ty": 41,
      "x": 41669,
      "y": 49151,
      "ta": "#jspsych-survey-multi-choice-2 > p"
    },
    {
      "t": 54303,
      "e": 51742,
      "ty": 2,
      "x": 983,
      "y": 583
    },
    {
      "t": 54404,
      "e": 51843,
      "ty": 2,
      "x": 994,
      "y": 187
    },
    {
      "t": 54503,
      "e": 51942,
      "ty": 2,
      "x": 976,
      "y": 90
    },
    {
      "t": 54503,
      "e": 51942,
      "ty": 41,
      "x": 33335,
      "y": 4542,
      "ta": "html > body"
    },
    {
      "t": 54604,
      "e": 52043,
      "ty": 2,
      "x": 962,
      "y": 75
    },
    {
      "t": 54703,
      "e": 52142,
      "ty": 2,
      "x": 953,
      "y": 155
    },
    {
      "t": 54754,
      "e": 52193,
      "ty": 41,
      "x": 30752,
      "y": 373,
      "ta": "#jspsych-survey-multi-choice-form"
    },
    {
      "t": 54803,
      "e": 52242,
      "ty": 2,
      "x": 936,
      "y": 194
    },
    {
      "t": 54904,
      "e": 52343,
      "ty": 2,
      "x": 888,
      "y": 237
    },
    {
      "t": 55004,
      "e": 52443,
      "ty": 2,
      "x": 880,
      "y": 238
    },
    {
      "t": 55004,
      "e": 52443,
      "ty": 41,
      "x": 47967,
      "y": 29490,
      "ta": "#jspsych-survey-multi-choice-option-0-0 > label"
    },
    {
      "t": 55065,
      "e": 52504,
      "ty": 3,
      "x": 880,
      "y": 238,
      "ta": "#jspsych-survey-multi-choice-option-0-0 > label"
    },
    {
      "t": 55136,
      "e": 52575,
      "ty": 4,
      "x": 47967,
      "y": 29490,
      "ta": "#jspsych-survey-multi-choice-option-0-0 > label"
    },
    {
      "t": 55136,
      "e": 52575,
      "ty": 5,
      "x": 880,
      "y": 238,
      "ta": "#jspsych-survey-multi-choice-option-0-0 > label"
    },
    {
      "t": 55136,
      "e": 52575,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-0[0]_mf"
    },
    {
      "t": 55137,
      "e": 52576,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-0[0]_mf",
      "v": "English"
    },
    {
      "t": 55403,
      "e": 52842,
      "ty": 2,
      "x": 891,
      "y": 271
    },
    {
      "t": 55503,
      "e": 52942,
      "ty": 2,
      "x": 908,
      "y": 325
    },
    {
      "t": 55505,
      "e": 52944,
      "ty": 41,
      "x": 20547,
      "y": 37448,
      "ta": "#jspsych-survey-multi-choice-option-0-3"
    },
    {
      "t": 55604,
      "e": 53043,
      "ty": 2,
      "x": 927,
      "y": 383
    },
    {
      "t": 55703,
      "e": 53142,
      "ty": 2,
      "x": 931,
      "y": 412
    },
    {
      "t": 55754,
      "e": 53193,
      "ty": 41,
      "x": 24581,
      "y": 56172,
      "ta": "#jspsych-survey-multi-choice-option-1-0"
    },
    {
      "t": 55803,
      "e": 53242,
      "ty": 2,
      "x": 913,
      "y": 437
    },
    {
      "t": 55904,
      "e": 53343,
      "ty": 2,
      "x": 894,
      "y": 441
    },
    {
      "t": 56004,
      "e": 53443,
      "ty": 2,
      "x": 876,
      "y": 446
    },
    {
      "t": 56004,
      "e": 53443,
      "ty": 41,
      "x": 43594,
      "y": 42597,
      "ta": "#jspsych-survey-multi-choice-option-1-1 > label"
    },
    {
      "t": 56104,
      "e": 53543,
      "ty": 2,
      "x": 870,
      "y": 455
    },
    {
      "t": 56204,
      "e": 53643,
      "ty": 2,
      "x": 868,
      "y": 464
    },
    {
      "t": 56254,
      "e": 53693,
      "ty": 41,
      "x": 48176,
      "y": 16383,
      "ta": "#jspsych-survey-multi-choice-option-1-2 > label"
    },
    {
      "t": 56303,
      "e": 53742,
      "ty": 2,
      "x": 867,
      "y": 466
    },
    {
      "t": 56404,
      "e": 53843,
      "ty": 2,
      "x": 866,
      "y": 471
    },
    {
      "t": 56465,
      "e": 53904,
      "ty": 3,
      "x": 866,
      "y": 471,
      "ta": "#jspsych-survey-multi-choice-option-1-2 > label"
    },
    {
      "t": 56466,
      "e": 53905,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-0[0]_mf"
    },
    {
      "t": 56503,
      "e": 53942,
      "ty": 41,
      "x": 47119,
      "y": 32767,
      "ta": "#jspsych-survey-multi-choice-option-1-2 > label"
    },
    {
      "t": 56567,
      "e": 54006,
      "ty": 4,
      "x": 47119,
      "y": 32767,
      "ta": "#jspsych-survey-multi-choice-option-1-2 > label"
    },
    {
      "t": 56567,
      "e": 54006,
      "ty": 5,
      "x": 866,
      "y": 471,
      "ta": "#jspsych-survey-multi-choice-option-1-2 > label"
    },
    {
      "t": 56569,
      "e": 54008,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-1[2]_mf"
    },
    {
      "t": 56569,
      "e": 54008,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-1[2]_mf",
      "v": "Third"
    },
    {
      "t": 56753,
      "e": 54192,
      "ty": 41,
      "x": 48088,
      "y": 3276,
      "ta": "#jspsych-survey-multi-choice-option-1-3 > label"
    },
    {
      "t": 56804,
      "e": 54243,
      "ty": 2,
      "x": 905,
      "y": 510
    },
    {
      "t": 56903,
      "e": 54342,
      "ty": 2,
      "x": 970,
      "y": 577
    },
    {
      "t": 57003,
      "e": 54442,
      "ty": 2,
      "x": 984,
      "y": 629
    },
    {
      "t": 57004,
      "e": 54443,
      "ty": 41,
      "x": 38583,
      "y": 32767,
      "ta": "#jspsych-survey-multi-choice-2 > p"
    },
    {
      "t": 57104,
      "e": 54543,
      "ty": 2,
      "x": 978,
      "y": 643
    },
    {
      "t": 57204,
      "e": 54643,
      "ty": 2,
      "x": 944,
      "y": 680
    },
    {
      "t": 57254,
      "e": 54693,
      "ty": 41,
      "x": 31569,
      "y": 49151,
      "ta": "#jspsych-survey-multi-choice-option-2-0 > label"
    },
    {
      "t": 57303,
      "e": 54742,
      "ty": 2,
      "x": 937,
      "y": 680
    },
    {
      "t": 57404,
      "e": 54843,
      "ty": 2,
      "x": 933,
      "y": 683
    },
    {
      "t": 57503,
      "e": 54942,
      "ty": 2,
      "x": 933,
      "y": 689
    },
    {
      "t": 57503,
      "e": 54942,
      "ty": 41,
      "x": 26480,
      "y": 0,
      "ta": "#jspsych-survey-multi-choice-option-2-1"
    },
    {
      "t": 57604,
      "e": 55043,
      "ty": 2,
      "x": 933,
      "y": 692
    },
    {
      "t": 57704,
      "e": 55143,
      "ty": 2,
      "x": 931,
      "y": 694
    },
    {
      "t": 57753,
      "e": 55192,
      "ty": 41,
      "x": 27611,
      "y": 26214,
      "ta": "#jspsych-survey-multi-choice-option-2-1 > label"
    },
    {
      "t": 57803,
      "e": 55242,
      "ty": 2,
      "x": 934,
      "y": 727
    },
    {
      "t": 57904,
      "e": 55343,
      "ty": 2,
      "x": 935,
      "y": 743
    },
    {
      "t": 58003,
      "e": 55442,
      "ty": 2,
      "x": 931,
      "y": 755
    },
    {
      "t": 58004,
      "e": 55443,
      "ty": 41,
      "x": 45721,
      "y": 19660,
      "ta": "#jspsych-survey-multi-choice-option-2-3 > label"
    },
    {
      "t": 58103,
      "e": 55542,
      "ty": 2,
      "x": 924,
      "y": 777
    },
    {
      "t": 58205,
      "e": 55644,
      "ty": 2,
      "x": 921,
      "y": 786
    },
    {
      "t": 58255,
      "e": 55645,
      "ty": 41,
      "x": 55186,
      "y": 29490,
      "ta": "#jspsych-survey-multi-choice-option-2-4 > label"
    },
    {
      "t": 58304,
      "e": 55694,
      "ty": 2,
      "x": 917,
      "y": 792
    },
    {
      "t": 58403,
      "e": 55793,
      "ty": 2,
      "x": 904,
      "y": 822
    },
    {
      "t": 58502,
      "e": 55892,
      "ty": 2,
      "x": 902,
      "y": 829
    },
    {
      "t": 58503,
      "e": 55893,
      "ty": 41,
      "x": 19123,
      "y": 0,
      "ta": "#jspsych-survey-multi-choice-option-2-6"
    },
    {
      "t": 59203,
      "e": 56593,
      "ty": 2,
      "x": 896,
      "y": 779
    },
    {
      "t": 59253,
      "e": 56643,
      "ty": 41,
      "x": 17699,
      "y": 7021,
      "ta": "#jspsych-survey-multi-choice-option-2-4"
    },
    {
      "t": 59303,
      "e": 56693,
      "ty": 2,
      "x": 896,
      "y": 776
    },
    {
      "t": 59403,
      "e": 56793,
      "ty": 2,
      "x": 896,
      "y": 775
    },
    {
      "t": 59503,
      "e": 56893,
      "ty": 2,
      "x": 896,
      "y": 765
    },
    {
      "t": 59503,
      "e": 56893,
      "ty": 41,
      "x": 31118,
      "y": 52428,
      "ta": "#jspsych-survey-multi-choice-option-2-3 > label"
    },
    {
      "t": 59602,
      "e": 56992,
      "ty": 2,
      "x": 896,
      "y": 756
    },
    {
      "t": 59703,
      "e": 57093,
      "ty": 2,
      "x": 898,
      "y": 745
    },
    {
      "t": 59752,
      "e": 57142,
      "ty": 41,
      "x": 19722,
      "y": 55704,
      "ta": "#jspsych-survey-multi-choice-option-2-2 > label"
    },
    {
      "t": 59803,
      "e": 57193,
      "ty": 2,
      "x": 900,
      "y": 734
    },
    {
      "t": 59903,
      "e": 57293,
      "ty": 2,
      "x": 903,
      "y": 723
    },
    {
      "t": 60003,
      "e": 57393,
      "ty": 41,
      "x": 22320,
      "y": 58981,
      "ta": "#jspsych-survey-multi-choice-option-2-1 > label"
    },
    {
      "t": 60003,
      "e": 57393,
      "ty": 2,
      "x": 910,
      "y": 711
    },
    {
      "t": 60102,
      "e": 57492,
      "ty": 2,
      "x": 912,
      "y": 704
    },
    {
      "t": 60203,
      "e": 57593,
      "ty": 2,
      "x": 913,
      "y": 701
    },
    {
      "t": 60253,
      "e": 57643,
      "ty": 41,
      "x": 23076,
      "y": 26214,
      "ta": "#jspsych-survey-multi-choice-option-2-1 > label"
    },
    {
      "t": 61472,
      "e": 58862,
      "ty": 3,
      "x": 913,
      "y": 701,
      "ta": "#jspsych-survey-multi-choice-option-2-1 > label"
    },
    {
      "t": 61472,
      "e": 58862,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-1[2]_mf"
    },
    {
      "t": 61583,
      "e": 58973,
      "ty": 4,
      "x": 23076,
      "y": 26214,
      "ta": "#jspsych-survey-multi-choice-option-2-1 > label"
    },
    {
      "t": 61584,
      "e": 58974,
      "ty": 5,
      "x": 913,
      "y": 701,
      "ta": "#jspsych-survey-multi-choice-option-2-1 > label"
    },
    {
      "t": 61584,
      "e": 58974,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-2[1]_mf"
    },
    {
      "t": 61584,
      "e": 58974,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-2[1]_mf",
      "v": "Social Sciences (incl. CogSci)"
    },
    {
      "t": 65002,
      "e": 62392,
      "ty": 2,
      "x": 908,
      "y": 728
    },
    {
      "t": 65003,
      "e": 62393,
      "ty": 41,
      "x": 21729,
      "y": 22937,
      "ta": "#jspsych-survey-multi-choice-option-2-2 > label"
    },
    {
      "t": 65103,
      "e": 62493,
      "ty": 2,
      "x": 904,
      "y": 742
    },
    {
      "t": 65253,
      "e": 62643,
      "ty": 41,
      "x": 19597,
      "y": 58513,
      "ta": "#jspsych-survey-multi-choice-option-2-2"
    },
    {
      "t": 65503,
      "e": 62893,
      "ty": 2,
      "x": 898,
      "y": 792
    },
    {
      "t": 65503,
      "e": 62893,
      "ty": 41,
      "x": 42870,
      "y": 49151,
      "ta": "#jspsych-survey-multi-choice-option-2-4 > label"
    },
    {
      "t": 65603,
      "e": 62993,
      "ty": 2,
      "x": 883,
      "y": 909
    },
    {
      "t": 65703,
      "e": 63093,
      "ty": 2,
      "x": 876,
      "y": 958
    },
    {
      "t": 65753,
      "e": 63143,
      "ty": 41,
      "x": 43340,
      "y": 26214,
      "ta": "#jspsych-survey-multi-choice-option-3-1 > label"
    },
    {
      "t": 65803,
      "e": 63193,
      "ty": 2,
      "x": 875,
      "y": 961
    },
    {
      "t": 65929,
      "e": 63319,
      "ty": 3,
      "x": 875,
      "y": 961,
      "ta": "#jspsych-survey-multi-choice-option-3-1 > label"
    },
    {
      "t": 65930,
      "e": 63320,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-2[1]_mf"
    },
    {
      "t": 66007,
      "e": 63397,
      "ty": 4,
      "x": 43340,
      "y": 26214,
      "ta": "#jspsych-survey-multi-choice-option-3-1 > label"
    },
    {
      "t": 66007,
      "e": 63397,
      "ty": 5,
      "x": 875,
      "y": 961,
      "ta": "#jspsych-survey-multi-choice-option-3-1 > label"
    },
    {
      "t": 66007,
      "e": 63397,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-3[1]_mf"
    },
    {
      "t": 66008,
      "e": 63398,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-3[1]_mf",
      "v": "Female"
    },
    {
      "t": 66203,
      "e": 63593,
      "ty": 2,
      "x": 874,
      "y": 973
    },
    {
      "t": 66253,
      "e": 63643,
      "ty": 41,
      "x": 58151,
      "y": 58981,
      "ta": "#jspsych-survey-multi-choice-option-3-2 > label"
    },
    {
      "t": 66303,
      "e": 63693,
      "ty": 2,
      "x": 882,
      "y": 1004
    },
    {
      "t": 66393,
      "e": 63783,
      "ty": 3,
      "x": 882,
      "y": 1004,
      "ta": "#jspsych-survey-multi-choice-option-3-2"
    },
    {
      "t": 66394,
      "e": 63784,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-3[1]_mf"
    },
    {
      "t": 66488,
      "e": 63784,
      "ty": 4,
      "x": 14376,
      "y": 63194,
      "ta": "#jspsych-survey-multi-choice-option-3-2"
    },
    {
      "t": 66488,
      "e": 63784,
      "ty": 5,
      "x": 882,
      "y": 1004,
      "ta": "#jspsych-survey-multi-choice-option-3-2"
    },
    {
      "t": 66503,
      "e": 63799,
      "ty": 41,
      "x": 14376,
      "y": 63194,
      "ta": "#jspsych-survey-multi-choice-option-3-2"
    },
    {
      "t": 66609,
      "e": 63905,
      "ty": 6,
      "x": 883,
      "y": 1006,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 66702,
      "e": 63998,
      "ty": 2,
      "x": 885,
      "y": 1010
    },
    {
      "t": 66753,
      "e": 64049,
      "ty": 41,
      "x": 28644,
      "y": 11915,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 66768,
      "e": 64064,
      "ty": 3,
      "x": 886,
      "y": 1012,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 66769,
      "e": 64065,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 66803,
      "e": 64099,
      "ty": 2,
      "x": 886,
      "y": 1012
    },
    {
      "t": 66856,
      "e": 64152,
      "ty": 4,
      "x": 29159,
      "y": 13901,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 66856,
      "e": 64152,
      "ty": 5,
      "x": 886,
      "y": 1012,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 66860,
      "e": 64156,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 66861,
      "e": 64157,
      "ty": 13,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-multi-choice-form"
    },
    {
      "t": 66862,
      "e": 64158,
      "ty": 38,
      "x": 5,
      "y": 0
    },
    {
      "t": 67003,
      "e": 64299,
      "ty": 41,
      "x": 30236,
      "y": 55618,
      "ta": "html > body"
    },
    {
      "t": 67103,
      "e": 64399,
      "ty": 2,
      "x": 897,
      "y": 1038
    },
    {
      "t": 67254,
      "e": 64550,
      "ty": 41,
      "x": 30615,
      "y": 57059,
      "ta": "html > body"
    },
    {
      "t": 67703,
      "e": 64999,
      "ty": 2,
      "x": 897,
      "y": 1040
    },
    {
      "t": 67754,
      "e": 65050,
      "ty": 41,
      "x": 30580,
      "y": 57336,
      "ta": "html > body"
    },
    {
      "t": 67803,
      "e": 65099,
      "ty": 2,
      "x": 896,
      "y": 1043
    },
    {
      "t": 68003,
      "e": 65299,
      "ty": 2,
      "x": 894,
      "y": 1043
    },
    {
      "t": 68003,
      "e": 65299,
      "ty": 41,
      "x": 30511,
      "y": 57336,
      "ta": "html > body"
    },
    {
      "t": 68103,
      "e": 65399,
      "ty": 2,
      "x": 889,
      "y": 1035
    },
    {
      "t": 68203,
      "e": 65499,
      "ty": 2,
      "x": 888,
      "y": 998
    },
    {
      "t": 68253,
      "e": 65549,
      "ty": 41,
      "x": 30305,
      "y": 54787,
      "ta": "html > body"
    },
    {
      "t": 68272,
      "e": 65568,
      "ty": 38,
      "x": 6,
      "y": 0
    },
    {
      "t": 68303,
      "e": 65599,
      "ty": 2,
      "x": 889,
      "y": 994
    },
    {
      "t": 68403,
      "e": 65699,
      "ty": 2,
      "x": 895,
      "y": 975
    },
    {
      "t": 68503,
      "e": 65799,
      "ty": 2,
      "x": 896,
      "y": 968
    },
    {
      "t": 68503,
      "e": 65799,
      "ty": 41,
      "x": 29643,
      "y": 58285,
      "ta": "> div.masterdiv > div:[2]"
    },
    {
      "t": 68603,
      "e": 65899,
      "ty": 2,
      "x": 897,
      "y": 966
    },
    {
      "t": 68754,
      "e": 66050,
      "ty": 41,
      "x": 29692,
      "y": 58077,
      "ta": "> div.masterdiv > div:[2]"
    },
    {
      "t": 68803,
      "e": 66099,
      "ty": 2,
      "x": 900,
      "y": 933
    },
    {
      "t": 68903,
      "e": 66199,
      "ty": 2,
      "x": 900,
      "y": 616
    },
    {
      "t": 69004,
      "e": 66300,
      "ty": 2,
      "x": 873,
      "y": 475
    },
    {
      "t": 69004,
      "e": 66300,
      "ty": 41,
      "x": 28511,
      "y": 16269,
      "ta": "> div.masterdiv > div:[2] > div"
    },
    {
      "t": 69103,
      "e": 66399,
      "ty": 2,
      "x": 855,
      "y": 473
    },
    {
      "t": 69203,
      "e": 66499,
      "ty": 2,
      "x": 756,
      "y": 481
    },
    {
      "t": 69253,
      "e": 66549,
      "ty": 41,
      "x": 22067,
      "y": 1371,
      "ta": "> div.masterdiv > div:[2] > div > p:[3]"
    },
    {
      "t": 69303,
      "e": 66599,
      "ty": 2,
      "x": 724,
      "y": 494
    },
    {
      "t": 69403,
      "e": 66699,
      "ty": 2,
      "x": 711,
      "y": 497
    },
    {
      "t": 69503,
      "e": 66799,
      "ty": 2,
      "x": 711,
      "y": 498
    },
    {
      "t": 69503,
      "e": 66799,
      "ty": 41,
      "x": 20542,
      "y": 6052,
      "ta": "> div.masterdiv > div:[2] > div > p:[3]"
    },
    {
      "t": 70253,
      "e": 67549,
      "ty": 41,
      "x": 21083,
      "y": 4102,
      "ta": "> div.masterdiv > div:[2] > div > p:[3]"
    },
    {
      "t": 70303,
      "e": 67599,
      "ty": 2,
      "x": 733,
      "y": 488
    },
    {
      "t": 70403,
      "e": 67699,
      "ty": 2,
      "x": 746,
      "y": 481
    },
    {
      "t": 70503,
      "e": 67799,
      "ty": 2,
      "x": 748,
      "y": 480
    },
    {
      "t": 70503,
      "e": 67799,
      "ty": 41,
      "x": 22362,
      "y": 16848,
      "ta": "> div.masterdiv > div:[2] > div"
    },
    {
      "t": 70603,
      "e": 67899,
      "ty": 2,
      "x": 750,
      "y": 479
    },
    {
      "t": 70703,
      "e": 67999,
      "ty": 2,
      "x": 753,
      "y": 478
    },
    {
      "t": 70754,
      "e": 68050,
      "ty": 41,
      "x": 22755,
      "y": 16385,
      "ta": "> div.masterdiv > div:[2] > div"
    },
    {
      "t": 70803,
      "e": 68099,
      "ty": 2,
      "x": 761,
      "y": 474
    },
    {
      "t": 70903,
      "e": 68199,
      "ty": 2,
      "x": 774,
      "y": 468
    },
    {
      "t": 71004,
      "e": 68300,
      "ty": 2,
      "x": 790,
      "y": 462
    },
    {
      "t": 71004,
      "e": 68300,
      "ty": 41,
      "x": 24428,
      "y": 63596,
      "ta": "> div.masterdiv > div:[2] > div > p:[2]"
    },
    {
      "t": 71103,
      "e": 68399,
      "ty": 2,
      "x": 796,
      "y": 460
    },
    {
      "t": 71254,
      "e": 68550,
      "ty": 41,
      "x": 24723,
      "y": 62036,
      "ta": "> div.masterdiv > div:[2] > div > p:[2]"
    },
    {
      "t": 71403,
      "e": 68699,
      "ty": 2,
      "x": 818,
      "y": 604
    },
    {
      "t": 71504,
      "e": 68800,
      "ty": 2,
      "x": 941,
      "y": 882
    },
    {
      "t": 71504,
      "e": 68800,
      "ty": 41,
      "x": 31857,
      "y": 22271,
      "ta": "> div.masterdiv > div:[2] > div > p:[6]"
    },
    {
      "t": 71603,
      "e": 68899,
      "ty": 2,
      "x": 961,
      "y": 951
    },
    {
      "t": 71703,
      "e": 68999,
      "ty": 2,
      "x": 1008,
      "y": 1002
    },
    {
      "t": 71753,
      "e": 69049,
      "ty": 41,
      "x": 35350,
      "y": 60709,
      "ta": "> div.masterdiv > div:[2]"
    },
    {
      "t": 71803,
      "e": 69099,
      "ty": 2,
      "x": 1012,
      "y": 1003
    },
    {
      "t": 71903,
      "e": 69199,
      "ty": 2,
      "x": 1015,
      "y": 1027
    },
    {
      "t": 72003,
      "e": 69299,
      "ty": 2,
      "x": 1012,
      "y": 1032
    },
    {
      "t": 72004,
      "e": 69300,
      "ty": 41,
      "x": 35350,
      "y": 62717,
      "ta": "> div.masterdiv > div:[2]"
    },
    {
      "t": 72103,
      "e": 69399,
      "ty": 2,
      "x": 1010,
      "y": 1038
    },
    {
      "t": 72179,
      "e": 69475,
      "ty": 6,
      "x": 1012,
      "y": 1074,
      "ta": "#start"
    },
    {
      "t": 72203,
      "e": 69499,
      "ty": 2,
      "x": 1012,
      "y": 1077
    },
    {
      "t": 72253,
      "e": 69549,
      "ty": 41,
      "x": 55977,
      "y": 14094,
      "ta": "#start"
    },
    {
      "t": 72303,
      "e": 69599,
      "ty": 2,
      "x": 1009,
      "y": 1087
    },
    {
      "t": 72403,
      "e": 69699,
      "ty": 2,
      "x": 1006,
      "y": 1090
    },
    {
      "t": 72410,
      "e": 69706,
      "ty": 3,
      "x": 1006,
      "y": 1090,
      "ta": "#start"
    },
    {
      "t": 72411,
      "e": 69707,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#start"
    },
    {
      "t": 72504,
      "e": 69800,
      "ty": 41,
      "x": 52701,
      "y": 33369,
      "ta": "#start"
    },
    {
      "t": 72512,
      "e": 69808,
      "ty": 4,
      "x": 52701,
      "y": 33369,
      "ta": "#start"
    },
    {
      "t": 72512,
      "e": 69808,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#start"
    },
    {
      "t": 72513,
      "e": 69809,
      "ty": 5,
      "x": 1006,
      "y": 1090,
      "ta": "#start"
    },
    {
      "t": 72513,
      "e": 69809,
      "ty": 38,
      "x": 7,
      "y": 0
    },
    {
      "t": 72903,
      "e": 70199,
      "ty": 2,
      "x": 1004,
      "y": 1076
    },
    {
      "t": 73004,
      "e": 70300,
      "ty": 2,
      "x": 1001,
      "y": 1066
    },
    {
      "t": 73004,
      "e": 70300,
      "ty": 41,
      "x": 34196,
      "y": 58610,
      "ta": "html > body"
    },
    {
      "t": 73103,
      "e": 70399,
      "ty": 2,
      "x": 997,
      "y": 1053
    },
    {
      "t": 73204,
      "e": 70500,
      "ty": 2,
      "x": 994,
      "y": 1037
    },
    {
      "t": 73254,
      "e": 70550,
      "ty": 41,
      "x": 33921,
      "y": 56560,
      "ta": "html > body"
    },
    {
      "t": 73304,
      "e": 70600,
      "ty": 2,
      "x": 992,
      "y": 1026
    },
    {
      "t": 73404,
      "e": 70700,
      "ty": 2,
      "x": 992,
      "y": 1021
    },
    {
      "t": 73503,
      "e": 70799,
      "ty": 2,
      "x": 992,
      "y": 1017
    },
    {
      "t": 73504,
      "e": 70800,
      "ty": 41,
      "x": 33886,
      "y": 55895,
      "ta": "html > body"
    },
    {
      "t": 73546,
      "e": 70842,
      "ty": 38,
      "x": 8,
      "y": 0
    },
    {
      "t": 74181,
      "e": 71477,
      "ty": 2,
      "x": 992,
      "y": 1002
    },
    {
      "t": 74182,
      "e": 71478,
      "ty": 41,
      "x": 34639,
      "y": 32876,
      "ta": "#jspsych-data-display"
    },
    {
      "t": 74778,
      "e": 72074,
      "ty": 20,
      "x": 0,
      "y": 0
    }
  ],
  "domMutations": [
    {
      "sequence": 1,
      "data": "{\"f\":\"applyChanged\",\"args\":[[{\"id\":56},{\"id\":57},{\"id\":58},{\"id\":59},{\"id\":60},{\"id\":61},{\"id\":62},{\"id\":63},{\"id\":64},{\"id\":65},{\"id\":66},{\"id\":67},{\"id\":68},{\"id\":69},{\"id\":70},{\"id\":71},{\"id\":72},{\"id\":73},{\"id\":74},{\"id\":75},{\"id\":76},{\"id\":77},{\"id\":78},{\"id\":79},{\"id\":80},{\"id\":81},{\"id\":82},{\"id\":83},{\"id\":84},{\"id\":85},{\"id\":86},{\"id\":87},{\"id\":88},{\"id\":89},{\"id\":90},{\"id\":91},{\"id\":92},{\"id\":93},{\"id\":94},{\"id\":95},{\"id\":96},{\"id\":97},{\"id\":98},{\"id\":99},{\"id\":100},{\"id\":101},{\"id\":102},{\"id\":103},{\"id\":104},{\"id\":105},{\"id\":106},{\"id\":107},{\"id\":108},{\"id\":109},{\"id\":110},{\"id\":111},{\"id\":112},{\"id\":113},{\"id\":114},{\"id\":115},{\"id\":116},{\"id\":117},{\"id\":118},{\"id\":119},{\"id\":120},{\"id\":121},{\"id\":122},{\"id\":123},{\"id\":124},{\"id\":125},{\"id\":126},{\"id\":127},{\"id\":128},{\"id\":129},{\"id\":130},{\"id\":131},{\"id\":132},{\"id\":133},{\"id\":134},{\"id\":135},{\"id\":136},{\"id\":137},{\"id\":138},{\"id\":139},{\"id\":140},{\"id\":141},{\"id\":142},{\"id\":143},{\"id\":144},{\"id\":145},{\"id\":146},{\"id\":147},{\"id\":148},{\"id\":149},{\"id\":150},{\"id\":151},{\"id\":152},{\"id\":153},{\"id\":154},{\"id\":155},{\"id\":156},{\"id\":157},{\"id\":158},{\"id\":159},{\"id\":160},{\"id\":161},{\"id\":162},{\"id\":163},{\"id\":164},{\"id\":165},{\"id\":166},{\"id\":167},{\"id\":168},{\"id\":169},{\"id\":170},{\"id\":171},{\"id\":172},{\"id\":173},{\"id\":174},{\"id\":175},{\"id\":176},{\"id\":177},{\"id\":178},{\"id\":179},{\"id\":180},{\"id\":181},{\"id\":182},{\"id\":183},{\"id\":184},{\"id\":185},{\"id\":186},{\"id\":187},{\"id\":188},{\"id\":189},{\"id\":190},{\"id\":191},{\"id\":192},{\"id\":193},{\"id\":194},{\"id\":195},{\"id\":196},{\"id\":197},{\"id\":198},{\"id\":199},{\"id\":200},{\"id\":201},{\"id\":202},{\"id\":203},{\"id\":204},{\"id\":205},{\"id\":206},{\"id\":207},{\"id\":208},{\"id\":209},{\"id\":210},{\"id\":211},{\"id\":212},{\"id\":213},{\"id\":214},{\"id\":215},{\"id\":216},{\"id\":217},{\"id\":218},{\"id\":219},{\"id\":220},{\"id\":221},{\"id\":222},{\"id\":223},{\"id\":224},{\"id\":225},{\"id\":226},{\"id\":227},{\"id\":228},{\"id\":229},{\"id\":230},{\"id\":231},{\"id\":232},{\"id\":233},{\"id\":234},{\"id\":235},{\"id\":236},{\"id\":237},{\"id\":238},{\"id\":239},{\"id\":240},{\"id\":241},{\"id\":242},{\"id\":243},{\"id\":244},{\"id\":245},{\"id\":246},{\"id\":247},{\"id\":248},{\"id\":249},{\"id\":250},{\"id\":251},{\"id\":252},{\"id\":253},{\"id\":254},{\"id\":255},{\"id\":256},{\"id\":257},{\"id\":258},{\"id\":259},{\"id\":260},{\"id\":261},{\"id\":262},{\"id\":263},{\"id\":264},{\"id\":265},{\"id\":266},{\"id\":267},{\"id\":268},{\"id\":269},{\"id\":270},{\"id\":271},{\"id\":272},{\"id\":273},{\"id\":274},{\"id\":275},{\"id\":276},{\"id\":277},{\"id\":278},{\"id\":279},{\"id\":280},{\"id\":281},{\"id\":282},{\"id\":283},{\"id\":284},{\"id\":285},{\"id\":286},{\"id\":287},{\"id\":288},{\"id\":289},{\"id\":290},{\"id\":291},{\"id\":292},{\"id\":293},{\"id\":294},{\"id\":295},{\"id\":296},{\"id\":297},{\"id\":298},{\"id\":299},{\"id\":300},{\"id\":301},{\"id\":302},{\"id\":303},{\"id\":304},{\"id\":305},{\"id\":306},{\"id\":307},{\"id\":308},{\"id\":309},{\"id\":310},{\"id\":311},{\"id\":312},{\"id\":313},{\"id\":314},{\"id\":315},{\"id\":316},{\"id\":317},{\"id\":318},{\"id\":319},{\"id\":320},{\"id\":321},{\"id\":322},{\"id\":323},{\"id\":324},{\"id\":325},{\"id\":326},{\"id\":327},{\"id\":328},{\"id\":329},{\"id\":330},{\"id\":331},{\"id\":332},{\"id\":333},{\"id\":334},{\"id\":335},{\"id\":336},{\"id\":337},{\"id\":338},{\"id\":339},{\"id\":340},{\"id\":341},{\"id\":342},{\"id\":343},{\"id\":344},{\"id\":345},{\"id\":346},{\"id\":347},{\"id\":348},{\"id\":349},{\"id\":350},{\"id\":351},{\"id\":352},{\"id\":353},{\"id\":354},{\"id\":355},{\"id\":356},{\"id\":357},{\"id\":358},{\"id\":359},{\"id\":360},{\"id\":361},{\"id\":362},{\"id\":363},{\"id\":364},{\"id\":365},{\"id\":366},{\"id\":367},{\"id\":368},{\"id\":369},{\"id\":370},{\"id\":371},{\"id\":372},{\"id\":373},{\"id\":374},{\"id\":375},{\"id\":376},{\"id\":377},{\"id\":378},{\"id\":379},{\"id\":380},{\"id\":381},{\"id\":382},{\"id\":383},{\"id\":384},{\"id\":385},{\"id\":386},{\"id\":387},{\"id\":388},{\"id\":389},{\"id\":390},{\"id\":391},{\"id\":392},{\"id\":393},{\"id\":394},{\"id\":395},{\"id\":396},{\"id\":397},{\"id\":398},{\"id\":399},{\"id\":400},{\"id\":401},{\"id\":402},{\"id\":403},{\"id\":404},{\"id\":405},{\"id\":406},{\"id\":407},{\"id\":408},{\"id\":409},{\"id\":410},{\"id\":411},{\"id\":412},{\"id\":413},{\"id\":414},{\"id\":415},{\"id\":416},{\"id\":417},{\"id\":418},{\"id\":419},{\"id\":420},{\"id\":421},{\"id\":422},{\"id\":423},{\"id\":424},{\"id\":425},{\"id\":426},{\"id\":427},{\"id\":428},{\"id\":429},{\"id\":430},{\"id\":431},{\"id\":432},{\"id\":433},{\"id\":434},{\"id\":435},{\"id\":436},{\"id\":437},{\"id\":438},{\"id\":439},{\"id\":440},{\"id\":441},{\"id\":442},{\"id\":443},{\"id\":444},{\"id\":445},{\"id\":446},{\"id\":447},{\"id\":448},{\"id\":449},{\"id\":450},{\"id\":451},{\"id\":452},{\"id\":453},{\"id\":454},{\"id\":455},{\"id\":456},{\"id\":457},{\"id\":458},{\"id\":459},{\"id\":460},{\"id\":461},{\"id\":462},{\"id\":463},{\"id\":464},{\"id\":465},{\"id\":466},{\"id\":467},{\"id\":468},{\"id\":469},{\"id\":470},{\"id\":471},{\"id\":472},{\"id\":473},{\"id\":474},{\"id\":475},{\"id\":476},{\"id\":477},{\"id\":478},{\"id\":479},{\"id\":480},{\"id\":481},{\"id\":482},{\"id\":483},{\"id\":484},{\"id\":485},{\"id\":486},{\"id\":487},{\"id\":488},{\"id\":489},{\"id\":490},{\"id\":491},{\"id\":492},{\"id\":493},{\"id\":494},{\"id\":495},{\"id\":496},{\"id\":497},{\"id\":498},{\"id\":499},{\"id\":500},{\"id\":501},{\"id\":502},{\"id\":503},{\"id\":504},{\"id\":505},{\"id\":506},{\"id\":507},{\"id\":508},{\"id\":509},{\"id\":510},{\"id\":511},{\"id\":512},{\"id\":513},{\"id\":514},{\"id\":515},{\"id\":516},{\"id\":517},{\"id\":518},{\"id\":519},{\"id\":520},{\"id\":521},{\"id\":522},{\"id\":523},{\"id\":524},{\"id\":525},{\"id\":526},{\"id\":527},{\"id\":528},{\"id\":529},{\"id\":530},{\"id\":531},{\"id\":532},{\"id\":533},{\"id\":534},{\"id\":535},{\"id\":536},{\"id\":537},{\"id\":538},{\"id\":539},{\"id\":540},{\"id\":541},{\"id\":542},{\"id\":543},{\"id\":544},{\"id\":545},{\"id\":546},{\"id\":547},{\"id\":548},{\"id\":549},{\"id\":550},{\"id\":551},{\"id\":552},{\"id\":553},{\"id\":554},{\"id\":555},{\"id\":556},{\"id\":557},{\"id\":558},{\"id\":559},{\"id\":560},{\"id\":561},{\"id\":562},{\"id\":563},{\"id\":564},{\"id\":565},{\"id\":566},{\"id\":567},{\"id\":568},{\"id\":569},{\"id\":570},{\"id\":571},{\"id\":572},{\"id\":573},{\"id\":574},{\"id\":575},{\"id\":576},{\"id\":577},{\"id\":578},{\"id\":579},{\"id\":580},{\"id\":581},{\"id\":582},{\"id\":583},{\"id\":584},{\"id\":585},{\"id\":586},{\"id\":587},{\"id\":588},{\"id\":589},{\"id\":590},{\"id\":591},{\"id\":592},{\"id\":593},{\"id\":594},{\"id\":595},{\"id\":596},{\"id\":597},{\"id\":598},{\"id\":599},{\"id\":600},{\"id\":601},{\"id\":602},{\"id\":603},{\"id\":604},{\"id\":605},{\"id\":606},{\"id\":607},{\"id\":608},{\"id\":609},{\"id\":610},{\"id\":611},{\"id\":612},{\"id\":613},{\"id\":614},{\"id\":615},{\"id\":616},{\"id\":617},{\"id\":618},{\"id\":619},{\"id\":620},{\"id\":621},{\"id\":622},{\"id\":623},{\"id\":624},{\"id\":625},{\"id\":626},{\"id\":627},{\"id\":628},{\"id\":629},{\"id\":630},{\"id\":631},{\"id\":632},{\"id\":633},{\"id\":634},{\"id\":635},{\"id\":636},{\"id\":637},{\"id\":638},{\"id\":639},{\"id\":640},{\"id\":641},{\"id\":642},{\"id\":643},{\"id\":644},{\"id\":645},{\"id\":646},{\"id\":647},{\"id\":648},{\"id\":649},{\"id\":650},{\"id\":651},{\"id\":652},{\"id\":653},{\"id\":654},{\"id\":655},{\"id\":656},{\"id\":657},{\"id\":658},{\"id\":659},{\"id\":660},{\"id\":661},{\"id\":662},{\"id\":663},{\"id\":664},{\"id\":665},{\"id\":666},{\"id\":667},{\"id\":668},{\"id\":669},{\"id\":670},{\"id\":671},{\"id\":672},{\"id\":673},{\"id\":674},{\"id\":675},{\"id\":676},{\"id\":677},{\"id\":678},{\"id\":679},{\"id\":680},{\"id\":681},{\"id\":682},{\"id\":683},{\"id\":684},{\"id\":685},{\"id\":686},{\"id\":687},{\"id\":688},{\"id\":689},{\"id\":690},{\"id\":691},{\"id\":692},{\"id\":693},{\"id\":694},{\"id\":695},{\"id\":696},{\"id\":697},{\"id\":698},{\"id\":699},{\"id\":700},{\"id\":701},{\"id\":702},{\"id\":703},{\"id\":704},{\"id\":705},{\"id\":706},{\"id\":707},{\"id\":708},{\"id\":709},{\"id\":710},{\"id\":711},{\"id\":712},{\"id\":713},{\"id\":714},{\"id\":715},{\"id\":716},{\"id\":717},{\"id\":718},{\"id\":719},{\"id\":720},{\"id\":721},{\"id\":722},{\"id\":723},{\"id\":724},{\"id\":725},{\"id\":726},{\"id\":727},{\"id\":728},{\"id\":729},{\"id\":730},{\"id\":731},{\"id\":732},{\"id\":733},{\"id\":734},{\"id\":735},{\"id\":736},{\"id\":737},{\"id\":738},{\"id\":739},{\"id\":740},{\"id\":741},{\"id\":742},{\"id\":743},{\"id\":744},{\"id\":745},{\"id\":746},{\"id\":747},{\"id\":748},{\"id\":749},{\"id\":750},{\"id\":751},{\"id\":752},{\"id\":753},{\"id\":754},{\"id\":755},{\"id\":756},{\"id\":757},{\"id\":758},{\"id\":759},{\"id\":760},{\"id\":761},{\"id\":762},{\"id\":763},{\"id\":764},{\"id\":765},{\"id\":766},{\"id\":767},{\"id\":768},{\"id\":769},{\"id\":770},{\"id\":771},{\"id\":772},{\"id\":773},{\"id\":774},{\"id\":775},{\"id\":776},{\"id\":777},{\"id\":778},{\"id\":779},{\"id\":780},{\"id\":781},{\"id\":782},{\"id\":783},{\"id\":784},{\"id\":785},{\"id\":786},{\"id\":787},{\"id\":788},{\"id\":789},{\"id\":790},{\"id\":791},{\"id\":792},{\"id\":793},{\"id\":794},{\"id\":795},{\"id\":796},{\"id\":797},{\"id\":798},{\"id\":799},{\"id\":800},{\"id\":801},{\"id\":802},{\"id\":803},{\"id\":804},{\"id\":805},{\"id\":806},{\"id\":807},{\"id\":808},{\"id\":809},{\"id\":810},{\"id\":811},{\"id\":812},{\"id\":813},{\"id\":814},{\"id\":815},{\"id\":816},{\"id\":817},{\"id\":818},{\"id\":819},{\"id\":820},{\"id\":821},{\"id\":822},{\"id\":823},{\"id\":824},{\"id\":825},{\"id\":826},{\"id\":827},{\"id\":828},{\"id\":829},{\"id\":830},{\"id\":831},{\"id\":832},{\"id\":833},{\"id\":834},{\"id\":835},{\"id\":836},{\"id\":837},{\"id\":838},{\"id\":839},{\"id\":840},{\"id\":841},{\"id\":842},{\"id\":843},{\"id\":844},{\"id\":845},{\"id\":846},{\"id\":847},{\"id\":848},{\"id\":849},{\"id\":850},{\"id\":851},{\"id\":852},{\"id\":853},{\"id\":854},{\"id\":855},{\"id\":856},{\"id\":857},{\"id\":858},{\"id\":859},{\"id\":860},{\"id\":861},{\"id\":862},{\"id\":863},{\"id\":864},{\"id\":865},{\"id\":866},{\"id\":867},{\"id\":868},{\"id\":869},{\"id\":870},{\"id\":871},{\"id\":872},{\"id\":873},{\"id\":874},{\"id\":875},{\"id\":876},{\"id\":877},{\"id\":878},{\"id\":879},{\"id\":880},{\"id\":881},{\"id\":882},{\"id\":883},{\"id\":884},{\"id\":885},{\"id\":886},{\"id\":887},{\"id\":888},{\"id\":889},{\"id\":890},{\"id\":891},{\"id\":892},{\"id\":893},{\"id\":894},{\"id\":895},{\"id\":896},{\"id\":897},{\"id\":898},{\"id\":899},{\"id\":900},{\"id\":901},{\"id\":902},{\"id\":903},{\"id\":904},{\"id\":905},{\"id\":906},{\"id\":907},{\"id\":908},{\"id\":909},{\"id\":910},{\"id\":911},{\"id\":912},{\"id\":913},{\"id\":914},{\"id\":915},{\"id\":916},{\"id\":917},{\"id\":918},{\"id\":919},{\"id\":920},{\"id\":921},{\"id\":922},{\"id\":923},{\"id\":924},{\"id\":925},{\"id\":926},{\"id\":927},{\"id\":928},{\"id\":929},{\"id\":930},{\"id\":931},{\"id\":932},{\"id\":933},{\"id\":934},{\"id\":935},{\"id\":936},{\"id\":937},{\"id\":938},{\"id\":939},{\"id\":940},{\"id\":941},{\"id\":942},{\"id\":943},{\"id\":944},{\"id\":945},{\"id\":946},{\"id\":947},{\"id\":948},{\"id\":949},{\"id\":950},{\"id\":951},{\"id\":952},{\"id\":953},{\"id\":954},{\"id\":955},{\"id\":956},{\"id\":957},{\"id\":958},{\"id\":959},{\"id\":960},{\"id\":961},{\"id\":962},{\"id\":963},{\"id\":964},{\"id\":965},{\"id\":966},{\"id\":967},{\"id\":968},{\"id\":969},{\"id\":970},{\"id\":971},{\"id\":972},{\"id\":973},{\"id\":974},{\"id\":975},{\"id\":976},{\"id\":977},{\"id\":978},{\"id\":979},{\"id\":980},{\"id\":981},{\"id\":982},{\"id\":983},{\"id\":984},{\"id\":985},{\"id\":986},{\"id\":987},{\"id\":988},{\"id\":989},{\"id\":990},{\"id\":991},{\"id\":992},{\"id\":993},{\"id\":994},{\"id\":995},{\"id\":996},{\"id\":997},{\"id\":998},{\"id\":999},{\"id\":1000},{\"id\":1001},{\"id\":1002},{\"id\":1003},{\"id\":1004},{\"id\":1005},{\"id\":1006},{\"id\":1007},{\"id\":1008},{\"id\":1009},{\"id\":1010},{\"id\":1011},{\"id\":1012},{\"id\":1013},{\"id\":1014},{\"id\":1015},{\"id\":1016},{\"id\":1017},{\"id\":1018},{\"id\":1019},{\"id\":1020},{\"id\":1021},{\"id\":1022},{\"id\":1023},{\"id\":1024},{\"id\":1025},{\"id\":1026},{\"id\":1027},{\"id\":1028},{\"id\":1029},{\"id\":1030},{\"id\":1031},{\"id\":1032},{\"id\":1033},{\"id\":1034},{\"id\":1035},{\"id\":1036},{\"id\":1037},{\"id\":1038},{\"id\":1039},{\"id\":1040},{\"id\":1041},{\"id\":1042},{\"id\":1043},{\"id\":1044},{\"id\":1045},{\"id\":1046},{\"id\":1047},{\"id\":1048},{\"id\":1049},{\"id\":1050},{\"id\":1051},{\"id\":1052},{\"id\":1053},{\"id\":1054},{\"id\":1055},{\"id\":1056},{\"id\":1057},{\"id\":1058},{\"id\":1059},{\"id\":1060},{\"id\":1061},{\"id\":1062},{\"id\":1063},{\"id\":1064},{\"id\":1065},{\"id\":1066},{\"id\":1067},{\"id\":1068},{\"id\":1069},{\"id\":1070},{\"id\":1071},{\"id\":1072},{\"id\":1073},{\"id\":1074},{\"id\":1075},{\"id\":1076},{\"id\":1077},{\"id\":1078},{\"id\":1079},{\"id\":1080},{\"id\":1081},{\"id\":1082},{\"id\":1083},{\"id\":1084},{\"id\":1085},{\"id\":1086},{\"id\":1087},{\"id\":1088},{\"id\":1089},{\"id\":1090},{\"id\":1091},{\"id\":1092},{\"id\":1093},{\"id\":1094},{\"id\":1095},{\"id\":1096},{\"id\":1097},{\"id\":1098},{\"id\":1099},{\"id\":1100},{\"id\":1101},{\"id\":1102},{\"id\":1103},{\"id\":1104},{\"id\":1105},{\"id\":1106},{\"id\":1107},{\"id\":1108},{\"id\":1109},{\"id\":1110},{\"id\":1111},{\"id\":1112},{\"id\":1113},{\"id\":1114},{\"id\":1115},{\"id\":1116},{\"id\":1117},{\"id\":1118},{\"id\":1119},{\"id\":1120},{\"id\":1121},{\"id\":1122},{\"id\":1123},{\"id\":1124},{\"id\":1125},{\"id\":1126},{\"id\":1127},{\"id\":1128},{\"id\":1129},{\"id\":1130},{\"id\":1131},{\"id\":1132},{\"id\":1133},{\"id\":1134},{\"id\":1135},{\"id\":1136},{\"id\":1137},{\"id\":1138},{\"id\":1139},{\"id\":1140},{\"id\":1141},{\"id\":1142},{\"id\":1143},{\"id\":1144},{\"id\":1145},{\"id\":1146},{\"id\":1147},{\"id\":1148},{\"id\":1149},{\"id\":1150},{\"id\":1151},{\"id\":1152},{\"id\":1153},{\"id\":1154},{\"id\":1155},{\"id\":1156},{\"id\":1157},{\"id\":1158},{\"id\":1159},{\"id\":1160},{\"id\":1161},{\"id\":1162},{\"id\":1163},{\"id\":1164},{\"id\":1165},{\"id\":1166},{\"id\":1167},{\"id\":1168},{\"id\":1169},{\"id\":1170},{\"id\":1171},{\"id\":1172},{\"id\":1173},{\"id\":1174},{\"id\":1175},{\"id\":1176},{\"id\":1177},{\"id\":1178},{\"id\":1179},{\"id\":1180},{\"id\":1181},{\"id\":1182},{\"id\":1183},{\"id\":1184},{\"id\":1185},{\"id\":1186},{\"id\":1187},{\"id\":1188},{\"id\":1189},{\"id\":1190},{\"id\":1191},{\"id\":1192},{\"id\":1193},{\"id\":1194},{\"id\":1195},{\"id\":1196},{\"id\":1197},{\"id\":1198},{\"id\":1199},{\"id\":1200},{\"id\":1201},{\"id\":1202},{\"id\":1203},{\"id\":1204},{\"id\":1205},{\"id\":1206},{\"id\":1207},{\"id\":1208},{\"id\":1209},{\"id\":1210},{\"id\":1211},{\"id\":1212},{\"id\":1213},{\"id\":1214},{\"id\":1215},{\"id\":1216},{\"id\":1217},{\"id\":1218},{\"id\":1219},{\"id\":1220},{\"id\":1221},{\"id\":1222},{\"id\":1223},{\"id\":1224},{\"id\":1225},{\"id\":1226},{\"id\":1227},{\"id\":1228},{\"id\":1229},{\"id\":1230},{\"id\":1231},{\"id\":1232},{\"id\":1233},{\"id\":1234},{\"id\":1235},{\"id\":1236},{\"id\":1237},{\"id\":1238},{\"id\":1239},{\"id\":1240},{\"id\":1241},{\"id\":1242},{\"id\":1243},{\"id\":1244},{\"id\":1245},{\"id\":1246},{\"id\":1247},{\"id\":1248},{\"id\":1249},{\"id\":1250},{\"id\":1251},{\"id\":1252},{\"id\":1253},{\"id\":1254},{\"id\":1255},{\"id\":1256},{\"id\":1257},{\"id\":1258},{\"id\":1259},{\"id\":1260},{\"id\":1261},{\"id\":1262},{\"id\":1263},{\"id\":1264},{\"id\":1265},{\"id\":1266},{\"id\":1267},{\"id\":1268},{\"id\":1269},{\"id\":1270},{\"id\":1271},{\"id\":1272},{\"id\":1273},{\"id\":1274},{\"id\":1275},{\"id\":1276},{\"id\":1277},{\"id\":1278},{\"id\":1279},{\"id\":1280},{\"id\":1281},{\"id\":1282},{\"id\":1283},{\"id\":1284},{\"id\":1285},{\"id\":1286},{\"id\":1287},{\"id\":1288},{\"id\":1289},{\"id\":1290},{\"id\":1291},{\"id\":1292},{\"id\":1293},{\"id\":1294},{\"id\":1295},{\"id\":1296},{\"id\":1297},{\"id\":1298},{\"id\":1299},{\"id\":1300},{\"id\":1301},{\"id\":1302},{\"id\":1303},{\"id\":1304},{\"id\":1305},{\"id\":1306},{\"id\":1307},{\"id\":1308},{\"id\":1309},{\"id\":1310},{\"id\":1311},{\"id\":1312},{\"id\":1313},{\"id\":1314},{\"id\":1315},{\"id\":1316},{\"id\":1317},{\"id\":1318},{\"id\":1319},{\"id\":1320},{\"id\":1321},{\"id\":1322},{\"id\":1323},{\"id\":1324},{\"id\":1325},{\"id\":1326},{\"id\":1327},{\"id\":1328},{\"id\":1329},{\"id\":1330},{\"id\":1331},{\"id\":1332},{\"id\":1333},{\"id\":1334},{\"id\":1335},{\"id\":1336},{\"id\":1337},{\"id\":1338},{\"id\":1339},{\"id\":1340},{\"id\":1341},{\"id\":1342},{\"id\":1343},{\"id\":1344},{\"id\":1345},{\"id\":1346},{\"id\":1347},{\"id\":1348},{\"id\":1349},{\"id\":1350},{\"id\":1351},{\"id\":1352},{\"id\":1353},{\"id\":1354},{\"id\":1355},{\"id\":1356},{\"id\":1357},{\"id\":1358},{\"id\":1359},{\"id\":1360},{\"id\":1361},{\"id\":1362},{\"id\":1363},{\"id\":1364},{\"id\":1365},{\"id\":1366},{\"id\":1367},{\"id\":1368},{\"id\":1369},{\"id\":1370},{\"id\":1371},{\"id\":1372},{\"id\":1373},{\"id\":1374},{\"id\":1375},{\"id\":1376},{\"id\":1377},{\"id\":1378},{\"id\":1379},{\"id\":1380},{\"id\":1381},{\"id\":1382},{\"id\":1383},{\"id\":1384},{\"id\":1385},{\"id\":1386},{\"id\":1387},{\"id\":1388},{\"id\":1389},{\"id\":1390},{\"id\":1391},{\"id\":1392},{\"id\":1393},{\"id\":1394},{\"id\":1395},{\"id\":1396},{\"id\":1397},{\"id\":1398},{\"id\":1399},{\"id\":1400},{\"id\":1401},{\"id\":1402},{\"id\":1403},{\"id\":1404},{\"id\":1405},{\"id\":1406},{\"id\":1407},{\"id\":1408},{\"id\":1409},{\"id\":1410},{\"id\":1411},{\"id\":1412},{\"id\":1413},{\"id\":1414},{\"id\":1415},{\"id\":1416},{\"id\":1417},{\"id\":1418},{\"id\":1419},{\"id\":1420},{\"id\":1421},{\"id\":1422},{\"id\":1423},{\"id\":1424},{\"id\":1425},{\"id\":1426},{\"id\":1427},{\"id\":1428},{\"id\":1429},{\"id\":1430},{\"id\":1431},{\"id\":1432},{\"id\":1433},{\"id\":1434},{\"id\":1435},{\"id\":1436},{\"id\":1437},{\"id\":1438},{\"id\":1439},{\"id\":1440},{\"id\":1441},{\"id\":1442},{\"id\":1443},{\"id\":1444},{\"id\":1445},{\"id\":1446},{\"id\":1447},{\"id\":1448},{\"id\":1449},{\"id\":1450},{\"id\":1451},{\"id\":1452},{\"id\":1453},{\"id\":1454},{\"id\":1455},{\"id\":1456},{\"id\":1457},{\"id\":1458},{\"id\":1459},{\"id\":1460},{\"id\":1461},{\"id\":1462},{\"id\":1463},{\"id\":1464},{\"id\":1465},{\"id\":1466},{\"id\":1467},{\"id\":1468},{\"id\":1469},{\"id\":1470},{\"id\":1471},{\"id\":1472},{\"id\":1473},{\"id\":1474},{\"id\":1475},{\"id\":1476},{\"id\":1477},{\"id\":1478},{\"id\":1479},{\"id\":1480},{\"id\":1481},{\"id\":1482},{\"id\":1483},{\"id\":1484},{\"id\":1485},{\"id\":1486},{\"id\":1487},{\"id\":1488},{\"id\":1489},{\"id\":1490},{\"id\":1491},{\"id\":1492},{\"id\":1493},{\"id\":1494},{\"id\":1495},{\"id\":1496},{\"id\":1497},{\"id\":1498},{\"id\":1499},{\"id\":1500},{\"id\":1501},{\"id\":1502},{\"id\":1503},{\"id\":1504},{\"id\":1505},{\"id\":1506},{\"id\":1507},{\"id\":1508},{\"id\":1509},{\"id\":1510},{\"id\":1511},{\"id\":1512},{\"id\":1513},{\"id\":1514},{\"id\":1515},{\"id\":1516},{\"id\":1517},{\"id\":1518},{\"id\":1519},{\"id\":1520},{\"id\":1521},{\"id\":1522},{\"id\":1523},{\"id\":1524},{\"id\":1525},{\"id\":1526},{\"id\":1527},{\"id\":1528},{\"id\":1529},{\"id\":1530},{\"id\":1531},{\"id\":1532},{\"id\":1533},{\"id\":1534},{\"id\":1535},{\"id\":1536},{\"id\":1537},{\"id\":1538},{\"id\":1539},{\"id\":1540},{\"id\":1541},{\"id\":1542},{\"id\":1543},{\"id\":1544},{\"id\":1545},{\"id\":1546},{\"id\":1547},{\"id\":1548},{\"id\":1549},{\"id\":1550},{\"id\":1551},{\"id\":1552},{\"id\":1553},{\"id\":1554},{\"id\":1555},{\"id\":1556},{\"id\":1557},{\"id\":1558},{\"id\":1559},{\"id\":1560},{\"id\":1561},{\"id\":1562},{\"id\":1563},{\"id\":1564},{\"id\":1565},{\"id\":1566},{\"id\":1567},{\"id\":1568},{\"id\":1569},{\"id\":1570},{\"id\":1571},{\"id\":1572},{\"id\":1573},{\"id\":1574},{\"id\":1575},{\"id\":1576},{\"id\":1577},{\"id\":1578},{\"id\":1579},{\"id\":1580},{\"id\":1581},{\"id\":1582},{\"id\":1583},{\"id\":1584},{\"id\":1585},{\"id\":1586},{\"id\":1587},{\"id\":1588},{\"id\":1589},{\"id\":1590},{\"id\":1591},{\"id\":1592},{\"id\":1593},{\"id\":1594},{\"id\":1595},{\"id\":1596},{\"id\":1597},{\"id\":1598},{\"id\":1599},{\"id\":1600},{\"id\":1601},{\"id\":1602},{\"id\":1603},{\"id\":1604},{\"id\":1605},{\"id\":1606},{\"id\":1607},{\"id\":1608},{\"id\":1609},{\"id\":1610},{\"id\":1611},{\"id\":1612},{\"id\":1613},{\"id\":1614},{\"id\":1615},{\"id\":1616},{\"id\":1617},{\"id\":1618},{\"id\":1619},{\"id\":1620},{\"id\":1621},{\"id\":1622},{\"id\":1623},{\"id\":1624},{\"id\":1625},{\"id\":1626},{\"id\":1627},{\"id\":1628},{\"id\":1629},{\"id\":1630},{\"id\":1631},{\"id\":1632},{\"id\":1633},{\"id\":1634},{\"id\":1635},{\"id\":1636},{\"id\":1637},{\"id\":1638},{\"id\":1639},{\"id\":1640},{\"id\":1641},{\"id\":1642},{\"id\":1643},{\"id\":1644},{\"id\":1645},{\"id\":1646},{\"id\":1647},{\"id\":1648},{\"id\":1649},{\"id\":1650},{\"id\":1651},{\"id\":1652},{\"id\":1653},{\"id\":1654},{\"id\":1655},{\"id\":1656},{\"id\":1657},{\"id\":1658},{\"id\":1659},{\"id\":1660},{\"id\":1661},{\"id\":1662},{\"id\":1663},{\"id\":1664},{\"id\":1665},{\"id\":1666},{\"id\":1667},{\"id\":1668},{\"id\":1669},{\"id\":1670},{\"id\":1671},{\"id\":1672},{\"id\":1673},{\"id\":1674},{\"id\":1675},{\"id\":1676},{\"id\":1677},{\"id\":1678},{\"id\":1679},{\"id\":1680},{\"id\":1681},{\"id\":1682},{\"id\":1683},{\"id\":1684},{\"id\":1685},{\"id\":1686},{\"id\":1687},{\"id\":1688},{\"id\":1689},{\"id\":1690},{\"id\":1691},{\"id\":1692},{\"id\":1693},{\"id\":1694},{\"id\":1695},{\"id\":1696},{\"id\":1697},{\"id\":1698},{\"id\":1699},{\"id\":1700},{\"id\":1701},{\"id\":1702},{\"id\":1703},{\"id\":1704},{\"id\":1705},{\"id\":1706},{\"id\":1707},{\"id\":1708},{\"id\":1709},{\"id\":1710},{\"id\":1711},{\"id\":1712},{\"id\":1713},{\"id\":1714},{\"id\":1715},{\"id\":1716},{\"id\":1717},{\"id\":1718},{\"id\":1719},{\"id\":1720},{\"id\":1721},{\"id\":1722},{\"id\":1723},{\"id\":1724},{\"id\":1725},{\"id\":1726},{\"id\":1727},{\"id\":1728},{\"id\":1729},{\"id\":1730},{\"id\":1731},{\"id\":1732},{\"id\":1733},{\"id\":1734},{\"id\":1735},{\"id\":1736},{\"id\":1737},{\"id\":1738},{\"id\":1739},{\"id\":1740},{\"id\":1741},{\"id\":1742},{\"id\":1743},{\"id\":1744},{\"id\":1745},{\"id\":1746},{\"id\":1747},{\"id\":1748},{\"id\":1749},{\"id\":1750},{\"id\":1751},{\"id\":1752},{\"id\":1753},{\"id\":1754},{\"id\":1755},{\"id\":1756},{\"id\":1757},{\"id\":1758},{\"id\":1759},{\"id\":1760},{\"id\":1761},{\"id\":1762},{\"id\":1763},{\"id\":1764},{\"id\":1765},{\"id\":1766},{\"id\":1767},{\"id\":1768},{\"id\":1769},{\"id\":1770},{\"id\":1771},{\"id\":1772},{\"id\":1773},{\"id\":1774},{\"id\":1775},{\"id\":1776},{\"id\":1777},{\"id\":1778},{\"id\":1779},{\"id\":1780},{\"id\":1781},{\"id\":1782},{\"id\":1783},{\"id\":1784},{\"id\":1785},{\"id\":1786},{\"id\":1787},{\"id\":1788},{\"id\":1789},{\"id\":1790},{\"id\":1791},{\"id\":1792},{\"id\":1793},{\"id\":1794},{\"id\":1795},{\"id\":1796},{\"id\":1797},{\"id\":1798},{\"id\":1799},{\"id\":1800},{\"id\":1801},{\"id\":1802},{\"id\":1803},{\"id\":1804},{\"id\":1805},{\"id\":1806},{\"id\":1807},{\"id\":1808},{\"id\":1809},{\"id\":1810},{\"id\":1811},{\"id\":1812},{\"id\":1813},{\"id\":1814},{\"id\":1815},{\"id\":1816},{\"id\":1817},{\"id\":1818},{\"id\":1819},{\"id\":1820},{\"id\":1821},{\"id\":1822},{\"id\":1823},{\"id\":1824},{\"id\":1825},{\"id\":1826},{\"id\":1827},{\"id\":1828},{\"id\":1829},{\"id\":1830},{\"id\":1831},{\"id\":1832},{\"id\":1833},{\"id\":1834},{\"id\":1835},{\"id\":1836},{\"id\":1837},{\"id\":1838},{\"id\":1839},{\"id\":1840},{\"id\":1841},{\"id\":1842},{\"id\":1843},{\"id\":1844},{\"id\":1845},{\"id\":1846},{\"id\":1847},{\"id\":1848},{\"id\":1849},{\"id\":1850},{\"id\":1851},{\"id\":1852},{\"id\":1853},{\"id\":1854},{\"id\":1855},{\"id\":1856},{\"id\":1857},{\"id\":1858},{\"id\":1859},{\"id\":1860},{\"id\":1861},{\"id\":1862},{\"id\":1863},{\"id\":1864},{\"id\":1865},{\"id\":1866},{\"id\":1867},{\"id\":1868},{\"id\":1869},{\"id\":1870},{\"id\":1871},{\"id\":1872},{\"id\":1873},{\"id\":1874},{\"id\":1875},{\"id\":1876},{\"id\":1877},{\"id\":1878},{\"id\":1879},{\"id\":1880},{\"id\":1881},{\"id\":1882},{\"id\":1883},{\"id\":1884},{\"id\":1885},{\"id\":1886},{\"id\":1887},{\"id\":1888},{\"id\":1889},{\"id\":1890},{\"id\":1891},{\"id\":1892},{\"id\":1893},{\"id\":1894},{\"id\":1895},{\"id\":1896},{\"id\":1897},{\"id\":1898},{\"id\":1899},{\"id\":1900},{\"id\":1901},{\"id\":1902},{\"id\":1903},{\"id\":1904},{\"id\":1905},{\"id\":1906},{\"id\":1907},{\"id\":1908},{\"id\":1909},{\"id\":1910},{\"id\":1911},{\"id\":1912},{\"id\":1913},{\"id\":1914},{\"id\":1915},{\"id\":1916},{\"id\":1917},{\"id\":1918},{\"id\":1919},{\"id\":1920},{\"id\":1921},{\"id\":1922},{\"id\":1923},{\"id\":1924},{\"id\":1925},{\"id\":1926},{\"id\":1927},{\"id\":1928},{\"id\":1929},{\"id\":1930},{\"id\":1931},{\"id\":1932},{\"id\":1933},{\"id\":1934},{\"id\":1935},{\"id\":1936},{\"id\":1937},{\"id\":1938},{\"id\":1939},{\"id\":1940},{\"id\":1941},{\"id\":1942},{\"id\":1943},{\"id\":1944},{\"id\":1945},{\"id\":1946},{\"id\":1947},{\"id\":1948},{\"id\":1949},{\"id\":1950},{\"id\":1951},{\"id\":1952},{\"id\":1953},{\"id\":1954},{\"id\":1955},{\"id\":1956},{\"id\":1957},{\"id\":1958},{\"id\":1959},{\"id\":1960},{\"id\":1961},{\"id\":1962},{\"id\":1963},{\"id\":1964},{\"id\":1965},{\"id\":1966},{\"id\":1967},{\"id\":1968},{\"id\":1969},{\"id\":1970},{\"id\":1971},{\"id\":1972},{\"id\":1973},{\"id\":1974},{\"id\":1975},{\"id\":1976},{\"id\":1977},{\"id\":1978},{\"id\":1979},{\"id\":1980},{\"id\":1981},{\"id\":1982},{\"id\":1983},{\"id\":1984},{\"id\":1985},{\"id\":1986},{\"id\":1987},{\"id\":1988},{\"id\":1989},{\"id\":1990},{\"id\":1991},{\"id\":1992},{\"id\":1993},{\"id\":1994},{\"id\":1995},{\"id\":1996},{\"id\":1997},{\"id\":1998},{\"id\":1999},{\"id\":2000},{\"id\":2001},{\"id\":2002},{\"id\":2003},{\"id\":2004},{\"id\":2005},{\"id\":2006},{\"id\":2007},{\"id\":2008},{\"id\":2009},{\"id\":2010},{\"id\":2011},{\"id\":2012},{\"id\":2013},{\"id\":2014},{\"id\":2015},{\"id\":2016},{\"id\":2017},{\"id\":2018},{\"id\":2019},{\"id\":2020},{\"id\":2021},{\"id\":2022},{\"id\":2023},{\"id\":2024},{\"id\":2025},{\"id\":2026},{\"id\":2027},{\"id\":2028},{\"id\":2029},{\"id\":2030},{\"id\":2031},{\"id\":2032},{\"id\":2033},{\"id\":2034},{\"id\":2035},{\"id\":2036},{\"id\":2037},{\"id\":2038},{\"id\":2039},{\"id\":2040},{\"id\":2041},{\"id\":2042},{\"id\":2043},{\"id\":2044},{\"id\":2045},{\"id\":2046},{\"id\":2047},{\"id\":2048},{\"id\":2049},{\"id\":2050},{\"id\":2051},{\"id\":2052},{\"id\":2053},{\"id\":2054},{\"id\":2055},{\"id\":2056},{\"id\":2057},{\"id\":2058},{\"id\":2059},{\"id\":2060},{\"id\":2061},{\"id\":2062},{\"id\":2063},{\"id\":2064},{\"id\":2065},{\"id\":2066},{\"id\":2067},{\"id\":2068},{\"id\":2069},{\"id\":2070},{\"id\":2071},{\"id\":2072},{\"id\":2073},{\"id\":2074},{\"id\":2075},{\"id\":2076},{\"id\":2077},{\"id\":2078},{\"id\":2079},{\"id\":2080},{\"id\":2081},{\"id\":2082},{\"id\":2083},{\"id\":2084},{\"id\":2085},{\"id\":2086},{\"id\":2087},{\"id\":2088},{\"id\":2089},{\"id\":2090},{\"id\":2091},{\"id\":2092},{\"id\":2093},{\"id\":2094},{\"id\":2095},{\"id\":2096},{\"id\":2097},{\"id\":2098},{\"id\":2099},{\"id\":2100},{\"id\":2101},{\"id\":2102},{\"id\":2103},{\"id\":2104},{\"id\":2105},{\"id\":2106},{\"id\":2107},{\"id\":2108},{\"id\":2109},{\"id\":2110},{\"id\":2111},{\"id\":2112},{\"id\":2113},{\"id\":2114},{\"id\":2115},{\"id\":2116},{\"id\":2117},{\"id\":2118},{\"id\":2119},{\"id\":2120},{\"id\":2121},{\"id\":2122},{\"id\":2123},{\"id\":2124},{\"id\":2125},{\"id\":2126},{\"id\":2127},{\"id\":2128},{\"id\":2129},{\"id\":2130},{\"id\":2131},{\"id\":2132},{\"id\":2133},{\"id\":2134},{\"id\":2135},{\"id\":2136},{\"id\":2137},{\"id\":2138},{\"id\":2139},{\"id\":2140},{\"id\":2141},{\"id\":2142},{\"id\":2143},{\"id\":2144},{\"id\":2145},{\"id\":2146},{\"id\":2147},{\"id\":2148},{\"id\":2149},{\"id\":2150},{\"id\":2151},{\"id\":2152},{\"id\":2153},{\"id\":2154},{\"id\":2155},{\"id\":2156},{\"id\":2157},{\"id\":2158},{\"id\":2159},{\"id\":2160},{\"id\":2161},{\"id\":2162},{\"id\":2163},{\"id\":2164},{\"id\":2165},{\"id\":2166},{\"id\":2167},{\"id\":2168},{\"id\":2169},{\"id\":2170},{\"id\":2171},{\"id\":2172},{\"id\":2173},{\"id\":2174},{\"id\":2175},{\"id\":2176},{\"id\":2177},{\"id\":2178},{\"id\":2179},{\"id\":2180},{\"id\":2181},{\"id\":2182},{\"id\":2183},{\"id\":2184},{\"id\":2185},{\"id\":2186},{\"id\":2187},{\"id\":2188},{\"id\":2189},{\"id\":2190},{\"id\":2191},{\"id\":2192},{\"id\":2193},{\"id\":2194},{\"id\":2195},{\"id\":2196},{\"id\":2197},{\"id\":2198},{\"id\":2199},{\"id\":2200},{\"id\":2201},{\"id\":2202},{\"id\":2203},{\"id\":2204},{\"id\":2205},{\"id\":2206},{\"id\":2207},{\"id\":2208},{\"id\":2209},{\"id\":2210},{\"id\":2211},{\"id\":2212},{\"id\":2213},{\"id\":2214},{\"id\":2215},{\"id\":2216},{\"id\":2217},{\"id\":2218},{\"id\":2219},{\"id\":2220},{\"id\":2221},{\"id\":2222},{\"id\":2223},{\"id\":2224},{\"id\":2225},{\"id\":2226},{\"id\":2227},{\"id\":2228},{\"id\":2229},{\"id\":2230},{\"id\":2231},{\"id\":2232},{\"id\":2233},{\"id\":2234},{\"id\":2235},{\"id\":2236},{\"id\":2237},{\"id\":2238},{\"id\":2239},{\"id\":2240},{\"id\":2241},{\"id\":2242},{\"id\":2243},{\"id\":2244},{\"id\":2245},{\"id\":2246},{\"id\":2247},{\"id\":2248},{\"id\":2249},{\"id\":2250},{\"id\":2251},{\"id\":2252},{\"id\":2253},{\"id\":2254},{\"id\":2255},{\"id\":2256},{\"id\":2257},{\"id\":2258},{\"id\":2259},{\"id\":2260},{\"id\":2261},{\"id\":2262},{\"id\":2263},{\"id\":2264},{\"id\":2265},{\"id\":2266},{\"id\":2267},{\"id\":2268},{\"id\":2269},{\"id\":2270},{\"id\":2271},{\"id\":2272},{\"id\":2273},{\"id\":2274},{\"id\":2275},{\"id\":2276},{\"id\":2277},{\"id\":2278},{\"id\":2279},{\"id\":2280},{\"id\":2281},{\"id\":2282},{\"id\":2283},{\"id\":2284},{\"id\":2285},{\"id\":2286},{\"id\":2287},{\"id\":2288},{\"id\":2289},{\"id\":2290},{\"id\":2291},{\"id\":2292},{\"id\":2293},{\"id\":2294},{\"id\":2295},{\"id\":2296},{\"id\":2297},{\"id\":2298},{\"id\":2299},{\"id\":2300},{\"id\":2301},{\"id\":2302},{\"id\":2303},{\"id\":2304},{\"id\":2305},{\"id\":2306},{\"id\":2307},{\"id\":2308},{\"id\":2309},{\"id\":2310},{\"id\":2311},{\"id\":2312},{\"id\":2313},{\"id\":2314},{\"id\":2315},{\"id\":2316},{\"id\":2317},{\"id\":2318},{\"id\":2319},{\"id\":2320},{\"id\":2321},{\"id\":2322},{\"id\":2323},{\"id\":2324},{\"id\":2325},{\"id\":2326},{\"id\":2327},{\"id\":2328},{\"id\":2329},{\"id\":2330},{\"id\":2331},{\"id\":2332},{\"id\":2333},{\"id\":2334},{\"id\":2335},{\"id\":2336},{\"id\":2337},{\"id\":2338},{\"id\":2339},{\"id\":2340},{\"id\":2341},{\"id\":2342},{\"id\":2343},{\"id\":2344},{\"id\":2345},{\"id\":2346},{\"id\":2347},{\"id\":2348},{\"id\":2349},{\"id\":2350},{\"id\":2351},{\"id\":2352},{\"id\":2353},{\"id\":2354},{\"id\":2355},{\"id\":2356},{\"id\":2357},{\"id\":2358},{\"id\":2359},{\"id\":2360},{\"id\":2361},{\"id\":2362},{\"id\":2363},{\"id\":2364},{\"id\":2365},{\"id\":2366},{\"id\":2367},{\"id\":2368},{\"id\":2369},{\"id\":2370},{\"id\":2371},{\"id\":2372},{\"id\":2373},{\"id\":2374},{\"id\":2375},{\"id\":2376},{\"id\":2377},{\"id\":2378},{\"id\":2379},{\"id\":2380},{\"id\":2381},{\"id\":2382},{\"id\":2383},{\"id\":2384},{\"id\":2385},{\"id\":2386},{\"id\":2387},{\"id\":2388},{\"id\":2389},{\"id\":2390},{\"id\":2391},{\"id\":2392},{\"id\":2393},{\"id\":2394},{\"id\":2395},{\"id\":2396},{\"id\":2397},{\"id\":2398},{\"id\":2399},{\"id\":2400},{\"id\":2401},{\"id\":2402},{\"id\":2403},{\"id\":2404},{\"id\":2405},{\"id\":2406},{\"id\":2407},{\"id\":2408},{\"id\":2409},{\"id\":2410},{\"id\":2411},{\"id\":2412},{\"id\":2413},{\"id\":2414},{\"id\":2415},{\"id\":2416},{\"id\":2417},{\"id\":2418},{\"id\":2419},{\"id\":2420},{\"id\":2421},{\"id\":2422},{\"id\":2423},{\"id\":2424},{\"id\":2425},{\"id\":2426},{\"id\":2427},{\"id\":2428},{\"id\":2429},{\"id\":2430},{\"id\":2431},{\"id\":2432},{\"id\":2433},{\"id\":2434},{\"id\":2435},{\"id\":2436},{\"id\":2437},{\"id\":2438},{\"id\":2439},{\"id\":2440},{\"id\":2441},{\"id\":2442},{\"id\":2443},{\"id\":2444},{\"id\":2445},{\"id\":2446},{\"id\":2447},{\"id\":2448},{\"id\":2449},{\"id\":2450},{\"id\":2451},{\"id\":2452},{\"id\":2453},{\"id\":2454},{\"id\":2455},{\"id\":2456},{\"id\":2457},{\"id\":2458},{\"id\":2459},{\"id\":2460},{\"id\":2461},{\"id\":2462},{\"id\":2463},{\"id\":2464},{\"id\":2465},{\"id\":2466},{\"id\":2467},{\"id\":2468},{\"id\":2469},{\"id\":2470},{\"id\":2471},{\"id\":2472},{\"id\":2473},{\"id\":2474},{\"id\":2475},{\"id\":2476},{\"id\":2477},{\"id\":2478},{\"id\":2479},{\"id\":2480},{\"id\":2481},{\"id\":2482},{\"id\":2483},{\"id\":2484},{\"id\":2485},{\"id\":2486},{\"id\":2487},{\"id\":2488},{\"id\":2489},{\"id\":2490},{\"id\":2491},{\"id\":2492},{\"id\":2493},{\"id\":2494},{\"id\":2495},{\"id\":2496},{\"id\":2497},{\"id\":2498},{\"id\":2499},{\"id\":2500},{\"id\":2501},{\"id\":2502},{\"id\":2503},{\"id\":2504},{\"id\":2505},{\"id\":2506},{\"id\":2507},{\"id\":2508},{\"id\":2509},{\"id\":2510},{\"id\":2511},{\"id\":2512},{\"id\":2513},{\"id\":2514},{\"id\":2515},{\"id\":2516},{\"id\":2517},{\"id\":2518},{\"id\":2519},{\"id\":2520},{\"id\":2521},{\"id\":2522},{\"id\":2523},{\"id\":2524},{\"id\":2525},{\"id\":2526},{\"id\":2527},{\"id\":2528},{\"id\":2529},{\"id\":2530},{\"id\":2531},{\"id\":2532},{\"id\":2533},{\"id\":2534},{\"id\":2535},{\"id\":2536},{\"id\":2537},{\"id\":2538},{\"id\":2539},{\"id\":2540},{\"id\":2541},{\"id\":2542},{\"id\":2543},{\"id\":2544},{\"id\":2545},{\"id\":2546},{\"id\":2547},{\"id\":2548},{\"id\":2549},{\"id\":2550},{\"id\":2551},{\"id\":2552},{\"id\":2553},{\"id\":2554},{\"id\":2555},{\"id\":2556},{\"id\":2557},{\"id\":2558},{\"id\":2559},{\"id\":2560},{\"id\":2561},{\"id\":2562},{\"id\":2563},{\"id\":2564},{\"id\":2565},{\"id\":2566},{\"id\":2567},{\"id\":2568},{\"id\":2569},{\"id\":2570},{\"id\":2571},{\"id\":2572},{\"id\":2573},{\"id\":2574},{\"id\":2575},{\"id\":2576},{\"id\":2577},{\"id\":2578},{\"id\":2579},{\"id\":2580},{\"id\":2581},{\"id\":2582},{\"id\":2583},{\"id\":2584},{\"id\":2585},{\"id\":2586},{\"id\":2587},{\"id\":2588},{\"id\":2589},{\"id\":2590},{\"id\":2591},{\"id\":2592},{\"nodeType\":3,\"id\":2596,\"textContent\":\" // Track clicks on page $(document).ready(function() { $(\\\".control\\\").click(function(e) { e.stopImmediatePropagation(); clicks = clicks + 1; console.log(clicks); }); }); $('.userid').html(sid); // console.log(\\\"start of clicked array: \\\"+clicked); // console.log(\\\"start of hovered string: \\\"+hovered); //set correct answers for each question var triangular_answers = { \\\"acme.starttime.1\\\" : [\\\"F\\\"], \\\"acme.starts.1\\\" : [\\\"K\\\"], \\\"acme.meets.1\\\" : [\\\"F\\\"], \\\"acme.endtime.1\\\" : [\\\"H\\\"], \\\"acme.midpoint.1\\\" : [\\\"O\\\"], \\\"acme.starttime.2\\\" : [\\\"F\\\"], \\\"acme.starts.2\\\" : [\\\"K\\\"], \\\"acme.meets.2\\\" : [\\\"F\\\"], \\\"acme.endtime.2\\\" : [\\\"H\\\"], \\\"acme.midpoint.2\\\" : [\\\"A\\\"], \\\"bigset.duration.1\\\" : [\\\"E\\\",\\\"G\\\"], \\\"bigset.duration+starts.1\\\" : [\\\"X\\\",\\\"O\\\"], \\\"bigset.duration+contained.1\\\" : [\\\"G\\\"], \\\"bigset.starttime+before+endtime+during.1\\\": [\\\"I\\\"], \\\"bigset.ends.1\\\" : [\\\"E\\\"], \\\"bigset.duration.2\\\" : [\\\"E\\\",\\\"G\\\"], \\\"bigset.duration+starts.2\\\" : [\\\"X\\\",\\\"O\\\"], \\\"bigset.duration+contained.2\\\" : [\\\"G\\\"], \\\"bigset.starttime+before+endtime+during.2\\\":[\\\"I\\\"], \\\"bigset.ends.2\\\" : [\\\"E\\\"], \\\"bigset.starttime.1\\\" : [\\\"M\\\",\\\"L\\\"], \\\"bigset.starts.1\\\" : [\\\"G\\\"], \\\"bigset.meets.1\\\" : [\\\"E\\\",\\\"F\\\"], \\\"bigset.endtime.1\\\" : [\\\"X\\\"], \\\"bigset.midpoint.1\\\" : [\\\"K\\\",\\\"X\\\"], \\\"bigset.starttime.2\\\" : [\\\"M\\\",\\\"L\\\"], \\\"bigset.starts.2\\\" : [\\\"G\\\"], \\\"bigset.meets.2\\\" : [\\\"E\\\",\\\"F\\\"], \\\"bigset.endtime.2\\\" : [\\\"X\\\"], \\\"bigset.midpoint.2\\\" : [\\\"K\\\",\\\"X\\\"] } var orthogonal_answers = { \\\"acme.starttime.1\\\" : [\\\"A\\\"], \\\"acme.starts.1\\\" : [\\\"E\\\"], \\\"acme.meets.1\\\" : [\\\"Z\\\"], \\\"acme.endtime.1\\\" : [\\\"U\\\"], \\\"acme.midpoint.1\\\" : [\\\"U\\\"], \\\"acme.starttime.2\\\" : [\\\"0\\\"], \\\"acme.starts.2\\\" : [\\\"0\\\"], \\\"acme.meets.2\\\" : [\\\"0\\\"], \\\"acme.endtime.2\\\" : [\\\"0\\\"], \\\"acme.midpoint.2\\\" : [\\\"0\\\"], \\\"bigset.duration.1\\\" : [\\\"E\\\",\\\"G\\\"], \\\"bigset.duration+starts.1\\\" : [\\\"F\\\",\\\"B\\\"], \\\"bigset.duration+contained.1\\\" : [\\\"E\\\"], \\\"bigset.starttime+before+endtime+during.1\\\": [\\\"I\\\"], \\\"bigset.ends.1\\\" : [\\\"X\\\"], \\\"bigset.duration.2\\\" : [\\\"E\\\",\\\"G\\\"], \\\"bigset.duration+starts.2\\\" : [\\\"F\\\",\\\"B\\\"], \\\"bigset.duration+contained.2\\\" : [\\\"E\\\"], \\\"bigset.starttime+before+endtime+during.2\\\":[\\\"I\\\"], \\\"bigset.ends.2\\\" : [\\\"X\\\"], \\\"bigset.starttime.1\\\" : [\\\"F\\\",\\\"B\\\"], \\\"bigset.starts.1\\\" : [\\\"B\\\"], \\\"bigset.meets.1\\\" : [\\\"F\\\",\\\"X\\\"], \\\"bigset.endtime.1\\\" : [\\\"B\\\"], \\\"bigset.midpoint.1\\\" : [\\\"E\\\",\\\"F\\\"], \\\"bigset.starttime.2\\\" : [\\\"F\\\",\\\"B\\\"], \\\"bigset.starts.2\\\" : [\\\"B\\\"], \\\"bigset.meets.2\\\" : [\\\"F\\\",\\\"X\\\"], \\\"bigset.endtime.2\\\" : [\\\"B\\\"], \\\"bigset.midpoint.2\\\" : [\\\"E\\\",\\\"F\\\"] } //display the question and answer buttons based on input values from jsPsych document.getElementById(scenario+\\\".\\\"+question).style.display = \\\"block\\\"; if (question == \\\"strategy\\\") {document.getElementById(\\\"strategyButton\\\").style.display = \\\"block\\\";} else {document.getElementById(\\\"testingButton\\\").style.display = \\\"block\\\";} //---------SET PROPERTIES OF THE GRAPH -------------// // set the dimensions and margins of the graph var margin = {top: 25, right: 30, bottom: 90, left: 100}, width = 800, height = 800; var intersects = false; //default value for intersects scaffold var xAxisTitle, yAxisTitle; var datafile =\\\"\\\"; // SET AXIS VALUES if (axis == 1){ axis = \\\"Orthogonal-XInside-YFull\\\"; } else if (axis == 2){ axis = \\\"Orthogonal-XInside-YPartial\\\"; } else if (axis ==3){ axis = \\\"Triangular-XInside-YInside\\\"; } else if (axis ==4){ axis = \\\"Orthogonal-XInside-YInside\\\"; } else if (axis ==5){ axis = \\\"Orthogonal-XFull-YFull\\\"; } // SET EXPLICIT SCAFFOLD FEATURES if (explicit ==2 && axis != \\\"diagonal\\\"){ scaffold = 2; intersects = false; } else if (explicit == 2 && axis == \\\"diagonal\\\"){ scaffold = 2; intersects = false; } //TODO: not sure if above two lines are still valid since leaders are now generated on the fly else if (explicit == 3){ $('#hint-interactive').css(\\\"display\\\",\\\"block\\\"); //display textimage scaffold intersects = true; } //SET DATA FILE FOR IMPLICIT SCAFFOLD if (impasse == 1){ datafile = \\\"../views/src/data/acme_nonimpasse.csv\\\"; } else if (impasse == 2){ datafile = \\\"../views/src/data/acme_impasse.csv\\\"; } //OVERRIDE DATA FILE FOR NON-SCAFFOLD QUESTIONS if (q > 5) { //override data file if q# is greater than 5 datafile = \\\"../views/src/data/bigset.csv\\\"; console.log(\\\"override data file\\\"); $('#orthogonal-image').css(\\\"display\\\",\\\"none\\\"); //display textimage scaffold $('#diagonal-image').css(\\\"display\\\",\\\"none\\\"); //display textimage scaffold $('#hint-interactive').css(\\\"display\\\",\\\"none\\\"); //display textimage scaffold intersects = false; } // //---------CREATE THE SVG ------------------------// var svg = d3.select(\\\".d3container\\\").append(\\\"svg\\\") .attr(\\\"width\\\", width + margin.left + margin.right) .attr(\\\"height\\\", height + margin.top + margin.bottom) .append(\\\"g\\\") .attr(\\\"transform\\\", \\\"translate(\\\" + margin.left + \\\",\\\" + margin.top + \\\")\\\"); //---------DRAW THE GRAPH ------------------------// xAxisTitle = \\\"START & END TIME (time of day)\\\"; yAxisTitle = \\\"DURATION (in hours)\\\"; drawTriangleModel(datafile,intersects,axis,scaffold,q); \"},{\"id\":2593},{\"id\":2594},{\"nodeType\":3,\"id\":2597,\"textContent\":\" //MOUSE LOGGING SCRIPT var mouseLog = [] var xwidth = $(document).width(); var xheight = $(document).width(); mouseLog.push(\\\"{x:\\\"+xwidth+\\\",y:\\\"+xheight+\\\",t:\\\"+\\\"0};\\\") document.onmousemove = function(e){ var pageCoords = \\\"{x:\\\" + e.pageX + \\\",y:\\\"+ e.pageY +\\\",t:\\\"+ Date.now()+ \\\"};\\\" ; mouseLog.push(pageCoords); // console.log(pageCoords); }; \"},{\"id\":2595}],[],[],[]]}"
    },
    {
      "sequence": 2,
      "data": "{\"f\":\"applyChanged\",\"args\":[[],[{\"nodeType\":1,\"id\":2598,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-text-preamble\",\"class\":\"jspsych-survey-text-preamble\"},\"parentNode\":{\"id\":55}},{\"nodeType\":1,\"id\":2599,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-text-0\",\"class\":\"jspsych-survey-text-question\"},\"previousSibling\":{\"id\":2598},\"parentNode\":{\"id\":55}},{\"nodeType\":1,\"id\":2600,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-text-1\",\"class\":\"jspsych-survey-text-question\"},\"previousSibling\":{\"id\":2599},\"parentNode\":{\"id\":55}},{\"nodeType\":1,\"id\":2601,\"tagName\":\"BUTTON\",\"attributes\":{\"id\":\"jspsych-survey-text-next\",\"class\":\"jspsych-btn jspsych-survey-text\"},\"previousSibling\":{\"id\":2600},\"parentNode\":{\"id\":55}},{\"nodeType\":1,\"id\":2602,\"tagName\":\"P\",\"attributes\":{\"class\":\"jspsych-survey-text\"},\"parentNode\":{\"id\":2599}},{\"nodeType\":1,\"id\":2603,\"tagName\":\"TEXTAREA\",\"attributes\":{\"name\":\"#jspsych-survey-text-response-0\",\"cols\":\"40\",\"rows\":\"1\"},\"previousSibling\":{\"id\":2602},\"parentNode\":{\"id\":2599}},{\"nodeType\":3,\"id\":2604,\"textContent\":\"What is your age?\",\"parentNode\":{\"id\":2602}},{\"nodeType\":1,\"id\":2605,\"tagName\":\"P\",\"attributes\":{\"class\":\"jspsych-survey-text\"},\"parentNode\":{\"id\":2600}},{\"nodeType\":1,\"id\":2606,\"tagName\":\"TEXTAREA\",\"attributes\":{\"name\":\"#jspsych-survey-text-response-1\",\"cols\":\"40\",\"rows\":\"1\"},\"previousSibling\":{\"id\":2605},\"parentNode\":{\"id\":2600}},{\"nodeType\":3,\"id\":2607,\"textContent\":\"In what country were you born?\",\"parentNode\":{\"id\":2605}},{\"nodeType\":3,\"id\":2608,\"textContent\":\"Submit Answers\",\"parentNode\":{\"id\":2601}}],[],[]]}"
    },
    {
      "sequence": 3,
      "data": "{\"f\":\"applyChanged\",\"args\":[[{\"id\":2598},{\"id\":2599},{\"id\":2602},{\"id\":2604},{\"id\":2603},{\"id\":2600},{\"id\":2605},{\"id\":2607},{\"id\":2606},{\"id\":2601},{\"id\":2608}],[],[],[]]}"
    },
    {
      "sequence": 4,
      "data": "{\"f\":\"applyChanged\",\"args\":[[],[{\"nodeType\":1,\"id\":2609,\"tagName\":\"FORM\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-form\"},\"parentNode\":{\"id\":55}},{\"nodeType\":1,\"id\":2610,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-preamble\",\"class\":\"jspsych-survey-multi-choice-preamble\"},\"parentNode\":{\"id\":2609}},{\"nodeType\":1,\"id\":2611,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-0\",\"class\":\"jspsych-survey-multi-choice-question jspsych-survey-multi-choice-horizontal\"},\"previousSibling\":{\"id\":2610},\"parentNode\":{\"id\":2609}},{\"nodeType\":1,\"id\":2612,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-1\",\"class\":\"jspsych-survey-multi-choice-question jspsych-survey-multi-choice-horizontal\"},\"previousSibling\":{\"id\":2611},\"parentNode\":{\"id\":2609}},{\"nodeType\":1,\"id\":2613,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-2\",\"class\":\"jspsych-survey-multi-choice-question jspsych-survey-multi-choice-horizontal\"},\"previousSibling\":{\"id\":2612},\"parentNode\":{\"id\":2609}},{\"nodeType\":1,\"id\":2614,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-3\",\"class\":\"jspsych-survey-multi-choice-question jspsych-survey-multi-choice-horizontal\"},\"previousSibling\":{\"id\":2613},\"parentNode\":{\"id\":2609}},{\"nodeType\":1,\"id\":2615,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"submit\",\"id\":\"jspsych-survey-multi-choice-next\",\"class\":\"jspsych-survey-multi-choice jspsych-btn\",\"value\":\"Submit Answers\"},\"previousSibling\":{\"id\":2614},\"parentNode\":{\"id\":2609}},{\"nodeType\":1,\"id\":2616,\"tagName\":\"P\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text survey-multi-choice\"},\"parentNode\":{\"id\":2611}},{\"nodeType\":1,\"id\":2617,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-0-0\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2616},\"parentNode\":{\"id\":2611}},{\"nodeType\":1,\"id\":2618,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-0-1\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2617},\"parentNode\":{\"id\":2611}},{\"nodeType\":1,\"id\":2619,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-0-2\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2618},\"parentNode\":{\"id\":2611}},{\"nodeType\":1,\"id\":2620,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-0-3\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2619},\"parentNode\":{\"id\":2611}},{\"nodeType\":3,\"id\":2621,\"textContent\":\"What is your first language?\",\"parentNode\":{\"id\":2616}},{\"nodeType\":1,\"id\":2622,\"tagName\":\"SPAN\",\"attributes\":{\"class\":\"required\"},\"previousSibling\":{\"id\":2621},\"parentNode\":{\"id\":2616}},{\"nodeType\":1,\"id\":2623,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2617}},{\"nodeType\":1,\"id\":2624,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-0\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2623}},{\"nodeType\":3,\"id\":2625,\"textContent\":\"English\",\"previousSibling\":{\"id\":2624},\"parentNode\":{\"id\":2623}},{\"nodeType\":1,\"id\":2626,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2618}},{\"nodeType\":1,\"id\":2627,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-0\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2626}},{\"nodeType\":3,\"id\":2628,\"textContent\":\"Spanish\",\"previousSibling\":{\"id\":2627},\"parentNode\":{\"id\":2626}},{\"nodeType\":1,\"id\":2629,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2619}},{\"nodeType\":1,\"id\":2630,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-0\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2629}},{\"nodeType\":3,\"id\":2631,\"textContent\":\"Mandarin or Cantonese\",\"previousSibling\":{\"id\":2630},\"parentNode\":{\"id\":2629}},{\"nodeType\":1,\"id\":2632,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2620}},{\"nodeType\":1,\"id\":2633,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-0\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2632}},{\"nodeType\":3,\"id\":2634,\"textContent\":\"Other\",\"previousSibling\":{\"id\":2633},\"parentNode\":{\"id\":2632}},{\"nodeType\":3,\"id\":2635,\"textContent\":\"*\",\"parentNode\":{\"id\":2622}},{\"nodeType\":1,\"id\":2636,\"tagName\":\"P\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text survey-multi-choice\"},\"parentNode\":{\"id\":2612}},{\"nodeType\":1,\"id\":2637,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-1-0\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2636},\"parentNode\":{\"id\":2612}},{\"nodeType\":1,\"id\":2638,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-1-1\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2637},\"parentNode\":{\"id\":2612}},{\"nodeType\":1,\"id\":2639,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-1-2\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2638},\"parentNode\":{\"id\":2612}},{\"nodeType\":1,\"id\":2640,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-1-3\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2639},\"parentNode\":{\"id\":2612}},{\"nodeType\":1,\"id\":2641,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-1-4\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2640},\"parentNode\":{\"id\":2612}},{\"nodeType\":1,\"id\":2642,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-1-5\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2641},\"parentNode\":{\"id\":2612}},{\"nodeType\":1,\"id\":2643,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-1-6\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2642},\"parentNode\":{\"id\":2612}},{\"nodeType\":3,\"id\":2644,\"textContent\":\"What is your year in school?\",\"parentNode\":{\"id\":2636}},{\"nodeType\":1,\"id\":2645,\"tagName\":\"SPAN\",\"attributes\":{\"class\":\"required\"},\"previousSibling\":{\"id\":2644},\"parentNode\":{\"id\":2636}},{\"nodeType\":1,\"id\":2646,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2637}},{\"nodeType\":1,\"id\":2647,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-1\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2646}},{\"nodeType\":3,\"id\":2648,\"textContent\":\"First\",\"previousSibling\":{\"id\":2647},\"parentNode\":{\"id\":2646}},{\"nodeType\":1,\"id\":2649,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2638}},{\"nodeType\":1,\"id\":2650,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-1\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2649}},{\"nodeType\":3,\"id\":2651,\"textContent\":\"Second\",\"previousSibling\":{\"id\":2650},\"parentNode\":{\"id\":2649}},{\"nodeType\":1,\"id\":2652,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2639}},{\"nodeType\":1,\"id\":2653,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-1\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2652}},{\"nodeType\":3,\"id\":2654,\"textContent\":\"Third\",\"previousSibling\":{\"id\":2653},\"parentNode\":{\"id\":2652}},{\"nodeType\":1,\"id\":2655,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2640}},{\"nodeType\":1,\"id\":2656,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-1\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2655}},{\"nodeType\":3,\"id\":2657,\"textContent\":\"Fourth\",\"previousSibling\":{\"id\":2656},\"parentNode\":{\"id\":2655}},{\"nodeType\":1,\"id\":2658,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2641}},{\"nodeType\":1,\"id\":2659,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-1\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2658}},{\"nodeType\":3,\"id\":2660,\"textContent\":\"Fifth\",\"previousSibling\":{\"id\":2659},\"parentNode\":{\"id\":2658}},{\"nodeType\":1,\"id\":2661,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2642}},{\"nodeType\":1,\"id\":2662,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-1\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2661}},{\"nodeType\":3,\"id\":2663,\"textContent\":\"Graduate\",\"previousSibling\":{\"id\":2662},\"parentNode\":{\"id\":2661}},{\"nodeType\":1,\"id\":2664,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2643}},{\"nodeType\":1,\"id\":2665,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-1\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2664}},{\"nodeType\":3,\"id\":2666,\"textContent\":\"Other\",\"previousSibling\":{\"id\":2665},\"parentNode\":{\"id\":2664}},{\"nodeType\":3,\"id\":2667,\"textContent\":\"*\",\"parentNode\":{\"id\":2645}},{\"nodeType\":1,\"id\":2668,\"tagName\":\"P\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text survey-multi-choice\"},\"parentNode\":{\"id\":2613}},{\"nodeType\":1,\"id\":2669,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-2-0\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2668},\"parentNode\":{\"id\":2613}},{\"nodeType\":1,\"id\":2670,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-2-1\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2669},\"parentNode\":{\"id\":2613}},{\"nodeType\":1,\"id\":2671,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-2-2\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2670},\"parentNode\":{\"id\":2613}},{\"nodeType\":1,\"id\":2672,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-2-3\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2671},\"parentNode\":{\"id\":2613}},{\"nodeType\":1,\"id\":2673,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-2-4\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2672},\"parentNode\":{\"id\":2613}},{\"nodeType\":1,\"id\":2674,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-2-5\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2673},\"parentNode\":{\"id\":2613}},{\"nodeType\":1,\"id\":2675,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-2-6\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2674},\"parentNode\":{\"id\":2613}},{\"nodeType\":3,\"id\":2676,\"textContent\":\"What is your major area of study?\",\"parentNode\":{\"id\":2668}},{\"nodeType\":1,\"id\":2677,\"tagName\":\"SPAN\",\"attributes\":{\"class\":\"required\"},\"previousSibling\":{\"id\":2676},\"parentNode\":{\"id\":2668}},{\"nodeType\":1,\"id\":2678,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2669}},{\"nodeType\":1,\"id\":2679,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-2\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2678}},{\"nodeType\":3,\"id\":2680,\"textContent\":\"Math or Computer Sciences\",\"previousSibling\":{\"id\":2679},\"parentNode\":{\"id\":2678}},{\"nodeType\":1,\"id\":2681,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2670}},{\"nodeType\":1,\"id\":2682,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-2\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2681}},{\"nodeType\":3,\"id\":2683,\"textContent\":\"Social Sciences (incl. CogSci)\",\"previousSibling\":{\"id\":2682},\"parentNode\":{\"id\":2681}},{\"nodeType\":1,\"id\":2684,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2671}},{\"nodeType\":1,\"id\":2685,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-2\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2684}},{\"nodeType\":3,\"id\":2686,\"textContent\":\"Biomedical & Health Sciences\",\"previousSibling\":{\"id\":2685},\"parentNode\":{\"id\":2684}},{\"nodeType\":1,\"id\":2687,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2672}},{\"nodeType\":1,\"id\":2688,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-2\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2687}},{\"nodeType\":3,\"id\":2689,\"textContent\":\"Natural Sciences\",\"previousSibling\":{\"id\":2688},\"parentNode\":{\"id\":2687}},{\"nodeType\":1,\"id\":2690,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2673}},{\"nodeType\":1,\"id\":2691,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-2\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2690}},{\"nodeType\":3,\"id\":2692,\"textContent\":\"Engineering\",\"previousSibling\":{\"id\":2691},\"parentNode\":{\"id\":2690}},{\"nodeType\":1,\"id\":2693,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2674}},{\"nodeType\":1,\"id\":2694,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-2\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2693}},{\"nodeType\":3,\"id\":2695,\"textContent\":\"Humanities\",\"previousSibling\":{\"id\":2694},\"parentNode\":{\"id\":2693}},{\"nodeType\":1,\"id\":2696,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2675}},{\"nodeType\":1,\"id\":2697,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-2\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2696}},{\"nodeType\":3,\"id\":2698,\"textContent\":\"Fine Arts\",\"previousSibling\":{\"id\":2697},\"parentNode\":{\"id\":2696}},{\"nodeType\":3,\"id\":2699,\"textContent\":\"*\",\"parentNode\":{\"id\":2677}},{\"nodeType\":1,\"id\":2700,\"tagName\":\"P\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text survey-multi-choice\"},\"parentNode\":{\"id\":2614}},{\"nodeType\":1,\"id\":2701,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-3-0\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2700},\"parentNode\":{\"id\":2614}},{\"nodeType\":1,\"id\":2702,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-3-1\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2701},\"parentNode\":{\"id\":2614}},{\"nodeType\":1,\"id\":2703,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-3-2\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2702},\"parentNode\":{\"id\":2614}},{\"nodeType\":3,\"id\":2704,\"textContent\":\"What is your gender?\",\"parentNode\":{\"id\":2700}},{\"nodeType\":1,\"id\":2705,\"tagName\":\"SPAN\",\"attributes\":{\"class\":\"required\"},\"previousSibling\":{\"id\":2704},\"parentNode\":{\"id\":2700}},{\"nodeType\":1,\"id\":2706,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2701}},{\"nodeType\":1,\"id\":2707,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-3\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2706}},{\"nodeType\":3,\"id\":2708,\"textContent\":\"Male\",\"previousSibling\":{\"id\":2707},\"parentNode\":{\"id\":2706}},{\"nodeType\":1,\"id\":2709,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2702}},{\"nodeType\":1,\"id\":2710,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-3\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2709}},{\"nodeType\":3,\"id\":2711,\"textContent\":\"Female\",\"previousSibling\":{\"id\":2710},\"parentNode\":{\"id\":2709}},{\"nodeType\":1,\"id\":2712,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2703}},{\"nodeType\":1,\"id\":2713,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-3\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2712}},{\"nodeType\":3,\"id\":2714,\"textContent\":\"Other\",\"previousSibling\":{\"id\":2713},\"parentNode\":{\"id\":2712}},{\"nodeType\":3,\"id\":2715,\"textContent\":\"*\",\"parentNode\":{\"id\":2705}}],[],[]]}"
    },
    {
      "sequence": 5,
      "data": "{\"f\":\"applyChanged\",\"args\":[[{\"id\":2609},{\"id\":2610},{\"id\":2611},{\"id\":2616},{\"id\":2621},{\"id\":2622},{\"id\":2635},{\"id\":2617},{\"id\":2623},{\"id\":2624},{\"id\":2625},{\"id\":2618},{\"id\":2626},{\"id\":2627},{\"id\":2628},{\"id\":2619},{\"id\":2629},{\"id\":2630},{\"id\":2631},{\"id\":2620},{\"id\":2632},{\"id\":2633},{\"id\":2634},{\"id\":2612},{\"id\":2636},{\"id\":2644},{\"id\":2645},{\"id\":2667},{\"id\":2637},{\"id\":2646},{\"id\":2647},{\"id\":2648},{\"id\":2638},{\"id\":2649},{\"id\":2650},{\"id\":2651},{\"id\":2639},{\"id\":2652},{\"id\":2653},{\"id\":2654},{\"id\":2640},{\"id\":2655},{\"id\":2656},{\"id\":2657},{\"id\":2641},{\"id\":2658},{\"id\":2659},{\"id\":2660},{\"id\":2642},{\"id\":2661},{\"id\":2662},{\"id\":2663},{\"id\":2643},{\"id\":2664},{\"id\":2665},{\"id\":2666},{\"id\":2613},{\"id\":2668},{\"id\":2676},{\"id\":2677},{\"id\":2699},{\"id\":2669},{\"id\":2678},{\"id\":2679},{\"id\":2680},{\"id\":2670},{\"id\":2681},{\"id\":2682},{\"id\":2683},{\"id\":2671},{\"id\":2684},{\"id\":2685},{\"id\":2686},{\"id\":2672},{\"id\":2687},{\"id\":2688},{\"id\":2689},{\"id\":2673},{\"id\":2690},{\"id\":2691},{\"id\":2692},{\"id\":2674},{\"id\":2693},{\"id\":2694},{\"id\":2695},{\"id\":2675},{\"id\":2696},{\"id\":2697},{\"id\":2698},{\"id\":2614},{\"id\":2700},{\"id\":2704},{\"id\":2705},{\"id\":2715},{\"id\":2701},{\"id\":2706},{\"id\":2707},{\"id\":2708},{\"id\":2702},{\"id\":2709},{\"id\":2710},{\"id\":2711},{\"id\":2703},{\"id\":2712},{\"id\":2713},{\"id\":2714},{\"id\":2615}],[],[],[]]}"
    },
    {
      "sequence": 6,
      "data": "{\"f\":\"applyChanged\",\"args\":[[],[{\"nodeType\":1,\"id\":2716,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"masterdiv\"},\"parentNode\":{\"id\":55}},{\"nodeType\":3,\"id\":2717,\"textContent\":\" \",\"previousSibling\":{\"id\":2716},\"parentNode\":{\"id\":55}},{\"nodeType\":3,\"id\":2718,\"textContent\":\" \",\"parentNode\":{\"id\":2716}},{\"nodeType\":1,\"id\":2719,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"top\"},\"previousSibling\":{\"id\":2718},\"parentNode\":{\"id\":2716}},{\"nodeType\":3,\"id\":2720,\"textContent\":\" \",\"previousSibling\":{\"id\":2719},\"parentNode\":{\"id\":2716}},{\"nodeType\":1,\"id\":2721,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"instructions\"},\"previousSibling\":{\"id\":2720},\"parentNode\":{\"id\":2716}},{\"nodeType\":3,\"id\":2722,\"textContent\":\" \",\"previousSibling\":{\"id\":2721},\"parentNode\":{\"id\":2716}},{\"nodeType\":1,\"id\":2723,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bottom\"},\"previousSibling\":{\"id\":2722},\"parentNode\":{\"id\":2716}},{\"nodeType\":3,\"id\":2724,\"textContent\":\" \",\"previousSibling\":{\"id\":2723},\"parentNode\":{\"id\":2716}},{\"nodeType\":3,\"id\":2725,\"textContent\":\" \",\"parentNode\":{\"id\":2719}},{\"nodeType\":1,\"id\":2726,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bcent\"},\"previousSibling\":{\"id\":2725},\"parentNode\":{\"id\":2719}},{\"nodeType\":3,\"id\":2727,\"textContent\":\" \",\"previousSibling\":{\"id\":2726},\"parentNode\":{\"id\":2719}},{\"nodeType\":3,\"id\":2728,\"textContent\":\" \",\"parentNode\":{\"id\":2726}},{\"nodeType\":1,\"id\":2729,\"tagName\":\"H3\",\"attributes\":{},\"previousSibling\":{\"id\":2728},\"parentNode\":{\"id\":2726}},{\"nodeType\":3,\"id\":2730,\"textContent\":\" \",\"previousSibling\":{\"id\":2729},\"parentNode\":{\"id\":2726}},{\"nodeType\":3,\"id\":2731,\"textContent\":\"DEBRIEFING\",\"parentNode\":{\"id\":2729}},{\"nodeType\":3,\"id\":2732,\"textContent\":\" \",\"parentNode\":{\"id\":2721}},{\"nodeType\":1,\"id\":2733,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"vcent\"},\"previousSibling\":{\"id\":2732},\"parentNode\":{\"id\":2721}},{\"nodeType\":3,\"id\":2734,\"textContent\":\" \",\"previousSibling\":{\"id\":2733},\"parentNode\":{\"id\":2721}},{\"nodeType\":3,\"id\":2735,\"textContent\":\" \",\"parentNode\":{\"id\":2733}},{\"nodeType\":1,\"id\":2736,\"tagName\":\"P\",\"attributes\":{\"style\":\"font-style:italic\"},\"previousSibling\":{\"id\":2735},\"parentNode\":{\"id\":2733}},{\"nodeType\":1,\"id\":2737,\"tagName\":\"P\",\"attributes\":{},\"previousSibling\":{\"id\":2736},\"parentNode\":{\"id\":2733}},{\"nodeType\":3,\"id\":2738,\"textContent\":\" \",\"previousSibling\":{\"id\":2737},\"parentNode\":{\"id\":2733}},{\"nodeType\":1,\"id\":2739,\"tagName\":\"P\",\"attributes\":{},\"previousSibling\":{\"id\":2738},\"parentNode\":{\"id\":2733}},{\"nodeType\":3,\"id\":2740,\"textContent\":\" \",\"previousSibling\":{\"id\":2739},\"parentNode\":{\"id\":2733}},{\"nodeType\":1,\"id\":2741,\"tagName\":\"P\",\"attributes\":{},\"previousSibling\":{\"id\":2740},\"parentNode\":{\"id\":2733}},{\"nodeType\":3,\"id\":2742,\"textContent\":\" \",\"previousSibling\":{\"id\":2741},\"parentNode\":{\"id\":2733}},{\"nodeType\":1,\"id\":2743,\"tagName\":\"P\",\"attributes\":{\"style\":\"font-style:bold;\"},\"previousSibling\":{\"id\":2742},\"parentNode\":{\"id\":2733}},{\"nodeType\":3,\"id\":2744,\"textContent\":\" \",\"previousSibling\":{\"id\":2743},\"parentNode\":{\"id\":2733}},{\"nodeType\":1,\"id\":2745,\"tagName\":\"P\",\"attributes\":{\"style\":\"font-style:italic;\"},\"previousSibling\":{\"id\":2744},\"parentNode\":{\"id\":2733}},{\"nodeType\":3,\"id\":2746,\"textContent\":\" \",\"previousSibling\":{\"id\":2745},\"parentNode\":{\"id\":2733}},{\"nodeType\":3,\"id\":2747,\"textContent\":\"Thank you very much for your participation! This debriefing will tell you more about the study, what you did, and why. \",\"parentNode\":{\"id\":2736}},{\"nodeType\":3,\"id\":2748,\"textContent\":\" \",\"parentNode\":{\"id\":2737}},{\"nodeType\":1,\"id\":2749,\"tagName\":\"B\",\"attributes\":{},\"previousSibling\":{\"id\":2748},\"parentNode\":{\"id\":2737}},{\"nodeType\":3,\"id\":2750,\"textContent\":\" You have just used a series of pictures (charts, graphs and diagrams) accompanied by different types of instructions to answer a series of problem solving questions. While you were using the pictures, we measured where you clicked, scrolled and pointed with the computer mouse. We also measured the accuracy of your responses and the time it took to complete each question.\",\"previousSibling\":{\"id\":2749},\"parentNode\":{\"id\":2737}},{\"nodeType\":3,\"id\":2751,\"textContent\":\"What did you just do?\",\"parentNode\":{\"id\":2749}},{\"nodeType\":3,\"id\":2752,\"textContent\":\" \",\"parentNode\":{\"id\":2739}},{\"nodeType\":1,\"id\":2753,\"tagName\":\"B\",\"attributes\":{},\"previousSibling\":{\"id\":2752},\"parentNode\":{\"id\":2739}},{\"nodeType\":3,\"id\":2754,\"textContent\":\" Researchers of learning and cognition have long been interested in how graphic displays of information can be used to communicate, solve problems, and generate insights. As powerful as graphics may be in their communicative efficiency, they're not always immediately intuitive to understand. In short, we know a great deal more about learning with representations than we do about the learning of representations. In this project we are building upon previous research on reading and graph comprehension to explore how readers make sense of unfamiliar representations. The instructions you saw for each type of graph are known as “scaffolding techniques”, and we will compare your performance with the scaffolding techniques you saw with the performance of other participants to determine which types of instructions are most effective in helping humans to make sense of unfamiliar graphs. \",\"previousSibling\":{\"id\":2753},\"parentNode\":{\"id\":2739}},{\"nodeType\":3,\"id\":2755,\"textContent\":\"Why did we have you do it?\",\"parentNode\":{\"id\":2753}},{\"nodeType\":1,\"id\":2756,\"tagName\":\"B\",\"attributes\":{},\"parentNode\":{\"id\":2741}},{\"nodeType\":3,\"id\":2757,\"textContent\":\" We expect that you will have found some of the graphics more difficult to use than others. We also expect that with the assistance of the instructions, after solving several problems you will learn to use the difficult graphics so that you can answer the questions even more quickly than without. If you would like to receive a copy of the results of the study, or have any further questions, please contact the researchers Primary Researcher: Amy Fox : a2fox@ucsd.edu Faculty Advisor : Dr. Jim Hollan : hollan@ucsd.edu \",\"previousSibling\":{\"id\":2756},\"parentNode\":{\"id\":2741}},{\"nodeType\":3,\"id\":2758,\"textContent\":\"What do we expect to find?\",\"parentNode\":{\"id\":2756}},{\"nodeType\":3,\"id\":2759,\"textContent\":\"It is important that you do not discuss this experiment with other students who might participate after you. They must participate in the same way as you did, without any knowledge of what the experiment entails, or the reasoning behind it.\",\"parentNode\":{\"id\":2743}},{\"nodeType\":3,\"id\":2760,\"textContent\":\"Thank you for your time! We hope you enjoyed participating in this study as much as we enjoyed designing it.\",\"parentNode\":{\"id\":2745}},{\"nodeType\":3,\"id\":2761,\"textContent\":\" \",\"parentNode\":{\"id\":2723}},{\"nodeType\":1,\"id\":2762,\"tagName\":\"BUTTON\",\"attributes\":{\"class\":\"btn\",\"type\":\"button\",\"id\":\"start\"},\"previousSibling\":{\"id\":2761},\"parentNode\":{\"id\":2723}},{\"nodeType\":3,\"id\":2763,\"textContent\":\" \",\"previousSibling\":{\"id\":2762},\"parentNode\":{\"id\":2723}},{\"nodeType\":3,\"id\":2764,\"textContent\":\"FINISH\",\"parentNode\":{\"id\":2762}}],[],[]]}"
    },
    {
      "sequence": 7,
      "data": "{\"f\":\"applyChanged\",\"args\":[[{\"id\":2716},{\"id\":2718},{\"id\":2719},{\"id\":2725},{\"id\":2726},{\"id\":2728},{\"id\":2729},{\"id\":2731},{\"id\":2730},{\"id\":2727},{\"id\":2720},{\"id\":2721},{\"id\":2732},{\"id\":2733},{\"id\":2735},{\"id\":2736},{\"id\":2747},{\"id\":2737},{\"id\":2748},{\"id\":2749},{\"id\":2751},{\"id\":2750},{\"id\":2738},{\"id\":2739},{\"id\":2752},{\"id\":2753},{\"id\":2755},{\"id\":2754},{\"id\":2740},{\"id\":2741},{\"id\":2756},{\"id\":2758},{\"id\":2757},{\"id\":2742},{\"id\":2743},{\"id\":2759},{\"id\":2744},{\"id\":2745},{\"id\":2760},{\"id\":2746},{\"id\":2734},{\"id\":2722},{\"id\":2723},{\"id\":2761},{\"id\":2762},{\"id\":2764},{\"id\":2763},{\"id\":2724},{\"id\":2717}],[],[],[]]}"
    },
    {
      "sequence": 8,
      "data": "{\"f\":\"applyChanged\",\"args\":[[],[{\"nodeType\":1,\"id\":2765,\"tagName\":\"PRE\",\"attributes\":{\"id\":\"jspsych-data-display\"},\"parentNode\":{\"id\":55}},{\"nodeType\":3,\"id\":2766,\"textContent\":\"[ { \\\"rt\\\": 68799, \\\"stimulus\\\": \\\"img/phone.png\\\", \\\"key_press\\\": 32, \\\"block\\\": \\\"phone\\\", \\\"trial_type\\\": \\\"single-stim\\\", \\\"trial_index\\\": 0, \\\"time_elapsed\\\": 68806, \\\"internal_node_id\\\": \\\"0.0-0.0\\\", \\\"subject\\\": \\\"R06S6\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"echo\\\", \\\"condition\\\": \\\"121\\\" }, { \\\"rt\\\": 52558, \\\"url\\\": \\\"../views/src/external/consent.html\\\", \\\"block\\\": \\\"consent\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 1, \\\"time_elapsed\\\": 122696, \\\"internal_node_id\\\": \\\"0.0-1.0\\\", \\\"subject\\\": \\\"R06S6\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"echo\\\", \\\"condition\\\": \\\"121\\\" }, { \\\"rt\\\": 8603, \\\"responses\\\": \\\"{\\\\\\\"Q0\\\\\\\":\\\\\\\"echo\\\\\\\",\\\\\\\"Q1\\\\\\\":\\\\\\\"121\\\\\\\"}\\\", \\\"block\\\": \\\"codes\\\", \\\"trial_type\\\": \\\"survey-text\\\", \\\"trial_index\\\": 2, \\\"time_elapsed\\\": 132303, \\\"internal_node_id\\\": \\\"0.0-2.0\\\", \\\"subject\\\": \\\"R06S6\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"echo\\\", \\\"condition\\\": \\\"121\\\" }, { \\\"rt\\\": 16431, \\\"url\\\": \\\"../views/src/external/instructions_lab.html\\\", \\\"block\\\": \\\"instructions_lab\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 3, \\\"time_elapsed\\\": 150063, \\\"internal_node_id\\\": \\\"0.0-3.0\\\", \\\"subject\\\": \\\"R06S6\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"echo\\\", \\\"condition\\\": \\\"121\\\" }, { \\\"rt\\\": 14066, \\\"stimulus\\\": \\\"img/acme.png\\\", \\\"key_press\\\": 13, \\\"block\\\": \\\"scenario\\\", \\\"trial_type\\\": \\\"single-stim\\\", \\\"trial_index\\\": 4, \\\"time_elapsed\\\": 165132, \\\"internal_node_id\\\": \\\"0.0-4.0\\\", \\\"subject\\\": \\\"R06S6\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"echo\\\", \\\"condition\\\": \\\"121\\\" }, { \\\"rt\\\": 10053, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 5, \\\"time_elapsed\\\": 176536, \\\"internal_node_id\\\": \\\"0.0-5.0-0.0\\\", \\\"subject\\\": \\\"R06S6\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"echo\\\", \\\"condition\\\": \\\"121\\\", \\\"scenario\\\": \\\"acme\\\", \\\"question\\\": \\\"starttime\\\", \\\"q\\\": 1, \\\"clicks\\\": 1, \\\"explicit\\\": 1, \\\"impasse\\\": 2, \\\"axis\\\": \\\"Orthogonal-XInside-YFull\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 0, \\\"answer\\\": [ \\\"O\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"U \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-01 PM-11 AM\\\", \\\"block\\\": \\\"triangular_scaffolded\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:1090,y:1028,t:1527009001612};\\\", \\\"{x:1077,y:1024,t:1527009001646};\\\", \\\"{x:1071,y:1024,t:1527009001836};\\\", \\\"{x:1098,y:1024,t:1527009002225};\\\", \\\"{x:1146,y:1010,t:1527009002238};\\\", \\\"{x:1233,y:961,t:1527009002255};\\\", \\\"{x:1288,y:936,t:1527009002272};\\\", \\\"{x:1307,y:932,t:1527009002290};\\\", \\\"{x:1307,y:931,t:1527009002336};\\\", \\\"{x:1303,y:929,t:1527009002344};\\\", \\\"{x:1291,y:925,t:1527009002354};\\\", \\\"{x:1275,y:922,t:1527009002371};\\\", \\\"{x:1265,y:921,t:1527009002388};\\\", \\\"{x:1259,y:921,t:1527009002405};\\\", \\\"{x:1253,y:929,t:1527009002421};\\\", \\\"{x:1251,y:942,t:1527009002438};\\\", \\\"{x:1249,y:949,t:1527009002706};\\\", \\\"{x:1225,y:1001,t:1527009002722};\\\", \\\"{x:1208,y:1037,t:1527009002739};\\\", \\\"{x:1196,y:1061,t:1527009002755};\\\", \\\"{x:1194,y:1066,t:1527009002772};\\\", \\\"{x:1194,y:1063,t:1527009002809};\\\", \\\"{x:1194,y:1059,t:1527009002822};\\\", \\\"{x:1194,y:1052,t:1527009002839};\\\", \\\"{x:1194,y:1048,t:1527009002856};\\\", \\\"{x:1192,y:1041,t:1527009002871};\\\", \\\"{x:1172,y:1029,t:1527009002890};\\\", \\\"{x:1158,y:1018,t:1527009002905};\\\", \\\"{x:1152,y:1015,t:1527009002922};\\\", \\\"{x:1145,y:1012,t:1527009002939};\\\", \\\"{x:1133,y:1006,t:1527009002955};\\\", \\\"{x:1112,y:991,t:1527009002971};\\\", \\\"{x:1073,y:964,t:1527009002989};\\\", \\\"{x:1023,y:930,t:1527009003006};\\\", \\\"{x:964,y:891,t:1527009003021};\\\", \\\"{x:905,y:846,t:1527009003038};\\\", \\\"{x:853,y:803,t:1527009003056};\\\", \\\"{x:817,y:772,t:1527009003072};\\\", \\\"{x:764,y:731,t:1527009003090};\\\", \\\"{x:731,y:710,t:1527009003106};\\\", \\\"{x:701,y:693,t:1527009003122};\\\", \\\"{x:684,y:683,t:1527009003139};\\\", \\\"{x:668,y:675,t:1527009003156};\\\", \\\"{x:655,y:669,t:1527009003172};\\\", \\\"{x:649,y:665,t:1527009003188};\\\", \\\"{x:638,y:661,t:1527009003206};\\\", \\\"{x:628,y:658,t:1527009003222};\\\", \\\"{x:612,y:653,t:1527009003239};\\\", \\\"{x:606,y:651,t:1527009003256};\\\", \\\"{x:605,y:651,t:1527009003271};\\\", \\\"{x:603,y:649,t:1527009003293};\\\", \\\"{x:599,y:647,t:1527009003305};\\\", \\\"{x:597,y:646,t:1527009003323};\\\", \\\"{x:591,y:641,t:1527009003338};\\\", \\\"{x:582,y:633,t:1527009003355};\\\", \\\"{x:569,y:624,t:1527009003372};\\\", \\\"{x:553,y:612,t:1527009003389};\\\", \\\"{x:532,y:597,t:1527009003405};\\\", \\\"{x:508,y:583,t:1527009003423};\\\", \\\"{x:477,y:565,t:1527009003439};\\\", \\\"{x:458,y:552,t:1527009003455};\\\", \\\"{x:441,y:538,t:1527009003472};\\\", \\\"{x:437,y:533,t:1527009003490};\\\", \\\"{x:436,y:531,t:1527009003505};\\\", \\\"{x:436,y:530,t:1527009003522};\\\", \\\"{x:435,y:529,t:1527009003538};\\\", \\\"{x:435,y:528,t:1527009003576};\\\", \\\"{x:435,y:527,t:1527009003600};\\\", \\\"{x:435,y:526,t:1527009003625};\\\", \\\"{x:435,y:525,t:1527009003639};\\\", \\\"{x:435,y:524,t:1527009003656};\\\", \\\"{x:436,y:518,t:1527009003672};\\\", \\\"{x:439,y:515,t:1527009003690};\\\", \\\"{x:440,y:513,t:1527009003706};\\\", \\\"{x:443,y:511,t:1527009003723};\\\", \\\"{x:445,y:507,t:1527009003740};\\\", \\\"{x:447,y:505,t:1527009003757};\\\", \\\"{x:453,y:499,t:1527009003772};\\\", \\\"{x:458,y:495,t:1527009003789};\\\", \\\"{x:465,y:490,t:1527009003805};\\\", \\\"{x:469,y:487,t:1527009003822};\\\", \\\"{x:472,y:486,t:1527009003840};\\\", \\\"{x:473,y:485,t:1527009003855};\\\", \\\"{x:480,y:482,t:1527009003872};\\\", \\\"{x:485,y:480,t:1527009003889};\\\", \\\"{x:492,y:479,t:1527009003905};\\\", \\\"{x:501,y:476,t:1527009003922};\\\", \\\"{x:510,y:475,t:1527009003939};\\\", \\\"{x:517,y:474,t:1527009003956};\\\", \\\"{x:532,y:474,t:1527009003973};\\\", \\\"{x:557,y:474,t:1527009003989};\\\", \\\"{x:588,y:474,t:1527009004006};\\\", \\\"{x:621,y:474,t:1527009004023};\\\", \\\"{x:657,y:477,t:1527009004041};\\\", \\\"{x:687,y:483,t:1527009004056};\\\", \\\"{x:735,y:489,t:1527009004072};\\\", \\\"{x:773,y:496,t:1527009004089};\\\", \\\"{x:806,y:501,t:1527009004106};\\\", \\\"{x:839,y:507,t:1527009004123};\\\", \\\"{x:868,y:512,t:1527009004139};\\\", \\\"{x:897,y:522,t:1527009004156};\\\", \\\"{x:930,y:534,t:1527009004172};\\\", \\\"{x:973,y:554,t:1527009004189};\\\", \\\"{x:1023,y:577,t:1527009004207};\\\", \\\"{x:1070,y:597,t:1527009004222};\\\", \\\"{x:1116,y:621,t:1527009004239};\\\", \\\"{x:1174,y:650,t:1527009004256};\\\", \\\"{x:1206,y:675,t:1527009004272};\\\", \\\"{x:1240,y:691,t:1527009004289};\\\", \\\"{x:1277,y:709,t:1527009004307};\\\", \\\"{x:1309,y:726,t:1527009004322};\\\", \\\"{x:1352,y:747,t:1527009004339};\\\", \\\"{x:1414,y:781,t:1527009004356};\\\", \\\"{x:1502,y:833,t:1527009004372};\\\", \\\"{x:1548,y:869,t:1527009004389};\\\", \\\"{x:1557,y:877,t:1527009004407};\\\", \\\"{x:1558,y:878,t:1527009004424};\\\", \\\"{x:1559,y:878,t:1527009004439};\\\", \\\"{x:1560,y:879,t:1527009004456};\\\", \\\"{x:1562,y:880,t:1527009004480};\\\", \\\"{x:1562,y:882,t:1527009004489};\\\", \\\"{x:1562,y:886,t:1527009004507};\\\", \\\"{x:1562,y:890,t:1527009004523};\\\", \\\"{x:1562,y:897,t:1527009004539};\\\", \\\"{x:1562,y:907,t:1527009004557};\\\", \\\"{x:1562,y:914,t:1527009004574};\\\", \\\"{x:1558,y:922,t:1527009004590};\\\", \\\"{x:1555,y:926,t:1527009004607};\\\", \\\"{x:1552,y:928,t:1527009004624};\\\", \\\"{x:1549,y:930,t:1527009004640};\\\", \\\"{x:1547,y:930,t:1527009004656};\\\", \\\"{x:1546,y:931,t:1527009004674};\\\", \\\"{x:1545,y:931,t:1527009004690};\\\", \\\"{x:1542,y:931,t:1527009004706};\\\", \\\"{x:1540,y:931,t:1527009004723};\\\", \\\"{x:1537,y:931,t:1527009004739};\\\", \\\"{x:1532,y:932,t:1527009004757};\\\", \\\"{x:1527,y:933,t:1527009004774};\\\", \\\"{x:1519,y:935,t:1527009004789};\\\", \\\"{x:1505,y:941,t:1527009004807};\\\", \\\"{x:1487,y:950,t:1527009004824};\\\", \\\"{x:1456,y:962,t:1527009004841};\\\", \\\"{x:1437,y:971,t:1527009004857};\\\", \\\"{x:1422,y:974,t:1527009004874};\\\", \\\"{x:1405,y:980,t:1527009004890};\\\", \\\"{x:1389,y:988,t:1527009004908};\\\", \\\"{x:1371,y:994,t:1527009004924};\\\", \\\"{x:1358,y:1000,t:1527009004940};\\\", \\\"{x:1345,y:1005,t:1527009004957};\\\", \\\"{x:1339,y:1009,t:1527009004973};\\\", \\\"{x:1334,y:1010,t:1527009004991};\\\", \\\"{x:1333,y:1010,t:1527009005007};\\\", \\\"{x:1332,y:1010,t:1527009005023};\\\", \\\"{x:1327,y:1010,t:1527009005041};\\\", \\\"{x:1313,y:1010,t:1527009005057};\\\", \\\"{x:1294,y:1002,t:1527009005074};\\\", \\\"{x:1279,y:1000,t:1527009005091};\\\", \\\"{x:1269,y:998,t:1527009005106};\\\", \\\"{x:1266,y:997,t:1527009005123};\\\", \\\"{x:1265,y:996,t:1527009005145};\\\", \\\"{x:1264,y:996,t:1527009005273};\\\", \\\"{x:1264,y:994,t:1527009005290};\\\", \\\"{x:1265,y:994,t:1527009005307};\\\", \\\"{x:1266,y:993,t:1527009005324};\\\", \\\"{x:1268,y:992,t:1527009005341};\\\", \\\"{x:1270,y:992,t:1527009005358};\\\", \\\"{x:1271,y:991,t:1527009005374};\\\", \\\"{x:1272,y:991,t:1527009005391};\\\", \\\"{x:1273,y:991,t:1527009005408};\\\", \\\"{x:1275,y:991,t:1527009005424};\\\", \\\"{x:1276,y:991,t:1527009005561};\\\", \\\"{x:1277,y:991,t:1527009005575};\\\", \\\"{x:1278,y:991,t:1527009005609};\\\", \\\"{x:1280,y:991,t:1527009005633};\\\", \\\"{x:1281,y:991,t:1527009005641};\\\", \\\"{x:1285,y:991,t:1527009005658};\\\", \\\"{x:1289,y:989,t:1527009005674};\\\", \\\"{x:1293,y:988,t:1527009005691};\\\", \\\"{x:1295,y:987,t:1527009005708};\\\", \\\"{x:1296,y:987,t:1527009007818};\\\", \\\"{x:1296,y:981,t:1527009008130};\\\", \\\"{x:1292,y:965,t:1527009008144};\\\", \\\"{x:1272,y:923,t:1527009008161};\\\", \\\"{x:1225,y:837,t:1527009008176};\\\", \\\"{x:1199,y:776,t:1527009008193};\\\", \\\"{x:1172,y:720,t:1527009008210};\\\", \\\"{x:1142,y:666,t:1527009008227};\\\", \\\"{x:1111,y:618,t:1527009008243};\\\", \\\"{x:1086,y:582,t:1527009008260};\\\", \\\"{x:1070,y:563,t:1527009008278};\\\", \\\"{x:1058,y:548,t:1527009008293};\\\", \\\"{x:1047,y:540,t:1527009008310};\\\", \\\"{x:1030,y:531,t:1527009008328};\\\", \\\"{x:1014,y:525,t:1527009008344};\\\", \\\"{x:995,y:518,t:1527009008361};\\\", \\\"{x:967,y:509,t:1527009008377};\\\", \\\"{x:950,y:507,t:1527009008395};\\\", \\\"{x:933,y:505,t:1527009008410};\\\", \\\"{x:917,y:505,t:1527009008426};\\\", \\\"{x:896,y:513,t:1527009008442};\\\", \\\"{x:878,y:523,t:1527009008459};\\\", \\\"{x:859,y:536,t:1527009008475};\\\", \\\"{x:845,y:549,t:1527009008493};\\\", \\\"{x:831,y:557,t:1527009008510};\\\", \\\"{x:820,y:561,t:1527009008525};\\\", \\\"{x:809,y:562,t:1527009008542};\\\", \\\"{x:807,y:562,t:1527009008559};\\\", \\\"{x:807,y:561,t:1527009008648};\\\", \\\"{x:807,y:560,t:1527009008664};\\\", \\\"{x:808,y:558,t:1527009008676};\\\", \\\"{x:811,y:555,t:1527009008692};\\\", \\\"{x:817,y:549,t:1527009008710};\\\", \\\"{x:821,y:544,t:1527009008726};\\\", \\\"{x:823,y:541,t:1527009008743};\\\", \\\"{x:824,y:539,t:1527009008760};\\\", \\\"{x:825,y:537,t:1527009008776};\\\", \\\"{x:825,y:535,t:1527009008794};\\\", \\\"{x:826,y:533,t:1527009008809};\\\", \\\"{x:827,y:531,t:1527009008827};\\\", \\\"{x:827,y:529,t:1527009008848};\\\", \\\"{x:827,y:528,t:1527009008880};\\\", \\\"{x:823,y:527,t:1527009009233};\\\", \\\"{x:817,y:527,t:1527009009243};\\\", \\\"{x:809,y:538,t:1527009009260};\\\", \\\"{x:799,y:551,t:1527009009277};\\\", \\\"{x:783,y:566,t:1527009009293};\\\", \\\"{x:767,y:576,t:1527009009311};\\\", \\\"{x:756,y:585,t:1527009009327};\\\", \\\"{x:731,y:602,t:1527009009344};\\\", \\\"{x:717,y:611,t:1527009009360};\\\", \\\"{x:704,y:621,t:1527009009377};\\\", \\\"{x:689,y:631,t:1527009009394};\\\", \\\"{x:672,y:643,t:1527009009410};\\\", \\\"{x:654,y:655,t:1527009009427};\\\", \\\"{x:632,y:668,t:1527009009443};\\\", \\\"{x:608,y:678,t:1527009009460};\\\", \\\"{x:574,y:696,t:1527009009476};\\\", \\\"{x:528,y:714,t:1527009009494};\\\", \\\"{x:487,y:731,t:1527009009510};\\\", \\\"{x:457,y:739,t:1527009009527};\\\", \\\"{x:423,y:747,t:1527009009544};\\\", \\\"{x:416,y:750,t:1527009009560};\\\", \\\"{x:411,y:753,t:1527009009577};\\\", \\\"{x:407,y:755,t:1527009009593};\\\", \\\"{x:406,y:755,t:1527009009611};\\\", \\\"{x:406,y:756,t:1527009009632};\\\", \\\"{x:408,y:756,t:1527009009648};\\\", \\\"{x:410,y:756,t:1527009009661};\\\", \\\"{x:416,y:753,t:1527009009678};\\\", \\\"{x:419,y:750,t:1527009009693};\\\", \\\"{x:426,y:746,t:1527009009711};\\\", \\\"{x:433,y:743,t:1527009009728};\\\", \\\"{x:437,y:742,t:1527009009744};\\\", \\\"{x:443,y:739,t:1527009009761};\\\", \\\"{x:449,y:736,t:1527009009778};\\\", \\\"{x:453,y:735,t:1527009009794};\\\", \\\"{x:464,y:732,t:1527009009812};\\\", \\\"{x:477,y:730,t:1527009009827};\\\", \\\"{x:484,y:727,t:1527009009843};\\\", \\\"{x:486,y:727,t:1527009009859};\\\", \\\"{x:487,y:726,t:1527009009876};\\\", \\\"{x:488,y:726,t:1527009009894};\\\", \\\"{x:490,y:723,t:1527009009909};\\\", \\\"{x:490,y:721,t:1527009009926};\\\", \\\"{x:491,y:718,t:1527009009944};\\\", \\\"{x:494,y:713,t:1527009009960};\\\", \\\"{x:496,y:710,t:1527009009976};\\\", \\\"{x:497,y:709,t:1527009009993};\\\", \\\"{x:497,y:708,t:1527009010009};\\\", \\\"{x:497,y:707,t:1527009010027};\\\", \\\"{x:497,y:704,t:1527009012129};\\\", \\\"{x:495,y:699,t:1527009012147};\\\", \\\"{x:495,y:693,t:1527009012163};\\\", \\\"{x:491,y:687,t:1527009012179};\\\", \\\"{x:491,y:684,t:1527009012196};\\\", \\\"{x:491,y:683,t:1527009012213};\\\", \\\"{x:489,y:681,t:1527009012229};\\\", \\\"{x:489,y:679,t:1527009012328};\\\", \\\"{x:489,y:677,t:1527009012346};\\\", \\\"{x:489,y:674,t:1527009012363};\\\", \\\"{x:487,y:671,t:1527009012379};\\\", \\\"{x:486,y:667,t:1527009012396};\\\", \\\"{x:485,y:664,t:1527009012413};\\\", \\\"{x:484,y:661,t:1527009012429};\\\", \\\"{x:484,y:659,t:1527009012449};\\\", \\\"{x:484,y:658,t:1527009012465};\\\", \\\"{x:484,y:657,t:1527009012481};\\\", \\\"{x:483,y:656,t:1527009012504};\\\", \\\"{x:482,y:655,t:1527009012512};\\\", \\\"{x:482,y:654,t:1527009012529};\\\", \\\"{x:482,y:651,t:1527009012546};\\\", \\\"{x:480,y:648,t:1527009012563};\\\", \\\"{x:479,y:645,t:1527009012579};\\\", \\\"{x:477,y:640,t:1527009012596};\\\", \\\"{x:474,y:631,t:1527009012613};\\\", \\\"{x:468,y:620,t:1527009012630};\\\", \\\"{x:465,y:614,t:1527009012646};\\\", \\\"{x:458,y:603,t:1527009012663};\\\", \\\"{x:438,y:575,t:1527009012732};\\\", \\\"{x:437,y:572,t:1527009012745};\\\", \\\"{x:437,y:570,t:1527009012763};\\\", \\\"{x:436,y:566,t:1527009012780};\\\", \\\"{x:436,y:565,t:1527009012800};\\\" ] }, { \\\"rt\\\": 31823, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 6, \\\"time_elapsed\\\": 209609, \\\"internal_node_id\\\": \\\"0.0-5.0-1.0\\\", \\\"subject\\\": \\\"R06S6\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"echo\\\", \\\"condition\\\": \\\"121\\\", \\\"scenario\\\": \\\"acme\\\", \\\"question\\\": \\\"starts\\\", \\\"q\\\": 2, \\\"clicks\\\": 1, \\\"explicit\\\": 1, \\\"impasse\\\": 2, \\\"axis\\\": \\\"Orthogonal-XInside-YFull\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 0, \\\"answer\\\": [ \\\"G\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"U \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-F -D -D \\\", \\\"block\\\": \\\"triangular_scaffolded\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:436,y:564,t:1527009012916};\\\", \\\"{x:436,y:563,t:1527009013136};\\\", \\\"{x:436,y:562,t:1527009013147};\\\", \\\"{x:436,y:561,t:1527009013162};\\\", \\\"{x:436,y:560,t:1527009013180};\\\", \\\"{x:436,y:559,t:1527009013197};\\\", \\\"{x:436,y:558,t:1527009013213};\\\", \\\"{x:436,y:557,t:1527009013230};\\\", \\\"{x:436,y:556,t:1527009013247};\\\", \\\"{x:436,y:554,t:1527009013263};\\\", \\\"{x:436,y:552,t:1527009013280};\\\", \\\"{x:436,y:551,t:1527009013296};\\\", \\\"{x:436,y:544,t:1527009013406};\\\", \\\"{x:436,y:542,t:1527009013416};\\\", \\\"{x:436,y:540,t:1527009013429};\\\", \\\"{x:436,y:538,t:1527009013447};\\\", \\\"{x:436,y:533,t:1527009013464};\\\", \\\"{x:436,y:529,t:1527009013480};\\\", \\\"{x:436,y:525,t:1527009013497};\\\", \\\"{x:436,y:521,t:1527009013514};\\\", \\\"{x:434,y:516,t:1527009013529};\\\", \\\"{x:434,y:514,t:1527009013547};\\\", \\\"{x:433,y:513,t:1527009013564};\\\", \\\"{x:433,y:511,t:1527009013913};\\\", \\\"{x:433,y:508,t:1527009013920};\\\", \\\"{x:433,y:507,t:1527009013931};\\\", \\\"{x:433,y:506,t:1527009013947};\\\", \\\"{x:433,y:503,t:1527009013965};\\\", \\\"{x:433,y:501,t:1527009013981};\\\", \\\"{x:433,y:500,t:1527009013997};\\\", \\\"{x:433,y:498,t:1527009014013};\\\", \\\"{x:433,y:497,t:1527009014136};\\\", \\\"{x:433,y:495,t:1527009014168};\\\", \\\"{x:433,y:493,t:1527009014181};\\\", \\\"{x:434,y:491,t:1527009014197};\\\", \\\"{x:436,y:490,t:1527009014214};\\\", \\\"{x:437,y:488,t:1527009014231};\\\", \\\"{x:438,y:487,t:1527009014247};\\\", \\\"{x:439,y:486,t:1527009014267};\\\", \\\"{x:441,y:485,t:1527009014284};\\\", \\\"{x:443,y:483,t:1527009014300};\\\", \\\"{x:448,y:480,t:1527009014317};\\\", \\\"{x:453,y:477,t:1527009014334};\\\", \\\"{x:457,y:475,t:1527009014351};\\\", \\\"{x:462,y:473,t:1527009014367};\\\", \\\"{x:466,y:472,t:1527009014384};\\\", \\\"{x:471,y:470,t:1527009014401};\\\", \\\"{x:475,y:469,t:1527009014417};\\\", \\\"{x:482,y:466,t:1527009014434};\\\", \\\"{x:492,y:464,t:1527009014451};\\\", \\\"{x:501,y:463,t:1527009014468};\\\", \\\"{x:511,y:462,t:1527009014484};\\\", \\\"{x:521,y:461,t:1527009014501};\\\", \\\"{x:535,y:461,t:1527009014517};\\\", \\\"{x:553,y:461,t:1527009014534};\\\", \\\"{x:576,y:461,t:1527009014551};\\\", \\\"{x:602,y:461,t:1527009014567};\\\", \\\"{x:635,y:461,t:1527009014584};\\\", \\\"{x:668,y:461,t:1527009014601};\\\", \\\"{x:705,y:461,t:1527009014617};\\\", \\\"{x:756,y:461,t:1527009014633};\\\", \\\"{x:836,y:472,t:1527009014651};\\\", \\\"{x:897,y:482,t:1527009014668};\\\", \\\"{x:959,y:490,t:1527009014684};\\\", \\\"{x:1025,y:506,t:1527009014702};\\\", \\\"{x:1074,y:514,t:1527009014717};\\\", \\\"{x:1078,y:515,t:1527009014734};\\\", \\\"{x:1079,y:515,t:1527009015180};\\\", \\\"{x:1081,y:516,t:1527009015220};\\\", \\\"{x:1082,y:516,t:1527009015260};\\\", \\\"{x:1084,y:517,t:1527009015276};\\\", \\\"{x:1087,y:518,t:1527009015285};\\\", \\\"{x:1107,y:524,t:1527009015301};\\\", \\\"{x:1152,y:536,t:1527009015318};\\\", \\\"{x:1221,y:552,t:1527009015336};\\\", \\\"{x:1312,y:563,t:1527009015352};\\\", \\\"{x:1418,y:581,t:1527009015369};\\\", \\\"{x:1536,y:606,t:1527009015386};\\\", \\\"{x:1648,y:628,t:1527009015402};\\\", \\\"{x:1742,y:654,t:1527009015419};\\\", \\\"{x:1837,y:683,t:1527009015436};\\\", \\\"{x:1866,y:694,t:1527009015451};\\\", \\\"{x:1879,y:702,t:1527009015468};\\\", \\\"{x:1882,y:705,t:1527009015486};\\\", \\\"{x:1882,y:706,t:1527009015501};\\\", \\\"{x:1883,y:706,t:1527009015523};\\\", \\\"{x:1883,y:708,t:1527009015535};\\\", \\\"{x:1877,y:719,t:1527009015551};\\\", \\\"{x:1869,y:734,t:1527009015568};\\\", \\\"{x:1856,y:753,t:1527009015585};\\\", \\\"{x:1843,y:776,t:1527009015600};\\\", \\\"{x:1826,y:801,t:1527009015618};\\\", \\\"{x:1793,y:842,t:1527009015634};\\\", \\\"{x:1770,y:864,t:1527009015651};\\\", \\\"{x:1750,y:880,t:1527009015668};\\\", \\\"{x:1726,y:897,t:1527009015685};\\\", \\\"{x:1708,y:909,t:1527009015702};\\\", \\\"{x:1687,y:920,t:1527009015718};\\\", \\\"{x:1668,y:930,t:1527009015735};\\\", \\\"{x:1648,y:936,t:1527009015751};\\\", \\\"{x:1637,y:937,t:1527009015768};\\\", \\\"{x:1629,y:937,t:1527009015784};\\\", \\\"{x:1623,y:937,t:1527009015802};\\\", \\\"{x:1614,y:931,t:1527009015817};\\\", \\\"{x:1598,y:919,t:1527009015835};\\\", \\\"{x:1589,y:911,t:1527009015852};\\\", \\\"{x:1584,y:906,t:1527009015867};\\\", \\\"{x:1582,y:902,t:1527009015885};\\\", \\\"{x:1575,y:891,t:1527009015902};\\\", \\\"{x:1575,y:889,t:1527009015918};\\\", \\\"{x:1575,y:878,t:1527009015935};\\\", \\\"{x:1577,y:865,t:1527009015952};\\\", \\\"{x:1583,y:851,t:1527009015968};\\\", \\\"{x:1586,y:838,t:1527009015986};\\\", \\\"{x:1587,y:826,t:1527009016002};\\\", \\\"{x:1588,y:816,t:1527009016018};\\\", \\\"{x:1589,y:804,t:1527009016035};\\\", \\\"{x:1589,y:800,t:1527009016051};\\\", \\\"{x:1590,y:799,t:1527009016068};\\\", \\\"{x:1590,y:797,t:1527009016085};\\\", \\\"{x:1590,y:796,t:1527009016116};\\\", \\\"{x:1590,y:795,t:1527009016132};\\\", \\\"{x:1590,y:794,t:1527009016148};\\\", \\\"{x:1590,y:793,t:1527009016332};\\\", \\\"{x:1589,y:793,t:1527009016339};\\\", \\\"{x:1586,y:791,t:1527009016352};\\\", \\\"{x:1578,y:789,t:1527009016369};\\\", \\\"{x:1567,y:785,t:1527009016385};\\\", \\\"{x:1553,y:781,t:1527009016402};\\\", \\\"{x:1531,y:774,t:1527009016419};\\\", \\\"{x:1523,y:772,t:1527009016436};\\\", \\\"{x:1518,y:770,t:1527009016452};\\\", \\\"{x:1514,y:770,t:1527009016470};\\\", \\\"{x:1510,y:769,t:1527009016486};\\\", \\\"{x:1509,y:768,t:1527009016503};\\\", \\\"{x:1505,y:767,t:1527009016519};\\\", \\\"{x:1502,y:766,t:1527009016537};\\\", \\\"{x:1497,y:765,t:1527009016552};\\\", \\\"{x:1494,y:763,t:1527009016569};\\\", \\\"{x:1489,y:761,t:1527009016586};\\\", \\\"{x:1486,y:759,t:1527009016603};\\\", \\\"{x:1478,y:756,t:1527009016620};\\\", \\\"{x:1469,y:755,t:1527009016635};\\\", \\\"{x:1461,y:752,t:1527009016652};\\\", \\\"{x:1451,y:751,t:1527009016669};\\\", \\\"{x:1437,y:750,t:1527009016687};\\\", \\\"{x:1425,y:747,t:1527009016702};\\\", \\\"{x:1407,y:746,t:1527009016720};\\\", \\\"{x:1382,y:743,t:1527009016737};\\\", \\\"{x:1356,y:741,t:1527009016751};\\\", \\\"{x:1328,y:741,t:1527009016769};\\\", \\\"{x:1298,y:741,t:1527009016786};\\\", \\\"{x:1270,y:741,t:1527009016802};\\\", \\\"{x:1232,y:740,t:1527009016819};\\\", \\\"{x:1216,y:739,t:1527009016836};\\\", \\\"{x:1211,y:738,t:1527009016852};\\\", \\\"{x:1211,y:737,t:1527009016868};\\\", \\\"{x:1211,y:736,t:1527009016948};\\\", \\\"{x:1212,y:735,t:1527009016956};\\\", \\\"{x:1213,y:734,t:1527009016969};\\\", \\\"{x:1214,y:734,t:1527009016986};\\\", \\\"{x:1216,y:732,t:1527009017002};\\\", \\\"{x:1219,y:730,t:1527009017018};\\\", \\\"{x:1225,y:730,t:1527009017036};\\\", \\\"{x:1231,y:728,t:1527009017052};\\\", \\\"{x:1236,y:728,t:1527009017069};\\\", \\\"{x:1247,y:728,t:1527009017086};\\\", \\\"{x:1264,y:728,t:1527009017103};\\\", \\\"{x:1284,y:730,t:1527009017119};\\\", \\\"{x:1319,y:739,t:1527009017136};\\\", \\\"{x:1358,y:749,t:1527009017153};\\\", \\\"{x:1376,y:756,t:1527009017169};\\\", \\\"{x:1406,y:759,t:1527009017186};\\\", \\\"{x:1486,y:766,t:1527009017203};\\\", \\\"{x:1503,y:769,t:1527009017219};\\\", \\\"{x:1521,y:777,t:1527009017236};\\\", \\\"{x:1531,y:782,t:1527009017253};\\\", \\\"{x:1533,y:783,t:1527009017269};\\\", \\\"{x:1533,y:784,t:1527009017292};\\\", \\\"{x:1533,y:786,t:1527009017304};\\\", \\\"{x:1533,y:788,t:1527009017319};\\\", \\\"{x:1533,y:790,t:1527009017336};\\\", \\\"{x:1533,y:791,t:1527009017388};\\\", \\\"{x:1533,y:793,t:1527009017419};\\\", \\\"{x:1532,y:794,t:1527009017444};\\\", \\\"{x:1531,y:795,t:1527009017508};\\\", \\\"{x:1530,y:795,t:1527009017520};\\\", \\\"{x:1522,y:794,t:1527009017538};\\\", \\\"{x:1508,y:793,t:1527009017553};\\\", \\\"{x:1496,y:793,t:1527009017569};\\\", \\\"{x:1484,y:795,t:1527009017586};\\\", \\\"{x:1460,y:801,t:1527009017604};\\\", \\\"{x:1438,y:809,t:1527009017620};\\\", \\\"{x:1414,y:817,t:1527009017637};\\\", \\\"{x:1394,y:825,t:1527009017653};\\\", \\\"{x:1379,y:831,t:1527009017670};\\\", \\\"{x:1372,y:835,t:1527009017686};\\\", \\\"{x:1370,y:836,t:1527009017703};\\\", \\\"{x:1370,y:834,t:1527009017762};\\\", \\\"{x:1372,y:833,t:1527009017771};\\\", \\\"{x:1374,y:830,t:1527009017786};\\\", \\\"{x:1379,y:820,t:1527009017802};\\\", \\\"{x:1382,y:813,t:1527009017820};\\\", \\\"{x:1384,y:800,t:1527009017836};\\\", \\\"{x:1384,y:789,t:1527009017853};\\\", \\\"{x:1386,y:779,t:1527009017870};\\\", \\\"{x:1386,y:773,t:1527009017886};\\\", \\\"{x:1387,y:767,t:1527009017903};\\\", \\\"{x:1387,y:762,t:1527009017920};\\\", \\\"{x:1387,y:758,t:1527009017936};\\\", \\\"{x:1387,y:754,t:1527009017953};\\\", \\\"{x:1391,y:748,t:1527009017970};\\\", \\\"{x:1395,y:739,t:1527009017987};\\\", \\\"{x:1400,y:731,t:1527009018004};\\\", \\\"{x:1402,y:728,t:1527009018020};\\\", \\\"{x:1402,y:727,t:1527009018037};\\\", \\\"{x:1402,y:726,t:1527009018100};\\\", \\\"{x:1403,y:726,t:1527009018180};\\\", \\\"{x:1404,y:725,t:1527009018188};\\\", \\\"{x:1405,y:724,t:1527009018203};\\\", \\\"{x:1408,y:722,t:1527009018220};\\\", \\\"{x:1411,y:721,t:1527009018238};\\\", \\\"{x:1411,y:720,t:1527009018254};\\\", \\\"{x:1414,y:718,t:1527009018271};\\\", \\\"{x:1418,y:715,t:1527009018288};\\\", \\\"{x:1423,y:713,t:1527009018303};\\\", \\\"{x:1430,y:709,t:1527009018320};\\\", \\\"{x:1439,y:706,t:1527009018337};\\\", \\\"{x:1451,y:701,t:1527009018354};\\\", \\\"{x:1464,y:696,t:1527009018371};\\\", \\\"{x:1485,y:687,t:1527009018388};\\\", \\\"{x:1502,y:676,t:1527009018403};\\\", \\\"{x:1516,y:663,t:1527009018420};\\\", \\\"{x:1532,y:649,t:1527009018438};\\\", \\\"{x:1549,y:628,t:1527009018453};\\\", \\\"{x:1577,y:597,t:1527009018471};\\\", \\\"{x:1610,y:561,t:1527009018487};\\\", \\\"{x:1645,y:526,t:1527009018504};\\\", \\\"{x:1671,y:494,t:1527009018520};\\\", \\\"{x:1694,y:462,t:1527009018538};\\\", \\\"{x:1705,y:446,t:1527009018554};\\\", \\\"{x:1709,y:440,t:1527009018570};\\\", \\\"{x:1709,y:438,t:1527009018588};\\\", \\\"{x:1707,y:438,t:1527009018604};\\\", \\\"{x:1701,y:438,t:1527009018620};\\\", \\\"{x:1695,y:438,t:1527009018638};\\\", \\\"{x:1691,y:441,t:1527009018654};\\\", \\\"{x:1685,y:447,t:1527009018671};\\\", \\\"{x:1683,y:452,t:1527009018688};\\\", \\\"{x:1679,y:458,t:1527009018705};\\\", \\\"{x:1678,y:461,t:1527009018721};\\\", \\\"{x:1676,y:464,t:1527009018738};\\\", \\\"{x:1675,y:465,t:1527009018764};\\\", \\\"{x:1673,y:465,t:1527009018892};\\\", \\\"{x:1672,y:465,t:1527009018905};\\\", \\\"{x:1668,y:462,t:1527009018920};\\\", \\\"{x:1664,y:460,t:1527009018937};\\\", \\\"{x:1660,y:459,t:1527009018955};\\\", \\\"{x:1657,y:457,t:1527009018971};\\\", \\\"{x:1657,y:456,t:1527009019132};\\\", \\\"{x:1654,y:455,t:1527009019139};\\\", \\\"{x:1653,y:455,t:1527009019154};\\\", \\\"{x:1650,y:452,t:1527009019171};\\\", \\\"{x:1649,y:451,t:1527009019412};\\\", \\\"{x:1648,y:451,t:1527009019427};\\\", \\\"{x:1648,y:450,t:1527009019438};\\\", \\\"{x:1646,y:450,t:1527009019454};\\\", \\\"{x:1645,y:450,t:1527009019538};\\\", \\\"{x:1644,y:449,t:1527009019555};\\\", \\\"{x:1642,y:448,t:1527009019571};\\\", \\\"{x:1640,y:447,t:1527009019587};\\\", \\\"{x:1638,y:446,t:1527009019796};\\\", \\\"{x:1637,y:446,t:1527009019827};\\\", \\\"{x:1635,y:445,t:1527009019851};\\\", \\\"{x:1634,y:444,t:1527009019868};\\\", \\\"{x:1632,y:444,t:1527009019876};\\\", \\\"{x:1632,y:443,t:1527009019889};\\\", \\\"{x:1631,y:443,t:1527009019905};\\\", \\\"{x:1629,y:442,t:1527009019922};\\\", \\\"{x:1627,y:441,t:1527009019964};\\\", \\\"{x:1626,y:440,t:1527009020028};\\\", \\\"{x:1625,y:440,t:1527009020051};\\\", \\\"{x:1624,y:439,t:1527009020060};\\\", \\\"{x:1623,y:439,t:1527009020072};\\\", \\\"{x:1622,y:439,t:1527009020089};\\\", \\\"{x:1619,y:437,t:1527009020106};\\\", \\\"{x:1617,y:436,t:1527009020156};\\\", \\\"{x:1616,y:436,t:1527009020171};\\\", \\\"{x:1613,y:434,t:1527009020190};\\\", \\\"{x:1614,y:434,t:1527009021068};\\\", \\\"{x:1615,y:434,t:1527009021092};\\\", \\\"{x:1616,y:434,t:1527009021115};\\\", \\\"{x:1617,y:434,t:1527009021123};\\\", \\\"{x:1618,y:434,t:1527009021139};\\\", \\\"{x:1618,y:435,t:1527009021157};\\\", \\\"{x:1620,y:435,t:1527009021173};\\\", \\\"{x:1622,y:435,t:1527009021196};\\\", \\\"{x:1622,y:436,t:1527009021205};\\\", \\\"{x:1625,y:438,t:1527009021524};\\\", \\\"{x:1626,y:449,t:1527009021540};\\\", \\\"{x:1626,y:467,t:1527009021556};\\\", \\\"{x:1626,y:488,t:1527009021573};\\\", \\\"{x:1623,y:508,t:1527009021589};\\\", \\\"{x:1618,y:524,t:1527009021607};\\\", \\\"{x:1616,y:534,t:1527009021622};\\\", \\\"{x:1616,y:540,t:1527009021640};\\\", \\\"{x:1616,y:545,t:1527009021656};\\\", \\\"{x:1616,y:548,t:1527009021672};\\\", \\\"{x:1616,y:553,t:1527009021690};\\\", \\\"{x:1616,y:554,t:1527009021716};\\\", \\\"{x:1616,y:551,t:1527009021924};\\\", \\\"{x:1616,y:535,t:1527009021940};\\\", \\\"{x:1616,y:521,t:1527009021956};\\\", \\\"{x:1616,y:514,t:1527009021974};\\\", \\\"{x:1616,y:509,t:1527009021990};\\\", \\\"{x:1616,y:506,t:1527009022007};\\\", \\\"{x:1616,y:504,t:1527009022024};\\\", \\\"{x:1616,y:503,t:1527009022044};\\\", \\\"{x:1616,y:502,t:1527009022067};\\\", \\\"{x:1616,y:501,t:1527009022075};\\\", \\\"{x:1616,y:499,t:1527009022089};\\\", \\\"{x:1616,y:495,t:1527009022107};\\\", \\\"{x:1616,y:488,t:1527009022123};\\\", \\\"{x:1616,y:479,t:1527009022140};\\\", \\\"{x:1614,y:468,t:1527009022156};\\\", \\\"{x:1605,y:451,t:1527009022174};\\\", \\\"{x:1599,y:439,t:1527009022189};\\\", \\\"{x:1595,y:438,t:1527009022207};\\\", \\\"{x:1594,y:438,t:1527009022223};\\\", \\\"{x:1593,y:434,t:1527009022644};\\\", \\\"{x:1593,y:432,t:1527009022716};\\\", \\\"{x:1592,y:430,t:1527009022732};\\\", \\\"{x:1593,y:430,t:1527009022794};\\\", \\\"{x:1594,y:430,t:1527009022806};\\\", \\\"{x:1598,y:428,t:1527009022824};\\\", \\\"{x:1600,y:427,t:1527009022840};\\\", \\\"{x:1602,y:424,t:1527009022857};\\\", \\\"{x:1603,y:424,t:1527009022873};\\\", \\\"{x:1604,y:423,t:1527009022890};\\\", \\\"{x:1607,y:422,t:1527009022907};\\\", \\\"{x:1609,y:421,t:1527009022923};\\\", \\\"{x:1611,y:420,t:1527009022940};\\\", \\\"{x:1613,y:419,t:1527009022957};\\\", \\\"{x:1617,y:417,t:1527009022973};\\\", \\\"{x:1624,y:414,t:1527009022990};\\\", \\\"{x:1627,y:413,t:1527009023007};\\\", \\\"{x:1636,y:412,t:1527009023024};\\\", \\\"{x:1642,y:410,t:1527009023041};\\\", \\\"{x:1643,y:410,t:1527009023057};\\\", \\\"{x:1644,y:410,t:1527009024716};\\\", \\\"{x:1644,y:411,t:1527009024819};\\\", \\\"{x:1644,y:412,t:1527009025348};\\\", \\\"{x:1644,y:414,t:1527009025364};\\\", \\\"{x:1644,y:415,t:1527009025376};\\\", \\\"{x:1644,y:418,t:1527009025393};\\\", \\\"{x:1645,y:420,t:1527009025409};\\\", \\\"{x:1645,y:421,t:1527009025425};\\\", \\\"{x:1645,y:422,t:1527009025475};\\\", \\\"{x:1645,y:423,t:1527009025499};\\\", \\\"{x:1645,y:424,t:1527009026108};\\\", \\\"{x:1645,y:425,t:1527009026124};\\\", \\\"{x:1645,y:426,t:1527009026140};\\\", \\\"{x:1645,y:427,t:1527009026155};\\\", \\\"{x:1645,y:428,t:1527009026219};\\\", \\\"{x:1645,y:429,t:1527009026234};\\\", \\\"{x:1645,y:430,t:1527009026243};\\\", \\\"{x:1644,y:430,t:1527009026259};\\\", \\\"{x:1643,y:431,t:1527009026276};\\\", \\\"{x:1643,y:433,t:1527009026299};\\\", \\\"{x:1643,y:434,t:1527009026339};\\\", \\\"{x:1643,y:436,t:1527009026370};\\\", \\\"{x:1643,y:437,t:1527009026394};\\\", \\\"{x:1643,y:439,t:1527009026411};\\\", \\\"{x:1642,y:440,t:1527009026426};\\\", \\\"{x:1642,y:442,t:1527009026442};\\\", \\\"{x:1640,y:446,t:1527009026460};\\\", \\\"{x:1639,y:451,t:1527009026477};\\\", \\\"{x:1637,y:457,t:1527009026493};\\\", \\\"{x:1636,y:462,t:1527009026510};\\\", \\\"{x:1631,y:474,t:1527009026527};\\\", \\\"{x:1626,y:489,t:1527009026543};\\\", \\\"{x:1623,y:507,t:1527009026559};\\\", \\\"{x:1616,y:528,t:1527009026576};\\\", \\\"{x:1616,y:555,t:1527009026592};\\\", \\\"{x:1623,y:579,t:1527009026610};\\\", \\\"{x:1623,y:599,t:1527009026627};\\\", \\\"{x:1623,y:609,t:1527009026642};\\\", \\\"{x:1623,y:610,t:1527009026659};\\\", \\\"{x:1624,y:613,t:1527009035300};\\\", \\\"{x:1630,y:625,t:1527009035316};\\\", \\\"{x:1637,y:641,t:1527009035333};\\\", \\\"{x:1643,y:651,t:1527009035350};\\\", \\\"{x:1649,y:660,t:1527009035365};\\\", \\\"{x:1654,y:669,t:1527009035382};\\\", \\\"{x:1662,y:677,t:1527009035399};\\\", \\\"{x:1667,y:683,t:1527009035416};\\\", \\\"{x:1674,y:693,t:1527009035433};\\\", \\\"{x:1681,y:702,t:1527009035450};\\\", \\\"{x:1687,y:712,t:1527009035465};\\\", \\\"{x:1708,y:740,t:1527009035483};\\\", \\\"{x:1725,y:763,t:1527009035500};\\\", \\\"{x:1742,y:781,t:1527009035516};\\\", \\\"{x:1750,y:794,t:1527009035532};\\\", \\\"{x:1751,y:796,t:1527009035549};\\\", \\\"{x:1752,y:796,t:1527009035566};\\\", \\\"{x:1752,y:797,t:1527009035587};\\\", \\\"{x:1752,y:799,t:1527009035611};\\\", \\\"{x:1752,y:801,t:1527009035627};\\\", \\\"{x:1752,y:802,t:1527009035643};\\\", \\\"{x:1752,y:803,t:1527009035650};\\\", \\\"{x:1752,y:804,t:1527009035667};\\\", \\\"{x:1751,y:804,t:1527009035683};\\\", \\\"{x:1751,y:805,t:1527009035700};\\\", \\\"{x:1751,y:806,t:1527009035717};\\\", \\\"{x:1750,y:807,t:1527009035739};\\\", \\\"{x:1750,y:808,t:1527009035763};\\\", \\\"{x:1750,y:809,t:1527009035771};\\\", \\\"{x:1750,y:810,t:1527009035783};\\\", \\\"{x:1748,y:812,t:1527009035800};\\\", \\\"{x:1748,y:813,t:1527009035819};\\\", \\\"{x:1748,y:815,t:1527009035836};\\\", \\\"{x:1747,y:815,t:1527009035850};\\\", \\\"{x:1747,y:816,t:1527009036220};\\\", \\\"{x:1746,y:816,t:1527009036233};\\\", \\\"{x:1744,y:815,t:1527009036251};\\\", \\\"{x:1742,y:812,t:1527009036268};\\\", \\\"{x:1741,y:811,t:1527009036307};\\\", \\\"{x:1741,y:810,t:1527009036339};\\\", \\\"{x:1740,y:810,t:1527009036351};\\\", \\\"{x:1740,y:809,t:1527009036367};\\\", \\\"{x:1739,y:808,t:1527009036384};\\\", \\\"{x:1738,y:807,t:1527009036400};\\\", \\\"{x:1737,y:806,t:1527009036417};\\\", \\\"{x:1737,y:805,t:1527009036444};\\\", \\\"{x:1735,y:804,t:1527009036516};\\\", \\\"{x:1735,y:803,t:1527009036556};\\\", \\\"{x:1735,y:802,t:1527009036596};\\\", \\\"{x:1735,y:801,t:1527009036603};\\\", \\\"{x:1735,y:800,t:1527009036619};\\\", \\\"{x:1735,y:799,t:1527009036651};\\\", \\\"{x:1735,y:798,t:1527009036667};\\\", \\\"{x:1735,y:797,t:1527009036685};\\\", \\\"{x:1735,y:796,t:1527009036701};\\\", \\\"{x:1735,y:795,t:1527009036723};\\\", \\\"{x:1735,y:794,t:1527009036756};\\\", \\\"{x:1736,y:792,t:1527009036804};\\\", \\\"{x:1736,y:791,t:1527009036916};\\\", \\\"{x:1736,y:789,t:1527009036955};\\\", \\\"{x:1736,y:788,t:1527009037060};\\\", \\\"{x:1736,y:787,t:1527009037076};\\\", \\\"{x:1736,y:786,t:1527009037107};\\\", \\\"{x:1736,y:785,t:1527009039556};\\\", \\\"{x:1735,y:784,t:1527009039587};\\\", \\\"{x:1735,y:783,t:1527009040371};\\\", \\\"{x:1734,y:782,t:1527009040395};\\\", \\\"{x:1734,y:781,t:1527009040403};\\\", \\\"{x:1733,y:781,t:1527009040428};\\\", \\\"{x:1733,y:780,t:1527009040444};\\\", \\\"{x:1732,y:780,t:1527009040453};\\\", \\\"{x:1732,y:778,t:1527009040470};\\\", \\\"{x:1730,y:776,t:1527009040488};\\\", \\\"{x:1730,y:774,t:1527009040515};\\\", \\\"{x:1729,y:773,t:1527009040523};\\\", \\\"{x:1728,y:772,t:1527009040547};\\\", \\\"{x:1728,y:771,t:1527009040652};\\\", \\\"{x:1727,y:769,t:1527009040659};\\\", \\\"{x:1726,y:769,t:1527009040716};\\\", \\\"{x:1726,y:767,t:1527009040835};\\\", \\\"{x:1725,y:767,t:1527009042732};\\\", \\\"{x:1724,y:767,t:1527009042741};\\\", \\\"{x:1723,y:767,t:1527009042755};\\\", \\\"{x:1724,y:767,t:1527009042818};\\\", \\\"{x:1722,y:767,t:1527009042947};\\\", \\\"{x:1716,y:767,t:1527009042955};\\\", \\\"{x:1693,y:767,t:1527009042972};\\\", \\\"{x:1664,y:767,t:1527009042988};\\\", \\\"{x:1632,y:768,t:1527009043005};\\\", \\\"{x:1584,y:768,t:1527009043022};\\\", \\\"{x:1529,y:768,t:1527009043038};\\\", \\\"{x:1467,y:768,t:1527009043055};\\\", \\\"{x:1380,y:773,t:1527009043072};\\\", \\\"{x:1305,y:773,t:1527009043088};\\\", \\\"{x:1254,y:773,t:1527009043106};\\\", \\\"{x:1220,y:773,t:1527009043122};\\\", \\\"{x:1190,y:773,t:1527009043138};\\\", \\\"{x:1152,y:773,t:1527009043154};\\\", \\\"{x:1133,y:773,t:1527009043173};\\\", \\\"{x:1118,y:773,t:1527009043188};\\\", \\\"{x:1098,y:773,t:1527009043205};\\\", \\\"{x:1069,y:773,t:1527009043223};\\\", \\\"{x:1025,y:773,t:1527009043238};\\\", \\\"{x:970,y:766,t:1527009043255};\\\", \\\"{x:924,y:757,t:1527009043272};\\\", \\\"{x:870,y:748,t:1527009043289};\\\", \\\"{x:825,y:742,t:1527009043305};\\\", \\\"{x:775,y:734,t:1527009043322};\\\", \\\"{x:697,y:723,t:1527009043338};\\\", \\\"{x:540,y:701,t:1527009043356};\\\", \\\"{x:419,y:691,t:1527009043372};\\\", \\\"{x:284,y:676,t:1527009043389};\\\", \\\"{x:168,y:662,t:1527009043406};\\\", \\\"{x:85,y:653,t:1527009043422};\\\", \\\"{x:53,y:649,t:1527009043440};\\\", \\\"{x:33,y:649,t:1527009043457};\\\", \\\"{x:31,y:649,t:1527009043474};\\\", \\\"{x:31,y:648,t:1527009043498};\\\", \\\"{x:38,y:646,t:1527009043506};\\\", \\\"{x:56,y:638,t:1527009043525};\\\", \\\"{x:76,y:630,t:1527009043541};\\\", \\\"{x:101,y:620,t:1527009043557};\\\", \\\"{x:123,y:609,t:1527009043575};\\\", \\\"{x:137,y:605,t:1527009043590};\\\", \\\"{x:152,y:604,t:1527009043607};\\\", \\\"{x:173,y:606,t:1527009043624};\\\", \\\"{x:199,y:616,t:1527009043641};\\\", \\\"{x:219,y:624,t:1527009043658};\\\", \\\"{x:237,y:633,t:1527009043673};\\\", \\\"{x:257,y:636,t:1527009043690};\\\", \\\"{x:277,y:638,t:1527009043708};\\\", \\\"{x:278,y:638,t:1527009043723};\\\", \\\"{x:280,y:638,t:1527009043755};\\\", \\\"{x:284,y:637,t:1527009043762};\\\", \\\"{x:286,y:637,t:1527009043774};\\\", \\\"{x:293,y:633,t:1527009043791};\\\", \\\"{x:298,y:631,t:1527009043807};\\\", \\\"{x:299,y:630,t:1527009043824};\\\", \\\"{x:301,y:628,t:1527009043841};\\\", \\\"{x:303,y:626,t:1527009043857};\\\", \\\"{x:314,y:618,t:1527009043875};\\\", \\\"{x:333,y:614,t:1527009043890};\\\", \\\"{x:338,y:614,t:1527009043907};\\\", \\\"{x:340,y:614,t:1527009043924};\\\", \\\"{x:344,y:614,t:1527009043940};\\\", \\\"{x:348,y:615,t:1527009043957};\\\", \\\"{x:353,y:617,t:1527009043974};\\\", \\\"{x:362,y:618,t:1527009043991};\\\", \\\"{x:365,y:619,t:1527009044006};\\\", \\\"{x:369,y:621,t:1527009044025};\\\", \\\"{x:370,y:621,t:1527009044041};\\\", \\\"{x:372,y:622,t:1527009044057};\\\", \\\"{x:373,y:623,t:1527009044074};\\\", \\\"{x:374,y:623,t:1527009044091};\\\", \\\"{x:375,y:623,t:1527009044146};\\\", \\\"{x:375,y:624,t:1527009044157};\\\", \\\"{x:375,y:625,t:1527009044174};\\\", \\\"{x:376,y:627,t:1527009044191};\\\", \\\"{x:376,y:628,t:1527009044330};\\\", \\\"{x:376,y:630,t:1527009044346};\\\", \\\"{x:378,y:632,t:1527009044357};\\\", \\\"{x:381,y:634,t:1527009044374};\\\", \\\"{x:393,y:642,t:1527009044391};\\\", \\\"{x:414,y:660,t:1527009044409};\\\", \\\"{x:433,y:676,t:1527009044424};\\\", \\\"{x:455,y:692,t:1527009044441};\\\", \\\"{x:477,y:709,t:1527009044458};\\\", \\\"{x:492,y:720,t:1527009044474};\\\", \\\"{x:499,y:725,t:1527009044491};\\\", \\\"{x:502,y:727,t:1527009044508};\\\", \\\"{x:503,y:727,t:1527009044554};\\\", \\\"{x:504,y:727,t:1527009044578};\\\", \\\"{x:505,y:728,t:1527009044603};\\\", \\\"{x:506,y:728,t:1527009044874};\\\", \\\"{x:508,y:727,t:1527009044906};\\\", \\\"{x:510,y:726,t:1527009045067};\\\", \\\"{x:511,y:726,t:1527009045075};\\\", \\\"{x:522,y:724,t:1527009045091};\\\", \\\"{x:541,y:724,t:1527009045108};\\\", \\\"{x:564,y:726,t:1527009045125};\\\", \\\"{x:594,y:730,t:1527009045141};\\\", \\\"{x:633,y:736,t:1527009045158};\\\", \\\"{x:664,y:740,t:1527009045176};\\\", \\\"{x:690,y:743,t:1527009045192};\\\", \\\"{x:710,y:744,t:1527009045208};\\\", \\\"{x:724,y:745,t:1527009045225};\\\", \\\"{x:728,y:745,t:1527009045241};\\\", \\\"{x:729,y:745,t:1527009045258};\\\", \\\"{x:730,y:746,t:1527009045299};\\\", \\\"{x:730,y:748,t:1527009045308};\\\", \\\"{x:730,y:749,t:1527009045325};\\\", \\\"{x:729,y:750,t:1527009045491};\\\", \\\"{x:728,y:750,t:1527009045547};\\\", \\\"{x:726,y:749,t:1527009045866};\\\" ] }, { \\\"rt\\\": 10152, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 7, \\\"time_elapsed\\\": 221008, \\\"internal_node_id\\\": \\\"0.0-5.0-2.0\\\", \\\"subject\\\": \\\"R06S6\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"echo\\\", \\\"condition\\\": \\\"121\\\", \\\"scenario\\\": \\\"acme\\\", \\\"question\\\": \\\"meets\\\", \\\"q\\\": 3, \\\"clicks\\\": 1.5, \\\"explicit\\\": 1, \\\"impasse\\\": 2, \\\"axis\\\": \\\"Orthogonal-XInside-YFull\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 0, \\\"answer\\\": [ \\\"B\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"U \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-C -3\\\", \\\"block\\\": \\\"triangular_scaffolded\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:725,y:749,t:1527009046009};\\\", \\\"{x:724,y:751,t:1527009049619};\\\", \\\"{x:723,y:751,t:1527009049635};\\\", \\\"{x:722,y:751,t:1527009049645};\\\", \\\"{x:757,y:754,t:1527009049661};\\\", \\\"{x:835,y:763,t:1527009049678};\\\", \\\"{x:894,y:773,t:1527009049696};\\\", \\\"{x:937,y:780,t:1527009049711};\\\", \\\"{x:976,y:785,t:1527009049728};\\\", \\\"{x:1006,y:787,t:1527009049745};\\\", \\\"{x:1025,y:788,t:1527009049761};\\\", \\\"{x:1045,y:789,t:1527009049779};\\\", \\\"{x:1053,y:789,t:1527009049794};\\\", \\\"{x:1059,y:789,t:1527009049812};\\\", \\\"{x:1064,y:789,t:1527009049828};\\\", \\\"{x:1073,y:787,t:1527009049846};\\\", \\\"{x:1084,y:784,t:1527009049862};\\\", \\\"{x:1102,y:779,t:1527009049878};\\\", \\\"{x:1125,y:773,t:1527009049895};\\\", \\\"{x:1151,y:769,t:1527009049911};\\\", \\\"{x:1172,y:764,t:1527009049928};\\\", \\\"{x:1199,y:760,t:1527009049946};\\\", \\\"{x:1222,y:756,t:1527009049962};\\\", \\\"{x:1259,y:751,t:1527009049978};\\\", \\\"{x:1281,y:747,t:1527009049995};\\\", \\\"{x:1300,y:743,t:1527009050011};\\\", \\\"{x:1314,y:740,t:1527009050028};\\\", \\\"{x:1326,y:736,t:1527009050045};\\\", \\\"{x:1339,y:732,t:1527009050061};\\\", \\\"{x:1350,y:728,t:1527009050079};\\\", \\\"{x:1358,y:726,t:1527009050095};\\\", \\\"{x:1367,y:723,t:1527009050112};\\\", \\\"{x:1370,y:723,t:1527009050129};\\\", \\\"{x:1371,y:722,t:1527009050146};\\\", \\\"{x:1373,y:721,t:1527009050162};\\\", \\\"{x:1376,y:720,t:1527009050179};\\\", \\\"{x:1378,y:718,t:1527009050195};\\\", \\\"{x:1383,y:718,t:1527009050213};\\\", \\\"{x:1387,y:716,t:1527009050228};\\\", \\\"{x:1389,y:715,t:1527009050245};\\\", \\\"{x:1391,y:715,t:1527009050263};\\\", \\\"{x:1394,y:715,t:1527009050279};\\\", \\\"{x:1397,y:715,t:1527009050296};\\\", \\\"{x:1400,y:715,t:1527009050312};\\\", \\\"{x:1402,y:715,t:1527009050329};\\\", \\\"{x:1406,y:715,t:1527009050345};\\\", \\\"{x:1408,y:715,t:1527009050362};\\\", \\\"{x:1409,y:715,t:1527009050378};\\\", \\\"{x:1410,y:715,t:1527009050580};\\\", \\\"{x:1417,y:717,t:1527009050596};\\\", \\\"{x:1434,y:724,t:1527009050612};\\\", \\\"{x:1458,y:733,t:1527009050630};\\\", \\\"{x:1490,y:746,t:1527009050646};\\\", \\\"{x:1515,y:757,t:1527009050662};\\\", \\\"{x:1539,y:768,t:1527009050680};\\\", \\\"{x:1555,y:776,t:1527009050696};\\\", \\\"{x:1567,y:780,t:1527009050713};\\\", \\\"{x:1568,y:784,t:1527009050729};\\\", \\\"{x:1568,y:785,t:1527009050805};\\\", \\\"{x:1568,y:786,t:1527009050813};\\\", \\\"{x:1568,y:788,t:1527009050830};\\\", \\\"{x:1568,y:789,t:1527009050846};\\\", \\\"{x:1566,y:791,t:1527009050863};\\\", \\\"{x:1562,y:794,t:1527009050880};\\\", \\\"{x:1556,y:797,t:1527009050895};\\\", \\\"{x:1543,y:803,t:1527009050913};\\\", \\\"{x:1531,y:808,t:1527009050930};\\\", \\\"{x:1514,y:813,t:1527009050946};\\\", \\\"{x:1478,y:817,t:1527009050963};\\\", \\\"{x:1455,y:817,t:1527009050980};\\\", \\\"{x:1431,y:817,t:1527009050996};\\\", \\\"{x:1401,y:817,t:1527009051013};\\\", \\\"{x:1368,y:817,t:1527009051030};\\\", \\\"{x:1341,y:817,t:1527009051047};\\\", \\\"{x:1319,y:817,t:1527009051063};\\\", \\\"{x:1296,y:820,t:1527009051080};\\\", \\\"{x:1271,y:823,t:1527009051097};\\\", \\\"{x:1247,y:826,t:1527009051112};\\\", \\\"{x:1231,y:830,t:1527009051130};\\\", \\\"{x:1215,y:831,t:1527009051150};\\\", \\\"{x:1212,y:831,t:1527009051163};\\\", \\\"{x:1210,y:832,t:1527009051180};\\\", \\\"{x:1210,y:831,t:1527009053154};\\\", \\\"{x:1210,y:830,t:1527009053177};\\\", \\\"{x:1210,y:829,t:1527009053186};\\\", \\\"{x:1209,y:829,t:1527009053197};\\\", \\\"{x:1209,y:828,t:1527009053214};\\\", \\\"{x:1208,y:827,t:1527009053230};\\\", \\\"{x:1207,y:826,t:1527009053247};\\\", \\\"{x:1206,y:826,t:1527009053264};\\\", \\\"{x:1205,y:825,t:1527009053281};\\\", \\\"{x:1204,y:824,t:1527009053306};\\\", \\\"{x:1202,y:823,t:1527009053313};\\\", \\\"{x:1200,y:820,t:1527009053331};\\\", \\\"{x:1193,y:816,t:1527009053347};\\\", \\\"{x:1180,y:808,t:1527009053364};\\\", \\\"{x:1166,y:801,t:1527009053381};\\\", \\\"{x:1148,y:794,t:1527009053397};\\\", \\\"{x:1131,y:786,t:1527009053414};\\\", \\\"{x:1113,y:779,t:1527009053431};\\\", \\\"{x:1099,y:772,t:1527009053447};\\\", \\\"{x:1089,y:768,t:1527009053464};\\\", \\\"{x:1082,y:765,t:1527009053481};\\\", \\\"{x:1079,y:763,t:1527009053497};\\\", \\\"{x:1075,y:761,t:1527009053513};\\\", \\\"{x:1068,y:761,t:1527009053531};\\\", \\\"{x:1056,y:759,t:1527009053547};\\\", \\\"{x:1033,y:754,t:1527009053565};\\\", \\\"{x:1007,y:749,t:1527009053581};\\\", \\\"{x:966,y:742,t:1527009053598};\\\", \\\"{x:907,y:734,t:1527009053614};\\\", \\\"{x:850,y:721,t:1527009053631};\\\", \\\"{x:774,y:707,t:1527009053647};\\\", \\\"{x:691,y:688,t:1527009053664};\\\", \\\"{x:622,y:666,t:1527009053681};\\\", \\\"{x:566,y:650,t:1527009053697};\\\", \\\"{x:465,y:620,t:1527009053715};\\\", \\\"{x:413,y:607,t:1527009053732};\\\", \\\"{x:360,y:591,t:1527009053749};\\\", \\\"{x:327,y:584,t:1527009053765};\\\", \\\"{x:293,y:575,t:1527009053782};\\\", \\\"{x:267,y:569,t:1527009053799};\\\", \\\"{x:246,y:563,t:1527009053815};\\\", \\\"{x:228,y:559,t:1527009053831};\\\", \\\"{x:215,y:555,t:1527009053848};\\\", \\\"{x:207,y:553,t:1527009053865};\\\", \\\"{x:200,y:551,t:1527009053881};\\\", \\\"{x:180,y:547,t:1527009053897};\\\", \\\"{x:165,y:545,t:1527009053915};\\\", \\\"{x:160,y:544,t:1527009053931};\\\", \\\"{x:159,y:544,t:1527009054002};\\\", \\\"{x:157,y:544,t:1527009054015};\\\", \\\"{x:156,y:546,t:1527009054031};\\\", \\\"{x:156,y:553,t:1527009054048};\\\", \\\"{x:156,y:563,t:1527009054065};\\\", \\\"{x:159,y:571,t:1527009054081};\\\", \\\"{x:171,y:579,t:1527009054098};\\\", \\\"{x:181,y:581,t:1527009054115};\\\", \\\"{x:195,y:582,t:1527009054131};\\\", \\\"{x:217,y:584,t:1527009054148};\\\", \\\"{x:245,y:585,t:1527009054165};\\\", \\\"{x:272,y:586,t:1527009054181};\\\", \\\"{x:299,y:590,t:1527009054199};\\\", \\\"{x:324,y:592,t:1527009054215};\\\", \\\"{x:345,y:596,t:1527009054232};\\\", \\\"{x:367,y:599,t:1527009054248};\\\", \\\"{x:390,y:603,t:1527009054266};\\\", \\\"{x:427,y:610,t:1527009054282};\\\", \\\"{x:457,y:614,t:1527009054298};\\\", \\\"{x:489,y:618,t:1527009054315};\\\", \\\"{x:517,y:621,t:1527009054333};\\\", \\\"{x:541,y:625,t:1527009054348};\\\", \\\"{x:561,y:627,t:1527009054365};\\\", \\\"{x:579,y:631,t:1527009054382};\\\", \\\"{x:597,y:633,t:1527009054398};\\\", \\\"{x:610,y:635,t:1527009054415};\\\", \\\"{x:620,y:636,t:1527009054433};\\\", \\\"{x:627,y:637,t:1527009054449};\\\", \\\"{x:637,y:637,t:1527009054465};\\\", \\\"{x:661,y:637,t:1527009054482};\\\", \\\"{x:675,y:637,t:1527009054499};\\\", \\\"{x:678,y:637,t:1527009054515};\\\", \\\"{x:677,y:637,t:1527009054546};\\\", \\\"{x:675,y:637,t:1527009054554};\\\", \\\"{x:671,y:637,t:1527009054565};\\\", \\\"{x:669,y:637,t:1527009054582};\\\", \\\"{x:668,y:637,t:1527009054627};\\\", \\\"{x:666,y:637,t:1527009054635};\\\", \\\"{x:665,y:637,t:1527009054649};\\\", \\\"{x:661,y:637,t:1527009054666};\\\", \\\"{x:653,y:637,t:1527009054683};\\\", \\\"{x:648,y:637,t:1527009054699};\\\", \\\"{x:644,y:637,t:1527009054716};\\\", \\\"{x:643,y:637,t:1527009054733};\\\", \\\"{x:639,y:637,t:1527009054751};\\\", \\\"{x:633,y:637,t:1527009054766};\\\", \\\"{x:619,y:637,t:1527009054782};\\\", \\\"{x:608,y:636,t:1527009054800};\\\", \\\"{x:597,y:634,t:1527009054816};\\\", \\\"{x:591,y:633,t:1527009054832};\\\", \\\"{x:593,y:633,t:1527009055139};\\\", \\\"{x:594,y:632,t:1527009055150};\\\", \\\"{x:596,y:632,t:1527009055167};\\\", \\\"{x:598,y:632,t:1527009055183};\\\", \\\"{x:599,y:632,t:1527009055199};\\\", \\\"{x:600,y:632,t:1527009055218};\\\", \\\"{x:601,y:632,t:1527009055233};\\\", \\\"{x:602,y:632,t:1527009055266};\\\", \\\"{x:603,y:632,t:1527009055282};\\\", \\\"{x:604,y:632,t:1527009055299};\\\", \\\"{x:605,y:632,t:1527009055322};\\\", \\\"{x:607,y:632,t:1527009055387};\\\", \\\"{x:609,y:632,t:1527009055426};\\\", \\\"{x:609,y:632,t:1527009055499};\\\", \\\"{x:609,y:633,t:1527009055594};\\\", \\\"{x:609,y:635,t:1527009055602};\\\", \\\"{x:607,y:641,t:1527009055617};\\\", \\\"{x:600,y:647,t:1527009055633};\\\", \\\"{x:598,y:649,t:1527009055649};\\\", \\\"{x:592,y:654,t:1527009055667};\\\", \\\"{x:589,y:658,t:1527009055683};\\\", \\\"{x:588,y:661,t:1527009055700};\\\", \\\"{x:585,y:665,t:1527009055717};\\\", \\\"{x:583,y:667,t:1527009055732};\\\", \\\"{x:578,y:671,t:1527009055749};\\\", \\\"{x:570,y:674,t:1527009055766};\\\", \\\"{x:559,y:680,t:1527009055782};\\\", \\\"{x:546,y:687,t:1527009055799};\\\", \\\"{x:534,y:696,t:1527009055816};\\\", \\\"{x:520,y:702,t:1527009055833};\\\", \\\"{x:510,y:706,t:1527009055849};\\\", \\\"{x:500,y:709,t:1527009055866};\\\", \\\"{x:497,y:711,t:1527009055883};\\\", \\\"{x:496,y:712,t:1527009055900};\\\", \\\"{x:494,y:713,t:1527009055916};\\\", \\\"{x:494,y:714,t:1527009055938};\\\", \\\"{x:493,y:715,t:1527009055970};\\\", \\\"{x:493,y:716,t:1527009055995};\\\", \\\"{x:493,y:715,t:1527009056899};\\\", \\\"{x:493,y:714,t:1527009057067};\\\", \\\"{x:494,y:713,t:1527009057107};\\\", \\\"{x:494,y:712,t:1527009057209};\\\" ] }, { \\\"rt\\\": 62869, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 8, \\\"time_elapsed\\\": 285080, \\\"internal_node_id\\\": \\\"0.0-5.0-3.0\\\", \\\"subject\\\": \\\"R06S6\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"echo\\\", \\\"condition\\\": \\\"121\\\", \\\"scenario\\\": \\\"acme\\\", \\\"question\\\": \\\"endtime\\\", \\\"q\\\": 4, \\\"clicks\\\": 2, \\\"explicit\\\": 1, \\\"impasse\\\": 2, \\\"axis\\\": \\\"Orthogonal-XInside-YFull\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 0, \\\"answer\\\": [ \\\"O\\\", \\\"F\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"U \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-04 PM-04 PM-04 PM-C -Z -U -01 PM-12 PM-02 PM-03 PM-02 PM-12 PM-F -F -C \\\", \\\"block\\\": \\\"triangular_scaffolded\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:494,y:711,t:1527009057354};\\\", \\\"{x:495,y:711,t:1527009057369};\\\", \\\"{x:495,y:710,t:1527009057439};\\\", \\\"{x:495,y:709,t:1527009057594};\\\", \\\"{x:495,y:708,t:1527009057658};\\\", \\\"{x:496,y:708,t:1527009057675};\\\", \\\"{x:496,y:707,t:1527009057739};\\\", \\\"{x:497,y:706,t:1527009058187};\\\", \\\"{x:508,y:703,t:1527009058204};\\\", \\\"{x:522,y:701,t:1527009058220};\\\", \\\"{x:541,y:700,t:1527009058239};\\\", \\\"{x:570,y:700,t:1527009058254};\\\", \\\"{x:623,y:700,t:1527009058269};\\\", \\\"{x:703,y:708,t:1527009058285};\\\", \\\"{x:792,y:721,t:1527009058301};\\\", \\\"{x:895,y:737,t:1527009058318};\\\", \\\"{x:990,y:753,t:1527009058336};\\\", \\\"{x:1067,y:769,t:1527009058352};\\\", \\\"{x:1123,y:779,t:1527009058369};\\\", \\\"{x:1162,y:784,t:1527009058386};\\\", \\\"{x:1180,y:786,t:1527009058401};\\\", \\\"{x:1190,y:787,t:1527009058418};\\\", \\\"{x:1192,y:788,t:1527009058435};\\\", \\\"{x:1193,y:788,t:1527009058452};\\\", \\\"{x:1194,y:788,t:1527009058469};\\\", \\\"{x:1196,y:788,t:1527009058486};\\\", \\\"{x:1199,y:788,t:1527009058501};\\\", \\\"{x:1201,y:788,t:1527009058519};\\\", \\\"{x:1204,y:788,t:1527009058535};\\\", \\\"{x:1206,y:788,t:1527009058551};\\\", \\\"{x:1209,y:788,t:1527009058568};\\\", \\\"{x:1211,y:788,t:1527009058586};\\\", \\\"{x:1217,y:790,t:1527009058603};\\\", \\\"{x:1222,y:792,t:1527009058619};\\\", \\\"{x:1228,y:794,t:1527009058636};\\\", \\\"{x:1234,y:796,t:1527009058653};\\\", \\\"{x:1237,y:797,t:1527009058670};\\\", \\\"{x:1240,y:797,t:1527009058686};\\\", \\\"{x:1241,y:798,t:1527009058703};\\\", \\\"{x:1242,y:798,t:1527009060635};\\\", \\\"{x:1245,y:800,t:1527009060642};\\\", \\\"{x:1248,y:802,t:1527009060654};\\\", \\\"{x:1266,y:811,t:1527009060671};\\\", \\\"{x:1298,y:825,t:1527009060687};\\\", \\\"{x:1332,y:836,t:1527009060704};\\\", \\\"{x:1372,y:850,t:1527009060721};\\\", \\\"{x:1417,y:862,t:1527009060737};\\\", \\\"{x:1459,y:874,t:1527009060755};\\\", \\\"{x:1497,y:884,t:1527009060770};\\\", \\\"{x:1512,y:889,t:1527009060786};\\\", \\\"{x:1522,y:890,t:1527009060804};\\\", \\\"{x:1529,y:891,t:1527009060820};\\\", \\\"{x:1532,y:892,t:1527009060836};\\\", \\\"{x:1534,y:894,t:1527009060853};\\\", \\\"{x:1536,y:894,t:1527009060870};\\\", \\\"{x:1536,y:895,t:1527009060887};\\\", \\\"{x:1537,y:895,t:1527009060903};\\\", \\\"{x:1538,y:895,t:1527009060920};\\\", \\\"{x:1539,y:896,t:1527009060937};\\\", \\\"{x:1539,y:897,t:1527009060953};\\\", \\\"{x:1540,y:897,t:1527009061034};\\\", \\\"{x:1541,y:897,t:1527009061050};\\\", \\\"{x:1542,y:897,t:1527009061098};\\\", \\\"{x:1544,y:897,t:1527009061130};\\\", \\\"{x:1545,y:897,t:1527009061146};\\\", \\\"{x:1547,y:897,t:1527009061154};\\\", \\\"{x:1552,y:897,t:1527009061170};\\\", \\\"{x:1571,y:897,t:1527009061188};\\\", \\\"{x:1596,y:903,t:1527009061203};\\\", \\\"{x:1623,y:906,t:1527009061221};\\\", \\\"{x:1648,y:912,t:1527009061238};\\\", \\\"{x:1667,y:917,t:1527009061254};\\\", \\\"{x:1673,y:917,t:1527009061271};\\\", \\\"{x:1674,y:918,t:1527009061288};\\\", \\\"{x:1674,y:919,t:1527009061363};\\\", \\\"{x:1672,y:919,t:1527009061403};\\\", \\\"{x:1670,y:919,t:1527009061418};\\\", \\\"{x:1669,y:920,t:1527009061427};\\\", \\\"{x:1667,y:920,t:1527009061438};\\\", \\\"{x:1661,y:923,t:1527009061455};\\\", \\\"{x:1657,y:924,t:1527009061471};\\\", \\\"{x:1651,y:927,t:1527009061489};\\\", \\\"{x:1647,y:930,t:1527009061506};\\\", \\\"{x:1643,y:932,t:1527009061521};\\\", \\\"{x:1638,y:936,t:1527009061538};\\\", \\\"{x:1634,y:939,t:1527009061554};\\\", \\\"{x:1628,y:943,t:1527009061571};\\\", \\\"{x:1619,y:946,t:1527009061589};\\\", \\\"{x:1610,y:950,t:1527009061605};\\\", \\\"{x:1603,y:952,t:1527009061622};\\\", \\\"{x:1594,y:954,t:1527009061638};\\\", \\\"{x:1590,y:956,t:1527009061655};\\\", \\\"{x:1590,y:957,t:1527009061740};\\\", \\\"{x:1590,y:959,t:1527009061755};\\\", \\\"{x:1590,y:962,t:1527009061771};\\\", \\\"{x:1592,y:965,t:1527009061788};\\\", \\\"{x:1596,y:969,t:1527009061805};\\\", \\\"{x:1597,y:971,t:1527009061821};\\\", \\\"{x:1599,y:973,t:1527009061838};\\\", \\\"{x:1600,y:975,t:1527009061855};\\\", \\\"{x:1602,y:977,t:1527009061872};\\\", \\\"{x:1604,y:980,t:1527009061888};\\\", \\\"{x:1605,y:981,t:1527009061905};\\\", \\\"{x:1606,y:982,t:1527009061939};\\\", \\\"{x:1608,y:983,t:1527009062355};\\\", \\\"{x:1609,y:983,t:1527009062372};\\\", \\\"{x:1609,y:985,t:1527009062388};\\\", \\\"{x:1609,y:986,t:1527009062409};\\\", \\\"{x:1609,y:988,t:1527009062421};\\\", \\\"{x:1613,y:992,t:1527009062439};\\\", \\\"{x:1615,y:994,t:1527009062455};\\\", \\\"{x:1616,y:994,t:1527009062472};\\\", \\\"{x:1616,y:995,t:1527009062586};\\\", \\\"{x:1617,y:995,t:1527009062699};\\\", \\\"{x:1618,y:995,t:1527009062715};\\\", \\\"{x:1619,y:994,t:1527009063019};\\\", \\\"{x:1619,y:993,t:1527009063043};\\\", \\\"{x:1620,y:992,t:1527009063083};\\\", \\\"{x:1621,y:989,t:1527009063107};\\\", \\\"{x:1621,y:988,t:1527009063164};\\\", \\\"{x:1622,y:988,t:1527009063187};\\\", \\\"{x:1622,y:987,t:1527009063195};\\\", \\\"{x:1622,y:986,t:1527009063243};\\\", \\\"{x:1622,y:985,t:1527009063316};\\\", \\\"{x:1622,y:984,t:1527009063396};\\\", \\\"{x:1622,y:983,t:1527009063418};\\\", \\\"{x:1622,y:982,t:1527009063499};\\\", \\\"{x:1622,y:981,t:1527009063515};\\\", \\\"{x:1622,y:980,t:1527009063587};\\\", \\\"{x:1622,y:979,t:1527009063787};\\\", \\\"{x:1623,y:979,t:1527009063859};\\\", \\\"{x:1624,y:979,t:1527009063873};\\\", \\\"{x:1626,y:978,t:1527009063890};\\\", \\\"{x:1627,y:976,t:1527009063907};\\\", \\\"{x:1628,y:976,t:1527009063924};\\\", \\\"{x:1629,y:976,t:1527009063941};\\\", \\\"{x:1630,y:976,t:1527009063956};\\\", \\\"{x:1631,y:976,t:1527009063974};\\\", \\\"{x:1632,y:976,t:1527009063990};\\\", \\\"{x:1635,y:974,t:1527009064007};\\\", \\\"{x:1635,y:972,t:1527009064023};\\\", \\\"{x:1639,y:969,t:1527009064041};\\\", \\\"{x:1642,y:968,t:1527009064057};\\\", \\\"{x:1646,y:968,t:1527009064073};\\\", \\\"{x:1647,y:968,t:1527009064090};\\\", \\\"{x:1649,y:968,t:1527009064106};\\\", \\\"{x:1650,y:967,t:1527009064147};\\\", \\\"{x:1649,y:967,t:1527009064284};\\\", \\\"{x:1648,y:967,t:1527009064290};\\\", \\\"{x:1646,y:967,t:1527009064307};\\\", \\\"{x:1644,y:967,t:1527009064323};\\\", \\\"{x:1643,y:967,t:1527009064340};\\\", \\\"{x:1641,y:968,t:1527009064357};\\\", \\\"{x:1639,y:968,t:1527009064373};\\\", \\\"{x:1638,y:969,t:1527009064391};\\\", \\\"{x:1637,y:970,t:1527009064408};\\\", \\\"{x:1635,y:971,t:1527009064424};\\\", \\\"{x:1632,y:972,t:1527009064440};\\\", \\\"{x:1631,y:974,t:1527009064459};\\\", \\\"{x:1629,y:974,t:1527009064473};\\\", \\\"{x:1628,y:974,t:1527009064491};\\\", \\\"{x:1626,y:975,t:1527009064506};\\\", \\\"{x:1625,y:975,t:1527009064531};\\\", \\\"{x:1624,y:975,t:1527009064540};\\\", \\\"{x:1622,y:976,t:1527009064558};\\\", \\\"{x:1620,y:976,t:1527009064573};\\\", \\\"{x:1618,y:976,t:1527009064591};\\\", \\\"{x:1616,y:976,t:1527009064607};\\\", \\\"{x:1615,y:976,t:1527009064659};\\\", \\\"{x:1614,y:976,t:1527009064747};\\\", \\\"{x:1613,y:975,t:1527009064758};\\\", \\\"{x:1610,y:969,t:1527009064774};\\\", \\\"{x:1605,y:963,t:1527009064791};\\\", \\\"{x:1604,y:961,t:1527009064807};\\\", \\\"{x:1603,y:961,t:1527009064824};\\\", \\\"{x:1602,y:960,t:1527009065067};\\\", \\\"{x:1601,y:960,t:1527009065083};\\\", \\\"{x:1600,y:958,t:1527009065098};\\\", \\\"{x:1597,y:955,t:1527009065107};\\\", \\\"{x:1582,y:941,t:1527009065125};\\\", \\\"{x:1565,y:929,t:1527009065140};\\\", \\\"{x:1530,y:909,t:1527009065158};\\\", \\\"{x:1485,y:888,t:1527009065174};\\\", \\\"{x:1436,y:867,t:1527009065190};\\\", \\\"{x:1380,y:844,t:1527009065207};\\\", \\\"{x:1331,y:823,t:1527009065224};\\\", \\\"{x:1306,y:814,t:1527009065241};\\\", \\\"{x:1289,y:808,t:1527009065257};\\\", \\\"{x:1283,y:806,t:1527009065273};\\\", \\\"{x:1284,y:806,t:1527009065363};\\\", \\\"{x:1286,y:806,t:1527009065374};\\\", \\\"{x:1289,y:806,t:1527009065391};\\\", \\\"{x:1291,y:807,t:1527009065407};\\\", \\\"{x:1293,y:808,t:1527009065424};\\\", \\\"{x:1297,y:810,t:1527009065441};\\\", \\\"{x:1304,y:812,t:1527009065457};\\\", \\\"{x:1313,y:816,t:1527009065474};\\\", \\\"{x:1317,y:818,t:1527009065490};\\\", \\\"{x:1323,y:822,t:1527009065508};\\\", \\\"{x:1333,y:827,t:1527009065524};\\\", \\\"{x:1339,y:832,t:1527009065541};\\\", \\\"{x:1348,y:837,t:1527009065557};\\\", \\\"{x:1353,y:841,t:1527009065574};\\\", \\\"{x:1356,y:843,t:1527009065592};\\\", \\\"{x:1358,y:844,t:1527009065607};\\\", \\\"{x:1359,y:844,t:1527009065995};\\\", \\\"{x:1360,y:844,t:1527009066035};\\\", \\\"{x:1358,y:844,t:1527009066308};\\\", \\\"{x:1351,y:844,t:1527009066326};\\\", \\\"{x:1339,y:845,t:1527009066341};\\\", \\\"{x:1327,y:845,t:1527009066359};\\\", \\\"{x:1312,y:845,t:1527009066375};\\\", \\\"{x:1299,y:845,t:1527009066392};\\\", \\\"{x:1286,y:842,t:1527009066408};\\\", \\\"{x:1272,y:840,t:1527009066426};\\\", \\\"{x:1263,y:838,t:1527009066441};\\\", \\\"{x:1253,y:836,t:1527009066458};\\\", \\\"{x:1241,y:832,t:1527009066475};\\\", \\\"{x:1229,y:828,t:1527009066491};\\\", \\\"{x:1215,y:823,t:1527009066509};\\\", \\\"{x:1204,y:822,t:1527009066526};\\\", \\\"{x:1198,y:821,t:1527009066542};\\\", \\\"{x:1194,y:821,t:1527009066559};\\\", \\\"{x:1188,y:819,t:1527009066576};\\\", \\\"{x:1186,y:819,t:1527009066592};\\\", \\\"{x:1185,y:819,t:1527009066618};\\\", \\\"{x:1184,y:819,t:1527009066626};\\\", \\\"{x:1183,y:819,t:1527009066641};\\\", \\\"{x:1180,y:822,t:1527009066659};\\\", \\\"{x:1177,y:824,t:1527009066675};\\\", \\\"{x:1174,y:827,t:1527009066691};\\\", \\\"{x:1171,y:829,t:1527009066708};\\\", \\\"{x:1168,y:832,t:1527009066725};\\\", \\\"{x:1166,y:833,t:1527009066743};\\\", \\\"{x:1166,y:834,t:1527009066758};\\\", \\\"{x:1165,y:834,t:1527009066787};\\\", \\\"{x:1165,y:835,t:1527009066907};\\\", \\\"{x:1165,y:832,t:1527009066939};\\\", \\\"{x:1163,y:829,t:1527009066947};\\\", \\\"{x:1162,y:828,t:1527009066958};\\\", \\\"{x:1159,y:821,t:1527009066975};\\\", \\\"{x:1153,y:816,t:1527009066992};\\\", \\\"{x:1149,y:814,t:1527009067008};\\\", \\\"{x:1147,y:812,t:1527009067024};\\\", \\\"{x:1147,y:811,t:1527009067041};\\\", \\\"{x:1146,y:811,t:1527009067066};\\\", \\\"{x:1146,y:810,t:1527009067155};\\\", \\\"{x:1146,y:809,t:1527009067170};\\\", \\\"{x:1144,y:808,t:1527009067193};\\\", \\\"{x:1143,y:808,t:1527009067241};\\\", \\\"{x:1142,y:806,t:1527009067258};\\\", \\\"{x:1140,y:806,t:1527009067275};\\\", \\\"{x:1140,y:807,t:1527009067619};\\\", \\\"{x:1141,y:808,t:1527009067626};\\\", \\\"{x:1142,y:813,t:1527009067643};\\\", \\\"{x:1146,y:817,t:1527009067659};\\\", \\\"{x:1153,y:823,t:1527009067676};\\\", \\\"{x:1163,y:830,t:1527009067693};\\\", \\\"{x:1178,y:836,t:1527009067710};\\\", \\\"{x:1195,y:841,t:1527009067727};\\\", \\\"{x:1213,y:847,t:1527009067742};\\\", \\\"{x:1238,y:851,t:1527009067759};\\\", \\\"{x:1260,y:857,t:1527009067777};\\\", \\\"{x:1283,y:860,t:1527009067792};\\\", \\\"{x:1302,y:863,t:1527009067810};\\\", \\\"{x:1328,y:866,t:1527009067827};\\\", \\\"{x:1339,y:868,t:1527009067843};\\\", \\\"{x:1346,y:869,t:1527009067859};\\\", \\\"{x:1352,y:871,t:1527009067876};\\\", \\\"{x:1353,y:871,t:1527009067893};\\\", \\\"{x:1356,y:872,t:1527009067910};\\\", \\\"{x:1358,y:872,t:1527009067927};\\\", \\\"{x:1359,y:873,t:1527009067942};\\\", \\\"{x:1362,y:875,t:1527009067960};\\\", \\\"{x:1365,y:876,t:1527009067976};\\\", \\\"{x:1373,y:879,t:1527009067992};\\\", \\\"{x:1383,y:883,t:1527009068009};\\\", \\\"{x:1402,y:890,t:1527009068027};\\\", \\\"{x:1415,y:894,t:1527009068045};\\\", \\\"{x:1429,y:896,t:1527009068059};\\\", \\\"{x:1447,y:902,t:1527009068076};\\\", \\\"{x:1460,y:904,t:1527009068093};\\\", \\\"{x:1471,y:905,t:1527009068109};\\\", \\\"{x:1479,y:905,t:1527009068126};\\\", \\\"{x:1486,y:905,t:1527009068143};\\\", \\\"{x:1487,y:905,t:1527009068260};\\\", \\\"{x:1488,y:905,t:1527009068315};\\\", \\\"{x:1489,y:905,t:1527009068327};\\\", \\\"{x:1490,y:905,t:1527009068451};\\\", \\\"{x:1491,y:905,t:1527009068483};\\\", \\\"{x:1492,y:905,t:1527009068493};\\\", \\\"{x:1493,y:904,t:1527009068510};\\\", \\\"{x:1494,y:904,t:1527009068588};\\\", \\\"{x:1495,y:904,t:1527009068611};\\\", \\\"{x:1499,y:904,t:1527009068627};\\\", \\\"{x:1503,y:905,t:1527009068643};\\\", \\\"{x:1511,y:907,t:1527009068660};\\\", \\\"{x:1518,y:908,t:1527009068677};\\\", \\\"{x:1526,y:909,t:1527009068693};\\\", \\\"{x:1530,y:910,t:1527009068710};\\\", \\\"{x:1532,y:911,t:1527009068727};\\\", \\\"{x:1532,y:913,t:1527009068979};\\\", \\\"{x:1531,y:917,t:1527009068994};\\\", \\\"{x:1524,y:924,t:1527009069011};\\\", \\\"{x:1521,y:928,t:1527009069027};\\\", \\\"{x:1519,y:929,t:1527009069043};\\\", \\\"{x:1518,y:929,t:1527009069061};\\\", \\\"{x:1515,y:931,t:1527009069078};\\\", \\\"{x:1513,y:932,t:1527009069093};\\\", \\\"{x:1509,y:932,t:1527009069111};\\\", \\\"{x:1501,y:935,t:1527009069127};\\\", \\\"{x:1495,y:936,t:1527009069143};\\\", \\\"{x:1491,y:937,t:1527009069161};\\\", \\\"{x:1485,y:940,t:1527009069178};\\\", \\\"{x:1482,y:940,t:1527009069194};\\\", \\\"{x:1478,y:940,t:1527009069211};\\\", \\\"{x:1472,y:943,t:1527009069226};\\\", \\\"{x:1467,y:944,t:1527009069243};\\\", \\\"{x:1457,y:948,t:1527009069260};\\\", \\\"{x:1446,y:950,t:1527009069278};\\\", \\\"{x:1432,y:952,t:1527009069293};\\\", \\\"{x:1419,y:952,t:1527009069310};\\\", \\\"{x:1414,y:952,t:1527009069328};\\\", \\\"{x:1410,y:952,t:1527009069344};\\\", \\\"{x:1407,y:952,t:1527009069360};\\\", \\\"{x:1406,y:952,t:1527009069378};\\\", \\\"{x:1404,y:952,t:1527009069393};\\\", \\\"{x:1406,y:951,t:1527009069675};\\\", \\\"{x:1407,y:949,t:1527009069683};\\\", \\\"{x:1408,y:949,t:1527009069694};\\\", \\\"{x:1413,y:946,t:1527009069710};\\\", \\\"{x:1416,y:944,t:1527009069727};\\\", \\\"{x:1417,y:943,t:1527009069744};\\\", \\\"{x:1418,y:942,t:1527009069759};\\\", \\\"{x:1420,y:941,t:1527009069777};\\\", \\\"{x:1424,y:941,t:1527009069794};\\\", \\\"{x:1429,y:941,t:1527009069809};\\\", \\\"{x:1442,y:943,t:1527009069827};\\\", \\\"{x:1461,y:949,t:1527009069844};\\\", \\\"{x:1479,y:954,t:1527009069860};\\\", \\\"{x:1490,y:958,t:1527009069877};\\\", \\\"{x:1500,y:960,t:1527009069894};\\\", \\\"{x:1507,y:961,t:1527009069910};\\\", \\\"{x:1511,y:961,t:1527009069928};\\\", \\\"{x:1510,y:961,t:1527009069987};\\\", \\\"{x:1504,y:961,t:1527009069994};\\\", \\\"{x:1492,y:961,t:1527009070011};\\\", \\\"{x:1486,y:961,t:1527009070027};\\\", \\\"{x:1481,y:963,t:1527009070044};\\\", \\\"{x:1473,y:964,t:1527009070061};\\\", \\\"{x:1468,y:967,t:1527009070077};\\\", \\\"{x:1454,y:971,t:1527009070094};\\\", \\\"{x:1437,y:974,t:1527009070111};\\\", \\\"{x:1417,y:980,t:1527009070127};\\\", \\\"{x:1399,y:982,t:1527009070144};\\\", \\\"{x:1384,y:982,t:1527009070162};\\\", \\\"{x:1373,y:982,t:1527009070177};\\\", \\\"{x:1366,y:981,t:1527009070194};\\\", \\\"{x:1365,y:981,t:1527009070211};\\\", \\\"{x:1364,y:981,t:1527009070315};\\\", \\\"{x:1364,y:980,t:1527009070339};\\\", \\\"{x:1364,y:979,t:1527009070347};\\\", \\\"{x:1364,y:978,t:1527009070371};\\\", \\\"{x:1365,y:976,t:1527009070451};\\\", \\\"{x:1366,y:975,t:1527009070467};\\\", \\\"{x:1367,y:974,t:1527009070479};\\\", \\\"{x:1369,y:972,t:1527009070496};\\\", \\\"{x:1372,y:971,t:1527009070512};\\\", \\\"{x:1375,y:970,t:1527009070529};\\\", \\\"{x:1375,y:969,t:1527009070544};\\\", \\\"{x:1377,y:968,t:1527009070562};\\\", \\\"{x:1378,y:968,t:1527009070579};\\\", \\\"{x:1380,y:968,t:1527009070619};\\\", \\\"{x:1381,y:968,t:1527009070643};\\\", \\\"{x:1383,y:968,t:1527009070659};\\\", \\\"{x:1384,y:968,t:1527009070668};\\\", \\\"{x:1386,y:968,t:1527009070679};\\\", \\\"{x:1390,y:968,t:1527009070695};\\\", \\\"{x:1396,y:968,t:1527009070712};\\\", \\\"{x:1403,y:968,t:1527009070728};\\\", \\\"{x:1411,y:968,t:1527009070744};\\\", \\\"{x:1420,y:968,t:1527009070762};\\\", \\\"{x:1433,y:968,t:1527009070778};\\\", \\\"{x:1441,y:968,t:1527009070795};\\\", \\\"{x:1445,y:969,t:1527009070811};\\\", \\\"{x:1449,y:971,t:1527009070828};\\\", \\\"{x:1454,y:973,t:1527009070844};\\\", \\\"{x:1459,y:974,t:1527009070861};\\\", \\\"{x:1464,y:975,t:1527009070879};\\\", \\\"{x:1470,y:978,t:1527009070894};\\\", \\\"{x:1476,y:980,t:1527009070911};\\\", \\\"{x:1482,y:982,t:1527009070928};\\\", \\\"{x:1486,y:982,t:1527009070945};\\\", \\\"{x:1491,y:983,t:1527009070962};\\\", \\\"{x:1493,y:983,t:1527009070978};\\\", \\\"{x:1495,y:984,t:1527009071011};\\\", \\\"{x:1494,y:986,t:1527009071068};\\\", \\\"{x:1492,y:986,t:1527009071107};\\\", \\\"{x:1491,y:987,t:1527009071115};\\\", \\\"{x:1490,y:988,t:1527009071129};\\\", \\\"{x:1489,y:989,t:1527009071146};\\\", \\\"{x:1487,y:989,t:1527009071161};\\\", \\\"{x:1483,y:991,t:1527009071179};\\\", \\\"{x:1481,y:991,t:1527009071196};\\\", \\\"{x:1479,y:992,t:1527009071211};\\\", \\\"{x:1478,y:992,t:1527009071243};\\\", \\\"{x:1477,y:993,t:1527009071475};\\\", \\\"{x:1478,y:993,t:1527009073875};\\\", \\\"{x:1480,y:993,t:1527009073891};\\\", \\\"{x:1481,y:993,t:1527009073906};\\\", \\\"{x:1483,y:993,t:1527009073923};\\\", \\\"{x:1484,y:993,t:1527009073946};\\\", \\\"{x:1486,y:993,t:1527009074123};\\\", \\\"{x:1487,y:993,t:1527009074138};\\\", \\\"{x:1490,y:993,t:1527009074154};\\\", \\\"{x:1492,y:993,t:1527009074173};\\\", \\\"{x:1494,y:993,t:1527009074180};\\\", \\\"{x:1497,y:993,t:1527009074197};\\\", \\\"{x:1504,y:991,t:1527009074213};\\\", \\\"{x:1510,y:991,t:1527009074230};\\\", \\\"{x:1513,y:991,t:1527009074247};\\\", \\\"{x:1521,y:990,t:1527009074264};\\\", \\\"{x:1529,y:989,t:1527009074284};\\\", \\\"{x:1536,y:989,t:1527009074301};\\\", \\\"{x:1541,y:987,t:1527009074318};\\\", \\\"{x:1542,y:987,t:1527009074335};\\\", \\\"{x:1544,y:986,t:1527009074351};\\\", \\\"{x:1546,y:985,t:1527009074991};\\\", \\\"{x:1547,y:985,t:1527009075007};\\\", \\\"{x:1548,y:984,t:1527009075020};\\\", \\\"{x:1549,y:984,t:1527009075080};\\\", \\\"{x:1549,y:983,t:1527009075255};\\\", \\\"{x:1549,y:982,t:1527009075367};\\\", \\\"{x:1549,y:981,t:1527009075375};\\\", \\\"{x:1547,y:981,t:1527009075398};\\\", \\\"{x:1546,y:980,t:1527009075422};\\\", \\\"{x:1544,y:980,t:1527009075438};\\\", \\\"{x:1544,y:979,t:1527009075453};\\\", \\\"{x:1542,y:978,t:1527009075469};\\\", \\\"{x:1541,y:977,t:1527009075485};\\\", \\\"{x:1538,y:977,t:1527009075501};\\\", \\\"{x:1538,y:976,t:1527009075518};\\\", \\\"{x:1537,y:976,t:1527009075536};\\\", \\\"{x:1536,y:975,t:1527009075552};\\\", \\\"{x:1535,y:975,t:1527009075646};\\\", \\\"{x:1534,y:975,t:1527009076327};\\\", \\\"{x:1533,y:975,t:1527009076343};\\\", \\\"{x:1531,y:975,t:1527009076353};\\\", \\\"{x:1529,y:975,t:1527009076369};\\\", \\\"{x:1528,y:975,t:1527009076391};\\\", \\\"{x:1527,y:975,t:1527009076448};\\\", \\\"{x:1526,y:975,t:1527009076478};\\\", \\\"{x:1525,y:976,t:1527009076511};\\\", \\\"{x:1524,y:977,t:1527009076527};\\\", \\\"{x:1523,y:977,t:1527009076537};\\\", \\\"{x:1522,y:977,t:1527009076583};\\\", \\\"{x:1521,y:977,t:1527009076615};\\\", \\\"{x:1520,y:977,t:1527009076622};\\\", \\\"{x:1519,y:977,t:1527009076637};\\\", \\\"{x:1518,y:978,t:1527009076653};\\\", \\\"{x:1517,y:978,t:1527009076670};\\\", \\\"{x:1515,y:978,t:1527009076686};\\\", \\\"{x:1514,y:978,t:1527009076703};\\\", \\\"{x:1513,y:978,t:1527009076720};\\\", \\\"{x:1512,y:978,t:1527009076737};\\\", \\\"{x:1510,y:978,t:1527009076754};\\\", \\\"{x:1508,y:978,t:1527009076770};\\\", \\\"{x:1507,y:978,t:1527009076786};\\\", \\\"{x:1506,y:978,t:1527009076804};\\\", \\\"{x:1504,y:978,t:1527009076820};\\\", \\\"{x:1502,y:978,t:1527009076837};\\\", \\\"{x:1500,y:978,t:1527009076854};\\\", \\\"{x:1497,y:978,t:1527009076870};\\\", \\\"{x:1493,y:978,t:1527009076886};\\\", \\\"{x:1491,y:978,t:1527009076903};\\\", \\\"{x:1489,y:979,t:1527009076919};\\\", \\\"{x:1488,y:979,t:1527009076937};\\\", \\\"{x:1487,y:979,t:1527009076966};\\\", \\\"{x:1487,y:980,t:1527009076990};\\\", \\\"{x:1486,y:980,t:1527009077014};\\\", \\\"{x:1485,y:980,t:1527009077047};\\\", \\\"{x:1485,y:981,t:1527009077823};\\\", \\\"{x:1485,y:982,t:1527009079319};\\\", \\\"{x:1486,y:982,t:1527009079559};\\\", \\\"{x:1486,y:981,t:1527009079599};\\\", \\\"{x:1486,y:980,t:1527009079847};\\\", \\\"{x:1487,y:980,t:1527009079871};\\\", \\\"{x:1488,y:980,t:1527009079902};\\\", \\\"{x:1489,y:980,t:1527009080103};\\\", \\\"{x:1489,y:979,t:1527009080599};\\\", \\\"{x:1489,y:978,t:1527009080607};\\\", \\\"{x:1489,y:974,t:1527009080623};\\\", \\\"{x:1489,y:971,t:1527009080640};\\\", \\\"{x:1489,y:967,t:1527009080657};\\\", \\\"{x:1489,y:965,t:1527009080673};\\\", \\\"{x:1489,y:964,t:1527009080690};\\\", \\\"{x:1489,y:961,t:1527009080706};\\\", \\\"{x:1488,y:960,t:1527009080723};\\\", \\\"{x:1486,y:958,t:1527009080740};\\\", \\\"{x:1484,y:956,t:1527009080756};\\\", \\\"{x:1484,y:955,t:1527009080774};\\\", \\\"{x:1483,y:954,t:1527009080790};\\\", \\\"{x:1481,y:953,t:1527009080806};\\\", \\\"{x:1479,y:949,t:1527009080823};\\\", \\\"{x:1475,y:944,t:1527009080840};\\\", \\\"{x:1471,y:940,t:1527009080855};\\\", \\\"{x:1468,y:935,t:1527009080872};\\\", \\\"{x:1464,y:931,t:1527009080889};\\\", \\\"{x:1461,y:928,t:1527009080905};\\\", \\\"{x:1458,y:924,t:1527009080923};\\\", \\\"{x:1456,y:921,t:1527009080939};\\\", \\\"{x:1454,y:920,t:1527009080956};\\\", \\\"{x:1454,y:918,t:1527009080972};\\\", \\\"{x:1452,y:916,t:1527009080990};\\\", \\\"{x:1452,y:915,t:1527009082919};\\\", \\\"{x:1452,y:914,t:1527009082926};\\\", \\\"{x:1452,y:913,t:1527009082942};\\\", \\\"{x:1452,y:912,t:1527009082967};\\\", \\\"{x:1452,y:911,t:1527009082974};\\\", \\\"{x:1452,y:910,t:1527009082991};\\\", \\\"{x:1452,y:909,t:1527009083008};\\\", \\\"{x:1452,y:906,t:1527009083025};\\\", \\\"{x:1452,y:905,t:1527009083046};\\\", \\\"{x:1453,y:905,t:1527009083058};\\\", \\\"{x:1453,y:903,t:1527009083075};\\\", \\\"{x:1453,y:902,t:1527009083091};\\\", \\\"{x:1453,y:901,t:1527009083119};\\\", \\\"{x:1453,y:900,t:1527009083143};\\\", \\\"{x:1454,y:899,t:1527009083158};\\\", \\\"{x:1455,y:899,t:1527009083182};\\\", \\\"{x:1456,y:898,t:1527009083207};\\\", \\\"{x:1456,y:897,t:1527009083225};\\\", \\\"{x:1458,y:893,t:1527009083241};\\\", \\\"{x:1458,y:891,t:1527009083258};\\\", \\\"{x:1458,y:890,t:1527009083275};\\\", \\\"{x:1458,y:888,t:1527009083703};\\\", \\\"{x:1458,y:887,t:1527009083791};\\\", \\\"{x:1459,y:884,t:1527009083809};\\\", \\\"{x:1460,y:881,t:1527009083825};\\\", \\\"{x:1463,y:876,t:1527009083842};\\\", \\\"{x:1463,y:872,t:1527009083859};\\\", \\\"{x:1466,y:867,t:1527009083875};\\\", \\\"{x:1469,y:863,t:1527009083892};\\\", \\\"{x:1471,y:858,t:1527009083909};\\\", \\\"{x:1474,y:853,t:1527009083925};\\\", \\\"{x:1479,y:844,t:1527009083943};\\\", \\\"{x:1482,y:838,t:1527009083958};\\\", \\\"{x:1487,y:832,t:1527009083975};\\\", \\\"{x:1490,y:824,t:1527009083993};\\\", \\\"{x:1496,y:816,t:1527009084009};\\\", \\\"{x:1501,y:810,t:1527009084025};\\\", \\\"{x:1505,y:803,t:1527009084042};\\\", \\\"{x:1509,y:797,t:1527009084059};\\\", \\\"{x:1513,y:790,t:1527009084075};\\\", \\\"{x:1515,y:787,t:1527009084093};\\\", \\\"{x:1516,y:782,t:1527009084110};\\\", \\\"{x:1518,y:778,t:1527009084125};\\\", \\\"{x:1519,y:772,t:1527009084143};\\\", \\\"{x:1519,y:769,t:1527009084159};\\\", \\\"{x:1519,y:765,t:1527009084175};\\\", \\\"{x:1519,y:761,t:1527009084191};\\\", \\\"{x:1519,y:758,t:1527009084208};\\\", \\\"{x:1519,y:757,t:1527009084224};\\\", \\\"{x:1519,y:756,t:1527009084246};\\\", \\\"{x:1519,y:754,t:1527009084487};\\\", \\\"{x:1518,y:754,t:1527009084503};\\\", \\\"{x:1517,y:754,t:1527009084518};\\\", \\\"{x:1516,y:753,t:1527009084534};\\\", \\\"{x:1515,y:753,t:1527009084551};\\\", \\\"{x:1513,y:752,t:1527009084559};\\\", \\\"{x:1512,y:752,t:1527009084576};\\\", \\\"{x:1509,y:752,t:1527009084591};\\\", \\\"{x:1502,y:751,t:1527009084608};\\\", \\\"{x:1494,y:749,t:1527009084626};\\\", \\\"{x:1484,y:747,t:1527009084641};\\\", \\\"{x:1475,y:746,t:1527009084659};\\\", \\\"{x:1468,y:745,t:1527009084676};\\\", \\\"{x:1458,y:743,t:1527009084692};\\\", \\\"{x:1448,y:741,t:1527009084709};\\\", \\\"{x:1441,y:738,t:1527009084725};\\\", \\\"{x:1440,y:738,t:1527009084743};\\\", \\\"{x:1438,y:738,t:1527009084773};\\\", \\\"{x:1438,y:737,t:1527009084919};\\\", \\\"{x:1437,y:737,t:1527009085079};\\\", \\\"{x:1436,y:737,t:1527009085093};\\\", \\\"{x:1435,y:737,t:1527009085109};\\\", \\\"{x:1428,y:734,t:1527009085126};\\\", \\\"{x:1419,y:731,t:1527009085143};\\\", \\\"{x:1408,y:729,t:1527009085159};\\\", \\\"{x:1392,y:728,t:1527009085176};\\\", \\\"{x:1373,y:725,t:1527009085192};\\\", \\\"{x:1348,y:719,t:1527009085209};\\\", \\\"{x:1328,y:713,t:1527009085226};\\\", \\\"{x:1312,y:708,t:1527009085243};\\\", \\\"{x:1302,y:703,t:1527009085260};\\\", \\\"{x:1295,y:698,t:1527009085276};\\\", \\\"{x:1293,y:696,t:1527009085293};\\\", \\\"{x:1293,y:695,t:1527009085318};\\\", \\\"{x:1293,y:694,t:1527009085326};\\\", \\\"{x:1293,y:689,t:1527009085343};\\\", \\\"{x:1293,y:686,t:1527009085360};\\\", \\\"{x:1290,y:680,t:1527009085376};\\\", \\\"{x:1290,y:678,t:1527009085393};\\\", \\\"{x:1289,y:677,t:1527009085410};\\\", \\\"{x:1289,y:675,t:1527009085426};\\\", \\\"{x:1289,y:674,t:1527009085446};\\\", \\\"{x:1289,y:673,t:1527009085479};\\\", \\\"{x:1289,y:672,t:1527009085493};\\\", \\\"{x:1289,y:671,t:1527009085511};\\\", \\\"{x:1289,y:670,t:1527009085542};\\\", \\\"{x:1289,y:669,t:1527009085599};\\\", \\\"{x:1289,y:668,t:1527009085615};\\\", \\\"{x:1289,y:667,t:1527009085626};\\\", \\\"{x:1289,y:665,t:1527009085643};\\\", \\\"{x:1290,y:661,t:1527009085660};\\\", \\\"{x:1291,y:653,t:1527009085676};\\\", \\\"{x:1292,y:647,t:1527009085693};\\\", \\\"{x:1294,y:634,t:1527009085710};\\\", \\\"{x:1294,y:623,t:1527009085726};\\\", \\\"{x:1293,y:614,t:1527009085743};\\\", \\\"{x:1291,y:607,t:1527009085760};\\\", \\\"{x:1287,y:604,t:1527009085777};\\\", \\\"{x:1285,y:600,t:1527009085793};\\\", \\\"{x:1284,y:596,t:1527009085809};\\\", \\\"{x:1283,y:596,t:1527009085827};\\\", \\\"{x:1282,y:596,t:1527009085843};\\\", \\\"{x:1282,y:595,t:1527009085862};\\\", \\\"{x:1282,y:594,t:1527009085877};\\\", \\\"{x:1282,y:593,t:1527009085893};\\\", \\\"{x:1282,y:592,t:1527009085910};\\\", \\\"{x:1282,y:591,t:1527009085927};\\\", \\\"{x:1282,y:590,t:1527009086063};\\\", \\\"{x:1283,y:590,t:1527009086077};\\\", \\\"{x:1287,y:593,t:1527009086093};\\\", \\\"{x:1290,y:600,t:1527009086110};\\\", \\\"{x:1291,y:605,t:1527009086127};\\\", \\\"{x:1292,y:609,t:1527009086142};\\\", \\\"{x:1295,y:618,t:1527009086160};\\\", \\\"{x:1300,y:632,t:1527009086176};\\\", \\\"{x:1308,y:644,t:1527009086194};\\\", \\\"{x:1315,y:659,t:1527009086210};\\\", \\\"{x:1321,y:669,t:1527009086227};\\\", \\\"{x:1328,y:682,t:1527009086243};\\\", \\\"{x:1335,y:694,t:1527009086259};\\\", \\\"{x:1348,y:715,t:1527009086276};\\\", \\\"{x:1363,y:743,t:1527009086294};\\\", \\\"{x:1374,y:762,t:1527009086310};\\\", \\\"{x:1382,y:773,t:1527009086327};\\\", \\\"{x:1387,y:781,t:1527009086344};\\\", \\\"{x:1390,y:786,t:1527009086360};\\\", \\\"{x:1391,y:789,t:1527009086377};\\\", \\\"{x:1391,y:792,t:1527009086394};\\\", \\\"{x:1391,y:796,t:1527009086410};\\\", \\\"{x:1391,y:800,t:1527009086426};\\\", \\\"{x:1391,y:803,t:1527009086444};\\\", \\\"{x:1391,y:804,t:1527009086460};\\\", \\\"{x:1391,y:806,t:1527009086477};\\\", \\\"{x:1390,y:813,t:1527009086494};\\\", \\\"{x:1388,y:821,t:1527009086510};\\\", \\\"{x:1384,y:831,t:1527009086527};\\\", \\\"{x:1382,y:840,t:1527009086544};\\\", \\\"{x:1378,y:851,t:1527009086560};\\\", \\\"{x:1376,y:860,t:1527009086577};\\\", \\\"{x:1375,y:870,t:1527009086594};\\\", \\\"{x:1375,y:879,t:1527009086609};\\\", \\\"{x:1375,y:891,t:1527009086627};\\\", \\\"{x:1375,y:898,t:1527009086643};\\\", \\\"{x:1375,y:905,t:1527009086660};\\\", \\\"{x:1374,y:911,t:1527009086677};\\\", \\\"{x:1371,y:927,t:1527009086695};\\\", \\\"{x:1369,y:940,t:1527009086710};\\\", \\\"{x:1366,y:950,t:1527009086727};\\\", \\\"{x:1365,y:957,t:1527009086744};\\\", \\\"{x:1365,y:959,t:1527009086761};\\\", \\\"{x:1365,y:961,t:1527009086777};\\\", \\\"{x:1365,y:963,t:1527009086794};\\\", \\\"{x:1363,y:963,t:1527009087079};\\\", \\\"{x:1354,y:964,t:1527009087094};\\\", \\\"{x:1341,y:968,t:1527009087111};\\\", \\\"{x:1328,y:970,t:1527009087128};\\\", \\\"{x:1321,y:972,t:1527009087145};\\\", \\\"{x:1320,y:973,t:1527009087162};\\\", \\\"{x:1319,y:973,t:1527009087262};\\\", \\\"{x:1310,y:965,t:1527009087277};\\\", \\\"{x:1299,y:953,t:1527009087293};\\\", \\\"{x:1287,y:942,t:1527009087310};\\\", \\\"{x:1282,y:939,t:1527009087328};\\\", \\\"{x:1279,y:935,t:1527009087344};\\\", \\\"{x:1278,y:933,t:1527009087360};\\\", \\\"{x:1278,y:932,t:1527009087377};\\\", \\\"{x:1278,y:931,t:1527009087394};\\\", \\\"{x:1278,y:929,t:1527009087411};\\\", \\\"{x:1277,y:929,t:1527009087427};\\\", \\\"{x:1277,y:928,t:1527009087444};\\\", \\\"{x:1277,y:926,t:1527009087462};\\\", \\\"{x:1277,y:925,t:1527009087511};\\\", \\\"{x:1277,y:923,t:1527009087591};\\\", \\\"{x:1277,y:922,t:1527009087615};\\\", \\\"{x:1277,y:920,t:1527009087807};\\\", \\\"{x:1278,y:919,t:1527009087822};\\\", \\\"{x:1279,y:918,t:1527009087838};\\\", \\\"{x:1279,y:917,t:1527009087846};\\\", \\\"{x:1280,y:915,t:1527009087861};\\\", \\\"{x:1283,y:912,t:1527009087878};\\\", \\\"{x:1284,y:909,t:1527009087894};\\\", \\\"{x:1285,y:906,t:1527009087911};\\\", \\\"{x:1286,y:904,t:1527009087928};\\\", \\\"{x:1288,y:900,t:1527009087945};\\\", \\\"{x:1289,y:896,t:1527009087961};\\\", \\\"{x:1289,y:893,t:1527009087978};\\\", \\\"{x:1292,y:890,t:1527009087995};\\\", \\\"{x:1292,y:884,t:1527009088012};\\\", \\\"{x:1292,y:876,t:1527009088028};\\\", \\\"{x:1294,y:865,t:1527009088045};\\\", \\\"{x:1294,y:858,t:1527009088062};\\\", \\\"{x:1296,y:849,t:1527009088078};\\\", \\\"{x:1296,y:843,t:1527009088095};\\\", \\\"{x:1297,y:839,t:1527009088112};\\\", \\\"{x:1300,y:833,t:1527009088128};\\\", \\\"{x:1301,y:830,t:1527009088145};\\\", \\\"{x:1305,y:824,t:1527009088163};\\\", \\\"{x:1308,y:820,t:1527009088178};\\\", \\\"{x:1310,y:815,t:1527009088195};\\\", \\\"{x:1313,y:813,t:1527009088212};\\\", \\\"{x:1316,y:810,t:1527009088228};\\\", \\\"{x:1318,y:807,t:1527009088245};\\\", \\\"{x:1322,y:804,t:1527009088262};\\\", \\\"{x:1323,y:801,t:1527009088279};\\\", \\\"{x:1327,y:797,t:1527009088296};\\\", \\\"{x:1330,y:791,t:1527009088313};\\\", \\\"{x:1335,y:786,t:1527009088329};\\\", \\\"{x:1339,y:780,t:1527009088345};\\\", \\\"{x:1342,y:777,t:1527009088363};\\\", \\\"{x:1342,y:776,t:1527009088378};\\\", \\\"{x:1344,y:774,t:1527009088396};\\\", \\\"{x:1345,y:774,t:1527009088414};\\\", \\\"{x:1346,y:773,t:1527009088428};\\\", \\\"{x:1348,y:773,t:1527009088445};\\\", \\\"{x:1351,y:772,t:1527009088462};\\\", \\\"{x:1354,y:770,t:1527009088478};\\\", \\\"{x:1360,y:769,t:1527009088495};\\\", \\\"{x:1363,y:768,t:1527009088513};\\\", \\\"{x:1366,y:767,t:1527009088528};\\\", \\\"{x:1372,y:766,t:1527009088545};\\\", \\\"{x:1377,y:765,t:1527009088563};\\\", \\\"{x:1380,y:765,t:1527009088578};\\\", \\\"{x:1384,y:765,t:1527009088595};\\\", \\\"{x:1385,y:765,t:1527009088611};\\\", \\\"{x:1387,y:765,t:1527009088629};\\\", \\\"{x:1388,y:765,t:1527009088645};\\\", \\\"{x:1395,y:765,t:1527009088661};\\\", \\\"{x:1399,y:765,t:1527009088679};\\\", \\\"{x:1401,y:765,t:1527009088695};\\\", \\\"{x:1402,y:765,t:1527009088712};\\\", \\\"{x:1404,y:765,t:1527009088742};\\\", \\\"{x:1403,y:765,t:1527009090583};\\\", \\\"{x:1403,y:766,t:1527009090639};\\\", \\\"{x:1402,y:766,t:1527009090679};\\\", \\\"{x:1401,y:767,t:1527009090799};\\\", \\\"{x:1400,y:767,t:1527009091887};\\\", \\\"{x:1399,y:768,t:1527009091927};\\\", \\\"{x:1398,y:768,t:1527009092255};\\\", \\\"{x:1397,y:768,t:1527009092271};\\\", \\\"{x:1396,y:768,t:1527009092287};\\\", \\\"{x:1395,y:768,t:1527009092335};\\\", \\\"{x:1394,y:768,t:1527009092348};\\\", \\\"{x:1393,y:768,t:1527009092367};\\\", \\\"{x:1392,y:768,t:1527009092398};\\\", \\\"{x:1391,y:768,t:1527009092455};\\\", \\\"{x:1390,y:768,t:1527009092479};\\\", \\\"{x:1389,y:768,t:1527009092519};\\\", \\\"{x:1389,y:767,t:1527009092531};\\\", \\\"{x:1388,y:766,t:1527009092599};\\\", \\\"{x:1387,y:766,t:1527009092671};\\\", \\\"{x:1386,y:766,t:1527009095439};\\\", \\\"{x:1384,y:766,t:1527009095451};\\\", \\\"{x:1375,y:766,t:1527009095468};\\\", \\\"{x:1372,y:767,t:1527009095483};\\\", \\\"{x:1361,y:771,t:1527009095500};\\\", \\\"{x:1352,y:775,t:1527009095517};\\\", \\\"{x:1345,y:775,t:1527009095533};\\\", \\\"{x:1336,y:776,t:1527009095550};\\\", \\\"{x:1326,y:776,t:1527009095568};\\\", \\\"{x:1322,y:776,t:1527009095583};\\\", \\\"{x:1321,y:776,t:1527009095600};\\\", \\\"{x:1320,y:776,t:1527009095792};\\\", \\\"{x:1318,y:776,t:1527009095801};\\\", \\\"{x:1315,y:776,t:1527009095817};\\\", \\\"{x:1314,y:776,t:1527009095834};\\\", \\\"{x:1313,y:776,t:1527009095850};\\\", \\\"{x:1312,y:776,t:1527009095878};\\\", \\\"{x:1311,y:775,t:1527009095966};\\\", \\\"{x:1310,y:775,t:1527009095990};\\\", \\\"{x:1309,y:775,t:1527009096062};\\\", \\\"{x:1308,y:775,t:1527009098015};\\\", \\\"{x:1304,y:771,t:1527009098023};\\\", \\\"{x:1302,y:768,t:1527009098036};\\\", \\\"{x:1295,y:761,t:1527009098053};\\\", \\\"{x:1293,y:756,t:1527009098069};\\\", \\\"{x:1291,y:754,t:1527009098086};\\\", \\\"{x:1291,y:753,t:1527009098103};\\\", \\\"{x:1290,y:752,t:1527009098134};\\\", \\\"{x:1290,y:751,t:1527009098165};\\\", \\\"{x:1289,y:751,t:1527009098182};\\\", \\\"{x:1288,y:751,t:1527009098213};\\\", \\\"{x:1286,y:751,t:1527009098270};\\\", \\\"{x:1285,y:750,t:1527009098285};\\\", \\\"{x:1282,y:747,t:1527009098303};\\\", \\\"{x:1280,y:746,t:1527009098319};\\\", \\\"{x:1278,y:743,t:1527009098335};\\\", \\\"{x:1275,y:741,t:1527009098352};\\\", \\\"{x:1274,y:740,t:1527009098374};\\\", \\\"{x:1273,y:739,t:1527009098385};\\\", \\\"{x:1272,y:739,t:1527009098403};\\\", \\\"{x:1271,y:738,t:1527009098420};\\\", \\\"{x:1270,y:737,t:1527009098436};\\\", \\\"{x:1268,y:735,t:1527009098453};\\\", \\\"{x:1264,y:733,t:1527009098470};\\\", \\\"{x:1260,y:731,t:1527009098486};\\\", \\\"{x:1252,y:726,t:1527009098503};\\\", \\\"{x:1247,y:724,t:1527009098520};\\\", \\\"{x:1243,y:722,t:1527009098537};\\\", \\\"{x:1240,y:720,t:1527009098553};\\\", \\\"{x:1238,y:719,t:1527009098570};\\\", \\\"{x:1236,y:719,t:1527009098587};\\\", \\\"{x:1233,y:717,t:1527009098603};\\\", \\\"{x:1231,y:716,t:1527009098620};\\\", \\\"{x:1227,y:715,t:1527009098637};\\\", \\\"{x:1224,y:713,t:1527009098653};\\\", \\\"{x:1221,y:712,t:1527009098670};\\\", \\\"{x:1220,y:711,t:1527009098687};\\\", \\\"{x:1218,y:711,t:1527009098702};\\\", \\\"{x:1217,y:711,t:1527009098719};\\\", \\\"{x:1217,y:709,t:1527009098838};\\\", \\\"{x:1217,y:707,t:1527009098863};\\\", \\\"{x:1217,y:706,t:1527009098870};\\\", \\\"{x:1217,y:704,t:1527009098886};\\\", \\\"{x:1217,y:702,t:1527009098903};\\\", \\\"{x:1217,y:701,t:1527009098920};\\\", \\\"{x:1217,y:700,t:1527009098958};\\\", \\\"{x:1217,y:699,t:1527009098983};\\\", \\\"{x:1217,y:698,t:1527009099006};\\\", \\\"{x:1217,y:697,t:1527009099030};\\\", \\\"{x:1217,y:696,t:1527009099038};\\\", \\\"{x:1217,y:695,t:1527009099055};\\\", \\\"{x:1218,y:694,t:1527009099070};\\\", \\\"{x:1219,y:691,t:1527009099086};\\\", \\\"{x:1221,y:687,t:1527009099104};\\\", \\\"{x:1222,y:684,t:1527009099119};\\\", \\\"{x:1225,y:678,t:1527009099137};\\\", \\\"{x:1226,y:675,t:1527009099153};\\\", \\\"{x:1227,y:672,t:1527009099170};\\\", \\\"{x:1229,y:670,t:1527009099187};\\\", \\\"{x:1233,y:667,t:1527009099204};\\\", \\\"{x:1234,y:663,t:1527009099220};\\\", \\\"{x:1236,y:659,t:1527009099236};\\\", \\\"{x:1238,y:657,t:1527009099253};\\\", \\\"{x:1239,y:655,t:1527009099269};\\\", \\\"{x:1240,y:653,t:1527009099287};\\\", \\\"{x:1241,y:651,t:1527009099303};\\\", \\\"{x:1242,y:650,t:1527009099320};\\\", \\\"{x:1243,y:649,t:1527009099337};\\\", \\\"{x:1240,y:649,t:1527009099423};\\\", \\\"{x:1230,y:649,t:1527009099437};\\\", \\\"{x:1198,y:658,t:1527009099454};\\\", \\\"{x:1125,y:671,t:1527009099471};\\\", \\\"{x:1043,y:677,t:1527009099486};\\\", \\\"{x:962,y:677,t:1527009099504};\\\", \\\"{x:868,y:677,t:1527009099520};\\\", \\\"{x:798,y:676,t:1527009099536};\\\", \\\"{x:760,y:673,t:1527009099554};\\\", \\\"{x:738,y:669,t:1527009099571};\\\", \\\"{x:727,y:669,t:1527009099587};\\\", \\\"{x:726,y:669,t:1527009099604};\\\", \\\"{x:725,y:667,t:1527009099687};\\\", \\\"{x:732,y:660,t:1527009099703};\\\", \\\"{x:741,y:652,t:1527009099721};\\\", \\\"{x:756,y:642,t:1527009099736};\\\", \\\"{x:772,y:635,t:1527009099753};\\\", \\\"{x:791,y:625,t:1527009099770};\\\", \\\"{x:803,y:618,t:1527009099786};\\\", \\\"{x:816,y:610,t:1527009099804};\\\", \\\"{x:821,y:604,t:1527009099820};\\\", \\\"{x:824,y:600,t:1527009099836};\\\", \\\"{x:826,y:597,t:1527009099855};\\\", \\\"{x:826,y:595,t:1527009099871};\\\", \\\"{x:830,y:594,t:1527009099888};\\\", \\\"{x:835,y:592,t:1527009099905};\\\", \\\"{x:837,y:586,t:1527009099922};\\\", \\\"{x:837,y:583,t:1527009099942};\\\", \\\"{x:838,y:582,t:1527009099955};\\\", \\\"{x:838,y:581,t:1527009099973};\\\", \\\"{x:838,y:580,t:1527009100030};\\\", \\\"{x:839,y:579,t:1527009100070};\\\", \\\"{x:841,y:576,t:1527009100078};\\\", \\\"{x:842,y:575,t:1527009100094};\\\", \\\"{x:842,y:574,t:1527009100192};\\\", \\\"{x:842,y:569,t:1527009100205};\\\", \\\"{x:842,y:566,t:1527009100222};\\\", \\\"{x:842,y:562,t:1527009100239};\\\", \\\"{x:842,y:554,t:1527009100256};\\\", \\\"{x:842,y:545,t:1527009100272};\\\", \\\"{x:842,y:540,t:1527009100290};\\\", \\\"{x:842,y:538,t:1527009100306};\\\", \\\"{x:842,y:535,t:1527009100323};\\\", \\\"{x:842,y:532,t:1527009100339};\\\", \\\"{x:842,y:531,t:1527009100494};\\\", \\\"{x:842,y:530,t:1527009100506};\\\", \\\"{x:845,y:530,t:1527009100943};\\\", \\\"{x:852,y:530,t:1527009100957};\\\", \\\"{x:885,y:550,t:1527009100976};\\\", \\\"{x:929,y:569,t:1527009100990};\\\", \\\"{x:995,y:595,t:1527009101007};\\\", \\\"{x:1079,y:624,t:1527009101023};\\\", \\\"{x:1174,y:658,t:1527009101039};\\\", \\\"{x:1280,y:692,t:1527009101056};\\\", \\\"{x:1367,y:721,t:1527009101073};\\\", \\\"{x:1448,y:748,t:1527009101090};\\\", \\\"{x:1496,y:764,t:1527009101106};\\\", \\\"{x:1516,y:771,t:1527009101123};\\\", \\\"{x:1531,y:776,t:1527009101140};\\\", \\\"{x:1533,y:777,t:1527009101157};\\\", \\\"{x:1534,y:778,t:1527009101181};\\\", \\\"{x:1533,y:778,t:1527009101407};\\\", \\\"{x:1528,y:780,t:1527009101424};\\\", \\\"{x:1524,y:783,t:1527009101441};\\\", \\\"{x:1520,y:786,t:1527009101458};\\\", \\\"{x:1516,y:790,t:1527009101474};\\\", \\\"{x:1511,y:801,t:1527009101491};\\\", \\\"{x:1506,y:819,t:1527009101508};\\\", \\\"{x:1505,y:837,t:1527009101524};\\\", \\\"{x:1503,y:846,t:1527009101541};\\\", \\\"{x:1503,y:849,t:1527009101558};\\\", \\\"{x:1500,y:849,t:1527009102031};\\\", \\\"{x:1494,y:850,t:1527009102041};\\\", \\\"{x:1473,y:855,t:1527009102058};\\\", \\\"{x:1450,y:859,t:1527009102074};\\\", \\\"{x:1418,y:865,t:1527009102091};\\\", \\\"{x:1373,y:873,t:1527009102108};\\\", \\\"{x:1322,y:880,t:1527009102125};\\\", \\\"{x:1292,y:884,t:1527009102141};\\\", \\\"{x:1269,y:887,t:1527009102158};\\\", \\\"{x:1267,y:888,t:1527009102174};\\\", \\\"{x:1266,y:888,t:1527009102447};\\\", \\\"{x:1264,y:886,t:1527009102458};\\\", \\\"{x:1259,y:882,t:1527009102475};\\\", \\\"{x:1256,y:879,t:1527009102492};\\\", \\\"{x:1254,y:877,t:1527009102508};\\\", \\\"{x:1249,y:874,t:1527009102525};\\\", \\\"{x:1244,y:871,t:1527009102541};\\\", \\\"{x:1240,y:868,t:1527009102558};\\\", \\\"{x:1239,y:868,t:1527009102599};\\\", \\\"{x:1238,y:866,t:1527009103015};\\\", \\\"{x:1237,y:865,t:1527009103025};\\\", \\\"{x:1237,y:863,t:1527009103042};\\\", \\\"{x:1236,y:861,t:1527009103062};\\\", \\\"{x:1235,y:861,t:1527009103075};\\\", \\\"{x:1234,y:860,t:1527009103091};\\\", \\\"{x:1233,y:857,t:1527009103109};\\\", \\\"{x:1231,y:855,t:1527009103125};\\\", \\\"{x:1226,y:849,t:1527009103142};\\\", \\\"{x:1221,y:845,t:1527009103159};\\\", \\\"{x:1218,y:841,t:1527009103176};\\\", \\\"{x:1211,y:837,t:1527009103192};\\\", \\\"{x:1209,y:836,t:1527009103209};\\\", \\\"{x:1208,y:835,t:1527009103225};\\\", \\\"{x:1208,y:834,t:1527009103241};\\\", \\\"{x:1209,y:834,t:1527009103301};\\\", \\\"{x:1210,y:834,t:1527009103309};\\\", \\\"{x:1214,y:834,t:1527009103326};\\\", \\\"{x:1218,y:834,t:1527009103341};\\\", \\\"{x:1221,y:834,t:1527009103359};\\\", \\\"{x:1223,y:834,t:1527009103375};\\\", \\\"{x:1225,y:834,t:1527009103391};\\\", \\\"{x:1228,y:834,t:1527009103408};\\\", \\\"{x:1229,y:834,t:1527009103430};\\\", \\\"{x:1230,y:834,t:1527009103470};\\\", \\\"{x:1231,y:834,t:1527009103559};\\\", \\\"{x:1234,y:834,t:1527009103695};\\\", \\\"{x:1237,y:834,t:1527009103709};\\\", \\\"{x:1248,y:829,t:1527009103726};\\\", \\\"{x:1253,y:826,t:1527009103743};\\\", \\\"{x:1261,y:821,t:1527009103759};\\\", \\\"{x:1268,y:816,t:1527009103776};\\\", \\\"{x:1282,y:808,t:1527009103793};\\\", \\\"{x:1293,y:798,t:1527009103809};\\\", \\\"{x:1307,y:787,t:1527009103826};\\\", \\\"{x:1318,y:780,t:1527009103843};\\\", \\\"{x:1323,y:778,t:1527009103859};\\\", \\\"{x:1328,y:775,t:1527009103876};\\\", \\\"{x:1329,y:775,t:1527009103893};\\\", \\\"{x:1328,y:775,t:1527009104174};\\\", \\\"{x:1327,y:770,t:1527009104575};\\\", \\\"{x:1327,y:756,t:1527009104582};\\\", \\\"{x:1322,y:739,t:1527009104593};\\\", \\\"{x:1315,y:723,t:1527009104610};\\\", \\\"{x:1310,y:714,t:1527009104627};\\\", \\\"{x:1309,y:710,t:1527009104643};\\\", \\\"{x:1307,y:704,t:1527009104660};\\\", \\\"{x:1306,y:698,t:1527009104677};\\\", \\\"{x:1304,y:689,t:1527009104693};\\\", \\\"{x:1300,y:667,t:1527009104710};\\\", \\\"{x:1299,y:654,t:1527009104727};\\\", \\\"{x:1295,y:636,t:1527009104743};\\\", \\\"{x:1290,y:617,t:1527009104760};\\\", \\\"{x:1287,y:610,t:1527009104777};\\\", \\\"{x:1287,y:605,t:1527009104794};\\\", \\\"{x:1287,y:600,t:1527009104810};\\\", \\\"{x:1287,y:590,t:1527009104827};\\\", \\\"{x:1288,y:575,t:1527009104844};\\\", \\\"{x:1288,y:560,t:1527009104860};\\\", \\\"{x:1288,y:546,t:1527009104877};\\\", \\\"{x:1288,y:526,t:1527009104894};\\\", \\\"{x:1288,y:518,t:1527009104910};\\\", \\\"{x:1289,y:512,t:1527009104927};\\\", \\\"{x:1292,y:507,t:1527009104944};\\\", \\\"{x:1297,y:501,t:1527009104960};\\\", \\\"{x:1300,y:497,t:1527009104977};\\\", \\\"{x:1309,y:493,t:1527009104994};\\\", \\\"{x:1316,y:489,t:1527009105010};\\\", \\\"{x:1320,y:485,t:1527009105028};\\\", \\\"{x:1323,y:481,t:1527009105044};\\\", \\\"{x:1327,y:477,t:1527009105060};\\\", \\\"{x:1333,y:475,t:1527009105077};\\\", \\\"{x:1343,y:469,t:1527009105094};\\\", \\\"{x:1355,y:464,t:1527009105110};\\\", \\\"{x:1367,y:462,t:1527009105127};\\\", \\\"{x:1375,y:458,t:1527009105144};\\\", \\\"{x:1383,y:454,t:1527009105160};\\\", \\\"{x:1385,y:453,t:1527009105177};\\\", \\\"{x:1387,y:453,t:1527009105194};\\\", \\\"{x:1388,y:452,t:1527009105211};\\\", \\\"{x:1389,y:452,t:1527009105227};\\\", \\\"{x:1393,y:450,t:1527009105244};\\\", \\\"{x:1399,y:447,t:1527009105261};\\\", \\\"{x:1411,y:444,t:1527009105277};\\\", \\\"{x:1419,y:440,t:1527009105294};\\\", \\\"{x:1420,y:439,t:1527009105311};\\\", \\\"{x:1421,y:439,t:1527009105527};\\\", \\\"{x:1421,y:437,t:1527009105583};\\\", \\\"{x:1417,y:437,t:1527009105861};\\\", \\\"{x:1413,y:443,t:1527009105878};\\\", \\\"{x:1406,y:450,t:1527009105893};\\\", \\\"{x:1404,y:454,t:1527009105911};\\\", \\\"{x:1399,y:459,t:1527009105927};\\\", \\\"{x:1396,y:463,t:1527009105944};\\\", \\\"{x:1392,y:467,t:1527009105961};\\\", \\\"{x:1389,y:473,t:1527009105978};\\\", \\\"{x:1381,y:484,t:1527009105994};\\\", \\\"{x:1373,y:493,t:1527009106010};\\\", \\\"{x:1368,y:501,t:1527009106027};\\\", \\\"{x:1363,y:508,t:1527009106045};\\\", \\\"{x:1357,y:512,t:1527009106061};\\\", \\\"{x:1342,y:525,t:1527009106078};\\\", \\\"{x:1331,y:532,t:1527009106094};\\\", \\\"{x:1318,y:539,t:1527009106111};\\\", \\\"{x:1302,y:546,t:1527009106128};\\\", \\\"{x:1287,y:551,t:1527009106145};\\\", \\\"{x:1274,y:555,t:1527009106160};\\\", \\\"{x:1271,y:556,t:1527009106177};\\\", \\\"{x:1271,y:554,t:1527009106303};\\\", \\\"{x:1273,y:549,t:1527009106311};\\\", \\\"{x:1276,y:543,t:1527009106328};\\\", \\\"{x:1280,y:538,t:1527009106345};\\\", \\\"{x:1284,y:533,t:1527009106361};\\\", \\\"{x:1286,y:530,t:1527009106378};\\\", \\\"{x:1289,y:525,t:1527009106395};\\\", \\\"{x:1291,y:521,t:1527009106412};\\\", \\\"{x:1293,y:518,t:1527009106428};\\\", \\\"{x:1295,y:515,t:1527009106445};\\\", \\\"{x:1299,y:511,t:1527009106462};\\\", \\\"{x:1302,y:508,t:1527009106479};\\\", \\\"{x:1302,y:506,t:1527009106495};\\\", \\\"{x:1303,y:505,t:1527009106518};\\\", \\\"{x:1304,y:505,t:1527009106535};\\\", \\\"{x:1304,y:513,t:1527009109551};\\\", \\\"{x:1304,y:519,t:1527009109564};\\\", \\\"{x:1306,y:533,t:1527009109581};\\\", \\\"{x:1306,y:542,t:1527009109597};\\\", \\\"{x:1311,y:556,t:1527009109614};\\\", \\\"{x:1314,y:563,t:1527009109631};\\\", \\\"{x:1318,y:569,t:1527009109648};\\\", \\\"{x:1321,y:575,t:1527009109664};\\\", \\\"{x:1323,y:578,t:1527009109681};\\\", \\\"{x:1323,y:582,t:1527009109699};\\\", \\\"{x:1326,y:589,t:1527009109714};\\\", \\\"{x:1327,y:599,t:1527009109732};\\\", \\\"{x:1331,y:611,t:1527009109748};\\\", \\\"{x:1332,y:616,t:1527009109764};\\\", \\\"{x:1335,y:624,t:1527009109781};\\\", \\\"{x:1338,y:636,t:1527009109798};\\\", \\\"{x:1341,y:649,t:1527009109815};\\\", \\\"{x:1347,y:667,t:1527009109831};\\\", \\\"{x:1351,y:687,t:1527009109848};\\\", \\\"{x:1354,y:708,t:1527009109864};\\\", \\\"{x:1357,y:728,t:1527009109882};\\\", \\\"{x:1361,y:739,t:1527009109898};\\\", \\\"{x:1362,y:743,t:1527009109914};\\\", \\\"{x:1364,y:746,t:1527009109931};\\\", \\\"{x:1365,y:749,t:1527009109948};\\\", \\\"{x:1365,y:750,t:1527009109964};\\\", \\\"{x:1367,y:753,t:1527009109981};\\\", \\\"{x:1368,y:757,t:1527009109998};\\\", \\\"{x:1368,y:758,t:1527009110015};\\\", \\\"{x:1368,y:761,t:1527009110032};\\\", \\\"{x:1368,y:762,t:1527009110049};\\\", \\\"{x:1368,y:765,t:1527009110065};\\\", \\\"{x:1365,y:766,t:1527009110081};\\\", \\\"{x:1359,y:766,t:1527009110098};\\\", \\\"{x:1353,y:766,t:1527009110115};\\\", \\\"{x:1352,y:766,t:1527009110132};\\\", \\\"{x:1351,y:766,t:1527009110148};\\\", \\\"{x:1350,y:766,t:1527009110343};\\\", \\\"{x:1350,y:767,t:1527009110350};\\\", \\\"{x:1348,y:768,t:1527009110365};\\\", \\\"{x:1346,y:769,t:1527009110382};\\\", \\\"{x:1343,y:771,t:1527009110398};\\\", \\\"{x:1341,y:772,t:1527009110416};\\\", \\\"{x:1339,y:772,t:1527009110431};\\\", \\\"{x:1338,y:772,t:1527009110535};\\\", \\\"{x:1337,y:772,t:1527009110549};\\\", \\\"{x:1336,y:772,t:1527009110565};\\\", \\\"{x:1335,y:772,t:1527009110638};\\\", \\\"{x:1334,y:772,t:1527009110648};\\\", \\\"{x:1333,y:772,t:1527009110665};\\\", \\\"{x:1332,y:772,t:1527009110682};\\\", \\\"{x:1331,y:772,t:1527009111310};\\\", \\\"{x:1331,y:774,t:1527009111318};\\\", \\\"{x:1331,y:775,t:1527009111334};\\\", \\\"{x:1331,y:777,t:1527009111350};\\\", \\\"{x:1331,y:778,t:1527009111366};\\\", \\\"{x:1331,y:780,t:1527009111390};\\\", \\\"{x:1331,y:782,t:1527009111406};\\\", \\\"{x:1332,y:784,t:1527009111438};\\\", \\\"{x:1333,y:785,t:1527009111502};\\\", \\\"{x:1333,y:786,t:1527009111517};\\\", \\\"{x:1334,y:787,t:1527009111543};\\\", \\\"{x:1333,y:787,t:1527009113119};\\\", \\\"{x:1332,y:787,t:1527009113334};\\\", \\\"{x:1331,y:787,t:1527009113352};\\\", \\\"{x:1330,y:787,t:1527009113511};\\\", \\\"{x:1331,y:787,t:1527009115382};\\\", \\\"{x:1334,y:787,t:1527009115390};\\\", \\\"{x:1339,y:786,t:1527009115402};\\\", \\\"{x:1346,y:783,t:1527009115419};\\\", \\\"{x:1350,y:782,t:1527009115437};\\\", \\\"{x:1355,y:780,t:1527009115452};\\\", \\\"{x:1360,y:779,t:1527009115469};\\\", \\\"{x:1362,y:778,t:1527009115486};\\\", \\\"{x:1363,y:778,t:1527009115502};\\\", \\\"{x:1365,y:777,t:1527009115519};\\\", \\\"{x:1368,y:775,t:1527009115536};\\\", \\\"{x:1369,y:775,t:1527009115552};\\\", \\\"{x:1372,y:775,t:1527009115570};\\\", \\\"{x:1373,y:773,t:1527009115587};\\\", \\\"{x:1374,y:773,t:1527009115606};\\\", \\\"{x:1375,y:773,t:1527009115654};\\\", \\\"{x:1376,y:772,t:1527009115670};\\\", \\\"{x:1377,y:772,t:1527009115686};\\\", \\\"{x:1379,y:771,t:1527009115703};\\\", \\\"{x:1375,y:769,t:1527009117894};\\\", \\\"{x:1367,y:769,t:1527009117904};\\\", \\\"{x:1351,y:769,t:1527009117921};\\\", \\\"{x:1336,y:771,t:1527009117938};\\\", \\\"{x:1309,y:775,t:1527009117955};\\\", \\\"{x:1261,y:783,t:1527009117972};\\\", \\\"{x:1201,y:788,t:1527009117988};\\\", \\\"{x:1127,y:793,t:1527009118005};\\\", \\\"{x:1042,y:796,t:1527009118022};\\\", \\\"{x:999,y:799,t:1527009118038};\\\", \\\"{x:962,y:799,t:1527009118055};\\\", \\\"{x:906,y:798,t:1527009118071};\\\", \\\"{x:852,y:789,t:1527009118089};\\\", \\\"{x:798,y:779,t:1527009118104};\\\", \\\"{x:734,y:762,t:1527009118122};\\\", \\\"{x:668,y:746,t:1527009118138};\\\", \\\"{x:637,y:736,t:1527009118155};\\\", \\\"{x:624,y:733,t:1527009118172};\\\", \\\"{x:621,y:731,t:1527009118189};\\\", \\\"{x:622,y:730,t:1527009118214};\\\", \\\"{x:624,y:729,t:1527009118221};\\\", \\\"{x:626,y:727,t:1527009118238};\\\", \\\"{x:628,y:722,t:1527009118255};\\\", \\\"{x:626,y:714,t:1527009118271};\\\", \\\"{x:618,y:705,t:1527009118288};\\\", \\\"{x:606,y:690,t:1527009118305};\\\", \\\"{x:592,y:678,t:1527009118321};\\\", \\\"{x:580,y:666,t:1527009118338};\\\", \\\"{x:577,y:664,t:1527009118355};\\\", \\\"{x:575,y:664,t:1527009118371};\\\", \\\"{x:572,y:660,t:1527009118388};\\\", \\\"{x:561,y:651,t:1527009118405};\\\", \\\"{x:561,y:650,t:1527009118422};\\\", \\\"{x:560,y:649,t:1527009118438};\\\", \\\"{x:561,y:648,t:1527009118461};\\\", \\\"{x:562,y:648,t:1527009118477};\\\", \\\"{x:560,y:647,t:1527009118557};\\\", \\\"{x:559,y:647,t:1527009118570};\\\", \\\"{x:556,y:647,t:1527009118587};\\\", \\\"{x:549,y:646,t:1527009118604};\\\", \\\"{x:546,y:645,t:1527009118619};\\\", \\\"{x:539,y:642,t:1527009118637};\\\", \\\"{x:530,y:638,t:1527009118654};\\\", \\\"{x:514,y:633,t:1527009118670};\\\", \\\"{x:493,y:625,t:1527009118688};\\\", \\\"{x:473,y:620,t:1527009118704};\\\", \\\"{x:456,y:614,t:1527009118720};\\\", \\\"{x:441,y:608,t:1527009118737};\\\", \\\"{x:425,y:601,t:1527009118754};\\\", \\\"{x:409,y:596,t:1527009118770};\\\", \\\"{x:394,y:588,t:1527009118787};\\\", \\\"{x:378,y:581,t:1527009118805};\\\", \\\"{x:360,y:574,t:1527009118821};\\\", \\\"{x:354,y:572,t:1527009118837};\\\", \\\"{x:353,y:571,t:1527009118853};\\\", \\\"{x:354,y:571,t:1527009118958};\\\", \\\"{x:358,y:569,t:1527009118970};\\\", \\\"{x:364,y:567,t:1527009118987};\\\", \\\"{x:371,y:563,t:1527009119004};\\\", \\\"{x:380,y:557,t:1527009119022};\\\", \\\"{x:386,y:554,t:1527009119037};\\\", \\\"{x:391,y:551,t:1527009119054};\\\", \\\"{x:396,y:548,t:1527009119071};\\\", \\\"{x:397,y:547,t:1527009119087};\\\", \\\"{x:401,y:547,t:1527009119373};\\\", \\\"{x:406,y:547,t:1527009119388};\\\", \\\"{x:419,y:553,t:1527009119404};\\\", \\\"{x:440,y:568,t:1527009119421};\\\", \\\"{x:458,y:582,t:1527009119438};\\\", \\\"{x:475,y:600,t:1527009119454};\\\", \\\"{x:489,y:617,t:1527009119472};\\\", \\\"{x:505,y:637,t:1527009119489};\\\", \\\"{x:516,y:653,t:1527009119504};\\\", \\\"{x:523,y:665,t:1527009119521};\\\", \\\"{x:532,y:679,t:1527009119538};\\\", \\\"{x:537,y:688,t:1527009119554};\\\", \\\"{x:542,y:698,t:1527009119571};\\\", \\\"{x:545,y:705,t:1527009119589};\\\", \\\"{x:546,y:708,t:1527009119604};\\\", \\\"{x:549,y:719,t:1527009119621};\\\", \\\"{x:553,y:729,t:1527009119638};\\\", \\\"{x:554,y:734,t:1527009119656};\\\", \\\"{x:555,y:736,t:1527009119672};\\\", \\\"{x:555,y:734,t:1527009119934};\\\", \\\"{x:554,y:725,t:1527009119941};\\\", \\\"{x:554,y:722,t:1527009119955};\\\", \\\"{x:553,y:718,t:1527009119971};\\\", \\\"{x:553,y:716,t:1527009119988};\\\", \\\"{x:555,y:716,t:1527009120357};\\\", \\\"{x:556,y:716,t:1527009120371};\\\", \\\"{x:558,y:717,t:1527009120388};\\\", \\\"{x:559,y:718,t:1527009120405};\\\", \\\"{x:559,y:719,t:1527009120429};\\\", \\\"{x:559,y:720,t:1527009120438};\\\", \\\"{x:560,y:719,t:1527009121470};\\\", \\\"{x:560,y:711,t:1527009121477};\\\", \\\"{x:560,y:708,t:1527009121489};\\\", \\\"{x:560,y:694,t:1527009121506};\\\", \\\"{x:560,y:683,t:1527009121523};\\\", \\\"{x:563,y:671,t:1527009121539};\\\", \\\"{x:567,y:664,t:1527009121556};\\\" ] }, { \\\"rt\\\": 38895, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 9, \\\"time_elapsed\\\": 325520, \\\"internal_node_id\\\": \\\"0.0-5.0-4.0\\\", \\\"subject\\\": \\\"R06S6\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"echo\\\", \\\"condition\\\": \\\"121\\\", \\\"scenario\\\": \\\"acme\\\", \\\"question\\\": \\\"midpoint\\\", \\\"q\\\": 5, \\\"clicks\\\": 2, \\\"explicit\\\": 1, \\\"impasse\\\": 2, \\\"axis\\\": \\\"Orthogonal-XInside-YFull\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 0, \\\"answer\\\": [ \\\"A\\\", \\\"F\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"U \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"\\\", \\\"block\\\": \\\"triangular_scaffolded\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:570,y:658,t:1527009121756};\\\", \\\"{x:570,y:656,t:1527009122350};\\\", \\\"{x:570,y:655,t:1527009122366};\\\", \\\"{x:571,y:654,t:1527009122373};\\\", \\\"{x:571,y:653,t:1527009122390};\\\", \\\"{x:571,y:652,t:1527009122414};\\\", \\\"{x:572,y:651,t:1527009122424};\\\", \\\"{x:572,y:650,t:1527009132614};\\\", \\\"{x:573,y:648,t:1527009132630};\\\", \\\"{x:580,y:645,t:1527009132647};\\\", \\\"{x:591,y:640,t:1527009132665};\\\", \\\"{x:601,y:636,t:1527009132680};\\\", \\\"{x:614,y:631,t:1527009132698};\\\", \\\"{x:633,y:627,t:1527009132714};\\\", \\\"{x:656,y:619,t:1527009132731};\\\", \\\"{x:683,y:614,t:1527009132746};\\\", \\\"{x:716,y:604,t:1527009132763};\\\", \\\"{x:762,y:595,t:1527009132780};\\\", \\\"{x:816,y:584,t:1527009132797};\\\", \\\"{x:919,y:566,t:1527009132816};\\\", \\\"{x:986,y:554,t:1527009132832};\\\", \\\"{x:1040,y:547,t:1527009132849};\\\", \\\"{x:1101,y:538,t:1527009132865};\\\", \\\"{x:1165,y:530,t:1527009132881};\\\", \\\"{x:1226,y:521,t:1527009132899};\\\", \\\"{x:1282,y:514,t:1527009132914};\\\", \\\"{x:1336,y:506,t:1527009132932};\\\", \\\"{x:1381,y:498,t:1527009132949};\\\", \\\"{x:1420,y:493,t:1527009132965};\\\", \\\"{x:1469,y:487,t:1527009132983};\\\", \\\"{x:1495,y:483,t:1527009132999};\\\", \\\"{x:1516,y:482,t:1527009133014};\\\", \\\"{x:1531,y:482,t:1527009133032};\\\", \\\"{x:1534,y:482,t:1527009133049};\\\", \\\"{x:1530,y:483,t:1527009133110};\\\", \\\"{x:1525,y:485,t:1527009133118};\\\", \\\"{x:1519,y:488,t:1527009133131};\\\", \\\"{x:1513,y:491,t:1527009133149};\\\", \\\"{x:1503,y:493,t:1527009133164};\\\", \\\"{x:1494,y:497,t:1527009133182};\\\", \\\"{x:1487,y:498,t:1527009133199};\\\", \\\"{x:1477,y:501,t:1527009133215};\\\", \\\"{x:1459,y:506,t:1527009133233};\\\", \\\"{x:1436,y:508,t:1527009133249};\\\", \\\"{x:1411,y:514,t:1527009133266};\\\", \\\"{x:1387,y:517,t:1527009133282};\\\", \\\"{x:1371,y:517,t:1527009133299};\\\", \\\"{x:1358,y:519,t:1527009133316};\\\", \\\"{x:1352,y:521,t:1527009133331};\\\", \\\"{x:1351,y:521,t:1527009133349};\\\", \\\"{x:1349,y:521,t:1527009133623};\\\", \\\"{x:1348,y:521,t:1527009133635};\\\", \\\"{x:1344,y:520,t:1527009133648};\\\", \\\"{x:1337,y:518,t:1527009133666};\\\", \\\"{x:1336,y:517,t:1527009133683};\\\", \\\"{x:1335,y:516,t:1527009133758};\\\", \\\"{x:1333,y:516,t:1527009133902};\\\", \\\"{x:1332,y:516,t:1527009133966};\\\", \\\"{x:1331,y:515,t:1527009133989};\\\", \\\"{x:1329,y:514,t:1527009133999};\\\", \\\"{x:1326,y:514,t:1527009134016};\\\", \\\"{x:1325,y:513,t:1527009134035};\\\", \\\"{x:1324,y:512,t:1527009134050};\\\", \\\"{x:1323,y:512,t:1527009134094};\\\", \\\"{x:1322,y:512,t:1527009134110};\\\", \\\"{x:1322,y:511,t:1527009147577};\\\", \\\"{x:1320,y:510,t:1527009149194};\\\", \\\"{x:1296,y:513,t:1527009149200};\\\", \\\"{x:1270,y:523,t:1527009149215};\\\", \\\"{x:1229,y:531,t:1527009149232};\\\", \\\"{x:1221,y:531,t:1527009149248};\\\", \\\"{x:1221,y:533,t:1527009149265};\\\", \\\"{x:1221,y:534,t:1527009149346};\\\", \\\"{x:1216,y:537,t:1527009149353};\\\", \\\"{x:1210,y:538,t:1527009149365};\\\", \\\"{x:1208,y:538,t:1527009149382};\\\", \\\"{x:1207,y:538,t:1527009149399};\\\", \\\"{x:1202,y:542,t:1527009149415};\\\", \\\"{x:1191,y:551,t:1527009149432};\\\", \\\"{x:1152,y:569,t:1527009149449};\\\", \\\"{x:1120,y:580,t:1527009149465};\\\", \\\"{x:1083,y:589,t:1527009149482};\\\", \\\"{x:1037,y:600,t:1527009149499};\\\", \\\"{x:981,y:608,t:1527009149515};\\\", \\\"{x:923,y:608,t:1527009149533};\\\", \\\"{x:859,y:608,t:1527009149550};\\\", \\\"{x:819,y:608,t:1527009149565};\\\", \\\"{x:777,y:603,t:1527009149598};\\\", \\\"{x:752,y:596,t:1527009149614};\\\", \\\"{x:723,y:591,t:1527009149632};\\\", \\\"{x:651,y:581,t:1527009149648};\\\", \\\"{x:594,y:568,t:1527009149664};\\\", \\\"{x:536,y:553,t:1527009149682};\\\", \\\"{x:482,y:536,t:1527009149699};\\\", \\\"{x:433,y:524,t:1527009149714};\\\", \\\"{x:385,y:516,t:1527009149732};\\\", \\\"{x:348,y:511,t:1527009149749};\\\", \\\"{x:318,y:506,t:1527009149766};\\\", \\\"{x:295,y:506,t:1527009149781};\\\", \\\"{x:279,y:506,t:1527009149798};\\\", \\\"{x:275,y:506,t:1527009149816};\\\", \\\"{x:277,y:506,t:1527009149864};\\\", \\\"{x:280,y:506,t:1527009149872};\\\", \\\"{x:281,y:506,t:1527009149881};\\\", \\\"{x:283,y:508,t:1527009149899};\\\", \\\"{x:287,y:508,t:1527009149915};\\\", \\\"{x:293,y:512,t:1527009149933};\\\", \\\"{x:299,y:512,t:1527009149948};\\\", \\\"{x:301,y:514,t:1527009149965};\\\", \\\"{x:304,y:514,t:1527009149983};\\\", \\\"{x:313,y:514,t:1527009149999};\\\", \\\"{x:330,y:518,t:1527009150016};\\\", \\\"{x:364,y:521,t:1527009150033};\\\", \\\"{x:382,y:524,t:1527009150050};\\\", \\\"{x:390,y:526,t:1527009150065};\\\", \\\"{x:397,y:528,t:1527009150081};\\\", \\\"{x:401,y:530,t:1527009150098};\\\", \\\"{x:404,y:532,t:1527009150115};\\\", \\\"{x:405,y:532,t:1527009150132};\\\", \\\"{x:406,y:533,t:1527009150217};\\\", \\\"{x:406,y:534,t:1527009150232};\\\", \\\"{x:406,y:535,t:1527009150249};\\\", \\\"{x:406,y:536,t:1527009150609};\\\", \\\"{x:406,y:537,t:1527009150616};\\\", \\\"{x:411,y:559,t:1527009150633};\\\", \\\"{x:421,y:584,t:1527009150648};\\\", \\\"{x:430,y:610,t:1527009150667};\\\", \\\"{x:438,y:628,t:1527009150683};\\\", \\\"{x:443,y:645,t:1527009150700};\\\", \\\"{x:453,y:660,t:1527009150716};\\\", \\\"{x:455,y:667,t:1527009150733};\\\", \\\"{x:455,y:669,t:1527009150760};\\\", \\\"{x:456,y:669,t:1527009150792};\\\", \\\"{x:457,y:671,t:1527009150960};\\\", \\\"{x:460,y:673,t:1527009150968};\\\", \\\"{x:461,y:678,t:1527009150983};\\\", \\\"{x:463,y:684,t:1527009151000};\\\", \\\"{x:468,y:689,t:1527009151016};\\\", \\\"{x:474,y:698,t:1527009151032};\\\", \\\"{x:474,y:701,t:1527009151049};\\\", \\\"{x:474,y:704,t:1527009151066};\\\", \\\"{x:476,y:708,t:1527009151083};\\\", \\\"{x:477,y:712,t:1527009151100};\\\", \\\"{x:478,y:716,t:1527009151118};\\\", \\\"{x:480,y:720,t:1527009151133};\\\", \\\"{x:481,y:723,t:1527009151150};\\\", \\\"{x:482,y:725,t:1527009151168};\\\", \\\"{x:483,y:727,t:1527009151182};\\\", \\\"{x:484,y:728,t:1527009151199};\\\", \\\"{x:485,y:729,t:1527009151217};\\\", \\\"{x:487,y:724,t:1527009154889};\\\", \\\"{x:490,y:717,t:1527009154903};\\\", \\\"{x:497,y:704,t:1527009154921};\\\", \\\"{x:499,y:697,t:1527009154936};\\\", \\\"{x:502,y:693,t:1527009154953};\\\", \\\"{x:503,y:690,t:1527009154969};\\\", \\\"{x:505,y:685,t:1527009154985};\\\", \\\"{x:505,y:680,t:1527009155002};\\\", \\\"{x:507,y:673,t:1527009155018};\\\", \\\"{x:512,y:660,t:1527009155037};\\\", \\\"{x:521,y:644,t:1527009155053};\\\", \\\"{x:530,y:630,t:1527009155069};\\\", \\\"{x:544,y:615,t:1527009155086};\\\", \\\"{x:561,y:601,t:1527009155102};\\\", \\\"{x:575,y:591,t:1527009155119};\\\", \\\"{x:584,y:581,t:1527009155136};\\\", \\\"{x:587,y:578,t:1527009155153};\\\", \\\"{x:589,y:575,t:1527009155169};\\\", \\\"{x:589,y:574,t:1527009155185};\\\", \\\"{x:589,y:573,t:1527009155202};\\\", \\\"{x:589,y:571,t:1527009155219};\\\", \\\"{x:589,y:570,t:1527009155237};\\\", \\\"{x:583,y:566,t:1527009155253};\\\", \\\"{x:574,y:565,t:1527009155270};\\\", \\\"{x:562,y:565,t:1527009155286};\\\", \\\"{x:554,y:565,t:1527009155303};\\\", \\\"{x:531,y:572,t:1527009155320};\\\", \\\"{x:515,y:578,t:1527009155336};\\\", \\\"{x:498,y:585,t:1527009155353};\\\", \\\"{x:480,y:594,t:1527009155371};\\\", \\\"{x:461,y:599,t:1527009155387};\\\", \\\"{x:447,y:602,t:1527009155403};\\\", \\\"{x:440,y:605,t:1527009155420};\\\", \\\"{x:437,y:606,t:1527009155437};\\\", \\\"{x:436,y:606,t:1527009155504};\\\", \\\"{x:431,y:604,t:1527009155520};\\\", \\\"{x:428,y:602,t:1527009155536};\\\", \\\"{x:427,y:601,t:1527009155560};\\\", \\\"{x:426,y:599,t:1527009155584};\\\", \\\"{x:425,y:597,t:1527009155592};\\\", \\\"{x:425,y:596,t:1527009155609};\\\", \\\"{x:423,y:594,t:1527009155621};\\\", \\\"{x:422,y:593,t:1527009155636};\\\", \\\"{x:420,y:591,t:1527009155653};\\\", \\\"{x:419,y:590,t:1527009155848};\\\", \\\"{x:417,y:589,t:1527009155864};\\\", \\\"{x:416,y:587,t:1527009155880};\\\", \\\"{x:415,y:584,t:1527009155888};\\\", \\\"{x:413,y:582,t:1527009155902};\\\", \\\"{x:410,y:577,t:1527009155919};\\\", \\\"{x:409,y:574,t:1527009155936};\\\", \\\"{x:408,y:573,t:1527009155976};\\\", \\\"{x:408,y:572,t:1527009155987};\\\", \\\"{x:407,y:572,t:1527009156025};\\\", \\\"{x:406,y:572,t:1527009156032};\\\", \\\"{x:410,y:572,t:1527009156224};\\\", \\\"{x:413,y:573,t:1527009156237};\\\", \\\"{x:420,y:577,t:1527009156254};\\\", \\\"{x:433,y:593,t:1527009156270};\\\", \\\"{x:446,y:612,t:1527009156287};\\\", \\\"{x:464,y:642,t:1527009156304};\\\", \\\"{x:476,y:665,t:1527009156320};\\\", \\\"{x:481,y:681,t:1527009156337};\\\", \\\"{x:484,y:690,t:1527009156354};\\\", \\\"{x:485,y:695,t:1527009156370};\\\", \\\"{x:485,y:697,t:1527009156386};\\\", \\\"{x:486,y:698,t:1527009156404};\\\", \\\"{x:487,y:700,t:1527009156420};\\\", \\\"{x:487,y:705,t:1527009156437};\\\", \\\"{x:487,y:712,t:1527009156454};\\\", \\\"{x:487,y:720,t:1527009156471};\\\", \\\"{x:487,y:729,t:1527009156487};\\\", \\\"{x:487,y:735,t:1527009156503};\\\", \\\"{x:487,y:733,t:1527009161233};\\\", \\\"{x:487,y:732,t:1527009161240};\\\", \\\"{x:488,y:728,t:1527009161257};\\\", \\\"{x:489,y:725,t:1527009161275};\\\", \\\"{x:489,y:723,t:1527009161291};\\\", \\\"{x:489,y:722,t:1527009161307};\\\", \\\"{x:490,y:721,t:1527009161325};\\\", \\\"{x:490,y:720,t:1527009161341};\\\", \\\"{x:491,y:720,t:1527009161357};\\\", \\\"{x:491,y:719,t:1527009161392};\\\", \\\"{x:491,y:718,t:1527009161408};\\\", \\\"{x:492,y:717,t:1527009161449};\\\", \\\"{x:493,y:715,t:1527009161457};\\\", \\\"{x:495,y:712,t:1527009161474};\\\", \\\"{x:497,y:708,t:1527009161491};\\\", \\\"{x:498,y:706,t:1527009161508};\\\", \\\"{x:502,y:701,t:1527009161524};\\\", \\\"{x:504,y:696,t:1527009161542};\\\", \\\"{x:508,y:688,t:1527009161558};\\\", \\\"{x:512,y:684,t:1527009161574};\\\", \\\"{x:515,y:678,t:1527009161591};\\\", \\\"{x:523,y:666,t:1527009161608};\\\", \\\"{x:527,y:658,t:1527009161624};\\\", \\\"{x:534,y:649,t:1527009161641};\\\", \\\"{x:539,y:642,t:1527009161658};\\\", \\\"{x:545,y:634,t:1527009161677};\\\", \\\"{x:551,y:626,t:1527009161690};\\\", \\\"{x:557,y:617,t:1527009161707};\\\", \\\"{x:562,y:611,t:1527009161723};\\\", \\\"{x:565,y:606,t:1527009161741};\\\" ] }, { \\\"rt\\\": 9331, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 10, \\\"time_elapsed\\\": 336063, \\\"internal_node_id\\\": \\\"0.0-6.0-0.0\\\", \\\"subject\\\": \\\"R06S6\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"echo\\\", \\\"condition\\\": \\\"121\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"duration\\\", \\\"q\\\": 6, \\\"clicks\\\": 3.5, \\\"explicit\\\": 1, \\\"impasse\\\": 2, \\\"axis\\\": \\\"Orthogonal-XInside-YFull\\\", \\\"correct\\\": 1, \\\"orth_correct\\\": 1, \\\"answer\\\": [ \\\"E\\\", \\\"G\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"\\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:577,y:591,t:1527009161862};\\\", \\\"{x:570,y:590,t:1527009162323};\\\", \\\"{x:568,y:590,t:1527009162329};\\\", \\\"{x:567,y:590,t:1527009162341};\\\", \\\"{x:565,y:590,t:1527009162375};\\\", \\\"{x:568,y:584,t:1527009162568};\\\", \\\"{x:570,y:576,t:1527009162575};\\\", \\\"{x:578,y:560,t:1527009162593};\\\", \\\"{x:585,y:545,t:1527009162609};\\\", \\\"{x:591,y:527,t:1527009162625};\\\", \\\"{x:597,y:512,t:1527009162643};\\\", \\\"{x:600,y:504,t:1527009162658};\\\", \\\"{x:601,y:499,t:1527009162675};\\\", \\\"{x:602,y:494,t:1527009162692};\\\", \\\"{x:603,y:488,t:1527009162708};\\\", \\\"{x:603,y:484,t:1527009162725};\\\", \\\"{x:604,y:480,t:1527009162742};\\\", \\\"{x:604,y:477,t:1527009162759};\\\", \\\"{x:604,y:475,t:1527009162775};\\\", \\\"{x:604,y:474,t:1527009162791};\\\", \\\"{x:601,y:474,t:1527009163256};\\\", \\\"{x:597,y:474,t:1527009163264};\\\", \\\"{x:593,y:475,t:1527009163276};\\\", \\\"{x:585,y:480,t:1527009163292};\\\", \\\"{x:578,y:481,t:1527009163308};\\\", \\\"{x:570,y:485,t:1527009163326};\\\", \\\"{x:561,y:489,t:1527009163342};\\\", \\\"{x:555,y:490,t:1527009163359};\\\", \\\"{x:549,y:490,t:1527009163375};\\\", \\\"{x:542,y:491,t:1527009163391};\\\", \\\"{x:534,y:492,t:1527009163407};\\\", \\\"{x:530,y:493,t:1527009163425};\\\", \\\"{x:527,y:493,t:1527009163441};\\\", \\\"{x:526,y:494,t:1527009163459};\\\", \\\"{x:527,y:496,t:1527009163808};\\\", \\\"{x:535,y:499,t:1527009163826};\\\", \\\"{x:543,y:501,t:1527009163842};\\\", \\\"{x:548,y:502,t:1527009163859};\\\", \\\"{x:551,y:502,t:1527009163876};\\\", \\\"{x:555,y:504,t:1527009163891};\\\", \\\"{x:561,y:504,t:1527009163908};\\\", \\\"{x:566,y:504,t:1527009163926};\\\", \\\"{x:566,y:503,t:1527009163942};\\\", \\\"{x:567,y:503,t:1527009164625};\\\", \\\"{x:567,y:505,t:1527009164641};\\\", \\\"{x:566,y:507,t:1527009164658};\\\", \\\"{x:564,y:508,t:1527009164674};\\\", \\\"{x:563,y:509,t:1527009164691};\\\", \\\"{x:561,y:509,t:1527009164708};\\\", \\\"{x:560,y:511,t:1527009164724};\\\", \\\"{x:559,y:511,t:1527009164741};\\\", \\\"{x:557,y:512,t:1527009164759};\\\", \\\"{x:555,y:513,t:1527009164776};\\\", \\\"{x:555,y:514,t:1527009164791};\\\", \\\"{x:553,y:514,t:1527009164807};\\\", \\\"{x:553,y:515,t:1527009164824};\\\", \\\"{x:552,y:515,t:1527009164841};\\\", \\\"{x:551,y:516,t:1527009166273};\\\", \\\"{x:544,y:526,t:1527009166291};\\\", \\\"{x:540,y:534,t:1527009166307};\\\", \\\"{x:533,y:545,t:1527009166328};\\\", \\\"{x:531,y:548,t:1527009166344};\\\", \\\"{x:530,y:549,t:1527009166362};\\\", \\\"{x:529,y:550,t:1527009166379};\\\", \\\"{x:528,y:551,t:1527009166395};\\\", \\\"{x:527,y:551,t:1527009166416};\\\", \\\"{x:525,y:551,t:1527009166537};\\\", \\\"{x:522,y:551,t:1527009166545};\\\", \\\"{x:519,y:551,t:1527009166561};\\\", \\\"{x:523,y:550,t:1527009166624};\\\", \\\"{x:528,y:547,t:1527009166632};\\\", \\\"{x:533,y:546,t:1527009166645};\\\", \\\"{x:541,y:542,t:1527009166661};\\\", \\\"{x:553,y:536,t:1527009166679};\\\", \\\"{x:561,y:532,t:1527009166695};\\\", \\\"{x:566,y:531,t:1527009166712};\\\", \\\"{x:569,y:528,t:1527009166728};\\\", \\\"{x:572,y:528,t:1527009166745};\\\", \\\"{x:574,y:527,t:1527009166761};\\\", \\\"{x:579,y:524,t:1527009166779};\\\", \\\"{x:583,y:522,t:1527009166795};\\\", \\\"{x:586,y:520,t:1527009166811};\\\", \\\"{x:590,y:516,t:1527009166829};\\\", \\\"{x:592,y:512,t:1527009166845};\\\", \\\"{x:596,y:505,t:1527009166862};\\\", \\\"{x:600,y:498,t:1527009166878};\\\", \\\"{x:605,y:493,t:1527009166895};\\\", \\\"{x:609,y:488,t:1527009166912};\\\", \\\"{x:612,y:488,t:1527009166928};\\\", \\\"{x:613,y:486,t:1527009166945};\\\", \\\"{x:615,y:486,t:1527009167096};\\\", \\\"{x:615,y:486,t:1527009167162};\\\", \\\"{x:616,y:486,t:1527009167232};\\\", \\\"{x:615,y:488,t:1527009167250};\\\", \\\"{x:615,y:492,t:1527009167264};\\\", \\\"{x:615,y:495,t:1527009167279};\\\", \\\"{x:615,y:499,t:1527009167295};\\\", \\\"{x:615,y:503,t:1527009167312};\\\", \\\"{x:615,y:505,t:1527009167329};\\\", \\\"{x:615,y:506,t:1527009167345};\\\", \\\"{x:615,y:507,t:1527009167362};\\\", \\\"{x:615,y:508,t:1527009167408};\\\", \\\"{x:617,y:510,t:1527009167431};\\\", \\\"{x:617,y:510,t:1527009167505};\\\", \\\"{x:618,y:510,t:1527009167583};\\\", \\\"{x:621,y:510,t:1527009167595};\\\", \\\"{x:630,y:513,t:1527009167612};\\\", \\\"{x:636,y:514,t:1527009167629};\\\", \\\"{x:650,y:516,t:1527009167646};\\\", \\\"{x:668,y:520,t:1527009167663};\\\", \\\"{x:692,y:526,t:1527009167679};\\\", \\\"{x:714,y:530,t:1527009167695};\\\", \\\"{x:722,y:531,t:1527009167712};\\\", \\\"{x:731,y:534,t:1527009167730};\\\", \\\"{x:743,y:538,t:1527009167746};\\\", \\\"{x:756,y:541,t:1527009167762};\\\", \\\"{x:766,y:543,t:1527009167779};\\\", \\\"{x:775,y:545,t:1527009167796};\\\", \\\"{x:783,y:546,t:1527009167812};\\\", \\\"{x:790,y:548,t:1527009167829};\\\", \\\"{x:794,y:548,t:1527009167846};\\\", \\\"{x:800,y:550,t:1527009167862};\\\", \\\"{x:806,y:550,t:1527009167880};\\\", \\\"{x:813,y:552,t:1527009167896};\\\", \\\"{x:819,y:552,t:1527009167913};\\\", \\\"{x:824,y:553,t:1527009167930};\\\", \\\"{x:825,y:553,t:1527009167946};\\\", \\\"{x:827,y:553,t:1527009168048};\\\", \\\"{x:828,y:553,t:1527009168112};\\\", \\\"{x:829,y:553,t:1527009168127};\\\", \\\"{x:830,y:553,t:1527009168136};\\\", \\\"{x:830,y:553,t:1527009168168};\\\", \\\"{x:829,y:553,t:1527009168280};\\\", \\\"{x:827,y:553,t:1527009168295};\\\", \\\"{x:825,y:555,t:1527009168314};\\\", \\\"{x:821,y:555,t:1527009168329};\\\", \\\"{x:814,y:557,t:1527009168347};\\\", \\\"{x:806,y:560,t:1527009168363};\\\", \\\"{x:792,y:564,t:1527009168380};\\\", \\\"{x:776,y:569,t:1527009168396};\\\", \\\"{x:761,y:577,t:1527009168414};\\\", \\\"{x:742,y:591,t:1527009168430};\\\", \\\"{x:721,y:602,t:1527009168448};\\\", \\\"{x:707,y:613,t:1527009168463};\\\", \\\"{x:684,y:633,t:1527009168480};\\\", \\\"{x:673,y:652,t:1527009168496};\\\", \\\"{x:661,y:673,t:1527009168513};\\\", \\\"{x:654,y:685,t:1527009168529};\\\", \\\"{x:657,y:685,t:1527009168559};\\\", \\\"{x:667,y:684,t:1527009168567};\\\", \\\"{x:680,y:678,t:1527009168579};\\\", \\\"{x:696,y:670,t:1527009168596};\\\", \\\"{x:712,y:657,t:1527009168613};\\\", \\\"{x:729,y:643,t:1527009168630};\\\", \\\"{x:748,y:628,t:1527009168647};\\\", \\\"{x:764,y:616,t:1527009168663};\\\", \\\"{x:780,y:602,t:1527009168680};\\\", \\\"{x:784,y:598,t:1527009168697};\\\", \\\"{x:787,y:595,t:1527009168713};\\\", \\\"{x:791,y:592,t:1527009168731};\\\", \\\"{x:795,y:590,t:1527009168746};\\\", \\\"{x:800,y:587,t:1527009168763};\\\", \\\"{x:803,y:584,t:1527009168781};\\\", \\\"{x:807,y:580,t:1527009168796};\\\", \\\"{x:812,y:575,t:1527009168813};\\\", \\\"{x:820,y:564,t:1527009168830};\\\", \\\"{x:826,y:555,t:1527009168848};\\\", \\\"{x:836,y:544,t:1527009168863};\\\", \\\"{x:840,y:539,t:1527009168880};\\\", \\\"{x:847,y:535,t:1527009168897};\\\", \\\"{x:854,y:531,t:1527009168913};\\\", \\\"{x:859,y:528,t:1527009168930};\\\", \\\"{x:861,y:527,t:1527009168947};\\\", \\\"{x:861,y:526,t:1527009168963};\\\", \\\"{x:860,y:526,t:1527009169177};\\\", \\\"{x:859,y:526,t:1527009169256};\\\", \\\"{x:858,y:526,t:1527009169265};\\\", \\\"{x:857,y:526,t:1527009169288};\\\", \\\"{x:856,y:527,t:1527009169304};\\\", \\\"{x:854,y:528,t:1527009169345};\\\", \\\"{x:853,y:530,t:1527009169365};\\\", \\\"{x:850,y:534,t:1527009169380};\\\", \\\"{x:847,y:539,t:1527009169397};\\\", \\\"{x:844,y:542,t:1527009169414};\\\", \\\"{x:838,y:548,t:1527009169430};\\\", \\\"{x:836,y:550,t:1527009169447};\\\", \\\"{x:835,y:552,t:1527009169463};\\\", \\\"{x:835,y:550,t:1527009170018};\\\", \\\"{x:834,y:549,t:1527009170560};\\\", \\\"{x:828,y:551,t:1527009170567};\\\", \\\"{x:823,y:556,t:1527009170582};\\\", \\\"{x:801,y:573,t:1527009170599};\\\", \\\"{x:753,y:606,t:1527009170615};\\\", \\\"{x:662,y:663,t:1527009170632};\\\", \\\"{x:572,y:711,t:1527009170649};\\\", \\\"{x:519,y:739,t:1527009170665};\\\", \\\"{x:508,y:749,t:1527009170681};\\\", \\\"{x:477,y:754,t:1527009170698};\\\", \\\"{x:439,y:762,t:1527009170716};\\\", \\\"{x:420,y:768,t:1527009170731};\\\", \\\"{x:411,y:771,t:1527009170749};\\\", \\\"{x:405,y:774,t:1527009170765};\\\", \\\"{x:407,y:774,t:1527009170816};\\\", \\\"{x:409,y:772,t:1527009170832};\\\", \\\"{x:424,y:762,t:1527009170849};\\\", \\\"{x:429,y:758,t:1527009170865};\\\", \\\"{x:435,y:753,t:1527009170882};\\\", \\\"{x:444,y:747,t:1527009170899};\\\", \\\"{x:451,y:744,t:1527009170916};\\\", \\\"{x:458,y:741,t:1527009170931};\\\", \\\"{x:464,y:738,t:1527009170948};\\\", \\\"{x:469,y:736,t:1527009170966};\\\", \\\"{x:473,y:734,t:1527009170981};\\\", \\\"{x:476,y:731,t:1527009170998};\\\", \\\"{x:483,y:728,t:1527009171016};\\\", \\\"{x:484,y:728,t:1527009171031};\\\", \\\"{x:483,y:728,t:1527009171399};\\\", \\\"{x:473,y:728,t:1527009171416};\\\", \\\"{x:466,y:730,t:1527009171432};\\\", \\\"{x:457,y:731,t:1527009171448};\\\", \\\"{x:450,y:731,t:1527009171465};\\\", \\\"{x:441,y:730,t:1527009171482};\\\", \\\"{x:429,y:722,t:1527009171498};\\\", \\\"{x:425,y:716,t:1527009171516};\\\", \\\"{x:423,y:715,t:1527009171532};\\\", \\\"{x:423,y:714,t:1527009171551};\\\", \\\"{x:419,y:714,t:1527009171633};\\\", \\\"{x:419,y:713,t:1527009171985};\\\", \\\"{x:419,y:712,t:1527009172000};\\\", \\\"{x:419,y:710,t:1527009172016};\\\", \\\"{x:419,y:709,t:1527009172032};\\\", \\\"{x:419,y:706,t:1527009172049};\\\", \\\"{x:420,y:706,t:1527009172066};\\\", \\\"{x:420,y:705,t:1527009172082};\\\", \\\"{x:420,y:704,t:1527009172099};\\\", \\\"{x:420,y:702,t:1527009172117};\\\", \\\"{x:421,y:700,t:1527009172144};\\\", \\\"{x:422,y:699,t:1527009172168};\\\", \\\"{x:423,y:698,t:1527009172184};\\\", \\\"{x:424,y:696,t:1527009172200};\\\", \\\"{x:431,y:683,t:1527009172260};\\\", \\\"{x:432,y:681,t:1527009172266};\\\", \\\"{x:435,y:674,t:1527009172282};\\\", \\\"{x:440,y:661,t:1527009172299};\\\", \\\"{x:450,y:642,t:1527009172316};\\\", \\\"{x:457,y:615,t:1527009172333};\\\" ] }, { \\\"rt\\\": 20771, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 11, \\\"time_elapsed\\\": 358153, \\\"internal_node_id\\\": \\\"0.0-6.0-1.0\\\", \\\"subject\\\": \\\"R06S6\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"echo\\\", \\\"condition\\\": \\\"121\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"duration+starts\\\", \\\"q\\\": 7, \\\"clicks\\\": 2.5, \\\"explicit\\\": 1, \\\"impasse\\\": 2, \\\"axis\\\": \\\"Orthogonal-XInside-YFull\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 1, \\\"answer\\\": [ \\\"F\\\", \\\"B\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-C \\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:458,y:596,t:1527009172510};\\\", \\\"{x:458,y:595,t:1527009172920};\\\", \\\"{x:458,y:592,t:1527009172933};\\\", \\\"{x:462,y:585,t:1527009172950};\\\", \\\"{x:463,y:575,t:1527009172966};\\\", \\\"{x:466,y:561,t:1527009172983};\\\", \\\"{x:467,y:553,t:1527009173000};\\\", \\\"{x:475,y:503,t:1527009173098};\\\", \\\"{x:475,y:501,t:1527009173116};\\\", \\\"{x:475,y:499,t:1527009173133};\\\", \\\"{x:475,y:498,t:1527009173150};\\\", \\\"{x:475,y:496,t:1527009173167};\\\", \\\"{x:471,y:494,t:1527009173183};\\\", \\\"{x:465,y:492,t:1527009173200};\\\", \\\"{x:459,y:489,t:1527009173217};\\\", \\\"{x:450,y:485,t:1527009173233};\\\", \\\"{x:442,y:483,t:1527009173251};\\\", \\\"{x:437,y:482,t:1527009173266};\\\", \\\"{x:433,y:481,t:1527009173283};\\\", \\\"{x:427,y:479,t:1527009173301};\\\", \\\"{x:425,y:479,t:1527009173318};\\\", \\\"{x:420,y:479,t:1527009173333};\\\", \\\"{x:415,y:479,t:1527009173351};\\\", \\\"{x:412,y:479,t:1527009173366};\\\", \\\"{x:409,y:480,t:1527009173383};\\\", \\\"{x:406,y:481,t:1527009173440};\\\", \\\"{x:405,y:481,t:1527009173451};\\\", \\\"{x:402,y:483,t:1527009173468};\\\", \\\"{x:398,y:486,t:1527009173483};\\\", \\\"{x:387,y:489,t:1527009173501};\\\", \\\"{x:378,y:492,t:1527009173518};\\\", \\\"{x:368,y:495,t:1527009173534};\\\", \\\"{x:361,y:497,t:1527009173550};\\\", \\\"{x:356,y:498,t:1527009173567};\\\", \\\"{x:354,y:498,t:1527009173583};\\\", \\\"{x:353,y:498,t:1527009173607};\\\", \\\"{x:354,y:498,t:1527009173911};\\\", \\\"{x:355,y:498,t:1527009173928};\\\", \\\"{x:356,y:498,t:1527009173936};\\\", \\\"{x:357,y:498,t:1527009173951};\\\", \\\"{x:359,y:496,t:1527009173975};\\\", \\\"{x:360,y:496,t:1527009174000};\\\", \\\"{x:360,y:495,t:1527009174007};\\\", \\\"{x:362,y:495,t:1527009174017};\\\", \\\"{x:364,y:493,t:1527009174034};\\\", \\\"{x:367,y:491,t:1527009174051};\\\", \\\"{x:370,y:489,t:1527009174068};\\\", \\\"{x:372,y:487,t:1527009174084};\\\", \\\"{x:374,y:485,t:1527009174101};\\\", \\\"{x:375,y:485,t:1527009174118};\\\", \\\"{x:377,y:484,t:1527009174133};\\\", \\\"{x:378,y:483,t:1527009174152};\\\", \\\"{x:378,y:482,t:1527009174175};\\\", \\\"{x:379,y:482,t:1527009174208};\\\", \\\"{x:381,y:482,t:1527009174232};\\\", \\\"{x:382,y:481,t:1527009174240};\\\", \\\"{x:383,y:481,t:1527009174250};\\\", \\\"{x:385,y:479,t:1527009174267};\\\", \\\"{x:388,y:478,t:1527009174283};\\\", \\\"{x:392,y:476,t:1527009174300};\\\", \\\"{x:397,y:475,t:1527009174318};\\\", \\\"{x:403,y:474,t:1527009174334};\\\", \\\"{x:407,y:472,t:1527009174350};\\\", \\\"{x:410,y:471,t:1527009174367};\\\", \\\"{x:411,y:471,t:1527009174384};\\\", \\\"{x:412,y:471,t:1527009174415};\\\", \\\"{x:413,y:471,t:1527009174520};\\\", \\\"{x:414,y:471,t:1527009174640};\\\", \\\"{x:415,y:471,t:1527009175241};\\\", \\\"{x:417,y:471,t:1527009175250};\\\", \\\"{x:422,y:471,t:1527009175268};\\\", \\\"{x:430,y:472,t:1527009175283};\\\", \\\"{x:437,y:473,t:1527009175301};\\\", \\\"{x:447,y:474,t:1527009175317};\\\", \\\"{x:457,y:475,t:1527009175333};\\\", \\\"{x:463,y:476,t:1527009175350};\\\", \\\"{x:472,y:478,t:1527009175367};\\\", \\\"{x:477,y:479,t:1527009175383};\\\", \\\"{x:479,y:479,t:1527009175401};\\\", \\\"{x:482,y:479,t:1527009175417};\\\", \\\"{x:484,y:479,t:1527009175434};\\\", \\\"{x:484,y:480,t:1527009175450};\\\", \\\"{x:486,y:480,t:1527009175467};\\\", \\\"{x:488,y:480,t:1527009175483};\\\", \\\"{x:490,y:480,t:1527009175501};\\\", \\\"{x:492,y:480,t:1527009175518};\\\", \\\"{x:494,y:480,t:1527009175534};\\\", \\\"{x:495,y:480,t:1527009175551};\\\", \\\"{x:503,y:480,t:1527009175568};\\\", \\\"{x:511,y:480,t:1527009175583};\\\", \\\"{x:520,y:480,t:1527009175600};\\\", \\\"{x:526,y:480,t:1527009175618};\\\", \\\"{x:531,y:482,t:1527009175634};\\\", \\\"{x:538,y:482,t:1527009175651};\\\", \\\"{x:543,y:484,t:1527009175668};\\\", \\\"{x:549,y:484,t:1527009175684};\\\", \\\"{x:553,y:485,t:1527009175701};\\\", \\\"{x:556,y:485,t:1527009175717};\\\", \\\"{x:558,y:486,t:1527009175734};\\\", \\\"{x:559,y:486,t:1527009175750};\\\", \\\"{x:560,y:486,t:1527009175784};\\\", \\\"{x:560,y:487,t:1527009176040};\\\", \\\"{x:560,y:488,t:1527009176051};\\\", \\\"{x:560,y:489,t:1527009176071};\\\", \\\"{x:558,y:490,t:1527009176088};\\\", \\\"{x:557,y:491,t:1527009176103};\\\", \\\"{x:555,y:491,t:1527009176127};\\\", \\\"{x:555,y:492,t:1527009176152};\\\", \\\"{x:554,y:492,t:1527009176264};\\\", \\\"{x:554,y:493,t:1527009176464};\\\", \\\"{x:557,y:493,t:1527009176471};\\\", \\\"{x:559,y:493,t:1527009176487};\\\", \\\"{x:565,y:494,t:1527009176503};\\\", \\\"{x:574,y:493,t:1527009176520};\\\", \\\"{x:585,y:490,t:1527009176535};\\\", \\\"{x:591,y:488,t:1527009176553};\\\", \\\"{x:596,y:487,t:1527009176570};\\\", \\\"{x:603,y:485,t:1527009176587};\\\", \\\"{x:607,y:485,t:1527009176602};\\\", \\\"{x:611,y:485,t:1527009176620};\\\", \\\"{x:615,y:485,t:1527009176637};\\\", \\\"{x:621,y:485,t:1527009176653};\\\", \\\"{x:627,y:485,t:1527009176670};\\\", \\\"{x:633,y:485,t:1527009176687};\\\", \\\"{x:640,y:485,t:1527009176702};\\\", \\\"{x:654,y:485,t:1527009176720};\\\", \\\"{x:662,y:486,t:1527009176737};\\\", \\\"{x:674,y:486,t:1527009176753};\\\", \\\"{x:689,y:490,t:1527009176771};\\\", \\\"{x:702,y:492,t:1527009176787};\\\", \\\"{x:722,y:497,t:1527009176803};\\\", \\\"{x:740,y:502,t:1527009176820};\\\", \\\"{x:752,y:506,t:1527009176837};\\\", \\\"{x:762,y:510,t:1527009176852};\\\", \\\"{x:768,y:512,t:1527009176869};\\\", \\\"{x:772,y:513,t:1527009176886};\\\", \\\"{x:773,y:514,t:1527009176902};\\\", \\\"{x:774,y:515,t:1527009176920};\\\", \\\"{x:774,y:516,t:1527009176944};\\\", \\\"{x:774,y:517,t:1527009176968};\\\", \\\"{x:774,y:518,t:1527009176985};\\\", \\\"{x:774,y:519,t:1527009177016};\\\", \\\"{x:774,y:520,t:1527009177048};\\\", \\\"{x:774,y:521,t:1527009177112};\\\", \\\"{x:774,y:523,t:1527009177337};\\\", \\\"{x:772,y:524,t:1527009177354};\\\", \\\"{x:772,y:526,t:1527009177372};\\\", \\\"{x:772,y:527,t:1527009177387};\\\", \\\"{x:776,y:531,t:1527009177403};\\\", \\\"{x:782,y:531,t:1527009177512};\\\", \\\"{x:783,y:531,t:1527009177528};\\\", \\\"{x:784,y:531,t:1527009177552};\\\", \\\"{x:785,y:532,t:1527009177559};\\\", \\\"{x:787,y:533,t:1527009177570};\\\", \\\"{x:792,y:535,t:1527009177587};\\\", \\\"{x:797,y:537,t:1527009177604};\\\", \\\"{x:802,y:540,t:1527009177620};\\\", \\\"{x:805,y:543,t:1527009177637};\\\", \\\"{x:810,y:545,t:1527009177653};\\\", \\\"{x:824,y:549,t:1527009177671};\\\", \\\"{x:836,y:549,t:1527009177687};\\\", \\\"{x:854,y:549,t:1527009177704};\\\", \\\"{x:867,y:549,t:1527009177720};\\\", \\\"{x:872,y:550,t:1527009177737};\\\", \\\"{x:875,y:551,t:1527009177754};\\\", \\\"{x:876,y:552,t:1527009177770};\\\", \\\"{x:879,y:554,t:1527009177787};\\\", \\\"{x:880,y:554,t:1527009177824};\\\", \\\"{x:880,y:555,t:1527009177848};\\\", \\\"{x:881,y:556,t:1527009177865};\\\", \\\"{x:881,y:557,t:1527009177903};\\\", \\\"{x:881,y:558,t:1527009177952};\\\", \\\"{x:883,y:560,t:1527009178248};\\\", \\\"{x:884,y:560,t:1527009178264};\\\", \\\"{x:887,y:561,t:1527009178272};\\\", \\\"{x:892,y:563,t:1527009178289};\\\", \\\"{x:901,y:567,t:1527009178304};\\\", \\\"{x:909,y:570,t:1527009178320};\\\", \\\"{x:914,y:572,t:1527009178337};\\\", \\\"{x:917,y:573,t:1527009178353};\\\", \\\"{x:918,y:573,t:1527009178371};\\\", \\\"{x:920,y:573,t:1527009178388};\\\", \\\"{x:921,y:573,t:1527009178407};\\\", \\\"{x:923,y:574,t:1527009178420};\\\", \\\"{x:924,y:575,t:1527009178440};\\\", \\\"{x:925,y:575,t:1527009178463};\\\", \\\"{x:926,y:575,t:1527009178480};\\\", \\\"{x:927,y:575,t:1527009178487};\\\", \\\"{x:929,y:576,t:1527009178505};\\\", \\\"{x:930,y:576,t:1527009178520};\\\", \\\"{x:932,y:576,t:1527009178608};\\\", \\\"{x:933,y:576,t:1527009178632};\\\", \\\"{x:934,y:578,t:1527009178639};\\\", \\\"{x:935,y:578,t:1527009178656};\\\", \\\"{x:936,y:578,t:1527009178672};\\\", \\\"{x:938,y:579,t:1527009178687};\\\", \\\"{x:939,y:580,t:1527009178704};\\\", \\\"{x:941,y:580,t:1527009178727};\\\", \\\"{x:942,y:581,t:1527009178759};\\\", \\\"{x:944,y:581,t:1527009178824};\\\", \\\"{x:945,y:582,t:1527009178838};\\\", \\\"{x:946,y:583,t:1527009178896};\\\", \\\"{x:947,y:583,t:1527009178912};\\\", \\\"{x:949,y:584,t:1527009178968};\\\", \\\"{x:950,y:585,t:1527009179000};\\\", \\\"{x:952,y:585,t:1527009179176};\\\", \\\"{x:954,y:586,t:1527009179187};\\\", \\\"{x:960,y:589,t:1527009179205};\\\", \\\"{x:967,y:592,t:1527009179221};\\\", \\\"{x:979,y:599,t:1527009179239};\\\", \\\"{x:998,y:605,t:1527009179255};\\\", \\\"{x:1025,y:619,t:1527009179272};\\\", \\\"{x:1035,y:625,t:1527009179289};\\\", \\\"{x:1041,y:632,t:1527009179304};\\\", \\\"{x:1046,y:638,t:1527009179322};\\\", \\\"{x:1049,y:642,t:1527009179338};\\\", \\\"{x:1052,y:646,t:1527009179355};\\\", \\\"{x:1052,y:649,t:1527009179372};\\\", \\\"{x:1053,y:653,t:1527009179388};\\\", \\\"{x:1054,y:659,t:1527009179405};\\\", \\\"{x:1057,y:665,t:1527009179422};\\\", \\\"{x:1059,y:669,t:1527009179439};\\\", \\\"{x:1063,y:673,t:1527009179455};\\\", \\\"{x:1070,y:681,t:1527009179472};\\\", \\\"{x:1075,y:687,t:1527009179489};\\\", \\\"{x:1079,y:692,t:1527009179505};\\\", \\\"{x:1079,y:695,t:1527009179522};\\\", \\\"{x:1079,y:696,t:1527009179539};\\\", \\\"{x:1079,y:697,t:1527009179568};\\\", \\\"{x:1079,y:696,t:1527009180088};\\\", \\\"{x:1080,y:696,t:1527009180106};\\\", \\\"{x:1082,y:692,t:1527009180123};\\\", \\\"{x:1086,y:691,t:1527009180140};\\\", \\\"{x:1096,y:690,t:1527009180156};\\\", \\\"{x:1108,y:690,t:1527009180173};\\\", \\\"{x:1122,y:690,t:1527009180189};\\\", \\\"{x:1144,y:690,t:1527009180207};\\\", \\\"{x:1161,y:693,t:1527009180223};\\\", \\\"{x:1173,y:693,t:1527009180239};\\\", \\\"{x:1195,y:693,t:1527009180256};\\\", \\\"{x:1211,y:693,t:1527009180273};\\\", \\\"{x:1226,y:692,t:1527009180289};\\\", \\\"{x:1242,y:686,t:1527009180306};\\\", \\\"{x:1256,y:682,t:1527009180323};\\\", \\\"{x:1273,y:678,t:1527009180339};\\\", \\\"{x:1286,y:675,t:1527009180356};\\\", \\\"{x:1298,y:671,t:1527009180373};\\\", \\\"{x:1308,y:667,t:1527009180389};\\\", \\\"{x:1315,y:665,t:1527009180406};\\\", \\\"{x:1323,y:663,t:1527009180423};\\\", \\\"{x:1330,y:659,t:1527009180440};\\\", \\\"{x:1339,y:655,t:1527009180457};\\\", \\\"{x:1345,y:653,t:1527009180473};\\\", \\\"{x:1357,y:649,t:1527009180490};\\\", \\\"{x:1370,y:645,t:1527009180506};\\\", \\\"{x:1386,y:640,t:1527009180523};\\\", \\\"{x:1400,y:636,t:1527009180540};\\\", \\\"{x:1405,y:635,t:1527009180556};\\\", \\\"{x:1411,y:634,t:1527009180573};\\\", \\\"{x:1414,y:634,t:1527009180590};\\\", \\\"{x:1418,y:634,t:1527009180606};\\\", \\\"{x:1423,y:634,t:1527009180623};\\\", \\\"{x:1438,y:633,t:1527009180640};\\\", \\\"{x:1442,y:632,t:1527009180656};\\\", \\\"{x:1444,y:631,t:1527009180676};\\\", \\\"{x:1444,y:630,t:1527009183801};\\\", \\\"{x:1443,y:629,t:1527009186297};\\\", \\\"{x:1440,y:628,t:1527009187946};\\\", \\\"{x:1428,y:624,t:1527009187961};\\\", \\\"{x:1408,y:624,t:1527009187978};\\\", \\\"{x:1374,y:630,t:1527009187996};\\\", \\\"{x:1318,y:639,t:1527009188012};\\\", \\\"{x:1265,y:640,t:1527009188028};\\\", \\\"{x:1211,y:642,t:1527009188046};\\\", \\\"{x:1179,y:642,t:1527009188062};\\\", \\\"{x:1149,y:642,t:1527009188078};\\\", \\\"{x:1125,y:642,t:1527009188096};\\\", \\\"{x:1108,y:642,t:1527009188111};\\\", \\\"{x:1078,y:642,t:1527009188129};\\\", \\\"{x:1057,y:642,t:1527009188146};\\\", \\\"{x:1021,y:642,t:1527009188162};\\\", \\\"{x:985,y:642,t:1527009188179};\\\", \\\"{x:944,y:645,t:1527009188195};\\\", \\\"{x:894,y:645,t:1527009188213};\\\", \\\"{x:863,y:645,t:1527009188228};\\\", \\\"{x:840,y:645,t:1527009188245};\\\", \\\"{x:833,y:645,t:1527009188262};\\\", \\\"{x:832,y:645,t:1527009188279};\\\", \\\"{x:830,y:645,t:1527009188295};\\\", \\\"{x:829,y:645,t:1527009188311};\\\", \\\"{x:827,y:645,t:1527009188328};\\\", \\\"{x:821,y:643,t:1527009188345};\\\", \\\"{x:815,y:641,t:1527009188362};\\\", \\\"{x:813,y:640,t:1527009188378};\\\", \\\"{x:808,y:639,t:1527009188395};\\\", \\\"{x:807,y:638,t:1527009188412};\\\", \\\"{x:800,y:636,t:1527009188428};\\\", \\\"{x:796,y:634,t:1527009188445};\\\", \\\"{x:791,y:633,t:1527009188462};\\\", \\\"{x:789,y:631,t:1527009188479};\\\", \\\"{x:788,y:630,t:1527009188543};\\\", \\\"{x:787,y:628,t:1527009188567};\\\", \\\"{x:787,y:627,t:1527009188583};\\\", \\\"{x:787,y:625,t:1527009188596};\\\", \\\"{x:787,y:624,t:1527009188612};\\\", \\\"{x:787,y:622,t:1527009188629};\\\", \\\"{x:787,y:621,t:1527009188647};\\\", \\\"{x:787,y:620,t:1527009188664};\\\", \\\"{x:787,y:619,t:1527009188679};\\\", \\\"{x:786,y:618,t:1527009188695};\\\", \\\"{x:785,y:615,t:1527009188712};\\\", \\\"{x:781,y:611,t:1527009188729};\\\", \\\"{x:773,y:605,t:1527009188746};\\\", \\\"{x:762,y:600,t:1527009188763};\\\", \\\"{x:750,y:592,t:1527009188779};\\\", \\\"{x:738,y:587,t:1527009188796};\\\", \\\"{x:733,y:584,t:1527009188811};\\\", \\\"{x:731,y:584,t:1527009188839};\\\", \\\"{x:731,y:583,t:1527009188855};\\\", \\\"{x:730,y:582,t:1527009188871};\\\", \\\"{x:729,y:581,t:1527009188887};\\\", \\\"{x:727,y:579,t:1527009188895};\\\", \\\"{x:724,y:575,t:1527009188912};\\\", \\\"{x:721,y:572,t:1527009188930};\\\", \\\"{x:715,y:565,t:1527009188946};\\\", \\\"{x:711,y:559,t:1527009188964};\\\", \\\"{x:705,y:552,t:1527009188980};\\\", \\\"{x:698,y:547,t:1527009188996};\\\", \\\"{x:696,y:545,t:1527009189012};\\\", \\\"{x:696,y:543,t:1527009189029};\\\", \\\"{x:695,y:543,t:1527009189046};\\\", \\\"{x:695,y:541,t:1527009189063};\\\", \\\"{x:696,y:540,t:1527009189079};\\\", \\\"{x:707,y:535,t:1527009189096};\\\", \\\"{x:720,y:531,t:1527009189113};\\\", \\\"{x:734,y:530,t:1527009189131};\\\", \\\"{x:753,y:530,t:1527009189146};\\\", \\\"{x:776,y:530,t:1527009189163};\\\", \\\"{x:798,y:530,t:1527009189179};\\\", \\\"{x:813,y:530,t:1527009189195};\\\", \\\"{x:822,y:529,t:1527009189213};\\\", \\\"{x:825,y:528,t:1527009189229};\\\", \\\"{x:826,y:528,t:1527009189263};\\\", \\\"{x:829,y:526,t:1527009189279};\\\", \\\"{x:835,y:523,t:1527009189296};\\\", \\\"{x:841,y:521,t:1527009189313};\\\", \\\"{x:843,y:519,t:1527009189329};\\\", \\\"{x:846,y:519,t:1527009189346};\\\", \\\"{x:847,y:518,t:1527009189363};\\\", \\\"{x:847,y:517,t:1527009189416};\\\", \\\"{x:847,y:515,t:1527009189430};\\\", \\\"{x:847,y:512,t:1527009189446};\\\", \\\"{x:847,y:510,t:1527009189463};\\\", \\\"{x:847,y:509,t:1527009189487};\\\", \\\"{x:846,y:507,t:1527009189519};\\\", \\\"{x:845,y:505,t:1527009189535};\\\", \\\"{x:844,y:504,t:1527009189546};\\\", \\\"{x:840,y:500,t:1527009189563};\\\", \\\"{x:839,y:499,t:1527009189580};\\\", \\\"{x:839,y:500,t:1527009189903};\\\", \\\"{x:833,y:505,t:1527009189913};\\\", \\\"{x:818,y:516,t:1527009189931};\\\", \\\"{x:804,y:524,t:1527009189948};\\\", \\\"{x:793,y:533,t:1527009189964};\\\", \\\"{x:780,y:541,t:1527009189980};\\\", \\\"{x:768,y:544,t:1527009189997};\\\", \\\"{x:760,y:546,t:1527009190013};\\\", \\\"{x:755,y:548,t:1527009190030};\\\", \\\"{x:750,y:553,t:1527009190047};\\\", \\\"{x:747,y:555,t:1527009190063};\\\", \\\"{x:741,y:559,t:1527009190081};\\\", \\\"{x:736,y:562,t:1527009190097};\\\", \\\"{x:726,y:565,t:1527009190114};\\\", \\\"{x:716,y:566,t:1527009190131};\\\", \\\"{x:705,y:569,t:1527009190147};\\\", \\\"{x:693,y:573,t:1527009190164};\\\", \\\"{x:678,y:577,t:1527009190180};\\\", \\\"{x:659,y:582,t:1527009190197};\\\", \\\"{x:641,y:588,t:1527009190214};\\\", \\\"{x:624,y:592,t:1527009190231};\\\", \\\"{x:592,y:602,t:1527009190248};\\\", \\\"{x:572,y:608,t:1527009190263};\\\", \\\"{x:548,y:617,t:1527009190280};\\\", \\\"{x:522,y:625,t:1527009190297};\\\", \\\"{x:505,y:630,t:1527009190314};\\\", \\\"{x:498,y:632,t:1527009190331};\\\", \\\"{x:492,y:634,t:1527009190347};\\\", \\\"{x:489,y:635,t:1527009190365};\\\", \\\"{x:488,y:635,t:1527009190381};\\\", \\\"{x:487,y:635,t:1527009190397};\\\", \\\"{x:484,y:635,t:1527009190415};\\\", \\\"{x:472,y:635,t:1527009190431};\\\", \\\"{x:459,y:633,t:1527009190448};\\\", \\\"{x:441,y:626,t:1527009190466};\\\", \\\"{x:424,y:622,t:1527009190481};\\\", \\\"{x:403,y:617,t:1527009190497};\\\", \\\"{x:383,y:611,t:1527009190514};\\\", \\\"{x:369,y:606,t:1527009190530};\\\", \\\"{x:356,y:605,t:1527009190547};\\\", \\\"{x:348,y:602,t:1527009190563};\\\", \\\"{x:342,y:601,t:1527009190580};\\\", \\\"{x:335,y:601,t:1527009190597};\\\", \\\"{x:322,y:598,t:1527009190615};\\\", \\\"{x:305,y:597,t:1527009190631};\\\", \\\"{x:297,y:597,t:1527009190647};\\\", \\\"{x:289,y:597,t:1527009190664};\\\", \\\"{x:279,y:597,t:1527009190681};\\\", \\\"{x:271,y:597,t:1527009190697};\\\", \\\"{x:255,y:600,t:1527009190714};\\\", \\\"{x:242,y:600,t:1527009190732};\\\", \\\"{x:232,y:600,t:1527009190747};\\\", \\\"{x:224,y:597,t:1527009190764};\\\", \\\"{x:222,y:596,t:1527009190781};\\\", \\\"{x:222,y:592,t:1527009190799};\\\", \\\"{x:221,y:584,t:1527009190814};\\\", \\\"{x:219,y:565,t:1527009190831};\\\", \\\"{x:210,y:545,t:1527009190848};\\\", \\\"{x:198,y:529,t:1527009190864};\\\", \\\"{x:183,y:517,t:1527009190881};\\\", \\\"{x:170,y:510,t:1527009190897};\\\", \\\"{x:164,y:504,t:1527009190914};\\\", \\\"{x:163,y:504,t:1527009190931};\\\", \\\"{x:161,y:504,t:1527009190992};\\\", \\\"{x:159,y:504,t:1527009190999};\\\", \\\"{x:156,y:504,t:1527009191014};\\\", \\\"{x:150,y:511,t:1527009191031};\\\", \\\"{x:148,y:514,t:1527009191048};\\\", \\\"{x:147,y:516,t:1527009191064};\\\", \\\"{x:147,y:518,t:1527009191081};\\\", \\\"{x:147,y:519,t:1527009191098};\\\", \\\"{x:147,y:522,t:1527009191114};\\\", \\\"{x:147,y:524,t:1527009191131};\\\", \\\"{x:147,y:527,t:1527009191149};\\\", \\\"{x:147,y:528,t:1527009191164};\\\", \\\"{x:148,y:531,t:1527009191181};\\\", \\\"{x:148,y:532,t:1527009191197};\\\", \\\"{x:148,y:533,t:1527009191214};\\\", \\\"{x:148,y:536,t:1527009191232};\\\", \\\"{x:148,y:538,t:1527009191247};\\\", \\\"{x:149,y:538,t:1527009191481};\\\", \\\"{x:157,y:543,t:1527009191498};\\\", \\\"{x:173,y:550,t:1527009191514};\\\", \\\"{x:209,y:571,t:1527009191532};\\\", \\\"{x:266,y:606,t:1527009191548};\\\", \\\"{x:329,y:639,t:1527009191565};\\\", \\\"{x:387,y:667,t:1527009191581};\\\", \\\"{x:440,y:690,t:1527009191599};\\\", \\\"{x:501,y:706,t:1527009191615};\\\", \\\"{x:514,y:709,t:1527009191631};\\\", \\\"{x:515,y:709,t:1527009191648};\\\", \\\"{x:515,y:708,t:1527009191711};\\\", \\\"{x:507,y:698,t:1527009191720};\\\", \\\"{x:493,y:683,t:1527009191732};\\\", \\\"{x:437,y:635,t:1527009191748};\\\", \\\"{x:369,y:596,t:1527009191765};\\\", \\\"{x:314,y:571,t:1527009191782};\\\", \\\"{x:258,y:552,t:1527009191799};\\\", \\\"{x:220,y:539,t:1527009191814};\\\", \\\"{x:184,y:531,t:1527009191832};\\\", \\\"{x:174,y:527,t:1527009191848};\\\", \\\"{x:173,y:527,t:1527009191865};\\\", \\\"{x:172,y:527,t:1527009191936};\\\", \\\"{x:170,y:527,t:1527009191951};\\\", \\\"{x:169,y:527,t:1527009191966};\\\", \\\"{x:166,y:531,t:1527009191983};\\\", \\\"{x:164,y:536,t:1527009191998};\\\", \\\"{x:164,y:538,t:1527009192015};\\\", \\\"{x:164,y:539,t:1527009192031};\\\", \\\"{x:164,y:540,t:1527009192167};\\\", \\\"{x:165,y:540,t:1527009192207};\\\", \\\"{x:165,y:540,t:1527009192259};\\\", \\\"{x:166,y:541,t:1527009192561};\\\", \\\"{x:179,y:549,t:1527009192568};\\\", \\\"{x:206,y:563,t:1527009192584};\\\", \\\"{x:294,y:619,t:1527009192599};\\\", \\\"{x:416,y:680,t:1527009192615};\\\", \\\"{x:478,y:716,t:1527009192632};\\\", \\\"{x:530,y:745,t:1527009192650};\\\", \\\"{x:555,y:761,t:1527009192665};\\\", \\\"{x:561,y:764,t:1527009192682};\\\", \\\"{x:561,y:765,t:1527009192699};\\\", \\\"{x:562,y:765,t:1527009192744};\\\", \\\"{x:566,y:765,t:1527009192751};\\\", \\\"{x:568,y:766,t:1527009192765};\\\", \\\"{x:573,y:768,t:1527009192782};\\\", \\\"{x:574,y:768,t:1527009192799};\\\", \\\"{x:575,y:766,t:1527009192848};\\\", \\\"{x:575,y:763,t:1527009192856};\\\", \\\"{x:575,y:759,t:1527009192866};\\\", \\\"{x:575,y:755,t:1527009192882};\\\", \\\"{x:575,y:749,t:1527009192899};\\\", \\\"{x:574,y:746,t:1527009192916};\\\", \\\"{x:571,y:742,t:1527009192932};\\\", \\\"{x:568,y:740,t:1527009192949};\\\", \\\"{x:566,y:739,t:1527009192966};\\\", \\\"{x:565,y:737,t:1527009192983};\\\", \\\"{x:560,y:735,t:1527009193000};\\\", \\\"{x:552,y:733,t:1527009193016};\\\", \\\"{x:550,y:731,t:1527009193032};\\\", \\\"{x:549,y:731,t:1527009193088};\\\", \\\"{x:549,y:730,t:1527009194096};\\\" ] }, { \\\"rt\\\": 24373, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 12, \\\"time_elapsed\\\": 383811, \\\"internal_node_id\\\": \\\"0.0-6.0-2.0\\\", \\\"subject\\\": \\\"R06S6\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"echo\\\", \\\"condition\\\": \\\"121\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"duration+contained\\\", \\\"q\\\": 8, \\\"clicks\\\": 1, \\\"explicit\\\": 1, \\\"impasse\\\": 2, \\\"axis\\\": \\\"Orthogonal-XInside-YFull\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 1, \\\"answer\\\": [ \\\"E\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-7-B -I -X -X -X -I \\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:547,y:726,t:1527009195059};\\\", \\\"{x:535,y:708,t:1527009195073};\\\", \\\"{x:497,y:664,t:1527009195088};\\\", \\\"{x:457,y:622,t:1527009195105};\\\", \\\"{x:423,y:588,t:1527009195122};\\\", \\\"{x:394,y:558,t:1527009195139};\\\", \\\"{x:378,y:543,t:1527009195155};\\\", \\\"{x:371,y:538,t:1527009195171};\\\", \\\"{x:370,y:535,t:1527009195188};\\\", \\\"{x:363,y:526,t:1527009195205};\\\", \\\"{x:353,y:512,t:1527009195222};\\\", \\\"{x:336,y:491,t:1527009195239};\\\", \\\"{x:317,y:473,t:1527009195255};\\\", \\\"{x:299,y:461,t:1527009195272};\\\", \\\"{x:295,y:457,t:1527009195288};\\\", \\\"{x:294,y:456,t:1527009195305};\\\", \\\"{x:293,y:455,t:1527009195321};\\\", \\\"{x:293,y:454,t:1527009195363};\\\", \\\"{x:293,y:453,t:1527009195371};\\\", \\\"{x:294,y:452,t:1527009195388};\\\", \\\"{x:296,y:452,t:1527009195405};\\\", \\\"{x:300,y:452,t:1527009195421};\\\", \\\"{x:307,y:452,t:1527009195438};\\\", \\\"{x:315,y:452,t:1527009195456};\\\", \\\"{x:325,y:452,t:1527009195471};\\\", \\\"{x:338,y:453,t:1527009195488};\\\", \\\"{x:347,y:455,t:1527009195505};\\\", \\\"{x:352,y:455,t:1527009195521};\\\", \\\"{x:356,y:455,t:1527009195538};\\\", \\\"{x:359,y:455,t:1527009195555};\\\", \\\"{x:360,y:456,t:1527009195572};\\\", \\\"{x:361,y:456,t:1527009195588};\\\", \\\"{x:362,y:456,t:1527009195612};\\\", \\\"{x:364,y:456,t:1527009195684};\\\", \\\"{x:365,y:456,t:1527009195692};\\\", \\\"{x:368,y:455,t:1527009195708};\\\", \\\"{x:369,y:452,t:1527009195748};\\\", \\\"{x:370,y:452,t:1527009196997};\\\", \\\"{x:371,y:452,t:1527009197052};\\\", \\\"{x:372,y:452,t:1527009197060};\\\", \\\"{x:375,y:452,t:1527009197075};\\\", \\\"{x:379,y:452,t:1527009197090};\\\", \\\"{x:388,y:454,t:1527009197106};\\\", \\\"{x:390,y:456,t:1527009197123};\\\", \\\"{x:391,y:456,t:1527009197140};\\\", \\\"{x:392,y:457,t:1527009197172};\\\", \\\"{x:393,y:458,t:1527009197188};\\\", \\\"{x:394,y:458,t:1527009197204};\\\", \\\"{x:395,y:458,t:1527009197212};\\\", \\\"{x:395,y:459,t:1527009197236};\\\", \\\"{x:396,y:460,t:1527009197268};\\\", \\\"{x:397,y:461,t:1527009197325};\\\", \\\"{x:399,y:461,t:1527009197340};\\\", \\\"{x:401,y:461,t:1527009197356};\\\", \\\"{x:402,y:462,t:1527009197373};\\\", \\\"{x:404,y:462,t:1527009197419};\\\", \\\"{x:404,y:463,t:1527009197861};\\\", \\\"{x:404,y:464,t:1527009197884};\\\", \\\"{x:404,y:465,t:1527009197891};\\\", \\\"{x:404,y:466,t:1527009197906};\\\", \\\"{x:403,y:467,t:1527009197931};\\\", \\\"{x:403,y:468,t:1527009197947};\\\", \\\"{x:402,y:468,t:1527009197962};\\\", \\\"{x:402,y:469,t:1527009197973};\\\", \\\"{x:401,y:470,t:1527009197990};\\\", \\\"{x:400,y:471,t:1527009198010};\\\", \\\"{x:400,y:472,t:1527009198024};\\\", \\\"{x:399,y:472,t:1527009198040};\\\", \\\"{x:398,y:474,t:1527009198057};\\\", \\\"{x:398,y:475,t:1527009198083};\\\", \\\"{x:397,y:476,t:1527009198099};\\\", \\\"{x:396,y:476,t:1527009198219};\\\", \\\"{x:395,y:477,t:1527009198226};\\\", \\\"{x:394,y:477,t:1527009198250};\\\", \\\"{x:394,y:478,t:1527009198259};\\\", \\\"{x:393,y:478,t:1527009198274};\\\", \\\"{x:393,y:479,t:1527009198315};\\\", \\\"{x:396,y:481,t:1527009198323};\\\", \\\"{x:408,y:485,t:1527009198340};\\\", \\\"{x:417,y:487,t:1527009198358};\\\", \\\"{x:428,y:487,t:1527009198373};\\\", \\\"{x:439,y:487,t:1527009198391};\\\", \\\"{x:461,y:487,t:1527009198407};\\\", \\\"{x:489,y:487,t:1527009198425};\\\", \\\"{x:516,y:487,t:1527009198441};\\\", \\\"{x:544,y:487,t:1527009198457};\\\", \\\"{x:573,y:487,t:1527009198475};\\\", \\\"{x:603,y:487,t:1527009198491};\\\", \\\"{x:665,y:487,t:1527009198507};\\\", \\\"{x:713,y:487,t:1527009198525};\\\", \\\"{x:755,y:487,t:1527009198541};\\\", \\\"{x:787,y:487,t:1527009198558};\\\", \\\"{x:811,y:487,t:1527009198575};\\\", \\\"{x:829,y:487,t:1527009198592};\\\", \\\"{x:843,y:489,t:1527009198607};\\\", \\\"{x:850,y:491,t:1527009198625};\\\", \\\"{x:857,y:492,t:1527009198642};\\\", \\\"{x:864,y:492,t:1527009198658};\\\", \\\"{x:878,y:493,t:1527009198674};\\\", \\\"{x:904,y:494,t:1527009198690};\\\", \\\"{x:923,y:494,t:1527009198708};\\\", \\\"{x:939,y:494,t:1527009198724};\\\", \\\"{x:951,y:496,t:1527009198741};\\\", \\\"{x:962,y:496,t:1527009198758};\\\", \\\"{x:973,y:496,t:1527009198775};\\\", \\\"{x:983,y:496,t:1527009198791};\\\", \\\"{x:997,y:496,t:1527009198808};\\\", \\\"{x:1006,y:496,t:1527009198824};\\\", \\\"{x:1015,y:496,t:1527009198842};\\\", \\\"{x:1027,y:496,t:1527009198857};\\\", \\\"{x:1042,y:496,t:1527009198874};\\\", \\\"{x:1060,y:496,t:1527009198892};\\\", \\\"{x:1066,y:496,t:1527009198908};\\\", \\\"{x:1068,y:496,t:1527009198925};\\\", \\\"{x:1066,y:497,t:1527009199636};\\\", \\\"{x:1066,y:499,t:1527009202229};\\\", \\\"{x:1067,y:500,t:1527009202244};\\\", \\\"{x:1070,y:501,t:1527009202261};\\\", \\\"{x:1071,y:502,t:1527009202277};\\\", \\\"{x:1072,y:503,t:1527009202308};\\\", \\\"{x:1073,y:504,t:1527009202324};\\\", \\\"{x:1073,y:505,t:1527009202343};\\\", \\\"{x:1075,y:506,t:1527009202360};\\\", \\\"{x:1080,y:508,t:1527009202375};\\\", \\\"{x:1089,y:512,t:1527009202393};\\\", \\\"{x:1101,y:520,t:1527009202409};\\\", \\\"{x:1112,y:526,t:1527009202426};\\\", \\\"{x:1118,y:531,t:1527009202443};\\\", \\\"{x:1127,y:539,t:1527009202459};\\\", \\\"{x:1132,y:545,t:1527009202476};\\\", \\\"{x:1136,y:554,t:1527009202493};\\\", \\\"{x:1142,y:563,t:1527009202510};\\\", \\\"{x:1147,y:574,t:1527009202526};\\\", \\\"{x:1150,y:584,t:1527009202543};\\\", \\\"{x:1153,y:593,t:1527009202560};\\\", \\\"{x:1157,y:598,t:1527009202576};\\\", \\\"{x:1160,y:600,t:1527009202593};\\\", \\\"{x:1167,y:603,t:1527009202610};\\\", \\\"{x:1172,y:604,t:1527009202626};\\\", \\\"{x:1181,y:607,t:1527009202643};\\\", \\\"{x:1185,y:608,t:1527009202659};\\\", \\\"{x:1194,y:610,t:1527009202675};\\\", \\\"{x:1205,y:614,t:1527009202692};\\\", \\\"{x:1219,y:618,t:1527009202710};\\\", \\\"{x:1228,y:619,t:1527009202725};\\\", \\\"{x:1241,y:624,t:1527009202743};\\\", \\\"{x:1257,y:628,t:1527009202760};\\\", \\\"{x:1269,y:630,t:1527009202776};\\\", \\\"{x:1285,y:632,t:1527009202793};\\\", \\\"{x:1294,y:633,t:1527009202809};\\\", \\\"{x:1308,y:633,t:1527009202826};\\\", \\\"{x:1324,y:633,t:1527009202843};\\\", \\\"{x:1348,y:633,t:1527009202859};\\\", \\\"{x:1357,y:633,t:1527009202876};\\\", \\\"{x:1363,y:633,t:1527009202893};\\\", \\\"{x:1365,y:633,t:1527009202910};\\\", \\\"{x:1366,y:633,t:1527009202926};\\\", \\\"{x:1366,y:635,t:1527009203163};\\\", \\\"{x:1366,y:639,t:1527009203177};\\\", \\\"{x:1363,y:652,t:1527009203193};\\\", \\\"{x:1362,y:660,t:1527009203209};\\\", \\\"{x:1362,y:670,t:1527009203227};\\\", \\\"{x:1362,y:679,t:1527009203243};\\\", \\\"{x:1367,y:693,t:1527009203259};\\\", \\\"{x:1368,y:699,t:1527009203277};\\\", \\\"{x:1369,y:704,t:1527009203293};\\\", \\\"{x:1373,y:715,t:1527009203310};\\\", \\\"{x:1374,y:725,t:1527009203326};\\\", \\\"{x:1374,y:731,t:1527009203343};\\\", \\\"{x:1374,y:738,t:1527009203360};\\\", \\\"{x:1374,y:742,t:1527009203377};\\\", \\\"{x:1374,y:744,t:1527009203393};\\\", \\\"{x:1373,y:745,t:1527009203427};\\\", \\\"{x:1371,y:745,t:1527009203443};\\\", \\\"{x:1368,y:748,t:1527009203460};\\\", \\\"{x:1366,y:749,t:1527009203477};\\\", \\\"{x:1363,y:749,t:1527009203493};\\\", \\\"{x:1355,y:749,t:1527009203509};\\\", \\\"{x:1344,y:749,t:1527009203526};\\\", \\\"{x:1339,y:747,t:1527009203543};\\\", \\\"{x:1337,y:747,t:1527009204371};\\\", \\\"{x:1336,y:747,t:1527009204379};\\\", \\\"{x:1334,y:747,t:1527009204393};\\\", \\\"{x:1333,y:747,t:1527009204409};\\\", \\\"{x:1332,y:746,t:1527009204426};\\\", \\\"{x:1330,y:745,t:1527009204444};\\\", \\\"{x:1329,y:744,t:1527009204460};\\\", \\\"{x:1327,y:743,t:1527009204477};\\\", \\\"{x:1325,y:743,t:1527009204507};\\\", \\\"{x:1323,y:741,t:1527009204564};\\\", \\\"{x:1321,y:741,t:1527009204596};\\\", \\\"{x:1319,y:740,t:1527009204619};\\\", \\\"{x:1317,y:740,t:1527009204628};\\\", \\\"{x:1315,y:739,t:1527009204644};\\\", \\\"{x:1314,y:739,t:1527009204661};\\\", \\\"{x:1311,y:738,t:1527009204677};\\\", \\\"{x:1310,y:738,t:1527009204693};\\\", \\\"{x:1308,y:738,t:1527009204715};\\\", \\\"{x:1306,y:737,t:1527009204731};\\\", \\\"{x:1305,y:737,t:1527009204747};\\\", \\\"{x:1304,y:737,t:1527009204763};\\\", \\\"{x:1303,y:737,t:1527009204811};\\\", \\\"{x:1302,y:737,t:1527009204827};\\\", \\\"{x:1301,y:737,t:1527009204845};\\\", \\\"{x:1297,y:737,t:1527009204861};\\\", \\\"{x:1293,y:740,t:1527009204877};\\\", \\\"{x:1290,y:742,t:1527009204894};\\\", \\\"{x:1285,y:744,t:1527009204910};\\\", \\\"{x:1283,y:745,t:1527009204926};\\\", \\\"{x:1281,y:745,t:1527009204944};\\\", \\\"{x:1280,y:746,t:1527009204961};\\\", \\\"{x:1279,y:747,t:1527009205045};\\\", \\\"{x:1279,y:748,t:1527009205068};\\\", \\\"{x:1278,y:748,t:1527009205100};\\\", \\\"{x:1277,y:749,t:1527009205116};\\\", \\\"{x:1276,y:750,t:1527009205140};\\\", \\\"{x:1276,y:751,t:1527009205148};\\\", \\\"{x:1275,y:751,t:1527009205164};\\\", \\\"{x:1274,y:752,t:1527009205177};\\\", \\\"{x:1273,y:753,t:1527009205194};\\\", \\\"{x:1273,y:754,t:1527009205212};\\\", \\\"{x:1272,y:754,t:1527009205228};\\\", \\\"{x:1269,y:755,t:1527009205244};\\\", \\\"{x:1268,y:757,t:1527009205261};\\\", \\\"{x:1265,y:760,t:1527009205277};\\\", \\\"{x:1261,y:762,t:1527009205294};\\\", \\\"{x:1260,y:764,t:1527009205311};\\\", \\\"{x:1258,y:765,t:1527009205327};\\\", \\\"{x:1257,y:767,t:1527009205344};\\\", \\\"{x:1257,y:756,t:1527009205571};\\\", \\\"{x:1257,y:742,t:1527009205579};\\\", \\\"{x:1257,y:727,t:1527009205594};\\\", \\\"{x:1257,y:659,t:1527009205611};\\\", \\\"{x:1257,y:631,t:1527009205627};\\\", \\\"{x:1258,y:616,t:1527009205644};\\\", \\\"{x:1258,y:609,t:1527009205661};\\\", \\\"{x:1259,y:604,t:1527009205678};\\\", \\\"{x:1259,y:599,t:1527009205693};\\\", \\\"{x:1259,y:594,t:1527009205711};\\\", \\\"{x:1259,y:586,t:1527009205728};\\\", \\\"{x:1259,y:579,t:1527009205743};\\\", \\\"{x:1259,y:574,t:1527009205760};\\\", \\\"{x:1259,y:571,t:1527009205778};\\\", \\\"{x:1259,y:572,t:1527009205915};\\\", \\\"{x:1257,y:580,t:1527009205928};\\\", \\\"{x:1246,y:605,t:1527009205944};\\\", \\\"{x:1231,y:650,t:1527009205960};\\\", \\\"{x:1207,y:705,t:1527009205977};\\\", \\\"{x:1177,y:767,t:1527009205994};\\\", \\\"{x:1141,y:841,t:1527009206011};\\\", \\\"{x:1123,y:878,t:1527009206028};\\\", \\\"{x:1115,y:901,t:1527009206044};\\\", \\\"{x:1112,y:912,t:1527009206061};\\\", \\\"{x:1112,y:914,t:1527009206077};\\\", \\\"{x:1114,y:914,t:1527009206187};\\\", \\\"{x:1120,y:912,t:1527009206195};\\\", \\\"{x:1137,y:901,t:1527009206211};\\\", \\\"{x:1153,y:892,t:1527009206228};\\\", \\\"{x:1164,y:885,t:1527009206244};\\\", \\\"{x:1174,y:880,t:1527009206261};\\\", \\\"{x:1180,y:876,t:1527009206278};\\\", \\\"{x:1182,y:875,t:1527009206294};\\\", \\\"{x:1183,y:874,t:1527009206311};\\\", \\\"{x:1184,y:874,t:1527009206328};\\\", \\\"{x:1185,y:873,t:1527009206344};\\\", \\\"{x:1185,y:872,t:1527009206361};\\\", \\\"{x:1186,y:872,t:1527009206378};\\\", \\\"{x:1188,y:872,t:1527009206395};\\\", \\\"{x:1188,y:871,t:1527009206412};\\\", \\\"{x:1189,y:871,t:1527009206428};\\\", \\\"{x:1195,y:871,t:1527009210084};\\\", \\\"{x:1210,y:871,t:1527009210097};\\\", \\\"{x:1240,y:871,t:1527009210114};\\\", \\\"{x:1267,y:868,t:1527009210129};\\\", \\\"{x:1290,y:860,t:1527009210146};\\\", \\\"{x:1310,y:854,t:1527009210163};\\\", \\\"{x:1315,y:854,t:1527009210178};\\\", \\\"{x:1322,y:851,t:1527009210196};\\\", \\\"{x:1333,y:849,t:1527009210213};\\\", \\\"{x:1349,y:848,t:1527009210229};\\\", \\\"{x:1376,y:840,t:1527009210246};\\\", \\\"{x:1408,y:836,t:1527009210263};\\\", \\\"{x:1435,y:832,t:1527009210279};\\\", \\\"{x:1453,y:828,t:1527009210296};\\\", \\\"{x:1463,y:828,t:1527009210312};\\\", \\\"{x:1465,y:827,t:1527009210329};\\\", \\\"{x:1466,y:827,t:1527009210346};\\\", \\\"{x:1472,y:826,t:1527009210364};\\\", \\\"{x:1477,y:826,t:1527009210380};\\\", \\\"{x:1485,y:824,t:1527009210397};\\\", \\\"{x:1492,y:823,t:1527009210413};\\\", \\\"{x:1497,y:823,t:1527009210430};\\\", \\\"{x:1500,y:823,t:1527009210446};\\\", \\\"{x:1507,y:823,t:1527009210463};\\\", \\\"{x:1510,y:823,t:1527009210480};\\\", \\\"{x:1511,y:822,t:1527009210580};\\\", \\\"{x:1508,y:820,t:1527009210597};\\\", \\\"{x:1502,y:819,t:1527009210614};\\\", \\\"{x:1500,y:819,t:1527009210630};\\\", \\\"{x:1497,y:819,t:1527009210646};\\\", \\\"{x:1494,y:820,t:1527009210663};\\\", \\\"{x:1493,y:820,t:1527009210681};\\\", \\\"{x:1492,y:820,t:1527009210697};\\\", \\\"{x:1491,y:820,t:1527009210713};\\\", \\\"{x:1490,y:820,t:1527009210731};\\\", \\\"{x:1489,y:821,t:1527009210764};\\\", \\\"{x:1488,y:821,t:1527009210796};\\\", \\\"{x:1487,y:821,t:1527009210814};\\\", \\\"{x:1486,y:822,t:1527009210924};\\\", \\\"{x:1486,y:823,t:1527009210932};\\\", \\\"{x:1484,y:824,t:1527009210955};\\\", \\\"{x:1483,y:826,t:1527009210979};\\\", \\\"{x:1482,y:828,t:1527009211013};\\\", \\\"{x:1481,y:830,t:1527009211030};\\\", \\\"{x:1480,y:830,t:1527009211046};\\\", \\\"{x:1480,y:831,t:1527009211063};\\\", \\\"{x:1480,y:832,t:1527009211083};\\\", \\\"{x:1480,y:833,t:1527009211096};\\\", \\\"{x:1478,y:835,t:1527009211661};\\\", \\\"{x:1475,y:837,t:1527009211669};\\\", \\\"{x:1471,y:838,t:1527009211680};\\\", \\\"{x:1464,y:841,t:1527009211697};\\\", \\\"{x:1457,y:845,t:1527009211713};\\\", \\\"{x:1452,y:845,t:1527009211730};\\\", \\\"{x:1451,y:845,t:1527009212500};\\\", \\\"{x:1451,y:844,t:1527009212523};\\\", \\\"{x:1451,y:843,t:1527009212540};\\\", \\\"{x:1451,y:842,t:1527009212548};\\\", \\\"{x:1447,y:839,t:1527009212564};\\\", \\\"{x:1444,y:836,t:1527009212580};\\\", \\\"{x:1432,y:829,t:1527009212598};\\\", \\\"{x:1417,y:821,t:1527009212615};\\\", \\\"{x:1404,y:815,t:1527009212631};\\\", \\\"{x:1400,y:813,t:1527009212648};\\\", \\\"{x:1398,y:812,t:1527009212827};\\\", \\\"{x:1393,y:810,t:1527009212835};\\\", \\\"{x:1389,y:809,t:1527009212847};\\\", \\\"{x:1381,y:806,t:1527009212864};\\\", \\\"{x:1372,y:804,t:1527009212880};\\\", \\\"{x:1366,y:803,t:1527009212897};\\\", \\\"{x:1358,y:801,t:1527009212914};\\\", \\\"{x:1341,y:799,t:1527009212930};\\\", \\\"{x:1330,y:798,t:1527009212947};\\\", \\\"{x:1325,y:797,t:1527009212964};\\\", \\\"{x:1324,y:797,t:1527009212982};\\\", \\\"{x:1323,y:797,t:1527009213044};\\\", \\\"{x:1322,y:796,t:1527009213149};\\\", \\\"{x:1323,y:794,t:1527009213172};\\\", \\\"{x:1325,y:793,t:1527009213182};\\\", \\\"{x:1326,y:792,t:1527009213203};\\\", \\\"{x:1326,y:791,t:1527009213214};\\\", \\\"{x:1327,y:791,t:1527009213232};\\\", \\\"{x:1328,y:790,t:1527009213248};\\\", \\\"{x:1328,y:788,t:1527009213265};\\\", \\\"{x:1328,y:787,t:1527009213284};\\\", \\\"{x:1328,y:785,t:1527009213297};\\\", \\\"{x:1329,y:784,t:1527009213315};\\\", \\\"{x:1330,y:780,t:1527009213332};\\\", \\\"{x:1330,y:776,t:1527009213347};\\\", \\\"{x:1330,y:772,t:1527009213365};\\\", \\\"{x:1330,y:769,t:1527009213381};\\\", \\\"{x:1330,y:767,t:1527009213398};\\\", \\\"{x:1330,y:766,t:1527009213428};\\\", \\\"{x:1330,y:765,t:1527009213436};\\\", \\\"{x:1330,y:764,t:1527009213447};\\\", \\\"{x:1330,y:763,t:1527009213500};\\\", \\\"{x:1329,y:763,t:1527009213724};\\\", \\\"{x:1327,y:763,t:1527009213732};\\\", \\\"{x:1320,y:760,t:1527009213748};\\\", \\\"{x:1315,y:759,t:1527009213765};\\\", \\\"{x:1314,y:759,t:1527009213782};\\\", \\\"{x:1313,y:759,t:1527009213869};\\\", \\\"{x:1311,y:758,t:1527009213884};\\\", \\\"{x:1310,y:757,t:1527009213898};\\\", \\\"{x:1308,y:757,t:1527009213914};\\\", \\\"{x:1303,y:756,t:1527009213932};\\\", \\\"{x:1300,y:756,t:1527009213948};\\\", \\\"{x:1292,y:756,t:1527009213965};\\\", \\\"{x:1277,y:753,t:1527009213981};\\\", \\\"{x:1269,y:751,t:1527009213999};\\\", \\\"{x:1262,y:748,t:1527009214015};\\\", \\\"{x:1261,y:748,t:1527009214032};\\\", \\\"{x:1260,y:748,t:1527009216708};\\\", \\\"{x:1259,y:753,t:1527009216716};\\\", \\\"{x:1258,y:759,t:1527009216733};\\\", \\\"{x:1256,y:762,t:1527009216750};\\\", \\\"{x:1256,y:763,t:1527009216766};\\\", \\\"{x:1254,y:764,t:1527009216783};\\\", \\\"{x:1253,y:764,t:1527009216852};\\\", \\\"{x:1247,y:764,t:1527009216866};\\\", \\\"{x:1224,y:764,t:1527009216883};\\\", \\\"{x:1180,y:764,t:1527009216900};\\\", \\\"{x:1126,y:764,t:1527009216917};\\\", \\\"{x:1033,y:754,t:1527009216933};\\\", \\\"{x:946,y:741,t:1527009216950};\\\", \\\"{x:849,y:725,t:1527009216965};\\\", \\\"{x:768,y:713,t:1527009216983};\\\", \\\"{x:727,y:708,t:1527009216999};\\\", \\\"{x:709,y:703,t:1527009217015};\\\", \\\"{x:703,y:703,t:1527009217032};\\\", \\\"{x:702,y:703,t:1527009217049};\\\", \\\"{x:702,y:702,t:1527009217116};\\\", \\\"{x:698,y:700,t:1527009217133};\\\", \\\"{x:694,y:699,t:1527009217150};\\\", \\\"{x:694,y:693,t:1527009217166};\\\", \\\"{x:694,y:683,t:1527009217183};\\\", \\\"{x:694,y:673,t:1527009217200};\\\", \\\"{x:697,y:661,t:1527009217217};\\\", \\\"{x:697,y:645,t:1527009217232};\\\", \\\"{x:693,y:629,t:1527009217251};\\\", \\\"{x:685,y:611,t:1527009217266};\\\", \\\"{x:671,y:594,t:1527009217282};\\\", \\\"{x:666,y:582,t:1527009217306};\\\", \\\"{x:666,y:579,t:1527009217322};\\\", \\\"{x:663,y:574,t:1527009217338};\\\", \\\"{x:662,y:573,t:1527009217356};\\\", \\\"{x:656,y:569,t:1527009217372};\\\", \\\"{x:650,y:565,t:1527009217389};\\\", \\\"{x:644,y:559,t:1527009217407};\\\", \\\"{x:640,y:553,t:1527009217423};\\\", \\\"{x:637,y:548,t:1527009217439};\\\", \\\"{x:635,y:544,t:1527009217455};\\\", \\\"{x:634,y:540,t:1527009217472};\\\", \\\"{x:630,y:533,t:1527009217489};\\\", \\\"{x:627,y:527,t:1527009217507};\\\", \\\"{x:622,y:521,t:1527009217523};\\\", \\\"{x:619,y:516,t:1527009217540};\\\", \\\"{x:618,y:514,t:1527009217557};\\\", \\\"{x:618,y:513,t:1527009217579};\\\", \\\"{x:617,y:512,t:1527009217619};\\\", \\\"{x:615,y:511,t:1527009217627};\\\", \\\"{x:614,y:510,t:1527009217639};\\\", \\\"{x:612,y:509,t:1527009217656};\\\", \\\"{x:610,y:509,t:1527009218116};\\\", \\\"{x:610,y:514,t:1527009218123};\\\", \\\"{x:609,y:531,t:1527009218141};\\\", \\\"{x:604,y:553,t:1527009218156};\\\", \\\"{x:597,y:577,t:1527009218173};\\\", \\\"{x:585,y:604,t:1527009218191};\\\", \\\"{x:575,y:630,t:1527009218206};\\\", \\\"{x:566,y:651,t:1527009218223};\\\", \\\"{x:558,y:671,t:1527009218240};\\\", \\\"{x:555,y:692,t:1527009218257};\\\", \\\"{x:552,y:706,t:1527009218273};\\\", \\\"{x:551,y:713,t:1527009218290};\\\", \\\"{x:551,y:714,t:1527009218323};\\\", \\\"{x:551,y:716,t:1527009218371};\\\", \\\"{x:550,y:719,t:1527009218387};\\\", \\\"{x:548,y:722,t:1527009218397};\\\", \\\"{x:544,y:725,t:1527009218406};\\\", \\\"{x:536,y:734,t:1527009218423};\\\", \\\"{x:524,y:745,t:1527009218440};\\\", \\\"{x:507,y:755,t:1527009218457};\\\", \\\"{x:498,y:758,t:1527009218473};\\\", \\\"{x:497,y:759,t:1527009218490};\\\", \\\"{x:497,y:757,t:1527009218587};\\\", \\\"{x:497,y:756,t:1527009218595};\\\", \\\"{x:498,y:755,t:1527009218611};\\\", \\\"{x:498,y:754,t:1527009218624};\\\", \\\"{x:499,y:753,t:1527009218627};\\\", \\\"{x:499,y:751,t:1527009218640};\\\", \\\"{x:499,y:749,t:1527009218656};\\\", \\\"{x:501,y:745,t:1527009218673};\\\", \\\"{x:502,y:743,t:1527009218690};\\\", \\\"{x:503,y:740,t:1527009218708};\\\", \\\"{x:503,y:739,t:1527009218723};\\\", \\\"{x:504,y:739,t:1527009218740};\\\", \\\"{x:505,y:738,t:1527009218758};\\\" ] }, { \\\"rt\\\": 14129, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 13, \\\"time_elapsed\\\": 399235, \\\"internal_node_id\\\": \\\"0.0-6.0-3.0\\\", \\\"subject\\\": \\\"R06S6\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"echo\\\", \\\"condition\\\": \\\"121\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"starttime+before+endtime+during\\\", \\\"q\\\": 9, \\\"clicks\\\": 2.5, \\\"explicit\\\": 1, \\\"impasse\\\": 2, \\\"axis\\\": \\\"Orthogonal-XInside-YFull\\\", \\\"correct\\\": 1, \\\"orth_correct\\\": 1, \\\"answer\\\": [ \\\"I\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-6\\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:504,y:737,t:1527009220939};\\\", \\\"{x:492,y:731,t:1527009220963};\\\", \\\"{x:489,y:730,t:1527009220975};\\\", \\\"{x:486,y:725,t:1527009220993};\\\", \\\"{x:476,y:689,t:1527009221009};\\\", \\\"{x:465,y:646,t:1527009221026};\\\", \\\"{x:457,y:608,t:1527009221043};\\\", \\\"{x:449,y:570,t:1527009221059};\\\", \\\"{x:444,y:511,t:1527009221076};\\\", \\\"{x:449,y:466,t:1527009221093};\\\", \\\"{x:473,y:426,t:1527009221108};\\\", \\\"{x:497,y:387,t:1527009221126};\\\", \\\"{x:511,y:367,t:1527009221143};\\\", \\\"{x:514,y:351,t:1527009221160};\\\", \\\"{x:514,y:347,t:1527009221176};\\\", \\\"{x:514,y:354,t:1527009221355};\\\", \\\"{x:518,y:368,t:1527009221363};\\\", \\\"{x:522,y:382,t:1527009221377};\\\", \\\"{x:531,y:411,t:1527009221394};\\\", \\\"{x:542,y:435,t:1527009221410};\\\", \\\"{x:554,y:455,t:1527009221427};\\\", \\\"{x:569,y:471,t:1527009221443};\\\", \\\"{x:573,y:474,t:1527009221460};\\\", \\\"{x:578,y:478,t:1527009221477};\\\", \\\"{x:585,y:484,t:1527009221493};\\\", \\\"{x:592,y:490,t:1527009221510};\\\", \\\"{x:597,y:495,t:1527009221527};\\\", \\\"{x:601,y:502,t:1527009221543};\\\", \\\"{x:605,y:507,t:1527009221559};\\\", \\\"{x:609,y:511,t:1527009221575};\\\", \\\"{x:612,y:515,t:1527009221592};\\\", \\\"{x:614,y:517,t:1527009221610};\\\", \\\"{x:617,y:520,t:1527009221626};\\\", \\\"{x:620,y:521,t:1527009221643};\\\", \\\"{x:629,y:522,t:1527009221659};\\\", \\\"{x:636,y:522,t:1527009221677};\\\", \\\"{x:644,y:522,t:1527009221693};\\\", \\\"{x:654,y:522,t:1527009221710};\\\", \\\"{x:674,y:520,t:1527009221725};\\\", \\\"{x:705,y:517,t:1527009221743};\\\", \\\"{x:763,y:510,t:1527009221760};\\\", \\\"{x:847,y:508,t:1527009221776};\\\", \\\"{x:900,y:508,t:1527009221793};\\\", \\\"{x:933,y:508,t:1527009221809};\\\", \\\"{x:955,y:512,t:1527009221827};\\\", \\\"{x:985,y:524,t:1527009221842};\\\", \\\"{x:992,y:529,t:1527009221859};\\\", \\\"{x:1018,y:535,t:1527009221875};\\\", \\\"{x:1042,y:544,t:1527009221893};\\\", \\\"{x:1056,y:548,t:1527009221909};\\\", \\\"{x:1062,y:551,t:1527009221925};\\\", \\\"{x:1062,y:552,t:1527009221972};\\\", \\\"{x:1062,y:553,t:1527009221979};\\\", \\\"{x:1062,y:555,t:1527009221993};\\\", \\\"{x:1062,y:557,t:1527009222010};\\\", \\\"{x:1062,y:561,t:1527009222026};\\\", \\\"{x:1062,y:564,t:1527009222042};\\\", \\\"{x:1062,y:569,t:1527009222059};\\\", \\\"{x:1062,y:571,t:1527009222077};\\\", \\\"{x:1062,y:574,t:1527009222092};\\\", \\\"{x:1062,y:579,t:1527009222109};\\\", \\\"{x:1065,y:590,t:1527009222126};\\\", \\\"{x:1073,y:607,t:1527009222142};\\\", \\\"{x:1086,y:620,t:1527009222159};\\\", \\\"{x:1101,y:630,t:1527009222176};\\\", \\\"{x:1121,y:645,t:1527009222193};\\\", \\\"{x:1146,y:662,t:1527009222210};\\\", \\\"{x:1169,y:673,t:1527009222226};\\\", \\\"{x:1182,y:680,t:1527009222242};\\\", \\\"{x:1196,y:689,t:1527009222259};\\\", \\\"{x:1205,y:693,t:1527009222275};\\\", \\\"{x:1213,y:697,t:1527009222293};\\\", \\\"{x:1219,y:700,t:1527009222309};\\\", \\\"{x:1225,y:700,t:1527009222325};\\\", \\\"{x:1222,y:700,t:1527009222861};\\\", \\\"{x:1153,y:691,t:1527009222875};\\\", \\\"{x:1073,y:672,t:1527009222892};\\\", \\\"{x:984,y:659,t:1527009222909};\\\", \\\"{x:850,y:633,t:1527009222926};\\\", \\\"{x:729,y:602,t:1527009222941};\\\", \\\"{x:619,y:575,t:1527009222959};\\\", \\\"{x:531,y:552,t:1527009222977};\\\", \\\"{x:504,y:547,t:1527009222993};\\\", \\\"{x:499,y:547,t:1527009223010};\\\", \\\"{x:498,y:547,t:1527009223028};\\\", \\\"{x:498,y:545,t:1527009223220};\\\", \\\"{x:501,y:543,t:1527009223229};\\\", \\\"{x:518,y:533,t:1527009223243};\\\", \\\"{x:540,y:519,t:1527009223261};\\\", \\\"{x:559,y:507,t:1527009223278};\\\", \\\"{x:574,y:499,t:1527009223294};\\\", \\\"{x:579,y:495,t:1527009223310};\\\", \\\"{x:581,y:495,t:1527009223328};\\\", \\\"{x:582,y:494,t:1527009223343};\\\", \\\"{x:583,y:493,t:1527009223360};\\\", \\\"{x:584,y:492,t:1527009223411};\\\", \\\"{x:585,y:492,t:1527009223484};\\\", \\\"{x:586,y:492,t:1527009223523};\\\", \\\"{x:587,y:492,t:1527009223539};\\\", \\\"{x:588,y:492,t:1527009223548};\\\", \\\"{x:589,y:492,t:1527009223588};\\\", \\\"{x:590,y:492,t:1527009223603};\\\", \\\"{x:591,y:492,t:1527009223619};\\\", \\\"{x:592,y:492,t:1527009223643};\\\", \\\"{x:593,y:492,t:1527009223651};\\\", \\\"{x:594,y:492,t:1527009223667};\\\", \\\"{x:595,y:492,t:1527009223678};\\\", \\\"{x:598,y:492,t:1527009223695};\\\", \\\"{x:602,y:492,t:1527009223712};\\\", \\\"{x:608,y:492,t:1527009223728};\\\", \\\"{x:615,y:492,t:1527009223744};\\\", \\\"{x:623,y:492,t:1527009223760};\\\", \\\"{x:634,y:492,t:1527009223777};\\\", \\\"{x:656,y:492,t:1527009223795};\\\", \\\"{x:667,y:492,t:1527009223811};\\\", \\\"{x:702,y:494,t:1527009223827};\\\", \\\"{x:726,y:494,t:1527009223845};\\\", \\\"{x:747,y:496,t:1527009223860};\\\", \\\"{x:767,y:500,t:1527009223877};\\\", \\\"{x:787,y:505,t:1527009223894};\\\", \\\"{x:808,y:509,t:1527009223912};\\\", \\\"{x:834,y:515,t:1527009223928};\\\", \\\"{x:873,y:524,t:1527009223945};\\\", \\\"{x:918,y:537,t:1527009223963};\\\", \\\"{x:973,y:548,t:1527009223978};\\\", \\\"{x:1076,y:580,t:1527009223995};\\\", \\\"{x:1128,y:591,t:1527009224011};\\\", \\\"{x:1149,y:603,t:1527009224027};\\\", \\\"{x:1162,y:612,t:1527009224045};\\\", \\\"{x:1171,y:623,t:1527009224062};\\\", \\\"{x:1175,y:632,t:1527009224078};\\\", \\\"{x:1177,y:645,t:1527009224095};\\\", \\\"{x:1177,y:648,t:1527009224112};\\\", \\\"{x:1177,y:652,t:1527009224128};\\\", \\\"{x:1177,y:654,t:1527009224145};\\\", \\\"{x:1177,y:658,t:1527009224162};\\\", \\\"{x:1175,y:667,t:1527009224178};\\\", \\\"{x:1174,y:681,t:1527009224196};\\\", \\\"{x:1174,y:688,t:1527009224211};\\\", \\\"{x:1174,y:694,t:1527009224228};\\\", \\\"{x:1176,y:701,t:1527009224245};\\\", \\\"{x:1181,y:707,t:1527009224262};\\\", \\\"{x:1186,y:715,t:1527009224278};\\\", \\\"{x:1191,y:724,t:1527009224295};\\\", \\\"{x:1199,y:738,t:1527009224312};\\\", \\\"{x:1205,y:750,t:1527009224328};\\\", \\\"{x:1216,y:764,t:1527009224345};\\\", \\\"{x:1226,y:773,t:1527009224362};\\\", \\\"{x:1240,y:783,t:1527009224379};\\\", \\\"{x:1244,y:785,t:1527009224395};\\\", \\\"{x:1245,y:785,t:1527009224411};\\\", \\\"{x:1246,y:786,t:1527009224443};\\\", \\\"{x:1247,y:786,t:1527009224572};\\\", \\\"{x:1247,y:785,t:1527009224579};\\\", \\\"{x:1247,y:781,t:1527009224595};\\\", \\\"{x:1247,y:778,t:1527009224612};\\\", \\\"{x:1247,y:773,t:1527009224630};\\\", \\\"{x:1247,y:770,t:1527009224645};\\\", \\\"{x:1248,y:764,t:1527009224662};\\\", \\\"{x:1251,y:758,t:1527009224680};\\\", \\\"{x:1255,y:751,t:1527009224695};\\\", \\\"{x:1260,y:746,t:1527009224712};\\\", \\\"{x:1268,y:739,t:1527009224729};\\\", \\\"{x:1271,y:737,t:1527009224745};\\\", \\\"{x:1275,y:736,t:1527009224762};\\\", \\\"{x:1276,y:734,t:1527009224779};\\\", \\\"{x:1280,y:733,t:1527009224795};\\\", \\\"{x:1289,y:729,t:1527009224812};\\\", \\\"{x:1296,y:726,t:1527009224829};\\\", \\\"{x:1309,y:722,t:1527009224846};\\\", \\\"{x:1323,y:720,t:1527009224862};\\\", \\\"{x:1336,y:719,t:1527009224880};\\\", \\\"{x:1349,y:719,t:1527009224896};\\\", \\\"{x:1359,y:719,t:1527009224912};\\\", \\\"{x:1368,y:719,t:1527009224930};\\\", \\\"{x:1373,y:719,t:1527009224947};\\\", \\\"{x:1378,y:719,t:1527009224963};\\\", \\\"{x:1387,y:717,t:1527009224980};\\\", \\\"{x:1392,y:716,t:1527009224996};\\\", \\\"{x:1396,y:715,t:1527009225012};\\\", \\\"{x:1400,y:713,t:1527009225029};\\\", \\\"{x:1404,y:713,t:1527009225047};\\\", \\\"{x:1409,y:712,t:1527009225062};\\\", \\\"{x:1417,y:711,t:1527009225079};\\\", \\\"{x:1429,y:711,t:1527009225096};\\\", \\\"{x:1447,y:709,t:1527009225112};\\\", \\\"{x:1470,y:708,t:1527009225129};\\\", \\\"{x:1509,y:708,t:1527009225146};\\\", \\\"{x:1551,y:708,t:1527009225162};\\\", \\\"{x:1602,y:708,t:1527009225179};\\\", \\\"{x:1623,y:707,t:1527009225195};\\\", \\\"{x:1632,y:707,t:1527009225212};\\\", \\\"{x:1634,y:707,t:1527009225229};\\\", \\\"{x:1633,y:707,t:1527009225420};\\\", \\\"{x:1632,y:707,t:1527009225429};\\\", \\\"{x:1630,y:707,t:1527009225445};\\\", \\\"{x:1628,y:708,t:1527009225462};\\\", \\\"{x:1627,y:709,t:1527009225479};\\\", \\\"{x:1626,y:709,t:1527009225532};\\\", \\\"{x:1625,y:709,t:1527009225546};\\\", \\\"{x:1625,y:710,t:1527009225572};\\\", \\\"{x:1623,y:712,t:1527009225588};\\\", \\\"{x:1621,y:713,t:1527009225596};\\\", \\\"{x:1616,y:716,t:1527009225613};\\\", \\\"{x:1608,y:719,t:1527009225628};\\\", \\\"{x:1596,y:724,t:1527009225646};\\\", \\\"{x:1580,y:731,t:1527009225663};\\\", \\\"{x:1565,y:739,t:1527009225679};\\\", \\\"{x:1552,y:743,t:1527009225696};\\\", \\\"{x:1539,y:750,t:1527009225713};\\\", \\\"{x:1530,y:755,t:1527009225729};\\\", \\\"{x:1527,y:757,t:1527009225746};\\\", \\\"{x:1526,y:757,t:1527009225868};\\\", \\\"{x:1522,y:757,t:1527009225881};\\\", \\\"{x:1502,y:757,t:1527009225896};\\\", \\\"{x:1479,y:761,t:1527009225913};\\\", \\\"{x:1454,y:764,t:1527009225931};\\\", \\\"{x:1418,y:769,t:1527009225946};\\\", \\\"{x:1338,y:787,t:1527009225963};\\\", \\\"{x:1296,y:800,t:1527009225980};\\\", \\\"{x:1244,y:813,t:1527009225997};\\\", \\\"{x:1203,y:820,t:1527009226013};\\\", \\\"{x:1180,y:824,t:1527009226030};\\\", \\\"{x:1173,y:828,t:1527009226046};\\\", \\\"{x:1171,y:828,t:1527009226179};\\\", \\\"{x:1173,y:828,t:1527009226242};\\\", \\\"{x:1176,y:827,t:1527009226251};\\\", \\\"{x:1181,y:826,t:1527009226262};\\\", \\\"{x:1187,y:824,t:1527009226280};\\\", \\\"{x:1193,y:822,t:1527009226296};\\\", \\\"{x:1197,y:821,t:1527009226313};\\\", \\\"{x:1198,y:821,t:1527009226330};\\\", \\\"{x:1190,y:820,t:1527009230316};\\\", \\\"{x:1166,y:812,t:1527009230333};\\\", \\\"{x:1146,y:809,t:1527009230349};\\\", \\\"{x:1127,y:806,t:1527009230367};\\\", \\\"{x:1111,y:802,t:1527009230384};\\\", \\\"{x:1096,y:797,t:1527009230399};\\\", \\\"{x:1078,y:789,t:1527009230416};\\\", \\\"{x:1058,y:780,t:1527009230433};\\\", \\\"{x:1034,y:766,t:1527009230449};\\\", \\\"{x:978,y:730,t:1527009230466};\\\", \\\"{x:866,y:680,t:1527009230483};\\\", \\\"{x:766,y:652,t:1527009230499};\\\", \\\"{x:664,y:622,t:1527009230517};\\\", \\\"{x:581,y:601,t:1527009230533};\\\", \\\"{x:500,y:575,t:1527009230549};\\\", \\\"{x:437,y:561,t:1527009230567};\\\", \\\"{x:367,y:540,t:1527009230583};\\\", \\\"{x:323,y:528,t:1527009230600};\\\", \\\"{x:296,y:520,t:1527009230616};\\\", \\\"{x:283,y:514,t:1527009230633};\\\", \\\"{x:277,y:514,t:1527009230649};\\\", \\\"{x:274,y:514,t:1527009230666};\\\", \\\"{x:275,y:514,t:1527009230762};\\\", \\\"{x:277,y:514,t:1527009230772};\\\", \\\"{x:279,y:514,t:1527009230784};\\\", \\\"{x:282,y:513,t:1527009230800};\\\", \\\"{x:284,y:512,t:1527009230817};\\\", \\\"{x:286,y:511,t:1527009230833};\\\", \\\"{x:287,y:510,t:1527009230849};\\\", \\\"{x:288,y:510,t:1527009230875};\\\", \\\"{x:289,y:510,t:1527009230899};\\\", \\\"{x:290,y:509,t:1527009230915};\\\", \\\"{x:290,y:508,t:1527009230987};\\\", \\\"{x:288,y:507,t:1527009231001};\\\", \\\"{x:279,y:505,t:1527009231018};\\\", \\\"{x:266,y:501,t:1527009231036};\\\", \\\"{x:242,y:495,t:1527009231051};\\\", \\\"{x:229,y:493,t:1527009231066};\\\", \\\"{x:225,y:492,t:1527009231083};\\\", \\\"{x:223,y:492,t:1527009231187};\\\", \\\"{x:222,y:492,t:1527009231211};\\\", \\\"{x:220,y:492,t:1527009231228};\\\", \\\"{x:217,y:492,t:1527009231235};\\\", \\\"{x:214,y:492,t:1527009231250};\\\", \\\"{x:203,y:493,t:1527009231267};\\\", \\\"{x:198,y:493,t:1527009231283};\\\", \\\"{x:197,y:493,t:1527009231348};\\\", \\\"{x:196,y:494,t:1527009231372};\\\", \\\"{x:195,y:495,t:1527009231388};\\\", \\\"{x:195,y:495,t:1527009231501};\\\", \\\"{x:194,y:495,t:1527009231659};\\\", \\\"{x:192,y:495,t:1527009231668};\\\", \\\"{x:188,y:497,t:1527009231683};\\\", \\\"{x:185,y:498,t:1527009231701};\\\", \\\"{x:181,y:498,t:1527009231716};\\\", \\\"{x:175,y:501,t:1527009231734};\\\", \\\"{x:170,y:501,t:1527009231751};\\\", \\\"{x:165,y:502,t:1527009231767};\\\", \\\"{x:157,y:502,t:1527009231784};\\\", \\\"{x:153,y:502,t:1527009231801};\\\", \\\"{x:150,y:502,t:1527009231818};\\\", \\\"{x:149,y:502,t:1527009231859};\\\", \\\"{x:149,y:504,t:1527009232187};\\\", \\\"{x:150,y:504,t:1527009232251};\\\", \\\"{x:151,y:504,t:1527009232580};\\\", \\\"{x:153,y:504,t:1527009232588};\\\", \\\"{x:155,y:504,t:1527009232603};\\\", \\\"{x:157,y:503,t:1527009232617};\\\", \\\"{x:169,y:503,t:1527009232634};\\\", \\\"{x:185,y:504,t:1527009232651};\\\", \\\"{x:200,y:510,t:1527009232668};\\\", \\\"{x:216,y:515,t:1527009232685};\\\", \\\"{x:229,y:518,t:1527009232701};\\\", \\\"{x:242,y:522,t:1527009232718};\\\", \\\"{x:260,y:531,t:1527009232735};\\\", \\\"{x:272,y:536,t:1527009232751};\\\", \\\"{x:277,y:538,t:1527009232769};\\\", \\\"{x:277,y:539,t:1527009232827};\\\", \\\"{x:276,y:540,t:1527009232835};\\\", \\\"{x:263,y:540,t:1527009232853};\\\", \\\"{x:247,y:533,t:1527009232868};\\\", \\\"{x:235,y:529,t:1527009232885};\\\", \\\"{x:229,y:528,t:1527009232902};\\\", \\\"{x:219,y:524,t:1527009232918};\\\", \\\"{x:210,y:522,t:1527009232935};\\\", \\\"{x:201,y:519,t:1527009232952};\\\", \\\"{x:198,y:519,t:1527009232968};\\\", \\\"{x:197,y:518,t:1527009232985};\\\", \\\"{x:194,y:516,t:1527009233002};\\\", \\\"{x:193,y:516,t:1527009233083};\\\", \\\"{x:191,y:516,t:1527009233091};\\\", \\\"{x:191,y:515,t:1527009233102};\\\", \\\"{x:186,y:513,t:1527009233118};\\\", \\\"{x:182,y:512,t:1527009233136};\\\", \\\"{x:179,y:511,t:1527009233151};\\\", \\\"{x:176,y:509,t:1527009233168};\\\", \\\"{x:171,y:508,t:1527009233185};\\\", \\\"{x:170,y:508,t:1527009233202};\\\", \\\"{x:168,y:507,t:1527009233219};\\\", \\\"{x:167,y:506,t:1527009233243};\\\", \\\"{x:165,y:506,t:1527009233370};\\\", \\\"{x:164,y:506,t:1527009233395};\\\", \\\"{x:164,y:506,t:1527009233432};\\\", \\\"{x:168,y:507,t:1527009233740};\\\", \\\"{x:174,y:509,t:1527009233752};\\\", \\\"{x:189,y:516,t:1527009233770};\\\", \\\"{x:207,y:524,t:1527009233786};\\\", \\\"{x:246,y:546,t:1527009233803};\\\", \\\"{x:335,y:597,t:1527009233819};\\\", \\\"{x:399,y:639,t:1527009233836};\\\", \\\"{x:465,y:681,t:1527009233852};\\\", \\\"{x:508,y:711,t:1527009233869};\\\", \\\"{x:526,y:724,t:1527009233886};\\\", \\\"{x:540,y:737,t:1527009233903};\\\", \\\"{x:556,y:748,t:1527009233919};\\\", \\\"{x:562,y:753,t:1527009233936};\\\", \\\"{x:562,y:754,t:1527009233952};\\\", \\\"{x:563,y:754,t:1527009234115};\\\", \\\"{x:563,y:753,t:1527009234123};\\\", \\\"{x:561,y:752,t:1527009234138};\\\", \\\"{x:560,y:751,t:1527009234153};\\\", \\\"{x:560,y:750,t:1527009234168};\\\", \\\"{x:559,y:749,t:1527009234187};\\\" ] }, { \\\"rt\\\": 41526, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 14, \\\"time_elapsed\\\": 442074, \\\"internal_node_id\\\": \\\"0.0-6.0-4.0\\\", \\\"subject\\\": \\\"R06S6\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"echo\\\", \\\"condition\\\": \\\"121\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"ends\\\", \\\"q\\\": 10, \\\"clicks\\\": 1, \\\"explicit\\\": 1, \\\"impasse\\\": 2, \\\"axis\\\": \\\"Orthogonal-XInside-YFull\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 1, \\\"answer\\\": [ \\\"X\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-F -X \\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:558,y:724,t:1527009236500};\\\", \\\"{x:530,y:597,t:1527009236526};\\\", \\\"{x:501,y:529,t:1527009236538};\\\", \\\"{x:487,y:497,t:1527009236555};\\\", \\\"{x:441,y:418,t:1527009236571};\\\", \\\"{x:424,y:388,t:1527009236588};\\\", \\\"{x:417,y:372,t:1527009236604};\\\", \\\"{x:415,y:364,t:1527009236621};\\\", \\\"{x:412,y:357,t:1527009236638};\\\", \\\"{x:409,y:354,t:1527009236653};\\\", \\\"{x:405,y:347,t:1527009236671};\\\", \\\"{x:405,y:342,t:1527009236688};\\\", \\\"{x:405,y:341,t:1527009236704};\\\", \\\"{x:407,y:338,t:1527009236721};\\\", \\\"{x:409,y:338,t:1527009236738};\\\", \\\"{x:412,y:335,t:1527009236754};\\\", \\\"{x:413,y:335,t:1527009236771};\\\", \\\"{x:415,y:335,t:1527009236788};\\\", \\\"{x:423,y:335,t:1527009236804};\\\", \\\"{x:443,y:342,t:1527009236821};\\\", \\\"{x:459,y:349,t:1527009236838};\\\", \\\"{x:466,y:351,t:1527009236854};\\\", \\\"{x:471,y:353,t:1527009236871};\\\", \\\"{x:472,y:354,t:1527009236889};\\\", \\\"{x:475,y:357,t:1527009236904};\\\", \\\"{x:481,y:363,t:1527009236921};\\\", \\\"{x:488,y:368,t:1527009236939};\\\", \\\"{x:500,y:376,t:1527009236954};\\\", \\\"{x:522,y:388,t:1527009236971};\\\", \\\"{x:541,y:396,t:1527009236988};\\\", \\\"{x:566,y:405,t:1527009237004};\\\", \\\"{x:590,y:411,t:1527009237021};\\\", \\\"{x:615,y:419,t:1527009237038};\\\", \\\"{x:644,y:428,t:1527009237054};\\\", \\\"{x:676,y:436,t:1527009237071};\\\", \\\"{x:710,y:448,t:1527009237089};\\\", \\\"{x:742,y:462,t:1527009237104};\\\", \\\"{x:788,y:479,t:1527009237121};\\\", \\\"{x:809,y:485,t:1527009237138};\\\", \\\"{x:818,y:488,t:1527009237155};\\\", \\\"{x:821,y:492,t:1527009237171};\\\", \\\"{x:823,y:492,t:1527009237516};\\\", \\\"{x:829,y:494,t:1527009237524};\\\", \\\"{x:838,y:496,t:1527009237538};\\\", \\\"{x:889,y:511,t:1527009237555};\\\", \\\"{x:965,y:537,t:1527009237572};\\\", \\\"{x:1059,y:577,t:1527009237588};\\\", \\\"{x:1164,y:622,t:1527009237605};\\\", \\\"{x:1265,y:665,t:1527009237622};\\\", \\\"{x:1348,y:701,t:1527009237639};\\\", \\\"{x:1417,y:730,t:1527009237655};\\\", \\\"{x:1495,y:768,t:1527009237672};\\\", \\\"{x:1564,y:797,t:1527009237688};\\\", \\\"{x:1624,y:833,t:1527009237705};\\\", \\\"{x:1646,y:849,t:1527009237722};\\\", \\\"{x:1650,y:852,t:1527009237738};\\\", \\\"{x:1647,y:852,t:1527009237828};\\\", \\\"{x:1639,y:844,t:1527009237839};\\\", \\\"{x:1622,y:825,t:1527009237856};\\\", \\\"{x:1603,y:816,t:1527009237873};\\\", \\\"{x:1577,y:812,t:1527009237890};\\\", \\\"{x:1551,y:809,t:1527009237906};\\\", \\\"{x:1528,y:807,t:1527009237922};\\\", \\\"{x:1511,y:807,t:1527009237938};\\\", \\\"{x:1508,y:807,t:1527009237956};\\\", \\\"{x:1507,y:807,t:1527009237973};\\\", \\\"{x:1504,y:808,t:1527009237990};\\\", \\\"{x:1502,y:809,t:1527009238005};\\\", \\\"{x:1501,y:809,t:1527009238023};\\\", \\\"{x:1499,y:809,t:1527009238040};\\\", \\\"{x:1497,y:810,t:1527009238055};\\\", \\\"{x:1491,y:811,t:1527009238073};\\\", \\\"{x:1487,y:812,t:1527009238089};\\\", \\\"{x:1477,y:814,t:1527009238105};\\\", \\\"{x:1463,y:814,t:1527009238123};\\\", \\\"{x:1449,y:814,t:1527009238140};\\\", \\\"{x:1444,y:814,t:1527009238156};\\\", \\\"{x:1437,y:814,t:1527009238173};\\\", \\\"{x:1429,y:814,t:1527009238189};\\\", \\\"{x:1421,y:813,t:1527009238206};\\\", \\\"{x:1417,y:812,t:1527009238222};\\\", \\\"{x:1416,y:812,t:1527009238284};\\\", \\\"{x:1415,y:812,t:1527009238299};\\\", \\\"{x:1413,y:809,t:1527009238308};\\\", \\\"{x:1410,y:805,t:1527009238322};\\\", \\\"{x:1377,y:783,t:1527009238339};\\\", \\\"{x:1355,y:769,t:1527009238356};\\\", \\\"{x:1338,y:756,t:1527009238373};\\\", \\\"{x:1328,y:749,t:1527009238390};\\\", \\\"{x:1324,y:745,t:1527009238407};\\\", \\\"{x:1322,y:744,t:1527009238423};\\\", \\\"{x:1322,y:743,t:1527009238439};\\\", \\\"{x:1324,y:743,t:1527009238459};\\\", \\\"{x:1324,y:742,t:1527009238473};\\\", \\\"{x:1325,y:741,t:1527009238490};\\\", \\\"{x:1328,y:739,t:1527009238507};\\\", \\\"{x:1329,y:737,t:1527009238522};\\\", \\\"{x:1333,y:735,t:1527009238540};\\\", \\\"{x:1335,y:733,t:1527009238557};\\\", \\\"{x:1337,y:731,t:1527009238573};\\\", \\\"{x:1340,y:729,t:1527009238590};\\\", \\\"{x:1344,y:726,t:1527009238607};\\\", \\\"{x:1348,y:725,t:1527009238623};\\\", \\\"{x:1351,y:724,t:1527009238640};\\\", \\\"{x:1353,y:722,t:1527009238657};\\\", \\\"{x:1355,y:721,t:1527009238673};\\\", \\\"{x:1356,y:720,t:1527009238724};\\\", \\\"{x:1356,y:718,t:1527009245244};\\\", \\\"{x:1354,y:715,t:1527009245261};\\\", \\\"{x:1354,y:713,t:1527009245277};\\\", \\\"{x:1354,y:712,t:1527009245294};\\\", \\\"{x:1354,y:710,t:1527009245323};\\\", \\\"{x:1354,y:709,t:1527009245331};\\\", \\\"{x:1353,y:709,t:1527009245420};\\\", \\\"{x:1352,y:709,t:1527009274143};\\\", \\\"{x:1334,y:709,t:1527009274150};\\\", \\\"{x:1299,y:711,t:1527009274166};\\\", \\\"{x:1181,y:718,t:1527009274182};\\\", \\\"{x:1076,y:718,t:1527009274198};\\\", \\\"{x:972,y:713,t:1527009274216};\\\", \\\"{x:872,y:698,t:1527009274232};\\\", \\\"{x:804,y:685,t:1527009274248};\\\", \\\"{x:762,y:678,t:1527009274265};\\\", \\\"{x:747,y:676,t:1527009274281};\\\", \\\"{x:745,y:675,t:1527009274299};\\\", \\\"{x:744,y:675,t:1527009274326};\\\", \\\"{x:742,y:675,t:1527009274334};\\\", \\\"{x:739,y:674,t:1527009274348};\\\", \\\"{x:730,y:672,t:1527009274366};\\\", \\\"{x:722,y:670,t:1527009274381};\\\", \\\"{x:713,y:667,t:1527009274398};\\\", \\\"{x:710,y:665,t:1527009274415};\\\", \\\"{x:708,y:664,t:1527009274433};\\\", \\\"{x:703,y:662,t:1527009274448};\\\", \\\"{x:692,y:657,t:1527009274465};\\\", \\\"{x:677,y:651,t:1527009274481};\\\", \\\"{x:658,y:642,t:1527009274498};\\\", \\\"{x:640,y:635,t:1527009274515};\\\", \\\"{x:628,y:630,t:1527009274535};\\\", \\\"{x:621,y:628,t:1527009274548};\\\", \\\"{x:618,y:627,t:1527009274565};\\\", \\\"{x:614,y:627,t:1527009274581};\\\", \\\"{x:607,y:627,t:1527009274597};\\\", \\\"{x:597,y:627,t:1527009274615};\\\", \\\"{x:586,y:627,t:1527009274632};\\\", \\\"{x:560,y:627,t:1527009274653};\\\", \\\"{x:539,y:627,t:1527009274671};\\\", \\\"{x:519,y:627,t:1527009274688};\\\", \\\"{x:494,y:627,t:1527009274704};\\\", \\\"{x:474,y:627,t:1527009274721};\\\", \\\"{x:456,y:626,t:1527009274738};\\\", \\\"{x:442,y:625,t:1527009274755};\\\", \\\"{x:435,y:624,t:1527009274770};\\\", \\\"{x:433,y:624,t:1527009274788};\\\", \\\"{x:432,y:624,t:1527009274846};\\\", \\\"{x:429,y:624,t:1527009274862};\\\", \\\"{x:428,y:624,t:1527009274871};\\\", \\\"{x:425,y:623,t:1527009274888};\\\", \\\"{x:422,y:622,t:1527009274905};\\\", \\\"{x:419,y:622,t:1527009274921};\\\", \\\"{x:408,y:619,t:1527009274938};\\\", \\\"{x:394,y:615,t:1527009274954};\\\", \\\"{x:376,y:611,t:1527009274970};\\\", \\\"{x:357,y:606,t:1527009274988};\\\", \\\"{x:339,y:603,t:1527009275004};\\\", \\\"{x:320,y:601,t:1527009275021};\\\", \\\"{x:309,y:598,t:1527009275038};\\\", \\\"{x:304,y:598,t:1527009275055};\\\", \\\"{x:301,y:598,t:1527009275071};\\\", \\\"{x:298,y:598,t:1527009275087};\\\", \\\"{x:292,y:598,t:1527009275105};\\\", \\\"{x:286,y:599,t:1527009275122};\\\", \\\"{x:280,y:600,t:1527009275137};\\\", \\\"{x:276,y:602,t:1527009275155};\\\", \\\"{x:273,y:603,t:1527009275172};\\\", \\\"{x:271,y:605,t:1527009275188};\\\", \\\"{x:272,y:608,t:1527009275204};\\\", \\\"{x:279,y:611,t:1527009275222};\\\", \\\"{x:301,y:611,t:1527009275238};\\\", \\\"{x:336,y:611,t:1527009275255};\\\", \\\"{x:398,y:611,t:1527009275272};\\\", \\\"{x:473,y:611,t:1527009275288};\\\", \\\"{x:531,y:611,t:1527009275305};\\\", \\\"{x:595,y:611,t:1527009275321};\\\", \\\"{x:681,y:611,t:1527009275339};\\\", \\\"{x:759,y:611,t:1527009275355};\\\", \\\"{x:818,y:611,t:1527009275372};\\\", \\\"{x:873,y:607,t:1527009275389};\\\", \\\"{x:888,y:608,t:1527009275405};\\\", \\\"{x:902,y:608,t:1527009275421};\\\", \\\"{x:909,y:611,t:1527009275439};\\\", \\\"{x:923,y:613,t:1527009275454};\\\", \\\"{x:926,y:613,t:1527009275472};\\\", \\\"{x:928,y:613,t:1527009275489};\\\", \\\"{x:929,y:613,t:1527009275517};\\\", \\\"{x:923,y:611,t:1527009275526};\\\", \\\"{x:919,y:610,t:1527009275539};\\\", \\\"{x:907,y:606,t:1527009275555};\\\", \\\"{x:905,y:606,t:1527009275572};\\\", \\\"{x:899,y:605,t:1527009275589};\\\", \\\"{x:886,y:605,t:1527009275605};\\\", \\\"{x:865,y:605,t:1527009275623};\\\", \\\"{x:846,y:607,t:1527009275639};\\\", \\\"{x:824,y:610,t:1527009275655};\\\", \\\"{x:799,y:614,t:1527009275672};\\\", \\\"{x:769,y:619,t:1527009275689};\\\", \\\"{x:751,y:621,t:1527009275705};\\\", \\\"{x:733,y:625,t:1527009275722};\\\", \\\"{x:718,y:625,t:1527009275739};\\\", \\\"{x:699,y:625,t:1527009275756};\\\", \\\"{x:682,y:622,t:1527009275771};\\\", \\\"{x:663,y:613,t:1527009275789};\\\", \\\"{x:641,y:599,t:1527009275806};\\\", \\\"{x:635,y:595,t:1527009275822};\\\", \\\"{x:631,y:592,t:1527009275840};\\\", \\\"{x:629,y:589,t:1527009275856};\\\", \\\"{x:624,y:585,t:1527009275872};\\\", \\\"{x:619,y:579,t:1527009275889};\\\", \\\"{x:612,y:575,t:1527009275906};\\\", \\\"{x:602,y:568,t:1527009275922};\\\", \\\"{x:593,y:564,t:1527009275940};\\\", \\\"{x:584,y:561,t:1527009275956};\\\", \\\"{x:574,y:558,t:1527009275972};\\\", \\\"{x:565,y:557,t:1527009275988};\\\", \\\"{x:560,y:557,t:1527009276005};\\\", \\\"{x:562,y:557,t:1527009276069};\\\", \\\"{x:565,y:559,t:1527009276078};\\\", \\\"{x:567,y:560,t:1527009276089};\\\", \\\"{x:572,y:563,t:1527009276106};\\\", \\\"{x:577,y:567,t:1527009276122};\\\", \\\"{x:579,y:569,t:1527009276139};\\\", \\\"{x:580,y:570,t:1527009276156};\\\", \\\"{x:582,y:570,t:1527009276198};\\\", \\\"{x:584,y:570,t:1527009276214};\\\", \\\"{x:587,y:572,t:1527009276223};\\\", \\\"{x:591,y:574,t:1527009276240};\\\", \\\"{x:598,y:576,t:1527009276255};\\\", \\\"{x:602,y:578,t:1527009276273};\\\", \\\"{x:605,y:578,t:1527009276289};\\\", \\\"{x:606,y:579,t:1527009276305};\\\", \\\"{x:605,y:586,t:1527009276725};\\\", \\\"{x:599,y:596,t:1527009276741};\\\", \\\"{x:580,y:625,t:1527009276757};\\\", \\\"{x:562,y:655,t:1527009276773};\\\", \\\"{x:552,y:672,t:1527009276789};\\\", \\\"{x:548,y:685,t:1527009276805};\\\", \\\"{x:543,y:695,t:1527009276822};\\\", \\\"{x:542,y:704,t:1527009276840};\\\", \\\"{x:542,y:709,t:1527009276856};\\\", \\\"{x:542,y:712,t:1527009276873};\\\", \\\"{x:542,y:715,t:1527009276889};\\\", \\\"{x:542,y:720,t:1527009276906};\\\", \\\"{x:541,y:723,t:1527009276922};\\\", \\\"{x:540,y:729,t:1527009276940};\\\", \\\"{x:538,y:733,t:1527009276957};\\\", \\\"{x:538,y:734,t:1527009276973};\\\", \\\"{x:537,y:735,t:1527009277029};\\\", \\\"{x:536,y:736,t:1527009277040};\\\", \\\"{x:535,y:737,t:1527009277057};\\\", \\\"{x:535,y:739,t:1527009277074};\\\", \\\"{x:535,y:740,t:1527009277974};\\\", \\\"{x:539,y:741,t:1527009277990};\\\", \\\"{x:542,y:743,t:1527009278007};\\\", \\\"{x:543,y:743,t:1527009278024};\\\" ] }, { \\\"rt\\\": 10850, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 15, \\\"time_elapsed\\\": 454205, \\\"internal_node_id\\\": \\\"0.0-6.0-5.0\\\", \\\"subject\\\": \\\"R06S6\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"echo\\\", \\\"condition\\\": \\\"121\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"starttime\\\", \\\"q\\\": 11, \\\"clicks\\\": 2, \\\"explicit\\\": 1, \\\"impasse\\\": 2, \\\"axis\\\": \\\"Orthogonal-XInside-YFull\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 1, \\\"answer\\\": [ \\\"F\\\", \\\"B\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-01 PM-12 PM-12 PM\\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:543,y:740,t:1527009280349};\\\", \\\"{x:543,y:736,t:1527009280360};\\\", \\\"{x:543,y:723,t:1527009280377};\\\", \\\"{x:543,y:721,t:1527009280394};\\\", \\\"{x:542,y:717,t:1527009280412};\\\", \\\"{x:539,y:716,t:1527009280426};\\\", \\\"{x:539,y:714,t:1527009280441};\\\", \\\"{x:539,y:705,t:1527009280457};\\\", \\\"{x:542,y:695,t:1527009280473};\\\", \\\"{x:545,y:691,t:1527009280491};\\\", \\\"{x:547,y:685,t:1527009280507};\\\", \\\"{x:550,y:672,t:1527009280524};\\\", \\\"{x:556,y:649,t:1527009280542};\\\", \\\"{x:557,y:639,t:1527009280557};\\\", \\\"{x:562,y:627,t:1527009280575};\\\", \\\"{x:565,y:610,t:1527009280591};\\\", \\\"{x:572,y:598,t:1527009280610};\\\", \\\"{x:576,y:588,t:1527009280626};\\\", \\\"{x:585,y:573,t:1527009280642};\\\", \\\"{x:593,y:551,t:1527009280660};\\\", \\\"{x:602,y:535,t:1527009280677};\\\", \\\"{x:607,y:519,t:1527009280693};\\\", \\\"{x:611,y:503,t:1527009280709};\\\", \\\"{x:614,y:499,t:1527009280725};\\\", \\\"{x:618,y:488,t:1527009280743};\\\", \\\"{x:622,y:482,t:1527009280760};\\\", \\\"{x:622,y:479,t:1527009280776};\\\", \\\"{x:623,y:478,t:1527009280792};\\\", \\\"{x:625,y:478,t:1527009280809};\\\", \\\"{x:626,y:478,t:1527009281174};\\\", \\\"{x:628,y:478,t:1527009281662};\\\", \\\"{x:637,y:481,t:1527009281674};\\\", \\\"{x:664,y:489,t:1527009281692};\\\", \\\"{x:744,y:514,t:1527009281709};\\\", \\\"{x:842,y:544,t:1527009281724};\\\", \\\"{x:948,y:583,t:1527009281742};\\\", \\\"{x:1150,y:643,t:1527009281761};\\\", \\\"{x:1295,y:691,t:1527009281777};\\\", \\\"{x:1443,y:726,t:1527009281793};\\\", \\\"{x:1554,y:740,t:1527009281810};\\\", \\\"{x:1602,y:745,t:1527009281827};\\\", \\\"{x:1624,y:745,t:1527009281844};\\\", \\\"{x:1629,y:745,t:1527009281860};\\\", \\\"{x:1631,y:745,t:1527009281878};\\\", \\\"{x:1632,y:745,t:1527009281910};\\\", \\\"{x:1633,y:753,t:1527009281991};\\\", \\\"{x:1633,y:764,t:1527009281998};\\\", \\\"{x:1631,y:777,t:1527009282011};\\\", \\\"{x:1617,y:809,t:1527009282029};\\\", \\\"{x:1596,y:845,t:1527009282045};\\\", \\\"{x:1561,y:884,t:1527009282062};\\\", \\\"{x:1547,y:895,t:1527009282079};\\\", \\\"{x:1538,y:901,t:1527009282094};\\\", \\\"{x:1530,y:908,t:1527009282111};\\\", \\\"{x:1525,y:915,t:1527009282129};\\\", \\\"{x:1520,y:921,t:1527009282146};\\\", \\\"{x:1516,y:927,t:1527009282162};\\\", \\\"{x:1511,y:931,t:1527009282178};\\\", \\\"{x:1508,y:933,t:1527009282196};\\\", \\\"{x:1500,y:938,t:1527009282213};\\\", \\\"{x:1494,y:940,t:1527009282229};\\\", \\\"{x:1484,y:944,t:1527009282245};\\\", \\\"{x:1478,y:948,t:1527009282262};\\\", \\\"{x:1470,y:952,t:1527009282278};\\\", \\\"{x:1461,y:956,t:1527009282296};\\\", \\\"{x:1448,y:960,t:1527009282312};\\\", \\\"{x:1434,y:962,t:1527009282330};\\\", \\\"{x:1424,y:964,t:1527009282346};\\\", \\\"{x:1417,y:965,t:1527009282363};\\\", \\\"{x:1411,y:965,t:1527009282379};\\\", \\\"{x:1404,y:966,t:1527009282396};\\\", \\\"{x:1401,y:968,t:1527009282412};\\\", \\\"{x:1397,y:969,t:1527009282429};\\\", \\\"{x:1394,y:970,t:1527009282447};\\\", \\\"{x:1388,y:972,t:1527009282462};\\\", \\\"{x:1386,y:972,t:1527009282480};\\\", \\\"{x:1384,y:972,t:1527009282496};\\\", \\\"{x:1383,y:972,t:1527009282514};\\\", \\\"{x:1381,y:972,t:1527009282529};\\\", \\\"{x:1380,y:972,t:1527009282549};\\\", \\\"{x:1377,y:972,t:1527009282564};\\\", \\\"{x:1375,y:972,t:1527009282581};\\\", \\\"{x:1371,y:972,t:1527009282597};\\\", \\\"{x:1367,y:973,t:1527009282614};\\\", \\\"{x:1366,y:973,t:1527009282631};\\\", \\\"{x:1363,y:975,t:1527009282647};\\\", \\\"{x:1362,y:975,t:1527009282663};\\\", \\\"{x:1361,y:976,t:1527009282693};\\\", \\\"{x:1360,y:977,t:1527009282702};\\\", \\\"{x:1360,y:978,t:1527009282717};\\\", \\\"{x:1359,y:979,t:1527009282730};\\\", \\\"{x:1359,y:982,t:1527009282747};\\\", \\\"{x:1359,y:984,t:1527009282764};\\\", \\\"{x:1357,y:988,t:1527009282781};\\\", \\\"{x:1357,y:991,t:1527009282797};\\\", \\\"{x:1357,y:992,t:1527009282815};\\\", \\\"{x:1357,y:994,t:1527009282831};\\\", \\\"{x:1357,y:995,t:1527009282847};\\\", \\\"{x:1357,y:994,t:1527009283181};\\\", \\\"{x:1357,y:992,t:1527009283199};\\\", \\\"{x:1357,y:991,t:1527009283222};\\\", \\\"{x:1357,y:990,t:1527009283254};\\\", \\\"{x:1357,y:989,t:1527009283350};\\\", \\\"{x:1357,y:988,t:1527009283446};\\\", \\\"{x:1357,y:987,t:1527009283478};\\\", \\\"{x:1357,y:986,t:1527009283494};\\\", \\\"{x:1357,y:985,t:1527009283543};\\\", \\\"{x:1357,y:984,t:1527009283567};\\\", \\\"{x:1357,y:983,t:1527009283598};\\\", \\\"{x:1357,y:982,t:1527009283798};\\\", \\\"{x:1357,y:981,t:1527009283886};\\\", \\\"{x:1357,y:980,t:1527009283951};\\\", \\\"{x:1357,y:979,t:1527009283965};\\\", \\\"{x:1357,y:978,t:1527009283982};\\\", \\\"{x:1357,y:977,t:1527009284006};\\\", \\\"{x:1357,y:976,t:1527009284022};\\\", \\\"{x:1357,y:975,t:1527009284046};\\\", \\\"{x:1357,y:974,t:1527009284077};\\\", \\\"{x:1357,y:973,t:1527009284110};\\\", \\\"{x:1357,y:970,t:1527009284510};\\\", \\\"{x:1357,y:963,t:1527009284522};\\\", \\\"{x:1355,y:960,t:1527009284537};\\\", \\\"{x:1351,y:958,t:1527009284911};\\\", \\\"{x:1342,y:957,t:1527009284922};\\\", \\\"{x:1336,y:953,t:1527009284938};\\\", \\\"{x:1336,y:951,t:1527009284956};\\\", \\\"{x:1336,y:950,t:1527009284972};\\\", \\\"{x:1336,y:949,t:1527009284989};\\\", \\\"{x:1336,y:947,t:1527009285005};\\\", \\\"{x:1336,y:946,t:1527009285021};\\\", \\\"{x:1336,y:943,t:1527009285039};\\\", \\\"{x:1336,y:938,t:1527009285056};\\\", \\\"{x:1336,y:933,t:1527009285072};\\\", \\\"{x:1335,y:930,t:1527009285089};\\\", \\\"{x:1335,y:928,t:1527009285106};\\\", \\\"{x:1330,y:925,t:1527009285123};\\\", \\\"{x:1321,y:921,t:1527009285140};\\\", \\\"{x:1308,y:917,t:1527009285156};\\\", \\\"{x:1301,y:914,t:1527009285173};\\\", \\\"{x:1297,y:912,t:1527009285190};\\\", \\\"{x:1290,y:909,t:1527009285205};\\\", \\\"{x:1279,y:904,t:1527009285223};\\\", \\\"{x:1263,y:898,t:1527009285239};\\\", \\\"{x:1251,y:893,t:1527009285256};\\\", \\\"{x:1242,y:889,t:1527009285273};\\\", \\\"{x:1225,y:882,t:1527009285290};\\\", \\\"{x:1205,y:871,t:1527009285307};\\\", \\\"{x:1175,y:858,t:1527009285323};\\\", \\\"{x:1123,y:837,t:1527009285340};\\\", \\\"{x:1073,y:821,t:1527009285357};\\\", \\\"{x:997,y:797,t:1527009285374};\\\", \\\"{x:970,y:789,t:1527009285390};\\\", \\\"{x:944,y:778,t:1527009285407};\\\", \\\"{x:924,y:771,t:1527009285423};\\\", \\\"{x:909,y:764,t:1527009285440};\\\", \\\"{x:892,y:758,t:1527009285456};\\\", \\\"{x:872,y:750,t:1527009285474};\\\", \\\"{x:851,y:745,t:1527009285490};\\\", \\\"{x:823,y:736,t:1527009285506};\\\", \\\"{x:788,y:726,t:1527009285523};\\\", \\\"{x:751,y:714,t:1527009285541};\\\", \\\"{x:704,y:701,t:1527009285558};\\\", \\\"{x:675,y:690,t:1527009285574};\\\", \\\"{x:657,y:684,t:1527009285591};\\\", \\\"{x:648,y:677,t:1527009285608};\\\", \\\"{x:645,y:674,t:1527009285624};\\\", \\\"{x:639,y:670,t:1527009285640};\\\", \\\"{x:634,y:667,t:1527009285657};\\\", \\\"{x:623,y:662,t:1527009285674};\\\", \\\"{x:608,y:654,t:1527009285690};\\\", \\\"{x:589,y:646,t:1527009285707};\\\", \\\"{x:576,y:637,t:1527009285724};\\\", \\\"{x:562,y:624,t:1527009285741};\\\", \\\"{x:555,y:614,t:1527009285756};\\\", \\\"{x:548,y:602,t:1527009285774};\\\", \\\"{x:544,y:594,t:1527009285796};\\\", \\\"{x:543,y:589,t:1527009285813};\\\", \\\"{x:542,y:581,t:1527009285830};\\\", \\\"{x:542,y:576,t:1527009285846};\\\", \\\"{x:542,y:565,t:1527009285863};\\\", \\\"{x:545,y:554,t:1527009285880};\\\", \\\"{x:547,y:543,t:1527009285896};\\\", \\\"{x:552,y:531,t:1527009285912};\\\", \\\"{x:562,y:521,t:1527009285931};\\\", \\\"{x:573,y:514,t:1527009285947};\\\", \\\"{x:589,y:508,t:1527009285963};\\\", \\\"{x:602,y:501,t:1527009285981};\\\", \\\"{x:619,y:494,t:1527009285997};\\\", \\\"{x:632,y:488,t:1527009286013};\\\", \\\"{x:653,y:483,t:1527009286031};\\\", \\\"{x:682,y:481,t:1527009286046};\\\", \\\"{x:719,y:475,t:1527009286063};\\\", \\\"{x:754,y:469,t:1527009286081};\\\", \\\"{x:781,y:464,t:1527009286096};\\\", \\\"{x:800,y:463,t:1527009286113};\\\", \\\"{x:817,y:460,t:1527009286130};\\\", \\\"{x:830,y:457,t:1527009286146};\\\", \\\"{x:851,y:457,t:1527009286163};\\\", \\\"{x:872,y:457,t:1527009286181};\\\", \\\"{x:897,y:457,t:1527009286196};\\\", \\\"{x:922,y:461,t:1527009286213};\\\", \\\"{x:934,y:465,t:1527009286230};\\\", \\\"{x:938,y:467,t:1527009286246};\\\", \\\"{x:940,y:468,t:1527009286263};\\\", \\\"{x:938,y:473,t:1527009286280};\\\", \\\"{x:933,y:476,t:1527009286296};\\\", \\\"{x:923,y:481,t:1527009286312};\\\", \\\"{x:919,y:484,t:1527009286330};\\\", \\\"{x:914,y:487,t:1527009286347};\\\", \\\"{x:910,y:489,t:1527009286363};\\\", \\\"{x:903,y:491,t:1527009286380};\\\", \\\"{x:894,y:495,t:1527009286397};\\\", \\\"{x:887,y:497,t:1527009286414};\\\", \\\"{x:882,y:498,t:1527009286431};\\\", \\\"{x:877,y:499,t:1527009286447};\\\", \\\"{x:874,y:499,t:1527009286464};\\\", \\\"{x:870,y:499,t:1527009286481};\\\", \\\"{x:863,y:499,t:1527009286498};\\\", \\\"{x:856,y:499,t:1527009286514};\\\", \\\"{x:847,y:501,t:1527009286530};\\\", \\\"{x:844,y:501,t:1527009286547};\\\", \\\"{x:843,y:501,t:1527009286564};\\\", \\\"{x:841,y:501,t:1527009286613};\\\", \\\"{x:840,y:501,t:1527009286621};\\\", \\\"{x:836,y:501,t:1527009286630};\\\", \\\"{x:830,y:501,t:1527009286647};\\\", \\\"{x:829,y:501,t:1527009286664};\\\", \\\"{x:831,y:501,t:1527009286956};\\\", \\\"{x:832,y:501,t:1527009286997};\\\", \\\"{x:833,y:501,t:1527009287174};\\\", \\\"{x:830,y:502,t:1527009287182};\\\", \\\"{x:801,y:513,t:1527009287199};\\\", \\\"{x:752,y:525,t:1527009287215};\\\", \\\"{x:662,y:540,t:1527009287232};\\\", \\\"{x:545,y:561,t:1527009287247};\\\", \\\"{x:434,y:575,t:1527009287265};\\\", \\\"{x:345,y:579,t:1527009287281};\\\", \\\"{x:283,y:581,t:1527009287297};\\\", \\\"{x:241,y:581,t:1527009287315};\\\", \\\"{x:217,y:581,t:1527009287331};\\\", \\\"{x:203,y:582,t:1527009287348};\\\", \\\"{x:195,y:584,t:1527009287364};\\\", \\\"{x:171,y:591,t:1527009287381};\\\", \\\"{x:150,y:596,t:1527009287399};\\\", \\\"{x:140,y:597,t:1527009287414};\\\", \\\"{x:132,y:597,t:1527009287431};\\\", \\\"{x:131,y:597,t:1527009287460};\\\", \\\"{x:131,y:596,t:1527009287476};\\\", \\\"{x:132,y:593,t:1527009287485};\\\", \\\"{x:134,y:592,t:1527009287498};\\\", \\\"{x:136,y:588,t:1527009287514};\\\", \\\"{x:139,y:582,t:1527009287531};\\\", \\\"{x:141,y:577,t:1527009287548};\\\", \\\"{x:141,y:574,t:1527009287564};\\\", \\\"{x:143,y:568,t:1527009287581};\\\", \\\"{x:143,y:566,t:1527009287598};\\\", \\\"{x:143,y:561,t:1527009287615};\\\", \\\"{x:144,y:557,t:1527009287631};\\\", \\\"{x:145,y:548,t:1527009287649};\\\", \\\"{x:148,y:538,t:1527009287664};\\\", \\\"{x:152,y:530,t:1527009287682};\\\", \\\"{x:153,y:527,t:1527009287699};\\\", \\\"{x:154,y:526,t:1527009287715};\\\", \\\"{x:155,y:526,t:1527009287731};\\\", \\\"{x:159,y:524,t:1527009287749};\\\", \\\"{x:163,y:522,t:1527009287765};\\\", \\\"{x:165,y:521,t:1527009287781};\\\", \\\"{x:167,y:520,t:1527009287798};\\\", \\\"{x:166,y:520,t:1527009288021};\\\", \\\"{x:165,y:520,t:1527009288031};\\\", \\\"{x:164,y:520,t:1527009288070};\\\", \\\"{x:163,y:522,t:1527009288094};\\\", \\\"{x:162,y:523,t:1527009288110};\\\", \\\"{x:162,y:524,t:1527009288118};\\\", \\\"{x:162,y:525,t:1527009288132};\\\", \\\"{x:162,y:528,t:1527009288149};\\\", \\\"{x:162,y:531,t:1527009288165};\\\", \\\"{x:161,y:534,t:1527009288182};\\\", \\\"{x:161,y:535,t:1527009288198};\\\", \\\"{x:161,y:536,t:1527009288215};\\\", \\\"{x:161,y:537,t:1527009288261};\\\", \\\"{x:161,y:538,t:1527009288277};\\\", \\\"{x:161,y:539,t:1527009288293};\\\", \\\"{x:162,y:544,t:1527009288710};\\\", \\\"{x:170,y:548,t:1527009288718};\\\", \\\"{x:188,y:560,t:1527009288733};\\\", \\\"{x:250,y:616,t:1527009288750};\\\", \\\"{x:290,y:661,t:1527009288766};\\\", \\\"{x:331,y:705,t:1527009288783};\\\", \\\"{x:377,y:742,t:1527009288799};\\\", \\\"{x:419,y:769,t:1527009288816};\\\", \\\"{x:437,y:778,t:1527009288833};\\\", \\\"{x:448,y:780,t:1527009288850};\\\", \\\"{x:454,y:780,t:1527009288866};\\\", \\\"{x:460,y:780,t:1527009288882};\\\", \\\"{x:468,y:780,t:1527009288899};\\\", \\\"{x:475,y:780,t:1527009288917};\\\", \\\"{x:483,y:777,t:1527009288933};\\\", \\\"{x:494,y:774,t:1527009288949};\\\", \\\"{x:502,y:774,t:1527009288966};\\\", \\\"{x:511,y:773,t:1527009288984};\\\", \\\"{x:520,y:773,t:1527009288999};\\\", \\\"{x:526,y:772,t:1527009289016};\\\", \\\"{x:533,y:769,t:1527009289033};\\\", \\\"{x:535,y:766,t:1527009289049};\\\", \\\"{x:536,y:761,t:1527009289067};\\\", \\\"{x:538,y:758,t:1527009289083};\\\", \\\"{x:539,y:755,t:1527009289101};\\\", \\\"{x:540,y:753,t:1527009289117};\\\", \\\"{x:540,y:751,t:1527009289133};\\\", \\\"{x:540,y:750,t:1527009289149};\\\", \\\"{x:540,y:749,t:1527009289167};\\\", \\\"{x:540,y:748,t:1527009289184};\\\", \\\"{x:540,y:746,t:1527009289493};\\\", \\\"{x:540,y:745,t:1527009289501};\\\", \\\"{x:541,y:744,t:1527009289516};\\\", \\\"{x:542,y:742,t:1527009289533};\\\", \\\"{x:545,y:739,t:1527009289549};\\\", \\\"{x:545,y:738,t:1527009289567};\\\", \\\"{x:550,y:736,t:1527009289582};\\\", \\\"{x:550,y:735,t:1527009289599};\\\", \\\"{x:550,y:734,t:1527009289636};\\\", \\\"{x:553,y:734,t:1527009289749};\\\", \\\"{x:554,y:733,t:1527009290069};\\\", \\\"{x:555,y:733,t:1527009290083};\\\", \\\"{x:555,y:732,t:1527009290100};\\\", \\\"{x:556,y:732,t:1527009290342};\\\", \\\"{x:556,y:733,t:1527009290366};\\\", \\\"{x:553,y:733,t:1527009290383};\\\", \\\"{x:551,y:734,t:1527009290400};\\\", \\\"{x:549,y:734,t:1527009290416};\\\", \\\"{x:547,y:733,t:1527009290433};\\\" ] }, { \\\"rt\\\": 8931, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 16, \\\"time_elapsed\\\": 464406, \\\"internal_node_id\\\": \\\"0.0-6.0-6.0\\\", \\\"subject\\\": \\\"R06S6\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"echo\\\", \\\"condition\\\": \\\"121\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"starts\\\", \\\"q\\\": 12, \\\"clicks\\\": 1, \\\"explicit\\\": 1, \\\"impasse\\\": 2, \\\"axis\\\": \\\"Orthogonal-XInside-YFull\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 1, \\\"answer\\\": [ \\\"B\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"\\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:545,y:733,t:1527009290603};\\\", \\\"{x:544,y:733,t:1527009290733};\\\", \\\"{x:544,y:734,t:1527009290750};\\\", \\\"{x:543,y:737,t:1527009290787};\\\", \\\"{x:540,y:738,t:1527009290800};\\\", \\\"{x:535,y:739,t:1527009290818};\\\", \\\"{x:533,y:740,t:1527009290833};\\\", \\\"{x:531,y:741,t:1527009290850};\\\", \\\"{x:529,y:740,t:1527009291117};\\\", \\\"{x:531,y:724,t:1527009291134};\\\", \\\"{x:533,y:705,t:1527009291151};\\\", \\\"{x:533,y:688,t:1527009291167};\\\", \\\"{x:527,y:673,t:1527009291184};\\\", \\\"{x:510,y:651,t:1527009291200};\\\", \\\"{x:491,y:628,t:1527009291218};\\\", \\\"{x:477,y:612,t:1527009291234};\\\", \\\"{x:468,y:598,t:1527009291251};\\\", \\\"{x:455,y:580,t:1527009291268};\\\", \\\"{x:445,y:571,t:1527009291284};\\\", \\\"{x:439,y:566,t:1527009291300};\\\", \\\"{x:433,y:562,t:1527009291317};\\\", \\\"{x:429,y:560,t:1527009291335};\\\", \\\"{x:428,y:559,t:1527009291351};\\\", \\\"{x:425,y:557,t:1527009291367};\\\", \\\"{x:425,y:556,t:1527009291384};\\\", \\\"{x:424,y:556,t:1527009291401};\\\", \\\"{x:424,y:555,t:1527009291453};\\\", \\\"{x:424,y:552,t:1527009291467};\\\", \\\"{x:424,y:538,t:1527009291484};\\\", \\\"{x:431,y:514,t:1527009291501};\\\", \\\"{x:436,y:506,t:1527009291517};\\\", \\\"{x:439,y:503,t:1527009291534};\\\", \\\"{x:442,y:500,t:1527009291551};\\\", \\\"{x:443,y:498,t:1527009291568};\\\", \\\"{x:445,y:496,t:1527009291584};\\\", \\\"{x:448,y:494,t:1527009291602};\\\", \\\"{x:452,y:492,t:1527009291617};\\\", \\\"{x:454,y:490,t:1527009291634};\\\", \\\"{x:457,y:490,t:1527009291652};\\\", \\\"{x:461,y:489,t:1527009291668};\\\", \\\"{x:462,y:489,t:1527009291684};\\\", \\\"{x:465,y:487,t:1527009291701};\\\", \\\"{x:466,y:487,t:1527009291717};\\\", \\\"{x:468,y:487,t:1527009291735};\\\", \\\"{x:472,y:486,t:1527009291753};\\\", \\\"{x:478,y:485,t:1527009291768};\\\", \\\"{x:482,y:483,t:1527009291784};\\\", \\\"{x:485,y:482,t:1527009291801};\\\", \\\"{x:491,y:481,t:1527009291818};\\\", \\\"{x:498,y:480,t:1527009291834};\\\", \\\"{x:508,y:480,t:1527009291851};\\\", \\\"{x:525,y:480,t:1527009291868};\\\", \\\"{x:550,y:480,t:1527009291884};\\\", \\\"{x:595,y:480,t:1527009291901};\\\", \\\"{x:622,y:480,t:1527009291918};\\\", \\\"{x:644,y:480,t:1527009291935};\\\", \\\"{x:662,y:480,t:1527009291951};\\\", \\\"{x:681,y:480,t:1527009291968};\\\", \\\"{x:698,y:480,t:1527009291984};\\\", \\\"{x:714,y:480,t:1527009292001};\\\", \\\"{x:722,y:480,t:1527009292019};\\\", \\\"{x:729,y:480,t:1527009292034};\\\", \\\"{x:733,y:480,t:1527009292052};\\\", \\\"{x:734,y:480,t:1527009292069};\\\", \\\"{x:735,y:480,t:1527009292085};\\\", \\\"{x:737,y:480,t:1527009292101};\\\", \\\"{x:738,y:480,t:1527009292119};\\\", \\\"{x:747,y:481,t:1527009292134};\\\", \\\"{x:759,y:487,t:1527009292153};\\\", \\\"{x:782,y:497,t:1527009292168};\\\", \\\"{x:833,y:522,t:1527009292185};\\\", \\\"{x:929,y:564,t:1527009292202};\\\", \\\"{x:1053,y:613,t:1527009292219};\\\", \\\"{x:1199,y:657,t:1527009292235};\\\", \\\"{x:1357,y:701,t:1527009292251};\\\", \\\"{x:1525,y:746,t:1527009292268};\\\", \\\"{x:1694,y:819,t:1527009292284};\\\", \\\"{x:1739,y:841,t:1527009292301};\\\", \\\"{x:1740,y:841,t:1527009292319};\\\", \\\"{x:1738,y:841,t:1527009292782};\\\", \\\"{x:1733,y:840,t:1527009292790};\\\", \\\"{x:1728,y:838,t:1527009292802};\\\", \\\"{x:1721,y:838,t:1527009292819};\\\", \\\"{x:1714,y:838,t:1527009292836};\\\", \\\"{x:1710,y:838,t:1527009292853};\\\", \\\"{x:1709,y:838,t:1527009292869};\\\", \\\"{x:1707,y:838,t:1527009292966};\\\", \\\"{x:1703,y:839,t:1527009292973};\\\", \\\"{x:1695,y:840,t:1527009292986};\\\", \\\"{x:1678,y:844,t:1527009293003};\\\", \\\"{x:1665,y:847,t:1527009293019};\\\", \\\"{x:1648,y:851,t:1527009293036};\\\", \\\"{x:1628,y:854,t:1527009293052};\\\", \\\"{x:1611,y:858,t:1527009293069};\\\", \\\"{x:1597,y:859,t:1527009293085};\\\", \\\"{x:1594,y:860,t:1527009293103};\\\", \\\"{x:1592,y:860,t:1527009293119};\\\", \\\"{x:1591,y:860,t:1527009293136};\\\", \\\"{x:1590,y:860,t:1527009293718};\\\", \\\"{x:1589,y:860,t:1527009293726};\\\", \\\"{x:1589,y:859,t:1527009293736};\\\", \\\"{x:1588,y:859,t:1527009293753};\\\", \\\"{x:1587,y:858,t:1527009293772};\\\", \\\"{x:1586,y:858,t:1527009293785};\\\", \\\"{x:1586,y:857,t:1527009293805};\\\", \\\"{x:1585,y:856,t:1527009293861};\\\", \\\"{x:1581,y:854,t:1527009295981};\\\", \\\"{x:1556,y:848,t:1527009295988};\\\", \\\"{x:1515,y:840,t:1527009296003};\\\", \\\"{x:1381,y:809,t:1527009296020};\\\", \\\"{x:1260,y:785,t:1527009296037};\\\", \\\"{x:1143,y:762,t:1527009296053};\\\", \\\"{x:1051,y:735,t:1527009296070};\\\", \\\"{x:1045,y:726,t:1527009296088};\\\", \\\"{x:1030,y:719,t:1527009296366};\\\", \\\"{x:1000,y:714,t:1527009296373};\\\", \\\"{x:992,y:711,t:1527009296388};\\\", \\\"{x:976,y:709,t:1527009296406};\\\", \\\"{x:959,y:706,t:1527009296422};\\\", \\\"{x:948,y:704,t:1527009296437};\\\", \\\"{x:932,y:702,t:1527009296455};\\\", \\\"{x:914,y:701,t:1527009296471};\\\", \\\"{x:882,y:701,t:1527009296487};\\\", \\\"{x:828,y:698,t:1527009296505};\\\", \\\"{x:764,y:689,t:1527009296521};\\\", \\\"{x:690,y:682,t:1527009296537};\\\", \\\"{x:632,y:677,t:1527009296555};\\\", \\\"{x:575,y:666,t:1527009296570};\\\", \\\"{x:522,y:658,t:1527009296588};\\\", \\\"{x:461,y:646,t:1527009296606};\\\", \\\"{x:433,y:643,t:1527009296620};\\\", \\\"{x:412,y:639,t:1527009296637};\\\", \\\"{x:394,y:635,t:1527009296655};\\\", \\\"{x:382,y:632,t:1527009296672};\\\", \\\"{x:377,y:629,t:1527009296689};\\\", \\\"{x:373,y:628,t:1527009296706};\\\", \\\"{x:370,y:626,t:1527009296721};\\\", \\\"{x:370,y:625,t:1527009296788};\\\", \\\"{x:370,y:623,t:1527009296804};\\\", \\\"{x:370,y:621,t:1527009296821};\\\", \\\"{x:370,y:619,t:1527009296838};\\\", \\\"{x:372,y:616,t:1527009296855};\\\", \\\"{x:373,y:613,t:1527009296872};\\\", \\\"{x:376,y:610,t:1527009296889};\\\", \\\"{x:381,y:606,t:1527009296906};\\\", \\\"{x:384,y:604,t:1527009296921};\\\", \\\"{x:387,y:600,t:1527009296939};\\\", \\\"{x:388,y:596,t:1527009296956};\\\", \\\"{x:391,y:591,t:1527009296972};\\\", \\\"{x:394,y:583,t:1527009296989};\\\", \\\"{x:394,y:580,t:1527009297005};\\\", \\\"{x:394,y:577,t:1527009297023};\\\", \\\"{x:395,y:576,t:1527009297039};\\\", \\\"{x:396,y:574,t:1527009297055};\\\", \\\"{x:396,y:573,t:1527009297071};\\\", \\\"{x:396,y:571,t:1527009297089};\\\", \\\"{x:396,y:569,t:1527009297106};\\\", \\\"{x:397,y:568,t:1527009297123};\\\", \\\"{x:397,y:567,t:1527009297139};\\\", \\\"{x:398,y:566,t:1527009297245};\\\", \\\"{x:399,y:566,t:1527009297256};\\\", \\\"{x:405,y:566,t:1527009297273};\\\", \\\"{x:413,y:566,t:1527009297289};\\\", \\\"{x:426,y:566,t:1527009297307};\\\", \\\"{x:444,y:563,t:1527009297323};\\\", \\\"{x:474,y:563,t:1527009297339};\\\", \\\"{x:527,y:563,t:1527009297358};\\\", \\\"{x:649,y:563,t:1527009297372};\\\", \\\"{x:730,y:563,t:1527009297389};\\\", \\\"{x:796,y:563,t:1527009297405};\\\", \\\"{x:861,y:563,t:1527009297422};\\\", \\\"{x:900,y:563,t:1527009297439};\\\", \\\"{x:922,y:561,t:1527009297456};\\\", \\\"{x:931,y:558,t:1527009297472};\\\", \\\"{x:933,y:558,t:1527009297488};\\\", \\\"{x:932,y:558,t:1527009297516};\\\", \\\"{x:927,y:558,t:1527009297525};\\\", \\\"{x:914,y:553,t:1527009297540};\\\", \\\"{x:890,y:552,t:1527009297556};\\\", \\\"{x:849,y:552,t:1527009297572};\\\", \\\"{x:810,y:559,t:1527009297589};\\\", \\\"{x:761,y:564,t:1527009297606};\\\", \\\"{x:699,y:575,t:1527009297623};\\\", \\\"{x:637,y:585,t:1527009297639};\\\", \\\"{x:554,y:595,t:1527009297656};\\\", \\\"{x:479,y:603,t:1527009297673};\\\", \\\"{x:436,y:603,t:1527009297690};\\\", \\\"{x:384,y:603,t:1527009297706};\\\", \\\"{x:339,y:603,t:1527009297722};\\\", \\\"{x:311,y:601,t:1527009297740};\\\", \\\"{x:299,y:600,t:1527009297756};\\\", \\\"{x:291,y:598,t:1527009297773};\\\", \\\"{x:288,y:598,t:1527009297790};\\\", \\\"{x:282,y:598,t:1527009297807};\\\", \\\"{x:271,y:597,t:1527009297823};\\\", \\\"{x:253,y:595,t:1527009297839};\\\", \\\"{x:227,y:593,t:1527009297858};\\\", \\\"{x:201,y:589,t:1527009297873};\\\", \\\"{x:179,y:582,t:1527009297890};\\\", \\\"{x:167,y:577,t:1527009297906};\\\", \\\"{x:161,y:574,t:1527009297923};\\\", \\\"{x:159,y:572,t:1527009297940};\\\", \\\"{x:157,y:570,t:1527009297956};\\\", \\\"{x:155,y:567,t:1527009297973};\\\", \\\"{x:153,y:562,t:1527009297991};\\\", \\\"{x:150,y:558,t:1527009298005};\\\", \\\"{x:149,y:554,t:1527009298024};\\\", \\\"{x:149,y:550,t:1527009298040};\\\", \\\"{x:149,y:548,t:1527009298057};\\\", \\\"{x:149,y:546,t:1527009298073};\\\", \\\"{x:150,y:545,t:1527009298089};\\\", \\\"{x:151,y:544,t:1527009298142};\\\", \\\"{x:151,y:543,t:1527009298157};\\\", \\\"{x:152,y:543,t:1527009298181};\\\", \\\"{x:154,y:543,t:1527009298484};\\\", \\\"{x:160,y:543,t:1527009298492};\\\", \\\"{x:165,y:545,t:1527009298507};\\\", \\\"{x:174,y:549,t:1527009298524};\\\", \\\"{x:192,y:561,t:1527009298541};\\\", \\\"{x:258,y:609,t:1527009298557};\\\", \\\"{x:327,y:650,t:1527009298574};\\\", \\\"{x:398,y:695,t:1527009298590};\\\", \\\"{x:480,y:740,t:1527009298607};\\\", \\\"{x:549,y:771,t:1527009298624};\\\", \\\"{x:621,y:790,t:1527009298639};\\\", \\\"{x:666,y:802,t:1527009298657};\\\", \\\"{x:687,y:806,t:1527009298673};\\\", \\\"{x:690,y:806,t:1527009298689};\\\", \\\"{x:691,y:806,t:1527009298724};\\\", \\\"{x:691,y:805,t:1527009298765};\\\", \\\"{x:691,y:804,t:1527009298773};\\\", \\\"{x:691,y:803,t:1527009298805};\\\", \\\"{x:691,y:801,t:1527009298821};\\\", \\\"{x:691,y:800,t:1527009298829};\\\", \\\"{x:691,y:797,t:1527009298840};\\\", \\\"{x:678,y:786,t:1527009298857};\\\", \\\"{x:651,y:774,t:1527009298873};\\\", \\\"{x:622,y:765,t:1527009298889};\\\", \\\"{x:597,y:762,t:1527009298906};\\\", \\\"{x:573,y:762,t:1527009298923};\\\", \\\"{x:547,y:762,t:1527009298940};\\\", \\\"{x:517,y:762,t:1527009298957};\\\", \\\"{x:506,y:762,t:1527009298973};\\\", \\\"{x:502,y:761,t:1527009298990};\\\", \\\"{x:501,y:761,t:1527009299007};\\\", \\\"{x:500,y:761,t:1527009299229};\\\", \\\"{x:500,y:760,t:1527009299241};\\\", \\\"{x:500,y:759,t:1527009299257};\\\", \\\"{x:500,y:757,t:1527009299273};\\\", \\\"{x:501,y:756,t:1527009299291};\\\", \\\"{x:501,y:755,t:1527009299317};\\\", \\\"{x:501,y:754,t:1527009299325};\\\", \\\"{x:501,y:753,t:1527009299341};\\\", \\\"{x:502,y:753,t:1527009299357};\\\", \\\"{x:502,y:752,t:1527009299374};\\\", \\\"{x:502,y:751,t:1527009299405};\\\", \\\"{x:504,y:750,t:1527009299829};\\\", \\\"{x:509,y:748,t:1527009299841};\\\", \\\"{x:524,y:744,t:1527009299857};\\\", \\\"{x:539,y:744,t:1527009299875};\\\", \\\"{x:554,y:744,t:1527009299890};\\\", \\\"{x:569,y:744,t:1527009299907};\\\", \\\"{x:594,y:746,t:1527009299924};\\\", \\\"{x:611,y:750,t:1527009299940};\\\", \\\"{x:626,y:752,t:1527009299957};\\\", \\\"{x:646,y:755,t:1527009299975};\\\", \\\"{x:657,y:756,t:1527009299990};\\\", \\\"{x:667,y:757,t:1527009300008};\\\", \\\"{x:670,y:758,t:1527009300025};\\\" ] }, { \\\"rt\\\": 47430, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 17, \\\"time_elapsed\\\": 513103, \\\"internal_node_id\\\": \\\"0.0-6.0-7.0\\\", \\\"subject\\\": \\\"R06S6\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"echo\\\", \\\"condition\\\": \\\"121\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"meets\\\", \\\"q\\\": 13, \\\"clicks\\\": 2, \\\"explicit\\\": 1, \\\"impasse\\\": 2, \\\"axis\\\": \\\"Orthogonal-XInside-YFull\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 0, \\\"answer\\\": [ \\\"X\\\", \\\"O\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-M -Z -04 PM-Z -04 PM-X -O -O -O -B -X \\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:678,y:758,t:1527009302958};\\\", \\\"{x:691,y:754,t:1527009302965};\\\", \\\"{x:710,y:752,t:1527009302977};\\\", \\\"{x:775,y:748,t:1527009302993};\\\", \\\"{x:831,y:748,t:1527009303010};\\\", \\\"{x:869,y:748,t:1527009303027};\\\", \\\"{x:897,y:748,t:1527009303044};\\\", \\\"{x:939,y:757,t:1527009303059};\\\", \\\"{x:1006,y:776,t:1527009303077};\\\", \\\"{x:1053,y:789,t:1527009303094};\\\", \\\"{x:1105,y:803,t:1527009303110};\\\", \\\"{x:1159,y:821,t:1527009303127};\\\", \\\"{x:1223,y:838,t:1527009303144};\\\", \\\"{x:1283,y:853,t:1527009303160};\\\", \\\"{x:1336,y:866,t:1527009303177};\\\", \\\"{x:1380,y:878,t:1527009303194};\\\", \\\"{x:1406,y:886,t:1527009303211};\\\", \\\"{x:1417,y:889,t:1527009303227};\\\", \\\"{x:1421,y:891,t:1527009303244};\\\", \\\"{x:1422,y:892,t:1527009303260};\\\", \\\"{x:1422,y:898,t:1527009303277};\\\", \\\"{x:1422,y:902,t:1527009303294};\\\", \\\"{x:1419,y:903,t:1527009303310};\\\", \\\"{x:1418,y:903,t:1527009303742};\\\", \\\"{x:1418,y:905,t:1527009303758};\\\", \\\"{x:1419,y:905,t:1527009303781};\\\", \\\"{x:1418,y:905,t:1527009304452};\\\", \\\"{x:1417,y:905,t:1527009304485};\\\", \\\"{x:1416,y:905,t:1527009304501};\\\", \\\"{x:1415,y:905,t:1527009304518};\\\", \\\"{x:1414,y:904,t:1527009304622};\\\", \\\"{x:1412,y:904,t:1527009305302};\\\", \\\"{x:1412,y:903,t:1527009306718};\\\", \\\"{x:1412,y:896,t:1527009306729};\\\", \\\"{x:1422,y:880,t:1527009306746};\\\", \\\"{x:1433,y:871,t:1527009306763};\\\", \\\"{x:1447,y:864,t:1527009306779};\\\", \\\"{x:1456,y:858,t:1527009306796};\\\", \\\"{x:1463,y:854,t:1527009306812};\\\", \\\"{x:1465,y:853,t:1527009306829};\\\", \\\"{x:1467,y:852,t:1527009306846};\\\", \\\"{x:1468,y:852,t:1527009306863};\\\", \\\"{x:1469,y:851,t:1527009306880};\\\", \\\"{x:1472,y:849,t:1527009306896};\\\", \\\"{x:1476,y:846,t:1527009306913};\\\", \\\"{x:1480,y:844,t:1527009306930};\\\", \\\"{x:1486,y:842,t:1527009306946};\\\", \\\"{x:1490,y:839,t:1527009306963};\\\", \\\"{x:1495,y:836,t:1527009306980};\\\", \\\"{x:1503,y:832,t:1527009306997};\\\", \\\"{x:1516,y:822,t:1527009307012};\\\", \\\"{x:1525,y:815,t:1527009307030};\\\", \\\"{x:1537,y:809,t:1527009307046};\\\", \\\"{x:1548,y:801,t:1527009307064};\\\", \\\"{x:1556,y:795,t:1527009307081};\\\", \\\"{x:1566,y:790,t:1527009307096};\\\", \\\"{x:1571,y:786,t:1527009307114};\\\", \\\"{x:1575,y:784,t:1527009307131};\\\", \\\"{x:1578,y:782,t:1527009307146};\\\", \\\"{x:1582,y:779,t:1527009307163};\\\", \\\"{x:1584,y:776,t:1527009307180};\\\", \\\"{x:1587,y:775,t:1527009307197};\\\", \\\"{x:1588,y:773,t:1527009307213};\\\", \\\"{x:1590,y:772,t:1527009307230};\\\", \\\"{x:1590,y:771,t:1527009307246};\\\", \\\"{x:1591,y:769,t:1527009307276};\\\", \\\"{x:1592,y:767,t:1527009307293};\\\", \\\"{x:1594,y:764,t:1527009307301};\\\", \\\"{x:1596,y:762,t:1527009307314};\\\", \\\"{x:1598,y:760,t:1527009307330};\\\", \\\"{x:1600,y:756,t:1527009307347};\\\", \\\"{x:1602,y:753,t:1527009307363};\\\", \\\"{x:1603,y:751,t:1527009307380};\\\", \\\"{x:1603,y:748,t:1527009307397};\\\", \\\"{x:1604,y:745,t:1527009307413};\\\", \\\"{x:1605,y:745,t:1527009307430};\\\", \\\"{x:1605,y:743,t:1527009307448};\\\", \\\"{x:1605,y:740,t:1527009307463};\\\", \\\"{x:1605,y:736,t:1527009307480};\\\", \\\"{x:1605,y:733,t:1527009307497};\\\", \\\"{x:1605,y:729,t:1527009307513};\\\", \\\"{x:1605,y:727,t:1527009307531};\\\", \\\"{x:1605,y:725,t:1527009307547};\\\", \\\"{x:1605,y:723,t:1527009307564};\\\", \\\"{x:1606,y:719,t:1527009307580};\\\", \\\"{x:1607,y:714,t:1527009307597};\\\", \\\"{x:1609,y:711,t:1527009307614};\\\", \\\"{x:1610,y:707,t:1527009307631};\\\", \\\"{x:1610,y:704,t:1527009307648};\\\", \\\"{x:1611,y:701,t:1527009307666};\\\", \\\"{x:1611,y:706,t:1527009308247};\\\", \\\"{x:1610,y:713,t:1527009308265};\\\", \\\"{x:1608,y:717,t:1527009308281};\\\", \\\"{x:1608,y:719,t:1527009308298};\\\", \\\"{x:1608,y:720,t:1527009308314};\\\", \\\"{x:1608,y:721,t:1527009308331};\\\", \\\"{x:1607,y:723,t:1527009308348};\\\", \\\"{x:1607,y:730,t:1527009308365};\\\", \\\"{x:1605,y:735,t:1527009308381};\\\", \\\"{x:1605,y:738,t:1527009308398};\\\", \\\"{x:1605,y:740,t:1527009308414};\\\", \\\"{x:1605,y:741,t:1527009308431};\\\", \\\"{x:1605,y:743,t:1527009308447};\\\", \\\"{x:1605,y:745,t:1527009308465};\\\", \\\"{x:1605,y:748,t:1527009308482};\\\", \\\"{x:1605,y:749,t:1527009308498};\\\", \\\"{x:1605,y:750,t:1527009308514};\\\", \\\"{x:1605,y:751,t:1527009308541};\\\", \\\"{x:1605,y:752,t:1527009308598};\\\", \\\"{x:1605,y:753,t:1527009308615};\\\", \\\"{x:1605,y:756,t:1527009308632};\\\", \\\"{x:1605,y:760,t:1527009308648};\\\", \\\"{x:1604,y:763,t:1527009308664};\\\", \\\"{x:1603,y:767,t:1527009308682};\\\", \\\"{x:1603,y:771,t:1527009308697};\\\", \\\"{x:1603,y:776,t:1527009308714};\\\", \\\"{x:1600,y:782,t:1527009308732};\\\", \\\"{x:1598,y:790,t:1527009308748};\\\", \\\"{x:1596,y:798,t:1527009308765};\\\", \\\"{x:1596,y:803,t:1527009308781};\\\", \\\"{x:1596,y:807,t:1527009308799};\\\", \\\"{x:1596,y:818,t:1527009308815};\\\", \\\"{x:1596,y:830,t:1527009308832};\\\", \\\"{x:1595,y:848,t:1527009308849};\\\", \\\"{x:1595,y:871,t:1527009308865};\\\", \\\"{x:1595,y:898,t:1527009308882};\\\", \\\"{x:1595,y:919,t:1527009308898};\\\", \\\"{x:1595,y:933,t:1527009308915};\\\", \\\"{x:1595,y:936,t:1527009308931};\\\", \\\"{x:1595,y:937,t:1527009308957};\\\", \\\"{x:1596,y:937,t:1527009308974};\\\", \\\"{x:1597,y:937,t:1527009308997};\\\", \\\"{x:1598,y:939,t:1527009309015};\\\", \\\"{x:1602,y:942,t:1527009309031};\\\", \\\"{x:1605,y:946,t:1527009309049};\\\", \\\"{x:1607,y:949,t:1527009309064};\\\", \\\"{x:1609,y:951,t:1527009309082};\\\", \\\"{x:1609,y:953,t:1527009309099};\\\", \\\"{x:1610,y:954,t:1527009309115};\\\", \\\"{x:1614,y:961,t:1527009309133};\\\", \\\"{x:1617,y:968,t:1527009309148};\\\", \\\"{x:1623,y:976,t:1527009309166};\\\", \\\"{x:1624,y:977,t:1527009309181};\\\", \\\"{x:1625,y:978,t:1527009309205};\\\", \\\"{x:1625,y:979,t:1527009309293};\\\", \\\"{x:1626,y:980,t:1527009309301};\\\", \\\"{x:1626,y:981,t:1527009309317};\\\", \\\"{x:1626,y:980,t:1527009310269};\\\", \\\"{x:1626,y:975,t:1527009310282};\\\", \\\"{x:1626,y:966,t:1527009310301};\\\", \\\"{x:1626,y:953,t:1527009310315};\\\", \\\"{x:1626,y:940,t:1527009310331};\\\", \\\"{x:1626,y:930,t:1527009310348};\\\", \\\"{x:1627,y:918,t:1527009310365};\\\", \\\"{x:1630,y:905,t:1527009310382};\\\", \\\"{x:1634,y:884,t:1527009310399};\\\", \\\"{x:1637,y:868,t:1527009310415};\\\", \\\"{x:1637,y:849,t:1527009310432};\\\", \\\"{x:1637,y:831,t:1527009310450};\\\", \\\"{x:1637,y:813,t:1527009310465};\\\", \\\"{x:1639,y:800,t:1527009310483};\\\", \\\"{x:1642,y:785,t:1527009310499};\\\", \\\"{x:1642,y:772,t:1527009310515};\\\", \\\"{x:1642,y:759,t:1527009310532};\\\", \\\"{x:1642,y:742,t:1527009310549};\\\", \\\"{x:1642,y:731,t:1527009310566};\\\", \\\"{x:1642,y:726,t:1527009310582};\\\", \\\"{x:1641,y:722,t:1527009310600};\\\", \\\"{x:1641,y:719,t:1527009310615};\\\", \\\"{x:1641,y:718,t:1527009310637};\\\", \\\"{x:1640,y:716,t:1527009310649};\\\", \\\"{x:1639,y:714,t:1527009310666};\\\", \\\"{x:1637,y:710,t:1527009310682};\\\", \\\"{x:1637,y:708,t:1527009310698};\\\", \\\"{x:1636,y:706,t:1527009310716};\\\", \\\"{x:1635,y:705,t:1527009310731};\\\", \\\"{x:1632,y:705,t:1527009310749};\\\", \\\"{x:1630,y:704,t:1527009310766};\\\", \\\"{x:1628,y:704,t:1527009310783};\\\", \\\"{x:1627,y:703,t:1527009310799};\\\", \\\"{x:1625,y:702,t:1527009310816};\\\", \\\"{x:1624,y:702,t:1527009310837};\\\", \\\"{x:1621,y:701,t:1527009310853};\\\", \\\"{x:1620,y:701,t:1527009310866};\\\", \\\"{x:1617,y:699,t:1527009310883};\\\", \\\"{x:1617,y:698,t:1527009310900};\\\", \\\"{x:1615,y:697,t:1527009310916};\\\", \\\"{x:1614,y:696,t:1527009310933};\\\", \\\"{x:1614,y:695,t:1527009311205};\\\", \\\"{x:1615,y:695,t:1527009311221};\\\", \\\"{x:1616,y:695,t:1527009311233};\\\", \\\"{x:1617,y:695,t:1527009311249};\\\", \\\"{x:1618,y:696,t:1527009311266};\\\", \\\"{x:1619,y:696,t:1527009311284};\\\", \\\"{x:1620,y:697,t:1527009311301};\\\", \\\"{x:1621,y:697,t:1527009311350};\\\", \\\"{x:1621,y:700,t:1527009311367};\\\", \\\"{x:1621,y:706,t:1527009311384};\\\", \\\"{x:1621,y:711,t:1527009311399};\\\", \\\"{x:1621,y:717,t:1527009311416};\\\", \\\"{x:1621,y:724,t:1527009311434};\\\", \\\"{x:1621,y:736,t:1527009311449};\\\", \\\"{x:1620,y:748,t:1527009311467};\\\", \\\"{x:1618,y:765,t:1527009311484};\\\", \\\"{x:1617,y:774,t:1527009311500};\\\", \\\"{x:1617,y:781,t:1527009311516};\\\", \\\"{x:1617,y:785,t:1527009311533};\\\", \\\"{x:1617,y:787,t:1527009311958};\\\", \\\"{x:1617,y:790,t:1527009311967};\\\", \\\"{x:1617,y:797,t:1527009311984};\\\", \\\"{x:1617,y:806,t:1527009312001};\\\", \\\"{x:1617,y:814,t:1527009312017};\\\", \\\"{x:1617,y:823,t:1527009312033};\\\", \\\"{x:1617,y:837,t:1527009312051};\\\", \\\"{x:1620,y:858,t:1527009312068};\\\", \\\"{x:1622,y:877,t:1527009312084};\\\", \\\"{x:1625,y:899,t:1527009312101};\\\", \\\"{x:1630,y:935,t:1527009312117};\\\", \\\"{x:1631,y:953,t:1527009312133};\\\", \\\"{x:1634,y:967,t:1527009312150};\\\", \\\"{x:1637,y:975,t:1527009312168};\\\", \\\"{x:1638,y:979,t:1527009312184};\\\", \\\"{x:1637,y:979,t:1527009312533};\\\", \\\"{x:1635,y:978,t:1527009312551};\\\", \\\"{x:1634,y:978,t:1527009312598};\\\", \\\"{x:1633,y:978,t:1527009312774};\\\", \\\"{x:1632,y:977,t:1527009312798};\\\", \\\"{x:1632,y:976,t:1527009312893};\\\", \\\"{x:1631,y:976,t:1527009313117};\\\", \\\"{x:1630,y:975,t:1527009313135};\\\", \\\"{x:1628,y:975,t:1527009313152};\\\", \\\"{x:1625,y:973,t:1527009313168};\\\", \\\"{x:1622,y:971,t:1527009313185};\\\", \\\"{x:1617,y:967,t:1527009313203};\\\", \\\"{x:1604,y:958,t:1527009313218};\\\", \\\"{x:1593,y:949,t:1527009313235};\\\", \\\"{x:1585,y:941,t:1527009313252};\\\", \\\"{x:1576,y:933,t:1527009313268};\\\", \\\"{x:1545,y:909,t:1527009313285};\\\", \\\"{x:1524,y:894,t:1527009313301};\\\", \\\"{x:1503,y:881,t:1527009313318};\\\", \\\"{x:1475,y:862,t:1527009313335};\\\", \\\"{x:1444,y:844,t:1527009313352};\\\", \\\"{x:1418,y:828,t:1527009313368};\\\", \\\"{x:1399,y:815,t:1527009313384};\\\", \\\"{x:1384,y:806,t:1527009313402};\\\", \\\"{x:1378,y:802,t:1527009313417};\\\", \\\"{x:1377,y:802,t:1527009313435};\\\", \\\"{x:1377,y:801,t:1527009313486};\\\", \\\"{x:1379,y:798,t:1527009313502};\\\", \\\"{x:1381,y:798,t:1527009313519};\\\", \\\"{x:1384,y:797,t:1527009313535};\\\", \\\"{x:1388,y:795,t:1527009313552};\\\", \\\"{x:1394,y:791,t:1527009313569};\\\", \\\"{x:1407,y:789,t:1527009313585};\\\", \\\"{x:1428,y:789,t:1527009313602};\\\", \\\"{x:1444,y:788,t:1527009313619};\\\", \\\"{x:1456,y:785,t:1527009313635};\\\", \\\"{x:1468,y:784,t:1527009313652};\\\", \\\"{x:1480,y:781,t:1527009313668};\\\", \\\"{x:1496,y:780,t:1527009313685};\\\", \\\"{x:1498,y:780,t:1527009313701};\\\", \\\"{x:1499,y:780,t:1527009313719};\\\", \\\"{x:1499,y:779,t:1527009313735};\\\", \\\"{x:1500,y:779,t:1527009313752};\\\", \\\"{x:1504,y:777,t:1527009313769};\\\", \\\"{x:1513,y:777,t:1527009313785};\\\", \\\"{x:1520,y:776,t:1527009313802};\\\", \\\"{x:1524,y:775,t:1527009313819};\\\", \\\"{x:1526,y:774,t:1527009313835};\\\", \\\"{x:1526,y:773,t:1527009314342};\\\", \\\"{x:1526,y:772,t:1527009314430};\\\", \\\"{x:1525,y:772,t:1527009314882};\\\", \\\"{x:1523,y:773,t:1527009314890};\\\", \\\"{x:1522,y:779,t:1527009314908};\\\", \\\"{x:1517,y:789,t:1527009314925};\\\", \\\"{x:1514,y:796,t:1527009314940};\\\", \\\"{x:1513,y:801,t:1527009314957};\\\", \\\"{x:1513,y:803,t:1527009314974};\\\", \\\"{x:1512,y:805,t:1527009314990};\\\", \\\"{x:1512,y:807,t:1527009315008};\\\", \\\"{x:1511,y:810,t:1527009315024};\\\", \\\"{x:1509,y:813,t:1527009315040};\\\", \\\"{x:1506,y:819,t:1527009315057};\\\", \\\"{x:1503,y:823,t:1527009315073};\\\", \\\"{x:1502,y:825,t:1527009315090};\\\", \\\"{x:1500,y:827,t:1527009315107};\\\", \\\"{x:1499,y:828,t:1527009315124};\\\", \\\"{x:1498,y:828,t:1527009315141};\\\", \\\"{x:1494,y:828,t:1527009315157};\\\", \\\"{x:1492,y:828,t:1527009315174};\\\", \\\"{x:1489,y:829,t:1527009315190};\\\", \\\"{x:1488,y:829,t:1527009315207};\\\", \\\"{x:1486,y:831,t:1527009315225};\\\", \\\"{x:1485,y:832,t:1527009315258};\\\", \\\"{x:1484,y:832,t:1527009318018};\\\", \\\"{x:1479,y:832,t:1527009318026};\\\", \\\"{x:1458,y:819,t:1527009318043};\\\", \\\"{x:1403,y:799,t:1527009318059};\\\", \\\"{x:1309,y:773,t:1527009318076};\\\", \\\"{x:1210,y:752,t:1527009318093};\\\", \\\"{x:1109,y:730,t:1527009318109};\\\", \\\"{x:995,y:695,t:1527009318126};\\\", \\\"{x:914,y:670,t:1527009318143};\\\", \\\"{x:875,y:653,t:1527009318159};\\\", \\\"{x:860,y:646,t:1527009318177};\\\", \\\"{x:856,y:644,t:1527009318192};\\\", \\\"{x:850,y:640,t:1527009318209};\\\", \\\"{x:832,y:632,t:1527009318226};\\\", \\\"{x:799,y:620,t:1527009318243};\\\", \\\"{x:751,y:605,t:1527009318258};\\\", \\\"{x:707,y:594,t:1527009318276};\\\", \\\"{x:670,y:582,t:1527009318294};\\\", \\\"{x:629,y:574,t:1527009318310};\\\", \\\"{x:594,y:566,t:1527009318327};\\\", \\\"{x:571,y:561,t:1527009318343};\\\", \\\"{x:557,y:558,t:1527009318360};\\\", \\\"{x:545,y:556,t:1527009318376};\\\", \\\"{x:543,y:556,t:1527009318393};\\\", \\\"{x:542,y:556,t:1527009318409};\\\", \\\"{x:541,y:556,t:1527009318427};\\\", \\\"{x:540,y:556,t:1527009318444};\\\", \\\"{x:538,y:556,t:1527009318465};\\\", \\\"{x:537,y:556,t:1527009318489};\\\", \\\"{x:536,y:556,t:1527009318497};\\\", \\\"{x:535,y:556,t:1527009318511};\\\", \\\"{x:534,y:557,t:1527009318527};\\\", \\\"{x:532,y:558,t:1527009318544};\\\", \\\"{x:533,y:559,t:1527009318585};\\\", \\\"{x:536,y:559,t:1527009318594};\\\", \\\"{x:546,y:559,t:1527009318611};\\\", \\\"{x:552,y:561,t:1527009318627};\\\", \\\"{x:555,y:561,t:1527009318644};\\\", \\\"{x:557,y:561,t:1527009318660};\\\", \\\"{x:559,y:561,t:1527009318678};\\\", \\\"{x:563,y:563,t:1527009318694};\\\", \\\"{x:569,y:565,t:1527009318711};\\\", \\\"{x:574,y:569,t:1527009318727};\\\", \\\"{x:576,y:571,t:1527009318744};\\\", \\\"{x:578,y:572,t:1527009318785};\\\", \\\"{x:579,y:573,t:1527009318793};\\\", \\\"{x:582,y:574,t:1527009318811};\\\", \\\"{x:585,y:577,t:1527009318827};\\\", \\\"{x:586,y:578,t:1527009318844};\\\", \\\"{x:587,y:578,t:1527009318861};\\\", \\\"{x:587,y:579,t:1527009318922};\\\", \\\"{x:588,y:579,t:1527009318929};\\\", \\\"{x:589,y:579,t:1527009318943};\\\", \\\"{x:597,y:579,t:1527009318961};\\\", \\\"{x:599,y:580,t:1527009318977};\\\", \\\"{x:601,y:581,t:1527009318994};\\\", \\\"{x:602,y:581,t:1527009319011};\\\", \\\"{x:604,y:582,t:1527009319032};\\\", \\\"{x:605,y:582,t:1527009319049};\\\", \\\"{x:606,y:582,t:1527009319061};\\\", \\\"{x:607,y:583,t:1527009319076};\\\", \\\"{x:609,y:583,t:1527009319094};\\\", \\\"{x:610,y:583,t:1527009319201};\\\", \\\"{x:611,y:583,t:1527009319211};\\\", \\\"{x:612,y:583,t:1527009319228};\\\", \\\"{x:612,y:583,t:1527009319303};\\\", \\\"{x:621,y:588,t:1527009319707};\\\", \\\"{x:639,y:594,t:1527009319714};\\\", \\\"{x:664,y:601,t:1527009319729};\\\", \\\"{x:696,y:607,t:1527009319744};\\\", \\\"{x:748,y:616,t:1527009319762};\\\", \\\"{x:801,y:623,t:1527009319778};\\\", \\\"{x:869,y:637,t:1527009319794};\\\", \\\"{x:931,y:648,t:1527009319811};\\\", \\\"{x:983,y:660,t:1527009319828};\\\", \\\"{x:1031,y:668,t:1527009319845};\\\", \\\"{x:1068,y:675,t:1527009319861};\\\", \\\"{x:1097,y:681,t:1527009319877};\\\", \\\"{x:1131,y:686,t:1527009319894};\\\", \\\"{x:1154,y:690,t:1527009319911};\\\", \\\"{x:1177,y:695,t:1527009319928};\\\", \\\"{x:1196,y:698,t:1527009319944};\\\", \\\"{x:1232,y:705,t:1527009319961};\\\", \\\"{x:1258,y:709,t:1527009319979};\\\", \\\"{x:1287,y:715,t:1527009319994};\\\", \\\"{x:1319,y:721,t:1527009320012};\\\", \\\"{x:1342,y:723,t:1527009320029};\\\", \\\"{x:1368,y:728,t:1527009320045};\\\", \\\"{x:1386,y:730,t:1527009320061};\\\", \\\"{x:1402,y:733,t:1527009320079};\\\", \\\"{x:1413,y:734,t:1527009320094};\\\", \\\"{x:1420,y:735,t:1527009320111};\\\", \\\"{x:1424,y:735,t:1527009320128};\\\", \\\"{x:1425,y:736,t:1527009320145};\\\", \\\"{x:1426,y:736,t:1527009320203};\\\", \\\"{x:1428,y:736,t:1527009320217};\\\", \\\"{x:1431,y:737,t:1527009320234};\\\", \\\"{x:1433,y:737,t:1527009320245};\\\", \\\"{x:1442,y:738,t:1527009320261};\\\", \\\"{x:1457,y:741,t:1527009320278};\\\", \\\"{x:1477,y:744,t:1527009320294};\\\", \\\"{x:1498,y:748,t:1527009320312};\\\", \\\"{x:1518,y:750,t:1527009320328};\\\", \\\"{x:1532,y:754,t:1527009320344};\\\", \\\"{x:1549,y:757,t:1527009320361};\\\", \\\"{x:1552,y:758,t:1527009320378};\\\", \\\"{x:1554,y:759,t:1527009320394};\\\", \\\"{x:1555,y:759,t:1527009320411};\\\", \\\"{x:1556,y:759,t:1527009320428};\\\", \\\"{x:1557,y:760,t:1527009320489};\\\", \\\"{x:1558,y:761,t:1527009320530};\\\", \\\"{x:1558,y:760,t:1527009322162};\\\", \\\"{x:1556,y:759,t:1527009322186};\\\", \\\"{x:1555,y:758,t:1527009322194};\\\", \\\"{x:1554,y:758,t:1527009322226};\\\", \\\"{x:1554,y:757,t:1527009322234};\\\", \\\"{x:1553,y:757,t:1527009322282};\\\", \\\"{x:1552,y:755,t:1527009323178};\\\", \\\"{x:1552,y:753,t:1527009323194};\\\", \\\"{x:1550,y:750,t:1527009323211};\\\", \\\"{x:1550,y:749,t:1527009323228};\\\", \\\"{x:1549,y:747,t:1527009323243};\\\", \\\"{x:1549,y:745,t:1527009323260};\\\", \\\"{x:1548,y:744,t:1527009323277};\\\", \\\"{x:1547,y:741,t:1527009323293};\\\", \\\"{x:1545,y:738,t:1527009323310};\\\", \\\"{x:1539,y:731,t:1527009323327};\\\", \\\"{x:1528,y:723,t:1527009323343};\\\", \\\"{x:1515,y:715,t:1527009323360};\\\", \\\"{x:1487,y:695,t:1527009323377};\\\", \\\"{x:1475,y:685,t:1527009323394};\\\", \\\"{x:1466,y:680,t:1527009323411};\\\", \\\"{x:1464,y:678,t:1527009323427};\\\", \\\"{x:1463,y:676,t:1527009323443};\\\", \\\"{x:1462,y:675,t:1527009323474};\\\", \\\"{x:1462,y:674,t:1527009323481};\\\", \\\"{x:1461,y:674,t:1527009324018};\\\", \\\"{x:1466,y:678,t:1527009324610};\\\", \\\"{x:1483,y:686,t:1527009324627};\\\", \\\"{x:1488,y:686,t:1527009324644};\\\", \\\"{x:1490,y:686,t:1527009324661};\\\", \\\"{x:1490,y:687,t:1527009324676};\\\", \\\"{x:1491,y:688,t:1527009324693};\\\", \\\"{x:1492,y:688,t:1527009324713};\\\", \\\"{x:1493,y:688,t:1527009324727};\\\", \\\"{x:1494,y:688,t:1527009324818};\\\", \\\"{x:1496,y:691,t:1527009324827};\\\", \\\"{x:1499,y:701,t:1527009324844};\\\", \\\"{x:1504,y:715,t:1527009324861};\\\", \\\"{x:1508,y:723,t:1527009324877};\\\", \\\"{x:1508,y:725,t:1527009324894};\\\", \\\"{x:1509,y:729,t:1527009324921};\\\", \\\"{x:1511,y:730,t:1527009324930};\\\", \\\"{x:1511,y:732,t:1527009324944};\\\", \\\"{x:1515,y:745,t:1527009324961};\\\", \\\"{x:1528,y:777,t:1527009324977};\\\", \\\"{x:1541,y:806,t:1527009324993};\\\", \\\"{x:1550,y:818,t:1527009325011};\\\", \\\"{x:1551,y:820,t:1527009325027};\\\", \\\"{x:1552,y:821,t:1527009325044};\\\", \\\"{x:1548,y:821,t:1527009325195};\\\", \\\"{x:1539,y:817,t:1527009325210};\\\", \\\"{x:1535,y:815,t:1527009325227};\\\", \\\"{x:1531,y:813,t:1527009325244};\\\", \\\"{x:1530,y:812,t:1527009325260};\\\", \\\"{x:1529,y:810,t:1527009325426};\\\", \\\"{x:1528,y:807,t:1527009325444};\\\", \\\"{x:1527,y:802,t:1527009325459};\\\", \\\"{x:1522,y:794,t:1527009325477};\\\", \\\"{x:1517,y:787,t:1527009325494};\\\", \\\"{x:1512,y:781,t:1527009325510};\\\", \\\"{x:1511,y:779,t:1527009325527};\\\", \\\"{x:1511,y:777,t:1527009325544};\\\", \\\"{x:1510,y:777,t:1527009325559};\\\", \\\"{x:1510,y:776,t:1527009325577};\\\", \\\"{x:1510,y:775,t:1527009325602};\\\", \\\"{x:1510,y:774,t:1527009325634};\\\", \\\"{x:1511,y:773,t:1527009325658};\\\", \\\"{x:1512,y:773,t:1527009325698};\\\", \\\"{x:1513,y:772,t:1527009325730};\\\", \\\"{x:1514,y:772,t:1527009325819};\\\", \\\"{x:1515,y:772,t:1527009325833};\\\", \\\"{x:1516,y:772,t:1527009325844};\\\", \\\"{x:1517,y:772,t:1527009325860};\\\", \\\"{x:1518,y:772,t:1527009325876};\\\", \\\"{x:1520,y:772,t:1527009325897};\\\", \\\"{x:1520,y:773,t:1527009325909};\\\", \\\"{x:1521,y:773,t:1527009325927};\\\", \\\"{x:1522,y:773,t:1527009325944};\\\", \\\"{x:1523,y:773,t:1527009325960};\\\", \\\"{x:1524,y:773,t:1527009326002};\\\", \\\"{x:1525,y:773,t:1527009326025};\\\", \\\"{x:1526,y:774,t:1527009326242};\\\", \\\"{x:1523,y:774,t:1527009326259};\\\", \\\"{x:1512,y:772,t:1527009326277};\\\", \\\"{x:1503,y:763,t:1527009326292};\\\", \\\"{x:1498,y:758,t:1527009326310};\\\", \\\"{x:1497,y:758,t:1527009327490};\\\", \\\"{x:1497,y:759,t:1527009327530};\\\", \\\"{x:1498,y:760,t:1527009327546};\\\", \\\"{x:1499,y:760,t:1527009327560};\\\", \\\"{x:1501,y:761,t:1527009327576};\\\", \\\"{x:1502,y:762,t:1527009327592};\\\", \\\"{x:1504,y:763,t:1527009327610};\\\", \\\"{x:1507,y:765,t:1527009327626};\\\", \\\"{x:1511,y:765,t:1527009327643};\\\", \\\"{x:1513,y:766,t:1527009327659};\\\", \\\"{x:1515,y:768,t:1527009327675};\\\", \\\"{x:1515,y:769,t:1527009327698};\\\", \\\"{x:1515,y:770,t:1527009327710};\\\", \\\"{x:1515,y:771,t:1527009327730};\\\", \\\"{x:1515,y:773,t:1527009327753};\\\", \\\"{x:1514,y:773,t:1527009327769};\\\", \\\"{x:1511,y:773,t:1527009327776};\\\", \\\"{x:1510,y:773,t:1527009327792};\\\", \\\"{x:1503,y:773,t:1527009327808};\\\", \\\"{x:1495,y:770,t:1527009327826};\\\", \\\"{x:1492,y:770,t:1527009327843};\\\", \\\"{x:1490,y:769,t:1527009327859};\\\", \\\"{x:1489,y:769,t:1527009327876};\\\", \\\"{x:1487,y:768,t:1527009327892};\\\", \\\"{x:1485,y:767,t:1527009327909};\\\", \\\"{x:1481,y:766,t:1527009327925};\\\", \\\"{x:1475,y:763,t:1527009327943};\\\", \\\"{x:1473,y:762,t:1527009327959};\\\", \\\"{x:1472,y:762,t:1527009327976};\\\", \\\"{x:1471,y:762,t:1527009329195};\\\", \\\"{x:1454,y:767,t:1527009329209};\\\", \\\"{x:1384,y:788,t:1527009329226};\\\", \\\"{x:1334,y:796,t:1527009329242};\\\", \\\"{x:1297,y:796,t:1527009329259};\\\", \\\"{x:1274,y:796,t:1527009329275};\\\", \\\"{x:1264,y:796,t:1527009329293};\\\", \\\"{x:1263,y:796,t:1527009329309};\\\", \\\"{x:1264,y:795,t:1527009329482};\\\", \\\"{x:1271,y:791,t:1527009329492};\\\", \\\"{x:1285,y:785,t:1527009329509};\\\", \\\"{x:1299,y:779,t:1527009329526};\\\", \\\"{x:1311,y:774,t:1527009329542};\\\", \\\"{x:1323,y:768,t:1527009329559};\\\", \\\"{x:1330,y:764,t:1527009329576};\\\", \\\"{x:1333,y:764,t:1527009329592};\\\", \\\"{x:1335,y:763,t:1527009329609};\\\", \\\"{x:1338,y:761,t:1527009329627};\\\", \\\"{x:1342,y:759,t:1527009329642};\\\", \\\"{x:1345,y:757,t:1527009329659};\\\", \\\"{x:1347,y:756,t:1527009329676};\\\", \\\"{x:1348,y:756,t:1527009330904};\\\", \\\"{x:1349,y:756,t:1527009331401};\\\", \\\"{x:1350,y:756,t:1527009331417};\\\", \\\"{x:1352,y:756,t:1527009331442};\\\", \\\"{x:1354,y:757,t:1527009331458};\\\", \\\"{x:1357,y:758,t:1527009331475};\\\", \\\"{x:1363,y:761,t:1527009331492};\\\", \\\"{x:1371,y:763,t:1527009331508};\\\", \\\"{x:1378,y:768,t:1527009331525};\\\", \\\"{x:1382,y:774,t:1527009331543};\\\", \\\"{x:1386,y:789,t:1527009331558};\\\", \\\"{x:1391,y:808,t:1527009331575};\\\", \\\"{x:1395,y:828,t:1527009331591};\\\", \\\"{x:1397,y:838,t:1527009331608};\\\", \\\"{x:1398,y:843,t:1527009331625};\\\", \\\"{x:1398,y:844,t:1527009331641};\\\", \\\"{x:1398,y:847,t:1527009331658};\\\", \\\"{x:1398,y:851,t:1527009331675};\\\", \\\"{x:1398,y:856,t:1527009331691};\\\", \\\"{x:1397,y:859,t:1527009331708};\\\", \\\"{x:1397,y:860,t:1527009331725};\\\", \\\"{x:1397,y:861,t:1527009331754};\\\", \\\"{x:1397,y:862,t:1527009331770};\\\", \\\"{x:1397,y:864,t:1527009331778};\\\", \\\"{x:1397,y:865,t:1527009331792};\\\", \\\"{x:1396,y:872,t:1527009331808};\\\", \\\"{x:1394,y:877,t:1527009331826};\\\", \\\"{x:1393,y:879,t:1527009331842};\\\", \\\"{x:1393,y:880,t:1527009331858};\\\", \\\"{x:1393,y:882,t:1527009331875};\\\", \\\"{x:1393,y:883,t:1527009331892};\\\", \\\"{x:1392,y:886,t:1527009331908};\\\", \\\"{x:1392,y:888,t:1527009331925};\\\", \\\"{x:1392,y:890,t:1527009331942};\\\", \\\"{x:1391,y:892,t:1527009331958};\\\", \\\"{x:1390,y:895,t:1527009331975};\\\", \\\"{x:1386,y:902,t:1527009331993};\\\", \\\"{x:1383,y:906,t:1527009332008};\\\", \\\"{x:1379,y:912,t:1527009332025};\\\", \\\"{x:1376,y:916,t:1527009332041};\\\", \\\"{x:1375,y:918,t:1527009332058};\\\", \\\"{x:1374,y:919,t:1527009332075};\\\", \\\"{x:1374,y:916,t:1527009332290};\\\", \\\"{x:1374,y:914,t:1527009332306};\\\", \\\"{x:1374,y:913,t:1527009332313};\\\", \\\"{x:1374,y:912,t:1527009332325};\\\", \\\"{x:1374,y:911,t:1527009332341};\\\", \\\"{x:1375,y:908,t:1527009332358};\\\", \\\"{x:1376,y:908,t:1527009332376};\\\", \\\"{x:1376,y:907,t:1527009332522};\\\", \\\"{x:1378,y:906,t:1527009333258};\\\", \\\"{x:1384,y:903,t:1527009333275};\\\", \\\"{x:1391,y:896,t:1527009333291};\\\", \\\"{x:1397,y:892,t:1527009333308};\\\", \\\"{x:1404,y:887,t:1527009333325};\\\", \\\"{x:1409,y:882,t:1527009333342};\\\", \\\"{x:1413,y:878,t:1527009333358};\\\", \\\"{x:1417,y:874,t:1527009333374};\\\", \\\"{x:1421,y:869,t:1527009333391};\\\", \\\"{x:1424,y:865,t:1527009333408};\\\", \\\"{x:1429,y:859,t:1527009333425};\\\", \\\"{x:1433,y:853,t:1527009333441};\\\", \\\"{x:1437,y:849,t:1527009333458};\\\", \\\"{x:1446,y:842,t:1527009333474};\\\", \\\"{x:1455,y:835,t:1527009333491};\\\", \\\"{x:1462,y:831,t:1527009333508};\\\", \\\"{x:1470,y:824,t:1527009333524};\\\", \\\"{x:1474,y:822,t:1527009333541};\\\", \\\"{x:1476,y:821,t:1527009333558};\\\", \\\"{x:1481,y:820,t:1527009333573};\\\", \\\"{x:1484,y:819,t:1527009333590};\\\", \\\"{x:1491,y:818,t:1527009333608};\\\", \\\"{x:1503,y:817,t:1527009333623};\\\", \\\"{x:1530,y:814,t:1527009333640};\\\", \\\"{x:1546,y:814,t:1527009333658};\\\", \\\"{x:1560,y:814,t:1527009333673};\\\", \\\"{x:1572,y:814,t:1527009333690};\\\", \\\"{x:1586,y:814,t:1527009333708};\\\", \\\"{x:1602,y:814,t:1527009333723};\\\", \\\"{x:1622,y:814,t:1527009333740};\\\", \\\"{x:1638,y:814,t:1527009333757};\\\", \\\"{x:1652,y:814,t:1527009333774};\\\", \\\"{x:1663,y:813,t:1527009333791};\\\", \\\"{x:1669,y:813,t:1527009333808};\\\", \\\"{x:1671,y:812,t:1527009333823};\\\", \\\"{x:1670,y:812,t:1527009333945};\\\", \\\"{x:1666,y:810,t:1527009333958};\\\", \\\"{x:1659,y:808,t:1527009333974};\\\", \\\"{x:1652,y:806,t:1527009333991};\\\", \\\"{x:1646,y:804,t:1527009334008};\\\", \\\"{x:1643,y:804,t:1527009334024};\\\", \\\"{x:1642,y:804,t:1527009335305};\\\", \\\"{x:1639,y:804,t:1527009345273};\\\", \\\"{x:1629,y:804,t:1527009345288};\\\", \\\"{x:1610,y:808,t:1527009345304};\\\", \\\"{x:1571,y:813,t:1527009345321};\\\", \\\"{x:1548,y:817,t:1527009345338};\\\", \\\"{x:1535,y:818,t:1527009345355};\\\", \\\"{x:1532,y:818,t:1527009345372};\\\", \\\"{x:1531,y:818,t:1527009345474};\\\", \\\"{x:1530,y:818,t:1527009345487};\\\", \\\"{x:1529,y:818,t:1527009345513};\\\", \\\"{x:1528,y:818,t:1527009345529};\\\", \\\"{x:1526,y:818,t:1527009345537};\\\", \\\"{x:1524,y:817,t:1527009345555};\\\", \\\"{x:1521,y:817,t:1527009345572};\\\", \\\"{x:1521,y:816,t:1527009345610};\\\", \\\"{x:1520,y:815,t:1527009345682};\\\", \\\"{x:1520,y:814,t:1527009345738};\\\", \\\"{x:1520,y:813,t:1527009345755};\\\", \\\"{x:1520,y:812,t:1527009345772};\\\", \\\"{x:1520,y:811,t:1527009345788};\\\", \\\"{x:1520,y:809,t:1527009345805};\\\", \\\"{x:1520,y:808,t:1527009345822};\\\", \\\"{x:1520,y:806,t:1527009345837};\\\", \\\"{x:1520,y:805,t:1527009345857};\\\", \\\"{x:1520,y:803,t:1527009345881};\\\", \\\"{x:1520,y:802,t:1527009345913};\\\", \\\"{x:1520,y:800,t:1527009346050};\\\", \\\"{x:1520,y:799,t:1527009346138};\\\", \\\"{x:1519,y:799,t:1527009346177};\\\", \\\"{x:1519,y:797,t:1527009346202};\\\", \\\"{x:1519,y:796,t:1527009346241};\\\", \\\"{x:1518,y:795,t:1527009346257};\\\", \\\"{x:1518,y:794,t:1527009346274};\\\", \\\"{x:1516,y:793,t:1527009346313};\\\", \\\"{x:1515,y:792,t:1527009346321};\\\", \\\"{x:1509,y:790,t:1527009346337};\\\", \\\"{x:1501,y:785,t:1527009346354};\\\", \\\"{x:1491,y:780,t:1527009346371};\\\", \\\"{x:1480,y:778,t:1527009346387};\\\", \\\"{x:1468,y:775,t:1527009346404};\\\", \\\"{x:1440,y:774,t:1527009346420};\\\", \\\"{x:1395,y:774,t:1527009346436};\\\", \\\"{x:1315,y:774,t:1527009346454};\\\", \\\"{x:1215,y:774,t:1527009346470};\\\", \\\"{x:1111,y:768,t:1527009346487};\\\", \\\"{x:1007,y:758,t:1527009346504};\\\", \\\"{x:937,y:748,t:1527009346520};\\\", \\\"{x:876,y:738,t:1527009346537};\\\", \\\"{x:846,y:732,t:1527009346554};\\\", \\\"{x:829,y:726,t:1527009346570};\\\", \\\"{x:818,y:721,t:1527009346587};\\\", \\\"{x:808,y:717,t:1527009346604};\\\", \\\"{x:799,y:711,t:1527009346620};\\\", \\\"{x:794,y:705,t:1527009346637};\\\", \\\"{x:790,y:699,t:1527009346655};\\\", \\\"{x:785,y:691,t:1527009346670};\\\", \\\"{x:778,y:678,t:1527009346688};\\\", \\\"{x:774,y:666,t:1527009346704};\\\", \\\"{x:770,y:654,t:1527009346720};\\\", \\\"{x:770,y:643,t:1527009346737};\\\", \\\"{x:770,y:638,t:1527009346754};\\\", \\\"{x:770,y:635,t:1527009346771};\\\", \\\"{x:772,y:630,t:1527009346788};\\\", \\\"{x:776,y:627,t:1527009346804};\\\", \\\"{x:779,y:624,t:1527009346820};\\\", \\\"{x:784,y:621,t:1527009346844};\\\", \\\"{x:788,y:619,t:1527009346859};\\\", \\\"{x:792,y:616,t:1527009346877};\\\", \\\"{x:797,y:614,t:1527009346894};\\\", \\\"{x:801,y:610,t:1527009346910};\\\", \\\"{x:806,y:607,t:1527009346927};\\\", \\\"{x:810,y:604,t:1527009346944};\\\", \\\"{x:813,y:603,t:1527009346960};\\\", \\\"{x:815,y:602,t:1527009346977};\\\", \\\"{x:816,y:601,t:1527009346994};\\\", \\\"{x:819,y:600,t:1527009347012};\\\", \\\"{x:822,y:598,t:1527009347027};\\\", \\\"{x:825,y:596,t:1527009347049};\\\", \\\"{x:826,y:596,t:1527009347072};\\\", \\\"{x:827,y:595,t:1527009347083};\\\", \\\"{x:828,y:594,t:1527009347099};\\\", \\\"{x:829,y:593,t:1527009347116};\\\", \\\"{x:830,y:591,t:1527009347133};\\\", \\\"{x:831,y:590,t:1527009347149};\\\", \\\"{x:832,y:588,t:1527009347166};\\\", \\\"{x:833,y:585,t:1527009347183};\\\", \\\"{x:835,y:582,t:1527009347200};\\\", \\\"{x:836,y:582,t:1527009347216};\\\", \\\"{x:836,y:580,t:1527009347233};\\\", \\\"{x:834,y:580,t:1527009347560};\\\", \\\"{x:833,y:580,t:1527009347569};\\\", \\\"{x:830,y:580,t:1527009347583};\\\", \\\"{x:816,y:584,t:1527009347601};\\\", \\\"{x:804,y:589,t:1527009347616};\\\", \\\"{x:778,y:600,t:1527009347634};\\\", \\\"{x:753,y:613,t:1527009347651};\\\", \\\"{x:725,y:621,t:1527009347666};\\\", \\\"{x:700,y:628,t:1527009347684};\\\", \\\"{x:679,y:636,t:1527009347701};\\\", \\\"{x:663,y:641,t:1527009347717};\\\", \\\"{x:653,y:645,t:1527009347733};\\\", \\\"{x:646,y:648,t:1527009347750};\\\", \\\"{x:637,y:655,t:1527009347767};\\\", \\\"{x:625,y:663,t:1527009347783};\\\", \\\"{x:608,y:675,t:1527009347800};\\\", \\\"{x:594,y:683,t:1527009347817};\\\", \\\"{x:577,y:690,t:1527009347833};\\\", \\\"{x:556,y:697,t:1527009347850};\\\", \\\"{x:533,y:705,t:1527009347867};\\\", \\\"{x:526,y:707,t:1527009347884};\\\", \\\"{x:523,y:709,t:1527009347900};\\\", \\\"{x:520,y:711,t:1527009347917};\\\", \\\"{x:517,y:715,t:1527009347934};\\\", \\\"{x:515,y:718,t:1527009347950};\\\", \\\"{x:512,y:721,t:1527009347969};\\\", \\\"{x:511,y:722,t:1527009347984};\\\", \\\"{x:510,y:722,t:1527009348057};\\\", \\\"{x:510,y:723,t:1527009348067};\\\", \\\"{x:507,y:727,t:1527009348084};\\\", \\\"{x:504,y:731,t:1527009348100};\\\", \\\"{x:503,y:733,t:1527009348117};\\\", \\\"{x:503,y:734,t:1527009348134};\\\", \\\"{x:502,y:734,t:1527009348249};\\\", \\\"{x:501,y:734,t:1527009348284};\\\", \\\"{x:500,y:733,t:1527009348300};\\\", \\\"{x:499,y:733,t:1527009348577};\\\" ] }, { \\\"rt\\\": 24490, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 18, \\\"time_elapsed\\\": 538923, \\\"internal_node_id\\\": \\\"0.0-6.0-8.0\\\", \\\"subject\\\": \\\"R06S6\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"echo\\\", \\\"condition\\\": \\\"121\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"endtime\\\", \\\"q\\\": 14, \\\"clicks\\\": 1, \\\"explicit\\\": 1, \\\"impasse\\\": 2, \\\"axis\\\": \\\"Orthogonal-XInside-YFull\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 1, \\\"answer\\\": [ \\\"B\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-N -03 PM-O -03 PM-B -B -B -B -M \\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:497,y:733,t:1527009349561};\\\", \\\"{x:497,y:730,t:1527009350160};\\\", \\\"{x:503,y:713,t:1527009350168};\\\", \\\"{x:544,y:664,t:1527009350185};\\\", \\\"{x:593,y:623,t:1527009350203};\\\", \\\"{x:628,y:590,t:1527009350219};\\\", \\\"{x:658,y:566,t:1527009350235};\\\", \\\"{x:683,y:544,t:1527009350252};\\\", \\\"{x:697,y:533,t:1527009350268};\\\", \\\"{x:704,y:526,t:1527009350285};\\\", \\\"{x:708,y:524,t:1527009350302};\\\", \\\"{x:711,y:523,t:1527009350319};\\\", \\\"{x:717,y:519,t:1527009350335};\\\", \\\"{x:723,y:516,t:1527009350353};\\\", \\\"{x:727,y:515,t:1527009350368};\\\", \\\"{x:728,y:515,t:1527009350632};\\\", \\\"{x:732,y:515,t:1527009350649};\\\", \\\"{x:745,y:528,t:1527009350658};\\\", \\\"{x:766,y:548,t:1527009350669};\\\", \\\"{x:829,y:587,t:1527009350686};\\\", \\\"{x:909,y:622,t:1527009350703};\\\", \\\"{x:995,y:646,t:1527009350720};\\\", \\\"{x:1152,y:682,t:1527009350736};\\\", \\\"{x:1274,y:701,t:1527009350752};\\\", \\\"{x:1386,y:721,t:1527009350769};\\\", \\\"{x:1492,y:742,t:1527009350785};\\\", \\\"{x:1579,y:761,t:1527009350802};\\\", \\\"{x:1624,y:773,t:1527009350819};\\\", \\\"{x:1651,y:783,t:1527009350835};\\\", \\\"{x:1674,y:794,t:1527009350852};\\\", \\\"{x:1687,y:800,t:1527009350869};\\\", \\\"{x:1694,y:805,t:1527009350885};\\\", \\\"{x:1700,y:811,t:1527009350903};\\\", \\\"{x:1703,y:817,t:1527009350919};\\\", \\\"{x:1705,y:823,t:1527009350935};\\\", \\\"{x:1710,y:831,t:1527009350952};\\\", \\\"{x:1710,y:832,t:1527009350968};\\\", \\\"{x:1710,y:834,t:1527009350986};\\\", \\\"{x:1709,y:834,t:1527009351042};\\\", \\\"{x:1708,y:834,t:1527009351056};\\\", \\\"{x:1707,y:834,t:1527009351072};\\\", \\\"{x:1706,y:834,t:1527009351225};\\\", \\\"{x:1706,y:833,t:1527009351236};\\\", \\\"{x:1705,y:833,t:1527009351370};\\\", \\\"{x:1703,y:833,t:1527009351386};\\\", \\\"{x:1690,y:833,t:1527009351402};\\\", \\\"{x:1678,y:833,t:1527009351422};\\\", \\\"{x:1659,y:833,t:1527009351435};\\\", \\\"{x:1650,y:833,t:1527009351452};\\\", \\\"{x:1646,y:833,t:1527009351469};\\\", \\\"{x:1644,y:833,t:1527009351486};\\\", \\\"{x:1642,y:833,t:1527009351504};\\\", \\\"{x:1639,y:836,t:1527009351519};\\\", \\\"{x:1631,y:859,t:1527009351535};\\\", \\\"{x:1594,y:929,t:1527009351552};\\\", \\\"{x:1579,y:960,t:1527009351569};\\\", \\\"{x:1569,y:979,t:1527009351585};\\\", \\\"{x:1563,y:990,t:1527009351602};\\\", \\\"{x:1561,y:994,t:1527009351619};\\\", \\\"{x:1558,y:996,t:1527009351635};\\\", \\\"{x:1557,y:996,t:1527009351652};\\\", \\\"{x:1556,y:996,t:1527009351897};\\\", \\\"{x:1556,y:995,t:1527009351905};\\\", \\\"{x:1556,y:992,t:1527009351919};\\\", \\\"{x:1555,y:991,t:1527009351935};\\\", \\\"{x:1555,y:989,t:1527009351953};\\\", \\\"{x:1554,y:988,t:1527009351969};\\\", \\\"{x:1553,y:986,t:1527009351986};\\\", \\\"{x:1553,y:985,t:1527009352017};\\\", \\\"{x:1552,y:985,t:1527009352065};\\\", \\\"{x:1552,y:984,t:1527009352674};\\\", \\\"{x:1552,y:982,t:1527009352685};\\\", \\\"{x:1552,y:979,t:1527009352702};\\\", \\\"{x:1552,y:976,t:1527009352720};\\\", \\\"{x:1552,y:974,t:1527009352736};\\\", \\\"{x:1552,y:973,t:1527009352762};\\\", \\\"{x:1552,y:969,t:1527009358497};\\\", \\\"{x:1552,y:960,t:1527009358506};\\\", \\\"{x:1555,y:954,t:1527009358519};\\\", \\\"{x:1558,y:941,t:1527009358536};\\\", \\\"{x:1562,y:925,t:1527009358552};\\\", \\\"{x:1562,y:920,t:1527009358570};\\\", \\\"{x:1562,y:918,t:1527009358586};\\\", \\\"{x:1562,y:914,t:1527009358602};\\\", \\\"{x:1562,y:912,t:1527009358619};\\\", \\\"{x:1562,y:910,t:1527009358635};\\\", \\\"{x:1562,y:908,t:1527009358652};\\\", \\\"{x:1562,y:906,t:1527009358669};\\\", \\\"{x:1560,y:902,t:1527009358685};\\\", \\\"{x:1558,y:899,t:1527009358702};\\\", \\\"{x:1557,y:895,t:1527009358720};\\\", \\\"{x:1553,y:889,t:1527009358736};\\\", \\\"{x:1550,y:883,t:1527009358752};\\\", \\\"{x:1549,y:879,t:1527009358769};\\\", \\\"{x:1543,y:873,t:1527009358785};\\\", \\\"{x:1536,y:862,t:1527009358803};\\\", \\\"{x:1529,y:851,t:1527009358819};\\\", \\\"{x:1522,y:842,t:1527009358836};\\\", \\\"{x:1516,y:831,t:1527009358853};\\\", \\\"{x:1509,y:821,t:1527009358870};\\\", \\\"{x:1506,y:815,t:1527009358886};\\\", \\\"{x:1501,y:808,t:1527009358903};\\\", \\\"{x:1501,y:804,t:1527009358920};\\\", \\\"{x:1498,y:799,t:1527009358936};\\\", \\\"{x:1498,y:795,t:1527009358953};\\\", \\\"{x:1497,y:792,t:1527009358970};\\\", \\\"{x:1497,y:789,t:1527009358986};\\\", \\\"{x:1495,y:786,t:1527009359003};\\\", \\\"{x:1495,y:783,t:1527009359020};\\\", \\\"{x:1495,y:780,t:1527009359036};\\\", \\\"{x:1495,y:779,t:1527009359053};\\\", \\\"{x:1495,y:777,t:1527009359070};\\\", \\\"{x:1495,y:776,t:1527009359086};\\\", \\\"{x:1496,y:775,t:1527009359129};\\\", \\\"{x:1496,y:774,t:1527009359137};\\\", \\\"{x:1498,y:773,t:1527009359153};\\\", \\\"{x:1499,y:773,t:1527009359177};\\\", \\\"{x:1500,y:773,t:1527009359187};\\\", \\\"{x:1501,y:772,t:1527009359203};\\\", \\\"{x:1502,y:771,t:1527009359220};\\\", \\\"{x:1503,y:770,t:1527009359236};\\\", \\\"{x:1506,y:770,t:1527009359253};\\\", \\\"{x:1507,y:769,t:1527009359270};\\\", \\\"{x:1508,y:768,t:1527009359285};\\\", \\\"{x:1509,y:767,t:1527009359303};\\\", \\\"{x:1510,y:767,t:1527009359320};\\\", \\\"{x:1512,y:766,t:1527009359335};\\\", \\\"{x:1513,y:765,t:1527009359352};\\\", \\\"{x:1514,y:764,t:1527009359370};\\\", \\\"{x:1515,y:763,t:1527009359392};\\\", \\\"{x:1516,y:763,t:1527009359424};\\\", \\\"{x:1517,y:762,t:1527009359456};\\\", \\\"{x:1518,y:762,t:1527009359593};\\\", \\\"{x:1519,y:761,t:1527009359603};\\\", \\\"{x:1520,y:761,t:1527009359642};\\\", \\\"{x:1521,y:761,t:1527009359673};\\\", \\\"{x:1522,y:760,t:1527009359686};\\\", \\\"{x:1524,y:759,t:1527009359713};\\\", \\\"{x:1525,y:759,t:1527009359737};\\\", \\\"{x:1526,y:758,t:1527009359753};\\\", \\\"{x:1528,y:758,t:1527009359771};\\\", \\\"{x:1529,y:757,t:1527009359787};\\\", \\\"{x:1531,y:757,t:1527009359803};\\\", \\\"{x:1532,y:757,t:1527009359820};\\\", \\\"{x:1533,y:757,t:1527009359836};\\\", \\\"{x:1536,y:757,t:1527009359853};\\\", \\\"{x:1538,y:757,t:1527009359870};\\\", \\\"{x:1545,y:758,t:1527009359886};\\\", \\\"{x:1548,y:760,t:1527009359902};\\\", \\\"{x:1549,y:764,t:1527009359919};\\\", \\\"{x:1549,y:777,t:1527009359935};\\\", \\\"{x:1549,y:808,t:1527009359952};\\\", \\\"{x:1549,y:831,t:1527009359970};\\\", \\\"{x:1549,y:851,t:1527009359985};\\\", \\\"{x:1548,y:867,t:1527009360003};\\\", \\\"{x:1545,y:882,t:1527009360020};\\\", \\\"{x:1543,y:903,t:1527009360035};\\\", \\\"{x:1537,y:924,t:1527009360053};\\\", \\\"{x:1532,y:944,t:1527009360070};\\\", \\\"{x:1528,y:958,t:1527009360086};\\\", \\\"{x:1526,y:965,t:1527009360102};\\\", \\\"{x:1524,y:970,t:1527009360120};\\\", \\\"{x:1524,y:971,t:1527009360136};\\\", \\\"{x:1523,y:972,t:1527009360153};\\\", \\\"{x:1523,y:973,t:1527009360257};\\\", \\\"{x:1524,y:973,t:1527009360270};\\\", \\\"{x:1527,y:974,t:1527009360285};\\\", \\\"{x:1528,y:974,t:1527009360302};\\\", \\\"{x:1529,y:976,t:1527009360319};\\\", \\\"{x:1530,y:976,t:1527009360335};\\\", \\\"{x:1534,y:977,t:1527009360352};\\\", \\\"{x:1535,y:977,t:1527009360416};\\\", \\\"{x:1536,y:978,t:1527009360424};\\\", \\\"{x:1537,y:978,t:1527009360436};\\\", \\\"{x:1539,y:979,t:1527009360453};\\\", \\\"{x:1540,y:980,t:1527009360470};\\\", \\\"{x:1541,y:980,t:1527009360528};\\\", \\\"{x:1542,y:977,t:1527009360536};\\\", \\\"{x:1544,y:973,t:1527009360552};\\\", \\\"{x:1544,y:969,t:1527009360570};\\\", \\\"{x:1545,y:966,t:1527009360585};\\\", \\\"{x:1545,y:962,t:1527009360602};\\\", \\\"{x:1545,y:961,t:1527009360619};\\\", \\\"{x:1546,y:959,t:1527009360635};\\\", \\\"{x:1546,y:957,t:1527009360653};\\\", \\\"{x:1546,y:953,t:1527009360670};\\\", \\\"{x:1546,y:951,t:1527009360685};\\\", \\\"{x:1546,y:948,t:1527009360703};\\\", \\\"{x:1546,y:943,t:1527009360720};\\\", \\\"{x:1546,y:937,t:1527009360736};\\\", \\\"{x:1546,y:932,t:1527009360753};\\\", \\\"{x:1546,y:926,t:1527009360770};\\\", \\\"{x:1545,y:919,t:1527009360786};\\\", \\\"{x:1541,y:908,t:1527009360803};\\\", \\\"{x:1539,y:898,t:1527009360820};\\\", \\\"{x:1537,y:887,t:1527009360835};\\\", \\\"{x:1537,y:878,t:1527009360853};\\\", \\\"{x:1537,y:869,t:1527009360870};\\\", \\\"{x:1537,y:858,t:1527009360886};\\\", \\\"{x:1535,y:849,t:1527009360903};\\\", \\\"{x:1535,y:840,t:1527009360920};\\\", \\\"{x:1535,y:833,t:1527009360935};\\\", \\\"{x:1533,y:821,t:1527009360953};\\\", \\\"{x:1533,y:816,t:1527009360970};\\\", \\\"{x:1533,y:807,t:1527009360986};\\\", \\\"{x:1533,y:797,t:1527009361003};\\\", \\\"{x:1533,y:791,t:1527009361020};\\\", \\\"{x:1532,y:783,t:1527009361036};\\\", \\\"{x:1531,y:779,t:1527009361052};\\\", \\\"{x:1531,y:773,t:1527009361070};\\\", \\\"{x:1529,y:765,t:1527009361086};\\\", \\\"{x:1528,y:755,t:1527009361103};\\\", \\\"{x:1527,y:746,t:1527009361120};\\\", \\\"{x:1526,y:742,t:1527009361136};\\\", \\\"{x:1526,y:732,t:1527009361152};\\\", \\\"{x:1525,y:725,t:1527009361170};\\\", \\\"{x:1524,y:717,t:1527009361185};\\\", \\\"{x:1524,y:706,t:1527009361203};\\\", \\\"{x:1524,y:695,t:1527009361220};\\\", \\\"{x:1524,y:682,t:1527009361236};\\\", \\\"{x:1524,y:677,t:1527009361253};\\\", \\\"{x:1524,y:673,t:1527009361270};\\\", \\\"{x:1524,y:671,t:1527009361285};\\\", \\\"{x:1524,y:670,t:1527009361302};\\\", \\\"{x:1524,y:667,t:1527009361320};\\\", \\\"{x:1524,y:664,t:1527009361336};\\\", \\\"{x:1524,y:661,t:1527009361354};\\\", \\\"{x:1524,y:660,t:1527009361371};\\\", \\\"{x:1528,y:663,t:1527009361591};\\\", \\\"{x:1530,y:666,t:1527009361602};\\\", \\\"{x:1533,y:674,t:1527009361620};\\\", \\\"{x:1534,y:681,t:1527009361635};\\\", \\\"{x:1536,y:685,t:1527009361652};\\\", \\\"{x:1536,y:688,t:1527009361669};\\\", \\\"{x:1537,y:689,t:1527009361685};\\\", \\\"{x:1537,y:690,t:1527009361703};\\\", \\\"{x:1537,y:691,t:1527009361720};\\\", \\\"{x:1538,y:691,t:1527009361736};\\\", \\\"{x:1538,y:694,t:1527009361752};\\\", \\\"{x:1539,y:695,t:1527009361770};\\\", \\\"{x:1539,y:696,t:1527009361792};\\\", \\\"{x:1539,y:697,t:1527009361808};\\\", \\\"{x:1539,y:698,t:1527009361824};\\\", \\\"{x:1539,y:699,t:1527009361836};\\\", \\\"{x:1539,y:700,t:1527009361853};\\\", \\\"{x:1539,y:702,t:1527009361870};\\\", \\\"{x:1540,y:704,t:1527009361886};\\\", \\\"{x:1540,y:705,t:1527009362378};\\\", \\\"{x:1540,y:707,t:1527009362386};\\\", \\\"{x:1540,y:708,t:1527009362417};\\\", \\\"{x:1540,y:709,t:1527009365194};\\\", \\\"{x:1539,y:711,t:1527009365204};\\\", \\\"{x:1535,y:713,t:1527009365221};\\\", \\\"{x:1534,y:714,t:1527009365236};\\\", \\\"{x:1532,y:715,t:1527009365253};\\\", \\\"{x:1531,y:715,t:1527009365281};\\\", \\\"{x:1528,y:717,t:1527009365296};\\\", \\\"{x:1525,y:718,t:1527009365305};\\\", \\\"{x:1520,y:720,t:1527009365319};\\\", \\\"{x:1508,y:723,t:1527009365336};\\\", \\\"{x:1479,y:732,t:1527009365353};\\\", \\\"{x:1451,y:739,t:1527009365369};\\\", \\\"{x:1423,y:745,t:1527009365386};\\\", \\\"{x:1394,y:750,t:1527009365403};\\\", \\\"{x:1366,y:753,t:1527009365420};\\\", \\\"{x:1342,y:757,t:1527009365437};\\\", \\\"{x:1327,y:759,t:1527009365454};\\\", \\\"{x:1319,y:760,t:1527009365470};\\\", \\\"{x:1316,y:761,t:1527009365486};\\\", \\\"{x:1316,y:762,t:1527009365504};\\\", \\\"{x:1317,y:764,t:1527009365657};\\\", \\\"{x:1318,y:764,t:1527009365669};\\\", \\\"{x:1320,y:765,t:1527009365685};\\\", \\\"{x:1322,y:765,t:1527009365703};\\\", \\\"{x:1325,y:767,t:1527009365719};\\\", \\\"{x:1326,y:767,t:1527009365735};\\\", \\\"{x:1327,y:767,t:1527009365753};\\\", \\\"{x:1328,y:767,t:1527009365776};\\\", \\\"{x:1329,y:767,t:1527009365786};\\\", \\\"{x:1330,y:767,t:1527009365803};\\\", \\\"{x:1332,y:767,t:1527009365824};\\\", \\\"{x:1333,y:765,t:1527009365929};\\\", \\\"{x:1334,y:764,t:1527009365936};\\\", \\\"{x:1335,y:763,t:1527009365953};\\\", \\\"{x:1336,y:761,t:1527009365970};\\\", \\\"{x:1337,y:760,t:1527009365986};\\\", \\\"{x:1337,y:759,t:1527009366003};\\\", \\\"{x:1338,y:759,t:1527009366019};\\\", \\\"{x:1339,y:757,t:1527009366040};\\\", \\\"{x:1340,y:757,t:1527009366053};\\\", \\\"{x:1341,y:755,t:1527009366072};\\\", \\\"{x:1342,y:754,t:1527009366096};\\\", \\\"{x:1343,y:753,t:1527009366105};\\\", \\\"{x:1345,y:752,t:1527009366121};\\\", \\\"{x:1346,y:751,t:1527009366161};\\\", \\\"{x:1347,y:749,t:1527009366193};\\\", \\\"{x:1347,y:748,t:1527009366217};\\\", \\\"{x:1348,y:748,t:1527009366224};\\\", \\\"{x:1348,y:746,t:1527009366236};\\\", \\\"{x:1348,y:745,t:1527009366257};\\\", \\\"{x:1348,y:743,t:1527009366289};\\\", \\\"{x:1348,y:742,t:1527009366312};\\\", \\\"{x:1348,y:741,t:1527009366370};\\\", \\\"{x:1348,y:747,t:1527009367033};\\\", \\\"{x:1348,y:757,t:1527009367040};\\\", \\\"{x:1345,y:766,t:1527009367054};\\\", \\\"{x:1338,y:786,t:1527009367072};\\\", \\\"{x:1332,y:801,t:1527009367087};\\\", \\\"{x:1326,y:809,t:1527009367103};\\\", \\\"{x:1321,y:813,t:1527009367119};\\\", \\\"{x:1302,y:819,t:1527009367137};\\\", \\\"{x:1276,y:820,t:1527009367153};\\\", \\\"{x:1236,y:820,t:1527009367170};\\\", \\\"{x:1182,y:820,t:1527009367186};\\\", \\\"{x:1080,y:808,t:1527009367204};\\\", \\\"{x:994,y:783,t:1527009367220};\\\", \\\"{x:905,y:758,t:1527009367236};\\\", \\\"{x:836,y:727,t:1527009367253};\\\", \\\"{x:801,y:707,t:1527009367269};\\\", \\\"{x:776,y:692,t:1527009367286};\\\", \\\"{x:753,y:679,t:1527009367303};\\\", \\\"{x:729,y:664,t:1527009367319};\\\", \\\"{x:709,y:655,t:1527009367336};\\\", \\\"{x:688,y:645,t:1527009367353};\\\", \\\"{x:664,y:639,t:1527009367370};\\\", \\\"{x:649,y:634,t:1527009367385};\\\", \\\"{x:643,y:632,t:1527009367403};\\\", \\\"{x:640,y:630,t:1527009367419};\\\", \\\"{x:636,y:628,t:1527009367436};\\\", \\\"{x:628,y:622,t:1527009367453};\\\", \\\"{x:619,y:618,t:1527009367462};\\\", \\\"{x:602,y:608,t:1527009367479};\\\", \\\"{x:591,y:601,t:1527009367494};\\\", \\\"{x:571,y:588,t:1527009367512};\\\", \\\"{x:553,y:577,t:1527009367532};\\\", \\\"{x:523,y:562,t:1527009367549};\\\", \\\"{x:466,y:543,t:1527009367566};\\\", \\\"{x:396,y:517,t:1527009367584};\\\", \\\"{x:318,y:497,t:1527009367599};\\\", \\\"{x:228,y:475,t:1527009367616};\\\", \\\"{x:196,y:474,t:1527009367631};\\\", \\\"{x:165,y:474,t:1527009367648};\\\", \\\"{x:146,y:474,t:1527009367666};\\\", \\\"{x:138,y:474,t:1527009367683};\\\", \\\"{x:134,y:474,t:1527009367699};\\\", \\\"{x:125,y:477,t:1527009367716};\\\", \\\"{x:114,y:482,t:1527009367733};\\\", \\\"{x:103,y:490,t:1527009367750};\\\", \\\"{x:97,y:498,t:1527009367766};\\\", \\\"{x:95,y:503,t:1527009367783};\\\", \\\"{x:95,y:509,t:1527009367799};\\\", \\\"{x:95,y:511,t:1527009367816};\\\", \\\"{x:95,y:514,t:1527009367833};\\\", \\\"{x:95,y:517,t:1527009367849};\\\", \\\"{x:96,y:523,t:1527009367867};\\\", \\\"{x:101,y:532,t:1527009367883};\\\", \\\"{x:105,y:536,t:1527009367899};\\\", \\\"{x:109,y:538,t:1527009367916};\\\", \\\"{x:111,y:538,t:1527009367933};\\\", \\\"{x:115,y:538,t:1527009367950};\\\", \\\"{x:123,y:538,t:1527009367966};\\\", \\\"{x:130,y:538,t:1527009367983};\\\", \\\"{x:142,y:538,t:1527009368000};\\\", \\\"{x:150,y:538,t:1527009368016};\\\", \\\"{x:155,y:537,t:1527009368033};\\\", \\\"{x:160,y:537,t:1527009368050};\\\", \\\"{x:162,y:537,t:1527009368066};\\\", \\\"{x:164,y:537,t:1527009368083};\\\", \\\"{x:165,y:537,t:1527009368104};\\\", \\\"{x:166,y:537,t:1527009368145};\\\", \\\"{x:167,y:537,t:1527009368168};\\\", \\\"{x:171,y:537,t:1527009368594};\\\", \\\"{x:177,y:538,t:1527009368600};\\\", \\\"{x:224,y:553,t:1527009368618};\\\", \\\"{x:314,y:576,t:1527009368634};\\\", \\\"{x:453,y:615,t:1527009368651};\\\", \\\"{x:631,y:654,t:1527009368667};\\\", \\\"{x:814,y:683,t:1527009368683};\\\", \\\"{x:1018,y:710,t:1527009368699};\\\", \\\"{x:1203,y:738,t:1527009368716};\\\", \\\"{x:1350,y:759,t:1527009368733};\\\", \\\"{x:1462,y:782,t:1527009368750};\\\", \\\"{x:1547,y:803,t:1527009368767};\\\", \\\"{x:1595,y:816,t:1527009368783};\\\", \\\"{x:1632,y:828,t:1527009368800};\\\", \\\"{x:1649,y:832,t:1527009368816};\\\", \\\"{x:1658,y:835,t:1527009368833};\\\", \\\"{x:1667,y:839,t:1527009368850};\\\", \\\"{x:1673,y:841,t:1527009368866};\\\", \\\"{x:1674,y:842,t:1527009368882};\\\", \\\"{x:1675,y:844,t:1527009368993};\\\", \\\"{x:1675,y:845,t:1527009369001};\\\", \\\"{x:1669,y:849,t:1527009369017};\\\", \\\"{x:1661,y:853,t:1527009369033};\\\", \\\"{x:1656,y:857,t:1527009369050};\\\", \\\"{x:1648,y:863,t:1527009369066};\\\", \\\"{x:1639,y:869,t:1527009369084};\\\", \\\"{x:1630,y:876,t:1527009369100};\\\", \\\"{x:1613,y:889,t:1527009369116};\\\", \\\"{x:1594,y:902,t:1527009369134};\\\", \\\"{x:1573,y:915,t:1527009369151};\\\", \\\"{x:1556,y:926,t:1527009369166};\\\", \\\"{x:1541,y:935,t:1527009369183};\\\", \\\"{x:1520,y:943,t:1527009369201};\\\", \\\"{x:1507,y:945,t:1527009369217};\\\", \\\"{x:1496,y:949,t:1527009369233};\\\", \\\"{x:1484,y:953,t:1527009369249};\\\", \\\"{x:1473,y:957,t:1527009369267};\\\", \\\"{x:1466,y:959,t:1527009369283};\\\", \\\"{x:1459,y:961,t:1527009369300};\\\", \\\"{x:1453,y:962,t:1527009369317};\\\", \\\"{x:1450,y:962,t:1527009369333};\\\", \\\"{x:1445,y:963,t:1527009369350};\\\", \\\"{x:1439,y:965,t:1527009369367};\\\", \\\"{x:1428,y:966,t:1527009369384};\\\", \\\"{x:1417,y:967,t:1527009369399};\\\", \\\"{x:1396,y:967,t:1527009369417};\\\", \\\"{x:1387,y:967,t:1527009369433};\\\", \\\"{x:1380,y:965,t:1527009369450};\\\", \\\"{x:1374,y:964,t:1527009369467};\\\", \\\"{x:1369,y:962,t:1527009369484};\\\", \\\"{x:1362,y:961,t:1527009369500};\\\", \\\"{x:1354,y:960,t:1527009369517};\\\", \\\"{x:1349,y:960,t:1527009369534};\\\", \\\"{x:1345,y:957,t:1527009369550};\\\", \\\"{x:1344,y:957,t:1527009369577};\\\", \\\"{x:1342,y:955,t:1527009369593};\\\", \\\"{x:1342,y:954,t:1527009369601};\\\", \\\"{x:1338,y:949,t:1527009369616};\\\", \\\"{x:1337,y:944,t:1527009369632};\\\", \\\"{x:1334,y:941,t:1527009369649};\\\", \\\"{x:1334,y:939,t:1527009369666};\\\", \\\"{x:1334,y:937,t:1527009369683};\\\", \\\"{x:1333,y:936,t:1527009369699};\\\", \\\"{x:1333,y:934,t:1527009369716};\\\", \\\"{x:1333,y:933,t:1527009369744};\\\", \\\"{x:1333,y:931,t:1527009369768};\\\", \\\"{x:1333,y:930,t:1527009369784};\\\", \\\"{x:1333,y:929,t:1527009369799};\\\", \\\"{x:1333,y:928,t:1527009369816};\\\", \\\"{x:1334,y:927,t:1527009369832};\\\", \\\"{x:1334,y:926,t:1527009369849};\\\", \\\"{x:1335,y:925,t:1527009369866};\\\", \\\"{x:1336,y:924,t:1527009369883};\\\", \\\"{x:1337,y:923,t:1527009369905};\\\", \\\"{x:1340,y:917,t:1527009371017};\\\", \\\"{x:1353,y:903,t:1527009371031};\\\", \\\"{x:1379,y:878,t:1527009371049};\\\", \\\"{x:1396,y:860,t:1527009371066};\\\", \\\"{x:1408,y:845,t:1527009371081};\\\", \\\"{x:1424,y:831,t:1527009371097};\\\", \\\"{x:1435,y:816,t:1527009371115};\\\", \\\"{x:1443,y:797,t:1527009371131};\\\", \\\"{x:1451,y:777,t:1527009371148};\\\", \\\"{x:1457,y:760,t:1527009371165};\\\", \\\"{x:1457,y:753,t:1527009371180};\\\", \\\"{x:1457,y:748,t:1527009371198};\\\", \\\"{x:1457,y:745,t:1527009371215};\\\", \\\"{x:1457,y:743,t:1527009371231};\\\", \\\"{x:1453,y:742,t:1527009371249};\\\", \\\"{x:1451,y:738,t:1527009371265};\\\", \\\"{x:1449,y:734,t:1527009371281};\\\", \\\"{x:1443,y:716,t:1527009371665};\\\", \\\"{x:1441,y:704,t:1527009371681};\\\", \\\"{x:1440,y:703,t:1527009371699};\\\", \\\"{x:1439,y:699,t:1527009371715};\\\", \\\"{x:1436,y:693,t:1527009371731};\\\", \\\"{x:1433,y:687,t:1527009371748};\\\", \\\"{x:1433,y:684,t:1527009371764};\\\", \\\"{x:1432,y:681,t:1527009371781};\\\", \\\"{x:1432,y:680,t:1527009371799};\\\", \\\"{x:1431,y:678,t:1527009371814};\\\", \\\"{x:1431,y:677,t:1527009371831};\\\", \\\"{x:1431,y:673,t:1527009371945};\\\", \\\"{x:1431,y:671,t:1527009371953};\\\", \\\"{x:1430,y:669,t:1527009371964};\\\", \\\"{x:1427,y:663,t:1527009371981};\\\", \\\"{x:1422,y:655,t:1527009371998};\\\", \\\"{x:1418,y:649,t:1527009372014};\\\", \\\"{x:1416,y:644,t:1527009372031};\\\", \\\"{x:1414,y:642,t:1527009372047};\\\", \\\"{x:1411,y:637,t:1527009372065};\\\", \\\"{x:1411,y:636,t:1527009372097};\\\", \\\"{x:1407,y:639,t:1527009372273};\\\", \\\"{x:1405,y:645,t:1527009372281};\\\", \\\"{x:1402,y:658,t:1527009372298};\\\", \\\"{x:1400,y:667,t:1527009372314};\\\", \\\"{x:1398,y:672,t:1527009372332};\\\", \\\"{x:1397,y:675,t:1527009372348};\\\", \\\"{x:1397,y:682,t:1527009372364};\\\", \\\"{x:1397,y:688,t:1527009372381};\\\", \\\"{x:1397,y:696,t:1527009372398};\\\", \\\"{x:1397,y:704,t:1527009372414};\\\", \\\"{x:1397,y:713,t:1527009372431};\\\", \\\"{x:1397,y:721,t:1527009372447};\\\", \\\"{x:1398,y:737,t:1527009372464};\\\", \\\"{x:1399,y:746,t:1527009372481};\\\", \\\"{x:1400,y:752,t:1527009372497};\\\", \\\"{x:1401,y:759,t:1527009372515};\\\", \\\"{x:1404,y:767,t:1527009372531};\\\", \\\"{x:1404,y:775,t:1527009372548};\\\", \\\"{x:1404,y:780,t:1527009372564};\\\", \\\"{x:1404,y:784,t:1527009372580};\\\", \\\"{x:1404,y:790,t:1527009372598};\\\", \\\"{x:1405,y:796,t:1527009372614};\\\", \\\"{x:1407,y:801,t:1527009372630};\\\", \\\"{x:1407,y:803,t:1527009372648};\\\", \\\"{x:1408,y:806,t:1527009372665};\\\", \\\"{x:1408,y:808,t:1527009372681};\\\", \\\"{x:1408,y:809,t:1527009372697};\\\", \\\"{x:1393,y:810,t:1527009373009};\\\", \\\"{x:1345,y:810,t:1527009373016};\\\", \\\"{x:1284,y:805,t:1527009373030};\\\", \\\"{x:1137,y:783,t:1527009373048};\\\", \\\"{x:968,y:759,t:1527009373063};\\\", \\\"{x:718,y:746,t:1527009373080};\\\", \\\"{x:592,y:741,t:1527009373096};\\\", \\\"{x:517,y:739,t:1527009373115};\\\", \\\"{x:496,y:739,t:1527009373130};\\\", \\\"{x:494,y:739,t:1527009373146};\\\", \\\"{x:494,y:740,t:1527009373170};\\\", \\\"{x:492,y:742,t:1527009373192};\\\", \\\"{x:491,y:744,t:1527009373203};\\\", \\\"{x:485,y:751,t:1527009373219};\\\", \\\"{x:479,y:751,t:1527009373237};\\\", \\\"{x:473,y:751,t:1527009373253};\\\", \\\"{x:472,y:748,t:1527009373269};\\\", \\\"{x:471,y:731,t:1527009373287};\\\", \\\"{x:476,y:703,t:1527009373303};\\\", \\\"{x:493,y:674,t:1527009373320};\\\", \\\"{x:507,y:661,t:1527009373337};\\\", \\\"{x:520,y:654,t:1527009373353};\\\", \\\"{x:530,y:650,t:1527009373370};\\\", \\\"{x:535,y:647,t:1527009373387};\\\", \\\"{x:535,y:648,t:1527009373457};\\\", \\\"{x:535,y:659,t:1527009373470};\\\", \\\"{x:532,y:699,t:1527009373487};\\\", \\\"{x:520,y:747,t:1527009373504};\\\", \\\"{x:519,y:764,t:1527009373520};\\\", \\\"{x:518,y:769,t:1527009373537};\\\", \\\"{x:518,y:770,t:1527009373554};\\\", \\\"{x:517,y:771,t:1527009373600};\\\", \\\"{x:517,y:770,t:1527009373737};\\\", \\\"{x:518,y:756,t:1527009373754};\\\", \\\"{x:519,y:747,t:1527009373771};\\\", \\\"{x:520,y:741,t:1527009373787};\\\", \\\"{x:521,y:736,t:1527009373804};\\\", \\\"{x:523,y:733,t:1527009373821};\\\", \\\"{x:523,y:732,t:1527009373856};\\\" ] }, { \\\"rt\\\": 29435, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 19, \\\"time_elapsed\\\": 569653, \\\"internal_node_id\\\": \\\"0.0-6.0-9.0\\\", \\\"subject\\\": \\\"R06S6\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"echo\\\", \\\"condition\\\": \\\"121\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"midpoint\\\", \\\"q\\\": 15, \\\"clicks\\\": 2.5, \\\"explicit\\\": 1, \\\"impasse\\\": 2, \\\"axis\\\": \\\"Orthogonal-XInside-YFull\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 0, \\\"answer\\\": [ \\\"B\\\", \\\"M\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-M -01 PM-12 PM-M -M -M \\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:524,y:731,t:1527009376684};\\\", \\\"{x:527,y:731,t:1527009376693};\\\", \\\"{x:542,y:728,t:1527009376709};\\\", \\\"{x:555,y:722,t:1527009376727};\\\", \\\"{x:567,y:717,t:1527009376743};\\\", \\\"{x:572,y:716,t:1527009376760};\\\", \\\"{x:574,y:714,t:1527009376776};\\\", \\\"{x:575,y:713,t:1527009376792};\\\", \\\"{x:577,y:713,t:1527009376809};\\\", \\\"{x:580,y:711,t:1527009376827};\\\", \\\"{x:583,y:709,t:1527009376842};\\\", \\\"{x:588,y:701,t:1527009376859};\\\", \\\"{x:590,y:698,t:1527009376876};\\\", \\\"{x:590,y:692,t:1527009376892};\\\", \\\"{x:591,y:688,t:1527009376910};\\\", \\\"{x:592,y:685,t:1527009376926};\\\", \\\"{x:592,y:682,t:1527009376942};\\\", \\\"{x:593,y:680,t:1527009376960};\\\", \\\"{x:593,y:677,t:1527009376976};\\\", \\\"{x:594,y:674,t:1527009376993};\\\", \\\"{x:594,y:671,t:1527009377010};\\\", \\\"{x:594,y:668,t:1527009377027};\\\", \\\"{x:594,y:665,t:1527009377043};\\\", \\\"{x:595,y:661,t:1527009377059};\\\", \\\"{x:597,y:658,t:1527009377077};\\\", \\\"{x:597,y:657,t:1527009377094};\\\", \\\"{x:598,y:656,t:1527009377110};\\\", \\\"{x:598,y:655,t:1527009377164};\\\", \\\"{x:600,y:655,t:1527009380581};\\\", \\\"{x:622,y:656,t:1527009380596};\\\", \\\"{x:708,y:656,t:1527009380613};\\\", \\\"{x:838,y:656,t:1527009380629};\\\", \\\"{x:993,y:656,t:1527009380646};\\\", \\\"{x:1159,y:656,t:1527009380663};\\\", \\\"{x:1294,y:656,t:1527009380679};\\\", \\\"{x:1397,y:656,t:1527009380696};\\\", \\\"{x:1440,y:656,t:1527009380714};\\\", \\\"{x:1450,y:656,t:1527009380729};\\\", \\\"{x:1455,y:659,t:1527009380844};\\\", \\\"{x:1465,y:663,t:1527009380852};\\\", \\\"{x:1476,y:670,t:1527009380863};\\\", \\\"{x:1496,y:683,t:1527009380879};\\\", \\\"{x:1516,y:705,t:1527009380897};\\\", \\\"{x:1538,y:732,t:1527009380913};\\\", \\\"{x:1551,y:762,t:1527009380931};\\\", \\\"{x:1556,y:787,t:1527009380947};\\\", \\\"{x:1556,y:806,t:1527009380964};\\\", \\\"{x:1553,y:823,t:1527009380980};\\\", \\\"{x:1553,y:824,t:1527009380996};\\\", \\\"{x:1553,y:825,t:1527009381083};\\\", \\\"{x:1553,y:828,t:1527009381107};\\\", \\\"{x:1552,y:832,t:1527009381115};\\\", \\\"{x:1551,y:835,t:1527009381129};\\\", \\\"{x:1549,y:843,t:1527009381146};\\\", \\\"{x:1547,y:854,t:1527009381163};\\\", \\\"{x:1544,y:872,t:1527009381178};\\\", \\\"{x:1540,y:883,t:1527009381196};\\\", \\\"{x:1536,y:892,t:1527009381213};\\\", \\\"{x:1535,y:898,t:1527009381230};\\\", \\\"{x:1535,y:904,t:1527009381246};\\\", \\\"{x:1535,y:910,t:1527009381262};\\\", \\\"{x:1535,y:916,t:1527009381280};\\\", \\\"{x:1535,y:924,t:1527009381296};\\\", \\\"{x:1534,y:936,t:1527009381313};\\\", \\\"{x:1531,y:944,t:1527009381330};\\\", \\\"{x:1528,y:950,t:1527009381347};\\\", \\\"{x:1526,y:954,t:1527009381363};\\\", \\\"{x:1526,y:958,t:1527009381380};\\\", \\\"{x:1526,y:960,t:1527009381397};\\\", \\\"{x:1524,y:961,t:1527009381413};\\\", \\\"{x:1524,y:963,t:1527009381430};\\\", \\\"{x:1524,y:964,t:1527009381447};\\\", \\\"{x:1523,y:965,t:1527009381463};\\\", \\\"{x:1523,y:966,t:1527009381480};\\\", \\\"{x:1522,y:966,t:1527009381497};\\\", \\\"{x:1521,y:967,t:1527009381514};\\\", \\\"{x:1520,y:967,t:1527009381637};\\\", \\\"{x:1518,y:967,t:1527009381652};\\\", \\\"{x:1517,y:967,t:1527009381668};\\\", \\\"{x:1516,y:967,t:1527009381684};\\\", \\\"{x:1515,y:967,t:1527009381697};\\\", \\\"{x:1514,y:967,t:1527009381713};\\\", \\\"{x:1512,y:967,t:1527009381731};\\\", \\\"{x:1511,y:967,t:1527009381747};\\\", \\\"{x:1510,y:967,t:1527009382221};\\\", \\\"{x:1509,y:967,t:1527009382252};\\\", \\\"{x:1508,y:967,t:1527009382452};\\\", \\\"{x:1506,y:967,t:1527009382464};\\\", \\\"{x:1505,y:967,t:1527009382481};\\\", \\\"{x:1503,y:967,t:1527009382498};\\\", \\\"{x:1495,y:966,t:1527009383724};\\\", \\\"{x:1483,y:962,t:1527009383732};\\\", \\\"{x:1453,y:953,t:1527009383748};\\\", \\\"{x:1422,y:945,t:1527009383765};\\\", \\\"{x:1368,y:929,t:1527009383783};\\\", \\\"{x:1302,y:910,t:1527009383798};\\\", \\\"{x:1274,y:901,t:1527009383816};\\\", \\\"{x:1262,y:896,t:1527009383833};\\\", \\\"{x:1260,y:895,t:1527009383849};\\\", \\\"{x:1259,y:893,t:1527009383866};\\\", \\\"{x:1259,y:888,t:1527009383884};\\\", \\\"{x:1259,y:886,t:1527009383898};\\\", \\\"{x:1259,y:884,t:1527009383915};\\\", \\\"{x:1264,y:876,t:1527009383932};\\\", \\\"{x:1272,y:869,t:1527009383949};\\\", \\\"{x:1284,y:860,t:1527009383966};\\\", \\\"{x:1298,y:849,t:1527009383983};\\\", \\\"{x:1313,y:838,t:1527009383998};\\\", \\\"{x:1327,y:828,t:1527009384016};\\\", \\\"{x:1338,y:815,t:1527009384032};\\\", \\\"{x:1351,y:801,t:1527009384049};\\\", \\\"{x:1358,y:793,t:1527009384066};\\\", \\\"{x:1365,y:777,t:1527009384083};\\\", \\\"{x:1366,y:776,t:1527009384098};\\\", \\\"{x:1368,y:768,t:1527009384115};\\\", \\\"{x:1369,y:766,t:1527009384132};\\\", \\\"{x:1370,y:766,t:1527009384148};\\\", \\\"{x:1369,y:764,t:1527009384237};\\\", \\\"{x:1369,y:763,t:1527009384249};\\\", \\\"{x:1364,y:762,t:1527009384266};\\\", \\\"{x:1354,y:762,t:1527009384283};\\\", \\\"{x:1341,y:764,t:1527009384300};\\\", \\\"{x:1323,y:770,t:1527009384315};\\\", \\\"{x:1306,y:774,t:1527009384332};\\\", \\\"{x:1294,y:776,t:1527009384350};\\\", \\\"{x:1285,y:779,t:1527009384365};\\\", \\\"{x:1279,y:780,t:1527009384382};\\\", \\\"{x:1273,y:781,t:1527009384400};\\\", \\\"{x:1266,y:785,t:1527009384415};\\\", \\\"{x:1261,y:788,t:1527009384432};\\\", \\\"{x:1257,y:790,t:1527009384449};\\\", \\\"{x:1252,y:792,t:1527009384466};\\\", \\\"{x:1251,y:793,t:1527009384484};\\\", \\\"{x:1250,y:793,t:1527009384499};\\\", \\\"{x:1249,y:793,t:1527009384524};\\\", \\\"{x:1249,y:794,t:1527009384532};\\\", \\\"{x:1248,y:794,t:1527009384564};\\\", \\\"{x:1247,y:795,t:1527009384579};\\\", \\\"{x:1247,y:796,t:1527009384620};\\\", \\\"{x:1247,y:797,t:1527009384748};\\\", \\\"{x:1247,y:798,t:1527009384772};\\\", \\\"{x:1247,y:799,t:1527009384788};\\\", \\\"{x:1247,y:800,t:1527009384811};\\\", \\\"{x:1247,y:801,t:1527009384828};\\\", \\\"{x:1247,y:802,t:1527009384836};\\\", \\\"{x:1247,y:803,t:1527009384849};\\\", \\\"{x:1247,y:805,t:1527009384865};\\\", \\\"{x:1247,y:806,t:1527009384883};\\\", \\\"{x:1249,y:808,t:1527009384899};\\\", \\\"{x:1252,y:810,t:1527009384915};\\\", \\\"{x:1254,y:811,t:1527009384932};\\\", \\\"{x:1259,y:811,t:1527009384949};\\\", \\\"{x:1263,y:812,t:1527009384966};\\\", \\\"{x:1272,y:812,t:1527009384982};\\\", \\\"{x:1282,y:808,t:1527009384999};\\\", \\\"{x:1294,y:802,t:1527009385016};\\\", \\\"{x:1308,y:795,t:1527009385032};\\\", \\\"{x:1325,y:786,t:1527009385049};\\\", \\\"{x:1344,y:778,t:1527009385066};\\\", \\\"{x:1357,y:772,t:1527009385084};\\\", \\\"{x:1360,y:770,t:1527009385098};\\\", \\\"{x:1362,y:770,t:1527009385115};\\\", \\\"{x:1362,y:769,t:1527009385133};\\\", \\\"{x:1363,y:769,t:1527009385162};\\\", \\\"{x:1364,y:771,t:1527009385179};\\\", \\\"{x:1365,y:777,t:1527009385187};\\\", \\\"{x:1366,y:784,t:1527009385199};\\\", \\\"{x:1372,y:804,t:1527009385216};\\\", \\\"{x:1374,y:823,t:1527009385233};\\\", \\\"{x:1376,y:837,t:1527009385249};\\\", \\\"{x:1377,y:850,t:1527009385266};\\\", \\\"{x:1380,y:866,t:1527009385283};\\\", \\\"{x:1385,y:887,t:1527009385299};\\\", \\\"{x:1387,y:909,t:1527009385316};\\\", \\\"{x:1392,y:932,t:1527009385333};\\\", \\\"{x:1393,y:954,t:1527009385349};\\\", \\\"{x:1396,y:967,t:1527009385366};\\\", \\\"{x:1396,y:972,t:1527009385384};\\\", \\\"{x:1396,y:974,t:1527009385399};\\\", \\\"{x:1394,y:974,t:1527009385621};\\\", \\\"{x:1393,y:974,t:1527009385644};\\\", \\\"{x:1392,y:974,t:1527009385668};\\\", \\\"{x:1391,y:974,t:1527009385684};\\\", \\\"{x:1390,y:974,t:1527009385717};\\\", \\\"{x:1388,y:974,t:1527009385764};\\\", \\\"{x:1387,y:974,t:1527009385804};\\\", \\\"{x:1387,y:975,t:1527009385828};\\\", \\\"{x:1385,y:975,t:1527009385860};\\\", \\\"{x:1383,y:977,t:1527009385875};\\\", \\\"{x:1382,y:978,t:1527009385884};\\\", \\\"{x:1380,y:979,t:1527009385900};\\\", \\\"{x:1377,y:982,t:1527009385916};\\\", \\\"{x:1374,y:984,t:1527009385933};\\\", \\\"{x:1370,y:987,t:1527009385950};\\\", \\\"{x:1366,y:989,t:1527009385966};\\\", \\\"{x:1364,y:989,t:1527009385983};\\\", \\\"{x:1363,y:989,t:1527009386000};\\\", \\\"{x:1361,y:990,t:1527009386016};\\\", \\\"{x:1360,y:990,t:1527009386212};\\\", \\\"{x:1360,y:989,t:1527009386227};\\\", \\\"{x:1359,y:989,t:1527009386244};\\\", \\\"{x:1358,y:988,t:1527009386284};\\\", \\\"{x:1357,y:986,t:1527009386556};\\\", \\\"{x:1357,y:985,t:1527009386567};\\\", \\\"{x:1356,y:983,t:1527009386585};\\\", \\\"{x:1354,y:980,t:1527009386600};\\\", \\\"{x:1354,y:978,t:1527009386617};\\\", \\\"{x:1352,y:975,t:1527009386635};\\\", \\\"{x:1352,y:974,t:1527009386651};\\\", \\\"{x:1351,y:972,t:1527009386668};\\\", \\\"{x:1351,y:971,t:1527009388396};\\\", \\\"{x:1351,y:968,t:1527009388461};\\\", \\\"{x:1353,y:964,t:1527009388469};\\\", \\\"{x:1356,y:960,t:1527009388485};\\\", \\\"{x:1360,y:954,t:1527009388502};\\\", \\\"{x:1364,y:950,t:1527009388518};\\\", \\\"{x:1368,y:946,t:1527009388535};\\\", \\\"{x:1372,y:943,t:1527009388552};\\\", \\\"{x:1375,y:940,t:1527009388568};\\\", \\\"{x:1377,y:938,t:1527009388585};\\\", \\\"{x:1378,y:936,t:1527009388602};\\\", \\\"{x:1381,y:934,t:1527009388618};\\\", \\\"{x:1385,y:928,t:1527009388635};\\\", \\\"{x:1386,y:926,t:1527009388652};\\\", \\\"{x:1387,y:924,t:1527009388668};\\\", \\\"{x:1388,y:924,t:1527009388685};\\\", \\\"{x:1388,y:922,t:1527009388703};\\\", \\\"{x:1389,y:921,t:1527009388718};\\\", \\\"{x:1389,y:919,t:1527009388735};\\\", \\\"{x:1390,y:917,t:1527009388752};\\\", \\\"{x:1391,y:915,t:1527009388772};\\\", \\\"{x:1391,y:914,t:1527009388787};\\\", \\\"{x:1391,y:912,t:1527009388803};\\\", \\\"{x:1391,y:911,t:1527009388819};\\\", \\\"{x:1392,y:909,t:1527009388836};\\\", \\\"{x:1392,y:908,t:1527009388852};\\\", \\\"{x:1392,y:907,t:1527009389220};\\\", \\\"{x:1392,y:906,t:1527009389548};\\\", \\\"{x:1391,y:905,t:1527009389556};\\\", \\\"{x:1388,y:905,t:1527009389569};\\\", \\\"{x:1383,y:901,t:1527009389588};\\\", \\\"{x:1375,y:899,t:1527009389602};\\\", \\\"{x:1363,y:893,t:1527009389619};\\\", \\\"{x:1358,y:891,t:1527009389636};\\\", \\\"{x:1350,y:888,t:1527009389652};\\\", \\\"{x:1346,y:886,t:1527009389669};\\\", \\\"{x:1344,y:885,t:1527009389686};\\\", \\\"{x:1343,y:884,t:1527009389723};\\\", \\\"{x:1342,y:883,t:1527009389748};\\\", \\\"{x:1341,y:882,t:1527009389764};\\\", \\\"{x:1341,y:881,t:1527009389772};\\\", \\\"{x:1341,y:880,t:1527009389796};\\\", \\\"{x:1341,y:879,t:1527009389819};\\\", \\\"{x:1341,y:878,t:1527009389836};\\\", \\\"{x:1341,y:877,t:1527009389916};\\\", \\\"{x:1341,y:876,t:1527009389956};\\\", \\\"{x:1343,y:876,t:1527009390996};\\\", \\\"{x:1346,y:876,t:1527009391003};\\\", \\\"{x:1352,y:879,t:1527009391021};\\\", \\\"{x:1354,y:880,t:1527009391038};\\\", \\\"{x:1357,y:881,t:1527009391054};\\\", \\\"{x:1359,y:882,t:1527009391071};\\\", \\\"{x:1360,y:882,t:1527009391092};\\\", \\\"{x:1361,y:883,t:1527009391108};\\\", \\\"{x:1362,y:883,t:1527009391132};\\\", \\\"{x:1363,y:883,t:1527009391148};\\\", \\\"{x:1364,y:883,t:1527009391156};\\\", \\\"{x:1365,y:884,t:1527009391170};\\\", \\\"{x:1369,y:886,t:1527009391187};\\\", \\\"{x:1370,y:886,t:1527009391203};\\\", \\\"{x:1372,y:886,t:1527009391308};\\\", \\\"{x:1373,y:887,t:1527009391644};\\\", \\\"{x:1374,y:887,t:1527009391655};\\\", \\\"{x:1376,y:890,t:1527009391671};\\\", \\\"{x:1377,y:892,t:1527009391689};\\\", \\\"{x:1379,y:894,t:1527009391704};\\\", \\\"{x:1380,y:895,t:1527009391720};\\\", \\\"{x:1381,y:896,t:1527009391736};\\\", \\\"{x:1382,y:897,t:1527009391884};\\\", \\\"{x:1383,y:897,t:1527009391940};\\\", \\\"{x:1384,y:898,t:1527009391963};\\\", \\\"{x:1377,y:894,t:1527009393892};\\\", \\\"{x:1371,y:892,t:1527009393907};\\\", \\\"{x:1351,y:882,t:1527009393923};\\\", \\\"{x:1313,y:867,t:1527009393940};\\\", \\\"{x:1284,y:858,t:1527009393956};\\\", \\\"{x:1252,y:847,t:1527009393973};\\\", \\\"{x:1220,y:840,t:1527009393990};\\\", \\\"{x:1164,y:823,t:1527009394006};\\\", \\\"{x:1121,y:810,t:1527009394023};\\\", \\\"{x:1088,y:801,t:1527009394040};\\\", \\\"{x:1066,y:793,t:1527009394055};\\\", \\\"{x:1041,y:786,t:1527009394073};\\\", \\\"{x:1016,y:779,t:1527009394090};\\\", \\\"{x:993,y:773,t:1527009394107};\\\", \\\"{x:971,y:767,t:1527009394123};\\\", \\\"{x:942,y:762,t:1527009394140};\\\", \\\"{x:920,y:758,t:1527009394155};\\\", \\\"{x:894,y:753,t:1527009394173};\\\", \\\"{x:860,y:741,t:1527009394190};\\\", \\\"{x:822,y:719,t:1527009394206};\\\", \\\"{x:785,y:689,t:1527009394223};\\\", \\\"{x:759,y:666,t:1527009394239};\\\", \\\"{x:724,y:634,t:1527009394258};\\\", \\\"{x:697,y:610,t:1527009394274};\\\", \\\"{x:650,y:583,t:1527009394290};\\\", \\\"{x:491,y:510,t:1527009394324};\\\", \\\"{x:442,y:491,t:1527009394340};\\\", \\\"{x:407,y:481,t:1527009394357};\\\", \\\"{x:387,y:475,t:1527009394373};\\\", \\\"{x:383,y:475,t:1527009394390};\\\", \\\"{x:380,y:475,t:1527009394407};\\\", \\\"{x:377,y:475,t:1527009394423};\\\", \\\"{x:369,y:478,t:1527009394440};\\\", \\\"{x:359,y:492,t:1527009394458};\\\", \\\"{x:347,y:507,t:1527009394473};\\\", \\\"{x:336,y:521,t:1527009394490};\\\", \\\"{x:332,y:537,t:1527009394507};\\\", \\\"{x:332,y:547,t:1527009394524};\\\", \\\"{x:334,y:556,t:1527009394540};\\\", \\\"{x:339,y:564,t:1527009394557};\\\", \\\"{x:343,y:569,t:1527009394573};\\\", \\\"{x:349,y:573,t:1527009394591};\\\", \\\"{x:358,y:580,t:1527009394608};\\\", \\\"{x:366,y:587,t:1527009394625};\\\", \\\"{x:374,y:593,t:1527009394640};\\\", \\\"{x:378,y:594,t:1527009394657};\\\", \\\"{x:384,y:595,t:1527009394674};\\\", \\\"{x:392,y:595,t:1527009394690};\\\", \\\"{x:403,y:586,t:1527009394707};\\\", \\\"{x:407,y:579,t:1527009394723};\\\", \\\"{x:410,y:575,t:1527009394741};\\\", \\\"{x:410,y:570,t:1527009394757};\\\", \\\"{x:410,y:564,t:1527009394773};\\\", \\\"{x:410,y:560,t:1527009394790};\\\", \\\"{x:410,y:559,t:1527009394811};\\\", \\\"{x:410,y:558,t:1527009394907};\\\", \\\"{x:409,y:557,t:1527009394931};\\\", \\\"{x:410,y:557,t:1527009395412};\\\", \\\"{x:415,y:558,t:1527009395425};\\\", \\\"{x:428,y:561,t:1527009395442};\\\", \\\"{x:457,y:565,t:1527009395458};\\\", \\\"{x:527,y:573,t:1527009395474};\\\", \\\"{x:660,y:600,t:1527009395491};\\\", \\\"{x:752,y:616,t:1527009395509};\\\", \\\"{x:839,y:629,t:1527009395524};\\\", \\\"{x:926,y:644,t:1527009395541};\\\", \\\"{x:1006,y:655,t:1527009395558};\\\", \\\"{x:1062,y:663,t:1527009395574};\\\", \\\"{x:1099,y:668,t:1527009395591};\\\", \\\"{x:1124,y:672,t:1527009395607};\\\", \\\"{x:1146,y:675,t:1527009395624};\\\", \\\"{x:1167,y:680,t:1527009395641};\\\", \\\"{x:1193,y:686,t:1527009395658};\\\", \\\"{x:1219,y:692,t:1527009395675};\\\", \\\"{x:1252,y:697,t:1527009395690};\\\", \\\"{x:1272,y:700,t:1527009395708};\\\", \\\"{x:1286,y:701,t:1527009395724};\\\", \\\"{x:1298,y:703,t:1527009395741};\\\", \\\"{x:1309,y:705,t:1527009395758};\\\", \\\"{x:1311,y:706,t:1527009395775};\\\", \\\"{x:1313,y:706,t:1527009395791};\\\", \\\"{x:1314,y:706,t:1527009395812};\\\", \\\"{x:1317,y:706,t:1527009396235};\\\", \\\"{x:1317,y:705,t:1527009396243};\\\", \\\"{x:1319,y:703,t:1527009396258};\\\", \\\"{x:1322,y:698,t:1527009396273};\\\", \\\"{x:1325,y:693,t:1527009396290};\\\", \\\"{x:1329,y:686,t:1527009396307};\\\", \\\"{x:1331,y:681,t:1527009396323};\\\", \\\"{x:1334,y:677,t:1527009396341};\\\", \\\"{x:1337,y:672,t:1527009396357};\\\", \\\"{x:1338,y:667,t:1527009396374};\\\", \\\"{x:1341,y:661,t:1527009396390};\\\", \\\"{x:1342,y:655,t:1527009396406};\\\", \\\"{x:1345,y:651,t:1527009396423};\\\", \\\"{x:1345,y:646,t:1527009396441};\\\", \\\"{x:1348,y:641,t:1527009396456};\\\", \\\"{x:1348,y:639,t:1527009396474};\\\", \\\"{x:1348,y:638,t:1527009396490};\\\", \\\"{x:1349,y:637,t:1527009396548};\\\", \\\"{x:1351,y:637,t:1527009398084};\\\", \\\"{x:1355,y:637,t:1527009398092};\\\", \\\"{x:1357,y:638,t:1527009398105};\\\", \\\"{x:1361,y:639,t:1527009398122};\\\", \\\"{x:1364,y:640,t:1527009398138};\\\", \\\"{x:1366,y:641,t:1527009398155};\\\", \\\"{x:1369,y:641,t:1527009398172};\\\", \\\"{x:1369,y:642,t:1527009398188};\\\", \\\"{x:1371,y:642,t:1527009398205};\\\", \\\"{x:1372,y:643,t:1527009398222};\\\", \\\"{x:1374,y:644,t:1527009398268};\\\", \\\"{x:1375,y:644,t:1527009398276};\\\", \\\"{x:1376,y:645,t:1527009398288};\\\", \\\"{x:1379,y:646,t:1527009398305};\\\", \\\"{x:1382,y:646,t:1527009398321};\\\", \\\"{x:1386,y:649,t:1527009398338};\\\", \\\"{x:1389,y:649,t:1527009398355};\\\", \\\"{x:1391,y:652,t:1527009398371};\\\", \\\"{x:1393,y:660,t:1527009398387};\\\", \\\"{x:1395,y:664,t:1527009398405};\\\", \\\"{x:1397,y:672,t:1527009398421};\\\", \\\"{x:1402,y:682,t:1527009398438};\\\", \\\"{x:1404,y:691,t:1527009398455};\\\", \\\"{x:1409,y:704,t:1527009398471};\\\", \\\"{x:1413,y:716,t:1527009398488};\\\", \\\"{x:1419,y:731,t:1527009398504};\\\", \\\"{x:1424,y:741,t:1527009398520};\\\", \\\"{x:1426,y:749,t:1527009398538};\\\", \\\"{x:1427,y:752,t:1527009398554};\\\", \\\"{x:1427,y:754,t:1527009398571};\\\", \\\"{x:1412,y:754,t:1527009401068};\\\", \\\"{x:1318,y:754,t:1527009401085};\\\", \\\"{x:1233,y:749,t:1527009401101};\\\", \\\"{x:1127,y:747,t:1527009401118};\\\", \\\"{x:1011,y:735,t:1527009401134};\\\", \\\"{x:902,y:725,t:1527009401151};\\\", \\\"{x:807,y:713,t:1527009401168};\\\", \\\"{x:734,y:699,t:1527009401184};\\\", \\\"{x:686,y:691,t:1527009401200};\\\", \\\"{x:650,y:689,t:1527009401218};\\\", \\\"{x:628,y:684,t:1527009401233};\\\", \\\"{x:609,y:681,t:1527009401251};\\\", \\\"{x:573,y:675,t:1527009401267};\\\", \\\"{x:548,y:670,t:1527009401283};\\\", \\\"{x:524,y:666,t:1527009401301};\\\", \\\"{x:508,y:663,t:1527009401317};\\\", \\\"{x:497,y:659,t:1527009401335};\\\", \\\"{x:494,y:658,t:1527009401350};\\\", \\\"{x:493,y:657,t:1527009401370};\\\", \\\"{x:492,y:657,t:1527009401410};\\\", \\\"{x:492,y:654,t:1527009401419};\\\", \\\"{x:490,y:651,t:1527009401430};\\\", \\\"{x:484,y:643,t:1527009401446};\\\", \\\"{x:473,y:635,t:1527009401463};\\\", \\\"{x:456,y:625,t:1527009401479};\\\", \\\"{x:440,y:615,t:1527009401495};\\\", \\\"{x:426,y:606,t:1527009401513};\\\", \\\"{x:421,y:603,t:1527009401529};\\\", \\\"{x:417,y:599,t:1527009401545};\\\", \\\"{x:414,y:597,t:1527009401562};\\\", \\\"{x:413,y:597,t:1527009401578};\\\", \\\"{x:410,y:595,t:1527009401595};\\\", \\\"{x:409,y:594,t:1527009401612};\\\", \\\"{x:407,y:593,t:1527009401629};\\\", \\\"{x:406,y:592,t:1527009401646};\\\", \\\"{x:408,y:592,t:1527009401811};\\\", \\\"{x:411,y:592,t:1527009401819};\\\", \\\"{x:417,y:593,t:1527009401830};\\\", \\\"{x:425,y:595,t:1527009401848};\\\", \\\"{x:440,y:597,t:1527009401863};\\\", \\\"{x:457,y:597,t:1527009401879};\\\", \\\"{x:479,y:597,t:1527009401895};\\\", \\\"{x:502,y:597,t:1527009401914};\\\", \\\"{x:526,y:597,t:1527009401928};\\\", \\\"{x:562,y:596,t:1527009401945};\\\", \\\"{x:614,y:593,t:1527009401963};\\\", \\\"{x:642,y:593,t:1527009401979};\\\", \\\"{x:677,y:593,t:1527009401996};\\\", \\\"{x:702,y:593,t:1527009402013};\\\", \\\"{x:720,y:593,t:1527009402029};\\\", \\\"{x:728,y:593,t:1527009402048};\\\", \\\"{x:730,y:593,t:1527009402063};\\\", \\\"{x:729,y:592,t:1527009402115};\\\", \\\"{x:722,y:590,t:1527009402131};\\\", \\\"{x:692,y:584,t:1527009402147};\\\", \\\"{x:672,y:581,t:1527009402163};\\\", \\\"{x:655,y:578,t:1527009402179};\\\", \\\"{x:645,y:578,t:1527009402197};\\\", \\\"{x:633,y:578,t:1527009402213};\\\", \\\"{x:619,y:578,t:1527009402230};\\\", \\\"{x:601,y:578,t:1527009402247};\\\", \\\"{x:586,y:578,t:1527009402264};\\\", \\\"{x:577,y:578,t:1527009402280};\\\", \\\"{x:569,y:579,t:1527009402297};\\\", \\\"{x:558,y:583,t:1527009402314};\\\", \\\"{x:549,y:585,t:1527009402330};\\\", \\\"{x:531,y:590,t:1527009402347};\\\", \\\"{x:515,y:591,t:1527009402363};\\\", \\\"{x:498,y:594,t:1527009402381};\\\", \\\"{x:484,y:596,t:1527009402396};\\\", \\\"{x:470,y:598,t:1527009402413};\\\", \\\"{x:455,y:600,t:1527009402430};\\\", \\\"{x:441,y:603,t:1527009402447};\\\", \\\"{x:427,y:603,t:1527009402463};\\\", \\\"{x:409,y:603,t:1527009402479};\\\", \\\"{x:390,y:603,t:1527009402496};\\\", \\\"{x:367,y:603,t:1527009402514};\\\", \\\"{x:344,y:602,t:1527009402529};\\\", \\\"{x:312,y:595,t:1527009402546};\\\", \\\"{x:289,y:590,t:1527009402564};\\\", \\\"{x:266,y:582,t:1527009402581};\\\", \\\"{x:250,y:575,t:1527009402597};\\\", \\\"{x:226,y:565,t:1527009402614};\\\", \\\"{x:205,y:558,t:1527009402630};\\\", \\\"{x:187,y:551,t:1527009402647};\\\", \\\"{x:173,y:546,t:1527009402663};\\\", \\\"{x:165,y:544,t:1527009402680};\\\", \\\"{x:163,y:543,t:1527009402696};\\\", \\\"{x:161,y:543,t:1527009402713};\\\", \\\"{x:160,y:542,t:1527009402730};\\\", \\\"{x:158,y:541,t:1527009402747};\\\", \\\"{x:157,y:541,t:1527009402763};\\\", \\\"{x:159,y:541,t:1527009403140};\\\", \\\"{x:163,y:543,t:1527009403148};\\\", \\\"{x:168,y:546,t:1527009403164};\\\", \\\"{x:181,y:555,t:1527009403181};\\\", \\\"{x:197,y:569,t:1527009403198};\\\", \\\"{x:223,y:589,t:1527009403214};\\\", \\\"{x:251,y:607,t:1527009403230};\\\", \\\"{x:274,y:620,t:1527009403248};\\\", \\\"{x:299,y:630,t:1527009403264};\\\", \\\"{x:342,y:645,t:1527009403280};\\\", \\\"{x:374,y:656,t:1527009403298};\\\", \\\"{x:394,y:663,t:1527009403314};\\\", \\\"{x:403,y:665,t:1527009403331};\\\", \\\"{x:401,y:663,t:1527009403387};\\\", \\\"{x:390,y:655,t:1527009403398};\\\", \\\"{x:367,y:639,t:1527009403415};\\\", \\\"{x:320,y:618,t:1527009403430};\\\", \\\"{x:271,y:599,t:1527009403448};\\\", \\\"{x:241,y:587,t:1527009403464};\\\", \\\"{x:224,y:581,t:1527009403480};\\\", \\\"{x:214,y:577,t:1527009403498};\\\", \\\"{x:201,y:574,t:1527009403515};\\\", \\\"{x:195,y:570,t:1527009403531};\\\", \\\"{x:186,y:568,t:1527009403548};\\\", \\\"{x:179,y:565,t:1527009403565};\\\", \\\"{x:174,y:564,t:1527009403581};\\\", \\\"{x:172,y:562,t:1527009403599};\\\", \\\"{x:170,y:562,t:1527009403668};\\\", \\\"{x:169,y:562,t:1527009403681};\\\", \\\"{x:162,y:562,t:1527009403698};\\\", \\\"{x:158,y:562,t:1527009403715};\\\", \\\"{x:157,y:562,t:1527009403731};\\\", \\\"{x:156,y:562,t:1527009403795};\\\", \\\"{x:159,y:562,t:1527009404067};\\\", \\\"{x:163,y:563,t:1527009404083};\\\", \\\"{x:171,y:564,t:1527009404098};\\\", \\\"{x:182,y:570,t:1527009404115};\\\", \\\"{x:185,y:573,t:1527009404131};\\\", \\\"{x:190,y:579,t:1527009404148};\\\", \\\"{x:211,y:597,t:1527009404165};\\\", \\\"{x:257,y:624,t:1527009404183};\\\", \\\"{x:303,y:660,t:1527009404198};\\\", \\\"{x:357,y:698,t:1527009404215};\\\", \\\"{x:400,y:721,t:1527009404232};\\\", \\\"{x:437,y:747,t:1527009404248};\\\", \\\"{x:478,y:771,t:1527009404265};\\\", \\\"{x:503,y:786,t:1527009404282};\\\", \\\"{x:514,y:792,t:1527009404298};\\\", \\\"{x:515,y:793,t:1527009404315};\\\", \\\"{x:516,y:793,t:1527009404339};\\\", \\\"{x:517,y:793,t:1527009404348};\\\", \\\"{x:520,y:793,t:1527009404365};\\\", \\\"{x:529,y:795,t:1527009404382};\\\", \\\"{x:543,y:797,t:1527009404399};\\\", \\\"{x:546,y:798,t:1527009404414};\\\", \\\"{x:548,y:797,t:1527009404451};\\\", \\\"{x:548,y:794,t:1527009404466};\\\", \\\"{x:548,y:781,t:1527009404482};\\\", \\\"{x:548,y:774,t:1527009404499};\\\", \\\"{x:548,y:770,t:1527009404515};\\\", \\\"{x:548,y:767,t:1527009404533};\\\", \\\"{x:548,y:765,t:1527009404563};\\\", \\\"{x:547,y:765,t:1527009404612};\\\" ] }, { \\\"rt\\\": 44715, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 20, \\\"time_elapsed\\\": 615605, \\\"internal_node_id\\\": \\\"0.0-7.0-0.0\\\", \\\"subject\\\": \\\"R06S6\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"echo\\\", \\\"condition\\\": \\\"121\\\", \\\"q\\\": 16, \\\"answer\\\": \\\"look at the x axis until you hit 12pm and then look up at the dots that lie on it\\\", \\\"block\\\": \\\"triangular_testing\\\" }, { \\\"rt\\\": 6774, \\\"responses\\\": \\\"{\\\\\\\"Q0\\\\\\\":\\\\\\\"21\\\\\\\",\\\\\\\"Q1\\\\\\\":\\\\\\\"USA\\\\\\\\n\\\\\\\"}\\\", \\\"block\\\": \\\"demo-1\\\", \\\"trial_type\\\": \\\"survey-text\\\", \\\"trial_index\\\": 21, \\\"time_elapsed\\\": 623387, \\\"internal_node_id\\\": \\\"0.0-8.0\\\", \\\"subject\\\": \\\"R06S6\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"echo\\\", \\\"condition\\\": \\\"121\\\" }, { \\\"rt\\\": 13126, \\\"responses\\\": \\\"{\\\\\\\"Q0\\\\\\\":\\\\\\\"English\\\\\\\",\\\\\\\"Q1\\\\\\\":\\\\\\\"Third\\\\\\\",\\\\\\\"Q2\\\\\\\":\\\\\\\"Social Sciences (incl. CogSci)\\\\\\\",\\\\\\\"Q3\\\\\\\":\\\\\\\"Female\\\\\\\"}\\\", \\\"block\\\": \\\"demo-2\\\", \\\"trial_type\\\": \\\"survey-multi-choice\\\", \\\"trial_index\\\": 22, \\\"time_elapsed\\\": 637535, \\\"internal_node_id\\\": \\\"0.0-9.0\\\", \\\"subject\\\": \\\"R06S6\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"echo\\\", \\\"condition\\\": \\\"121\\\" }, { \\\"rt\\\": 4246, \\\"url\\\": \\\"../views/src/external/debrief.html\\\", \\\"block\\\": \\\"debrief\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 23, \\\"time_elapsed\\\": 643186, \\\"internal_node_id\\\": \\\"0.0-10.0\\\", \\\"subject\\\": \\\"R06S6\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"echo\\\", \\\"condition\\\": \\\"121\\\" } ]\",\"parentNode\":{\"id\":2765}}],[],[]]}"
    }
  ],
  "initialDom": "{\"f\":\"initialize\",\"args\":[1,[{\"nodeType\":10,\"id\":2,\"name\":\"html\",\"publicId\":\"\",\"systemId\":\"\"},{\"nodeType\":1,\"id\":3,\"tagName\":\"HTML\",\"attributes\":{\"class\":\"fa-events-icons-ready\"},\"childNodes\":[{\"nodeType\":1,\"id\":4,\"tagName\":\"HEAD\",\"attributes\":{},\"childNodes\":[{\"nodeType\":3,\"id\":5,\"textContent\":\" \"},{\"nodeType\":1,\"id\":6,\"tagName\":\"TITLE\",\"attributes\":{},\"childNodes\":[{\"nodeType\":3,\"id\":7,\"textContent\":\"FOX2YP\"}]},{\"nodeType\":3,\"id\":8,\"textContent\":\" \"},{\"nodeType\":8,\"id\":9},{\"nodeType\":3,\"id\":10,\"textContent\":\" \"},{\"nodeType\":1,\"id\":11,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":12,\"textContent\":\" \"},{\"nodeType\":1,\"id\":13,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":14,\"textContent\":\" \"},{\"nodeType\":1,\"id\":15,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":16,\"textContent\":\" \"},{\"nodeType\":1,\"id\":17,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":18,\"textContent\":\" \"},{\"nodeType\":1,\"id\":19,\"tagName\":\"SCRIPT\"},{\"nodeType\":1,\"id\":20,\"tagName\":\"LINK\",\"attributes\":{\"href\":\"https://use.fontawesome.com/945539d961.css\",\"media\":\"all\",\"rel\":\"stylesheet\"}},{\"nodeType\":3,\"id\":21,\"textContent\":\" \"},{\"nodeType\":8,\"id\":22},{\"nodeType\":3,\"id\":23,\"textContent\":\" \"},{\"nodeType\":1,\"id\":24,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":25,\"textContent\":\" \"},{\"nodeType\":1,\"id\":26,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":27,\"textContent\":\" \"},{\"nodeType\":1,\"id\":28,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":29,\"textContent\":\" \"},{\"nodeType\":1,\"id\":30,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":31,\"textContent\":\" \"},{\"nodeType\":1,\"id\":32,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":33,\"textContent\":\" \"},{\"nodeType\":1,\"id\":34,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":35,\"textContent\":\" \"},{\"nodeType\":1,\"id\":36,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":37,\"textContent\":\" \"},{\"nodeType\":8,\"id\":38},{\"nodeType\":3,\"id\":39,\"textContent\":\" \"},{\"nodeType\":1,\"id\":40,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":41,\"textContent\":\" \"},{\"nodeType\":8,\"id\":42},{\"nodeType\":3,\"id\":43,\"textContent\":\" \"},{\"nodeType\":8,\"id\":44},{\"nodeType\":3,\"id\":45,\"textContent\":\" \"},{\"nodeType\":1,\"id\":46,\"tagName\":\"LINK\",\"attributes\":{\"href\":\"../views/jsPsych/css/jspsych.css\",\"rel\":\"stylesheet\",\"type\":\"text/css\"}},{\"nodeType\":3,\"id\":47,\"textContent\":\" \"},{\"nodeType\":1,\"id\":48,\"tagName\":\"LINK\",\"attributes\":{\"href\":\"../css/styles.css\",\"rel\":\"stylesheet\",\"type\":\"text/css\"}},{\"nodeType\":3,\"id\":49,\"textContent\":\" \"},{\"nodeType\":1,\"id\":50,\"tagName\":\"SCRIPT\"},{\"nodeType\":1,\"id\":51,\"tagName\":\"SCRIPT\"}]},{\"nodeType\":3,\"id\":52,\"textContent\":\" \"},{\"nodeType\":8,\"id\":53},{\"nodeType\":3,\"id\":54,\"textContent\":\" \"},{\"nodeType\":1,\"id\":55,\"tagName\":\"BODY\",\"attributes\":{\"class\":\"jspsych-display-element\"},\"childNodes\":[{\"nodeType\":3,\"id\":56,\"textContent\":\" \"},{\"nodeType\":1,\"id\":57,\"tagName\":\"META\",\"attributes\":{\"charset\":\"utf-8\"}},{\"nodeType\":3,\"id\":58,\"textContent\":\" \"},{\"nodeType\":8,\"id\":59},{\"nodeType\":3,\"id\":60,\"textContent\":\" \"},{\"nodeType\":1,\"id\":61,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":62,\"textContent\":\" \"},{\"nodeType\":1,\"id\":63,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":64,\"textContent\":\" \"},{\"nodeType\":1,\"id\":65,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":66,\"textContent\":\" \"},{\"nodeType\":1,\"id\":67,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":68,\"textContent\":\" \"},{\"nodeType\":1,\"id\":69,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":70,\"textContent\":\" \"},{\"nodeType\":1,\"id\":71,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":72,\"textContent\":\" \"},{\"nodeType\":1,\"id\":73,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"stimulus\"},\"childNodes\":[{\"nodeType\":3,\"id\":74,\"textContent\":\" \"},{\"nodeType\":1,\"id\":75,\"tagName\":\"P\",\"attributes\":{\"class\":\"userid\",\"id\":\"userid\"},\"childNodes\":[{\"nodeType\":3,\"id\":76,\"textContent\":\"R06S6\"}]},{\"nodeType\":3,\"id\":77,\"textContent\":\" \"},{\"nodeType\":1,\"id\":78,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"userinput\"},\"childNodes\":[{\"nodeType\":3,\"id\":79,\"textContent\":\" \"},{\"nodeType\":8,\"id\":80},{\"nodeType\":3,\"id\":81,\"textContent\":\" \"},{\"nodeType\":1,\"id\":82,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"legend\",\"id\":\"hint-interactive\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":83,\"textContent\":\" \"},{\"nodeType\":1,\"id\":84,\"tagName\":\"P\",\"attributes\":{},\"childNodes\":[{\"nodeType\":3,\"id\":85,\"textContent\":\"Hint: Hover your mouse over the data points in the graph\"}]},{\"nodeType\":3,\"id\":86,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":87,\"textContent\":\" \"},{\"nodeType\":8,\"id\":88},{\"nodeType\":3,\"id\":89,\"textContent\":\" \"},{\"nodeType\":8,\"id\":90},{\"nodeType\":3,\"id\":91,\"textContent\":\" \"},{\"nodeType\":1,\"id\":92,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"test\"},\"childNodes\":[{\"nodeType\":3,\"id\":93,\"textContent\":\" \"},{\"nodeType\":1,\"id\":94,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"acme\",\"id\":\"acme.starttime\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":95,\"textContent\":\" \"},{\"nodeType\":1,\"id\":96,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":97,\"textContent\":\"Which shift(s) start at 11 am? \"}]},{\"nodeType\":3,\"id\":98,\"textContent\":\" \"},{\"nodeType\":1,\"id\":99,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":100,\"textContent\":\" \"},{\"nodeType\":1,\"id\":101,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":102,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":103,\"textContent\":\" \"},{\"nodeType\":1,\"id\":104,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":105,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":106,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":107,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":108,\"textContent\":\" \"},{\"nodeType\":1,\"id\":109,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":110,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":111,\"textContent\":\" \"},{\"nodeType\":1,\"id\":112,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":113,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":114,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":115,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":116,\"textContent\":\" \"},{\"nodeType\":1,\"id\":117,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":118,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":119,\"textContent\":\" \"},{\"nodeType\":1,\"id\":120,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":121,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":122,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":123,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":124,\"textContent\":\" \"},{\"nodeType\":1,\"id\":125,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":126,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":127,\"textContent\":\" \"},{\"nodeType\":1,\"id\":128,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":129,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":130,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":131,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":132,\"textContent\":\" \"},{\"nodeType\":1,\"id\":133,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":134,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":135,\"textContent\":\" \"},{\"nodeType\":1,\"id\":136,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":137,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":138,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":139,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":140,\"textContent\":\" \"},{\"nodeType\":1,\"id\":141,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":142,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":143,\"textContent\":\" \"},{\"nodeType\":1,\"id\":144,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":145,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":146,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":147,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":148,\"textContent\":\" \"},{\"nodeType\":1,\"id\":149,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":150,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":151,\"textContent\":\" \"},{\"nodeType\":1,\"id\":152,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":153,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":154,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":155,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":156,\"textContent\":\" \"},{\"nodeType\":1,\"id\":157,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":158,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":159,\"textContent\":\" \"},{\"nodeType\":1,\"id\":160,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":161,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":162,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":163,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":164,\"textContent\":\" \"},{\"nodeType\":1,\"id\":165,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":166,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":167,\"textContent\":\" \"},{\"nodeType\":1,\"id\":168,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":169,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":170,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":171,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":172,\"textContent\":\" \"},{\"nodeType\":1,\"id\":173,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":174,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":175,\"textContent\":\" \"},{\"nodeType\":1,\"id\":176,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":177,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":178,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":179,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":180,\"textContent\":\" \"},{\"nodeType\":1,\"id\":181,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":182,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":183,\"textContent\":\" \"},{\"nodeType\":1,\"id\":184,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"U\",\"value\":\"\"}},{\"nodeType\":3,\"id\":185,\"textContent\":\"U \"},{\"nodeType\":1,\"id\":186,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":187,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":188,\"textContent\":\" \"},{\"nodeType\":1,\"id\":189,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":190,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":191,\"textContent\":\" \"},{\"nodeType\":1,\"id\":192,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":193,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":194,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":195,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":196,\"textContent\":\" \"},{\"nodeType\":1,\"id\":197,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":198,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":199,\"textContent\":\" \"},{\"nodeType\":1,\"id\":200,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":201,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":202,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":203,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":204,\"textContent\":\" \"},{\"nodeType\":1,\"id\":205,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":206,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":207,\"textContent\":\" \"},{\"nodeType\":1,\"id\":208,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":209,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":210,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":211,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":212,\"textContent\":\" \"},{\"nodeType\":1,\"id\":213,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":214,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":215,\"textContent\":\" \"},{\"nodeType\":1,\"id\":216,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":217,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":218,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":219,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":220,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":221,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":222,\"textContent\":\" \"},{\"nodeType\":1,\"id\":223,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"acme\",\"id\":\"acme.starts\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":224,\"textContent\":\" \"},{\"nodeType\":1,\"id\":225,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":226,\"textContent\":\"Which shift(s) start at the same time as D?\"}]},{\"nodeType\":3,\"id\":227,\"textContent\":\" \"},{\"nodeType\":1,\"id\":228,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":229,\"textContent\":\" \"},{\"nodeType\":1,\"id\":230,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":231,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":232,\"textContent\":\" \"},{\"nodeType\":1,\"id\":233,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":234,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":235,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":236,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":237,\"textContent\":\" \"},{\"nodeType\":1,\"id\":238,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":239,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":240,\"textContent\":\" \"},{\"nodeType\":1,\"id\":241,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":242,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":243,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":244,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":245,\"textContent\":\" \"},{\"nodeType\":1,\"id\":246,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":247,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":248,\"textContent\":\" \"},{\"nodeType\":1,\"id\":249,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":250,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":251,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":252,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":253,\"textContent\":\" \"},{\"nodeType\":1,\"id\":254,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":255,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":256,\"textContent\":\" \"},{\"nodeType\":1,\"id\":257,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":258,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":259,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":260,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":261,\"textContent\":\" \"},{\"nodeType\":1,\"id\":262,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":263,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":264,\"textContent\":\" \"},{\"nodeType\":1,\"id\":265,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":266,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":267,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":268,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":269,\"textContent\":\" \"},{\"nodeType\":1,\"id\":270,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":271,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":272,\"textContent\":\" \"},{\"nodeType\":1,\"id\":273,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":274,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":275,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":276,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":277,\"textContent\":\" \"},{\"nodeType\":1,\"id\":278,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":279,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":280,\"textContent\":\" \"},{\"nodeType\":1,\"id\":281,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":282,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":283,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":284,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":285,\"textContent\":\" \"},{\"nodeType\":1,\"id\":286,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":287,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":288,\"textContent\":\" \"},{\"nodeType\":1,\"id\":289,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":290,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":291,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":292,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":293,\"textContent\":\" \"},{\"nodeType\":1,\"id\":294,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":295,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":296,\"textContent\":\" \"},{\"nodeType\":1,\"id\":297,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":298,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":299,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":300,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":301,\"textContent\":\" \"},{\"nodeType\":1,\"id\":302,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":303,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":304,\"textContent\":\" \"},{\"nodeType\":1,\"id\":305,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":306,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":307,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":308,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":309,\"textContent\":\" \"},{\"nodeType\":1,\"id\":310,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":311,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":312,\"textContent\":\" \"},{\"nodeType\":1,\"id\":313,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"U\",\"value\":\"\"}},{\"nodeType\":3,\"id\":314,\"textContent\":\"U \"},{\"nodeType\":1,\"id\":315,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":316,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":317,\"textContent\":\" \"},{\"nodeType\":1,\"id\":318,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":319,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":320,\"textContent\":\" \"},{\"nodeType\":1,\"id\":321,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":322,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":323,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":324,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":325,\"textContent\":\" \"},{\"nodeType\":1,\"id\":326,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":327,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":328,\"textContent\":\" \"},{\"nodeType\":1,\"id\":329,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":330,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":331,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":332,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":333,\"textContent\":\" \"},{\"nodeType\":1,\"id\":334,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":335,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":336,\"textContent\":\" \"},{\"nodeType\":1,\"id\":337,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":338,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":339,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":340,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":341,\"textContent\":\" \"},{\"nodeType\":1,\"id\":342,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":343,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":344,\"textContent\":\" \"},{\"nodeType\":1,\"id\":345,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":346,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":347,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":348,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":349,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":350,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":351,\"textContent\":\" \"},{\"nodeType\":1,\"id\":352,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"acme\",\"id\":\"acme.meets\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":353,\"textContent\":\" \"},{\"nodeType\":1,\"id\":354,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":355,\"textContent\":\"Which shift(s) begin when C ends?\"}]},{\"nodeType\":3,\"id\":356,\"textContent\":\" \"},{\"nodeType\":1,\"id\":357,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":358,\"textContent\":\" \"},{\"nodeType\":1,\"id\":359,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":360,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":361,\"textContent\":\" \"},{\"nodeType\":1,\"id\":362,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":363,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":364,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":365,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":366,\"textContent\":\" \"},{\"nodeType\":1,\"id\":367,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":368,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":369,\"textContent\":\" \"},{\"nodeType\":1,\"id\":370,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":371,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":372,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":373,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":374,\"textContent\":\" \"},{\"nodeType\":1,\"id\":375,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":376,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":377,\"textContent\":\" \"},{\"nodeType\":1,\"id\":378,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":379,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":380,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":381,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":382,\"textContent\":\" \"},{\"nodeType\":1,\"id\":383,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":384,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":385,\"textContent\":\" \"},{\"nodeType\":1,\"id\":386,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":387,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":388,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":389,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":390,\"textContent\":\" \"},{\"nodeType\":1,\"id\":391,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":392,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":393,\"textContent\":\" \"},{\"nodeType\":1,\"id\":394,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":395,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":396,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":397,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":398,\"textContent\":\" \"},{\"nodeType\":1,\"id\":399,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":400,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":401,\"textContent\":\" \"},{\"nodeType\":1,\"id\":402,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":403,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":404,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":405,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":406,\"textContent\":\" \"},{\"nodeType\":1,\"id\":407,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":408,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":409,\"textContent\":\" \"},{\"nodeType\":1,\"id\":410,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":411,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":412,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":413,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":414,\"textContent\":\" \"},{\"nodeType\":1,\"id\":415,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":416,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":417,\"textContent\":\" \"},{\"nodeType\":1,\"id\":418,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":419,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":420,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":421,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":422,\"textContent\":\" \"},{\"nodeType\":1,\"id\":423,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":424,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":425,\"textContent\":\" \"},{\"nodeType\":1,\"id\":426,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":427,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":428,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":429,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":430,\"textContent\":\" \"},{\"nodeType\":1,\"id\":431,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":432,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":433,\"textContent\":\" \"},{\"nodeType\":1,\"id\":434,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":435,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":436,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":437,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":438,\"textContent\":\" \"},{\"nodeType\":1,\"id\":439,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":440,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":441,\"textContent\":\" \"},{\"nodeType\":1,\"id\":442,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"U\",\"value\":\"\"}},{\"nodeType\":3,\"id\":443,\"textContent\":\"U \"},{\"nodeType\":1,\"id\":444,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":445,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":446,\"textContent\":\" \"},{\"nodeType\":1,\"id\":447,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":448,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":449,\"textContent\":\" \"},{\"nodeType\":1,\"id\":450,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":451,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":452,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":453,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":454,\"textContent\":\" \"},{\"nodeType\":1,\"id\":455,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":456,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":457,\"textContent\":\" \"},{\"nodeType\":1,\"id\":458,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":459,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":460,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":461,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":462,\"textContent\":\" \"},{\"nodeType\":1,\"id\":463,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":464,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":465,\"textContent\":\" \"},{\"nodeType\":1,\"id\":466,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":467,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":468,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":469,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":470,\"textContent\":\" \"},{\"nodeType\":1,\"id\":471,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":472,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":473,\"textContent\":\" \"},{\"nodeType\":1,\"id\":474,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":475,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":476,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":477,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":478,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":479,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":480,\"textContent\":\" \"},{\"nodeType\":1,\"id\":481,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"acme\",\"id\":\"acme.endtime\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":482,\"textContent\":\" \"},{\"nodeType\":1,\"id\":483,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":484,\"textContent\":\" Which shift(s) end at 4 pm?\"}]},{\"nodeType\":3,\"id\":485,\"textContent\":\" \"},{\"nodeType\":1,\"id\":486,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":487,\"textContent\":\" \"},{\"nodeType\":1,\"id\":488,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":489,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":490,\"textContent\":\" \"},{\"nodeType\":1,\"id\":491,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":492,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":493,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":494,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":495,\"textContent\":\" \"},{\"nodeType\":1,\"id\":496,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":497,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":498,\"textContent\":\" \"},{\"nodeType\":1,\"id\":499,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":500,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":501,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":502,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":503,\"textContent\":\" \"},{\"nodeType\":1,\"id\":504,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":505,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":506,\"textContent\":\" \"},{\"nodeType\":1,\"id\":507,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":508,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":509,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":510,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":511,\"textContent\":\" \"},{\"nodeType\":1,\"id\":512,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":513,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":514,\"textContent\":\" \"},{\"nodeType\":1,\"id\":515,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":516,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":517,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":518,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":519,\"textContent\":\" \"},{\"nodeType\":1,\"id\":520,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":521,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":522,\"textContent\":\" \"},{\"nodeType\":1,\"id\":523,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":524,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":525,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":526,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":527,\"textContent\":\" \"},{\"nodeType\":1,\"id\":528,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":529,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":530,\"textContent\":\" \"},{\"nodeType\":1,\"id\":531,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":532,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":533,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":534,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":535,\"textContent\":\" \"},{\"nodeType\":1,\"id\":536,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":537,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":538,\"textContent\":\" \"},{\"nodeType\":1,\"id\":539,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":540,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":541,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":542,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":543,\"textContent\":\" \"},{\"nodeType\":1,\"id\":544,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":545,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":546,\"textContent\":\" \"},{\"nodeType\":1,\"id\":547,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":548,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":549,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":550,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":551,\"textContent\":\" \"},{\"nodeType\":1,\"id\":552,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":553,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":554,\"textContent\":\" \"},{\"nodeType\":1,\"id\":555,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":556,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":557,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":558,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":559,\"textContent\":\" \"},{\"nodeType\":1,\"id\":560,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":561,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":562,\"textContent\":\" \"},{\"nodeType\":1,\"id\":563,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":564,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":565,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":566,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":567,\"textContent\":\" \"},{\"nodeType\":1,\"id\":568,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":569,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":570,\"textContent\":\" \"},{\"nodeType\":1,\"id\":571,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"U\",\"value\":\"\"}},{\"nodeType\":3,\"id\":572,\"textContent\":\"U \"},{\"nodeType\":1,\"id\":573,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":574,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":575,\"textContent\":\" \"},{\"nodeType\":1,\"id\":576,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":577,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":578,\"textContent\":\" \"},{\"nodeType\":1,\"id\":579,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":580,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":581,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":582,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":583,\"textContent\":\" \"},{\"nodeType\":1,\"id\":584,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":585,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":586,\"textContent\":\" \"},{\"nodeType\":1,\"id\":587,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":588,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":589,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":590,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":591,\"textContent\":\" \"},{\"nodeType\":1,\"id\":592,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":593,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":594,\"textContent\":\" \"},{\"nodeType\":1,\"id\":595,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":596,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":597,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":598,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":599,\"textContent\":\" \"},{\"nodeType\":1,\"id\":600,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":601,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":602,\"textContent\":\" \"},{\"nodeType\":1,\"id\":603,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":604,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":605,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":606,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":607,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":608,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":609,\"textContent\":\" \"},{\"nodeType\":1,\"id\":610,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"acme\",\"id\":\"acme.midpoint\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":611,\"textContent\":\" \"},{\"nodeType\":1,\"id\":612,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":613,\"textContent\":\"Coffee breaks happen halfway through a shift.\"},{\"nodeType\":1,\"id\":614,\"tagName\":\"BR\",\"attributes\":{}},{\"nodeType\":3,\"id\":615,\"textContent\":\" Which shift(s) share a break with I?\"}]},{\"nodeType\":3,\"id\":616,\"textContent\":\" \"},{\"nodeType\":1,\"id\":617,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":618,\"textContent\":\" \"},{\"nodeType\":1,\"id\":619,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":620,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":621,\"textContent\":\" \"},{\"nodeType\":1,\"id\":622,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":623,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":624,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":625,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":626,\"textContent\":\" \"},{\"nodeType\":1,\"id\":627,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":628,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":629,\"textContent\":\" \"},{\"nodeType\":1,\"id\":630,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":631,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":632,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":633,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":634,\"textContent\":\" \"},{\"nodeType\":1,\"id\":635,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":636,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":637,\"textContent\":\" \"},{\"nodeType\":1,\"id\":638,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":639,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":640,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":641,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":642,\"textContent\":\" \"},{\"nodeType\":1,\"id\":643,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":644,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":645,\"textContent\":\" \"},{\"nodeType\":1,\"id\":646,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":647,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":648,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":649,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":650,\"textContent\":\" \"},{\"nodeType\":1,\"id\":651,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":652,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":653,\"textContent\":\" \"},{\"nodeType\":1,\"id\":654,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":655,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":656,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":657,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":658,\"textContent\":\" \"},{\"nodeType\":1,\"id\":659,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":660,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":661,\"textContent\":\" \"},{\"nodeType\":1,\"id\":662,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":663,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":664,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":665,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":666,\"textContent\":\" \"},{\"nodeType\":1,\"id\":667,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":668,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":669,\"textContent\":\" \"},{\"nodeType\":1,\"id\":670,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":671,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":672,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":673,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":674,\"textContent\":\" \"},{\"nodeType\":1,\"id\":675,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":676,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":677,\"textContent\":\" \"},{\"nodeType\":1,\"id\":678,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":679,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":680,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":681,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":682,\"textContent\":\" \"},{\"nodeType\":1,\"id\":683,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":684,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":685,\"textContent\":\" \"},{\"nodeType\":1,\"id\":686,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":687,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":688,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":689,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":690,\"textContent\":\" \"},{\"nodeType\":1,\"id\":691,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":692,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":693,\"textContent\":\" \"},{\"nodeType\":1,\"id\":694,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":695,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":696,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":697,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":698,\"textContent\":\" \"},{\"nodeType\":1,\"id\":699,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":700,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":701,\"textContent\":\" \"},{\"nodeType\":1,\"id\":702,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"U\",\"value\":\"\"}},{\"nodeType\":3,\"id\":703,\"textContent\":\"U \"},{\"nodeType\":1,\"id\":704,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":705,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":706,\"textContent\":\" \"},{\"nodeType\":1,\"id\":707,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":708,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":709,\"textContent\":\" \"},{\"nodeType\":1,\"id\":710,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":711,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":712,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":713,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":714,\"textContent\":\" \"},{\"nodeType\":1,\"id\":715,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":716,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":717,\"textContent\":\" \"},{\"nodeType\":1,\"id\":718,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":719,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":720,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":721,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":722,\"textContent\":\" \"},{\"nodeType\":1,\"id\":723,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":724,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":725,\"textContent\":\" \"},{\"nodeType\":1,\"id\":726,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":727,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":728,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":729,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":730,\"textContent\":\" \"},{\"nodeType\":1,\"id\":731,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":732,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":733,\"textContent\":\" \"},{\"nodeType\":1,\"id\":734,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":735,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":736,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":737,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":738,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":739,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":740,\"textContent\":\" \"},{\"nodeType\":1,\"id\":741,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.duration\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":742,\"textContent\":\" \"},{\"nodeType\":1,\"id\":743,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":744,\"textContent\":\"Which shift(s) are six hours long?\"}]},{\"nodeType\":3,\"id\":745,\"textContent\":\" \"},{\"nodeType\":1,\"id\":746,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":747,\"textContent\":\" \"},{\"nodeType\":1,\"id\":748,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":749,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":750,\"textContent\":\" \"},{\"nodeType\":1,\"id\":751,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":752,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":753,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":754,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":755,\"textContent\":\" \"},{\"nodeType\":1,\"id\":756,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":757,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":758,\"textContent\":\" \"},{\"nodeType\":1,\"id\":759,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":760,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":761,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":762,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":763,\"textContent\":\" \"},{\"nodeType\":1,\"id\":764,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":765,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":766,\"textContent\":\" \"},{\"nodeType\":1,\"id\":767,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":768,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":769,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":770,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":771,\"textContent\":\" \"},{\"nodeType\":1,\"id\":772,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":773,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":774,\"textContent\":\" \"},{\"nodeType\":1,\"id\":775,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":776,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":777,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":778,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":779,\"textContent\":\" \"},{\"nodeType\":1,\"id\":780,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":781,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":782,\"textContent\":\" \"},{\"nodeType\":1,\"id\":783,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":784,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":785,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":786,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":787,\"textContent\":\" \"},{\"nodeType\":1,\"id\":788,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":789,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":790,\"textContent\":\" \"},{\"nodeType\":1,\"id\":791,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":792,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":793,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":794,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":795,\"textContent\":\" \"},{\"nodeType\":1,\"id\":796,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":797,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":798,\"textContent\":\" \"},{\"nodeType\":1,\"id\":799,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":800,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":801,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":802,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":803,\"textContent\":\" \"},{\"nodeType\":1,\"id\":804,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":805,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":806,\"textContent\":\" \"},{\"nodeType\":1,\"id\":807,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":808,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":809,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":810,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":811,\"textContent\":\" \"},{\"nodeType\":1,\"id\":812,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":813,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":814,\"textContent\":\" \"},{\"nodeType\":1,\"id\":815,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":816,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":817,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":818,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":819,\"textContent\":\" \"},{\"nodeType\":1,\"id\":820,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":821,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":822,\"textContent\":\" \"},{\"nodeType\":1,\"id\":823,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":824,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":825,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":826,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":827,\"textContent\":\" \"},{\"nodeType\":1,\"id\":828,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":829,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":830,\"textContent\":\" \"},{\"nodeType\":1,\"id\":831,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":832,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":833,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":834,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":835,\"textContent\":\" \"},{\"nodeType\":1,\"id\":836,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":837,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":838,\"textContent\":\" \"},{\"nodeType\":1,\"id\":839,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":840,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":841,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":842,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":843,\"textContent\":\" \"},{\"nodeType\":1,\"id\":844,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":845,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":846,\"textContent\":\" \"},{\"nodeType\":1,\"id\":847,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":848,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":849,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":850,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":851,\"textContent\":\" \"},{\"nodeType\":1,\"id\":852,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":853,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":854,\"textContent\":\" \"},{\"nodeType\":1,\"id\":855,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":856,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":857,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":858,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":859,\"textContent\":\" \"},{\"nodeType\":1,\"id\":860,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":861,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":862,\"textContent\":\" \"},{\"nodeType\":1,\"id\":863,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":864,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":865,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":866,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":867,\"textContent\":\" \"},{\"nodeType\":1,\"id\":868,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":869,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":870,\"textContent\":\" \"},{\"nodeType\":1,\"id\":871,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":872,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":873,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":874,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":875,\"textContent\":\" \"},{\"nodeType\":1,\"id\":876,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":877,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":878,\"textContent\":\" \"},{\"nodeType\":1,\"id\":879,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":880,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":881,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":882,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":883,\"textContent\":\" \"},{\"nodeType\":1,\"id\":884,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":885,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":886,\"textContent\":\" \"},{\"nodeType\":1,\"id\":887,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":888,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":889,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":890,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":891,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":892,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":893,\"textContent\":\" \"},{\"nodeType\":1,\"id\":894,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.duration+starts\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":895,\"textContent\":\" \"},{\"nodeType\":1,\"id\":896,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":897,\"textContent\":\"Which 2 shifts less than 5 hours long start at the same time?\"}]},{\"nodeType\":3,\"id\":898,\"textContent\":\" \"},{\"nodeType\":1,\"id\":899,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":900,\"textContent\":\" \"},{\"nodeType\":1,\"id\":901,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":902,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":903,\"textContent\":\" \"},{\"nodeType\":1,\"id\":904,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":905,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":906,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":907,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":908,\"textContent\":\" \"},{\"nodeType\":1,\"id\":909,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":910,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":911,\"textContent\":\" \"},{\"nodeType\":1,\"id\":912,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":913,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":914,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":915,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":916,\"textContent\":\" \"},{\"nodeType\":1,\"id\":917,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":918,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":919,\"textContent\":\" \"},{\"nodeType\":1,\"id\":920,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":921,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":922,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":923,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":924,\"textContent\":\" \"},{\"nodeType\":1,\"id\":925,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":926,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":927,\"textContent\":\" \"},{\"nodeType\":1,\"id\":928,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":929,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":930,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":931,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":932,\"textContent\":\" \"},{\"nodeType\":1,\"id\":933,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":934,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":935,\"textContent\":\" \"},{\"nodeType\":1,\"id\":936,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":937,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":938,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":939,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":940,\"textContent\":\" \"},{\"nodeType\":1,\"id\":941,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":942,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":943,\"textContent\":\" \"},{\"nodeType\":1,\"id\":944,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":945,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":946,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":947,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":948,\"textContent\":\" \"},{\"nodeType\":1,\"id\":949,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":950,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":951,\"textContent\":\" \"},{\"nodeType\":1,\"id\":952,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":953,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":954,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":955,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":956,\"textContent\":\" \"},{\"nodeType\":1,\"id\":957,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":958,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":959,\"textContent\":\" \"},{\"nodeType\":1,\"id\":960,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":961,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":962,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":963,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":964,\"textContent\":\" \"},{\"nodeType\":1,\"id\":965,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":966,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":967,\"textContent\":\" \"},{\"nodeType\":1,\"id\":968,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":969,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":970,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":971,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":972,\"textContent\":\" \"},{\"nodeType\":1,\"id\":973,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":974,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":975,\"textContent\":\" \"},{\"nodeType\":1,\"id\":976,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":977,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":978,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":979,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":980,\"textContent\":\" \"},{\"nodeType\":1,\"id\":981,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":982,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":983,\"textContent\":\" \"},{\"nodeType\":1,\"id\":984,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":985,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":986,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":987,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":988,\"textContent\":\" \"},{\"nodeType\":1,\"id\":989,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":990,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":991,\"textContent\":\" \"},{\"nodeType\":1,\"id\":992,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":993,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":994,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":995,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":996,\"textContent\":\" \"},{\"nodeType\":1,\"id\":997,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":998,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":999,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1000,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1001,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":1002,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1003,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1004,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1005,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1006,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1007,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1008,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1009,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":1010,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1011,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1012,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1013,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1014,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1015,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1016,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1017,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":1018,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1019,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1020,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1021,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1022,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1023,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1024,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1025,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":1026,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1027,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1028,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1029,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1030,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1031,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1032,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1033,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":1034,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1035,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1036,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1037,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1038,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1039,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1040,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1041,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":1042,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1043,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1044,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1045,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1046,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1047,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.duration+contained\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":1048,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1049,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":1050,\"textContent\":\"Which shift(s) under 7 hours long starts before B starts, and ends after X ends?\"}]},{\"nodeType\":3,\"id\":1051,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1052,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":1053,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1054,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1055,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1056,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1057,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1058,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":1059,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1060,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1061,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1062,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1063,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1064,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1065,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1066,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":1067,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1068,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1069,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1070,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1071,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1072,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1073,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1074,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":1075,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1076,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1077,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1078,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1079,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1080,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1081,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1082,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":1083,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1084,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1085,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1086,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1087,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1088,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1089,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1090,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":1091,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1092,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1093,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1094,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1095,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1096,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1097,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1098,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":1099,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1100,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1101,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1102,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1103,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1104,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1105,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1106,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":1107,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1108,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1109,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1110,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1111,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1112,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1113,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1114,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":1115,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1116,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1117,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1118,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1119,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1120,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1121,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1122,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":1123,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1124,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1125,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1126,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1127,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1128,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1129,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1130,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":1131,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1132,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1133,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1134,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1135,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1136,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1137,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1138,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":1139,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1140,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1141,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1142,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1143,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1144,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1145,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1146,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":1147,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1148,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1149,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1150,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1151,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1152,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1153,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1154,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":1155,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1156,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1157,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1158,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1159,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1160,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1161,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1162,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":1163,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1164,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1165,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1166,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1167,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1168,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1169,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1170,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":1171,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1172,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1173,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1174,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1175,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1176,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1177,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1178,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":1179,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1180,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1181,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1182,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1183,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1184,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1185,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1186,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":1187,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1188,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1189,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1190,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1191,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1192,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1193,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1194,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":1195,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1196,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1197,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1198,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1199,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1200,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.starttime+before+endtime+during\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":1201,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1202,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":1203,\"textContent\":\"Which shift(s) begins before J begins and ends during B?\"}]},{\"nodeType\":3,\"id\":1204,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1205,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":1206,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1207,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1208,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1209,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1210,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1211,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":1212,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1213,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1214,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1215,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1216,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1217,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1218,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1219,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":1220,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1221,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1222,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1223,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1224,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1225,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1226,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1227,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":1228,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1229,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1230,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1231,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1232,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1233,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1234,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1235,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":1236,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1237,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1238,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1239,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1240,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1241,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1242,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1243,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":1244,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1245,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1246,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1247,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1248,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1249,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1250,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1251,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":1252,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1253,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1254,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1255,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1256,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1257,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1258,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1259,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":1260,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1261,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1262,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1263,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1264,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1265,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1266,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1267,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":1268,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1269,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1270,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1271,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1272,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1273,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1274,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1275,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":1276,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1277,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1278,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1279,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1280,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1281,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1282,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1283,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":1284,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1285,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1286,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1287,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1288,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1289,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1290,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1291,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":1292,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1293,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1294,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1295,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1296,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1297,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1298,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1299,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":1300,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1301,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1302,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1303,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1304,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1305,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1306,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1307,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":1308,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1309,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1310,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1311,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1312,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1313,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1314,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1315,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":1316,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1317,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1318,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1319,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1320,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1321,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1322,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1323,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":1324,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1325,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1326,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1327,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1328,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1329,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1330,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1331,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":1332,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1333,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1334,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1335,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1336,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1337,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1338,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1339,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":1340,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1341,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1342,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1343,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1344,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1345,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1346,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1347,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":1348,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1349,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1350,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1351,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1352,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1353,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.ends\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":1354,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1355,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":1356,\"textContent\":\"Which shift(s) end at the same time as F?\"}]},{\"nodeType\":3,\"id\":1357,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1358,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":1359,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1360,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1361,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1362,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1363,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1364,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":1365,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1366,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1367,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1368,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1369,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1370,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1371,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1372,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":1373,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1374,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1375,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1376,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1377,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1378,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1379,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1380,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":1381,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1382,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1383,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1384,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1385,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1386,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1387,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1388,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":1389,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1390,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1391,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1392,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1393,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1394,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1395,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1396,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":1397,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1398,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1399,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1400,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1401,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1402,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1403,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1404,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":1405,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1406,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1407,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1408,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1409,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1410,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1411,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1412,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":1413,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1414,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1415,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1416,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1417,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1418,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1419,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1420,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":1421,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1422,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1423,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1424,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1425,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1426,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1427,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1428,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":1429,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1430,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1431,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1432,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1433,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1434,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1435,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1436,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":1437,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1438,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1439,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1440,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1441,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1442,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1443,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1444,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":1445,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1446,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1447,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1448,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1449,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1450,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1451,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1452,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":1453,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1454,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1455,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1456,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1457,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1458,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1459,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1460,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":1461,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1462,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1463,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1464,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1465,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1466,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1467,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1468,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":1469,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1470,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1471,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1472,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1473,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1474,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1475,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1476,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":1477,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1478,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1479,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1480,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1481,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1482,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1483,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1484,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":1485,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1486,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1487,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1488,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1489,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1490,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1491,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1492,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":1493,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1494,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1495,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1496,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1497,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1498,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1499,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1500,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":1501,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1502,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1503,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1504,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1505,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1506,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.starttime\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":1507,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1508,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":1509,\"textContent\":\"Which shift(s) start at 12pm?\"}]},{\"nodeType\":3,\"id\":1510,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1511,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":1512,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1513,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1514,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1515,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1516,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1517,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":1518,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1519,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1520,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1521,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1522,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1523,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1524,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1525,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":1526,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1527,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1528,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1529,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1530,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1531,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1532,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1533,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":1534,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1535,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1536,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1537,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1538,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1539,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1540,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1541,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":1542,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1543,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1544,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1545,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1546,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1547,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1548,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1549,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":1550,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1551,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1552,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1553,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1554,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1555,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1556,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1557,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":1558,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1559,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1560,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1561,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1562,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1563,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1564,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1565,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":1566,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1567,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1568,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1569,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1570,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1571,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1572,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1573,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":1574,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1575,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1576,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1577,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1578,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1579,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1580,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1581,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":1582,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1583,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1584,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1585,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1586,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1587,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1588,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1589,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":1590,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1591,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1592,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1593,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1594,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1595,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1596,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1597,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":1598,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1599,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1600,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1601,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1602,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1603,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1604,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1605,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":1606,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1607,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1608,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1609,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1610,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1611,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1612,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1613,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":1614,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1615,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1616,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1617,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1618,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1619,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1620,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1621,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":1622,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1623,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1624,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1625,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1626,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1627,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1628,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1629,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":1630,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1631,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1632,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1633,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1634,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1635,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1636,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1637,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":1638,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1639,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1640,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1641,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1642,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1643,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1644,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1645,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":1646,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1647,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1648,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1649,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1650,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1651,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1652,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1653,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":1654,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1655,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1656,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1657,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1658,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1659,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.starts\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":1660,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1661,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":1662,\"textContent\":\"Which shift(s) start at the same time as F?\"}]},{\"nodeType\":3,\"id\":1663,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1664,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":1665,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1666,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1667,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1668,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1669,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1670,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":1671,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1672,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1673,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1674,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1675,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1676,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1677,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1678,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":1679,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1680,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1681,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1682,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1683,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1684,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1685,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1686,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":1687,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1688,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1689,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1690,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1691,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1692,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1693,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1694,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":1695,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1696,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1697,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1698,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1699,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1700,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1701,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1702,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":1703,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1704,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1705,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1706,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1707,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1708,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1709,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1710,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":1711,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1712,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1713,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1714,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1715,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1716,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1717,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1718,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":1719,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1720,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1721,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1722,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1723,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1724,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1725,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1726,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":1727,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1728,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1729,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1730,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1731,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1732,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1733,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1734,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":1735,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1736,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1737,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1738,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1739,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1740,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1741,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1742,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":1743,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1744,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1745,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1746,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1747,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1748,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1749,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1750,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":1751,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1752,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1753,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1754,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1755,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1756,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1757,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1758,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":1759,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1760,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1761,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1762,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1763,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1764,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1765,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1766,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":1767,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1768,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1769,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1770,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1771,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1772,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1773,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1774,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":1775,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1776,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1777,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1778,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1779,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1780,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1781,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1782,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":1783,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1784,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1785,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1786,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1787,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1788,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1789,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1790,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":1791,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1792,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1793,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1794,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1795,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1796,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1797,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1798,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":1799,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1800,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1801,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1802,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1803,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1804,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1805,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1806,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":1807,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1808,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1809,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1810,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1811,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1812,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.meets\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":1813,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1814,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":1815,\"textContent\":\"Which 2 shifts end when Z begins?\"}]},{\"nodeType\":3,\"id\":1816,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1817,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":1818,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1819,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1820,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1821,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1822,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1823,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":1824,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1825,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1826,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1827,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1828,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1829,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1830,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1831,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":1832,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1833,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1834,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1835,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1836,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1837,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1838,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1839,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":1840,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1841,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1842,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1843,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1844,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1845,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1846,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1847,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":1848,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1849,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1850,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1851,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1852,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1853,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1854,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1855,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":1856,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1857,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1858,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1859,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1860,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1861,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1862,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1863,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":1864,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1865,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1866,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1867,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1868,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1869,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1870,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1871,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":1872,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1873,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1874,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1875,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1876,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1877,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1878,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1879,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":1880,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1881,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1882,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1883,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1884,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1885,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1886,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1887,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":1888,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1889,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1890,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1891,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1892,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1893,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1894,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1895,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":1896,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1897,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1898,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1899,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1900,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1901,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1902,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1903,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":1904,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1905,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1906,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1907,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1908,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1909,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1910,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1911,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":1912,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1913,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1914,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1915,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1916,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1917,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1918,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1919,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":1920,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1921,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1922,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1923,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1924,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1925,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1926,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1927,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":1928,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1929,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1930,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1931,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1932,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1933,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1934,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1935,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":1936,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1937,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1938,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1939,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1940,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1941,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1942,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1943,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":1944,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1945,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1946,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1947,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1948,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1949,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1950,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1951,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":1952,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1953,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1954,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1955,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1956,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1957,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1958,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1959,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":1960,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1961,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1962,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1963,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1964,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1965,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.endtime\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":1966,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1967,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":1968,\"textContent\":\"Which shift(s) end at 3pm?\"}]},{\"nodeType\":3,\"id\":1969,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1970,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":1971,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1972,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1973,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1974,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1975,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1976,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":1977,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1978,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1979,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1980,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1981,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1982,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1983,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1984,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":1985,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1986,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1987,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1988,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1989,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1990,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1991,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1992,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":1993,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1994,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1995,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1996,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1997,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1998,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1999,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2000,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":2001,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2002,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2003,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2004,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2005,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2006,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2007,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2008,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":2009,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2010,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2011,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2012,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2013,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2014,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2015,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2016,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":2017,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2018,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2019,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2020,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2021,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2022,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2023,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2024,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":2025,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2026,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2027,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2028,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2029,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2030,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2031,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2032,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":2033,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2034,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2035,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2036,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2037,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2038,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2039,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2040,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":2041,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2042,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2043,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2044,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2045,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2046,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2047,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2048,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":2049,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2050,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2051,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2052,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2053,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2054,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2055,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2056,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":2057,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2058,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2059,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2060,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2061,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2062,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2063,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2064,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":2065,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2066,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2067,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2068,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2069,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2070,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2071,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2072,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":2073,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2074,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2075,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2076,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2077,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2078,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2079,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2080,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":2081,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2082,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2083,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2084,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2085,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2086,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2087,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2088,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":2089,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2090,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2091,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2092,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2093,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2094,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2095,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2096,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":2097,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2098,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2099,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2100,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2101,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2102,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2103,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2104,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":2105,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2106,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2107,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2108,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2109,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2110,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2111,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2112,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":2113,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2114,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2115,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2116,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2117,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2118,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.midpoint\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":2119,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2120,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":2121,\"textContent\":\"Coffee breaks happen halfway through a shift. \"},{\"nodeType\":1,\"id\":2122,\"tagName\":\"BR\",\"attributes\":{}},{\"nodeType\":3,\"id\":2123,\"textContent\":\"Which shifts share a break at 2pm?\"}]},{\"nodeType\":3,\"id\":2124,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2125,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":2126,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2127,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2128,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2129,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2130,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2131,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":2132,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2133,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2134,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2135,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2136,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2137,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2138,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2139,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":2140,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2141,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2142,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2143,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2144,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2145,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2146,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2147,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":2148,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2149,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2150,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2151,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2152,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2153,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2154,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2155,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":2156,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2157,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2158,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2159,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2160,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2161,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2162,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2163,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":2164,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2165,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2166,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2167,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2168,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2169,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2170,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2171,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":2172,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2173,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2174,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2175,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2176,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2177,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2178,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2179,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":2180,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2181,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2182,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2183,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2184,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2185,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2186,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2187,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":2188,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2189,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2190,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2191,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2192,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2193,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2194,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2195,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":2196,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2197,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2198,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2199,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2200,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2201,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2202,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2203,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":2204,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2205,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2206,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2207,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2208,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2209,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2210,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2211,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":2212,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2213,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2214,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2215,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2216,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2217,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2218,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2219,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":2220,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2221,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2222,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2223,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2224,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2225,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2226,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2227,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":2228,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2229,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2230,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2231,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2232,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2233,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2234,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2235,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":2236,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2237,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2238,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2239,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2240,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2241,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2242,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2243,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":2244,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2245,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2246,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2247,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2248,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2249,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2250,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2251,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":2252,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2253,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2254,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2255,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2256,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2257,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2258,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2259,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":2260,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2261,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2262,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2263,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2264,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2265,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2266,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2267,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":2268,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2269,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2270,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2271,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2272,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2273,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\".strategy\",\"style\":\"display: block;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2274,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2275,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":2276,\"textContent\":\"Please describe how to determine what event(s) start at 12pm?\"}]},{\"nodeType\":3,\"id\":2277,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2278,\"tagName\":\"TEXTAREA\",\"attributes\":{\"id\":\"strategyAnswer\",\"rows\":\"5\",\"cols\":\"80\"}},{\"nodeType\":3,\"id\":2279,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2280,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2281,\"textContent\":\" \"},{\"nodeType\":8,\"id\":2282},{\"nodeType\":3,\"id\":2283,\"textContent\":\" \"},{\"nodeType\":8,\"id\":2284},{\"nodeType\":3,\"id\":2285,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2286,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"fixbottom\"},\"childNodes\":[{\"nodeType\":3,\"id\":2287,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2288,\"tagName\":\"BUTTON\",\"attributes\":{\"type\":\"button\",\"id\":\"testingButton\",\"style\":\"display:none;\",\"class\":\"btn\"},\"childNodes\":[{\"nodeType\":3,\"id\":2289,\"textContent\":\"SUBMIT\"}]},{\"nodeType\":3,\"id\":2290,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2291,\"tagName\":\"BUTTON\",\"attributes\":{\"type\":\"button\",\"id\":\"strategyButton\",\"style\":\"display: block;\",\"class\":\"btn\"},\"childNodes\":[{\"nodeType\":3,\"id\":2292,\"textContent\":\"SUBMIT\"}]},{\"nodeType\":3,\"id\":2293,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2294,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2295,\"textContent\":\" \"},{\"nodeType\":8,\"id\":2296},{\"nodeType\":3,\"id\":2297,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2298,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"d3container\"},\"childNodes\":[{\"nodeType\":1,\"id\":2299,\"tagName\":\"svg\",\"attributes\":{\"width\":\"930\",\"height\":\"915\"},\"childNodes\":[{\"nodeType\":1,\"id\":2300,\"tagName\":\"g\",\"attributes\":{\"transform\":\"translate(100,25)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2301,\"tagName\":\"g\",\"attributes\":{\"class\":\"leaders\"}},{\"nodeType\":1,\"id\":2302,\"tagName\":\"g\",\"attributes\":{\"class\":\"static-scaffold\"}},{\"nodeType\":1,\"id\":2303,\"tagName\":\"g\",\"attributes\":{\"class\":\"xaxis\",\"transform\":\"translate(0,800)\",\"fill\":\"none\",\"font-size\":\"10\",\"font-family\":\"sans-serif\",\"text-anchor\":\"middle\"},\"childNodes\":[{\"nodeType\":1,\"id\":2304,\"tagName\":\"path\",\"attributes\":{\"class\":\"domain\",\"stroke\":\"#000\",\"d\":\"M0.5,6V0.5H800.5V6\"}},{\"nodeType\":1,\"id\":2305,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0.5,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2306,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2307,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2308,\"textContent\":\"08 AM\"}]}]},{\"nodeType\":1,\"id\":2309,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(33.83333333333333,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2310,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2311,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2312,\"textContent\":\"08:30\"}]}]},{\"nodeType\":1,\"id\":2313,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(67.16666666666666,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2314,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2315,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2316,\"textContent\":\"09 AM\"}]}]},{\"nodeType\":1,\"id\":2317,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(100.5,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2318,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2319,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2320,\"textContent\":\"09:30\"}]}]},{\"nodeType\":1,\"id\":2321,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(133.83333333333331,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2322,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2323,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2324,\"textContent\":\"10 AM\"}]}]},{\"nodeType\":1,\"id\":2325,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(167.16666666666669,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2326,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2327,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2328,\"textContent\":\"10:30\"}]}]},{\"nodeType\":1,\"id\":2329,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(200.5,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2330,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2331,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2332,\"textContent\":\"11 AM\"}]}]},{\"nodeType\":1,\"id\":2333,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(233.83333333333334,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2334,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2335,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2336,\"textContent\":\"11:30\"}]}]},{\"nodeType\":1,\"id\":2337,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(267.16666666666663,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2338,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2339,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2340,\"textContent\":\"12 PM\"}]}]},{\"nodeType\":1,\"id\":2341,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(300.5,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2342,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2343,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2344,\"textContent\":\"12:30\"}]}]},{\"nodeType\":1,\"id\":2345,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(333.83333333333337,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2346,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2347,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2348,\"textContent\":\"01 PM\"}]}]},{\"nodeType\":1,\"id\":2349,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(367.16666666666663,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2350,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2351,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2352,\"textContent\":\"01:30\"}]}]},{\"nodeType\":1,\"id\":2353,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(400.5,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2354,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2355,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2356,\"textContent\":\"02 PM\"}]}]},{\"nodeType\":1,\"id\":2357,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(433.8333333333333,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2358,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2359,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2360,\"textContent\":\"02:30\"}]}]},{\"nodeType\":1,\"id\":2361,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(467.1666666666667,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2362,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2363,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2364,\"textContent\":\"03 PM\"}]}]},{\"nodeType\":1,\"id\":2365,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(500.5,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2366,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2367,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2368,\"textContent\":\"03:30\"}]}]},{\"nodeType\":1,\"id\":2369,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(533.8333333333333,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2370,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2371,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2372,\"textContent\":\"04 PM\"}]}]},{\"nodeType\":1,\"id\":2373,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(567.1666666666667,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2374,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2375,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2376,\"textContent\":\"04:30\"}]}]},{\"nodeType\":1,\"id\":2377,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(600.5,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2378,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2379,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2380,\"textContent\":\"05 PM\"}]}]},{\"nodeType\":1,\"id\":2381,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(633.8333333333333,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2382,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2383,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2384,\"textContent\":\"05:30\"}]}]},{\"nodeType\":1,\"id\":2385,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(667.1666666666667,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2386,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2387,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2388,\"textContent\":\"06 PM\"}]}]},{\"nodeType\":1,\"id\":2389,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(700.5,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2390,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2391,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2392,\"textContent\":\"06:30\"}]}]},{\"nodeType\":1,\"id\":2393,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(733.8333333333333,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2394,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2395,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2396,\"textContent\":\"07 PM\"}]}]},{\"nodeType\":1,\"id\":2397,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(767.1666666666667,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2398,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2399,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2400,\"textContent\":\"07:30\"}]}]},{\"nodeType\":1,\"id\":2401,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(800.5,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2402,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2403,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2404,\"textContent\":\"08 PM\"}]}]},{\"nodeType\":1,\"id\":2405,\"tagName\":\"g\",\"attributes\":{\"class\":\"axisTitle\"},\"childNodes\":[{\"nodeType\":1,\"id\":2406,\"tagName\":\"text\",\"attributes\":{\"x\":\"533.3333333333334\",\"y\":\"80\",\"style\":\"text-anchor: end;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2407,\"textContent\":\"START & END TIME (time of day)\"}]}]}]},{\"nodeType\":1,\"id\":2408,\"tagName\":\"g\",\"attributes\":{\"class\":\"yaxis\",\"fill\":\"none\",\"font-size\":\"10\",\"font-family\":\"sans-serif\",\"text-anchor\":\"end\"},\"childNodes\":[{\"nodeType\":1,\"id\":2409,\"tagName\":\"path\",\"attributes\":{\"class\":\"domain\",\"stroke\":\"#000\",\"d\":\"M-15,800.5H0.5V0.5H-15\"}},{\"nodeType\":1,\"id\":2410,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,800.5)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2411,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2412,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2413,\"textContent\":\"0\"}]}]},{\"nodeType\":1,\"id\":2414,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,733.8333333333334)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2415,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2416,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2417,\"textContent\":\"1\"}]}]},{\"nodeType\":1,\"id\":2418,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,667.1666666666667)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2419,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2420,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2421,\"textContent\":\"2\"}]}]},{\"nodeType\":1,\"id\":2422,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,600.5)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2423,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2424,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2425,\"textContent\":\"3\"}]}]},{\"nodeType\":1,\"id\":2426,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,533.8333333333334)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2427,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2428,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2429,\"textContent\":\"4\"}]}]},{\"nodeType\":1,\"id\":2430,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,467.16666666666663)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2431,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2432,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2433,\"textContent\":\"5\"}]}]},{\"nodeType\":1,\"id\":2434,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,400.5)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2435,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2436,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2437,\"textContent\":\"6\"}]}]},{\"nodeType\":1,\"id\":2438,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,333.8333333333333)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2439,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2440,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2441,\"textContent\":\"7\"}]}]},{\"nodeType\":1,\"id\":2442,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,267.16666666666674)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2443,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2444,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2445,\"textContent\":\"8\"}]}]},{\"nodeType\":1,\"id\":2446,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,200.5)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2447,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2448,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2449,\"textContent\":\"9\"}]}]},{\"nodeType\":1,\"id\":2450,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,133.83333333333326)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2451,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2452,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2453,\"textContent\":\"10\"}]}]},{\"nodeType\":1,\"id\":2454,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,67.16666666666674)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2455,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2456,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2457,\"textContent\":\"11\"}]}]},{\"nodeType\":1,\"id\":2458,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,0.5)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2459,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2460,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2461,\"textContent\":\"12\"}]}]},{\"nodeType\":1,\"id\":2462,\"tagName\":\"g\",\"attributes\":{\"class\":\"axisTitle\"},\"childNodes\":[{\"nodeType\":1,\"id\":2463,\"tagName\":\"text\",\"attributes\":{\"transform\":\"rotate(-90)\",\"x\":\"-350\",\"y\":\"-60\",\"style\":\"text-anchor: end;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2464,\"textContent\":\"DURATION (in hours)\"}]}]}]},{\"nodeType\":1,\"id\":2465,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2466,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2467,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"733.3333333333334\",\"y2\":\"733.3333333333334\"}}]},{\"nodeType\":1,\"id\":2468,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2469,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"666.6666666666667\",\"y2\":\"666.6666666666667\"}}]},{\"nodeType\":1,\"id\":2470,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2471,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"600\",\"y2\":\"600\"}}]},{\"nodeType\":1,\"id\":2472,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2473,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"533.3333333333334\",\"y2\":\"533.3333333333334\"}}]},{\"nodeType\":1,\"id\":2474,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2475,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"466.66666666666663\",\"y2\":\"466.66666666666663\"}}]},{\"nodeType\":1,\"id\":2476,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2477,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"400\",\"y2\":\"400\"}}]},{\"nodeType\":1,\"id\":2478,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2479,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"333.3333333333333\",\"y2\":\"333.3333333333333\"}}]},{\"nodeType\":1,\"id\":2480,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2481,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"266.66666666666674\",\"y2\":\"266.66666666666674\"}}]},{\"nodeType\":1,\"id\":2482,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2483,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"200\",\"y2\":\"200\"}}]},{\"nodeType\":1,\"id\":2484,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2485,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"133.33333333333326\",\"y2\":\"133.33333333333326\"}}]},{\"nodeType\":1,\"id\":2486,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2487,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"66.66666666666674\",\"y2\":\"66.66666666666674\"}}]},{\"nodeType\":1,\"id\":2488,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2489,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"0\",\"y2\":\"0\"}}]}]},{\"nodeType\":1,\"id\":2490,\"tagName\":\"g\",\"attributes\":{\"class\":\"xgrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2491,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"0\",\"y1\":\"800\",\"x2\":\"400\",\"y2\":\"0\"}},{\"nodeType\":1,\"id\":2492,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"800\",\"y1\":\"800\",\"x2\":\"400\",\"y2\":\"0\"}},{\"nodeType\":1,\"id\":2493,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"66.66666666666666\",\"y1\":\"800\",\"x2\":\"433.3333333333333\",\"y2\":\"66.66666666666674\"}},{\"nodeType\":1,\"id\":2494,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"733.3333333333333\",\"y1\":\"800\",\"x2\":\"366.66666666666663\",\"y2\":\"66.66666666666674\"}},{\"nodeType\":1,\"id\":2495,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"133.33333333333331\",\"y1\":\"800\",\"x2\":\"466.6666666666667\",\"y2\":\"133.33333333333326\"}},{\"nodeType\":1,\"id\":2496,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"666.6666666666667\",\"y1\":\"800\",\"x2\":\"333.33333333333337\",\"y2\":\"133.33333333333326\"}},{\"nodeType\":1,\"id\":2497,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"200\",\"y1\":\"800\",\"x2\":\"500\",\"y2\":\"200\"}},{\"nodeType\":1,\"id\":2498,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"600\",\"y1\":\"800\",\"x2\":\"300\",\"y2\":\"200\"}},{\"nodeType\":1,\"id\":2499,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"266.66666666666663\",\"y1\":\"800\",\"x2\":\"533.3333333333333\",\"y2\":\"266.66666666666674\"}},{\"nodeType\":1,\"id\":2500,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"533.3333333333333\",\"y1\":\"800\",\"x2\":\"266.66666666666663\",\"y2\":\"266.66666666666674\"}},{\"nodeType\":1,\"id\":2501,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"333.33333333333337\",\"y1\":\"800\",\"x2\":\"566.6666666666667\",\"y2\":\"333.3333333333333\"}},{\"nodeType\":1,\"id\":2502,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"466.6666666666667\",\"y1\":\"800\",\"x2\":\"233.33333333333334\",\"y2\":\"333.3333333333333\"}},{\"nodeType\":1,\"id\":2503,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"400\",\"y1\":\"800\",\"x2\":\"600\",\"y2\":\"400\"}},{\"nodeType\":1,\"id\":2504,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"400\",\"y1\":\"800\",\"x2\":\"200\",\"y2\":\"400\"}},{\"nodeType\":1,\"id\":2505,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"466.6666666666667\",\"y1\":\"800\",\"x2\":\"633.3333333333333\",\"y2\":\"466.66666666666663\"}},{\"nodeType\":1,\"id\":2506,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"333.33333333333337\",\"y1\":\"800\",\"x2\":\"166.66666666666669\",\"y2\":\"466.66666666666663\"}},{\"nodeType\":1,\"id\":2507,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"533.3333333333333\",\"y1\":\"800\",\"x2\":\"666.6666666666667\",\"y2\":\"533.3333333333334\"}},{\"nodeType\":1,\"id\":2508,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"266.66666666666663\",\"y1\":\"800\",\"x2\":\"133.33333333333331\",\"y2\":\"533.3333333333334\"}},{\"nodeType\":1,\"id\":2509,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"600\",\"y1\":\"800\",\"x2\":\"700\",\"y2\":\"600\"}},{\"nodeType\":1,\"id\":2510,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"200\",\"y1\":\"800\",\"x2\":\"100\",\"y2\":\"600\"}},{\"nodeType\":1,\"id\":2511,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"666.6666666666667\",\"y1\":\"800\",\"x2\":\"733.3333333333333\",\"y2\":\"666.6666666666667\"}},{\"nodeType\":1,\"id\":2512,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"133.33333333333331\",\"y1\":\"800\",\"x2\":\"66.66666666666666\",\"y2\":\"666.6666666666667\"}},{\"nodeType\":1,\"id\":2513,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"733.3333333333333\",\"y1\":\"800\",\"x2\":\"766.6666666666667\",\"y2\":\"733.3333333333334\"}},{\"nodeType\":1,\"id\":2514,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"66.66666666666666\",\"y1\":\"800\",\"x2\":\"33.33333333333333\",\"y2\":\"733.3333333333334\"}}]},{\"nodeType\":1,\"id\":2515,\"tagName\":\"g\",\"attributes\":{\"class\":\"data\"},\"childNodes\":[{\"nodeType\":1,\"id\":2516,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2517,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"333.33333333333337\",\"cy\":\"266.66666666666674\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2518,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"328.33333333333337\",\"y\":\"258.66666666666674\"},\"childNodes\":[{\"nodeType\":3,\"id\":2519,\"textContent\":\"A \"}]}]},{\"nodeType\":1,\"id\":2520,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2521,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"266.66666666666663\",\"cy\":\"600\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2522,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"261.66666666666663\",\"y\":\"592\"},\"childNodes\":[{\"nodeType\":3,\"id\":2523,\"textContent\":\"B \"}]}]},{\"nodeType\":1,\"id\":2524,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2525,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"366.66666666666663\",\"cy\":\"466.66666666666663\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2526,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"361.66666666666663\",\"y\":\"458.66666666666663\"},\"childNodes\":[{\"nodeType\":3,\"id\":2527,\"textContent\":\"C \"}]}]},{\"nodeType\":1,\"id\":2528,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2529,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"666.6666666666667\",\"cy\":\"666.6666666666667\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2530,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"661.6666666666667\",\"y\":\"658.6666666666667\"},\"childNodes\":[{\"nodeType\":3,\"id\":2531,\"textContent\":\"D \"}]}]},{\"nodeType\":1,\"id\":2532,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2533,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"200\",\"cy\":\"400\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2534,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"195\",\"y\":\"392\"},\"childNodes\":[{\"nodeType\":3,\"id\":2535,\"textContent\":\"E \"}]}]},{\"nodeType\":1,\"id\":2536,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2537,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"266.66666666666663\",\"cy\":\"533.3333333333334\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2538,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"261.66666666666663\",\"y\":\"525.3333333333334\"},\"childNodes\":[{\"nodeType\":3,\"id\":2539,\"textContent\":\"F \"}]}]},{\"nodeType\":1,\"id\":2540,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2541,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"333.33333333333337\",\"cy\":\"400\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2542,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"328.33333333333337\",\"y\":\"392\"},\"childNodes\":[{\"nodeType\":3,\"id\":2543,\"textContent\":\"G \"}]}]},{\"nodeType\":1,\"id\":2544,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2545,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"500\",\"cy\":\"466.66666666666663\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2546,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"495\",\"y\":\"458.66666666666663\"},\"childNodes\":[{\"nodeType\":3,\"id\":2547,\"textContent\":\"H \"}]}]},{\"nodeType\":1,\"id\":2548,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2549,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"100\",\"cy\":\"600\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2550,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"95\",\"y\":\"592\"},\"childNodes\":[{\"nodeType\":3,\"id\":2551,\"textContent\":\"I \"}]}]},{\"nodeType\":1,\"id\":2552,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2553,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"133.33333333333331\",\"cy\":\"666.6666666666667\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2554,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"128.33333333333331\",\"y\":\"658.6666666666667\"},\"childNodes\":[{\"nodeType\":3,\"id\":2555,\"textContent\":\"J \"}]}]},{\"nodeType\":1,\"id\":2556,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2557,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"400\",\"cy\":\"133.33333333333326\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2558,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"395\",\"y\":\"125.33333333333326\"},\"childNodes\":[{\"nodeType\":3,\"id\":2559,\"textContent\":\"K \"}]}]},{\"nodeType\":1,\"id\":2560,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2561,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"500\",\"cy\":\"333.3333333333333\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2562,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"495\",\"y\":\"325.3333333333333\"},\"childNodes\":[{\"nodeType\":3,\"id\":2563,\"textContent\":\"L \"}]}]},{\"nodeType\":1,\"id\":2564,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2565,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"300\",\"cy\":\"733.3333333333334\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2566,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"295\",\"y\":\"725.3333333333334\"},\"childNodes\":[{\"nodeType\":3,\"id\":2567,\"textContent\":\"M \"}]}]},{\"nodeType\":1,\"id\":2568,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2569,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"600\",\"cy\":\"666.6666666666667\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2570,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"595\",\"y\":\"658.6666666666667\"},\"childNodes\":[{\"nodeType\":3,\"id\":2571,\"textContent\":\"N \"}]}]},{\"nodeType\":1,\"id\":2572,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2573,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"433.3333333333333\",\"cy\":\"600\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2574,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"428.3333333333333\",\"y\":\"592\"},\"childNodes\":[{\"nodeType\":3,\"id\":2575,\"textContent\":\"O \"}]}]},{\"nodeType\":1,\"id\":2576,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2577,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"500\",\"cy\":\"200\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2578,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"495\",\"y\":\"192\"},\"childNodes\":[{\"nodeType\":3,\"id\":2579,\"textContent\":\"P \"}]}]},{\"nodeType\":1,\"id\":2580,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2581,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"533.3333333333333\",\"cy\":\"533.3333333333334\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2582,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"528.3333333333333\",\"y\":\"525.3333333333334\"},\"childNodes\":[{\"nodeType\":3,\"id\":2583,\"textContent\":\"Z \"}]}]},{\"nodeType\":1,\"id\":2584,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2585,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"400\",\"cy\":\"666.6666666666667\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2586,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"395\",\"y\":\"658.6666666666667\"},\"childNodes\":[{\"nodeType\":3,\"id\":2587,\"textContent\":\"X \"}]}]}]}]}]}]},{\"nodeType\":3,\"id\":2588,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2589,\"textContent\":\" \"},{\"nodeType\":8,\"id\":2590},{\"nodeType\":3,\"id\":2591,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2592,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":2593,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2594,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":2595,\"textContent\":\" \"}]}]}]]}",
  "useCssProxy": true,
  "loadTimes": "es: 152, dom: 837, initialDom: 1439",
  "javascriptErrors": []
}