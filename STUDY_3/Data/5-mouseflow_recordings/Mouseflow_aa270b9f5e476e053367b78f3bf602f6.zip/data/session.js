var MF = MF || {};MF.RecordingData = MF.RecordingData || {};MF.RecordingData["session"] = {
  "id": "aa270b9f5e476e053367b78f3bf602f6",
  "created": "2018-05-31T12:14:39.3447331-07:00",
  "lastActivity": "2018-05-31T12:15:07.7867331-07:00",
  "pageViews": [
    {
      "id": "053139363044905a47e8f4f9e7c9cd65e5a38d88",
      "startTime": "2018-05-31T12:14:39.3447331-07:00",
      "endTime": "2018-05-31T12:15:07.7867331-07:00",
      "title": "FOX2YP",
      "uri": "https://warm-citadel-75324.herokuapp.com/",
      "websitePage": "/15",
      "visitTime": 28442,
      "engagementTime": 25193,
      "scroll": 100.0,
      "tags": [
        "form-interact"
      ],
      "friction": 0,
      "annotations": []
    }
  ],
  "duration": 28442,
  "engagementTime": 25193,
  "totalFriction": 0,
  "country": "us",
  "region": "CA",
  "city": "La Jolla",
  "isp": "University of California, San Diego",
  "ip": "128.54.68.23",
  "lang": "en-US",
  "userAgent": "Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/67.0.3396.62 Safari/537.36",
  "browser": "Chrome",
  "browserVersion": "67.0.3396.62",
  "os": "Windows",
  "osVersion": "7",
  "device": "Desktop",
  "referrer": "",
  "referrerType": "",
  "screenRes": "1920x1200",
  "tags": [
    "form-interact"
  ],
  "variables": [
    "SID=XQ4O8",
    "CONDITION=115",
    "ORTH_CORRECT=1"
  ],
  "watched": false,
  "starred": false,
  "lng": -117.2359,
  "lat": 32.8807,
  "visitorId": "f62308b5ea48e9fb449832c70029cf8e",
  "gdpr": false
}