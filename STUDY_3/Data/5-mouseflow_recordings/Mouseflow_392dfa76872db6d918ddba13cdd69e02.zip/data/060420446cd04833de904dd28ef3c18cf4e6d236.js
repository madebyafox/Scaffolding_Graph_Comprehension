var MF = MF || {};MF.RecordingData = MF.RecordingData || {};MF.RecordingData["060420446cd04833de904dd28ef3c18cf4e6d236"] = {
  "startTime": "2018-06-04T19:18:20.2837116Z",
  "websitePageUrl": "/16",
  "visitTime": 182912,
  "engagementTime": 134892,
  "pageTitle": "FOX2YP",
  "url": "https://warm-citadel-75324.herokuapp.com/",
  "viewportWidth": 1920,
  "viewportHeight": 1200,
  "tags": [
    "form-interact",
    "submit"
  ],
  "session": {
    "id": "392dfa76872db6d918ddba13cdd69e02",
    "created": "2018-06-04T19:18:20.2837116+00:00",
    "lastActivity": "0001-01-01T00:00:00+00:00",
    "pages": 1,
    "duration": 0,
    "engagementTime": 0,
    "totalFriction": 0,
    "country": "us",
    "region": "CA",
    "city": "La Jolla",
    "isp": "University of California, San Diego",
    "ip": "###.###.###.###",
    "lang": "en-US",
    "userAgent": "Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/66.0.3359.181 Safari/537.36",
    "browser": "Chrome",
    "browserVersion": "66.0.3359.181",
    "os": "Windows",
    "osVersion": "7",
    "device": "Desktop",
    "referrer": "",
    "referrerType": "",
    "screenRes": "1920x1200",
    "entryPage": "/16",
    "tags": [
      "form-interact",
      "submit"
    ],
    "variables": [
      "SID=JYGX2",
      "CONDITION=311"
    ],
    "watched": false,
    "starred": false,
    "lng": 32.8807,
    "lat": 32.8807,
    "visitorId": "b93db2658cd4f3a4f4ab1a5b3ec22dbd",
    "gdpr": false,
    "visitorName": null,
    "playbackUrl": "https://us.mouseflow.com/websites/e0c9ff05-6fcb-4c4a-8173-e5a0724987b1/recordings/392dfa76872db6d918ddba13cdd69e02/play"
  },
  "events": [
    {
      "t": 0,
      "e": 0,
      "ty": 14,
      "x": 0,
      "y": 1199
    },
    {
      "t": 269,
      "e": 269,
      "ty": 0,
      "x": 1920,
      "y": 1200
    },
    {
      "t": 269,
      "e": 269,
      "ty": 2,
      "x": 743,
      "y": 804
    },
    {
      "t": 269,
      "e": 269,
      "ty": 41,
      "x": 3610,
      "y": 47287,
      "ta": "> div.stimulus > div:[2]"
    },
    {
      "t": 658,
      "e": 658,
      "ty": 2,
      "x": 757,
      "y": 814
    },
    {
      "t": 750,
      "e": 750,
      "ty": 41,
      "x": 4414,
      "y": 48139,
      "ta": "> div.stimulus > div:[2]"
    },
    {
      "t": 800,
      "e": 800,
      "ty": 2,
      "x": 757,
      "y": 819
    },
    {
      "t": 1001,
      "e": 1001,
      "ty": 41,
      "x": 4414,
      "y": 48352,
      "ta": "> div.stimulus > div:[2]"
    },
    {
      "t": 1201,
      "e": 1201,
      "ty": 2,
      "x": 759,
      "y": 821
    },
    {
      "t": 1251,
      "e": 1251,
      "ty": 41,
      "x": 4528,
      "y": 48494,
      "ta": "> div.stimulus > div:[2]"
    },
    {
      "t": 1301,
      "e": 1301,
      "ty": 2,
      "x": 760,
      "y": 824
    },
    {
      "t": 1400,
      "e": 1400,
      "ty": 2,
      "x": 762,
      "y": 832
    },
    {
      "t": 1501,
      "e": 1501,
      "ty": 41,
      "x": 4701,
      "y": 49275,
      "ta": "> div.stimulus > div:[2]"
    },
    {
      "t": 1750,
      "e": 1750,
      "ty": 41,
      "x": 4701,
      "y": 49346,
      "ta": "> div.stimulus > div:[2]"
    },
    {
      "t": 1801,
      "e": 1801,
      "ty": 2,
      "x": 762,
      "y": 833
    },
    {
      "t": 2700,
      "e": 2700,
      "ty": 2,
      "x": 756,
      "y": 829
    },
    {
      "t": 2751,
      "e": 2751,
      "ty": 41,
      "x": 4356,
      "y": 49062,
      "ta": "> div.stimulus > div:[2]"
    },
    {
      "t": 2801,
      "e": 2801,
      "ty": 2,
      "x": 755,
      "y": 829
    },
    {
      "t": 3001,
      "e": 3001,
      "ty": 41,
      "x": 4299,
      "y": 49062,
      "ta": "> div.stimulus > div:[2]"
    },
    {
      "t": 3101,
      "e": 3101,
      "ty": 2,
      "x": 753,
      "y": 829
    },
    {
      "t": 3201,
      "e": 3201,
      "ty": 2,
      "x": 751,
      "y": 830
    },
    {
      "t": 3251,
      "e": 3251,
      "ty": 41,
      "x": 4069,
      "y": 49133,
      "ta": "> div.stimulus > div:[2]"
    },
    {
      "t": 4101,
      "e": 4101,
      "ty": 2,
      "x": 750,
      "y": 830
    },
    {
      "t": 4201,
      "e": 4201,
      "ty": 2,
      "x": 755,
      "y": 824
    },
    {
      "t": 4251,
      "e": 4251,
      "ty": 41,
      "x": 4414,
      "y": 48636,
      "ta": "> div.stimulus > div:[2]"
    },
    {
      "t": 4300,
      "e": 4300,
      "ty": 2,
      "x": 758,
      "y": 823
    },
    {
      "t": 4502,
      "e": 4502,
      "ty": 41,
      "x": 4471,
      "y": 48636,
      "ta": "> div.stimulus > div:[2]"
    },
    {
      "t": 4700,
      "e": 4700,
      "ty": 2,
      "x": 751,
      "y": 826
    },
    {
      "t": 4751,
      "e": 4751,
      "ty": 41,
      "x": 3840,
      "y": 49062,
      "ta": "> div.stimulus > div:[2]"
    },
    {
      "t": 4801,
      "e": 4801,
      "ty": 2,
      "x": 745,
      "y": 829
    },
    {
      "t": 4900,
      "e": 4900,
      "ty": 2,
      "x": 737,
      "y": 820
    },
    {
      "t": 5000,
      "e": 5000,
      "ty": 2,
      "x": 755,
      "y": 815
    },
    {
      "t": 5000,
      "e": 5000,
      "ty": 41,
      "x": 4299,
      "y": 48068,
      "ta": "> div.stimulus > div:[2]"
    },
    {
      "t": 5100,
      "e": 5100,
      "ty": 2,
      "x": 989,
      "y": 785
    },
    {
      "t": 5200,
      "e": 5200,
      "ty": 2,
      "x": 1123,
      "y": 780
    },
    {
      "t": 5250,
      "e": 5250,
      "ty": 41,
      "x": 26003,
      "y": 46554,
      "ta": "> div.stimulus > div:[2] > svg"
    },
    {
      "t": 5300,
      "e": 5300,
      "ty": 2,
      "x": 1190,
      "y": 799
    },
    {
      "t": 5400,
      "e": 5400,
      "ty": 2,
      "x": 1219,
      "y": 830
    },
    {
      "t": 5500,
      "e": 5500,
      "ty": 2,
      "x": 1225,
      "y": 891
    },
    {
      "t": 5501,
      "e": 5501,
      "ty": 41,
      "x": 30936,
      "y": 53932,
      "ta": "> div.stimulus > div:[2] > svg"
    },
    {
      "t": 5601,
      "e": 5601,
      "ty": 2,
      "x": 1205,
      "y": 927
    },
    {
      "t": 5701,
      "e": 5701,
      "ty": 2,
      "x": 1196,
      "y": 935
    },
    {
      "t": 5751,
      "e": 5751,
      "ty": 41,
      "x": 28611,
      "y": 57298,
      "ta": "> div.stimulus > div:[2] > svg"
    },
    {
      "t": 5801,
      "e": 5801,
      "ty": 2,
      "x": 1168,
      "y": 961
    },
    {
      "t": 5901,
      "e": 5901,
      "ty": 2,
      "x": 1152,
      "y": 986
    },
    {
      "t": 6001,
      "e": 6001,
      "ty": 41,
      "x": 25792,
      "y": 60736,
      "ta": "> div.stimulus > div:[2] > svg"
    },
    {
      "t": 6301,
      "e": 6301,
      "ty": 2,
      "x": 1150,
      "y": 987
    },
    {
      "t": 6400,
      "e": 6400,
      "ty": 2,
      "x": 1145,
      "y": 1005
    },
    {
      "t": 6502,
      "e": 6502,
      "ty": 41,
      "x": 25299,
      "y": 62097,
      "ta": "> div.stimulus > div:[2] > svg"
    },
    {
      "t": 6601,
      "e": 6601,
      "ty": 2,
      "x": 1137,
      "y": 1006
    },
    {
      "t": 6702,
      "e": 6702,
      "ty": 2,
      "x": 1141,
      "y": 984
    },
    {
      "t": 6752,
      "e": 6752,
      "ty": 41,
      "x": 22569,
      "y": 5957,
      "ta": "> div.stimulus > div:[2] > svg > g > g:[3] > path"
    },
    {
      "t": 6801,
      "e": 6801,
      "ty": 2,
      "x": 1166,
      "y": 956
    },
    {
      "t": 6902,
      "e": 6902,
      "ty": 2,
      "x": 1173,
      "y": 938
    },
    {
      "t": 7001,
      "e": 7001,
      "ty": 2,
      "x": 1178,
      "y": 923
    },
    {
      "t": 7002,
      "e": 7002,
      "ty": 41,
      "x": 27624,
      "y": 56224,
      "ta": "> div.stimulus > div:[2] > svg"
    },
    {
      "t": 7106,
      "e": 7106,
      "ty": 2,
      "x": 1186,
      "y": 901
    },
    {
      "t": 7201,
      "e": 7201,
      "ty": 2,
      "x": 1187,
      "y": 898
    },
    {
      "t": 7250,
      "e": 7250,
      "ty": 41,
      "x": 38314,
      "y": 41869,
      "ta": "> div.stimulus > div:[2] > svg > g > g:[7] > g:[13] > circle"
    },
    {
      "t": 7401,
      "e": 7401,
      "ty": 2,
      "x": 1185,
      "y": 820
    },
    {
      "t": 7501,
      "e": 7501,
      "ty": 2,
      "x": 1193,
      "y": 799
    },
    {
      "t": 7501,
      "e": 7501,
      "ty": 41,
      "x": 28681,
      "y": 47342,
      "ta": "> div.stimulus > div:[2] > svg"
    },
    {
      "t": 7601,
      "e": 7601,
      "ty": 2,
      "x": 1202,
      "y": 798
    },
    {
      "t": 7701,
      "e": 7701,
      "ty": 2,
      "x": 1204,
      "y": 884
    },
    {
      "t": 7751,
      "e": 7751,
      "ty": 41,
      "x": 29245,
      "y": 54075,
      "ta": "> div.stimulus > div:[2] > svg"
    },
    {
      "t": 7801,
      "e": 7801,
      "ty": 2,
      "x": 1199,
      "y": 897
    },
    {
      "t": 7901,
      "e": 7901,
      "ty": 2,
      "x": 1195,
      "y": 898
    },
    {
      "t": 8001,
      "e": 8001,
      "ty": 2,
      "x": 1173,
      "y": 903
    },
    {
      "t": 8001,
      "e": 8001,
      "ty": 41,
      "x": 27272,
      "y": 54791,
      "ta": "> div.stimulus > div:[2] > svg"
    },
    {
      "t": 8250,
      "e": 8250,
      "ty": 41,
      "x": 27765,
      "y": 54719,
      "ta": "> div.stimulus > div:[2] > svg"
    },
    {
      "t": 8300,
      "e": 8300,
      "ty": 2,
      "x": 1183,
      "y": 902
    },
    {
      "t": 8400,
      "e": 8400,
      "ty": 2,
      "x": 1186,
      "y": 900
    },
    {
      "t": 8500,
      "e": 8500,
      "ty": 41,
      "x": 32852,
      "y": 52792,
      "ta": "> div.stimulus > div:[2] > svg > g > g:[7] > g:[13] > circle"
    },
    {
      "t": 8700,
      "e": 8700,
      "ty": 2,
      "x": 1185,
      "y": 896
    },
    {
      "t": 8751,
      "e": 8751,
      "ty": 41,
      "x": 27391,
      "y": 14563,
      "ta": "> div.stimulus > div:[2] > svg > g > g:[7] > g:[13] > circle"
    },
    {
      "t": 8800,
      "e": 8800,
      "ty": 2,
      "x": 1185,
      "y": 893
    },
    {
      "t": 10000,
      "e": 10000,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 11000,
      "e": 11000,
      "ty": 2,
      "x": 1132,
      "y": 902
    },
    {
      "t": 11001,
      "e": 11001,
      "ty": 41,
      "x": 24382,
      "y": 54719,
      "ta": "> div.stimulus > div:[2] > svg"
    },
    {
      "t": 11100,
      "e": 11100,
      "ty": 2,
      "x": 928,
      "y": 907
    },
    {
      "t": 11200,
      "e": 11200,
      "ty": 2,
      "x": 768,
      "y": 889
    },
    {
      "t": 11251,
      "e": 11251,
      "ty": 41,
      "x": 54845,
      "y": 43597,
      "ta": "> div.stimulus > div"
    },
    {
      "t": 11300,
      "e": 11300,
      "ty": 2,
      "x": 532,
      "y": 713
    },
    {
      "t": 11400,
      "e": 11400,
      "ty": 2,
      "x": 514,
      "y": 660
    },
    {
      "t": 11500,
      "e": 11500,
      "ty": 2,
      "x": 473,
      "y": 632
    },
    {
      "t": 11500,
      "e": 11500,
      "ty": 41,
      "x": 42255,
      "y": 34567,
      "ta": "> div.stimulus > div"
    },
    {
      "t": 11538,
      "e": 11538,
      "ty": 6,
      "x": 424,
      "y": 593,
      "ta": "#strategyAnswer"
    },
    {
      "t": 11600,
      "e": 11600,
      "ty": 2,
      "x": 385,
      "y": 561
    },
    {
      "t": 11685,
      "e": 11685,
      "ty": 3,
      "x": 372,
      "y": 544,
      "ta": "#strategyAnswer"
    },
    {
      "t": 11685,
      "e": 11685,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 11700,
      "e": 11700,
      "ty": 2,
      "x": 372,
      "y": 544
    },
    {
      "t": 11750,
      "e": 11750,
      "ty": 41,
      "x": 30902,
      "y": 17205,
      "ta": "#strategyAnswer"
    },
    {
      "t": 11756,
      "e": 11756,
      "ty": 4,
      "x": 30902,
      "y": 17205,
      "ta": "#strategyAnswer"
    },
    {
      "t": 11757,
      "e": 11757,
      "ty": 5,
      "x": 372,
      "y": 544,
      "ta": "#strategyAnswer"
    },
    {
      "t": 11990,
      "e": 11990,
      "ty": 7,
      "x": 816,
      "y": 539,
      "ta": "#strategyAnswer"
    },
    {
      "t": 12000,
      "e": 12000,
      "ty": 2,
      "x": 816,
      "y": 539
    },
    {
      "t": 12001,
      "e": 12001,
      "ty": 41,
      "x": 19711,
      "y": 9380,
      "ta": "> div.stimulus > div:[2] > svg > g > g:[4] > g:[14] > text"
    },
    {
      "t": 12100,
      "e": 12100,
      "ty": 2,
      "x": 1029,
      "y": 534
    },
    {
      "t": 12251,
      "e": 12251,
      "ty": 41,
      "x": 17124,
      "y": 28362,
      "ta": "> div.stimulus > div:[2] > svg"
    },
    {
      "t": 15688,
      "e": 15688,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "70"
    },
    {
      "t": 15688,
      "e": 15688,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 15758,
      "e": 15758,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "f"
    },
    {
      "t": 15822,
      "e": 15822,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "73"
    },
    {
      "t": 15822,
      "e": 15822,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 15902,
      "e": 15902,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "78"
    },
    {
      "t": 15902,
      "e": 15902,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 15943,
      "e": 15943,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "fin"
    },
    {
      "t": 15983,
      "e": 15983,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "fin"
    },
    {
      "t": 16015,
      "e": 16015,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "68"
    },
    {
      "t": 16015,
      "e": 16015,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 16086,
      "e": 16086,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "find"
    },
    {
      "t": 16102,
      "e": 16102,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 16103,
      "e": 16103,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 16207,
      "e": 16207,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "find "
    },
    {
      "t": 16229,
      "e": 16229,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 16238,
      "e": 16238,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 16238,
      "e": 16238,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 16309,
      "e": 16309,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 16326,
      "e": 16326,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "72"
    },
    {
      "t": 16326,
      "e": 16326,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 16430,
      "e": 16430,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||h"
    },
    {
      "t": 16438,
      "e": 16438,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 16439,
      "e": 16439,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 16502,
      "e": 16502,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||e"
    },
    {
      "t": 16534,
      "e": 16534,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 16535,
      "e": 16535,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 16590,
      "e": 16590,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 16791,
      "e": 16791,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 17290,
      "e": 17290,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 17324,
      "e": 17324,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 17357,
      "e": 17357,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 17389,
      "e": 17389,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 17422,
      "e": 17422,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 17455,
      "e": 17455,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 17488,
      "e": 17488,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 17521,
      "e": 17521,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 17554,
      "e": 17554,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 17587,
      "e": 17587,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 17620,
      "e": 17620,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 17654,
      "e": 17654,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 17687,
      "e": 17687,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 17720,
      "e": 17720,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 17753,
      "e": 17753,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 17786,
      "e": 17786,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 17819,
      "e": 17819,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 17851,
      "e": 17851,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 17879,
      "e": 17879,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": ""
    },
    {
      "t": 18263,
      "e": 18263,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "16"
    },
    {
      "t": 18422,
      "e": 18422,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "70"
    },
    {
      "t": 18423,
      "e": 18423,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 18463,
      "e": 18463,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "F"
    },
    {
      "t": 18526,
      "e": 18526,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "F"
    },
    {
      "t": 18679,
      "e": 18679,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "73"
    },
    {
      "t": 18680,
      "e": 18680,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 18750,
      "e": 18750,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "78"
    },
    {
      "t": 18751,
      "e": 18751,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 18758,
      "e": 18758,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Fin"
    },
    {
      "t": 18838,
      "e": 18838,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Fin"
    },
    {
      "t": 18886,
      "e": 18886,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "68"
    },
    {
      "t": 18887,
      "e": 18887,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 18942,
      "e": 18942,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Find"
    },
    {
      "t": 19014,
      "e": 19014,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 19014,
      "e": 19014,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 19127,
      "e": 19127,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 19479,
      "e": 19479,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "49"
    },
    {
      "t": 19480,
      "e": 19480,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 19550,
      "e": 19550,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "50"
    },
    {
      "t": 19550,
      "e": 19550,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 19582,
      "e": 19582,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||12"
    },
    {
      "t": 19607,
      "e": 19607,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 19966,
      "e": 19966,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "80"
    },
    {
      "t": 19968,
      "e": 19968,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 20006,
      "e": 20006,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 20102,
      "e": 20102,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||p"
    },
    {
      "t": 20126,
      "e": 20126,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "188"
    },
    {
      "t": 20126,
      "e": 20126,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 20254,
      "e": 20254,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||,"
    },
    {
      "t": 20327,
      "e": 20327,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 20327,
      "e": 20327,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 20422,
      "e": 20422,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 20438,
      "e": 20438,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "80"
    },
    {
      "t": 20438,
      "e": 20438,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 20575,
      "e": 20575,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||p"
    },
    {
      "t": 20591,
      "e": 20591,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "77"
    },
    {
      "t": 20593,
      "e": 20593,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 20670,
      "e": 20670,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||m"
    },
    {
      "t": 20670,
      "e": 20670,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 20670,
      "e": 20670,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 20766,
      "e": 20766,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 21031,
      "e": 21031,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 21054,
      "e": 21054,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Find 12p, pm"
    },
    {
      "t": 21158,
      "e": 21158,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 21206,
      "e": 21206,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Find 12p, p"
    },
    {
      "t": 21319,
      "e": 21319,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 21366,
      "e": 21366,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Find 12p, "
    },
    {
      "t": 21478,
      "e": 21478,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 21527,
      "e": 21527,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Find 12p,"
    },
    {
      "t": 21615,
      "e": 21615,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 21678,
      "e": 21678,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Find 12p"
    },
    {
      "t": 21808,
      "e": 21808,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Find 12p"
    },
    {
      "t": 22456,
      "e": 22456,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "77"
    },
    {
      "t": 22457,
      "e": 22457,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 22559,
      "e": 22559,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||m"
    },
    {
      "t": 22654,
      "e": 22654,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 22655,
      "e": 22655,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 22809,
      "e": 22809,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Find 12pm "
    },
    {
      "t": 22814,
      "e": 22814,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 23662,
      "e": 23662,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "79"
    },
    {
      "t": 23664,
      "e": 23664,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 23750,
      "e": 23750,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||o"
    },
    {
      "t": 24071,
      "e": 24071,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "78"
    },
    {
      "t": 24072,
      "e": 24072,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 24182,
      "e": 24182,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||n"
    },
    {
      "t": 24335,
      "e": 24335,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 24335,
      "e": 24335,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 24414,
      "e": 24414,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 24951,
      "e": 24951,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 24952,
      "e": 24952,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 24998,
      "e": 24998,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 25070,
      "e": 25070,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "72"
    },
    {
      "t": 25071,
      "e": 25071,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 25150,
      "e": 25150,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||h"
    },
    {
      "t": 25463,
      "e": 25463,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 25464,
      "e": 25464,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 25502,
      "e": 25502,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||e"
    },
    {
      "t": 25609,
      "e": 25609,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Find 12pm on the"
    },
    {
      "t": 25743,
      "e": 25743,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 25744,
      "e": 25744,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 25806,
      "e": 25806,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 27839,
      "e": 27839,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "88"
    },
    {
      "t": 27839,
      "e": 27839,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 27935,
      "e": 27935,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||x"
    },
    {
      "t": 28478,
      "e": 28478,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "189"
    },
    {
      "t": 28478,
      "e": 28478,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 28543,
      "e": 28543,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||-"
    },
    {
      "t": 29038,
      "e": 29038,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 29038,
      "e": 29038,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 29158,
      "e": 29158,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||a"
    },
    {
      "t": 29527,
      "e": 29527,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "88"
    },
    {
      "t": 29528,
      "e": 29528,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 29606,
      "e": 29606,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||x"
    },
    {
      "t": 30007,
      "e": 30007,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "73"
    },
    {
      "t": 30008,
      "e": 30008,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 30009,
      "e": 30009,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 30078,
      "e": 30078,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||i"
    },
    {
      "t": 30503,
      "e": 30503,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "83"
    },
    {
      "t": 30503,
      "e": 30503,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 30550,
      "e": 30550,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||s"
    },
    {
      "t": 30622,
      "e": 30622,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "190"
    },
    {
      "t": 30622,
      "e": 30622,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 30710,
      "e": 30710,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 30711,
      "e": 30711,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 30718,
      "e": 30718,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||. "
    },
    {
      "t": 30782,
      "e": 30782,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 31389,
      "e": 31389,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "16"
    },
    {
      "t": 31759,
      "e": 31759,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "76"
    },
    {
      "t": 31759,
      "e": 31759,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 31870,
      "e": 31870,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||L"
    },
    {
      "t": 32047,
      "e": 32047,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 32399,
      "e": 32399,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "79"
    },
    {
      "t": 32400,
      "e": 32400,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 32439,
      "e": 32439,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||o"
    },
    {
      "t": 32583,
      "e": 32583,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "79"
    },
    {
      "t": 32584,
      "e": 32584,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 32734,
      "e": 32734,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||o"
    },
    {
      "t": 32790,
      "e": 32790,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "75"
    },
    {
      "t": 32790,
      "e": 32790,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 32869,
      "e": 32869,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||k"
    },
    {
      "t": 33422,
      "e": 33422,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 33461,
      "e": 33461,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Find 12pm on the x-axis. Loo"
    },
    {
      "t": 33590,
      "e": 33590,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 33622,
      "e": 33622,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Find 12pm on the x-axis. Lo"
    },
    {
      "t": 33711,
      "e": 33711,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 33766,
      "e": 33766,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Find 12pm on the x-axis. L"
    },
    {
      "t": 34166,
      "e": 34166,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 34221,
      "e": 34221,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Find 12pm on the x-axis. "
    },
    {
      "t": 34439,
      "e": 34439,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "16"
    },
    {
      "t": 34575,
      "e": 34575,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 34575,
      "e": 34575,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 34670,
      "e": 34670,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||T"
    },
    {
      "t": 34702,
      "e": 34702,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 34798,
      "e": 34798,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "72"
    },
    {
      "t": 34799,
      "e": 34799,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 34863,
      "e": 34863,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||h"
    },
    {
      "t": 34902,
      "e": 34902,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 34903,
      "e": 34903,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 34950,
      "e": 34950,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||e"
    },
    {
      "t": 35046,
      "e": 35046,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 35094,
      "e": 35094,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Find 12pm on the x-axis. Th"
    },
    {
      "t": 35198,
      "e": 35198,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 35246,
      "e": 35246,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Find 12pm on the x-axis. T"
    },
    {
      "t": 35351,
      "e": 35351,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 35390,
      "e": 35390,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Find 12pm on the x-axis. "
    },
    {
      "t": 36238,
      "e": 36238,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "16"
    },
    {
      "t": 36415,
      "e": 36415,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 36415,
      "e": 36415,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 36462,
      "e": 36462,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||T"
    },
    {
      "t": 36509,
      "e": 36509,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 36647,
      "e": 36647,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "72"
    },
    {
      "t": 36648,
      "e": 36648,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 36742,
      "e": 36742,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||h"
    },
    {
      "t": 36750,
      "e": 36750,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 36750,
      "e": 36750,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 36806,
      "e": 36806,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||e"
    },
    {
      "t": 36854,
      "e": 36854,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 36854,
      "e": 36854,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 36950,
      "e": 36950,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 36958,
      "e": 36958,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "80"
    },
    {
      "t": 36960,
      "e": 36960,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 37078,
      "e": 37078,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "79"
    },
    {
      "t": 37079,
      "e": 37079,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 37134,
      "e": 37134,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||po"
    },
    {
      "t": 37190,
      "e": 37190,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 37311,
      "e": 37311,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "73"
    },
    {
      "t": 37311,
      "e": 37311,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 37421,
      "e": 37421,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "78"
    },
    {
      "t": 37422,
      "e": 37422,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 37438,
      "e": 37438,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||in"
    },
    {
      "t": 37543,
      "e": 37543,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 37559,
      "e": 37559,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 37560,
      "e": 37560,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 37613,
      "e": 37613,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 37694,
      "e": 37694,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 37694,
      "e": 37694,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 37792,
      "e": 37792,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 37862,
      "e": 37862,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "72"
    },
    {
      "t": 37862,
      "e": 37862,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 37950,
      "e": 37950,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 37950,
      "e": 37950,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 37973,
      "e": 37973,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||ha"
    },
    {
      "t": 38054,
      "e": 38054,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "83"
    },
    {
      "t": 38055,
      "e": 38055,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 38078,
      "e": 38078,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||s"
    },
    {
      "t": 38174,
      "e": 38174,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 38279,
      "e": 38279,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 38279,
      "e": 38279,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 38391,
      "e": 38391,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 38430,
      "e": 38430,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 38431,
      "e": 38431,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 38510,
      "e": 38510,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 38638,
      "e": 38638,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "87"
    },
    {
      "t": 38638,
      "e": 38638,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 38718,
      "e": 38718,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||w"
    },
    {
      "t": 38751,
      "e": 38751,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "79"
    },
    {
      "t": 38752,
      "e": 38752,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 38862,
      "e": 38862,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 38862,
      "e": 38862,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 38878,
      "e": 38878,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||o "
    },
    {
      "t": 38975,
      "e": 38975,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 39143,
      "e": 39143,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "68"
    },
    {
      "t": 39143,
      "e": 39143,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 39222,
      "e": 39143,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||d"
    },
    {
      "t": 39262,
      "e": 39183,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "73"
    },
    {
      "t": 39262,
      "e": 39183,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 39358,
      "e": 39279,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||i"
    },
    {
      "t": 39446,
      "e": 39367,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 39446,
      "e": 39367,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 39543,
      "e": 39464,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||a"
    },
    {
      "t": 39615,
      "e": 39536,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "71"
    },
    {
      "t": 39615,
      "e": 39536,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 39694,
      "e": 39615,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||g"
    },
    {
      "t": 39734,
      "e": 39655,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "79"
    },
    {
      "t": 39734,
      "e": 39655,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 39798,
      "e": 39719,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||o"
    },
    {
      "t": 39927,
      "e": 39848,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "78"
    },
    {
      "t": 39928,
      "e": 39849,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 40014,
      "e": 39935,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||n"
    },
    {
      "t": 40046,
      "e": 39967,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 40047,
      "e": 39968,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 40150,
      "e": 40071,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||a"
    },
    {
      "t": 40158,
      "e": 40079,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "76"
    },
    {
      "t": 40159,
      "e": 40080,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 40270,
      "e": 40191,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||l"
    },
    {
      "t": 40366,
      "e": 40287,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "83"
    },
    {
      "t": 40367,
      "e": 40288,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 40445,
      "e": 40366,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||s"
    },
    {
      "t": 41782,
      "e": 41703,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 41783,
      "e": 41704,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 41966,
      "e": 41887,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 42175,
      "e": 42096,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 42175,
      "e": 42096,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 42245,
      "e": 42166,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 42270,
      "e": 42191,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "72"
    },
    {
      "t": 42270,
      "e": 42191,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 42366,
      "e": 42287,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||h"
    },
    {
      "t": 42415,
      "e": 42336,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 42415,
      "e": 42336,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 42494,
      "e": 42415,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||e"
    },
    {
      "t": 42609,
      "e": 42530,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Find 12pm on the x-axis. The point has two diagonals the"
    },
    {
      "t": 42766,
      "e": 42687,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 42798,
      "e": 42719,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Find 12pm on the x-axis. The point has two diagonals th"
    },
    {
      "t": 42894,
      "e": 42815,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 42949,
      "e": 42870,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Find 12pm on the x-axis. The point has two diagonals t"
    },
    {
      "t": 43670,
      "e": 43591,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "72"
    },
    {
      "t": 43671,
      "e": 43592,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 43781,
      "e": 43702,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||h"
    },
    {
      "t": 43854,
      "e": 43775,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 43855,
      "e": 43776,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 43958,
      "e": 43879,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 43958,
      "e": 43879,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 43974,
      "e": 43895,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||at"
    },
    {
      "t": 44030,
      "e": 43951,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 44159,
      "e": 44080,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 44159,
      "e": 44080,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 44255,
      "e": 44176,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 44390,
      "e": 44311,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "83"
    },
    {
      "t": 44391,
      "e": 44312,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 44494,
      "e": 44415,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||s"
    },
    {
      "t": 44526,
      "e": 44447,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 44526,
      "e": 44447,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 44639,
      "e": 44560,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 44647,
      "e": 44568,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 44647,
      "e": 44568,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 44725,
      "e": 44646,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||e"
    },
    {
      "t": 44758,
      "e": 44679,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "77"
    },
    {
      "t": 44758,
      "e": 44679,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 44846,
      "e": 44767,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 44846,
      "e": 44767,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 44894,
      "e": 44815,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||m "
    },
    {
      "t": 44967,
      "e": 44888,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "70"
    },
    {
      "t": 44967,
      "e": 44888,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 44973,
      "e": 44894,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||f"
    },
    {
      "t": 45029,
      "e": 44950,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "82"
    },
    {
      "t": 45030,
      "e": 44951,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 45078,
      "e": 44999,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||r"
    },
    {
      "t": 45133,
      "e": 45054,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "79"
    },
    {
      "t": 45134,
      "e": 45055,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 45150,
      "e": 45071,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||o"
    },
    {
      "t": 45206,
      "e": 45127,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "77"
    },
    {
      "t": 45207,
      "e": 45128,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 45246,
      "e": 45167,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||m"
    },
    {
      "t": 45334,
      "e": 45255,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 45334,
      "e": 45255,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 45342,
      "e": 45263,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 45414,
      "e": 45335,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 45454,
      "e": 45375,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "73"
    },
    {
      "t": 45455,
      "e": 45376,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 45565,
      "e": 45486,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||i"
    },
    {
      "t": 45614,
      "e": 45535,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 45614,
      "e": 45535,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 45662,
      "e": 45583,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 45735,
      "e": 45656,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "190"
    },
    {
      "t": 45736,
      "e": 45657,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 45814,
      "e": 45735,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 45816,
      "e": 45737,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 45862,
      "e": 45783,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||. "
    },
    {
      "t": 45910,
      "e": 45831,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 49038,
      "e": 48959,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "16"
    },
    {
      "t": 49537,
      "e": 49458,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "16"
    },
    {
      "t": 49571,
      "e": 49492,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "16"
    },
    {
      "t": 49604,
      "e": 49525,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "16"
    },
    {
      "t": 49636,
      "e": 49557,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "16"
    },
    {
      "t": 49670,
      "e": 49591,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "16"
    },
    {
      "t": 49703,
      "e": 49624,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "16"
    },
    {
      "t": 49736,
      "e": 49657,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "16"
    },
    {
      "t": 49769,
      "e": 49690,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "16"
    },
    {
      "t": 49802,
      "e": 49723,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "16"
    },
    {
      "t": 49835,
      "e": 49756,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "16"
    },
    {
      "t": 49868,
      "e": 49789,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "16"
    },
    {
      "t": 49902,
      "e": 49790,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "16"
    },
    {
      "t": 49933,
      "e": 49821,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "16"
    },
    {
      "t": 49966,
      "e": 49854,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "16"
    },
    {
      "t": 49999,
      "e": 49887,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "16"
    },
    {
      "t": 50032,
      "e": 49920,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "16"
    },
    {
      "t": 50065,
      "e": 49953,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "16"
    },
    {
      "t": 50098,
      "e": 49986,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "16"
    },
    {
      "t": 50132,
      "e": 50020,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "16"
    },
    {
      "t": 50165,
      "e": 50053,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "16"
    },
    {
      "t": 50198,
      "e": 50086,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "16"
    },
    {
      "t": 50231,
      "e": 50119,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "76"
    },
    {
      "t": 50231,
      "e": 50119,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 50326,
      "e": 50214,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||L"
    },
    {
      "t": 50382,
      "e": 50270,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 50574,
      "e": 50462,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "79"
    },
    {
      "t": 50576,
      "e": 50464,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 50653,
      "e": 50541,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||o"
    },
    {
      "t": 50701,
      "e": 50589,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "79"
    },
    {
      "t": 50702,
      "e": 50590,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 50806,
      "e": 50694,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||o"
    },
    {
      "t": 51190,
      "e": 51078,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "75"
    },
    {
      "t": 51191,
      "e": 51079,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 51270,
      "e": 51158,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||k"
    },
    {
      "t": 51494,
      "e": 51382,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 51495,
      "e": 51383,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 51611,
      "e": 51499,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Find 12pm on the x-axis. The point has two diagonals that stem from it. Look "
    },
    {
      "t": 51631,
      "e": 51519,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 51710,
      "e": 51598,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 51711,
      "e": 51599,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 51813,
      "e": 51701,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 51814,
      "e": 51702,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 51845,
      "e": 51733,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||at"
    },
    {
      "t": 51926,
      "e": 51814,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 51999,
      "e": 51887,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 51999,
      "e": 51887,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 52142,
      "e": 52030,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 52214,
      "e": 52102,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 52215,
      "e": 52103,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 52278,
      "e": 52166,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 52318,
      "e": 52206,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "72"
    },
    {
      "t": 52318,
      "e": 52206,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 52398,
      "e": 52286,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||h"
    },
    {
      "t": 52510,
      "e": 52398,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 52512,
      "e": 52400,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 52589,
      "e": 52477,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||e"
    },
    {
      "t": 52710,
      "e": 52598,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 52710,
      "e": 52598,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 52814,
      "e": 52702,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 53359,
      "e": 53247,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "68"
    },
    {
      "t": 53360,
      "e": 53248,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 53470,
      "e": 53358,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||d"
    },
    {
      "t": 53558,
      "e": 53446,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "73"
    },
    {
      "t": 53558,
      "e": 53446,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 53653,
      "e": 53541,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||i"
    },
    {
      "t": 53750,
      "e": 53638,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 53750,
      "e": 53638,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 53853,
      "e": 53741,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||a"
    },
    {
      "t": 53958,
      "e": 53846,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "71"
    },
    {
      "t": 53959,
      "e": 53847,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 54013,
      "e": 53901,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||g"
    },
    {
      "t": 54142,
      "e": 54030,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "79"
    },
    {
      "t": 54143,
      "e": 54031,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 54249,
      "e": 54137,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "78"
    },
    {
      "t": 54250,
      "e": 54138,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 54261,
      "e": 54149,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||on"
    },
    {
      "t": 54349,
      "e": 54237,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 54389,
      "e": 54277,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 54389,
      "e": 54277,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 54486,
      "e": 54374,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||a"
    },
    {
      "t": 54510,
      "e": 54398,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "76"
    },
    {
      "t": 54510,
      "e": 54398,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 54597,
      "e": 54485,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 54598,
      "e": 54486,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 54646,
      "e": 54534,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||l "
    },
    {
      "t": 54702,
      "e": 54590,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 55054,
      "e": 54942,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "83"
    },
    {
      "t": 55055,
      "e": 54943,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 55182,
      "e": 55070,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 55182,
      "e": 55070,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 55221,
      "e": 55109,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||st"
    },
    {
      "t": 55317,
      "e": 55205,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 55334,
      "e": 55222,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 55334,
      "e": 55222,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 55405,
      "e": 55293,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||e"
    },
    {
      "t": 55502,
      "e": 55390,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "77"
    },
    {
      "t": 55503,
      "e": 55391,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 55557,
      "e": 55445,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||m"
    },
    {
      "t": 55654,
      "e": 55542,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "77"
    },
    {
      "t": 55656,
      "e": 55544,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 55702,
      "e": 55590,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||m"
    },
    {
      "t": 55806,
      "e": 55694,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "73"
    },
    {
      "t": 55807,
      "e": 55695,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 55869,
      "e": 55757,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "78"
    },
    {
      "t": 55869,
      "e": 55757,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 55886,
      "e": 55774,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||in"
    },
    {
      "t": 55974,
      "e": 55862,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 56022,
      "e": 55910,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "71"
    },
    {
      "t": 56022,
      "e": 55910,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 56062,
      "e": 55950,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||g"
    },
    {
      "t": 56150,
      "e": 56038,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 56152,
      "e": 56040,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 56262,
      "e": 56150,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 56278,
      "e": 56166,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "70"
    },
    {
      "t": 56278,
      "e": 56166,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 56390,
      "e": 56278,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "82"
    },
    {
      "t": 56391,
      "e": 56279,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 56413,
      "e": 56301,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||fr"
    },
    {
      "t": 56478,
      "e": 56366,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "79"
    },
    {
      "t": 56478,
      "e": 56366,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 56502,
      "e": 56390,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||o"
    },
    {
      "t": 56541,
      "e": 56429,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "77"
    },
    {
      "t": 56542,
      "e": 56430,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 56597,
      "e": 56485,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||m"
    },
    {
      "t": 56646,
      "e": 56534,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 56647,
      "e": 56535,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 56670,
      "e": 56558,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 56742,
      "e": 56630,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 57213,
      "e": 57101,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "49"
    },
    {
      "t": 57213,
      "e": 57101,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 57277,
      "e": 57165,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||1"
    },
    {
      "t": 57390,
      "e": 57278,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "50"
    },
    {
      "t": 57392,
      "e": 57279,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 57486,
      "e": 57373,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||2"
    },
    {
      "t": 57686,
      "e": 57573,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "80"
    },
    {
      "t": 57686,
      "e": 57573,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 57807,
      "e": 57694,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Find 12pm on the x-axis. The point has two diagonals that stem from it. Look at the diagonal stemming from 12p"
    },
    {
      "t": 57822,
      "e": 57709,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||p"
    },
    {
      "t": 57822,
      "e": 57709,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "77"
    },
    {
      "t": 57822,
      "e": 57709,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 57926,
      "e": 57813,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 57927,
      "e": 57814,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 57934,
      "e": 57821,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||m "
    },
    {
      "t": 58053,
      "e": 57940,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 58430,
      "e": 58317,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 58431,
      "e": 58318,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 58494,
      "e": 58381,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 58606,
      "e": 58493,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "72"
    },
    {
      "t": 58606,
      "e": 58493,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 58741,
      "e": 58628,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||h"
    },
    {
      "t": 58742,
      "e": 58629,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 58742,
      "e": 58629,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 58805,
      "e": 58692,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 58806,
      "e": 58693,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 58854,
      "e": 58741,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||at"
    },
    {
      "t": 58902,
      "e": 58789,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 58966,
      "e": 58853,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 58966,
      "e": 58853,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 59078,
      "e": 58965,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 59294,
      "e": 59181,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "80"
    },
    {
      "t": 59296,
      "e": 59183,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 59405,
      "e": 59292,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "79"
    },
    {
      "t": 59405,
      "e": 59292,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 59430,
      "e": 59317,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||po"
    },
    {
      "t": 59510,
      "e": 59397,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 59647,
      "e": 59534,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "73"
    },
    {
      "t": 59647,
      "e": 59534,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 59741,
      "e": 59628,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "78"
    },
    {
      "t": 59741,
      "e": 59628,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 59781,
      "e": 59668,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||in"
    },
    {
      "t": 59838,
      "e": 59725,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 59854,
      "e": 59741,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 59855,
      "e": 59742,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 59958,
      "e": 59845,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "83"
    },
    {
      "t": 59958,
      "e": 59845,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 59981,
      "e": 59868,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||ts"
    },
    {
      "t": 60029,
      "e": 59916,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 60030,
      "e": 59917,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 60061,
      "e": 59948,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 60117,
      "e": 60004,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 60149,
      "e": 60036,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 60149,
      "e": 60036,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 60221,
      "e": 60108,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "79"
    },
    {
      "t": 60222,
      "e": 60109,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 60237,
      "e": 60124,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||to"
    },
    {
      "t": 60318,
      "e": 60205,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 60318,
      "e": 60205,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 60334,
      "e": 60221,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 60381,
      "e": 60268,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 60382,
      "e": 60269,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 60421,
      "e": 60308,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 60485,
      "e": 60372,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 60517,
      "e": 60404,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "72"
    },
    {
      "t": 60518,
      "e": 60405,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 60614,
      "e": 60501,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||h"
    },
    {
      "t": 60622,
      "e": 60509,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 60623,
      "e": 60510,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 60685,
      "e": 60572,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||e"
    },
    {
      "t": 60718,
      "e": 60605,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 60718,
      "e": 60605,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 60789,
      "e": 60676,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "82"
    },
    {
      "t": 60790,
      "e": 60677,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 60806,
      "e": 60693,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| r"
    },
    {
      "t": 60886,
      "e": 60773,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 60902,
      "e": 60789,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "73"
    },
    {
      "t": 60902,
      "e": 60789,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 61005,
      "e": 60892,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "71"
    },
    {
      "t": 61006,
      "e": 60893,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 61021,
      "e": 60908,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||ig"
    },
    {
      "t": 61069,
      "e": 60956,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 61134,
      "e": 61021,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "72"
    },
    {
      "t": 61135,
      "e": 61022,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 61214,
      "e": 61101,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||h"
    },
    {
      "t": 61215,
      "e": 61102,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 61215,
      "e": 61102,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 61246,
      "e": 61133,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 61375,
      "e": 61262,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "190"
    },
    {
      "t": 61376,
      "e": 61263,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 61438,
      "e": 61325,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 61438,
      "e": 61325,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 61485,
      "e": 61372,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||. "
    },
    {
      "t": 61517,
      "e": 61404,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 65095,
      "e": 64982,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "16"
    },
    {
      "t": 65190,
      "e": 65077,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 65191,
      "e": 65078,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 65262,
      "e": 65149,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||A"
    },
    {
      "t": 65302,
      "e": 65189,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 65470,
      "e": 65357,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "83"
    },
    {
      "t": 65471,
      "e": 65358,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 65533,
      "e": 65420,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||s"
    },
    {
      "t": 65558,
      "e": 65445,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 65558,
      "e": 65445,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 65630,
      "e": 65517,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 65686,
      "e": 65573,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "89"
    },
    {
      "t": 65686,
      "e": 65573,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 65790,
      "e": 65677,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||y"
    },
    {
      "t": 65854,
      "e": 65741,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "79"
    },
    {
      "t": 65855,
      "e": 65742,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 65933,
      "e": 65820,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "85"
    },
    {
      "t": 65933,
      "e": 65820,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 66038,
      "e": 65925,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||ou"
    },
    {
      "t": 66046,
      "e": 65933,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 66046,
      "e": 65933,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 66077,
      "e": 65964,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 66158,
      "e": 66045,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 66245,
      "e": 66132,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "77"
    },
    {
      "t": 66246,
      "e": 66133,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 66349,
      "e": 66236,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||m"
    },
    {
      "t": 66366,
      "e": 66253,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "79"
    },
    {
      "t": 66366,
      "e": 66253,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 66454,
      "e": 66341,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||o"
    },
    {
      "t": 66527,
      "e": 66342,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "86"
    },
    {
      "t": 66529,
      "e": 66344,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 66597,
      "e": 66412,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||v"
    },
    {
      "t": 66710,
      "e": 66525,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 66710,
      "e": 66525,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 66781,
      "e": 66596,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||e"
    },
    {
      "t": 66797,
      "e": 66612,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 66797,
      "e": 66612,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 66925,
      "e": 66740,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "85"
    },
    {
      "t": 66926,
      "e": 66741,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 66949,
      "e": 66764,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| u"
    },
    {
      "t": 67054,
      "e": 66869,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "80"
    },
    {
      "t": 67054,
      "e": 66869,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 67101,
      "e": 66916,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||p"
    },
    {
      "t": 67181,
      "e": 66996,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 67238,
      "e": 67053,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 67238,
      "e": 67053,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 67278,
      "e": 67093,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 67409,
      "e": 67224,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Find 12pm on the x-axis. The point has two diagonals that stem from it. Look at the diagonal stemming from 12pm that points to the right. As you move up "
    },
    {
      "t": 68230,
      "e": 68045,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 68231,
      "e": 68046,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 68293,
      "e": 68108,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 68341,
      "e": 68156,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "72"
    },
    {
      "t": 68341,
      "e": 68156,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 68445,
      "e": 68260,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||h"
    },
    {
      "t": 68447,
      "e": 68262,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 68447,
      "e": 68262,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 68493,
      "e": 68308,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||e"
    },
    {
      "t": 68541,
      "e": 68356,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 68541,
      "e": 68356,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 68637,
      "e": 68452,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 68830,
      "e": 68645,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "68"
    },
    {
      "t": 68830,
      "e": 68645,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 68917,
      "e": 68732,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||d"
    },
    {
      "t": 69045,
      "e": 68860,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "73"
    },
    {
      "t": 69046,
      "e": 68861,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 69149,
      "e": 68964,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||i"
    },
    {
      "t": 69157,
      "e": 68972,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 69157,
      "e": 68972,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 69254,
      "e": 69069,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||a"
    },
    {
      "t": 69534,
      "e": 69349,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "71"
    },
    {
      "t": 69535,
      "e": 69350,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 69581,
      "e": 69396,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||g"
    },
    {
      "t": 69637,
      "e": 69452,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "79"
    },
    {
      "t": 69637,
      "e": 69452,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 69710,
      "e": 69525,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||o"
    },
    {
      "t": 69726,
      "e": 69541,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "78"
    },
    {
      "t": 69726,
      "e": 69541,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 69830,
      "e": 69645,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||n"
    },
    {
      "t": 69869,
      "e": 69684,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 69869,
      "e": 69684,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 69950,
      "e": 69765,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||a"
    },
    {
      "t": 70014,
      "e": 69829,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "76"
    },
    {
      "t": 70014,
      "e": 69829,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 70085,
      "e": 69900,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||l"
    },
    {
      "t": 70209,
      "e": 70024,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Find 12pm on the x-axis. The point has two diagonals that stem from it. Look at the diagonal stemming from 12pm that points to the right. As you move up the diagonal"
    },
    {
      "t": 70222,
      "e": 70037,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "188"
    },
    {
      "t": 70222,
      "e": 70037,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 70310,
      "e": 70125,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 70310,
      "e": 70125,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 70349,
      "e": 70164,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||, "
    },
    {
      "t": 70405,
      "e": 70220,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 70606,
      "e": 70421,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 70607,
      "e": 70422,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 70693,
      "e": 70508,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||a"
    },
    {
      "t": 70733,
      "e": 70548,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "78"
    },
    {
      "t": 70733,
      "e": 70548,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 70813,
      "e": 70628,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||n"
    },
    {
      "t": 70894,
      "e": 70709,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "89"
    },
    {
      "t": 70896,
      "e": 70711,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 71008,
      "e": 70711,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Find 12pm on the x-axis. The point has two diagonals that stem from it. Look at the diagonal stemming from 12pm that points to the right. As you move up the diagonal, any"
    },
    {
      "t": 71013,
      "e": 70716,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||y"
    },
    {
      "t": 71086,
      "e": 70789,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 71086,
      "e": 70789,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 71181,
      "e": 70884,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 71229,
      "e": 70932,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "80"
    },
    {
      "t": 71230,
      "e": 70933,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 71293,
      "e": 70996,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "79"
    },
    {
      "t": 71294,
      "e": 70997,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 71325,
      "e": 71028,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||po"
    },
    {
      "t": 71334,
      "e": 71037,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 72262,
      "e": 71965,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "73"
    },
    {
      "t": 72264,
      "e": 71967,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 72317,
      "e": 72020,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||i"
    },
    {
      "t": 72582,
      "e": 72285,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "78"
    },
    {
      "t": 72583,
      "e": 72286,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 72654,
      "e": 72357,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||n"
    },
    {
      "t": 72765,
      "e": 72468,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 72765,
      "e": 72468,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 72862,
      "e": 72565,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "83"
    },
    {
      "t": 72862,
      "e": 72565,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 72877,
      "e": 72580,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||ts"
    },
    {
      "t": 72974,
      "e": 72677,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 72982,
      "e": 72685,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 72982,
      "e": 72685,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 73069,
      "e": 72772,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 73077,
      "e": 72780,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "79"
    },
    {
      "t": 73077,
      "e": 72780,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 73165,
      "e": 72868,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "78"
    },
    {
      "t": 73165,
      "e": 72868,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 73221,
      "e": 72924,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||on"
    },
    {
      "t": 73277,
      "e": 72980,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 73278,
      "e": 72981,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 73309,
      "e": 73012,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 73406,
      "e": 73109,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 73606,
      "e": 73309,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 73607,
      "e": 73310,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 73677,
      "e": 73380,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 73701,
      "e": 73404,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "72"
    },
    {
      "t": 73702,
      "e": 73405,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 73797,
      "e": 73500,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||h"
    },
    {
      "t": 73830,
      "e": 73533,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 73830,
      "e": 73533,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 73886,
      "e": 73589,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 73887,
      "e": 73590,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 73941,
      "e": 73644,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||at"
    },
    {
      "t": 73973,
      "e": 73676,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 74053,
      "e": 73756,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 74053,
      "e": 73756,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 74149,
      "e": 73852,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 74285,
      "e": 73988,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "76"
    },
    {
      "t": 74285,
      "e": 73988,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 74373,
      "e": 74076,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||l"
    },
    {
      "t": 74446,
      "e": 74149,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "73"
    },
    {
      "t": 74447,
      "e": 74150,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 74541,
      "e": 74244,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "78"
    },
    {
      "t": 74542,
      "e": 74245,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 74558,
      "e": 74261,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||in"
    },
    {
      "t": 74653,
      "e": 74356,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 74973,
      "e": 74676,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 74973,
      "e": 74676,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 75021,
      "e": 74724,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||e"
    },
    {
      "t": 75265,
      "e": 74968,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 75266,
      "e": 74969,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 75369,
      "e": 75072,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 76921,
      "e": 76624,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "72"
    },
    {
      "t": 76923,
      "e": 76626,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 76993,
      "e": 76696,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||h"
    },
    {
      "t": 77050,
      "e": 76753,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 77050,
      "e": 76753,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 77161,
      "e": 76864,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "83"
    },
    {
      "t": 77161,
      "e": 76864,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 77184,
      "e": 76887,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||as"
    },
    {
      "t": 77289,
      "e": 76992,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 77322,
      "e": 77025,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 77322,
      "e": 77025,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 77417,
      "e": 77120,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 77424,
      "e": 77127,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 77425,
      "e": 77128,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 77529,
      "e": 77232,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||a"
    },
    {
      "t": 77537,
      "e": 77240,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 77538,
      "e": 77241,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 77650,
      "e": 77353,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 77954,
      "e": 77657,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "83"
    },
    {
      "t": 77954,
      "e": 77657,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 78025,
      "e": 77728,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||s"
    },
    {
      "t": 78065,
      "e": 77768,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 78065,
      "e": 77768,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 78178,
      "e": 77881,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 78201,
      "e": 77904,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 78202,
      "e": 77905,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 78337,
      "e": 78040,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||a"
    },
    {
      "t": 78345,
      "e": 78048,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "82"
    },
    {
      "t": 78345,
      "e": 78048,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 78434,
      "e": 78137,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||r"
    },
    {
      "t": 78546,
      "e": 78249,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 78546,
      "e": 78249,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 78625,
      "e": 78328,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 78713,
      "e": 78416,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 78714,
      "e": 78417,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 78809,
      "e": 78512,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 78817,
      "e": 78520,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 78817,
      "e": 78520,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 78897,
      "e": 78600,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 78905,
      "e": 78608,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "73"
    },
    {
      "t": 78906,
      "e": 78609,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 78962,
      "e": 78665,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "77"
    },
    {
      "t": 78962,
      "e": 78665,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 78993,
      "e": 78696,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||im"
    },
    {
      "t": 79097,
      "e": 78696,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 79098,
      "e": 78697,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 79145,
      "e": 78744,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||e"
    },
    {
      "t": 79153,
      "e": 78752,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 79193,
      "e": 78792,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 79193,
      "e": 78792,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 79305,
      "e": 78904,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 79321,
      "e": 78920,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "79"
    },
    {
      "t": 79321,
      "e": 78920,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 79449,
      "e": 79048,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||o"
    },
    {
      "t": 79770,
      "e": 79369,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "70"
    },
    {
      "t": 79770,
      "e": 79369,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 79825,
      "e": 79424,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||f"
    },
    {
      "t": 80105,
      "e": 79704,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 80105,
      "e": 79704,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 80161,
      "e": 79760,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 80361,
      "e": 79960,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "49"
    },
    {
      "t": 80363,
      "e": 79962,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 80408,
      "e": 80007,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "50"
    },
    {
      "t": 80409,
      "e": 80008,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 80441,
      "e": 80040,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||12"
    },
    {
      "t": 80497,
      "e": 80096,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 80691,
      "e": 80290,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "80"
    },
    {
      "t": 80691,
      "e": 80290,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 80744,
      "e": 80343,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "77"
    },
    {
      "t": 80744,
      "e": 80343,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 80760,
      "e": 80359,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||pm"
    },
    {
      "t": 80817,
      "e": 80416,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 80938,
      "e": 80537,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "191"
    },
    {
      "t": 80938,
      "e": 80537,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 80993,
      "e": 80592,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||/"
    },
    {
      "t": 81794,
      "e": 81393,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 81849,
      "e": 81448,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Find 12pm on the x-axis. The point has two diagonals that stem from it. Look at the diagonal stemming from 12pm that points to the right. As you move up the diagonal, any points on that line has a start time of 12pm"
    },
    {
      "t": 82145,
      "e": 81744,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "190"
    },
    {
      "t": 82147,
      "e": 81746,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 82210,
      "e": 81809,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||."
    },
    {
      "t": 83011,
      "e": 82610,
      "ty": 2,
      "x": 741,
      "y": 768
    },
    {
      "t": 83011,
      "e": 82610,
      "ty": 41,
      "x": 3495,
      "y": 44731,
      "ta": "> div.stimulus > div:[2]"
    },
    {
      "t": 83110,
      "e": 82709,
      "ty": 2,
      "x": 741,
      "y": 774
    },
    {
      "t": 83210,
      "e": 82809,
      "ty": 2,
      "x": 732,
      "y": 762
    },
    {
      "t": 83261,
      "e": 82860,
      "ty": 41,
      "x": 2979,
      "y": 44305,
      "ta": "> div.stimulus > div:[2]"
    },
    {
      "t": 83511,
      "e": 83110,
      "ty": 2,
      "x": 635,
      "y": 712
    },
    {
      "t": 83511,
      "e": 83110,
      "ty": 41,
      "x": 60466,
      "y": 38999,
      "ta": "> div.stimulus > div"
    },
    {
      "t": 83611,
      "e": 83210,
      "ty": 2,
      "x": 568,
      "y": 684
    },
    {
      "t": 83711,
      "e": 83310,
      "ty": 2,
      "x": 507,
      "y": 681
    },
    {
      "t": 83740,
      "e": 83339,
      "ty": 6,
      "x": 451,
      "y": 675,
      "ta": "#strategyButton"
    },
    {
      "t": 83761,
      "e": 83360,
      "ty": 41,
      "x": 49919,
      "y": 31351,
      "ta": "#strategyButton"
    },
    {
      "t": 83810,
      "e": 83409,
      "ty": 2,
      "x": 411,
      "y": 667
    },
    {
      "t": 83910,
      "e": 83509,
      "ty": 2,
      "x": 406,
      "y": 673
    },
    {
      "t": 84011,
      "e": 83610,
      "ty": 2,
      "x": 404,
      "y": 675
    },
    {
      "t": 84012,
      "e": 83611,
      "ty": 41,
      "x": 35719,
      "y": 39061,
      "ta": "#strategyButton"
    },
    {
      "t": 84150,
      "e": 83749,
      "ty": 3,
      "x": 404,
      "y": 675,
      "ta": "#strategyButton"
    },
    {
      "t": 84152,
      "e": 83751,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Find 12pm on the x-axis. The point has two diagonals that stem from it. Look at the diagonal stemming from 12pm that points to the right. As you move up the diagonal, any points on that line has a start time of 12pm."
    },
    {
      "t": 84153,
      "e": 83752,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 84153,
      "e": 83752,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#strategyButton"
    },
    {
      "t": 84230,
      "e": 83829,
      "ty": 4,
      "x": 35719,
      "y": 39061,
      "ta": "#strategyButton"
    },
    {
      "t": 84246,
      "e": 83845,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#strategyButton"
    },
    {
      "t": 84247,
      "e": 83846,
      "ty": 5,
      "x": 404,
      "y": 675,
      "ta": "#strategyButton"
    },
    {
      "t": 84253,
      "e": 83852,
      "ty": 38,
      "x": 1,
      "y": 0
    },
    {
      "t": 84511,
      "e": 84110,
      "ty": 2,
      "x": 491,
      "y": 756
    },
    {
      "t": 84511,
      "e": 84110,
      "ty": 41,
      "x": 16633,
      "y": 41437,
      "ta": "html > body"
    },
    {
      "t": 84610,
      "e": 84209,
      "ty": 2,
      "x": 555,
      "y": 837
    },
    {
      "t": 84761,
      "e": 84360,
      "ty": 41,
      "x": 18837,
      "y": 45924,
      "ta": "html > body"
    },
    {
      "t": 85253,
      "e": 84852,
      "ty": 38,
      "x": 2,
      "y": 0
    },
    {
      "t": 85911,
      "e": 85510,
      "ty": 2,
      "x": 597,
      "y": 828
    },
    {
      "t": 86010,
      "e": 85609,
      "ty": 2,
      "x": 826,
      "y": 711
    },
    {
      "t": 86010,
      "e": 85609,
      "ty": 41,
      "x": 28170,
      "y": 38944,
      "ta": "html > body"
    },
    {
      "t": 86074,
      "e": 85673,
      "ty": 6,
      "x": 859,
      "y": 664,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 86107,
      "e": 85706,
      "ty": 7,
      "x": 865,
      "y": 639,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 86110,
      "e": 85709,
      "ty": 2,
      "x": 865,
      "y": 639
    },
    {
      "t": 86211,
      "e": 85810,
      "ty": 2,
      "x": 886,
      "y": 577
    },
    {
      "t": 86261,
      "e": 85810,
      "ty": 41,
      "x": 17086,
      "y": 60602,
      "ta": "#jspsych-survey-text-0"
    },
    {
      "t": 86311,
      "e": 85860,
      "ty": 2,
      "x": 887,
      "y": 576
    },
    {
      "t": 86342,
      "e": 85891,
      "ty": 6,
      "x": 888,
      "y": 569,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 86410,
      "e": 85959,
      "ty": 2,
      "x": 892,
      "y": 554
    },
    {
      "t": 86430,
      "e": 85979,
      "ty": 7,
      "x": 893,
      "y": 553,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 86486,
      "e": 86035,
      "ty": 3,
      "x": 893,
      "y": 553,
      "ta": "#jspsych-survey-text-0"
    },
    {
      "t": 86510,
      "e": 86059,
      "ty": 2,
      "x": 893,
      "y": 553
    },
    {
      "t": 86511,
      "e": 86060,
      "ty": 41,
      "x": 18384,
      "y": 44394,
      "ta": "#jspsych-survey-text-0"
    },
    {
      "t": 86589,
      "e": 86138,
      "ty": 4,
      "x": 18384,
      "y": 44394,
      "ta": "#jspsych-survey-text-0"
    },
    {
      "t": 86590,
      "e": 86139,
      "ty": 5,
      "x": 893,
      "y": 553,
      "ta": "#jspsych-survey-text-0"
    },
    {
      "t": 86726,
      "e": 86275,
      "ty": 6,
      "x": 898,
      "y": 560,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 86760,
      "e": 86309,
      "ty": 41,
      "x": 20547,
      "y": 46810,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 86810,
      "e": 86359,
      "ty": 2,
      "x": 904,
      "y": 571
    },
    {
      "t": 86910,
      "e": 86459,
      "ty": 3,
      "x": 904,
      "y": 571,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 86911,
      "e": 86460,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 87011,
      "e": 86560,
      "ty": 41,
      "x": 20763,
      "y": 53052,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 87013,
      "e": 86562,
      "ty": 4,
      "x": 20763,
      "y": 53052,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 87014,
      "e": 86563,
      "ty": 5,
      "x": 904,
      "y": 571,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 87698,
      "e": 87247,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "98"
    },
    {
      "t": 87698,
      "e": 87247,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 87761,
      "e": 87310,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "97"
    },
    {
      "t": 87761,
      "e": 87310,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 87792,
      "e": 87341,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "21"
    },
    {
      "t": 87833,
      "e": 87382,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "21"
    },
    {
      "t": 89042,
      "e": 88591,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "9"
    },
    {
      "t": 89042,
      "e": 88591,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "21"
    },
    {
      "t": 89042,
      "e": 88591,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 89044,
      "e": 88593,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 89113,
      "e": 88662,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": ""
    },
    {
      "t": 89929,
      "e": 89478,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "16"
    },
    {
      "t": 90073,
      "e": 89622,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "83"
    },
    {
      "t": 90074,
      "e": 89623,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 90136,
      "e": 89685,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "S"
    },
    {
      "t": 90201,
      "e": 89750,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "S"
    },
    {
      "t": 91497,
      "e": 91046,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "8"
    },
    {
      "t": 91577,
      "e": 91126,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": ""
    },
    {
      "t": 91874,
      "e": 91423,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "16"
    },
    {
      "t": 91977,
      "e": 91526,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "85"
    },
    {
      "t": 91978,
      "e": 91527,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 92073,
      "e": 91622,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "U"
    },
    {
      "t": 92080,
      "e": 91629,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "U"
    },
    {
      "t": 92216,
      "e": 91765,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "78"
    },
    {
      "t": 92216,
      "e": 91765,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 92288,
      "e": 91837,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "Un"
    },
    {
      "t": 92352,
      "e": 91901,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "73"
    },
    {
      "t": 92352,
      "e": 91901,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 92441,
      "e": 91990,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "Uni"
    },
    {
      "t": 92545,
      "e": 92094,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "67"
    },
    {
      "t": 92546,
      "e": 92095,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 92616,
      "e": 92165,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "Unic"
    },
    {
      "t": 92858,
      "e": 92407,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "84"
    },
    {
      "t": 92858,
      "e": 92407,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 93011,
      "e": 92560,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "Unict"
    },
    {
      "t": 93024,
      "e": 92573,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "69"
    },
    {
      "t": 93024,
      "e": 92573,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 93048,
      "e": 92597,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "+||te"
    },
    {
      "t": 93088,
      "e": 92637,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "+||"
    },
    {
      "t": 93211,
      "e": 92760,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "Unicte"
    },
    {
      "t": 93241,
      "e": 92790,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "8"
    },
    {
      "t": 93288,
      "e": 92837,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "Unict"
    },
    {
      "t": 93410,
      "e": 92959,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "8"
    },
    {
      "t": 93432,
      "e": 92981,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "Unic"
    },
    {
      "t": 93520,
      "e": 93069,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "8"
    },
    {
      "t": 93568,
      "e": 93117,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "Uni"
    },
    {
      "t": 93665,
      "e": 93214,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "84"
    },
    {
      "t": 93666,
      "e": 93215,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 93777,
      "e": 93326,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "69"
    },
    {
      "t": 93777,
      "e": 93326,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 93808,
      "e": 93357,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "Unite"
    },
    {
      "t": 93914,
      "e": 93463,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "68"
    },
    {
      "t": 93914,
      "e": 93463,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 93921,
      "e": 93470,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "+||d"
    },
    {
      "t": 94121,
      "e": 93670,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "+||"
    },
    {
      "t": 94153,
      "e": 93702,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "32"
    },
    {
      "t": 94153,
      "e": 93702,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 94250,
      "e": 93799,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "+|| "
    },
    {
      "t": 94273,
      "e": 93822,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "16"
    },
    {
      "t": 94569,
      "e": 94118,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "83"
    },
    {
      "t": 94570,
      "e": 94119,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 94688,
      "e": 94237,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "+||S"
    },
    {
      "t": 94736,
      "e": 94285,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "+||"
    },
    {
      "t": 94905,
      "e": 94454,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "84"
    },
    {
      "t": 94905,
      "e": 94454,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 94986,
      "e": 94535,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "65"
    },
    {
      "t": 94986,
      "e": 94535,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 95000,
      "e": 94549,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "+||ta"
    },
    {
      "t": 95185,
      "e": 94734,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "+||"
    },
    {
      "t": 95201,
      "e": 94750,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "84"
    },
    {
      "t": 95202,
      "e": 94751,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 95369,
      "e": 94918,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "69"
    },
    {
      "t": 95369,
      "e": 94918,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 95385,
      "e": 94934,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "+||te"
    },
    {
      "t": 95498,
      "e": 95047,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "+||"
    },
    {
      "t": 95826,
      "e": 95375,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "83"
    },
    {
      "t": 95826,
      "e": 95375,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 95881,
      "e": 95430,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "+||s"
    },
    {
      "t": 96011,
      "e": 95560,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "United States"
    },
    {
      "t": 96986,
      "e": 96535,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "32"
    },
    {
      "t": 96987,
      "e": 96536,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 97025,
      "e": 96574,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "+|| "
    },
    {
      "t": 97346,
      "e": 96895,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "79"
    },
    {
      "t": 97346,
      "e": 96895,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 97432,
      "e": 96981,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "+||o"
    },
    {
      "t": 97505,
      "e": 97054,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "70"
    },
    {
      "t": 97505,
      "e": 97054,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 97577,
      "e": 97126,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "+||f"
    },
    {
      "t": 97705,
      "e": 97254,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "32"
    },
    {
      "t": 97706,
      "e": 97255,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 97811,
      "e": 97360,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "United States of "
    },
    {
      "t": 97816,
      "e": 97365,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "+|| "
    },
    {
      "t": 97954,
      "e": 97503,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "16"
    },
    {
      "t": 98098,
      "e": 97647,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "65"
    },
    {
      "t": 98098,
      "e": 97647,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 98185,
      "e": 97734,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "+||A"
    },
    {
      "t": 98281,
      "e": 97830,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "+||"
    },
    {
      "t": 98393,
      "e": 97942,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "77"
    },
    {
      "t": 98394,
      "e": 97943,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 98473,
      "e": 98022,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "69"
    },
    {
      "t": 98473,
      "e": 98022,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 98480,
      "e": 98029,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "+||me"
    },
    {
      "t": 98545,
      "e": 98094,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "82"
    },
    {
      "t": 98545,
      "e": 98094,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 98578,
      "e": 98127,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "+||r"
    },
    {
      "t": 98633,
      "e": 98182,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "+||"
    },
    {
      "t": 98650,
      "e": 98183,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "73"
    },
    {
      "t": 98651,
      "e": 98184,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 98752,
      "e": 98285,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "+||i"
    },
    {
      "t": 99073,
      "e": 98606,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "67"
    },
    {
      "t": 99074,
      "e": 98607,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 99129,
      "e": 98662,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "+||c"
    },
    {
      "t": 100849,
      "e": 100382,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "65"
    },
    {
      "t": 100850,
      "e": 100383,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 100928,
      "e": 100461,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "+||a"
    },
    {
      "t": 102011,
      "e": 101544,
      "ty": 2,
      "x": 904,
      "y": 572
    },
    {
      "t": 102011,
      "e": 101544,
      "ty": 41,
      "x": 20763,
      "y": 56172,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 102171,
      "e": 101704,
      "ty": 7,
      "x": 906,
      "y": 579,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 102211,
      "e": 101744,
      "ty": 2,
      "x": 929,
      "y": 606
    },
    {
      "t": 102237,
      "e": 101770,
      "ty": 6,
      "x": 976,
      "y": 649,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 102260,
      "e": 101793,
      "ty": 41,
      "x": 40229,
      "y": 53052,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 102270,
      "e": 101803,
      "ty": 7,
      "x": 1023,
      "y": 679,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 102270,
      "e": 101803,
      "ty": 6,
      "x": 1023,
      "y": 679,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 102286,
      "e": 101819,
      "ty": 7,
      "x": 1055,
      "y": 695,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 102310,
      "e": 101843,
      "ty": 2,
      "x": 1079,
      "y": 703
    },
    {
      "t": 102410,
      "e": 101943,
      "ty": 2,
      "x": 1142,
      "y": 729
    },
    {
      "t": 102510,
      "e": 102043,
      "ty": 2,
      "x": 1150,
      "y": 734
    },
    {
      "t": 102511,
      "e": 102044,
      "ty": 41,
      "x": 39327,
      "y": 40218,
      "ta": "html > body"
    },
    {
      "t": 102611,
      "e": 102144,
      "ty": 2,
      "x": 1151,
      "y": 736
    },
    {
      "t": 102761,
      "e": 102294,
      "ty": 41,
      "x": 39362,
      "y": 40329,
      "ta": "html > body"
    },
    {
      "t": 103611,
      "e": 103144,
      "ty": 2,
      "x": 1146,
      "y": 747
    },
    {
      "t": 103711,
      "e": 103244,
      "ty": 2,
      "x": 1143,
      "y": 756
    },
    {
      "t": 103761,
      "e": 103294,
      "ty": 41,
      "x": 39052,
      "y": 41714,
      "ta": "html > body"
    },
    {
      "t": 103810,
      "e": 103343,
      "ty": 2,
      "x": 1142,
      "y": 761
    },
    {
      "t": 103911,
      "e": 103444,
      "ty": 2,
      "x": 1138,
      "y": 769
    },
    {
      "t": 104010,
      "e": 103543,
      "ty": 2,
      "x": 1117,
      "y": 773
    },
    {
      "t": 104011,
      "e": 103544,
      "ty": 41,
      "x": 38191,
      "y": 42378,
      "ta": "html > body"
    },
    {
      "t": 104110,
      "e": 103643,
      "ty": 2,
      "x": 1087,
      "y": 774
    },
    {
      "t": 104261,
      "e": 103794,
      "ty": 41,
      "x": 37158,
      "y": 42434,
      "ta": "html > body"
    },
    {
      "t": 104511,
      "e": 104044,
      "ty": 2,
      "x": 1065,
      "y": 774
    },
    {
      "t": 104511,
      "e": 104044,
      "ty": 41,
      "x": 36400,
      "y": 42434,
      "ta": "html > body"
    },
    {
      "t": 104611,
      "e": 104144,
      "ty": 2,
      "x": 1018,
      "y": 733
    },
    {
      "t": 104710,
      "e": 104243,
      "ty": 2,
      "x": 991,
      "y": 719
    },
    {
      "t": 104756,
      "e": 104289,
      "ty": 6,
      "x": 974,
      "y": 708,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 104761,
      "e": 104294,
      "ty": 41,
      "x": 40240,
      "y": 63549,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 104810,
      "e": 104343,
      "ty": 2,
      "x": 968,
      "y": 704
    },
    {
      "t": 104934,
      "e": 104467,
      "ty": 3,
      "x": 967,
      "y": 703,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 104934,
      "e": 104467,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "United States of America"
    },
    {
      "t": 104935,
      "e": 104468,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 104936,
      "e": 104469,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 105010,
      "e": 104543,
      "ty": 2,
      "x": 966,
      "y": 703
    },
    {
      "t": 105010,
      "e": 104543,
      "ty": 41,
      "x": 36117,
      "y": 53619,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 105053,
      "e": 104586,
      "ty": 4,
      "x": 36117,
      "y": 53619,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 105053,
      "e": 104586,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 105053,
      "e": 104586,
      "ty": 5,
      "x": 966,
      "y": 703,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 105054,
      "e": 104587,
      "ty": 38,
      "x": 3,
      "y": 0
    },
    {
      "t": 105410,
      "e": 104943,
      "ty": 2,
      "x": 1161,
      "y": 789
    },
    {
      "t": 105511,
      "e": 105044,
      "ty": 2,
      "x": 1273,
      "y": 818
    },
    {
      "t": 105511,
      "e": 105044,
      "ty": 41,
      "x": 43563,
      "y": 44871,
      "ta": "html > body"
    },
    {
      "t": 106076,
      "e": 105609,
      "ty": 38,
      "x": 4,
      "y": 0
    },
    {
      "t": 106111,
      "e": 105644,
      "ty": 2,
      "x": 1273,
      "y": 827
    },
    {
      "t": 106211,
      "e": 105744,
      "ty": 2,
      "x": 1276,
      "y": 838
    },
    {
      "t": 106261,
      "e": 105794,
      "ty": 41,
      "x": 43667,
      "y": 45979,
      "ta": "html > body"
    },
    {
      "t": 106911,
      "e": 106444,
      "ty": 2,
      "x": 1263,
      "y": 838
    },
    {
      "t": 107011,
      "e": 106544,
      "ty": 2,
      "x": 1175,
      "y": 845
    },
    {
      "t": 107011,
      "e": 106544,
      "ty": 41,
      "x": 40188,
      "y": 46367,
      "ta": "html > body"
    },
    {
      "t": 107110,
      "e": 106643,
      "ty": 2,
      "x": 1103,
      "y": 858
    },
    {
      "t": 107211,
      "e": 106744,
      "ty": 2,
      "x": 1093,
      "y": 858
    },
    {
      "t": 107261,
      "e": 106794,
      "ty": 41,
      "x": 64452,
      "y": 52084,
      "ta": "#jspsych-survey-multi-choice-form"
    },
    {
      "t": 107411,
      "e": 106944,
      "ty": 2,
      "x": 1064,
      "y": 685
    },
    {
      "t": 107511,
      "e": 107044,
      "ty": 2,
      "x": 899,
      "y": 405
    },
    {
      "t": 107511,
      "e": 107044,
      "ty": 41,
      "x": 18411,
      "y": 9362,
      "ta": "#jspsych-survey-multi-choice-option-1-0"
    },
    {
      "t": 107611,
      "e": 107144,
      "ty": 2,
      "x": 856,
      "y": 306
    },
    {
      "t": 107710,
      "e": 107243,
      "ty": 2,
      "x": 863,
      "y": 237
    },
    {
      "t": 107761,
      "e": 107294,
      "ty": 41,
      "x": 35684,
      "y": 19660,
      "ta": "#jspsych-survey-multi-choice-option-0-0 > label"
    },
    {
      "t": 107811,
      "e": 107344,
      "ty": 2,
      "x": 865,
      "y": 235
    },
    {
      "t": 107911,
      "e": 107444,
      "ty": 2,
      "x": 860,
      "y": 256
    },
    {
      "t": 108010,
      "e": 107543,
      "ty": 2,
      "x": 851,
      "y": 284
    },
    {
      "t": 108010,
      "e": 107543,
      "ty": 41,
      "x": 7019,
      "y": 7021,
      "ta": "#jspsych-survey-multi-choice-option-0-2"
    },
    {
      "t": 108111,
      "e": 107644,
      "ty": 2,
      "x": 836,
      "y": 310
    },
    {
      "t": 108175,
      "e": 107708,
      "ty": 6,
      "x": 835,
      "y": 317,
      "ta": "jspsych-survey-multi-choice-response-0[3]_mf"
    },
    {
      "t": 108211,
      "e": 107744,
      "ty": 2,
      "x": 833,
      "y": 319
    },
    {
      "t": 108261,
      "e": 107794,
      "ty": 41,
      "x": 28120,
      "y": 30246,
      "ta": "jspsych-survey-multi-choice-response-0[3]_mf"
    },
    {
      "t": 108311,
      "e": 107844,
      "ty": 2,
      "x": 832,
      "y": 324
    },
    {
      "t": 108374,
      "e": 107907,
      "ty": 3,
      "x": 832,
      "y": 324,
      "ta": "jspsych-survey-multi-choice-response-0[3]_mf"
    },
    {
      "t": 108376,
      "e": 107909,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-0[3]_mf"
    },
    {
      "t": 108469,
      "e": 108002,
      "ty": 4,
      "x": 28120,
      "y": 40329,
      "ta": "jspsych-survey-multi-choice-response-0[3]_mf"
    },
    {
      "t": 108469,
      "e": 108002,
      "ty": 5,
      "x": 832,
      "y": 324,
      "ta": "jspsych-survey-multi-choice-response-0[3]_mf"
    },
    {
      "t": 108469,
      "e": 108002,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-0[3]_mf",
      "v": "Other"
    },
    {
      "t": 108511,
      "e": 108044,
      "ty": 41,
      "x": 28120,
      "y": 40329,
      "ta": "jspsych-survey-multi-choice-response-0[3]_mf"
    },
    {
      "t": 108693,
      "e": 108226,
      "ty": 7,
      "x": 844,
      "y": 331,
      "ta": "jspsych-survey-multi-choice-response-0[3]_mf"
    },
    {
      "t": 108711,
      "e": 108244,
      "ty": 2,
      "x": 878,
      "y": 343
    },
    {
      "t": 108760,
      "e": 108293,
      "ty": 41,
      "x": 40843,
      "y": 22879,
      "ta": "html > body"
    },
    {
      "t": 108811,
      "e": 108344,
      "ty": 2,
      "x": 1274,
      "y": 438
    },
    {
      "t": 109012,
      "e": 108545,
      "ty": 41,
      "x": 43598,
      "y": 23820,
      "ta": "html > body"
    },
    {
      "t": 109111,
      "e": 108644,
      "ty": 2,
      "x": 1260,
      "y": 440
    },
    {
      "t": 109210,
      "e": 108743,
      "ty": 2,
      "x": 1262,
      "y": 433
    },
    {
      "t": 109261,
      "e": 108794,
      "ty": 41,
      "x": 43184,
      "y": 23543,
      "ta": "html > body"
    },
    {
      "t": 109311,
      "e": 108844,
      "ty": 2,
      "x": 1263,
      "y": 432
    },
    {
      "t": 109511,
      "e": 109044,
      "ty": 41,
      "x": 43219,
      "y": 23488,
      "ta": "html > body"
    },
    {
      "t": 109910,
      "e": 109443,
      "ty": 2,
      "x": 1263,
      "y": 435
    },
    {
      "t": 110010,
      "e": 109543,
      "ty": 2,
      "x": 1261,
      "y": 439
    },
    {
      "t": 110011,
      "e": 109544,
      "ty": 41,
      "x": 43150,
      "y": 23876,
      "ta": "html > body"
    },
    {
      "t": 110011,
      "e": 109544,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 110710,
      "e": 110243,
      "ty": 2,
      "x": 1247,
      "y": 445
    },
    {
      "t": 110760,
      "e": 110293,
      "ty": 41,
      "x": 37812,
      "y": 25371,
      "ta": "html > body"
    },
    {
      "t": 110810,
      "e": 110343,
      "ty": 2,
      "x": 976,
      "y": 473
    },
    {
      "t": 110911,
      "e": 110444,
      "ty": 2,
      "x": 945,
      "y": 469
    },
    {
      "t": 111011,
      "e": 110544,
      "ty": 2,
      "x": 942,
      "y": 483
    },
    {
      "t": 111012,
      "e": 110545,
      "ty": 41,
      "x": 28616,
      "y": 60853,
      "ta": "#jspsych-survey-multi-choice-option-1-2"
    },
    {
      "t": 111111,
      "e": 110644,
      "ty": 2,
      "x": 922,
      "y": 518
    },
    {
      "t": 111211,
      "e": 110744,
      "ty": 2,
      "x": 920,
      "y": 518
    },
    {
      "t": 111261,
      "e": 110794,
      "ty": 41,
      "x": 23395,
      "y": 11702,
      "ta": "#jspsych-survey-multi-choice-option-1-4"
    },
    {
      "t": 111310,
      "e": 110843,
      "ty": 2,
      "x": 919,
      "y": 518
    },
    {
      "t": 111411,
      "e": 110944,
      "ty": 2,
      "x": 915,
      "y": 518
    },
    {
      "t": 111510,
      "e": 111043,
      "ty": 2,
      "x": 912,
      "y": 519
    },
    {
      "t": 111510,
      "e": 111043,
      "ty": 41,
      "x": 21496,
      "y": 14043,
      "ta": "#jspsych-survey-multi-choice-option-1-4"
    },
    {
      "t": 111612,
      "e": 111145,
      "ty": 2,
      "x": 911,
      "y": 510
    },
    {
      "t": 111760,
      "e": 111293,
      "ty": 41,
      "x": 21259,
      "y": 58513,
      "ta": "#jspsych-survey-multi-choice-option-1-3"
    },
    {
      "t": 111911,
      "e": 111444,
      "ty": 2,
      "x": 900,
      "y": 490
    },
    {
      "t": 112010,
      "e": 111543,
      "ty": 2,
      "x": 859,
      "y": 471
    },
    {
      "t": 112010,
      "e": 111543,
      "ty": 41,
      "x": 39720,
      "y": 32767,
      "ta": "#jspsych-survey-multi-choice-option-1-2 > label"
    },
    {
      "t": 112109,
      "e": 111642,
      "ty": 2,
      "x": 845,
      "y": 463
    },
    {
      "t": 112211,
      "e": 111744,
      "ty": 2,
      "x": 843,
      "y": 463
    },
    {
      "t": 112261,
      "e": 111794,
      "ty": 41,
      "x": 22808,
      "y": 6553,
      "ta": "#jspsych-survey-multi-choice-option-1-2 > label"
    },
    {
      "t": 112311,
      "e": 111844,
      "ty": 2,
      "x": 841,
      "y": 465
    },
    {
      "t": 112312,
      "e": 111845,
      "ty": 6,
      "x": 839,
      "y": 466,
      "ta": "jspsych-survey-multi-choice-response-1[2]_mf"
    },
    {
      "t": 112410,
      "e": 111943,
      "ty": 2,
      "x": 833,
      "y": 469
    },
    {
      "t": 112445,
      "e": 111978,
      "ty": 3,
      "x": 833,
      "y": 469,
      "ta": "jspsych-survey-multi-choice-response-1[2]_mf"
    },
    {
      "t": 112446,
      "e": 111979,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-0[3]_mf"
    },
    {
      "t": 112447,
      "e": 111980,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-1[2]_mf"
    },
    {
      "t": 112511,
      "e": 112044,
      "ty": 41,
      "x": 33161,
      "y": 25205,
      "ta": "jspsych-survey-multi-choice-response-1[2]_mf"
    },
    {
      "t": 112540,
      "e": 112073,
      "ty": 4,
      "x": 33161,
      "y": 25205,
      "ta": "jspsych-survey-multi-choice-response-1[2]_mf"
    },
    {
      "t": 112541,
      "e": 112074,
      "ty": 5,
      "x": 833,
      "y": 469,
      "ta": "jspsych-survey-multi-choice-response-1[2]_mf"
    },
    {
      "t": 112541,
      "e": 112074,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-1[2]_mf",
      "v": "Third"
    },
    {
      "t": 112662,
      "e": 112195,
      "ty": 7,
      "x": 842,
      "y": 469,
      "ta": "jspsych-survey-multi-choice-response-1[2]_mf"
    },
    {
      "t": 112710,
      "e": 112243,
      "ty": 2,
      "x": 892,
      "y": 480
    },
    {
      "t": 112760,
      "e": 112293,
      "ty": 41,
      "x": 54959,
      "y": 28086,
      "ta": "#jspsych-survey-multi-choice-option-1-4"
    },
    {
      "t": 112810,
      "e": 112343,
      "ty": 2,
      "x": 1123,
      "y": 555
    },
    {
      "t": 112910,
      "e": 112443,
      "ty": 2,
      "x": 1126,
      "y": 560
    },
    {
      "t": 113010,
      "e": 112543,
      "ty": 2,
      "x": 1137,
      "y": 610
    },
    {
      "t": 113010,
      "e": 112543,
      "ty": 41,
      "x": 38880,
      "y": 33349,
      "ta": "html > body"
    },
    {
      "t": 113110,
      "e": 112643,
      "ty": 2,
      "x": 1188,
      "y": 648
    },
    {
      "t": 113261,
      "e": 112794,
      "ty": 41,
      "x": 40636,
      "y": 35454,
      "ta": "html > body"
    },
    {
      "t": 113510,
      "e": 113043,
      "ty": 2,
      "x": 1149,
      "y": 680
    },
    {
      "t": 113510,
      "e": 113043,
      "ty": 41,
      "x": 39293,
      "y": 37226,
      "ta": "html > body"
    },
    {
      "t": 113610,
      "e": 113143,
      "ty": 2,
      "x": 988,
      "y": 737
    },
    {
      "t": 113710,
      "e": 113243,
      "ty": 2,
      "x": 867,
      "y": 756
    },
    {
      "t": 113760,
      "e": 113293,
      "ty": 41,
      "x": 16096,
      "y": 45874,
      "ta": "#jspsych-survey-multi-choice-option-2-3 > label"
    },
    {
      "t": 113810,
      "e": 113343,
      "ty": 2,
      "x": 855,
      "y": 774
    },
    {
      "t": 113910,
      "e": 113443,
      "ty": 2,
      "x": 853,
      "y": 803
    },
    {
      "t": 114010,
      "e": 113543,
      "ty": 2,
      "x": 851,
      "y": 814
    },
    {
      "t": 114010,
      "e": 113543,
      "ty": 41,
      "x": 17458,
      "y": 29490,
      "ta": "#jspsych-survey-multi-choice-option-2-5 > label"
    },
    {
      "t": 114110,
      "e": 113643,
      "ty": 2,
      "x": 851,
      "y": 819
    },
    {
      "t": 114261,
      "e": 113794,
      "ty": 41,
      "x": 17458,
      "y": 45874,
      "ta": "#jspsych-survey-multi-choice-option-2-5 > label"
    },
    {
      "t": 114310,
      "e": 113843,
      "ty": 2,
      "x": 851,
      "y": 816
    },
    {
      "t": 114410,
      "e": 113943,
      "ty": 2,
      "x": 856,
      "y": 792
    },
    {
      "t": 114510,
      "e": 114043,
      "ty": 2,
      "x": 859,
      "y": 716
    },
    {
      "t": 114510,
      "e": 114043,
      "ty": 41,
      "x": 8918,
      "y": 63194,
      "ta": "#jspsych-survey-multi-choice-option-2-1"
    },
    {
      "t": 114610,
      "e": 114143,
      "ty": 2,
      "x": 856,
      "y": 706
    },
    {
      "t": 114760,
      "e": 114293,
      "ty": 41,
      "x": 7453,
      "y": 42597,
      "ta": "#jspsych-survey-multi-choice-option-2-1 > label"
    },
    {
      "t": 114810,
      "e": 114343,
      "ty": 2,
      "x": 845,
      "y": 707
    },
    {
      "t": 114910,
      "e": 114443,
      "ty": 2,
      "x": 798,
      "y": 719
    },
    {
      "t": 115010,
      "e": 114543,
      "ty": 2,
      "x": 789,
      "y": 726
    },
    {
      "t": 115011,
      "e": 114544,
      "ty": 41,
      "x": 26895,
      "y": 39775,
      "ta": "html > body"
    },
    {
      "t": 115110,
      "e": 114643,
      "ty": 2,
      "x": 775,
      "y": 736
    },
    {
      "t": 115210,
      "e": 114743,
      "ty": 2,
      "x": 774,
      "y": 737
    },
    {
      "t": 115260,
      "e": 114793,
      "ty": 41,
      "x": 26379,
      "y": 40384,
      "ta": "html > body"
    },
    {
      "t": 115310,
      "e": 114843,
      "ty": 2,
      "x": 800,
      "y": 729
    },
    {
      "t": 115410,
      "e": 114943,
      "ty": 2,
      "x": 840,
      "y": 716
    },
    {
      "t": 115510,
      "e": 115043,
      "ty": 2,
      "x": 856,
      "y": 703
    },
    {
      "t": 115511,
      "e": 115044,
      "ty": 41,
      "x": 8713,
      "y": 32767,
      "ta": "#jspsych-survey-multi-choice-option-2-1 > label"
    },
    {
      "t": 115710,
      "e": 115243,
      "ty": 2,
      "x": 854,
      "y": 702
    },
    {
      "t": 115760,
      "e": 115293,
      "ty": 41,
      "x": 6193,
      "y": 29490,
      "ta": "#jspsych-survey-multi-choice-option-2-1 > label"
    },
    {
      "t": 115810,
      "e": 115343,
      "ty": 2,
      "x": 841,
      "y": 701
    },
    {
      "t": 116011,
      "e": 115544,
      "ty": 41,
      "x": 4933,
      "y": 26214,
      "ta": "#jspsych-survey-multi-choice-option-2-1 > label"
    },
    {
      "t": 116197,
      "e": 115730,
      "ty": 3,
      "x": 841,
      "y": 701,
      "ta": "#jspsych-survey-multi-choice-option-2-1 > label"
    },
    {
      "t": 116198,
      "e": 115731,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-1[2]_mf"
    },
    {
      "t": 116300,
      "e": 115833,
      "ty": 4,
      "x": 4933,
      "y": 26214,
      "ta": "#jspsych-survey-multi-choice-option-2-1 > label"
    },
    {
      "t": 116301,
      "e": 115834,
      "ty": 5,
      "x": 841,
      "y": 701,
      "ta": "#jspsych-survey-multi-choice-option-2-1 > label"
    },
    {
      "t": 116301,
      "e": 115834,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-2[1]_mf"
    },
    {
      "t": 116302,
      "e": 115835,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-2[1]_mf",
      "v": "Social Sciences (incl. CogSci)"
    },
    {
      "t": 116710,
      "e": 116243,
      "ty": 2,
      "x": 840,
      "y": 701
    },
    {
      "t": 116760,
      "e": 116293,
      "ty": 41,
      "x": 4681,
      "y": 26214,
      "ta": "#jspsych-survey-multi-choice-option-2-1 > label"
    },
    {
      "t": 117011,
      "e": 116544,
      "ty": 2,
      "x": 881,
      "y": 696
    },
    {
      "t": 117011,
      "e": 116544,
      "ty": 41,
      "x": 15012,
      "y": 9830,
      "ta": "#jspsych-survey-multi-choice-option-2-1 > label"
    },
    {
      "t": 117111,
      "e": 116644,
      "ty": 2,
      "x": 1012,
      "y": 730
    },
    {
      "t": 117210,
      "e": 116743,
      "ty": 2,
      "x": 1257,
      "y": 893
    },
    {
      "t": 117261,
      "e": 116794,
      "ty": 41,
      "x": 43012,
      "y": 49026,
      "ta": "html > body"
    },
    {
      "t": 117511,
      "e": 117044,
      "ty": 2,
      "x": 1259,
      "y": 893
    },
    {
      "t": 117511,
      "e": 117044,
      "ty": 41,
      "x": 43081,
      "y": 49026,
      "ta": "html > body"
    },
    {
      "t": 117611,
      "e": 117144,
      "ty": 2,
      "x": 1260,
      "y": 927
    },
    {
      "t": 117711,
      "e": 117244,
      "ty": 2,
      "x": 1260,
      "y": 936
    },
    {
      "t": 117761,
      "e": 117294,
      "ty": 41,
      "x": 43116,
      "y": 51408,
      "ta": "html > body"
    },
    {
      "t": 119211,
      "e": 118744,
      "ty": 2,
      "x": 1259,
      "y": 937
    },
    {
      "t": 119260,
      "e": 118793,
      "ty": 41,
      "x": 43081,
      "y": 51464,
      "ta": "html > body"
    },
    {
      "t": 119411,
      "e": 118944,
      "ty": 2,
      "x": 1231,
      "y": 941
    },
    {
      "t": 119510,
      "e": 119043,
      "ty": 2,
      "x": 1229,
      "y": 941
    },
    {
      "t": 119511,
      "e": 119044,
      "ty": 41,
      "x": 42048,
      "y": 51685,
      "ta": "html > body"
    },
    {
      "t": 120410,
      "e": 119943,
      "ty": 2,
      "x": 1137,
      "y": 961
    },
    {
      "t": 120510,
      "e": 120043,
      "ty": 2,
      "x": 1077,
      "y": 967
    },
    {
      "t": 120511,
      "e": 120044,
      "ty": 41,
      "x": 60655,
      "y": 42129,
      "ta": "#jspsych-survey-multi-choice-option-3-1"
    },
    {
      "t": 120610,
      "e": 120143,
      "ty": 2,
      "x": 951,
      "y": 995
    },
    {
      "t": 120710,
      "e": 120243,
      "ty": 2,
      "x": 901,
      "y": 1004
    },
    {
      "t": 120761,
      "e": 120294,
      "ty": 41,
      "x": 17461,
      "y": 63194,
      "ta": "#jspsych-survey-multi-choice-option-3-2"
    },
    {
      "t": 120810,
      "e": 120343,
      "ty": 2,
      "x": 891,
      "y": 1003
    },
    {
      "t": 120910,
      "e": 120443,
      "ty": 2,
      "x": 864,
      "y": 976
    },
    {
      "t": 121010,
      "e": 120543,
      "ty": 2,
      "x": 844,
      "y": 971
    },
    {
      "t": 121011,
      "e": 120544,
      "ty": 41,
      "x": 18263,
      "y": 58981,
      "ta": "#jspsych-survey-multi-choice-option-3-1 > label"
    },
    {
      "t": 121068,
      "e": 120601,
      "ty": 6,
      "x": 839,
      "y": 967,
      "ta": "jspsych-survey-multi-choice-response-3[1]_mf"
    },
    {
      "t": 121110,
      "e": 120643,
      "ty": 2,
      "x": 838,
      "y": 966
    },
    {
      "t": 121260,
      "e": 120793,
      "ty": 41,
      "x": 48284,
      "y": 50411,
      "ta": "jspsych-survey-multi-choice-response-3[1]_mf"
    },
    {
      "t": 121311,
      "e": 120844,
      "ty": 2,
      "x": 836,
      "y": 965
    },
    {
      "t": 121334,
      "e": 120867,
      "ty": 3,
      "x": 836,
      "y": 965,
      "ta": "jspsych-survey-multi-choice-response-3[1]_mf"
    },
    {
      "t": 121335,
      "e": 120868,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-2[1]_mf"
    },
    {
      "t": 121336,
      "e": 120869,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-3[1]_mf"
    },
    {
      "t": 121412,
      "e": 120945,
      "ty": 4,
      "x": 48284,
      "y": 45370,
      "ta": "jspsych-survey-multi-choice-response-3[1]_mf"
    },
    {
      "t": 121413,
      "e": 120946,
      "ty": 5,
      "x": 836,
      "y": 965,
      "ta": "jspsych-survey-multi-choice-response-3[1]_mf"
    },
    {
      "t": 121413,
      "e": 120946,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-3[1]_mf",
      "v": "Female"
    },
    {
      "t": 121510,
      "e": 121043,
      "ty": 41,
      "x": 48284,
      "y": 45370,
      "ta": "jspsych-survey-multi-choice-response-3[1]_mf"
    },
    {
      "t": 121629,
      "e": 121162,
      "ty": 7,
      "x": 841,
      "y": 973,
      "ta": "jspsych-survey-multi-choice-response-3[1]_mf"
    },
    {
      "t": 121669,
      "e": 121202,
      "ty": 6,
      "x": 884,
      "y": 1011,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 121710,
      "e": 121243,
      "ty": 2,
      "x": 914,
      "y": 1027
    },
    {
      "t": 121761,
      "e": 121294,
      "ty": 41,
      "x": 45136,
      "y": 47661,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 121811,
      "e": 121344,
      "ty": 2,
      "x": 917,
      "y": 1029
    },
    {
      "t": 121911,
      "e": 121444,
      "ty": 2,
      "x": 909,
      "y": 1030
    },
    {
      "t": 122011,
      "e": 121544,
      "ty": 2,
      "x": 903,
      "y": 1026
    },
    {
      "t": 122011,
      "e": 121544,
      "ty": 41,
      "x": 37921,
      "y": 41704,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 122110,
      "e": 121643,
      "ty": 2,
      "x": 901,
      "y": 1023
    },
    {
      "t": 122118,
      "e": 121651,
      "ty": 3,
      "x": 901,
      "y": 1023,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 122119,
      "e": 121652,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-3[1]_mf"
    },
    {
      "t": 122120,
      "e": 121653,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 122196,
      "e": 121729,
      "ty": 4,
      "x": 36890,
      "y": 35746,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 122196,
      "e": 121729,
      "ty": 5,
      "x": 901,
      "y": 1023,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 122199,
      "e": 121732,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 122199,
      "e": 121732,
      "ty": 13,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-multi-choice-form"
    },
    {
      "t": 122201,
      "e": 121734,
      "ty": 38,
      "x": 5,
      "y": 0
    },
    {
      "t": 122260,
      "e": 121793,
      "ty": 41,
      "x": 30752,
      "y": 56228,
      "ta": "html > body"
    },
    {
      "t": 122610,
      "e": 122143,
      "ty": 2,
      "x": 930,
      "y": 1016
    },
    {
      "t": 122711,
      "e": 122244,
      "ty": 2,
      "x": 1368,
      "y": 898
    },
    {
      "t": 122761,
      "e": 122294,
      "ty": 41,
      "x": 54446,
      "y": 45979,
      "ta": "html > body"
    },
    {
      "t": 122811,
      "e": 122344,
      "ty": 2,
      "x": 1651,
      "y": 818
    },
    {
      "t": 123011,
      "e": 122544,
      "ty": 41,
      "x": 56581,
      "y": 44871,
      "ta": "html > body"
    },
    {
      "t": 123510,
      "e": 123043,
      "ty": 2,
      "x": 1670,
      "y": 826
    },
    {
      "t": 123511,
      "e": 123044,
      "ty": 41,
      "x": 57235,
      "y": 45314,
      "ta": "html > body"
    },
    {
      "t": 123531,
      "e": 123064,
      "ty": 38,
      "x": 6,
      "y": 0
    },
    {
      "t": 123610,
      "e": 123143,
      "ty": 2,
      "x": 1670,
      "y": 827
    },
    {
      "t": 123760,
      "e": 123293,
      "ty": 41,
      "x": 57269,
      "y": 45204,
      "ta": "> div.masterdiv"
    },
    {
      "t": 123810,
      "e": 123343,
      "ty": 2,
      "x": 1604,
      "y": 763
    },
    {
      "t": 123911,
      "e": 123444,
      "ty": 2,
      "x": 1384,
      "y": 616
    },
    {
      "t": 124010,
      "e": 123543,
      "ty": 2,
      "x": 1382,
      "y": 612
    },
    {
      "t": 124011,
      "e": 123544,
      "ty": 41,
      "x": 53553,
      "y": 50522,
      "ta": "> div.masterdiv > div:[2] > div > p:[3]"
    },
    {
      "t": 124111,
      "e": 123644,
      "ty": 2,
      "x": 1382,
      "y": 611
    },
    {
      "t": 124261,
      "e": 123794,
      "ty": 41,
      "x": 53553,
      "y": 50132,
      "ta": "> div.masterdiv > div:[2] > div > p:[3]"
    },
    {
      "t": 125510,
      "e": 125043,
      "ty": 2,
      "x": 1373,
      "y": 642
    },
    {
      "t": 125511,
      "e": 125044,
      "ty": 41,
      "x": 53110,
      "y": 62225,
      "ta": "> div.masterdiv > div:[2] > div > p:[3]"
    },
    {
      "t": 125612,
      "e": 125046,
      "ty": 2,
      "x": 1306,
      "y": 780
    },
    {
      "t": 125710,
      "e": 125144,
      "ty": 2,
      "x": 1306,
      "y": 781
    },
    {
      "t": 125761,
      "e": 125195,
      "ty": 41,
      "x": 49814,
      "y": 51700,
      "ta": "> div.masterdiv > div:[2] > div"
    },
    {
      "t": 125911,
      "e": 125345,
      "ty": 2,
      "x": 1316,
      "y": 838
    },
    {
      "t": 126011,
      "e": 125445,
      "ty": 2,
      "x": 1338,
      "y": 864
    },
    {
      "t": 126011,
      "e": 125445,
      "ty": 41,
      "x": 51388,
      "y": 61310,
      "ta": "> div.masterdiv > div:[2] > div"
    },
    {
      "t": 126111,
      "e": 125545,
      "ty": 2,
      "x": 1449,
      "y": 865
    },
    {
      "t": 126211,
      "e": 125645,
      "ty": 2,
      "x": 1456,
      "y": 864
    },
    {
      "t": 126261,
      "e": 125695,
      "ty": 41,
      "x": 57193,
      "y": 61310,
      "ta": "> div.masterdiv > div:[2] > div"
    },
    {
      "t": 140014,
      "e": 130695,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 178715,
      "e": 130695,
      "ty": 2,
      "x": 1458,
      "y": 864
    },
    {
      "t": 178765,
      "e": 130745,
      "ty": 41,
      "x": 57538,
      "y": 36314,
      "ta": "> div.masterdiv > div:[2] > div > p:[6]"
    },
    {
      "t": 178815,
      "e": 130795,
      "ty": 2,
      "x": 1463,
      "y": 888
    },
    {
      "t": 179115,
      "e": 131095,
      "ty": 2,
      "x": 1418,
      "y": 907
    },
    {
      "t": 179214,
      "e": 131194,
      "ty": 2,
      "x": 1312,
      "y": 941
    },
    {
      "t": 179265,
      "e": 131245,
      "ty": 41,
      "x": 49715,
      "y": 56623,
      "ta": "> div.masterdiv > div:[2]"
    },
    {
      "t": 179314,
      "e": 131294,
      "ty": 2,
      "x": 1291,
      "y": 949
    },
    {
      "t": 179415,
      "e": 131395,
      "ty": 2,
      "x": 1179,
      "y": 980
    },
    {
      "t": 179515,
      "e": 131495,
      "ty": 2,
      "x": 1091,
      "y": 986
    },
    {
      "t": 179515,
      "e": 131495,
      "ty": 41,
      "x": 39236,
      "y": 59532,
      "ta": "> div.masterdiv > div:[2]"
    },
    {
      "t": 179615,
      "e": 131595,
      "ty": 2,
      "x": 1008,
      "y": 1004
    },
    {
      "t": 179714,
      "e": 131694,
      "ty": 2,
      "x": 1001,
      "y": 1005
    },
    {
      "t": 179765,
      "e": 131745,
      "ty": 41,
      "x": 33284,
      "y": 61194,
      "ta": "> div.masterdiv > div:[2]"
    },
    {
      "t": 179814,
      "e": 131794,
      "ty": 2,
      "x": 947,
      "y": 1017
    },
    {
      "t": 179914,
      "e": 131894,
      "ty": 2,
      "x": 917,
      "y": 1029
    },
    {
      "t": 180015,
      "e": 131995,
      "ty": 2,
      "x": 901,
      "y": 1045
    },
    {
      "t": 180015,
      "e": 131995,
      "ty": 41,
      "x": 29889,
      "y": 63617,
      "ta": "> div.masterdiv > div:[2]"
    },
    {
      "t": 180114,
      "e": 132094,
      "ty": 2,
      "x": 898,
      "y": 1065
    },
    {
      "t": 180214,
      "e": 132194,
      "ty": 2,
      "x": 896,
      "y": 1083
    },
    {
      "t": 180265,
      "e": 132245,
      "ty": 41,
      "x": 3042,
      "y": 5712,
      "ta": "> div.masterdiv > div:[3]"
    },
    {
      "t": 180314,
      "e": 132294,
      "ty": 2,
      "x": 897,
      "y": 1084
    },
    {
      "t": 180367,
      "e": 132347,
      "ty": 6,
      "x": 914,
      "y": 1086,
      "ta": "#start"
    },
    {
      "t": 180415,
      "e": 132395,
      "ty": 2,
      "x": 938,
      "y": 1087
    },
    {
      "t": 180515,
      "e": 132495,
      "ty": 2,
      "x": 961,
      "y": 1094
    },
    {
      "t": 180515,
      "e": 132495,
      "ty": 41,
      "x": 28125,
      "y": 41079,
      "ta": "#start"
    },
    {
      "t": 180568,
      "e": 132548,
      "ty": 3,
      "x": 961,
      "y": 1094,
      "ta": "#start"
    },
    {
      "t": 180569,
      "e": 132549,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#start"
    },
    {
      "t": 180680,
      "e": 132660,
      "ty": 4,
      "x": 28125,
      "y": 41079,
      "ta": "#start"
    },
    {
      "t": 180681,
      "e": 132661,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#start"
    },
    {
      "t": 180682,
      "e": 132662,
      "ty": 5,
      "x": 961,
      "y": 1094,
      "ta": "#start"
    },
    {
      "t": 180683,
      "e": 132663,
      "ty": 38,
      "x": 7,
      "y": 0
    },
    {
      "t": 181722,
      "e": 133702,
      "ty": 38,
      "x": 8,
      "y": 0
    },
    {
      "t": 182389,
      "e": 134369,
      "ty": 2,
      "x": 1765,
      "y": 609
    },
    {
      "t": 182389,
      "e": 134369,
      "ty": 41,
      "x": 55858,
      "y": 32769,
      "ta": "#jspsych-data-display"
    },
    {
      "t": 182912,
      "e": 134892,
      "ty": 20,
      "x": 0,
      "y": 0
    }
  ],
  "domMutations": [
    {
      "sequence": 1,
      "data": "{\"f\":\"applyChanged\",\"args\":[[{\"id\":56},{\"id\":57},{\"id\":58},{\"id\":59},{\"id\":60},{\"id\":61},{\"id\":62},{\"id\":63},{\"id\":64},{\"id\":65},{\"id\":66},{\"id\":67},{\"id\":68},{\"id\":69},{\"id\":70},{\"id\":71},{\"id\":72},{\"id\":73},{\"id\":74},{\"id\":75},{\"id\":76},{\"id\":77},{\"id\":78},{\"id\":79},{\"id\":80},{\"id\":81},{\"id\":82},{\"id\":83},{\"id\":84},{\"id\":85},{\"id\":86},{\"id\":87},{\"id\":88},{\"id\":89},{\"id\":90},{\"id\":91},{\"id\":92},{\"id\":93},{\"id\":94},{\"id\":95},{\"id\":96},{\"id\":97},{\"id\":98},{\"id\":99},{\"id\":100},{\"id\":101},{\"id\":102},{\"id\":103},{\"id\":104},{\"id\":105},{\"id\":106},{\"id\":107},{\"id\":108},{\"id\":109},{\"id\":110},{\"id\":111},{\"id\":112},{\"id\":113},{\"id\":114},{\"id\":115},{\"id\":116},{\"id\":117},{\"id\":118},{\"id\":119},{\"id\":120},{\"id\":121},{\"id\":122},{\"id\":123},{\"id\":124},{\"id\":125},{\"id\":126},{\"id\":127},{\"id\":128},{\"id\":129},{\"id\":130},{\"id\":131},{\"id\":132},{\"id\":133},{\"id\":134},{\"id\":135},{\"id\":136},{\"id\":137},{\"id\":138},{\"id\":139},{\"id\":140},{\"id\":141},{\"id\":142},{\"id\":143},{\"id\":144},{\"id\":145},{\"id\":146},{\"id\":147},{\"id\":148},{\"id\":149},{\"id\":150},{\"id\":151},{\"id\":152},{\"id\":153},{\"id\":154},{\"id\":155},{\"id\":156},{\"id\":157},{\"id\":158},{\"id\":159},{\"id\":160},{\"id\":161},{\"id\":162},{\"id\":163},{\"id\":164},{\"id\":165},{\"id\":166},{\"id\":167},{\"id\":168},{\"id\":169},{\"id\":170},{\"id\":171},{\"id\":172},{\"id\":173},{\"id\":174},{\"id\":175},{\"id\":176},{\"id\":177},{\"id\":178},{\"id\":179},{\"id\":180},{\"id\":181},{\"id\":182},{\"id\":183},{\"id\":184},{\"id\":185},{\"id\":186},{\"id\":187},{\"id\":188},{\"id\":189},{\"id\":190},{\"id\":191},{\"id\":192},{\"id\":193},{\"id\":194},{\"id\":195},{\"id\":196},{\"id\":197},{\"id\":198},{\"id\":199},{\"id\":200},{\"id\":201},{\"id\":202},{\"id\":203},{\"id\":204},{\"id\":205},{\"id\":206},{\"id\":207},{\"id\":208},{\"id\":209},{\"id\":210},{\"id\":211},{\"id\":212},{\"id\":213},{\"id\":214},{\"id\":215},{\"id\":216},{\"id\":217},{\"id\":218},{\"id\":219},{\"id\":220},{\"id\":221},{\"id\":222},{\"id\":223},{\"id\":224},{\"id\":225},{\"id\":226},{\"id\":227},{\"id\":228},{\"id\":229},{\"id\":230},{\"id\":231},{\"id\":232},{\"id\":233},{\"id\":234},{\"id\":235},{\"id\":236},{\"id\":237},{\"id\":238},{\"id\":239},{\"id\":240},{\"id\":241},{\"id\":242},{\"id\":243},{\"id\":244},{\"id\":245},{\"id\":246},{\"id\":247},{\"id\":248},{\"id\":249},{\"id\":250},{\"id\":251},{\"id\":252},{\"id\":253},{\"id\":254},{\"id\":255},{\"id\":256},{\"id\":257},{\"id\":258},{\"id\":259},{\"id\":260},{\"id\":261},{\"id\":262},{\"id\":263},{\"id\":264},{\"id\":265},{\"id\":266},{\"id\":267},{\"id\":268},{\"id\":269},{\"id\":270},{\"id\":271},{\"id\":272},{\"id\":273},{\"id\":274},{\"id\":275},{\"id\":276},{\"id\":277},{\"id\":278},{\"id\":279},{\"id\":280},{\"id\":281},{\"id\":282},{\"id\":283},{\"id\":284},{\"id\":285},{\"id\":286},{\"id\":287},{\"id\":288},{\"id\":289},{\"id\":290},{\"id\":291},{\"id\":292},{\"id\":293},{\"id\":294},{\"id\":295},{\"id\":296},{\"id\":297},{\"id\":298},{\"id\":299},{\"id\":300},{\"id\":301},{\"id\":302},{\"id\":303},{\"id\":304},{\"id\":305},{\"id\":306},{\"id\":307},{\"id\":308},{\"id\":309},{\"id\":310},{\"id\":311},{\"id\":312},{\"id\":313},{\"id\":314},{\"id\":315},{\"id\":316},{\"id\":317},{\"id\":318},{\"id\":319},{\"id\":320},{\"id\":321},{\"id\":322},{\"id\":323},{\"id\":324},{\"id\":325},{\"id\":326},{\"id\":327},{\"id\":328},{\"id\":329},{\"id\":330},{\"id\":331},{\"id\":332},{\"id\":333},{\"id\":334},{\"id\":335},{\"id\":336},{\"id\":337},{\"id\":338},{\"id\":339},{\"id\":340},{\"id\":341},{\"id\":342},{\"id\":343},{\"id\":344},{\"id\":345},{\"id\":346},{\"id\":347},{\"id\":348},{\"id\":349},{\"id\":350},{\"id\":351},{\"id\":352},{\"id\":353},{\"id\":354},{\"id\":355},{\"id\":356},{\"id\":357},{\"id\":358},{\"id\":359},{\"id\":360},{\"id\":361},{\"id\":362},{\"id\":363},{\"id\":364},{\"id\":365},{\"id\":366},{\"id\":367},{\"id\":368},{\"id\":369},{\"id\":370},{\"id\":371},{\"id\":372},{\"id\":373},{\"id\":374},{\"id\":375},{\"id\":376},{\"id\":377},{\"id\":378},{\"id\":379},{\"id\":380},{\"id\":381},{\"id\":382},{\"id\":383},{\"id\":384},{\"id\":385},{\"id\":386},{\"id\":387},{\"id\":388},{\"id\":389},{\"id\":390},{\"id\":391},{\"id\":392},{\"id\":393},{\"id\":394},{\"id\":395},{\"id\":396},{\"id\":397},{\"id\":398},{\"id\":399},{\"id\":400},{\"id\":401},{\"id\":402},{\"id\":403},{\"id\":404},{\"id\":405},{\"id\":406},{\"id\":407},{\"id\":408},{\"id\":409},{\"id\":410},{\"id\":411},{\"id\":412},{\"id\":413},{\"id\":414},{\"id\":415},{\"id\":416},{\"id\":417},{\"id\":418},{\"id\":419},{\"id\":420},{\"id\":421},{\"id\":422},{\"id\":423},{\"id\":424},{\"id\":425},{\"id\":426},{\"id\":427},{\"id\":428},{\"id\":429},{\"id\":430},{\"id\":431},{\"id\":432},{\"id\":433},{\"id\":434},{\"id\":435},{\"id\":436},{\"id\":437},{\"id\":438},{\"id\":439},{\"id\":440},{\"id\":441},{\"id\":442},{\"id\":443},{\"id\":444},{\"id\":445},{\"id\":446},{\"id\":447},{\"id\":448},{\"id\":449},{\"id\":450},{\"id\":451},{\"id\":452},{\"id\":453},{\"id\":454},{\"id\":455},{\"id\":456},{\"id\":457},{\"id\":458},{\"id\":459},{\"id\":460},{\"id\":461},{\"id\":462},{\"id\":463},{\"id\":464},{\"id\":465},{\"id\":466},{\"id\":467},{\"id\":468},{\"id\":469},{\"id\":470},{\"id\":471},{\"id\":472},{\"id\":473},{\"id\":474},{\"id\":475},{\"id\":476},{\"id\":477},{\"id\":478},{\"id\":479},{\"id\":480},{\"id\":481},{\"id\":482},{\"id\":483},{\"id\":484},{\"id\":485},{\"id\":486},{\"id\":487},{\"id\":488},{\"id\":489},{\"id\":490},{\"id\":491},{\"id\":492},{\"id\":493},{\"id\":494},{\"id\":495},{\"id\":496},{\"id\":497},{\"id\":498},{\"id\":499},{\"id\":500},{\"id\":501},{\"id\":502},{\"id\":503},{\"id\":504},{\"id\":505},{\"id\":506},{\"id\":507},{\"id\":508},{\"id\":509},{\"id\":510},{\"id\":511},{\"id\":512},{\"id\":513},{\"id\":514},{\"id\":515},{\"id\":516},{\"id\":517},{\"id\":518},{\"id\":519},{\"id\":520},{\"id\":521},{\"id\":522},{\"id\":523},{\"id\":524},{\"id\":525},{\"id\":526},{\"id\":527},{\"id\":528},{\"id\":529},{\"id\":530},{\"id\":531},{\"id\":532},{\"id\":533},{\"id\":534},{\"id\":535},{\"id\":536},{\"id\":537},{\"id\":538},{\"id\":539},{\"id\":540},{\"id\":541},{\"id\":542},{\"id\":543},{\"id\":544},{\"id\":545},{\"id\":546},{\"id\":547},{\"id\":548},{\"id\":549},{\"id\":550},{\"id\":551},{\"id\":552},{\"id\":553},{\"id\":554},{\"id\":555},{\"id\":556},{\"id\":557},{\"id\":558},{\"id\":559},{\"id\":560},{\"id\":561},{\"id\":562},{\"id\":563},{\"id\":564},{\"id\":565},{\"id\":566},{\"id\":567},{\"id\":568},{\"id\":569},{\"id\":570},{\"id\":571},{\"id\":572},{\"id\":573},{\"id\":574},{\"id\":575},{\"id\":576},{\"id\":577},{\"id\":578},{\"id\":579},{\"id\":580},{\"id\":581},{\"id\":582},{\"id\":583},{\"id\":584},{\"id\":585},{\"id\":586},{\"id\":587},{\"id\":588},{\"id\":589},{\"id\":590},{\"id\":591},{\"id\":592},{\"id\":593},{\"id\":594},{\"id\":595},{\"id\":596},{\"id\":597},{\"id\":598},{\"id\":599},{\"id\":600},{\"id\":601},{\"id\":602},{\"id\":603},{\"id\":604},{\"id\":605},{\"id\":606},{\"id\":607},{\"id\":608},{\"id\":609},{\"id\":610},{\"id\":611},{\"id\":612},{\"id\":613},{\"id\":614},{\"id\":615},{\"id\":616},{\"id\":617},{\"id\":618},{\"id\":619},{\"id\":620},{\"id\":621},{\"id\":622},{\"id\":623},{\"id\":624},{\"id\":625},{\"id\":626},{\"id\":627},{\"id\":628},{\"id\":629},{\"id\":630},{\"id\":631},{\"id\":632},{\"id\":633},{\"id\":634},{\"id\":635},{\"id\":636},{\"id\":637},{\"id\":638},{\"id\":639},{\"id\":640},{\"id\":641},{\"id\":642},{\"id\":643},{\"id\":644},{\"id\":645},{\"id\":646},{\"id\":647},{\"id\":648},{\"id\":649},{\"id\":650},{\"id\":651},{\"id\":652},{\"id\":653},{\"id\":654},{\"id\":655},{\"id\":656},{\"id\":657},{\"id\":658},{\"id\":659},{\"id\":660},{\"id\":661},{\"id\":662},{\"id\":663},{\"id\":664},{\"id\":665},{\"id\":666},{\"id\":667},{\"id\":668},{\"id\":669},{\"id\":670},{\"id\":671},{\"id\":672},{\"id\":673},{\"id\":674},{\"id\":675},{\"id\":676},{\"id\":677},{\"id\":678},{\"id\":679},{\"id\":680},{\"id\":681},{\"id\":682},{\"id\":683},{\"id\":684},{\"id\":685},{\"id\":686},{\"id\":687},{\"id\":688},{\"id\":689},{\"id\":690},{\"id\":691},{\"id\":692},{\"id\":693},{\"id\":694},{\"id\":695},{\"id\":696},{\"id\":697},{\"id\":698},{\"id\":699},{\"id\":700},{\"id\":701},{\"id\":702},{\"id\":703},{\"id\":704},{\"id\":705},{\"id\":706},{\"id\":707},{\"id\":708},{\"id\":709},{\"id\":710},{\"id\":711},{\"id\":712},{\"id\":713},{\"id\":714},{\"id\":715},{\"id\":716},{\"id\":717},{\"id\":718},{\"id\":719},{\"id\":720},{\"id\":721},{\"id\":722},{\"id\":723},{\"id\":724},{\"id\":725},{\"id\":726},{\"id\":727},{\"id\":728},{\"id\":729},{\"id\":730},{\"id\":731},{\"id\":732},{\"id\":733},{\"id\":734},{\"id\":735},{\"id\":736},{\"id\":737},{\"id\":738},{\"id\":739},{\"id\":740},{\"id\":741},{\"id\":742},{\"id\":743},{\"id\":744},{\"id\":745},{\"id\":746},{\"id\":747},{\"id\":748},{\"id\":749},{\"id\":750},{\"id\":751},{\"id\":752},{\"id\":753},{\"id\":754},{\"id\":755},{\"id\":756},{\"id\":757},{\"id\":758},{\"id\":759},{\"id\":760},{\"id\":761},{\"id\":762},{\"id\":763},{\"id\":764},{\"id\":765},{\"id\":766},{\"id\":767},{\"id\":768},{\"id\":769},{\"id\":770},{\"id\":771},{\"id\":772},{\"id\":773},{\"id\":774},{\"id\":775},{\"id\":776},{\"id\":777},{\"id\":778},{\"id\":779},{\"id\":780},{\"id\":781},{\"id\":782},{\"id\":783},{\"id\":784},{\"id\":785},{\"id\":786},{\"id\":787},{\"id\":788},{\"id\":789},{\"id\":790},{\"id\":791},{\"id\":792},{\"id\":793},{\"id\":794},{\"id\":795},{\"id\":796},{\"id\":797},{\"id\":798},{\"id\":799},{\"id\":800},{\"id\":801},{\"id\":802},{\"id\":803},{\"id\":804},{\"id\":805},{\"id\":806},{\"id\":807},{\"id\":808},{\"id\":809},{\"id\":810},{\"id\":811},{\"id\":812},{\"id\":813},{\"id\":814},{\"id\":815},{\"id\":816},{\"id\":817},{\"id\":818},{\"id\":819},{\"id\":820},{\"id\":821},{\"id\":822},{\"id\":823},{\"id\":824},{\"id\":825},{\"id\":826},{\"id\":827},{\"id\":828},{\"id\":829},{\"id\":830},{\"id\":831},{\"id\":832},{\"id\":833},{\"id\":834},{\"id\":835},{\"id\":836},{\"id\":837},{\"id\":838},{\"id\":839},{\"id\":840},{\"id\":841},{\"id\":842},{\"id\":843},{\"id\":844},{\"id\":845},{\"id\":846},{\"id\":847},{\"id\":848},{\"id\":849},{\"id\":850},{\"id\":851},{\"id\":852},{\"id\":853},{\"id\":854},{\"id\":855},{\"id\":856},{\"id\":857},{\"id\":858},{\"id\":859},{\"id\":860},{\"id\":861},{\"id\":862},{\"id\":863},{\"id\":864},{\"id\":865},{\"id\":866},{\"id\":867},{\"id\":868},{\"id\":869},{\"id\":870},{\"id\":871},{\"id\":872},{\"id\":873},{\"id\":874},{\"id\":875},{\"id\":876},{\"id\":877},{\"id\":878},{\"id\":879},{\"id\":880},{\"id\":881},{\"id\":882},{\"id\":883},{\"id\":884},{\"id\":885},{\"id\":886},{\"id\":887},{\"id\":888},{\"id\":889},{\"id\":890},{\"id\":891},{\"id\":892},{\"id\":893},{\"id\":894},{\"id\":895},{\"id\":896},{\"id\":897},{\"id\":898},{\"id\":899},{\"id\":900},{\"id\":901},{\"id\":902},{\"id\":903},{\"id\":904},{\"id\":905},{\"id\":906},{\"id\":907},{\"id\":908},{\"id\":909},{\"id\":910},{\"id\":911},{\"id\":912},{\"id\":913},{\"id\":914},{\"id\":915},{\"id\":916},{\"id\":917},{\"id\":918},{\"id\":919},{\"id\":920},{\"id\":921},{\"id\":922},{\"id\":923},{\"id\":924},{\"id\":925},{\"id\":926},{\"id\":927},{\"id\":928},{\"id\":929},{\"id\":930},{\"id\":931},{\"id\":932},{\"id\":933},{\"id\":934},{\"id\":935},{\"id\":936},{\"id\":937},{\"id\":938},{\"id\":939},{\"id\":940},{\"id\":941},{\"id\":942},{\"id\":943},{\"id\":944},{\"id\":945},{\"id\":946},{\"id\":947},{\"id\":948},{\"id\":949},{\"id\":950},{\"id\":951},{\"id\":952},{\"id\":953},{\"id\":954},{\"id\":955},{\"id\":956},{\"id\":957},{\"id\":958},{\"id\":959},{\"id\":960},{\"id\":961},{\"id\":962},{\"id\":963},{\"id\":964},{\"id\":965},{\"id\":966},{\"id\":967},{\"id\":968},{\"id\":969},{\"id\":970},{\"id\":971},{\"id\":972},{\"id\":973},{\"id\":974},{\"id\":975},{\"id\":976},{\"id\":977},{\"id\":978},{\"id\":979},{\"id\":980},{\"id\":981},{\"id\":982},{\"id\":983},{\"id\":984},{\"id\":985},{\"id\":986},{\"id\":987},{\"id\":988},{\"id\":989},{\"id\":990},{\"id\":991},{\"id\":992},{\"id\":993},{\"id\":994},{\"id\":995},{\"id\":996},{\"id\":997},{\"id\":998},{\"id\":999},{\"id\":1000},{\"id\":1001},{\"id\":1002},{\"id\":1003},{\"id\":1004},{\"id\":1005},{\"id\":1006},{\"id\":1007},{\"id\":1008},{\"id\":1009},{\"id\":1010},{\"id\":1011},{\"id\":1012},{\"id\":1013},{\"id\":1014},{\"id\":1015},{\"id\":1016},{\"id\":1017},{\"id\":1018},{\"id\":1019},{\"id\":1020},{\"id\":1021},{\"id\":1022},{\"id\":1023},{\"id\":1024},{\"id\":1025},{\"id\":1026},{\"id\":1027},{\"id\":1028},{\"id\":1029},{\"id\":1030},{\"id\":1031},{\"id\":1032},{\"id\":1033},{\"id\":1034},{\"id\":1035},{\"id\":1036},{\"id\":1037},{\"id\":1038},{\"id\":1039},{\"id\":1040},{\"id\":1041},{\"id\":1042},{\"id\":1043},{\"id\":1044},{\"id\":1045},{\"id\":1046},{\"id\":1047},{\"id\":1048},{\"id\":1049},{\"id\":1050},{\"id\":1051},{\"id\":1052},{\"id\":1053},{\"id\":1054},{\"id\":1055},{\"id\":1056},{\"id\":1057},{\"id\":1058},{\"id\":1059},{\"id\":1060},{\"id\":1061},{\"id\":1062},{\"id\":1063},{\"id\":1064},{\"id\":1065},{\"id\":1066},{\"id\":1067},{\"id\":1068},{\"id\":1069},{\"id\":1070},{\"id\":1071},{\"id\":1072},{\"id\":1073},{\"id\":1074},{\"id\":1075},{\"id\":1076},{\"id\":1077},{\"id\":1078},{\"id\":1079},{\"id\":1080},{\"id\":1081},{\"id\":1082},{\"id\":1083},{\"id\":1084},{\"id\":1085},{\"id\":1086},{\"id\":1087},{\"id\":1088},{\"id\":1089},{\"id\":1090},{\"id\":1091},{\"id\":1092},{\"id\":1093},{\"id\":1094},{\"id\":1095},{\"id\":1096},{\"id\":1097},{\"id\":1098},{\"id\":1099},{\"id\":1100},{\"id\":1101},{\"id\":1102},{\"id\":1103},{\"id\":1104},{\"id\":1105},{\"id\":1106},{\"id\":1107},{\"id\":1108},{\"id\":1109},{\"id\":1110},{\"id\":1111},{\"id\":1112},{\"id\":1113},{\"id\":1114},{\"id\":1115},{\"id\":1116},{\"id\":1117},{\"id\":1118},{\"id\":1119},{\"id\":1120},{\"id\":1121},{\"id\":1122},{\"id\":1123},{\"id\":1124},{\"id\":1125},{\"id\":1126},{\"id\":1127},{\"id\":1128},{\"id\":1129},{\"id\":1130},{\"id\":1131},{\"id\":1132},{\"id\":1133},{\"id\":1134},{\"id\":1135},{\"id\":1136},{\"id\":1137},{\"id\":1138},{\"id\":1139},{\"id\":1140},{\"id\":1141},{\"id\":1142},{\"id\":1143},{\"id\":1144},{\"id\":1145},{\"id\":1146},{\"id\":1147},{\"id\":1148},{\"id\":1149},{\"id\":1150},{\"id\":1151},{\"id\":1152},{\"id\":1153},{\"id\":1154},{\"id\":1155},{\"id\":1156},{\"id\":1157},{\"id\":1158},{\"id\":1159},{\"id\":1160},{\"id\":1161},{\"id\":1162},{\"id\":1163},{\"id\":1164},{\"id\":1165},{\"id\":1166},{\"id\":1167},{\"id\":1168},{\"id\":1169},{\"id\":1170},{\"id\":1171},{\"id\":1172},{\"id\":1173},{\"id\":1174},{\"id\":1175},{\"id\":1176},{\"id\":1177},{\"id\":1178},{\"id\":1179},{\"id\":1180},{\"id\":1181},{\"id\":1182},{\"id\":1183},{\"id\":1184},{\"id\":1185},{\"id\":1186},{\"id\":1187},{\"id\":1188},{\"id\":1189},{\"id\":1190},{\"id\":1191},{\"id\":1192},{\"id\":1193},{\"id\":1194},{\"id\":1195},{\"id\":1196},{\"id\":1197},{\"id\":1198},{\"id\":1199},{\"id\":1200},{\"id\":1201},{\"id\":1202},{\"id\":1203},{\"id\":1204},{\"id\":1205},{\"id\":1206},{\"id\":1207},{\"id\":1208},{\"id\":1209},{\"id\":1210},{\"id\":1211},{\"id\":1212},{\"id\":1213},{\"id\":1214},{\"id\":1215},{\"id\":1216},{\"id\":1217},{\"id\":1218},{\"id\":1219},{\"id\":1220},{\"id\":1221},{\"id\":1222},{\"id\":1223},{\"id\":1224},{\"id\":1225},{\"id\":1226},{\"id\":1227},{\"id\":1228},{\"id\":1229},{\"id\":1230},{\"id\":1231},{\"id\":1232},{\"id\":1233},{\"id\":1234},{\"id\":1235},{\"id\":1236},{\"id\":1237},{\"id\":1238},{\"id\":1239},{\"id\":1240},{\"id\":1241},{\"id\":1242},{\"id\":1243},{\"id\":1244},{\"id\":1245},{\"id\":1246},{\"id\":1247},{\"id\":1248},{\"id\":1249},{\"id\":1250},{\"id\":1251},{\"id\":1252},{\"id\":1253},{\"id\":1254},{\"id\":1255},{\"id\":1256},{\"id\":1257},{\"id\":1258},{\"id\":1259},{\"id\":1260},{\"id\":1261},{\"id\":1262},{\"id\":1263},{\"id\":1264},{\"id\":1265},{\"id\":1266},{\"id\":1267},{\"id\":1268},{\"id\":1269},{\"id\":1270},{\"id\":1271},{\"id\":1272},{\"id\":1273},{\"id\":1274},{\"id\":1275},{\"id\":1276},{\"id\":1277},{\"id\":1278},{\"id\":1279},{\"id\":1280},{\"id\":1281},{\"id\":1282},{\"id\":1283},{\"id\":1284},{\"id\":1285},{\"id\":1286},{\"id\":1287},{\"id\":1288},{\"id\":1289},{\"id\":1290},{\"id\":1291},{\"id\":1292},{\"id\":1293},{\"id\":1294},{\"id\":1295},{\"id\":1296},{\"id\":1297},{\"id\":1298},{\"id\":1299},{\"id\":1300},{\"id\":1301},{\"id\":1302},{\"id\":1303},{\"id\":1304},{\"id\":1305},{\"id\":1306},{\"id\":1307},{\"id\":1308},{\"id\":1309},{\"id\":1310},{\"id\":1311},{\"id\":1312},{\"id\":1313},{\"id\":1314},{\"id\":1315},{\"id\":1316},{\"id\":1317},{\"id\":1318},{\"id\":1319},{\"id\":1320},{\"id\":1321},{\"id\":1322},{\"id\":1323},{\"id\":1324},{\"id\":1325},{\"id\":1326},{\"id\":1327},{\"id\":1328},{\"id\":1329},{\"id\":1330},{\"id\":1331},{\"id\":1332},{\"id\":1333},{\"id\":1334},{\"id\":1335},{\"id\":1336},{\"id\":1337},{\"id\":1338},{\"id\":1339},{\"id\":1340},{\"id\":1341},{\"id\":1342},{\"id\":1343},{\"id\":1344},{\"id\":1345},{\"id\":1346},{\"id\":1347},{\"id\":1348},{\"id\":1349},{\"id\":1350},{\"id\":1351},{\"id\":1352},{\"id\":1353},{\"id\":1354},{\"id\":1355},{\"id\":1356},{\"id\":1357},{\"id\":1358},{\"id\":1359},{\"id\":1360},{\"id\":1361},{\"id\":1362},{\"id\":1363},{\"id\":1364},{\"id\":1365},{\"id\":1366},{\"id\":1367},{\"id\":1368},{\"id\":1369},{\"id\":1370},{\"id\":1371},{\"id\":1372},{\"id\":1373},{\"id\":1374},{\"id\":1375},{\"id\":1376},{\"id\":1377},{\"id\":1378},{\"id\":1379},{\"id\":1380},{\"id\":1381},{\"id\":1382},{\"id\":1383},{\"id\":1384},{\"id\":1385},{\"id\":1386},{\"id\":1387},{\"id\":1388},{\"id\":1389},{\"id\":1390},{\"id\":1391},{\"id\":1392},{\"id\":1393},{\"id\":1394},{\"id\":1395},{\"id\":1396},{\"id\":1397},{\"id\":1398},{\"id\":1399},{\"id\":1400},{\"id\":1401},{\"id\":1402},{\"id\":1403},{\"id\":1404},{\"id\":1405},{\"id\":1406},{\"id\":1407},{\"id\":1408},{\"id\":1409},{\"id\":1410},{\"id\":1411},{\"id\":1412},{\"id\":1413},{\"id\":1414},{\"id\":1415},{\"id\":1416},{\"id\":1417},{\"id\":1418},{\"id\":1419},{\"id\":1420},{\"id\":1421},{\"id\":1422},{\"id\":1423},{\"id\":1424},{\"id\":1425},{\"id\":1426},{\"id\":1427},{\"id\":1428},{\"id\":1429},{\"id\":1430},{\"id\":1431},{\"id\":1432},{\"id\":1433},{\"id\":1434},{\"id\":1435},{\"id\":1436},{\"id\":1437},{\"id\":1438},{\"id\":1439},{\"id\":1440},{\"id\":1441},{\"id\":1442},{\"id\":1443},{\"id\":1444},{\"id\":1445},{\"id\":1446},{\"id\":1447},{\"id\":1448},{\"id\":1449},{\"id\":1450},{\"id\":1451},{\"id\":1452},{\"id\":1453},{\"id\":1454},{\"id\":1455},{\"id\":1456},{\"id\":1457},{\"id\":1458},{\"id\":1459},{\"id\":1460},{\"id\":1461},{\"id\":1462},{\"id\":1463},{\"id\":1464},{\"id\":1465},{\"id\":1466},{\"id\":1467},{\"id\":1468},{\"id\":1469},{\"id\":1470},{\"id\":1471},{\"id\":1472},{\"id\":1473},{\"id\":1474},{\"id\":1475},{\"id\":1476},{\"id\":1477},{\"id\":1478},{\"id\":1479},{\"id\":1480},{\"id\":1481},{\"id\":1482},{\"id\":1483},{\"id\":1484},{\"id\":1485},{\"id\":1486},{\"id\":1487},{\"id\":1488},{\"id\":1489},{\"id\":1490},{\"id\":1491},{\"id\":1492},{\"id\":1493},{\"id\":1494},{\"id\":1495},{\"id\":1496},{\"id\":1497},{\"id\":1498},{\"id\":1499},{\"id\":1500},{\"id\":1501},{\"id\":1502},{\"id\":1503},{\"id\":1504},{\"id\":1505},{\"id\":1506},{\"id\":1507},{\"id\":1508},{\"id\":1509},{\"id\":1510},{\"id\":1511},{\"id\":1512},{\"id\":1513},{\"id\":1514},{\"id\":1515},{\"id\":1516},{\"id\":1517},{\"id\":1518},{\"id\":1519},{\"id\":1520},{\"id\":1521},{\"id\":1522},{\"id\":1523},{\"id\":1524},{\"id\":1525},{\"id\":1526},{\"id\":1527},{\"id\":1528},{\"id\":1529},{\"id\":1530},{\"id\":1531},{\"id\":1532},{\"id\":1533},{\"id\":1534},{\"id\":1535},{\"id\":1536},{\"id\":1537},{\"id\":1538},{\"id\":1539},{\"id\":1540},{\"id\":1541},{\"id\":1542},{\"id\":1543},{\"id\":1544},{\"id\":1545},{\"id\":1546},{\"id\":1547},{\"id\":1548},{\"id\":1549},{\"id\":1550},{\"id\":1551},{\"id\":1552},{\"id\":1553},{\"id\":1554},{\"id\":1555},{\"id\":1556},{\"id\":1557},{\"id\":1558},{\"id\":1559},{\"id\":1560},{\"id\":1561},{\"id\":1562},{\"id\":1563},{\"id\":1564},{\"id\":1565},{\"id\":1566},{\"id\":1567},{\"id\":1568},{\"id\":1569},{\"id\":1570},{\"id\":1571},{\"id\":1572},{\"id\":1573},{\"id\":1574},{\"id\":1575},{\"id\":1576},{\"id\":1577},{\"id\":1578},{\"id\":1579},{\"id\":1580},{\"id\":1581},{\"id\":1582},{\"id\":1583},{\"id\":1584},{\"id\":1585},{\"id\":1586},{\"id\":1587},{\"id\":1588},{\"id\":1589},{\"id\":1590},{\"id\":1591},{\"id\":1592},{\"id\":1593},{\"id\":1594},{\"id\":1595},{\"id\":1596},{\"id\":1597},{\"id\":1598},{\"id\":1599},{\"id\":1600},{\"id\":1601},{\"id\":1602},{\"id\":1603},{\"id\":1604},{\"id\":1605},{\"id\":1606},{\"id\":1607},{\"id\":1608},{\"id\":1609},{\"id\":1610},{\"id\":1611},{\"id\":1612},{\"id\":1613},{\"id\":1614},{\"id\":1615},{\"id\":1616},{\"id\":1617},{\"id\":1618},{\"id\":1619},{\"id\":1620},{\"id\":1621},{\"id\":1622},{\"id\":1623},{\"id\":1624},{\"id\":1625},{\"id\":1626},{\"id\":1627},{\"id\":1628},{\"id\":1629},{\"id\":1630},{\"id\":1631},{\"id\":1632},{\"id\":1633},{\"id\":1634},{\"id\":1635},{\"id\":1636},{\"id\":1637},{\"id\":1638},{\"id\":1639},{\"id\":1640},{\"id\":1641},{\"id\":1642},{\"id\":1643},{\"id\":1644},{\"id\":1645},{\"id\":1646},{\"id\":1647},{\"id\":1648},{\"id\":1649},{\"id\":1650},{\"id\":1651},{\"id\":1652},{\"id\":1653},{\"id\":1654},{\"id\":1655},{\"id\":1656},{\"id\":1657},{\"id\":1658},{\"id\":1659},{\"id\":1660},{\"id\":1661},{\"id\":1662},{\"id\":1663},{\"id\":1664},{\"id\":1665},{\"id\":1666},{\"id\":1667},{\"id\":1668},{\"id\":1669},{\"id\":1670},{\"id\":1671},{\"id\":1672},{\"id\":1673},{\"id\":1674},{\"id\":1675},{\"id\":1676},{\"id\":1677},{\"id\":1678},{\"id\":1679},{\"id\":1680},{\"id\":1681},{\"id\":1682},{\"id\":1683},{\"id\":1684},{\"id\":1685},{\"id\":1686},{\"id\":1687},{\"id\":1688},{\"id\":1689},{\"id\":1690},{\"id\":1691},{\"id\":1692},{\"id\":1693},{\"id\":1694},{\"id\":1695},{\"id\":1696},{\"id\":1697},{\"id\":1698},{\"id\":1699},{\"id\":1700},{\"id\":1701},{\"id\":1702},{\"id\":1703},{\"id\":1704},{\"id\":1705},{\"id\":1706},{\"id\":1707},{\"id\":1708},{\"id\":1709},{\"id\":1710},{\"id\":1711},{\"id\":1712},{\"id\":1713},{\"id\":1714},{\"id\":1715},{\"id\":1716},{\"id\":1717},{\"id\":1718},{\"id\":1719},{\"id\":1720},{\"id\":1721},{\"id\":1722},{\"id\":1723},{\"id\":1724},{\"id\":1725},{\"id\":1726},{\"id\":1727},{\"id\":1728},{\"id\":1729},{\"id\":1730},{\"id\":1731},{\"id\":1732},{\"id\":1733},{\"id\":1734},{\"id\":1735},{\"id\":1736},{\"id\":1737},{\"id\":1738},{\"id\":1739},{\"id\":1740},{\"id\":1741},{\"id\":1742},{\"id\":1743},{\"id\":1744},{\"id\":1745},{\"id\":1746},{\"id\":1747},{\"id\":1748},{\"id\":1749},{\"id\":1750},{\"id\":1751},{\"id\":1752},{\"id\":1753},{\"id\":1754},{\"id\":1755},{\"id\":1756},{\"id\":1757},{\"id\":1758},{\"id\":1759},{\"id\":1760},{\"id\":1761},{\"id\":1762},{\"id\":1763},{\"id\":1764},{\"id\":1765},{\"id\":1766},{\"id\":1767},{\"id\":1768},{\"id\":1769},{\"id\":1770},{\"id\":1771},{\"id\":1772},{\"id\":1773},{\"id\":1774},{\"id\":1775},{\"id\":1776},{\"id\":1777},{\"id\":1778},{\"id\":1779},{\"id\":1780},{\"id\":1781},{\"id\":1782},{\"id\":1783},{\"id\":1784},{\"id\":1785},{\"id\":1786},{\"id\":1787},{\"id\":1788},{\"id\":1789},{\"id\":1790},{\"id\":1791},{\"id\":1792},{\"id\":1793},{\"id\":1794},{\"id\":1795},{\"id\":1796},{\"id\":1797},{\"id\":1798},{\"id\":1799},{\"id\":1800},{\"id\":1801},{\"id\":1802},{\"id\":1803},{\"id\":1804},{\"id\":1805},{\"id\":1806},{\"id\":1807},{\"id\":1808},{\"id\":1809},{\"id\":1810},{\"id\":1811},{\"id\":1812},{\"id\":1813},{\"id\":1814},{\"id\":1815},{\"id\":1816},{\"id\":1817},{\"id\":1818},{\"id\":1819},{\"id\":1820},{\"id\":1821},{\"id\":1822},{\"id\":1823},{\"id\":1824},{\"id\":1825},{\"id\":1826},{\"id\":1827},{\"id\":1828},{\"id\":1829},{\"id\":1830},{\"id\":1831},{\"id\":1832},{\"id\":1833},{\"id\":1834},{\"id\":1835},{\"id\":1836},{\"id\":1837},{\"id\":1838},{\"id\":1839},{\"id\":1840},{\"id\":1841},{\"id\":1842},{\"id\":1843},{\"id\":1844},{\"id\":1845},{\"id\":1846},{\"id\":1847},{\"id\":1848},{\"id\":1849},{\"id\":1850},{\"id\":1851},{\"id\":1852},{\"id\":1853},{\"id\":1854},{\"id\":1855},{\"id\":1856},{\"id\":1857},{\"id\":1858},{\"id\":1859},{\"id\":1860},{\"id\":1861},{\"id\":1862},{\"id\":1863},{\"id\":1864},{\"id\":1865},{\"id\":1866},{\"id\":1867},{\"id\":1868},{\"id\":1869},{\"id\":1870},{\"id\":1871},{\"id\":1872},{\"id\":1873},{\"id\":1874},{\"id\":1875},{\"id\":1876},{\"id\":1877},{\"id\":1878},{\"id\":1879},{\"id\":1880},{\"id\":1881},{\"id\":1882},{\"id\":1883},{\"id\":1884},{\"id\":1885},{\"id\":1886},{\"id\":1887},{\"id\":1888},{\"id\":1889},{\"id\":1890},{\"id\":1891},{\"id\":1892},{\"id\":1893},{\"id\":1894},{\"id\":1895},{\"id\":1896},{\"id\":1897},{\"id\":1898},{\"id\":1899},{\"id\":1900},{\"id\":1901},{\"id\":1902},{\"id\":1903},{\"id\":1904},{\"id\":1905},{\"id\":1906},{\"id\":1907},{\"id\":1908},{\"id\":1909},{\"id\":1910},{\"id\":1911},{\"id\":1912},{\"id\":1913},{\"id\":1914},{\"id\":1915},{\"id\":1916},{\"id\":1917},{\"id\":1918},{\"id\":1919},{\"id\":1920},{\"id\":1921},{\"id\":1922},{\"id\":1923},{\"id\":1924},{\"id\":1925},{\"id\":1926},{\"id\":1927},{\"id\":1928},{\"id\":1929},{\"id\":1930},{\"id\":1931},{\"id\":1932},{\"id\":1933},{\"id\":1934},{\"id\":1935},{\"id\":1936},{\"id\":1937},{\"id\":1938},{\"id\":1939},{\"id\":1940},{\"id\":1941},{\"id\":1942},{\"id\":1943},{\"id\":1944},{\"id\":1945},{\"id\":1946},{\"id\":1947},{\"id\":1948},{\"id\":1949},{\"id\":1950},{\"id\":1951},{\"id\":1952},{\"id\":1953},{\"id\":1954},{\"id\":1955},{\"id\":1956},{\"id\":1957},{\"id\":1958},{\"id\":1959},{\"id\":1960},{\"id\":1961},{\"id\":1962},{\"id\":1963},{\"id\":1964},{\"id\":1965},{\"id\":1966},{\"id\":1967},{\"id\":1968},{\"id\":1969},{\"id\":1970},{\"id\":1971},{\"id\":1972},{\"id\":1973},{\"id\":1974},{\"id\":1975},{\"id\":1976},{\"id\":1977},{\"id\":1978},{\"id\":1979},{\"id\":1980},{\"id\":1981},{\"id\":1982},{\"id\":1983},{\"id\":1984},{\"id\":1985},{\"id\":1986},{\"id\":1987},{\"id\":1988},{\"id\":1989},{\"id\":1990},{\"id\":1991},{\"id\":1992},{\"id\":1993},{\"id\":1994},{\"id\":1995},{\"id\":1996},{\"id\":1997},{\"id\":1998},{\"id\":1999},{\"id\":2000},{\"id\":2001},{\"id\":2002},{\"id\":2003},{\"id\":2004},{\"id\":2005},{\"id\":2006},{\"id\":2007},{\"id\":2008},{\"id\":2009},{\"id\":2010},{\"id\":2011},{\"id\":2012},{\"id\":2013},{\"id\":2014},{\"id\":2015},{\"id\":2016},{\"id\":2017},{\"id\":2018},{\"id\":2019},{\"id\":2020},{\"id\":2021},{\"id\":2022},{\"id\":2023},{\"id\":2024},{\"id\":2025},{\"id\":2026},{\"id\":2027},{\"id\":2028},{\"id\":2029},{\"id\":2030},{\"id\":2031},{\"id\":2032},{\"id\":2033},{\"id\":2034},{\"id\":2035},{\"id\":2036},{\"id\":2037},{\"id\":2038},{\"id\":2039},{\"id\":2040},{\"id\":2041},{\"id\":2042},{\"id\":2043},{\"id\":2044},{\"id\":2045},{\"id\":2046},{\"id\":2047},{\"id\":2048},{\"id\":2049},{\"id\":2050},{\"id\":2051},{\"id\":2052},{\"id\":2053},{\"id\":2054},{\"id\":2055},{\"id\":2056},{\"id\":2057},{\"id\":2058},{\"id\":2059},{\"id\":2060},{\"id\":2061},{\"id\":2062},{\"id\":2063},{\"id\":2064},{\"id\":2065},{\"id\":2066},{\"id\":2067},{\"id\":2068},{\"id\":2069},{\"id\":2070},{\"id\":2071},{\"id\":2072},{\"id\":2073},{\"id\":2074},{\"id\":2075},{\"id\":2076},{\"id\":2077},{\"id\":2078},{\"id\":2079},{\"id\":2080},{\"id\":2081},{\"id\":2082},{\"id\":2083},{\"id\":2084},{\"id\":2085},{\"id\":2086},{\"id\":2087},{\"id\":2088},{\"id\":2089},{\"id\":2090},{\"id\":2091},{\"id\":2092},{\"id\":2093},{\"id\":2094},{\"id\":2095},{\"id\":2096},{\"id\":2097},{\"id\":2098},{\"id\":2099},{\"id\":2100},{\"id\":2101},{\"id\":2102},{\"id\":2103},{\"id\":2104},{\"id\":2105},{\"id\":2106},{\"id\":2107},{\"id\":2108},{\"id\":2109},{\"id\":2110},{\"id\":2111},{\"id\":2112},{\"id\":2113},{\"id\":2114},{\"id\":2115},{\"id\":2116},{\"id\":2117},{\"id\":2118},{\"id\":2119},{\"id\":2120},{\"id\":2121},{\"id\":2122},{\"id\":2123},{\"id\":2124},{\"id\":2125},{\"id\":2126},{\"id\":2127},{\"id\":2128},{\"id\":2129},{\"id\":2130},{\"id\":2131},{\"id\":2132},{\"id\":2133},{\"id\":2134},{\"id\":2135},{\"id\":2136},{\"id\":2137},{\"id\":2138},{\"id\":2139},{\"id\":2140},{\"id\":2141},{\"id\":2142},{\"id\":2143},{\"id\":2144},{\"id\":2145},{\"id\":2146},{\"id\":2147},{\"id\":2148},{\"id\":2149},{\"id\":2150},{\"id\":2151},{\"id\":2152},{\"id\":2153},{\"id\":2154},{\"id\":2155},{\"id\":2156},{\"id\":2157},{\"id\":2158},{\"id\":2159},{\"id\":2160},{\"id\":2161},{\"id\":2162},{\"id\":2163},{\"id\":2164},{\"id\":2165},{\"id\":2166},{\"id\":2167},{\"id\":2168},{\"id\":2169},{\"id\":2170},{\"id\":2171},{\"id\":2172},{\"id\":2173},{\"id\":2174},{\"id\":2175},{\"id\":2176},{\"id\":2177},{\"id\":2178},{\"id\":2179},{\"id\":2180},{\"id\":2181},{\"id\":2182},{\"id\":2183},{\"id\":2184},{\"id\":2185},{\"id\":2186},{\"id\":2187},{\"id\":2188},{\"id\":2189},{\"id\":2190},{\"id\":2191},{\"id\":2192},{\"id\":2193},{\"id\":2194},{\"id\":2195},{\"id\":2196},{\"id\":2197},{\"id\":2198},{\"id\":2199},{\"id\":2200},{\"id\":2201},{\"id\":2202},{\"id\":2203},{\"id\":2204},{\"id\":2205},{\"id\":2206},{\"id\":2207},{\"id\":2208},{\"id\":2209},{\"id\":2210},{\"id\":2211},{\"id\":2212},{\"id\":2213},{\"id\":2214},{\"id\":2215},{\"id\":2216},{\"id\":2217},{\"id\":2218},{\"id\":2219},{\"id\":2220},{\"id\":2221},{\"id\":2222},{\"id\":2223},{\"id\":2224},{\"id\":2225},{\"id\":2226},{\"id\":2227},{\"id\":2228},{\"id\":2229},{\"id\":2230},{\"id\":2231},{\"id\":2232},{\"id\":2233},{\"id\":2234},{\"id\":2235},{\"id\":2236},{\"id\":2237},{\"id\":2238},{\"id\":2239},{\"id\":2240},{\"id\":2241},{\"id\":2242},{\"id\":2243},{\"id\":2244},{\"id\":2245},{\"id\":2246},{\"id\":2247},{\"id\":2248},{\"id\":2249},{\"id\":2250},{\"id\":2251},{\"id\":2252},{\"id\":2253},{\"id\":2254},{\"id\":2255},{\"id\":2256},{\"id\":2257},{\"id\":2258},{\"id\":2259},{\"id\":2260},{\"id\":2261},{\"id\":2262},{\"id\":2263},{\"id\":2264},{\"id\":2265},{\"id\":2266},{\"id\":2267},{\"id\":2268},{\"id\":2269},{\"id\":2270},{\"id\":2271},{\"id\":2272},{\"id\":2273},{\"id\":2274},{\"id\":2275},{\"id\":2276},{\"id\":2277},{\"id\":2278},{\"id\":2279},{\"id\":2280},{\"id\":2281},{\"id\":2282},{\"id\":2283},{\"id\":2284},{\"id\":2285},{\"id\":2286},{\"id\":2287},{\"id\":2288},{\"id\":2289},{\"id\":2290},{\"id\":2291},{\"id\":2292},{\"id\":2293},{\"id\":2294},{\"id\":2295},{\"id\":2296},{\"id\":2297},{\"id\":2298},{\"id\":2299},{\"id\":2300},{\"id\":2301},{\"id\":2302},{\"id\":2303},{\"id\":2304},{\"id\":2305},{\"id\":2306},{\"id\":2307},{\"id\":2308},{\"id\":2309},{\"id\":2310},{\"id\":2311},{\"id\":2312},{\"id\":2313},{\"id\":2314},{\"id\":2315},{\"id\":2316},{\"id\":2317},{\"id\":2318},{\"id\":2319},{\"id\":2320},{\"id\":2321},{\"id\":2322},{\"id\":2323},{\"id\":2324},{\"id\":2325},{\"id\":2326},{\"id\":2327},{\"id\":2328},{\"id\":2329},{\"id\":2330},{\"id\":2331},{\"id\":2332},{\"id\":2333},{\"id\":2334},{\"id\":2335},{\"id\":2336},{\"id\":2337},{\"id\":2338},{\"id\":2339},{\"id\":2340},{\"id\":2341},{\"id\":2342},{\"id\":2343},{\"id\":2344},{\"id\":2345},{\"id\":2346},{\"id\":2347},{\"id\":2348},{\"id\":2349},{\"id\":2350},{\"id\":2351},{\"id\":2352},{\"id\":2353},{\"id\":2354},{\"id\":2355},{\"id\":2356},{\"id\":2357},{\"id\":2358},{\"id\":2359},{\"id\":2360},{\"id\":2361},{\"id\":2362},{\"id\":2363},{\"id\":2364},{\"id\":2365},{\"id\":2366},{\"id\":2367},{\"id\":2368},{\"id\":2369},{\"id\":2370},{\"id\":2371},{\"id\":2372},{\"id\":2373},{\"id\":2374},{\"id\":2375},{\"id\":2376},{\"id\":2377},{\"id\":2378},{\"id\":2379},{\"id\":2380},{\"id\":2381},{\"id\":2382},{\"id\":2383},{\"id\":2384},{\"id\":2385},{\"id\":2386},{\"id\":2387},{\"id\":2388},{\"id\":2389},{\"id\":2390},{\"id\":2391},{\"id\":2392},{\"id\":2393},{\"id\":2394},{\"id\":2395},{\"id\":2396},{\"id\":2397},{\"id\":2398},{\"id\":2399},{\"id\":2400},{\"id\":2401},{\"id\":2402},{\"id\":2403},{\"id\":2404},{\"id\":2405},{\"id\":2406},{\"id\":2407},{\"id\":2408},{\"id\":2409},{\"id\":2410},{\"id\":2411},{\"id\":2412},{\"id\":2413},{\"id\":2414},{\"id\":2415},{\"id\":2416},{\"id\":2417},{\"id\":2418},{\"id\":2419},{\"id\":2420},{\"id\":2421},{\"id\":2422},{\"id\":2423},{\"id\":2424},{\"id\":2425},{\"id\":2426},{\"id\":2427},{\"id\":2428},{\"id\":2429},{\"id\":2430},{\"id\":2431},{\"id\":2432},{\"id\":2433},{\"id\":2434},{\"id\":2435},{\"id\":2436},{\"id\":2437},{\"id\":2438},{\"id\":2439},{\"id\":2440},{\"id\":2441},{\"id\":2442},{\"id\":2443},{\"id\":2444},{\"id\":2445},{\"id\":2446},{\"id\":2447},{\"id\":2448},{\"id\":2449},{\"id\":2450},{\"id\":2451},{\"id\":2452},{\"id\":2453},{\"id\":2454},{\"id\":2455},{\"id\":2456},{\"id\":2457},{\"id\":2458},{\"id\":2459},{\"id\":2460},{\"id\":2461},{\"id\":2462},{\"id\":2463},{\"id\":2464},{\"id\":2465},{\"id\":2466},{\"id\":2467},{\"id\":2468},{\"id\":2469},{\"id\":2470},{\"id\":2471},{\"id\":2472},{\"id\":2473},{\"id\":2474},{\"id\":2475},{\"id\":2476},{\"id\":2477},{\"id\":2478},{\"id\":2479},{\"id\":2480},{\"id\":2481},{\"id\":2482},{\"id\":2483},{\"id\":2484},{\"id\":2485},{\"id\":2486},{\"id\":2487},{\"id\":2488},{\"id\":2489},{\"id\":2490},{\"id\":2491},{\"id\":2492},{\"id\":2493},{\"id\":2494},{\"id\":2495},{\"id\":2496},{\"id\":2497},{\"id\":2498},{\"id\":2499},{\"id\":2500},{\"id\":2501},{\"id\":2502},{\"id\":2503},{\"id\":2504},{\"id\":2505},{\"id\":2506},{\"id\":2507},{\"id\":2508},{\"id\":2509},{\"id\":2510},{\"id\":2511},{\"id\":2512},{\"id\":2513},{\"id\":2514},{\"id\":2515},{\"id\":2516},{\"id\":2517},{\"id\":2518},{\"id\":2519},{\"id\":2520},{\"id\":2521},{\"id\":2522},{\"id\":2523},{\"id\":2524},{\"id\":2525},{\"id\":2526},{\"id\":2527},{\"id\":2528},{\"id\":2529},{\"id\":2530},{\"id\":2531},{\"id\":2532},{\"id\":2533},{\"id\":2534},{\"id\":2535},{\"id\":2536},{\"id\":2537},{\"id\":2538},{\"id\":2539},{\"id\":2540},{\"id\":2541},{\"id\":2542},{\"id\":2543},{\"id\":2544},{\"id\":2545},{\"id\":2546},{\"id\":2547},{\"id\":2548},{\"id\":2549},{\"id\":2550},{\"id\":2551},{\"id\":2552},{\"id\":2553},{\"id\":2554},{\"id\":2555},{\"id\":2556},{\"id\":2557},{\"id\":2558},{\"id\":2559},{\"id\":2560},{\"id\":2561},{\"id\":2562},{\"id\":2563},{\"id\":2564},{\"id\":2565},{\"id\":2566},{\"id\":2567},{\"id\":2568},{\"id\":2569},{\"id\":2570},{\"id\":2571},{\"id\":2572},{\"id\":2573},{\"id\":2574},{\"id\":2575},{\"id\":2576},{\"id\":2577},{\"id\":2578},{\"id\":2579},{\"id\":2580},{\"id\":2581},{\"id\":2582},{\"id\":2583},{\"id\":2584},{\"id\":2585},{\"id\":2586},{\"id\":2587},{\"id\":2588},{\"id\":2589},{\"id\":2590},{\"id\":2591},{\"id\":2592},{\"nodeType\":3,\"id\":2596,\"textContent\":\" // Track clicks on page $(document).ready(function() { $(\\\".control\\\").click(function(e) { e.stopImmediatePropagation(); clicks = clicks + 1; console.log(clicks); }); }); $('.userid').html(sid); // console.log(\\\"start of clicked array: \\\"+clicked); // console.log(\\\"start of hovered string: \\\"+hovered); //set correct answers for each question var triangular_answers = { \\\"acme.starttime.1\\\" : [\\\"F\\\"], \\\"acme.starts.1\\\" : [\\\"K\\\"], \\\"acme.meets.1\\\" : [\\\"F\\\"], \\\"acme.endtime.1\\\" : [\\\"H\\\"], \\\"acme.midpoint.1\\\" : [\\\"O\\\"], \\\"acme.starttime.2\\\" : [\\\"F\\\"], \\\"acme.starts.2\\\" : [\\\"K\\\"], \\\"acme.meets.2\\\" : [\\\"F\\\"], \\\"acme.endtime.2\\\" : [\\\"H\\\"], \\\"acme.midpoint.2\\\" : [\\\"A\\\"], \\\"bigset.duration.1\\\" : [\\\"E\\\",\\\"G\\\"], \\\"bigset.duration+starts.1\\\" : [\\\"X\\\",\\\"O\\\"], \\\"bigset.duration+contained.1\\\" : [\\\"G\\\"], \\\"bigset.starttime+before+endtime+during.1\\\": [\\\"I\\\"], \\\"bigset.ends.1\\\" : [\\\"E\\\"], \\\"bigset.duration.2\\\" : [\\\"E\\\",\\\"G\\\"], \\\"bigset.duration+starts.2\\\" : [\\\"X\\\",\\\"O\\\"], \\\"bigset.duration+contained.2\\\" : [\\\"G\\\"], \\\"bigset.starttime+before+endtime+during.2\\\":[\\\"I\\\"], \\\"bigset.ends.2\\\" : [\\\"E\\\"], \\\"bigset.starttime.1\\\" : [\\\"M\\\",\\\"L\\\"], \\\"bigset.starts.1\\\" : [\\\"G\\\"], \\\"bigset.meets.1\\\" : [\\\"E\\\",\\\"F\\\"], \\\"bigset.endtime.1\\\" : [\\\"X\\\"], \\\"bigset.midpoint.1\\\" : [\\\"K\\\",\\\"X\\\"], \\\"bigset.starttime.2\\\" : [\\\"M\\\",\\\"L\\\"], \\\"bigset.starts.2\\\" : [\\\"G\\\"], \\\"bigset.meets.2\\\" : [\\\"E\\\",\\\"F\\\"], \\\"bigset.endtime.2\\\" : [\\\"X\\\"], \\\"bigset.midpoint.2\\\" : [\\\"K\\\",\\\"X\\\"] } var orthogonal_answers = { \\\"acme.starttime.1\\\" : [\\\"A\\\"], \\\"acme.starts.1\\\" : [\\\"E\\\"], \\\"acme.meets.1\\\" : [\\\"Z\\\"], \\\"acme.endtime.1\\\" : [\\\"U\\\"], \\\"acme.midpoint.1\\\" : [\\\"U\\\"], \\\"acme.starttime.2\\\" : [\\\"0\\\"], \\\"acme.starts.2\\\" : [\\\"0\\\"], \\\"acme.meets.2\\\" : [\\\"0\\\"], \\\"acme.endtime.2\\\" : [\\\"0\\\"], \\\"acme.midpoint.2\\\" : [\\\"0\\\"], \\\"bigset.duration.1\\\" : [\\\"E\\\",\\\"G\\\"], \\\"bigset.duration+starts.1\\\" : [\\\"F\\\",\\\"B\\\"], \\\"bigset.duration+contained.1\\\" : [\\\"E\\\"], \\\"bigset.starttime+before+endtime+during.1\\\": [\\\"I\\\"], \\\"bigset.ends.1\\\" : [\\\"X\\\"], \\\"bigset.duration.2\\\" : [\\\"E\\\",\\\"G\\\"], \\\"bigset.duration+starts.2\\\" : [\\\"F\\\",\\\"B\\\"], \\\"bigset.duration+contained.2\\\" : [\\\"E\\\"], \\\"bigset.starttime+before+endtime+during.2\\\":[\\\"I\\\"], \\\"bigset.ends.2\\\" : [\\\"X\\\"], \\\"bigset.starttime.1\\\" : [\\\"F\\\",\\\"B\\\"], \\\"bigset.starts.1\\\" : [\\\"B\\\"], \\\"bigset.meets.1\\\" : [\\\"F\\\",\\\"X\\\"], \\\"bigset.endtime.1\\\" : [\\\"B\\\"], \\\"bigset.midpoint.1\\\" : [\\\"E\\\",\\\"F\\\"], \\\"bigset.starttime.2\\\" : [\\\"F\\\",\\\"B\\\"], \\\"bigset.starts.2\\\" : [\\\"B\\\"], \\\"bigset.meets.2\\\" : [\\\"F\\\",\\\"X\\\"], \\\"bigset.endtime.2\\\" : [\\\"B\\\"], \\\"bigset.midpoint.2\\\" : [\\\"E\\\",\\\"F\\\"] } //display the question and answer buttons based on input values from jsPsych document.getElementById(scenario+\\\".\\\"+question).style.display = \\\"block\\\"; if (question == \\\"strategy\\\") {document.getElementById(\\\"strategyButton\\\").style.display = \\\"block\\\";} else {document.getElementById(\\\"testingButton\\\").style.display = \\\"block\\\";} //---------SET PROPERTIES OF THE GRAPH -------------// // set the dimensions and margins of the graph var margin = {top: 25, right: 30, bottom: 90, left: 100}, width = 800, height = 800; var intersects = false; //default value for intersects scaffold var xAxisTitle, yAxisTitle; var datafile =\\\"\\\"; // SET AXIS VALUES if (axis == 1){ axis = \\\"Orthogonal-XInside-YFull\\\"; } else if (axis == 2){ axis = \\\"Orthogonal-XInside-YPartial\\\"; } else if (axis ==3){ axis = \\\"Triangular-XInside-YInside\\\"; } else if (axis ==4){ axis = \\\"Orthogonal-XInside-YInside\\\"; } else if (axis ==5){ axis = \\\"Orthogonal-XFull-YFull\\\"; } // SET EXPLICIT SCAFFOLD FEATURES if (explicit ==2 && axis != \\\"diagonal\\\"){ scaffold = 2; intersects = false; } else if (explicit == 2 && axis == \\\"diagonal\\\"){ scaffold = 2; intersects = false; } //TODO: not sure if above two lines are still valid since leaders are now generated on the fly else if (explicit == 3){ $('#hint-interactive').css(\\\"display\\\",\\\"block\\\"); //display textimage scaffold intersects = true; } //SET DATA FILE FOR IMPLICIT SCAFFOLD if (impasse == 1){ datafile = \\\"../views/src/data/acme_nonimpasse.csv\\\"; } else if (impasse == 2){ datafile = \\\"../views/src/data/acme_impasse.csv\\\"; } //OVERRIDE DATA FILE FOR NON-SCAFFOLD QUESTIONS if (q > 5) { //override data file if q# is greater than 5 datafile = \\\"../views/src/data/bigset.csv\\\"; console.log(\\\"override data file\\\"); $('#orthogonal-image').css(\\\"display\\\",\\\"none\\\"); //display textimage scaffold $('#diagonal-image').css(\\\"display\\\",\\\"none\\\"); //display textimage scaffold $('#hint-interactive').css(\\\"display\\\",\\\"none\\\"); //display textimage scaffold intersects = false; } // //---------CREATE THE SVG ------------------------// var svg = d3.select(\\\".d3container\\\").append(\\\"svg\\\") .attr(\\\"width\\\", width + margin.left + margin.right) .attr(\\\"height\\\", height + margin.top + margin.bottom) .append(\\\"g\\\") .attr(\\\"transform\\\", \\\"translate(\\\" + margin.left + \\\",\\\" + margin.top + \\\")\\\"); //---------DRAW THE GRAPH ------------------------// xAxisTitle = \\\"START & END TIME (time of day)\\\"; yAxisTitle = \\\"DURATION (in hours)\\\"; drawTriangleModel(datafile,intersects,axis,scaffold,q); \"},{\"id\":2593},{\"id\":2594},{\"nodeType\":3,\"id\":2597,\"textContent\":\" //MOUSE LOGGING SCRIPT var mouseLog = [] var xwidth = $(document).width(); var xheight = $(document).width(); mouseLog.push(\\\"{x:\\\"+xwidth+\\\",y:\\\"+xheight+\\\",t:\\\"+\\\"0};\\\") document.onmousemove = function(e){ var pageCoords = \\\"{x:\\\" + e.pageX + \\\",y:\\\"+ e.pageY +\\\",t:\\\"+ Date.now()+ \\\"};\\\" ; mouseLog.push(pageCoords); // console.log(pageCoords); }; \"},{\"id\":2595}],[],[],[]]}"
    },
    {
      "sequence": 2,
      "data": "{\"f\":\"applyChanged\",\"args\":[[],[{\"nodeType\":1,\"id\":2598,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-text-preamble\",\"class\":\"jspsych-survey-text-preamble\"},\"parentNode\":{\"id\":55}},{\"nodeType\":1,\"id\":2599,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-text-0\",\"class\":\"jspsych-survey-text-question\"},\"previousSibling\":{\"id\":2598},\"parentNode\":{\"id\":55}},{\"nodeType\":1,\"id\":2600,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-text-1\",\"class\":\"jspsych-survey-text-question\"},\"previousSibling\":{\"id\":2599},\"parentNode\":{\"id\":55}},{\"nodeType\":1,\"id\":2601,\"tagName\":\"BUTTON\",\"attributes\":{\"id\":\"jspsych-survey-text-next\",\"class\":\"jspsych-btn jspsych-survey-text\"},\"previousSibling\":{\"id\":2600},\"parentNode\":{\"id\":55}},{\"nodeType\":1,\"id\":2602,\"tagName\":\"P\",\"attributes\":{\"class\":\"jspsych-survey-text\"},\"parentNode\":{\"id\":2599}},{\"nodeType\":1,\"id\":2603,\"tagName\":\"TEXTAREA\",\"attributes\":{\"name\":\"#jspsych-survey-text-response-0\",\"cols\":\"40\",\"rows\":\"1\"},\"previousSibling\":{\"id\":2602},\"parentNode\":{\"id\":2599}},{\"nodeType\":3,\"id\":2604,\"textContent\":\"What is your age?\",\"parentNode\":{\"id\":2602}},{\"nodeType\":1,\"id\":2605,\"tagName\":\"P\",\"attributes\":{\"class\":\"jspsych-survey-text\"},\"parentNode\":{\"id\":2600}},{\"nodeType\":1,\"id\":2606,\"tagName\":\"TEXTAREA\",\"attributes\":{\"name\":\"#jspsych-survey-text-response-1\",\"cols\":\"40\",\"rows\":\"1\"},\"previousSibling\":{\"id\":2605},\"parentNode\":{\"id\":2600}},{\"nodeType\":3,\"id\":2607,\"textContent\":\"In what country were you born?\",\"parentNode\":{\"id\":2605}},{\"nodeType\":3,\"id\":2608,\"textContent\":\"Submit Answers\",\"parentNode\":{\"id\":2601}}],[],[]]}"
    },
    {
      "sequence": 3,
      "data": "{\"f\":\"applyChanged\",\"args\":[[{\"id\":2598},{\"id\":2599},{\"id\":2602},{\"id\":2604},{\"id\":2603},{\"id\":2600},{\"id\":2605},{\"id\":2607},{\"id\":2606},{\"id\":2601},{\"id\":2608}],[],[],[]]}"
    },
    {
      "sequence": 4,
      "data": "{\"f\":\"applyChanged\",\"args\":[[],[{\"nodeType\":1,\"id\":2609,\"tagName\":\"FORM\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-form\"},\"parentNode\":{\"id\":55}},{\"nodeType\":1,\"id\":2610,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-preamble\",\"class\":\"jspsych-survey-multi-choice-preamble\"},\"parentNode\":{\"id\":2609}},{\"nodeType\":1,\"id\":2611,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-0\",\"class\":\"jspsych-survey-multi-choice-question jspsych-survey-multi-choice-horizontal\"},\"previousSibling\":{\"id\":2610},\"parentNode\":{\"id\":2609}},{\"nodeType\":1,\"id\":2612,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-1\",\"class\":\"jspsych-survey-multi-choice-question jspsych-survey-multi-choice-horizontal\"},\"previousSibling\":{\"id\":2611},\"parentNode\":{\"id\":2609}},{\"nodeType\":1,\"id\":2613,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-2\",\"class\":\"jspsych-survey-multi-choice-question jspsych-survey-multi-choice-horizontal\"},\"previousSibling\":{\"id\":2612},\"parentNode\":{\"id\":2609}},{\"nodeType\":1,\"id\":2614,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-3\",\"class\":\"jspsych-survey-multi-choice-question jspsych-survey-multi-choice-horizontal\"},\"previousSibling\":{\"id\":2613},\"parentNode\":{\"id\":2609}},{\"nodeType\":1,\"id\":2615,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"submit\",\"id\":\"jspsych-survey-multi-choice-next\",\"class\":\"jspsych-survey-multi-choice jspsych-btn\",\"value\":\"Submit Answers\"},\"previousSibling\":{\"id\":2614},\"parentNode\":{\"id\":2609}},{\"nodeType\":1,\"id\":2616,\"tagName\":\"P\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text survey-multi-choice\"},\"parentNode\":{\"id\":2611}},{\"nodeType\":1,\"id\":2617,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-0-0\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2616},\"parentNode\":{\"id\":2611}},{\"nodeType\":1,\"id\":2618,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-0-1\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2617},\"parentNode\":{\"id\":2611}},{\"nodeType\":1,\"id\":2619,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-0-2\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2618},\"parentNode\":{\"id\":2611}},{\"nodeType\":1,\"id\":2620,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-0-3\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2619},\"parentNode\":{\"id\":2611}},{\"nodeType\":3,\"id\":2621,\"textContent\":\"What is your first language?\",\"parentNode\":{\"id\":2616}},{\"nodeType\":1,\"id\":2622,\"tagName\":\"SPAN\",\"attributes\":{\"class\":\"required\"},\"previousSibling\":{\"id\":2621},\"parentNode\":{\"id\":2616}},{\"nodeType\":1,\"id\":2623,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2617}},{\"nodeType\":1,\"id\":2624,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-0\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2623}},{\"nodeType\":3,\"id\":2625,\"textContent\":\"English\",\"previousSibling\":{\"id\":2624},\"parentNode\":{\"id\":2623}},{\"nodeType\":1,\"id\":2626,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2618}},{\"nodeType\":1,\"id\":2627,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-0\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2626}},{\"nodeType\":3,\"id\":2628,\"textContent\":\"Spanish\",\"previousSibling\":{\"id\":2627},\"parentNode\":{\"id\":2626}},{\"nodeType\":1,\"id\":2629,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2619}},{\"nodeType\":1,\"id\":2630,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-0\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2629}},{\"nodeType\":3,\"id\":2631,\"textContent\":\"Mandarin or Cantonese\",\"previousSibling\":{\"id\":2630},\"parentNode\":{\"id\":2629}},{\"nodeType\":1,\"id\":2632,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2620}},{\"nodeType\":1,\"id\":2633,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-0\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2632}},{\"nodeType\":3,\"id\":2634,\"textContent\":\"Other\",\"previousSibling\":{\"id\":2633},\"parentNode\":{\"id\":2632}},{\"nodeType\":3,\"id\":2635,\"textContent\":\"*\",\"parentNode\":{\"id\":2622}},{\"nodeType\":1,\"id\":2636,\"tagName\":\"P\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text survey-multi-choice\"},\"parentNode\":{\"id\":2612}},{\"nodeType\":1,\"id\":2637,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-1-0\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2636},\"parentNode\":{\"id\":2612}},{\"nodeType\":1,\"id\":2638,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-1-1\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2637},\"parentNode\":{\"id\":2612}},{\"nodeType\":1,\"id\":2639,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-1-2\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2638},\"parentNode\":{\"id\":2612}},{\"nodeType\":1,\"id\":2640,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-1-3\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2639},\"parentNode\":{\"id\":2612}},{\"nodeType\":1,\"id\":2641,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-1-4\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2640},\"parentNode\":{\"id\":2612}},{\"nodeType\":1,\"id\":2642,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-1-5\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2641},\"parentNode\":{\"id\":2612}},{\"nodeType\":1,\"id\":2643,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-1-6\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2642},\"parentNode\":{\"id\":2612}},{\"nodeType\":3,\"id\":2644,\"textContent\":\"What is your year in school?\",\"parentNode\":{\"id\":2636}},{\"nodeType\":1,\"id\":2645,\"tagName\":\"SPAN\",\"attributes\":{\"class\":\"required\"},\"previousSibling\":{\"id\":2644},\"parentNode\":{\"id\":2636}},{\"nodeType\":1,\"id\":2646,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2637}},{\"nodeType\":1,\"id\":2647,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-1\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2646}},{\"nodeType\":3,\"id\":2648,\"textContent\":\"First\",\"previousSibling\":{\"id\":2647},\"parentNode\":{\"id\":2646}},{\"nodeType\":1,\"id\":2649,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2638}},{\"nodeType\":1,\"id\":2650,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-1\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2649}},{\"nodeType\":3,\"id\":2651,\"textContent\":\"Second\",\"previousSibling\":{\"id\":2650},\"parentNode\":{\"id\":2649}},{\"nodeType\":1,\"id\":2652,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2639}},{\"nodeType\":1,\"id\":2653,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-1\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2652}},{\"nodeType\":3,\"id\":2654,\"textContent\":\"Third\",\"previousSibling\":{\"id\":2653},\"parentNode\":{\"id\":2652}},{\"nodeType\":1,\"id\":2655,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2640}},{\"nodeType\":1,\"id\":2656,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-1\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2655}},{\"nodeType\":3,\"id\":2657,\"textContent\":\"Fourth\",\"previousSibling\":{\"id\":2656},\"parentNode\":{\"id\":2655}},{\"nodeType\":1,\"id\":2658,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2641}},{\"nodeType\":1,\"id\":2659,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-1\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2658}},{\"nodeType\":3,\"id\":2660,\"textContent\":\"Fifth\",\"previousSibling\":{\"id\":2659},\"parentNode\":{\"id\":2658}},{\"nodeType\":1,\"id\":2661,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2642}},{\"nodeType\":1,\"id\":2662,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-1\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2661}},{\"nodeType\":3,\"id\":2663,\"textContent\":\"Graduate\",\"previousSibling\":{\"id\":2662},\"parentNode\":{\"id\":2661}},{\"nodeType\":1,\"id\":2664,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2643}},{\"nodeType\":1,\"id\":2665,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-1\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2664}},{\"nodeType\":3,\"id\":2666,\"textContent\":\"Other\",\"previousSibling\":{\"id\":2665},\"parentNode\":{\"id\":2664}},{\"nodeType\":3,\"id\":2667,\"textContent\":\"*\",\"parentNode\":{\"id\":2645}},{\"nodeType\":1,\"id\":2668,\"tagName\":\"P\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text survey-multi-choice\"},\"parentNode\":{\"id\":2613}},{\"nodeType\":1,\"id\":2669,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-2-0\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2668},\"parentNode\":{\"id\":2613}},{\"nodeType\":1,\"id\":2670,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-2-1\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2669},\"parentNode\":{\"id\":2613}},{\"nodeType\":1,\"id\":2671,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-2-2\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2670},\"parentNode\":{\"id\":2613}},{\"nodeType\":1,\"id\":2672,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-2-3\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2671},\"parentNode\":{\"id\":2613}},{\"nodeType\":1,\"id\":2673,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-2-4\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2672},\"parentNode\":{\"id\":2613}},{\"nodeType\":1,\"id\":2674,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-2-5\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2673},\"parentNode\":{\"id\":2613}},{\"nodeType\":1,\"id\":2675,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-2-6\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2674},\"parentNode\":{\"id\":2613}},{\"nodeType\":3,\"id\":2676,\"textContent\":\"What is your major area of study?\",\"parentNode\":{\"id\":2668}},{\"nodeType\":1,\"id\":2677,\"tagName\":\"SPAN\",\"attributes\":{\"class\":\"required\"},\"previousSibling\":{\"id\":2676},\"parentNode\":{\"id\":2668}},{\"nodeType\":1,\"id\":2678,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2669}},{\"nodeType\":1,\"id\":2679,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-2\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2678}},{\"nodeType\":3,\"id\":2680,\"textContent\":\"Math or Computer Sciences\",\"previousSibling\":{\"id\":2679},\"parentNode\":{\"id\":2678}},{\"nodeType\":1,\"id\":2681,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2670}},{\"nodeType\":1,\"id\":2682,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-2\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2681}},{\"nodeType\":3,\"id\":2683,\"textContent\":\"Social Sciences (incl. CogSci)\",\"previousSibling\":{\"id\":2682},\"parentNode\":{\"id\":2681}},{\"nodeType\":1,\"id\":2684,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2671}},{\"nodeType\":1,\"id\":2685,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-2\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2684}},{\"nodeType\":3,\"id\":2686,\"textContent\":\"Biomedical & Health Sciences\",\"previousSibling\":{\"id\":2685},\"parentNode\":{\"id\":2684}},{\"nodeType\":1,\"id\":2687,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2672}},{\"nodeType\":1,\"id\":2688,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-2\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2687}},{\"nodeType\":3,\"id\":2689,\"textContent\":\"Natural Sciences\",\"previousSibling\":{\"id\":2688},\"parentNode\":{\"id\":2687}},{\"nodeType\":1,\"id\":2690,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2673}},{\"nodeType\":1,\"id\":2691,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-2\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2690}},{\"nodeType\":3,\"id\":2692,\"textContent\":\"Engineering\",\"previousSibling\":{\"id\":2691},\"parentNode\":{\"id\":2690}},{\"nodeType\":1,\"id\":2693,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2674}},{\"nodeType\":1,\"id\":2694,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-2\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2693}},{\"nodeType\":3,\"id\":2695,\"textContent\":\"Humanities\",\"previousSibling\":{\"id\":2694},\"parentNode\":{\"id\":2693}},{\"nodeType\":1,\"id\":2696,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2675}},{\"nodeType\":1,\"id\":2697,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-2\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2696}},{\"nodeType\":3,\"id\":2698,\"textContent\":\"Fine Arts\",\"previousSibling\":{\"id\":2697},\"parentNode\":{\"id\":2696}},{\"nodeType\":3,\"id\":2699,\"textContent\":\"*\",\"parentNode\":{\"id\":2677}},{\"nodeType\":1,\"id\":2700,\"tagName\":\"P\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text survey-multi-choice\"},\"parentNode\":{\"id\":2614}},{\"nodeType\":1,\"id\":2701,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-3-0\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2700},\"parentNode\":{\"id\":2614}},{\"nodeType\":1,\"id\":2702,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-3-1\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2701},\"parentNode\":{\"id\":2614}},{\"nodeType\":1,\"id\":2703,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-3-2\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2702},\"parentNode\":{\"id\":2614}},{\"nodeType\":3,\"id\":2704,\"textContent\":\"What is your gender?\",\"parentNode\":{\"id\":2700}},{\"nodeType\":1,\"id\":2705,\"tagName\":\"SPAN\",\"attributes\":{\"class\":\"required\"},\"previousSibling\":{\"id\":2704},\"parentNode\":{\"id\":2700}},{\"nodeType\":1,\"id\":2706,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2701}},{\"nodeType\":1,\"id\":2707,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-3\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2706}},{\"nodeType\":3,\"id\":2708,\"textContent\":\"Male\",\"previousSibling\":{\"id\":2707},\"parentNode\":{\"id\":2706}},{\"nodeType\":1,\"id\":2709,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2702}},{\"nodeType\":1,\"id\":2710,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-3\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2709}},{\"nodeType\":3,\"id\":2711,\"textContent\":\"Female\",\"previousSibling\":{\"id\":2710},\"parentNode\":{\"id\":2709}},{\"nodeType\":1,\"id\":2712,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2703}},{\"nodeType\":1,\"id\":2713,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-3\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2712}},{\"nodeType\":3,\"id\":2714,\"textContent\":\"Other\",\"previousSibling\":{\"id\":2713},\"parentNode\":{\"id\":2712}},{\"nodeType\":3,\"id\":2715,\"textContent\":\"*\",\"parentNode\":{\"id\":2705}}],[],[]]}"
    },
    {
      "sequence": 5,
      "data": "{\"f\":\"applyChanged\",\"args\":[[{\"id\":2609},{\"id\":2610},{\"id\":2611},{\"id\":2616},{\"id\":2621},{\"id\":2622},{\"id\":2635},{\"id\":2617},{\"id\":2623},{\"id\":2624},{\"id\":2625},{\"id\":2618},{\"id\":2626},{\"id\":2627},{\"id\":2628},{\"id\":2619},{\"id\":2629},{\"id\":2630},{\"id\":2631},{\"id\":2620},{\"id\":2632},{\"id\":2633},{\"id\":2634},{\"id\":2612},{\"id\":2636},{\"id\":2644},{\"id\":2645},{\"id\":2667},{\"id\":2637},{\"id\":2646},{\"id\":2647},{\"id\":2648},{\"id\":2638},{\"id\":2649},{\"id\":2650},{\"id\":2651},{\"id\":2639},{\"id\":2652},{\"id\":2653},{\"id\":2654},{\"id\":2640},{\"id\":2655},{\"id\":2656},{\"id\":2657},{\"id\":2641},{\"id\":2658},{\"id\":2659},{\"id\":2660},{\"id\":2642},{\"id\":2661},{\"id\":2662},{\"id\":2663},{\"id\":2643},{\"id\":2664},{\"id\":2665},{\"id\":2666},{\"id\":2613},{\"id\":2668},{\"id\":2676},{\"id\":2677},{\"id\":2699},{\"id\":2669},{\"id\":2678},{\"id\":2679},{\"id\":2680},{\"id\":2670},{\"id\":2681},{\"id\":2682},{\"id\":2683},{\"id\":2671},{\"id\":2684},{\"id\":2685},{\"id\":2686},{\"id\":2672},{\"id\":2687},{\"id\":2688},{\"id\":2689},{\"id\":2673},{\"id\":2690},{\"id\":2691},{\"id\":2692},{\"id\":2674},{\"id\":2693},{\"id\":2694},{\"id\":2695},{\"id\":2675},{\"id\":2696},{\"id\":2697},{\"id\":2698},{\"id\":2614},{\"id\":2700},{\"id\":2704},{\"id\":2705},{\"id\":2715},{\"id\":2701},{\"id\":2706},{\"id\":2707},{\"id\":2708},{\"id\":2702},{\"id\":2709},{\"id\":2710},{\"id\":2711},{\"id\":2703},{\"id\":2712},{\"id\":2713},{\"id\":2714},{\"id\":2615}],[],[],[]]}"
    },
    {
      "sequence": 6,
      "data": "{\"f\":\"applyChanged\",\"args\":[[],[{\"nodeType\":1,\"id\":2716,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"masterdiv\"},\"parentNode\":{\"id\":55}},{\"nodeType\":3,\"id\":2717,\"textContent\":\" \",\"previousSibling\":{\"id\":2716},\"parentNode\":{\"id\":55}},{\"nodeType\":3,\"id\":2718,\"textContent\":\" \",\"parentNode\":{\"id\":2716}},{\"nodeType\":1,\"id\":2719,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"top\"},\"previousSibling\":{\"id\":2718},\"parentNode\":{\"id\":2716}},{\"nodeType\":3,\"id\":2720,\"textContent\":\" \",\"previousSibling\":{\"id\":2719},\"parentNode\":{\"id\":2716}},{\"nodeType\":1,\"id\":2721,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"instructions\"},\"previousSibling\":{\"id\":2720},\"parentNode\":{\"id\":2716}},{\"nodeType\":3,\"id\":2722,\"textContent\":\" \",\"previousSibling\":{\"id\":2721},\"parentNode\":{\"id\":2716}},{\"nodeType\":1,\"id\":2723,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bottom\"},\"previousSibling\":{\"id\":2722},\"parentNode\":{\"id\":2716}},{\"nodeType\":3,\"id\":2724,\"textContent\":\" \",\"previousSibling\":{\"id\":2723},\"parentNode\":{\"id\":2716}},{\"nodeType\":3,\"id\":2725,\"textContent\":\" \",\"parentNode\":{\"id\":2719}},{\"nodeType\":1,\"id\":2726,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bcent\"},\"previousSibling\":{\"id\":2725},\"parentNode\":{\"id\":2719}},{\"nodeType\":3,\"id\":2727,\"textContent\":\" \",\"previousSibling\":{\"id\":2726},\"parentNode\":{\"id\":2719}},{\"nodeType\":3,\"id\":2728,\"textContent\":\" \",\"parentNode\":{\"id\":2726}},{\"nodeType\":1,\"id\":2729,\"tagName\":\"H3\",\"attributes\":{},\"previousSibling\":{\"id\":2728},\"parentNode\":{\"id\":2726}},{\"nodeType\":3,\"id\":2730,\"textContent\":\" \",\"previousSibling\":{\"id\":2729},\"parentNode\":{\"id\":2726}},{\"nodeType\":3,\"id\":2731,\"textContent\":\"DEBRIEFING\",\"parentNode\":{\"id\":2729}},{\"nodeType\":3,\"id\":2732,\"textContent\":\" \",\"parentNode\":{\"id\":2721}},{\"nodeType\":1,\"id\":2733,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"vcent\"},\"previousSibling\":{\"id\":2732},\"parentNode\":{\"id\":2721}},{\"nodeType\":3,\"id\":2734,\"textContent\":\" \",\"previousSibling\":{\"id\":2733},\"parentNode\":{\"id\":2721}},{\"nodeType\":3,\"id\":2735,\"textContent\":\" \",\"parentNode\":{\"id\":2733}},{\"nodeType\":1,\"id\":2736,\"tagName\":\"P\",\"attributes\":{\"style\":\"font-style:italic\"},\"previousSibling\":{\"id\":2735},\"parentNode\":{\"id\":2733}},{\"nodeType\":1,\"id\":2737,\"tagName\":\"P\",\"attributes\":{},\"previousSibling\":{\"id\":2736},\"parentNode\":{\"id\":2733}},{\"nodeType\":3,\"id\":2738,\"textContent\":\" \",\"previousSibling\":{\"id\":2737},\"parentNode\":{\"id\":2733}},{\"nodeType\":1,\"id\":2739,\"tagName\":\"P\",\"attributes\":{},\"previousSibling\":{\"id\":2738},\"parentNode\":{\"id\":2733}},{\"nodeType\":3,\"id\":2740,\"textContent\":\" \",\"previousSibling\":{\"id\":2739},\"parentNode\":{\"id\":2733}},{\"nodeType\":1,\"id\":2741,\"tagName\":\"P\",\"attributes\":{},\"previousSibling\":{\"id\":2740},\"parentNode\":{\"id\":2733}},{\"nodeType\":3,\"id\":2742,\"textContent\":\" \",\"previousSibling\":{\"id\":2741},\"parentNode\":{\"id\":2733}},{\"nodeType\":1,\"id\":2743,\"tagName\":\"P\",\"attributes\":{\"style\":\"font-style:bold;\"},\"previousSibling\":{\"id\":2742},\"parentNode\":{\"id\":2733}},{\"nodeType\":3,\"id\":2744,\"textContent\":\" \",\"previousSibling\":{\"id\":2743},\"parentNode\":{\"id\":2733}},{\"nodeType\":1,\"id\":2745,\"tagName\":\"P\",\"attributes\":{\"style\":\"font-style:italic;\"},\"previousSibling\":{\"id\":2744},\"parentNode\":{\"id\":2733}},{\"nodeType\":3,\"id\":2746,\"textContent\":\" \",\"previousSibling\":{\"id\":2745},\"parentNode\":{\"id\":2733}},{\"nodeType\":3,\"id\":2747,\"textContent\":\"Thank you very much for your participation! This debriefing will tell you more about the study, what you did, and why. \",\"parentNode\":{\"id\":2736}},{\"nodeType\":3,\"id\":2748,\"textContent\":\" \",\"parentNode\":{\"id\":2737}},{\"nodeType\":1,\"id\":2749,\"tagName\":\"B\",\"attributes\":{},\"previousSibling\":{\"id\":2748},\"parentNode\":{\"id\":2737}},{\"nodeType\":3,\"id\":2750,\"textContent\":\" You have just used a series of pictures (charts, graphs and diagrams) accompanied by different types of instructions to answer a series of problem solving questions. While you were using the pictures, we measured where you clicked, scrolled and pointed with the computer mouse. We also measured the accuracy of your responses and the time it took to complete each question.\",\"previousSibling\":{\"id\":2749},\"parentNode\":{\"id\":2737}},{\"nodeType\":3,\"id\":2751,\"textContent\":\"What did you just do?\",\"parentNode\":{\"id\":2749}},{\"nodeType\":3,\"id\":2752,\"textContent\":\" \",\"parentNode\":{\"id\":2739}},{\"nodeType\":1,\"id\":2753,\"tagName\":\"B\",\"attributes\":{},\"previousSibling\":{\"id\":2752},\"parentNode\":{\"id\":2739}},{\"nodeType\":3,\"id\":2754,\"textContent\":\" Researchers of learning and cognition have long been interested in how graphic displays of information can be used to communicate, solve problems, and generate insights. As powerful as graphics may be in their communicative efficiency, they're not always immediately intuitive to understand. In short, we know a great deal more about learning with representations than we do about the learning of representations. In this project we are building upon previous research on reading and graph comprehension to explore how readers make sense of unfamiliar representations. The instructions you saw for each type of graph are known as “scaffolding techniques”, and we will compare your performance with the scaffolding techniques you saw with the performance of other participants to determine which types of instructions are most effective in helping humans to make sense of unfamiliar graphs. \",\"previousSibling\":{\"id\":2753},\"parentNode\":{\"id\":2739}},{\"nodeType\":3,\"id\":2755,\"textContent\":\"Why did we have you do it?\",\"parentNode\":{\"id\":2753}},{\"nodeType\":1,\"id\":2756,\"tagName\":\"B\",\"attributes\":{},\"parentNode\":{\"id\":2741}},{\"nodeType\":3,\"id\":2757,\"textContent\":\" We expect that you will have found some of the graphics more difficult to use than others. We also expect that with the assistance of the instructions, after solving several problems you will learn to use the difficult graphics so that you can answer the questions even more quickly than without. If you would like to receive a copy of the results of the study, or have any further questions, please contact the researchers Primary Researcher: Amy Fox : a2fox@ucsd.edu Faculty Advisor : Dr. Jim Hollan : hollan@ucsd.edu \",\"previousSibling\":{\"id\":2756},\"parentNode\":{\"id\":2741}},{\"nodeType\":3,\"id\":2758,\"textContent\":\"What do we expect to find?\",\"parentNode\":{\"id\":2756}},{\"nodeType\":3,\"id\":2759,\"textContent\":\"It is important that you do not discuss this experiment with other students who might participate after you. They must participate in the same way as you did, without any knowledge of what the experiment entails, or the reasoning behind it.\",\"parentNode\":{\"id\":2743}},{\"nodeType\":3,\"id\":2760,\"textContent\":\"Thank you for your time! We hope you enjoyed participating in this study as much as we enjoyed designing it.\",\"parentNode\":{\"id\":2745}},{\"nodeType\":3,\"id\":2761,\"textContent\":\" \",\"parentNode\":{\"id\":2723}},{\"nodeType\":1,\"id\":2762,\"tagName\":\"BUTTON\",\"attributes\":{\"class\":\"btn\",\"type\":\"button\",\"id\":\"start\"},\"previousSibling\":{\"id\":2761},\"parentNode\":{\"id\":2723}},{\"nodeType\":3,\"id\":2763,\"textContent\":\" \",\"previousSibling\":{\"id\":2762},\"parentNode\":{\"id\":2723}},{\"nodeType\":3,\"id\":2764,\"textContent\":\"FINISH\",\"parentNode\":{\"id\":2762}}],[],[]]}"
    },
    {
      "sequence": 7,
      "data": "{\"f\":\"applyChanged\",\"args\":[[{\"id\":2716},{\"id\":2718},{\"id\":2719},{\"id\":2725},{\"id\":2726},{\"id\":2728},{\"id\":2729},{\"id\":2731},{\"id\":2730},{\"id\":2727},{\"id\":2720},{\"id\":2721},{\"id\":2732},{\"id\":2733},{\"id\":2735},{\"id\":2736},{\"id\":2747},{\"id\":2737},{\"id\":2748},{\"id\":2749},{\"id\":2751},{\"id\":2750},{\"id\":2738},{\"id\":2739},{\"id\":2752},{\"id\":2753},{\"id\":2755},{\"id\":2754},{\"id\":2740},{\"id\":2741},{\"id\":2756},{\"id\":2758},{\"id\":2757},{\"id\":2742},{\"id\":2743},{\"id\":2759},{\"id\":2744},{\"id\":2745},{\"id\":2760},{\"id\":2746},{\"id\":2734},{\"id\":2722},{\"id\":2723},{\"id\":2761},{\"id\":2762},{\"id\":2764},{\"id\":2763},{\"id\":2724},{\"id\":2717}],[],[],[]]}"
    },
    {
      "sequence": 8,
      "data": "{\"f\":\"applyChanged\",\"args\":[[],[{\"nodeType\":1,\"id\":2765,\"tagName\":\"PRE\",\"attributes\":{\"id\":\"jspsych-data-display\"},\"parentNode\":{\"id\":55}},{\"nodeType\":3,\"id\":2766,\"textContent\":\"[ { \\\"rt\\\": 245656, \\\"stimulus\\\": \\\"img/phone.png\\\", \\\"key_press\\\": 13, \\\"block\\\": \\\"phone\\\", \\\"trial_type\\\": \\\"single-stim\\\", \\\"trial_index\\\": 0, \\\"time_elapsed\\\": 245662, \\\"internal_node_id\\\": \\\"0.0-0.0\\\", \\\"subject\\\": \\\"JYGX2\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"yankee\\\", \\\"condition\\\": \\\"311\\\" }, { \\\"rt\\\": 30330, \\\"url\\\": \\\"../views/src/external/consent.html\\\", \\\"block\\\": \\\"consent\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 1, \\\"time_elapsed\\\": 277342, \\\"internal_node_id\\\": \\\"0.0-1.0\\\", \\\"subject\\\": \\\"JYGX2\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"yankee\\\", \\\"condition\\\": \\\"311\\\" }, { \\\"rt\\\": 6540, \\\"responses\\\": \\\"{\\\\\\\"Q0\\\\\\\":\\\\\\\"yankee\\\\\\\",\\\\\\\"Q1\\\\\\\":\\\\\\\"311\\\\\\\"}\\\", \\\"block\\\": \\\"codes\\\", \\\"trial_type\\\": \\\"survey-text\\\", \\\"trial_index\\\": 2, \\\"time_elapsed\\\": 284890, \\\"internal_node_id\\\": \\\"0.0-2.0\\\", \\\"subject\\\": \\\"JYGX2\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"yankee\\\", \\\"condition\\\": \\\"311\\\" }, { \\\"rt\\\": 8741, \\\"url\\\": \\\"../views/src/external/instructions_lab.html\\\", \\\"block\\\": \\\"instructions_lab\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 3, \\\"time_elapsed\\\": 294723, \\\"internal_node_id\\\": \\\"0.0-3.0\\\", \\\"subject\\\": \\\"JYGX2\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"yankee\\\", \\\"condition\\\": \\\"311\\\" }, { \\\"rt\\\": 8995, \\\"stimulus\\\": \\\"img/acme.png\\\", \\\"key_press\\\": 13, \\\"block\\\": \\\"scenario\\\", \\\"trial_type\\\": \\\"single-stim\\\", \\\"trial_index\\\": 4, \\\"time_elapsed\\\": 304721, \\\"internal_node_id\\\": \\\"0.0-4.0\\\", \\\"subject\\\": \\\"JYGX2\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"yankee\\\", \\\"condition\\\": \\\"311\\\" }, { \\\"rt\\\": 29062, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 5, \\\"time_elapsed\\\": 335191, \\\"internal_node_id\\\": \\\"0.0-5.0-0.0\\\", \\\"subject\\\": \\\"JYGX2\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"yankee\\\", \\\"condition\\\": \\\"311\\\", \\\"scenario\\\": \\\"acme\\\", \\\"question\\\": \\\"starttime\\\", \\\"q\\\": 1, \\\"clicks\\\": 1, \\\"explicit\\\": 3, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XInside-YFull\\\", \\\"correct\\\": 1, \\\"orth_correct\\\": 0, \\\"answer\\\": [ \\\"F\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"X \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"U \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-O -Z -F -F -4-10 AM-F -F -F -F \\\", \\\"block\\\": \\\"triangular_scaffolded\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:1089,y:941,t:1528139562799};\\\", \\\"{x:1082,y:952,t:1528139562812};\\\", \\\"{x:1073,y:987,t:1528139562829};\\\", \\\"{x:1071,y:1007,t:1528139562846};\\\", \\\"{x:1071,y:1009,t:1528139562863};\\\", \\\"{x:1052,y:1005,t:1528139563161};\\\", \\\"{x:1033,y:1002,t:1528139563168};\\\", \\\"{x:995,y:993,t:1528139563180};\\\", \\\"{x:905,y:976,t:1528139563197};\\\", \\\"{x:806,y:964,t:1528139563213};\\\", \\\"{x:720,y:955,t:1528139563230};\\\", \\\"{x:690,y:940,t:1528139563247};\\\", \\\"{x:687,y:938,t:1528139563262};\\\", \\\"{x:687,y:937,t:1528139563407};\\\", \\\"{x:686,y:937,t:1528139563415};\\\", \\\"{x:684,y:937,t:1528139563560};\\\", \\\"{x:684,y:936,t:1528139563568};\\\", \\\"{x:683,y:936,t:1528139563583};\\\", \\\"{x:682,y:935,t:1528139566624};\\\", \\\"{x:683,y:923,t:1528139566631};\\\", \\\"{x:713,y:897,t:1528139566649};\\\", \\\"{x:735,y:879,t:1528139566666};\\\", \\\"{x:757,y:857,t:1528139566682};\\\", \\\"{x:784,y:828,t:1528139566699};\\\", \\\"{x:817,y:799,t:1528139566716};\\\", \\\"{x:862,y:769,t:1528139566733};\\\", \\\"{x:913,y:730,t:1528139566749};\\\", \\\"{x:982,y:687,t:1528139566767};\\\", \\\"{x:1072,y:635,t:1528139566783};\\\", \\\"{x:1181,y:581,t:1528139566799};\\\", \\\"{x:1328,y:501,t:1528139566816};\\\", \\\"{x:1402,y:458,t:1528139566833};\\\", \\\"{x:1476,y:414,t:1528139566850};\\\", \\\"{x:1531,y:389,t:1528139566867};\\\", \\\"{x:1567,y:374,t:1528139566883};\\\", \\\"{x:1588,y:365,t:1528139566900};\\\", \\\"{x:1601,y:362,t:1528139566917};\\\", \\\"{x:1614,y:360,t:1528139566933};\\\", \\\"{x:1630,y:358,t:1528139566950};\\\", \\\"{x:1647,y:358,t:1528139566967};\\\", \\\"{x:1668,y:358,t:1528139566984};\\\", \\\"{x:1684,y:358,t:1528139567000};\\\", \\\"{x:1702,y:362,t:1528139567016};\\\", \\\"{x:1708,y:367,t:1528139567034};\\\", \\\"{x:1713,y:380,t:1528139567049};\\\", \\\"{x:1714,y:391,t:1528139567067};\\\", \\\"{x:1714,y:402,t:1528139567083};\\\", \\\"{x:1709,y:418,t:1528139567100};\\\", \\\"{x:1698,y:436,t:1528139567117};\\\", \\\"{x:1684,y:455,t:1528139567133};\\\", \\\"{x:1666,y:473,t:1528139567150};\\\", \\\"{x:1642,y:492,t:1528139567167};\\\", \\\"{x:1618,y:509,t:1528139567183};\\\", \\\"{x:1587,y:524,t:1528139567200};\\\", \\\"{x:1543,y:548,t:1528139567217};\\\", \\\"{x:1505,y:568,t:1528139567234};\\\", \\\"{x:1473,y:586,t:1528139567250};\\\", \\\"{x:1452,y:600,t:1528139567266};\\\", \\\"{x:1429,y:615,t:1528139567283};\\\", \\\"{x:1406,y:629,t:1528139567300};\\\", \\\"{x:1391,y:637,t:1528139567317};\\\", \\\"{x:1382,y:641,t:1528139567334};\\\", \\\"{x:1376,y:645,t:1528139567350};\\\", \\\"{x:1371,y:647,t:1528139567367};\\\", \\\"{x:1371,y:648,t:1528139567488};\\\", \\\"{x:1370,y:648,t:1528139567512};\\\", \\\"{x:1367,y:647,t:1528139567521};\\\", \\\"{x:1365,y:646,t:1528139567534};\\\", \\\"{x:1357,y:642,t:1528139567551};\\\", \\\"{x:1348,y:638,t:1528139567567};\\\", \\\"{x:1343,y:638,t:1528139567583};\\\", \\\"{x:1337,y:637,t:1528139567600};\\\", \\\"{x:1336,y:637,t:1528139567616};\\\", \\\"{x:1334,y:637,t:1528139567633};\\\", \\\"{x:1332,y:635,t:1528139567697};\\\", \\\"{x:1330,y:635,t:1528139567768};\\\", \\\"{x:1329,y:635,t:1528139567782};\\\", \\\"{x:1321,y:635,t:1528139567800};\\\", \\\"{x:1318,y:635,t:1528139567816};\\\", \\\"{x:1315,y:635,t:1528139567836};\\\", \\\"{x:1313,y:634,t:1528139567867};\\\", \\\"{x:1312,y:634,t:1528139567883};\\\", \\\"{x:1308,y:635,t:1528139570516};\\\", \\\"{x:1301,y:679,t:1528139570536};\\\", \\\"{x:1291,y:707,t:1528139570552};\\\", \\\"{x:1285,y:733,t:1528139570569};\\\", \\\"{x:1278,y:750,t:1528139570586};\\\", \\\"{x:1273,y:767,t:1528139570602};\\\", \\\"{x:1268,y:783,t:1528139570619};\\\", \\\"{x:1262,y:797,t:1528139570636};\\\", \\\"{x:1258,y:808,t:1528139570652};\\\", \\\"{x:1257,y:817,t:1528139570669};\\\", \\\"{x:1254,y:824,t:1528139570686};\\\", \\\"{x:1253,y:831,t:1528139570702};\\\", \\\"{x:1251,y:837,t:1528139570719};\\\", \\\"{x:1251,y:841,t:1528139570735};\\\", \\\"{x:1251,y:844,t:1528139570753};\\\", \\\"{x:1251,y:847,t:1528139570770};\\\", \\\"{x:1251,y:851,t:1528139570786};\\\", \\\"{x:1253,y:856,t:1528139570802};\\\", \\\"{x:1255,y:859,t:1528139570820};\\\", \\\"{x:1259,y:864,t:1528139570837};\\\", \\\"{x:1264,y:871,t:1528139570853};\\\", \\\"{x:1269,y:880,t:1528139570870};\\\", \\\"{x:1276,y:890,t:1528139570887};\\\", \\\"{x:1283,y:901,t:1528139570903};\\\", \\\"{x:1288,y:911,t:1528139570920};\\\", \\\"{x:1301,y:925,t:1528139570937};\\\", \\\"{x:1307,y:936,t:1528139570953};\\\", \\\"{x:1315,y:946,t:1528139570969};\\\", \\\"{x:1316,y:948,t:1528139570987};\\\", \\\"{x:1319,y:948,t:1528139571009};\\\", \\\"{x:1323,y:946,t:1528139571020};\\\", \\\"{x:1332,y:936,t:1528139571037};\\\", \\\"{x:1340,y:922,t:1528139571054};\\\", \\\"{x:1350,y:900,t:1528139571075};\\\", \\\"{x:1379,y:818,t:1528139571104};\\\", \\\"{x:1387,y:796,t:1528139571119};\\\", \\\"{x:1392,y:778,t:1528139571137};\\\", \\\"{x:1393,y:764,t:1528139571153};\\\", \\\"{x:1393,y:756,t:1528139571169};\\\", \\\"{x:1393,y:745,t:1528139571186};\\\", \\\"{x:1393,y:741,t:1528139571203};\\\", \\\"{x:1393,y:739,t:1528139571219};\\\", \\\"{x:1393,y:738,t:1528139571247};\\\", \\\"{x:1392,y:738,t:1528139571328};\\\", \\\"{x:1391,y:738,t:1528139571343};\\\", \\\"{x:1390,y:739,t:1528139571353};\\\", \\\"{x:1389,y:741,t:1528139571369};\\\", \\\"{x:1387,y:746,t:1528139571387};\\\", \\\"{x:1386,y:750,t:1528139571403};\\\", \\\"{x:1385,y:757,t:1528139571420};\\\", \\\"{x:1385,y:760,t:1528139571437};\\\", \\\"{x:1383,y:764,t:1528139571453};\\\", \\\"{x:1382,y:766,t:1528139571469};\\\", \\\"{x:1382,y:768,t:1528139571486};\\\", \\\"{x:1381,y:769,t:1528139571623};\\\", \\\"{x:1381,y:770,t:1528139571640};\\\", \\\"{x:1381,y:771,t:1528139571656};\\\", \\\"{x:1380,y:771,t:1528139572167};\\\", \\\"{x:1379,y:771,t:1528139572175};\\\", \\\"{x:1378,y:771,t:1528139572192};\\\", \\\"{x:1377,y:770,t:1528139572265};\\\", \\\"{x:1376,y:770,t:1528139572392};\\\", \\\"{x:1376,y:769,t:1528139572424};\\\", \\\"{x:1376,y:768,t:1528139572438};\\\", \\\"{x:1376,y:767,t:1528139572455};\\\", \\\"{x:1376,y:766,t:1528139572545};\\\", \\\"{x:1376,y:765,t:1528139572591};\\\", \\\"{x:1376,y:764,t:1528139572743};\\\", \\\"{x:1377,y:763,t:1528139572791};\\\", \\\"{x:1378,y:763,t:1528139574088};\\\", \\\"{x:1380,y:763,t:1528139574094};\\\", \\\"{x:1382,y:763,t:1528139574110};\\\", \\\"{x:1383,y:763,t:1528139574135};\\\", \\\"{x:1383,y:762,t:1528139578216};\\\", \\\"{x:1382,y:761,t:1528139578256};\\\", \\\"{x:1381,y:761,t:1528139578264};\\\", \\\"{x:1379,y:761,t:1528139578275};\\\", \\\"{x:1376,y:761,t:1528139578292};\\\", \\\"{x:1369,y:761,t:1528139578311};\\\", \\\"{x:1359,y:763,t:1528139578326};\\\", \\\"{x:1342,y:767,t:1528139578342};\\\", \\\"{x:1326,y:770,t:1528139578358};\\\", \\\"{x:1308,y:773,t:1528139578375};\\\", \\\"{x:1281,y:779,t:1528139578391};\\\", \\\"{x:1266,y:781,t:1528139578408};\\\", \\\"{x:1253,y:784,t:1528139578424};\\\", \\\"{x:1237,y:788,t:1528139578442};\\\", \\\"{x:1224,y:791,t:1528139578458};\\\", \\\"{x:1212,y:795,t:1528139578474};\\\", \\\"{x:1195,y:800,t:1528139578491};\\\", \\\"{x:1181,y:804,t:1528139578508};\\\", \\\"{x:1170,y:806,t:1528139578526};\\\", \\\"{x:1157,y:808,t:1528139578542};\\\", \\\"{x:1143,y:809,t:1528139578559};\\\", \\\"{x:1117,y:811,t:1528139578575};\\\", \\\"{x:1093,y:811,t:1528139578592};\\\", \\\"{x:1043,y:811,t:1528139578609};\\\", \\\"{x:979,y:811,t:1528139578626};\\\", \\\"{x:917,y:811,t:1528139578642};\\\", \\\"{x:860,y:814,t:1528139578659};\\\", \\\"{x:821,y:814,t:1528139578676};\\\", \\\"{x:799,y:814,t:1528139578691};\\\", \\\"{x:788,y:812,t:1528139578709};\\\", \\\"{x:782,y:811,t:1528139578726};\\\", \\\"{x:773,y:806,t:1528139578742};\\\", \\\"{x:755,y:799,t:1528139578759};\\\", \\\"{x:710,y:771,t:1528139578775};\\\", \\\"{x:654,y:732,t:1528139578792};\\\", \\\"{x:603,y:695,t:1528139578809};\\\", \\\"{x:580,y:673,t:1528139578827};\\\", \\\"{x:564,y:656,t:1528139578842};\\\", \\\"{x:553,y:636,t:1528139578861};\\\", \\\"{x:542,y:623,t:1528139578875};\\\", \\\"{x:530,y:621,t:1528139578892};\\\", \\\"{x:530,y:616,t:1528139578911};\\\", \\\"{x:528,y:608,t:1528139578925};\\\", \\\"{x:526,y:599,t:1528139578942};\\\", \\\"{x:523,y:592,t:1528139578959};\\\", \\\"{x:522,y:590,t:1528139578975};\\\", \\\"{x:522,y:589,t:1528139578999};\\\", \\\"{x:522,y:588,t:1528139579047};\\\", \\\"{x:522,y:587,t:1528139579408};\\\", \\\"{x:520,y:587,t:1528139581968};\\\", \\\"{x:518,y:588,t:1528139581983};\\\", \\\"{x:517,y:590,t:1528139581998};\\\", \\\"{x:515,y:591,t:1528139582008};\\\", \\\"{x:514,y:592,t:1528139582025};\\\", \\\"{x:514,y:594,t:1528139582040};\\\", \\\"{x:513,y:595,t:1528139582058};\\\", \\\"{x:512,y:595,t:1528139582087};\\\", \\\"{x:511,y:596,t:1528139582103};\\\", \\\"{x:511,y:597,t:1528139582248};\\\", \\\"{x:511,y:598,t:1528139582264};\\\", \\\"{x:509,y:599,t:1528139582275};\\\", \\\"{x:507,y:601,t:1528139582290};\\\", \\\"{x:504,y:603,t:1528139582308};\\\", \\\"{x:502,y:604,t:1528139582324};\\\", \\\"{x:502,y:605,t:1528139582340};\\\", \\\"{x:500,y:606,t:1528139582358};\\\", \\\"{x:499,y:606,t:1528139582374};\\\", \\\"{x:498,y:606,t:1528139582391};\\\", \\\"{x:497,y:607,t:1528139582408};\\\", \\\"{x:496,y:608,t:1528139582424};\\\", \\\"{x:495,y:608,t:1528139582439};\\\", \\\"{x:492,y:609,t:1528139582455};\\\", \\\"{x:489,y:611,t:1528139582471};\\\", \\\"{x:486,y:612,t:1528139582488};\\\", \\\"{x:482,y:615,t:1528139582511};\\\", \\\"{x:481,y:615,t:1528139582640};\\\", \\\"{x:481,y:613,t:1528139582648};\\\", \\\"{x:481,y:610,t:1528139582663};\\\", \\\"{x:481,y:603,t:1528139582679};\\\", \\\"{x:477,y:591,t:1528139582695};\\\", \\\"{x:470,y:582,t:1528139582711};\\\", \\\"{x:457,y:574,t:1528139582729};\\\", \\\"{x:445,y:567,t:1528139582746};\\\", \\\"{x:439,y:563,t:1528139582762};\\\", \\\"{x:433,y:560,t:1528139582778};\\\", \\\"{x:432,y:559,t:1528139582795};\\\", \\\"{x:431,y:559,t:1528139582812};\\\", \\\"{x:433,y:558,t:1528139582903};\\\", \\\"{x:438,y:556,t:1528139582912};\\\", \\\"{x:447,y:555,t:1528139582928};\\\", \\\"{x:458,y:551,t:1528139582945};\\\", \\\"{x:477,y:546,t:1528139582963};\\\", \\\"{x:495,y:544,t:1528139582979};\\\", \\\"{x:508,y:542,t:1528139582997};\\\", \\\"{x:519,y:541,t:1528139583013};\\\", \\\"{x:527,y:541,t:1528139583028};\\\", \\\"{x:534,y:541,t:1528139583047};\\\", \\\"{x:542,y:538,t:1528139583062};\\\", \\\"{x:543,y:537,t:1528139583078};\\\", \\\"{x:547,y:537,t:1528139583095};\\\", \\\"{x:552,y:534,t:1528139583112};\\\", \\\"{x:559,y:533,t:1528139583129};\\\", \\\"{x:568,y:532,t:1528139583146};\\\", \\\"{x:577,y:530,t:1528139583163};\\\", \\\"{x:587,y:530,t:1528139583179};\\\", \\\"{x:598,y:530,t:1528139583196};\\\", \\\"{x:605,y:530,t:1528139583213};\\\", \\\"{x:610,y:530,t:1528139583229};\\\", \\\"{x:613,y:530,t:1528139583246};\\\", \\\"{x:616,y:530,t:1528139583263};\\\", \\\"{x:617,y:530,t:1528139583279};\\\", \\\"{x:618,y:532,t:1528139583345};\\\", \\\"{x:618,y:533,t:1528139583351};\\\", \\\"{x:620,y:537,t:1528139583368};\\\", \\\"{x:620,y:538,t:1528139583379};\\\", \\\"{x:620,y:544,t:1528139583396};\\\", \\\"{x:620,y:548,t:1528139583412};\\\", \\\"{x:620,y:554,t:1528139583428};\\\", \\\"{x:616,y:564,t:1528139583444};\\\", \\\"{x:611,y:574,t:1528139583462};\\\", \\\"{x:603,y:585,t:1528139583478};\\\", \\\"{x:590,y:601,t:1528139583495};\\\", \\\"{x:584,y:609,t:1528139583513};\\\", \\\"{x:582,y:615,t:1528139583529};\\\", \\\"{x:582,y:620,t:1528139583545};\\\", \\\"{x:582,y:626,t:1528139583562};\\\", \\\"{x:582,y:639,t:1528139583579};\\\", \\\"{x:593,y:657,t:1528139583596};\\\", \\\"{x:609,y:671,t:1528139583613};\\\", \\\"{x:632,y:683,t:1528139583630};\\\", \\\"{x:662,y:686,t:1528139583646};\\\", \\\"{x:708,y:691,t:1528139583662};\\\", \\\"{x:779,y:692,t:1528139583679};\\\", \\\"{x:833,y:694,t:1528139583695};\\\", \\\"{x:879,y:696,t:1528139583712};\\\", \\\"{x:929,y:696,t:1528139583729};\\\", \\\"{x:991,y:696,t:1528139583746};\\\", \\\"{x:1057,y:696,t:1528139583763};\\\", \\\"{x:1116,y:696,t:1528139583780};\\\", \\\"{x:1169,y:696,t:1528139583797};\\\", \\\"{x:1206,y:696,t:1528139583813};\\\", \\\"{x:1229,y:696,t:1528139583830};\\\", \\\"{x:1244,y:696,t:1528139583846};\\\", \\\"{x:1247,y:696,t:1528139583863};\\\", \\\"{x:1241,y:696,t:1528139583904};\\\", \\\"{x:1227,y:697,t:1528139583913};\\\", \\\"{x:1169,y:699,t:1528139583930};\\\", \\\"{x:1052,y:701,t:1528139583946};\\\", \\\"{x:926,y:711,t:1528139583963};\\\", \\\"{x:808,y:719,t:1528139583980};\\\", \\\"{x:693,y:727,t:1528139583997};\\\", \\\"{x:590,y:731,t:1528139584013};\\\", \\\"{x:509,y:731,t:1528139584030};\\\", \\\"{x:456,y:731,t:1528139584047};\\\", \\\"{x:434,y:731,t:1528139584063};\\\", \\\"{x:427,y:731,t:1528139584080};\\\", \\\"{x:428,y:731,t:1528139584193};\\\", \\\"{x:433,y:731,t:1528139584200};\\\", \\\"{x:442,y:730,t:1528139584213};\\\", \\\"{x:459,y:726,t:1528139584230};\\\", \\\"{x:501,y:714,t:1528139584247};\\\", \\\"{x:522,y:709,t:1528139584263};\\\", \\\"{x:535,y:701,t:1528139584279};\\\", \\\"{x:543,y:696,t:1528139584296};\\\", \\\"{x:543,y:695,t:1528139584313};\\\", \\\"{x:543,y:693,t:1528139584351};\\\", \\\"{x:543,y:687,t:1528139584364};\\\", \\\"{x:535,y:669,t:1528139584380};\\\", \\\"{x:519,y:656,t:1528139584396};\\\", \\\"{x:504,y:650,t:1528139584415};\\\", \\\"{x:483,y:645,t:1528139584431};\\\", \\\"{x:457,y:642,t:1528139584446};\\\", \\\"{x:415,y:637,t:1528139584463};\\\", \\\"{x:395,y:633,t:1528139584479};\\\", \\\"{x:388,y:629,t:1528139584497};\\\", \\\"{x:386,y:628,t:1528139584513};\\\", \\\"{x:385,y:627,t:1528139584535};\\\", \\\"{x:385,y:624,t:1528139584680};\\\", \\\"{x:385,y:617,t:1528139584698};\\\", \\\"{x:387,y:605,t:1528139584713};\\\", \\\"{x:392,y:596,t:1528139584730};\\\", \\\"{x:395,y:586,t:1528139584747};\\\", \\\"{x:400,y:581,t:1528139584764};\\\", \\\"{x:400,y:582,t:1528139584968};\\\", \\\"{x:400,y:584,t:1528139584982};\\\", \\\"{x:399,y:586,t:1528139584997};\\\", \\\"{x:402,y:587,t:1528139585391};\\\", \\\"{x:415,y:590,t:1528139585399};\\\", \\\"{x:424,y:590,t:1528139585414};\\\", \\\"{x:453,y:590,t:1528139585431};\\\", \\\"{x:517,y:590,t:1528139585448};\\\", \\\"{x:574,y:593,t:1528139585464};\\\", \\\"{x:638,y:593,t:1528139585481};\\\", \\\"{x:691,y:593,t:1528139585498};\\\", \\\"{x:718,y:593,t:1528139585514};\\\", \\\"{x:738,y:593,t:1528139585531};\\\", \\\"{x:743,y:593,t:1528139585547};\\\", \\\"{x:744,y:593,t:1528139585703};\\\", \\\"{x:746,y:593,t:1528139585715};\\\", \\\"{x:747,y:596,t:1528139585732};\\\", \\\"{x:747,y:597,t:1528139585752};\\\", \\\"{x:748,y:597,t:1528139585944};\\\", \\\"{x:751,y:598,t:1528139586056};\\\", \\\"{x:763,y:598,t:1528139586066};\\\", \\\"{x:798,y:598,t:1528139586083};\\\", \\\"{x:846,y:598,t:1528139586101};\\\", \\\"{x:888,y:598,t:1528139586118};\\\", \\\"{x:944,y:598,t:1528139586131};\\\", \\\"{x:1011,y:598,t:1528139586148};\\\", \\\"{x:1077,y:598,t:1528139586164};\\\", \\\"{x:1152,y:598,t:1528139586181};\\\", \\\"{x:1226,y:604,t:1528139586198};\\\", \\\"{x:1309,y:616,t:1528139586214};\\\", \\\"{x:1352,y:623,t:1528139586231};\\\", \\\"{x:1384,y:628,t:1528139586248};\\\", \\\"{x:1410,y:632,t:1528139586265};\\\", \\\"{x:1434,y:637,t:1528139586282};\\\", \\\"{x:1455,y:646,t:1528139586298};\\\", \\\"{x:1469,y:651,t:1528139586315};\\\", \\\"{x:1472,y:654,t:1528139586332};\\\", \\\"{x:1474,y:659,t:1528139586348};\\\", \\\"{x:1475,y:662,t:1528139586365};\\\", \\\"{x:1477,y:667,t:1528139586382};\\\", \\\"{x:1477,y:673,t:1528139586398};\\\", \\\"{x:1477,y:681,t:1528139586416};\\\", \\\"{x:1477,y:686,t:1528139586431};\\\", \\\"{x:1477,y:692,t:1528139586448};\\\", \\\"{x:1477,y:697,t:1528139586465};\\\", \\\"{x:1474,y:705,t:1528139586482};\\\", \\\"{x:1470,y:714,t:1528139586498};\\\", \\\"{x:1464,y:723,t:1528139586516};\\\", \\\"{x:1456,y:732,t:1528139586532};\\\", \\\"{x:1450,y:740,t:1528139586548};\\\", \\\"{x:1445,y:748,t:1528139586564};\\\", \\\"{x:1439,y:753,t:1528139586581};\\\", \\\"{x:1434,y:757,t:1528139586597};\\\", \\\"{x:1426,y:761,t:1528139586614};\\\", \\\"{x:1422,y:763,t:1528139586631};\\\", \\\"{x:1418,y:765,t:1528139586648};\\\", \\\"{x:1410,y:769,t:1528139586664};\\\", \\\"{x:1400,y:774,t:1528139586681};\\\", \\\"{x:1389,y:779,t:1528139586698};\\\", \\\"{x:1374,y:787,t:1528139586715};\\\", \\\"{x:1365,y:791,t:1528139586731};\\\", \\\"{x:1357,y:794,t:1528139586747};\\\", \\\"{x:1354,y:795,t:1528139586765};\\\", \\\"{x:1353,y:795,t:1528139587024};\\\", \\\"{x:1350,y:797,t:1528139587032};\\\", \\\"{x:1339,y:805,t:1528139587049};\\\", \\\"{x:1321,y:823,t:1528139587064};\\\", \\\"{x:1288,y:868,t:1528139587081};\\\", \\\"{x:1251,y:912,t:1528139587099};\\\", \\\"{x:1214,y:954,t:1528139587114};\\\", \\\"{x:1178,y:991,t:1528139587132};\\\", \\\"{x:1153,y:1012,t:1528139587149};\\\", \\\"{x:1135,y:1030,t:1528139587165};\\\", \\\"{x:1121,y:1040,t:1528139587182};\\\", \\\"{x:1118,y:1042,t:1528139587199};\\\", \\\"{x:1117,y:1042,t:1528139587312};\\\", \\\"{x:1116,y:1042,t:1528139587328};\\\", \\\"{x:1116,y:1039,t:1528139587343};\\\", \\\"{x:1116,y:1035,t:1528139587352};\\\", \\\"{x:1118,y:1030,t:1528139587365};\\\", \\\"{x:1123,y:1021,t:1528139587383};\\\", \\\"{x:1128,y:1007,t:1528139587399};\\\", \\\"{x:1133,y:1001,t:1528139587416};\\\", \\\"{x:1136,y:997,t:1528139587432};\\\", \\\"{x:1140,y:994,t:1528139587450};\\\", \\\"{x:1146,y:993,t:1528139587466};\\\", \\\"{x:1152,y:990,t:1528139587482};\\\", \\\"{x:1161,y:990,t:1528139587499};\\\", \\\"{x:1176,y:986,t:1528139587515};\\\", \\\"{x:1196,y:982,t:1528139587532};\\\", \\\"{x:1205,y:978,t:1528139587550};\\\", \\\"{x:1212,y:975,t:1528139587565};\\\", \\\"{x:1214,y:974,t:1528139587582};\\\", \\\"{x:1216,y:973,t:1528139587599};\\\", \\\"{x:1219,y:971,t:1528139587615};\\\", \\\"{x:1222,y:968,t:1528139587633};\\\", \\\"{x:1226,y:968,t:1528139587650};\\\", \\\"{x:1235,y:965,t:1528139587666};\\\", \\\"{x:1246,y:963,t:1528139587683};\\\", \\\"{x:1259,y:962,t:1528139587700};\\\", \\\"{x:1268,y:962,t:1528139587716};\\\", \\\"{x:1276,y:960,t:1528139587733};\\\", \\\"{x:1283,y:960,t:1528139587749};\\\", \\\"{x:1287,y:960,t:1528139587766};\\\", \\\"{x:1289,y:960,t:1528139587783};\\\", \\\"{x:1290,y:960,t:1528139587824};\\\", \\\"{x:1291,y:960,t:1528139587832};\\\", \\\"{x:1294,y:960,t:1528139587849};\\\", \\\"{x:1297,y:960,t:1528139587865};\\\", \\\"{x:1301,y:960,t:1528139587882};\\\", \\\"{x:1305,y:957,t:1528139587898};\\\", \\\"{x:1309,y:954,t:1528139587915};\\\", \\\"{x:1313,y:948,t:1528139587932};\\\", \\\"{x:1317,y:930,t:1528139587949};\\\", \\\"{x:1317,y:915,t:1528139587966};\\\", \\\"{x:1317,y:901,t:1528139587982};\\\", \\\"{x:1317,y:889,t:1528139587999};\\\", \\\"{x:1317,y:887,t:1528139588016};\\\", \\\"{x:1317,y:886,t:1528139588112};\\\", \\\"{x:1317,y:885,t:1528139588120};\\\", \\\"{x:1318,y:885,t:1528139588133};\\\", \\\"{x:1322,y:881,t:1528139588150};\\\", \\\"{x:1325,y:877,t:1528139588166};\\\", \\\"{x:1328,y:872,t:1528139588183};\\\", \\\"{x:1332,y:865,t:1528139588199};\\\", \\\"{x:1336,y:859,t:1528139588216};\\\", \\\"{x:1340,y:852,t:1528139588233};\\\", \\\"{x:1341,y:847,t:1528139588250};\\\", \\\"{x:1345,y:840,t:1528139588266};\\\", \\\"{x:1348,y:832,t:1528139588282};\\\", \\\"{x:1351,y:823,t:1528139588299};\\\", \\\"{x:1354,y:816,t:1528139588316};\\\", \\\"{x:1355,y:811,t:1528139588331};\\\", \\\"{x:1358,y:804,t:1528139588348};\\\", \\\"{x:1359,y:799,t:1528139588366};\\\", \\\"{x:1362,y:795,t:1528139588381};\\\", \\\"{x:1364,y:788,t:1528139588399};\\\", \\\"{x:1366,y:782,t:1528139588416};\\\", \\\"{x:1370,y:776,t:1528139588432};\\\", \\\"{x:1373,y:773,t:1528139588449};\\\", \\\"{x:1375,y:768,t:1528139588467};\\\", \\\"{x:1376,y:766,t:1528139588486};\\\", \\\"{x:1377,y:765,t:1528139588499};\\\", \\\"{x:1378,y:763,t:1528139588515};\\\", \\\"{x:1378,y:762,t:1528139588591};\\\", \\\"{x:1378,y:760,t:1528139588622};\\\", \\\"{x:1379,y:759,t:1528139588631};\\\", \\\"{x:1380,y:758,t:1528139588646};\\\", \\\"{x:1381,y:757,t:1528139588664};\\\", \\\"{x:1381,y:759,t:1528139588892};\\\", \\\"{x:1383,y:762,t:1528139588900};\\\", \\\"{x:1383,y:764,t:1528139588916};\\\", \\\"{x:1383,y:768,t:1528139588933};\\\", \\\"{x:1384,y:770,t:1528139588951};\\\", \\\"{x:1383,y:770,t:1528139589369};\\\", \\\"{x:1382,y:770,t:1528139589392};\\\", \\\"{x:1381,y:770,t:1528139589544};\\\", \\\"{x:1380,y:769,t:1528139589639};\\\", \\\"{x:1380,y:767,t:1528139589656};\\\", \\\"{x:1380,y:765,t:1528139589683};\\\", \\\"{x:1380,y:764,t:1528139589701};\\\", \\\"{x:1378,y:767,t:1528139590048};\\\", \\\"{x:1373,y:773,t:1528139590058};\\\", \\\"{x:1367,y:779,t:1528139590068};\\\", \\\"{x:1356,y:791,t:1528139590085};\\\", \\\"{x:1345,y:800,t:1528139590101};\\\", \\\"{x:1337,y:806,t:1528139590117};\\\", \\\"{x:1333,y:811,t:1528139590135};\\\", \\\"{x:1329,y:815,t:1528139590151};\\\", \\\"{x:1327,y:816,t:1528139590168};\\\", \\\"{x:1322,y:820,t:1528139590185};\\\", \\\"{x:1318,y:823,t:1528139590201};\\\", \\\"{x:1314,y:827,t:1528139590218};\\\", \\\"{x:1308,y:831,t:1528139590235};\\\", \\\"{x:1300,y:837,t:1528139590251};\\\", \\\"{x:1290,y:843,t:1528139590268};\\\", \\\"{x:1274,y:851,t:1528139590285};\\\", \\\"{x:1251,y:858,t:1528139590301};\\\", \\\"{x:1222,y:864,t:1528139590318};\\\", \\\"{x:1170,y:873,t:1528139590336};\\\", \\\"{x:1143,y:874,t:1528139590352};\\\", \\\"{x:1121,y:874,t:1528139590369};\\\", \\\"{x:1100,y:874,t:1528139590385};\\\", \\\"{x:1079,y:874,t:1528139590402};\\\", \\\"{x:1058,y:874,t:1528139590419};\\\", \\\"{x:1036,y:874,t:1528139590436};\\\", \\\"{x:1006,y:874,t:1528139590451};\\\", \\\"{x:977,y:874,t:1528139590469};\\\", \\\"{x:926,y:874,t:1528139590486};\\\", \\\"{x:859,y:874,t:1528139590502};\\\", \\\"{x:806,y:874,t:1528139590518};\\\", \\\"{x:738,y:867,t:1528139590535};\\\", \\\"{x:715,y:861,t:1528139590552};\\\", \\\"{x:697,y:854,t:1528139590569};\\\", \\\"{x:690,y:850,t:1528139590585};\\\", \\\"{x:689,y:850,t:1528139590602};\\\", \\\"{x:688,y:850,t:1528139590618};\\\", \\\"{x:686,y:848,t:1528139590635};\\\", \\\"{x:682,y:845,t:1528139590652};\\\", \\\"{x:676,y:840,t:1528139590668};\\\", \\\"{x:668,y:834,t:1528139590685};\\\", \\\"{x:659,y:830,t:1528139590702};\\\", \\\"{x:642,y:823,t:1528139590717};\\\", \\\"{x:614,y:810,t:1528139590734};\\\", \\\"{x:603,y:803,t:1528139590752};\\\", \\\"{x:593,y:795,t:1528139590768};\\\", \\\"{x:589,y:790,t:1528139590785};\\\", \\\"{x:587,y:788,t:1528139590802};\\\", \\\"{x:586,y:787,t:1528139590818};\\\", \\\"{x:584,y:786,t:1528139590835};\\\", \\\"{x:575,y:783,t:1528139590852};\\\", \\\"{x:561,y:779,t:1528139590868};\\\", \\\"{x:549,y:772,t:1528139590886};\\\", \\\"{x:535,y:764,t:1528139590903};\\\", \\\"{x:526,y:757,t:1528139590918};\\\", \\\"{x:520,y:753,t:1528139590935};\\\", \\\"{x:519,y:751,t:1528139590952};\\\", \\\"{x:518,y:751,t:1528139591480};\\\", \\\"{x:544,y:749,t:1528139591864};\\\", \\\"{x:580,y:738,t:1528139591872};\\\", \\\"{x:607,y:733,t:1528139591887};\\\", \\\"{x:693,y:729,t:1528139591904};\\\", \\\"{x:720,y:726,t:1528139591919};\\\", \\\"{x:742,y:725,t:1528139591936};\\\", \\\"{x:763,y:721,t:1528139591953};\\\", \\\"{x:791,y:721,t:1528139591969};\\\", \\\"{x:824,y:721,t:1528139591986};\\\", \\\"{x:866,y:721,t:1528139592003};\\\", \\\"{x:934,y:718,t:1528139592019};\\\", \\\"{x:1007,y:716,t:1528139592036};\\\", \\\"{x:1081,y:709,t:1528139592054};\\\", \\\"{x:1141,y:704,t:1528139592070};\\\", \\\"{x:1181,y:702,t:1528139592086};\\\", \\\"{x:1216,y:702,t:1528139592103};\\\", \\\"{x:1227,y:702,t:1528139592119};\\\", \\\"{x:1229,y:702,t:1528139592137};\\\" ] }, { \\\"rt\\\": 17930, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 6, \\\"time_elapsed\\\": 354390, \\\"internal_node_id\\\": \\\"0.0-5.0-1.0\\\", \\\"subject\\\": \\\"JYGX2\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"yankee\\\", \\\"condition\\\": \\\"311\\\", \\\"scenario\\\": \\\"acme\\\", \\\"question\\\": \\\"starts\\\", \\\"q\\\": 2, \\\"clicks\\\": 1, \\\"explicit\\\": 3, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XInside-YFull\\\", \\\"correct\\\": 1, \\\"orth_correct\\\": 0, \\\"answer\\\": [ \\\"K\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"X \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"U \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-K -K -D -D -K -K -K -K \\\", \\\"block\\\": \\\"triangular_scaffolded\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:1179,y:714,t:1528139592494};\\\", \\\"{x:1168,y:715,t:1528139592502};\\\", \\\"{x:1158,y:718,t:1528139592520};\\\", \\\"{x:1152,y:718,t:1528139592537};\\\", \\\"{x:1149,y:719,t:1528139592553};\\\", \\\"{x:1146,y:719,t:1528139592582};\\\", \\\"{x:1146,y:720,t:1528139592590};\\\", \\\"{x:1145,y:721,t:1528139592602};\\\", \\\"{x:1143,y:722,t:1528139592620};\\\", \\\"{x:1140,y:723,t:1528139592636};\\\", \\\"{x:1136,y:725,t:1528139592653};\\\", \\\"{x:1133,y:728,t:1528139592670};\\\", \\\"{x:1127,y:729,t:1528139592686};\\\", \\\"{x:1122,y:730,t:1528139592703};\\\", \\\"{x:1120,y:731,t:1528139592719};\\\", \\\"{x:1118,y:732,t:1528139593055};\\\", \\\"{x:1116,y:734,t:1528139593070};\\\", \\\"{x:1097,y:741,t:1528139593087};\\\", \\\"{x:1077,y:749,t:1528139593103};\\\", \\\"{x:1054,y:757,t:1528139593120};\\\", \\\"{x:1033,y:764,t:1528139593137};\\\", \\\"{x:1011,y:769,t:1528139593152};\\\", \\\"{x:993,y:775,t:1528139593170};\\\", \\\"{x:976,y:780,t:1528139593187};\\\", \\\"{x:961,y:784,t:1528139593203};\\\", \\\"{x:957,y:786,t:1528139593220};\\\", \\\"{x:953,y:786,t:1528139593237};\\\", \\\"{x:951,y:788,t:1528139593253};\\\", \\\"{x:949,y:788,t:1528139593270};\\\", \\\"{x:948,y:788,t:1528139593287};\\\", \\\"{x:947,y:788,t:1528139593303};\\\", \\\"{x:947,y:789,t:1528139593344};\\\", \\\"{x:946,y:789,t:1528139593353};\\\", \\\"{x:945,y:789,t:1528139593370};\\\", \\\"{x:944,y:791,t:1528139593407};\\\", \\\"{x:943,y:791,t:1528139593472};\\\", \\\"{x:941,y:793,t:1528139593487};\\\", \\\"{x:940,y:794,t:1528139593504};\\\", \\\"{x:939,y:796,t:1528139593520};\\\", \\\"{x:938,y:796,t:1528139593752};\\\", \\\"{x:938,y:797,t:1528139593824};\\\", \\\"{x:937,y:799,t:1528139593855};\\\", \\\"{x:937,y:801,t:1528139597008};\\\", \\\"{x:937,y:802,t:1528139597023};\\\", \\\"{x:936,y:803,t:1528139597262};\\\", \\\"{x:935,y:803,t:1528139597286};\\\", \\\"{x:934,y:803,t:1528139597294};\\\", \\\"{x:934,y:800,t:1528139597327};\\\", \\\"{x:939,y:796,t:1528139597339};\\\", \\\"{x:953,y:789,t:1528139597356};\\\", \\\"{x:972,y:780,t:1528139597373};\\\", \\\"{x:993,y:767,t:1528139597390};\\\", \\\"{x:1018,y:755,t:1528139597406};\\\", \\\"{x:1043,y:736,t:1528139597423};\\\", \\\"{x:1058,y:724,t:1528139597440};\\\", \\\"{x:1075,y:710,t:1528139597457};\\\", \\\"{x:1086,y:700,t:1528139597473};\\\", \\\"{x:1097,y:689,t:1528139597490};\\\", \\\"{x:1105,y:681,t:1528139597506};\\\", \\\"{x:1117,y:671,t:1528139597524};\\\", \\\"{x:1130,y:661,t:1528139597541};\\\", \\\"{x:1149,y:647,t:1528139597556};\\\", \\\"{x:1171,y:631,t:1528139597573};\\\", \\\"{x:1196,y:615,t:1528139597590};\\\", \\\"{x:1227,y:594,t:1528139597607};\\\", \\\"{x:1296,y:552,t:1528139597623};\\\", \\\"{x:1326,y:534,t:1528139597640};\\\", \\\"{x:1349,y:521,t:1528139597656};\\\", \\\"{x:1370,y:510,t:1528139597674};\\\", \\\"{x:1386,y:503,t:1528139597690};\\\", \\\"{x:1396,y:497,t:1528139597707};\\\", \\\"{x:1405,y:492,t:1528139597724};\\\", \\\"{x:1410,y:490,t:1528139597741};\\\", \\\"{x:1414,y:486,t:1528139597757};\\\", \\\"{x:1422,y:478,t:1528139597774};\\\", \\\"{x:1430,y:473,t:1528139597790};\\\", \\\"{x:1434,y:469,t:1528139597806};\\\", \\\"{x:1446,y:462,t:1528139597824};\\\", \\\"{x:1451,y:458,t:1528139597841};\\\", \\\"{x:1462,y:453,t:1528139597857};\\\", \\\"{x:1471,y:450,t:1528139597873};\\\", \\\"{x:1484,y:447,t:1528139597890};\\\", \\\"{x:1493,y:443,t:1528139597906};\\\", \\\"{x:1504,y:438,t:1528139597923};\\\", \\\"{x:1515,y:433,t:1528139597940};\\\", \\\"{x:1523,y:428,t:1528139597956};\\\", \\\"{x:1536,y:424,t:1528139597973};\\\", \\\"{x:1551,y:420,t:1528139597990};\\\", \\\"{x:1566,y:417,t:1528139598006};\\\", \\\"{x:1581,y:415,t:1528139598023};\\\", \\\"{x:1587,y:414,t:1528139598040};\\\", \\\"{x:1596,y:412,t:1528139598057};\\\", \\\"{x:1599,y:411,t:1528139598073};\\\", \\\"{x:1603,y:411,t:1528139598090};\\\", \\\"{x:1606,y:411,t:1528139598107};\\\", \\\"{x:1608,y:410,t:1528139598123};\\\", \\\"{x:1613,y:409,t:1528139598141};\\\", \\\"{x:1616,y:407,t:1528139598157};\\\", \\\"{x:1623,y:406,t:1528139598174};\\\", \\\"{x:1628,y:406,t:1528139598190};\\\", \\\"{x:1639,y:406,t:1528139598208};\\\", \\\"{x:1646,y:406,t:1528139598223};\\\", \\\"{x:1651,y:406,t:1528139598241};\\\", \\\"{x:1653,y:407,t:1528139598257};\\\", \\\"{x:1654,y:408,t:1528139598273};\\\", \\\"{x:1657,y:411,t:1528139598290};\\\", \\\"{x:1659,y:414,t:1528139598307};\\\", \\\"{x:1659,y:418,t:1528139598323};\\\", \\\"{x:1659,y:421,t:1528139598340};\\\", \\\"{x:1659,y:423,t:1528139598357};\\\", \\\"{x:1659,y:425,t:1528139598373};\\\", \\\"{x:1659,y:428,t:1528139598391};\\\", \\\"{x:1656,y:434,t:1528139598406};\\\", \\\"{x:1653,y:437,t:1528139598423};\\\", \\\"{x:1647,y:440,t:1528139598440};\\\", \\\"{x:1642,y:442,t:1528139598457};\\\", \\\"{x:1640,y:442,t:1528139598473};\\\", \\\"{x:1639,y:442,t:1528139598490};\\\", \\\"{x:1638,y:442,t:1528139598507};\\\", \\\"{x:1636,y:442,t:1528139598524};\\\", \\\"{x:1633,y:442,t:1528139598540};\\\", \\\"{x:1629,y:442,t:1528139598557};\\\", \\\"{x:1628,y:442,t:1528139598574};\\\", \\\"{x:1627,y:442,t:1528139598591};\\\", \\\"{x:1625,y:441,t:1528139598615};\\\", \\\"{x:1623,y:441,t:1528139598855};\\\", \\\"{x:1622,y:441,t:1528139598864};\\\", \\\"{x:1620,y:442,t:1528139598875};\\\", \\\"{x:1616,y:444,t:1528139598891};\\\", \\\"{x:1610,y:448,t:1528139598908};\\\", \\\"{x:1608,y:449,t:1528139598924};\\\", \\\"{x:1607,y:449,t:1528139598940};\\\", \\\"{x:1606,y:450,t:1528139598967};\\\", \\\"{x:1605,y:453,t:1528139599079};\\\", \\\"{x:1604,y:454,t:1528139599091};\\\", \\\"{x:1601,y:457,t:1528139599107};\\\", \\\"{x:1596,y:464,t:1528139599124};\\\", \\\"{x:1590,y:473,t:1528139599142};\\\", \\\"{x:1585,y:481,t:1528139599158};\\\", \\\"{x:1581,y:488,t:1528139599175};\\\", \\\"{x:1578,y:494,t:1528139599191};\\\", \\\"{x:1577,y:496,t:1528139599208};\\\", \\\"{x:1577,y:497,t:1528139599225};\\\", \\\"{x:1577,y:499,t:1528139599242};\\\", \\\"{x:1577,y:500,t:1528139599258};\\\", \\\"{x:1575,y:503,t:1528139599274};\\\", \\\"{x:1575,y:508,t:1528139599291};\\\", \\\"{x:1573,y:513,t:1528139599307};\\\", \\\"{x:1571,y:517,t:1528139599324};\\\", \\\"{x:1570,y:524,t:1528139599342};\\\", \\\"{x:1569,y:528,t:1528139599358};\\\", \\\"{x:1567,y:532,t:1528139599374};\\\", \\\"{x:1563,y:542,t:1528139599391};\\\", \\\"{x:1559,y:551,t:1528139599407};\\\", \\\"{x:1556,y:559,t:1528139599425};\\\", \\\"{x:1549,y:572,t:1528139599442};\\\", \\\"{x:1541,y:590,t:1528139599458};\\\", \\\"{x:1531,y:606,t:1528139599475};\\\", \\\"{x:1524,y:619,t:1528139599491};\\\", \\\"{x:1517,y:628,t:1528139599514};\\\", \\\"{x:1511,y:638,t:1528139599540};\\\", \\\"{x:1510,y:641,t:1528139599558};\\\", \\\"{x:1508,y:643,t:1528139599575};\\\", \\\"{x:1507,y:645,t:1528139599606};\\\", \\\"{x:1506,y:646,t:1528139599622};\\\", \\\"{x:1506,y:647,t:1528139599638};\\\", \\\"{x:1505,y:649,t:1528139599655};\\\", \\\"{x:1505,y:648,t:1528139599935};\\\", \\\"{x:1505,y:646,t:1528139599943};\\\", \\\"{x:1506,y:641,t:1528139599960};\\\", \\\"{x:1507,y:638,t:1528139599977};\\\", \\\"{x:1507,y:635,t:1528139600256};\\\", \\\"{x:1509,y:633,t:1528139600264};\\\", \\\"{x:1509,y:632,t:1528139600279};\\\", \\\"{x:1509,y:631,t:1528139600293};\\\", \\\"{x:1510,y:630,t:1528139600309};\\\", \\\"{x:1510,y:629,t:1528139600326};\\\", \\\"{x:1510,y:636,t:1528139601063};\\\", \\\"{x:1508,y:643,t:1528139601077};\\\", \\\"{x:1498,y:658,t:1528139601094};\\\", \\\"{x:1491,y:669,t:1528139601110};\\\", \\\"{x:1485,y:680,t:1528139601126};\\\", \\\"{x:1480,y:692,t:1528139601142};\\\", \\\"{x:1477,y:698,t:1528139601160};\\\", \\\"{x:1474,y:703,t:1528139601176};\\\", \\\"{x:1471,y:710,t:1528139601194};\\\", \\\"{x:1468,y:718,t:1528139601210};\\\", \\\"{x:1463,y:728,t:1528139601226};\\\", \\\"{x:1459,y:739,t:1528139601244};\\\", \\\"{x:1450,y:753,t:1528139601260};\\\", \\\"{x:1443,y:764,t:1528139601276};\\\", \\\"{x:1437,y:772,t:1528139601293};\\\", \\\"{x:1434,y:778,t:1528139601310};\\\", \\\"{x:1432,y:779,t:1528139601326};\\\", \\\"{x:1427,y:785,t:1528139601343};\\\", \\\"{x:1424,y:790,t:1528139601361};\\\", \\\"{x:1420,y:798,t:1528139601376};\\\", \\\"{x:1415,y:808,t:1528139601393};\\\", \\\"{x:1410,y:819,t:1528139601411};\\\", \\\"{x:1405,y:831,t:1528139601427};\\\", \\\"{x:1401,y:842,t:1528139601443};\\\", \\\"{x:1398,y:847,t:1528139601461};\\\", \\\"{x:1395,y:855,t:1528139601477};\\\", \\\"{x:1393,y:859,t:1528139601493};\\\", \\\"{x:1392,y:863,t:1528139601510};\\\", \\\"{x:1390,y:868,t:1528139601527};\\\", \\\"{x:1389,y:872,t:1528139601543};\\\", \\\"{x:1388,y:877,t:1528139601561};\\\", \\\"{x:1386,y:884,t:1528139601578};\\\", \\\"{x:1384,y:892,t:1528139601593};\\\", \\\"{x:1380,y:899,t:1528139601610};\\\", \\\"{x:1376,y:907,t:1528139601627};\\\", \\\"{x:1371,y:915,t:1528139601643};\\\", \\\"{x:1366,y:922,t:1528139601660};\\\", \\\"{x:1364,y:925,t:1528139601677};\\\", \\\"{x:1363,y:926,t:1528139601694};\\\", \\\"{x:1364,y:926,t:1528139601910};\\\", \\\"{x:1374,y:912,t:1528139601927};\\\", \\\"{x:1382,y:891,t:1528139601945};\\\", \\\"{x:1393,y:867,t:1528139601960};\\\", \\\"{x:1404,y:845,t:1528139601977};\\\", \\\"{x:1417,y:823,t:1528139601994};\\\", \\\"{x:1427,y:803,t:1528139602011};\\\", \\\"{x:1439,y:782,t:1528139602028};\\\", \\\"{x:1448,y:761,t:1528139602045};\\\", \\\"{x:1459,y:742,t:1528139602060};\\\", \\\"{x:1466,y:728,t:1528139602078};\\\", \\\"{x:1474,y:716,t:1528139602094};\\\", \\\"{x:1481,y:703,t:1528139602111};\\\", \\\"{x:1495,y:675,t:1528139602127};\\\", \\\"{x:1503,y:658,t:1528139602145};\\\", \\\"{x:1513,y:636,t:1528139602160};\\\", \\\"{x:1518,y:618,t:1528139602178};\\\", \\\"{x:1526,y:599,t:1528139602194};\\\", \\\"{x:1536,y:583,t:1528139602211};\\\", \\\"{x:1545,y:567,t:1528139602228};\\\", \\\"{x:1553,y:551,t:1528139602245};\\\", \\\"{x:1561,y:536,t:1528139602260};\\\", \\\"{x:1568,y:523,t:1528139602277};\\\", \\\"{x:1577,y:509,t:1528139602294};\\\", \\\"{x:1586,y:492,t:1528139602310};\\\", \\\"{x:1589,y:482,t:1528139602327};\\\", \\\"{x:1592,y:474,t:1528139602345};\\\", \\\"{x:1593,y:465,t:1528139602361};\\\", \\\"{x:1595,y:452,t:1528139602378};\\\", \\\"{x:1597,y:441,t:1528139602394};\\\", \\\"{x:1599,y:434,t:1528139602411};\\\", \\\"{x:1599,y:433,t:1528139602427};\\\", \\\"{x:1599,y:432,t:1528139602558};\\\", \\\"{x:1599,y:429,t:1528139602566};\\\", \\\"{x:1601,y:425,t:1528139602577};\\\", \\\"{x:1603,y:423,t:1528139602594};\\\", \\\"{x:1606,y:420,t:1528139602611};\\\", \\\"{x:1607,y:420,t:1528139602627};\\\", \\\"{x:1608,y:420,t:1528139602644};\\\", \\\"{x:1610,y:420,t:1528139602661};\\\", \\\"{x:1611,y:420,t:1528139602677};\\\", \\\"{x:1613,y:420,t:1528139602694};\\\", \\\"{x:1614,y:420,t:1528139602711};\\\", \\\"{x:1614,y:422,t:1528139603143};\\\", \\\"{x:1614,y:425,t:1528139603166};\\\", \\\"{x:1614,y:428,t:1528139603179};\\\", \\\"{x:1613,y:430,t:1528139603195};\\\", \\\"{x:1613,y:431,t:1528139603211};\\\", \\\"{x:1613,y:432,t:1528139603230};\\\", \\\"{x:1613,y:438,t:1528139603715};\\\", \\\"{x:1607,y:455,t:1528139603728};\\\", \\\"{x:1593,y:479,t:1528139603745};\\\", \\\"{x:1580,y:498,t:1528139603762};\\\", \\\"{x:1571,y:514,t:1528139603778};\\\", \\\"{x:1563,y:526,t:1528139603795};\\\", \\\"{x:1557,y:536,t:1528139603813};\\\", \\\"{x:1552,y:545,t:1528139603828};\\\", \\\"{x:1549,y:553,t:1528139603845};\\\", \\\"{x:1542,y:570,t:1528139603863};\\\", \\\"{x:1539,y:576,t:1528139603878};\\\", \\\"{x:1530,y:595,t:1528139603895};\\\", \\\"{x:1525,y:607,t:1528139603913};\\\", \\\"{x:1520,y:618,t:1528139603929};\\\", \\\"{x:1518,y:624,t:1528139603946};\\\", \\\"{x:1515,y:628,t:1528139603966};\\\", \\\"{x:1515,y:629,t:1528139603978};\\\", \\\"{x:1515,y:630,t:1528139603995};\\\", \\\"{x:1515,y:631,t:1528139604047};\\\", \\\"{x:1512,y:634,t:1528139605608};\\\", \\\"{x:1511,y:634,t:1528139605615};\\\", \\\"{x:1507,y:635,t:1528139605633};\\\", \\\"{x:1499,y:636,t:1528139605647};\\\", \\\"{x:1497,y:637,t:1528139605663};\\\", \\\"{x:1498,y:637,t:1528139606032};\\\", \\\"{x:1503,y:637,t:1528139606047};\\\", \\\"{x:1509,y:636,t:1528139606064};\\\", \\\"{x:1512,y:636,t:1528139606081};\\\", \\\"{x:1515,y:635,t:1528139606103};\\\", \\\"{x:1515,y:634,t:1528139606230};\\\", \\\"{x:1516,y:633,t:1528139606247};\\\", \\\"{x:1517,y:632,t:1528139606263};\\\", \\\"{x:1518,y:632,t:1528139606280};\\\", \\\"{x:1517,y:632,t:1528139607007};\\\", \\\"{x:1514,y:632,t:1528139607014};\\\", \\\"{x:1505,y:633,t:1528139607034};\\\", \\\"{x:1494,y:637,t:1528139607048};\\\", \\\"{x:1481,y:641,t:1528139607064};\\\", \\\"{x:1470,y:643,t:1528139607081};\\\", \\\"{x:1458,y:646,t:1528139607097};\\\", \\\"{x:1449,y:650,t:1528139607114};\\\", \\\"{x:1442,y:651,t:1528139607131};\\\", \\\"{x:1436,y:655,t:1528139607147};\\\", \\\"{x:1425,y:660,t:1528139607164};\\\", \\\"{x:1414,y:667,t:1528139607181};\\\", \\\"{x:1400,y:676,t:1528139607198};\\\", \\\"{x:1374,y:692,t:1528139607215};\\\", \\\"{x:1355,y:702,t:1528139607231};\\\", \\\"{x:1329,y:718,t:1528139607247};\\\", \\\"{x:1288,y:741,t:1528139607265};\\\", \\\"{x:1256,y:763,t:1528139607282};\\\", \\\"{x:1221,y:784,t:1528139607297};\\\", \\\"{x:1175,y:809,t:1528139607314};\\\", \\\"{x:1138,y:830,t:1528139607331};\\\", \\\"{x:1116,y:842,t:1528139607348};\\\", \\\"{x:1097,y:853,t:1528139607364};\\\", \\\"{x:1084,y:860,t:1528139607382};\\\", \\\"{x:1077,y:864,t:1528139607398};\\\", \\\"{x:1073,y:867,t:1528139607415};\\\", \\\"{x:1071,y:868,t:1528139607431};\\\", \\\"{x:1070,y:869,t:1528139607448};\\\", \\\"{x:1071,y:865,t:1528139607680};\\\", \\\"{x:1074,y:859,t:1528139607688};\\\", \\\"{x:1081,y:851,t:1528139607699};\\\", \\\"{x:1095,y:831,t:1528139607715};\\\", \\\"{x:1122,y:800,t:1528139607732};\\\", \\\"{x:1159,y:765,t:1528139607749};\\\", \\\"{x:1203,y:736,t:1528139607765};\\\", \\\"{x:1238,y:718,t:1528139607782};\\\", \\\"{x:1270,y:703,t:1528139607800};\\\", \\\"{x:1284,y:696,t:1528139607815};\\\", \\\"{x:1301,y:688,t:1528139607832};\\\", \\\"{x:1316,y:683,t:1528139607850};\\\", \\\"{x:1327,y:677,t:1528139607865};\\\", \\\"{x:1347,y:667,t:1528139607882};\\\", \\\"{x:1360,y:660,t:1528139607899};\\\", \\\"{x:1375,y:652,t:1528139607915};\\\", \\\"{x:1388,y:646,t:1528139607932};\\\", \\\"{x:1404,y:640,t:1528139607948};\\\", \\\"{x:1412,y:637,t:1528139607965};\\\", \\\"{x:1422,y:636,t:1528139607982};\\\", \\\"{x:1437,y:636,t:1528139607999};\\\", \\\"{x:1448,y:636,t:1528139608015};\\\", \\\"{x:1460,y:636,t:1528139608032};\\\", \\\"{x:1467,y:636,t:1528139608051};\\\", \\\"{x:1476,y:636,t:1528139608066};\\\", \\\"{x:1486,y:636,t:1528139608082};\\\", \\\"{x:1495,y:635,t:1528139608099};\\\", \\\"{x:1502,y:634,t:1528139608116};\\\", \\\"{x:1510,y:633,t:1528139608136};\\\", \\\"{x:1515,y:632,t:1528139608148};\\\", \\\"{x:1522,y:632,t:1528139608166};\\\", \\\"{x:1527,y:632,t:1528139608182};\\\", \\\"{x:1528,y:632,t:1528139608222};\\\", \\\"{x:1528,y:631,t:1528139608270};\\\", \\\"{x:1527,y:631,t:1528139608351};\\\", \\\"{x:1524,y:631,t:1528139608365};\\\", \\\"{x:1519,y:631,t:1528139608386};\\\", \\\"{x:1518,y:631,t:1528139608398};\\\", \\\"{x:1517,y:631,t:1528139608430};\\\", \\\"{x:1515,y:631,t:1528139608743};\\\", \\\"{x:1510,y:631,t:1528139608751};\\\", \\\"{x:1453,y:636,t:1528139608782};\\\", \\\"{x:1377,y:642,t:1528139608799};\\\", \\\"{x:1290,y:645,t:1528139608816};\\\", \\\"{x:1207,y:654,t:1528139608833};\\\", \\\"{x:1131,y:667,t:1528139608850};\\\", \\\"{x:1089,y:674,t:1528139608865};\\\", \\\"{x:1063,y:678,t:1528139608882};\\\", \\\"{x:1043,y:681,t:1528139608900};\\\", \\\"{x:1033,y:682,t:1528139608915};\\\", \\\"{x:1025,y:683,t:1528139608933};\\\", \\\"{x:1016,y:684,t:1528139608949};\\\", \\\"{x:1007,y:684,t:1528139608965};\\\", \\\"{x:982,y:688,t:1528139608983};\\\", \\\"{x:962,y:691,t:1528139609000};\\\", \\\"{x:944,y:693,t:1528139609015};\\\", \\\"{x:929,y:695,t:1528139609033};\\\", \\\"{x:915,y:696,t:1528139609050};\\\", \\\"{x:899,y:696,t:1528139609066};\\\", \\\"{x:880,y:696,t:1528139609083};\\\", \\\"{x:859,y:696,t:1528139609100};\\\", \\\"{x:836,y:696,t:1528139609115};\\\", \\\"{x:809,y:696,t:1528139609133};\\\", \\\"{x:774,y:693,t:1528139609150};\\\", \\\"{x:718,y:688,t:1528139609167};\\\", \\\"{x:689,y:688,t:1528139609183};\\\", \\\"{x:661,y:687,t:1528139609200};\\\", \\\"{x:639,y:687,t:1528139609217};\\\", \\\"{x:618,y:683,t:1528139609235};\\\", \\\"{x:596,y:680,t:1528139609249};\\\", \\\"{x:579,y:677,t:1528139609267};\\\", \\\"{x:559,y:675,t:1528139609283};\\\", \\\"{x:546,y:673,t:1528139609299};\\\", \\\"{x:534,y:671,t:1528139609316};\\\", \\\"{x:529,y:670,t:1528139609332};\\\", \\\"{x:524,y:670,t:1528139609349};\\\", \\\"{x:519,y:668,t:1528139609366};\\\", \\\"{x:517,y:668,t:1528139609382};\\\", \\\"{x:512,y:667,t:1528139609399};\\\", \\\"{x:503,y:664,t:1528139609416};\\\", \\\"{x:491,y:663,t:1528139609434};\\\", \\\"{x:470,y:661,t:1528139609449};\\\", \\\"{x:447,y:659,t:1528139609466};\\\", \\\"{x:426,y:659,t:1528139609483};\\\", \\\"{x:408,y:657,t:1528139609499};\\\", \\\"{x:397,y:654,t:1528139609517};\\\", \\\"{x:391,y:651,t:1528139609534};\\\", \\\"{x:388,y:648,t:1528139609550};\\\", \\\"{x:385,y:646,t:1528139609566};\\\", \\\"{x:380,y:643,t:1528139609583};\\\", \\\"{x:380,y:642,t:1528139609606};\\\", \\\"{x:380,y:641,t:1528139609646};\\\", \\\"{x:380,y:640,t:1528139609655};\\\", \\\"{x:380,y:639,t:1528139609670};\\\", \\\"{x:380,y:638,t:1528139609683};\\\", \\\"{x:381,y:638,t:1528139609966};\\\", \\\"{x:393,y:645,t:1528139609984};\\\", \\\"{x:416,y:669,t:1528139609999};\\\", \\\"{x:447,y:699,t:1528139610017};\\\", \\\"{x:478,y:723,t:1528139610034};\\\", \\\"{x:487,y:733,t:1528139610051};\\\", \\\"{x:491,y:739,t:1528139610067};\\\", \\\"{x:492,y:742,t:1528139610083};\\\", \\\"{x:492,y:743,t:1528139610100};\\\", \\\"{x:493,y:745,t:1528139610116};\\\", \\\"{x:493,y:746,t:1528139610655};\\\", \\\"{x:498,y:746,t:1528139610668};\\\", \\\"{x:517,y:756,t:1528139610683};\\\", \\\"{x:539,y:765,t:1528139610701};\\\", \\\"{x:577,y:782,t:1528139610718};\\\", \\\"{x:625,y:797,t:1528139610735};\\\", \\\"{x:656,y:804,t:1528139610750};\\\", \\\"{x:677,y:812,t:1528139610768};\\\", \\\"{x:701,y:819,t:1528139610785};\\\", \\\"{x:715,y:821,t:1528139610800};\\\", \\\"{x:728,y:825,t:1528139610818};\\\", \\\"{x:735,y:827,t:1528139610834};\\\", \\\"{x:738,y:828,t:1528139610851};\\\", \\\"{x:741,y:829,t:1528139610868};\\\", \\\"{x:742,y:829,t:1528139610885};\\\", \\\"{x:743,y:829,t:1528139610951};\\\", \\\"{x:745,y:829,t:1528139611303};\\\", \\\"{x:746,y:829,t:1528139611318};\\\" ] }, { \\\"rt\\\": 17083, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 7, \\\"time_elapsed\\\": 372698, \\\"internal_node_id\\\": \\\"0.0-5.0-2.0\\\", \\\"subject\\\": \\\"JYGX2\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"yankee\\\", \\\"condition\\\": \\\"311\\\", \\\"scenario\\\": \\\"acme\\\", \\\"question\\\": \\\"meets\\\", \\\"q\\\": 3, \\\"clicks\\\": 1, \\\"explicit\\\": 3, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XInside-YFull\\\", \\\"correct\\\": 1, \\\"orth_correct\\\": 0, \\\"answer\\\": [ \\\"F\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"X \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"U \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-H -C -C -C -C -C \\\", \\\"block\\\": \\\"triangular_scaffolded\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:747,y:827,t:1528139612142};\\\", \\\"{x:750,y:824,t:1528139612151};\\\", \\\"{x:753,y:820,t:1528139612169};\\\", \\\"{x:755,y:819,t:1528139612185};\\\", \\\"{x:754,y:816,t:1528139612202};\\\", \\\"{x:747,y:816,t:1528139612218};\\\", \\\"{x:732,y:816,t:1528139612235};\\\", \\\"{x:730,y:816,t:1528139612251};\\\", \\\"{x:730,y:814,t:1528139613015};\\\", \\\"{x:730,y:810,t:1528139613023};\\\", \\\"{x:730,y:807,t:1528139613039};\\\", \\\"{x:731,y:805,t:1528139613053};\\\", \\\"{x:734,y:805,t:1528139613069};\\\", \\\"{x:735,y:805,t:1528139613086};\\\", \\\"{x:735,y:804,t:1528139613151};\\\", \\\"{x:737,y:803,t:1528139613159};\\\", \\\"{x:739,y:801,t:1528139613170};\\\", \\\"{x:747,y:798,t:1528139613186};\\\", \\\"{x:760,y:790,t:1528139613203};\\\", \\\"{x:772,y:785,t:1528139613220};\\\", \\\"{x:781,y:782,t:1528139613235};\\\", \\\"{x:789,y:778,t:1528139613253};\\\", \\\"{x:794,y:777,t:1528139613269};\\\", \\\"{x:799,y:775,t:1528139613285};\\\", \\\"{x:801,y:775,t:1528139613303};\\\", \\\"{x:802,y:774,t:1528139613320};\\\", \\\"{x:802,y:772,t:1528139613392};\\\", \\\"{x:802,y:771,t:1528139613407};\\\", \\\"{x:802,y:770,t:1528139613431};\\\", \\\"{x:802,y:769,t:1528139613463};\\\", \\\"{x:802,y:768,t:1528139613576};\\\", \\\"{x:803,y:768,t:1528139614400};\\\", \\\"{x:804,y:768,t:1528139615271};\\\", \\\"{x:805,y:768,t:1528139615288};\\\", \\\"{x:807,y:768,t:1528139616365};\\\", \\\"{x:815,y:766,t:1528139616379};\\\", \\\"{x:831,y:764,t:1528139616395};\\\", \\\"{x:855,y:762,t:1528139616411};\\\", \\\"{x:887,y:757,t:1528139616429};\\\", \\\"{x:950,y:754,t:1528139616445};\\\", \\\"{x:998,y:754,t:1528139616462};\\\", \\\"{x:1047,y:750,t:1528139616478};\\\", \\\"{x:1105,y:745,t:1528139616495};\\\", \\\"{x:1152,y:739,t:1528139616513};\\\", \\\"{x:1188,y:735,t:1528139616529};\\\", \\\"{x:1222,y:730,t:1528139616546};\\\", \\\"{x:1250,y:727,t:1528139616562};\\\", \\\"{x:1273,y:722,t:1528139616579};\\\", \\\"{x:1298,y:719,t:1528139616597};\\\", \\\"{x:1319,y:717,t:1528139616613};\\\", \\\"{x:1338,y:713,t:1528139616629};\\\", \\\"{x:1357,y:707,t:1528139616646};\\\", \\\"{x:1363,y:706,t:1528139616664};\\\", \\\"{x:1369,y:703,t:1528139616679};\\\", \\\"{x:1375,y:698,t:1528139616695};\\\", \\\"{x:1382,y:688,t:1528139616713};\\\", \\\"{x:1388,y:676,t:1528139616729};\\\", \\\"{x:1400,y:659,t:1528139616746};\\\", \\\"{x:1406,y:647,t:1528139616763};\\\", \\\"{x:1413,y:630,t:1528139616779};\\\", \\\"{x:1418,y:622,t:1528139616796};\\\", \\\"{x:1422,y:617,t:1528139616813};\\\", \\\"{x:1424,y:614,t:1528139616829};\\\", \\\"{x:1429,y:608,t:1528139616845};\\\", \\\"{x:1432,y:605,t:1528139616862};\\\", \\\"{x:1439,y:599,t:1528139616879};\\\", \\\"{x:1451,y:590,t:1528139616895};\\\", \\\"{x:1466,y:578,t:1528139616912};\\\", \\\"{x:1482,y:567,t:1528139616929};\\\", \\\"{x:1505,y:551,t:1528139616945};\\\", \\\"{x:1532,y:536,t:1528139616962};\\\", \\\"{x:1564,y:517,t:1528139616980};\\\", \\\"{x:1588,y:500,t:1528139616996};\\\", \\\"{x:1609,y:484,t:1528139617013};\\\", \\\"{x:1632,y:461,t:1528139617029};\\\", \\\"{x:1647,y:449,t:1528139617045};\\\", \\\"{x:1658,y:435,t:1528139617063};\\\", \\\"{x:1673,y:421,t:1528139617080};\\\", \\\"{x:1686,y:409,t:1528139617095};\\\", \\\"{x:1700,y:397,t:1528139617113};\\\", \\\"{x:1716,y:384,t:1528139617130};\\\", \\\"{x:1730,y:373,t:1528139617145};\\\", \\\"{x:1731,y:369,t:1528139617163};\\\", \\\"{x:1737,y:366,t:1528139617180};\\\", \\\"{x:1737,y:367,t:1528139617670};\\\", \\\"{x:1733,y:373,t:1528139617680};\\\", \\\"{x:1708,y:387,t:1528139617697};\\\", \\\"{x:1683,y:402,t:1528139617713};\\\", \\\"{x:1661,y:418,t:1528139617730};\\\", \\\"{x:1636,y:435,t:1528139617747};\\\", \\\"{x:1605,y:457,t:1528139617763};\\\", \\\"{x:1557,y:483,t:1528139617780};\\\", \\\"{x:1492,y:517,t:1528139617797};\\\", \\\"{x:1414,y:553,t:1528139617813};\\\", \\\"{x:1286,y:609,t:1528139617829};\\\", \\\"{x:1210,y:649,t:1528139617846};\\\", \\\"{x:1154,y:685,t:1528139617864};\\\", \\\"{x:1127,y:706,t:1528139617880};\\\", \\\"{x:1114,y:720,t:1528139617896};\\\", \\\"{x:1110,y:729,t:1528139617914};\\\", \\\"{x:1109,y:732,t:1528139617930};\\\", \\\"{x:1109,y:733,t:1528139617947};\\\", \\\"{x:1109,y:734,t:1528139617964};\\\", \\\"{x:1111,y:736,t:1528139617980};\\\", \\\"{x:1118,y:740,t:1528139617997};\\\", \\\"{x:1133,y:744,t:1528139618013};\\\", \\\"{x:1143,y:745,t:1528139618030};\\\", \\\"{x:1158,y:745,t:1528139618046};\\\", \\\"{x:1184,y:745,t:1528139618064};\\\", \\\"{x:1208,y:745,t:1528139618080};\\\", \\\"{x:1236,y:745,t:1528139618097};\\\", \\\"{x:1262,y:745,t:1528139618114};\\\", \\\"{x:1277,y:745,t:1528139618130};\\\", \\\"{x:1291,y:741,t:1528139618147};\\\", \\\"{x:1300,y:738,t:1528139618164};\\\", \\\"{x:1308,y:733,t:1528139618180};\\\", \\\"{x:1314,y:731,t:1528139618197};\\\", \\\"{x:1319,y:729,t:1528139618214};\\\", \\\"{x:1320,y:728,t:1528139618230};\\\", \\\"{x:1321,y:728,t:1528139618247};\\\", \\\"{x:1322,y:728,t:1528139618374};\\\", \\\"{x:1323,y:729,t:1528139618390};\\\", \\\"{x:1323,y:730,t:1528139618397};\\\", \\\"{x:1323,y:740,t:1528139618414};\\\", \\\"{x:1321,y:753,t:1528139618432};\\\", \\\"{x:1316,y:765,t:1528139618447};\\\", \\\"{x:1309,y:779,t:1528139618465};\\\", \\\"{x:1302,y:796,t:1528139618480};\\\", \\\"{x:1295,y:814,t:1528139618498};\\\", \\\"{x:1288,y:832,t:1528139618514};\\\", \\\"{x:1280,y:850,t:1528139618531};\\\", \\\"{x:1272,y:861,t:1528139618548};\\\", \\\"{x:1266,y:869,t:1528139618564};\\\", \\\"{x:1265,y:870,t:1528139618582};\\\", \\\"{x:1265,y:871,t:1528139618597};\\\", \\\"{x:1264,y:871,t:1528139618646};\\\", \\\"{x:1263,y:871,t:1528139618664};\\\", \\\"{x:1261,y:866,t:1528139618681};\\\", \\\"{x:1258,y:860,t:1528139618698};\\\", \\\"{x:1257,y:856,t:1528139618714};\\\", \\\"{x:1256,y:854,t:1528139618732};\\\", \\\"{x:1254,y:853,t:1528139618748};\\\", \\\"{x:1253,y:853,t:1528139618764};\\\", \\\"{x:1250,y:853,t:1528139618781};\\\", \\\"{x:1244,y:853,t:1528139618798};\\\", \\\"{x:1236,y:853,t:1528139618814};\\\", \\\"{x:1227,y:853,t:1528139618831};\\\", \\\"{x:1214,y:852,t:1528139618848};\\\", \\\"{x:1205,y:850,t:1528139618865};\\\", \\\"{x:1201,y:849,t:1528139618881};\\\", \\\"{x:1198,y:848,t:1528139618898};\\\", \\\"{x:1197,y:848,t:1528139618914};\\\", \\\"{x:1197,y:847,t:1528139618942};\\\", \\\"{x:1197,y:845,t:1528139618966};\\\", \\\"{x:1197,y:843,t:1528139618981};\\\", \\\"{x:1199,y:835,t:1528139618997};\\\", \\\"{x:1202,y:830,t:1528139619014};\\\", \\\"{x:1206,y:825,t:1528139619031};\\\", \\\"{x:1208,y:822,t:1528139619048};\\\", \\\"{x:1208,y:821,t:1528139619065};\\\", \\\"{x:1208,y:820,t:1528139619150};\\\", \\\"{x:1207,y:820,t:1528139619166};\\\", \\\"{x:1206,y:822,t:1528139619182};\\\", \\\"{x:1204,y:824,t:1528139619198};\\\", \\\"{x:1203,y:825,t:1528139619230};\\\", \\\"{x:1203,y:826,t:1528139619253};\\\", \\\"{x:1201,y:827,t:1528139619270};\\\", \\\"{x:1201,y:829,t:1528139619294};\\\", \\\"{x:1200,y:830,t:1528139619302};\\\", \\\"{x:1199,y:830,t:1528139619374};\\\", \\\"{x:1198,y:830,t:1528139619398};\\\", \\\"{x:1197,y:830,t:1528139619415};\\\", \\\"{x:1196,y:829,t:1528139619447};\\\", \\\"{x:1196,y:827,t:1528139619478};\\\", \\\"{x:1196,y:826,t:1528139619494};\\\", \\\"{x:1196,y:825,t:1528139619501};\\\", \\\"{x:1196,y:824,t:1528139619518};\\\", \\\"{x:1196,y:822,t:1528139619550};\\\", \\\"{x:1197,y:820,t:1528139619565};\\\", \\\"{x:1198,y:819,t:1528139619582};\\\", \\\"{x:1198,y:817,t:1528139619598};\\\", \\\"{x:1199,y:817,t:1528139619615};\\\", \\\"{x:1200,y:816,t:1528139619631};\\\", \\\"{x:1201,y:816,t:1528139619648};\\\", \\\"{x:1202,y:816,t:1528139619693};\\\", \\\"{x:1203,y:816,t:1528139619701};\\\", \\\"{x:1204,y:816,t:1528139619715};\\\", \\\"{x:1206,y:816,t:1528139619733};\\\", \\\"{x:1208,y:816,t:1528139619748};\\\", \\\"{x:1208,y:817,t:1528139619773};\\\", \\\"{x:1209,y:817,t:1528139619806};\\\", \\\"{x:1209,y:818,t:1528139619814};\\\", \\\"{x:1210,y:820,t:1528139619832};\\\", \\\"{x:1211,y:820,t:1528139619848};\\\", \\\"{x:1211,y:821,t:1528139619865};\\\", \\\"{x:1212,y:821,t:1528139619882};\\\", \\\"{x:1213,y:822,t:1528139619934};\\\", \\\"{x:1214,y:823,t:1528139619948};\\\", \\\"{x:1214,y:824,t:1528139619990};\\\", \\\"{x:1216,y:827,t:1528139620009};\\\", \\\"{x:1217,y:827,t:1528139620014};\\\", \\\"{x:1218,y:828,t:1528139620031};\\\", \\\"{x:1218,y:829,t:1528139620053};\\\", \\\"{x:1219,y:830,t:1528139620198};\\\", \\\"{x:1219,y:831,t:1528139620685};\\\", \\\"{x:1219,y:832,t:1528139621500};\\\", \\\"{x:1219,y:833,t:1528139621549};\\\", \\\"{x:1219,y:835,t:1528139621581};\\\", \\\"{x:1219,y:837,t:1528139621599};\\\", \\\"{x:1219,y:838,t:1528139621725};\\\", \\\"{x:1219,y:836,t:1528139622165};\\\", \\\"{x:1219,y:835,t:1528139622181};\\\", \\\"{x:1219,y:833,t:1528139622206};\\\", \\\"{x:1219,y:832,t:1528139622253};\\\", \\\"{x:1219,y:830,t:1528139622277};\\\", \\\"{x:1219,y:829,t:1528139622301};\\\", \\\"{x:1219,y:827,t:1528139622317};\\\", \\\"{x:1219,y:826,t:1528139622453};\\\", \\\"{x:1217,y:825,t:1528139622517};\\\", \\\"{x:1215,y:825,t:1528139622533};\\\", \\\"{x:1214,y:825,t:1528139622549};\\\", \\\"{x:1213,y:824,t:1528139622567};\\\", \\\"{x:1214,y:824,t:1528139623077};\\\", \\\"{x:1216,y:824,t:1528139623084};\\\", \\\"{x:1221,y:827,t:1528139623101};\\\", \\\"{x:1232,y:832,t:1528139623117};\\\", \\\"{x:1235,y:834,t:1528139623133};\\\", \\\"{x:1236,y:835,t:1528139623150};\\\", \\\"{x:1237,y:836,t:1528139623168};\\\", \\\"{x:1235,y:836,t:1528139623373};\\\", \\\"{x:1233,y:836,t:1528139623405};\\\", \\\"{x:1230,y:835,t:1528139623418};\\\", \\\"{x:1228,y:834,t:1528139623434};\\\", \\\"{x:1227,y:833,t:1528139623451};\\\", \\\"{x:1226,y:833,t:1528139623485};\\\", \\\"{x:1225,y:832,t:1528139623565};\\\", \\\"{x:1224,y:832,t:1528139623644};\\\", \\\"{x:1222,y:832,t:1528139623661};\\\", \\\"{x:1221,y:832,t:1528139623669};\\\", \\\"{x:1218,y:832,t:1528139623686};\\\", \\\"{x:1218,y:831,t:1528139623701};\\\", \\\"{x:1217,y:831,t:1528139623765};\\\", \\\"{x:1216,y:831,t:1528139623781};\\\", \\\"{x:1215,y:831,t:1528139623813};\\\", \\\"{x:1210,y:831,t:1528139626469};\\\", \\\"{x:1133,y:831,t:1528139626503};\\\", \\\"{x:1072,y:831,t:1528139626520};\\\", \\\"{x:1010,y:831,t:1528139626537};\\\", \\\"{x:942,y:825,t:1528139626552};\\\", \\\"{x:890,y:816,t:1528139626570};\\\", \\\"{x:845,y:808,t:1528139626587};\\\", \\\"{x:805,y:801,t:1528139626603};\\\", \\\"{x:767,y:792,t:1528139626620};\\\", \\\"{x:707,y:779,t:1528139626636};\\\", \\\"{x:654,y:773,t:1528139626653};\\\", \\\"{x:585,y:762,t:1528139626670};\\\", \\\"{x:526,y:756,t:1528139626687};\\\", \\\"{x:463,y:749,t:1528139626703};\\\", \\\"{x:416,y:739,t:1528139626720};\\\", \\\"{x:364,y:718,t:1528139626737};\\\", \\\"{x:339,y:712,t:1528139626752};\\\", \\\"{x:329,y:706,t:1528139626769};\\\", \\\"{x:327,y:702,t:1528139626787};\\\", \\\"{x:327,y:700,t:1528139626803};\\\", \\\"{x:327,y:698,t:1528139626820};\\\", \\\"{x:327,y:692,t:1528139626837};\\\", \\\"{x:328,y:684,t:1528139626854};\\\", \\\"{x:331,y:679,t:1528139626869};\\\", \\\"{x:334,y:673,t:1528139626887};\\\", \\\"{x:340,y:666,t:1528139626904};\\\", \\\"{x:345,y:661,t:1528139626919};\\\", \\\"{x:353,y:654,t:1528139626937};\\\", \\\"{x:359,y:650,t:1528139626954};\\\", \\\"{x:368,y:647,t:1528139626970};\\\", \\\"{x:378,y:645,t:1528139626987};\\\", \\\"{x:385,y:645,t:1528139627003};\\\", \\\"{x:388,y:645,t:1528139627020};\\\", \\\"{x:389,y:645,t:1528139627045};\\\", \\\"{x:389,y:644,t:1528139627133};\\\", \\\"{x:389,y:639,t:1528139627677};\\\", \\\"{x:389,y:632,t:1528139627688};\\\", \\\"{x:387,y:617,t:1528139627705};\\\", \\\"{x:386,y:607,t:1528139627722};\\\", \\\"{x:386,y:603,t:1528139627738};\\\", \\\"{x:386,y:598,t:1528139627753};\\\", \\\"{x:385,y:597,t:1528139627771};\\\", \\\"{x:385,y:596,t:1528139627788};\\\", \\\"{x:385,y:595,t:1528139627804};\\\", \\\"{x:387,y:601,t:1528139628181};\\\", \\\"{x:389,y:609,t:1528139628189};\\\", \\\"{x:395,y:619,t:1528139628205};\\\", \\\"{x:418,y:651,t:1528139628221};\\\", \\\"{x:437,y:672,t:1528139628238};\\\", \\\"{x:454,y:685,t:1528139628255};\\\", \\\"{x:460,y:692,t:1528139628271};\\\", \\\"{x:465,y:698,t:1528139628287};\\\", \\\"{x:470,y:704,t:1528139628305};\\\", \\\"{x:472,y:706,t:1528139628321};\\\", \\\"{x:475,y:709,t:1528139628338};\\\", \\\"{x:476,y:711,t:1528139628355};\\\", \\\"{x:478,y:713,t:1528139628371};\\\", \\\"{x:478,y:714,t:1528139628388};\\\", \\\"{x:480,y:720,t:1528139628405};\\\", \\\"{x:482,y:722,t:1528139628421};\\\", \\\"{x:482,y:728,t:1528139628437};\\\", \\\"{x:483,y:731,t:1528139628454};\\\", \\\"{x:485,y:736,t:1528139628472};\\\", \\\"{x:485,y:739,t:1528139628488};\\\", \\\"{x:486,y:742,t:1528139628504};\\\", \\\"{x:487,y:747,t:1528139628521};\\\", \\\"{x:489,y:751,t:1528139628538};\\\", \\\"{x:489,y:754,t:1528139628554};\\\", \\\"{x:489,y:755,t:1528139628570};\\\", \\\"{x:490,y:756,t:1528139628884};\\\", \\\"{x:493,y:757,t:1528139628893};\\\", \\\"{x:498,y:757,t:1528139628905};\\\", \\\"{x:518,y:759,t:1528139628922};\\\", \\\"{x:541,y:764,t:1528139628937};\\\", \\\"{x:573,y:771,t:1528139628954};\\\", \\\"{x:613,y:785,t:1528139628972};\\\", \\\"{x:678,y:806,t:1528139628988};\\\", \\\"{x:759,y:829,t:1528139629004};\\\", \\\"{x:798,y:841,t:1528139629021};\\\", \\\"{x:819,y:847,t:1528139629039};\\\", \\\"{x:830,y:850,t:1528139629055};\\\", \\\"{x:833,y:852,t:1528139629072};\\\", \\\"{x:834,y:852,t:1528139629089};\\\", \\\"{x:835,y:853,t:1528139629105};\\\", \\\"{x:836,y:854,t:1528139629188};\\\", \\\"{x:836,y:855,t:1528139629284};\\\", \\\"{x:838,y:855,t:1528139629301};\\\", \\\"{x:839,y:855,t:1528139629308};\\\", \\\"{x:843,y:855,t:1528139629322};\\\", \\\"{x:848,y:855,t:1528139629339};\\\", \\\"{x:857,y:855,t:1528139629355};\\\", \\\"{x:862,y:855,t:1528139629371};\\\", \\\"{x:868,y:855,t:1528139629389};\\\", \\\"{x:869,y:855,t:1528139629404};\\\", \\\"{x:870,y:855,t:1528139629422};\\\", \\\"{x:871,y:856,t:1528139629469};\\\", \\\"{x:873,y:857,t:1528139629484};\\\", \\\"{x:875,y:858,t:1528139629493};\\\", \\\"{x:878,y:860,t:1528139629506};\\\", \\\"{x:882,y:863,t:1528139629522};\\\", \\\"{x:885,y:866,t:1528139629538};\\\", \\\"{x:888,y:868,t:1528139629556};\\\", \\\"{x:889,y:868,t:1528139629572};\\\", \\\"{x:890,y:869,t:1528139629589};\\\", \\\"{x:892,y:871,t:1528139629606};\\\", \\\"{x:895,y:875,t:1528139629622};\\\", \\\"{x:898,y:876,t:1528139629639};\\\", \\\"{x:900,y:878,t:1528139629656};\\\", \\\"{x:900,y:879,t:1528139629672};\\\", \\\"{x:902,y:882,t:1528139629689};\\\", \\\"{x:903,y:883,t:1528139629709};\\\", \\\"{x:904,y:883,t:1528139629772};\\\", \\\"{x:905,y:884,t:1528139629796};\\\", \\\"{x:906,y:885,t:1528139629813};\\\" ] }, { \\\"rt\\\": 17028, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 8, \\\"time_elapsed\\\": 390939, \\\"internal_node_id\\\": \\\"0.0-5.0-3.0\\\", \\\"subject\\\": \\\"JYGX2\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"yankee\\\", \\\"condition\\\": \\\"311\\\", \\\"scenario\\\": \\\"acme\\\", \\\"question\\\": \\\"endtime\\\", \\\"q\\\": 4, \\\"clicks\\\": 1, \\\"explicit\\\": 3, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XInside-YFull\\\", \\\"correct\\\": 1, \\\"orth_correct\\\": 0, \\\"answer\\\": [ \\\"H\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"X \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"U \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-1-04 PM-H -C -04 PM\\\", \\\"block\\\": \\\"triangular_scaffolded\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:912,y:895,t:1528139629947};\\\", \\\"{x:913,y:896,t:1528139629965};\\\", \\\"{x:913,y:897,t:1528139629980};\\\", \\\"{x:913,y:898,t:1528139630012};\\\", \\\"{x:913,y:900,t:1528139630189};\\\", \\\"{x:914,y:901,t:1528139630206};\\\", \\\"{x:915,y:902,t:1528139630224};\\\", \\\"{x:916,y:903,t:1528139630269};\\\", \\\"{x:916,y:904,t:1528139630284};\\\", \\\"{x:918,y:906,t:1528139630324};\\\", \\\"{x:919,y:906,t:1528139630413};\\\", \\\"{x:918,y:905,t:1528139630549};\\\", \\\"{x:916,y:905,t:1528139630613};\\\", \\\"{x:915,y:905,t:1528139630718};\\\", \\\"{x:915,y:904,t:1528139630726};\\\", \\\"{x:915,y:903,t:1528139630758};\\\", \\\"{x:913,y:902,t:1528139631382};\\\", \\\"{x:912,y:901,t:1528139631542};\\\", \\\"{x:915,y:899,t:1528139631557};\\\", \\\"{x:923,y:898,t:1528139631574};\\\", \\\"{x:942,y:894,t:1528139631590};\\\", \\\"{x:959,y:893,t:1528139631607};\\\", \\\"{x:983,y:893,t:1528139631624};\\\", \\\"{x:1008,y:892,t:1528139631640};\\\", \\\"{x:1034,y:892,t:1528139631657};\\\", \\\"{x:1056,y:892,t:1528139631674};\\\", \\\"{x:1079,y:891,t:1528139631691};\\\", \\\"{x:1108,y:891,t:1528139631707};\\\", \\\"{x:1138,y:888,t:1528139631724};\\\", \\\"{x:1171,y:886,t:1528139631740};\\\", \\\"{x:1219,y:885,t:1528139631757};\\\", \\\"{x:1247,y:885,t:1528139631774};\\\", \\\"{x:1270,y:885,t:1528139631790};\\\", \\\"{x:1291,y:885,t:1528139631807};\\\", \\\"{x:1303,y:885,t:1528139631824};\\\", \\\"{x:1312,y:885,t:1528139631841};\\\", \\\"{x:1317,y:887,t:1528139631857};\\\", \\\"{x:1320,y:889,t:1528139631874};\\\", \\\"{x:1322,y:891,t:1528139631890};\\\", \\\"{x:1324,y:892,t:1528139631908};\\\", \\\"{x:1327,y:894,t:1528139631925};\\\", \\\"{x:1330,y:900,t:1528139631941};\\\", \\\"{x:1333,y:904,t:1528139631957};\\\", \\\"{x:1333,y:907,t:1528139631974};\\\", \\\"{x:1336,y:908,t:1528139631991};\\\", \\\"{x:1340,y:913,t:1528139632006};\\\", \\\"{x:1341,y:915,t:1528139632024};\\\", \\\"{x:1343,y:916,t:1528139632085};\\\", \\\"{x:1350,y:916,t:1528139632092};\\\", \\\"{x:1353,y:916,t:1528139632107};\\\", \\\"{x:1360,y:916,t:1528139632124};\\\", \\\"{x:1367,y:916,t:1528139632141};\\\", \\\"{x:1370,y:918,t:1528139632157};\\\", \\\"{x:1371,y:919,t:1528139632174};\\\", \\\"{x:1372,y:920,t:1528139632197};\\\", \\\"{x:1375,y:920,t:1528139632207};\\\", \\\"{x:1391,y:921,t:1528139632224};\\\", \\\"{x:1418,y:921,t:1528139632241};\\\", \\\"{x:1452,y:923,t:1528139632258};\\\", \\\"{x:1484,y:923,t:1528139632274};\\\", \\\"{x:1506,y:925,t:1528139632291};\\\", \\\"{x:1526,y:924,t:1528139632307};\\\", \\\"{x:1545,y:924,t:1528139632324};\\\", \\\"{x:1558,y:924,t:1528139632341};\\\", \\\"{x:1560,y:924,t:1528139632358};\\\", \\\"{x:1561,y:924,t:1528139632374};\\\", \\\"{x:1563,y:924,t:1528139632405};\\\", \\\"{x:1565,y:925,t:1528139632421};\\\", \\\"{x:1568,y:927,t:1528139632429};\\\", \\\"{x:1569,y:928,t:1528139632442};\\\", \\\"{x:1571,y:930,t:1528139632459};\\\", \\\"{x:1572,y:934,t:1528139632475};\\\", \\\"{x:1576,y:944,t:1528139632492};\\\", \\\"{x:1580,y:952,t:1528139632508};\\\", \\\"{x:1582,y:959,t:1528139632524};\\\", \\\"{x:1593,y:970,t:1528139632541};\\\", \\\"{x:1604,y:974,t:1528139632559};\\\", \\\"{x:1611,y:976,t:1528139632575};\\\", \\\"{x:1619,y:977,t:1528139632591};\\\", \\\"{x:1626,y:977,t:1528139632609};\\\", \\\"{x:1632,y:977,t:1528139632625};\\\", \\\"{x:1637,y:977,t:1528139632641};\\\", \\\"{x:1639,y:977,t:1528139632658};\\\", \\\"{x:1640,y:977,t:1528139632684};\\\", \\\"{x:1640,y:976,t:1528139632700};\\\", \\\"{x:1641,y:975,t:1528139632708};\\\", \\\"{x:1642,y:972,t:1528139632724};\\\", \\\"{x:1642,y:971,t:1528139632748};\\\", \\\"{x:1642,y:970,t:1528139632758};\\\", \\\"{x:1642,y:969,t:1528139632780};\\\", \\\"{x:1642,y:968,t:1528139632812};\\\", \\\"{x:1642,y:966,t:1528139632829};\\\", \\\"{x:1641,y:965,t:1528139632845};\\\", \\\"{x:1638,y:964,t:1528139632858};\\\", \\\"{x:1632,y:962,t:1528139632875};\\\", \\\"{x:1622,y:961,t:1528139632891};\\\", \\\"{x:1610,y:961,t:1528139632909};\\\", \\\"{x:1603,y:962,t:1528139632926};\\\", \\\"{x:1602,y:962,t:1528139632941};\\\", \\\"{x:1601,y:962,t:1528139633086};\\\", \\\"{x:1600,y:962,t:1528139633093};\\\", \\\"{x:1599,y:962,t:1528139633117};\\\", \\\"{x:1597,y:961,t:1528139633134};\\\", \\\"{x:1596,y:961,t:1528139633141};\\\", \\\"{x:1593,y:959,t:1528139633158};\\\", \\\"{x:1592,y:958,t:1528139633175};\\\", \\\"{x:1589,y:954,t:1528139633191};\\\", \\\"{x:1588,y:952,t:1528139633208};\\\", \\\"{x:1586,y:949,t:1528139633225};\\\", \\\"{x:1584,y:944,t:1528139633241};\\\", \\\"{x:1581,y:937,t:1528139633258};\\\", \\\"{x:1580,y:931,t:1528139633275};\\\", \\\"{x:1578,y:922,t:1528139633291};\\\", \\\"{x:1576,y:916,t:1528139633308};\\\", \\\"{x:1575,y:911,t:1528139633326};\\\", \\\"{x:1575,y:910,t:1528139633342};\\\", \\\"{x:1574,y:908,t:1528139633358};\\\", \\\"{x:1573,y:905,t:1528139633398};\\\", \\\"{x:1573,y:903,t:1528139633409};\\\", \\\"{x:1571,y:898,t:1528139633425};\\\", \\\"{x:1570,y:893,t:1528139633442};\\\", \\\"{x:1568,y:882,t:1528139633459};\\\", \\\"{x:1564,y:871,t:1528139633476};\\\", \\\"{x:1559,y:862,t:1528139633493};\\\", \\\"{x:1555,y:854,t:1528139633509};\\\", \\\"{x:1549,y:844,t:1528139633526};\\\", \\\"{x:1547,y:842,t:1528139633543};\\\", \\\"{x:1541,y:835,t:1528139633558};\\\", \\\"{x:1537,y:831,t:1528139633575};\\\", \\\"{x:1533,y:826,t:1528139633592};\\\", \\\"{x:1529,y:820,t:1528139633608};\\\", \\\"{x:1525,y:815,t:1528139633625};\\\", \\\"{x:1522,y:810,t:1528139633642};\\\", \\\"{x:1519,y:804,t:1528139633658};\\\", \\\"{x:1516,y:800,t:1528139633675};\\\", \\\"{x:1515,y:796,t:1528139633693};\\\", \\\"{x:1512,y:791,t:1528139633708};\\\", \\\"{x:1508,y:780,t:1528139633725};\\\", \\\"{x:1502,y:770,t:1528139633742};\\\", \\\"{x:1496,y:760,t:1528139633759};\\\", \\\"{x:1491,y:751,t:1528139633776};\\\", \\\"{x:1484,y:740,t:1528139633792};\\\", \\\"{x:1478,y:730,t:1528139633809};\\\", \\\"{x:1471,y:717,t:1528139633826};\\\", \\\"{x:1465,y:706,t:1528139633843};\\\", \\\"{x:1458,y:696,t:1528139633860};\\\", \\\"{x:1451,y:684,t:1528139633876};\\\", \\\"{x:1445,y:675,t:1528139633893};\\\", \\\"{x:1439,y:664,t:1528139633909};\\\", \\\"{x:1435,y:655,t:1528139633926};\\\", \\\"{x:1431,y:647,t:1528139633943};\\\", \\\"{x:1429,y:638,t:1528139633960};\\\", \\\"{x:1426,y:631,t:1528139633976};\\\", \\\"{x:1422,y:623,t:1528139633992};\\\", \\\"{x:1420,y:615,t:1528139634010};\\\", \\\"{x:1417,y:607,t:1528139634025};\\\", \\\"{x:1413,y:599,t:1528139634043};\\\", \\\"{x:1410,y:592,t:1528139634060};\\\", \\\"{x:1409,y:589,t:1528139634076};\\\", \\\"{x:1407,y:584,t:1528139634093};\\\", \\\"{x:1406,y:578,t:1528139634110};\\\", \\\"{x:1406,y:576,t:1528139634126};\\\", \\\"{x:1406,y:575,t:1528139634143};\\\", \\\"{x:1405,y:574,t:1528139634160};\\\", \\\"{x:1405,y:572,t:1528139634176};\\\", \\\"{x:1405,y:571,t:1528139634205};\\\", \\\"{x:1405,y:570,t:1528139634254};\\\", \\\"{x:1405,y:569,t:1528139634302};\\\", \\\"{x:1405,y:568,t:1528139634358};\\\", \\\"{x:1406,y:566,t:1528139634374};\\\", \\\"{x:1407,y:565,t:1528139634390};\\\", \\\"{x:1407,y:564,t:1528139634397};\\\", \\\"{x:1409,y:563,t:1528139634420};\\\", \\\"{x:1409,y:562,t:1528139634459};\\\", \\\"{x:1411,y:562,t:1528139634493};\\\", \\\"{x:1412,y:561,t:1528139634517};\\\", \\\"{x:1374,y:561,t:1528139638144};\\\", \\\"{x:1340,y:566,t:1528139638160};\\\", \\\"{x:1308,y:571,t:1528139638179};\\\", \\\"{x:1291,y:573,t:1528139638195};\\\", \\\"{x:1277,y:575,t:1528139638212};\\\", \\\"{x:1263,y:578,t:1528139638229};\\\", \\\"{x:1251,y:580,t:1528139638246};\\\", \\\"{x:1229,y:582,t:1528139638262};\\\", \\\"{x:1201,y:587,t:1528139638279};\\\", \\\"{x:1154,y:595,t:1528139638295};\\\", \\\"{x:1108,y:604,t:1528139638313};\\\", \\\"{x:1074,y:615,t:1528139638329};\\\", \\\"{x:1044,y:623,t:1528139638346};\\\", \\\"{x:1022,y:629,t:1528139638362};\\\", \\\"{x:998,y:637,t:1528139638380};\\\", \\\"{x:977,y:640,t:1528139638396};\\\", \\\"{x:957,y:642,t:1528139638412};\\\", \\\"{x:920,y:645,t:1528139638430};\\\", \\\"{x:898,y:646,t:1528139638445};\\\", \\\"{x:871,y:646,t:1528139638462};\\\", \\\"{x:839,y:646,t:1528139638479};\\\", \\\"{x:808,y:646,t:1528139638497};\\\", \\\"{x:782,y:646,t:1528139638512};\\\", \\\"{x:763,y:646,t:1528139638529};\\\", \\\"{x:748,y:644,t:1528139638546};\\\", \\\"{x:733,y:638,t:1528139638562};\\\", \\\"{x:713,y:632,t:1528139638580};\\\", \\\"{x:692,y:626,t:1528139638596};\\\", \\\"{x:674,y:619,t:1528139638612};\\\", \\\"{x:652,y:613,t:1528139638630};\\\", \\\"{x:638,y:609,t:1528139638647};\\\", \\\"{x:628,y:605,t:1528139638663};\\\", \\\"{x:625,y:604,t:1528139638680};\\\", \\\"{x:623,y:604,t:1528139638697};\\\", \\\"{x:621,y:602,t:1528139638713};\\\", \\\"{x:614,y:602,t:1528139638729};\\\", \\\"{x:606,y:601,t:1528139638747};\\\", \\\"{x:605,y:601,t:1528139638763};\\\", \\\"{x:603,y:601,t:1528139638869};\\\", \\\"{x:602,y:600,t:1528139638885};\\\", \\\"{x:606,y:600,t:1528139640333};\\\", \\\"{x:608,y:602,t:1528139640348};\\\", \\\"{x:614,y:604,t:1528139640365};\\\", \\\"{x:617,y:605,t:1528139640381};\\\", \\\"{x:625,y:608,t:1528139640399};\\\", \\\"{x:636,y:612,t:1528139640415};\\\", \\\"{x:652,y:621,t:1528139640431};\\\", \\\"{x:682,y:629,t:1528139640447};\\\", \\\"{x:740,y:644,t:1528139640465};\\\", \\\"{x:827,y:671,t:1528139640480};\\\", \\\"{x:927,y:705,t:1528139640497};\\\", \\\"{x:1031,y:744,t:1528139640515};\\\", \\\"{x:1127,y:780,t:1528139640532};\\\", \\\"{x:1217,y:815,t:1528139640548};\\\", \\\"{x:1333,y:858,t:1528139640565};\\\", \\\"{x:1386,y:874,t:1528139640581};\\\", \\\"{x:1430,y:884,t:1528139640598};\\\", \\\"{x:1452,y:890,t:1528139640615};\\\", \\\"{x:1476,y:892,t:1528139640632};\\\", \\\"{x:1507,y:892,t:1528139640647};\\\", \\\"{x:1538,y:892,t:1528139640665};\\\", \\\"{x:1570,y:892,t:1528139640682};\\\", \\\"{x:1597,y:892,t:1528139640698};\\\", \\\"{x:1615,y:892,t:1528139640714};\\\", \\\"{x:1620,y:892,t:1528139640732};\\\", \\\"{x:1625,y:892,t:1528139640748};\\\", \\\"{x:1631,y:894,t:1528139640765};\\\", \\\"{x:1635,y:894,t:1528139640781};\\\", \\\"{x:1641,y:896,t:1528139640797};\\\", \\\"{x:1651,y:898,t:1528139640815};\\\", \\\"{x:1661,y:902,t:1528139640832};\\\", \\\"{x:1666,y:903,t:1528139640848};\\\", \\\"{x:1670,y:906,t:1528139640865};\\\", \\\"{x:1671,y:908,t:1528139640882};\\\", \\\"{x:1672,y:909,t:1528139640898};\\\", \\\"{x:1673,y:911,t:1528139640914};\\\", \\\"{x:1673,y:914,t:1528139640932};\\\", \\\"{x:1673,y:918,t:1528139640949};\\\", \\\"{x:1673,y:919,t:1528139640965};\\\", \\\"{x:1669,y:924,t:1528139640981};\\\", \\\"{x:1664,y:927,t:1528139640999};\\\", \\\"{x:1659,y:931,t:1528139641015};\\\", \\\"{x:1655,y:933,t:1528139641032};\\\", \\\"{x:1650,y:935,t:1528139641049};\\\", \\\"{x:1646,y:935,t:1528139641064};\\\", \\\"{x:1644,y:937,t:1528139641082};\\\", \\\"{x:1644,y:938,t:1528139641099};\\\", \\\"{x:1641,y:939,t:1528139641115};\\\", \\\"{x:1639,y:940,t:1528139641132};\\\", \\\"{x:1636,y:942,t:1528139641150};\\\", \\\"{x:1633,y:944,t:1528139641165};\\\", \\\"{x:1631,y:946,t:1528139641182};\\\", \\\"{x:1630,y:948,t:1528139641199};\\\", \\\"{x:1628,y:950,t:1528139641215};\\\", \\\"{x:1628,y:951,t:1528139641232};\\\", \\\"{x:1627,y:953,t:1528139641249};\\\", \\\"{x:1627,y:954,t:1528139641266};\\\", \\\"{x:1627,y:956,t:1528139641285};\\\", \\\"{x:1626,y:957,t:1528139641316};\\\", \\\"{x:1625,y:958,t:1528139641437};\\\", \\\"{x:1625,y:959,t:1528139641449};\\\", \\\"{x:1622,y:961,t:1528139641466};\\\", \\\"{x:1618,y:962,t:1528139641482};\\\", \\\"{x:1616,y:963,t:1528139641499};\\\", \\\"{x:1614,y:965,t:1528139641516};\\\", \\\"{x:1612,y:965,t:1528139641532};\\\", \\\"{x:1612,y:966,t:1528139641549};\\\", \\\"{x:1611,y:966,t:1528139641598};\\\", \\\"{x:1610,y:968,t:1528139641613};\\\", \\\"{x:1609,y:968,t:1528139641629};\\\", \\\"{x:1608,y:970,t:1528139641638};\\\", \\\"{x:1607,y:970,t:1528139641648};\\\", \\\"{x:1606,y:970,t:1528139642054};\\\", \\\"{x:1605,y:970,t:1528139642510};\\\", \\\"{x:1605,y:969,t:1528139643973};\\\", \\\"{x:1605,y:968,t:1528139643985};\\\", \\\"{x:1609,y:964,t:1528139644002};\\\", \\\"{x:1612,y:961,t:1528139644019};\\\", \\\"{x:1613,y:960,t:1528139644036};\\\", \\\"{x:1614,y:959,t:1528139644052};\\\", \\\"{x:1615,y:957,t:1528139644070};\\\", \\\"{x:1615,y:954,t:1528139644422};\\\", \\\"{x:1609,y:950,t:1528139644435};\\\", \\\"{x:1593,y:939,t:1528139644453};\\\", \\\"{x:1580,y:931,t:1528139644468};\\\", \\\"{x:1568,y:921,t:1528139644485};\\\", \\\"{x:1567,y:920,t:1528139644501};\\\", \\\"{x:1567,y:918,t:1528139644518};\\\", \\\"{x:1567,y:917,t:1528139644535};\\\", \\\"{x:1566,y:916,t:1528139644566};\\\", \\\"{x:1566,y:915,t:1528139644597};\\\", \\\"{x:1566,y:914,t:1528139644661};\\\", \\\"{x:1567,y:913,t:1528139644685};\\\", \\\"{x:1568,y:913,t:1528139644709};\\\", \\\"{x:1570,y:913,t:1528139644719};\\\", \\\"{x:1574,y:915,t:1528139644736};\\\", \\\"{x:1581,y:917,t:1528139644753};\\\", \\\"{x:1594,y:924,t:1528139644769};\\\", \\\"{x:1606,y:931,t:1528139644785};\\\", \\\"{x:1617,y:937,t:1528139644802};\\\", \\\"{x:1624,y:945,t:1528139644818};\\\", \\\"{x:1628,y:949,t:1528139644834};\\\", \\\"{x:1632,y:957,t:1528139644851};\\\", \\\"{x:1635,y:964,t:1528139644869};\\\", \\\"{x:1636,y:967,t:1528139644884};\\\", \\\"{x:1637,y:970,t:1528139644901};\\\", \\\"{x:1638,y:971,t:1528139644919};\\\", \\\"{x:1638,y:972,t:1528139645069};\\\", \\\"{x:1637,y:972,t:1528139645094};\\\", \\\"{x:1637,y:971,t:1528139645109};\\\", \\\"{x:1636,y:969,t:1528139645119};\\\", \\\"{x:1635,y:967,t:1528139645136};\\\", \\\"{x:1635,y:966,t:1528139645152};\\\", \\\"{x:1635,y:965,t:1528139645169};\\\", \\\"{x:1635,y:964,t:1528139645206};\\\", \\\"{x:1635,y:963,t:1528139645230};\\\", \\\"{x:1635,y:962,t:1528139645237};\\\", \\\"{x:1635,y:961,t:1528139645262};\\\", \\\"{x:1635,y:960,t:1528139645269};\\\", \\\"{x:1635,y:959,t:1528139645286};\\\", \\\"{x:1635,y:958,t:1528139645309};\\\", \\\"{x:1636,y:956,t:1528139645349};\\\", \\\"{x:1636,y:954,t:1528139645950};\\\", \\\"{x:1634,y:946,t:1528139645957};\\\", \\\"{x:1625,y:940,t:1528139645970};\\\", \\\"{x:1604,y:923,t:1528139645985};\\\", \\\"{x:1573,y:899,t:1528139646003};\\\", \\\"{x:1541,y:876,t:1528139646019};\\\", \\\"{x:1520,y:861,t:1528139646036};\\\", \\\"{x:1492,y:840,t:1528139646052};\\\", \\\"{x:1472,y:826,t:1528139646070};\\\", \\\"{x:1453,y:813,t:1528139646085};\\\", \\\"{x:1430,y:803,t:1528139646103};\\\", \\\"{x:1410,y:796,t:1528139646119};\\\", \\\"{x:1395,y:792,t:1528139646135};\\\", \\\"{x:1373,y:790,t:1528139646153};\\\", \\\"{x:1352,y:786,t:1528139646170};\\\", \\\"{x:1333,y:786,t:1528139646186};\\\", \\\"{x:1308,y:786,t:1528139646203};\\\", \\\"{x:1287,y:787,t:1528139646220};\\\", \\\"{x:1260,y:795,t:1528139646236};\\\", \\\"{x:1190,y:811,t:1528139646252};\\\", \\\"{x:1125,y:823,t:1528139646270};\\\", \\\"{x:1045,y:834,t:1528139646287};\\\", \\\"{x:972,y:844,t:1528139646303};\\\", \\\"{x:894,y:855,t:1528139646320};\\\", \\\"{x:834,y:862,t:1528139646337};\\\", \\\"{x:797,y:862,t:1528139646353};\\\", \\\"{x:771,y:865,t:1528139646370};\\\", \\\"{x:738,y:869,t:1528139646387};\\\", \\\"{x:714,y:872,t:1528139646403};\\\", \\\"{x:693,y:875,t:1528139646420};\\\", \\\"{x:669,y:878,t:1528139646437};\\\", \\\"{x:660,y:878,t:1528139646453};\\\", \\\"{x:647,y:879,t:1528139646470};\\\", \\\"{x:641,y:879,t:1528139646487};\\\", \\\"{x:635,y:879,t:1528139646503};\\\", \\\"{x:634,y:879,t:1528139646520};\\\", \\\"{x:633,y:878,t:1528139646538};\\\", \\\"{x:629,y:873,t:1528139646553};\\\", \\\"{x:621,y:863,t:1528139646570};\\\", \\\"{x:605,y:844,t:1528139646587};\\\", \\\"{x:587,y:825,t:1528139646603};\\\", \\\"{x:562,y:805,t:1528139646620};\\\", \\\"{x:532,y:784,t:1528139646638};\\\", \\\"{x:519,y:776,t:1528139646653};\\\", \\\"{x:511,y:772,t:1528139646670};\\\", \\\"{x:509,y:770,t:1528139646688};\\\", \\\"{x:507,y:769,t:1528139646704};\\\", \\\"{x:507,y:768,t:1528139646719};\\\", \\\"{x:508,y:771,t:1528139647229};\\\", \\\"{x:521,y:790,t:1528139647237};\\\", \\\"{x:545,y:827,t:1528139647252};\\\", \\\"{x:573,y:858,t:1528139647269};\\\", \\\"{x:609,y:897,t:1528139647286};\\\", \\\"{x:638,y:924,t:1528139647303};\\\", \\\"{x:656,y:937,t:1528139647319};\\\", \\\"{x:663,y:944,t:1528139647337};\\\", \\\"{x:666,y:948,t:1528139647352};\\\", \\\"{x:667,y:948,t:1528139647370};\\\", \\\"{x:668,y:949,t:1528139647845};\\\", \\\"{x:669,y:949,t:1528139647854};\\\", \\\"{x:670,y:950,t:1528139647877};\\\" ] }, { \\\"rt\\\": 16850, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 9, \\\"time_elapsed\\\": 409003, \\\"internal_node_id\\\": \\\"0.0-5.0-4.0\\\", \\\"subject\\\": \\\"JYGX2\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"yankee\\\", \\\"condition\\\": \\\"311\\\", \\\"scenario\\\": \\\"acme\\\", \\\"question\\\": \\\"midpoint\\\", \\\"q\\\": 5, \\\"clicks\\\": 1, \\\"explicit\\\": 3, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XInside-YFull\\\", \\\"correct\\\": 1, \\\"orth_correct\\\": 0, \\\"answer\\\": [ \\\"O\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"X \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"U \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-I -I -O -O \\\", \\\"block\\\": \\\"triangular_scaffolded\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:688,y:946,t:1528139652614};\\\", \\\"{x:706,y:937,t:1528139652624};\\\", \\\"{x:745,y:920,t:1528139652640};\\\", \\\"{x:792,y:906,t:1528139652657};\\\", \\\"{x:833,y:893,t:1528139652674};\\\", \\\"{x:853,y:888,t:1528139652691};\\\", \\\"{x:871,y:881,t:1528139652707};\\\", \\\"{x:878,y:876,t:1528139652725};\\\", \\\"{x:883,y:876,t:1528139652740};\\\", \\\"{x:891,y:870,t:1528139652757};\\\", \\\"{x:900,y:868,t:1528139652774};\\\", \\\"{x:910,y:862,t:1528139652790};\\\", \\\"{x:918,y:859,t:1528139652808};\\\", \\\"{x:928,y:855,t:1528139652825};\\\", \\\"{x:940,y:851,t:1528139652840};\\\", \\\"{x:945,y:849,t:1528139652857};\\\", \\\"{x:948,y:847,t:1528139652874};\\\", \\\"{x:952,y:847,t:1528139652891};\\\", \\\"{x:953,y:847,t:1528139652907};\\\", \\\"{x:955,y:847,t:1528139653405};\\\", \\\"{x:956,y:847,t:1528139653413};\\\", \\\"{x:957,y:847,t:1528139653429};\\\", \\\"{x:958,y:847,t:1528139653445};\\\", \\\"{x:960,y:846,t:1528139653494};\\\", \\\"{x:968,y:841,t:1528139653509};\\\", \\\"{x:986,y:831,t:1528139653525};\\\", \\\"{x:1022,y:807,t:1528139653541};\\\", \\\"{x:1058,y:784,t:1528139653558};\\\", \\\"{x:1090,y:757,t:1528139653575};\\\", \\\"{x:1124,y:725,t:1528139653592};\\\", \\\"{x:1151,y:694,t:1528139653609};\\\", \\\"{x:1170,y:670,t:1528139653625};\\\", \\\"{x:1191,y:645,t:1528139653641};\\\", \\\"{x:1205,y:630,t:1528139653659};\\\", \\\"{x:1214,y:618,t:1528139653675};\\\", \\\"{x:1225,y:605,t:1528139653691};\\\", \\\"{x:1235,y:592,t:1528139653708};\\\", \\\"{x:1246,y:580,t:1528139653724};\\\", \\\"{x:1258,y:561,t:1528139653741};\\\", \\\"{x:1268,y:550,t:1528139653758};\\\", \\\"{x:1279,y:536,t:1528139653774};\\\", \\\"{x:1288,y:526,t:1528139653790};\\\", \\\"{x:1297,y:515,t:1528139653808};\\\", \\\"{x:1303,y:507,t:1528139653825};\\\", \\\"{x:1309,y:501,t:1528139653841};\\\", \\\"{x:1315,y:492,t:1528139653862};\\\", \\\"{x:1319,y:487,t:1528139653876};\\\", \\\"{x:1323,y:480,t:1528139653890};\\\", \\\"{x:1324,y:479,t:1528139653908};\\\", \\\"{x:1324,y:480,t:1528139654109};\\\", \\\"{x:1322,y:483,t:1528139654125};\\\", \\\"{x:1319,y:489,t:1528139654142};\\\", \\\"{x:1318,y:492,t:1528139654162};\\\", \\\"{x:1317,y:492,t:1528139654175};\\\", \\\"{x:1317,y:493,t:1528139654192};\\\", \\\"{x:1317,y:495,t:1528139654324};\\\", \\\"{x:1316,y:497,t:1528139654342};\\\", \\\"{x:1316,y:498,t:1528139654358};\\\", \\\"{x:1315,y:498,t:1528139654375};\\\", \\\"{x:1315,y:500,t:1528139655134};\\\", \\\"{x:1315,y:504,t:1528139660785};\\\", \\\"{x:1314,y:538,t:1528139660809};\\\", \\\"{x:1308,y:576,t:1528139660831};\\\", \\\"{x:1303,y:595,t:1528139660847};\\\", \\\"{x:1303,y:598,t:1528139660864};\\\", \\\"{x:1303,y:600,t:1528139660880};\\\", \\\"{x:1303,y:601,t:1528139660932};\\\", \\\"{x:1303,y:602,t:1528139660947};\\\", \\\"{x:1304,y:606,t:1528139660965};\\\", \\\"{x:1305,y:608,t:1528139660980};\\\", \\\"{x:1307,y:610,t:1528139660997};\\\", \\\"{x:1307,y:612,t:1528139661015};\\\", \\\"{x:1307,y:613,t:1528139661030};\\\", \\\"{x:1307,y:614,t:1528139661053};\\\", \\\"{x:1308,y:615,t:1528139661070};\\\", \\\"{x:1308,y:617,t:1528139661102};\\\", \\\"{x:1311,y:618,t:1528139661117};\\\", \\\"{x:1311,y:620,t:1528139661130};\\\", \\\"{x:1314,y:622,t:1528139661148};\\\", \\\"{x:1315,y:624,t:1528139661165};\\\", \\\"{x:1315,y:626,t:1528139661185};\\\", \\\"{x:1315,y:627,t:1528139661197};\\\", \\\"{x:1315,y:628,t:1528139661349};\\\", \\\"{x:1315,y:630,t:1528139661364};\\\", \\\"{x:1315,y:631,t:1528139661396};\\\", \\\"{x:1308,y:631,t:1528139662592};\\\", \\\"{x:1301,y:633,t:1528139662599};\\\", \\\"{x:1283,y:636,t:1528139662615};\\\", \\\"{x:1273,y:636,t:1528139662631};\\\", \\\"{x:1266,y:636,t:1528139662648};\\\", \\\"{x:1262,y:638,t:1528139662665};\\\", \\\"{x:1261,y:638,t:1528139662682};\\\", \\\"{x:1256,y:638,t:1528139662699};\\\", \\\"{x:1244,y:640,t:1528139662716};\\\", \\\"{x:1183,y:648,t:1528139662732};\\\", \\\"{x:997,y:669,t:1528139662749};\\\", \\\"{x:845,y:688,t:1528139662766};\\\", \\\"{x:694,y:699,t:1528139662784};\\\", \\\"{x:555,y:703,t:1528139662798};\\\", \\\"{x:455,y:707,t:1528139662816};\\\", \\\"{x:399,y:707,t:1528139662832};\\\", \\\"{x:377,y:707,t:1528139662849};\\\", \\\"{x:374,y:707,t:1528139662866};\\\", \\\"{x:373,y:707,t:1528139662901};\\\", \\\"{x:373,y:705,t:1528139663029};\\\", \\\"{x:373,y:704,t:1528139663037};\\\", \\\"{x:373,y:702,t:1528139663049};\\\", \\\"{x:377,y:696,t:1528139663067};\\\", \\\"{x:383,y:691,t:1528139663082};\\\", \\\"{x:391,y:686,t:1528139663098};\\\", \\\"{x:401,y:679,t:1528139663116};\\\", \\\"{x:408,y:672,t:1528139663131};\\\", \\\"{x:427,y:661,t:1528139663149};\\\", \\\"{x:443,y:654,t:1528139663165};\\\", \\\"{x:462,y:647,t:1528139663182};\\\", \\\"{x:486,y:640,t:1528139663199};\\\", \\\"{x:514,y:635,t:1528139663216};\\\", \\\"{x:542,y:626,t:1528139663233};\\\", \\\"{x:570,y:622,t:1528139663249};\\\", \\\"{x:594,y:617,t:1528139663265};\\\", \\\"{x:616,y:614,t:1528139663282};\\\", \\\"{x:639,y:613,t:1528139663299};\\\", \\\"{x:665,y:610,t:1528139663315};\\\", \\\"{x:706,y:605,t:1528139663332};\\\", \\\"{x:727,y:600,t:1528139663351};\\\", \\\"{x:745,y:597,t:1528139663365};\\\", \\\"{x:759,y:594,t:1528139663382};\\\", \\\"{x:769,y:590,t:1528139663399};\\\", \\\"{x:771,y:590,t:1528139663415};\\\", \\\"{x:773,y:588,t:1528139663432};\\\", \\\"{x:775,y:586,t:1528139663558};\\\", \\\"{x:778,y:584,t:1528139663567};\\\", \\\"{x:780,y:583,t:1528139663583};\\\", \\\"{x:782,y:581,t:1528139663599};\\\", \\\"{x:784,y:579,t:1528139663616};\\\", \\\"{x:786,y:578,t:1528139663632};\\\", \\\"{x:788,y:577,t:1528139663649};\\\", \\\"{x:790,y:577,t:1528139663666};\\\", \\\"{x:793,y:577,t:1528139663683};\\\", \\\"{x:797,y:577,t:1528139663700};\\\", \\\"{x:803,y:577,t:1528139663716};\\\", \\\"{x:806,y:577,t:1528139663732};\\\", \\\"{x:807,y:577,t:1528139663749};\\\", \\\"{x:809,y:576,t:1528139663767};\\\", \\\"{x:810,y:576,t:1528139663805};\\\", \\\"{x:812,y:576,t:1528139663829};\\\", \\\"{x:814,y:576,t:1528139663845};\\\", \\\"{x:815,y:576,t:1528139663853};\\\", \\\"{x:816,y:576,t:1528139663866};\\\", \\\"{x:823,y:576,t:1528139663882};\\\", \\\"{x:828,y:576,t:1528139663900};\\\", \\\"{x:834,y:574,t:1528139663916};\\\", \\\"{x:838,y:573,t:1528139663933};\\\", \\\"{x:842,y:572,t:1528139663949};\\\", \\\"{x:839,y:575,t:1528139664244};\\\", \\\"{x:836,y:580,t:1528139664252};\\\", \\\"{x:831,y:585,t:1528139664267};\\\", \\\"{x:818,y:598,t:1528139664284};\\\", \\\"{x:802,y:613,t:1528139664299};\\\", \\\"{x:775,y:640,t:1528139664317};\\\", \\\"{x:760,y:656,t:1528139664334};\\\", \\\"{x:745,y:669,t:1528139664349};\\\", \\\"{x:730,y:678,t:1528139664367};\\\", \\\"{x:715,y:685,t:1528139664383};\\\", \\\"{x:706,y:688,t:1528139664400};\\\", \\\"{x:700,y:692,t:1528139664417};\\\", \\\"{x:693,y:695,t:1528139664434};\\\", \\\"{x:689,y:697,t:1528139664450};\\\", \\\"{x:682,y:699,t:1528139664466};\\\", \\\"{x:673,y:701,t:1528139664484};\\\", \\\"{x:656,y:705,t:1528139664499};\\\", \\\"{x:616,y:716,t:1528139664517};\\\", \\\"{x:591,y:722,t:1528139664534};\\\", \\\"{x:571,y:724,t:1528139664551};\\\", \\\"{x:555,y:725,t:1528139664567};\\\", \\\"{x:551,y:727,t:1528139664583};\\\", \\\"{x:551,y:728,t:1528139664600};\\\", \\\"{x:550,y:730,t:1528139664617};\\\", \\\"{x:550,y:733,t:1528139664634};\\\", \\\"{x:547,y:737,t:1528139664650};\\\", \\\"{x:547,y:745,t:1528139664667};\\\", \\\"{x:546,y:750,t:1528139664684};\\\", \\\"{x:546,y:757,t:1528139664703};\\\", \\\"{x:546,y:759,t:1528139664724};\\\", \\\"{x:546,y:760,t:1528139664733};\\\", \\\"{x:546,y:762,t:1528139664853};\\\", \\\"{x:545,y:764,t:1528139664867};\\\", \\\"{x:537,y:769,t:1528139664883};\\\", \\\"{x:532,y:772,t:1528139664901};\\\" ] }, { \\\"rt\\\": 21311, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 10, \\\"time_elapsed\\\": 431606, \\\"internal_node_id\\\": \\\"0.0-6.0-0.0\\\", \\\"subject\\\": \\\"JYGX2\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"yankee\\\", \\\"condition\\\": \\\"311\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"duration\\\", \\\"q\\\": 6, \\\"clicks\\\": 2.5, \\\"explicit\\\": 3, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XInside-YFull\\\", \\\"correct\\\": 1, \\\"orth_correct\\\": 1, \\\"answer\\\": [ \\\"E\\\", \\\"G\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-E -E -E -E -E -E -E -E -G -G -6-6-E -G \\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:536,y:772,t:1528139666328};\\\", \\\"{x:538,y:773,t:1528139666336};\\\", \\\"{x:539,y:775,t:1528139666354};\\\", \\\"{x:543,y:776,t:1528139666369};\\\", \\\"{x:545,y:777,t:1528139666385};\\\", \\\"{x:547,y:778,t:1528139666416};\\\", \\\"{x:548,y:778,t:1528139666484};\\\", \\\"{x:550,y:780,t:1528139666745};\\\", \\\"{x:551,y:780,t:1528139666788};\\\", \\\"{x:552,y:781,t:1528139666804};\\\", \\\"{x:553,y:781,t:1528139666860};\\\", \\\"{x:554,y:781,t:1528139666892};\\\", \\\"{x:555,y:781,t:1528139666916};\\\", \\\"{x:555,y:782,t:1528139666932};\\\", \\\"{x:556,y:782,t:1528139666940};\\\", \\\"{x:557,y:782,t:1528139666956};\\\", \\\"{x:558,y:783,t:1528139666969};\\\", \\\"{x:560,y:783,t:1528139666988};\\\", \\\"{x:560,y:784,t:1528139667002};\\\", \\\"{x:561,y:784,t:1528139667019};\\\", \\\"{x:562,y:784,t:1528139667036};\\\", \\\"{x:563,y:785,t:1528139667052};\\\", \\\"{x:565,y:787,t:1528139667069};\\\", \\\"{x:567,y:788,t:1528139667101};\\\", \\\"{x:568,y:788,t:1528139667141};\\\", \\\"{x:569,y:788,t:1528139667173};\\\", \\\"{x:569,y:790,t:1528139667245};\\\", \\\"{x:570,y:790,t:1528139667253};\\\", \\\"{x:572,y:791,t:1528139667269};\\\", \\\"{x:572,y:794,t:1528139667286};\\\", \\\"{x:572,y:795,t:1528139667303};\\\", \\\"{x:573,y:796,t:1528139667318};\\\", \\\"{x:574,y:798,t:1528139667336};\\\", \\\"{x:575,y:800,t:1528139667353};\\\", \\\"{x:576,y:802,t:1528139667369};\\\", \\\"{x:577,y:804,t:1528139667386};\\\", \\\"{x:578,y:805,t:1528139667403};\\\", \\\"{x:579,y:806,t:1528139667445};\\\", \\\"{x:580,y:806,t:1528139667469};\\\", \\\"{x:580,y:807,t:1528139667493};\\\", \\\"{x:581,y:807,t:1528139667509};\\\", \\\"{x:581,y:808,t:1528139667621};\\\", \\\"{x:581,y:809,t:1528139667636};\\\", \\\"{x:581,y:811,t:1528139667653};\\\", \\\"{x:582,y:814,t:1528139667669};\\\", \\\"{x:583,y:814,t:1528139667686};\\\", \\\"{x:584,y:816,t:1528139667703};\\\", \\\"{x:584,y:818,t:1528139667719};\\\", \\\"{x:585,y:819,t:1528139667736};\\\", \\\"{x:585,y:820,t:1528139667780};\\\", \\\"{x:586,y:820,t:1528139667829};\\\", \\\"{x:586,y:821,t:1528139667933};\\\", \\\"{x:586,y:822,t:1528139667956};\\\", \\\"{x:586,y:823,t:1528139667969};\\\", \\\"{x:587,y:825,t:1528139667985};\\\", \\\"{x:587,y:826,t:1528139668060};\\\", \\\"{x:588,y:826,t:1528139668141};\\\", \\\"{x:589,y:826,t:1528139668152};\\\", \\\"{x:595,y:824,t:1528139668169};\\\", \\\"{x:602,y:819,t:1528139668186};\\\", \\\"{x:604,y:818,t:1528139668202};\\\", \\\"{x:607,y:816,t:1528139668219};\\\", \\\"{x:616,y:810,t:1528139668236};\\\", \\\"{x:621,y:808,t:1528139668252};\\\", \\\"{x:622,y:808,t:1528139668270};\\\", \\\"{x:623,y:808,t:1528139668287};\\\", \\\"{x:625,y:808,t:1528139668781};\\\", \\\"{x:626,y:808,t:1528139668789};\\\", \\\"{x:627,y:808,t:1528139668805};\\\", \\\"{x:628,y:809,t:1528139668820};\\\", \\\"{x:630,y:809,t:1528139668837};\\\", \\\"{x:631,y:810,t:1528139668854};\\\", \\\"{x:632,y:810,t:1528139668870};\\\", \\\"{x:633,y:810,t:1528139668909};\\\", \\\"{x:635,y:811,t:1528139669029};\\\", \\\"{x:635,y:812,t:1528139669085};\\\", \\\"{x:637,y:812,t:1528139669092};\\\", \\\"{x:641,y:815,t:1528139669104};\\\", \\\"{x:646,y:817,t:1528139669119};\\\", \\\"{x:651,y:819,t:1528139669137};\\\", \\\"{x:658,y:823,t:1528139669154};\\\", \\\"{x:662,y:823,t:1528139669171};\\\", \\\"{x:664,y:824,t:1528139669187};\\\", \\\"{x:665,y:824,t:1528139669204};\\\", \\\"{x:669,y:824,t:1528139669221};\\\", \\\"{x:674,y:824,t:1528139669237};\\\", \\\"{x:681,y:824,t:1528139669254};\\\", \\\"{x:690,y:824,t:1528139669271};\\\", \\\"{x:701,y:821,t:1528139669288};\\\", \\\"{x:709,y:817,t:1528139669304};\\\", \\\"{x:713,y:816,t:1528139669321};\\\", \\\"{x:714,y:815,t:1528139669337};\\\", \\\"{x:716,y:814,t:1528139669354};\\\", \\\"{x:723,y:810,t:1528139669371};\\\", \\\"{x:731,y:805,t:1528139669387};\\\", \\\"{x:738,y:801,t:1528139669404};\\\", \\\"{x:752,y:792,t:1528139669421};\\\", \\\"{x:762,y:787,t:1528139669436};\\\", \\\"{x:776,y:780,t:1528139669454};\\\", \\\"{x:791,y:774,t:1528139669471};\\\", \\\"{x:806,y:764,t:1528139669488};\\\", \\\"{x:825,y:753,t:1528139669504};\\\", \\\"{x:852,y:737,t:1528139669521};\\\", \\\"{x:878,y:725,t:1528139669537};\\\", \\\"{x:914,y:710,t:1528139669554};\\\", \\\"{x:956,y:689,t:1528139669571};\\\", \\\"{x:984,y:672,t:1528139669588};\\\", \\\"{x:1002,y:659,t:1528139669604};\\\", \\\"{x:1019,y:647,t:1528139669621};\\\", \\\"{x:1027,y:643,t:1528139669638};\\\", \\\"{x:1035,y:637,t:1528139669654};\\\", \\\"{x:1049,y:629,t:1528139669671};\\\", \\\"{x:1065,y:620,t:1528139669688};\\\", \\\"{x:1081,y:610,t:1528139669704};\\\", \\\"{x:1099,y:601,t:1528139669721};\\\", \\\"{x:1118,y:589,t:1528139669738};\\\", \\\"{x:1133,y:581,t:1528139669754};\\\", \\\"{x:1142,y:574,t:1528139669771};\\\", \\\"{x:1149,y:570,t:1528139669788};\\\", \\\"{x:1155,y:566,t:1528139669804};\\\", \\\"{x:1168,y:559,t:1528139669821};\\\", \\\"{x:1177,y:553,t:1528139669839};\\\", \\\"{x:1193,y:545,t:1528139669854};\\\", \\\"{x:1208,y:537,t:1528139669871};\\\", \\\"{x:1226,y:529,t:1528139669889};\\\", \\\"{x:1242,y:519,t:1528139669904};\\\", \\\"{x:1255,y:511,t:1528139669920};\\\", \\\"{x:1268,y:504,t:1528139669937};\\\", \\\"{x:1282,y:495,t:1528139669953};\\\", \\\"{x:1297,y:489,t:1528139669970};\\\", \\\"{x:1308,y:482,t:1528139669988};\\\", \\\"{x:1320,y:477,t:1528139670003};\\\", \\\"{x:1346,y:466,t:1528139670020};\\\", \\\"{x:1367,y:457,t:1528139670037};\\\", \\\"{x:1386,y:446,t:1528139670054};\\\", \\\"{x:1400,y:436,t:1528139670071};\\\", \\\"{x:1405,y:429,t:1528139670087};\\\", \\\"{x:1405,y:428,t:1528139670104};\\\", \\\"{x:1404,y:430,t:1528139671174};\\\", \\\"{x:1386,y:452,t:1528139671189};\\\", \\\"{x:1362,y:479,t:1528139671206};\\\", \\\"{x:1342,y:510,t:1528139671222};\\\", \\\"{x:1330,y:529,t:1528139671240};\\\", \\\"{x:1324,y:541,t:1528139671255};\\\", \\\"{x:1323,y:546,t:1528139671272};\\\", \\\"{x:1323,y:557,t:1528139671289};\\\", \\\"{x:1323,y:567,t:1528139671305};\\\", \\\"{x:1323,y:575,t:1528139671322};\\\", \\\"{x:1323,y:585,t:1528139671339};\\\", \\\"{x:1323,y:592,t:1528139671356};\\\", \\\"{x:1323,y:598,t:1528139671372};\\\", \\\"{x:1325,y:601,t:1528139671390};\\\", \\\"{x:1326,y:601,t:1528139671429};\\\", \\\"{x:1327,y:600,t:1528139671444};\\\", \\\"{x:1327,y:596,t:1528139671455};\\\", \\\"{x:1327,y:587,t:1528139671472};\\\", \\\"{x:1320,y:577,t:1528139671489};\\\", \\\"{x:1311,y:569,t:1528139671505};\\\", \\\"{x:1299,y:562,t:1528139671522};\\\", \\\"{x:1286,y:556,t:1528139671539};\\\", \\\"{x:1278,y:549,t:1528139671556};\\\", \\\"{x:1274,y:546,t:1528139671573};\\\", \\\"{x:1273,y:546,t:1528139671589};\\\", \\\"{x:1272,y:546,t:1528139671606};\\\", \\\"{x:1272,y:547,t:1528139671669};\\\", \\\"{x:1272,y:548,t:1528139671685};\\\", \\\"{x:1272,y:549,t:1528139671709};\\\", \\\"{x:1274,y:551,t:1528139671749};\\\", \\\"{x:1275,y:552,t:1528139671764};\\\", \\\"{x:1276,y:552,t:1528139671774};\\\", \\\"{x:1279,y:555,t:1528139671789};\\\", \\\"{x:1282,y:557,t:1528139671806};\\\", \\\"{x:1287,y:560,t:1528139671823};\\\", \\\"{x:1289,y:563,t:1528139671840};\\\", \\\"{x:1290,y:563,t:1528139671857};\\\", \\\"{x:1291,y:564,t:1528139672014};\\\", \\\"{x:1291,y:565,t:1528139672029};\\\", \\\"{x:1291,y:566,t:1528139672045};\\\", \\\"{x:1290,y:567,t:1528139672085};\\\", \\\"{x:1289,y:567,t:1528139672093};\\\", \\\"{x:1288,y:567,t:1528139672106};\\\", \\\"{x:1287,y:567,t:1528139672123};\\\", \\\"{x:1286,y:567,t:1528139672140};\\\", \\\"{x:1284,y:567,t:1528139672159};\\\", \\\"{x:1283,y:567,t:1528139672269};\\\", \\\"{x:1281,y:567,t:1528139672533};\\\", \\\"{x:1279,y:567,t:1528139672549};\\\", \\\"{x:1277,y:567,t:1528139672581};\\\", \\\"{x:1276,y:567,t:1528139672591};\\\", \\\"{x:1276,y:566,t:1528139672606};\\\", \\\"{x:1275,y:565,t:1528139672623};\\\", \\\"{x:1276,y:565,t:1528139672926};\\\", \\\"{x:1277,y:565,t:1528139672940};\\\", \\\"{x:1277,y:564,t:1528139672957};\\\", \\\"{x:1279,y:563,t:1528139673078};\\\", \\\"{x:1280,y:563,t:1528139673093};\\\", \\\"{x:1282,y:563,t:1528139673133};\\\", \\\"{x:1283,y:563,t:1528139673221};\\\", \\\"{x:1287,y:562,t:1528139673230};\\\", \\\"{x:1288,y:562,t:1528139673240};\\\", \\\"{x:1289,y:562,t:1528139673717};\\\", \\\"{x:1289,y:563,t:1528139673733};\\\", \\\"{x:1288,y:565,t:1528139673741};\\\", \\\"{x:1285,y:568,t:1528139673758};\\\", \\\"{x:1283,y:570,t:1528139673774};\\\", \\\"{x:1282,y:570,t:1528139673791};\\\", \\\"{x:1281,y:570,t:1528139673853};\\\", \\\"{x:1280,y:570,t:1528139673877};\\\", \\\"{x:1279,y:570,t:1528139673891};\\\", \\\"{x:1278,y:569,t:1528139673907};\\\", \\\"{x:1278,y:567,t:1528139673925};\\\", \\\"{x:1277,y:564,t:1528139673941};\\\", \\\"{x:1277,y:563,t:1528139673957};\\\", \\\"{x:1276,y:561,t:1528139673974};\\\", \\\"{x:1276,y:558,t:1528139673992};\\\", \\\"{x:1276,y:554,t:1528139674008};\\\", \\\"{x:1276,y:553,t:1528139674024};\\\", \\\"{x:1276,y:554,t:1528139674237};\\\", \\\"{x:1276,y:555,t:1528139674253};\\\", \\\"{x:1276,y:557,t:1528139674261};\\\", \\\"{x:1276,y:559,t:1528139674278};\\\", \\\"{x:1277,y:559,t:1528139674422};\\\", \\\"{x:1278,y:560,t:1528139674452};\\\", \\\"{x:1283,y:560,t:1528139675005};\\\", \\\"{x:1290,y:559,t:1528139675014};\\\", \\\"{x:1301,y:558,t:1528139675025};\\\", \\\"{x:1322,y:553,t:1528139675042};\\\", \\\"{x:1345,y:551,t:1528139675058};\\\", \\\"{x:1365,y:548,t:1528139675076};\\\", \\\"{x:1375,y:548,t:1528139675092};\\\", \\\"{x:1381,y:548,t:1528139675108};\\\", \\\"{x:1383,y:548,t:1528139675125};\\\", \\\"{x:1385,y:548,t:1528139675141};\\\", \\\"{x:1390,y:548,t:1528139675159};\\\", \\\"{x:1397,y:548,t:1528139675176};\\\", \\\"{x:1404,y:548,t:1528139675192};\\\", \\\"{x:1412,y:548,t:1528139675209};\\\", \\\"{x:1413,y:548,t:1528139675225};\\\", \\\"{x:1415,y:548,t:1528139675242};\\\", \\\"{x:1415,y:549,t:1528139675309};\\\", \\\"{x:1415,y:551,t:1528139675325};\\\", \\\"{x:1415,y:553,t:1528139675342};\\\", \\\"{x:1415,y:555,t:1528139675359};\\\", \\\"{x:1415,y:557,t:1528139675375};\\\", \\\"{x:1415,y:558,t:1528139675404};\\\", \\\"{x:1415,y:559,t:1528139675424};\\\", \\\"{x:1415,y:560,t:1528139675444};\\\", \\\"{x:1413,y:561,t:1528139675467};\\\", \\\"{x:1413,y:562,t:1528139675485};\\\", \\\"{x:1408,y:563,t:1528139675896};\\\", \\\"{x:1400,y:563,t:1528139675902};\\\", \\\"{x:1380,y:566,t:1528139675918};\\\", \\\"{x:1364,y:569,t:1528139675934};\\\", \\\"{x:1357,y:570,t:1528139675951};\\\", \\\"{x:1354,y:570,t:1528139675968};\\\", \\\"{x:1352,y:570,t:1528139676022};\\\", \\\"{x:1349,y:570,t:1528139676035};\\\", \\\"{x:1339,y:570,t:1528139676051};\\\", \\\"{x:1323,y:570,t:1528139676068};\\\", \\\"{x:1306,y:570,t:1528139676085};\\\", \\\"{x:1287,y:570,t:1528139676101};\\\", \\\"{x:1283,y:570,t:1528139676119};\\\", \\\"{x:1282,y:570,t:1528139676134};\\\", \\\"{x:1281,y:570,t:1528139676173};\\\", \\\"{x:1278,y:571,t:1528139676184};\\\", \\\"{x:1274,y:573,t:1528139676201};\\\", \\\"{x:1265,y:573,t:1528139676219};\\\", \\\"{x:1258,y:574,t:1528139676235};\\\", \\\"{x:1253,y:575,t:1528139676252};\\\", \\\"{x:1248,y:576,t:1528139676269};\\\", \\\"{x:1244,y:577,t:1528139676285};\\\", \\\"{x:1234,y:579,t:1528139676302};\\\", \\\"{x:1224,y:582,t:1528139676318};\\\", \\\"{x:1216,y:582,t:1528139676336};\\\", \\\"{x:1203,y:582,t:1528139676351};\\\", \\\"{x:1181,y:582,t:1528139676369};\\\", \\\"{x:1159,y:578,t:1528139676386};\\\", \\\"{x:1134,y:574,t:1528139676402};\\\", \\\"{x:1109,y:569,t:1528139676419};\\\", \\\"{x:1086,y:567,t:1528139676436};\\\", \\\"{x:1062,y:564,t:1528139676452};\\\", \\\"{x:1047,y:561,t:1528139676470};\\\", \\\"{x:1045,y:559,t:1528139676486};\\\", \\\"{x:1047,y:559,t:1528139676631};\\\", \\\"{x:1050,y:559,t:1528139676638};\\\", \\\"{x:1052,y:559,t:1528139676652};\\\", \\\"{x:1054,y:560,t:1528139676669};\\\", \\\"{x:1055,y:560,t:1528139676694};\\\", \\\"{x:1057,y:560,t:1528139676806};\\\", \\\"{x:1058,y:560,t:1528139676819};\\\", \\\"{x:1065,y:560,t:1528139676836};\\\", \\\"{x:1070,y:560,t:1528139676852};\\\", \\\"{x:1075,y:560,t:1528139676869};\\\", \\\"{x:1083,y:560,t:1528139676886};\\\", \\\"{x:1088,y:560,t:1528139676902};\\\", \\\"{x:1094,y:560,t:1528139676919};\\\", \\\"{x:1099,y:560,t:1528139676936};\\\", \\\"{x:1104,y:560,t:1528139676953};\\\", \\\"{x:1107,y:560,t:1528139676969};\\\", \\\"{x:1111,y:560,t:1528139676986};\\\", \\\"{x:1114,y:560,t:1528139677003};\\\", \\\"{x:1117,y:560,t:1528139677019};\\\", \\\"{x:1119,y:560,t:1528139677036};\\\", \\\"{x:1125,y:558,t:1528139677053};\\\", \\\"{x:1129,y:558,t:1528139677070};\\\", \\\"{x:1136,y:554,t:1528139677087};\\\", \\\"{x:1140,y:554,t:1528139677103};\\\", \\\"{x:1144,y:554,t:1528139677119};\\\", \\\"{x:1147,y:554,t:1528139677136};\\\", \\\"{x:1151,y:554,t:1528139677153};\\\", \\\"{x:1154,y:554,t:1528139677169};\\\", \\\"{x:1159,y:554,t:1528139677186};\\\", \\\"{x:1165,y:554,t:1528139677203};\\\", \\\"{x:1169,y:554,t:1528139677219};\\\", \\\"{x:1176,y:554,t:1528139677236};\\\", \\\"{x:1180,y:554,t:1528139677253};\\\", \\\"{x:1186,y:554,t:1528139677270};\\\", \\\"{x:1194,y:554,t:1528139677286};\\\", \\\"{x:1201,y:554,t:1528139677303};\\\", \\\"{x:1208,y:554,t:1528139677321};\\\", \\\"{x:1215,y:554,t:1528139677336};\\\", \\\"{x:1223,y:554,t:1528139677353};\\\", \\\"{x:1230,y:554,t:1528139677370};\\\", \\\"{x:1236,y:554,t:1528139677385};\\\", \\\"{x:1238,y:554,t:1528139677402};\\\", \\\"{x:1239,y:553,t:1528139677419};\\\", \\\"{x:1241,y:553,t:1528139677435};\\\", \\\"{x:1243,y:553,t:1528139677469};\\\", \\\"{x:1244,y:553,t:1528139677486};\\\", \\\"{x:1247,y:553,t:1528139677502};\\\", \\\"{x:1248,y:553,t:1528139677519};\\\", \\\"{x:1251,y:553,t:1528139677536};\\\", \\\"{x:1255,y:553,t:1528139677552};\\\", \\\"{x:1258,y:554,t:1528139677569};\\\", \\\"{x:1262,y:555,t:1528139677586};\\\", \\\"{x:1266,y:555,t:1528139677603};\\\", \\\"{x:1271,y:556,t:1528139677620};\\\", \\\"{x:1277,y:558,t:1528139677636};\\\", \\\"{x:1284,y:560,t:1528139677652};\\\", \\\"{x:1291,y:560,t:1528139677670};\\\", \\\"{x:1293,y:560,t:1528139677686};\\\", \\\"{x:1294,y:560,t:1528139677703};\\\", \\\"{x:1295,y:560,t:1528139677720};\\\", \\\"{x:1296,y:560,t:1528139677759};\\\", \\\"{x:1298,y:560,t:1528139677783};\\\", \\\"{x:1299,y:560,t:1528139677815};\\\", \\\"{x:1300,y:560,t:1528139677822};\\\", \\\"{x:1301,y:560,t:1528139677837};\\\", \\\"{x:1305,y:560,t:1528139677853};\\\", \\\"{x:1312,y:560,t:1528139677870};\\\", \\\"{x:1318,y:561,t:1528139677887};\\\", \\\"{x:1323,y:561,t:1528139677902};\\\", \\\"{x:1332,y:562,t:1528139677919};\\\", \\\"{x:1339,y:562,t:1528139677937};\\\", \\\"{x:1344,y:562,t:1528139677953};\\\", \\\"{x:1349,y:564,t:1528139677970};\\\", \\\"{x:1351,y:564,t:1528139677987};\\\", \\\"{x:1352,y:564,t:1528139678003};\\\", \\\"{x:1353,y:564,t:1528139678022};\\\", \\\"{x:1354,y:564,t:1528139678037};\\\", \\\"{x:1355,y:564,t:1528139678053};\\\", \\\"{x:1357,y:564,t:1528139678079};\\\", \\\"{x:1358,y:564,t:1528139678135};\\\", \\\"{x:1359,y:564,t:1528139678151};\\\", \\\"{x:1361,y:564,t:1528139678166};\\\", \\\"{x:1363,y:564,t:1528139678182};\\\", \\\"{x:1364,y:564,t:1528139678191};\\\", \\\"{x:1366,y:564,t:1528139678204};\\\", \\\"{x:1368,y:564,t:1528139678220};\\\", \\\"{x:1370,y:564,t:1528139678237};\\\", \\\"{x:1373,y:564,t:1528139678254};\\\", \\\"{x:1380,y:564,t:1528139678271};\\\", \\\"{x:1384,y:564,t:1528139678287};\\\", \\\"{x:1394,y:564,t:1528139678304};\\\", \\\"{x:1401,y:564,t:1528139678320};\\\", \\\"{x:1405,y:564,t:1528139678337};\\\", \\\"{x:1408,y:564,t:1528139678354};\\\", \\\"{x:1409,y:564,t:1528139678370};\\\", \\\"{x:1411,y:565,t:1528139678403};\\\", \\\"{x:1413,y:566,t:1528139678420};\\\", \\\"{x:1415,y:566,t:1528139678437};\\\", \\\"{x:1417,y:566,t:1528139678454};\\\", \\\"{x:1418,y:566,t:1528139678526};\\\", \\\"{x:1420,y:567,t:1528139678984};\\\", \\\"{x:1403,y:567,t:1528139680295};\\\", \\\"{x:1375,y:567,t:1528139680305};\\\", \\\"{x:1294,y:567,t:1528139680322};\\\", \\\"{x:1192,y:567,t:1528139680338};\\\", \\\"{x:1086,y:569,t:1528139680356};\\\", \\\"{x:997,y:571,t:1528139680372};\\\", \\\"{x:938,y:571,t:1528139680390};\\\", \\\"{x:908,y:571,t:1528139680405};\\\", \\\"{x:892,y:571,t:1528139680421};\\\", \\\"{x:891,y:571,t:1528139680437};\\\", \\\"{x:890,y:573,t:1528139680502};\\\", \\\"{x:889,y:574,t:1528139680509};\\\", \\\"{x:887,y:576,t:1528139680525};\\\", \\\"{x:886,y:577,t:1528139680541};\\\", \\\"{x:884,y:578,t:1528139680574};\\\", \\\"{x:883,y:578,t:1528139680597};\\\", \\\"{x:882,y:578,t:1528139680605};\\\", \\\"{x:880,y:580,t:1528139680623};\\\", \\\"{x:879,y:580,t:1528139680639};\\\", \\\"{x:878,y:580,t:1528139680655};\\\", \\\"{x:878,y:581,t:1528139680673};\\\", \\\"{x:877,y:582,t:1528139680689};\\\", \\\"{x:876,y:582,t:1528139680735};\\\", \\\"{x:876,y:583,t:1528139680742};\\\", \\\"{x:876,y:586,t:1528139680756};\\\", \\\"{x:875,y:589,t:1528139680773};\\\", \\\"{x:875,y:592,t:1528139680790};\\\", \\\"{x:875,y:593,t:1528139681119};\\\", \\\"{x:873,y:594,t:1528139681128};\\\", \\\"{x:872,y:595,t:1528139681140};\\\", \\\"{x:867,y:597,t:1528139681156};\\\", \\\"{x:862,y:600,t:1528139681173};\\\", \\\"{x:846,y:608,t:1528139681191};\\\", \\\"{x:834,y:613,t:1528139681205};\\\", \\\"{x:821,y:619,t:1528139681223};\\\", \\\"{x:813,y:624,t:1528139681239};\\\", \\\"{x:807,y:627,t:1528139681256};\\\", \\\"{x:802,y:630,t:1528139681272};\\\", \\\"{x:801,y:633,t:1528139681290};\\\", \\\"{x:797,y:640,t:1528139681305};\\\", \\\"{x:793,y:649,t:1528139681322};\\\", \\\"{x:792,y:662,t:1528139681340};\\\", \\\"{x:789,y:681,t:1528139681357};\\\", \\\"{x:789,y:705,t:1528139681373};\\\", \\\"{x:789,y:745,t:1528139681389};\\\", \\\"{x:789,y:771,t:1528139681407};\\\", \\\"{x:789,y:791,t:1528139681423};\\\", \\\"{x:788,y:801,t:1528139681440};\\\", \\\"{x:787,y:809,t:1528139681456};\\\", \\\"{x:784,y:817,t:1528139681472};\\\", \\\"{x:784,y:821,t:1528139681490};\\\", \\\"{x:784,y:824,t:1528139681506};\\\", \\\"{x:783,y:826,t:1528139681523};\\\", \\\"{x:783,y:827,t:1528139681847};\\\", \\\"{x:783,y:825,t:1528139681917};\\\", \\\"{x:783,y:822,t:1528139681925};\\\", \\\"{x:783,y:818,t:1528139681939};\\\", \\\"{x:780,y:807,t:1528139681956};\\\", \\\"{x:774,y:792,t:1528139681974};\\\", \\\"{x:765,y:782,t:1528139681989};\\\", \\\"{x:756,y:773,t:1528139682006};\\\", \\\"{x:745,y:768,t:1528139682023};\\\", \\\"{x:728,y:762,t:1528139682040};\\\", \\\"{x:711,y:757,t:1528139682057};\\\", \\\"{x:693,y:751,t:1528139682073};\\\", \\\"{x:677,y:747,t:1528139682089};\\\", \\\"{x:667,y:746,t:1528139682106};\\\", \\\"{x:660,y:745,t:1528139682124};\\\", \\\"{x:658,y:744,t:1528139682141};\\\", \\\"{x:658,y:743,t:1528139682157};\\\", \\\"{x:655,y:742,t:1528139682173};\\\", \\\"{x:649,y:739,t:1528139682191};\\\", \\\"{x:638,y:735,t:1528139682206};\\\", \\\"{x:624,y:729,t:1528139682224};\\\", \\\"{x:606,y:720,t:1528139682241};\\\", \\\"{x:589,y:708,t:1528139682257};\\\", \\\"{x:569,y:694,t:1528139682274};\\\", \\\"{x:555,y:678,t:1528139682292};\\\", \\\"{x:549,y:664,t:1528139682307};\\\", \\\"{x:546,y:650,t:1528139682324};\\\", \\\"{x:545,y:640,t:1528139682341};\\\", \\\"{x:551,y:626,t:1528139682358};\\\", \\\"{x:572,y:601,t:1528139682374};\\\", \\\"{x:587,y:582,t:1528139682392};\\\", \\\"{x:601,y:567,t:1528139682407};\\\", \\\"{x:614,y:556,t:1528139682424};\\\", \\\"{x:626,y:548,t:1528139682441};\\\", \\\"{x:631,y:545,t:1528139682457};\\\", \\\"{x:633,y:544,t:1528139682473};\\\", \\\"{x:637,y:543,t:1528139682490};\\\", \\\"{x:641,y:542,t:1528139682507};\\\", \\\"{x:648,y:542,t:1528139682524};\\\", \\\"{x:654,y:541,t:1528139682541};\\\", \\\"{x:661,y:539,t:1528139682557};\\\", \\\"{x:667,y:537,t:1528139682574};\\\", \\\"{x:668,y:536,t:1528139682662};\\\", \\\"{x:668,y:535,t:1528139682674};\\\", \\\"{x:664,y:534,t:1528139682691};\\\", \\\"{x:661,y:533,t:1528139682708};\\\", \\\"{x:654,y:532,t:1528139682724};\\\", \\\"{x:649,y:532,t:1528139682741};\\\", \\\"{x:646,y:531,t:1528139682758};\\\", \\\"{x:642,y:529,t:1528139682774};\\\", \\\"{x:641,y:529,t:1528139682791};\\\", \\\"{x:639,y:526,t:1528139682808};\\\", \\\"{x:636,y:523,t:1528139682824};\\\", \\\"{x:630,y:520,t:1528139682841};\\\", \\\"{x:626,y:518,t:1528139682857};\\\", \\\"{x:621,y:516,t:1528139682875};\\\", \\\"{x:619,y:515,t:1528139682890};\\\", \\\"{x:617,y:514,t:1528139682908};\\\", \\\"{x:616,y:513,t:1528139682924};\\\", \\\"{x:616,y:512,t:1528139682940};\\\", \\\"{x:614,y:509,t:1528139682958};\\\", \\\"{x:613,y:509,t:1528139683269};\\\", \\\"{x:609,y:509,t:1528139683277};\\\", \\\"{x:597,y:512,t:1528139683291};\\\", \\\"{x:568,y:523,t:1528139683308};\\\", \\\"{x:536,y:532,t:1528139683325};\\\", \\\"{x:510,y:540,t:1528139683340};\\\", \\\"{x:480,y:547,t:1528139683358};\\\", \\\"{x:457,y:554,t:1528139683375};\\\", \\\"{x:431,y:560,t:1528139683391};\\\", \\\"{x:411,y:567,t:1528139683409};\\\", \\\"{x:401,y:569,t:1528139683425};\\\", \\\"{x:397,y:572,t:1528139683442};\\\", \\\"{x:396,y:572,t:1528139683461};\\\", \\\"{x:392,y:572,t:1528139683486};\\\", \\\"{x:391,y:573,t:1528139683509};\\\", \\\"{x:390,y:573,t:1528139683525};\\\", \\\"{x:386,y:574,t:1528139683542};\\\", \\\"{x:382,y:575,t:1528139683558};\\\", \\\"{x:377,y:577,t:1528139683575};\\\", \\\"{x:372,y:580,t:1528139683593};\\\", \\\"{x:369,y:582,t:1528139683609};\\\", \\\"{x:363,y:585,t:1528139683625};\\\", \\\"{x:360,y:585,t:1528139683642};\\\", \\\"{x:355,y:585,t:1528139683658};\\\", \\\"{x:347,y:587,t:1528139683675};\\\", \\\"{x:331,y:588,t:1528139683692};\\\", \\\"{x:317,y:589,t:1528139683708};\\\", \\\"{x:303,y:592,t:1528139683725};\\\", \\\"{x:285,y:594,t:1528139683743};\\\", \\\"{x:271,y:597,t:1528139683758};\\\", \\\"{x:261,y:597,t:1528139683775};\\\", \\\"{x:248,y:597,t:1528139683791};\\\", \\\"{x:237,y:597,t:1528139683807};\\\", \\\"{x:218,y:597,t:1528139683824};\\\", \\\"{x:196,y:597,t:1528139683842};\\\", \\\"{x:186,y:595,t:1528139683858};\\\", \\\"{x:181,y:592,t:1528139683875};\\\", \\\"{x:180,y:590,t:1528139683894};\\\", \\\"{x:178,y:588,t:1528139683918};\\\", \\\"{x:178,y:587,t:1528139683933};\\\", \\\"{x:177,y:585,t:1528139683941};\\\", \\\"{x:174,y:582,t:1528139683958};\\\", \\\"{x:171,y:578,t:1528139683974};\\\", \\\"{x:169,y:573,t:1528139683992};\\\", \\\"{x:167,y:572,t:1528139684009};\\\", \\\"{x:168,y:574,t:1528139684183};\\\", \\\"{x:169,y:576,t:1528139684193};\\\", \\\"{x:171,y:586,t:1528139684209};\\\", \\\"{x:172,y:598,t:1528139684226};\\\", \\\"{x:172,y:613,t:1528139684242};\\\", \\\"{x:172,y:629,t:1528139684259};\\\", \\\"{x:172,y:646,t:1528139684275};\\\", \\\"{x:172,y:660,t:1528139684291};\\\", \\\"{x:172,y:667,t:1528139684309};\\\", \\\"{x:172,y:670,t:1528139684326};\\\", \\\"{x:172,y:671,t:1528139684341};\\\", \\\"{x:174,y:673,t:1528139684413};\\\", \\\"{x:175,y:674,t:1528139684424};\\\", \\\"{x:180,y:675,t:1528139684442};\\\", \\\"{x:188,y:675,t:1528139684459};\\\", \\\"{x:198,y:675,t:1528139684476};\\\", \\\"{x:212,y:671,t:1528139684492};\\\", \\\"{x:235,y:663,t:1528139684510};\\\", \\\"{x:281,y:649,t:1528139684527};\\\", \\\"{x:313,y:637,t:1528139684544};\\\", \\\"{x:352,y:629,t:1528139684560};\\\", \\\"{x:390,y:617,t:1528139684577};\\\", \\\"{x:424,y:610,t:1528139684592};\\\", \\\"{x:468,y:602,t:1528139684608};\\\", \\\"{x:502,y:595,t:1528139684626};\\\", \\\"{x:532,y:588,t:1528139684642};\\\", \\\"{x:553,y:582,t:1528139684659};\\\", \\\"{x:570,y:578,t:1528139684675};\\\", \\\"{x:584,y:574,t:1528139684691};\\\", \\\"{x:595,y:572,t:1528139684709};\\\", \\\"{x:609,y:569,t:1528139684725};\\\", \\\"{x:628,y:566,t:1528139684742};\\\", \\\"{x:640,y:566,t:1528139684759};\\\", \\\"{x:655,y:566,t:1528139684776};\\\", \\\"{x:675,y:564,t:1528139684792};\\\", \\\"{x:690,y:562,t:1528139684809};\\\", \\\"{x:711,y:559,t:1528139684826};\\\", \\\"{x:734,y:555,t:1528139684842};\\\", \\\"{x:760,y:547,t:1528139684859};\\\", \\\"{x:786,y:540,t:1528139684876};\\\", \\\"{x:807,y:535,t:1528139684893};\\\", \\\"{x:815,y:531,t:1528139684909};\\\", \\\"{x:817,y:531,t:1528139684925};\\\", \\\"{x:819,y:531,t:1528139684943};\\\", \\\"{x:820,y:531,t:1528139684966};\\\", \\\"{x:821,y:530,t:1528139684976};\\\", \\\"{x:821,y:531,t:1528139685087};\\\", \\\"{x:821,y:533,t:1528139685094};\\\", \\\"{x:821,y:535,t:1528139685110};\\\", \\\"{x:821,y:537,t:1528139685126};\\\", \\\"{x:821,y:538,t:1528139685142};\\\", \\\"{x:821,y:541,t:1528139685406};\\\", \\\"{x:814,y:548,t:1528139685414};\\\", \\\"{x:808,y:553,t:1528139685426};\\\", \\\"{x:791,y:571,t:1528139685445};\\\", \\\"{x:776,y:587,t:1528139685460};\\\", \\\"{x:757,y:607,t:1528139685476};\\\", \\\"{x:739,y:626,t:1528139685493};\\\", \\\"{x:715,y:656,t:1528139685510};\\\", \\\"{x:698,y:677,t:1528139685525};\\\", \\\"{x:684,y:690,t:1528139685543};\\\", \\\"{x:674,y:699,t:1528139685560};\\\", \\\"{x:664,y:705,t:1528139685576};\\\", \\\"{x:657,y:712,t:1528139685593};\\\", \\\"{x:648,y:716,t:1528139685610};\\\", \\\"{x:641,y:719,t:1528139685625};\\\", \\\"{x:637,y:720,t:1528139685642};\\\", \\\"{x:636,y:721,t:1528139685660};\\\", \\\"{x:635,y:721,t:1528139685726};\\\", \\\"{x:634,y:721,t:1528139685743};\\\", \\\"{x:633,y:721,t:1528139685761};\\\", \\\"{x:631,y:721,t:1528139685776};\\\", \\\"{x:627,y:716,t:1528139685793};\\\", \\\"{x:627,y:705,t:1528139685810};\\\", \\\"{x:635,y:698,t:1528139685826};\\\", \\\"{x:651,y:675,t:1528139685843};\\\", \\\"{x:656,y:655,t:1528139685860};\\\", \\\"{x:671,y:641,t:1528139685876};\\\", \\\"{x:687,y:628,t:1528139685894};\\\", \\\"{x:693,y:622,t:1528139685909};\\\", \\\"{x:693,y:621,t:1528139685926};\\\", \\\"{x:696,y:618,t:1528139686102};\\\", \\\"{x:700,y:616,t:1528139686110};\\\", \\\"{x:718,y:607,t:1528139686127};\\\", \\\"{x:741,y:596,t:1528139686144};\\\", \\\"{x:758,y:586,t:1528139686161};\\\", \\\"{x:774,y:575,t:1528139686176};\\\", \\\"{x:778,y:572,t:1528139686193};\\\", \\\"{x:779,y:572,t:1528139686210};\\\", \\\"{x:780,y:570,t:1528139686238};\\\", \\\"{x:781,y:568,t:1528139686246};\\\", \\\"{x:781,y:567,t:1528139686261};\\\", \\\"{x:785,y:560,t:1528139686279};\\\", \\\"{x:786,y:557,t:1528139686292};\\\", \\\"{x:789,y:551,t:1528139686310};\\\", \\\"{x:791,y:548,t:1528139686327};\\\", \\\"{x:793,y:545,t:1528139686344};\\\", \\\"{x:793,y:544,t:1528139686359};\\\", \\\"{x:794,y:544,t:1528139686445};\\\", \\\"{x:795,y:543,t:1528139686460};\\\", \\\"{x:797,y:541,t:1528139686477};\\\", \\\"{x:803,y:538,t:1528139686493};\\\", \\\"{x:806,y:537,t:1528139686510};\\\", \\\"{x:809,y:537,t:1528139686527};\\\", \\\"{x:813,y:536,t:1528139686544};\\\", \\\"{x:816,y:535,t:1528139686560};\\\", \\\"{x:821,y:534,t:1528139686577};\\\", \\\"{x:827,y:534,t:1528139686595};\\\", \\\"{x:828,y:533,t:1528139686610};\\\", \\\"{x:829,y:533,t:1528139686821};\\\", \\\"{x:828,y:533,t:1528139687086};\\\", \\\"{x:827,y:533,t:1528139687094};\\\", \\\"{x:823,y:536,t:1528139687111};\\\", \\\"{x:818,y:545,t:1528139687127};\\\", \\\"{x:807,y:565,t:1528139687144};\\\", \\\"{x:790,y:590,t:1528139687161};\\\", \\\"{x:756,y:638,t:1528139687179};\\\", \\\"{x:716,y:678,t:1528139687193};\\\", \\\"{x:669,y:716,t:1528139687211};\\\", \\\"{x:642,y:732,t:1528139687227};\\\", \\\"{x:618,y:742,t:1528139687243};\\\", \\\"{x:604,y:747,t:1528139687261};\\\", \\\"{x:586,y:753,t:1528139687277};\\\", \\\"{x:568,y:754,t:1528139687294};\\\", \\\"{x:561,y:754,t:1528139687311};\\\", \\\"{x:554,y:754,t:1528139687329};\\\", \\\"{x:545,y:749,t:1528139687344};\\\", \\\"{x:536,y:747,t:1528139687361};\\\", \\\"{x:530,y:745,t:1528139687378};\\\", \\\"{x:527,y:743,t:1528139687395};\\\", \\\"{x:523,y:741,t:1528139687411};\\\", \\\"{x:522,y:741,t:1528139687430};\\\", \\\"{x:521,y:740,t:1528139687446};\\\", \\\"{x:520,y:740,t:1528139688254};\\\", \\\"{x:549,y:731,t:1528139688671};\\\", \\\"{x:559,y:728,t:1528139688678};\\\", \\\"{x:571,y:723,t:1528139688695};\\\", \\\"{x:587,y:715,t:1528139688712};\\\", \\\"{x:608,y:709,t:1528139688727};\\\", \\\"{x:641,y:700,t:1528139688744};\\\" ] }, { \\\"rt\\\": 30666, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 11, \\\"time_elapsed\\\": 463544, \\\"internal_node_id\\\": \\\"0.0-6.0-1.0\\\", \\\"subject\\\": \\\"JYGX2\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"yankee\\\", \\\"condition\\\": \\\"311\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"duration+starts\\\", \\\"q\\\": 7, \\\"clicks\\\": 2, \\\"explicit\\\": 3, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XInside-YFull\\\", \\\"correct\\\": 1, \\\"orth_correct\\\": 0, \\\"answer\\\": [ \\\"X\\\", \\\"O\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-F -X \\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:1091,y:632,t:1528139688909};\\\", \\\"{x:1124,y:632,t:1528139688934};\\\", \\\"{x:1132,y:632,t:1528139688945};\\\", \\\"{x:1144,y:632,t:1528139688961};\\\", \\\"{x:1156,y:632,t:1528139688979};\\\", \\\"{x:1170,y:630,t:1528139688998};\\\", \\\"{x:1179,y:628,t:1528139689012};\\\", \\\"{x:1197,y:627,t:1528139689028};\\\", \\\"{x:1242,y:621,t:1528139689045};\\\", \\\"{x:1292,y:615,t:1528139689062};\\\", \\\"{x:1367,y:604,t:1528139689079};\\\", \\\"{x:1500,y:585,t:1528139689096};\\\", \\\"{x:1650,y:563,t:1528139689112};\\\", \\\"{x:1816,y:539,t:1528139689129};\\\", \\\"{x:1919,y:513,t:1528139689146};\\\", \\\"{x:1919,y:493,t:1528139689162};\\\", \\\"{x:1919,y:477,t:1528139689179};\\\", \\\"{x:1919,y:463,t:1528139689196};\\\", \\\"{x:1919,y:454,t:1528139689213};\\\", \\\"{x:1919,y:451,t:1528139689229};\\\", \\\"{x:1919,y:449,t:1528139689310};\\\", \\\"{x:1919,y:448,t:1528139689405};\\\", \\\"{x:1919,y:442,t:1528139689413};\\\", \\\"{x:1919,y:437,t:1528139689428};\\\", \\\"{x:1919,y:429,t:1528139689446};\\\", \\\"{x:1919,y:423,t:1528139689463};\\\", \\\"{x:1919,y:415,t:1528139689479};\\\", \\\"{x:1919,y:414,t:1528139689496};\\\", \\\"{x:1917,y:410,t:1528139690727};\\\", \\\"{x:1903,y:392,t:1528139690734};\\\", \\\"{x:1871,y:360,t:1528139690748};\\\", \\\"{x:1842,y:304,t:1528139690764};\\\", \\\"{x:1828,y:283,t:1528139690780};\\\", \\\"{x:1821,y:274,t:1528139690798};\\\", \\\"{x:1818,y:274,t:1528139690831};\\\", \\\"{x:1807,y:275,t:1528139690848};\\\", \\\"{x:1764,y:292,t:1528139690864};\\\", \\\"{x:1669,y:320,t:1528139690881};\\\", \\\"{x:1538,y:350,t:1528139690898};\\\", \\\"{x:1399,y:371,t:1528139690915};\\\", \\\"{x:1258,y:386,t:1528139690931};\\\", \\\"{x:1124,y:396,t:1528139690948};\\\", \\\"{x:1013,y:398,t:1528139690964};\\\", \\\"{x:927,y:398,t:1528139690981};\\\", \\\"{x:879,y:398,t:1528139690997};\\\", \\\"{x:855,y:398,t:1528139691014};\\\", \\\"{x:844,y:397,t:1528139691032};\\\", \\\"{x:840,y:395,t:1528139691047};\\\", \\\"{x:836,y:394,t:1528139691065};\\\", \\\"{x:832,y:392,t:1528139691081};\\\", \\\"{x:825,y:392,t:1528139691098};\\\", \\\"{x:817,y:394,t:1528139691114};\\\", \\\"{x:801,y:402,t:1528139691131};\\\", \\\"{x:775,y:417,t:1528139691148};\\\", \\\"{x:746,y:434,t:1528139691164};\\\", \\\"{x:705,y:466,t:1528139691181};\\\", \\\"{x:665,y:496,t:1528139691199};\\\", \\\"{x:582,y:541,t:1528139691214};\\\", \\\"{x:523,y:568,t:1528139691231};\\\", \\\"{x:410,y:622,t:1528139691264};\\\", \\\"{x:350,y:637,t:1528139691281};\\\", \\\"{x:323,y:645,t:1528139691298};\\\", \\\"{x:305,y:646,t:1528139691314};\\\", \\\"{x:298,y:647,t:1528139691331};\\\", \\\"{x:296,y:647,t:1528139691347};\\\", \\\"{x:295,y:647,t:1528139691364};\\\", \\\"{x:293,y:647,t:1528139691381};\\\", \\\"{x:290,y:645,t:1528139691397};\\\", \\\"{x:287,y:643,t:1528139691414};\\\", \\\"{x:286,y:641,t:1528139691431};\\\", \\\"{x:284,y:640,t:1528139691448};\\\", \\\"{x:284,y:639,t:1528139691464};\\\", \\\"{x:282,y:637,t:1528139691502};\\\", \\\"{x:283,y:634,t:1528139691973};\\\", \\\"{x:288,y:630,t:1528139691982};\\\", \\\"{x:303,y:621,t:1528139691997};\\\", \\\"{x:319,y:614,t:1528139692014};\\\", \\\"{x:331,y:609,t:1528139692031};\\\", \\\"{x:339,y:605,t:1528139692048};\\\", \\\"{x:348,y:604,t:1528139692065};\\\", \\\"{x:350,y:602,t:1528139692081};\\\", \\\"{x:351,y:602,t:1528139692098};\\\", \\\"{x:352,y:602,t:1528139692115};\\\", \\\"{x:353,y:590,t:1528139692467};\\\", \\\"{x:353,y:546,t:1528139692483};\\\", \\\"{x:347,y:491,t:1528139692499};\\\", \\\"{x:337,y:462,t:1528139692515};\\\", \\\"{x:330,y:442,t:1528139692532};\\\", \\\"{x:328,y:436,t:1528139692547};\\\", \\\"{x:327,y:435,t:1528139692565};\\\", \\\"{x:329,y:435,t:1528139692677};\\\", \\\"{x:330,y:435,t:1528139692685};\\\", \\\"{x:332,y:437,t:1528139692698};\\\", \\\"{x:334,y:440,t:1528139692715};\\\", \\\"{x:337,y:445,t:1528139692732};\\\", \\\"{x:339,y:447,t:1528139692747};\\\", \\\"{x:340,y:452,t:1528139692765};\\\", \\\"{x:342,y:456,t:1528139692782};\\\", \\\"{x:343,y:461,t:1528139692798};\\\", \\\"{x:345,y:463,t:1528139692814};\\\", \\\"{x:347,y:465,t:1528139692832};\\\", \\\"{x:349,y:467,t:1528139692848};\\\", \\\"{x:353,y:467,t:1528139692865};\\\", \\\"{x:362,y:467,t:1528139692882};\\\", \\\"{x:366,y:467,t:1528139692898};\\\", \\\"{x:376,y:465,t:1528139692914};\\\", \\\"{x:382,y:463,t:1528139692932};\\\", \\\"{x:387,y:460,t:1528139692947};\\\", \\\"{x:393,y:458,t:1528139692965};\\\", \\\"{x:394,y:458,t:1528139692981};\\\", \\\"{x:396,y:458,t:1528139692998};\\\", \\\"{x:397,y:458,t:1528139693015};\\\", \\\"{x:399,y:458,t:1528139693032};\\\", \\\"{x:400,y:458,t:1528139693048};\\\", \\\"{x:401,y:458,t:1528139693065};\\\", \\\"{x:403,y:458,t:1528139693082};\\\", \\\"{x:404,y:459,t:1528139693098};\\\", \\\"{x:405,y:460,t:1528139693134};\\\", \\\"{x:406,y:460,t:1528139693150};\\\", \\\"{x:407,y:461,t:1528139693166};\\\", \\\"{x:408,y:463,t:1528139693182};\\\", \\\"{x:410,y:465,t:1528139693198};\\\", \\\"{x:411,y:466,t:1528139693222};\\\", \\\"{x:412,y:467,t:1528139693463};\\\", \\\"{x:413,y:468,t:1528139693471};\\\", \\\"{x:413,y:469,t:1528139693486};\\\", \\\"{x:414,y:470,t:1528139693498};\\\", \\\"{x:414,y:471,t:1528139693515};\\\", \\\"{x:415,y:473,t:1528139693532};\\\", \\\"{x:415,y:474,t:1528139694638};\\\", \\\"{x:415,y:476,t:1528139694718};\\\", \\\"{x:415,y:478,t:1528139694733};\\\", \\\"{x:415,y:481,t:1528139694750};\\\", \\\"{x:415,y:482,t:1528139694765};\\\", \\\"{x:415,y:484,t:1528139695086};\\\", \\\"{x:415,y:485,t:1528139695099};\\\", \\\"{x:417,y:489,t:1528139695118};\\\", \\\"{x:419,y:491,t:1528139695132};\\\", \\\"{x:421,y:492,t:1528139695147};\\\", \\\"{x:424,y:494,t:1528139695164};\\\", \\\"{x:429,y:496,t:1528139695180};\\\", \\\"{x:438,y:499,t:1528139695197};\\\", \\\"{x:448,y:503,t:1528139695214};\\\", \\\"{x:463,y:509,t:1528139695231};\\\", \\\"{x:485,y:515,t:1528139695248};\\\", \\\"{x:518,y:520,t:1528139695264};\\\", \\\"{x:582,y:530,t:1528139695281};\\\", \\\"{x:658,y:541,t:1528139695300};\\\", \\\"{x:769,y:574,t:1528139695318};\\\", \\\"{x:850,y:586,t:1528139695334};\\\", \\\"{x:932,y:603,t:1528139695350};\\\", \\\"{x:994,y:613,t:1528139695367};\\\", \\\"{x:1052,y:622,t:1528139695384};\\\", \\\"{x:1100,y:629,t:1528139695400};\\\", \\\"{x:1140,y:636,t:1528139695417};\\\", \\\"{x:1168,y:643,t:1528139695434};\\\", \\\"{x:1188,y:651,t:1528139695450};\\\", \\\"{x:1204,y:659,t:1528139695468};\\\", \\\"{x:1219,y:670,t:1528139695484};\\\", \\\"{x:1232,y:678,t:1528139695500};\\\", \\\"{x:1242,y:683,t:1528139695517};\\\", \\\"{x:1246,y:684,t:1528139695534};\\\", \\\"{x:1248,y:685,t:1528139695550};\\\", \\\"{x:1249,y:685,t:1528139695751};\\\", \\\"{x:1249,y:684,t:1528139695768};\\\", \\\"{x:1240,y:680,t:1528139695785};\\\", \\\"{x:1217,y:674,t:1528139695802};\\\", \\\"{x:1183,y:666,t:1528139695818};\\\", \\\"{x:1130,y:658,t:1528139695835};\\\", \\\"{x:1052,y:658,t:1528139695851};\\\", \\\"{x:982,y:658,t:1528139695868};\\\", \\\"{x:929,y:658,t:1528139695885};\\\", \\\"{x:875,y:658,t:1528139695902};\\\", \\\"{x:857,y:658,t:1528139695918};\\\", \\\"{x:851,y:658,t:1528139695934};\\\", \\\"{x:850,y:658,t:1528139695952};\\\", \\\"{x:861,y:659,t:1528139696942};\\\", \\\"{x:891,y:664,t:1528139696951};\\\", \\\"{x:959,y:668,t:1528139696969};\\\", \\\"{x:1056,y:668,t:1528139696986};\\\", \\\"{x:1164,y:668,t:1528139697002};\\\", \\\"{x:1283,y:668,t:1528139697019};\\\", \\\"{x:1394,y:667,t:1528139697036};\\\", \\\"{x:1489,y:651,t:1528139697052};\\\", \\\"{x:1573,y:638,t:1528139697069};\\\", \\\"{x:1617,y:625,t:1528139697086};\\\", \\\"{x:1623,y:622,t:1528139697102};\\\", \\\"{x:1624,y:622,t:1528139697175};\\\", \\\"{x:1624,y:625,t:1528139697186};\\\", \\\"{x:1604,y:634,t:1528139697203};\\\", \\\"{x:1560,y:649,t:1528139697219};\\\", \\\"{x:1491,y:666,t:1528139697236};\\\", \\\"{x:1388,y:680,t:1528139697253};\\\", \\\"{x:1256,y:695,t:1528139697269};\\\", \\\"{x:1132,y:714,t:1528139697286};\\\", \\\"{x:1081,y:731,t:1528139697302};\\\", \\\"{x:1055,y:739,t:1528139697319};\\\", \\\"{x:1050,y:740,t:1528139697336};\\\", \\\"{x:1049,y:740,t:1528139697353};\\\", \\\"{x:1050,y:742,t:1528139697369};\\\", \\\"{x:1056,y:745,t:1528139697386};\\\", \\\"{x:1070,y:747,t:1528139697403};\\\", \\\"{x:1096,y:748,t:1528139697419};\\\", \\\"{x:1118,y:748,t:1528139697436};\\\", \\\"{x:1142,y:748,t:1528139697453};\\\", \\\"{x:1172,y:748,t:1528139697469};\\\", \\\"{x:1213,y:748,t:1528139697486};\\\", \\\"{x:1236,y:748,t:1528139697502};\\\", \\\"{x:1252,y:747,t:1528139697520};\\\", \\\"{x:1270,y:742,t:1528139697536};\\\", \\\"{x:1289,y:737,t:1528139697553};\\\", \\\"{x:1304,y:731,t:1528139697570};\\\", \\\"{x:1313,y:727,t:1528139697586};\\\", \\\"{x:1317,y:726,t:1528139697603};\\\", \\\"{x:1317,y:725,t:1528139697620};\\\", \\\"{x:1318,y:725,t:1528139697646};\\\", \\\"{x:1320,y:723,t:1528139697654};\\\", \\\"{x:1329,y:719,t:1528139697670};\\\", \\\"{x:1345,y:713,t:1528139697686};\\\", \\\"{x:1364,y:706,t:1528139697703};\\\", \\\"{x:1386,y:697,t:1528139697720};\\\", \\\"{x:1404,y:689,t:1528139697735};\\\", \\\"{x:1418,y:684,t:1528139697753};\\\", \\\"{x:1425,y:679,t:1528139697770};\\\", \\\"{x:1427,y:678,t:1528139697786};\\\", \\\"{x:1426,y:676,t:1528139697910};\\\", \\\"{x:1422,y:675,t:1528139697919};\\\", \\\"{x:1405,y:668,t:1528139697936};\\\", \\\"{x:1374,y:667,t:1528139697953};\\\", \\\"{x:1296,y:667,t:1528139697970};\\\", \\\"{x:1180,y:680,t:1528139697986};\\\", \\\"{x:1047,y:695,t:1528139698003};\\\", \\\"{x:917,y:716,t:1528139698020};\\\", \\\"{x:792,y:732,t:1528139698036};\\\", \\\"{x:701,y:746,t:1528139698053};\\\", \\\"{x:636,y:757,t:1528139698070};\\\", \\\"{x:623,y:761,t:1528139698086};\\\", \\\"{x:622,y:761,t:1528139698103};\\\", \\\"{x:623,y:763,t:1528139698199};\\\", \\\"{x:627,y:765,t:1528139698205};\\\", \\\"{x:632,y:766,t:1528139698220};\\\", \\\"{x:651,y:768,t:1528139698237};\\\", \\\"{x:673,y:768,t:1528139698252};\\\", \\\"{x:709,y:763,t:1528139698269};\\\", \\\"{x:737,y:760,t:1528139698286};\\\", \\\"{x:758,y:756,t:1528139698303};\\\", \\\"{x:767,y:756,t:1528139698320};\\\", \\\"{x:768,y:756,t:1528139698337};\\\", \\\"{x:769,y:756,t:1528139698353};\\\", \\\"{x:770,y:756,t:1528139698710};\\\", \\\"{x:771,y:756,t:1528139698766};\\\", \\\"{x:772,y:756,t:1528139698789};\\\", \\\"{x:773,y:756,t:1528139698813};\\\", \\\"{x:773,y:757,t:1528139698845};\\\", \\\"{x:774,y:757,t:1528139698853};\\\", \\\"{x:774,y:758,t:1528139698870};\\\", \\\"{x:775,y:758,t:1528139698886};\\\", \\\"{x:776,y:759,t:1528139698974};\\\", \\\"{x:776,y:760,t:1528139699166};\\\", \\\"{x:776,y:761,t:1528139699174};\\\", \\\"{x:776,y:762,t:1528139699190};\\\", \\\"{x:776,y:763,t:1528139699204};\\\", \\\"{x:776,y:764,t:1528139699221};\\\", \\\"{x:775,y:765,t:1528139699237};\\\", \\\"{x:774,y:765,t:1528139699278};\\\", \\\"{x:781,y:761,t:1528139700591};\\\", \\\"{x:794,y:748,t:1528139700604};\\\", \\\"{x:866,y:703,t:1528139700622};\\\", \\\"{x:920,y:670,t:1528139700638};\\\", \\\"{x:961,y:654,t:1528139700655};\\\", \\\"{x:989,y:639,t:1528139700673};\\\", \\\"{x:1009,y:628,t:1528139700688};\\\", \\\"{x:1021,y:619,t:1528139700705};\\\", \\\"{x:1028,y:615,t:1528139700722};\\\", \\\"{x:1033,y:613,t:1528139700738};\\\", \\\"{x:1040,y:608,t:1528139700755};\\\", \\\"{x:1044,y:604,t:1528139700772};\\\", \\\"{x:1052,y:598,t:1528139700788};\\\", \\\"{x:1060,y:594,t:1528139700805};\\\", \\\"{x:1069,y:589,t:1528139700822};\\\", \\\"{x:1073,y:586,t:1528139700838};\\\", \\\"{x:1075,y:585,t:1528139700855};\\\", \\\"{x:1077,y:585,t:1528139700943};\\\", \\\"{x:1079,y:587,t:1528139700955};\\\", \\\"{x:1082,y:596,t:1528139700972};\\\", \\\"{x:1088,y:605,t:1528139700989};\\\", \\\"{x:1090,y:610,t:1528139701005};\\\", \\\"{x:1095,y:618,t:1528139701022};\\\", \\\"{x:1096,y:622,t:1528139701038};\\\", \\\"{x:1096,y:624,t:1528139701055};\\\", \\\"{x:1096,y:625,t:1528139701110};\\\", \\\"{x:1096,y:627,t:1528139701122};\\\", \\\"{x:1098,y:629,t:1528139701139};\\\", \\\"{x:1098,y:631,t:1528139701155};\\\", \\\"{x:1098,y:632,t:1528139701190};\\\", \\\"{x:1098,y:634,t:1528139701430};\\\", \\\"{x:1098,y:636,t:1528139701446};\\\", \\\"{x:1098,y:637,t:1528139701456};\\\", \\\"{x:1098,y:638,t:1528139701472};\\\", \\\"{x:1099,y:640,t:1528139701489};\\\", \\\"{x:1099,y:641,t:1528139701510};\\\", \\\"{x:1100,y:643,t:1528139701523};\\\", \\\"{x:1100,y:644,t:1528139701539};\\\", \\\"{x:1101,y:647,t:1528139701556};\\\", \\\"{x:1101,y:650,t:1528139701572};\\\", \\\"{x:1102,y:652,t:1528139701589};\\\", \\\"{x:1101,y:652,t:1528139705135};\\\", \\\"{x:1102,y:652,t:1528139705190};\\\", \\\"{x:1103,y:652,t:1528139706118};\\\", \\\"{x:1106,y:653,t:1528139706126};\\\", \\\"{x:1107,y:653,t:1528139706150};\\\", \\\"{x:1108,y:654,t:1528139706166};\\\", \\\"{x:1109,y:654,t:1528139706182};\\\", \\\"{x:1118,y:654,t:1528139706192};\\\", \\\"{x:1149,y:654,t:1528139706209};\\\", \\\"{x:1196,y:650,t:1528139706226};\\\", \\\"{x:1230,y:644,t:1528139706243};\\\", \\\"{x:1262,y:640,t:1528139706258};\\\", \\\"{x:1281,y:639,t:1528139706276};\\\", \\\"{x:1289,y:638,t:1528139706291};\\\", \\\"{x:1291,y:638,t:1528139706309};\\\", \\\"{x:1292,y:638,t:1528139706325};\\\", \\\"{x:1295,y:638,t:1528139706342};\\\", \\\"{x:1300,y:638,t:1528139706359};\\\", \\\"{x:1308,y:634,t:1528139706376};\\\", \\\"{x:1317,y:633,t:1528139706392};\\\", \\\"{x:1326,y:631,t:1528139706408};\\\", \\\"{x:1336,y:630,t:1528139706425};\\\", \\\"{x:1345,y:629,t:1528139706442};\\\", \\\"{x:1349,y:629,t:1528139706459};\\\", \\\"{x:1352,y:629,t:1528139706475};\\\", \\\"{x:1354,y:629,t:1528139706491};\\\", \\\"{x:1355,y:629,t:1528139706509};\\\", \\\"{x:1357,y:630,t:1528139706526};\\\", \\\"{x:1358,y:631,t:1528139706542};\\\", \\\"{x:1358,y:632,t:1528139706559};\\\", \\\"{x:1360,y:633,t:1528139706576};\\\", \\\"{x:1361,y:634,t:1528139706593};\\\", \\\"{x:1361,y:636,t:1528139706609};\\\", \\\"{x:1362,y:639,t:1528139706626};\\\", \\\"{x:1362,y:640,t:1528139706643};\\\", \\\"{x:1362,y:641,t:1528139706659};\\\", \\\"{x:1362,y:642,t:1528139706676};\\\", \\\"{x:1362,y:643,t:1528139706790};\\\", \\\"{x:1362,y:645,t:1528139706797};\\\", \\\"{x:1362,y:647,t:1528139706813};\\\", \\\"{x:1362,y:648,t:1528139706829};\\\", \\\"{x:1363,y:649,t:1528139706843};\\\", \\\"{x:1363,y:651,t:1528139706870};\\\", \\\"{x:1363,y:653,t:1528139707015};\\\", \\\"{x:1364,y:653,t:1528139707462};\\\", \\\"{x:1365,y:654,t:1528139707486};\\\", \\\"{x:1366,y:654,t:1528139707493};\\\", \\\"{x:1366,y:655,t:1528139707510};\\\", \\\"{x:1365,y:655,t:1528139707773};\\\", \\\"{x:1364,y:655,t:1528139707781};\\\", \\\"{x:1363,y:655,t:1528139707805};\\\", \\\"{x:1362,y:655,t:1528139707821};\\\", \\\"{x:1361,y:654,t:1528139707837};\\\", \\\"{x:1360,y:653,t:1528139708150};\\\", \\\"{x:1359,y:653,t:1528139708161};\\\", \\\"{x:1357,y:652,t:1528139708178};\\\", \\\"{x:1355,y:651,t:1528139708198};\\\", \\\"{x:1353,y:651,t:1528139708210};\\\", \\\"{x:1340,y:651,t:1528139708227};\\\", \\\"{x:1322,y:651,t:1528139708245};\\\", \\\"{x:1301,y:651,t:1528139708261};\\\", \\\"{x:1277,y:652,t:1528139708277};\\\", \\\"{x:1247,y:657,t:1528139708293};\\\", \\\"{x:1230,y:659,t:1528139708311};\\\", \\\"{x:1224,y:659,t:1528139708328};\\\", \\\"{x:1223,y:660,t:1528139708344};\\\", \\\"{x:1222,y:661,t:1528139708470};\\\", \\\"{x:1222,y:663,t:1528139708486};\\\", \\\"{x:1223,y:663,t:1528139708494};\\\", \\\"{x:1224,y:663,t:1528139708512};\\\", \\\"{x:1226,y:664,t:1528139708527};\\\", \\\"{x:1226,y:665,t:1528139708622};\\\", \\\"{x:1226,y:666,t:1528139708646};\\\", \\\"{x:1226,y:667,t:1528139708661};\\\", \\\"{x:1225,y:667,t:1528139708677};\\\", \\\"{x:1224,y:668,t:1528139708694};\\\", \\\"{x:1227,y:668,t:1528139708902};\\\", \\\"{x:1231,y:668,t:1528139708912};\\\", \\\"{x:1237,y:668,t:1528139708928};\\\", \\\"{x:1243,y:668,t:1528139708944};\\\", \\\"{x:1247,y:668,t:1528139708962};\\\", \\\"{x:1251,y:669,t:1528139708978};\\\", \\\"{x:1254,y:670,t:1528139708994};\\\", \\\"{x:1255,y:670,t:1528139709022};\\\", \\\"{x:1256,y:671,t:1528139709030};\\\", \\\"{x:1257,y:671,t:1528139709045};\\\", \\\"{x:1258,y:672,t:1528139709061};\\\", \\\"{x:1263,y:672,t:1528139709078};\\\", \\\"{x:1267,y:673,t:1528139709094};\\\", \\\"{x:1275,y:676,t:1528139709111};\\\", \\\"{x:1282,y:677,t:1528139709128};\\\", \\\"{x:1287,y:679,t:1528139709144};\\\", \\\"{x:1292,y:680,t:1528139709161};\\\", \\\"{x:1293,y:680,t:1528139709179};\\\", \\\"{x:1295,y:682,t:1528139709194};\\\", \\\"{x:1297,y:683,t:1528139709211};\\\", \\\"{x:1301,y:684,t:1528139709228};\\\", \\\"{x:1303,y:684,t:1528139709245};\\\", \\\"{x:1305,y:684,t:1528139709261};\\\", \\\"{x:1305,y:685,t:1528139709374};\\\", \\\"{x:1307,y:685,t:1528139709583};\\\", \\\"{x:1308,y:685,t:1528139709595};\\\", \\\"{x:1309,y:685,t:1528139709611};\\\", \\\"{x:1310,y:685,t:1528139709628};\\\", \\\"{x:1312,y:686,t:1528139709646};\\\", \\\"{x:1315,y:687,t:1528139709661};\\\", \\\"{x:1319,y:688,t:1528139709678};\\\", \\\"{x:1320,y:689,t:1528139709695};\\\", \\\"{x:1321,y:689,t:1528139709734};\\\", \\\"{x:1322,y:689,t:1528139709758};\\\", \\\"{x:1325,y:690,t:1528139709766};\\\", \\\"{x:1329,y:690,t:1528139709778};\\\", \\\"{x:1339,y:691,t:1528139709796};\\\", \\\"{x:1353,y:696,t:1528139709814};\\\", \\\"{x:1364,y:696,t:1528139709828};\\\", \\\"{x:1373,y:696,t:1528139709845};\\\", \\\"{x:1377,y:696,t:1528139709861};\\\", \\\"{x:1381,y:696,t:1528139709878};\\\", \\\"{x:1384,y:696,t:1528139709894};\\\", \\\"{x:1390,y:696,t:1528139709912};\\\", \\\"{x:1399,y:694,t:1528139709928};\\\", \\\"{x:1408,y:689,t:1528139709944};\\\", \\\"{x:1418,y:684,t:1528139709962};\\\", \\\"{x:1425,y:684,t:1528139709978};\\\", \\\"{x:1432,y:681,t:1528139709994};\\\", \\\"{x:1433,y:680,t:1528139710012};\\\", \\\"{x:1432,y:680,t:1528139710190};\\\", \\\"{x:1430,y:680,t:1528139710198};\\\", \\\"{x:1429,y:680,t:1528139710212};\\\", \\\"{x:1427,y:680,t:1528139710229};\\\", \\\"{x:1426,y:680,t:1528139710246};\\\", \\\"{x:1425,y:680,t:1528139710262};\\\", \\\"{x:1424,y:680,t:1528139710278};\\\", \\\"{x:1424,y:681,t:1528139710454};\\\", \\\"{x:1424,y:683,t:1528139710470};\\\", \\\"{x:1424,y:684,t:1528139710494};\\\", \\\"{x:1424,y:685,t:1528139710512};\\\", \\\"{x:1426,y:685,t:1528139711990};\\\", \\\"{x:1428,y:685,t:1528139712005};\\\", \\\"{x:1429,y:685,t:1528139712014};\\\", \\\"{x:1430,y:685,t:1528139712030};\\\", \\\"{x:1433,y:686,t:1528139712047};\\\", \\\"{x:1436,y:687,t:1528139712063};\\\", \\\"{x:1439,y:689,t:1528139712081};\\\", \\\"{x:1444,y:691,t:1528139712096};\\\", \\\"{x:1450,y:693,t:1528139712114};\\\", \\\"{x:1455,y:696,t:1528139712130};\\\", \\\"{x:1458,y:697,t:1528139712147};\\\", \\\"{x:1462,y:700,t:1528139712164};\\\", \\\"{x:1468,y:702,t:1528139712180};\\\", \\\"{x:1473,y:705,t:1528139712196};\\\", \\\"{x:1478,y:707,t:1528139712214};\\\", \\\"{x:1478,y:708,t:1528139712231};\\\", \\\"{x:1479,y:708,t:1528139712248};\\\", \\\"{x:1479,y:709,t:1528139712270};\\\", \\\"{x:1480,y:709,t:1528139712281};\\\", \\\"{x:1481,y:710,t:1528139712308};\\\", \\\"{x:1483,y:711,t:1528139712333};\\\", \\\"{x:1485,y:711,t:1528139712357};\\\", \\\"{x:1486,y:711,t:1528139712373};\\\", \\\"{x:1488,y:711,t:1528139712381};\\\", \\\"{x:1492,y:711,t:1528139712397};\\\", \\\"{x:1500,y:711,t:1528139712413};\\\", \\\"{x:1504,y:711,t:1528139712430};\\\", \\\"{x:1507,y:711,t:1528139712447};\\\", \\\"{x:1509,y:711,t:1528139712463};\\\", \\\"{x:1510,y:711,t:1528139712480};\\\", \\\"{x:1514,y:713,t:1528139712497};\\\", \\\"{x:1517,y:713,t:1528139712513};\\\", \\\"{x:1519,y:713,t:1528139712530};\\\", \\\"{x:1521,y:713,t:1528139712547};\\\", \\\"{x:1523,y:713,t:1528139712563};\\\", \\\"{x:1524,y:713,t:1528139712582};\\\", \\\"{x:1525,y:713,t:1528139712669};\\\", \\\"{x:1526,y:713,t:1528139712680};\\\", \\\"{x:1529,y:714,t:1528139712696};\\\", \\\"{x:1530,y:714,t:1528139712714};\\\", \\\"{x:1531,y:714,t:1528139712729};\\\", \\\"{x:1532,y:714,t:1528139712747};\\\", \\\"{x:1533,y:714,t:1528139712781};\\\", \\\"{x:1534,y:715,t:1528139712797};\\\", \\\"{x:1535,y:715,t:1528139712829};\\\", \\\"{x:1536,y:715,t:1528139712847};\\\", \\\"{x:1537,y:716,t:1528139712865};\\\", \\\"{x:1537,y:718,t:1528139713606};\\\", \\\"{x:1537,y:724,t:1528139713614};\\\", \\\"{x:1539,y:740,t:1528139713632};\\\", \\\"{x:1539,y:749,t:1528139713648};\\\", \\\"{x:1539,y:757,t:1528139713664};\\\", \\\"{x:1539,y:764,t:1528139713682};\\\", \\\"{x:1539,y:765,t:1528139713702};\\\", \\\"{x:1539,y:767,t:1528139713798};\\\", \\\"{x:1539,y:768,t:1528139713815};\\\", \\\"{x:1538,y:768,t:1528139713838};\\\", \\\"{x:1537,y:768,t:1528139713886};\\\", \\\"{x:1536,y:768,t:1528139713910};\\\", \\\"{x:1535,y:769,t:1528139713926};\\\", \\\"{x:1534,y:769,t:1528139713974};\\\", \\\"{x:1533,y:770,t:1528139713982};\\\", \\\"{x:1530,y:774,t:1528139713998};\\\", \\\"{x:1526,y:779,t:1528139714015};\\\", \\\"{x:1522,y:784,t:1528139714032};\\\", \\\"{x:1517,y:789,t:1528139714049};\\\", \\\"{x:1513,y:794,t:1528139714065};\\\", \\\"{x:1508,y:800,t:1528139714082};\\\", \\\"{x:1494,y:812,t:1528139714099};\\\", \\\"{x:1492,y:823,t:1528139714114};\\\", \\\"{x:1492,y:824,t:1528139714132};\\\", \\\"{x:1481,y:824,t:1528139714423};\\\", \\\"{x:1465,y:824,t:1528139714433};\\\", \\\"{x:1412,y:824,t:1528139714448};\\\", \\\"{x:1337,y:824,t:1528139714466};\\\", \\\"{x:1248,y:824,t:1528139714482};\\\", \\\"{x:1161,y:823,t:1528139714498};\\\", \\\"{x:1066,y:819,t:1528139714515};\\\", \\\"{x:983,y:810,t:1528139714532};\\\", \\\"{x:937,y:793,t:1528139714548};\\\", \\\"{x:907,y:778,t:1528139714565};\\\", \\\"{x:898,y:769,t:1528139714582};\\\", \\\"{x:892,y:757,t:1528139714599};\\\", \\\"{x:886,y:742,t:1528139714615};\\\", \\\"{x:876,y:729,t:1528139714631};\\\", \\\"{x:862,y:716,t:1528139714648};\\\", \\\"{x:845,y:708,t:1528139714666};\\\", \\\"{x:822,y:700,t:1528139714682};\\\", \\\"{x:794,y:695,t:1528139714698};\\\", \\\"{x:756,y:690,t:1528139714715};\\\", \\\"{x:700,y:684,t:1528139714733};\\\", \\\"{x:653,y:678,t:1528139714748};\\\", \\\"{x:600,y:673,t:1528139714765};\\\", \\\"{x:584,y:671,t:1528139714781};\\\", \\\"{x:579,y:670,t:1528139714798};\\\", \\\"{x:578,y:669,t:1528139714816};\\\", \\\"{x:577,y:668,t:1528139714871};\\\", \\\"{x:576,y:667,t:1528139714893};\\\", \\\"{x:575,y:667,t:1528139714902};\\\", \\\"{x:575,y:665,t:1528139714915};\\\", \\\"{x:579,y:660,t:1528139714933};\\\", \\\"{x:595,y:653,t:1528139714949};\\\", \\\"{x:626,y:642,t:1528139714966};\\\", \\\"{x:650,y:637,t:1528139714982};\\\", \\\"{x:666,y:633,t:1528139714998};\\\", \\\"{x:684,y:628,t:1528139715017};\\\", \\\"{x:699,y:626,t:1528139715032};\\\", \\\"{x:715,y:624,t:1528139715048};\\\", \\\"{x:726,y:624,t:1528139715067};\\\", \\\"{x:741,y:624,t:1528139715082};\\\", \\\"{x:758,y:623,t:1528139715100};\\\", \\\"{x:778,y:621,t:1528139715116};\\\", \\\"{x:801,y:616,t:1528139715133};\\\", \\\"{x:811,y:612,t:1528139715150};\\\", \\\"{x:820,y:608,t:1528139715166};\\\", \\\"{x:821,y:607,t:1528139715182};\\\", \\\"{x:823,y:607,t:1528139715205};\\\", \\\"{x:823,y:606,t:1528139715216};\\\", \\\"{x:826,y:605,t:1528139715233};\\\", \\\"{x:829,y:603,t:1528139715251};\\\", \\\"{x:830,y:602,t:1528139715265};\\\", \\\"{x:830,y:600,t:1528139715358};\\\", \\\"{x:830,y:599,t:1528139715366};\\\", \\\"{x:830,y:593,t:1528139715383};\\\", \\\"{x:830,y:588,t:1528139715400};\\\", \\\"{x:830,y:587,t:1528139715416};\\\", \\\"{x:822,y:586,t:1528139715927};\\\", \\\"{x:807,y:586,t:1528139715934};\\\", \\\"{x:775,y:589,t:1528139715950};\\\", \\\"{x:729,y:591,t:1528139715967};\\\", \\\"{x:682,y:597,t:1528139715985};\\\", \\\"{x:648,y:604,t:1528139716000};\\\", \\\"{x:609,y:609,t:1528139716017};\\\", \\\"{x:573,y:613,t:1528139716035};\\\", \\\"{x:536,y:620,t:1528139716049};\\\", \\\"{x:487,y:631,t:1528139716068};\\\", \\\"{x:447,y:637,t:1528139716084};\\\", \\\"{x:408,y:649,t:1528139716101};\\\", \\\"{x:349,y:667,t:1528139716117};\\\", \\\"{x:320,y:675,t:1528139716134};\\\", \\\"{x:302,y:681,t:1528139716150};\\\", \\\"{x:296,y:683,t:1528139716167};\\\", \\\"{x:298,y:683,t:1528139716301};\\\", \\\"{x:304,y:683,t:1528139716318};\\\", \\\"{x:311,y:681,t:1528139716334};\\\", \\\"{x:315,y:677,t:1528139716350};\\\", \\\"{x:316,y:676,t:1528139716374};\\\", \\\"{x:316,y:675,t:1528139716397};\\\", \\\"{x:316,y:674,t:1528139716422};\\\", \\\"{x:313,y:674,t:1528139716433};\\\", \\\"{x:304,y:672,t:1528139716449};\\\", \\\"{x:286,y:672,t:1528139716467};\\\", \\\"{x:256,y:672,t:1528139716483};\\\", \\\"{x:217,y:672,t:1528139716500};\\\", \\\"{x:175,y:672,t:1528139716517};\\\", \\\"{x:159,y:670,t:1528139716534};\\\", \\\"{x:154,y:667,t:1528139716552};\\\", \\\"{x:153,y:666,t:1528139716566};\\\", \\\"{x:151,y:665,t:1528139716597};\\\", \\\"{x:150,y:664,t:1528139716613};\\\", \\\"{x:149,y:664,t:1528139716629};\\\", \\\"{x:148,y:663,t:1528139716637};\\\", \\\"{x:147,y:663,t:1528139716652};\\\", \\\"{x:146,y:662,t:1528139716666};\\\", \\\"{x:145,y:660,t:1528139716684};\\\", \\\"{x:145,y:658,t:1528139716700};\\\", \\\"{x:148,y:655,t:1528139716717};\\\", \\\"{x:158,y:649,t:1528139716734};\\\", \\\"{x:168,y:645,t:1528139716751};\\\", \\\"{x:179,y:640,t:1528139716767};\\\", \\\"{x:194,y:637,t:1528139716784};\\\", \\\"{x:210,y:633,t:1528139716801};\\\", \\\"{x:230,y:627,t:1528139716818};\\\", \\\"{x:252,y:622,t:1528139716834};\\\", \\\"{x:274,y:615,t:1528139716852};\\\", \\\"{x:298,y:607,t:1528139716868};\\\", \\\"{x:332,y:594,t:1528139716885};\\\", \\\"{x:397,y:567,t:1528139716901};\\\", \\\"{x:427,y:548,t:1528139716918};\\\", \\\"{x:431,y:543,t:1528139716934};\\\", \\\"{x:433,y:542,t:1528139716951};\\\", \\\"{x:435,y:541,t:1528139716967};\\\", \\\"{x:436,y:541,t:1528139716984};\\\", \\\"{x:440,y:541,t:1528139717001};\\\", \\\"{x:442,y:541,t:1528139717017};\\\", \\\"{x:445,y:540,t:1528139717034};\\\", \\\"{x:446,y:539,t:1528139717051};\\\", \\\"{x:447,y:539,t:1528139717067};\\\", \\\"{x:451,y:539,t:1528139717084};\\\", \\\"{x:460,y:539,t:1528139717101};\\\", \\\"{x:471,y:539,t:1528139717117};\\\", \\\"{x:481,y:539,t:1528139717135};\\\", \\\"{x:491,y:539,t:1528139717152};\\\", \\\"{x:503,y:539,t:1528139717169};\\\", \\\"{x:514,y:539,t:1528139717184};\\\", \\\"{x:527,y:539,t:1528139717201};\\\", \\\"{x:538,y:537,t:1528139717218};\\\", \\\"{x:548,y:535,t:1528139717235};\\\", \\\"{x:557,y:534,t:1528139717251};\\\", \\\"{x:566,y:532,t:1528139717268};\\\", \\\"{x:578,y:529,t:1528139717284};\\\", \\\"{x:595,y:525,t:1528139717301};\\\", \\\"{x:609,y:522,t:1528139717318};\\\", \\\"{x:625,y:520,t:1528139717335};\\\", \\\"{x:639,y:520,t:1528139717351};\\\", \\\"{x:647,y:520,t:1528139717368};\\\", \\\"{x:652,y:520,t:1528139717385};\\\", \\\"{x:653,y:520,t:1528139717446};\\\", \\\"{x:655,y:520,t:1528139717502};\\\", \\\"{x:655,y:521,t:1528139717518};\\\", \\\"{x:655,y:523,t:1528139717536};\\\", \\\"{x:655,y:527,t:1528139717552};\\\", \\\"{x:654,y:529,t:1528139717567};\\\", \\\"{x:651,y:534,t:1528139717585};\\\", \\\"{x:649,y:537,t:1528139717600};\\\", \\\"{x:646,y:540,t:1528139717618};\\\", \\\"{x:644,y:543,t:1528139717635};\\\", \\\"{x:644,y:545,t:1528139717652};\\\", \\\"{x:640,y:547,t:1528139717669};\\\", \\\"{x:636,y:553,t:1528139717685};\\\", \\\"{x:632,y:558,t:1528139717703};\\\", \\\"{x:628,y:563,t:1528139717718};\\\", \\\"{x:625,y:566,t:1528139717735};\\\", \\\"{x:623,y:568,t:1528139717752};\\\", \\\"{x:619,y:570,t:1528139717768};\\\", \\\"{x:616,y:572,t:1528139717785};\\\", \\\"{x:615,y:572,t:1528139717813};\\\", \\\"{x:614,y:574,t:1528139718101};\\\", \\\"{x:613,y:580,t:1528139718109};\\\", \\\"{x:610,y:585,t:1528139718118};\\\", \\\"{x:605,y:604,t:1528139718136};\\\", \\\"{x:598,y:624,t:1528139718153};\\\", \\\"{x:589,y:643,t:1528139718170};\\\", \\\"{x:583,y:662,t:1528139718185};\\\", \\\"{x:576,y:682,t:1528139718202};\\\", \\\"{x:571,y:699,t:1528139718219};\\\", \\\"{x:565,y:716,t:1528139718235};\\\", \\\"{x:559,y:731,t:1528139718253};\\\", \\\"{x:551,y:741,t:1528139718269};\\\", \\\"{x:549,y:746,t:1528139718285};\\\", \\\"{x:547,y:747,t:1528139718302};\\\", \\\"{x:546,y:748,t:1528139718319};\\\", \\\"{x:545,y:748,t:1528139718382};\\\", \\\"{x:543,y:748,t:1528139718397};\\\", \\\"{x:540,y:748,t:1528139718405};\\\", \\\"{x:537,y:748,t:1528139718420};\\\", \\\"{x:526,y:748,t:1528139718436};\\\", \\\"{x:519,y:748,t:1528139718453};\\\", \\\"{x:512,y:748,t:1528139718469};\\\", \\\"{x:509,y:747,t:1528139718485};\\\", \\\"{x:507,y:747,t:1528139718510};\\\", \\\"{x:506,y:745,t:1528139718520};\\\", \\\"{x:502,y:742,t:1528139718535};\\\", \\\"{x:500,y:738,t:1528139718553};\\\", \\\"{x:497,y:736,t:1528139718569};\\\", \\\"{x:496,y:733,t:1528139718585};\\\", \\\"{x:495,y:732,t:1528139718603};\\\", \\\"{x:494,y:730,t:1528139718619};\\\", \\\"{x:493,y:728,t:1528139718637};\\\", \\\"{x:493,y:727,t:1528139718653};\\\", \\\"{x:493,y:726,t:1528139718671};\\\", \\\"{x:492,y:725,t:1528139718685};\\\", \\\"{x:492,y:724,t:1528139718709};\\\", \\\"{x:492,y:723,t:1528139718829};\\\", \\\"{x:492,y:724,t:1528139719006};\\\", \\\"{x:495,y:725,t:1528139719020};\\\", \\\"{x:499,y:726,t:1528139719036};\\\", \\\"{x:503,y:728,t:1528139719053};\\\", \\\"{x:509,y:728,t:1528139719069};\\\", \\\"{x:510,y:729,t:1528139719134};\\\", \\\"{x:512,y:732,t:1528139720182};\\\", \\\"{x:515,y:734,t:1528139720190};\\\", \\\"{x:520,y:739,t:1528139720203};\\\", \\\"{x:533,y:747,t:1528139720220};\\\", \\\"{x:562,y:764,t:1528139720237};\\\", \\\"{x:579,y:775,t:1528139720253};\\\", \\\"{x:601,y:785,t:1528139720270};\\\", \\\"{x:622,y:793,t:1528139720287};\\\", \\\"{x:636,y:798,t:1528139720303};\\\", \\\"{x:648,y:804,t:1528139720321};\\\", \\\"{x:655,y:807,t:1528139720337};\\\", \\\"{x:661,y:811,t:1528139720354};\\\", \\\"{x:665,y:813,t:1528139720371};\\\", \\\"{x:666,y:813,t:1528139720387};\\\", \\\"{x:667,y:814,t:1528139720403};\\\", \\\"{x:668,y:814,t:1528139720421};\\\", \\\"{x:670,y:815,t:1528139720445};\\\", \\\"{x:671,y:815,t:1528139720461};\\\", \\\"{x:672,y:816,t:1528139720470};\\\", \\\"{x:673,y:816,t:1528139720487};\\\", \\\"{x:674,y:816,t:1528139720509};\\\", \\\"{x:675,y:816,t:1528139720684};\\\" ] }, { \\\"rt\\\": 50725, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 12, \\\"time_elapsed\\\": 515556, \\\"internal_node_id\\\": \\\"0.0-6.0-2.0\\\", \\\"subject\\\": \\\"JYGX2\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"yankee\\\", \\\"condition\\\": \\\"311\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"duration+contained\\\", \\\"q\\\": 8, \\\"clicks\\\": 1, \\\"explicit\\\": 3, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XInside-YFull\\\", \\\"correct\\\": 1, \\\"orth_correct\\\": 0, \\\"answer\\\": [ \\\"G\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-B -B -B -G -G -F -I -J -J -F -E -G -G -C \\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:677,y:816,t:1528139720865};\\\", \\\"{x:678,y:816,t:1528139721003};\\\", \\\"{x:678,y:819,t:1528139721125};\\\", \\\"{x:682,y:819,t:1528139721437};\\\", \\\"{x:685,y:819,t:1528139721445};\\\", \\\"{x:691,y:819,t:1528139721454};\\\", \\\"{x:703,y:814,t:1528139721471};\\\", \\\"{x:716,y:811,t:1528139721488};\\\", \\\"{x:730,y:804,t:1528139721504};\\\", \\\"{x:742,y:799,t:1528139721522};\\\", \\\"{x:758,y:793,t:1528139721539};\\\", \\\"{x:771,y:787,t:1528139721554};\\\", \\\"{x:783,y:782,t:1528139721571};\\\", \\\"{x:790,y:779,t:1528139721588};\\\", \\\"{x:793,y:778,t:1528139721604};\\\", \\\"{x:794,y:778,t:1528139721621};\\\", \\\"{x:795,y:777,t:1528139721694};\\\", \\\"{x:796,y:777,t:1528139721708};\\\", \\\"{x:797,y:777,t:1528139721765};\\\", \\\"{x:798,y:776,t:1528139721780};\\\", \\\"{x:799,y:776,t:1528139721804};\\\", \\\"{x:800,y:776,t:1528139721829};\\\", \\\"{x:802,y:776,t:1528139722286};\\\", \\\"{x:803,y:776,t:1528139722342};\\\", \\\"{x:805,y:776,t:1528139722437};\\\", \\\"{x:806,y:777,t:1528139722462};\\\", \\\"{x:807,y:778,t:1528139722477};\\\", \\\"{x:808,y:779,t:1528139722489};\\\", \\\"{x:811,y:781,t:1528139722505};\\\", \\\"{x:812,y:782,t:1528139722523};\\\", \\\"{x:817,y:785,t:1528139722538};\\\", \\\"{x:818,y:786,t:1528139722556};\\\", \\\"{x:820,y:788,t:1528139722572};\\\", \\\"{x:822,y:788,t:1528139722589};\\\", \\\"{x:825,y:791,t:1528139722606};\\\", \\\"{x:826,y:792,t:1528139722622};\\\", \\\"{x:828,y:794,t:1528139722638};\\\", \\\"{x:829,y:794,t:1528139722749};\\\", \\\"{x:830,y:794,t:1528139722764};\\\", \\\"{x:831,y:794,t:1528139722780};\\\", \\\"{x:831,y:795,t:1528139722789};\\\", \\\"{x:833,y:797,t:1528139722805};\\\", \\\"{x:834,y:798,t:1528139722822};\\\", \\\"{x:835,y:798,t:1528139722839};\\\", \\\"{x:836,y:799,t:1528139722855};\\\", \\\"{x:837,y:800,t:1528139722872};\\\", \\\"{x:838,y:800,t:1528139722889};\\\", \\\"{x:839,y:801,t:1528139722908};\\\", \\\"{x:840,y:802,t:1528139722924};\\\", \\\"{x:840,y:803,t:1528139722948};\\\", \\\"{x:842,y:804,t:1528139722965};\\\", \\\"{x:843,y:805,t:1528139723029};\\\", \\\"{x:844,y:805,t:1528139723069};\\\", \\\"{x:845,y:805,t:1528139723134};\\\", \\\"{x:846,y:805,t:1528139723206};\\\", \\\"{x:846,y:806,t:1528139723222};\\\", \\\"{x:847,y:807,t:1528139723240};\\\", \\\"{x:848,y:808,t:1528139723257};\\\", \\\"{x:849,y:809,t:1528139723272};\\\", \\\"{x:850,y:810,t:1528139723302};\\\", \\\"{x:851,y:810,t:1528139724062};\\\", \\\"{x:852,y:810,t:1528139724073};\\\", \\\"{x:855,y:810,t:1528139724089};\\\", \\\"{x:856,y:810,t:1528139724106};\\\", \\\"{x:857,y:810,t:1528139724150};\\\", \\\"{x:858,y:810,t:1528139724342};\\\", \\\"{x:860,y:810,t:1528139724374};\\\", \\\"{x:861,y:810,t:1528139724391};\\\", \\\"{x:862,y:810,t:1528139724454};\\\", \\\"{x:862,y:811,t:1528139724469};\\\", \\\"{x:863,y:812,t:1528139725518};\\\", \\\"{x:864,y:812,t:1528139725534};\\\", \\\"{x:865,y:812,t:1528139725549};\\\", \\\"{x:866,y:812,t:1528139725557};\\\", \\\"{x:867,y:813,t:1528139725582};\\\", \\\"{x:868,y:813,t:1528139727038};\\\", \\\"{x:868,y:812,t:1528139727078};\\\", \\\"{x:868,y:811,t:1528139727101};\\\", \\\"{x:868,y:810,t:1528139727285};\\\", \\\"{x:868,y:809,t:1528139727302};\\\", \\\"{x:868,y:808,t:1528139727317};\\\", \\\"{x:868,y:807,t:1528139727326};\\\", \\\"{x:868,y:806,t:1528139727414};\\\", \\\"{x:868,y:804,t:1528139727429};\\\", \\\"{x:868,y:803,t:1528139727442};\\\", \\\"{x:868,y:801,t:1528139727459};\\\", \\\"{x:870,y:799,t:1528139727476};\\\", \\\"{x:871,y:797,t:1528139727493};\\\", \\\"{x:871,y:796,t:1528139727509};\\\", \\\"{x:875,y:791,t:1528139727526};\\\", \\\"{x:879,y:787,t:1528139727543};\\\", \\\"{x:886,y:783,t:1528139727560};\\\", \\\"{x:896,y:777,t:1528139727576};\\\", \\\"{x:909,y:772,t:1528139727593};\\\", \\\"{x:925,y:765,t:1528139727611};\\\", \\\"{x:941,y:759,t:1528139727626};\\\", \\\"{x:958,y:754,t:1528139727643};\\\", \\\"{x:975,y:746,t:1528139727660};\\\", \\\"{x:995,y:741,t:1528139727676};\\\", \\\"{x:1011,y:739,t:1528139727693};\\\", \\\"{x:1024,y:736,t:1528139727710};\\\", \\\"{x:1029,y:736,t:1528139727726};\\\", \\\"{x:1033,y:735,t:1528139727743};\\\", \\\"{x:1035,y:735,t:1528139727761};\\\", \\\"{x:1037,y:735,t:1528139728093};\\\", \\\"{x:1048,y:734,t:1528139728109};\\\", \\\"{x:1059,y:731,t:1528139728127};\\\", \\\"{x:1087,y:725,t:1528139728142};\\\", \\\"{x:1125,y:718,t:1528139728159};\\\", \\\"{x:1174,y:708,t:1528139728177};\\\", \\\"{x:1219,y:695,t:1528139728193};\\\", \\\"{x:1261,y:682,t:1528139728210};\\\", \\\"{x:1293,y:672,t:1528139728227};\\\", \\\"{x:1321,y:661,t:1528139728244};\\\", \\\"{x:1340,y:652,t:1528139728260};\\\", \\\"{x:1358,y:646,t:1528139728277};\\\", \\\"{x:1371,y:640,t:1528139728293};\\\", \\\"{x:1391,y:630,t:1528139728310};\\\", \\\"{x:1402,y:624,t:1528139728327};\\\", \\\"{x:1412,y:616,t:1528139728343};\\\", \\\"{x:1417,y:612,t:1528139728360};\\\", \\\"{x:1421,y:611,t:1528139728377};\\\", \\\"{x:1423,y:608,t:1528139728393};\\\", \\\"{x:1425,y:607,t:1528139728412};\\\", \\\"{x:1425,y:606,t:1528139728427};\\\", \\\"{x:1426,y:605,t:1528139728443};\\\", \\\"{x:1428,y:604,t:1528139728470};\\\", \\\"{x:1428,y:603,t:1528139728486};\\\", \\\"{x:1427,y:602,t:1528139728814};\\\", \\\"{x:1422,y:602,t:1528139728827};\\\", \\\"{x:1413,y:603,t:1528139728844};\\\", \\\"{x:1408,y:604,t:1528139728860};\\\", \\\"{x:1401,y:604,t:1528139728877};\\\", \\\"{x:1398,y:604,t:1528139728893};\\\", \\\"{x:1390,y:604,t:1528139728910};\\\", \\\"{x:1379,y:604,t:1528139728927};\\\", \\\"{x:1360,y:604,t:1528139728944};\\\", \\\"{x:1340,y:606,t:1528139728960};\\\", \\\"{x:1316,y:607,t:1528139728977};\\\", \\\"{x:1293,y:607,t:1528139728994};\\\", \\\"{x:1270,y:606,t:1528139729012};\\\", \\\"{x:1254,y:599,t:1528139729027};\\\", \\\"{x:1237,y:595,t:1528139729045};\\\", \\\"{x:1215,y:586,t:1528139729062};\\\", \\\"{x:1201,y:579,t:1528139729078};\\\", \\\"{x:1188,y:570,t:1528139729094};\\\", \\\"{x:1172,y:563,t:1528139729112};\\\", \\\"{x:1159,y:555,t:1528139729128};\\\", \\\"{x:1151,y:549,t:1528139729144};\\\", \\\"{x:1144,y:545,t:1528139729162};\\\", \\\"{x:1143,y:544,t:1528139729177};\\\", \\\"{x:1142,y:543,t:1528139729194};\\\", \\\"{x:1141,y:542,t:1528139729214};\\\", \\\"{x:1141,y:540,t:1528139729237};\\\", \\\"{x:1141,y:539,t:1528139729246};\\\", \\\"{x:1143,y:537,t:1528139729261};\\\", \\\"{x:1157,y:530,t:1528139729277};\\\", \\\"{x:1169,y:528,t:1528139729293};\\\", \\\"{x:1180,y:524,t:1528139729311};\\\", \\\"{x:1189,y:522,t:1528139729326};\\\", \\\"{x:1193,y:521,t:1528139729344};\\\", \\\"{x:1195,y:520,t:1528139729360};\\\", \\\"{x:1197,y:518,t:1528139729377};\\\", \\\"{x:1199,y:516,t:1528139729393};\\\", \\\"{x:1203,y:514,t:1528139729410};\\\", \\\"{x:1213,y:509,t:1528139729427};\\\", \\\"{x:1223,y:504,t:1528139729443};\\\", \\\"{x:1238,y:499,t:1528139729461};\\\", \\\"{x:1259,y:493,t:1528139729476};\\\", \\\"{x:1280,y:489,t:1528139729494};\\\", \\\"{x:1297,y:487,t:1528139729510};\\\", \\\"{x:1310,y:486,t:1528139729528};\\\", \\\"{x:1324,y:484,t:1528139729544};\\\", \\\"{x:1330,y:483,t:1528139729561};\\\", \\\"{x:1335,y:483,t:1528139729578};\\\", \\\"{x:1337,y:483,t:1528139729595};\\\", \\\"{x:1341,y:484,t:1528139729611};\\\", \\\"{x:1349,y:488,t:1528139729629};\\\", \\\"{x:1357,y:495,t:1528139729644};\\\", \\\"{x:1372,y:508,t:1528139729661};\\\", \\\"{x:1379,y:513,t:1528139729678};\\\", \\\"{x:1383,y:517,t:1528139729694};\\\", \\\"{x:1384,y:519,t:1528139729711};\\\", \\\"{x:1385,y:520,t:1528139729728};\\\", \\\"{x:1387,y:522,t:1528139729744};\\\", \\\"{x:1388,y:522,t:1528139729761};\\\", \\\"{x:1388,y:523,t:1528139729878};\\\", \\\"{x:1383,y:523,t:1528139729894};\\\", \\\"{x:1377,y:523,t:1528139729911};\\\", \\\"{x:1375,y:523,t:1528139729928};\\\", \\\"{x:1373,y:523,t:1528139729945};\\\", \\\"{x:1371,y:523,t:1528139730757};\\\", \\\"{x:1370,y:523,t:1528139730862};\\\", \\\"{x:1368,y:523,t:1528139731094};\\\", \\\"{x:1363,y:525,t:1528139731112};\\\", \\\"{x:1355,y:526,t:1528139731128};\\\", \\\"{x:1345,y:527,t:1528139731145};\\\", \\\"{x:1337,y:527,t:1528139731162};\\\", \\\"{x:1332,y:527,t:1528139731179};\\\", \\\"{x:1330,y:527,t:1528139731195};\\\", \\\"{x:1329,y:527,t:1528139731213};\\\", \\\"{x:1327,y:527,t:1528139731261};\\\", \\\"{x:1324,y:528,t:1528139731280};\\\", \\\"{x:1321,y:530,t:1528139731295};\\\", \\\"{x:1318,y:533,t:1528139731312};\\\", \\\"{x:1316,y:534,t:1528139731328};\\\", \\\"{x:1315,y:534,t:1528139731346};\\\", \\\"{x:1313,y:535,t:1528139731362};\\\", \\\"{x:1313,y:536,t:1528139731421};\\\", \\\"{x:1316,y:541,t:1528139732702};\\\", \\\"{x:1323,y:556,t:1528139732713};\\\", \\\"{x:1337,y:587,t:1528139732731};\\\", \\\"{x:1348,y:636,t:1528139732747};\\\", \\\"{x:1363,y:686,t:1528139732763};\\\", \\\"{x:1374,y:728,t:1528139732780};\\\", \\\"{x:1376,y:751,t:1528139732796};\\\", \\\"{x:1377,y:773,t:1528139732814};\\\", \\\"{x:1377,y:780,t:1528139732830};\\\", \\\"{x:1377,y:781,t:1528139732847};\\\", \\\"{x:1376,y:781,t:1528139732926};\\\", \\\"{x:1376,y:779,t:1528139732934};\\\", \\\"{x:1375,y:778,t:1528139732947};\\\", \\\"{x:1372,y:772,t:1528139732963};\\\", \\\"{x:1368,y:766,t:1528139732981};\\\", \\\"{x:1361,y:754,t:1528139732997};\\\", \\\"{x:1357,y:749,t:1528139733013};\\\", \\\"{x:1355,y:749,t:1528139733030};\\\", \\\"{x:1352,y:748,t:1528139733046};\\\", \\\"{x:1351,y:748,t:1528139733063};\\\", \\\"{x:1350,y:748,t:1528139733109};\\\", \\\"{x:1349,y:749,t:1528139733116};\\\", \\\"{x:1349,y:750,t:1528139733130};\\\", \\\"{x:1348,y:756,t:1528139733146};\\\", \\\"{x:1348,y:761,t:1528139733164};\\\", \\\"{x:1347,y:764,t:1528139733180};\\\", \\\"{x:1345,y:768,t:1528139733196};\\\", \\\"{x:1344,y:770,t:1528139733222};\\\", \\\"{x:1346,y:770,t:1528139733422};\\\", \\\"{x:1347,y:770,t:1528139733461};\\\", \\\"{x:1348,y:770,t:1528139733614};\\\", \\\"{x:1347,y:772,t:1528139733631};\\\", \\\"{x:1345,y:772,t:1528139733647};\\\", \\\"{x:1345,y:773,t:1528139734190};\\\", \\\"{x:1345,y:774,t:1528139734197};\\\", \\\"{x:1345,y:777,t:1528139734215};\\\", \\\"{x:1344,y:782,t:1528139734231};\\\", \\\"{x:1344,y:787,t:1528139734248};\\\", \\\"{x:1343,y:794,t:1528139734264};\\\", \\\"{x:1340,y:802,t:1528139734281};\\\", \\\"{x:1340,y:811,t:1528139734298};\\\", \\\"{x:1336,y:821,t:1528139734314};\\\", \\\"{x:1335,y:828,t:1528139734332};\\\", \\\"{x:1332,y:840,t:1528139734349};\\\", \\\"{x:1327,y:853,t:1528139734364};\\\", \\\"{x:1316,y:874,t:1528139734382};\\\", \\\"{x:1309,y:889,t:1528139734398};\\\", \\\"{x:1297,y:908,t:1528139734415};\\\", \\\"{x:1286,y:922,t:1528139734431};\\\", \\\"{x:1276,y:934,t:1528139734449};\\\", \\\"{x:1269,y:944,t:1528139734464};\\\", \\\"{x:1266,y:948,t:1528139734482};\\\", \\\"{x:1265,y:949,t:1528139734498};\\\", \\\"{x:1265,y:950,t:1528139734514};\\\", \\\"{x:1264,y:950,t:1528139734574};\\\", \\\"{x:1263,y:950,t:1528139734702};\\\", \\\"{x:1261,y:951,t:1528139734715};\\\", \\\"{x:1260,y:953,t:1528139734731};\\\", \\\"{x:1257,y:956,t:1528139734747};\\\", \\\"{x:1255,y:959,t:1528139734764};\\\", \\\"{x:1253,y:960,t:1528139734780};\\\", \\\"{x:1253,y:961,t:1528139734798};\\\", \\\"{x:1252,y:961,t:1528139734815};\\\", \\\"{x:1252,y:963,t:1528139734831};\\\", \\\"{x:1251,y:963,t:1528139734848};\\\", \\\"{x:1251,y:964,t:1528139734917};\\\", \\\"{x:1250,y:964,t:1528139735671};\\\", \\\"{x:1249,y:964,t:1528139735695};\\\", \\\"{x:1249,y:965,t:1528139735708};\\\", \\\"{x:1248,y:966,t:1528139735733};\\\", \\\"{x:1248,y:967,t:1528139735765};\\\", \\\"{x:1245,y:968,t:1528139736320};\\\", \\\"{x:1243,y:968,t:1528139736327};\\\", \\\"{x:1240,y:968,t:1528139736341};\\\", \\\"{x:1238,y:968,t:1528139736358};\\\", \\\"{x:1238,y:967,t:1528139736415};\\\", \\\"{x:1238,y:966,t:1528139736425};\\\", \\\"{x:1238,y:960,t:1528139736441};\\\", \\\"{x:1238,y:947,t:1528139736459};\\\", \\\"{x:1242,y:928,t:1528139736475};\\\", \\\"{x:1251,y:900,t:1528139736491};\\\", \\\"{x:1257,y:876,t:1528139736508};\\\", \\\"{x:1263,y:852,t:1528139736525};\\\", \\\"{x:1270,y:815,t:1528139736542};\\\", \\\"{x:1274,y:793,t:1528139736558};\\\", \\\"{x:1280,y:776,t:1528139736576};\\\", \\\"{x:1285,y:761,t:1528139736591};\\\", \\\"{x:1290,y:751,t:1528139736608};\\\", \\\"{x:1293,y:743,t:1528139736625};\\\", \\\"{x:1299,y:730,t:1528139736642};\\\", \\\"{x:1306,y:718,t:1528139736658};\\\", \\\"{x:1312,y:707,t:1528139736676};\\\", \\\"{x:1321,y:691,t:1528139736692};\\\", \\\"{x:1330,y:678,t:1528139736708};\\\", \\\"{x:1341,y:664,t:1528139736726};\\\", \\\"{x:1351,y:650,t:1528139736743};\\\", \\\"{x:1359,y:642,t:1528139736759};\\\", \\\"{x:1365,y:633,t:1528139736776};\\\", \\\"{x:1368,y:629,t:1528139736792};\\\", \\\"{x:1370,y:624,t:1528139736809};\\\", \\\"{x:1373,y:620,t:1528139736826};\\\", \\\"{x:1378,y:611,t:1528139736842};\\\", \\\"{x:1383,y:602,t:1528139736858};\\\", \\\"{x:1389,y:595,t:1528139736875};\\\", \\\"{x:1391,y:592,t:1528139736893};\\\", \\\"{x:1392,y:589,t:1528139736909};\\\", \\\"{x:1394,y:588,t:1528139736926};\\\", \\\"{x:1395,y:586,t:1528139736943};\\\", \\\"{x:1397,y:585,t:1528139736958};\\\", \\\"{x:1399,y:584,t:1528139737039};\\\", \\\"{x:1399,y:583,t:1528139737047};\\\", \\\"{x:1401,y:582,t:1528139737063};\\\", \\\"{x:1403,y:581,t:1528139737076};\\\", \\\"{x:1406,y:579,t:1528139737093};\\\", \\\"{x:1408,y:578,t:1528139737110};\\\", \\\"{x:1411,y:577,t:1528139737126};\\\", \\\"{x:1414,y:576,t:1528139737143};\\\", \\\"{x:1417,y:575,t:1528139737160};\\\", \\\"{x:1418,y:575,t:1528139737176};\\\", \\\"{x:1420,y:573,t:1528139737193};\\\", \\\"{x:1422,y:571,t:1528139737210};\\\", \\\"{x:1425,y:567,t:1528139737226};\\\", \\\"{x:1428,y:564,t:1528139737243};\\\", \\\"{x:1432,y:559,t:1528139737260};\\\", \\\"{x:1435,y:554,t:1528139737276};\\\", \\\"{x:1436,y:552,t:1528139737293};\\\", \\\"{x:1438,y:551,t:1528139737309};\\\", \\\"{x:1438,y:550,t:1528139737326};\\\", \\\"{x:1438,y:549,t:1528139737342};\\\", \\\"{x:1439,y:549,t:1528139737383};\\\", \\\"{x:1439,y:546,t:1528139737496};\\\", \\\"{x:1439,y:542,t:1528139737510};\\\", \\\"{x:1442,y:525,t:1528139737526};\\\", \\\"{x:1449,y:510,t:1528139737543};\\\", \\\"{x:1453,y:503,t:1528139737560};\\\", \\\"{x:1454,y:499,t:1528139737576};\\\", \\\"{x:1454,y:498,t:1528139737593};\\\", \\\"{x:1455,y:498,t:1528139737615};\\\", \\\"{x:1455,y:500,t:1528139737734};\\\", \\\"{x:1455,y:503,t:1528139737742};\\\", \\\"{x:1454,y:510,t:1528139737759};\\\", \\\"{x:1451,y:515,t:1528139737776};\\\", \\\"{x:1450,y:519,t:1528139737793};\\\", \\\"{x:1450,y:521,t:1528139737810};\\\", \\\"{x:1449,y:524,t:1528139737827};\\\", \\\"{x:1448,y:525,t:1528139737843};\\\", \\\"{x:1448,y:526,t:1528139737860};\\\", \\\"{x:1448,y:527,t:1528139737876};\\\", \\\"{x:1447,y:529,t:1528139737895};\\\", \\\"{x:1447,y:530,t:1528139737918};\\\", \\\"{x:1446,y:532,t:1528139737934};\\\", \\\"{x:1445,y:533,t:1528139737943};\\\", \\\"{x:1442,y:536,t:1528139737959};\\\", \\\"{x:1440,y:539,t:1528139737976};\\\", \\\"{x:1438,y:542,t:1528139737993};\\\", \\\"{x:1438,y:545,t:1528139738009};\\\", \\\"{x:1436,y:548,t:1528139738026};\\\", \\\"{x:1435,y:550,t:1528139738043};\\\", \\\"{x:1435,y:551,t:1528139738062};\\\", \\\"{x:1434,y:551,t:1528139738078};\\\", \\\"{x:1434,y:552,t:1528139738094};\\\", \\\"{x:1434,y:553,t:1528139738125};\\\", \\\"{x:1434,y:554,t:1528139738143};\\\", \\\"{x:1434,y:555,t:1528139738166};\\\", \\\"{x:1434,y:556,t:1528139738176};\\\", \\\"{x:1433,y:557,t:1528139738194};\\\", \\\"{x:1433,y:558,t:1528139738230};\\\", \\\"{x:1433,y:559,t:1528139738311};\\\", \\\"{x:1431,y:559,t:1528139738327};\\\", \\\"{x:1430,y:561,t:1528139738344};\\\", \\\"{x:1428,y:565,t:1528139738360};\\\", \\\"{x:1427,y:567,t:1528139738376};\\\", \\\"{x:1426,y:568,t:1528139738394};\\\", \\\"{x:1425,y:569,t:1528139738409};\\\", \\\"{x:1424,y:570,t:1528139738426};\\\", \\\"{x:1424,y:571,t:1528139738443};\\\", \\\"{x:1424,y:572,t:1528139738478};\\\", \\\"{x:1423,y:574,t:1528139738503};\\\", \\\"{x:1422,y:574,t:1528139738510};\\\", \\\"{x:1422,y:575,t:1528139738615};\\\", \\\"{x:1421,y:576,t:1528139738647};\\\", \\\"{x:1420,y:578,t:1528139738661};\\\", \\\"{x:1418,y:582,t:1528139738677};\\\", \\\"{x:1417,y:586,t:1528139738694};\\\", \\\"{x:1414,y:591,t:1528139738710};\\\", \\\"{x:1413,y:593,t:1528139738727};\\\", \\\"{x:1412,y:595,t:1528139738743};\\\", \\\"{x:1411,y:596,t:1528139738760};\\\", \\\"{x:1411,y:598,t:1528139738777};\\\", \\\"{x:1410,y:600,t:1528139738798};\\\", \\\"{x:1410,y:601,t:1528139738814};\\\", \\\"{x:1409,y:602,t:1528139738826};\\\", \\\"{x:1408,y:602,t:1528139738943};\\\", \\\"{x:1408,y:595,t:1528139738961};\\\", \\\"{x:1414,y:579,t:1528139738977};\\\", \\\"{x:1423,y:560,t:1528139738994};\\\", \\\"{x:1431,y:544,t:1528139739011};\\\", \\\"{x:1437,y:534,t:1528139739028};\\\", \\\"{x:1441,y:528,t:1528139739044};\\\", \\\"{x:1442,y:526,t:1528139739061};\\\", \\\"{x:1443,y:524,t:1528139739078};\\\", \\\"{x:1444,y:522,t:1528139739094};\\\", \\\"{x:1445,y:519,t:1528139739111};\\\", \\\"{x:1447,y:517,t:1528139739128};\\\", \\\"{x:1448,y:515,t:1528139739144};\\\", \\\"{x:1450,y:513,t:1528139739161};\\\", \\\"{x:1454,y:509,t:1528139739178};\\\", \\\"{x:1458,y:503,t:1528139739194};\\\", \\\"{x:1462,y:498,t:1528139739211};\\\", \\\"{x:1468,y:490,t:1528139739228};\\\", \\\"{x:1472,y:484,t:1528139739244};\\\", \\\"{x:1473,y:480,t:1528139739261};\\\", \\\"{x:1474,y:479,t:1528139739278};\\\", \\\"{x:1475,y:478,t:1528139739294};\\\", \\\"{x:1474,y:484,t:1528139739383};\\\", \\\"{x:1473,y:491,t:1528139739394};\\\", \\\"{x:1465,y:505,t:1528139739411};\\\", \\\"{x:1459,y:520,t:1528139739428};\\\", \\\"{x:1453,y:528,t:1528139739445};\\\", \\\"{x:1450,y:534,t:1528139739460};\\\", \\\"{x:1448,y:538,t:1528139739478};\\\", \\\"{x:1442,y:550,t:1528139739495};\\\", \\\"{x:1440,y:555,t:1528139739511};\\\", \\\"{x:1436,y:562,t:1528139739528};\\\", \\\"{x:1432,y:568,t:1528139739545};\\\", \\\"{x:1428,y:574,t:1528139739561};\\\", \\\"{x:1426,y:577,t:1528139739578};\\\", \\\"{x:1425,y:578,t:1528139739595};\\\", \\\"{x:1425,y:579,t:1528139739614};\\\", \\\"{x:1425,y:580,t:1528139739628};\\\", \\\"{x:1424,y:581,t:1528139739645};\\\", \\\"{x:1423,y:582,t:1528139739660};\\\", \\\"{x:1422,y:585,t:1528139739678};\\\", \\\"{x:1419,y:592,t:1528139739695};\\\", \\\"{x:1418,y:595,t:1528139739710};\\\", \\\"{x:1415,y:600,t:1528139739728};\\\", \\\"{x:1413,y:607,t:1528139739745};\\\", \\\"{x:1411,y:613,t:1528139739761};\\\", \\\"{x:1407,y:620,t:1528139739778};\\\", \\\"{x:1404,y:629,t:1528139739795};\\\", \\\"{x:1400,y:638,t:1528139739811};\\\", \\\"{x:1395,y:648,t:1528139739828};\\\", \\\"{x:1392,y:652,t:1528139739844};\\\", \\\"{x:1390,y:656,t:1528139739860};\\\", \\\"{x:1388,y:659,t:1528139739878};\\\", \\\"{x:1385,y:665,t:1528139739893};\\\", \\\"{x:1383,y:668,t:1528139739911};\\\", \\\"{x:1380,y:672,t:1528139739927};\\\", \\\"{x:1378,y:674,t:1528139739944};\\\", \\\"{x:1376,y:677,t:1528139739961};\\\", \\\"{x:1375,y:679,t:1528139739977};\\\", \\\"{x:1372,y:683,t:1528139739994};\\\", \\\"{x:1371,y:686,t:1528139740012};\\\", \\\"{x:1367,y:691,t:1528139740027};\\\", \\\"{x:1362,y:697,t:1528139740045};\\\", \\\"{x:1359,y:703,t:1528139740062};\\\", \\\"{x:1356,y:710,t:1528139740078};\\\", \\\"{x:1355,y:713,t:1528139740095};\\\", \\\"{x:1354,y:716,t:1528139740112};\\\", \\\"{x:1353,y:718,t:1528139740128};\\\", \\\"{x:1353,y:721,t:1528139740144};\\\", \\\"{x:1352,y:725,t:1528139740162};\\\", \\\"{x:1351,y:729,t:1528139740178};\\\", \\\"{x:1349,y:732,t:1528139740194};\\\", \\\"{x:1348,y:736,t:1528139740212};\\\", \\\"{x:1348,y:737,t:1528139740228};\\\", \\\"{x:1347,y:740,t:1528139740244};\\\", \\\"{x:1346,y:740,t:1528139740262};\\\", \\\"{x:1346,y:741,t:1528139740278};\\\", \\\"{x:1346,y:742,t:1528139740360};\\\", \\\"{x:1345,y:743,t:1528139740375};\\\", \\\"{x:1345,y:745,t:1528139740391};\\\", \\\"{x:1344,y:746,t:1528139740399};\\\", \\\"{x:1343,y:747,t:1528139740412};\\\", \\\"{x:1343,y:748,t:1528139740430};\\\", \\\"{x:1342,y:748,t:1528139740445};\\\", \\\"{x:1342,y:749,t:1528139740487};\\\", \\\"{x:1342,y:750,t:1528139740495};\\\", \\\"{x:1342,y:752,t:1528139740512};\\\", \\\"{x:1339,y:754,t:1528139740529};\\\", \\\"{x:1338,y:760,t:1528139740545};\\\", \\\"{x:1337,y:762,t:1528139740562};\\\", \\\"{x:1334,y:765,t:1528139740579};\\\", \\\"{x:1331,y:769,t:1528139740595};\\\", \\\"{x:1330,y:771,t:1528139740612};\\\", \\\"{x:1328,y:775,t:1528139740628};\\\", \\\"{x:1327,y:776,t:1528139740645};\\\", \\\"{x:1327,y:777,t:1528139740662};\\\", \\\"{x:1326,y:777,t:1528139740679};\\\", \\\"{x:1325,y:778,t:1528139740694};\\\", \\\"{x:1324,y:778,t:1528139740846};\\\", \\\"{x:1324,y:774,t:1528139740861};\\\", \\\"{x:1335,y:750,t:1528139740878};\\\", \\\"{x:1346,y:733,t:1528139740896};\\\", \\\"{x:1356,y:720,t:1528139740912};\\\", \\\"{x:1362,y:713,t:1528139740929};\\\", \\\"{x:1366,y:706,t:1528139740946};\\\", \\\"{x:1367,y:704,t:1528139740962};\\\", \\\"{x:1369,y:702,t:1528139740979};\\\", \\\"{x:1369,y:701,t:1528139740999};\\\", \\\"{x:1370,y:701,t:1528139741012};\\\", \\\"{x:1370,y:700,t:1528139741030};\\\", \\\"{x:1370,y:698,t:1528139741046};\\\", \\\"{x:1371,y:697,t:1528139741063};\\\", \\\"{x:1371,y:698,t:1528139741191};\\\", \\\"{x:1371,y:700,t:1528139741198};\\\", \\\"{x:1371,y:703,t:1528139741212};\\\", \\\"{x:1371,y:708,t:1528139741229};\\\", \\\"{x:1371,y:710,t:1528139741247};\\\", \\\"{x:1371,y:712,t:1528139741262};\\\", \\\"{x:1370,y:715,t:1528139741279};\\\", \\\"{x:1369,y:715,t:1528139741455};\\\", \\\"{x:1369,y:717,t:1528139741463};\\\", \\\"{x:1367,y:720,t:1528139741479};\\\", \\\"{x:1366,y:722,t:1528139741496};\\\", \\\"{x:1364,y:725,t:1528139741513};\\\", \\\"{x:1363,y:726,t:1528139741529};\\\", \\\"{x:1362,y:727,t:1528139741546};\\\", \\\"{x:1362,y:728,t:1528139741563};\\\", \\\"{x:1361,y:729,t:1528139741579};\\\", \\\"{x:1358,y:731,t:1528139741596};\\\", \\\"{x:1357,y:732,t:1528139741613};\\\", \\\"{x:1356,y:733,t:1528139741629};\\\", \\\"{x:1354,y:733,t:1528139741646};\\\", \\\"{x:1353,y:733,t:1528139741783};\\\", \\\"{x:1354,y:734,t:1528139746471};\\\", \\\"{x:1358,y:736,t:1528139746484};\\\", \\\"{x:1378,y:746,t:1528139746499};\\\", \\\"{x:1408,y:754,t:1528139746516};\\\", \\\"{x:1443,y:766,t:1528139746533};\\\", \\\"{x:1480,y:777,t:1528139746550};\\\", \\\"{x:1486,y:779,t:1528139746567};\\\", \\\"{x:1492,y:781,t:1528139746582};\\\", \\\"{x:1493,y:782,t:1528139746647};\\\", \\\"{x:1494,y:782,t:1528139746655};\\\", \\\"{x:1496,y:782,t:1528139746666};\\\", \\\"{x:1497,y:783,t:1528139746687};\\\", \\\"{x:1497,y:784,t:1528139746783};\\\", \\\"{x:1497,y:785,t:1528139746801};\\\", \\\"{x:1495,y:787,t:1528139746816};\\\", \\\"{x:1494,y:791,t:1528139746834};\\\", \\\"{x:1494,y:795,t:1528139746851};\\\", \\\"{x:1494,y:799,t:1528139746866};\\\", \\\"{x:1494,y:802,t:1528139746884};\\\", \\\"{x:1495,y:806,t:1528139746900};\\\", \\\"{x:1497,y:808,t:1528139746916};\\\", \\\"{x:1500,y:812,t:1528139746933};\\\", \\\"{x:1504,y:819,t:1528139746951};\\\", \\\"{x:1507,y:823,t:1528139746966};\\\", \\\"{x:1508,y:827,t:1528139746983};\\\", \\\"{x:1508,y:830,t:1528139747000};\\\", \\\"{x:1509,y:832,t:1528139747016};\\\", \\\"{x:1510,y:835,t:1528139747034};\\\", \\\"{x:1510,y:838,t:1528139747050};\\\", \\\"{x:1510,y:840,t:1528139747067};\\\", \\\"{x:1510,y:841,t:1528139747083};\\\", \\\"{x:1510,y:843,t:1528139747100};\\\", \\\"{x:1508,y:844,t:1528139747118};\\\", \\\"{x:1504,y:848,t:1528139747133};\\\", \\\"{x:1501,y:854,t:1528139747150};\\\", \\\"{x:1500,y:858,t:1528139747166};\\\", \\\"{x:1500,y:861,t:1528139747184};\\\", \\\"{x:1500,y:862,t:1528139747201};\\\", \\\"{x:1500,y:864,t:1528139747217};\\\", \\\"{x:1502,y:866,t:1528139747233};\\\", \\\"{x:1503,y:868,t:1528139747250};\\\", \\\"{x:1506,y:869,t:1528139747267};\\\", \\\"{x:1510,y:870,t:1528139747283};\\\", \\\"{x:1511,y:872,t:1528139747300};\\\", \\\"{x:1514,y:872,t:1528139747535};\\\", \\\"{x:1516,y:868,t:1528139747550};\\\", \\\"{x:1517,y:867,t:1528139747567};\\\", \\\"{x:1518,y:863,t:1528139747584};\\\", \\\"{x:1518,y:861,t:1528139747600};\\\", \\\"{x:1518,y:860,t:1528139747617};\\\", \\\"{x:1518,y:858,t:1528139747634};\\\", \\\"{x:1518,y:857,t:1528139747669};\\\", \\\"{x:1518,y:855,t:1528139747684};\\\", \\\"{x:1518,y:854,t:1528139747700};\\\", \\\"{x:1518,y:848,t:1528139747716};\\\", \\\"{x:1518,y:844,t:1528139747733};\\\", \\\"{x:1518,y:841,t:1528139747750};\\\", \\\"{x:1517,y:838,t:1528139747767};\\\", \\\"{x:1517,y:834,t:1528139747784};\\\", \\\"{x:1514,y:829,t:1528139747800};\\\", \\\"{x:1513,y:825,t:1528139747817};\\\", \\\"{x:1511,y:820,t:1528139747834};\\\", \\\"{x:1509,y:812,t:1528139747850};\\\", \\\"{x:1509,y:807,t:1528139747867};\\\", \\\"{x:1509,y:802,t:1528139747884};\\\", \\\"{x:1509,y:796,t:1528139747900};\\\", \\\"{x:1509,y:790,t:1528139747917};\\\", \\\"{x:1508,y:783,t:1528139747934};\\\", \\\"{x:1508,y:780,t:1528139747950};\\\", \\\"{x:1508,y:777,t:1528139747967};\\\", \\\"{x:1508,y:775,t:1528139747985};\\\", \\\"{x:1508,y:774,t:1528139748001};\\\", \\\"{x:1508,y:773,t:1528139748037};\\\", \\\"{x:1508,y:772,t:1528139748077};\\\", \\\"{x:1508,y:770,t:1528139748094};\\\", \\\"{x:1508,y:769,t:1528139748109};\\\", \\\"{x:1508,y:768,t:1528139748126};\\\", \\\"{x:1508,y:767,t:1528139748134};\\\", \\\"{x:1508,y:766,t:1528139748150};\\\", \\\"{x:1508,y:765,t:1528139748167};\\\", \\\"{x:1508,y:764,t:1528139748184};\\\", \\\"{x:1508,y:761,t:1528139748201};\\\", \\\"{x:1507,y:760,t:1528139748217};\\\", \\\"{x:1506,y:758,t:1528139748234};\\\", \\\"{x:1505,y:757,t:1528139748251};\\\", \\\"{x:1505,y:753,t:1528139748267};\\\", \\\"{x:1504,y:751,t:1528139748284};\\\", \\\"{x:1504,y:748,t:1528139748301};\\\", \\\"{x:1504,y:747,t:1528139748317};\\\", \\\"{x:1503,y:744,t:1528139748334};\\\", \\\"{x:1502,y:744,t:1528139748350};\\\", \\\"{x:1502,y:742,t:1528139748375};\\\", \\\"{x:1502,y:741,t:1528139748399};\\\", \\\"{x:1501,y:740,t:1528139748407};\\\", \\\"{x:1500,y:738,t:1528139748422};\\\", \\\"{x:1499,y:737,t:1528139748438};\\\", \\\"{x:1499,y:736,t:1528139748452};\\\", \\\"{x:1497,y:735,t:1528139748469};\\\", \\\"{x:1496,y:734,t:1528139748484};\\\", \\\"{x:1495,y:732,t:1528139748501};\\\", \\\"{x:1495,y:731,t:1528139748518};\\\", \\\"{x:1494,y:729,t:1528139748535};\\\", \\\"{x:1493,y:728,t:1528139748551};\\\", \\\"{x:1492,y:727,t:1528139748568};\\\", \\\"{x:1491,y:725,t:1528139748585};\\\", \\\"{x:1489,y:723,t:1528139748601};\\\", \\\"{x:1488,y:719,t:1528139748619};\\\", \\\"{x:1485,y:716,t:1528139748634};\\\", \\\"{x:1484,y:714,t:1528139748652};\\\", \\\"{x:1484,y:712,t:1528139748671};\\\", \\\"{x:1483,y:711,t:1528139748686};\\\", \\\"{x:1482,y:711,t:1528139748702};\\\", \\\"{x:1481,y:710,t:1528139748719};\\\", \\\"{x:1480,y:708,t:1528139748735};\\\", \\\"{x:1479,y:706,t:1528139748751};\\\", \\\"{x:1477,y:704,t:1528139748769};\\\", \\\"{x:1476,y:703,t:1528139748784};\\\", \\\"{x:1473,y:699,t:1528139748801};\\\", \\\"{x:1471,y:698,t:1528139748818};\\\", \\\"{x:1469,y:696,t:1528139748834};\\\", \\\"{x:1467,y:694,t:1528139748851};\\\", \\\"{x:1464,y:691,t:1528139748869};\\\", \\\"{x:1461,y:689,t:1528139748885};\\\", \\\"{x:1459,y:687,t:1528139748901};\\\", \\\"{x:1453,y:684,t:1528139748919};\\\", \\\"{x:1450,y:681,t:1528139748934};\\\", \\\"{x:1447,y:679,t:1528139748951};\\\", \\\"{x:1443,y:677,t:1528139748969};\\\", \\\"{x:1442,y:676,t:1528139748985};\\\", \\\"{x:1440,y:674,t:1528139749002};\\\", \\\"{x:1439,y:673,t:1528139749022};\\\", \\\"{x:1438,y:672,t:1528139749035};\\\", \\\"{x:1437,y:672,t:1528139749051};\\\", \\\"{x:1435,y:669,t:1528139749068};\\\", \\\"{x:1434,y:666,t:1528139749086};\\\", \\\"{x:1433,y:664,t:1528139749102};\\\", \\\"{x:1430,y:661,t:1528139749119};\\\", \\\"{x:1427,y:657,t:1528139749134};\\\", \\\"{x:1425,y:653,t:1528139749152};\\\", \\\"{x:1424,y:651,t:1528139749168};\\\", \\\"{x:1421,y:647,t:1528139749185};\\\", \\\"{x:1419,y:643,t:1528139749202};\\\", \\\"{x:1417,y:639,t:1528139749218};\\\", \\\"{x:1415,y:635,t:1528139749236};\\\", \\\"{x:1414,y:633,t:1528139749252};\\\", \\\"{x:1414,y:631,t:1528139749269};\\\", \\\"{x:1413,y:628,t:1528139749285};\\\", \\\"{x:1412,y:624,t:1528139749301};\\\", \\\"{x:1410,y:621,t:1528139749319};\\\", \\\"{x:1409,y:617,t:1528139749334};\\\", \\\"{x:1406,y:614,t:1528139749351};\\\", \\\"{x:1405,y:611,t:1528139749369};\\\", \\\"{x:1404,y:609,t:1528139749385};\\\", \\\"{x:1403,y:607,t:1528139749401};\\\", \\\"{x:1403,y:605,t:1528139749418};\\\", \\\"{x:1402,y:604,t:1528139749436};\\\", \\\"{x:1400,y:602,t:1528139749453};\\\", \\\"{x:1400,y:601,t:1528139749468};\\\", \\\"{x:1400,y:598,t:1528139749485};\\\", \\\"{x:1399,y:596,t:1528139749503};\\\", \\\"{x:1398,y:592,t:1528139749519};\\\", \\\"{x:1397,y:590,t:1528139749535};\\\", \\\"{x:1396,y:587,t:1528139749552};\\\", \\\"{x:1396,y:584,t:1528139749569};\\\", \\\"{x:1395,y:582,t:1528139749585};\\\", \\\"{x:1395,y:581,t:1528139749603};\\\", \\\"{x:1395,y:579,t:1528139749619};\\\", \\\"{x:1395,y:578,t:1528139749635};\\\", \\\"{x:1394,y:576,t:1528139749652};\\\", \\\"{x:1394,y:575,t:1528139749668};\\\", \\\"{x:1394,y:573,t:1528139749685};\\\", \\\"{x:1394,y:569,t:1528139749701};\\\", \\\"{x:1393,y:567,t:1528139749717};\\\", \\\"{x:1393,y:566,t:1528139749735};\\\", \\\"{x:1393,y:565,t:1528139749752};\\\", \\\"{x:1393,y:563,t:1528139749768};\\\", \\\"{x:1393,y:562,t:1528139749791};\\\", \\\"{x:1393,y:560,t:1528139749802};\\\", \\\"{x:1393,y:559,t:1528139749817};\\\", \\\"{x:1394,y:557,t:1528139749835};\\\", \\\"{x:1394,y:556,t:1528139749852};\\\", \\\"{x:1396,y:552,t:1528139749869};\\\", \\\"{x:1397,y:551,t:1528139749885};\\\", \\\"{x:1398,y:551,t:1528139749903};\\\", \\\"{x:1399,y:549,t:1528139749919};\\\", \\\"{x:1400,y:549,t:1528139750023};\\\", \\\"{x:1401,y:549,t:1528139750039};\\\", \\\"{x:1402,y:549,t:1528139750052};\\\", \\\"{x:1403,y:549,t:1528139750120};\\\", \\\"{x:1405,y:555,t:1528139750135};\\\", \\\"{x:1406,y:558,t:1528139750153};\\\", \\\"{x:1407,y:562,t:1528139750169};\\\", \\\"{x:1407,y:564,t:1528139750326};\\\", \\\"{x:1407,y:565,t:1528139750470};\\\", \\\"{x:1408,y:566,t:1528139750599};\\\", \\\"{x:1409,y:567,t:1528139750606};\\\", \\\"{x:1410,y:568,t:1528139750670};\\\", \\\"{x:1411,y:568,t:1528139751215};\\\", \\\"{x:1412,y:568,t:1528139751222};\\\", \\\"{x:1413,y:568,t:1528139751302};\\\", \\\"{x:1414,y:568,t:1528139751320};\\\", \\\"{x:1415,y:568,t:1528139751431};\\\", \\\"{x:1416,y:569,t:1528139751456};\\\", \\\"{x:1416,y:568,t:1528139751727};\\\", \\\"{x:1416,y:567,t:1528139751753};\\\", \\\"{x:1415,y:566,t:1528139751991};\\\", \\\"{x:1414,y:565,t:1528139752022};\\\", \\\"{x:1412,y:565,t:1528139752037};\\\", \\\"{x:1411,y:564,t:1528139752054};\\\", \\\"{x:1410,y:564,t:1528139752071};\\\", \\\"{x:1409,y:563,t:1528139752094};\\\", \\\"{x:1409,y:564,t:1528139754479};\\\", \\\"{x:1407,y:575,t:1528139754489};\\\", \\\"{x:1392,y:611,t:1528139754506};\\\", \\\"{x:1370,y:646,t:1528139754522};\\\", \\\"{x:1359,y:673,t:1528139754538};\\\", \\\"{x:1346,y:695,t:1528139754556};\\\", \\\"{x:1338,y:708,t:1528139754573};\\\", \\\"{x:1337,y:718,t:1528139754589};\\\", \\\"{x:1337,y:725,t:1528139754606};\\\", \\\"{x:1337,y:730,t:1528139754622};\\\", \\\"{x:1337,y:731,t:1528139754639};\\\", \\\"{x:1336,y:736,t:1528139754656};\\\", \\\"{x:1335,y:743,t:1528139754673};\\\", \\\"{x:1334,y:753,t:1528139754689};\\\", \\\"{x:1331,y:767,t:1528139754705};\\\", \\\"{x:1327,y:784,t:1528139754723};\\\", \\\"{x:1323,y:800,t:1528139754739};\\\", \\\"{x:1319,y:812,t:1528139754756};\\\", \\\"{x:1317,y:817,t:1528139754773};\\\", \\\"{x:1317,y:818,t:1528139754789};\\\", \\\"{x:1317,y:819,t:1528139754805};\\\", \\\"{x:1317,y:820,t:1528139754919};\\\", \\\"{x:1315,y:822,t:1528139754927};\\\", \\\"{x:1308,y:824,t:1528139754940};\\\", \\\"{x:1291,y:824,t:1528139754956};\\\", \\\"{x:1271,y:823,t:1528139754973};\\\", \\\"{x:1253,y:819,t:1528139754990};\\\", \\\"{x:1237,y:813,t:1528139755005};\\\", \\\"{x:1216,y:805,t:1528139755022};\\\", \\\"{x:1214,y:803,t:1528139755039};\\\", \\\"{x:1212,y:802,t:1528139755055};\\\", \\\"{x:1211,y:802,t:1528139755086};\\\", \\\"{x:1210,y:802,t:1528139755094};\\\", \\\"{x:1208,y:800,t:1528139755106};\\\", \\\"{x:1201,y:799,t:1528139755123};\\\", \\\"{x:1192,y:796,t:1528139755140};\\\", \\\"{x:1187,y:795,t:1528139755155};\\\", \\\"{x:1184,y:794,t:1528139755171};\\\", \\\"{x:1181,y:792,t:1528139755189};\\\", \\\"{x:1179,y:792,t:1528139755205};\\\", \\\"{x:1177,y:790,t:1528139755222};\\\", \\\"{x:1175,y:789,t:1528139755246};\\\", \\\"{x:1174,y:787,t:1528139755262};\\\", \\\"{x:1173,y:785,t:1528139755272};\\\", \\\"{x:1173,y:783,t:1528139755293};\\\", \\\"{x:1172,y:783,t:1528139755306};\\\", \\\"{x:1172,y:780,t:1528139755322};\\\", \\\"{x:1172,y:778,t:1528139755339};\\\", \\\"{x:1172,y:776,t:1528139755357};\\\", \\\"{x:1172,y:775,t:1528139755372};\\\", \\\"{x:1171,y:775,t:1528139755406};\\\", \\\"{x:1171,y:773,t:1528139755455};\\\", \\\"{x:1171,y:772,t:1528139755479};\\\", \\\"{x:1172,y:770,t:1528139755489};\\\", \\\"{x:1174,y:769,t:1528139755507};\\\", \\\"{x:1176,y:768,t:1528139755522};\\\", \\\"{x:1178,y:767,t:1528139755591};\\\", \\\"{x:1182,y:766,t:1528139755606};\\\", \\\"{x:1183,y:765,t:1528139755623};\\\", \\\"{x:1184,y:764,t:1528139755670};\\\", \\\"{x:1186,y:766,t:1528139756095};\\\", \\\"{x:1187,y:767,t:1528139756107};\\\", \\\"{x:1190,y:773,t:1528139756123};\\\", \\\"{x:1193,y:781,t:1528139756141};\\\", \\\"{x:1196,y:787,t:1528139756156};\\\", \\\"{x:1199,y:791,t:1528139756174};\\\", \\\"{x:1202,y:798,t:1528139756190};\\\", \\\"{x:1205,y:801,t:1528139756206};\\\", \\\"{x:1207,y:806,t:1528139756223};\\\", \\\"{x:1211,y:810,t:1528139756241};\\\", \\\"{x:1213,y:814,t:1528139756257};\\\", \\\"{x:1214,y:819,t:1528139756274};\\\", \\\"{x:1215,y:821,t:1528139756290};\\\", \\\"{x:1216,y:821,t:1528139756352};\\\", \\\"{x:1215,y:821,t:1528139756503};\\\", \\\"{x:1214,y:821,t:1528139756511};\\\", \\\"{x:1214,y:819,t:1528139756526};\\\", \\\"{x:1214,y:818,t:1528139756543};\\\", \\\"{x:1214,y:817,t:1528139756558};\\\", \\\"{x:1215,y:816,t:1528139756573};\\\", \\\"{x:1216,y:815,t:1528139756751};\\\", \\\"{x:1217,y:815,t:1528139756799};\\\", \\\"{x:1220,y:813,t:1528139756807};\\\", \\\"{x:1227,y:810,t:1528139756823};\\\", \\\"{x:1234,y:807,t:1528139756840};\\\", \\\"{x:1242,y:802,t:1528139756858};\\\", \\\"{x:1250,y:798,t:1528139756874};\\\", \\\"{x:1255,y:794,t:1528139756891};\\\", \\\"{x:1264,y:788,t:1528139756908};\\\", \\\"{x:1272,y:781,t:1528139756924};\\\", \\\"{x:1278,y:777,t:1528139756941};\\\", \\\"{x:1284,y:774,t:1528139756957};\\\", \\\"{x:1288,y:771,t:1528139756974};\\\", \\\"{x:1292,y:768,t:1528139756991};\\\", \\\"{x:1295,y:766,t:1528139757008};\\\", \\\"{x:1299,y:763,t:1528139757025};\\\", \\\"{x:1305,y:759,t:1528139757041};\\\", \\\"{x:1311,y:755,t:1528139757058};\\\", \\\"{x:1313,y:753,t:1528139757074};\\\", \\\"{x:1315,y:752,t:1528139757090};\\\", \\\"{x:1316,y:751,t:1528139757126};\\\", \\\"{x:1317,y:750,t:1528139757140};\\\", \\\"{x:1320,y:747,t:1528139757158};\\\", \\\"{x:1332,y:738,t:1528139757174};\\\", \\\"{x:1339,y:732,t:1528139757190};\\\", \\\"{x:1345,y:727,t:1528139757207};\\\", \\\"{x:1348,y:724,t:1528139757225};\\\", \\\"{x:1349,y:723,t:1528139757240};\\\", \\\"{x:1350,y:723,t:1528139757270};\\\", \\\"{x:1350,y:722,t:1528139757278};\\\", \\\"{x:1350,y:721,t:1528139757291};\\\", \\\"{x:1352,y:719,t:1528139757308};\\\", \\\"{x:1353,y:717,t:1528139757324};\\\", \\\"{x:1354,y:714,t:1528139757341};\\\", \\\"{x:1356,y:712,t:1528139757358};\\\", \\\"{x:1358,y:708,t:1528139757375};\\\", \\\"{x:1360,y:704,t:1528139757390};\\\", \\\"{x:1361,y:702,t:1528139757408};\\\", \\\"{x:1361,y:701,t:1528139757455};\\\", \\\"{x:1359,y:700,t:1528139757671};\\\", \\\"{x:1357,y:698,t:1528139757687};\\\", \\\"{x:1356,y:697,t:1528139757703};\\\", \\\"{x:1354,y:697,t:1528139757710};\\\", \\\"{x:1353,y:697,t:1528139757727};\\\", \\\"{x:1352,y:696,t:1528139757758};\\\", \\\"{x:1352,y:695,t:1528139757775};\\\", \\\"{x:1351,y:695,t:1528139757982};\\\", \\\"{x:1349,y:695,t:1528139757999};\\\", \\\"{x:1348,y:695,t:1528139758031};\\\", \\\"{x:1347,y:695,t:1528139758041};\\\", \\\"{x:1346,y:695,t:1528139758058};\\\", \\\"{x:1346,y:694,t:1528139758074};\\\", \\\"{x:1340,y:691,t:1528139759567};\\\", \\\"{x:1332,y:685,t:1528139759576};\\\", \\\"{x:1322,y:673,t:1528139759592};\\\", \\\"{x:1316,y:663,t:1528139759609};\\\", \\\"{x:1310,y:656,t:1528139759625};\\\", \\\"{x:1307,y:651,t:1528139759643};\\\", \\\"{x:1304,y:645,t:1528139759660};\\\", \\\"{x:1303,y:642,t:1528139759675};\\\", \\\"{x:1303,y:640,t:1528139759692};\\\", \\\"{x:1303,y:637,t:1528139759710};\\\", \\\"{x:1302,y:634,t:1528139759726};\\\", \\\"{x:1302,y:630,t:1528139759743};\\\", \\\"{x:1300,y:628,t:1528139759761};\\\", \\\"{x:1300,y:627,t:1528139759776};\\\", \\\"{x:1299,y:625,t:1528139759792};\\\", \\\"{x:1297,y:621,t:1528139759809};\\\", \\\"{x:1296,y:619,t:1528139759826};\\\", \\\"{x:1296,y:618,t:1528139759843};\\\", \\\"{x:1294,y:614,t:1528139759860};\\\", \\\"{x:1293,y:613,t:1528139759877};\\\", \\\"{x:1292,y:610,t:1528139759892};\\\", \\\"{x:1290,y:606,t:1528139759910};\\\", \\\"{x:1285,y:600,t:1528139759926};\\\", \\\"{x:1280,y:590,t:1528139759943};\\\", \\\"{x:1274,y:578,t:1528139759960};\\\", \\\"{x:1270,y:570,t:1528139759977};\\\", \\\"{x:1268,y:565,t:1528139759993};\\\", \\\"{x:1268,y:563,t:1528139760010};\\\", \\\"{x:1267,y:561,t:1528139760027};\\\", \\\"{x:1267,y:560,t:1528139760043};\\\", \\\"{x:1267,y:559,t:1528139760238};\\\", \\\"{x:1268,y:559,t:1528139760254};\\\", \\\"{x:1270,y:559,t:1528139760262};\\\", \\\"{x:1271,y:559,t:1528139760286};\\\", \\\"{x:1272,y:559,t:1528139760295};\\\", \\\"{x:1274,y:559,t:1528139760311};\\\", \\\"{x:1274,y:560,t:1528139760326};\\\", \\\"{x:1275,y:560,t:1528139760367};\\\", \\\"{x:1276,y:560,t:1528139761543};\\\", \\\"{x:1279,y:562,t:1528139761561};\\\", \\\"{x:1282,y:562,t:1528139761590};\\\", \\\"{x:1287,y:562,t:1528139761600};\\\", \\\"{x:1293,y:562,t:1528139761611};\\\", \\\"{x:1306,y:562,t:1528139761628};\\\", \\\"{x:1318,y:559,t:1528139761644};\\\", \\\"{x:1324,y:558,t:1528139761660};\\\", \\\"{x:1327,y:557,t:1528139761678};\\\", \\\"{x:1329,y:555,t:1528139761694};\\\", \\\"{x:1330,y:554,t:1528139761710};\\\", \\\"{x:1335,y:550,t:1528139761727};\\\", \\\"{x:1338,y:547,t:1528139761744};\\\", \\\"{x:1340,y:545,t:1528139761760};\\\", \\\"{x:1345,y:543,t:1528139761778};\\\", \\\"{x:1348,y:542,t:1528139761795};\\\", \\\"{x:1353,y:541,t:1528139761810};\\\", \\\"{x:1359,y:540,t:1528139761828};\\\", \\\"{x:1364,y:539,t:1528139761845};\\\", \\\"{x:1367,y:538,t:1528139761861};\\\", \\\"{x:1368,y:538,t:1528139761878};\\\", \\\"{x:1369,y:537,t:1528139761894};\\\", \\\"{x:1371,y:537,t:1528139761910};\\\", \\\"{x:1372,y:537,t:1528139761928};\\\", \\\"{x:1373,y:537,t:1528139761945};\\\", \\\"{x:1374,y:537,t:1528139762120};\\\", \\\"{x:1376,y:537,t:1528139762127};\\\", \\\"{x:1379,y:539,t:1528139762144};\\\", \\\"{x:1385,y:543,t:1528139762161};\\\", \\\"{x:1391,y:546,t:1528139762178};\\\", \\\"{x:1397,y:549,t:1528139762195};\\\", \\\"{x:1399,y:550,t:1528139762211};\\\", \\\"{x:1401,y:550,t:1528139762228};\\\", \\\"{x:1402,y:551,t:1528139762245};\\\", \\\"{x:1406,y:552,t:1528139762262};\\\", \\\"{x:1409,y:553,t:1528139762278};\\\", \\\"{x:1418,y:554,t:1528139762295};\\\", \\\"{x:1425,y:555,t:1528139762312};\\\", \\\"{x:1428,y:555,t:1528139762327};\\\", \\\"{x:1429,y:555,t:1528139762345};\\\", \\\"{x:1429,y:556,t:1528139762471};\\\", \\\"{x:1428,y:556,t:1528139762527};\\\", \\\"{x:1424,y:557,t:1528139762545};\\\", \\\"{x:1419,y:558,t:1528139762562};\\\", \\\"{x:1416,y:558,t:1528139762578};\\\", \\\"{x:1415,y:558,t:1528139762595};\\\", \\\"{x:1414,y:558,t:1528139762612};\\\", \\\"{x:1413,y:558,t:1528139762679};\\\", \\\"{x:1412,y:558,t:1528139762710};\\\", \\\"{x:1412,y:559,t:1528139765375};\\\", \\\"{x:1407,y:562,t:1528139766439};\\\", \\\"{x:1401,y:563,t:1528139766448};\\\", \\\"{x:1391,y:565,t:1528139766465};\\\", \\\"{x:1388,y:565,t:1528139766481};\\\", \\\"{x:1387,y:565,t:1528139766583};\\\", \\\"{x:1383,y:568,t:1528139766598};\\\", \\\"{x:1376,y:569,t:1528139766614};\\\", \\\"{x:1363,y:573,t:1528139766631};\\\", \\\"{x:1344,y:579,t:1528139766648};\\\", \\\"{x:1323,y:584,t:1528139766665};\\\", \\\"{x:1293,y:592,t:1528139766681};\\\", \\\"{x:1248,y:605,t:1528139766698};\\\", \\\"{x:1187,y:622,t:1528139766715};\\\", \\\"{x:1120,y:633,t:1528139766731};\\\", \\\"{x:1037,y:644,t:1528139766748};\\\", \\\"{x:965,y:653,t:1528139766765};\\\", \\\"{x:881,y:653,t:1528139766781};\\\", \\\"{x:781,y:653,t:1528139766798};\\\", \\\"{x:728,y:653,t:1528139766814};\\\", \\\"{x:700,y:653,t:1528139766831};\\\", \\\"{x:668,y:653,t:1528139766848};\\\", \\\"{x:653,y:653,t:1528139766865};\\\", \\\"{x:647,y:653,t:1528139766881};\\\", \\\"{x:644,y:653,t:1528139766898};\\\", \\\"{x:643,y:653,t:1528139766926};\\\", \\\"{x:642,y:653,t:1528139766934};\\\", \\\"{x:640,y:652,t:1528139766950};\\\", \\\"{x:640,y:650,t:1528139766965};\\\", \\\"{x:639,y:647,t:1528139766981};\\\", \\\"{x:639,y:640,t:1528139766998};\\\", \\\"{x:638,y:636,t:1528139767015};\\\", \\\"{x:636,y:630,t:1528139767033};\\\", \\\"{x:634,y:624,t:1528139767048};\\\", \\\"{x:629,y:617,t:1528139767064};\\\", \\\"{x:628,y:615,t:1528139767075};\\\", \\\"{x:618,y:607,t:1528139767092};\\\", \\\"{x:605,y:602,t:1528139767109};\\\", \\\"{x:572,y:596,t:1528139767126};\\\", \\\"{x:521,y:590,t:1528139767151};\\\", \\\"{x:474,y:590,t:1528139767167};\\\", \\\"{x:439,y:590,t:1528139767183};\\\", \\\"{x:409,y:589,t:1528139767200};\\\", \\\"{x:391,y:588,t:1528139767217};\\\", \\\"{x:385,y:586,t:1528139767233};\\\", \\\"{x:383,y:586,t:1528139767250};\\\", \\\"{x:383,y:585,t:1528139767390};\\\", \\\"{x:383,y:583,t:1528139767405};\\\", \\\"{x:383,y:582,t:1528139767422};\\\", \\\"{x:383,y:580,t:1528139767438};\\\", \\\"{x:382,y:579,t:1528139767454};\\\", \\\"{x:380,y:579,t:1528139767470};\\\", \\\"{x:375,y:579,t:1528139767484};\\\", \\\"{x:354,y:579,t:1528139767502};\\\", \\\"{x:305,y:579,t:1528139767517};\\\", \\\"{x:247,y:584,t:1528139767534};\\\", \\\"{x:176,y:591,t:1528139767551};\\\", \\\"{x:110,y:594,t:1528139767568};\\\", \\\"{x:57,y:594,t:1528139767584};\\\", \\\"{x:28,y:594,t:1528139767600};\\\", \\\"{x:21,y:594,t:1528139767618};\\\", \\\"{x:20,y:594,t:1528139767634};\\\", \\\"{x:23,y:594,t:1528139767718};\\\", \\\"{x:41,y:591,t:1528139767734};\\\", \\\"{x:62,y:585,t:1528139767751};\\\", \\\"{x:85,y:579,t:1528139767767};\\\", \\\"{x:108,y:575,t:1528139767784};\\\", \\\"{x:128,y:573,t:1528139767800};\\\", \\\"{x:145,y:569,t:1528139767817};\\\", \\\"{x:167,y:567,t:1528139767834};\\\", \\\"{x:191,y:562,t:1528139767850};\\\", \\\"{x:216,y:558,t:1528139767867};\\\", \\\"{x:244,y:555,t:1528139767885};\\\", \\\"{x:268,y:552,t:1528139767901};\\\", \\\"{x:316,y:546,t:1528139767918};\\\", \\\"{x:343,y:541,t:1528139767933};\\\", \\\"{x:371,y:538,t:1528139767950};\\\", \\\"{x:391,y:534,t:1528139767968};\\\", \\\"{x:412,y:532,t:1528139767985};\\\", \\\"{x:435,y:530,t:1528139768000};\\\", \\\"{x:459,y:529,t:1528139768018};\\\", \\\"{x:490,y:528,t:1528139768034};\\\", \\\"{x:524,y:526,t:1528139768051};\\\", \\\"{x:560,y:523,t:1528139768068};\\\", \\\"{x:600,y:521,t:1528139768084};\\\", \\\"{x:634,y:520,t:1528139768100};\\\", \\\"{x:679,y:517,t:1528139768118};\\\", \\\"{x:700,y:517,t:1528139768134};\\\", \\\"{x:723,y:517,t:1528139768151};\\\", \\\"{x:740,y:516,t:1528139768167};\\\", \\\"{x:759,y:516,t:1528139768184};\\\", \\\"{x:774,y:516,t:1528139768200};\\\", \\\"{x:783,y:516,t:1528139768217};\\\", \\\"{x:786,y:516,t:1528139768234};\\\", \\\"{x:788,y:517,t:1528139768250};\\\", \\\"{x:789,y:517,t:1528139768267};\\\", \\\"{x:791,y:517,t:1528139768284};\\\", \\\"{x:792,y:517,t:1528139768309};\\\", \\\"{x:792,y:518,t:1528139768326};\\\", \\\"{x:794,y:519,t:1528139768341};\\\", \\\"{x:796,y:520,t:1528139768350};\\\", \\\"{x:800,y:522,t:1528139768367};\\\", \\\"{x:804,y:525,t:1528139768385};\\\", \\\"{x:809,y:527,t:1528139768401};\\\", \\\"{x:812,y:528,t:1528139768417};\\\", \\\"{x:814,y:530,t:1528139768434};\\\", \\\"{x:816,y:532,t:1528139768451};\\\", \\\"{x:819,y:532,t:1528139768468};\\\", \\\"{x:822,y:534,t:1528139768484};\\\", \\\"{x:825,y:535,t:1528139768502};\\\", \\\"{x:828,y:535,t:1528139768517};\\\", \\\"{x:829,y:536,t:1528139768534};\\\", \\\"{x:830,y:537,t:1528139768551};\\\", \\\"{x:832,y:537,t:1528139768569};\\\", \\\"{x:832,y:538,t:1528139768585};\\\", \\\"{x:834,y:539,t:1528139768601};\\\", \\\"{x:835,y:539,t:1528139768973};\\\", \\\"{x:838,y:541,t:1528139768985};\\\", \\\"{x:843,y:542,t:1528139769002};\\\", \\\"{x:861,y:542,t:1528139769019};\\\", \\\"{x:890,y:542,t:1528139769035};\\\", \\\"{x:929,y:543,t:1528139769052};\\\", \\\"{x:970,y:547,t:1528139769069};\\\", \\\"{x:1013,y:554,t:1528139769085};\\\", \\\"{x:1078,y:561,t:1528139769102};\\\", \\\"{x:1136,y:568,t:1528139769118};\\\", \\\"{x:1181,y:569,t:1528139769135};\\\", \\\"{x:1211,y:570,t:1528139769152};\\\", \\\"{x:1233,y:570,t:1528139769169};\\\", \\\"{x:1255,y:570,t:1528139769185};\\\", \\\"{x:1273,y:570,t:1528139769202};\\\", \\\"{x:1286,y:570,t:1528139769221};\\\", \\\"{x:1303,y:570,t:1528139769235};\\\", \\\"{x:1323,y:570,t:1528139769251};\\\", \\\"{x:1342,y:570,t:1528139769269};\\\", \\\"{x:1359,y:570,t:1528139769285};\\\", \\\"{x:1389,y:571,t:1528139769302};\\\", \\\"{x:1403,y:571,t:1528139769319};\\\", \\\"{x:1419,y:574,t:1528139769336};\\\", \\\"{x:1432,y:574,t:1528139769352};\\\", \\\"{x:1442,y:574,t:1528139769369};\\\", \\\"{x:1445,y:574,t:1528139769385};\\\", \\\"{x:1447,y:575,t:1528139769487};\\\", \\\"{x:1447,y:577,t:1528139769510};\\\", \\\"{x:1448,y:580,t:1528139769519};\\\", \\\"{x:1450,y:586,t:1528139769536};\\\", \\\"{x:1454,y:600,t:1528139769552};\\\", \\\"{x:1459,y:617,t:1528139769569};\\\", \\\"{x:1467,y:631,t:1528139769586};\\\", \\\"{x:1470,y:635,t:1528139769602};\\\", \\\"{x:1472,y:637,t:1528139769620};\\\", \\\"{x:1472,y:639,t:1528139769636};\\\", \\\"{x:1471,y:639,t:1528139769751};\\\", \\\"{x:1465,y:639,t:1528139769769};\\\", \\\"{x:1459,y:639,t:1528139769786};\\\", \\\"{x:1456,y:639,t:1528139769802};\\\", \\\"{x:1454,y:639,t:1528139769820};\\\", \\\"{x:1453,y:639,t:1528139769836};\\\", \\\"{x:1451,y:638,t:1528139769852};\\\", \\\"{x:1450,y:637,t:1528139769868};\\\", \\\"{x:1448,y:635,t:1528139769887};\\\", \\\"{x:1448,y:634,t:1528139769902};\\\", \\\"{x:1447,y:633,t:1528139769934};\\\", \\\"{x:1446,y:633,t:1528139770582};\\\", \\\"{x:1442,y:642,t:1528139770591};\\\", \\\"{x:1436,y:652,t:1528139770603};\\\", \\\"{x:1426,y:670,t:1528139770619};\\\", \\\"{x:1418,y:687,t:1528139770636};\\\", \\\"{x:1408,y:701,t:1528139770653};\\\", \\\"{x:1400,y:714,t:1528139770669};\\\", \\\"{x:1388,y:739,t:1528139770685};\\\", \\\"{x:1376,y:762,t:1528139770703};\\\", \\\"{x:1355,y:788,t:1528139770719};\\\", \\\"{x:1329,y:820,t:1528139770736};\\\", \\\"{x:1283,y:856,t:1528139770752};\\\", \\\"{x:1224,y:886,t:1528139770768};\\\", \\\"{x:1154,y:909,t:1528139770785};\\\", \\\"{x:1066,y:930,t:1528139770802};\\\", \\\"{x:978,y:940,t:1528139770819};\\\", \\\"{x:899,y:945,t:1528139770835};\\\", \\\"{x:831,y:947,t:1528139770853};\\\", \\\"{x:775,y:946,t:1528139770868};\\\", \\\"{x:733,y:932,t:1528139770886};\\\", \\\"{x:721,y:921,t:1528139770903};\\\", \\\"{x:713,y:910,t:1528139770920};\\\", \\\"{x:706,y:902,t:1528139770936};\\\", \\\"{x:699,y:892,t:1528139770952};\\\", \\\"{x:690,y:887,t:1528139770969};\\\", \\\"{x:678,y:883,t:1528139770986};\\\", \\\"{x:667,y:877,t:1528139771003};\\\", \\\"{x:656,y:871,t:1528139771020};\\\", \\\"{x:643,y:861,t:1528139771036};\\\", \\\"{x:628,y:851,t:1528139771053};\\\", \\\"{x:612,y:841,t:1528139771070};\\\", \\\"{x:603,y:837,t:1528139771086};\\\", \\\"{x:595,y:833,t:1528139771103};\\\", \\\"{x:584,y:828,t:1528139771120};\\\", \\\"{x:568,y:821,t:1528139771136};\\\", \\\"{x:546,y:807,t:1528139771154};\\\", \\\"{x:528,y:796,t:1528139771170};\\\", \\\"{x:518,y:787,t:1528139771187};\\\", \\\"{x:511,y:779,t:1528139771203};\\\", \\\"{x:506,y:774,t:1528139771221};\\\", \\\"{x:505,y:769,t:1528139771236};\\\", \\\"{x:504,y:765,t:1528139771253};\\\", \\\"{x:502,y:761,t:1528139771270};\\\", \\\"{x:502,y:757,t:1528139771286};\\\", \\\"{x:502,y:753,t:1528139771303};\\\", \\\"{x:502,y:750,t:1528139771320};\\\", \\\"{x:502,y:746,t:1528139771336};\\\", \\\"{x:502,y:744,t:1528139771353};\\\", \\\"{x:502,y:747,t:1528139771773};\\\", \\\"{x:516,y:757,t:1528139771786};\\\", \\\"{x:564,y:794,t:1528139771804};\\\", \\\"{x:624,y:827,t:1528139771821};\\\", \\\"{x:725,y:871,t:1528139771837};\\\", \\\"{x:775,y:893,t:1528139771854};\\\", \\\"{x:806,y:907,t:1528139771871};\\\", \\\"{x:820,y:913,t:1528139771887};\\\", \\\"{x:823,y:915,t:1528139771904};\\\", \\\"{x:824,y:915,t:1528139771983};\\\" ] }, { \\\"rt\\\": 26135, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 13, \\\"time_elapsed\\\": 542955, \\\"internal_node_id\\\": \\\"0.0-6.0-3.0\\\", \\\"subject\\\": \\\"JYGX2\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"yankee\\\", \\\"condition\\\": \\\"311\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"starttime+before+endtime+during\\\", \\\"q\\\": 9, \\\"clicks\\\": 1, \\\"explicit\\\": 3, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XInside-YFull\\\", \\\"correct\\\": 1, \\\"orth_correct\\\": 1, \\\"answer\\\": [ \\\"I\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-B -B -B -J -I -E -E -E -B -I -J -11 AM-J -I -I \\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:843,y:914,t:1528139777126};\\\", \\\"{x:948,y:888,t:1528139777145};\\\", \\\"{x:1070,y:850,t:1528139777158};\\\", \\\"{x:1180,y:826,t:1528139777175};\\\", \\\"{x:1266,y:811,t:1528139777190};\\\", \\\"{x:1317,y:797,t:1528139777207};\\\", \\\"{x:1338,y:789,t:1528139777224};\\\", \\\"{x:1342,y:787,t:1528139777241};\\\", \\\"{x:1346,y:785,t:1528139777258};\\\", \\\"{x:1348,y:782,t:1528139777275};\\\", \\\"{x:1351,y:776,t:1528139777291};\\\", \\\"{x:1359,y:767,t:1528139777308};\\\", \\\"{x:1370,y:757,t:1528139777325};\\\", \\\"{x:1387,y:746,t:1528139777341};\\\", \\\"{x:1403,y:734,t:1528139777358};\\\", \\\"{x:1403,y:733,t:1528139777375};\\\", \\\"{x:1403,y:734,t:1528139777526};\\\", \\\"{x:1401,y:741,t:1528139777542};\\\", \\\"{x:1388,y:761,t:1528139777558};\\\", \\\"{x:1381,y:772,t:1528139777575};\\\", \\\"{x:1378,y:776,t:1528139777593};\\\", \\\"{x:1377,y:778,t:1528139777608};\\\", \\\"{x:1376,y:778,t:1528139777625};\\\", \\\"{x:1374,y:778,t:1528139777662};\\\", \\\"{x:1373,y:778,t:1528139777678};\\\", \\\"{x:1371,y:778,t:1528139777695};\\\", \\\"{x:1370,y:778,t:1528139777710};\\\", \\\"{x:1367,y:778,t:1528139777725};\\\", \\\"{x:1363,y:778,t:1528139777742};\\\", \\\"{x:1357,y:778,t:1528139777758};\\\", \\\"{x:1354,y:777,t:1528139777776};\\\", \\\"{x:1350,y:775,t:1528139777792};\\\", \\\"{x:1348,y:773,t:1528139777809};\\\", \\\"{x:1346,y:770,t:1528139777826};\\\", \\\"{x:1344,y:767,t:1528139777845};\\\", \\\"{x:1343,y:761,t:1528139777858};\\\", \\\"{x:1342,y:761,t:1528139777875};\\\", \\\"{x:1342,y:759,t:1528139777892};\\\", \\\"{x:1342,y:758,t:1528139777973};\\\", \\\"{x:1342,y:757,t:1528139777981};\\\", \\\"{x:1342,y:756,t:1528139778014};\\\", \\\"{x:1344,y:756,t:1528139778703};\\\", \\\"{x:1346,y:756,t:1528139778710};\\\", \\\"{x:1347,y:756,t:1528139778726};\\\", \\\"{x:1348,y:756,t:1528139778742};\\\", \\\"{x:1349,y:756,t:1528139778766};\\\", \\\"{x:1348,y:756,t:1528139779190};\\\", \\\"{x:1347,y:756,t:1528139779645};\\\", \\\"{x:1345,y:757,t:1528139779660};\\\", \\\"{x:1344,y:758,t:1528139779676};\\\", \\\"{x:1343,y:760,t:1528139779693};\\\", \\\"{x:1342,y:762,t:1528139781518};\\\", \\\"{x:1337,y:774,t:1528139781530};\\\", \\\"{x:1320,y:792,t:1528139781544};\\\", \\\"{x:1301,y:805,t:1528139781561};\\\", \\\"{x:1293,y:813,t:1528139781578};\\\", \\\"{x:1288,y:817,t:1528139781595};\\\", \\\"{x:1286,y:818,t:1528139781611};\\\", \\\"{x:1285,y:818,t:1528139781846};\\\", \\\"{x:1280,y:818,t:1528139781862};\\\", \\\"{x:1270,y:818,t:1528139781878};\\\", \\\"{x:1254,y:818,t:1528139781895};\\\", \\\"{x:1232,y:818,t:1528139781912};\\\", \\\"{x:1211,y:818,t:1528139781928};\\\", \\\"{x:1194,y:818,t:1528139781946};\\\", \\\"{x:1180,y:818,t:1528139781962};\\\", \\\"{x:1173,y:820,t:1528139781978};\\\", \\\"{x:1172,y:820,t:1528139781996};\\\", \\\"{x:1172,y:817,t:1528139782310};\\\", \\\"{x:1172,y:810,t:1528139782318};\\\", \\\"{x:1172,y:802,t:1528139782328};\\\", \\\"{x:1173,y:785,t:1528139782345};\\\", \\\"{x:1180,y:764,t:1528139782363};\\\", \\\"{x:1186,y:742,t:1528139782380};\\\", \\\"{x:1193,y:722,t:1528139782395};\\\", \\\"{x:1200,y:704,t:1528139782413};\\\", \\\"{x:1206,y:692,t:1528139782429};\\\", \\\"{x:1207,y:679,t:1528139782446};\\\", \\\"{x:1210,y:675,t:1528139782462};\\\", \\\"{x:1211,y:673,t:1528139782478};\\\", \\\"{x:1213,y:667,t:1528139782496};\\\", \\\"{x:1215,y:663,t:1528139782512};\\\", \\\"{x:1218,y:658,t:1528139782529};\\\", \\\"{x:1220,y:651,t:1528139782546};\\\", \\\"{x:1223,y:646,t:1528139782562};\\\", \\\"{x:1226,y:639,t:1528139782579};\\\", \\\"{x:1232,y:630,t:1528139782596};\\\", \\\"{x:1236,y:623,t:1528139782613};\\\", \\\"{x:1240,y:619,t:1528139782629};\\\", \\\"{x:1248,y:610,t:1528139782645};\\\", \\\"{x:1254,y:602,t:1528139782661};\\\", \\\"{x:1261,y:595,t:1528139782679};\\\", \\\"{x:1264,y:592,t:1528139782695};\\\", \\\"{x:1265,y:589,t:1528139782712};\\\", \\\"{x:1268,y:587,t:1528139782729};\\\", \\\"{x:1270,y:585,t:1528139782745};\\\", \\\"{x:1273,y:583,t:1528139782762};\\\", \\\"{x:1275,y:582,t:1528139782779};\\\", \\\"{x:1275,y:581,t:1528139782854};\\\", \\\"{x:1275,y:580,t:1528139783085};\\\", \\\"{x:1276,y:578,t:1528139783095};\\\", \\\"{x:1276,y:574,t:1528139783112};\\\", \\\"{x:1276,y:573,t:1528139783129};\\\", \\\"{x:1277,y:572,t:1528139783145};\\\", \\\"{x:1277,y:571,t:1528139783162};\\\", \\\"{x:1277,y:568,t:1528139783179};\\\", \\\"{x:1278,y:566,t:1528139783196};\\\", \\\"{x:1278,y:562,t:1528139783212};\\\", \\\"{x:1279,y:559,t:1528139783229};\\\", \\\"{x:1279,y:558,t:1528139783254};\\\", \\\"{x:1279,y:557,t:1528139784055};\\\", \\\"{x:1280,y:557,t:1528139784070};\\\", \\\"{x:1280,y:558,t:1528139784080};\\\", \\\"{x:1280,y:559,t:1528139784096};\\\", \\\"{x:1280,y:560,t:1528139784113};\\\", \\\"{x:1280,y:561,t:1528139784134};\\\", \\\"{x:1280,y:562,t:1528139784166};\\\", \\\"{x:1280,y:563,t:1528139784182};\\\", \\\"{x:1281,y:563,t:1528139784798};\\\", \\\"{x:1291,y:588,t:1528139784815};\\\", \\\"{x:1309,y:630,t:1528139784830};\\\", \\\"{x:1330,y:682,t:1528139784848};\\\", \\\"{x:1345,y:718,t:1528139784863};\\\", \\\"{x:1356,y:742,t:1528139784881};\\\", \\\"{x:1362,y:755,t:1528139784898};\\\", \\\"{x:1367,y:765,t:1528139784914};\\\", \\\"{x:1372,y:771,t:1528139784931};\\\", \\\"{x:1374,y:774,t:1528139784948};\\\", \\\"{x:1376,y:775,t:1528139784964};\\\", \\\"{x:1378,y:777,t:1528139784981};\\\", \\\"{x:1386,y:784,t:1528139784998};\\\", \\\"{x:1390,y:786,t:1528139785014};\\\", \\\"{x:1391,y:786,t:1528139785030};\\\", \\\"{x:1390,y:786,t:1528139785166};\\\", \\\"{x:1389,y:786,t:1528139785181};\\\", \\\"{x:1380,y:784,t:1528139785198};\\\", \\\"{x:1373,y:782,t:1528139785214};\\\", \\\"{x:1365,y:778,t:1528139785231};\\\", \\\"{x:1360,y:776,t:1528139785248};\\\", \\\"{x:1352,y:775,t:1528139785265};\\\", \\\"{x:1345,y:774,t:1528139785281};\\\", \\\"{x:1339,y:771,t:1528139785298};\\\", \\\"{x:1335,y:770,t:1528139785315};\\\", \\\"{x:1334,y:770,t:1528139785331};\\\", \\\"{x:1332,y:770,t:1528139785407};\\\", \\\"{x:1332,y:768,t:1528139785526};\\\", \\\"{x:1333,y:767,t:1528139785534};\\\", \\\"{x:1336,y:764,t:1528139785548};\\\", \\\"{x:1340,y:762,t:1528139785564};\\\", \\\"{x:1343,y:761,t:1528139785582};\\\", \\\"{x:1344,y:761,t:1528139785638};\\\", \\\"{x:1345,y:761,t:1528139785686};\\\", \\\"{x:1346,y:761,t:1528139785718};\\\", \\\"{x:1347,y:762,t:1528139785733};\\\", \\\"{x:1348,y:763,t:1528139785749};\\\", \\\"{x:1348,y:764,t:1528139785764};\\\", \\\"{x:1349,y:765,t:1528139785782};\\\", \\\"{x:1350,y:767,t:1528139785798};\\\", \\\"{x:1351,y:768,t:1528139785815};\\\", \\\"{x:1351,y:769,t:1528139785934};\\\", \\\"{x:1352,y:770,t:1528139785966};\\\", \\\"{x:1355,y:773,t:1528139785982};\\\", \\\"{x:1356,y:775,t:1528139785997};\\\", \\\"{x:1358,y:778,t:1528139786014};\\\", \\\"{x:1358,y:779,t:1528139786032};\\\", \\\"{x:1359,y:780,t:1528139786049};\\\", \\\"{x:1361,y:782,t:1528139786065};\\\", \\\"{x:1361,y:784,t:1528139786082};\\\", \\\"{x:1362,y:785,t:1528139786099};\\\", \\\"{x:1362,y:786,t:1528139786118};\\\", \\\"{x:1362,y:787,t:1528139786132};\\\", \\\"{x:1364,y:788,t:1528139786148};\\\", \\\"{x:1365,y:790,t:1528139786165};\\\", \\\"{x:1368,y:794,t:1528139786182};\\\", \\\"{x:1370,y:797,t:1528139786198};\\\", \\\"{x:1372,y:800,t:1528139786215};\\\", \\\"{x:1374,y:804,t:1528139786232};\\\", \\\"{x:1376,y:808,t:1528139786249};\\\", \\\"{x:1379,y:813,t:1528139786264};\\\", \\\"{x:1381,y:815,t:1528139786282};\\\", \\\"{x:1385,y:823,t:1528139786298};\\\", \\\"{x:1387,y:829,t:1528139786315};\\\", \\\"{x:1391,y:836,t:1528139786331};\\\", \\\"{x:1392,y:841,t:1528139786348};\\\", \\\"{x:1394,y:843,t:1528139786364};\\\", \\\"{x:1394,y:844,t:1528139786382};\\\", \\\"{x:1394,y:845,t:1528139786399};\\\", \\\"{x:1391,y:841,t:1528139786478};\\\", \\\"{x:1377,y:837,t:1528139786486};\\\", \\\"{x:1359,y:834,t:1528139786498};\\\", \\\"{x:1326,y:828,t:1528139786516};\\\", \\\"{x:1299,y:824,t:1528139786531};\\\", \\\"{x:1278,y:822,t:1528139786549};\\\", \\\"{x:1265,y:815,t:1528139786566};\\\", \\\"{x:1264,y:815,t:1528139786582};\\\", \\\"{x:1264,y:814,t:1528139786599};\\\", \\\"{x:1263,y:812,t:1528139786616};\\\", \\\"{x:1261,y:810,t:1528139786632};\\\", \\\"{x:1258,y:806,t:1528139786649};\\\", \\\"{x:1255,y:803,t:1528139786666};\\\", \\\"{x:1251,y:800,t:1528139786682};\\\", \\\"{x:1246,y:800,t:1528139786699};\\\", \\\"{x:1238,y:797,t:1528139786716};\\\", \\\"{x:1229,y:795,t:1528139786731};\\\", \\\"{x:1225,y:792,t:1528139786749};\\\", \\\"{x:1220,y:791,t:1528139786766};\\\", \\\"{x:1219,y:789,t:1528139786782};\\\", \\\"{x:1217,y:789,t:1528139786799};\\\", \\\"{x:1214,y:787,t:1528139786816};\\\", \\\"{x:1213,y:787,t:1528139786832};\\\", \\\"{x:1211,y:785,t:1528139786849};\\\", \\\"{x:1209,y:785,t:1528139786866};\\\", \\\"{x:1207,y:785,t:1528139786882};\\\", \\\"{x:1206,y:785,t:1528139786899};\\\", \\\"{x:1204,y:784,t:1528139786915};\\\", \\\"{x:1200,y:782,t:1528139786932};\\\", \\\"{x:1198,y:780,t:1528139786949};\\\", \\\"{x:1195,y:780,t:1528139786965};\\\", \\\"{x:1194,y:779,t:1528139786983};\\\", \\\"{x:1191,y:778,t:1528139786999};\\\", \\\"{x:1189,y:777,t:1528139787016};\\\", \\\"{x:1188,y:777,t:1528139787038};\\\", \\\"{x:1188,y:776,t:1528139787048};\\\", \\\"{x:1186,y:775,t:1528139787111};\\\", \\\"{x:1185,y:775,t:1528139787134};\\\", \\\"{x:1184,y:775,t:1528139787148};\\\", \\\"{x:1183,y:775,t:1528139787223};\\\", \\\"{x:1183,y:774,t:1528139787233};\\\", \\\"{x:1181,y:774,t:1528139787262};\\\", \\\"{x:1181,y:773,t:1528139787270};\\\", \\\"{x:1180,y:773,t:1528139787294};\\\", \\\"{x:1180,y:772,t:1528139787302};\\\", \\\"{x:1179,y:772,t:1528139787358};\\\", \\\"{x:1180,y:772,t:1528139787574};\\\", \\\"{x:1181,y:772,t:1528139787598};\\\", \\\"{x:1182,y:772,t:1528139787606};\\\", \\\"{x:1183,y:773,t:1528139787638};\\\", \\\"{x:1183,y:772,t:1528139788198};\\\", \\\"{x:1183,y:771,t:1528139788217};\\\", \\\"{x:1183,y:769,t:1528139788233};\\\", \\\"{x:1182,y:768,t:1528139788250};\\\", \\\"{x:1182,y:767,t:1528139788283};\\\", \\\"{x:1183,y:767,t:1528139788567};\\\", \\\"{x:1184,y:767,t:1528139788622};\\\", \\\"{x:1185,y:767,t:1528139788678};\\\", \\\"{x:1186,y:768,t:1528139789111};\\\", \\\"{x:1186,y:769,t:1528139789126};\\\", \\\"{x:1186,y:770,t:1528139789133};\\\", \\\"{x:1186,y:772,t:1528139789150};\\\", \\\"{x:1186,y:773,t:1528139789167};\\\", \\\"{x:1186,y:775,t:1528139789221};\\\", \\\"{x:1186,y:776,t:1528139789245};\\\", \\\"{x:1187,y:776,t:1528139789253};\\\", \\\"{x:1188,y:777,t:1528139789266};\\\", \\\"{x:1188,y:778,t:1528139789283};\\\", \\\"{x:1189,y:779,t:1528139789301};\\\", \\\"{x:1189,y:781,t:1528139789317};\\\", \\\"{x:1191,y:782,t:1528139789333};\\\", \\\"{x:1192,y:783,t:1528139789350};\\\", \\\"{x:1192,y:785,t:1528139789368};\\\", \\\"{x:1193,y:786,t:1528139789383};\\\", \\\"{x:1193,y:788,t:1528139789405};\\\", \\\"{x:1194,y:788,t:1528139789417};\\\", \\\"{x:1195,y:789,t:1528139789436};\\\", \\\"{x:1195,y:791,t:1528139789450};\\\", \\\"{x:1196,y:792,t:1528139789469};\\\", \\\"{x:1196,y:793,t:1528139789483};\\\", \\\"{x:1197,y:793,t:1528139789501};\\\", \\\"{x:1197,y:795,t:1528139789517};\\\", \\\"{x:1198,y:796,t:1528139789533};\\\", \\\"{x:1198,y:797,t:1528139789556};\\\", \\\"{x:1198,y:798,t:1528139789573};\\\", \\\"{x:1198,y:800,t:1528139789589};\\\", \\\"{x:1199,y:801,t:1528139789601};\\\", \\\"{x:1200,y:804,t:1528139789617};\\\", \\\"{x:1200,y:806,t:1528139789634};\\\", \\\"{x:1201,y:808,t:1528139789651};\\\", \\\"{x:1202,y:812,t:1528139789667};\\\", \\\"{x:1202,y:814,t:1528139789683};\\\", \\\"{x:1203,y:815,t:1528139789701};\\\", \\\"{x:1204,y:817,t:1528139789717};\\\", \\\"{x:1204,y:818,t:1528139789734};\\\", \\\"{x:1205,y:820,t:1528139789751};\\\", \\\"{x:1205,y:823,t:1528139789768};\\\", \\\"{x:1208,y:827,t:1528139789784};\\\", \\\"{x:1211,y:831,t:1528139789801};\\\", \\\"{x:1213,y:834,t:1528139789818};\\\", \\\"{x:1215,y:837,t:1528139789836};\\\", \\\"{x:1218,y:841,t:1528139789851};\\\", \\\"{x:1219,y:843,t:1528139789868};\\\", \\\"{x:1222,y:847,t:1528139789885};\\\", \\\"{x:1224,y:850,t:1528139789901};\\\", \\\"{x:1228,y:856,t:1528139789918};\\\", \\\"{x:1228,y:857,t:1528139789935};\\\", \\\"{x:1230,y:860,t:1528139789951};\\\", \\\"{x:1230,y:861,t:1528139789968};\\\", \\\"{x:1232,y:865,t:1528139789985};\\\", \\\"{x:1234,y:869,t:1528139790001};\\\", \\\"{x:1237,y:875,t:1528139790018};\\\", \\\"{x:1240,y:881,t:1528139790035};\\\", \\\"{x:1242,y:883,t:1528139790051};\\\", \\\"{x:1244,y:886,t:1528139790068};\\\", \\\"{x:1245,y:888,t:1528139790085};\\\", \\\"{x:1247,y:892,t:1528139790101};\\\", \\\"{x:1250,y:897,t:1528139790117};\\\", \\\"{x:1252,y:903,t:1528139790135};\\\", \\\"{x:1255,y:907,t:1528139790151};\\\", \\\"{x:1258,y:912,t:1528139790167};\\\", \\\"{x:1262,y:920,t:1528139790185};\\\", \\\"{x:1267,y:927,t:1528139790201};\\\", \\\"{x:1273,y:936,t:1528139790218};\\\", \\\"{x:1277,y:941,t:1528139790236};\\\", \\\"{x:1280,y:946,t:1528139790251};\\\", \\\"{x:1282,y:951,t:1528139790268};\\\", \\\"{x:1284,y:952,t:1528139790285};\\\", \\\"{x:1284,y:953,t:1528139790302};\\\", \\\"{x:1284,y:954,t:1528139790318};\\\", \\\"{x:1284,y:955,t:1528139790335};\\\", \\\"{x:1285,y:956,t:1528139790352};\\\", \\\"{x:1285,y:957,t:1528139790382};\\\", \\\"{x:1285,y:958,t:1528139790462};\\\", \\\"{x:1286,y:960,t:1528139790470};\\\", \\\"{x:1287,y:960,t:1528139790485};\\\", \\\"{x:1287,y:963,t:1528139790503};\\\", \\\"{x:1287,y:965,t:1528139790518};\\\", \\\"{x:1287,y:967,t:1528139790535};\\\", \\\"{x:1287,y:968,t:1528139790552};\\\", \\\"{x:1287,y:969,t:1528139791110};\\\", \\\"{x:1287,y:970,t:1528139791141};\\\", \\\"{x:1286,y:970,t:1528139791152};\\\", \\\"{x:1284,y:969,t:1528139791169};\\\", \\\"{x:1284,y:968,t:1528139791295};\\\", \\\"{x:1284,y:967,t:1528139791398};\\\", \\\"{x:1285,y:967,t:1528139791430};\\\", \\\"{x:1286,y:967,t:1528139791446};\\\", \\\"{x:1285,y:967,t:1528139791958};\\\", \\\"{x:1284,y:967,t:1528139791974};\\\", \\\"{x:1283,y:967,t:1528139791990};\\\", \\\"{x:1283,y:966,t:1528139792003};\\\", \\\"{x:1282,y:966,t:1528139792020};\\\", \\\"{x:1280,y:965,t:1528139792036};\\\", \\\"{x:1280,y:964,t:1528139792053};\\\", \\\"{x:1280,y:963,t:1528139792069};\\\", \\\"{x:1279,y:962,t:1528139792118};\\\", \\\"{x:1278,y:961,t:1528139793358};\\\", \\\"{x:1277,y:960,t:1528139793374};\\\", \\\"{x:1276,y:960,t:1528139793462};\\\", \\\"{x:1276,y:958,t:1528139793501};\\\", \\\"{x:1276,y:957,t:1528139793518};\\\", \\\"{x:1276,y:956,t:1528139793622};\\\", \\\"{x:1277,y:956,t:1528139793678};\\\", \\\"{x:1278,y:956,t:1528139793687};\\\", \\\"{x:1281,y:956,t:1528139793705};\\\", \\\"{x:1283,y:956,t:1528139793721};\\\", \\\"{x:1284,y:956,t:1528139793737};\\\", \\\"{x:1285,y:956,t:1528139793754};\\\", \\\"{x:1286,y:957,t:1528139793790};\\\", \\\"{x:1286,y:959,t:1528139794062};\\\", \\\"{x:1285,y:960,t:1528139794094};\\\", \\\"{x:1285,y:961,t:1528139794117};\\\", \\\"{x:1284,y:961,t:1528139794166};\\\", \\\"{x:1282,y:961,t:1528139794214};\\\", \\\"{x:1281,y:961,t:1528139794335};\\\", \\\"{x:1281,y:960,t:1528139794526};\\\", \\\"{x:1278,y:957,t:1528139796081};\\\", \\\"{x:1276,y:953,t:1528139796088};\\\", \\\"{x:1274,y:951,t:1528139796099};\\\", \\\"{x:1273,y:947,t:1528139796115};\\\", \\\"{x:1270,y:942,t:1528139796132};\\\", \\\"{x:1270,y:941,t:1528139796149};\\\", \\\"{x:1269,y:939,t:1528139796166};\\\", \\\"{x:1269,y:938,t:1528139796182};\\\", \\\"{x:1269,y:937,t:1528139796199};\\\", \\\"{x:1269,y:934,t:1528139796215};\\\", \\\"{x:1267,y:933,t:1528139796232};\\\", \\\"{x:1267,y:931,t:1528139796249};\\\", \\\"{x:1265,y:928,t:1528139796266};\\\", \\\"{x:1265,y:925,t:1528139796282};\\\", \\\"{x:1262,y:919,t:1528139796299};\\\", \\\"{x:1260,y:912,t:1528139796315};\\\", \\\"{x:1255,y:903,t:1528139796332};\\\", \\\"{x:1250,y:892,t:1528139796349};\\\", \\\"{x:1244,y:880,t:1528139796366};\\\", \\\"{x:1237,y:867,t:1528139796382};\\\", \\\"{x:1230,y:854,t:1528139796399};\\\", \\\"{x:1221,y:835,t:1528139796416};\\\", \\\"{x:1215,y:822,t:1528139796432};\\\", \\\"{x:1207,y:804,t:1528139796449};\\\", \\\"{x:1198,y:786,t:1528139796466};\\\", \\\"{x:1190,y:772,t:1528139796481};\\\", \\\"{x:1183,y:760,t:1528139796499};\\\", \\\"{x:1180,y:755,t:1528139796516};\\\", \\\"{x:1179,y:754,t:1528139796735};\\\", \\\"{x:1179,y:753,t:1528139796748};\\\", \\\"{x:1171,y:749,t:1528139796766};\\\", \\\"{x:1154,y:747,t:1528139796783};\\\", \\\"{x:1128,y:746,t:1528139796799};\\\", \\\"{x:1077,y:745,t:1528139796816};\\\", \\\"{x:1037,y:737,t:1528139796833};\\\", \\\"{x:986,y:721,t:1528139796848};\\\", \\\"{x:928,y:706,t:1528139796866};\\\", \\\"{x:882,y:689,t:1528139796882};\\\", \\\"{x:840,y:676,t:1528139796899};\\\", \\\"{x:806,y:665,t:1528139796915};\\\", \\\"{x:788,y:658,t:1528139796933};\\\", \\\"{x:758,y:649,t:1528139796948};\\\", \\\"{x:737,y:641,t:1528139796966};\\\", \\\"{x:725,y:638,t:1528139796983};\\\", \\\"{x:717,y:633,t:1528139796999};\\\", \\\"{x:715,y:632,t:1528139797015};\\\", \\\"{x:710,y:630,t:1528139797035};\\\", \\\"{x:703,y:627,t:1528139797049};\\\", \\\"{x:683,y:624,t:1528139797064};\\\", \\\"{x:651,y:619,t:1528139797083};\\\", \\\"{x:582,y:610,t:1528139797100};\\\", \\\"{x:499,y:610,t:1528139797117};\\\", \\\"{x:415,y:610,t:1528139797133};\\\", \\\"{x:357,y:610,t:1528139797150};\\\", \\\"{x:293,y:608,t:1528139797166};\\\", \\\"{x:272,y:605,t:1528139797184};\\\", \\\"{x:260,y:603,t:1528139797200};\\\", \\\"{x:259,y:603,t:1528139797217};\\\", \\\"{x:259,y:602,t:1528139797311};\\\", \\\"{x:261,y:598,t:1528139797320};\\\", \\\"{x:264,y:595,t:1528139797334};\\\", \\\"{x:287,y:581,t:1528139797351};\\\", \\\"{x:298,y:575,t:1528139797366};\\\", \\\"{x:314,y:567,t:1528139797383};\\\", \\\"{x:330,y:558,t:1528139797400};\\\", \\\"{x:337,y:552,t:1528139797418};\\\", \\\"{x:338,y:552,t:1528139797433};\\\", \\\"{x:339,y:551,t:1528139797487};\\\", \\\"{x:339,y:550,t:1528139797527};\\\", \\\"{x:336,y:550,t:1528139797534};\\\", \\\"{x:331,y:550,t:1528139797550};\\\", \\\"{x:297,y:550,t:1528139797567};\\\", \\\"{x:261,y:550,t:1528139797586};\\\", \\\"{x:230,y:546,t:1528139797600};\\\", \\\"{x:201,y:544,t:1528139797617};\\\", \\\"{x:190,y:540,t:1528139797634};\\\", \\\"{x:186,y:539,t:1528139797650};\\\", \\\"{x:184,y:536,t:1528139797667};\\\", \\\"{x:182,y:533,t:1528139797684};\\\", \\\"{x:181,y:533,t:1528139797700};\\\", \\\"{x:179,y:531,t:1528139797717};\\\", \\\"{x:178,y:530,t:1528139797734};\\\", \\\"{x:175,y:529,t:1528139797750};\\\", \\\"{x:172,y:527,t:1528139797767};\\\", \\\"{x:171,y:526,t:1528139797785};\\\", \\\"{x:170,y:524,t:1528139797800};\\\", \\\"{x:170,y:521,t:1528139797817};\\\", \\\"{x:168,y:517,t:1528139797835};\\\", \\\"{x:168,y:514,t:1528139797850};\\\", \\\"{x:168,y:511,t:1528139797867};\\\", \\\"{x:167,y:509,t:1528139797884};\\\", \\\"{x:166,y:507,t:1528139797903};\\\", \\\"{x:165,y:507,t:1528139797917};\\\", \\\"{x:164,y:505,t:1528139797934};\\\", \\\"{x:162,y:503,t:1528139797952};\\\", \\\"{x:164,y:503,t:1528139798223};\\\", \\\"{x:169,y:510,t:1528139798234};\\\", \\\"{x:185,y:529,t:1528139798252};\\\", \\\"{x:202,y:551,t:1528139798268};\\\", \\\"{x:229,y:581,t:1528139798286};\\\", \\\"{x:262,y:609,t:1528139798301};\\\", \\\"{x:284,y:625,t:1528139798318};\\\", \\\"{x:312,y:647,t:1528139798335};\\\", \\\"{x:326,y:657,t:1528139798351};\\\", \\\"{x:340,y:668,t:1528139798367};\\\", \\\"{x:357,y:679,t:1528139798385};\\\", \\\"{x:383,y:689,t:1528139798401};\\\", \\\"{x:415,y:699,t:1528139798417};\\\", \\\"{x:442,y:706,t:1528139798434};\\\", \\\"{x:473,y:716,t:1528139798451};\\\", \\\"{x:499,y:722,t:1528139798468};\\\", \\\"{x:525,y:728,t:1528139798483};\\\", \\\"{x:550,y:729,t:1528139798501};\\\", \\\"{x:569,y:729,t:1528139798518};\\\", \\\"{x:579,y:730,t:1528139798534};\\\", \\\"{x:580,y:730,t:1528139798551};\\\", \\\"{x:580,y:731,t:1528139798647};\\\", \\\"{x:580,y:732,t:1528139798655};\\\", \\\"{x:580,y:733,t:1528139798668};\\\", \\\"{x:580,y:735,t:1528139798684};\\\", \\\"{x:576,y:736,t:1528139798701};\\\", \\\"{x:558,y:736,t:1528139798719};\\\", \\\"{x:553,y:736,t:1528139798734};\\\", \\\"{x:546,y:736,t:1528139798752};\\\", \\\"{x:539,y:736,t:1528139798769};\\\", \\\"{x:538,y:736,t:1528139798786};\\\", \\\"{x:536,y:736,t:1528139798814};\\\", \\\"{x:540,y:744,t:1528139799415};\\\", \\\"{x:550,y:786,t:1528139799423};\\\", \\\"{x:566,y:834,t:1528139799435};\\\", \\\"{x:569,y:873,t:1528139799452};\\\", \\\"{x:570,y:873,t:1528139799703};\\\", \\\"{x:571,y:873,t:1528139799815};\\\", \\\"{x:572,y:873,t:1528139799823};\\\", \\\"{x:575,y:873,t:1528139799836};\\\", \\\"{x:578,y:872,t:1528139799852};\\\", \\\"{x:582,y:871,t:1528139799869};\\\", \\\"{x:587,y:868,t:1528139799885};\\\", \\\"{x:591,y:866,t:1528139799902};\\\", \\\"{x:598,y:861,t:1528139799919};\\\", \\\"{x:607,y:856,t:1528139799935};\\\", \\\"{x:617,y:850,t:1528139799952};\\\", \\\"{x:634,y:845,t:1528139799970};\\\", \\\"{x:648,y:841,t:1528139799985};\\\", \\\"{x:662,y:839,t:1528139800011};\\\", \\\"{x:668,y:838,t:1528139800019};\\\", \\\"{x:674,y:837,t:1528139800035};\\\", \\\"{x:682,y:837,t:1528139800052};\\\", \\\"{x:688,y:837,t:1528139800069};\\\", \\\"{x:702,y:837,t:1528139800086};\\\", \\\"{x:708,y:837,t:1528139800102};\\\", \\\"{x:715,y:838,t:1528139800119};\\\", \\\"{x:721,y:839,t:1528139800136};\\\" ] }, { \\\"rt\\\": 10221, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 14, \\\"time_elapsed\\\": 554475, \\\"internal_node_id\\\": \\\"0.0-6.0-4.0\\\", \\\"subject\\\": \\\"JYGX2\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"yankee\\\", \\\"condition\\\": \\\"311\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"ends\\\", \\\"q\\\": 10, \\\"clicks\\\": 1, \\\"explicit\\\": 3, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XInside-YFull\\\", \\\"correct\\\": 1, \\\"orth_correct\\\": 0, \\\"answer\\\": [ \\\"E\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-F -02 PM-E -6\\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:729,y:842,t:1528139800283};\\\", \\\"{x:730,y:842,t:1528139800334};\\\", \\\"{x:731,y:842,t:1528139800343};\\\", \\\"{x:731,y:843,t:1528139800353};\\\", \\\"{x:732,y:843,t:1528139800374};\\\", \\\"{x:733,y:843,t:1528139800422};\\\", \\\"{x:734,y:843,t:1528139800687};\\\", \\\"{x:734,y:844,t:1528139801424};\\\", \\\"{x:734,y:845,t:1528139802423};\\\", \\\"{x:735,y:846,t:1528139802496};\\\", \\\"{x:736,y:847,t:1528139802528};\\\", \\\"{x:739,y:847,t:1528139802538};\\\", \\\"{x:748,y:848,t:1528139802555};\\\", \\\"{x:759,y:848,t:1528139802571};\\\", \\\"{x:778,y:848,t:1528139802588};\\\", \\\"{x:792,y:848,t:1528139802605};\\\", \\\"{x:807,y:848,t:1528139802621};\\\", \\\"{x:818,y:850,t:1528139802638};\\\", \\\"{x:833,y:852,t:1528139802655};\\\", \\\"{x:843,y:854,t:1528139802671};\\\", \\\"{x:857,y:856,t:1528139802687};\\\", \\\"{x:875,y:856,t:1528139802704};\\\", \\\"{x:893,y:856,t:1528139802721};\\\", \\\"{x:920,y:854,t:1528139802737};\\\", \\\"{x:946,y:849,t:1528139802755};\\\", \\\"{x:985,y:843,t:1528139802772};\\\", \\\"{x:1030,y:836,t:1528139802787};\\\", \\\"{x:1083,y:828,t:1528139802805};\\\", \\\"{x:1129,y:825,t:1528139802821};\\\", \\\"{x:1157,y:822,t:1528139802838};\\\", \\\"{x:1201,y:822,t:1528139802854};\\\", \\\"{x:1237,y:822,t:1528139802871};\\\", \\\"{x:1274,y:821,t:1528139802887};\\\", \\\"{x:1298,y:821,t:1528139802904};\\\", \\\"{x:1325,y:821,t:1528139802922};\\\", \\\"{x:1354,y:820,t:1528139802938};\\\", \\\"{x:1363,y:820,t:1528139802955};\\\", \\\"{x:1370,y:820,t:1528139802972};\\\", \\\"{x:1374,y:820,t:1528139802988};\\\", \\\"{x:1375,y:820,t:1528139803005};\\\", \\\"{x:1375,y:819,t:1528139803039};\\\", \\\"{x:1374,y:816,t:1528139803055};\\\", \\\"{x:1367,y:811,t:1528139803071};\\\", \\\"{x:1354,y:803,t:1528139803088};\\\", \\\"{x:1325,y:782,t:1528139803104};\\\", \\\"{x:1287,y:752,t:1528139803121};\\\", \\\"{x:1243,y:714,t:1528139803138};\\\", \\\"{x:1219,y:694,t:1528139803155};\\\", \\\"{x:1210,y:681,t:1528139803172};\\\", \\\"{x:1206,y:668,t:1528139803189};\\\", \\\"{x:1206,y:655,t:1528139803205};\\\", \\\"{x:1209,y:648,t:1528139803222};\\\", \\\"{x:1213,y:642,t:1528139803239};\\\", \\\"{x:1218,y:642,t:1528139803255};\\\", \\\"{x:1227,y:642,t:1528139803272};\\\", \\\"{x:1244,y:642,t:1528139803289};\\\", \\\"{x:1263,y:642,t:1528139803305};\\\", \\\"{x:1284,y:645,t:1528139803322};\\\", \\\"{x:1304,y:658,t:1528139803339};\\\", \\\"{x:1320,y:670,t:1528139803355};\\\", \\\"{x:1333,y:684,t:1528139803372};\\\", \\\"{x:1341,y:696,t:1528139803389};\\\", \\\"{x:1344,y:701,t:1528139803407};\\\", \\\"{x:1346,y:709,t:1528139803421};\\\", \\\"{x:1348,y:719,t:1528139803438};\\\", \\\"{x:1350,y:725,t:1528139803454};\\\", \\\"{x:1353,y:729,t:1528139803472};\\\", \\\"{x:1354,y:732,t:1528139803488};\\\", \\\"{x:1356,y:737,t:1528139803504};\\\", \\\"{x:1358,y:746,t:1528139803522};\\\", \\\"{x:1366,y:761,t:1528139803539};\\\", \\\"{x:1372,y:777,t:1528139803555};\\\", \\\"{x:1381,y:793,t:1528139803571};\\\", \\\"{x:1389,y:806,t:1528139803588};\\\", \\\"{x:1401,y:820,t:1528139803605};\\\", \\\"{x:1411,y:834,t:1528139803622};\\\", \\\"{x:1420,y:844,t:1528139803638};\\\", \\\"{x:1427,y:851,t:1528139803655};\\\", \\\"{x:1431,y:857,t:1528139803672};\\\", \\\"{x:1435,y:861,t:1528139803689};\\\", \\\"{x:1440,y:868,t:1528139803706};\\\", \\\"{x:1441,y:872,t:1528139803722};\\\", \\\"{x:1446,y:878,t:1528139803739};\\\", \\\"{x:1450,y:886,t:1528139803756};\\\", \\\"{x:1455,y:894,t:1528139803772};\\\", \\\"{x:1461,y:903,t:1528139803789};\\\", \\\"{x:1467,y:912,t:1528139803806};\\\", \\\"{x:1472,y:918,t:1528139803822};\\\", \\\"{x:1478,y:927,t:1528139803839};\\\", \\\"{x:1483,y:933,t:1528139803855};\\\", \\\"{x:1488,y:942,t:1528139803872};\\\", \\\"{x:1495,y:950,t:1528139803889};\\\", \\\"{x:1499,y:958,t:1528139803906};\\\", \\\"{x:1505,y:968,t:1528139803922};\\\", \\\"{x:1508,y:971,t:1528139803939};\\\", \\\"{x:1510,y:973,t:1528139803956};\\\", \\\"{x:1511,y:975,t:1528139803972};\\\", \\\"{x:1511,y:976,t:1528139804007};\\\", \\\"{x:1513,y:978,t:1528139804024};\\\", \\\"{x:1513,y:979,t:1528139804038};\\\", \\\"{x:1513,y:980,t:1528139804055};\\\", \\\"{x:1513,y:981,t:1528139804071};\\\", \\\"{x:1513,y:984,t:1528139804089};\\\", \\\"{x:1511,y:984,t:1528139804106};\\\", \\\"{x:1510,y:984,t:1528139804122};\\\", \\\"{x:1507,y:983,t:1528139804139};\\\", \\\"{x:1504,y:981,t:1528139804155};\\\", \\\"{x:1499,y:977,t:1528139804172};\\\", \\\"{x:1496,y:974,t:1528139804188};\\\", \\\"{x:1492,y:972,t:1528139804206};\\\", \\\"{x:1485,y:968,t:1528139804223};\\\", \\\"{x:1484,y:968,t:1528139804239};\\\", \\\"{x:1482,y:967,t:1528139804720};\\\", \\\"{x:1480,y:966,t:1528139804728};\\\", \\\"{x:1477,y:965,t:1528139804740};\\\", \\\"{x:1474,y:963,t:1528139804756};\\\", \\\"{x:1470,y:959,t:1528139804772};\\\", \\\"{x:1465,y:954,t:1528139804789};\\\", \\\"{x:1456,y:945,t:1528139804806};\\\", \\\"{x:1452,y:941,t:1528139804822};\\\", \\\"{x:1451,y:938,t:1528139804840};\\\", \\\"{x:1449,y:936,t:1528139804863};\\\", \\\"{x:1449,y:935,t:1528139804872};\\\", \\\"{x:1447,y:933,t:1528139804890};\\\", \\\"{x:1442,y:926,t:1528139804906};\\\", \\\"{x:1433,y:917,t:1528139804923};\\\", \\\"{x:1423,y:908,t:1528139804940};\\\", \\\"{x:1411,y:898,t:1528139804956};\\\", \\\"{x:1401,y:889,t:1528139804972};\\\", \\\"{x:1388,y:874,t:1528139804990};\\\", \\\"{x:1376,y:855,t:1528139805006};\\\", \\\"{x:1350,y:822,t:1528139805023};\\\", \\\"{x:1334,y:801,t:1528139805040};\\\", \\\"{x:1320,y:779,t:1528139805057};\\\", \\\"{x:1309,y:759,t:1528139805073};\\\", \\\"{x:1301,y:735,t:1528139805091};\\\", \\\"{x:1296,y:712,t:1528139805107};\\\", \\\"{x:1291,y:693,t:1528139805123};\\\", \\\"{x:1284,y:670,t:1528139805140};\\\", \\\"{x:1280,y:650,t:1528139805157};\\\", \\\"{x:1277,y:633,t:1528139805173};\\\", \\\"{x:1276,y:619,t:1528139805190};\\\", \\\"{x:1273,y:608,t:1528139805207};\\\", \\\"{x:1272,y:602,t:1528139805223};\\\", \\\"{x:1271,y:595,t:1528139805240};\\\", \\\"{x:1271,y:587,t:1528139805258};\\\", \\\"{x:1270,y:582,t:1528139805273};\\\", \\\"{x:1269,y:580,t:1528139805290};\\\", \\\"{x:1269,y:579,t:1528139805307};\\\", \\\"{x:1269,y:577,t:1528139805323};\\\", \\\"{x:1269,y:575,t:1528139805340};\\\", \\\"{x:1268,y:574,t:1528139805357};\\\", \\\"{x:1268,y:573,t:1528139805376};\\\", \\\"{x:1268,y:572,t:1528139805390};\\\", \\\"{x:1268,y:569,t:1528139805407};\\\", \\\"{x:1268,y:566,t:1528139805423};\\\", \\\"{x:1268,y:564,t:1528139805440};\\\", \\\"{x:1268,y:563,t:1528139805457};\\\", \\\"{x:1268,y:562,t:1528139805487};\\\", \\\"{x:1268,y:561,t:1528139805632};\\\", \\\"{x:1269,y:561,t:1528139805640};\\\", \\\"{x:1272,y:561,t:1528139805658};\\\", \\\"{x:1275,y:562,t:1528139805674};\\\", \\\"{x:1278,y:563,t:1528139805691};\\\", \\\"{x:1278,y:564,t:1528139805707};\\\", \\\"{x:1279,y:564,t:1528139805724};\\\", \\\"{x:1275,y:564,t:1528139806288};\\\", \\\"{x:1269,y:564,t:1528139806295};\\\", \\\"{x:1260,y:564,t:1528139806307};\\\", \\\"{x:1235,y:564,t:1528139806324};\\\", \\\"{x:1208,y:564,t:1528139806341};\\\", \\\"{x:1182,y:564,t:1528139806357};\\\", \\\"{x:1159,y:564,t:1528139806374};\\\", \\\"{x:1125,y:564,t:1528139806391};\\\", \\\"{x:1102,y:564,t:1528139806407};\\\", \\\"{x:1082,y:564,t:1528139806425};\\\", \\\"{x:1059,y:564,t:1528139806441};\\\", \\\"{x:1033,y:564,t:1528139806458};\\\", \\\"{x:1002,y:563,t:1528139806474};\\\", \\\"{x:974,y:563,t:1528139806491};\\\", \\\"{x:937,y:563,t:1528139806510};\\\", \\\"{x:892,y:563,t:1528139806523};\\\", \\\"{x:859,y:563,t:1528139806540};\\\", \\\"{x:795,y:563,t:1528139806558};\\\", \\\"{x:686,y:563,t:1528139806575};\\\", \\\"{x:630,y:563,t:1528139806590};\\\", \\\"{x:603,y:563,t:1528139806608};\\\", \\\"{x:585,y:563,t:1528139806624};\\\", \\\"{x:578,y:563,t:1528139806641};\\\", \\\"{x:576,y:563,t:1528139806657};\\\", \\\"{x:575,y:562,t:1528139806711};\\\", \\\"{x:575,y:559,t:1528139806725};\\\", \\\"{x:577,y:555,t:1528139806741};\\\", \\\"{x:580,y:550,t:1528139806758};\\\", \\\"{x:584,y:545,t:1528139806774};\\\", \\\"{x:588,y:541,t:1528139806791};\\\", \\\"{x:592,y:537,t:1528139806808};\\\", \\\"{x:599,y:531,t:1528139806824};\\\", \\\"{x:606,y:526,t:1528139806842};\\\", \\\"{x:612,y:519,t:1528139806859};\\\", \\\"{x:618,y:513,t:1528139806875};\\\", \\\"{x:622,y:509,t:1528139806892};\\\", \\\"{x:623,y:508,t:1528139806908};\\\", \\\"{x:625,y:507,t:1528139806925};\\\", \\\"{x:625,y:506,t:1528139806943};\\\", \\\"{x:625,y:504,t:1528139806958};\\\", \\\"{x:628,y:500,t:1528139806975};\\\", \\\"{x:628,y:499,t:1528139807088};\\\", \\\"{x:628,y:498,t:1528139807095};\\\", \\\"{x:626,y:497,t:1528139807108};\\\", \\\"{x:620,y:495,t:1528139807125};\\\", \\\"{x:614,y:492,t:1528139807142};\\\", \\\"{x:612,y:491,t:1528139807158};\\\", \\\"{x:611,y:490,t:1528139807199};\\\", \\\"{x:611,y:496,t:1528139807535};\\\", \\\"{x:611,y:507,t:1528139807543};\\\", \\\"{x:611,y:527,t:1528139807559};\\\", \\\"{x:611,y:545,t:1528139807575};\\\", \\\"{x:611,y:561,t:1528139807592};\\\", \\\"{x:610,y:577,t:1528139807609};\\\", \\\"{x:609,y:595,t:1528139807624};\\\", \\\"{x:606,y:610,t:1528139807642};\\\", \\\"{x:603,y:624,t:1528139807659};\\\", \\\"{x:600,y:635,t:1528139807675};\\\", \\\"{x:596,y:645,t:1528139807691};\\\", \\\"{x:592,y:660,t:1528139807709};\\\", \\\"{x:586,y:673,t:1528139807725};\\\", \\\"{x:581,y:685,t:1528139807742};\\\", \\\"{x:571,y:696,t:1528139807758};\\\", \\\"{x:564,y:700,t:1528139807776};\\\", \\\"{x:555,y:704,t:1528139807792};\\\", \\\"{x:546,y:706,t:1528139807808};\\\", \\\"{x:537,y:707,t:1528139807826};\\\", \\\"{x:528,y:707,t:1528139807841};\\\", \\\"{x:520,y:707,t:1528139807859};\\\", \\\"{x:518,y:707,t:1528139807875};\\\", \\\"{x:517,y:707,t:1528139807892};\\\", \\\"{x:516,y:709,t:1528139807991};\\\", \\\"{x:516,y:716,t:1528139808009};\\\", \\\"{x:516,y:726,t:1528139808028};\\\", \\\"{x:517,y:741,t:1528139808043};\\\", \\\"{x:517,y:756,t:1528139808059};\\\", \\\"{x:517,y:766,t:1528139808076};\\\", \\\"{x:516,y:769,t:1528139808092};\\\", \\\"{x:515,y:770,t:1528139808134};\\\", \\\"{x:514,y:770,t:1528139808158};\\\", \\\"{x:513,y:770,t:1528139808183};\\\", \\\"{x:511,y:769,t:1528139808192};\\\", \\\"{x:511,y:766,t:1528139808209};\\\", \\\"{x:511,y:762,t:1528139808225};\\\", \\\"{x:511,y:758,t:1528139808242};\\\", \\\"{x:510,y:753,t:1528139808260};\\\", \\\"{x:510,y:749,t:1528139808275};\\\", \\\"{x:510,y:748,t:1528139808293};\\\", \\\"{x:510,y:747,t:1528139808327};\\\", \\\"{x:510,y:746,t:1528139808351};\\\", \\\"{x:510,y:745,t:1528139808383};\\\" ] }, { \\\"rt\\\": 18443, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 15, \\\"time_elapsed\\\": 574176, \\\"internal_node_id\\\": \\\"0.0-6.0-5.0\\\", \\\"subject\\\": \\\"JYGX2\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"yankee\\\", \\\"condition\\\": \\\"311\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"starttime\\\", \\\"q\\\": 11, \\\"clicks\\\": 2, \\\"explicit\\\": 3, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XInside-YFull\\\", \\\"correct\\\": 1, \\\"orth_correct\\\": 0, \\\"answer\\\": [ \\\"M\\\", \\\"L\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-09 AM-01 PM-M \\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:511,y:752,t:1528139812430};\\\", \\\"{x:523,y:781,t:1528139812448};\\\", \\\"{x:530,y:803,t:1528139812469};\\\", \\\"{x:535,y:817,t:1528139812478};\\\", \\\"{x:538,y:830,t:1528139812495};\\\", \\\"{x:539,y:840,t:1528139812511};\\\", \\\"{x:540,y:843,t:1528139812529};\\\", \\\"{x:540,y:844,t:1528139812663};\\\", \\\"{x:540,y:845,t:1528139812703};\\\", \\\"{x:541,y:846,t:1528139812735};\\\", \\\"{x:542,y:847,t:1528139812759};\\\", \\\"{x:543,y:848,t:1528139813023};\\\", \\\"{x:544,y:849,t:1528139813031};\\\", \\\"{x:545,y:849,t:1528139813046};\\\", \\\"{x:548,y:850,t:1528139813063};\\\", \\\"{x:549,y:848,t:1528139813079};\\\", \\\"{x:549,y:846,t:1528139813102};\\\", \\\"{x:548,y:845,t:1528139813126};\\\", \\\"{x:549,y:843,t:1528139813470};\\\", \\\"{x:550,y:841,t:1528139813480};\\\", \\\"{x:552,y:839,t:1528139813496};\\\", \\\"{x:552,y:837,t:1528139813512};\\\", \\\"{x:553,y:836,t:1528139813529};\\\", \\\"{x:554,y:835,t:1528139813547};\\\", \\\"{x:555,y:835,t:1528139813566};\\\", \\\"{x:556,y:834,t:1528139813597};\\\", \\\"{x:557,y:833,t:1528139813612};\\\", \\\"{x:558,y:833,t:1528139813629};\\\", \\\"{x:559,y:832,t:1528139813646};\\\", \\\"{x:560,y:832,t:1528139813662};\\\", \\\"{x:561,y:832,t:1528139813919};\\\", \\\"{x:563,y:832,t:1528139813935};\\\", \\\"{x:564,y:832,t:1528139813948};\\\", \\\"{x:570,y:832,t:1528139813963};\\\", \\\"{x:575,y:833,t:1528139813980};\\\", \\\"{x:580,y:833,t:1528139813997};\\\", \\\"{x:587,y:835,t:1528139814013};\\\", \\\"{x:596,y:836,t:1528139814030};\\\", \\\"{x:609,y:838,t:1528139814047};\\\", \\\"{x:616,y:838,t:1528139814064};\\\", \\\"{x:623,y:838,t:1528139814081};\\\", \\\"{x:629,y:838,t:1528139814097};\\\", \\\"{x:638,y:838,t:1528139814114};\\\", \\\"{x:653,y:838,t:1528139814130};\\\", \\\"{x:672,y:838,t:1528139814147};\\\", \\\"{x:694,y:838,t:1528139814164};\\\", \\\"{x:720,y:841,t:1528139814180};\\\", \\\"{x:750,y:849,t:1528139814197};\\\", \\\"{x:786,y:860,t:1528139814214};\\\", \\\"{x:872,y:883,t:1528139814231};\\\", \\\"{x:936,y:902,t:1528139814247};\\\", \\\"{x:997,y:919,t:1528139814265};\\\", \\\"{x:1049,y:941,t:1528139814280};\\\", \\\"{x:1095,y:956,t:1528139814297};\\\", \\\"{x:1151,y:972,t:1528139814315};\\\", \\\"{x:1198,y:986,t:1528139814331};\\\", \\\"{x:1255,y:998,t:1528139814348};\\\", \\\"{x:1303,y:1005,t:1528139814364};\\\", \\\"{x:1329,y:1011,t:1528139814381};\\\", \\\"{x:1350,y:1012,t:1528139814397};\\\", \\\"{x:1364,y:1014,t:1528139814414};\\\", \\\"{x:1375,y:1014,t:1528139814431};\\\", \\\"{x:1395,y:1012,t:1528139814447};\\\", \\\"{x:1405,y:1005,t:1528139814464};\\\", \\\"{x:1409,y:995,t:1528139814480};\\\", \\\"{x:1409,y:986,t:1528139814497};\\\", \\\"{x:1409,y:972,t:1528139814515};\\\", \\\"{x:1407,y:962,t:1528139814531};\\\", \\\"{x:1406,y:953,t:1528139814548};\\\", \\\"{x:1404,y:947,t:1528139814564};\\\", \\\"{x:1402,y:943,t:1528139814582};\\\", \\\"{x:1397,y:937,t:1528139814598};\\\", \\\"{x:1396,y:934,t:1528139814614};\\\", \\\"{x:1392,y:930,t:1528139814631};\\\", \\\"{x:1388,y:929,t:1528139814647};\\\", \\\"{x:1386,y:929,t:1528139814665};\\\", \\\"{x:1385,y:929,t:1528139814682};\\\", \\\"{x:1383,y:929,t:1528139814697};\\\", \\\"{x:1381,y:929,t:1528139814715};\\\", \\\"{x:1379,y:929,t:1528139814731};\\\", \\\"{x:1376,y:929,t:1528139814747};\\\", \\\"{x:1370,y:935,t:1528139814765};\\\", \\\"{x:1365,y:938,t:1528139814781};\\\", \\\"{x:1358,y:944,t:1528139814798};\\\", \\\"{x:1354,y:946,t:1528139814814};\\\", \\\"{x:1353,y:948,t:1528139814831};\\\", \\\"{x:1352,y:949,t:1528139814863};\\\", \\\"{x:1352,y:950,t:1528139814881};\\\", \\\"{x:1351,y:952,t:1528139814898};\\\", \\\"{x:1351,y:955,t:1528139814914};\\\", \\\"{x:1350,y:959,t:1528139814931};\\\", \\\"{x:1348,y:963,t:1528139814948};\\\", \\\"{x:1348,y:964,t:1528139815015};\\\", \\\"{x:1347,y:963,t:1528139815031};\\\", \\\"{x:1347,y:957,t:1528139815049};\\\", \\\"{x:1348,y:950,t:1528139815065};\\\", \\\"{x:1350,y:943,t:1528139815080};\\\", \\\"{x:1355,y:933,t:1528139815098};\\\", \\\"{x:1359,y:924,t:1528139815114};\\\", \\\"{x:1363,y:917,t:1528139815131};\\\", \\\"{x:1365,y:912,t:1528139815147};\\\", \\\"{x:1367,y:910,t:1528139815164};\\\", \\\"{x:1367,y:908,t:1528139815181};\\\", \\\"{x:1368,y:908,t:1528139815198};\\\", \\\"{x:1368,y:907,t:1528139815214};\\\", \\\"{x:1370,y:906,t:1528139815231};\\\", \\\"{x:1372,y:906,t:1528139815278};\\\", \\\"{x:1373,y:906,t:1528139815286};\\\", \\\"{x:1376,y:906,t:1528139815298};\\\", \\\"{x:1377,y:906,t:1528139815528};\\\", \\\"{x:1377,y:905,t:1528139815551};\\\", \\\"{x:1377,y:904,t:1528139815575};\\\", \\\"{x:1377,y:903,t:1528139815583};\\\", \\\"{x:1377,y:902,t:1528139815615};\\\", \\\"{x:1376,y:902,t:1528139815824};\\\", \\\"{x:1376,y:901,t:1528139815832};\\\", \\\"{x:1377,y:901,t:1528139816056};\\\", \\\"{x:1377,y:900,t:1528139816068};\\\", \\\"{x:1379,y:898,t:1528139816082};\\\", \\\"{x:1380,y:898,t:1528139816110};\\\", \\\"{x:1373,y:898,t:1528139818689};\\\", \\\"{x:1354,y:899,t:1528139818700};\\\", \\\"{x:1273,y:902,t:1528139818717};\\\", \\\"{x:1194,y:906,t:1528139818734};\\\", \\\"{x:1090,y:908,t:1528139818751};\\\", \\\"{x:1037,y:908,t:1528139818767};\\\", \\\"{x:1001,y:908,t:1528139818784};\\\", \\\"{x:966,y:908,t:1528139818801};\\\", \\\"{x:941,y:904,t:1528139818817};\\\", \\\"{x:913,y:900,t:1528139818834};\\\", \\\"{x:876,y:892,t:1528139818850};\\\", \\\"{x:835,y:882,t:1528139818867};\\\", \\\"{x:793,y:864,t:1528139818885};\\\", \\\"{x:749,y:846,t:1528139818900};\\\", \\\"{x:723,y:833,t:1528139818917};\\\", \\\"{x:695,y:809,t:1528139818935};\\\", \\\"{x:684,y:789,t:1528139818951};\\\", \\\"{x:674,y:766,t:1528139818967};\\\", \\\"{x:664,y:746,t:1528139818984};\\\", \\\"{x:653,y:732,t:1528139819000};\\\", \\\"{x:645,y:720,t:1528139819018};\\\", \\\"{x:636,y:708,t:1528139819035};\\\", \\\"{x:629,y:694,t:1528139819051};\\\", \\\"{x:621,y:679,t:1528139819068};\\\", \\\"{x:614,y:660,t:1528139819084};\\\", \\\"{x:607,y:636,t:1528139819100};\\\", \\\"{x:599,y:612,t:1528139819119};\\\", \\\"{x:590,y:576,t:1528139819134};\\\", \\\"{x:586,y:553,t:1528139819150};\\\", \\\"{x:581,y:532,t:1528139819167};\\\", \\\"{x:579,y:511,t:1528139819183};\\\", \\\"{x:577,y:502,t:1528139819200};\\\", \\\"{x:575,y:498,t:1528139819217};\\\", \\\"{x:571,y:497,t:1528139819234};\\\", \\\"{x:569,y:496,t:1528139819251};\\\", \\\"{x:567,y:494,t:1528139819267};\\\", \\\"{x:565,y:494,t:1528139819284};\\\", \\\"{x:563,y:494,t:1528139819300};\\\", \\\"{x:559,y:494,t:1528139819317};\\\", \\\"{x:541,y:495,t:1528139819334};\\\", \\\"{x:519,y:499,t:1528139819350};\\\", \\\"{x:497,y:505,t:1528139819368};\\\", \\\"{x:475,y:508,t:1528139819383};\\\", \\\"{x:457,y:511,t:1528139819400};\\\", \\\"{x:443,y:512,t:1528139819418};\\\", \\\"{x:439,y:513,t:1528139819435};\\\", \\\"{x:437,y:513,t:1528139819451};\\\", \\\"{x:437,y:514,t:1528139819468};\\\", \\\"{x:437,y:516,t:1528139819799};\\\", \\\"{x:437,y:517,t:1528139819822};\\\", \\\"{x:437,y:518,t:1528139819840};\\\", \\\"{x:437,y:519,t:1528139819853};\\\", \\\"{x:437,y:520,t:1528139819870};\\\", \\\"{x:437,y:521,t:1528139819902};\\\", \\\"{x:437,y:522,t:1528139819926};\\\", \\\"{x:437,y:523,t:1528139819942};\\\", \\\"{x:437,y:524,t:1528139819951};\\\", \\\"{x:437,y:527,t:1528139819968};\\\", \\\"{x:437,y:529,t:1528139819985};\\\", \\\"{x:437,y:531,t:1528139820001};\\\", \\\"{x:437,y:534,t:1528139820018};\\\", \\\"{x:437,y:536,t:1528139820038};\\\", \\\"{x:437,y:538,t:1528139820071};\\\", \\\"{x:436,y:538,t:1528139820111};\\\", \\\"{x:433,y:540,t:1528139820127};\\\", \\\"{x:430,y:540,t:1528139820135};\\\", \\\"{x:422,y:540,t:1528139820151};\\\", \\\"{x:407,y:540,t:1528139820170};\\\", \\\"{x:385,y:540,t:1528139820185};\\\", \\\"{x:366,y:540,t:1528139820202};\\\", \\\"{x:346,y:540,t:1528139820218};\\\", \\\"{x:327,y:538,t:1528139820235};\\\", \\\"{x:321,y:535,t:1528139820252};\\\", \\\"{x:320,y:535,t:1528139820268};\\\", \\\"{x:321,y:535,t:1528139820335};\\\", \\\"{x:322,y:535,t:1528139820353};\\\", \\\"{x:333,y:537,t:1528139820368};\\\", \\\"{x:352,y:543,t:1528139820385};\\\", \\\"{x:375,y:548,t:1528139820403};\\\", \\\"{x:393,y:549,t:1528139820418};\\\", \\\"{x:402,y:553,t:1528139820435};\\\", \\\"{x:403,y:553,t:1528139820452};\\\", \\\"{x:404,y:553,t:1528139820467};\\\", \\\"{x:402,y:552,t:1528139820582};\\\", \\\"{x:401,y:552,t:1528139820590};\\\", \\\"{x:400,y:552,t:1528139820602};\\\", \\\"{x:396,y:550,t:1528139820619};\\\", \\\"{x:396,y:549,t:1528139820639};\\\", \\\"{x:396,y:553,t:1528139821064};\\\", \\\"{x:396,y:558,t:1528139821071};\\\", \\\"{x:396,y:565,t:1528139821086};\\\", \\\"{x:398,y:578,t:1528139821102};\\\", \\\"{x:399,y:583,t:1528139821119};\\\", \\\"{x:400,y:588,t:1528139821136};\\\", \\\"{x:400,y:590,t:1528139821152};\\\", \\\"{x:400,y:591,t:1528139821169};\\\", \\\"{x:400,y:594,t:1528139821186};\\\", \\\"{x:400,y:595,t:1528139821214};\\\", \\\"{x:400,y:596,t:1528139821222};\\\", \\\"{x:399,y:597,t:1528139821236};\\\", \\\"{x:398,y:599,t:1528139821252};\\\", \\\"{x:397,y:602,t:1528139821270};\\\", \\\"{x:396,y:604,t:1528139821286};\\\", \\\"{x:395,y:606,t:1528139821301};\\\", \\\"{x:394,y:607,t:1528139821351};\\\", \\\"{x:394,y:608,t:1528139821367};\\\", \\\"{x:394,y:609,t:1528139821374};\\\", \\\"{x:394,y:610,t:1528139821398};\\\", \\\"{x:394,y:612,t:1528139821606};\\\", \\\"{x:396,y:614,t:1528139821619};\\\", \\\"{x:407,y:619,t:1528139821636};\\\", \\\"{x:415,y:624,t:1528139821653};\\\", \\\"{x:424,y:630,t:1528139821669};\\\", \\\"{x:439,y:642,t:1528139821687};\\\", \\\"{x:458,y:654,t:1528139821703};\\\", \\\"{x:481,y:671,t:1528139821720};\\\", \\\"{x:505,y:688,t:1528139821736};\\\", \\\"{x:525,y:702,t:1528139821753};\\\", \\\"{x:540,y:714,t:1528139821770};\\\", \\\"{x:549,y:721,t:1528139821786};\\\", \\\"{x:554,y:726,t:1528139821803};\\\", \\\"{x:555,y:728,t:1528139821819};\\\", \\\"{x:555,y:729,t:1528139821927};\\\", \\\"{x:554,y:729,t:1528139821936};\\\", \\\"{x:552,y:729,t:1528139821954};\\\", \\\"{x:548,y:729,t:1528139821971};\\\", \\\"{x:545,y:729,t:1528139821986};\\\", \\\"{x:541,y:729,t:1528139822004};\\\", \\\"{x:539,y:729,t:1528139822020};\\\", \\\"{x:537,y:728,t:1528139822037};\\\", \\\"{x:536,y:728,t:1528139822055};\\\", \\\"{x:535,y:728,t:1528139822070};\\\", \\\"{x:533,y:728,t:1528139822087};\\\", \\\"{x:532,y:728,t:1528139822104};\\\", \\\"{x:527,y:729,t:1528139822120};\\\", \\\"{x:520,y:732,t:1528139822136};\\\", \\\"{x:516,y:733,t:1528139822153};\\\", \\\"{x:511,y:735,t:1528139822171};\\\", \\\"{x:508,y:736,t:1528139822186};\\\", \\\"{x:507,y:736,t:1528139822203};\\\", \\\"{x:505,y:736,t:1528139822230};\\\" ] }, { \\\"rt\\\": 17074, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 16, \\\"time_elapsed\\\": 592459, \\\"internal_node_id\\\": \\\"0.0-6.0-6.0\\\", \\\"subject\\\": \\\"JYGX2\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"yankee\\\", \\\"condition\\\": \\\"311\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"starts\\\", \\\"q\\\": 12, \\\"clicks\\\": 1, \\\"explicit\\\": 3, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XInside-YFull\\\", \\\"correct\\\": 1, \\\"orth_correct\\\": 0, \\\"answer\\\": [ \\\"G\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-J -2-I -F -F \\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:505,y:738,t:1528139832087};\\\", \\\"{x:504,y:758,t:1528139832095};\\\", \\\"{x:497,y:824,t:1528139832111};\\\", \\\"{x:485,y:886,t:1528139832127};\\\", \\\"{x:480,y:939,t:1528139832145};\\\", \\\"{x:481,y:939,t:1528139832326};\\\", \\\"{x:483,y:937,t:1528139832334};\\\", \\\"{x:485,y:932,t:1528139832344};\\\", \\\"{x:494,y:920,t:1528139832362};\\\", \\\"{x:501,y:907,t:1528139832378};\\\", \\\"{x:509,y:892,t:1528139832395};\\\", \\\"{x:515,y:873,t:1528139832412};\\\", \\\"{x:519,y:860,t:1528139832428};\\\", \\\"{x:521,y:853,t:1528139832444};\\\", \\\"{x:522,y:852,t:1528139832461};\\\", \\\"{x:522,y:850,t:1528139832478};\\\", \\\"{x:525,y:849,t:1528139834047};\\\", \\\"{x:574,y:849,t:1528139834063};\\\", \\\"{x:653,y:846,t:1528139834080};\\\", \\\"{x:736,y:846,t:1528139834097};\\\", \\\"{x:827,y:846,t:1528139834113};\\\", \\\"{x:889,y:846,t:1528139834130};\\\", \\\"{x:939,y:846,t:1528139834147};\\\", \\\"{x:970,y:846,t:1528139834164};\\\", \\\"{x:998,y:846,t:1528139834181};\\\", \\\"{x:1020,y:843,t:1528139834197};\\\", \\\"{x:1041,y:842,t:1528139834214};\\\", \\\"{x:1057,y:841,t:1528139834231};\\\", \\\"{x:1084,y:837,t:1528139834247};\\\", \\\"{x:1108,y:835,t:1528139834264};\\\", \\\"{x:1133,y:830,t:1528139834280};\\\", \\\"{x:1156,y:829,t:1528139834297};\\\", \\\"{x:1175,y:829,t:1528139834314};\\\", \\\"{x:1184,y:829,t:1528139834330};\\\", \\\"{x:1197,y:829,t:1528139834348};\\\", \\\"{x:1208,y:829,t:1528139834364};\\\", \\\"{x:1212,y:829,t:1528139834383};\\\", \\\"{x:1217,y:830,t:1528139834397};\\\", \\\"{x:1221,y:830,t:1528139834416};\\\", \\\"{x:1225,y:831,t:1528139834431};\\\", \\\"{x:1226,y:831,t:1528139834447};\\\", \\\"{x:1227,y:831,t:1528139834479};\\\", \\\"{x:1229,y:831,t:1528139835007};\\\", \\\"{x:1230,y:831,t:1528139835023};\\\", \\\"{x:1230,y:829,t:1528139835047};\\\", \\\"{x:1231,y:827,t:1528139835064};\\\", \\\"{x:1232,y:825,t:1528139835081};\\\", \\\"{x:1232,y:824,t:1528139835098};\\\", \\\"{x:1233,y:823,t:1528139835114};\\\", \\\"{x:1234,y:823,t:1528139835151};\\\", \\\"{x:1236,y:822,t:1528139835166};\\\", \\\"{x:1238,y:817,t:1528139835181};\\\", \\\"{x:1245,y:800,t:1528139835199};\\\", \\\"{x:1258,y:769,t:1528139835214};\\\", \\\"{x:1267,y:745,t:1528139835232};\\\", \\\"{x:1278,y:724,t:1528139835248};\\\", \\\"{x:1284,y:709,t:1528139835265};\\\", \\\"{x:1288,y:697,t:1528139835281};\\\", \\\"{x:1293,y:687,t:1528139835298};\\\", \\\"{x:1296,y:680,t:1528139835315};\\\", \\\"{x:1300,y:673,t:1528139835331};\\\", \\\"{x:1301,y:665,t:1528139835348};\\\", \\\"{x:1304,y:656,t:1528139835365};\\\", \\\"{x:1306,y:652,t:1528139835382};\\\", \\\"{x:1308,y:648,t:1528139835399};\\\", \\\"{x:1308,y:647,t:1528139835415};\\\", \\\"{x:1308,y:646,t:1528139835512};\\\", \\\"{x:1307,y:651,t:1528139835743};\\\", \\\"{x:1297,y:665,t:1528139835751};\\\", \\\"{x:1290,y:675,t:1528139835766};\\\", \\\"{x:1261,y:707,t:1528139835782};\\\", \\\"{x:1245,y:723,t:1528139835799};\\\", \\\"{x:1232,y:736,t:1528139835815};\\\", \\\"{x:1221,y:745,t:1528139835832};\\\", \\\"{x:1219,y:746,t:1528139835849};\\\", \\\"{x:1218,y:748,t:1528139835865};\\\", \\\"{x:1217,y:749,t:1528139835882};\\\", \\\"{x:1216,y:751,t:1528139835899};\\\", \\\"{x:1215,y:754,t:1528139835915};\\\", \\\"{x:1214,y:757,t:1528139835932};\\\", \\\"{x:1212,y:762,t:1528139835949};\\\", \\\"{x:1212,y:763,t:1528139835965};\\\", \\\"{x:1211,y:767,t:1528139835982};\\\", \\\"{x:1210,y:769,t:1528139835999};\\\", \\\"{x:1209,y:773,t:1528139836015};\\\", \\\"{x:1207,y:779,t:1528139836032};\\\", \\\"{x:1206,y:783,t:1528139836049};\\\", \\\"{x:1204,y:788,t:1528139836065};\\\", \\\"{x:1203,y:792,t:1528139836082};\\\", \\\"{x:1202,y:796,t:1528139836100};\\\", \\\"{x:1201,y:801,t:1528139836116};\\\", \\\"{x:1200,y:805,t:1528139836132};\\\", \\\"{x:1200,y:806,t:1528139836150};\\\", \\\"{x:1200,y:807,t:1528139836166};\\\", \\\"{x:1200,y:809,t:1528139836271};\\\", \\\"{x:1197,y:811,t:1528139836807};\\\", \\\"{x:1193,y:814,t:1528139836816};\\\", \\\"{x:1172,y:817,t:1528139836833};\\\", \\\"{x:1147,y:822,t:1528139836850};\\\", \\\"{x:1111,y:823,t:1528139836866};\\\", \\\"{x:1059,y:829,t:1528139836884};\\\", \\\"{x:988,y:834,t:1528139836901};\\\", \\\"{x:924,y:834,t:1528139836916};\\\", \\\"{x:891,y:835,t:1528139836933};\\\", \\\"{x:846,y:838,t:1528139836951};\\\", \\\"{x:831,y:838,t:1528139836966};\\\", \\\"{x:826,y:837,t:1528139836983};\\\", \\\"{x:825,y:835,t:1528139837000};\\\", \\\"{x:824,y:833,t:1528139837016};\\\", \\\"{x:824,y:832,t:1528139837055};\\\", \\\"{x:825,y:832,t:1528139837127};\\\", \\\"{x:826,y:832,t:1528139837134};\\\", \\\"{x:834,y:830,t:1528139837150};\\\", \\\"{x:836,y:830,t:1528139837167};\\\", \\\"{x:839,y:829,t:1528139837183};\\\", \\\"{x:841,y:829,t:1528139837200};\\\", \\\"{x:842,y:829,t:1528139837217};\\\", \\\"{x:843,y:829,t:1528139837234};\\\", \\\"{x:845,y:829,t:1528139837250};\\\", \\\"{x:846,y:829,t:1528139837267};\\\", \\\"{x:847,y:829,t:1528139837283};\\\", \\\"{x:848,y:829,t:1528139837300};\\\", \\\"{x:852,y:829,t:1528139837317};\\\", \\\"{x:855,y:826,t:1528139837333};\\\", \\\"{x:868,y:824,t:1528139837350};\\\", \\\"{x:875,y:821,t:1528139837366};\\\", \\\"{x:880,y:821,t:1528139837383};\\\", \\\"{x:882,y:820,t:1528139837400};\\\", \\\"{x:883,y:820,t:1528139837417};\\\", \\\"{x:884,y:820,t:1528139837566};\\\", \\\"{x:885,y:820,t:1528139839631};\\\", \\\"{x:886,y:820,t:1528139839662};\\\", \\\"{x:889,y:818,t:1528139839671};\\\", \\\"{x:891,y:816,t:1528139839686};\\\", \\\"{x:893,y:813,t:1528139839702};\\\", \\\"{x:895,y:811,t:1528139839719};\\\", \\\"{x:896,y:809,t:1528139839736};\\\", \\\"{x:896,y:808,t:1528139839752};\\\", \\\"{x:897,y:807,t:1528139839769};\\\", \\\"{x:898,y:807,t:1528139839787};\\\", \\\"{x:899,y:806,t:1528139839951};\\\", \\\"{x:899,y:805,t:1528139839959};\\\", \\\"{x:899,y:804,t:1528139839990};\\\", \\\"{x:899,y:803,t:1528139840087};\\\", \\\"{x:899,y:802,t:1528139840118};\\\", \\\"{x:907,y:802,t:1528139840999};\\\", \\\"{x:923,y:802,t:1528139841006};\\\", \\\"{x:948,y:802,t:1528139841020};\\\", \\\"{x:1012,y:793,t:1528139841038};\\\", \\\"{x:1119,y:777,t:1528139841055};\\\", \\\"{x:1187,y:763,t:1528139841072};\\\", \\\"{x:1244,y:752,t:1528139841089};\\\", \\\"{x:1278,y:742,t:1528139841104};\\\", \\\"{x:1293,y:736,t:1528139841122};\\\", \\\"{x:1297,y:732,t:1528139841137};\\\", \\\"{x:1299,y:730,t:1528139841154};\\\", \\\"{x:1301,y:726,t:1528139841172};\\\", \\\"{x:1302,y:717,t:1528139841187};\\\", \\\"{x:1305,y:708,t:1528139841204};\\\", \\\"{x:1312,y:701,t:1528139841221};\\\", \\\"{x:1321,y:692,t:1528139841237};\\\", \\\"{x:1338,y:677,t:1528139841253};\\\", \\\"{x:1345,y:673,t:1528139841271};\\\", \\\"{x:1346,y:672,t:1528139841287};\\\", \\\"{x:1348,y:672,t:1528139841342};\\\", \\\"{x:1349,y:672,t:1528139841358};\\\", \\\"{x:1352,y:672,t:1528139841374};\\\", \\\"{x:1352,y:674,t:1528139841386};\\\", \\\"{x:1352,y:676,t:1528139841404};\\\", \\\"{x:1352,y:678,t:1528139841421};\\\", \\\"{x:1354,y:680,t:1528139841437};\\\", \\\"{x:1354,y:683,t:1528139841454};\\\", \\\"{x:1354,y:687,t:1528139841471};\\\", \\\"{x:1354,y:692,t:1528139841488};\\\", \\\"{x:1354,y:695,t:1528139841504};\\\", \\\"{x:1354,y:696,t:1528139841655};\\\", \\\"{x:1353,y:698,t:1528139841671};\\\", \\\"{x:1351,y:701,t:1528139841688};\\\", \\\"{x:1350,y:702,t:1528139841705};\\\", \\\"{x:1348,y:704,t:1528139841721};\\\", \\\"{x:1347,y:705,t:1528139841739};\\\", \\\"{x:1345,y:706,t:1528139841754};\\\", \\\"{x:1344,y:706,t:1528139841798};\\\", \\\"{x:1343,y:706,t:1528139841806};\\\", \\\"{x:1342,y:706,t:1528139841823};\\\", \\\"{x:1341,y:706,t:1528139841855};\\\", \\\"{x:1340,y:706,t:1528139841872};\\\", \\\"{x:1339,y:706,t:1528139841983};\\\", \\\"{x:1339,y:704,t:1528139842151};\\\", \\\"{x:1341,y:701,t:1528139842166};\\\", \\\"{x:1341,y:699,t:1528139842182};\\\", \\\"{x:1343,y:698,t:1528139842191};\\\", \\\"{x:1343,y:697,t:1528139842222};\\\", \\\"{x:1345,y:697,t:1528139842375};\\\", \\\"{x:1346,y:697,t:1528139842575};\\\", \\\"{x:1347,y:698,t:1528139842902};\\\", \\\"{x:1335,y:698,t:1528139844551};\\\", \\\"{x:1308,y:698,t:1528139844558};\\\", \\\"{x:1246,y:698,t:1528139844574};\\\", \\\"{x:1168,y:698,t:1528139844592};\\\", \\\"{x:1094,y:690,t:1528139844608};\\\", \\\"{x:1026,y:678,t:1528139844624};\\\", \\\"{x:980,y:668,t:1528139844642};\\\", \\\"{x:942,y:662,t:1528139844658};\\\", \\\"{x:913,y:656,t:1528139844675};\\\", \\\"{x:887,y:655,t:1528139844691};\\\", \\\"{x:865,y:650,t:1528139844708};\\\", \\\"{x:847,y:646,t:1528139844725};\\\", \\\"{x:825,y:639,t:1528139844741};\\\", \\\"{x:803,y:634,t:1528139844758};\\\", \\\"{x:785,y:628,t:1528139844776};\\\", \\\"{x:763,y:621,t:1528139844792};\\\", \\\"{x:736,y:615,t:1528139844808};\\\", \\\"{x:724,y:613,t:1528139844821};\\\", \\\"{x:685,y:600,t:1528139844837};\\\", \\\"{x:658,y:588,t:1528139844855};\\\", \\\"{x:638,y:577,t:1528139844871};\\\", \\\"{x:608,y:564,t:1528139844888};\\\", \\\"{x:586,y:555,t:1528139844905};\\\", \\\"{x:564,y:546,t:1528139844920};\\\", \\\"{x:546,y:537,t:1528139844938};\\\", \\\"{x:526,y:531,t:1528139844955};\\\", \\\"{x:510,y:529,t:1528139844971};\\\", \\\"{x:494,y:526,t:1528139844989};\\\", \\\"{x:478,y:525,t:1528139845005};\\\", \\\"{x:462,y:522,t:1528139845022};\\\", \\\"{x:435,y:519,t:1528139845037};\\\", \\\"{x:420,y:517,t:1528139845056};\\\", \\\"{x:405,y:517,t:1528139845071};\\\", \\\"{x:391,y:517,t:1528139845088};\\\", \\\"{x:380,y:517,t:1528139845104};\\\", \\\"{x:371,y:517,t:1528139845121};\\\", \\\"{x:369,y:516,t:1528139845138};\\\", \\\"{x:368,y:515,t:1528139845154};\\\", \\\"{x:368,y:516,t:1528139845438};\\\", \\\"{x:368,y:517,t:1528139845559};\\\", \\\"{x:368,y:518,t:1528139845573};\\\", \\\"{x:367,y:519,t:1528139845587};\\\", \\\"{x:366,y:520,t:1528139845604};\\\", \\\"{x:365,y:522,t:1528139845622};\\\", \\\"{x:365,y:523,t:1528139845645};\\\", \\\"{x:366,y:525,t:1528139845832};\\\", \\\"{x:374,y:525,t:1528139845909};\\\", \\\"{x:378,y:525,t:1528139845922};\\\", \\\"{x:386,y:524,t:1528139845939};\\\", \\\"{x:395,y:524,t:1528139845955};\\\", \\\"{x:404,y:526,t:1528139845973};\\\", \\\"{x:416,y:527,t:1528139845989};\\\", \\\"{x:432,y:530,t:1528139846005};\\\", \\\"{x:463,y:530,t:1528139846021};\\\", \\\"{x:494,y:530,t:1528139846038};\\\", \\\"{x:525,y:530,t:1528139846056};\\\", \\\"{x:548,y:532,t:1528139846072};\\\", \\\"{x:569,y:537,t:1528139846089};\\\", \\\"{x:581,y:538,t:1528139846105};\\\", \\\"{x:584,y:539,t:1528139846122};\\\", \\\"{x:585,y:540,t:1528139846139};\\\", \\\"{x:585,y:542,t:1528139846174};\\\", \\\"{x:581,y:543,t:1528139846189};\\\", \\\"{x:561,y:547,t:1528139846205};\\\", \\\"{x:524,y:551,t:1528139846222};\\\", \\\"{x:504,y:552,t:1528139846241};\\\", \\\"{x:483,y:552,t:1528139846257};\\\", \\\"{x:456,y:552,t:1528139846271};\\\", \\\"{x:442,y:552,t:1528139846289};\\\", \\\"{x:431,y:554,t:1528139846305};\\\", \\\"{x:424,y:554,t:1528139846322};\\\", \\\"{x:418,y:554,t:1528139846339};\\\", \\\"{x:411,y:554,t:1528139846355};\\\", \\\"{x:404,y:554,t:1528139846372};\\\", \\\"{x:398,y:554,t:1528139846389};\\\", \\\"{x:382,y:554,t:1528139846405};\\\", \\\"{x:364,y:554,t:1528139846422};\\\", \\\"{x:349,y:556,t:1528139846440};\\\", \\\"{x:333,y:555,t:1528139846456};\\\", \\\"{x:327,y:554,t:1528139846472};\\\", \\\"{x:326,y:553,t:1528139846489};\\\", \\\"{x:323,y:552,t:1528139846517};\\\", \\\"{x:321,y:551,t:1528139846526};\\\", \\\"{x:319,y:551,t:1528139846549};\\\", \\\"{x:317,y:551,t:1528139846557};\\\", \\\"{x:316,y:551,t:1528139846572};\\\", \\\"{x:311,y:551,t:1528139846589};\\\", \\\"{x:307,y:550,t:1528139846605};\\\", \\\"{x:304,y:550,t:1528139846621};\\\", \\\"{x:300,y:550,t:1528139846640};\\\", \\\"{x:299,y:550,t:1528139846656};\\\", \\\"{x:299,y:551,t:1528139846687};\\\", \\\"{x:299,y:553,t:1528139846702};\\\", \\\"{x:299,y:554,t:1528139846998};\\\", \\\"{x:308,y:555,t:1528139847007};\\\", \\\"{x:331,y:558,t:1528139847025};\\\", \\\"{x:387,y:558,t:1528139847040};\\\", \\\"{x:448,y:558,t:1528139847055};\\\", \\\"{x:512,y:558,t:1528139847072};\\\", \\\"{x:559,y:556,t:1528139847089};\\\", \\\"{x:591,y:552,t:1528139847105};\\\", \\\"{x:613,y:550,t:1528139847122};\\\", \\\"{x:625,y:550,t:1528139847139};\\\", \\\"{x:638,y:550,t:1528139847156};\\\", \\\"{x:653,y:550,t:1528139847174};\\\", \\\"{x:673,y:550,t:1528139847189};\\\", \\\"{x:713,y:550,t:1528139847206};\\\", \\\"{x:743,y:547,t:1528139847224};\\\", \\\"{x:774,y:547,t:1528139847240};\\\", \\\"{x:799,y:545,t:1528139847256};\\\", \\\"{x:821,y:545,t:1528139847273};\\\", \\\"{x:832,y:545,t:1528139847289};\\\", \\\"{x:835,y:545,t:1528139847306};\\\", \\\"{x:836,y:545,t:1528139847325};\\\", \\\"{x:836,y:546,t:1528139847340};\\\", \\\"{x:836,y:547,t:1528139847358};\\\", \\\"{x:836,y:548,t:1528139847373};\\\", \\\"{x:836,y:549,t:1528139847391};\\\", \\\"{x:836,y:550,t:1528139847710};\\\", \\\"{x:836,y:551,t:1528139847723};\\\", \\\"{x:836,y:553,t:1528139847740};\\\", \\\"{x:830,y:556,t:1528139847758};\\\", \\\"{x:821,y:562,t:1528139847773};\\\", \\\"{x:794,y:580,t:1528139847790};\\\", \\\"{x:766,y:597,t:1528139847808};\\\", \\\"{x:717,y:620,t:1528139847823};\\\", \\\"{x:659,y:648,t:1528139847841};\\\", \\\"{x:598,y:676,t:1528139847857};\\\", \\\"{x:556,y:694,t:1528139847873};\\\", \\\"{x:525,y:708,t:1528139847891};\\\", \\\"{x:507,y:716,t:1528139847906};\\\", \\\"{x:497,y:720,t:1528139847925};\\\", \\\"{x:493,y:722,t:1528139847940};\\\", \\\"{x:491,y:725,t:1528139847957};\\\", \\\"{x:491,y:730,t:1528139847974};\\\", \\\"{x:490,y:735,t:1528139847990};\\\", \\\"{x:488,y:743,t:1528139848008};\\\", \\\"{x:484,y:749,t:1528139848024};\\\", \\\"{x:482,y:751,t:1528139848040};\\\", \\\"{x:477,y:756,t:1528139848057};\\\", \\\"{x:471,y:760,t:1528139848074};\\\", \\\"{x:464,y:765,t:1528139848090};\\\", \\\"{x:461,y:767,t:1528139848107};\\\", \\\"{x:461,y:764,t:1528139848166};\\\", \\\"{x:462,y:761,t:1528139848174};\\\", \\\"{x:468,y:756,t:1528139848191};\\\", \\\"{x:478,y:748,t:1528139848208};\\\", \\\"{x:489,y:740,t:1528139848223};\\\", \\\"{x:494,y:736,t:1528139848240};\\\", \\\"{x:495,y:735,t:1528139848257};\\\", \\\"{x:495,y:734,t:1528139848286};\\\", \\\"{x:500,y:734,t:1528139848734};\\\", \\\"{x:512,y:752,t:1528139848742};\\\", \\\"{x:533,y:778,t:1528139848758};\\\", \\\"{x:595,y:846,t:1528139848774};\\\", \\\"{x:638,y:882,t:1528139848791};\\\", \\\"{x:668,y:909,t:1528139848808};\\\", \\\"{x:674,y:914,t:1528139848824};\\\", \\\"{x:675,y:916,t:1528139848842};\\\", \\\"{x:681,y:920,t:1528139848857};\\\", \\\"{x:683,y:919,t:1528139849119};\\\", \\\"{x:683,y:917,t:1528139849126};\\\", \\\"{x:685,y:915,t:1528139849142};\\\", \\\"{x:686,y:912,t:1528139849158};\\\", \\\"{x:687,y:909,t:1528139849174};\\\", \\\"{x:688,y:906,t:1528139849191};\\\", \\\"{x:689,y:904,t:1528139849208};\\\", \\\"{x:689,y:903,t:1528139849224};\\\", \\\"{x:690,y:902,t:1528139849241};\\\", \\\"{x:690,y:901,t:1528139849278};\\\" ] }, { \\\"rt\\\": 14550, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 17, \\\"time_elapsed\\\": 608231, \\\"internal_node_id\\\": \\\"0.0-6.0-7.0\\\", \\\"subject\\\": \\\"JYGX2\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"yankee\\\", \\\"condition\\\": \\\"311\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"meets\\\", \\\"q\\\": 13, \\\"clicks\\\": 2.5, \\\"explicit\\\": 3, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XInside-YFull\\\", \\\"correct\\\": 1, \\\"orth_correct\\\": 0, \\\"answer\\\": [ \\\"E\\\", \\\"F\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-02 PM\\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:693,y:900,t:1528139849715};\\\", \\\"{x:699,y:901,t:1528139852703};\\\", \\\"{x:709,y:905,t:1528139852711};\\\", \\\"{x:737,y:912,t:1528139852728};\\\", \\\"{x:773,y:912,t:1528139852743};\\\", \\\"{x:804,y:917,t:1528139852760};\\\", \\\"{x:834,y:919,t:1528139852777};\\\", \\\"{x:851,y:923,t:1528139852794};\\\", \\\"{x:864,y:926,t:1528139852819};\\\", \\\"{x:867,y:927,t:1528139852828};\\\", \\\"{x:877,y:927,t:1528139852845};\\\", \\\"{x:893,y:927,t:1528139852860};\\\", \\\"{x:923,y:927,t:1528139852877};\\\", \\\"{x:925,y:927,t:1528139852894};\\\", \\\"{x:926,y:927,t:1528139852911};\\\", \\\"{x:927,y:927,t:1528139853231};\\\", \\\"{x:931,y:925,t:1528139853245};\\\", \\\"{x:951,y:917,t:1528139853261};\\\", \\\"{x:997,y:909,t:1528139853278};\\\", \\\"{x:1102,y:890,t:1528139853295};\\\", \\\"{x:1176,y:875,t:1528139853312};\\\", \\\"{x:1243,y:865,t:1528139853328};\\\", \\\"{x:1285,y:859,t:1528139853344};\\\", \\\"{x:1328,y:851,t:1528139853362};\\\", \\\"{x:1356,y:846,t:1528139853378};\\\", \\\"{x:1387,y:839,t:1528139853395};\\\", \\\"{x:1417,y:832,t:1528139853412};\\\", \\\"{x:1448,y:822,t:1528139853428};\\\", \\\"{x:1481,y:809,t:1528139853445};\\\", \\\"{x:1521,y:796,t:1528139853462};\\\", \\\"{x:1538,y:788,t:1528139853479};\\\", \\\"{x:1551,y:779,t:1528139853494};\\\", \\\"{x:1566,y:768,t:1528139853512};\\\", \\\"{x:1580,y:754,t:1528139853528};\\\", \\\"{x:1594,y:737,t:1528139853545};\\\", \\\"{x:1606,y:720,t:1528139853562};\\\", \\\"{x:1614,y:703,t:1528139853578};\\\", \\\"{x:1621,y:687,t:1528139853595};\\\", \\\"{x:1625,y:671,t:1528139853612};\\\", \\\"{x:1630,y:652,t:1528139853628};\\\", \\\"{x:1631,y:642,t:1528139853645};\\\", \\\"{x:1632,y:638,t:1528139853662};\\\", \\\"{x:1632,y:636,t:1528139853678};\\\", \\\"{x:1632,y:635,t:1528139853702};\\\", \\\"{x:1631,y:635,t:1528139853807};\\\", \\\"{x:1628,y:640,t:1528139853815};\\\", \\\"{x:1622,y:650,t:1528139853828};\\\", \\\"{x:1611,y:665,t:1528139853844};\\\", \\\"{x:1595,y:686,t:1528139853862};\\\", \\\"{x:1588,y:697,t:1528139853878};\\\", \\\"{x:1585,y:703,t:1528139853894};\\\", \\\"{x:1585,y:705,t:1528139853911};\\\", \\\"{x:1585,y:706,t:1528139853982};\\\", \\\"{x:1586,y:706,t:1528139854086};\\\", \\\"{x:1590,y:706,t:1528139854095};\\\", \\\"{x:1600,y:704,t:1528139854112};\\\", \\\"{x:1611,y:702,t:1528139854129};\\\", \\\"{x:1620,y:701,t:1528139854145};\\\", \\\"{x:1623,y:700,t:1528139854161};\\\", \\\"{x:1624,y:700,t:1528139854207};\\\", \\\"{x:1624,y:703,t:1528139854295};\\\", \\\"{x:1620,y:717,t:1528139854312};\\\", \\\"{x:1614,y:735,t:1528139854329};\\\", \\\"{x:1607,y:753,t:1528139854346};\\\", \\\"{x:1599,y:770,t:1528139854362};\\\", \\\"{x:1593,y:781,t:1528139854379};\\\", \\\"{x:1589,y:790,t:1528139854396};\\\", \\\"{x:1586,y:797,t:1528139854412};\\\", \\\"{x:1583,y:802,t:1528139854429};\\\", \\\"{x:1576,y:813,t:1528139854447};\\\", \\\"{x:1573,y:819,t:1528139854462};\\\", \\\"{x:1570,y:825,t:1528139854478};\\\", \\\"{x:1562,y:834,t:1528139854496};\\\", \\\"{x:1559,y:839,t:1528139854512};\\\", \\\"{x:1553,y:847,t:1528139854529};\\\", \\\"{x:1549,y:855,t:1528139854546};\\\", \\\"{x:1545,y:862,t:1528139854562};\\\", \\\"{x:1541,y:868,t:1528139854579};\\\", \\\"{x:1539,y:872,t:1528139854596};\\\", \\\"{x:1537,y:877,t:1528139854613};\\\", \\\"{x:1533,y:882,t:1528139854629};\\\", \\\"{x:1529,y:889,t:1528139854646};\\\", \\\"{x:1528,y:892,t:1528139854662};\\\", \\\"{x:1527,y:896,t:1528139854679};\\\", \\\"{x:1525,y:899,t:1528139854696};\\\", \\\"{x:1525,y:901,t:1528139854712};\\\", \\\"{x:1524,y:903,t:1528139854728};\\\", \\\"{x:1524,y:905,t:1528139854745};\\\", \\\"{x:1522,y:908,t:1528139854762};\\\", \\\"{x:1520,y:915,t:1528139854778};\\\", \\\"{x:1517,y:921,t:1528139854795};\\\", \\\"{x:1516,y:929,t:1528139854813};\\\", \\\"{x:1512,y:936,t:1528139854828};\\\", \\\"{x:1509,y:943,t:1528139854846};\\\", \\\"{x:1506,y:947,t:1528139854862};\\\", \\\"{x:1504,y:950,t:1528139854879};\\\", \\\"{x:1503,y:952,t:1528139854896};\\\", \\\"{x:1501,y:955,t:1528139854913};\\\", \\\"{x:1498,y:959,t:1528139854929};\\\", \\\"{x:1495,y:962,t:1528139854946};\\\", \\\"{x:1493,y:964,t:1528139854963};\\\", \\\"{x:1490,y:968,t:1528139854980};\\\", \\\"{x:1487,y:971,t:1528139854996};\\\", \\\"{x:1481,y:973,t:1528139855013};\\\", \\\"{x:1477,y:973,t:1528139855029};\\\", \\\"{x:1472,y:974,t:1528139855046};\\\", \\\"{x:1470,y:974,t:1528139855063};\\\", \\\"{x:1469,y:974,t:1528139855080};\\\", \\\"{x:1468,y:974,t:1528139855102};\\\", \\\"{x:1467,y:974,t:1528139855113};\\\", \\\"{x:1466,y:974,t:1528139855134};\\\", \\\"{x:1466,y:973,t:1528139855167};\\\", \\\"{x:1466,y:972,t:1528139855179};\\\", \\\"{x:1466,y:970,t:1528139855196};\\\", \\\"{x:1466,y:969,t:1528139855213};\\\", \\\"{x:1466,y:967,t:1528139855231};\\\", \\\"{x:1466,y:966,t:1528139855311};\\\", \\\"{x:1466,y:965,t:1528139855318};\\\", \\\"{x:1467,y:963,t:1528139855330};\\\", \\\"{x:1469,y:962,t:1528139855346};\\\", \\\"{x:1473,y:959,t:1528139855363};\\\", \\\"{x:1474,y:958,t:1528139855380};\\\", \\\"{x:1477,y:956,t:1528139855396};\\\", \\\"{x:1478,y:956,t:1528139855534};\\\", \\\"{x:1478,y:957,t:1528139855656};\\\", \\\"{x:1478,y:956,t:1528139855768};\\\", \\\"{x:1478,y:955,t:1528139855825};\\\", \\\"{x:1479,y:955,t:1528139856289};\\\", \\\"{x:1479,y:956,t:1528139856307};\\\", \\\"{x:1480,y:956,t:1528139856497};\\\", \\\"{x:1480,y:957,t:1528139856520};\\\", \\\"{x:1481,y:957,t:1528139856584};\\\", \\\"{x:1482,y:957,t:1528139856593};\\\", \\\"{x:1483,y:958,t:1528139856607};\\\", \\\"{x:1484,y:959,t:1528139856625};\\\", \\\"{x:1484,y:960,t:1528139856833};\\\", \\\"{x:1484,y:961,t:1528139856840};\\\", \\\"{x:1484,y:962,t:1528139856937};\\\", \\\"{x:1484,y:963,t:1528139856952};\\\", \\\"{x:1484,y:964,t:1528139856968};\\\", \\\"{x:1483,y:965,t:1528139857105};\\\", \\\"{x:1482,y:966,t:1528139857512};\\\", \\\"{x:1481,y:966,t:1528139857665};\\\", \\\"{x:1480,y:966,t:1528139857704};\\\", \\\"{x:1479,y:966,t:1528139857992};\\\", \\\"{x:1478,y:966,t:1528139858008};\\\", \\\"{x:1476,y:966,t:1528139858736};\\\", \\\"{x:1469,y:966,t:1528139858744};\\\", \\\"{x:1459,y:966,t:1528139858759};\\\", \\\"{x:1440,y:966,t:1528139858775};\\\", \\\"{x:1403,y:966,t:1528139858792};\\\", \\\"{x:1381,y:960,t:1528139858809};\\\", \\\"{x:1338,y:948,t:1528139858825};\\\", \\\"{x:1286,y:933,t:1528139858842};\\\", \\\"{x:1231,y:922,t:1528139858859};\\\", \\\"{x:1165,y:905,t:1528139858875};\\\", \\\"{x:1084,y:866,t:1528139858892};\\\", \\\"{x:1012,y:819,t:1528139858909};\\\", \\\"{x:934,y:760,t:1528139858925};\\\", \\\"{x:866,y:711,t:1528139858941};\\\", \\\"{x:815,y:670,t:1528139858958};\\\", \\\"{x:764,y:628,t:1528139858975};\\\", \\\"{x:741,y:610,t:1528139858991};\\\", \\\"{x:727,y:596,t:1528139859009};\\\", \\\"{x:717,y:583,t:1528139859025};\\\", \\\"{x:712,y:577,t:1528139859042};\\\", \\\"{x:711,y:575,t:1528139859058};\\\", \\\"{x:709,y:572,t:1528139859075};\\\", \\\"{x:706,y:569,t:1528139859092};\\\", \\\"{x:703,y:569,t:1528139859108};\\\", \\\"{x:699,y:569,t:1528139859126};\\\", \\\"{x:686,y:569,t:1528139859142};\\\", \\\"{x:666,y:571,t:1528139859158};\\\", \\\"{x:605,y:576,t:1528139859176};\\\", \\\"{x:558,y:576,t:1528139859193};\\\", \\\"{x:510,y:576,t:1528139859209};\\\", \\\"{x:465,y:576,t:1528139859226};\\\", \\\"{x:427,y:573,t:1528139859243};\\\", \\\"{x:406,y:569,t:1528139859260};\\\", \\\"{x:399,y:566,t:1528139859275};\\\", \\\"{x:396,y:564,t:1528139859293};\\\", \\\"{x:394,y:559,t:1528139859309};\\\", \\\"{x:394,y:555,t:1528139859326};\\\", \\\"{x:399,y:550,t:1528139859343};\\\", \\\"{x:445,y:544,t:1528139859359};\\\", \\\"{x:479,y:538,t:1528139859375};\\\", \\\"{x:509,y:536,t:1528139859393};\\\", \\\"{x:537,y:536,t:1528139859409};\\\", \\\"{x:556,y:536,t:1528139859425};\\\", \\\"{x:566,y:536,t:1528139859442};\\\", \\\"{x:571,y:536,t:1528139859459};\\\", \\\"{x:572,y:536,t:1528139859475};\\\", \\\"{x:573,y:536,t:1528139859495};\\\", \\\"{x:574,y:536,t:1528139859624};\\\", \\\"{x:576,y:533,t:1528139859631};\\\", \\\"{x:576,y:532,t:1528139859642};\\\", \\\"{x:577,y:527,t:1528139859659};\\\", \\\"{x:580,y:521,t:1528139859676};\\\", \\\"{x:585,y:511,t:1528139859693};\\\", \\\"{x:589,y:506,t:1528139859709};\\\", \\\"{x:591,y:500,t:1528139859727};\\\", \\\"{x:592,y:499,t:1528139859742};\\\", \\\"{x:593,y:502,t:1528139860288};\\\", \\\"{x:589,y:506,t:1528139860296};\\\", \\\"{x:584,y:508,t:1528139860309};\\\", \\\"{x:569,y:512,t:1528139860327};\\\", \\\"{x:540,y:512,t:1528139860344};\\\", \\\"{x:517,y:512,t:1528139860360};\\\", \\\"{x:494,y:512,t:1528139860379};\\\", \\\"{x:474,y:512,t:1528139860394};\\\", \\\"{x:450,y:512,t:1528139860409};\\\", \\\"{x:426,y:512,t:1528139860426};\\\", \\\"{x:393,y:512,t:1528139860444};\\\", \\\"{x:351,y:512,t:1528139860460};\\\", \\\"{x:311,y:517,t:1528139860476};\\\", \\\"{x:269,y:518,t:1528139860494};\\\", \\\"{x:235,y:522,t:1528139860509};\\\", \\\"{x:212,y:523,t:1528139860527};\\\", \\\"{x:192,y:525,t:1528139860543};\\\", \\\"{x:183,y:528,t:1528139860561};\\\", \\\"{x:179,y:530,t:1528139860576};\\\", \\\"{x:172,y:532,t:1528139860594};\\\", \\\"{x:164,y:537,t:1528139860610};\\\", \\\"{x:156,y:541,t:1528139860626};\\\", \\\"{x:150,y:545,t:1528139860644};\\\", \\\"{x:147,y:549,t:1528139860661};\\\", \\\"{x:145,y:550,t:1528139860677};\\\", \\\"{x:144,y:551,t:1528139860694};\\\", \\\"{x:144,y:553,t:1528139860712};\\\", \\\"{x:144,y:555,t:1528139860727};\\\", \\\"{x:144,y:560,t:1528139860744};\\\", \\\"{x:142,y:567,t:1528139860761};\\\", \\\"{x:140,y:572,t:1528139860776};\\\", \\\"{x:138,y:580,t:1528139860793};\\\", \\\"{x:136,y:586,t:1528139860810};\\\", \\\"{x:136,y:592,t:1528139860827};\\\", \\\"{x:136,y:595,t:1528139860844};\\\", \\\"{x:136,y:598,t:1528139860860};\\\", \\\"{x:136,y:601,t:1528139860878};\\\", \\\"{x:139,y:606,t:1528139860893};\\\", \\\"{x:142,y:612,t:1528139860911};\\\", \\\"{x:143,y:616,t:1528139860927};\\\", \\\"{x:144,y:618,t:1528139860944};\\\", \\\"{x:146,y:620,t:1528139860961};\\\", \\\"{x:147,y:621,t:1528139860984};\\\", \\\"{x:148,y:622,t:1528139860994};\\\", \\\"{x:158,y:623,t:1528139861011};\\\", \\\"{x:178,y:623,t:1528139861027};\\\", \\\"{x:203,y:623,t:1528139861043};\\\", \\\"{x:232,y:619,t:1528139861060};\\\", \\\"{x:271,y:612,t:1528139861077};\\\", \\\"{x:332,y:604,t:1528139861095};\\\", \\\"{x:389,y:592,t:1528139861111};\\\", \\\"{x:483,y:568,t:1528139861127};\\\", \\\"{x:550,y:560,t:1528139861143};\\\", \\\"{x:592,y:553,t:1528139861160};\\\", \\\"{x:621,y:552,t:1528139861178};\\\", \\\"{x:647,y:552,t:1528139861193};\\\", \\\"{x:664,y:552,t:1528139861210};\\\", \\\"{x:683,y:552,t:1528139861227};\\\", \\\"{x:698,y:552,t:1528139861243};\\\", \\\"{x:716,y:552,t:1528139861261};\\\", \\\"{x:737,y:552,t:1528139861279};\\\", \\\"{x:759,y:547,t:1528139861293};\\\", \\\"{x:774,y:545,t:1528139861310};\\\", \\\"{x:786,y:542,t:1528139861327};\\\", \\\"{x:787,y:542,t:1528139861344};\\\", \\\"{x:788,y:541,t:1528139861367};\\\", \\\"{x:790,y:540,t:1528139861383};\\\", \\\"{x:793,y:537,t:1528139861394};\\\", \\\"{x:802,y:529,t:1528139861411};\\\", \\\"{x:814,y:519,t:1528139861428};\\\", \\\"{x:823,y:511,t:1528139861445};\\\", \\\"{x:826,y:507,t:1528139861461};\\\", \\\"{x:827,y:505,t:1528139861477};\\\", \\\"{x:828,y:504,t:1528139861494};\\\", \\\"{x:828,y:503,t:1528139861519};\\\", \\\"{x:828,y:501,t:1528139861528};\\\", \\\"{x:830,y:499,t:1528139861544};\\\", \\\"{x:831,y:498,t:1528139861560};\\\", \\\"{x:834,y:498,t:1528139861578};\\\", \\\"{x:835,y:498,t:1528139861595};\\\", \\\"{x:836,y:498,t:1528139861871};\\\", \\\"{x:836,y:502,t:1528139861879};\\\", \\\"{x:832,y:509,t:1528139861895};\\\", \\\"{x:804,y:541,t:1528139861911};\\\", \\\"{x:758,y:579,t:1528139861928};\\\", \\\"{x:694,y:618,t:1528139861944};\\\", \\\"{x:616,y:656,t:1528139861961};\\\", \\\"{x:549,y:680,t:1528139861977};\\\", \\\"{x:521,y:688,t:1528139861994};\\\", \\\"{x:508,y:691,t:1528139862010};\\\", \\\"{x:507,y:694,t:1528139862028};\\\", \\\"{x:508,y:694,t:1528139862079};\\\", \\\"{x:508,y:695,t:1528139862103};\\\", \\\"{x:508,y:697,t:1528139862111};\\\", \\\"{x:509,y:698,t:1528139862127};\\\", \\\"{x:511,y:701,t:1528139862145};\\\", \\\"{x:514,y:704,t:1528139862161};\\\", \\\"{x:523,y:709,t:1528139862177};\\\", \\\"{x:531,y:710,t:1528139862195};\\\", \\\"{x:541,y:711,t:1528139862211};\\\", \\\"{x:548,y:713,t:1528139862228};\\\", \\\"{x:554,y:713,t:1528139862245};\\\", \\\"{x:555,y:713,t:1528139862261};\\\", \\\"{x:556,y:713,t:1528139862336};\\\", \\\"{x:560,y:711,t:1528139862344};\\\", \\\"{x:569,y:695,t:1528139862362};\\\", \\\"{x:586,y:666,t:1528139862378};\\\", \\\"{x:601,y:628,t:1528139862395};\\\", \\\"{x:610,y:594,t:1528139862412};\\\", \\\"{x:616,y:571,t:1528139862430};\\\", \\\"{x:621,y:552,t:1528139862445};\\\", \\\"{x:621,y:546,t:1528139862461};\\\", \\\"{x:621,y:542,t:1528139862479};\\\", \\\"{x:621,y:538,t:1528139862494};\\\", \\\"{x:621,y:534,t:1528139862511};\\\", \\\"{x:621,y:533,t:1528139862529};\\\", \\\"{x:621,y:532,t:1528139862640};\\\", \\\"{x:621,y:531,t:1528139862647};\\\", \\\"{x:618,y:527,t:1528139862663};\\\", \\\"{x:614,y:518,t:1528139862679};\\\", \\\"{x:612,y:505,t:1528139862696};\\\", \\\"{x:612,y:501,t:1528139862711};\\\", \\\"{x:612,y:497,t:1528139862728};\\\", \\\"{x:612,y:496,t:1528139862745};\\\", \\\"{x:613,y:495,t:1528139862848};\\\", \\\"{x:612,y:509,t:1528139863080};\\\", \\\"{x:602,y:573,t:1528139863096};\\\", \\\"{x:582,y:648,t:1528139863112};\\\", \\\"{x:569,y:698,t:1528139863129};\\\", \\\"{x:568,y:726,t:1528139863146};\\\", \\\"{x:571,y:747,t:1528139863161};\\\", \\\"{x:583,y:760,t:1528139863179};\\\", \\\"{x:592,y:767,t:1528139863196};\\\", \\\"{x:595,y:773,t:1528139863212};\\\", \\\"{x:599,y:779,t:1528139863228};\\\", \\\"{x:599,y:782,t:1528139863245};\\\", \\\"{x:599,y:785,t:1528139863262};\\\", \\\"{x:599,y:788,t:1528139863278};\\\", \\\"{x:599,y:790,t:1528139863295};\\\", \\\"{x:599,y:791,t:1528139863313};\\\", \\\"{x:598,y:792,t:1528139863328};\\\", \\\"{x:596,y:794,t:1528139863345};\\\", \\\"{x:594,y:794,t:1528139863368};\\\", \\\"{x:593,y:794,t:1528139863379};\\\", \\\"{x:590,y:794,t:1528139863396};\\\", \\\"{x:586,y:790,t:1528139863413};\\\", \\\"{x:582,y:784,t:1528139863429};\\\", \\\"{x:575,y:777,t:1528139863446};\\\", \\\"{x:563,y:767,t:1528139863463};\\\", \\\"{x:555,y:756,t:1528139863479};\\\", \\\"{x:540,y:734,t:1528139863498};\\\", \\\"{x:535,y:721,t:1528139863513};\\\", \\\"{x:534,y:715,t:1528139863528};\\\", \\\"{x:534,y:710,t:1528139863545};\\\", \\\"{x:534,y:707,t:1528139863562};\\\", \\\"{x:534,y:705,t:1528139863580};\\\", \\\"{x:534,y:702,t:1528139863596};\\\", \\\"{x:534,y:707,t:1528139863881};\\\", \\\"{x:534,y:716,t:1528139863896};\\\", \\\"{x:534,y:719,t:1528139863912};\\\", \\\"{x:535,y:724,t:1528139863931};\\\", \\\"{x:535,y:729,t:1528139863945};\\\", \\\"{x:536,y:732,t:1528139863963};\\\", \\\"{x:537,y:734,t:1528139863979};\\\", \\\"{x:537,y:735,t:1528139864576};\\\", \\\"{x:539,y:740,t:1528139864583};\\\", \\\"{x:553,y:743,t:1528139864597};\\\", \\\"{x:603,y:748,t:1528139864614};\\\", \\\"{x:660,y:758,t:1528139864630};\\\", \\\"{x:716,y:767,t:1528139864647};\\\", \\\"{x:757,y:775,t:1528139864663};\\\", \\\"{x:763,y:776,t:1528139864680};\\\" ] }, { \\\"rt\\\": 15686, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 18, \\\"time_elapsed\\\": 625125, \\\"internal_node_id\\\": \\\"0.0-6.0-8.0\\\", \\\"subject\\\": \\\"JYGX2\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"yankee\\\", \\\"condition\\\": \\\"311\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"endtime\\\", \\\"q\\\": 14, \\\"clicks\\\": 1, \\\"explicit\\\": 3, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XInside-YFull\\\", \\\"correct\\\": 1, \\\"orth_correct\\\": 0, \\\"answer\\\": [ \\\"X\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-03 PM-03 PM-X -X -X -03 PM\\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:768,y:776,t:1528139868529};\\\", \\\"{x:776,y:777,t:1528139868536};\\\", \\\"{x:786,y:777,t:1528139868550};\\\", \\\"{x:808,y:781,t:1528139868566};\\\", \\\"{x:830,y:784,t:1528139868583};\\\", \\\"{x:855,y:787,t:1528139868599};\\\", \\\"{x:870,y:789,t:1528139868616};\\\", \\\"{x:883,y:791,t:1528139868633};\\\", \\\"{x:908,y:792,t:1528139868650};\\\", \\\"{x:944,y:792,t:1528139868666};\\\", \\\"{x:978,y:792,t:1528139868683};\\\", \\\"{x:1010,y:792,t:1528139868700};\\\", \\\"{x:1041,y:792,t:1528139868716};\\\", \\\"{x:1063,y:795,t:1528139868733};\\\", \\\"{x:1084,y:799,t:1528139868751};\\\", \\\"{x:1107,y:806,t:1528139868768};\\\", \\\"{x:1136,y:819,t:1528139868784};\\\", \\\"{x:1154,y:830,t:1528139868800};\\\", \\\"{x:1169,y:839,t:1528139868816};\\\", \\\"{x:1183,y:848,t:1528139868833};\\\", \\\"{x:1199,y:857,t:1528139868850};\\\", \\\"{x:1211,y:864,t:1528139868867};\\\", \\\"{x:1225,y:872,t:1528139868882};\\\", \\\"{x:1240,y:884,t:1528139868900};\\\", \\\"{x:1252,y:893,t:1528139868917};\\\", \\\"{x:1264,y:901,t:1528139868932};\\\", \\\"{x:1278,y:911,t:1528139868950};\\\", \\\"{x:1292,y:918,t:1528139868966};\\\", \\\"{x:1304,y:926,t:1528139868983};\\\", \\\"{x:1327,y:933,t:1528139869000};\\\", \\\"{x:1339,y:935,t:1528139869017};\\\", \\\"{x:1344,y:935,t:1528139869033};\\\", \\\"{x:1344,y:934,t:1528139869050};\\\", \\\"{x:1348,y:934,t:1528139869335};\\\", \\\"{x:1355,y:931,t:1528139869350};\\\", \\\"{x:1377,y:930,t:1528139869366};\\\", \\\"{x:1399,y:930,t:1528139869384};\\\", \\\"{x:1416,y:930,t:1528139869400};\\\", \\\"{x:1437,y:930,t:1528139869417};\\\", \\\"{x:1468,y:934,t:1528139869434};\\\", \\\"{x:1506,y:939,t:1528139869451};\\\", \\\"{x:1546,y:946,t:1528139869467};\\\", \\\"{x:1579,y:954,t:1528139869484};\\\", \\\"{x:1600,y:959,t:1528139869500};\\\", \\\"{x:1612,y:962,t:1528139869517};\\\", \\\"{x:1617,y:963,t:1528139869534};\\\", \\\"{x:1619,y:963,t:1528139869550};\\\", \\\"{x:1621,y:963,t:1528139869640};\\\", \\\"{x:1617,y:963,t:1528139869679};\\\", \\\"{x:1614,y:963,t:1528139869687};\\\", \\\"{x:1611,y:963,t:1528139869701};\\\", \\\"{x:1601,y:963,t:1528139869716};\\\", \\\"{x:1592,y:963,t:1528139869734};\\\", \\\"{x:1584,y:966,t:1528139869751};\\\", \\\"{x:1581,y:966,t:1528139869767};\\\", \\\"{x:1576,y:967,t:1528139869784};\\\", \\\"{x:1569,y:970,t:1528139869800};\\\", \\\"{x:1556,y:973,t:1528139869817};\\\", \\\"{x:1540,y:976,t:1528139869833};\\\", \\\"{x:1529,y:976,t:1528139869851};\\\", \\\"{x:1524,y:976,t:1528139869868};\\\", \\\"{x:1523,y:976,t:1528139869884};\\\", \\\"{x:1521,y:976,t:1528139869901};\\\", \\\"{x:1521,y:975,t:1528139869917};\\\", \\\"{x:1521,y:972,t:1528139869936};\\\", \\\"{x:1522,y:971,t:1528139869952};\\\", \\\"{x:1523,y:969,t:1528139869967};\\\", \\\"{x:1525,y:968,t:1528139869984};\\\", \\\"{x:1527,y:967,t:1528139870001};\\\", \\\"{x:1533,y:966,t:1528139870018};\\\", \\\"{x:1543,y:964,t:1528139870035};\\\", \\\"{x:1549,y:963,t:1528139870051};\\\", \\\"{x:1555,y:961,t:1528139870067};\\\", \\\"{x:1560,y:961,t:1528139870084};\\\", \\\"{x:1563,y:961,t:1528139870102};\\\", \\\"{x:1565,y:961,t:1528139870118};\\\", \\\"{x:1566,y:961,t:1528139870134};\\\", \\\"{x:1567,y:961,t:1528139870152};\\\", \\\"{x:1568,y:961,t:1528139870248};\\\", \\\"{x:1568,y:962,t:1528139870264};\\\", \\\"{x:1568,y:964,t:1528139870288};\\\", \\\"{x:1563,y:965,t:1528139870304};\\\", \\\"{x:1558,y:968,t:1528139870318};\\\", \\\"{x:1551,y:969,t:1528139870335};\\\", \\\"{x:1546,y:969,t:1528139870351};\\\", \\\"{x:1545,y:969,t:1528139870368};\\\", \\\"{x:1544,y:969,t:1528139870560};\\\", \\\"{x:1544,y:968,t:1528139871080};\\\", \\\"{x:1544,y:964,t:1528139871088};\\\", \\\"{x:1544,y:961,t:1528139871102};\\\", \\\"{x:1543,y:953,t:1528139871119};\\\", \\\"{x:1535,y:934,t:1528139871136};\\\", \\\"{x:1523,y:910,t:1528139871152};\\\", \\\"{x:1517,y:892,t:1528139871169};\\\", \\\"{x:1513,y:879,t:1528139871186};\\\", \\\"{x:1511,y:870,t:1528139871202};\\\", \\\"{x:1509,y:866,t:1528139871219};\\\", \\\"{x:1509,y:865,t:1528139871236};\\\", \\\"{x:1509,y:863,t:1528139871253};\\\", \\\"{x:1506,y:860,t:1528139871416};\\\", \\\"{x:1505,y:858,t:1528139871424};\\\", \\\"{x:1501,y:853,t:1528139871435};\\\", \\\"{x:1492,y:843,t:1528139871452};\\\", \\\"{x:1483,y:833,t:1528139871471};\\\", \\\"{x:1480,y:829,t:1528139871485};\\\", \\\"{x:1480,y:828,t:1528139871502};\\\", \\\"{x:1480,y:827,t:1528139871518};\\\", \\\"{x:1479,y:827,t:1528139871535};\\\", \\\"{x:1478,y:827,t:1528139872736};\\\", \\\"{x:1477,y:826,t:1528139872753};\\\", \\\"{x:1474,y:825,t:1528139872771};\\\", \\\"{x:1471,y:820,t:1528139872787};\\\", \\\"{x:1469,y:813,t:1528139872803};\\\", \\\"{x:1465,y:803,t:1528139872819};\\\", \\\"{x:1461,y:793,t:1528139872836};\\\", \\\"{x:1459,y:784,t:1528139872853};\\\", \\\"{x:1455,y:776,t:1528139872869};\\\", \\\"{x:1453,y:768,t:1528139872886};\\\", \\\"{x:1451,y:758,t:1528139872904};\\\", \\\"{x:1443,y:742,t:1528139872920};\\\", \\\"{x:1438,y:733,t:1528139872937};\\\", \\\"{x:1432,y:722,t:1528139872954};\\\", \\\"{x:1426,y:709,t:1528139872970};\\\", \\\"{x:1416,y:692,t:1528139872986};\\\", \\\"{x:1408,y:674,t:1528139873004};\\\", \\\"{x:1395,y:651,t:1528139873021};\\\", \\\"{x:1385,y:630,t:1528139873036};\\\", \\\"{x:1377,y:615,t:1528139873053};\\\", \\\"{x:1369,y:600,t:1528139873071};\\\", \\\"{x:1362,y:585,t:1528139873086};\\\", \\\"{x:1347,y:560,t:1528139873104};\\\", \\\"{x:1342,y:552,t:1528139873120};\\\", \\\"{x:1340,y:547,t:1528139873136};\\\", \\\"{x:1339,y:544,t:1528139873153};\\\", \\\"{x:1338,y:543,t:1528139873170};\\\", \\\"{x:1338,y:542,t:1528139873186};\\\", \\\"{x:1337,y:540,t:1528139873203};\\\", \\\"{x:1337,y:539,t:1528139873220};\\\", \\\"{x:1336,y:537,t:1528139873235};\\\", \\\"{x:1332,y:534,t:1528139873407};\\\", \\\"{x:1331,y:533,t:1528139873420};\\\", \\\"{x:1325,y:530,t:1528139873436};\\\", \\\"{x:1318,y:525,t:1528139873453};\\\", \\\"{x:1309,y:520,t:1528139873470};\\\", \\\"{x:1305,y:515,t:1528139873486};\\\", \\\"{x:1302,y:510,t:1528139873503};\\\", \\\"{x:1301,y:506,t:1528139873520};\\\", \\\"{x:1301,y:507,t:1528139873832};\\\", \\\"{x:1301,y:513,t:1528139873840};\\\", \\\"{x:1304,y:520,t:1528139873854};\\\", \\\"{x:1309,y:534,t:1528139873870};\\\", \\\"{x:1315,y:547,t:1528139873888};\\\", \\\"{x:1323,y:564,t:1528139873903};\\\", \\\"{x:1325,y:570,t:1528139873921};\\\", \\\"{x:1330,y:578,t:1528139873937};\\\", \\\"{x:1334,y:586,t:1528139873954};\\\", \\\"{x:1339,y:596,t:1528139873971};\\\", \\\"{x:1344,y:603,t:1528139873988};\\\", \\\"{x:1347,y:607,t:1528139874004};\\\", \\\"{x:1351,y:610,t:1528139874020};\\\", \\\"{x:1353,y:614,t:1528139874037};\\\", \\\"{x:1357,y:618,t:1528139874053};\\\", \\\"{x:1359,y:621,t:1528139874070};\\\", \\\"{x:1369,y:635,t:1528139874138};\\\", \\\"{x:1369,y:636,t:1528139874154};\\\", \\\"{x:1370,y:636,t:1528139874191};\\\", \\\"{x:1371,y:637,t:1528139874214};\\\", \\\"{x:1371,y:638,t:1528139874327};\\\", \\\"{x:1370,y:639,t:1528139874337};\\\", \\\"{x:1367,y:640,t:1528139874354};\\\", \\\"{x:1363,y:643,t:1528139874371};\\\", \\\"{x:1362,y:643,t:1528139874388};\\\", \\\"{x:1360,y:643,t:1528139874480};\\\", \\\"{x:1357,y:642,t:1528139874496};\\\", \\\"{x:1357,y:638,t:1528139874505};\\\", \\\"{x:1355,y:629,t:1528139874521};\\\", \\\"{x:1353,y:619,t:1528139874538};\\\", \\\"{x:1353,y:613,t:1528139874555};\\\", \\\"{x:1353,y:607,t:1528139874571};\\\", \\\"{x:1355,y:600,t:1528139874587};\\\", \\\"{x:1357,y:596,t:1528139874605};\\\", \\\"{x:1357,y:595,t:1528139874696};\\\", \\\"{x:1360,y:595,t:1528139874711};\\\", \\\"{x:1370,y:615,t:1528139874728};\\\", \\\"{x:1395,y:675,t:1528139874780};\\\", \\\"{x:1397,y:679,t:1528139874786};\\\", \\\"{x:1399,y:681,t:1528139874804};\\\", \\\"{x:1399,y:683,t:1528139874821};\\\", \\\"{x:1401,y:684,t:1528139874837};\\\", \\\"{x:1401,y:685,t:1528139874853};\\\", \\\"{x:1403,y:688,t:1528139874870};\\\", \\\"{x:1405,y:693,t:1528139874887};\\\", \\\"{x:1409,y:701,t:1528139874904};\\\", \\\"{x:1415,y:710,t:1528139874921};\\\", \\\"{x:1422,y:725,t:1528139874937};\\\", \\\"{x:1430,y:739,t:1528139874954};\\\", \\\"{x:1438,y:752,t:1528139874971};\\\", \\\"{x:1445,y:763,t:1528139874988};\\\", \\\"{x:1452,y:774,t:1528139875005};\\\", \\\"{x:1459,y:784,t:1528139875021};\\\", \\\"{x:1465,y:793,t:1528139875038};\\\", \\\"{x:1471,y:802,t:1528139875055};\\\", \\\"{x:1474,y:810,t:1528139875072};\\\", \\\"{x:1479,y:818,t:1528139875088};\\\", \\\"{x:1480,y:821,t:1528139875104};\\\", \\\"{x:1484,y:827,t:1528139875122};\\\", \\\"{x:1491,y:836,t:1528139875139};\\\", \\\"{x:1494,y:841,t:1528139875154};\\\", \\\"{x:1497,y:846,t:1528139875172};\\\", \\\"{x:1501,y:849,t:1528139875188};\\\", \\\"{x:1502,y:851,t:1528139875204};\\\", \\\"{x:1503,y:852,t:1528139875221};\\\", \\\"{x:1503,y:853,t:1528139875239};\\\", \\\"{x:1503,y:854,t:1528139875263};\\\", \\\"{x:1503,y:856,t:1528139875272};\\\", \\\"{x:1503,y:857,t:1528139875289};\\\", \\\"{x:1504,y:858,t:1528139875305};\\\", \\\"{x:1504,y:860,t:1528139875321};\\\", \\\"{x:1504,y:861,t:1528139875338};\\\", \\\"{x:1504,y:863,t:1528139875354};\\\", \\\"{x:1505,y:864,t:1528139875371};\\\", \\\"{x:1506,y:866,t:1528139875388};\\\", \\\"{x:1506,y:868,t:1528139875404};\\\", \\\"{x:1507,y:873,t:1528139875421};\\\", \\\"{x:1511,y:881,t:1528139875437};\\\", \\\"{x:1517,y:897,t:1528139875455};\\\", \\\"{x:1519,y:904,t:1528139875471};\\\", \\\"{x:1521,y:908,t:1528139875488};\\\", \\\"{x:1523,y:911,t:1528139875505};\\\", \\\"{x:1523,y:913,t:1528139875522};\\\", \\\"{x:1524,y:917,t:1528139875539};\\\", \\\"{x:1527,y:920,t:1528139875555};\\\", \\\"{x:1531,y:927,t:1528139875571};\\\", \\\"{x:1534,y:935,t:1528139875589};\\\", \\\"{x:1538,y:942,t:1528139875606};\\\", \\\"{x:1543,y:950,t:1528139875621};\\\", \\\"{x:1545,y:955,t:1528139875638};\\\", \\\"{x:1553,y:965,t:1528139875656};\\\", \\\"{x:1557,y:970,t:1528139875672};\\\", \\\"{x:1560,y:975,t:1528139875688};\\\", \\\"{x:1564,y:979,t:1528139875706};\\\", \\\"{x:1566,y:982,t:1528139875721};\\\", \\\"{x:1567,y:982,t:1528139875738};\\\", \\\"{x:1567,y:981,t:1528139875809};\\\", \\\"{x:1563,y:977,t:1528139875821};\\\", \\\"{x:1560,y:962,t:1528139875839};\\\", \\\"{x:1552,y:936,t:1528139875856};\\\", \\\"{x:1547,y:918,t:1528139875872};\\\", \\\"{x:1546,y:900,t:1528139875889};\\\", \\\"{x:1542,y:884,t:1528139875905};\\\", \\\"{x:1542,y:872,t:1528139875923};\\\", \\\"{x:1542,y:864,t:1528139875939};\\\", \\\"{x:1542,y:862,t:1528139875955};\\\", \\\"{x:1542,y:861,t:1528139875973};\\\", \\\"{x:1542,y:860,t:1528139876000};\\\", \\\"{x:1541,y:859,t:1528139876008};\\\", \\\"{x:1541,y:857,t:1528139876024};\\\", \\\"{x:1540,y:857,t:1528139876039};\\\", \\\"{x:1535,y:854,t:1528139876056};\\\", \\\"{x:1527,y:850,t:1528139876072};\\\", \\\"{x:1522,y:848,t:1528139876088};\\\", \\\"{x:1517,y:847,t:1528139876105};\\\", \\\"{x:1516,y:847,t:1528139876123};\\\", \\\"{x:1515,y:846,t:1528139876139};\\\", \\\"{x:1512,y:845,t:1528139876155};\\\", \\\"{x:1511,y:845,t:1528139876173};\\\", \\\"{x:1507,y:843,t:1528139876189};\\\", \\\"{x:1505,y:842,t:1528139876205};\\\", \\\"{x:1504,y:842,t:1528139876248};\\\", \\\"{x:1501,y:844,t:1528139876255};\\\", \\\"{x:1497,y:854,t:1528139876272};\\\", \\\"{x:1493,y:862,t:1528139876288};\\\", \\\"{x:1492,y:866,t:1528139876306};\\\", \\\"{x:1491,y:868,t:1528139876322};\\\", \\\"{x:1491,y:869,t:1528139876339};\\\", \\\"{x:1490,y:870,t:1528139876355};\\\", \\\"{x:1489,y:872,t:1528139876373};\\\", \\\"{x:1488,y:873,t:1528139876390};\\\", \\\"{x:1486,y:876,t:1528139876406};\\\", \\\"{x:1477,y:877,t:1528139876422};\\\", \\\"{x:1467,y:879,t:1528139876440};\\\", \\\"{x:1452,y:881,t:1528139876456};\\\", \\\"{x:1450,y:882,t:1528139876472};\\\", \\\"{x:1450,y:883,t:1528139876896};\\\", \\\"{x:1450,y:885,t:1528139876905};\\\", \\\"{x:1449,y:885,t:1528139876935};\\\", \\\"{x:1447,y:885,t:1528139876944};\\\", \\\"{x:1446,y:885,t:1528139876957};\\\", \\\"{x:1443,y:885,t:1528139876972};\\\", \\\"{x:1436,y:885,t:1528139876989};\\\", \\\"{x:1420,y:880,t:1528139877007};\\\", \\\"{x:1393,y:872,t:1528139877022};\\\", \\\"{x:1337,y:853,t:1528139877040};\\\", \\\"{x:1311,y:836,t:1528139877056};\\\", \\\"{x:1273,y:814,t:1528139877073};\\\", \\\"{x:1237,y:799,t:1528139877090};\\\", \\\"{x:1209,y:787,t:1528139877107};\\\", \\\"{x:1186,y:775,t:1528139877123};\\\", \\\"{x:1165,y:761,t:1528139877139};\\\", \\\"{x:1150,y:752,t:1528139877157};\\\", \\\"{x:1140,y:747,t:1528139877172};\\\", \\\"{x:1135,y:743,t:1528139877189};\\\", \\\"{x:1131,y:738,t:1528139877207};\\\", \\\"{x:1131,y:735,t:1528139877222};\\\", \\\"{x:1131,y:734,t:1528139877384};\\\", \\\"{x:1129,y:733,t:1528139877432};\\\", \\\"{x:1124,y:731,t:1528139877440};\\\", \\\"{x:1117,y:729,t:1528139877457};\\\", \\\"{x:1112,y:727,t:1528139877473};\\\", \\\"{x:1104,y:724,t:1528139877489};\\\", \\\"{x:1088,y:716,t:1528139877506};\\\", \\\"{x:1063,y:710,t:1528139877524};\\\", \\\"{x:1017,y:700,t:1528139877540};\\\", \\\"{x:947,y:680,t:1528139877557};\\\", \\\"{x:869,y:656,t:1528139877573};\\\", \\\"{x:792,y:638,t:1528139877589};\\\", \\\"{x:715,y:619,t:1528139877608};\\\", \\\"{x:650,y:605,t:1528139877623};\\\", \\\"{x:628,y:600,t:1528139877640};\\\", \\\"{x:610,y:598,t:1528139877656};\\\", \\\"{x:600,y:597,t:1528139877673};\\\", \\\"{x:585,y:594,t:1528139877690};\\\", \\\"{x:573,y:592,t:1528139877707};\\\", \\\"{x:554,y:589,t:1528139877723};\\\", \\\"{x:537,y:588,t:1528139877740};\\\", \\\"{x:516,y:588,t:1528139877757};\\\", \\\"{x:494,y:588,t:1528139877775};\\\", \\\"{x:473,y:588,t:1528139877790};\\\", \\\"{x:441,y:587,t:1528139877807};\\\", \\\"{x:422,y:587,t:1528139877824};\\\", \\\"{x:407,y:585,t:1528139877840};\\\", \\\"{x:394,y:582,t:1528139877857};\\\", \\\"{x:386,y:579,t:1528139877874};\\\", \\\"{x:382,y:579,t:1528139877890};\\\", \\\"{x:376,y:579,t:1528139877907};\\\", \\\"{x:373,y:579,t:1528139877925};\\\", \\\"{x:374,y:579,t:1528139878025};\\\", \\\"{x:375,y:579,t:1528139878040};\\\", \\\"{x:376,y:579,t:1528139878063};\\\", \\\"{x:377,y:579,t:1528139878103};\\\", \\\"{x:378,y:580,t:1528139878111};\\\", \\\"{x:378,y:582,t:1528139878124};\\\", \\\"{x:381,y:586,t:1528139878141};\\\", \\\"{x:381,y:587,t:1528139878157};\\\", \\\"{x:381,y:589,t:1528139878174};\\\", \\\"{x:381,y:593,t:1528139878191};\\\", \\\"{x:381,y:599,t:1528139878208};\\\", \\\"{x:381,y:605,t:1528139878224};\\\", \\\"{x:377,y:614,t:1528139878240};\\\", \\\"{x:369,y:623,t:1528139878257};\\\", \\\"{x:357,y:629,t:1528139878274};\\\", \\\"{x:340,y:636,t:1528139878291};\\\", \\\"{x:321,y:640,t:1528139878307};\\\", \\\"{x:293,y:645,t:1528139878324};\\\", \\\"{x:269,y:647,t:1528139878342};\\\", \\\"{x:247,y:647,t:1528139878357};\\\", \\\"{x:236,y:649,t:1528139878374};\\\", \\\"{x:226,y:650,t:1528139878390};\\\", \\\"{x:218,y:650,t:1528139878407};\\\", \\\"{x:215,y:648,t:1528139878424};\\\", \\\"{x:217,y:646,t:1528139878679};\\\", \\\"{x:219,y:646,t:1528139878691};\\\", \\\"{x:225,y:644,t:1528139878707};\\\", \\\"{x:256,y:639,t:1528139878723};\\\", \\\"{x:293,y:628,t:1528139878741};\\\", \\\"{x:310,y:622,t:1528139878756};\\\", \\\"{x:323,y:619,t:1528139878775};\\\", \\\"{x:338,y:614,t:1528139878791};\\\", \\\"{x:347,y:611,t:1528139878808};\\\", \\\"{x:362,y:610,t:1528139878824};\\\", \\\"{x:383,y:607,t:1528139878842};\\\", \\\"{x:405,y:601,t:1528139878859};\\\", \\\"{x:443,y:599,t:1528139878875};\\\", \\\"{x:489,y:594,t:1528139878891};\\\", \\\"{x:527,y:593,t:1528139878909};\\\", \\\"{x:554,y:592,t:1528139878924};\\\", \\\"{x:578,y:592,t:1528139878941};\\\", \\\"{x:595,y:592,t:1528139878958};\\\", \\\"{x:614,y:592,t:1528139878974};\\\", \\\"{x:654,y:592,t:1528139878991};\\\", \\\"{x:677,y:592,t:1528139879008};\\\", \\\"{x:697,y:592,t:1528139879024};\\\", \\\"{x:711,y:591,t:1528139879041};\\\", \\\"{x:716,y:590,t:1528139879058};\\\", \\\"{x:717,y:590,t:1528139879074};\\\", \\\"{x:715,y:591,t:1528139879167};\\\", \\\"{x:709,y:593,t:1528139879175};\\\", \\\"{x:701,y:594,t:1528139879193};\\\", \\\"{x:699,y:594,t:1528139879208};\\\", \\\"{x:698,y:594,t:1528139879224};\\\", \\\"{x:696,y:594,t:1528139879246};\\\", \\\"{x:696,y:595,t:1528139879560};\\\", \\\"{x:692,y:596,t:1528139879575};\\\", \\\"{x:686,y:597,t:1528139879593};\\\", \\\"{x:680,y:597,t:1528139879610};\\\", \\\"{x:672,y:597,t:1528139879626};\\\", \\\"{x:663,y:597,t:1528139879643};\\\", \\\"{x:655,y:597,t:1528139879660};\\\", \\\"{x:650,y:597,t:1528139879675};\\\", \\\"{x:645,y:596,t:1528139879692};\\\", \\\"{x:640,y:595,t:1528139879710};\\\", \\\"{x:635,y:592,t:1528139879726};\\\", \\\"{x:632,y:592,t:1528139879742};\\\", \\\"{x:625,y:589,t:1528139879758};\\\", \\\"{x:619,y:587,t:1528139879774};\\\", \\\"{x:615,y:585,t:1528139879792};\\\", \\\"{x:611,y:584,t:1528139879808};\\\", \\\"{x:609,y:584,t:1528139879825};\\\", \\\"{x:608,y:583,t:1528139879842};\\\", \\\"{x:607,y:582,t:1528139879870};\\\", \\\"{x:606,y:581,t:1528139879895};\\\", \\\"{x:606,y:579,t:1528139879908};\\\", \\\"{x:606,y:581,t:1528139880134};\\\", \\\"{x:606,y:586,t:1528139880142};\\\", \\\"{x:599,y:608,t:1528139880159};\\\", \\\"{x:592,y:633,t:1528139880175};\\\", \\\"{x:582,y:656,t:1528139880192};\\\", \\\"{x:570,y:683,t:1528139880209};\\\", \\\"{x:561,y:702,t:1528139880225};\\\", \\\"{x:556,y:714,t:1528139880242};\\\", \\\"{x:551,y:724,t:1528139880260};\\\", \\\"{x:547,y:729,t:1528139880275};\\\", \\\"{x:547,y:731,t:1528139880292};\\\", \\\"{x:545,y:732,t:1528139880309};\\\", \\\"{x:544,y:732,t:1528139880342};\\\", \\\"{x:543,y:732,t:1528139880359};\\\", \\\"{x:541,y:732,t:1528139880375};\\\", \\\"{x:537,y:731,t:1528139880392};\\\", \\\"{x:533,y:728,t:1528139880408};\\\", \\\"{x:531,y:722,t:1528139880425};\\\", \\\"{x:529,y:720,t:1528139880442};\\\", \\\"{x:529,y:719,t:1528139880459};\\\", \\\"{x:528,y:719,t:1528139880656};\\\", \\\"{x:526,y:720,t:1528139880665};\\\", \\\"{x:525,y:722,t:1528139880676};\\\", \\\"{x:520,y:729,t:1528139880692};\\\", \\\"{x:517,y:738,t:1528139880709};\\\", \\\"{x:513,y:743,t:1528139880726};\\\" ] }, { \\\"rt\\\": 17067, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 19, \\\"time_elapsed\\\": 643486, \\\"internal_node_id\\\": \\\"0.0-6.0-9.0\\\", \\\"subject\\\": \\\"JYGX2\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"yankee\\\", \\\"condition\\\": \\\"311\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"midpoint\\\", \\\"q\\\": 15, \\\"clicks\\\": 2, \\\"explicit\\\": 3, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XInside-YFull\\\", \\\"correct\\\": 1, \\\"orth_correct\\\": 0, \\\"answer\\\": [ \\\"K\\\", \\\"X\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-02 PM-03 PM-10 AM-10 AM-01 PM-02 PM-02 PM-X -X -X \\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:513,y:744,t:1528139883006};\\\", \\\"{x:513,y:750,t:1528139883015};\\\", \\\"{x:513,y:764,t:1528139883028};\\\", \\\"{x:519,y:805,t:1528139883046};\\\", \\\"{x:529,y:838,t:1528139883062};\\\", \\\"{x:536,y:866,t:1528139883077};\\\", \\\"{x:544,y:882,t:1528139883094};\\\", \\\"{x:546,y:886,t:1528139883110};\\\", \\\"{x:546,y:887,t:1528139885463};\\\", \\\"{x:585,y:884,t:1528139885479};\\\", \\\"{x:647,y:883,t:1528139885496};\\\", \\\"{x:725,y:881,t:1528139885513};\\\", \\\"{x:792,y:881,t:1528139885529};\\\", \\\"{x:859,y:881,t:1528139885547};\\\", \\\"{x:928,y:881,t:1528139885563};\\\", \\\"{x:978,y:881,t:1528139885579};\\\", \\\"{x:1015,y:881,t:1528139885597};\\\", \\\"{x:1045,y:881,t:1528139885614};\\\", \\\"{x:1073,y:881,t:1528139885629};\\\", \\\"{x:1093,y:881,t:1528139885647};\\\", \\\"{x:1117,y:881,t:1528139885663};\\\", \\\"{x:1128,y:881,t:1528139885679};\\\", \\\"{x:1135,y:879,t:1528139885696};\\\", \\\"{x:1141,y:879,t:1528139885714};\\\", \\\"{x:1148,y:879,t:1528139885730};\\\", \\\"{x:1152,y:878,t:1528139885747};\\\", \\\"{x:1162,y:876,t:1528139885763};\\\", \\\"{x:1182,y:874,t:1528139885779};\\\", \\\"{x:1204,y:867,t:1528139885797};\\\", \\\"{x:1217,y:861,t:1528139885813};\\\", \\\"{x:1221,y:859,t:1528139885830};\\\", \\\"{x:1221,y:858,t:1528139885846};\\\", \\\"{x:1223,y:858,t:1528139885864};\\\", \\\"{x:1222,y:858,t:1528139885904};\\\", \\\"{x:1221,y:858,t:1528139886064};\\\", \\\"{x:1220,y:862,t:1528139886248};\\\", \\\"{x:1220,y:888,t:1528139886264};\\\", \\\"{x:1220,y:900,t:1528139886281};\\\", \\\"{x:1226,y:917,t:1528139886296};\\\", \\\"{x:1228,y:933,t:1528139886313};\\\", \\\"{x:1229,y:948,t:1528139886330};\\\", \\\"{x:1231,y:956,t:1528139886346};\\\", \\\"{x:1231,y:959,t:1528139886363};\\\", \\\"{x:1231,y:960,t:1528139886380};\\\", \\\"{x:1232,y:960,t:1528139887280};\\\", \\\"{x:1236,y:962,t:1528139887298};\\\", \\\"{x:1244,y:964,t:1528139887315};\\\", \\\"{x:1256,y:965,t:1528139887332};\\\", \\\"{x:1274,y:967,t:1528139887348};\\\", \\\"{x:1299,y:968,t:1528139887365};\\\", \\\"{x:1322,y:968,t:1528139887381};\\\", \\\"{x:1344,y:968,t:1528139887398};\\\", \\\"{x:1368,y:968,t:1528139887415};\\\", \\\"{x:1399,y:968,t:1528139887432};\\\", \\\"{x:1415,y:968,t:1528139887448};\\\", \\\"{x:1431,y:968,t:1528139887465};\\\", \\\"{x:1442,y:968,t:1528139887482};\\\", \\\"{x:1448,y:968,t:1528139887498};\\\", \\\"{x:1452,y:969,t:1528139887516};\\\", \\\"{x:1458,y:971,t:1528139887532};\\\", \\\"{x:1463,y:972,t:1528139887549};\\\", \\\"{x:1467,y:973,t:1528139887565};\\\", \\\"{x:1474,y:975,t:1528139887582};\\\", \\\"{x:1479,y:976,t:1528139887598};\\\", \\\"{x:1483,y:976,t:1528139887614};\\\", \\\"{x:1487,y:978,t:1528139887631};\\\", \\\"{x:1492,y:979,t:1528139887648};\\\", \\\"{x:1498,y:979,t:1528139887665};\\\", \\\"{x:1504,y:980,t:1528139887683};\\\", \\\"{x:1507,y:980,t:1528139887698};\\\", \\\"{x:1509,y:980,t:1528139887715};\\\", \\\"{x:1511,y:980,t:1528139887732};\\\", \\\"{x:1512,y:980,t:1528139887768};\\\", \\\"{x:1513,y:980,t:1528139887783};\\\", \\\"{x:1515,y:980,t:1528139887798};\\\", \\\"{x:1517,y:980,t:1528139887815};\\\", \\\"{x:1524,y:980,t:1528139887832};\\\", \\\"{x:1529,y:980,t:1528139887848};\\\", \\\"{x:1536,y:980,t:1528139887865};\\\", \\\"{x:1542,y:980,t:1528139887882};\\\", \\\"{x:1548,y:980,t:1528139887898};\\\", \\\"{x:1553,y:981,t:1528139887915};\\\", \\\"{x:1559,y:983,t:1528139887932};\\\", \\\"{x:1564,y:984,t:1528139887949};\\\", \\\"{x:1570,y:984,t:1528139887966};\\\", \\\"{x:1574,y:984,t:1528139887982};\\\", \\\"{x:1579,y:985,t:1528139887999};\\\", \\\"{x:1583,y:985,t:1528139888015};\\\", \\\"{x:1585,y:985,t:1528139888032};\\\", \\\"{x:1586,y:985,t:1528139888049};\\\", \\\"{x:1587,y:985,t:1528139888127};\\\", \\\"{x:1588,y:985,t:1528139888159};\\\", \\\"{x:1586,y:985,t:1528139888167};\\\", \\\"{x:1582,y:985,t:1528139888181};\\\", \\\"{x:1560,y:985,t:1528139888199};\\\", \\\"{x:1534,y:988,t:1528139888215};\\\", \\\"{x:1516,y:990,t:1528139888232};\\\", \\\"{x:1496,y:993,t:1528139888249};\\\", \\\"{x:1482,y:996,t:1528139888265};\\\", \\\"{x:1469,y:998,t:1528139888281};\\\", \\\"{x:1455,y:1000,t:1528139888299};\\\", \\\"{x:1445,y:1003,t:1528139888315};\\\", \\\"{x:1436,y:1004,t:1528139888332};\\\", \\\"{x:1422,y:1004,t:1528139888349};\\\", \\\"{x:1412,y:1004,t:1528139888366};\\\", \\\"{x:1405,y:1004,t:1528139888382};\\\", \\\"{x:1399,y:1004,t:1528139888399};\\\", \\\"{x:1383,y:998,t:1528139888415};\\\", \\\"{x:1374,y:995,t:1528139888432};\\\", \\\"{x:1361,y:993,t:1528139888449};\\\", \\\"{x:1347,y:992,t:1528139888466};\\\", \\\"{x:1335,y:992,t:1528139888482};\\\", \\\"{x:1327,y:992,t:1528139888499};\\\", \\\"{x:1316,y:992,t:1528139888516};\\\", \\\"{x:1312,y:992,t:1528139888532};\\\", \\\"{x:1308,y:992,t:1528139888549};\\\", \\\"{x:1306,y:992,t:1528139888566};\\\", \\\"{x:1305,y:992,t:1528139888648};\\\", \\\"{x:1296,y:989,t:1528139888666};\\\", \\\"{x:1282,y:988,t:1528139888682};\\\", \\\"{x:1264,y:987,t:1528139888699};\\\", \\\"{x:1250,y:984,t:1528139888716};\\\", \\\"{x:1242,y:983,t:1528139888732};\\\", \\\"{x:1229,y:980,t:1528139888749};\\\", \\\"{x:1217,y:977,t:1528139888766};\\\", \\\"{x:1211,y:975,t:1528139888783};\\\", \\\"{x:1210,y:974,t:1528139888799};\\\", \\\"{x:1208,y:974,t:1528139888864};\\\", \\\"{x:1207,y:974,t:1528139888872};\\\", \\\"{x:1201,y:974,t:1528139888882};\\\", \\\"{x:1191,y:974,t:1528139888899};\\\", \\\"{x:1186,y:974,t:1528139888916};\\\", \\\"{x:1180,y:974,t:1528139888933};\\\", \\\"{x:1178,y:974,t:1528139888949};\\\", \\\"{x:1176,y:973,t:1528139888966};\\\", \\\"{x:1175,y:973,t:1528139889246};\\\", \\\"{x:1181,y:973,t:1528139889270};\\\", \\\"{x:1190,y:973,t:1528139889282};\\\", \\\"{x:1214,y:969,t:1528139889300};\\\", \\\"{x:1252,y:968,t:1528139889315};\\\", \\\"{x:1287,y:968,t:1528139889332};\\\", \\\"{x:1305,y:968,t:1528139889348};\\\", \\\"{x:1316,y:968,t:1528139889366};\\\", \\\"{x:1323,y:968,t:1528139889382};\\\", \\\"{x:1324,y:966,t:1528139889431};\\\", \\\"{x:1326,y:965,t:1528139889447};\\\", \\\"{x:1328,y:965,t:1528139889454};\\\", \\\"{x:1330,y:965,t:1528139889465};\\\", \\\"{x:1339,y:965,t:1528139889482};\\\", \\\"{x:1351,y:965,t:1528139889499};\\\", \\\"{x:1362,y:965,t:1528139889515};\\\", \\\"{x:1373,y:967,t:1528139889532};\\\", \\\"{x:1389,y:969,t:1528139889549};\\\", \\\"{x:1402,y:971,t:1528139889565};\\\", \\\"{x:1417,y:974,t:1528139889582};\\\", \\\"{x:1429,y:976,t:1528139889599};\\\", \\\"{x:1439,y:977,t:1528139889616};\\\", \\\"{x:1448,y:977,t:1528139889632};\\\", \\\"{x:1458,y:978,t:1528139889650};\\\", \\\"{x:1466,y:978,t:1528139889666};\\\", \\\"{x:1479,y:978,t:1528139889683};\\\", \\\"{x:1495,y:978,t:1528139889700};\\\", \\\"{x:1506,y:978,t:1528139889715};\\\", \\\"{x:1515,y:978,t:1528139889733};\\\", \\\"{x:1520,y:977,t:1528139889749};\\\", \\\"{x:1522,y:977,t:1528139889765};\\\", \\\"{x:1523,y:977,t:1528139889782};\\\", \\\"{x:1522,y:977,t:1528139889983};\\\", \\\"{x:1510,y:976,t:1528139890000};\\\", \\\"{x:1492,y:975,t:1528139890017};\\\", \\\"{x:1479,y:974,t:1528139890033};\\\", \\\"{x:1467,y:973,t:1528139890050};\\\", \\\"{x:1463,y:972,t:1528139890067};\\\", \\\"{x:1465,y:972,t:1528139890311};\\\", \\\"{x:1466,y:972,t:1528139890352};\\\", \\\"{x:1468,y:972,t:1528139890367};\\\", \\\"{x:1470,y:970,t:1528139890384};\\\", \\\"{x:1474,y:968,t:1528139890400};\\\", \\\"{x:1475,y:967,t:1528139890417};\\\", \\\"{x:1480,y:965,t:1528139890434};\\\", \\\"{x:1483,y:963,t:1528139890450};\\\", \\\"{x:1487,y:961,t:1528139890467};\\\", \\\"{x:1490,y:957,t:1528139890484};\\\", \\\"{x:1491,y:953,t:1528139890501};\\\", \\\"{x:1491,y:952,t:1528139890624};\\\", \\\"{x:1491,y:951,t:1528139890848};\\\", \\\"{x:1488,y:941,t:1528139890855};\\\", \\\"{x:1486,y:930,t:1528139890868};\\\", \\\"{x:1481,y:911,t:1528139890884};\\\", \\\"{x:1479,y:892,t:1528139890902};\\\", \\\"{x:1474,y:877,t:1528139890917};\\\", \\\"{x:1473,y:867,t:1528139890934};\\\", \\\"{x:1471,y:860,t:1528139890951};\\\", \\\"{x:1471,y:858,t:1528139890967};\\\", \\\"{x:1471,y:855,t:1528139890984};\\\", \\\"{x:1471,y:848,t:1528139891001};\\\", \\\"{x:1472,y:843,t:1528139891017};\\\", \\\"{x:1474,y:837,t:1528139891035};\\\", \\\"{x:1475,y:829,t:1528139891051};\\\", \\\"{x:1476,y:824,t:1528139891067};\\\", \\\"{x:1476,y:820,t:1528139891084};\\\", \\\"{x:1476,y:818,t:1528139891101};\\\", \\\"{x:1476,y:817,t:1528139891117};\\\", \\\"{x:1476,y:815,t:1528139891134};\\\", \\\"{x:1476,y:814,t:1528139891151};\\\", \\\"{x:1476,y:812,t:1528139891167};\\\", \\\"{x:1478,y:812,t:1528139891400};\\\", \\\"{x:1478,y:815,t:1528139891418};\\\", \\\"{x:1478,y:818,t:1528139891434};\\\", \\\"{x:1479,y:822,t:1528139891451};\\\", \\\"{x:1480,y:825,t:1528139891471};\\\", \\\"{x:1480,y:826,t:1528139891483};\\\", \\\"{x:1480,y:828,t:1528139891501};\\\", \\\"{x:1480,y:829,t:1528139891542};\\\", \\\"{x:1480,y:826,t:1528139892911};\\\", \\\"{x:1480,y:824,t:1528139892920};\\\", \\\"{x:1480,y:819,t:1528139892935};\\\", \\\"{x:1480,y:817,t:1528139892952};\\\", \\\"{x:1481,y:814,t:1528139892969};\\\", \\\"{x:1481,y:812,t:1528139892985};\\\", \\\"{x:1481,y:811,t:1528139893002};\\\", \\\"{x:1481,y:809,t:1528139893032};\\\", \\\"{x:1481,y:808,t:1528139893055};\\\", \\\"{x:1481,y:806,t:1528139893071};\\\", \\\"{x:1482,y:805,t:1528139893087};\\\", \\\"{x:1482,y:803,t:1528139893103};\\\", \\\"{x:1482,y:800,t:1528139893120};\\\", \\\"{x:1482,y:798,t:1528139893136};\\\", \\\"{x:1482,y:796,t:1528139893152};\\\", \\\"{x:1482,y:792,t:1528139893169};\\\", \\\"{x:1482,y:788,t:1528139893185};\\\", \\\"{x:1481,y:783,t:1528139893202};\\\", \\\"{x:1480,y:777,t:1528139893219};\\\", \\\"{x:1478,y:772,t:1528139893236};\\\", \\\"{x:1477,y:767,t:1528139893253};\\\", \\\"{x:1477,y:763,t:1528139893270};\\\", \\\"{x:1476,y:757,t:1528139893286};\\\", \\\"{x:1476,y:753,t:1528139893302};\\\", \\\"{x:1476,y:745,t:1528139893318};\\\", \\\"{x:1474,y:740,t:1528139893336};\\\", \\\"{x:1474,y:734,t:1528139893352};\\\", \\\"{x:1473,y:728,t:1528139893368};\\\", \\\"{x:1473,y:723,t:1528139893386};\\\", \\\"{x:1473,y:716,t:1528139893401};\\\", \\\"{x:1473,y:713,t:1528139893419};\\\", \\\"{x:1473,y:708,t:1528139893436};\\\", \\\"{x:1473,y:701,t:1528139893452};\\\", \\\"{x:1473,y:696,t:1528139893469};\\\", \\\"{x:1473,y:688,t:1528139893486};\\\", \\\"{x:1473,y:681,t:1528139893502};\\\", \\\"{x:1473,y:668,t:1528139893519};\\\", \\\"{x:1473,y:661,t:1528139893535};\\\", \\\"{x:1473,y:654,t:1528139893552};\\\", \\\"{x:1473,y:651,t:1528139893570};\\\", \\\"{x:1473,y:647,t:1528139893586};\\\", \\\"{x:1473,y:644,t:1528139893602};\\\", \\\"{x:1472,y:641,t:1528139893619};\\\", \\\"{x:1472,y:636,t:1528139893636};\\\", \\\"{x:1472,y:634,t:1528139893653};\\\", \\\"{x:1472,y:631,t:1528139893669};\\\", \\\"{x:1472,y:629,t:1528139893686};\\\", \\\"{x:1472,y:624,t:1528139893703};\\\", \\\"{x:1472,y:619,t:1528139893720};\\\", \\\"{x:1472,y:614,t:1528139893736};\\\", \\\"{x:1472,y:609,t:1528139893753};\\\", \\\"{x:1472,y:604,t:1528139893769};\\\", \\\"{x:1472,y:599,t:1528139893787};\\\", \\\"{x:1472,y:597,t:1528139893803};\\\", \\\"{x:1473,y:592,t:1528139893819};\\\", \\\"{x:1474,y:588,t:1528139893836};\\\", \\\"{x:1474,y:580,t:1528139893853};\\\", \\\"{x:1477,y:569,t:1528139893870};\\\", \\\"{x:1478,y:559,t:1528139893886};\\\", \\\"{x:1479,y:547,t:1528139893903};\\\", \\\"{x:1481,y:540,t:1528139893920};\\\", \\\"{x:1482,y:534,t:1528139893936};\\\", \\\"{x:1483,y:529,t:1528139893953};\\\", \\\"{x:1483,y:527,t:1528139893970};\\\", \\\"{x:1483,y:525,t:1528139893986};\\\", \\\"{x:1483,y:522,t:1528139894003};\\\", \\\"{x:1483,y:521,t:1528139894019};\\\", \\\"{x:1483,y:518,t:1528139894037};\\\", \\\"{x:1483,y:517,t:1528139894054};\\\", \\\"{x:1483,y:515,t:1528139894070};\\\", \\\"{x:1483,y:514,t:1528139894086};\\\", \\\"{x:1483,y:510,t:1528139894104};\\\", \\\"{x:1483,y:509,t:1528139894119};\\\", \\\"{x:1483,y:502,t:1528139894137};\\\", \\\"{x:1483,y:495,t:1528139894153};\\\", \\\"{x:1483,y:486,t:1528139894171};\\\", \\\"{x:1483,y:479,t:1528139894186};\\\", \\\"{x:1483,y:474,t:1528139894203};\\\", \\\"{x:1483,y:469,t:1528139894221};\\\", \\\"{x:1483,y:463,t:1528139894236};\\\", \\\"{x:1483,y:455,t:1528139894253};\\\", \\\"{x:1483,y:450,t:1528139894270};\\\", \\\"{x:1483,y:446,t:1528139894287};\\\", \\\"{x:1483,y:440,t:1528139894304};\\\", \\\"{x:1483,y:438,t:1528139894320};\\\", \\\"{x:1483,y:437,t:1528139894337};\\\", \\\"{x:1483,y:435,t:1528139894354};\\\", \\\"{x:1483,y:433,t:1528139894371};\\\", \\\"{x:1483,y:429,t:1528139894386};\\\", \\\"{x:1483,y:426,t:1528139894404};\\\", \\\"{x:1483,y:423,t:1528139894421};\\\", \\\"{x:1483,y:421,t:1528139894436};\\\", \\\"{x:1483,y:419,t:1528139894454};\\\", \\\"{x:1482,y:418,t:1528139894471};\\\", \\\"{x:1482,y:416,t:1528139894486};\\\", \\\"{x:1482,y:412,t:1528139894504};\\\", \\\"{x:1482,y:407,t:1528139894520};\\\", \\\"{x:1482,y:405,t:1528139894537};\\\", \\\"{x:1482,y:401,t:1528139894553};\\\", \\\"{x:1482,y:400,t:1528139894570};\\\", \\\"{x:1482,y:398,t:1528139894586};\\\", \\\"{x:1482,y:397,t:1528139894712};\\\", \\\"{x:1482,y:396,t:1528139894720};\\\", \\\"{x:1482,y:393,t:1528139894737};\\\", \\\"{x:1482,y:390,t:1528139894752};\\\", \\\"{x:1482,y:384,t:1528139894770};\\\", \\\"{x:1482,y:383,t:1528139894786};\\\", \\\"{x:1482,y:379,t:1528139894803};\\\", \\\"{x:1482,y:376,t:1528139894820};\\\", \\\"{x:1482,y:372,t:1528139894837};\\\", \\\"{x:1482,y:369,t:1528139894853};\\\", \\\"{x:1482,y:366,t:1528139894870};\\\", \\\"{x:1482,y:365,t:1528139894887};\\\", \\\"{x:1482,y:363,t:1528139894903};\\\", \\\"{x:1482,y:361,t:1528139894920};\\\", \\\"{x:1482,y:359,t:1528139894937};\\\", \\\"{x:1483,y:355,t:1528139894954};\\\", \\\"{x:1483,y:352,t:1528139894971};\\\", \\\"{x:1483,y:346,t:1528139894987};\\\", \\\"{x:1483,y:338,t:1528139895004};\\\", \\\"{x:1485,y:332,t:1528139895020};\\\", \\\"{x:1485,y:326,t:1528139895037};\\\", \\\"{x:1486,y:322,t:1528139895054};\\\", \\\"{x:1486,y:318,t:1528139895071};\\\", \\\"{x:1486,y:314,t:1528139895087};\\\", \\\"{x:1486,y:311,t:1528139895104};\\\", \\\"{x:1486,y:309,t:1528139895136};\\\", \\\"{x:1487,y:307,t:1528139895143};\\\", \\\"{x:1487,y:306,t:1528139895168};\\\", \\\"{x:1487,y:305,t:1528139895183};\\\", \\\"{x:1488,y:305,t:1528139895207};\\\", \\\"{x:1488,y:304,t:1528139895221};\\\", \\\"{x:1505,y:307,t:1528139895560};\\\", \\\"{x:1545,y:323,t:1528139895571};\\\", \\\"{x:1572,y:331,t:1528139895587};\\\", \\\"{x:1573,y:332,t:1528139895605};\\\", \\\"{x:1573,y:335,t:1528139895840};\\\", \\\"{x:1544,y:358,t:1528139895854};\\\", \\\"{x:1333,y:480,t:1528139895871};\\\", \\\"{x:1157,y:554,t:1528139895887};\\\", \\\"{x:997,y:598,t:1528139895904};\\\", \\\"{x:857,y:631,t:1528139895922};\\\", \\\"{x:751,y:644,t:1528139895937};\\\", \\\"{x:673,y:658,t:1528139895971};\\\", \\\"{x:662,y:658,t:1528139895988};\\\", \\\"{x:659,y:658,t:1528139896004};\\\", \\\"{x:657,y:658,t:1528139896022};\\\", \\\"{x:648,y:652,t:1528139896038};\\\", \\\"{x:613,y:642,t:1528139896055};\\\", \\\"{x:586,y:634,t:1528139896071};\\\", \\\"{x:565,y:625,t:1528139896087};\\\", \\\"{x:548,y:616,t:1528139896105};\\\", \\\"{x:534,y:610,t:1528139896121};\\\", \\\"{x:519,y:603,t:1528139896139};\\\", \\\"{x:507,y:596,t:1528139896154};\\\", \\\"{x:497,y:591,t:1528139896172};\\\", \\\"{x:485,y:585,t:1528139896187};\\\", \\\"{x:474,y:582,t:1528139896204};\\\", \\\"{x:463,y:579,t:1528139896222};\\\", \\\"{x:454,y:578,t:1528139896237};\\\", \\\"{x:444,y:578,t:1528139896254};\\\", \\\"{x:434,y:578,t:1528139896271};\\\", \\\"{x:423,y:582,t:1528139896288};\\\", \\\"{x:411,y:590,t:1528139896305};\\\", \\\"{x:392,y:604,t:1528139896321};\\\", \\\"{x:370,y:622,t:1528139896340};\\\", \\\"{x:331,y:645,t:1528139896355};\\\", \\\"{x:308,y:661,t:1528139896373};\\\", \\\"{x:291,y:675,t:1528139896389};\\\", \\\"{x:281,y:682,t:1528139896405};\\\", \\\"{x:279,y:685,t:1528139896423};\\\", \\\"{x:278,y:685,t:1528139896438};\\\", \\\"{x:278,y:686,t:1528139896600};\\\", \\\"{x:283,y:687,t:1528139896607};\\\", \\\"{x:310,y:687,t:1528139896622};\\\", \\\"{x:447,y:671,t:1528139896640};\\\", \\\"{x:529,y:665,t:1528139896655};\\\", \\\"{x:589,y:662,t:1528139896671};\\\", \\\"{x:622,y:662,t:1528139896689};\\\", \\\"{x:642,y:662,t:1528139896704};\\\", \\\"{x:657,y:659,t:1528139896722};\\\", \\\"{x:674,y:653,t:1528139896739};\\\", \\\"{x:695,y:645,t:1528139896757};\\\", \\\"{x:721,y:635,t:1528139896772};\\\", \\\"{x:752,y:620,t:1528139896789};\\\", \\\"{x:777,y:609,t:1528139896807};\\\", \\\"{x:807,y:599,t:1528139896822};\\\", \\\"{x:833,y:590,t:1528139896839};\\\", \\\"{x:834,y:590,t:1528139896855};\\\", \\\"{x:835,y:590,t:1528139896872};\\\", \\\"{x:835,y:589,t:1528139896975};\\\", \\\"{x:826,y:591,t:1528139896990};\\\", \\\"{x:792,y:597,t:1528139897007};\\\", \\\"{x:736,y:610,t:1528139897023};\\\", \\\"{x:705,y:615,t:1528139897038};\\\", \\\"{x:678,y:617,t:1528139897056};\\\", \\\"{x:663,y:617,t:1528139897071};\\\", \\\"{x:656,y:617,t:1528139897088};\\\", \\\"{x:654,y:617,t:1528139897106};\\\", \\\"{x:652,y:617,t:1528139897121};\\\", \\\"{x:650,y:616,t:1528139897138};\\\", \\\"{x:643,y:616,t:1528139897155};\\\", \\\"{x:631,y:616,t:1528139897172};\\\", \\\"{x:619,y:616,t:1528139897188};\\\", \\\"{x:606,y:614,t:1528139897207};\\\", \\\"{x:596,y:611,t:1528139897221};\\\", \\\"{x:592,y:607,t:1528139897239};\\\", \\\"{x:591,y:603,t:1528139897256};\\\", \\\"{x:591,y:596,t:1528139897272};\\\", \\\"{x:591,y:593,t:1528139897289};\\\", \\\"{x:591,y:590,t:1528139897306};\\\", \\\"{x:591,y:589,t:1528139897322};\\\", \\\"{x:593,y:589,t:1528139897439};\\\", \\\"{x:602,y:592,t:1528139897457};\\\", \\\"{x:612,y:596,t:1528139897472};\\\", \\\"{x:616,y:597,t:1528139897489};\\\", \\\"{x:618,y:599,t:1528139897506};\\\", \\\"{x:619,y:599,t:1528139897523};\\\", \\\"{x:618,y:599,t:1528139897927};\\\", \\\"{x:608,y:602,t:1528139897940};\\\", \\\"{x:580,y:607,t:1528139897957};\\\", \\\"{x:551,y:610,t:1528139897973};\\\", \\\"{x:516,y:614,t:1528139897990};\\\", \\\"{x:493,y:614,t:1528139898006};\\\", \\\"{x:465,y:614,t:1528139898022};\\\", \\\"{x:451,y:614,t:1528139898040};\\\", \\\"{x:447,y:615,t:1528139898056};\\\", \\\"{x:445,y:615,t:1528139898073};\\\", \\\"{x:444,y:615,t:1528139898094};\\\", \\\"{x:443,y:615,t:1528139898151};\\\", \\\"{x:441,y:615,t:1528139898167};\\\", \\\"{x:440,y:615,t:1528139898174};\\\", \\\"{x:439,y:613,t:1528139898191};\\\", \\\"{x:437,y:610,t:1528139898206};\\\", \\\"{x:432,y:606,t:1528139898223};\\\", \\\"{x:430,y:603,t:1528139898240};\\\", \\\"{x:425,y:600,t:1528139898256};\\\", \\\"{x:421,y:598,t:1528139898273};\\\", \\\"{x:417,y:597,t:1528139898291};\\\", \\\"{x:416,y:597,t:1528139898307};\\\", \\\"{x:413,y:597,t:1528139898323};\\\", \\\"{x:409,y:596,t:1528139898340};\\\", \\\"{x:407,y:596,t:1528139898357};\\\", \\\"{x:404,y:596,t:1528139898372};\\\", \\\"{x:398,y:596,t:1528139898390};\\\", \\\"{x:391,y:596,t:1528139898408};\\\", \\\"{x:389,y:596,t:1528139898423};\\\", \\\"{x:388,y:596,t:1528139898520};\\\", \\\"{x:387,y:596,t:1528139898527};\\\", \\\"{x:387,y:594,t:1528139898719};\\\", \\\"{x:389,y:594,t:1528139898766};\\\", \\\"{x:392,y:595,t:1528139898774};\\\", \\\"{x:395,y:596,t:1528139898790};\\\", \\\"{x:418,y:614,t:1528139898807};\\\", \\\"{x:436,y:629,t:1528139898825};\\\", \\\"{x:455,y:642,t:1528139898839};\\\", \\\"{x:474,y:655,t:1528139898858};\\\", \\\"{x:487,y:662,t:1528139898874};\\\", \\\"{x:500,y:670,t:1528139898891};\\\", \\\"{x:509,y:675,t:1528139898907};\\\", \\\"{x:516,y:680,t:1528139898924};\\\", \\\"{x:522,y:685,t:1528139898940};\\\", \\\"{x:524,y:689,t:1528139898958};\\\", \\\"{x:527,y:694,t:1528139898974};\\\", \\\"{x:530,y:700,t:1528139898990};\\\", \\\"{x:531,y:706,t:1528139899008};\\\", \\\"{x:531,y:709,t:1528139899025};\\\", \\\"{x:531,y:714,t:1528139899040};\\\", \\\"{x:531,y:718,t:1528139899057};\\\", \\\"{x:529,y:720,t:1528139899074};\\\", \\\"{x:529,y:723,t:1528139899090};\\\", \\\"{x:528,y:724,t:1528139899107};\\\", \\\"{x:528,y:725,t:1528139899124};\\\", \\\"{x:526,y:727,t:1528139899142};\\\", \\\"{x:526,y:728,t:1528139899157};\\\", \\\"{x:525,y:730,t:1528139899174};\\\", \\\"{x:524,y:732,t:1528139899190};\\\", \\\"{x:523,y:734,t:1528139899208};\\\", \\\"{x:523,y:736,t:1528139899224};\\\", \\\"{x:523,y:737,t:1528139899241};\\\", \\\"{x:522,y:741,t:1528139899256};\\\", \\\"{x:520,y:744,t:1528139899274};\\\", \\\"{x:517,y:748,t:1528139899290};\\\", \\\"{x:515,y:752,t:1528139899307};\\\", \\\"{x:513,y:755,t:1528139899324};\\\", \\\"{x:512,y:759,t:1528139899341};\\\", \\\"{x:511,y:761,t:1528139899357};\\\", \\\"{x:512,y:762,t:1528139899743};\\\", \\\"{x:523,y:762,t:1528139899758};\\\", \\\"{x:565,y:767,t:1528139899774};\\\", \\\"{x:644,y:782,t:1528139899791};\\\", \\\"{x:682,y:790,t:1528139899808};\\\", \\\"{x:714,y:798,t:1528139899823};\\\", \\\"{x:731,y:802,t:1528139899841};\\\", \\\"{x:741,y:803,t:1528139899858};\\\", \\\"{x:743,y:803,t:1528139899874};\\\" ] }, { \\\"rt\\\": 83964, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 20, \\\"time_elapsed\\\": 728749, \\\"internal_node_id\\\": \\\"0.0-7.0-0.0\\\", \\\"subject\\\": \\\"JYGX2\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"yankee\\\", \\\"condition\\\": \\\"311\\\", \\\"q\\\": 16, \\\"answer\\\": \\\"Find 12pm on the x-axis. The point has two diagonals that stem from it. Look at the diagonal stemming from 12pm that points to the right. As you move up the diagonal, any points on that line has a start time of 12pm.\\\", \\\"block\\\": \\\"triangular_testing\\\" }, { \\\"rt\\\": 19801, \\\"responses\\\": \\\"{\\\\\\\"Q0\\\\\\\":\\\\\\\"21\\\\\\\",\\\\\\\"Q1\\\\\\\":\\\\\\\"United States of America\\\\\\\"}\\\", \\\"block\\\": \\\"demo-1\\\", \\\"trial_type\\\": \\\"survey-text\\\", \\\"trial_index\\\": 21, \\\"time_elapsed\\\": 749555, \\\"internal_node_id\\\": \\\"0.0-8.0\\\", \\\"subject\\\": \\\"JYGX2\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"yankee\\\", \\\"condition\\\": \\\"311\\\" }, { \\\"rt\\\": 16123, \\\"responses\\\": \\\"{\\\\\\\"Q0\\\\\\\":\\\\\\\"Other\\\\\\\",\\\\\\\"Q1\\\\\\\":\\\\\\\"Third\\\\\\\",\\\\\\\"Q2\\\\\\\":\\\\\\\"Social Sciences (incl. CogSci)\\\\\\\",\\\\\\\"Q3\\\\\\\":\\\\\\\"Female\\\\\\\"}\\\", \\\"block\\\": \\\"demo-2\\\", \\\"trial_type\\\": \\\"survey-multi-choice\\\", \\\"trial_index\\\": 22, \\\"time_elapsed\\\": 766701, \\\"internal_node_id\\\": \\\"0.0-9.0\\\", \\\"subject\\\": \\\"JYGX2\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"yankee\\\", \\\"condition\\\": \\\"311\\\" }, { \\\"rt\\\": 57154, \\\"url\\\": \\\"../views/src/external/debrief.html\\\", \\\"block\\\": \\\"debrief\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 23, \\\"time_elapsed\\\": 825183, \\\"internal_node_id\\\": \\\"0.0-10.0\\\", \\\"subject\\\": \\\"JYGX2\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"yankee\\\", \\\"condition\\\": \\\"311\\\" } ]\",\"parentNode\":{\"id\":2765}}],[],[]]}"
    }
  ],
  "initialDom": "{\"f\":\"initialize\",\"args\":[1,[{\"nodeType\":10,\"id\":2,\"name\":\"html\",\"publicId\":\"\",\"systemId\":\"\"},{\"nodeType\":1,\"id\":3,\"tagName\":\"HTML\",\"attributes\":{\"class\":\"fa-events-icons-ready\"},\"childNodes\":[{\"nodeType\":1,\"id\":4,\"tagName\":\"HEAD\",\"attributes\":{},\"childNodes\":[{\"nodeType\":3,\"id\":5,\"textContent\":\" \"},{\"nodeType\":1,\"id\":6,\"tagName\":\"TITLE\",\"attributes\":{},\"childNodes\":[{\"nodeType\":3,\"id\":7,\"textContent\":\"FOX2YP\"}]},{\"nodeType\":3,\"id\":8,\"textContent\":\" \"},{\"nodeType\":8,\"id\":9},{\"nodeType\":3,\"id\":10,\"textContent\":\" \"},{\"nodeType\":1,\"id\":11,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":12,\"textContent\":\" \"},{\"nodeType\":1,\"id\":13,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":14,\"textContent\":\" \"},{\"nodeType\":1,\"id\":15,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":16,\"textContent\":\" \"},{\"nodeType\":1,\"id\":17,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":18,\"textContent\":\" \"},{\"nodeType\":1,\"id\":19,\"tagName\":\"SCRIPT\"},{\"nodeType\":1,\"id\":20,\"tagName\":\"LINK\",\"attributes\":{\"href\":\"https://use.fontawesome.com/945539d961.css\",\"media\":\"all\",\"rel\":\"stylesheet\"}},{\"nodeType\":3,\"id\":21,\"textContent\":\" \"},{\"nodeType\":8,\"id\":22},{\"nodeType\":3,\"id\":23,\"textContent\":\" \"},{\"nodeType\":1,\"id\":24,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":25,\"textContent\":\" \"},{\"nodeType\":1,\"id\":26,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":27,\"textContent\":\" \"},{\"nodeType\":1,\"id\":28,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":29,\"textContent\":\" \"},{\"nodeType\":1,\"id\":30,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":31,\"textContent\":\" \"},{\"nodeType\":1,\"id\":32,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":33,\"textContent\":\" \"},{\"nodeType\":1,\"id\":34,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":35,\"textContent\":\" \"},{\"nodeType\":1,\"id\":36,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":37,\"textContent\":\" \"},{\"nodeType\":8,\"id\":38},{\"nodeType\":3,\"id\":39,\"textContent\":\" \"},{\"nodeType\":1,\"id\":40,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":41,\"textContent\":\" \"},{\"nodeType\":8,\"id\":42},{\"nodeType\":3,\"id\":43,\"textContent\":\" \"},{\"nodeType\":8,\"id\":44},{\"nodeType\":3,\"id\":45,\"textContent\":\" \"},{\"nodeType\":1,\"id\":46,\"tagName\":\"LINK\",\"attributes\":{\"href\":\"../views/jsPsych/css/jspsych.css\",\"rel\":\"stylesheet\",\"type\":\"text/css\"}},{\"nodeType\":3,\"id\":47,\"textContent\":\" \"},{\"nodeType\":1,\"id\":48,\"tagName\":\"LINK\",\"attributes\":{\"href\":\"../css/styles.css\",\"rel\":\"stylesheet\",\"type\":\"text/css\"}},{\"nodeType\":3,\"id\":49,\"textContent\":\" \"},{\"nodeType\":1,\"id\":50,\"tagName\":\"SCRIPT\"},{\"nodeType\":1,\"id\":51,\"tagName\":\"SCRIPT\"}]},{\"nodeType\":3,\"id\":52,\"textContent\":\" \"},{\"nodeType\":8,\"id\":53},{\"nodeType\":3,\"id\":54,\"textContent\":\" \"},{\"nodeType\":1,\"id\":55,\"tagName\":\"BODY\",\"attributes\":{\"class\":\"jspsych-display-element\"},\"childNodes\":[{\"nodeType\":3,\"id\":56,\"textContent\":\" \"},{\"nodeType\":1,\"id\":57,\"tagName\":\"META\",\"attributes\":{\"charset\":\"utf-8\"}},{\"nodeType\":3,\"id\":58,\"textContent\":\" \"},{\"nodeType\":8,\"id\":59},{\"nodeType\":3,\"id\":60,\"textContent\":\" \"},{\"nodeType\":1,\"id\":61,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":62,\"textContent\":\" \"},{\"nodeType\":1,\"id\":63,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":64,\"textContent\":\" \"},{\"nodeType\":1,\"id\":65,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":66,\"textContent\":\" \"},{\"nodeType\":1,\"id\":67,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":68,\"textContent\":\" \"},{\"nodeType\":1,\"id\":69,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":70,\"textContent\":\" \"},{\"nodeType\":1,\"id\":71,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":72,\"textContent\":\" \"},{\"nodeType\":1,\"id\":73,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"stimulus\"},\"childNodes\":[{\"nodeType\":3,\"id\":74,\"textContent\":\" \"},{\"nodeType\":1,\"id\":75,\"tagName\":\"P\",\"attributes\":{\"class\":\"userid\",\"id\":\"userid\"},\"childNodes\":[{\"nodeType\":3,\"id\":76,\"textContent\":\"JYGX2\"}]},{\"nodeType\":3,\"id\":77,\"textContent\":\" \"},{\"nodeType\":1,\"id\":78,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"userinput\"},\"childNodes\":[{\"nodeType\":3,\"id\":79,\"textContent\":\" \"},{\"nodeType\":8,\"id\":80},{\"nodeType\":3,\"id\":81,\"textContent\":\" \"},{\"nodeType\":1,\"id\":82,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"legend\",\"id\":\"hint-interactive\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":83,\"textContent\":\" \"},{\"nodeType\":1,\"id\":84,\"tagName\":\"P\",\"attributes\":{},\"childNodes\":[{\"nodeType\":3,\"id\":85,\"textContent\":\"Hint: Hover your mouse over the data points in the graph\"}]},{\"nodeType\":3,\"id\":86,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":87,\"textContent\":\" \"},{\"nodeType\":8,\"id\":88},{\"nodeType\":3,\"id\":89,\"textContent\":\" \"},{\"nodeType\":8,\"id\":90},{\"nodeType\":3,\"id\":91,\"textContent\":\" \"},{\"nodeType\":1,\"id\":92,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"test\"},\"childNodes\":[{\"nodeType\":3,\"id\":93,\"textContent\":\" \"},{\"nodeType\":1,\"id\":94,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"acme\",\"id\":\"acme.starttime\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":95,\"textContent\":\" \"},{\"nodeType\":1,\"id\":96,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":97,\"textContent\":\"Which shift(s) start at 11 am? \"}]},{\"nodeType\":3,\"id\":98,\"textContent\":\" \"},{\"nodeType\":1,\"id\":99,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":100,\"textContent\":\" \"},{\"nodeType\":1,\"id\":101,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":102,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":103,\"textContent\":\" \"},{\"nodeType\":1,\"id\":104,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":105,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":106,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":107,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":108,\"textContent\":\" \"},{\"nodeType\":1,\"id\":109,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":110,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":111,\"textContent\":\" \"},{\"nodeType\":1,\"id\":112,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":113,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":114,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":115,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":116,\"textContent\":\" \"},{\"nodeType\":1,\"id\":117,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":118,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":119,\"textContent\":\" \"},{\"nodeType\":1,\"id\":120,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":121,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":122,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":123,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":124,\"textContent\":\" \"},{\"nodeType\":1,\"id\":125,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":126,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":127,\"textContent\":\" \"},{\"nodeType\":1,\"id\":128,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":129,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":130,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":131,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":132,\"textContent\":\" \"},{\"nodeType\":1,\"id\":133,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":134,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":135,\"textContent\":\" \"},{\"nodeType\":1,\"id\":136,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":137,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":138,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":139,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":140,\"textContent\":\" \"},{\"nodeType\":1,\"id\":141,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":142,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":143,\"textContent\":\" \"},{\"nodeType\":1,\"id\":144,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":145,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":146,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":147,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":148,\"textContent\":\" \"},{\"nodeType\":1,\"id\":149,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":150,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":151,\"textContent\":\" \"},{\"nodeType\":1,\"id\":152,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":153,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":154,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":155,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":156,\"textContent\":\" \"},{\"nodeType\":1,\"id\":157,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":158,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":159,\"textContent\":\" \"},{\"nodeType\":1,\"id\":160,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":161,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":162,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":163,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":164,\"textContent\":\" \"},{\"nodeType\":1,\"id\":165,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":166,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":167,\"textContent\":\" \"},{\"nodeType\":1,\"id\":168,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":169,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":170,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":171,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":172,\"textContent\":\" \"},{\"nodeType\":1,\"id\":173,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":174,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":175,\"textContent\":\" \"},{\"nodeType\":1,\"id\":176,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":177,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":178,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":179,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":180,\"textContent\":\" \"},{\"nodeType\":1,\"id\":181,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":182,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":183,\"textContent\":\" \"},{\"nodeType\":1,\"id\":184,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"U\",\"value\":\"\"}},{\"nodeType\":3,\"id\":185,\"textContent\":\"U \"},{\"nodeType\":1,\"id\":186,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":187,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":188,\"textContent\":\" \"},{\"nodeType\":1,\"id\":189,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":190,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":191,\"textContent\":\" \"},{\"nodeType\":1,\"id\":192,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":193,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":194,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":195,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":196,\"textContent\":\" \"},{\"nodeType\":1,\"id\":197,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":198,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":199,\"textContent\":\" \"},{\"nodeType\":1,\"id\":200,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":201,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":202,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":203,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":204,\"textContent\":\" \"},{\"nodeType\":1,\"id\":205,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":206,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":207,\"textContent\":\" \"},{\"nodeType\":1,\"id\":208,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":209,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":210,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":211,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":212,\"textContent\":\" \"},{\"nodeType\":1,\"id\":213,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":214,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":215,\"textContent\":\" \"},{\"nodeType\":1,\"id\":216,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":217,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":218,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":219,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":220,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":221,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":222,\"textContent\":\" \"},{\"nodeType\":1,\"id\":223,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"acme\",\"id\":\"acme.starts\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":224,\"textContent\":\" \"},{\"nodeType\":1,\"id\":225,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":226,\"textContent\":\"Which shift(s) start at the same time as D?\"}]},{\"nodeType\":3,\"id\":227,\"textContent\":\" \"},{\"nodeType\":1,\"id\":228,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":229,\"textContent\":\" \"},{\"nodeType\":1,\"id\":230,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":231,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":232,\"textContent\":\" \"},{\"nodeType\":1,\"id\":233,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":234,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":235,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":236,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":237,\"textContent\":\" \"},{\"nodeType\":1,\"id\":238,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":239,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":240,\"textContent\":\" \"},{\"nodeType\":1,\"id\":241,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":242,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":243,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":244,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":245,\"textContent\":\" \"},{\"nodeType\":1,\"id\":246,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":247,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":248,\"textContent\":\" \"},{\"nodeType\":1,\"id\":249,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":250,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":251,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":252,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":253,\"textContent\":\" \"},{\"nodeType\":1,\"id\":254,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":255,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":256,\"textContent\":\" \"},{\"nodeType\":1,\"id\":257,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":258,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":259,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":260,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":261,\"textContent\":\" \"},{\"nodeType\":1,\"id\":262,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":263,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":264,\"textContent\":\" \"},{\"nodeType\":1,\"id\":265,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":266,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":267,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":268,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":269,\"textContent\":\" \"},{\"nodeType\":1,\"id\":270,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":271,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":272,\"textContent\":\" \"},{\"nodeType\":1,\"id\":273,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":274,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":275,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":276,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":277,\"textContent\":\" \"},{\"nodeType\":1,\"id\":278,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":279,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":280,\"textContent\":\" \"},{\"nodeType\":1,\"id\":281,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":282,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":283,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":284,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":285,\"textContent\":\" \"},{\"nodeType\":1,\"id\":286,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":287,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":288,\"textContent\":\" \"},{\"nodeType\":1,\"id\":289,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":290,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":291,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":292,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":293,\"textContent\":\" \"},{\"nodeType\":1,\"id\":294,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":295,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":296,\"textContent\":\" \"},{\"nodeType\":1,\"id\":297,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":298,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":299,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":300,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":301,\"textContent\":\" \"},{\"nodeType\":1,\"id\":302,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":303,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":304,\"textContent\":\" \"},{\"nodeType\":1,\"id\":305,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":306,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":307,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":308,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":309,\"textContent\":\" \"},{\"nodeType\":1,\"id\":310,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":311,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":312,\"textContent\":\" \"},{\"nodeType\":1,\"id\":313,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"U\",\"value\":\"\"}},{\"nodeType\":3,\"id\":314,\"textContent\":\"U \"},{\"nodeType\":1,\"id\":315,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":316,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":317,\"textContent\":\" \"},{\"nodeType\":1,\"id\":318,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":319,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":320,\"textContent\":\" \"},{\"nodeType\":1,\"id\":321,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":322,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":323,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":324,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":325,\"textContent\":\" \"},{\"nodeType\":1,\"id\":326,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":327,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":328,\"textContent\":\" \"},{\"nodeType\":1,\"id\":329,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":330,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":331,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":332,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":333,\"textContent\":\" \"},{\"nodeType\":1,\"id\":334,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":335,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":336,\"textContent\":\" \"},{\"nodeType\":1,\"id\":337,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":338,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":339,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":340,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":341,\"textContent\":\" \"},{\"nodeType\":1,\"id\":342,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":343,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":344,\"textContent\":\" \"},{\"nodeType\":1,\"id\":345,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":346,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":347,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":348,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":349,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":350,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":351,\"textContent\":\" \"},{\"nodeType\":1,\"id\":352,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"acme\",\"id\":\"acme.meets\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":353,\"textContent\":\" \"},{\"nodeType\":1,\"id\":354,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":355,\"textContent\":\"Which shift(s) begin when C ends?\"}]},{\"nodeType\":3,\"id\":356,\"textContent\":\" \"},{\"nodeType\":1,\"id\":357,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":358,\"textContent\":\" \"},{\"nodeType\":1,\"id\":359,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":360,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":361,\"textContent\":\" \"},{\"nodeType\":1,\"id\":362,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":363,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":364,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":365,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":366,\"textContent\":\" \"},{\"nodeType\":1,\"id\":367,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":368,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":369,\"textContent\":\" \"},{\"nodeType\":1,\"id\":370,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":371,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":372,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":373,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":374,\"textContent\":\" \"},{\"nodeType\":1,\"id\":375,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":376,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":377,\"textContent\":\" \"},{\"nodeType\":1,\"id\":378,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":379,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":380,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":381,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":382,\"textContent\":\" \"},{\"nodeType\":1,\"id\":383,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":384,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":385,\"textContent\":\" \"},{\"nodeType\":1,\"id\":386,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":387,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":388,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":389,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":390,\"textContent\":\" \"},{\"nodeType\":1,\"id\":391,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":392,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":393,\"textContent\":\" \"},{\"nodeType\":1,\"id\":394,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":395,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":396,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":397,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":398,\"textContent\":\" \"},{\"nodeType\":1,\"id\":399,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":400,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":401,\"textContent\":\" \"},{\"nodeType\":1,\"id\":402,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":403,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":404,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":405,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":406,\"textContent\":\" \"},{\"nodeType\":1,\"id\":407,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":408,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":409,\"textContent\":\" \"},{\"nodeType\":1,\"id\":410,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":411,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":412,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":413,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":414,\"textContent\":\" \"},{\"nodeType\":1,\"id\":415,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":416,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":417,\"textContent\":\" \"},{\"nodeType\":1,\"id\":418,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":419,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":420,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":421,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":422,\"textContent\":\" \"},{\"nodeType\":1,\"id\":423,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":424,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":425,\"textContent\":\" \"},{\"nodeType\":1,\"id\":426,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":427,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":428,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":429,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":430,\"textContent\":\" \"},{\"nodeType\":1,\"id\":431,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":432,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":433,\"textContent\":\" \"},{\"nodeType\":1,\"id\":434,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":435,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":436,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":437,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":438,\"textContent\":\" \"},{\"nodeType\":1,\"id\":439,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":440,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":441,\"textContent\":\" \"},{\"nodeType\":1,\"id\":442,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"U\",\"value\":\"\"}},{\"nodeType\":3,\"id\":443,\"textContent\":\"U \"},{\"nodeType\":1,\"id\":444,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":445,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":446,\"textContent\":\" \"},{\"nodeType\":1,\"id\":447,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":448,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":449,\"textContent\":\" \"},{\"nodeType\":1,\"id\":450,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":451,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":452,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":453,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":454,\"textContent\":\" \"},{\"nodeType\":1,\"id\":455,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":456,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":457,\"textContent\":\" \"},{\"nodeType\":1,\"id\":458,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":459,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":460,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":461,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":462,\"textContent\":\" \"},{\"nodeType\":1,\"id\":463,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":464,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":465,\"textContent\":\" \"},{\"nodeType\":1,\"id\":466,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":467,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":468,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":469,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":470,\"textContent\":\" \"},{\"nodeType\":1,\"id\":471,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":472,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":473,\"textContent\":\" \"},{\"nodeType\":1,\"id\":474,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":475,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":476,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":477,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":478,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":479,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":480,\"textContent\":\" \"},{\"nodeType\":1,\"id\":481,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"acme\",\"id\":\"acme.endtime\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":482,\"textContent\":\" \"},{\"nodeType\":1,\"id\":483,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":484,\"textContent\":\" Which shift(s) end at 4 pm?\"}]},{\"nodeType\":3,\"id\":485,\"textContent\":\" \"},{\"nodeType\":1,\"id\":486,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":487,\"textContent\":\" \"},{\"nodeType\":1,\"id\":488,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":489,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":490,\"textContent\":\" \"},{\"nodeType\":1,\"id\":491,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":492,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":493,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":494,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":495,\"textContent\":\" \"},{\"nodeType\":1,\"id\":496,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":497,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":498,\"textContent\":\" \"},{\"nodeType\":1,\"id\":499,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":500,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":501,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":502,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":503,\"textContent\":\" \"},{\"nodeType\":1,\"id\":504,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":505,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":506,\"textContent\":\" \"},{\"nodeType\":1,\"id\":507,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":508,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":509,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":510,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":511,\"textContent\":\" \"},{\"nodeType\":1,\"id\":512,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":513,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":514,\"textContent\":\" \"},{\"nodeType\":1,\"id\":515,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":516,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":517,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":518,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":519,\"textContent\":\" \"},{\"nodeType\":1,\"id\":520,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":521,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":522,\"textContent\":\" \"},{\"nodeType\":1,\"id\":523,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":524,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":525,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":526,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":527,\"textContent\":\" \"},{\"nodeType\":1,\"id\":528,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":529,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":530,\"textContent\":\" \"},{\"nodeType\":1,\"id\":531,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":532,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":533,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":534,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":535,\"textContent\":\" \"},{\"nodeType\":1,\"id\":536,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":537,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":538,\"textContent\":\" \"},{\"nodeType\":1,\"id\":539,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":540,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":541,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":542,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":543,\"textContent\":\" \"},{\"nodeType\":1,\"id\":544,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":545,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":546,\"textContent\":\" \"},{\"nodeType\":1,\"id\":547,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":548,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":549,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":550,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":551,\"textContent\":\" \"},{\"nodeType\":1,\"id\":552,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":553,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":554,\"textContent\":\" \"},{\"nodeType\":1,\"id\":555,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":556,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":557,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":558,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":559,\"textContent\":\" \"},{\"nodeType\":1,\"id\":560,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":561,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":562,\"textContent\":\" \"},{\"nodeType\":1,\"id\":563,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":564,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":565,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":566,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":567,\"textContent\":\" \"},{\"nodeType\":1,\"id\":568,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":569,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":570,\"textContent\":\" \"},{\"nodeType\":1,\"id\":571,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"U\",\"value\":\"\"}},{\"nodeType\":3,\"id\":572,\"textContent\":\"U \"},{\"nodeType\":1,\"id\":573,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":574,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":575,\"textContent\":\" \"},{\"nodeType\":1,\"id\":576,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":577,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":578,\"textContent\":\" \"},{\"nodeType\":1,\"id\":579,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":580,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":581,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":582,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":583,\"textContent\":\" \"},{\"nodeType\":1,\"id\":584,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":585,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":586,\"textContent\":\" \"},{\"nodeType\":1,\"id\":587,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":588,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":589,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":590,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":591,\"textContent\":\" \"},{\"nodeType\":1,\"id\":592,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":593,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":594,\"textContent\":\" \"},{\"nodeType\":1,\"id\":595,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":596,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":597,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":598,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":599,\"textContent\":\" \"},{\"nodeType\":1,\"id\":600,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":601,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":602,\"textContent\":\" \"},{\"nodeType\":1,\"id\":603,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":604,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":605,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":606,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":607,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":608,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":609,\"textContent\":\" \"},{\"nodeType\":1,\"id\":610,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"acme\",\"id\":\"acme.midpoint\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":611,\"textContent\":\" \"},{\"nodeType\":1,\"id\":612,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":613,\"textContent\":\"Coffee breaks happen halfway through a shift.\"},{\"nodeType\":1,\"id\":614,\"tagName\":\"BR\",\"attributes\":{}},{\"nodeType\":3,\"id\":615,\"textContent\":\" Which shift(s) share a break with I?\"}]},{\"nodeType\":3,\"id\":616,\"textContent\":\" \"},{\"nodeType\":1,\"id\":617,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":618,\"textContent\":\" \"},{\"nodeType\":1,\"id\":619,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":620,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":621,\"textContent\":\" \"},{\"nodeType\":1,\"id\":622,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":623,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":624,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":625,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":626,\"textContent\":\" \"},{\"nodeType\":1,\"id\":627,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":628,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":629,\"textContent\":\" \"},{\"nodeType\":1,\"id\":630,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":631,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":632,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":633,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":634,\"textContent\":\" \"},{\"nodeType\":1,\"id\":635,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":636,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":637,\"textContent\":\" \"},{\"nodeType\":1,\"id\":638,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":639,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":640,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":641,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":642,\"textContent\":\" \"},{\"nodeType\":1,\"id\":643,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":644,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":645,\"textContent\":\" \"},{\"nodeType\":1,\"id\":646,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":647,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":648,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":649,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":650,\"textContent\":\" \"},{\"nodeType\":1,\"id\":651,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":652,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":653,\"textContent\":\" \"},{\"nodeType\":1,\"id\":654,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":655,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":656,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":657,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":658,\"textContent\":\" \"},{\"nodeType\":1,\"id\":659,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":660,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":661,\"textContent\":\" \"},{\"nodeType\":1,\"id\":662,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":663,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":664,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":665,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":666,\"textContent\":\" \"},{\"nodeType\":1,\"id\":667,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":668,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":669,\"textContent\":\" \"},{\"nodeType\":1,\"id\":670,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":671,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":672,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":673,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":674,\"textContent\":\" \"},{\"nodeType\":1,\"id\":675,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":676,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":677,\"textContent\":\" \"},{\"nodeType\":1,\"id\":678,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":679,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":680,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":681,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":682,\"textContent\":\" \"},{\"nodeType\":1,\"id\":683,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":684,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":685,\"textContent\":\" \"},{\"nodeType\":1,\"id\":686,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":687,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":688,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":689,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":690,\"textContent\":\" \"},{\"nodeType\":1,\"id\":691,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":692,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":693,\"textContent\":\" \"},{\"nodeType\":1,\"id\":694,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":695,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":696,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":697,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":698,\"textContent\":\" \"},{\"nodeType\":1,\"id\":699,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":700,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":701,\"textContent\":\" \"},{\"nodeType\":1,\"id\":702,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"U\",\"value\":\"\"}},{\"nodeType\":3,\"id\":703,\"textContent\":\"U \"},{\"nodeType\":1,\"id\":704,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":705,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":706,\"textContent\":\" \"},{\"nodeType\":1,\"id\":707,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":708,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":709,\"textContent\":\" \"},{\"nodeType\":1,\"id\":710,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":711,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":712,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":713,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":714,\"textContent\":\" \"},{\"nodeType\":1,\"id\":715,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":716,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":717,\"textContent\":\" \"},{\"nodeType\":1,\"id\":718,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":719,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":720,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":721,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":722,\"textContent\":\" \"},{\"nodeType\":1,\"id\":723,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":724,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":725,\"textContent\":\" \"},{\"nodeType\":1,\"id\":726,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":727,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":728,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":729,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":730,\"textContent\":\" \"},{\"nodeType\":1,\"id\":731,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":732,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":733,\"textContent\":\" \"},{\"nodeType\":1,\"id\":734,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":735,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":736,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":737,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":738,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":739,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":740,\"textContent\":\" \"},{\"nodeType\":1,\"id\":741,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.duration\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":742,\"textContent\":\" \"},{\"nodeType\":1,\"id\":743,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":744,\"textContent\":\"Which shift(s) are six hours long?\"}]},{\"nodeType\":3,\"id\":745,\"textContent\":\" \"},{\"nodeType\":1,\"id\":746,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":747,\"textContent\":\" \"},{\"nodeType\":1,\"id\":748,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":749,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":750,\"textContent\":\" \"},{\"nodeType\":1,\"id\":751,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":752,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":753,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":754,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":755,\"textContent\":\" \"},{\"nodeType\":1,\"id\":756,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":757,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":758,\"textContent\":\" \"},{\"nodeType\":1,\"id\":759,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":760,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":761,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":762,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":763,\"textContent\":\" \"},{\"nodeType\":1,\"id\":764,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":765,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":766,\"textContent\":\" \"},{\"nodeType\":1,\"id\":767,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":768,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":769,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":770,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":771,\"textContent\":\" \"},{\"nodeType\":1,\"id\":772,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":773,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":774,\"textContent\":\" \"},{\"nodeType\":1,\"id\":775,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":776,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":777,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":778,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":779,\"textContent\":\" \"},{\"nodeType\":1,\"id\":780,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":781,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":782,\"textContent\":\" \"},{\"nodeType\":1,\"id\":783,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":784,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":785,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":786,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":787,\"textContent\":\" \"},{\"nodeType\":1,\"id\":788,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":789,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":790,\"textContent\":\" \"},{\"nodeType\":1,\"id\":791,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":792,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":793,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":794,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":795,\"textContent\":\" \"},{\"nodeType\":1,\"id\":796,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":797,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":798,\"textContent\":\" \"},{\"nodeType\":1,\"id\":799,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":800,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":801,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":802,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":803,\"textContent\":\" \"},{\"nodeType\":1,\"id\":804,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":805,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":806,\"textContent\":\" \"},{\"nodeType\":1,\"id\":807,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":808,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":809,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":810,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":811,\"textContent\":\" \"},{\"nodeType\":1,\"id\":812,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":813,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":814,\"textContent\":\" \"},{\"nodeType\":1,\"id\":815,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":816,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":817,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":818,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":819,\"textContent\":\" \"},{\"nodeType\":1,\"id\":820,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":821,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":822,\"textContent\":\" \"},{\"nodeType\":1,\"id\":823,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":824,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":825,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":826,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":827,\"textContent\":\" \"},{\"nodeType\":1,\"id\":828,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":829,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":830,\"textContent\":\" \"},{\"nodeType\":1,\"id\":831,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":832,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":833,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":834,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":835,\"textContent\":\" \"},{\"nodeType\":1,\"id\":836,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":837,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":838,\"textContent\":\" \"},{\"nodeType\":1,\"id\":839,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":840,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":841,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":842,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":843,\"textContent\":\" \"},{\"nodeType\":1,\"id\":844,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":845,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":846,\"textContent\":\" \"},{\"nodeType\":1,\"id\":847,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":848,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":849,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":850,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":851,\"textContent\":\" \"},{\"nodeType\":1,\"id\":852,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":853,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":854,\"textContent\":\" \"},{\"nodeType\":1,\"id\":855,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":856,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":857,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":858,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":859,\"textContent\":\" \"},{\"nodeType\":1,\"id\":860,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":861,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":862,\"textContent\":\" \"},{\"nodeType\":1,\"id\":863,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":864,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":865,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":866,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":867,\"textContent\":\" \"},{\"nodeType\":1,\"id\":868,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":869,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":870,\"textContent\":\" \"},{\"nodeType\":1,\"id\":871,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":872,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":873,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":874,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":875,\"textContent\":\" \"},{\"nodeType\":1,\"id\":876,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":877,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":878,\"textContent\":\" \"},{\"nodeType\":1,\"id\":879,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":880,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":881,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":882,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":883,\"textContent\":\" \"},{\"nodeType\":1,\"id\":884,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":885,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":886,\"textContent\":\" \"},{\"nodeType\":1,\"id\":887,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":888,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":889,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":890,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":891,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":892,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":893,\"textContent\":\" \"},{\"nodeType\":1,\"id\":894,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.duration+starts\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":895,\"textContent\":\" \"},{\"nodeType\":1,\"id\":896,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":897,\"textContent\":\"Which 2 shifts less than 5 hours long start at the same time?\"}]},{\"nodeType\":3,\"id\":898,\"textContent\":\" \"},{\"nodeType\":1,\"id\":899,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":900,\"textContent\":\" \"},{\"nodeType\":1,\"id\":901,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":902,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":903,\"textContent\":\" \"},{\"nodeType\":1,\"id\":904,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":905,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":906,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":907,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":908,\"textContent\":\" \"},{\"nodeType\":1,\"id\":909,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":910,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":911,\"textContent\":\" \"},{\"nodeType\":1,\"id\":912,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":913,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":914,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":915,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":916,\"textContent\":\" \"},{\"nodeType\":1,\"id\":917,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":918,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":919,\"textContent\":\" \"},{\"nodeType\":1,\"id\":920,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":921,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":922,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":923,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":924,\"textContent\":\" \"},{\"nodeType\":1,\"id\":925,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":926,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":927,\"textContent\":\" \"},{\"nodeType\":1,\"id\":928,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":929,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":930,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":931,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":932,\"textContent\":\" \"},{\"nodeType\":1,\"id\":933,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":934,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":935,\"textContent\":\" \"},{\"nodeType\":1,\"id\":936,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":937,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":938,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":939,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":940,\"textContent\":\" \"},{\"nodeType\":1,\"id\":941,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":942,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":943,\"textContent\":\" \"},{\"nodeType\":1,\"id\":944,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":945,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":946,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":947,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":948,\"textContent\":\" \"},{\"nodeType\":1,\"id\":949,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":950,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":951,\"textContent\":\" \"},{\"nodeType\":1,\"id\":952,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":953,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":954,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":955,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":956,\"textContent\":\" \"},{\"nodeType\":1,\"id\":957,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":958,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":959,\"textContent\":\" \"},{\"nodeType\":1,\"id\":960,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":961,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":962,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":963,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":964,\"textContent\":\" \"},{\"nodeType\":1,\"id\":965,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":966,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":967,\"textContent\":\" \"},{\"nodeType\":1,\"id\":968,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":969,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":970,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":971,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":972,\"textContent\":\" \"},{\"nodeType\":1,\"id\":973,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":974,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":975,\"textContent\":\" \"},{\"nodeType\":1,\"id\":976,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":977,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":978,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":979,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":980,\"textContent\":\" \"},{\"nodeType\":1,\"id\":981,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":982,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":983,\"textContent\":\" \"},{\"nodeType\":1,\"id\":984,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":985,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":986,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":987,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":988,\"textContent\":\" \"},{\"nodeType\":1,\"id\":989,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":990,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":991,\"textContent\":\" \"},{\"nodeType\":1,\"id\":992,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":993,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":994,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":995,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":996,\"textContent\":\" \"},{\"nodeType\":1,\"id\":997,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":998,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":999,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1000,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1001,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":1002,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1003,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1004,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1005,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1006,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1007,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1008,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1009,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":1010,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1011,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1012,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1013,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1014,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1015,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1016,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1017,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":1018,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1019,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1020,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1021,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1022,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1023,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1024,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1025,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":1026,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1027,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1028,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1029,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1030,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1031,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1032,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1033,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":1034,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1035,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1036,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1037,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1038,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1039,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1040,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1041,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":1042,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1043,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1044,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1045,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1046,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1047,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.duration+contained\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":1048,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1049,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":1050,\"textContent\":\"Which shift(s) under 7 hours long starts before B starts, and ends after X ends?\"}]},{\"nodeType\":3,\"id\":1051,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1052,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":1053,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1054,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1055,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1056,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1057,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1058,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":1059,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1060,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1061,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1062,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1063,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1064,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1065,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1066,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":1067,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1068,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1069,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1070,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1071,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1072,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1073,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1074,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":1075,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1076,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1077,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1078,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1079,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1080,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1081,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1082,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":1083,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1084,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1085,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1086,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1087,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1088,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1089,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1090,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":1091,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1092,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1093,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1094,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1095,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1096,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1097,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1098,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":1099,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1100,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1101,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1102,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1103,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1104,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1105,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1106,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":1107,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1108,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1109,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1110,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1111,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1112,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1113,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1114,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":1115,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1116,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1117,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1118,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1119,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1120,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1121,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1122,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":1123,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1124,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1125,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1126,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1127,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1128,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1129,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1130,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":1131,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1132,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1133,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1134,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1135,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1136,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1137,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1138,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":1139,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1140,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1141,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1142,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1143,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1144,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1145,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1146,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":1147,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1148,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1149,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1150,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1151,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1152,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1153,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1154,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":1155,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1156,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1157,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1158,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1159,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1160,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1161,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1162,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":1163,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1164,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1165,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1166,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1167,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1168,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1169,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1170,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":1171,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1172,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1173,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1174,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1175,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1176,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1177,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1178,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":1179,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1180,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1181,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1182,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1183,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1184,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1185,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1186,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":1187,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1188,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1189,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1190,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1191,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1192,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1193,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1194,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":1195,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1196,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1197,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1198,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1199,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1200,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.starttime+before+endtime+during\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":1201,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1202,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":1203,\"textContent\":\"Which shift(s) begins before J begins and ends during B?\"}]},{\"nodeType\":3,\"id\":1204,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1205,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":1206,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1207,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1208,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1209,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1210,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1211,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":1212,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1213,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1214,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1215,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1216,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1217,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1218,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1219,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":1220,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1221,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1222,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1223,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1224,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1225,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1226,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1227,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":1228,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1229,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1230,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1231,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1232,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1233,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1234,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1235,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":1236,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1237,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1238,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1239,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1240,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1241,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1242,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1243,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":1244,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1245,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1246,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1247,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1248,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1249,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1250,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1251,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":1252,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1253,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1254,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1255,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1256,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1257,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1258,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1259,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":1260,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1261,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1262,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1263,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1264,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1265,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1266,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1267,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":1268,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1269,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1270,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1271,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1272,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1273,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1274,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1275,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":1276,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1277,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1278,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1279,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1280,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1281,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1282,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1283,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":1284,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1285,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1286,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1287,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1288,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1289,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1290,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1291,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":1292,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1293,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1294,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1295,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1296,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1297,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1298,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1299,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":1300,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1301,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1302,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1303,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1304,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1305,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1306,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1307,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":1308,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1309,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1310,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1311,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1312,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1313,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1314,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1315,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":1316,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1317,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1318,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1319,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1320,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1321,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1322,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1323,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":1324,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1325,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1326,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1327,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1328,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1329,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1330,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1331,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":1332,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1333,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1334,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1335,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1336,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1337,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1338,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1339,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":1340,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1341,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1342,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1343,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1344,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1345,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1346,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1347,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":1348,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1349,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1350,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1351,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1352,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1353,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.ends\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":1354,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1355,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":1356,\"textContent\":\"Which shift(s) end at the same time as F?\"}]},{\"nodeType\":3,\"id\":1357,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1358,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":1359,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1360,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1361,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1362,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1363,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1364,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":1365,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1366,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1367,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1368,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1369,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1370,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1371,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1372,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":1373,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1374,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1375,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1376,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1377,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1378,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1379,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1380,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":1381,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1382,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1383,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1384,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1385,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1386,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1387,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1388,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":1389,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1390,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1391,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1392,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1393,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1394,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1395,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1396,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":1397,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1398,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1399,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1400,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1401,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1402,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1403,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1404,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":1405,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1406,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1407,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1408,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1409,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1410,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1411,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1412,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":1413,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1414,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1415,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1416,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1417,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1418,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1419,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1420,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":1421,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1422,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1423,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1424,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1425,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1426,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1427,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1428,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":1429,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1430,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1431,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1432,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1433,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1434,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1435,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1436,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":1437,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1438,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1439,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1440,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1441,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1442,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1443,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1444,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":1445,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1446,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1447,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1448,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1449,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1450,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1451,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1452,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":1453,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1454,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1455,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1456,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1457,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1458,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1459,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1460,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":1461,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1462,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1463,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1464,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1465,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1466,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1467,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1468,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":1469,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1470,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1471,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1472,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1473,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1474,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1475,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1476,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":1477,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1478,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1479,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1480,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1481,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1482,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1483,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1484,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":1485,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1486,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1487,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1488,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1489,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1490,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1491,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1492,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":1493,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1494,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1495,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1496,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1497,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1498,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1499,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1500,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":1501,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1502,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1503,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1504,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1505,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1506,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.starttime\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":1507,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1508,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":1509,\"textContent\":\"Which shift(s) start at 12pm?\"}]},{\"nodeType\":3,\"id\":1510,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1511,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":1512,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1513,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1514,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1515,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1516,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1517,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":1518,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1519,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1520,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1521,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1522,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1523,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1524,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1525,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":1526,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1527,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1528,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1529,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1530,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1531,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1532,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1533,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":1534,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1535,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1536,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1537,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1538,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1539,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1540,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1541,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":1542,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1543,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1544,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1545,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1546,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1547,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1548,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1549,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":1550,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1551,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1552,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1553,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1554,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1555,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1556,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1557,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":1558,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1559,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1560,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1561,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1562,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1563,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1564,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1565,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":1566,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1567,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1568,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1569,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1570,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1571,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1572,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1573,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":1574,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1575,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1576,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1577,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1578,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1579,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1580,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1581,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":1582,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1583,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1584,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1585,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1586,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1587,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1588,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1589,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":1590,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1591,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1592,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1593,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1594,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1595,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1596,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1597,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":1598,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1599,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1600,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1601,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1602,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1603,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1604,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1605,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":1606,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1607,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1608,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1609,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1610,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1611,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1612,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1613,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":1614,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1615,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1616,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1617,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1618,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1619,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1620,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1621,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":1622,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1623,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1624,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1625,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1626,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1627,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1628,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1629,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":1630,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1631,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1632,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1633,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1634,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1635,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1636,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1637,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":1638,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1639,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1640,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1641,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1642,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1643,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1644,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1645,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":1646,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1647,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1648,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1649,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1650,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1651,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1652,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1653,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":1654,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1655,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1656,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1657,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1658,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1659,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.starts\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":1660,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1661,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":1662,\"textContent\":\"Which shift(s) start at the same time as F?\"}]},{\"nodeType\":3,\"id\":1663,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1664,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":1665,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1666,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1667,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1668,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1669,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1670,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":1671,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1672,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1673,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1674,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1675,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1676,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1677,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1678,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":1679,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1680,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1681,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1682,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1683,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1684,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1685,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1686,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":1687,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1688,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1689,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1690,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1691,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1692,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1693,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1694,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":1695,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1696,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1697,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1698,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1699,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1700,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1701,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1702,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":1703,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1704,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1705,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1706,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1707,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1708,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1709,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1710,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":1711,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1712,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1713,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1714,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1715,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1716,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1717,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1718,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":1719,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1720,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1721,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1722,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1723,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1724,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1725,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1726,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":1727,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1728,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1729,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1730,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1731,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1732,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1733,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1734,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":1735,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1736,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1737,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1738,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1739,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1740,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1741,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1742,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":1743,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1744,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1745,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1746,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1747,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1748,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1749,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1750,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":1751,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1752,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1753,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1754,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1755,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1756,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1757,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1758,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":1759,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1760,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1761,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1762,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1763,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1764,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1765,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1766,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":1767,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1768,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1769,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1770,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1771,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1772,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1773,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1774,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":1775,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1776,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1777,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1778,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1779,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1780,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1781,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1782,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":1783,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1784,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1785,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1786,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1787,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1788,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1789,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1790,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":1791,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1792,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1793,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1794,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1795,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1796,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1797,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1798,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":1799,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1800,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1801,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1802,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1803,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1804,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1805,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1806,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":1807,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1808,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1809,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1810,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1811,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1812,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.meets\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":1813,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1814,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":1815,\"textContent\":\"Which 2 shifts end when Z begins?\"}]},{\"nodeType\":3,\"id\":1816,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1817,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":1818,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1819,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1820,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1821,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1822,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1823,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":1824,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1825,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1826,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1827,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1828,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1829,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1830,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1831,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":1832,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1833,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1834,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1835,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1836,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1837,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1838,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1839,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":1840,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1841,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1842,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1843,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1844,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1845,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1846,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1847,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":1848,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1849,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1850,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1851,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1852,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1853,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1854,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1855,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":1856,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1857,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1858,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1859,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1860,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1861,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1862,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1863,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":1864,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1865,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1866,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1867,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1868,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1869,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1870,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1871,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":1872,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1873,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1874,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1875,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1876,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1877,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1878,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1879,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":1880,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1881,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1882,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1883,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1884,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1885,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1886,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1887,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":1888,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1889,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1890,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1891,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1892,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1893,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1894,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1895,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":1896,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1897,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1898,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1899,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1900,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1901,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1902,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1903,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":1904,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1905,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1906,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1907,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1908,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1909,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1910,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1911,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":1912,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1913,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1914,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1915,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1916,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1917,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1918,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1919,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":1920,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1921,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1922,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1923,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1924,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1925,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1926,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1927,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":1928,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1929,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1930,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1931,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1932,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1933,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1934,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1935,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":1936,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1937,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1938,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1939,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1940,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1941,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1942,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1943,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":1944,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1945,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1946,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1947,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1948,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1949,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1950,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1951,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":1952,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1953,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1954,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1955,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1956,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1957,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1958,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1959,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":1960,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1961,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1962,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1963,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1964,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1965,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.endtime\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":1966,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1967,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":1968,\"textContent\":\"Which shift(s) end at 3pm?\"}]},{\"nodeType\":3,\"id\":1969,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1970,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":1971,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1972,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1973,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1974,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1975,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1976,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":1977,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1978,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1979,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1980,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1981,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1982,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1983,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1984,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":1985,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1986,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1987,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1988,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1989,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1990,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1991,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1992,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":1993,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1994,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1995,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1996,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1997,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1998,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1999,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2000,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":2001,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2002,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2003,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2004,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2005,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2006,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2007,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2008,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":2009,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2010,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2011,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2012,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2013,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2014,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2015,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2016,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":2017,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2018,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2019,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2020,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2021,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2022,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2023,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2024,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":2025,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2026,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2027,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2028,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2029,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2030,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2031,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2032,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":2033,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2034,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2035,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2036,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2037,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2038,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2039,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2040,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":2041,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2042,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2043,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2044,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2045,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2046,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2047,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2048,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":2049,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2050,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2051,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2052,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2053,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2054,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2055,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2056,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":2057,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2058,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2059,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2060,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2061,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2062,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2063,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2064,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":2065,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2066,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2067,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2068,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2069,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2070,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2071,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2072,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":2073,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2074,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2075,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2076,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2077,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2078,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2079,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2080,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":2081,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2082,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2083,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2084,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2085,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2086,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2087,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2088,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":2089,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2090,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2091,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2092,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2093,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2094,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2095,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2096,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":2097,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2098,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2099,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2100,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2101,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2102,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2103,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2104,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":2105,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2106,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2107,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2108,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2109,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2110,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2111,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2112,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":2113,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2114,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2115,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2116,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2117,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2118,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.midpoint\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":2119,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2120,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":2121,\"textContent\":\"Coffee breaks happen halfway through a shift. \"},{\"nodeType\":1,\"id\":2122,\"tagName\":\"BR\",\"attributes\":{}},{\"nodeType\":3,\"id\":2123,\"textContent\":\"Which shifts share a break at 2pm?\"}]},{\"nodeType\":3,\"id\":2124,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2125,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":2126,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2127,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2128,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2129,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2130,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2131,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":2132,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2133,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2134,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2135,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2136,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2137,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2138,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2139,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":2140,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2141,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2142,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2143,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2144,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2145,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2146,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2147,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":2148,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2149,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2150,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2151,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2152,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2153,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2154,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2155,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":2156,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2157,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2158,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2159,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2160,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2161,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2162,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2163,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":2164,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2165,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2166,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2167,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2168,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2169,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2170,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2171,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":2172,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2173,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2174,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2175,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2176,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2177,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2178,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2179,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":2180,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2181,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2182,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2183,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2184,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2185,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2186,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2187,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":2188,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2189,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2190,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2191,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2192,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2193,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2194,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2195,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":2196,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2197,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2198,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2199,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2200,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2201,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2202,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2203,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":2204,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2205,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2206,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2207,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2208,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2209,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2210,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2211,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":2212,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2213,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2214,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2215,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2216,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2217,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2218,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2219,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":2220,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2221,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2222,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2223,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2224,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2225,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2226,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2227,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":2228,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2229,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2230,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2231,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2232,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2233,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2234,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2235,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":2236,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2237,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2238,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2239,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2240,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2241,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2242,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2243,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":2244,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2245,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2246,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2247,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2248,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2249,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2250,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2251,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":2252,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2253,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2254,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2255,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2256,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2257,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2258,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2259,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":2260,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2261,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2262,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2263,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2264,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2265,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2266,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2267,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":2268,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2269,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2270,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2271,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2272,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2273,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\".strategy\",\"style\":\"display: block;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2274,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2275,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":2276,\"textContent\":\"Please describe how to determine what event(s) start at 12pm?\"}]},{\"nodeType\":3,\"id\":2277,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2278,\"tagName\":\"TEXTAREA\",\"attributes\":{\"id\":\"strategyAnswer\",\"rows\":\"5\",\"cols\":\"80\"}},{\"nodeType\":3,\"id\":2279,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2280,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2281,\"textContent\":\" \"},{\"nodeType\":8,\"id\":2282},{\"nodeType\":3,\"id\":2283,\"textContent\":\" \"},{\"nodeType\":8,\"id\":2284},{\"nodeType\":3,\"id\":2285,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2286,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"fixbottom\"},\"childNodes\":[{\"nodeType\":3,\"id\":2287,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2288,\"tagName\":\"BUTTON\",\"attributes\":{\"type\":\"button\",\"id\":\"testingButton\",\"style\":\"display:none;\",\"class\":\"btn\"},\"childNodes\":[{\"nodeType\":3,\"id\":2289,\"textContent\":\"SUBMIT\"}]},{\"nodeType\":3,\"id\":2290,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2291,\"tagName\":\"BUTTON\",\"attributes\":{\"type\":\"button\",\"id\":\"strategyButton\",\"style\":\"display: block;\",\"class\":\"btn\"},\"childNodes\":[{\"nodeType\":3,\"id\":2292,\"textContent\":\"SUBMIT\"}]},{\"nodeType\":3,\"id\":2293,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2294,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2295,\"textContent\":\" \"},{\"nodeType\":8,\"id\":2296},{\"nodeType\":3,\"id\":2297,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2298,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"d3container\"},\"childNodes\":[{\"nodeType\":1,\"id\":2299,\"tagName\":\"svg\",\"attributes\":{\"width\":\"930\",\"height\":\"915\"},\"childNodes\":[{\"nodeType\":1,\"id\":2300,\"tagName\":\"g\",\"attributes\":{\"transform\":\"translate(100,25)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2301,\"tagName\":\"g\",\"attributes\":{\"class\":\"leaders\"}},{\"nodeType\":1,\"id\":2302,\"tagName\":\"g\",\"attributes\":{\"class\":\"static-scaffold\"}},{\"nodeType\":1,\"id\":2303,\"tagName\":\"g\",\"attributes\":{\"class\":\"xaxis\",\"transform\":\"translate(0,800)\",\"fill\":\"none\",\"font-size\":\"10\",\"font-family\":\"sans-serif\",\"text-anchor\":\"middle\"},\"childNodes\":[{\"nodeType\":1,\"id\":2304,\"tagName\":\"path\",\"attributes\":{\"class\":\"domain\",\"stroke\":\"#000\",\"d\":\"M0.5,6V0.5H800.5V6\"}},{\"nodeType\":1,\"id\":2305,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0.5,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2306,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2307,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2308,\"textContent\":\"08 AM\"}]}]},{\"nodeType\":1,\"id\":2309,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(33.83333333333333,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2310,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2311,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2312,\"textContent\":\"08:30\"}]}]},{\"nodeType\":1,\"id\":2313,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(67.16666666666666,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2314,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2315,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2316,\"textContent\":\"09 AM\"}]}]},{\"nodeType\":1,\"id\":2317,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(100.5,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2318,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2319,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2320,\"textContent\":\"09:30\"}]}]},{\"nodeType\":1,\"id\":2321,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(133.83333333333331,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2322,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2323,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2324,\"textContent\":\"10 AM\"}]}]},{\"nodeType\":1,\"id\":2325,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(167.16666666666669,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2326,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2327,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2328,\"textContent\":\"10:30\"}]}]},{\"nodeType\":1,\"id\":2329,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(200.5,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2330,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2331,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2332,\"textContent\":\"11 AM\"}]}]},{\"nodeType\":1,\"id\":2333,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(233.83333333333334,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2334,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2335,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2336,\"textContent\":\"11:30\"}]}]},{\"nodeType\":1,\"id\":2337,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(267.16666666666663,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2338,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2339,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2340,\"textContent\":\"12 PM\"}]}]},{\"nodeType\":1,\"id\":2341,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(300.5,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2342,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2343,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2344,\"textContent\":\"12:30\"}]}]},{\"nodeType\":1,\"id\":2345,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(333.83333333333337,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2346,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2347,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2348,\"textContent\":\"01 PM\"}]}]},{\"nodeType\":1,\"id\":2349,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(367.16666666666663,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2350,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2351,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2352,\"textContent\":\"01:30\"}]}]},{\"nodeType\":1,\"id\":2353,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(400.5,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2354,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2355,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2356,\"textContent\":\"02 PM\"}]}]},{\"nodeType\":1,\"id\":2357,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(433.8333333333333,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2358,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2359,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2360,\"textContent\":\"02:30\"}]}]},{\"nodeType\":1,\"id\":2361,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(467.1666666666667,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2362,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2363,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2364,\"textContent\":\"03 PM\"}]}]},{\"nodeType\":1,\"id\":2365,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(500.5,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2366,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2367,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2368,\"textContent\":\"03:30\"}]}]},{\"nodeType\":1,\"id\":2369,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(533.8333333333333,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2370,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2371,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2372,\"textContent\":\"04 PM\"}]}]},{\"nodeType\":1,\"id\":2373,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(567.1666666666667,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2374,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2375,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2376,\"textContent\":\"04:30\"}]}]},{\"nodeType\":1,\"id\":2377,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(600.5,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2378,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2379,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2380,\"textContent\":\"05 PM\"}]}]},{\"nodeType\":1,\"id\":2381,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(633.8333333333333,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2382,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2383,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2384,\"textContent\":\"05:30\"}]}]},{\"nodeType\":1,\"id\":2385,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(667.1666666666667,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2386,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2387,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2388,\"textContent\":\"06 PM\"}]}]},{\"nodeType\":1,\"id\":2389,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(700.5,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2390,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2391,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2392,\"textContent\":\"06:30\"}]}]},{\"nodeType\":1,\"id\":2393,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(733.8333333333333,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2394,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2395,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2396,\"textContent\":\"07 PM\"}]}]},{\"nodeType\":1,\"id\":2397,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(767.1666666666667,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2398,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2399,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2400,\"textContent\":\"07:30\"}]}]},{\"nodeType\":1,\"id\":2401,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(800.5,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2402,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2403,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2404,\"textContent\":\"08 PM\"}]}]},{\"nodeType\":1,\"id\":2405,\"tagName\":\"g\",\"attributes\":{\"class\":\"axisTitle\"},\"childNodes\":[{\"nodeType\":1,\"id\":2406,\"tagName\":\"text\",\"attributes\":{\"x\":\"533.3333333333334\",\"y\":\"80\",\"style\":\"text-anchor: end;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2407,\"textContent\":\"START & END TIME (time of day)\"}]}]}]},{\"nodeType\":1,\"id\":2408,\"tagName\":\"g\",\"attributes\":{\"class\":\"yaxis\",\"fill\":\"none\",\"font-size\":\"10\",\"font-family\":\"sans-serif\",\"text-anchor\":\"end\"},\"childNodes\":[{\"nodeType\":1,\"id\":2409,\"tagName\":\"path\",\"attributes\":{\"class\":\"domain\",\"stroke\":\"#000\",\"d\":\"M-15,800.5H0.5V0.5H-15\"}},{\"nodeType\":1,\"id\":2410,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,800.5)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2411,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2412,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2413,\"textContent\":\"0\"}]}]},{\"nodeType\":1,\"id\":2414,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,733.8333333333334)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2415,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2416,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2417,\"textContent\":\"1\"}]}]},{\"nodeType\":1,\"id\":2418,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,667.1666666666667)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2419,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2420,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2421,\"textContent\":\"2\"}]}]},{\"nodeType\":1,\"id\":2422,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,600.5)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2423,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2424,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2425,\"textContent\":\"3\"}]}]},{\"nodeType\":1,\"id\":2426,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,533.8333333333334)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2427,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2428,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2429,\"textContent\":\"4\"}]}]},{\"nodeType\":1,\"id\":2430,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,467.16666666666663)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2431,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2432,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2433,\"textContent\":\"5\"}]}]},{\"nodeType\":1,\"id\":2434,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,400.5)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2435,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2436,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2437,\"textContent\":\"6\"}]}]},{\"nodeType\":1,\"id\":2438,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,333.8333333333333)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2439,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2440,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2441,\"textContent\":\"7\"}]}]},{\"nodeType\":1,\"id\":2442,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,267.16666666666674)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2443,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2444,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2445,\"textContent\":\"8\"}]}]},{\"nodeType\":1,\"id\":2446,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,200.5)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2447,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2448,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2449,\"textContent\":\"9\"}]}]},{\"nodeType\":1,\"id\":2450,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,133.83333333333326)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2451,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2452,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2453,\"textContent\":\"10\"}]}]},{\"nodeType\":1,\"id\":2454,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,67.16666666666674)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2455,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2456,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2457,\"textContent\":\"11\"}]}]},{\"nodeType\":1,\"id\":2458,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,0.5)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2459,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2460,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2461,\"textContent\":\"12\"}]}]},{\"nodeType\":1,\"id\":2462,\"tagName\":\"g\",\"attributes\":{\"class\":\"axisTitle\"},\"childNodes\":[{\"nodeType\":1,\"id\":2463,\"tagName\":\"text\",\"attributes\":{\"transform\":\"rotate(-90)\",\"x\":\"-350\",\"y\":\"-60\",\"style\":\"text-anchor: end;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2464,\"textContent\":\"DURATION (in hours)\"}]}]}]},{\"nodeType\":1,\"id\":2465,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2466,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2467,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"733.3333333333334\",\"y2\":\"733.3333333333334\"}}]},{\"nodeType\":1,\"id\":2468,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2469,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"666.6666666666667\",\"y2\":\"666.6666666666667\"}}]},{\"nodeType\":1,\"id\":2470,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2471,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"600\",\"y2\":\"600\"}}]},{\"nodeType\":1,\"id\":2472,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2473,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"533.3333333333334\",\"y2\":\"533.3333333333334\"}}]},{\"nodeType\":1,\"id\":2474,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2475,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"466.66666666666663\",\"y2\":\"466.66666666666663\"}}]},{\"nodeType\":1,\"id\":2476,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2477,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"400\",\"y2\":\"400\"}}]},{\"nodeType\":1,\"id\":2478,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2479,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"333.3333333333333\",\"y2\":\"333.3333333333333\"}}]},{\"nodeType\":1,\"id\":2480,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2481,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"266.66666666666674\",\"y2\":\"266.66666666666674\"}}]},{\"nodeType\":1,\"id\":2482,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2483,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"200\",\"y2\":\"200\"}}]},{\"nodeType\":1,\"id\":2484,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2485,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"133.33333333333326\",\"y2\":\"133.33333333333326\"}}]},{\"nodeType\":1,\"id\":2486,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2487,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"66.66666666666674\",\"y2\":\"66.66666666666674\"}}]},{\"nodeType\":1,\"id\":2488,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2489,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"0\",\"y2\":\"0\"}}]}]},{\"nodeType\":1,\"id\":2490,\"tagName\":\"g\",\"attributes\":{\"class\":\"xgrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2491,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"0\",\"y1\":\"800\",\"x2\":\"400\",\"y2\":\"0\"}},{\"nodeType\":1,\"id\":2492,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"800\",\"y1\":\"800\",\"x2\":\"400\",\"y2\":\"0\"}},{\"nodeType\":1,\"id\":2493,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"66.66666666666666\",\"y1\":\"800\",\"x2\":\"433.3333333333333\",\"y2\":\"66.66666666666674\"}},{\"nodeType\":1,\"id\":2494,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"733.3333333333333\",\"y1\":\"800\",\"x2\":\"366.66666666666663\",\"y2\":\"66.66666666666674\"}},{\"nodeType\":1,\"id\":2495,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"133.33333333333331\",\"y1\":\"800\",\"x2\":\"466.6666666666667\",\"y2\":\"133.33333333333326\"}},{\"nodeType\":1,\"id\":2496,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"666.6666666666667\",\"y1\":\"800\",\"x2\":\"333.33333333333337\",\"y2\":\"133.33333333333326\"}},{\"nodeType\":1,\"id\":2497,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"200\",\"y1\":\"800\",\"x2\":\"500\",\"y2\":\"200\"}},{\"nodeType\":1,\"id\":2498,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"600\",\"y1\":\"800\",\"x2\":\"300\",\"y2\":\"200\"}},{\"nodeType\":1,\"id\":2499,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"266.66666666666663\",\"y1\":\"800\",\"x2\":\"533.3333333333333\",\"y2\":\"266.66666666666674\"}},{\"nodeType\":1,\"id\":2500,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"533.3333333333333\",\"y1\":\"800\",\"x2\":\"266.66666666666663\",\"y2\":\"266.66666666666674\"}},{\"nodeType\":1,\"id\":2501,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"333.33333333333337\",\"y1\":\"800\",\"x2\":\"566.6666666666667\",\"y2\":\"333.3333333333333\"}},{\"nodeType\":1,\"id\":2502,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"466.6666666666667\",\"y1\":\"800\",\"x2\":\"233.33333333333334\",\"y2\":\"333.3333333333333\"}},{\"nodeType\":1,\"id\":2503,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"400\",\"y1\":\"800\",\"x2\":\"600\",\"y2\":\"400\"}},{\"nodeType\":1,\"id\":2504,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"400\",\"y1\":\"800\",\"x2\":\"200\",\"y2\":\"400\"}},{\"nodeType\":1,\"id\":2505,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"466.6666666666667\",\"y1\":\"800\",\"x2\":\"633.3333333333333\",\"y2\":\"466.66666666666663\"}},{\"nodeType\":1,\"id\":2506,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"333.33333333333337\",\"y1\":\"800\",\"x2\":\"166.66666666666669\",\"y2\":\"466.66666666666663\"}},{\"nodeType\":1,\"id\":2507,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"533.3333333333333\",\"y1\":\"800\",\"x2\":\"666.6666666666667\",\"y2\":\"533.3333333333334\"}},{\"nodeType\":1,\"id\":2508,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"266.66666666666663\",\"y1\":\"800\",\"x2\":\"133.33333333333331\",\"y2\":\"533.3333333333334\"}},{\"nodeType\":1,\"id\":2509,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"600\",\"y1\":\"800\",\"x2\":\"700\",\"y2\":\"600\"}},{\"nodeType\":1,\"id\":2510,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"200\",\"y1\":\"800\",\"x2\":\"100\",\"y2\":\"600\"}},{\"nodeType\":1,\"id\":2511,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"666.6666666666667\",\"y1\":\"800\",\"x2\":\"733.3333333333333\",\"y2\":\"666.6666666666667\"}},{\"nodeType\":1,\"id\":2512,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"133.33333333333331\",\"y1\":\"800\",\"x2\":\"66.66666666666666\",\"y2\":\"666.6666666666667\"}},{\"nodeType\":1,\"id\":2513,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"733.3333333333333\",\"y1\":\"800\",\"x2\":\"766.6666666666667\",\"y2\":\"733.3333333333334\"}},{\"nodeType\":1,\"id\":2514,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"66.66666666666666\",\"y1\":\"800\",\"x2\":\"33.33333333333333\",\"y2\":\"733.3333333333334\"}}]},{\"nodeType\":1,\"id\":2515,\"tagName\":\"g\",\"attributes\":{\"class\":\"data\"},\"childNodes\":[{\"nodeType\":1,\"id\":2516,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2517,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"333.33333333333337\",\"cy\":\"266.66666666666674\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2518,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"328.33333333333337\",\"y\":\"258.66666666666674\"},\"childNodes\":[{\"nodeType\":3,\"id\":2519,\"textContent\":\"A \"}]}]},{\"nodeType\":1,\"id\":2520,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2521,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"266.66666666666663\",\"cy\":\"600\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2522,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"261.66666666666663\",\"y\":\"592\"},\"childNodes\":[{\"nodeType\":3,\"id\":2523,\"textContent\":\"B \"}]}]},{\"nodeType\":1,\"id\":2524,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2525,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"366.66666666666663\",\"cy\":\"466.66666666666663\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2526,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"361.66666666666663\",\"y\":\"458.66666666666663\"},\"childNodes\":[{\"nodeType\":3,\"id\":2527,\"textContent\":\"C \"}]}]},{\"nodeType\":1,\"id\":2528,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2529,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"666.6666666666667\",\"cy\":\"666.6666666666667\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2530,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"661.6666666666667\",\"y\":\"658.6666666666667\"},\"childNodes\":[{\"nodeType\":3,\"id\":2531,\"textContent\":\"D \"}]}]},{\"nodeType\":1,\"id\":2532,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2533,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"200\",\"cy\":\"400\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2534,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"195\",\"y\":\"392\"},\"childNodes\":[{\"nodeType\":3,\"id\":2535,\"textContent\":\"E \"}]}]},{\"nodeType\":1,\"id\":2536,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2537,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"266.66666666666663\",\"cy\":\"533.3333333333334\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2538,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"261.66666666666663\",\"y\":\"525.3333333333334\"},\"childNodes\":[{\"nodeType\":3,\"id\":2539,\"textContent\":\"F \"}]}]},{\"nodeType\":1,\"id\":2540,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2541,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"333.33333333333337\",\"cy\":\"400\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2542,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"328.33333333333337\",\"y\":\"392\"},\"childNodes\":[{\"nodeType\":3,\"id\":2543,\"textContent\":\"G \"}]}]},{\"nodeType\":1,\"id\":2544,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2545,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"500\",\"cy\":\"466.66666666666663\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2546,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"495\",\"y\":\"458.66666666666663\"},\"childNodes\":[{\"nodeType\":3,\"id\":2547,\"textContent\":\"H \"}]}]},{\"nodeType\":1,\"id\":2548,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2549,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"100\",\"cy\":\"600\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2550,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"95\",\"y\":\"592\"},\"childNodes\":[{\"nodeType\":3,\"id\":2551,\"textContent\":\"I \"}]}]},{\"nodeType\":1,\"id\":2552,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2553,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"133.33333333333331\",\"cy\":\"666.6666666666667\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2554,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"128.33333333333331\",\"y\":\"658.6666666666667\"},\"childNodes\":[{\"nodeType\":3,\"id\":2555,\"textContent\":\"J \"}]}]},{\"nodeType\":1,\"id\":2556,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2557,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"400\",\"cy\":\"133.33333333333326\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2558,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"395\",\"y\":\"125.33333333333326\"},\"childNodes\":[{\"nodeType\":3,\"id\":2559,\"textContent\":\"K \"}]}]},{\"nodeType\":1,\"id\":2560,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2561,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"500\",\"cy\":\"333.3333333333333\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2562,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"495\",\"y\":\"325.3333333333333\"},\"childNodes\":[{\"nodeType\":3,\"id\":2563,\"textContent\":\"L \"}]}]},{\"nodeType\":1,\"id\":2564,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2565,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"300\",\"cy\":\"733.3333333333334\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2566,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"295\",\"y\":\"725.3333333333334\"},\"childNodes\":[{\"nodeType\":3,\"id\":2567,\"textContent\":\"M \"}]}]},{\"nodeType\":1,\"id\":2568,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2569,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"600\",\"cy\":\"666.6666666666667\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2570,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"595\",\"y\":\"658.6666666666667\"},\"childNodes\":[{\"nodeType\":3,\"id\":2571,\"textContent\":\"N \"}]}]},{\"nodeType\":1,\"id\":2572,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2573,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"433.3333333333333\",\"cy\":\"600\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2574,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"428.3333333333333\",\"y\":\"592\"},\"childNodes\":[{\"nodeType\":3,\"id\":2575,\"textContent\":\"O \"}]}]},{\"nodeType\":1,\"id\":2576,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2577,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"500\",\"cy\":\"200\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2578,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"495\",\"y\":\"192\"},\"childNodes\":[{\"nodeType\":3,\"id\":2579,\"textContent\":\"P \"}]}]},{\"nodeType\":1,\"id\":2580,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2581,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"533.3333333333333\",\"cy\":\"533.3333333333334\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2582,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"528.3333333333333\",\"y\":\"525.3333333333334\"},\"childNodes\":[{\"nodeType\":3,\"id\":2583,\"textContent\":\"Z \"}]}]},{\"nodeType\":1,\"id\":2584,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2585,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"400\",\"cy\":\"666.6666666666667\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2586,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"395\",\"y\":\"658.6666666666667\"},\"childNodes\":[{\"nodeType\":3,\"id\":2587,\"textContent\":\"X \"}]}]}]}]}]}]},{\"nodeType\":3,\"id\":2588,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2589,\"textContent\":\" \"},{\"nodeType\":8,\"id\":2590},{\"nodeType\":3,\"id\":2591,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2592,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":2593,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2594,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":2595,\"textContent\":\" \"}]}]}]]}",
  "useCssProxy": true,
  "loadTimes": "es: 155, dom: 783, initialDom: 1180",
  "javascriptErrors": []
}