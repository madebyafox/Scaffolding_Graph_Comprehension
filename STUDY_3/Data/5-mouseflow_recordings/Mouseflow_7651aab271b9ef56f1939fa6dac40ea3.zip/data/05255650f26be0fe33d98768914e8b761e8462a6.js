var MF = MF || {};MF.RecordingData = MF.RecordingData || {};MF.RecordingData["05255650f26be0fe33d98768914e8b761e8462a6"] = {
  "startTime": "2018-05-25T17:25:56.3570438Z",
  "websitePageUrl": "/16",
  "visitTime": 255142,
  "engagementTime": 147872,
  "pageTitle": "FOX2YP",
  "url": "https://warm-citadel-75324.herokuapp.com/",
  "viewportWidth": 1920,
  "viewportHeight": 1094,
  "tags": [
    "form-interact",
    "submit"
  ],
  "session": {
    "id": "7651aab271b9ef56f1939fa6dac40ea3",
    "created": "2018-05-25T17:25:56.3522469+00:00",
    "lastActivity": "0001-01-01T00:00:00+00:00",
    "pages": 1,
    "duration": 0,
    "engagementTime": 0,
    "totalFriction": 0,
    "country": "us",
    "region": "CA",
    "city": "La Jolla",
    "isp": "University of California, San Diego",
    "ip": "###.###.###.###",
    "lang": "en-US",
    "userAgent": "Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/66.0.3359.181 Safari/537.36",
    "browser": "Chrome",
    "browserVersion": "66.0.3359.181",
    "os": "Windows",
    "osVersion": "7",
    "device": "Desktop",
    "referrer": "",
    "referrerType": "",
    "screenRes": "1920x1200",
    "entryPage": "/16",
    "tags": [
      "form-interact",
      "submit"
    ],
    "variables": [
      "SID=YC7SX",
      "CONDITION=115-late"
    ],
    "watched": false,
    "starred": false,
    "lng": 32.8807,
    "lat": 32.8807,
    "visitorId": "7570a6d66231236f478eee0ec95ff8a9",
    "gdpr": false,
    "visitorName": null,
    "playbackUrl": "https://us.mouseflow.com/websites/e0c9ff05-6fcb-4c4a-8173-e5a0724987b1/recordings/7651aab271b9ef56f1939fa6dac40ea3/play"
  },
  "events": [
    {
      "t": 1,
      "e": 1,
      "ty": 14,
      "x": 0,
      "y": 1093
    },
    {
      "t": 101,
      "e": 101,
      "ty": 0,
      "x": 1920,
      "y": 1094
    },
    {
      "t": 634,
      "e": 634,
      "ty": 38,
      "x": 1,
      "y": 0
    },
    {
      "t": 704,
      "e": 704,
      "ty": 38,
      "x": 2,
      "y": 0
    },
    {
      "t": 5601,
      "e": 5101,
      "ty": 2,
      "x": 547,
      "y": 680
    },
    {
      "t": 5700,
      "e": 5200,
      "ty": 2,
      "x": 547,
      "y": 647
    },
    {
      "t": 5751,
      "e": 5251,
      "ty": 41,
      "x": 51473,
      "y": 37848,
      "ta": "> div.stimulus > div"
    },
    {
      "t": 5801,
      "e": 5301,
      "ty": 2,
      "x": 561,
      "y": 615
    },
    {
      "t": 5901,
      "e": 5401,
      "ty": 2,
      "x": 576,
      "y": 570
    },
    {
      "t": 5997,
      "e": 5497,
      "ty": 6,
      "x": 583,
      "y": 549,
      "ta": "#strategyAnswer"
    },
    {
      "t": 6001,
      "e": 5501,
      "ty": 2,
      "x": 583,
      "y": 549
    },
    {
      "t": 6001,
      "e": 5501,
      "ty": 41,
      "x": 54620,
      "y": 64131,
      "ta": "#strategyAnswer"
    },
    {
      "t": 6101,
      "e": 5601,
      "ty": 2,
      "x": 588,
      "y": 534
    },
    {
      "t": 6201,
      "e": 5701,
      "ty": 2,
      "x": 593,
      "y": 527
    },
    {
      "t": 6251,
      "e": 5751,
      "ty": 41,
      "x": 55744,
      "y": 46332,
      "ta": "#strategyAnswer"
    },
    {
      "t": 7169,
      "e": 6669,
      "ty": 3,
      "x": 593,
      "y": 527,
      "ta": "#strategyAnswer"
    },
    {
      "t": 7171,
      "e": 6671,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 7407,
      "e": 6907,
      "ty": 4,
      "x": 55744,
      "y": 46332,
      "ta": "#strategyAnswer"
    },
    {
      "t": 7408,
      "e": 6908,
      "ty": 5,
      "x": 593,
      "y": 527,
      "ta": "#strategyAnswer"
    },
    {
      "t": 10001,
      "e": 9501,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 16661,
      "e": 11908,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "73"
    },
    {
      "t": 16661,
      "e": 11908,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 16755,
      "e": 12002,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "70"
    },
    {
      "t": 16755,
      "e": 12002,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 16779,
      "e": 12026,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "if"
    },
    {
      "t": 16859,
      "e": 12106,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "if"
    },
    {
      "t": 16956,
      "e": 12203,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 16956,
      "e": 12203,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 17131,
      "e": 12378,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "89"
    },
    {
      "t": 17132,
      "e": 12379,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 17138,
      "e": 12385,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "if y"
    },
    {
      "t": 17228,
      "e": 12475,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 17325,
      "e": 12572,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "79"
    },
    {
      "t": 17326,
      "e": 12573,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 17403,
      "e": 12650,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "85"
    },
    {
      "t": 17403,
      "e": 12650,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 17532,
      "e": 12779,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||ou"
    },
    {
      "t": 17556,
      "e": 12803,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 17715,
      "e": 12962,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 17716,
      "e": 12963,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 17818,
      "e": 13065,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 17963,
      "e": 13210,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "76"
    },
    {
      "t": 17963,
      "e": 13210,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 18058,
      "e": 13305,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||l"
    },
    {
      "t": 18178,
      "e": 13425,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "79"
    },
    {
      "t": 18179,
      "e": 13426,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 18275,
      "e": 13522,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||o"
    },
    {
      "t": 18355,
      "e": 13602,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "79"
    },
    {
      "t": 18356,
      "e": 13603,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 18531,
      "e": 13778,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||o"
    },
    {
      "t": 18572,
      "e": 13819,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "75"
    },
    {
      "t": 18572,
      "e": 13819,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 18731,
      "e": 13978,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||k"
    },
    {
      "t": 18804,
      "e": 14051,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 18804,
      "e": 14051,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 18900,
      "e": 14147,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 18916,
      "e": 14163,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 18917,
      "e": 14164,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 19051,
      "e": 14298,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 19052,
      "e": 14299,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 19107,
      "e": 14354,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||at"
    },
    {
      "t": 19164,
      "e": 14411,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 19195,
      "e": 14442,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 19196,
      "e": 14443,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 19331,
      "e": 14578,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 19387,
      "e": 14634,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 19387,
      "e": 14634,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 19459,
      "e": 14706,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "72"
    },
    {
      "t": 19460,
      "e": 14707,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 19514,
      "e": 14761,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||th"
    },
    {
      "t": 19611,
      "e": 14858,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 19612,
      "e": 14859,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 19651,
      "e": 14898,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||e"
    },
    {
      "t": 19691,
      "e": 14938,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 19747,
      "e": 14994,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 19749,
      "e": 14996,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 19875,
      "e": 15122,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "72"
    },
    {
      "t": 19876,
      "e": 15123,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 19891,
      "e": 15138,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| h"
    },
    {
      "t": 19986,
      "e": 15233,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 20099,
      "e": 15346,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "79"
    },
    {
      "t": 20100,
      "e": 15347,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 20202,
      "e": 15449,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "if you look at the ho"
    },
    {
      "t": 20203,
      "e": 15450,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||o"
    },
    {
      "t": 20275,
      "e": 15522,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "82"
    },
    {
      "t": 20275,
      "e": 15522,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 20380,
      "e": 15627,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||r"
    },
    {
      "t": 20467,
      "e": 15714,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "73"
    },
    {
      "t": 20468,
      "e": 15715,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 20563,
      "e": 15810,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||i"
    },
    {
      "t": 21084,
      "e": 16331,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "90"
    },
    {
      "t": 21085,
      "e": 16332,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 21187,
      "e": 16434,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "79"
    },
    {
      "t": 21187,
      "e": 16434,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 21195,
      "e": 16442,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||zo"
    },
    {
      "t": 21311,
      "e": 16558,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "78"
    },
    {
      "t": 21312,
      "e": 16559,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 21359,
      "e": 16606,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||n"
    },
    {
      "t": 21448,
      "e": 16695,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 21455,
      "e": 16702,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 21456,
      "e": 16703,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 21567,
      "e": 16814,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 21567,
      "e": 16814,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 21598,
      "e": 16845,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||ta"
    },
    {
      "t": 21646,
      "e": 16893,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "76"
    },
    {
      "t": 21647,
      "e": 16894,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 21703,
      "e": 16950,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||l"
    },
    {
      "t": 21806,
      "e": 17053,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "if you look at the horizontal"
    },
    {
      "t": 21815,
      "e": 17062,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 21816,
      "e": 17063,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 21847,
      "e": 17094,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 21927,
      "e": 17174,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 22063,
      "e": 17310,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 22063,
      "e": 17310,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 22184,
      "e": 17431,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||a"
    },
    {
      "t": 22311,
      "e": 17558,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "88"
    },
    {
      "t": 22312,
      "e": 17559,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 22422,
      "e": 17669,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||x"
    },
    {
      "t": 22446,
      "e": 17693,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "73"
    },
    {
      "t": 22447,
      "e": 17694,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 22559,
      "e": 17806,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||i"
    },
    {
      "t": 22561,
      "e": 17808,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "83"
    },
    {
      "t": 22562,
      "e": 17809,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 22678,
      "e": 17925,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||s"
    },
    {
      "t": 22734,
      "e": 17981,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 22735,
      "e": 17982,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 22815,
      "e": 18062,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 27943,
      "e": 23062,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "89"
    },
    {
      "t": 27943,
      "e": 23062,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 28038,
      "e": 23157,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||y"
    },
    {
      "t": 28054,
      "e": 23173,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "79"
    },
    {
      "t": 28054,
      "e": 23173,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 28167,
      "e": 23286,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "85"
    },
    {
      "t": 28168,
      "e": 23287,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 28263,
      "e": 23382,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||ou"
    },
    {
      "t": 28278,
      "e": 23397,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 28439,
      "e": 23558,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 28440,
      "e": 23559,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 28542,
      "e": 23661,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 28598,
      "e": 23717,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "67"
    },
    {
      "t": 28599,
      "e": 23718,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 28687,
      "e": 23806,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 28688,
      "e": 23807,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 28766,
      "e": 23885,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||ca"
    },
    {
      "t": 28806,
      "e": 23925,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "78"
    },
    {
      "t": 28807,
      "e": 23926,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 28839,
      "e": 23958,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||n"
    },
    {
      "t": 28897,
      "e": 23961,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 29005,
      "e": 24069,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "if you look at the horizontal axis you can"
    },
    {
      "t": 29038,
      "e": 24102,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 29038,
      "e": 24102,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 29103,
      "e": 24167,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 29143,
      "e": 24207,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "83"
    },
    {
      "t": 29144,
      "e": 24208,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 29222,
      "e": 24286,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||s"
    },
    {
      "t": 29359,
      "e": 24423,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 29359,
      "e": 24423,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 29415,
      "e": 24479,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||e"
    },
    {
      "t": 29535,
      "e": 24599,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 29535,
      "e": 24599,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 29583,
      "e": 24647,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||e"
    },
    {
      "t": 29670,
      "e": 24734,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 29671,
      "e": 24735,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 29774,
      "e": 24838,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 30095,
      "e": 25159,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "87"
    },
    {
      "t": 30095,
      "e": 25159,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 30190,
      "e": 25254,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||w"
    },
    {
      "t": 30271,
      "e": 25335,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "72"
    },
    {
      "t": 30272,
      "e": 25336,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 30350,
      "e": 25414,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||h"
    },
    {
      "t": 30471,
      "e": 25535,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "73"
    },
    {
      "t": 30471,
      "e": 25535,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 30574,
      "e": 25638,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||i"
    },
    {
      "t": 30671,
      "e": 25735,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "67"
    },
    {
      "t": 30672,
      "e": 25736,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 30742,
      "e": 25806,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||c"
    },
    {
      "t": 30959,
      "e": 26023,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "72"
    },
    {
      "t": 30959,
      "e": 26023,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 31047,
      "e": 26111,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||h"
    },
    {
      "t": 31182,
      "e": 26246,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 31183,
      "e": 26247,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 31286,
      "e": 26350,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 32199,
      "e": 27263,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "83"
    },
    {
      "t": 32200,
      "e": 27264,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 32278,
      "e": 27342,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||s"
    },
    {
      "t": 32335,
      "e": 27399,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "72"
    },
    {
      "t": 32335,
      "e": 27399,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 32471,
      "e": 27535,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "73"
    },
    {
      "t": 32471,
      "e": 27535,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 32494,
      "e": 27558,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||hi"
    },
    {
      "t": 32599,
      "e": 27663,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 32720,
      "e": 27784,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "70"
    },
    {
      "t": 32720,
      "e": 27784,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 32799,
      "e": 27863,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||f"
    },
    {
      "t": 32951,
      "e": 28015,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 32952,
      "e": 28016,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 33022,
      "e": 28086,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 33087,
      "e": 28151,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 33087,
      "e": 28151,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 33206,
      "e": 28270,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "if you look at the horizontal axis you can see which shift "
    },
    {
      "t": 33222,
      "e": 28286,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "76"
    },
    {
      "t": 33222,
      "e": 28286,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 33230,
      "e": 28294,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| l"
    },
    {
      "t": 33406,
      "e": 28470,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "if you look at the horizontal axis you can see which shift l"
    },
    {
      "t": 33407,
      "e": 28471,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 33455,
      "e": 28519,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "73"
    },
    {
      "t": 33456,
      "e": 28520,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 33598,
      "e": 28662,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "78"
    },
    {
      "t": 33598,
      "e": 28662,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 33630,
      "e": 28694,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||in"
    },
    {
      "t": 33695,
      "e": 28759,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 33791,
      "e": 28855,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 33791,
      "e": 28855,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 33871,
      "e": 28935,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "83"
    },
    {
      "t": 33871,
      "e": 28935,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 33903,
      "e": 28967,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||es"
    },
    {
      "t": 34007,
      "e": 29071,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "if you look at the horizontal axis you can see which shift lines"
    },
    {
      "t": 34008,
      "e": 29072,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 34031,
      "e": 29095,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 34032,
      "e": 29096,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 34129,
      "e": 29193,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 34222,
      "e": 29286,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "79"
    },
    {
      "t": 34223,
      "e": 29287,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 34359,
      "e": 29423,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||o"
    },
    {
      "t": 34758,
      "e": 29822,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 34879,
      "e": 29943,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "if you look at the horizontal axis you can see which shift lines "
    },
    {
      "t": 35087,
      "e": 30151,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "85"
    },
    {
      "t": 35089,
      "e": 30153,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 35166,
      "e": 30230,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||u"
    },
    {
      "t": 35175,
      "e": 30239,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "80"
    },
    {
      "t": 35175,
      "e": 30239,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 35255,
      "e": 30319,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||p"
    },
    {
      "t": 36990,
      "e": 32054,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 37489,
      "e": 32553,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 37522,
      "e": 32586,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 37556,
      "e": 32620,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 37588,
      "e": 32652,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 37621,
      "e": 32685,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 37655,
      "e": 32719,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 37687,
      "e": 32751,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 37721,
      "e": 32752,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 37753,
      "e": 32784,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 37786,
      "e": 32817,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 37819,
      "e": 32850,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 37852,
      "e": 32883,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 37886,
      "e": 32917,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 37918,
      "e": 32949,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 37950,
      "e": 32981,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "if you look at the horizontal axis you can see which"
    },
    {
      "t": 38231,
      "e": 33262,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 38406,
      "e": 33437,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "if you look at the horizontal axis you can see whic"
    },
    {
      "t": 38731,
      "e": 33762,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 38763,
      "e": 33794,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 38796,
      "e": 33827,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 38829,
      "e": 33860,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 38862,
      "e": 33893,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 38895,
      "e": 33926,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 38928,
      "e": 33959,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 38961,
      "e": 33992,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 38994,
      "e": 34025,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 39027,
      "e": 34058,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 39060,
      "e": 34091,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 39093,
      "e": 34124,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 39118,
      "e": 34149,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "if you look at the horizontal axis you "
    },
    {
      "t": 39351,
      "e": 34382,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 39415,
      "e": 34446,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "if you look at the horizontal axis you"
    },
    {
      "t": 39519,
      "e": 34550,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 39583,
      "e": 34614,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "if you look at the horizontal axis yo"
    },
    {
      "t": 39687,
      "e": 34718,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 39743,
      "e": 34774,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "if you look at the horizontal axis y"
    },
    {
      "t": 39839,
      "e": 34870,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 39910,
      "e": 34941,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "if you look at the horizontal axis "
    },
    {
      "t": 43495,
      "e": 38526,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 43495,
      "e": 38526,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 43575,
      "e": 38606,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||a"
    },
    {
      "t": 43631,
      "e": 38662,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "78"
    },
    {
      "t": 43633,
      "e": 38664,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 43719,
      "e": 38750,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||n"
    },
    {
      "t": 43751,
      "e": 38782,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "68"
    },
    {
      "t": 43752,
      "e": 38783,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 43814,
      "e": 38845,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||d"
    },
    {
      "t": 43919,
      "e": 38950,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 43920,
      "e": 38951,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 43974,
      "e": 39005,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 45495,
      "e": 40526,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "71"
    },
    {
      "t": 45497,
      "e": 40528,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 45549,
      "e": 40580,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||g"
    },
    {
      "t": 45574,
      "e": 40605,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "79"
    },
    {
      "t": 45574,
      "e": 40605,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 45671,
      "e": 40702,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||o"
    },
    {
      "t": 45767,
      "e": 40798,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 45768,
      "e": 40799,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 45846,
      "e": 40877,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 46391,
      "e": 41422,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 46462,
      "e": 41493,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "if you look at the horizontal axis and go"
    },
    {
      "t": 46551,
      "e": 41582,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 46630,
      "e": 41661,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "if you look at the horizontal axis and g"
    },
    {
      "t": 46702,
      "e": 41733,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 46775,
      "e": 41806,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "if you look at the horizontal axis and "
    },
    {
      "t": 47319,
      "e": 42350,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "76"
    },
    {
      "t": 47320,
      "e": 42351,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 47398,
      "e": 42429,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||l"
    },
    {
      "t": 47551,
      "e": 42582,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "79"
    },
    {
      "t": 47552,
      "e": 42583,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 47573,
      "e": 42604,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||o"
    },
    {
      "t": 47687,
      "e": 42718,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "79"
    },
    {
      "t": 47687,
      "e": 42718,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 47806,
      "e": 42837,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "if you look at the horizontal axis and loo"
    },
    {
      "t": 47862,
      "e": 42893,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "75"
    },
    {
      "t": 47863,
      "e": 42894,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 47894,
      "e": 42925,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||ok"
    },
    {
      "t": 47942,
      "e": 42973,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 48110,
      "e": 43141,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 48112,
      "e": 43141,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 48214,
      "e": 43243,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 48278,
      "e": 43307,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 48278,
      "e": 43307,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 48399,
      "e": 43428,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 48399,
      "e": 43428,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 48414,
      "e": 43443,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||at"
    },
    {
      "t": 48462,
      "e": 43491,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 48478,
      "e": 43507,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 48479,
      "e": 43508,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 48551,
      "e": 43580,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 48599,
      "e": 43628,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 48599,
      "e": 43628,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 48694,
      "e": 43723,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 48726,
      "e": 43755,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "72"
    },
    {
      "t": 48726,
      "e": 43755,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 48839,
      "e": 43868,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||h"
    },
    {
      "t": 48886,
      "e": 43915,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 48888,
      "e": 43917,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 48982,
      "e": 44011,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||e"
    },
    {
      "t": 49063,
      "e": 44092,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 49063,
      "e": 44092,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 49150,
      "e": 44179,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 49622,
      "e": 44651,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "49"
    },
    {
      "t": 49622,
      "e": 44651,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 49726,
      "e": 44755,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "50"
    },
    {
      "t": 49727,
      "e": 44756,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 49775,
      "e": 44804,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||12"
    },
    {
      "t": 49871,
      "e": 44900,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 53566,
      "e": 48595,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "80"
    },
    {
      "t": 53567,
      "e": 48596,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 53718,
      "e": 48747,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "77"
    },
    {
      "t": 53719,
      "e": 48748,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 53742,
      "e": 48771,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||pm"
    },
    {
      "t": 53839,
      "e": 48868,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 54590,
      "e": 49619,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 54592,
      "e": 49621,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 54670,
      "e": 49699,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 54822,
      "e": 49851,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "77"
    },
    {
      "t": 54823,
      "e": 49852,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 54911,
      "e": 49940,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||m"
    },
    {
      "t": 54919,
      "e": 49948,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 54920,
      "e": 49949,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 55038,
      "e": 50067,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "82"
    },
    {
      "t": 55038,
      "e": 50067,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 55045,
      "e": 50074,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||ar"
    },
    {
      "t": 55102,
      "e": 50131,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 55207,
      "e": 50236,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "if you look at the horizontal axis and look at the 12pm mar"
    },
    {
      "t": 55207,
      "e": 50236,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "75"
    },
    {
      "t": 55208,
      "e": 50237,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 55318,
      "e": 50347,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||k"
    },
    {
      "t": 55439,
      "e": 50468,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 55440,
      "e": 50469,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 55534,
      "e": 50563,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 60003,
      "e": 55032,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 60773,
      "e": 55563,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "89"
    },
    {
      "t": 60773,
      "e": 55563,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 60837,
      "e": 55627,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||y"
    },
    {
      "t": 60885,
      "e": 55675,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "79"
    },
    {
      "t": 60885,
      "e": 55675,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 60941,
      "e": 55731,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "85"
    },
    {
      "t": 60941,
      "e": 55731,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 61006,
      "e": 55796,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||ou"
    },
    {
      "t": 61038,
      "e": 55828,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 61198,
      "e": 55988,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 61198,
      "e": 55988,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 61286,
      "e": 56076,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 61398,
      "e": 56188,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "67"
    },
    {
      "t": 61399,
      "e": 56189,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 61486,
      "e": 56276,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 61486,
      "e": 56276,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 61557,
      "e": 56347,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||ca"
    },
    {
      "t": 61622,
      "e": 56412,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 61623,
      "e": 56413,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "78"
    },
    {
      "t": 61623,
      "e": 56413,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 61718,
      "e": 56508,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||n"
    },
    {
      "t": 61863,
      "e": 56653,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 61864,
      "e": 56654,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 61918,
      "e": 56708,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 62022,
      "e": 56812,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "83"
    },
    {
      "t": 62022,
      "e": 56812,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 62119,
      "e": 56909,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||s"
    },
    {
      "t": 62270,
      "e": 57060,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 62271,
      "e": 57061,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 62334,
      "e": 57124,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||e"
    },
    {
      "t": 62438,
      "e": 57228,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 62438,
      "e": 57228,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 62494,
      "e": 57284,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||e"
    },
    {
      "t": 62583,
      "e": 57373,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 62583,
      "e": 57373,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 62686,
      "e": 57476,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 62815,
      "e": 57605,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "87"
    },
    {
      "t": 62816,
      "e": 57606,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 62926,
      "e": 57716,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||w"
    },
    {
      "t": 63030,
      "e": 57820,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "72"
    },
    {
      "t": 63031,
      "e": 57821,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 63198,
      "e": 57988,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||h"
    },
    {
      "t": 63206,
      "e": 57996,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "73"
    },
    {
      "t": 63206,
      "e": 57996,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 63382,
      "e": 58172,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||i"
    },
    {
      "t": 63422,
      "e": 58212,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "67"
    },
    {
      "t": 63423,
      "e": 58213,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 63502,
      "e": 58292,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||c"
    },
    {
      "t": 63582,
      "e": 58372,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "72"
    },
    {
      "t": 63582,
      "e": 58372,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 63671,
      "e": 58461,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||h"
    },
    {
      "t": 63783,
      "e": 58573,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 63784,
      "e": 58574,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 63910,
      "e": 58700,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 63974,
      "e": 58764,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "83"
    },
    {
      "t": 63975,
      "e": 58765,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 64078,
      "e": 58868,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||s"
    },
    {
      "t": 64119,
      "e": 58909,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "72"
    },
    {
      "t": 64119,
      "e": 58909,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 64254,
      "e": 59044,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "73"
    },
    {
      "t": 64254,
      "e": 59044,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 64286,
      "e": 59076,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||hi"
    },
    {
      "t": 64407,
      "e": 59197,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "if you look at the horizontal axis and look at the 12pm mark you can see which shi"
    },
    {
      "t": 64408,
      "e": 59198,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 64462,
      "e": 59252,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "70"
    },
    {
      "t": 64463,
      "e": 59253,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 64535,
      "e": 59325,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||f"
    },
    {
      "t": 64685,
      "e": 59475,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 64686,
      "e": 59476,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 64774,
      "e": 59564,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 64870,
      "e": 59660,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "83"
    },
    {
      "t": 64871,
      "e": 59661,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 64974,
      "e": 59764,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||s"
    },
    {
      "t": 64990,
      "e": 59780,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 64992,
      "e": 59782,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 65118,
      "e": 59908,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 65439,
      "e": 60229,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "83"
    },
    {
      "t": 65440,
      "e": 60230,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 65559,
      "e": 60349,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 65559,
      "e": 60349,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 65574,
      "e": 60364,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||st"
    },
    {
      "t": 65710,
      "e": 60500,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 65726,
      "e": 60516,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 65727,
      "e": 60517,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 65838,
      "e": 60628,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "82"
    },
    {
      "t": 65839,
      "e": 60629,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 65885,
      "e": 60675,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||ar"
    },
    {
      "t": 65933,
      "e": 60723,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 66047,
      "e": 60837,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 66047,
      "e": 60837,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 66207,
      "e": 60997,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "if you look at the horizontal axis and look at the 12pm mark you can see which shifts start"
    },
    {
      "t": 66207,
      "e": 60997,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "83"
    },
    {
      "t": 66208,
      "e": 60998,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 66229,
      "e": 61019,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||ts"
    },
    {
      "t": 66342,
      "e": 61132,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 66463,
      "e": 61253,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 66463,
      "e": 61253,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 66566,
      "e": 61356,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 66799,
      "e": 61589,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 66878,
      "e": 61590,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "if you look at the horizontal axis and look at the 12pm mark you can see which shifts starts"
    },
    {
      "t": 66974,
      "e": 61686,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 67038,
      "e": 61750,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "if you look at the horizontal axis and look at the 12pm mark you can see which shifts start"
    },
    {
      "t": 67415,
      "e": 62127,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 67416,
      "e": 62128,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 67533,
      "e": 62245,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 67639,
      "e": 62351,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 67639,
      "e": 62351,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 67806,
      "e": 62518,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "if you look at the horizontal axis and look at the 12pm mark you can see which shifts start a"
    },
    {
      "t": 67807,
      "e": 62519,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||a"
    },
    {
      "t": 67814,
      "e": 62526,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 67814,
      "e": 62526,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 67967,
      "e": 62679,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 67982,
      "e": 62694,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 67983,
      "e": 62695,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 68142,
      "e": 62854,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 68574,
      "e": 63286,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "49"
    },
    {
      "t": 68575,
      "e": 63287,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 68679,
      "e": 63391,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "50"
    },
    {
      "t": 68679,
      "e": 63391,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 68767,
      "e": 63479,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||12"
    },
    {
      "t": 68814,
      "e": 63526,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 69022,
      "e": 63734,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "79"
    },
    {
      "t": 69024,
      "e": 63736,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 69142,
      "e": 63854,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "77"
    },
    {
      "t": 69142,
      "e": 63854,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 69166,
      "e": 63878,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||om"
    },
    {
      "t": 69238,
      "e": 63950,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 69399,
      "e": 64111,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 69399,
      "e": 64111,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 69462,
      "e": 64174,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 69989,
      "e": 64701,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 70070,
      "e": 64782,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "if you look at the horizontal axis and look at the 12pm mark you can see which shifts start at 12om"
    },
    {
      "t": 70150,
      "e": 64862,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 70230,
      "e": 64942,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "if you look at the horizontal axis and look at the 12pm mark you can see which shifts start at 12o"
    },
    {
      "t": 70318,
      "e": 65030,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 70413,
      "e": 65125,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "if you look at the horizontal axis and look at the 12pm mark you can see which shifts start at 12"
    },
    {
      "t": 71167,
      "e": 65879,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "80"
    },
    {
      "t": 71167,
      "e": 65879,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 71270,
      "e": 65982,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "77"
    },
    {
      "t": 71272,
      "e": 65984,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 71301,
      "e": 66013,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||pm"
    },
    {
      "t": 71382,
      "e": 66094,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 71567,
      "e": 66279,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 71568,
      "e": 66280,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 71645,
      "e": 66357,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 76439,
      "e": 71151,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "66"
    },
    {
      "t": 76439,
      "e": 71151,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 76502,
      "e": 71214,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||b"
    },
    {
      "t": 76606,
      "e": 71215,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "if you look at the horizontal axis and look at the 12pm mark you can see which shifts start at 12pm b"
    },
    {
      "t": 76629,
      "e": 71238,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "89"
    },
    {
      "t": 76630,
      "e": 71239,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 76702,
      "e": 71311,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||y"
    },
    {
      "t": 76782,
      "e": 71391,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 76782,
      "e": 71391,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 76885,
      "e": 71494,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 77014,
      "e": 71623,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "83"
    },
    {
      "t": 77015,
      "e": 71624,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 77126,
      "e": 71735,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||s"
    },
    {
      "t": 77206,
      "e": 71815,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 77207,
      "e": 71816,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 77269,
      "e": 71878,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||e"
    },
    {
      "t": 77350,
      "e": 71959,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 77350,
      "e": 71959,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 77414,
      "e": 72023,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||e"
    },
    {
      "t": 77486,
      "e": 72095,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "73"
    },
    {
      "t": 77487,
      "e": 72096,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 77574,
      "e": 72183,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "78"
    },
    {
      "t": 77575,
      "e": 72184,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 77614,
      "e": 72223,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||in"
    },
    {
      "t": 77654,
      "e": 72263,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "71"
    },
    {
      "t": 77655,
      "e": 72264,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 77695,
      "e": 72304,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||g"
    },
    {
      "t": 77743,
      "e": 72352,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 77838,
      "e": 72447,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 77839,
      "e": 72448,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 77926,
      "e": 72535,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 77998,
      "e": 72607,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "87"
    },
    {
      "t": 77998,
      "e": 72607,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 78079,
      "e": 72688,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||w"
    },
    {
      "t": 78215,
      "e": 72824,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "72"
    },
    {
      "t": 78215,
      "e": 72824,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 78294,
      "e": 72903,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||h"
    },
    {
      "t": 78334,
      "e": 72943,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "73"
    },
    {
      "t": 78334,
      "e": 72943,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 78414,
      "e": 73023,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||i"
    },
    {
      "t": 78558,
      "e": 73167,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "67"
    },
    {
      "t": 78559,
      "e": 73168,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 78645,
      "e": 73254,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||c"
    },
    {
      "t": 78678,
      "e": 73287,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "72"
    },
    {
      "t": 78678,
      "e": 73287,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 78807,
      "e": 73416,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "if you look at the horizontal axis and look at the 12pm mark you can see which shifts start at 12pm by seeing which"
    },
    {
      "t": 78808,
      "e": 73417,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 78808,
      "e": 73417,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 78838,
      "e": 73447,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||h "
    },
    {
      "t": 78919,
      "e": 73528,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 79134,
      "e": 73743,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "68"
    },
    {
      "t": 79135,
      "e": 73744,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 79198,
      "e": 73807,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||d"
    },
    {
      "t": 79798,
      "e": 74407,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "79"
    },
    {
      "t": 79798,
      "e": 74407,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 79853,
      "e": 74462,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||o"
    },
    {
      "t": 80055,
      "e": 74664,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 80055,
      "e": 74664,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 80125,
      "e": 74734,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 80614,
      "e": 75223,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 80687,
      "e": 75296,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "if you look at the horizontal axis and look at the 12pm mark you can see which shifts start at 12pm by seeing which do"
    },
    {
      "t": 80791,
      "e": 75400,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 80821,
      "e": 75430,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "if you look at the horizontal axis and look at the 12pm mark you can see which shifts start at 12pm by seeing which d"
    },
    {
      "t": 80838,
      "e": 75447,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 80838,
      "e": 75447,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 80974,
      "e": 75583,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 81063,
      "e": 75672,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 81063,
      "e": 75672,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 81190,
      "e": 75799,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 81473,
      "e": 76082,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 81538,
      "e": 76083,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "if you look at the horizontal axis and look at the 12pm mark you can see which shifts start at 12pm by seeing which dt"
    },
    {
      "t": 81633,
      "e": 76178,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 81762,
      "e": 76307,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "if you look at the horizontal axis and look at the 12pm mark you can see which shifts start at 12pm by seeing which d"
    },
    {
      "t": 82722,
      "e": 77267,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "79"
    },
    {
      "t": 82722,
      "e": 77267,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 82801,
      "e": 77346,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 82801,
      "e": 77346,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 82825,
      "e": 77370,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||ot"
    },
    {
      "t": 82889,
      "e": 77434,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 83138,
      "e": 77683,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 83139,
      "e": 77684,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 83257,
      "e": 77802,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 89601,
      "e": 82802,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "77"
    },
    {
      "t": 89603,
      "e": 82804,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 89681,
      "e": 82882,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||m"
    },
    {
      "t": 89761,
      "e": 82962,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 89761,
      "e": 82962,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 89857,
      "e": 83058,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||a"
    },
    {
      "t": 90007,
      "e": 83208,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 90010,
      "e": 83211,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 90010,
      "e": 83211,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 90041,
      "e": 83242,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 90210,
      "e": 83411,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "if you look at the horizontal axis and look at the 12pm mark you can see which shifts start at 12pm by seeing which dot mat"
    },
    {
      "t": 90258,
      "e": 83459,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "67"
    },
    {
      "t": 90258,
      "e": 83459,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 90329,
      "e": 83530,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||c"
    },
    {
      "t": 90426,
      "e": 83627,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "72"
    },
    {
      "t": 90426,
      "e": 83627,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 90506,
      "e": 83707,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||h"
    },
    {
      "t": 90577,
      "e": 83778,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 90579,
      "e": 83780,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 90681,
      "e": 83882,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||e"
    },
    {
      "t": 90689,
      "e": 83890,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "83"
    },
    {
      "t": 90689,
      "e": 83890,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 90769,
      "e": 83970,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||s"
    },
    {
      "t": 90881,
      "e": 84082,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 90882,
      "e": 84083,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 90961,
      "e": 84162,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 91202,
      "e": 84403,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "85"
    },
    {
      "t": 91202,
      "e": 84403,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 91273,
      "e": 84474,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||u"
    },
    {
      "t": 91425,
      "e": 84626,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "80"
    },
    {
      "t": 91426,
      "e": 84627,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 91490,
      "e": 84691,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||p"
    },
    {
      "t": 91610,
      "e": 84811,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "if you look at the horizontal axis and look at the 12pm mark you can see which shifts start at 12pm by seeing which dot matches up"
    },
    {
      "t": 92274,
      "e": 85475,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 92275,
      "e": 85476,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 92321,
      "e": 85522,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 92754,
      "e": 85955,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 92757,
      "e": 85958,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 92857,
      "e": 86058,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "72"
    },
    {
      "t": 92857,
      "e": 86058,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 92881,
      "e": 86082,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||th"
    },
    {
      "t": 92977,
      "e": 86178,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 93258,
      "e": 86459,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 93345,
      "e": 86546,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "if you look at the horizontal axis and look at the 12pm mark you can see which shifts start at 12pm by seeing which dot matches up t"
    },
    {
      "t": 94001,
      "e": 87202,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "79"
    },
    {
      "t": 94002,
      "e": 87203,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 94081,
      "e": 87282,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||o"
    },
    {
      "t": 94233,
      "e": 87434,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 94234,
      "e": 87435,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 94321,
      "e": 87522,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 94336,
      "e": 87537,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 94337,
      "e": 87538,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 94433,
      "e": 87634,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "72"
    },
    {
      "t": 94434,
      "e": 87635,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 94473,
      "e": 87674,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||th"
    },
    {
      "t": 94546,
      "e": 87747,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 94547,
      "e": 87748,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 94617,
      "e": 87818,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||a"
    },
    {
      "t": 94714,
      "e": 87915,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 94714,
      "e": 87915,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 94753,
      "e": 87954,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 94825,
      "e": 88026,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 94857,
      "e": 88058,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 94857,
      "e": 88058,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 94945,
      "e": 88146,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 95105,
      "e": 88306,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "76"
    },
    {
      "t": 95106,
      "e": 88307,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 95209,
      "e": 88410,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "if you look at the horizontal axis and look at the 12pm mark you can see which shifts start at 12pm by seeing which dot matches up to that l"
    },
    {
      "t": 95257,
      "e": 88458,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "73"
    },
    {
      "t": 95258,
      "e": 88459,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 95273,
      "e": 88459,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||li"
    },
    {
      "t": 95402,
      "e": 88588,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "78"
    },
    {
      "t": 95402,
      "e": 88588,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 95449,
      "e": 88635,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||n"
    },
    {
      "t": 95512,
      "e": 88698,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 96241,
      "e": 89427,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 96329,
      "e": 89515,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "if you look at the horizontal axis and look at the 12pm mark you can see which shifts start at 12pm by seeing which dot matches up to that li"
    },
    {
      "t": 96417,
      "e": 89603,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 96528,
      "e": 89714,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "if you look at the horizontal axis and look at the 12pm mark you can see which shifts start at 12pm by seeing which dot matches up to that l"
    },
    {
      "t": 96953,
      "e": 90139,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 97057,
      "e": 90243,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "if you look at the horizontal axis and look at the 12pm mark you can see which shifts start at 12pm by seeing which dot matches up to that "
    },
    {
      "t": 97265,
      "e": 90451,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "77"
    },
    {
      "t": 97266,
      "e": 90452,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 97393,
      "e": 90579,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||m"
    },
    {
      "t": 97401,
      "e": 90587,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 97402,
      "e": 90588,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 97586,
      "e": 90772,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||a"
    },
    {
      "t": 97602,
      "e": 90788,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "82"
    },
    {
      "t": 97602,
      "e": 90788,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 97722,
      "e": 90908,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||r"
    },
    {
      "t": 97778,
      "e": 90964,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "75"
    },
    {
      "t": 97780,
      "e": 90966,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 97994,
      "e": 91180,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||k"
    },
    {
      "t": 98002,
      "e": 91188,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 98002,
      "e": 91188,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 98113,
      "e": 91299,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 102866,
      "e": 96052,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "86"
    },
    {
      "t": 102867,
      "e": 96053,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 102993,
      "e": 96179,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 102993,
      "e": 96179,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 103041,
      "e": 96227,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||ve"
    },
    {
      "t": 103081,
      "e": 96267,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "82"
    },
    {
      "t": 103082,
      "e": 96268,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 103146,
      "e": 96332,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||r"
    },
    {
      "t": 103177,
      "e": 96363,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 103322,
      "e": 96508,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 103323,
      "e": 96509,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 103392,
      "e": 96578,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 103522,
      "e": 96708,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "73"
    },
    {
      "t": 103523,
      "e": 96709,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 103609,
      "e": 96795,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||i"
    },
    {
      "t": 103689,
      "e": 96875,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "67"
    },
    {
      "t": 103689,
      "e": 96875,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 103810,
      "e": 96996,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "if you look at the horizontal axis and look at the 12pm mark you can see which shifts start at 12pm by seeing which dot matches up to that mark vertic"
    },
    {
      "t": 103817,
      "e": 97003,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 103818,
      "e": 97004,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 103865,
      "e": 97051,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||ca"
    },
    {
      "t": 103953,
      "e": 97139,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 103980,
      "e": 97166,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "76"
    },
    {
      "t": 103980,
      "e": 97166,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 104048,
      "e": 97234,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||l"
    },
    {
      "t": 104153,
      "e": 97339,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "76"
    },
    {
      "t": 104154,
      "e": 97340,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 104266,
      "e": 97452,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "89"
    },
    {
      "t": 104267,
      "e": 97453,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 104273,
      "e": 97459,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||ly"
    },
    {
      "t": 104401,
      "e": 97587,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 107620,
      "e": 97590,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "190"
    },
    {
      "t": 107622,
      "e": 97592,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 107744,
      "e": 97714,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||."
    },
    {
      "t": 108146,
      "e": 98116,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "13"
    },
    {
      "t": 108147,
      "e": 98117,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 108249,
      "e": 98219,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||\n"
    },
    {
      "t": 110006,
      "e": 99976,
      "ty": 7,
      "x": 511,
      "y": 566,
      "ta": "#strategyAnswer"
    },
    {
      "t": 110008,
      "e": 99978,
      "ty": 2,
      "x": 511,
      "y": 566
    },
    {
      "t": 110009,
      "e": 99979,
      "ty": 41,
      "x": 46527,
      "y": 64294,
      "ta": "> div.stimulus > div > div:[2]"
    },
    {
      "t": 110021,
      "e": 99991,
      "ty": 6,
      "x": 371,
      "y": 627,
      "ta": "#strategyButton"
    },
    {
      "t": 110038,
      "e": 100008,
      "ty": 7,
      "x": 318,
      "y": 650,
      "ta": "#strategyButton"
    },
    {
      "t": 110107,
      "e": 100077,
      "ty": 2,
      "x": 279,
      "y": 667
    },
    {
      "t": 110258,
      "e": 100228,
      "ty": 41,
      "x": 20448,
      "y": 40099,
      "ta": "> div.stimulus > div"
    },
    {
      "t": 110307,
      "e": 100277,
      "ty": 2,
      "x": 330,
      "y": 656
    },
    {
      "t": 110407,
      "e": 100377,
      "ty": 2,
      "x": 392,
      "y": 645
    },
    {
      "t": 110508,
      "e": 100478,
      "ty": 2,
      "x": 408,
      "y": 637
    },
    {
      "t": 110508,
      "e": 100478,
      "ty": 41,
      "x": 41851,
      "y": 44737,
      "ta": "> div.stimulus > div > div:[3]"
    },
    {
      "t": 110556,
      "e": 100526,
      "ty": 6,
      "x": 410,
      "y": 635,
      "ta": "#strategyButton"
    },
    {
      "t": 110608,
      "e": 100578,
      "ty": 2,
      "x": 411,
      "y": 634
    },
    {
      "t": 110637,
      "e": 100607,
      "ty": 3,
      "x": 411,
      "y": 634,
      "ta": "#strategyButton"
    },
    {
      "t": 110638,
      "e": 100608,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "if you look at the horizontal axis and look at the 12pm mark you can see which shifts start at 12pm by seeing which dot matches up to that mark vertically.\n"
    },
    {
      "t": 110638,
      "e": 100608,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 110638,
      "e": 100608,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#strategyButton"
    },
    {
      "t": 110717,
      "e": 100687,
      "ty": 4,
      "x": 39542,
      "y": 62191,
      "ta": "#strategyButton"
    },
    {
      "t": 110732,
      "e": 100702,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#strategyButton"
    },
    {
      "t": 110734,
      "e": 100704,
      "ty": 5,
      "x": 411,
      "y": 634,
      "ta": "#strategyButton"
    },
    {
      "t": 110743,
      "e": 100713,
      "ty": 38,
      "x": 3,
      "y": 0
    },
    {
      "t": 110757,
      "e": 100727,
      "ty": 41,
      "x": 13878,
      "y": 38091,
      "ta": "html > body"
    },
    {
      "t": 111107,
      "e": 101077,
      "ty": 2,
      "x": 682,
      "y": 782
    },
    {
      "t": 111208,
      "e": 101178,
      "ty": 2,
      "x": 1158,
      "y": 922
    },
    {
      "t": 111257,
      "e": 101227,
      "ty": 41,
      "x": 39637,
      "y": 55677,
      "ta": "html > body"
    },
    {
      "t": 111308,
      "e": 101278,
      "ty": 2,
      "x": 1142,
      "y": 916
    },
    {
      "t": 111407,
      "e": 101377,
      "ty": 2,
      "x": 1141,
      "y": 915
    },
    {
      "t": 111508,
      "e": 101478,
      "ty": 41,
      "x": 39017,
      "y": 55190,
      "ta": "html > body"
    },
    {
      "t": 111741,
      "e": 101711,
      "ty": 38,
      "x": 4,
      "y": 0
    },
    {
      "t": 112616,
      "e": 102586,
      "ty": 2,
      "x": 1086,
      "y": 622
    },
    {
      "t": 112657,
      "e": 102627,
      "ty": 6,
      "x": 1057,
      "y": 501,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 112673,
      "e": 102643,
      "ty": 7,
      "x": 1047,
      "y": 481,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 112707,
      "e": 102677,
      "ty": 2,
      "x": 1036,
      "y": 465
    },
    {
      "t": 112758,
      "e": 102728,
      "ty": 41,
      "x": 48664,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > p"
    },
    {
      "t": 112807,
      "e": 102777,
      "ty": 2,
      "x": 1032,
      "y": 454
    },
    {
      "t": 112907,
      "e": 102877,
      "ty": 2,
      "x": 1012,
      "y": 499
    },
    {
      "t": 112924,
      "e": 102894,
      "ty": 6,
      "x": 1007,
      "y": 505,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 113007,
      "e": 102977,
      "ty": 2,
      "x": 1002,
      "y": 513
    },
    {
      "t": 113008,
      "e": 102978,
      "ty": 41,
      "x": 41959,
      "y": 37448,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 113255,
      "e": 103225,
      "ty": 3,
      "x": 1002,
      "y": 513,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 113255,
      "e": 103225,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 113364,
      "e": 103334,
      "ty": 4,
      "x": 41959,
      "y": 37448,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 113364,
      "e": 103334,
      "ty": 5,
      "x": 1002,
      "y": 513,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 114617,
      "e": 104587,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "98"
    },
    {
      "t": 114617,
      "e": 104587,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 114705,
      "e": 104675,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "96"
    },
    {
      "t": 114706,
      "e": 104676,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 114753,
      "e": 104723,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "20"
    },
    {
      "t": 114857,
      "e": 104827,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "20"
    },
    {
      "t": 115727,
      "e": 105697,
      "ty": 7,
      "x": 1006,
      "y": 537,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 115757,
      "e": 105727,
      "ty": 41,
      "x": 44122,
      "y": 28086,
      "ta": "#jspsych-survey-text-1 > p"
    },
    {
      "t": 115807,
      "e": 105777,
      "ty": 2,
      "x": 1018,
      "y": 587
    },
    {
      "t": 115860,
      "e": 105830,
      "ty": 6,
      "x": 1021,
      "y": 594,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 115907,
      "e": 105877,
      "ty": 2,
      "x": 1024,
      "y": 603
    },
    {
      "t": 116008,
      "e": 105978,
      "ty": 2,
      "x": 1024,
      "y": 604
    },
    {
      "t": 116008,
      "e": 105978,
      "ty": 41,
      "x": 46718,
      "y": 31207,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 116102,
      "e": 106072,
      "ty": 3,
      "x": 1024,
      "y": 604,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 116103,
      "e": 106073,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "20"
    },
    {
      "t": 116104,
      "e": 106074,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 116104,
      "e": 106074,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 116197,
      "e": 106167,
      "ty": 4,
      "x": 46718,
      "y": 31207,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 116197,
      "e": 106167,
      "ty": 5,
      "x": 1024,
      "y": 604,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 117633,
      "e": 107603,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "16"
    },
    {
      "t": 117786,
      "e": 107756,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "85"
    },
    {
      "t": 117786,
      "e": 107756,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 117905,
      "e": 107875,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "U"
    },
    {
      "t": 118129,
      "e": 108099,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "83"
    },
    {
      "t": 118130,
      "e": 108100,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 118209,
      "e": 108179,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "US"
    },
    {
      "t": 118378,
      "e": 108348,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "65"
    },
    {
      "t": 118378,
      "e": 108348,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 118481,
      "e": 108451,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "USA"
    },
    {
      "t": 118521,
      "e": 108491,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "USA"
    },
    {
      "t": 119797,
      "e": 109767,
      "ty": 7,
      "x": 1014,
      "y": 616,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 119808,
      "e": 109778,
      "ty": 2,
      "x": 1014,
      "y": 616
    },
    {
      "t": 119829,
      "e": 109799,
      "ty": 6,
      "x": 1004,
      "y": 624,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 119908,
      "e": 109878,
      "ty": 2,
      "x": 1001,
      "y": 631
    },
    {
      "t": 120008,
      "e": 109978,
      "ty": 2,
      "x": 995,
      "y": 643
    },
    {
      "t": 120008,
      "e": 109978,
      "ty": 41,
      "x": 51063,
      "y": 39718,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 120008,
      "e": 109978,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 120037,
      "e": 110007,
      "ty": 3,
      "x": 995,
      "y": 643,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 120038,
      "e": 110008,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "USA"
    },
    {
      "t": 120038,
      "e": 110008,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 120039,
      "e": 110009,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 120141,
      "e": 110111,
      "ty": 4,
      "x": 51063,
      "y": 39718,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 120141,
      "e": 110111,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 120141,
      "e": 110111,
      "ty": 5,
      "x": 995,
      "y": 643,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 120142,
      "e": 110112,
      "ty": 38,
      "x": 5,
      "y": 0
    },
    {
      "t": 120208,
      "e": 110178,
      "ty": 2,
      "x": 994,
      "y": 643
    },
    {
      "t": 120258,
      "e": 110228,
      "ty": 41,
      "x": 33955,
      "y": 38639,
      "ta": "html > body"
    },
    {
      "t": 121153,
      "e": 111123,
      "ty": 38,
      "x": 6,
      "y": 0
    },
    {
      "t": 122208,
      "e": 112178,
      "ty": 2,
      "x": 972,
      "y": 598
    },
    {
      "t": 122258,
      "e": 112228,
      "ty": 41,
      "x": 35498,
      "y": 58513,
      "ta": "#jspsych-survey-multi-choice-2 > p"
    },
    {
      "t": 122308,
      "e": 112278,
      "ty": 2,
      "x": 971,
      "y": 587
    },
    {
      "t": 122759,
      "e": 112729,
      "ty": 41,
      "x": 35498,
      "y": 49151,
      "ta": "#jspsych-survey-multi-choice-2 > p"
    },
    {
      "t": 122808,
      "e": 112778,
      "ty": 2,
      "x": 963,
      "y": 559
    },
    {
      "t": 122908,
      "e": 112878,
      "ty": 2,
      "x": 964,
      "y": 508
    },
    {
      "t": 123008,
      "e": 112978,
      "ty": 2,
      "x": 960,
      "y": 374
    },
    {
      "t": 123008,
      "e": 112978,
      "ty": 41,
      "x": 32888,
      "y": 60853,
      "ta": "#jspsych-survey-multi-choice-option-1-0"
    },
    {
      "t": 123108,
      "e": 113078,
      "ty": 2,
      "x": 915,
      "y": 244
    },
    {
      "t": 123208,
      "e": 113178,
      "ty": 2,
      "x": 857,
      "y": 179
    },
    {
      "t": 123258,
      "e": 113228,
      "ty": 41,
      "x": 29133,
      "y": 9830,
      "ta": "#jspsych-survey-multi-choice-option-0-0 > label"
    },
    {
      "t": 123308,
      "e": 113278,
      "ty": 2,
      "x": 852,
      "y": 179
    },
    {
      "t": 123382,
      "e": 113352,
      "ty": 6,
      "x": 839,
      "y": 191,
      "ta": "jspsych-survey-multi-choice-response-0[0]_mf"
    },
    {
      "t": 123408,
      "e": 113378,
      "ty": 2,
      "x": 839,
      "y": 191
    },
    {
      "t": 123508,
      "e": 113478,
      "ty": 41,
      "x": 63408,
      "y": 60493,
      "ta": "jspsych-survey-multi-choice-response-0[0]_mf"
    },
    {
      "t": 123590,
      "e": 113560,
      "ty": 7,
      "x": 840,
      "y": 191,
      "ta": "jspsych-survey-multi-choice-response-0[0]_mf"
    },
    {
      "t": 123608,
      "e": 113578,
      "ty": 2,
      "x": 840,
      "y": 191
    },
    {
      "t": 123662,
      "e": 113632,
      "ty": 3,
      "x": 840,
      "y": 191,
      "ta": "#jspsych-survey-multi-choice-option-0-0 > label"
    },
    {
      "t": 123759,
      "e": 113729,
      "ty": 41,
      "x": 15213,
      "y": 49151,
      "ta": "#jspsych-survey-multi-choice-option-0-0 > label"
    },
    {
      "t": 123766,
      "e": 113736,
      "ty": 4,
      "x": 15213,
      "y": 49151,
      "ta": "#jspsych-survey-multi-choice-option-0-0 > label"
    },
    {
      "t": 123766,
      "e": 113736,
      "ty": 5,
      "x": 840,
      "y": 191,
      "ta": "#jspsych-survey-multi-choice-option-0-0 > label"
    },
    {
      "t": 123766,
      "e": 113736,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-0[0]_mf"
    },
    {
      "t": 123768,
      "e": 113738,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-0[0]_mf",
      "v": "English"
    },
    {
      "t": 124030,
      "e": 114000,
      "ty": 6,
      "x": 839,
      "y": 191,
      "ta": "jspsych-survey-multi-choice-response-0[0]_mf"
    },
    {
      "t": 124045,
      "e": 114015,
      "ty": 7,
      "x": 838,
      "y": 193,
      "ta": "jspsych-survey-multi-choice-response-0[0]_mf"
    },
    {
      "t": 124099,
      "e": 114069,
      "ty": 6,
      "x": 838,
      "y": 212,
      "ta": "jspsych-survey-multi-choice-response-0[1]_mf"
    },
    {
      "t": 124107,
      "e": 114077,
      "ty": 2,
      "x": 838,
      "y": 212
    },
    {
      "t": 124116,
      "e": 114086,
      "ty": 7,
      "x": 838,
      "y": 224,
      "ta": "jspsych-survey-multi-choice-response-0[1]_mf"
    },
    {
      "t": 124208,
      "e": 114178,
      "ty": 2,
      "x": 843,
      "y": 265
    },
    {
      "t": 124258,
      "e": 114228,
      "ty": 41,
      "x": 4171,
      "y": 13151,
      "ta": "#jspsych-survey-multi-choice-form"
    },
    {
      "t": 124308,
      "e": 114278,
      "ty": 2,
      "x": 836,
      "y": 296
    },
    {
      "t": 124408,
      "e": 114378,
      "ty": 2,
      "x": 836,
      "y": 320
    },
    {
      "t": 124508,
      "e": 114478,
      "ty": 2,
      "x": 836,
      "y": 324
    },
    {
      "t": 124508,
      "e": 114478,
      "ty": 41,
      "x": 3459,
      "y": 51491,
      "ta": "#jspsych-survey-multi-choice-1 > p"
    },
    {
      "t": 125707,
      "e": 115677,
      "ty": 2,
      "x": 871,
      "y": 329
    },
    {
      "t": 125757,
      "e": 115727,
      "ty": 41,
      "x": 12003,
      "y": 7582,
      "ta": "#jspsych-survey-multi-choice-1"
    },
    {
      "t": 125807,
      "e": 115777,
      "ty": 2,
      "x": 875,
      "y": 330
    },
    {
      "t": 125907,
      "e": 115877,
      "ty": 2,
      "x": 916,
      "y": 337
    },
    {
      "t": 126007,
      "e": 115977,
      "ty": 2,
      "x": 1044,
      "y": 347
    },
    {
      "t": 126008,
      "e": 115978,
      "ty": 41,
      "x": 52823,
      "y": 12186,
      "ta": "#jspsych-survey-multi-choice-1"
    },
    {
      "t": 126107,
      "e": 116077,
      "ty": 2,
      "x": 1055,
      "y": 347
    },
    {
      "t": 126257,
      "e": 116227,
      "ty": 41,
      "x": 55433,
      "y": 12186,
      "ta": "#jspsych-survey-multi-choice-1"
    },
    {
      "t": 126307,
      "e": 116277,
      "ty": 2,
      "x": 1052,
      "y": 347
    },
    {
      "t": 126407,
      "e": 116377,
      "ty": 2,
      "x": 1048,
      "y": 349
    },
    {
      "t": 126507,
      "e": 116477,
      "ty": 2,
      "x": 1043,
      "y": 352
    },
    {
      "t": 126508,
      "e": 116478,
      "ty": 41,
      "x": 52585,
      "y": 9362,
      "ta": "#jspsych-survey-multi-choice-option-1-0"
    },
    {
      "t": 126608,
      "e": 116578,
      "ty": 2,
      "x": 1033,
      "y": 356
    },
    {
      "t": 126707,
      "e": 116677,
      "ty": 2,
      "x": 1016,
      "y": 370
    },
    {
      "t": 126757,
      "e": 116727,
      "ty": 41,
      "x": 43804,
      "y": 63194,
      "ta": "#jspsych-survey-multi-choice-option-1-0"
    },
    {
      "t": 126807,
      "e": 116777,
      "ty": 2,
      "x": 995,
      "y": 380
    },
    {
      "t": 126907,
      "e": 116877,
      "ty": 2,
      "x": 939,
      "y": 387
    },
    {
      "t": 127007,
      "e": 116977,
      "ty": 2,
      "x": 881,
      "y": 392
    },
    {
      "t": 127007,
      "e": 116977,
      "ty": 41,
      "x": 47588,
      "y": 39321,
      "ta": "#jspsych-survey-multi-choice-option-1-1 > label"
    },
    {
      "t": 127107,
      "e": 117077,
      "ty": 2,
      "x": 856,
      "y": 397
    },
    {
      "t": 127207,
      "e": 117177,
      "ty": 2,
      "x": 841,
      "y": 405
    },
    {
      "t": 127258,
      "e": 117178,
      "ty": 41,
      "x": 17523,
      "y": 6553,
      "ta": "#jspsych-survey-multi-choice-option-1-2 > label"
    },
    {
      "t": 127268,
      "e": 117188,
      "ty": 6,
      "x": 837,
      "y": 411,
      "ta": "jspsych-survey-multi-choice-response-1[2]_mf"
    },
    {
      "t": 127307,
      "e": 117227,
      "ty": 2,
      "x": 835,
      "y": 414
    },
    {
      "t": 127407,
      "e": 117327,
      "ty": 2,
      "x": 833,
      "y": 417
    },
    {
      "t": 127507,
      "e": 117427,
      "ty": 2,
      "x": 831,
      "y": 422
    },
    {
      "t": 127508,
      "e": 117428,
      "ty": 41,
      "x": 23079,
      "y": 55452,
      "ta": "jspsych-survey-multi-choice-response-1[2]_mf"
    },
    {
      "t": 127907,
      "e": 117827,
      "ty": 2,
      "x": 832,
      "y": 422
    },
    {
      "t": 128008,
      "e": 117928,
      "ty": 41,
      "x": 28120,
      "y": 55452,
      "ta": "jspsych-survey-multi-choice-response-1[2]_mf"
    },
    {
      "t": 128507,
      "e": 118427,
      "ty": 2,
      "x": 835,
      "y": 418
    },
    {
      "t": 128507,
      "e": 118427,
      "ty": 41,
      "x": 43243,
      "y": 35288,
      "ta": "jspsych-survey-multi-choice-response-1[2]_mf"
    },
    {
      "t": 128607,
      "e": 118527,
      "ty": 2,
      "x": 835,
      "y": 417
    },
    {
      "t": 128758,
      "e": 118678,
      "ty": 41,
      "x": 43243,
      "y": 30246,
      "ta": "jspsych-survey-multi-choice-response-1[2]_mf"
    },
    {
      "t": 131286,
      "e": 121206,
      "ty": 3,
      "x": 835,
      "y": 417,
      "ta": "jspsych-survey-multi-choice-response-1[2]_mf"
    },
    {
      "t": 131287,
      "e": 121207,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-0[0]_mf"
    },
    {
      "t": 131287,
      "e": 121207,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-1[2]_mf"
    },
    {
      "t": 131428,
      "e": 121348,
      "ty": 4,
      "x": 43243,
      "y": 30246,
      "ta": "jspsych-survey-multi-choice-response-1[2]_mf"
    },
    {
      "t": 131429,
      "e": 121349,
      "ty": 5,
      "x": 835,
      "y": 417,
      "ta": "jspsych-survey-multi-choice-response-1[2]_mf"
    },
    {
      "t": 131429,
      "e": 121349,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-1[2]_mf",
      "v": "Third"
    },
    {
      "t": 131677,
      "e": 121597,
      "ty": 7,
      "x": 840,
      "y": 432,
      "ta": "jspsych-survey-multi-choice-response-1[2]_mf"
    },
    {
      "t": 131707,
      "e": 121627,
      "ty": 2,
      "x": 853,
      "y": 470
    },
    {
      "t": 131757,
      "e": 121677,
      "ty": 41,
      "x": 7494,
      "y": 7021,
      "ta": "#jspsych-survey-multi-choice-option-1-5"
    },
    {
      "t": 131807,
      "e": 121727,
      "ty": 2,
      "x": 853,
      "y": 491
    },
    {
      "t": 132708,
      "e": 122628,
      "ty": 2,
      "x": 853,
      "y": 498
    },
    {
      "t": 132758,
      "e": 122678,
      "ty": 41,
      "x": 21546,
      "y": 36044,
      "ta": "#jspsych-survey-multi-choice-option-1-5 > label"
    },
    {
      "t": 132807,
      "e": 122727,
      "ty": 2,
      "x": 853,
      "y": 506
    },
    {
      "t": 132907,
      "e": 122827,
      "ty": 2,
      "x": 855,
      "y": 514
    },
    {
      "t": 133008,
      "e": 122928,
      "ty": 2,
      "x": 855,
      "y": 534
    },
    {
      "t": 133008,
      "e": 122928,
      "ty": 41,
      "x": 33333,
      "y": 45874,
      "ta": "#jspsych-survey-multi-choice-option-1-6 > label"
    },
    {
      "t": 133107,
      "e": 123027,
      "ty": 2,
      "x": 858,
      "y": 581
    },
    {
      "t": 133207,
      "e": 123127,
      "ty": 2,
      "x": 863,
      "y": 610
    },
    {
      "t": 133257,
      "e": 123177,
      "ty": 41,
      "x": 11163,
      "y": 42597,
      "ta": "#jspsych-survey-multi-choice-option-2-0 > label"
    },
    {
      "t": 133307,
      "e": 123227,
      "ty": 2,
      "x": 863,
      "y": 639
    },
    {
      "t": 133407,
      "e": 123327,
      "ty": 2,
      "x": 863,
      "y": 653
    },
    {
      "t": 133507,
      "e": 123427,
      "ty": 2,
      "x": 863,
      "y": 666
    },
    {
      "t": 133508,
      "e": 123428,
      "ty": 41,
      "x": 9867,
      "y": 4681,
      "ta": "#jspsych-survey-multi-choice-option-2-2"
    },
    {
      "t": 133609,
      "e": 123529,
      "ty": 2,
      "x": 858,
      "y": 697
    },
    {
      "t": 133707,
      "e": 123627,
      "ty": 2,
      "x": 851,
      "y": 713
    },
    {
      "t": 133757,
      "e": 123677,
      "ty": 41,
      "x": 9003,
      "y": 62258,
      "ta": "#jspsych-survey-multi-choice-option-2-3 > label"
    },
    {
      "t": 133807,
      "e": 123727,
      "ty": 2,
      "x": 837,
      "y": 717
    },
    {
      "t": 133907,
      "e": 123827,
      "ty": 2,
      "x": 828,
      "y": 725
    },
    {
      "t": 134007,
      "e": 123927,
      "ty": 2,
      "x": 828,
      "y": 726
    },
    {
      "t": 134008,
      "e": 123928,
      "ty": 41,
      "x": 3682,
      "y": 6553,
      "ta": "#jspsych-survey-multi-choice-option-2-4 > label"
    },
    {
      "t": 134248,
      "e": 123930,
      "ty": 6,
      "x": 828,
      "y": 728,
      "ta": "jspsych-survey-multi-choice-response-2[4]_mf"
    },
    {
      "t": 134257,
      "e": 123939,
      "ty": 41,
      "x": 7955,
      "y": 5041,
      "ta": "jspsych-survey-multi-choice-response-2[4]_mf"
    },
    {
      "t": 134308,
      "e": 123990,
      "ty": 2,
      "x": 828,
      "y": 731
    },
    {
      "t": 134381,
      "e": 124063,
      "ty": 3,
      "x": 829,
      "y": 733,
      "ta": "jspsych-survey-multi-choice-response-2[4]_mf"
    },
    {
      "t": 134381,
      "e": 124063,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-1[2]_mf"
    },
    {
      "t": 134381,
      "e": 124063,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-2[4]_mf"
    },
    {
      "t": 134407,
      "e": 124089,
      "ty": 2,
      "x": 829,
      "y": 733
    },
    {
      "t": 134501,
      "e": 124183,
      "ty": 4,
      "x": 12996,
      "y": 30246,
      "ta": "jspsych-survey-multi-choice-response-2[4]_mf"
    },
    {
      "t": 134501,
      "e": 124183,
      "ty": 5,
      "x": 829,
      "y": 733,
      "ta": "jspsych-survey-multi-choice-response-2[4]_mf"
    },
    {
      "t": 134502,
      "e": 124184,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-2[4]_mf",
      "v": "Engineering"
    },
    {
      "t": 134508,
      "e": 124190,
      "ty": 41,
      "x": 12996,
      "y": 30246,
      "ta": "jspsych-survey-multi-choice-response-2[4]_mf"
    },
    {
      "t": 134740,
      "e": 124422,
      "ty": 7,
      "x": 835,
      "y": 750,
      "ta": "jspsych-survey-multi-choice-response-2[4]_mf"
    },
    {
      "t": 134757,
      "e": 124439,
      "ty": 41,
      "x": 3222,
      "y": 4681,
      "ta": "#jspsych-survey-multi-choice-option-2-5"
    },
    {
      "t": 134807,
      "e": 124489,
      "ty": 2,
      "x": 849,
      "y": 774
    },
    {
      "t": 134908,
      "e": 124590,
      "ty": 2,
      "x": 855,
      "y": 781
    },
    {
      "t": 135008,
      "e": 124690,
      "ty": 41,
      "x": 23657,
      "y": 3276,
      "ta": "#jspsych-survey-multi-choice-option-2-6 > label"
    },
    {
      "t": 135707,
      "e": 125389,
      "ty": 2,
      "x": 854,
      "y": 785
    },
    {
      "t": 135757,
      "e": 125439,
      "ty": 41,
      "x": 21544,
      "y": 29490,
      "ta": "#jspsych-survey-multi-choice-option-2-6 > label"
    },
    {
      "t": 135808,
      "e": 125490,
      "ty": 2,
      "x": 852,
      "y": 790
    },
    {
      "t": 135907,
      "e": 125589,
      "ty": 2,
      "x": 851,
      "y": 796
    },
    {
      "t": 136008,
      "e": 125690,
      "ty": 2,
      "x": 848,
      "y": 806
    },
    {
      "t": 136008,
      "e": 125690,
      "ty": 41,
      "x": 6307,
      "y": 52158,
      "ta": "#jspsych-survey-multi-choice-form"
    },
    {
      "t": 136107,
      "e": 125789,
      "ty": 2,
      "x": 847,
      "y": 818
    },
    {
      "t": 136208,
      "e": 125890,
      "ty": 2,
      "x": 845,
      "y": 826
    },
    {
      "t": 136258,
      "e": 125940,
      "ty": 41,
      "x": 5595,
      "y": 18724,
      "ta": "#jspsych-survey-multi-choice-3 > p"
    },
    {
      "t": 136307,
      "e": 125989,
      "ty": 2,
      "x": 845,
      "y": 833
    },
    {
      "t": 136408,
      "e": 126090,
      "ty": 2,
      "x": 845,
      "y": 840
    },
    {
      "t": 136508,
      "e": 126190,
      "ty": 2,
      "x": 845,
      "y": 844
    },
    {
      "t": 136508,
      "e": 126190,
      "ty": 41,
      "x": 5595,
      "y": 51491,
      "ta": "#jspsych-survey-multi-choice-3 > p"
    },
    {
      "t": 136608,
      "e": 126290,
      "ty": 2,
      "x": 845,
      "y": 848
    },
    {
      "t": 136707,
      "e": 126389,
      "ty": 2,
      "x": 845,
      "y": 853
    },
    {
      "t": 136758,
      "e": 126440,
      "ty": 41,
      "x": 5595,
      "y": 17139,
      "ta": "#jspsych-survey-multi-choice-3"
    },
    {
      "t": 136808,
      "e": 126490,
      "ty": 2,
      "x": 846,
      "y": 858
    },
    {
      "t": 136907,
      "e": 126589,
      "ty": 2,
      "x": 852,
      "y": 868
    },
    {
      "t": 137008,
      "e": 126690,
      "ty": 2,
      "x": 852,
      "y": 869
    },
    {
      "t": 137008,
      "e": 126690,
      "ty": 41,
      "x": 7256,
      "y": 2340,
      "ta": "#jspsych-survey-multi-choice-option-3-0"
    },
    {
      "t": 137208,
      "e": 126890,
      "ty": 2,
      "x": 853,
      "y": 871
    },
    {
      "t": 137258,
      "e": 126940,
      "ty": 41,
      "x": 34491,
      "y": 13107,
      "ta": "#jspsych-survey-multi-choice-option-3-0 > label"
    },
    {
      "t": 137307,
      "e": 126989,
      "ty": 2,
      "x": 853,
      "y": 879
    },
    {
      "t": 137408,
      "e": 127090,
      "ty": 2,
      "x": 847,
      "y": 891
    },
    {
      "t": 137495,
      "e": 127177,
      "ty": 6,
      "x": 837,
      "y": 903,
      "ta": "jspsych-survey-multi-choice-response-3[1]_mf"
    },
    {
      "t": 137508,
      "e": 127190,
      "ty": 2,
      "x": 837,
      "y": 903
    },
    {
      "t": 137508,
      "e": 127190,
      "ty": 41,
      "x": 53325,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-3[1]_mf"
    },
    {
      "t": 137608,
      "e": 127290,
      "ty": 2,
      "x": 836,
      "y": 904
    },
    {
      "t": 137708,
      "e": 127390,
      "ty": 2,
      "x": 835,
      "y": 905
    },
    {
      "t": 137758,
      "e": 127440,
      "ty": 41,
      "x": 43243,
      "y": 10082,
      "ta": "jspsych-survey-multi-choice-response-3[1]_mf"
    },
    {
      "t": 137789,
      "e": 127471,
      "ty": 3,
      "x": 835,
      "y": 905,
      "ta": "jspsych-survey-multi-choice-response-3[1]_mf"
    },
    {
      "t": 137790,
      "e": 127472,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-2[4]_mf"
    },
    {
      "t": 137791,
      "e": 127473,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-3[1]_mf"
    },
    {
      "t": 137941,
      "e": 127623,
      "ty": 4,
      "x": 43243,
      "y": 10082,
      "ta": "jspsych-survey-multi-choice-response-3[1]_mf"
    },
    {
      "t": 137941,
      "e": 127623,
      "ty": 5,
      "x": 835,
      "y": 905,
      "ta": "jspsych-survey-multi-choice-response-3[1]_mf"
    },
    {
      "t": 137941,
      "e": 127623,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-3[1]_mf",
      "v": "Female"
    },
    {
      "t": 138095,
      "e": 127777,
      "ty": 7,
      "x": 837,
      "y": 917,
      "ta": "jspsych-survey-multi-choice-response-3[1]_mf"
    },
    {
      "t": 138107,
      "e": 127789,
      "ty": 2,
      "x": 837,
      "y": 917
    },
    {
      "t": 138207,
      "e": 127889,
      "ty": 2,
      "x": 862,
      "y": 945
    },
    {
      "t": 138258,
      "e": 127940,
      "ty": 41,
      "x": 10579,
      "y": 63194,
      "ta": "#jspsych-survey-multi-choice-option-3-2"
    },
    {
      "t": 138261,
      "e": 127943,
      "ty": 6,
      "x": 867,
      "y": 952,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 138307,
      "e": 127989,
      "ty": 2,
      "x": 868,
      "y": 954
    },
    {
      "t": 138408,
      "e": 128090,
      "ty": 2,
      "x": 873,
      "y": 963
    },
    {
      "t": 138508,
      "e": 128190,
      "ty": 2,
      "x": 875,
      "y": 965
    },
    {
      "t": 138508,
      "e": 128190,
      "ty": 41,
      "x": 23490,
      "y": 25816,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 138974,
      "e": 128656,
      "ty": 3,
      "x": 875,
      "y": 965,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 138975,
      "e": 128657,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-3[1]_mf"
    },
    {
      "t": 138977,
      "e": 128660,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 139149,
      "e": 128832,
      "ty": 4,
      "x": 23490,
      "y": 25816,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 139149,
      "e": 128832,
      "ty": 5,
      "x": 875,
      "y": 965,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 139153,
      "e": 128836,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 139155,
      "e": 128838,
      "ty": 13,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-multi-choice-form"
    },
    {
      "t": 139156,
      "e": 128839,
      "ty": 38,
      "x": 7,
      "y": 0
    },
    {
      "t": 140492,
      "e": 130175,
      "ty": 38,
      "x": 8,
      "y": 0
    },
    {
      "t": 141811,
      "e": 131494,
      "ty": 2,
      "x": 875,
      "y": 964
    },
    {
      "t": 142012,
      "e": 131695,
      "ty": 41,
      "x": 28610,
      "y": 64523,
      "ta": "> div.masterdiv > div:[2]"
    },
    {
      "t": 146011,
      "e": 135694,
      "ty": 2,
      "x": 876,
      "y": 962
    },
    {
      "t": 146012,
      "e": 135695,
      "ty": 41,
      "x": 28659,
      "y": 64371,
      "ta": "> div.masterdiv > div:[2]"
    },
    {
      "t": 146112,
      "e": 135795,
      "ty": 2,
      "x": 876,
      "y": 961
    },
    {
      "t": 146262,
      "e": 135945,
      "ty": 41,
      "x": 28659,
      "y": 64295,
      "ta": "> div.masterdiv > div:[2]"
    },
    {
      "t": 150011,
      "e": 139694,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 248215,
      "e": 140945,
      "ty": 2,
      "x": 942,
      "y": 958
    },
    {
      "t": 248265,
      "e": 140995,
      "ty": 41,
      "x": 34218,
      "y": 64447,
      "ta": "> div.masterdiv > div:[2]"
    },
    {
      "t": 248315,
      "e": 141045,
      "ty": 2,
      "x": 999,
      "y": 966
    },
    {
      "t": 248490,
      "e": 141220,
      "ty": 6,
      "x": 995,
      "y": 978,
      "ta": "#start"
    },
    {
      "t": 248514,
      "e": 141244,
      "ty": 2,
      "x": 993,
      "y": 981
    },
    {
      "t": 248514,
      "e": 141244,
      "ty": 41,
      "x": 45601,
      "y": 7137,
      "ta": "#start"
    },
    {
      "t": 248614,
      "e": 141344,
      "ty": 2,
      "x": 989,
      "y": 986
    },
    {
      "t": 248715,
      "e": 141445,
      "ty": 2,
      "x": 980,
      "y": 994
    },
    {
      "t": 248765,
      "e": 141495,
      "ty": 41,
      "x": 38501,
      "y": 32195,
      "ta": "#start"
    },
    {
      "t": 248914,
      "e": 141644,
      "ty": 2,
      "x": 979,
      "y": 995
    },
    {
      "t": 249014,
      "e": 141744,
      "ty": 2,
      "x": 979,
      "y": 996
    },
    {
      "t": 249015,
      "e": 141745,
      "ty": 41,
      "x": 37955,
      "y": 36050,
      "ta": "#start"
    },
    {
      "t": 252284,
      "e": 145014,
      "ty": 3,
      "x": 979,
      "y": 996,
      "ta": "#start"
    },
    {
      "t": 252286,
      "e": 145016,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#start"
    },
    {
      "t": 252531,
      "e": 145261,
      "ty": 4,
      "x": 37955,
      "y": 36050,
      "ta": "#start"
    },
    {
      "t": 252533,
      "e": 145263,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#start"
    },
    {
      "t": 252534,
      "e": 145264,
      "ty": 5,
      "x": 979,
      "y": 996,
      "ta": "#start"
    },
    {
      "t": 252534,
      "e": 145264,
      "ty": 38,
      "x": 9,
      "y": 0
    },
    {
      "t": 253575,
      "e": 146305,
      "ty": 38,
      "x": 10,
      "y": 0
    },
    {
      "t": 255115,
      "e": 147845,
      "ty": 2,
      "x": 881,
      "y": 930
    },
    {
      "t": 255142,
      "e": 147872,
      "ty": 20,
      "x": 0,
      "y": 0
    }
  ],
  "domMutations": [
    {
      "sequence": 1,
      "data": "{\"f\":\"applyChanged\",\"args\":[[{\"id\":5}],[],[],[]]}"
    },
    {
      "sequence": 2,
      "data": "{\"f\":\"applyChanged\",\"args\":[[],[{\"nodeType\":1,\"id\":2312,\"tagName\":\"g\",\"attributes\":{\"class\":\"xaxis\",\"transform\":\"translate(0,800)\",\"fill\":\"none\",\"font-size\":\"10\",\"font-family\":\"sans-serif\",\"text-anchor\":\"middle\"},\"previousSibling\":{\"id\":2303},\"parentNode\":{\"id\":2301}},{\"nodeType\":1,\"id\":2313,\"tagName\":\"g\",\"attributes\":{\"class\":\"yaxis\",\"fill\":\"none\",\"font-size\":\"10\",\"font-family\":\"sans-serif\",\"text-anchor\":\"end\"},\"previousSibling\":{\"id\":2312},\"parentNode\":{\"id\":2301}},{\"nodeType\":1,\"id\":2314,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"previousSibling\":{\"id\":2313},\"parentNode\":{\"id\":2301}},{\"nodeType\":1,\"id\":2315,\"tagName\":\"g\",\"attributes\":{\"class\":\"xgrid\"},\"previousSibling\":{\"id\":2314},\"parentNode\":{\"id\":2301}},{\"nodeType\":1,\"id\":2316,\"tagName\":\"g\",\"attributes\":{\"class\":\"data\"},\"previousSibling\":{\"id\":2315},\"parentNode\":{\"id\":2301}},{\"nodeType\":1,\"id\":2317,\"tagName\":\"path\",\"attributes\":{\"class\":\"domain\",\"stroke\":\"#000\",\"d\":\"M0.5,6V0.5H800.5V6\"},\"parentNode\":{\"id\":2312}},{\"nodeType\":1,\"id\":2318,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0.5,0)\"},\"previousSibling\":{\"id\":2317},\"parentNode\":{\"id\":2312}},{\"nodeType\":1,\"id\":2319,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(33.83333333333333,0)\"},\"previousSibling\":{\"id\":2318},\"parentNode\":{\"id\":2312}},{\"nodeType\":1,\"id\":2320,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(67.16666666666666,0)\"},\"previousSibling\":{\"id\":2319},\"parentNode\":{\"id\":2312}},{\"nodeType\":1,\"id\":2321,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(100.5,0)\"},\"previousSibling\":{\"id\":2320},\"parentNode\":{\"id\":2312}},{\"nodeType\":1,\"id\":2322,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(133.83333333333331,0)\"},\"previousSibling\":{\"id\":2321},\"parentNode\":{\"id\":2312}},{\"nodeType\":1,\"id\":2323,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(167.16666666666669,0)\"},\"previousSibling\":{\"id\":2322},\"parentNode\":{\"id\":2312}},{\"nodeType\":1,\"id\":2324,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(200.5,0)\"},\"previousSibling\":{\"id\":2323},\"parentNode\":{\"id\":2312}},{\"nodeType\":1,\"id\":2325,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(233.83333333333334,0)\"},\"previousSibling\":{\"id\":2324},\"parentNode\":{\"id\":2312}},{\"nodeType\":1,\"id\":2326,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(267.16666666666663,0)\"},\"previousSibling\":{\"id\":2325},\"parentNode\":{\"id\":2312}},{\"nodeType\":1,\"id\":2327,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(300.5,0)\"},\"previousSibling\":{\"id\":2326},\"parentNode\":{\"id\":2312}},{\"nodeType\":1,\"id\":2328,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(333.83333333333337,0)\"},\"previousSibling\":{\"id\":2327},\"parentNode\":{\"id\":2312}},{\"nodeType\":1,\"id\":2329,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(367.16666666666663,0)\"},\"previousSibling\":{\"id\":2328},\"parentNode\":{\"id\":2312}},{\"nodeType\":1,\"id\":2330,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(400.5,0)\"},\"previousSibling\":{\"id\":2329},\"parentNode\":{\"id\":2312}},{\"nodeType\":1,\"id\":2331,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(433.8333333333333,0)\"},\"previousSibling\":{\"id\":2330},\"parentNode\":{\"id\":2312}},{\"nodeType\":1,\"id\":2332,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(467.1666666666667,0)\"},\"previousSibling\":{\"id\":2331},\"parentNode\":{\"id\":2312}},{\"nodeType\":1,\"id\":2333,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(500.5,0)\"},\"previousSibling\":{\"id\":2332},\"parentNode\":{\"id\":2312}},{\"nodeType\":1,\"id\":2334,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(533.8333333333333,0)\"},\"previousSibling\":{\"id\":2333},\"parentNode\":{\"id\":2312}},{\"nodeType\":1,\"id\":2335,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(567.1666666666667,0)\"},\"previousSibling\":{\"id\":2334},\"parentNode\":{\"id\":2312}},{\"nodeType\":1,\"id\":2336,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(600.5,0)\"},\"previousSibling\":{\"id\":2335},\"parentNode\":{\"id\":2312}},{\"nodeType\":1,\"id\":2337,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(633.8333333333333,0)\"},\"previousSibling\":{\"id\":2336},\"parentNode\":{\"id\":2312}},{\"nodeType\":1,\"id\":2338,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(667.1666666666667,0)\"},\"previousSibling\":{\"id\":2337},\"parentNode\":{\"id\":2312}},{\"nodeType\":1,\"id\":2339,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(700.5,0)\"},\"previousSibling\":{\"id\":2338},\"parentNode\":{\"id\":2312}},{\"nodeType\":1,\"id\":2340,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(733.8333333333333,0)\"},\"previousSibling\":{\"id\":2339},\"parentNode\":{\"id\":2312}},{\"nodeType\":1,\"id\":2341,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(767.1666666666667,0)\"},\"previousSibling\":{\"id\":2340},\"parentNode\":{\"id\":2312}},{\"nodeType\":1,\"id\":2342,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(800.5,0)\"},\"previousSibling\":{\"id\":2341},\"parentNode\":{\"id\":2312}},{\"nodeType\":1,\"id\":2343,\"tagName\":\"g\",\"attributes\":{\"class\":\"axisTitle\"},\"previousSibling\":{\"id\":2342},\"parentNode\":{\"id\":2312}},{\"nodeType\":1,\"id\":2344,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"},\"parentNode\":{\"id\":2318}},{\"nodeType\":1,\"id\":2345,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"previousSibling\":{\"id\":2344},\"parentNode\":{\"id\":2318}},{\"nodeType\":1,\"id\":2346,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"},\"parentNode\":{\"id\":2319}},{\"nodeType\":1,\"id\":2347,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"previousSibling\":{\"id\":2346},\"parentNode\":{\"id\":2319}},{\"nodeType\":1,\"id\":2348,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"},\"parentNode\":{\"id\":2320}},{\"nodeType\":1,\"id\":2349,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"previousSibling\":{\"id\":2348},\"parentNode\":{\"id\":2320}},{\"nodeType\":1,\"id\":2350,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"},\"parentNode\":{\"id\":2321}},{\"nodeType\":1,\"id\":2351,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"previousSibling\":{\"id\":2350},\"parentNode\":{\"id\":2321}},{\"nodeType\":1,\"id\":2352,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"},\"parentNode\":{\"id\":2322}},{\"nodeType\":1,\"id\":2353,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"previousSibling\":{\"id\":2352},\"parentNode\":{\"id\":2322}},{\"nodeType\":1,\"id\":2354,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"},\"parentNode\":{\"id\":2323}},{\"nodeType\":1,\"id\":2355,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"previousSibling\":{\"id\":2354},\"parentNode\":{\"id\":2323}},{\"nodeType\":1,\"id\":2356,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"},\"parentNode\":{\"id\":2324}},{\"nodeType\":1,\"id\":2357,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"previousSibling\":{\"id\":2356},\"parentNode\":{\"id\":2324}},{\"nodeType\":1,\"id\":2358,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"},\"parentNode\":{\"id\":2325}},{\"nodeType\":1,\"id\":2359,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"previousSibling\":{\"id\":2358},\"parentNode\":{\"id\":2325}},{\"nodeType\":1,\"id\":2360,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"},\"parentNode\":{\"id\":2326}},{\"nodeType\":1,\"id\":2361,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"previousSibling\":{\"id\":2360},\"parentNode\":{\"id\":2326}},{\"nodeType\":1,\"id\":2362,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"},\"parentNode\":{\"id\":2327}},{\"nodeType\":1,\"id\":2363,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"previousSibling\":{\"id\":2362},\"parentNode\":{\"id\":2327}},{\"nodeType\":1,\"id\":2364,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"},\"parentNode\":{\"id\":2328}},{\"nodeType\":1,\"id\":2365,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"previousSibling\":{\"id\":2364},\"parentNode\":{\"id\":2328}},{\"nodeType\":1,\"id\":2366,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"},\"parentNode\":{\"id\":2329}},{\"nodeType\":1,\"id\":2367,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"previousSibling\":{\"id\":2366},\"parentNode\":{\"id\":2329}},{\"nodeType\":1,\"id\":2368,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"},\"parentNode\":{\"id\":2330}},{\"nodeType\":1,\"id\":2369,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"previousSibling\":{\"id\":2368},\"parentNode\":{\"id\":2330}},{\"nodeType\":1,\"id\":2370,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"},\"parentNode\":{\"id\":2331}},{\"nodeType\":1,\"id\":2371,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"previousSibling\":{\"id\":2370},\"parentNode\":{\"id\":2331}},{\"nodeType\":1,\"id\":2372,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"},\"parentNode\":{\"id\":2332}},{\"nodeType\":1,\"id\":2373,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"previousSibling\":{\"id\":2372},\"parentNode\":{\"id\":2332}},{\"nodeType\":1,\"id\":2374,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"},\"parentNode\":{\"id\":2333}},{\"nodeType\":1,\"id\":2375,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"previousSibling\":{\"id\":2374},\"parentNode\":{\"id\":2333}},{\"nodeType\":1,\"id\":2376,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"},\"parentNode\":{\"id\":2334}},{\"nodeType\":1,\"id\":2377,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"previousSibling\":{\"id\":2376},\"parentNode\":{\"id\":2334}},{\"nodeType\":1,\"id\":2378,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"},\"parentNode\":{\"id\":2335}},{\"nodeType\":1,\"id\":2379,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"previousSibling\":{\"id\":2378},\"parentNode\":{\"id\":2335}},{\"nodeType\":1,\"id\":2380,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"},\"parentNode\":{\"id\":2336}},{\"nodeType\":1,\"id\":2381,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"previousSibling\":{\"id\":2380},\"parentNode\":{\"id\":2336}},{\"nodeType\":1,\"id\":2382,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"},\"parentNode\":{\"id\":2337}},{\"nodeType\":1,\"id\":2383,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"previousSibling\":{\"id\":2382},\"parentNode\":{\"id\":2337}},{\"nodeType\":1,\"id\":2384,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"},\"parentNode\":{\"id\":2338}},{\"nodeType\":1,\"id\":2385,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"previousSibling\":{\"id\":2384},\"parentNode\":{\"id\":2338}},{\"nodeType\":1,\"id\":2386,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"},\"parentNode\":{\"id\":2339}},{\"nodeType\":1,\"id\":2387,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"previousSibling\":{\"id\":2386},\"parentNode\":{\"id\":2339}},{\"nodeType\":1,\"id\":2388,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"},\"parentNode\":{\"id\":2340}},{\"nodeType\":1,\"id\":2389,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"previousSibling\":{\"id\":2388},\"parentNode\":{\"id\":2340}},{\"nodeType\":1,\"id\":2390,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"},\"parentNode\":{\"id\":2341}},{\"nodeType\":1,\"id\":2391,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"previousSibling\":{\"id\":2390},\"parentNode\":{\"id\":2341}},{\"nodeType\":1,\"id\":2392,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"},\"parentNode\":{\"id\":2342}},{\"nodeType\":1,\"id\":2393,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"previousSibling\":{\"id\":2392},\"parentNode\":{\"id\":2342}},{\"nodeType\":3,\"id\":2394,\"textContent\":\"08 AM\",\"parentNode\":{\"id\":2345}},{\"nodeType\":3,\"id\":2395,\"textContent\":\"08:30\",\"parentNode\":{\"id\":2347}},{\"nodeType\":3,\"id\":2396,\"textContent\":\"09 AM\",\"parentNode\":{\"id\":2349}},{\"nodeType\":3,\"id\":2397,\"textContent\":\"09:30\",\"parentNode\":{\"id\":2351}},{\"nodeType\":3,\"id\":2398,\"textContent\":\"10 AM\",\"parentNode\":{\"id\":2353}},{\"nodeType\":3,\"id\":2399,\"textContent\":\"10:30\",\"parentNode\":{\"id\":2355}},{\"nodeType\":3,\"id\":2400,\"textContent\":\"11 AM\",\"parentNode\":{\"id\":2357}},{\"nodeType\":3,\"id\":2401,\"textContent\":\"11:30\",\"parentNode\":{\"id\":2359}},{\"nodeType\":3,\"id\":2402,\"textContent\":\"12 PM\",\"parentNode\":{\"id\":2361}},{\"nodeType\":3,\"id\":2403,\"textContent\":\"12:30\",\"parentNode\":{\"id\":2363}},{\"nodeType\":3,\"id\":2404,\"textContent\":\"01 PM\",\"parentNode\":{\"id\":2365}},{\"nodeType\":3,\"id\":2405,\"textContent\":\"01:30\",\"parentNode\":{\"id\":2367}},{\"nodeType\":3,\"id\":2406,\"textContent\":\"02 PM\",\"parentNode\":{\"id\":2369}},{\"nodeType\":3,\"id\":2407,\"textContent\":\"02:30\",\"parentNode\":{\"id\":2371}},{\"nodeType\":3,\"id\":2408,\"textContent\":\"03 PM\",\"parentNode\":{\"id\":2373}},{\"nodeType\":3,\"id\":2409,\"textContent\":\"03:30\",\"parentNode\":{\"id\":2375}},{\"nodeType\":3,\"id\":2410,\"textContent\":\"04 PM\",\"parentNode\":{\"id\":2377}},{\"nodeType\":3,\"id\":2411,\"textContent\":\"04:30\",\"parentNode\":{\"id\":2379}},{\"nodeType\":3,\"id\":2412,\"textContent\":\"05 PM\",\"parentNode\":{\"id\":2381}},{\"nodeType\":3,\"id\":2413,\"textContent\":\"05:30\",\"parentNode\":{\"id\":2383}},{\"nodeType\":3,\"id\":2414,\"textContent\":\"06 PM\",\"parentNode\":{\"id\":2385}},{\"nodeType\":3,\"id\":2415,\"textContent\":\"06:30\",\"parentNode\":{\"id\":2387}},{\"nodeType\":3,\"id\":2416,\"textContent\":\"07 PM\",\"parentNode\":{\"id\":2389}},{\"nodeType\":3,\"id\":2417,\"textContent\":\"07:30\",\"parentNode\":{\"id\":2391}},{\"nodeType\":3,\"id\":2418,\"textContent\":\"08 PM\",\"parentNode\":{\"id\":2393}},{\"nodeType\":1,\"id\":2419,\"tagName\":\"text\",\"attributes\":{\"x\":\"533.3333333333334\",\"y\":\"80\",\"style\":\"text-anchor: end;\"},\"parentNode\":{\"id\":2343}},{\"nodeType\":3,\"id\":2420,\"textContent\":\"START & END TIME (time of day)\",\"parentNode\":{\"id\":2419}},{\"nodeType\":1,\"id\":2421,\"tagName\":\"path\",\"attributes\":{\"class\":\"domain\",\"stroke\":\"#000\",\"d\":\"M-15,800.5H0.5V0.5H-15\"},\"parentNode\":{\"id\":2313}},{\"nodeType\":1,\"id\":2422,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,800.5)\"},\"previousSibling\":{\"id\":2421},\"parentNode\":{\"id\":2313}},{\"nodeType\":1,\"id\":2423,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,733.8333333333334)\"},\"previousSibling\":{\"id\":2422},\"parentNode\":{\"id\":2313}},{\"nodeType\":1,\"id\":2424,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,667.1666666666667)\"},\"previousSibling\":{\"id\":2423},\"parentNode\":{\"id\":2313}},{\"nodeType\":1,\"id\":2425,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,600.5)\"},\"previousSibling\":{\"id\":2424},\"parentNode\":{\"id\":2313}},{\"nodeType\":1,\"id\":2426,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,533.8333333333334)\"},\"previousSibling\":{\"id\":2425},\"parentNode\":{\"id\":2313}},{\"nodeType\":1,\"id\":2427,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,467.16666666666663)\"},\"previousSibling\":{\"id\":2426},\"parentNode\":{\"id\":2313}},{\"nodeType\":1,\"id\":2428,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,400.5)\"},\"previousSibling\":{\"id\":2427},\"parentNode\":{\"id\":2313}},{\"nodeType\":1,\"id\":2429,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,333.8333333333333)\"},\"previousSibling\":{\"id\":2428},\"parentNode\":{\"id\":2313}},{\"nodeType\":1,\"id\":2430,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,267.16666666666674)\"},\"previousSibling\":{\"id\":2429},\"parentNode\":{\"id\":2313}},{\"nodeType\":1,\"id\":2431,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,200.5)\"},\"previousSibling\":{\"id\":2430},\"parentNode\":{\"id\":2313}},{\"nodeType\":1,\"id\":2432,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,133.83333333333326)\"},\"previousSibling\":{\"id\":2431},\"parentNode\":{\"id\":2313}},{\"nodeType\":1,\"id\":2433,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,67.16666666666674)\"},\"previousSibling\":{\"id\":2432},\"parentNode\":{\"id\":2313}},{\"nodeType\":1,\"id\":2434,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,0.5)\"},\"previousSibling\":{\"id\":2433},\"parentNode\":{\"id\":2313}},{\"nodeType\":1,\"id\":2435,\"tagName\":\"g\",\"attributes\":{\"class\":\"axisTitle\"},\"previousSibling\":{\"id\":2434},\"parentNode\":{\"id\":2313}},{\"nodeType\":1,\"id\":2436,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"},\"parentNode\":{\"id\":2422}},{\"nodeType\":1,\"id\":2437,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"previousSibling\":{\"id\":2436},\"parentNode\":{\"id\":2422}},{\"nodeType\":1,\"id\":2438,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"},\"parentNode\":{\"id\":2423}},{\"nodeType\":1,\"id\":2439,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"previousSibling\":{\"id\":2438},\"parentNode\":{\"id\":2423}},{\"nodeType\":1,\"id\":2440,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"},\"parentNode\":{\"id\":2424}},{\"nodeType\":1,\"id\":2441,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"previousSibling\":{\"id\":2440},\"parentNode\":{\"id\":2424}},{\"nodeType\":1,\"id\":2442,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"},\"parentNode\":{\"id\":2425}},{\"nodeType\":1,\"id\":2443,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"previousSibling\":{\"id\":2442},\"parentNode\":{\"id\":2425}},{\"nodeType\":1,\"id\":2444,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"},\"parentNode\":{\"id\":2426}},{\"nodeType\":1,\"id\":2445,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"previousSibling\":{\"id\":2444},\"parentNode\":{\"id\":2426}},{\"nodeType\":1,\"id\":2446,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"},\"parentNode\":{\"id\":2427}},{\"nodeType\":1,\"id\":2447,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"previousSibling\":{\"id\":2446},\"parentNode\":{\"id\":2427}},{\"nodeType\":1,\"id\":2448,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"},\"parentNode\":{\"id\":2428}},{\"nodeType\":1,\"id\":2449,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"previousSibling\":{\"id\":2448},\"parentNode\":{\"id\":2428}},{\"nodeType\":1,\"id\":2450,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"},\"parentNode\":{\"id\":2429}},{\"nodeType\":1,\"id\":2451,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"previousSibling\":{\"id\":2450},\"parentNode\":{\"id\":2429}},{\"nodeType\":1,\"id\":2452,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"},\"parentNode\":{\"id\":2430}},{\"nodeType\":1,\"id\":2453,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"previousSibling\":{\"id\":2452},\"parentNode\":{\"id\":2430}},{\"nodeType\":1,\"id\":2454,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"},\"parentNode\":{\"id\":2431}},{\"nodeType\":1,\"id\":2455,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"previousSibling\":{\"id\":2454},\"parentNode\":{\"id\":2431}},{\"nodeType\":1,\"id\":2456,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"},\"parentNode\":{\"id\":2432}},{\"nodeType\":1,\"id\":2457,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"previousSibling\":{\"id\":2456},\"parentNode\":{\"id\":2432}},{\"nodeType\":1,\"id\":2458,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"},\"parentNode\":{\"id\":2433}},{\"nodeType\":1,\"id\":2459,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"previousSibling\":{\"id\":2458},\"parentNode\":{\"id\":2433}},{\"nodeType\":1,\"id\":2460,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"},\"parentNode\":{\"id\":2434}},{\"nodeType\":1,\"id\":2461,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"previousSibling\":{\"id\":2460},\"parentNode\":{\"id\":2434}},{\"nodeType\":3,\"id\":2462,\"textContent\":\"0\",\"parentNode\":{\"id\":2437}},{\"nodeType\":3,\"id\":2463,\"textContent\":\"1\",\"parentNode\":{\"id\":2439}},{\"nodeType\":3,\"id\":2464,\"textContent\":\"2\",\"parentNode\":{\"id\":2441}},{\"nodeType\":3,\"id\":2465,\"textContent\":\"3\",\"parentNode\":{\"id\":2443}},{\"nodeType\":3,\"id\":2466,\"textContent\":\"4\",\"parentNode\":{\"id\":2445}},{\"nodeType\":3,\"id\":2467,\"textContent\":\"5\",\"parentNode\":{\"id\":2447}},{\"nodeType\":3,\"id\":2468,\"textContent\":\"6\",\"parentNode\":{\"id\":2449}},{\"nodeType\":3,\"id\":2469,\"textContent\":\"7\",\"parentNode\":{\"id\":2451}},{\"nodeType\":3,\"id\":2470,\"textContent\":\"8\",\"parentNode\":{\"id\":2453}},{\"nodeType\":3,\"id\":2471,\"textContent\":\"9\",\"parentNode\":{\"id\":2455}},{\"nodeType\":3,\"id\":2472,\"textContent\":\"10\",\"parentNode\":{\"id\":2457}},{\"nodeType\":3,\"id\":2473,\"textContent\":\"11\",\"parentNode\":{\"id\":2459}},{\"nodeType\":3,\"id\":2474,\"textContent\":\"12\",\"parentNode\":{\"id\":2461}},{\"nodeType\":1,\"id\":2475,\"tagName\":\"text\",\"attributes\":{\"transform\":\"rotate(-90)\",\"x\":\"-350\",\"y\":\"-60\",\"style\":\"text-anchor: end;\"},\"parentNode\":{\"id\":2435}},{\"nodeType\":3,\"id\":2476,\"textContent\":\"DURATION (in hours)\",\"parentNode\":{\"id\":2475}},{\"nodeType\":1,\"id\":2477,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"parentNode\":{\"id\":2314}},{\"nodeType\":1,\"id\":2478,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"previousSibling\":{\"id\":2477},\"parentNode\":{\"id\":2314}},{\"nodeType\":1,\"id\":2479,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"previousSibling\":{\"id\":2478},\"parentNode\":{\"id\":2314}},{\"nodeType\":1,\"id\":2480,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"previousSibling\":{\"id\":2479},\"parentNode\":{\"id\":2314}},{\"nodeType\":1,\"id\":2481,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"previousSibling\":{\"id\":2480},\"parentNode\":{\"id\":2314}},{\"nodeType\":1,\"id\":2482,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"previousSibling\":{\"id\":2481},\"parentNode\":{\"id\":2314}},{\"nodeType\":1,\"id\":2483,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"previousSibling\":{\"id\":2482},\"parentNode\":{\"id\":2314}},{\"nodeType\":1,\"id\":2484,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"previousSibling\":{\"id\":2483},\"parentNode\":{\"id\":2314}},{\"nodeType\":1,\"id\":2485,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"previousSibling\":{\"id\":2484},\"parentNode\":{\"id\":2314}},{\"nodeType\":1,\"id\":2486,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"previousSibling\":{\"id\":2485},\"parentNode\":{\"id\":2314}},{\"nodeType\":1,\"id\":2487,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"previousSibling\":{\"id\":2486},\"parentNode\":{\"id\":2314}},{\"nodeType\":1,\"id\":2488,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"previousSibling\":{\"id\":2487},\"parentNode\":{\"id\":2314}},{\"nodeType\":1,\"id\":2489,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"733.3333333333334\",\"y2\":\"733.3333333333334\"},\"parentNode\":{\"id\":2477}},{\"nodeType\":1,\"id\":2490,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"666.6666666666667\",\"y2\":\"666.6666666666667\"},\"parentNode\":{\"id\":2478}},{\"nodeType\":1,\"id\":2491,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"600\",\"y2\":\"600\"},\"parentNode\":{\"id\":2479}},{\"nodeType\":1,\"id\":2492,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"533.3333333333334\",\"y2\":\"533.3333333333334\"},\"parentNode\":{\"id\":2480}},{\"nodeType\":1,\"id\":2493,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"466.66666666666663\",\"y2\":\"466.66666666666663\"},\"parentNode\":{\"id\":2481}},{\"nodeType\":1,\"id\":2494,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"400\",\"y2\":\"400\"},\"parentNode\":{\"id\":2482}},{\"nodeType\":1,\"id\":2495,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"333.3333333333333\",\"y2\":\"333.3333333333333\"},\"parentNode\":{\"id\":2483}},{\"nodeType\":1,\"id\":2496,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"266.66666666666674\",\"y2\":\"266.66666666666674\"},\"parentNode\":{\"id\":2484}},{\"nodeType\":1,\"id\":2497,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"200\",\"y2\":\"200\"},\"parentNode\":{\"id\":2485}},{\"nodeType\":1,\"id\":2498,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"133.33333333333326\",\"y2\":\"133.33333333333326\"},\"parentNode\":{\"id\":2486}},{\"nodeType\":1,\"id\":2499,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"66.66666666666674\",\"y2\":\"66.66666666666674\"},\"parentNode\":{\"id\":2487}},{\"nodeType\":1,\"id\":2500,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"0\",\"y2\":\"0\"},\"parentNode\":{\"id\":2488}},{\"nodeType\":1,\"id\":2501,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"0\",\"y1\":\"800\",\"x2\":\"400\",\"y2\":\"0\"},\"parentNode\":{\"id\":2315}},{\"nodeType\":1,\"id\":2502,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"800\",\"y1\":\"800\",\"x2\":\"400\",\"y2\":\"0\"},\"previousSibling\":{\"id\":2501},\"parentNode\":{\"id\":2315}},{\"nodeType\":1,\"id\":2503,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"66.66666666666666\",\"y1\":\"800\",\"x2\":\"466.6666666666667\",\"y2\":\"0\"},\"previousSibling\":{\"id\":2502},\"parentNode\":{\"id\":2315}},{\"nodeType\":1,\"id\":2504,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"733.3333333333333\",\"y1\":\"800\",\"x2\":\"333.33333333333337\",\"y2\":\"0\"},\"previousSibling\":{\"id\":2503},\"parentNode\":{\"id\":2315}},{\"nodeType\":1,\"id\":2505,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"133.33333333333331\",\"y1\":\"800\",\"x2\":\"533.3333333333333\",\"y2\":\"0\"},\"previousSibling\":{\"id\":2504},\"parentNode\":{\"id\":2315}},{\"nodeType\":1,\"id\":2506,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"666.6666666666667\",\"y1\":\"800\",\"x2\":\"266.66666666666663\",\"y2\":\"0\"},\"previousSibling\":{\"id\":2505},\"parentNode\":{\"id\":2315}},{\"nodeType\":1,\"id\":2507,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"200\",\"y1\":\"800\",\"x2\":\"600\",\"y2\":\"0\"},\"previousSibling\":{\"id\":2506},\"parentNode\":{\"id\":2315}},{\"nodeType\":1,\"id\":2508,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"600\",\"y1\":\"800\",\"x2\":\"200\",\"y2\":\"0\"},\"previousSibling\":{\"id\":2507},\"parentNode\":{\"id\":2315}},{\"nodeType\":1,\"id\":2509,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"266.66666666666663\",\"y1\":\"800\",\"x2\":\"666.6666666666667\",\"y2\":\"0\"},\"previousSibling\":{\"id\":2508},\"parentNode\":{\"id\":2315}},{\"nodeType\":1,\"id\":2510,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"533.3333333333333\",\"y1\":\"800\",\"x2\":\"133.33333333333331\",\"y2\":\"0\"},\"previousSibling\":{\"id\":2509},\"parentNode\":{\"id\":2315}},{\"nodeType\":1,\"id\":2511,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"333.33333333333337\",\"y1\":\"800\",\"x2\":\"733.3333333333333\",\"y2\":\"0\"},\"previousSibling\":{\"id\":2510},\"parentNode\":{\"id\":2315}},{\"nodeType\":1,\"id\":2512,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"466.6666666666667\",\"y1\":\"800\",\"x2\":\"66.66666666666666\",\"y2\":\"0\"},\"previousSibling\":{\"id\":2511},\"parentNode\":{\"id\":2315}},{\"nodeType\":1,\"id\":2513,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"400\",\"y1\":\"800\",\"x2\":\"800\",\"y2\":\"0\"},\"previousSibling\":{\"id\":2512},\"parentNode\":{\"id\":2315}},{\"nodeType\":1,\"id\":2514,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"400\",\"y1\":\"800\",\"x2\":\"0\",\"y2\":\"0\"},\"previousSibling\":{\"id\":2513},\"parentNode\":{\"id\":2315}},{\"nodeType\":1,\"id\":2515,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"466.6666666666667\",\"y1\":\"800\",\"x2\":\"800\",\"y2\":\"133.33333333333326\"},\"previousSibling\":{\"id\":2514},\"parentNode\":{\"id\":2315}},{\"nodeType\":1,\"id\":2516,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"333.33333333333337\",\"y1\":\"800\",\"x2\":\"0\",\"y2\":\"133.33333333333326\"},\"previousSibling\":{\"id\":2515},\"parentNode\":{\"id\":2315}},{\"nodeType\":1,\"id\":2517,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"533.3333333333333\",\"y1\":\"800\",\"x2\":\"800\",\"y2\":\"266.66666666666674\"},\"previousSibling\":{\"id\":2516},\"parentNode\":{\"id\":2315}},{\"nodeType\":1,\"id\":2518,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"266.66666666666663\",\"y1\":\"800\",\"x2\":\"0\",\"y2\":\"266.66666666666674\"},\"previousSibling\":{\"id\":2517},\"parentNode\":{\"id\":2315}},{\"nodeType\":1,\"id\":2519,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"600\",\"y1\":\"800\",\"x2\":\"800\",\"y2\":\"400\"},\"previousSibling\":{\"id\":2518},\"parentNode\":{\"id\":2315}},{\"nodeType\":1,\"id\":2520,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"200\",\"y1\":\"800\",\"x2\":\"0\",\"y2\":\"400\"},\"previousSibling\":{\"id\":2519},\"parentNode\":{\"id\":2315}},{\"nodeType\":1,\"id\":2521,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"666.6666666666667\",\"y1\":\"800\",\"x2\":\"800\",\"y2\":\"533.3333333333334\"},\"previousSibling\":{\"id\":2520},\"parentNode\":{\"id\":2315}},{\"nodeType\":1,\"id\":2522,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"133.33333333333331\",\"y1\":\"800\",\"x2\":\"0\",\"y2\":\"533.3333333333334\"},\"previousSibling\":{\"id\":2521},\"parentNode\":{\"id\":2315}},{\"nodeType\":1,\"id\":2523,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"733.3333333333333\",\"y1\":\"800\",\"x2\":\"800\",\"y2\":\"666.6666666666667\"},\"previousSibling\":{\"id\":2522},\"parentNode\":{\"id\":2315}},{\"nodeType\":1,\"id\":2524,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"66.66666666666666\",\"y1\":\"800\",\"x2\":\"0\",\"y2\":\"666.6666666666667\"},\"previousSibling\":{\"id\":2523},\"parentNode\":{\"id\":2315}},{\"nodeType\":1,\"id\":2525,\"tagName\":\"g\",\"attributes\":{},\"parentNode\":{\"id\":2316}},{\"nodeType\":1,\"id\":2526,\"tagName\":\"g\",\"attributes\":{},\"previousSibling\":{\"id\":2525},\"parentNode\":{\"id\":2316}},{\"nodeType\":1,\"id\":2527,\"tagName\":\"g\",\"attributes\":{},\"previousSibling\":{\"id\":2526},\"parentNode\":{\"id\":2316}},{\"nodeType\":1,\"id\":2528,\"tagName\":\"g\",\"attributes\":{},\"previousSibling\":{\"id\":2527},\"parentNode\":{\"id\":2316}},{\"nodeType\":1,\"id\":2529,\"tagName\":\"g\",\"attributes\":{},\"previousSibling\":{\"id\":2528},\"parentNode\":{\"id\":2316}},{\"nodeType\":1,\"id\":2530,\"tagName\":\"g\",\"attributes\":{},\"previousSibling\":{\"id\":2529},\"parentNode\":{\"id\":2316}},{\"nodeType\":1,\"id\":2531,\"tagName\":\"g\",\"attributes\":{},\"previousSibling\":{\"id\":2530},\"parentNode\":{\"id\":2316}},{\"nodeType\":1,\"id\":2532,\"tagName\":\"g\",\"attributes\":{},\"previousSibling\":{\"id\":2531},\"parentNode\":{\"id\":2316}},{\"nodeType\":1,\"id\":2533,\"tagName\":\"g\",\"attributes\":{},\"previousSibling\":{\"id\":2532},\"parentNode\":{\"id\":2316}},{\"nodeType\":1,\"id\":2534,\"tagName\":\"g\",\"attributes\":{},\"previousSibling\":{\"id\":2533},\"parentNode\":{\"id\":2316}},{\"nodeType\":1,\"id\":2535,\"tagName\":\"g\",\"attributes\":{},\"previousSibling\":{\"id\":2534},\"parentNode\":{\"id\":2316}},{\"nodeType\":1,\"id\":2536,\"tagName\":\"g\",\"attributes\":{},\"previousSibling\":{\"id\":2535},\"parentNode\":{\"id\":2316}},{\"nodeType\":1,\"id\":2537,\"tagName\":\"g\",\"attributes\":{},\"previousSibling\":{\"id\":2536},\"parentNode\":{\"id\":2316}},{\"nodeType\":1,\"id\":2538,\"tagName\":\"g\",\"attributes\":{},\"previousSibling\":{\"id\":2537},\"parentNode\":{\"id\":2316}},{\"nodeType\":1,\"id\":2539,\"tagName\":\"g\",\"attributes\":{},\"previousSibling\":{\"id\":2538},\"parentNode\":{\"id\":2316}},{\"nodeType\":1,\"id\":2540,\"tagName\":\"g\",\"attributes\":{},\"previousSibling\":{\"id\":2539},\"parentNode\":{\"id\":2316}},{\"nodeType\":1,\"id\":2541,\"tagName\":\"g\",\"attributes\":{},\"previousSibling\":{\"id\":2540},\"parentNode\":{\"id\":2316}},{\"nodeType\":1,\"id\":2542,\"tagName\":\"g\",\"attributes\":{},\"previousSibling\":{\"id\":2541},\"parentNode\":{\"id\":2316}},{\"nodeType\":1,\"id\":2543,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"333.33333333333337\",\"cy\":\"266.66666666666674\",\"r\":\"6\",\"selected\":\"false\"},\"parentNode\":{\"id\":2525}},{\"nodeType\":1,\"id\":2544,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"328.33333333333337\",\"y\":\"258.66666666666674\"},\"previousSibling\":{\"id\":2543},\"parentNode\":{\"id\":2525}},{\"nodeType\":1,\"id\":2545,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"266.66666666666663\",\"cy\":\"600\",\"r\":\"6\",\"selected\":\"false\"},\"parentNode\":{\"id\":2526}},{\"nodeType\":1,\"id\":2546,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"261.66666666666663\",\"y\":\"592\"},\"previousSibling\":{\"id\":2545},\"parentNode\":{\"id\":2526}},{\"nodeType\":1,\"id\":2547,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"366.66666666666663\",\"cy\":\"466.66666666666663\",\"r\":\"6\",\"selected\":\"false\"},\"parentNode\":{\"id\":2527}},{\"nodeType\":1,\"id\":2548,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"361.66666666666663\",\"y\":\"458.66666666666663\"},\"previousSibling\":{\"id\":2547},\"parentNode\":{\"id\":2527}},{\"nodeType\":1,\"id\":2549,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"666.6666666666667\",\"cy\":\"666.6666666666667\",\"r\":\"6\",\"selected\":\"false\"},\"parentNode\":{\"id\":2528}},{\"nodeType\":1,\"id\":2550,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"661.6666666666667\",\"y\":\"658.6666666666667\"},\"previousSibling\":{\"id\":2549},\"parentNode\":{\"id\":2528}},{\"nodeType\":1,\"id\":2551,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"200\",\"cy\":\"400\",\"r\":\"6\",\"selected\":\"false\"},\"parentNode\":{\"id\":2529}},{\"nodeType\":1,\"id\":2552,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"195\",\"y\":\"392\"},\"previousSibling\":{\"id\":2551},\"parentNode\":{\"id\":2529}},{\"nodeType\":1,\"id\":2553,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"266.66666666666663\",\"cy\":\"533.3333333333334\",\"r\":\"6\",\"selected\":\"false\"},\"parentNode\":{\"id\":2530}},{\"nodeType\":1,\"id\":2554,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"261.66666666666663\",\"y\":\"525.3333333333334\"},\"previousSibling\":{\"id\":2553},\"parentNode\":{\"id\":2530}},{\"nodeType\":1,\"id\":2555,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"333.33333333333337\",\"cy\":\"400\",\"r\":\"6\",\"selected\":\"false\"},\"parentNode\":{\"id\":2531}},{\"nodeType\":1,\"id\":2556,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"328.33333333333337\",\"y\":\"392\"},\"previousSibling\":{\"id\":2555},\"parentNode\":{\"id\":2531}},{\"nodeType\":1,\"id\":2557,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"500\",\"cy\":\"466.66666666666663\",\"r\":\"6\",\"selected\":\"false\"},\"parentNode\":{\"id\":2532}},{\"nodeType\":1,\"id\":2558,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"495\",\"y\":\"458.66666666666663\"},\"previousSibling\":{\"id\":2557},\"parentNode\":{\"id\":2532}},{\"nodeType\":1,\"id\":2559,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"100\",\"cy\":\"600\",\"r\":\"6\",\"selected\":\"false\"},\"parentNode\":{\"id\":2533}},{\"nodeType\":1,\"id\":2560,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"95\",\"y\":\"592\"},\"previousSibling\":{\"id\":2559},\"parentNode\":{\"id\":2533}},{\"nodeType\":1,\"id\":2561,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"133.33333333333331\",\"cy\":\"666.6666666666667\",\"r\":\"6\",\"selected\":\"false\"},\"parentNode\":{\"id\":2534}},{\"nodeType\":1,\"id\":2562,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"128.33333333333331\",\"y\":\"658.6666666666667\"},\"previousSibling\":{\"id\":2561},\"parentNode\":{\"id\":2534}},{\"nodeType\":1,\"id\":2563,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"400\",\"cy\":\"133.33333333333326\",\"r\":\"6\",\"selected\":\"false\"},\"parentNode\":{\"id\":2535}},{\"nodeType\":1,\"id\":2564,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"395\",\"y\":\"125.33333333333326\"},\"previousSibling\":{\"id\":2563},\"parentNode\":{\"id\":2535}},{\"nodeType\":1,\"id\":2565,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"500\",\"cy\":\"333.3333333333333\",\"r\":\"6\",\"selected\":\"false\"},\"parentNode\":{\"id\":2536}},{\"nodeType\":1,\"id\":2566,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"495\",\"y\":\"325.3333333333333\"},\"previousSibling\":{\"id\":2565},\"parentNode\":{\"id\":2536}},{\"nodeType\":1,\"id\":2567,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"300\",\"cy\":\"733.3333333333334\",\"r\":\"6\",\"selected\":\"false\"},\"parentNode\":{\"id\":2537}},{\"nodeType\":1,\"id\":2568,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"295\",\"y\":\"725.3333333333334\"},\"previousSibling\":{\"id\":2567},\"parentNode\":{\"id\":2537}},{\"nodeType\":1,\"id\":2569,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"600\",\"cy\":\"666.6666666666667\",\"r\":\"6\",\"selected\":\"false\"},\"parentNode\":{\"id\":2538}},{\"nodeType\":1,\"id\":2570,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"595\",\"y\":\"658.6666666666667\"},\"previousSibling\":{\"id\":2569},\"parentNode\":{\"id\":2538}},{\"nodeType\":1,\"id\":2571,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"433.3333333333333\",\"cy\":\"600\",\"r\":\"6\",\"selected\":\"false\"},\"parentNode\":{\"id\":2539}},{\"nodeType\":1,\"id\":2572,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"428.3333333333333\",\"y\":\"592\"},\"previousSibling\":{\"id\":2571},\"parentNode\":{\"id\":2539}},{\"nodeType\":1,\"id\":2573,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"500\",\"cy\":\"200\",\"r\":\"6\",\"selected\":\"false\"},\"parentNode\":{\"id\":2540}},{\"nodeType\":1,\"id\":2574,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"495\",\"y\":\"192\"},\"previousSibling\":{\"id\":2573},\"parentNode\":{\"id\":2540}},{\"nodeType\":1,\"id\":2575,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"533.3333333333333\",\"cy\":\"533.3333333333334\",\"r\":\"6\",\"selected\":\"false\"},\"parentNode\":{\"id\":2541}},{\"nodeType\":1,\"id\":2576,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"528.3333333333333\",\"y\":\"525.3333333333334\"},\"previousSibling\":{\"id\":2575},\"parentNode\":{\"id\":2541}},{\"nodeType\":1,\"id\":2577,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"400\",\"cy\":\"666.6666666666667\",\"r\":\"6\",\"selected\":\"false\"},\"parentNode\":{\"id\":2542}},{\"nodeType\":1,\"id\":2578,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"395\",\"y\":\"658.6666666666667\"},\"previousSibling\":{\"id\":2577},\"parentNode\":{\"id\":2542}},{\"nodeType\":3,\"id\":2579,\"textContent\":\"A \",\"parentNode\":{\"id\":2544}},{\"nodeType\":3,\"id\":2580,\"textContent\":\"B \",\"parentNode\":{\"id\":2546}},{\"nodeType\":3,\"id\":2581,\"textContent\":\"C \",\"parentNode\":{\"id\":2548}},{\"nodeType\":3,\"id\":2582,\"textContent\":\"D \",\"parentNode\":{\"id\":2550}},{\"nodeType\":3,\"id\":2583,\"textContent\":\"E \",\"parentNode\":{\"id\":2552}},{\"nodeType\":3,\"id\":2584,\"textContent\":\"F \",\"parentNode\":{\"id\":2554}},{\"nodeType\":3,\"id\":2585,\"textContent\":\"G \",\"parentNode\":{\"id\":2556}},{\"nodeType\":3,\"id\":2586,\"textContent\":\"H \",\"parentNode\":{\"id\":2558}},{\"nodeType\":3,\"id\":2587,\"textContent\":\"I \",\"parentNode\":{\"id\":2560}},{\"nodeType\":3,\"id\":2588,\"textContent\":\"J \",\"parentNode\":{\"id\":2562}},{\"nodeType\":3,\"id\":2589,\"textContent\":\"K \",\"parentNode\":{\"id\":2564}},{\"nodeType\":3,\"id\":2590,\"textContent\":\"L \",\"parentNode\":{\"id\":2566}},{\"nodeType\":3,\"id\":2591,\"textContent\":\"M \",\"parentNode\":{\"id\":2568}},{\"nodeType\":3,\"id\":2592,\"textContent\":\"N \",\"parentNode\":{\"id\":2570}},{\"nodeType\":3,\"id\":2593,\"textContent\":\"O \",\"parentNode\":{\"id\":2572}},{\"nodeType\":3,\"id\":2594,\"textContent\":\"P \",\"parentNode\":{\"id\":2574}},{\"nodeType\":3,\"id\":2595,\"textContent\":\"Z \",\"parentNode\":{\"id\":2576}},{\"nodeType\":3,\"id\":2596,\"textContent\":\"X \",\"parentNode\":{\"id\":2578}}],[],[]]}"
    },
    {
      "sequence": 3,
      "data": "{\"f\":\"applyChanged\",\"args\":[[{\"id\":57},{\"id\":58},{\"id\":59},{\"id\":60},{\"id\":61},{\"id\":62},{\"id\":63},{\"id\":64},{\"id\":65},{\"id\":66},{\"id\":67},{\"id\":68},{\"id\":69},{\"id\":70},{\"id\":71},{\"id\":72},{\"id\":73},{\"id\":74},{\"id\":75},{\"id\":76},{\"id\":77},{\"id\":78},{\"id\":79},{\"id\":80},{\"id\":81},{\"id\":82},{\"id\":83},{\"id\":84},{\"id\":85},{\"id\":86},{\"id\":87},{\"id\":88},{\"id\":89},{\"id\":90},{\"id\":91},{\"id\":92},{\"id\":93},{\"id\":94},{\"id\":95},{\"id\":96},{\"id\":97},{\"id\":98},{\"id\":99},{\"id\":100},{\"id\":101},{\"id\":102},{\"id\":103},{\"id\":104},{\"id\":105},{\"id\":106},{\"id\":107},{\"id\":108},{\"id\":109},{\"id\":110},{\"id\":111},{\"id\":112},{\"id\":113},{\"id\":114},{\"id\":115},{\"id\":116},{\"id\":117},{\"id\":118},{\"id\":119},{\"id\":120},{\"id\":121},{\"id\":122},{\"id\":123},{\"id\":124},{\"id\":125},{\"id\":126},{\"id\":127},{\"id\":128},{\"id\":129},{\"id\":130},{\"id\":131},{\"id\":132},{\"id\":133},{\"id\":134},{\"id\":135},{\"id\":136},{\"id\":137},{\"id\":138},{\"id\":139},{\"id\":140},{\"id\":141},{\"id\":142},{\"id\":143},{\"id\":144},{\"id\":145},{\"id\":146},{\"id\":147},{\"id\":148},{\"id\":149},{\"id\":150},{\"id\":151},{\"id\":152},{\"id\":153},{\"id\":154},{\"id\":155},{\"id\":156},{\"id\":157},{\"id\":158},{\"id\":159},{\"id\":160},{\"id\":161},{\"id\":162},{\"id\":163},{\"id\":164},{\"id\":165},{\"id\":166},{\"id\":167},{\"id\":168},{\"id\":169},{\"id\":170},{\"id\":171},{\"id\":172},{\"id\":173},{\"id\":174},{\"id\":175},{\"id\":176},{\"id\":177},{\"id\":178},{\"id\":179},{\"id\":180},{\"id\":181},{\"id\":182},{\"id\":183},{\"id\":184},{\"id\":185},{\"id\":186},{\"id\":187},{\"id\":188},{\"id\":189},{\"id\":190},{\"id\":191},{\"id\":192},{\"id\":193},{\"id\":194},{\"id\":195},{\"id\":196},{\"id\":197},{\"id\":198},{\"id\":199},{\"id\":200},{\"id\":201},{\"id\":202},{\"id\":203},{\"id\":204},{\"id\":205},{\"id\":206},{\"id\":207},{\"id\":208},{\"id\":209},{\"id\":210},{\"id\":211},{\"id\":212},{\"id\":213},{\"id\":214},{\"id\":215},{\"id\":216},{\"id\":217},{\"id\":218},{\"id\":219},{\"id\":220},{\"id\":221},{\"id\":222},{\"id\":223},{\"id\":224},{\"id\":225},{\"id\":226},{\"id\":227},{\"id\":228},{\"id\":229},{\"id\":230},{\"id\":231},{\"id\":232},{\"id\":233},{\"id\":234},{\"id\":235},{\"id\":236},{\"id\":237},{\"id\":238},{\"id\":239},{\"id\":240},{\"id\":241},{\"id\":242},{\"id\":243},{\"id\":244},{\"id\":245},{\"id\":246},{\"id\":247},{\"id\":248},{\"id\":249},{\"id\":250},{\"id\":251},{\"id\":252},{\"id\":253},{\"id\":254},{\"id\":255},{\"id\":256},{\"id\":257},{\"id\":258},{\"id\":259},{\"id\":260},{\"id\":261},{\"id\":262},{\"id\":263},{\"id\":264},{\"id\":265},{\"id\":266},{\"id\":267},{\"id\":268},{\"id\":269},{\"id\":270},{\"id\":271},{\"id\":272},{\"id\":273},{\"id\":274},{\"id\":275},{\"id\":276},{\"id\":277},{\"id\":278},{\"id\":279},{\"id\":280},{\"id\":281},{\"id\":282},{\"id\":283},{\"id\":284},{\"id\":285},{\"id\":286},{\"id\":287},{\"id\":288},{\"id\":289},{\"id\":290},{\"id\":291},{\"id\":292},{\"id\":293},{\"id\":294},{\"id\":295},{\"id\":296},{\"id\":297},{\"id\":298},{\"id\":299},{\"id\":300},{\"id\":301},{\"id\":302},{\"id\":303},{\"id\":304},{\"id\":305},{\"id\":306},{\"id\":307},{\"id\":308},{\"id\":309},{\"id\":310},{\"id\":311},{\"id\":312},{\"id\":313},{\"id\":314},{\"id\":315},{\"id\":316},{\"id\":317},{\"id\":318},{\"id\":319},{\"id\":320},{\"id\":321},{\"id\":322},{\"id\":323},{\"id\":324},{\"id\":325},{\"id\":326},{\"id\":327},{\"id\":328},{\"id\":329},{\"id\":330},{\"id\":331},{\"id\":332},{\"id\":333},{\"id\":334},{\"id\":335},{\"id\":336},{\"id\":337},{\"id\":338},{\"id\":339},{\"id\":340},{\"id\":341},{\"id\":342},{\"id\":343},{\"id\":344},{\"id\":345},{\"id\":346},{\"id\":347},{\"id\":348},{\"id\":349},{\"id\":350},{\"id\":351},{\"id\":352},{\"id\":353},{\"id\":354},{\"id\":355},{\"id\":356},{\"id\":357},{\"id\":358},{\"id\":359},{\"id\":360},{\"id\":361},{\"id\":362},{\"id\":363},{\"id\":364},{\"id\":365},{\"id\":366},{\"id\":367},{\"id\":368},{\"id\":369},{\"id\":370},{\"id\":371},{\"id\":372},{\"id\":373},{\"id\":374},{\"id\":375},{\"id\":376},{\"id\":377},{\"id\":378},{\"id\":379},{\"id\":380},{\"id\":381},{\"id\":382},{\"id\":383},{\"id\":384},{\"id\":385},{\"id\":386},{\"id\":387},{\"id\":388},{\"id\":389},{\"id\":390},{\"id\":391},{\"id\":392},{\"id\":393},{\"id\":394},{\"id\":395},{\"id\":396},{\"id\":397},{\"id\":398},{\"id\":399},{\"id\":400},{\"id\":401},{\"id\":402},{\"id\":403},{\"id\":404},{\"id\":405},{\"id\":406},{\"id\":407},{\"id\":408},{\"id\":409},{\"id\":410},{\"id\":411},{\"id\":412},{\"id\":413},{\"id\":414},{\"id\":415},{\"id\":416},{\"id\":417},{\"id\":418},{\"id\":419},{\"id\":420},{\"id\":421},{\"id\":422},{\"id\":423},{\"id\":424},{\"id\":425},{\"id\":426},{\"id\":427},{\"id\":428},{\"id\":429},{\"id\":430},{\"id\":431},{\"id\":432},{\"id\":433},{\"id\":434},{\"id\":435},{\"id\":436},{\"id\":437},{\"id\":438},{\"id\":439},{\"id\":440},{\"id\":441},{\"id\":442},{\"id\":443},{\"id\":444},{\"id\":445},{\"id\":446},{\"id\":447},{\"id\":448},{\"id\":449},{\"id\":450},{\"id\":451},{\"id\":452},{\"id\":453},{\"id\":454},{\"id\":455},{\"id\":456},{\"id\":457},{\"id\":458},{\"id\":459},{\"id\":460},{\"id\":461},{\"id\":462},{\"id\":463},{\"id\":464},{\"id\":465},{\"id\":466},{\"id\":467},{\"id\":468},{\"id\":469},{\"id\":470},{\"id\":471},{\"id\":472},{\"id\":473},{\"id\":474},{\"id\":475},{\"id\":476},{\"id\":477},{\"id\":478},{\"id\":479},{\"id\":480},{\"id\":481},{\"id\":482},{\"id\":483},{\"id\":484},{\"id\":485},{\"id\":486},{\"id\":487},{\"id\":488},{\"id\":489},{\"id\":490},{\"id\":491},{\"id\":492},{\"id\":493},{\"id\":494},{\"id\":495},{\"id\":496},{\"id\":497},{\"id\":498},{\"id\":499},{\"id\":500},{\"id\":501},{\"id\":502},{\"id\":503},{\"id\":504},{\"id\":505},{\"id\":506},{\"id\":507},{\"id\":508},{\"id\":509},{\"id\":510},{\"id\":511},{\"id\":512},{\"id\":513},{\"id\":514},{\"id\":515},{\"id\":516},{\"id\":517},{\"id\":518},{\"id\":519},{\"id\":520},{\"id\":521},{\"id\":522},{\"id\":523},{\"id\":524},{\"id\":525},{\"id\":526},{\"id\":527},{\"id\":528},{\"id\":529},{\"id\":530},{\"id\":531},{\"id\":532},{\"id\":533},{\"id\":534},{\"id\":535},{\"id\":536},{\"id\":537},{\"id\":538},{\"id\":539},{\"id\":540},{\"id\":541},{\"id\":542},{\"id\":543},{\"id\":544},{\"id\":545},{\"id\":546},{\"id\":547},{\"id\":548},{\"id\":549},{\"id\":550},{\"id\":551},{\"id\":552},{\"id\":553},{\"id\":554},{\"id\":555},{\"id\":556},{\"id\":557},{\"id\":558},{\"id\":559},{\"id\":560},{\"id\":561},{\"id\":562},{\"id\":563},{\"id\":564},{\"id\":565},{\"id\":566},{\"id\":567},{\"id\":568},{\"id\":569},{\"id\":570},{\"id\":571},{\"id\":572},{\"id\":573},{\"id\":574},{\"id\":575},{\"id\":576},{\"id\":577},{\"id\":578},{\"id\":579},{\"id\":580},{\"id\":581},{\"id\":582},{\"id\":583},{\"id\":584},{\"id\":585},{\"id\":586},{\"id\":587},{\"id\":588},{\"id\":589},{\"id\":590},{\"id\":591},{\"id\":592},{\"id\":593},{\"id\":594},{\"id\":595},{\"id\":596},{\"id\":597},{\"id\":598},{\"id\":599},{\"id\":600},{\"id\":601},{\"id\":602},{\"id\":603},{\"id\":604},{\"id\":605},{\"id\":606},{\"id\":607},{\"id\":608},{\"id\":609},{\"id\":610},{\"id\":611},{\"id\":612},{\"id\":613},{\"id\":614},{\"id\":615},{\"id\":616},{\"id\":617},{\"id\":618},{\"id\":619},{\"id\":620},{\"id\":621},{\"id\":622},{\"id\":623},{\"id\":624},{\"id\":625},{\"id\":626},{\"id\":627},{\"id\":628},{\"id\":629},{\"id\":630},{\"id\":631},{\"id\":632},{\"id\":633},{\"id\":634},{\"id\":635},{\"id\":636},{\"id\":637},{\"id\":638},{\"id\":639},{\"id\":640},{\"id\":641},{\"id\":642},{\"id\":643},{\"id\":644},{\"id\":645},{\"id\":646},{\"id\":647},{\"id\":648},{\"id\":649},{\"id\":650},{\"id\":651},{\"id\":652},{\"id\":653},{\"id\":654},{\"id\":655},{\"id\":656},{\"id\":657},{\"id\":658},{\"id\":659},{\"id\":660},{\"id\":661},{\"id\":662},{\"id\":663},{\"id\":664},{\"id\":665},{\"id\":666},{\"id\":667},{\"id\":668},{\"id\":669},{\"id\":670},{\"id\":671},{\"id\":672},{\"id\":673},{\"id\":674},{\"id\":675},{\"id\":676},{\"id\":677},{\"id\":678},{\"id\":679},{\"id\":680},{\"id\":681},{\"id\":682},{\"id\":683},{\"id\":684},{\"id\":685},{\"id\":686},{\"id\":687},{\"id\":688},{\"id\":689},{\"id\":690},{\"id\":691},{\"id\":692},{\"id\":693},{\"id\":694},{\"id\":695},{\"id\":696},{\"id\":697},{\"id\":698},{\"id\":699},{\"id\":700},{\"id\":701},{\"id\":702},{\"id\":703},{\"id\":704},{\"id\":705},{\"id\":706},{\"id\":707},{\"id\":708},{\"id\":709},{\"id\":710},{\"id\":711},{\"id\":712},{\"id\":713},{\"id\":714},{\"id\":715},{\"id\":716},{\"id\":717},{\"id\":718},{\"id\":719},{\"id\":720},{\"id\":721},{\"id\":722},{\"id\":723},{\"id\":724},{\"id\":725},{\"id\":726},{\"id\":727},{\"id\":728},{\"id\":729},{\"id\":730},{\"id\":731},{\"id\":732},{\"id\":733},{\"id\":734},{\"id\":735},{\"id\":736},{\"id\":737},{\"id\":738},{\"id\":739},{\"id\":740},{\"id\":741},{\"id\":742},{\"id\":743},{\"id\":744},{\"id\":745},{\"id\":746},{\"id\":747},{\"id\":748},{\"id\":749},{\"id\":750},{\"id\":751},{\"id\":752},{\"id\":753},{\"id\":754},{\"id\":755},{\"id\":756},{\"id\":757},{\"id\":758},{\"id\":759},{\"id\":760},{\"id\":761},{\"id\":762},{\"id\":763},{\"id\":764},{\"id\":765},{\"id\":766},{\"id\":767},{\"id\":768},{\"id\":769},{\"id\":770},{\"id\":771},{\"id\":772},{\"id\":773},{\"id\":774},{\"id\":775},{\"id\":776},{\"id\":777},{\"id\":778},{\"id\":779},{\"id\":780},{\"id\":781},{\"id\":782},{\"id\":783},{\"id\":784},{\"id\":785},{\"id\":786},{\"id\":787},{\"id\":788},{\"id\":789},{\"id\":790},{\"id\":791},{\"id\":792},{\"id\":793},{\"id\":794},{\"id\":795},{\"id\":796},{\"id\":797},{\"id\":798},{\"id\":799},{\"id\":800},{\"id\":801},{\"id\":802},{\"id\":803},{\"id\":804},{\"id\":805},{\"id\":806},{\"id\":807},{\"id\":808},{\"id\":809},{\"id\":810},{\"id\":811},{\"id\":812},{\"id\":813},{\"id\":814},{\"id\":815},{\"id\":816},{\"id\":817},{\"id\":818},{\"id\":819},{\"id\":820},{\"id\":821},{\"id\":822},{\"id\":823},{\"id\":824},{\"id\":825},{\"id\":826},{\"id\":827},{\"id\":828},{\"id\":829},{\"id\":830},{\"id\":831},{\"id\":832},{\"id\":833},{\"id\":834},{\"id\":835},{\"id\":836},{\"id\":837},{\"id\":838},{\"id\":839},{\"id\":840},{\"id\":841},{\"id\":842},{\"id\":843},{\"id\":844},{\"id\":845},{\"id\":846},{\"id\":847},{\"id\":848},{\"id\":849},{\"id\":850},{\"id\":851},{\"id\":852},{\"id\":853},{\"id\":854},{\"id\":855},{\"id\":856},{\"id\":857},{\"id\":858},{\"id\":859},{\"id\":860},{\"id\":861},{\"id\":862},{\"id\":863},{\"id\":864},{\"id\":865},{\"id\":866},{\"id\":867},{\"id\":868},{\"id\":869},{\"id\":870},{\"id\":871},{\"id\":872},{\"id\":873},{\"id\":874},{\"id\":875},{\"id\":876},{\"id\":877},{\"id\":878},{\"id\":879},{\"id\":880},{\"id\":881},{\"id\":882},{\"id\":883},{\"id\":884},{\"id\":885},{\"id\":886},{\"id\":887},{\"id\":888},{\"id\":889},{\"id\":890},{\"id\":891},{\"id\":892},{\"id\":893},{\"id\":894},{\"id\":895},{\"id\":896},{\"id\":897},{\"id\":898},{\"id\":899},{\"id\":900},{\"id\":901},{\"id\":902},{\"id\":903},{\"id\":904},{\"id\":905},{\"id\":906},{\"id\":907},{\"id\":908},{\"id\":909},{\"id\":910},{\"id\":911},{\"id\":912},{\"id\":913},{\"id\":914},{\"id\":915},{\"id\":916},{\"id\":917},{\"id\":918},{\"id\":919},{\"id\":920},{\"id\":921},{\"id\":922},{\"id\":923},{\"id\":924},{\"id\":925},{\"id\":926},{\"id\":927},{\"id\":928},{\"id\":929},{\"id\":930},{\"id\":931},{\"id\":932},{\"id\":933},{\"id\":934},{\"id\":935},{\"id\":936},{\"id\":937},{\"id\":938},{\"id\":939},{\"id\":940},{\"id\":941},{\"id\":942},{\"id\":943},{\"id\":944},{\"id\":945},{\"id\":946},{\"id\":947},{\"id\":948},{\"id\":949},{\"id\":950},{\"id\":951},{\"id\":952},{\"id\":953},{\"id\":954},{\"id\":955},{\"id\":956},{\"id\":957},{\"id\":958},{\"id\":959},{\"id\":960},{\"id\":961},{\"id\":962},{\"id\":963},{\"id\":964},{\"id\":965},{\"id\":966},{\"id\":967},{\"id\":968},{\"id\":969},{\"id\":970},{\"id\":971},{\"id\":972},{\"id\":973},{\"id\":974},{\"id\":975},{\"id\":976},{\"id\":977},{\"id\":978},{\"id\":979},{\"id\":980},{\"id\":981},{\"id\":982},{\"id\":983},{\"id\":984},{\"id\":985},{\"id\":986},{\"id\":987},{\"id\":988},{\"id\":989},{\"id\":990},{\"id\":991},{\"id\":992},{\"id\":993},{\"id\":994},{\"id\":995},{\"id\":996},{\"id\":997},{\"id\":998},{\"id\":999},{\"id\":1000},{\"id\":1001},{\"id\":1002},{\"id\":1003},{\"id\":1004},{\"id\":1005},{\"id\":1006},{\"id\":1007},{\"id\":1008},{\"id\":1009},{\"id\":1010},{\"id\":1011},{\"id\":1012},{\"id\":1013},{\"id\":1014},{\"id\":1015},{\"id\":1016},{\"id\":1017},{\"id\":1018},{\"id\":1019},{\"id\":1020},{\"id\":1021},{\"id\":1022},{\"id\":1023},{\"id\":1024},{\"id\":1025},{\"id\":1026},{\"id\":1027},{\"id\":1028},{\"id\":1029},{\"id\":1030},{\"id\":1031},{\"id\":1032},{\"id\":1033},{\"id\":1034},{\"id\":1035},{\"id\":1036},{\"id\":1037},{\"id\":1038},{\"id\":1039},{\"id\":1040},{\"id\":1041},{\"id\":1042},{\"id\":1043},{\"id\":1044},{\"id\":1045},{\"id\":1046},{\"id\":1047},{\"id\":1048},{\"id\":1049},{\"id\":1050},{\"id\":1051},{\"id\":1052},{\"id\":1053},{\"id\":1054},{\"id\":1055},{\"id\":1056},{\"id\":1057},{\"id\":1058},{\"id\":1059},{\"id\":1060},{\"id\":1061},{\"id\":1062},{\"id\":1063},{\"id\":1064},{\"id\":1065},{\"id\":1066},{\"id\":1067},{\"id\":1068},{\"id\":1069},{\"id\":1070},{\"id\":1071},{\"id\":1072},{\"id\":1073},{\"id\":1074},{\"id\":1075},{\"id\":1076},{\"id\":1077},{\"id\":1078},{\"id\":1079},{\"id\":1080},{\"id\":1081},{\"id\":1082},{\"id\":1083},{\"id\":1084},{\"id\":1085},{\"id\":1086},{\"id\":1087},{\"id\":1088},{\"id\":1089},{\"id\":1090},{\"id\":1091},{\"id\":1092},{\"id\":1093},{\"id\":1094},{\"id\":1095},{\"id\":1096},{\"id\":1097},{\"id\":1098},{\"id\":1099},{\"id\":1100},{\"id\":1101},{\"id\":1102},{\"id\":1103},{\"id\":1104},{\"id\":1105},{\"id\":1106},{\"id\":1107},{\"id\":1108},{\"id\":1109},{\"id\":1110},{\"id\":1111},{\"id\":1112},{\"id\":1113},{\"id\":1114},{\"id\":1115},{\"id\":1116},{\"id\":1117},{\"id\":1118},{\"id\":1119},{\"id\":1120},{\"id\":1121},{\"id\":1122},{\"id\":1123},{\"id\":1124},{\"id\":1125},{\"id\":1126},{\"id\":1127},{\"id\":1128},{\"id\":1129},{\"id\":1130},{\"id\":1131},{\"id\":1132},{\"id\":1133},{\"id\":1134},{\"id\":1135},{\"id\":1136},{\"id\":1137},{\"id\":1138},{\"id\":1139},{\"id\":1140},{\"id\":1141},{\"id\":1142},{\"id\":1143},{\"id\":1144},{\"id\":1145},{\"id\":1146},{\"id\":1147},{\"id\":1148},{\"id\":1149},{\"id\":1150},{\"id\":1151},{\"id\":1152},{\"id\":1153},{\"id\":1154},{\"id\":1155},{\"id\":1156},{\"id\":1157},{\"id\":1158},{\"id\":1159},{\"id\":1160},{\"id\":1161},{\"id\":1162},{\"id\":1163},{\"id\":1164},{\"id\":1165},{\"id\":1166},{\"id\":1167},{\"id\":1168},{\"id\":1169},{\"id\":1170},{\"id\":1171},{\"id\":1172},{\"id\":1173},{\"id\":1174},{\"id\":1175},{\"id\":1176},{\"id\":1177},{\"id\":1178},{\"id\":1179},{\"id\":1180},{\"id\":1181},{\"id\":1182},{\"id\":1183},{\"id\":1184},{\"id\":1185},{\"id\":1186},{\"id\":1187},{\"id\":1188},{\"id\":1189},{\"id\":1190},{\"id\":1191},{\"id\":1192},{\"id\":1193},{\"id\":1194},{\"id\":1195},{\"id\":1196},{\"id\":1197},{\"id\":1198},{\"id\":1199},{\"id\":1200},{\"id\":1201},{\"id\":1202},{\"id\":1203},{\"id\":1204},{\"id\":1205},{\"id\":1206},{\"id\":1207},{\"id\":1208},{\"id\":1209},{\"id\":1210},{\"id\":1211},{\"id\":1212},{\"id\":1213},{\"id\":1214},{\"id\":1215},{\"id\":1216},{\"id\":1217},{\"id\":1218},{\"id\":1219},{\"id\":1220},{\"id\":1221},{\"id\":1222},{\"id\":1223},{\"id\":1224},{\"id\":1225},{\"id\":1226},{\"id\":1227},{\"id\":1228},{\"id\":1229},{\"id\":1230},{\"id\":1231},{\"id\":1232},{\"id\":1233},{\"id\":1234},{\"id\":1235},{\"id\":1236},{\"id\":1237},{\"id\":1238},{\"id\":1239},{\"id\":1240},{\"id\":1241},{\"id\":1242},{\"id\":1243},{\"id\":1244},{\"id\":1245},{\"id\":1246},{\"id\":1247},{\"id\":1248},{\"id\":1249},{\"id\":1250},{\"id\":1251},{\"id\":1252},{\"id\":1253},{\"id\":1254},{\"id\":1255},{\"id\":1256},{\"id\":1257},{\"id\":1258},{\"id\":1259},{\"id\":1260},{\"id\":1261},{\"id\":1262},{\"id\":1263},{\"id\":1264},{\"id\":1265},{\"id\":1266},{\"id\":1267},{\"id\":1268},{\"id\":1269},{\"id\":1270},{\"id\":1271},{\"id\":1272},{\"id\":1273},{\"id\":1274},{\"id\":1275},{\"id\":1276},{\"id\":1277},{\"id\":1278},{\"id\":1279},{\"id\":1280},{\"id\":1281},{\"id\":1282},{\"id\":1283},{\"id\":1284},{\"id\":1285},{\"id\":1286},{\"id\":1287},{\"id\":1288},{\"id\":1289},{\"id\":1290},{\"id\":1291},{\"id\":1292},{\"id\":1293},{\"id\":1294},{\"id\":1295},{\"id\":1296},{\"id\":1297},{\"id\":1298},{\"id\":1299},{\"id\":1300},{\"id\":1301},{\"id\":1302},{\"id\":1303},{\"id\":1304},{\"id\":1305},{\"id\":1306},{\"id\":1307},{\"id\":1308},{\"id\":1309},{\"id\":1310},{\"id\":1311},{\"id\":1312},{\"id\":1313},{\"id\":1314},{\"id\":1315},{\"id\":1316},{\"id\":1317},{\"id\":1318},{\"id\":1319},{\"id\":1320},{\"id\":1321},{\"id\":1322},{\"id\":1323},{\"id\":1324},{\"id\":1325},{\"id\":1326},{\"id\":1327},{\"id\":1328},{\"id\":1329},{\"id\":1330},{\"id\":1331},{\"id\":1332},{\"id\":1333},{\"id\":1334},{\"id\":1335},{\"id\":1336},{\"id\":1337},{\"id\":1338},{\"id\":1339},{\"id\":1340},{\"id\":1341},{\"id\":1342},{\"id\":1343},{\"id\":1344},{\"id\":1345},{\"id\":1346},{\"id\":1347},{\"id\":1348},{\"id\":1349},{\"id\":1350},{\"id\":1351},{\"id\":1352},{\"id\":1353},{\"id\":1354},{\"id\":1355},{\"id\":1356},{\"id\":1357},{\"id\":1358},{\"id\":1359},{\"id\":1360},{\"id\":1361},{\"id\":1362},{\"id\":1363},{\"id\":1364},{\"id\":1365},{\"id\":1366},{\"id\":1367},{\"id\":1368},{\"id\":1369},{\"id\":1370},{\"id\":1371},{\"id\":1372},{\"id\":1373},{\"id\":1374},{\"id\":1375},{\"id\":1376},{\"id\":1377},{\"id\":1378},{\"id\":1379},{\"id\":1380},{\"id\":1381},{\"id\":1382},{\"id\":1383},{\"id\":1384},{\"id\":1385},{\"id\":1386},{\"id\":1387},{\"id\":1388},{\"id\":1389},{\"id\":1390},{\"id\":1391},{\"id\":1392},{\"id\":1393},{\"id\":1394},{\"id\":1395},{\"id\":1396},{\"id\":1397},{\"id\":1398},{\"id\":1399},{\"id\":1400},{\"id\":1401},{\"id\":1402},{\"id\":1403},{\"id\":1404},{\"id\":1405},{\"id\":1406},{\"id\":1407},{\"id\":1408},{\"id\":1409},{\"id\":1410},{\"id\":1411},{\"id\":1412},{\"id\":1413},{\"id\":1414},{\"id\":1415},{\"id\":1416},{\"id\":1417},{\"id\":1418},{\"id\":1419},{\"id\":1420},{\"id\":1421},{\"id\":1422},{\"id\":1423},{\"id\":1424},{\"id\":1425},{\"id\":1426},{\"id\":1427},{\"id\":1428},{\"id\":1429},{\"id\":1430},{\"id\":1431},{\"id\":1432},{\"id\":1433},{\"id\":1434},{\"id\":1435},{\"id\":1436},{\"id\":1437},{\"id\":1438},{\"id\":1439},{\"id\":1440},{\"id\":1441},{\"id\":1442},{\"id\":1443},{\"id\":1444},{\"id\":1445},{\"id\":1446},{\"id\":1447},{\"id\":1448},{\"id\":1449},{\"id\":1450},{\"id\":1451},{\"id\":1452},{\"id\":1453},{\"id\":1454},{\"id\":1455},{\"id\":1456},{\"id\":1457},{\"id\":1458},{\"id\":1459},{\"id\":1460},{\"id\":1461},{\"id\":1462},{\"id\":1463},{\"id\":1464},{\"id\":1465},{\"id\":1466},{\"id\":1467},{\"id\":1468},{\"id\":1469},{\"id\":1470},{\"id\":1471},{\"id\":1472},{\"id\":1473},{\"id\":1474},{\"id\":1475},{\"id\":1476},{\"id\":1477},{\"id\":1478},{\"id\":1479},{\"id\":1480},{\"id\":1481},{\"id\":1482},{\"id\":1483},{\"id\":1484},{\"id\":1485},{\"id\":1486},{\"id\":1487},{\"id\":1488},{\"id\":1489},{\"id\":1490},{\"id\":1491},{\"id\":1492},{\"id\":1493},{\"id\":1494},{\"id\":1495},{\"id\":1496},{\"id\":1497},{\"id\":1498},{\"id\":1499},{\"id\":1500},{\"id\":1501},{\"id\":1502},{\"id\":1503},{\"id\":1504},{\"id\":1505},{\"id\":1506},{\"id\":1507},{\"id\":1508},{\"id\":1509},{\"id\":1510},{\"id\":1511},{\"id\":1512},{\"id\":1513},{\"id\":1514},{\"id\":1515},{\"id\":1516},{\"id\":1517},{\"id\":1518},{\"id\":1519},{\"id\":1520},{\"id\":1521},{\"id\":1522},{\"id\":1523},{\"id\":1524},{\"id\":1525},{\"id\":1526},{\"id\":1527},{\"id\":1528},{\"id\":1529},{\"id\":1530},{\"id\":1531},{\"id\":1532},{\"id\":1533},{\"id\":1534},{\"id\":1535},{\"id\":1536},{\"id\":1537},{\"id\":1538},{\"id\":1539},{\"id\":1540},{\"id\":1541},{\"id\":1542},{\"id\":1543},{\"id\":1544},{\"id\":1545},{\"id\":1546},{\"id\":1547},{\"id\":1548},{\"id\":1549},{\"id\":1550},{\"id\":1551},{\"id\":1552},{\"id\":1553},{\"id\":1554},{\"id\":1555},{\"id\":1556},{\"id\":1557},{\"id\":1558},{\"id\":1559},{\"id\":1560},{\"id\":1561},{\"id\":1562},{\"id\":1563},{\"id\":1564},{\"id\":1565},{\"id\":1566},{\"id\":1567},{\"id\":1568},{\"id\":1569},{\"id\":1570},{\"id\":1571},{\"id\":1572},{\"id\":1573},{\"id\":1574},{\"id\":1575},{\"id\":1576},{\"id\":1577},{\"id\":1578},{\"id\":1579},{\"id\":1580},{\"id\":1581},{\"id\":1582},{\"id\":1583},{\"id\":1584},{\"id\":1585},{\"id\":1586},{\"id\":1587},{\"id\":1588},{\"id\":1589},{\"id\":1590},{\"id\":1591},{\"id\":1592},{\"id\":1593},{\"id\":1594},{\"id\":1595},{\"id\":1596},{\"id\":1597},{\"id\":1598},{\"id\":1599},{\"id\":1600},{\"id\":1601},{\"id\":1602},{\"id\":1603},{\"id\":1604},{\"id\":1605},{\"id\":1606},{\"id\":1607},{\"id\":1608},{\"id\":1609},{\"id\":1610},{\"id\":1611},{\"id\":1612},{\"id\":1613},{\"id\":1614},{\"id\":1615},{\"id\":1616},{\"id\":1617},{\"id\":1618},{\"id\":1619},{\"id\":1620},{\"id\":1621},{\"id\":1622},{\"id\":1623},{\"id\":1624},{\"id\":1625},{\"id\":1626},{\"id\":1627},{\"id\":1628},{\"id\":1629},{\"id\":1630},{\"id\":1631},{\"id\":1632},{\"id\":1633},{\"id\":1634},{\"id\":1635},{\"id\":1636},{\"id\":1637},{\"id\":1638},{\"id\":1639},{\"id\":1640},{\"id\":1641},{\"id\":1642},{\"id\":1643},{\"id\":1644},{\"id\":1645},{\"id\":1646},{\"id\":1647},{\"id\":1648},{\"id\":1649},{\"id\":1650},{\"id\":1651},{\"id\":1652},{\"id\":1653},{\"id\":1654},{\"id\":1655},{\"id\":1656},{\"id\":1657},{\"id\":1658},{\"id\":1659},{\"id\":1660},{\"id\":1661},{\"id\":1662},{\"id\":1663},{\"id\":1664},{\"id\":1665},{\"id\":1666},{\"id\":1667},{\"id\":1668},{\"id\":1669},{\"id\":1670},{\"id\":1671},{\"id\":1672},{\"id\":1673},{\"id\":1674},{\"id\":1675},{\"id\":1676},{\"id\":1677},{\"id\":1678},{\"id\":1679},{\"id\":1680},{\"id\":1681},{\"id\":1682},{\"id\":1683},{\"id\":1684},{\"id\":1685},{\"id\":1686},{\"id\":1687},{\"id\":1688},{\"id\":1689},{\"id\":1690},{\"id\":1691},{\"id\":1692},{\"id\":1693},{\"id\":1694},{\"id\":1695},{\"id\":1696},{\"id\":1697},{\"id\":1698},{\"id\":1699},{\"id\":1700},{\"id\":1701},{\"id\":1702},{\"id\":1703},{\"id\":1704},{\"id\":1705},{\"id\":1706},{\"id\":1707},{\"id\":1708},{\"id\":1709},{\"id\":1710},{\"id\":1711},{\"id\":1712},{\"id\":1713},{\"id\":1714},{\"id\":1715},{\"id\":1716},{\"id\":1717},{\"id\":1718},{\"id\":1719},{\"id\":1720},{\"id\":1721},{\"id\":1722},{\"id\":1723},{\"id\":1724},{\"id\":1725},{\"id\":1726},{\"id\":1727},{\"id\":1728},{\"id\":1729},{\"id\":1730},{\"id\":1731},{\"id\":1732},{\"id\":1733},{\"id\":1734},{\"id\":1735},{\"id\":1736},{\"id\":1737},{\"id\":1738},{\"id\":1739},{\"id\":1740},{\"id\":1741},{\"id\":1742},{\"id\":1743},{\"id\":1744},{\"id\":1745},{\"id\":1746},{\"id\":1747},{\"id\":1748},{\"id\":1749},{\"id\":1750},{\"id\":1751},{\"id\":1752},{\"id\":1753},{\"id\":1754},{\"id\":1755},{\"id\":1756},{\"id\":1757},{\"id\":1758},{\"id\":1759},{\"id\":1760},{\"id\":1761},{\"id\":1762},{\"id\":1763},{\"id\":1764},{\"id\":1765},{\"id\":1766},{\"id\":1767},{\"id\":1768},{\"id\":1769},{\"id\":1770},{\"id\":1771},{\"id\":1772},{\"id\":1773},{\"id\":1774},{\"id\":1775},{\"id\":1776},{\"id\":1777},{\"id\":1778},{\"id\":1779},{\"id\":1780},{\"id\":1781},{\"id\":1782},{\"id\":1783},{\"id\":1784},{\"id\":1785},{\"id\":1786},{\"id\":1787},{\"id\":1788},{\"id\":1789},{\"id\":1790},{\"id\":1791},{\"id\":1792},{\"id\":1793},{\"id\":1794},{\"id\":1795},{\"id\":1796},{\"id\":1797},{\"id\":1798},{\"id\":1799},{\"id\":1800},{\"id\":1801},{\"id\":1802},{\"id\":1803},{\"id\":1804},{\"id\":1805},{\"id\":1806},{\"id\":1807},{\"id\":1808},{\"id\":1809},{\"id\":1810},{\"id\":1811},{\"id\":1812},{\"id\":1813},{\"id\":1814},{\"id\":1815},{\"id\":1816},{\"id\":1817},{\"id\":1818},{\"id\":1819},{\"id\":1820},{\"id\":1821},{\"id\":1822},{\"id\":1823},{\"id\":1824},{\"id\":1825},{\"id\":1826},{\"id\":1827},{\"id\":1828},{\"id\":1829},{\"id\":1830},{\"id\":1831},{\"id\":1832},{\"id\":1833},{\"id\":1834},{\"id\":1835},{\"id\":1836},{\"id\":1837},{\"id\":1838},{\"id\":1839},{\"id\":1840},{\"id\":1841},{\"id\":1842},{\"id\":1843},{\"id\":1844},{\"id\":1845},{\"id\":1846},{\"id\":1847},{\"id\":1848},{\"id\":1849},{\"id\":1850},{\"id\":1851},{\"id\":1852},{\"id\":1853},{\"id\":1854},{\"id\":1855},{\"id\":1856},{\"id\":1857},{\"id\":1858},{\"id\":1859},{\"id\":1860},{\"id\":1861},{\"id\":1862},{\"id\":1863},{\"id\":1864},{\"id\":1865},{\"id\":1866},{\"id\":1867},{\"id\":1868},{\"id\":1869},{\"id\":1870},{\"id\":1871},{\"id\":1872},{\"id\":1873},{\"id\":1874},{\"id\":1875},{\"id\":1876},{\"id\":1877},{\"id\":1878},{\"id\":1879},{\"id\":1880},{\"id\":1881},{\"id\":1882},{\"id\":1883},{\"id\":1884},{\"id\":1885},{\"id\":1886},{\"id\":1887},{\"id\":1888},{\"id\":1889},{\"id\":1890},{\"id\":1891},{\"id\":1892},{\"id\":1893},{\"id\":1894},{\"id\":1895},{\"id\":1896},{\"id\":1897},{\"id\":1898},{\"id\":1899},{\"id\":1900},{\"id\":1901},{\"id\":1902},{\"id\":1903},{\"id\":1904},{\"id\":1905},{\"id\":1906},{\"id\":1907},{\"id\":1908},{\"id\":1909},{\"id\":1910},{\"id\":1911},{\"id\":1912},{\"id\":1913},{\"id\":1914},{\"id\":1915},{\"id\":1916},{\"id\":1917},{\"id\":1918},{\"id\":1919},{\"id\":1920},{\"id\":1921},{\"id\":1922},{\"id\":1923},{\"id\":1924},{\"id\":1925},{\"id\":1926},{\"id\":1927},{\"id\":1928},{\"id\":1929},{\"id\":1930},{\"id\":1931},{\"id\":1932},{\"id\":1933},{\"id\":1934},{\"id\":1935},{\"id\":1936},{\"id\":1937},{\"id\":1938},{\"id\":1939},{\"id\":1940},{\"id\":1941},{\"id\":1942},{\"id\":1943},{\"id\":1944},{\"id\":1945},{\"id\":1946},{\"id\":1947},{\"id\":1948},{\"id\":1949},{\"id\":1950},{\"id\":1951},{\"id\":1952},{\"id\":1953},{\"id\":1954},{\"id\":1955},{\"id\":1956},{\"id\":1957},{\"id\":1958},{\"id\":1959},{\"id\":1960},{\"id\":1961},{\"id\":1962},{\"id\":1963},{\"id\":1964},{\"id\":1965},{\"id\":1966},{\"id\":1967},{\"id\":1968},{\"id\":1969},{\"id\":1970},{\"id\":1971},{\"id\":1972},{\"id\":1973},{\"id\":1974},{\"id\":1975},{\"id\":1976},{\"id\":1977},{\"id\":1978},{\"id\":1979},{\"id\":1980},{\"id\":1981},{\"id\":1982},{\"id\":1983},{\"id\":1984},{\"id\":1985},{\"id\":1986},{\"id\":1987},{\"id\":1988},{\"id\":1989},{\"id\":1990},{\"id\":1991},{\"id\":1992},{\"id\":1993},{\"id\":1994},{\"id\":1995},{\"id\":1996},{\"id\":1997},{\"id\":1998},{\"id\":1999},{\"id\":2000},{\"id\":2001},{\"id\":2002},{\"id\":2003},{\"id\":2004},{\"id\":2005},{\"id\":2006},{\"id\":2007},{\"id\":2008},{\"id\":2009},{\"id\":2010},{\"id\":2011},{\"id\":2012},{\"id\":2013},{\"id\":2014},{\"id\":2015},{\"id\":2016},{\"id\":2017},{\"id\":2018},{\"id\":2019},{\"id\":2020},{\"id\":2021},{\"id\":2022},{\"id\":2023},{\"id\":2024},{\"id\":2025},{\"id\":2026},{\"id\":2027},{\"id\":2028},{\"id\":2029},{\"id\":2030},{\"id\":2031},{\"id\":2032},{\"id\":2033},{\"id\":2034},{\"id\":2035},{\"id\":2036},{\"id\":2037},{\"id\":2038},{\"id\":2039},{\"id\":2040},{\"id\":2041},{\"id\":2042},{\"id\":2043},{\"id\":2044},{\"id\":2045},{\"id\":2046},{\"id\":2047},{\"id\":2048},{\"id\":2049},{\"id\":2050},{\"id\":2051},{\"id\":2052},{\"id\":2053},{\"id\":2054},{\"id\":2055},{\"id\":2056},{\"id\":2057},{\"id\":2058},{\"id\":2059},{\"id\":2060},{\"id\":2061},{\"id\":2062},{\"id\":2063},{\"id\":2064},{\"id\":2065},{\"id\":2066},{\"id\":2067},{\"id\":2068},{\"id\":2069},{\"id\":2070},{\"id\":2071},{\"id\":2072},{\"id\":2073},{\"id\":2074},{\"id\":2075},{\"id\":2076},{\"id\":2077},{\"id\":2078},{\"id\":2079},{\"id\":2080},{\"id\":2081},{\"id\":2082},{\"id\":2083},{\"id\":2084},{\"id\":2085},{\"id\":2086},{\"id\":2087},{\"id\":2088},{\"id\":2089},{\"id\":2090},{\"id\":2091},{\"id\":2092},{\"id\":2093},{\"id\":2094},{\"id\":2095},{\"id\":2096},{\"id\":2097},{\"id\":2098},{\"id\":2099},{\"id\":2100},{\"id\":2101},{\"id\":2102},{\"id\":2103},{\"id\":2104},{\"id\":2105},{\"id\":2106},{\"id\":2107},{\"id\":2108},{\"id\":2109},{\"id\":2110},{\"id\":2111},{\"id\":2112},{\"id\":2113},{\"id\":2114},{\"id\":2115},{\"id\":2116},{\"id\":2117},{\"id\":2118},{\"id\":2119},{\"id\":2120},{\"id\":2121},{\"id\":2122},{\"id\":2123},{\"id\":2124},{\"id\":2125},{\"id\":2126},{\"id\":2127},{\"id\":2128},{\"id\":2129},{\"id\":2130},{\"id\":2131},{\"id\":2132},{\"id\":2133},{\"id\":2134},{\"id\":2135},{\"id\":2136},{\"id\":2137},{\"id\":2138},{\"id\":2139},{\"id\":2140},{\"id\":2141},{\"id\":2142},{\"id\":2143},{\"id\":2144},{\"id\":2145},{\"id\":2146},{\"id\":2147},{\"id\":2148},{\"id\":2149},{\"id\":2150},{\"id\":2151},{\"id\":2152},{\"id\":2153},{\"id\":2154},{\"id\":2155},{\"id\":2156},{\"id\":2157},{\"id\":2158},{\"id\":2159},{\"id\":2160},{\"id\":2161},{\"id\":2162},{\"id\":2163},{\"id\":2164},{\"id\":2165},{\"id\":2166},{\"id\":2167},{\"id\":2168},{\"id\":2169},{\"id\":2170},{\"id\":2171},{\"id\":2172},{\"id\":2173},{\"id\":2174},{\"id\":2175},{\"id\":2176},{\"id\":2177},{\"id\":2178},{\"id\":2179},{\"id\":2180},{\"id\":2181},{\"id\":2182},{\"id\":2183},{\"id\":2184},{\"id\":2185},{\"id\":2186},{\"id\":2187},{\"id\":2188},{\"id\":2189},{\"id\":2190},{\"id\":2191},{\"id\":2192},{\"id\":2193},{\"id\":2194},{\"id\":2195},{\"id\":2196},{\"id\":2197},{\"id\":2198},{\"id\":2199},{\"id\":2200},{\"id\":2201},{\"id\":2202},{\"id\":2203},{\"id\":2204},{\"id\":2205},{\"id\":2206},{\"id\":2207},{\"id\":2208},{\"id\":2209},{\"id\":2210},{\"id\":2211},{\"id\":2212},{\"id\":2213},{\"id\":2214},{\"id\":2215},{\"id\":2216},{\"id\":2217},{\"id\":2218},{\"id\":2219},{\"id\":2220},{\"id\":2221},{\"id\":2222},{\"id\":2223},{\"id\":2224},{\"id\":2225},{\"id\":2226},{\"id\":2227},{\"id\":2228},{\"id\":2229},{\"id\":2230},{\"id\":2231},{\"id\":2232},{\"id\":2233},{\"id\":2234},{\"id\":2235},{\"id\":2236},{\"id\":2237},{\"id\":2238},{\"id\":2239},{\"id\":2240},{\"id\":2241},{\"id\":2242},{\"id\":2243},{\"id\":2244},{\"id\":2245},{\"id\":2246},{\"id\":2247},{\"id\":2248},{\"id\":2249},{\"id\":2250},{\"id\":2251},{\"id\":2252},{\"id\":2253},{\"id\":2254},{\"id\":2255},{\"id\":2256},{\"id\":2257},{\"id\":2258},{\"id\":2259},{\"id\":2260},{\"id\":2261},{\"id\":2262},{\"id\":2263},{\"id\":2264},{\"id\":2265},{\"id\":2266},{\"id\":2267},{\"id\":2268},{\"id\":2269},{\"id\":2270},{\"id\":2271},{\"id\":2272},{\"id\":2273},{\"id\":2274},{\"id\":2275},{\"id\":2276},{\"id\":2277},{\"id\":2278},{\"id\":2279},{\"id\":2280},{\"id\":2281},{\"id\":2282},{\"id\":2283},{\"id\":2284},{\"id\":2285},{\"id\":2286},{\"id\":2287},{\"id\":2288},{\"id\":2289},{\"id\":2290},{\"id\":2291},{\"id\":2292},{\"id\":2293},{\"id\":2294},{\"id\":2295},{\"id\":2296},{\"id\":2297},{\"id\":2298},{\"id\":2299},{\"id\":2300},{\"id\":2301},{\"id\":2302},{\"id\":2303},{\"id\":2312},{\"id\":2317},{\"id\":2318},{\"id\":2344},{\"id\":2345},{\"id\":2394},{\"id\":2319},{\"id\":2346},{\"id\":2347},{\"id\":2395},{\"id\":2320},{\"id\":2348},{\"id\":2349},{\"id\":2396},{\"id\":2321},{\"id\":2350},{\"id\":2351},{\"id\":2397},{\"id\":2322},{\"id\":2352},{\"id\":2353},{\"id\":2398},{\"id\":2323},{\"id\":2354},{\"id\":2355},{\"id\":2399},{\"id\":2324},{\"id\":2356},{\"id\":2357},{\"id\":2400},{\"id\":2325},{\"id\":2358},{\"id\":2359},{\"id\":2401},{\"id\":2326},{\"id\":2360},{\"id\":2361},{\"id\":2402},{\"id\":2327},{\"id\":2362},{\"id\":2363},{\"id\":2403},{\"id\":2328},{\"id\":2364},{\"id\":2365},{\"id\":2404},{\"id\":2329},{\"id\":2366},{\"id\":2367},{\"id\":2405},{\"id\":2330},{\"id\":2368},{\"id\":2369},{\"id\":2406},{\"id\":2331},{\"id\":2370},{\"id\":2371},{\"id\":2407},{\"id\":2332},{\"id\":2372},{\"id\":2373},{\"id\":2408},{\"id\":2333},{\"id\":2374},{\"id\":2375},{\"id\":2409},{\"id\":2334},{\"id\":2376},{\"id\":2377},{\"id\":2410},{\"id\":2335},{\"id\":2378},{\"id\":2379},{\"id\":2411},{\"id\":2336},{\"id\":2380},{\"id\":2381},{\"id\":2412},{\"id\":2337},{\"id\":2382},{\"id\":2383},{\"id\":2413},{\"id\":2338},{\"id\":2384},{\"id\":2385},{\"id\":2414},{\"id\":2339},{\"id\":2386},{\"id\":2387},{\"id\":2415},{\"id\":2340},{\"id\":2388},{\"id\":2389},{\"id\":2416},{\"id\":2341},{\"id\":2390},{\"id\":2391},{\"id\":2417},{\"id\":2342},{\"id\":2392},{\"id\":2393},{\"id\":2418},{\"id\":2343},{\"id\":2419},{\"id\":2420},{\"id\":2313},{\"id\":2421},{\"id\":2422},{\"id\":2436},{\"id\":2437},{\"id\":2462},{\"id\":2423},{\"id\":2438},{\"id\":2439},{\"id\":2463},{\"id\":2424},{\"id\":2440},{\"id\":2441},{\"id\":2464},{\"id\":2425},{\"id\":2442},{\"id\":2443},{\"id\":2465},{\"id\":2426},{\"id\":2444},{\"id\":2445},{\"id\":2466},{\"id\":2427},{\"id\":2446},{\"id\":2447},{\"id\":2467},{\"id\":2428},{\"id\":2448},{\"id\":2449},{\"id\":2468},{\"id\":2429},{\"id\":2450},{\"id\":2451},{\"id\":2469},{\"id\":2430},{\"id\":2452},{\"id\":2453},{\"id\":2470},{\"id\":2431},{\"id\":2454},{\"id\":2455},{\"id\":2471},{\"id\":2432},{\"id\":2456},{\"id\":2457},{\"id\":2472},{\"id\":2433},{\"id\":2458},{\"id\":2459},{\"id\":2473},{\"id\":2434},{\"id\":2460},{\"id\":2461},{\"id\":2474},{\"id\":2435},{\"id\":2475},{\"id\":2476},{\"id\":2314},{\"id\":2477},{\"id\":2489},{\"id\":2478},{\"id\":2490},{\"id\":2479},{\"id\":2491},{\"id\":2480},{\"id\":2492},{\"id\":2481},{\"id\":2493},{\"id\":2482},{\"id\":2494},{\"id\":2483},{\"id\":2495},{\"id\":2484},{\"id\":2496},{\"id\":2485},{\"id\":2497},{\"id\":2486},{\"id\":2498},{\"id\":2487},{\"id\":2499},{\"id\":2488},{\"id\":2500},{\"id\":2315},{\"id\":2501},{\"id\":2502},{\"id\":2503},{\"id\":2504},{\"id\":2505},{\"id\":2506},{\"id\":2507},{\"id\":2508},{\"id\":2509},{\"id\":2510},{\"id\":2511},{\"id\":2512},{\"id\":2513},{\"id\":2514},{\"id\":2515},{\"id\":2516},{\"id\":2517},{\"id\":2518},{\"id\":2519},{\"id\":2520},{\"id\":2521},{\"id\":2522},{\"id\":2523},{\"id\":2524},{\"id\":2316},{\"id\":2525},{\"id\":2543},{\"id\":2544},{\"id\":2579},{\"id\":2526},{\"id\":2545},{\"id\":2546},{\"id\":2580},{\"id\":2527},{\"id\":2547},{\"id\":2548},{\"id\":2581},{\"id\":2528},{\"id\":2549},{\"id\":2550},{\"id\":2582},{\"id\":2529},{\"id\":2551},{\"id\":2552},{\"id\":2583},{\"id\":2530},{\"id\":2553},{\"id\":2554},{\"id\":2584},{\"id\":2531},{\"id\":2555},{\"id\":2556},{\"id\":2585},{\"id\":2532},{\"id\":2557},{\"id\":2558},{\"id\":2586},{\"id\":2533},{\"id\":2559},{\"id\":2560},{\"id\":2587},{\"id\":2534},{\"id\":2561},{\"id\":2562},{\"id\":2588},{\"id\":2535},{\"id\":2563},{\"id\":2564},{\"id\":2589},{\"id\":2536},{\"id\":2565},{\"id\":2566},{\"id\":2590},{\"id\":2537},{\"id\":2567},{\"id\":2568},{\"id\":2591},{\"id\":2538},{\"id\":2569},{\"id\":2570},{\"id\":2592},{\"id\":2539},{\"id\":2571},{\"id\":2572},{\"id\":2593},{\"id\":2540},{\"id\":2573},{\"id\":2574},{\"id\":2594},{\"id\":2541},{\"id\":2575},{\"id\":2576},{\"id\":2595},{\"id\":2542},{\"id\":2577},{\"id\":2578},{\"id\":2596},{\"id\":2304},{\"id\":2305},{\"id\":2306},{\"id\":2307},{\"id\":2308},{\"nodeType\":3,\"id\":2597,\"textContent\":\" // Track clicks on page $(document).ready(function() { $(\\\".control\\\").click(function(e) { e.stopImmediatePropagation(); clicks = clicks + 1; console.log(clicks); }); }); $('.userid').html(sid); // console.log(\\\"start of clicked array: \\\"+clicked); // console.log(\\\"start of hovered string: \\\"+hovered); //set correct answers for each question var triangular_answers = { \\\"acme.starttime.1\\\" : [\\\"F\\\"], \\\"acme.starts.1\\\" : [\\\"K\\\"], \\\"acme.meets.1\\\" : [\\\"F\\\"], \\\"acme.endtime.1\\\" : [\\\"H\\\"], \\\"acme.midpoint.1\\\" : [\\\"O\\\"], \\\"acme.starttime.2\\\" : [\\\"F\\\"], \\\"acme.starts.2\\\" : [\\\"K\\\"], \\\"acme.meets.2\\\" : [\\\"F\\\"], \\\"acme.endtime.2\\\" : [\\\"H\\\"], \\\"acme.midpoint.2\\\" : [\\\"A\\\"], \\\"bigset.duration.1\\\" : [\\\"E\\\",\\\"G\\\"], \\\"bigset.duration+starts.1\\\" : [\\\"X\\\",\\\"O\\\"], \\\"bigset.duration+contained.1\\\" : [\\\"G\\\"], \\\"bigset.starttime+before+endtime+during.1\\\": [\\\"I\\\"], \\\"bigset.ends.1\\\" : [\\\"E\\\"], \\\"bigset.duration.2\\\" : [\\\"E\\\",\\\"G\\\"], \\\"bigset.duration+starts.2\\\" : [\\\"X\\\",\\\"O\\\"], \\\"bigset.duration+contained.2\\\" : [\\\"G\\\"], \\\"bigset.starttime+before+endtime+during.2\\\":[\\\"I\\\"], \\\"bigset.ends.2\\\" : [\\\"E\\\"], \\\"bigset.starttime.1\\\" : [\\\"M\\\",\\\"L\\\"], \\\"bigset.starts.1\\\" : [\\\"G\\\"], \\\"bigset.meets.1\\\" : [\\\"E\\\",\\\"F\\\"], \\\"bigset.endtime.1\\\" : [\\\"X\\\"], \\\"bigset.midpoint.1\\\" : [\\\"K\\\",\\\"X\\\"], \\\"bigset.starttime.2\\\" : [\\\"M\\\",\\\"L\\\"], \\\"bigset.starts.2\\\" : [\\\"G\\\"], \\\"bigset.meets.2\\\" : [\\\"E\\\",\\\"F\\\"], \\\"bigset.endtime.2\\\" : [\\\"X\\\"], \\\"bigset.midpoint.2\\\" : [\\\"K\\\",\\\"X\\\"] } var orthogonal_answers = { \\\"acme.starttime.1\\\" : [\\\"A\\\"], \\\"acme.starts.1\\\" : [\\\"E\\\"], \\\"acme.meets.1\\\" : [\\\"Z\\\"], \\\"acme.endtime.1\\\" : [\\\"U\\\"], \\\"acme.midpoint.1\\\" : [\\\"U\\\"], \\\"acme.starttime.2\\\" : [\\\"0\\\"], \\\"acme.starts.2\\\" : [\\\"0\\\"], \\\"acme.meets.2\\\" : [\\\"0\\\"], \\\"acme.endtime.2\\\" : [\\\"0\\\"], \\\"acme.midpoint.2\\\" : [\\\"0\\\"], \\\"bigset.duration.1\\\" : [\\\"E\\\",\\\"G\\\"], \\\"bigset.duration+starts.1\\\" : [\\\"F\\\",\\\"B\\\"], \\\"bigset.duration+contained.1\\\" : [\\\"E\\\"], \\\"bigset.starttime+before+endtime+during.1\\\": [\\\"I\\\"], \\\"bigset.ends.1\\\" : [\\\"X\\\"], \\\"bigset.duration.2\\\" : [\\\"E\\\",\\\"G\\\"], \\\"bigset.duration+starts.2\\\" : [\\\"F\\\",\\\"B\\\"], \\\"bigset.duration+contained.2\\\" : [\\\"E\\\"], \\\"bigset.starttime+before+endtime+during.2\\\":[\\\"I\\\"], \\\"bigset.ends.2\\\" : [\\\"X\\\"], \\\"bigset.starttime.1\\\" : [\\\"F\\\",\\\"B\\\"], \\\"bigset.starts.1\\\" : [\\\"B\\\"], \\\"bigset.meets.1\\\" : [\\\"F\\\",\\\"X\\\"], \\\"bigset.endtime.1\\\" : [\\\"B\\\"], \\\"bigset.midpoint.1\\\" : [\\\"E\\\",\\\"F\\\"], \\\"bigset.starttime.2\\\" : [\\\"F\\\",\\\"B\\\"], \\\"bigset.starts.2\\\" : [\\\"B\\\"], \\\"bigset.meets.2\\\" : [\\\"F\\\",\\\"X\\\"], \\\"bigset.endtime.2\\\" : [\\\"B\\\"], \\\"bigset.midpoint.2\\\" : [\\\"E\\\",\\\"F\\\"] } //display the question and answer buttons based on input values from jsPsych document.getElementById(scenario+\\\".\\\"+question).style.display = \\\"block\\\"; if (question == \\\"strategy\\\") {document.getElementById(\\\"strategyButton\\\").style.display = \\\"block\\\";} else {document.getElementById(\\\"testingButton\\\").style.display = \\\"block\\\";} //---------SET PROPERTIES OF THE GRAPH -------------// // set the dimensions and margins of the graph var margin = {top: 25, right: 30, bottom: 90, left: 100}, width = 800, height = 800; var intersects = false; //default value for intersects scaffold var xAxisTitle, yAxisTitle; var datafile =\\\"\\\"; // SET AXIS VALUES if (axis == 1){ axis = \\\"Orthogonal-XInside-YFull\\\"; } else if (axis == 2){ axis = \\\"Orthogonal-XInside-YPartial\\\"; } else if (axis ==3){ axis = \\\"Triangular-XInside-YInside\\\"; } else if (axis ==4){ axis = \\\"Orthogonal-XInside-YInside\\\"; } else if (axis ==5){ axis = \\\"Orthogonal-XFull-YFull\\\"; } // SET EXPLICIT SCAFFOLD FEATURES if (explicit ==2 && axis != \\\"diagonal\\\"){ scaffold = 2; intersects = false; } else if (explicit == 2 && axis == \\\"diagonal\\\"){ scaffold = 2; intersects = false; } //TODO: not sure if above two lines are still valid since leaders are now generated on the fly else if (explicit == 3){ $('#hint-interactive').css(\\\"display\\\",\\\"block\\\"); //display textimage scaffold intersects = true; } //SET DATA FILE FOR IMPLICIT SCAFFOLD if (impasse == 1){ datafile = \\\"../views/src/data/acme_nonimpasse.csv\\\"; } else if (impasse == 2){ datafile = \\\"../views/src/data/acme_impasse.csv\\\"; } //OVERRIDE DATA FILE FOR NON-SCAFFOLD QUESTIONS if (q > 5) { //override data file if q# is greater than 5 datafile = \\\"../views/src/data/bigset.csv\\\"; console.log(\\\"override data file\\\"); $('#orthogonal-image').css(\\\"display\\\",\\\"none\\\"); //display textimage scaffold $('#diagonal-image').css(\\\"display\\\",\\\"none\\\"); //display textimage scaffold $('#hint-interactive').css(\\\"display\\\",\\\"none\\\"); //display textimage scaffold intersects = false; } // //---------CREATE THE SVG ------------------------// var svg = d3.select(\\\".d3container\\\").append(\\\"svg\\\") .attr(\\\"width\\\", width + margin.left + margin.right) .attr(\\\"height\\\", height + margin.top + margin.bottom) .append(\\\"g\\\") .attr(\\\"transform\\\", \\\"translate(\\\" + margin.left + \\\",\\\" + margin.top + \\\")\\\"); //---------DRAW THE GRAPH ------------------------// xAxisTitle = \\\"START & END TIME (time of day)\\\"; yAxisTitle = \\\"DURATION (in hours)\\\"; drawTriangleModel(datafile,intersects,axis,scaffold,q); \"},{\"id\":2309},{\"id\":2310},{\"nodeType\":3,\"id\":2598,\"textContent\":\" //MOUSE LOGGING SCRIPT var mouseLog = [] var xwidth = $(document).width(); var xheight = $(document).width(); mouseLog.push(\\\"{x:\\\"+xwidth+\\\",y:\\\"+xheight+\\\",t:\\\"+\\\"0};\\\") document.onmousemove = function(e){ var pageCoords = \\\"{x:\\\" + e.pageX + \\\",y:\\\"+ e.pageY +\\\",t:\\\"+ Date.now()+ \\\"};\\\" ; mouseLog.push(pageCoords); // console.log(pageCoords); }; \"},{\"id\":2311}],[],[],[]]}"
    },
    {
      "sequence": 4,
      "data": "{\"f\":\"applyChanged\",\"args\":[[],[{\"nodeType\":1,\"id\":2599,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-text-preamble\",\"class\":\"jspsych-survey-text-preamble\"},\"parentNode\":{\"id\":56}},{\"nodeType\":1,\"id\":2600,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-text-0\",\"class\":\"jspsych-survey-text-question\"},\"previousSibling\":{\"id\":2599},\"parentNode\":{\"id\":56}},{\"nodeType\":1,\"id\":2601,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-text-1\",\"class\":\"jspsych-survey-text-question\"},\"previousSibling\":{\"id\":2600},\"parentNode\":{\"id\":56}},{\"nodeType\":1,\"id\":2602,\"tagName\":\"BUTTON\",\"attributes\":{\"id\":\"jspsych-survey-text-next\",\"class\":\"jspsych-btn jspsych-survey-text\"},\"previousSibling\":{\"id\":2601},\"parentNode\":{\"id\":56}},{\"nodeType\":1,\"id\":2603,\"tagName\":\"P\",\"attributes\":{\"class\":\"jspsych-survey-text\"},\"parentNode\":{\"id\":2600}},{\"nodeType\":1,\"id\":2604,\"tagName\":\"TEXTAREA\",\"attributes\":{\"name\":\"#jspsych-survey-text-response-0\",\"cols\":\"40\",\"rows\":\"1\"},\"previousSibling\":{\"id\":2603},\"parentNode\":{\"id\":2600}},{\"nodeType\":3,\"id\":2605,\"textContent\":\"What is your age?\",\"parentNode\":{\"id\":2603}},{\"nodeType\":1,\"id\":2606,\"tagName\":\"P\",\"attributes\":{\"class\":\"jspsych-survey-text\"},\"parentNode\":{\"id\":2601}},{\"nodeType\":1,\"id\":2607,\"tagName\":\"TEXTAREA\",\"attributes\":{\"name\":\"#jspsych-survey-text-response-1\",\"cols\":\"40\",\"rows\":\"1\"},\"previousSibling\":{\"id\":2606},\"parentNode\":{\"id\":2601}},{\"nodeType\":3,\"id\":2608,\"textContent\":\"In what country were you born?\",\"parentNode\":{\"id\":2606}},{\"nodeType\":3,\"id\":2609,\"textContent\":\"Submit Answers\",\"parentNode\":{\"id\":2602}}],[],[]]}"
    },
    {
      "sequence": 5,
      "data": "{\"f\":\"applyChanged\",\"args\":[[{\"id\":2599},{\"id\":2600},{\"id\":2603},{\"id\":2605},{\"id\":2604},{\"id\":2601},{\"id\":2606},{\"id\":2608},{\"id\":2607},{\"id\":2602},{\"id\":2609}],[],[],[]]}"
    },
    {
      "sequence": 6,
      "data": "{\"f\":\"applyChanged\",\"args\":[[],[{\"nodeType\":1,\"id\":2610,\"tagName\":\"FORM\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-form\"},\"parentNode\":{\"id\":56}},{\"nodeType\":1,\"id\":2611,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-preamble\",\"class\":\"jspsych-survey-multi-choice-preamble\"},\"parentNode\":{\"id\":2610}},{\"nodeType\":1,\"id\":2612,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-0\",\"class\":\"jspsych-survey-multi-choice-question jspsych-survey-multi-choice-horizontal\"},\"previousSibling\":{\"id\":2611},\"parentNode\":{\"id\":2610}},{\"nodeType\":1,\"id\":2613,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-1\",\"class\":\"jspsych-survey-multi-choice-question jspsych-survey-multi-choice-horizontal\"},\"previousSibling\":{\"id\":2612},\"parentNode\":{\"id\":2610}},{\"nodeType\":1,\"id\":2614,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-2\",\"class\":\"jspsych-survey-multi-choice-question jspsych-survey-multi-choice-horizontal\"},\"previousSibling\":{\"id\":2613},\"parentNode\":{\"id\":2610}},{\"nodeType\":1,\"id\":2615,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-3\",\"class\":\"jspsych-survey-multi-choice-question jspsych-survey-multi-choice-horizontal\"},\"previousSibling\":{\"id\":2614},\"parentNode\":{\"id\":2610}},{\"nodeType\":1,\"id\":2616,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"submit\",\"id\":\"jspsych-survey-multi-choice-next\",\"class\":\"jspsych-survey-multi-choice jspsych-btn\",\"value\":\"Submit Answers\"},\"previousSibling\":{\"id\":2615},\"parentNode\":{\"id\":2610}},{\"nodeType\":1,\"id\":2617,\"tagName\":\"P\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text survey-multi-choice\"},\"parentNode\":{\"id\":2612}},{\"nodeType\":1,\"id\":2618,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-0-0\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2617},\"parentNode\":{\"id\":2612}},{\"nodeType\":1,\"id\":2619,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-0-1\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2618},\"parentNode\":{\"id\":2612}},{\"nodeType\":1,\"id\":2620,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-0-2\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2619},\"parentNode\":{\"id\":2612}},{\"nodeType\":1,\"id\":2621,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-0-3\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2620},\"parentNode\":{\"id\":2612}},{\"nodeType\":3,\"id\":2622,\"textContent\":\"What is your first language?\",\"parentNode\":{\"id\":2617}},{\"nodeType\":1,\"id\":2623,\"tagName\":\"SPAN\",\"attributes\":{\"class\":\"required\"},\"previousSibling\":{\"id\":2622},\"parentNode\":{\"id\":2617}},{\"nodeType\":1,\"id\":2624,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2618}},{\"nodeType\":1,\"id\":2625,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-0\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2624}},{\"nodeType\":3,\"id\":2626,\"textContent\":\"English\",\"previousSibling\":{\"id\":2625},\"parentNode\":{\"id\":2624}},{\"nodeType\":1,\"id\":2627,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2619}},{\"nodeType\":1,\"id\":2628,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-0\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2627}},{\"nodeType\":3,\"id\":2629,\"textContent\":\"Spanish\",\"previousSibling\":{\"id\":2628},\"parentNode\":{\"id\":2627}},{\"nodeType\":1,\"id\":2630,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2620}},{\"nodeType\":1,\"id\":2631,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-0\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2630}},{\"nodeType\":3,\"id\":2632,\"textContent\":\"Mandarin or Cantonese\",\"previousSibling\":{\"id\":2631},\"parentNode\":{\"id\":2630}},{\"nodeType\":1,\"id\":2633,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2621}},{\"nodeType\":1,\"id\":2634,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-0\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2633}},{\"nodeType\":3,\"id\":2635,\"textContent\":\"Other\",\"previousSibling\":{\"id\":2634},\"parentNode\":{\"id\":2633}},{\"nodeType\":3,\"id\":2636,\"textContent\":\"*\",\"parentNode\":{\"id\":2623}},{\"nodeType\":1,\"id\":2637,\"tagName\":\"P\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text survey-multi-choice\"},\"parentNode\":{\"id\":2613}},{\"nodeType\":1,\"id\":2638,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-1-0\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2637},\"parentNode\":{\"id\":2613}},{\"nodeType\":1,\"id\":2639,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-1-1\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2638},\"parentNode\":{\"id\":2613}},{\"nodeType\":1,\"id\":2640,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-1-2\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2639},\"parentNode\":{\"id\":2613}},{\"nodeType\":1,\"id\":2641,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-1-3\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2640},\"parentNode\":{\"id\":2613}},{\"nodeType\":1,\"id\":2642,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-1-4\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2641},\"parentNode\":{\"id\":2613}},{\"nodeType\":1,\"id\":2643,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-1-5\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2642},\"parentNode\":{\"id\":2613}},{\"nodeType\":1,\"id\":2644,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-1-6\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2643},\"parentNode\":{\"id\":2613}},{\"nodeType\":3,\"id\":2645,\"textContent\":\"What is your year in school?\",\"parentNode\":{\"id\":2637}},{\"nodeType\":1,\"id\":2646,\"tagName\":\"SPAN\",\"attributes\":{\"class\":\"required\"},\"previousSibling\":{\"id\":2645},\"parentNode\":{\"id\":2637}},{\"nodeType\":1,\"id\":2647,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2638}},{\"nodeType\":1,\"id\":2648,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-1\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2647}},{\"nodeType\":3,\"id\":2649,\"textContent\":\"First\",\"previousSibling\":{\"id\":2648},\"parentNode\":{\"id\":2647}},{\"nodeType\":1,\"id\":2650,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2639}},{\"nodeType\":1,\"id\":2651,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-1\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2650}},{\"nodeType\":3,\"id\":2652,\"textContent\":\"Second\",\"previousSibling\":{\"id\":2651},\"parentNode\":{\"id\":2650}},{\"nodeType\":1,\"id\":2653,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2640}},{\"nodeType\":1,\"id\":2654,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-1\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2653}},{\"nodeType\":3,\"id\":2655,\"textContent\":\"Third\",\"previousSibling\":{\"id\":2654},\"parentNode\":{\"id\":2653}},{\"nodeType\":1,\"id\":2656,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2641}},{\"nodeType\":1,\"id\":2657,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-1\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2656}},{\"nodeType\":3,\"id\":2658,\"textContent\":\"Fourth\",\"previousSibling\":{\"id\":2657},\"parentNode\":{\"id\":2656}},{\"nodeType\":1,\"id\":2659,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2642}},{\"nodeType\":1,\"id\":2660,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-1\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2659}},{\"nodeType\":3,\"id\":2661,\"textContent\":\"Fifth\",\"previousSibling\":{\"id\":2660},\"parentNode\":{\"id\":2659}},{\"nodeType\":1,\"id\":2662,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2643}},{\"nodeType\":1,\"id\":2663,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-1\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2662}},{\"nodeType\":3,\"id\":2664,\"textContent\":\"Graduate\",\"previousSibling\":{\"id\":2663},\"parentNode\":{\"id\":2662}},{\"nodeType\":1,\"id\":2665,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2644}},{\"nodeType\":1,\"id\":2666,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-1\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2665}},{\"nodeType\":3,\"id\":2667,\"textContent\":\"Other\",\"previousSibling\":{\"id\":2666},\"parentNode\":{\"id\":2665}},{\"nodeType\":3,\"id\":2668,\"textContent\":\"*\",\"parentNode\":{\"id\":2646}},{\"nodeType\":1,\"id\":2669,\"tagName\":\"P\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text survey-multi-choice\"},\"parentNode\":{\"id\":2614}},{\"nodeType\":1,\"id\":2670,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-2-0\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2669},\"parentNode\":{\"id\":2614}},{\"nodeType\":1,\"id\":2671,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-2-1\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2670},\"parentNode\":{\"id\":2614}},{\"nodeType\":1,\"id\":2672,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-2-2\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2671},\"parentNode\":{\"id\":2614}},{\"nodeType\":1,\"id\":2673,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-2-3\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2672},\"parentNode\":{\"id\":2614}},{\"nodeType\":1,\"id\":2674,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-2-4\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2673},\"parentNode\":{\"id\":2614}},{\"nodeType\":1,\"id\":2675,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-2-5\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2674},\"parentNode\":{\"id\":2614}},{\"nodeType\":1,\"id\":2676,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-2-6\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2675},\"parentNode\":{\"id\":2614}},{\"nodeType\":3,\"id\":2677,\"textContent\":\"What is your major area of study?\",\"parentNode\":{\"id\":2669}},{\"nodeType\":1,\"id\":2678,\"tagName\":\"SPAN\",\"attributes\":{\"class\":\"required\"},\"previousSibling\":{\"id\":2677},\"parentNode\":{\"id\":2669}},{\"nodeType\":1,\"id\":2679,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2670}},{\"nodeType\":1,\"id\":2680,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-2\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2679}},{\"nodeType\":3,\"id\":2681,\"textContent\":\"Math or Computer Sciences\",\"previousSibling\":{\"id\":2680},\"parentNode\":{\"id\":2679}},{\"nodeType\":1,\"id\":2682,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2671}},{\"nodeType\":1,\"id\":2683,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-2\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2682}},{\"nodeType\":3,\"id\":2684,\"textContent\":\"Social Sciences (incl. CogSci)\",\"previousSibling\":{\"id\":2683},\"parentNode\":{\"id\":2682}},{\"nodeType\":1,\"id\":2685,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2672}},{\"nodeType\":1,\"id\":2686,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-2\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2685}},{\"nodeType\":3,\"id\":2687,\"textContent\":\"Biomedical & Health Sciences\",\"previousSibling\":{\"id\":2686},\"parentNode\":{\"id\":2685}},{\"nodeType\":1,\"id\":2688,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2673}},{\"nodeType\":1,\"id\":2689,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-2\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2688}},{\"nodeType\":3,\"id\":2690,\"textContent\":\"Natural Sciences\",\"previousSibling\":{\"id\":2689},\"parentNode\":{\"id\":2688}},{\"nodeType\":1,\"id\":2691,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2674}},{\"nodeType\":1,\"id\":2692,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-2\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2691}},{\"nodeType\":3,\"id\":2693,\"textContent\":\"Engineering\",\"previousSibling\":{\"id\":2692},\"parentNode\":{\"id\":2691}},{\"nodeType\":1,\"id\":2694,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2675}},{\"nodeType\":1,\"id\":2695,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-2\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2694}},{\"nodeType\":3,\"id\":2696,\"textContent\":\"Humanities\",\"previousSibling\":{\"id\":2695},\"parentNode\":{\"id\":2694}},{\"nodeType\":1,\"id\":2697,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2676}},{\"nodeType\":1,\"id\":2698,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-2\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2697}},{\"nodeType\":3,\"id\":2699,\"textContent\":\"Fine Arts\",\"previousSibling\":{\"id\":2698},\"parentNode\":{\"id\":2697}},{\"nodeType\":3,\"id\":2700,\"textContent\":\"*\",\"parentNode\":{\"id\":2678}},{\"nodeType\":1,\"id\":2701,\"tagName\":\"P\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text survey-multi-choice\"},\"parentNode\":{\"id\":2615}},{\"nodeType\":1,\"id\":2702,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-3-0\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2701},\"parentNode\":{\"id\":2615}},{\"nodeType\":1,\"id\":2703,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-3-1\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2702},\"parentNode\":{\"id\":2615}},{\"nodeType\":1,\"id\":2704,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-3-2\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2703},\"parentNode\":{\"id\":2615}},{\"nodeType\":3,\"id\":2705,\"textContent\":\"What is your gender?\",\"parentNode\":{\"id\":2701}},{\"nodeType\":1,\"id\":2706,\"tagName\":\"SPAN\",\"attributes\":{\"class\":\"required\"},\"previousSibling\":{\"id\":2705},\"parentNode\":{\"id\":2701}},{\"nodeType\":1,\"id\":2707,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2702}},{\"nodeType\":1,\"id\":2708,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-3\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2707}},{\"nodeType\":3,\"id\":2709,\"textContent\":\"Male\",\"previousSibling\":{\"id\":2708},\"parentNode\":{\"id\":2707}},{\"nodeType\":1,\"id\":2710,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2703}},{\"nodeType\":1,\"id\":2711,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-3\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2710}},{\"nodeType\":3,\"id\":2712,\"textContent\":\"Female\",\"previousSibling\":{\"id\":2711},\"parentNode\":{\"id\":2710}},{\"nodeType\":1,\"id\":2713,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2704}},{\"nodeType\":1,\"id\":2714,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-3\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2713}},{\"nodeType\":3,\"id\":2715,\"textContent\":\"Other\",\"previousSibling\":{\"id\":2714},\"parentNode\":{\"id\":2713}},{\"nodeType\":3,\"id\":2716,\"textContent\":\"*\",\"parentNode\":{\"id\":2706}}],[],[]]}"
    },
    {
      "sequence": 7,
      "data": "{\"f\":\"applyChanged\",\"args\":[[{\"id\":2610},{\"id\":2611},{\"id\":2612},{\"id\":2617},{\"id\":2622},{\"id\":2623},{\"id\":2636},{\"id\":2618},{\"id\":2624},{\"id\":2625},{\"id\":2626},{\"id\":2619},{\"id\":2627},{\"id\":2628},{\"id\":2629},{\"id\":2620},{\"id\":2630},{\"id\":2631},{\"id\":2632},{\"id\":2621},{\"id\":2633},{\"id\":2634},{\"id\":2635},{\"id\":2613},{\"id\":2637},{\"id\":2645},{\"id\":2646},{\"id\":2668},{\"id\":2638},{\"id\":2647},{\"id\":2648},{\"id\":2649},{\"id\":2639},{\"id\":2650},{\"id\":2651},{\"id\":2652},{\"id\":2640},{\"id\":2653},{\"id\":2654},{\"id\":2655},{\"id\":2641},{\"id\":2656},{\"id\":2657},{\"id\":2658},{\"id\":2642},{\"id\":2659},{\"id\":2660},{\"id\":2661},{\"id\":2643},{\"id\":2662},{\"id\":2663},{\"id\":2664},{\"id\":2644},{\"id\":2665},{\"id\":2666},{\"id\":2667},{\"id\":2614},{\"id\":2669},{\"id\":2677},{\"id\":2678},{\"id\":2700},{\"id\":2670},{\"id\":2679},{\"id\":2680},{\"id\":2681},{\"id\":2671},{\"id\":2682},{\"id\":2683},{\"id\":2684},{\"id\":2672},{\"id\":2685},{\"id\":2686},{\"id\":2687},{\"id\":2673},{\"id\":2688},{\"id\":2689},{\"id\":2690},{\"id\":2674},{\"id\":2691},{\"id\":2692},{\"id\":2693},{\"id\":2675},{\"id\":2694},{\"id\":2695},{\"id\":2696},{\"id\":2676},{\"id\":2697},{\"id\":2698},{\"id\":2699},{\"id\":2615},{\"id\":2701},{\"id\":2705},{\"id\":2706},{\"id\":2716},{\"id\":2702},{\"id\":2707},{\"id\":2708},{\"id\":2709},{\"id\":2703},{\"id\":2710},{\"id\":2711},{\"id\":2712},{\"id\":2704},{\"id\":2713},{\"id\":2714},{\"id\":2715},{\"id\":2616}],[],[],[]]}"
    },
    {
      "sequence": 8,
      "data": "{\"f\":\"applyChanged\",\"args\":[[],[{\"nodeType\":1,\"id\":2717,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"masterdiv\"},\"parentNode\":{\"id\":56}},{\"nodeType\":3,\"id\":2718,\"textContent\":\" \",\"previousSibling\":{\"id\":2717},\"parentNode\":{\"id\":56}},{\"nodeType\":3,\"id\":2719,\"textContent\":\" \",\"parentNode\":{\"id\":2717}},{\"nodeType\":1,\"id\":2720,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"top\"},\"previousSibling\":{\"id\":2719},\"parentNode\":{\"id\":2717}},{\"nodeType\":3,\"id\":2721,\"textContent\":\" \",\"previousSibling\":{\"id\":2720},\"parentNode\":{\"id\":2717}},{\"nodeType\":1,\"id\":2722,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"instructions\"},\"previousSibling\":{\"id\":2721},\"parentNode\":{\"id\":2717}},{\"nodeType\":3,\"id\":2723,\"textContent\":\" \",\"previousSibling\":{\"id\":2722},\"parentNode\":{\"id\":2717}},{\"nodeType\":1,\"id\":2724,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bottom\"},\"previousSibling\":{\"id\":2723},\"parentNode\":{\"id\":2717}},{\"nodeType\":3,\"id\":2725,\"textContent\":\" \",\"previousSibling\":{\"id\":2724},\"parentNode\":{\"id\":2717}},{\"nodeType\":3,\"id\":2726,\"textContent\":\" \",\"parentNode\":{\"id\":2720}},{\"nodeType\":1,\"id\":2727,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bcent\"},\"previousSibling\":{\"id\":2726},\"parentNode\":{\"id\":2720}},{\"nodeType\":3,\"id\":2728,\"textContent\":\" \",\"previousSibling\":{\"id\":2727},\"parentNode\":{\"id\":2720}},{\"nodeType\":3,\"id\":2729,\"textContent\":\" \",\"parentNode\":{\"id\":2727}},{\"nodeType\":1,\"id\":2730,\"tagName\":\"H3\",\"attributes\":{},\"previousSibling\":{\"id\":2729},\"parentNode\":{\"id\":2727}},{\"nodeType\":3,\"id\":2731,\"textContent\":\" \",\"previousSibling\":{\"id\":2730},\"parentNode\":{\"id\":2727}},{\"nodeType\":3,\"id\":2732,\"textContent\":\"DEBRIEFING\",\"parentNode\":{\"id\":2730}},{\"nodeType\":3,\"id\":2733,\"textContent\":\" \",\"parentNode\":{\"id\":2722}},{\"nodeType\":1,\"id\":2734,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"vcent\"},\"previousSibling\":{\"id\":2733},\"parentNode\":{\"id\":2722}},{\"nodeType\":3,\"id\":2735,\"textContent\":\" \",\"previousSibling\":{\"id\":2734},\"parentNode\":{\"id\":2722}},{\"nodeType\":3,\"id\":2736,\"textContent\":\" \",\"parentNode\":{\"id\":2734}},{\"nodeType\":1,\"id\":2737,\"tagName\":\"P\",\"attributes\":{\"style\":\"font-style:italic\"},\"previousSibling\":{\"id\":2736},\"parentNode\":{\"id\":2734}},{\"nodeType\":1,\"id\":2738,\"tagName\":\"P\",\"attributes\":{},\"previousSibling\":{\"id\":2737},\"parentNode\":{\"id\":2734}},{\"nodeType\":3,\"id\":2739,\"textContent\":\" \",\"previousSibling\":{\"id\":2738},\"parentNode\":{\"id\":2734}},{\"nodeType\":1,\"id\":2740,\"tagName\":\"P\",\"attributes\":{},\"previousSibling\":{\"id\":2739},\"parentNode\":{\"id\":2734}},{\"nodeType\":3,\"id\":2741,\"textContent\":\" \",\"previousSibling\":{\"id\":2740},\"parentNode\":{\"id\":2734}},{\"nodeType\":1,\"id\":2742,\"tagName\":\"P\",\"attributes\":{},\"previousSibling\":{\"id\":2741},\"parentNode\":{\"id\":2734}},{\"nodeType\":3,\"id\":2743,\"textContent\":\" \",\"previousSibling\":{\"id\":2742},\"parentNode\":{\"id\":2734}},{\"nodeType\":1,\"id\":2744,\"tagName\":\"P\",\"attributes\":{\"style\":\"font-style:bold;\"},\"previousSibling\":{\"id\":2743},\"parentNode\":{\"id\":2734}},{\"nodeType\":3,\"id\":2745,\"textContent\":\" \",\"previousSibling\":{\"id\":2744},\"parentNode\":{\"id\":2734}},{\"nodeType\":1,\"id\":2746,\"tagName\":\"P\",\"attributes\":{\"style\":\"font-style:italic;\"},\"previousSibling\":{\"id\":2745},\"parentNode\":{\"id\":2734}},{\"nodeType\":3,\"id\":2747,\"textContent\":\" \",\"previousSibling\":{\"id\":2746},\"parentNode\":{\"id\":2734}},{\"nodeType\":3,\"id\":2748,\"textContent\":\"Thank you very much for your participation! This debriefing will tell you more about the study, what you did, and why. \",\"parentNode\":{\"id\":2737}},{\"nodeType\":3,\"id\":2749,\"textContent\":\" \",\"parentNode\":{\"id\":2738}},{\"nodeType\":1,\"id\":2750,\"tagName\":\"B\",\"attributes\":{},\"previousSibling\":{\"id\":2749},\"parentNode\":{\"id\":2738}},{\"nodeType\":3,\"id\":2751,\"textContent\":\" You have just used a series of pictures (charts, graphs and diagrams) accompanied by different types of instructions to answer a series of problem solving questions. While you were using the pictures, we measured where you clicked, scrolled and pointed with the computer mouse. We also measured the accuracy of your responses and the time it took to complete each question.\",\"previousSibling\":{\"id\":2750},\"parentNode\":{\"id\":2738}},{\"nodeType\":3,\"id\":2752,\"textContent\":\"What did you just do?\",\"parentNode\":{\"id\":2750}},{\"nodeType\":3,\"id\":2753,\"textContent\":\" \",\"parentNode\":{\"id\":2740}},{\"nodeType\":1,\"id\":2754,\"tagName\":\"B\",\"attributes\":{},\"previousSibling\":{\"id\":2753},\"parentNode\":{\"id\":2740}},{\"nodeType\":3,\"id\":2755,\"textContent\":\" Researchers of learning and cognition have long been interested in how graphic displays of information can be used to communicate, solve problems, and generate insights. As powerful as graphics may be in their communicative efficiency, they're not always immediately intuitive to understand. In short, we know a great deal more about learning with representations than we do about the learning of representations. In this project we are building upon previous research on reading and graph comprehension to explore how readers make sense of unfamiliar representations. The instructions you saw for each type of graph are known as “scaffolding techniques”, and we will compare your performance with the scaffolding techniques you saw with the performance of other participants to determine which types of instructions are most effective in helping humans to make sense of unfamiliar graphs. \",\"previousSibling\":{\"id\":2754},\"parentNode\":{\"id\":2740}},{\"nodeType\":3,\"id\":2756,\"textContent\":\"Why did we have you do it?\",\"parentNode\":{\"id\":2754}},{\"nodeType\":1,\"id\":2757,\"tagName\":\"B\",\"attributes\":{},\"parentNode\":{\"id\":2742}},{\"nodeType\":3,\"id\":2758,\"textContent\":\" We expect that you will have found some of the graphics more difficult to use than others. We also expect that with the assistance of the instructions, after solving several problems you will learn to use the difficult graphics so that you can answer the questions even more quickly than without. If you would like to receive a copy of the results of the study, or have any further questions, please contact the researchers Primary Researcher: Amy Fox : a2fox@ucsd.edu Faculty Advisor : Dr. Jim Hollan : hollan@ucsd.edu \",\"previousSibling\":{\"id\":2757},\"parentNode\":{\"id\":2742}},{\"nodeType\":3,\"id\":2759,\"textContent\":\"What do we expect to find?\",\"parentNode\":{\"id\":2757}},{\"nodeType\":3,\"id\":2760,\"textContent\":\"It is important that you do not discuss this experiment with other students who might participate after you. They must participate in the same way as you did, without any knowledge of what the experiment entails, or the reasoning behind it.\",\"parentNode\":{\"id\":2744}},{\"nodeType\":3,\"id\":2761,\"textContent\":\"Thank you for your time! We hope you enjoyed participating in this study as much as we enjoyed designing it.\",\"parentNode\":{\"id\":2746}},{\"nodeType\":3,\"id\":2762,\"textContent\":\" \",\"parentNode\":{\"id\":2724}},{\"nodeType\":1,\"id\":2763,\"tagName\":\"BUTTON\",\"attributes\":{\"class\":\"btn\",\"type\":\"button\",\"id\":\"start\"},\"previousSibling\":{\"id\":2762},\"parentNode\":{\"id\":2724}},{\"nodeType\":3,\"id\":2764,\"textContent\":\" \",\"previousSibling\":{\"id\":2763},\"parentNode\":{\"id\":2724}},{\"nodeType\":3,\"id\":2765,\"textContent\":\"FINISH\",\"parentNode\":{\"id\":2763}}],[],[]]}"
    },
    {
      "sequence": 9,
      "data": "{\"f\":\"applyChanged\",\"args\":[[{\"id\":2717},{\"id\":2719},{\"id\":2720},{\"id\":2726},{\"id\":2727},{\"id\":2729},{\"id\":2730},{\"id\":2732},{\"id\":2731},{\"id\":2728},{\"id\":2721},{\"id\":2722},{\"id\":2733},{\"id\":2734},{\"id\":2736},{\"id\":2737},{\"id\":2748},{\"id\":2738},{\"id\":2749},{\"id\":2750},{\"id\":2752},{\"id\":2751},{\"id\":2739},{\"id\":2740},{\"id\":2753},{\"id\":2754},{\"id\":2756},{\"id\":2755},{\"id\":2741},{\"id\":2742},{\"id\":2757},{\"id\":2759},{\"id\":2758},{\"id\":2743},{\"id\":2744},{\"id\":2760},{\"id\":2745},{\"id\":2746},{\"id\":2761},{\"id\":2747},{\"id\":2735},{\"id\":2723},{\"id\":2724},{\"id\":2762},{\"id\":2763},{\"id\":2765},{\"id\":2764},{\"id\":2725},{\"id\":2718}],[],[],[]]}"
    },
    {
      "sequence": 10,
      "data": "{\"f\":\"applyChanged\",\"args\":[[],[{\"nodeType\":1,\"id\":2766,\"tagName\":\"PRE\",\"attributes\":{\"id\":\"jspsych-data-display\"},\"parentNode\":{\"id\":56}},{\"nodeType\":3,\"id\":2767,\"textContent\":\"[ { \\\"rt\\\": 8364, \\\"stimulus\\\": \\\"img/phone.png\\\", \\\"key_press\\\": 13, \\\"block\\\": \\\"phone\\\", \\\"trial_type\\\": \\\"single-stim\\\", \\\"trial_index\\\": 0, \\\"time_elapsed\\\": 8366, \\\"internal_node_id\\\": \\\"0.0-0.0\\\", \\\"subject\\\": \\\"YC7SX\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"mike\\\", \\\"condition\\\": \\\"115-late\\\" }, { \\\"rt\\\": 7969, \\\"url\\\": \\\"../views/src/external/consent.html\\\", \\\"block\\\": \\\"consent\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 1, \\\"time_elapsed\\\": 17422, \\\"internal_node_id\\\": \\\"0.0-1.0\\\", \\\"subject\\\": \\\"YC7SX\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"mike\\\", \\\"condition\\\": \\\"115-late\\\" }, { \\\"rt\\\": 20018, \\\"responses\\\": \\\"{\\\\\\\"Q0\\\\\\\":\\\\\\\"MIKE\\\\\\\",\\\\\\\"Q1\\\\\\\":\\\\\\\"115-late\\\\\\\"}\\\", \\\"block\\\": \\\"codes\\\", \\\"trial_type\\\": \\\"survey-text\\\", \\\"trial_index\\\": 2, \\\"time_elapsed\\\": 38450, \\\"internal_node_id\\\": \\\"0.0-2.0\\\", \\\"subject\\\": \\\"YC7SX\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"mike\\\", \\\"condition\\\": \\\"115-late\\\" }, { \\\"rt\\\": 16686, \\\"url\\\": \\\"../views/src/external/instructions_lab.html\\\", \\\"block\\\": \\\"instructions_lab\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 3, \\\"time_elapsed\\\": 56225, \\\"internal_node_id\\\": \\\"0.0-3.0\\\", \\\"subject\\\": \\\"YC7SX\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"mike\\\", \\\"condition\\\": \\\"115-late\\\" }, { \\\"rt\\\": 12560, \\\"stimulus\\\": \\\"img/acme.png\\\", \\\"key_press\\\": 13, \\\"block\\\": \\\"scenario\\\", \\\"trial_type\\\": \\\"single-stim\\\", \\\"trial_index\\\": 4, \\\"time_elapsed\\\": 69787, \\\"internal_node_id\\\": \\\"0.0-4.0\\\", \\\"subject\\\": \\\"YC7SX\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"mike\\\", \\\"condition\\\": \\\"115-late\\\" }, { \\\"rt\\\": 19923, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 5, \\\"time_elapsed\\\": 90999, \\\"internal_node_id\\\": \\\"0.0-5.0-0.0\\\", \\\"subject\\\": \\\"YC7SX\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"mike\\\", \\\"condition\\\": \\\"115-late\\\", \\\"scenario\\\": \\\"acme\\\", \\\"question\\\": \\\"starttime\\\", \\\"q\\\": 1, \\\"clicks\\\": 1, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XFull-YFull\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 1, \\\"answer\\\": [ \\\"A\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"X \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"U \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-5-11 AM-A \\\", \\\"block\\\": \\\"triangular_scaffolded\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:1048,y:617,t:1527268538781};\\\", \\\"{x:1048,y:613,t:1527268538790};\\\", \\\"{x:1048,y:609,t:1527268538800};\\\", \\\"{x:1049,y:602,t:1527268538817};\\\", \\\"{x:1051,y:595,t:1527268538834};\\\", \\\"{x:1052,y:589,t:1527268538850};\\\", \\\"{x:1052,y:585,t:1527268538867};\\\", \\\"{x:1053,y:581,t:1527268538884};\\\", \\\"{x:1053,y:577,t:1527268538900};\\\", \\\"{x:1056,y:569,t:1527268538917};\\\", \\\"{x:1057,y:564,t:1527268538934};\\\", \\\"{x:1060,y:558,t:1527268538951};\\\", \\\"{x:1061,y:549,t:1527268538968};\\\", \\\"{x:1061,y:544,t:1527268538984};\\\", \\\"{x:1064,y:540,t:1527268539001};\\\", \\\"{x:1065,y:533,t:1527268539017};\\\", \\\"{x:1065,y:528,t:1527268539035};\\\", \\\"{x:1067,y:519,t:1527268539051};\\\", \\\"{x:1067,y:511,t:1527268539069};\\\", \\\"{x:1067,y:500,t:1527268539085};\\\", \\\"{x:1067,y:491,t:1527268539101};\\\", \\\"{x:1067,y:482,t:1527268539118};\\\", \\\"{x:1067,y:474,t:1527268539134};\\\", \\\"{x:1068,y:469,t:1527268539151};\\\", \\\"{x:1069,y:463,t:1527268539168};\\\", \\\"{x:1069,y:458,t:1527268539185};\\\", \\\"{x:1069,y:455,t:1527268539201};\\\", \\\"{x:1069,y:452,t:1527268539218};\\\", \\\"{x:1069,y:451,t:1527268539234};\\\", \\\"{x:1069,y:450,t:1527268539250};\\\", \\\"{x:1070,y:449,t:1527268539268};\\\", \\\"{x:1073,y:452,t:1527268539647};\\\", \\\"{x:1080,y:460,t:1527268539654};\\\", \\\"{x:1087,y:468,t:1527268539668};\\\", \\\"{x:1100,y:482,t:1527268539685};\\\", \\\"{x:1120,y:500,t:1527268539702};\\\", \\\"{x:1134,y:509,t:1527268539718};\\\", \\\"{x:1143,y:518,t:1527268539735};\\\", \\\"{x:1152,y:525,t:1527268539752};\\\", \\\"{x:1156,y:531,t:1527268539769};\\\", \\\"{x:1160,y:538,t:1527268539785};\\\", \\\"{x:1162,y:544,t:1527268539802};\\\", \\\"{x:1165,y:551,t:1527268539819};\\\", \\\"{x:1168,y:561,t:1527268539835};\\\", \\\"{x:1172,y:571,t:1527268539852};\\\", \\\"{x:1176,y:585,t:1527268539869};\\\", \\\"{x:1178,y:593,t:1527268539885};\\\", \\\"{x:1185,y:606,t:1527268539903};\\\", \\\"{x:1187,y:613,t:1527268539918};\\\", \\\"{x:1191,y:621,t:1527268539935};\\\", \\\"{x:1194,y:629,t:1527268539952};\\\", \\\"{x:1198,y:637,t:1527268539969};\\\", \\\"{x:1200,y:642,t:1527268539985};\\\", \\\"{x:1203,y:650,t:1527268540002};\\\", \\\"{x:1207,y:657,t:1527268540022};\\\", \\\"{x:1208,y:663,t:1527268540034};\\\", \\\"{x:1212,y:671,t:1527268540051};\\\", \\\"{x:1216,y:678,t:1527268540068};\\\", \\\"{x:1222,y:689,t:1527268540084};\\\", \\\"{x:1231,y:704,t:1527268540101};\\\", \\\"{x:1236,y:713,t:1527268540118};\\\", \\\"{x:1237,y:718,t:1527268540135};\\\", \\\"{x:1240,y:726,t:1527268540151};\\\", \\\"{x:1241,y:737,t:1527268540169};\\\", \\\"{x:1242,y:748,t:1527268540184};\\\", \\\"{x:1242,y:758,t:1527268540202};\\\", \\\"{x:1242,y:773,t:1527268540219};\\\", \\\"{x:1242,y:791,t:1527268540235};\\\", \\\"{x:1239,y:806,t:1527268540251};\\\", \\\"{x:1235,y:818,t:1527268540268};\\\", \\\"{x:1233,y:826,t:1527268540285};\\\", \\\"{x:1233,y:827,t:1527268540301};\\\", \\\"{x:1233,y:829,t:1527268540325};\\\", \\\"{x:1233,y:830,t:1527268540335};\\\", \\\"{x:1233,y:833,t:1527268540351};\\\", \\\"{x:1233,y:842,t:1527268540368};\\\", \\\"{x:1236,y:862,t:1527268540386};\\\", \\\"{x:1247,y:885,t:1527268540401};\\\", \\\"{x:1258,y:903,t:1527268540418};\\\", \\\"{x:1265,y:911,t:1527268540436};\\\", \\\"{x:1269,y:917,t:1527268540451};\\\", \\\"{x:1273,y:922,t:1527268540468};\\\", \\\"{x:1274,y:924,t:1527268540486};\\\", \\\"{x:1275,y:923,t:1527268540663};\\\", \\\"{x:1275,y:921,t:1527268540671};\\\", \\\"{x:1276,y:919,t:1527268540686};\\\", \\\"{x:1276,y:916,t:1527268540702};\\\", \\\"{x:1279,y:912,t:1527268540719};\\\", \\\"{x:1280,y:906,t:1527268540735};\\\", \\\"{x:1282,y:901,t:1527268540752};\\\", \\\"{x:1284,y:892,t:1527268540769};\\\", \\\"{x:1287,y:882,t:1527268540785};\\\", \\\"{x:1290,y:874,t:1527268540803};\\\", \\\"{x:1292,y:865,t:1527268540818};\\\", \\\"{x:1293,y:859,t:1527268540836};\\\", \\\"{x:1295,y:850,t:1527268540853};\\\", \\\"{x:1296,y:846,t:1527268540869};\\\", \\\"{x:1296,y:837,t:1527268540886};\\\", \\\"{x:1297,y:834,t:1527268540903};\\\", \\\"{x:1297,y:830,t:1527268540919};\\\", \\\"{x:1299,y:827,t:1527268540936};\\\", \\\"{x:1299,y:823,t:1527268540953};\\\", \\\"{x:1300,y:819,t:1527268540968};\\\", \\\"{x:1300,y:815,t:1527268540986};\\\", \\\"{x:1300,y:810,t:1527268541004};\\\", \\\"{x:1300,y:805,t:1527268541019};\\\", \\\"{x:1300,y:800,t:1527268541036};\\\", \\\"{x:1300,y:795,t:1527268541053};\\\", \\\"{x:1300,y:791,t:1527268541069};\\\", \\\"{x:1300,y:783,t:1527268541086};\\\", \\\"{x:1300,y:776,t:1527268541102};\\\", \\\"{x:1300,y:773,t:1527268541119};\\\", \\\"{x:1300,y:769,t:1527268541136};\\\", \\\"{x:1300,y:767,t:1527268541153};\\\", \\\"{x:1300,y:765,t:1527268541169};\\\", \\\"{x:1299,y:764,t:1527268541186};\\\", \\\"{x:1299,y:763,t:1527268541203};\\\", \\\"{x:1299,y:761,t:1527268541220};\\\", \\\"{x:1299,y:759,t:1527268541238};\\\", \\\"{x:1298,y:759,t:1527268541253};\\\", \\\"{x:1297,y:759,t:1527268541350};\\\", \\\"{x:1297,y:758,t:1527268541358};\\\", \\\"{x:1296,y:758,t:1527268541374};\\\", \\\"{x:1295,y:758,t:1527268541385};\\\", \\\"{x:1293,y:758,t:1527268541402};\\\", \\\"{x:1291,y:758,t:1527268541420};\\\", \\\"{x:1290,y:758,t:1527268541436};\\\", \\\"{x:1288,y:758,t:1527268541453};\\\", \\\"{x:1286,y:758,t:1527268541470};\\\", \\\"{x:1285,y:758,t:1527268541486};\\\", \\\"{x:1284,y:758,t:1527268541502};\\\", \\\"{x:1283,y:759,t:1527268541614};\\\", \\\"{x:1282,y:759,t:1527268541622};\\\", \\\"{x:1282,y:760,t:1527268541636};\\\", \\\"{x:1280,y:761,t:1527268541653};\\\", \\\"{x:1271,y:761,t:1527268541670};\\\", \\\"{x:1248,y:761,t:1527268541685};\\\", \\\"{x:1198,y:751,t:1527268541703};\\\", \\\"{x:1119,y:737,t:1527268541720};\\\", \\\"{x:1037,y:718,t:1527268541737};\\\", \\\"{x:942,y:686,t:1527268541753};\\\", \\\"{x:851,y:663,t:1527268541770};\\\", \\\"{x:790,y:646,t:1527268541787};\\\", \\\"{x:729,y:631,t:1527268541802};\\\", \\\"{x:674,y:616,t:1527268541820};\\\", \\\"{x:634,y:607,t:1527268541837};\\\", \\\"{x:610,y:603,t:1527268541853};\\\", \\\"{x:578,y:595,t:1527268541871};\\\", \\\"{x:551,y:587,t:1527268541887};\\\", \\\"{x:521,y:580,t:1527268541902};\\\", \\\"{x:493,y:577,t:1527268541921};\\\", \\\"{x:464,y:571,t:1527268541938};\\\", \\\"{x:419,y:566,t:1527268541954};\\\", \\\"{x:384,y:558,t:1527268541971};\\\", \\\"{x:360,y:550,t:1527268541988};\\\", \\\"{x:353,y:547,t:1527268542005};\\\", \\\"{x:350,y:543,t:1527268542020};\\\", \\\"{x:348,y:539,t:1527268542037};\\\", \\\"{x:348,y:533,t:1527268542054};\\\", \\\"{x:348,y:527,t:1527268542071};\\\", \\\"{x:348,y:520,t:1527268542088};\\\", \\\"{x:349,y:515,t:1527268542104};\\\", \\\"{x:351,y:508,t:1527268542120};\\\", \\\"{x:353,y:503,t:1527268542138};\\\", \\\"{x:358,y:497,t:1527268542154};\\\", \\\"{x:361,y:493,t:1527268542171};\\\", \\\"{x:364,y:489,t:1527268542188};\\\", \\\"{x:367,y:486,t:1527268542205};\\\", \\\"{x:370,y:482,t:1527268542222};\\\", \\\"{x:371,y:480,t:1527268542237};\\\", \\\"{x:373,y:479,t:1527268542254};\\\", \\\"{x:373,y:478,t:1527268542271};\\\", \\\"{x:373,y:477,t:1527268542287};\\\", \\\"{x:374,y:476,t:1527268542310};\\\", \\\"{x:374,y:475,t:1527268542320};\\\", \\\"{x:376,y:474,t:1527268542338};\\\", \\\"{x:378,y:470,t:1527268542354};\\\", \\\"{x:379,y:469,t:1527268542371};\\\", \\\"{x:381,y:467,t:1527268542388};\\\", \\\"{x:382,y:466,t:1527268542404};\\\", \\\"{x:383,y:465,t:1527268542502};\\\", \\\"{x:383,y:465,t:1527268542562};\\\", \\\"{x:383,y:468,t:1527268542831};\\\", \\\"{x:383,y:471,t:1527268542837};\\\", \\\"{x:384,y:477,t:1527268542855};\\\", \\\"{x:385,y:481,t:1527268542873};\\\", \\\"{x:385,y:483,t:1527268542888};\\\", \\\"{x:386,y:484,t:1527268542904};\\\", \\\"{x:386,y:486,t:1527268542922};\\\", \\\"{x:386,y:487,t:1527268542939};\\\", \\\"{x:386,y:488,t:1527268542955};\\\", \\\"{x:386,y:489,t:1527268542971};\\\", \\\"{x:388,y:493,t:1527268542989};\\\", \\\"{x:388,y:496,t:1527268543005};\\\", \\\"{x:389,y:500,t:1527268543021};\\\", \\\"{x:389,y:502,t:1527268543038};\\\", \\\"{x:389,y:505,t:1527268543054};\\\", \\\"{x:390,y:506,t:1527268543071};\\\", \\\"{x:390,y:507,t:1527268543089};\\\", \\\"{x:390,y:508,t:1527268547734};\\\", \\\"{x:390,y:510,t:1527268547742};\\\", \\\"{x:391,y:524,t:1527268547761};\\\", \\\"{x:393,y:533,t:1527268547775};\\\", \\\"{x:397,y:542,t:1527268547791};\\\", \\\"{x:401,y:556,t:1527268547806};\\\", \\\"{x:403,y:565,t:1527268547823};\\\", \\\"{x:407,y:575,t:1527268547842};\\\", \\\"{x:411,y:585,t:1527268547859};\\\", \\\"{x:416,y:596,t:1527268547876};\\\", \\\"{x:417,y:603,t:1527268547892};\\\", \\\"{x:421,y:616,t:1527268547909};\\\", \\\"{x:425,y:629,t:1527268547925};\\\", \\\"{x:428,y:640,t:1527268547941};\\\", \\\"{x:430,y:646,t:1527268547959};\\\", \\\"{x:431,y:648,t:1527268547976};\\\", \\\"{x:432,y:649,t:1527268547991};\\\", \\\"{x:432,y:651,t:1527268548038};\\\", \\\"{x:433,y:651,t:1527268548141};\\\", \\\"{x:436,y:651,t:1527268548159};\\\", \\\"{x:441,y:653,t:1527268548176};\\\", \\\"{x:444,y:653,t:1527268548192};\\\", \\\"{x:448,y:655,t:1527268548210};\\\", \\\"{x:450,y:656,t:1527268548229};\\\", \\\"{x:451,y:656,t:1527268548262};\\\", \\\"{x:453,y:656,t:1527268548277};\\\", \\\"{x:454,y:656,t:1527268548292};\\\", \\\"{x:456,y:656,t:1527268548309};\\\", \\\"{x:457,y:656,t:1527268548325};\\\", \\\"{x:459,y:657,t:1527268548341};\\\", \\\"{x:460,y:657,t:1527268548358};\\\", \\\"{x:460,y:658,t:1527268548381};\\\" ] }, { \\\"rt\\\": 14687, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 6, \\\"time_elapsed\\\": 106993, \\\"internal_node_id\\\": \\\"0.0-5.0-1.0\\\", \\\"subject\\\": \\\"YC7SX\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"mike\\\", \\\"condition\\\": \\\"115-late\\\", \\\"scenario\\\": \\\"acme\\\", \\\"question\\\": \\\"starts\\\", \\\"q\\\": 2, \\\"clicks\\\": 1, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XFull-YFull\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 1, \\\"answer\\\": [ \\\"E\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"X \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"U \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-B \\\", \\\"block\\\": \\\"triangular_scaffolded\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:462,y:658,t:1527268552438};\\\", \\\"{x:464,y:658,t:1527268552449};\\\", \\\"{x:470,y:658,t:1527268552466};\\\", \\\"{x:478,y:657,t:1527268552483};\\\", \\\"{x:482,y:657,t:1527268552500};\\\", \\\"{x:484,y:657,t:1527268552516};\\\", \\\"{x:485,y:657,t:1527268552549};\\\", \\\"{x:486,y:657,t:1527268552567};\\\", \\\"{x:489,y:657,t:1527268552582};\\\", \\\"{x:492,y:657,t:1527268552600};\\\", \\\"{x:497,y:657,t:1527268552617};\\\", \\\"{x:500,y:657,t:1527268552633};\\\", \\\"{x:504,y:657,t:1527268552650};\\\", \\\"{x:508,y:657,t:1527268552667};\\\", \\\"{x:513,y:657,t:1527268552683};\\\", \\\"{x:519,y:657,t:1527268552700};\\\", \\\"{x:526,y:657,t:1527268552718};\\\", \\\"{x:535,y:657,t:1527268552734};\\\", \\\"{x:540,y:657,t:1527268552750};\\\", \\\"{x:546,y:657,t:1527268552768};\\\", \\\"{x:552,y:657,t:1527268552785};\\\", \\\"{x:557,y:657,t:1527268552800};\\\", \\\"{x:565,y:657,t:1527268552818};\\\", \\\"{x:575,y:657,t:1527268552834};\\\", \\\"{x:590,y:657,t:1527268552851};\\\", \\\"{x:606,y:657,t:1527268552863};\\\", \\\"{x:625,y:657,t:1527268552879};\\\", \\\"{x:642,y:657,t:1527268552896};\\\", \\\"{x:661,y:657,t:1527268552913};\\\", \\\"{x:679,y:657,t:1527268552929};\\\", \\\"{x:691,y:657,t:1527268552946};\\\", \\\"{x:702,y:657,t:1527268552962};\\\", \\\"{x:710,y:657,t:1527268552979};\\\", \\\"{x:720,y:657,t:1527268552996};\\\", \\\"{x:737,y:657,t:1527268553013};\\\", \\\"{x:742,y:657,t:1527268553029};\\\", \\\"{x:771,y:657,t:1527268553046};\\\", \\\"{x:797,y:661,t:1527268553063};\\\", \\\"{x:847,y:669,t:1527268553080};\\\", \\\"{x:911,y:677,t:1527268553096};\\\", \\\"{x:989,y:688,t:1527268553114};\\\", \\\"{x:1087,y:704,t:1527268553130};\\\", \\\"{x:1192,y:717,t:1527268553146};\\\", \\\"{x:1292,y:733,t:1527268553164};\\\", \\\"{x:1395,y:751,t:1527268553181};\\\", \\\"{x:1492,y:763,t:1527268553197};\\\", \\\"{x:1605,y:779,t:1527268553214};\\\", \\\"{x:1647,y:779,t:1527268553229};\\\", \\\"{x:1676,y:779,t:1527268553248};\\\", \\\"{x:1699,y:779,t:1527268553264};\\\", \\\"{x:1713,y:779,t:1527268553280};\\\", \\\"{x:1721,y:779,t:1527268553296};\\\", \\\"{x:1725,y:777,t:1527268553313};\\\", \\\"{x:1727,y:776,t:1527268553330};\\\", \\\"{x:1728,y:775,t:1527268553346};\\\", \\\"{x:1728,y:774,t:1527268553365};\\\", \\\"{x:1728,y:773,t:1527268553379};\\\", \\\"{x:1728,y:771,t:1527268553405};\\\", \\\"{x:1729,y:771,t:1527268553428};\\\", \\\"{x:1729,y:770,t:1527268553445};\\\", \\\"{x:1729,y:769,t:1527268553477};\\\", \\\"{x:1729,y:767,t:1527268553501};\\\", \\\"{x:1729,y:766,t:1527268553518};\\\", \\\"{x:1728,y:765,t:1527268553530};\\\", \\\"{x:1725,y:765,t:1527268553547};\\\", \\\"{x:1719,y:761,t:1527268553563};\\\", \\\"{x:1714,y:759,t:1527268553580};\\\", \\\"{x:1711,y:755,t:1527268553596};\\\", \\\"{x:1705,y:749,t:1527268553613};\\\", \\\"{x:1689,y:730,t:1527268553630};\\\", \\\"{x:1683,y:723,t:1527268553647};\\\", \\\"{x:1680,y:720,t:1527268553664};\\\", \\\"{x:1679,y:715,t:1527268553680};\\\", \\\"{x:1678,y:712,t:1527268553697};\\\", \\\"{x:1676,y:706,t:1527268553714};\\\", \\\"{x:1676,y:691,t:1527268553730};\\\", \\\"{x:1676,y:669,t:1527268553748};\\\", \\\"{x:1676,y:639,t:1527268553763};\\\", \\\"{x:1671,y:608,t:1527268553780};\\\", \\\"{x:1666,y:587,t:1527268553797};\\\", \\\"{x:1662,y:566,t:1527268553813};\\\", \\\"{x:1659,y:540,t:1527268553830};\\\", \\\"{x:1659,y:521,t:1527268553848};\\\", \\\"{x:1657,y:504,t:1527268553864};\\\", \\\"{x:1654,y:490,t:1527268553880};\\\", \\\"{x:1650,y:479,t:1527268553897};\\\", \\\"{x:1647,y:469,t:1527268553913};\\\", \\\"{x:1645,y:461,t:1527268553930};\\\", \\\"{x:1639,y:447,t:1527268553947};\\\", \\\"{x:1637,y:438,t:1527268553964};\\\", \\\"{x:1635,y:433,t:1527268553980};\\\", \\\"{x:1634,y:428,t:1527268553997};\\\", \\\"{x:1632,y:421,t:1527268554014};\\\", \\\"{x:1630,y:414,t:1527268554030};\\\", \\\"{x:1627,y:408,t:1527268554048};\\\", \\\"{x:1626,y:406,t:1527268554065};\\\", \\\"{x:1626,y:404,t:1527268554081};\\\", \\\"{x:1626,y:403,t:1527268554097};\\\", \\\"{x:1624,y:401,t:1527268554114};\\\", \\\"{x:1623,y:401,t:1527268554254};\\\", \\\"{x:1618,y:404,t:1527268554264};\\\", \\\"{x:1614,y:420,t:1527268554280};\\\", \\\"{x:1609,y:441,t:1527268554297};\\\", \\\"{x:1603,y:465,t:1527268554315};\\\", \\\"{x:1599,y:482,t:1527268554330};\\\", \\\"{x:1596,y:494,t:1527268554348};\\\", \\\"{x:1593,y:506,t:1527268554364};\\\", \\\"{x:1592,y:512,t:1527268554382};\\\", \\\"{x:1592,y:516,t:1527268554397};\\\", \\\"{x:1591,y:519,t:1527268554414};\\\", \\\"{x:1591,y:522,t:1527268554431};\\\", \\\"{x:1591,y:525,t:1527268554447};\\\", \\\"{x:1591,y:531,t:1527268554464};\\\", \\\"{x:1591,y:536,t:1527268554480};\\\", \\\"{x:1591,y:538,t:1527268554497};\\\", \\\"{x:1591,y:539,t:1527268554514};\\\", \\\"{x:1591,y:540,t:1527268554531};\\\", \\\"{x:1591,y:542,t:1527268554547};\\\", \\\"{x:1592,y:544,t:1527268554564};\\\", \\\"{x:1593,y:545,t:1527268554581};\\\", \\\"{x:1593,y:547,t:1527268554597};\\\", \\\"{x:1593,y:548,t:1527268554614};\\\", \\\"{x:1594,y:548,t:1527268554631};\\\", \\\"{x:1595,y:548,t:1527268554758};\\\", \\\"{x:1596,y:547,t:1527268554766};\\\", \\\"{x:1597,y:543,t:1527268554782};\\\", \\\"{x:1601,y:534,t:1527268554798};\\\", \\\"{x:1603,y:528,t:1527268554814};\\\", \\\"{x:1605,y:525,t:1527268554831};\\\", \\\"{x:1605,y:523,t:1527268554848};\\\", \\\"{x:1605,y:522,t:1527268554865};\\\", \\\"{x:1605,y:520,t:1527268554881};\\\", \\\"{x:1606,y:520,t:1527268554899};\\\", \\\"{x:1602,y:520,t:1527268555349};\\\", \\\"{x:1589,y:520,t:1527268555364};\\\", \\\"{x:1509,y:520,t:1527268555381};\\\", \\\"{x:1425,y:520,t:1527268555398};\\\", \\\"{x:1320,y:520,t:1527268555415};\\\", \\\"{x:1218,y:520,t:1527268555431};\\\", \\\"{x:1118,y:520,t:1527268555448};\\\", \\\"{x:1023,y:520,t:1527268555466};\\\", \\\"{x:954,y:520,t:1527268555481};\\\", \\\"{x:912,y:520,t:1527268555499};\\\", \\\"{x:889,y:520,t:1527268555515};\\\", \\\"{x:874,y:520,t:1527268555531};\\\", \\\"{x:864,y:520,t:1527268555548};\\\", \\\"{x:855,y:520,t:1527268555565};\\\", \\\"{x:837,y:521,t:1527268555581};\\\", \\\"{x:821,y:525,t:1527268555598};\\\", \\\"{x:799,y:527,t:1527268555615};\\\", \\\"{x:773,y:532,t:1527268555631};\\\", \\\"{x:751,y:535,t:1527268555648};\\\", \\\"{x:739,y:536,t:1527268555665};\\\", \\\"{x:730,y:536,t:1527268555681};\\\", \\\"{x:723,y:536,t:1527268555699};\\\", \\\"{x:718,y:536,t:1527268555714};\\\", \\\"{x:709,y:536,t:1527268555731};\\\", \\\"{x:692,y:536,t:1527268555748};\\\", \\\"{x:669,y:536,t:1527268555765};\\\", \\\"{x:624,y:536,t:1527268555782};\\\", \\\"{x:593,y:536,t:1527268555799};\\\", \\\"{x:573,y:536,t:1527268555815};\\\", \\\"{x:554,y:536,t:1527268555831};\\\", \\\"{x:536,y:536,t:1527268555848};\\\", \\\"{x:526,y:536,t:1527268555865};\\\", \\\"{x:521,y:536,t:1527268555881};\\\", \\\"{x:519,y:536,t:1527268555898};\\\", \\\"{x:516,y:536,t:1527268555915};\\\", \\\"{x:512,y:536,t:1527268555931};\\\", \\\"{x:509,y:536,t:1527268555948};\\\", \\\"{x:504,y:536,t:1527268555965};\\\", \\\"{x:501,y:536,t:1527268555982};\\\", \\\"{x:493,y:537,t:1527268556000};\\\", \\\"{x:486,y:538,t:1527268556015};\\\", \\\"{x:476,y:538,t:1527268556031};\\\", \\\"{x:462,y:541,t:1527268556047};\\\", \\\"{x:453,y:542,t:1527268556064};\\\", \\\"{x:448,y:543,t:1527268556081};\\\", \\\"{x:442,y:544,t:1527268556098};\\\", \\\"{x:443,y:544,t:1527268556190};\\\", \\\"{x:450,y:543,t:1527268556197};\\\", \\\"{x:464,y:539,t:1527268556213};\\\", \\\"{x:481,y:538,t:1527268556231};\\\", \\\"{x:502,y:534,t:1527268556248};\\\", \\\"{x:525,y:534,t:1527268556264};\\\", \\\"{x:547,y:534,t:1527268556282};\\\", \\\"{x:563,y:532,t:1527268556299};\\\", \\\"{x:577,y:530,t:1527268556315};\\\", \\\"{x:594,y:530,t:1527268556332};\\\", \\\"{x:632,y:530,t:1527268556349};\\\", \\\"{x:647,y:530,t:1527268556364};\\\", \\\"{x:683,y:530,t:1527268556382};\\\", \\\"{x:704,y:530,t:1527268556399};\\\", \\\"{x:719,y:530,t:1527268556415};\\\", \\\"{x:724,y:530,t:1527268556433};\\\", \\\"{x:723,y:530,t:1527268556494};\\\", \\\"{x:719,y:530,t:1527268556501};\\\", \\\"{x:716,y:531,t:1527268556516};\\\", \\\"{x:710,y:534,t:1527268556532};\\\", \\\"{x:693,y:539,t:1527268556549};\\\", \\\"{x:675,y:542,t:1527268556565};\\\", \\\"{x:652,y:545,t:1527268556581};\\\", \\\"{x:625,y:550,t:1527268556599};\\\", \\\"{x:594,y:555,t:1527268556616};\\\", \\\"{x:560,y:558,t:1527268556632};\\\", \\\"{x:527,y:563,t:1527268556649};\\\", \\\"{x:496,y:567,t:1527268556667};\\\", \\\"{x:468,y:572,t:1527268556682};\\\", \\\"{x:437,y:574,t:1527268556698};\\\", \\\"{x:414,y:576,t:1527268556716};\\\", \\\"{x:396,y:578,t:1527268556732};\\\", \\\"{x:374,y:578,t:1527268556750};\\\", \\\"{x:362,y:578,t:1527268556766};\\\", \\\"{x:352,y:578,t:1527268556782};\\\", \\\"{x:340,y:578,t:1527268556799};\\\", \\\"{x:320,y:578,t:1527268556816};\\\", \\\"{x:293,y:578,t:1527268556832};\\\", \\\"{x:265,y:578,t:1527268556850};\\\", \\\"{x:236,y:578,t:1527268556866};\\\", \\\"{x:214,y:578,t:1527268556882};\\\", \\\"{x:200,y:578,t:1527268556899};\\\", \\\"{x:195,y:578,t:1527268556916};\\\", \\\"{x:193,y:578,t:1527268556932};\\\", \\\"{x:192,y:578,t:1527268557046};\\\", \\\"{x:189,y:578,t:1527268557055};\\\", \\\"{x:188,y:578,t:1527268557066};\\\", \\\"{x:186,y:578,t:1527268557083};\\\", \\\"{x:183,y:578,t:1527268557099};\\\", \\\"{x:178,y:579,t:1527268557116};\\\", \\\"{x:171,y:580,t:1527268557133};\\\", \\\"{x:169,y:580,t:1527268557149};\\\", \\\"{x:167,y:581,t:1527268557166};\\\", \\\"{x:168,y:581,t:1527268563766};\\\", \\\"{x:180,y:583,t:1527268563775};\\\", \\\"{x:201,y:585,t:1527268563790};\\\", \\\"{x:241,y:593,t:1527268563804};\\\", \\\"{x:310,y:610,t:1527268563821};\\\", \\\"{x:336,y:616,t:1527268563838};\\\", \\\"{x:351,y:621,t:1527268563855};\\\", \\\"{x:357,y:625,t:1527268563871};\\\", \\\"{x:359,y:626,t:1527268563888};\\\", \\\"{x:362,y:627,t:1527268563905};\\\", \\\"{x:363,y:627,t:1527268563925};\\\", \\\"{x:364,y:628,t:1527268563938};\\\", \\\"{x:365,y:629,t:1527268563955};\\\", \\\"{x:372,y:631,t:1527268563971};\\\", \\\"{x:377,y:633,t:1527268563989};\\\", \\\"{x:401,y:642,t:1527268564005};\\\", \\\"{x:418,y:647,t:1527268564022};\\\", \\\"{x:436,y:650,t:1527268564039};\\\", \\\"{x:458,y:654,t:1527268564056};\\\", \\\"{x:476,y:656,t:1527268564071};\\\", \\\"{x:486,y:658,t:1527268564088};\\\", \\\"{x:490,y:658,t:1527268564105};\\\", \\\"{x:491,y:658,t:1527268564122};\\\", \\\"{x:492,y:658,t:1527268564142};\\\", \\\"{x:493,y:658,t:1527268564157};\\\", \\\"{x:494,y:658,t:1527268564303};\\\" ] }, { \\\"rt\\\": 25488, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 7, \\\"time_elapsed\\\": 133695, \\\"internal_node_id\\\": \\\"0.0-5.0-2.0\\\", \\\"subject\\\": \\\"YC7SX\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"mike\\\", \\\"condition\\\": \\\"115-late\\\", \\\"scenario\\\": \\\"acme\\\", \\\"question\\\": \\\"meets\\\", \\\"q\\\": 3, \\\"clicks\\\": 1, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XFull-YFull\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 1, \\\"answer\\\": [ \\\"Z\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"X \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"U \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"\\\", \\\"block\\\": \\\"triangular_scaffolded\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:496,y:658,t:1527268574982};\\\", \\\"{x:497,y:658,t:1527268574997};\\\", \\\"{x:498,y:659,t:1527268575005};\\\", \\\"{x:500,y:660,t:1527268575022};\\\", \\\"{x:501,y:660,t:1527268575334};\\\", \\\"{x:501,y:661,t:1527268575461};\\\", \\\"{x:501,y:662,t:1527268575477};\\\", \\\"{x:501,y:664,t:1527268575487};\\\", \\\"{x:501,y:668,t:1527268575504};\\\", \\\"{x:501,y:670,t:1527268575521};\\\", \\\"{x:501,y:672,t:1527268575538};\\\", \\\"{x:501,y:674,t:1527268575555};\\\", \\\"{x:501,y:675,t:1527268575590};\\\", \\\"{x:501,y:674,t:1527268589106};\\\", \\\"{x:502,y:670,t:1527268589114};\\\", \\\"{x:506,y:666,t:1527268589125};\\\", \\\"{x:514,y:655,t:1527268589142};\\\", \\\"{x:524,y:646,t:1527268589160};\\\", \\\"{x:529,y:641,t:1527268589175};\\\", \\\"{x:535,y:635,t:1527268589191};\\\", \\\"{x:539,y:631,t:1527268589205};\\\", \\\"{x:544,y:626,t:1527268589222};\\\", \\\"{x:550,y:621,t:1527268589238};\\\", \\\"{x:557,y:615,t:1527268589254};\\\", \\\"{x:561,y:612,t:1527268589272};\\\", \\\"{x:565,y:608,t:1527268589288};\\\", \\\"{x:566,y:605,t:1527268589305};\\\", \\\"{x:568,y:602,t:1527268589321};\\\", \\\"{x:568,y:600,t:1527268589338};\\\", \\\"{x:568,y:596,t:1527268589356};\\\", \\\"{x:562,y:593,t:1527268589372};\\\", \\\"{x:540,y:587,t:1527268589389};\\\", \\\"{x:502,y:584,t:1527268589405};\\\", \\\"{x:459,y:581,t:1527268589422};\\\", \\\"{x:403,y:581,t:1527268589439};\\\", \\\"{x:339,y:581,t:1527268589455};\\\", \\\"{x:284,y:578,t:1527268589472};\\\", \\\"{x:249,y:578,t:1527268589489};\\\", \\\"{x:231,y:578,t:1527268589505};\\\", \\\"{x:224,y:578,t:1527268589522};\\\", \\\"{x:222,y:578,t:1527268589578};\\\", \\\"{x:217,y:578,t:1527268589589};\\\", \\\"{x:208,y:581,t:1527268589606};\\\", \\\"{x:199,y:582,t:1527268589622};\\\", \\\"{x:186,y:586,t:1527268589640};\\\", \\\"{x:174,y:588,t:1527268589656};\\\", \\\"{x:166,y:589,t:1527268589672};\\\", \\\"{x:163,y:589,t:1527268589689};\\\", \\\"{x:162,y:589,t:1527268589706};\\\", \\\"{x:162,y:588,t:1527268589842};\\\", \\\"{x:162,y:586,t:1527268589856};\\\", \\\"{x:163,y:576,t:1527268589873};\\\", \\\"{x:163,y:567,t:1527268589890};\\\", \\\"{x:163,y:554,t:1527268589906};\\\", \\\"{x:163,y:547,t:1527268589922};\\\", \\\"{x:164,y:544,t:1527268589938};\\\", \\\"{x:164,y:540,t:1527268589955};\\\", \\\"{x:166,y:538,t:1527268589972};\\\", \\\"{x:166,y:536,t:1527268589989};\\\", \\\"{x:166,y:534,t:1527268590006};\\\", \\\"{x:166,y:533,t:1527268590022};\\\", \\\"{x:166,y:531,t:1527268590040};\\\", \\\"{x:166,y:527,t:1527268590057};\\\", \\\"{x:166,y:526,t:1527268590072};\\\", \\\"{x:166,y:521,t:1527268590090};\\\", \\\"{x:166,y:517,t:1527268590106};\\\", \\\"{x:166,y:514,t:1527268590122};\\\", \\\"{x:165,y:512,t:1527268590139};\\\", \\\"{x:165,y:511,t:1527268590156};\\\", \\\"{x:165,y:509,t:1527268590173};\\\", \\\"{x:173,y:519,t:1527268590457};\\\", \\\"{x:218,y:562,t:1527268590474};\\\", \\\"{x:268,y:603,t:1527268590490};\\\", \\\"{x:305,y:632,t:1527268590506};\\\", \\\"{x:338,y:651,t:1527268590523};\\\", \\\"{x:367,y:667,t:1527268590539};\\\", \\\"{x:388,y:678,t:1527268590556};\\\", \\\"{x:398,y:683,t:1527268590573};\\\", \\\"{x:399,y:683,t:1527268590589};\\\", \\\"{x:399,y:682,t:1527268590698};\\\", \\\"{x:399,y:678,t:1527268590706};\\\", \\\"{x:403,y:670,t:1527268590723};\\\", \\\"{x:405,y:666,t:1527268590739};\\\", \\\"{x:408,y:662,t:1527268590756};\\\", \\\"{x:411,y:658,t:1527268590774};\\\", \\\"{x:413,y:655,t:1527268590790};\\\", \\\"{x:414,y:654,t:1527268590817};\\\", \\\"{x:417,y:654,t:1527268590890};\\\", \\\"{x:418,y:654,t:1527268590907};\\\", \\\"{x:422,y:655,t:1527268590924};\\\", \\\"{x:426,y:655,t:1527268590940};\\\", \\\"{x:433,y:655,t:1527268590957};\\\", \\\"{x:441,y:655,t:1527268590974};\\\", \\\"{x:450,y:656,t:1527268590992};\\\", \\\"{x:455,y:656,t:1527268591006};\\\", \\\"{x:456,y:656,t:1527268591023};\\\", \\\"{x:456,y:657,t:1527268591082};\\\" ] }, { \\\"rt\\\": 70895, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 8, \\\"time_elapsed\\\": 205869, \\\"internal_node_id\\\": \\\"0.0-5.0-3.0\\\", \\\"subject\\\": \\\"YC7SX\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"mike\\\", \\\"condition\\\": \\\"115-late\\\", \\\"scenario\\\": \\\"acme\\\", \\\"question\\\": \\\"endtime\\\", \\\"q\\\": 4, \\\"clicks\\\": 2, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XFull-YFull\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 0, \\\"answer\\\": [ \\\"O\\\", \\\"U\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"X \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"U \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-A -U -U -Z -Z -F -F -F -O -O -O -K -K -12 PM-Z -O -H -U -U -G -G \\\", \\\"block\\\": \\\"triangular_scaffolded\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:477,y:661,t:1527268593731};\\\", \\\"{x:531,y:669,t:1527268593743};\\\", \\\"{x:636,y:681,t:1527268593759};\\\", \\\"{x:770,y:687,t:1527268593775};\\\", \\\"{x:938,y:709,t:1527268593792};\\\", \\\"{x:1202,y:745,t:1527268593809};\\\", \\\"{x:1351,y:760,t:1527268593825};\\\", \\\"{x:1451,y:776,t:1527268593842};\\\", \\\"{x:1497,y:779,t:1527268593860};\\\", \\\"{x:1516,y:779,t:1527268593875};\\\", \\\"{x:1522,y:782,t:1527268593892};\\\", \\\"{x:1518,y:782,t:1527268594083};\\\", \\\"{x:1513,y:781,t:1527268594093};\\\", \\\"{x:1503,y:780,t:1527268594109};\\\", \\\"{x:1487,y:778,t:1527268594127};\\\", \\\"{x:1472,y:776,t:1527268594143};\\\", \\\"{x:1458,y:774,t:1527268594160};\\\", \\\"{x:1448,y:774,t:1527268594177};\\\", \\\"{x:1440,y:772,t:1527268594193};\\\", \\\"{x:1434,y:772,t:1527268594210};\\\", \\\"{x:1432,y:772,t:1527268594226};\\\", \\\"{x:1431,y:772,t:1527268594250};\\\", \\\"{x:1430,y:772,t:1527268594260};\\\", \\\"{x:1428,y:772,t:1527268594277};\\\", \\\"{x:1423,y:774,t:1527268594293};\\\", \\\"{x:1417,y:775,t:1527268594310};\\\", \\\"{x:1411,y:777,t:1527268594327};\\\", \\\"{x:1406,y:779,t:1527268594342};\\\", \\\"{x:1402,y:780,t:1527268594360};\\\", \\\"{x:1398,y:783,t:1527268594377};\\\", \\\"{x:1394,y:784,t:1527268594393};\\\", \\\"{x:1388,y:786,t:1527268594410};\\\", \\\"{x:1384,y:788,t:1527268594426};\\\", \\\"{x:1379,y:789,t:1527268594443};\\\", \\\"{x:1376,y:791,t:1527268594460};\\\", \\\"{x:1371,y:793,t:1527268594477};\\\", \\\"{x:1369,y:794,t:1527268594494};\\\", \\\"{x:1365,y:795,t:1527268594509};\\\", \\\"{x:1361,y:797,t:1527268594527};\\\", \\\"{x:1358,y:797,t:1527268594543};\\\", \\\"{x:1354,y:798,t:1527268594560};\\\", \\\"{x:1347,y:801,t:1527268594577};\\\", \\\"{x:1338,y:803,t:1527268594594};\\\", \\\"{x:1330,y:806,t:1527268594611};\\\", \\\"{x:1321,y:806,t:1527268594627};\\\", \\\"{x:1315,y:807,t:1527268594644};\\\", \\\"{x:1309,y:807,t:1527268594660};\\\", \\\"{x:1304,y:809,t:1527268594677};\\\", \\\"{x:1297,y:810,t:1527268594694};\\\", \\\"{x:1289,y:810,t:1527268594709};\\\", \\\"{x:1281,y:810,t:1527268594727};\\\", \\\"{x:1272,y:810,t:1527268594743};\\\", \\\"{x:1267,y:810,t:1527268594759};\\\", \\\"{x:1262,y:811,t:1527268594777};\\\", \\\"{x:1257,y:813,t:1527268594794};\\\", \\\"{x:1256,y:813,t:1527268594810};\\\", \\\"{x:1254,y:813,t:1527268594826};\\\", \\\"{x:1253,y:813,t:1527268594858};\\\", \\\"{x:1252,y:813,t:1527268594882};\\\", \\\"{x:1251,y:814,t:1527268594906};\\\", \\\"{x:1250,y:814,t:1527268594938};\\\", \\\"{x:1249,y:814,t:1527268594963};\\\", \\\"{x:1248,y:815,t:1527268594987};\\\", \\\"{x:1247,y:816,t:1527268594994};\\\", \\\"{x:1246,y:816,t:1527268595034};\\\", \\\"{x:1245,y:816,t:1527268595523};\\\", \\\"{x:1244,y:816,t:1527268595530};\\\", \\\"{x:1243,y:816,t:1527268595544};\\\", \\\"{x:1242,y:816,t:1527268595561};\\\", \\\"{x:1238,y:813,t:1527268595578};\\\", \\\"{x:1236,y:812,t:1527268595594};\\\", \\\"{x:1235,y:810,t:1527268595611};\\\", \\\"{x:1234,y:809,t:1527268595628};\\\", \\\"{x:1232,y:806,t:1527268595644};\\\", \\\"{x:1231,y:804,t:1527268595661};\\\", \\\"{x:1230,y:803,t:1527268595678};\\\", \\\"{x:1229,y:802,t:1527268595694};\\\", \\\"{x:1229,y:800,t:1527268595711};\\\", \\\"{x:1228,y:799,t:1527268595728};\\\", \\\"{x:1227,y:797,t:1527268595744};\\\", \\\"{x:1226,y:794,t:1527268595761};\\\", \\\"{x:1225,y:791,t:1527268595778};\\\", \\\"{x:1224,y:787,t:1527268595794};\\\", \\\"{x:1223,y:786,t:1527268595811};\\\", \\\"{x:1223,y:783,t:1527268595828};\\\", \\\"{x:1223,y:782,t:1527268595845};\\\", \\\"{x:1223,y:780,t:1527268595861};\\\", \\\"{x:1223,y:778,t:1527268595898};\\\", \\\"{x:1222,y:778,t:1527268595911};\\\", \\\"{x:1221,y:775,t:1527268595928};\\\", \\\"{x:1220,y:773,t:1527268595945};\\\", \\\"{x:1219,y:772,t:1527268595970};\\\", \\\"{x:1219,y:771,t:1527268596602};\\\", \\\"{x:1220,y:769,t:1527268596612};\\\", \\\"{x:1222,y:769,t:1527268596628};\\\", \\\"{x:1228,y:768,t:1527268596645};\\\", \\\"{x:1241,y:768,t:1527268596662};\\\", \\\"{x:1250,y:767,t:1527268596679};\\\", \\\"{x:1251,y:767,t:1527268596714};\\\", \\\"{x:1253,y:767,t:1527268596771};\\\", \\\"{x:1255,y:767,t:1527268596794};\\\", \\\"{x:1259,y:767,t:1527268596812};\\\", \\\"{x:1261,y:767,t:1527268596829};\\\", \\\"{x:1262,y:767,t:1527268596866};\\\", \\\"{x:1263,y:767,t:1527268596890};\\\", \\\"{x:1264,y:767,t:1527268596898};\\\", \\\"{x:1265,y:767,t:1527268596911};\\\", \\\"{x:1268,y:767,t:1527268596928};\\\", \\\"{x:1272,y:769,t:1527268596944};\\\", \\\"{x:1278,y:770,t:1527268596961};\\\", \\\"{x:1282,y:771,t:1527268596978};\\\", \\\"{x:1285,y:772,t:1527268596995};\\\", \\\"{x:1286,y:772,t:1527268597017};\\\", \\\"{x:1287,y:772,t:1527268597058};\\\", \\\"{x:1288,y:772,t:1527268597066};\\\", \\\"{x:1289,y:772,t:1527268597079};\\\", \\\"{x:1294,y:772,t:1527268597094};\\\", \\\"{x:1300,y:772,t:1527268597111};\\\", \\\"{x:1306,y:772,t:1527268597129};\\\", \\\"{x:1311,y:772,t:1527268597146};\\\", \\\"{x:1315,y:772,t:1527268597162};\\\", \\\"{x:1316,y:772,t:1527268597178};\\\", \\\"{x:1317,y:772,t:1527268597196};\\\", \\\"{x:1320,y:772,t:1527268597290};\\\", \\\"{x:1321,y:772,t:1527268597297};\\\", \\\"{x:1323,y:772,t:1527268597312};\\\", \\\"{x:1324,y:772,t:1527268597329};\\\", \\\"{x:1332,y:774,t:1527268597346};\\\", \\\"{x:1338,y:775,t:1527268597362};\\\", \\\"{x:1343,y:775,t:1527268597379};\\\", \\\"{x:1346,y:775,t:1527268597396};\\\", \\\"{x:1347,y:775,t:1527268597412};\\\", \\\"{x:1348,y:775,t:1527268597429};\\\", \\\"{x:1349,y:775,t:1527268597482};\\\", \\\"{x:1350,y:775,t:1527268597499};\\\", \\\"{x:1350,y:776,t:1527268598402};\\\", \\\"{x:1351,y:776,t:1527268599251};\\\", \\\"{x:1352,y:776,t:1527268599264};\\\", \\\"{x:1360,y:776,t:1527268599280};\\\", \\\"{x:1367,y:776,t:1527268599297};\\\", \\\"{x:1374,y:776,t:1527268599314};\\\", \\\"{x:1378,y:776,t:1527268599330};\\\", \\\"{x:1379,y:776,t:1527268599347};\\\", \\\"{x:1381,y:776,t:1527268599402};\\\", \\\"{x:1382,y:776,t:1527268599418};\\\", \\\"{x:1384,y:776,t:1527268599431};\\\", \\\"{x:1387,y:776,t:1527268599447};\\\", \\\"{x:1389,y:776,t:1527268599464};\\\", \\\"{x:1392,y:776,t:1527268599481};\\\", \\\"{x:1396,y:776,t:1527268599497};\\\", \\\"{x:1406,y:776,t:1527268599514};\\\", \\\"{x:1411,y:776,t:1527268599530};\\\", \\\"{x:1417,y:776,t:1527268599547};\\\", \\\"{x:1419,y:776,t:1527268599564};\\\", \\\"{x:1420,y:776,t:1527268599581};\\\", \\\"{x:1421,y:776,t:1527268599597};\\\", \\\"{x:1422,y:776,t:1527268599683};\\\", \\\"{x:1424,y:776,t:1527268599859};\\\", \\\"{x:1427,y:776,t:1527268599866};\\\", \\\"{x:1431,y:776,t:1527268599881};\\\", \\\"{x:1440,y:776,t:1527268599898};\\\", \\\"{x:1447,y:776,t:1527268599914};\\\", \\\"{x:1452,y:776,t:1527268599931};\\\", \\\"{x:1453,y:776,t:1527268599948};\\\", \\\"{x:1454,y:776,t:1527268600011};\\\", \\\"{x:1455,y:776,t:1527268600034};\\\", \\\"{x:1456,y:776,t:1527268600048};\\\", \\\"{x:1461,y:776,t:1527268600064};\\\", \\\"{x:1466,y:776,t:1527268600081};\\\", \\\"{x:1477,y:776,t:1527268600100};\\\", \\\"{x:1484,y:776,t:1527268600113};\\\", \\\"{x:1489,y:776,t:1527268600131};\\\", \\\"{x:1491,y:776,t:1527268600147};\\\", \\\"{x:1490,y:776,t:1527268600449};\\\", \\\"{x:1489,y:776,t:1527268600464};\\\", \\\"{x:1487,y:777,t:1527268600481};\\\", \\\"{x:1483,y:778,t:1527268600497};\\\", \\\"{x:1482,y:779,t:1527268600515};\\\", \\\"{x:1479,y:779,t:1527268600530};\\\", \\\"{x:1476,y:781,t:1527268600548};\\\", \\\"{x:1473,y:781,t:1527268600565};\\\", \\\"{x:1470,y:782,t:1527268600581};\\\", \\\"{x:1465,y:783,t:1527268600598};\\\", \\\"{x:1461,y:785,t:1527268600615};\\\", \\\"{x:1453,y:789,t:1527268600631};\\\", \\\"{x:1445,y:791,t:1527268600647};\\\", \\\"{x:1434,y:796,t:1527268600665};\\\", \\\"{x:1421,y:802,t:1527268600681};\\\", \\\"{x:1405,y:810,t:1527268600697};\\\", \\\"{x:1399,y:814,t:1527268600715};\\\", \\\"{x:1394,y:818,t:1527268600732};\\\", \\\"{x:1391,y:821,t:1527268600748};\\\", \\\"{x:1388,y:825,t:1527268600765};\\\", \\\"{x:1385,y:828,t:1527268600782};\\\", \\\"{x:1382,y:832,t:1527268600798};\\\", \\\"{x:1380,y:833,t:1527268600814};\\\", \\\"{x:1376,y:836,t:1527268600831};\\\", \\\"{x:1370,y:838,t:1527268600848};\\\", \\\"{x:1363,y:840,t:1527268600865};\\\", \\\"{x:1352,y:844,t:1527268600882};\\\", \\\"{x:1346,y:846,t:1527268600897};\\\", \\\"{x:1344,y:846,t:1527268600915};\\\", \\\"{x:1342,y:846,t:1527268600933};\\\", \\\"{x:1344,y:846,t:1527268601658};\\\", \\\"{x:1349,y:846,t:1527268601666};\\\", \\\"{x:1359,y:844,t:1527268601683};\\\", \\\"{x:1369,y:844,t:1527268601699};\\\", \\\"{x:1376,y:844,t:1527268601716};\\\", \\\"{x:1380,y:844,t:1527268601731};\\\", \\\"{x:1380,y:843,t:1527268601761};\\\", \\\"{x:1380,y:842,t:1527268602401};\\\", \\\"{x:1380,y:841,t:1527268602416};\\\", \\\"{x:1380,y:840,t:1527268602432};\\\", \\\"{x:1380,y:838,t:1527268602449};\\\", \\\"{x:1380,y:837,t:1527268602473};\\\", \\\"{x:1380,y:836,t:1527268602482};\\\", \\\"{x:1380,y:835,t:1527268602505};\\\", \\\"{x:1380,y:834,t:1527268602516};\\\", \\\"{x:1380,y:831,t:1527268602532};\\\", \\\"{x:1380,y:829,t:1527268602550};\\\", \\\"{x:1380,y:824,t:1527268602566};\\\", \\\"{x:1380,y:813,t:1527268602583};\\\", \\\"{x:1380,y:803,t:1527268602600};\\\", \\\"{x:1380,y:789,t:1527268602615};\\\", \\\"{x:1380,y:777,t:1527268602633};\\\", \\\"{x:1380,y:758,t:1527268602651};\\\", \\\"{x:1380,y:745,t:1527268602666};\\\", \\\"{x:1380,y:737,t:1527268602683};\\\", \\\"{x:1383,y:730,t:1527268602699};\\\", \\\"{x:1383,y:725,t:1527268602715};\\\", \\\"{x:1383,y:721,t:1527268602733};\\\", \\\"{x:1383,y:714,t:1527268602750};\\\", \\\"{x:1384,y:710,t:1527268602765};\\\", \\\"{x:1384,y:706,t:1527268602783};\\\", \\\"{x:1385,y:704,t:1527268602801};\\\", \\\"{x:1385,y:703,t:1527268602816};\\\", \\\"{x:1385,y:702,t:1527268603131};\\\", \\\"{x:1387,y:702,t:1527268603546};\\\", \\\"{x:1388,y:702,t:1527268603553};\\\", \\\"{x:1390,y:702,t:1527268603567};\\\", \\\"{x:1394,y:702,t:1527268603584};\\\", \\\"{x:1398,y:702,t:1527268603600};\\\", \\\"{x:1401,y:702,t:1527268603675};\\\", \\\"{x:1406,y:702,t:1527268603684};\\\", \\\"{x:1418,y:702,t:1527268603700};\\\", \\\"{x:1434,y:702,t:1527268603717};\\\", \\\"{x:1443,y:702,t:1527268603734};\\\", \\\"{x:1451,y:702,t:1527268603751};\\\", \\\"{x:1453,y:702,t:1527268603767};\\\", \\\"{x:1454,y:702,t:1527268603784};\\\", \\\"{x:1455,y:702,t:1527268603843};\\\", \\\"{x:1457,y:702,t:1527268603850};\\\", \\\"{x:1458,y:702,t:1527268603867};\\\", \\\"{x:1460,y:702,t:1527268603884};\\\", \\\"{x:1461,y:702,t:1527268603971};\\\", \\\"{x:1463,y:702,t:1527268604018};\\\", \\\"{x:1466,y:702,t:1527268604034};\\\", \\\"{x:1472,y:703,t:1527268604051};\\\", \\\"{x:1479,y:704,t:1527268604067};\\\", \\\"{x:1489,y:705,t:1527268604084};\\\", \\\"{x:1496,y:707,t:1527268604101};\\\", \\\"{x:1501,y:707,t:1527268604117};\\\", \\\"{x:1503,y:707,t:1527268604134};\\\", \\\"{x:1504,y:707,t:1527268604235};\\\", \\\"{x:1508,y:708,t:1527268604251};\\\", \\\"{x:1513,y:708,t:1527268604269};\\\", \\\"{x:1514,y:709,t:1527268604284};\\\", \\\"{x:1515,y:709,t:1527268604302};\\\", \\\"{x:1516,y:709,t:1527268604586};\\\", \\\"{x:1518,y:709,t:1527268604601};\\\", \\\"{x:1523,y:709,t:1527268604618};\\\", \\\"{x:1527,y:709,t:1527268604635};\\\", \\\"{x:1530,y:709,t:1527268604652};\\\", \\\"{x:1532,y:709,t:1527268604668};\\\", \\\"{x:1533,y:709,t:1527268604690};\\\", \\\"{x:1534,y:709,t:1527268604795};\\\", \\\"{x:1535,y:709,t:1527268604898};\\\", \\\"{x:1536,y:709,t:1527268604914};\\\", \\\"{x:1538,y:709,t:1527268604922};\\\", \\\"{x:1540,y:709,t:1527268604938};\\\", \\\"{x:1542,y:709,t:1527268604951};\\\", \\\"{x:1543,y:709,t:1527268604969};\\\", \\\"{x:1545,y:709,t:1527268604985};\\\", \\\"{x:1546,y:709,t:1527268605001};\\\", \\\"{x:1547,y:709,t:1527268605027};\\\", \\\"{x:1548,y:709,t:1527268605043};\\\", \\\"{x:1549,y:709,t:1527268605066};\\\", \\\"{x:1550,y:709,t:1527268605082};\\\", \\\"{x:1551,y:709,t:1527268605090};\\\", \\\"{x:1553,y:709,t:1527268605102};\\\", \\\"{x:1556,y:709,t:1527268605118};\\\", \\\"{x:1560,y:709,t:1527268605135};\\\", \\\"{x:1564,y:709,t:1527268605152};\\\", \\\"{x:1568,y:709,t:1527268605168};\\\", \\\"{x:1574,y:709,t:1527268605185};\\\", \\\"{x:1579,y:709,t:1527268605202};\\\", \\\"{x:1582,y:709,t:1527268605219};\\\", \\\"{x:1583,y:709,t:1527268607987};\\\", \\\"{x:1580,y:707,t:1527268608005};\\\", \\\"{x:1578,y:706,t:1527268608021};\\\", \\\"{x:1576,y:706,t:1527268608082};\\\", \\\"{x:1575,y:706,t:1527268608090};\\\", \\\"{x:1572,y:706,t:1527268608105};\\\", \\\"{x:1568,y:706,t:1527268608121};\\\", \\\"{x:1561,y:706,t:1527268608137};\\\", \\\"{x:1547,y:706,t:1527268608154};\\\", \\\"{x:1539,y:706,t:1527268608171};\\\", \\\"{x:1529,y:706,t:1527268608187};\\\", \\\"{x:1517,y:706,t:1527268608204};\\\", \\\"{x:1504,y:706,t:1527268608221};\\\", \\\"{x:1490,y:706,t:1527268608237};\\\", \\\"{x:1475,y:706,t:1527268608255};\\\", \\\"{x:1461,y:706,t:1527268608272};\\\", \\\"{x:1447,y:707,t:1527268608287};\\\", \\\"{x:1437,y:708,t:1527268608304};\\\", \\\"{x:1429,y:708,t:1527268608321};\\\", \\\"{x:1422,y:708,t:1527268608337};\\\", \\\"{x:1416,y:708,t:1527268608354};\\\", \\\"{x:1413,y:708,t:1527268608370};\\\", \\\"{x:1409,y:708,t:1527268608387};\\\", \\\"{x:1406,y:708,t:1527268608404};\\\", \\\"{x:1402,y:708,t:1527268608421};\\\", \\\"{x:1397,y:708,t:1527268608437};\\\", \\\"{x:1392,y:708,t:1527268608454};\\\", \\\"{x:1391,y:708,t:1527268608471};\\\", \\\"{x:1389,y:708,t:1527268608486};\\\", \\\"{x:1388,y:709,t:1527268608537};\\\", \\\"{x:1385,y:706,t:1527268608755};\\\", \\\"{x:1379,y:694,t:1527268608772};\\\", \\\"{x:1372,y:677,t:1527268608789};\\\", \\\"{x:1367,y:662,t:1527268608804};\\\", \\\"{x:1363,y:648,t:1527268608822};\\\", \\\"{x:1359,y:636,t:1527268608839};\\\", \\\"{x:1358,y:629,t:1527268608854};\\\", \\\"{x:1356,y:623,t:1527268608871};\\\", \\\"{x:1354,y:618,t:1527268608888};\\\", \\\"{x:1354,y:616,t:1527268608904};\\\", \\\"{x:1352,y:609,t:1527268608921};\\\", \\\"{x:1352,y:607,t:1527268608945};\\\", \\\"{x:1351,y:605,t:1527268608954};\\\", \\\"{x:1350,y:604,t:1527268608971};\\\", \\\"{x:1347,y:600,t:1527268608988};\\\", \\\"{x:1343,y:597,t:1527268609004};\\\", \\\"{x:1337,y:593,t:1527268609021};\\\", \\\"{x:1334,y:591,t:1527268609038};\\\", \\\"{x:1332,y:590,t:1527268609055};\\\", \\\"{x:1330,y:590,t:1527268609071};\\\", \\\"{x:1326,y:587,t:1527268609088};\\\", \\\"{x:1321,y:585,t:1527268609105};\\\", \\\"{x:1319,y:584,t:1527268609121};\\\", \\\"{x:1315,y:581,t:1527268609138};\\\", \\\"{x:1314,y:580,t:1527268609155};\\\", \\\"{x:1312,y:580,t:1527268609171};\\\", \\\"{x:1310,y:578,t:1527268609188};\\\", \\\"{x:1310,y:577,t:1527268609204};\\\", \\\"{x:1308,y:577,t:1527268609221};\\\", \\\"{x:1307,y:576,t:1527268609242};\\\", \\\"{x:1306,y:575,t:1527268609499};\\\", \\\"{x:1307,y:574,t:1527268609506};\\\", \\\"{x:1309,y:573,t:1527268609522};\\\", \\\"{x:1310,y:573,t:1527268609538};\\\", \\\"{x:1313,y:571,t:1527268609556};\\\", \\\"{x:1315,y:571,t:1527268609572};\\\", \\\"{x:1318,y:571,t:1527268609588};\\\", \\\"{x:1320,y:571,t:1527268609606};\\\", \\\"{x:1321,y:571,t:1527268609623};\\\", \\\"{x:1327,y:571,t:1527268609639};\\\", \\\"{x:1336,y:571,t:1527268609655};\\\", \\\"{x:1342,y:571,t:1527268609672};\\\", \\\"{x:1347,y:572,t:1527268609688};\\\", \\\"{x:1350,y:573,t:1527268609706};\\\", \\\"{x:1356,y:573,t:1527268609722};\\\", \\\"{x:1360,y:574,t:1527268609739};\\\", \\\"{x:1363,y:575,t:1527268609755};\\\", \\\"{x:1364,y:575,t:1527268609772};\\\", \\\"{x:1365,y:575,t:1527268609789};\\\", \\\"{x:1366,y:575,t:1527268609805};\\\", \\\"{x:1367,y:576,t:1527268609822};\\\", \\\"{x:1372,y:576,t:1527268609839};\\\", \\\"{x:1378,y:576,t:1527268609855};\\\", \\\"{x:1383,y:576,t:1527268609872};\\\", \\\"{x:1387,y:576,t:1527268609889};\\\", \\\"{x:1388,y:576,t:1527268609905};\\\", \\\"{x:1389,y:576,t:1527268610211};\\\", \\\"{x:1390,y:576,t:1527268610223};\\\", \\\"{x:1396,y:576,t:1527268610239};\\\", \\\"{x:1403,y:576,t:1527268610256};\\\", \\\"{x:1407,y:576,t:1527268610273};\\\", \\\"{x:1412,y:576,t:1527268610290};\\\", \\\"{x:1414,y:576,t:1527268610307};\\\", \\\"{x:1415,y:576,t:1527268610330};\\\", \\\"{x:1417,y:576,t:1527268610394};\\\", \\\"{x:1420,y:576,t:1527268610405};\\\", \\\"{x:1424,y:576,t:1527268610423};\\\", \\\"{x:1428,y:576,t:1527268610440};\\\", \\\"{x:1433,y:576,t:1527268610457};\\\", \\\"{x:1435,y:576,t:1527268610472};\\\", \\\"{x:1437,y:576,t:1527268610490};\\\", \\\"{x:1438,y:576,t:1527268610506};\\\", \\\"{x:1441,y:576,t:1527268610523};\\\", \\\"{x:1443,y:576,t:1527268610539};\\\", \\\"{x:1445,y:576,t:1527268610556};\\\", \\\"{x:1446,y:576,t:1527268610587};\\\", \\\"{x:1448,y:576,t:1527268610850};\\\", \\\"{x:1449,y:576,t:1527268610858};\\\", \\\"{x:1453,y:576,t:1527268610874};\\\", \\\"{x:1459,y:576,t:1527268610890};\\\", \\\"{x:1464,y:576,t:1527268610906};\\\", \\\"{x:1468,y:576,t:1527268610923};\\\", \\\"{x:1474,y:576,t:1527268610939};\\\", \\\"{x:1477,y:576,t:1527268610956};\\\", \\\"{x:1480,y:575,t:1527268610974};\\\", \\\"{x:1481,y:575,t:1527268610990};\\\", \\\"{x:1484,y:575,t:1527268611007};\\\", \\\"{x:1488,y:575,t:1527268611024};\\\", \\\"{x:1492,y:575,t:1527268611039};\\\", \\\"{x:1495,y:575,t:1527268611056};\\\", \\\"{x:1501,y:575,t:1527268611074};\\\", \\\"{x:1504,y:575,t:1527268611090};\\\", \\\"{x:1509,y:575,t:1527268611107};\\\", \\\"{x:1514,y:575,t:1527268611123};\\\", \\\"{x:1517,y:575,t:1527268611140};\\\", \\\"{x:1519,y:575,t:1527268611157};\\\", \\\"{x:1520,y:575,t:1527268611354};\\\", \\\"{x:1523,y:575,t:1527268611363};\\\", \\\"{x:1524,y:575,t:1527268611374};\\\", \\\"{x:1528,y:575,t:1527268611390};\\\", \\\"{x:1534,y:575,t:1527268611407};\\\", \\\"{x:1535,y:575,t:1527268611424};\\\", \\\"{x:1537,y:575,t:1527268611442};\\\", \\\"{x:1538,y:575,t:1527268611539};\\\", \\\"{x:1540,y:575,t:1527268611546};\\\", \\\"{x:1541,y:575,t:1527268611563};\\\", \\\"{x:1543,y:575,t:1527268611574};\\\", \\\"{x:1546,y:575,t:1527268611591};\\\", \\\"{x:1550,y:575,t:1527268611607};\\\", \\\"{x:1553,y:575,t:1527268611624};\\\", \\\"{x:1555,y:575,t:1527268611641};\\\", \\\"{x:1557,y:575,t:1527268611656};\\\", \\\"{x:1558,y:575,t:1527268611682};\\\", \\\"{x:1560,y:575,t:1527268611746};\\\", \\\"{x:1561,y:575,t:1527268611756};\\\", \\\"{x:1566,y:575,t:1527268611774};\\\", \\\"{x:1571,y:575,t:1527268611791};\\\", \\\"{x:1575,y:575,t:1527268611807};\\\", \\\"{x:1579,y:575,t:1527268611824};\\\", \\\"{x:1582,y:575,t:1527268611841};\\\", \\\"{x:1589,y:575,t:1527268611858};\\\", \\\"{x:1590,y:575,t:1527268611874};\\\", \\\"{x:1587,y:575,t:1527268616466};\\\", \\\"{x:1583,y:575,t:1527268616478};\\\", \\\"{x:1575,y:575,t:1527268616494};\\\", \\\"{x:1566,y:575,t:1527268616511};\\\", \\\"{x:1562,y:575,t:1527268616528};\\\", \\\"{x:1558,y:575,t:1527268616545};\\\", \\\"{x:1554,y:575,t:1527268616561};\\\", \\\"{x:1547,y:575,t:1527268616578};\\\", \\\"{x:1541,y:575,t:1527268616594};\\\", \\\"{x:1531,y:575,t:1527268616610};\\\", \\\"{x:1516,y:577,t:1527268616628};\\\", \\\"{x:1503,y:580,t:1527268616646};\\\", \\\"{x:1488,y:581,t:1527268616661};\\\", \\\"{x:1473,y:584,t:1527268616677};\\\", \\\"{x:1459,y:584,t:1527268616695};\\\", \\\"{x:1442,y:584,t:1527268616711};\\\", \\\"{x:1423,y:585,t:1527268616728};\\\", \\\"{x:1407,y:586,t:1527268616745};\\\", \\\"{x:1390,y:587,t:1527268616761};\\\", \\\"{x:1370,y:591,t:1527268616778};\\\", \\\"{x:1362,y:591,t:1527268616794};\\\", \\\"{x:1355,y:592,t:1527268616811};\\\", \\\"{x:1352,y:594,t:1527268616827};\\\", \\\"{x:1350,y:594,t:1527268616845};\\\", \\\"{x:1349,y:594,t:1527268616861};\\\", \\\"{x:1348,y:594,t:1527268616877};\\\", \\\"{x:1347,y:594,t:1527268616894};\\\", \\\"{x:1346,y:594,t:1527268616911};\\\", \\\"{x:1345,y:594,t:1527268617051};\\\", \\\"{x:1344,y:594,t:1527268617065};\\\", \\\"{x:1343,y:594,t:1527268617078};\\\", \\\"{x:1340,y:594,t:1527268617095};\\\", \\\"{x:1335,y:593,t:1527268617112};\\\", \\\"{x:1334,y:593,t:1527268617128};\\\", \\\"{x:1333,y:593,t:1527268617146};\\\", \\\"{x:1331,y:593,t:1527268617162};\\\", \\\"{x:1329,y:593,t:1527268617186};\\\", \\\"{x:1328,y:592,t:1527268617210};\\\", \\\"{x:1327,y:591,t:1527268617226};\\\", \\\"{x:1327,y:590,t:1527268617275};\\\", \\\"{x:1327,y:589,t:1527268617290};\\\", \\\"{x:1327,y:588,t:1527268617298};\\\", \\\"{x:1328,y:587,t:1527268617311};\\\", \\\"{x:1328,y:586,t:1527268617328};\\\", \\\"{x:1330,y:586,t:1527268617344};\\\", \\\"{x:1331,y:584,t:1527268617360};\\\", \\\"{x:1332,y:584,t:1527268617377};\\\", \\\"{x:1334,y:583,t:1527268617465};\\\", \\\"{x:1336,y:582,t:1527268617506};\\\", \\\"{x:1336,y:581,t:1527268617562};\\\", \\\"{x:1337,y:581,t:1527268617643};\\\", \\\"{x:1338,y:586,t:1527268618266};\\\", \\\"{x:1339,y:595,t:1527268618279};\\\", \\\"{x:1342,y:616,t:1527268618296};\\\", \\\"{x:1346,y:638,t:1527268618313};\\\", \\\"{x:1349,y:662,t:1527268618329};\\\", \\\"{x:1351,y:699,t:1527268618346};\\\", \\\"{x:1354,y:724,t:1527268618362};\\\", \\\"{x:1354,y:751,t:1527268618379};\\\", \\\"{x:1354,y:774,t:1527268618396};\\\", \\\"{x:1354,y:798,t:1527268618413};\\\", \\\"{x:1354,y:821,t:1527268618429};\\\", \\\"{x:1354,y:839,t:1527268618446};\\\", \\\"{x:1348,y:856,t:1527268618463};\\\", \\\"{x:1346,y:864,t:1527268618479};\\\", \\\"{x:1344,y:873,t:1527268618496};\\\", \\\"{x:1342,y:881,t:1527268618513};\\\", \\\"{x:1339,y:890,t:1527268618529};\\\", \\\"{x:1338,y:899,t:1527268618546};\\\", \\\"{x:1338,y:905,t:1527268618563};\\\", \\\"{x:1338,y:908,t:1527268618579};\\\", \\\"{x:1339,y:913,t:1527268618596};\\\", \\\"{x:1341,y:917,t:1527268618613};\\\", \\\"{x:1341,y:920,t:1527268618629};\\\", \\\"{x:1341,y:923,t:1527268618646};\\\", \\\"{x:1342,y:927,t:1527268618662};\\\", \\\"{x:1343,y:927,t:1527268618679};\\\", \\\"{x:1343,y:928,t:1527268618696};\\\", \\\"{x:1343,y:927,t:1527268618826};\\\", \\\"{x:1343,y:924,t:1527268618834};\\\", \\\"{x:1343,y:923,t:1527268618846};\\\", \\\"{x:1343,y:917,t:1527268618863};\\\", \\\"{x:1343,y:914,t:1527268618881};\\\", \\\"{x:1343,y:908,t:1527268618896};\\\", \\\"{x:1343,y:905,t:1527268618913};\\\", \\\"{x:1343,y:901,t:1527268618930};\\\", \\\"{x:1343,y:898,t:1527268618946};\\\", \\\"{x:1344,y:894,t:1527268618963};\\\", \\\"{x:1344,y:892,t:1527268618980};\\\", \\\"{x:1345,y:888,t:1527268618996};\\\", \\\"{x:1347,y:884,t:1527268619013};\\\", \\\"{x:1347,y:882,t:1527268619030};\\\", \\\"{x:1347,y:880,t:1527268619046};\\\", \\\"{x:1347,y:877,t:1527268619063};\\\", \\\"{x:1348,y:875,t:1527268619080};\\\", \\\"{x:1348,y:874,t:1527268619096};\\\", \\\"{x:1348,y:870,t:1527268619113};\\\", \\\"{x:1350,y:865,t:1527268619130};\\\", \\\"{x:1350,y:864,t:1527268619146};\\\", \\\"{x:1350,y:862,t:1527268619163};\\\", \\\"{x:1350,y:861,t:1527268619180};\\\", \\\"{x:1350,y:859,t:1527268619197};\\\", \\\"{x:1351,y:858,t:1527268619213};\\\", \\\"{x:1351,y:857,t:1527268619230};\\\", \\\"{x:1351,y:856,t:1527268619247};\\\", \\\"{x:1351,y:854,t:1527268619263};\\\", \\\"{x:1352,y:852,t:1527268619280};\\\", \\\"{x:1352,y:849,t:1527268619297};\\\", \\\"{x:1352,y:848,t:1527268619313};\\\", \\\"{x:1352,y:847,t:1527268619330};\\\", \\\"{x:1352,y:845,t:1527268619347};\\\", \\\"{x:1352,y:846,t:1527268619506};\\\", \\\"{x:1352,y:850,t:1527268619514};\\\", \\\"{x:1350,y:857,t:1527268619530};\\\", \\\"{x:1349,y:865,t:1527268619547};\\\", \\\"{x:1349,y:873,t:1527268619563};\\\", \\\"{x:1349,y:880,t:1527268619579};\\\", \\\"{x:1349,y:885,t:1527268619597};\\\", \\\"{x:1349,y:888,t:1527268619613};\\\", \\\"{x:1349,y:890,t:1527268619630};\\\", \\\"{x:1349,y:894,t:1527268619647};\\\", \\\"{x:1349,y:897,t:1527268619663};\\\", \\\"{x:1349,y:898,t:1527268619679};\\\", \\\"{x:1349,y:900,t:1527268619697};\\\", \\\"{x:1349,y:901,t:1527268619714};\\\", \\\"{x:1349,y:902,t:1527268619730};\\\", \\\"{x:1349,y:903,t:1527268619762};\\\", \\\"{x:1348,y:904,t:1527268619786};\\\", \\\"{x:1347,y:906,t:1527268619810};\\\", \\\"{x:1346,y:907,t:1527268619834};\\\", \\\"{x:1346,y:908,t:1527268619847};\\\", \\\"{x:1345,y:909,t:1527268619866};\\\", \\\"{x:1344,y:910,t:1527268619880};\\\", \\\"{x:1343,y:910,t:1527268619896};\\\", \\\"{x:1343,y:911,t:1527268619987};\\\", \\\"{x:1343,y:909,t:1527268620107};\\\", \\\"{x:1343,y:908,t:1527268620122};\\\", \\\"{x:1343,y:906,t:1527268620130};\\\", \\\"{x:1342,y:903,t:1527268620147};\\\", \\\"{x:1340,y:897,t:1527268620164};\\\", \\\"{x:1340,y:891,t:1527268620181};\\\", \\\"{x:1340,y:886,t:1527268620197};\\\", \\\"{x:1340,y:881,t:1527268620214};\\\", \\\"{x:1340,y:875,t:1527268620231};\\\", \\\"{x:1340,y:870,t:1527268620247};\\\", \\\"{x:1340,y:864,t:1527268620264};\\\", \\\"{x:1340,y:858,t:1527268620281};\\\", \\\"{x:1340,y:853,t:1527268620298};\\\", \\\"{x:1339,y:847,t:1527268620313};\\\", \\\"{x:1339,y:845,t:1527268620331};\\\", \\\"{x:1339,y:842,t:1527268620346};\\\", \\\"{x:1339,y:840,t:1527268620363};\\\", \\\"{x:1339,y:838,t:1527268620380};\\\", \\\"{x:1339,y:835,t:1527268620396};\\\", \\\"{x:1339,y:832,t:1527268620413};\\\", \\\"{x:1339,y:829,t:1527268620430};\\\", \\\"{x:1339,y:826,t:1527268620446};\\\", \\\"{x:1339,y:823,t:1527268620463};\\\", \\\"{x:1339,y:819,t:1527268620480};\\\", \\\"{x:1339,y:816,t:1527268620496};\\\", \\\"{x:1339,y:808,t:1527268620513};\\\", \\\"{x:1339,y:804,t:1527268620530};\\\", \\\"{x:1339,y:799,t:1527268620548};\\\", \\\"{x:1340,y:792,t:1527268620563};\\\", \\\"{x:1341,y:788,t:1527268620580};\\\", \\\"{x:1342,y:784,t:1527268620597};\\\", \\\"{x:1343,y:779,t:1527268620613};\\\", \\\"{x:1343,y:775,t:1527268620631};\\\", \\\"{x:1344,y:771,t:1527268620647};\\\", \\\"{x:1344,y:769,t:1527268620663};\\\", \\\"{x:1345,y:766,t:1527268620681};\\\", \\\"{x:1345,y:764,t:1527268620697};\\\", \\\"{x:1346,y:762,t:1527268620713};\\\", \\\"{x:1346,y:760,t:1527268620730};\\\", \\\"{x:1346,y:758,t:1527268620747};\\\", \\\"{x:1347,y:755,t:1527268620764};\\\", \\\"{x:1347,y:751,t:1527268620781};\\\", \\\"{x:1348,y:748,t:1527268620798};\\\", \\\"{x:1348,y:744,t:1527268620814};\\\", \\\"{x:1349,y:741,t:1527268620831};\\\", \\\"{x:1349,y:737,t:1527268620848};\\\", \\\"{x:1349,y:733,t:1527268620864};\\\", \\\"{x:1349,y:728,t:1527268620881};\\\", \\\"{x:1349,y:720,t:1527268620897};\\\", \\\"{x:1349,y:717,t:1527268620914};\\\", \\\"{x:1349,y:715,t:1527268620931};\\\", \\\"{x:1349,y:714,t:1527268620948};\\\", \\\"{x:1349,y:712,t:1527268620965};\\\", \\\"{x:1349,y:711,t:1527268620981};\\\", \\\"{x:1349,y:709,t:1527268620998};\\\", \\\"{x:1349,y:708,t:1527268621015};\\\", \\\"{x:1349,y:706,t:1527268621031};\\\", \\\"{x:1349,y:705,t:1527268621048};\\\", \\\"{x:1349,y:702,t:1527268621066};\\\", \\\"{x:1349,y:701,t:1527268621081};\\\", \\\"{x:1349,y:698,t:1527268621097};\\\", \\\"{x:1349,y:695,t:1527268621115};\\\", \\\"{x:1349,y:694,t:1527268621131};\\\", \\\"{x:1349,y:692,t:1527268621147};\\\", \\\"{x:1349,y:689,t:1527268621165};\\\", \\\"{x:1349,y:687,t:1527268621181};\\\", \\\"{x:1349,y:684,t:1527268621198};\\\", \\\"{x:1349,y:683,t:1527268621215};\\\", \\\"{x:1349,y:680,t:1527268621231};\\\", \\\"{x:1349,y:679,t:1527268621248};\\\", \\\"{x:1349,y:677,t:1527268621265};\\\", \\\"{x:1349,y:675,t:1527268621281};\\\", \\\"{x:1349,y:672,t:1527268621298};\\\", \\\"{x:1349,y:670,t:1527268621314};\\\", \\\"{x:1348,y:669,t:1527268621331};\\\", \\\"{x:1348,y:667,t:1527268621348};\\\", \\\"{x:1347,y:664,t:1527268621365};\\\", \\\"{x:1347,y:662,t:1527268621381};\\\", \\\"{x:1346,y:658,t:1527268621398};\\\", \\\"{x:1346,y:656,t:1527268621415};\\\", \\\"{x:1346,y:654,t:1527268621432};\\\", \\\"{x:1346,y:652,t:1527268621448};\\\", \\\"{x:1344,y:650,t:1527268621465};\\\", \\\"{x:1343,y:647,t:1527268621483};\\\", \\\"{x:1343,y:645,t:1527268621498};\\\", \\\"{x:1342,y:643,t:1527268621515};\\\", \\\"{x:1342,y:642,t:1527268621533};\\\", \\\"{x:1341,y:639,t:1527268621548};\\\", \\\"{x:1341,y:636,t:1527268621565};\\\", \\\"{x:1340,y:633,t:1527268621582};\\\", \\\"{x:1340,y:629,t:1527268621598};\\\", \\\"{x:1339,y:624,t:1527268621615};\\\", \\\"{x:1339,y:620,t:1527268621632};\\\", \\\"{x:1337,y:616,t:1527268621648};\\\", \\\"{x:1337,y:615,t:1527268621666};\\\", \\\"{x:1336,y:612,t:1527268621682};\\\", \\\"{x:1336,y:611,t:1527268621713};\\\", \\\"{x:1336,y:609,t:1527268621732};\\\", \\\"{x:1335,y:608,t:1527268621748};\\\", \\\"{x:1335,y:606,t:1527268621765};\\\", \\\"{x:1335,y:603,t:1527268621782};\\\", \\\"{x:1335,y:600,t:1527268621798};\\\", \\\"{x:1335,y:596,t:1527268621815};\\\", \\\"{x:1335,y:591,t:1527268621833};\\\", \\\"{x:1335,y:586,t:1527268621849};\\\", \\\"{x:1337,y:579,t:1527268621865};\\\", \\\"{x:1337,y:573,t:1527268621882};\\\", \\\"{x:1337,y:572,t:1527268621898};\\\", \\\"{x:1337,y:571,t:1527268621915};\\\", \\\"{x:1337,y:570,t:1527268621932};\\\", \\\"{x:1338,y:570,t:1527268622458};\\\", \\\"{x:1339,y:570,t:1527268622634};\\\", \\\"{x:1340,y:569,t:1527268622649};\\\", \\\"{x:1344,y:569,t:1527268622665};\\\", \\\"{x:1349,y:569,t:1527268622682};\\\", \\\"{x:1353,y:569,t:1527268622699};\\\", \\\"{x:1356,y:569,t:1527268622716};\\\", \\\"{x:1358,y:569,t:1527268622732};\\\", \\\"{x:1360,y:569,t:1527268622748};\\\", \\\"{x:1363,y:569,t:1527268622766};\\\", \\\"{x:1368,y:569,t:1527268622783};\\\", \\\"{x:1375,y:571,t:1527268622799};\\\", \\\"{x:1381,y:571,t:1527268622815};\\\", \\\"{x:1384,y:572,t:1527268622833};\\\", \\\"{x:1388,y:572,t:1527268622849};\\\", \\\"{x:1391,y:572,t:1527268622865};\\\", \\\"{x:1392,y:572,t:1527268622883};\\\", \\\"{x:1393,y:572,t:1527268622922};\\\", \\\"{x:1394,y:572,t:1527268622933};\\\", \\\"{x:1398,y:572,t:1527268622949};\\\", \\\"{x:1402,y:574,t:1527268622966};\\\", \\\"{x:1403,y:574,t:1527268622983};\\\", \\\"{x:1404,y:574,t:1527268623067};\\\", \\\"{x:1406,y:574,t:1527268623090};\\\", \\\"{x:1407,y:574,t:1527268623106};\\\", \\\"{x:1409,y:574,t:1527268623116};\\\", \\\"{x:1411,y:574,t:1527268623747};\\\", \\\"{x:1415,y:574,t:1527268623753};\\\", \\\"{x:1419,y:574,t:1527268623767};\\\", \\\"{x:1434,y:574,t:1527268623783};\\\", \\\"{x:1453,y:574,t:1527268623800};\\\", \\\"{x:1468,y:574,t:1527268623817};\\\", \\\"{x:1483,y:574,t:1527268623833};\\\", \\\"{x:1495,y:574,t:1527268623850};\\\", \\\"{x:1499,y:574,t:1527268623867};\\\", \\\"{x:1503,y:574,t:1527268623883};\\\", \\\"{x:1504,y:574,t:1527268623900};\\\", \\\"{x:1505,y:574,t:1527268623918};\\\", \\\"{x:1506,y:574,t:1527268624091};\\\", \\\"{x:1506,y:575,t:1527268624100};\\\", \\\"{x:1505,y:576,t:1527268624121};\\\", \\\"{x:1504,y:576,t:1527268624134};\\\", \\\"{x:1503,y:576,t:1527268624210};\\\", \\\"{x:1501,y:576,t:1527268624299};\\\", \\\"{x:1500,y:576,t:1527268624330};\\\", \\\"{x:1498,y:576,t:1527268624346};\\\", \\\"{x:1497,y:576,t:1527268624354};\\\", \\\"{x:1495,y:576,t:1527268624368};\\\", \\\"{x:1491,y:576,t:1527268624384};\\\", \\\"{x:1489,y:576,t:1527268624400};\\\", \\\"{x:1488,y:576,t:1527268624417};\\\", \\\"{x:1486,y:575,t:1527268624434};\\\", \\\"{x:1486,y:574,t:1527268624643};\\\", \\\"{x:1486,y:573,t:1527268624651};\\\", \\\"{x:1488,y:573,t:1527268624673};\\\", \\\"{x:1489,y:573,t:1527268624684};\\\", \\\"{x:1492,y:573,t:1527268624700};\\\", \\\"{x:1494,y:573,t:1527268624717};\\\", \\\"{x:1500,y:573,t:1527268624734};\\\", \\\"{x:1509,y:573,t:1527268624751};\\\", \\\"{x:1525,y:573,t:1527268624767};\\\", \\\"{x:1538,y:573,t:1527268624784};\\\", \\\"{x:1550,y:573,t:1527268624800};\\\", \\\"{x:1556,y:573,t:1527268624817};\\\", \\\"{x:1558,y:573,t:1527268624833};\\\", \\\"{x:1560,y:573,t:1527268625778};\\\", \\\"{x:1561,y:573,t:1527268625786};\\\", \\\"{x:1568,y:573,t:1527268625802};\\\", \\\"{x:1573,y:573,t:1527268625818};\\\", \\\"{x:1580,y:573,t:1527268625836};\\\", \\\"{x:1584,y:573,t:1527268625853};\\\", \\\"{x:1588,y:573,t:1527268625868};\\\", \\\"{x:1589,y:573,t:1527268625885};\\\", \\\"{x:1590,y:573,t:1527268625902};\\\", \\\"{x:1591,y:573,t:1527268625919};\\\", \\\"{x:1593,y:573,t:1527268625935};\\\", \\\"{x:1598,y:573,t:1527268625952};\\\", \\\"{x:1600,y:573,t:1527268625968};\\\", \\\"{x:1603,y:573,t:1527268625985};\\\", \\\"{x:1605,y:573,t:1527268626002};\\\", \\\"{x:1607,y:573,t:1527268626019};\\\", \\\"{x:1610,y:573,t:1527268626036};\\\", \\\"{x:1612,y:573,t:1527268626052};\\\", \\\"{x:1615,y:573,t:1527268626068};\\\", \\\"{x:1616,y:573,t:1527268626085};\\\", \\\"{x:1617,y:573,t:1527268626102};\\\", \\\"{x:1616,y:571,t:1527268632098};\\\", \\\"{x:1610,y:571,t:1527268632107};\\\", \\\"{x:1589,y:571,t:1527268632123};\\\", \\\"{x:1550,y:571,t:1527268632139};\\\", \\\"{x:1483,y:571,t:1527268632156};\\\", \\\"{x:1389,y:571,t:1527268632173};\\\", \\\"{x:1291,y:571,t:1527268632190};\\\", \\\"{x:1189,y:571,t:1527268632205};\\\", \\\"{x:1092,y:571,t:1527268632223};\\\", \\\"{x:1000,y:571,t:1527268632240};\\\", \\\"{x:920,y:571,t:1527268632256};\\\", \\\"{x:808,y:571,t:1527268632273};\\\", \\\"{x:758,y:571,t:1527268632290};\\\", \\\"{x:705,y:571,t:1527268632306};\\\", \\\"{x:663,y:571,t:1527268632322};\\\", \\\"{x:624,y:571,t:1527268632340};\\\", \\\"{x:595,y:571,t:1527268632357};\\\", \\\"{x:567,y:571,t:1527268632373};\\\", \\\"{x:537,y:571,t:1527268632389};\\\", \\\"{x:508,y:571,t:1527268632406};\\\", \\\"{x:487,y:571,t:1527268632425};\\\", \\\"{x:466,y:571,t:1527268632440};\\\", \\\"{x:431,y:571,t:1527268632456};\\\", \\\"{x:412,y:571,t:1527268632474};\\\", \\\"{x:408,y:570,t:1527268632489};\\\", \\\"{x:407,y:570,t:1527268632507};\\\", \\\"{x:406,y:569,t:1527268632545};\\\", \\\"{x:405,y:568,t:1527268632569};\\\", \\\"{x:400,y:566,t:1527268632585};\\\", \\\"{x:398,y:566,t:1527268632593};\\\", \\\"{x:394,y:565,t:1527268632606};\\\", \\\"{x:381,y:564,t:1527268632624};\\\", \\\"{x:363,y:562,t:1527268632640};\\\", \\\"{x:328,y:559,t:1527268632658};\\\", \\\"{x:300,y:559,t:1527268632674};\\\", \\\"{x:275,y:559,t:1527268632690};\\\", \\\"{x:252,y:559,t:1527268632708};\\\", \\\"{x:232,y:558,t:1527268632724};\\\", \\\"{x:212,y:556,t:1527268632740};\\\", \\\"{x:192,y:553,t:1527268632757};\\\", \\\"{x:180,y:552,t:1527268632774};\\\", \\\"{x:172,y:551,t:1527268632791};\\\", \\\"{x:169,y:551,t:1527268632807};\\\", \\\"{x:169,y:550,t:1527268632824};\\\", \\\"{x:169,y:549,t:1527268632849};\\\", \\\"{x:173,y:547,t:1527268632857};\\\", \\\"{x:192,y:538,t:1527268632874};\\\", \\\"{x:220,y:530,t:1527268632891};\\\", \\\"{x:275,y:518,t:1527268632909};\\\", \\\"{x:336,y:503,t:1527268632923};\\\", \\\"{x:408,y:494,t:1527268632941};\\\", \\\"{x:502,y:482,t:1527268632958};\\\", \\\"{x:613,y:480,t:1527268632973};\\\", \\\"{x:702,y:480,t:1527268632990};\\\", \\\"{x:770,y:475,t:1527268633007};\\\", \\\"{x:808,y:475,t:1527268633024};\\\", \\\"{x:826,y:475,t:1527268633041};\\\", \\\"{x:827,y:475,t:1527268633097};\\\", \\\"{x:829,y:475,t:1527268633107};\\\", \\\"{x:839,y:475,t:1527268633124};\\\", \\\"{x:855,y:475,t:1527268633141};\\\", \\\"{x:869,y:475,t:1527268633157};\\\", \\\"{x:879,y:474,t:1527268633175};\\\", \\\"{x:879,y:473,t:1527268633466};\\\", \\\"{x:878,y:473,t:1527268633475};\\\", \\\"{x:869,y:472,t:1527268633491};\\\", \\\"{x:862,y:470,t:1527268633508};\\\", \\\"{x:856,y:469,t:1527268633524};\\\", \\\"{x:850,y:468,t:1527268633542};\\\", \\\"{x:848,y:468,t:1527268633600};\\\", \\\"{x:846,y:467,t:1527268633608};\\\", \\\"{x:844,y:467,t:1527268633624};\\\", \\\"{x:836,y:467,t:1527268633641};\\\", \\\"{x:835,y:467,t:1527268633657};\\\", \\\"{x:834,y:467,t:1527268633762};\\\", \\\"{x:835,y:466,t:1527268634754};\\\", \\\"{x:837,y:466,t:1527268634761};\\\", \\\"{x:839,y:466,t:1527268634775};\\\", \\\"{x:840,y:466,t:1527268634792};\\\", \\\"{x:845,y:466,t:1527268634810};\\\", \\\"{x:850,y:466,t:1527268634825};\\\", \\\"{x:859,y:466,t:1527268634842};\\\", \\\"{x:871,y:466,t:1527268634860};\\\", \\\"{x:884,y:466,t:1527268634876};\\\", \\\"{x:897,y:466,t:1527268634892};\\\", \\\"{x:913,y:466,t:1527268634909};\\\", \\\"{x:929,y:466,t:1527268634924};\\\", \\\"{x:948,y:466,t:1527268634942};\\\", \\\"{x:962,y:466,t:1527268634959};\\\", \\\"{x:979,y:467,t:1527268634975};\\\", \\\"{x:993,y:469,t:1527268634992};\\\", \\\"{x:1004,y:473,t:1527268635009};\\\", \\\"{x:1013,y:476,t:1527268635026};\\\", \\\"{x:1022,y:478,t:1527268635042};\\\", \\\"{x:1031,y:481,t:1527268635059};\\\", \\\"{x:1046,y:486,t:1527268635075};\\\", \\\"{x:1064,y:490,t:1527268635093};\\\", \\\"{x:1089,y:499,t:1527268635109};\\\", \\\"{x:1113,y:505,t:1527268635126};\\\", \\\"{x:1139,y:510,t:1527268635142};\\\", \\\"{x:1162,y:517,t:1527268635160};\\\", \\\"{x:1183,y:523,t:1527268635176};\\\", \\\"{x:1204,y:530,t:1527268635192};\\\", \\\"{x:1231,y:541,t:1527268635209};\\\", \\\"{x:1252,y:546,t:1527268635226};\\\", \\\"{x:1271,y:554,t:1527268635242};\\\", \\\"{x:1292,y:558,t:1527268635260};\\\", \\\"{x:1310,y:564,t:1527268635277};\\\", \\\"{x:1325,y:566,t:1527268635294};\\\", \\\"{x:1332,y:568,t:1527268635310};\\\", \\\"{x:1333,y:568,t:1527268635326};\\\", \\\"{x:1334,y:568,t:1527268635401};\\\", \\\"{x:1336,y:567,t:1527268635408};\\\", \\\"{x:1339,y:564,t:1527268635427};\\\", \\\"{x:1344,y:557,t:1527268635442};\\\", \\\"{x:1353,y:550,t:1527268635459};\\\", \\\"{x:1361,y:545,t:1527268635477};\\\", \\\"{x:1369,y:540,t:1527268635492};\\\", \\\"{x:1375,y:537,t:1527268635509};\\\", \\\"{x:1380,y:534,t:1527268635526};\\\", \\\"{x:1387,y:530,t:1527268635542};\\\", \\\"{x:1395,y:527,t:1527268635559};\\\", \\\"{x:1402,y:523,t:1527268635576};\\\", \\\"{x:1409,y:519,t:1527268635592};\\\", \\\"{x:1412,y:516,t:1527268635609};\\\", \\\"{x:1414,y:516,t:1527268635626};\\\", \\\"{x:1415,y:515,t:1527268635643};\\\", \\\"{x:1415,y:514,t:1527268635698};\\\", \\\"{x:1416,y:514,t:1527268638391};\\\", \\\"{x:1418,y:516,t:1527268638410};\\\", \\\"{x:1419,y:522,t:1527268638427};\\\", \\\"{x:1422,y:529,t:1527268638443};\\\", \\\"{x:1426,y:538,t:1527268638459};\\\", \\\"{x:1433,y:549,t:1527268638476};\\\", \\\"{x:1437,y:557,t:1527268638492};\\\", \\\"{x:1442,y:564,t:1527268638509};\\\", \\\"{x:1448,y:573,t:1527268638526};\\\", \\\"{x:1452,y:579,t:1527268638542};\\\", \\\"{x:1459,y:586,t:1527268638559};\\\", \\\"{x:1462,y:590,t:1527268638576};\\\", \\\"{x:1463,y:592,t:1527268638592};\\\", \\\"{x:1464,y:593,t:1527268638609};\\\", \\\"{x:1465,y:594,t:1527268638626};\\\", \\\"{x:1466,y:595,t:1527268638642};\\\", \\\"{x:1466,y:596,t:1527268638663};\\\", \\\"{x:1467,y:596,t:1527268638676};\\\", \\\"{x:1469,y:596,t:1527268638692};\\\", \\\"{x:1475,y:596,t:1527268638710};\\\", \\\"{x:1484,y:594,t:1527268638726};\\\", \\\"{x:1505,y:586,t:1527268638743};\\\", \\\"{x:1514,y:583,t:1527268638759};\\\", \\\"{x:1522,y:581,t:1527268638776};\\\", \\\"{x:1525,y:580,t:1527268638793};\\\", \\\"{x:1526,y:579,t:1527268638855};\\\", \\\"{x:1527,y:578,t:1527268638872};\\\", \\\"{x:1528,y:577,t:1527268638879};\\\", \\\"{x:1529,y:576,t:1527268638912};\\\", \\\"{x:1529,y:575,t:1527268639160};\\\", \\\"{x:1528,y:575,t:1527268639176};\\\", \\\"{x:1527,y:575,t:1527268644464};\\\", \\\"{x:1525,y:581,t:1527268644479};\\\", \\\"{x:1525,y:586,t:1527268644496};\\\", \\\"{x:1524,y:588,t:1527268644513};\\\", \\\"{x:1523,y:590,t:1527268644529};\\\", \\\"{x:1523,y:592,t:1527268644550};\\\", \\\"{x:1523,y:593,t:1527268644566};\\\", \\\"{x:1523,y:594,t:1527268644579};\\\", \\\"{x:1523,y:595,t:1527268644595};\\\", \\\"{x:1522,y:597,t:1527268644613};\\\", \\\"{x:1522,y:598,t:1527268644630};\\\", \\\"{x:1521,y:601,t:1527268644646};\\\", \\\"{x:1521,y:602,t:1527268644662};\\\", \\\"{x:1521,y:605,t:1527268644680};\\\", \\\"{x:1521,y:606,t:1527268644696};\\\", \\\"{x:1521,y:609,t:1527268644713};\\\", \\\"{x:1521,y:611,t:1527268644730};\\\", \\\"{x:1521,y:614,t:1527268644746};\\\", \\\"{x:1521,y:616,t:1527268644762};\\\", \\\"{x:1521,y:618,t:1527268644779};\\\", \\\"{x:1521,y:621,t:1527268644796};\\\", \\\"{x:1521,y:623,t:1527268644812};\\\", \\\"{x:1521,y:625,t:1527268644829};\\\", \\\"{x:1522,y:627,t:1527268644845};\\\", \\\"{x:1522,y:630,t:1527268644862};\\\", \\\"{x:1522,y:633,t:1527268644880};\\\", \\\"{x:1522,y:635,t:1527268644896};\\\", \\\"{x:1522,y:638,t:1527268644913};\\\", \\\"{x:1522,y:639,t:1527268644930};\\\", \\\"{x:1522,y:641,t:1527268644945};\\\", \\\"{x:1522,y:642,t:1527268644990};\\\", \\\"{x:1522,y:643,t:1527268645135};\\\", \\\"{x:1523,y:644,t:1527268645152};\\\", \\\"{x:1523,y:645,t:1527268645311};\\\", \\\"{x:1523,y:646,t:1527268645415};\\\", \\\"{x:1524,y:647,t:1527268645430};\\\", \\\"{x:1524,y:648,t:1527268645455};\\\", \\\"{x:1524,y:649,t:1527268645471};\\\", \\\"{x:1524,y:650,t:1527268645503};\\\", \\\"{x:1524,y:651,t:1527268645519};\\\", \\\"{x:1525,y:652,t:1527268645530};\\\", \\\"{x:1525,y:653,t:1527268645551};\\\", \\\"{x:1525,y:654,t:1527268645566};\\\", \\\"{x:1525,y:656,t:1527268645581};\\\", \\\"{x:1525,y:657,t:1527268645599};\\\", \\\"{x:1525,y:659,t:1527268645615};\\\", \\\"{x:1525,y:661,t:1527268645630};\\\", \\\"{x:1525,y:662,t:1527268645648};\\\", \\\"{x:1525,y:663,t:1527268645665};\\\", \\\"{x:1525,y:665,t:1527268645681};\\\", \\\"{x:1526,y:665,t:1527268645698};\\\", \\\"{x:1526,y:667,t:1527268645714};\\\", \\\"{x:1527,y:668,t:1527268645731};\\\", \\\"{x:1527,y:669,t:1527268645748};\\\", \\\"{x:1527,y:670,t:1527268645765};\\\", \\\"{x:1527,y:672,t:1527268645781};\\\", \\\"{x:1527,y:674,t:1527268645798};\\\", \\\"{x:1527,y:677,t:1527268645815};\\\", \\\"{x:1527,y:680,t:1527268645831};\\\", \\\"{x:1527,y:686,t:1527268645847};\\\", \\\"{x:1526,y:690,t:1527268645865};\\\", \\\"{x:1525,y:695,t:1527268645881};\\\", \\\"{x:1523,y:699,t:1527268645897};\\\", \\\"{x:1522,y:704,t:1527268645914};\\\", \\\"{x:1522,y:707,t:1527268645931};\\\", \\\"{x:1520,y:710,t:1527268645948};\\\", \\\"{x:1520,y:712,t:1527268645964};\\\", \\\"{x:1519,y:715,t:1527268645981};\\\", \\\"{x:1517,y:719,t:1527268645998};\\\", \\\"{x:1516,y:724,t:1527268646014};\\\", \\\"{x:1513,y:731,t:1527268646031};\\\", \\\"{x:1512,y:734,t:1527268646047};\\\", \\\"{x:1510,y:738,t:1527268646065};\\\", \\\"{x:1507,y:742,t:1527268646081};\\\", \\\"{x:1505,y:745,t:1527268646097};\\\", \\\"{x:1502,y:749,t:1527268646114};\\\", \\\"{x:1499,y:752,t:1527268646131};\\\", \\\"{x:1497,y:753,t:1527268646147};\\\", \\\"{x:1493,y:756,t:1527268646164};\\\", \\\"{x:1491,y:757,t:1527268646183};\\\", \\\"{x:1489,y:758,t:1527268646198};\\\", \\\"{x:1483,y:762,t:1527268646215};\\\", \\\"{x:1479,y:764,t:1527268646231};\\\", \\\"{x:1475,y:767,t:1527268646248};\\\", \\\"{x:1471,y:770,t:1527268646265};\\\", \\\"{x:1468,y:771,t:1527268646281};\\\", \\\"{x:1468,y:772,t:1527268646297};\\\", \\\"{x:1468,y:773,t:1527268646384};\\\", \\\"{x:1468,y:774,t:1527268646503};\\\", \\\"{x:1467,y:775,t:1527268646514};\\\", \\\"{x:1467,y:776,t:1527268646551};\\\", \\\"{x:1468,y:776,t:1527268647079};\\\", \\\"{x:1469,y:776,t:1527268647095};\\\", \\\"{x:1471,y:776,t:1527268647103};\\\", \\\"{x:1472,y:776,t:1527268647118};\\\", \\\"{x:1473,y:776,t:1527268647327};\\\", \\\"{x:1476,y:775,t:1527268647335};\\\", \\\"{x:1480,y:773,t:1527268647349};\\\", \\\"{x:1487,y:772,t:1527268647366};\\\", \\\"{x:1491,y:772,t:1527268647381};\\\", \\\"{x:1497,y:772,t:1527268647399};\\\", \\\"{x:1499,y:772,t:1527268647415};\\\", \\\"{x:1500,y:772,t:1527268647432};\\\", \\\"{x:1501,y:771,t:1527268647471};\\\", \\\"{x:1504,y:770,t:1527268647495};\\\", \\\"{x:1505,y:770,t:1527268647503};\\\", \\\"{x:1507,y:770,t:1527268647515};\\\", \\\"{x:1510,y:769,t:1527268647531};\\\", \\\"{x:1512,y:768,t:1527268647548};\\\", \\\"{x:1515,y:768,t:1527268647566};\\\", \\\"{x:1517,y:768,t:1527268647581};\\\", \\\"{x:1520,y:768,t:1527268647598};\\\", \\\"{x:1524,y:768,t:1527268647614};\\\", \\\"{x:1528,y:768,t:1527268647632};\\\", \\\"{x:1531,y:768,t:1527268647649};\\\", \\\"{x:1533,y:768,t:1527268647666};\\\", \\\"{x:1534,y:768,t:1527268647681};\\\", \\\"{x:1536,y:768,t:1527268647744};\\\", \\\"{x:1538,y:768,t:1527268647750};\\\", \\\"{x:1540,y:768,t:1527268647767};\\\", \\\"{x:1541,y:768,t:1527268647782};\\\", \\\"{x:1543,y:768,t:1527268647872};\\\", \\\"{x:1544,y:769,t:1527268647903};\\\", \\\"{x:1545,y:769,t:1527268647916};\\\", \\\"{x:1547,y:771,t:1527268647932};\\\", \\\"{x:1549,y:773,t:1527268647948};\\\", \\\"{x:1552,y:774,t:1527268647966};\\\", \\\"{x:1553,y:774,t:1527268647982};\\\", \\\"{x:1554,y:774,t:1527268648072};\\\", \\\"{x:1554,y:775,t:1527268648087};\\\", \\\"{x:1557,y:776,t:1527268648103};\\\", \\\"{x:1561,y:776,t:1527268648115};\\\", \\\"{x:1570,y:776,t:1527268648133};\\\", \\\"{x:1577,y:777,t:1527268648149};\\\", \\\"{x:1583,y:777,t:1527268648166};\\\", \\\"{x:1588,y:777,t:1527268648182};\\\", \\\"{x:1590,y:777,t:1527268648248};\\\", \\\"{x:1592,y:777,t:1527268648255};\\\", \\\"{x:1595,y:777,t:1527268648265};\\\", \\\"{x:1597,y:777,t:1527268648283};\\\", \\\"{x:1601,y:777,t:1527268648300};\\\", \\\"{x:1606,y:777,t:1527268648315};\\\", \\\"{x:1607,y:777,t:1527268648332};\\\", \\\"{x:1611,y:777,t:1527268648349};\\\", \\\"{x:1615,y:777,t:1527268648366};\\\", \\\"{x:1620,y:777,t:1527268648382};\\\", \\\"{x:1619,y:776,t:1527268648599};\\\", \\\"{x:1617,y:776,t:1527268648616};\\\", \\\"{x:1612,y:776,t:1527268648633};\\\", \\\"{x:1607,y:775,t:1527268648649};\\\", \\\"{x:1602,y:773,t:1527268648665};\\\", \\\"{x:1600,y:772,t:1527268648682};\\\", \\\"{x:1599,y:772,t:1527268648701};\\\", \\\"{x:1600,y:772,t:1527268648846};\\\", \\\"{x:1601,y:772,t:1527268648863};\\\", \\\"{x:1602,y:772,t:1527268648870};\\\", \\\"{x:1603,y:772,t:1527268648887};\\\", \\\"{x:1605,y:772,t:1527268648899};\\\", \\\"{x:1606,y:772,t:1527268648916};\\\", \\\"{x:1609,y:773,t:1527268648933};\\\", \\\"{x:1609,y:772,t:1527268649936};\\\", \\\"{x:1600,y:769,t:1527268649951};\\\", \\\"{x:1586,y:767,t:1527268649967};\\\", \\\"{x:1557,y:757,t:1527268649984};\\\", \\\"{x:1506,y:741,t:1527268650001};\\\", \\\"{x:1418,y:718,t:1527268650017};\\\", \\\"{x:1321,y:693,t:1527268650033};\\\", \\\"{x:1208,y:662,t:1527268650051};\\\", \\\"{x:1084,y:630,t:1527268650066};\\\", \\\"{x:967,y:605,t:1527268650084};\\\", \\\"{x:860,y:585,t:1527268650100};\\\", \\\"{x:798,y:575,t:1527268650116};\\\", \\\"{x:772,y:571,t:1527268650134};\\\", \\\"{x:761,y:568,t:1527268650151};\\\", \\\"{x:758,y:566,t:1527268650166};\\\", \\\"{x:753,y:564,t:1527268650184};\\\", \\\"{x:744,y:560,t:1527268650201};\\\", \\\"{x:732,y:555,t:1527268650218};\\\", \\\"{x:723,y:551,t:1527268650233};\\\", \\\"{x:718,y:548,t:1527268650250};\\\", \\\"{x:707,y:546,t:1527268650268};\\\", \\\"{x:694,y:541,t:1527268650284};\\\", \\\"{x:674,y:537,t:1527268650301};\\\", \\\"{x:663,y:536,t:1527268650318};\\\", \\\"{x:655,y:534,t:1527268650335};\\\", \\\"{x:653,y:534,t:1527268650352};\\\", \\\"{x:650,y:534,t:1527268650368};\\\", \\\"{x:649,y:534,t:1527268650390};\\\", \\\"{x:647,y:534,t:1527268650402};\\\", \\\"{x:643,y:534,t:1527268650419};\\\", \\\"{x:635,y:536,t:1527268650435};\\\", \\\"{x:628,y:538,t:1527268650452};\\\", \\\"{x:620,y:541,t:1527268650469};\\\", \\\"{x:613,y:542,t:1527268650486};\\\", \\\"{x:608,y:542,t:1527268650502};\\\", \\\"{x:604,y:544,t:1527268650519};\\\", \\\"{x:603,y:544,t:1527268650542};\\\", \\\"{x:602,y:544,t:1527268650838};\\\", \\\"{x:602,y:545,t:1527268650910};\\\", \\\"{x:603,y:546,t:1527268650967};\\\", \\\"{x:604,y:546,t:1527268650990};\\\", \\\"{x:604,y:547,t:1527268651002};\\\", \\\"{x:606,y:547,t:1527268651020};\\\", \\\"{x:609,y:548,t:1527268651036};\\\", \\\"{x:619,y:551,t:1527268651052};\\\", \\\"{x:634,y:554,t:1527268651070};\\\", \\\"{x:659,y:557,t:1527268651087};\\\", \\\"{x:681,y:562,t:1527268651103};\\\", \\\"{x:700,y:564,t:1527268651119};\\\", \\\"{x:721,y:567,t:1527268651136};\\\", \\\"{x:736,y:569,t:1527268651153};\\\", \\\"{x:749,y:572,t:1527268651169};\\\", \\\"{x:765,y:575,t:1527268651186};\\\", \\\"{x:785,y:582,t:1527268651203};\\\", \\\"{x:804,y:589,t:1527268651219};\\\", \\\"{x:827,y:594,t:1527268651236};\\\", \\\"{x:853,y:602,t:1527268651253};\\\", \\\"{x:883,y:609,t:1527268651269};\\\", \\\"{x:943,y:629,t:1527268651286};\\\", \\\"{x:988,y:643,t:1527268651303};\\\", \\\"{x:1029,y:653,t:1527268651319};\\\", \\\"{x:1061,y:663,t:1527268651336};\\\", \\\"{x:1094,y:672,t:1527268651353};\\\", \\\"{x:1125,y:680,t:1527268651370};\\\", \\\"{x:1151,y:688,t:1527268651386};\\\", \\\"{x:1176,y:696,t:1527268651404};\\\", \\\"{x:1198,y:704,t:1527268651419};\\\", \\\"{x:1218,y:714,t:1527268651436};\\\", \\\"{x:1232,y:722,t:1527268651453};\\\", \\\"{x:1248,y:727,t:1527268651470};\\\", \\\"{x:1266,y:736,t:1527268651486};\\\", \\\"{x:1268,y:740,t:1527268651503};\\\", \\\"{x:1268,y:741,t:1527268651527};\\\", \\\"{x:1268,y:742,t:1527268651559};\\\", \\\"{x:1268,y:743,t:1527268651571};\\\", \\\"{x:1269,y:743,t:1527268652728};\\\", \\\"{x:1271,y:743,t:1527268656903};\\\", \\\"{x:1275,y:743,t:1527268656911};\\\", \\\"{x:1283,y:743,t:1527268656926};\\\", \\\"{x:1295,y:743,t:1527268656941};\\\", \\\"{x:1310,y:743,t:1527268656958};\\\", \\\"{x:1329,y:743,t:1527268656975};\\\", \\\"{x:1335,y:743,t:1527268656991};\\\", \\\"{x:1337,y:743,t:1527268657008};\\\", \\\"{x:1339,y:743,t:1527268657025};\\\", \\\"{x:1340,y:743,t:1527268657041};\\\", \\\"{x:1343,y:743,t:1527268657058};\\\", \\\"{x:1345,y:742,t:1527268657078};\\\", \\\"{x:1348,y:742,t:1527268657090};\\\", \\\"{x:1353,y:742,t:1527268657108};\\\", \\\"{x:1358,y:741,t:1527268657125};\\\", \\\"{x:1365,y:738,t:1527268657141};\\\", \\\"{x:1373,y:737,t:1527268657158};\\\", \\\"{x:1387,y:732,t:1527268657175};\\\", \\\"{x:1391,y:730,t:1527268657191};\\\", \\\"{x:1396,y:729,t:1527268657209};\\\", \\\"{x:1401,y:728,t:1527268657225};\\\", \\\"{x:1405,y:726,t:1527268657242};\\\", \\\"{x:1409,y:726,t:1527268657258};\\\", \\\"{x:1415,y:725,t:1527268657275};\\\", \\\"{x:1418,y:724,t:1527268657292};\\\", \\\"{x:1423,y:724,t:1527268657308};\\\", \\\"{x:1428,y:722,t:1527268657325};\\\", \\\"{x:1431,y:722,t:1527268657342};\\\", \\\"{x:1434,y:722,t:1527268657358};\\\", \\\"{x:1440,y:719,t:1527268657374};\\\", \\\"{x:1442,y:719,t:1527268657392};\\\", \\\"{x:1444,y:718,t:1527268657415};\\\", \\\"{x:1444,y:717,t:1527268657438};\\\", \\\"{x:1445,y:717,t:1527268657471};\\\", \\\"{x:1445,y:716,t:1527268657489};\\\", \\\"{x:1445,y:715,t:1527268657502};\\\", \\\"{x:1445,y:714,t:1527268657703};\\\", \\\"{x:1445,y:713,t:1527268657710};\\\", \\\"{x:1448,y:713,t:1527268657727};\\\", \\\"{x:1449,y:713,t:1527268657742};\\\", \\\"{x:1453,y:712,t:1527268657759};\\\", \\\"{x:1455,y:711,t:1527268657775};\\\", \\\"{x:1457,y:710,t:1527268657792};\\\", \\\"{x:1460,y:709,t:1527268657809};\\\", \\\"{x:1461,y:709,t:1527268657825};\\\", \\\"{x:1465,y:709,t:1527268657842};\\\", \\\"{x:1468,y:708,t:1527268657859};\\\", \\\"{x:1473,y:706,t:1527268657874};\\\", \\\"{x:1479,y:705,t:1527268657892};\\\", \\\"{x:1486,y:705,t:1527268657909};\\\", \\\"{x:1494,y:704,t:1527268657925};\\\", \\\"{x:1500,y:701,t:1527268657942};\\\", \\\"{x:1508,y:700,t:1527268657959};\\\", \\\"{x:1510,y:698,t:1527268657975};\\\", \\\"{x:1513,y:697,t:1527268657992};\\\", \\\"{x:1516,y:696,t:1527268658009};\\\", \\\"{x:1517,y:695,t:1527268658040};\\\", \\\"{x:1518,y:695,t:1527268658054};\\\", \\\"{x:1518,y:694,t:1527268658071};\\\", \\\"{x:1519,y:694,t:1527268658078};\\\", \\\"{x:1522,y:693,t:1527268660336};\\\", \\\"{x:1524,y:693,t:1527268660344};\\\", \\\"{x:1536,y:691,t:1527268660361};\\\", \\\"{x:1547,y:690,t:1527268660377};\\\", \\\"{x:1560,y:690,t:1527268660394};\\\", \\\"{x:1568,y:689,t:1527268660411};\\\", \\\"{x:1574,y:689,t:1527268660426};\\\", \\\"{x:1576,y:689,t:1527268660443};\\\", \\\"{x:1578,y:689,t:1527268660460};\\\", \\\"{x:1579,y:689,t:1527268660476};\\\", \\\"{x:1583,y:689,t:1527268660494};\\\", \\\"{x:1590,y:689,t:1527268660510};\\\", \\\"{x:1599,y:689,t:1527268660526};\\\", \\\"{x:1608,y:689,t:1527268660544};\\\", \\\"{x:1621,y:689,t:1527268660560};\\\", \\\"{x:1631,y:689,t:1527268660576};\\\", \\\"{x:1635,y:689,t:1527268660594};\\\", \\\"{x:1637,y:689,t:1527268660611};\\\", \\\"{x:1638,y:689,t:1527268660627};\\\", \\\"{x:1640,y:689,t:1527268660671};\\\", \\\"{x:1641,y:690,t:1527268660703};\\\", \\\"{x:1642,y:690,t:1527268660710};\\\", \\\"{x:1643,y:692,t:1527268660727};\\\", \\\"{x:1645,y:694,t:1527268660743};\\\", \\\"{x:1647,y:698,t:1527268660761};\\\", \\\"{x:1647,y:699,t:1527268660777};\\\", \\\"{x:1648,y:700,t:1527268660793};\\\", \\\"{x:1649,y:702,t:1527268660814};\\\", \\\"{x:1649,y:703,t:1527268660839};\\\", \\\"{x:1650,y:704,t:1527268660846};\\\", \\\"{x:1651,y:705,t:1527268660871};\\\", \\\"{x:1649,y:705,t:1527268662494};\\\", \\\"{x:1634,y:705,t:1527268662512};\\\", \\\"{x:1608,y:705,t:1527268662528};\\\", \\\"{x:1570,y:705,t:1527268662546};\\\", \\\"{x:1506,y:705,t:1527268662562};\\\", \\\"{x:1442,y:704,t:1527268662579};\\\", \\\"{x:1374,y:701,t:1527268662596};\\\", \\\"{x:1312,y:701,t:1527268662611};\\\", \\\"{x:1270,y:701,t:1527268662629};\\\", \\\"{x:1246,y:698,t:1527268662646};\\\", \\\"{x:1227,y:698,t:1527268662662};\\\", \\\"{x:1203,y:698,t:1527268662679};\\\", \\\"{x:1188,y:698,t:1527268662696};\\\", \\\"{x:1170,y:698,t:1527268662712};\\\", \\\"{x:1143,y:698,t:1527268662729};\\\", \\\"{x:1112,y:698,t:1527268662745};\\\", \\\"{x:1064,y:698,t:1527268662762};\\\", \\\"{x:1014,y:698,t:1527268662779};\\\", \\\"{x:961,y:698,t:1527268662796};\\\", \\\"{x:916,y:698,t:1527268662812};\\\", \\\"{x:877,y:698,t:1527268662829};\\\", \\\"{x:846,y:698,t:1527268662845};\\\", \\\"{x:822,y:698,t:1527268662861};\\\", \\\"{x:782,y:702,t:1527268662879};\\\", \\\"{x:753,y:708,t:1527268662896};\\\", \\\"{x:731,y:711,t:1527268662912};\\\", \\\"{x:707,y:713,t:1527268662929};\\\", \\\"{x:684,y:715,t:1527268662946};\\\", \\\"{x:664,y:717,t:1527268662962};\\\", \\\"{x:644,y:717,t:1527268662979};\\\", \\\"{x:627,y:717,t:1527268662996};\\\", \\\"{x:610,y:712,t:1527268663013};\\\", \\\"{x:596,y:711,t:1527268663029};\\\", \\\"{x:577,y:709,t:1527268663047};\\\", \\\"{x:562,y:705,t:1527268663063};\\\", \\\"{x:550,y:701,t:1527268663078};\\\", \\\"{x:540,y:696,t:1527268663095};\\\", \\\"{x:536,y:694,t:1527268663112};\\\", \\\"{x:532,y:691,t:1527268663129};\\\", \\\"{x:527,y:688,t:1527268663145};\\\", \\\"{x:523,y:684,t:1527268663162};\\\", \\\"{x:513,y:680,t:1527268663178};\\\", \\\"{x:508,y:676,t:1527268663196};\\\", \\\"{x:507,y:675,t:1527268663213};\\\", \\\"{x:505,y:672,t:1527268663230};\\\", \\\"{x:505,y:669,t:1527268663246};\\\", \\\"{x:505,y:666,t:1527268663263};\\\", \\\"{x:505,y:664,t:1527268663279};\\\", \\\"{x:504,y:663,t:1527268663296};\\\", \\\"{x:504,y:664,t:1527268663799};\\\", \\\"{x:504,y:667,t:1527268663813};\\\", \\\"{x:506,y:679,t:1527268663830};\\\", \\\"{x:506,y:686,t:1527268663846};\\\", \\\"{x:506,y:692,t:1527268663864};\\\", \\\"{x:507,y:697,t:1527268663880};\\\", \\\"{x:507,y:699,t:1527268663897};\\\", \\\"{x:507,y:701,t:1527268663914};\\\", \\\"{x:507,y:702,t:1527268663930};\\\", \\\"{x:507,y:704,t:1527268663947};\\\" ] }, { \\\"rt\\\": 106414, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 9, \\\"time_elapsed\\\": 313837, \\\"internal_node_id\\\": \\\"0.0-5.0-4.0\\\", \\\"subject\\\": \\\"YC7SX\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"mike\\\", \\\"condition\\\": \\\"115-late\\\", \\\"scenario\\\": \\\"acme\\\", \\\"question\\\": \\\"midpoint\\\", \\\"q\\\": 5, \\\"clicks\\\": 1, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XFull-YFull\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 0, \\\"answer\\\": [ \\\"F\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"X \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"U \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-Z -Z -I -O -O -I -F -F -06 PM-12 PM-C -A -01 PM-01 PM-K \\\", \\\"block\\\": \\\"triangular_scaffolded\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:507,y:705,t:1527268670127};\\\", \\\"{x:515,y:710,t:1527268672815};\\\", \\\"{x:538,y:721,t:1527268672823};\\\", \\\"{x:572,y:730,t:1527268672837};\\\", \\\"{x:642,y:744,t:1527268672854};\\\", \\\"{x:758,y:762,t:1527268672872};\\\", \\\"{x:845,y:776,t:1527268672887};\\\", \\\"{x:920,y:788,t:1527268672904};\\\", \\\"{x:979,y:796,t:1527268672920};\\\", \\\"{x:1029,y:804,t:1527268672937};\\\", \\\"{x:1063,y:810,t:1527268672954};\\\", \\\"{x:1084,y:811,t:1527268672971};\\\", \\\"{x:1098,y:814,t:1527268672987};\\\", \\\"{x:1111,y:815,t:1527268673003};\\\", \\\"{x:1119,y:816,t:1527268673021};\\\", \\\"{x:1132,y:817,t:1527268673036};\\\", \\\"{x:1150,y:819,t:1527268673054};\\\", \\\"{x:1185,y:822,t:1527268673072};\\\", \\\"{x:1213,y:826,t:1527268673086};\\\", \\\"{x:1246,y:828,t:1527268673103};\\\", \\\"{x:1282,y:834,t:1527268673121};\\\", \\\"{x:1311,y:839,t:1527268673137};\\\", \\\"{x:1332,y:842,t:1527268673154};\\\", \\\"{x:1349,y:845,t:1527268673173};\\\", \\\"{x:1354,y:845,t:1527268673188};\\\", \\\"{x:1350,y:845,t:1527268673312};\\\", \\\"{x:1345,y:843,t:1527268673320};\\\", \\\"{x:1336,y:838,t:1527268673338};\\\", \\\"{x:1330,y:837,t:1527268673353};\\\", \\\"{x:1328,y:836,t:1527268673371};\\\", \\\"{x:1328,y:835,t:1527268682063};\\\", \\\"{x:1330,y:825,t:1527268682077};\\\", \\\"{x:1341,y:762,t:1527268682095};\\\", \\\"{x:1355,y:697,t:1527268682110};\\\", \\\"{x:1372,y:636,t:1527268682127};\\\", \\\"{x:1383,y:584,t:1527268682144};\\\", \\\"{x:1387,y:551,t:1527268682160};\\\", \\\"{x:1393,y:526,t:1527268682177};\\\", \\\"{x:1396,y:506,t:1527268682194};\\\", \\\"{x:1397,y:496,t:1527268682210};\\\", \\\"{x:1398,y:491,t:1527268682227};\\\", \\\"{x:1399,y:486,t:1527268682244};\\\", \\\"{x:1399,y:481,t:1527268682260};\\\", \\\"{x:1399,y:476,t:1527268682277};\\\", \\\"{x:1399,y:469,t:1527268682293};\\\", \\\"{x:1397,y:466,t:1527268682309};\\\", \\\"{x:1395,y:464,t:1527268682326};\\\", \\\"{x:1392,y:461,t:1527268682343};\\\", \\\"{x:1389,y:458,t:1527268682360};\\\", \\\"{x:1387,y:456,t:1527268682377};\\\", \\\"{x:1384,y:453,t:1527268682393};\\\", \\\"{x:1382,y:451,t:1527268682410};\\\", \\\"{x:1378,y:451,t:1527268682426};\\\", \\\"{x:1375,y:449,t:1527268682444};\\\", \\\"{x:1372,y:449,t:1527268682461};\\\", \\\"{x:1369,y:449,t:1527268682477};\\\", \\\"{x:1360,y:448,t:1527268682494};\\\", \\\"{x:1351,y:447,t:1527268682510};\\\", \\\"{x:1342,y:447,t:1527268682527};\\\", \\\"{x:1335,y:447,t:1527268682543};\\\", \\\"{x:1331,y:447,t:1527268682560};\\\", \\\"{x:1327,y:447,t:1527268682576};\\\", \\\"{x:1326,y:447,t:1527268682593};\\\", \\\"{x:1325,y:447,t:1527268682611};\\\", \\\"{x:1322,y:447,t:1527268682627};\\\", \\\"{x:1319,y:447,t:1527268682662};\\\", \\\"{x:1318,y:447,t:1527268682677};\\\", \\\"{x:1312,y:447,t:1527268682694};\\\", \\\"{x:1309,y:447,t:1527268682711};\\\", \\\"{x:1307,y:447,t:1527268682727};\\\", \\\"{x:1306,y:447,t:1527268682744};\\\", \\\"{x:1306,y:446,t:1527268683847};\\\", \\\"{x:1306,y:447,t:1527268685126};\\\", \\\"{x:1307,y:449,t:1527268685135};\\\", \\\"{x:1308,y:451,t:1527268685146};\\\", \\\"{x:1308,y:455,t:1527268685162};\\\", \\\"{x:1308,y:459,t:1527268685180};\\\", \\\"{x:1308,y:461,t:1527268685196};\\\", \\\"{x:1308,y:466,t:1527268685212};\\\", \\\"{x:1308,y:468,t:1527268685229};\\\", \\\"{x:1308,y:472,t:1527268685246};\\\", \\\"{x:1308,y:476,t:1527268685263};\\\", \\\"{x:1308,y:479,t:1527268685280};\\\", \\\"{x:1308,y:483,t:1527268685296};\\\", \\\"{x:1308,y:486,t:1527268685313};\\\", \\\"{x:1309,y:491,t:1527268685329};\\\", \\\"{x:1309,y:496,t:1527268685346};\\\", \\\"{x:1310,y:500,t:1527268685363};\\\", \\\"{x:1310,y:505,t:1527268685379};\\\", \\\"{x:1311,y:509,t:1527268685396};\\\", \\\"{x:1314,y:517,t:1527268685413};\\\", \\\"{x:1317,y:523,t:1527268685429};\\\", \\\"{x:1321,y:539,t:1527268685446};\\\", \\\"{x:1325,y:549,t:1527268685463};\\\", \\\"{x:1326,y:558,t:1527268685478};\\\", \\\"{x:1329,y:571,t:1527268685496};\\\", \\\"{x:1331,y:577,t:1527268685513};\\\", \\\"{x:1332,y:584,t:1527268685528};\\\", \\\"{x:1333,y:588,t:1527268685546};\\\", \\\"{x:1333,y:593,t:1527268685562};\\\", \\\"{x:1333,y:599,t:1527268685579};\\\", \\\"{x:1333,y:602,t:1527268685596};\\\", \\\"{x:1333,y:604,t:1527268685612};\\\", \\\"{x:1333,y:607,t:1527268685629};\\\", \\\"{x:1333,y:611,t:1527268685646};\\\", \\\"{x:1333,y:613,t:1527268685663};\\\", \\\"{x:1332,y:616,t:1527268685680};\\\", \\\"{x:1331,y:620,t:1527268685696};\\\", \\\"{x:1330,y:622,t:1527268685713};\\\", \\\"{x:1329,y:626,t:1527268685729};\\\", \\\"{x:1329,y:628,t:1527268685746};\\\", \\\"{x:1329,y:631,t:1527268685762};\\\", \\\"{x:1327,y:634,t:1527268685780};\\\", \\\"{x:1327,y:638,t:1527268685796};\\\", \\\"{x:1326,y:642,t:1527268685813};\\\", \\\"{x:1325,y:649,t:1527268685830};\\\", \\\"{x:1325,y:653,t:1527268685846};\\\", \\\"{x:1323,y:659,t:1527268685863};\\\", \\\"{x:1323,y:662,t:1527268685880};\\\", \\\"{x:1322,y:668,t:1527268685896};\\\", \\\"{x:1321,y:674,t:1527268685913};\\\", \\\"{x:1321,y:681,t:1527268685930};\\\", \\\"{x:1318,y:689,t:1527268685946};\\\", \\\"{x:1316,y:697,t:1527268685963};\\\", \\\"{x:1316,y:704,t:1527268685980};\\\", \\\"{x:1316,y:707,t:1527268685996};\\\", \\\"{x:1316,y:710,t:1527268686014};\\\", \\\"{x:1316,y:713,t:1527268686030};\\\", \\\"{x:1316,y:714,t:1527268686046};\\\", \\\"{x:1316,y:718,t:1527268686063};\\\", \\\"{x:1316,y:719,t:1527268686080};\\\", \\\"{x:1316,y:722,t:1527268686096};\\\", \\\"{x:1316,y:724,t:1527268686113};\\\", \\\"{x:1317,y:727,t:1527268686131};\\\", \\\"{x:1317,y:728,t:1527268686150};\\\", \\\"{x:1317,y:730,t:1527268686166};\\\", \\\"{x:1317,y:732,t:1527268686180};\\\", \\\"{x:1318,y:735,t:1527268686196};\\\", \\\"{x:1321,y:740,t:1527268686213};\\\", \\\"{x:1321,y:742,t:1527268686230};\\\", \\\"{x:1321,y:746,t:1527268686246};\\\", \\\"{x:1321,y:749,t:1527268686263};\\\", \\\"{x:1321,y:751,t:1527268686280};\\\", \\\"{x:1321,y:753,t:1527268686297};\\\", \\\"{x:1321,y:755,t:1527268686313};\\\", \\\"{x:1321,y:758,t:1527268686330};\\\", \\\"{x:1322,y:761,t:1527268686347};\\\", \\\"{x:1322,y:762,t:1527268686364};\\\", \\\"{x:1322,y:764,t:1527268686380};\\\", \\\"{x:1322,y:765,t:1527268686397};\\\", \\\"{x:1322,y:768,t:1527268686414};\\\", \\\"{x:1322,y:771,t:1527268686430};\\\", \\\"{x:1321,y:776,t:1527268686447};\\\", \\\"{x:1321,y:779,t:1527268686463};\\\", \\\"{x:1321,y:782,t:1527268686480};\\\", \\\"{x:1320,y:785,t:1527268686497};\\\", \\\"{x:1320,y:786,t:1527268686518};\\\", \\\"{x:1318,y:790,t:1527268686530};\\\", \\\"{x:1318,y:792,t:1527268686547};\\\", \\\"{x:1318,y:794,t:1527268686599};\\\", \\\"{x:1318,y:795,t:1527268686613};\\\", \\\"{x:1316,y:801,t:1527268686630};\\\", \\\"{x:1316,y:803,t:1527268686647};\\\", \\\"{x:1315,y:806,t:1527268686663};\\\", \\\"{x:1314,y:811,t:1527268686681};\\\", \\\"{x:1314,y:814,t:1527268686697};\\\", \\\"{x:1314,y:817,t:1527268686714};\\\", \\\"{x:1312,y:819,t:1527268686731};\\\", \\\"{x:1310,y:821,t:1527268686747};\\\", \\\"{x:1310,y:823,t:1527268686774};\\\", \\\"{x:1310,y:824,t:1527268686782};\\\", \\\"{x:1308,y:827,t:1527268686798};\\\", \\\"{x:1308,y:828,t:1527268686814};\\\", \\\"{x:1307,y:828,t:1527268686831};\\\", \\\"{x:1306,y:828,t:1527268686863};\\\", \\\"{x:1305,y:828,t:1527268686951};\\\", \\\"{x:1304,y:828,t:1527268686967};\\\", \\\"{x:1305,y:830,t:1527268687006};\\\", \\\"{x:1306,y:831,t:1527268687015};\\\", \\\"{x:1309,y:833,t:1527268687030};\\\", \\\"{x:1309,y:834,t:1527268687087};\\\", \\\"{x:1309,y:835,t:1527268687102};\\\", \\\"{x:1309,y:838,t:1527268687134};\\\", \\\"{x:1313,y:842,t:1527268687147};\\\", \\\"{x:1314,y:850,t:1527268687165};\\\", \\\"{x:1317,y:855,t:1527268687180};\\\", \\\"{x:1317,y:859,t:1527268687198};\\\", \\\"{x:1317,y:865,t:1527268687215};\\\", \\\"{x:1316,y:869,t:1527268687230};\\\", \\\"{x:1315,y:877,t:1527268687247};\\\", \\\"{x:1311,y:883,t:1527268687264};\\\", \\\"{x:1309,y:890,t:1527268687282};\\\", \\\"{x:1307,y:894,t:1527268687297};\\\", \\\"{x:1307,y:896,t:1527268687315};\\\", \\\"{x:1304,y:900,t:1527268687331};\\\", \\\"{x:1304,y:901,t:1527268687347};\\\", \\\"{x:1304,y:904,t:1527268687365};\\\", \\\"{x:1303,y:906,t:1527268687381};\\\", \\\"{x:1302,y:909,t:1527268687398};\\\", \\\"{x:1300,y:911,t:1527268687414};\\\", \\\"{x:1300,y:913,t:1527268687431};\\\", \\\"{x:1300,y:914,t:1527268687448};\\\", \\\"{x:1301,y:914,t:1527268687863};\\\", \\\"{x:1304,y:914,t:1527268687870};\\\", \\\"{x:1305,y:914,t:1527268687881};\\\", \\\"{x:1308,y:913,t:1527268687898};\\\", \\\"{x:1309,y:913,t:1527268687914};\\\", \\\"{x:1309,y:912,t:1527268687932};\\\", \\\"{x:1311,y:912,t:1527268687948};\\\", \\\"{x:1311,y:911,t:1527268687964};\\\", \\\"{x:1312,y:909,t:1527268687982};\\\", \\\"{x:1315,y:904,t:1527268687999};\\\", \\\"{x:1316,y:900,t:1527268688015};\\\", \\\"{x:1318,y:895,t:1527268688031};\\\", \\\"{x:1319,y:888,t:1527268688048};\\\", \\\"{x:1319,y:881,t:1527268688064};\\\", \\\"{x:1320,y:875,t:1527268688081};\\\", \\\"{x:1320,y:868,t:1527268688098};\\\", \\\"{x:1322,y:863,t:1527268688115};\\\", \\\"{x:1323,y:859,t:1527268688131};\\\", \\\"{x:1323,y:857,t:1527268688148};\\\", \\\"{x:1323,y:853,t:1527268688165};\\\", \\\"{x:1323,y:850,t:1527268688182};\\\", \\\"{x:1323,y:847,t:1527268688198};\\\", \\\"{x:1323,y:844,t:1527268688215};\\\", \\\"{x:1322,y:841,t:1527268688231};\\\", \\\"{x:1322,y:840,t:1527268688249};\\\", \\\"{x:1322,y:837,t:1527268688265};\\\", \\\"{x:1322,y:833,t:1527268688281};\\\", \\\"{x:1321,y:830,t:1527268688299};\\\", \\\"{x:1321,y:827,t:1527268688316};\\\", \\\"{x:1321,y:825,t:1527268688332};\\\", \\\"{x:1320,y:821,t:1527268688349};\\\", \\\"{x:1319,y:817,t:1527268688366};\\\", \\\"{x:1319,y:812,t:1527268688381};\\\", \\\"{x:1319,y:804,t:1527268688399};\\\", \\\"{x:1319,y:799,t:1527268688415};\\\", \\\"{x:1319,y:795,t:1527268688431};\\\", \\\"{x:1319,y:792,t:1527268688448};\\\", \\\"{x:1319,y:789,t:1527268688466};\\\", \\\"{x:1319,y:787,t:1527268688481};\\\", \\\"{x:1318,y:783,t:1527268688498};\\\", \\\"{x:1318,y:778,t:1527268688516};\\\", \\\"{x:1318,y:774,t:1527268688532};\\\", \\\"{x:1318,y:770,t:1527268688549};\\\", \\\"{x:1318,y:766,t:1527268688566};\\\", \\\"{x:1318,y:759,t:1527268688582};\\\", \\\"{x:1318,y:756,t:1527268688598};\\\", \\\"{x:1318,y:750,t:1527268688615};\\\", \\\"{x:1319,y:745,t:1527268688633};\\\", \\\"{x:1319,y:741,t:1527268688648};\\\", \\\"{x:1319,y:737,t:1527268688665};\\\", \\\"{x:1320,y:733,t:1527268688682};\\\", \\\"{x:1320,y:729,t:1527268688698};\\\", \\\"{x:1320,y:726,t:1527268688716};\\\", \\\"{x:1321,y:723,t:1527268688733};\\\", \\\"{x:1322,y:719,t:1527268688748};\\\", \\\"{x:1322,y:716,t:1527268688765};\\\", \\\"{x:1324,y:708,t:1527268688781};\\\", \\\"{x:1324,y:704,t:1527268688798};\\\", \\\"{x:1325,y:700,t:1527268688815};\\\", \\\"{x:1326,y:695,t:1527268688831};\\\", \\\"{x:1326,y:693,t:1527268688848};\\\", \\\"{x:1326,y:690,t:1527268688865};\\\", \\\"{x:1326,y:686,t:1527268688882};\\\", \\\"{x:1326,y:683,t:1527268688898};\\\", \\\"{x:1325,y:677,t:1527268688915};\\\", \\\"{x:1323,y:673,t:1527268688932};\\\", \\\"{x:1323,y:667,t:1527268688948};\\\", \\\"{x:1323,y:661,t:1527268688965};\\\", \\\"{x:1323,y:654,t:1527268688982};\\\", \\\"{x:1322,y:648,t:1527268688999};\\\", \\\"{x:1321,y:641,t:1527268689015};\\\", \\\"{x:1321,y:637,t:1527268689032};\\\", \\\"{x:1321,y:630,t:1527268689048};\\\", \\\"{x:1321,y:625,t:1527268689066};\\\", \\\"{x:1321,y:618,t:1527268689083};\\\", \\\"{x:1321,y:613,t:1527268689099};\\\", \\\"{x:1321,y:607,t:1527268689116};\\\", \\\"{x:1319,y:601,t:1527268689132};\\\", \\\"{x:1319,y:594,t:1527268689149};\\\", \\\"{x:1319,y:587,t:1527268689165};\\\", \\\"{x:1319,y:576,t:1527268689182};\\\", \\\"{x:1317,y:571,t:1527268689200};\\\", \\\"{x:1316,y:566,t:1527268689215};\\\", \\\"{x:1316,y:563,t:1527268689232};\\\", \\\"{x:1316,y:557,t:1527268689249};\\\", \\\"{x:1316,y:553,t:1527268689265};\\\", \\\"{x:1316,y:548,t:1527268689283};\\\", \\\"{x:1316,y:542,t:1527268689299};\\\", \\\"{x:1316,y:534,t:1527268689315};\\\", \\\"{x:1316,y:528,t:1527268689332};\\\", \\\"{x:1315,y:518,t:1527268689350};\\\", \\\"{x:1315,y:508,t:1527268689365};\\\", \\\"{x:1314,y:493,t:1527268689382};\\\", \\\"{x:1313,y:483,t:1527268689399};\\\", \\\"{x:1313,y:475,t:1527268689416};\\\", \\\"{x:1313,y:468,t:1527268689432};\\\", \\\"{x:1313,y:461,t:1527268689450};\\\", \\\"{x:1311,y:457,t:1527268689465};\\\", \\\"{x:1311,y:453,t:1527268689483};\\\", \\\"{x:1311,y:451,t:1527268689499};\\\", \\\"{x:1311,y:449,t:1527268689516};\\\", \\\"{x:1311,y:448,t:1527268689533};\\\", \\\"{x:1311,y:446,t:1527268689549};\\\", \\\"{x:1312,y:445,t:1527268689647};\\\", \\\"{x:1312,y:444,t:1527268689654};\\\", \\\"{x:1313,y:443,t:1527268689678};\\\", \\\"{x:1314,y:443,t:1527268689686};\\\", \\\"{x:1315,y:442,t:1527268689702};\\\", \\\"{x:1315,y:441,t:1527268691655};\\\", \\\"{x:1316,y:441,t:1527268691759};\\\", \\\"{x:1317,y:441,t:1527268691782};\\\", \\\"{x:1318,y:441,t:1527268691822};\\\", \\\"{x:1318,y:440,t:1527268691879};\\\", \\\"{x:1319,y:440,t:1527268691910};\\\", \\\"{x:1320,y:440,t:1527268692040};\\\", \\\"{x:1321,y:440,t:1527268692051};\\\", \\\"{x:1322,y:440,t:1527268692383};\\\", \\\"{x:1322,y:439,t:1527268692399};\\\", \\\"{x:1323,y:439,t:1527268692447};\\\", \\\"{x:1324,y:438,t:1527268692502};\\\", \\\"{x:1325,y:438,t:1527268692534};\\\", \\\"{x:1325,y:437,t:1527268692673};\\\", \\\"{x:1326,y:437,t:1527268693167};\\\", \\\"{x:1327,y:437,t:1527268693198};\\\", \\\"{x:1328,y:437,t:1527268693263};\\\", \\\"{x:1329,y:436,t:1527268693286};\\\", \\\"{x:1330,y:436,t:1527268693318};\\\", \\\"{x:1330,y:435,t:1527268693335};\\\", \\\"{x:1331,y:435,t:1527268693503};\\\", \\\"{x:1333,y:435,t:1527268693615};\\\", \\\"{x:1333,y:434,t:1527268693622};\\\", \\\"{x:1334,y:434,t:1527268693638};\\\", \\\"{x:1335,y:434,t:1527268693653};\\\", \\\"{x:1339,y:434,t:1527268693668};\\\", \\\"{x:1346,y:434,t:1527268693686};\\\", \\\"{x:1354,y:434,t:1527268693703};\\\", \\\"{x:1360,y:434,t:1527268693718};\\\", \\\"{x:1362,y:434,t:1527268693736};\\\", \\\"{x:1363,y:434,t:1527268693752};\\\", \\\"{x:1364,y:434,t:1527268693775};\\\", \\\"{x:1365,y:434,t:1527268693799};\\\", \\\"{x:1366,y:434,t:1527268693919};\\\", \\\"{x:1368,y:435,t:1527268693936};\\\", \\\"{x:1375,y:435,t:1527268693952};\\\", \\\"{x:1384,y:436,t:1527268693970};\\\", \\\"{x:1394,y:438,t:1527268693985};\\\", \\\"{x:1400,y:439,t:1527268694003};\\\", \\\"{x:1403,y:440,t:1527268694020};\\\", \\\"{x:1404,y:440,t:1527268694158};\\\", \\\"{x:1404,y:441,t:1527268694169};\\\", \\\"{x:1401,y:442,t:1527268694185};\\\", \\\"{x:1400,y:443,t:1527268694202};\\\", \\\"{x:1399,y:443,t:1527268694219};\\\", \\\"{x:1398,y:443,t:1527268694234};\\\", \\\"{x:1397,y:443,t:1527268694342};\\\", \\\"{x:1396,y:445,t:1527268694353};\\\", \\\"{x:1395,y:445,t:1527268694369};\\\", \\\"{x:1394,y:445,t:1527268694386};\\\", \\\"{x:1393,y:446,t:1527268694402};\\\", \\\"{x:1392,y:446,t:1527268694461};\\\", \\\"{x:1391,y:446,t:1527268694493};\\\", \\\"{x:1390,y:446,t:1527268694550};\\\", \\\"{x:1388,y:446,t:1527268694798};\\\", \\\"{x:1385,y:448,t:1527268694814};\\\", \\\"{x:1384,y:448,t:1527268694822};\\\", \\\"{x:1381,y:449,t:1527268694836};\\\", \\\"{x:1380,y:450,t:1527268694854};\\\", \\\"{x:1377,y:452,t:1527268694870};\\\", \\\"{x:1375,y:456,t:1527268694886};\\\", \\\"{x:1374,y:462,t:1527268694904};\\\", \\\"{x:1374,y:468,t:1527268694920};\\\", \\\"{x:1374,y:476,t:1527268694937};\\\", \\\"{x:1373,y:487,t:1527268694953};\\\", \\\"{x:1370,y:499,t:1527268694970};\\\", \\\"{x:1370,y:505,t:1527268694987};\\\", \\\"{x:1369,y:514,t:1527268695004};\\\", \\\"{x:1369,y:519,t:1527268695019};\\\", \\\"{x:1369,y:525,t:1527268695037};\\\", \\\"{x:1369,y:535,t:1527268695054};\\\", \\\"{x:1369,y:541,t:1527268695070};\\\", \\\"{x:1369,y:546,t:1527268695086};\\\", \\\"{x:1369,y:549,t:1527268695104};\\\", \\\"{x:1370,y:553,t:1527268695120};\\\", \\\"{x:1370,y:557,t:1527268695137};\\\", \\\"{x:1370,y:560,t:1527268695154};\\\", \\\"{x:1371,y:563,t:1527268695169};\\\", \\\"{x:1371,y:567,t:1527268695187};\\\", \\\"{x:1371,y:572,t:1527268695204};\\\", \\\"{x:1371,y:578,t:1527268695219};\\\", \\\"{x:1371,y:583,t:1527268695237};\\\", \\\"{x:1373,y:590,t:1527268695253};\\\", \\\"{x:1375,y:598,t:1527268695271};\\\", \\\"{x:1375,y:602,t:1527268695287};\\\", \\\"{x:1376,y:606,t:1527268695304};\\\", \\\"{x:1377,y:611,t:1527268695321};\\\", \\\"{x:1377,y:613,t:1527268695337};\\\", \\\"{x:1378,y:615,t:1527268695353};\\\", \\\"{x:1378,y:618,t:1527268695370};\\\", \\\"{x:1379,y:622,t:1527268695387};\\\", \\\"{x:1379,y:626,t:1527268695404};\\\", \\\"{x:1381,y:630,t:1527268695421};\\\", \\\"{x:1382,y:635,t:1527268695437};\\\", \\\"{x:1382,y:641,t:1527268695454};\\\", \\\"{x:1382,y:646,t:1527268695469};\\\", \\\"{x:1382,y:649,t:1527268695486};\\\", \\\"{x:1382,y:654,t:1527268695503};\\\", \\\"{x:1382,y:660,t:1527268695520};\\\", \\\"{x:1383,y:666,t:1527268695536};\\\", \\\"{x:1383,y:672,t:1527268695553};\\\", \\\"{x:1383,y:679,t:1527268695570};\\\", \\\"{x:1383,y:684,t:1527268695586};\\\", \\\"{x:1383,y:687,t:1527268695603};\\\", \\\"{x:1383,y:690,t:1527268695621};\\\", \\\"{x:1383,y:694,t:1527268695637};\\\", \\\"{x:1383,y:699,t:1527268695653};\\\", \\\"{x:1385,y:708,t:1527268695671};\\\", \\\"{x:1385,y:713,t:1527268695687};\\\", \\\"{x:1385,y:718,t:1527268695705};\\\", \\\"{x:1385,y:722,t:1527268695722};\\\", \\\"{x:1385,y:726,t:1527268695736};\\\", \\\"{x:1385,y:730,t:1527268695753};\\\", \\\"{x:1385,y:735,t:1527268695771};\\\", \\\"{x:1385,y:738,t:1527268695788};\\\", \\\"{x:1385,y:743,t:1527268695803};\\\", \\\"{x:1385,y:746,t:1527268695821};\\\", \\\"{x:1385,y:750,t:1527268695838};\\\", \\\"{x:1385,y:751,t:1527268695854};\\\", \\\"{x:1385,y:754,t:1527268695870};\\\", \\\"{x:1385,y:757,t:1527268695888};\\\", \\\"{x:1385,y:760,t:1527268695904};\\\", \\\"{x:1385,y:762,t:1527268695920};\\\", \\\"{x:1385,y:764,t:1527268695938};\\\", \\\"{x:1385,y:767,t:1527268695954};\\\", \\\"{x:1385,y:768,t:1527268695971};\\\", \\\"{x:1385,y:769,t:1527268695987};\\\", \\\"{x:1385,y:771,t:1527268696003};\\\", \\\"{x:1385,y:774,t:1527268696021};\\\", \\\"{x:1385,y:776,t:1527268696037};\\\", \\\"{x:1385,y:779,t:1527268696054};\\\", \\\"{x:1385,y:783,t:1527268696070};\\\", \\\"{x:1385,y:785,t:1527268696088};\\\", \\\"{x:1385,y:790,t:1527268696103};\\\", \\\"{x:1385,y:793,t:1527268696120};\\\", \\\"{x:1385,y:798,t:1527268696138};\\\", \\\"{x:1385,y:804,t:1527268696154};\\\", \\\"{x:1385,y:810,t:1527268696170};\\\", \\\"{x:1385,y:817,t:1527268696188};\\\", \\\"{x:1385,y:823,t:1527268696204};\\\", \\\"{x:1385,y:829,t:1527268696221};\\\", \\\"{x:1385,y:835,t:1527268696238};\\\", \\\"{x:1385,y:838,t:1527268696254};\\\", \\\"{x:1385,y:842,t:1527268696272};\\\", \\\"{x:1385,y:846,t:1527268696288};\\\", \\\"{x:1385,y:847,t:1527268696311};\\\", \\\"{x:1385,y:848,t:1527268696320};\\\", \\\"{x:1385,y:849,t:1527268696338};\\\", \\\"{x:1385,y:850,t:1527268696358};\\\", \\\"{x:1385,y:851,t:1527268696371};\\\", \\\"{x:1385,y:853,t:1527268696388};\\\", \\\"{x:1385,y:856,t:1527268696405};\\\", \\\"{x:1385,y:858,t:1527268696421};\\\", \\\"{x:1385,y:859,t:1527268696438};\\\", \\\"{x:1385,y:866,t:1527268696454};\\\", \\\"{x:1383,y:871,t:1527268696470};\\\", \\\"{x:1383,y:874,t:1527268696487};\\\", \\\"{x:1381,y:877,t:1527268696504};\\\", \\\"{x:1380,y:882,t:1527268696520};\\\", \\\"{x:1380,y:885,t:1527268696537};\\\", \\\"{x:1378,y:888,t:1527268696554};\\\", \\\"{x:1378,y:891,t:1527268696570};\\\", \\\"{x:1377,y:894,t:1527268696587};\\\", \\\"{x:1377,y:895,t:1527268696604};\\\", \\\"{x:1377,y:897,t:1527268696620};\\\", \\\"{x:1377,y:898,t:1527268696637};\\\", \\\"{x:1376,y:900,t:1527268696654};\\\", \\\"{x:1376,y:901,t:1527268696671};\\\", \\\"{x:1376,y:902,t:1527268696688};\\\", \\\"{x:1376,y:903,t:1527268696705};\\\", \\\"{x:1376,y:905,t:1527268696721};\\\", \\\"{x:1376,y:906,t:1527268696738};\\\", \\\"{x:1376,y:909,t:1527268696754};\\\", \\\"{x:1376,y:910,t:1527268696791};\\\", \\\"{x:1376,y:911,t:1527268696806};\\\", \\\"{x:1376,y:912,t:1527268696823};\\\", \\\"{x:1376,y:913,t:1527268696846};\\\", \\\"{x:1376,y:914,t:1527268696854};\\\", \\\"{x:1375,y:915,t:1527268696872};\\\", \\\"{x:1375,y:916,t:1527268696887};\\\", \\\"{x:1375,y:918,t:1527268696905};\\\", \\\"{x:1375,y:919,t:1527268696921};\\\", \\\"{x:1374,y:920,t:1527268696937};\\\", \\\"{x:1373,y:921,t:1527268696954};\\\", \\\"{x:1373,y:922,t:1527268696972};\\\", \\\"{x:1373,y:923,t:1527268696988};\\\", \\\"{x:1372,y:924,t:1527268697005};\\\", \\\"{x:1372,y:925,t:1527268697046};\\\", \\\"{x:1372,y:926,t:1527268697086};\\\", \\\"{x:1372,y:927,t:1527268697108};\\\", \\\"{x:1371,y:928,t:1527268697132};\\\", \\\"{x:1371,y:929,t:1527268697164};\\\", \\\"{x:1370,y:930,t:1527268697196};\\\", \\\"{x:1370,y:931,t:1527268698765};\\\", \\\"{x:1369,y:930,t:1527268698771};\\\", \\\"{x:1369,y:929,t:1527268698787};\\\", \\\"{x:1369,y:926,t:1527268698803};\\\", \\\"{x:1369,y:911,t:1527268698820};\\\", \\\"{x:1369,y:891,t:1527268698838};\\\", \\\"{x:1369,y:855,t:1527268698853};\\\", \\\"{x:1369,y:799,t:1527268698870};\\\", \\\"{x:1377,y:735,t:1527268698887};\\\", \\\"{x:1382,y:672,t:1527268698903};\\\", \\\"{x:1387,y:612,t:1527268698920};\\\", \\\"{x:1387,y:557,t:1527268698938};\\\", \\\"{x:1387,y:512,t:1527268698953};\\\", \\\"{x:1387,y:474,t:1527268698970};\\\", \\\"{x:1388,y:429,t:1527268698988};\\\", \\\"{x:1388,y:419,t:1527268699003};\\\", \\\"{x:1388,y:396,t:1527268699020};\\\", \\\"{x:1388,y:383,t:1527268699037};\\\", \\\"{x:1386,y:373,t:1527268699053};\\\", \\\"{x:1385,y:366,t:1527268699070};\\\", \\\"{x:1385,y:364,t:1527268699087};\\\", \\\"{x:1385,y:363,t:1527268699104};\\\", \\\"{x:1385,y:362,t:1527268699173};\\\", \\\"{x:1378,y:363,t:1527268699187};\\\", \\\"{x:1372,y:371,t:1527268699204};\\\", \\\"{x:1368,y:382,t:1527268699220};\\\", \\\"{x:1364,y:391,t:1527268699236};\\\", \\\"{x:1363,y:401,t:1527268699253};\\\", \\\"{x:1362,y:408,t:1527268699269};\\\", \\\"{x:1360,y:414,t:1527268699286};\\\", \\\"{x:1360,y:417,t:1527268699303};\\\", \\\"{x:1360,y:420,t:1527268699319};\\\", \\\"{x:1360,y:424,t:1527268699337};\\\", \\\"{x:1360,y:428,t:1527268699353};\\\", \\\"{x:1360,y:434,t:1527268699369};\\\", \\\"{x:1360,y:442,t:1527268699387};\\\", \\\"{x:1361,y:445,t:1527268699403};\\\", \\\"{x:1361,y:447,t:1527268699419};\\\", \\\"{x:1363,y:448,t:1527268699436};\\\", \\\"{x:1365,y:448,t:1527268699836};\\\", \\\"{x:1372,y:447,t:1527268699854};\\\", \\\"{x:1378,y:447,t:1527268699871};\\\", \\\"{x:1383,y:446,t:1527268699887};\\\", \\\"{x:1385,y:445,t:1527268699904};\\\", \\\"{x:1387,y:445,t:1527268699921};\\\", \\\"{x:1389,y:445,t:1527268699937};\\\", \\\"{x:1391,y:445,t:1527268699954};\\\", \\\"{x:1395,y:445,t:1527268699972};\\\", \\\"{x:1398,y:446,t:1527268699988};\\\", \\\"{x:1399,y:446,t:1527268700004};\\\", \\\"{x:1400,y:446,t:1527268700021};\\\", \\\"{x:1402,y:446,t:1527268700043};\\\", \\\"{x:1403,y:446,t:1527268700054};\\\", \\\"{x:1408,y:447,t:1527268700070};\\\", \\\"{x:1413,y:448,t:1527268700088};\\\", \\\"{x:1417,y:448,t:1527268700104};\\\", \\\"{x:1424,y:449,t:1527268700121};\\\", \\\"{x:1433,y:450,t:1527268700138};\\\", \\\"{x:1437,y:450,t:1527268700154};\\\", \\\"{x:1440,y:450,t:1527268700172};\\\", \\\"{x:1441,y:450,t:1527268700444};\\\", \\\"{x:1444,y:450,t:1527268700454};\\\", \\\"{x:1453,y:450,t:1527268700472};\\\", \\\"{x:1460,y:450,t:1527268700488};\\\", \\\"{x:1465,y:448,t:1527268700504};\\\", \\\"{x:1467,y:448,t:1527268700521};\\\", \\\"{x:1468,y:448,t:1527268700636};\\\", \\\"{x:1470,y:447,t:1527268700644};\\\", \\\"{x:1471,y:447,t:1527268700655};\\\", \\\"{x:1475,y:447,t:1527268700672};\\\", \\\"{x:1481,y:447,t:1527268700689};\\\", \\\"{x:1486,y:447,t:1527268700706};\\\", \\\"{x:1490,y:447,t:1527268700721};\\\", \\\"{x:1496,y:447,t:1527268700739};\\\", \\\"{x:1499,y:447,t:1527268700756};\\\", \\\"{x:1500,y:447,t:1527268700779};\\\", \\\"{x:1502,y:447,t:1527268700836};\\\", \\\"{x:1503,y:447,t:1527268700885};\\\", \\\"{x:1506,y:447,t:1527268701271};\\\", \\\"{x:1512,y:447,t:1527268701276};\\\", \\\"{x:1519,y:447,t:1527268701288};\\\", \\\"{x:1534,y:445,t:1527268701305};\\\", \\\"{x:1546,y:443,t:1527268701321};\\\", \\\"{x:1554,y:442,t:1527268701338};\\\", \\\"{x:1557,y:440,t:1527268701355};\\\", \\\"{x:1560,y:440,t:1527268701516};\\\", \\\"{x:1563,y:440,t:1527268701532};\\\", \\\"{x:1564,y:440,t:1527268701539};\\\", \\\"{x:1572,y:440,t:1527268701555};\\\", \\\"{x:1579,y:440,t:1527268701573};\\\", \\\"{x:1584,y:440,t:1527268701590};\\\", \\\"{x:1588,y:440,t:1527268701606};\\\", \\\"{x:1590,y:440,t:1527268701622};\\\", \\\"{x:1591,y:440,t:1527268701732};\\\", \\\"{x:1591,y:441,t:1527268701740};\\\", \\\"{x:1593,y:441,t:1527268703484};\\\", \\\"{x:1600,y:441,t:1527268703491};\\\", \\\"{x:1615,y:441,t:1527268703508};\\\", \\\"{x:1632,y:441,t:1527268703523};\\\", \\\"{x:1648,y:441,t:1527268703540};\\\", \\\"{x:1653,y:441,t:1527268703557};\\\", \\\"{x:1653,y:442,t:1527268704531};\\\", \\\"{x:1653,y:443,t:1527268704563};\\\", \\\"{x:1654,y:443,t:1527268704574};\\\", \\\"{x:1657,y:443,t:1527268704591};\\\", \\\"{x:1660,y:443,t:1527268704606};\\\", \\\"{x:1666,y:443,t:1527268704624};\\\", \\\"{x:1672,y:444,t:1527268704641};\\\", \\\"{x:1681,y:445,t:1527268704657};\\\", \\\"{x:1690,y:447,t:1527268704674};\\\", \\\"{x:1695,y:447,t:1527268704691};\\\", \\\"{x:1696,y:447,t:1527268704764};\\\", \\\"{x:1698,y:447,t:1527268704874};\\\", \\\"{x:1701,y:447,t:1527268704890};\\\", \\\"{x:1703,y:447,t:1527268704907};\\\", \\\"{x:1706,y:447,t:1527268704924};\\\", \\\"{x:1708,y:447,t:1527268705147};\\\", \\\"{x:1709,y:446,t:1527268705159};\\\", \\\"{x:1711,y:446,t:1527268705174};\\\", \\\"{x:1714,y:446,t:1527268705191};\\\", \\\"{x:1716,y:446,t:1527268705209};\\\", \\\"{x:1719,y:444,t:1527268705224};\\\", \\\"{x:1720,y:444,t:1527268705241};\\\", \\\"{x:1723,y:444,t:1527268705258};\\\", \\\"{x:1726,y:444,t:1527268705274};\\\", \\\"{x:1734,y:444,t:1527268705292};\\\", \\\"{x:1740,y:444,t:1527268705309};\\\", \\\"{x:1748,y:444,t:1527268705324};\\\", \\\"{x:1754,y:444,t:1527268705342};\\\", \\\"{x:1759,y:444,t:1527268705358};\\\", \\\"{x:1761,y:444,t:1527268705375};\\\", \\\"{x:1762,y:444,t:1527268705392};\\\", \\\"{x:1763,y:444,t:1527268705409};\\\", \\\"{x:1765,y:444,t:1527268705425};\\\", \\\"{x:1767,y:444,t:1527268705442};\\\", \\\"{x:1770,y:444,t:1527268705458};\\\", \\\"{x:1773,y:444,t:1527268705475};\\\", \\\"{x:1776,y:444,t:1527268705491};\\\", \\\"{x:1777,y:444,t:1527268705508};\\\", \\\"{x:1778,y:444,t:1527268705525};\\\", \\\"{x:1779,y:444,t:1527268705724};\\\", \\\"{x:1781,y:444,t:1527268705732};\\\", \\\"{x:1783,y:445,t:1527268705748};\\\", \\\"{x:1784,y:446,t:1527268705759};\\\", \\\"{x:1787,y:451,t:1527268705775};\\\", \\\"{x:1788,y:454,t:1527268705792};\\\", \\\"{x:1791,y:458,t:1527268705809};\\\", \\\"{x:1793,y:461,t:1527268705826};\\\", \\\"{x:1793,y:463,t:1527268705843};\\\", \\\"{x:1793,y:464,t:1527268705858};\\\", \\\"{x:1794,y:465,t:1527268705876};\\\", \\\"{x:1794,y:466,t:1527268705908};\\\", \\\"{x:1794,y:467,t:1527268705926};\\\", \\\"{x:1794,y:468,t:1527268705943};\\\", \\\"{x:1794,y:469,t:1527268705959};\\\", \\\"{x:1794,y:470,t:1527268705975};\\\", \\\"{x:1794,y:471,t:1527268705992};\\\", \\\"{x:1794,y:472,t:1527268706009};\\\", \\\"{x:1794,y:473,t:1527268706025};\\\", \\\"{x:1793,y:473,t:1527268706188};\\\", \\\"{x:1793,y:471,t:1527268706196};\\\", \\\"{x:1792,y:469,t:1527268706209};\\\", \\\"{x:1790,y:464,t:1527268706226};\\\", \\\"{x:1788,y:460,t:1527268706242};\\\", \\\"{x:1787,y:458,t:1527268706259};\\\", \\\"{x:1787,y:457,t:1527268706276};\\\", \\\"{x:1787,y:456,t:1527268706293};\\\", \\\"{x:1787,y:455,t:1527268706316};\\\", \\\"{x:1787,y:453,t:1527268706380};\\\", \\\"{x:1786,y:452,t:1527268706396};\\\", \\\"{x:1786,y:451,t:1527268706411};\\\", \\\"{x:1786,y:450,t:1527268706426};\\\", \\\"{x:1786,y:449,t:1527268706443};\\\", \\\"{x:1786,y:444,t:1527268706460};\\\", \\\"{x:1785,y:443,t:1527268706476};\\\", \\\"{x:1785,y:441,t:1527268706493};\\\", \\\"{x:1784,y:440,t:1527268706509};\\\", \\\"{x:1784,y:439,t:1527268706525};\\\", \\\"{x:1783,y:437,t:1527268706542};\\\", \\\"{x:1783,y:436,t:1527268706563};\\\", \\\"{x:1782,y:437,t:1527268706884};\\\", \\\"{x:1781,y:438,t:1527268706900};\\\", \\\"{x:1781,y:439,t:1527268706910};\\\", \\\"{x:1781,y:441,t:1527268706926};\\\", \\\"{x:1780,y:441,t:1527268706943};\\\", \\\"{x:1780,y:442,t:1527268706960};\\\", \\\"{x:1780,y:443,t:1527268706977};\\\", \\\"{x:1779,y:444,t:1527268706995};\\\", \\\"{x:1779,y:445,t:1527268707011};\\\", \\\"{x:1779,y:446,t:1527268707028};\\\", \\\"{x:1779,y:447,t:1527268707060};\\\", \\\"{x:1779,y:448,t:1527268707076};\\\", \\\"{x:1779,y:449,t:1527268707093};\\\", \\\"{x:1779,y:450,t:1527268707116};\\\", \\\"{x:1779,y:451,t:1527268707148};\\\", \\\"{x:1779,y:452,t:1527268707179};\\\", \\\"{x:1779,y:453,t:1527268707228};\\\", \\\"{x:1779,y:455,t:1527268707243};\\\", \\\"{x:1780,y:455,t:1527268707275};\\\", \\\"{x:1780,y:456,t:1527268707294};\\\", \\\"{x:1780,y:457,t:1527268707309};\\\", \\\"{x:1780,y:458,t:1527268707327};\\\", \\\"{x:1780,y:459,t:1527268707820};\\\", \\\"{x:1780,y:460,t:1527268707827};\\\", \\\"{x:1780,y:461,t:1527268707844};\\\", \\\"{x:1780,y:463,t:1527268707860};\\\", \\\"{x:1780,y:465,t:1527268707883};\\\", \\\"{x:1780,y:466,t:1527268707894};\\\", \\\"{x:1780,y:467,t:1527268707911};\\\", \\\"{x:1780,y:470,t:1527268707927};\\\", \\\"{x:1781,y:471,t:1527268707943};\\\", \\\"{x:1782,y:474,t:1527268707961};\\\", \\\"{x:1782,y:476,t:1527268707977};\\\", \\\"{x:1783,y:476,t:1527268707993};\\\", \\\"{x:1783,y:479,t:1527268708010};\\\", \\\"{x:1783,y:481,t:1527268708026};\\\", \\\"{x:1783,y:483,t:1527268708044};\\\", \\\"{x:1783,y:486,t:1527268708060};\\\", \\\"{x:1783,y:488,t:1527268708077};\\\", \\\"{x:1783,y:491,t:1527268708094};\\\", \\\"{x:1783,y:492,t:1527268708111};\\\", \\\"{x:1783,y:493,t:1527268708127};\\\", \\\"{x:1783,y:495,t:1527268708148};\\\", \\\"{x:1782,y:496,t:1527268708171};\\\", \\\"{x:1782,y:498,t:1527268708283};\\\", \\\"{x:1781,y:499,t:1527268708348};\\\", \\\"{x:1780,y:499,t:1527268708508};\\\", \\\"{x:1780,y:496,t:1527268708516};\\\", \\\"{x:1780,y:493,t:1527268708528};\\\", \\\"{x:1779,y:488,t:1527268708544};\\\", \\\"{x:1778,y:483,t:1527268708561};\\\", \\\"{x:1777,y:478,t:1527268708578};\\\", \\\"{x:1777,y:476,t:1527268708594};\\\", \\\"{x:1776,y:472,t:1527268708610};\\\", \\\"{x:1776,y:470,t:1527268708628};\\\", \\\"{x:1776,y:469,t:1527268708660};\\\", \\\"{x:1776,y:467,t:1527268708732};\\\", \\\"{x:1776,y:466,t:1527268708747};\\\", \\\"{x:1776,y:464,t:1527268708760};\\\", \\\"{x:1776,y:460,t:1527268708778};\\\", \\\"{x:1776,y:458,t:1527268708794};\\\", \\\"{x:1776,y:457,t:1527268708811};\\\", \\\"{x:1776,y:456,t:1527268708827};\\\", \\\"{x:1776,y:455,t:1527268708852};\\\", \\\"{x:1776,y:454,t:1527268708876};\\\", \\\"{x:1776,y:453,t:1527268708891};\\\", \\\"{x:1776,y:452,t:1527268708900};\\\", \\\"{x:1776,y:451,t:1527268708910};\\\", \\\"{x:1776,y:450,t:1527268708927};\\\", \\\"{x:1776,y:448,t:1527268708944};\\\", \\\"{x:1777,y:446,t:1527268708960};\\\", \\\"{x:1777,y:445,t:1527268708977};\\\", \\\"{x:1777,y:447,t:1527268709292};\\\", \\\"{x:1777,y:448,t:1527268709300};\\\", \\\"{x:1777,y:449,t:1527268709312};\\\", \\\"{x:1777,y:451,t:1527268709328};\\\", \\\"{x:1777,y:454,t:1527268709345};\\\", \\\"{x:1777,y:455,t:1527268709362};\\\", \\\"{x:1778,y:457,t:1527268709377};\\\", \\\"{x:1778,y:459,t:1527268709395};\\\", \\\"{x:1778,y:461,t:1527268709412};\\\", \\\"{x:1778,y:462,t:1527268709428};\\\", \\\"{x:1778,y:463,t:1527268709445};\\\", \\\"{x:1778,y:464,t:1527268709462};\\\", \\\"{x:1778,y:466,t:1527268709478};\\\", \\\"{x:1778,y:467,t:1527268709495};\\\", \\\"{x:1778,y:469,t:1527268709512};\\\", \\\"{x:1778,y:472,t:1527268709528};\\\", \\\"{x:1778,y:474,t:1527268709545};\\\", \\\"{x:1778,y:477,t:1527268709562};\\\", \\\"{x:1778,y:480,t:1527268709578};\\\", \\\"{x:1778,y:483,t:1527268709595};\\\", \\\"{x:1778,y:485,t:1527268709611};\\\", \\\"{x:1778,y:486,t:1527268709628};\\\", \\\"{x:1778,y:487,t:1527268709645};\\\", \\\"{x:1778,y:488,t:1527268709661};\\\", \\\"{x:1778,y:490,t:1527268709679};\\\", \\\"{x:1778,y:492,t:1527268709694};\\\", \\\"{x:1779,y:493,t:1527268709712};\\\", \\\"{x:1779,y:496,t:1527268709729};\\\", \\\"{x:1779,y:497,t:1527268709745};\\\", \\\"{x:1780,y:499,t:1527268709762};\\\", \\\"{x:1780,y:501,t:1527268709779};\\\", \\\"{x:1780,y:502,t:1527268709795};\\\", \\\"{x:1780,y:504,t:1527268709812};\\\", \\\"{x:1780,y:505,t:1527268709836};\\\", \\\"{x:1780,y:506,t:1527268709867};\\\", \\\"{x:1780,y:507,t:1527268709879};\\\", \\\"{x:1781,y:509,t:1527268709894};\\\", \\\"{x:1781,y:510,t:1527268709912};\\\", \\\"{x:1781,y:511,t:1527268709929};\\\", \\\"{x:1782,y:512,t:1527268709947};\\\", \\\"{x:1782,y:513,t:1527268709963};\\\", \\\"{x:1783,y:514,t:1527268709980};\\\", \\\"{x:1783,y:515,t:1527268710019};\\\", \\\"{x:1783,y:516,t:1527268710036};\\\", \\\"{x:1783,y:517,t:1527268710044};\\\", \\\"{x:1783,y:518,t:1527268710062};\\\", \\\"{x:1784,y:519,t:1527268710079};\\\", \\\"{x:1784,y:520,t:1527268710099};\\\", \\\"{x:1785,y:521,t:1527268710116};\\\", \\\"{x:1785,y:522,t:1527268710131};\\\", \\\"{x:1785,y:523,t:1527268710146};\\\", \\\"{x:1785,y:524,t:1527268710163};\\\", \\\"{x:1785,y:525,t:1527268710178};\\\", \\\"{x:1785,y:526,t:1527268710195};\\\", \\\"{x:1786,y:527,t:1527268710236};\\\", \\\"{x:1786,y:528,t:1527268710252};\\\", \\\"{x:1786,y:529,t:1527268710275};\\\", \\\"{x:1786,y:530,t:1527268710316};\\\", \\\"{x:1786,y:531,t:1527268710328};\\\", \\\"{x:1787,y:532,t:1527268710346};\\\", \\\"{x:1787,y:533,t:1527268710362};\\\", \\\"{x:1787,y:535,t:1527268710378};\\\", \\\"{x:1787,y:536,t:1527268710395};\\\", \\\"{x:1787,y:537,t:1527268710411};\\\", \\\"{x:1787,y:538,t:1527268710429};\\\", \\\"{x:1787,y:539,t:1527268710446};\\\", \\\"{x:1787,y:540,t:1527268710461};\\\", \\\"{x:1787,y:541,t:1527268710478};\\\", \\\"{x:1787,y:542,t:1527268710495};\\\", \\\"{x:1787,y:544,t:1527268710511};\\\", \\\"{x:1787,y:545,t:1527268710528};\\\", \\\"{x:1787,y:546,t:1527268710545};\\\", \\\"{x:1787,y:547,t:1527268710562};\\\", \\\"{x:1787,y:548,t:1527268710578};\\\", \\\"{x:1787,y:549,t:1527268710594};\\\", \\\"{x:1787,y:550,t:1527268710612};\\\", \\\"{x:1786,y:552,t:1527268710628};\\\", \\\"{x:1786,y:553,t:1527268710651};\\\", \\\"{x:1786,y:554,t:1527268710716};\\\", \\\"{x:1786,y:555,t:1527268710732};\\\", \\\"{x:1786,y:556,t:1527268710747};\\\", \\\"{x:1785,y:556,t:1527268710763};\\\", \\\"{x:1785,y:557,t:1527268710844};\\\", \\\"{x:1785,y:558,t:1527268710908};\\\", \\\"{x:1785,y:559,t:1527268711156};\\\", \\\"{x:1785,y:560,t:1527268711212};\\\", \\\"{x:1785,y:561,t:1527268711244};\\\", \\\"{x:1785,y:562,t:1527268711251};\\\", \\\"{x:1785,y:563,t:1527268711300};\\\", \\\"{x:1785,y:564,t:1527268711316};\\\", \\\"{x:1784,y:565,t:1527268711330};\\\", \\\"{x:1783,y:565,t:1527268711346};\\\", \\\"{x:1783,y:566,t:1527268711363};\\\", \\\"{x:1782,y:568,t:1527268711379};\\\", \\\"{x:1782,y:570,t:1527268711396};\\\", \\\"{x:1781,y:572,t:1527268711413};\\\", \\\"{x:1780,y:574,t:1527268711430};\\\", \\\"{x:1779,y:575,t:1527268711446};\\\", \\\"{x:1779,y:576,t:1527268711467};\\\", \\\"{x:1779,y:577,t:1527268711491};\\\", \\\"{x:1779,y:578,t:1527268711603};\\\", \\\"{x:1779,y:580,t:1527268711643};\\\", \\\"{x:1779,y:581,t:1527268711659};\\\", \\\"{x:1779,y:582,t:1527268711700};\\\", \\\"{x:1779,y:583,t:1527268711731};\\\", \\\"{x:1779,y:584,t:1527268711747};\\\", \\\"{x:1779,y:585,t:1527268711780};\\\", \\\"{x:1779,y:586,t:1527268711796};\\\", \\\"{x:1779,y:587,t:1527268711813};\\\", \\\"{x:1779,y:588,t:1527268711836};\\\", \\\"{x:1779,y:589,t:1527268711847};\\\", \\\"{x:1779,y:590,t:1527268711863};\\\", \\\"{x:1779,y:591,t:1527268711880};\\\", \\\"{x:1779,y:592,t:1527268711897};\\\", \\\"{x:1779,y:593,t:1527268711913};\\\", \\\"{x:1779,y:594,t:1527268711931};\\\", \\\"{x:1779,y:595,t:1527268711955};\\\", \\\"{x:1779,y:596,t:1527268712004};\\\", \\\"{x:1779,y:597,t:1527268712028};\\\", \\\"{x:1779,y:598,t:1527268712043};\\\", \\\"{x:1779,y:599,t:1527268712052};\\\", \\\"{x:1777,y:600,t:1527268712064};\\\", \\\"{x:1777,y:602,t:1527268712083};\\\", \\\"{x:1777,y:604,t:1527268712115};\\\", \\\"{x:1777,y:605,t:1527268712147};\\\", \\\"{x:1777,y:607,t:1527268712163};\\\", \\\"{x:1777,y:608,t:1527268712195};\\\", \\\"{x:1777,y:610,t:1527268712227};\\\", \\\"{x:1777,y:611,t:1527268712243};\\\", \\\"{x:1777,y:613,t:1527268712284};\\\", \\\"{x:1777,y:614,t:1527268712307};\\\", \\\"{x:1777,y:616,t:1527268712332};\\\", \\\"{x:1777,y:617,t:1527268712355};\\\", \\\"{x:1776,y:619,t:1527268712372};\\\", \\\"{x:1776,y:620,t:1527268712387};\\\", \\\"{x:1775,y:622,t:1527268712404};\\\", \\\"{x:1775,y:623,t:1527268712420};\\\", \\\"{x:1775,y:624,t:1527268712430};\\\", \\\"{x:1775,y:625,t:1527268712447};\\\", \\\"{x:1775,y:627,t:1527268712464};\\\", \\\"{x:1775,y:628,t:1527268712480};\\\", \\\"{x:1775,y:631,t:1527268712497};\\\", \\\"{x:1775,y:632,t:1527268712513};\\\", \\\"{x:1775,y:634,t:1527268712529};\\\", \\\"{x:1775,y:635,t:1527268712547};\\\", \\\"{x:1775,y:637,t:1527268712564};\\\", \\\"{x:1775,y:638,t:1527268712581};\\\", \\\"{x:1775,y:639,t:1527268712597};\\\", \\\"{x:1775,y:641,t:1527268712613};\\\", \\\"{x:1776,y:643,t:1527268712631};\\\", \\\"{x:1776,y:644,t:1527268712647};\\\", \\\"{x:1776,y:646,t:1527268712664};\\\", \\\"{x:1776,y:647,t:1527268712681};\\\", \\\"{x:1776,y:650,t:1527268712696};\\\", \\\"{x:1776,y:652,t:1527268712714};\\\", \\\"{x:1776,y:654,t:1527268712731};\\\", \\\"{x:1776,y:656,t:1527268712747};\\\", \\\"{x:1776,y:659,t:1527268712763};\\\", \\\"{x:1776,y:660,t:1527268712780};\\\", \\\"{x:1776,y:662,t:1527268712797};\\\", \\\"{x:1776,y:663,t:1527268712814};\\\", \\\"{x:1776,y:666,t:1527268712831};\\\", \\\"{x:1776,y:667,t:1527268712847};\\\", \\\"{x:1776,y:669,t:1527268712864};\\\", \\\"{x:1776,y:670,t:1527268712881};\\\", \\\"{x:1776,y:673,t:1527268712897};\\\", \\\"{x:1776,y:674,t:1527268712914};\\\", \\\"{x:1776,y:676,t:1527268712930};\\\", \\\"{x:1776,y:678,t:1527268712947};\\\", \\\"{x:1776,y:679,t:1527268712964};\\\", \\\"{x:1776,y:681,t:1527268712981};\\\", \\\"{x:1776,y:682,t:1527268712996};\\\", \\\"{x:1776,y:684,t:1527268713014};\\\", \\\"{x:1775,y:685,t:1527268713031};\\\", \\\"{x:1775,y:686,t:1527268713048};\\\", \\\"{x:1775,y:687,t:1527268713064};\\\", \\\"{x:1775,y:688,t:1527268713081};\\\", \\\"{x:1775,y:690,t:1527268713098};\\\", \\\"{x:1775,y:692,t:1527268713114};\\\", \\\"{x:1774,y:694,t:1527268713131};\\\", \\\"{x:1773,y:698,t:1527268713147};\\\", \\\"{x:1773,y:701,t:1527268713164};\\\", \\\"{x:1773,y:702,t:1527268713181};\\\", \\\"{x:1773,y:704,t:1527268713198};\\\", \\\"{x:1773,y:705,t:1527268713214};\\\", \\\"{x:1773,y:707,t:1527268713231};\\\", \\\"{x:1773,y:708,t:1527268713248};\\\", \\\"{x:1773,y:709,t:1527268713268};\\\", \\\"{x:1773,y:710,t:1527268713300};\\\", \\\"{x:1773,y:711,t:1527268713324};\\\", \\\"{x:1774,y:713,t:1527268713332};\\\", \\\"{x:1774,y:715,t:1527268713347};\\\", \\\"{x:1774,y:717,t:1527268713364};\\\", \\\"{x:1774,y:719,t:1527268713381};\\\", \\\"{x:1775,y:722,t:1527268713398};\\\", \\\"{x:1775,y:724,t:1527268713414};\\\", \\\"{x:1775,y:726,t:1527268713430};\\\", \\\"{x:1776,y:728,t:1527268713451};\\\", \\\"{x:1776,y:729,t:1527268713468};\\\", \\\"{x:1776,y:731,t:1527268713499};\\\", \\\"{x:1777,y:733,t:1527268713516};\\\", \\\"{x:1777,y:735,t:1527268713531};\\\", \\\"{x:1777,y:737,t:1527268713548};\\\", \\\"{x:1777,y:739,t:1527268713565};\\\", \\\"{x:1778,y:742,t:1527268713580};\\\", \\\"{x:1778,y:745,t:1527268713598};\\\", \\\"{x:1778,y:747,t:1527268713614};\\\", \\\"{x:1780,y:750,t:1527268713631};\\\", \\\"{x:1780,y:752,t:1527268713648};\\\", \\\"{x:1780,y:754,t:1527268713665};\\\", \\\"{x:1781,y:756,t:1527268713681};\\\", \\\"{x:1781,y:758,t:1527268713698};\\\", \\\"{x:1781,y:760,t:1527268713714};\\\", \\\"{x:1782,y:762,t:1527268713731};\\\", \\\"{x:1782,y:765,t:1527268713748};\\\", \\\"{x:1783,y:768,t:1527268713764};\\\", \\\"{x:1783,y:771,t:1527268713781};\\\", \\\"{x:1783,y:773,t:1527268713798};\\\", \\\"{x:1783,y:778,t:1527268713815};\\\", \\\"{x:1783,y:781,t:1527268713831};\\\", \\\"{x:1783,y:785,t:1527268713848};\\\", \\\"{x:1783,y:790,t:1527268713865};\\\", \\\"{x:1783,y:792,t:1527268713881};\\\", \\\"{x:1784,y:796,t:1527268713898};\\\", \\\"{x:1784,y:798,t:1527268713915};\\\", \\\"{x:1784,y:799,t:1527268713931};\\\", \\\"{x:1784,y:802,t:1527268713948};\\\", \\\"{x:1784,y:803,t:1527268713965};\\\", \\\"{x:1784,y:804,t:1527268713982};\\\", \\\"{x:1784,y:805,t:1527268713997};\\\", \\\"{x:1784,y:807,t:1527268714028};\\\", \\\"{x:1784,y:808,t:1527268714043};\\\", \\\"{x:1784,y:809,t:1527268714060};\\\", \\\"{x:1785,y:811,t:1527268714067};\\\", \\\"{x:1785,y:813,t:1527268714091};\\\", \\\"{x:1785,y:814,t:1527268714099};\\\", \\\"{x:1785,y:815,t:1527268714115};\\\", \\\"{x:1787,y:821,t:1527268714131};\\\", \\\"{x:1787,y:825,t:1527268714148};\\\", \\\"{x:1788,y:829,t:1527268714165};\\\", \\\"{x:1788,y:832,t:1527268714182};\\\", \\\"{x:1788,y:834,t:1527268714198};\\\", \\\"{x:1788,y:838,t:1527268714215};\\\", \\\"{x:1789,y:839,t:1527268714232};\\\", \\\"{x:1789,y:842,t:1527268714248};\\\", \\\"{x:1789,y:843,t:1527268714265};\\\", \\\"{x:1790,y:845,t:1527268714282};\\\", \\\"{x:1790,y:848,t:1527268714298};\\\", \\\"{x:1790,y:851,t:1527268714315};\\\", \\\"{x:1791,y:855,t:1527268714332};\\\", \\\"{x:1792,y:858,t:1527268714348};\\\", \\\"{x:1792,y:861,t:1527268714365};\\\", \\\"{x:1792,y:864,t:1527268714382};\\\", \\\"{x:1792,y:869,t:1527268714398};\\\", \\\"{x:1792,y:874,t:1527268714415};\\\", \\\"{x:1792,y:880,t:1527268714432};\\\", \\\"{x:1792,y:885,t:1527268714449};\\\", \\\"{x:1792,y:890,t:1527268714465};\\\", \\\"{x:1792,y:895,t:1527268714482};\\\", \\\"{x:1792,y:899,t:1527268714498};\\\", \\\"{x:1792,y:902,t:1527268714514};\\\", \\\"{x:1792,y:903,t:1527268714595};\\\", \\\"{x:1792,y:904,t:1527268714626};\\\", \\\"{x:1792,y:905,t:1527268714634};\\\", \\\"{x:1792,y:906,t:1527268714659};\\\", \\\"{x:1792,y:907,t:1527268714667};\\\", \\\"{x:1792,y:908,t:1527268714681};\\\", \\\"{x:1792,y:910,t:1527268714698};\\\", \\\"{x:1792,y:912,t:1527268714714};\\\", \\\"{x:1792,y:918,t:1527268714731};\\\", \\\"{x:1792,y:922,t:1527268714749};\\\", \\\"{x:1792,y:926,t:1527268714765};\\\", \\\"{x:1792,y:928,t:1527268714782};\\\", \\\"{x:1792,y:932,t:1527268714799};\\\", \\\"{x:1792,y:934,t:1527268714815};\\\", \\\"{x:1792,y:936,t:1527268714831};\\\", \\\"{x:1792,y:937,t:1527268715140};\\\", \\\"{x:1791,y:937,t:1527268715163};\\\", \\\"{x:1790,y:937,t:1527268715284};\\\", \\\"{x:1788,y:937,t:1527268715316};\\\", \\\"{x:1784,y:939,t:1527268715342};\\\", \\\"{x:1781,y:939,t:1527268715348};\\\", \\\"{x:1777,y:940,t:1527268715365};\\\", \\\"{x:1773,y:942,t:1527268715381};\\\", \\\"{x:1772,y:942,t:1527268716003};\\\", \\\"{x:1771,y:941,t:1527268716026};\\\", \\\"{x:1771,y:939,t:1527268716052};\\\", \\\"{x:1771,y:937,t:1527268716065};\\\", \\\"{x:1768,y:927,t:1527268716082};\\\", \\\"{x:1759,y:912,t:1527268716099};\\\", \\\"{x:1747,y:896,t:1527268716115};\\\", \\\"{x:1728,y:875,t:1527268716132};\\\", \\\"{x:1695,y:850,t:1527268716150};\\\", \\\"{x:1652,y:815,t:1527268716165};\\\", \\\"{x:1589,y:765,t:1527268716183};\\\", \\\"{x:1531,y:717,t:1527268716199};\\\", \\\"{x:1474,y:659,t:1527268716215};\\\", \\\"{x:1427,y:600,t:1527268716232};\\\", \\\"{x:1391,y:554,t:1527268716249};\\\", \\\"{x:1374,y:528,t:1527268716265};\\\", \\\"{x:1358,y:501,t:1527268716282};\\\", \\\"{x:1353,y:486,t:1527268716299};\\\", \\\"{x:1346,y:473,t:1527268716315};\\\", \\\"{x:1343,y:461,t:1527268716332};\\\", \\\"{x:1335,y:444,t:1527268716349};\\\", \\\"{x:1329,y:430,t:1527268716366};\\\", \\\"{x:1323,y:418,t:1527268716382};\\\", \\\"{x:1322,y:415,t:1527268716399};\\\", \\\"{x:1322,y:414,t:1527268716416};\\\", \\\"{x:1322,y:413,t:1527268716432};\\\", \\\"{x:1321,y:413,t:1527268716522};\\\", \\\"{x:1318,y:413,t:1527268716533};\\\", \\\"{x:1311,y:420,t:1527268716549};\\\", \\\"{x:1306,y:428,t:1527268716566};\\\", \\\"{x:1299,y:438,t:1527268716582};\\\", \\\"{x:1296,y:446,t:1527268716599};\\\", \\\"{x:1296,y:452,t:1527268716616};\\\", \\\"{x:1294,y:458,t:1527268716632};\\\", \\\"{x:1294,y:464,t:1527268716649};\\\", \\\"{x:1294,y:471,t:1527268716666};\\\", \\\"{x:1294,y:478,t:1527268716682};\\\", \\\"{x:1294,y:484,t:1527268716699};\\\", \\\"{x:1294,y:491,t:1527268716717};\\\", \\\"{x:1295,y:499,t:1527268716732};\\\", \\\"{x:1296,y:508,t:1527268716750};\\\", \\\"{x:1298,y:517,t:1527268716766};\\\", \\\"{x:1299,y:523,t:1527268716782};\\\", \\\"{x:1300,y:532,t:1527268716800};\\\", \\\"{x:1300,y:539,t:1527268716816};\\\", \\\"{x:1303,y:548,t:1527268716832};\\\", \\\"{x:1303,y:553,t:1527268716850};\\\", \\\"{x:1304,y:561,t:1527268716867};\\\", \\\"{x:1305,y:567,t:1527268716883};\\\", \\\"{x:1306,y:572,t:1527268716900};\\\", \\\"{x:1307,y:577,t:1527268716917};\\\", \\\"{x:1308,y:584,t:1527268716935};\\\", \\\"{x:1310,y:588,t:1527268716950};\\\", \\\"{x:1311,y:592,t:1527268716967};\\\", \\\"{x:1312,y:595,t:1527268716984};\\\", \\\"{x:1313,y:600,t:1527268716999};\\\", \\\"{x:1314,y:603,t:1527268717018};\\\", \\\"{x:1314,y:606,t:1527268717034};\\\", \\\"{x:1314,y:609,t:1527268717050};\\\", \\\"{x:1314,y:613,t:1527268717067};\\\", \\\"{x:1314,y:615,t:1527268717083};\\\", \\\"{x:1315,y:619,t:1527268717100};\\\", \\\"{x:1315,y:622,t:1527268717117};\\\", \\\"{x:1315,y:625,t:1527268717134};\\\", \\\"{x:1315,y:630,t:1527268717150};\\\", \\\"{x:1315,y:637,t:1527268717167};\\\", \\\"{x:1315,y:645,t:1527268717184};\\\", \\\"{x:1315,y:652,t:1527268717200};\\\", \\\"{x:1315,y:658,t:1527268717217};\\\", \\\"{x:1315,y:664,t:1527268717234};\\\", \\\"{x:1315,y:668,t:1527268717250};\\\", \\\"{x:1315,y:671,t:1527268717268};\\\", \\\"{x:1315,y:673,t:1527268717283};\\\", \\\"{x:1314,y:677,t:1527268717301};\\\", \\\"{x:1314,y:680,t:1527268717318};\\\", \\\"{x:1314,y:682,t:1527268717334};\\\", \\\"{x:1314,y:684,t:1527268717356};\\\", \\\"{x:1314,y:685,t:1527268717371};\\\", \\\"{x:1314,y:687,t:1527268717387};\\\", \\\"{x:1313,y:688,t:1527268717401};\\\", \\\"{x:1313,y:690,t:1527268717417};\\\", \\\"{x:1313,y:694,t:1527268717434};\\\", \\\"{x:1311,y:699,t:1527268717452};\\\", \\\"{x:1311,y:702,t:1527268717467};\\\", \\\"{x:1310,y:710,t:1527268717483};\\\", \\\"{x:1310,y:714,t:1527268717500};\\\", \\\"{x:1309,y:721,t:1527268717517};\\\", \\\"{x:1307,y:728,t:1527268717534};\\\", \\\"{x:1307,y:734,t:1527268717550};\\\", \\\"{x:1306,y:739,t:1527268717567};\\\", \\\"{x:1306,y:743,t:1527268717583};\\\", \\\"{x:1306,y:748,t:1527268717600};\\\", \\\"{x:1306,y:751,t:1527268717616};\\\", \\\"{x:1306,y:756,t:1527268717634};\\\", \\\"{x:1305,y:766,t:1527268717651};\\\", \\\"{x:1305,y:771,t:1527268717666};\\\", \\\"{x:1305,y:775,t:1527268717684};\\\", \\\"{x:1305,y:781,t:1527268717701};\\\", \\\"{x:1305,y:786,t:1527268717716};\\\", \\\"{x:1305,y:792,t:1527268717734};\\\", \\\"{x:1305,y:796,t:1527268717751};\\\", \\\"{x:1305,y:802,t:1527268717767};\\\", \\\"{x:1305,y:807,t:1527268717784};\\\", \\\"{x:1305,y:810,t:1527268717801};\\\", \\\"{x:1305,y:816,t:1527268717818};\\\", \\\"{x:1305,y:820,t:1527268717834};\\\", \\\"{x:1305,y:827,t:1527268717851};\\\", \\\"{x:1305,y:833,t:1527268717867};\\\", \\\"{x:1305,y:836,t:1527268717884};\\\", \\\"{x:1305,y:840,t:1527268717901};\\\", \\\"{x:1305,y:845,t:1527268717918};\\\", \\\"{x:1305,y:849,t:1527268717934};\\\", \\\"{x:1305,y:857,t:1527268717950};\\\", \\\"{x:1305,y:863,t:1527268717969};\\\", \\\"{x:1305,y:869,t:1527268717984};\\\", \\\"{x:1305,y:875,t:1527268718001};\\\", \\\"{x:1305,y:882,t:1527268718018};\\\", \\\"{x:1305,y:887,t:1527268718034};\\\", \\\"{x:1305,y:894,t:1527268718051};\\\", \\\"{x:1305,y:897,t:1527268718067};\\\", \\\"{x:1305,y:900,t:1527268718084};\\\", \\\"{x:1305,y:902,t:1527268718101};\\\", \\\"{x:1306,y:905,t:1527268718118};\\\", \\\"{x:1306,y:906,t:1527268718156};\\\", \\\"{x:1306,y:907,t:1527268718168};\\\", \\\"{x:1307,y:908,t:1527268718184};\\\", \\\"{x:1308,y:909,t:1527268718201};\\\", \\\"{x:1308,y:910,t:1527268718219};\\\", \\\"{x:1308,y:911,t:1527268718268};\\\", \\\"{x:1309,y:912,t:1527268718285};\\\", \\\"{x:1309,y:913,t:1527268718301};\\\", \\\"{x:1309,y:914,t:1527268718318};\\\", \\\"{x:1309,y:916,t:1527268718335};\\\", \\\"{x:1310,y:918,t:1527268718351};\\\", \\\"{x:1311,y:919,t:1527268718368};\\\", \\\"{x:1311,y:921,t:1527268718385};\\\", \\\"{x:1311,y:920,t:1527268722268};\\\", \\\"{x:1312,y:920,t:1527268724226};\\\", \\\"{x:1312,y:921,t:1527268724243};\\\", \\\"{x:1313,y:921,t:1527268724266};\\\", \\\"{x:1316,y:923,t:1527268724274};\\\", \\\"{x:1319,y:923,t:1527268724289};\\\", \\\"{x:1323,y:924,t:1527268724304};\\\", \\\"{x:1329,y:916,t:1527268724322};\\\", \\\"{x:1329,y:909,t:1527268724339};\\\", \\\"{x:1329,y:908,t:1527268737820};\\\", \\\"{x:1331,y:901,t:1527268737852};\\\", \\\"{x:1334,y:893,t:1527268737866};\\\", \\\"{x:1334,y:885,t:1527268737882};\\\", \\\"{x:1336,y:875,t:1527268737899};\\\", \\\"{x:1337,y:870,t:1527268737915};\\\", \\\"{x:1340,y:864,t:1527268737933};\\\", \\\"{x:1345,y:856,t:1527268737949};\\\", \\\"{x:1351,y:849,t:1527268737966};\\\", \\\"{x:1356,y:844,t:1527268737983};\\\", \\\"{x:1359,y:839,t:1527268737999};\\\", \\\"{x:1362,y:834,t:1527268738016};\\\", \\\"{x:1362,y:832,t:1527268738033};\\\", \\\"{x:1362,y:830,t:1527268738049};\\\", \\\"{x:1363,y:827,t:1527268738066};\\\", \\\"{x:1364,y:821,t:1527268738083};\\\", \\\"{x:1364,y:815,t:1527268738099};\\\", \\\"{x:1365,y:810,t:1527268738116};\\\", \\\"{x:1367,y:804,t:1527268738133};\\\", \\\"{x:1369,y:797,t:1527268738149};\\\", \\\"{x:1372,y:787,t:1527268738166};\\\", \\\"{x:1372,y:778,t:1527268738183};\\\", \\\"{x:1374,y:773,t:1527268738199};\\\", \\\"{x:1374,y:769,t:1527268738216};\\\", \\\"{x:1374,y:766,t:1527268738233};\\\", \\\"{x:1374,y:764,t:1527268738249};\\\", \\\"{x:1374,y:762,t:1527268738266};\\\", \\\"{x:1373,y:757,t:1527268738283};\\\", \\\"{x:1371,y:755,t:1527268738299};\\\", \\\"{x:1367,y:753,t:1527268738316};\\\", \\\"{x:1357,y:748,t:1527268738333};\\\", \\\"{x:1347,y:745,t:1527268738349};\\\", \\\"{x:1333,y:741,t:1527268738366};\\\", \\\"{x:1319,y:737,t:1527268738383};\\\", \\\"{x:1308,y:733,t:1527268738399};\\\", \\\"{x:1294,y:732,t:1527268738415};\\\", \\\"{x:1285,y:730,t:1527268738432};\\\", \\\"{x:1284,y:730,t:1527268738449};\\\", \\\"{x:1280,y:730,t:1527268738465};\\\", \\\"{x:1274,y:730,t:1527268738481};\\\", \\\"{x:1269,y:730,t:1527268738499};\\\", \\\"{x:1262,y:732,t:1527268738515};\\\", \\\"{x:1247,y:738,t:1527268738532};\\\", \\\"{x:1233,y:744,t:1527268738549};\\\", \\\"{x:1222,y:750,t:1527268738565};\\\", \\\"{x:1213,y:754,t:1527268738582};\\\", \\\"{x:1208,y:757,t:1527268738599};\\\", \\\"{x:1204,y:758,t:1527268738615};\\\", \\\"{x:1201,y:760,t:1527268738632};\\\", \\\"{x:1200,y:761,t:1527268738650};\\\", \\\"{x:1198,y:761,t:1527268738665};\\\", \\\"{x:1196,y:763,t:1527268738682};\\\", \\\"{x:1195,y:764,t:1527268738699};\\\", \\\"{x:1194,y:765,t:1527268738723};\\\", \\\"{x:1192,y:767,t:1527268738771};\\\", \\\"{x:1194,y:768,t:1527268739044};\\\", \\\"{x:1198,y:769,t:1527268739051};\\\", \\\"{x:1203,y:770,t:1527268739067};\\\", \\\"{x:1209,y:772,t:1527268739083};\\\", \\\"{x:1216,y:773,t:1527268739100};\\\", \\\"{x:1221,y:775,t:1527268739118};\\\", \\\"{x:1227,y:776,t:1527268739133};\\\", \\\"{x:1229,y:776,t:1527268739150};\\\", \\\"{x:1230,y:776,t:1527268739203};\\\", \\\"{x:1230,y:777,t:1527268739660};\\\", \\\"{x:1229,y:778,t:1527268739668};\\\", \\\"{x:1228,y:778,t:1527268739684};\\\", \\\"{x:1229,y:778,t:1527268740571};\\\", \\\"{x:1231,y:778,t:1527268740652};\\\", \\\"{x:1236,y:778,t:1527268740668};\\\", \\\"{x:1240,y:779,t:1527268740684};\\\", \\\"{x:1249,y:782,t:1527268740701};\\\", \\\"{x:1258,y:784,t:1527268740719};\\\", \\\"{x:1267,y:786,t:1527268740734};\\\", \\\"{x:1274,y:787,t:1527268740751};\\\", \\\"{x:1279,y:788,t:1527268740768};\\\", \\\"{x:1281,y:788,t:1527268740784};\\\", \\\"{x:1282,y:788,t:1527268741172};\\\", \\\"{x:1283,y:788,t:1527268741195};\\\", \\\"{x:1283,y:787,t:1527268741219};\\\", \\\"{x:1284,y:787,t:1527268741235};\\\", \\\"{x:1284,y:785,t:1527268741251};\\\", \\\"{x:1284,y:784,t:1527268741270};\\\", \\\"{x:1285,y:783,t:1527268741291};\\\", \\\"{x:1285,y:782,t:1527268741499};\\\", \\\"{x:1285,y:780,t:1527268741636};\\\", \\\"{x:1286,y:780,t:1527268741917};\\\", \\\"{x:1287,y:780,t:1527268742067};\\\", \\\"{x:1288,y:780,t:1527268742075};\\\", \\\"{x:1289,y:779,t:1527268742085};\\\", \\\"{x:1295,y:779,t:1527268742102};\\\", \\\"{x:1305,y:779,t:1527268742119};\\\", \\\"{x:1317,y:779,t:1527268742135};\\\", \\\"{x:1330,y:779,t:1527268742152};\\\", \\\"{x:1345,y:779,t:1527268742169};\\\", \\\"{x:1358,y:779,t:1527268742185};\\\", \\\"{x:1367,y:779,t:1527268742202};\\\", \\\"{x:1373,y:779,t:1527268742219};\\\", \\\"{x:1373,y:778,t:1527268742420};\\\", \\\"{x:1370,y:777,t:1527268742436};\\\", \\\"{x:1368,y:777,t:1527268742452};\\\", \\\"{x:1366,y:777,t:1527268742470};\\\", \\\"{x:1367,y:777,t:1527268742692};\\\", \\\"{x:1368,y:777,t:1527268742703};\\\", \\\"{x:1371,y:777,t:1527268742719};\\\", \\\"{x:1375,y:777,t:1527268742736};\\\", \\\"{x:1378,y:777,t:1527268742753};\\\", \\\"{x:1382,y:777,t:1527268742769};\\\", \\\"{x:1387,y:777,t:1527268742786};\\\", \\\"{x:1395,y:777,t:1527268742803};\\\", \\\"{x:1400,y:777,t:1527268742819};\\\", \\\"{x:1404,y:777,t:1527268742836};\\\", \\\"{x:1410,y:777,t:1527268742854};\\\", \\\"{x:1414,y:778,t:1527268742870};\\\", \\\"{x:1418,y:779,t:1527268742887};\\\", \\\"{x:1419,y:779,t:1527268742903};\\\", \\\"{x:1420,y:779,t:1527268742919};\\\", \\\"{x:1421,y:779,t:1527268743267};\\\", \\\"{x:1421,y:780,t:1527268743283};\\\", \\\"{x:1420,y:781,t:1527268743300};\\\", \\\"{x:1419,y:782,t:1527268743307};\\\", \\\"{x:1418,y:782,t:1527268743320};\\\", \\\"{x:1415,y:785,t:1527268743336};\\\", \\\"{x:1412,y:788,t:1527268743353};\\\", \\\"{x:1406,y:793,t:1527268743370};\\\", \\\"{x:1401,y:798,t:1527268743387};\\\", \\\"{x:1395,y:808,t:1527268743402};\\\", \\\"{x:1393,y:812,t:1527268743419};\\\", \\\"{x:1391,y:815,t:1527268743436};\\\", \\\"{x:1389,y:817,t:1527268743452};\\\", \\\"{x:1386,y:820,t:1527268743470};\\\", \\\"{x:1386,y:821,t:1527268743486};\\\", \\\"{x:1384,y:823,t:1527268743503};\\\", \\\"{x:1383,y:823,t:1527268743519};\\\", \\\"{x:1383,y:824,t:1527268743536};\\\", \\\"{x:1382,y:824,t:1527268743553};\\\", \\\"{x:1381,y:825,t:1527268743569};\\\", \\\"{x:1380,y:826,t:1527268743586};\\\", \\\"{x:1379,y:827,t:1527268743610};\\\", \\\"{x:1378,y:827,t:1527268743635};\\\", \\\"{x:1377,y:827,t:1527268743667};\\\", \\\"{x:1377,y:828,t:1527268743676};\\\", \\\"{x:1375,y:829,t:1527268743688};\\\", \\\"{x:1373,y:830,t:1527268743704};\\\", \\\"{x:1372,y:831,t:1527268743720};\\\", \\\"{x:1371,y:831,t:1527268743755};\\\", \\\"{x:1370,y:832,t:1527268743779};\\\", \\\"{x:1369,y:833,t:1527268744043};\\\", \\\"{x:1369,y:835,t:1527268744059};\\\", \\\"{x:1370,y:835,t:1527268744070};\\\", \\\"{x:1373,y:838,t:1527268744087};\\\", \\\"{x:1376,y:840,t:1527268744104};\\\", \\\"{x:1377,y:842,t:1527268744120};\\\", \\\"{x:1379,y:843,t:1527268744138};\\\", \\\"{x:1380,y:840,t:1527268744490};\\\", \\\"{x:1381,y:837,t:1527268744504};\\\", \\\"{x:1384,y:826,t:1527268744520};\\\", \\\"{x:1388,y:813,t:1527268744537};\\\", \\\"{x:1390,y:799,t:1527268744554};\\\", \\\"{x:1391,y:786,t:1527268744569};\\\", \\\"{x:1394,y:769,t:1527268744587};\\\", \\\"{x:1396,y:756,t:1527268744604};\\\", \\\"{x:1398,y:747,t:1527268744620};\\\", \\\"{x:1398,y:740,t:1527268744637};\\\", \\\"{x:1399,y:733,t:1527268744654};\\\", \\\"{x:1399,y:727,t:1527268744670};\\\", \\\"{x:1399,y:723,t:1527268744687};\\\", \\\"{x:1399,y:719,t:1527268744704};\\\", \\\"{x:1399,y:717,t:1527268744721};\\\", \\\"{x:1399,y:714,t:1527268744737};\\\", \\\"{x:1398,y:712,t:1527268744754};\\\", \\\"{x:1397,y:708,t:1527268744771};\\\", \\\"{x:1396,y:705,t:1527268744787};\\\", \\\"{x:1395,y:702,t:1527268744804};\\\", \\\"{x:1395,y:701,t:1527268744821};\\\", \\\"{x:1394,y:701,t:1527268744837};\\\", \\\"{x:1395,y:701,t:1527268745554};\\\", \\\"{x:1402,y:701,t:1527268745571};\\\", \\\"{x:1414,y:701,t:1527268745588};\\\", \\\"{x:1426,y:703,t:1527268745604};\\\", \\\"{x:1437,y:705,t:1527268745621};\\\", \\\"{x:1445,y:706,t:1527268745638};\\\", \\\"{x:1447,y:706,t:1527268745654};\\\", \\\"{x:1449,y:707,t:1527268745671};\\\", \\\"{x:1451,y:707,t:1527268747292};\\\", \\\"{x:1452,y:707,t:1527268747306};\\\", \\\"{x:1461,y:707,t:1527268747323};\\\", \\\"{x:1477,y:707,t:1527268747339};\\\", \\\"{x:1483,y:707,t:1527268747356};\\\", \\\"{x:1489,y:708,t:1527268747372};\\\", \\\"{x:1493,y:708,t:1527268747389};\\\", \\\"{x:1494,y:708,t:1527268747419};\\\", \\\"{x:1495,y:708,t:1527268747443};\\\", \\\"{x:1497,y:708,t:1527268747456};\\\", \\\"{x:1500,y:708,t:1527268747473};\\\", \\\"{x:1504,y:708,t:1527268747489};\\\", \\\"{x:1506,y:708,t:1527268747506};\\\", \\\"{x:1509,y:708,t:1527268747522};\\\", \\\"{x:1510,y:708,t:1527268747563};\\\", \\\"{x:1511,y:708,t:1527268747579};\\\", \\\"{x:1513,y:709,t:1527268747589};\\\", \\\"{x:1514,y:709,t:1527268748131};\\\", \\\"{x:1515,y:709,t:1527268748147};\\\", \\\"{x:1516,y:709,t:1527268748700};\\\", \\\"{x:1518,y:709,t:1527268748899};\\\", \\\"{x:1521,y:709,t:1527268748907};\\\", \\\"{x:1527,y:709,t:1527268748923};\\\", \\\"{x:1533,y:711,t:1527268748940};\\\", \\\"{x:1539,y:711,t:1527268748957};\\\", \\\"{x:1542,y:712,t:1527268748974};\\\", \\\"{x:1543,y:712,t:1527268749027};\\\", \\\"{x:1545,y:712,t:1527268749040};\\\", \\\"{x:1548,y:712,t:1527268749057};\\\", \\\"{x:1553,y:712,t:1527268749075};\\\", \\\"{x:1559,y:712,t:1527268749091};\\\", \\\"{x:1563,y:712,t:1527268749107};\\\", \\\"{x:1565,y:712,t:1527268749124};\\\", \\\"{x:1566,y:712,t:1527268749141};\\\", \\\"{x:1567,y:712,t:1527268749158};\\\", \\\"{x:1568,y:712,t:1527268749175};\\\", \\\"{x:1570,y:712,t:1527268749190};\\\", \\\"{x:1571,y:712,t:1527268749227};\\\", \\\"{x:1569,y:712,t:1527268750012};\\\", \\\"{x:1566,y:713,t:1527268750024};\\\", \\\"{x:1556,y:714,t:1527268750042};\\\", \\\"{x:1541,y:717,t:1527268750059};\\\", \\\"{x:1525,y:718,t:1527268750075};\\\", \\\"{x:1501,y:719,t:1527268750091};\\\", \\\"{x:1486,y:719,t:1527268750109};\\\", \\\"{x:1470,y:719,t:1527268750125};\\\", \\\"{x:1452,y:719,t:1527268750142};\\\", \\\"{x:1434,y:721,t:1527268750159};\\\", \\\"{x:1417,y:723,t:1527268750174};\\\", \\\"{x:1408,y:726,t:1527268750191};\\\", \\\"{x:1402,y:727,t:1527268750208};\\\", \\\"{x:1399,y:729,t:1527268750225};\\\", \\\"{x:1397,y:730,t:1527268750242};\\\", \\\"{x:1396,y:731,t:1527268750258};\\\", \\\"{x:1395,y:731,t:1527268750275};\\\", \\\"{x:1395,y:729,t:1527268750403};\\\", \\\"{x:1395,y:727,t:1527268750412};\\\", \\\"{x:1395,y:726,t:1527268750425};\\\", \\\"{x:1395,y:723,t:1527268750442};\\\", \\\"{x:1395,y:721,t:1527268750458};\\\", \\\"{x:1394,y:719,t:1527268750476};\\\", \\\"{x:1393,y:719,t:1527268750522};\\\", \\\"{x:1393,y:718,t:1527268750538};\\\", \\\"{x:1392,y:717,t:1527268750570};\\\", \\\"{x:1391,y:717,t:1527268750594};\\\", \\\"{x:1390,y:716,t:1527268750608};\\\", \\\"{x:1388,y:716,t:1527268750683};\\\", \\\"{x:1385,y:716,t:1527268750699};\\\", \\\"{x:1384,y:717,t:1527268750709};\\\", \\\"{x:1383,y:724,t:1527268750725};\\\", \\\"{x:1383,y:730,t:1527268750742};\\\", \\\"{x:1383,y:738,t:1527268750758};\\\", \\\"{x:1383,y:749,t:1527268750776};\\\", \\\"{x:1383,y:759,t:1527268750792};\\\", \\\"{x:1383,y:768,t:1527268750808};\\\", \\\"{x:1384,y:774,t:1527268750825};\\\", \\\"{x:1384,y:781,t:1527268750842};\\\", \\\"{x:1385,y:788,t:1527268750858};\\\", \\\"{x:1387,y:798,t:1527268750875};\\\", \\\"{x:1387,y:804,t:1527268750892};\\\", \\\"{x:1389,y:812,t:1527268750909};\\\", \\\"{x:1390,y:819,t:1527268750925};\\\", \\\"{x:1393,y:826,t:1527268750943};\\\", \\\"{x:1393,y:833,t:1527268750959};\\\", \\\"{x:1394,y:839,t:1527268750976};\\\", \\\"{x:1395,y:847,t:1527268750992};\\\", \\\"{x:1396,y:855,t:1527268751008};\\\", \\\"{x:1398,y:863,t:1527268751026};\\\", \\\"{x:1398,y:872,t:1527268751043};\\\", \\\"{x:1399,y:879,t:1527268751059};\\\", \\\"{x:1401,y:890,t:1527268751076};\\\", \\\"{x:1401,y:894,t:1527268751093};\\\", \\\"{x:1401,y:900,t:1527268751108};\\\", \\\"{x:1401,y:906,t:1527268751126};\\\", \\\"{x:1401,y:911,t:1527268751142};\\\", \\\"{x:1401,y:917,t:1527268751159};\\\", \\\"{x:1401,y:922,t:1527268751175};\\\", \\\"{x:1401,y:924,t:1527268751192};\\\", \\\"{x:1402,y:928,t:1527268751209};\\\", \\\"{x:1402,y:929,t:1527268751225};\\\", \\\"{x:1402,y:932,t:1527268751243};\\\", \\\"{x:1402,y:934,t:1527268751276};\\\", \\\"{x:1402,y:935,t:1527268751299};\\\", \\\"{x:1401,y:936,t:1527268751323};\\\", \\\"{x:1400,y:937,t:1527268751331};\\\", \\\"{x:1399,y:937,t:1527268751343};\\\", \\\"{x:1398,y:938,t:1527268751360};\\\", \\\"{x:1397,y:938,t:1527268751375};\\\", \\\"{x:1396,y:938,t:1527268751547};\\\", \\\"{x:1395,y:938,t:1527268751563};\\\", \\\"{x:1394,y:938,t:1527268751715};\\\", \\\"{x:1394,y:937,t:1527268753612};\\\", \\\"{x:1395,y:937,t:1527268753628};\\\", \\\"{x:1396,y:936,t:1527268754626};\\\", \\\"{x:1396,y:935,t:1527268754634};\\\", \\\"{x:1398,y:934,t:1527268754650};\\\", \\\"{x:1398,y:933,t:1527268754661};\\\", \\\"{x:1399,y:933,t:1527268754678};\\\", \\\"{x:1399,y:932,t:1527268754939};\\\", \\\"{x:1401,y:932,t:1527268754995};\\\", \\\"{x:1401,y:931,t:1527268755011};\\\", \\\"{x:1401,y:928,t:1527268760535};\\\", \\\"{x:1398,y:919,t:1527268760546};\\\", \\\"{x:1383,y:894,t:1527268760563};\\\", \\\"{x:1358,y:862,t:1527268760579};\\\", \\\"{x:1332,y:827,t:1527268760595};\\\", \\\"{x:1294,y:791,t:1527268760613};\\\", \\\"{x:1251,y:756,t:1527268760630};\\\", \\\"{x:1204,y:716,t:1527268760645};\\\", \\\"{x:1156,y:683,t:1527268760663};\\\", \\\"{x:1103,y:649,t:1527268760679};\\\", \\\"{x:1073,y:630,t:1527268760695};\\\", \\\"{x:1042,y:609,t:1527268760713};\\\", \\\"{x:1009,y:594,t:1527268760730};\\\", \\\"{x:973,y:579,t:1527268760746};\\\", \\\"{x:943,y:566,t:1527268760764};\\\", \\\"{x:906,y:549,t:1527268760780};\\\", \\\"{x:875,y:541,t:1527268760796};\\\", \\\"{x:829,y:528,t:1527268760820};\\\", \\\"{x:803,y:523,t:1527268760836};\\\", \\\"{x:779,y:521,t:1527268760852};\\\", \\\"{x:755,y:517,t:1527268760870};\\\", \\\"{x:724,y:512,t:1527268760885};\\\", \\\"{x:685,y:506,t:1527268760903};\\\", \\\"{x:624,y:497,t:1527268760919};\\\", \\\"{x:576,y:489,t:1527268760937};\\\", \\\"{x:542,y:484,t:1527268760952};\\\", \\\"{x:506,y:479,t:1527268760969};\\\", \\\"{x:478,y:478,t:1527268760988};\\\", \\\"{x:453,y:476,t:1527268761003};\\\", \\\"{x:427,y:475,t:1527268761020};\\\", \\\"{x:401,y:475,t:1527268761037};\\\", \\\"{x:378,y:475,t:1527268761054};\\\", \\\"{x:365,y:475,t:1527268761070};\\\", \\\"{x:359,y:475,t:1527268761087};\\\", \\\"{x:354,y:476,t:1527268761102};\\\", \\\"{x:347,y:479,t:1527268761120};\\\", \\\"{x:341,y:483,t:1527268761137};\\\", \\\"{x:338,y:485,t:1527268761153};\\\", \\\"{x:336,y:486,t:1527268761170};\\\", \\\"{x:335,y:487,t:1527268761187};\\\", \\\"{x:335,y:488,t:1527268761203};\\\", \\\"{x:335,y:489,t:1527268761220};\\\", \\\"{x:335,y:491,t:1527268761237};\\\", \\\"{x:335,y:494,t:1527268761254};\\\", \\\"{x:335,y:497,t:1527268761270};\\\", \\\"{x:335,y:501,t:1527268761288};\\\", \\\"{x:337,y:505,t:1527268761304};\\\", \\\"{x:337,y:506,t:1527268761320};\\\", \\\"{x:339,y:507,t:1527268761472};\\\", \\\"{x:340,y:508,t:1527268761487};\\\", \\\"{x:344,y:512,t:1527268761504};\\\", \\\"{x:346,y:514,t:1527268761521};\\\", \\\"{x:349,y:515,t:1527268761537};\\\", \\\"{x:350,y:515,t:1527268761554};\\\", \\\"{x:351,y:515,t:1527268761571};\\\", \\\"{x:352,y:515,t:1527268761656};\\\", \\\"{x:353,y:515,t:1527268761671};\\\", \\\"{x:355,y:515,t:1527268761687};\\\", \\\"{x:356,y:515,t:1527268761704};\\\", \\\"{x:358,y:515,t:1527268761721};\\\", \\\"{x:359,y:515,t:1527268761800};\\\", \\\"{x:362,y:515,t:1527268761808};\\\", \\\"{x:367,y:516,t:1527268761821};\\\", \\\"{x:377,y:516,t:1527268761838};\\\", \\\"{x:382,y:516,t:1527268761853};\\\", \\\"{x:385,y:516,t:1527268762304};\\\", \\\"{x:411,y:520,t:1527268762321};\\\", \\\"{x:443,y:524,t:1527268762339};\\\", \\\"{x:480,y:530,t:1527268762354};\\\", \\\"{x:533,y:537,t:1527268762372};\\\", \\\"{x:595,y:547,t:1527268762388};\\\", \\\"{x:682,y:562,t:1527268762403};\\\", \\\"{x:773,y:573,t:1527268762421};\\\", \\\"{x:868,y:589,t:1527268762438};\\\", \\\"{x:970,y:600,t:1527268762455};\\\", \\\"{x:1076,y:618,t:1527268762471};\\\", \\\"{x:1224,y:638,t:1527268762488};\\\", \\\"{x:1324,y:652,t:1527268762505};\\\", \\\"{x:1419,y:669,t:1527268762521};\\\", \\\"{x:1514,y:683,t:1527268762538};\\\", \\\"{x:1592,y:695,t:1527268762555};\\\", \\\"{x:1659,y:706,t:1527268762571};\\\", \\\"{x:1712,y:712,t:1527268762588};\\\", \\\"{x:1750,y:716,t:1527268762605};\\\", \\\"{x:1775,y:716,t:1527268762621};\\\", \\\"{x:1793,y:716,t:1527268762639};\\\", \\\"{x:1803,y:716,t:1527268762654};\\\", \\\"{x:1807,y:713,t:1527268762671};\\\", \\\"{x:1810,y:708,t:1527268762688};\\\", \\\"{x:1812,y:704,t:1527268762706};\\\", \\\"{x:1812,y:698,t:1527268762721};\\\", \\\"{x:1812,y:691,t:1527268762739};\\\", \\\"{x:1812,y:678,t:1527268762755};\\\", \\\"{x:1811,y:667,t:1527268762771};\\\", \\\"{x:1810,y:652,t:1527268762788};\\\", \\\"{x:1809,y:638,t:1527268762806};\\\", \\\"{x:1809,y:624,t:1527268762821};\\\", \\\"{x:1809,y:613,t:1527268762838};\\\", \\\"{x:1809,y:596,t:1527268762856};\\\", \\\"{x:1809,y:577,t:1527268762872};\\\", \\\"{x:1806,y:548,t:1527268762889};\\\", \\\"{x:1802,y:526,t:1527268762906};\\\", \\\"{x:1795,y:509,t:1527268762921};\\\", \\\"{x:1788,y:503,t:1527268762938};\\\", \\\"{x:1785,y:502,t:1527268762955};\\\", \\\"{x:1783,y:501,t:1527268762973};\\\", \\\"{x:1780,y:501,t:1527268762988};\\\", \\\"{x:1778,y:499,t:1527268763006};\\\", \\\"{x:1775,y:498,t:1527268763022};\\\", \\\"{x:1766,y:492,t:1527268763038};\\\", \\\"{x:1756,y:488,t:1527268763055};\\\", \\\"{x:1725,y:441,t:1527268763073};\\\", \\\"{x:1698,y:394,t:1527268763088};\\\", \\\"{x:1664,y:356,t:1527268763105};\\\", \\\"{x:1637,y:332,t:1527268763122};\\\", \\\"{x:1606,y:309,t:1527268763139};\\\", \\\"{x:1584,y:296,t:1527268763156};\\\", \\\"{x:1563,y:287,t:1527268763173};\\\", \\\"{x:1547,y:285,t:1527268763188};\\\", \\\"{x:1538,y:285,t:1527268763206};\\\", \\\"{x:1532,y:285,t:1527268763222};\\\", \\\"{x:1526,y:287,t:1527268763239};\\\", \\\"{x:1515,y:289,t:1527268763256};\\\", \\\"{x:1505,y:294,t:1527268763273};\\\", \\\"{x:1502,y:297,t:1527268763288};\\\", \\\"{x:1497,y:301,t:1527268763305};\\\", \\\"{x:1493,y:304,t:1527268763323};\\\", \\\"{x:1488,y:308,t:1527268763338};\\\", \\\"{x:1485,y:312,t:1527268763356};\\\", \\\"{x:1482,y:316,t:1527268763372};\\\", \\\"{x:1474,y:322,t:1527268763389};\\\", \\\"{x:1466,y:328,t:1527268763406};\\\", \\\"{x:1458,y:332,t:1527268763422};\\\", \\\"{x:1449,y:337,t:1527268763440};\\\", \\\"{x:1443,y:342,t:1527268763455};\\\", \\\"{x:1435,y:349,t:1527268763472};\\\", \\\"{x:1432,y:354,t:1527268763489};\\\", \\\"{x:1431,y:357,t:1527268763506};\\\", \\\"{x:1430,y:360,t:1527268763522};\\\", \\\"{x:1430,y:362,t:1527268763540};\\\", \\\"{x:1430,y:363,t:1527268763556};\\\", \\\"{x:1429,y:363,t:1527268763573};\\\", \\\"{x:1429,y:364,t:1527268763704};\\\", \\\"{x:1429,y:365,t:1527268763759};\\\", \\\"{x:1429,y:366,t:1527268763783};\\\", \\\"{x:1429,y:367,t:1527268765103};\\\", \\\"{x:1430,y:367,t:1527268766399};\\\", \\\"{x:1431,y:367,t:1527268766504};\\\", \\\"{x:1432,y:368,t:1527268766511};\\\", \\\"{x:1432,y:369,t:1527268766631};\\\", \\\"{x:1433,y:369,t:1527268767695};\\\", \\\"{x:1434,y:370,t:1527268767708};\\\", \\\"{x:1434,y:372,t:1527268767725};\\\", \\\"{x:1435,y:374,t:1527268767742};\\\", \\\"{x:1435,y:375,t:1527268767759};\\\", \\\"{x:1436,y:375,t:1527268767776};\\\", \\\"{x:1436,y:377,t:1527268768505};\\\", \\\"{x:1436,y:378,t:1527268768520};\\\", \\\"{x:1437,y:378,t:1527268768528};\\\", \\\"{x:1437,y:380,t:1527268768543};\\\", \\\"{x:1439,y:381,t:1527268768560};\\\", \\\"{x:1439,y:382,t:1527268768577};\\\", \\\"{x:1440,y:383,t:1527268768592};\\\", \\\"{x:1440,y:385,t:1527268768609};\\\", \\\"{x:1442,y:388,t:1527268768627};\\\", \\\"{x:1443,y:392,t:1527268768643};\\\", \\\"{x:1443,y:398,t:1527268768660};\\\", \\\"{x:1445,y:404,t:1527268768676};\\\", \\\"{x:1446,y:410,t:1527268768692};\\\", \\\"{x:1446,y:414,t:1527268768709};\\\", \\\"{x:1447,y:418,t:1527268768727};\\\", \\\"{x:1451,y:427,t:1527268768743};\\\", \\\"{x:1457,y:439,t:1527268768760};\\\", \\\"{x:1466,y:459,t:1527268768776};\\\", \\\"{x:1471,y:475,t:1527268768793};\\\", \\\"{x:1477,y:491,t:1527268768809};\\\", \\\"{x:1485,y:510,t:1527268768827};\\\", \\\"{x:1501,y:534,t:1527268768844};\\\", \\\"{x:1511,y:557,t:1527268768860};\\\", \\\"{x:1516,y:576,t:1527268768877};\\\", \\\"{x:1517,y:590,t:1527268768894};\\\", \\\"{x:1520,y:605,t:1527268768909};\\\", \\\"{x:1520,y:611,t:1527268768927};\\\", \\\"{x:1520,y:615,t:1527268768943};\\\", \\\"{x:1520,y:618,t:1527268768959};\\\", \\\"{x:1520,y:621,t:1527268768976};\\\", \\\"{x:1516,y:629,t:1527268768994};\\\", \\\"{x:1513,y:640,t:1527268769009};\\\", \\\"{x:1509,y:654,t:1527268769026};\\\", \\\"{x:1505,y:667,t:1527268769044};\\\", \\\"{x:1503,y:679,t:1527268769060};\\\", \\\"{x:1499,y:693,t:1527268769076};\\\", \\\"{x:1494,y:707,t:1527268769094};\\\", \\\"{x:1491,y:716,t:1527268769109};\\\", \\\"{x:1490,y:724,t:1527268769126};\\\", \\\"{x:1486,y:732,t:1527268769144};\\\", \\\"{x:1482,y:745,t:1527268769160};\\\", \\\"{x:1480,y:751,t:1527268769177};\\\", \\\"{x:1478,y:757,t:1527268769194};\\\", \\\"{x:1474,y:761,t:1527268769211};\\\", \\\"{x:1473,y:765,t:1527268769226};\\\", \\\"{x:1472,y:768,t:1527268769244};\\\", \\\"{x:1470,y:771,t:1527268769260};\\\", \\\"{x:1470,y:773,t:1527268769276};\\\", \\\"{x:1470,y:775,t:1527268769293};\\\", \\\"{x:1470,y:777,t:1527268769310};\\\", \\\"{x:1470,y:779,t:1527268769326};\\\", \\\"{x:1470,y:783,t:1527268769343};\\\", \\\"{x:1470,y:786,t:1527268769359};\\\", \\\"{x:1470,y:788,t:1527268769376};\\\", \\\"{x:1471,y:790,t:1527268769394};\\\", \\\"{x:1472,y:792,t:1527268769410};\\\", \\\"{x:1474,y:793,t:1527268769426};\\\", \\\"{x:1475,y:794,t:1527268769496};\\\", \\\"{x:1476,y:794,t:1527268769520};\\\", \\\"{x:1476,y:795,t:1527268769528};\\\", \\\"{x:1476,y:796,t:1527268769543};\\\", \\\"{x:1477,y:796,t:1527268769584};\\\", \\\"{x:1476,y:796,t:1527268769952};\\\", \\\"{x:1473,y:795,t:1527268769960};\\\", \\\"{x:1464,y:790,t:1527268769977};\\\", \\\"{x:1449,y:786,t:1527268769994};\\\", \\\"{x:1431,y:781,t:1527268770010};\\\", \\\"{x:1407,y:774,t:1527268770028};\\\", \\\"{x:1376,y:768,t:1527268770044};\\\", \\\"{x:1338,y:758,t:1527268770060};\\\", \\\"{x:1293,y:751,t:1527268770078};\\\", \\\"{x:1246,y:745,t:1527268770095};\\\", \\\"{x:1198,y:745,t:1527268770110};\\\", \\\"{x:1120,y:745,t:1527268770128};\\\", \\\"{x:1059,y:745,t:1527268770144};\\\", \\\"{x:1008,y:745,t:1527268770161};\\\", \\\"{x:944,y:745,t:1527268770177};\\\", \\\"{x:897,y:745,t:1527268770194};\\\", \\\"{x:849,y:745,t:1527268770210};\\\", \\\"{x:807,y:745,t:1527268770228};\\\", \\\"{x:771,y:745,t:1527268770244};\\\", \\\"{x:737,y:742,t:1527268770261};\\\", \\\"{x:702,y:738,t:1527268770277};\\\", \\\"{x:676,y:733,t:1527268770295};\\\", \\\"{x:658,y:729,t:1527268770311};\\\", \\\"{x:631,y:722,t:1527268770328};\\\", \\\"{x:618,y:718,t:1527268770344};\\\", \\\"{x:607,y:715,t:1527268770360};\\\", \\\"{x:600,y:712,t:1527268770377};\\\", \\\"{x:593,y:710,t:1527268770394};\\\", \\\"{x:588,y:709,t:1527268770411};\\\", \\\"{x:587,y:708,t:1527268770427};\\\", \\\"{x:585,y:707,t:1527268770444};\\\", \\\"{x:585,y:706,t:1527268770460};\\\", \\\"{x:584,y:706,t:1527268770480};\\\", \\\"{x:583,y:705,t:1527268770494};\\\", \\\"{x:580,y:702,t:1527268770512};\\\", \\\"{x:579,y:701,t:1527268770527};\\\", \\\"{x:566,y:693,t:1527268770544};\\\", \\\"{x:556,y:687,t:1527268770562};\\\", \\\"{x:549,y:683,t:1527268770577};\\\", \\\"{x:545,y:681,t:1527268770594};\\\", \\\"{x:542,y:680,t:1527268770610};\\\", \\\"{x:541,y:680,t:1527268770627};\\\", \\\"{x:540,y:680,t:1527268770644};\\\", \\\"{x:538,y:679,t:1527268770660};\\\", \\\"{x:537,y:678,t:1527268770677};\\\", \\\"{x:536,y:678,t:1527268770703};\\\", \\\"{x:535,y:678,t:1527268770727};\\\", \\\"{x:534,y:678,t:1527268770759};\\\", \\\"{x:533,y:678,t:1527268770767};\\\", \\\"{x:533,y:677,t:1527268771680};\\\", \\\"{x:532,y:675,t:1527268771695};\\\" ] }, { \\\"rt\\\": 14275, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 10, \\\"time_elapsed\\\": 329645, \\\"internal_node_id\\\": \\\"0.0-6.0-0.0\\\", \\\"subject\\\": \\\"YC7SX\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"mike\\\", \\\"condition\\\": \\\"115-late\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"duration\\\", \\\"q\\\": 6, \\\"clicks\\\": 3.5, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XFull-YFull\\\", \\\"correct\\\": 1, \\\"orth_correct\\\": 1, \\\"answer\\\": [ \\\"E\\\", \\\"G\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-E -6\\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:532,y:674,t:1527268774312};\\\", \\\"{x:534,y:672,t:1527268774331};\\\", \\\"{x:536,y:671,t:1527268774347};\\\", \\\"{x:540,y:669,t:1527268774364};\\\", \\\"{x:549,y:669,t:1527268774381};\\\", \\\"{x:568,y:669,t:1527268774399};\\\", \\\"{x:590,y:670,t:1527268774413};\\\", \\\"{x:621,y:675,t:1527268774430};\\\", \\\"{x:678,y:682,t:1527268774446};\\\", \\\"{x:720,y:682,t:1527268774464};\\\", \\\"{x:773,y:682,t:1527268774480};\\\", \\\"{x:813,y:681,t:1527268774497};\\\", \\\"{x:851,y:679,t:1527268774514};\\\", \\\"{x:893,y:679,t:1527268774530};\\\", \\\"{x:932,y:679,t:1527268774547};\\\", \\\"{x:971,y:679,t:1527268774563};\\\", \\\"{x:998,y:679,t:1527268774580};\\\", \\\"{x:1019,y:679,t:1527268774597};\\\", \\\"{x:1041,y:679,t:1527268774620};\\\", \\\"{x:1044,y:679,t:1527268774630};\\\", \\\"{x:1048,y:678,t:1527268774647};\\\", \\\"{x:1049,y:678,t:1527268774840};\\\", \\\"{x:1050,y:678,t:1527268774848};\\\", \\\"{x:1051,y:678,t:1527268774888};\\\", \\\"{x:1052,y:677,t:1527268775096};\\\", \\\"{x:1055,y:675,t:1527268775104};\\\", \\\"{x:1058,y:674,t:1527268775115};\\\", \\\"{x:1064,y:671,t:1527268775132};\\\", \\\"{x:1072,y:666,t:1527268775148};\\\", \\\"{x:1078,y:664,t:1527268775164};\\\", \\\"{x:1083,y:662,t:1527268775182};\\\", \\\"{x:1088,y:660,t:1527268775197};\\\", \\\"{x:1091,y:659,t:1527268775214};\\\", \\\"{x:1100,y:656,t:1527268775232};\\\", \\\"{x:1104,y:656,t:1527268775248};\\\", \\\"{x:1106,y:655,t:1527268775265};\\\", \\\"{x:1106,y:653,t:1527268776664};\\\", \\\"{x:1106,y:649,t:1527268776672};\\\", \\\"{x:1106,y:646,t:1527268776683};\\\", \\\"{x:1106,y:639,t:1527268776699};\\\", \\\"{x:1106,y:631,t:1527268776716};\\\", \\\"{x:1106,y:625,t:1527268776733};\\\", \\\"{x:1106,y:620,t:1527268776750};\\\", \\\"{x:1106,y:614,t:1527268776766};\\\", \\\"{x:1106,y:608,t:1527268776783};\\\", \\\"{x:1106,y:601,t:1527268776800};\\\", \\\"{x:1107,y:595,t:1527268776816};\\\", \\\"{x:1108,y:589,t:1527268776833};\\\", \\\"{x:1111,y:583,t:1527268776850};\\\", \\\"{x:1114,y:576,t:1527268776866};\\\", \\\"{x:1116,y:569,t:1527268776883};\\\", \\\"{x:1123,y:559,t:1527268776900};\\\", \\\"{x:1129,y:548,t:1527268776916};\\\", \\\"{x:1134,y:540,t:1527268776932};\\\", \\\"{x:1135,y:535,t:1527268776950};\\\", \\\"{x:1139,y:529,t:1527268776966};\\\", \\\"{x:1146,y:523,t:1527268776983};\\\", \\\"{x:1151,y:519,t:1527268777000};\\\", \\\"{x:1154,y:517,t:1527268777016};\\\", \\\"{x:1158,y:515,t:1527268777033};\\\", \\\"{x:1161,y:514,t:1527268777050};\\\", \\\"{x:1163,y:513,t:1527268777066};\\\", \\\"{x:1165,y:513,t:1527268777083};\\\", \\\"{x:1166,y:513,t:1527268777100};\\\", \\\"{x:1171,y:512,t:1527268777116};\\\", \\\"{x:1180,y:512,t:1527268777133};\\\", \\\"{x:1193,y:512,t:1527268777150};\\\", \\\"{x:1212,y:512,t:1527268777166};\\\", \\\"{x:1236,y:512,t:1527268777183};\\\", \\\"{x:1276,y:512,t:1527268777203};\\\", \\\"{x:1299,y:512,t:1527268777217};\\\", \\\"{x:1326,y:512,t:1527268777233};\\\", \\\"{x:1352,y:512,t:1527268777249};\\\", \\\"{x:1378,y:515,t:1527268777267};\\\", \\\"{x:1399,y:517,t:1527268777283};\\\", \\\"{x:1413,y:518,t:1527268777299};\\\", \\\"{x:1425,y:520,t:1527268777317};\\\", \\\"{x:1431,y:521,t:1527268777333};\\\", \\\"{x:1435,y:521,t:1527268777350};\\\", \\\"{x:1436,y:521,t:1527268777367};\\\", \\\"{x:1435,y:521,t:1527268777503};\\\", \\\"{x:1433,y:521,t:1527268777516};\\\", \\\"{x:1432,y:521,t:1527268777532};\\\", \\\"{x:1429,y:521,t:1527268777550};\\\", \\\"{x:1427,y:521,t:1527268777567};\\\", \\\"{x:1426,y:521,t:1527268777592};\\\", \\\"{x:1424,y:521,t:1527268777648};\\\", \\\"{x:1423,y:521,t:1527268777656};\\\", \\\"{x:1421,y:521,t:1527268777667};\\\", \\\"{x:1416,y:521,t:1527268777683};\\\", \\\"{x:1408,y:521,t:1527268777699};\\\", \\\"{x:1390,y:521,t:1527268777717};\\\", \\\"{x:1363,y:521,t:1527268777734};\\\", \\\"{x:1303,y:517,t:1527268777750};\\\", \\\"{x:1210,y:512,t:1527268777767};\\\", \\\"{x:1060,y:510,t:1527268777784};\\\", \\\"{x:952,y:510,t:1527268777801};\\\", \\\"{x:857,y:510,t:1527268777818};\\\", \\\"{x:791,y:510,t:1527268777834};\\\", \\\"{x:743,y:510,t:1527268777849};\\\", \\\"{x:706,y:510,t:1527268777867};\\\", \\\"{x:676,y:510,t:1527268777883};\\\", \\\"{x:650,y:510,t:1527268777901};\\\", \\\"{x:624,y:510,t:1527268777916};\\\", \\\"{x:600,y:510,t:1527268777934};\\\", \\\"{x:571,y:510,t:1527268777950};\\\", \\\"{x:540,y:510,t:1527268777966};\\\", \\\"{x:498,y:510,t:1527268777984};\\\", \\\"{x:473,y:508,t:1527268778000};\\\", \\\"{x:454,y:505,t:1527268778016};\\\", \\\"{x:445,y:505,t:1527268778033};\\\", \\\"{x:443,y:505,t:1527268778051};\\\", \\\"{x:444,y:504,t:1527268778087};\\\", \\\"{x:445,y:503,t:1527268778100};\\\", \\\"{x:450,y:501,t:1527268778118};\\\", \\\"{x:459,y:498,t:1527268778134};\\\", \\\"{x:472,y:492,t:1527268778150};\\\", \\\"{x:498,y:485,t:1527268778167};\\\", \\\"{x:517,y:479,t:1527268778185};\\\", \\\"{x:538,y:473,t:1527268778200};\\\", \\\"{x:557,y:468,t:1527268778218};\\\", \\\"{x:574,y:463,t:1527268778234};\\\", \\\"{x:586,y:459,t:1527268778250};\\\", \\\"{x:589,y:458,t:1527268778267};\\\", \\\"{x:590,y:458,t:1527268778283};\\\", \\\"{x:591,y:458,t:1527268778383};\\\", \\\"{x:597,y:456,t:1527268778761};\\\", \\\"{x:609,y:456,t:1527268778768};\\\", \\\"{x:645,y:456,t:1527268778783};\\\", \\\"{x:682,y:456,t:1527268778799};\\\", \\\"{x:724,y:456,t:1527268778817};\\\", \\\"{x:770,y:460,t:1527268778833};\\\", \\\"{x:816,y:467,t:1527268778851};\\\", \\\"{x:844,y:477,t:1527268778869};\\\", \\\"{x:859,y:483,t:1527268778884};\\\", \\\"{x:869,y:491,t:1527268778900};\\\", \\\"{x:873,y:495,t:1527268778918};\\\", \\\"{x:873,y:496,t:1527268778935};\\\", \\\"{x:873,y:497,t:1527268779041};\\\", \\\"{x:873,y:498,t:1527268779051};\\\", \\\"{x:873,y:499,t:1527268779067};\\\", \\\"{x:870,y:500,t:1527268779085};\\\", \\\"{x:863,y:500,t:1527268779102};\\\", \\\"{x:855,y:500,t:1527268779118};\\\", \\\"{x:851,y:500,t:1527268779134};\\\", \\\"{x:850,y:500,t:1527268779151};\\\", \\\"{x:849,y:500,t:1527268779192};\\\", \\\"{x:849,y:499,t:1527268779232};\\\", \\\"{x:849,y:498,t:1527268779248};\\\", \\\"{x:849,y:497,t:1527268779272};\\\", \\\"{x:849,y:496,t:1527268779285};\\\", \\\"{x:849,y:495,t:1527268779302};\\\", \\\"{x:848,y:494,t:1527268779318};\\\", \\\"{x:848,y:492,t:1527268779334};\\\", \\\"{x:847,y:490,t:1527268779351};\\\", \\\"{x:846,y:489,t:1527268779383};\\\", \\\"{x:839,y:489,t:1527268779583};\\\", \\\"{x:828,y:489,t:1527268779591};\\\", \\\"{x:815,y:489,t:1527268779601};\\\", \\\"{x:772,y:486,t:1527268779618};\\\", \\\"{x:704,y:474,t:1527268779635};\\\", \\\"{x:647,y:469,t:1527268779651};\\\", \\\"{x:617,y:464,t:1527268779669};\\\", \\\"{x:599,y:458,t:1527268779685};\\\", \\\"{x:586,y:450,t:1527268779702};\\\", \\\"{x:582,y:446,t:1527268779719};\\\", \\\"{x:582,y:445,t:1527268779734};\\\", \\\"{x:584,y:445,t:1527268779848};\\\", \\\"{x:585,y:445,t:1527268779872};\\\", \\\"{x:586,y:445,t:1527268779888};\\\", \\\"{x:587,y:445,t:1527268779901};\\\", \\\"{x:590,y:445,t:1527268780168};\\\", \\\"{x:592,y:445,t:1527268780185};\\\", \\\"{x:595,y:445,t:1527268780240};\\\", \\\"{x:599,y:445,t:1527268780252};\\\", \\\"{x:616,y:448,t:1527268780269};\\\", \\\"{x:638,y:450,t:1527268780285};\\\", \\\"{x:664,y:452,t:1527268780302};\\\", \\\"{x:701,y:456,t:1527268780319};\\\", \\\"{x:766,y:463,t:1527268780336};\\\", \\\"{x:805,y:469,t:1527268780353};\\\", \\\"{x:834,y:473,t:1527268780369};\\\", \\\"{x:852,y:475,t:1527268780386};\\\", \\\"{x:854,y:477,t:1527268780402};\\\", \\\"{x:852,y:477,t:1527268780455};\\\", \\\"{x:846,y:476,t:1527268780468};\\\", \\\"{x:808,y:475,t:1527268780486};\\\", \\\"{x:747,y:469,t:1527268780504};\\\", \\\"{x:643,y:463,t:1527268780520};\\\", \\\"{x:583,y:458,t:1527268780536};\\\", \\\"{x:552,y:449,t:1527268780552};\\\", \\\"{x:536,y:446,t:1527268780568};\\\", \\\"{x:535,y:446,t:1527268780591};\\\", \\\"{x:535,y:445,t:1527268780607};\\\", \\\"{x:536,y:445,t:1527268780671};\\\", \\\"{x:537,y:444,t:1527268780686};\\\", \\\"{x:545,y:443,t:1527268780702};\\\", \\\"{x:561,y:440,t:1527268780720};\\\", \\\"{x:572,y:439,t:1527268780736};\\\", \\\"{x:582,y:439,t:1527268780752};\\\", \\\"{x:590,y:439,t:1527268780770};\\\", \\\"{x:596,y:439,t:1527268780786};\\\", \\\"{x:597,y:439,t:1527268780807};\\\", \\\"{x:598,y:439,t:1527268780953};\\\", \\\"{x:601,y:439,t:1527268781243};\\\", \\\"{x:608,y:442,t:1527268781281};\\\", \\\"{x:611,y:442,t:1527268781287};\\\", \\\"{x:614,y:443,t:1527268781301};\\\", \\\"{x:619,y:445,t:1527268781318};\\\", \\\"{x:628,y:447,t:1527268781334};\\\", \\\"{x:636,y:450,t:1527268781351};\\\", \\\"{x:640,y:452,t:1527268781943};\\\", \\\"{x:651,y:454,t:1527268781954};\\\", \\\"{x:691,y:465,t:1527268781970};\\\", \\\"{x:750,y:475,t:1527268781987};\\\", \\\"{x:806,y:483,t:1527268782004};\\\", \\\"{x:870,y:492,t:1527268782019};\\\", \\\"{x:919,y:501,t:1527268782036};\\\", \\\"{x:941,y:504,t:1527268782054};\\\", \\\"{x:945,y:505,t:1527268782070};\\\", \\\"{x:943,y:504,t:1527268782161};\\\", \\\"{x:939,y:504,t:1527268782170};\\\", \\\"{x:923,y:502,t:1527268782187};\\\", \\\"{x:901,y:498,t:1527268782203};\\\", \\\"{x:883,y:497,t:1527268782220};\\\", \\\"{x:865,y:494,t:1527268782237};\\\", \\\"{x:852,y:492,t:1527268782254};\\\", \\\"{x:846,y:491,t:1527268782271};\\\", \\\"{x:843,y:490,t:1527268782287};\\\", \\\"{x:843,y:489,t:1527268782304};\\\", \\\"{x:842,y:489,t:1527268782344};\\\", \\\"{x:841,y:489,t:1527268782359};\\\", \\\"{x:840,y:489,t:1527268782371};\\\", \\\"{x:835,y:489,t:1527268782387};\\\", \\\"{x:830,y:488,t:1527268782404};\\\", \\\"{x:826,y:486,t:1527268782421};\\\", \\\"{x:825,y:486,t:1527268782438};\\\", \\\"{x:821,y:486,t:1527268782816};\\\", \\\"{x:814,y:490,t:1527268782824};\\\", \\\"{x:809,y:494,t:1527268782837};\\\", \\\"{x:795,y:504,t:1527268782854};\\\", \\\"{x:775,y:514,t:1527268782871};\\\", \\\"{x:744,y:526,t:1527268782887};\\\", \\\"{x:728,y:537,t:1527268782903};\\\", \\\"{x:715,y:547,t:1527268782921};\\\", \\\"{x:710,y:557,t:1527268782938};\\\", \\\"{x:708,y:565,t:1527268782955};\\\", \\\"{x:707,y:578,t:1527268782970};\\\", \\\"{x:703,y:588,t:1527268782988};\\\", \\\"{x:701,y:594,t:1527268783004};\\\", \\\"{x:699,y:599,t:1527268783021};\\\", \\\"{x:700,y:599,t:1527268783160};\\\", \\\"{x:700,y:600,t:1527268783920};\\\", \\\"{x:700,y:601,t:1527268784024};\\\", \\\"{x:700,y:602,t:1527268784104};\\\", \\\"{x:700,y:603,t:1527268785464};\\\", \\\"{x:700,y:604,t:1527268785496};\\\", \\\"{x:699,y:605,t:1527268785520};\\\", \\\"{x:698,y:606,t:1527268785544};\\\", \\\"{x:697,y:606,t:1527268785559};\\\", \\\"{x:696,y:607,t:1527268785572};\\\", \\\"{x:693,y:609,t:1527268785588};\\\", \\\"{x:688,y:612,t:1527268785605};\\\", \\\"{x:684,y:615,t:1527268785623};\\\", \\\"{x:674,y:620,t:1527268785639};\\\", \\\"{x:656,y:630,t:1527268785656};\\\", \\\"{x:638,y:637,t:1527268785673};\\\", \\\"{x:613,y:645,t:1527268785689};\\\", \\\"{x:585,y:649,t:1527268785706};\\\", \\\"{x:558,y:654,t:1527268785723};\\\", \\\"{x:533,y:656,t:1527268785738};\\\", \\\"{x:519,y:659,t:1527268785756};\\\", \\\"{x:514,y:661,t:1527268785773};\\\", \\\"{x:513,y:661,t:1527268785789};\\\", \\\"{x:513,y:663,t:1527268785806};\\\", \\\"{x:513,y:664,t:1527268785823};\\\", \\\"{x:513,y:666,t:1527268785839};\\\", \\\"{x:513,y:667,t:1527268785873};\\\", \\\"{x:513,y:669,t:1527268785890};\\\", \\\"{x:513,y:670,t:1527268785906};\\\", \\\"{x:513,y:674,t:1527268785923};\\\", \\\"{x:513,y:679,t:1527268785939};\\\", \\\"{x:513,y:683,t:1527268785957};\\\", \\\"{x:513,y:687,t:1527268785974};\\\", \\\"{x:513,y:691,t:1527268785989};\\\", \\\"{x:513,y:693,t:1527268786006};\\\" ] }, { \\\"rt\\\": 20720, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 11, \\\"time_elapsed\\\": 351676, \\\"internal_node_id\\\": \\\"0.0-6.0-1.0\\\", \\\"subject\\\": \\\"YC7SX\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"mike\\\", \\\"condition\\\": \\\"115-late\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"duration+starts\\\", \\\"q\\\": 7, \\\"clicks\\\": 2, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XFull-YFull\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 1, \\\"answer\\\": [ \\\"F\\\", \\\"B\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-Z -F -B -B \\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:524,y:693,t:1527268794647};\\\", \\\"{x:541,y:693,t:1527268794660};\\\", \\\"{x:553,y:693,t:1527268794665};\\\", \\\"{x:579,y:693,t:1527268794682};\\\", \\\"{x:606,y:693,t:1527268794698};\\\", \\\"{x:636,y:693,t:1527268794714};\\\", \\\"{x:674,y:693,t:1527268794730};\\\", \\\"{x:706,y:693,t:1527268794746};\\\", \\\"{x:739,y:693,t:1527268794764};\\\", \\\"{x:771,y:693,t:1527268794779};\\\", \\\"{x:807,y:693,t:1527268794797};\\\", \\\"{x:839,y:692,t:1527268794814};\\\", \\\"{x:868,y:690,t:1527268794830};\\\", \\\"{x:910,y:686,t:1527268794847};\\\", \\\"{x:935,y:685,t:1527268794863};\\\", \\\"{x:961,y:685,t:1527268794880};\\\", \\\"{x:979,y:681,t:1527268794896};\\\", \\\"{x:995,y:675,t:1527268794914};\\\", \\\"{x:1009,y:669,t:1527268794930};\\\", \\\"{x:1022,y:665,t:1527268794947};\\\", \\\"{x:1038,y:663,t:1527268794964};\\\", \\\"{x:1056,y:659,t:1527268794980};\\\", \\\"{x:1073,y:656,t:1527268794997};\\\", \\\"{x:1091,y:653,t:1527268795014};\\\", \\\"{x:1102,y:649,t:1527268795030};\\\", \\\"{x:1117,y:641,t:1527268795047};\\\", \\\"{x:1123,y:637,t:1527268795064};\\\", \\\"{x:1133,y:630,t:1527268795081};\\\", \\\"{x:1146,y:620,t:1527268795097};\\\", \\\"{x:1164,y:610,t:1527268795114};\\\", \\\"{x:1185,y:598,t:1527268795131};\\\", \\\"{x:1208,y:585,t:1527268795147};\\\", \\\"{x:1242,y:571,t:1527268795165};\\\", \\\"{x:1288,y:552,t:1527268795181};\\\", \\\"{x:1351,y:538,t:1527268795197};\\\", \\\"{x:1416,y:524,t:1527268795214};\\\", \\\"{x:1507,y:513,t:1527268795231};\\\", \\\"{x:1562,y:513,t:1527268795247};\\\", \\\"{x:1635,y:513,t:1527268795264};\\\", \\\"{x:1712,y:521,t:1527268795281};\\\", \\\"{x:1779,y:531,t:1527268795297};\\\", \\\"{x:1833,y:539,t:1527268795314};\\\", \\\"{x:1870,y:546,t:1527268795331};\\\", \\\"{x:1897,y:552,t:1527268795347};\\\", \\\"{x:1912,y:556,t:1527268795359};\\\", \\\"{x:1917,y:576,t:1527268804640};\\\", \\\"{x:1914,y:576,t:1527268804655};\\\", \\\"{x:1903,y:576,t:1527268804672};\\\", \\\"{x:1899,y:577,t:1527268804690};\\\", \\\"{x:1896,y:577,t:1527268804705};\\\", \\\"{x:1895,y:577,t:1527268804722};\\\", \\\"{x:1894,y:577,t:1527268804739};\\\", \\\"{x:1893,y:577,t:1527268804776};\\\", \\\"{x:1892,y:577,t:1527268804789};\\\", \\\"{x:1890,y:577,t:1527268804806};\\\", \\\"{x:1887,y:578,t:1527268804822};\\\", \\\"{x:1881,y:580,t:1527268804840};\\\", \\\"{x:1875,y:582,t:1527268804856};\\\", \\\"{x:1871,y:583,t:1527268804872};\\\", \\\"{x:1865,y:585,t:1527268804890};\\\", \\\"{x:1862,y:586,t:1527268804906};\\\", \\\"{x:1857,y:587,t:1527268804922};\\\", \\\"{x:1854,y:588,t:1527268804939};\\\", \\\"{x:1850,y:588,t:1527268804956};\\\", \\\"{x:1848,y:589,t:1527268804973};\\\", \\\"{x:1845,y:590,t:1527268804989};\\\", \\\"{x:1843,y:592,t:1527268805006};\\\", \\\"{x:1837,y:594,t:1527268805022};\\\", \\\"{x:1828,y:598,t:1527268805040};\\\", \\\"{x:1818,y:601,t:1527268805056};\\\", \\\"{x:1806,y:605,t:1527268805072};\\\", \\\"{x:1791,y:608,t:1527268805088};\\\", \\\"{x:1763,y:610,t:1527268805105};\\\", \\\"{x:1732,y:610,t:1527268805122};\\\", \\\"{x:1693,y:615,t:1527268805138};\\\", \\\"{x:1662,y:617,t:1527268805155};\\\", \\\"{x:1634,y:623,t:1527268805172};\\\", \\\"{x:1613,y:629,t:1527268805189};\\\", \\\"{x:1595,y:633,t:1527268805206};\\\", \\\"{x:1579,y:638,t:1527268805223};\\\", \\\"{x:1570,y:639,t:1527268805239};\\\", \\\"{x:1563,y:640,t:1527268805256};\\\", \\\"{x:1558,y:641,t:1527268805274};\\\", \\\"{x:1554,y:642,t:1527268805289};\\\", \\\"{x:1548,y:643,t:1527268805306};\\\", \\\"{x:1537,y:644,t:1527268805323};\\\", \\\"{x:1523,y:646,t:1527268805339};\\\", \\\"{x:1509,y:647,t:1527268805356};\\\", \\\"{x:1495,y:649,t:1527268805373};\\\", \\\"{x:1481,y:652,t:1527268805390};\\\", \\\"{x:1467,y:652,t:1527268805406};\\\", \\\"{x:1450,y:653,t:1527268805423};\\\", \\\"{x:1444,y:653,t:1527268805439};\\\", \\\"{x:1425,y:653,t:1527268805456};\\\", \\\"{x:1413,y:653,t:1527268805474};\\\", \\\"{x:1400,y:652,t:1527268805489};\\\", \\\"{x:1383,y:652,t:1527268805506};\\\", \\\"{x:1373,y:651,t:1527268805523};\\\", \\\"{x:1367,y:650,t:1527268805539};\\\", \\\"{x:1363,y:650,t:1527268805556};\\\", \\\"{x:1362,y:649,t:1527268805599};\\\", \\\"{x:1361,y:648,t:1527268805607};\\\", \\\"{x:1357,y:648,t:1527268805622};\\\", \\\"{x:1351,y:648,t:1527268805639};\\\", \\\"{x:1346,y:648,t:1527268805655};\\\", \\\"{x:1345,y:647,t:1527268805673};\\\", \\\"{x:1344,y:647,t:1527268805690};\\\", \\\"{x:1344,y:651,t:1527268805857};\\\", \\\"{x:1344,y:667,t:1527268805876};\\\", \\\"{x:1344,y:682,t:1527268805890};\\\", \\\"{x:1344,y:696,t:1527268805906};\\\", \\\"{x:1344,y:706,t:1527268805924};\\\", \\\"{x:1344,y:709,t:1527268805940};\\\", \\\"{x:1342,y:711,t:1527268805956};\\\", \\\"{x:1342,y:712,t:1527268805992};\\\", \\\"{x:1341,y:712,t:1527268806120};\\\", \\\"{x:1338,y:711,t:1527268806127};\\\", \\\"{x:1329,y:708,t:1527268806140};\\\", \\\"{x:1306,y:701,t:1527268806156};\\\", \\\"{x:1258,y:686,t:1527268806174};\\\", \\\"{x:1186,y:666,t:1527268806190};\\\", \\\"{x:1036,y:623,t:1527268806207};\\\", \\\"{x:987,y:611,t:1527268806223};\\\", \\\"{x:854,y:574,t:1527268806241};\\\", \\\"{x:784,y:555,t:1527268806256};\\\", \\\"{x:734,y:540,t:1527268806273};\\\", \\\"{x:703,y:532,t:1527268806290};\\\", \\\"{x:682,y:525,t:1527268806306};\\\", \\\"{x:668,y:521,t:1527268806322};\\\", \\\"{x:659,y:520,t:1527268806340};\\\", \\\"{x:653,y:517,t:1527268806356};\\\", \\\"{x:648,y:516,t:1527268806372};\\\", \\\"{x:639,y:512,t:1527268806390};\\\", \\\"{x:626,y:505,t:1527268806407};\\\", \\\"{x:624,y:502,t:1527268806423};\\\", \\\"{x:623,y:498,t:1527268806439};\\\", \\\"{x:622,y:492,t:1527268806457};\\\", \\\"{x:622,y:485,t:1527268806474};\\\", \\\"{x:622,y:482,t:1527268806489};\\\", \\\"{x:622,y:478,t:1527268806506};\\\", \\\"{x:621,y:475,t:1527268806524};\\\", \\\"{x:617,y:471,t:1527268806540};\\\", \\\"{x:606,y:468,t:1527268806556};\\\", \\\"{x:590,y:465,t:1527268806574};\\\", \\\"{x:575,y:464,t:1527268806590};\\\", \\\"{x:556,y:464,t:1527268806606};\\\", \\\"{x:549,y:464,t:1527268806623};\\\", \\\"{x:546,y:465,t:1527268806640};\\\", \\\"{x:545,y:466,t:1527268806657};\\\", \\\"{x:545,y:467,t:1527268806674};\\\", \\\"{x:553,y:468,t:1527268806690};\\\", \\\"{x:574,y:469,t:1527268806707};\\\", \\\"{x:603,y:469,t:1527268806723};\\\", \\\"{x:638,y:470,t:1527268806739};\\\", \\\"{x:683,y:470,t:1527268806757};\\\", \\\"{x:717,y:470,t:1527268806774};\\\", \\\"{x:743,y:470,t:1527268806790};\\\", \\\"{x:760,y:470,t:1527268806807};\\\", \\\"{x:761,y:470,t:1527268806824};\\\", \\\"{x:762,y:470,t:1527268806903};\\\", \\\"{x:763,y:470,t:1527268806912};\\\", \\\"{x:764,y:470,t:1527268806927};\\\", \\\"{x:765,y:470,t:1527268806940};\\\", \\\"{x:769,y:470,t:1527268806957};\\\", \\\"{x:773,y:468,t:1527268806974};\\\", \\\"{x:779,y:466,t:1527268806991};\\\", \\\"{x:782,y:465,t:1527268807007};\\\", \\\"{x:786,y:465,t:1527268807024};\\\", \\\"{x:792,y:464,t:1527268807043};\\\", \\\"{x:797,y:461,t:1527268807057};\\\", \\\"{x:799,y:461,t:1527268807073};\\\", \\\"{x:802,y:460,t:1527268807090};\\\", \\\"{x:805,y:459,t:1527268807106};\\\", \\\"{x:806,y:459,t:1527268807123};\\\", \\\"{x:808,y:458,t:1527268807141};\\\", \\\"{x:810,y:457,t:1527268807157};\\\", \\\"{x:812,y:457,t:1527268807173};\\\", \\\"{x:816,y:456,t:1527268807190};\\\", \\\"{x:819,y:455,t:1527268807206};\\\", \\\"{x:823,y:455,t:1527268807224};\\\", \\\"{x:826,y:454,t:1527268807241};\\\", \\\"{x:827,y:454,t:1527268807256};\\\", \\\"{x:828,y:453,t:1527268807274};\\\", \\\"{x:826,y:453,t:1527268807543};\\\", \\\"{x:822,y:451,t:1527268807558};\\\", \\\"{x:787,y:451,t:1527268807574};\\\", \\\"{x:734,y:451,t:1527268807591};\\\", \\\"{x:656,y:451,t:1527268807607};\\\", \\\"{x:583,y:451,t:1527268807623};\\\", \\\"{x:514,y:451,t:1527268807640};\\\", \\\"{x:436,y:451,t:1527268807659};\\\", \\\"{x:369,y:449,t:1527268807674};\\\", \\\"{x:321,y:448,t:1527268807691};\\\", \\\"{x:291,y:448,t:1527268807708};\\\", \\\"{x:275,y:448,t:1527268807724};\\\", \\\"{x:264,y:448,t:1527268807742};\\\", \\\"{x:253,y:448,t:1527268807757};\\\", \\\"{x:241,y:451,t:1527268807773};\\\", \\\"{x:223,y:457,t:1527268807791};\\\", \\\"{x:208,y:461,t:1527268807807};\\\", \\\"{x:193,y:466,t:1527268807824};\\\", \\\"{x:183,y:470,t:1527268807841};\\\", \\\"{x:179,y:471,t:1527268807858};\\\", \\\"{x:177,y:473,t:1527268807876};\\\", \\\"{x:174,y:475,t:1527268807890};\\\", \\\"{x:172,y:478,t:1527268807908};\\\", \\\"{x:167,y:482,t:1527268807924};\\\", \\\"{x:161,y:487,t:1527268807941};\\\", \\\"{x:158,y:492,t:1527268807957};\\\", \\\"{x:155,y:495,t:1527268807974};\\\", \\\"{x:154,y:496,t:1527268807991};\\\", \\\"{x:153,y:496,t:1527268808055};\\\", \\\"{x:153,y:493,t:1527268808063};\\\", \\\"{x:154,y:490,t:1527268808079};\\\", \\\"{x:154,y:489,t:1527268808091};\\\", \\\"{x:154,y:487,t:1527268808108};\\\", \\\"{x:156,y:486,t:1527268808471};\\\", \\\"{x:159,y:487,t:1527268808478};\\\", \\\"{x:163,y:493,t:1527268808492};\\\", \\\"{x:174,y:513,t:1527268808508};\\\", \\\"{x:186,y:535,t:1527268808524};\\\", \\\"{x:202,y:558,t:1527268808542};\\\", \\\"{x:224,y:581,t:1527268808558};\\\", \\\"{x:247,y:603,t:1527268808576};\\\", \\\"{x:252,y:610,t:1527268808591};\\\", \\\"{x:256,y:615,t:1527268808608};\\\", \\\"{x:258,y:619,t:1527268808625};\\\", \\\"{x:263,y:622,t:1527268808642};\\\", \\\"{x:269,y:625,t:1527268808659};\\\", \\\"{x:276,y:627,t:1527268808675};\\\", \\\"{x:289,y:631,t:1527268808692};\\\", \\\"{x:310,y:635,t:1527268808709};\\\", \\\"{x:333,y:641,t:1527268808725};\\\", \\\"{x:357,y:647,t:1527268808742};\\\", \\\"{x:397,y:660,t:1527268808759};\\\", \\\"{x:414,y:667,t:1527268808775};\\\", \\\"{x:423,y:670,t:1527268808792};\\\", \\\"{x:426,y:672,t:1527268808809};\\\", \\\"{x:427,y:674,t:1527268808840};\\\", \\\"{x:428,y:676,t:1527268808847};\\\", \\\"{x:430,y:678,t:1527268808864};\\\", \\\"{x:432,y:679,t:1527268808876};\\\", \\\"{x:438,y:682,t:1527268808893};\\\", \\\"{x:446,y:684,t:1527268808910};\\\", \\\"{x:460,y:688,t:1527268808925};\\\", \\\"{x:475,y:690,t:1527268808941};\\\", \\\"{x:495,y:697,t:1527268808958};\\\", \\\"{x:504,y:699,t:1527268808975};\\\", \\\"{x:509,y:700,t:1527268808991};\\\", \\\"{x:511,y:700,t:1527268809009};\\\", \\\"{x:512,y:700,t:1527268809278};\\\", \\\"{x:514,y:700,t:1527268809295};\\\", \\\"{x:515,y:700,t:1527268809309};\\\", \\\"{x:516,y:699,t:1527268809325};\\\", \\\"{x:517,y:698,t:1527268809342};\\\", \\\"{x:518,y:697,t:1527268809358};\\\", \\\"{x:520,y:696,t:1527268809376};\\\", \\\"{x:521,y:696,t:1527268809391};\\\", \\\"{x:522,y:696,t:1527268809409};\\\", \\\"{x:523,y:696,t:1527268809426};\\\", \\\"{x:525,y:695,t:1527268809584};\\\", \\\"{x:526,y:695,t:1527268809593};\\\", \\\"{x:532,y:695,t:1527268809609};\\\", \\\"{x:546,y:695,t:1527268809626};\\\", \\\"{x:561,y:695,t:1527268809643};\\\", \\\"{x:576,y:695,t:1527268809658};\\\", \\\"{x:596,y:697,t:1527268809676};\\\", \\\"{x:612,y:698,t:1527268809692};\\\", \\\"{x:630,y:700,t:1527268809709};\\\", \\\"{x:651,y:705,t:1527268809726};\\\", \\\"{x:674,y:705,t:1527268809743};\\\", \\\"{x:683,y:705,t:1527268809760};\\\", \\\"{x:685,y:705,t:1527268809776};\\\", \\\"{x:686,y:705,t:1527268809793};\\\", \\\"{x:687,y:704,t:1527268809809};\\\", \\\"{x:690,y:703,t:1527268809826};\\\", \\\"{x:690,y:702,t:1527268809847};\\\", \\\"{x:690,y:701,t:1527268809879};\\\", \\\"{x:691,y:700,t:1527268809893};\\\", \\\"{x:692,y:700,t:1527268809911};\\\", \\\"{x:692,y:699,t:1527268809926};\\\", \\\"{x:692,y:698,t:1527268810024};\\\" ] }, { \\\"rt\\\": 54698, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 12, \\\"time_elapsed\\\": 407638, \\\"internal_node_id\\\": \\\"0.0-6.0-2.0\\\", \\\"subject\\\": \\\"YC7SX\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"mike\\\", \\\"condition\\\": \\\"115-late\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"duration+contained\\\", \\\"q\\\": 8, \\\"clicks\\\": 1, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XFull-YFull\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 1, \\\"answer\\\": [ \\\"E\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-B -B -B -B -E -E -E \\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:692,y:697,t:1527268817827};\\\", \\\"{x:691,y:697,t:1527268822323};\\\", \\\"{x:690,y:697,t:1527268822890};\\\", \\\"{x:688,y:697,t:1527268822914};\\\", \\\"{x:688,y:698,t:1527268822939};\\\", \\\"{x:687,y:698,t:1527268822956};\\\", \\\"{x:687,y:699,t:1527268822979};\\\", \\\"{x:688,y:699,t:1527268832537};\\\", \\\"{x:689,y:698,t:1527268832562};\\\", \\\"{x:689,y:697,t:1527268832570};\\\", \\\"{x:690,y:696,t:1527268832626};\\\", \\\"{x:691,y:695,t:1527268832650};\\\", \\\"{x:692,y:694,t:1527268832682};\\\", \\\"{x:693,y:693,t:1527268832722};\\\", \\\"{x:694,y:692,t:1527268832779};\\\", \\\"{x:695,y:692,t:1527268832796};\\\", \\\"{x:695,y:691,t:1527268832914};\\\", \\\"{x:696,y:691,t:1527268832962};\\\", \\\"{x:696,y:690,t:1527268833051};\\\", \\\"{x:697,y:690,t:1527268833064};\\\", \\\"{x:697,y:689,t:1527268833354};\\\", \\\"{x:697,y:686,t:1527268833363};\\\", \\\"{x:698,y:680,t:1527268833380};\\\", \\\"{x:698,y:675,t:1527268833396};\\\", \\\"{x:698,y:669,t:1527268833413};\\\", \\\"{x:698,y:659,t:1527268833430};\\\", \\\"{x:693,y:648,t:1527268833446};\\\", \\\"{x:682,y:634,t:1527268833464};\\\", \\\"{x:669,y:620,t:1527268833480};\\\", \\\"{x:653,y:609,t:1527268833497};\\\", \\\"{x:631,y:596,t:1527268833513};\\\", \\\"{x:597,y:575,t:1527268833531};\\\", \\\"{x:576,y:563,t:1527268833547};\\\", \\\"{x:555,y:551,t:1527268833563};\\\", \\\"{x:537,y:540,t:1527268833581};\\\", \\\"{x:516,y:529,t:1527268833597};\\\", \\\"{x:493,y:516,t:1527268833615};\\\", \\\"{x:473,y:506,t:1527268833631};\\\", \\\"{x:456,y:497,t:1527268833648};\\\", \\\"{x:444,y:490,t:1527268833665};\\\", \\\"{x:418,y:474,t:1527268833682};\\\", \\\"{x:398,y:463,t:1527268833699};\\\", \\\"{x:387,y:457,t:1527268833715};\\\", \\\"{x:381,y:452,t:1527268833732};\\\", \\\"{x:379,y:450,t:1527268833748};\\\", \\\"{x:378,y:447,t:1527268833765};\\\", \\\"{x:378,y:445,t:1527268833781};\\\", \\\"{x:378,y:444,t:1527268833797};\\\", \\\"{x:378,y:442,t:1527268833931};\\\", \\\"{x:385,y:440,t:1527268833949};\\\", \\\"{x:389,y:439,t:1527268833966};\\\", \\\"{x:391,y:438,t:1527268833981};\\\", \\\"{x:392,y:438,t:1527268833998};\\\", \\\"{x:393,y:438,t:1527268834015};\\\", \\\"{x:394,y:438,t:1527268834031};\\\", \\\"{x:394,y:437,t:1527268834048};\\\", \\\"{x:396,y:436,t:1527268834066};\\\", \\\"{x:399,y:436,t:1527268834081};\\\", \\\"{x:408,y:433,t:1527268834099};\\\", \\\"{x:412,y:432,t:1527268834115};\\\", \\\"{x:420,y:429,t:1527268834131};\\\", \\\"{x:423,y:428,t:1527268834149};\\\", \\\"{x:426,y:428,t:1527268834165};\\\", \\\"{x:426,y:427,t:1527268834182};\\\", \\\"{x:427,y:427,t:1527268834199};\\\", \\\"{x:428,y:427,t:1527268834214};\\\", \\\"{x:429,y:427,t:1527268834232};\\\", \\\"{x:430,y:426,t:1527268834297};\\\", \\\"{x:434,y:425,t:1527268836394};\\\", \\\"{x:444,y:421,t:1527268836402};\\\", \\\"{x:451,y:421,t:1527268836417};\\\", \\\"{x:468,y:419,t:1527268836434};\\\", \\\"{x:489,y:416,t:1527268836450};\\\", \\\"{x:498,y:416,t:1527268836467};\\\", \\\"{x:502,y:416,t:1527268836483};\\\", \\\"{x:506,y:415,t:1527268836501};\\\", \\\"{x:508,y:414,t:1527268836517};\\\", \\\"{x:512,y:414,t:1527268836533};\\\", \\\"{x:513,y:414,t:1527268836551};\\\", \\\"{x:515,y:414,t:1527268836568};\\\", \\\"{x:518,y:414,t:1527268836583};\\\", \\\"{x:520,y:414,t:1527268836600};\\\", \\\"{x:523,y:413,t:1527268836618};\\\", \\\"{x:525,y:412,t:1527268836634};\\\", \\\"{x:526,y:412,t:1527268836650};\\\", \\\"{x:527,y:412,t:1527268836668};\\\", \\\"{x:530,y:412,t:1527268836684};\\\", \\\"{x:532,y:411,t:1527268836701};\\\", \\\"{x:535,y:411,t:1527268836717};\\\", \\\"{x:541,y:411,t:1527268836734};\\\", \\\"{x:545,y:411,t:1527268836750};\\\", \\\"{x:550,y:411,t:1527268836767};\\\", \\\"{x:553,y:411,t:1527268836784};\\\", \\\"{x:555,y:411,t:1527268836801};\\\", \\\"{x:556,y:411,t:1527268836817};\\\", \\\"{x:558,y:411,t:1527268836835};\\\", \\\"{x:560,y:411,t:1527268836851};\\\", \\\"{x:561,y:411,t:1527268836874};\\\", \\\"{x:562,y:411,t:1527268836946};\\\", \\\"{x:564,y:411,t:1527268836962};\\\", \\\"{x:565,y:411,t:1527268836978};\\\", \\\"{x:566,y:411,t:1527268836986};\\\", \\\"{x:567,y:411,t:1527268837123};\\\", \\\"{x:568,y:411,t:1527268838587};\\\", \\\"{x:572,y:411,t:1527268838602};\\\", \\\"{x:591,y:409,t:1527268838619};\\\", \\\"{x:598,y:408,t:1527268838635};\\\", \\\"{x:602,y:407,t:1527268838651};\\\", \\\"{x:603,y:407,t:1527268839995};\\\", \\\"{x:607,y:407,t:1527268840003};\\\", \\\"{x:615,y:407,t:1527268840020};\\\", \\\"{x:629,y:407,t:1527268840036};\\\", \\\"{x:644,y:408,t:1527268840052};\\\", \\\"{x:657,y:409,t:1527268840069};\\\", \\\"{x:667,y:411,t:1527268840087};\\\", \\\"{x:672,y:413,t:1527268840102};\\\", \\\"{x:675,y:413,t:1527268840119};\\\", \\\"{x:676,y:413,t:1527268840146};\\\", \\\"{x:677,y:413,t:1527268840258};\\\", \\\"{x:681,y:413,t:1527268840270};\\\", \\\"{x:690,y:413,t:1527268840286};\\\", \\\"{x:701,y:414,t:1527268840303};\\\", \\\"{x:717,y:414,t:1527268840319};\\\", \\\"{x:730,y:414,t:1527268840336};\\\", \\\"{x:738,y:415,t:1527268840353};\\\", \\\"{x:747,y:417,t:1527268840369};\\\", \\\"{x:748,y:417,t:1527268840386};\\\", \\\"{x:750,y:418,t:1527268840403};\\\", \\\"{x:752,y:418,t:1527268840419};\\\", \\\"{x:753,y:418,t:1527268840436};\\\", \\\"{x:757,y:418,t:1527268840453};\\\", \\\"{x:761,y:418,t:1527268840469};\\\", \\\"{x:767,y:418,t:1527268840486};\\\", \\\"{x:775,y:418,t:1527268840503};\\\", \\\"{x:782,y:418,t:1527268840520};\\\", \\\"{x:787,y:418,t:1527268840537};\\\", \\\"{x:790,y:418,t:1527268840553};\\\", \\\"{x:792,y:418,t:1527268840570};\\\", \\\"{x:793,y:418,t:1527268840778};\\\", \\\"{x:796,y:421,t:1527268841083};\\\", \\\"{x:798,y:423,t:1527268841090};\\\", \\\"{x:803,y:426,t:1527268841104};\\\", \\\"{x:811,y:432,t:1527268841121};\\\", \\\"{x:826,y:437,t:1527268841138};\\\", \\\"{x:854,y:447,t:1527268841153};\\\", \\\"{x:877,y:452,t:1527268841171};\\\", \\\"{x:899,y:459,t:1527268841188};\\\", \\\"{x:925,y:466,t:1527268841204};\\\", \\\"{x:950,y:473,t:1527268841221};\\\", \\\"{x:974,y:478,t:1527268841238};\\\", \\\"{x:996,y:483,t:1527268841254};\\\", \\\"{x:1016,y:486,t:1527268841271};\\\", \\\"{x:1032,y:490,t:1527268841288};\\\", \\\"{x:1054,y:491,t:1527268841304};\\\", \\\"{x:1093,y:498,t:1527268841322};\\\", \\\"{x:1122,y:504,t:1527268841337};\\\", \\\"{x:1147,y:511,t:1527268841354};\\\", \\\"{x:1168,y:517,t:1527268841371};\\\", \\\"{x:1192,y:522,t:1527268841388};\\\", \\\"{x:1211,y:530,t:1527268841404};\\\", \\\"{x:1219,y:532,t:1527268841421};\\\", \\\"{x:1226,y:534,t:1527268841438};\\\", \\\"{x:1227,y:535,t:1527268841454};\\\", \\\"{x:1228,y:535,t:1527268841497};\\\", \\\"{x:1228,y:536,t:1527268841506};\\\", \\\"{x:1232,y:539,t:1527268841522};\\\", \\\"{x:1241,y:548,t:1527268841538};\\\", \\\"{x:1258,y:563,t:1527268841555};\\\", \\\"{x:1280,y:581,t:1527268841572};\\\", \\\"{x:1303,y:599,t:1527268841588};\\\", \\\"{x:1338,y:620,t:1527268841605};\\\", \\\"{x:1354,y:632,t:1527268841621};\\\", \\\"{x:1368,y:643,t:1527268841639};\\\", \\\"{x:1379,y:651,t:1527268841654};\\\", \\\"{x:1386,y:657,t:1527268841672};\\\", \\\"{x:1389,y:660,t:1527268841688};\\\", \\\"{x:1389,y:662,t:1527268841704};\\\", \\\"{x:1389,y:667,t:1527268841722};\\\", \\\"{x:1389,y:672,t:1527268841739};\\\", \\\"{x:1387,y:675,t:1527268841755};\\\", \\\"{x:1383,y:678,t:1527268841772};\\\", \\\"{x:1378,y:681,t:1527268841789};\\\", \\\"{x:1368,y:685,t:1527268841806};\\\", \\\"{x:1359,y:688,t:1527268841822};\\\", \\\"{x:1353,y:692,t:1527268841838};\\\", \\\"{x:1350,y:695,t:1527268841856};\\\", \\\"{x:1347,y:699,t:1527268841872};\\\", \\\"{x:1347,y:701,t:1527268841889};\\\", \\\"{x:1347,y:704,t:1527268841906};\\\", \\\"{x:1347,y:705,t:1527268841933};\\\", \\\"{x:1347,y:706,t:1527268841969};\\\", \\\"{x:1348,y:706,t:1527268841993};\\\", \\\"{x:1349,y:707,t:1527268842017};\\\", \\\"{x:1349,y:708,t:1527268842449};\\\", \\\"{x:1349,y:710,t:1527268842473};\\\", \\\"{x:1349,y:711,t:1527268842497};\\\", \\\"{x:1349,y:713,t:1527268842569};\\\", \\\"{x:1349,y:714,t:1527268842634};\\\", \\\"{x:1349,y:716,t:1527268842684};\\\", \\\"{x:1349,y:717,t:1527268842899};\\\", \\\"{x:1349,y:719,t:1527268843027};\\\", \\\"{x:1349,y:720,t:1527268843090};\\\", \\\"{x:1349,y:721,t:1527268843218};\\\", \\\"{x:1349,y:722,t:1527268843259};\\\", \\\"{x:1349,y:723,t:1527268843538};\\\", \\\"{x:1349,y:722,t:1527268847595};\\\", \\\"{x:1349,y:721,t:1527268847610};\\\", \\\"{x:1349,y:720,t:1527268847627};\\\", \\\"{x:1349,y:718,t:1527268847645};\\\", \\\"{x:1349,y:717,t:1527268847660};\\\", \\\"{x:1349,y:716,t:1527268847678};\\\", \\\"{x:1349,y:715,t:1527268847695};\\\", \\\"{x:1349,y:714,t:1527268847710};\\\", \\\"{x:1349,y:713,t:1527268847738};\\\", \\\"{x:1349,y:712,t:1527268847779};\\\", \\\"{x:1349,y:711,t:1527268847802};\\\", \\\"{x:1349,y:710,t:1527268847834};\\\", \\\"{x:1349,y:709,t:1527268847858};\\\", \\\"{x:1349,y:708,t:1527268847866};\\\", \\\"{x:1349,y:707,t:1527268847906};\\\", \\\"{x:1349,y:706,t:1527268847922};\\\", \\\"{x:1349,y:705,t:1527268847930};\\\", \\\"{x:1349,y:704,t:1527268847955};\\\", \\\"{x:1349,y:703,t:1527268847962};\\\", \\\"{x:1349,y:701,t:1527268847976};\\\", \\\"{x:1349,y:696,t:1527268847993};\\\", \\\"{x:1349,y:690,t:1527268848011};\\\", \\\"{x:1349,y:683,t:1527268848027};\\\", \\\"{x:1343,y:670,t:1527268848044};\\\", \\\"{x:1337,y:656,t:1527268848061};\\\", \\\"{x:1330,y:640,t:1527268848077};\\\", \\\"{x:1325,y:626,t:1527268848094};\\\", \\\"{x:1321,y:617,t:1527268848111};\\\", \\\"{x:1321,y:613,t:1527268848127};\\\", \\\"{x:1320,y:608,t:1527268848144};\\\", \\\"{x:1318,y:604,t:1527268848161};\\\", \\\"{x:1318,y:600,t:1527268848177};\\\", \\\"{x:1317,y:592,t:1527268848194};\\\", \\\"{x:1317,y:587,t:1527268848211};\\\", \\\"{x:1317,y:582,t:1527268848227};\\\", \\\"{x:1317,y:578,t:1527268848245};\\\", \\\"{x:1317,y:573,t:1527268848261};\\\", \\\"{x:1317,y:569,t:1527268848277};\\\", \\\"{x:1317,y:567,t:1527268848294};\\\", \\\"{x:1317,y:565,t:1527268848311};\\\", \\\"{x:1317,y:563,t:1527268848328};\\\", \\\"{x:1317,y:562,t:1527268848635};\\\", \\\"{x:1317,y:560,t:1527268848667};\\\", \\\"{x:1317,y:559,t:1527268848698};\\\", \\\"{x:1317,y:558,t:1527268848730};\\\", \\\"{x:1317,y:557,t:1527268849297};\\\", \\\"{x:1317,y:556,t:1527268849311};\\\", \\\"{x:1315,y:552,t:1527268849327};\\\", \\\"{x:1313,y:549,t:1527268849345};\\\", \\\"{x:1310,y:543,t:1527268849361};\\\", \\\"{x:1309,y:541,t:1527268849378};\\\", \\\"{x:1309,y:540,t:1527268849395};\\\", \\\"{x:1309,y:538,t:1527268849411};\\\", \\\"{x:1307,y:536,t:1527268849427};\\\", \\\"{x:1307,y:533,t:1527268849445};\\\", \\\"{x:1306,y:532,t:1527268849461};\\\", \\\"{x:1305,y:529,t:1527268849477};\\\", \\\"{x:1305,y:527,t:1527268849494};\\\", \\\"{x:1303,y:525,t:1527268849511};\\\", \\\"{x:1303,y:524,t:1527268849528};\\\", \\\"{x:1302,y:523,t:1527268849544};\\\", \\\"{x:1296,y:518,t:1527268849561};\\\", \\\"{x:1292,y:515,t:1527268849579};\\\", \\\"{x:1288,y:512,t:1527268849595};\\\", \\\"{x:1284,y:509,t:1527268849612};\\\", \\\"{x:1279,y:504,t:1527268849629};\\\", \\\"{x:1274,y:502,t:1527268849645};\\\", \\\"{x:1270,y:499,t:1527268849661};\\\", \\\"{x:1265,y:497,t:1527268849679};\\\", \\\"{x:1262,y:495,t:1527268849695};\\\", \\\"{x:1259,y:493,t:1527268849711};\\\", \\\"{x:1257,y:493,t:1527268849729};\\\", \\\"{x:1256,y:492,t:1527268849745};\\\", \\\"{x:1256,y:493,t:1527268849978};\\\", \\\"{x:1257,y:494,t:1527268850369};\\\", \\\"{x:1258,y:494,t:1527268850393};\\\", \\\"{x:1260,y:495,t:1527268850417};\\\", \\\"{x:1261,y:496,t:1527268850433};\\\", \\\"{x:1263,y:497,t:1527268850457};\\\", \\\"{x:1264,y:497,t:1527268850482};\\\", \\\"{x:1265,y:497,t:1527268850683};\\\", \\\"{x:1266,y:499,t:1527268850930};\\\", \\\"{x:1269,y:501,t:1527268850945};\\\", \\\"{x:1272,y:503,t:1527268850962};\\\", \\\"{x:1274,y:504,t:1527268850980};\\\", \\\"{x:1277,y:506,t:1527268850996};\\\", \\\"{x:1279,y:507,t:1527268851012};\\\", \\\"{x:1280,y:507,t:1527268851030};\\\", \\\"{x:1280,y:509,t:1527268855826};\\\", \\\"{x:1273,y:510,t:1527268855835};\\\", \\\"{x:1246,y:510,t:1527268855850};\\\", \\\"{x:1208,y:510,t:1527268855867};\\\", \\\"{x:1144,y:510,t:1527268855884};\\\", \\\"{x:1068,y:506,t:1527268855901};\\\", \\\"{x:990,y:497,t:1527268855918};\\\", \\\"{x:934,y:487,t:1527268855936};\\\", \\\"{x:889,y:480,t:1527268855950};\\\", \\\"{x:865,y:477,t:1527268855967};\\\", \\\"{x:850,y:475,t:1527268855983};\\\", \\\"{x:841,y:474,t:1527268856000};\\\", \\\"{x:834,y:474,t:1527268856017};\\\", \\\"{x:829,y:471,t:1527268856033};\\\", \\\"{x:814,y:470,t:1527268856049};\\\", \\\"{x:797,y:467,t:1527268856066};\\\", \\\"{x:779,y:465,t:1527268856083};\\\", \\\"{x:758,y:462,t:1527268856101};\\\", \\\"{x:741,y:460,t:1527268856116};\\\", \\\"{x:726,y:457,t:1527268856133};\\\", \\\"{x:710,y:455,t:1527268856150};\\\", \\\"{x:702,y:454,t:1527268856167};\\\", \\\"{x:698,y:454,t:1527268856182};\\\", \\\"{x:695,y:452,t:1527268856200};\\\", \\\"{x:693,y:452,t:1527268856218};\\\", \\\"{x:691,y:452,t:1527268856233};\\\", \\\"{x:681,y:452,t:1527268856250};\\\", \\\"{x:671,y:452,t:1527268856268};\\\", \\\"{x:657,y:451,t:1527268856283};\\\", \\\"{x:646,y:451,t:1527268856300};\\\", \\\"{x:638,y:450,t:1527268856318};\\\", \\\"{x:635,y:450,t:1527268856333};\\\", \\\"{x:634,y:448,t:1527268856350};\\\", \\\"{x:633,y:448,t:1527268856367};\\\", \\\"{x:632,y:448,t:1527268856514};\\\", \\\"{x:631,y:448,t:1527268856530};\\\", \\\"{x:630,y:448,t:1527268856537};\\\", \\\"{x:627,y:448,t:1527268856938};\\\", \\\"{x:624,y:448,t:1527268856950};\\\", \\\"{x:621,y:456,t:1527268856967};\\\", \\\"{x:619,y:463,t:1527268856986};\\\", \\\"{x:618,y:468,t:1527268857001};\\\", \\\"{x:616,y:475,t:1527268857018};\\\", \\\"{x:616,y:478,t:1527268857034};\\\", \\\"{x:613,y:484,t:1527268857051};\\\", \\\"{x:610,y:491,t:1527268857067};\\\", \\\"{x:607,y:499,t:1527268857084};\\\", \\\"{x:604,y:510,t:1527268857101};\\\", \\\"{x:601,y:519,t:1527268857117};\\\", \\\"{x:599,y:530,t:1527268857134};\\\", \\\"{x:596,y:545,t:1527268857151};\\\", \\\"{x:594,y:559,t:1527268857167};\\\", \\\"{x:593,y:570,t:1527268857183};\\\", \\\"{x:589,y:586,t:1527268857201};\\\", \\\"{x:588,y:590,t:1527268857216};\\\", \\\"{x:586,y:599,t:1527268857234};\\\", \\\"{x:586,y:603,t:1527268857250};\\\", \\\"{x:586,y:607,t:1527268857267};\\\", \\\"{x:586,y:609,t:1527268857284};\\\", \\\"{x:586,y:612,t:1527268857301};\\\", \\\"{x:586,y:613,t:1527268857329};\\\", \\\"{x:586,y:614,t:1527268857337};\\\", \\\"{x:586,y:615,t:1527268857353};\\\", \\\"{x:586,y:617,t:1527268857369};\\\", \\\"{x:588,y:619,t:1527268857384};\\\", \\\"{x:592,y:621,t:1527268857400};\\\", \\\"{x:598,y:625,t:1527268857417};\\\", \\\"{x:616,y:638,t:1527268857434};\\\", \\\"{x:639,y:650,t:1527268857451};\\\", \\\"{x:665,y:663,t:1527268857467};\\\", \\\"{x:699,y:678,t:1527268857484};\\\", \\\"{x:732,y:692,t:1527268857500};\\\", \\\"{x:765,y:705,t:1527268857517};\\\", \\\"{x:818,y:719,t:1527268857534};\\\", \\\"{x:840,y:722,t:1527268857551};\\\", \\\"{x:864,y:725,t:1527268857568};\\\", \\\"{x:879,y:725,t:1527268857584};\\\", \\\"{x:894,y:728,t:1527268857600};\\\", \\\"{x:907,y:729,t:1527268857617};\\\", \\\"{x:918,y:733,t:1527268857633};\\\", \\\"{x:930,y:737,t:1527268857650};\\\", \\\"{x:941,y:740,t:1527268857667};\\\", \\\"{x:958,y:745,t:1527268857685};\\\", \\\"{x:978,y:749,t:1527268857700};\\\", \\\"{x:992,y:753,t:1527268857718};\\\", \\\"{x:1004,y:755,t:1527268857734};\\\", \\\"{x:1020,y:759,t:1527268857751};\\\", \\\"{x:1036,y:762,t:1527268857767};\\\", \\\"{x:1046,y:762,t:1527268857785};\\\", \\\"{x:1051,y:762,t:1527268857801};\\\", \\\"{x:1055,y:762,t:1527268857817};\\\", \\\"{x:1063,y:762,t:1527268857834};\\\", \\\"{x:1075,y:764,t:1527268857851};\\\", \\\"{x:1093,y:766,t:1527268857867};\\\", \\\"{x:1110,y:770,t:1527268857884};\\\", \\\"{x:1133,y:772,t:1527268857900};\\\", \\\"{x:1154,y:780,t:1527268857917};\\\", \\\"{x:1174,y:785,t:1527268857934};\\\", \\\"{x:1188,y:790,t:1527268857950};\\\", \\\"{x:1201,y:793,t:1527268857967};\\\", \\\"{x:1210,y:795,t:1527268857983};\\\", \\\"{x:1215,y:796,t:1527268858000};\\\", \\\"{x:1220,y:796,t:1527268858018};\\\", \\\"{x:1221,y:796,t:1527268858033};\\\", \\\"{x:1221,y:797,t:1527268858066};\\\", \\\"{x:1221,y:796,t:1527268858274};\\\", \\\"{x:1221,y:795,t:1527268858298};\\\", \\\"{x:1221,y:794,t:1527268858305};\\\", \\\"{x:1221,y:793,t:1527268858362};\\\", \\\"{x:1221,y:792,t:1527268858386};\\\", \\\"{x:1221,y:791,t:1527268858410};\\\", \\\"{x:1221,y:790,t:1527268858546};\\\", \\\"{x:1221,y:789,t:1527268858554};\\\", \\\"{x:1222,y:789,t:1527268858586};\\\", \\\"{x:1222,y:788,t:1527268858601};\\\", \\\"{x:1223,y:788,t:1527268858634};\\\", \\\"{x:1224,y:787,t:1527268858651};\\\", \\\"{x:1227,y:787,t:1527268858667};\\\", \\\"{x:1228,y:786,t:1527268858683};\\\", \\\"{x:1230,y:786,t:1527268858700};\\\", \\\"{x:1234,y:786,t:1527268858717};\\\", \\\"{x:1236,y:786,t:1527268858733};\\\", \\\"{x:1240,y:786,t:1527268858751};\\\", \\\"{x:1243,y:784,t:1527268858766};\\\", \\\"{x:1248,y:783,t:1527268858783};\\\", \\\"{x:1254,y:783,t:1527268858801};\\\", \\\"{x:1263,y:782,t:1527268858817};\\\", \\\"{x:1270,y:780,t:1527268858833};\\\", \\\"{x:1274,y:780,t:1527268858850};\\\", \\\"{x:1276,y:780,t:1527268858867};\\\", \\\"{x:1278,y:779,t:1527268858938};\\\", \\\"{x:1280,y:778,t:1527268858963};\\\", \\\"{x:1282,y:777,t:1527268858986};\\\", \\\"{x:1284,y:777,t:1527268860131};\\\", \\\"{x:1288,y:777,t:1527268860138};\\\", \\\"{x:1293,y:777,t:1527268860150};\\\", \\\"{x:1302,y:777,t:1527268860167};\\\", \\\"{x:1314,y:777,t:1527268860183};\\\", \\\"{x:1322,y:777,t:1527268860199};\\\", \\\"{x:1327,y:777,t:1527268860217};\\\", \\\"{x:1329,y:777,t:1527268860232};\\\", \\\"{x:1331,y:777,t:1527268860250};\\\", \\\"{x:1333,y:778,t:1527268860266};\\\", \\\"{x:1334,y:778,t:1527268860282};\\\", \\\"{x:1337,y:778,t:1527268860299};\\\", \\\"{x:1338,y:778,t:1527268860316};\\\", \\\"{x:1341,y:779,t:1527268860332};\\\", \\\"{x:1344,y:779,t:1527268860349};\\\", \\\"{x:1348,y:780,t:1527268860365};\\\", \\\"{x:1352,y:781,t:1527268860382};\\\", \\\"{x:1359,y:782,t:1527268860399};\\\", \\\"{x:1362,y:782,t:1527268860415};\\\", \\\"{x:1366,y:783,t:1527268860432};\\\", \\\"{x:1365,y:784,t:1527268862578};\\\", \\\"{x:1358,y:784,t:1527268862585};\\\", \\\"{x:1352,y:784,t:1527268862597};\\\", \\\"{x:1325,y:785,t:1527268862614};\\\", \\\"{x:1274,y:781,t:1527268862631};\\\", \\\"{x:1188,y:768,t:1527268862648};\\\", \\\"{x:1092,y:750,t:1527268862665};\\\", \\\"{x:985,y:735,t:1527268862682};\\\", \\\"{x:933,y:724,t:1527268862699};\\\", \\\"{x:906,y:714,t:1527268862715};\\\", \\\"{x:892,y:707,t:1527268862732};\\\", \\\"{x:888,y:705,t:1527268862747};\\\", \\\"{x:882,y:703,t:1527268862764};\\\", \\\"{x:874,y:699,t:1527268862782};\\\", \\\"{x:871,y:699,t:1527268862798};\\\", \\\"{x:868,y:699,t:1527268862826};\\\", \\\"{x:864,y:699,t:1527268862834};\\\", \\\"{x:860,y:699,t:1527268862848};\\\", \\\"{x:852,y:699,t:1527268862864};\\\", \\\"{x:840,y:699,t:1527268862882};\\\", \\\"{x:830,y:699,t:1527268862897};\\\", \\\"{x:816,y:699,t:1527268862914};\\\", \\\"{x:799,y:699,t:1527268862931};\\\", \\\"{x:778,y:699,t:1527268862947};\\\", \\\"{x:756,y:699,t:1527268862965};\\\", \\\"{x:737,y:701,t:1527268862982};\\\", \\\"{x:719,y:701,t:1527268862997};\\\", \\\"{x:707,y:701,t:1527268863015};\\\", \\\"{x:702,y:701,t:1527268863031};\\\", \\\"{x:699,y:701,t:1527268863048};\\\", \\\"{x:698,y:701,t:1527268863065};\\\", \\\"{x:697,y:701,t:1527268863082};\\\", \\\"{x:696,y:701,t:1527268863098};\\\", \\\"{x:695,y:701,t:1527268863130};\\\", \\\"{x:694,y:701,t:1527268863154};\\\", \\\"{x:692,y:701,t:1527268863243};\\\", \\\"{x:690,y:700,t:1527268864259};\\\", \\\"{x:685,y:698,t:1527268864265};\\\", \\\"{x:681,y:698,t:1527268864281};\\\", \\\"{x:667,y:696,t:1527268864298};\\\", \\\"{x:661,y:696,t:1527268864314};\\\", \\\"{x:654,y:696,t:1527268864331};\\\", \\\"{x:647,y:696,t:1527268864348};\\\", \\\"{x:640,y:697,t:1527268864364};\\\", \\\"{x:636,y:699,t:1527268864380};\\\", \\\"{x:634,y:700,t:1527268864398};\\\", \\\"{x:633,y:701,t:1527268864413};\\\", \\\"{x:632,y:702,t:1527268864431};\\\", \\\"{x:630,y:702,t:1527268864446};\\\", \\\"{x:627,y:702,t:1527268864464};\\\", \\\"{x:622,y:702,t:1527268864480};\\\", \\\"{x:617,y:702,t:1527268864497};\\\", \\\"{x:603,y:698,t:1527268864513};\\\", \\\"{x:583,y:689,t:1527268864531};\\\", \\\"{x:563,y:684,t:1527268864548};\\\", \\\"{x:539,y:677,t:1527268864563};\\\", \\\"{x:516,y:670,t:1527268864580};\\\", \\\"{x:506,y:667,t:1527268864590};\\\", \\\"{x:497,y:665,t:1527268864606};\\\", \\\"{x:496,y:665,t:1527268864623};\\\", \\\"{x:496,y:666,t:1527268864874};\\\", \\\"{x:496,y:670,t:1527268864891};\\\", \\\"{x:497,y:674,t:1527268864907};\\\", \\\"{x:497,y:675,t:1527268864924};\\\", \\\"{x:498,y:677,t:1527268864940};\\\", \\\"{x:499,y:678,t:1527268864957};\\\", \\\"{x:500,y:679,t:1527268865019};\\\", \\\"{x:500,y:680,t:1527268865140};\\\", \\\"{x:500,y:680,t:1527268865225};\\\", \\\"{x:502,y:680,t:1527268865506};\\\" ] }, { \\\"rt\\\": 22480, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 13, \\\"time_elapsed\\\": 431395, \\\"internal_node_id\\\": \\\"0.0-6.0-3.0\\\", \\\"subject\\\": \\\"YC7SX\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"mike\\\", \\\"condition\\\": \\\"115-late\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"starttime+before+endtime+during\\\", \\\"q\\\": 9, \\\"clicks\\\": 1, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XFull-YFull\\\", \\\"correct\\\": 1, \\\"orth_correct\\\": 1, \\\"answer\\\": [ \\\"I\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-J -J -I -B -B -I \\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:503,y:680,t:1527268869954};\\\", \\\"{x:503,y:679,t:1527268869986};\\\", \\\"{x:504,y:679,t:1527268870042};\\\", \\\"{x:505,y:679,t:1527268870055};\\\", \\\"{x:506,y:678,t:1527268870082};\\\", \\\"{x:507,y:678,t:1527268870122};\\\", \\\"{x:508,y:677,t:1527268870146};\\\", \\\"{x:509,y:676,t:1527268870154};\\\", \\\"{x:511,y:675,t:1527268870177};\\\", \\\"{x:513,y:674,t:1527268870194};\\\", \\\"{x:515,y:673,t:1527268870206};\\\", \\\"{x:517,y:670,t:1527268870222};\\\", \\\"{x:522,y:666,t:1527268870240};\\\", \\\"{x:530,y:657,t:1527268870256};\\\", \\\"{x:544,y:637,t:1527268870271};\\\", \\\"{x:563,y:609,t:1527268870294};\\\", \\\"{x:570,y:585,t:1527268870311};\\\", \\\"{x:574,y:562,t:1527268870328};\\\", \\\"{x:578,y:544,t:1527268870345};\\\", \\\"{x:579,y:514,t:1527268870361};\\\", \\\"{x:579,y:501,t:1527268870377};\\\", \\\"{x:579,y:490,t:1527268870394};\\\", \\\"{x:579,y:483,t:1527268870411};\\\", \\\"{x:578,y:476,t:1527268870428};\\\", \\\"{x:577,y:470,t:1527268870444};\\\", \\\"{x:577,y:466,t:1527268870461};\\\", \\\"{x:574,y:462,t:1527268870479};\\\", \\\"{x:571,y:460,t:1527268870494};\\\", \\\"{x:565,y:456,t:1527268870511};\\\", \\\"{x:560,y:453,t:1527268870528};\\\", \\\"{x:550,y:446,t:1527268870545};\\\", \\\"{x:533,y:434,t:1527268870561};\\\", \\\"{x:519,y:427,t:1527268870579};\\\", \\\"{x:502,y:416,t:1527268870594};\\\", \\\"{x:479,y:406,t:1527268870612};\\\", \\\"{x:463,y:399,t:1527268870628};\\\", \\\"{x:452,y:396,t:1527268870645};\\\", \\\"{x:443,y:392,t:1527268870661};\\\", \\\"{x:439,y:390,t:1527268870678};\\\", \\\"{x:439,y:389,t:1527268870729};\\\", \\\"{x:439,y:388,t:1527268870745};\\\", \\\"{x:440,y:388,t:1527268870762};\\\", \\\"{x:442,y:387,t:1527268870778};\\\", \\\"{x:443,y:387,t:1527268870794};\\\", \\\"{x:446,y:386,t:1527268870811};\\\", \\\"{x:446,y:385,t:1527268870829};\\\", \\\"{x:450,y:385,t:1527268870844};\\\", \\\"{x:452,y:385,t:1527268870861};\\\", \\\"{x:453,y:385,t:1527268870878};\\\", \\\"{x:455,y:385,t:1527268870894};\\\", \\\"{x:457,y:385,t:1527268870911};\\\", \\\"{x:458,y:385,t:1527268870929};\\\", \\\"{x:462,y:386,t:1527268870944};\\\", \\\"{x:469,y:387,t:1527268870962};\\\", \\\"{x:474,y:388,t:1527268870979};\\\", \\\"{x:478,y:389,t:1527268870995};\\\", \\\"{x:480,y:390,t:1527268871012};\\\", \\\"{x:484,y:390,t:1527268871029};\\\", \\\"{x:485,y:390,t:1527268871045};\\\", \\\"{x:486,y:390,t:1527268871062};\\\", \\\"{x:486,y:391,t:1527268871882};\\\", \\\"{x:486,y:392,t:1527268871986};\\\", \\\"{x:485,y:393,t:1527268873002};\\\", \\\"{x:484,y:393,t:1527268873025};\\\", \\\"{x:483,y:395,t:1527268873962};\\\", \\\"{x:491,y:401,t:1527268873969};\\\", \\\"{x:512,y:410,t:1527268873980};\\\", \\\"{x:583,y:439,t:1527268873998};\\\", \\\"{x:675,y:470,t:1527268874015};\\\", \\\"{x:775,y:496,t:1527268874031};\\\", \\\"{x:890,y:542,t:1527268874049};\\\", \\\"{x:989,y:585,t:1527268874063};\\\", \\\"{x:1082,y:627,t:1527268874080};\\\", \\\"{x:1101,y:640,t:1527268874097};\\\", \\\"{x:1107,y:648,t:1527268874114};\\\", \\\"{x:1107,y:652,t:1527268874130};\\\", \\\"{x:1102,y:660,t:1527268874148};\\\", \\\"{x:1087,y:668,t:1527268874164};\\\", \\\"{x:1071,y:675,t:1527268874180};\\\", \\\"{x:1060,y:683,t:1527268874197};\\\", \\\"{x:1052,y:692,t:1527268874214};\\\", \\\"{x:1049,y:700,t:1527268874231};\\\", \\\"{x:1048,y:705,t:1527268874247};\\\", \\\"{x:1047,y:711,t:1527268874263};\\\", \\\"{x:1051,y:725,t:1527268874281};\\\", \\\"{x:1061,y:739,t:1527268874296};\\\", \\\"{x:1074,y:751,t:1527268874313};\\\", \\\"{x:1076,y:754,t:1527268874330};\\\", \\\"{x:1095,y:764,t:1527268874346};\\\", \\\"{x:1098,y:770,t:1527268874363};\\\", \\\"{x:1107,y:774,t:1527268874380};\\\", \\\"{x:1111,y:778,t:1527268874396};\\\", \\\"{x:1114,y:778,t:1527268874562};\\\", \\\"{x:1115,y:777,t:1527268874569};\\\", \\\"{x:1117,y:775,t:1527268874586};\\\", \\\"{x:1118,y:775,t:1527268874597};\\\", \\\"{x:1129,y:773,t:1527268874613};\\\", \\\"{x:1139,y:771,t:1527268874630};\\\", \\\"{x:1153,y:770,t:1527268874647};\\\", \\\"{x:1168,y:770,t:1527268874663};\\\", \\\"{x:1180,y:770,t:1527268874680};\\\", \\\"{x:1191,y:770,t:1527268874697};\\\", \\\"{x:1200,y:770,t:1527268874714};\\\", \\\"{x:1201,y:770,t:1527268874730};\\\", \\\"{x:1203,y:770,t:1527268874746};\\\", \\\"{x:1204,y:770,t:1527268875026};\\\", \\\"{x:1206,y:770,t:1527268875042};\\\", \\\"{x:1208,y:770,t:1527268875050};\\\", \\\"{x:1210,y:771,t:1527268875080};\\\", \\\"{x:1211,y:772,t:1527268875097};\\\", \\\"{x:1211,y:773,t:1527268875129};\\\", \\\"{x:1212,y:773,t:1527268875145};\\\", \\\"{x:1213,y:774,t:1527268875282};\\\", \\\"{x:1214,y:774,t:1527268875295};\\\", \\\"{x:1215,y:775,t:1527268875314};\\\", \\\"{x:1216,y:775,t:1527268875337};\\\", \\\"{x:1217,y:775,t:1527268881334};\\\", \\\"{x:1217,y:774,t:1527268881341};\\\", \\\"{x:1217,y:773,t:1527268881357};\\\", \\\"{x:1218,y:771,t:1527268881372};\\\", \\\"{x:1218,y:770,t:1527268881388};\\\", \\\"{x:1218,y:767,t:1527268881404};\\\", \\\"{x:1218,y:763,t:1527268881421};\\\", \\\"{x:1218,y:759,t:1527268881437};\\\", \\\"{x:1218,y:756,t:1527268881454};\\\", \\\"{x:1218,y:750,t:1527268881471};\\\", \\\"{x:1218,y:746,t:1527268881487};\\\", \\\"{x:1217,y:740,t:1527268881504};\\\", \\\"{x:1215,y:737,t:1527268881521};\\\", \\\"{x:1213,y:734,t:1527268881537};\\\", \\\"{x:1212,y:733,t:1527268881557};\\\", \\\"{x:1211,y:732,t:1527268881574};\\\", \\\"{x:1210,y:732,t:1527268881587};\\\", \\\"{x:1210,y:731,t:1527268881604};\\\", \\\"{x:1208,y:729,t:1527268881620};\\\", \\\"{x:1204,y:728,t:1527268881637};\\\", \\\"{x:1200,y:727,t:1527268881653};\\\", \\\"{x:1196,y:725,t:1527268881670};\\\", \\\"{x:1194,y:724,t:1527268881687};\\\", \\\"{x:1192,y:723,t:1527268881704};\\\", \\\"{x:1191,y:722,t:1527268881720};\\\", \\\"{x:1189,y:721,t:1527268881737};\\\", \\\"{x:1187,y:721,t:1527268881757};\\\", \\\"{x:1186,y:720,t:1527268881773};\\\", \\\"{x:1184,y:718,t:1527268881789};\\\", \\\"{x:1183,y:718,t:1527268881805};\\\", \\\"{x:1182,y:717,t:1527268881829};\\\", \\\"{x:1181,y:717,t:1527268881877};\\\", \\\"{x:1181,y:716,t:1527268881894};\\\", \\\"{x:1181,y:715,t:1527268881919};\\\", \\\"{x:1180,y:714,t:1527268881949};\\\", \\\"{x:1181,y:714,t:1527268882413};\\\", \\\"{x:1182,y:714,t:1527268882420};\\\", \\\"{x:1183,y:714,t:1527268882436};\\\", \\\"{x:1184,y:714,t:1527268882452};\\\", \\\"{x:1185,y:714,t:1527268882468};\\\", \\\"{x:1186,y:714,t:1527268882487};\\\", \\\"{x:1188,y:714,t:1527268882502};\\\", \\\"{x:1191,y:714,t:1527268882519};\\\", \\\"{x:1196,y:714,t:1527268882535};\\\", \\\"{x:1201,y:714,t:1527268882552};\\\", \\\"{x:1206,y:714,t:1527268882569};\\\", \\\"{x:1209,y:714,t:1527268882585};\\\", \\\"{x:1212,y:714,t:1527268882602};\\\", \\\"{x:1213,y:714,t:1527268882618};\\\", \\\"{x:1214,y:714,t:1527268882637};\\\", \\\"{x:1215,y:714,t:1527268882652};\\\", \\\"{x:1216,y:714,t:1527268882668};\\\", \\\"{x:1222,y:714,t:1527268882685};\\\", \\\"{x:1225,y:714,t:1527268882701};\\\", \\\"{x:1229,y:714,t:1527268882718};\\\", \\\"{x:1230,y:714,t:1527268882742};\\\", \\\"{x:1232,y:714,t:1527268882854};\\\", \\\"{x:1233,y:714,t:1527268882868};\\\", \\\"{x:1234,y:714,t:1527268882885};\\\", \\\"{x:1235,y:714,t:1527268882901};\\\", \\\"{x:1236,y:714,t:1527268882982};\\\", \\\"{x:1238,y:714,t:1527268882997};\\\", \\\"{x:1239,y:714,t:1527268883006};\\\", \\\"{x:1241,y:714,t:1527268883021};\\\", \\\"{x:1243,y:714,t:1527268883034};\\\", \\\"{x:1249,y:711,t:1527268883051};\\\", \\\"{x:1254,y:710,t:1527268883069};\\\", \\\"{x:1263,y:707,t:1527268883084};\\\", \\\"{x:1276,y:705,t:1527268883101};\\\", \\\"{x:1290,y:703,t:1527268883117};\\\", \\\"{x:1302,y:702,t:1527268883134};\\\", \\\"{x:1308,y:702,t:1527268883151};\\\", \\\"{x:1310,y:702,t:1527268883168};\\\", \\\"{x:1311,y:702,t:1527268883230};\\\", \\\"{x:1312,y:702,t:1527268883405};\\\", \\\"{x:1315,y:702,t:1527268883417};\\\", \\\"{x:1325,y:703,t:1527268883434};\\\", \\\"{x:1336,y:703,t:1527268883450};\\\", \\\"{x:1347,y:703,t:1527268883467};\\\", \\\"{x:1360,y:704,t:1527268883484};\\\", \\\"{x:1367,y:704,t:1527268883500};\\\", \\\"{x:1369,y:705,t:1527268883517};\\\", \\\"{x:1370,y:705,t:1527268883638};\\\", \\\"{x:1372,y:705,t:1527268883650};\\\", \\\"{x:1378,y:706,t:1527268883666};\\\", \\\"{x:1382,y:707,t:1527268883682};\\\", \\\"{x:1384,y:707,t:1527268883700};\\\", \\\"{x:1384,y:708,t:1527268884549};\\\", \\\"{x:1381,y:708,t:1527268884565};\\\", \\\"{x:1379,y:708,t:1527268884581};\\\", \\\"{x:1379,y:709,t:1527268884598};\\\", \\\"{x:1378,y:710,t:1527268884638};\\\", \\\"{x:1377,y:710,t:1527268884694};\\\", \\\"{x:1376,y:710,t:1527268884701};\\\", \\\"{x:1375,y:710,t:1527268884714};\\\", \\\"{x:1369,y:710,t:1527268884731};\\\", \\\"{x:1363,y:710,t:1527268884748};\\\", \\\"{x:1346,y:709,t:1527268884765};\\\", \\\"{x:1328,y:709,t:1527268884781};\\\", \\\"{x:1320,y:709,t:1527268884797};\\\", \\\"{x:1314,y:709,t:1527268884814};\\\", \\\"{x:1308,y:709,t:1527268884831};\\\", \\\"{x:1303,y:709,t:1527268884847};\\\", \\\"{x:1299,y:709,t:1527268884864};\\\", \\\"{x:1291,y:708,t:1527268884881};\\\", \\\"{x:1284,y:706,t:1527268884897};\\\", \\\"{x:1272,y:705,t:1527268884914};\\\", \\\"{x:1265,y:705,t:1527268884931};\\\", \\\"{x:1260,y:705,t:1527268884947};\\\", \\\"{x:1257,y:705,t:1527268884964};\\\", \\\"{x:1254,y:705,t:1527268884981};\\\", \\\"{x:1251,y:705,t:1527268884997};\\\", \\\"{x:1247,y:705,t:1527268885014};\\\", \\\"{x:1239,y:705,t:1527268885030};\\\", \\\"{x:1230,y:705,t:1527268885047};\\\", \\\"{x:1216,y:704,t:1527268885064};\\\", \\\"{x:1201,y:703,t:1527268885080};\\\", \\\"{x:1191,y:701,t:1527268885097};\\\", \\\"{x:1186,y:700,t:1527268885114};\\\", \\\"{x:1180,y:700,t:1527268885130};\\\", \\\"{x:1177,y:700,t:1527268885147};\\\", \\\"{x:1176,y:700,t:1527268885163};\\\", \\\"{x:1175,y:700,t:1527268885180};\\\", \\\"{x:1173,y:700,t:1527268885197};\\\", \\\"{x:1172,y:701,t:1527268885533};\\\", \\\"{x:1172,y:703,t:1527268885590};\\\", \\\"{x:1173,y:705,t:1527268885597};\\\", \\\"{x:1173,y:706,t:1527268885613};\\\", \\\"{x:1174,y:707,t:1527268885629};\\\", \\\"{x:1174,y:709,t:1527268885646};\\\", \\\"{x:1174,y:710,t:1527268885664};\\\", \\\"{x:1174,y:711,t:1527268885694};\\\", \\\"{x:1174,y:712,t:1527268885701};\\\", \\\"{x:1174,y:713,t:1527268885712};\\\", \\\"{x:1176,y:714,t:1527268885729};\\\", \\\"{x:1170,y:714,t:1527268885861};\\\", \\\"{x:1145,y:714,t:1527268885879};\\\", \\\"{x:1101,y:707,t:1527268885896};\\\", \\\"{x:1027,y:690,t:1527268885912};\\\", \\\"{x:921,y:658,t:1527268885929};\\\", \\\"{x:830,y:633,t:1527268885945};\\\", \\\"{x:760,y:611,t:1527268885962};\\\", \\\"{x:715,y:598,t:1527268885979};\\\", \\\"{x:698,y:591,t:1527268885995};\\\", \\\"{x:691,y:587,t:1527268886012};\\\", \\\"{x:691,y:586,t:1527268886028};\\\", \\\"{x:691,y:582,t:1527268886044};\\\", \\\"{x:690,y:579,t:1527268886062};\\\", \\\"{x:686,y:571,t:1527268886079};\\\", \\\"{x:671,y:558,t:1527268886095};\\\", \\\"{x:646,y:545,t:1527268886111};\\\", \\\"{x:609,y:525,t:1527268886125};\\\", \\\"{x:558,y:507,t:1527268886142};\\\", \\\"{x:511,y:487,t:1527268886157};\\\", \\\"{x:470,y:471,t:1527268886178};\\\", \\\"{x:440,y:462,t:1527268886195};\\\", \\\"{x:419,y:456,t:1527268886211};\\\", \\\"{x:405,y:452,t:1527268886228};\\\", \\\"{x:394,y:450,t:1527268886245};\\\", \\\"{x:389,y:450,t:1527268886260};\\\", \\\"{x:384,y:449,t:1527268886277};\\\", \\\"{x:381,y:449,t:1527268886294};\\\", \\\"{x:377,y:449,t:1527268886310};\\\", \\\"{x:376,y:449,t:1527268886327};\\\", \\\"{x:374,y:449,t:1527268886345};\\\", \\\"{x:373,y:449,t:1527268886460};\\\", \\\"{x:373,y:454,t:1527268886478};\\\", \\\"{x:370,y:460,t:1527268886493};\\\", \\\"{x:365,y:468,t:1527268886511};\\\", \\\"{x:359,y:476,t:1527268886527};\\\", \\\"{x:349,y:486,t:1527268886544};\\\", \\\"{x:336,y:492,t:1527268886562};\\\", \\\"{x:315,y:497,t:1527268886577};\\\", \\\"{x:291,y:501,t:1527268886595};\\\", \\\"{x:263,y:501,t:1527268886612};\\\", \\\"{x:233,y:501,t:1527268886627};\\\", \\\"{x:200,y:497,t:1527268886644};\\\", \\\"{x:194,y:494,t:1527268886661};\\\", \\\"{x:194,y:493,t:1527268886677};\\\", \\\"{x:196,y:490,t:1527268886694};\\\", \\\"{x:202,y:486,t:1527268886712};\\\", \\\"{x:208,y:482,t:1527268886727};\\\", \\\"{x:210,y:480,t:1527268886745};\\\", \\\"{x:211,y:477,t:1527268886762};\\\", \\\"{x:211,y:476,t:1527268886779};\\\", \\\"{x:211,y:475,t:1527268886795};\\\", \\\"{x:211,y:473,t:1527268886811};\\\", \\\"{x:209,y:472,t:1527268886828};\\\", \\\"{x:209,y:470,t:1527268886846};\\\", \\\"{x:205,y:467,t:1527268886861};\\\", \\\"{x:199,y:463,t:1527268886878};\\\", \\\"{x:191,y:459,t:1527268886894};\\\", \\\"{x:181,y:455,t:1527268886911};\\\", \\\"{x:172,y:452,t:1527268886928};\\\", \\\"{x:167,y:452,t:1527268886945};\\\", \\\"{x:165,y:450,t:1527268886962};\\\", \\\"{x:171,y:451,t:1527268887580};\\\", \\\"{x:190,y:462,t:1527268887595};\\\", \\\"{x:252,y:494,t:1527268887612};\\\", \\\"{x:367,y:547,t:1527268887629};\\\", \\\"{x:453,y:588,t:1527268887646};\\\", \\\"{x:530,y:632,t:1527268887662};\\\", \\\"{x:583,y:658,t:1527268887678};\\\", \\\"{x:616,y:677,t:1527268887695};\\\", \\\"{x:630,y:689,t:1527268887712};\\\", \\\"{x:634,y:693,t:1527268887729};\\\", \\\"{x:636,y:695,t:1527268887745};\\\", \\\"{x:636,y:696,t:1527268887761};\\\", \\\"{x:636,y:697,t:1527268887796};\\\", \\\"{x:636,y:698,t:1527268887812};\\\", \\\"{x:636,y:699,t:1527268887829};\\\", \\\"{x:636,y:701,t:1527268887846};\\\", \\\"{x:636,y:702,t:1527268887862};\\\", \\\"{x:635,y:704,t:1527268887879};\\\", \\\"{x:622,y:704,t:1527268887896};\\\", \\\"{x:604,y:704,t:1527268887913};\\\", \\\"{x:585,y:704,t:1527268887929};\\\", \\\"{x:574,y:704,t:1527268887946};\\\", \\\"{x:566,y:702,t:1527268887963};\\\", \\\"{x:563,y:701,t:1527268887979};\\\", \\\"{x:562,y:701,t:1527268887996};\\\", \\\"{x:560,y:700,t:1527268888061};\\\", \\\"{x:559,y:700,t:1527268888070};\\\", \\\"{x:557,y:700,t:1527268888078};\\\", \\\"{x:552,y:698,t:1527268888095};\\\", \\\"{x:551,y:698,t:1527268888111};\\\", \\\"{x:549,y:698,t:1527268888128};\\\", \\\"{x:548,y:697,t:1527268888145};\\\", \\\"{x:547,y:697,t:1527268888429};\\\", \\\"{x:546,y:696,t:1527268888445};\\\", \\\"{x:545,y:696,t:1527268888541};\\\" ] }, { \\\"rt\\\": 56690, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 14, \\\"time_elapsed\\\": 489348, \\\"internal_node_id\\\": \\\"0.0-6.0-4.0\\\", \\\"subject\\\": \\\"YC7SX\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"mike\\\", \\\"condition\\\": \\\"115-late\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"ends\\\", \\\"q\\\": 10, \\\"clicks\\\": 2.5, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XFull-YFull\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 0, \\\"answer\\\": [ \\\"F\\\", \\\"X\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-Z -X -O -O -F -B -B -G -C -X -X -4\\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:545,y:695,t:1527268901174};\\\", \\\"{x:550,y:694,t:1527268901185};\\\", \\\"{x:572,y:697,t:1527268901203};\\\", \\\"{x:596,y:701,t:1527268901218};\\\", \\\"{x:621,y:706,t:1527268901234};\\\", \\\"{x:646,y:711,t:1527268901251};\\\", \\\"{x:681,y:718,t:1527268901273};\\\", \\\"{x:706,y:725,t:1527268901289};\\\", \\\"{x:733,y:732,t:1527268901306};\\\", \\\"{x:760,y:735,t:1527268901323};\\\", \\\"{x:800,y:741,t:1527268901339};\\\", \\\"{x:829,y:742,t:1527268901356};\\\", \\\"{x:860,y:746,t:1527268901373};\\\", \\\"{x:892,y:746,t:1527268901391};\\\", \\\"{x:922,y:747,t:1527268901406};\\\", \\\"{x:963,y:750,t:1527268901424};\\\", \\\"{x:1003,y:752,t:1527268901440};\\\", \\\"{x:1055,y:755,t:1527268901457};\\\", \\\"{x:1109,y:759,t:1527268901473};\\\", \\\"{x:1168,y:760,t:1527268901491};\\\", \\\"{x:1219,y:760,t:1527268901506};\\\", \\\"{x:1263,y:760,t:1527268901524};\\\", \\\"{x:1315,y:758,t:1527268901540};\\\", \\\"{x:1336,y:755,t:1527268901556};\\\", \\\"{x:1356,y:753,t:1527268901574};\\\", \\\"{x:1368,y:752,t:1527268901591};\\\", \\\"{x:1379,y:749,t:1527268901607};\\\", \\\"{x:1387,y:745,t:1527268901624};\\\", \\\"{x:1392,y:742,t:1527268901641};\\\", \\\"{x:1394,y:739,t:1527268901658};\\\", \\\"{x:1397,y:737,t:1527268901674};\\\", \\\"{x:1402,y:733,t:1527268901690};\\\", \\\"{x:1408,y:728,t:1527268901708};\\\", \\\"{x:1412,y:722,t:1527268901723};\\\", \\\"{x:1415,y:713,t:1527268901741};\\\", \\\"{x:1417,y:705,t:1527268901757};\\\", \\\"{x:1418,y:698,t:1527268901774};\\\", \\\"{x:1420,y:687,t:1527268901791};\\\", \\\"{x:1421,y:680,t:1527268901807};\\\", \\\"{x:1422,y:673,t:1527268901824};\\\", \\\"{x:1423,y:666,t:1527268901841};\\\", \\\"{x:1424,y:661,t:1527268901857};\\\", \\\"{x:1425,y:655,t:1527268901874};\\\", \\\"{x:1425,y:652,t:1527268901891};\\\", \\\"{x:1425,y:650,t:1527268901908};\\\", \\\"{x:1425,y:649,t:1527268901933};\\\", \\\"{x:1425,y:648,t:1527268901949};\\\", \\\"{x:1425,y:647,t:1527268901965};\\\", \\\"{x:1425,y:645,t:1527268901997};\\\", \\\"{x:1423,y:643,t:1527268902045};\\\", \\\"{x:1423,y:642,t:1527268902061};\\\", \\\"{x:1421,y:641,t:1527268902085};\\\", \\\"{x:1419,y:641,t:1527268902101};\\\", \\\"{x:1418,y:640,t:1527268902108};\\\", \\\"{x:1417,y:640,t:1527268902124};\\\", \\\"{x:1416,y:639,t:1527268902140};\\\", \\\"{x:1415,y:639,t:1527268902157};\\\", \\\"{x:1414,y:639,t:1527268902174};\\\", \\\"{x:1413,y:639,t:1527268902190};\\\", \\\"{x:1412,y:639,t:1527268902207};\\\", \\\"{x:1411,y:639,t:1527268902224};\\\", \\\"{x:1412,y:640,t:1527268902549};\\\", \\\"{x:1415,y:640,t:1527268902558};\\\", \\\"{x:1422,y:640,t:1527268902575};\\\", \\\"{x:1428,y:640,t:1527268902592};\\\", \\\"{x:1432,y:640,t:1527268902608};\\\", \\\"{x:1435,y:640,t:1527268902624};\\\", \\\"{x:1439,y:640,t:1527268902642};\\\", \\\"{x:1442,y:640,t:1527268902658};\\\", \\\"{x:1448,y:640,t:1527268902674};\\\", \\\"{x:1451,y:640,t:1527268902692};\\\", \\\"{x:1456,y:641,t:1527268902709};\\\", \\\"{x:1461,y:642,t:1527268902724};\\\", \\\"{x:1468,y:643,t:1527268902742};\\\", \\\"{x:1475,y:643,t:1527268902759};\\\", \\\"{x:1484,y:644,t:1527268902775};\\\", \\\"{x:1491,y:645,t:1527268902792};\\\", \\\"{x:1496,y:647,t:1527268902809};\\\", \\\"{x:1501,y:647,t:1527268902825};\\\", \\\"{x:1505,y:648,t:1527268902842};\\\", \\\"{x:1506,y:648,t:1527268902859};\\\", \\\"{x:1503,y:648,t:1527268902997};\\\", \\\"{x:1499,y:648,t:1527268903009};\\\", \\\"{x:1489,y:646,t:1527268903025};\\\", \\\"{x:1485,y:646,t:1527268903042};\\\", \\\"{x:1489,y:646,t:1527268903541};\\\", \\\"{x:1491,y:646,t:1527268903549};\\\", \\\"{x:1494,y:646,t:1527268903559};\\\", \\\"{x:1501,y:646,t:1527268903576};\\\", \\\"{x:1508,y:646,t:1527268903593};\\\", \\\"{x:1512,y:646,t:1527268903609};\\\", \\\"{x:1516,y:646,t:1527268903625};\\\", \\\"{x:1517,y:646,t:1527268903643};\\\", \\\"{x:1522,y:646,t:1527268903658};\\\", \\\"{x:1527,y:646,t:1527268903675};\\\", \\\"{x:1534,y:646,t:1527268903691};\\\", \\\"{x:1539,y:646,t:1527268903709};\\\", \\\"{x:1540,y:646,t:1527268903749};\\\", \\\"{x:1541,y:646,t:1527268903759};\\\", \\\"{x:1542,y:646,t:1527268903776};\\\", \\\"{x:1544,y:646,t:1527268903792};\\\", \\\"{x:1547,y:646,t:1527268903810};\\\", \\\"{x:1550,y:646,t:1527268903825};\\\", \\\"{x:1551,y:646,t:1527268903842};\\\", \\\"{x:1552,y:646,t:1527268903869};\\\", \\\"{x:1554,y:646,t:1527268904245};\\\", \\\"{x:1559,y:647,t:1527268904260};\\\", \\\"{x:1577,y:650,t:1527268904277};\\\", \\\"{x:1591,y:652,t:1527268904293};\\\", \\\"{x:1598,y:653,t:1527268904310};\\\", \\\"{x:1601,y:653,t:1527268904327};\\\", \\\"{x:1602,y:653,t:1527268904429};\\\", \\\"{x:1603,y:653,t:1527268904444};\\\", \\\"{x:1604,y:653,t:1527268904460};\\\", \\\"{x:1605,y:653,t:1527268904476};\\\", \\\"{x:1606,y:653,t:1527268904548};\\\", \\\"{x:1607,y:653,t:1527268904559};\\\", \\\"{x:1610,y:652,t:1527268904577};\\\", \\\"{x:1612,y:651,t:1527268904594};\\\", \\\"{x:1614,y:650,t:1527268904609};\\\", \\\"{x:1616,y:649,t:1527268904628};\\\", \\\"{x:1617,y:649,t:1527268904894};\\\", \\\"{x:1619,y:649,t:1527268904933};\\\", \\\"{x:1618,y:649,t:1527268908677};\\\", \\\"{x:1615,y:651,t:1527268908693};\\\", \\\"{x:1613,y:652,t:1527268908725};\\\", \\\"{x:1612,y:652,t:1527268908749};\\\", \\\"{x:1610,y:653,t:1527268908765};\\\", \\\"{x:1607,y:655,t:1527268908781};\\\", \\\"{x:1606,y:656,t:1527268908798};\\\", \\\"{x:1603,y:656,t:1527268908815};\\\", \\\"{x:1600,y:659,t:1527268908831};\\\", \\\"{x:1598,y:661,t:1527268908848};\\\", \\\"{x:1594,y:664,t:1527268908865};\\\", \\\"{x:1591,y:667,t:1527268908881};\\\", \\\"{x:1586,y:670,t:1527268908898};\\\", \\\"{x:1581,y:678,t:1527268908915};\\\", \\\"{x:1572,y:688,t:1527268908931};\\\", \\\"{x:1563,y:698,t:1527268908949};\\\", \\\"{x:1544,y:717,t:1527268908965};\\\", \\\"{x:1534,y:730,t:1527268908981};\\\", \\\"{x:1527,y:739,t:1527268908998};\\\", \\\"{x:1521,y:750,t:1527268909015};\\\", \\\"{x:1517,y:757,t:1527268909031};\\\", \\\"{x:1514,y:761,t:1527268909048};\\\", \\\"{x:1513,y:763,t:1527268909065};\\\", \\\"{x:1513,y:764,t:1527268909082};\\\", \\\"{x:1515,y:766,t:1527268909150};\\\", \\\"{x:1520,y:769,t:1527268909165};\\\", \\\"{x:1528,y:770,t:1527268909182};\\\", \\\"{x:1537,y:773,t:1527268909198};\\\", \\\"{x:1548,y:776,t:1527268909216};\\\", \\\"{x:1560,y:780,t:1527268909232};\\\", \\\"{x:1569,y:783,t:1527268909248};\\\", \\\"{x:1572,y:783,t:1527268909266};\\\", \\\"{x:1573,y:783,t:1527268909605};\\\", \\\"{x:1576,y:783,t:1527268909615};\\\", \\\"{x:1579,y:785,t:1527268909632};\\\", \\\"{x:1580,y:785,t:1527268909649};\\\", \\\"{x:1582,y:785,t:1527268909693};\\\", \\\"{x:1583,y:786,t:1527268909717};\\\", \\\"{x:1585,y:786,t:1527268909749};\\\", \\\"{x:1586,y:786,t:1527268909773};\\\", \\\"{x:1587,y:786,t:1527268909782};\\\", \\\"{x:1588,y:785,t:1527268909799};\\\", \\\"{x:1590,y:784,t:1527268909816};\\\", \\\"{x:1592,y:782,t:1527268909832};\\\", \\\"{x:1595,y:782,t:1527268909850};\\\", \\\"{x:1598,y:782,t:1527268909866};\\\", \\\"{x:1599,y:780,t:1527268909883};\\\", \\\"{x:1600,y:780,t:1527268909908};\\\", \\\"{x:1601,y:780,t:1527268909949};\\\", \\\"{x:1602,y:780,t:1527268909973};\\\", \\\"{x:1603,y:780,t:1527268909982};\\\", \\\"{x:1604,y:779,t:1527268910004};\\\", \\\"{x:1605,y:779,t:1527268910059};\\\", \\\"{x:1606,y:778,t:1527268910067};\\\", \\\"{x:1607,y:778,t:1527268910084};\\\", \\\"{x:1608,y:778,t:1527268910140};\\\", \\\"{x:1608,y:777,t:1527268910405};\\\", \\\"{x:1606,y:777,t:1527268910416};\\\", \\\"{x:1588,y:774,t:1527268910433};\\\", \\\"{x:1557,y:772,t:1527268910451};\\\", \\\"{x:1520,y:772,t:1527268910466};\\\", \\\"{x:1478,y:772,t:1527268910484};\\\", \\\"{x:1442,y:772,t:1527268910501};\\\", \\\"{x:1413,y:766,t:1527268910516};\\\", \\\"{x:1390,y:759,t:1527268910533};\\\", \\\"{x:1375,y:753,t:1527268910550};\\\", \\\"{x:1361,y:747,t:1527268910567};\\\", \\\"{x:1340,y:738,t:1527268910583};\\\", \\\"{x:1300,y:722,t:1527268910601};\\\", \\\"{x:1236,y:694,t:1527268910617};\\\", \\\"{x:1164,y:663,t:1527268910633};\\\", \\\"{x:1107,y:641,t:1527268910650};\\\", \\\"{x:1071,y:626,t:1527268910666};\\\", \\\"{x:1043,y:612,t:1527268910683};\\\", \\\"{x:1021,y:605,t:1527268910701};\\\", \\\"{x:1000,y:598,t:1527268910717};\\\", \\\"{x:987,y:594,t:1527268910733};\\\", \\\"{x:970,y:591,t:1527268910750};\\\", \\\"{x:946,y:588,t:1527268910767};\\\", \\\"{x:913,y:582,t:1527268910783};\\\", \\\"{x:867,y:571,t:1527268910802};\\\", \\\"{x:813,y:562,t:1527268910817};\\\", \\\"{x:761,y:551,t:1527268910832};\\\", \\\"{x:730,y:544,t:1527268910848};\\\", \\\"{x:711,y:537,t:1527268910864};\\\", \\\"{x:702,y:534,t:1527268910880};\\\", \\\"{x:697,y:533,t:1527268910897};\\\", \\\"{x:696,y:532,t:1527268910914};\\\", \\\"{x:695,y:531,t:1527268910972};\\\", \\\"{x:693,y:529,t:1527268910987};\\\", \\\"{x:692,y:529,t:1527268910997};\\\", \\\"{x:689,y:528,t:1527268911013};\\\", \\\"{x:685,y:526,t:1527268911031};\\\", \\\"{x:682,y:526,t:1527268911047};\\\", \\\"{x:674,y:525,t:1527268911065};\\\", \\\"{x:660,y:525,t:1527268911081};\\\", \\\"{x:645,y:525,t:1527268911098};\\\", \\\"{x:633,y:525,t:1527268911116};\\\", \\\"{x:622,y:525,t:1527268911130};\\\", \\\"{x:610,y:525,t:1527268911148};\\\", \\\"{x:608,y:525,t:1527268911163};\\\", \\\"{x:607,y:525,t:1527268911181};\\\", \\\"{x:609,y:525,t:1527268911709};\\\", \\\"{x:613,y:526,t:1527268911717};\\\", \\\"{x:625,y:535,t:1527268911733};\\\", \\\"{x:633,y:541,t:1527268911748};\\\", \\\"{x:662,y:561,t:1527268911766};\\\", \\\"{x:692,y:580,t:1527268911782};\\\", \\\"{x:727,y:600,t:1527268911798};\\\", \\\"{x:775,y:624,t:1527268911815};\\\", \\\"{x:819,y:644,t:1527268911831};\\\", \\\"{x:879,y:666,t:1527268911849};\\\", \\\"{x:939,y:688,t:1527268911864};\\\", \\\"{x:970,y:704,t:1527268911882};\\\", \\\"{x:1007,y:721,t:1527268911899};\\\", \\\"{x:1029,y:730,t:1527268911915};\\\", \\\"{x:1062,y:745,t:1527268911932};\\\", \\\"{x:1078,y:750,t:1527268911949};\\\", \\\"{x:1092,y:756,t:1527268911965};\\\", \\\"{x:1107,y:761,t:1527268911983};\\\", \\\"{x:1120,y:766,t:1527268911999};\\\", \\\"{x:1132,y:770,t:1527268912014};\\\", \\\"{x:1140,y:771,t:1527268912032};\\\", \\\"{x:1147,y:774,t:1527268912049};\\\", \\\"{x:1153,y:775,t:1527268912065};\\\", \\\"{x:1155,y:776,t:1527268912082};\\\", \\\"{x:1156,y:776,t:1527268912099};\\\", \\\"{x:1157,y:776,t:1527268912133};\\\", \\\"{x:1158,y:776,t:1527268912150};\\\", \\\"{x:1159,y:777,t:1527268912181};\\\", \\\"{x:1161,y:777,t:1527268912357};\\\", \\\"{x:1162,y:777,t:1527268912367};\\\", \\\"{x:1166,y:777,t:1527268912382};\\\", \\\"{x:1169,y:776,t:1527268912399};\\\", \\\"{x:1175,y:776,t:1527268912416};\\\", \\\"{x:1188,y:774,t:1527268912432};\\\", \\\"{x:1202,y:774,t:1527268912449};\\\", \\\"{x:1220,y:774,t:1527268912466};\\\", \\\"{x:1243,y:774,t:1527268912482};\\\", \\\"{x:1263,y:773,t:1527268912499};\\\", \\\"{x:1287,y:769,t:1527268912517};\\\", \\\"{x:1293,y:768,t:1527268912532};\\\", \\\"{x:1313,y:764,t:1527268912549};\\\", \\\"{x:1331,y:762,t:1527268912567};\\\", \\\"{x:1349,y:758,t:1527268912582};\\\", \\\"{x:1366,y:755,t:1527268912599};\\\", \\\"{x:1376,y:751,t:1527268912616};\\\", \\\"{x:1387,y:749,t:1527268912632};\\\", \\\"{x:1393,y:747,t:1527268912649};\\\", \\\"{x:1396,y:746,t:1527268912666};\\\", \\\"{x:1398,y:745,t:1527268912684};\\\", \\\"{x:1400,y:744,t:1527268912700};\\\", \\\"{x:1407,y:740,t:1527268912717};\\\", \\\"{x:1411,y:737,t:1527268912733};\\\", \\\"{x:1415,y:735,t:1527268912749};\\\", \\\"{x:1418,y:733,t:1527268912766};\\\", \\\"{x:1420,y:731,t:1527268912783};\\\", \\\"{x:1420,y:729,t:1527268912861};\\\", \\\"{x:1419,y:729,t:1527268912876};\\\", \\\"{x:1418,y:729,t:1527268912941};\\\", \\\"{x:1417,y:729,t:1527268912956};\\\", \\\"{x:1416,y:728,t:1527268912967};\\\", \\\"{x:1416,y:727,t:1527268912983};\\\", \\\"{x:1415,y:727,t:1527268912999};\\\", \\\"{x:1413,y:726,t:1527268913028};\\\", \\\"{x:1411,y:724,t:1527268913076};\\\", \\\"{x:1409,y:724,t:1527268913108};\\\", \\\"{x:1409,y:723,t:1527268913333};\\\", \\\"{x:1410,y:723,t:1527268913351};\\\", \\\"{x:1412,y:721,t:1527268913373};\\\", \\\"{x:1413,y:721,t:1527268913383};\\\", \\\"{x:1414,y:720,t:1527268913401};\\\", \\\"{x:1415,y:719,t:1527268913416};\\\", \\\"{x:1416,y:718,t:1527268913434};\\\", \\\"{x:1417,y:717,t:1527268913450};\\\", \\\"{x:1418,y:716,t:1527268913469};\\\", \\\"{x:1419,y:715,t:1527268913485};\\\", \\\"{x:1419,y:714,t:1527268913509};\\\", \\\"{x:1420,y:712,t:1527268913525};\\\", \\\"{x:1420,y:711,t:1527268913573};\\\", \\\"{x:1420,y:709,t:1527268913605};\\\", \\\"{x:1420,y:708,t:1527268913637};\\\", \\\"{x:1420,y:706,t:1527268913885};\\\", \\\"{x:1422,y:704,t:1527268913901};\\\", \\\"{x:1423,y:704,t:1527268913917};\\\", \\\"{x:1426,y:704,t:1527268913934};\\\", \\\"{x:1430,y:704,t:1527268913950};\\\", \\\"{x:1433,y:704,t:1527268913968};\\\", \\\"{x:1436,y:704,t:1527268913984};\\\", \\\"{x:1437,y:704,t:1527268914000};\\\", \\\"{x:1438,y:704,t:1527268914017};\\\", \\\"{x:1439,y:704,t:1527268914034};\\\", \\\"{x:1441,y:705,t:1527268914051};\\\", \\\"{x:1444,y:705,t:1527268914068};\\\", \\\"{x:1450,y:707,t:1527268914084};\\\", \\\"{x:1456,y:708,t:1527268914100};\\\", \\\"{x:1461,y:709,t:1527268914117};\\\", \\\"{x:1465,y:710,t:1527268914134};\\\", \\\"{x:1468,y:710,t:1527268914149};\\\", \\\"{x:1469,y:710,t:1527268914167};\\\", \\\"{x:1470,y:710,t:1527268914184};\\\", \\\"{x:1471,y:710,t:1527268914244};\\\", \\\"{x:1473,y:711,t:1527268914317};\\\", \\\"{x:1474,y:711,t:1527268914334};\\\", \\\"{x:1475,y:711,t:1527268914356};\\\", \\\"{x:1476,y:711,t:1527268914373};\\\", \\\"{x:1477,y:711,t:1527268914384};\\\", \\\"{x:1480,y:711,t:1527268914401};\\\", \\\"{x:1481,y:711,t:1527268914417};\\\", \\\"{x:1483,y:711,t:1527268914435};\\\", \\\"{x:1486,y:711,t:1527268914734};\\\", \\\"{x:1490,y:711,t:1527268914751};\\\", \\\"{x:1494,y:711,t:1527268914768};\\\", \\\"{x:1498,y:711,t:1527268914784};\\\", \\\"{x:1502,y:712,t:1527268914802};\\\", \\\"{x:1505,y:713,t:1527268914819};\\\", \\\"{x:1508,y:713,t:1527268914835};\\\", \\\"{x:1510,y:713,t:1527268914852};\\\", \\\"{x:1512,y:713,t:1527268914867};\\\", \\\"{x:1520,y:714,t:1527268914886};\\\", \\\"{x:1525,y:714,t:1527268914902};\\\", \\\"{x:1530,y:714,t:1527268914919};\\\", \\\"{x:1535,y:716,t:1527268914935};\\\", \\\"{x:1537,y:716,t:1527268914951};\\\", \\\"{x:1540,y:716,t:1527268914968};\\\", \\\"{x:1543,y:716,t:1527268914984};\\\", \\\"{x:1547,y:716,t:1527268915002};\\\", \\\"{x:1550,y:716,t:1527268915018};\\\", \\\"{x:1553,y:716,t:1527268915035};\\\", \\\"{x:1555,y:716,t:1527268915051};\\\", \\\"{x:1556,y:716,t:1527268920036};\\\", \\\"{x:1554,y:717,t:1527268920052};\\\", \\\"{x:1548,y:717,t:1527268920533};\\\", \\\"{x:1541,y:715,t:1527268920541};\\\", \\\"{x:1530,y:710,t:1527268920557};\\\", \\\"{x:1513,y:704,t:1527268920573};\\\", \\\"{x:1496,y:697,t:1527268920590};\\\", \\\"{x:1483,y:693,t:1527268920606};\\\", \\\"{x:1474,y:689,t:1527268920622};\\\", \\\"{x:1469,y:685,t:1527268920639};\\\", \\\"{x:1466,y:682,t:1527268920656};\\\", \\\"{x:1466,y:681,t:1527268920676};\\\", \\\"{x:1465,y:680,t:1527268920689};\\\", \\\"{x:1462,y:674,t:1527268920707};\\\", \\\"{x:1458,y:670,t:1527268920723};\\\", \\\"{x:1450,y:666,t:1527268920739};\\\", \\\"{x:1428,y:654,t:1527268920756};\\\", \\\"{x:1408,y:645,t:1527268920772};\\\", \\\"{x:1397,y:639,t:1527268920790};\\\", \\\"{x:1387,y:634,t:1527268920806};\\\", \\\"{x:1385,y:632,t:1527268920822};\\\", \\\"{x:1385,y:631,t:1527268920853};\\\", \\\"{x:1386,y:630,t:1527268920877};\\\", \\\"{x:1387,y:630,t:1527268920917};\\\", \\\"{x:1388,y:630,t:1527268920924};\\\", \\\"{x:1389,y:630,t:1527268920939};\\\", \\\"{x:1390,y:630,t:1527268920957};\\\", \\\"{x:1392,y:630,t:1527268920973};\\\", \\\"{x:1395,y:630,t:1527268920990};\\\", \\\"{x:1399,y:630,t:1527268921007};\\\", \\\"{x:1403,y:630,t:1527268921023};\\\", \\\"{x:1407,y:633,t:1527268921040};\\\", \\\"{x:1410,y:637,t:1527268921056};\\\", \\\"{x:1412,y:638,t:1527268921073};\\\", \\\"{x:1412,y:640,t:1527268921090};\\\", \\\"{x:1414,y:642,t:1527268921107};\\\", \\\"{x:1415,y:644,t:1527268921124};\\\", \\\"{x:1417,y:645,t:1527268921140};\\\", \\\"{x:1418,y:645,t:1527268921156};\\\", \\\"{x:1418,y:646,t:1527268921181};\\\", \\\"{x:1418,y:647,t:1527268922077};\\\", \\\"{x:1417,y:647,t:1527268922091};\\\", \\\"{x:1416,y:649,t:1527268922108};\\\", \\\"{x:1414,y:649,t:1527268922124};\\\", \\\"{x:1413,y:649,t:1527268922140};\\\", \\\"{x:1411,y:649,t:1527268922158};\\\", \\\"{x:1409,y:649,t:1527268922176};\\\", \\\"{x:1405,y:649,t:1527268922191};\\\", \\\"{x:1400,y:649,t:1527268922208};\\\", \\\"{x:1391,y:645,t:1527268922225};\\\", \\\"{x:1383,y:642,t:1527268922241};\\\", \\\"{x:1371,y:639,t:1527268922258};\\\", \\\"{x:1363,y:637,t:1527268922275};\\\", \\\"{x:1360,y:635,t:1527268922291};\\\", \\\"{x:1354,y:634,t:1527268922308};\\\", \\\"{x:1348,y:631,t:1527268922324};\\\", \\\"{x:1344,y:630,t:1527268922341};\\\", \\\"{x:1343,y:629,t:1527268922358};\\\", \\\"{x:1342,y:629,t:1527268922478};\\\", \\\"{x:1341,y:629,t:1527268922491};\\\", \\\"{x:1339,y:629,t:1527268922508};\\\", \\\"{x:1338,y:629,t:1527268922525};\\\", \\\"{x:1338,y:630,t:1527268922541};\\\", \\\"{x:1338,y:631,t:1527268922558};\\\", \\\"{x:1338,y:633,t:1527268922575};\\\", \\\"{x:1338,y:635,t:1527268922592};\\\", \\\"{x:1338,y:638,t:1527268922608};\\\", \\\"{x:1338,y:640,t:1527268922624};\\\", \\\"{x:1338,y:641,t:1527268922641};\\\", \\\"{x:1338,y:643,t:1527268922658};\\\", \\\"{x:1338,y:644,t:1527268922675};\\\", \\\"{x:1338,y:647,t:1527268922692};\\\", \\\"{x:1338,y:649,t:1527268922708};\\\", \\\"{x:1339,y:653,t:1527268922724};\\\", \\\"{x:1340,y:656,t:1527268922742};\\\", \\\"{x:1340,y:660,t:1527268922758};\\\", \\\"{x:1342,y:663,t:1527268922774};\\\", \\\"{x:1342,y:665,t:1527268922792};\\\", \\\"{x:1342,y:667,t:1527268922808};\\\", \\\"{x:1343,y:670,t:1527268922825};\\\", \\\"{x:1343,y:673,t:1527268922842};\\\", \\\"{x:1343,y:674,t:1527268922858};\\\", \\\"{x:1344,y:676,t:1527268922875};\\\", \\\"{x:1344,y:677,t:1527268922892};\\\", \\\"{x:1344,y:678,t:1527268922908};\\\", \\\"{x:1346,y:680,t:1527268922924};\\\", \\\"{x:1346,y:683,t:1527268922941};\\\", \\\"{x:1347,y:685,t:1527268922958};\\\", \\\"{x:1348,y:687,t:1527268922975};\\\", \\\"{x:1348,y:691,t:1527268922992};\\\", \\\"{x:1349,y:694,t:1527268923009};\\\", \\\"{x:1349,y:700,t:1527268923025};\\\", \\\"{x:1350,y:704,t:1527268923041};\\\", \\\"{x:1351,y:708,t:1527268923059};\\\", \\\"{x:1351,y:710,t:1527268923075};\\\", \\\"{x:1352,y:712,t:1527268923092};\\\", \\\"{x:1352,y:717,t:1527268923110};\\\", \\\"{x:1353,y:719,t:1527268923124};\\\", \\\"{x:1353,y:722,t:1527268923142};\\\", \\\"{x:1353,y:725,t:1527268923159};\\\", \\\"{x:1353,y:729,t:1527268923175};\\\", \\\"{x:1353,y:732,t:1527268923192};\\\", \\\"{x:1353,y:736,t:1527268923209};\\\", \\\"{x:1353,y:739,t:1527268923225};\\\", \\\"{x:1353,y:742,t:1527268923242};\\\", \\\"{x:1353,y:744,t:1527268923259};\\\", \\\"{x:1353,y:746,t:1527268923275};\\\", \\\"{x:1353,y:748,t:1527268923292};\\\", \\\"{x:1353,y:749,t:1527268923309};\\\", \\\"{x:1353,y:750,t:1527268923325};\\\", \\\"{x:1353,y:747,t:1527268923429};\\\", \\\"{x:1353,y:744,t:1527268923442};\\\", \\\"{x:1353,y:735,t:1527268923459};\\\", \\\"{x:1353,y:722,t:1527268923476};\\\", \\\"{x:1354,y:713,t:1527268923491};\\\", \\\"{x:1356,y:703,t:1527268923508};\\\", \\\"{x:1356,y:697,t:1527268923526};\\\", \\\"{x:1356,y:692,t:1527268923542};\\\", \\\"{x:1356,y:684,t:1527268923559};\\\", \\\"{x:1357,y:677,t:1527268923575};\\\", \\\"{x:1358,y:673,t:1527268923591};\\\", \\\"{x:1360,y:670,t:1527268923609};\\\", \\\"{x:1360,y:667,t:1527268923626};\\\", \\\"{x:1362,y:665,t:1527268923642};\\\", \\\"{x:1362,y:664,t:1527268923658};\\\", \\\"{x:1363,y:662,t:1527268923676};\\\", \\\"{x:1363,y:661,t:1527268923861};\\\", \\\"{x:1363,y:660,t:1527268923876};\\\", \\\"{x:1363,y:658,t:1527268923893};\\\", \\\"{x:1363,y:656,t:1527268923909};\\\", \\\"{x:1363,y:655,t:1527268923925};\\\", \\\"{x:1363,y:653,t:1527268923943};\\\", \\\"{x:1363,y:651,t:1527268923964};\\\", \\\"{x:1363,y:650,t:1527268923997};\\\", \\\"{x:1358,y:650,t:1527268926597};\\\", \\\"{x:1351,y:650,t:1527268926611};\\\", \\\"{x:1335,y:646,t:1527268926628};\\\", \\\"{x:1292,y:640,t:1527268926644};\\\", \\\"{x:1248,y:631,t:1527268926662};\\\", \\\"{x:1183,y:616,t:1527268926678};\\\", \\\"{x:1118,y:597,t:1527268926695};\\\", \\\"{x:1036,y:576,t:1527268926712};\\\", \\\"{x:946,y:559,t:1527268926729};\\\", \\\"{x:864,y:542,t:1527268926745};\\\", \\\"{x:800,y:534,t:1527268926761};\\\", \\\"{x:784,y:530,t:1527268926793};\\\", \\\"{x:784,y:529,t:1527268926810};\\\", \\\"{x:787,y:528,t:1527268926827};\\\", \\\"{x:790,y:527,t:1527268926843};\\\", \\\"{x:792,y:525,t:1527268926859};\\\", \\\"{x:794,y:525,t:1527268926877};\\\", \\\"{x:802,y:521,t:1527268926894};\\\", \\\"{x:805,y:520,t:1527268926910};\\\", \\\"{x:809,y:517,t:1527268926927};\\\", \\\"{x:813,y:512,t:1527268926943};\\\", \\\"{x:817,y:503,t:1527268926962};\\\", \\\"{x:820,y:495,t:1527268926979};\\\", \\\"{x:822,y:484,t:1527268926993};\\\", \\\"{x:822,y:477,t:1527268927010};\\\", \\\"{x:822,y:474,t:1527268927027};\\\", \\\"{x:822,y:470,t:1527268927044};\\\", \\\"{x:822,y:465,t:1527268927060};\\\", \\\"{x:822,y:462,t:1527268927078};\\\", \\\"{x:822,y:458,t:1527268927094};\\\", \\\"{x:822,y:454,t:1527268927110};\\\", \\\"{x:822,y:451,t:1527268927127};\\\", \\\"{x:822,y:448,t:1527268927144};\\\", \\\"{x:823,y:446,t:1527268927161};\\\", \\\"{x:827,y:446,t:1527268927485};\\\", \\\"{x:831,y:446,t:1527268927495};\\\", \\\"{x:838,y:446,t:1527268927511};\\\", \\\"{x:845,y:448,t:1527268927527};\\\", \\\"{x:853,y:456,t:1527268927544};\\\", \\\"{x:861,y:465,t:1527268927562};\\\", \\\"{x:870,y:476,t:1527268927578};\\\", \\\"{x:883,y:488,t:1527268927594};\\\", \\\"{x:894,y:497,t:1527268927611};\\\", \\\"{x:900,y:501,t:1527268927627};\\\", \\\"{x:897,y:499,t:1527268927917};\\\", \\\"{x:893,y:493,t:1527268927928};\\\", \\\"{x:882,y:484,t:1527268927944};\\\", \\\"{x:874,y:474,t:1527268927961};\\\", \\\"{x:868,y:471,t:1527268927980};\\\", \\\"{x:864,y:469,t:1527268927994};\\\", \\\"{x:863,y:467,t:1527268928051};\\\", \\\"{x:861,y:466,t:1527268928059};\\\", \\\"{x:853,y:460,t:1527268928078};\\\", \\\"{x:846,y:457,t:1527268928095};\\\", \\\"{x:841,y:453,t:1527268928111};\\\", \\\"{x:838,y:450,t:1527268928129};\\\", \\\"{x:835,y:446,t:1527268928145};\\\", \\\"{x:835,y:445,t:1527268928163};\\\", \\\"{x:837,y:445,t:1527268928515};\\\", \\\"{x:840,y:448,t:1527268928528};\\\", \\\"{x:853,y:460,t:1527268928546};\\\", \\\"{x:865,y:467,t:1527268928561};\\\", \\\"{x:873,y:472,t:1527268928579};\\\", \\\"{x:879,y:475,t:1527268928595};\\\", \\\"{x:881,y:477,t:1527268928612};\\\", \\\"{x:883,y:478,t:1527268928628};\\\", \\\"{x:884,y:479,t:1527268928652};\\\", \\\"{x:887,y:479,t:1527268928708};\\\", \\\"{x:892,y:482,t:1527268928715};\\\", \\\"{x:896,y:485,t:1527268928728};\\\", \\\"{x:912,y:494,t:1527268928746};\\\", \\\"{x:933,y:507,t:1527268928762};\\\", \\\"{x:956,y:519,t:1527268928779};\\\", \\\"{x:1007,y:540,t:1527268928796};\\\", \\\"{x:1027,y:547,t:1527268928811};\\\", \\\"{x:1074,y:568,t:1527268928829};\\\", \\\"{x:1101,y:582,t:1527268928846};\\\", \\\"{x:1126,y:598,t:1527268928862};\\\", \\\"{x:1154,y:622,t:1527268928879};\\\", \\\"{x:1169,y:638,t:1527268928895};\\\", \\\"{x:1169,y:645,t:1527268928913};\\\", \\\"{x:1170,y:645,t:1527268930581};\\\", \\\"{x:1171,y:645,t:1527268930597};\\\", \\\"{x:1172,y:645,t:1527268930614};\\\", \\\"{x:1173,y:645,t:1527268930653};\\\", \\\"{x:1177,y:645,t:1527268931005};\\\", \\\"{x:1184,y:644,t:1527268931014};\\\", \\\"{x:1200,y:640,t:1527268931032};\\\", \\\"{x:1217,y:631,t:1527268931047};\\\", \\\"{x:1255,y:611,t:1527268931064};\\\", \\\"{x:1280,y:594,t:1527268931081};\\\", \\\"{x:1298,y:572,t:1527268931097};\\\", \\\"{x:1313,y:556,t:1527268931114};\\\", \\\"{x:1322,y:548,t:1527268931131};\\\", \\\"{x:1327,y:544,t:1527268931147};\\\", \\\"{x:1328,y:543,t:1527268931164};\\\", \\\"{x:1329,y:542,t:1527268931182};\\\", \\\"{x:1329,y:541,t:1527268931204};\\\", \\\"{x:1330,y:539,t:1527268931221};\\\", \\\"{x:1331,y:538,t:1527268931237};\\\", \\\"{x:1331,y:535,t:1527268931252};\\\", \\\"{x:1333,y:535,t:1527268931264};\\\", \\\"{x:1333,y:534,t:1527268931285};\\\", \\\"{x:1333,y:532,t:1527268931317};\\\", \\\"{x:1333,y:531,t:1527268931331};\\\", \\\"{x:1332,y:527,t:1527268931348};\\\", \\\"{x:1331,y:526,t:1527268931364};\\\", \\\"{x:1327,y:522,t:1527268931381};\\\", \\\"{x:1325,y:520,t:1527268931398};\\\", \\\"{x:1324,y:518,t:1527268931414};\\\", \\\"{x:1322,y:517,t:1527268931477};\\\", \\\"{x:1321,y:517,t:1527268931492};\\\", \\\"{x:1320,y:517,t:1527268931500};\\\", \\\"{x:1318,y:516,t:1527268931514};\\\", \\\"{x:1316,y:515,t:1527268931531};\\\", \\\"{x:1313,y:514,t:1527268931548};\\\", \\\"{x:1312,y:514,t:1527268931566};\\\", \\\"{x:1311,y:514,t:1527268931581};\\\", \\\"{x:1310,y:514,t:1527268931637};\\\", \\\"{x:1309,y:514,t:1527268931661};\\\", \\\"{x:1308,y:514,t:1527268931677};\\\", \\\"{x:1307,y:514,t:1527268931693};\\\", \\\"{x:1306,y:514,t:1527268931733};\\\", \\\"{x:1305,y:514,t:1527268931749};\\\", \\\"{x:1304,y:514,t:1527268931765};\\\", \\\"{x:1303,y:514,t:1527268932117};\\\", \\\"{x:1302,y:515,t:1527268932389};\\\", \\\"{x:1302,y:516,t:1527268932501};\\\", \\\"{x:1302,y:517,t:1527268932533};\\\", \\\"{x:1302,y:518,t:1527268932949};\\\", \\\"{x:1301,y:518,t:1527268932981};\\\", \\\"{x:1300,y:519,t:1527268932990};\\\", \\\"{x:1299,y:519,t:1527268933165};\\\", \\\"{x:1299,y:520,t:1527268933183};\\\", \\\"{x:1298,y:520,t:1527268933204};\\\", \\\"{x:1297,y:520,t:1527268933309};\\\", \\\"{x:1294,y:520,t:1527268933316};\\\", \\\"{x:1296,y:519,t:1527268933485};\\\", \\\"{x:1298,y:517,t:1527268933499};\\\", \\\"{x:1305,y:515,t:1527268933516};\\\", \\\"{x:1309,y:513,t:1527268933533};\\\", \\\"{x:1310,y:512,t:1527268933549};\\\", \\\"{x:1311,y:512,t:1527268933567};\\\", \\\"{x:1312,y:512,t:1527268933583};\\\", \\\"{x:1314,y:512,t:1527268933600};\\\", \\\"{x:1315,y:510,t:1527268933617};\\\", \\\"{x:1319,y:509,t:1527268933636};\\\", \\\"{x:1321,y:509,t:1527268933649};\\\", \\\"{x:1328,y:509,t:1527268933666};\\\", \\\"{x:1335,y:509,t:1527268933684};\\\", \\\"{x:1342,y:510,t:1527268933699};\\\", \\\"{x:1352,y:510,t:1527268933716};\\\", \\\"{x:1359,y:511,t:1527268933733};\\\", \\\"{x:1366,y:513,t:1527268933750};\\\", \\\"{x:1367,y:514,t:1527268933845};\\\", \\\"{x:1367,y:515,t:1527268933885};\\\", \\\"{x:1365,y:517,t:1527268933900};\\\", \\\"{x:1364,y:517,t:1527268933917};\\\", \\\"{x:1362,y:517,t:1527268933933};\\\", \\\"{x:1361,y:518,t:1527268933951};\\\", \\\"{x:1359,y:518,t:1527268934005};\\\", \\\"{x:1357,y:517,t:1527268934016};\\\", \\\"{x:1356,y:517,t:1527268934033};\\\", \\\"{x:1354,y:516,t:1527268934050};\\\", \\\"{x:1354,y:514,t:1527268934165};\\\", \\\"{x:1355,y:514,t:1527268934172};\\\", \\\"{x:1356,y:513,t:1527268934189};\\\", \\\"{x:1357,y:513,t:1527268934200};\\\", \\\"{x:1358,y:512,t:1527268934228};\\\", \\\"{x:1360,y:512,t:1527268934244};\\\", \\\"{x:1362,y:512,t:1527268934252};\\\", \\\"{x:1362,y:511,t:1527268934266};\\\", \\\"{x:1364,y:510,t:1527268934283};\\\", \\\"{x:1368,y:509,t:1527268934300};\\\", \\\"{x:1374,y:509,t:1527268934317};\\\", \\\"{x:1377,y:509,t:1527268934333};\\\", \\\"{x:1379,y:509,t:1527268934350};\\\", \\\"{x:1383,y:509,t:1527268934367};\\\", \\\"{x:1386,y:509,t:1527268934383};\\\", \\\"{x:1389,y:509,t:1527268934400};\\\", \\\"{x:1391,y:509,t:1527268934525};\\\", \\\"{x:1392,y:509,t:1527268934533};\\\", \\\"{x:1395,y:509,t:1527268934550};\\\", \\\"{x:1399,y:510,t:1527268934567};\\\", \\\"{x:1403,y:512,t:1527268934583};\\\", \\\"{x:1407,y:512,t:1527268934601};\\\", \\\"{x:1410,y:514,t:1527268934618};\\\", \\\"{x:1412,y:515,t:1527268934650};\\\", \\\"{x:1413,y:515,t:1527268934668};\\\", \\\"{x:1414,y:515,t:1527268935284};\\\", \\\"{x:1414,y:516,t:1527268935470};\\\", \\\"{x:1413,y:517,t:1527268935941};\\\", \\\"{x:1412,y:518,t:1527268936077};\\\", \\\"{x:1411,y:518,t:1527268936100};\\\", \\\"{x:1410,y:520,t:1527268938745};\\\", \\\"{x:1410,y:521,t:1527268938768};\\\", \\\"{x:1410,y:522,t:1527268938775};\\\", \\\"{x:1410,y:523,t:1527268938791};\\\", \\\"{x:1410,y:525,t:1527268938806};\\\", \\\"{x:1410,y:527,t:1527268938823};\\\", \\\"{x:1410,y:528,t:1527268938847};\\\", \\\"{x:1410,y:529,t:1527268938856};\\\", \\\"{x:1411,y:530,t:1527268938874};\\\", \\\"{x:1412,y:532,t:1527268938890};\\\", \\\"{x:1413,y:533,t:1527268938906};\\\", \\\"{x:1414,y:536,t:1527268938924};\\\", \\\"{x:1415,y:539,t:1527268938941};\\\", \\\"{x:1417,y:541,t:1527268938956};\\\", \\\"{x:1418,y:543,t:1527268938973};\\\", \\\"{x:1420,y:547,t:1527268938991};\\\", \\\"{x:1421,y:549,t:1527268939007};\\\", \\\"{x:1424,y:552,t:1527268939024};\\\", \\\"{x:1425,y:555,t:1527268939041};\\\", \\\"{x:1428,y:558,t:1527268939058};\\\", \\\"{x:1431,y:561,t:1527268939074};\\\", \\\"{x:1432,y:562,t:1527268939091};\\\", \\\"{x:1433,y:564,t:1527268939107};\\\", \\\"{x:1434,y:565,t:1527268939123};\\\", \\\"{x:1435,y:565,t:1527268939141};\\\", \\\"{x:1437,y:567,t:1527268939158};\\\", \\\"{x:1438,y:567,t:1527268939174};\\\", \\\"{x:1439,y:568,t:1527268939192};\\\", \\\"{x:1439,y:570,t:1527268939208};\\\", \\\"{x:1440,y:570,t:1527268939223};\\\", \\\"{x:1440,y:571,t:1527268939328};\\\", \\\"{x:1441,y:572,t:1527268939341};\\\", \\\"{x:1442,y:572,t:1527268939360};\\\", \\\"{x:1442,y:573,t:1527268939374};\\\", \\\"{x:1443,y:575,t:1527268939393};\\\", \\\"{x:1444,y:576,t:1527268939424};\\\", \\\"{x:1445,y:577,t:1527268939448};\\\", \\\"{x:1445,y:579,t:1527268939504};\\\", \\\"{x:1446,y:580,t:1527268939527};\\\", \\\"{x:1447,y:580,t:1527268939544};\\\", \\\"{x:1447,y:581,t:1527268939559};\\\", \\\"{x:1447,y:582,t:1527268939575};\\\", \\\"{x:1448,y:586,t:1527268939593};\\\", \\\"{x:1449,y:586,t:1527268939608};\\\", \\\"{x:1450,y:588,t:1527268939624};\\\", \\\"{x:1450,y:589,t:1527268939641};\\\", \\\"{x:1450,y:590,t:1527268939658};\\\", \\\"{x:1450,y:591,t:1527268939675};\\\", \\\"{x:1451,y:592,t:1527268939691};\\\", \\\"{x:1452,y:594,t:1527268939708};\\\", \\\"{x:1452,y:595,t:1527268939725};\\\", \\\"{x:1453,y:598,t:1527268939741};\\\", \\\"{x:1453,y:599,t:1527268939758};\\\", \\\"{x:1454,y:602,t:1527268939775};\\\", \\\"{x:1456,y:607,t:1527268939792};\\\", \\\"{x:1457,y:612,t:1527268939807};\\\", \\\"{x:1458,y:616,t:1527268939825};\\\", \\\"{x:1460,y:620,t:1527268939841};\\\", \\\"{x:1461,y:625,t:1527268939858};\\\", \\\"{x:1462,y:628,t:1527268939875};\\\", \\\"{x:1463,y:632,t:1527268939891};\\\", \\\"{x:1463,y:638,t:1527268939908};\\\", \\\"{x:1464,y:641,t:1527268939925};\\\", \\\"{x:1464,y:642,t:1527268939942};\\\", \\\"{x:1465,y:646,t:1527268939958};\\\", \\\"{x:1465,y:649,t:1527268939975};\\\", \\\"{x:1467,y:656,t:1527268939994};\\\", \\\"{x:1468,y:660,t:1527268940007};\\\", \\\"{x:1468,y:663,t:1527268940024};\\\", \\\"{x:1469,y:667,t:1527268940041};\\\", \\\"{x:1472,y:671,t:1527268940057};\\\", \\\"{x:1473,y:677,t:1527268940075};\\\", \\\"{x:1480,y:686,t:1527268940092};\\\", \\\"{x:1482,y:693,t:1527268940107};\\\", \\\"{x:1484,y:698,t:1527268940124};\\\", \\\"{x:1485,y:702,t:1527268940141};\\\", \\\"{x:1486,y:706,t:1527268940157};\\\", \\\"{x:1488,y:709,t:1527268940175};\\\", \\\"{x:1490,y:713,t:1527268940191};\\\", \\\"{x:1491,y:714,t:1527268940207};\\\", \\\"{x:1491,y:716,t:1527268940224};\\\", \\\"{x:1491,y:717,t:1527268940241};\\\", \\\"{x:1491,y:719,t:1527268940257};\\\", \\\"{x:1491,y:721,t:1527268940274};\\\", \\\"{x:1492,y:723,t:1527268940292};\\\", \\\"{x:1492,y:725,t:1527268940308};\\\", \\\"{x:1492,y:727,t:1527268940325};\\\", \\\"{x:1492,y:730,t:1527268940341};\\\", \\\"{x:1492,y:736,t:1527268940358};\\\", \\\"{x:1492,y:738,t:1527268940375};\\\", \\\"{x:1492,y:743,t:1527268940392};\\\", \\\"{x:1492,y:747,t:1527268940408};\\\", \\\"{x:1492,y:751,t:1527268940424};\\\", \\\"{x:1492,y:753,t:1527268940442};\\\", \\\"{x:1492,y:755,t:1527268940458};\\\", \\\"{x:1491,y:756,t:1527268940474};\\\", \\\"{x:1491,y:757,t:1527268940491};\\\", \\\"{x:1491,y:758,t:1527268940576};\\\", \\\"{x:1491,y:759,t:1527268940592};\\\", \\\"{x:1491,y:760,t:1527268940609};\\\", \\\"{x:1491,y:761,t:1527268940625};\\\", \\\"{x:1491,y:763,t:1527268940641};\\\", \\\"{x:1491,y:764,t:1527268940659};\\\", \\\"{x:1491,y:765,t:1527268940675};\\\", \\\"{x:1491,y:766,t:1527268940692};\\\", \\\"{x:1491,y:767,t:1527268940719};\\\", \\\"{x:1491,y:768,t:1527268940735};\\\", \\\"{x:1491,y:769,t:1527268940751};\\\", \\\"{x:1491,y:770,t:1527268940791};\\\", \\\"{x:1491,y:771,t:1527268940808};\\\", \\\"{x:1491,y:772,t:1527268940825};\\\", \\\"{x:1491,y:773,t:1527268940871};\\\", \\\"{x:1491,y:774,t:1527268940887};\\\", \\\"{x:1491,y:775,t:1527268940944};\\\", \\\"{x:1491,y:776,t:1527268941296};\\\", \\\"{x:1491,y:777,t:1527268941657};\\\", \\\"{x:1493,y:777,t:1527268941880};\\\", \\\"{x:1494,y:777,t:1527268941892};\\\", \\\"{x:1498,y:777,t:1527268941909};\\\", \\\"{x:1501,y:777,t:1527268941925};\\\", \\\"{x:1504,y:777,t:1527268941942};\\\", \\\"{x:1506,y:776,t:1527268941960};\\\", \\\"{x:1507,y:776,t:1527268941976};\\\", \\\"{x:1508,y:775,t:1527268942000};\\\", \\\"{x:1509,y:775,t:1527268942016};\\\", \\\"{x:1509,y:774,t:1527268942026};\\\", \\\"{x:1510,y:774,t:1527268942043};\\\", \\\"{x:1513,y:774,t:1527268942060};\\\", \\\"{x:1515,y:774,t:1527268942076};\\\", \\\"{x:1518,y:774,t:1527268942093};\\\", \\\"{x:1520,y:774,t:1527268942110};\\\", \\\"{x:1525,y:774,t:1527268942126};\\\", \\\"{x:1527,y:774,t:1527268942144};\\\", \\\"{x:1531,y:774,t:1527268942160};\\\", \\\"{x:1533,y:774,t:1527268942177};\\\", \\\"{x:1534,y:774,t:1527268942193};\\\", \\\"{x:1536,y:774,t:1527268942215};\\\", \\\"{x:1537,y:774,t:1527268942232};\\\", \\\"{x:1538,y:774,t:1527268942243};\\\", \\\"{x:1541,y:774,t:1527268942260};\\\", \\\"{x:1543,y:774,t:1527268942277};\\\", \\\"{x:1544,y:774,t:1527268942293};\\\", \\\"{x:1546,y:774,t:1527268942310};\\\", \\\"{x:1547,y:774,t:1527268942328};\\\", \\\"{x:1549,y:774,t:1527268942343};\\\", \\\"{x:1550,y:774,t:1527268942384};\\\", \\\"{x:1548,y:774,t:1527268943000};\\\", \\\"{x:1546,y:775,t:1527268943010};\\\", \\\"{x:1540,y:775,t:1527268943027};\\\", \\\"{x:1534,y:776,t:1527268943044};\\\", \\\"{x:1531,y:776,t:1527268943061};\\\", \\\"{x:1528,y:776,t:1527268943077};\\\", \\\"{x:1527,y:776,t:1527268943094};\\\", \\\"{x:1525,y:776,t:1527268943111};\\\", \\\"{x:1524,y:776,t:1527268943127};\\\", \\\"{x:1522,y:776,t:1527268943144};\\\", \\\"{x:1520,y:776,t:1527268943161};\\\", \\\"{x:1515,y:779,t:1527268943178};\\\", \\\"{x:1512,y:779,t:1527268943194};\\\", \\\"{x:1505,y:779,t:1527268943211};\\\", \\\"{x:1497,y:779,t:1527268943227};\\\", \\\"{x:1486,y:780,t:1527268943244};\\\", \\\"{x:1479,y:781,t:1527268943261};\\\", \\\"{x:1471,y:783,t:1527268943279};\\\", \\\"{x:1465,y:784,t:1527268943294};\\\", \\\"{x:1462,y:784,t:1527268943311};\\\", \\\"{x:1460,y:785,t:1527268943327};\\\", \\\"{x:1457,y:787,t:1527268943344};\\\", \\\"{x:1457,y:789,t:1527268943361};\\\", \\\"{x:1456,y:791,t:1527268943377};\\\", \\\"{x:1454,y:793,t:1527268943394};\\\", \\\"{x:1453,y:794,t:1527268943411};\\\", \\\"{x:1453,y:796,t:1527268943427};\\\", \\\"{x:1453,y:797,t:1527268943448};\\\", \\\"{x:1451,y:799,t:1527268943463};\\\", \\\"{x:1451,y:800,t:1527268943496};\\\", \\\"{x:1451,y:801,t:1527268943512};\\\", \\\"{x:1450,y:803,t:1527268943528};\\\", \\\"{x:1451,y:802,t:1527268943976};\\\", \\\"{x:1452,y:801,t:1527268943984};\\\", \\\"{x:1453,y:799,t:1527268943995};\\\", \\\"{x:1457,y:795,t:1527268944010};\\\", \\\"{x:1461,y:791,t:1527268944028};\\\", \\\"{x:1464,y:788,t:1527268944044};\\\", \\\"{x:1468,y:782,t:1527268944060};\\\", \\\"{x:1471,y:775,t:1527268944077};\\\", \\\"{x:1473,y:767,t:1527268944095};\\\", \\\"{x:1476,y:763,t:1527268944110};\\\", \\\"{x:1478,y:763,t:1527268944127};\\\", \\\"{x:1481,y:761,t:1527268944144};\\\", \\\"{x:1483,y:760,t:1527268944160};\\\", \\\"{x:1484,y:759,t:1527268944178};\\\", \\\"{x:1485,y:759,t:1527268944195};\\\", \\\"{x:1488,y:758,t:1527268944211};\\\", \\\"{x:1491,y:756,t:1527268944228};\\\", \\\"{x:1492,y:755,t:1527268944245};\\\", \\\"{x:1495,y:755,t:1527268944261};\\\", \\\"{x:1497,y:753,t:1527268944278};\\\", \\\"{x:1500,y:751,t:1527268944295};\\\", \\\"{x:1502,y:749,t:1527268944311};\\\", \\\"{x:1506,y:746,t:1527268944328};\\\", \\\"{x:1508,y:745,t:1527268944345};\\\", \\\"{x:1509,y:745,t:1527268944362};\\\", \\\"{x:1511,y:743,t:1527268944378};\\\", \\\"{x:1512,y:742,t:1527268944395};\\\", \\\"{x:1513,y:741,t:1527268944412};\\\", \\\"{x:1514,y:740,t:1527268944428};\\\", \\\"{x:1516,y:738,t:1527268944445};\\\", \\\"{x:1517,y:736,t:1527268944463};\\\", \\\"{x:1518,y:736,t:1527268944478};\\\", \\\"{x:1519,y:735,t:1527268944495};\\\", \\\"{x:1521,y:733,t:1527268944512};\\\", \\\"{x:1522,y:731,t:1527268944528};\\\", \\\"{x:1522,y:729,t:1527268944552};\\\", \\\"{x:1523,y:729,t:1527268944562};\\\", \\\"{x:1524,y:728,t:1527268944579};\\\", \\\"{x:1525,y:727,t:1527268944600};\\\", \\\"{x:1526,y:726,t:1527268944616};\\\", \\\"{x:1527,y:726,t:1527268944656};\\\", \\\"{x:1526,y:724,t:1527268945454};\\\", \\\"{x:1525,y:724,t:1527268945470};\\\", \\\"{x:1524,y:724,t:1527268945487};\\\", \\\"{x:1523,y:724,t:1527268945502};\\\", \\\"{x:1521,y:724,t:1527268945511};\\\", \\\"{x:1520,y:724,t:1527268945528};\\\", \\\"{x:1517,y:724,t:1527268945545};\\\", \\\"{x:1511,y:723,t:1527268945562};\\\", \\\"{x:1498,y:722,t:1527268945578};\\\", \\\"{x:1473,y:718,t:1527268945595};\\\", \\\"{x:1444,y:713,t:1527268945611};\\\", \\\"{x:1408,y:709,t:1527268945628};\\\", \\\"{x:1361,y:703,t:1527268945645};\\\", \\\"{x:1313,y:695,t:1527268945662};\\\", \\\"{x:1260,y:689,t:1527268945678};\\\", \\\"{x:1184,y:674,t:1527268945695};\\\", \\\"{x:1149,y:667,t:1527268945713};\\\", \\\"{x:1119,y:664,t:1527268945729};\\\", \\\"{x:1103,y:659,t:1527268945746};\\\", \\\"{x:1089,y:654,t:1527268945763};\\\", \\\"{x:1080,y:652,t:1527268945779};\\\", \\\"{x:1071,y:652,t:1527268945796};\\\", \\\"{x:1067,y:651,t:1527268945813};\\\", \\\"{x:1060,y:650,t:1527268945829};\\\", \\\"{x:1053,y:648,t:1527268945847};\\\", \\\"{x:1046,y:647,t:1527268945862};\\\", \\\"{x:1038,y:646,t:1527268945878};\\\", \\\"{x:1023,y:642,t:1527268945896};\\\", \\\"{x:1023,y:641,t:1527268946265};\\\", \\\"{x:1020,y:640,t:1527268946287};\\\", \\\"{x:1009,y:638,t:1527268946296};\\\", \\\"{x:968,y:631,t:1527268946313};\\\", \\\"{x:947,y:631,t:1527268946330};\\\", \\\"{x:892,y:630,t:1527268946346};\\\", \\\"{x:851,y:626,t:1527268946363};\\\", \\\"{x:805,y:623,t:1527268946380};\\\", \\\"{x:763,y:623,t:1527268946396};\\\", \\\"{x:725,y:623,t:1527268946413};\\\", \\\"{x:700,y:623,t:1527268946430};\\\", \\\"{x:679,y:618,t:1527268946446};\\\", \\\"{x:660,y:618,t:1527268946463};\\\", \\\"{x:634,y:618,t:1527268946480};\\\", \\\"{x:612,y:618,t:1527268946496};\\\", \\\"{x:594,y:618,t:1527268946513};\\\", \\\"{x:573,y:619,t:1527268946530};\\\", \\\"{x:558,y:620,t:1527268946546};\\\", \\\"{x:544,y:624,t:1527268946563};\\\", \\\"{x:532,y:625,t:1527268946580};\\\", \\\"{x:522,y:630,t:1527268946597};\\\", \\\"{x:513,y:637,t:1527268946613};\\\", \\\"{x:508,y:645,t:1527268946630};\\\", \\\"{x:504,y:653,t:1527268946647};\\\", \\\"{x:501,y:659,t:1527268946662};\\\", \\\"{x:500,y:661,t:1527268946680};\\\", \\\"{x:499,y:663,t:1527268946697};\\\", \\\"{x:498,y:666,t:1527268946713};\\\", \\\"{x:498,y:667,t:1527268946731};\\\", \\\"{x:498,y:669,t:1527268946747};\\\", \\\"{x:498,y:670,t:1527268946775};\\\", \\\"{x:497,y:672,t:1527268946798};\\\", \\\"{x:497,y:673,t:1527268946846};\\\", \\\"{x:497,y:673,t:1527268946930};\\\", \\\"{x:499,y:672,t:1527268947047};\\\", \\\"{x:505,y:669,t:1527268947063};\\\", \\\"{x:514,y:667,t:1527268947079};\\\", \\\"{x:522,y:665,t:1527268947097};\\\", \\\"{x:531,y:662,t:1527268947113};\\\", \\\"{x:539,y:659,t:1527268947129};\\\", \\\"{x:546,y:656,t:1527268947147};\\\", \\\"{x:553,y:654,t:1527268947164};\\\", \\\"{x:563,y:649,t:1527268947180};\\\", \\\"{x:571,y:644,t:1527268947197};\\\", \\\"{x:579,y:640,t:1527268947214};\\\", \\\"{x:586,y:636,t:1527268947230};\\\", \\\"{x:590,y:634,t:1527268947247};\\\", \\\"{x:591,y:633,t:1527268947263};\\\" ] }, { \\\"rt\\\": 9133, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 15, \\\"time_elapsed\\\": 499808, \\\"internal_node_id\\\": \\\"0.0-6.0-5.0\\\", \\\"subject\\\": \\\"YC7SX\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"mike\\\", \\\"condition\\\": \\\"115-late\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"starttime\\\", \\\"q\\\": 11, \\\"clicks\\\": 2, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XFull-YFull\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 1, \\\"answer\\\": [ \\\"F\\\", \\\"B\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-08 AM-12 PM-F \\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:595,y:635,t:1527268950456};\\\", \\\"{x:605,y:650,t:1527268950466};\\\", \\\"{x:625,y:674,t:1527268950483};\\\", \\\"{x:648,y:702,t:1527268950500};\\\", \\\"{x:668,y:722,t:1527268950516};\\\", \\\"{x:694,y:744,t:1527268950533};\\\", \\\"{x:726,y:766,t:1527268950550};\\\", \\\"{x:756,y:784,t:1527268950566};\\\", \\\"{x:792,y:805,t:1527268950584};\\\", \\\"{x:816,y:817,t:1527268950600};\\\", \\\"{x:839,y:827,t:1527268950616};\\\", \\\"{x:861,y:838,t:1527268950633};\\\", \\\"{x:887,y:850,t:1527268950650};\\\", \\\"{x:914,y:861,t:1527268950667};\\\", \\\"{x:947,y:876,t:1527268950683};\\\", \\\"{x:979,y:891,t:1527268950701};\\\", \\\"{x:1003,y:899,t:1527268950718};\\\", \\\"{x:1024,y:908,t:1527268950733};\\\", \\\"{x:1044,y:916,t:1527268950751};\\\", \\\"{x:1063,y:922,t:1527268950768};\\\", \\\"{x:1071,y:926,t:1527268950783};\\\", \\\"{x:1079,y:928,t:1527268950800};\\\", \\\"{x:1085,y:929,t:1527268950817};\\\", \\\"{x:1094,y:931,t:1527268950833};\\\", \\\"{x:1105,y:935,t:1527268950851};\\\", \\\"{x:1119,y:936,t:1527268950867};\\\", \\\"{x:1134,y:939,t:1527268950883};\\\", \\\"{x:1151,y:941,t:1527268950901};\\\", \\\"{x:1170,y:945,t:1527268950918};\\\", \\\"{x:1190,y:948,t:1527268950933};\\\", \\\"{x:1208,y:951,t:1527268950950};\\\", \\\"{x:1232,y:954,t:1527268950967};\\\", \\\"{x:1243,y:956,t:1527268950983};\\\", \\\"{x:1252,y:956,t:1527268951000};\\\", \\\"{x:1260,y:956,t:1527268951016};\\\", \\\"{x:1266,y:956,t:1527268951032};\\\", \\\"{x:1272,y:956,t:1527268951050};\\\", \\\"{x:1278,y:956,t:1527268951067};\\\", \\\"{x:1285,y:955,t:1527268951083};\\\", \\\"{x:1289,y:954,t:1527268951100};\\\", \\\"{x:1291,y:953,t:1527268951117};\\\", \\\"{x:1293,y:953,t:1527268951133};\\\", \\\"{x:1295,y:953,t:1527268951160};\\\", \\\"{x:1297,y:951,t:1527268951176};\\\", \\\"{x:1298,y:951,t:1527268951184};\\\", \\\"{x:1303,y:950,t:1527268951200};\\\", \\\"{x:1308,y:949,t:1527268951217};\\\", \\\"{x:1315,y:946,t:1527268951234};\\\", \\\"{x:1318,y:946,t:1527268951251};\\\", \\\"{x:1322,y:946,t:1527268951268};\\\", \\\"{x:1324,y:945,t:1527268951284};\\\", \\\"{x:1327,y:945,t:1527268951300};\\\", \\\"{x:1328,y:944,t:1527268951317};\\\", \\\"{x:1331,y:943,t:1527268951334};\\\", \\\"{x:1335,y:942,t:1527268951350};\\\", \\\"{x:1341,y:940,t:1527268951367};\\\", \\\"{x:1345,y:939,t:1527268951383};\\\", \\\"{x:1347,y:937,t:1527268951400};\\\", \\\"{x:1348,y:936,t:1527268951417};\\\", \\\"{x:1349,y:934,t:1527268951435};\\\", \\\"{x:1351,y:933,t:1527268951450};\\\", \\\"{x:1352,y:933,t:1527268951467};\\\", \\\"{x:1354,y:930,t:1527268951485};\\\", \\\"{x:1355,y:929,t:1527268951500};\\\", \\\"{x:1356,y:927,t:1527268951517};\\\", \\\"{x:1357,y:925,t:1527268951535};\\\", \\\"{x:1357,y:919,t:1527268951551};\\\", \\\"{x:1360,y:912,t:1527268951568};\\\", \\\"{x:1361,y:904,t:1527268951585};\\\", \\\"{x:1364,y:896,t:1527268951601};\\\", \\\"{x:1365,y:891,t:1527268951617};\\\", \\\"{x:1366,y:887,t:1527268951634};\\\", \\\"{x:1367,y:883,t:1527268951652};\\\", \\\"{x:1368,y:879,t:1527268951668};\\\", \\\"{x:1368,y:876,t:1527268951685};\\\", \\\"{x:1369,y:872,t:1527268951701};\\\", \\\"{x:1371,y:866,t:1527268951717};\\\", \\\"{x:1371,y:861,t:1527268951734};\\\", \\\"{x:1373,y:851,t:1527268951752};\\\", \\\"{x:1375,y:843,t:1527268951768};\\\", \\\"{x:1375,y:837,t:1527268951785};\\\", \\\"{x:1375,y:831,t:1527268951802};\\\", \\\"{x:1375,y:822,t:1527268951818};\\\", \\\"{x:1375,y:814,t:1527268951834};\\\", \\\"{x:1375,y:806,t:1527268951852};\\\", \\\"{x:1375,y:796,t:1527268951867};\\\", \\\"{x:1375,y:787,t:1527268951884};\\\", \\\"{x:1375,y:780,t:1527268951902};\\\", \\\"{x:1374,y:773,t:1527268951918};\\\", \\\"{x:1373,y:767,t:1527268951934};\\\", \\\"{x:1371,y:755,t:1527268951951};\\\", \\\"{x:1371,y:750,t:1527268951967};\\\", \\\"{x:1371,y:744,t:1527268951984};\\\", \\\"{x:1371,y:739,t:1527268952001};\\\", \\\"{x:1371,y:734,t:1527268952018};\\\", \\\"{x:1370,y:731,t:1527268952035};\\\", \\\"{x:1369,y:727,t:1527268952052};\\\", \\\"{x:1368,y:723,t:1527268952068};\\\", \\\"{x:1366,y:720,t:1527268952084};\\\", \\\"{x:1365,y:716,t:1527268952101};\\\", \\\"{x:1364,y:713,t:1527268952118};\\\", \\\"{x:1364,y:709,t:1527268952134};\\\", \\\"{x:1363,y:703,t:1527268952151};\\\", \\\"{x:1362,y:701,t:1527268952168};\\\", \\\"{x:1362,y:697,t:1527268952184};\\\", \\\"{x:1362,y:696,t:1527268952200};\\\", \\\"{x:1362,y:694,t:1527268952218};\\\", \\\"{x:1361,y:692,t:1527268952234};\\\", \\\"{x:1360,y:690,t:1527268952251};\\\", \\\"{x:1360,y:689,t:1527268952269};\\\", \\\"{x:1360,y:684,t:1527268952284};\\\", \\\"{x:1360,y:680,t:1527268952301};\\\", \\\"{x:1360,y:677,t:1527268952318};\\\", \\\"{x:1360,y:675,t:1527268952334};\\\", \\\"{x:1360,y:672,t:1527268952351};\\\", \\\"{x:1359,y:668,t:1527268952368};\\\", \\\"{x:1359,y:663,t:1527268952384};\\\", \\\"{x:1358,y:660,t:1527268952401};\\\", \\\"{x:1358,y:658,t:1527268952418};\\\", \\\"{x:1358,y:656,t:1527268952434};\\\", \\\"{x:1358,y:655,t:1527268952455};\\\", \\\"{x:1358,y:653,t:1527268952512};\\\", \\\"{x:1357,y:652,t:1527268952608};\\\", \\\"{x:1356,y:652,t:1527268952656};\\\", \\\"{x:1356,y:651,t:1527268952668};\\\", \\\"{x:1355,y:650,t:1527268952686};\\\", \\\"{x:1355,y:649,t:1527268952760};\\\", \\\"{x:1355,y:648,t:1527268952800};\\\", \\\"{x:1353,y:648,t:1527268953840};\\\", \\\"{x:1351,y:648,t:1527268953858};\\\", \\\"{x:1349,y:648,t:1527268953870};\\\", \\\"{x:1347,y:648,t:1527268953887};\\\", \\\"{x:1343,y:648,t:1527268953904};\\\", \\\"{x:1335,y:648,t:1527268953920};\\\", \\\"{x:1330,y:648,t:1527268953936};\\\", \\\"{x:1324,y:648,t:1527268953953};\\\", \\\"{x:1316,y:648,t:1527268953969};\\\", \\\"{x:1309,y:648,t:1527268953986};\\\", \\\"{x:1304,y:648,t:1527268954002};\\\", \\\"{x:1299,y:648,t:1527268954019};\\\", \\\"{x:1292,y:648,t:1527268954037};\\\", \\\"{x:1284,y:648,t:1527268954053};\\\", \\\"{x:1273,y:648,t:1527268954069};\\\", \\\"{x:1262,y:648,t:1527268954086};\\\", \\\"{x:1249,y:648,t:1527268954103};\\\", \\\"{x:1233,y:648,t:1527268954120};\\\", \\\"{x:1219,y:648,t:1527268954136};\\\", \\\"{x:1205,y:648,t:1527268954152};\\\", \\\"{x:1190,y:648,t:1527268954169};\\\", \\\"{x:1172,y:648,t:1527268954187};\\\", \\\"{x:1152,y:646,t:1527268954202};\\\", \\\"{x:1123,y:646,t:1527268954219};\\\", \\\"{x:1085,y:646,t:1527268954237};\\\", \\\"{x:1046,y:646,t:1527268954254};\\\", \\\"{x:1006,y:646,t:1527268954269};\\\", \\\"{x:970,y:646,t:1527268954287};\\\", \\\"{x:925,y:646,t:1527268954304};\\\", \\\"{x:900,y:646,t:1527268954320};\\\", \\\"{x:885,y:645,t:1527268954337};\\\", \\\"{x:877,y:644,t:1527268954353};\\\", \\\"{x:870,y:643,t:1527268954370};\\\", \\\"{x:866,y:642,t:1527268954386};\\\", \\\"{x:861,y:642,t:1527268954403};\\\", \\\"{x:858,y:640,t:1527268954420};\\\", \\\"{x:853,y:640,t:1527268954436};\\\", \\\"{x:845,y:639,t:1527268954454};\\\", \\\"{x:831,y:637,t:1527268954469};\\\", \\\"{x:814,y:637,t:1527268954486};\\\", \\\"{x:779,y:636,t:1527268954503};\\\", \\\"{x:753,y:634,t:1527268954520};\\\", \\\"{x:725,y:628,t:1527268954537};\\\", \\\"{x:697,y:625,t:1527268954553};\\\", \\\"{x:674,y:620,t:1527268954569};\\\", \\\"{x:652,y:619,t:1527268954586};\\\", \\\"{x:632,y:619,t:1527268954604};\\\", \\\"{x:616,y:618,t:1527268954620};\\\", \\\"{x:605,y:618,t:1527268954636};\\\", \\\"{x:599,y:617,t:1527268954654};\\\", \\\"{x:591,y:615,t:1527268954670};\\\", \\\"{x:585,y:614,t:1527268954686};\\\", \\\"{x:569,y:613,t:1527268954703};\\\", \\\"{x:559,y:611,t:1527268954720};\\\", \\\"{x:547,y:609,t:1527268954737};\\\", \\\"{x:539,y:608,t:1527268954754};\\\", \\\"{x:526,y:606,t:1527268954770};\\\", \\\"{x:516,y:603,t:1527268954786};\\\", \\\"{x:501,y:599,t:1527268954803};\\\", \\\"{x:491,y:596,t:1527268954822};\\\", \\\"{x:480,y:593,t:1527268954836};\\\", \\\"{x:466,y:588,t:1527268954853};\\\", \\\"{x:446,y:582,t:1527268954869};\\\", \\\"{x:429,y:577,t:1527268954886};\\\", \\\"{x:413,y:572,t:1527268954902};\\\", \\\"{x:398,y:568,t:1527268954919};\\\", \\\"{x:392,y:567,t:1527268954936};\\\", \\\"{x:392,y:566,t:1527268954975};\\\", \\\"{x:394,y:565,t:1527268954986};\\\", \\\"{x:400,y:561,t:1527268955003};\\\", \\\"{x:408,y:558,t:1527268955020};\\\", \\\"{x:414,y:556,t:1527268955037};\\\", \\\"{x:420,y:552,t:1527268955053};\\\", \\\"{x:431,y:548,t:1527268955070};\\\", \\\"{x:449,y:541,t:1527268955087};\\\", \\\"{x:460,y:536,t:1527268955103};\\\", \\\"{x:469,y:532,t:1527268955120};\\\", \\\"{x:481,y:526,t:1527268955137};\\\", \\\"{x:489,y:523,t:1527268955153};\\\", \\\"{x:497,y:519,t:1527268955170};\\\", \\\"{x:500,y:519,t:1527268955189};\\\", \\\"{x:504,y:516,t:1527268955203};\\\", \\\"{x:509,y:515,t:1527268955220};\\\", \\\"{x:517,y:511,t:1527268955236};\\\", \\\"{x:528,y:507,t:1527268955254};\\\", \\\"{x:542,y:504,t:1527268955270};\\\", \\\"{x:564,y:499,t:1527268955287};\\\", \\\"{x:620,y:492,t:1527268955305};\\\", \\\"{x:667,y:482,t:1527268955320};\\\", \\\"{x:706,y:470,t:1527268955337};\\\", \\\"{x:731,y:462,t:1527268955355};\\\", \\\"{x:744,y:459,t:1527268955370};\\\", \\\"{x:747,y:458,t:1527268955387};\\\", \\\"{x:748,y:458,t:1527268955432};\\\", \\\"{x:749,y:457,t:1527268955440};\\\", \\\"{x:750,y:457,t:1527268955471};\\\", \\\"{x:751,y:457,t:1527268955568};\\\", \\\"{x:752,y:456,t:1527268955575};\\\", \\\"{x:754,y:455,t:1527268955589};\\\", \\\"{x:760,y:455,t:1527268955604};\\\", \\\"{x:773,y:455,t:1527268955621};\\\", \\\"{x:782,y:455,t:1527268955638};\\\", \\\"{x:802,y:455,t:1527268955655};\\\", \\\"{x:816,y:456,t:1527268955672};\\\", \\\"{x:827,y:457,t:1527268955689};\\\", \\\"{x:835,y:459,t:1527268955704};\\\", \\\"{x:838,y:459,t:1527268955721};\\\", \\\"{x:839,y:459,t:1527268955736};\\\", \\\"{x:839,y:460,t:1527268955999};\\\", \\\"{x:838,y:461,t:1527268956007};\\\", \\\"{x:836,y:462,t:1527268956021};\\\", \\\"{x:830,y:464,t:1527268956037};\\\", \\\"{x:822,y:467,t:1527268956054};\\\", \\\"{x:803,y:469,t:1527268956070};\\\", \\\"{x:788,y:472,t:1527268956087};\\\", \\\"{x:773,y:477,t:1527268956103};\\\", \\\"{x:758,y:479,t:1527268956121};\\\", \\\"{x:743,y:483,t:1527268956137};\\\", \\\"{x:722,y:487,t:1527268956155};\\\", \\\"{x:698,y:493,t:1527268956171};\\\", \\\"{x:669,y:498,t:1527268956187};\\\", \\\"{x:627,y:504,t:1527268956204};\\\", \\\"{x:588,y:509,t:1527268956221};\\\", \\\"{x:532,y:515,t:1527268956237};\\\", \\\"{x:474,y:515,t:1527268956254};\\\", \\\"{x:384,y:515,t:1527268956271};\\\", \\\"{x:318,y:510,t:1527268956288};\\\", \\\"{x:257,y:503,t:1527268956304};\\\", \\\"{x:214,y:500,t:1527268956321};\\\", \\\"{x:195,y:500,t:1527268956338};\\\", \\\"{x:186,y:500,t:1527268956353};\\\", \\\"{x:184,y:499,t:1527268956371};\\\", \\\"{x:182,y:497,t:1527268956511};\\\", \\\"{x:181,y:497,t:1527268956520};\\\", \\\"{x:179,y:495,t:1527268956538};\\\", \\\"{x:178,y:493,t:1527268956553};\\\", \\\"{x:177,y:492,t:1527268956570};\\\", \\\"{x:176,y:491,t:1527268956588};\\\", \\\"{x:172,y:489,t:1527268956605};\\\", \\\"{x:170,y:488,t:1527268956621};\\\", \\\"{x:172,y:488,t:1527268956766};\\\", \\\"{x:173,y:488,t:1527268956775};\\\", \\\"{x:176,y:488,t:1527268956788};\\\", \\\"{x:177,y:488,t:1527268956805};\\\", \\\"{x:184,y:492,t:1527268956821};\\\", \\\"{x:189,y:494,t:1527268956837};\\\", \\\"{x:196,y:499,t:1527268956855};\\\", \\\"{x:205,y:507,t:1527268956871};\\\", \\\"{x:212,y:515,t:1527268956889};\\\", \\\"{x:222,y:522,t:1527268956905};\\\", \\\"{x:239,y:538,t:1527268956921};\\\", \\\"{x:260,y:549,t:1527268956939};\\\", \\\"{x:283,y:558,t:1527268956955};\\\", \\\"{x:315,y:574,t:1527268956971};\\\", \\\"{x:349,y:590,t:1527268956989};\\\", \\\"{x:381,y:608,t:1527268957005};\\\", \\\"{x:414,y:628,t:1527268957022};\\\", \\\"{x:478,y:669,t:1527268957059};\\\", \\\"{x:494,y:679,t:1527268957071};\\\", \\\"{x:501,y:683,t:1527268957088};\\\", \\\"{x:502,y:684,t:1527268957143};\\\", \\\"{x:503,y:684,t:1527268957154};\\\", \\\"{x:503,y:686,t:1527268957171};\\\", \\\"{x:504,y:688,t:1527268957188};\\\", \\\"{x:504,y:689,t:1527268957205};\\\", \\\"{x:505,y:689,t:1527268957221};\\\", \\\"{x:506,y:689,t:1527268957534};\\\", \\\"{x:508,y:689,t:1527268957543};\\\", \\\"{x:509,y:689,t:1527268957555};\\\", \\\"{x:512,y:689,t:1527268957572};\\\", \\\"{x:514,y:689,t:1527268957664};\\\", \\\"{x:515,y:689,t:1527268957672};\\\", \\\"{x:519,y:688,t:1527268957689};\\\", \\\"{x:527,y:688,t:1527268957705};\\\", \\\"{x:540,y:685,t:1527268957722};\\\", \\\"{x:557,y:683,t:1527268957740};\\\", \\\"{x:579,y:680,t:1527268957755};\\\", \\\"{x:601,y:678,t:1527268957772};\\\", \\\"{x:620,y:677,t:1527268957790};\\\", \\\"{x:633,y:674,t:1527268957805};\\\", \\\"{x:641,y:674,t:1527268957823};\\\", \\\"{x:651,y:674,t:1527268957839};\\\", \\\"{x:655,y:674,t:1527268957855};\\\", \\\"{x:660,y:673,t:1527268957872};\\\", \\\"{x:664,y:673,t:1527268957889};\\\", \\\"{x:667,y:673,t:1527268957906};\\\", \\\"{x:671,y:673,t:1527268957922};\\\", \\\"{x:674,y:673,t:1527268957939};\\\", \\\"{x:680,y:673,t:1527268957957};\\\", \\\"{x:689,y:674,t:1527268957972};\\\", \\\"{x:700,y:675,t:1527268957989};\\\", \\\"{x:714,y:678,t:1527268958006};\\\", \\\"{x:727,y:679,t:1527268958022};\\\", \\\"{x:742,y:681,t:1527268958039};\\\", \\\"{x:748,y:683,t:1527268958056};\\\", \\\"{x:751,y:684,t:1527268958072};\\\", \\\"{x:752,y:684,t:1527268958090};\\\", \\\"{x:753,y:684,t:1527268958127};\\\", \\\"{x:754,y:684,t:1527268958139};\\\", \\\"{x:752,y:685,t:1527268958191};\\\", \\\"{x:749,y:687,t:1527268958206};\\\", \\\"{x:746,y:689,t:1527268958222};\\\", \\\"{x:740,y:692,t:1527268958239};\\\", \\\"{x:738,y:693,t:1527268958256};\\\", \\\"{x:736,y:694,t:1527268958272};\\\", \\\"{x:734,y:694,t:1527268958311};\\\", \\\"{x:734,y:695,t:1527268958323};\\\", \\\"{x:733,y:695,t:1527268958339};\\\", \\\"{x:731,y:696,t:1527268958356};\\\", \\\"{x:729,y:697,t:1527268958372};\\\" ] }, { \\\"rt\\\": 14146, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 16, \\\"time_elapsed\\\": 515207, \\\"internal_node_id\\\": \\\"0.0-6.0-6.0\\\", \\\"subject\\\": \\\"YC7SX\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"mike\\\", \\\"condition\\\": \\\"115-late\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"starts\\\", \\\"q\\\": 12, \\\"clicks\\\": 2, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XFull-YFull\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 0, \\\"answer\\\": [ \\\"F\\\", \\\"B\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"\\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:729,y:698,t:1527268961256};\\\", \\\"{x:729,y:700,t:1527268965462};\\\", \\\"{x:728,y:700,t:1527268965511};\\\", \\\"{x:727,y:701,t:1527268965623};\\\", \\\"{x:726,y:701,t:1527268967952};\\\", \\\"{x:724,y:701,t:1527268968103};\\\", \\\"{x:727,y:701,t:1527268968808};\\\", \\\"{x:732,y:698,t:1527268968815};\\\", \\\"{x:750,y:682,t:1527268968831};\\\", \\\"{x:774,y:663,t:1527268968848};\\\", \\\"{x:794,y:647,t:1527268968865};\\\", \\\"{x:811,y:632,t:1527268968881};\\\", \\\"{x:824,y:613,t:1527268968898};\\\", \\\"{x:833,y:598,t:1527268968915};\\\", \\\"{x:841,y:578,t:1527268968933};\\\", \\\"{x:844,y:560,t:1527268968948};\\\", \\\"{x:844,y:535,t:1527268968981};\\\", \\\"{x:844,y:521,t:1527268968997};\\\", \\\"{x:846,y:507,t:1527268969015};\\\", \\\"{x:846,y:499,t:1527268969032};\\\", \\\"{x:846,y:491,t:1527268969047};\\\", \\\"{x:844,y:487,t:1527268969065};\\\", \\\"{x:842,y:480,t:1527268969082};\\\", \\\"{x:842,y:475,t:1527268969097};\\\", \\\"{x:841,y:471,t:1527268969115};\\\", \\\"{x:841,y:468,t:1527268969132};\\\", \\\"{x:841,y:465,t:1527268969148};\\\", \\\"{x:840,y:461,t:1527268969165};\\\", \\\"{x:840,y:459,t:1527268969181};\\\", \\\"{x:839,y:454,t:1527268969198};\\\", \\\"{x:839,y:451,t:1527268969214};\\\", \\\"{x:838,y:450,t:1527268969231};\\\", \\\"{x:836,y:450,t:1527268969447};\\\", \\\"{x:830,y:450,t:1527268969454};\\\", \\\"{x:825,y:450,t:1527268969465};\\\", \\\"{x:817,y:450,t:1527268969482};\\\", \\\"{x:806,y:450,t:1527268969498};\\\", \\\"{x:787,y:452,t:1527268969515};\\\", \\\"{x:764,y:454,t:1527268969532};\\\", \\\"{x:723,y:459,t:1527268969549};\\\", \\\"{x:686,y:459,t:1527268969565};\\\", \\\"{x:658,y:460,t:1527268969582};\\\", \\\"{x:614,y:462,t:1527268969599};\\\", \\\"{x:585,y:464,t:1527268969614};\\\", \\\"{x:557,y:464,t:1527268969631};\\\", \\\"{x:527,y:465,t:1527268969649};\\\", \\\"{x:503,y:465,t:1527268969665};\\\", \\\"{x:476,y:465,t:1527268969681};\\\", \\\"{x:455,y:465,t:1527268969698};\\\", \\\"{x:432,y:467,t:1527268969715};\\\", \\\"{x:405,y:467,t:1527268969732};\\\", \\\"{x:375,y:470,t:1527268969749};\\\", \\\"{x:357,y:472,t:1527268969767};\\\", \\\"{x:336,y:472,t:1527268969781};\\\", \\\"{x:314,y:473,t:1527268969798};\\\", \\\"{x:301,y:476,t:1527268969815};\\\", \\\"{x:293,y:476,t:1527268969832};\\\", \\\"{x:286,y:476,t:1527268969849};\\\", \\\"{x:276,y:476,t:1527268969866};\\\", \\\"{x:260,y:476,t:1527268969883};\\\", \\\"{x:240,y:476,t:1527268969898};\\\", \\\"{x:222,y:476,t:1527268969915};\\\", \\\"{x:212,y:476,t:1527268969932};\\\", \\\"{x:203,y:476,t:1527268969949};\\\", \\\"{x:200,y:476,t:1527268969966};\\\", \\\"{x:198,y:476,t:1527268969982};\\\", \\\"{x:193,y:476,t:1527268969998};\\\", \\\"{x:188,y:476,t:1527268970016};\\\", \\\"{x:183,y:476,t:1527268970031};\\\", \\\"{x:177,y:476,t:1527268970048};\\\", \\\"{x:173,y:476,t:1527268970065};\\\", \\\"{x:167,y:476,t:1527268970081};\\\", \\\"{x:165,y:476,t:1527268970098};\\\", \\\"{x:164,y:476,t:1527268970223};\\\", \\\"{x:163,y:476,t:1527268970232};\\\", \\\"{x:162,y:476,t:1527268970263};\\\", \\\"{x:160,y:476,t:1527268970279};\\\", \\\"{x:160,y:477,t:1527268970287};\\\", \\\"{x:159,y:477,t:1527268970399};\\\", \\\"{x:159,y:478,t:1527268971960};\\\", \\\"{x:159,y:479,t:1527268971999};\\\", \\\"{x:160,y:479,t:1527268972023};\\\", \\\"{x:161,y:479,t:1527268972034};\\\", \\\"{x:162,y:480,t:1527268972055};\\\", \\\"{x:163,y:480,t:1527268972067};\\\", \\\"{x:167,y:485,t:1527268972083};\\\", \\\"{x:172,y:490,t:1527268972100};\\\", \\\"{x:179,y:499,t:1527268972117};\\\", \\\"{x:186,y:505,t:1527268972134};\\\", \\\"{x:198,y:519,t:1527268972151};\\\", \\\"{x:205,y:528,t:1527268972166};\\\", \\\"{x:216,y:545,t:1527268972184};\\\", \\\"{x:230,y:563,t:1527268972201};\\\", \\\"{x:252,y:579,t:1527268972217};\\\", \\\"{x:282,y:599,t:1527268972234};\\\", \\\"{x:314,y:618,t:1527268972251};\\\", \\\"{x:346,y:633,t:1527268972267};\\\", \\\"{x:375,y:645,t:1527268972283};\\\", \\\"{x:394,y:656,t:1527268972301};\\\", \\\"{x:414,y:665,t:1527268972317};\\\", \\\"{x:430,y:673,t:1527268972334};\\\", \\\"{x:445,y:678,t:1527268972351};\\\", \\\"{x:452,y:680,t:1527268972366};\\\", \\\"{x:457,y:680,t:1527268972384};\\\", \\\"{x:459,y:680,t:1527268972401};\\\", \\\"{x:460,y:680,t:1527268972417};\\\", \\\"{x:462,y:680,t:1527268972434};\\\", \\\"{x:463,y:680,t:1527268972454};\\\", \\\"{x:465,y:680,t:1527268972471};\\\", \\\"{x:466,y:680,t:1527268972484};\\\", \\\"{x:468,y:681,t:1527268972500};\\\", \\\"{x:469,y:681,t:1527268972518};\\\", \\\"{x:470,y:681,t:1527268972542};\\\", \\\"{x:471,y:682,t:1527268972575};\\\", \\\"{x:472,y:682,t:1527268972601};\\\", \\\"{x:472,y:682,t:1527268972790};\\\" ] }, { \\\"rt\\\": 25962, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 17, \\\"time_elapsed\\\": 542494, \\\"internal_node_id\\\": \\\"0.0-6.0-7.0\\\", \\\"subject\\\": \\\"YC7SX\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"mike\\\", \\\"condition\\\": \\\"115-late\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"meets\\\", \\\"q\\\": 13, \\\"clicks\\\": 2.5, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XFull-YFull\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 1, \\\"answer\\\": [ \\\"F\\\", \\\"X\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-F -Z -Z \\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:481,y:686,t:1527268981552};\\\", \\\"{x:505,y:692,t:1527268981569};\\\", \\\"{x:564,y:705,t:1527268981593};\\\", \\\"{x:590,y:713,t:1527268981602};\\\", \\\"{x:645,y:727,t:1527268981618};\\\", \\\"{x:737,y:755,t:1527268981641};\\\", \\\"{x:798,y:772,t:1527268981658};\\\", \\\"{x:862,y:791,t:1527268981675};\\\", \\\"{x:932,y:815,t:1527268981691};\\\", \\\"{x:994,y:832,t:1527268981708};\\\", \\\"{x:1049,y:846,t:1527268981726};\\\", \\\"{x:1097,y:855,t:1527268981741};\\\", \\\"{x:1139,y:861,t:1527268981758};\\\", \\\"{x:1188,y:868,t:1527268981774};\\\", \\\"{x:1215,y:872,t:1527268981791};\\\", \\\"{x:1243,y:875,t:1527268981809};\\\", \\\"{x:1272,y:880,t:1527268981826};\\\", \\\"{x:1300,y:883,t:1527268981841};\\\", \\\"{x:1329,y:883,t:1527268981858};\\\", \\\"{x:1356,y:883,t:1527268981875};\\\", \\\"{x:1378,y:883,t:1527268981891};\\\", \\\"{x:1394,y:877,t:1527268981909};\\\", \\\"{x:1408,y:871,t:1527268981925};\\\", \\\"{x:1418,y:866,t:1527268981941};\\\", \\\"{x:1431,y:850,t:1527268981959};\\\", \\\"{x:1443,y:837,t:1527268981975};\\\", \\\"{x:1459,y:826,t:1527268981991};\\\", \\\"{x:1476,y:820,t:1527268982009};\\\", \\\"{x:1491,y:812,t:1527268982025};\\\", \\\"{x:1503,y:804,t:1527268982042};\\\", \\\"{x:1514,y:798,t:1527268982058};\\\", \\\"{x:1523,y:794,t:1527268982076};\\\", \\\"{x:1537,y:788,t:1527268982092};\\\", \\\"{x:1549,y:780,t:1527268982109};\\\", \\\"{x:1562,y:773,t:1527268982126};\\\", \\\"{x:1575,y:764,t:1527268982143};\\\", \\\"{x:1586,y:758,t:1527268982159};\\\", \\\"{x:1595,y:748,t:1527268982175};\\\", \\\"{x:1597,y:741,t:1527268982193};\\\", \\\"{x:1599,y:730,t:1527268982209};\\\", \\\"{x:1607,y:718,t:1527268982225};\\\", \\\"{x:1614,y:702,t:1527268982243};\\\", \\\"{x:1621,y:684,t:1527268982259};\\\", \\\"{x:1627,y:666,t:1527268982275};\\\", \\\"{x:1631,y:654,t:1527268982292};\\\", \\\"{x:1631,y:650,t:1527268982309};\\\", \\\"{x:1633,y:646,t:1527268982326};\\\", \\\"{x:1633,y:645,t:1527268982416};\\\", \\\"{x:1632,y:645,t:1527268982487};\\\", \\\"{x:1630,y:645,t:1527268982494};\\\", \\\"{x:1629,y:647,t:1527268982508};\\\", \\\"{x:1624,y:653,t:1527268982525};\\\", \\\"{x:1622,y:666,t:1527268982542};\\\", \\\"{x:1622,y:678,t:1527268982559};\\\", \\\"{x:1622,y:686,t:1527268982575};\\\", \\\"{x:1623,y:697,t:1527268982593};\\\", \\\"{x:1626,y:704,t:1527268982609};\\\", \\\"{x:1627,y:711,t:1527268982625};\\\", \\\"{x:1631,y:719,t:1527268982642};\\\", \\\"{x:1632,y:726,t:1527268982659};\\\", \\\"{x:1636,y:734,t:1527268982676};\\\", \\\"{x:1638,y:739,t:1527268982692};\\\", \\\"{x:1640,y:743,t:1527268982710};\\\", \\\"{x:1642,y:747,t:1527268982725};\\\", \\\"{x:1643,y:752,t:1527268982743};\\\", \\\"{x:1643,y:756,t:1527268982759};\\\", \\\"{x:1643,y:762,t:1527268982775};\\\", \\\"{x:1643,y:768,t:1527268982793};\\\", \\\"{x:1643,y:776,t:1527268982810};\\\", \\\"{x:1643,y:786,t:1527268982825};\\\", \\\"{x:1643,y:796,t:1527268982843};\\\", \\\"{x:1642,y:807,t:1527268982860};\\\", \\\"{x:1641,y:815,t:1527268982876};\\\", \\\"{x:1640,y:820,t:1527268982893};\\\", \\\"{x:1639,y:824,t:1527268982910};\\\", \\\"{x:1639,y:827,t:1527268982928};\\\", \\\"{x:1639,y:830,t:1527268982943};\\\", \\\"{x:1638,y:834,t:1527268982959};\\\", \\\"{x:1637,y:837,t:1527268982977};\\\", \\\"{x:1637,y:840,t:1527268982993};\\\", \\\"{x:1637,y:845,t:1527268983009};\\\", \\\"{x:1634,y:849,t:1527268983027};\\\", \\\"{x:1634,y:856,t:1527268983042};\\\", \\\"{x:1631,y:862,t:1527268983060};\\\", \\\"{x:1629,y:870,t:1527268983077};\\\", \\\"{x:1625,y:878,t:1527268983093};\\\", \\\"{x:1621,y:886,t:1527268983110};\\\", \\\"{x:1617,y:897,t:1527268983127};\\\", \\\"{x:1617,y:899,t:1527268983143};\\\", \\\"{x:1616,y:902,t:1527268983160};\\\", \\\"{x:1616,y:903,t:1527268983177};\\\", \\\"{x:1616,y:904,t:1527268983192};\\\", \\\"{x:1616,y:905,t:1527268983210};\\\", \\\"{x:1614,y:907,t:1527268983227};\\\", \\\"{x:1614,y:908,t:1527268983243};\\\", \\\"{x:1614,y:909,t:1527268986760};\\\", \\\"{x:1612,y:909,t:1527268986768};\\\", \\\"{x:1606,y:909,t:1527268986779};\\\", \\\"{x:1591,y:907,t:1527268986797};\\\", \\\"{x:1570,y:902,t:1527268986813};\\\", \\\"{x:1546,y:900,t:1527268986829};\\\", \\\"{x:1523,y:897,t:1527268986846};\\\", \\\"{x:1495,y:892,t:1527268986864};\\\", \\\"{x:1480,y:890,t:1527268986879};\\\", \\\"{x:1469,y:889,t:1527268986896};\\\", \\\"{x:1461,y:887,t:1527268986913};\\\", \\\"{x:1455,y:887,t:1527268986930};\\\", \\\"{x:1451,y:885,t:1527268986946};\\\", \\\"{x:1445,y:884,t:1527268986963};\\\", \\\"{x:1436,y:882,t:1527268986980};\\\", \\\"{x:1420,y:877,t:1527268986997};\\\", \\\"{x:1406,y:873,t:1527268987013};\\\", \\\"{x:1383,y:868,t:1527268987030};\\\", \\\"{x:1358,y:861,t:1527268987046};\\\", \\\"{x:1317,y:850,t:1527268987063};\\\", \\\"{x:1292,y:843,t:1527268987079};\\\", \\\"{x:1273,y:838,t:1527268987096};\\\", \\\"{x:1262,y:834,t:1527268987113};\\\", \\\"{x:1254,y:831,t:1527268987130};\\\", \\\"{x:1250,y:829,t:1527268987146};\\\", \\\"{x:1249,y:828,t:1527268987163};\\\", \\\"{x:1246,y:827,t:1527268987180};\\\", \\\"{x:1246,y:826,t:1527268987198};\\\", \\\"{x:1245,y:825,t:1527268987215};\\\", \\\"{x:1244,y:825,t:1527268987230};\\\", \\\"{x:1243,y:823,t:1527268987246};\\\", \\\"{x:1231,y:819,t:1527268987264};\\\", \\\"{x:1216,y:814,t:1527268987280};\\\", \\\"{x:1200,y:809,t:1527268987297};\\\", \\\"{x:1181,y:801,t:1527268987313};\\\", \\\"{x:1156,y:792,t:1527268987330};\\\", \\\"{x:1129,y:782,t:1527268987346};\\\", \\\"{x:1091,y:770,t:1527268987363};\\\", \\\"{x:1057,y:759,t:1527268987380};\\\", \\\"{x:1022,y:746,t:1527268987397};\\\", \\\"{x:994,y:734,t:1527268987413};\\\", \\\"{x:975,y:726,t:1527268987430};\\\", \\\"{x:958,y:712,t:1527268987447};\\\", \\\"{x:954,y:702,t:1527268987463};\\\", \\\"{x:949,y:689,t:1527268987480};\\\", \\\"{x:946,y:680,t:1527268987497};\\\", \\\"{x:945,y:676,t:1527268987513};\\\", \\\"{x:942,y:671,t:1527268987530};\\\", \\\"{x:938,y:665,t:1527268987546};\\\", \\\"{x:934,y:662,t:1527268987563};\\\", \\\"{x:925,y:657,t:1527268987580};\\\", \\\"{x:911,y:652,t:1527268987597};\\\", \\\"{x:894,y:644,t:1527268987613};\\\", \\\"{x:871,y:637,t:1527268987630};\\\", \\\"{x:836,y:627,t:1527268987648};\\\", \\\"{x:814,y:625,t:1527268987663};\\\", \\\"{x:793,y:622,t:1527268987680};\\\", \\\"{x:791,y:622,t:1527268987696};\\\", \\\"{x:790,y:622,t:1527268987713};\\\", \\\"{x:789,y:620,t:1527268988039};\\\", \\\"{x:785,y:617,t:1527268988055};\\\", \\\"{x:774,y:613,t:1527268988063};\\\", \\\"{x:768,y:611,t:1527268988080};\\\", \\\"{x:766,y:611,t:1527268988096};\\\", \\\"{x:763,y:611,t:1527268988127};\\\", \\\"{x:761,y:611,t:1527268988135};\\\", \\\"{x:759,y:611,t:1527268988146};\\\", \\\"{x:755,y:610,t:1527268988163};\\\", \\\"{x:753,y:610,t:1527268988180};\\\", \\\"{x:750,y:608,t:1527268988198};\\\", \\\"{x:737,y:602,t:1527268988213};\\\", \\\"{x:722,y:594,t:1527268988230};\\\", \\\"{x:709,y:588,t:1527268988247};\\\", \\\"{x:705,y:585,t:1527268988263};\\\", \\\"{x:699,y:580,t:1527268988281};\\\", \\\"{x:692,y:576,t:1527268988298};\\\", \\\"{x:682,y:569,t:1527268988313};\\\", \\\"{x:669,y:564,t:1527268988331};\\\", \\\"{x:659,y:560,t:1527268988346};\\\", \\\"{x:656,y:560,t:1527268988363};\\\", \\\"{x:654,y:558,t:1527268988380};\\\", \\\"{x:653,y:557,t:1527268988439};\\\", \\\"{x:651,y:555,t:1527268988470};\\\", \\\"{x:651,y:554,t:1527268988480};\\\", \\\"{x:649,y:553,t:1527268988496};\\\", \\\"{x:646,y:550,t:1527268988514};\\\", \\\"{x:643,y:544,t:1527268988531};\\\", \\\"{x:639,y:540,t:1527268988547};\\\", \\\"{x:631,y:534,t:1527268988563};\\\", \\\"{x:622,y:525,t:1527268988580};\\\", \\\"{x:616,y:522,t:1527268988597};\\\", \\\"{x:615,y:521,t:1527268988613};\\\", \\\"{x:612,y:520,t:1527268988630};\\\", \\\"{x:611,y:519,t:1527268988647};\\\", \\\"{x:612,y:518,t:1527268992775};\\\", \\\"{x:617,y:517,t:1527268992785};\\\", \\\"{x:630,y:512,t:1527268992803};\\\", \\\"{x:647,y:508,t:1527268992818};\\\", \\\"{x:669,y:508,t:1527268992835};\\\", \\\"{x:698,y:510,t:1527268992850};\\\", \\\"{x:723,y:517,t:1527268992866};\\\", \\\"{x:739,y:522,t:1527268992883};\\\", \\\"{x:776,y:535,t:1527268992899};\\\", \\\"{x:815,y:547,t:1527268992917};\\\", \\\"{x:859,y:558,t:1527268992934};\\\", \\\"{x:922,y:573,t:1527268992950};\\\", \\\"{x:964,y:578,t:1527268992968};\\\", \\\"{x:1007,y:587,t:1527268992984};\\\", \\\"{x:1050,y:600,t:1527268993001};\\\", \\\"{x:1084,y:611,t:1527268993017};\\\", \\\"{x:1117,y:620,t:1527268993034};\\\", \\\"{x:1148,y:628,t:1527268993050};\\\", \\\"{x:1174,y:633,t:1527268993067};\\\", \\\"{x:1198,y:639,t:1527268993084};\\\", \\\"{x:1223,y:643,t:1527268993101};\\\", \\\"{x:1249,y:648,t:1527268993117};\\\", \\\"{x:1271,y:650,t:1527268993134};\\\", \\\"{x:1297,y:653,t:1527268993150};\\\", \\\"{x:1307,y:653,t:1527268993167};\\\", \\\"{x:1314,y:653,t:1527268993184};\\\", \\\"{x:1315,y:653,t:1527268993201};\\\", \\\"{x:1316,y:652,t:1527268993217};\\\", \\\"{x:1319,y:651,t:1527268993234};\\\", \\\"{x:1321,y:649,t:1527268993251};\\\", \\\"{x:1325,y:649,t:1527268993267};\\\", \\\"{x:1332,y:648,t:1527268993284};\\\", \\\"{x:1339,y:646,t:1527268993301};\\\", \\\"{x:1342,y:645,t:1527268993319};\\\", \\\"{x:1344,y:645,t:1527268993334};\\\", \\\"{x:1348,y:645,t:1527268993350};\\\", \\\"{x:1354,y:645,t:1527268993369};\\\", \\\"{x:1363,y:645,t:1527268993385};\\\", \\\"{x:1372,y:645,t:1527268993400};\\\", \\\"{x:1381,y:645,t:1527268993417};\\\", \\\"{x:1391,y:644,t:1527268993434};\\\", \\\"{x:1397,y:641,t:1527268993450};\\\", \\\"{x:1401,y:640,t:1527268993467};\\\", \\\"{x:1404,y:640,t:1527268993485};\\\", \\\"{x:1406,y:640,t:1527268993500};\\\", \\\"{x:1407,y:640,t:1527268993518};\\\", \\\"{x:1408,y:640,t:1527268993535};\\\", \\\"{x:1409,y:640,t:1527268993550};\\\", \\\"{x:1411,y:638,t:1527268993870};\\\", \\\"{x:1413,y:639,t:1527268994439};\\\", \\\"{x:1416,y:639,t:1527268994450};\\\", \\\"{x:1423,y:641,t:1527268994467};\\\", \\\"{x:1437,y:643,t:1527268994483};\\\", \\\"{x:1450,y:644,t:1527268994500};\\\", \\\"{x:1461,y:646,t:1527268994516};\\\", \\\"{x:1468,y:646,t:1527268994533};\\\", \\\"{x:1470,y:646,t:1527268994549};\\\", \\\"{x:1471,y:646,t:1527268994566};\\\", \\\"{x:1473,y:646,t:1527268994680};\\\", \\\"{x:1474,y:646,t:1527268994711};\\\", \\\"{x:1475,y:646,t:1527268994719};\\\", \\\"{x:1478,y:646,t:1527268994960};\\\", \\\"{x:1481,y:646,t:1527268994967};\\\", \\\"{x:1485,y:646,t:1527268994982};\\\", \\\"{x:1494,y:646,t:1527268994999};\\\", \\\"{x:1500,y:646,t:1527268995016};\\\", \\\"{x:1506,y:646,t:1527268995033};\\\", \\\"{x:1510,y:646,t:1527268995049};\\\", \\\"{x:1512,y:646,t:1527268995067};\\\", \\\"{x:1513,y:646,t:1527268995083};\\\", \\\"{x:1514,y:646,t:1527268995103};\\\", \\\"{x:1515,y:646,t:1527268995117};\\\", \\\"{x:1518,y:646,t:1527268995132};\\\", \\\"{x:1521,y:646,t:1527268995149};\\\", \\\"{x:1525,y:646,t:1527268995166};\\\", \\\"{x:1528,y:646,t:1527268995182};\\\", \\\"{x:1532,y:646,t:1527268995199};\\\", \\\"{x:1535,y:645,t:1527268995216};\\\", \\\"{x:1540,y:645,t:1527268995232};\\\", \\\"{x:1543,y:644,t:1527268995249};\\\", \\\"{x:1545,y:643,t:1527268995265};\\\", \\\"{x:1547,y:643,t:1527268995282};\\\", \\\"{x:1549,y:643,t:1527268995299};\\\", \\\"{x:1551,y:643,t:1527268995703};\\\", \\\"{x:1553,y:643,t:1527268995716};\\\", \\\"{x:1557,y:643,t:1527268995732};\\\", \\\"{x:1560,y:643,t:1527268995749};\\\", \\\"{x:1563,y:643,t:1527268995766};\\\", \\\"{x:1566,y:643,t:1527268995782};\\\", \\\"{x:1568,y:643,t:1527268995798};\\\", \\\"{x:1574,y:643,t:1527268995815};\\\", \\\"{x:1577,y:643,t:1527268995832};\\\", \\\"{x:1581,y:643,t:1527268995848};\\\", \\\"{x:1586,y:643,t:1527268995865};\\\", \\\"{x:1592,y:643,t:1527268995882};\\\", \\\"{x:1601,y:644,t:1527268995899};\\\", \\\"{x:1612,y:645,t:1527268995916};\\\", \\\"{x:1621,y:647,t:1527268995933};\\\", \\\"{x:1626,y:647,t:1527268995948};\\\", \\\"{x:1629,y:647,t:1527268995965};\\\", \\\"{x:1630,y:647,t:1527268996624};\\\", \\\"{x:1629,y:647,t:1527268997415};\\\", \\\"{x:1627,y:647,t:1527268997431};\\\", \\\"{x:1612,y:641,t:1527268997447};\\\", \\\"{x:1593,y:637,t:1527268997465};\\\", \\\"{x:1554,y:629,t:1527268997481};\\\", \\\"{x:1495,y:620,t:1527268997497};\\\", \\\"{x:1434,y:612,t:1527268997514};\\\", \\\"{x:1389,y:606,t:1527268997530};\\\", \\\"{x:1365,y:606,t:1527268997547};\\\", \\\"{x:1347,y:606,t:1527268997565};\\\", \\\"{x:1342,y:606,t:1527268997581};\\\", \\\"{x:1338,y:605,t:1527268997601};\\\", \\\"{x:1334,y:605,t:1527268997617};\\\", \\\"{x:1325,y:603,t:1527268997635};\\\", \\\"{x:1302,y:601,t:1527268997652};\\\", \\\"{x:1263,y:596,t:1527268997668};\\\", \\\"{x:1199,y:585,t:1527268997684};\\\", \\\"{x:1121,y:576,t:1527268997701};\\\", \\\"{x:1043,y:565,t:1527268997717};\\\", \\\"{x:968,y:553,t:1527268997734};\\\", \\\"{x:890,y:542,t:1527268997751};\\\", \\\"{x:827,y:530,t:1527268997768};\\\", \\\"{x:770,y:517,t:1527268997784};\\\", \\\"{x:733,y:510,t:1527268997800};\\\", \\\"{x:703,y:500,t:1527268997825};\\\", \\\"{x:699,y:499,t:1527268997842};\\\", \\\"{x:699,y:498,t:1527268997859};\\\", \\\"{x:699,y:497,t:1527268997890};\\\", \\\"{x:699,y:496,t:1527268997898};\\\", \\\"{x:701,y:493,t:1527268997909};\\\", \\\"{x:718,y:486,t:1527268997924};\\\", \\\"{x:737,y:477,t:1527268997942};\\\", \\\"{x:749,y:470,t:1527268997959};\\\", \\\"{x:756,y:466,t:1527268997974};\\\", \\\"{x:764,y:461,t:1527268997993};\\\", \\\"{x:769,y:459,t:1527268998008};\\\", \\\"{x:769,y:458,t:1527268998024};\\\", \\\"{x:771,y:458,t:1527268998042};\\\", \\\"{x:774,y:457,t:1527268998059};\\\", \\\"{x:776,y:456,t:1527268998075};\\\", \\\"{x:778,y:455,t:1527268998092};\\\", \\\"{x:781,y:454,t:1527268998109};\\\", \\\"{x:784,y:452,t:1527268998125};\\\", \\\"{x:787,y:451,t:1527268998142};\\\", \\\"{x:791,y:450,t:1527268998159};\\\", \\\"{x:795,y:448,t:1527268998176};\\\", \\\"{x:797,y:446,t:1527268998192};\\\", \\\"{x:800,y:445,t:1527268998209};\\\", \\\"{x:802,y:444,t:1527268998226};\\\", \\\"{x:803,y:444,t:1527268998242};\\\", \\\"{x:807,y:443,t:1527268998258};\\\", \\\"{x:810,y:441,t:1527268998276};\\\", \\\"{x:811,y:441,t:1527268998315};\\\", \\\"{x:812,y:441,t:1527268998326};\\\", \\\"{x:813,y:441,t:1527268998347};\\\", \\\"{x:815,y:441,t:1527268998359};\\\", \\\"{x:817,y:441,t:1527268998376};\\\", \\\"{x:818,y:441,t:1527268998392};\\\", \\\"{x:819,y:441,t:1527268998409};\\\", \\\"{x:820,y:441,t:1527268998426};\\\", \\\"{x:818,y:443,t:1527268998812};\\\", \\\"{x:817,y:443,t:1527268998827};\\\", \\\"{x:815,y:444,t:1527268998843};\\\", \\\"{x:813,y:444,t:1527268998860};\\\", \\\"{x:812,y:445,t:1527268998876};\\\", \\\"{x:813,y:446,t:1527268998963};\\\", \\\"{x:818,y:446,t:1527268998976};\\\", \\\"{x:826,y:448,t:1527268998994};\\\", \\\"{x:834,y:448,t:1527268999010};\\\", \\\"{x:837,y:448,t:1527268999026};\\\", \\\"{x:837,y:449,t:1527268999314};\\\", \\\"{x:833,y:452,t:1527268999325};\\\", \\\"{x:827,y:454,t:1527268999343};\\\", \\\"{x:813,y:459,t:1527268999360};\\\", \\\"{x:796,y:464,t:1527268999376};\\\", \\\"{x:774,y:468,t:1527268999393};\\\", \\\"{x:733,y:476,t:1527268999410};\\\", \\\"{x:706,y:487,t:1527268999427};\\\", \\\"{x:685,y:499,t:1527268999442};\\\", \\\"{x:665,y:511,t:1527268999460};\\\", \\\"{x:649,y:524,t:1527268999477};\\\", \\\"{x:635,y:536,t:1527268999493};\\\", \\\"{x:625,y:548,t:1527268999511};\\\", \\\"{x:621,y:556,t:1527268999526};\\\", \\\"{x:617,y:568,t:1527268999543};\\\", \\\"{x:613,y:581,t:1527268999561};\\\", \\\"{x:608,y:595,t:1527268999577};\\\", \\\"{x:607,y:612,t:1527268999592};\\\", \\\"{x:597,y:639,t:1527268999610};\\\", \\\"{x:591,y:653,t:1527268999626};\\\", \\\"{x:586,y:665,t:1527268999642};\\\", \\\"{x:580,y:679,t:1527268999661};\\\", \\\"{x:572,y:690,t:1527268999678};\\\", \\\"{x:569,y:699,t:1527268999693};\\\", \\\"{x:565,y:703,t:1527268999710};\\\", \\\"{x:564,y:703,t:1527268999727};\\\", \\\"{x:562,y:705,t:1527268999743};\\\", \\\"{x:560,y:706,t:1527268999760};\\\", \\\"{x:558,y:706,t:1527268999777};\\\", \\\"{x:553,y:705,t:1527268999793};\\\", \\\"{x:542,y:699,t:1527268999811};\\\", \\\"{x:530,y:693,t:1527268999827};\\\", \\\"{x:521,y:688,t:1527268999843};\\\", \\\"{x:517,y:685,t:1527268999860};\\\", \\\"{x:515,y:684,t:1527268999877};\\\", \\\"{x:514,y:683,t:1527268999894};\\\", \\\"{x:514,y:682,t:1527268999939};\\\", \\\"{x:512,y:680,t:1527269000094};\\\", \\\"{x:506,y:680,t:1527269000109};\\\", \\\"{x:505,y:679,t:1527269000127};\\\", \\\"{x:504,y:679,t:1527269000154};\\\" ] }, { \\\"rt\\\": 40559, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 18, \\\"time_elapsed\\\": 584411, \\\"internal_node_id\\\": \\\"0.0-6.0-8.0\\\", \\\"subject\\\": \\\"YC7SX\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"mike\\\", \\\"condition\\\": \\\"115-late\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"endtime\\\", \\\"q\\\": 14, \\\"clicks\\\": 1.5, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XFull-YFull\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 1, \\\"answer\\\": [ \\\"B\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-B -4-3-B -X -X -X -X \\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:507,y:679,t:1527269006803};\\\", \\\"{x:512,y:679,t:1527269006811};\\\", \\\"{x:517,y:678,t:1527269006825};\\\", \\\"{x:529,y:678,t:1527269006842};\\\", \\\"{x:543,y:678,t:1527269006858};\\\", \\\"{x:555,y:678,t:1527269006875};\\\", \\\"{x:570,y:680,t:1527269006893};\\\", \\\"{x:592,y:686,t:1527269006908};\\\", \\\"{x:613,y:691,t:1527269006925};\\\", \\\"{x:646,y:697,t:1527269006949};\\\", \\\"{x:673,y:699,t:1527269006965};\\\", \\\"{x:697,y:705,t:1527269006982};\\\", \\\"{x:723,y:709,t:1527269006999};\\\", \\\"{x:747,y:715,t:1527269007016};\\\", \\\"{x:771,y:717,t:1527269007032};\\\", \\\"{x:796,y:722,t:1527269007049};\\\", \\\"{x:833,y:725,t:1527269007065};\\\", \\\"{x:859,y:726,t:1527269007082};\\\", \\\"{x:883,y:726,t:1527269007099};\\\", \\\"{x:909,y:728,t:1527269007116};\\\", \\\"{x:931,y:732,t:1527269007132};\\\", \\\"{x:950,y:736,t:1527269007149};\\\", \\\"{x:964,y:737,t:1527269007166};\\\", \\\"{x:980,y:739,t:1527269007183};\\\", \\\"{x:996,y:741,t:1527269007200};\\\", \\\"{x:1009,y:743,t:1527269007217};\\\", \\\"{x:1018,y:744,t:1527269007233};\\\", \\\"{x:1026,y:744,t:1527269007249};\\\", \\\"{x:1034,y:744,t:1527269007266};\\\", \\\"{x:1038,y:744,t:1527269007282};\\\", \\\"{x:1042,y:744,t:1527269007300};\\\", \\\"{x:1047,y:744,t:1527269007316};\\\", \\\"{x:1052,y:744,t:1527269007333};\\\", \\\"{x:1059,y:744,t:1527269007350};\\\", \\\"{x:1067,y:744,t:1527269007367};\\\", \\\"{x:1077,y:744,t:1527269007383};\\\", \\\"{x:1087,y:744,t:1527269007400};\\\", \\\"{x:1097,y:744,t:1527269007417};\\\", \\\"{x:1112,y:742,t:1527269007433};\\\", \\\"{x:1130,y:742,t:1527269007450};\\\", \\\"{x:1156,y:742,t:1527269007468};\\\", \\\"{x:1175,y:742,t:1527269007483};\\\", \\\"{x:1195,y:742,t:1527269007500};\\\", \\\"{x:1212,y:742,t:1527269007517};\\\", \\\"{x:1230,y:742,t:1527269007534};\\\", \\\"{x:1243,y:742,t:1527269007550};\\\", \\\"{x:1254,y:742,t:1527269007567};\\\", \\\"{x:1262,y:742,t:1527269007584};\\\", \\\"{x:1265,y:742,t:1527269007599};\\\", \\\"{x:1266,y:742,t:1527269007616};\\\", \\\"{x:1267,y:742,t:1527269007634};\\\", \\\"{x:1267,y:741,t:1527269007651};\\\", \\\"{x:1268,y:741,t:1527269007667};\\\", \\\"{x:1272,y:740,t:1527269007684};\\\", \\\"{x:1276,y:739,t:1527269007700};\\\", \\\"{x:1281,y:737,t:1527269007717};\\\", \\\"{x:1285,y:737,t:1527269007734};\\\", \\\"{x:1293,y:737,t:1527269007750};\\\", \\\"{x:1300,y:735,t:1527269007767};\\\", \\\"{x:1305,y:734,t:1527269007784};\\\", \\\"{x:1309,y:733,t:1527269007800};\\\", \\\"{x:1311,y:733,t:1527269007817};\\\", \\\"{x:1312,y:733,t:1527269007884};\\\", \\\"{x:1314,y:733,t:1527269008851};\\\", \\\"{x:1315,y:732,t:1527269008868};\\\", \\\"{x:1317,y:731,t:1527269008884};\\\", \\\"{x:1319,y:731,t:1527269008901};\\\", \\\"{x:1321,y:731,t:1527269008918};\\\", \\\"{x:1322,y:730,t:1527269008934};\\\", \\\"{x:1324,y:729,t:1527269008951};\\\", \\\"{x:1325,y:729,t:1527269008971};\\\", \\\"{x:1327,y:729,t:1527269008985};\\\", \\\"{x:1328,y:728,t:1527269009000};\\\", \\\"{x:1329,y:727,t:1527269009017};\\\", \\\"{x:1332,y:727,t:1527269009035};\\\", \\\"{x:1333,y:727,t:1527269009051};\\\", \\\"{x:1334,y:727,t:1527269009068};\\\", \\\"{x:1335,y:726,t:1527269009085};\\\", \\\"{x:1337,y:725,t:1527269009101};\\\", \\\"{x:1337,y:724,t:1527269009118};\\\", \\\"{x:1338,y:724,t:1527269009135};\\\", \\\"{x:1339,y:724,t:1527269009151};\\\", \\\"{x:1340,y:723,t:1527269009171};\\\", \\\"{x:1341,y:723,t:1527269009186};\\\", \\\"{x:1342,y:723,t:1527269009202};\\\", \\\"{x:1343,y:722,t:1527269009218};\\\", \\\"{x:1344,y:721,t:1527269009235};\\\", \\\"{x:1345,y:721,t:1527269009251};\\\", \\\"{x:1347,y:720,t:1527269009275};\\\", \\\"{x:1348,y:718,t:1527269009379};\\\", \\\"{x:1349,y:718,t:1527269009402};\\\", \\\"{x:1349,y:717,t:1527269009419};\\\", \\\"{x:1350,y:717,t:1527269009467};\\\", \\\"{x:1350,y:716,t:1527269009507};\\\", \\\"{x:1350,y:715,t:1527269012318};\\\", \\\"{x:1342,y:711,t:1527269012336};\\\", \\\"{x:1326,y:705,t:1527269012354};\\\", \\\"{x:1300,y:697,t:1527269012369};\\\", \\\"{x:1222,y:675,t:1527269012386};\\\", \\\"{x:1164,y:660,t:1527269012403};\\\", \\\"{x:1106,y:645,t:1527269012420};\\\", \\\"{x:1058,y:637,t:1527269012437};\\\", \\\"{x:1016,y:630,t:1527269012454};\\\", \\\"{x:981,y:624,t:1527269012470};\\\", \\\"{x:945,y:616,t:1527269012486};\\\", \\\"{x:904,y:606,t:1527269012503};\\\", \\\"{x:879,y:600,t:1527269012519};\\\", \\\"{x:839,y:589,t:1527269012536};\\\", \\\"{x:795,y:579,t:1527269012553};\\\", \\\"{x:743,y:566,t:1527269012571};\\\", \\\"{x:645,y:545,t:1527269012587};\\\", \\\"{x:565,y:523,t:1527269012604};\\\", \\\"{x:483,y:504,t:1527269012620};\\\", \\\"{x:404,y:491,t:1527269012638};\\\", \\\"{x:326,y:465,t:1527269012654};\\\", \\\"{x:264,y:446,t:1527269012672};\\\", \\\"{x:222,y:435,t:1527269012687};\\\", \\\"{x:199,y:430,t:1527269012704};\\\", \\\"{x:179,y:425,t:1527269012721};\\\", \\\"{x:165,y:421,t:1527269012737};\\\", \\\"{x:158,y:418,t:1527269012753};\\\", \\\"{x:153,y:417,t:1527269012771};\\\", \\\"{x:152,y:417,t:1527269012788};\\\", \\\"{x:150,y:417,t:1527269012804};\\\", \\\"{x:148,y:418,t:1527269012826};\\\", \\\"{x:147,y:420,t:1527269012858};\\\", \\\"{x:145,y:422,t:1527269012874};\\\", \\\"{x:145,y:424,t:1527269012887};\\\", \\\"{x:143,y:430,t:1527269012904};\\\", \\\"{x:143,y:438,t:1527269012923};\\\", \\\"{x:143,y:446,t:1527269012938};\\\", \\\"{x:143,y:457,t:1527269012954};\\\", \\\"{x:143,y:465,t:1527269012971};\\\", \\\"{x:143,y:469,t:1527269012988};\\\", \\\"{x:143,y:472,t:1527269013005};\\\", \\\"{x:143,y:473,t:1527269013020};\\\", \\\"{x:144,y:473,t:1527269013037};\\\", \\\"{x:144,y:475,t:1527269013053};\\\", \\\"{x:144,y:478,t:1527269013071};\\\", \\\"{x:144,y:481,t:1527269013087};\\\", \\\"{x:144,y:485,t:1527269013103};\\\", \\\"{x:145,y:486,t:1527269013120};\\\", \\\"{x:145,y:488,t:1527269013138};\\\", \\\"{x:146,y:489,t:1527269013563};\\\", \\\"{x:148,y:489,t:1527269013578};\\\", \\\"{x:149,y:489,t:1527269013589};\\\", \\\"{x:151,y:488,t:1527269013604};\\\", \\\"{x:152,y:488,t:1527269013621};\\\", \\\"{x:154,y:488,t:1527269014154};\\\", \\\"{x:160,y:486,t:1527269014162};\\\", \\\"{x:164,y:486,t:1527269014172};\\\", \\\"{x:179,y:486,t:1527269014189};\\\", \\\"{x:198,y:486,t:1527269014206};\\\", \\\"{x:230,y:491,t:1527269014221};\\\", \\\"{x:285,y:504,t:1527269014241};\\\", \\\"{x:368,y:528,t:1527269014256};\\\", \\\"{x:481,y:559,t:1527269014272};\\\", \\\"{x:611,y:593,t:1527269014288};\\\", \\\"{x:749,y:634,t:1527269014306};\\\", \\\"{x:866,y:670,t:1527269014321};\\\", \\\"{x:939,y:688,t:1527269014338};\\\", \\\"{x:941,y:688,t:1527269015027};\\\", \\\"{x:946,y:687,t:1527269015039};\\\", \\\"{x:967,y:685,t:1527269015055};\\\", \\\"{x:983,y:692,t:1527269015072};\\\", \\\"{x:995,y:695,t:1527269015089};\\\", \\\"{x:1014,y:697,t:1527269015106};\\\", \\\"{x:1026,y:700,t:1527269015122};\\\", \\\"{x:1048,y:702,t:1527269015138};\\\", \\\"{x:1063,y:705,t:1527269015157};\\\", \\\"{x:1079,y:707,t:1527269015172};\\\", \\\"{x:1091,y:709,t:1527269015189};\\\", \\\"{x:1103,y:711,t:1527269015205};\\\", \\\"{x:1113,y:712,t:1527269015222};\\\", \\\"{x:1122,y:712,t:1527269015239};\\\", \\\"{x:1135,y:715,t:1527269015255};\\\", \\\"{x:1145,y:715,t:1527269015272};\\\", \\\"{x:1158,y:717,t:1527269015289};\\\", \\\"{x:1169,y:718,t:1527269015306};\\\", \\\"{x:1184,y:720,t:1527269015322};\\\", \\\"{x:1207,y:723,t:1527269015339};\\\", \\\"{x:1221,y:723,t:1527269015355};\\\", \\\"{x:1235,y:726,t:1527269015372};\\\", \\\"{x:1250,y:728,t:1527269015389};\\\", \\\"{x:1266,y:730,t:1527269015406};\\\", \\\"{x:1278,y:731,t:1527269015422};\\\", \\\"{x:1285,y:732,t:1527269015439};\\\", \\\"{x:1292,y:732,t:1527269015457};\\\", \\\"{x:1297,y:732,t:1527269015472};\\\", \\\"{x:1300,y:732,t:1527269015489};\\\", \\\"{x:1304,y:732,t:1527269015506};\\\", \\\"{x:1307,y:732,t:1527269015522};\\\", \\\"{x:1312,y:732,t:1527269015539};\\\", \\\"{x:1314,y:732,t:1527269015556};\\\", \\\"{x:1319,y:732,t:1527269015572};\\\", \\\"{x:1323,y:731,t:1527269015590};\\\", \\\"{x:1327,y:731,t:1527269015606};\\\", \\\"{x:1330,y:731,t:1527269015622};\\\", \\\"{x:1331,y:730,t:1527269015639};\\\", \\\"{x:1333,y:729,t:1527269015656};\\\", \\\"{x:1335,y:728,t:1527269015675};\\\", \\\"{x:1335,y:727,t:1527269015691};\\\", \\\"{x:1337,y:727,t:1527269015706};\\\", \\\"{x:1339,y:726,t:1527269015722};\\\", \\\"{x:1340,y:724,t:1527269015740};\\\", \\\"{x:1341,y:724,t:1527269015756};\\\", \\\"{x:1343,y:722,t:1527269015773};\\\", \\\"{x:1344,y:721,t:1527269015789};\\\", \\\"{x:1345,y:719,t:1527269015810};\\\", \\\"{x:1345,y:718,t:1527269015826};\\\", \\\"{x:1346,y:717,t:1527269015838};\\\", \\\"{x:1347,y:716,t:1527269015855};\\\", \\\"{x:1349,y:714,t:1527269015873};\\\", \\\"{x:1350,y:714,t:1527269015888};\\\", \\\"{x:1351,y:713,t:1527269015914};\\\", \\\"{x:1351,y:712,t:1527269015930};\\\", \\\"{x:1352,y:712,t:1527269020091};\\\", \\\"{x:1353,y:712,t:1527269020108};\\\", \\\"{x:1354,y:711,t:1527269028069};\\\", \\\"{x:1356,y:709,t:1527269028098};\\\", \\\"{x:1358,y:708,t:1527269028122};\\\", \\\"{x:1358,y:707,t:1527269028129};\\\", \\\"{x:1359,y:707,t:1527269028153};\\\", \\\"{x:1361,y:706,t:1527269028210};\\\", \\\"{x:1362,y:706,t:1527269028249};\\\", \\\"{x:1363,y:705,t:1527269028258};\\\", \\\"{x:1365,y:705,t:1527269028275};\\\", \\\"{x:1369,y:703,t:1527269028291};\\\", \\\"{x:1372,y:703,t:1527269028309};\\\", \\\"{x:1376,y:702,t:1527269028324};\\\", \\\"{x:1379,y:701,t:1527269028342};\\\", \\\"{x:1383,y:701,t:1527269028358};\\\", \\\"{x:1387,y:700,t:1527269028375};\\\", \\\"{x:1391,y:700,t:1527269028392};\\\", \\\"{x:1392,y:699,t:1527269028409};\\\", \\\"{x:1393,y:699,t:1527269028522};\\\", \\\"{x:1394,y:699,t:1527269028570};\\\", \\\"{x:1395,y:699,t:1527269028628};\\\", \\\"{x:1396,y:699,t:1527269028683};\\\", \\\"{x:1397,y:699,t:1527269028698};\\\", \\\"{x:1399,y:700,t:1527269028747};\\\", \\\"{x:1400,y:700,t:1527269028771};\\\", \\\"{x:1402,y:701,t:1527269028778};\\\", \\\"{x:1404,y:702,t:1527269028803};\\\", \\\"{x:1405,y:702,t:1527269028818};\\\", \\\"{x:1406,y:703,t:1527269028826};\\\", \\\"{x:1407,y:703,t:1527269028858};\\\", \\\"{x:1408,y:703,t:1527269028907};\\\", \\\"{x:1408,y:704,t:1527269028914};\\\", \\\"{x:1409,y:704,t:1527269028954};\\\", \\\"{x:1410,y:706,t:1527269029003};\\\", \\\"{x:1411,y:706,t:1527269029010};\\\", \\\"{x:1412,y:707,t:1527269029027};\\\", \\\"{x:1413,y:708,t:1527269029051};\\\", \\\"{x:1413,y:709,t:1527269029067};\\\", \\\"{x:1415,y:710,t:1527269029075};\\\", \\\"{x:1415,y:711,t:1527269029098};\\\", \\\"{x:1416,y:711,t:1527269029109};\\\", \\\"{x:1418,y:712,t:1527269029126};\\\", \\\"{x:1419,y:714,t:1527269029142};\\\", \\\"{x:1421,y:716,t:1527269029160};\\\", \\\"{x:1422,y:717,t:1527269029176};\\\", \\\"{x:1424,y:718,t:1527269029193};\\\", \\\"{x:1425,y:719,t:1527269029210};\\\", \\\"{x:1426,y:720,t:1527269029227};\\\", \\\"{x:1428,y:721,t:1527269029242};\\\", \\\"{x:1430,y:721,t:1527269029307};\\\", \\\"{x:1431,y:722,t:1527269029347};\\\", \\\"{x:1432,y:722,t:1527269029360};\\\", \\\"{x:1432,y:723,t:1527269029376};\\\", \\\"{x:1433,y:723,t:1527269029393};\\\", \\\"{x:1434,y:724,t:1527269029410};\\\", \\\"{x:1435,y:724,t:1527269029426};\\\", \\\"{x:1438,y:727,t:1527269029442};\\\", \\\"{x:1442,y:729,t:1527269029460};\\\", \\\"{x:1447,y:732,t:1527269029475};\\\", \\\"{x:1452,y:735,t:1527269029493};\\\", \\\"{x:1456,y:738,t:1527269029510};\\\", \\\"{x:1458,y:739,t:1527269029526};\\\", \\\"{x:1460,y:740,t:1527269029542};\\\", \\\"{x:1461,y:740,t:1527269029595};\\\", \\\"{x:1463,y:742,t:1527269029610};\\\", \\\"{x:1464,y:742,t:1527269029651};\\\", \\\"{x:1464,y:743,t:1527269029691};\\\", \\\"{x:1464,y:744,t:1527269029755};\\\", \\\"{x:1465,y:745,t:1527269029762};\\\", \\\"{x:1466,y:746,t:1527269029803};\\\", \\\"{x:1466,y:747,t:1527269029818};\\\", \\\"{x:1467,y:748,t:1527269029827};\\\", \\\"{x:1469,y:750,t:1527269029851};\\\", \\\"{x:1469,y:751,t:1527269029867};\\\", \\\"{x:1470,y:752,t:1527269029883};\\\", \\\"{x:1471,y:753,t:1527269029898};\\\", \\\"{x:1471,y:754,t:1527269029910};\\\", \\\"{x:1472,y:755,t:1527269029931};\\\", \\\"{x:1473,y:756,t:1527269029963};\\\", \\\"{x:1473,y:757,t:1527269029977};\\\", \\\"{x:1474,y:759,t:1527269029993};\\\", \\\"{x:1475,y:760,t:1527269030009};\\\", \\\"{x:1478,y:766,t:1527269030027};\\\", \\\"{x:1479,y:767,t:1527269030042};\\\", \\\"{x:1480,y:768,t:1527269030062};\\\", \\\"{x:1481,y:769,t:1527269030090};\\\", \\\"{x:1482,y:770,t:1527269030226};\\\", \\\"{x:1483,y:771,t:1527269030283};\\\", \\\"{x:1484,y:771,t:1527269030331};\\\", \\\"{x:1485,y:772,t:1527269030411};\\\", \\\"{x:1485,y:773,t:1527269031099};\\\", \\\"{x:1485,y:772,t:1527269039529};\\\", \\\"{x:1484,y:772,t:1527269040746};\\\", \\\"{x:1482,y:771,t:1527269040955};\\\", \\\"{x:1480,y:770,t:1527269040994};\\\", \\\"{x:1476,y:769,t:1527269041034};\\\", \\\"{x:1469,y:765,t:1527269041047};\\\", \\\"{x:1461,y:761,t:1527269041062};\\\", \\\"{x:1453,y:760,t:1527269041079};\\\", \\\"{x:1445,y:760,t:1527269041096};\\\", \\\"{x:1431,y:757,t:1527269041112};\\\", \\\"{x:1411,y:751,t:1527269041129};\\\", \\\"{x:1376,y:743,t:1527269041146};\\\", \\\"{x:1351,y:739,t:1527269041162};\\\", \\\"{x:1318,y:732,t:1527269041179};\\\", \\\"{x:1279,y:727,t:1527269041196};\\\", \\\"{x:1234,y:721,t:1527269041211};\\\", \\\"{x:1186,y:714,t:1527269041229};\\\", \\\"{x:1125,y:706,t:1527269041245};\\\", \\\"{x:1050,y:696,t:1527269041262};\\\", \\\"{x:1002,y:695,t:1527269041279};\\\", \\\"{x:966,y:695,t:1527269041296};\\\", \\\"{x:934,y:695,t:1527269041312};\\\", \\\"{x:908,y:694,t:1527269041329};\\\", \\\"{x:871,y:694,t:1527269041346};\\\", \\\"{x:847,y:690,t:1527269041362};\\\", \\\"{x:822,y:687,t:1527269041378};\\\", \\\"{x:796,y:684,t:1527269041396};\\\", \\\"{x:767,y:679,t:1527269041412};\\\", \\\"{x:740,y:676,t:1527269041429};\\\", \\\"{x:717,y:672,t:1527269041446};\\\", \\\"{x:696,y:670,t:1527269041462};\\\", \\\"{x:680,y:670,t:1527269041479};\\\", \\\"{x:663,y:670,t:1527269041496};\\\", \\\"{x:648,y:668,t:1527269041512};\\\", \\\"{x:635,y:668,t:1527269041529};\\\", \\\"{x:616,y:668,t:1527269041546};\\\", \\\"{x:601,y:668,t:1527269041562};\\\", \\\"{x:584,y:668,t:1527269041579};\\\", \\\"{x:565,y:668,t:1527269041596};\\\", \\\"{x:553,y:668,t:1527269041613};\\\", \\\"{x:546,y:668,t:1527269041628};\\\", \\\"{x:544,y:668,t:1527269041645};\\\", \\\"{x:543,y:668,t:1527269041661};\\\", \\\"{x:542,y:668,t:1527269041737};\\\", \\\"{x:538,y:668,t:1527269041745};\\\", \\\"{x:534,y:668,t:1527269041761};\\\", \\\"{x:523,y:668,t:1527269041778};\\\", \\\"{x:519,y:668,t:1527269041794};\\\", \\\"{x:521,y:668,t:1527269042435};\\\", \\\"{x:530,y:662,t:1527269042445};\\\", \\\"{x:550,y:654,t:1527269042461};\\\", \\\"{x:569,y:645,t:1527269042478};\\\", \\\"{x:588,y:637,t:1527269042495};\\\", \\\"{x:604,y:628,t:1527269042511};\\\", \\\"{x:614,y:623,t:1527269042528};\\\", \\\"{x:626,y:618,t:1527269042545};\\\", \\\"{x:636,y:613,t:1527269042561};\\\", \\\"{x:644,y:610,t:1527269042577};\\\", \\\"{x:647,y:609,t:1527269042595};\\\", \\\"{x:647,y:608,t:1527269042626};\\\", \\\"{x:646,y:608,t:1527269043017};\\\", \\\"{x:645,y:608,t:1527269043034};\\\", \\\"{x:644,y:608,t:1527269043049};\\\", \\\"{x:643,y:608,t:1527269043065};\\\" ] }, { \\\"rt\\\": 112095, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 19, \\\"time_elapsed\\\": 697763, \\\"internal_node_id\\\": \\\"0.0-6.0-9.0\\\", \\\"subject\\\": \\\"YC7SX\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"mike\\\", \\\"condition\\\": \\\"115-late\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"midpoint\\\", \\\"q\\\": 15, \\\"clicks\\\": 6.5, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XFull-YFull\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 1, \\\"answer\\\": [ \\\"E\\\", \\\"F\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-I -I -J -J \\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:642,y:609,t:1527269048618};\\\", \\\"{x:642,y:610,t:1527269048633};\\\", \\\"{x:640,y:610,t:1527269048649};\\\", \\\"{x:640,y:611,t:1527269048665};\\\", \\\"{x:638,y:611,t:1527269048761};\\\", \\\"{x:637,y:612,t:1527269048785};\\\", \\\"{x:635,y:613,t:1527269048825};\\\", \\\"{x:636,y:616,t:1527269048979};\\\", \\\"{x:643,y:618,t:1527269048986};\\\", \\\"{x:648,y:618,t:1527269049000};\\\", \\\"{x:657,y:622,t:1527269049016};\\\", \\\"{x:668,y:625,t:1527269049034};\\\", \\\"{x:689,y:633,t:1527269049050};\\\", \\\"{x:712,y:645,t:1527269049066};\\\", \\\"{x:741,y:657,t:1527269049083};\\\", \\\"{x:774,y:670,t:1527269049100};\\\", \\\"{x:813,y:681,t:1527269049116};\\\", \\\"{x:854,y:692,t:1527269049133};\\\", \\\"{x:905,y:706,t:1527269049150};\\\", \\\"{x:942,y:719,t:1527269049166};\\\", \\\"{x:984,y:732,t:1527269049184};\\\", \\\"{x:1018,y:741,t:1527269049200};\\\", \\\"{x:1060,y:755,t:1527269049218};\\\", \\\"{x:1073,y:759,t:1527269049233};\\\", \\\"{x:1097,y:769,t:1527269049251};\\\", \\\"{x:1111,y:776,t:1527269049267};\\\", \\\"{x:1120,y:783,t:1527269049284};\\\", \\\"{x:1124,y:788,t:1527269049301};\\\", \\\"{x:1126,y:789,t:1527269049318};\\\", \\\"{x:1128,y:791,t:1527269049334};\\\", \\\"{x:1128,y:792,t:1527269049354};\\\", \\\"{x:1129,y:792,t:1527269050538};\\\", \\\"{x:1130,y:792,t:1527269050551};\\\", \\\"{x:1134,y:792,t:1527269050569};\\\", \\\"{x:1139,y:789,t:1527269050585};\\\", \\\"{x:1146,y:785,t:1527269050602};\\\", \\\"{x:1149,y:783,t:1527269050618};\\\", \\\"{x:1152,y:781,t:1527269050635};\\\", \\\"{x:1153,y:780,t:1527269050652};\\\", \\\"{x:1155,y:779,t:1527269050669};\\\", \\\"{x:1155,y:778,t:1527269050685};\\\", \\\"{x:1157,y:777,t:1527269050702};\\\", \\\"{x:1158,y:775,t:1527269050720};\\\", \\\"{x:1159,y:774,t:1527269050738};\\\", \\\"{x:1160,y:772,t:1527269050754};\\\", \\\"{x:1161,y:771,t:1527269050770};\\\", \\\"{x:1161,y:770,t:1527269050787};\\\", \\\"{x:1162,y:770,t:1527269050802};\\\", \\\"{x:1165,y:765,t:1527269050818};\\\", \\\"{x:1165,y:764,t:1527269050834};\\\", \\\"{x:1166,y:763,t:1527269050851};\\\", \\\"{x:1168,y:760,t:1527269050868};\\\", \\\"{x:1169,y:759,t:1527269050885};\\\", \\\"{x:1171,y:756,t:1527269050901};\\\", \\\"{x:1171,y:755,t:1527269050930};\\\", \\\"{x:1172,y:754,t:1527269050946};\\\", \\\"{x:1173,y:753,t:1527269050962};\\\", \\\"{x:1174,y:752,t:1527269050977};\\\", \\\"{x:1175,y:751,t:1527269050985};\\\", \\\"{x:1176,y:750,t:1527269051001};\\\", \\\"{x:1178,y:748,t:1527269051018};\\\", \\\"{x:1178,y:747,t:1527269051035};\\\", \\\"{x:1180,y:745,t:1527269051051};\\\", \\\"{x:1181,y:743,t:1527269051068};\\\", \\\"{x:1183,y:741,t:1527269051085};\\\", \\\"{x:1184,y:740,t:1527269051101};\\\", \\\"{x:1185,y:738,t:1527269051119};\\\", \\\"{x:1185,y:737,t:1527269051135};\\\", \\\"{x:1185,y:736,t:1527269051152};\\\", \\\"{x:1187,y:733,t:1527269051168};\\\", \\\"{x:1187,y:731,t:1527269051186};\\\", \\\"{x:1187,y:730,t:1527269051201};\\\", \\\"{x:1188,y:727,t:1527269051218};\\\", \\\"{x:1189,y:725,t:1527269051235};\\\", \\\"{x:1190,y:724,t:1527269051346};\\\", \\\"{x:1190,y:723,t:1527269051787};\\\", \\\"{x:1189,y:723,t:1527269051802};\\\", \\\"{x:1187,y:723,t:1527269051819};\\\", \\\"{x:1186,y:723,t:1527269051842};\\\", \\\"{x:1185,y:723,t:1527269051853};\\\", \\\"{x:1184,y:724,t:1527269051870};\\\", \\\"{x:1183,y:725,t:1527269051906};\\\", \\\"{x:1182,y:726,t:1527269051920};\\\", \\\"{x:1182,y:727,t:1527269051936};\\\", \\\"{x:1182,y:728,t:1527269051953};\\\", \\\"{x:1182,y:730,t:1527269051970};\\\", \\\"{x:1182,y:733,t:1527269051986};\\\", \\\"{x:1182,y:738,t:1527269052002};\\\", \\\"{x:1182,y:741,t:1527269052020};\\\", \\\"{x:1182,y:744,t:1527269052036};\\\", \\\"{x:1182,y:750,t:1527269052052};\\\", \\\"{x:1183,y:754,t:1527269052069};\\\", \\\"{x:1185,y:758,t:1527269052085};\\\", \\\"{x:1186,y:761,t:1527269052102};\\\", \\\"{x:1186,y:764,t:1527269052119};\\\", \\\"{x:1187,y:768,t:1527269052135};\\\", \\\"{x:1189,y:771,t:1527269052152};\\\", \\\"{x:1190,y:775,t:1527269052169};\\\", \\\"{x:1190,y:777,t:1527269052185};\\\", \\\"{x:1190,y:783,t:1527269052203};\\\", \\\"{x:1190,y:786,t:1527269052219};\\\", \\\"{x:1192,y:791,t:1527269052236};\\\", \\\"{x:1192,y:799,t:1527269052252};\\\", \\\"{x:1192,y:809,t:1527269052270};\\\", \\\"{x:1192,y:824,t:1527269052285};\\\", \\\"{x:1192,y:839,t:1527269052303};\\\", \\\"{x:1192,y:857,t:1527269052320};\\\", \\\"{x:1193,y:868,t:1527269052336};\\\", \\\"{x:1193,y:878,t:1527269052352};\\\", \\\"{x:1194,y:884,t:1527269052370};\\\", \\\"{x:1194,y:888,t:1527269052387};\\\", \\\"{x:1194,y:889,t:1527269052403};\\\", \\\"{x:1193,y:889,t:1527269052635};\\\", \\\"{x:1192,y:889,t:1527269052699};\\\", \\\"{x:1190,y:889,t:1527269056586};\\\", \\\"{x:1190,y:888,t:1527269056651};\\\", \\\"{x:1189,y:888,t:1527269056683};\\\", \\\"{x:1189,y:887,t:1527269056691};\\\", \\\"{x:1189,y:884,t:1527269056706};\\\", \\\"{x:1189,y:882,t:1527269056723};\\\", \\\"{x:1189,y:880,t:1527269056739};\\\", \\\"{x:1189,y:878,t:1527269056757};\\\", \\\"{x:1189,y:876,t:1527269056773};\\\", \\\"{x:1189,y:875,t:1527269056790};\\\", \\\"{x:1189,y:871,t:1527269056808};\\\", \\\"{x:1189,y:868,t:1527269056823};\\\", \\\"{x:1189,y:865,t:1527269056840};\\\", \\\"{x:1189,y:864,t:1527269056857};\\\", \\\"{x:1189,y:862,t:1527269056872};\\\", \\\"{x:1189,y:860,t:1527269056890};\\\", \\\"{x:1191,y:855,t:1527269056907};\\\", \\\"{x:1192,y:853,t:1527269056923};\\\", \\\"{x:1196,y:850,t:1527269056940};\\\", \\\"{x:1198,y:847,t:1527269056957};\\\", \\\"{x:1201,y:844,t:1527269056973};\\\", \\\"{x:1205,y:841,t:1527269056990};\\\", \\\"{x:1210,y:838,t:1527269057008};\\\", \\\"{x:1216,y:833,t:1527269057023};\\\", \\\"{x:1222,y:829,t:1527269057040};\\\", \\\"{x:1227,y:825,t:1527269057057};\\\", \\\"{x:1234,y:822,t:1527269057073};\\\", \\\"{x:1243,y:816,t:1527269057090};\\\", \\\"{x:1248,y:813,t:1527269057106};\\\", \\\"{x:1259,y:807,t:1527269057124};\\\", \\\"{x:1269,y:802,t:1527269057139};\\\", \\\"{x:1281,y:795,t:1527269057157};\\\", \\\"{x:1293,y:790,t:1527269057174};\\\", \\\"{x:1305,y:782,t:1527269057190};\\\", \\\"{x:1315,y:776,t:1527269057209};\\\", \\\"{x:1329,y:771,t:1527269057224};\\\", \\\"{x:1340,y:766,t:1527269057240};\\\", \\\"{x:1354,y:761,t:1527269057257};\\\", \\\"{x:1378,y:750,t:1527269057275};\\\", \\\"{x:1392,y:744,t:1527269057290};\\\", \\\"{x:1405,y:739,t:1527269057307};\\\", \\\"{x:1413,y:735,t:1527269057324};\\\", \\\"{x:1418,y:735,t:1527269057340};\\\", \\\"{x:1421,y:733,t:1527269057357};\\\", \\\"{x:1423,y:732,t:1527269057374};\\\", \\\"{x:1424,y:732,t:1527269057579};\\\", \\\"{x:1425,y:733,t:1527269057591};\\\", \\\"{x:1425,y:735,t:1527269057611};\\\", \\\"{x:1426,y:740,t:1527269057627};\\\", \\\"{x:1430,y:749,t:1527269057644};\\\", \\\"{x:1431,y:756,t:1527269057661};\\\", \\\"{x:1432,y:766,t:1527269057677};\\\", \\\"{x:1434,y:774,t:1527269057694};\\\", \\\"{x:1435,y:778,t:1527269057711};\\\", \\\"{x:1436,y:782,t:1527269057727};\\\", \\\"{x:1438,y:787,t:1527269057744};\\\", \\\"{x:1438,y:791,t:1527269057761};\\\", \\\"{x:1438,y:794,t:1527269057777};\\\", \\\"{x:1439,y:796,t:1527269057794};\\\", \\\"{x:1439,y:799,t:1527269057812};\\\", \\\"{x:1440,y:802,t:1527269057827};\\\", \\\"{x:1440,y:806,t:1527269057844};\\\", \\\"{x:1440,y:809,t:1527269057860};\\\", \\\"{x:1440,y:814,t:1527269057878};\\\", \\\"{x:1440,y:816,t:1527269057894};\\\", \\\"{x:1440,y:817,t:1527269057911};\\\", \\\"{x:1440,y:818,t:1527269057927};\\\", \\\"{x:1440,y:819,t:1527269057945};\\\", \\\"{x:1440,y:821,t:1527269057961};\\\", \\\"{x:1440,y:822,t:1527269057977};\\\", \\\"{x:1440,y:823,t:1527269057998};\\\", \\\"{x:1440,y:824,t:1527269058014};\\\", \\\"{x:1440,y:825,t:1527269058028};\\\", \\\"{x:1440,y:826,t:1527269058044};\\\", \\\"{x:1440,y:828,t:1527269058062};\\\", \\\"{x:1439,y:831,t:1527269058078};\\\", \\\"{x:1438,y:832,t:1527269058101};\\\", \\\"{x:1437,y:833,t:1527269058111};\\\", \\\"{x:1437,y:834,t:1527269058134};\\\", \\\"{x:1436,y:835,t:1527269058144};\\\", \\\"{x:1436,y:836,t:1527269058162};\\\", \\\"{x:1435,y:837,t:1527269058178};\\\", \\\"{x:1434,y:838,t:1527269058194};\\\", \\\"{x:1434,y:839,t:1527269058212};\\\", \\\"{x:1434,y:840,t:1527269058310};\\\", \\\"{x:1433,y:841,t:1527269063462};\\\", \\\"{x:1423,y:841,t:1527269063469};\\\", \\\"{x:1406,y:833,t:1527269063482};\\\", \\\"{x:1368,y:817,t:1527269063499};\\\", \\\"{x:1346,y:807,t:1527269063515};\\\", \\\"{x:1328,y:800,t:1527269063531};\\\", \\\"{x:1308,y:790,t:1527269063548};\\\", \\\"{x:1281,y:774,t:1527269063566};\\\", \\\"{x:1268,y:767,t:1527269063582};\\\", \\\"{x:1262,y:764,t:1527269063598};\\\", \\\"{x:1261,y:764,t:1527269063616};\\\", \\\"{x:1261,y:763,t:1527269063661};\\\", \\\"{x:1261,y:762,t:1527269063669};\\\", \\\"{x:1261,y:760,t:1527269063681};\\\", \\\"{x:1261,y:757,t:1527269063698};\\\", \\\"{x:1262,y:752,t:1527269063716};\\\", \\\"{x:1263,y:747,t:1527269063732};\\\", \\\"{x:1261,y:739,t:1527269063749};\\\", \\\"{x:1254,y:731,t:1527269063765};\\\", \\\"{x:1247,y:727,t:1527269063782};\\\", \\\"{x:1239,y:722,t:1527269063798};\\\", \\\"{x:1229,y:717,t:1527269063816};\\\", \\\"{x:1219,y:714,t:1527269063832};\\\", \\\"{x:1209,y:709,t:1527269063849};\\\", \\\"{x:1202,y:706,t:1527269063865};\\\", \\\"{x:1197,y:704,t:1527269063882};\\\", \\\"{x:1195,y:703,t:1527269063899};\\\", \\\"{x:1193,y:702,t:1527269063916};\\\", \\\"{x:1191,y:701,t:1527269063933};\\\", \\\"{x:1190,y:701,t:1527269063949};\\\", \\\"{x:1188,y:701,t:1527269063998};\\\", \\\"{x:1187,y:701,t:1527269064046};\\\", \\\"{x:1185,y:701,t:1527269064069};\\\", \\\"{x:1184,y:701,t:1527269064086};\\\", \\\"{x:1183,y:702,t:1527269064099};\\\", \\\"{x:1181,y:702,t:1527269064116};\\\", \\\"{x:1180,y:703,t:1527269064133};\\\", \\\"{x:1179,y:703,t:1527269064149};\\\", \\\"{x:1178,y:703,t:1527269064165};\\\", \\\"{x:1178,y:704,t:1527269072662};\\\", \\\"{x:1179,y:706,t:1527269072676};\\\", \\\"{x:1179,y:711,t:1527269072689};\\\", \\\"{x:1180,y:716,t:1527269072705};\\\", \\\"{x:1180,y:717,t:1527269072723};\\\", \\\"{x:1181,y:720,t:1527269072738};\\\", \\\"{x:1182,y:724,t:1527269072755};\\\", \\\"{x:1185,y:732,t:1527269072773};\\\", \\\"{x:1187,y:738,t:1527269072789};\\\", \\\"{x:1190,y:742,t:1527269072806};\\\", \\\"{x:1191,y:747,t:1527269072822};\\\", \\\"{x:1193,y:750,t:1527269072839};\\\", \\\"{x:1195,y:754,t:1527269072855};\\\", \\\"{x:1197,y:758,t:1527269072872};\\\", \\\"{x:1198,y:758,t:1527269072889};\\\", \\\"{x:1200,y:760,t:1527269072906};\\\", \\\"{x:1201,y:761,t:1527269072933};\\\", \\\"{x:1202,y:761,t:1527269072949};\\\", \\\"{x:1203,y:761,t:1527269072965};\\\", \\\"{x:1204,y:762,t:1527269072974};\\\", \\\"{x:1205,y:764,t:1527269072989};\\\", \\\"{x:1207,y:765,t:1527269073006};\\\", \\\"{x:1208,y:767,t:1527269073023};\\\", \\\"{x:1209,y:769,t:1527269073039};\\\", \\\"{x:1210,y:769,t:1527269073055};\\\", \\\"{x:1210,y:771,t:1527269073073};\\\", \\\"{x:1212,y:772,t:1527269073091};\\\", \\\"{x:1212,y:773,t:1527269073126};\\\", \\\"{x:1212,y:774,t:1527269073148};\\\", \\\"{x:1210,y:774,t:1527269083052};\\\", \\\"{x:1209,y:774,t:1527269083064};\\\", \\\"{x:1208,y:774,t:1527269083080};\\\", \\\"{x:1207,y:773,t:1527269083096};\\\", \\\"{x:1206,y:773,t:1527269083114};\\\", \\\"{x:1205,y:773,t:1527269083130};\\\", \\\"{x:1203,y:772,t:1527269083147};\\\", \\\"{x:1202,y:766,t:1527269083164};\\\", \\\"{x:1200,y:762,t:1527269083180};\\\", \\\"{x:1194,y:750,t:1527269083196};\\\", \\\"{x:1192,y:747,t:1527269083215};\\\", \\\"{x:1190,y:743,t:1527269083231};\\\", \\\"{x:1187,y:739,t:1527269083247};\\\", \\\"{x:1186,y:735,t:1527269083264};\\\", \\\"{x:1184,y:732,t:1527269083281};\\\", \\\"{x:1181,y:728,t:1527269083297};\\\", \\\"{x:1178,y:723,t:1527269083314};\\\", \\\"{x:1171,y:718,t:1527269083331};\\\", \\\"{x:1162,y:712,t:1527269083348};\\\", \\\"{x:1149,y:706,t:1527269083364};\\\", \\\"{x:1117,y:693,t:1527269083381};\\\", \\\"{x:1100,y:685,t:1527269083397};\\\", \\\"{x:1074,y:678,t:1527269083414};\\\", \\\"{x:1047,y:670,t:1527269083432};\\\", \\\"{x:1014,y:663,t:1527269083448};\\\", \\\"{x:987,y:654,t:1527269083464};\\\", \\\"{x:949,y:642,t:1527269083482};\\\", \\\"{x:916,y:634,t:1527269083497};\\\", \\\"{x:886,y:626,t:1527269083514};\\\", \\\"{x:858,y:617,t:1527269083531};\\\", \\\"{x:830,y:607,t:1527269083547};\\\", \\\"{x:809,y:599,t:1527269083564};\\\", \\\"{x:762,y:582,t:1527269083583};\\\", \\\"{x:705,y:571,t:1527269083598};\\\", \\\"{x:692,y:564,t:1527269083613};\\\", \\\"{x:690,y:563,t:1527269083631};\\\", \\\"{x:684,y:562,t:1527269083647};\\\", \\\"{x:679,y:556,t:1527269083676};\\\", \\\"{x:669,y:549,t:1527269083685};\\\", \\\"{x:666,y:545,t:1527269083697};\\\", \\\"{x:653,y:538,t:1527269083713};\\\", \\\"{x:654,y:538,t:1527269083805};\\\", \\\"{x:654,y:539,t:1527269083861};\\\", \\\"{x:647,y:539,t:1527269083868};\\\", \\\"{x:638,y:539,t:1527269083882};\\\", \\\"{x:616,y:538,t:1527269083897};\\\", \\\"{x:593,y:536,t:1527269083915};\\\", \\\"{x:567,y:533,t:1527269083931};\\\", \\\"{x:543,y:531,t:1527269083947};\\\", \\\"{x:518,y:527,t:1527269083965};\\\", \\\"{x:508,y:526,t:1527269083981};\\\", \\\"{x:499,y:524,t:1527269083998};\\\", \\\"{x:487,y:522,t:1527269084015};\\\", \\\"{x:478,y:521,t:1527269084032};\\\", \\\"{x:465,y:518,t:1527269084048};\\\", \\\"{x:451,y:517,t:1527269084065};\\\", \\\"{x:436,y:513,t:1527269084082};\\\", \\\"{x:423,y:511,t:1527269084098};\\\", \\\"{x:412,y:507,t:1527269084115};\\\", \\\"{x:402,y:503,t:1527269084132};\\\", \\\"{x:389,y:501,t:1527269084148};\\\", \\\"{x:370,y:493,t:1527269084165};\\\", \\\"{x:357,y:489,t:1527269084182};\\\", \\\"{x:340,y:482,t:1527269084198};\\\", \\\"{x:320,y:477,t:1527269084215};\\\", \\\"{x:304,y:470,t:1527269084232};\\\", \\\"{x:283,y:464,t:1527269084248};\\\", \\\"{x:258,y:457,t:1527269084266};\\\", \\\"{x:230,y:449,t:1527269084282};\\\", \\\"{x:206,y:442,t:1527269084299};\\\", \\\"{x:188,y:439,t:1527269084315};\\\", \\\"{x:179,y:438,t:1527269084332};\\\", \\\"{x:178,y:438,t:1527269084348};\\\", \\\"{x:177,y:438,t:1527269084365};\\\", \\\"{x:176,y:438,t:1527269084502};\\\", \\\"{x:174,y:438,t:1527269084515};\\\", \\\"{x:170,y:438,t:1527269084533};\\\", \\\"{x:165,y:440,t:1527269084550};\\\", \\\"{x:163,y:442,t:1527269084566};\\\", \\\"{x:161,y:443,t:1527269084583};\\\", \\\"{x:161,y:444,t:1527269084599};\\\", \\\"{x:160,y:445,t:1527269084615};\\\", \\\"{x:160,y:447,t:1527269084632};\\\", \\\"{x:158,y:448,t:1527269084651};\\\", \\\"{x:157,y:450,t:1527269084664};\\\", \\\"{x:156,y:452,t:1527269084682};\\\", \\\"{x:155,y:454,t:1527269084724};\\\", \\\"{x:155,y:455,t:1527269084740};\\\", \\\"{x:157,y:455,t:1527269084965};\\\", \\\"{x:168,y:454,t:1527269084982};\\\", \\\"{x:184,y:454,t:1527269084999};\\\", \\\"{x:197,y:454,t:1527269085016};\\\", \\\"{x:212,y:454,t:1527269085031};\\\", \\\"{x:233,y:454,t:1527269085048};\\\", \\\"{x:256,y:456,t:1527269085066};\\\", \\\"{x:277,y:461,t:1527269085083};\\\", \\\"{x:294,y:465,t:1527269085099};\\\", \\\"{x:308,y:467,t:1527269085116};\\\", \\\"{x:318,y:468,t:1527269085132};\\\", \\\"{x:326,y:470,t:1527269085149};\\\", \\\"{x:328,y:470,t:1527269085166};\\\", \\\"{x:329,y:470,t:1527269085182};\\\", \\\"{x:330,y:470,t:1527269085199};\\\", \\\"{x:332,y:470,t:1527269085216};\\\", \\\"{x:334,y:470,t:1527269085232};\\\", \\\"{x:336,y:471,t:1527269085249};\\\", \\\"{x:339,y:471,t:1527269085266};\\\", \\\"{x:340,y:471,t:1527269085284};\\\", \\\"{x:341,y:471,t:1527269085299};\\\", \\\"{x:346,y:471,t:1527269085317};\\\", \\\"{x:352,y:470,t:1527269085333};\\\", \\\"{x:359,y:469,t:1527269085349};\\\", \\\"{x:364,y:469,t:1527269085366};\\\", \\\"{x:365,y:469,t:1527269085383};\\\", \\\"{x:367,y:469,t:1527269085399};\\\", \\\"{x:368,y:469,t:1527269085416};\\\", \\\"{x:370,y:469,t:1527269085433};\\\", \\\"{x:372,y:469,t:1527269085449};\\\", \\\"{x:375,y:469,t:1527269085466};\\\", \\\"{x:378,y:469,t:1527269085484};\\\", \\\"{x:381,y:469,t:1527269085499};\\\", \\\"{x:382,y:469,t:1527269086038};\\\", \\\"{x:382,y:473,t:1527269086050};\\\", \\\"{x:382,y:474,t:1527269086066};\\\", \\\"{x:392,y:476,t:1527269104702};\\\", \\\"{x:400,y:478,t:1527269104710};\\\", \\\"{x:405,y:478,t:1527269104727};\\\", \\\"{x:408,y:478,t:1527269104828};\\\", \\\"{x:410,y:477,t:1527269104836};\\\", \\\"{x:413,y:474,t:1527269104848};\\\", \\\"{x:417,y:474,t:1527269104864};\\\", \\\"{x:422,y:474,t:1527269104882};\\\", \\\"{x:423,y:474,t:1527269104900};\\\", \\\"{x:424,y:475,t:1527269105781};\\\", \\\"{x:424,y:479,t:1527269105790};\\\", \\\"{x:424,y:490,t:1527269105800};\\\", \\\"{x:427,y:497,t:1527269105816};\\\", \\\"{x:428,y:503,t:1527269105833};\\\", \\\"{x:429,y:511,t:1527269105849};\\\", \\\"{x:432,y:519,t:1527269105866};\\\", \\\"{x:435,y:526,t:1527269105883};\\\", \\\"{x:440,y:538,t:1527269105899};\\\", \\\"{x:449,y:559,t:1527269105917};\\\", \\\"{x:455,y:571,t:1527269105933};\\\", \\\"{x:458,y:582,t:1527269105949};\\\", \\\"{x:463,y:596,t:1527269105966};\\\", \\\"{x:465,y:605,t:1527269105983};\\\", \\\"{x:467,y:612,t:1527269105999};\\\", \\\"{x:471,y:621,t:1527269106016};\\\", \\\"{x:484,y:641,t:1527269106033};\\\", \\\"{x:495,y:658,t:1527269106048};\\\", \\\"{x:504,y:669,t:1527269106065};\\\", \\\"{x:516,y:686,t:1527269106083};\\\", \\\"{x:531,y:705,t:1527269106100};\\\", \\\"{x:535,y:714,t:1527269106115};\\\", \\\"{x:537,y:720,t:1527269106133};\\\", \\\"{x:539,y:727,t:1527269106149};\\\", \\\"{x:540,y:735,t:1527269106166};\\\", \\\"{x:542,y:741,t:1527269106183};\\\", \\\"{x:543,y:743,t:1527269106200};\\\", \\\"{x:543,y:744,t:1527269106215};\\\", \\\"{x:543,y:745,t:1527269106233};\\\", \\\"{x:543,y:746,t:1527269106251};\\\", \\\"{x:543,y:747,t:1527269106276};\\\", \\\"{x:543,y:744,t:1527269106364};\\\", \\\"{x:543,y:740,t:1527269106372};\\\", \\\"{x:543,y:733,t:1527269106383};\\\", \\\"{x:543,y:720,t:1527269106400};\\\", \\\"{x:538,y:705,t:1527269106416};\\\", \\\"{x:530,y:687,t:1527269106433};\\\", \\\"{x:526,y:679,t:1527269106450};\\\", \\\"{x:525,y:675,t:1527269106466};\\\", \\\"{x:523,y:673,t:1527269106483};\\\", \\\"{x:523,y:672,t:1527269107245};\\\", \\\"{x:523,y:665,t:1527269107253};\\\", \\\"{x:523,y:657,t:1527269107267};\\\", \\\"{x:522,y:625,t:1527269107285};\\\", \\\"{x:518,y:613,t:1527269107300};\\\", \\\"{x:513,y:574,t:1527269107318};\\\", \\\"{x:509,y:556,t:1527269107334};\\\", \\\"{x:507,y:538,t:1527269107352};\\\", \\\"{x:507,y:523,t:1527269107367};\\\", \\\"{x:506,y:512,t:1527269107384};\\\", \\\"{x:504,y:496,t:1527269107400};\\\", \\\"{x:498,y:490,t:1527269107417};\\\", \\\"{x:494,y:486,t:1527269107434};\\\", \\\"{x:489,y:483,t:1527269107452};\\\", \\\"{x:482,y:480,t:1527269107467};\\\", \\\"{x:468,y:475,t:1527269107484};\\\", \\\"{x:456,y:471,t:1527269107500};\\\", \\\"{x:442,y:470,t:1527269107517};\\\", \\\"{x:426,y:470,t:1527269107534};\\\", \\\"{x:408,y:466,t:1527269107552};\\\", \\\"{x:399,y:465,t:1527269107567};\\\", \\\"{x:391,y:461,t:1527269107584};\\\", \\\"{x:386,y:460,t:1527269107601};\\\", \\\"{x:383,y:459,t:1527269107617};\\\", \\\"{x:381,y:458,t:1527269107634};\\\", \\\"{x:381,y:457,t:1527269107660};\\\", \\\"{x:380,y:457,t:1527269107668};\\\", \\\"{x:378,y:456,t:1527269107684};\\\", \\\"{x:377,y:456,t:1527269107700};\\\", \\\"{x:376,y:456,t:1527269107717};\\\", \\\"{x:375,y:455,t:1527269107735};\\\", \\\"{x:372,y:455,t:1527269107877};\\\", \\\"{x:369,y:455,t:1527269107884};\\\", \\\"{x:368,y:455,t:1527269107901};\\\", \\\"{x:366,y:455,t:1527269107918};\\\", \\\"{x:366,y:454,t:1527269107973};\\\", \\\"{x:363,y:453,t:1527269107984};\\\", \\\"{x:360,y:453,t:1527269108001};\\\", \\\"{x:355,y:452,t:1527269108018};\\\", \\\"{x:352,y:452,t:1527269108034};\\\", \\\"{x:347,y:452,t:1527269108051};\\\", \\\"{x:334,y:450,t:1527269108068};\\\", \\\"{x:316,y:446,t:1527269108085};\\\", \\\"{x:300,y:444,t:1527269108101};\\\", \\\"{x:293,y:443,t:1527269108119};\\\", \\\"{x:286,y:441,t:1527269108134};\\\", \\\"{x:289,y:441,t:1527269108229};\\\", \\\"{x:293,y:442,t:1527269108237};\\\", \\\"{x:297,y:442,t:1527269108252};\\\", \\\"{x:319,y:448,t:1527269108269};\\\", \\\"{x:327,y:452,t:1527269108284};\\\", \\\"{x:349,y:457,t:1527269108301};\\\", \\\"{x:365,y:462,t:1527269108318};\\\", \\\"{x:375,y:465,t:1527269108335};\\\", \\\"{x:385,y:468,t:1527269108353};\\\", \\\"{x:392,y:470,t:1527269108369};\\\", \\\"{x:393,y:471,t:1527269108413};\\\", \\\"{x:393,y:472,t:1527269108469};\\\", \\\"{x:393,y:473,t:1527269108485};\\\", \\\"{x:392,y:473,t:1527269108502};\\\", \\\"{x:391,y:474,t:1527269108519};\\\", \\\"{x:390,y:474,t:1527269108536};\\\", \\\"{x:389,y:474,t:1527269108948};\\\", \\\"{x:386,y:474,t:1527269108956};\\\", \\\"{x:384,y:474,t:1527269108972};\\\", \\\"{x:383,y:474,t:1527269108985};\\\", \\\"{x:381,y:472,t:1527269109002};\\\", \\\"{x:379,y:470,t:1527269109018};\\\", \\\"{x:376,y:469,t:1527269109061};\\\", \\\"{x:373,y:468,t:1527269109078};\\\", \\\"{x:371,y:468,t:1527269109085};\\\", \\\"{x:363,y:467,t:1527269109102};\\\", \\\"{x:354,y:465,t:1527269109119};\\\", \\\"{x:336,y:461,t:1527269109135};\\\", \\\"{x:319,y:455,t:1527269109152};\\\", \\\"{x:291,y:447,t:1527269109170};\\\", \\\"{x:266,y:442,t:1527269109186};\\\", \\\"{x:246,y:434,t:1527269109202};\\\", \\\"{x:229,y:428,t:1527269109219};\\\", \\\"{x:214,y:425,t:1527269109235};\\\", \\\"{x:199,y:422,t:1527269109252};\\\", \\\"{x:193,y:422,t:1527269109269};\\\", \\\"{x:188,y:422,t:1527269109285};\\\", \\\"{x:183,y:422,t:1527269109303};\\\", \\\"{x:176,y:422,t:1527269109319};\\\", \\\"{x:172,y:421,t:1527269109336};\\\", \\\"{x:170,y:421,t:1527269109352};\\\", \\\"{x:169,y:421,t:1527269109369};\\\", \\\"{x:168,y:421,t:1527269109386};\\\", \\\"{x:166,y:423,t:1527269109402};\\\", \\\"{x:166,y:424,t:1527269109421};\\\", \\\"{x:165,y:426,t:1527269109436};\\\", \\\"{x:164,y:429,t:1527269109453};\\\", \\\"{x:162,y:432,t:1527269109469};\\\", \\\"{x:162,y:436,t:1527269109484};\\\", \\\"{x:162,y:437,t:1527269109502};\\\", \\\"{x:161,y:440,t:1527269109517};\\\", \\\"{x:161,y:441,t:1527269109535};\\\", \\\"{x:159,y:443,t:1527269109552};\\\", \\\"{x:159,y:446,t:1527269109568};\\\", \\\"{x:159,y:447,t:1527269109585};\\\", \\\"{x:159,y:450,t:1527269109602};\\\", \\\"{x:159,y:453,t:1527269109618};\\\", \\\"{x:159,y:455,t:1527269109636};\\\", \\\"{x:159,y:456,t:1527269109652};\\\", \\\"{x:159,y:457,t:1527269109684};\\\", \\\"{x:159,y:458,t:1527269109700};\\\", \\\"{x:159,y:459,t:1527269109758};\\\", \\\"{x:176,y:457,t:1527269125241};\\\", \\\"{x:215,y:457,t:1527269125251};\\\", \\\"{x:301,y:457,t:1527269125267};\\\", \\\"{x:332,y:456,t:1527269125284};\\\", \\\"{x:345,y:451,t:1527269125300};\\\", \\\"{x:356,y:441,t:1527269125318};\\\", \\\"{x:377,y:420,t:1527269125335};\\\", \\\"{x:395,y:413,t:1527269125350};\\\", \\\"{x:417,y:405,t:1527269125368};\\\", \\\"{x:439,y:396,t:1527269125384};\\\", \\\"{x:456,y:388,t:1527269125401};\\\", \\\"{x:467,y:384,t:1527269125418};\\\", \\\"{x:477,y:382,t:1527269125434};\\\", \\\"{x:487,y:382,t:1527269125452};\\\", \\\"{x:503,y:384,t:1527269125467};\\\", \\\"{x:527,y:394,t:1527269125485};\\\", \\\"{x:567,y:411,t:1527269125501};\\\", \\\"{x:634,y:434,t:1527269125518};\\\", \\\"{x:758,y:478,t:1527269125535};\\\", \\\"{x:866,y:525,t:1527269125552};\\\", \\\"{x:976,y:571,t:1527269125567};\\\", \\\"{x:1072,y:611,t:1527269125584};\\\", \\\"{x:1124,y:634,t:1527269125601};\\\", \\\"{x:1140,y:643,t:1527269125618};\\\", \\\"{x:1141,y:643,t:1527269125635};\\\", \\\"{x:1137,y:641,t:1527269125728};\\\", \\\"{x:1128,y:636,t:1527269125735};\\\", \\\"{x:1111,y:622,t:1527269125752};\\\", \\\"{x:1094,y:612,t:1527269125768};\\\", \\\"{x:1072,y:593,t:1527269125784};\\\", \\\"{x:1030,y:565,t:1527269125801};\\\", \\\"{x:978,y:533,t:1527269125818};\\\", \\\"{x:936,y:511,t:1527269125835};\\\", \\\"{x:913,y:501,t:1527269125851};\\\", \\\"{x:895,y:493,t:1527269125867};\\\", \\\"{x:879,y:486,t:1527269125884};\\\", \\\"{x:865,y:481,t:1527269125900};\\\", \\\"{x:858,y:478,t:1527269125917};\\\", \\\"{x:853,y:476,t:1527269125934};\\\", \\\"{x:851,y:476,t:1527269125951};\\\", \\\"{x:850,y:476,t:1527269126030};\\\", \\\"{x:849,y:475,t:1527269126055};\\\", \\\"{x:848,y:475,t:1527269126071};\\\", \\\"{x:847,y:474,t:1527269126087};\\\", \\\"{x:846,y:472,t:1527269126120};\\\", \\\"{x:843,y:468,t:1527269126135};\\\", \\\"{x:841,y:467,t:1527269126152};\\\", \\\"{x:840,y:466,t:1527269146471};\\\", \\\"{x:827,y:466,t:1527269146479};\\\", \\\"{x:813,y:466,t:1527269146494};\\\", \\\"{x:781,y:466,t:1527269146510};\\\", \\\"{x:735,y:462,t:1527269146526};\\\", \\\"{x:727,y:462,t:1527269146535};\\\", \\\"{x:715,y:462,t:1527269146552};\\\", \\\"{x:713,y:462,t:1527269146568};\\\", \\\"{x:712,y:462,t:1527269146584};\\\", \\\"{x:711,y:462,t:1527269146622};\\\", \\\"{x:708,y:462,t:1527269146634};\\\", \\\"{x:704,y:462,t:1527269146651};\\\", \\\"{x:698,y:462,t:1527269146668};\\\", \\\"{x:686,y:457,t:1527269146685};\\\", \\\"{x:665,y:452,t:1527269146702};\\\", \\\"{x:631,y:446,t:1527269146719};\\\", \\\"{x:611,y:446,t:1527269146734};\\\", \\\"{x:589,y:446,t:1527269146751};\\\", \\\"{x:571,y:446,t:1527269146769};\\\", \\\"{x:563,y:445,t:1527269146786};\\\", \\\"{x:560,y:445,t:1527269146802};\\\", \\\"{x:559,y:445,t:1527269146879};\\\", \\\"{x:559,y:448,t:1527269146904};\\\", \\\"{x:559,y:450,t:1527269146918};\\\", \\\"{x:561,y:453,t:1527269146935};\\\", \\\"{x:562,y:454,t:1527269146952};\\\", \\\"{x:563,y:456,t:1527269146968};\\\", \\\"{x:564,y:457,t:1527269146985};\\\", \\\"{x:566,y:458,t:1527269147003};\\\", \\\"{x:570,y:459,t:1527269147018};\\\", \\\"{x:582,y:461,t:1527269147035};\\\", \\\"{x:597,y:462,t:1527269147053};\\\", \\\"{x:619,y:464,t:1527269147069};\\\", \\\"{x:637,y:467,t:1527269147085};\\\", \\\"{x:651,y:467,t:1527269147102};\\\", \\\"{x:665,y:467,t:1527269147118};\\\", \\\"{x:667,y:467,t:1527269147136};\\\", \\\"{x:665,y:467,t:1527269147295};\\\", \\\"{x:659,y:467,t:1527269147303};\\\", \\\"{x:644,y:467,t:1527269147319};\\\", \\\"{x:632,y:465,t:1527269147337};\\\", \\\"{x:622,y:462,t:1527269147352};\\\", \\\"{x:617,y:461,t:1527269147369};\\\", \\\"{x:616,y:461,t:1527269147385};\\\", \\\"{x:616,y:462,t:1527269148319};\\\", \\\"{x:616,y:463,t:1527269148337};\\\", \\\"{x:616,y:465,t:1527269148353};\\\", \\\"{x:616,y:467,t:1527269148370};\\\", \\\"{x:616,y:470,t:1527269148387};\\\", \\\"{x:617,y:472,t:1527269148403};\\\", \\\"{x:617,y:475,t:1527269148421};\\\", \\\"{x:618,y:478,t:1527269148436};\\\", \\\"{x:619,y:482,t:1527269148453};\\\", \\\"{x:621,y:486,t:1527269148470};\\\", \\\"{x:623,y:494,t:1527269148486};\\\", \\\"{x:625,y:498,t:1527269148503};\\\", \\\"{x:626,y:501,t:1527269148519};\\\", \\\"{x:628,y:505,t:1527269148536};\\\", \\\"{x:629,y:509,t:1527269148554};\\\", \\\"{x:634,y:515,t:1527269148570};\\\", \\\"{x:636,y:518,t:1527269148587};\\\", \\\"{x:640,y:524,t:1527269148604};\\\", \\\"{x:645,y:532,t:1527269148620};\\\", \\\"{x:650,y:538,t:1527269148637};\\\", \\\"{x:656,y:546,t:1527269148654};\\\", \\\"{x:660,y:553,t:1527269148669};\\\", \\\"{x:673,y:568,t:1527269148687};\\\", \\\"{x:681,y:579,t:1527269148704};\\\", \\\"{x:695,y:593,t:1527269148720};\\\", \\\"{x:709,y:608,t:1527269148736};\\\", \\\"{x:729,y:624,t:1527269148753};\\\", \\\"{x:746,y:641,t:1527269148769};\\\", \\\"{x:759,y:652,t:1527269148787};\\\", \\\"{x:765,y:658,t:1527269148803};\\\", \\\"{x:767,y:659,t:1527269148821};\\\", \\\"{x:761,y:659,t:1527269154264};\\\", \\\"{x:751,y:659,t:1527269154275};\\\", \\\"{x:735,y:659,t:1527269154292};\\\", \\\"{x:716,y:658,t:1527269154308};\\\", \\\"{x:700,y:657,t:1527269154325};\\\", \\\"{x:688,y:655,t:1527269154341};\\\", \\\"{x:676,y:655,t:1527269154358};\\\", \\\"{x:662,y:655,t:1527269154375};\\\", \\\"{x:652,y:657,t:1527269154391};\\\", \\\"{x:641,y:662,t:1527269154408};\\\", \\\"{x:631,y:667,t:1527269154425};\\\", \\\"{x:615,y:673,t:1527269154441};\\\", \\\"{x:606,y:678,t:1527269154459};\\\", \\\"{x:596,y:683,t:1527269154475};\\\", \\\"{x:589,y:688,t:1527269154491};\\\", \\\"{x:583,y:693,t:1527269154508};\\\", \\\"{x:577,y:696,t:1527269154525};\\\", \\\"{x:574,y:698,t:1527269154541};\\\", \\\"{x:571,y:699,t:1527269154559};\\\", \\\"{x:569,y:700,t:1527269154576};\\\", \\\"{x:567,y:700,t:1527269154959};\\\", \\\"{x:566,y:700,t:1527269154975};\\\", \\\"{x:564,y:700,t:1527269154994};\\\", \\\"{x:562,y:700,t:1527269155009};\\\", \\\"{x:561,y:700,t:1527269155024};\\\", \\\"{x:560,y:700,t:1527269155042};\\\", \\\"{x:558,y:700,t:1527269155058};\\\", \\\"{x:557,y:700,t:1527269155075};\\\", \\\"{x:556,y:700,t:1527269155091};\\\", \\\"{x:555,y:700,t:1527269155126};\\\", \\\"{x:554,y:700,t:1527269155142};\\\", \\\"{x:553,y:700,t:1527269155158};\\\", \\\"{x:552,y:700,t:1527269155174};\\\", \\\"{x:550,y:701,t:1527269155192};\\\", \\\"{x:549,y:701,t:1527269155326};\\\", \\\"{x:548,y:701,t:1527269155345};\\\" ] }, { \\\"rt\\\": 110162, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 20, \\\"time_elapsed\\\": 809510, \\\"internal_node_id\\\": \\\"0.0-7.0-0.0\\\", \\\"subject\\\": \\\"YC7SX\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"mike\\\", \\\"condition\\\": \\\"115-late\\\", \\\"q\\\": 16, \\\"answer\\\": \\\"if you look at the horizontal axis and look at the 12pm mark you can see which shifts start at 12pm by seeing which dot matches up to that mark vertically.\\\\n\\\", \\\"block\\\": \\\"triangular_testing\\\" }, { \\\"rt\\\": 8402, \\\"responses\\\": \\\"{\\\\\\\"Q0\\\\\\\":\\\\\\\"20\\\\\\\",\\\\\\\"Q1\\\\\\\":\\\\\\\"USA\\\\\\\"}\\\", \\\"block\\\": \\\"demo-1\\\", \\\"trial_type\\\": \\\"survey-text\\\", \\\"trial_index\\\": 21, \\\"time_elapsed\\\": 818917, \\\"internal_node_id\\\": \\\"0.0-8.0\\\", \\\"subject\\\": \\\"YC7SX\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"mike\\\", \\\"condition\\\": \\\"115-late\\\" }, { \\\"rt\\\": 18001, \\\"responses\\\": \\\"{\\\\\\\"Q0\\\\\\\":\\\\\\\"English\\\\\\\",\\\\\\\"Q1\\\\\\\":\\\\\\\"Third\\\\\\\",\\\\\\\"Q2\\\\\\\":\\\\\\\"Engineering\\\\\\\",\\\\\\\"Q3\\\\\\\":\\\\\\\"Female\\\\\\\"}\\\", \\\"block\\\": \\\"demo-2\\\", \\\"trial_type\\\": \\\"survey-multi-choice\\\", \\\"trial_index\\\": 22, \\\"time_elapsed\\\": 837930, \\\"internal_node_id\\\": \\\"0.0-9.0\\\", \\\"subject\\\": \\\"YC7SX\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"mike\\\", \\\"condition\\\": \\\"115-late\\\" }, { \\\"rt\\\": 112045, \\\"url\\\": \\\"../views/src/external/debrief.html\\\", \\\"block\\\": \\\"debrief\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 23, \\\"time_elapsed\\\": 951310, \\\"internal_node_id\\\": \\\"0.0-10.0\\\", \\\"subject\\\": \\\"YC7SX\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"mike\\\", \\\"condition\\\": \\\"115-late\\\" } ]\",\"parentNode\":{\"id\":2766}}],[],[]]}"
    }
  ],
  "initialDom": "{\"f\":\"initialize\",\"args\":[1,[{\"nodeType\":10,\"id\":2,\"name\":\"html\",\"publicId\":\"\",\"systemId\":\"\"},{\"nodeType\":1,\"id\":3,\"tagName\":\"HTML\",\"attributes\":{\"class\":\"fa-events-icons-ready\"},\"childNodes\":[{\"nodeType\":1,\"id\":4,\"tagName\":\"HEAD\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":5,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":6,\"textContent\":\" \"},{\"nodeType\":1,\"id\":7,\"tagName\":\"TITLE\",\"attributes\":{},\"childNodes\":[{\"nodeType\":3,\"id\":8,\"textContent\":\"FOX2YP\"}]},{\"nodeType\":3,\"id\":9,\"textContent\":\" \"},{\"nodeType\":8,\"id\":10},{\"nodeType\":3,\"id\":11,\"textContent\":\" \"},{\"nodeType\":1,\"id\":12,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":13,\"textContent\":\" \"},{\"nodeType\":1,\"id\":14,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":15,\"textContent\":\" \"},{\"nodeType\":1,\"id\":16,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":17,\"textContent\":\" \"},{\"nodeType\":1,\"id\":18,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":19,\"textContent\":\" \"},{\"nodeType\":1,\"id\":20,\"tagName\":\"SCRIPT\"},{\"nodeType\":1,\"id\":21,\"tagName\":\"LINK\",\"attributes\":{\"href\":\"https://use.fontawesome.com/945539d961.css\",\"media\":\"all\",\"rel\":\"stylesheet\"}},{\"nodeType\":3,\"id\":22,\"textContent\":\" \"},{\"nodeType\":8,\"id\":23},{\"nodeType\":3,\"id\":24,\"textContent\":\" \"},{\"nodeType\":1,\"id\":25,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":26,\"textContent\":\" \"},{\"nodeType\":1,\"id\":27,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":28,\"textContent\":\" \"},{\"nodeType\":1,\"id\":29,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":30,\"textContent\":\" \"},{\"nodeType\":1,\"id\":31,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":32,\"textContent\":\" \"},{\"nodeType\":1,\"id\":33,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":34,\"textContent\":\" \"},{\"nodeType\":1,\"id\":35,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":36,\"textContent\":\" \"},{\"nodeType\":1,\"id\":37,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":38,\"textContent\":\" \"},{\"nodeType\":8,\"id\":39},{\"nodeType\":3,\"id\":40,\"textContent\":\" \"},{\"nodeType\":1,\"id\":41,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":42,\"textContent\":\" \"},{\"nodeType\":8,\"id\":43},{\"nodeType\":3,\"id\":44,\"textContent\":\" \"},{\"nodeType\":8,\"id\":45},{\"nodeType\":3,\"id\":46,\"textContent\":\" \"},{\"nodeType\":1,\"id\":47,\"tagName\":\"LINK\",\"attributes\":{\"href\":\"../views/jsPsych/css/jspsych.css\",\"rel\":\"stylesheet\",\"type\":\"text/css\"}},{\"nodeType\":3,\"id\":48,\"textContent\":\" \"},{\"nodeType\":1,\"id\":49,\"tagName\":\"LINK\",\"attributes\":{\"href\":\"../css/styles.css\",\"rel\":\"stylesheet\",\"type\":\"text/css\"}},{\"nodeType\":3,\"id\":50,\"textContent\":\" \"},{\"nodeType\":1,\"id\":51,\"tagName\":\"SCRIPT\"},{\"nodeType\":1,\"id\":52,\"tagName\":\"SCRIPT\"}]},{\"nodeType\":3,\"id\":53,\"textContent\":\" \"},{\"nodeType\":8,\"id\":54},{\"nodeType\":3,\"id\":55,\"textContent\":\" \"},{\"nodeType\":1,\"id\":56,\"tagName\":\"BODY\",\"attributes\":{\"class\":\"jspsych-display-element\"},\"childNodes\":[{\"nodeType\":3,\"id\":57,\"textContent\":\" \"},{\"nodeType\":1,\"id\":58,\"tagName\":\"META\",\"attributes\":{\"charset\":\"utf-8\"}},{\"nodeType\":3,\"id\":59,\"textContent\":\" \"},{\"nodeType\":8,\"id\":60},{\"nodeType\":3,\"id\":61,\"textContent\":\" \"},{\"nodeType\":1,\"id\":62,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":63,\"textContent\":\" \"},{\"nodeType\":1,\"id\":64,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":65,\"textContent\":\" \"},{\"nodeType\":1,\"id\":66,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":67,\"textContent\":\" \"},{\"nodeType\":1,\"id\":68,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":69,\"textContent\":\" \"},{\"nodeType\":1,\"id\":70,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":71,\"textContent\":\" \"},{\"nodeType\":1,\"id\":72,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":73,\"textContent\":\" \"},{\"nodeType\":1,\"id\":74,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"stimulus\"},\"childNodes\":[{\"nodeType\":3,\"id\":75,\"textContent\":\" \"},{\"nodeType\":1,\"id\":76,\"tagName\":\"P\",\"attributes\":{\"class\":\"userid\",\"id\":\"userid\"},\"childNodes\":[{\"nodeType\":3,\"id\":77,\"textContent\":\"YC7SX\"}]},{\"nodeType\":3,\"id\":78,\"textContent\":\" \"},{\"nodeType\":1,\"id\":79,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"userinput\"},\"childNodes\":[{\"nodeType\":3,\"id\":80,\"textContent\":\" \"},{\"nodeType\":8,\"id\":81},{\"nodeType\":3,\"id\":82,\"textContent\":\" \"},{\"nodeType\":1,\"id\":83,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"legend\",\"id\":\"hint-interactive\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":84,\"textContent\":\" \"},{\"nodeType\":1,\"id\":85,\"tagName\":\"P\",\"attributes\":{},\"childNodes\":[{\"nodeType\":3,\"id\":86,\"textContent\":\"Hint: Hover your mouse over the data points in the graph\"}]},{\"nodeType\":3,\"id\":87,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":88,\"textContent\":\" \"},{\"nodeType\":8,\"id\":89},{\"nodeType\":3,\"id\":90,\"textContent\":\" \"},{\"nodeType\":8,\"id\":91},{\"nodeType\":3,\"id\":92,\"textContent\":\" \"},{\"nodeType\":1,\"id\":93,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"test\"},\"childNodes\":[{\"nodeType\":3,\"id\":94,\"textContent\":\" \"},{\"nodeType\":1,\"id\":95,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"acme\",\"id\":\"acme.starttime\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":96,\"textContent\":\" \"},{\"nodeType\":1,\"id\":97,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":98,\"textContent\":\"Which shift(s) start at 11 am? \"}]},{\"nodeType\":3,\"id\":99,\"textContent\":\" \"},{\"nodeType\":1,\"id\":100,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":101,\"textContent\":\" \"},{\"nodeType\":1,\"id\":102,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":103,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":104,\"textContent\":\" \"},{\"nodeType\":1,\"id\":105,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":106,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":107,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":108,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":109,\"textContent\":\" \"},{\"nodeType\":1,\"id\":110,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":111,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":112,\"textContent\":\" \"},{\"nodeType\":1,\"id\":113,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":114,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":115,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":116,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":117,\"textContent\":\" \"},{\"nodeType\":1,\"id\":118,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":119,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":120,\"textContent\":\" \"},{\"nodeType\":1,\"id\":121,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":122,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":123,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":124,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":125,\"textContent\":\" \"},{\"nodeType\":1,\"id\":126,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":127,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":128,\"textContent\":\" \"},{\"nodeType\":1,\"id\":129,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":130,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":131,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":132,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":133,\"textContent\":\" \"},{\"nodeType\":1,\"id\":134,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":135,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":136,\"textContent\":\" \"},{\"nodeType\":1,\"id\":137,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":138,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":139,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":140,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":141,\"textContent\":\" \"},{\"nodeType\":1,\"id\":142,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":143,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":144,\"textContent\":\" \"},{\"nodeType\":1,\"id\":145,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":146,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":147,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":148,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":149,\"textContent\":\" \"},{\"nodeType\":1,\"id\":150,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":151,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":152,\"textContent\":\" \"},{\"nodeType\":1,\"id\":153,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":154,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":155,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":156,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":157,\"textContent\":\" \"},{\"nodeType\":1,\"id\":158,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":159,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":160,\"textContent\":\" \"},{\"nodeType\":1,\"id\":161,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":162,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":163,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":164,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":165,\"textContent\":\" \"},{\"nodeType\":1,\"id\":166,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":167,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":168,\"textContent\":\" \"},{\"nodeType\":1,\"id\":169,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":170,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":171,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":172,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":173,\"textContent\":\" \"},{\"nodeType\":1,\"id\":174,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":175,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":176,\"textContent\":\" \"},{\"nodeType\":1,\"id\":177,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":178,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":179,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":180,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":181,\"textContent\":\" \"},{\"nodeType\":1,\"id\":182,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":183,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":184,\"textContent\":\" \"},{\"nodeType\":1,\"id\":185,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"U\",\"value\":\"\"}},{\"nodeType\":3,\"id\":186,\"textContent\":\"U \"},{\"nodeType\":1,\"id\":187,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":188,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":189,\"textContent\":\" \"},{\"nodeType\":1,\"id\":190,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":191,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":192,\"textContent\":\" \"},{\"nodeType\":1,\"id\":193,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":194,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":195,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":196,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":197,\"textContent\":\" \"},{\"nodeType\":1,\"id\":198,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":199,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":200,\"textContent\":\" \"},{\"nodeType\":1,\"id\":201,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":202,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":203,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":204,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":205,\"textContent\":\" \"},{\"nodeType\":1,\"id\":206,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":207,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":208,\"textContent\":\" \"},{\"nodeType\":1,\"id\":209,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":210,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":211,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":212,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":213,\"textContent\":\" \"},{\"nodeType\":1,\"id\":214,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":215,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":216,\"textContent\":\" \"},{\"nodeType\":1,\"id\":217,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":218,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":219,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":220,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":221,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":222,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":223,\"textContent\":\" \"},{\"nodeType\":1,\"id\":224,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"acme\",\"id\":\"acme.starts\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":225,\"textContent\":\" \"},{\"nodeType\":1,\"id\":226,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":227,\"textContent\":\"Which shift(s) start at the same time as D?\"}]},{\"nodeType\":3,\"id\":228,\"textContent\":\" \"},{\"nodeType\":1,\"id\":229,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":230,\"textContent\":\" \"},{\"nodeType\":1,\"id\":231,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":232,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":233,\"textContent\":\" \"},{\"nodeType\":1,\"id\":234,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":235,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":236,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":237,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":238,\"textContent\":\" \"},{\"nodeType\":1,\"id\":239,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":240,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":241,\"textContent\":\" \"},{\"nodeType\":1,\"id\":242,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":243,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":244,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":245,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":246,\"textContent\":\" \"},{\"nodeType\":1,\"id\":247,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":248,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":249,\"textContent\":\" \"},{\"nodeType\":1,\"id\":250,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":251,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":252,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":253,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":254,\"textContent\":\" \"},{\"nodeType\":1,\"id\":255,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":256,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":257,\"textContent\":\" \"},{\"nodeType\":1,\"id\":258,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":259,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":260,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":261,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":262,\"textContent\":\" \"},{\"nodeType\":1,\"id\":263,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":264,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":265,\"textContent\":\" \"},{\"nodeType\":1,\"id\":266,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":267,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":268,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":269,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":270,\"textContent\":\" \"},{\"nodeType\":1,\"id\":271,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":272,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":273,\"textContent\":\" \"},{\"nodeType\":1,\"id\":274,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":275,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":276,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":277,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":278,\"textContent\":\" \"},{\"nodeType\":1,\"id\":279,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":280,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":281,\"textContent\":\" \"},{\"nodeType\":1,\"id\":282,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":283,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":284,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":285,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":286,\"textContent\":\" \"},{\"nodeType\":1,\"id\":287,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":288,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":289,\"textContent\":\" \"},{\"nodeType\":1,\"id\":290,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":291,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":292,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":293,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":294,\"textContent\":\" \"},{\"nodeType\":1,\"id\":295,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":296,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":297,\"textContent\":\" \"},{\"nodeType\":1,\"id\":298,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":299,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":300,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":301,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":302,\"textContent\":\" \"},{\"nodeType\":1,\"id\":303,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":304,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":305,\"textContent\":\" \"},{\"nodeType\":1,\"id\":306,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":307,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":308,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":309,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":310,\"textContent\":\" \"},{\"nodeType\":1,\"id\":311,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":312,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":313,\"textContent\":\" \"},{\"nodeType\":1,\"id\":314,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"U\",\"value\":\"\"}},{\"nodeType\":3,\"id\":315,\"textContent\":\"U \"},{\"nodeType\":1,\"id\":316,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":317,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":318,\"textContent\":\" \"},{\"nodeType\":1,\"id\":319,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":320,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":321,\"textContent\":\" \"},{\"nodeType\":1,\"id\":322,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":323,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":324,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":325,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":326,\"textContent\":\" \"},{\"nodeType\":1,\"id\":327,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":328,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":329,\"textContent\":\" \"},{\"nodeType\":1,\"id\":330,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":331,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":332,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":333,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":334,\"textContent\":\" \"},{\"nodeType\":1,\"id\":335,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":336,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":337,\"textContent\":\" \"},{\"nodeType\":1,\"id\":338,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":339,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":340,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":341,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":342,\"textContent\":\" \"},{\"nodeType\":1,\"id\":343,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":344,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":345,\"textContent\":\" \"},{\"nodeType\":1,\"id\":346,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":347,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":348,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":349,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":350,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":351,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":352,\"textContent\":\" \"},{\"nodeType\":1,\"id\":353,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"acme\",\"id\":\"acme.meets\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":354,\"textContent\":\" \"},{\"nodeType\":1,\"id\":355,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":356,\"textContent\":\"Which shift(s) begin when C ends?\"}]},{\"nodeType\":3,\"id\":357,\"textContent\":\" \"},{\"nodeType\":1,\"id\":358,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":359,\"textContent\":\" \"},{\"nodeType\":1,\"id\":360,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":361,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":362,\"textContent\":\" \"},{\"nodeType\":1,\"id\":363,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":364,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":365,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":366,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":367,\"textContent\":\" \"},{\"nodeType\":1,\"id\":368,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":369,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":370,\"textContent\":\" \"},{\"nodeType\":1,\"id\":371,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":372,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":373,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":374,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":375,\"textContent\":\" \"},{\"nodeType\":1,\"id\":376,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":377,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":378,\"textContent\":\" \"},{\"nodeType\":1,\"id\":379,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":380,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":381,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":382,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":383,\"textContent\":\" \"},{\"nodeType\":1,\"id\":384,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":385,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":386,\"textContent\":\" \"},{\"nodeType\":1,\"id\":387,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":388,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":389,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":390,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":391,\"textContent\":\" \"},{\"nodeType\":1,\"id\":392,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":393,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":394,\"textContent\":\" \"},{\"nodeType\":1,\"id\":395,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":396,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":397,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":398,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":399,\"textContent\":\" \"},{\"nodeType\":1,\"id\":400,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":401,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":402,\"textContent\":\" \"},{\"nodeType\":1,\"id\":403,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":404,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":405,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":406,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":407,\"textContent\":\" \"},{\"nodeType\":1,\"id\":408,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":409,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":410,\"textContent\":\" \"},{\"nodeType\":1,\"id\":411,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":412,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":413,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":414,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":415,\"textContent\":\" \"},{\"nodeType\":1,\"id\":416,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":417,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":418,\"textContent\":\" \"},{\"nodeType\":1,\"id\":419,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":420,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":421,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":422,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":423,\"textContent\":\" \"},{\"nodeType\":1,\"id\":424,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":425,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":426,\"textContent\":\" \"},{\"nodeType\":1,\"id\":427,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":428,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":429,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":430,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":431,\"textContent\":\" \"},{\"nodeType\":1,\"id\":432,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":433,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":434,\"textContent\":\" \"},{\"nodeType\":1,\"id\":435,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":436,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":437,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":438,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":439,\"textContent\":\" \"},{\"nodeType\":1,\"id\":440,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":441,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":442,\"textContent\":\" \"},{\"nodeType\":1,\"id\":443,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"U\",\"value\":\"\"}},{\"nodeType\":3,\"id\":444,\"textContent\":\"U \"},{\"nodeType\":1,\"id\":445,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":446,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":447,\"textContent\":\" \"},{\"nodeType\":1,\"id\":448,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":449,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":450,\"textContent\":\" \"},{\"nodeType\":1,\"id\":451,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":452,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":453,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":454,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":455,\"textContent\":\" \"},{\"nodeType\":1,\"id\":456,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":457,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":458,\"textContent\":\" \"},{\"nodeType\":1,\"id\":459,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":460,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":461,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":462,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":463,\"textContent\":\" \"},{\"nodeType\":1,\"id\":464,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":465,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":466,\"textContent\":\" \"},{\"nodeType\":1,\"id\":467,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":468,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":469,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":470,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":471,\"textContent\":\" \"},{\"nodeType\":1,\"id\":472,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":473,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":474,\"textContent\":\" \"},{\"nodeType\":1,\"id\":475,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":476,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":477,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":478,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":479,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":480,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":481,\"textContent\":\" \"},{\"nodeType\":1,\"id\":482,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"acme\",\"id\":\"acme.endtime\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":483,\"textContent\":\" \"},{\"nodeType\":1,\"id\":484,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":485,\"textContent\":\" Which shift(s) end at 4 pm?\"}]},{\"nodeType\":3,\"id\":486,\"textContent\":\" \"},{\"nodeType\":1,\"id\":487,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":488,\"textContent\":\" \"},{\"nodeType\":1,\"id\":489,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":490,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":491,\"textContent\":\" \"},{\"nodeType\":1,\"id\":492,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":493,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":494,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":495,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":496,\"textContent\":\" \"},{\"nodeType\":1,\"id\":497,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":498,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":499,\"textContent\":\" \"},{\"nodeType\":1,\"id\":500,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":501,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":502,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":503,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":504,\"textContent\":\" \"},{\"nodeType\":1,\"id\":505,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":506,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":507,\"textContent\":\" \"},{\"nodeType\":1,\"id\":508,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":509,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":510,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":511,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":512,\"textContent\":\" \"},{\"nodeType\":1,\"id\":513,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":514,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":515,\"textContent\":\" \"},{\"nodeType\":1,\"id\":516,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":517,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":518,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":519,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":520,\"textContent\":\" \"},{\"nodeType\":1,\"id\":521,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":522,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":523,\"textContent\":\" \"},{\"nodeType\":1,\"id\":524,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":525,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":526,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":527,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":528,\"textContent\":\" \"},{\"nodeType\":1,\"id\":529,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":530,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":531,\"textContent\":\" \"},{\"nodeType\":1,\"id\":532,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":533,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":534,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":535,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":536,\"textContent\":\" \"},{\"nodeType\":1,\"id\":537,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":538,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":539,\"textContent\":\" \"},{\"nodeType\":1,\"id\":540,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":541,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":542,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":543,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":544,\"textContent\":\" \"},{\"nodeType\":1,\"id\":545,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":546,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":547,\"textContent\":\" \"},{\"nodeType\":1,\"id\":548,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":549,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":550,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":551,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":552,\"textContent\":\" \"},{\"nodeType\":1,\"id\":553,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":554,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":555,\"textContent\":\" \"},{\"nodeType\":1,\"id\":556,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":557,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":558,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":559,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":560,\"textContent\":\" \"},{\"nodeType\":1,\"id\":561,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":562,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":563,\"textContent\":\" \"},{\"nodeType\":1,\"id\":564,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":565,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":566,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":567,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":568,\"textContent\":\" \"},{\"nodeType\":1,\"id\":569,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":570,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":571,\"textContent\":\" \"},{\"nodeType\":1,\"id\":572,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"U\",\"value\":\"\"}},{\"nodeType\":3,\"id\":573,\"textContent\":\"U \"},{\"nodeType\":1,\"id\":574,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":575,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":576,\"textContent\":\" \"},{\"nodeType\":1,\"id\":577,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":578,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":579,\"textContent\":\" \"},{\"nodeType\":1,\"id\":580,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":581,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":582,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":583,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":584,\"textContent\":\" \"},{\"nodeType\":1,\"id\":585,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":586,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":587,\"textContent\":\" \"},{\"nodeType\":1,\"id\":588,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":589,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":590,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":591,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":592,\"textContent\":\" \"},{\"nodeType\":1,\"id\":593,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":594,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":595,\"textContent\":\" \"},{\"nodeType\":1,\"id\":596,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":597,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":598,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":599,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":600,\"textContent\":\" \"},{\"nodeType\":1,\"id\":601,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":602,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":603,\"textContent\":\" \"},{\"nodeType\":1,\"id\":604,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":605,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":606,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":607,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":608,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":609,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":610,\"textContent\":\" \"},{\"nodeType\":1,\"id\":611,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"acme\",\"id\":\"acme.midpoint\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":612,\"textContent\":\" \"},{\"nodeType\":1,\"id\":613,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":614,\"textContent\":\"Coffee breaks happen halfway through a shift.\"},{\"nodeType\":1,\"id\":615,\"tagName\":\"BR\",\"attributes\":{}},{\"nodeType\":3,\"id\":616,\"textContent\":\" Which shift(s) share a break with I?\"}]},{\"nodeType\":3,\"id\":617,\"textContent\":\" \"},{\"nodeType\":1,\"id\":618,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":619,\"textContent\":\" \"},{\"nodeType\":1,\"id\":620,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":621,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":622,\"textContent\":\" \"},{\"nodeType\":1,\"id\":623,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":624,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":625,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":626,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":627,\"textContent\":\" \"},{\"nodeType\":1,\"id\":628,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":629,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":630,\"textContent\":\" \"},{\"nodeType\":1,\"id\":631,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":632,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":633,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":634,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":635,\"textContent\":\" \"},{\"nodeType\":1,\"id\":636,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":637,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":638,\"textContent\":\" \"},{\"nodeType\":1,\"id\":639,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":640,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":641,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":642,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":643,\"textContent\":\" \"},{\"nodeType\":1,\"id\":644,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":645,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":646,\"textContent\":\" \"},{\"nodeType\":1,\"id\":647,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":648,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":649,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":650,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":651,\"textContent\":\" \"},{\"nodeType\":1,\"id\":652,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":653,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":654,\"textContent\":\" \"},{\"nodeType\":1,\"id\":655,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":656,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":657,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":658,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":659,\"textContent\":\" \"},{\"nodeType\":1,\"id\":660,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":661,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":662,\"textContent\":\" \"},{\"nodeType\":1,\"id\":663,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":664,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":665,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":666,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":667,\"textContent\":\" \"},{\"nodeType\":1,\"id\":668,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":669,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":670,\"textContent\":\" \"},{\"nodeType\":1,\"id\":671,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":672,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":673,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":674,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":675,\"textContent\":\" \"},{\"nodeType\":1,\"id\":676,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":677,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":678,\"textContent\":\" \"},{\"nodeType\":1,\"id\":679,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":680,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":681,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":682,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":683,\"textContent\":\" \"},{\"nodeType\":1,\"id\":684,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":685,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":686,\"textContent\":\" \"},{\"nodeType\":1,\"id\":687,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":688,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":689,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":690,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":691,\"textContent\":\" \"},{\"nodeType\":1,\"id\":692,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":693,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":694,\"textContent\":\" \"},{\"nodeType\":1,\"id\":695,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":696,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":697,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":698,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":699,\"textContent\":\" \"},{\"nodeType\":1,\"id\":700,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":701,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":702,\"textContent\":\" \"},{\"nodeType\":1,\"id\":703,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"U\",\"value\":\"\"}},{\"nodeType\":3,\"id\":704,\"textContent\":\"U \"},{\"nodeType\":1,\"id\":705,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":706,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":707,\"textContent\":\" \"},{\"nodeType\":1,\"id\":708,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":709,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":710,\"textContent\":\" \"},{\"nodeType\":1,\"id\":711,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":712,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":713,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":714,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":715,\"textContent\":\" \"},{\"nodeType\":1,\"id\":716,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":717,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":718,\"textContent\":\" \"},{\"nodeType\":1,\"id\":719,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":720,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":721,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":722,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":723,\"textContent\":\" \"},{\"nodeType\":1,\"id\":724,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":725,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":726,\"textContent\":\" \"},{\"nodeType\":1,\"id\":727,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":728,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":729,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":730,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":731,\"textContent\":\" \"},{\"nodeType\":1,\"id\":732,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":733,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":734,\"textContent\":\" \"},{\"nodeType\":1,\"id\":735,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":736,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":737,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":738,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":739,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":740,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":741,\"textContent\":\" \"},{\"nodeType\":1,\"id\":742,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.duration\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":743,\"textContent\":\" \"},{\"nodeType\":1,\"id\":744,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":745,\"textContent\":\"Which shift(s) are six hours long?\"}]},{\"nodeType\":3,\"id\":746,\"textContent\":\" \"},{\"nodeType\":1,\"id\":747,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":748,\"textContent\":\" \"},{\"nodeType\":1,\"id\":749,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":750,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":751,\"textContent\":\" \"},{\"nodeType\":1,\"id\":752,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":753,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":754,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":755,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":756,\"textContent\":\" \"},{\"nodeType\":1,\"id\":757,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":758,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":759,\"textContent\":\" \"},{\"nodeType\":1,\"id\":760,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":761,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":762,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":763,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":764,\"textContent\":\" \"},{\"nodeType\":1,\"id\":765,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":766,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":767,\"textContent\":\" \"},{\"nodeType\":1,\"id\":768,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":769,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":770,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":771,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":772,\"textContent\":\" \"},{\"nodeType\":1,\"id\":773,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":774,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":775,\"textContent\":\" \"},{\"nodeType\":1,\"id\":776,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":777,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":778,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":779,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":780,\"textContent\":\" \"},{\"nodeType\":1,\"id\":781,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":782,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":783,\"textContent\":\" \"},{\"nodeType\":1,\"id\":784,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":785,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":786,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":787,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":788,\"textContent\":\" \"},{\"nodeType\":1,\"id\":789,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":790,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":791,\"textContent\":\" \"},{\"nodeType\":1,\"id\":792,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":793,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":794,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":795,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":796,\"textContent\":\" \"},{\"nodeType\":1,\"id\":797,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":798,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":799,\"textContent\":\" \"},{\"nodeType\":1,\"id\":800,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":801,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":802,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":803,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":804,\"textContent\":\" \"},{\"nodeType\":1,\"id\":805,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":806,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":807,\"textContent\":\" \"},{\"nodeType\":1,\"id\":808,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":809,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":810,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":811,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":812,\"textContent\":\" \"},{\"nodeType\":1,\"id\":813,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":814,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":815,\"textContent\":\" \"},{\"nodeType\":1,\"id\":816,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":817,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":818,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":819,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":820,\"textContent\":\" \"},{\"nodeType\":1,\"id\":821,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":822,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":823,\"textContent\":\" \"},{\"nodeType\":1,\"id\":824,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":825,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":826,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":827,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":828,\"textContent\":\" \"},{\"nodeType\":1,\"id\":829,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":830,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":831,\"textContent\":\" \"},{\"nodeType\":1,\"id\":832,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":833,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":834,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":835,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":836,\"textContent\":\" \"},{\"nodeType\":1,\"id\":837,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":838,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":839,\"textContent\":\" \"},{\"nodeType\":1,\"id\":840,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":841,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":842,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":843,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":844,\"textContent\":\" \"},{\"nodeType\":1,\"id\":845,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":846,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":847,\"textContent\":\" \"},{\"nodeType\":1,\"id\":848,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":849,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":850,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":851,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":852,\"textContent\":\" \"},{\"nodeType\":1,\"id\":853,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":854,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":855,\"textContent\":\" \"},{\"nodeType\":1,\"id\":856,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":857,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":858,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":859,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":860,\"textContent\":\" \"},{\"nodeType\":1,\"id\":861,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":862,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":863,\"textContent\":\" \"},{\"nodeType\":1,\"id\":864,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":865,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":866,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":867,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":868,\"textContent\":\" \"},{\"nodeType\":1,\"id\":869,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":870,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":871,\"textContent\":\" \"},{\"nodeType\":1,\"id\":872,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":873,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":874,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":875,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":876,\"textContent\":\" \"},{\"nodeType\":1,\"id\":877,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":878,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":879,\"textContent\":\" \"},{\"nodeType\":1,\"id\":880,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":881,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":882,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":883,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":884,\"textContent\":\" \"},{\"nodeType\":1,\"id\":885,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":886,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":887,\"textContent\":\" \"},{\"nodeType\":1,\"id\":888,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":889,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":890,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":891,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":892,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":893,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":894,\"textContent\":\" \"},{\"nodeType\":1,\"id\":895,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.duration+starts\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":896,\"textContent\":\" \"},{\"nodeType\":1,\"id\":897,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":898,\"textContent\":\"Which 2 shifts less than 5 hours long start at the same time?\"}]},{\"nodeType\":3,\"id\":899,\"textContent\":\" \"},{\"nodeType\":1,\"id\":900,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":901,\"textContent\":\" \"},{\"nodeType\":1,\"id\":902,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":903,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":904,\"textContent\":\" \"},{\"nodeType\":1,\"id\":905,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":906,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":907,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":908,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":909,\"textContent\":\" \"},{\"nodeType\":1,\"id\":910,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":911,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":912,\"textContent\":\" \"},{\"nodeType\":1,\"id\":913,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":914,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":915,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":916,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":917,\"textContent\":\" \"},{\"nodeType\":1,\"id\":918,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":919,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":920,\"textContent\":\" \"},{\"nodeType\":1,\"id\":921,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":922,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":923,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":924,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":925,\"textContent\":\" \"},{\"nodeType\":1,\"id\":926,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":927,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":928,\"textContent\":\" \"},{\"nodeType\":1,\"id\":929,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":930,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":931,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":932,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":933,\"textContent\":\" \"},{\"nodeType\":1,\"id\":934,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":935,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":936,\"textContent\":\" \"},{\"nodeType\":1,\"id\":937,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":938,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":939,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":940,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":941,\"textContent\":\" \"},{\"nodeType\":1,\"id\":942,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":943,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":944,\"textContent\":\" \"},{\"nodeType\":1,\"id\":945,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":946,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":947,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":948,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":949,\"textContent\":\" \"},{\"nodeType\":1,\"id\":950,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":951,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":952,\"textContent\":\" \"},{\"nodeType\":1,\"id\":953,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":954,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":955,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":956,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":957,\"textContent\":\" \"},{\"nodeType\":1,\"id\":958,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":959,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":960,\"textContent\":\" \"},{\"nodeType\":1,\"id\":961,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":962,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":963,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":964,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":965,\"textContent\":\" \"},{\"nodeType\":1,\"id\":966,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":967,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":968,\"textContent\":\" \"},{\"nodeType\":1,\"id\":969,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":970,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":971,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":972,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":973,\"textContent\":\" \"},{\"nodeType\":1,\"id\":974,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":975,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":976,\"textContent\":\" \"},{\"nodeType\":1,\"id\":977,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":978,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":979,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":980,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":981,\"textContent\":\" \"},{\"nodeType\":1,\"id\":982,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":983,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":984,\"textContent\":\" \"},{\"nodeType\":1,\"id\":985,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":986,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":987,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":988,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":989,\"textContent\":\" \"},{\"nodeType\":1,\"id\":990,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":991,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":992,\"textContent\":\" \"},{\"nodeType\":1,\"id\":993,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":994,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":995,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":996,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":997,\"textContent\":\" \"},{\"nodeType\":1,\"id\":998,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":999,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1000,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1001,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1002,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":1003,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1004,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1005,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1006,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1007,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1008,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1009,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1010,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":1011,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1012,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1013,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1014,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1015,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1016,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1017,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1018,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":1019,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1020,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1021,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1022,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1023,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1024,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1025,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1026,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":1027,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1028,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1029,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1030,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1031,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1032,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1033,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1034,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":1035,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1036,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1037,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1038,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1039,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1040,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1041,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1042,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":1043,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1044,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1045,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1046,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1047,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1048,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.duration+contained\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":1049,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1050,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":1051,\"textContent\":\"Which shift(s) under 7 hours long starts before B starts, and ends after X ends?\"}]},{\"nodeType\":3,\"id\":1052,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1053,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":1054,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1055,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1056,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1057,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1058,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1059,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":1060,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1061,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1062,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1063,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1064,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1065,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1066,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1067,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":1068,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1069,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1070,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1071,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1072,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1073,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1074,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1075,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":1076,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1077,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1078,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1079,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1080,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1081,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1082,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1083,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":1084,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1085,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1086,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1087,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1088,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1089,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1090,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1091,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":1092,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1093,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1094,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1095,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1096,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1097,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1098,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1099,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":1100,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1101,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1102,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1103,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1104,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1105,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1106,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1107,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":1108,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1109,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1110,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1111,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1112,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1113,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1114,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1115,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":1116,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1117,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1118,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1119,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1120,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1121,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1122,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1123,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":1124,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1125,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1126,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1127,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1128,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1129,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1130,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1131,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":1132,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1133,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1134,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1135,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1136,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1137,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1138,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1139,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":1140,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1141,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1142,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1143,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1144,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1145,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1146,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1147,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":1148,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1149,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1150,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1151,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1152,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1153,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1154,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1155,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":1156,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1157,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1158,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1159,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1160,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1161,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1162,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1163,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":1164,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1165,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1166,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1167,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1168,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1169,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1170,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1171,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":1172,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1173,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1174,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1175,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1176,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1177,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1178,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1179,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":1180,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1181,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1182,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1183,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1184,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1185,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1186,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1187,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":1188,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1189,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1190,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1191,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1192,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1193,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1194,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1195,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":1196,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1197,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1198,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1199,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1200,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1201,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.starttime+before+endtime+during\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":1202,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1203,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":1204,\"textContent\":\"Which shift(s) begins before J begins and ends during B?\"}]},{\"nodeType\":3,\"id\":1205,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1206,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":1207,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1208,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1209,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1210,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1211,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1212,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":1213,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1214,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1215,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1216,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1217,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1218,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1219,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1220,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":1221,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1222,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1223,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1224,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1225,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1226,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1227,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1228,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":1229,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1230,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1231,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1232,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1233,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1234,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1235,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1236,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":1237,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1238,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1239,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1240,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1241,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1242,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1243,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1244,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":1245,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1246,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1247,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1248,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1249,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1250,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1251,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1252,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":1253,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1254,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1255,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1256,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1257,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1258,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1259,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1260,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":1261,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1262,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1263,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1264,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1265,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1266,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1267,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1268,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":1269,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1270,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1271,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1272,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1273,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1274,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1275,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1276,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":1277,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1278,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1279,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1280,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1281,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1282,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1283,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1284,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":1285,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1286,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1287,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1288,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1289,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1290,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1291,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1292,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":1293,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1294,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1295,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1296,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1297,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1298,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1299,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1300,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":1301,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1302,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1303,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1304,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1305,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1306,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1307,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1308,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":1309,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1310,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1311,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1312,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1313,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1314,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1315,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1316,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":1317,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1318,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1319,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1320,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1321,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1322,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1323,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1324,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":1325,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1326,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1327,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1328,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1329,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1330,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1331,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1332,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":1333,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1334,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1335,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1336,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1337,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1338,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1339,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1340,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":1341,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1342,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1343,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1344,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1345,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1346,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1347,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1348,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":1349,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1350,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1351,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1352,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1353,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1354,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.ends\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":1355,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1356,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":1357,\"textContent\":\"Which shift(s) end at the same time as F?\"}]},{\"nodeType\":3,\"id\":1358,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1359,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":1360,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1361,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1362,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1363,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1364,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1365,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":1366,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1367,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1368,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1369,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1370,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1371,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1372,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1373,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":1374,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1375,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1376,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1377,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1378,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1379,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1380,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1381,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":1382,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1383,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1384,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1385,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1386,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1387,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1388,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1389,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":1390,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1391,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1392,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1393,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1394,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1395,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1396,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1397,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":1398,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1399,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1400,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1401,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1402,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1403,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1404,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1405,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":1406,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1407,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1408,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1409,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1410,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1411,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1412,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1413,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":1414,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1415,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1416,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1417,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1418,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1419,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1420,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1421,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":1422,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1423,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1424,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1425,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1426,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1427,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1428,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1429,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":1430,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1431,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1432,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1433,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1434,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1435,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1436,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1437,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":1438,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1439,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1440,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1441,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1442,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1443,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1444,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1445,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":1446,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1447,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1448,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1449,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1450,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1451,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1452,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1453,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":1454,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1455,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1456,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1457,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1458,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1459,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1460,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1461,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":1462,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1463,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1464,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1465,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1466,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1467,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1468,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1469,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":1470,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1471,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1472,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1473,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1474,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1475,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1476,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1477,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":1478,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1479,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1480,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1481,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1482,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1483,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1484,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1485,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":1486,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1487,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1488,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1489,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1490,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1491,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1492,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1493,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":1494,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1495,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1496,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1497,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1498,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1499,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1500,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1501,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":1502,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1503,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1504,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1505,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1506,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1507,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.starttime\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":1508,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1509,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":1510,\"textContent\":\"Which shift(s) start at 12pm?\"}]},{\"nodeType\":3,\"id\":1511,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1512,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":1513,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1514,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1515,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1516,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1517,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1518,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":1519,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1520,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1521,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1522,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1523,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1524,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1525,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1526,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":1527,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1528,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1529,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1530,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1531,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1532,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1533,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1534,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":1535,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1536,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1537,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1538,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1539,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1540,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1541,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1542,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":1543,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1544,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1545,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1546,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1547,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1548,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1549,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1550,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":1551,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1552,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1553,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1554,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1555,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1556,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1557,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1558,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":1559,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1560,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1561,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1562,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1563,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1564,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1565,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1566,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":1567,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1568,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1569,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1570,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1571,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1572,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1573,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1574,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":1575,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1576,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1577,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1578,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1579,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1580,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1581,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1582,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":1583,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1584,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1585,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1586,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1587,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1588,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1589,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1590,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":1591,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1592,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1593,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1594,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1595,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1596,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1597,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1598,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":1599,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1600,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1601,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1602,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1603,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1604,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1605,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1606,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":1607,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1608,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1609,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1610,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1611,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1612,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1613,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1614,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":1615,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1616,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1617,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1618,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1619,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1620,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1621,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1622,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":1623,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1624,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1625,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1626,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1627,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1628,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1629,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1630,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":1631,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1632,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1633,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1634,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1635,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1636,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1637,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1638,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":1639,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1640,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1641,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1642,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1643,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1644,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1645,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1646,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":1647,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1648,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1649,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1650,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1651,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1652,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1653,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1654,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":1655,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1656,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1657,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1658,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1659,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1660,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.starts\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":1661,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1662,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":1663,\"textContent\":\"Which shift(s) start at the same time as F?\"}]},{\"nodeType\":3,\"id\":1664,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1665,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":1666,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1667,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1668,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1669,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1670,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1671,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":1672,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1673,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1674,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1675,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1676,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1677,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1678,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1679,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":1680,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1681,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1682,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1683,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1684,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1685,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1686,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1687,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":1688,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1689,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1690,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1691,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1692,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1693,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1694,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1695,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":1696,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1697,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1698,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1699,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1700,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1701,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1702,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1703,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":1704,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1705,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1706,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1707,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1708,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1709,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1710,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1711,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":1712,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1713,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1714,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1715,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1716,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1717,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1718,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1719,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":1720,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1721,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1722,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1723,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1724,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1725,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1726,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1727,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":1728,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1729,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1730,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1731,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1732,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1733,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1734,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1735,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":1736,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1737,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1738,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1739,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1740,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1741,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1742,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1743,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":1744,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1745,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1746,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1747,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1748,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1749,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1750,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1751,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":1752,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1753,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1754,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1755,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1756,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1757,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1758,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1759,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":1760,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1761,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1762,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1763,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1764,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1765,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1766,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1767,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":1768,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1769,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1770,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1771,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1772,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1773,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1774,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1775,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":1776,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1777,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1778,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1779,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1780,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1781,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1782,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1783,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":1784,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1785,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1786,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1787,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1788,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1789,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1790,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1791,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":1792,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1793,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1794,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1795,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1796,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1797,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1798,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1799,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":1800,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1801,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1802,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1803,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1804,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1805,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1806,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1807,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":1808,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1809,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1810,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1811,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1812,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1813,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.meets\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":1814,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1815,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":1816,\"textContent\":\"Which 2 shifts end when Z begins?\"}]},{\"nodeType\":3,\"id\":1817,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1818,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":1819,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1820,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1821,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1822,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1823,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1824,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":1825,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1826,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1827,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1828,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1829,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1830,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1831,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1832,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":1833,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1834,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1835,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1836,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1837,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1838,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1839,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1840,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":1841,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1842,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1843,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1844,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1845,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1846,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1847,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1848,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":1849,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1850,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1851,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1852,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1853,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1854,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1855,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1856,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":1857,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1858,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1859,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1860,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1861,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1862,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1863,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1864,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":1865,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1866,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1867,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1868,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1869,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1870,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1871,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1872,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":1873,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1874,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1875,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1876,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1877,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1878,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1879,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1880,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":1881,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1882,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1883,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1884,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1885,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1886,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1887,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1888,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":1889,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1890,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1891,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1892,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1893,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1894,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1895,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1896,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":1897,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1898,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1899,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1900,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1901,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1902,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1903,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1904,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":1905,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1906,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1907,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1908,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1909,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1910,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1911,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1912,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":1913,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1914,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1915,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1916,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1917,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1918,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1919,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1920,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":1921,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1922,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1923,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1924,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1925,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1926,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1927,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1928,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":1929,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1930,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1931,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1932,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1933,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1934,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1935,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1936,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":1937,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1938,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1939,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1940,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1941,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1942,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1943,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1944,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":1945,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1946,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1947,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1948,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1949,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1950,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1951,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1952,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":1953,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1954,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1955,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1956,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1957,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1958,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1959,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1960,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":1961,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1962,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1963,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1964,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1965,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1966,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.endtime\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":1967,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1968,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":1969,\"textContent\":\"Which shift(s) end at 3pm?\"}]},{\"nodeType\":3,\"id\":1970,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1971,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":1972,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1973,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1974,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1975,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1976,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1977,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":1978,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1979,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1980,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1981,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1982,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1983,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1984,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1985,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":1986,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1987,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1988,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1989,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1990,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1991,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1992,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1993,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":1994,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1995,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1996,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1997,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1998,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1999,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2000,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2001,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":2002,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2003,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2004,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2005,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2006,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2007,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2008,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2009,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":2010,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2011,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2012,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2013,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2014,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2015,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2016,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2017,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":2018,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2019,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2020,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2021,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2022,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2023,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2024,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2025,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":2026,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2027,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2028,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2029,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2030,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2031,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2032,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2033,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":2034,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2035,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2036,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2037,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2038,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2039,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2040,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2041,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":2042,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2043,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2044,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2045,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2046,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2047,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2048,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2049,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":2050,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2051,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2052,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2053,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2054,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2055,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2056,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2057,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":2058,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2059,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2060,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2061,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2062,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2063,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2064,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2065,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":2066,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2067,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2068,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2069,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2070,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2071,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2072,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2073,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":2074,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2075,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2076,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2077,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2078,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2079,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2080,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2081,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":2082,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2083,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2084,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2085,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2086,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2087,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2088,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2089,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":2090,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2091,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2092,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2093,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2094,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2095,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2096,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2097,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":2098,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2099,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2100,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2101,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2102,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2103,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2104,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2105,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":2106,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2107,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2108,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2109,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2110,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2111,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2112,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2113,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":2114,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2115,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2116,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2117,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2118,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2119,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.midpoint\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":2120,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2121,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":2122,\"textContent\":\"Coffee breaks happen halfway through a shift. \"},{\"nodeType\":1,\"id\":2123,\"tagName\":\"BR\",\"attributes\":{}},{\"nodeType\":3,\"id\":2124,\"textContent\":\"Which shifts share a break at 2pm?\"}]},{\"nodeType\":3,\"id\":2125,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2126,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":2127,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2128,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2129,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2130,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2131,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2132,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":2133,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2134,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2135,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2136,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2137,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2138,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2139,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2140,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":2141,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2142,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2143,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2144,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2145,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2146,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2147,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2148,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":2149,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2150,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2151,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2152,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2153,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2154,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2155,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2156,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":2157,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2158,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2159,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2160,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2161,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2162,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2163,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2164,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":2165,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2166,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2167,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2168,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2169,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2170,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2171,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2172,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":2173,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2174,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2175,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2176,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2177,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2178,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2179,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2180,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":2181,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2182,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2183,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2184,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2185,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2186,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2187,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2188,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":2189,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2190,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2191,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2192,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2193,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2194,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2195,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2196,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":2197,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2198,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2199,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2200,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2201,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2202,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2203,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2204,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":2205,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2206,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2207,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2208,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2209,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2210,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2211,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2212,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":2213,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2214,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2215,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2216,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2217,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2218,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2219,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2220,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":2221,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2222,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2223,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2224,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2225,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2226,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2227,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2228,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":2229,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2230,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2231,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2232,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2233,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2234,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2235,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2236,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":2237,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2238,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2239,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2240,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2241,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2242,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2243,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2244,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":2245,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2246,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2247,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2248,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2249,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2250,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2251,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2252,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":2253,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2254,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2255,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2256,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2257,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2258,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2259,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2260,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":2261,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2262,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2263,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2264,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2265,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2266,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2267,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2268,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":2269,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2270,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2271,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2272,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2273,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2274,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\".strategy\",\"style\":\"display: block;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2275,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2276,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":2277,\"textContent\":\"Please describe how to determine what event(s) start at 12pm?\"}]},{\"nodeType\":3,\"id\":2278,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2279,\"tagName\":\"TEXTAREA\",\"attributes\":{\"id\":\"strategyAnswer\",\"rows\":\"5\",\"cols\":\"80\"}},{\"nodeType\":3,\"id\":2280,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2281,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2282,\"textContent\":\" \"},{\"nodeType\":8,\"id\":2283},{\"nodeType\":3,\"id\":2284,\"textContent\":\" \"},{\"nodeType\":8,\"id\":2285},{\"nodeType\":3,\"id\":2286,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2287,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"fixbottom\"},\"childNodes\":[{\"nodeType\":3,\"id\":2288,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2289,\"tagName\":\"BUTTON\",\"attributes\":{\"type\":\"button\",\"id\":\"testingButton\",\"style\":\"display:none;\",\"class\":\"btn\"},\"childNodes\":[{\"nodeType\":3,\"id\":2290,\"textContent\":\"SUBMIT\"}]},{\"nodeType\":3,\"id\":2291,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2292,\"tagName\":\"BUTTON\",\"attributes\":{\"type\":\"button\",\"id\":\"strategyButton\",\"style\":\"display: block;\",\"class\":\"btn\"},\"childNodes\":[{\"nodeType\":3,\"id\":2293,\"textContent\":\"SUBMIT\"}]},{\"nodeType\":3,\"id\":2294,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2295,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2296,\"textContent\":\" \"},{\"nodeType\":8,\"id\":2297},{\"nodeType\":3,\"id\":2298,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2299,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"d3container\"},\"childNodes\":[{\"nodeType\":1,\"id\":2300,\"tagName\":\"svg\",\"attributes\":{\"width\":\"930\",\"height\":\"915\"},\"childNodes\":[{\"nodeType\":1,\"id\":2301,\"tagName\":\"g\",\"attributes\":{\"transform\":\"translate(100,25)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2302,\"tagName\":\"g\",\"attributes\":{\"class\":\"leaders\"}},{\"nodeType\":1,\"id\":2303,\"tagName\":\"g\",\"attributes\":{\"class\":\"static-scaffold\"}}]}]}]},{\"nodeType\":3,\"id\":2304,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2305,\"textContent\":\" \"},{\"nodeType\":8,\"id\":2306},{\"nodeType\":3,\"id\":2307,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2308,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":2309,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2310,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":2311,\"textContent\":\" \"}]}]}]]}",
  "useCssProxy": true,
  "loadTimes": "es: 163, dom: 1061, initialDom: 1150",
  "javascriptErrors": []
}