var MF = MF || {};MF.RecordingData = MF.RecordingData || {};MF.RecordingData["05213196896b546e14ec06c0e7816a0f223d7254"] = {
  "startTime": "2018-05-21T19:17:31.5442015Z",
  "websitePageUrl": "/16",
  "visitTime": 224717,
  "engagementTime": 179922,
  "pageTitle": "FOX2YP",
  "url": "https://warm-citadel-75324.herokuapp.com/",
  "viewportWidth": 1920,
  "viewportHeight": 1200,
  "tags": [
    "form-interact",
    "submit"
  ],
  "session": {
    "id": "864aa8897dc03a400922b549431d6f3f",
    "created": "2018-05-21T19:17:31.2067715+00:00",
    "lastActivity": "0001-01-01T00:00:00+00:00",
    "pages": 1,
    "duration": 0,
    "engagementTime": 0,
    "totalFriction": 0,
    "country": "us",
    "region": "CA",
    "city": "La Jolla",
    "isp": "University of California, San Diego",
    "ip": "###.###.###.###",
    "lang": "en-US",
    "userAgent": "Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/66.0.3359.181 Safari/537.36",
    "browser": "Chrome",
    "browserVersion": "66.0.3359.181",
    "os": "Windows",
    "osVersion": "7",
    "device": "Desktop",
    "referrer": "",
    "referrerType": "",
    "screenRes": "1920x1200",
    "entryPage": "/16",
    "tags": [
      "form-interact",
      "submit"
    ],
    "variables": [
      "SID=GQ35Z",
      "CONDITION=111"
    ],
    "watched": false,
    "starred": false,
    "lng": 32.8807,
    "lat": 32.8807,
    "visitorId": "ae44aff74663e855be6a68279ad6014a",
    "gdpr": false,
    "visitorName": null,
    "playbackUrl": "https://us.mouseflow.com/websites/e0c9ff05-6fcb-4c4a-8173-e5a0724987b1/recordings/864aa8897dc03a400922b549431d6f3f/play"
  },
  "events": [
    {
      "t": 1,
      "e": 1,
      "ty": 14,
      "x": 0,
      "y": 1199
    },
    {
      "t": 38,
      "e": 38,
      "ty": 4,
      "x": 21730,
      "y": 40495,
      "ta": "html > body"
    },
    {
      "t": 38,
      "e": 38,
      "ty": 5,
      "x": 639,
      "y": 739,
      "ta": "html > body"
    },
    {
      "t": 201,
      "e": 201,
      "ty": 0,
      "x": 1920,
      "y": 1200
    },
    {
      "t": 201,
      "e": 201,
      "ty": 2,
      "x": 639,
      "y": 739
    },
    {
      "t": 201,
      "e": 201,
      "ty": 1,
      "x": 0,
      "y": 16
    },
    {
      "t": 251,
      "e": 251,
      "ty": 41,
      "x": 60915,
      "y": 40495,
      "ta": "> div.stimulus > div"
    },
    {
      "t": 301,
      "e": 301,
      "ty": 2,
      "x": 636,
      "y": 739
    },
    {
      "t": 401,
      "e": 401,
      "ty": 2,
      "x": 634,
      "y": 739
    },
    {
      "t": 501,
      "e": 501,
      "ty": 41,
      "x": 60353,
      "y": 40495,
      "ta": "> div.stimulus > div"
    },
    {
      "t": 765,
      "e": 765,
      "ty": 2,
      "x": 632,
      "y": 737
    },
    {
      "t": 765,
      "e": 765,
      "ty": 41,
      "x": 60128,
      "y": 40384,
      "ta": "> div.stimulus > div"
    },
    {
      "t": 801,
      "e": 801,
      "ty": 2,
      "x": 628,
      "y": 737
    },
    {
      "t": 901,
      "e": 901,
      "ty": 2,
      "x": 612,
      "y": 721
    },
    {
      "t": 1001,
      "e": 1001,
      "ty": 2,
      "x": 535,
      "y": 672
    },
    {
      "t": 1001,
      "e": 1001,
      "ty": 41,
      "x": 49225,
      "y": 36783,
      "ta": "> div.stimulus > div"
    },
    {
      "t": 1082,
      "e": 1082,
      "ty": 6,
      "x": 457,
      "y": 603,
      "ta": "#strategyAnswer"
    },
    {
      "t": 1101,
      "e": 1101,
      "ty": 2,
      "x": 443,
      "y": 591
    },
    {
      "t": 1201,
      "e": 1201,
      "ty": 2,
      "x": 382,
      "y": 550
    },
    {
      "t": 1252,
      "e": 1252,
      "ty": 41,
      "x": 29553,
      "y": 11541,
      "ta": "#strategyAnswer"
    },
    {
      "t": 1301,
      "e": 1301,
      "ty": 2,
      "x": 359,
      "y": 536
    },
    {
      "t": 1310,
      "e": 1310,
      "ty": 3,
      "x": 359,
      "y": 536,
      "ta": "#strategyAnswer"
    },
    {
      "t": 1310,
      "e": 1310,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 1421,
      "e": 1421,
      "ty": 4,
      "x": 29440,
      "y": 10732,
      "ta": "#strategyAnswer"
    },
    {
      "t": 1422,
      "e": 1422,
      "ty": 5,
      "x": 359,
      "y": 536,
      "ta": "#strategyAnswer"
    },
    {
      "t": 1501,
      "e": 1501,
      "ty": 41,
      "x": 29440,
      "y": 10732,
      "ta": "#strategyAnswer"
    },
    {
      "t": 1750,
      "e": 1750,
      "ty": 41,
      "x": 30115,
      "y": 10732,
      "ta": "#strategyAnswer"
    },
    {
      "t": 1801,
      "e": 1801,
      "ty": 2,
      "x": 377,
      "y": 541
    },
    {
      "t": 1901,
      "e": 1901,
      "ty": 2,
      "x": 384,
      "y": 549
    },
    {
      "t": 2000,
      "e": 2000,
      "ty": 41,
      "x": 32251,
      "y": 21250,
      "ta": "#strategyAnswer"
    },
    {
      "t": 2100,
      "e": 2100,
      "ty": 2,
      "x": 384,
      "y": 550
    },
    {
      "t": 2252,
      "e": 2252,
      "ty": 41,
      "x": 32251,
      "y": 22868,
      "ta": "#strategyAnswer"
    },
    {
      "t": 2300,
      "e": 2300,
      "ty": 2,
      "x": 380,
      "y": 552
    },
    {
      "t": 2400,
      "e": 2400,
      "ty": 2,
      "x": 368,
      "y": 550
    },
    {
      "t": 2500,
      "e": 2500,
      "ty": 2,
      "x": 345,
      "y": 535
    },
    {
      "t": 2500,
      "e": 2500,
      "ty": 41,
      "x": 27867,
      "y": 9923,
      "ta": "#strategyAnswer"
    },
    {
      "t": 2549,
      "e": 2549,
      "ty": 7,
      "x": 325,
      "y": 512,
      "ta": "#strategyAnswer"
    },
    {
      "t": 2600,
      "e": 2600,
      "ty": 2,
      "x": 304,
      "y": 487
    },
    {
      "t": 2700,
      "e": 2700,
      "ty": 2,
      "x": 276,
      "y": 431
    },
    {
      "t": 2751,
      "e": 2751,
      "ty": 41,
      "x": 18537,
      "y": 22048,
      "ta": "> div.stimulus > div"
    },
    {
      "t": 2800,
      "e": 2800,
      "ty": 2,
      "x": 261,
      "y": 401
    },
    {
      "t": 2900,
      "e": 2900,
      "ty": 2,
      "x": 257,
      "y": 396
    },
    {
      "t": 3001,
      "e": 3001,
      "ty": 41,
      "x": 17975,
      "y": 21494,
      "ta": "> div.stimulus > div"
    },
    {
      "t": 7242,
      "e": 7242,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "16"
    },
    {
      "t": 7506,
      "e": 7506,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 7506,
      "e": 7506,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 7593,
      "e": 7593,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "E"
    },
    {
      "t": 7609,
      "e": 7609,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "E"
    },
    {
      "t": 7753,
      "e": 7753,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "78"
    },
    {
      "t": 7754,
      "e": 7754,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 7841,
      "e": 7841,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "En"
    },
    {
      "t": 7985,
      "e": 7985,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "89"
    },
    {
      "t": 7986,
      "e": 7986,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 8065,
      "e": 8065,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Eny"
    },
    {
      "t": 8161,
      "e": 8161,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 8161,
      "e": 8161,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 8257,
      "e": 8257,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Eny "
    },
    {
      "t": 8457,
      "e": 8457,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 8458,
      "e": 8458,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 8553,
      "e": 8553,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||e"
    },
    {
      "t": 8713,
      "e": 8713,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "86"
    },
    {
      "t": 8714,
      "e": 8714,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 8793,
      "e": 8793,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||v"
    },
    {
      "t": 8857,
      "e": 8857,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 8857,
      "e": 8857,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 8945,
      "e": 8945,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||e"
    },
    {
      "t": 9113,
      "e": 9113,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "78"
    },
    {
      "t": 9114,
      "e": 9114,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 9201,
      "e": 9201,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||n"
    },
    {
      "t": 9281,
      "e": 9281,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 9281,
      "e": 9281,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 9353,
      "e": 9353,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 9433,
      "e": 9433,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 9434,
      "e": 9434,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 9521,
      "e": 9521,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 9529,
      "e": 9529,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 9530,
      "e": 9530,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 9594,
      "e": 9594,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 9665,
      "e": 9665,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "72"
    },
    {
      "t": 9666,
      "e": 9666,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 9738,
      "e": 9738,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||h"
    },
    {
      "t": 9826,
      "e": 9826,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 9826,
      "e": 9826,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 9905,
      "e": 9905,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||a"
    },
    {
      "t": 9985,
      "e": 9985,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 9986,
      "e": 9986,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 10001,
      "e": 10001,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 10073,
      "e": 10073,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 10217,
      "e": 10217,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 10217,
      "e": 10217,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 10305,
      "e": 10305,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 13162,
      "e": 13162,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "73"
    },
    {
      "t": 13162,
      "e": 13162,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 13250,
      "e": 13250,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||i"
    },
    {
      "t": 13337,
      "e": 13337,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "83"
    },
    {
      "t": 13337,
      "e": 13337,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 13409,
      "e": 13409,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||s"
    },
    {
      "t": 13513,
      "e": 13513,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 13513,
      "e": 13513,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 13594,
      "e": 13594,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 13794,
      "e": 13794,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "79"
    },
    {
      "t": 13794,
      "e": 13794,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 13865,
      "e": 13865,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||o"
    },
    {
      "t": 14161,
      "e": 14161,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "78"
    },
    {
      "t": 14162,
      "e": 14162,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 14209,
      "e": 14209,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||n"
    },
    {
      "t": 20001,
      "e": 19209,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 26289,
      "e": 19209,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "80"
    },
    {
      "t": 26289,
      "e": 19209,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 26377,
      "e": 19297,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||p"
    },
    {
      "t": 26505,
      "e": 19425,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "79"
    },
    {
      "t": 26505,
      "e": 19425,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 26601,
      "e": 19521,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||o"
    },
    {
      "t": 26681,
      "e": 19601,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "83"
    },
    {
      "t": 26681,
      "e": 19601,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 26744,
      "e": 19664,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||s"
    },
    {
      "t": 26840,
      "e": 19760,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "73"
    },
    {
      "t": 26841,
      "e": 19761,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 26920,
      "e": 19840,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||i"
    },
    {
      "t": 27016,
      "e": 19936,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 27017,
      "e": 19937,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 27097,
      "e": 20017,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 27153,
      "e": 20073,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "73"
    },
    {
      "t": 27153,
      "e": 20073,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 27248,
      "e": 20168,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||i"
    },
    {
      "t": 27377,
      "e": 20297,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "86"
    },
    {
      "t": 27377,
      "e": 20297,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 27425,
      "e": 20345,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||v"
    },
    {
      "t": 27633,
      "e": 20553,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 27633,
      "e": 20553,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 27697,
      "e": 20617,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||e"
    },
    {
      "t": 27802,
      "e": 20722,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Eny event that is onpositive"
    },
    {
      "t": 27864,
      "e": 20784,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 27865,
      "e": 20785,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 27953,
      "e": 20873,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 28001,
      "e": 20921,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "83"
    },
    {
      "t": 28001,
      "e": 20921,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 28073,
      "e": 20993,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||s"
    },
    {
      "t": 28201,
      "e": 21121,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "76"
    },
    {
      "t": 28201,
      "e": 21121,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 28281,
      "e": 21201,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||l"
    },
    {
      "t": 28409,
      "e": 21329,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "79"
    },
    {
      "t": 28409,
      "e": 21329,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 28481,
      "e": 21401,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||o"
    },
    {
      "t": 28602,
      "e": 21522,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Eny event that is onpositive slo"
    },
    {
      "t": 28641,
      "e": 21561,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "80"
    },
    {
      "t": 28641,
      "e": 21561,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 28721,
      "e": 21641,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||p"
    },
    {
      "t": 28865,
      "e": 21785,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 28865,
      "e": 21785,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 28928,
      "e": 21848,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||e"
    },
    {
      "t": 31576,
      "e": 24496,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "68"
    },
    {
      "t": 31577,
      "e": 24497,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 31633,
      "e": 24553,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||d"
    },
    {
      "t": 31705,
      "e": 24625,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 31705,
      "e": 24625,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 31793,
      "e": 24713,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 31937,
      "e": 24857,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "76"
    },
    {
      "t": 31937,
      "e": 24857,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 32008,
      "e": 24928,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||l"
    },
    {
      "t": 32153,
      "e": 25073,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "73"
    },
    {
      "t": 32153,
      "e": 25073,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 32224,
      "e": 25144,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||i"
    },
    {
      "t": 32392,
      "e": 25312,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "78"
    },
    {
      "t": 32392,
      "e": 25312,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 32464,
      "e": 25384,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||n"
    },
    {
      "t": 32553,
      "e": 25473,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 32553,
      "e": 25473,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 32608,
      "e": 25528,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||e"
    },
    {
      "t": 40001,
      "e": 30528,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 50750,
      "e": 30528,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 50751,
      "e": 30529,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 50919,
      "e": 30697,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 52255,
      "e": 32033,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "73"
    },
    {
      "t": 52255,
      "e": 32033,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 52326,
      "e": 32104,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||i"
    },
    {
      "t": 52526,
      "e": 32304,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "78"
    },
    {
      "t": 52527,
      "e": 32305,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 52599,
      "e": 32377,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||n"
    },
    {
      "t": 52798,
      "e": 32576,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 52798,
      "e": 32576,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 52870,
      "e": 32648,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 53078,
      "e": 32856,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 53078,
      "e": 32856,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 53166,
      "e": 32944,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||e"
    },
    {
      "t": 53302,
      "e": 33080,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "82"
    },
    {
      "t": 53302,
      "e": 33080,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 53382,
      "e": 33160,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||r"
    },
    {
      "t": 53566,
      "e": 33344,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "83"
    },
    {
      "t": 53566,
      "e": 33344,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 53702,
      "e": 33480,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||s"
    },
    {
      "t": 53822,
      "e": 33600,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 53822,
      "e": 33600,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 53919,
      "e": 33697,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||e"
    },
    {
      "t": 54302,
      "e": 34080,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "67"
    },
    {
      "t": 54302,
      "e": 34080,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 54358,
      "e": 34136,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||c"
    },
    {
      "t": 54526,
      "e": 34304,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 54526,
      "e": 34304,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 54582,
      "e": 34360,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 54695,
      "e": 34473,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "73"
    },
    {
      "t": 54695,
      "e": 34473,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 54774,
      "e": 34552,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||i"
    },
    {
      "t": 54918,
      "e": 34696,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "78"
    },
    {
      "t": 54919,
      "e": 34697,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 55015,
      "e": 34793,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||n"
    },
    {
      "t": 55118,
      "e": 34896,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "71"
    },
    {
      "t": 55118,
      "e": 34896,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 55190,
      "e": 34968,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||g"
    },
    {
      "t": 55294,
      "e": 35072,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 55295,
      "e": 35073,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 55374,
      "e": 35152,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 55614,
      "e": 35392,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "49"
    },
    {
      "t": 55614,
      "e": 35392,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 55687,
      "e": 35465,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||1"
    },
    {
      "t": 55801,
      "e": 35579,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Eny event that is onpositive sloped line intersecting 1"
    },
    {
      "t": 55878,
      "e": 35656,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "50"
    },
    {
      "t": 55878,
      "e": 35656,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 55950,
      "e": 35728,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||2"
    },
    {
      "t": 56150,
      "e": 35928,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "80"
    },
    {
      "t": 56150,
      "e": 35928,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 56222,
      "e": 36000,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||p"
    },
    {
      "t": 56438,
      "e": 36216,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "77"
    },
    {
      "t": 56438,
      "e": 36216,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 56510,
      "e": 36288,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||m"
    },
    {
      "t": 56606,
      "e": 36384,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 56606,
      "e": 36384,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 56710,
      "e": 36488,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 56862,
      "e": 36640,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "79"
    },
    {
      "t": 56863,
      "e": 36641,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 56950,
      "e": 36728,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||o"
    },
    {
      "t": 57078,
      "e": 36856,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "82"
    },
    {
      "t": 57079,
      "e": 36857,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 57158,
      "e": 36936,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||r"
    },
    {
      "t": 57294,
      "e": 37072,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 57294,
      "e": 37072,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 57390,
      "e": 37168,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 57678,
      "e": 37456,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 57678,
      "e": 37456,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 57751,
      "e": 37529,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||a"
    },
    {
      "t": 57854,
      "e": 37632,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "78"
    },
    {
      "t": 57855,
      "e": 37633,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 57934,
      "e": 37712,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||n"
    },
    {
      "t": 58094,
      "e": 37872,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "89"
    },
    {
      "t": 58094,
      "e": 37872,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 58167,
      "e": 37945,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||y"
    },
    {
      "t": 58230,
      "e": 38008,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 58230,
      "e": 38008,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 58318,
      "e": 38096,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 58502,
      "e": 38280,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 58502,
      "e": 38280,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 58582,
      "e": 38360,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||e"
    },
    {
      "t": 58775,
      "e": 38553,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "86"
    },
    {
      "t": 58775,
      "e": 38553,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 58838,
      "e": 38616,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||v"
    },
    {
      "t": 58966,
      "e": 38744,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 58966,
      "e": 38744,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 59046,
      "e": 38824,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||e"
    },
    {
      "t": 59174,
      "e": 38952,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "78"
    },
    {
      "t": 59175,
      "e": 38953,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 59254,
      "e": 39032,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||n"
    },
    {
      "t": 59478,
      "e": 39256,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 59478,
      "e": 39256,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 59550,
      "e": 39328,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 59686,
      "e": 39464,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 59687,
      "e": 39465,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 59774,
      "e": 39552,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 59999,
      "e": 39777,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 62334,
      "e": 42112,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "87"
    },
    {
      "t": 62335,
      "e": 42113,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 62430,
      "e": 42208,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||w"
    },
    {
      "t": 62486,
      "e": 42264,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "72"
    },
    {
      "t": 62486,
      "e": 42264,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 62566,
      "e": 42344,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||h"
    },
    {
      "t": 62814,
      "e": 42592,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "79"
    },
    {
      "t": 62814,
      "e": 42592,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 62902,
      "e": 42680,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||o"
    },
    {
      "t": 63061,
      "e": 42839,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "83"
    },
    {
      "t": 63062,
      "e": 42840,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 63142,
      "e": 42920,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||s"
    },
    {
      "t": 63302,
      "e": 43080,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 63302,
      "e": 43080,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 63374,
      "e": 43152,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||e"
    },
    {
      "t": 63541,
      "e": 43319,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 63542,
      "e": 43320,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 63590,
      "e": 43368,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 66974,
      "e": 46752,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "72"
    },
    {
      "t": 66975,
      "e": 46753,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 67054,
      "e": 46832,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||h"
    },
    {
      "t": 67230,
      "e": 47008,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 67230,
      "e": 47008,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 67326,
      "e": 47104,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||e"
    },
    {
      "t": 67438,
      "e": 47216,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "73"
    },
    {
      "t": 67438,
      "e": 47216,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 67518,
      "e": 47296,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||i"
    },
    {
      "t": 68086,
      "e": 47864,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 68166,
      "e": 47944,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Eny event that is onpositive sloped line intersecting 12pm or any event whose he"
    },
    {
      "t": 68262,
      "e": 48040,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 68334,
      "e": 48112,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Eny event that is onpositive sloped line intersecting 12pm or any event whose h"
    },
    {
      "t": 68822,
      "e": 48600,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 68909,
      "e": 48687,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Eny event that is onpositive sloped line intersecting 12pm or any event whose "
    },
    {
      "t": 69998,
      "e": 49776,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 73502,
      "e": 53280,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "89"
    },
    {
      "t": 73502,
      "e": 53280,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 73581,
      "e": 53359,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||y"
    },
    {
      "t": 74830,
      "e": 54608,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "189"
    },
    {
      "t": 74830,
      "e": 54608,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 74902,
      "e": 54680,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||-"
    },
    {
      "t": 75269,
      "e": 55047,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "67"
    },
    {
      "t": 75270,
      "e": 55048,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 75390,
      "e": 55168,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||c"
    },
    {
      "t": 75622,
      "e": 55400,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "79"
    },
    {
      "t": 75622,
      "e": 55400,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 75734,
      "e": 55512,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||o"
    },
    {
      "t": 75845,
      "e": 55623,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "82"
    },
    {
      "t": 75846,
      "e": 55624,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 75917,
      "e": 55695,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||r"
    },
    {
      "t": 76134,
      "e": 55912,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "68"
    },
    {
      "t": 76134,
      "e": 55912,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 76206,
      "e": 55984,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||d"
    },
    {
      "t": 76277,
      "e": 56055,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "73"
    },
    {
      "t": 76278,
      "e": 56056,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 76358,
      "e": 56136,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||i"
    },
    {
      "t": 76517,
      "e": 56295,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "78"
    },
    {
      "t": 76518,
      "e": 56296,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 76598,
      "e": 56376,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||n"
    },
    {
      "t": 76709,
      "e": 56487,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 76710,
      "e": 56488,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 76757,
      "e": 56535,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||a"
    },
    {
      "t": 76838,
      "e": 56616,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 76838,
      "e": 56616,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 76902,
      "e": 56680,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 77054,
      "e": 56832,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 77054,
      "e": 56832,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 77126,
      "e": 56904,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||e"
    },
    {
      "t": 77566,
      "e": 57344,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 77566,
      "e": 57344,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 77638,
      "e": 57416,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 79999,
      "e": 59777,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 93279,
      "e": 62416,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "111"
    },
    {
      "t": 93280,
      "e": 62417,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 93358,
      "e": 62495,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||/"
    },
    {
      "t": 94038,
      "e": 63175,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 94157,
      "e": 63294,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Eny event that is onpositive sloped line intersecting 12pm or any event whose y-cordinate "
    },
    {
      "t": 94398,
      "e": 63535,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "68"
    },
    {
      "t": 94398,
      "e": 63535,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 94469,
      "e": 63606,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||d"
    },
    {
      "t": 94566,
      "e": 63703,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "73"
    },
    {
      "t": 94566,
      "e": 63703,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 94646,
      "e": 63783,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||i"
    },
    {
      "t": 94775,
      "e": 63912,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "86"
    },
    {
      "t": 94775,
      "e": 63912,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 94846,
      "e": 63983,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||v"
    },
    {
      "t": 94902,
      "e": 64039,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "73"
    },
    {
      "t": 94902,
      "e": 64039,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 94982,
      "e": 64119,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||i"
    },
    {
      "t": 95223,
      "e": 64360,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "68"
    },
    {
      "t": 95223,
      "e": 64360,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 95285,
      "e": 64422,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||d"
    },
    {
      "t": 95401,
      "e": 64538,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Eny event that is onpositive sloped line intersecting 12pm or any event whose y-cordinate divid"
    },
    {
      "t": 95446,
      "e": 64583,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 95447,
      "e": 64584,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 95501,
      "e": 64638,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||e"
    },
    {
      "t": 95638,
      "e": 64775,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "68"
    },
    {
      "t": 95638,
      "e": 64775,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 95718,
      "e": 64855,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||d"
    },
    {
      "t": 95830,
      "e": 64967,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 95830,
      "e": 64967,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 95894,
      "e": 65031,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 96000,
      "e": 65137,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Eny event that is onpositive sloped line intersecting 12pm or any event whose y-cordinate divided "
    },
    {
      "t": 96038,
      "e": 65175,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "66"
    },
    {
      "t": 96039,
      "e": 65176,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 96102,
      "e": 65239,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||b"
    },
    {
      "t": 96263,
      "e": 65400,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "89"
    },
    {
      "t": 96263,
      "e": 65400,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 96326,
      "e": 65463,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||y"
    },
    {
      "t": 96462,
      "e": 65599,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 96463,
      "e": 65600,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 96549,
      "e": 65686,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 96662,
      "e": 65799,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "50"
    },
    {
      "t": 96663,
      "e": 65800,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 96725,
      "e": 65862,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||2"
    },
    {
      "t": 97030,
      "e": 66167,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 97033,
      "e": 66170,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 97101,
      "e": 66238,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 99999,
      "e": 69136,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 109597,
      "e": 71238,
      "ty": 2,
      "x": 322,
      "y": 241
    },
    {
      "t": 109697,
      "e": 71338,
      "ty": 2,
      "x": 302,
      "y": 221
    },
    {
      "t": 109748,
      "e": 71389,
      "ty": 41,
      "x": 21122,
      "y": 12796,
      "ta": "> div.stimulus > div"
    },
    {
      "t": 109798,
      "e": 71439,
      "ty": 2,
      "x": 265,
      "y": 273
    },
    {
      "t": 109898,
      "e": 71539,
      "ty": 2,
      "x": 238,
      "y": 330
    },
    {
      "t": 109998,
      "e": 71639,
      "ty": 2,
      "x": 226,
      "y": 442
    },
    {
      "t": 109998,
      "e": 71639,
      "ty": 41,
      "x": 14490,
      "y": 24042,
      "ta": "> div.stimulus > div"
    },
    {
      "t": 110067,
      "e": 71708,
      "ty": 6,
      "x": 232,
      "y": 524,
      "ta": "#strategyAnswer"
    },
    {
      "t": 110097,
      "e": 71738,
      "ty": 2,
      "x": 233,
      "y": 530
    },
    {
      "t": 110197,
      "e": 71838,
      "ty": 2,
      "x": 253,
      "y": 549
    },
    {
      "t": 110248,
      "e": 71889,
      "ty": 41,
      "x": 18986,
      "y": 23678,
      "ta": "#strategyAnswer"
    },
    {
      "t": 110297,
      "e": 71938,
      "ty": 2,
      "x": 281,
      "y": 554
    },
    {
      "t": 110398,
      "e": 72039,
      "ty": 2,
      "x": 295,
      "y": 556
    },
    {
      "t": 110497,
      "e": 72138,
      "ty": 2,
      "x": 334,
      "y": 557
    },
    {
      "t": 110497,
      "e": 72138,
      "ty": 41,
      "x": 26630,
      "y": 27723,
      "ta": "#strategyAnswer"
    },
    {
      "t": 110597,
      "e": 72238,
      "ty": 2,
      "x": 408,
      "y": 556
    },
    {
      "t": 110698,
      "e": 72339,
      "ty": 2,
      "x": 515,
      "y": 541
    },
    {
      "t": 110748,
      "e": 72389,
      "ty": 41,
      "x": 47876,
      "y": 13969,
      "ta": "#strategyAnswer"
    },
    {
      "t": 110797,
      "e": 72438,
      "ty": 2,
      "x": 510,
      "y": 536
    },
    {
      "t": 110898,
      "e": 72539,
      "ty": 2,
      "x": 446,
      "y": 540
    },
    {
      "t": 110998,
      "e": 72639,
      "ty": 2,
      "x": 459,
      "y": 542
    },
    {
      "t": 110998,
      "e": 72639,
      "ty": 41,
      "x": 40681,
      "y": 15587,
      "ta": "#strategyAnswer"
    },
    {
      "t": 111098,
      "e": 72739,
      "ty": 2,
      "x": 529,
      "y": 531
    },
    {
      "t": 111185,
      "e": 72826,
      "ty": 7,
      "x": 602,
      "y": 520,
      "ta": "#strategyAnswer"
    },
    {
      "t": 111197,
      "e": 72838,
      "ty": 2,
      "x": 602,
      "y": 520
    },
    {
      "t": 111248,
      "e": 72889,
      "ty": 41,
      "x": 58779,
      "y": 52113,
      "ta": "#.strategy > p"
    },
    {
      "t": 111297,
      "e": 72938,
      "ty": 2,
      "x": 647,
      "y": 519
    },
    {
      "t": 111302,
      "e": 72943,
      "ty": 6,
      "x": 660,
      "y": 522,
      "ta": "#strategyAnswer"
    },
    {
      "t": 111397,
      "e": 73038,
      "ty": 2,
      "x": 673,
      "y": 524
    },
    {
      "t": 111498,
      "e": 73139,
      "ty": 2,
      "x": 673,
      "y": 525
    },
    {
      "t": 111498,
      "e": 73139,
      "ty": 41,
      "x": 64737,
      "y": 1833,
      "ta": "#strategyAnswer"
    },
    {
      "t": 111598,
      "e": 73239,
      "ty": 2,
      "x": 669,
      "y": 536
    },
    {
      "t": 111690,
      "e": 73331,
      "ty": 3,
      "x": 669,
      "y": 536,
      "ta": "#strategyAnswer"
    },
    {
      "t": 111748,
      "e": 73389,
      "ty": 41,
      "x": 64287,
      "y": 10732,
      "ta": "#strategyAnswer"
    },
    {
      "t": 111776,
      "e": 73417,
      "ty": 4,
      "x": 64287,
      "y": 10732,
      "ta": "#strategyAnswer"
    },
    {
      "t": 111776,
      "e": 73417,
      "ty": 5,
      "x": 669,
      "y": 536,
      "ta": "#strategyAnswer"
    },
    {
      "t": 111998,
      "e": 73639,
      "ty": 2,
      "x": 668,
      "y": 537
    },
    {
      "t": 111998,
      "e": 73639,
      "ty": 41,
      "x": 64175,
      "y": 11541,
      "ta": "#strategyAnswer"
    },
    {
      "t": 113125,
      "e": 74766,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "88"
    },
    {
      "t": 113126,
      "e": 74767,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 113219,
      "e": 74860,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Eny event that is onpositive sloped line intersecting 12pm or any event whose xy-cordinate divided by 2 "
    },
    {
      "t": 113405,
      "e": 75046,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "189"
    },
    {
      "t": 113405,
      "e": 75046,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 113540,
      "e": 75181,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Eny event that is onpositive sloped line intersecting 12pm or any event whose x-y-cordinate divided by 2 "
    },
    {
      "t": 114277,
      "e": 75918,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "67"
    },
    {
      "t": 114277,
      "e": 75918,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 114355,
      "e": 75996,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Eny event that is onpositive sloped line intersecting 12pm or any event whose x-cy-cordinate divided by 2 "
    },
    {
      "t": 114492,
      "e": 76133,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "79"
    },
    {
      "t": 114493,
      "e": 76134,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 114572,
      "e": 76213,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Eny event that is onpositive sloped line intersecting 12pm or any event whose x-coy-cordinate divided by 2 "
    },
    {
      "t": 114636,
      "e": 76277,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "82"
    },
    {
      "t": 114636,
      "e": 76277,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 114725,
      "e": 76366,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Eny event that is onpositive sloped line intersecting 12pm or any event whose x-cory-cordinate divided by 2 "
    },
    {
      "t": 114990,
      "e": 76631,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "68"
    },
    {
      "t": 114991,
      "e": 76632,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 115075,
      "e": 76716,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Eny event that is onpositive sloped line intersecting 12pm or any event whose x-cordy-cordinate divided by 2 "
    },
    {
      "t": 115164,
      "e": 76805,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "73"
    },
    {
      "t": 115164,
      "e": 76805,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 115245,
      "e": 76806,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Eny event that is onpositive sloped line intersecting 12pm or any event whose x-cordiy-cordinate divided by 2 "
    },
    {
      "t": 115364,
      "e": 76925,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "78"
    },
    {
      "t": 115364,
      "e": 76925,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 115436,
      "e": 76997,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Eny event that is onpositive sloped line intersecting 12pm or any event whose x-cordiny-cordinate divided by 2 "
    },
    {
      "t": 115516,
      "e": 77077,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 115516,
      "e": 77077,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 115579,
      "e": 77140,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Eny event that is onpositive sloped line intersecting 12pm or any event whose x-cordinay-cordinate divided by 2 "
    },
    {
      "t": 115701,
      "e": 77262,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 115702,
      "e": 77263,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 115772,
      "e": 77333,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Eny event that is onpositive sloped line intersecting 12pm or any event whose x-cordinaty-cordinate divided by 2 "
    },
    {
      "t": 116012,
      "e": 77573,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 116013,
      "e": 77574,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 116091,
      "e": 77652,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Eny event that is onpositive sloped line intersecting 12pm or any event whose x-cordinatey-cordinate divided by 2 "
    },
    {
      "t": 116198,
      "e": 77759,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Eny event that is onpositive sloped line intersecting 12pm or any event whose x-cordinatey-cordinate divided by 2 "
    },
    {
      "t": 116276,
      "e": 77837,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 116276,
      "e": 77837,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 116364,
      "e": 77925,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Eny event that is onpositive sloped line intersecting 12pm or any event whose x-cordinate y-cordinate divided by 2 "
    },
    {
      "t": 116500,
      "e": 78061,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "83"
    },
    {
      "t": 116500,
      "e": 78061,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 116572,
      "e": 78061,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Eny event that is onpositive sloped line intersecting 12pm or any event whose x-cordinate sy-cordinate divided by 2 "
    },
    {
      "t": 116660,
      "e": 78149,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "72"
    },
    {
      "t": 116660,
      "e": 78149,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 116716,
      "e": 78205,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Eny event that is onpositive sloped line intersecting 12pm or any event whose x-cordinate shy-cordinate divided by 2 "
    },
    {
      "t": 116917,
      "e": 78406,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "73"
    },
    {
      "t": 116917,
      "e": 78406,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 116988,
      "e": 78477,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Eny event that is onpositive sloped line intersecting 12pm or any event whose x-cordinate shiy-cordinate divided by 2 "
    },
    {
      "t": 117165,
      "e": 78654,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "70"
    },
    {
      "t": 117165,
      "e": 78654,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 117252,
      "e": 78741,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Eny event that is onpositive sloped line intersecting 12pm or any event whose x-cordinate shify-cordinate divided by 2 "
    },
    {
      "t": 117404,
      "e": 78893,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 117405,
      "e": 78894,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 117475,
      "e": 78964,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Eny event that is onpositive sloped line intersecting 12pm or any event whose x-cordinate shifty-cordinate divided by 2 "
    },
    {
      "t": 117599,
      "e": 79088,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Eny event that is onpositive sloped line intersecting 12pm or any event whose x-cordinate shifty-cordinate divided by 2 "
    },
    {
      "t": 117685,
      "e": 79174,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 117685,
      "e": 79174,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 117772,
      "e": 79261,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Eny event that is onpositive sloped line intersecting 12pm or any event whose x-cordinate shiftey-cordinate divided by 2 "
    },
    {
      "t": 117933,
      "e": 79422,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "68"
    },
    {
      "t": 117933,
      "e": 79422,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 118004,
      "e": 79422,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Eny event that is onpositive sloped line intersecting 12pm or any event whose x-cordinate shiftedy-cordinate divided by 2 "
    },
    {
      "t": 118164,
      "e": 79582,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 118164,
      "e": 79582,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 118227,
      "e": 79645,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Eny event that is onpositive sloped line intersecting 12pm or any event whose x-cordinate shifted y-cordinate divided by 2 "
    },
    {
      "t": 119228,
      "e": 80646,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 119229,
      "e": 80647,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 119316,
      "e": 80734,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Eny event that is onpositive sloped line intersecting 12pm or any event whose x-cordinate shifted ty-cordinate divided by 2 "
    },
    {
      "t": 119436,
      "e": 80854,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "79"
    },
    {
      "t": 119437,
      "e": 80855,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 119507,
      "e": 80925,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Eny event that is onpositive sloped line intersecting 12pm or any event whose x-cordinate shifted toy-cordinate divided by 2 "
    },
    {
      "t": 119595,
      "e": 81013,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 119597,
      "e": 81015,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 119683,
      "e": 81101,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Eny event that is onpositive sloped line intersecting 12pm or any event whose x-cordinate shifted to y-cordinate divided by 2 "
    },
    {
      "t": 119764,
      "e": 81182,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 119764,
      "e": 81182,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 119820,
      "e": 81238,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Eny event that is onpositive sloped line intersecting 12pm or any event whose x-cordinate shifted to ty-cordinate divided by 2 "
    },
    {
      "t": 119851,
      "e": 81269,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "72"
    },
    {
      "t": 119852,
      "e": 81270,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 119932,
      "e": 81350,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Eny event that is onpositive sloped line intersecting 12pm or any event whose x-cordinate shifted to thy-cordinate divided by 2 "
    },
    {
      "t": 120076,
      "e": 81494,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 120077,
      "e": 81495,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 120149,
      "e": 81497,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Eny event that is onpositive sloped line intersecting 12pm or any event whose x-cordinate shifted to they-cordinate divided by 2 "
    },
    {
      "t": 120196,
      "e": 81544,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 120196,
      "e": 81544,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 120276,
      "e": 81624,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Eny event that is onpositive sloped line intersecting 12pm or any event whose x-cordinate shifted to the y-cordinate divided by 2 "
    },
    {
      "t": 120420,
      "e": 81768,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "76"
    },
    {
      "t": 120421,
      "e": 81769,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 120499,
      "e": 81847,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Eny event that is onpositive sloped line intersecting 12pm or any event whose x-cordinate shifted to the ly-cordinate divided by 2 "
    },
    {
      "t": 120628,
      "e": 81976,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 120629,
      "e": 81977,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 120707,
      "e": 82055,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Eny event that is onpositive sloped line intersecting 12pm or any event whose x-cordinate shifted to the ley-cordinate divided by 2 "
    },
    {
      "t": 121036,
      "e": 82384,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "70"
    },
    {
      "t": 121037,
      "e": 82385,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 121108,
      "e": 82456,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Eny event that is onpositive sloped line intersecting 12pm or any event whose x-cordinate shifted to the lefy-cordinate divided by 2 "
    },
    {
      "t": 121252,
      "e": 82600,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 121253,
      "e": 82601,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 121316,
      "e": 82664,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Eny event that is onpositive sloped line intersecting 12pm or any event whose x-cordinate shifted to the lefty-cordinate divided by 2 "
    },
    {
      "t": 121420,
      "e": 82768,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 121420,
      "e": 82768,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 121532,
      "e": 82769,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Eny event that is onpositive sloped line intersecting 12pm or any event whose x-cordinate shifted to the left y-cordinate divided by 2 "
    },
    {
      "t": 121652,
      "e": 82889,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "66"
    },
    {
      "t": 121652,
      "e": 82889,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 121731,
      "e": 82968,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Eny event that is onpositive sloped line intersecting 12pm or any event whose x-cordinate shifted to the left by-cordinate divided by 2 "
    },
    {
      "t": 121892,
      "e": 83129,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "89"
    },
    {
      "t": 121892,
      "e": 83129,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 121964,
      "e": 83201,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Eny event that is onpositive sloped line intersecting 12pm or any event whose x-cordinate shifted to the left byy-cordinate divided by 2 "
    },
    {
      "t": 122204,
      "e": 83441,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 122204,
      "e": 83441,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 122283,
      "e": 83520,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Eny event that is onpositive sloped line intersecting 12pm or any event whose x-cordinate shifted to the left by y-cordinate divided by 2 "
    },
    {
      "t": 122399,
      "e": 83636,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Eny event that is onpositive sloped line intersecting 12pm or any event whose x-cordinate shifted to the left by y-cordinate divided by 2 "
    },
    {
      "t": 123660,
      "e": 84897,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 123660,
      "e": 84897,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 123683,
      "e": 84920,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Eny event that is onpositive sloped line intersecting 12pm or any event whose x-cordinate shifted to the left by ty-cordinate divided by 2 "
    },
    {
      "t": 123799,
      "e": 84920,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Eny event that is onpositive sloped line intersecting 12pm or any event whose x-cordinate shifted to the left by ty-cordinate divided by 2 "
    },
    {
      "t": 124004,
      "e": 85125,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "72"
    },
    {
      "t": 124005,
      "e": 85126,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 124083,
      "e": 85204,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Eny event that is onpositive sloped line intersecting 12pm or any event whose x-cordinate shifted to the left by thy-cordinate divided by 2 "
    },
    {
      "t": 124200,
      "e": 85321,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Eny event that is onpositive sloped line intersecting 12pm or any event whose x-cordinate shifted to the left by thy-cordinate divided by 2 "
    },
    {
      "t": 124276,
      "e": 85397,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 124277,
      "e": 85398,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 124355,
      "e": 85476,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Eny event that is onpositive sloped line intersecting 12pm or any event whose x-cordinate shifted to the left by they-cordinate divided by 2 "
    },
    {
      "t": 124460,
      "e": 85581,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "73"
    },
    {
      "t": 124460,
      "e": 85581,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 124540,
      "e": 85661,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Eny event that is onpositive sloped line intersecting 12pm or any event whose x-cordinate shifted to the left by theiy-cordinate divided by 2 "
    },
    {
      "t": 124668,
      "e": 85789,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "82"
    },
    {
      "t": 124668,
      "e": 85789,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 124747,
      "e": 85868,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Eny event that is onpositive sloped line intersecting 12pm or any event whose x-cordinate shifted to the left by theiry-cordinate divided by 2 "
    },
    {
      "t": 125212,
      "e": 86333,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 125213,
      "e": 86334,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 125284,
      "e": 86334,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Eny event that is onpositive sloped line intersecting 12pm or any event whose x-cordinate shifted to the left by their y-cordinate divided by 2 "
    },
    {
      "t": 125399,
      "e": 86449,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Eny event that is onpositive sloped line intersecting 12pm or any event whose x-cordinate shifted to the left by their y-cordinate divided by 2 "
    },
    {
      "t": 125896,
      "e": 86946,
      "ty": 7,
      "x": 727,
      "y": 486,
      "ta": "#strategyAnswer"
    },
    {
      "t": 125897,
      "e": 86947,
      "ty": 2,
      "x": 727,
      "y": 486
    },
    {
      "t": 125998,
      "e": 87048,
      "ty": 2,
      "x": 755,
      "y": 460
    },
    {
      "t": 125998,
      "e": 87048,
      "ty": 41,
      "x": 4299,
      "y": 22862,
      "ta": "> div.stimulus > div:[2]"
    },
    {
      "t": 126097,
      "e": 87147,
      "ty": 2,
      "x": 817,
      "y": 478
    },
    {
      "t": 126197,
      "e": 87247,
      "ty": 2,
      "x": 704,
      "y": 515
    },
    {
      "t": 126246,
      "e": 87296,
      "ty": 6,
      "x": 644,
      "y": 522,
      "ta": "#strategyAnswer"
    },
    {
      "t": 126249,
      "e": 87299,
      "ty": 41,
      "x": 61477,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 126297,
      "e": 87347,
      "ty": 2,
      "x": 581,
      "y": 533
    },
    {
      "t": 126397,
      "e": 87447,
      "ty": 2,
      "x": 509,
      "y": 549
    },
    {
      "t": 126497,
      "e": 87547,
      "ty": 2,
      "x": 466,
      "y": 555
    },
    {
      "t": 126497,
      "e": 87547,
      "ty": 41,
      "x": 41468,
      "y": 26105,
      "ta": "#strategyAnswer"
    },
    {
      "t": 126597,
      "e": 87647,
      "ty": 2,
      "x": 465,
      "y": 555
    },
    {
      "t": 126697,
      "e": 87747,
      "ty": 2,
      "x": 463,
      "y": 555
    },
    {
      "t": 126747,
      "e": 87797,
      "ty": 41,
      "x": 41019,
      "y": 26105,
      "ta": "#strategyAnswer"
    },
    {
      "t": 126797,
      "e": 87847,
      "ty": 2,
      "x": 463,
      "y": 552
    },
    {
      "t": 126898,
      "e": 87948,
      "ty": 2,
      "x": 465,
      "y": 551
    },
    {
      "t": 126997,
      "e": 88047,
      "ty": 41,
      "x": 41356,
      "y": 22868,
      "ta": "#strategyAnswer"
    },
    {
      "t": 127068,
      "e": 88118,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "16"
    },
    {
      "t": 127198,
      "e": 88248,
      "ty": 2,
      "x": 466,
      "y": 544
    },
    {
      "t": 127248,
      "e": 88298,
      "ty": 41,
      "x": 41693,
      "y": 13160,
      "ta": "#strategyAnswer"
    },
    {
      "t": 127298,
      "e": 88348,
      "ty": 2,
      "x": 469,
      "y": 536
    },
    {
      "t": 127397,
      "e": 88447,
      "ty": 2,
      "x": 471,
      "y": 535
    },
    {
      "t": 127468,
      "e": 88518,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "57"
    },
    {
      "t": 127468,
      "e": 88518,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 127497,
      "e": 88547,
      "ty": 2,
      "x": 481,
      "y": 531
    },
    {
      "t": 127497,
      "e": 88547,
      "ty": 41,
      "x": 43154,
      "y": 6687,
      "ta": "#strategyAnswer"
    },
    {
      "t": 127556,
      "e": 88606,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Eny event that is onpositive sloped line intersecting 12pm or any event whose x-cordinate shifted to the left by their (y-cordinate divided by 2 "
    },
    {
      "t": 127563,
      "e": 88613,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 127597,
      "e": 88647,
      "ty": 2,
      "x": 529,
      "y": 545
    },
    {
      "t": 127697,
      "e": 88747,
      "ty": 2,
      "x": 549,
      "y": 553
    },
    {
      "t": 127747,
      "e": 88797,
      "ty": 41,
      "x": 50798,
      "y": 24487,
      "ta": "#strategyAnswer"
    },
    {
      "t": 127798,
      "e": 88848,
      "ty": 2,
      "x": 555,
      "y": 558
    },
    {
      "t": 127897,
      "e": 88947,
      "ty": 2,
      "x": 573,
      "y": 561
    },
    {
      "t": 127997,
      "e": 89047,
      "ty": 2,
      "x": 583,
      "y": 557
    },
    {
      "t": 127997,
      "e": 89047,
      "ty": 41,
      "x": 54620,
      "y": 27723,
      "ta": "#strategyAnswer"
    },
    {
      "t": 128097,
      "e": 89147,
      "ty": 2,
      "x": 585,
      "y": 552
    },
    {
      "t": 128168,
      "e": 89218,
      "ty": 3,
      "x": 585,
      "y": 546,
      "ta": "#strategyAnswer"
    },
    {
      "t": 128198,
      "e": 89248,
      "ty": 2,
      "x": 585,
      "y": 546
    },
    {
      "t": 128247,
      "e": 89297,
      "ty": 41,
      "x": 54845,
      "y": 18823,
      "ta": "#strategyAnswer"
    },
    {
      "t": 128264,
      "e": 89314,
      "ty": 4,
      "x": 54845,
      "y": 18823,
      "ta": "#strategyAnswer"
    },
    {
      "t": 128264,
      "e": 89314,
      "ty": 5,
      "x": 585,
      "y": 546,
      "ta": "#strategyAnswer"
    },
    {
      "t": 128372,
      "e": 89422,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "16"
    },
    {
      "t": 128397,
      "e": 89447,
      "ty": 2,
      "x": 594,
      "y": 542
    },
    {
      "t": 128412,
      "e": 89462,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "48"
    },
    {
      "t": 128413,
      "e": 89463,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 128497,
      "e": 89547,
      "ty": 2,
      "x": 604,
      "y": 542
    },
    {
      "t": 128497,
      "e": 89547,
      "ty": 41,
      "x": 56981,
      "y": 15587,
      "ta": "#strategyAnswer"
    },
    {
      "t": 128540,
      "e": 89590,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Eny event that is onpositive sloped line intersecting 12pm or any event whose x-cordinate shifted to the left by their (y-cordinate divided by 2) "
    },
    {
      "t": 128564,
      "e": 89614,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 128597,
      "e": 89647,
      "ty": 2,
      "x": 606,
      "y": 542
    },
    {
      "t": 128698,
      "e": 89748,
      "ty": 2,
      "x": 609,
      "y": 542
    },
    {
      "t": 128748,
      "e": 89798,
      "ty": 41,
      "x": 59117,
      "y": 17205,
      "ta": "#strategyAnswer"
    },
    {
      "t": 128798,
      "e": 89848,
      "ty": 2,
      "x": 648,
      "y": 556
    },
    {
      "t": 128898,
      "e": 89948,
      "ty": 2,
      "x": 659,
      "y": 562
    },
    {
      "t": 128997,
      "e": 90047,
      "ty": 41,
      "x": 63163,
      "y": 31768,
      "ta": "#strategyAnswer"
    },
    {
      "t": 129035,
      "e": 90085,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 129035,
      "e": 90085,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 129115,
      "e": 90165,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 131044,
      "e": 92094,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "73"
    },
    {
      "t": 131044,
      "e": 92094,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 131116,
      "e": 92094,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Eny event that is onpositive sloped line intersecting 12pm or any event whose x-cordinate shifted to the left by their (y-cordinate divided by 2) i "
    },
    {
      "t": 132421,
      "e": 93399,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 132531,
      "e": 93509,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Eny event that is onpositive sloped line intersecting 12pm or any event whose x-cordinate shifted to the left by their (y-cordinate divided by 2)  "
    },
    {
      "t": 134884,
      "e": 95862,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "73"
    },
    {
      "t": 134885,
      "e": 95863,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 134971,
      "e": 95949,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Eny event that is onpositive sloped line intersecting 12pm or any event whose x-cordinate shifted to the left by their (y-cordinate divided by 2) i "
    },
    {
      "t": 135116,
      "e": 96094,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "83"
    },
    {
      "t": 135117,
      "e": 96095,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 135188,
      "e": 96166,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Eny event that is onpositive sloped line intersecting 12pm or any event whose x-cordinate shifted to the left by their (y-cordinate divided by 2) is "
    },
    {
      "t": 135259,
      "e": 96237,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 135260,
      "e": 96238,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 135339,
      "e": 96317,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 135556,
      "e": 96534,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 135556,
      "e": 96534,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 135627,
      "e": 96605,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Eny event that is onpositive sloped line intersecting 12pm or any event whose x-cordinate shifted to the left by their (y-cordinate divided by 2) is t "
    },
    {
      "t": 135708,
      "e": 96686,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "72"
    },
    {
      "t": 135708,
      "e": 96686,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 135787,
      "e": 96686,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Eny event that is onpositive sloped line intersecting 12pm or any event whose x-cordinate shifted to the left by their (y-cordinate divided by 2) is th "
    },
    {
      "t": 135867,
      "e": 96766,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 135867,
      "e": 96766,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 135940,
      "e": 96839,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Eny event that is onpositive sloped line intersecting 12pm or any event whose x-cordinate shifted to the left by their (y-cordinate divided by 2) is the "
    },
    {
      "t": 136020,
      "e": 96919,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 136021,
      "e": 96920,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 136107,
      "e": 97006,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 136652,
      "e": 97551,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 136723,
      "e": 97622,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Eny event that is onpositive sloped line intersecting 12pm or any event whose x-cordinate shifted to the left by their (y-cordinate divided by 2) is the "
    },
    {
      "t": 136843,
      "e": 97742,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 136915,
      "e": 97814,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Eny event that is onpositive sloped line intersecting 12pm or any event whose x-cordinate shifted to the left by their (y-cordinate divided by 2) is th "
    },
    {
      "t": 137123,
      "e": 98022,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 137211,
      "e": 98110,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Eny event that is onpositive sloped line intersecting 12pm or any event whose x-cordinate shifted to the left by their (y-cordinate divided by 2) is t "
    },
    {
      "t": 137403,
      "e": 98302,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 137499,
      "e": 98302,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Eny event that is onpositive sloped line intersecting 12pm or any event whose x-cordinate shifted to the left by their (y-cordinate divided by 2) is  "
    },
    {
      "t": 138068,
      "e": 98871,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "49"
    },
    {
      "t": 138069,
      "e": 98872,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 138147,
      "e": 98950,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Eny event that is onpositive sloped line intersecting 12pm or any event whose x-cordinate shifted to the left by their (y-cordinate divided by 2) is 1 "
    },
    {
      "t": 138332,
      "e": 99135,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "50"
    },
    {
      "t": 138332,
      "e": 99135,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 138395,
      "e": 99198,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Eny event that is onpositive sloped line intersecting 12pm or any event whose x-cordinate shifted to the left by their (y-cordinate divided by 2) is 12 "
    },
    {
      "t": 138652,
      "e": 99455,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "80"
    },
    {
      "t": 138653,
      "e": 99456,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 138724,
      "e": 99527,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Eny event that is onpositive sloped line intersecting 12pm or any event whose x-cordinate shifted to the left by their (y-cordinate divided by 2) is 12p "
    },
    {
      "t": 139092,
      "e": 99895,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "77"
    },
    {
      "t": 139095,
      "e": 99898,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 139163,
      "e": 99966,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Eny event that is onpositive sloped line intersecting 12pm or any event whose x-cordinate shifted to the left by their (y-cordinate divided by 2) is 12pm "
    },
    {
      "t": 140403,
      "e": 101206,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "190"
    },
    {
      "t": 140404,
      "e": 101207,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 140451,
      "e": 101207,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Eny event that is onpositive sloped line intersecting 12pm or any event whose x-cordinate shifted to the left by their (y-cordinate divided by 2) is 12pm. "
    },
    {
      "t": 140600,
      "e": 101356,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Eny event that is onpositive sloped line intersecting 12pm or any event whose x-cordinate shifted to the left by their (y-cordinate divided by 2) is 12pm. "
    },
    {
      "t": 140858,
      "e": 101614,
      "ty": 7,
      "x": 633,
      "y": 463,
      "ta": "#strategyAnswer"
    },
    {
      "t": 140898,
      "e": 101654,
      "ty": 2,
      "x": 599,
      "y": 429
    },
    {
      "t": 140998,
      "e": 101754,
      "ty": 2,
      "x": 608,
      "y": 440
    },
    {
      "t": 140998,
      "e": 101754,
      "ty": 41,
      "x": 57430,
      "y": 23931,
      "ta": "> div.stimulus > div"
    },
    {
      "t": 141091,
      "e": 101847,
      "ty": 6,
      "x": 527,
      "y": 522,
      "ta": "#strategyAnswer"
    },
    {
      "t": 141098,
      "e": 101854,
      "ty": 2,
      "x": 527,
      "y": 522
    },
    {
      "t": 141192,
      "e": 101948,
      "ty": 7,
      "x": 480,
      "y": 519,
      "ta": "#strategyAnswer"
    },
    {
      "t": 141197,
      "e": 101953,
      "ty": 2,
      "x": 480,
      "y": 519
    },
    {
      "t": 141248,
      "e": 102004,
      "ty": 41,
      "x": 27192,
      "y": 14664,
      "ta": "#.strategy > p"
    },
    {
      "t": 141298,
      "e": 102054,
      "ty": 2,
      "x": 310,
      "y": 507
    },
    {
      "t": 141398,
      "e": 102154,
      "ty": 2,
      "x": 305,
      "y": 509
    },
    {
      "t": 141458,
      "e": 102214,
      "ty": 6,
      "x": 295,
      "y": 523,
      "ta": "#strategyAnswer"
    },
    {
      "t": 141497,
      "e": 102253,
      "ty": 2,
      "x": 284,
      "y": 531
    },
    {
      "t": 141497,
      "e": 102253,
      "ty": 41,
      "x": 21010,
      "y": 6687,
      "ta": "#strategyAnswer"
    },
    {
      "t": 141597,
      "e": 102353,
      "ty": 2,
      "x": 278,
      "y": 534
    },
    {
      "t": 141664,
      "e": 102420,
      "ty": 3,
      "x": 278,
      "y": 534,
      "ta": "#strategyAnswer"
    },
    {
      "t": 141747,
      "e": 102503,
      "ty": 41,
      "x": 20110,
      "y": 10732,
      "ta": "#strategyAnswer"
    },
    {
      "t": 141751,
      "e": 102507,
      "ty": 4,
      "x": 20110,
      "y": 10732,
      "ta": "#strategyAnswer"
    },
    {
      "t": 141798,
      "e": 102554,
      "ty": 2,
      "x": 276,
      "y": 536
    },
    {
      "t": 144198,
      "e": 104954,
      "ty": 2,
      "x": 300,
      "y": 550
    },
    {
      "t": 144199,
      "e": 104955,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Eny event that is on positive sloped line intersecting 12pm or any event whose x-cordinate shifted to the left by their (y-cordinate divided by 2) is 12pm. "
    },
    {
      "t": 144248,
      "e": 105004,
      "ty": 41,
      "x": 22808,
      "y": 22059,
      "ta": "#strategyAnswer"
    },
    {
      "t": 144478,
      "e": 105234,
      "ty": 7,
      "x": 85,
      "y": 534,
      "ta": "#strategyAnswer"
    },
    {
      "t": 144497,
      "e": 105253,
      "ty": 2,
      "x": 12,
      "y": 531
    },
    {
      "t": 144497,
      "e": 105253,
      "ty": 41,
      "x": 137,
      "y": 28972,
      "ta": "> div.stimulus"
    },
    {
      "t": 144598,
      "e": 105354,
      "ty": 2,
      "x": 0,
      "y": 531
    },
    {
      "t": 144698,
      "e": 105454,
      "ty": 2,
      "x": 40,
      "y": 545
    },
    {
      "t": 144748,
      "e": 105504,
      "ty": 41,
      "x": 2513,
      "y": 30025,
      "ta": "> div.stimulus"
    },
    {
      "t": 144798,
      "e": 105554,
      "ty": 2,
      "x": 83,
      "y": 549
    },
    {
      "t": 144898,
      "e": 105654,
      "ty": 2,
      "x": 83,
      "y": 545
    },
    {
      "t": 144998,
      "e": 105754,
      "ty": 2,
      "x": 90,
      "y": 537
    },
    {
      "t": 144998,
      "e": 105754,
      "ty": 41,
      "x": 2823,
      "y": 29305,
      "ta": "> div.stimulus"
    },
    {
      "t": 145063,
      "e": 105819,
      "ty": 6,
      "x": 97,
      "y": 532,
      "ta": "#strategyAnswer"
    },
    {
      "t": 145097,
      "e": 105853,
      "ty": 2,
      "x": 99,
      "y": 531
    },
    {
      "t": 145198,
      "e": 105954,
      "ty": 2,
      "x": 102,
      "y": 530
    },
    {
      "t": 145223,
      "e": 105979,
      "ty": 3,
      "x": 102,
      "y": 530,
      "ta": "#strategyAnswer"
    },
    {
      "t": 145247,
      "e": 106003,
      "ty": 41,
      "x": 663,
      "y": 5878,
      "ta": "#strategyAnswer"
    },
    {
      "t": 145298,
      "e": 106054,
      "ty": 2,
      "x": 104,
      "y": 530
    },
    {
      "t": 145304,
      "e": 106060,
      "ty": 4,
      "x": 888,
      "y": 5878,
      "ta": "#strategyAnswer"
    },
    {
      "t": 145398,
      "e": 106154,
      "ty": 2,
      "x": 105,
      "y": 530
    },
    {
      "t": 145498,
      "e": 106254,
      "ty": 41,
      "x": 888,
      "y": 5878,
      "ta": "#strategyAnswer"
    },
    {
      "t": 146498,
      "e": 107254,
      "ty": 2,
      "x": 210,
      "y": 548
    },
    {
      "t": 146498,
      "e": 107254,
      "ty": 41,
      "x": 12691,
      "y": 20441,
      "ta": "#strategyAnswer"
    },
    {
      "t": 146598,
      "e": 107354,
      "ty": 2,
      "x": 275,
      "y": 546
    },
    {
      "t": 146599,
      "e": 107355,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Any event that is on positive sloped line intersecting 12pm or any event whose x-cordinate shifted to the left by their (y-cordinate divided by 2) is 12pm. "
    },
    {
      "t": 146698,
      "e": 107454,
      "ty": 2,
      "x": 304,
      "y": 543
    },
    {
      "t": 146748,
      "e": 107504,
      "ty": 41,
      "x": 23370,
      "y": 16396,
      "ta": "#strategyAnswer"
    },
    {
      "t": 146798,
      "e": 107554,
      "ty": 2,
      "x": 307,
      "y": 541
    },
    {
      "t": 146898,
      "e": 107654,
      "ty": 2,
      "x": 310,
      "y": 541
    },
    {
      "t": 146997,
      "e": 107753,
      "ty": 2,
      "x": 308,
      "y": 538
    },
    {
      "t": 146997,
      "e": 107753,
      "ty": 41,
      "x": 23707,
      "y": 12351,
      "ta": "#strategyAnswer"
    },
    {
      "t": 147097,
      "e": 107853,
      "ty": 2,
      "x": 295,
      "y": 537
    },
    {
      "t": 147198,
      "e": 107954,
      "ty": 2,
      "x": 279,
      "y": 537
    },
    {
      "t": 147248,
      "e": 108004,
      "ty": 41,
      "x": 19323,
      "y": 12351,
      "ta": "#strategyAnswer"
    },
    {
      "t": 147298,
      "e": 108054,
      "ty": 2,
      "x": 268,
      "y": 538
    },
    {
      "t": 147398,
      "e": 108154,
      "ty": 2,
      "x": 255,
      "y": 538
    },
    {
      "t": 147497,
      "e": 108253,
      "ty": 2,
      "x": 251,
      "y": 538
    },
    {
      "t": 147498,
      "e": 108254,
      "ty": 41,
      "x": 17300,
      "y": 12351,
      "ta": "#strategyAnswer"
    },
    {
      "t": 147599,
      "e": 108355,
      "ty": 3,
      "x": 251,
      "y": 538,
      "ta": "#strategyAnswer"
    },
    {
      "t": 147695,
      "e": 108356,
      "ty": 4,
      "x": 17300,
      "y": 12351,
      "ta": "#strategyAnswer"
    },
    {
      "t": 147696,
      "e": 108357,
      "ty": 5,
      "x": 251,
      "y": 538,
      "ta": "#strategyAnswer"
    },
    {
      "t": 147898,
      "e": 108559,
      "ty": 2,
      "x": 263,
      "y": 544
    },
    {
      "t": 147998,
      "e": 108659,
      "ty": 2,
      "x": 264,
      "y": 546
    },
    {
      "t": 147999,
      "e": 108660,
      "ty": 41,
      "x": 18761,
      "y": 18823,
      "ta": "#strategyAnswer"
    },
    {
      "t": 148235,
      "e": 108896,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 148235,
      "e": 108896,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 148331,
      "e": 108992,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Any event that is on apositive sloped line intersecting 12pm or any event whose x-cordinate shifted to the left by their (y-cordinate divided by 2) is 12pm. "
    },
    {
      "t": 148499,
      "e": 109160,
      "ty": 2,
      "x": 252,
      "y": 563
    },
    {
      "t": 148499,
      "e": 109160,
      "ty": 41,
      "x": 17413,
      "y": 32577,
      "ta": "#strategyAnswer"
    },
    {
      "t": 148524,
      "e": 109185,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 148525,
      "e": 109186,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 148597,
      "e": 109258,
      "ty": 2,
      "x": 212,
      "y": 577
    },
    {
      "t": 148618,
      "e": 109279,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Any event that is on a positive sloped line intersecting 12pm or any event whose x-cordinate shifted to the left by their (y-cordinate divided by 2) is 12pm. "
    },
    {
      "t": 148697,
      "e": 109358,
      "ty": 2,
      "x": 208,
      "y": 568
    },
    {
      "t": 148747,
      "e": 109408,
      "ty": 41,
      "x": 12129,
      "y": 29341,
      "ta": "#strategyAnswer"
    },
    {
      "t": 148797,
      "e": 109458,
      "ty": 2,
      "x": 205,
      "y": 556
    },
    {
      "t": 148872,
      "e": 109533,
      "ty": 3,
      "x": 205,
      "y": 556,
      "ta": "#strategyAnswer"
    },
    {
      "t": 148967,
      "e": 109628,
      "ty": 4,
      "x": 12129,
      "y": 26914,
      "ta": "#strategyAnswer"
    },
    {
      "t": 148998,
      "e": 109659,
      "ty": 41,
      "x": 12129,
      "y": 26914,
      "ta": "#strategyAnswer"
    },
    {
      "t": 149450,
      "e": 110111,
      "ty": 3,
      "x": 204,
      "y": 556,
      "ta": "#strategyAnswer"
    },
    {
      "t": 149498,
      "e": 110159,
      "ty": 2,
      "x": 204,
      "y": 556
    },
    {
      "t": 149498,
      "e": 110159,
      "ty": 41,
      "x": 12017,
      "y": 26914,
      "ta": "#strategyAnswer"
    },
    {
      "t": 149552,
      "e": 110213,
      "ty": 4,
      "x": 12017,
      "y": 26914,
      "ta": "#strategyAnswer"
    },
    {
      "t": 149881,
      "e": 110542,
      "ty": 3,
      "x": 202,
      "y": 550,
      "ta": "#strategyAnswer"
    },
    {
      "t": 149898,
      "e": 110559,
      "ty": 2,
      "x": 201,
      "y": 550
    },
    {
      "t": 149975,
      "e": 110636,
      "ty": 4,
      "x": 11455,
      "y": 22059,
      "ta": "#strategyAnswer"
    },
    {
      "t": 150011,
      "e": 110672,
      "ty": 2,
      "x": 199,
      "y": 550
    },
    {
      "t": 150011,
      "e": 110672,
      "ty": 41,
      "x": 11455,
      "y": 22059,
      "ta": "#strategyAnswer"
    },
    {
      "t": 150466,
      "e": 111127,
      "ty": 3,
      "x": 228,
      "y": 549,
      "ta": "#strategyAnswer"
    },
    {
      "t": 150498,
      "e": 111159,
      "ty": 2,
      "x": 228,
      "y": 549
    },
    {
      "t": 150498,
      "e": 111159,
      "ty": 41,
      "x": 14715,
      "y": 21250,
      "ta": "#strategyAnswer"
    },
    {
      "t": 150535,
      "e": 111196,
      "ty": 4,
      "x": 14715,
      "y": 21250,
      "ta": "#strategyAnswer"
    },
    {
      "t": 150535,
      "e": 111196,
      "ty": 5,
      "x": 228,
      "y": 549,
      "ta": "#strategyAnswer"
    },
    {
      "t": 150898,
      "e": 111559,
      "ty": 2,
      "x": 221,
      "y": 550
    },
    {
      "t": 150968,
      "e": 111629,
      "ty": 3,
      "x": 206,
      "y": 547,
      "ta": "#strategyAnswer"
    },
    {
      "t": 150998,
      "e": 111659,
      "ty": 2,
      "x": 206,
      "y": 547
    },
    {
      "t": 150998,
      "e": 111659,
      "ty": 41,
      "x": 12242,
      "y": 19632,
      "ta": "#strategyAnswer"
    },
    {
      "t": 151071,
      "e": 111732,
      "ty": 4,
      "x": 12242,
      "y": 19632,
      "ta": "#strategyAnswer"
    },
    {
      "t": 151116,
      "e": 111777,
      "ty": 2,
      "x": 206,
      "y": 546
    },
    {
      "t": 151248,
      "e": 111909,
      "ty": 41,
      "x": 12242,
      "y": 18823,
      "ta": "#strategyAnswer"
    },
    {
      "t": 152098,
      "e": 112759,
      "ty": 2,
      "x": 228,
      "y": 579
    },
    {
      "t": 152197,
      "e": 112858,
      "ty": 2,
      "x": 214,
      "y": 562
    },
    {
      "t": 152199,
      "e": 112860,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Any event that is on a positive sloped line intersecting 12pm or any event whose x-coordinate shifted to the left by their (y-cordinate divided by 2) is 12pm. "
    },
    {
      "t": 152247,
      "e": 112908,
      "ty": 41,
      "x": 12129,
      "y": 25296,
      "ta": "#strategyAnswer"
    },
    {
      "t": 152298,
      "e": 112959,
      "ty": 2,
      "x": 205,
      "y": 554
    },
    {
      "t": 152328,
      "e": 112989,
      "ty": 3,
      "x": 205,
      "y": 554,
      "ta": "#strategyAnswer"
    },
    {
      "t": 152407,
      "e": 113068,
      "ty": 4,
      "x": 12129,
      "y": 25296,
      "ta": "#strategyAnswer"
    },
    {
      "t": 152407,
      "e": 113068,
      "ty": 5,
      "x": 205,
      "y": 554,
      "ta": "#strategyAnswer"
    },
    {
      "t": 152495,
      "e": 113156,
      "ty": 3,
      "x": 205,
      "y": 554,
      "ta": "#strategyAnswer"
    },
    {
      "t": 152559,
      "e": 113220,
      "ty": 4,
      "x": 12129,
      "y": 25296,
      "ta": "#strategyAnswer"
    },
    {
      "t": 152559,
      "e": 113220,
      "ty": 5,
      "x": 205,
      "y": 554,
      "ta": "#strategyAnswer"
    },
    {
      "t": 152797,
      "e": 113458,
      "ty": 2,
      "x": 205,
      "y": 552
    },
    {
      "t": 152811,
      "e": 113472,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "17"
    },
    {
      "t": 152897,
      "e": 113558,
      "ty": 2,
      "x": 214,
      "y": 546
    },
    {
      "t": 152997,
      "e": 113658,
      "ty": 2,
      "x": 267,
      "y": 536
    },
    {
      "t": 152998,
      "e": 113659,
      "ty": 41,
      "x": 19099,
      "y": 10732,
      "ta": "#strategyAnswer"
    },
    {
      "t": 153098,
      "e": 113759,
      "ty": 2,
      "x": 316,
      "y": 542
    },
    {
      "t": 153197,
      "e": 113858,
      "ty": 2,
      "x": 363,
      "y": 542
    },
    {
      "t": 153248,
      "e": 113909,
      "ty": 41,
      "x": 30340,
      "y": 15587,
      "ta": "#strategyAnswer"
    },
    {
      "t": 153297,
      "e": 113958,
      "ty": 2,
      "x": 367,
      "y": 542
    },
    {
      "t": 153311,
      "e": 113972,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "17"
    },
    {
      "t": 153332,
      "e": 113993,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "67"
    },
    {
      "t": 153398,
      "e": 114059,
      "ty": 2,
      "x": 380,
      "y": 538
    },
    {
      "t": 153497,
      "e": 114158,
      "ty": 2,
      "x": 428,
      "y": 540
    },
    {
      "t": 153497,
      "e": 114158,
      "ty": 41,
      "x": 37197,
      "y": 13969,
      "ta": "#strategyAnswer"
    },
    {
      "t": 153580,
      "e": 114159,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Any event that is on a positive sloped line intersecting 12pm or any event whose x-coordinate shifted to the left by their (y-cordinate divided by 2) is 12pm. "
    },
    {
      "t": 153595,
      "e": 114174,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 153597,
      "e": 114176,
      "ty": 2,
      "x": 485,
      "y": 556
    },
    {
      "t": 153698,
      "e": 114277,
      "ty": 2,
      "x": 507,
      "y": 558
    },
    {
      "t": 153747,
      "e": 114326,
      "ty": 41,
      "x": 47201,
      "y": 29341,
      "ta": "#strategyAnswer"
    },
    {
      "t": 153797,
      "e": 114376,
      "ty": 2,
      "x": 529,
      "y": 560
    },
    {
      "t": 153897,
      "e": 114476,
      "ty": 2,
      "x": 535,
      "y": 560
    },
    {
      "t": 153997,
      "e": 114576,
      "ty": 2,
      "x": 533,
      "y": 560
    },
    {
      "t": 153997,
      "e": 114576,
      "ty": 41,
      "x": 49000,
      "y": 30150,
      "ta": "#strategyAnswer"
    },
    {
      "t": 154097,
      "e": 114676,
      "ty": 2,
      "x": 523,
      "y": 559
    },
    {
      "t": 154197,
      "e": 114776,
      "ty": 2,
      "x": 514,
      "y": 559
    },
    {
      "t": 154247,
      "e": 114826,
      "ty": 41,
      "x": 45627,
      "y": 22868,
      "ta": "#strategyAnswer"
    },
    {
      "t": 154297,
      "e": 114876,
      "ty": 2,
      "x": 503,
      "y": 551
    },
    {
      "t": 154328,
      "e": 114907,
      "ty": 3,
      "x": 503,
      "y": 551,
      "ta": "#strategyAnswer"
    },
    {
      "t": 154422,
      "e": 115001,
      "ty": 4,
      "x": 45627,
      "y": 22868,
      "ta": "#strategyAnswer"
    },
    {
      "t": 154422,
      "e": 115001,
      "ty": 5,
      "x": 503,
      "y": 551,
      "ta": "#strategyAnswer"
    },
    {
      "t": 154471,
      "e": 115050,
      "ty": 3,
      "x": 503,
      "y": 551,
      "ta": "#strategyAnswer"
    },
    {
      "t": 154559,
      "e": 115138,
      "ty": 4,
      "x": 45627,
      "y": 22868,
      "ta": "#strategyAnswer"
    },
    {
      "t": 154559,
      "e": 115138,
      "ty": 5,
      "x": 503,
      "y": 551,
      "ta": "#strategyAnswer"
    },
    {
      "t": 154571,
      "e": 115150,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "17"
    },
    {
      "t": 154700,
      "e": 115279,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "86"
    },
    {
      "t": 154747,
      "e": 115326,
      "ty": 41,
      "x": 44616,
      "y": 22868,
      "ta": "#strategyAnswer"
    },
    {
      "t": 154797,
      "e": 115376,
      "ty": 2,
      "x": 463,
      "y": 555
    },
    {
      "t": 154842,
      "e": 115421,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Any event that is on a positive sloped line intersecting 12pm or any event whose x-coordinate shifted to the left by their (y-coordinate divided by 2) is 12pm. "
    },
    {
      "t": 154851,
      "e": 115430,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 154898,
      "e": 115477,
      "ty": 2,
      "x": 323,
      "y": 582
    },
    {
      "t": 154997,
      "e": 115576,
      "ty": 2,
      "x": 250,
      "y": 586
    },
    {
      "t": 154997,
      "e": 115576,
      "ty": 41,
      "x": 17188,
      "y": 51186,
      "ta": "#strategyAnswer"
    },
    {
      "t": 155097,
      "e": 115676,
      "ty": 2,
      "x": 190,
      "y": 585
    },
    {
      "t": 155197,
      "e": 115776,
      "ty": 2,
      "x": 115,
      "y": 579
    },
    {
      "t": 155247,
      "e": 115826,
      "ty": 41,
      "x": 2125,
      "y": 41477,
      "ta": "#strategyAnswer"
    },
    {
      "t": 155297,
      "e": 115876,
      "ty": 2,
      "x": 117,
      "y": 573
    },
    {
      "t": 155397,
      "e": 115976,
      "ty": 2,
      "x": 118,
      "y": 568
    },
    {
      "t": 155497,
      "e": 116076,
      "ty": 41,
      "x": 2350,
      "y": 36623,
      "ta": "#strategyAnswer"
    },
    {
      "t": 155511,
      "e": 116090,
      "ty": 3,
      "x": 118,
      "y": 568,
      "ta": "#strategyAnswer"
    },
    {
      "t": 155597,
      "e": 116176,
      "ty": 2,
      "x": 119,
      "y": 567
    },
    {
      "t": 155623,
      "e": 116202,
      "ty": 4,
      "x": 2462,
      "y": 35814,
      "ta": "#strategyAnswer"
    },
    {
      "t": 155747,
      "e": 116326,
      "ty": 41,
      "x": 2462,
      "y": 35814,
      "ta": "#strategyAnswer"
    },
    {
      "t": 156338,
      "e": 116917,
      "ty": 3,
      "x": 276,
      "y": 543,
      "ta": "#strategyAnswer"
    },
    {
      "t": 156397,
      "e": 116976,
      "ty": 2,
      "x": 276,
      "y": 543
    },
    {
      "t": 156415,
      "e": 116994,
      "ty": 4,
      "x": 20110,
      "y": 16396,
      "ta": "#strategyAnswer"
    },
    {
      "t": 156415,
      "e": 116994,
      "ty": 5,
      "x": 276,
      "y": 543,
      "ta": "#strategyAnswer"
    },
    {
      "t": 156497,
      "e": 117076,
      "ty": 2,
      "x": 298,
      "y": 541
    },
    {
      "t": 156498,
      "e": 117077,
      "ty": 41,
      "x": 22583,
      "y": 14778,
      "ta": "#strategyAnswer"
    },
    {
      "t": 156597,
      "e": 117176,
      "ty": 2,
      "x": 443,
      "y": 553
    },
    {
      "t": 156697,
      "e": 117276,
      "ty": 2,
      "x": 479,
      "y": 559
    },
    {
      "t": 156747,
      "e": 117326,
      "ty": 41,
      "x": 42705,
      "y": 34196,
      "ta": "#strategyAnswer"
    },
    {
      "t": 156798,
      "e": 117377,
      "ty": 2,
      "x": 461,
      "y": 601
    },
    {
      "t": 156802,
      "e": 117381,
      "ty": 7,
      "x": 456,
      "y": 615,
      "ta": "#strategyAnswer"
    },
    {
      "t": 156889,
      "e": 117468,
      "ty": 6,
      "x": 439,
      "y": 655,
      "ta": "#strategyButton"
    },
    {
      "t": 156897,
      "e": 117476,
      "ty": 2,
      "x": 439,
      "y": 655
    },
    {
      "t": 156997,
      "e": 117576,
      "ty": 2,
      "x": 433,
      "y": 659
    },
    {
      "t": 156997,
      "e": 117576,
      "ty": 41,
      "x": 51557,
      "y": 8221,
      "ta": "#strategyButton"
    },
    {
      "t": 157097,
      "e": 117676,
      "ty": 2,
      "x": 431,
      "y": 659
    },
    {
      "t": 157193,
      "e": 117772,
      "ty": 3,
      "x": 431,
      "y": 659,
      "ta": "#strategyButton"
    },
    {
      "t": 157193,
      "e": 117772,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Any event that is on a positive sloped line intersecting 12pm or any event whose x-coordinate shifted to the left by their (y-coordinate divided by 2) is 12pm. "
    },
    {
      "t": 157194,
      "e": 117773,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 157195,
      "e": 117774,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#strategyButton"
    },
    {
      "t": 157247,
      "e": 117826,
      "ty": 41,
      "x": 50465,
      "y": 8221,
      "ta": "#strategyButton"
    },
    {
      "t": 157344,
      "e": 117923,
      "ty": 4,
      "x": 50465,
      "y": 8221,
      "ta": "#strategyButton"
    },
    {
      "t": 157363,
      "e": 117942,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#strategyButton"
    },
    {
      "t": 157364,
      "e": 117943,
      "ty": 5,
      "x": 431,
      "y": 659,
      "ta": "#strategyButton"
    },
    {
      "t": 157370,
      "e": 117949,
      "ty": 38,
      "x": 1,
      "y": 0
    },
    {
      "t": 157597,
      "e": 118176,
      "ty": 2,
      "x": 423,
      "y": 660
    },
    {
      "t": 157747,
      "e": 118326,
      "ty": 41,
      "x": 14291,
      "y": 36119,
      "ta": "html > body"
    },
    {
      "t": 158197,
      "e": 118776,
      "ty": 2,
      "x": 422,
      "y": 660
    },
    {
      "t": 158248,
      "e": 118827,
      "ty": 41,
      "x": 14360,
      "y": 36119,
      "ta": "html > body"
    },
    {
      "t": 158297,
      "e": 118876,
      "ty": 2,
      "x": 446,
      "y": 647
    },
    {
      "t": 158379,
      "e": 118958,
      "ty": 38,
      "x": 2,
      "y": 0
    },
    {
      "t": 158397,
      "e": 118976,
      "ty": 2,
      "x": 454,
      "y": 644
    },
    {
      "t": 158497,
      "e": 119076,
      "ty": 2,
      "x": 455,
      "y": 642
    },
    {
      "t": 158497,
      "e": 119076,
      "ty": 41,
      "x": 15393,
      "y": 35121,
      "ta": "html > body"
    },
    {
      "t": 158597,
      "e": 119176,
      "ty": 2,
      "x": 457,
      "y": 641
    },
    {
      "t": 158697,
      "e": 119276,
      "ty": 2,
      "x": 457,
      "y": 634
    },
    {
      "t": 158747,
      "e": 119326,
      "ty": 41,
      "x": 15462,
      "y": 34678,
      "ta": "html > body"
    },
    {
      "t": 158797,
      "e": 119376,
      "ty": 2,
      "x": 460,
      "y": 630
    },
    {
      "t": 158897,
      "e": 119476,
      "ty": 2,
      "x": 493,
      "y": 596
    },
    {
      "t": 158997,
      "e": 119576,
      "ty": 2,
      "x": 513,
      "y": 589
    },
    {
      "t": 158998,
      "e": 119577,
      "ty": 41,
      "x": 17391,
      "y": 32185,
      "ta": "html > body"
    },
    {
      "t": 159097,
      "e": 119676,
      "ty": 2,
      "x": 685,
      "y": 567
    },
    {
      "t": 159198,
      "e": 119777,
      "ty": 2,
      "x": 777,
      "y": 574
    },
    {
      "t": 159248,
      "e": 119778,
      "ty": 41,
      "x": 0,
      "y": 704,
      "ta": "#jspsych-survey-text-1"
    },
    {
      "t": 159297,
      "e": 119827,
      "ty": 2,
      "x": 816,
      "y": 587
    },
    {
      "t": 159397,
      "e": 119927,
      "ty": 2,
      "x": 831,
      "y": 583
    },
    {
      "t": 159497,
      "e": 120027,
      "ty": 2,
      "x": 839,
      "y": 576
    },
    {
      "t": 159498,
      "e": 120028,
      "ty": 41,
      "x": 6704,
      "y": 60602,
      "ta": "#jspsych-survey-text-0"
    },
    {
      "t": 159528,
      "e": 120058,
      "ty": 3,
      "x": 840,
      "y": 575,
      "ta": "#jspsych-survey-text-0"
    },
    {
      "t": 159597,
      "e": 120127,
      "ty": 2,
      "x": 840,
      "y": 575
    },
    {
      "t": 159615,
      "e": 120145,
      "ty": 4,
      "x": 6921,
      "y": 59897,
      "ta": "#jspsych-survey-text-0"
    },
    {
      "t": 159616,
      "e": 120146,
      "ty": 5,
      "x": 840,
      "y": 575,
      "ta": "#jspsych-survey-text-0"
    },
    {
      "t": 159632,
      "e": 120162,
      "ty": 6,
      "x": 841,
      "y": 574,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 159697,
      "e": 120227,
      "ty": 2,
      "x": 843,
      "y": 573
    },
    {
      "t": 159748,
      "e": 120278,
      "ty": 41,
      "x": 7570,
      "y": 59293,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 159798,
      "e": 120328,
      "ty": 2,
      "x": 845,
      "y": 573
    },
    {
      "t": 159840,
      "e": 120370,
      "ty": 3,
      "x": 845,
      "y": 573,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 159841,
      "e": 120371,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 159919,
      "e": 120449,
      "ty": 4,
      "x": 8002,
      "y": 59293,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 159919,
      "e": 120449,
      "ty": 5,
      "x": 845,
      "y": 573,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 159997,
      "e": 120527,
      "ty": 2,
      "x": 846,
      "y": 572
    },
    {
      "t": 159997,
      "e": 120527,
      "ty": 41,
      "x": 8218,
      "y": 56172,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 160057,
      "e": 120587,
      "ty": 7,
      "x": 870,
      "y": 606,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 160073,
      "e": 120603,
      "ty": 6,
      "x": 886,
      "y": 654,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 160097,
      "e": 120627,
      "ty": 2,
      "x": 888,
      "y": 657
    },
    {
      "t": 160247,
      "e": 120777,
      "ty": 41,
      "x": 17302,
      "y": 31207,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 160587,
      "e": 121117,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "97"
    },
    {
      "t": 160588,
      "e": 121118,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 160691,
      "e": 121221,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "1"
    },
    {
      "t": 160827,
      "e": 121357,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "105"
    },
    {
      "t": 160828,
      "e": 121358,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 160915,
      "e": 121445,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "19"
    },
    {
      "t": 161902,
      "e": 122432,
      "ty": 2,
      "x": 888,
      "y": 658
    },
    {
      "t": 161935,
      "e": 122465,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "9"
    },
    {
      "t": 161935,
      "e": 122465,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "19"
    },
    {
      "t": 161935,
      "e": 122465,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 161935,
      "e": 122465,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 162002,
      "e": 122532,
      "ty": 41,
      "x": 17302,
      "y": 34327,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 162063,
      "e": 122593,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": ""
    },
    {
      "t": 162664,
      "e": 123194,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "16"
    },
    {
      "t": 162864,
      "e": 123394,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "73"
    },
    {
      "t": 162865,
      "e": 123395,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 162919,
      "e": 123449,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "I"
    },
    {
      "t": 162928,
      "e": 123458,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "I"
    },
    {
      "t": 163088,
      "e": 123618,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "83"
    },
    {
      "t": 163089,
      "e": 123619,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 163176,
      "e": 123706,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "Is"
    },
    {
      "t": 163264,
      "e": 123794,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "82"
    },
    {
      "t": 163264,
      "e": 123794,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 163335,
      "e": 123865,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "Isr"
    },
    {
      "t": 163383,
      "e": 123913,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "65"
    },
    {
      "t": 163383,
      "e": 123913,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 163447,
      "e": 123977,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "Isra"
    },
    {
      "t": 163511,
      "e": 124041,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "69"
    },
    {
      "t": 163512,
      "e": 124042,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 163575,
      "e": 124105,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "+||e"
    },
    {
      "t": 163840,
      "e": 124370,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "76"
    },
    {
      "t": 163841,
      "e": 124371,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 163927,
      "e": 124457,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "+||l"
    },
    {
      "t": 164159,
      "e": 124689,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "13"
    },
    {
      "t": 164160,
      "e": 124690,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 164231,
      "e": 124761,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "+||\n"
    },
    {
      "t": 165295,
      "e": 125825,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "8"
    },
    {
      "t": 165352,
      "e": 125882,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "Israel"
    },
    {
      "t": 165402,
      "e": 125932,
      "ty": 2,
      "x": 900,
      "y": 666
    },
    {
      "t": 165416,
      "e": 125946,
      "ty": 7,
      "x": 906,
      "y": 680,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 165416,
      "e": 125946,
      "ty": 6,
      "x": 906,
      "y": 680,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 165502,
      "e": 126032,
      "ty": 2,
      "x": 914,
      "y": 704
    },
    {
      "t": 165502,
      "e": 126032,
      "ty": 41,
      "x": 9317,
      "y": 55605,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 165702,
      "e": 126232,
      "ty": 2,
      "x": 917,
      "y": 704
    },
    {
      "t": 165752,
      "e": 126282,
      "ty": 41,
      "x": 10863,
      "y": 55605,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 165802,
      "e": 126332,
      "ty": 2,
      "x": 922,
      "y": 696
    },
    {
      "t": 165837,
      "e": 126367,
      "ty": 3,
      "x": 922,
      "y": 696,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 165838,
      "e": 126368,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "Israel"
    },
    {
      "t": 165838,
      "e": 126368,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 165838,
      "e": 126368,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 165915,
      "e": 126445,
      "ty": 4,
      "x": 13440,
      "y": 39718,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 165916,
      "e": 126446,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 165916,
      "e": 126446,
      "ty": 5,
      "x": 922,
      "y": 696,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 165916,
      "e": 126446,
      "ty": 38,
      "x": 3,
      "y": 0
    },
    {
      "t": 166002,
      "e": 126532,
      "ty": 41,
      "x": 31476,
      "y": 38113,
      "ta": "html > body"
    },
    {
      "t": 166102,
      "e": 126632,
      "ty": 2,
      "x": 904,
      "y": 697
    },
    {
      "t": 166202,
      "e": 126732,
      "ty": 2,
      "x": 805,
      "y": 716
    },
    {
      "t": 166252,
      "e": 126782,
      "ty": 41,
      "x": 26000,
      "y": 39387,
      "ta": "html > body"
    },
    {
      "t": 166302,
      "e": 126832,
      "ty": 2,
      "x": 746,
      "y": 722
    },
    {
      "t": 166402,
      "e": 126932,
      "ty": 2,
      "x": 721,
      "y": 731
    },
    {
      "t": 166502,
      "e": 127032,
      "ty": 2,
      "x": 720,
      "y": 731
    },
    {
      "t": 166502,
      "e": 127032,
      "ty": 41,
      "x": 24519,
      "y": 40052,
      "ta": "html > body"
    },
    {
      "t": 166927,
      "e": 127457,
      "ty": 38,
      "x": 4,
      "y": 0
    },
    {
      "t": 167202,
      "e": 127732,
      "ty": 2,
      "x": 721,
      "y": 729
    },
    {
      "t": 167252,
      "e": 127782,
      "ty": 41,
      "x": 24554,
      "y": 39941,
      "ta": "html > body"
    },
    {
      "t": 167402,
      "e": 127932,
      "ty": 2,
      "x": 737,
      "y": 704
    },
    {
      "t": 167502,
      "e": 128032,
      "ty": 2,
      "x": 737,
      "y": 601
    },
    {
      "t": 167502,
      "e": 128032,
      "ty": 41,
      "x": 25105,
      "y": 32850,
      "ta": "html > body"
    },
    {
      "t": 167602,
      "e": 128132,
      "ty": 2,
      "x": 721,
      "y": 563
    },
    {
      "t": 167635,
      "e": 128165,
      "ty": 3,
      "x": 718,
      "y": 562,
      "ta": "html > body"
    },
    {
      "t": 167698,
      "e": 128228,
      "ty": 4,
      "x": 24450,
      "y": 30690,
      "ta": "html > body"
    },
    {
      "t": 167702,
      "e": 128232,
      "ty": 2,
      "x": 718,
      "y": 562
    },
    {
      "t": 167752,
      "e": 128282,
      "ty": 41,
      "x": 24450,
      "y": 30690,
      "ta": "html > body"
    },
    {
      "t": 167972,
      "e": 128502,
      "ty": 3,
      "x": 646,
      "y": 561,
      "ta": "html > body"
    },
    {
      "t": 168002,
      "e": 128532,
      "ty": 2,
      "x": 646,
      "y": 561
    },
    {
      "t": 168002,
      "e": 128532,
      "ty": 41,
      "x": 21971,
      "y": 30634,
      "ta": "html > body"
    },
    {
      "t": 168043,
      "e": 128573,
      "ty": 4,
      "x": 21971,
      "y": 30634,
      "ta": "html > body"
    },
    {
      "t": 168043,
      "e": 128573,
      "ty": 5,
      "x": 646,
      "y": 561,
      "ta": "html > body"
    },
    {
      "t": 168102,
      "e": 128632,
      "ty": 2,
      "x": 644,
      "y": 561
    },
    {
      "t": 168201,
      "e": 128731,
      "ty": 2,
      "x": 617,
      "y": 593
    },
    {
      "t": 168252,
      "e": 128782,
      "ty": 41,
      "x": 20972,
      "y": 32407,
      "ta": "html > body"
    },
    {
      "t": 168602,
      "e": 129132,
      "ty": 2,
      "x": 621,
      "y": 583
    },
    {
      "t": 168701,
      "e": 129231,
      "ty": 2,
      "x": 651,
      "y": 545
    },
    {
      "t": 168752,
      "e": 129282,
      "ty": 41,
      "x": 23245,
      "y": 27366,
      "ta": "html > body"
    },
    {
      "t": 168801,
      "e": 129331,
      "ty": 2,
      "x": 697,
      "y": 476
    },
    {
      "t": 168902,
      "e": 129432,
      "ty": 2,
      "x": 707,
      "y": 430
    },
    {
      "t": 169002,
      "e": 129532,
      "ty": 2,
      "x": 721,
      "y": 395
    },
    {
      "t": 169002,
      "e": 129532,
      "ty": 41,
      "x": 24554,
      "y": 21438,
      "ta": "html > body"
    },
    {
      "t": 169102,
      "e": 129632,
      "ty": 2,
      "x": 733,
      "y": 375
    },
    {
      "t": 169202,
      "e": 129732,
      "ty": 2,
      "x": 733,
      "y": 374
    },
    {
      "t": 169252,
      "e": 129782,
      "ty": 41,
      "x": 24967,
      "y": 20275,
      "ta": "html > body"
    },
    {
      "t": 169302,
      "e": 129832,
      "ty": 2,
      "x": 733,
      "y": 373
    },
    {
      "t": 169401,
      "e": 129931,
      "ty": 2,
      "x": 731,
      "y": 356
    },
    {
      "t": 169502,
      "e": 130032,
      "ty": 2,
      "x": 740,
      "y": 338
    },
    {
      "t": 169502,
      "e": 130032,
      "ty": 41,
      "x": 25208,
      "y": 18281,
      "ta": "html > body"
    },
    {
      "t": 169602,
      "e": 130132,
      "ty": 2,
      "x": 759,
      "y": 317
    },
    {
      "t": 169702,
      "e": 130232,
      "ty": 2,
      "x": 790,
      "y": 292
    },
    {
      "t": 169752,
      "e": 130282,
      "ty": 41,
      "x": 27274,
      "y": 15455,
      "ta": "html > body"
    },
    {
      "t": 169801,
      "e": 130331,
      "ty": 2,
      "x": 804,
      "y": 285
    },
    {
      "t": 169902,
      "e": 130432,
      "ty": 2,
      "x": 824,
      "y": 288
    },
    {
      "t": 169902,
      "e": 130432,
      "ty": 6,
      "x": 826,
      "y": 290,
      "ta": "jspsych-survey-multi-choice-response-0[2]_mf"
    },
    {
      "t": 169985,
      "e": 130515,
      "ty": 7,
      "x": 835,
      "y": 301,
      "ta": "jspsych-survey-multi-choice-response-0[2]_mf"
    },
    {
      "t": 170002,
      "e": 130532,
      "ty": 2,
      "x": 835,
      "y": 301
    },
    {
      "t": 170002,
      "e": 130532,
      "ty": 41,
      "x": 4255,
      "y": 52428,
      "ta": "#jspsych-survey-multi-choice-option-0-2 > label"
    },
    {
      "t": 170102,
      "e": 130632,
      "ty": 2,
      "x": 842,
      "y": 312
    },
    {
      "t": 170202,
      "e": 130732,
      "ty": 2,
      "x": 848,
      "y": 316
    },
    {
      "t": 170253,
      "e": 130783,
      "ty": 41,
      "x": 26384,
      "y": 9830,
      "ta": "#jspsych-survey-multi-choice-option-0-3 > label"
    },
    {
      "t": 170302,
      "e": 130832,
      "ty": 2,
      "x": 848,
      "y": 318
    },
    {
      "t": 170403,
      "e": 130933,
      "ty": 2,
      "x": 849,
      "y": 320
    },
    {
      "t": 170502,
      "e": 131032,
      "ty": 41,
      "x": 27377,
      "y": 22937,
      "ta": "#jspsych-survey-multi-choice-option-0-3 > label"
    },
    {
      "t": 170532,
      "e": 131062,
      "ty": 3,
      "x": 849,
      "y": 320,
      "ta": "#jspsych-survey-multi-choice-option-0-3 > label"
    },
    {
      "t": 170620,
      "e": 131150,
      "ty": 4,
      "x": 27377,
      "y": 22937,
      "ta": "#jspsych-survey-multi-choice-option-0-3 > label"
    },
    {
      "t": 170620,
      "e": 131150,
      "ty": 5,
      "x": 849,
      "y": 320,
      "ta": "#jspsych-survey-multi-choice-option-0-3 > label"
    },
    {
      "t": 170621,
      "e": 131151,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-0[3]_mf"
    },
    {
      "t": 170623,
      "e": 131153,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-0[3]_mf",
      "v": "Other"
    },
    {
      "t": 170802,
      "e": 131332,
      "ty": 2,
      "x": 855,
      "y": 323
    },
    {
      "t": 170902,
      "e": 131432,
      "ty": 2,
      "x": 898,
      "y": 348
    },
    {
      "t": 171002,
      "e": 131532,
      "ty": 2,
      "x": 915,
      "y": 356
    },
    {
      "t": 171002,
      "e": 131532,
      "ty": 41,
      "x": 22208,
      "y": 2340,
      "ta": "#jspsych-survey-multi-choice-1 > p"
    },
    {
      "t": 171102,
      "e": 131632,
      "ty": 2,
      "x": 916,
      "y": 360
    },
    {
      "t": 171202,
      "e": 131732,
      "ty": 2,
      "x": 921,
      "y": 378
    },
    {
      "t": 171253,
      "e": 131783,
      "ty": 41,
      "x": 23869,
      "y": 8665,
      "ta": "#jspsych-survey-multi-choice-1"
    },
    {
      "t": 171302,
      "e": 131832,
      "ty": 2,
      "x": 922,
      "y": 391
    },
    {
      "t": 171402,
      "e": 131932,
      "ty": 2,
      "x": 913,
      "y": 397
    },
    {
      "t": 171502,
      "e": 132032,
      "ty": 2,
      "x": 906,
      "y": 401
    },
    {
      "t": 171503,
      "e": 132033,
      "ty": 41,
      "x": 20072,
      "y": 0,
      "ta": "#jspsych-survey-multi-choice-option-1-0"
    },
    {
      "t": 171602,
      "e": 132132,
      "ty": 2,
      "x": 902,
      "y": 402
    },
    {
      "t": 171702,
      "e": 132232,
      "ty": 2,
      "x": 893,
      "y": 406
    },
    {
      "t": 171752,
      "e": 132282,
      "ty": 41,
      "x": 15800,
      "y": 14043,
      "ta": "#jspsych-survey-multi-choice-option-1-0"
    },
    {
      "t": 171802,
      "e": 132332,
      "ty": 2,
      "x": 885,
      "y": 408
    },
    {
      "t": 171902,
      "e": 132432,
      "ty": 2,
      "x": 874,
      "y": 411
    },
    {
      "t": 172003,
      "e": 132533,
      "ty": 2,
      "x": 872,
      "y": 411
    },
    {
      "t": 172003,
      "e": 132533,
      "ty": 41,
      "x": 59206,
      "y": 19660,
      "ta": "#jspsych-survey-multi-choice-option-1-0 > label"
    },
    {
      "t": 172102,
      "e": 132632,
      "ty": 2,
      "x": 871,
      "y": 412
    },
    {
      "t": 172202,
      "e": 132732,
      "ty": 2,
      "x": 867,
      "y": 415
    },
    {
      "t": 172253,
      "e": 132783,
      "ty": 41,
      "x": 53353,
      "y": 32767,
      "ta": "#jspsych-survey-multi-choice-option-1-0 > label"
    },
    {
      "t": 172702,
      "e": 133232,
      "ty": 2,
      "x": 866,
      "y": 416
    },
    {
      "t": 172752,
      "e": 133282,
      "ty": 41,
      "x": 52182,
      "y": 36044,
      "ta": "#jspsych-survey-multi-choice-option-1-0 > label"
    },
    {
      "t": 175002,
      "e": 135532,
      "ty": 2,
      "x": 871,
      "y": 413
    },
    {
      "t": 175003,
      "e": 135533,
      "ty": 41,
      "x": 58035,
      "y": 26214,
      "ta": "#jspsych-survey-multi-choice-option-1-0 > label"
    },
    {
      "t": 175103,
      "e": 135633,
      "ty": 2,
      "x": 873,
      "y": 413
    },
    {
      "t": 175203,
      "e": 135733,
      "ty": 2,
      "x": 874,
      "y": 412
    },
    {
      "t": 175252,
      "e": 135782,
      "ty": 41,
      "x": 61547,
      "y": 22937,
      "ta": "#jspsych-survey-multi-choice-option-1-0 > label"
    },
    {
      "t": 175302,
      "e": 135832,
      "ty": 2,
      "x": 875,
      "y": 411
    },
    {
      "t": 175428,
      "e": 135958,
      "ty": 3,
      "x": 875,
      "y": 411,
      "ta": "#jspsych-survey-multi-choice-option-1-0 > label"
    },
    {
      "t": 175429,
      "e": 135959,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-0[3]_mf"
    },
    {
      "t": 175502,
      "e": 136032,
      "ty": 41,
      "x": 62718,
      "y": 19660,
      "ta": "#jspsych-survey-multi-choice-option-1-0 > label"
    },
    {
      "t": 175515,
      "e": 136045,
      "ty": 4,
      "x": 62718,
      "y": 19660,
      "ta": "#jspsych-survey-multi-choice-option-1-0 > label"
    },
    {
      "t": 175515,
      "e": 136045,
      "ty": 5,
      "x": 875,
      "y": 411,
      "ta": "#jspsych-survey-multi-choice-option-1-0 > label"
    },
    {
      "t": 175515,
      "e": 136045,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-1[0]_mf"
    },
    {
      "t": 175516,
      "e": 136046,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-1[0]_mf",
      "v": "First"
    },
    {
      "t": 175753,
      "e": 136283,
      "ty": 41,
      "x": 60377,
      "y": 19660,
      "ta": "#jspsych-survey-multi-choice-option-1-0 > label"
    },
    {
      "t": 175802,
      "e": 136332,
      "ty": 2,
      "x": 823,
      "y": 419
    },
    {
      "t": 175902,
      "e": 136432,
      "ty": 2,
      "x": 735,
      "y": 444
    },
    {
      "t": 176003,
      "e": 136533,
      "ty": 2,
      "x": 715,
      "y": 454
    },
    {
      "t": 176003,
      "e": 136533,
      "ty": 41,
      "x": 24347,
      "y": 24707,
      "ta": "html > body"
    },
    {
      "t": 176102,
      "e": 136632,
      "ty": 2,
      "x": 718,
      "y": 462
    },
    {
      "t": 176140,
      "e": 136670,
      "ty": 3,
      "x": 718,
      "y": 462,
      "ta": "html > body"
    },
    {
      "t": 176141,
      "e": 136671,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-1[0]_mf"
    },
    {
      "t": 176203,
      "e": 136733,
      "ty": 2,
      "x": 725,
      "y": 465
    },
    {
      "t": 176243,
      "e": 136773,
      "ty": 4,
      "x": 24691,
      "y": 25316,
      "ta": "html > body"
    },
    {
      "t": 176253,
      "e": 136774,
      "ty": 41,
      "x": 24691,
      "y": 25316,
      "ta": "html > body"
    },
    {
      "t": 176470,
      "e": 136991,
      "ty": 3,
      "x": 616,
      "y": 454,
      "ta": "html > body"
    },
    {
      "t": 176502,
      "e": 137023,
      "ty": 2,
      "x": 616,
      "y": 454
    },
    {
      "t": 176503,
      "e": 137024,
      "ty": 41,
      "x": 20938,
      "y": 24707,
      "ta": "html > body"
    },
    {
      "t": 176523,
      "e": 137044,
      "ty": 4,
      "x": 20938,
      "y": 24707,
      "ta": "html > body"
    },
    {
      "t": 176524,
      "e": 137045,
      "ty": 5,
      "x": 616,
      "y": 454,
      "ta": "html > body"
    },
    {
      "t": 177903,
      "e": 138424,
      "ty": 2,
      "x": 625,
      "y": 482
    },
    {
      "t": 178003,
      "e": 138524,
      "ty": 2,
      "x": 686,
      "y": 529
    },
    {
      "t": 178003,
      "e": 138524,
      "ty": 41,
      "x": 23348,
      "y": 28861,
      "ta": "html > body"
    },
    {
      "t": 178103,
      "e": 138624,
      "ty": 2,
      "x": 775,
      "y": 575
    },
    {
      "t": 178203,
      "e": 138724,
      "ty": 2,
      "x": 835,
      "y": 632
    },
    {
      "t": 178252,
      "e": 138773,
      "ty": 41,
      "x": 16802,
      "y": 39321,
      "ta": "#jspsych-survey-multi-choice-option-2-0 > label"
    },
    {
      "t": 178302,
      "e": 138823,
      "ty": 2,
      "x": 903,
      "y": 689
    },
    {
      "t": 178403,
      "e": 138924,
      "ty": 2,
      "x": 913,
      "y": 691
    },
    {
      "t": 178502,
      "e": 139023,
      "ty": 2,
      "x": 930,
      "y": 684
    },
    {
      "t": 178503,
      "e": 139024,
      "ty": 41,
      "x": 29153,
      "y": 62258,
      "ta": "#jspsych-survey-multi-choice-option-2-0 > label"
    },
    {
      "t": 178602,
      "e": 139123,
      "ty": 2,
      "x": 936,
      "y": 683
    },
    {
      "t": 178753,
      "e": 139274,
      "ty": 41,
      "x": 30764,
      "y": 58981,
      "ta": "#jspsych-survey-multi-choice-option-2-0 > label"
    },
    {
      "t": 179102,
      "e": 139623,
      "ty": 2,
      "x": 936,
      "y": 687
    },
    {
      "t": 179202,
      "e": 139723,
      "ty": 2,
      "x": 932,
      "y": 694
    },
    {
      "t": 179252,
      "e": 139773,
      "ty": 41,
      "x": 27107,
      "y": 22937,
      "ta": "#jspsych-survey-multi-choice-option-2-1 > label"
    },
    {
      "t": 179302,
      "e": 139823,
      "ty": 2,
      "x": 929,
      "y": 704
    },
    {
      "t": 179503,
      "e": 140024,
      "ty": 41,
      "x": 27107,
      "y": 36044,
      "ta": "#jspsych-survey-multi-choice-option-2-1 > label"
    },
    {
      "t": 180468,
      "e": 140989,
      "ty": 3,
      "x": 929,
      "y": 704,
      "ta": "#jspsych-survey-multi-choice-option-2-1 > label"
    },
    {
      "t": 180563,
      "e": 141084,
      "ty": 4,
      "x": 27107,
      "y": 36044,
      "ta": "#jspsych-survey-multi-choice-option-2-1 > label"
    },
    {
      "t": 180563,
      "e": 141084,
      "ty": 5,
      "x": 929,
      "y": 704,
      "ta": "#jspsych-survey-multi-choice-option-2-1 > label"
    },
    {
      "t": 180563,
      "e": 141084,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-2[1]_mf"
    },
    {
      "t": 180564,
      "e": 141085,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-2[1]_mf",
      "v": "Social Sciences (incl. CogSci)"
    },
    {
      "t": 180703,
      "e": 141224,
      "ty": 2,
      "x": 893,
      "y": 701
    },
    {
      "t": 180753,
      "e": 141274,
      "ty": 41,
      "x": 6949,
      "y": 26214,
      "ta": "#jspsych-survey-multi-choice-option-2-1 > label"
    },
    {
      "t": 180761,
      "e": 141282,
      "ty": 6,
      "x": 838,
      "y": 701,
      "ta": "jspsych-survey-multi-choice-response-2[1]_mf"
    },
    {
      "t": 180795,
      "e": 141316,
      "ty": 7,
      "x": 798,
      "y": 695,
      "ta": "jspsych-survey-multi-choice-response-2[1]_mf"
    },
    {
      "t": 180802,
      "e": 141323,
      "ty": 2,
      "x": 798,
      "y": 695
    },
    {
      "t": 180902,
      "e": 141423,
      "ty": 2,
      "x": 718,
      "y": 685
    },
    {
      "t": 181002,
      "e": 141523,
      "ty": 2,
      "x": 699,
      "y": 679
    },
    {
      "t": 181003,
      "e": 141524,
      "ty": 41,
      "x": 23796,
      "y": 37171,
      "ta": "html > body"
    },
    {
      "t": 181084,
      "e": 141605,
      "ty": 3,
      "x": 699,
      "y": 679,
      "ta": "html > body"
    },
    {
      "t": 181085,
      "e": 141606,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-2[1]_mf"
    },
    {
      "t": 181130,
      "e": 141651,
      "ty": 4,
      "x": 23796,
      "y": 37171,
      "ta": "html > body"
    },
    {
      "t": 181397,
      "e": 141918,
      "ty": 3,
      "x": 614,
      "y": 645,
      "ta": "html > body"
    },
    {
      "t": 181402,
      "e": 141923,
      "ty": 2,
      "x": 614,
      "y": 645
    },
    {
      "t": 181503,
      "e": 142024,
      "ty": 41,
      "x": 20869,
      "y": 35288,
      "ta": "html > body"
    },
    {
      "t": 181507,
      "e": 142028,
      "ty": 4,
      "x": 20869,
      "y": 35288,
      "ta": "html > body"
    },
    {
      "t": 181508,
      "e": 142029,
      "ty": 5,
      "x": 614,
      "y": 645,
      "ta": "html > body"
    },
    {
      "t": 181752,
      "e": 142273,
      "ty": 41,
      "x": 20834,
      "y": 35288,
      "ta": "html > body"
    },
    {
      "t": 181803,
      "e": 142324,
      "ty": 2,
      "x": 603,
      "y": 645
    },
    {
      "t": 182002,
      "e": 142523,
      "ty": 2,
      "x": 603,
      "y": 644
    },
    {
      "t": 182003,
      "e": 142524,
      "ty": 41,
      "x": 20490,
      "y": 35232,
      "ta": "html > body"
    },
    {
      "t": 183051,
      "e": 143572,
      "ty": 3,
      "x": 603,
      "y": 644,
      "ta": "html > body"
    },
    {
      "t": 183139,
      "e": 143660,
      "ty": 4,
      "x": 20456,
      "y": 35177,
      "ta": "html > body"
    },
    {
      "t": 183203,
      "e": 143724,
      "ty": 2,
      "x": 602,
      "y": 643
    },
    {
      "t": 183252,
      "e": 143773,
      "ty": 41,
      "x": 20456,
      "y": 35177,
      "ta": "html > body"
    },
    {
      "t": 183389,
      "e": 143910,
      "ty": 3,
      "x": 555,
      "y": 613,
      "ta": "html > body"
    },
    {
      "t": 183401,
      "e": 143922,
      "ty": 2,
      "x": 555,
      "y": 613
    },
    {
      "t": 183460,
      "e": 143981,
      "ty": 4,
      "x": 18837,
      "y": 33515,
      "ta": "html > body"
    },
    {
      "t": 183460,
      "e": 143981,
      "ty": 5,
      "x": 555,
      "y": 613,
      "ta": "html > body"
    },
    {
      "t": 183503,
      "e": 144024,
      "ty": 41,
      "x": 18837,
      "y": 33515,
      "ta": "html > body"
    },
    {
      "t": 183752,
      "e": 144273,
      "ty": 41,
      "x": 18734,
      "y": 33515,
      "ta": "html > body"
    },
    {
      "t": 183802,
      "e": 144323,
      "ty": 2,
      "x": 551,
      "y": 613
    },
    {
      "t": 184002,
      "e": 144523,
      "ty": 41,
      "x": 18699,
      "y": 33515,
      "ta": "html > body"
    },
    {
      "t": 187302,
      "e": 147823,
      "ty": 2,
      "x": 583,
      "y": 621
    },
    {
      "t": 187401,
      "e": 147922,
      "ty": 2,
      "x": 665,
      "y": 653
    },
    {
      "t": 187502,
      "e": 148023,
      "ty": 2,
      "x": 735,
      "y": 665
    },
    {
      "t": 187502,
      "e": 148023,
      "ty": 41,
      "x": 25036,
      "y": 36396,
      "ta": "html > body"
    },
    {
      "t": 187602,
      "e": 148123,
      "ty": 2,
      "x": 792,
      "y": 661
    },
    {
      "t": 187702,
      "e": 148223,
      "ty": 2,
      "x": 830,
      "y": 663
    },
    {
      "t": 187751,
      "e": 148272,
      "ty": 41,
      "x": 8210,
      "y": 9830,
      "ta": "#jspsych-survey-multi-choice-option-2-0 > label"
    },
    {
      "t": 187801,
      "e": 148322,
      "ty": 2,
      "x": 852,
      "y": 668
    },
    {
      "t": 188001,
      "e": 148522,
      "ty": 2,
      "x": 847,
      "y": 672
    },
    {
      "t": 188002,
      "e": 148523,
      "ty": 41,
      "x": 6867,
      "y": 22937,
      "ta": "#jspsych-survey-multi-choice-option-2-0 > label"
    },
    {
      "t": 188068,
      "e": 148589,
      "ty": 6,
      "x": 837,
      "y": 676,
      "ta": "jspsych-survey-multi-choice-response-2[0]_mf"
    },
    {
      "t": 188102,
      "e": 148623,
      "ty": 2,
      "x": 826,
      "y": 679
    },
    {
      "t": 188118,
      "e": 148639,
      "ty": 7,
      "x": 822,
      "y": 679,
      "ta": "jspsych-survey-multi-choice-response-2[0]_mf"
    },
    {
      "t": 188202,
      "e": 148723,
      "ty": 2,
      "x": 780,
      "y": 696
    },
    {
      "t": 188251,
      "e": 148772,
      "ty": 41,
      "x": 26379,
      "y": 38334,
      "ta": "html > body"
    },
    {
      "t": 188302,
      "e": 148823,
      "ty": 2,
      "x": 768,
      "y": 704
    },
    {
      "t": 188402,
      "e": 148923,
      "ty": 2,
      "x": 754,
      "y": 718
    },
    {
      "t": 188502,
      "e": 149023,
      "ty": 2,
      "x": 744,
      "y": 724
    },
    {
      "t": 188502,
      "e": 149023,
      "ty": 41,
      "x": 25346,
      "y": 39664,
      "ta": "html > body"
    },
    {
      "t": 188602,
      "e": 149123,
      "ty": 2,
      "x": 738,
      "y": 728
    },
    {
      "t": 188702,
      "e": 149223,
      "ty": 2,
      "x": 731,
      "y": 731
    },
    {
      "t": 188752,
      "e": 149273,
      "ty": 41,
      "x": 24795,
      "y": 40273,
      "ta": "html > body"
    },
    {
      "t": 188802,
      "e": 149323,
      "ty": 2,
      "x": 728,
      "y": 752
    },
    {
      "t": 188901,
      "e": 149422,
      "ty": 2,
      "x": 728,
      "y": 757
    },
    {
      "t": 189002,
      "e": 149523,
      "ty": 2,
      "x": 733,
      "y": 766
    },
    {
      "t": 189002,
      "e": 149523,
      "ty": 41,
      "x": 24967,
      "y": 41991,
      "ta": "html > body"
    },
    {
      "t": 189202,
      "e": 149723,
      "ty": 2,
      "x": 730,
      "y": 760
    },
    {
      "t": 189252,
      "e": 149773,
      "ty": 41,
      "x": 24864,
      "y": 41658,
      "ta": "html > body"
    },
    {
      "t": 189412,
      "e": 149933,
      "ty": 3,
      "x": 730,
      "y": 760,
      "ta": "html > body"
    },
    {
      "t": 189483,
      "e": 150004,
      "ty": 4,
      "x": 24864,
      "y": 41658,
      "ta": "html > body"
    },
    {
      "t": 189747,
      "e": 150268,
      "ty": 3,
      "x": 691,
      "y": 737,
      "ta": "html > body"
    },
    {
      "t": 189751,
      "e": 150272,
      "ty": 41,
      "x": 23520,
      "y": 40384,
      "ta": "html > body"
    },
    {
      "t": 189802,
      "e": 150323,
      "ty": 2,
      "x": 691,
      "y": 737
    },
    {
      "t": 189834,
      "e": 150355,
      "ty": 4,
      "x": 23520,
      "y": 40384,
      "ta": "html > body"
    },
    {
      "t": 189834,
      "e": 150355,
      "ty": 5,
      "x": 691,
      "y": 737,
      "ta": "html > body"
    },
    {
      "t": 190002,
      "e": 150523,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 190502,
      "e": 151023,
      "ty": 2,
      "x": 691,
      "y": 738
    },
    {
      "t": 190502,
      "e": 151023,
      "ty": 41,
      "x": 23520,
      "y": 40440,
      "ta": "html > body"
    },
    {
      "t": 190602,
      "e": 151123,
      "ty": 2,
      "x": 692,
      "y": 740
    },
    {
      "t": 190701,
      "e": 151222,
      "ty": 2,
      "x": 725,
      "y": 782
    },
    {
      "t": 190752,
      "e": 151273,
      "ty": 41,
      "x": 24829,
      "y": 43930,
      "ta": "html > body"
    },
    {
      "t": 190802,
      "e": 151323,
      "ty": 2,
      "x": 753,
      "y": 842
    },
    {
      "t": 190902,
      "e": 151423,
      "ty": 2,
      "x": 813,
      "y": 923
    },
    {
      "t": 191002,
      "e": 151523,
      "ty": 2,
      "x": 857,
      "y": 958
    },
    {
      "t": 191002,
      "e": 151523,
      "ty": 41,
      "x": 28779,
      "y": 16383,
      "ta": "#jspsych-survey-multi-choice-option-3-1 > label"
    },
    {
      "t": 191102,
      "e": 151623,
      "ty": 2,
      "x": 858,
      "y": 947
    },
    {
      "t": 191202,
      "e": 151723,
      "ty": 2,
      "x": 856,
      "y": 939
    },
    {
      "t": 191252,
      "e": 151773,
      "ty": 41,
      "x": 37767,
      "y": 45874,
      "ta": "#jspsych-survey-multi-choice-option-3-0 > label"
    },
    {
      "t": 191283,
      "e": 151804,
      "ty": 3,
      "x": 856,
      "y": 939,
      "ta": "#jspsych-survey-multi-choice-option-3-0 > label"
    },
    {
      "t": 191363,
      "e": 151884,
      "ty": 4,
      "x": 37767,
      "y": 45874,
      "ta": "#jspsych-survey-multi-choice-option-3-0 > label"
    },
    {
      "t": 191364,
      "e": 151885,
      "ty": 5,
      "x": 856,
      "y": 939,
      "ta": "#jspsych-survey-multi-choice-option-3-0 > label"
    },
    {
      "t": 191364,
      "e": 151885,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-3[0]_mf"
    },
    {
      "t": 191366,
      "e": 151887,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-3[0]_mf",
      "v": "Male"
    },
    {
      "t": 191501,
      "e": 152022,
      "ty": 2,
      "x": 867,
      "y": 946
    },
    {
      "t": 191501,
      "e": 152022,
      "ty": 41,
      "x": 10816,
      "y": 58513,
      "ta": "#jspsych-survey-multi-choice-option-3-0"
    },
    {
      "t": 191601,
      "e": 152122,
      "ty": 2,
      "x": 882,
      "y": 966
    },
    {
      "t": 191702,
      "e": 152223,
      "ty": 2,
      "x": 892,
      "y": 986
    },
    {
      "t": 191752,
      "e": 152273,
      "ty": 41,
      "x": 16749,
      "y": 30426,
      "ta": "#jspsych-survey-multi-choice-option-3-2"
    },
    {
      "t": 191802,
      "e": 152323,
      "ty": 2,
      "x": 893,
      "y": 1001
    },
    {
      "t": 191821,
      "e": 152342,
      "ty": 6,
      "x": 895,
      "y": 1009,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 191902,
      "e": 152423,
      "ty": 2,
      "x": 896,
      "y": 1020
    },
    {
      "t": 191970,
      "e": 152491,
      "ty": 3,
      "x": 898,
      "y": 1027,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 191971,
      "e": 152492,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-3[0]_mf"
    },
    {
      "t": 191972,
      "e": 152493,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 192001,
      "e": 152522,
      "ty": 2,
      "x": 898,
      "y": 1027
    },
    {
      "t": 192002,
      "e": 152523,
      "ty": 41,
      "x": 35344,
      "y": 43690,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 192060,
      "e": 152581,
      "ty": 4,
      "x": 35344,
      "y": 43690,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 192060,
      "e": 152581,
      "ty": 5,
      "x": 898,
      "y": 1027,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 192067,
      "e": 152588,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 192069,
      "e": 152590,
      "ty": 13,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-multi-choice-form"
    },
    {
      "t": 192072,
      "e": 152593,
      "ty": 38,
      "x": 5,
      "y": 0
    },
    {
      "t": 192201,
      "e": 152722,
      "ty": 2,
      "x": 890,
      "y": 1021
    },
    {
      "t": 192252,
      "e": 152773,
      "ty": 41,
      "x": 29444,
      "y": 55064,
      "ta": "html > body"
    },
    {
      "t": 192302,
      "e": 152823,
      "ty": 2,
      "x": 843,
      "y": 983
    },
    {
      "t": 192402,
      "e": 152923,
      "ty": 2,
      "x": 821,
      "y": 959
    },
    {
      "t": 192502,
      "e": 153023,
      "ty": 2,
      "x": 806,
      "y": 935
    },
    {
      "t": 192502,
      "e": 153023,
      "ty": 41,
      "x": 27481,
      "y": 51353,
      "ta": "html > body"
    },
    {
      "t": 192602,
      "e": 153123,
      "ty": 2,
      "x": 793,
      "y": 924
    },
    {
      "t": 192752,
      "e": 153273,
      "ty": 41,
      "x": 27033,
      "y": 50743,
      "ta": "html > body"
    },
    {
      "t": 193102,
      "e": 153623,
      "ty": 2,
      "x": 779,
      "y": 918
    },
    {
      "t": 193202,
      "e": 153723,
      "ty": 2,
      "x": 776,
      "y": 918
    },
    {
      "t": 193251,
      "e": 153772,
      "ty": 41,
      "x": 26448,
      "y": 50411,
      "ta": "html > body"
    },
    {
      "t": 193407,
      "e": 153928,
      "ty": 38,
      "x": 6,
      "y": 0
    },
    {
      "t": 194402,
      "e": 154923,
      "ty": 2,
      "x": 791,
      "y": 923
    },
    {
      "t": 194482,
      "e": 155003,
      "ty": 3,
      "x": 791,
      "y": 925,
      "ta": "> div.masterdiv > div:[2]"
    },
    {
      "t": 194502,
      "e": 155023,
      "ty": 2,
      "x": 791,
      "y": 925
    },
    {
      "t": 194502,
      "e": 155023,
      "ty": 41,
      "x": 24477,
      "y": 55308,
      "ta": "> div.masterdiv > div:[2]"
    },
    {
      "t": 194562,
      "e": 155083,
      "ty": 4,
      "x": 24477,
      "y": 55308,
      "ta": "> div.masterdiv > div:[2]"
    },
    {
      "t": 194885,
      "e": 155406,
      "ty": 3,
      "x": 753,
      "y": 926,
      "ta": "> div.masterdiv > div:[2]"
    },
    {
      "t": 194902,
      "e": 155423,
      "ty": 2,
      "x": 753,
      "y": 926
    },
    {
      "t": 194978,
      "e": 155499,
      "ty": 4,
      "x": 22608,
      "y": 55377,
      "ta": "> div.masterdiv > div:[2]"
    },
    {
      "t": 194978,
      "e": 155499,
      "ty": 5,
      "x": 753,
      "y": 926,
      "ta": "> div.masterdiv > div:[2]"
    },
    {
      "t": 195002,
      "e": 155523,
      "ty": 41,
      "x": 22608,
      "y": 55377,
      "ta": "> div.masterdiv > div:[2]"
    },
    {
      "t": 195902,
      "e": 156423,
      "ty": 2,
      "x": 750,
      "y": 926
    },
    {
      "t": 196002,
      "e": 156523,
      "ty": 41,
      "x": 22460,
      "y": 55377,
      "ta": "> div.masterdiv > div:[2]"
    },
    {
      "t": 196701,
      "e": 157222,
      "ty": 2,
      "x": 747,
      "y": 927
    },
    {
      "t": 196752,
      "e": 157273,
      "ty": 41,
      "x": 21968,
      "y": 55515,
      "ta": "> div.masterdiv > div:[2]"
    },
    {
      "t": 196802,
      "e": 157323,
      "ty": 2,
      "x": 740,
      "y": 928
    },
    {
      "t": 198252,
      "e": 158773,
      "ty": 41,
      "x": 21919,
      "y": 55515,
      "ta": "> div.masterdiv > div:[2]"
    },
    {
      "t": 198302,
      "e": 158823,
      "ty": 2,
      "x": 739,
      "y": 928
    },
    {
      "t": 200002,
      "e": 160523,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 206302,
      "e": 163823,
      "ty": 2,
      "x": 746,
      "y": 929
    },
    {
      "t": 206402,
      "e": 163923,
      "ty": 2,
      "x": 797,
      "y": 964
    },
    {
      "t": 206503,
      "e": 164024,
      "ty": 2,
      "x": 800,
      "y": 964
    },
    {
      "t": 206503,
      "e": 164024,
      "ty": 41,
      "x": 24920,
      "y": 58008,
      "ta": "> div.masterdiv > div:[2]"
    },
    {
      "t": 206602,
      "e": 164123,
      "ty": 2,
      "x": 801,
      "y": 964
    },
    {
      "t": 206752,
      "e": 164273,
      "ty": 41,
      "x": 24969,
      "y": 58008,
      "ta": "> div.masterdiv > div:[2]"
    },
    {
      "t": 207102,
      "e": 164623,
      "ty": 2,
      "x": 802,
      "y": 963
    },
    {
      "t": 207197,
      "e": 164718,
      "ty": 3,
      "x": 805,
      "y": 953,
      "ta": "> div.masterdiv > div:[2]"
    },
    {
      "t": 207202,
      "e": 164723,
      "ty": 2,
      "x": 805,
      "y": 953
    },
    {
      "t": 207253,
      "e": 164774,
      "ty": 41,
      "x": 25166,
      "y": 57177,
      "ta": "> div.masterdiv > div:[2]"
    },
    {
      "t": 207267,
      "e": 164788,
      "ty": 4,
      "x": 25166,
      "y": 57177,
      "ta": "> div.masterdiv > div:[2]"
    },
    {
      "t": 207302,
      "e": 164823,
      "ty": 2,
      "x": 805,
      "y": 952
    },
    {
      "t": 207549,
      "e": 165070,
      "ty": 3,
      "x": 725,
      "y": 922,
      "ta": "> div.masterdiv > div:[2]"
    },
    {
      "t": 207602,
      "e": 165123,
      "ty": 2,
      "x": 723,
      "y": 922
    },
    {
      "t": 207642,
      "e": 165163,
      "ty": 4,
      "x": 21132,
      "y": 55100,
      "ta": "> div.masterdiv > div:[2]"
    },
    {
      "t": 207642,
      "e": 165163,
      "ty": 5,
      "x": 723,
      "y": 922,
      "ta": "> div.masterdiv > div:[2]"
    },
    {
      "t": 207752,
      "e": 165273,
      "ty": 41,
      "x": 21132,
      "y": 55100,
      "ta": "> div.masterdiv > div:[2]"
    },
    {
      "t": 208003,
      "e": 165524,
      "ty": 2,
      "x": 720,
      "y": 922
    },
    {
      "t": 208003,
      "e": 165524,
      "ty": 41,
      "x": 20984,
      "y": 55100,
      "ta": "> div.masterdiv > div:[2]"
    },
    {
      "t": 208402,
      "e": 165923,
      "ty": 2,
      "x": 719,
      "y": 922
    },
    {
      "t": 208502,
      "e": 166023,
      "ty": 41,
      "x": 20935,
      "y": 55100,
      "ta": "> div.masterdiv > div:[2]"
    },
    {
      "t": 209702,
      "e": 167223,
      "ty": 2,
      "x": 759,
      "y": 924
    },
    {
      "t": 209753,
      "e": 167274,
      "ty": 41,
      "x": 24969,
      "y": 55169,
      "ta": "> div.masterdiv > div:[2]"
    },
    {
      "t": 209802,
      "e": 167323,
      "ty": 2,
      "x": 852,
      "y": 918
    },
    {
      "t": 209903,
      "e": 167424,
      "ty": 2,
      "x": 954,
      "y": 936
    },
    {
      "t": 209979,
      "e": 167500,
      "ty": 3,
      "x": 972,
      "y": 940,
      "ta": "> div.masterdiv > div:[2]"
    },
    {
      "t": 210002,
      "e": 167523,
      "ty": 2,
      "x": 972,
      "y": 940
    },
    {
      "t": 210002,
      "e": 167523,
      "ty": 41,
      "x": 33382,
      "y": 56346,
      "ta": "> div.masterdiv > div:[2]"
    },
    {
      "t": 210059,
      "e": 167580,
      "ty": 4,
      "x": 33382,
      "y": 56415,
      "ta": "> div.masterdiv > div:[2]"
    },
    {
      "t": 210102,
      "e": 167623,
      "ty": 2,
      "x": 972,
      "y": 941
    },
    {
      "t": 210253,
      "e": 167774,
      "ty": 41,
      "x": 33382,
      "y": 56415,
      "ta": "> div.masterdiv > div:[2]"
    },
    {
      "t": 210493,
      "e": 168014,
      "ty": 3,
      "x": 892,
      "y": 930,
      "ta": "> div.masterdiv > div:[2]"
    },
    {
      "t": 210502,
      "e": 168023,
      "ty": 2,
      "x": 892,
      "y": 930
    },
    {
      "t": 210503,
      "e": 168024,
      "ty": 41,
      "x": 29446,
      "y": 55654,
      "ta": "> div.masterdiv > div:[2]"
    },
    {
      "t": 210586,
      "e": 168107,
      "ty": 4,
      "x": 29446,
      "y": 55654,
      "ta": "> div.masterdiv > div:[2]"
    },
    {
      "t": 210586,
      "e": 168107,
      "ty": 5,
      "x": 892,
      "y": 930,
      "ta": "> div.masterdiv > div:[2]"
    },
    {
      "t": 217902,
      "e": 173107,
      "ty": 2,
      "x": 881,
      "y": 922
    },
    {
      "t": 218002,
      "e": 173207,
      "ty": 2,
      "x": 879,
      "y": 918
    },
    {
      "t": 218002,
      "e": 173207,
      "ty": 41,
      "x": 28807,
      "y": 54823,
      "ta": "> div.masterdiv > div:[2]"
    },
    {
      "t": 218101,
      "e": 173306,
      "ty": 2,
      "x": 877,
      "y": 906
    },
    {
      "t": 218201,
      "e": 173406,
      "ty": 2,
      "x": 874,
      "y": 891
    },
    {
      "t": 218252,
      "e": 173457,
      "ty": 41,
      "x": 28511,
      "y": 40995,
      "ta": "> div.masterdiv > div:[2] > div > p:[6]"
    },
    {
      "t": 218302,
      "e": 173507,
      "ty": 2,
      "x": 873,
      "y": 886
    },
    {
      "t": 218402,
      "e": 173607,
      "ty": 2,
      "x": 880,
      "y": 875
    },
    {
      "t": 218501,
      "e": 173706,
      "ty": 2,
      "x": 896,
      "y": 854
    },
    {
      "t": 218502,
      "e": 173707,
      "ty": 41,
      "x": 29643,
      "y": 64968,
      "ta": "> div.masterdiv > div:[2] > div > p:[5]"
    },
    {
      "t": 218602,
      "e": 173807,
      "ty": 2,
      "x": 912,
      "y": 839
    },
    {
      "t": 218701,
      "e": 173906,
      "ty": 2,
      "x": 938,
      "y": 823
    },
    {
      "t": 218752,
      "e": 173957,
      "ty": 41,
      "x": 32300,
      "y": 25179,
      "ta": "> div.masterdiv > div:[2] > div > p:[5]"
    },
    {
      "t": 218801,
      "e": 174006,
      "ty": 2,
      "x": 962,
      "y": 818
    },
    {
      "t": 218902,
      "e": 174107,
      "ty": 2,
      "x": 983,
      "y": 822
    },
    {
      "t": 219001,
      "e": 174206,
      "ty": 2,
      "x": 989,
      "y": 835
    },
    {
      "t": 219002,
      "e": 174207,
      "ty": 41,
      "x": 34218,
      "y": 42733,
      "ta": "> div.masterdiv > div:[2] > div > p:[5]"
    },
    {
      "t": 219102,
      "e": 174307,
      "ty": 2,
      "x": 983,
      "y": 843
    },
    {
      "t": 219201,
      "e": 174406,
      "ty": 2,
      "x": 965,
      "y": 851
    },
    {
      "t": 219252,
      "e": 174457,
      "ty": 41,
      "x": 32546,
      "y": 64968,
      "ta": "> div.masterdiv > div:[2] > div > p:[5]"
    },
    {
      "t": 219302,
      "e": 174507,
      "ty": 2,
      "x": 942,
      "y": 861
    },
    {
      "t": 219401,
      "e": 174606,
      "ty": 2,
      "x": 926,
      "y": 866
    },
    {
      "t": 219502,
      "e": 174707,
      "ty": 2,
      "x": 918,
      "y": 871
    },
    {
      "t": 219502,
      "e": 174707,
      "ty": 41,
      "x": 30725,
      "y": 62121,
      "ta": "> div.masterdiv > div:[2] > div"
    },
    {
      "t": 219602,
      "e": 174807,
      "ty": 2,
      "x": 915,
      "y": 874
    },
    {
      "t": 219702,
      "e": 174907,
      "ty": 2,
      "x": 907,
      "y": 876
    },
    {
      "t": 219752,
      "e": 174957,
      "ty": 41,
      "x": 30037,
      "y": 10568,
      "ta": "> div.masterdiv > div:[2] > div > p:[6]"
    },
    {
      "t": 219801,
      "e": 175006,
      "ty": 2,
      "x": 898,
      "y": 879
    },
    {
      "t": 219902,
      "e": 175107,
      "ty": 2,
      "x": 895,
      "y": 880
    },
    {
      "t": 220001,
      "e": 175206,
      "ty": 2,
      "x": 892,
      "y": 882
    },
    {
      "t": 220001,
      "e": 175206,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 220004,
      "e": 175209,
      "ty": 41,
      "x": 29446,
      "y": 22271,
      "ta": "> div.masterdiv > div:[2] > div > p:[6]"
    },
    {
      "t": 220101,
      "e": 175306,
      "ty": 2,
      "x": 889,
      "y": 882
    },
    {
      "t": 220252,
      "e": 175457,
      "ty": 41,
      "x": 29299,
      "y": 22271,
      "ta": "> div.masterdiv > div:[2] > div > p:[6]"
    },
    {
      "t": 220401,
      "e": 175606,
      "ty": 2,
      "x": 887,
      "y": 889
    },
    {
      "t": 220502,
      "e": 175707,
      "ty": 2,
      "x": 883,
      "y": 943
    },
    {
      "t": 220502,
      "e": 175707,
      "ty": 41,
      "x": 29003,
      "y": 56554,
      "ta": "> div.masterdiv > div:[2]"
    },
    {
      "t": 220601,
      "e": 175806,
      "ty": 2,
      "x": 912,
      "y": 1007
    },
    {
      "t": 220702,
      "e": 175907,
      "ty": 2,
      "x": 949,
      "y": 1069
    },
    {
      "t": 220703,
      "e": 175908,
      "ty": 6,
      "x": 956,
      "y": 1079,
      "ta": "#start"
    },
    {
      "t": 220752,
      "e": 175957,
      "ty": 41,
      "x": 28671,
      "y": 27587,
      "ta": "#start"
    },
    {
      "t": 220802,
      "e": 176007,
      "ty": 2,
      "x": 967,
      "y": 1093
    },
    {
      "t": 220901,
      "e": 176106,
      "ty": 2,
      "x": 974,
      "y": 1100
    },
    {
      "t": 220926,
      "e": 176131,
      "ty": 7,
      "x": 980,
      "y": 1108,
      "ta": "#start"
    },
    {
      "t": 221001,
      "e": 176206,
      "ty": 2,
      "x": 981,
      "y": 1112
    },
    {
      "t": 221003,
      "e": 176208,
      "ty": 41,
      "x": 42831,
      "y": 21778,
      "ta": "> div.masterdiv > div:[3]"
    },
    {
      "t": 221102,
      "e": 176307,
      "ty": 2,
      "x": 984,
      "y": 1114
    },
    {
      "t": 221202,
      "e": 176407,
      "ty": 2,
      "x": 985,
      "y": 1115
    },
    {
      "t": 221257,
      "e": 176462,
      "ty": 41,
      "x": 44704,
      "y": 19562,
      "ta": "> div.masterdiv > div:[3]"
    },
    {
      "t": 221265,
      "e": 176470,
      "ty": 6,
      "x": 984,
      "y": 1104,
      "ta": "#start"
    },
    {
      "t": 221305,
      "e": 176510,
      "ty": 2,
      "x": 981,
      "y": 1101
    },
    {
      "t": 221406,
      "e": 176611,
      "ty": 2,
      "x": 976,
      "y": 1099
    },
    {
      "t": 221506,
      "e": 176711,
      "ty": 41,
      "x": 36317,
      "y": 50717,
      "ta": "#start"
    },
    {
      "t": 221905,
      "e": 177110,
      "ty": 2,
      "x": 973,
      "y": 1095
    },
    {
      "t": 221968,
      "e": 177173,
      "ty": 3,
      "x": 973,
      "y": 1095,
      "ta": "#start"
    },
    {
      "t": 221969,
      "e": 177174,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#start"
    },
    {
      "t": 222006,
      "e": 177211,
      "ty": 41,
      "x": 34678,
      "y": 43007,
      "ta": "#start"
    },
    {
      "t": 222047,
      "e": 177252,
      "ty": 4,
      "x": 34678,
      "y": 43007,
      "ta": "#start"
    },
    {
      "t": 222048,
      "e": 177253,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#start"
    },
    {
      "t": 222050,
      "e": 177255,
      "ty": 5,
      "x": 973,
      "y": 1095,
      "ta": "#start"
    },
    {
      "t": 222051,
      "e": 177256,
      "ty": 38,
      "x": 7,
      "y": 0
    },
    {
      "t": 222405,
      "e": 177610,
      "ty": 2,
      "x": 971,
      "y": 1091
    },
    {
      "t": 222506,
      "e": 177711,
      "ty": 2,
      "x": 967,
      "y": 1083
    },
    {
      "t": 222506,
      "e": 177711,
      "ty": 41,
      "x": 33025,
      "y": 59552,
      "ta": "html > body"
    },
    {
      "t": 222606,
      "e": 177811,
      "ty": 2,
      "x": 960,
      "y": 1076
    },
    {
      "t": 222705,
      "e": 177910,
      "ty": 2,
      "x": 955,
      "y": 1071
    },
    {
      "t": 222756,
      "e": 177961,
      "ty": 41,
      "x": 32612,
      "y": 58887,
      "ta": "html > body"
    },
    {
      "t": 223092,
      "e": 178297,
      "ty": 38,
      "x": 8,
      "y": 0
    },
    {
      "t": 224717,
      "e": 179922,
      "ty": 20,
      "x": 0,
      "y": 0
    }
  ],
  "domMutations": [
    {
      "sequence": 1,
      "data": "{\"f\":\"applyChanged\",\"args\":[[{\"id\":56},{\"id\":57},{\"id\":58},{\"id\":59},{\"id\":60},{\"id\":61},{\"id\":62},{\"id\":63},{\"id\":64},{\"id\":65},{\"id\":66},{\"id\":67},{\"id\":68},{\"id\":69},{\"id\":70},{\"id\":71},{\"id\":72},{\"id\":73},{\"id\":74},{\"id\":75},{\"id\":76},{\"id\":77},{\"id\":78},{\"id\":79},{\"id\":80},{\"id\":81},{\"id\":82},{\"id\":83},{\"id\":84},{\"id\":85},{\"id\":86},{\"id\":87},{\"id\":88},{\"id\":89},{\"id\":90},{\"id\":91},{\"id\":92},{\"id\":93},{\"id\":94},{\"id\":95},{\"id\":96},{\"id\":97},{\"id\":98},{\"id\":99},{\"id\":100},{\"id\":101},{\"id\":102},{\"id\":103},{\"id\":104},{\"id\":105},{\"id\":106},{\"id\":107},{\"id\":108},{\"id\":109},{\"id\":110},{\"id\":111},{\"id\":112},{\"id\":113},{\"id\":114},{\"id\":115},{\"id\":116},{\"id\":117},{\"id\":118},{\"id\":119},{\"id\":120},{\"id\":121},{\"id\":122},{\"id\":123},{\"id\":124},{\"id\":125},{\"id\":126},{\"id\":127},{\"id\":128},{\"id\":129},{\"id\":130},{\"id\":131},{\"id\":132},{\"id\":133},{\"id\":134},{\"id\":135},{\"id\":136},{\"id\":137},{\"id\":138},{\"id\":139},{\"id\":140},{\"id\":141},{\"id\":142},{\"id\":143},{\"id\":144},{\"id\":145},{\"id\":146},{\"id\":147},{\"id\":148},{\"id\":149},{\"id\":150},{\"id\":151},{\"id\":152},{\"id\":153},{\"id\":154},{\"id\":155},{\"id\":156},{\"id\":157},{\"id\":158},{\"id\":159},{\"id\":160},{\"id\":161},{\"id\":162},{\"id\":163},{\"id\":164},{\"id\":165},{\"id\":166},{\"id\":167},{\"id\":168},{\"id\":169},{\"id\":170},{\"id\":171},{\"id\":172},{\"id\":173},{\"id\":174},{\"id\":175},{\"id\":176},{\"id\":177},{\"id\":178},{\"id\":179},{\"id\":180},{\"id\":181},{\"id\":182},{\"id\":183},{\"id\":184},{\"id\":185},{\"id\":186},{\"id\":187},{\"id\":188},{\"id\":189},{\"id\":190},{\"id\":191},{\"id\":192},{\"id\":193},{\"id\":194},{\"id\":195},{\"id\":196},{\"id\":197},{\"id\":198},{\"id\":199},{\"id\":200},{\"id\":201},{\"id\":202},{\"id\":203},{\"id\":204},{\"id\":205},{\"id\":206},{\"id\":207},{\"id\":208},{\"id\":209},{\"id\":210},{\"id\":211},{\"id\":212},{\"id\":213},{\"id\":214},{\"id\":215},{\"id\":216},{\"id\":217},{\"id\":218},{\"id\":219},{\"id\":220},{\"id\":221},{\"id\":222},{\"id\":223},{\"id\":224},{\"id\":225},{\"id\":226},{\"id\":227},{\"id\":228},{\"id\":229},{\"id\":230},{\"id\":231},{\"id\":232},{\"id\":233},{\"id\":234},{\"id\":235},{\"id\":236},{\"id\":237},{\"id\":238},{\"id\":239},{\"id\":240},{\"id\":241},{\"id\":242},{\"id\":243},{\"id\":244},{\"id\":245},{\"id\":246},{\"id\":247},{\"id\":248},{\"id\":249},{\"id\":250},{\"id\":251},{\"id\":252},{\"id\":253},{\"id\":254},{\"id\":255},{\"id\":256},{\"id\":257},{\"id\":258},{\"id\":259},{\"id\":260},{\"id\":261},{\"id\":262},{\"id\":263},{\"id\":264},{\"id\":265},{\"id\":266},{\"id\":267},{\"id\":268},{\"id\":269},{\"id\":270},{\"id\":271},{\"id\":272},{\"id\":273},{\"id\":274},{\"id\":275},{\"id\":276},{\"id\":277},{\"id\":278},{\"id\":279},{\"id\":280},{\"id\":281},{\"id\":282},{\"id\":283},{\"id\":284},{\"id\":285},{\"id\":286},{\"id\":287},{\"id\":288},{\"id\":289},{\"id\":290},{\"id\":291},{\"id\":292},{\"id\":293},{\"id\":294},{\"id\":295},{\"id\":296},{\"id\":297},{\"id\":298},{\"id\":299},{\"id\":300},{\"id\":301},{\"id\":302},{\"id\":303},{\"id\":304},{\"id\":305},{\"id\":306},{\"id\":307},{\"id\":308},{\"id\":309},{\"id\":310},{\"id\":311},{\"id\":312},{\"id\":313},{\"id\":314},{\"id\":315},{\"id\":316},{\"id\":317},{\"id\":318},{\"id\":319},{\"id\":320},{\"id\":321},{\"id\":322},{\"id\":323},{\"id\":324},{\"id\":325},{\"id\":326},{\"id\":327},{\"id\":328},{\"id\":329},{\"id\":330},{\"id\":331},{\"id\":332},{\"id\":333},{\"id\":334},{\"id\":335},{\"id\":336},{\"id\":337},{\"id\":338},{\"id\":339},{\"id\":340},{\"id\":341},{\"id\":342},{\"id\":343},{\"id\":344},{\"id\":345},{\"id\":346},{\"id\":347},{\"id\":348},{\"id\":349},{\"id\":350},{\"id\":351},{\"id\":352},{\"id\":353},{\"id\":354},{\"id\":355},{\"id\":356},{\"id\":357},{\"id\":358},{\"id\":359},{\"id\":360},{\"id\":361},{\"id\":362},{\"id\":363},{\"id\":364},{\"id\":365},{\"id\":366},{\"id\":367},{\"id\":368},{\"id\":369},{\"id\":370},{\"id\":371},{\"id\":372},{\"id\":373},{\"id\":374},{\"id\":375},{\"id\":376},{\"id\":377},{\"id\":378},{\"id\":379},{\"id\":380},{\"id\":381},{\"id\":382},{\"id\":383},{\"id\":384},{\"id\":385},{\"id\":386},{\"id\":387},{\"id\":388},{\"id\":389},{\"id\":390},{\"id\":391},{\"id\":392},{\"id\":393},{\"id\":394},{\"id\":395},{\"id\":396},{\"id\":397},{\"id\":398},{\"id\":399},{\"id\":400},{\"id\":401},{\"id\":402},{\"id\":403},{\"id\":404},{\"id\":405},{\"id\":406},{\"id\":407},{\"id\":408},{\"id\":409},{\"id\":410},{\"id\":411},{\"id\":412},{\"id\":413},{\"id\":414},{\"id\":415},{\"id\":416},{\"id\":417},{\"id\":418},{\"id\":419},{\"id\":420},{\"id\":421},{\"id\":422},{\"id\":423},{\"id\":424},{\"id\":425},{\"id\":426},{\"id\":427},{\"id\":428},{\"id\":429},{\"id\":430},{\"id\":431},{\"id\":432},{\"id\":433},{\"id\":434},{\"id\":435},{\"id\":436},{\"id\":437},{\"id\":438},{\"id\":439},{\"id\":440},{\"id\":441},{\"id\":442},{\"id\":443},{\"id\":444},{\"id\":445},{\"id\":446},{\"id\":447},{\"id\":448},{\"id\":449},{\"id\":450},{\"id\":451},{\"id\":452},{\"id\":453},{\"id\":454},{\"id\":455},{\"id\":456},{\"id\":457},{\"id\":458},{\"id\":459},{\"id\":460},{\"id\":461},{\"id\":462},{\"id\":463},{\"id\":464},{\"id\":465},{\"id\":466},{\"id\":467},{\"id\":468},{\"id\":469},{\"id\":470},{\"id\":471},{\"id\":472},{\"id\":473},{\"id\":474},{\"id\":475},{\"id\":476},{\"id\":477},{\"id\":478},{\"id\":479},{\"id\":480},{\"id\":481},{\"id\":482},{\"id\":483},{\"id\":484},{\"id\":485},{\"id\":486},{\"id\":487},{\"id\":488},{\"id\":489},{\"id\":490},{\"id\":491},{\"id\":492},{\"id\":493},{\"id\":494},{\"id\":495},{\"id\":496},{\"id\":497},{\"id\":498},{\"id\":499},{\"id\":500},{\"id\":501},{\"id\":502},{\"id\":503},{\"id\":504},{\"id\":505},{\"id\":506},{\"id\":507},{\"id\":508},{\"id\":509},{\"id\":510},{\"id\":511},{\"id\":512},{\"id\":513},{\"id\":514},{\"id\":515},{\"id\":516},{\"id\":517},{\"id\":518},{\"id\":519},{\"id\":520},{\"id\":521},{\"id\":522},{\"id\":523},{\"id\":524},{\"id\":525},{\"id\":526},{\"id\":527},{\"id\":528},{\"id\":529},{\"id\":530},{\"id\":531},{\"id\":532},{\"id\":533},{\"id\":534},{\"id\":535},{\"id\":536},{\"id\":537},{\"id\":538},{\"id\":539},{\"id\":540},{\"id\":541},{\"id\":542},{\"id\":543},{\"id\":544},{\"id\":545},{\"id\":546},{\"id\":547},{\"id\":548},{\"id\":549},{\"id\":550},{\"id\":551},{\"id\":552},{\"id\":553},{\"id\":554},{\"id\":555},{\"id\":556},{\"id\":557},{\"id\":558},{\"id\":559},{\"id\":560},{\"id\":561},{\"id\":562},{\"id\":563},{\"id\":564},{\"id\":565},{\"id\":566},{\"id\":567},{\"id\":568},{\"id\":569},{\"id\":570},{\"id\":571},{\"id\":572},{\"id\":573},{\"id\":574},{\"id\":575},{\"id\":576},{\"id\":577},{\"id\":578},{\"id\":579},{\"id\":580},{\"id\":581},{\"id\":582},{\"id\":583},{\"id\":584},{\"id\":585},{\"id\":586},{\"id\":587},{\"id\":588},{\"id\":589},{\"id\":590},{\"id\":591},{\"id\":592},{\"id\":593},{\"id\":594},{\"id\":595},{\"id\":596},{\"id\":597},{\"id\":598},{\"id\":599},{\"id\":600},{\"id\":601},{\"id\":602},{\"id\":603},{\"id\":604},{\"id\":605},{\"id\":606},{\"id\":607},{\"id\":608},{\"id\":609},{\"id\":610},{\"id\":611},{\"id\":612},{\"id\":613},{\"id\":614},{\"id\":615},{\"id\":616},{\"id\":617},{\"id\":618},{\"id\":619},{\"id\":620},{\"id\":621},{\"id\":622},{\"id\":623},{\"id\":624},{\"id\":625},{\"id\":626},{\"id\":627},{\"id\":628},{\"id\":629},{\"id\":630},{\"id\":631},{\"id\":632},{\"id\":633},{\"id\":634},{\"id\":635},{\"id\":636},{\"id\":637},{\"id\":638},{\"id\":639},{\"id\":640},{\"id\":641},{\"id\":642},{\"id\":643},{\"id\":644},{\"id\":645},{\"id\":646},{\"id\":647},{\"id\":648},{\"id\":649},{\"id\":650},{\"id\":651},{\"id\":652},{\"id\":653},{\"id\":654},{\"id\":655},{\"id\":656},{\"id\":657},{\"id\":658},{\"id\":659},{\"id\":660},{\"id\":661},{\"id\":662},{\"id\":663},{\"id\":664},{\"id\":665},{\"id\":666},{\"id\":667},{\"id\":668},{\"id\":669},{\"id\":670},{\"id\":671},{\"id\":672},{\"id\":673},{\"id\":674},{\"id\":675},{\"id\":676},{\"id\":677},{\"id\":678},{\"id\":679},{\"id\":680},{\"id\":681},{\"id\":682},{\"id\":683},{\"id\":684},{\"id\":685},{\"id\":686},{\"id\":687},{\"id\":688},{\"id\":689},{\"id\":690},{\"id\":691},{\"id\":692},{\"id\":693},{\"id\":694},{\"id\":695},{\"id\":696},{\"id\":697},{\"id\":698},{\"id\":699},{\"id\":700},{\"id\":701},{\"id\":702},{\"id\":703},{\"id\":704},{\"id\":705},{\"id\":706},{\"id\":707},{\"id\":708},{\"id\":709},{\"id\":710},{\"id\":711},{\"id\":712},{\"id\":713},{\"id\":714},{\"id\":715},{\"id\":716},{\"id\":717},{\"id\":718},{\"id\":719},{\"id\":720},{\"id\":721},{\"id\":722},{\"id\":723},{\"id\":724},{\"id\":725},{\"id\":726},{\"id\":727},{\"id\":728},{\"id\":729},{\"id\":730},{\"id\":731},{\"id\":732},{\"id\":733},{\"id\":734},{\"id\":735},{\"id\":736},{\"id\":737},{\"id\":738},{\"id\":739},{\"id\":740},{\"id\":741},{\"id\":742},{\"id\":743},{\"id\":744},{\"id\":745},{\"id\":746},{\"id\":747},{\"id\":748},{\"id\":749},{\"id\":750},{\"id\":751},{\"id\":752},{\"id\":753},{\"id\":754},{\"id\":755},{\"id\":756},{\"id\":757},{\"id\":758},{\"id\":759},{\"id\":760},{\"id\":761},{\"id\":762},{\"id\":763},{\"id\":764},{\"id\":765},{\"id\":766},{\"id\":767},{\"id\":768},{\"id\":769},{\"id\":770},{\"id\":771},{\"id\":772},{\"id\":773},{\"id\":774},{\"id\":775},{\"id\":776},{\"id\":777},{\"id\":778},{\"id\":779},{\"id\":780},{\"id\":781},{\"id\":782},{\"id\":783},{\"id\":784},{\"id\":785},{\"id\":786},{\"id\":787},{\"id\":788},{\"id\":789},{\"id\":790},{\"id\":791},{\"id\":792},{\"id\":793},{\"id\":794},{\"id\":795},{\"id\":796},{\"id\":797},{\"id\":798},{\"id\":799},{\"id\":800},{\"id\":801},{\"id\":802},{\"id\":803},{\"id\":804},{\"id\":805},{\"id\":806},{\"id\":807},{\"id\":808},{\"id\":809},{\"id\":810},{\"id\":811},{\"id\":812},{\"id\":813},{\"id\":814},{\"id\":815},{\"id\":816},{\"id\":817},{\"id\":818},{\"id\":819},{\"id\":820},{\"id\":821},{\"id\":822},{\"id\":823},{\"id\":824},{\"id\":825},{\"id\":826},{\"id\":827},{\"id\":828},{\"id\":829},{\"id\":830},{\"id\":831},{\"id\":832},{\"id\":833},{\"id\":834},{\"id\":835},{\"id\":836},{\"id\":837},{\"id\":838},{\"id\":839},{\"id\":840},{\"id\":841},{\"id\":842},{\"id\":843},{\"id\":844},{\"id\":845},{\"id\":846},{\"id\":847},{\"id\":848},{\"id\":849},{\"id\":850},{\"id\":851},{\"id\":852},{\"id\":853},{\"id\":854},{\"id\":855},{\"id\":856},{\"id\":857},{\"id\":858},{\"id\":859},{\"id\":860},{\"id\":861},{\"id\":862},{\"id\":863},{\"id\":864},{\"id\":865},{\"id\":866},{\"id\":867},{\"id\":868},{\"id\":869},{\"id\":870},{\"id\":871},{\"id\":872},{\"id\":873},{\"id\":874},{\"id\":875},{\"id\":876},{\"id\":877},{\"id\":878},{\"id\":879},{\"id\":880},{\"id\":881},{\"id\":882},{\"id\":883},{\"id\":884},{\"id\":885},{\"id\":886},{\"id\":887},{\"id\":888},{\"id\":889},{\"id\":890},{\"id\":891},{\"id\":892},{\"id\":893},{\"id\":894},{\"id\":895},{\"id\":896},{\"id\":897},{\"id\":898},{\"id\":899},{\"id\":900},{\"id\":901},{\"id\":902},{\"id\":903},{\"id\":904},{\"id\":905},{\"id\":906},{\"id\":907},{\"id\":908},{\"id\":909},{\"id\":910},{\"id\":911},{\"id\":912},{\"id\":913},{\"id\":914},{\"id\":915},{\"id\":916},{\"id\":917},{\"id\":918},{\"id\":919},{\"id\":920},{\"id\":921},{\"id\":922},{\"id\":923},{\"id\":924},{\"id\":925},{\"id\":926},{\"id\":927},{\"id\":928},{\"id\":929},{\"id\":930},{\"id\":931},{\"id\":932},{\"id\":933},{\"id\":934},{\"id\":935},{\"id\":936},{\"id\":937},{\"id\":938},{\"id\":939},{\"id\":940},{\"id\":941},{\"id\":942},{\"id\":943},{\"id\":944},{\"id\":945},{\"id\":946},{\"id\":947},{\"id\":948},{\"id\":949},{\"id\":950},{\"id\":951},{\"id\":952},{\"id\":953},{\"id\":954},{\"id\":955},{\"id\":956},{\"id\":957},{\"id\":958},{\"id\":959},{\"id\":960},{\"id\":961},{\"id\":962},{\"id\":963},{\"id\":964},{\"id\":965},{\"id\":966},{\"id\":967},{\"id\":968},{\"id\":969},{\"id\":970},{\"id\":971},{\"id\":972},{\"id\":973},{\"id\":974},{\"id\":975},{\"id\":976},{\"id\":977},{\"id\":978},{\"id\":979},{\"id\":980},{\"id\":981},{\"id\":982},{\"id\":983},{\"id\":984},{\"id\":985},{\"id\":986},{\"id\":987},{\"id\":988},{\"id\":989},{\"id\":990},{\"id\":991},{\"id\":992},{\"id\":993},{\"id\":994},{\"id\":995},{\"id\":996},{\"id\":997},{\"id\":998},{\"id\":999},{\"id\":1000},{\"id\":1001},{\"id\":1002},{\"id\":1003},{\"id\":1004},{\"id\":1005},{\"id\":1006},{\"id\":1007},{\"id\":1008},{\"id\":1009},{\"id\":1010},{\"id\":1011},{\"id\":1012},{\"id\":1013},{\"id\":1014},{\"id\":1015},{\"id\":1016},{\"id\":1017},{\"id\":1018},{\"id\":1019},{\"id\":1020},{\"id\":1021},{\"id\":1022},{\"id\":1023},{\"id\":1024},{\"id\":1025},{\"id\":1026},{\"id\":1027},{\"id\":1028},{\"id\":1029},{\"id\":1030},{\"id\":1031},{\"id\":1032},{\"id\":1033},{\"id\":1034},{\"id\":1035},{\"id\":1036},{\"id\":1037},{\"id\":1038},{\"id\":1039},{\"id\":1040},{\"id\":1041},{\"id\":1042},{\"id\":1043},{\"id\":1044},{\"id\":1045},{\"id\":1046},{\"id\":1047},{\"id\":1048},{\"id\":1049},{\"id\":1050},{\"id\":1051},{\"id\":1052},{\"id\":1053},{\"id\":1054},{\"id\":1055},{\"id\":1056},{\"id\":1057},{\"id\":1058},{\"id\":1059},{\"id\":1060},{\"id\":1061},{\"id\":1062},{\"id\":1063},{\"id\":1064},{\"id\":1065},{\"id\":1066},{\"id\":1067},{\"id\":1068},{\"id\":1069},{\"id\":1070},{\"id\":1071},{\"id\":1072},{\"id\":1073},{\"id\":1074},{\"id\":1075},{\"id\":1076},{\"id\":1077},{\"id\":1078},{\"id\":1079},{\"id\":1080},{\"id\":1081},{\"id\":1082},{\"id\":1083},{\"id\":1084},{\"id\":1085},{\"id\":1086},{\"id\":1087},{\"id\":1088},{\"id\":1089},{\"id\":1090},{\"id\":1091},{\"id\":1092},{\"id\":1093},{\"id\":1094},{\"id\":1095},{\"id\":1096},{\"id\":1097},{\"id\":1098},{\"id\":1099},{\"id\":1100},{\"id\":1101},{\"id\":1102},{\"id\":1103},{\"id\":1104},{\"id\":1105},{\"id\":1106},{\"id\":1107},{\"id\":1108},{\"id\":1109},{\"id\":1110},{\"id\":1111},{\"id\":1112},{\"id\":1113},{\"id\":1114},{\"id\":1115},{\"id\":1116},{\"id\":1117},{\"id\":1118},{\"id\":1119},{\"id\":1120},{\"id\":1121},{\"id\":1122},{\"id\":1123},{\"id\":1124},{\"id\":1125},{\"id\":1126},{\"id\":1127},{\"id\":1128},{\"id\":1129},{\"id\":1130},{\"id\":1131},{\"id\":1132},{\"id\":1133},{\"id\":1134},{\"id\":1135},{\"id\":1136},{\"id\":1137},{\"id\":1138},{\"id\":1139},{\"id\":1140},{\"id\":1141},{\"id\":1142},{\"id\":1143},{\"id\":1144},{\"id\":1145},{\"id\":1146},{\"id\":1147},{\"id\":1148},{\"id\":1149},{\"id\":1150},{\"id\":1151},{\"id\":1152},{\"id\":1153},{\"id\":1154},{\"id\":1155},{\"id\":1156},{\"id\":1157},{\"id\":1158},{\"id\":1159},{\"id\":1160},{\"id\":1161},{\"id\":1162},{\"id\":1163},{\"id\":1164},{\"id\":1165},{\"id\":1166},{\"id\":1167},{\"id\":1168},{\"id\":1169},{\"id\":1170},{\"id\":1171},{\"id\":1172},{\"id\":1173},{\"id\":1174},{\"id\":1175},{\"id\":1176},{\"id\":1177},{\"id\":1178},{\"id\":1179},{\"id\":1180},{\"id\":1181},{\"id\":1182},{\"id\":1183},{\"id\":1184},{\"id\":1185},{\"id\":1186},{\"id\":1187},{\"id\":1188},{\"id\":1189},{\"id\":1190},{\"id\":1191},{\"id\":1192},{\"id\":1193},{\"id\":1194},{\"id\":1195},{\"id\":1196},{\"id\":1197},{\"id\":1198},{\"id\":1199},{\"id\":1200},{\"id\":1201},{\"id\":1202},{\"id\":1203},{\"id\":1204},{\"id\":1205},{\"id\":1206},{\"id\":1207},{\"id\":1208},{\"id\":1209},{\"id\":1210},{\"id\":1211},{\"id\":1212},{\"id\":1213},{\"id\":1214},{\"id\":1215},{\"id\":1216},{\"id\":1217},{\"id\":1218},{\"id\":1219},{\"id\":1220},{\"id\":1221},{\"id\":1222},{\"id\":1223},{\"id\":1224},{\"id\":1225},{\"id\":1226},{\"id\":1227},{\"id\":1228},{\"id\":1229},{\"id\":1230},{\"id\":1231},{\"id\":1232},{\"id\":1233},{\"id\":1234},{\"id\":1235},{\"id\":1236},{\"id\":1237},{\"id\":1238},{\"id\":1239},{\"id\":1240},{\"id\":1241},{\"id\":1242},{\"id\":1243},{\"id\":1244},{\"id\":1245},{\"id\":1246},{\"id\":1247},{\"id\":1248},{\"id\":1249},{\"id\":1250},{\"id\":1251},{\"id\":1252},{\"id\":1253},{\"id\":1254},{\"id\":1255},{\"id\":1256},{\"id\":1257},{\"id\":1258},{\"id\":1259},{\"id\":1260},{\"id\":1261},{\"id\":1262},{\"id\":1263},{\"id\":1264},{\"id\":1265},{\"id\":1266},{\"id\":1267},{\"id\":1268},{\"id\":1269},{\"id\":1270},{\"id\":1271},{\"id\":1272},{\"id\":1273},{\"id\":1274},{\"id\":1275},{\"id\":1276},{\"id\":1277},{\"id\":1278},{\"id\":1279},{\"id\":1280},{\"id\":1281},{\"id\":1282},{\"id\":1283},{\"id\":1284},{\"id\":1285},{\"id\":1286},{\"id\":1287},{\"id\":1288},{\"id\":1289},{\"id\":1290},{\"id\":1291},{\"id\":1292},{\"id\":1293},{\"id\":1294},{\"id\":1295},{\"id\":1296},{\"id\":1297},{\"id\":1298},{\"id\":1299},{\"id\":1300},{\"id\":1301},{\"id\":1302},{\"id\":1303},{\"id\":1304},{\"id\":1305},{\"id\":1306},{\"id\":1307},{\"id\":1308},{\"id\":1309},{\"id\":1310},{\"id\":1311},{\"id\":1312},{\"id\":1313},{\"id\":1314},{\"id\":1315},{\"id\":1316},{\"id\":1317},{\"id\":1318},{\"id\":1319},{\"id\":1320},{\"id\":1321},{\"id\":1322},{\"id\":1323},{\"id\":1324},{\"id\":1325},{\"id\":1326},{\"id\":1327},{\"id\":1328},{\"id\":1329},{\"id\":1330},{\"id\":1331},{\"id\":1332},{\"id\":1333},{\"id\":1334},{\"id\":1335},{\"id\":1336},{\"id\":1337},{\"id\":1338},{\"id\":1339},{\"id\":1340},{\"id\":1341},{\"id\":1342},{\"id\":1343},{\"id\":1344},{\"id\":1345},{\"id\":1346},{\"id\":1347},{\"id\":1348},{\"id\":1349},{\"id\":1350},{\"id\":1351},{\"id\":1352},{\"id\":1353},{\"id\":1354},{\"id\":1355},{\"id\":1356},{\"id\":1357},{\"id\":1358},{\"id\":1359},{\"id\":1360},{\"id\":1361},{\"id\":1362},{\"id\":1363},{\"id\":1364},{\"id\":1365},{\"id\":1366},{\"id\":1367},{\"id\":1368},{\"id\":1369},{\"id\":1370},{\"id\":1371},{\"id\":1372},{\"id\":1373},{\"id\":1374},{\"id\":1375},{\"id\":1376},{\"id\":1377},{\"id\":1378},{\"id\":1379},{\"id\":1380},{\"id\":1381},{\"id\":1382},{\"id\":1383},{\"id\":1384},{\"id\":1385},{\"id\":1386},{\"id\":1387},{\"id\":1388},{\"id\":1389},{\"id\":1390},{\"id\":1391},{\"id\":1392},{\"id\":1393},{\"id\":1394},{\"id\":1395},{\"id\":1396},{\"id\":1397},{\"id\":1398},{\"id\":1399},{\"id\":1400},{\"id\":1401},{\"id\":1402},{\"id\":1403},{\"id\":1404},{\"id\":1405},{\"id\":1406},{\"id\":1407},{\"id\":1408},{\"id\":1409},{\"id\":1410},{\"id\":1411},{\"id\":1412},{\"id\":1413},{\"id\":1414},{\"id\":1415},{\"id\":1416},{\"id\":1417},{\"id\":1418},{\"id\":1419},{\"id\":1420},{\"id\":1421},{\"id\":1422},{\"id\":1423},{\"id\":1424},{\"id\":1425},{\"id\":1426},{\"id\":1427},{\"id\":1428},{\"id\":1429},{\"id\":1430},{\"id\":1431},{\"id\":1432},{\"id\":1433},{\"id\":1434},{\"id\":1435},{\"id\":1436},{\"id\":1437},{\"id\":1438},{\"id\":1439},{\"id\":1440},{\"id\":1441},{\"id\":1442},{\"id\":1443},{\"id\":1444},{\"id\":1445},{\"id\":1446},{\"id\":1447},{\"id\":1448},{\"id\":1449},{\"id\":1450},{\"id\":1451},{\"id\":1452},{\"id\":1453},{\"id\":1454},{\"id\":1455},{\"id\":1456},{\"id\":1457},{\"id\":1458},{\"id\":1459},{\"id\":1460},{\"id\":1461},{\"id\":1462},{\"id\":1463},{\"id\":1464},{\"id\":1465},{\"id\":1466},{\"id\":1467},{\"id\":1468},{\"id\":1469},{\"id\":1470},{\"id\":1471},{\"id\":1472},{\"id\":1473},{\"id\":1474},{\"id\":1475},{\"id\":1476},{\"id\":1477},{\"id\":1478},{\"id\":1479},{\"id\":1480},{\"id\":1481},{\"id\":1482},{\"id\":1483},{\"id\":1484},{\"id\":1485},{\"id\":1486},{\"id\":1487},{\"id\":1488},{\"id\":1489},{\"id\":1490},{\"id\":1491},{\"id\":1492},{\"id\":1493},{\"id\":1494},{\"id\":1495},{\"id\":1496},{\"id\":1497},{\"id\":1498},{\"id\":1499},{\"id\":1500},{\"id\":1501},{\"id\":1502},{\"id\":1503},{\"id\":1504},{\"id\":1505},{\"id\":1506},{\"id\":1507},{\"id\":1508},{\"id\":1509},{\"id\":1510},{\"id\":1511},{\"id\":1512},{\"id\":1513},{\"id\":1514},{\"id\":1515},{\"id\":1516},{\"id\":1517},{\"id\":1518},{\"id\":1519},{\"id\":1520},{\"id\":1521},{\"id\":1522},{\"id\":1523},{\"id\":1524},{\"id\":1525},{\"id\":1526},{\"id\":1527},{\"id\":1528},{\"id\":1529},{\"id\":1530},{\"id\":1531},{\"id\":1532},{\"id\":1533},{\"id\":1534},{\"id\":1535},{\"id\":1536},{\"id\":1537},{\"id\":1538},{\"id\":1539},{\"id\":1540},{\"id\":1541},{\"id\":1542},{\"id\":1543},{\"id\":1544},{\"id\":1545},{\"id\":1546},{\"id\":1547},{\"id\":1548},{\"id\":1549},{\"id\":1550},{\"id\":1551},{\"id\":1552},{\"id\":1553},{\"id\":1554},{\"id\":1555},{\"id\":1556},{\"id\":1557},{\"id\":1558},{\"id\":1559},{\"id\":1560},{\"id\":1561},{\"id\":1562},{\"id\":1563},{\"id\":1564},{\"id\":1565},{\"id\":1566},{\"id\":1567},{\"id\":1568},{\"id\":1569},{\"id\":1570},{\"id\":1571},{\"id\":1572},{\"id\":1573},{\"id\":1574},{\"id\":1575},{\"id\":1576},{\"id\":1577},{\"id\":1578},{\"id\":1579},{\"id\":1580},{\"id\":1581},{\"id\":1582},{\"id\":1583},{\"id\":1584},{\"id\":1585},{\"id\":1586},{\"id\":1587},{\"id\":1588},{\"id\":1589},{\"id\":1590},{\"id\":1591},{\"id\":1592},{\"id\":1593},{\"id\":1594},{\"id\":1595},{\"id\":1596},{\"id\":1597},{\"id\":1598},{\"id\":1599},{\"id\":1600},{\"id\":1601},{\"id\":1602},{\"id\":1603},{\"id\":1604},{\"id\":1605},{\"id\":1606},{\"id\":1607},{\"id\":1608},{\"id\":1609},{\"id\":1610},{\"id\":1611},{\"id\":1612},{\"id\":1613},{\"id\":1614},{\"id\":1615},{\"id\":1616},{\"id\":1617},{\"id\":1618},{\"id\":1619},{\"id\":1620},{\"id\":1621},{\"id\":1622},{\"id\":1623},{\"id\":1624},{\"id\":1625},{\"id\":1626},{\"id\":1627},{\"id\":1628},{\"id\":1629},{\"id\":1630},{\"id\":1631},{\"id\":1632},{\"id\":1633},{\"id\":1634},{\"id\":1635},{\"id\":1636},{\"id\":1637},{\"id\":1638},{\"id\":1639},{\"id\":1640},{\"id\":1641},{\"id\":1642},{\"id\":1643},{\"id\":1644},{\"id\":1645},{\"id\":1646},{\"id\":1647},{\"id\":1648},{\"id\":1649},{\"id\":1650},{\"id\":1651},{\"id\":1652},{\"id\":1653},{\"id\":1654},{\"id\":1655},{\"id\":1656},{\"id\":1657},{\"id\":1658},{\"id\":1659},{\"id\":1660},{\"id\":1661},{\"id\":1662},{\"id\":1663},{\"id\":1664},{\"id\":1665},{\"id\":1666},{\"id\":1667},{\"id\":1668},{\"id\":1669},{\"id\":1670},{\"id\":1671},{\"id\":1672},{\"id\":1673},{\"id\":1674},{\"id\":1675},{\"id\":1676},{\"id\":1677},{\"id\":1678},{\"id\":1679},{\"id\":1680},{\"id\":1681},{\"id\":1682},{\"id\":1683},{\"id\":1684},{\"id\":1685},{\"id\":1686},{\"id\":1687},{\"id\":1688},{\"id\":1689},{\"id\":1690},{\"id\":1691},{\"id\":1692},{\"id\":1693},{\"id\":1694},{\"id\":1695},{\"id\":1696},{\"id\":1697},{\"id\":1698},{\"id\":1699},{\"id\":1700},{\"id\":1701},{\"id\":1702},{\"id\":1703},{\"id\":1704},{\"id\":1705},{\"id\":1706},{\"id\":1707},{\"id\":1708},{\"id\":1709},{\"id\":1710},{\"id\":1711},{\"id\":1712},{\"id\":1713},{\"id\":1714},{\"id\":1715},{\"id\":1716},{\"id\":1717},{\"id\":1718},{\"id\":1719},{\"id\":1720},{\"id\":1721},{\"id\":1722},{\"id\":1723},{\"id\":1724},{\"id\":1725},{\"id\":1726},{\"id\":1727},{\"id\":1728},{\"id\":1729},{\"id\":1730},{\"id\":1731},{\"id\":1732},{\"id\":1733},{\"id\":1734},{\"id\":1735},{\"id\":1736},{\"id\":1737},{\"id\":1738},{\"id\":1739},{\"id\":1740},{\"id\":1741},{\"id\":1742},{\"id\":1743},{\"id\":1744},{\"id\":1745},{\"id\":1746},{\"id\":1747},{\"id\":1748},{\"id\":1749},{\"id\":1750},{\"id\":1751},{\"id\":1752},{\"id\":1753},{\"id\":1754},{\"id\":1755},{\"id\":1756},{\"id\":1757},{\"id\":1758},{\"id\":1759},{\"id\":1760},{\"id\":1761},{\"id\":1762},{\"id\":1763},{\"id\":1764},{\"id\":1765},{\"id\":1766},{\"id\":1767},{\"id\":1768},{\"id\":1769},{\"id\":1770},{\"id\":1771},{\"id\":1772},{\"id\":1773},{\"id\":1774},{\"id\":1775},{\"id\":1776},{\"id\":1777},{\"id\":1778},{\"id\":1779},{\"id\":1780},{\"id\":1781},{\"id\":1782},{\"id\":1783},{\"id\":1784},{\"id\":1785},{\"id\":1786},{\"id\":1787},{\"id\":1788},{\"id\":1789},{\"id\":1790},{\"id\":1791},{\"id\":1792},{\"id\":1793},{\"id\":1794},{\"id\":1795},{\"id\":1796},{\"id\":1797},{\"id\":1798},{\"id\":1799},{\"id\":1800},{\"id\":1801},{\"id\":1802},{\"id\":1803},{\"id\":1804},{\"id\":1805},{\"id\":1806},{\"id\":1807},{\"id\":1808},{\"id\":1809},{\"id\":1810},{\"id\":1811},{\"id\":1812},{\"id\":1813},{\"id\":1814},{\"id\":1815},{\"id\":1816},{\"id\":1817},{\"id\":1818},{\"id\":1819},{\"id\":1820},{\"id\":1821},{\"id\":1822},{\"id\":1823},{\"id\":1824},{\"id\":1825},{\"id\":1826},{\"id\":1827},{\"id\":1828},{\"id\":1829},{\"id\":1830},{\"id\":1831},{\"id\":1832},{\"id\":1833},{\"id\":1834},{\"id\":1835},{\"id\":1836},{\"id\":1837},{\"id\":1838},{\"id\":1839},{\"id\":1840},{\"id\":1841},{\"id\":1842},{\"id\":1843},{\"id\":1844},{\"id\":1845},{\"id\":1846},{\"id\":1847},{\"id\":1848},{\"id\":1849},{\"id\":1850},{\"id\":1851},{\"id\":1852},{\"id\":1853},{\"id\":1854},{\"id\":1855},{\"id\":1856},{\"id\":1857},{\"id\":1858},{\"id\":1859},{\"id\":1860},{\"id\":1861},{\"id\":1862},{\"id\":1863},{\"id\":1864},{\"id\":1865},{\"id\":1866},{\"id\":1867},{\"id\":1868},{\"id\":1869},{\"id\":1870},{\"id\":1871},{\"id\":1872},{\"id\":1873},{\"id\":1874},{\"id\":1875},{\"id\":1876},{\"id\":1877},{\"id\":1878},{\"id\":1879},{\"id\":1880},{\"id\":1881},{\"id\":1882},{\"id\":1883},{\"id\":1884},{\"id\":1885},{\"id\":1886},{\"id\":1887},{\"id\":1888},{\"id\":1889},{\"id\":1890},{\"id\":1891},{\"id\":1892},{\"id\":1893},{\"id\":1894},{\"id\":1895},{\"id\":1896},{\"id\":1897},{\"id\":1898},{\"id\":1899},{\"id\":1900},{\"id\":1901},{\"id\":1902},{\"id\":1903},{\"id\":1904},{\"id\":1905},{\"id\":1906},{\"id\":1907},{\"id\":1908},{\"id\":1909},{\"id\":1910},{\"id\":1911},{\"id\":1912},{\"id\":1913},{\"id\":1914},{\"id\":1915},{\"id\":1916},{\"id\":1917},{\"id\":1918},{\"id\":1919},{\"id\":1920},{\"id\":1921},{\"id\":1922},{\"id\":1923},{\"id\":1924},{\"id\":1925},{\"id\":1926},{\"id\":1927},{\"id\":1928},{\"id\":1929},{\"id\":1930},{\"id\":1931},{\"id\":1932},{\"id\":1933},{\"id\":1934},{\"id\":1935},{\"id\":1936},{\"id\":1937},{\"id\":1938},{\"id\":1939},{\"id\":1940},{\"id\":1941},{\"id\":1942},{\"id\":1943},{\"id\":1944},{\"id\":1945},{\"id\":1946},{\"id\":1947},{\"id\":1948},{\"id\":1949},{\"id\":1950},{\"id\":1951},{\"id\":1952},{\"id\":1953},{\"id\":1954},{\"id\":1955},{\"id\":1956},{\"id\":1957},{\"id\":1958},{\"id\":1959},{\"id\":1960},{\"id\":1961},{\"id\":1962},{\"id\":1963},{\"id\":1964},{\"id\":1965},{\"id\":1966},{\"id\":1967},{\"id\":1968},{\"id\":1969},{\"id\":1970},{\"id\":1971},{\"id\":1972},{\"id\":1973},{\"id\":1974},{\"id\":1975},{\"id\":1976},{\"id\":1977},{\"id\":1978},{\"id\":1979},{\"id\":1980},{\"id\":1981},{\"id\":1982},{\"id\":1983},{\"id\":1984},{\"id\":1985},{\"id\":1986},{\"id\":1987},{\"id\":1988},{\"id\":1989},{\"id\":1990},{\"id\":1991},{\"id\":1992},{\"id\":1993},{\"id\":1994},{\"id\":1995},{\"id\":1996},{\"id\":1997},{\"id\":1998},{\"id\":1999},{\"id\":2000},{\"id\":2001},{\"id\":2002},{\"id\":2003},{\"id\":2004},{\"id\":2005},{\"id\":2006},{\"id\":2007},{\"id\":2008},{\"id\":2009},{\"id\":2010},{\"id\":2011},{\"id\":2012},{\"id\":2013},{\"id\":2014},{\"id\":2015},{\"id\":2016},{\"id\":2017},{\"id\":2018},{\"id\":2019},{\"id\":2020},{\"id\":2021},{\"id\":2022},{\"id\":2023},{\"id\":2024},{\"id\":2025},{\"id\":2026},{\"id\":2027},{\"id\":2028},{\"id\":2029},{\"id\":2030},{\"id\":2031},{\"id\":2032},{\"id\":2033},{\"id\":2034},{\"id\":2035},{\"id\":2036},{\"id\":2037},{\"id\":2038},{\"id\":2039},{\"id\":2040},{\"id\":2041},{\"id\":2042},{\"id\":2043},{\"id\":2044},{\"id\":2045},{\"id\":2046},{\"id\":2047},{\"id\":2048},{\"id\":2049},{\"id\":2050},{\"id\":2051},{\"id\":2052},{\"id\":2053},{\"id\":2054},{\"id\":2055},{\"id\":2056},{\"id\":2057},{\"id\":2058},{\"id\":2059},{\"id\":2060},{\"id\":2061},{\"id\":2062},{\"id\":2063},{\"id\":2064},{\"id\":2065},{\"id\":2066},{\"id\":2067},{\"id\":2068},{\"id\":2069},{\"id\":2070},{\"id\":2071},{\"id\":2072},{\"id\":2073},{\"id\":2074},{\"id\":2075},{\"id\":2076},{\"id\":2077},{\"id\":2078},{\"id\":2079},{\"id\":2080},{\"id\":2081},{\"id\":2082},{\"id\":2083},{\"id\":2084},{\"id\":2085},{\"id\":2086},{\"id\":2087},{\"id\":2088},{\"id\":2089},{\"id\":2090},{\"id\":2091},{\"id\":2092},{\"id\":2093},{\"id\":2094},{\"id\":2095},{\"id\":2096},{\"id\":2097},{\"id\":2098},{\"id\":2099},{\"id\":2100},{\"id\":2101},{\"id\":2102},{\"id\":2103},{\"id\":2104},{\"id\":2105},{\"id\":2106},{\"id\":2107},{\"id\":2108},{\"id\":2109},{\"id\":2110},{\"id\":2111},{\"id\":2112},{\"id\":2113},{\"id\":2114},{\"id\":2115},{\"id\":2116},{\"id\":2117},{\"id\":2118},{\"id\":2119},{\"id\":2120},{\"id\":2121},{\"id\":2122},{\"id\":2123},{\"id\":2124},{\"id\":2125},{\"id\":2126},{\"id\":2127},{\"id\":2128},{\"id\":2129},{\"id\":2130},{\"id\":2131},{\"id\":2132},{\"id\":2133},{\"id\":2134},{\"id\":2135},{\"id\":2136},{\"id\":2137},{\"id\":2138},{\"id\":2139},{\"id\":2140},{\"id\":2141},{\"id\":2142},{\"id\":2143},{\"id\":2144},{\"id\":2145},{\"id\":2146},{\"id\":2147},{\"id\":2148},{\"id\":2149},{\"id\":2150},{\"id\":2151},{\"id\":2152},{\"id\":2153},{\"id\":2154},{\"id\":2155},{\"id\":2156},{\"id\":2157},{\"id\":2158},{\"id\":2159},{\"id\":2160},{\"id\":2161},{\"id\":2162},{\"id\":2163},{\"id\":2164},{\"id\":2165},{\"id\":2166},{\"id\":2167},{\"id\":2168},{\"id\":2169},{\"id\":2170},{\"id\":2171},{\"id\":2172},{\"id\":2173},{\"id\":2174},{\"id\":2175},{\"id\":2176},{\"id\":2177},{\"id\":2178},{\"id\":2179},{\"id\":2180},{\"id\":2181},{\"id\":2182},{\"id\":2183},{\"id\":2184},{\"id\":2185},{\"id\":2186},{\"id\":2187},{\"id\":2188},{\"id\":2189},{\"id\":2190},{\"id\":2191},{\"id\":2192},{\"id\":2193},{\"id\":2194},{\"id\":2195},{\"id\":2196},{\"id\":2197},{\"id\":2198},{\"id\":2199},{\"id\":2200},{\"id\":2201},{\"id\":2202},{\"id\":2203},{\"id\":2204},{\"id\":2205},{\"id\":2206},{\"id\":2207},{\"id\":2208},{\"id\":2209},{\"id\":2210},{\"id\":2211},{\"id\":2212},{\"id\":2213},{\"id\":2214},{\"id\":2215},{\"id\":2216},{\"id\":2217},{\"id\":2218},{\"id\":2219},{\"id\":2220},{\"id\":2221},{\"id\":2222},{\"id\":2223},{\"id\":2224},{\"id\":2225},{\"id\":2226},{\"id\":2227},{\"id\":2228},{\"id\":2229},{\"id\":2230},{\"id\":2231},{\"id\":2232},{\"id\":2233},{\"id\":2234},{\"id\":2235},{\"id\":2236},{\"id\":2237},{\"id\":2238},{\"id\":2239},{\"id\":2240},{\"id\":2241},{\"id\":2242},{\"id\":2243},{\"id\":2244},{\"id\":2245},{\"id\":2246},{\"id\":2247},{\"id\":2248},{\"id\":2249},{\"id\":2250},{\"id\":2251},{\"id\":2252},{\"id\":2253},{\"id\":2254},{\"id\":2255},{\"id\":2256},{\"id\":2257},{\"id\":2258},{\"id\":2259},{\"id\":2260},{\"id\":2261},{\"id\":2262},{\"id\":2263},{\"id\":2264},{\"id\":2265},{\"id\":2266},{\"id\":2267},{\"id\":2268},{\"id\":2269},{\"id\":2270},{\"id\":2271},{\"id\":2272},{\"id\":2273},{\"id\":2274},{\"id\":2275},{\"id\":2276},{\"id\":2277},{\"id\":2278},{\"id\":2279},{\"id\":2280},{\"id\":2281},{\"id\":2282},{\"id\":2283},{\"id\":2284},{\"id\":2285},{\"id\":2286},{\"id\":2287},{\"id\":2288},{\"id\":2289},{\"id\":2290},{\"id\":2291},{\"id\":2292},{\"id\":2293},{\"id\":2294},{\"id\":2295},{\"id\":2296},{\"id\":2297},{\"id\":2298},{\"id\":2299},{\"id\":2300},{\"id\":2301},{\"id\":2302},{\"id\":2303},{\"id\":2304},{\"id\":2305},{\"id\":2306},{\"id\":2307},{\"id\":2308},{\"id\":2309},{\"id\":2310},{\"id\":2311},{\"id\":2312},{\"id\":2313},{\"id\":2314},{\"id\":2315},{\"id\":2316},{\"id\":2317},{\"id\":2318},{\"id\":2319},{\"id\":2320},{\"id\":2321},{\"id\":2322},{\"id\":2323},{\"id\":2324},{\"id\":2325},{\"id\":2326},{\"id\":2327},{\"id\":2328},{\"id\":2329},{\"id\":2330},{\"id\":2331},{\"id\":2332},{\"id\":2333},{\"id\":2334},{\"id\":2335},{\"id\":2336},{\"id\":2337},{\"id\":2338},{\"id\":2339},{\"id\":2340},{\"id\":2341},{\"id\":2342},{\"id\":2343},{\"id\":2344},{\"id\":2345},{\"id\":2346},{\"id\":2347},{\"id\":2348},{\"id\":2349},{\"id\":2350},{\"id\":2351},{\"id\":2352},{\"id\":2353},{\"id\":2354},{\"id\":2355},{\"id\":2356},{\"id\":2357},{\"id\":2358},{\"id\":2359},{\"id\":2360},{\"id\":2361},{\"id\":2362},{\"id\":2363},{\"id\":2364},{\"id\":2365},{\"id\":2366},{\"id\":2367},{\"id\":2368},{\"id\":2369},{\"id\":2370},{\"id\":2371},{\"id\":2372},{\"id\":2373},{\"id\":2374},{\"id\":2375},{\"id\":2376},{\"id\":2377},{\"id\":2378},{\"id\":2379},{\"id\":2380},{\"id\":2381},{\"id\":2382},{\"id\":2383},{\"id\":2384},{\"id\":2385},{\"id\":2386},{\"id\":2387},{\"id\":2388},{\"id\":2389},{\"id\":2390},{\"id\":2391},{\"id\":2392},{\"id\":2393},{\"id\":2394},{\"id\":2395},{\"id\":2396},{\"id\":2397},{\"id\":2398},{\"id\":2399},{\"id\":2400},{\"id\":2401},{\"id\":2402},{\"id\":2403},{\"id\":2404},{\"id\":2405},{\"id\":2406},{\"id\":2407},{\"id\":2408},{\"id\":2409},{\"id\":2410},{\"id\":2411},{\"id\":2412},{\"id\":2413},{\"id\":2414},{\"id\":2415},{\"id\":2416},{\"id\":2417},{\"id\":2418},{\"id\":2419},{\"id\":2420},{\"id\":2421},{\"id\":2422},{\"id\":2423},{\"id\":2424},{\"id\":2425},{\"id\":2426},{\"id\":2427},{\"id\":2428},{\"id\":2429},{\"id\":2430},{\"id\":2431},{\"id\":2432},{\"id\":2433},{\"id\":2434},{\"id\":2435},{\"id\":2436},{\"id\":2437},{\"id\":2438},{\"id\":2439},{\"id\":2440},{\"id\":2441},{\"id\":2442},{\"id\":2443},{\"id\":2444},{\"id\":2445},{\"id\":2446},{\"id\":2447},{\"id\":2448},{\"id\":2449},{\"id\":2450},{\"id\":2451},{\"id\":2452},{\"id\":2453},{\"id\":2454},{\"id\":2455},{\"id\":2456},{\"id\":2457},{\"id\":2458},{\"id\":2459},{\"id\":2460},{\"id\":2461},{\"id\":2462},{\"id\":2463},{\"id\":2464},{\"id\":2465},{\"id\":2466},{\"id\":2467},{\"id\":2468},{\"id\":2469},{\"id\":2470},{\"id\":2471},{\"id\":2472},{\"id\":2473},{\"id\":2474},{\"id\":2475},{\"id\":2476},{\"id\":2477},{\"id\":2478},{\"id\":2479},{\"id\":2480},{\"id\":2481},{\"id\":2482},{\"id\":2483},{\"id\":2484},{\"id\":2485},{\"id\":2486},{\"id\":2487},{\"id\":2488},{\"id\":2489},{\"id\":2490},{\"id\":2491},{\"id\":2492},{\"id\":2493},{\"id\":2494},{\"id\":2495},{\"id\":2496},{\"id\":2497},{\"id\":2498},{\"id\":2499},{\"id\":2500},{\"id\":2501},{\"id\":2502},{\"id\":2503},{\"id\":2504},{\"id\":2505},{\"id\":2506},{\"id\":2507},{\"id\":2508},{\"id\":2509},{\"id\":2510},{\"id\":2511},{\"id\":2512},{\"id\":2513},{\"id\":2514},{\"id\":2515},{\"id\":2516},{\"id\":2517},{\"id\":2518},{\"id\":2519},{\"id\":2520},{\"id\":2521},{\"id\":2522},{\"id\":2523},{\"id\":2524},{\"id\":2525},{\"id\":2526},{\"id\":2527},{\"id\":2528},{\"id\":2529},{\"id\":2530},{\"id\":2531},{\"id\":2532},{\"id\":2533},{\"id\":2534},{\"id\":2535},{\"id\":2536},{\"id\":2537},{\"id\":2538},{\"id\":2539},{\"id\":2540},{\"id\":2541},{\"id\":2542},{\"id\":2543},{\"id\":2544},{\"id\":2545},{\"id\":2546},{\"id\":2547},{\"id\":2548},{\"id\":2549},{\"id\":2550},{\"id\":2551},{\"id\":2552},{\"id\":2553},{\"id\":2554},{\"id\":2555},{\"id\":2556},{\"id\":2557},{\"id\":2558},{\"id\":2559},{\"id\":2560},{\"id\":2561},{\"id\":2562},{\"id\":2563},{\"id\":2564},{\"id\":2565},{\"id\":2566},{\"id\":2567},{\"id\":2568},{\"id\":2569},{\"id\":2570},{\"id\":2571},{\"id\":2572},{\"id\":2573},{\"id\":2574},{\"id\":2575},{\"id\":2576},{\"id\":2577},{\"id\":2578},{\"id\":2579},{\"id\":2580},{\"id\":2581},{\"id\":2582},{\"id\":2583},{\"id\":2584},{\"id\":2585},{\"id\":2586},{\"id\":2587},{\"id\":2588},{\"id\":2589},{\"id\":2590},{\"id\":2591},{\"id\":2592},{\"nodeType\":3,\"id\":2596,\"textContent\":\" // Track clicks on page $(document).ready(function() { $(\\\".control\\\").click(function(e) { e.stopImmediatePropagation(); clicks = clicks + 1; console.log(clicks); }); }); $('.userid').html(sid); // console.log(\\\"start of clicked array: \\\"+clicked); // console.log(\\\"start of hovered string: \\\"+hovered); //set correct answers for each question var triangular_answers = { \\\"acme.starttime.1\\\" : [\\\"F\\\"], \\\"acme.starts.1\\\" : [\\\"K\\\"], \\\"acme.meets.1\\\" : [\\\"F\\\"], \\\"acme.endtime.1\\\" : [\\\"H\\\"], \\\"acme.midpoint.1\\\" : [\\\"O\\\"], \\\"acme.starttime.2\\\" : [\\\"F\\\"], \\\"acme.starts.2\\\" : [\\\"K\\\"], \\\"acme.meets.2\\\" : [\\\"F\\\"], \\\"acme.endtime.2\\\" : [\\\"H\\\"], \\\"acme.midpoint.2\\\" : [\\\"A\\\"], \\\"bigset.duration.1\\\" : [\\\"E\\\",\\\"G\\\"], \\\"bigset.duration+starts.1\\\" : [\\\"X\\\",\\\"O\\\"], \\\"bigset.duration+contained.1\\\" : [\\\"G\\\"], \\\"bigset.starttime+before+endtime+during.1\\\": [\\\"I\\\"], \\\"bigset.ends.1\\\" : [\\\"E\\\"], \\\"bigset.duration.2\\\" : [\\\"E\\\",\\\"G\\\"], \\\"bigset.duration+starts.2\\\" : [\\\"X\\\",\\\"O\\\"], \\\"bigset.duration+contained.2\\\" : [\\\"G\\\"], \\\"bigset.starttime+before+endtime+during.2\\\":[\\\"I\\\"], \\\"bigset.ends.2\\\" : [\\\"E\\\"], \\\"bigset.starttime.1\\\" : [\\\"M\\\",\\\"L\\\"], \\\"bigset.starts.1\\\" : [\\\"G\\\"], \\\"bigset.meets.1\\\" : [\\\"E\\\",\\\"F\\\"], \\\"bigset.endtime.1\\\" : [\\\"X\\\"], \\\"bigset.midpoint.1\\\" : [\\\"K\\\",\\\"X\\\"], \\\"bigset.starttime.2\\\" : [\\\"M\\\",\\\"L\\\"], \\\"bigset.starts.2\\\" : [\\\"G\\\"], \\\"bigset.meets.2\\\" : [\\\"E\\\",\\\"F\\\"], \\\"bigset.endtime.2\\\" : [\\\"X\\\"], \\\"bigset.midpoint.2\\\" : [\\\"K\\\",\\\"X\\\"] } var orthogonal_answers = { \\\"acme.starttime.1\\\" : [\\\"A\\\"], \\\"acme.starts.1\\\" : [\\\"E\\\"], \\\"acme.meets.1\\\" : [\\\"Z\\\"], \\\"acme.endtime.1\\\" : [\\\"U\\\"], \\\"acme.midpoint.1\\\" : [\\\"U\\\"], \\\"acme.starttime.2\\\" : [\\\"0\\\"], \\\"acme.starts.2\\\" : [\\\"0\\\"], \\\"acme.meets.2\\\" : [\\\"0\\\"], \\\"acme.endtime.2\\\" : [\\\"0\\\"], \\\"acme.midpoint.2\\\" : [\\\"0\\\"], \\\"bigset.duration.1\\\" : [\\\"E\\\",\\\"G\\\"], \\\"bigset.duration+starts.1\\\" : [\\\"F\\\",\\\"B\\\"], \\\"bigset.duration+contained.1\\\" : [\\\"E\\\"], \\\"bigset.starttime+before+endtime+during.1\\\": [\\\"I\\\"], \\\"bigset.ends.1\\\" : [\\\"X\\\"], \\\"bigset.duration.2\\\" : [\\\"E\\\",\\\"G\\\"], \\\"bigset.duration+starts.2\\\" : [\\\"F\\\",\\\"B\\\"], \\\"bigset.duration+contained.2\\\" : [\\\"E\\\"], \\\"bigset.starttime+before+endtime+during.2\\\":[\\\"I\\\"], \\\"bigset.ends.2\\\" : [\\\"X\\\"], \\\"bigset.starttime.1\\\" : [\\\"F\\\",\\\"B\\\"], \\\"bigset.starts.1\\\" : [\\\"B\\\"], \\\"bigset.meets.1\\\" : [\\\"F\\\",\\\"X\\\"], \\\"bigset.endtime.1\\\" : [\\\"B\\\"], \\\"bigset.midpoint.1\\\" : [\\\"E\\\",\\\"F\\\"], \\\"bigset.starttime.2\\\" : [\\\"F\\\",\\\"B\\\"], \\\"bigset.starts.2\\\" : [\\\"B\\\"], \\\"bigset.meets.2\\\" : [\\\"F\\\",\\\"X\\\"], \\\"bigset.endtime.2\\\" : [\\\"B\\\"], \\\"bigset.midpoint.2\\\" : [\\\"E\\\",\\\"F\\\"] } //display the question and answer buttons based on input values from jsPsych document.getElementById(scenario+\\\".\\\"+question).style.display = \\\"block\\\"; if (question == \\\"strategy\\\") {document.getElementById(\\\"strategyButton\\\").style.display = \\\"block\\\";} else {document.getElementById(\\\"testingButton\\\").style.display = \\\"block\\\";} //---------SET PROPERTIES OF THE GRAPH -------------// // set the dimensions and margins of the graph var margin = {top: 25, right: 30, bottom: 90, left: 100}, width = 800, height = 800; var intersects = false; //default value for intersects scaffold var xAxisTitle, yAxisTitle; var datafile =\\\"\\\"; // SET AXIS VALUES if (axis == 1){ axis = \\\"Orthogonal-XInside-YFull\\\"; } else if (axis == 2){ axis = \\\"Orthogonal-XInside-YPartial\\\"; } else if (axis ==3){ axis = \\\"Triangular-XInside-YInside\\\"; } else if (axis ==4){ axis = \\\"Orthogonal-XInside-YInside\\\"; } else if (axis ==5){ axis = \\\"Orthogonal-XFull-YFull\\\"; } // SET EXPLICIT SCAFFOLD FEATURES if (explicit ==2 && axis != \\\"diagonal\\\"){ scaffold = 2; intersects = false; } else if (explicit == 2 && axis == \\\"diagonal\\\"){ scaffold = 2; intersects = false; } //TODO: not sure if above two lines are still valid since leaders are now generated on the fly else if (explicit == 3){ $('#hint-interactive').css(\\\"display\\\",\\\"block\\\"); //display textimage scaffold intersects = true; } //SET DATA FILE FOR IMPLICIT SCAFFOLD if (impasse == 1){ datafile = \\\"../views/src/data/acme_nonimpasse.csv\\\"; } else if (impasse == 2){ datafile = \\\"../views/src/data/acme_impasse.csv\\\"; } //OVERRIDE DATA FILE FOR NON-SCAFFOLD QUESTIONS if (q > 5) { //override data file if q# is greater than 5 datafile = \\\"../views/src/data/bigset.csv\\\"; console.log(\\\"override data file\\\"); $('#orthogonal-image').css(\\\"display\\\",\\\"none\\\"); //display textimage scaffold $('#diagonal-image').css(\\\"display\\\",\\\"none\\\"); //display textimage scaffold $('#hint-interactive').css(\\\"display\\\",\\\"none\\\"); //display textimage scaffold intersects = false; } // //---------CREATE THE SVG ------------------------// var svg = d3.select(\\\".d3container\\\").append(\\\"svg\\\") .attr(\\\"width\\\", width + margin.left + margin.right) .attr(\\\"height\\\", height + margin.top + margin.bottom) .append(\\\"g\\\") .attr(\\\"transform\\\", \\\"translate(\\\" + margin.left + \\\",\\\" + margin.top + \\\")\\\"); //---------DRAW THE GRAPH ------------------------// xAxisTitle = \\\"START & END TIME (time of day)\\\"; yAxisTitle = \\\"DURATION (in hours)\\\"; drawTriangleModel(datafile,intersects,axis,scaffold,q); \"},{\"id\":2593},{\"id\":2594},{\"nodeType\":3,\"id\":2597,\"textContent\":\" //MOUSE LOGGING SCRIPT var mouseLog = [] var xwidth = $(document).width(); var xheight = $(document).width(); mouseLog.push(\\\"{x:\\\"+xwidth+\\\",y:\\\"+xheight+\\\",t:\\\"+\\\"0};\\\") document.onmousemove = function(e){ var pageCoords = \\\"{x:\\\" + e.pageX + \\\",y:\\\"+ e.pageY +\\\",t:\\\"+ Date.now()+ \\\"};\\\" ; mouseLog.push(pageCoords); // console.log(pageCoords); }; \"},{\"id\":2595}],[],[],[]]}"
    },
    {
      "sequence": 2,
      "data": "{\"f\":\"applyChanged\",\"args\":[[],[{\"nodeType\":1,\"id\":2598,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-text-preamble\",\"class\":\"jspsych-survey-text-preamble\"},\"parentNode\":{\"id\":55}},{\"nodeType\":1,\"id\":2599,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-text-0\",\"class\":\"jspsych-survey-text-question\"},\"previousSibling\":{\"id\":2598},\"parentNode\":{\"id\":55}},{\"nodeType\":1,\"id\":2600,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-text-1\",\"class\":\"jspsych-survey-text-question\"},\"previousSibling\":{\"id\":2599},\"parentNode\":{\"id\":55}},{\"nodeType\":1,\"id\":2601,\"tagName\":\"BUTTON\",\"attributes\":{\"id\":\"jspsych-survey-text-next\",\"class\":\"jspsych-btn jspsych-survey-text\"},\"previousSibling\":{\"id\":2600},\"parentNode\":{\"id\":55}},{\"nodeType\":1,\"id\":2602,\"tagName\":\"P\",\"attributes\":{\"class\":\"jspsych-survey-text\"},\"parentNode\":{\"id\":2599}},{\"nodeType\":1,\"id\":2603,\"tagName\":\"TEXTAREA\",\"attributes\":{\"name\":\"#jspsych-survey-text-response-0\",\"cols\":\"40\",\"rows\":\"1\"},\"previousSibling\":{\"id\":2602},\"parentNode\":{\"id\":2599}},{\"nodeType\":3,\"id\":2604,\"textContent\":\"What is your age?\",\"parentNode\":{\"id\":2602}},{\"nodeType\":1,\"id\":2605,\"tagName\":\"P\",\"attributes\":{\"class\":\"jspsych-survey-text\"},\"parentNode\":{\"id\":2600}},{\"nodeType\":1,\"id\":2606,\"tagName\":\"TEXTAREA\",\"attributes\":{\"name\":\"#jspsych-survey-text-response-1\",\"cols\":\"40\",\"rows\":\"1\"},\"previousSibling\":{\"id\":2605},\"parentNode\":{\"id\":2600}},{\"nodeType\":3,\"id\":2607,\"textContent\":\"In what country were you born?\",\"parentNode\":{\"id\":2605}},{\"nodeType\":3,\"id\":2608,\"textContent\":\"Submit Answers\",\"parentNode\":{\"id\":2601}}],[],[]]}"
    },
    {
      "sequence": 3,
      "data": "{\"f\":\"applyChanged\",\"args\":[[{\"id\":2598},{\"id\":2599},{\"id\":2602},{\"id\":2604},{\"id\":2603},{\"id\":2600},{\"id\":2605},{\"id\":2607},{\"id\":2606},{\"id\":2601},{\"id\":2608}],[],[],[]]}"
    },
    {
      "sequence": 4,
      "data": "{\"f\":\"applyChanged\",\"args\":[[],[{\"nodeType\":1,\"id\":2609,\"tagName\":\"FORM\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-form\"},\"parentNode\":{\"id\":55}},{\"nodeType\":1,\"id\":2610,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-preamble\",\"class\":\"jspsych-survey-multi-choice-preamble\"},\"parentNode\":{\"id\":2609}},{\"nodeType\":1,\"id\":2611,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-0\",\"class\":\"jspsych-survey-multi-choice-question jspsych-survey-multi-choice-horizontal\"},\"previousSibling\":{\"id\":2610},\"parentNode\":{\"id\":2609}},{\"nodeType\":1,\"id\":2612,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-1\",\"class\":\"jspsych-survey-multi-choice-question jspsych-survey-multi-choice-horizontal\"},\"previousSibling\":{\"id\":2611},\"parentNode\":{\"id\":2609}},{\"nodeType\":1,\"id\":2613,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-2\",\"class\":\"jspsych-survey-multi-choice-question jspsych-survey-multi-choice-horizontal\"},\"previousSibling\":{\"id\":2612},\"parentNode\":{\"id\":2609}},{\"nodeType\":1,\"id\":2614,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-3\",\"class\":\"jspsych-survey-multi-choice-question jspsych-survey-multi-choice-horizontal\"},\"previousSibling\":{\"id\":2613},\"parentNode\":{\"id\":2609}},{\"nodeType\":1,\"id\":2615,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"submit\",\"id\":\"jspsych-survey-multi-choice-next\",\"class\":\"jspsych-survey-multi-choice jspsych-btn\",\"value\":\"Submit Answers\"},\"previousSibling\":{\"id\":2614},\"parentNode\":{\"id\":2609}},{\"nodeType\":1,\"id\":2616,\"tagName\":\"P\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text survey-multi-choice\"},\"parentNode\":{\"id\":2611}},{\"nodeType\":1,\"id\":2617,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-0-0\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2616},\"parentNode\":{\"id\":2611}},{\"nodeType\":1,\"id\":2618,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-0-1\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2617},\"parentNode\":{\"id\":2611}},{\"nodeType\":1,\"id\":2619,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-0-2\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2618},\"parentNode\":{\"id\":2611}},{\"nodeType\":1,\"id\":2620,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-0-3\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2619},\"parentNode\":{\"id\":2611}},{\"nodeType\":3,\"id\":2621,\"textContent\":\"What is your first language?\",\"parentNode\":{\"id\":2616}},{\"nodeType\":1,\"id\":2622,\"tagName\":\"SPAN\",\"attributes\":{\"class\":\"required\"},\"previousSibling\":{\"id\":2621},\"parentNode\":{\"id\":2616}},{\"nodeType\":1,\"id\":2623,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2617}},{\"nodeType\":1,\"id\":2624,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-0\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2623}},{\"nodeType\":3,\"id\":2625,\"textContent\":\"English\",\"previousSibling\":{\"id\":2624},\"parentNode\":{\"id\":2623}},{\"nodeType\":1,\"id\":2626,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2618}},{\"nodeType\":1,\"id\":2627,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-0\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2626}},{\"nodeType\":3,\"id\":2628,\"textContent\":\"Spanish\",\"previousSibling\":{\"id\":2627},\"parentNode\":{\"id\":2626}},{\"nodeType\":1,\"id\":2629,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2619}},{\"nodeType\":1,\"id\":2630,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-0\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2629}},{\"nodeType\":3,\"id\":2631,\"textContent\":\"Mandarin or Cantonese\",\"previousSibling\":{\"id\":2630},\"parentNode\":{\"id\":2629}},{\"nodeType\":1,\"id\":2632,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2620}},{\"nodeType\":1,\"id\":2633,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-0\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2632}},{\"nodeType\":3,\"id\":2634,\"textContent\":\"Other\",\"previousSibling\":{\"id\":2633},\"parentNode\":{\"id\":2632}},{\"nodeType\":3,\"id\":2635,\"textContent\":\"*\",\"parentNode\":{\"id\":2622}},{\"nodeType\":1,\"id\":2636,\"tagName\":\"P\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text survey-multi-choice\"},\"parentNode\":{\"id\":2612}},{\"nodeType\":1,\"id\":2637,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-1-0\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2636},\"parentNode\":{\"id\":2612}},{\"nodeType\":1,\"id\":2638,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-1-1\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2637},\"parentNode\":{\"id\":2612}},{\"nodeType\":1,\"id\":2639,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-1-2\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2638},\"parentNode\":{\"id\":2612}},{\"nodeType\":1,\"id\":2640,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-1-3\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2639},\"parentNode\":{\"id\":2612}},{\"nodeType\":1,\"id\":2641,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-1-4\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2640},\"parentNode\":{\"id\":2612}},{\"nodeType\":1,\"id\":2642,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-1-5\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2641},\"parentNode\":{\"id\":2612}},{\"nodeType\":1,\"id\":2643,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-1-6\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2642},\"parentNode\":{\"id\":2612}},{\"nodeType\":3,\"id\":2644,\"textContent\":\"What is your year in school?\",\"parentNode\":{\"id\":2636}},{\"nodeType\":1,\"id\":2645,\"tagName\":\"SPAN\",\"attributes\":{\"class\":\"required\"},\"previousSibling\":{\"id\":2644},\"parentNode\":{\"id\":2636}},{\"nodeType\":1,\"id\":2646,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2637}},{\"nodeType\":1,\"id\":2647,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-1\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2646}},{\"nodeType\":3,\"id\":2648,\"textContent\":\"First\",\"previousSibling\":{\"id\":2647},\"parentNode\":{\"id\":2646}},{\"nodeType\":1,\"id\":2649,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2638}},{\"nodeType\":1,\"id\":2650,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-1\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2649}},{\"nodeType\":3,\"id\":2651,\"textContent\":\"Second\",\"previousSibling\":{\"id\":2650},\"parentNode\":{\"id\":2649}},{\"nodeType\":1,\"id\":2652,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2639}},{\"nodeType\":1,\"id\":2653,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-1\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2652}},{\"nodeType\":3,\"id\":2654,\"textContent\":\"Third\",\"previousSibling\":{\"id\":2653},\"parentNode\":{\"id\":2652}},{\"nodeType\":1,\"id\":2655,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2640}},{\"nodeType\":1,\"id\":2656,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-1\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2655}},{\"nodeType\":3,\"id\":2657,\"textContent\":\"Fourth\",\"previousSibling\":{\"id\":2656},\"parentNode\":{\"id\":2655}},{\"nodeType\":1,\"id\":2658,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2641}},{\"nodeType\":1,\"id\":2659,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-1\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2658}},{\"nodeType\":3,\"id\":2660,\"textContent\":\"Fifth\",\"previousSibling\":{\"id\":2659},\"parentNode\":{\"id\":2658}},{\"nodeType\":1,\"id\":2661,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2642}},{\"nodeType\":1,\"id\":2662,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-1\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2661}},{\"nodeType\":3,\"id\":2663,\"textContent\":\"Graduate\",\"previousSibling\":{\"id\":2662},\"parentNode\":{\"id\":2661}},{\"nodeType\":1,\"id\":2664,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2643}},{\"nodeType\":1,\"id\":2665,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-1\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2664}},{\"nodeType\":3,\"id\":2666,\"textContent\":\"Other\",\"previousSibling\":{\"id\":2665},\"parentNode\":{\"id\":2664}},{\"nodeType\":3,\"id\":2667,\"textContent\":\"*\",\"parentNode\":{\"id\":2645}},{\"nodeType\":1,\"id\":2668,\"tagName\":\"P\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text survey-multi-choice\"},\"parentNode\":{\"id\":2613}},{\"nodeType\":1,\"id\":2669,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-2-0\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2668},\"parentNode\":{\"id\":2613}},{\"nodeType\":1,\"id\":2670,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-2-1\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2669},\"parentNode\":{\"id\":2613}},{\"nodeType\":1,\"id\":2671,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-2-2\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2670},\"parentNode\":{\"id\":2613}},{\"nodeType\":1,\"id\":2672,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-2-3\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2671},\"parentNode\":{\"id\":2613}},{\"nodeType\":1,\"id\":2673,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-2-4\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2672},\"parentNode\":{\"id\":2613}},{\"nodeType\":1,\"id\":2674,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-2-5\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2673},\"parentNode\":{\"id\":2613}},{\"nodeType\":1,\"id\":2675,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-2-6\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2674},\"parentNode\":{\"id\":2613}},{\"nodeType\":3,\"id\":2676,\"textContent\":\"What is your major area of study?\",\"parentNode\":{\"id\":2668}},{\"nodeType\":1,\"id\":2677,\"tagName\":\"SPAN\",\"attributes\":{\"class\":\"required\"},\"previousSibling\":{\"id\":2676},\"parentNode\":{\"id\":2668}},{\"nodeType\":1,\"id\":2678,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2669}},{\"nodeType\":1,\"id\":2679,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-2\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2678}},{\"nodeType\":3,\"id\":2680,\"textContent\":\"Math or Computer Sciences\",\"previousSibling\":{\"id\":2679},\"parentNode\":{\"id\":2678}},{\"nodeType\":1,\"id\":2681,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2670}},{\"nodeType\":1,\"id\":2682,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-2\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2681}},{\"nodeType\":3,\"id\":2683,\"textContent\":\"Social Sciences (incl. CogSci)\",\"previousSibling\":{\"id\":2682},\"parentNode\":{\"id\":2681}},{\"nodeType\":1,\"id\":2684,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2671}},{\"nodeType\":1,\"id\":2685,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-2\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2684}},{\"nodeType\":3,\"id\":2686,\"textContent\":\"Biomedical & Health Sciences\",\"previousSibling\":{\"id\":2685},\"parentNode\":{\"id\":2684}},{\"nodeType\":1,\"id\":2687,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2672}},{\"nodeType\":1,\"id\":2688,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-2\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2687}},{\"nodeType\":3,\"id\":2689,\"textContent\":\"Natural Sciences\",\"previousSibling\":{\"id\":2688},\"parentNode\":{\"id\":2687}},{\"nodeType\":1,\"id\":2690,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2673}},{\"nodeType\":1,\"id\":2691,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-2\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2690}},{\"nodeType\":3,\"id\":2692,\"textContent\":\"Engineering\",\"previousSibling\":{\"id\":2691},\"parentNode\":{\"id\":2690}},{\"nodeType\":1,\"id\":2693,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2674}},{\"nodeType\":1,\"id\":2694,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-2\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2693}},{\"nodeType\":3,\"id\":2695,\"textContent\":\"Humanities\",\"previousSibling\":{\"id\":2694},\"parentNode\":{\"id\":2693}},{\"nodeType\":1,\"id\":2696,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2675}},{\"nodeType\":1,\"id\":2697,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-2\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2696}},{\"nodeType\":3,\"id\":2698,\"textContent\":\"Fine Arts\",\"previousSibling\":{\"id\":2697},\"parentNode\":{\"id\":2696}},{\"nodeType\":3,\"id\":2699,\"textContent\":\"*\",\"parentNode\":{\"id\":2677}},{\"nodeType\":1,\"id\":2700,\"tagName\":\"P\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text survey-multi-choice\"},\"parentNode\":{\"id\":2614}},{\"nodeType\":1,\"id\":2701,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-3-0\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2700},\"parentNode\":{\"id\":2614}},{\"nodeType\":1,\"id\":2702,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-3-1\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2701},\"parentNode\":{\"id\":2614}},{\"nodeType\":1,\"id\":2703,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-3-2\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2702},\"parentNode\":{\"id\":2614}},{\"nodeType\":3,\"id\":2704,\"textContent\":\"What is your gender?\",\"parentNode\":{\"id\":2700}},{\"nodeType\":1,\"id\":2705,\"tagName\":\"SPAN\",\"attributes\":{\"class\":\"required\"},\"previousSibling\":{\"id\":2704},\"parentNode\":{\"id\":2700}},{\"nodeType\":1,\"id\":2706,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2701}},{\"nodeType\":1,\"id\":2707,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-3\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2706}},{\"nodeType\":3,\"id\":2708,\"textContent\":\"Male\",\"previousSibling\":{\"id\":2707},\"parentNode\":{\"id\":2706}},{\"nodeType\":1,\"id\":2709,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2702}},{\"nodeType\":1,\"id\":2710,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-3\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2709}},{\"nodeType\":3,\"id\":2711,\"textContent\":\"Female\",\"previousSibling\":{\"id\":2710},\"parentNode\":{\"id\":2709}},{\"nodeType\":1,\"id\":2712,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2703}},{\"nodeType\":1,\"id\":2713,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-3\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2712}},{\"nodeType\":3,\"id\":2714,\"textContent\":\"Other\",\"previousSibling\":{\"id\":2713},\"parentNode\":{\"id\":2712}},{\"nodeType\":3,\"id\":2715,\"textContent\":\"*\",\"parentNode\":{\"id\":2705}}],[],[]]}"
    },
    {
      "sequence": 5,
      "data": "{\"f\":\"applyChanged\",\"args\":[[{\"id\":2609},{\"id\":2610},{\"id\":2611},{\"id\":2616},{\"id\":2621},{\"id\":2622},{\"id\":2635},{\"id\":2617},{\"id\":2623},{\"id\":2624},{\"id\":2625},{\"id\":2618},{\"id\":2626},{\"id\":2627},{\"id\":2628},{\"id\":2619},{\"id\":2629},{\"id\":2630},{\"id\":2631},{\"id\":2620},{\"id\":2632},{\"id\":2633},{\"id\":2634},{\"id\":2612},{\"id\":2636},{\"id\":2644},{\"id\":2645},{\"id\":2667},{\"id\":2637},{\"id\":2646},{\"id\":2647},{\"id\":2648},{\"id\":2638},{\"id\":2649},{\"id\":2650},{\"id\":2651},{\"id\":2639},{\"id\":2652},{\"id\":2653},{\"id\":2654},{\"id\":2640},{\"id\":2655},{\"id\":2656},{\"id\":2657},{\"id\":2641},{\"id\":2658},{\"id\":2659},{\"id\":2660},{\"id\":2642},{\"id\":2661},{\"id\":2662},{\"id\":2663},{\"id\":2643},{\"id\":2664},{\"id\":2665},{\"id\":2666},{\"id\":2613},{\"id\":2668},{\"id\":2676},{\"id\":2677},{\"id\":2699},{\"id\":2669},{\"id\":2678},{\"id\":2679},{\"id\":2680},{\"id\":2670},{\"id\":2681},{\"id\":2682},{\"id\":2683},{\"id\":2671},{\"id\":2684},{\"id\":2685},{\"id\":2686},{\"id\":2672},{\"id\":2687},{\"id\":2688},{\"id\":2689},{\"id\":2673},{\"id\":2690},{\"id\":2691},{\"id\":2692},{\"id\":2674},{\"id\":2693},{\"id\":2694},{\"id\":2695},{\"id\":2675},{\"id\":2696},{\"id\":2697},{\"id\":2698},{\"id\":2614},{\"id\":2700},{\"id\":2704},{\"id\":2705},{\"id\":2715},{\"id\":2701},{\"id\":2706},{\"id\":2707},{\"id\":2708},{\"id\":2702},{\"id\":2709},{\"id\":2710},{\"id\":2711},{\"id\":2703},{\"id\":2712},{\"id\":2713},{\"id\":2714},{\"id\":2615}],[],[],[]]}"
    },
    {
      "sequence": 6,
      "data": "{\"f\":\"applyChanged\",\"args\":[[],[{\"nodeType\":1,\"id\":2716,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"masterdiv\"},\"parentNode\":{\"id\":55}},{\"nodeType\":3,\"id\":2717,\"textContent\":\" \",\"previousSibling\":{\"id\":2716},\"parentNode\":{\"id\":55}},{\"nodeType\":3,\"id\":2718,\"textContent\":\" \",\"parentNode\":{\"id\":2716}},{\"nodeType\":1,\"id\":2719,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"top\"},\"previousSibling\":{\"id\":2718},\"parentNode\":{\"id\":2716}},{\"nodeType\":3,\"id\":2720,\"textContent\":\" \",\"previousSibling\":{\"id\":2719},\"parentNode\":{\"id\":2716}},{\"nodeType\":1,\"id\":2721,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"instructions\"},\"previousSibling\":{\"id\":2720},\"parentNode\":{\"id\":2716}},{\"nodeType\":3,\"id\":2722,\"textContent\":\" \",\"previousSibling\":{\"id\":2721},\"parentNode\":{\"id\":2716}},{\"nodeType\":1,\"id\":2723,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bottom\"},\"previousSibling\":{\"id\":2722},\"parentNode\":{\"id\":2716}},{\"nodeType\":3,\"id\":2724,\"textContent\":\" \",\"previousSibling\":{\"id\":2723},\"parentNode\":{\"id\":2716}},{\"nodeType\":3,\"id\":2725,\"textContent\":\" \",\"parentNode\":{\"id\":2719}},{\"nodeType\":1,\"id\":2726,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bcent\"},\"previousSibling\":{\"id\":2725},\"parentNode\":{\"id\":2719}},{\"nodeType\":3,\"id\":2727,\"textContent\":\" \",\"previousSibling\":{\"id\":2726},\"parentNode\":{\"id\":2719}},{\"nodeType\":3,\"id\":2728,\"textContent\":\" \",\"parentNode\":{\"id\":2726}},{\"nodeType\":1,\"id\":2729,\"tagName\":\"H3\",\"attributes\":{},\"previousSibling\":{\"id\":2728},\"parentNode\":{\"id\":2726}},{\"nodeType\":3,\"id\":2730,\"textContent\":\" \",\"previousSibling\":{\"id\":2729},\"parentNode\":{\"id\":2726}},{\"nodeType\":3,\"id\":2731,\"textContent\":\"DEBRIEFING\",\"parentNode\":{\"id\":2729}},{\"nodeType\":3,\"id\":2732,\"textContent\":\" \",\"parentNode\":{\"id\":2721}},{\"nodeType\":1,\"id\":2733,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"vcent\"},\"previousSibling\":{\"id\":2732},\"parentNode\":{\"id\":2721}},{\"nodeType\":3,\"id\":2734,\"textContent\":\" \",\"previousSibling\":{\"id\":2733},\"parentNode\":{\"id\":2721}},{\"nodeType\":3,\"id\":2735,\"textContent\":\" \",\"parentNode\":{\"id\":2733}},{\"nodeType\":1,\"id\":2736,\"tagName\":\"P\",\"attributes\":{\"style\":\"font-style:italic\"},\"previousSibling\":{\"id\":2735},\"parentNode\":{\"id\":2733}},{\"nodeType\":1,\"id\":2737,\"tagName\":\"P\",\"attributes\":{},\"previousSibling\":{\"id\":2736},\"parentNode\":{\"id\":2733}},{\"nodeType\":3,\"id\":2738,\"textContent\":\" \",\"previousSibling\":{\"id\":2737},\"parentNode\":{\"id\":2733}},{\"nodeType\":1,\"id\":2739,\"tagName\":\"P\",\"attributes\":{},\"previousSibling\":{\"id\":2738},\"parentNode\":{\"id\":2733}},{\"nodeType\":3,\"id\":2740,\"textContent\":\" \",\"previousSibling\":{\"id\":2739},\"parentNode\":{\"id\":2733}},{\"nodeType\":1,\"id\":2741,\"tagName\":\"P\",\"attributes\":{},\"previousSibling\":{\"id\":2740},\"parentNode\":{\"id\":2733}},{\"nodeType\":3,\"id\":2742,\"textContent\":\" \",\"previousSibling\":{\"id\":2741},\"parentNode\":{\"id\":2733}},{\"nodeType\":1,\"id\":2743,\"tagName\":\"P\",\"attributes\":{\"style\":\"font-style:bold;\"},\"previousSibling\":{\"id\":2742},\"parentNode\":{\"id\":2733}},{\"nodeType\":3,\"id\":2744,\"textContent\":\" \",\"previousSibling\":{\"id\":2743},\"parentNode\":{\"id\":2733}},{\"nodeType\":1,\"id\":2745,\"tagName\":\"P\",\"attributes\":{\"style\":\"font-style:italic;\"},\"previousSibling\":{\"id\":2744},\"parentNode\":{\"id\":2733}},{\"nodeType\":3,\"id\":2746,\"textContent\":\" \",\"previousSibling\":{\"id\":2745},\"parentNode\":{\"id\":2733}},{\"nodeType\":3,\"id\":2747,\"textContent\":\"Thank you very much for your participation! This debriefing will tell you more about the study, what you did, and why. \",\"parentNode\":{\"id\":2736}},{\"nodeType\":3,\"id\":2748,\"textContent\":\" \",\"parentNode\":{\"id\":2737}},{\"nodeType\":1,\"id\":2749,\"tagName\":\"B\",\"attributes\":{},\"previousSibling\":{\"id\":2748},\"parentNode\":{\"id\":2737}},{\"nodeType\":3,\"id\":2750,\"textContent\":\" You have just used a series of pictures (charts, graphs and diagrams) accompanied by different types of instructions to answer a series of problem solving questions. While you were using the pictures, we measured where you clicked, scrolled and pointed with the computer mouse. We also measured the accuracy of your responses and the time it took to complete each question.\",\"previousSibling\":{\"id\":2749},\"parentNode\":{\"id\":2737}},{\"nodeType\":3,\"id\":2751,\"textContent\":\"What did you just do?\",\"parentNode\":{\"id\":2749}},{\"nodeType\":3,\"id\":2752,\"textContent\":\" \",\"parentNode\":{\"id\":2739}},{\"nodeType\":1,\"id\":2753,\"tagName\":\"B\",\"attributes\":{},\"previousSibling\":{\"id\":2752},\"parentNode\":{\"id\":2739}},{\"nodeType\":3,\"id\":2754,\"textContent\":\" Researchers of learning and cognition have long been interested in how graphic displays of information can be used to communicate, solve problems, and generate insights. As powerful as graphics may be in their communicative efficiency, they're not always immediately intuitive to understand. In short, we know a great deal more about learning with representations than we do about the learning of representations. In this project we are building upon previous research on reading and graph comprehension to explore how readers make sense of unfamiliar representations. The instructions you saw for each type of graph are known as “scaffolding techniques”, and we will compare your performance with the scaffolding techniques you saw with the performance of other participants to determine which types of instructions are most effective in helping humans to make sense of unfamiliar graphs. \",\"previousSibling\":{\"id\":2753},\"parentNode\":{\"id\":2739}},{\"nodeType\":3,\"id\":2755,\"textContent\":\"Why did we have you do it?\",\"parentNode\":{\"id\":2753}},{\"nodeType\":1,\"id\":2756,\"tagName\":\"B\",\"attributes\":{},\"parentNode\":{\"id\":2741}},{\"nodeType\":3,\"id\":2757,\"textContent\":\" We expect that you will have found some of the graphics more difficult to use than others. We also expect that with the assistance of the instructions, after solving several problems you will learn to use the difficult graphics so that you can answer the questions even more quickly than without. If you would like to receive a copy of the results of the study, or have any further questions, please contact the researchers Primary Researcher: Amy Fox : a2fox@ucsd.edu Faculty Advisor : Dr. Jim Hollan : hollan@ucsd.edu \",\"previousSibling\":{\"id\":2756},\"parentNode\":{\"id\":2741}},{\"nodeType\":3,\"id\":2758,\"textContent\":\"What do we expect to find?\",\"parentNode\":{\"id\":2756}},{\"nodeType\":3,\"id\":2759,\"textContent\":\"It is important that you do not discuss this experiment with other students who might participate after you. They must participate in the same way as you did, without any knowledge of what the experiment entails, or the reasoning behind it.\",\"parentNode\":{\"id\":2743}},{\"nodeType\":3,\"id\":2760,\"textContent\":\"Thank you for your time! We hope you enjoyed participating in this study as much as we enjoyed designing it.\",\"parentNode\":{\"id\":2745}},{\"nodeType\":3,\"id\":2761,\"textContent\":\" \",\"parentNode\":{\"id\":2723}},{\"nodeType\":1,\"id\":2762,\"tagName\":\"BUTTON\",\"attributes\":{\"class\":\"btn\",\"type\":\"button\",\"id\":\"start\"},\"previousSibling\":{\"id\":2761},\"parentNode\":{\"id\":2723}},{\"nodeType\":3,\"id\":2763,\"textContent\":\" \",\"previousSibling\":{\"id\":2762},\"parentNode\":{\"id\":2723}},{\"nodeType\":3,\"id\":2764,\"textContent\":\"FINISH\",\"parentNode\":{\"id\":2762}}],[],[]]}"
    },
    {
      "sequence": 7,
      "data": "{\"f\":\"applyChanged\",\"args\":[[{\"id\":2716},{\"id\":2718},{\"id\":2719},{\"id\":2725},{\"id\":2726},{\"id\":2728},{\"id\":2729},{\"id\":2731},{\"id\":2730},{\"id\":2727},{\"id\":2720},{\"id\":2721},{\"id\":2732},{\"id\":2733},{\"id\":2735},{\"id\":2736},{\"id\":2747},{\"id\":2737},{\"id\":2748},{\"id\":2749},{\"id\":2751},{\"id\":2750},{\"id\":2738},{\"id\":2739},{\"id\":2752},{\"id\":2753},{\"id\":2755},{\"id\":2754},{\"id\":2740},{\"id\":2741},{\"id\":2756},{\"id\":2758},{\"id\":2757},{\"id\":2742},{\"id\":2743},{\"id\":2759},{\"id\":2744},{\"id\":2745},{\"id\":2760},{\"id\":2746},{\"id\":2734},{\"id\":2722},{\"id\":2723},{\"id\":2761},{\"id\":2762},{\"id\":2764},{\"id\":2763},{\"id\":2724},{\"id\":2717}],[],[],[]]}"
    },
    {
      "sequence": 8,
      "data": "{\"f\":\"applyChanged\",\"args\":[[],[{\"nodeType\":1,\"id\":2765,\"tagName\":\"PRE\",\"attributes\":{\"id\":\"jspsych-data-display\"},\"parentNode\":{\"id\":55}},{\"nodeType\":3,\"id\":2766,\"textContent\":\"[ { \\\"rt\\\": 11460, \\\"stimulus\\\": \\\"img/phone.png\\\", \\\"key_press\\\": 32, \\\"block\\\": \\\"phone\\\", \\\"trial_type\\\": \\\"single-stim\\\", \\\"trial_index\\\": 0, \\\"time_elapsed\\\": 11463, \\\"internal_node_id\\\": \\\"0.0-0.0\\\", \\\"subject\\\": \\\"GQ35Z\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"charlie\\\", \\\"condition\\\": \\\"111\\\" }, { \\\"rt\\\": 134062, \\\"url\\\": \\\"../views/src/external/consent.html\\\", \\\"block\\\": \\\"consent\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 1, \\\"time_elapsed\\\": 146614, \\\"internal_node_id\\\": \\\"0.0-1.0\\\", \\\"subject\\\": \\\"GQ35Z\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"charlie\\\", \\\"condition\\\": \\\"111\\\" }, { \\\"rt\\\": 29036, \\\"responses\\\": \\\"{\\\\\\\"Q0\\\\\\\":\\\\\\\"CHARLIE\\\\\\\",\\\\\\\"Q1\\\\\\\":\\\\\\\"111\\\\\\\"}\\\", \\\"block\\\": \\\"codes\\\", \\\"trial_type\\\": \\\"survey-text\\\", \\\"trial_index\\\": 2, \\\"time_elapsed\\\": 176657, \\\"internal_node_id\\\": \\\"0.0-2.0\\\", \\\"subject\\\": \\\"GQ35Z\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"charlie\\\", \\\"condition\\\": \\\"111\\\" }, { \\\"rt\\\": 23553, \\\"url\\\": \\\"../views/src/external/instructions_lab.html\\\", \\\"block\\\": \\\"instructions_lab\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 3, \\\"time_elapsed\\\": 201547, \\\"internal_node_id\\\": \\\"0.0-3.0\\\", \\\"subject\\\": \\\"GQ35Z\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"charlie\\\", \\\"condition\\\": \\\"111\\\" }, { \\\"rt\\\": 9575, \\\"stimulus\\\": \\\"img/acme.png\\\", \\\"key_press\\\": 32, \\\"block\\\": \\\"scenario\\\", \\\"trial_type\\\": \\\"single-stim\\\", \\\"trial_index\\\": 4, \\\"time_elapsed\\\": 212125, \\\"internal_node_id\\\": \\\"0.0-4.0\\\", \\\"subject\\\": \\\"GQ35Z\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"charlie\\\", \\\"condition\\\": \\\"111\\\" }, { \\\"rt\\\": 70990, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 5, \\\"time_elapsed\\\": 284485, \\\"internal_node_id\\\": \\\"0.0-5.0-0.0\\\", \\\"subject\\\": \\\"GQ35Z\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"charlie\\\", \\\"condition\\\": \\\"111\\\", \\\"scenario\\\": \\\"acme\\\", \\\"question\\\": \\\"starttime\\\", \\\"q\\\": 1, \\\"clicks\\\": 6, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XInside-YFull\\\", \\\"correct\\\": 1, \\\"orth_correct\\\": 0, \\\"answer\\\": [ \\\"F\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"X \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"U \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-12 PM-11 AM-A -A -A -A -C -C -08 AM-09 AM-10 AM-11 AM-11 AM-11 AM-F \\\", \\\"block\\\": \\\"triangular_scaffolded\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:722,y:892,t:1526929864393};\\\", \\\"{x:720,y:893,t:1526929864408};\\\", \\\"{x:720,y:894,t:1526929864420};\\\", \\\"{x:719,y:894,t:1526929864447};\\\", \\\"{x:718,y:896,t:1526929864464};\\\", \\\"{x:717,y:898,t:1526929864472};\\\", \\\"{x:713,y:900,t:1526929864488};\\\", \\\"{x:713,y:901,t:1526929864504};\\\", \\\"{x:717,y:901,t:1526929865159};\\\", \\\"{x:724,y:901,t:1526929865170};\\\", \\\"{x:736,y:900,t:1526929865186};\\\", \\\"{x:750,y:898,t:1526929865204};\\\", \\\"{x:769,y:895,t:1526929865221};\\\", \\\"{x:785,y:892,t:1526929865237};\\\", \\\"{x:801,y:889,t:1526929865254};\\\", \\\"{x:827,y:885,t:1526929865271};\\\", \\\"{x:840,y:882,t:1526929865288};\\\", \\\"{x:856,y:877,t:1526929865304};\\\", \\\"{x:871,y:874,t:1526929865321};\\\", \\\"{x:884,y:870,t:1526929865337};\\\", \\\"{x:899,y:868,t:1526929865354};\\\", \\\"{x:912,y:865,t:1526929865371};\\\", \\\"{x:920,y:865,t:1526929865387};\\\", \\\"{x:926,y:865,t:1526929865404};\\\", \\\"{x:931,y:864,t:1526929865422};\\\", \\\"{x:933,y:864,t:1526929865438};\\\", \\\"{x:932,y:864,t:1526929865600};\\\", \\\"{x:928,y:864,t:1526929865607};\\\", \\\"{x:926,y:864,t:1526929865621};\\\", \\\"{x:925,y:864,t:1526929865637};\\\", \\\"{x:925,y:863,t:1526929866048};\\\", \\\"{x:925,y:861,t:1526929866063};\\\", \\\"{x:925,y:859,t:1526929867616};\\\", \\\"{x:929,y:857,t:1526929867623};\\\", \\\"{x:945,y:857,t:1526929867640};\\\", \\\"{x:963,y:857,t:1526929867656};\\\", \\\"{x:985,y:859,t:1526929867673};\\\", \\\"{x:1018,y:863,t:1526929867690};\\\", \\\"{x:1030,y:869,t:1526929867706};\\\", \\\"{x:1035,y:872,t:1526929867723};\\\", \\\"{x:1062,y:876,t:1526929867740};\\\", \\\"{x:1077,y:880,t:1526929867757};\\\", \\\"{x:1094,y:883,t:1526929867773};\\\", \\\"{x:1104,y:884,t:1526929867790};\\\", \\\"{x:1110,y:884,t:1526929867807};\\\", \\\"{x:1115,y:884,t:1526929867824};\\\", \\\"{x:1121,y:885,t:1526929867840};\\\", \\\"{x:1129,y:888,t:1526929867856};\\\", \\\"{x:1138,y:890,t:1526929867872};\\\", \\\"{x:1141,y:893,t:1526929867890};\\\", \\\"{x:1149,y:898,t:1526929867907};\\\", \\\"{x:1158,y:902,t:1526929867923};\\\", \\\"{x:1171,y:907,t:1526929867940};\\\", \\\"{x:1186,y:912,t:1526929867956};\\\", \\\"{x:1204,y:919,t:1526929867972};\\\", \\\"{x:1220,y:923,t:1526929867989};\\\", \\\"{x:1240,y:932,t:1526929868006};\\\", \\\"{x:1256,y:943,t:1526929868023};\\\", \\\"{x:1272,y:950,t:1526929868039};\\\", \\\"{x:1289,y:959,t:1526929868056};\\\", \\\"{x:1312,y:967,t:1526929868073};\\\", \\\"{x:1337,y:981,t:1526929868089};\\\", \\\"{x:1357,y:990,t:1526929868106};\\\", \\\"{x:1371,y:998,t:1526929868123};\\\", \\\"{x:1379,y:1001,t:1526929868139};\\\", \\\"{x:1382,y:1003,t:1526929868156};\\\", \\\"{x:1383,y:1004,t:1526929868173};\\\", \\\"{x:1383,y:1008,t:1526929868190};\\\", \\\"{x:1389,y:1012,t:1526929868206};\\\", \\\"{x:1389,y:1013,t:1526929868657};\\\", \\\"{x:1389,y:1014,t:1526929868673};\\\", \\\"{x:1386,y:1011,t:1526929869912};\\\", \\\"{x:1386,y:1008,t:1526929869925};\\\", \\\"{x:1386,y:1007,t:1526929870011};\\\", \\\"{x:1386,y:1006,t:1526929870046};\\\", \\\"{x:1385,y:1003,t:1526929870200};\\\", \\\"{x:1385,y:998,t:1526929870208};\\\", \\\"{x:1384,y:989,t:1526929870224};\\\", \\\"{x:1380,y:980,t:1526929870241};\\\", \\\"{x:1376,y:968,t:1526929870258};\\\", \\\"{x:1375,y:960,t:1526929870275};\\\", \\\"{x:1373,y:951,t:1526929870291};\\\", \\\"{x:1371,y:945,t:1526929870308};\\\", \\\"{x:1370,y:941,t:1526929870325};\\\", \\\"{x:1368,y:935,t:1526929870341};\\\", \\\"{x:1368,y:932,t:1526929870357};\\\", \\\"{x:1367,y:928,t:1526929870374};\\\", \\\"{x:1364,y:923,t:1526929870390};\\\", \\\"{x:1364,y:922,t:1526929870408};\\\", \\\"{x:1363,y:921,t:1526929870424};\\\", \\\"{x:1362,y:918,t:1526929870441};\\\", \\\"{x:1361,y:916,t:1526929870470};\\\", \\\"{x:1360,y:916,t:1526929870478};\\\", \\\"{x:1360,y:915,t:1526929870502};\\\", \\\"{x:1360,y:914,t:1526929870510};\\\", \\\"{x:1359,y:912,t:1526929870567};\\\", \\\"{x:1358,y:912,t:1526929870583};\\\", \\\"{x:1357,y:911,t:1526929870598};\\\", \\\"{x:1357,y:910,t:1526929870631};\\\", \\\"{x:1355,y:909,t:1526929870641};\\\", \\\"{x:1354,y:908,t:1526929870662};\\\", \\\"{x:1353,y:908,t:1526929870686};\\\", \\\"{x:1352,y:907,t:1526929870703};\\\", \\\"{x:1351,y:906,t:1526929870711};\\\", \\\"{x:1350,y:906,t:1526929870743};\\\", \\\"{x:1349,y:906,t:1526929870774};\\\", \\\"{x:1348,y:906,t:1526929870832};\\\", \\\"{x:1346,y:905,t:1526929870848};\\\", \\\"{x:1345,y:905,t:1526929870912};\\\", \\\"{x:1344,y:905,t:1526929870976};\\\", \\\"{x:1343,y:905,t:1526929871016};\\\", \\\"{x:1342,y:905,t:1526929871055};\\\", \\\"{x:1341,y:905,t:1526929871063};\\\", \\\"{x:1340,y:905,t:1526929871088};\\\", \\\"{x:1339,y:906,t:1526929871096};\\\", \\\"{x:1338,y:906,t:1526929871111};\\\", \\\"{x:1337,y:906,t:1526929871126};\\\", \\\"{x:1336,y:907,t:1526929871142};\\\", \\\"{x:1334,y:907,t:1526929871159};\\\", \\\"{x:1330,y:908,t:1526929871176};\\\", \\\"{x:1329,y:908,t:1526929871224};\\\", \\\"{x:1327,y:909,t:1526929871239};\\\", \\\"{x:1325,y:910,t:1526929871272};\\\", \\\"{x:1324,y:910,t:1526929871288};\\\", \\\"{x:1322,y:910,t:1526929871296};\\\", \\\"{x:1320,y:910,t:1526929871309};\\\", \\\"{x:1313,y:912,t:1526929871325};\\\", \\\"{x:1308,y:914,t:1526929871342};\\\", \\\"{x:1296,y:918,t:1526929871358};\\\", \\\"{x:1270,y:927,t:1526929871375};\\\", \\\"{x:1265,y:931,t:1526929871392};\\\", \\\"{x:1254,y:935,t:1526929871408};\\\", \\\"{x:1244,y:940,t:1526929871425};\\\", \\\"{x:1243,y:941,t:1526929871442};\\\", \\\"{x:1241,y:944,t:1526929871458};\\\", \\\"{x:1237,y:945,t:1526929871475};\\\", \\\"{x:1233,y:948,t:1526929871493};\\\", \\\"{x:1233,y:949,t:1526929871508};\\\", \\\"{x:1230,y:951,t:1526929871525};\\\", \\\"{x:1230,y:952,t:1526929871543};\\\", \\\"{x:1230,y:953,t:1526929871559};\\\", \\\"{x:1230,y:954,t:1526929871575};\\\", \\\"{x:1230,y:955,t:1526929871600};\\\", \\\"{x:1230,y:957,t:1526929871609};\\\", \\\"{x:1231,y:958,t:1526929871625};\\\", \\\"{x:1234,y:958,t:1526929871643};\\\", \\\"{x:1235,y:958,t:1526929871659};\\\", \\\"{x:1238,y:959,t:1526929871675};\\\", \\\"{x:1238,y:960,t:1526929871693};\\\", \\\"{x:1239,y:960,t:1526929871712};\\\", \\\"{x:1241,y:960,t:1526929871726};\\\", \\\"{x:1243,y:961,t:1526929871832};\\\", \\\"{x:1243,y:962,t:1526929871843};\\\", \\\"{x:1245,y:964,t:1526929871860};\\\", \\\"{x:1248,y:967,t:1526929871876};\\\", \\\"{x:1249,y:970,t:1526929871893};\\\", \\\"{x:1254,y:979,t:1526929871911};\\\", \\\"{x:1256,y:984,t:1526929871926};\\\", \\\"{x:1257,y:985,t:1526929871942};\\\", \\\"{x:1258,y:985,t:1526929871984};\\\", \\\"{x:1259,y:986,t:1526929871993};\\\", \\\"{x:1261,y:986,t:1526929872015};\\\", \\\"{x:1262,y:986,t:1526929872025};\\\", \\\"{x:1263,y:986,t:1526929872042};\\\", \\\"{x:1266,y:986,t:1526929872059};\\\", \\\"{x:1267,y:985,t:1526929872075};\\\", \\\"{x:1269,y:985,t:1526929872126};\\\", \\\"{x:1270,y:984,t:1526929872142};\\\", \\\"{x:1270,y:983,t:1526929872159};\\\", \\\"{x:1271,y:983,t:1526929872183};\\\", \\\"{x:1272,y:982,t:1526929872199};\\\", \\\"{x:1273,y:981,t:1526929872209};\\\", \\\"{x:1274,y:980,t:1526929872226};\\\", \\\"{x:1275,y:980,t:1526929872532};\\\", \\\"{x:1276,y:980,t:1526929872556};\\\", \\\"{x:1276,y:979,t:1526929872563};\\\", \\\"{x:1276,y:978,t:1526929872581};\\\", \\\"{x:1276,y:977,t:1526929872597};\\\", \\\"{x:1277,y:976,t:1526929872627};\\\", \\\"{x:1277,y:975,t:1526929872644};\\\", \\\"{x:1277,y:974,t:1526929872668};\\\", \\\"{x:1278,y:974,t:1526929872684};\\\", \\\"{x:1278,y:973,t:1526929872940};\\\", \\\"{x:1279,y:972,t:1526929872956};\\\", \\\"{x:1279,y:971,t:1526929872964};\\\", \\\"{x:1279,y:967,t:1526929872982};\\\", \\\"{x:1279,y:966,t:1526929872998};\\\", \\\"{x:1279,y:965,t:1526929873028};\\\", \\\"{x:1279,y:963,t:1526929873724};\\\", \\\"{x:1279,y:962,t:1526929873732};\\\", \\\"{x:1279,y:959,t:1526929873748};\\\", \\\"{x:1279,y:957,t:1526929873766};\\\", \\\"{x:1280,y:955,t:1526929873782};\\\", \\\"{x:1281,y:952,t:1526929873798};\\\", \\\"{x:1282,y:948,t:1526929873815};\\\", \\\"{x:1283,y:945,t:1526929873832};\\\", \\\"{x:1284,y:939,t:1526929873848};\\\", \\\"{x:1285,y:933,t:1526929873865};\\\", \\\"{x:1285,y:931,t:1526929873882};\\\", \\\"{x:1286,y:925,t:1526929873898};\\\", \\\"{x:1288,y:915,t:1526929873916};\\\", \\\"{x:1289,y:910,t:1526929873932};\\\", \\\"{x:1290,y:902,t:1526929873948};\\\", \\\"{x:1290,y:894,t:1526929873965};\\\", \\\"{x:1290,y:887,t:1526929873982};\\\", \\\"{x:1290,y:883,t:1526929873998};\\\", \\\"{x:1290,y:877,t:1526929874015};\\\", \\\"{x:1290,y:871,t:1526929874032};\\\", \\\"{x:1290,y:865,t:1526929874048};\\\", \\\"{x:1290,y:857,t:1526929874066};\\\", \\\"{x:1289,y:854,t:1526929874083};\\\", \\\"{x:1288,y:851,t:1526929874099};\\\", \\\"{x:1286,y:849,t:1526929874116};\\\", \\\"{x:1286,y:848,t:1526929874132};\\\", \\\"{x:1285,y:847,t:1526929874149};\\\", \\\"{x:1285,y:846,t:1526929874165};\\\", \\\"{x:1285,y:844,t:1526929874183};\\\", \\\"{x:1284,y:841,t:1526929874199};\\\", \\\"{x:1284,y:838,t:1526929874215};\\\", \\\"{x:1283,y:836,t:1526929874232};\\\", \\\"{x:1283,y:835,t:1526929874252};\\\", \\\"{x:1282,y:834,t:1526929874264};\\\", \\\"{x:1282,y:832,t:1526929874339};\\\", \\\"{x:1282,y:830,t:1526929882236};\\\", \\\"{x:1282,y:829,t:1526929882243};\\\", \\\"{x:1282,y:828,t:1526929882267};\\\", \\\"{x:1282,y:827,t:1526929882284};\\\", \\\"{x:1282,y:826,t:1526929882291};\\\", \\\"{x:1282,y:825,t:1526929882315};\\\", \\\"{x:1283,y:825,t:1526929882356};\\\", \\\"{x:1284,y:824,t:1526929882372};\\\", \\\"{x:1284,y:822,t:1526929882396};\\\", \\\"{x:1285,y:821,t:1526929882669};\\\", \\\"{x:1286,y:820,t:1526929882708};\\\", \\\"{x:1286,y:819,t:1526929882721};\\\", \\\"{x:1287,y:818,t:1526929882739};\\\", \\\"{x:1287,y:816,t:1526929882756};\\\", \\\"{x:1289,y:814,t:1526929882771};\\\", \\\"{x:1289,y:813,t:1526929882803};\\\", \\\"{x:1290,y:812,t:1526929882956};\\\", \\\"{x:1290,y:810,t:1526929882972};\\\", \\\"{x:1291,y:809,t:1526929882989};\\\", \\\"{x:1292,y:809,t:1526929883006};\\\", \\\"{x:1292,y:807,t:1526929883028};\\\", \\\"{x:1293,y:805,t:1526929883051};\\\", \\\"{x:1294,y:804,t:1526929883076};\\\", \\\"{x:1294,y:803,t:1526929883091};\\\", \\\"{x:1294,y:801,t:1526929883124};\\\", \\\"{x:1295,y:799,t:1526929883139};\\\", \\\"{x:1296,y:799,t:1526929883155};\\\", \\\"{x:1296,y:797,t:1526929883173};\\\", \\\"{x:1297,y:796,t:1526929883188};\\\", \\\"{x:1298,y:794,t:1526929883205};\\\", \\\"{x:1299,y:793,t:1526929883222};\\\", \\\"{x:1299,y:790,t:1526929883238};\\\", \\\"{x:1300,y:790,t:1526929883255};\\\", \\\"{x:1301,y:788,t:1526929883272};\\\", \\\"{x:1302,y:787,t:1526929883288};\\\", \\\"{x:1303,y:786,t:1526929883305};\\\", \\\"{x:1303,y:784,t:1526929883322};\\\", \\\"{x:1304,y:783,t:1526929883338};\\\", \\\"{x:1305,y:782,t:1526929883356};\\\", \\\"{x:1305,y:781,t:1526929883372};\\\", \\\"{x:1306,y:781,t:1526929883389};\\\", \\\"{x:1306,y:779,t:1526929883406};\\\", \\\"{x:1306,y:778,t:1526929883422};\\\", \\\"{x:1307,y:776,t:1526929883438};\\\", \\\"{x:1309,y:774,t:1526929883456};\\\", \\\"{x:1311,y:772,t:1526929883473};\\\", \\\"{x:1311,y:770,t:1526929883492};\\\", \\\"{x:1312,y:770,t:1526929883508};\\\", \\\"{x:1312,y:769,t:1526929883524};\\\", \\\"{x:1313,y:768,t:1526929883540};\\\", \\\"{x:1313,y:766,t:1526929883555};\\\", \\\"{x:1314,y:765,t:1526929883572};\\\", \\\"{x:1314,y:764,t:1526929883590};\\\", \\\"{x:1316,y:763,t:1526929883606};\\\", \\\"{x:1316,y:761,t:1526929883623};\\\", \\\"{x:1317,y:761,t:1526929883640};\\\", \\\"{x:1317,y:759,t:1526929883656};\\\", \\\"{x:1318,y:759,t:1526929883673};\\\", \\\"{x:1319,y:756,t:1526929883690};\\\", \\\"{x:1319,y:755,t:1526929883724};\\\", \\\"{x:1320,y:755,t:1526929883763};\\\", \\\"{x:1318,y:755,t:1526929883891};\\\", \\\"{x:1316,y:756,t:1526929883905};\\\", \\\"{x:1315,y:757,t:1526929883922};\\\", \\\"{x:1312,y:758,t:1526929883939};\\\", \\\"{x:1312,y:759,t:1526929883964};\\\", \\\"{x:1312,y:762,t:1526929883973};\\\", \\\"{x:1311,y:763,t:1526929883990};\\\", \\\"{x:1309,y:768,t:1526929884006};\\\", \\\"{x:1309,y:770,t:1526929884023};\\\", \\\"{x:1306,y:774,t:1526929884039};\\\", \\\"{x:1304,y:779,t:1526929884056};\\\", \\\"{x:1303,y:779,t:1526929884073};\\\", \\\"{x:1303,y:780,t:1526929884089};\\\", \\\"{x:1303,y:781,t:1526929884106};\\\", \\\"{x:1302,y:784,t:1526929884122};\\\", \\\"{x:1302,y:787,t:1526929884139};\\\", \\\"{x:1299,y:791,t:1526929884156};\\\", \\\"{x:1299,y:793,t:1526929884173};\\\", \\\"{x:1299,y:795,t:1526929884190};\\\", \\\"{x:1299,y:796,t:1526929884207};\\\", \\\"{x:1298,y:797,t:1526929884222};\\\", \\\"{x:1297,y:799,t:1526929884260};\\\", \\\"{x:1296,y:800,t:1526929884284};\\\", \\\"{x:1296,y:801,t:1526929884291};\\\", \\\"{x:1296,y:802,t:1526929884307};\\\", \\\"{x:1295,y:803,t:1526929884324};\\\", \\\"{x:1294,y:804,t:1526929884356};\\\", \\\"{x:1293,y:805,t:1526929884379};\\\", \\\"{x:1293,y:806,t:1526929884428};\\\", \\\"{x:1291,y:806,t:1526929884492};\\\", \\\"{x:1291,y:807,t:1526929884980};\\\", \\\"{x:1290,y:807,t:1526929887460};\\\", \\\"{x:1276,y:807,t:1526929887476};\\\", \\\"{x:1249,y:807,t:1526929887492};\\\", \\\"{x:1216,y:801,t:1526929887509};\\\", \\\"{x:1147,y:793,t:1526929887525};\\\", \\\"{x:1071,y:777,t:1526929887542};\\\", \\\"{x:966,y:765,t:1526929887558};\\\", \\\"{x:850,y:750,t:1526929887576};\\\", \\\"{x:739,y:736,t:1526929887591};\\\", \\\"{x:602,y:726,t:1526929887608};\\\", \\\"{x:477,y:707,t:1526929887627};\\\", \\\"{x:371,y:689,t:1526929887642};\\\", \\\"{x:274,y:677,t:1526929887658};\\\", \\\"{x:170,y:661,t:1526929887676};\\\", \\\"{x:142,y:659,t:1526929887693};\\\", \\\"{x:127,y:656,t:1526929887710};\\\", \\\"{x:123,y:655,t:1526929887726};\\\", \\\"{x:120,y:655,t:1526929887742};\\\", \\\"{x:119,y:654,t:1526929887760};\\\", \\\"{x:118,y:654,t:1526929887777};\\\", \\\"{x:116,y:652,t:1526929887795};\\\", \\\"{x:115,y:649,t:1526929887812};\\\", \\\"{x:112,y:643,t:1526929887826};\\\", \\\"{x:110,y:635,t:1526929887844};\\\", \\\"{x:106,y:621,t:1526929887860};\\\", \\\"{x:105,y:615,t:1526929887877};\\\", \\\"{x:105,y:609,t:1526929887894};\\\", \\\"{x:106,y:603,t:1526929887910};\\\", \\\"{x:110,y:599,t:1526929887927};\\\", \\\"{x:118,y:592,t:1526929887943};\\\", \\\"{x:126,y:588,t:1526929887959};\\\", \\\"{x:137,y:583,t:1526929887977};\\\", \\\"{x:148,y:577,t:1526929887993};\\\", \\\"{x:156,y:572,t:1526929888010};\\\", \\\"{x:174,y:564,t:1526929888026};\\\", \\\"{x:185,y:559,t:1526929888043};\\\", \\\"{x:195,y:556,t:1526929888060};\\\", \\\"{x:202,y:554,t:1526929888077};\\\", \\\"{x:214,y:552,t:1526929888093};\\\", \\\"{x:226,y:550,t:1526929888110};\\\", \\\"{x:240,y:549,t:1526929888127};\\\", \\\"{x:249,y:548,t:1526929888144};\\\", \\\"{x:259,y:547,t:1526929888160};\\\", \\\"{x:273,y:545,t:1526929888178};\\\", \\\"{x:286,y:545,t:1526929888194};\\\", \\\"{x:295,y:544,t:1526929888209};\\\", \\\"{x:296,y:544,t:1526929888227};\\\", \\\"{x:298,y:544,t:1526929888299};\\\", \\\"{x:299,y:544,t:1526929888331};\\\", \\\"{x:300,y:544,t:1526929888343};\\\", \\\"{x:305,y:544,t:1526929888360};\\\", \\\"{x:310,y:544,t:1526929888377};\\\", \\\"{x:324,y:542,t:1526929888393};\\\", \\\"{x:339,y:540,t:1526929888410};\\\", \\\"{x:360,y:538,t:1526929888426};\\\", \\\"{x:375,y:534,t:1526929888445};\\\", \\\"{x:383,y:533,t:1526929888461};\\\", \\\"{x:391,y:532,t:1526929888477};\\\", \\\"{x:396,y:532,t:1526929888494};\\\", \\\"{x:395,y:532,t:1526929888660};\\\", \\\"{x:392,y:531,t:1526929888669};\\\", \\\"{x:388,y:530,t:1526929888678};\\\", \\\"{x:386,y:530,t:1526929888694};\\\", \\\"{x:385,y:530,t:1526929888711};\\\", \\\"{x:385,y:529,t:1526929888995};\\\", \\\"{x:385,y:530,t:1526929889115};\\\", \\\"{x:385,y:531,t:1526929889128};\\\", \\\"{x:385,y:533,t:1526929889145};\\\", \\\"{x:385,y:535,t:1526929889161};\\\", \\\"{x:385,y:540,t:1526929889179};\\\", \\\"{x:385,y:542,t:1526929889195};\\\", \\\"{x:385,y:545,t:1526929889212};\\\", \\\"{x:385,y:547,t:1526929889228};\\\", \\\"{x:385,y:550,t:1526929889244};\\\", \\\"{x:385,y:552,t:1526929889261};\\\", \\\"{x:385,y:554,t:1526929889278};\\\", \\\"{x:385,y:558,t:1526929889294};\\\", \\\"{x:385,y:560,t:1526929889310};\\\", \\\"{x:385,y:562,t:1526929889328};\\\", \\\"{x:385,y:564,t:1526929889344};\\\", \\\"{x:385,y:566,t:1526929889360};\\\", \\\"{x:385,y:567,t:1526929889378};\\\", \\\"{x:385,y:566,t:1526929889562};\\\", \\\"{x:385,y:565,t:1526929889578};\\\", \\\"{x:385,y:563,t:1526929889594};\\\", \\\"{x:387,y:562,t:1526929889611};\\\", \\\"{x:388,y:560,t:1526929889628};\\\", \\\"{x:389,y:560,t:1526929889645};\\\", \\\"{x:391,y:557,t:1526929889661};\\\", \\\"{x:391,y:555,t:1526929889678};\\\", \\\"{x:392,y:554,t:1526929889695};\\\", \\\"{x:394,y:552,t:1526929889712};\\\", \\\"{x:394,y:548,t:1526929889729};\\\", \\\"{x:395,y:546,t:1526929889746};\\\", \\\"{x:395,y:543,t:1526929889761};\\\", \\\"{x:395,y:540,t:1526929889778};\\\", \\\"{x:395,y:536,t:1526929889795};\\\", \\\"{x:395,y:535,t:1526929889818};\\\", \\\"{x:395,y:534,t:1526929889827};\\\", \\\"{x:393,y:534,t:1526929889915};\\\", \\\"{x:391,y:534,t:1526929889928};\\\", \\\"{x:389,y:534,t:1526929889945};\\\", \\\"{x:386,y:536,t:1526929889962};\\\", \\\"{x:385,y:541,t:1526929889979};\\\", \\\"{x:382,y:548,t:1526929889995};\\\", \\\"{x:381,y:553,t:1526929890012};\\\", \\\"{x:380,y:556,t:1526929890027};\\\", \\\"{x:379,y:557,t:1526929890045};\\\", \\\"{x:378,y:559,t:1526929890062};\\\", \\\"{x:378,y:560,t:1526929890078};\\\", \\\"{x:377,y:560,t:1526929890354};\\\", \\\"{x:377,y:558,t:1526929890362};\\\", \\\"{x:378,y:556,t:1526929890378};\\\", \\\"{x:379,y:552,t:1526929890395};\\\", \\\"{x:379,y:550,t:1526929890412};\\\", \\\"{x:379,y:549,t:1526929890429};\\\", \\\"{x:379,y:548,t:1526929890450};\\\", \\\"{x:379,y:546,t:1526929890462};\\\", \\\"{x:379,y:545,t:1526929890491};\\\", \\\"{x:379,y:544,t:1526929890507};\\\", \\\"{x:379,y:543,t:1526929890523};\\\", \\\"{x:379,y:542,t:1526929890531};\\\", \\\"{x:379,y:541,t:1526929890563};\\\", \\\"{x:379,y:540,t:1526929890580};\\\", \\\"{x:379,y:539,t:1526929890603};\\\", \\\"{x:379,y:538,t:1526929890613};\\\", \\\"{x:379,y:537,t:1526929890630};\\\", \\\"{x:379,y:536,t:1526929890647};\\\", \\\"{x:379,y:535,t:1526929890675};\\\", \\\"{x:379,y:534,t:1526929890732};\\\", \\\"{x:380,y:534,t:1526929891860};\\\", \\\"{x:384,y:536,t:1526929891867};\\\", \\\"{x:386,y:536,t:1526929891880};\\\", \\\"{x:392,y:540,t:1526929891898};\\\", \\\"{x:401,y:543,t:1526929891913};\\\", \\\"{x:417,y:549,t:1526929891932};\\\", \\\"{x:444,y:560,t:1526929891946};\\\", \\\"{x:469,y:566,t:1526929891963};\\\", \\\"{x:492,y:576,t:1526929891980};\\\", \\\"{x:521,y:585,t:1526929891996};\\\", \\\"{x:549,y:595,t:1526929892012};\\\", \\\"{x:576,y:602,t:1526929892030};\\\", \\\"{x:580,y:605,t:1526929892047};\\\", \\\"{x:600,y:614,t:1526929892063};\\\", \\\"{x:625,y:628,t:1526929892081};\\\", \\\"{x:661,y:643,t:1526929892097};\\\", \\\"{x:706,y:664,t:1526929892114};\\\", \\\"{x:730,y:676,t:1526929892130};\\\", \\\"{x:770,y:689,t:1526929892147};\\\", \\\"{x:811,y:697,t:1526929892163};\\\", \\\"{x:834,y:701,t:1526929892179};\\\", \\\"{x:858,y:700,t:1526929892197};\\\", \\\"{x:874,y:700,t:1526929892213};\\\", \\\"{x:892,y:702,t:1526929892230};\\\", \\\"{x:906,y:706,t:1526929892247};\\\", \\\"{x:919,y:708,t:1526929892264};\\\", \\\"{x:929,y:711,t:1526929892281};\\\", \\\"{x:940,y:716,t:1526929892297};\\\", \\\"{x:950,y:718,t:1526929892314};\\\", \\\"{x:966,y:724,t:1526929892330};\\\", \\\"{x:997,y:738,t:1526929892348};\\\", \\\"{x:1019,y:750,t:1526929892363};\\\", \\\"{x:1042,y:766,t:1526929892380};\\\", \\\"{x:1064,y:780,t:1526929892399};\\\", \\\"{x:1085,y:790,t:1526929892413};\\\", \\\"{x:1103,y:802,t:1526929892429};\\\", \\\"{x:1117,y:809,t:1526929892447};\\\", \\\"{x:1130,y:819,t:1526929892463};\\\", \\\"{x:1150,y:829,t:1526929892480};\\\", \\\"{x:1162,y:835,t:1526929892497};\\\", \\\"{x:1178,y:841,t:1526929892513};\\\", \\\"{x:1194,y:848,t:1526929892530};\\\", \\\"{x:1212,y:856,t:1526929892547};\\\", \\\"{x:1224,y:863,t:1526929892563};\\\", \\\"{x:1234,y:869,t:1526929892580};\\\", \\\"{x:1242,y:874,t:1526929892598};\\\", \\\"{x:1250,y:882,t:1526929892613};\\\", \\\"{x:1253,y:884,t:1526929892630};\\\", \\\"{x:1253,y:885,t:1526929892648};\\\", \\\"{x:1258,y:889,t:1526929892663};\\\", \\\"{x:1260,y:895,t:1526929892681};\\\", \\\"{x:1264,y:904,t:1526929892697};\\\", \\\"{x:1267,y:910,t:1526929892714};\\\", \\\"{x:1268,y:912,t:1526929892731};\\\", \\\"{x:1268,y:914,t:1526929892748};\\\", \\\"{x:1270,y:916,t:1526929892765};\\\", \\\"{x:1270,y:920,t:1526929892781};\\\", \\\"{x:1275,y:923,t:1526929892798};\\\", \\\"{x:1275,y:928,t:1526929892814};\\\", \\\"{x:1276,y:929,t:1526929892831};\\\", \\\"{x:1276,y:930,t:1526929892900};\\\", \\\"{x:1276,y:931,t:1526929892914};\\\", \\\"{x:1278,y:933,t:1526929892932};\\\", \\\"{x:1278,y:934,t:1526929892955};\\\", \\\"{x:1278,y:935,t:1526929892971};\\\", \\\"{x:1278,y:936,t:1526929892996};\\\", \\\"{x:1278,y:937,t:1526929893004};\\\", \\\"{x:1279,y:938,t:1526929893015};\\\", \\\"{x:1280,y:940,t:1526929893031};\\\", \\\"{x:1281,y:942,t:1526929893048};\\\", \\\"{x:1281,y:944,t:1526929893065};\\\", \\\"{x:1281,y:945,t:1526929893080};\\\", \\\"{x:1281,y:946,t:1526929893124};\\\", \\\"{x:1281,y:947,t:1526929893131};\\\", \\\"{x:1281,y:948,t:1526929893148};\\\", \\\"{x:1281,y:949,t:1526929893165};\\\", \\\"{x:1283,y:951,t:1526929893181};\\\", \\\"{x:1283,y:953,t:1526929893219};\\\", \\\"{x:1284,y:954,t:1526929893291};\\\", \\\"{x:1284,y:953,t:1526929893370};\\\", \\\"{x:1284,y:951,t:1526929893380};\\\", \\\"{x:1284,y:948,t:1526929893397};\\\", \\\"{x:1284,y:947,t:1526929893414};\\\", \\\"{x:1284,y:945,t:1526929893430};\\\", \\\"{x:1283,y:944,t:1526929893447};\\\", \\\"{x:1283,y:943,t:1526929893490};\\\", \\\"{x:1283,y:942,t:1526929893498};\\\", \\\"{x:1283,y:941,t:1526929893515};\\\", \\\"{x:1283,y:939,t:1526929893530};\\\", \\\"{x:1283,y:936,t:1526929893547};\\\", \\\"{x:1283,y:931,t:1526929893564};\\\", \\\"{x:1283,y:923,t:1526929893580};\\\", \\\"{x:1280,y:913,t:1526929893598};\\\", \\\"{x:1279,y:904,t:1526929893615};\\\", \\\"{x:1279,y:897,t:1526929893631};\\\", \\\"{x:1279,y:894,t:1526929893648};\\\", \\\"{x:1279,y:890,t:1526929893665};\\\", \\\"{x:1279,y:889,t:1526929893680};\\\", \\\"{x:1279,y:888,t:1526929893697};\\\", \\\"{x:1279,y:885,t:1526929893714};\\\", \\\"{x:1279,y:883,t:1526929893730};\\\", \\\"{x:1279,y:880,t:1526929893747};\\\", \\\"{x:1279,y:877,t:1526929893764};\\\", \\\"{x:1279,y:876,t:1526929893786};\\\", \\\"{x:1279,y:875,t:1526929893811};\\\", \\\"{x:1279,y:874,t:1526929893819};\\\", \\\"{x:1279,y:873,t:1526929893835};\\\", \\\"{x:1279,y:871,t:1526929893852};\\\", \\\"{x:1279,y:870,t:1526929893867};\\\", \\\"{x:1279,y:869,t:1526929893881};\\\", \\\"{x:1279,y:868,t:1526929893898};\\\", \\\"{x:1279,y:867,t:1526929893916};\\\", \\\"{x:1279,y:865,t:1526929893948};\\\", \\\"{x:1280,y:864,t:1526929893965};\\\", \\\"{x:1280,y:860,t:1526929893982};\\\", \\\"{x:1280,y:857,t:1526929893998};\\\", \\\"{x:1281,y:852,t:1526929894015};\\\", \\\"{x:1281,y:850,t:1526929894032};\\\", \\\"{x:1281,y:846,t:1526929894048};\\\", \\\"{x:1281,y:844,t:1526929894065};\\\", \\\"{x:1281,y:839,t:1526929894082};\\\", \\\"{x:1281,y:836,t:1526929894098};\\\", \\\"{x:1281,y:832,t:1526929894117};\\\", \\\"{x:1282,y:829,t:1526929894148};\\\", \\\"{x:1283,y:828,t:1526929894764};\\\", \\\"{x:1285,y:828,t:1526929894781};\\\", \\\"{x:1287,y:830,t:1526929894798};\\\", \\\"{x:1290,y:835,t:1526929894815};\\\", \\\"{x:1290,y:838,t:1526929894832};\\\", \\\"{x:1290,y:849,t:1526929894847};\\\", \\\"{x:1285,y:857,t:1526929894865};\\\", \\\"{x:1283,y:864,t:1526929894882};\\\", \\\"{x:1281,y:873,t:1526929894898};\\\", \\\"{x:1280,y:882,t:1526929894917};\\\", \\\"{x:1279,y:888,t:1526929894931};\\\", \\\"{x:1278,y:893,t:1526929894948};\\\", \\\"{x:1277,y:900,t:1526929894965};\\\", \\\"{x:1276,y:902,t:1526929894981};\\\", \\\"{x:1275,y:908,t:1526929894998};\\\", \\\"{x:1275,y:916,t:1526929895014};\\\", \\\"{x:1275,y:923,t:1526929895032};\\\", \\\"{x:1275,y:926,t:1526929895048};\\\", \\\"{x:1275,y:929,t:1526929895064};\\\", \\\"{x:1275,y:930,t:1526929895083};\\\", \\\"{x:1275,y:931,t:1526929895140};\\\", \\\"{x:1275,y:933,t:1526929895149};\\\", \\\"{x:1275,y:936,t:1526929895165};\\\", \\\"{x:1276,y:937,t:1526929895181};\\\", \\\"{x:1277,y:938,t:1526929895268};\\\", \\\"{x:1279,y:938,t:1526929895500};\\\", \\\"{x:1280,y:938,t:1526929895517};\\\", \\\"{x:1282,y:937,t:1526929895532};\\\", \\\"{x:1282,y:935,t:1526929895604};\\\", \\\"{x:1282,y:934,t:1526929895716};\\\", \\\"{x:1282,y:933,t:1526929895731};\\\", \\\"{x:1282,y:932,t:1526929895748};\\\", \\\"{x:1283,y:931,t:1526929895812};\\\", \\\"{x:1283,y:930,t:1526929895844};\\\", \\\"{x:1283,y:929,t:1526929895851};\\\", \\\"{x:1283,y:928,t:1526929895868};\\\", \\\"{x:1283,y:927,t:1526929895892};\\\", \\\"{x:1283,y:925,t:1526929895900};\\\", \\\"{x:1283,y:924,t:1526929895964};\\\", \\\"{x:1283,y:923,t:1526929895981};\\\", \\\"{x:1283,y:922,t:1526929896036};\\\", \\\"{x:1283,y:921,t:1526929896068};\\\", \\\"{x:1283,y:919,t:1526929896404};\\\", \\\"{x:1282,y:919,t:1526929896430};\\\", \\\"{x:1282,y:918,t:1526929896442};\\\", \\\"{x:1282,y:917,t:1526929896466};\\\", \\\"{x:1281,y:916,t:1526929896481};\\\", \\\"{x:1280,y:915,t:1526929897652};\\\", \\\"{x:1278,y:914,t:1526929898428};\\\", \\\"{x:1277,y:914,t:1526929898468};\\\", \\\"{x:1277,y:913,t:1526929901932};\\\", \\\"{x:1277,y:910,t:1526929901947};\\\", \\\"{x:1277,y:909,t:1526929901955};\\\", \\\"{x:1277,y:908,t:1526929901967};\\\", \\\"{x:1277,y:906,t:1526929901984};\\\", \\\"{x:1277,y:903,t:1526929902000};\\\", \\\"{x:1275,y:899,t:1526929902017};\\\", \\\"{x:1274,y:898,t:1526929902034};\\\", \\\"{x:1274,y:894,t:1526929902051};\\\", \\\"{x:1274,y:892,t:1526929902066};\\\", \\\"{x:1274,y:889,t:1526929902083};\\\", \\\"{x:1274,y:886,t:1526929902100};\\\", \\\"{x:1274,y:883,t:1526929902116};\\\", \\\"{x:1274,y:877,t:1526929902133};\\\", \\\"{x:1274,y:875,t:1526929902151};\\\", \\\"{x:1274,y:872,t:1526929902166};\\\", \\\"{x:1274,y:870,t:1526929902186};\\\", \\\"{x:1274,y:869,t:1526929902200};\\\", \\\"{x:1274,y:867,t:1526929902217};\\\", \\\"{x:1274,y:866,t:1526929902233};\\\", \\\"{x:1274,y:862,t:1526929902250};\\\", \\\"{x:1273,y:860,t:1526929902266};\\\", \\\"{x:1273,y:859,t:1526929902291};\\\", \\\"{x:1273,y:857,t:1526929902307};\\\", \\\"{x:1273,y:856,t:1526929902380};\\\", \\\"{x:1273,y:854,t:1526929902388};\\\", \\\"{x:1273,y:853,t:1526929902401};\\\", \\\"{x:1273,y:851,t:1526929902417};\\\", \\\"{x:1273,y:850,t:1526929902507};\\\", \\\"{x:1273,y:848,t:1526929902532};\\\", \\\"{x:1273,y:847,t:1526929902564};\\\", \\\"{x:1273,y:845,t:1526929902636};\\\", \\\"{x:1273,y:844,t:1526929902651};\\\", \\\"{x:1274,y:844,t:1526929902691};\\\", \\\"{x:1275,y:843,t:1526929902716};\\\", \\\"{x:1277,y:842,t:1526929902747};\\\", \\\"{x:1278,y:841,t:1526929902755};\\\", \\\"{x:1278,y:840,t:1526929902804};\\\", \\\"{x:1279,y:840,t:1526929902819};\\\", \\\"{x:1280,y:839,t:1526929902851};\\\", \\\"{x:1280,y:838,t:1526929902948};\\\", \\\"{x:1280,y:837,t:1526929903060};\\\", \\\"{x:1280,y:835,t:1526929903083};\\\", \\\"{x:1280,y:834,t:1526929903101};\\\", \\\"{x:1281,y:832,t:1526929903118};\\\", \\\"{x:1281,y:831,t:1526929903155};\\\", \\\"{x:1280,y:831,t:1526929903891};\\\", \\\"{x:1279,y:831,t:1526929903907};\\\", \\\"{x:1278,y:832,t:1526929903918};\\\", \\\"{x:1278,y:833,t:1526929903934};\\\", \\\"{x:1278,y:835,t:1526929903952};\\\", \\\"{x:1278,y:838,t:1526929903968};\\\", \\\"{x:1278,y:843,t:1526929903984};\\\", \\\"{x:1277,y:846,t:1526929904001};\\\", \\\"{x:1277,y:850,t:1526929904018};\\\", \\\"{x:1277,y:854,t:1526929904034};\\\", \\\"{x:1277,y:860,t:1526929904051};\\\", \\\"{x:1277,y:864,t:1526929904067};\\\", \\\"{x:1277,y:868,t:1526929904084};\\\", \\\"{x:1276,y:874,t:1526929904101};\\\", \\\"{x:1276,y:881,t:1526929904118};\\\", \\\"{x:1276,y:889,t:1526929904134};\\\", \\\"{x:1276,y:897,t:1526929904151};\\\", \\\"{x:1276,y:902,t:1526929904168};\\\", \\\"{x:1276,y:909,t:1526929904184};\\\", \\\"{x:1276,y:915,t:1526929904201};\\\", \\\"{x:1277,y:916,t:1526929904218};\\\", \\\"{x:1277,y:918,t:1526929904235};\\\", \\\"{x:1277,y:921,t:1526929904251};\\\", \\\"{x:1279,y:926,t:1526929904268};\\\", \\\"{x:1281,y:927,t:1526929904284};\\\", \\\"{x:1282,y:929,t:1526929904301};\\\", \\\"{x:1282,y:931,t:1526929904371};\\\", \\\"{x:1283,y:932,t:1526929904403};\\\", \\\"{x:1283,y:934,t:1526929904427};\\\", \\\"{x:1283,y:935,t:1526929904468};\\\", \\\"{x:1283,y:937,t:1526929904508};\\\", \\\"{x:1284,y:938,t:1526929904523};\\\", \\\"{x:1284,y:939,t:1526929904739};\\\", \\\"{x:1284,y:941,t:1526929904884};\\\", \\\"{x:1284,y:942,t:1526929904899};\\\", \\\"{x:1284,y:943,t:1526929904915};\\\", \\\"{x:1284,y:945,t:1526929904940};\\\", \\\"{x:1284,y:947,t:1526929904951};\\\", \\\"{x:1284,y:949,t:1526929904968};\\\", \\\"{x:1284,y:951,t:1526929904986};\\\", \\\"{x:1284,y:952,t:1526929905004};\\\", \\\"{x:1284,y:953,t:1526929905060};\\\", \\\"{x:1284,y:954,t:1526929905084};\\\", \\\"{x:1284,y:955,t:1526929905252};\\\", \\\"{x:1285,y:957,t:1526929905283};\\\", \\\"{x:1286,y:957,t:1526929905348};\\\", \\\"{x:1285,y:957,t:1526929908211};\\\", \\\"{x:1284,y:953,t:1526929908227};\\\", \\\"{x:1283,y:951,t:1526929908236};\\\", \\\"{x:1282,y:946,t:1526929908252};\\\", \\\"{x:1282,y:937,t:1526929908269};\\\", \\\"{x:1282,y:928,t:1526929908286};\\\", \\\"{x:1281,y:920,t:1526929908302};\\\", \\\"{x:1279,y:911,t:1526929908319};\\\", \\\"{x:1274,y:900,t:1526929908336};\\\", \\\"{x:1271,y:887,t:1526929908352};\\\", \\\"{x:1269,y:881,t:1526929908369};\\\", \\\"{x:1269,y:875,t:1526929908386};\\\", \\\"{x:1269,y:870,t:1526929908403};\\\", \\\"{x:1269,y:862,t:1526929908419};\\\", \\\"{x:1269,y:857,t:1526929908437};\\\", \\\"{x:1268,y:852,t:1526929908453};\\\", \\\"{x:1267,y:850,t:1526929908469};\\\", \\\"{x:1267,y:848,t:1526929908723};\\\", \\\"{x:1268,y:845,t:1526929908737};\\\", \\\"{x:1270,y:844,t:1526929908752};\\\", \\\"{x:1272,y:841,t:1526929908769};\\\", \\\"{x:1272,y:840,t:1526929909220};\\\", \\\"{x:1272,y:842,t:1526929909236};\\\", \\\"{x:1271,y:844,t:1526929909253};\\\", \\\"{x:1269,y:848,t:1526929909270};\\\", \\\"{x:1268,y:849,t:1526929909286};\\\", \\\"{x:1267,y:851,t:1526929909303};\\\", \\\"{x:1265,y:854,t:1526929909319};\\\", \\\"{x:1264,y:856,t:1526929909336};\\\", \\\"{x:1263,y:859,t:1526929909354};\\\", \\\"{x:1261,y:862,t:1526929909370};\\\", \\\"{x:1260,y:863,t:1526929909386};\\\", \\\"{x:1259,y:863,t:1526929909403};\\\", \\\"{x:1258,y:864,t:1526929909419};\\\", \\\"{x:1258,y:865,t:1526929909437};\\\", \\\"{x:1256,y:865,t:1526929909467};\\\", \\\"{x:1256,y:866,t:1526929909491};\\\", \\\"{x:1255,y:866,t:1526929909503};\\\", \\\"{x:1255,y:867,t:1526929909519};\\\", \\\"{x:1255,y:868,t:1526929909537};\\\", \\\"{x:1253,y:872,t:1526929909553};\\\", \\\"{x:1253,y:873,t:1526929909569};\\\", \\\"{x:1252,y:875,t:1526929909586};\\\", \\\"{x:1251,y:877,t:1526929909603};\\\", \\\"{x:1250,y:880,t:1526929909620};\\\", \\\"{x:1249,y:881,t:1526929909636};\\\", \\\"{x:1249,y:883,t:1526929909653};\\\", \\\"{x:1248,y:887,t:1526929909669};\\\", \\\"{x:1246,y:889,t:1526929909686};\\\", \\\"{x:1246,y:892,t:1526929909703};\\\", \\\"{x:1245,y:896,t:1526929909719};\\\", \\\"{x:1242,y:900,t:1526929909736};\\\", \\\"{x:1242,y:904,t:1526929909754};\\\", \\\"{x:1241,y:908,t:1526929909769};\\\", \\\"{x:1241,y:910,t:1526929909787};\\\", \\\"{x:1239,y:914,t:1526929909803};\\\", \\\"{x:1238,y:916,t:1526929909819};\\\", \\\"{x:1238,y:920,t:1526929909837};\\\", \\\"{x:1237,y:927,t:1526929909854};\\\", \\\"{x:1235,y:935,t:1526929909869};\\\", \\\"{x:1233,y:939,t:1526929909886};\\\", \\\"{x:1232,y:942,t:1526929909904};\\\", \\\"{x:1231,y:944,t:1526929909919};\\\", \\\"{x:1230,y:948,t:1526929909936};\\\", \\\"{x:1227,y:952,t:1526929909953};\\\", \\\"{x:1227,y:954,t:1526929909969};\\\", \\\"{x:1224,y:957,t:1526929909987};\\\", \\\"{x:1223,y:959,t:1526929910003};\\\", \\\"{x:1222,y:962,t:1526929910019};\\\", \\\"{x:1221,y:963,t:1526929910037};\\\", \\\"{x:1221,y:964,t:1526929910053};\\\", \\\"{x:1225,y:961,t:1526929910404};\\\", \\\"{x:1229,y:957,t:1526929910420};\\\", \\\"{x:1238,y:953,t:1526929910436};\\\", \\\"{x:1245,y:945,t:1526929910453};\\\", \\\"{x:1252,y:942,t:1526929910470};\\\", \\\"{x:1256,y:939,t:1526929910487};\\\", \\\"{x:1260,y:936,t:1526929910504};\\\", \\\"{x:1263,y:935,t:1526929910520};\\\", \\\"{x:1263,y:934,t:1526929910536};\\\", \\\"{x:1265,y:933,t:1526929910555};\\\", \\\"{x:1266,y:933,t:1526929910587};\\\", \\\"{x:1267,y:933,t:1526929910604};\\\", \\\"{x:1269,y:933,t:1526929910620};\\\", \\\"{x:1269,y:932,t:1526929910636};\\\", \\\"{x:1270,y:932,t:1526929910654};\\\", \\\"{x:1272,y:931,t:1526929910671};\\\", \\\"{x:1274,y:931,t:1526929910687};\\\", \\\"{x:1275,y:931,t:1526929910703};\\\", \\\"{x:1278,y:931,t:1526929910721};\\\", \\\"{x:1280,y:931,t:1526929910736};\\\", \\\"{x:1284,y:933,t:1526929910754};\\\", \\\"{x:1285,y:933,t:1526929910770};\\\", \\\"{x:1287,y:934,t:1526929910786};\\\", \\\"{x:1288,y:934,t:1526929910803};\\\", \\\"{x:1288,y:935,t:1526929910835};\\\", \\\"{x:1290,y:936,t:1526929910853};\\\", \\\"{x:1291,y:937,t:1526929910870};\\\", \\\"{x:1292,y:938,t:1526929910886};\\\", \\\"{x:1294,y:938,t:1526929910904};\\\", \\\"{x:1297,y:941,t:1526929910920};\\\", \\\"{x:1299,y:941,t:1526929910936};\\\", \\\"{x:1301,y:942,t:1526929910955};\\\", \\\"{x:1302,y:944,t:1526929910971};\\\", \\\"{x:1303,y:944,t:1526929910995};\\\", \\\"{x:1304,y:945,t:1526929911043};\\\", \\\"{x:1308,y:946,t:1526929911053};\\\", \\\"{x:1312,y:950,t:1526929911070};\\\", \\\"{x:1314,y:952,t:1526929911086};\\\", \\\"{x:1315,y:953,t:1526929911104};\\\", \\\"{x:1316,y:953,t:1526929911120};\\\", \\\"{x:1317,y:955,t:1526929911212};\\\", \\\"{x:1318,y:956,t:1526929911220};\\\", \\\"{x:1319,y:957,t:1526929911237};\\\", \\\"{x:1320,y:958,t:1526929911253};\\\", \\\"{x:1321,y:959,t:1526929911283};\\\", \\\"{x:1322,y:959,t:1526929911507};\\\", \\\"{x:1323,y:960,t:1526929911520};\\\", \\\"{x:1324,y:961,t:1526929911546};\\\", \\\"{x:1324,y:958,t:1526929911674};\\\", \\\"{x:1324,y:957,t:1526929911687};\\\", \\\"{x:1324,y:954,t:1526929911703};\\\", \\\"{x:1323,y:951,t:1526929911719};\\\", \\\"{x:1321,y:944,t:1526929911736};\\\", \\\"{x:1319,y:941,t:1526929911752};\\\", \\\"{x:1319,y:937,t:1526929911770};\\\", \\\"{x:1317,y:934,t:1526929911787};\\\", \\\"{x:1317,y:933,t:1526929911818};\\\", \\\"{x:1317,y:932,t:1526929911891};\\\", \\\"{x:1319,y:932,t:1526929912035};\\\", \\\"{x:1322,y:933,t:1526929912043};\\\", \\\"{x:1325,y:935,t:1526929912053};\\\", \\\"{x:1327,y:937,t:1526929912070};\\\", \\\"{x:1329,y:939,t:1526929912087};\\\", \\\"{x:1330,y:940,t:1526929912104};\\\", \\\"{x:1330,y:942,t:1526929912120};\\\", \\\"{x:1331,y:943,t:1526929912137};\\\", \\\"{x:1333,y:948,t:1526929912154};\\\", \\\"{x:1333,y:950,t:1526929912171};\\\", \\\"{x:1335,y:952,t:1526929912187};\\\", \\\"{x:1335,y:953,t:1526929912211};\\\", \\\"{x:1335,y:954,t:1526929912227};\\\", \\\"{x:1335,y:955,t:1526929912238};\\\", \\\"{x:1337,y:958,t:1526929912254};\\\", \\\"{x:1340,y:965,t:1526929912270};\\\", \\\"{x:1340,y:966,t:1526929912307};\\\", \\\"{x:1337,y:958,t:1526929912908};\\\", \\\"{x:1331,y:942,t:1526929912921};\\\", \\\"{x:1307,y:894,t:1526929912937};\\\", \\\"{x:1282,y:807,t:1526929912955};\\\", \\\"{x:1262,y:743,t:1526929912971};\\\", \\\"{x:1257,y:638,t:1526929912987};\\\", \\\"{x:1268,y:588,t:1526929913005};\\\", \\\"{x:1273,y:534,t:1526929913021};\\\", \\\"{x:1283,y:486,t:1526929913037};\\\", \\\"{x:1291,y:455,t:1526929913054};\\\", \\\"{x:1309,y:436,t:1526929913069};\\\", \\\"{x:1322,y:410,t:1526929913086};\\\", \\\"{x:1333,y:387,t:1526929913103};\\\", \\\"{x:1339,y:368,t:1526929913119};\\\", \\\"{x:1343,y:356,t:1526929913137};\\\", \\\"{x:1343,y:342,t:1526929913154};\\\", \\\"{x:1348,y:331,t:1526929913170};\\\", \\\"{x:1356,y:324,t:1526929913186};\\\", \\\"{x:1361,y:320,t:1526929913204};\\\", \\\"{x:1365,y:313,t:1526929913220};\\\", \\\"{x:1366,y:307,t:1526929913236};\\\", \\\"{x:1367,y:298,t:1526929913254};\\\", \\\"{x:1368,y:290,t:1526929913270};\\\", \\\"{x:1369,y:288,t:1526929913288};\\\", \\\"{x:1369,y:282,t:1526929913305};\\\", \\\"{x:1369,y:279,t:1526929913320};\\\", \\\"{x:1369,y:276,t:1526929913337};\\\", \\\"{x:1369,y:270,t:1526929913355};\\\", \\\"{x:1367,y:265,t:1526929913370};\\\", \\\"{x:1365,y:257,t:1526929913387};\\\", \\\"{x:1364,y:253,t:1526929913405};\\\", \\\"{x:1363,y:251,t:1526929913421};\\\", \\\"{x:1362,y:246,t:1526929913437};\\\", \\\"{x:1360,y:244,t:1526929913456};\\\", \\\"{x:1359,y:243,t:1526929913471};\\\", \\\"{x:1358,y:243,t:1526929913487};\\\", \\\"{x:1352,y:243,t:1526929913505};\\\", \\\"{x:1341,y:246,t:1526929913520};\\\", \\\"{x:1337,y:247,t:1526929913538};\\\", \\\"{x:1335,y:247,t:1526929913555};\\\", \\\"{x:1334,y:247,t:1526929913675};\\\", \\\"{x:1333,y:248,t:1526929913688};\\\", \\\"{x:1329,y:267,t:1526929913705};\\\", \\\"{x:1325,y:291,t:1526929913720};\\\", \\\"{x:1318,y:322,t:1526929913737};\\\", \\\"{x:1305,y:364,t:1526929913754};\\\", \\\"{x:1293,y:419,t:1526929913771};\\\", \\\"{x:1276,y:480,t:1526929913787};\\\", \\\"{x:1256,y:527,t:1526929913804};\\\", \\\"{x:1244,y:582,t:1526929913821};\\\", \\\"{x:1229,y:627,t:1526929913837};\\\", \\\"{x:1215,y:672,t:1526929913854};\\\", \\\"{x:1209,y:719,t:1526929913871};\\\", \\\"{x:1209,y:752,t:1526929913888};\\\", \\\"{x:1210,y:781,t:1526929913905};\\\", \\\"{x:1212,y:800,t:1526929913921};\\\", \\\"{x:1212,y:811,t:1526929913938};\\\", \\\"{x:1212,y:815,t:1526929913954};\\\", \\\"{x:1212,y:819,t:1526929913971};\\\", \\\"{x:1211,y:822,t:1526929913987};\\\", \\\"{x:1211,y:828,t:1526929914004};\\\", \\\"{x:1211,y:834,t:1526929914021};\\\", \\\"{x:1211,y:836,t:1526929914038};\\\", \\\"{x:1210,y:838,t:1526929914054};\\\", \\\"{x:1208,y:839,t:1526929914072};\\\", \\\"{x:1208,y:840,t:1526929914171};\\\", \\\"{x:1208,y:843,t:1526929914244};\\\", \\\"{x:1208,y:847,t:1526929914254};\\\", \\\"{x:1208,y:856,t:1526929914271};\\\", \\\"{x:1208,y:862,t:1526929914288};\\\", \\\"{x:1208,y:868,t:1526929914305};\\\", \\\"{x:1206,y:872,t:1526929914321};\\\", \\\"{x:1204,y:875,t:1526929914337};\\\", \\\"{x:1203,y:875,t:1526929914404};\\\", \\\"{x:1202,y:875,t:1526929914422};\\\", \\\"{x:1200,y:873,t:1526929914437};\\\", \\\"{x:1198,y:871,t:1526929914455};\\\", \\\"{x:1196,y:866,t:1526929914471};\\\", \\\"{x:1194,y:862,t:1526929914488};\\\", \\\"{x:1192,y:857,t:1526929914505};\\\", \\\"{x:1192,y:856,t:1526929914788};\\\", \\\"{x:1204,y:856,t:1526929914804};\\\", \\\"{x:1222,y:859,t:1526929914821};\\\", \\\"{x:1233,y:859,t:1526929914838};\\\", \\\"{x:1240,y:859,t:1526929914854};\\\", \\\"{x:1244,y:859,t:1526929914872};\\\", \\\"{x:1245,y:859,t:1526929914891};\\\", \\\"{x:1246,y:859,t:1526929914907};\\\", \\\"{x:1247,y:859,t:1526929914923};\\\", \\\"{x:1249,y:859,t:1526929914955};\\\", \\\"{x:1251,y:859,t:1526929914971};\\\", \\\"{x:1254,y:859,t:1526929914988};\\\", \\\"{x:1256,y:859,t:1526929915005};\\\", \\\"{x:1257,y:859,t:1526929915021};\\\", \\\"{x:1258,y:859,t:1526929915038};\\\", \\\"{x:1260,y:859,t:1526929915195};\\\", \\\"{x:1261,y:861,t:1526929915205};\\\", \\\"{x:1264,y:866,t:1526929915222};\\\", \\\"{x:1267,y:871,t:1526929915238};\\\", \\\"{x:1271,y:876,t:1526929915254};\\\", \\\"{x:1273,y:879,t:1526929915271};\\\", \\\"{x:1273,y:880,t:1526929915289};\\\", \\\"{x:1275,y:883,t:1526929915305};\\\", \\\"{x:1275,y:884,t:1526929915331};\\\", \\\"{x:1276,y:884,t:1526929915338};\\\", \\\"{x:1276,y:885,t:1526929915387};\\\", \\\"{x:1276,y:887,t:1526929915411};\\\", \\\"{x:1276,y:888,t:1526929915422};\\\", \\\"{x:1276,y:889,t:1526929915451};\\\", \\\"{x:1276,y:891,t:1526929915508};\\\", \\\"{x:1274,y:891,t:1526929915529};\\\", \\\"{x:1274,y:892,t:1526929915537};\\\", \\\"{x:1273,y:892,t:1526929915553};\\\", \\\"{x:1272,y:892,t:1526929915571};\\\", \\\"{x:1271,y:893,t:1526929915588};\\\", \\\"{x:1269,y:893,t:1526929915604};\\\", \\\"{x:1267,y:895,t:1526929915620};\\\", \\\"{x:1265,y:895,t:1526929915638};\\\", \\\"{x:1259,y:896,t:1526929915654};\\\", \\\"{x:1255,y:896,t:1526929915671};\\\", \\\"{x:1246,y:897,t:1526929915688};\\\", \\\"{x:1244,y:897,t:1526929915704};\\\", \\\"{x:1239,y:898,t:1526929915721};\\\", \\\"{x:1230,y:899,t:1526929915737};\\\", \\\"{x:1224,y:899,t:1526929915754};\\\", \\\"{x:1219,y:899,t:1526929915771};\\\", \\\"{x:1213,y:900,t:1526929915787};\\\", \\\"{x:1206,y:900,t:1526929915805};\\\", \\\"{x:1197,y:902,t:1526929915821};\\\", \\\"{x:1191,y:902,t:1526929915838};\\\", \\\"{x:1188,y:902,t:1526929915854};\\\", \\\"{x:1184,y:903,t:1526929915870};\\\", \\\"{x:1179,y:905,t:1526929915887};\\\", \\\"{x:1171,y:911,t:1526929915904};\\\", \\\"{x:1159,y:918,t:1526929915920};\\\", \\\"{x:1155,y:923,t:1526929915938};\\\", \\\"{x:1149,y:928,t:1526929915954};\\\", \\\"{x:1141,y:935,t:1526929915970};\\\", \\\"{x:1136,y:939,t:1526929915988};\\\", \\\"{x:1131,y:943,t:1526929916005};\\\", \\\"{x:1127,y:948,t:1526929916021};\\\", \\\"{x:1121,y:951,t:1526929916037};\\\", \\\"{x:1118,y:954,t:1526929916055};\\\", \\\"{x:1115,y:957,t:1526929916070};\\\", \\\"{x:1112,y:960,t:1526929916088};\\\", \\\"{x:1110,y:961,t:1526929916105};\\\", \\\"{x:1104,y:966,t:1526929916121};\\\", \\\"{x:1100,y:971,t:1526929916138};\\\", \\\"{x:1098,y:972,t:1526929916154};\\\", \\\"{x:1097,y:973,t:1526929916171};\\\", \\\"{x:1096,y:975,t:1526929916188};\\\", \\\"{x:1095,y:975,t:1526929916218};\\\", \\\"{x:1096,y:976,t:1526929916355};\\\", \\\"{x:1101,y:977,t:1526929916371};\\\", \\\"{x:1107,y:978,t:1526929916388};\\\", \\\"{x:1117,y:979,t:1526929916405};\\\", \\\"{x:1126,y:982,t:1526929916421};\\\", \\\"{x:1137,y:983,t:1526929916438};\\\", \\\"{x:1139,y:985,t:1526929916455};\\\", \\\"{x:1145,y:985,t:1526929916471};\\\", \\\"{x:1147,y:985,t:1526929916488};\\\", \\\"{x:1152,y:986,t:1526929916505};\\\", \\\"{x:1157,y:986,t:1526929916521};\\\", \\\"{x:1167,y:987,t:1526929916538};\\\", \\\"{x:1176,y:989,t:1526929916555};\\\", \\\"{x:1181,y:989,t:1526929916571};\\\", \\\"{x:1184,y:989,t:1526929916588};\\\", \\\"{x:1188,y:989,t:1526929916605};\\\", \\\"{x:1191,y:989,t:1526929916621};\\\", \\\"{x:1194,y:989,t:1526929916639};\\\", \\\"{x:1196,y:989,t:1526929916655};\\\", \\\"{x:1198,y:989,t:1526929916671};\\\", \\\"{x:1199,y:989,t:1526929916723};\\\", \\\"{x:1201,y:989,t:1526929916738};\\\", \\\"{x:1203,y:989,t:1526929916755};\\\", \\\"{x:1205,y:988,t:1526929916772};\\\", \\\"{x:1207,y:988,t:1526929916789};\\\", \\\"{x:1208,y:988,t:1526929916806};\\\", \\\"{x:1211,y:986,t:1526929916822};\\\", \\\"{x:1213,y:985,t:1526929916892};\\\", \\\"{x:1214,y:985,t:1526929916916};\\\", \\\"{x:1215,y:984,t:1526929916948};\\\", \\\"{x:1217,y:984,t:1526929917004};\\\", \\\"{x:1218,y:983,t:1526929917035};\\\", \\\"{x:1218,y:982,t:1526929917043};\\\", \\\"{x:1220,y:982,t:1526929917055};\\\", \\\"{x:1223,y:982,t:1526929917071};\\\", \\\"{x:1224,y:982,t:1526929917088};\\\", \\\"{x:1226,y:982,t:1526929917107};\\\", \\\"{x:1228,y:982,t:1526929917122};\\\", \\\"{x:1233,y:982,t:1526929917139};\\\", \\\"{x:1235,y:982,t:1526929917155};\\\", \\\"{x:1238,y:983,t:1526929917173};\\\", \\\"{x:1241,y:983,t:1526929917188};\\\", \\\"{x:1243,y:983,t:1526929917243};\\\", \\\"{x:1244,y:983,t:1526929917274};\\\", \\\"{x:1246,y:983,t:1526929917288};\\\", \\\"{x:1248,y:983,t:1526929917306};\\\", \\\"{x:1250,y:983,t:1526929917323};\\\", \\\"{x:1251,y:983,t:1526929917363};\\\", \\\"{x:1252,y:983,t:1526929917387};\\\", \\\"{x:1253,y:983,t:1526929917411};\\\", \\\"{x:1255,y:983,t:1526929917690};\\\", \\\"{x:1256,y:983,t:1526929917721};\\\", \\\"{x:1257,y:983,t:1526929917746};\\\", \\\"{x:1258,y:983,t:1526929917754};\\\", \\\"{x:1259,y:983,t:1526929917786};\\\", \\\"{x:1260,y:983,t:1526929917802};\\\", \\\"{x:1262,y:982,t:1526929917810};\\\", \\\"{x:1263,y:981,t:1526929917826};\\\", \\\"{x:1264,y:981,t:1526929917842};\\\", \\\"{x:1266,y:980,t:1526929917866};\\\", \\\"{x:1266,y:979,t:1526929917891};\\\", \\\"{x:1267,y:979,t:1526929917907};\\\", \\\"{x:1268,y:972,t:1526929917922};\\\", \\\"{x:1268,y:966,t:1526929917940};\\\", \\\"{x:1269,y:958,t:1526929917960};\\\", \\\"{x:1270,y:945,t:1526929917972};\\\", \\\"{x:1271,y:940,t:1526929917988};\\\", \\\"{x:1273,y:932,t:1526929918004};\\\", \\\"{x:1274,y:931,t:1526929918025};\\\", \\\"{x:1274,y:930,t:1526929918042};\\\", \\\"{x:1275,y:930,t:1526929918054};\\\", \\\"{x:1276,y:929,t:1526929918071};\\\", \\\"{x:1277,y:929,t:1526929918130};\\\", \\\"{x:1279,y:928,t:1526929918153};\\\", \\\"{x:1281,y:928,t:1526929918258};\\\", \\\"{x:1283,y:929,t:1526929918272};\\\", \\\"{x:1284,y:932,t:1526929918289};\\\", \\\"{x:1284,y:933,t:1526929918305};\\\", \\\"{x:1284,y:934,t:1526929918322};\\\", \\\"{x:1284,y:935,t:1526929918338};\\\", \\\"{x:1283,y:937,t:1526929918362};\\\", \\\"{x:1282,y:937,t:1526929918378};\\\", \\\"{x:1280,y:937,t:1526929918389};\\\", \\\"{x:1262,y:937,t:1526929918405};\\\", \\\"{x:1222,y:919,t:1526929918421};\\\", \\\"{x:1128,y:879,t:1526929918439};\\\", \\\"{x:1013,y:835,t:1526929918454};\\\", \\\"{x:870,y:780,t:1526929918472};\\\", \\\"{x:734,y:737,t:1526929918489};\\\", \\\"{x:626,y:702,t:1526929918505};\\\", \\\"{x:569,y:684,t:1526929918522};\\\", \\\"{x:565,y:681,t:1526929918538};\\\", \\\"{x:565,y:679,t:1526929918555};\\\", \\\"{x:568,y:676,t:1526929918572};\\\", \\\"{x:574,y:671,t:1526929918589};\\\", \\\"{x:578,y:667,t:1526929918605};\\\", \\\"{x:582,y:661,t:1526929918623};\\\", \\\"{x:582,y:653,t:1526929918639};\\\", \\\"{x:580,y:646,t:1526929918656};\\\", \\\"{x:567,y:626,t:1526929918672};\\\", \\\"{x:551,y:611,t:1526929918690};\\\", \\\"{x:526,y:598,t:1526929918705};\\\", \\\"{x:509,y:588,t:1526929918717};\\\", \\\"{x:496,y:584,t:1526929918735};\\\", \\\"{x:486,y:580,t:1526929918752};\\\", \\\"{x:484,y:579,t:1526929918768};\\\", \\\"{x:479,y:577,t:1526929918784};\\\", \\\"{x:476,y:570,t:1526929918802};\\\", \\\"{x:467,y:563,t:1526929918818};\\\", \\\"{x:457,y:556,t:1526929918834};\\\", \\\"{x:441,y:544,t:1526929918852};\\\", \\\"{x:433,y:535,t:1526929918869};\\\", \\\"{x:430,y:532,t:1526929918885};\\\", \\\"{x:429,y:531,t:1526929918906};\\\", \\\"{x:428,y:530,t:1526929918930};\\\", \\\"{x:425,y:529,t:1526929918954};\\\", \\\"{x:421,y:529,t:1526929918968};\\\", \\\"{x:412,y:528,t:1526929918985};\\\", \\\"{x:401,y:528,t:1526929919001};\\\", \\\"{x:395,y:528,t:1526929919018};\\\", \\\"{x:393,y:528,t:1526929919035};\\\", \\\"{x:392,y:528,t:1526929919052};\\\", \\\"{x:391,y:528,t:1526929919179};\\\", \\\"{x:390,y:528,t:1526929919202};\\\", \\\"{x:389,y:528,t:1526929919242};\\\", \\\"{x:389,y:528,t:1526929919294};\\\", \\\"{x:388,y:528,t:1526929919531};\\\", \\\"{x:388,y:532,t:1526929919547};\\\", \\\"{x:385,y:535,t:1526929919555};\\\", \\\"{x:382,y:538,t:1526929919569};\\\", \\\"{x:381,y:539,t:1526929919585};\\\", \\\"{x:378,y:544,t:1526929919602};\\\", \\\"{x:376,y:548,t:1526929919619};\\\", \\\"{x:375,y:550,t:1526929919636};\\\", \\\"{x:375,y:560,t:1526929919652};\\\", \\\"{x:379,y:569,t:1526929919668};\\\", \\\"{x:383,y:577,t:1526929919686};\\\", \\\"{x:389,y:584,t:1526929919702};\\\", \\\"{x:398,y:594,t:1526929919719};\\\", \\\"{x:417,y:609,t:1526929919736};\\\", \\\"{x:444,y:629,t:1526929919752};\\\", \\\"{x:474,y:648,t:1526929919769};\\\", \\\"{x:572,y:704,t:1526929919786};\\\", \\\"{x:696,y:757,t:1526929919801};\\\", \\\"{x:821,y:800,t:1526929919819};\\\", \\\"{x:937,y:833,t:1526929919836};\\\", \\\"{x:1042,y:859,t:1526929919852};\\\", \\\"{x:1102,y:873,t:1526929919868};\\\", \\\"{x:1145,y:886,t:1526929919885};\\\", \\\"{x:1173,y:895,t:1526929919902};\\\", \\\"{x:1190,y:902,t:1526929919919};\\\", \\\"{x:1199,y:907,t:1526929919935};\\\", \\\"{x:1205,y:912,t:1526929919951};\\\", \\\"{x:1210,y:918,t:1526929919968};\\\", \\\"{x:1224,y:927,t:1526929919985};\\\", \\\"{x:1240,y:936,t:1526929920002};\\\", \\\"{x:1257,y:941,t:1526929920018};\\\", \\\"{x:1271,y:945,t:1526929920035};\\\", \\\"{x:1274,y:946,t:1526929920053};\\\", \\\"{x:1277,y:947,t:1526929920069};\\\", \\\"{x:1277,y:948,t:1526929920089};\\\", \\\"{x:1279,y:948,t:1526929920103};\\\", \\\"{x:1285,y:951,t:1526929920119};\\\", \\\"{x:1292,y:957,t:1526929920135};\\\", \\\"{x:1294,y:960,t:1526929920153};\\\", \\\"{x:1295,y:961,t:1526929920169};\\\", \\\"{x:1295,y:963,t:1526929920185};\\\", \\\"{x:1295,y:964,t:1526929920218};\\\", \\\"{x:1295,y:965,t:1526929920225};\\\", \\\"{x:1295,y:966,t:1526929920235};\\\", \\\"{x:1295,y:967,t:1526929920252};\\\", \\\"{x:1296,y:968,t:1526929920268};\\\", \\\"{x:1296,y:969,t:1526929920482};\\\", \\\"{x:1295,y:969,t:1526929920490};\\\", \\\"{x:1294,y:968,t:1526929920503};\\\", \\\"{x:1293,y:968,t:1526929920519};\\\", \\\"{x:1291,y:968,t:1526929920538};\\\", \\\"{x:1289,y:968,t:1526929920553};\\\", \\\"{x:1287,y:968,t:1526929920602};\\\", \\\"{x:1285,y:968,t:1526929920698};\\\", \\\"{x:1282,y:968,t:1526929920738};\\\", \\\"{x:1281,y:968,t:1526929920802};\\\", \\\"{x:1280,y:968,t:1526929920859};\\\", \\\"{x:1279,y:967,t:1526929922517};\\\", \\\"{x:1279,y:966,t:1526929922522};\\\", \\\"{x:1278,y:962,t:1526929922538};\\\", \\\"{x:1278,y:960,t:1526929922563};\\\", \\\"{x:1278,y:959,t:1526929922571};\\\", \\\"{x:1277,y:957,t:1526929922588};\\\", \\\"{x:1277,y:956,t:1526929922605};\\\", \\\"{x:1277,y:955,t:1526929922622};\\\", \\\"{x:1277,y:952,t:1526929922638};\\\", \\\"{x:1277,y:950,t:1526929922655};\\\", \\\"{x:1276,y:947,t:1526929922672};\\\", \\\"{x:1275,y:945,t:1526929922691};\\\", \\\"{x:1274,y:945,t:1526929922707};\\\", \\\"{x:1274,y:944,t:1526929922722};\\\", \\\"{x:1272,y:943,t:1526929922738};\\\", \\\"{x:1263,y:939,t:1526929922754};\\\", \\\"{x:1243,y:932,t:1526929922771};\\\", \\\"{x:1190,y:916,t:1526929922787};\\\", \\\"{x:1087,y:884,t:1526929922805};\\\", \\\"{x:945,y:836,t:1526929922821};\\\", \\\"{x:795,y:785,t:1526929922838};\\\", \\\"{x:651,y:742,t:1526929922855};\\\", \\\"{x:537,y:704,t:1526929922872};\\\", \\\"{x:513,y:692,t:1526929922888};\\\", \\\"{x:495,y:679,t:1526929922904};\\\", \\\"{x:486,y:670,t:1526929922918};\\\", \\\"{x:486,y:658,t:1526929922935};\\\", \\\"{x:488,y:647,t:1526929922952};\\\", \\\"{x:499,y:635,t:1526929922969};\\\", \\\"{x:510,y:612,t:1526929922988};\\\", \\\"{x:510,y:595,t:1526929923005};\\\", \\\"{x:510,y:574,t:1526929923023};\\\", \\\"{x:500,y:563,t:1526929923038};\\\", \\\"{x:493,y:557,t:1526929923055};\\\", \\\"{x:490,y:556,t:1526929923071};\\\", \\\"{x:489,y:555,t:1526929923090};\\\", \\\"{x:486,y:555,t:1526929923106};\\\", \\\"{x:483,y:555,t:1526929923122};\\\", \\\"{x:478,y:555,t:1526929923138};\\\", \\\"{x:466,y:557,t:1526929923155};\\\", \\\"{x:460,y:561,t:1526929923172};\\\", \\\"{x:456,y:564,t:1526929923189};\\\", \\\"{x:452,y:567,t:1526929923205};\\\", \\\"{x:451,y:568,t:1526929923223};\\\", \\\"{x:449,y:570,t:1526929923239};\\\", \\\"{x:447,y:571,t:1526929923255};\\\", \\\"{x:443,y:572,t:1526929923273};\\\", \\\"{x:439,y:575,t:1526929923291};\\\", \\\"{x:433,y:580,t:1526929923305};\\\", \\\"{x:429,y:583,t:1526929923322};\\\", \\\"{x:426,y:584,t:1526929923338};\\\", \\\"{x:423,y:586,t:1526929923355};\\\", \\\"{x:417,y:586,t:1526929923372};\\\", \\\"{x:412,y:586,t:1526929923388};\\\", \\\"{x:409,y:588,t:1526929923405};\\\", \\\"{x:406,y:588,t:1526929923422};\\\", \\\"{x:402,y:588,t:1526929923439};\\\", \\\"{x:401,y:588,t:1526929923455};\\\", \\\"{x:403,y:591,t:1526929923499};\\\", \\\"{x:405,y:591,t:1526929923506};\\\", \\\"{x:413,y:590,t:1526929923522};\\\", \\\"{x:423,y:588,t:1526929923540};\\\", \\\"{x:431,y:584,t:1526929923555};\\\", \\\"{x:441,y:579,t:1526929923572};\\\", \\\"{x:452,y:578,t:1526929923589};\\\", \\\"{x:467,y:576,t:1526929923605};\\\", \\\"{x:476,y:577,t:1526929923622};\\\", \\\"{x:489,y:581,t:1526929923639};\\\", \\\"{x:495,y:582,t:1526929923655};\\\", \\\"{x:498,y:582,t:1526929923672};\\\", \\\"{x:503,y:583,t:1526929923690};\\\", \\\"{x:508,y:584,t:1526929923705};\\\", \\\"{x:514,y:586,t:1526929923722};\\\", \\\"{x:520,y:588,t:1526929923739};\\\", \\\"{x:521,y:589,t:1526929923756};\\\", \\\"{x:519,y:590,t:1526929923787};\\\", \\\"{x:515,y:593,t:1526929923795};\\\", \\\"{x:512,y:593,t:1526929923805};\\\", \\\"{x:496,y:596,t:1526929923822};\\\", \\\"{x:472,y:599,t:1526929923839};\\\", \\\"{x:422,y:599,t:1526929923855};\\\", \\\"{x:366,y:600,t:1526929923872};\\\", \\\"{x:323,y:600,t:1526929923888};\\\", \\\"{x:289,y:597,t:1526929923905};\\\", \\\"{x:254,y:598,t:1526929923922};\\\", \\\"{x:246,y:599,t:1526929923938};\\\", \\\"{x:244,y:600,t:1526929923955};\\\", \\\"{x:243,y:601,t:1526929923978};\\\", \\\"{x:240,y:601,t:1526929923994};\\\", \\\"{x:239,y:602,t:1526929924006};\\\", \\\"{x:234,y:604,t:1526929924022};\\\", \\\"{x:231,y:605,t:1526929924039};\\\", \\\"{x:228,y:606,t:1526929924056};\\\", \\\"{x:227,y:606,t:1526929924072};\\\", \\\"{x:226,y:606,t:1526929924090};\\\", \\\"{x:225,y:606,t:1526929924107};\\\", \\\"{x:221,y:606,t:1526929924122};\\\", \\\"{x:213,y:606,t:1526929924139};\\\", \\\"{x:205,y:606,t:1526929924156};\\\", \\\"{x:192,y:604,t:1526929924173};\\\", \\\"{x:184,y:602,t:1526929924190};\\\", \\\"{x:178,y:600,t:1526929924206};\\\", \\\"{x:176,y:600,t:1526929924223};\\\", \\\"{x:176,y:599,t:1526929924266};\\\", \\\"{x:177,y:598,t:1526929924283};\\\", \\\"{x:180,y:598,t:1526929924290};\\\", \\\"{x:185,y:596,t:1526929924306};\\\", \\\"{x:195,y:594,t:1526929924324};\\\", \\\"{x:213,y:594,t:1526929924338};\\\", \\\"{x:237,y:594,t:1526929924356};\\\", \\\"{x:259,y:595,t:1526929924373};\\\", \\\"{x:272,y:599,t:1526929924389};\\\", \\\"{x:289,y:604,t:1526929924406};\\\", \\\"{x:296,y:608,t:1526929924423};\\\", \\\"{x:303,y:611,t:1526929924439};\\\", \\\"{x:304,y:614,t:1526929924456};\\\", \\\"{x:306,y:615,t:1526929924473};\\\", \\\"{x:314,y:623,t:1526929924490};\\\", \\\"{x:337,y:634,t:1526929924506};\\\", \\\"{x:347,y:639,t:1526929924523};\\\", \\\"{x:350,y:640,t:1526929924539};\\\", \\\"{x:353,y:642,t:1526929924556};\\\", \\\"{x:353,y:643,t:1526929924593};\\\", \\\"{x:355,y:643,t:1526929924689};\\\", \\\"{x:355,y:637,t:1526929924706};\\\", \\\"{x:355,y:634,t:1526929924723};\\\", \\\"{x:359,y:624,t:1526929924739};\\\", \\\"{x:366,y:611,t:1526929924757};\\\", \\\"{x:369,y:596,t:1526929924773};\\\", \\\"{x:374,y:586,t:1526929924789};\\\", \\\"{x:377,y:573,t:1526929924807};\\\", \\\"{x:377,y:567,t:1526929924822};\\\", \\\"{x:377,y:562,t:1526929924840};\\\", \\\"{x:378,y:558,t:1526929924856};\\\", \\\"{x:378,y:556,t:1526929924873};\\\", \\\"{x:378,y:554,t:1526929924890};\\\", \\\"{x:378,y:553,t:1526929924922};\\\", \\\"{x:378,y:551,t:1526929924938};\\\", \\\"{x:377,y:551,t:1526929925009};\\\", \\\"{x:377,y:551,t:1526929925101};\\\", \\\"{x:380,y:551,t:1526929925169};\\\", \\\"{x:389,y:556,t:1526929925177};\\\", \\\"{x:399,y:563,t:1526929925190};\\\", \\\"{x:447,y:586,t:1526929925207};\\\", \\\"{x:547,y:616,t:1526929925223};\\\", \\\"{x:660,y:645,t:1526929925240};\\\", \\\"{x:775,y:670,t:1526929925257};\\\", \\\"{x:873,y:689,t:1526929925272};\\\", \\\"{x:990,y:713,t:1526929925290};\\\", \\\"{x:1062,y:731,t:1526929925307};\\\", \\\"{x:1113,y:747,t:1526929925323};\\\", \\\"{x:1142,y:756,t:1526929925340};\\\", \\\"{x:1165,y:763,t:1526929925357};\\\", \\\"{x:1185,y:770,t:1526929925373};\\\", \\\"{x:1215,y:781,t:1526929925390};\\\", \\\"{x:1250,y:790,t:1526929925407};\\\", \\\"{x:1298,y:798,t:1526929925423};\\\", \\\"{x:1330,y:800,t:1526929925440};\\\", \\\"{x:1372,y:801,t:1526929925456};\\\", \\\"{x:1397,y:799,t:1526929925473};\\\", \\\"{x:1407,y:795,t:1526929925490};\\\", \\\"{x:1413,y:793,t:1526929925507};\\\", \\\"{x:1417,y:790,t:1526929925524};\\\", \\\"{x:1421,y:787,t:1526929925540};\\\", \\\"{x:1423,y:783,t:1526929925557};\\\", \\\"{x:1427,y:776,t:1526929925573};\\\", \\\"{x:1428,y:770,t:1526929925591};\\\", \\\"{x:1429,y:764,t:1526929925607};\\\", \\\"{x:1430,y:761,t:1526929925623};\\\", \\\"{x:1430,y:760,t:1526929925641};\\\", \\\"{x:1431,y:759,t:1526929925657};\\\", \\\"{x:1427,y:759,t:1526929925745};\\\", \\\"{x:1424,y:759,t:1526929925756};\\\", \\\"{x:1417,y:759,t:1526929925773};\\\", \\\"{x:1411,y:759,t:1526929925790};\\\", \\\"{x:1406,y:759,t:1526929925806};\\\", \\\"{x:1402,y:760,t:1526929925823};\\\", \\\"{x:1399,y:761,t:1526929925840};\\\", \\\"{x:1398,y:762,t:1526929925916};\\\", \\\"{x:1396,y:763,t:1526929925923};\\\", \\\"{x:1393,y:768,t:1526929925939};\\\", \\\"{x:1390,y:774,t:1526929925956};\\\", \\\"{x:1386,y:777,t:1526929925973};\\\", \\\"{x:1380,y:782,t:1526929925989};\\\", \\\"{x:1375,y:786,t:1526929926007};\\\", \\\"{x:1372,y:789,t:1526929926023};\\\", \\\"{x:1369,y:793,t:1526929926039};\\\", \\\"{x:1366,y:798,t:1526929926056};\\\", \\\"{x:1363,y:805,t:1526929926074};\\\", \\\"{x:1356,y:816,t:1526929926090};\\\", \\\"{x:1351,y:823,t:1526929926106};\\\", \\\"{x:1347,y:831,t:1526929926123};\\\", \\\"{x:1338,y:839,t:1526929926139};\\\", \\\"{x:1326,y:848,t:1526929926157};\\\", \\\"{x:1316,y:857,t:1526929926174};\\\", \\\"{x:1311,y:862,t:1526929926189};\\\", \\\"{x:1307,y:869,t:1526929926207};\\\", \\\"{x:1302,y:878,t:1526929926224};\\\", \\\"{x:1299,y:887,t:1526929926240};\\\", \\\"{x:1294,y:897,t:1526929926257};\\\", \\\"{x:1293,y:903,t:1526929926274};\\\", \\\"{x:1290,y:914,t:1526929926290};\\\", \\\"{x:1288,y:923,t:1526929926307};\\\", \\\"{x:1286,y:931,t:1526929926323};\\\", \\\"{x:1285,y:939,t:1526929926340};\\\", \\\"{x:1284,y:945,t:1526929926357};\\\", \\\"{x:1284,y:952,t:1526929926373};\\\", \\\"{x:1284,y:956,t:1526929926389};\\\", \\\"{x:1284,y:960,t:1526929926407};\\\", \\\"{x:1283,y:963,t:1526929926424};\\\", \\\"{x:1282,y:966,t:1526929926440};\\\", \\\"{x:1282,y:967,t:1526929926457};\\\", \\\"{x:1281,y:968,t:1526929926472};\\\", \\\"{x:1281,y:969,t:1526929926490};\\\", \\\"{x:1282,y:967,t:1526929929347};\\\", \\\"{x:1282,y:966,t:1526929929355};\\\", \\\"{x:1284,y:960,t:1526929929372};\\\", \\\"{x:1288,y:955,t:1526929929388};\\\", \\\"{x:1291,y:951,t:1526929929405};\\\", \\\"{x:1292,y:948,t:1526929929421};\\\", \\\"{x:1294,y:946,t:1526929929438};\\\", \\\"{x:1296,y:943,t:1526929929455};\\\", \\\"{x:1298,y:941,t:1526929929471};\\\", \\\"{x:1301,y:935,t:1526929929488};\\\", \\\"{x:1305,y:930,t:1526929929505};\\\", \\\"{x:1309,y:923,t:1526929929521};\\\", \\\"{x:1312,y:919,t:1526929929538};\\\", \\\"{x:1317,y:910,t:1526929929554};\\\", \\\"{x:1329,y:890,t:1526929929571};\\\", \\\"{x:1339,y:874,t:1526929929588};\\\", \\\"{x:1345,y:863,t:1526929929605};\\\", \\\"{x:1352,y:851,t:1526929929621};\\\", \\\"{x:1356,y:844,t:1526929929638};\\\", \\\"{x:1359,y:838,t:1526929929655};\\\", \\\"{x:1363,y:831,t:1526929929671};\\\", \\\"{x:1365,y:822,t:1526929929687};\\\", \\\"{x:1366,y:814,t:1526929929705};\\\", \\\"{x:1369,y:806,t:1526929929720};\\\", \\\"{x:1374,y:795,t:1526929929739};\\\", \\\"{x:1375,y:789,t:1526929929754};\\\", \\\"{x:1376,y:786,t:1526929929771};\\\", \\\"{x:1376,y:783,t:1526929929788};\\\", \\\"{x:1377,y:780,t:1526929929805};\\\", \\\"{x:1379,y:778,t:1526929929821};\\\", \\\"{x:1379,y:774,t:1526929929838};\\\", \\\"{x:1380,y:771,t:1526929929854};\\\", \\\"{x:1381,y:765,t:1526929929872};\\\", \\\"{x:1385,y:762,t:1526929929888};\\\", \\\"{x:1388,y:757,t:1526929929905};\\\", \\\"{x:1391,y:754,t:1526929929921};\\\", \\\"{x:1392,y:751,t:1526929929938};\\\", \\\"{x:1397,y:743,t:1526929929954};\\\", \\\"{x:1397,y:739,t:1526929929971};\\\", \\\"{x:1399,y:737,t:1526929929987};\\\", \\\"{x:1399,y:736,t:1526929930018};\\\", \\\"{x:1399,y:735,t:1526929930026};\\\", \\\"{x:1399,y:734,t:1526929930037};\\\", \\\"{x:1399,y:732,t:1526929930054};\\\", \\\"{x:1399,y:731,t:1526929930070};\\\", \\\"{x:1399,y:730,t:1526929930088};\\\", \\\"{x:1399,y:729,t:1526929930104};\\\", \\\"{x:1400,y:727,t:1526929930120};\\\", \\\"{x:1400,y:726,t:1526929930227};\\\", \\\"{x:1399,y:726,t:1526929930242};\\\", \\\"{x:1399,y:727,t:1526929930254};\\\", \\\"{x:1397,y:727,t:1526929930271};\\\", \\\"{x:1394,y:729,t:1526929930288};\\\", \\\"{x:1392,y:729,t:1526929930304};\\\", \\\"{x:1389,y:731,t:1526929930321};\\\", \\\"{x:1383,y:736,t:1526929930337};\\\", \\\"{x:1379,y:740,t:1526929930353};\\\", \\\"{x:1374,y:746,t:1526929930370};\\\", \\\"{x:1370,y:750,t:1526929930387};\\\", \\\"{x:1367,y:755,t:1526929930403};\\\", \\\"{x:1365,y:760,t:1526929930420};\\\", \\\"{x:1364,y:764,t:1526929930437};\\\", \\\"{x:1364,y:766,t:1526929930454};\\\", \\\"{x:1362,y:768,t:1526929930470};\\\", \\\"{x:1362,y:771,t:1526929930538};\\\", \\\"{x:1361,y:775,t:1526929930553};\\\", \\\"{x:1358,y:779,t:1526929930570};\\\", \\\"{x:1357,y:782,t:1526929930586};\\\", \\\"{x:1356,y:785,t:1526929930603};\\\", \\\"{x:1356,y:786,t:1526929930620};\\\", \\\"{x:1355,y:787,t:1526929930635};\\\", \\\"{x:1355,y:788,t:1526929930653};\\\", \\\"{x:1355,y:790,t:1526929930670};\\\", \\\"{x:1354,y:791,t:1526929930686};\\\", \\\"{x:1354,y:792,t:1526929930703};\\\", \\\"{x:1353,y:792,t:1526929930720};\\\", \\\"{x:1352,y:793,t:1526929930736};\\\", \\\"{x:1351,y:794,t:1526929930754};\\\", \\\"{x:1350,y:794,t:1526929930778};\\\", \\\"{x:1349,y:795,t:1526929930786};\\\", \\\"{x:1348,y:795,t:1526929930803};\\\", \\\"{x:1347,y:797,t:1526929930820};\\\", \\\"{x:1346,y:798,t:1526929930837};\\\", \\\"{x:1344,y:801,t:1526929930854};\\\", \\\"{x:1343,y:801,t:1526929930870};\\\", \\\"{x:1341,y:803,t:1526929930887};\\\", \\\"{x:1341,y:805,t:1526929930904};\\\", \\\"{x:1339,y:806,t:1526929930920};\\\", \\\"{x:1336,y:808,t:1526929930937};\\\", \\\"{x:1333,y:812,t:1526929930953};\\\", \\\"{x:1327,y:817,t:1526929930970};\\\", \\\"{x:1320,y:823,t:1526929930986};\\\", \\\"{x:1309,y:829,t:1526929931003};\\\", \\\"{x:1297,y:836,t:1526929931019};\\\", \\\"{x:1280,y:841,t:1526929931036};\\\", \\\"{x:1264,y:846,t:1526929931053};\\\", \\\"{x:1247,y:852,t:1526929931069};\\\", \\\"{x:1236,y:859,t:1526929931086};\\\", \\\"{x:1221,y:867,t:1526929931103};\\\", \\\"{x:1215,y:872,t:1526929931119};\\\", \\\"{x:1208,y:878,t:1526929931136};\\\", \\\"{x:1201,y:885,t:1526929931153};\\\", \\\"{x:1195,y:890,t:1526929931170};\\\", \\\"{x:1184,y:896,t:1526929931187};\\\", \\\"{x:1178,y:897,t:1526929931203};\\\", \\\"{x:1170,y:899,t:1526929931219};\\\", \\\"{x:1156,y:900,t:1526929931236};\\\", \\\"{x:1134,y:900,t:1526929931253};\\\", \\\"{x:1111,y:900,t:1526929931269};\\\", \\\"{x:1084,y:895,t:1526929931286};\\\", \\\"{x:1053,y:889,t:1526929931303};\\\", \\\"{x:1022,y:884,t:1526929931319};\\\", \\\"{x:997,y:880,t:1526929931336};\\\", \\\"{x:967,y:873,t:1526929931353};\\\", \\\"{x:947,y:870,t:1526929931370};\\\", \\\"{x:928,y:868,t:1526929931386};\\\", \\\"{x:902,y:864,t:1526929931402};\\\", \\\"{x:868,y:859,t:1526929931419};\\\", \\\"{x:840,y:849,t:1526929931436};\\\", \\\"{x:806,y:839,t:1526929931452};\\\", \\\"{x:782,y:831,t:1526929931469};\\\", \\\"{x:761,y:822,t:1526929931486};\\\", \\\"{x:743,y:816,t:1526929931502};\\\", \\\"{x:739,y:812,t:1526929931519};\\\", \\\"{x:734,y:810,t:1526929931536};\\\", \\\"{x:728,y:806,t:1526929931552};\\\", \\\"{x:718,y:797,t:1526929931569};\\\", \\\"{x:708,y:790,t:1526929931585};\\\", \\\"{x:697,y:781,t:1526929931602};\\\", \\\"{x:685,y:774,t:1526929931619};\\\", \\\"{x:671,y:767,t:1526929931637};\\\", \\\"{x:662,y:762,t:1526929931653};\\\", \\\"{x:646,y:755,t:1526929931669};\\\", \\\"{x:626,y:747,t:1526929931686};\\\", \\\"{x:605,y:739,t:1526929931702};\\\", \\\"{x:589,y:734,t:1526929931720};\\\", \\\"{x:572,y:730,t:1526929931736};\\\", \\\"{x:562,y:727,t:1526929931753};\\\", \\\"{x:550,y:723,t:1526929931770};\\\", \\\"{x:546,y:723,t:1526929931786};\\\", \\\"{x:542,y:723,t:1526929931806};\\\", \\\"{x:539,y:722,t:1526929931823};\\\", \\\"{x:534,y:722,t:1526929931840};\\\", \\\"{x:529,y:720,t:1526929931856};\\\", \\\"{x:521,y:719,t:1526929931873};\\\", \\\"{x:520,y:719,t:1526929931889};\\\", \\\"{x:522,y:718,t:1526929932765};\\\", \\\"{x:523,y:718,t:1526929932773};\\\", \\\"{x:528,y:718,t:1526929932782};\\\", \\\"{x:540,y:722,t:1526929932800};\\\", \\\"{x:553,y:726,t:1526929932815};\\\", \\\"{x:567,y:730,t:1526929932833};\\\", \\\"{x:583,y:732,t:1526929932850};\\\", \\\"{x:605,y:737,t:1526929932867};\\\", \\\"{x:615,y:741,t:1526929932883};\\\", \\\"{x:637,y:744,t:1526929932900};\\\", \\\"{x:655,y:747,t:1526929932916};\\\", \\\"{x:665,y:749,t:1526929932933};\\\", \\\"{x:669,y:750,t:1526929932950};\\\", \\\"{x:670,y:750,t:1526929932998};\\\", \\\"{x:671,y:750,t:1526929933006};\\\", \\\"{x:672,y:748,t:1526929933271};\\\", \\\"{x:672,y:747,t:1526929933284};\\\", \\\"{x:672,y:745,t:1526929933300};\\\", \\\"{x:672,y:744,t:1526929933326};\\\", \\\"{x:672,y:743,t:1526929933342};\\\", \\\"{x:672,y:742,t:1526929933374};\\\", \\\"{x:672,y:741,t:1526929933430};\\\" ] }, { \\\"rt\\\": 38664, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 6, \\\"time_elapsed\\\": 324735, \\\"internal_node_id\\\": \\\"0.0-5.0-1.0\\\", \\\"subject\\\": \\\"GQ35Z\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"charlie\\\", \\\"condition\\\": \\\"111\\\", \\\"scenario\\\": \\\"acme\\\", \\\"question\\\": \\\"starts\\\", \\\"q\\\": 2, \\\"clicks\\\": 1, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XInside-YFull\\\", \\\"correct\\\": 1, \\\"orth_correct\\\": 0, \\\"answer\\\": [ \\\"K\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"X \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"U \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-D -K -F -K -K -Z -Z -Z \\\", \\\"block\\\": \\\"triangular_scaffolded\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:574,y:837,t:1526929934921};\\\", \\\"{x:574,y:837,t:1526929935031};\\\", \\\"{x:573,y:837,t:1526929935534};\\\", \\\"{x:574,y:837,t:1526929936029};\\\", \\\"{x:577,y:835,t:1526929936038};\\\", \\\"{x:578,y:835,t:1526929936055};\\\", \\\"{x:578,y:834,t:1526929936142};\\\", \\\"{x:579,y:834,t:1526929936166};\\\", \\\"{x:580,y:834,t:1526929936238};\\\", \\\"{x:581,y:834,t:1526929936261};\\\", \\\"{x:588,y:834,t:1526929936273};\\\", \\\"{x:591,y:834,t:1526929936288};\\\", \\\"{x:599,y:834,t:1526929936305};\\\", \\\"{x:605,y:834,t:1526929936322};\\\", \\\"{x:621,y:834,t:1526929936339};\\\", \\\"{x:630,y:834,t:1526929936355};\\\", \\\"{x:639,y:834,t:1526929936372};\\\", \\\"{x:668,y:834,t:1526929936389};\\\", \\\"{x:688,y:834,t:1526929936405};\\\", \\\"{x:706,y:836,t:1526929936422};\\\", \\\"{x:717,y:836,t:1526929936440};\\\", \\\"{x:742,y:837,t:1526929936457};\\\", \\\"{x:765,y:838,t:1526929936472};\\\", \\\"{x:781,y:838,t:1526929936489};\\\", \\\"{x:801,y:838,t:1526929936506};\\\", \\\"{x:817,y:838,t:1526929936522};\\\", \\\"{x:831,y:838,t:1526929936539};\\\", \\\"{x:847,y:838,t:1526929936556};\\\", \\\"{x:861,y:838,t:1526929936572};\\\", \\\"{x:889,y:835,t:1526929936590};\\\", \\\"{x:910,y:832,t:1526929936606};\\\", \\\"{x:933,y:831,t:1526929936623};\\\", \\\"{x:962,y:825,t:1526929936639};\\\", \\\"{x:986,y:820,t:1526929936657};\\\", \\\"{x:1009,y:814,t:1526929936673};\\\", \\\"{x:1033,y:807,t:1526929936690};\\\", \\\"{x:1071,y:793,t:1526929936706};\\\", \\\"{x:1120,y:784,t:1526929936723};\\\", \\\"{x:1151,y:784,t:1526929936740};\\\", \\\"{x:1205,y:781,t:1526929936756};\\\", \\\"{x:1253,y:781,t:1526929936774};\\\", \\\"{x:1278,y:781,t:1526929936790};\\\", \\\"{x:1298,y:782,t:1526929936807};\\\", \\\"{x:1306,y:788,t:1526929936823};\\\", \\\"{x:1322,y:797,t:1526929936840};\\\", \\\"{x:1326,y:801,t:1526929936856};\\\", \\\"{x:1327,y:803,t:1526929936874};\\\", \\\"{x:1327,y:804,t:1526929936891};\\\", \\\"{x:1329,y:805,t:1526929937567};\\\", \\\"{x:1330,y:805,t:1526929937576};\\\", \\\"{x:1331,y:804,t:1526929937622};\\\", \\\"{x:1332,y:803,t:1526929937629};\\\", \\\"{x:1335,y:802,t:1526929937642};\\\", \\\"{x:1340,y:796,t:1526929937658};\\\", \\\"{x:1341,y:791,t:1526929937676};\\\", \\\"{x:1345,y:782,t:1526929937692};\\\", \\\"{x:1349,y:772,t:1526929937709};\\\", \\\"{x:1351,y:762,t:1526929937725};\\\", \\\"{x:1355,y:750,t:1526929937742};\\\", \\\"{x:1359,y:741,t:1526929937759};\\\", \\\"{x:1365,y:729,t:1526929937776};\\\", \\\"{x:1368,y:719,t:1526929937792};\\\", \\\"{x:1369,y:713,t:1526929937808};\\\", \\\"{x:1370,y:705,t:1526929937825};\\\", \\\"{x:1371,y:703,t:1526929937843};\\\", \\\"{x:1371,y:700,t:1526929937859};\\\", \\\"{x:1371,y:697,t:1526929937876};\\\", \\\"{x:1371,y:695,t:1526929937893};\\\", \\\"{x:1368,y:689,t:1526929937909};\\\", \\\"{x:1366,y:686,t:1526929937925};\\\", \\\"{x:1362,y:680,t:1526929937943};\\\", \\\"{x:1358,y:671,t:1526929937959};\\\", \\\"{x:1355,y:664,t:1526929937976};\\\", \\\"{x:1355,y:658,t:1526929937992};\\\", \\\"{x:1355,y:652,t:1526929938009};\\\", \\\"{x:1355,y:647,t:1526929938026};\\\", \\\"{x:1355,y:639,t:1526929938043};\\\", \\\"{x:1353,y:630,t:1526929938060};\\\", \\\"{x:1353,y:628,t:1526929938077};\\\", \\\"{x:1353,y:626,t:1526929938093};\\\", \\\"{x:1353,y:624,t:1526929938109};\\\", \\\"{x:1353,y:623,t:1526929938141};\\\", \\\"{x:1353,y:621,t:1526929938158};\\\", \\\"{x:1353,y:618,t:1526929938173};\\\", \\\"{x:1354,y:616,t:1526929938182};\\\", \\\"{x:1354,y:615,t:1526929938194};\\\", \\\"{x:1354,y:612,t:1526929938210};\\\", \\\"{x:1355,y:611,t:1526929938227};\\\", \\\"{x:1355,y:610,t:1526929938270};\\\", \\\"{x:1355,y:609,t:1526929938294};\\\", \\\"{x:1356,y:607,t:1526929938774};\\\", \\\"{x:1357,y:604,t:1526929938798};\\\", \\\"{x:1358,y:604,t:1526929938811};\\\", \\\"{x:1358,y:603,t:1526929938829};\\\", \\\"{x:1359,y:603,t:1526929938846};\\\", \\\"{x:1361,y:601,t:1526929938862};\\\", \\\"{x:1362,y:600,t:1526929938878};\\\", \\\"{x:1363,y:599,t:1526929938895};\\\", \\\"{x:1363,y:597,t:1526929938912};\\\", \\\"{x:1365,y:596,t:1526929938929};\\\", \\\"{x:1367,y:594,t:1526929938945};\\\", \\\"{x:1370,y:591,t:1526929938974};\\\", \\\"{x:1373,y:587,t:1526929938982};\\\", \\\"{x:1376,y:583,t:1526929938995};\\\", \\\"{x:1384,y:575,t:1526929939011};\\\", \\\"{x:1396,y:565,t:1526929939029};\\\", \\\"{x:1418,y:547,t:1526929939046};\\\", \\\"{x:1432,y:534,t:1526929939061};\\\", \\\"{x:1442,y:524,t:1526929939078};\\\", \\\"{x:1452,y:515,t:1526929939095};\\\", \\\"{x:1461,y:508,t:1526929939111};\\\", \\\"{x:1469,y:504,t:1526929939128};\\\", \\\"{x:1477,y:498,t:1526929939145};\\\", \\\"{x:1486,y:491,t:1526929939161};\\\", \\\"{x:1492,y:486,t:1526929939178};\\\", \\\"{x:1497,y:484,t:1526929939195};\\\", \\\"{x:1502,y:481,t:1526929939212};\\\", \\\"{x:1505,y:477,t:1526929939228};\\\", \\\"{x:1510,y:473,t:1526929939244};\\\", \\\"{x:1514,y:472,t:1526929939262};\\\", \\\"{x:1514,y:471,t:1526929939293};\\\", \\\"{x:1514,y:470,t:1526929939302};\\\", \\\"{x:1520,y:467,t:1526929939313};\\\", \\\"{x:1530,y:466,t:1526929939329};\\\", \\\"{x:1540,y:465,t:1526929939345};\\\", \\\"{x:1552,y:460,t:1526929939362};\\\", \\\"{x:1562,y:454,t:1526929939379};\\\", \\\"{x:1567,y:453,t:1526929939395};\\\", \\\"{x:1576,y:451,t:1526929939412};\\\", \\\"{x:1591,y:447,t:1526929939429};\\\", \\\"{x:1597,y:444,t:1526929939445};\\\", \\\"{x:1604,y:443,t:1526929939463};\\\", \\\"{x:1606,y:442,t:1526929939480};\\\", \\\"{x:1606,y:441,t:1526929939497};\\\", \\\"{x:1606,y:440,t:1526929939526};\\\", \\\"{x:1608,y:439,t:1526929939549};\\\", \\\"{x:1609,y:438,t:1526929939630};\\\", \\\"{x:1609,y:436,t:1526929939647};\\\", \\\"{x:1614,y:433,t:1526929939665};\\\", \\\"{x:1615,y:431,t:1526929939679};\\\", \\\"{x:1616,y:430,t:1526929939696};\\\", \\\"{x:1617,y:429,t:1526929939713};\\\", \\\"{x:1615,y:429,t:1526929940838};\\\", \\\"{x:1614,y:430,t:1526929940853};\\\", \\\"{x:1612,y:431,t:1526929940865};\\\", \\\"{x:1611,y:432,t:1526929940883};\\\", \\\"{x:1611,y:433,t:1526929940926};\\\", \\\"{x:1610,y:433,t:1526929940942};\\\", \\\"{x:1609,y:433,t:1526929940968};\\\", \\\"{x:1608,y:434,t:1526929941022};\\\", \\\"{x:1608,y:435,t:1526929941032};\\\", \\\"{x:1607,y:437,t:1526929941050};\\\", \\\"{x:1607,y:438,t:1526929941070};\\\", \\\"{x:1606,y:439,t:1526929941086};\\\", \\\"{x:1606,y:440,t:1526929941100};\\\", \\\"{x:1605,y:442,t:1526929941117};\\\", \\\"{x:1605,y:443,t:1526929941134};\\\", \\\"{x:1605,y:446,t:1526929941149};\\\", \\\"{x:1605,y:448,t:1526929941167};\\\", \\\"{x:1603,y:451,t:1526929941183};\\\", \\\"{x:1603,y:454,t:1526929941199};\\\", \\\"{x:1603,y:457,t:1526929941216};\\\", \\\"{x:1603,y:460,t:1526929941233};\\\", \\\"{x:1603,y:462,t:1526929941248};\\\", \\\"{x:1603,y:464,t:1526929941266};\\\", \\\"{x:1602,y:467,t:1526929941283};\\\", \\\"{x:1602,y:469,t:1526929941300};\\\", \\\"{x:1602,y:470,t:1526929941316};\\\", \\\"{x:1601,y:474,t:1526929941333};\\\", \\\"{x:1600,y:477,t:1526929941350};\\\", \\\"{x:1599,y:481,t:1526929941366};\\\", \\\"{x:1599,y:483,t:1526929941384};\\\", \\\"{x:1596,y:488,t:1526929941400};\\\", \\\"{x:1595,y:492,t:1526929941416};\\\", \\\"{x:1591,y:498,t:1526929941434};\\\", \\\"{x:1587,y:505,t:1526929941450};\\\", \\\"{x:1583,y:512,t:1526929941467};\\\", \\\"{x:1580,y:519,t:1526929941484};\\\", \\\"{x:1577,y:525,t:1526929941501};\\\", \\\"{x:1570,y:539,t:1526929941517};\\\", \\\"{x:1565,y:547,t:1526929941533};\\\", \\\"{x:1560,y:556,t:1526929941551};\\\", \\\"{x:1555,y:568,t:1526929941568};\\\", \\\"{x:1552,y:577,t:1526929941583};\\\", \\\"{x:1549,y:585,t:1526929941600};\\\", \\\"{x:1548,y:590,t:1526929941617};\\\", \\\"{x:1547,y:593,t:1526929941634};\\\", \\\"{x:1546,y:597,t:1526929941651};\\\", \\\"{x:1545,y:598,t:1526929941667};\\\", \\\"{x:1544,y:602,t:1526929941684};\\\", \\\"{x:1543,y:602,t:1526929941700};\\\", \\\"{x:1543,y:604,t:1526929941717};\\\", \\\"{x:1541,y:607,t:1526929941734};\\\", \\\"{x:1540,y:611,t:1526929941751};\\\", \\\"{x:1539,y:613,t:1526929941767};\\\", \\\"{x:1539,y:614,t:1526929941784};\\\", \\\"{x:1537,y:617,t:1526929941801};\\\", \\\"{x:1536,y:619,t:1526929941817};\\\", \\\"{x:1532,y:621,t:1526929941834};\\\", \\\"{x:1530,y:623,t:1526929941851};\\\", \\\"{x:1528,y:625,t:1526929941867};\\\", \\\"{x:1526,y:626,t:1526929941884};\\\", \\\"{x:1523,y:628,t:1526929941902};\\\", \\\"{x:1522,y:630,t:1526929941918};\\\", \\\"{x:1521,y:631,t:1526929941934};\\\", \\\"{x:1519,y:634,t:1526929941951};\\\", \\\"{x:1518,y:635,t:1526929941969};\\\", \\\"{x:1517,y:635,t:1526929941984};\\\", \\\"{x:1516,y:636,t:1526929942002};\\\", \\\"{x:1514,y:637,t:1526929942018};\\\", \\\"{x:1512,y:638,t:1526929942035};\\\", \\\"{x:1512,y:640,t:1526929942246};\\\", \\\"{x:1512,y:641,t:1526929942254};\\\", \\\"{x:1511,y:643,t:1526929942268};\\\", \\\"{x:1511,y:648,t:1526929942286};\\\", \\\"{x:1509,y:653,t:1526929942303};\\\", \\\"{x:1508,y:655,t:1526929942318};\\\", \\\"{x:1508,y:656,t:1526929942335};\\\", \\\"{x:1507,y:658,t:1526929942352};\\\", \\\"{x:1507,y:659,t:1526929942374};\\\", \\\"{x:1506,y:660,t:1526929942386};\\\", \\\"{x:1506,y:661,t:1526929942402};\\\", \\\"{x:1505,y:662,t:1526929942420};\\\", \\\"{x:1503,y:664,t:1526929942435};\\\", \\\"{x:1503,y:665,t:1526929942452};\\\", \\\"{x:1501,y:666,t:1526929942469};\\\", \\\"{x:1500,y:667,t:1526929942494};\\\", \\\"{x:1499,y:668,t:1526929942502};\\\", \\\"{x:1498,y:670,t:1526929942520};\\\", \\\"{x:1496,y:672,t:1526929942537};\\\", \\\"{x:1496,y:673,t:1526929942573};\\\", \\\"{x:1495,y:675,t:1526929942587};\\\", \\\"{x:1494,y:675,t:1526929942606};\\\", \\\"{x:1494,y:676,t:1526929942620};\\\", \\\"{x:1493,y:678,t:1526929942637};\\\", \\\"{x:1493,y:679,t:1526929942726};\\\", \\\"{x:1493,y:680,t:1526929942737};\\\", \\\"{x:1493,y:681,t:1526929942774};\\\", \\\"{x:1493,y:682,t:1526929942814};\\\", \\\"{x:1493,y:683,t:1526929942854};\\\", \\\"{x:1492,y:683,t:1526929942870};\\\", \\\"{x:1492,y:684,t:1526929942901};\\\", \\\"{x:1491,y:685,t:1526929942934};\\\", \\\"{x:1490,y:687,t:1526929942966};\\\", \\\"{x:1489,y:687,t:1526929942982};\\\", \\\"{x:1489,y:689,t:1526929942990};\\\", \\\"{x:1488,y:690,t:1526929943005};\\\", \\\"{x:1487,y:690,t:1526929943021};\\\", \\\"{x:1486,y:692,t:1526929943038};\\\", \\\"{x:1485,y:693,t:1526929943053};\\\", \\\"{x:1484,y:693,t:1526929943071};\\\", \\\"{x:1483,y:694,t:1526929943088};\\\", \\\"{x:1481,y:697,t:1526929943104};\\\", \\\"{x:1480,y:697,t:1526929943121};\\\", \\\"{x:1477,y:699,t:1526929943138};\\\", \\\"{x:1473,y:701,t:1526929943155};\\\", \\\"{x:1460,y:706,t:1526929943170};\\\", \\\"{x:1435,y:709,t:1526929943187};\\\", \\\"{x:1395,y:709,t:1526929943204};\\\", \\\"{x:1314,y:709,t:1526929943221};\\\", \\\"{x:1158,y:704,t:1526929943237};\\\", \\\"{x:1038,y:698,t:1526929943254};\\\", \\\"{x:951,y:694,t:1526929943272};\\\", \\\"{x:887,y:694,t:1526929943288};\\\", \\\"{x:836,y:694,t:1526929943305};\\\", \\\"{x:807,y:698,t:1526929943321};\\\", \\\"{x:733,y:714,t:1526929943338};\\\", \\\"{x:698,y:717,t:1526929943354};\\\", \\\"{x:678,y:717,t:1526929943372};\\\", \\\"{x:653,y:717,t:1526929943387};\\\", \\\"{x:627,y:715,t:1526929943404};\\\", \\\"{x:591,y:709,t:1526929943421};\\\", \\\"{x:571,y:700,t:1526929943438};\\\", \\\"{x:549,y:688,t:1526929943455};\\\", \\\"{x:531,y:673,t:1526929943472};\\\", \\\"{x:510,y:658,t:1526929943489};\\\", \\\"{x:496,y:645,t:1526929943507};\\\", \\\"{x:487,y:638,t:1526929943521};\\\", \\\"{x:485,y:634,t:1526929943537};\\\", \\\"{x:484,y:633,t:1526929943558};\\\", \\\"{x:483,y:631,t:1526929943575};\\\", \\\"{x:481,y:629,t:1526929943592};\\\", \\\"{x:472,y:628,t:1526929943607};\\\", \\\"{x:463,y:625,t:1526929943624};\\\", \\\"{x:453,y:624,t:1526929943642};\\\", \\\"{x:443,y:622,t:1526929943658};\\\", \\\"{x:439,y:622,t:1526929943675};\\\", \\\"{x:438,y:622,t:1526929943758};\\\", \\\"{x:437,y:622,t:1526929943781};\\\", \\\"{x:436,y:622,t:1526929943812};\\\", \\\"{x:435,y:622,t:1526929943825};\\\", \\\"{x:434,y:622,t:1526929943842};\\\", \\\"{x:429,y:622,t:1526929943859};\\\", \\\"{x:423,y:621,t:1526929943875};\\\", \\\"{x:419,y:620,t:1526929943892};\\\", \\\"{x:410,y:613,t:1526929943909};\\\", \\\"{x:403,y:611,t:1526929943926};\\\", \\\"{x:388,y:611,t:1526929943942};\\\", \\\"{x:362,y:611,t:1526929943958};\\\", \\\"{x:329,y:611,t:1526929943975};\\\", \\\"{x:297,y:609,t:1526929943992};\\\", \\\"{x:269,y:607,t:1526929944008};\\\", \\\"{x:239,y:605,t:1526929944025};\\\", \\\"{x:203,y:600,t:1526929944042};\\\", \\\"{x:173,y:592,t:1526929944059};\\\", \\\"{x:150,y:589,t:1526929944075};\\\", \\\"{x:143,y:587,t:1526929944092};\\\", \\\"{x:133,y:587,t:1526929944109};\\\", \\\"{x:131,y:587,t:1526929944125};\\\", \\\"{x:130,y:587,t:1526929944142};\\\", \\\"{x:129,y:588,t:1526929944222};\\\", \\\"{x:128,y:588,t:1526929944229};\\\", \\\"{x:127,y:592,t:1526929944242};\\\", \\\"{x:127,y:597,t:1526929944259};\\\", \\\"{x:127,y:602,t:1526929944275};\\\", \\\"{x:127,y:606,t:1526929944293};\\\", \\\"{x:127,y:610,t:1526929944309};\\\", \\\"{x:126,y:612,t:1526929944325};\\\", \\\"{x:126,y:614,t:1526929944344};\\\", \\\"{x:131,y:622,t:1526929944359};\\\", \\\"{x:135,y:627,t:1526929944375};\\\", \\\"{x:139,y:631,t:1526929944392};\\\", \\\"{x:143,y:635,t:1526929944408};\\\", \\\"{x:149,y:638,t:1526929944426};\\\", \\\"{x:158,y:643,t:1526929944442};\\\", \\\"{x:171,y:647,t:1526929944460};\\\", \\\"{x:190,y:650,t:1526929944475};\\\", \\\"{x:208,y:655,t:1526929944492};\\\", \\\"{x:241,y:659,t:1526929944509};\\\", \\\"{x:263,y:660,t:1526929944526};\\\", \\\"{x:290,y:664,t:1526929944542};\\\", \\\"{x:310,y:667,t:1526929944559};\\\", \\\"{x:331,y:669,t:1526929944576};\\\", \\\"{x:358,y:670,t:1526929944592};\\\", \\\"{x:380,y:670,t:1526929944609};\\\", \\\"{x:395,y:670,t:1526929944626};\\\", \\\"{x:411,y:669,t:1526929944642};\\\", \\\"{x:431,y:664,t:1526929944659};\\\", \\\"{x:449,y:662,t:1526929944676};\\\", \\\"{x:485,y:657,t:1526929944692};\\\", \\\"{x:512,y:651,t:1526929944709};\\\", \\\"{x:532,y:646,t:1526929944726};\\\", \\\"{x:540,y:643,t:1526929944743};\\\", \\\"{x:551,y:637,t:1526929944758};\\\", \\\"{x:560,y:632,t:1526929944775};\\\", \\\"{x:570,y:626,t:1526929944792};\\\", \\\"{x:577,y:623,t:1526929944808};\\\", \\\"{x:581,y:620,t:1526929944825};\\\", \\\"{x:586,y:616,t:1526929944843};\\\", \\\"{x:590,y:613,t:1526929944858};\\\", \\\"{x:593,y:612,t:1526929944877};\\\", \\\"{x:600,y:608,t:1526929944892};\\\", \\\"{x:608,y:605,t:1526929944908};\\\", \\\"{x:613,y:603,t:1526929944926};\\\", \\\"{x:623,y:598,t:1526929944942};\\\", \\\"{x:631,y:593,t:1526929944959};\\\", \\\"{x:639,y:589,t:1526929944976};\\\", \\\"{x:644,y:587,t:1526929944993};\\\", \\\"{x:659,y:583,t:1526929945009};\\\", \\\"{x:677,y:580,t:1526929945027};\\\", \\\"{x:693,y:576,t:1526929945043};\\\", \\\"{x:706,y:574,t:1526929945059};\\\", \\\"{x:726,y:574,t:1526929945077};\\\", \\\"{x:752,y:574,t:1526929945092};\\\", \\\"{x:767,y:574,t:1526929945109};\\\", \\\"{x:780,y:572,t:1526929945126};\\\", \\\"{x:789,y:571,t:1526929945143};\\\", \\\"{x:792,y:570,t:1526929945160};\\\", \\\"{x:792,y:571,t:1526929945238};\\\", \\\"{x:788,y:572,t:1526929945245};\\\", \\\"{x:784,y:573,t:1526929945259};\\\", \\\"{x:764,y:579,t:1526929945278};\\\", \\\"{x:728,y:585,t:1526929945293};\\\", \\\"{x:688,y:591,t:1526929945310};\\\", \\\"{x:660,y:600,t:1526929945326};\\\", \\\"{x:633,y:606,t:1526929945344};\\\", \\\"{x:620,y:613,t:1526929945360};\\\", \\\"{x:615,y:617,t:1526929945376};\\\", \\\"{x:611,y:618,t:1526929945393};\\\", \\\"{x:606,y:621,t:1526929945409};\\\", \\\"{x:599,y:621,t:1526929945426};\\\", \\\"{x:588,y:624,t:1526929945443};\\\", \\\"{x:581,y:627,t:1526929945460};\\\", \\\"{x:573,y:629,t:1526929945476};\\\", \\\"{x:539,y:629,t:1526929945492};\\\", \\\"{x:517,y:628,t:1526929945510};\\\", \\\"{x:492,y:624,t:1526929945527};\\\", \\\"{x:466,y:618,t:1526929945544};\\\", \\\"{x:447,y:616,t:1526929945561};\\\", \\\"{x:435,y:613,t:1526929945576};\\\", \\\"{x:431,y:613,t:1526929945593};\\\", \\\"{x:428,y:611,t:1526929945611};\\\", \\\"{x:426,y:610,t:1526929945626};\\\", \\\"{x:425,y:609,t:1526929945644};\\\", \\\"{x:424,y:609,t:1526929945660};\\\", \\\"{x:422,y:606,t:1526929945677};\\\", \\\"{x:418,y:605,t:1526929945694};\\\", \\\"{x:416,y:605,t:1526929945711};\\\", \\\"{x:413,y:605,t:1526929945727};\\\", \\\"{x:407,y:604,t:1526929945743};\\\", \\\"{x:401,y:602,t:1526929945760};\\\", \\\"{x:396,y:602,t:1526929945776};\\\", \\\"{x:394,y:601,t:1526929945793};\\\", \\\"{x:392,y:601,t:1526929945810};\\\", \\\"{x:391,y:601,t:1526929945844};\\\", \\\"{x:390,y:601,t:1526929945868};\\\", \\\"{x:389,y:601,t:1526929945877};\\\", \\\"{x:388,y:601,t:1526929945893};\\\", \\\"{x:390,y:601,t:1526929946076};\\\", \\\"{x:403,y:601,t:1526929946094};\\\", \\\"{x:420,y:603,t:1526929946111};\\\", \\\"{x:450,y:608,t:1526929946128};\\\", \\\"{x:513,y:619,t:1526929946144};\\\", \\\"{x:578,y:633,t:1526929946160};\\\", \\\"{x:656,y:646,t:1526929946177};\\\", \\\"{x:739,y:657,t:1526929946194};\\\", \\\"{x:826,y:670,t:1526929946210};\\\", \\\"{x:894,y:674,t:1526929946228};\\\", \\\"{x:936,y:675,t:1526929946244};\\\", \\\"{x:986,y:680,t:1526929946261};\\\", \\\"{x:1074,y:691,t:1526929946277};\\\", \\\"{x:1131,y:702,t:1526929946294};\\\", \\\"{x:1164,y:706,t:1526929946310};\\\", \\\"{x:1218,y:726,t:1526929946327};\\\", \\\"{x:1275,y:738,t:1526929946344};\\\", \\\"{x:1318,y:744,t:1526929946360};\\\", \\\"{x:1354,y:753,t:1526929946378};\\\", \\\"{x:1379,y:758,t:1526929946395};\\\", \\\"{x:1400,y:762,t:1526929946411};\\\", \\\"{x:1414,y:767,t:1526929946427};\\\", \\\"{x:1425,y:769,t:1526929946445};\\\", \\\"{x:1431,y:770,t:1526929946461};\\\", \\\"{x:1439,y:772,t:1526929946478};\\\", \\\"{x:1448,y:772,t:1526929946494};\\\", \\\"{x:1455,y:773,t:1526929946510};\\\", \\\"{x:1457,y:773,t:1526929946528};\\\", \\\"{x:1459,y:773,t:1526929946545};\\\", \\\"{x:1460,y:773,t:1526929946565};\\\", \\\"{x:1462,y:771,t:1526929946581};\\\", \\\"{x:1466,y:771,t:1526929946594};\\\", \\\"{x:1471,y:766,t:1526929946611};\\\", \\\"{x:1480,y:761,t:1526929946628};\\\", \\\"{x:1491,y:748,t:1526929946645};\\\", \\\"{x:1495,y:744,t:1526929946661};\\\", \\\"{x:1504,y:725,t:1526929946677};\\\", \\\"{x:1510,y:715,t:1526929946695};\\\", \\\"{x:1517,y:704,t:1526929946711};\\\", \\\"{x:1523,y:689,t:1526929946728};\\\", \\\"{x:1525,y:679,t:1526929946744};\\\", \\\"{x:1526,y:664,t:1526929946761};\\\", \\\"{x:1526,y:645,t:1526929946777};\\\", \\\"{x:1529,y:632,t:1526929946794};\\\", \\\"{x:1538,y:615,t:1526929946811};\\\", \\\"{x:1552,y:603,t:1526929946828};\\\", \\\"{x:1561,y:591,t:1526929946845};\\\", \\\"{x:1566,y:582,t:1526929946861};\\\", \\\"{x:1568,y:575,t:1526929946877};\\\", \\\"{x:1570,y:573,t:1526929946894};\\\", \\\"{x:1575,y:564,t:1526929946911};\\\", \\\"{x:1577,y:550,t:1526929946927};\\\", \\\"{x:1582,y:539,t:1526929946944};\\\", \\\"{x:1589,y:530,t:1526929946961};\\\", \\\"{x:1592,y:523,t:1526929946977};\\\", \\\"{x:1594,y:513,t:1526929946994};\\\", \\\"{x:1594,y:509,t:1526929947011};\\\", \\\"{x:1594,y:504,t:1526929947028};\\\", \\\"{x:1594,y:500,t:1526929947044};\\\", \\\"{x:1595,y:491,t:1526929947060};\\\", \\\"{x:1597,y:487,t:1526929947077};\\\", \\\"{x:1598,y:479,t:1526929947094};\\\", \\\"{x:1598,y:472,t:1526929947111};\\\", \\\"{x:1599,y:467,t:1526929947128};\\\", \\\"{x:1599,y:463,t:1526929947144};\\\", \\\"{x:1599,y:459,t:1526929947161};\\\", \\\"{x:1599,y:456,t:1526929947179};\\\", \\\"{x:1601,y:453,t:1526929947195};\\\", \\\"{x:1601,y:452,t:1526929947212};\\\", \\\"{x:1600,y:452,t:1526929947318};\\\", \\\"{x:1600,y:453,t:1526929947328};\\\", \\\"{x:1595,y:456,t:1526929947345};\\\", \\\"{x:1592,y:459,t:1526929947361};\\\", \\\"{x:1590,y:465,t:1526929947379};\\\", \\\"{x:1585,y:473,t:1526929947395};\\\", \\\"{x:1577,y:490,t:1526929947412};\\\", \\\"{x:1564,y:514,t:1526929947429};\\\", \\\"{x:1561,y:520,t:1526929947445};\\\", \\\"{x:1555,y:531,t:1526929947462};\\\", \\\"{x:1552,y:537,t:1526929947479};\\\", \\\"{x:1546,y:548,t:1526929947495};\\\", \\\"{x:1541,y:558,t:1526929947512};\\\", \\\"{x:1536,y:567,t:1526929947529};\\\", \\\"{x:1533,y:573,t:1526929947545};\\\", \\\"{x:1530,y:581,t:1526929947562};\\\", \\\"{x:1528,y:587,t:1526929947579};\\\", \\\"{x:1526,y:594,t:1526929947596};\\\", \\\"{x:1524,y:600,t:1526929947611};\\\", \\\"{x:1523,y:604,t:1526929947629};\\\", \\\"{x:1520,y:610,t:1526929947645};\\\", \\\"{x:1518,y:619,t:1526929947661};\\\", \\\"{x:1517,y:623,t:1526929947679};\\\", \\\"{x:1516,y:624,t:1526929947696};\\\", \\\"{x:1516,y:626,t:1526929947713};\\\", \\\"{x:1514,y:631,t:1526929947728};\\\", \\\"{x:1512,y:634,t:1526929947745};\\\", \\\"{x:1509,y:638,t:1526929947761};\\\", \\\"{x:1509,y:640,t:1526929947778};\\\", \\\"{x:1508,y:641,t:1526929947795};\\\", \\\"{x:1505,y:645,t:1526929947812};\\\", \\\"{x:1503,y:647,t:1526929947828};\\\", \\\"{x:1501,y:650,t:1526929947844};\\\", \\\"{x:1498,y:654,t:1526929947862};\\\", \\\"{x:1496,y:655,t:1526929947878};\\\", \\\"{x:1494,y:658,t:1526929947895};\\\", \\\"{x:1492,y:661,t:1526929947913};\\\", \\\"{x:1490,y:664,t:1526929947928};\\\", \\\"{x:1490,y:666,t:1526929947945};\\\", \\\"{x:1488,y:668,t:1526929947962};\\\", \\\"{x:1485,y:672,t:1526929947978};\\\", \\\"{x:1483,y:676,t:1526929947995};\\\", \\\"{x:1481,y:680,t:1526929948012};\\\", \\\"{x:1479,y:686,t:1526929948028};\\\", \\\"{x:1476,y:694,t:1526929948045};\\\", \\\"{x:1476,y:698,t:1526929948062};\\\", \\\"{x:1475,y:701,t:1526929948078};\\\", \\\"{x:1474,y:703,t:1526929948095};\\\", \\\"{x:1473,y:708,t:1526929948112};\\\", \\\"{x:1469,y:716,t:1526929948128};\\\", \\\"{x:1468,y:726,t:1526929948145};\\\", \\\"{x:1464,y:736,t:1526929948163};\\\", \\\"{x:1462,y:743,t:1526929948179};\\\", \\\"{x:1458,y:749,t:1526929948195};\\\", \\\"{x:1454,y:756,t:1526929948213};\\\", \\\"{x:1452,y:762,t:1526929948229};\\\", \\\"{x:1450,y:766,t:1526929948246};\\\", \\\"{x:1447,y:770,t:1526929948262};\\\", \\\"{x:1443,y:775,t:1526929948279};\\\", \\\"{x:1437,y:781,t:1526929948295};\\\", \\\"{x:1432,y:785,t:1526929948313};\\\", \\\"{x:1428,y:789,t:1526929948329};\\\", \\\"{x:1423,y:794,t:1526929948345};\\\", \\\"{x:1421,y:797,t:1526929948363};\\\", \\\"{x:1420,y:799,t:1526929948379};\\\", \\\"{x:1417,y:801,t:1526929948396};\\\", \\\"{x:1410,y:809,t:1526929948413};\\\", \\\"{x:1405,y:817,t:1526929948429};\\\", \\\"{x:1395,y:839,t:1526929948446};\\\", \\\"{x:1382,y:858,t:1526929948462};\\\", \\\"{x:1373,y:872,t:1526929948480};\\\", \\\"{x:1370,y:874,t:1526929948496};\\\", \\\"{x:1370,y:877,t:1526929948513};\\\", \\\"{x:1367,y:883,t:1526929948529};\\\", \\\"{x:1366,y:887,t:1526929948546};\\\", \\\"{x:1365,y:891,t:1526929948562};\\\", \\\"{x:1364,y:895,t:1526929948579};\\\", \\\"{x:1363,y:898,t:1526929948597};\\\", \\\"{x:1363,y:900,t:1526929948613};\\\", \\\"{x:1362,y:901,t:1526929948630};\\\", \\\"{x:1362,y:904,t:1526929948646};\\\", \\\"{x:1362,y:907,t:1526929948663};\\\", \\\"{x:1360,y:908,t:1526929948679};\\\", \\\"{x:1359,y:911,t:1526929948697};\\\", \\\"{x:1359,y:913,t:1526929948717};\\\", \\\"{x:1357,y:915,t:1526929948729};\\\", \\\"{x:1356,y:917,t:1526929948746};\\\", \\\"{x:1355,y:920,t:1526929948763};\\\", \\\"{x:1355,y:921,t:1526929948780};\\\", \\\"{x:1353,y:923,t:1526929948797};\\\", \\\"{x:1353,y:925,t:1526929948813};\\\", \\\"{x:1352,y:928,t:1526929948829};\\\", \\\"{x:1350,y:932,t:1526929948846};\\\", \\\"{x:1349,y:935,t:1526929948863};\\\", \\\"{x:1345,y:938,t:1526929948880};\\\", \\\"{x:1343,y:941,t:1526929948896};\\\", \\\"{x:1342,y:942,t:1526929948912};\\\", \\\"{x:1341,y:943,t:1526929948929};\\\", \\\"{x:1339,y:945,t:1526929948957};\\\", \\\"{x:1338,y:946,t:1526929948989};\\\", \\\"{x:1338,y:947,t:1526929949021};\\\", \\\"{x:1338,y:948,t:1526929949110};\\\", \\\"{x:1338,y:951,t:1526929949125};\\\", \\\"{x:1338,y:952,t:1526929949173};\\\", \\\"{x:1338,y:953,t:1526929949180};\\\", \\\"{x:1338,y:954,t:1526929949196};\\\", \\\"{x:1338,y:955,t:1526929949213};\\\", \\\"{x:1338,y:957,t:1526929949245};\\\", \\\"{x:1338,y:958,t:1526929949293};\\\", \\\"{x:1339,y:959,t:1526929949301};\\\", \\\"{x:1340,y:957,t:1526929950998};\\\", \\\"{x:1346,y:951,t:1526929951015};\\\", \\\"{x:1350,y:947,t:1526929951032};\\\", \\\"{x:1354,y:944,t:1526929951049};\\\", \\\"{x:1355,y:942,t:1526929951064};\\\", \\\"{x:1356,y:942,t:1526929951082};\\\", \\\"{x:1356,y:941,t:1526929951098};\\\", \\\"{x:1357,y:941,t:1526929951124};\\\", \\\"{x:1358,y:940,t:1526929951132};\\\", \\\"{x:1359,y:939,t:1526929951148};\\\", \\\"{x:1360,y:938,t:1526929951165};\\\", \\\"{x:1361,y:937,t:1526929952119};\\\", \\\"{x:1361,y:936,t:1526929952133};\\\", \\\"{x:1362,y:936,t:1526929952158};\\\", \\\"{x:1361,y:936,t:1526929952333};\\\", \\\"{x:1360,y:936,t:1526929952357};\\\", \\\"{x:1359,y:937,t:1526929952428};\\\", \\\"{x:1359,y:938,t:1526929952469};\\\", \\\"{x:1359,y:939,t:1526929952482};\\\", \\\"{x:1359,y:940,t:1526929952501};\\\", \\\"{x:1359,y:942,t:1526929952517};\\\", \\\"{x:1358,y:943,t:1526929952533};\\\", \\\"{x:1358,y:944,t:1526929952549};\\\", \\\"{x:1357,y:946,t:1526929952566};\\\", \\\"{x:1356,y:949,t:1526929952583};\\\", \\\"{x:1356,y:953,t:1526929952599};\\\", \\\"{x:1357,y:957,t:1526929952615};\\\", \\\"{x:1357,y:960,t:1526929952633};\\\", \\\"{x:1357,y:962,t:1526929952650};\\\", \\\"{x:1357,y:963,t:1526929952669};\\\", \\\"{x:1357,y:965,t:1526929955262};\\\", \\\"{x:1355,y:966,t:1526929955334};\\\", \\\"{x:1354,y:966,t:1526929955365};\\\", \\\"{x:1355,y:966,t:1526929957118};\\\", \\\"{x:1356,y:966,t:1526929957126};\\\", \\\"{x:1357,y:966,t:1526929957137};\\\", \\\"{x:1358,y:966,t:1526929957153};\\\", \\\"{x:1360,y:966,t:1526929957173};\\\", \\\"{x:1361,y:966,t:1526929957213};\\\", \\\"{x:1364,y:966,t:1526929957221};\\\", \\\"{x:1365,y:966,t:1526929957245};\\\", \\\"{x:1366,y:967,t:1526929957269};\\\", \\\"{x:1367,y:968,t:1526929957287};\\\", \\\"{x:1367,y:967,t:1526929958158};\\\", \\\"{x:1367,y:966,t:1526929958172};\\\", \\\"{x:1367,y:965,t:1526929958188};\\\", \\\"{x:1367,y:964,t:1526929958204};\\\", \\\"{x:1366,y:960,t:1526929958221};\\\", \\\"{x:1363,y:957,t:1526929958238};\\\", \\\"{x:1363,y:955,t:1526929958254};\\\", \\\"{x:1361,y:949,t:1526929958271};\\\", \\\"{x:1357,y:942,t:1526929958288};\\\", \\\"{x:1355,y:935,t:1526929958304};\\\", \\\"{x:1349,y:925,t:1526929958321};\\\", \\\"{x:1349,y:922,t:1526929958338};\\\", \\\"{x:1346,y:918,t:1526929958355};\\\", \\\"{x:1345,y:916,t:1526929958371};\\\", \\\"{x:1344,y:911,t:1526929958388};\\\", \\\"{x:1342,y:907,t:1526929958405};\\\", \\\"{x:1341,y:904,t:1526929958421};\\\", \\\"{x:1341,y:901,t:1526929958438};\\\", \\\"{x:1341,y:900,t:1526929958461};\\\", \\\"{x:1341,y:898,t:1526929958518};\\\", \\\"{x:1341,y:897,t:1526929958533};\\\", \\\"{x:1340,y:896,t:1526929958542};\\\", \\\"{x:1339,y:895,t:1526929958555};\\\", \\\"{x:1339,y:892,t:1526929958572};\\\", \\\"{x:1339,y:887,t:1526929958588};\\\", \\\"{x:1339,y:884,t:1526929958605};\\\", \\\"{x:1338,y:880,t:1526929958621};\\\", \\\"{x:1338,y:878,t:1526929958638};\\\", \\\"{x:1338,y:877,t:1526929958655};\\\", \\\"{x:1338,y:876,t:1526929958671};\\\", \\\"{x:1338,y:877,t:1526929958917};\\\", \\\"{x:1338,y:880,t:1526929958925};\\\", \\\"{x:1338,y:883,t:1526929958938};\\\", \\\"{x:1339,y:886,t:1526929958955};\\\", \\\"{x:1339,y:891,t:1526929958972};\\\", \\\"{x:1339,y:893,t:1526929958988};\\\", \\\"{x:1339,y:896,t:1526929959005};\\\", \\\"{x:1339,y:900,t:1526929959022};\\\", \\\"{x:1339,y:902,t:1526929959039};\\\", \\\"{x:1338,y:905,t:1526929959055};\\\", \\\"{x:1337,y:907,t:1526929959072};\\\", \\\"{x:1335,y:912,t:1526929959088};\\\", \\\"{x:1334,y:912,t:1526929959106};\\\", \\\"{x:1334,y:914,t:1526929959122};\\\", \\\"{x:1333,y:916,t:1526929959139};\\\", \\\"{x:1331,y:917,t:1526929959156};\\\", \\\"{x:1331,y:918,t:1526929959172};\\\", \\\"{x:1329,y:920,t:1526929959189};\\\", \\\"{x:1329,y:922,t:1526929959205};\\\", \\\"{x:1329,y:923,t:1526929959222};\\\", \\\"{x:1329,y:924,t:1526929959239};\\\", \\\"{x:1329,y:927,t:1526929959255};\\\", \\\"{x:1328,y:929,t:1526929959272};\\\", \\\"{x:1328,y:931,t:1526929959290};\\\", \\\"{x:1328,y:932,t:1526929959305};\\\", \\\"{x:1327,y:934,t:1526929959322};\\\", \\\"{x:1327,y:936,t:1526929959339};\\\", \\\"{x:1327,y:937,t:1526929959355};\\\", \\\"{x:1327,y:940,t:1526929959372};\\\", \\\"{x:1327,y:945,t:1526929959389};\\\", \\\"{x:1326,y:946,t:1526929959405};\\\", \\\"{x:1325,y:947,t:1526929959437};\\\", \\\"{x:1325,y:948,t:1526929959445};\\\", \\\"{x:1324,y:950,t:1526929959462};\\\", \\\"{x:1324,y:951,t:1526929959485};\\\", \\\"{x:1323,y:952,t:1526929959518};\\\", \\\"{x:1323,y:953,t:1526929959573};\\\", \\\"{x:1322,y:954,t:1526929959589};\\\", \\\"{x:1321,y:956,t:1526929959613};\\\", \\\"{x:1320,y:957,t:1526929959622};\\\", \\\"{x:1320,y:959,t:1526929959653};\\\", \\\"{x:1319,y:960,t:1526929959678};\\\", \\\"{x:1318,y:961,t:1526929959718};\\\", \\\"{x:1318,y:962,t:1526929959733};\\\", \\\"{x:1317,y:964,t:1526929959934};\\\", \\\"{x:1319,y:962,t:1526929961717};\\\", \\\"{x:1320,y:960,t:1526929961724};\\\", \\\"{x:1324,y:955,t:1526929961740};\\\", \\\"{x:1325,y:952,t:1526929961757};\\\", \\\"{x:1327,y:950,t:1526929961773};\\\", \\\"{x:1328,y:948,t:1526929961791};\\\", \\\"{x:1330,y:944,t:1526929961807};\\\", \\\"{x:1332,y:939,t:1526929961824};\\\", \\\"{x:1332,y:933,t:1526929961840};\\\", \\\"{x:1335,y:925,t:1526929961857};\\\", \\\"{x:1336,y:915,t:1526929961873};\\\", \\\"{x:1339,y:909,t:1526929961891};\\\", \\\"{x:1341,y:906,t:1526929961907};\\\", \\\"{x:1343,y:899,t:1526929961924};\\\", \\\"{x:1345,y:891,t:1526929961941};\\\", \\\"{x:1346,y:887,t:1526929961958};\\\", \\\"{x:1347,y:885,t:1526929961974};\\\", \\\"{x:1347,y:886,t:1526929962077};\\\", \\\"{x:1348,y:890,t:1526929962091};\\\", \\\"{x:1351,y:896,t:1526929962109};\\\", \\\"{x:1356,y:906,t:1526929962125};\\\", \\\"{x:1363,y:920,t:1526929962141};\\\", \\\"{x:1365,y:924,t:1526929962158};\\\", \\\"{x:1366,y:926,t:1526929962175};\\\", \\\"{x:1366,y:927,t:1526929962191};\\\", \\\"{x:1367,y:928,t:1526929962209};\\\", \\\"{x:1367,y:930,t:1526929962237};\\\", \\\"{x:1367,y:931,t:1526929962253};\\\", \\\"{x:1367,y:934,t:1526929962261};\\\", \\\"{x:1367,y:935,t:1526929962274};\\\", \\\"{x:1368,y:938,t:1526929962292};\\\", \\\"{x:1369,y:941,t:1526929962357};\\\", \\\"{x:1370,y:945,t:1526929962376};\\\", \\\"{x:1371,y:947,t:1526929962392};\\\", \\\"{x:1372,y:948,t:1526929962409};\\\", \\\"{x:1372,y:949,t:1526929962469};\\\", \\\"{x:1374,y:952,t:1526929962477};\\\", \\\"{x:1375,y:953,t:1526929962491};\\\", \\\"{x:1375,y:954,t:1526929962509};\\\", \\\"{x:1376,y:956,t:1526929962525};\\\", \\\"{x:1377,y:956,t:1526929962541};\\\", \\\"{x:1377,y:957,t:1526929962581};\\\", \\\"{x:1379,y:959,t:1526929962638};\\\", \\\"{x:1379,y:960,t:1526929962653};\\\", \\\"{x:1380,y:962,t:1526929962677};\\\", \\\"{x:1381,y:962,t:1526929963134};\\\", \\\"{x:1382,y:961,t:1526929963142};\\\", \\\"{x:1383,y:959,t:1526929963164};\\\", \\\"{x:1385,y:953,t:1526929963175};\\\", \\\"{x:1385,y:947,t:1526929963191};\\\", \\\"{x:1388,y:942,t:1526929963209};\\\", \\\"{x:1395,y:934,t:1526929963225};\\\", \\\"{x:1398,y:928,t:1526929963242};\\\", \\\"{x:1401,y:924,t:1526929963259};\\\", \\\"{x:1404,y:920,t:1526929963275};\\\", \\\"{x:1410,y:910,t:1526929963292};\\\", \\\"{x:1421,y:895,t:1526929963309};\\\", \\\"{x:1427,y:875,t:1526929963325};\\\", \\\"{x:1433,y:859,t:1526929963341};\\\", \\\"{x:1443,y:841,t:1526929963359};\\\", \\\"{x:1453,y:823,t:1526929963375};\\\", \\\"{x:1460,y:803,t:1526929963392};\\\", \\\"{x:1468,y:783,t:1526929963410};\\\", \\\"{x:1478,y:759,t:1526929963425};\\\", \\\"{x:1489,y:731,t:1526929963442};\\\", \\\"{x:1500,y:708,t:1526929963460};\\\", \\\"{x:1515,y:679,t:1526929963475};\\\", \\\"{x:1536,y:648,t:1526929963493};\\\", \\\"{x:1542,y:632,t:1526929963508};\\\", \\\"{x:1546,y:620,t:1526929963525};\\\", \\\"{x:1552,y:612,t:1526929963542};\\\", \\\"{x:1555,y:606,t:1526929963559};\\\", \\\"{x:1559,y:600,t:1526929963576};\\\", \\\"{x:1560,y:595,t:1526929963592};\\\", \\\"{x:1562,y:592,t:1526929963609};\\\", \\\"{x:1562,y:590,t:1526929963626};\\\", \\\"{x:1562,y:589,t:1526929963669};\\\", \\\"{x:1560,y:589,t:1526929963677};\\\", \\\"{x:1552,y:590,t:1526929963693};\\\", \\\"{x:1545,y:595,t:1526929963709};\\\", \\\"{x:1539,y:600,t:1526929963726};\\\", \\\"{x:1529,y:609,t:1526929963742};\\\", \\\"{x:1523,y:624,t:1526929963759};\\\", \\\"{x:1514,y:642,t:1526929963776};\\\", \\\"{x:1506,y:660,t:1526929963792};\\\", \\\"{x:1502,y:671,t:1526929963808};\\\", \\\"{x:1498,y:681,t:1526929963826};\\\", \\\"{x:1493,y:689,t:1526929963842};\\\", \\\"{x:1488,y:698,t:1526929963858};\\\", \\\"{x:1487,y:700,t:1526929963876};\\\", \\\"{x:1487,y:703,t:1526929963891};\\\", \\\"{x:1483,y:707,t:1526929963908};\\\", \\\"{x:1480,y:712,t:1526929963926};\\\", \\\"{x:1478,y:717,t:1526929963942};\\\", \\\"{x:1472,y:725,t:1526929963959};\\\", \\\"{x:1464,y:734,t:1526929963976};\\\", \\\"{x:1461,y:741,t:1526929963993};\\\", \\\"{x:1458,y:747,t:1526929964009};\\\", \\\"{x:1454,y:755,t:1526929964026};\\\", \\\"{x:1453,y:759,t:1526929964043};\\\", \\\"{x:1450,y:764,t:1526929964059};\\\", \\\"{x:1448,y:769,t:1526929964076};\\\", \\\"{x:1444,y:778,t:1526929964092};\\\", \\\"{x:1442,y:784,t:1526929964109};\\\", \\\"{x:1440,y:789,t:1526929964126};\\\", \\\"{x:1440,y:792,t:1526929964144};\\\", \\\"{x:1438,y:795,t:1526929964159};\\\", \\\"{x:1437,y:797,t:1526929964176};\\\", \\\"{x:1437,y:799,t:1526929964193};\\\", \\\"{x:1435,y:802,t:1526929964209};\\\", \\\"{x:1434,y:804,t:1526929964227};\\\", \\\"{x:1434,y:805,t:1526929964243};\\\", \\\"{x:1434,y:806,t:1526929964259};\\\", \\\"{x:1432,y:808,t:1526929964276};\\\", \\\"{x:1430,y:809,t:1526929964293};\\\", \\\"{x:1428,y:810,t:1526929964309};\\\", \\\"{x:1423,y:811,t:1526929964327};\\\", \\\"{x:1410,y:812,t:1526929964343};\\\", \\\"{x:1384,y:812,t:1526929964360};\\\", \\\"{x:1356,y:812,t:1526929964377};\\\", \\\"{x:1296,y:804,t:1526929964394};\\\", \\\"{x:1199,y:794,t:1526929964410};\\\", \\\"{x:1088,y:778,t:1526929964426};\\\", \\\"{x:976,y:768,t:1526929964444};\\\", \\\"{x:854,y:751,t:1526929964460};\\\", \\\"{x:740,y:733,t:1526929964476};\\\", \\\"{x:594,y:712,t:1526929964493};\\\", \\\"{x:538,y:706,t:1526929964512};\\\", \\\"{x:513,y:705,t:1526929964526};\\\", \\\"{x:503,y:705,t:1526929964543};\\\", \\\"{x:498,y:705,t:1526929964560};\\\", \\\"{x:495,y:705,t:1526929964572};\\\", \\\"{x:493,y:706,t:1526929964588};\\\", \\\"{x:490,y:707,t:1526929964605};\\\", \\\"{x:489,y:709,t:1526929964621};\\\", \\\"{x:486,y:711,t:1526929964639};\\\", \\\"{x:483,y:714,t:1526929964655};\\\", \\\"{x:482,y:715,t:1526929964672};\\\", \\\"{x:481,y:716,t:1526929964689};\\\", \\\"{x:480,y:716,t:1526929964705};\\\", \\\"{x:483,y:716,t:1526929973109};\\\", \\\"{x:488,y:716,t:1526929973117};\\\", \\\"{x:492,y:716,t:1526929973133};\\\", \\\"{x:507,y:716,t:1526929973149};\\\", \\\"{x:523,y:716,t:1526929973165};\\\", \\\"{x:537,y:716,t:1526929973182};\\\", \\\"{x:551,y:716,t:1526929973200};\\\", \\\"{x:559,y:716,t:1526929973216};\\\", \\\"{x:566,y:716,t:1526929973232};\\\", \\\"{x:577,y:715,t:1526929973249};\\\", \\\"{x:587,y:715,t:1526929973265};\\\", \\\"{x:595,y:715,t:1526929973283};\\\", \\\"{x:601,y:715,t:1526929973299};\\\", \\\"{x:605,y:715,t:1526929973315};\\\", \\\"{x:606,y:715,t:1526929973332};\\\", \\\"{x:607,y:714,t:1526929973349};\\\", \\\"{x:607,y:713,t:1526929973484};\\\", \\\"{x:607,y:712,t:1526929973499};\\\", \\\"{x:599,y:702,t:1526929973515};\\\", \\\"{x:593,y:693,t:1526929973532};\\\", \\\"{x:585,y:688,t:1526929973549};\\\", \\\"{x:581,y:684,t:1526929973566};\\\", \\\"{x:578,y:682,t:1526929973582};\\\", \\\"{x:577,y:681,t:1526929973605};\\\", \\\"{x:576,y:680,t:1526929973621};\\\", \\\"{x:575,y:679,t:1526929973632};\\\", \\\"{x:572,y:677,t:1526929973652};\\\", \\\"{x:571,y:675,t:1526929973667};\\\", \\\"{x:570,y:674,t:1526929973685};\\\", \\\"{x:568,y:670,t:1526929973699};\\\", \\\"{x:566,y:667,t:1526929973715};\\\", \\\"{x:559,y:658,t:1526929973732};\\\", \\\"{x:551,y:652,t:1526929973749};\\\", \\\"{x:548,y:648,t:1526929973766};\\\", \\\"{x:546,y:645,t:1526929973782};\\\", \\\"{x:544,y:643,t:1526929973799};\\\", \\\"{x:543,y:639,t:1526929973816};\\\", \\\"{x:538,y:633,t:1526929973832};\\\", \\\"{x:531,y:625,t:1526929973849};\\\", \\\"{x:528,y:620,t:1526929973866};\\\", \\\"{x:521,y:612,t:1526929973882};\\\", \\\"{x:514,y:604,t:1526929973899};\\\", \\\"{x:492,y:582,t:1526929973925};\\\", \\\"{x:487,y:576,t:1526929973933};\\\", \\\"{x:474,y:562,t:1526929973949};\\\", \\\"{x:462,y:551,t:1526929973966};\\\", \\\"{x:451,y:540,t:1526929973983};\\\", \\\"{x:438,y:528,t:1526929973999};\\\" ] }, { \\\"rt\\\": 32361, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 7, \\\"time_elapsed\\\": 358355, \\\"internal_node_id\\\": \\\"0.0-5.0-2.0\\\", \\\"subject\\\": \\\"GQ35Z\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"charlie\\\", \\\"condition\\\": \\\"111\\\", \\\"scenario\\\": \\\"acme\\\", \\\"question\\\": \\\"meets\\\", \\\"q\\\": 3, \\\"clicks\\\": 1, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XInside-YFull\\\", \\\"correct\\\": 1, \\\"orth_correct\\\": 0, \\\"answer\\\": [ \\\"F\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"X \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"U \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-11 AM-11 AM-Z -12 PM\\\", \\\"block\\\": \\\"triangular_scaffolded\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:374,y:468,t:1526929974152};\\\", \\\"{x:374,y:467,t:1526929974188};\\\", \\\"{x:375,y:465,t:1526929974199};\\\", \\\"{x:380,y:463,t:1526929974216};\\\", \\\"{x:384,y:460,t:1526929974232};\\\", \\\"{x:394,y:453,t:1526929974249};\\\", \\\"{x:417,y:456,t:1526929974272};\\\", \\\"{x:430,y:459,t:1526929974283};\\\", \\\"{x:468,y:464,t:1526929974299};\\\", \\\"{x:499,y:470,t:1526929974316};\\\", \\\"{x:507,y:472,t:1526929974333};\\\", \\\"{x:513,y:474,t:1526929974350};\\\", \\\"{x:524,y:474,t:1526929974366};\\\", \\\"{x:536,y:475,t:1526929974383};\\\", \\\"{x:544,y:479,t:1526929974400};\\\", \\\"{x:550,y:479,t:1526929974415};\\\", \\\"{x:559,y:482,t:1526929974433};\\\", \\\"{x:568,y:484,t:1526929974450};\\\", \\\"{x:575,y:488,t:1526929974466};\\\", \\\"{x:578,y:490,t:1526929974483};\\\", \\\"{x:579,y:490,t:1526929974501};\\\", \\\"{x:581,y:490,t:1526929974524};\\\", \\\"{x:583,y:490,t:1526929974533};\\\", \\\"{x:584,y:488,t:1526929974551};\\\", \\\"{x:588,y:476,t:1526929974566};\\\", \\\"{x:591,y:450,t:1526929974584};\\\", \\\"{x:591,y:427,t:1526929974601};\\\", \\\"{x:591,y:403,t:1526929974616};\\\", \\\"{x:591,y:384,t:1526929974633};\\\", \\\"{x:591,y:372,t:1526929974651};\\\", \\\"{x:608,y:339,t:1526929974746};\\\", \\\"{x:608,y:338,t:1526929974750};\\\", \\\"{x:543,y:332,t:1526929975096};\\\", \\\"{x:542,y:332,t:1526929975100};\\\", \\\"{x:542,y:332,t:1526929975189};\\\", \\\"{x:542,y:333,t:1526929975277};\\\", \\\"{x:546,y:336,t:1526929975284};\\\", \\\"{x:561,y:344,t:1526929975301};\\\", \\\"{x:578,y:352,t:1526929975318};\\\", \\\"{x:601,y:364,t:1526929975335};\\\", \\\"{x:623,y:372,t:1526929975351};\\\", \\\"{x:647,y:382,t:1526929975367};\\\", \\\"{x:667,y:388,t:1526929975384};\\\", \\\"{x:687,y:396,t:1526929975400};\\\", \\\"{x:704,y:405,t:1526929975418};\\\", \\\"{x:719,y:415,t:1526929975434};\\\", \\\"{x:730,y:421,t:1526929975451};\\\", \\\"{x:744,y:433,t:1526929975467};\\\", \\\"{x:756,y:439,t:1526929975485};\\\", \\\"{x:768,y:443,t:1526929975501};\\\", \\\"{x:778,y:451,t:1526929975518};\\\", \\\"{x:795,y:463,t:1526929975534};\\\", \\\"{x:819,y:472,t:1526929975551};\\\", \\\"{x:846,y:482,t:1526929975568};\\\", \\\"{x:873,y:484,t:1526929975585};\\\", \\\"{x:921,y:499,t:1526929975601};\\\", \\\"{x:949,y:507,t:1526929975618};\\\", \\\"{x:969,y:512,t:1526929975634};\\\", \\\"{x:988,y:516,t:1526929975651};\\\", \\\"{x:1004,y:520,t:1526929975667};\\\", \\\"{x:1009,y:522,t:1526929975684};\\\", \\\"{x:1009,y:523,t:1526929975701};\\\", \\\"{x:1011,y:524,t:1526929975717};\\\", \\\"{x:1015,y:524,t:1526929975734};\\\", \\\"{x:1017,y:525,t:1526929975751};\\\", \\\"{x:1019,y:526,t:1526929975767};\\\", \\\"{x:1019,y:528,t:1526929975784};\\\", \\\"{x:1022,y:533,t:1526929975801};\\\", \\\"{x:1022,y:540,t:1526929975818};\\\", \\\"{x:1019,y:546,t:1526929975834};\\\", \\\"{x:1019,y:547,t:1526929975851};\\\", \\\"{x:1019,y:548,t:1526929976156};\\\", \\\"{x:1021,y:548,t:1526929976168};\\\", \\\"{x:1030,y:548,t:1526929976185};\\\", \\\"{x:1033,y:548,t:1526929976201};\\\", \\\"{x:1035,y:548,t:1526929976218};\\\", \\\"{x:1040,y:546,t:1526929976235};\\\", \\\"{x:1055,y:544,t:1526929976251};\\\", \\\"{x:1064,y:544,t:1526929976269};\\\", \\\"{x:1077,y:541,t:1526929976285};\\\", \\\"{x:1115,y:541,t:1526929976301};\\\", \\\"{x:1156,y:540,t:1526929976319};\\\", \\\"{x:1189,y:536,t:1526929976335};\\\", \\\"{x:1211,y:532,t:1526929976352};\\\", \\\"{x:1234,y:527,t:1526929976368};\\\", \\\"{x:1244,y:522,t:1526929976385};\\\", \\\"{x:1266,y:512,t:1526929976401};\\\", \\\"{x:1278,y:502,t:1526929976419};\\\", \\\"{x:1296,y:490,t:1526929976436};\\\", \\\"{x:1313,y:481,t:1526929976452};\\\", \\\"{x:1338,y:463,t:1526929976469};\\\", \\\"{x:1358,y:453,t:1526929976485};\\\", \\\"{x:1373,y:446,t:1526929976503};\\\", \\\"{x:1386,y:437,t:1526929976519};\\\", \\\"{x:1399,y:430,t:1526929976536};\\\", \\\"{x:1408,y:425,t:1526929976553};\\\", \\\"{x:1423,y:418,t:1526929976568};\\\", \\\"{x:1430,y:416,t:1526929976585};\\\", \\\"{x:1440,y:414,t:1526929976603};\\\", \\\"{x:1444,y:413,t:1526929976618};\\\", \\\"{x:1446,y:412,t:1526929976635};\\\", \\\"{x:1450,y:411,t:1526929976652};\\\", \\\"{x:1451,y:411,t:1526929976870};\\\", \\\"{x:1450,y:411,t:1526929976892};\\\", \\\"{x:1448,y:411,t:1526929976903};\\\", \\\"{x:1445,y:412,t:1526929976919};\\\", \\\"{x:1444,y:414,t:1526929976935};\\\", \\\"{x:1443,y:415,t:1526929976952};\\\", \\\"{x:1442,y:415,t:1526929976972};\\\", \\\"{x:1440,y:417,t:1526929976989};\\\", \\\"{x:1439,y:419,t:1526929977002};\\\", \\\"{x:1436,y:425,t:1526929977020};\\\", \\\"{x:1433,y:431,t:1526929977036};\\\", \\\"{x:1428,y:443,t:1526929977053};\\\", \\\"{x:1424,y:451,t:1526929977069};\\\", \\\"{x:1421,y:455,t:1526929977086};\\\", \\\"{x:1419,y:462,t:1526929977103};\\\", \\\"{x:1417,y:467,t:1526929977120};\\\", \\\"{x:1414,y:473,t:1526929977136};\\\", \\\"{x:1412,y:478,t:1526929977152};\\\", \\\"{x:1412,y:480,t:1526929977170};\\\", \\\"{x:1410,y:485,t:1526929977186};\\\", \\\"{x:1408,y:491,t:1526929977202};\\\", \\\"{x:1406,y:494,t:1526929977219};\\\", \\\"{x:1404,y:501,t:1526929977236};\\\", \\\"{x:1401,y:509,t:1526929977253};\\\", \\\"{x:1401,y:516,t:1526929977269};\\\", \\\"{x:1398,y:522,t:1526929977287};\\\", \\\"{x:1397,y:529,t:1526929977303};\\\", \\\"{x:1395,y:539,t:1526929977320};\\\", \\\"{x:1392,y:544,t:1526929977336};\\\", \\\"{x:1387,y:556,t:1526929977353};\\\", \\\"{x:1383,y:568,t:1526929977369};\\\", \\\"{x:1378,y:578,t:1526929977387};\\\", \\\"{x:1374,y:590,t:1526929977402};\\\", \\\"{x:1370,y:603,t:1526929977419};\\\", \\\"{x:1358,y:627,t:1526929977437};\\\", \\\"{x:1353,y:640,t:1526929977452};\\\", \\\"{x:1346,y:652,t:1526929977470};\\\", \\\"{x:1344,y:658,t:1526929977486};\\\", \\\"{x:1341,y:663,t:1526929977503};\\\", \\\"{x:1336,y:666,t:1526929977520};\\\", \\\"{x:1334,y:668,t:1526929977537};\\\", \\\"{x:1332,y:669,t:1526929977553};\\\", \\\"{x:1331,y:671,t:1526929977569};\\\", \\\"{x:1331,y:674,t:1526929977586};\\\", \\\"{x:1330,y:680,t:1526929977603};\\\", \\\"{x:1329,y:687,t:1526929977619};\\\", \\\"{x:1325,y:699,t:1526929977636};\\\", \\\"{x:1324,y:710,t:1526929977653};\\\", \\\"{x:1324,y:721,t:1526929977669};\\\", \\\"{x:1324,y:730,t:1526929977687};\\\", \\\"{x:1324,y:736,t:1526929977704};\\\", \\\"{x:1324,y:737,t:1526929977725};\\\", \\\"{x:1324,y:738,t:1526929977741};\\\", \\\"{x:1324,y:740,t:1526929977754};\\\", \\\"{x:1324,y:743,t:1526929977770};\\\", \\\"{x:1324,y:748,t:1526929977787};\\\", \\\"{x:1324,y:751,t:1526929977803};\\\", \\\"{x:1325,y:753,t:1526929977820};\\\", \\\"{x:1326,y:755,t:1526929977837};\\\", \\\"{x:1326,y:756,t:1526929977965};\\\", \\\"{x:1326,y:758,t:1526929977972};\\\", \\\"{x:1326,y:759,t:1526929977989};\\\", \\\"{x:1326,y:760,t:1526929978004};\\\", \\\"{x:1326,y:762,t:1526929978021};\\\", \\\"{x:1326,y:763,t:1526929978037};\\\", \\\"{x:1326,y:764,t:1526929978069};\\\", \\\"{x:1326,y:763,t:1526929982141};\\\", \\\"{x:1328,y:741,t:1526929982158};\\\", \\\"{x:1330,y:726,t:1526929982175};\\\", \\\"{x:1326,y:702,t:1526929982191};\\\", \\\"{x:1314,y:681,t:1526929982208};\\\", \\\"{x:1304,y:662,t:1526929982225};\\\", \\\"{x:1299,y:653,t:1526929982241};\\\", \\\"{x:1298,y:652,t:1526929982258};\\\", \\\"{x:1299,y:651,t:1526929982413};\\\", \\\"{x:1301,y:651,t:1526929982426};\\\", \\\"{x:1310,y:648,t:1526929982441};\\\", \\\"{x:1320,y:645,t:1526929982458};\\\", \\\"{x:1331,y:642,t:1526929982475};\\\", \\\"{x:1336,y:641,t:1526929982491};\\\", \\\"{x:1337,y:641,t:1526929982508};\\\", \\\"{x:1339,y:641,t:1526929982525};\\\", \\\"{x:1340,y:642,t:1526929982542};\\\", \\\"{x:1340,y:643,t:1526929982558};\\\", \\\"{x:1342,y:644,t:1526929982575};\\\", \\\"{x:1343,y:646,t:1526929982592};\\\", \\\"{x:1346,y:648,t:1526929982608};\\\", \\\"{x:1351,y:651,t:1526929982625};\\\", \\\"{x:1355,y:653,t:1526929982642};\\\", \\\"{x:1359,y:658,t:1526929982658};\\\", \\\"{x:1372,y:668,t:1526929982675};\\\", \\\"{x:1380,y:676,t:1526929982692};\\\", \\\"{x:1386,y:691,t:1526929982707};\\\", \\\"{x:1395,y:715,t:1526929982725};\\\", \\\"{x:1395,y:729,t:1526929982741};\\\", \\\"{x:1395,y:743,t:1526929982757};\\\", \\\"{x:1391,y:759,t:1526929982774};\\\", \\\"{x:1388,y:769,t:1526929982792};\\\", \\\"{x:1382,y:787,t:1526929982807};\\\", \\\"{x:1374,y:799,t:1526929982824};\\\", \\\"{x:1366,y:817,t:1526929982842};\\\", \\\"{x:1356,y:832,t:1526929982858};\\\", \\\"{x:1349,y:844,t:1526929982875};\\\", \\\"{x:1339,y:853,t:1526929982892};\\\", \\\"{x:1338,y:856,t:1526929982908};\\\", \\\"{x:1333,y:862,t:1526929982925};\\\", \\\"{x:1326,y:867,t:1526929982942};\\\", \\\"{x:1324,y:868,t:1526929982959};\\\", \\\"{x:1322,y:870,t:1526929982975};\\\", \\\"{x:1321,y:870,t:1526929982991};\\\", \\\"{x:1319,y:871,t:1526929983009};\\\", \\\"{x:1317,y:871,t:1526929983028};\\\", \\\"{x:1316,y:871,t:1526929983052};\\\", \\\"{x:1314,y:870,t:1526929983060};\\\", \\\"{x:1312,y:867,t:1526929983075};\\\", \\\"{x:1312,y:864,t:1526929983092};\\\", \\\"{x:1309,y:858,t:1526929983108};\\\", \\\"{x:1305,y:853,t:1526929983125};\\\", \\\"{x:1304,y:851,t:1526929983142};\\\", \\\"{x:1301,y:848,t:1526929983159};\\\", \\\"{x:1299,y:847,t:1526929983197};\\\", \\\"{x:1299,y:845,t:1526929983209};\\\", \\\"{x:1296,y:845,t:1526929983226};\\\", \\\"{x:1294,y:845,t:1526929983242};\\\", \\\"{x:1292,y:844,t:1526929983259};\\\", \\\"{x:1290,y:844,t:1526929983277};\\\", \\\"{x:1289,y:844,t:1526929983292};\\\", \\\"{x:1288,y:843,t:1526929983437};\\\", \\\"{x:1288,y:842,t:1526929983669};\\\", \\\"{x:1288,y:841,t:1526929983676};\\\", \\\"{x:1288,y:840,t:1526929983692};\\\", \\\"{x:1289,y:838,t:1526929983709};\\\", \\\"{x:1291,y:836,t:1526929983727};\\\", \\\"{x:1291,y:835,t:1526929983743};\\\", \\\"{x:1292,y:833,t:1526929983759};\\\", \\\"{x:1293,y:833,t:1526929983776};\\\", \\\"{x:1293,y:832,t:1526929983813};\\\", \\\"{x:1293,y:831,t:1526929983837};\\\", \\\"{x:1294,y:829,t:1526929983851};\\\", \\\"{x:1295,y:829,t:1526929983860};\\\", \\\"{x:1296,y:825,t:1526929983875};\\\", \\\"{x:1301,y:817,t:1526929983892};\\\", \\\"{x:1302,y:813,t:1526929983909};\\\", \\\"{x:1304,y:810,t:1526929983926};\\\", \\\"{x:1305,y:808,t:1526929983942};\\\", \\\"{x:1305,y:806,t:1526929983959};\\\", \\\"{x:1307,y:803,t:1526929983975};\\\", \\\"{x:1308,y:800,t:1526929983993};\\\", \\\"{x:1311,y:798,t:1526929984009};\\\", \\\"{x:1312,y:795,t:1526929984026};\\\", \\\"{x:1315,y:789,t:1526929984042};\\\", \\\"{x:1317,y:784,t:1526929984060};\\\", \\\"{x:1318,y:784,t:1526929984075};\\\", \\\"{x:1322,y:781,t:1526929984093};\\\", \\\"{x:1323,y:779,t:1526929984116};\\\", \\\"{x:1325,y:777,t:1526929984132};\\\", \\\"{x:1325,y:776,t:1526929984149};\\\", \\\"{x:1326,y:776,t:1526929984159};\\\", \\\"{x:1326,y:774,t:1526929984176};\\\", \\\"{x:1327,y:772,t:1526929984192};\\\", \\\"{x:1328,y:770,t:1526929984210};\\\", \\\"{x:1329,y:770,t:1526929984226};\\\", \\\"{x:1332,y:767,t:1526929984243};\\\", \\\"{x:1333,y:764,t:1526929984260};\\\", \\\"{x:1335,y:764,t:1526929984276};\\\", \\\"{x:1335,y:761,t:1526929984293};\\\", \\\"{x:1336,y:760,t:1526929984310};\\\", \\\"{x:1337,y:755,t:1526929984327};\\\", \\\"{x:1339,y:751,t:1526929984343};\\\", \\\"{x:1340,y:747,t:1526929984360};\\\", \\\"{x:1342,y:744,t:1526929984376};\\\", \\\"{x:1343,y:741,t:1526929984393};\\\", \\\"{x:1344,y:738,t:1526929984410};\\\", \\\"{x:1346,y:735,t:1526929984428};\\\", \\\"{x:1346,y:731,t:1526929984443};\\\", \\\"{x:1347,y:726,t:1526929984460};\\\", \\\"{x:1350,y:720,t:1526929984477};\\\", \\\"{x:1352,y:713,t:1526929984493};\\\", \\\"{x:1354,y:710,t:1526929984510};\\\", \\\"{x:1356,y:705,t:1526929984528};\\\", \\\"{x:1357,y:702,t:1526929984544};\\\", \\\"{x:1359,y:697,t:1526929984560};\\\", \\\"{x:1359,y:694,t:1526929984578};\\\", \\\"{x:1363,y:689,t:1526929984593};\\\", \\\"{x:1363,y:686,t:1526929984610};\\\", \\\"{x:1363,y:684,t:1526929984627};\\\", \\\"{x:1365,y:681,t:1526929984644};\\\", \\\"{x:1365,y:678,t:1526929984660};\\\", \\\"{x:1367,y:672,t:1526929984677};\\\", \\\"{x:1368,y:666,t:1526929984694};\\\", \\\"{x:1369,y:661,t:1526929984710};\\\", \\\"{x:1370,y:655,t:1526929984728};\\\", \\\"{x:1371,y:650,t:1526929984744};\\\", \\\"{x:1371,y:646,t:1526929984761};\\\", \\\"{x:1372,y:643,t:1526929984777};\\\", \\\"{x:1373,y:638,t:1526929984794};\\\", \\\"{x:1374,y:635,t:1526929984810};\\\", \\\"{x:1374,y:633,t:1526929984827};\\\", \\\"{x:1375,y:628,t:1526929984844};\\\", \\\"{x:1379,y:619,t:1526929984860};\\\", \\\"{x:1383,y:610,t:1526929984877};\\\", \\\"{x:1384,y:603,t:1526929984894};\\\", \\\"{x:1385,y:599,t:1526929984910};\\\", \\\"{x:1386,y:597,t:1526929984927};\\\", \\\"{x:1386,y:596,t:1526929984944};\\\", \\\"{x:1386,y:595,t:1526929985053};\\\", \\\"{x:1386,y:594,t:1526929985165};\\\", \\\"{x:1386,y:593,t:1526929985469};\\\", \\\"{x:1385,y:593,t:1526929985485};\\\", \\\"{x:1384,y:593,t:1526929985494};\\\", \\\"{x:1383,y:593,t:1526929985511};\\\", \\\"{x:1381,y:593,t:1526929985532};\\\", \\\"{x:1380,y:594,t:1526929985573};\\\", \\\"{x:1379,y:594,t:1526929985589};\\\", \\\"{x:1378,y:595,t:1526929985612};\\\", \\\"{x:1377,y:596,t:1526929985653};\\\", \\\"{x:1376,y:597,t:1526929985668};\\\", \\\"{x:1375,y:597,t:1526929985693};\\\", \\\"{x:1373,y:601,t:1526929985701};\\\", \\\"{x:1372,y:602,t:1526929985711};\\\", \\\"{x:1371,y:604,t:1526929985728};\\\", \\\"{x:1369,y:607,t:1526929985745};\\\", \\\"{x:1369,y:609,t:1526929985760};\\\", \\\"{x:1368,y:610,t:1526929985777};\\\", \\\"{x:1368,y:611,t:1526929985795};\\\", \\\"{x:1366,y:612,t:1526929985810};\\\", \\\"{x:1366,y:614,t:1526929985828};\\\", \\\"{x:1366,y:615,t:1526929985844};\\\", \\\"{x:1365,y:616,t:1526929985867};\\\", \\\"{x:1365,y:617,t:1526929985884};\\\", \\\"{x:1364,y:618,t:1526929985997};\\\", \\\"{x:1363,y:618,t:1526929986021};\\\", \\\"{x:1363,y:619,t:1526929986044};\\\", \\\"{x:1363,y:620,t:1526929986085};\\\", \\\"{x:1362,y:620,t:1526929986100};\\\", \\\"{x:1362,y:621,t:1526929986117};\\\", \\\"{x:1361,y:622,t:1526929986149};\\\", \\\"{x:1360,y:622,t:1526929986172};\\\", \\\"{x:1360,y:623,t:1526929986180};\\\", \\\"{x:1359,y:623,t:1526929986205};\\\", \\\"{x:1358,y:624,t:1526929986213};\\\", \\\"{x:1356,y:626,t:1526929986228};\\\", \\\"{x:1353,y:628,t:1526929986244};\\\", \\\"{x:1350,y:631,t:1526929986262};\\\", \\\"{x:1343,y:638,t:1526929986278};\\\", \\\"{x:1329,y:652,t:1526929986295};\\\", \\\"{x:1314,y:670,t:1526929986312};\\\", \\\"{x:1293,y:697,t:1526929986328};\\\", \\\"{x:1278,y:714,t:1526929986345};\\\", \\\"{x:1255,y:736,t:1526929986362};\\\", \\\"{x:1243,y:748,t:1526929986378};\\\", \\\"{x:1226,y:760,t:1526929986395};\\\", \\\"{x:1217,y:767,t:1526929986413};\\\", \\\"{x:1217,y:769,t:1526929986452};\\\", \\\"{x:1217,y:772,t:1526929986462};\\\", \\\"{x:1215,y:777,t:1526929986479};\\\", \\\"{x:1215,y:782,t:1526929986495};\\\", \\\"{x:1215,y:787,t:1526929986512};\\\", \\\"{x:1215,y:791,t:1526929986529};\\\", \\\"{x:1215,y:795,t:1526929986545};\\\", \\\"{x:1219,y:801,t:1526929986562};\\\", \\\"{x:1221,y:808,t:1526929986579};\\\", \\\"{x:1221,y:809,t:1526929986595};\\\", \\\"{x:1222,y:811,t:1526929986621};\\\", \\\"{x:1224,y:814,t:1526929986629};\\\", \\\"{x:1226,y:822,t:1526929986645};\\\", \\\"{x:1229,y:826,t:1526929986663};\\\", \\\"{x:1243,y:838,t:1526929986679};\\\", \\\"{x:1257,y:844,t:1526929986696};\\\", \\\"{x:1268,y:852,t:1526929986712};\\\", \\\"{x:1277,y:859,t:1526929986729};\\\", \\\"{x:1281,y:861,t:1526929986746};\\\", \\\"{x:1283,y:862,t:1526929986762};\\\", \\\"{x:1284,y:864,t:1526929986779};\\\", \\\"{x:1283,y:867,t:1526929986795};\\\", \\\"{x:1280,y:870,t:1526929986811};\\\", \\\"{x:1279,y:877,t:1526929986828};\\\", \\\"{x:1277,y:888,t:1526929986845};\\\", \\\"{x:1276,y:893,t:1526929986862};\\\", \\\"{x:1276,y:898,t:1526929986878};\\\", \\\"{x:1276,y:901,t:1526929986896};\\\", \\\"{x:1275,y:907,t:1526929986912};\\\", \\\"{x:1275,y:913,t:1526929986928};\\\", \\\"{x:1275,y:920,t:1526929986945};\\\", \\\"{x:1275,y:926,t:1526929986962};\\\", \\\"{x:1275,y:931,t:1526929986979};\\\", \\\"{x:1275,y:935,t:1526929986996};\\\", \\\"{x:1275,y:937,t:1526929987012};\\\", \\\"{x:1275,y:942,t:1526929987029};\\\", \\\"{x:1276,y:944,t:1526929987046};\\\", \\\"{x:1277,y:946,t:1526929987062};\\\", \\\"{x:1278,y:946,t:1526929987079};\\\", \\\"{x:1281,y:948,t:1526929987096};\\\", \\\"{x:1283,y:952,t:1526929987113};\\\", \\\"{x:1285,y:956,t:1526929987129};\\\", \\\"{x:1286,y:958,t:1526929987145};\\\", \\\"{x:1288,y:961,t:1526929987163};\\\", \\\"{x:1288,y:962,t:1526929987180};\\\", \\\"{x:1289,y:962,t:1526929987220};\\\", \\\"{x:1289,y:963,t:1526929987525};\\\", \\\"{x:1290,y:964,t:1526929987533};\\\", \\\"{x:1291,y:965,t:1526929987548};\\\", \\\"{x:1291,y:966,t:1526929987571};\\\", \\\"{x:1291,y:967,t:1526929987579};\\\", \\\"{x:1291,y:968,t:1526929987595};\\\", \\\"{x:1291,y:970,t:1526929987676};\\\", \\\"{x:1291,y:971,t:1526929987699};\\\", \\\"{x:1291,y:972,t:1526929987723};\\\", \\\"{x:1291,y:974,t:1526929987748};\\\", \\\"{x:1290,y:974,t:1526929987764};\\\", \\\"{x:1289,y:974,t:1526929987804};\\\", \\\"{x:1287,y:974,t:1526929987820};\\\", \\\"{x:1285,y:974,t:1526929987830};\\\", \\\"{x:1283,y:974,t:1526929987847};\\\", \\\"{x:1282,y:974,t:1526929987876};\\\", \\\"{x:1281,y:974,t:1526929987997};\\\", \\\"{x:1281,y:973,t:1526929988309};\\\", \\\"{x:1281,y:972,t:1526929988341};\\\", \\\"{x:1282,y:971,t:1526929988509};\\\", \\\"{x:1283,y:970,t:1526929988524};\\\", \\\"{x:1283,y:969,t:1526929988532};\\\", \\\"{x:1284,y:969,t:1526929988547};\\\", \\\"{x:1285,y:969,t:1526929988804};\\\", \\\"{x:1289,y:969,t:1526929988828};\\\", \\\"{x:1290,y:969,t:1526929988836};\\\", \\\"{x:1292,y:969,t:1526929988847};\\\", \\\"{x:1293,y:969,t:1526929989269};\\\", \\\"{x:1294,y:970,t:1526929989573};\\\", \\\"{x:1293,y:970,t:1526929989989};\\\", \\\"{x:1292,y:970,t:1526929989999};\\\", \\\"{x:1291,y:970,t:1526929990015};\\\", \\\"{x:1289,y:970,t:1526929990052};\\\", \\\"{x:1288,y:970,t:1526929990093};\\\", \\\"{x:1287,y:970,t:1526929990124};\\\", \\\"{x:1286,y:970,t:1526929990148};\\\", \\\"{x:1285,y:970,t:1526929990166};\\\", \\\"{x:1283,y:970,t:1526929990182};\\\", \\\"{x:1283,y:969,t:1526929990200};\\\", \\\"{x:1282,y:968,t:1526929990237};\\\", \\\"{x:1281,y:968,t:1526929990253};\\\", \\\"{x:1280,y:968,t:1526929990349};\\\", \\\"{x:1279,y:968,t:1526929990525};\\\", \\\"{x:1278,y:968,t:1526929990532};\\\", \\\"{x:1278,y:966,t:1526929990900};\\\", \\\"{x:1278,y:965,t:1526929990924};\\\", \\\"{x:1278,y:963,t:1526929990940};\\\", \\\"{x:1280,y:960,t:1526929990964};\\\", \\\"{x:1281,y:958,t:1526929990980};\\\", \\\"{x:1282,y:958,t:1526929990988};\\\", \\\"{x:1282,y:957,t:1526929991000};\\\", \\\"{x:1284,y:955,t:1526929991016};\\\", \\\"{x:1284,y:954,t:1526929991033};\\\", \\\"{x:1285,y:954,t:1526929991051};\\\", \\\"{x:1287,y:954,t:1526929991067};\\\", \\\"{x:1292,y:949,t:1526929991082};\\\", \\\"{x:1297,y:944,t:1526929991099};\\\", \\\"{x:1299,y:941,t:1526929991116};\\\", \\\"{x:1300,y:937,t:1526929991132};\\\", \\\"{x:1302,y:935,t:1526929991150};\\\", \\\"{x:1305,y:931,t:1526929991165};\\\", \\\"{x:1306,y:929,t:1526929991188};\\\", \\\"{x:1307,y:928,t:1526929991200};\\\", \\\"{x:1309,y:921,t:1526929991215};\\\", \\\"{x:1310,y:916,t:1526929991232};\\\", \\\"{x:1311,y:913,t:1526929991250};\\\", \\\"{x:1311,y:910,t:1526929991266};\\\", \\\"{x:1313,y:907,t:1526929991283};\\\", \\\"{x:1315,y:903,t:1526929991299};\\\", \\\"{x:1317,y:899,t:1526929991316};\\\", \\\"{x:1317,y:898,t:1526929991340};\\\", \\\"{x:1317,y:897,t:1526929991357};\\\", \\\"{x:1318,y:896,t:1526929991367};\\\", \\\"{x:1319,y:892,t:1526929991384};\\\", \\\"{x:1319,y:890,t:1526929991400};\\\", \\\"{x:1320,y:884,t:1526929991418};\\\", \\\"{x:1321,y:879,t:1526929991434};\\\", \\\"{x:1323,y:875,t:1526929991450};\\\", \\\"{x:1325,y:872,t:1526929991467};\\\", \\\"{x:1326,y:868,t:1526929991483};\\\", \\\"{x:1329,y:860,t:1526929991500};\\\", \\\"{x:1330,y:854,t:1526929991517};\\\", \\\"{x:1330,y:848,t:1526929991533};\\\", \\\"{x:1332,y:843,t:1526929991551};\\\", \\\"{x:1336,y:840,t:1526929991567};\\\", \\\"{x:1338,y:836,t:1526929991583};\\\", \\\"{x:1340,y:833,t:1526929991600};\\\", \\\"{x:1341,y:830,t:1526929991617};\\\", \\\"{x:1343,y:827,t:1526929991635};\\\", \\\"{x:1344,y:822,t:1526929991650};\\\", \\\"{x:1345,y:821,t:1526929991666};\\\", \\\"{x:1347,y:817,t:1526929991683};\\\", \\\"{x:1347,y:814,t:1526929991699};\\\", \\\"{x:1349,y:811,t:1526929991716};\\\", \\\"{x:1349,y:808,t:1526929991734};\\\", \\\"{x:1349,y:805,t:1526929991750};\\\", \\\"{x:1350,y:804,t:1526929991766};\\\", \\\"{x:1350,y:802,t:1526929991784};\\\", \\\"{x:1351,y:800,t:1526929991804};\\\", \\\"{x:1352,y:798,t:1526929991817};\\\", \\\"{x:1354,y:795,t:1526929991833};\\\", \\\"{x:1355,y:792,t:1526929991852};\\\", \\\"{x:1355,y:791,t:1526929991868};\\\", \\\"{x:1357,y:789,t:1526929991884};\\\", \\\"{x:1359,y:787,t:1526929991900};\\\", \\\"{x:1360,y:785,t:1526929991917};\\\", \\\"{x:1361,y:784,t:1526929991934};\\\", \\\"{x:1363,y:782,t:1526929991950};\\\", \\\"{x:1364,y:781,t:1526929991967};\\\", \\\"{x:1364,y:780,t:1526929991984};\\\", \\\"{x:1365,y:779,t:1526929992001};\\\", \\\"{x:1365,y:778,t:1526929992021};\\\", \\\"{x:1366,y:778,t:1526929992037};\\\", \\\"{x:1366,y:777,t:1526929992050};\\\", \\\"{x:1366,y:776,t:1526929992067};\\\", \\\"{x:1366,y:775,t:1526929992124};\\\", \\\"{x:1363,y:775,t:1526929992245};\\\", \\\"{x:1357,y:770,t:1526929992253};\\\", \\\"{x:1346,y:769,t:1526929992268};\\\", \\\"{x:1267,y:746,t:1526929992284};\\\", \\\"{x:1149,y:719,t:1526929992300};\\\", \\\"{x:1024,y:683,t:1526929992318};\\\", \\\"{x:897,y:645,t:1526929992339};\\\", \\\"{x:755,y:603,t:1526929992357};\\\", \\\"{x:646,y:579,t:1526929992373};\\\", \\\"{x:562,y:554,t:1526929992388};\\\", \\\"{x:502,y:538,t:1526929992419};\\\", \\\"{x:500,y:537,t:1526929992435};\\\", \\\"{x:499,y:536,t:1526929992480};\\\", \\\"{x:497,y:536,t:1526929992488};\\\", \\\"{x:494,y:535,t:1526929992501};\\\", \\\"{x:488,y:532,t:1526929992518};\\\", \\\"{x:479,y:526,t:1526929992535};\\\", \\\"{x:469,y:522,t:1526929992552};\\\", \\\"{x:465,y:519,t:1526929992569};\\\", \\\"{x:459,y:518,t:1526929992585};\\\", \\\"{x:454,y:515,t:1526929992602};\\\", \\\"{x:433,y:510,t:1526929992617};\\\", \\\"{x:412,y:504,t:1526929992635};\\\", \\\"{x:398,y:502,t:1526929992652};\\\", \\\"{x:387,y:502,t:1526929992669};\\\", \\\"{x:378,y:502,t:1526929992685};\\\", \\\"{x:373,y:505,t:1526929992702};\\\", \\\"{x:369,y:507,t:1526929992721};\\\", \\\"{x:364,y:516,t:1526929992736};\\\", \\\"{x:358,y:523,t:1526929992752};\\\", \\\"{x:358,y:524,t:1526929992769};\\\", \\\"{x:358,y:525,t:1526929992792};\\\", \\\"{x:358,y:526,t:1526929992803};\\\", \\\"{x:357,y:528,t:1526929992819};\\\", \\\"{x:362,y:536,t:1526929992836};\\\", \\\"{x:369,y:539,t:1526929992854};\\\", \\\"{x:371,y:543,t:1526929992869};\\\", \\\"{x:372,y:544,t:1526929992887};\\\", \\\"{x:374,y:545,t:1526929992902};\\\", \\\"{x:375,y:546,t:1526929992927};\\\", \\\"{x:375,y:547,t:1526929992936};\\\", \\\"{x:377,y:548,t:1526929992951};\\\", \\\"{x:378,y:548,t:1526929993352};\\\", \\\"{x:380,y:548,t:1526929993359};\\\", \\\"{x:386,y:546,t:1526929993369};\\\", \\\"{x:394,y:545,t:1526929993386};\\\", \\\"{x:407,y:541,t:1526929993403};\\\", \\\"{x:421,y:537,t:1526929993419};\\\", \\\"{x:437,y:530,t:1526929993437};\\\", \\\"{x:453,y:521,t:1526929993452};\\\", \\\"{x:467,y:510,t:1526929993468};\\\", \\\"{x:480,y:500,t:1526929993487};\\\", \\\"{x:488,y:493,t:1526929993503};\\\", \\\"{x:498,y:484,t:1526929993519};\\\", \\\"{x:514,y:471,t:1526929993536};\\\", \\\"{x:517,y:469,t:1526929993553};\\\", \\\"{x:521,y:462,t:1526929993569};\\\", \\\"{x:523,y:458,t:1526929993586};\\\", \\\"{x:527,y:448,t:1526929993603};\\\", \\\"{x:530,y:436,t:1526929993619};\\\", \\\"{x:537,y:413,t:1526929993636};\\\", \\\"{x:537,y:409,t:1526929993653};\\\", \\\"{x:537,y:407,t:1526929993705};\\\", \\\"{x:535,y:403,t:1526929993720};\\\", \\\"{x:535,y:401,t:1526929993736};\\\", \\\"{x:516,y:378,t:1526930000817};\\\", \\\"{x:503,y:353,t:1526930000829};\\\", \\\"{x:500,y:330,t:1526930000846};\\\", \\\"{x:517,y:326,t:1526930000863};\\\", \\\"{x:540,y:319,t:1526930000880};\\\", \\\"{x:560,y:319,t:1526930000897};\\\", \\\"{x:584,y:321,t:1526930000913};\\\", \\\"{x:653,y:345,t:1526930000930};\\\", \\\"{x:745,y:374,t:1526930000946};\\\", \\\"{x:816,y:401,t:1526930000963};\\\", \\\"{x:871,y:433,t:1526930000980};\\\", \\\"{x:898,y:448,t:1526930000996};\\\", \\\"{x:916,y:465,t:1526930001013};\\\", \\\"{x:936,y:479,t:1526930001030};\\\", \\\"{x:955,y:487,t:1526930001045};\\\", \\\"{x:966,y:496,t:1526930001063};\\\", \\\"{x:975,y:511,t:1526930001080};\\\", \\\"{x:989,y:544,t:1526930001096};\\\", \\\"{x:1049,y:587,t:1526930001112};\\\", \\\"{x:1079,y:604,t:1526930001131};\\\", \\\"{x:1110,y:617,t:1526930001146};\\\", \\\"{x:1130,y:628,t:1526930001162};\\\", \\\"{x:1151,y:638,t:1526930001180};\\\", \\\"{x:1182,y:653,t:1526930001197};\\\", \\\"{x:1214,y:683,t:1526930001213};\\\", \\\"{x:1241,y:699,t:1526930001230};\\\", \\\"{x:1260,y:709,t:1526930001247};\\\", \\\"{x:1274,y:715,t:1526930001263};\\\", \\\"{x:1279,y:718,t:1526930001280};\\\", \\\"{x:1288,y:722,t:1526930001297};\\\", \\\"{x:1297,y:740,t:1526930001314};\\\", \\\"{x:1306,y:752,t:1526930001332};\\\", \\\"{x:1308,y:754,t:1526930001347};\\\", \\\"{x:1310,y:756,t:1526930001364};\\\", \\\"{x:1312,y:759,t:1526930001380};\\\", \\\"{x:1318,y:765,t:1526930001397};\\\", \\\"{x:1323,y:768,t:1526930001413};\\\", \\\"{x:1325,y:770,t:1526930001430};\\\", \\\"{x:1326,y:769,t:1526930001473};\\\", \\\"{x:1330,y:769,t:1526930001480};\\\", \\\"{x:1341,y:768,t:1526930001497};\\\", \\\"{x:1347,y:765,t:1526930001514};\\\", \\\"{x:1349,y:765,t:1526930001531};\\\", \\\"{x:1350,y:764,t:1526930001552};\\\", \\\"{x:1352,y:764,t:1526930001564};\\\", \\\"{x:1356,y:763,t:1526930001580};\\\", \\\"{x:1372,y:763,t:1526930001597};\\\", \\\"{x:1389,y:763,t:1526930001614};\\\", \\\"{x:1401,y:765,t:1526930001631};\\\", \\\"{x:1403,y:766,t:1526930001647};\\\", \\\"{x:1403,y:768,t:1526930001720};\\\", \\\"{x:1403,y:769,t:1526930001751};\\\", \\\"{x:1403,y:770,t:1526930001767};\\\", \\\"{x:1401,y:770,t:1526930001784};\\\", \\\"{x:1399,y:770,t:1526930001796};\\\", \\\"{x:1396,y:772,t:1526930001814};\\\", \\\"{x:1389,y:775,t:1526930001831};\\\", \\\"{x:1387,y:778,t:1526930001847};\\\", \\\"{x:1386,y:779,t:1526930001864};\\\", \\\"{x:1383,y:780,t:1526930001880};\\\", \\\"{x:1382,y:782,t:1526930001898};\\\", \\\"{x:1379,y:787,t:1526930001914};\\\", \\\"{x:1378,y:789,t:1526930001930};\\\", \\\"{x:1375,y:791,t:1526930001948};\\\", \\\"{x:1371,y:797,t:1526930001964};\\\", \\\"{x:1370,y:801,t:1526930001981};\\\", \\\"{x:1369,y:805,t:1526930001998};\\\", \\\"{x:1364,y:812,t:1526930002014};\\\", \\\"{x:1359,y:819,t:1526930002030};\\\", \\\"{x:1352,y:828,t:1526930002048};\\\", \\\"{x:1346,y:834,t:1526930002064};\\\", \\\"{x:1340,y:841,t:1526930002081};\\\", \\\"{x:1337,y:845,t:1526930002098};\\\", \\\"{x:1333,y:850,t:1526930002114};\\\", \\\"{x:1329,y:856,t:1526930002131};\\\", \\\"{x:1326,y:860,t:1526930002148};\\\", \\\"{x:1323,y:864,t:1526930002165};\\\", \\\"{x:1322,y:868,t:1526930002181};\\\", \\\"{x:1319,y:872,t:1526930002198};\\\", \\\"{x:1319,y:874,t:1526930002214};\\\", \\\"{x:1318,y:874,t:1526930002248};\\\", \\\"{x:1318,y:875,t:1526930002272};\\\", \\\"{x:1315,y:878,t:1526930002281};\\\", \\\"{x:1313,y:880,t:1526930002298};\\\", \\\"{x:1309,y:883,t:1526930002314};\\\", \\\"{x:1305,y:887,t:1526930002331};\\\", \\\"{x:1301,y:892,t:1526930002347};\\\", \\\"{x:1299,y:898,t:1526930002365};\\\", \\\"{x:1295,y:904,t:1526930002380};\\\", \\\"{x:1291,y:909,t:1526930002398};\\\", \\\"{x:1290,y:912,t:1526930002415};\\\", \\\"{x:1288,y:915,t:1526930002432};\\\", \\\"{x:1285,y:924,t:1526930002448};\\\", \\\"{x:1284,y:937,t:1526930002464};\\\", \\\"{x:1284,y:943,t:1526930002482};\\\", \\\"{x:1284,y:947,t:1526930002498};\\\", \\\"{x:1283,y:950,t:1526930002514};\\\", \\\"{x:1283,y:951,t:1526930002553};\\\", \\\"{x:1283,y:952,t:1526930002568};\\\", \\\"{x:1283,y:953,t:1526930002584};\\\", \\\"{x:1281,y:955,t:1526930002597};\\\", \\\"{x:1280,y:961,t:1526930002615};\\\", \\\"{x:1279,y:964,t:1526930002632};\\\", \\\"{x:1278,y:966,t:1526930002649};\\\", \\\"{x:1278,y:969,t:1526930002665};\\\", \\\"{x:1278,y:970,t:1526930002682};\\\", \\\"{x:1278,y:971,t:1526930002699};\\\", \\\"{x:1280,y:969,t:1526930003184};\\\", \\\"{x:1282,y:967,t:1526930003200};\\\", \\\"{x:1292,y:959,t:1526930003216};\\\", \\\"{x:1309,y:944,t:1526930003232};\\\", \\\"{x:1317,y:935,t:1526930003248};\\\", \\\"{x:1325,y:927,t:1526930003266};\\\", \\\"{x:1327,y:922,t:1526930003283};\\\", \\\"{x:1330,y:920,t:1526930003299};\\\", \\\"{x:1332,y:918,t:1526930003316};\\\", \\\"{x:1332,y:917,t:1526930003333};\\\", \\\"{x:1334,y:917,t:1526930003352};\\\", \\\"{x:1334,y:916,t:1526930003368};\\\", \\\"{x:1335,y:916,t:1526930003383};\\\", \\\"{x:1337,y:915,t:1526930003399};\\\", \\\"{x:1338,y:914,t:1526930003416};\\\", \\\"{x:1340,y:913,t:1526930003432};\\\", \\\"{x:1342,y:911,t:1526930003449};\\\", \\\"{x:1342,y:907,t:1526930003466};\\\", \\\"{x:1343,y:904,t:1526930003483};\\\", \\\"{x:1345,y:902,t:1526930003500};\\\", \\\"{x:1346,y:901,t:1526930003519};\\\", \\\"{x:1346,y:900,t:1526930003532};\\\", \\\"{x:1347,y:899,t:1526930003549};\\\", \\\"{x:1348,y:899,t:1526930003565};\\\", \\\"{x:1348,y:898,t:1526930003582};\\\", \\\"{x:1348,y:897,t:1526930003599};\\\", \\\"{x:1348,y:896,t:1526930004225};\\\", \\\"{x:1347,y:896,t:1526930004248};\\\", \\\"{x:1347,y:898,t:1526930004256};\\\", \\\"{x:1347,y:899,t:1526930004273};\\\", \\\"{x:1346,y:902,t:1526930004283};\\\", \\\"{x:1345,y:903,t:1526930004302};\\\", \\\"{x:1345,y:905,t:1526930004317};\\\", \\\"{x:1344,y:907,t:1526930004334};\\\", \\\"{x:1342,y:909,t:1526930004352};\\\", \\\"{x:1341,y:910,t:1526930004368};\\\", \\\"{x:1341,y:912,t:1526930004384};\\\", \\\"{x:1341,y:914,t:1526930004400};\\\", \\\"{x:1340,y:916,t:1526930004416};\\\", \\\"{x:1338,y:919,t:1526930004434};\\\", \\\"{x:1337,y:922,t:1526930004450};\\\", \\\"{x:1334,y:927,t:1526930004466};\\\", \\\"{x:1331,y:931,t:1526930004484};\\\", \\\"{x:1330,y:934,t:1526930004501};\\\", \\\"{x:1329,y:937,t:1526930004517};\\\", \\\"{x:1327,y:941,t:1526930004534};\\\", \\\"{x:1325,y:944,t:1526930004550};\\\", \\\"{x:1323,y:947,t:1526930004568};\\\", \\\"{x:1323,y:948,t:1526930004593};\\\", \\\"{x:1322,y:951,t:1526930004656};\\\", \\\"{x:1322,y:952,t:1526930004668};\\\", \\\"{x:1320,y:956,t:1526930004684};\\\", \\\"{x:1319,y:958,t:1526930004701};\\\", \\\"{x:1317,y:960,t:1526930004718};\\\", \\\"{x:1316,y:961,t:1526930004734};\\\", \\\"{x:1314,y:962,t:1526930004751};\\\", \\\"{x:1313,y:963,t:1526930004768};\\\", \\\"{x:1312,y:963,t:1526930004865};\\\", \\\"{x:1312,y:964,t:1526930004880};\\\", \\\"{x:1312,y:965,t:1526930004945};\\\", \\\"{x:1313,y:965,t:1526930005129};\\\", \\\"{x:1314,y:965,t:1526930005136};\\\", \\\"{x:1320,y:965,t:1526930005151};\\\", \\\"{x:1326,y:966,t:1526930005167};\\\", \\\"{x:1331,y:966,t:1526930005185};\\\", \\\"{x:1339,y:968,t:1526930005201};\\\", \\\"{x:1343,y:969,t:1526930005217};\\\", \\\"{x:1347,y:969,t:1526930005234};\\\", \\\"{x:1349,y:969,t:1526930005256};\\\", \\\"{x:1351,y:969,t:1526930005288};\\\", \\\"{x:1353,y:969,t:1526930005301};\\\", \\\"{x:1356,y:969,t:1526930005317};\\\", \\\"{x:1360,y:969,t:1526930005334};\\\", \\\"{x:1365,y:967,t:1526930005352};\\\", \\\"{x:1366,y:966,t:1526930005369};\\\", \\\"{x:1367,y:965,t:1526930005385};\\\", \\\"{x:1371,y:965,t:1526930005401};\\\", \\\"{x:1374,y:965,t:1526930005419};\\\", \\\"{x:1376,y:965,t:1526930005434};\\\", \\\"{x:1378,y:965,t:1526930005452};\\\", \\\"{x:1380,y:965,t:1526930005468};\\\", \\\"{x:1381,y:965,t:1526930005485};\\\", \\\"{x:1382,y:966,t:1526930005501};\\\", \\\"{x:1384,y:967,t:1526930005519};\\\", \\\"{x:1376,y:964,t:1526930005705};\\\", \\\"{x:1360,y:960,t:1526930005719};\\\", \\\"{x:1242,y:919,t:1526930005736};\\\", \\\"{x:1127,y:894,t:1526930005753};\\\", \\\"{x:1015,y:868,t:1526930005768};\\\", \\\"{x:920,y:852,t:1526930005786};\\\", \\\"{x:864,y:838,t:1526930005802};\\\", \\\"{x:767,y:810,t:1526930005819};\\\", \\\"{x:718,y:799,t:1526930005836};\\\", \\\"{x:704,y:795,t:1526930005852};\\\", \\\"{x:699,y:794,t:1526930005869};\\\", \\\"{x:694,y:794,t:1526930005886};\\\", \\\"{x:692,y:793,t:1526930005903};\\\", \\\"{x:689,y:793,t:1526930005919};\\\", \\\"{x:666,y:793,t:1526930005936};\\\", \\\"{x:651,y:795,t:1526930005952};\\\", \\\"{x:641,y:795,t:1526930005969};\\\", \\\"{x:635,y:798,t:1526930005985};\\\", \\\"{x:634,y:798,t:1526930006041};\\\", \\\"{x:634,y:797,t:1526930006053};\\\", \\\"{x:634,y:785,t:1526930006069};\\\", \\\"{x:623,y:773,t:1526930006086};\\\", \\\"{x:612,y:764,t:1526930006102};\\\", \\\"{x:599,y:757,t:1526930006119};\\\", \\\"{x:574,y:744,t:1526930006137};\\\", \\\"{x:567,y:741,t:1526930006153};\\\", \\\"{x:566,y:740,t:1526930006169};\\\", \\\"{x:565,y:740,t:1526930006208};\\\", \\\"{x:563,y:740,t:1526930006223};\\\", \\\"{x:561,y:739,t:1526930006235};\\\", \\\"{x:555,y:735,t:1526930006253};\\\", \\\"{x:547,y:734,t:1526930006269};\\\", \\\"{x:543,y:732,t:1526930006285};\\\", \\\"{x:542,y:731,t:1526930006296};\\\", \\\"{x:540,y:730,t:1526930006313};\\\", \\\"{x:539,y:730,t:1526930006330};\\\", \\\"{x:537,y:728,t:1526930006346};\\\", \\\"{x:535,y:725,t:1526930006363};\\\", \\\"{x:532,y:723,t:1526930006379};\\\", \\\"{x:532,y:722,t:1526930006396};\\\", \\\"{x:533,y:722,t:1526930006695};\\\", \\\"{x:541,y:722,t:1526930006713};\\\", \\\"{x:559,y:730,t:1526930006730};\\\", \\\"{x:582,y:742,t:1526930006746};\\\", \\\"{x:617,y:753,t:1526930006764};\\\", \\\"{x:658,y:771,t:1526930006780};\\\", \\\"{x:677,y:775,t:1526930006796};\\\", \\\"{x:702,y:780,t:1526930006813};\\\", \\\"{x:717,y:784,t:1526930006830};\\\", \\\"{x:726,y:787,t:1526930006846};\\\", \\\"{x:730,y:788,t:1526930006863};\\\", \\\"{x:731,y:788,t:1526930006969};\\\", \\\"{x:731,y:786,t:1526930007000};\\\", \\\"{x:728,y:785,t:1526930007014};\\\", \\\"{x:723,y:782,t:1526930007031};\\\", \\\"{x:714,y:776,t:1526930007048};\\\", \\\"{x:709,y:774,t:1526930007064};\\\", \\\"{x:707,y:773,t:1526930007081};\\\", \\\"{x:705,y:772,t:1526930007097};\\\", \\\"{x:703,y:771,t:1526930007114};\\\", \\\"{x:698,y:768,t:1526930007130};\\\", \\\"{x:689,y:764,t:1526930007147};\\\", \\\"{x:684,y:760,t:1526930007163};\\\", \\\"{x:681,y:759,t:1526930007180};\\\", \\\"{x:679,y:758,t:1526930007197};\\\", \\\"{x:677,y:758,t:1526930007214};\\\", \\\"{x:674,y:756,t:1526930007230};\\\", \\\"{x:671,y:756,t:1526930007248};\\\", \\\"{x:670,y:754,t:1526930007264};\\\", \\\"{x:670,y:758,t:1526930007376};\\\", \\\"{x:670,y:762,t:1526930007384};\\\", \\\"{x:670,y:765,t:1526930007397};\\\", \\\"{x:670,y:770,t:1526930007414};\\\", \\\"{x:669,y:779,t:1526930007431};\\\", \\\"{x:667,y:787,t:1526930007448};\\\", \\\"{x:666,y:790,t:1526930007464};\\\", \\\"{x:666,y:793,t:1526930007480};\\\", \\\"{x:665,y:795,t:1526930007497};\\\" ] }, { \\\"rt\\\": 8183, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 8, \\\"time_elapsed\\\": 367763, \\\"internal_node_id\\\": \\\"0.0-5.0-3.0\\\", \\\"subject\\\": \\\"GQ35Z\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"charlie\\\", \\\"condition\\\": \\\"111\\\", \\\"scenario\\\": \\\"acme\\\", \\\"question\\\": \\\"endtime\\\", \\\"q\\\": 4, \\\"clicks\\\": 1.5, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XInside-YFull\\\", \\\"correct\\\": 1, \\\"orth_correct\\\": 0, \\\"answer\\\": [ \\\"H\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"X \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"U \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-03 PM-04 PM\\\", \\\"block\\\": \\\"triangular_scaffolded\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:674,y:798,t:1526930008214};\\\", \\\"{x:678,y:800,t:1526930008220};\\\", \\\"{x:683,y:801,t:1526930008231};\\\", \\\"{x:695,y:804,t:1526930008248};\\\", \\\"{x:706,y:806,t:1526930008264};\\\", \\\"{x:712,y:806,t:1526930008282};\\\", \\\"{x:716,y:806,t:1526930008297};\\\", \\\"{x:652,y:804,t:1526930008684};\\\", \\\"{x:652,y:804,t:1526930008768};\\\", \\\"{x:654,y:804,t:1526930010208};\\\", \\\"{x:655,y:803,t:1526930010216};\\\", \\\"{x:658,y:803,t:1526930010232};\\\", \\\"{x:660,y:803,t:1526930010249};\\\", \\\"{x:666,y:803,t:1526930010266};\\\", \\\"{x:675,y:803,t:1526930010282};\\\", \\\"{x:681,y:803,t:1526930010299};\\\", \\\"{x:689,y:807,t:1526930010316};\\\", \\\"{x:696,y:807,t:1526930010332};\\\", \\\"{x:698,y:809,t:1526930010350};\\\", \\\"{x:700,y:809,t:1526930010366};\\\", \\\"{x:710,y:809,t:1526930010383};\\\", \\\"{x:716,y:806,t:1526930010399};\\\", \\\"{x:720,y:804,t:1526930010416};\\\", \\\"{x:726,y:801,t:1526930010433};\\\", \\\"{x:732,y:798,t:1526930010449};\\\", \\\"{x:745,y:795,t:1526930010466};\\\", \\\"{x:762,y:795,t:1526930010482};\\\", \\\"{x:776,y:791,t:1526930010499};\\\", \\\"{x:790,y:789,t:1526930010517};\\\", \\\"{x:814,y:789,t:1526930010534};\\\", \\\"{x:835,y:789,t:1526930010549};\\\", \\\"{x:845,y:789,t:1526930010567};\\\", \\\"{x:884,y:788,t:1526930010583};\\\", \\\"{x:911,y:794,t:1526930010600};\\\", \\\"{x:942,y:804,t:1526930010617};\\\", \\\"{x:964,y:808,t:1526930010634};\\\", \\\"{x:988,y:817,t:1526930010650};\\\", \\\"{x:1011,y:824,t:1526930010667};\\\", \\\"{x:1024,y:832,t:1526930010684};\\\", \\\"{x:1040,y:838,t:1526930010700};\\\", \\\"{x:1056,y:846,t:1526930010717};\\\", \\\"{x:1072,y:854,t:1526930010734};\\\", \\\"{x:1088,y:864,t:1526930010750};\\\", \\\"{x:1106,y:875,t:1526930010767};\\\", \\\"{x:1143,y:901,t:1526930010784};\\\", \\\"{x:1160,y:908,t:1526930010801};\\\", \\\"{x:1191,y:918,t:1526930010817};\\\", \\\"{x:1235,y:928,t:1526930010834};\\\", \\\"{x:1262,y:937,t:1526930010850};\\\", \\\"{x:1310,y:945,t:1526930010867};\\\", \\\"{x:1355,y:952,t:1526930010884};\\\", \\\"{x:1399,y:951,t:1526930010901};\\\", \\\"{x:1424,y:952,t:1526930010917};\\\", \\\"{x:1446,y:953,t:1526930010934};\\\", \\\"{x:1462,y:956,t:1526930010951};\\\", \\\"{x:1481,y:958,t:1526930010967};\\\", \\\"{x:1507,y:964,t:1526930010985};\\\", \\\"{x:1524,y:970,t:1526930011001};\\\", \\\"{x:1541,y:975,t:1526930011018};\\\", \\\"{x:1557,y:979,t:1526930011034};\\\", \\\"{x:1564,y:982,t:1526930011051};\\\", \\\"{x:1573,y:984,t:1526930011068};\\\", \\\"{x:1579,y:987,t:1526930011084};\\\", \\\"{x:1581,y:987,t:1526930011101};\\\", \\\"{x:1582,y:987,t:1526930011209};\\\", \\\"{x:1583,y:987,t:1526930011217};\\\", \\\"{x:1588,y:986,t:1526930011234};\\\", \\\"{x:1594,y:984,t:1526930011251};\\\", \\\"{x:1600,y:983,t:1526930011267};\\\", \\\"{x:1604,y:981,t:1526930011284};\\\", \\\"{x:1607,y:978,t:1526930011301};\\\", \\\"{x:1608,y:978,t:1526930011317};\\\", \\\"{x:1609,y:977,t:1526930011334};\\\", \\\"{x:1611,y:977,t:1526930011361};\\\", \\\"{x:1613,y:975,t:1526930011376};\\\", \\\"{x:1615,y:974,t:1526930011384};\\\", \\\"{x:1617,y:972,t:1526930011401};\\\", \\\"{x:1617,y:971,t:1526930011584};\\\", \\\"{x:1617,y:968,t:1526930011602};\\\", \\\"{x:1617,y:967,t:1526930011624};\\\", \\\"{x:1617,y:966,t:1526930011634};\\\", \\\"{x:1616,y:963,t:1526930011651};\\\", \\\"{x:1614,y:960,t:1526930011667};\\\", \\\"{x:1612,y:958,t:1526930011684};\\\", \\\"{x:1609,y:955,t:1526930011701};\\\", \\\"{x:1608,y:953,t:1526930011718};\\\", \\\"{x:1608,y:951,t:1526930011734};\\\", \\\"{x:1605,y:948,t:1526930011750};\\\", \\\"{x:1604,y:944,t:1526930011767};\\\", \\\"{x:1604,y:943,t:1526930011785};\\\", \\\"{x:1602,y:941,t:1526930011801};\\\", \\\"{x:1598,y:935,t:1526930011818};\\\", \\\"{x:1594,y:930,t:1526930011835};\\\", \\\"{x:1591,y:926,t:1526930011851};\\\", \\\"{x:1589,y:923,t:1526930011867};\\\", \\\"{x:1586,y:920,t:1526930011884};\\\", \\\"{x:1582,y:917,t:1526930011901};\\\", \\\"{x:1579,y:915,t:1526930011917};\\\", \\\"{x:1578,y:912,t:1526930011934};\\\", \\\"{x:1576,y:909,t:1526930011951};\\\", \\\"{x:1573,y:906,t:1526930011967};\\\", \\\"{x:1573,y:905,t:1526930011992};\\\", \\\"{x:1573,y:902,t:1526930012001};\\\", \\\"{x:1572,y:901,t:1526930012018};\\\", \\\"{x:1571,y:898,t:1526930012034};\\\", \\\"{x:1570,y:896,t:1526930012050};\\\", \\\"{x:1569,y:892,t:1526930012067};\\\", \\\"{x:1566,y:887,t:1526930012085};\\\", \\\"{x:1564,y:883,t:1526930012100};\\\", \\\"{x:1562,y:877,t:1526930012117};\\\", \\\"{x:1561,y:873,t:1526930012135};\\\", \\\"{x:1557,y:866,t:1526930012151};\\\", \\\"{x:1540,y:841,t:1526930012168};\\\", \\\"{x:1528,y:824,t:1526930012185};\\\", \\\"{x:1523,y:815,t:1526930012201};\\\", \\\"{x:1519,y:809,t:1526930012217};\\\", \\\"{x:1512,y:799,t:1526930012235};\\\", \\\"{x:1508,y:791,t:1526930012251};\\\", \\\"{x:1498,y:776,t:1526930012268};\\\", \\\"{x:1488,y:764,t:1526930012285};\\\", \\\"{x:1481,y:755,t:1526930012302};\\\", \\\"{x:1477,y:749,t:1526930012318};\\\", \\\"{x:1475,y:743,t:1526930012335};\\\", \\\"{x:1472,y:738,t:1526930012352};\\\", \\\"{x:1472,y:733,t:1526930012369};\\\", \\\"{x:1469,y:729,t:1526930012385};\\\", \\\"{x:1468,y:720,t:1526930012403};\\\", \\\"{x:1464,y:711,t:1526930012418};\\\", \\\"{x:1463,y:707,t:1526930012435};\\\", \\\"{x:1463,y:703,t:1526930012452};\\\", \\\"{x:1462,y:696,t:1526930012469};\\\", \\\"{x:1461,y:688,t:1526930012485};\\\", \\\"{x:1459,y:670,t:1526930012502};\\\", \\\"{x:1454,y:658,t:1526930012518};\\\", \\\"{x:1450,y:645,t:1526930012535};\\\", \\\"{x:1449,y:634,t:1526930012552};\\\", \\\"{x:1449,y:627,t:1526930012568};\\\", \\\"{x:1449,y:623,t:1526930012585};\\\", \\\"{x:1446,y:617,t:1526930012602};\\\", \\\"{x:1442,y:609,t:1526930012618};\\\", \\\"{x:1438,y:602,t:1526930012635};\\\", \\\"{x:1436,y:599,t:1526930012652};\\\", \\\"{x:1434,y:595,t:1526930012668};\\\", \\\"{x:1433,y:593,t:1526930012685};\\\", \\\"{x:1433,y:591,t:1526930012702};\\\", \\\"{x:1429,y:588,t:1526930012719};\\\", \\\"{x:1426,y:584,t:1526930012735};\\\", \\\"{x:1424,y:582,t:1526930012752};\\\", \\\"{x:1423,y:580,t:1526930012776};\\\", \\\"{x:1423,y:578,t:1526930012801};\\\", \\\"{x:1423,y:577,t:1526930012816};\\\", \\\"{x:1422,y:576,t:1526930012824};\\\", \\\"{x:1420,y:576,t:1526930012840};\\\", \\\"{x:1415,y:573,t:1526930012853};\\\", \\\"{x:1404,y:572,t:1526930012870};\\\", \\\"{x:1388,y:572,t:1526930012885};\\\", \\\"{x:1369,y:572,t:1526930012902};\\\", \\\"{x:1330,y:572,t:1526930012920};\\\", \\\"{x:1255,y:572,t:1526930012936};\\\", \\\"{x:1097,y:572,t:1526930012953};\\\", \\\"{x:991,y:572,t:1526930012969};\\\", \\\"{x:880,y:570,t:1526930012986};\\\", \\\"{x:775,y:558,t:1526930013001};\\\", \\\"{x:734,y:554,t:1526930013019};\\\", \\\"{x:715,y:554,t:1526930013035};\\\", \\\"{x:712,y:554,t:1526930013052};\\\", \\\"{x:710,y:554,t:1526930013069};\\\", \\\"{x:709,y:554,t:1526930013087};\\\", \\\"{x:707,y:554,t:1526930013101};\\\", \\\"{x:693,y:559,t:1526930013119};\\\", \\\"{x:676,y:572,t:1526930013135};\\\", \\\"{x:668,y:583,t:1526930013153};\\\", \\\"{x:664,y:591,t:1526930013168};\\\", \\\"{x:662,y:594,t:1526930013186};\\\", \\\"{x:660,y:598,t:1526930013202};\\\", \\\"{x:660,y:599,t:1526930013240};\\\", \\\"{x:658,y:599,t:1526930013252};\\\", \\\"{x:651,y:599,t:1526930013269};\\\", \\\"{x:639,y:596,t:1526930013287};\\\", \\\"{x:618,y:585,t:1526930013302};\\\", \\\"{x:599,y:569,t:1526930013320};\\\", \\\"{x:592,y:565,t:1526930013336};\\\", \\\"{x:587,y:558,t:1526930013352};\\\", \\\"{x:586,y:556,t:1526930013368};\\\", \\\"{x:586,y:555,t:1526930013423};\\\", \\\"{x:587,y:554,t:1526930013487};\\\", \\\"{x:590,y:554,t:1526930013503};\\\", \\\"{x:595,y:557,t:1526930013519};\\\", \\\"{x:597,y:557,t:1526930013592};\\\", \\\"{x:598,y:557,t:1526930013602};\\\", \\\"{x:602,y:557,t:1526930013833};\\\", \\\"{x:624,y:564,t:1526930013853};\\\", \\\"{x:648,y:570,t:1526930013869};\\\", \\\"{x:695,y:580,t:1526930013886};\\\", \\\"{x:749,y:590,t:1526930013903};\\\", \\\"{x:813,y:599,t:1526930013919};\\\", \\\"{x:914,y:610,t:1526930013936};\\\", \\\"{x:979,y:622,t:1526930013953};\\\", \\\"{x:1035,y:630,t:1526930013969};\\\", \\\"{x:1068,y:632,t:1526930013986};\\\", \\\"{x:1092,y:632,t:1526930014002};\\\", \\\"{x:1107,y:632,t:1526930014018};\\\", \\\"{x:1116,y:623,t:1526930014035};\\\", \\\"{x:1118,y:622,t:1526930014052};\\\", \\\"{x:1123,y:620,t:1526930014068};\\\", \\\"{x:1126,y:618,t:1526930014085};\\\", \\\"{x:1127,y:617,t:1526930014102};\\\", \\\"{x:1126,y:617,t:1526930014216};\\\", \\\"{x:1120,y:618,t:1526930014224};\\\", \\\"{x:1112,y:620,t:1526930014236};\\\", \\\"{x:1089,y:623,t:1526930014252};\\\", \\\"{x:1069,y:625,t:1526930014269};\\\", \\\"{x:1046,y:625,t:1526930014285};\\\", \\\"{x:1023,y:624,t:1526930014303};\\\", \\\"{x:995,y:624,t:1526930014319};\\\", \\\"{x:971,y:629,t:1526930014335};\\\", \\\"{x:940,y:643,t:1526930014352};\\\", \\\"{x:917,y:649,t:1526930014368};\\\", \\\"{x:894,y:659,t:1526930014385};\\\", \\\"{x:877,y:663,t:1526930014402};\\\", \\\"{x:859,y:675,t:1526930014418};\\\", \\\"{x:836,y:685,t:1526930014435};\\\", \\\"{x:817,y:696,t:1526930014452};\\\", \\\"{x:797,y:704,t:1526930014468};\\\", \\\"{x:770,y:712,t:1526930014485};\\\", \\\"{x:744,y:716,t:1526930014501};\\\", \\\"{x:724,y:719,t:1526930014518};\\\", \\\"{x:715,y:720,t:1526930014535};\\\", \\\"{x:711,y:721,t:1526930014551};\\\", \\\"{x:709,y:721,t:1526930014568};\\\", \\\"{x:708,y:721,t:1526930014585};\\\", \\\"{x:705,y:721,t:1526930014601};\\\", \\\"{x:698,y:718,t:1526930014618};\\\", \\\"{x:680,y:713,t:1526930014634};\\\", \\\"{x:667,y:709,t:1526930014651};\\\", \\\"{x:652,y:709,t:1526930014668};\\\", \\\"{x:637,y:709,t:1526930014684};\\\", \\\"{x:622,y:708,t:1526930014701};\\\", \\\"{x:611,y:708,t:1526930014717};\\\", \\\"{x:598,y:708,t:1526930014734};\\\", \\\"{x:593,y:708,t:1526930014751};\\\", \\\"{x:589,y:708,t:1526930014767};\\\", \\\"{x:586,y:709,t:1526930014784};\\\", \\\"{x:582,y:711,t:1526930014801};\\\", \\\"{x:581,y:712,t:1526930014817};\\\", \\\"{x:576,y:713,t:1526930014834};\\\", \\\"{x:572,y:714,t:1526930014851};\\\", \\\"{x:568,y:714,t:1526930014867};\\\", \\\"{x:567,y:714,t:1526930014884};\\\", \\\"{x:569,y:711,t:1526930014920};\\\", \\\"{x:576,y:704,t:1526930014934};\\\", \\\"{x:581,y:691,t:1526930014950};\\\", \\\"{x:590,y:669,t:1526930014967};\\\", \\\"{x:595,y:647,t:1526930014985};\\\", \\\"{x:601,y:638,t:1526930015000};\\\", \\\"{x:601,y:631,t:1526930015020};\\\", \\\"{x:604,y:623,t:1526930015037};\\\", \\\"{x:605,y:616,t:1526930015053};\\\", \\\"{x:605,y:613,t:1526930015071};\\\", \\\"{x:606,y:608,t:1526930015087};\\\", \\\"{x:606,y:602,t:1526930015103};\\\", \\\"{x:606,y:599,t:1526930015119};\\\", \\\"{x:606,y:598,t:1526930015137};\\\", \\\"{x:606,y:596,t:1526930015153};\\\", \\\"{x:606,y:594,t:1526930015170};\\\", \\\"{x:608,y:591,t:1526930015187};\\\", \\\"{x:613,y:582,t:1526930015204};\\\", \\\"{x:614,y:576,t:1526930015221};\\\", \\\"{x:617,y:572,t:1526930015237};\\\", \\\"{x:617,y:569,t:1526930015254};\\\", \\\"{x:617,y:566,t:1526930015271};\\\", \\\"{x:616,y:566,t:1526930015431};\\\", \\\"{x:613,y:569,t:1526930015439};\\\", \\\"{x:613,y:574,t:1526930015453};\\\", \\\"{x:613,y:580,t:1526930015471};\\\", \\\"{x:613,y:603,t:1526930015487};\\\", \\\"{x:605,y:637,t:1526930015504};\\\", \\\"{x:599,y:655,t:1526930015521};\\\", \\\"{x:589,y:671,t:1526930015537};\\\", \\\"{x:584,y:676,t:1526930015553};\\\", \\\"{x:580,y:682,t:1526930015570};\\\", \\\"{x:578,y:684,t:1526930015587};\\\", \\\"{x:578,y:685,t:1526930015604};\\\", \\\"{x:576,y:687,t:1526930015621};\\\", \\\"{x:573,y:689,t:1526930015636};\\\", \\\"{x:569,y:691,t:1526930015654};\\\", \\\"{x:562,y:696,t:1526930015671};\\\", \\\"{x:556,y:699,t:1526930015686};\\\", \\\"{x:548,y:702,t:1526930015704};\\\", \\\"{x:541,y:704,t:1526930015721};\\\", \\\"{x:538,y:704,t:1526930015738};\\\", \\\"{x:536,y:705,t:1526930015754};\\\", \\\"{x:537,y:705,t:1526930015938};\\\", \\\"{x:550,y:705,t:1526930015953};\\\", \\\"{x:581,y:705,t:1526930015971};\\\", \\\"{x:609,y:708,t:1526930015988};\\\", \\\"{x:643,y:711,t:1526930016004};\\\", \\\"{x:666,y:715,t:1526930016021};\\\", \\\"{x:684,y:717,t:1526930016038};\\\", \\\"{x:690,y:718,t:1526930016054};\\\", \\\"{x:693,y:718,t:1526930016071};\\\", \\\"{x:697,y:720,t:1526930016087};\\\", \\\"{x:709,y:724,t:1526930016104};\\\", \\\"{x:722,y:730,t:1526930016120};\\\", \\\"{x:739,y:737,t:1526930016137};\\\", \\\"{x:750,y:740,t:1526930016154};\\\", \\\"{x:754,y:741,t:1526930016171};\\\", \\\"{x:755,y:741,t:1526930016188};\\\" ] }, { \\\"rt\\\": 12386, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 9, \\\"time_elapsed\\\": 381373, \\\"internal_node_id\\\": \\\"0.0-5.0-4.0\\\", \\\"subject\\\": \\\"GQ35Z\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"charlie\\\", \\\"condition\\\": \\\"111\\\", \\\"scenario\\\": \\\"acme\\\", \\\"question\\\": \\\"midpoint\\\", \\\"q\\\": 5, \\\"clicks\\\": 1, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XInside-YFull\\\", \\\"correct\\\": 1, \\\"orth_correct\\\": 0, \\\"answer\\\": [ \\\"O\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"X \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"U \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-2-I -I \\\", \\\"block\\\": \\\"triangular_scaffolded\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:756,y:742,t:1526930017335};\\\", \\\"{x:759,y:757,t:1526930017622};\\\", \\\"{x:760,y:759,t:1526930017639};\\\", \\\"{x:761,y:760,t:1526930017655};\\\", \\\"{x:762,y:760,t:1526930017671};\\\", \\\"{x:762,y:761,t:1526930017689};\\\", \\\"{x:762,y:761,t:1526930017747};\\\", \\\"{x:708,y:743,t:1526930018082};\\\", \\\"{x:708,y:743,t:1526930018169};\\\", \\\"{x:707,y:743,t:1526930021248};\\\", \\\"{x:707,y:742,t:1526930021258};\\\", \\\"{x:711,y:742,t:1526930021275};\\\", \\\"{x:726,y:744,t:1526930021292};\\\", \\\"{x:742,y:749,t:1526930021309};\\\", \\\"{x:766,y:755,t:1526930021325};\\\", \\\"{x:787,y:763,t:1526930021343};\\\", \\\"{x:810,y:771,t:1526930021358};\\\", \\\"{x:837,y:781,t:1526930021375};\\\", \\\"{x:873,y:793,t:1526930021392};\\\", \\\"{x:892,y:797,t:1526930021409};\\\", \\\"{x:920,y:804,t:1526930021425};\\\", \\\"{x:944,y:810,t:1526930021443};\\\", \\\"{x:966,y:815,t:1526930021458};\\\", \\\"{x:987,y:817,t:1526930021476};\\\", \\\"{x:1006,y:818,t:1526930021493};\\\", \\\"{x:1025,y:822,t:1526930021508};\\\", \\\"{x:1039,y:823,t:1526930021525};\\\", \\\"{x:1050,y:824,t:1526930021542};\\\", \\\"{x:1061,y:826,t:1526930021559};\\\", \\\"{x:1082,y:828,t:1526930021577};\\\", \\\"{x:1106,y:828,t:1526930021592};\\\", \\\"{x:1137,y:828,t:1526930021609};\\\", \\\"{x:1203,y:819,t:1526930021626};\\\", \\\"{x:1258,y:813,t:1526930021642};\\\", \\\"{x:1296,y:811,t:1526930021660};\\\", \\\"{x:1340,y:807,t:1526930021675};\\\", \\\"{x:1382,y:797,t:1526930021692};\\\", \\\"{x:1413,y:787,t:1526930021710};\\\", \\\"{x:1433,y:781,t:1526930021726};\\\", \\\"{x:1458,y:773,t:1526930021743};\\\", \\\"{x:1481,y:765,t:1526930021759};\\\", \\\"{x:1489,y:761,t:1526930021776};\\\", \\\"{x:1494,y:757,t:1526930021793};\\\", \\\"{x:1496,y:753,t:1526930021810};\\\", \\\"{x:1496,y:747,t:1526930021826};\\\", \\\"{x:1494,y:731,t:1526930021842};\\\", \\\"{x:1477,y:714,t:1526930021860};\\\", \\\"{x:1455,y:692,t:1526930021876};\\\", \\\"{x:1440,y:680,t:1526930021892};\\\", \\\"{x:1431,y:671,t:1526930021909};\\\", \\\"{x:1417,y:662,t:1526930021925};\\\", \\\"{x:1404,y:653,t:1526930021942};\\\", \\\"{x:1392,y:646,t:1526930021960};\\\", \\\"{x:1383,y:637,t:1526930021976};\\\", \\\"{x:1376,y:628,t:1526930021993};\\\", \\\"{x:1367,y:616,t:1526930022010};\\\", \\\"{x:1365,y:614,t:1526930022025};\\\", \\\"{x:1363,y:611,t:1526930022043};\\\", \\\"{x:1362,y:606,t:1526930022059};\\\", \\\"{x:1359,y:597,t:1526930022076};\\\", \\\"{x:1355,y:588,t:1526930022092};\\\", \\\"{x:1351,y:576,t:1526930022109};\\\", \\\"{x:1350,y:572,t:1526930022126};\\\", \\\"{x:1350,y:571,t:1526930022142};\\\", \\\"{x:1349,y:564,t:1526930022159};\\\", \\\"{x:1347,y:557,t:1526930022175};\\\", \\\"{x:1347,y:548,t:1526930022192};\\\", \\\"{x:1343,y:537,t:1526930022208};\\\", \\\"{x:1341,y:531,t:1526930022226};\\\", \\\"{x:1340,y:525,t:1526930022242};\\\", \\\"{x:1339,y:518,t:1526930022259};\\\", \\\"{x:1337,y:513,t:1526930022277};\\\", \\\"{x:1334,y:511,t:1526930022292};\\\", \\\"{x:1329,y:500,t:1526930022309};\\\", \\\"{x:1324,y:494,t:1526930022326};\\\", \\\"{x:1322,y:491,t:1526930022342};\\\", \\\"{x:1322,y:490,t:1526930022360};\\\", \\\"{x:1321,y:489,t:1526930022376};\\\", \\\"{x:1321,y:488,t:1526930022393};\\\", \\\"{x:1320,y:486,t:1526930022417};\\\", \\\"{x:1318,y:486,t:1526930022553};\\\", \\\"{x:1316,y:486,t:1526930022568};\\\", \\\"{x:1311,y:488,t:1526930022576};\\\", \\\"{x:1309,y:490,t:1526930022594};\\\", \\\"{x:1306,y:491,t:1526930022610};\\\", \\\"{x:1304,y:493,t:1526930022626};\\\", \\\"{x:1304,y:495,t:1526930022761};\\\", \\\"{x:1304,y:496,t:1526930022849};\\\", \\\"{x:1305,y:496,t:1526930022864};\\\", \\\"{x:1307,y:496,t:1526930023120};\\\", \\\"{x:1308,y:496,t:1526930023872};\\\", \\\"{x:1309,y:496,t:1526930023883};\\\", \\\"{x:1307,y:496,t:1526930024521};\\\", \\\"{x:1303,y:500,t:1526930024528};\\\", \\\"{x:1288,y:506,t:1526930024545};\\\", \\\"{x:1260,y:517,t:1526930024561};\\\", \\\"{x:1229,y:531,t:1526930024577};\\\", \\\"{x:1180,y:544,t:1526930024595};\\\", \\\"{x:1116,y:563,t:1526930024612};\\\", \\\"{x:1036,y:579,t:1526930024627};\\\", \\\"{x:953,y:590,t:1526930024645};\\\", \\\"{x:892,y:598,t:1526930024663};\\\", \\\"{x:858,y:604,t:1526930024677};\\\", \\\"{x:834,y:607,t:1526930024694};\\\", \\\"{x:803,y:611,t:1526930024711};\\\", \\\"{x:784,y:615,t:1526930024728};\\\", \\\"{x:773,y:615,t:1526930024744};\\\", \\\"{x:756,y:617,t:1526930024761};\\\", \\\"{x:736,y:617,t:1526930024778};\\\", \\\"{x:715,y:617,t:1526930024795};\\\", \\\"{x:698,y:615,t:1526930024811};\\\", \\\"{x:689,y:613,t:1526930024828};\\\", \\\"{x:673,y:610,t:1526930024844};\\\", \\\"{x:653,y:607,t:1526930024861};\\\", \\\"{x:632,y:603,t:1526930024878};\\\", \\\"{x:615,y:600,t:1526930024894};\\\", \\\"{x:600,y:599,t:1526930024911};\\\", \\\"{x:594,y:599,t:1526930024929};\\\", \\\"{x:583,y:598,t:1526930024945};\\\", \\\"{x:570,y:598,t:1526930024961};\\\", \\\"{x:554,y:598,t:1526930024978};\\\", \\\"{x:540,y:597,t:1526930024995};\\\", \\\"{x:531,y:597,t:1526930025011};\\\", \\\"{x:516,y:597,t:1526930025027};\\\", \\\"{x:504,y:597,t:1526930025045};\\\", \\\"{x:490,y:597,t:1526930025062};\\\", \\\"{x:484,y:598,t:1526930025078};\\\", \\\"{x:482,y:599,t:1526930025095};\\\", \\\"{x:480,y:601,t:1526930025111};\\\", \\\"{x:480,y:605,t:1526930025127};\\\", \\\"{x:480,y:615,t:1526930025145};\\\", \\\"{x:480,y:625,t:1526930025162};\\\", \\\"{x:483,y:642,t:1526930025178};\\\", \\\"{x:492,y:655,t:1526930025195};\\\", \\\"{x:500,y:664,t:1526930025212};\\\", \\\"{x:513,y:676,t:1526930025228};\\\", \\\"{x:523,y:682,t:1526930025245};\\\", \\\"{x:527,y:685,t:1526930025262};\\\", \\\"{x:536,y:686,t:1526930025278};\\\", \\\"{x:576,y:693,t:1526930025295};\\\", \\\"{x:597,y:693,t:1526930025312};\\\", \\\"{x:611,y:691,t:1526930025328};\\\", \\\"{x:627,y:685,t:1526930025345};\\\", \\\"{x:646,y:677,t:1526930025362};\\\", \\\"{x:664,y:666,t:1526930025378};\\\", \\\"{x:689,y:654,t:1526930025396};\\\", \\\"{x:713,y:643,t:1526930025412};\\\", \\\"{x:724,y:638,t:1526930025428};\\\", \\\"{x:742,y:630,t:1526930025446};\\\", \\\"{x:756,y:623,t:1526930025462};\\\", \\\"{x:763,y:621,t:1526930025478};\\\", \\\"{x:770,y:616,t:1526930025495};\\\", \\\"{x:773,y:611,t:1526930025512};\\\", \\\"{x:776,y:605,t:1526930025528};\\\", \\\"{x:780,y:597,t:1526930025545};\\\", \\\"{x:784,y:590,t:1526930025563};\\\", \\\"{x:788,y:587,t:1526930025579};\\\", \\\"{x:797,y:580,t:1526930025594};\\\", \\\"{x:802,y:574,t:1526930025611};\\\", \\\"{x:807,y:566,t:1526930025628};\\\", \\\"{x:811,y:559,t:1526930025645};\\\", \\\"{x:814,y:554,t:1526930025661};\\\", \\\"{x:817,y:551,t:1526930025678};\\\", \\\"{x:824,y:548,t:1526930025696};\\\", \\\"{x:826,y:546,t:1526930025712};\\\", \\\"{x:828,y:544,t:1526930025729};\\\", \\\"{x:829,y:543,t:1526930025745};\\\", \\\"{x:829,y:541,t:1526930025762};\\\", \\\"{x:831,y:538,t:1526930025779};\\\", \\\"{x:834,y:536,t:1526930025795};\\\", \\\"{x:837,y:534,t:1526930025812};\\\", \\\"{x:837,y:533,t:1526930025880};\\\", \\\"{x:836,y:533,t:1526930025996};\\\", \\\"{x:834,y:533,t:1526930026012};\\\", \\\"{x:832,y:534,t:1526930026029};\\\", \\\"{x:829,y:535,t:1526930026045};\\\", \\\"{x:824,y:539,t:1526930026062};\\\", \\\"{x:816,y:556,t:1526930026079};\\\", \\\"{x:811,y:570,t:1526930026097};\\\", \\\"{x:804,y:588,t:1526930026112};\\\", \\\"{x:794,y:605,t:1526930026130};\\\", \\\"{x:788,y:619,t:1526930026146};\\\", \\\"{x:783,y:629,t:1526930026163};\\\", \\\"{x:777,y:641,t:1526930026179};\\\", \\\"{x:771,y:650,t:1526930026196};\\\", \\\"{x:764,y:657,t:1526930026212};\\\", \\\"{x:760,y:663,t:1526930026229};\\\", \\\"{x:752,y:668,t:1526930026246};\\\", \\\"{x:748,y:671,t:1526930026262};\\\", \\\"{x:739,y:676,t:1526930026280};\\\", \\\"{x:735,y:681,t:1526930026296};\\\", \\\"{x:727,y:688,t:1526930026313};\\\", \\\"{x:716,y:696,t:1526930026329};\\\", \\\"{x:708,y:701,t:1526930026346};\\\", \\\"{x:699,y:706,t:1526930026362};\\\", \\\"{x:691,y:711,t:1526930026379};\\\", \\\"{x:685,y:716,t:1526930026396};\\\", \\\"{x:679,y:719,t:1526930026413};\\\", \\\"{x:674,y:722,t:1526930026429};\\\", \\\"{x:672,y:723,t:1526930026447};\\\", \\\"{x:667,y:725,t:1526930026462};\\\", \\\"{x:657,y:729,t:1526930026480};\\\", \\\"{x:651,y:731,t:1526930026497};\\\", \\\"{x:643,y:732,t:1526930026514};\\\", \\\"{x:637,y:734,t:1526930026529};\\\", \\\"{x:632,y:735,t:1526930026546};\\\", \\\"{x:626,y:737,t:1526930026564};\\\", \\\"{x:622,y:739,t:1526930026580};\\\", \\\"{x:620,y:741,t:1526930026597};\\\", \\\"{x:614,y:745,t:1526930026613};\\\", \\\"{x:610,y:751,t:1526930026630};\\\", \\\"{x:606,y:757,t:1526930026647};\\\", \\\"{x:602,y:764,t:1526930026663};\\\", \\\"{x:600,y:770,t:1526930026680};\\\", \\\"{x:598,y:771,t:1526930026696};\\\", \\\"{x:597,y:774,t:1526930026714};\\\", \\\"{x:596,y:776,t:1526930026729};\\\", \\\"{x:594,y:778,t:1526930026746};\\\", \\\"{x:593,y:780,t:1526930026763};\\\", \\\"{x:592,y:781,t:1526930026780};\\\", \\\"{x:590,y:783,t:1526930026796};\\\", \\\"{x:589,y:784,t:1526930026814};\\\", \\\"{x:588,y:785,t:1526930026829};\\\", \\\"{x:588,y:786,t:1526930026904};\\\", \\\"{x:587,y:787,t:1526930026960};\\\", \\\"{x:586,y:788,t:1526930027024};\\\", \\\"{x:586,y:789,t:1526930027065};\\\", \\\"{x:584,y:790,t:1526930027087};\\\", \\\"{x:584,y:791,t:1526930027103};\\\", \\\"{x:583,y:792,t:1526930027120};\\\", \\\"{x:582,y:792,t:1526930027136};\\\", \\\"{x:582,y:793,t:1526930027160};\\\", \\\"{x:581,y:793,t:1526930027209};\\\", \\\"{x:579,y:795,t:1526930027239};\\\", \\\"{x:577,y:796,t:1526930027264};\\\", \\\"{x:575,y:796,t:1526930027312};\\\", \\\"{x:574,y:796,t:1526930027344};\\\", \\\"{x:571,y:796,t:1526930027351};\\\", \\\"{x:569,y:796,t:1526930027366};\\\", \\\"{x:567,y:796,t:1526930027379};\\\", \\\"{x:566,y:795,t:1526930028560};\\\", \\\"{x:566,y:794,t:1526930028576};\\\", \\\"{x:566,y:793,t:1526930028584};\\\", \\\"{x:565,y:791,t:1526930028599};\\\", \\\"{x:565,y:790,t:1526930028614};\\\", \\\"{x:562,y:786,t:1526930028631};\\\", \\\"{x:559,y:782,t:1526930028648};\\\", \\\"{x:558,y:781,t:1526930028672};\\\", \\\"{x:558,y:779,t:1526930028784};\\\", \\\"{x:558,y:777,t:1526930028800};\\\", \\\"{x:559,y:775,t:1526930028814};\\\", \\\"{x:562,y:771,t:1526930028832};\\\", \\\"{x:563,y:763,t:1526930028848};\\\", \\\"{x:564,y:756,t:1526930028865};\\\", \\\"{x:564,y:750,t:1526930028882};\\\", \\\"{x:564,y:744,t:1526930028899};\\\", \\\"{x:564,y:739,t:1526930028916};\\\", \\\"{x:564,y:736,t:1526930028931};\\\", \\\"{x:564,y:734,t:1526930028948};\\\", \\\"{x:564,y:732,t:1526930028964};\\\", \\\"{x:564,y:731,t:1526930028981};\\\", \\\"{x:563,y:731,t:1526930029007};\\\", \\\"{x:562,y:731,t:1526930029015};\\\", \\\"{x:561,y:731,t:1526930029038};\\\", \\\"{x:560,y:731,t:1526930029048};\\\", \\\"{x:557,y:731,t:1526930029064};\\\", \\\"{x:552,y:735,t:1526930029081};\\\", \\\"{x:547,y:738,t:1526930029098};\\\", \\\"{x:540,y:740,t:1526930029115};\\\", \\\"{x:530,y:742,t:1526930029131};\\\", \\\"{x:524,y:743,t:1526930029148};\\\", \\\"{x:518,y:744,t:1526930029165};\\\", \\\"{x:517,y:744,t:1526930029207};\\\", \\\"{x:516,y:744,t:1526930029264};\\\", \\\"{x:515,y:744,t:1526930029272};\\\", \\\"{x:512,y:743,t:1526930029288};\\\", \\\"{x:510,y:741,t:1526930029303};\\\", \\\"{x:510,y:739,t:1526930029316};\\\", \\\"{x:504,y:733,t:1526930029332};\\\", \\\"{x:501,y:728,t:1526930029349};\\\", \\\"{x:501,y:726,t:1526930029365};\\\", \\\"{x:503,y:726,t:1526930029607};\\\", \\\"{x:506,y:726,t:1526930029615};\\\", \\\"{x:521,y:735,t:1526930029632};\\\", \\\"{x:540,y:744,t:1526930029648};\\\", \\\"{x:555,y:750,t:1526930029665};\\\", \\\"{x:570,y:756,t:1526930029682};\\\", \\\"{x:580,y:761,t:1526930029698};\\\", \\\"{x:589,y:766,t:1526930029715};\\\", \\\"{x:595,y:770,t:1526930029732};\\\", \\\"{x:602,y:774,t:1526930029748};\\\", \\\"{x:610,y:779,t:1526930029765};\\\", \\\"{x:615,y:782,t:1526930029782};\\\", \\\"{x:620,y:784,t:1526930029798};\\\", \\\"{x:622,y:786,t:1526930029815};\\\", \\\"{x:624,y:788,t:1526930029833};\\\", \\\"{x:631,y:789,t:1526930029848};\\\", \\\"{x:633,y:790,t:1526930029865};\\\", \\\"{x:634,y:790,t:1526930030032};\\\", \\\"{x:634,y:789,t:1526930030471};\\\", \\\"{x:634,y:788,t:1526930030488};\\\", \\\"{x:634,y:787,t:1526930030503};\\\" ] }, { \\\"rt\\\": 9485, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 10, \\\"time_elapsed\\\": 392133, \\\"internal_node_id\\\": \\\"0.0-6.0-0.0\\\", \\\"subject\\\": \\\"GQ35Z\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"charlie\\\", \\\"condition\\\": \\\"111\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"duration\\\", \\\"q\\\": 6, \\\"clicks\\\": 2.5, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XInside-YFull\\\", \\\"correct\\\": 1, \\\"orth_correct\\\": 1, \\\"answer\\\": [ \\\"E\\\", \\\"G\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-E \\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:634,y:781,t:1526930030804};\\\", \\\"{x:634,y:780,t:1526930030816};\\\", \\\"{x:634,y:779,t:1526930030903};\\\", \\\"{x:636,y:775,t:1526930030916};\\\", \\\"{x:639,y:770,t:1526930030942};\\\", \\\"{x:641,y:768,t:1526930030949};\\\", \\\"{x:641,y:766,t:1526930030966};\\\", \\\"{x:643,y:764,t:1526930030983};\\\", \\\"{x:646,y:762,t:1526930030999};\\\", \\\"{x:647,y:761,t:1526930031016};\\\", \\\"{x:648,y:761,t:1526930031033};\\\", \\\"{x:650,y:758,t:1526930031049};\\\", \\\"{x:650,y:755,t:1526930031067};\\\", \\\"{x:651,y:751,t:1526930031083};\\\", \\\"{x:651,y:748,t:1526930031099};\\\", \\\"{x:651,y:745,t:1526930031116};\\\", \\\"{x:651,y:744,t:1526930031151};\\\", \\\"{x:651,y:743,t:1526930031264};\\\", \\\"{x:652,y:741,t:1526930031271};\\\", \\\"{x:653,y:741,t:1526930031283};\\\", \\\"{x:653,y:740,t:1526930031301};\\\", \\\"{x:653,y:741,t:1526930031535};\\\", \\\"{x:653,y:742,t:1526930031550};\\\", \\\"{x:653,y:744,t:1526930031567};\\\", \\\"{x:654,y:744,t:1526930031640};\\\", \\\"{x:655,y:744,t:1526930031655};\\\", \\\"{x:656,y:744,t:1526930031666};\\\", \\\"{x:659,y:744,t:1526930031684};\\\", \\\"{x:658,y:744,t:1526930031840};\\\", \\\"{x:657,y:744,t:1526930031850};\\\", \\\"{x:657,y:743,t:1526930031968};\\\", \\\"{x:657,y:742,t:1526930031984};\\\", \\\"{x:657,y:741,t:1526930032000};\\\", \\\"{x:657,y:740,t:1526930032018};\\\", \\\"{x:661,y:739,t:1526930032034};\\\", \\\"{x:663,y:738,t:1526930032050};\\\", \\\"{x:667,y:737,t:1526930032068};\\\", \\\"{x:682,y:737,t:1526930032084};\\\", \\\"{x:707,y:737,t:1526930032101};\\\", \\\"{x:752,y:737,t:1526930032118};\\\", \\\"{x:832,y:737,t:1526930032134};\\\", \\\"{x:857,y:737,t:1526930032151};\\\", \\\"{x:905,y:737,t:1526930032167};\\\", \\\"{x:930,y:737,t:1526930032184};\\\", \\\"{x:948,y:739,t:1526930032200};\\\", \\\"{x:951,y:739,t:1526930032218};\\\", \\\"{x:953,y:739,t:1526930032234};\\\", \\\"{x:954,y:739,t:1526930032288};\\\", \\\"{x:954,y:738,t:1526930032304};\\\", \\\"{x:957,y:735,t:1526930032816};\\\", \\\"{x:958,y:734,t:1526930032824};\\\", \\\"{x:958,y:731,t:1526930032835};\\\", \\\"{x:967,y:717,t:1526930032852};\\\", \\\"{x:979,y:707,t:1526930032867};\\\", \\\"{x:994,y:696,t:1526930032885};\\\", \\\"{x:1004,y:688,t:1526930032902};\\\", \\\"{x:1010,y:682,t:1526930032918};\\\", \\\"{x:1017,y:673,t:1526930032935};\\\", \\\"{x:1023,y:659,t:1526930032952};\\\", \\\"{x:1027,y:650,t:1526930032968};\\\", \\\"{x:1030,y:637,t:1526930032984};\\\", \\\"{x:1042,y:615,t:1526930033001};\\\", \\\"{x:1057,y:599,t:1526930033017};\\\", \\\"{x:1074,y:582,t:1526930033035};\\\", \\\"{x:1090,y:561,t:1526930033051};\\\", \\\"{x:1109,y:539,t:1526930033068};\\\", \\\"{x:1123,y:522,t:1526930033084};\\\", \\\"{x:1136,y:510,t:1526930033101};\\\", \\\"{x:1144,y:501,t:1526930033118};\\\", \\\"{x:1147,y:495,t:1526930033134};\\\", \\\"{x:1151,y:487,t:1526930033151};\\\", \\\"{x:1153,y:479,t:1526930033169};\\\", \\\"{x:1153,y:456,t:1526930033184};\\\", \\\"{x:1153,y:388,t:1526930033202};\\\", \\\"{x:1153,y:340,t:1526930033219};\\\", \\\"{x:1151,y:325,t:1526930033235};\\\", \\\"{x:1150,y:323,t:1526930033251};\\\", \\\"{x:1149,y:322,t:1526930033269};\\\", \\\"{x:1148,y:322,t:1526930033360};\\\", \\\"{x:1147,y:322,t:1526930033370};\\\", \\\"{x:1142,y:333,t:1526930033385};\\\", \\\"{x:1138,y:350,t:1526930033402};\\\", \\\"{x:1137,y:362,t:1526930033419};\\\", \\\"{x:1137,y:373,t:1526930033435};\\\", \\\"{x:1137,y:384,t:1526930033452};\\\", \\\"{x:1135,y:397,t:1526930033469};\\\", \\\"{x:1135,y:410,t:1526930033484};\\\", \\\"{x:1132,y:427,t:1526930033502};\\\", \\\"{x:1132,y:445,t:1526930033519};\\\", \\\"{x:1132,y:468,t:1526930033535};\\\", \\\"{x:1134,y:490,t:1526930033552};\\\", \\\"{x:1138,y:513,t:1526930033570};\\\", \\\"{x:1141,y:535,t:1526930033586};\\\", \\\"{x:1148,y:557,t:1526930033602};\\\", \\\"{x:1156,y:576,t:1526930033619};\\\", \\\"{x:1159,y:586,t:1526930033636};\\\", \\\"{x:1159,y:588,t:1526930033652};\\\", \\\"{x:1161,y:590,t:1526930033720};\\\", \\\"{x:1166,y:596,t:1526930033736};\\\", \\\"{x:1169,y:598,t:1526930033752};\\\", \\\"{x:1175,y:598,t:1526930033770};\\\", \\\"{x:1178,y:598,t:1526930033785};\\\", \\\"{x:1180,y:597,t:1526930033802};\\\", \\\"{x:1182,y:597,t:1526930033819};\\\", \\\"{x:1183,y:597,t:1526930033836};\\\", \\\"{x:1184,y:596,t:1526930033854};\\\", \\\"{x:1185,y:596,t:1526930033868};\\\", \\\"{x:1186,y:595,t:1526930033885};\\\", \\\"{x:1188,y:594,t:1526930033901};\\\", \\\"{x:1191,y:592,t:1526930033918};\\\", \\\"{x:1196,y:589,t:1526930033935};\\\", \\\"{x:1198,y:587,t:1526930033951};\\\", \\\"{x:1202,y:586,t:1526930033969};\\\", \\\"{x:1206,y:583,t:1526930033985};\\\", \\\"{x:1212,y:579,t:1526930034002};\\\", \\\"{x:1221,y:576,t:1526930034018};\\\", \\\"{x:1229,y:574,t:1526930034035};\\\", \\\"{x:1239,y:572,t:1526930034052};\\\", \\\"{x:1245,y:572,t:1526930034068};\\\", \\\"{x:1249,y:571,t:1526930034085};\\\", \\\"{x:1254,y:570,t:1526930034103};\\\", \\\"{x:1259,y:570,t:1526930034119};\\\", \\\"{x:1273,y:567,t:1526930034135};\\\", \\\"{x:1283,y:567,t:1526930034154};\\\", \\\"{x:1288,y:567,t:1526930034171};\\\", \\\"{x:1290,y:567,t:1526930034186};\\\", \\\"{x:1290,y:568,t:1526930034448};\\\", \\\"{x:1290,y:569,t:1526930034552};\\\", \\\"{x:1297,y:569,t:1526930034570};\\\", \\\"{x:1304,y:569,t:1526930034586};\\\", \\\"{x:1316,y:571,t:1526930034603};\\\", \\\"{x:1321,y:571,t:1526930034620};\\\", \\\"{x:1329,y:571,t:1526930034636};\\\", \\\"{x:1337,y:570,t:1526930034653};\\\", \\\"{x:1343,y:570,t:1526930034670};\\\", \\\"{x:1345,y:570,t:1526930034686};\\\", \\\"{x:1350,y:569,t:1526930034703};\\\", \\\"{x:1353,y:568,t:1526930034720};\\\", \\\"{x:1354,y:567,t:1526930034776};\\\", \\\"{x:1355,y:566,t:1526930034800};\\\", \\\"{x:1354,y:566,t:1526930034928};\\\", \\\"{x:1352,y:566,t:1526930034936};\\\", \\\"{x:1341,y:566,t:1526930034953};\\\", \\\"{x:1333,y:567,t:1526930034971};\\\", \\\"{x:1326,y:567,t:1526930034986};\\\", \\\"{x:1310,y:569,t:1526930035003};\\\", \\\"{x:1271,y:569,t:1526930035020};\\\", \\\"{x:1226,y:569,t:1526930035037};\\\", \\\"{x:1156,y:569,t:1526930035053};\\\", \\\"{x:1091,y:567,t:1526930035069};\\\", \\\"{x:1018,y:565,t:1526930035086};\\\", \\\"{x:934,y:562,t:1526930035103};\\\", \\\"{x:881,y:562,t:1526930035119};\\\", \\\"{x:850,y:562,t:1526930035136};\\\", \\\"{x:822,y:562,t:1526930035153};\\\", \\\"{x:795,y:562,t:1526930035169};\\\", \\\"{x:770,y:562,t:1526930035186};\\\", \\\"{x:746,y:562,t:1526930035203};\\\", \\\"{x:724,y:562,t:1526930035219};\\\", \\\"{x:704,y:562,t:1526930035236};\\\", \\\"{x:687,y:559,t:1526930035253};\\\", \\\"{x:673,y:559,t:1526930035270};\\\", \\\"{x:667,y:559,t:1526930035287};\\\", \\\"{x:655,y:559,t:1526930035303};\\\", \\\"{x:648,y:559,t:1526930035320};\\\", \\\"{x:631,y:559,t:1526930035337};\\\", \\\"{x:601,y:556,t:1526930035352};\\\", \\\"{x:571,y:553,t:1526930035371};\\\", \\\"{x:504,y:542,t:1526930035386};\\\", \\\"{x:439,y:537,t:1526930035403};\\\", \\\"{x:389,y:540,t:1526930035419};\\\", \\\"{x:371,y:540,t:1526930035436};\\\", \\\"{x:356,y:540,t:1526930035453};\\\", \\\"{x:346,y:543,t:1526930035469};\\\", \\\"{x:333,y:544,t:1526930035487};\\\", \\\"{x:323,y:544,t:1526930035502};\\\", \\\"{x:305,y:544,t:1526930035519};\\\", \\\"{x:277,y:544,t:1526930035536};\\\", \\\"{x:252,y:544,t:1526930035554};\\\", \\\"{x:216,y:547,t:1526930035570};\\\", \\\"{x:196,y:546,t:1526930035586};\\\", \\\"{x:177,y:543,t:1526930035604};\\\", \\\"{x:167,y:541,t:1526930035620};\\\", \\\"{x:164,y:541,t:1526930035637};\\\", \\\"{x:162,y:541,t:1526930035654};\\\", \\\"{x:162,y:539,t:1526930035703};\\\", \\\"{x:170,y:534,t:1526930035721};\\\", \\\"{x:197,y:532,t:1526930035737};\\\", \\\"{x:234,y:525,t:1526930035753};\\\", \\\"{x:287,y:518,t:1526930035770};\\\", \\\"{x:351,y:511,t:1526930035786};\\\", \\\"{x:401,y:504,t:1526930035803};\\\", \\\"{x:450,y:494,t:1526930035820};\\\", \\\"{x:474,y:487,t:1526930035836};\\\", \\\"{x:484,y:484,t:1526930035854};\\\", \\\"{x:486,y:483,t:1526930035870};\\\", \\\"{x:489,y:483,t:1526930035910};\\\", \\\"{x:490,y:483,t:1526930035921};\\\", \\\"{x:499,y:481,t:1526930035936};\\\", \\\"{x:504,y:481,t:1526930035953};\\\", \\\"{x:508,y:481,t:1526930035970};\\\", \\\"{x:513,y:481,t:1526930035987};\\\", \\\"{x:532,y:487,t:1526930036004};\\\", \\\"{x:557,y:493,t:1526930036020};\\\", \\\"{x:583,y:504,t:1526930036038};\\\", \\\"{x:603,y:508,t:1526930036053};\\\", \\\"{x:614,y:511,t:1526930036070};\\\", \\\"{x:621,y:513,t:1526930036087};\\\", \\\"{x:629,y:513,t:1526930036559};\\\", \\\"{x:645,y:515,t:1526930036571};\\\", \\\"{x:667,y:520,t:1526930036589};\\\", \\\"{x:690,y:525,t:1526930036604};\\\", \\\"{x:728,y:531,t:1526930036623};\\\", \\\"{x:749,y:533,t:1526930036638};\\\", \\\"{x:763,y:536,t:1526930036655};\\\", \\\"{x:769,y:537,t:1526930036671};\\\", \\\"{x:771,y:538,t:1526930036688};\\\", \\\"{x:773,y:538,t:1526930036759};\\\", \\\"{x:775,y:538,t:1526930036771};\\\", \\\"{x:777,y:538,t:1526930036788};\\\", \\\"{x:781,y:538,t:1526930036804};\\\", \\\"{x:783,y:538,t:1526930036821};\\\", \\\"{x:784,y:538,t:1526930036838};\\\", \\\"{x:785,y:538,t:1526930036854};\\\", \\\"{x:788,y:538,t:1526930036871};\\\", \\\"{x:790,y:538,t:1526930036887};\\\", \\\"{x:799,y:538,t:1526930036904};\\\", \\\"{x:808,y:540,t:1526930036921};\\\", \\\"{x:817,y:541,t:1526930036938};\\\", \\\"{x:821,y:542,t:1526930036954};\\\", \\\"{x:822,y:542,t:1526930036992};\\\", \\\"{x:823,y:542,t:1526930037016};\\\", \\\"{x:824,y:542,t:1526930037040};\\\", \\\"{x:824,y:543,t:1526930037087};\\\", \\\"{x:820,y:543,t:1526930037103};\\\", \\\"{x:805,y:543,t:1526930037121};\\\", \\\"{x:787,y:538,t:1526930037137};\\\", \\\"{x:758,y:529,t:1526930037154};\\\", \\\"{x:714,y:517,t:1526930037172};\\\", \\\"{x:678,y:507,t:1526930037187};\\\", \\\"{x:663,y:506,t:1526930037204};\\\", \\\"{x:659,y:505,t:1526930037221};\\\", \\\"{x:658,y:505,t:1526930037238};\\\", \\\"{x:657,y:505,t:1526930037311};\\\", \\\"{x:656,y:505,t:1526930037322};\\\", \\\"{x:652,y:505,t:1526930037339};\\\", \\\"{x:646,y:505,t:1526930037355};\\\", \\\"{x:640,y:505,t:1526930037372};\\\", \\\"{x:632,y:505,t:1526930037388};\\\", \\\"{x:624,y:505,t:1526930037405};\\\", \\\"{x:619,y:503,t:1526930037422};\\\", \\\"{x:616,y:503,t:1526930037438};\\\", \\\"{x:615,y:503,t:1526930037454};\\\", \\\"{x:613,y:503,t:1526930037487};\\\", \\\"{x:620,y:503,t:1526930037655};\\\", \\\"{x:641,y:503,t:1526930037671};\\\", \\\"{x:663,y:503,t:1526930037688};\\\", \\\"{x:680,y:506,t:1526930037705};\\\", \\\"{x:712,y:512,t:1526930037721};\\\", \\\"{x:734,y:515,t:1526930037739};\\\", \\\"{x:753,y:517,t:1526930037756};\\\", \\\"{x:765,y:520,t:1526930037772};\\\", \\\"{x:776,y:522,t:1526930037788};\\\", \\\"{x:787,y:525,t:1526930037805};\\\", \\\"{x:798,y:527,t:1526930037821};\\\", \\\"{x:812,y:530,t:1526930037838};\\\", \\\"{x:814,y:530,t:1526930037855};\\\", \\\"{x:815,y:530,t:1526930037895};\\\", \\\"{x:815,y:531,t:1526930037911};\\\", \\\"{x:815,y:532,t:1526930037921};\\\", \\\"{x:814,y:537,t:1526930037939};\\\", \\\"{x:813,y:540,t:1526930037955};\\\", \\\"{x:813,y:543,t:1526930037971};\\\", \\\"{x:811,y:546,t:1526930037989};\\\", \\\"{x:811,y:547,t:1526930038006};\\\", \\\"{x:811,y:549,t:1526930038022};\\\", \\\"{x:812,y:551,t:1526930038038};\\\", \\\"{x:818,y:552,t:1526930038055};\\\", \\\"{x:820,y:552,t:1526930038072};\\\", \\\"{x:822,y:552,t:1526930038089};\\\", \\\"{x:823,y:551,t:1526930038136};\\\", \\\"{x:825,y:550,t:1526930038152};\\\", \\\"{x:828,y:549,t:1526930038173};\\\", \\\"{x:832,y:546,t:1526930038189};\\\", \\\"{x:836,y:545,t:1526930038205};\\\", \\\"{x:837,y:544,t:1526930038222};\\\", \\\"{x:837,y:543,t:1526930038423};\\\", \\\"{x:834,y:544,t:1526930038438};\\\", \\\"{x:831,y:549,t:1526930038455};\\\", \\\"{x:825,y:559,t:1526930038473};\\\", \\\"{x:816,y:571,t:1526930038490};\\\", \\\"{x:804,y:584,t:1526930038505};\\\", \\\"{x:791,y:598,t:1526930038523};\\\", \\\"{x:773,y:614,t:1526930038539};\\\", \\\"{x:757,y:626,t:1526930038555};\\\", \\\"{x:735,y:643,t:1526930038573};\\\", \\\"{x:712,y:656,t:1526930038589};\\\", \\\"{x:692,y:671,t:1526930038605};\\\", \\\"{x:665,y:694,t:1526930038623};\\\", \\\"{x:652,y:704,t:1526930038639};\\\", \\\"{x:645,y:710,t:1526930038656};\\\", \\\"{x:639,y:714,t:1526930038672};\\\", \\\"{x:633,y:718,t:1526930038690};\\\", \\\"{x:626,y:719,t:1526930038706};\\\", \\\"{x:618,y:720,t:1526930038723};\\\", \\\"{x:607,y:720,t:1526930038740};\\\", \\\"{x:598,y:720,t:1526930038756};\\\", \\\"{x:587,y:720,t:1526930038773};\\\", \\\"{x:577,y:720,t:1526930038789};\\\", \\\"{x:566,y:722,t:1526930038806};\\\", \\\"{x:555,y:722,t:1526930038825};\\\", \\\"{x:551,y:722,t:1526930038839};\\\", \\\"{x:546,y:723,t:1526930038856};\\\", \\\"{x:545,y:723,t:1526930038873};\\\", \\\"{x:544,y:723,t:1526930038890};\\\", \\\"{x:542,y:725,t:1526930038906};\\\", \\\"{x:540,y:726,t:1526930038923};\\\", \\\"{x:535,y:729,t:1526930038940};\\\", \\\"{x:531,y:729,t:1526930038957};\\\", \\\"{x:530,y:729,t:1526930038972};\\\", \\\"{x:528,y:729,t:1526930038989};\\\", \\\"{x:525,y:729,t:1526930039006};\\\", \\\"{x:524,y:730,t:1526930039031};\\\", \\\"{x:523,y:730,t:1526930039062};\\\", \\\"{x:521,y:730,t:1526930039086};\\\", \\\"{x:521,y:731,t:1526930039103};\\\" ] }, { \\\"rt\\\": 25201, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 11, \\\"time_elapsed\\\": 418576, \\\"internal_node_id\\\": \\\"0.0-6.0-1.0\\\", \\\"subject\\\": \\\"GQ35Z\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"charlie\\\", \\\"condition\\\": \\\"111\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"duration+starts\\\", \\\"q\\\": 7, \\\"clicks\\\": 2, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XInside-YFull\\\", \\\"correct\\\": 1, \\\"orth_correct\\\": 0, \\\"answer\\\": [ \\\"X\\\", \\\"O\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-O -X -X -X -X -O -X \\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:521,y:732,t:1526930041904};\\\", \\\"{x:525,y:733,t:1526930041911};\\\", \\\"{x:535,y:735,t:1526930041925};\\\", \\\"{x:763,y:779,t:1526930042018};\\\", \\\"{x:779,y:787,t:1526930042026};\\\", \\\"{x:805,y:794,t:1526930042042};\\\", \\\"{x:823,y:797,t:1526930042058};\\\", \\\"{x:837,y:798,t:1526930042075};\\\", \\\"{x:842,y:800,t:1526930042092};\\\", \\\"{x:843,y:800,t:1526930042108};\\\", \\\"{x:845,y:801,t:1526930042126};\\\", \\\"{x:847,y:801,t:1526930042134};\\\", \\\"{x:849,y:802,t:1526930042158};\\\", \\\"{x:850,y:802,t:1526930042175};\\\", \\\"{x:850,y:802,t:1526930042215};\\\", \\\"{x:763,y:776,t:1526930042498};\\\", \\\"{x:762,y:776,t:1526930042511};\\\", \\\"{x:762,y:776,t:1526930042633};\\\", \\\"{x:763,y:774,t:1526930047206};\\\", \\\"{x:767,y:772,t:1526930047214};\\\", \\\"{x:775,y:768,t:1526930047230};\\\", \\\"{x:781,y:766,t:1526930047248};\\\", \\\"{x:789,y:762,t:1526930047264};\\\", \\\"{x:795,y:760,t:1526930047280};\\\", \\\"{x:800,y:758,t:1526930047298};\\\", \\\"{x:802,y:758,t:1526930047314};\\\", \\\"{x:806,y:755,t:1526930047331};\\\", \\\"{x:809,y:753,t:1526930047351};\\\", \\\"{x:810,y:752,t:1526930047364};\\\", \\\"{x:813,y:750,t:1526930047380};\\\", \\\"{x:821,y:748,t:1526930047398};\\\", \\\"{x:830,y:747,t:1526930047414};\\\", \\\"{x:850,y:744,t:1526930047430};\\\", \\\"{x:864,y:741,t:1526930047448};\\\", \\\"{x:877,y:737,t:1526930047464};\\\", \\\"{x:888,y:736,t:1526930047481};\\\", \\\"{x:899,y:731,t:1526930047498};\\\", \\\"{x:908,y:728,t:1526930047514};\\\", \\\"{x:919,y:723,t:1526930047531};\\\", \\\"{x:932,y:718,t:1526930047548};\\\", \\\"{x:941,y:714,t:1526930047565};\\\", \\\"{x:952,y:708,t:1526930047581};\\\", \\\"{x:971,y:698,t:1526930047598};\\\", \\\"{x:992,y:688,t:1526930047615};\\\", \\\"{x:1002,y:684,t:1526930047631};\\\", \\\"{x:1007,y:681,t:1526930047648};\\\", \\\"{x:1011,y:679,t:1526930047665};\\\", \\\"{x:1017,y:675,t:1526930047681};\\\", \\\"{x:1030,y:668,t:1526930047698};\\\", \\\"{x:1043,y:660,t:1526930047715};\\\", \\\"{x:1052,y:656,t:1526930047731};\\\", \\\"{x:1060,y:652,t:1526930047748};\\\", \\\"{x:1067,y:649,t:1526930047765};\\\", \\\"{x:1070,y:646,t:1526930047781};\\\", \\\"{x:1074,y:644,t:1526930047799};\\\", \\\"{x:1077,y:642,t:1526930047815};\\\", \\\"{x:1080,y:642,t:1526930047831};\\\", \\\"{x:1081,y:641,t:1526930047848};\\\", \\\"{x:1082,y:642,t:1526930048111};\\\", \\\"{x:1082,y:644,t:1526930048119};\\\", \\\"{x:1083,y:646,t:1526930048133};\\\", \\\"{x:1085,y:650,t:1526930048149};\\\", \\\"{x:1087,y:653,t:1526930048165};\\\", \\\"{x:1088,y:656,t:1526930048182};\\\", \\\"{x:1088,y:658,t:1526930048198};\\\", \\\"{x:1089,y:660,t:1526930048215};\\\", \\\"{x:1090,y:661,t:1526930048233};\\\", \\\"{x:1090,y:663,t:1526930048250};\\\", \\\"{x:1090,y:664,t:1526930048266};\\\", \\\"{x:1091,y:664,t:1526930048283};\\\", \\\"{x:1092,y:666,t:1526930048304};\\\", \\\"{x:1092,y:669,t:1526930048319};\\\", \\\"{x:1093,y:669,t:1526930048335};\\\", \\\"{x:1093,y:670,t:1526930048352};\\\", \\\"{x:1094,y:670,t:1526930048368};\\\", \\\"{x:1095,y:671,t:1526930048416};\\\", \\\"{x:1096,y:672,t:1526930048432};\\\", \\\"{x:1096,y:673,t:1526930048449};\\\", \\\"{x:1097,y:674,t:1526930048466};\\\", \\\"{x:1097,y:675,t:1526930048527};\\\", \\\"{x:1097,y:676,t:1526930048543};\\\", \\\"{x:1097,y:677,t:1526930048551};\\\", \\\"{x:1098,y:679,t:1526930048592};\\\", \\\"{x:1098,y:680,t:1526930048632};\\\", \\\"{x:1099,y:681,t:1526930048672};\\\", \\\"{x:1099,y:682,t:1526930048683};\\\", \\\"{x:1100,y:683,t:1526930051320};\\\", \\\"{x:1102,y:684,t:1526930051335};\\\", \\\"{x:1103,y:686,t:1526930051352};\\\", \\\"{x:1105,y:689,t:1526930051368};\\\", \\\"{x:1105,y:690,t:1526930051390};\\\", \\\"{x:1106,y:691,t:1526930051471};\\\", \\\"{x:1107,y:691,t:1526930051484};\\\", \\\"{x:1109,y:693,t:1526930051502};\\\", \\\"{x:1110,y:694,t:1526930051518};\\\", \\\"{x:1112,y:694,t:1526930051535};\\\", \\\"{x:1114,y:696,t:1526930051552};\\\", \\\"{x:1116,y:696,t:1526930051569};\\\", \\\"{x:1116,y:697,t:1526930051586};\\\", \\\"{x:1117,y:698,t:1526930051602};\\\", \\\"{x:1119,y:698,t:1526930051619};\\\", \\\"{x:1120,y:699,t:1526930051635};\\\", \\\"{x:1121,y:699,t:1526930051711};\\\", \\\"{x:1122,y:699,t:1526930051920};\\\", \\\"{x:1123,y:699,t:1526930051951};\\\", \\\"{x:1125,y:699,t:1526930051983};\\\", \\\"{x:1126,y:698,t:1526930052000};\\\", \\\"{x:1127,y:697,t:1526930052007};\\\", \\\"{x:1128,y:696,t:1526930052031};\\\", \\\"{x:1129,y:695,t:1526930052039};\\\", \\\"{x:1130,y:695,t:1526930052056};\\\", \\\"{x:1131,y:694,t:1526930052152};\\\", \\\"{x:1132,y:693,t:1526930052169};\\\", \\\"{x:1133,y:692,t:1526930052186};\\\", \\\"{x:1134,y:692,t:1526930052203};\\\", \\\"{x:1136,y:692,t:1526930052219};\\\", \\\"{x:1139,y:692,t:1526930052237};\\\", \\\"{x:1150,y:692,t:1526930052253};\\\", \\\"{x:1155,y:692,t:1526930052270};\\\", \\\"{x:1161,y:692,t:1526930052287};\\\", \\\"{x:1167,y:692,t:1526930052303};\\\", \\\"{x:1169,y:692,t:1526930052319};\\\", \\\"{x:1170,y:692,t:1526930052341};\\\", \\\"{x:1172,y:692,t:1526930052364};\\\", \\\"{x:1173,y:692,t:1526930052374};\\\", \\\"{x:1176,y:691,t:1526930052391};\\\", \\\"{x:1180,y:691,t:1526930052408};\\\", \\\"{x:1185,y:690,t:1526930052424};\\\", \\\"{x:1188,y:688,t:1526930052441};\\\", \\\"{x:1191,y:688,t:1526930052458};\\\", \\\"{x:1197,y:688,t:1526930052548};\\\", \\\"{x:1203,y:689,t:1526930052563};\\\", \\\"{x:1204,y:692,t:1526930052575};\\\", \\\"{x:1210,y:693,t:1526930052591};\\\", \\\"{x:1212,y:693,t:1526930052608};\\\", \\\"{x:1218,y:694,t:1526930052625};\\\", \\\"{x:1230,y:696,t:1526930052641};\\\", \\\"{x:1233,y:696,t:1526930052658};\\\", \\\"{x:1239,y:698,t:1526930052675};\\\", \\\"{x:1241,y:698,t:1526930052691};\\\", \\\"{x:1243,y:698,t:1526930052707};\\\", \\\"{x:1246,y:698,t:1526930052724};\\\", \\\"{x:1249,y:698,t:1526930052740};\\\", \\\"{x:1253,y:698,t:1526930052757};\\\", \\\"{x:1254,y:699,t:1526930052774};\\\", \\\"{x:1259,y:699,t:1526930052790};\\\", \\\"{x:1261,y:699,t:1526930052807};\\\", \\\"{x:1267,y:699,t:1526930052824};\\\", \\\"{x:1273,y:699,t:1526930052841};\\\", \\\"{x:1278,y:699,t:1526930052857};\\\", \\\"{x:1285,y:699,t:1526930052874};\\\", \\\"{x:1293,y:702,t:1526930052890};\\\", \\\"{x:1295,y:702,t:1526930052907};\\\", \\\"{x:1299,y:703,t:1526930052924};\\\", \\\"{x:1305,y:703,t:1526930052941};\\\", \\\"{x:1310,y:703,t:1526930052957};\\\", \\\"{x:1311,y:703,t:1526930052995};\\\", \\\"{x:1313,y:705,t:1526930053008};\\\", \\\"{x:1316,y:705,t:1526930053024};\\\", \\\"{x:1319,y:705,t:1526930053041};\\\", \\\"{x:1323,y:705,t:1526930053057};\\\", \\\"{x:1326,y:705,t:1526930053074};\\\", \\\"{x:1327,y:705,t:1526930053091};\\\", \\\"{x:1329,y:705,t:1526930053107};\\\", \\\"{x:1331,y:705,t:1526930053125};\\\", \\\"{x:1333,y:705,t:1526930053141};\\\", \\\"{x:1334,y:705,t:1526930053163};\\\", \\\"{x:1336,y:705,t:1526930053174};\\\", \\\"{x:1337,y:705,t:1526930053191};\\\", \\\"{x:1338,y:705,t:1526930053208};\\\", \\\"{x:1340,y:704,t:1526930054188};\\\", \\\"{x:1343,y:704,t:1526930054244};\\\", \\\"{x:1349,y:704,t:1526930054259};\\\", \\\"{x:1350,y:704,t:1526930054275};\\\", \\\"{x:1352,y:704,t:1526930054293};\\\", \\\"{x:1353,y:704,t:1526930054310};\\\", \\\"{x:1354,y:704,t:1526930054788};\\\", \\\"{x:1357,y:704,t:1526930054812};\\\", \\\"{x:1360,y:704,t:1526930054827};\\\", \\\"{x:1364,y:704,t:1526930054843};\\\", \\\"{x:1369,y:705,t:1526930054860};\\\", \\\"{x:1372,y:705,t:1526930054876};\\\", \\\"{x:1376,y:704,t:1526930054893};\\\", \\\"{x:1378,y:704,t:1526930054910};\\\", \\\"{x:1380,y:704,t:1526930054926};\\\", \\\"{x:1384,y:704,t:1526930054943};\\\", \\\"{x:1389,y:704,t:1526930054960};\\\", \\\"{x:1392,y:702,t:1526930054976};\\\", \\\"{x:1393,y:702,t:1526930055043};\\\", \\\"{x:1395,y:702,t:1526930055059};\\\", \\\"{x:1402,y:702,t:1526930055076};\\\", \\\"{x:1404,y:701,t:1526930055093};\\\", \\\"{x:1406,y:701,t:1526930055109};\\\", \\\"{x:1410,y:700,t:1526930055127};\\\", \\\"{x:1411,y:700,t:1526930055144};\\\", \\\"{x:1413,y:700,t:1526930055160};\\\", \\\"{x:1414,y:699,t:1526930055177};\\\", \\\"{x:1417,y:699,t:1526930055211};\\\", \\\"{x:1420,y:698,t:1526930055226};\\\", \\\"{x:1423,y:698,t:1526930055243};\\\", \\\"{x:1427,y:698,t:1526930055260};\\\", \\\"{x:1431,y:698,t:1526930055277};\\\", \\\"{x:1434,y:698,t:1526930055293};\\\", \\\"{x:1439,y:698,t:1526930055311};\\\", \\\"{x:1446,y:698,t:1526930055326};\\\", \\\"{x:1453,y:698,t:1526930055343};\\\", \\\"{x:1459,y:698,t:1526930055360};\\\", \\\"{x:1470,y:700,t:1526930055376};\\\", \\\"{x:1482,y:703,t:1526930055393};\\\", \\\"{x:1498,y:706,t:1526930055411};\\\", \\\"{x:1502,y:709,t:1526930055426};\\\", \\\"{x:1506,y:710,t:1526930055444};\\\", \\\"{x:1507,y:712,t:1526930055460};\\\", \\\"{x:1511,y:716,t:1526930055477};\\\", \\\"{x:1516,y:720,t:1526930055493};\\\", \\\"{x:1519,y:723,t:1526930055510};\\\", \\\"{x:1521,y:725,t:1526930055527};\\\", \\\"{x:1521,y:726,t:1526930055543};\\\", \\\"{x:1522,y:727,t:1526930055560};\\\", \\\"{x:1522,y:729,t:1526930055577};\\\", \\\"{x:1523,y:731,t:1526930055593};\\\", \\\"{x:1525,y:735,t:1526930055610};\\\", \\\"{x:1526,y:738,t:1526930055627};\\\", \\\"{x:1530,y:743,t:1526930055643};\\\", \\\"{x:1533,y:745,t:1526930055660};\\\", \\\"{x:1536,y:747,t:1526930055677};\\\", \\\"{x:1537,y:748,t:1526930055803};\\\", \\\"{x:1536,y:749,t:1526930055818};\\\", \\\"{x:1535,y:750,t:1526930055828};\\\", \\\"{x:1533,y:751,t:1526930055844};\\\", \\\"{x:1532,y:752,t:1526930055860};\\\", \\\"{x:1531,y:753,t:1526930055877};\\\", \\\"{x:1530,y:754,t:1526930055894};\\\", \\\"{x:1526,y:755,t:1526930055910};\\\", \\\"{x:1525,y:755,t:1526930055928};\\\", \\\"{x:1522,y:757,t:1526930055944};\\\", \\\"{x:1522,y:758,t:1526930055960};\\\", \\\"{x:1521,y:759,t:1526930055977};\\\", \\\"{x:1521,y:760,t:1526930055994};\\\", \\\"{x:1519,y:760,t:1526930056436};\\\", \\\"{x:1518,y:762,t:1526930056444};\\\", \\\"{x:1517,y:763,t:1526930056461};\\\", \\\"{x:1516,y:765,t:1526930056478};\\\", \\\"{x:1515,y:767,t:1526930056495};\\\", \\\"{x:1513,y:770,t:1526930056512};\\\", \\\"{x:1511,y:772,t:1526930056529};\\\", \\\"{x:1511,y:774,t:1526930056545};\\\", \\\"{x:1509,y:776,t:1526930056561};\\\", \\\"{x:1506,y:780,t:1526930056578};\\\", \\\"{x:1504,y:783,t:1526930056594};\\\", \\\"{x:1503,y:785,t:1526930056611};\\\", \\\"{x:1502,y:787,t:1526930056629};\\\", \\\"{x:1501,y:788,t:1526930056645};\\\", \\\"{x:1501,y:789,t:1526930056662};\\\", \\\"{x:1501,y:791,t:1526930056678};\\\", \\\"{x:1499,y:794,t:1526930056694};\\\", \\\"{x:1499,y:796,t:1526930056711};\\\", \\\"{x:1498,y:798,t:1526930056728};\\\", \\\"{x:1498,y:800,t:1526930056744};\\\", \\\"{x:1497,y:801,t:1526930056761};\\\", \\\"{x:1497,y:803,t:1526930056778};\\\", \\\"{x:1496,y:804,t:1526930056795};\\\", \\\"{x:1496,y:805,t:1526930056827};\\\", \\\"{x:1496,y:806,t:1526930056852};\\\", \\\"{x:1495,y:806,t:1526930056862};\\\", \\\"{x:1494,y:807,t:1526930056883};\\\", \\\"{x:1494,y:809,t:1526930056895};\\\", \\\"{x:1493,y:810,t:1526930056913};\\\", \\\"{x:1492,y:814,t:1526930056929};\\\", \\\"{x:1491,y:815,t:1526930056947};\\\", \\\"{x:1491,y:816,t:1526930056964};\\\", \\\"{x:1490,y:817,t:1526930057756};\\\", \\\"{x:1490,y:818,t:1526930058884};\\\", \\\"{x:1486,y:819,t:1526930058899};\\\", \\\"{x:1481,y:823,t:1526930058915};\\\", \\\"{x:1478,y:830,t:1526930058932};\\\", \\\"{x:1476,y:834,t:1526930058949};\\\", \\\"{x:1474,y:845,t:1526930058964};\\\", \\\"{x:1471,y:851,t:1526930058982};\\\", \\\"{x:1467,y:860,t:1526930058998};\\\", \\\"{x:1463,y:871,t:1526930059015};\\\", \\\"{x:1457,y:883,t:1526930059031};\\\", \\\"{x:1454,y:890,t:1526930059048};\\\", \\\"{x:1449,y:899,t:1526930059064};\\\", \\\"{x:1449,y:901,t:1526930059082};\\\", \\\"{x:1445,y:905,t:1526930059098};\\\", \\\"{x:1442,y:910,t:1526930059114};\\\", \\\"{x:1435,y:918,t:1526930059132};\\\", \\\"{x:1432,y:923,t:1526930059147};\\\", \\\"{x:1428,y:926,t:1526930059164};\\\", \\\"{x:1425,y:930,t:1526930059181};\\\", \\\"{x:1423,y:932,t:1526930059197};\\\", \\\"{x:1423,y:933,t:1526930059218};\\\", \\\"{x:1422,y:934,t:1526930059230};\\\", \\\"{x:1422,y:936,t:1526930059247};\\\", \\\"{x:1421,y:938,t:1526930059265};\\\", \\\"{x:1420,y:941,t:1526930059280};\\\", \\\"{x:1419,y:941,t:1526930059412};\\\", \\\"{x:1419,y:940,t:1526930059420};\\\", \\\"{x:1419,y:937,t:1526930059431};\\\", \\\"{x:1419,y:934,t:1526930059448};\\\", \\\"{x:1420,y:929,t:1526930059466};\\\", \\\"{x:1423,y:920,t:1526930059481};\\\", \\\"{x:1424,y:912,t:1526930059498};\\\", \\\"{x:1429,y:900,t:1526930059516};\\\", \\\"{x:1436,y:889,t:1526930059531};\\\", \\\"{x:1442,y:877,t:1526930059548};\\\", \\\"{x:1453,y:861,t:1526930059566};\\\", \\\"{x:1457,y:842,t:1526930059582};\\\", \\\"{x:1460,y:834,t:1526930059598};\\\", \\\"{x:1465,y:823,t:1526930059615};\\\", \\\"{x:1468,y:815,t:1526930059633};\\\", \\\"{x:1474,y:807,t:1526930059648};\\\", \\\"{x:1479,y:802,t:1526930059665};\\\", \\\"{x:1482,y:797,t:1526930059682};\\\", \\\"{x:1486,y:793,t:1526930059698};\\\", \\\"{x:1492,y:789,t:1526930059715};\\\", \\\"{x:1492,y:788,t:1526930059732};\\\", \\\"{x:1495,y:786,t:1526930059748};\\\", \\\"{x:1497,y:784,t:1526930059766};\\\", \\\"{x:1499,y:782,t:1526930059783};\\\", \\\"{x:1500,y:782,t:1526930059798};\\\", \\\"{x:1503,y:780,t:1526930059816};\\\", \\\"{x:1502,y:780,t:1526930059916};\\\", \\\"{x:1495,y:790,t:1526930059932};\\\", \\\"{x:1488,y:805,t:1526930059950};\\\", \\\"{x:1483,y:816,t:1526930059966};\\\", \\\"{x:1477,y:823,t:1526930059982};\\\", \\\"{x:1476,y:828,t:1526930060000};\\\", \\\"{x:1473,y:833,t:1526930060016};\\\", \\\"{x:1470,y:836,t:1526930060033};\\\", \\\"{x:1467,y:839,t:1526930060049};\\\", \\\"{x:1461,y:841,t:1526930060065};\\\", \\\"{x:1453,y:847,t:1526930060082};\\\", \\\"{x:1427,y:848,t:1526930060100};\\\", \\\"{x:1377,y:837,t:1526930060116};\\\", \\\"{x:1258,y:803,t:1526930060132};\\\", \\\"{x:1101,y:761,t:1526930060149};\\\", \\\"{x:960,y:727,t:1526930060166};\\\", \\\"{x:852,y:711,t:1526930060182};\\\", \\\"{x:766,y:697,t:1526930060199};\\\", \\\"{x:682,y:682,t:1526930060216};\\\", \\\"{x:617,y:670,t:1526930060231};\\\", \\\"{x:594,y:667,t:1526930060248};\\\", \\\"{x:586,y:667,t:1526930060265};\\\", \\\"{x:584,y:667,t:1526930060281};\\\", \\\"{x:583,y:667,t:1526930060298};\\\", \\\"{x:582,y:667,t:1526930060316};\\\", \\\"{x:580,y:667,t:1526930060332};\\\", \\\"{x:579,y:667,t:1526930060371};\\\", \\\"{x:579,y:664,t:1526930060382};\\\", \\\"{x:579,y:660,t:1526930060399};\\\", \\\"{x:582,y:654,t:1526930060416};\\\", \\\"{x:589,y:644,t:1526930060432};\\\", \\\"{x:595,y:635,t:1526930060449};\\\", \\\"{x:605,y:627,t:1526930060467};\\\", \\\"{x:615,y:619,t:1526930060482};\\\", \\\"{x:641,y:610,t:1526930060498};\\\", \\\"{x:656,y:607,t:1526930060511};\\\", \\\"{x:678,y:603,t:1526930060527};\\\", \\\"{x:691,y:599,t:1526930060545};\\\", \\\"{x:707,y:597,t:1526930060562};\\\", \\\"{x:722,y:593,t:1526930060578};\\\", \\\"{x:738,y:590,t:1526930060595};\\\", \\\"{x:747,y:587,t:1526930060612};\\\", \\\"{x:755,y:587,t:1526930060627};\\\", \\\"{x:757,y:585,t:1526930060645};\\\", \\\"{x:761,y:584,t:1526930060662};\\\", \\\"{x:767,y:582,t:1526930060677};\\\", \\\"{x:771,y:580,t:1526930060695};\\\", \\\"{x:776,y:580,t:1526930060711};\\\", \\\"{x:786,y:580,t:1526930060728};\\\", \\\"{x:796,y:580,t:1526930060744};\\\", \\\"{x:805,y:580,t:1526930060761};\\\", \\\"{x:811,y:580,t:1526930060778};\\\", \\\"{x:816,y:580,t:1526930060794};\\\", \\\"{x:827,y:585,t:1526930060812};\\\", \\\"{x:839,y:589,t:1526930060828};\\\", \\\"{x:841,y:591,t:1526930060845};\\\", \\\"{x:843,y:591,t:1526930060862};\\\", \\\"{x:843,y:592,t:1526930060883};\\\", \\\"{x:843,y:589,t:1526930060949};\\\", \\\"{x:841,y:583,t:1526930060962};\\\", \\\"{x:836,y:574,t:1526930060978};\\\", \\\"{x:836,y:573,t:1526930060994};\\\", \\\"{x:837,y:574,t:1526930061307};\\\", \\\"{x:838,y:576,t:1526930061315};\\\", \\\"{x:840,y:577,t:1526930061329};\\\", \\\"{x:842,y:580,t:1526930061346};\\\", \\\"{x:844,y:583,t:1526930061361};\\\", \\\"{x:845,y:584,t:1526930061379};\\\", \\\"{x:845,y:585,t:1526930061530};\\\", \\\"{x:845,y:586,t:1526930061554};\\\", \\\"{x:844,y:586,t:1526930061570};\\\", \\\"{x:843,y:586,t:1526930061586};\\\", \\\"{x:841,y:586,t:1526930061596};\\\", \\\"{x:838,y:587,t:1526930061612};\\\", \\\"{x:836,y:589,t:1526930061628};\\\", \\\"{x:834,y:590,t:1526930061646};\\\", \\\"{x:828,y:590,t:1526930061663};\\\", \\\"{x:815,y:591,t:1526930061678};\\\", \\\"{x:794,y:596,t:1526930061696};\\\", \\\"{x:763,y:601,t:1526930061712};\\\", \\\"{x:715,y:607,t:1526930061729};\\\", \\\"{x:661,y:608,t:1526930061746};\\\", \\\"{x:630,y:615,t:1526930061762};\\\", \\\"{x:604,y:617,t:1526930061779};\\\", \\\"{x:592,y:619,t:1526930061796};\\\", \\\"{x:585,y:620,t:1526930061811};\\\", \\\"{x:576,y:620,t:1526930061829};\\\", \\\"{x:562,y:621,t:1526930061846};\\\", \\\"{x:541,y:622,t:1526930061863};\\\", \\\"{x:526,y:627,t:1526930061878};\\\", \\\"{x:524,y:627,t:1526930061895};\\\", \\\"{x:519,y:631,t:1526930061912};\\\", \\\"{x:516,y:633,t:1526930061930};\\\", \\\"{x:517,y:633,t:1526930062036};\\\", \\\"{x:525,y:634,t:1526930062046};\\\", \\\"{x:541,y:635,t:1526930062063};\\\", \\\"{x:563,y:639,t:1526930062080};\\\", \\\"{x:584,y:643,t:1526930062096};\\\", \\\"{x:625,y:652,t:1526930062113};\\\", \\\"{x:665,y:654,t:1526930062129};\\\", \\\"{x:688,y:654,t:1526930062146};\\\", \\\"{x:714,y:654,t:1526930062163};\\\", \\\"{x:731,y:652,t:1526930062179};\\\", \\\"{x:748,y:644,t:1526930062196};\\\", \\\"{x:761,y:641,t:1526930062213};\\\", \\\"{x:777,y:634,t:1526930062229};\\\", \\\"{x:793,y:628,t:1526930062247};\\\", \\\"{x:801,y:623,t:1526930062262};\\\", \\\"{x:811,y:617,t:1526930062280};\\\", \\\"{x:817,y:612,t:1526930062296};\\\", \\\"{x:822,y:603,t:1526930062313};\\\", \\\"{x:827,y:598,t:1526930062330};\\\", \\\"{x:830,y:594,t:1526930062346};\\\", \\\"{x:835,y:588,t:1526930062363};\\\", \\\"{x:839,y:583,t:1526930062379};\\\", \\\"{x:842,y:579,t:1526930062395};\\\", \\\"{x:846,y:573,t:1526930062413};\\\", \\\"{x:849,y:567,t:1526930062429};\\\", \\\"{x:850,y:562,t:1526930062447};\\\", \\\"{x:850,y:558,t:1526930062462};\\\", \\\"{x:850,y:553,t:1526930062481};\\\", \\\"{x:850,y:547,t:1526930062496};\\\", \\\"{x:852,y:544,t:1526930062513};\\\", \\\"{x:853,y:541,t:1526930062530};\\\", \\\"{x:853,y:539,t:1526930062546};\\\", \\\"{x:853,y:534,t:1526930062563};\\\", \\\"{x:849,y:525,t:1526930062581};\\\", \\\"{x:836,y:518,t:1526930062597};\\\", \\\"{x:823,y:509,t:1526930062613};\\\", \\\"{x:822,y:509,t:1526930062629};\\\", \\\"{x:816,y:509,t:1526930062646};\\\", \\\"{x:811,y:509,t:1526930062663};\\\", \\\"{x:809,y:507,t:1526930062680};\\\", \\\"{x:803,y:507,t:1526930062697};\\\", \\\"{x:799,y:507,t:1526930062712};\\\", \\\"{x:797,y:507,t:1526930062730};\\\", \\\"{x:791,y:508,t:1526930062746};\\\", \\\"{x:772,y:512,t:1526930062763};\\\", \\\"{x:751,y:516,t:1526930062780};\\\", \\\"{x:735,y:518,t:1526930062797};\\\", \\\"{x:718,y:522,t:1526930062813};\\\", \\\"{x:703,y:527,t:1526930062830};\\\", \\\"{x:698,y:529,t:1526930062846};\\\", \\\"{x:696,y:530,t:1526930062862};\\\", \\\"{x:689,y:533,t:1526930062879};\\\", \\\"{x:685,y:535,t:1526930062896};\\\", \\\"{x:676,y:536,t:1526930062913};\\\", \\\"{x:669,y:540,t:1526930062929};\\\", \\\"{x:660,y:550,t:1526930062947};\\\", \\\"{x:655,y:559,t:1526930062964};\\\", \\\"{x:650,y:565,t:1526930062980};\\\", \\\"{x:647,y:569,t:1526930062997};\\\", \\\"{x:643,y:573,t:1526930063013};\\\", \\\"{x:642,y:575,t:1526930063030};\\\", \\\"{x:641,y:576,t:1526930063047};\\\", \\\"{x:640,y:576,t:1526930063066};\\\", \\\"{x:638,y:577,t:1526930063080};\\\", \\\"{x:637,y:577,t:1526930063099};\\\", \\\"{x:634,y:579,t:1526930063114};\\\", \\\"{x:629,y:580,t:1526930063130};\\\", \\\"{x:629,y:581,t:1526930063146};\\\", \\\"{x:628,y:582,t:1526930063180};\\\", \\\"{x:627,y:582,t:1526930063227};\\\", \\\"{x:626,y:582,t:1526930063236};\\\", \\\"{x:624,y:582,t:1526930063247};\\\", \\\"{x:618,y:582,t:1526930063265};\\\", \\\"{x:615,y:582,t:1526930063281};\\\", \\\"{x:609,y:582,t:1526930063297};\\\", \\\"{x:603,y:582,t:1526930063314};\\\", \\\"{x:602,y:582,t:1526930063331};\\\", \\\"{x:601,y:582,t:1526930063347};\\\", \\\"{x:604,y:582,t:1526930063563};\\\", \\\"{x:607,y:582,t:1526930063570};\\\", \\\"{x:608,y:582,t:1526930063581};\\\", \\\"{x:615,y:582,t:1526930063597};\\\", \\\"{x:620,y:583,t:1526930063614};\\\", \\\"{x:623,y:583,t:1526930063631};\\\", \\\"{x:628,y:587,t:1526930063647};\\\", \\\"{x:640,y:593,t:1526930063665};\\\", \\\"{x:668,y:607,t:1526930063682};\\\", \\\"{x:690,y:615,t:1526930063697};\\\", \\\"{x:713,y:620,t:1526930063713};\\\", \\\"{x:744,y:630,t:1526930063732};\\\", \\\"{x:769,y:638,t:1526930063747};\\\", \\\"{x:799,y:649,t:1526930063764};\\\", \\\"{x:830,y:665,t:1526930063781};\\\", \\\"{x:881,y:680,t:1526930063798};\\\", \\\"{x:941,y:699,t:1526930063814};\\\", \\\"{x:992,y:711,t:1526930063830};\\\", \\\"{x:1038,y:720,t:1526930063848};\\\", \\\"{x:1071,y:729,t:1526930063864};\\\", \\\"{x:1113,y:741,t:1526930063881};\\\", \\\"{x:1149,y:747,t:1526930063898};\\\", \\\"{x:1198,y:754,t:1526930063915};\\\", \\\"{x:1223,y:756,t:1526930063931};\\\", \\\"{x:1249,y:758,t:1526930063948};\\\", \\\"{x:1272,y:762,t:1526930063965};\\\", \\\"{x:1290,y:764,t:1526930063981};\\\", \\\"{x:1316,y:768,t:1526930063998};\\\", \\\"{x:1333,y:768,t:1526930064015};\\\", \\\"{x:1354,y:768,t:1526930064032};\\\", \\\"{x:1368,y:769,t:1526930064048};\\\", \\\"{x:1379,y:769,t:1526930064065};\\\", \\\"{x:1391,y:769,t:1526930064082};\\\", \\\"{x:1409,y:769,t:1526930064099};\\\", \\\"{x:1427,y:769,t:1526930064115};\\\", \\\"{x:1434,y:769,t:1526930064132};\\\", \\\"{x:1438,y:769,t:1526930064149};\\\", \\\"{x:1440,y:769,t:1526930064165};\\\", \\\"{x:1443,y:769,t:1526930064182};\\\", \\\"{x:1446,y:768,t:1526930064199};\\\", \\\"{x:1457,y:768,t:1526930064215};\\\", \\\"{x:1463,y:768,t:1526930064232};\\\", \\\"{x:1473,y:768,t:1526930064250};\\\", \\\"{x:1484,y:768,t:1526930064266};\\\", \\\"{x:1492,y:768,t:1526930064282};\\\", \\\"{x:1497,y:764,t:1526930064299};\\\", \\\"{x:1499,y:763,t:1526930064316};\\\", \\\"{x:1503,y:762,t:1526930064333};\\\", \\\"{x:1508,y:762,t:1526930064349};\\\", \\\"{x:1516,y:762,t:1526930064367};\\\", \\\"{x:1520,y:762,t:1526930064383};\\\", \\\"{x:1520,y:764,t:1526930064507};\\\", \\\"{x:1519,y:765,t:1526930064516};\\\", \\\"{x:1519,y:767,t:1526930064534};\\\", \\\"{x:1519,y:770,t:1526930064550};\\\", \\\"{x:1519,y:774,t:1526930064567};\\\", \\\"{x:1516,y:779,t:1526930064583};\\\", \\\"{x:1514,y:783,t:1526930064600};\\\", \\\"{x:1510,y:791,t:1526930064617};\\\", \\\"{x:1503,y:798,t:1526930064634};\\\", \\\"{x:1496,y:807,t:1526930064650};\\\", \\\"{x:1486,y:824,t:1526930064668};\\\", \\\"{x:1483,y:833,t:1526930064684};\\\", \\\"{x:1482,y:838,t:1526930064701};\\\", \\\"{x:1479,y:843,t:1526930064718};\\\", \\\"{x:1478,y:846,t:1526930064735};\\\", \\\"{x:1476,y:850,t:1526930064751};\\\", \\\"{x:1476,y:852,t:1526930064768};\\\", \\\"{x:1474,y:857,t:1526930064784};\\\", \\\"{x:1474,y:860,t:1526930064801};\\\", \\\"{x:1474,y:864,t:1526930064817};\\\", \\\"{x:1474,y:866,t:1526930064834};\\\", \\\"{x:1472,y:868,t:1526930064852};\\\", \\\"{x:1472,y:869,t:1526930064883};\\\", \\\"{x:1471,y:869,t:1526930064901};\\\", \\\"{x:1469,y:871,t:1526930064918};\\\", \\\"{x:1469,y:873,t:1526930064934};\\\", \\\"{x:1467,y:874,t:1526930064952};\\\", \\\"{x:1464,y:878,t:1526930064968};\\\", \\\"{x:1464,y:880,t:1526930064984};\\\", \\\"{x:1461,y:885,t:1526930065001};\\\", \\\"{x:1458,y:889,t:1526930065018};\\\", \\\"{x:1454,y:895,t:1526930065035};\\\", \\\"{x:1451,y:898,t:1526930065051};\\\", \\\"{x:1450,y:901,t:1526930065068};\\\", \\\"{x:1448,y:904,t:1526930065085};\\\", \\\"{x:1447,y:904,t:1526930065102};\\\", \\\"{x:1446,y:905,t:1526930065118};\\\", \\\"{x:1446,y:907,t:1526930065134};\\\", \\\"{x:1446,y:908,t:1526930065152};\\\", \\\"{x:1444,y:910,t:1526930065168};\\\", \\\"{x:1443,y:912,t:1526930065186};\\\", \\\"{x:1443,y:913,t:1526930065202};\\\", \\\"{x:1442,y:918,t:1526930065219};\\\", \\\"{x:1441,y:920,t:1526930065235};\\\", \\\"{x:1440,y:922,t:1526930065252};\\\", \\\"{x:1439,y:924,t:1526930065269};\\\", \\\"{x:1439,y:925,t:1526930065285};\\\", \\\"{x:1438,y:929,t:1526930065302};\\\", \\\"{x:1435,y:932,t:1526930065319};\\\", \\\"{x:1433,y:935,t:1526930065336};\\\", \\\"{x:1431,y:937,t:1526930065353};\\\", \\\"{x:1429,y:938,t:1526930065369};\\\", \\\"{x:1429,y:940,t:1526930065386};\\\", \\\"{x:1428,y:941,t:1526930065402};\\\", \\\"{x:1427,y:942,t:1526930065427};\\\", \\\"{x:1426,y:942,t:1526930065460};\\\", \\\"{x:1425,y:942,t:1526930065470};\\\", \\\"{x:1424,y:942,t:1526930065486};\\\", \\\"{x:1423,y:942,t:1526930065504};\\\", \\\"{x:1422,y:942,t:1526930065556};\\\", \\\"{x:1420,y:942,t:1526930065628};\\\", \\\"{x:1420,y:943,t:1526930065636};\\\", \\\"{x:1416,y:944,t:1526930065654};\\\", \\\"{x:1411,y:945,t:1526930065670};\\\", \\\"{x:1404,y:945,t:1526930065687};\\\", \\\"{x:1393,y:945,t:1526930065703};\\\", \\\"{x:1376,y:944,t:1526930065720};\\\", \\\"{x:1347,y:930,t:1526930065737};\\\", \\\"{x:1259,y:907,t:1526930065753};\\\", \\\"{x:1131,y:866,t:1526930065770};\\\", \\\"{x:942,y:805,t:1526930065787};\\\", \\\"{x:877,y:786,t:1526930065804};\\\", \\\"{x:850,y:775,t:1526930065820};\\\", \\\"{x:830,y:767,t:1526930065838};\\\", \\\"{x:815,y:763,t:1526930065854};\\\", \\\"{x:798,y:759,t:1526930065871};\\\", \\\"{x:778,y:757,t:1526930065888};\\\", \\\"{x:772,y:755,t:1526930065904};\\\", \\\"{x:769,y:755,t:1526930065921};\\\", \\\"{x:762,y:755,t:1526930065937};\\\", \\\"{x:757,y:755,t:1526930065954};\\\", \\\"{x:749,y:756,t:1526930065971};\\\", \\\"{x:741,y:757,t:1526930065987};\\\", \\\"{x:730,y:757,t:1526930066004};\\\", \\\"{x:720,y:757,t:1526930066021};\\\", \\\"{x:711,y:759,t:1526930066039};\\\", \\\"{x:700,y:761,t:1526930066055};\\\", \\\"{x:691,y:761,t:1526930066071};\\\", \\\"{x:680,y:764,t:1526930066088};\\\", \\\"{x:663,y:766,t:1526930066105};\\\", \\\"{x:647,y:769,t:1526930066122};\\\", \\\"{x:632,y:769,t:1526930066139};\\\", \\\"{x:613,y:770,t:1526930066155};\\\", \\\"{x:603,y:770,t:1526930066171};\\\", \\\"{x:596,y:770,t:1526930066188};\\\", \\\"{x:592,y:770,t:1526930066205};\\\", \\\"{x:590,y:770,t:1526930066222};\\\", \\\"{x:588,y:770,t:1526930066238};\\\", \\\"{x:581,y:768,t:1526930066256};\\\", \\\"{x:575,y:764,t:1526930066273};\\\", \\\"{x:570,y:763,t:1526930066289};\\\", \\\"{x:567,y:761,t:1526930066306};\\\", \\\"{x:562,y:758,t:1526930066323};\\\", \\\"{x:557,y:756,t:1526930066340};\\\", \\\"{x:552,y:753,t:1526930066357};\\\", \\\"{x:548,y:752,t:1526930066372};\\\", \\\"{x:547,y:750,t:1526930066467};\\\", \\\"{x:540,y:746,t:1526930066482};\\\", \\\"{x:527,y:739,t:1526930066499};\\\", \\\"{x:519,y:735,t:1526930066516};\\\", \\\"{x:517,y:735,t:1526930066532};\\\", \\\"{x:516,y:735,t:1526930066549};\\\", \\\"{x:518,y:733,t:1526930066826};\\\", \\\"{x:519,y:733,t:1526930066834};\\\", \\\"{x:520,y:732,t:1526930066849};\\\", \\\"{x:523,y:731,t:1526930066866};\\\", \\\"{x:543,y:729,t:1526930066883};\\\", \\\"{x:558,y:729,t:1526930066900};\\\", \\\"{x:595,y:729,t:1526930066916};\\\", \\\"{x:610,y:729,t:1526930066933};\\\", \\\"{x:632,y:729,t:1526930066950};\\\", \\\"{x:646,y:729,t:1526930066966};\\\", \\\"{x:659,y:729,t:1526930066982};\\\", \\\"{x:665,y:729,t:1526930067000};\\\", \\\"{x:667,y:729,t:1526930067016};\\\", \\\"{x:668,y:729,t:1526930067033};\\\", \\\"{x:669,y:729,t:1526930067051};\\\", \\\"{x:671,y:728,t:1526930067067};\\\", \\\"{x:673,y:728,t:1526930067083};\\\", \\\"{x:674,y:727,t:1526930067100};\\\" ] }, { \\\"rt\\\": 60618, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 12, \\\"time_elapsed\\\": 480402, \\\"internal_node_id\\\": \\\"0.0-6.0-2.0\\\", \\\"subject\\\": \\\"GQ35Z\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"charlie\\\", \\\"condition\\\": \\\"111\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"duration+contained\\\", \\\"q\\\": 8, \\\"clicks\\\": 3.5, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XInside-YFull\\\", \\\"correct\\\": 1, \\\"orth_correct\\\": 0, \\\"answer\\\": [ \\\"G\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-B -X -B -B -F -E -E -O -O -O -B -F -G -G -C -C -G -G -G -G -E -E -E -G -C -C \\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:681,y:728,t:1526930068323};\\\", \\\"{x:692,y:736,t:1526930068335};\\\", \\\"{x:783,y:771,t:1526930068399};\\\", \\\"{x:795,y:771,t:1526930068413};\\\", \\\"{x:803,y:771,t:1526930068418};\\\", \\\"{x:810,y:771,t:1526930068434};\\\", \\\"{x:826,y:769,t:1526930068451};\\\", \\\"{x:829,y:766,t:1526930068468};\\\", \\\"{x:827,y:767,t:1526930068595};\\\", \\\"{x:824,y:767,t:1526930068602};\\\", \\\"{x:820,y:771,t:1526930068610};\\\", \\\"{x:820,y:771,t:1526930068618};\\\", \\\"{x:735,y:758,t:1526930068902};\\\", \\\"{x:735,y:758,t:1526930068994};\\\", \\\"{x:735,y:757,t:1526930069212};\\\", \\\"{x:736,y:758,t:1526930069219};\\\", \\\"{x:737,y:759,t:1526930069235};\\\", \\\"{x:737,y:760,t:1526930069258};\\\", \\\"{x:736,y:760,t:1526930070323};\\\", \\\"{x:737,y:760,t:1526930072851};\\\", \\\"{x:738,y:760,t:1526930072883};\\\", \\\"{x:739,y:760,t:1526930072891};\\\", \\\"{x:740,y:759,t:1526930073562};\\\", \\\"{x:740,y:758,t:1526930073579};\\\", \\\"{x:741,y:758,t:1526930073588};\\\", \\\"{x:743,y:756,t:1526930073605};\\\", \\\"{x:745,y:756,t:1526930073621};\\\", \\\"{x:747,y:753,t:1526930073638};\\\", \\\"{x:751,y:750,t:1526930073656};\\\", \\\"{x:756,y:746,t:1526930073671};\\\", \\\"{x:765,y:739,t:1526930073688};\\\", \\\"{x:770,y:736,t:1526930073705};\\\", \\\"{x:782,y:726,t:1526930073721};\\\", \\\"{x:802,y:717,t:1526930073738};\\\", \\\"{x:829,y:705,t:1526930073755};\\\", \\\"{x:854,y:700,t:1526930073771};\\\", \\\"{x:876,y:696,t:1526930073788};\\\", \\\"{x:893,y:693,t:1526930073805};\\\", \\\"{x:910,y:687,t:1526930073822};\\\", \\\"{x:927,y:684,t:1526930073838};\\\", \\\"{x:940,y:682,t:1526930073855};\\\", \\\"{x:948,y:678,t:1526930073871};\\\", \\\"{x:957,y:676,t:1526930073888};\\\", \\\"{x:961,y:674,t:1526930073905};\\\", \\\"{x:968,y:671,t:1526930073921};\\\", \\\"{x:984,y:667,t:1526930073939};\\\", \\\"{x:1006,y:663,t:1526930073955};\\\", \\\"{x:1020,y:661,t:1526930073972};\\\", \\\"{x:1035,y:661,t:1526930073988};\\\", \\\"{x:1054,y:661,t:1526930074005};\\\", \\\"{x:1070,y:661,t:1526930074022};\\\", \\\"{x:1085,y:661,t:1526930074038};\\\", \\\"{x:1099,y:661,t:1526930074055};\\\", \\\"{x:1116,y:663,t:1526930074072};\\\", \\\"{x:1133,y:663,t:1526930074088};\\\", \\\"{x:1146,y:669,t:1526930074105};\\\", \\\"{x:1160,y:671,t:1526930074122};\\\", \\\"{x:1161,y:671,t:1526930074139};\\\", \\\"{x:1169,y:672,t:1526930074155};\\\", \\\"{x:1174,y:672,t:1526930074173};\\\", \\\"{x:1179,y:672,t:1526930074188};\\\", \\\"{x:1186,y:675,t:1526930074206};\\\", \\\"{x:1197,y:677,t:1526930074222};\\\", \\\"{x:1209,y:681,t:1526930074239};\\\", \\\"{x:1221,y:683,t:1526930074256};\\\", \\\"{x:1230,y:686,t:1526930074273};\\\", \\\"{x:1239,y:690,t:1526930074288};\\\", \\\"{x:1248,y:692,t:1526930074306};\\\", \\\"{x:1257,y:695,t:1526930074322};\\\", \\\"{x:1263,y:698,t:1526930074338};\\\", \\\"{x:1269,y:700,t:1526930074356};\\\", \\\"{x:1269,y:701,t:1526930074395};\\\", \\\"{x:1270,y:701,t:1526930074900};\\\", \\\"{x:1271,y:702,t:1526930074916};\\\", \\\"{x:1272,y:702,t:1526930074923};\\\", \\\"{x:1274,y:702,t:1526930074980};\\\", \\\"{x:1275,y:702,t:1526930075003};\\\", \\\"{x:1276,y:702,t:1526930075011};\\\", \\\"{x:1277,y:702,t:1526930075044};\\\", \\\"{x:1278,y:702,t:1526930075068};\\\", \\\"{x:1279,y:702,t:1526930075084};\\\", \\\"{x:1281,y:702,t:1526930075099};\\\", \\\"{x:1282,y:702,t:1526930075107};\\\", \\\"{x:1283,y:702,t:1526930075123};\\\", \\\"{x:1287,y:702,t:1526930075140};\\\", \\\"{x:1292,y:702,t:1526930075157};\\\", \\\"{x:1294,y:702,t:1526930075173};\\\", \\\"{x:1295,y:702,t:1526930075190};\\\", \\\"{x:1296,y:702,t:1526930075207};\\\", \\\"{x:1297,y:702,t:1526930075227};\\\", \\\"{x:1298,y:701,t:1526930075240};\\\", \\\"{x:1299,y:701,t:1526930075256};\\\", \\\"{x:1300,y:701,t:1526930075272};\\\", \\\"{x:1301,y:700,t:1526930075290};\\\", \\\"{x:1301,y:699,t:1526930075307};\\\", \\\"{x:1302,y:698,t:1526930075323};\\\", \\\"{x:1303,y:698,t:1526930075347};\\\", \\\"{x:1304,y:698,t:1526930075357};\\\", \\\"{x:1305,y:697,t:1526930075373};\\\", \\\"{x:1306,y:697,t:1526930075419};\\\", \\\"{x:1307,y:696,t:1526930075428};\\\", \\\"{x:1308,y:696,t:1526930075443};\\\", \\\"{x:1309,y:695,t:1526930075483};\\\", \\\"{x:1311,y:694,t:1526930075499};\\\", \\\"{x:1313,y:694,t:1526930075515};\\\", \\\"{x:1314,y:694,t:1526930075531};\\\", \\\"{x:1315,y:694,t:1526930075540};\\\", \\\"{x:1316,y:694,t:1526930075564};\\\", \\\"{x:1316,y:693,t:1526930075603};\\\", \\\"{x:1317,y:693,t:1526930075611};\\\", \\\"{x:1318,y:692,t:1526930075643};\\\", \\\"{x:1319,y:692,t:1526930075667};\\\", \\\"{x:1321,y:692,t:1526930075683};\\\", \\\"{x:1322,y:692,t:1526930075691};\\\", \\\"{x:1326,y:691,t:1526930075707};\\\", \\\"{x:1327,y:691,t:1526930075747};\\\", \\\"{x:1327,y:690,t:1526930075763};\\\", \\\"{x:1328,y:690,t:1526930075779};\\\", \\\"{x:1329,y:690,t:1526930075795};\\\", \\\"{x:1329,y:689,t:1526930075819};\\\", \\\"{x:1329,y:688,t:1526930076203};\\\", \\\"{x:1329,y:687,t:1526930076211};\\\", \\\"{x:1328,y:686,t:1526930076235};\\\", \\\"{x:1328,y:685,t:1526930076243};\\\", \\\"{x:1327,y:685,t:1526930076257};\\\", \\\"{x:1327,y:684,t:1526930076274};\\\", \\\"{x:1326,y:684,t:1526930076290};\\\", \\\"{x:1325,y:683,t:1526930076308};\\\", \\\"{x:1324,y:682,t:1526930076331};\\\", \\\"{x:1323,y:681,t:1526930076347};\\\", \\\"{x:1323,y:680,t:1526930076379};\\\", \\\"{x:1323,y:679,t:1526930076707};\\\", \\\"{x:1324,y:679,t:1526930076787};\\\", \\\"{x:1325,y:678,t:1526930076828};\\\", \\\"{x:1326,y:678,t:1526930076875};\\\", \\\"{x:1326,y:677,t:1526930076899};\\\", \\\"{x:1327,y:677,t:1526930076923};\\\", \\\"{x:1330,y:676,t:1526930076948};\\\", \\\"{x:1331,y:676,t:1526930076971};\\\", \\\"{x:1332,y:676,t:1526930076980};\\\", \\\"{x:1333,y:676,t:1526930076991};\\\", \\\"{x:1335,y:674,t:1526930077008};\\\", \\\"{x:1336,y:674,t:1526930077025};\\\", \\\"{x:1338,y:672,t:1526930077041};\\\", \\\"{x:1340,y:670,t:1526930077058};\\\", \\\"{x:1341,y:666,t:1526930077075};\\\", \\\"{x:1346,y:659,t:1526930077091};\\\", \\\"{x:1348,y:658,t:1526930077107};\\\", \\\"{x:1351,y:654,t:1526930077125};\\\", \\\"{x:1354,y:650,t:1526930077141};\\\", \\\"{x:1359,y:645,t:1526930077158};\\\", \\\"{x:1362,y:640,t:1526930077175};\\\", \\\"{x:1367,y:635,t:1526930077191};\\\", \\\"{x:1367,y:632,t:1526930077207};\\\", \\\"{x:1368,y:628,t:1526930077225};\\\", \\\"{x:1369,y:624,t:1526930077241};\\\", \\\"{x:1371,y:623,t:1526930077257};\\\", \\\"{x:1372,y:618,t:1526930077275};\\\", \\\"{x:1373,y:617,t:1526930077291};\\\", \\\"{x:1374,y:617,t:1526930077307};\\\", \\\"{x:1375,y:616,t:1526930077339};\\\", \\\"{x:1376,y:615,t:1526930077348};\\\", \\\"{x:1377,y:615,t:1526930077358};\\\", \\\"{x:1378,y:614,t:1526930077375};\\\", \\\"{x:1379,y:614,t:1526930077395};\\\", \\\"{x:1380,y:614,t:1526930077419};\\\", \\\"{x:1383,y:615,t:1526930077427};\\\", \\\"{x:1384,y:617,t:1526930077442};\\\", \\\"{x:1387,y:624,t:1526930077458};\\\", \\\"{x:1393,y:644,t:1526930077476};\\\", \\\"{x:1396,y:656,t:1526930077491};\\\", \\\"{x:1399,y:667,t:1526930077508};\\\", \\\"{x:1399,y:676,t:1526930077525};\\\", \\\"{x:1399,y:683,t:1526930077542};\\\", \\\"{x:1399,y:688,t:1526930077558};\\\", \\\"{x:1399,y:695,t:1526930077575};\\\", \\\"{x:1399,y:701,t:1526930077592};\\\", \\\"{x:1398,y:708,t:1526930077608};\\\", \\\"{x:1397,y:712,t:1526930077626};\\\", \\\"{x:1393,y:716,t:1526930077642};\\\", \\\"{x:1389,y:717,t:1526930077658};\\\", \\\"{x:1384,y:720,t:1526930077675};\\\", \\\"{x:1382,y:724,t:1526930077691};\\\", \\\"{x:1381,y:727,t:1526930077708};\\\", \\\"{x:1379,y:729,t:1526930077725};\\\", \\\"{x:1378,y:735,t:1526930077742};\\\", \\\"{x:1378,y:736,t:1526930077759};\\\", \\\"{x:1376,y:737,t:1526930077775};\\\", \\\"{x:1376,y:738,t:1526930077826};\\\", \\\"{x:1375,y:739,t:1526930077841};\\\", \\\"{x:1374,y:740,t:1526930077858};\\\", \\\"{x:1373,y:741,t:1526930077890};\\\", \\\"{x:1372,y:741,t:1526930077898};\\\", \\\"{x:1372,y:742,t:1526930077923};\\\", \\\"{x:1371,y:742,t:1526930077938};\\\", \\\"{x:1370,y:743,t:1526930077947};\\\", \\\"{x:1369,y:743,t:1526930077958};\\\", \\\"{x:1368,y:744,t:1526930077974};\\\", \\\"{x:1366,y:745,t:1526930077991};\\\", \\\"{x:1363,y:746,t:1526930078008};\\\", \\\"{x:1362,y:747,t:1526930078025};\\\", \\\"{x:1359,y:750,t:1526930078042};\\\", \\\"{x:1357,y:752,t:1526930078058};\\\", \\\"{x:1356,y:753,t:1526930078075};\\\", \\\"{x:1355,y:755,t:1526930078092};\\\", \\\"{x:1354,y:756,t:1526930078109};\\\", \\\"{x:1352,y:758,t:1526930078139};\\\", \\\"{x:1351,y:759,t:1526930078198};\\\", \\\"{x:1349,y:761,t:1526930078363};\\\", \\\"{x:1349,y:763,t:1526930085331};\\\", \\\"{x:1354,y:768,t:1526930085348};\\\", \\\"{x:1357,y:770,t:1526930085364};\\\", \\\"{x:1357,y:772,t:1526930085381};\\\", \\\"{x:1360,y:775,t:1526930085398};\\\", \\\"{x:1362,y:776,t:1526930085414};\\\", \\\"{x:1362,y:777,t:1526930085500};\\\", \\\"{x:1363,y:777,t:1526930085514};\\\", \\\"{x:1367,y:780,t:1526930085532};\\\", \\\"{x:1368,y:780,t:1526930085547};\\\", \\\"{x:1371,y:782,t:1526930085565};\\\", \\\"{x:1377,y:784,t:1526930085582};\\\", \\\"{x:1383,y:785,t:1526930085597};\\\", \\\"{x:1388,y:788,t:1526930085614};\\\", \\\"{x:1401,y:792,t:1526930085631};\\\", \\\"{x:1404,y:796,t:1526930085647};\\\", \\\"{x:1417,y:800,t:1526930085664};\\\", \\\"{x:1431,y:804,t:1526930085681};\\\", \\\"{x:1444,y:808,t:1526930085697};\\\", \\\"{x:1449,y:809,t:1526930085715};\\\", \\\"{x:1451,y:810,t:1526930085731};\\\", \\\"{x:1455,y:813,t:1526930085748};\\\", \\\"{x:1458,y:813,t:1526930085764};\\\", \\\"{x:1460,y:816,t:1526930085781};\\\", \\\"{x:1463,y:818,t:1526930085797};\\\", \\\"{x:1468,y:821,t:1526930085814};\\\", \\\"{x:1471,y:823,t:1526930085832};\\\", \\\"{x:1474,y:824,t:1526930085848};\\\", \\\"{x:1475,y:826,t:1526930085864};\\\", \\\"{x:1476,y:826,t:1526930085882};\\\", \\\"{x:1480,y:828,t:1526930085899};\\\", \\\"{x:1481,y:828,t:1526930085914};\\\", \\\"{x:1487,y:829,t:1526930085933};\\\", \\\"{x:1490,y:831,t:1526930085949};\\\", \\\"{x:1494,y:835,t:1526930085964};\\\", \\\"{x:1499,y:838,t:1526930085981};\\\", \\\"{x:1501,y:839,t:1526930085998};\\\", \\\"{x:1503,y:840,t:1526930086692};\\\", \\\"{x:1503,y:841,t:1526930086698};\\\", \\\"{x:1506,y:843,t:1526930086731};\\\", \\\"{x:1511,y:846,t:1526930086749};\\\", \\\"{x:1514,y:847,t:1526930086765};\\\", \\\"{x:1516,y:849,t:1526930086782};\\\", \\\"{x:1519,y:851,t:1526930086798};\\\", \\\"{x:1521,y:851,t:1526930086815};\\\", \\\"{x:1523,y:853,t:1526930086832};\\\", \\\"{x:1524,y:853,t:1526930086848};\\\", \\\"{x:1524,y:855,t:1526930086865};\\\", \\\"{x:1524,y:856,t:1526930086882};\\\", \\\"{x:1524,y:859,t:1526930086898};\\\", \\\"{x:1527,y:863,t:1526930086915};\\\", \\\"{x:1532,y:865,t:1526930086932};\\\", \\\"{x:1537,y:868,t:1526930086948};\\\", \\\"{x:1537,y:869,t:1526930086966};\\\", \\\"{x:1539,y:870,t:1526930086982};\\\", \\\"{x:1540,y:871,t:1526930086998};\\\", \\\"{x:1544,y:872,t:1526930087015};\\\", \\\"{x:1549,y:872,t:1526930087032};\\\", \\\"{x:1553,y:872,t:1526930087049};\\\", \\\"{x:1554,y:873,t:1526930087065};\\\", \\\"{x:1556,y:873,t:1526930087081};\\\", \\\"{x:1557,y:873,t:1526930087098};\\\", \\\"{x:1558,y:873,t:1526930087114};\\\", \\\"{x:1560,y:873,t:1526930087154};\\\", \\\"{x:1561,y:873,t:1526930087194};\\\", \\\"{x:1562,y:873,t:1526930087235};\\\", \\\"{x:1563,y:873,t:1526930087267};\\\", \\\"{x:1564,y:872,t:1526930087306};\\\", \\\"{x:1564,y:871,t:1526930087331};\\\", \\\"{x:1565,y:870,t:1526930087355};\\\", \\\"{x:1566,y:870,t:1526930087366};\\\", \\\"{x:1566,y:868,t:1526930087420};\\\", \\\"{x:1566,y:867,t:1526930087443};\\\", \\\"{x:1566,y:866,t:1526930087451};\\\", \\\"{x:1566,y:865,t:1526930087467};\\\", \\\"{x:1566,y:864,t:1526930087499};\\\", \\\"{x:1566,y:862,t:1526930087547};\\\", \\\"{x:1565,y:861,t:1526930087587};\\\", \\\"{x:1565,y:859,t:1526930087611};\\\", \\\"{x:1565,y:858,t:1526930087651};\\\", \\\"{x:1564,y:858,t:1526930087668};\\\", \\\"{x:1564,y:857,t:1526930087755};\\\", \\\"{x:1564,y:856,t:1526930087771};\\\", \\\"{x:1563,y:856,t:1526930088019};\\\", \\\"{x:1561,y:852,t:1526930088033};\\\", \\\"{x:1547,y:841,t:1526930088050};\\\", \\\"{x:1521,y:817,t:1526930088067};\\\", \\\"{x:1510,y:811,t:1526930088082};\\\", \\\"{x:1492,y:802,t:1526930088099};\\\", \\\"{x:1485,y:800,t:1526930088116};\\\", \\\"{x:1478,y:798,t:1526930088132};\\\", \\\"{x:1472,y:794,t:1526930088149};\\\", \\\"{x:1452,y:786,t:1526930088166};\\\", \\\"{x:1436,y:780,t:1526930088183};\\\", \\\"{x:1428,y:776,t:1526930088199};\\\", \\\"{x:1426,y:776,t:1526930088216};\\\", \\\"{x:1424,y:774,t:1526930088232};\\\", \\\"{x:1423,y:774,t:1526930088249};\\\", \\\"{x:1422,y:773,t:1526930088267};\\\", \\\"{x:1417,y:769,t:1526930088282};\\\", \\\"{x:1406,y:764,t:1526930088300};\\\", \\\"{x:1396,y:760,t:1526930088316};\\\", \\\"{x:1392,y:758,t:1526930088334};\\\", \\\"{x:1389,y:756,t:1526930088349};\\\", \\\"{x:1387,y:756,t:1526930088366};\\\", \\\"{x:1387,y:755,t:1526930088383};\\\", \\\"{x:1386,y:755,t:1526930088451};\\\", \\\"{x:1385,y:755,t:1526930088491};\\\", \\\"{x:1384,y:755,t:1526930088523};\\\", \\\"{x:1383,y:755,t:1526930088547};\\\", \\\"{x:1382,y:755,t:1526930088563};\\\", \\\"{x:1381,y:755,t:1526930088571};\\\", \\\"{x:1379,y:755,t:1526930088587};\\\", \\\"{x:1378,y:755,t:1526930088600};\\\", \\\"{x:1377,y:755,t:1526930088619};\\\", \\\"{x:1376,y:755,t:1526930088634};\\\", \\\"{x:1372,y:755,t:1526930088649};\\\", \\\"{x:1368,y:756,t:1526930088666};\\\", \\\"{x:1364,y:756,t:1526930088682};\\\", \\\"{x:1363,y:757,t:1526930088707};\\\", \\\"{x:1362,y:757,t:1526930088723};\\\", \\\"{x:1361,y:757,t:1526930088733};\\\", \\\"{x:1360,y:757,t:1526930088750};\\\", \\\"{x:1359,y:757,t:1526930088766};\\\", \\\"{x:1358,y:757,t:1526930088811};\\\", \\\"{x:1357,y:757,t:1526930089012};\\\", \\\"{x:1356,y:757,t:1526930089324};\\\", \\\"{x:1357,y:757,t:1526930089635};\\\", \\\"{x:1358,y:757,t:1526930089659};\\\", \\\"{x:1357,y:757,t:1526930089947};\\\", \\\"{x:1356,y:758,t:1526930089971};\\\", \\\"{x:1355,y:759,t:1526930090035};\\\", \\\"{x:1354,y:759,t:1526930090051};\\\", \\\"{x:1351,y:760,t:1526930090067};\\\", \\\"{x:1351,y:761,t:1526930090107};\\\", \\\"{x:1350,y:761,t:1526930090443};\\\", \\\"{x:1349,y:762,t:1526930090475};\\\", \\\"{x:1348,y:762,t:1526930090987};\\\", \\\"{x:1348,y:761,t:1526930093524};\\\", \\\"{x:1348,y:760,t:1526930093539};\\\", \\\"{x:1348,y:758,t:1526930093562};\\\", \\\"{x:1347,y:757,t:1526930093571};\\\", \\\"{x:1347,y:756,t:1526930093586};\\\", \\\"{x:1347,y:754,t:1526930093602};\\\", \\\"{x:1347,y:752,t:1526930093620};\\\", \\\"{x:1346,y:748,t:1526930093635};\\\", \\\"{x:1346,y:747,t:1526930093653};\\\", \\\"{x:1346,y:744,t:1526930093670};\\\", \\\"{x:1346,y:742,t:1526930093687};\\\", \\\"{x:1346,y:740,t:1526930093702};\\\", \\\"{x:1345,y:737,t:1526930093719};\\\", \\\"{x:1345,y:735,t:1526930093736};\\\", \\\"{x:1344,y:731,t:1526930093753};\\\", \\\"{x:1344,y:727,t:1526930093770};\\\", \\\"{x:1343,y:723,t:1526930093786};\\\", \\\"{x:1343,y:720,t:1526930093803};\\\", \\\"{x:1341,y:716,t:1526930093820};\\\", \\\"{x:1341,y:714,t:1526930093837};\\\", \\\"{x:1341,y:711,t:1526930093854};\\\", \\\"{x:1341,y:709,t:1526930093871};\\\", \\\"{x:1340,y:708,t:1526930093887};\\\", \\\"{x:1340,y:707,t:1526930093903};\\\", \\\"{x:1341,y:705,t:1526930093921};\\\", \\\"{x:1342,y:704,t:1526930093937};\\\", \\\"{x:1342,y:703,t:1526930093953};\\\", \\\"{x:1343,y:702,t:1526930093978};\\\", \\\"{x:1344,y:702,t:1526930096115};\\\", \\\"{x:1345,y:693,t:1526930096123};\\\", \\\"{x:1340,y:670,t:1526930096139};\\\", \\\"{x:1334,y:645,t:1526930096155};\\\", \\\"{x:1326,y:624,t:1526930096172};\\\", \\\"{x:1320,y:608,t:1526930096188};\\\", \\\"{x:1317,y:597,t:1526930096205};\\\", \\\"{x:1316,y:591,t:1526930096222};\\\", \\\"{x:1314,y:585,t:1526930096238};\\\", \\\"{x:1314,y:581,t:1526930096256};\\\", \\\"{x:1313,y:578,t:1526930096272};\\\", \\\"{x:1311,y:573,t:1526930096288};\\\", \\\"{x:1310,y:570,t:1526930096305};\\\", \\\"{x:1308,y:566,t:1526930096322};\\\", \\\"{x:1307,y:564,t:1526930096339};\\\", \\\"{x:1306,y:563,t:1526930096355};\\\", \\\"{x:1303,y:562,t:1526930096373};\\\", \\\"{x:1300,y:561,t:1526930096388};\\\", \\\"{x:1297,y:560,t:1526930096406};\\\", \\\"{x:1295,y:560,t:1526930096422};\\\", \\\"{x:1292,y:559,t:1526930096439};\\\", \\\"{x:1286,y:559,t:1526930096455};\\\", \\\"{x:1283,y:559,t:1526930096473};\\\", \\\"{x:1281,y:559,t:1526930096488};\\\", \\\"{x:1280,y:559,t:1526930096595};\\\", \\\"{x:1282,y:557,t:1526930096916};\\\", \\\"{x:1284,y:557,t:1526930096963};\\\", \\\"{x:1285,y:556,t:1526930096995};\\\", \\\"{x:1285,y:555,t:1526930097043};\\\", \\\"{x:1287,y:555,t:1526930097059};\\\", \\\"{x:1288,y:554,t:1526930097082};\\\", \\\"{x:1291,y:553,t:1526930097107};\\\", \\\"{x:1292,y:553,t:1526930097122};\\\", \\\"{x:1295,y:551,t:1526930097139};\\\", \\\"{x:1297,y:550,t:1526930097156};\\\", \\\"{x:1301,y:547,t:1526930097172};\\\", \\\"{x:1305,y:545,t:1526930097190};\\\", \\\"{x:1310,y:542,t:1526930097206};\\\", \\\"{x:1316,y:539,t:1526930097222};\\\", \\\"{x:1323,y:534,t:1526930097239};\\\", \\\"{x:1327,y:531,t:1526930097256};\\\", \\\"{x:1334,y:528,t:1526930097273};\\\", \\\"{x:1342,y:522,t:1526930097289};\\\", \\\"{x:1354,y:510,t:1526930097306};\\\", \\\"{x:1360,y:504,t:1526930097323};\\\", \\\"{x:1364,y:500,t:1526930097340};\\\", \\\"{x:1367,y:496,t:1526930097356};\\\", \\\"{x:1370,y:492,t:1526930097372};\\\", \\\"{x:1373,y:491,t:1526930097389};\\\", \\\"{x:1377,y:488,t:1526930097406};\\\", \\\"{x:1384,y:483,t:1526930097422};\\\", \\\"{x:1389,y:479,t:1526930097439};\\\", \\\"{x:1391,y:477,t:1526930097456};\\\", \\\"{x:1394,y:475,t:1526930097472};\\\", \\\"{x:1396,y:474,t:1526930097489};\\\", \\\"{x:1400,y:472,t:1526930097506};\\\", \\\"{x:1401,y:470,t:1526930097523};\\\", \\\"{x:1403,y:467,t:1526930097571};\\\", \\\"{x:1406,y:466,t:1526930097579};\\\", \\\"{x:1409,y:464,t:1526930097590};\\\", \\\"{x:1411,y:461,t:1526930097606};\\\", \\\"{x:1411,y:460,t:1526930097622};\\\", \\\"{x:1414,y:458,t:1526930097640};\\\", \\\"{x:1414,y:457,t:1526930097656};\\\", \\\"{x:1414,y:456,t:1526930097898};\\\", \\\"{x:1413,y:456,t:1526930097987};\\\", \\\"{x:1412,y:456,t:1526930098011};\\\", \\\"{x:1411,y:457,t:1526930098027};\\\", \\\"{x:1409,y:457,t:1526930098186};\\\", \\\"{x:1406,y:459,t:1526930098194};\\\", \\\"{x:1405,y:459,t:1526930098206};\\\", \\\"{x:1404,y:460,t:1526930098223};\\\", \\\"{x:1403,y:461,t:1526930098240};\\\", \\\"{x:1403,y:462,t:1526930098256};\\\", \\\"{x:1403,y:463,t:1526930098291};\\\", \\\"{x:1403,y:464,t:1526930098306};\\\", \\\"{x:1399,y:466,t:1526930098323};\\\", \\\"{x:1390,y:469,t:1526930098340};\\\", \\\"{x:1372,y:472,t:1526930098357};\\\", \\\"{x:1339,y:478,t:1526930098373};\\\", \\\"{x:1292,y:489,t:1526930098391};\\\", \\\"{x:1203,y:503,t:1526930098407};\\\", \\\"{x:1101,y:513,t:1526930098424};\\\", \\\"{x:988,y:525,t:1526930098441};\\\", \\\"{x:858,y:525,t:1526930098458};\\\", \\\"{x:743,y:531,t:1526930098473};\\\", \\\"{x:582,y:533,t:1526930098490};\\\", \\\"{x:543,y:533,t:1526930098501};\\\", \\\"{x:463,y:533,t:1526930098518};\\\", \\\"{x:407,y:533,t:1526930098535};\\\", \\\"{x:334,y:533,t:1526930098559};\\\", \\\"{x:297,y:534,t:1526930098574};\\\", \\\"{x:257,y:534,t:1526930098592};\\\", \\\"{x:222,y:530,t:1526930098609};\\\", \\\"{x:196,y:528,t:1526930098625};\\\", \\\"{x:165,y:519,t:1526930098642};\\\", \\\"{x:162,y:517,t:1526930098660};\\\", \\\"{x:162,y:516,t:1526930098706};\\\", \\\"{x:163,y:515,t:1526930098763};\\\", \\\"{x:165,y:515,t:1526930098777};\\\", \\\"{x:171,y:516,t:1526930098791};\\\", \\\"{x:183,y:523,t:1526930098809};\\\", \\\"{x:214,y:541,t:1526930098826};\\\", \\\"{x:240,y:555,t:1526930098842};\\\", \\\"{x:271,y:569,t:1526930098859};\\\", \\\"{x:300,y:578,t:1526930098876};\\\", \\\"{x:309,y:580,t:1526930098891};\\\", \\\"{x:328,y:588,t:1526930098909};\\\", \\\"{x:341,y:594,t:1526930098926};\\\", \\\"{x:356,y:598,t:1526930098941};\\\", \\\"{x:367,y:602,t:1526930098960};\\\", \\\"{x:373,y:603,t:1526930098975};\\\", \\\"{x:376,y:603,t:1526930098992};\\\", \\\"{x:379,y:604,t:1526930099009};\\\", \\\"{x:382,y:604,t:1526930099025};\\\", \\\"{x:386,y:604,t:1526930099041};\\\", \\\"{x:394,y:600,t:1526930099059};\\\", \\\"{x:404,y:598,t:1526930099076};\\\", \\\"{x:414,y:597,t:1526930099092};\\\", \\\"{x:426,y:593,t:1526930099110};\\\", \\\"{x:436,y:588,t:1526930099126};\\\", \\\"{x:443,y:586,t:1526930099142};\\\", \\\"{x:449,y:582,t:1526930099159};\\\", \\\"{x:451,y:580,t:1526930099175};\\\", \\\"{x:453,y:579,t:1526930099193};\\\", \\\"{x:456,y:576,t:1526930099209};\\\", \\\"{x:462,y:573,t:1526930099226};\\\", \\\"{x:471,y:567,t:1526930099243};\\\", \\\"{x:480,y:563,t:1526930099259};\\\", \\\"{x:495,y:557,t:1526930099277};\\\", \\\"{x:512,y:553,t:1526930099293};\\\", \\\"{x:534,y:551,t:1526930099309};\\\", \\\"{x:555,y:547,t:1526930099326};\\\", \\\"{x:575,y:545,t:1526930099343};\\\", \\\"{x:587,y:543,t:1526930099359};\\\", \\\"{x:591,y:543,t:1526930099376};\\\", \\\"{x:593,y:543,t:1526930099393};\\\", \\\"{x:594,y:543,t:1526930099475};\\\", \\\"{x:595,y:543,t:1526930099586};\\\", \\\"{x:595,y:542,t:1526930099594};\\\", \\\"{x:597,y:541,t:1526930099609};\\\", \\\"{x:599,y:541,t:1526930099626};\\\", \\\"{x:601,y:541,t:1526930099827};\\\", \\\"{x:620,y:538,t:1526930099842};\\\", \\\"{x:647,y:536,t:1526930099861};\\\", \\\"{x:736,y:532,t:1526930099877};\\\", \\\"{x:836,y:532,t:1526930099893};\\\", \\\"{x:944,y:532,t:1526930099911};\\\", \\\"{x:999,y:529,t:1526930099927};\\\", \\\"{x:1095,y:523,t:1526930099943};\\\", \\\"{x:1187,y:521,t:1526930099960};\\\", \\\"{x:1240,y:521,t:1526930099976};\\\", \\\"{x:1262,y:521,t:1526930099993};\\\", \\\"{x:1271,y:521,t:1526930100010};\\\", \\\"{x:1274,y:520,t:1526930100026};\\\", \\\"{x:1274,y:515,t:1526930100043};\\\", \\\"{x:1274,y:508,t:1526930100060};\\\", \\\"{x:1274,y:501,t:1526930100076};\\\", \\\"{x:1274,y:495,t:1526930100093};\\\", \\\"{x:1274,y:494,t:1526930100111};\\\", \\\"{x:1277,y:490,t:1526930100127};\\\", \\\"{x:1280,y:487,t:1526930100143};\\\", \\\"{x:1284,y:486,t:1526930100160};\\\", \\\"{x:1292,y:482,t:1526930100177};\\\", \\\"{x:1312,y:479,t:1526930100193};\\\", \\\"{x:1381,y:474,t:1526930100211};\\\", \\\"{x:1448,y:474,t:1526930100227};\\\", \\\"{x:1484,y:476,t:1526930100244};\\\", \\\"{x:1515,y:482,t:1526930100261};\\\", \\\"{x:1539,y:493,t:1526930100278};\\\", \\\"{x:1560,y:501,t:1526930100293};\\\", \\\"{x:1576,y:510,t:1526930100311};\\\", \\\"{x:1584,y:521,t:1526930100327};\\\", \\\"{x:1589,y:532,t:1526930100344};\\\", \\\"{x:1591,y:539,t:1526930100361};\\\", \\\"{x:1593,y:549,t:1526930100378};\\\", \\\"{x:1595,y:556,t:1526930100393};\\\", \\\"{x:1595,y:562,t:1526930100411};\\\", \\\"{x:1586,y:566,t:1526930100427};\\\", \\\"{x:1581,y:571,t:1526930100443};\\\", \\\"{x:1574,y:577,t:1526930100461};\\\", \\\"{x:1568,y:584,t:1526930100477};\\\", \\\"{x:1564,y:593,t:1526930100494};\\\", \\\"{x:1557,y:604,t:1526930100510};\\\", \\\"{x:1548,y:619,t:1526930100528};\\\", \\\"{x:1540,y:633,t:1526930100543};\\\", \\\"{x:1537,y:646,t:1526930100561};\\\", \\\"{x:1532,y:658,t:1526930100578};\\\", \\\"{x:1530,y:668,t:1526930100593};\\\", \\\"{x:1529,y:683,t:1526930100611};\\\", \\\"{x:1526,y:694,t:1526930100628};\\\", \\\"{x:1524,y:704,t:1526930100643};\\\", \\\"{x:1520,y:717,t:1526930100660};\\\", \\\"{x:1517,y:725,t:1526930100678};\\\", \\\"{x:1515,y:731,t:1526930100694};\\\", \\\"{x:1514,y:736,t:1526930100710};\\\", \\\"{x:1514,y:739,t:1526930100727};\\\", \\\"{x:1514,y:740,t:1526930100745};\\\", \\\"{x:1515,y:745,t:1526930100760};\\\", \\\"{x:1516,y:747,t:1526930100777};\\\", \\\"{x:1516,y:756,t:1526930100795};\\\", \\\"{x:1517,y:762,t:1526930100811};\\\", \\\"{x:1519,y:770,t:1526930100828};\\\", \\\"{x:1521,y:778,t:1526930100845};\\\", \\\"{x:1521,y:781,t:1526930100861};\\\", \\\"{x:1523,y:783,t:1526930100878};\\\", \\\"{x:1523,y:786,t:1526930100895};\\\", \\\"{x:1524,y:788,t:1526930100911};\\\", \\\"{x:1525,y:791,t:1526930100927};\\\", \\\"{x:1528,y:796,t:1526930100944};\\\", \\\"{x:1528,y:798,t:1526930100960};\\\", \\\"{x:1528,y:800,t:1526930100977};\\\", \\\"{x:1529,y:803,t:1526930100993};\\\", \\\"{x:1530,y:804,t:1526930101010};\\\", \\\"{x:1530,y:805,t:1526930101027};\\\", \\\"{x:1530,y:806,t:1526930101050};\\\", \\\"{x:1531,y:806,t:1526930101061};\\\", \\\"{x:1531,y:807,t:1526930101611};\\\", \\\"{x:1527,y:792,t:1526930101629};\\\", \\\"{x:1511,y:757,t:1526930101644};\\\", \\\"{x:1491,y:710,t:1526930101661};\\\", \\\"{x:1479,y:672,t:1526930101678};\\\", \\\"{x:1470,y:642,t:1526930101694};\\\", \\\"{x:1469,y:637,t:1526930101711};\\\", \\\"{x:1461,y:607,t:1526930101728};\\\", \\\"{x:1448,y:582,t:1526930101744};\\\", \\\"{x:1443,y:562,t:1526930101761};\\\", \\\"{x:1440,y:543,t:1526930101778};\\\", \\\"{x:1440,y:536,t:1526930101794};\\\", \\\"{x:1440,y:530,t:1526930101811};\\\", \\\"{x:1441,y:527,t:1526930101828};\\\", \\\"{x:1445,y:519,t:1526930101844};\\\", \\\"{x:1445,y:512,t:1526930101861};\\\", \\\"{x:1445,y:504,t:1526930101878};\\\", \\\"{x:1445,y:501,t:1526930101894};\\\", \\\"{x:1445,y:499,t:1526930101912};\\\", \\\"{x:1445,y:496,t:1526930101928};\\\", \\\"{x:1444,y:495,t:1526930101945};\\\", \\\"{x:1439,y:492,t:1526930101961};\\\", \\\"{x:1432,y:488,t:1526930101979};\\\", \\\"{x:1431,y:488,t:1526930101995};\\\", \\\"{x:1429,y:488,t:1526930102011};\\\", \\\"{x:1428,y:488,t:1526930102029};\\\", \\\"{x:1427,y:488,t:1526930102046};\\\", \\\"{x:1423,y:489,t:1526930102061};\\\", \\\"{x:1416,y:505,t:1526930102079};\\\", \\\"{x:1411,y:522,t:1526930102095};\\\", \\\"{x:1406,y:539,t:1526930102112};\\\", \\\"{x:1402,y:556,t:1526930102128};\\\", \\\"{x:1397,y:572,t:1526930102146};\\\", \\\"{x:1393,y:577,t:1526930102161};\\\", \\\"{x:1382,y:589,t:1526930102179};\\\", \\\"{x:1370,y:601,t:1526930102196};\\\", \\\"{x:1364,y:610,t:1526930102212};\\\", \\\"{x:1359,y:615,t:1526930102229};\\\", \\\"{x:1355,y:623,t:1526930102246};\\\", \\\"{x:1350,y:633,t:1526930102262};\\\", \\\"{x:1348,y:637,t:1526930102279};\\\", \\\"{x:1342,y:648,t:1526930102296};\\\", \\\"{x:1341,y:659,t:1526930102312};\\\", \\\"{x:1340,y:671,t:1526930102329};\\\", \\\"{x:1338,y:675,t:1526930102346};\\\", \\\"{x:1337,y:680,t:1526930102362};\\\", \\\"{x:1337,y:686,t:1526930102378};\\\", \\\"{x:1336,y:693,t:1526930102396};\\\", \\\"{x:1334,y:703,t:1526930102412};\\\", \\\"{x:1331,y:709,t:1526930102428};\\\", \\\"{x:1328,y:712,t:1526930102445};\\\", \\\"{x:1324,y:714,t:1526930102462};\\\", \\\"{x:1322,y:715,t:1526930102478};\\\", \\\"{x:1321,y:717,t:1526930102496};\\\", \\\"{x:1320,y:721,t:1526930102513};\\\", \\\"{x:1319,y:724,t:1526930102528};\\\", \\\"{x:1317,y:726,t:1526930102545};\\\", \\\"{x:1317,y:727,t:1526930102562};\\\", \\\"{x:1316,y:728,t:1526930102579};\\\", \\\"{x:1315,y:729,t:1526930102596};\\\", \\\"{x:1315,y:730,t:1526930102627};\\\", \\\"{x:1315,y:731,t:1526930102634};\\\", \\\"{x:1315,y:732,t:1526930102650};\\\", \\\"{x:1315,y:733,t:1526930102673};\\\", \\\"{x:1315,y:734,t:1526930102681};\\\", \\\"{x:1315,y:735,t:1526930104475};\\\", \\\"{x:1315,y:737,t:1526930104699};\\\", \\\"{x:1315,y:739,t:1526930104714};\\\", \\\"{x:1317,y:743,t:1526930104731};\\\", \\\"{x:1320,y:746,t:1526930104747};\\\", \\\"{x:1323,y:748,t:1526930104764};\\\", \\\"{x:1326,y:749,t:1526930104781};\\\", \\\"{x:1328,y:752,t:1526930104798};\\\", \\\"{x:1332,y:754,t:1526930104814};\\\", \\\"{x:1334,y:756,t:1526930104831};\\\", \\\"{x:1339,y:760,t:1526930104847};\\\", \\\"{x:1340,y:760,t:1526930104863};\\\", \\\"{x:1341,y:761,t:1526930104880};\\\", \\\"{x:1343,y:763,t:1526930104897};\\\", \\\"{x:1347,y:764,t:1526930104913};\\\", \\\"{x:1350,y:767,t:1526930104930};\\\", \\\"{x:1350,y:768,t:1526930105434};\\\", \\\"{x:1350,y:769,t:1526930105532};\\\", \\\"{x:1350,y:770,t:1526930105635};\\\", \\\"{x:1344,y:769,t:1526930105651};\\\", \\\"{x:1342,y:769,t:1526930105665};\\\", \\\"{x:1338,y:767,t:1526930105681};\\\", \\\"{x:1336,y:767,t:1526930105698};\\\", \\\"{x:1335,y:767,t:1526930105715};\\\", \\\"{x:1335,y:766,t:1526930105763};\\\", \\\"{x:1335,y:765,t:1526930105795};\\\", \\\"{x:1335,y:763,t:1526930105802};\\\", \\\"{x:1335,y:762,t:1526930105819};\\\", \\\"{x:1335,y:761,t:1526930105831};\\\", \\\"{x:1332,y:757,t:1526930105848};\\\", \\\"{x:1330,y:753,t:1526930105865};\\\", \\\"{x:1328,y:750,t:1526930105882};\\\", \\\"{x:1327,y:749,t:1526930105898};\\\", \\\"{x:1327,y:748,t:1526930105915};\\\", \\\"{x:1327,y:746,t:1526930105938};\\\", \\\"{x:1327,y:744,t:1526930105955};\\\", \\\"{x:1327,y:743,t:1526930105970};\\\", \\\"{x:1327,y:742,t:1526930105981};\\\", \\\"{x:1327,y:741,t:1526930105998};\\\", \\\"{x:1327,y:737,t:1526930106015};\\\", \\\"{x:1329,y:732,t:1526930106032};\\\", \\\"{x:1330,y:725,t:1526930106048};\\\", \\\"{x:1335,y:720,t:1526930106065};\\\", \\\"{x:1337,y:714,t:1526930106082};\\\", \\\"{x:1342,y:708,t:1526930106098};\\\", \\\"{x:1344,y:703,t:1526930106115};\\\", \\\"{x:1346,y:698,t:1526930106132};\\\", \\\"{x:1350,y:694,t:1526930106147};\\\", \\\"{x:1354,y:688,t:1526930106166};\\\", \\\"{x:1354,y:681,t:1526930106181};\\\", \\\"{x:1358,y:676,t:1526930106198};\\\", \\\"{x:1359,y:670,t:1526930106215};\\\", \\\"{x:1362,y:664,t:1526930106232};\\\", \\\"{x:1365,y:658,t:1526930106248};\\\", \\\"{x:1367,y:655,t:1526930106265};\\\", \\\"{x:1373,y:647,t:1526930106283};\\\", \\\"{x:1373,y:645,t:1526930106298};\\\", \\\"{x:1376,y:638,t:1526930106315};\\\", \\\"{x:1378,y:631,t:1526930106331};\\\", \\\"{x:1381,y:626,t:1526930106349};\\\", \\\"{x:1381,y:623,t:1526930106365};\\\", \\\"{x:1383,y:620,t:1526930106382};\\\", \\\"{x:1385,y:616,t:1526930106399};\\\", \\\"{x:1386,y:612,t:1526930106415};\\\", \\\"{x:1388,y:609,t:1526930106432};\\\", \\\"{x:1389,y:608,t:1526930106449};\\\", \\\"{x:1389,y:605,t:1526930106465};\\\", \\\"{x:1392,y:602,t:1526930106482};\\\", \\\"{x:1393,y:601,t:1526930106498};\\\", \\\"{x:1395,y:597,t:1526930106515};\\\", \\\"{x:1396,y:595,t:1526930106532};\\\", \\\"{x:1396,y:594,t:1526930106549};\\\", \\\"{x:1396,y:591,t:1526930106565};\\\", \\\"{x:1398,y:589,t:1526930106582};\\\", \\\"{x:1398,y:588,t:1526930106599};\\\", \\\"{x:1398,y:586,t:1526930106615};\\\", \\\"{x:1400,y:584,t:1526930106632};\\\", \\\"{x:1401,y:583,t:1526930106649};\\\", \\\"{x:1401,y:582,t:1526930106665};\\\", \\\"{x:1402,y:582,t:1526930106682};\\\", \\\"{x:1402,y:579,t:1526930106698};\\\", \\\"{x:1403,y:578,t:1526930106731};\\\", \\\"{x:1404,y:578,t:1526930106754};\\\", \\\"{x:1405,y:576,t:1526930106811};\\\", \\\"{x:1405,y:575,t:1526930106827};\\\", \\\"{x:1406,y:573,t:1526930106835};\\\", \\\"{x:1407,y:572,t:1526930106851};\\\", \\\"{x:1408,y:571,t:1526930106866};\\\", \\\"{x:1408,y:570,t:1526930106882};\\\", \\\"{x:1409,y:567,t:1526930106899};\\\", \\\"{x:1411,y:565,t:1526930106923};\\\", \\\"{x:1412,y:564,t:1526930106949};\\\", \\\"{x:1412,y:563,t:1526930106970};\\\", \\\"{x:1412,y:562,t:1526930106995};\\\", \\\"{x:1412,y:561,t:1526930107010};\\\", \\\"{x:1413,y:560,t:1526930107043};\\\", \\\"{x:1407,y:560,t:1526930108612};\\\", \\\"{x:1400,y:560,t:1526930108618};\\\", \\\"{x:1389,y:560,t:1526930108634};\\\", \\\"{x:1343,y:559,t:1526930108651};\\\", \\\"{x:1257,y:559,t:1526930108666};\\\", \\\"{x:1159,y:563,t:1526930108684};\\\", \\\"{x:1028,y:562,t:1526930108700};\\\", \\\"{x:899,y:547,t:1526930108718};\\\", \\\"{x:778,y:535,t:1526930108733};\\\", \\\"{x:673,y:527,t:1526930108750};\\\", \\\"{x:604,y:518,t:1526930108766};\\\", \\\"{x:576,y:518,t:1526930108784};\\\", \\\"{x:553,y:515,t:1526930108801};\\\", \\\"{x:546,y:515,t:1526930108817};\\\", \\\"{x:544,y:515,t:1526930108882};\\\", \\\"{x:542,y:515,t:1526930108889};\\\", \\\"{x:540,y:516,t:1526930108900};\\\", \\\"{x:535,y:521,t:1526930108918};\\\", \\\"{x:535,y:530,t:1526930108933};\\\", \\\"{x:535,y:540,t:1526930108950};\\\", \\\"{x:535,y:546,t:1526930108968};\\\", \\\"{x:535,y:549,t:1526930108984};\\\", \\\"{x:539,y:553,t:1526930109000};\\\", \\\"{x:555,y:561,t:1526930109018};\\\", \\\"{x:591,y:566,t:1526930109035};\\\", \\\"{x:618,y:572,t:1526930109050};\\\", \\\"{x:639,y:573,t:1526930109067};\\\", \\\"{x:658,y:572,t:1526930109084};\\\", \\\"{x:676,y:567,t:1526930109100};\\\", \\\"{x:690,y:567,t:1526930109117};\\\", \\\"{x:704,y:564,t:1526930109134};\\\", \\\"{x:714,y:564,t:1526930109151};\\\", \\\"{x:719,y:561,t:1526930109168};\\\", \\\"{x:720,y:561,t:1526930109184};\\\", \\\"{x:722,y:558,t:1526930109329};\\\", \\\"{x:731,y:558,t:1526930109338};\\\", \\\"{x:736,y:558,t:1526930109350};\\\", \\\"{x:753,y:557,t:1526930109368};\\\", \\\"{x:772,y:557,t:1526930109385};\\\", \\\"{x:783,y:557,t:1526930109400};\\\", \\\"{x:789,y:556,t:1526930109417};\\\", \\\"{x:794,y:555,t:1526930109435};\\\", \\\"{x:796,y:555,t:1526930109450};\\\", \\\"{x:801,y:555,t:1526930109467};\\\", \\\"{x:808,y:553,t:1526930109484};\\\", \\\"{x:811,y:553,t:1526930109500};\\\", \\\"{x:812,y:553,t:1526930109517};\\\", \\\"{x:814,y:552,t:1526930109537};\\\", \\\"{x:815,y:552,t:1526930109578};\\\", \\\"{x:817,y:551,t:1526930109585};\\\", \\\"{x:819,y:551,t:1526930109600};\\\", \\\"{x:823,y:550,t:1526930109618};\\\", \\\"{x:824,y:550,t:1526930109635};\\\", \\\"{x:825,y:550,t:1526930109650};\\\", \\\"{x:824,y:550,t:1526930110066};\\\", \\\"{x:822,y:550,t:1526930110074};\\\", \\\"{x:821,y:550,t:1526930110084};\\\", \\\"{x:816,y:550,t:1526930110101};\\\", \\\"{x:814,y:550,t:1526930110117};\\\", \\\"{x:797,y:549,t:1526930110134};\\\", \\\"{x:762,y:545,t:1526930110151};\\\", \\\"{x:692,y:533,t:1526930110168};\\\", \\\"{x:636,y:525,t:1526930110184};\\\", \\\"{x:612,y:524,t:1526930110202};\\\", \\\"{x:608,y:522,t:1526930110217};\\\", \\\"{x:607,y:522,t:1526930110290};\\\", \\\"{x:605,y:522,t:1526930110301};\\\", \\\"{x:602,y:523,t:1526930110318};\\\", \\\"{x:601,y:523,t:1526930110354};\\\", \\\"{x:601,y:524,t:1526930110369};\\\", \\\"{x:601,y:525,t:1526930110412};\\\", \\\"{x:603,y:526,t:1526930110451};\\\", \\\"{x:605,y:527,t:1526930110468};\\\", \\\"{x:606,y:528,t:1526930110485};\\\", \\\"{x:606,y:529,t:1526930110513};\\\", \\\"{x:606,y:531,t:1526930110522};\\\", \\\"{x:608,y:533,t:1526930110537};\\\", \\\"{x:608,y:535,t:1526930110551};\\\", \\\"{x:608,y:537,t:1526930110569};\\\", \\\"{x:609,y:539,t:1526930110585};\\\", \\\"{x:610,y:539,t:1526930110785};\\\", \\\"{x:615,y:539,t:1526930110801};\\\", \\\"{x:620,y:539,t:1526930110819};\\\", \\\"{x:632,y:540,t:1526930110835};\\\", \\\"{x:650,y:540,t:1526930110851};\\\", \\\"{x:686,y:545,t:1526930110868};\\\", \\\"{x:738,y:557,t:1526930110885};\\\", \\\"{x:817,y:570,t:1526930110902};\\\", \\\"{x:897,y:581,t:1526930110918};\\\", \\\"{x:969,y:585,t:1526930110936};\\\", \\\"{x:1042,y:595,t:1526930110953};\\\", \\\"{x:1100,y:603,t:1526930110969};\\\", \\\"{x:1173,y:619,t:1526930110985};\\\", \\\"{x:1214,y:627,t:1526930111002};\\\", \\\"{x:1237,y:634,t:1526930111018};\\\", \\\"{x:1255,y:643,t:1526930111035};\\\", \\\"{x:1269,y:645,t:1526930111052};\\\", \\\"{x:1287,y:649,t:1526930111068};\\\", \\\"{x:1302,y:653,t:1526930111085};\\\", \\\"{x:1314,y:658,t:1526930111102};\\\", \\\"{x:1326,y:662,t:1526930111118};\\\", \\\"{x:1342,y:668,t:1526930111135};\\\", \\\"{x:1356,y:674,t:1526930111152};\\\", \\\"{x:1366,y:675,t:1526930111168};\\\", \\\"{x:1387,y:679,t:1526930111186};\\\", \\\"{x:1396,y:679,t:1526930111202};\\\", \\\"{x:1398,y:679,t:1526930111219};\\\", \\\"{x:1399,y:679,t:1526930111236};\\\", \\\"{x:1401,y:679,t:1526930111253};\\\", \\\"{x:1402,y:679,t:1526930111269};\\\", \\\"{x:1402,y:678,t:1526930111286};\\\", \\\"{x:1402,y:676,t:1526930111302};\\\", \\\"{x:1402,y:675,t:1526930111319};\\\", \\\"{x:1402,y:662,t:1526930111336};\\\", \\\"{x:1394,y:628,t:1526930111353};\\\", \\\"{x:1369,y:593,t:1526930111370};\\\", \\\"{x:1368,y:592,t:1526930111386};\\\", \\\"{x:1363,y:584,t:1526930111402};\\\", \\\"{x:1355,y:574,t:1526930111420};\\\", \\\"{x:1337,y:548,t:1526930111436};\\\", \\\"{x:1319,y:527,t:1526930111453};\\\", \\\"{x:1313,y:521,t:1526930111470};\\\", \\\"{x:1311,y:514,t:1526930111485};\\\", \\\"{x:1311,y:505,t:1526930111503};\\\", \\\"{x:1309,y:485,t:1526930111520};\\\", \\\"{x:1302,y:463,t:1526930111535};\\\", \\\"{x:1292,y:435,t:1526930111552};\\\", \\\"{x:1289,y:413,t:1526930111570};\\\", \\\"{x:1298,y:401,t:1526930111586};\\\", \\\"{x:1311,y:392,t:1526930111603};\\\", \\\"{x:1316,y:386,t:1526930111619};\\\", \\\"{x:1317,y:384,t:1526930111636};\\\", \\\"{x:1318,y:384,t:1526930111666};\\\", \\\"{x:1325,y:384,t:1526930111699};\\\", \\\"{x:1333,y:393,t:1526930111706};\\\", \\\"{x:1342,y:400,t:1526930111720};\\\", \\\"{x:1362,y:410,t:1526930111736};\\\", \\\"{x:1376,y:420,t:1526930111753};\\\", \\\"{x:1386,y:430,t:1526930111770};\\\", \\\"{x:1390,y:439,t:1526930111786};\\\", \\\"{x:1392,y:449,t:1526930111802};\\\", \\\"{x:1398,y:462,t:1526930111819};\\\", \\\"{x:1406,y:472,t:1526930111837};\\\", \\\"{x:1415,y:482,t:1526930111853};\\\", \\\"{x:1419,y:490,t:1526930111870};\\\", \\\"{x:1424,y:499,t:1526930111886};\\\", \\\"{x:1426,y:505,t:1526930111902};\\\", \\\"{x:1427,y:511,t:1526930111919};\\\", \\\"{x:1427,y:519,t:1526930111937};\\\", \\\"{x:1427,y:522,t:1526930111952};\\\", \\\"{x:1428,y:529,t:1526930111970};\\\", \\\"{x:1428,y:531,t:1526930111986};\\\", \\\"{x:1428,y:533,t:1526930112002};\\\", \\\"{x:1427,y:536,t:1526930112020};\\\", \\\"{x:1422,y:538,t:1526930112036};\\\", \\\"{x:1421,y:538,t:1526930112053};\\\", \\\"{x:1420,y:539,t:1526930112115};\\\", \\\"{x:1418,y:540,t:1526930112122};\\\", \\\"{x:1415,y:540,t:1526930112137};\\\", \\\"{x:1412,y:541,t:1526930112153};\\\", \\\"{x:1412,y:542,t:1526930112170};\\\", \\\"{x:1410,y:544,t:1526930112187};\\\", \\\"{x:1407,y:545,t:1526930112203};\\\", \\\"{x:1403,y:548,t:1526930112220};\\\", \\\"{x:1396,y:554,t:1526930112237};\\\", \\\"{x:1393,y:559,t:1526930112253};\\\", \\\"{x:1391,y:565,t:1526930112270};\\\", \\\"{x:1389,y:571,t:1526930112287};\\\", \\\"{x:1388,y:576,t:1526930112304};\\\", \\\"{x:1388,y:579,t:1526930112320};\\\", \\\"{x:1388,y:582,t:1526930112695};\\\", \\\"{x:1386,y:583,t:1526930112710};\\\", \\\"{x:1386,y:584,t:1526930112725};\\\", \\\"{x:1386,y:586,t:1526930112741};\\\", \\\"{x:1383,y:594,t:1526930112759};\\\", \\\"{x:1381,y:600,t:1526930112774};\\\", \\\"{x:1371,y:616,t:1526930112791};\\\", \\\"{x:1359,y:638,t:1526930112808};\\\", \\\"{x:1346,y:665,t:1526930112825};\\\", \\\"{x:1335,y:682,t:1526930112841};\\\", \\\"{x:1324,y:702,t:1526930112858};\\\", \\\"{x:1319,y:710,t:1526930112875};\\\", \\\"{x:1315,y:714,t:1526930113383};\\\", \\\"{x:1314,y:714,t:1526930113406};\\\", \\\"{x:1314,y:715,t:1526930113495};\\\", \\\"{x:1312,y:717,t:1526930113508};\\\", \\\"{x:1311,y:719,t:1526930113525};\\\", \\\"{x:1311,y:720,t:1526930113590};\\\", \\\"{x:1311,y:722,t:1526930113608};\\\", \\\"{x:1314,y:724,t:1526930113625};\\\", \\\"{x:1316,y:726,t:1526930113647};\\\", \\\"{x:1316,y:728,t:1526930113659};\\\", \\\"{x:1322,y:733,t:1526930113675};\\\", \\\"{x:1322,y:734,t:1526930113692};\\\", \\\"{x:1324,y:734,t:1526930113709};\\\", \\\"{x:1325,y:734,t:1526930113725};\\\", \\\"{x:1326,y:734,t:1526930114310};\\\", \\\"{x:1327,y:734,t:1526930114334};\\\", \\\"{x:1328,y:733,t:1526930114366};\\\", \\\"{x:1330,y:732,t:1526930114390};\\\", \\\"{x:1331,y:732,t:1526930114431};\\\", \\\"{x:1332,y:732,t:1526930114443};\\\", \\\"{x:1333,y:731,t:1526930114471};\\\", \\\"{x:1334,y:731,t:1526930114478};\\\", \\\"{x:1335,y:730,t:1526930114502};\\\", \\\"{x:1336,y:730,t:1526930114535};\\\", \\\"{x:1336,y:729,t:1526930114543};\\\", \\\"{x:1337,y:729,t:1526930114559};\\\", \\\"{x:1339,y:728,t:1526930114576};\\\", \\\"{x:1339,y:727,t:1526930116134};\\\", \\\"{x:1341,y:724,t:1526930116143};\\\", \\\"{x:1344,y:718,t:1526930116160};\\\", \\\"{x:1350,y:709,t:1526930116177};\\\", \\\"{x:1356,y:702,t:1526930116193};\\\", \\\"{x:1362,y:697,t:1526930116210};\\\", \\\"{x:1366,y:693,t:1526930116226};\\\", \\\"{x:1372,y:689,t:1526930116243};\\\", \\\"{x:1382,y:682,t:1526930116261};\\\", \\\"{x:1397,y:672,t:1526930116276};\\\", \\\"{x:1413,y:661,t:1526930116293};\\\", \\\"{x:1424,y:651,t:1526930116311};\\\", \\\"{x:1432,y:645,t:1526930116326};\\\", \\\"{x:1437,y:641,t:1526930116343};\\\", \\\"{x:1439,y:637,t:1526930116360};\\\", \\\"{x:1439,y:636,t:1526930116377};\\\", \\\"{x:1440,y:634,t:1526930116397};\\\", \\\"{x:1442,y:631,t:1526930116410};\\\", \\\"{x:1445,y:625,t:1526930116426};\\\", \\\"{x:1447,y:618,t:1526930116444};\\\", \\\"{x:1450,y:610,t:1526930116460};\\\", \\\"{x:1452,y:602,t:1526930116476};\\\", \\\"{x:1454,y:594,t:1526930116493};\\\", \\\"{x:1454,y:589,t:1526930116510};\\\", \\\"{x:1454,y:586,t:1526930116527};\\\", \\\"{x:1454,y:584,t:1526930116543};\\\", \\\"{x:1454,y:583,t:1526930116560};\\\", \\\"{x:1454,y:582,t:1526930116578};\\\", \\\"{x:1454,y:580,t:1526930116593};\\\", \\\"{x:1454,y:578,t:1526930116610};\\\", \\\"{x:1452,y:574,t:1526930116628};\\\", \\\"{x:1449,y:571,t:1526930116643};\\\", \\\"{x:1446,y:567,t:1526930116664};\\\", \\\"{x:1443,y:567,t:1526930116677};\\\", \\\"{x:1442,y:566,t:1526930116693};\\\", \\\"{x:1442,y:565,t:1526930116710};\\\", \\\"{x:1441,y:565,t:1526930116728};\\\", \\\"{x:1440,y:564,t:1526930116743};\\\", \\\"{x:1438,y:564,t:1526930116805};\\\", \\\"{x:1437,y:564,t:1526930116821};\\\", \\\"{x:1436,y:564,t:1526930116836};\\\", \\\"{x:1435,y:564,t:1526930116853};\\\", \\\"{x:1435,y:565,t:1526930116861};\\\", \\\"{x:1434,y:565,t:1526930116876};\\\", \\\"{x:1434,y:566,t:1526930117013};\\\", \\\"{x:1433,y:566,t:1526930117101};\\\", \\\"{x:1432,y:566,t:1526930117110};\\\", \\\"{x:1431,y:566,t:1526930117127};\\\", \\\"{x:1429,y:566,t:1526930117144};\\\", \\\"{x:1426,y:568,t:1526930117160};\\\", \\\"{x:1424,y:568,t:1526930117178};\\\", \\\"{x:1422,y:568,t:1526930117194};\\\", \\\"{x:1421,y:568,t:1526930117210};\\\", \\\"{x:1420,y:568,t:1526930117254};\\\", \\\"{x:1419,y:568,t:1526930117285};\\\", \\\"{x:1418,y:568,t:1526930117309};\\\", \\\"{x:1417,y:567,t:1526930117455};\\\", \\\"{x:1415,y:565,t:1526930117478};\\\", \\\"{x:1414,y:563,t:1526930117495};\\\", \\\"{x:1413,y:562,t:1526930117511};\\\", \\\"{x:1413,y:561,t:1526930117718};\\\", \\\"{x:1413,y:560,t:1526930117728};\\\", \\\"{x:1415,y:557,t:1526930117746};\\\", \\\"{x:1416,y:553,t:1526930117762};\\\", \\\"{x:1416,y:549,t:1526930117778};\\\", \\\"{x:1416,y:548,t:1526930117794};\\\", \\\"{x:1416,y:546,t:1526930117811};\\\", \\\"{x:1416,y:545,t:1526930117827};\\\", \\\"{x:1415,y:544,t:1526930117844};\\\", \\\"{x:1376,y:538,t:1526930117861};\\\", \\\"{x:1279,y:523,t:1526930117878};\\\", \\\"{x:1152,y:508,t:1526930117894};\\\", \\\"{x:1032,y:502,t:1526930117911};\\\", \\\"{x:931,y:498,t:1526930117928};\\\", \\\"{x:824,y:505,t:1526930117944};\\\", \\\"{x:743,y:507,t:1526930117961};\\\", \\\"{x:706,y:507,t:1526930117978};\\\", \\\"{x:698,y:507,t:1526930117994};\\\", \\\"{x:696,y:507,t:1526930118142};\\\", \\\"{x:690,y:507,t:1526930118149};\\\", \\\"{x:686,y:507,t:1526930118162};\\\", \\\"{x:677,y:508,t:1526930118177};\\\", \\\"{x:671,y:508,t:1526930118194};\\\", \\\"{x:667,y:508,t:1526930118211};\\\", \\\"{x:665,y:510,t:1526930118228};\\\", \\\"{x:664,y:510,t:1526930118245};\\\", \\\"{x:662,y:511,t:1526930118261};\\\", \\\"{x:661,y:512,t:1526930118278};\\\", \\\"{x:657,y:512,t:1526930118295};\\\", \\\"{x:655,y:514,t:1526930118311};\\\", \\\"{x:650,y:517,t:1526930118328};\\\", \\\"{x:648,y:519,t:1526930118346};\\\", \\\"{x:645,y:525,t:1526930118362};\\\", \\\"{x:642,y:529,t:1526930118379};\\\", \\\"{x:639,y:531,t:1526930118396};\\\", \\\"{x:638,y:532,t:1526930118421};\\\", \\\"{x:637,y:533,t:1526930118454};\\\", \\\"{x:635,y:534,t:1526930118478};\\\", \\\"{x:634,y:534,t:1526930118496};\\\", \\\"{x:633,y:535,t:1526930118518};\\\", \\\"{x:631,y:536,t:1526930118558};\\\", \\\"{x:630,y:536,t:1526930118581};\\\", \\\"{x:629,y:536,t:1526930118595};\\\", \\\"{x:628,y:538,t:1526930118612};\\\", \\\"{x:627,y:538,t:1526930118693};\\\", \\\"{x:627,y:539,t:1526930118757};\\\", \\\"{x:625,y:539,t:1526930118821};\\\", \\\"{x:624,y:539,t:1526930118845};\\\", \\\"{x:622,y:539,t:1526930118862};\\\", \\\"{x:620,y:541,t:1526930118879};\\\", \\\"{x:617,y:541,t:1526930118896};\\\", \\\"{x:615,y:541,t:1526930118913};\\\", \\\"{x:614,y:541,t:1526930118930};\\\", \\\"{x:613,y:541,t:1526930119006};\\\", \\\"{x:612,y:541,t:1526930119149};\\\", \\\"{x:612,y:541,t:1526930119278};\\\", \\\"{x:613,y:541,t:1526930119397};\\\", \\\"{x:615,y:541,t:1526930119412};\\\", \\\"{x:626,y:543,t:1526930119429};\\\", \\\"{x:643,y:548,t:1526930119446};\\\", \\\"{x:661,y:557,t:1526930119463};\\\", \\\"{x:687,y:565,t:1526930119480};\\\", \\\"{x:717,y:570,t:1526930119495};\\\", \\\"{x:742,y:571,t:1526930119513};\\\", \\\"{x:764,y:575,t:1526930119529};\\\", \\\"{x:803,y:582,t:1526930119545};\\\", \\\"{x:830,y:587,t:1526930119563};\\\", \\\"{x:864,y:594,t:1526930119580};\\\", \\\"{x:897,y:600,t:1526930119595};\\\", \\\"{x:947,y:604,t:1526930119613};\\\", \\\"{x:1031,y:613,t:1526930119629};\\\", \\\"{x:1060,y:616,t:1526930119647};\\\", \\\"{x:1090,y:617,t:1526930119662};\\\", \\\"{x:1114,y:617,t:1526930119680};\\\", \\\"{x:1133,y:616,t:1526930119697};\\\", \\\"{x:1145,y:613,t:1526930119714};\\\", \\\"{x:1162,y:610,t:1526930119729};\\\", \\\"{x:1173,y:609,t:1526930119747};\\\", \\\"{x:1184,y:604,t:1526930119764};\\\", \\\"{x:1194,y:600,t:1526930119780};\\\", \\\"{x:1203,y:599,t:1526930119796};\\\", \\\"{x:1226,y:595,t:1526930119814};\\\", \\\"{x:1246,y:589,t:1526930119830};\\\", \\\"{x:1265,y:585,t:1526930119847};\\\", \\\"{x:1282,y:584,t:1526930119864};\\\", \\\"{x:1294,y:583,t:1526930119881};\\\", \\\"{x:1306,y:581,t:1526930119897};\\\", \\\"{x:1316,y:580,t:1526930119914};\\\", \\\"{x:1329,y:578,t:1526930119931};\\\", \\\"{x:1339,y:575,t:1526930119948};\\\", \\\"{x:1356,y:572,t:1526930119964};\\\", \\\"{x:1373,y:571,t:1526930119981};\\\", \\\"{x:1386,y:570,t:1526930119997};\\\", \\\"{x:1389,y:569,t:1526930120015};\\\", \\\"{x:1391,y:569,t:1526930120079};\\\", \\\"{x:1392,y:568,t:1526930120087};\\\", \\\"{x:1396,y:567,t:1526930120098};\\\", \\\"{x:1399,y:566,t:1526930120115};\\\", \\\"{x:1400,y:565,t:1526930120382};\\\", \\\"{x:1401,y:564,t:1526930120399};\\\", \\\"{x:1403,y:563,t:1526930120416};\\\", \\\"{x:1410,y:563,t:1526930120433};\\\", \\\"{x:1413,y:562,t:1526930120449};\\\", \\\"{x:1419,y:560,t:1526930120466};\\\", \\\"{x:1421,y:559,t:1526930120483};\\\", \\\"{x:1424,y:559,t:1526930120499};\\\", \\\"{x:1423,y:559,t:1526930120798};\\\", \\\"{x:1422,y:559,t:1526930120806};\\\", \\\"{x:1421,y:559,t:1526930120830};\\\", \\\"{x:1421,y:560,t:1526930120854};\\\", \\\"{x:1420,y:560,t:1526930120870};\\\", \\\"{x:1419,y:560,t:1526930121263};\\\", \\\"{x:1418,y:560,t:1526930121286};\\\", \\\"{x:1416,y:560,t:1526930121302};\\\", \\\"{x:1413,y:560,t:1526930121319};\\\", \\\"{x:1412,y:560,t:1526930121358};\\\", \\\"{x:1411,y:560,t:1526930121373};\\\", \\\"{x:1410,y:560,t:1526930121385};\\\", \\\"{x:1407,y:560,t:1526930121406};\\\", \\\"{x:1402,y:560,t:1526930121419};\\\", \\\"{x:1398,y:557,t:1526930121435};\\\", \\\"{x:1394,y:555,t:1526930121451};\\\", \\\"{x:1390,y:553,t:1526930121468};\\\", \\\"{x:1386,y:551,t:1526930121485};\\\", \\\"{x:1384,y:550,t:1526930121508};\\\", \\\"{x:1383,y:549,t:1526930121525};\\\", \\\"{x:1381,y:548,t:1526930121536};\\\", \\\"{x:1379,y:547,t:1526930121552};\\\", \\\"{x:1375,y:546,t:1526930121569};\\\", \\\"{x:1374,y:545,t:1526930121586};\\\", \\\"{x:1374,y:544,t:1526930121695};\\\", \\\"{x:1375,y:543,t:1526930121704};\\\", \\\"{x:1378,y:542,t:1526930121720};\\\", \\\"{x:1381,y:539,t:1526930121738};\\\", \\\"{x:1384,y:538,t:1526930121753};\\\", \\\"{x:1386,y:537,t:1526930121770};\\\", \\\"{x:1391,y:537,t:1526930121787};\\\", \\\"{x:1395,y:534,t:1526930121803};\\\", \\\"{x:1400,y:534,t:1526930121821};\\\", \\\"{x:1411,y:533,t:1526930121838};\\\", \\\"{x:1420,y:532,t:1526930121853};\\\", \\\"{x:1429,y:530,t:1526930121870};\\\", \\\"{x:1435,y:529,t:1526930121887};\\\", \\\"{x:1438,y:529,t:1526930121904};\\\", \\\"{x:1442,y:529,t:1526930121921};\\\", \\\"{x:1446,y:529,t:1526930121938};\\\", \\\"{x:1449,y:529,t:1526930121954};\\\", \\\"{x:1454,y:529,t:1526930121971};\\\", \\\"{x:1460,y:529,t:1526930121987};\\\", \\\"{x:1463,y:529,t:1526930122004};\\\", \\\"{x:1464,y:529,t:1526930122022};\\\", \\\"{x:1464,y:530,t:1526930122070};\\\", \\\"{x:1460,y:531,t:1526930122088};\\\", \\\"{x:1454,y:533,t:1526930122105};\\\", \\\"{x:1442,y:534,t:1526930122121};\\\", \\\"{x:1427,y:534,t:1526930122138};\\\", \\\"{x:1419,y:534,t:1526930122155};\\\", \\\"{x:1416,y:535,t:1526930122171};\\\", \\\"{x:1416,y:537,t:1526930122188};\\\", \\\"{x:1414,y:538,t:1526930122205};\\\", \\\"{x:1412,y:539,t:1526930122221};\\\", \\\"{x:1409,y:541,t:1526930122238};\\\", \\\"{x:1406,y:544,t:1526930122256};\\\", \\\"{x:1400,y:544,t:1526930122272};\\\", \\\"{x:1388,y:546,t:1526930122288};\\\", \\\"{x:1375,y:547,t:1526930122305};\\\", \\\"{x:1361,y:549,t:1526930122322};\\\", \\\"{x:1343,y:551,t:1526930122339};\\\", \\\"{x:1327,y:551,t:1526930122356};\\\", \\\"{x:1321,y:551,t:1526930122373};\\\", \\\"{x:1316,y:551,t:1526930122390};\\\", \\\"{x:1313,y:552,t:1526930122405};\\\", \\\"{x:1311,y:553,t:1526930122423};\\\", \\\"{x:1309,y:553,t:1526930122439};\\\", \\\"{x:1308,y:553,t:1526930122462};\\\", \\\"{x:1307,y:554,t:1526930122526};\\\", \\\"{x:1306,y:554,t:1526930122550};\\\", \\\"{x:1304,y:556,t:1526930122566};\\\", \\\"{x:1302,y:557,t:1526930122574};\\\", \\\"{x:1301,y:557,t:1526930122589};\\\", \\\"{x:1294,y:558,t:1526930122606};\\\", \\\"{x:1291,y:558,t:1526930122623};\\\", \\\"{x:1288,y:558,t:1526930122646};\\\", \\\"{x:1287,y:560,t:1526930122678};\\\", \\\"{x:1286,y:560,t:1526930122695};\\\", \\\"{x:1284,y:560,t:1526930122723};\\\", \\\"{x:1283,y:560,t:1526930122740};\\\", \\\"{x:1281,y:560,t:1526930122757};\\\", \\\"{x:1280,y:560,t:1526930122773};\\\", \\\"{x:1278,y:560,t:1526930122797};\\\", \\\"{x:1277,y:560,t:1526930122854};\\\", \\\"{x:1275,y:560,t:1526930122919};\\\", \\\"{x:1274,y:560,t:1526930122942};\\\", \\\"{x:1272,y:560,t:1526930122975};\\\", \\\"{x:1271,y:560,t:1526930123022};\\\", \\\"{x:1271,y:562,t:1526930123399};\\\", \\\"{x:1271,y:563,t:1526930123409};\\\", \\\"{x:1271,y:564,t:1526930123426};\\\", \\\"{x:1271,y:565,t:1526930123442};\\\", \\\"{x:1271,y:566,t:1526930123583};\\\", \\\"{x:1273,y:566,t:1526930123646};\\\", \\\"{x:1274,y:566,t:1526930123670};\\\", \\\"{x:1276,y:566,t:1526930123686};\\\", \\\"{x:1277,y:566,t:1526930123767};\\\", \\\"{x:1278,y:566,t:1526930123854};\\\", \\\"{x:1279,y:566,t:1526930123870};\\\", \\\"{x:1280,y:566,t:1526930124022};\\\", \\\"{x:1281,y:565,t:1526930124054};\\\", \\\"{x:1282,y:565,t:1526930124062};\\\", \\\"{x:1278,y:565,t:1526930124469};\\\", \\\"{x:1274,y:565,t:1526930124479};\\\", \\\"{x:1259,y:565,t:1526930124495};\\\", \\\"{x:1241,y:565,t:1526930124512};\\\", \\\"{x:1224,y:565,t:1526930124529};\\\", \\\"{x:1202,y:565,t:1526930124545};\\\", \\\"{x:1192,y:565,t:1526930124562};\\\", \\\"{x:1179,y:565,t:1526930124578};\\\", \\\"{x:1167,y:567,t:1526930124596};\\\", \\\"{x:1164,y:568,t:1526930124613};\\\", \\\"{x:1165,y:568,t:1526930124790};\\\", \\\"{x:1166,y:568,t:1526930124798};\\\", \\\"{x:1169,y:568,t:1526930124814};\\\", \\\"{x:1171,y:567,t:1526930124830};\\\", \\\"{x:1174,y:566,t:1526930124846};\\\", \\\"{x:1176,y:565,t:1526930124863};\\\", \\\"{x:1179,y:564,t:1526930124880};\\\", \\\"{x:1183,y:563,t:1526930124898};\\\", \\\"{x:1186,y:562,t:1526930124913};\\\", \\\"{x:1190,y:561,t:1526930124930};\\\", \\\"{x:1196,y:560,t:1526930124947};\\\", \\\"{x:1199,y:559,t:1526930124963};\\\", \\\"{x:1200,y:559,t:1526930124980};\\\", \\\"{x:1202,y:559,t:1526930124997};\\\", \\\"{x:1204,y:557,t:1526930125014};\\\", \\\"{x:1207,y:557,t:1526930125030};\\\", \\\"{x:1219,y:557,t:1526930125048};\\\", \\\"{x:1230,y:557,t:1526930125064};\\\", \\\"{x:1245,y:557,t:1526930125080};\\\", \\\"{x:1258,y:559,t:1526930125097};\\\", \\\"{x:1263,y:561,t:1526930125114};\\\", \\\"{x:1266,y:563,t:1526930125131};\\\", \\\"{x:1267,y:563,t:1526930125147};\\\", \\\"{x:1268,y:563,t:1526930125182};\\\", \\\"{x:1269,y:563,t:1526930125198};\\\", \\\"{x:1275,y:563,t:1526930125215};\\\", \\\"{x:1276,y:563,t:1526930125231};\\\", \\\"{x:1277,y:563,t:1526930125248};\\\", \\\"{x:1278,y:563,t:1526930125264};\\\", \\\"{x:1280,y:562,t:1526930125294};\\\", \\\"{x:1281,y:562,t:1526930125309};\\\", \\\"{x:1284,y:562,t:1526930125318};\\\", \\\"{x:1287,y:562,t:1526930125332};\\\", \\\"{x:1296,y:562,t:1526930125348};\\\", \\\"{x:1298,y:562,t:1526930125365};\\\", \\\"{x:1304,y:562,t:1526930125382};\\\", \\\"{x:1306,y:561,t:1526930125678};\\\", \\\"{x:1309,y:561,t:1526930125686};\\\", \\\"{x:1312,y:561,t:1526930125699};\\\", \\\"{x:1324,y:561,t:1526930125717};\\\", \\\"{x:1335,y:561,t:1526930125734};\\\", \\\"{x:1353,y:561,t:1526930125749};\\\", \\\"{x:1376,y:561,t:1526930125765};\\\", \\\"{x:1389,y:560,t:1526930125784};\\\", \\\"{x:1393,y:560,t:1526930125799};\\\", \\\"{x:1395,y:560,t:1526930125816};\\\", \\\"{x:1397,y:560,t:1526930125833};\\\", \\\"{x:1399,y:560,t:1526930125850};\\\", \\\"{x:1400,y:560,t:1526930125870};\\\", \\\"{x:1401,y:559,t:1526930125883};\\\", \\\"{x:1403,y:559,t:1526930125901};\\\", \\\"{x:1403,y:558,t:1526930125917};\\\", \\\"{x:1404,y:558,t:1526930125950};\\\", \\\"{x:1405,y:558,t:1526930126014};\\\", \\\"{x:1406,y:558,t:1526930126022};\\\", \\\"{x:1407,y:558,t:1526930126046};\\\", \\\"{x:1409,y:558,t:1526930126054};\\\", \\\"{x:1412,y:558,t:1526930126067};\\\", \\\"{x:1419,y:558,t:1526930126085};\\\", \\\"{x:1429,y:563,t:1526930126101};\\\", \\\"{x:1438,y:566,t:1526930126117};\\\", \\\"{x:1444,y:569,t:1526930126134};\\\", \\\"{x:1445,y:570,t:1526930126151};\\\", \\\"{x:1446,y:571,t:1526930126168};\\\", \\\"{x:1449,y:575,t:1526930126184};\\\", \\\"{x:1452,y:580,t:1526930126202};\\\", \\\"{x:1454,y:586,t:1526930126217};\\\", \\\"{x:1456,y:590,t:1526930126234};\\\", \\\"{x:1457,y:593,t:1526930126251};\\\", \\\"{x:1458,y:594,t:1526930126286};\\\", \\\"{x:1458,y:596,t:1526930126301};\\\", \\\"{x:1459,y:601,t:1526930126318};\\\", \\\"{x:1462,y:606,t:1526930126335};\\\", \\\"{x:1463,y:610,t:1526930126351};\\\", \\\"{x:1463,y:612,t:1526930126368};\\\", \\\"{x:1463,y:613,t:1526930126430};\\\", \\\"{x:1463,y:615,t:1526930126478};\\\", \\\"{x:1463,y:616,t:1526930126511};\\\", \\\"{x:1463,y:617,t:1526930126526};\\\", \\\"{x:1461,y:617,t:1526930126535};\\\", \\\"{x:1459,y:619,t:1526930126552};\\\", \\\"{x:1458,y:620,t:1526930126570};\\\", \\\"{x:1455,y:622,t:1526930126586};\\\", \\\"{x:1455,y:623,t:1526930126602};\\\", \\\"{x:1453,y:623,t:1526930126620};\\\", \\\"{x:1452,y:623,t:1526930126635};\\\", \\\"{x:1450,y:623,t:1526930126653};\\\", \\\"{x:1448,y:624,t:1526930126670};\\\", \\\"{x:1446,y:625,t:1526930126686};\\\", \\\"{x:1445,y:626,t:1526930126719};\\\", \\\"{x:1443,y:627,t:1526930126737};\\\", \\\"{x:1443,y:628,t:1526930126752};\\\", \\\"{x:1443,y:629,t:1526930126781};\\\", \\\"{x:1441,y:630,t:1526930126927};\\\", \\\"{x:1440,y:630,t:1526930126936};\\\", \\\"{x:1439,y:632,t:1526930126954};\\\", \\\"{x:1436,y:633,t:1526930126971};\\\", \\\"{x:1435,y:633,t:1526930126987};\\\", \\\"{x:1432,y:633,t:1526930127003};\\\", \\\"{x:1428,y:635,t:1526930127020};\\\", \\\"{x:1422,y:637,t:1526930127037};\\\", \\\"{x:1414,y:641,t:1526930127053};\\\", \\\"{x:1401,y:648,t:1526930127070};\\\", \\\"{x:1393,y:654,t:1526930127088};\\\", \\\"{x:1390,y:658,t:1526930127105};\\\", \\\"{x:1378,y:667,t:1526930127121};\\\", \\\"{x:1371,y:673,t:1526930127137};\\\", \\\"{x:1366,y:680,t:1526930127154};\\\", \\\"{x:1359,y:686,t:1526930127170};\\\", \\\"{x:1357,y:690,t:1526930127188};\\\", \\\"{x:1356,y:693,t:1526930127204};\\\", \\\"{x:1355,y:698,t:1526930127221};\\\", \\\"{x:1355,y:699,t:1526930127238};\\\", \\\"{x:1354,y:701,t:1526930127254};\\\", \\\"{x:1353,y:703,t:1526930127272};\\\", \\\"{x:1351,y:704,t:1526930127288};\\\", \\\"{x:1351,y:706,t:1526930127304};\\\", \\\"{x:1350,y:708,t:1526930127321};\\\", \\\"{x:1350,y:709,t:1526930127775};\\\", \\\"{x:1341,y:709,t:1526930127789};\\\", \\\"{x:1318,y:703,t:1526930127806};\\\", \\\"{x:1285,y:690,t:1526930127823};\\\", \\\"{x:1241,y:680,t:1526930127839};\\\", \\\"{x:1172,y:671,t:1526930127856};\\\", \\\"{x:1072,y:660,t:1526930127872};\\\", \\\"{x:962,y:652,t:1526930127889};\\\", \\\"{x:862,y:650,t:1526930127905};\\\", \\\"{x:760,y:650,t:1526930127923};\\\", \\\"{x:677,y:656,t:1526930127940};\\\", \\\"{x:627,y:656,t:1526930127956};\\\", \\\"{x:606,y:659,t:1526930127973};\\\", \\\"{x:594,y:664,t:1526930127989};\\\", \\\"{x:588,y:668,t:1526930128006};\\\", \\\"{x:586,y:673,t:1526930128023};\\\", \\\"{x:580,y:680,t:1526930128040};\\\", \\\"{x:578,y:683,t:1526930128057};\\\", \\\"{x:578,y:684,t:1526930128077};\\\", \\\"{x:578,y:686,t:1526930128101};\\\", \\\"{x:578,y:687,t:1526930128108};\\\", \\\"{x:578,y:689,t:1526930128123};\\\", \\\"{x:578,y:693,t:1526930128139};\\\", \\\"{x:578,y:695,t:1526930128157};\\\", \\\"{x:578,y:696,t:1526930128173};\\\", \\\"{x:576,y:697,t:1526930128190};\\\", \\\"{x:572,y:701,t:1526930128207};\\\", \\\"{x:568,y:706,t:1526930128224};\\\", \\\"{x:563,y:712,t:1526930128241};\\\", \\\"{x:560,y:715,t:1526930128257};\\\", \\\"{x:556,y:718,t:1526930128274};\\\", \\\"{x:555,y:719,t:1526930128291};\\\", \\\"{x:554,y:720,t:1526930128308};\\\", \\\"{x:553,y:721,t:1526930128324};\\\", \\\"{x:551,y:725,t:1526930128341};\\\", \\\"{x:550,y:726,t:1526930128350};\\\", \\\"{x:547,y:729,t:1526930128365};\\\", \\\"{x:545,y:731,t:1526930128383};\\\", \\\"{x:542,y:733,t:1526930128400};\\\", \\\"{x:540,y:733,t:1526930128416};\\\", \\\"{x:539,y:735,t:1526930128445};\\\", \\\"{x:538,y:735,t:1526930128453};\\\", \\\"{x:536,y:737,t:1526930128483};\\\", \\\"{x:536,y:737,t:1526930128578};\\\", \\\"{x:537,y:737,t:1526930128692};\\\", \\\"{x:545,y:737,t:1526930128703};\\\", \\\"{x:554,y:737,t:1526930128720};\\\", \\\"{x:576,y:737,t:1526930128737};\\\", \\\"{x:598,y:737,t:1526930128753};\\\", \\\"{x:626,y:737,t:1526930128770};\\\", \\\"{x:647,y:737,t:1526930128786};\\\", \\\"{x:667,y:737,t:1526930128804};\\\", \\\"{x:691,y:733,t:1526930128820};\\\", \\\"{x:720,y:733,t:1526930128837};\\\", \\\"{x:730,y:730,t:1526930128854};\\\", \\\"{x:752,y:729,t:1526930128870};\\\", \\\"{x:780,y:724,t:1526930128887};\\\", \\\"{x:797,y:717,t:1526930128904};\\\", \\\"{x:814,y:717,t:1526930128920};\\\", \\\"{x:831,y:712,t:1526930128937};\\\", \\\"{x:849,y:706,t:1526930128954};\\\", \\\"{x:861,y:700,t:1526930128971};\\\", \\\"{x:872,y:692,t:1526930128987};\\\", \\\"{x:877,y:689,t:1526930129004};\\\", \\\"{x:883,y:680,t:1526930129020};\\\", \\\"{x:886,y:673,t:1526930129037};\\\", \\\"{x:888,y:668,t:1526930129054};\\\", \\\"{x:889,y:662,t:1526930129070};\\\", \\\"{x:890,y:660,t:1526930129086};\\\", \\\"{x:891,y:658,t:1526930129104};\\\", \\\"{x:891,y:657,t:1526930129189};\\\", \\\"{x:891,y:654,t:1526930129204};\\\", \\\"{x:891,y:652,t:1526930129262};\\\", \\\"{x:891,y:650,t:1526930129293};\\\", \\\"{x:891,y:649,t:1526930129350};\\\", \\\"{x:888,y:649,t:1526930129374};\\\", \\\"{x:886,y:649,t:1526930129390};\\\", \\\"{x:884,y:649,t:1526930129404};\\\", \\\"{x:878,y:649,t:1526930129421};\\\", \\\"{x:877,y:651,t:1526930129437};\\\", \\\"{x:873,y:651,t:1526930129454};\\\", \\\"{x:871,y:652,t:1526930129471};\\\", \\\"{x:869,y:653,t:1526930129488};\\\", \\\"{x:868,y:653,t:1526930129504};\\\", \\\"{x:867,y:654,t:1526930129521};\\\", \\\"{x:865,y:654,t:1526930129558};\\\", \\\"{x:862,y:655,t:1526930129587};\\\", \\\"{x:859,y:655,t:1526930129603};\\\", \\\"{x:853,y:656,t:1526930129621};\\\", \\\"{x:845,y:657,t:1526930129637};\\\", \\\"{x:841,y:657,t:1526930129654};\\\", \\\"{x:838,y:659,t:1526930129671};\\\", \\\"{x:837,y:659,t:1526930129687};\\\", \\\"{x:836,y:659,t:1526930129789};\\\", \\\"{x:834,y:659,t:1526930129813};\\\", \\\"{x:831,y:661,t:1526930129821};\\\", \\\"{x:824,y:662,t:1526930129838};\\\", \\\"{x:819,y:662,t:1526930129854};\\\", \\\"{x:810,y:663,t:1526930129871};\\\" ] }, { \\\"rt\\\": 35830, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 13, \\\"time_elapsed\\\": 517800, \\\"internal_node_id\\\": \\\"0.0-6.0-3.0\\\", \\\"subject\\\": \\\"GQ35Z\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"charlie\\\", \\\"condition\\\": \\\"111\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"starttime+before+endtime+during\\\", \\\"q\\\": 9, \\\"clicks\\\": 1, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XInside-YFull\\\", \\\"correct\\\": 1, \\\"orth_correct\\\": 1, \\\"answer\\\": [ \\\"I\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-4-F -B -09 AM-E -F -F -B \\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:791,y:665,t:1526930130127};\\\", \\\"{x:789,y:668,t:1526930130551};\\\", \\\"{x:788,y:671,t:1526930130557};\\\", \\\"{x:787,y:673,t:1526930130572};\\\", \\\"{x:786,y:673,t:1526930130588};\\\", \\\"{x:786,y:674,t:1526930130604};\\\", \\\"{x:783,y:675,t:1526930130677};\\\", \\\"{x:783,y:676,t:1526930130701};\\\", \\\"{x:782,y:676,t:1526930130766};\\\", \\\"{x:782,y:676,t:1526930130774};\\\", \\\"{x:714,y:664,t:1526930131089};\\\", \\\"{x:714,y:664,t:1526930131221};\\\", \\\"{x:713,y:663,t:1526930131446};\\\", \\\"{x:713,y:662,t:1526930131461};\\\", \\\"{x:713,y:661,t:1526930131473};\\\", \\\"{x:714,y:661,t:1526930134238};\\\", \\\"{x:715,y:661,t:1526930134318};\\\", \\\"{x:716,y:661,t:1526930134958};\\\", \\\"{x:718,y:662,t:1526930135053};\\\", \\\"{x:722,y:663,t:1526930135069};\\\", \\\"{x:725,y:663,t:1526930135077};\\\", \\\"{x:730,y:664,t:1526930135092};\\\", \\\"{x:740,y:668,t:1526930135109};\\\", \\\"{x:756,y:671,t:1526930135125};\\\", \\\"{x:762,y:671,t:1526930135142};\\\", \\\"{x:770,y:675,t:1526930135159};\\\", \\\"{x:783,y:676,t:1526930135175};\\\", \\\"{x:795,y:680,t:1526930135193};\\\", \\\"{x:803,y:686,t:1526930135209};\\\", \\\"{x:814,y:692,t:1526930135226};\\\", \\\"{x:832,y:696,t:1526930135242};\\\", \\\"{x:844,y:698,t:1526930135259};\\\", \\\"{x:852,y:698,t:1526930135276};\\\", \\\"{x:863,y:698,t:1526930135293};\\\", \\\"{x:870,y:699,t:1526930135308};\\\", \\\"{x:877,y:700,t:1526930135326};\\\", \\\"{x:883,y:700,t:1526930135342};\\\", \\\"{x:893,y:701,t:1526930135358};\\\", \\\"{x:907,y:705,t:1526930135376};\\\", \\\"{x:920,y:710,t:1526930135392};\\\", \\\"{x:934,y:715,t:1526930135408};\\\", \\\"{x:942,y:717,t:1526930135426};\\\", \\\"{x:958,y:722,t:1526930135442};\\\", \\\"{x:971,y:726,t:1526930135458};\\\", \\\"{x:984,y:730,t:1526930135476};\\\", \\\"{x:994,y:732,t:1526930135493};\\\", \\\"{x:1004,y:736,t:1526930135509};\\\", \\\"{x:1025,y:742,t:1526930135525};\\\", \\\"{x:1037,y:745,t:1526930135542};\\\", \\\"{x:1049,y:746,t:1526930135559};\\\", \\\"{x:1060,y:749,t:1526930135576};\\\", \\\"{x:1072,y:751,t:1526930135592};\\\", \\\"{x:1078,y:751,t:1526930135608};\\\", \\\"{x:1079,y:751,t:1526930135654};\\\", \\\"{x:1080,y:751,t:1526930136022};\\\", \\\"{x:1081,y:751,t:1526930136030};\\\", \\\"{x:1083,y:751,t:1526930136046};\\\", \\\"{x:1085,y:751,t:1526930136059};\\\", \\\"{x:1092,y:751,t:1526930136077};\\\", \\\"{x:1101,y:751,t:1526930136093};\\\", \\\"{x:1107,y:750,t:1526930136110};\\\", \\\"{x:1111,y:750,t:1526930136126};\\\", \\\"{x:1112,y:750,t:1526930136143};\\\", \\\"{x:1113,y:750,t:1526930136160};\\\", \\\"{x:1114,y:750,t:1526930136182};\\\", \\\"{x:1117,y:749,t:1526930136206};\\\", \\\"{x:1118,y:748,t:1526930136222};\\\", \\\"{x:1120,y:748,t:1526930136237};\\\", \\\"{x:1120,y:747,t:1526930136302};\\\", \\\"{x:1121,y:747,t:1526930136422};\\\", \\\"{x:1121,y:746,t:1526930136429};\\\", \\\"{x:1119,y:743,t:1526930136443};\\\", \\\"{x:1116,y:740,t:1526930136460};\\\", \\\"{x:1112,y:737,t:1526930136476};\\\", \\\"{x:1110,y:735,t:1526930136493};\\\", \\\"{x:1106,y:732,t:1526930136510};\\\", \\\"{x:1106,y:731,t:1526930136527};\\\", \\\"{x:1105,y:730,t:1526930136549};\\\", \\\"{x:1102,y:729,t:1526930136565};\\\", \\\"{x:1101,y:728,t:1526930136577};\\\", \\\"{x:1100,y:727,t:1526930136594};\\\", \\\"{x:1099,y:724,t:1526930136609};\\\", \\\"{x:1097,y:722,t:1526930136627};\\\", \\\"{x:1095,y:721,t:1526930136643};\\\", \\\"{x:1094,y:720,t:1526930136660};\\\", \\\"{x:1093,y:720,t:1526930136677};\\\", \\\"{x:1091,y:717,t:1526930136694};\\\", \\\"{x:1088,y:714,t:1526930136709};\\\", \\\"{x:1082,y:710,t:1526930136727};\\\", \\\"{x:1074,y:704,t:1526930136744};\\\", \\\"{x:1063,y:696,t:1526930136760};\\\", \\\"{x:1046,y:686,t:1526930136778};\\\", \\\"{x:1027,y:674,t:1526930136794};\\\", \\\"{x:998,y:664,t:1526930136809};\\\", \\\"{x:976,y:656,t:1526930136827};\\\", \\\"{x:952,y:652,t:1526930136844};\\\", \\\"{x:939,y:651,t:1526930136859};\\\", \\\"{x:929,y:651,t:1526930136876};\\\", \\\"{x:917,y:651,t:1526930136893};\\\", \\\"{x:908,y:651,t:1526930136909};\\\", \\\"{x:898,y:649,t:1526930136926};\\\", \\\"{x:885,y:639,t:1526930136943};\\\", \\\"{x:868,y:628,t:1526930136962};\\\", \\\"{x:856,y:613,t:1526930136976};\\\", \\\"{x:842,y:598,t:1526930136993};\\\", \\\"{x:826,y:579,t:1526930137027};\\\", \\\"{x:821,y:573,t:1526930137044};\\\", \\\"{x:818,y:568,t:1526930137060};\\\", \\\"{x:814,y:566,t:1526930137077};\\\", \\\"{x:811,y:566,t:1526930137100};\\\", \\\"{x:806,y:566,t:1526930137110};\\\", \\\"{x:796,y:564,t:1526930137127};\\\", \\\"{x:778,y:561,t:1526930137143};\\\", \\\"{x:758,y:555,t:1526930137162};\\\", \\\"{x:736,y:550,t:1526930137177};\\\", \\\"{x:709,y:544,t:1526930137194};\\\", \\\"{x:691,y:539,t:1526930137210};\\\", \\\"{x:675,y:533,t:1526930137227};\\\", \\\"{x:659,y:527,t:1526930137244};\\\", \\\"{x:645,y:522,t:1526930137261};\\\", \\\"{x:635,y:518,t:1526930137277};\\\", \\\"{x:633,y:518,t:1526930137294};\\\", \\\"{x:633,y:517,t:1526930137342};\\\", \\\"{x:635,y:516,t:1526930137360};\\\", \\\"{x:640,y:516,t:1526930137377};\\\", \\\"{x:647,y:517,t:1526930137394};\\\", \\\"{x:677,y:529,t:1526930137411};\\\", \\\"{x:704,y:545,t:1526930137427};\\\", \\\"{x:739,y:555,t:1526930137445};\\\", \\\"{x:793,y:575,t:1526930137460};\\\", \\\"{x:885,y:600,t:1526930137477};\\\", \\\"{x:944,y:621,t:1526930137494};\\\", \\\"{x:1014,y:640,t:1526930137511};\\\", \\\"{x:1068,y:660,t:1526930137527};\\\", \\\"{x:1124,y:678,t:1526930137544};\\\", \\\"{x:1165,y:690,t:1526930137560};\\\", \\\"{x:1191,y:698,t:1526930137578};\\\", \\\"{x:1220,y:705,t:1526930137594};\\\", \\\"{x:1244,y:713,t:1526930137610};\\\", \\\"{x:1261,y:720,t:1526930137627};\\\", \\\"{x:1276,y:724,t:1526930137644};\\\", \\\"{x:1287,y:726,t:1526930137660};\\\", \\\"{x:1297,y:729,t:1526930137678};\\\", \\\"{x:1305,y:730,t:1526930137695};\\\", \\\"{x:1312,y:731,t:1526930137711};\\\", \\\"{x:1315,y:733,t:1526930137728};\\\", \\\"{x:1317,y:733,t:1526930137766};\\\", \\\"{x:1318,y:734,t:1526930137777};\\\", \\\"{x:1321,y:736,t:1526930137794};\\\", \\\"{x:1324,y:738,t:1526930137812};\\\", \\\"{x:1326,y:740,t:1526930137827};\\\", \\\"{x:1328,y:742,t:1526930137845};\\\", \\\"{x:1330,y:746,t:1526930137861};\\\", \\\"{x:1331,y:747,t:1526930137877};\\\", \\\"{x:1331,y:749,t:1526930137894};\\\", \\\"{x:1331,y:751,t:1526930137911};\\\", \\\"{x:1330,y:754,t:1526930137928};\\\", \\\"{x:1325,y:758,t:1526930137944};\\\", \\\"{x:1320,y:761,t:1526930137961};\\\", \\\"{x:1314,y:765,t:1526930137978};\\\", \\\"{x:1310,y:770,t:1526930137994};\\\", \\\"{x:1304,y:775,t:1526930138011};\\\", \\\"{x:1301,y:778,t:1526930138027};\\\", \\\"{x:1297,y:780,t:1526930138044};\\\", \\\"{x:1287,y:785,t:1526930138061};\\\", \\\"{x:1283,y:787,t:1526930138078};\\\", \\\"{x:1279,y:789,t:1526930138094};\\\", \\\"{x:1278,y:790,t:1526930138111};\\\", \\\"{x:1274,y:790,t:1526930138128};\\\", \\\"{x:1270,y:792,t:1526930138144};\\\", \\\"{x:1269,y:792,t:1526930138161};\\\", \\\"{x:1268,y:792,t:1526930138178};\\\", \\\"{x:1265,y:794,t:1526930138195};\\\", \\\"{x:1263,y:795,t:1526930138212};\\\", \\\"{x:1262,y:797,t:1526930138229};\\\", \\\"{x:1258,y:797,t:1526930138245};\\\", \\\"{x:1252,y:797,t:1526930138262};\\\", \\\"{x:1248,y:797,t:1526930138278};\\\", \\\"{x:1244,y:797,t:1526930138295};\\\", \\\"{x:1239,y:799,t:1526930138311};\\\", \\\"{x:1236,y:798,t:1526930138334};\\\", \\\"{x:1234,y:798,t:1526930138345};\\\", \\\"{x:1228,y:798,t:1526930138361};\\\", \\\"{x:1206,y:790,t:1526930138388};\\\", \\\"{x:1199,y:789,t:1526930138397};\\\", \\\"{x:1187,y:783,t:1526930138435};\\\", \\\"{x:1186,y:782,t:1526930138444};\\\", \\\"{x:1185,y:782,t:1526930138460};\\\", \\\"{x:1184,y:781,t:1526930138492};\\\", \\\"{x:1183,y:780,t:1526930138501};\\\", \\\"{x:1182,y:778,t:1526930138516};\\\", \\\"{x:1181,y:777,t:1526930138533};\\\", \\\"{x:1181,y:776,t:1526930138781};\\\", \\\"{x:1181,y:775,t:1526930138838};\\\", \\\"{x:1181,y:774,t:1526930139022};\\\", \\\"{x:1181,y:773,t:1526930139189};\\\", \\\"{x:1181,y:772,t:1526930139302};\\\", \\\"{x:1181,y:771,t:1526930139374};\\\", \\\"{x:1183,y:769,t:1526930139430};\\\", \\\"{x:1184,y:769,t:1526930139446};\\\", \\\"{x:1185,y:768,t:1526930139983};\\\", \\\"{x:1186,y:768,t:1526930139997};\\\", \\\"{x:1193,y:764,t:1526930140013};\\\", \\\"{x:1200,y:759,t:1526930140030};\\\", \\\"{x:1207,y:751,t:1526930140046};\\\", \\\"{x:1218,y:741,t:1526930140064};\\\", \\\"{x:1231,y:729,t:1526930140081};\\\", \\\"{x:1239,y:724,t:1526930140097};\\\", \\\"{x:1247,y:717,t:1526930140114};\\\", \\\"{x:1257,y:708,t:1526930140131};\\\", \\\"{x:1267,y:697,t:1526930140147};\\\", \\\"{x:1277,y:687,t:1526930140164};\\\", \\\"{x:1285,y:680,t:1526930140181};\\\", \\\"{x:1290,y:673,t:1526930140197};\\\", \\\"{x:1299,y:651,t:1526930140213};\\\", \\\"{x:1308,y:638,t:1526930140231};\\\", \\\"{x:1314,y:621,t:1526930140247};\\\", \\\"{x:1318,y:614,t:1526930140264};\\\", \\\"{x:1319,y:605,t:1526930140281};\\\", \\\"{x:1319,y:595,t:1526930140297};\\\", \\\"{x:1319,y:590,t:1526930140314};\\\", \\\"{x:1319,y:585,t:1526930140331};\\\", \\\"{x:1319,y:583,t:1526930140347};\\\", \\\"{x:1318,y:582,t:1526930140364};\\\", \\\"{x:1318,y:581,t:1526930140486};\\\", \\\"{x:1316,y:580,t:1526930140498};\\\", \\\"{x:1314,y:579,t:1526930140513};\\\", \\\"{x:1310,y:579,t:1526930140531};\\\", \\\"{x:1308,y:579,t:1526930140558};\\\", \\\"{x:1307,y:577,t:1526930140630};\\\", \\\"{x:1306,y:576,t:1526930140648};\\\", \\\"{x:1304,y:574,t:1526930140663};\\\", \\\"{x:1301,y:572,t:1526930140680};\\\", \\\"{x:1298,y:571,t:1526930140698};\\\", \\\"{x:1296,y:570,t:1526930140714};\\\", \\\"{x:1294,y:570,t:1526930140750};\\\", \\\"{x:1293,y:569,t:1526930140766};\\\", \\\"{x:1293,y:568,t:1526930140781};\\\", \\\"{x:1292,y:567,t:1526930140798};\\\", \\\"{x:1292,y:571,t:1526930141326};\\\", \\\"{x:1295,y:575,t:1526930141334};\\\", \\\"{x:1296,y:577,t:1526930141348};\\\", \\\"{x:1303,y:585,t:1526930141365};\\\", \\\"{x:1313,y:595,t:1526930141382};\\\", \\\"{x:1316,y:598,t:1526930141397};\\\", \\\"{x:1318,y:599,t:1526930141415};\\\", \\\"{x:1320,y:602,t:1526930141454};\\\", \\\"{x:1321,y:605,t:1526930141478};\\\", \\\"{x:1323,y:608,t:1526930141493};\\\", \\\"{x:1323,y:609,t:1526930141502};\\\", \\\"{x:1323,y:611,t:1526930141515};\\\", \\\"{x:1327,y:617,t:1526930141532};\\\", \\\"{x:1330,y:625,t:1526930141549};\\\", \\\"{x:1332,y:629,t:1526930141566};\\\", \\\"{x:1334,y:631,t:1526930141581};\\\", \\\"{x:1336,y:634,t:1526930141599};\\\", \\\"{x:1338,y:637,t:1526930141614};\\\", \\\"{x:1339,y:638,t:1526930141632};\\\", \\\"{x:1339,y:639,t:1526930141649};\\\", \\\"{x:1339,y:641,t:1526930141665};\\\", \\\"{x:1340,y:644,t:1526930141682};\\\", \\\"{x:1345,y:652,t:1526930141699};\\\", \\\"{x:1351,y:663,t:1526930141715};\\\", \\\"{x:1358,y:675,t:1526930141732};\\\", \\\"{x:1366,y:690,t:1526930141750};\\\", \\\"{x:1371,y:696,t:1526930141765};\\\", \\\"{x:1375,y:701,t:1526930141782};\\\", \\\"{x:1375,y:703,t:1526930141799};\\\", \\\"{x:1377,y:705,t:1526930141815};\\\", \\\"{x:1379,y:707,t:1526930141832};\\\", \\\"{x:1380,y:711,t:1526930141849};\\\", \\\"{x:1381,y:712,t:1526930141865};\\\", \\\"{x:1382,y:713,t:1526930141881};\\\", \\\"{x:1382,y:714,t:1526930141899};\\\", \\\"{x:1382,y:716,t:1526930141916};\\\", \\\"{x:1385,y:718,t:1526930141932};\\\", \\\"{x:1385,y:720,t:1526930141949};\\\", \\\"{x:1386,y:723,t:1526930141966};\\\", \\\"{x:1387,y:724,t:1526930141982};\\\", \\\"{x:1388,y:727,t:1526930141999};\\\", \\\"{x:1389,y:728,t:1526930142016};\\\", \\\"{x:1389,y:730,t:1526930142037};\\\", \\\"{x:1389,y:731,t:1526930142061};\\\", \\\"{x:1389,y:733,t:1526930142069};\\\", \\\"{x:1389,y:734,t:1526930142081};\\\", \\\"{x:1391,y:737,t:1526930142099};\\\", \\\"{x:1391,y:738,t:1526930142116};\\\", \\\"{x:1391,y:741,t:1526930142132};\\\", \\\"{x:1391,y:743,t:1526930142149};\\\", \\\"{x:1391,y:746,t:1526930142166};\\\", \\\"{x:1391,y:748,t:1526930142182};\\\", \\\"{x:1391,y:750,t:1526930142198};\\\", \\\"{x:1392,y:751,t:1526930142216};\\\", \\\"{x:1392,y:752,t:1526930142238};\\\", \\\"{x:1394,y:754,t:1526930142249};\\\", \\\"{x:1396,y:757,t:1526930142266};\\\", \\\"{x:1397,y:761,t:1526930142283};\\\", \\\"{x:1399,y:765,t:1526930142299};\\\", \\\"{x:1399,y:767,t:1526930142316};\\\", \\\"{x:1399,y:770,t:1526930142333};\\\", \\\"{x:1399,y:771,t:1526930142349};\\\", \\\"{x:1400,y:774,t:1526930142366};\\\", \\\"{x:1401,y:776,t:1526930142383};\\\", \\\"{x:1401,y:778,t:1526930142430};\\\", \\\"{x:1401,y:780,t:1526930142438};\\\", \\\"{x:1401,y:781,t:1526930142449};\\\", \\\"{x:1401,y:784,t:1526930142466};\\\", \\\"{x:1402,y:785,t:1526930142510};\\\", \\\"{x:1402,y:787,t:1526930142517};\\\", \\\"{x:1402,y:788,t:1526930142533};\\\", \\\"{x:1402,y:789,t:1526930142550};\\\", \\\"{x:1402,y:794,t:1526930142566};\\\", \\\"{x:1402,y:803,t:1526930142583};\\\", \\\"{x:1403,y:817,t:1526930142600};\\\", \\\"{x:1406,y:827,t:1526930142616};\\\", \\\"{x:1410,y:836,t:1526930142633};\\\", \\\"{x:1412,y:839,t:1526930142650};\\\", \\\"{x:1414,y:841,t:1526930142665};\\\", \\\"{x:1418,y:848,t:1526930142683};\\\", \\\"{x:1424,y:858,t:1526930142700};\\\", \\\"{x:1431,y:867,t:1526930142716};\\\", \\\"{x:1438,y:877,t:1526930142733};\\\", \\\"{x:1442,y:883,t:1526930142751};\\\", \\\"{x:1443,y:885,t:1526930142774};\\\", \\\"{x:1447,y:890,t:1526930142783};\\\", \\\"{x:1456,y:901,t:1526930142799};\\\", \\\"{x:1461,y:907,t:1526930142815};\\\", \\\"{x:1465,y:910,t:1526930142832};\\\", \\\"{x:1465,y:911,t:1526930142849};\\\", \\\"{x:1468,y:912,t:1526930142866};\\\", \\\"{x:1468,y:914,t:1526930142883};\\\", \\\"{x:1470,y:916,t:1526930142899};\\\", \\\"{x:1470,y:919,t:1526930142916};\\\", \\\"{x:1472,y:921,t:1526930142933};\\\", \\\"{x:1473,y:928,t:1526930142949};\\\", \\\"{x:1475,y:930,t:1526930142967};\\\", \\\"{x:1475,y:932,t:1526930142982};\\\", \\\"{x:1476,y:934,t:1526930143000};\\\", \\\"{x:1476,y:935,t:1526930143029};\\\", \\\"{x:1476,y:936,t:1526930143046};\\\", \\\"{x:1476,y:937,t:1526930143053};\\\", \\\"{x:1476,y:939,t:1526930143066};\\\", \\\"{x:1476,y:940,t:1526930143092};\\\", \\\"{x:1476,y:941,t:1526930143116};\\\", \\\"{x:1477,y:942,t:1526930143133};\\\", \\\"{x:1478,y:945,t:1526930143150};\\\", \\\"{x:1480,y:948,t:1526930143166};\\\", \\\"{x:1482,y:953,t:1526930143182};\\\", \\\"{x:1482,y:957,t:1526930143199};\\\", \\\"{x:1482,y:958,t:1526930143216};\\\", \\\"{x:1483,y:959,t:1526930143342};\\\", \\\"{x:1483,y:957,t:1526930144830};\\\", \\\"{x:1483,y:955,t:1526930144837};\\\", \\\"{x:1481,y:951,t:1526930144852};\\\", \\\"{x:1481,y:947,t:1526930144868};\\\", \\\"{x:1480,y:945,t:1526930144885};\\\", \\\"{x:1480,y:940,t:1526930144902};\\\", \\\"{x:1479,y:937,t:1526930144918};\\\", \\\"{x:1478,y:933,t:1526930144935};\\\", \\\"{x:1477,y:930,t:1526930144951};\\\", \\\"{x:1476,y:927,t:1526930144968};\\\", \\\"{x:1476,y:925,t:1526930144990};\\\", \\\"{x:1476,y:924,t:1526930145006};\\\", \\\"{x:1476,y:923,t:1526930145018};\\\", \\\"{x:1474,y:922,t:1526930145035};\\\", \\\"{x:1473,y:921,t:1526930145052};\\\", \\\"{x:1472,y:918,t:1526930145069};\\\", \\\"{x:1472,y:917,t:1526930145085};\\\", \\\"{x:1471,y:916,t:1526930145102};\\\", \\\"{x:1469,y:914,t:1526930145119};\\\", \\\"{x:1469,y:913,t:1526930145149};\\\", \\\"{x:1468,y:912,t:1526930145157};\\\", \\\"{x:1467,y:911,t:1526930145169};\\\", \\\"{x:1467,y:910,t:1526930145198};\\\", \\\"{x:1465,y:907,t:1526930145205};\\\", \\\"{x:1462,y:904,t:1526930145221};\\\", \\\"{x:1460,y:903,t:1526930145235};\\\", \\\"{x:1456,y:900,t:1526930145252};\\\", \\\"{x:1452,y:896,t:1526930145269};\\\", \\\"{x:1448,y:891,t:1526930145286};\\\", \\\"{x:1443,y:887,t:1526930145302};\\\", \\\"{x:1438,y:883,t:1526930145319};\\\", \\\"{x:1431,y:877,t:1526930145336};\\\", \\\"{x:1418,y:866,t:1526930145352};\\\", \\\"{x:1404,y:853,t:1526930145369};\\\", \\\"{x:1401,y:850,t:1526930145386};\\\", \\\"{x:1401,y:848,t:1526930145406};\\\", \\\"{x:1401,y:846,t:1526930145419};\\\", \\\"{x:1401,y:844,t:1526930145436};\\\", \\\"{x:1400,y:837,t:1526930145452};\\\", \\\"{x:1398,y:829,t:1526930145470};\\\", \\\"{x:1396,y:820,t:1526930145485};\\\", \\\"{x:1396,y:811,t:1526930145502};\\\", \\\"{x:1396,y:803,t:1526930145519};\\\", \\\"{x:1396,y:799,t:1526930145535};\\\", \\\"{x:1396,y:797,t:1526930145552};\\\", \\\"{x:1398,y:794,t:1526930145569};\\\", \\\"{x:1398,y:786,t:1526930145586};\\\", \\\"{x:1398,y:779,t:1526930145602};\\\", \\\"{x:1398,y:777,t:1526930145629};\\\", \\\"{x:1398,y:776,t:1526930145686};\\\", \\\"{x:1398,y:772,t:1526930145703};\\\", \\\"{x:1398,y:769,t:1526930145719};\\\", \\\"{x:1398,y:767,t:1526930145736};\\\", \\\"{x:1398,y:766,t:1526930145754};\\\", \\\"{x:1398,y:762,t:1526930145769};\\\", \\\"{x:1396,y:754,t:1526930145786};\\\", \\\"{x:1395,y:749,t:1526930145803};\\\", \\\"{x:1389,y:741,t:1526930145819};\\\", \\\"{x:1385,y:733,t:1526930145836};\\\", \\\"{x:1382,y:727,t:1526930145853};\\\", \\\"{x:1381,y:727,t:1526930145869};\\\", \\\"{x:1379,y:725,t:1526930145886};\\\", \\\"{x:1376,y:723,t:1526930145903};\\\", \\\"{x:1376,y:720,t:1526930145919};\\\", \\\"{x:1374,y:717,t:1526930145936};\\\", \\\"{x:1373,y:714,t:1526930145953};\\\", \\\"{x:1370,y:711,t:1526930145969};\\\", \\\"{x:1368,y:710,t:1526930145989};\\\", \\\"{x:1368,y:709,t:1526930146003};\\\", \\\"{x:1364,y:707,t:1526930146019};\\\", \\\"{x:1360,y:705,t:1526930146036};\\\", \\\"{x:1357,y:703,t:1526930146053};\\\", \\\"{x:1353,y:700,t:1526930146069};\\\", \\\"{x:1351,y:698,t:1526930146089};\\\", \\\"{x:1346,y:695,t:1526930146103};\\\", \\\"{x:1343,y:692,t:1526930146120};\\\", \\\"{x:1342,y:692,t:1526930146141};\\\", \\\"{x:1341,y:691,t:1526930146180};\\\", \\\"{x:1341,y:690,t:1526930146494};\\\", \\\"{x:1341,y:688,t:1526930146718};\\\", \\\"{x:1341,y:685,t:1526930146725};\\\", \\\"{x:1341,y:677,t:1526930146738};\\\", \\\"{x:1341,y:666,t:1526930146754};\\\", \\\"{x:1341,y:657,t:1526930146770};\\\", \\\"{x:1342,y:645,t:1526930146787};\\\", \\\"{x:1344,y:631,t:1526930146804};\\\", \\\"{x:1346,y:618,t:1526930146820};\\\", \\\"{x:1348,y:600,t:1526930146837};\\\", \\\"{x:1350,y:590,t:1526930146853};\\\", \\\"{x:1352,y:579,t:1526930146870};\\\", \\\"{x:1355,y:569,t:1526930146887};\\\", \\\"{x:1355,y:562,t:1526930146905};\\\", \\\"{x:1355,y:556,t:1526930146920};\\\", \\\"{x:1355,y:547,t:1526930146937};\\\", \\\"{x:1356,y:543,t:1526930146954};\\\", \\\"{x:1358,y:539,t:1526930146970};\\\", \\\"{x:1358,y:537,t:1526930146987};\\\", \\\"{x:1359,y:534,t:1526930147004};\\\", \\\"{x:1359,y:532,t:1526930147020};\\\", \\\"{x:1360,y:527,t:1526930147037};\\\", \\\"{x:1361,y:525,t:1526930147053};\\\", \\\"{x:1362,y:523,t:1526930147070};\\\", \\\"{x:1364,y:519,t:1526930147088};\\\", \\\"{x:1365,y:515,t:1526930147104};\\\", \\\"{x:1366,y:513,t:1526930147121};\\\", \\\"{x:1369,y:508,t:1526930147137};\\\", \\\"{x:1370,y:505,t:1526930147154};\\\", \\\"{x:1372,y:501,t:1526930147171};\\\", \\\"{x:1374,y:497,t:1526930147187};\\\", \\\"{x:1377,y:490,t:1526930147204};\\\", \\\"{x:1382,y:481,t:1526930147222};\\\", \\\"{x:1383,y:480,t:1526930147237};\\\", \\\"{x:1386,y:476,t:1526930147253};\\\", \\\"{x:1389,y:473,t:1526930147271};\\\", \\\"{x:1390,y:470,t:1526930147287};\\\", \\\"{x:1391,y:467,t:1526930147304};\\\", \\\"{x:1392,y:466,t:1526930147321};\\\", \\\"{x:1393,y:464,t:1526930147338};\\\", \\\"{x:1393,y:460,t:1526930147354};\\\", \\\"{x:1396,y:456,t:1526930147371};\\\", \\\"{x:1398,y:452,t:1526930147387};\\\", \\\"{x:1400,y:449,t:1526930147405};\\\", \\\"{x:1403,y:444,t:1526930147421};\\\", \\\"{x:1404,y:442,t:1526930147437};\\\", \\\"{x:1405,y:440,t:1526930147454};\\\", \\\"{x:1406,y:440,t:1526930147501};\\\", \\\"{x:1406,y:447,t:1526930147990};\\\", \\\"{x:1397,y:460,t:1526930148006};\\\", \\\"{x:1384,y:478,t:1526930148021};\\\", \\\"{x:1375,y:492,t:1526930148038};\\\", \\\"{x:1366,y:509,t:1526930148055};\\\", \\\"{x:1361,y:522,t:1526930148071};\\\", \\\"{x:1357,y:534,t:1526930148088};\\\", \\\"{x:1354,y:541,t:1526930148105};\\\", \\\"{x:1353,y:548,t:1526930148121};\\\", \\\"{x:1353,y:552,t:1526930148138};\\\", \\\"{x:1352,y:561,t:1526930148155};\\\", \\\"{x:1348,y:568,t:1526930148171};\\\", \\\"{x:1347,y:576,t:1526930148189};\\\", \\\"{x:1345,y:584,t:1526930148205};\\\", \\\"{x:1344,y:590,t:1526930148221};\\\", \\\"{x:1341,y:596,t:1526930148238};\\\", \\\"{x:1339,y:602,t:1526930148255};\\\", \\\"{x:1336,y:610,t:1526930148272};\\\", \\\"{x:1330,y:623,t:1526930148288};\\\", \\\"{x:1319,y:636,t:1526930148305};\\\", \\\"{x:1310,y:651,t:1526930148322};\\\", \\\"{x:1296,y:662,t:1526930148338};\\\", \\\"{x:1283,y:674,t:1526930148355};\\\", \\\"{x:1271,y:683,t:1526930148372};\\\", \\\"{x:1256,y:693,t:1526930148389};\\\", \\\"{x:1239,y:712,t:1526930148405};\\\", \\\"{x:1228,y:726,t:1526930148422};\\\", \\\"{x:1224,y:730,t:1526930148438};\\\", \\\"{x:1220,y:734,t:1526930148455};\\\", \\\"{x:1216,y:739,t:1526930148472};\\\", \\\"{x:1214,y:743,t:1526930148488};\\\", \\\"{x:1214,y:747,t:1526930148505};\\\", \\\"{x:1214,y:751,t:1526930148522};\\\", \\\"{x:1214,y:752,t:1526930148541};\\\", \\\"{x:1214,y:754,t:1526930148592};\\\", \\\"{x:1212,y:757,t:1526930148604};\\\", \\\"{x:1212,y:758,t:1526930148621};\\\", \\\"{x:1211,y:760,t:1526930148639};\\\", \\\"{x:1210,y:762,t:1526930148654};\\\", \\\"{x:1208,y:765,t:1526930148671};\\\", \\\"{x:1207,y:768,t:1526930148688};\\\", \\\"{x:1202,y:769,t:1526930148705};\\\", \\\"{x:1202,y:770,t:1526930148722};\\\", \\\"{x:1199,y:770,t:1526930148738};\\\", \\\"{x:1198,y:771,t:1526930148755};\\\", \\\"{x:1197,y:772,t:1526930148780};\\\", \\\"{x:1195,y:772,t:1526930148813};\\\", \\\"{x:1192,y:772,t:1526930148822};\\\", \\\"{x:1191,y:772,t:1526930148844};\\\", \\\"{x:1190,y:772,t:1526930148855};\\\", \\\"{x:1189,y:772,t:1526930148934};\\\", \\\"{x:1186,y:772,t:1526930149246};\\\", \\\"{x:1185,y:772,t:1526930149256};\\\", \\\"{x:1181,y:771,t:1526930149273};\\\", \\\"{x:1178,y:770,t:1526930149289};\\\", \\\"{x:1177,y:769,t:1526930149309};\\\", \\\"{x:1176,y:768,t:1526930149326};\\\", \\\"{x:1175,y:767,t:1526930149341};\\\", \\\"{x:1175,y:766,t:1526930149806};\\\", \\\"{x:1175,y:767,t:1526930149909};\\\", \\\"{x:1175,y:768,t:1526930149923};\\\", \\\"{x:1175,y:769,t:1526930149942};\\\", \\\"{x:1175,y:770,t:1526930149990};\\\", \\\"{x:1175,y:771,t:1526930150180};\\\", \\\"{x:1175,y:772,t:1526930150197};\\\", \\\"{x:1177,y:773,t:1526930150213};\\\", \\\"{x:1178,y:774,t:1526930150223};\\\", \\\"{x:1184,y:774,t:1526930150240};\\\", \\\"{x:1186,y:775,t:1526930150257};\\\", \\\"{x:1191,y:775,t:1526930150273};\\\", \\\"{x:1203,y:774,t:1526930150290};\\\", \\\"{x:1224,y:774,t:1526930150307};\\\", \\\"{x:1249,y:774,t:1526930150324};\\\", \\\"{x:1271,y:772,t:1526930150340};\\\", \\\"{x:1293,y:764,t:1526930150357};\\\", \\\"{x:1310,y:761,t:1526930150373};\\\", \\\"{x:1320,y:758,t:1526930150390};\\\", \\\"{x:1326,y:757,t:1526930150407};\\\", \\\"{x:1330,y:757,t:1526930150424};\\\", \\\"{x:1331,y:757,t:1526930150440};\\\", \\\"{x:1332,y:755,t:1526930150457};\\\", \\\"{x:1333,y:755,t:1526930150542};\\\", \\\"{x:1336,y:755,t:1526930150557};\\\", \\\"{x:1337,y:756,t:1526930150661};\\\", \\\"{x:1340,y:757,t:1526930150674};\\\", \\\"{x:1343,y:759,t:1526930150691};\\\", \\\"{x:1345,y:761,t:1526930150707};\\\", \\\"{x:1346,y:762,t:1526930150724};\\\", \\\"{x:1346,y:763,t:1526930150918};\\\", \\\"{x:1346,y:765,t:1526930150925};\\\", \\\"{x:1346,y:766,t:1526930150974};\\\", \\\"{x:1345,y:767,t:1526930150997};\\\", \\\"{x:1345,y:768,t:1526930151021};\\\", \\\"{x:1345,y:769,t:1526930151038};\\\", \\\"{x:1345,y:771,t:1526930151094};\\\", \\\"{x:1344,y:773,t:1526930151190};\\\", \\\"{x:1344,y:775,t:1526930151198};\\\", \\\"{x:1344,y:776,t:1526930151222};\\\", \\\"{x:1344,y:778,t:1526930151229};\\\", \\\"{x:1343,y:779,t:1526930151242};\\\", \\\"{x:1340,y:783,t:1526930151258};\\\", \\\"{x:1337,y:786,t:1526930151274};\\\", \\\"{x:1333,y:790,t:1526930151291};\\\", \\\"{x:1329,y:794,t:1526930151308};\\\", \\\"{x:1326,y:800,t:1526930151324};\\\", \\\"{x:1319,y:810,t:1526930151341};\\\", \\\"{x:1315,y:816,t:1526930151358};\\\", \\\"{x:1310,y:822,t:1526930151375};\\\", \\\"{x:1304,y:827,t:1526930151391};\\\", \\\"{x:1297,y:832,t:1526930151408};\\\", \\\"{x:1286,y:840,t:1526930151428};\\\", \\\"{x:1278,y:851,t:1526930151441};\\\", \\\"{x:1269,y:863,t:1526930151457};\\\", \\\"{x:1259,y:875,t:1526930151475};\\\", \\\"{x:1251,y:885,t:1526930151490};\\\", \\\"{x:1245,y:894,t:1526930151508};\\\", \\\"{x:1242,y:904,t:1526930151524};\\\", \\\"{x:1241,y:906,t:1526930151541};\\\", \\\"{x:1240,y:909,t:1526930151557};\\\", \\\"{x:1239,y:910,t:1526930151574};\\\", \\\"{x:1239,y:916,t:1526930151590};\\\", \\\"{x:1239,y:917,t:1526930151613};\\\", \\\"{x:1239,y:919,t:1526930151625};\\\", \\\"{x:1237,y:921,t:1526930151640};\\\", \\\"{x:1237,y:923,t:1526930151657};\\\", \\\"{x:1236,y:929,t:1526930151674};\\\", \\\"{x:1235,y:932,t:1526930151691};\\\", \\\"{x:1233,y:933,t:1526930151708};\\\", \\\"{x:1233,y:931,t:1526930151782};\\\", \\\"{x:1232,y:923,t:1526930151797};\\\", \\\"{x:1228,y:917,t:1526930151808};\\\", \\\"{x:1219,y:907,t:1526930151825};\\\", \\\"{x:1213,y:896,t:1526930151842};\\\", \\\"{x:1208,y:890,t:1526930151859};\\\", \\\"{x:1205,y:885,t:1526930151875};\\\", \\\"{x:1202,y:880,t:1526930151892};\\\", \\\"{x:1197,y:871,t:1526930151908};\\\", \\\"{x:1191,y:853,t:1526930151925};\\\", \\\"{x:1186,y:843,t:1526930151942};\\\", \\\"{x:1177,y:830,t:1526930151959};\\\", \\\"{x:1162,y:817,t:1526930151976};\\\", \\\"{x:1140,y:810,t:1526930151992};\\\", \\\"{x:1111,y:800,t:1526930152009};\\\", \\\"{x:1068,y:786,t:1526930152025};\\\", \\\"{x:1011,y:766,t:1526930152043};\\\", \\\"{x:951,y:740,t:1526930152060};\\\", \\\"{x:917,y:725,t:1526930152075};\\\", \\\"{x:857,y:697,t:1526930152092};\\\", \\\"{x:804,y:669,t:1526930152109};\\\", \\\"{x:776,y:655,t:1526930152125};\\\", \\\"{x:758,y:644,t:1526930152142};\\\", \\\"{x:747,y:637,t:1526930152159};\\\", \\\"{x:739,y:630,t:1526930152176};\\\", \\\"{x:733,y:624,t:1526930152192};\\\", \\\"{x:725,y:616,t:1526930152208};\\\", \\\"{x:718,y:611,t:1526930152223};\\\", \\\"{x:709,y:605,t:1526930152239};\\\", \\\"{x:696,y:597,t:1526930152255};\\\", \\\"{x:689,y:594,t:1526930152273};\\\", \\\"{x:679,y:588,t:1526930152289};\\\", \\\"{x:665,y:582,t:1526930152306};\\\", \\\"{x:655,y:578,t:1526930152322};\\\", \\\"{x:647,y:577,t:1526930152339};\\\", \\\"{x:637,y:574,t:1526930152355};\\\", \\\"{x:615,y:572,t:1526930152373};\\\", \\\"{x:607,y:570,t:1526930152389};\\\", \\\"{x:587,y:568,t:1526930152406};\\\", \\\"{x:578,y:567,t:1526930152422};\\\", \\\"{x:568,y:567,t:1526930152439};\\\", \\\"{x:564,y:566,t:1526930152455};\\\", \\\"{x:556,y:566,t:1526930152473};\\\", \\\"{x:539,y:566,t:1526930152490};\\\", \\\"{x:539,y:567,t:1526930152506};\\\", \\\"{x:539,y:568,t:1526930152522};\\\", \\\"{x:537,y:568,t:1526930152837};\\\", \\\"{x:533,y:567,t:1526930152845};\\\", \\\"{x:522,y:565,t:1526930152856};\\\", \\\"{x:495,y:555,t:1526930152875};\\\", \\\"{x:469,y:548,t:1526930152890};\\\", \\\"{x:446,y:540,t:1526930152907};\\\", \\\"{x:428,y:536,t:1526930152923};\\\", \\\"{x:389,y:526,t:1526930152940};\\\", \\\"{x:352,y:523,t:1526930152958};\\\", \\\"{x:342,y:521,t:1526930152974};\\\", \\\"{x:333,y:521,t:1526930152989};\\\", \\\"{x:328,y:521,t:1526930153006};\\\", \\\"{x:327,y:521,t:1526930153044};\\\", \\\"{x:326,y:521,t:1526930153056};\\\", \\\"{x:323,y:521,t:1526930153077};\\\", \\\"{x:312,y:522,t:1526930153090};\\\", \\\"{x:303,y:522,t:1526930153106};\\\", \\\"{x:282,y:522,t:1526930153122};\\\", \\\"{x:253,y:514,t:1526930153140};\\\", \\\"{x:202,y:491,t:1526930153156};\\\", \\\"{x:173,y:480,t:1526930153173};\\\", \\\"{x:156,y:476,t:1526930153189};\\\", \\\"{x:151,y:476,t:1526930153207};\\\", \\\"{x:152,y:481,t:1526930153350};\\\", \\\"{x:154,y:486,t:1526930153357};\\\", \\\"{x:156,y:491,t:1526930153374};\\\", \\\"{x:157,y:493,t:1526930153390};\\\", \\\"{x:157,y:494,t:1526930153406};\\\", \\\"{x:157,y:495,t:1526930153423};\\\", \\\"{x:159,y:495,t:1526930153452};\\\", \\\"{x:161,y:497,t:1526930153460};\\\", \\\"{x:164,y:497,t:1526930153473};\\\", \\\"{x:172,y:501,t:1526930153490};\\\", \\\"{x:175,y:505,t:1526930153507};\\\", \\\"{x:177,y:505,t:1526930153604};\\\", \\\"{x:178,y:506,t:1526930153628};\\\", \\\"{x:178,y:506,t:1526930153706};\\\", \\\"{x:180,y:507,t:1526930153909};\\\", \\\"{x:181,y:508,t:1526930153924};\\\", \\\"{x:185,y:510,t:1526930153941};\\\", \\\"{x:192,y:510,t:1526930153958};\\\", \\\"{x:195,y:511,t:1526930153973};\\\", \\\"{x:196,y:511,t:1526930154060};\\\", \\\"{x:196,y:510,t:1526930154073};\\\", \\\"{x:189,y:506,t:1526930154090};\\\", \\\"{x:180,y:502,t:1526930154108};\\\", \\\"{x:175,y:502,t:1526930154124};\\\", \\\"{x:172,y:501,t:1526930154141};\\\", \\\"{x:170,y:501,t:1526930154213};\\\", \\\"{x:169,y:501,t:1526930154224};\\\", \\\"{x:168,y:502,t:1526930154269};\\\", \\\"{x:168,y:506,t:1526930154277};\\\", \\\"{x:170,y:508,t:1526930154291};\\\", \\\"{x:198,y:524,t:1526930154309};\\\", \\\"{x:203,y:526,t:1526930154324};\\\", \\\"{x:355,y:573,t:1526930154341};\\\", \\\"{x:460,y:604,t:1526930154359};\\\", \\\"{x:565,y:632,t:1526930154374};\\\", \\\"{x:652,y:651,t:1526930154391};\\\", \\\"{x:685,y:657,t:1526930154407};\\\", \\\"{x:711,y:660,t:1526930154424};\\\", \\\"{x:745,y:669,t:1526930154440};\\\", \\\"{x:778,y:681,t:1526930154457};\\\", \\\"{x:825,y:692,t:1526930154475};\\\", \\\"{x:866,y:702,t:1526930154491};\\\", \\\"{x:893,y:709,t:1526930154508};\\\", \\\"{x:940,y:714,t:1526930154524};\\\", \\\"{x:963,y:717,t:1526930154542};\\\", \\\"{x:992,y:726,t:1526930154558};\\\", \\\"{x:1010,y:733,t:1526930154575};\\\", \\\"{x:1023,y:742,t:1526930154592};\\\", \\\"{x:1025,y:744,t:1526930154608};\\\", \\\"{x:1028,y:747,t:1526930154624};\\\", \\\"{x:1028,y:752,t:1526930154642};\\\", \\\"{x:1029,y:758,t:1526930154658};\\\", \\\"{x:1029,y:764,t:1526930154675};\\\", \\\"{x:1029,y:767,t:1526930154692};\\\", \\\"{x:1030,y:771,t:1526930154709};\\\", \\\"{x:1033,y:781,t:1526930154725};\\\", \\\"{x:1034,y:795,t:1526930154742};\\\", \\\"{x:1034,y:806,t:1526930154759};\\\", \\\"{x:1036,y:817,t:1526930154775};\\\", \\\"{x:1038,y:823,t:1526930154792};\\\", \\\"{x:1043,y:832,t:1526930154809};\\\", \\\"{x:1047,y:841,t:1526930154826};\\\", \\\"{x:1052,y:847,t:1526930154842};\\\", \\\"{x:1055,y:852,t:1526930154860};\\\", \\\"{x:1056,y:853,t:1526930154876};\\\", \\\"{x:1056,y:854,t:1526930154892};\\\", \\\"{x:1057,y:856,t:1526930154909};\\\", \\\"{x:1058,y:860,t:1526930154925};\\\", \\\"{x:1063,y:867,t:1526930154942};\\\", \\\"{x:1064,y:869,t:1526930154959};\\\", \\\"{x:1065,y:872,t:1526930154976};\\\", \\\"{x:1066,y:873,t:1526930154993};\\\", \\\"{x:1066,y:876,t:1526930155009};\\\", \\\"{x:1067,y:879,t:1526930155026};\\\", \\\"{x:1070,y:884,t:1526930155043};\\\", \\\"{x:1076,y:898,t:1526930155059};\\\", \\\"{x:1083,y:909,t:1526930155076};\\\", \\\"{x:1097,y:929,t:1526930155093};\\\", \\\"{x:1110,y:948,t:1526930155109};\\\", \\\"{x:1120,y:963,t:1526930155127};\\\", \\\"{x:1147,y:989,t:1526930155143};\\\", \\\"{x:1195,y:1013,t:1526930155160};\\\", \\\"{x:1265,y:1039,t:1526930155176};\\\", \\\"{x:1303,y:1048,t:1526930155193};\\\", \\\"{x:1313,y:1049,t:1526930155210};\\\", \\\"{x:1309,y:1049,t:1526930155262};\\\", \\\"{x:1306,y:1049,t:1526930155276};\\\", \\\"{x:1298,y:1049,t:1526930155293};\\\", \\\"{x:1293,y:1049,t:1526930155310};\\\", \\\"{x:1277,y:1044,t:1526930155327};\\\", \\\"{x:1269,y:1037,t:1526930155343};\\\", \\\"{x:1262,y:1035,t:1526930155360};\\\", \\\"{x:1255,y:1027,t:1526930155377};\\\", \\\"{x:1242,y:1021,t:1526930155394};\\\", \\\"{x:1236,y:1019,t:1526930155410};\\\", \\\"{x:1224,y:1012,t:1526930155427};\\\", \\\"{x:1211,y:1008,t:1526930155445};\\\", \\\"{x:1196,y:1003,t:1526930155460};\\\", \\\"{x:1183,y:1000,t:1526930155477};\\\", \\\"{x:1180,y:997,t:1526930155494};\\\", \\\"{x:1176,y:997,t:1526930155511};\\\", \\\"{x:1174,y:996,t:1526930155528};\\\", \\\"{x:1170,y:995,t:1526930155545};\\\", \\\"{x:1167,y:993,t:1526930155560};\\\", \\\"{x:1162,y:991,t:1526930155577};\\\", \\\"{x:1161,y:991,t:1526930155594};\\\", \\\"{x:1161,y:990,t:1526930155613};\\\", \\\"{x:1159,y:990,t:1526930155629};\\\", \\\"{x:1158,y:988,t:1526930155645};\\\", \\\"{x:1153,y:983,t:1526930155662};\\\", \\\"{x:1148,y:976,t:1526930155678};\\\", \\\"{x:1143,y:970,t:1526930155694};\\\", \\\"{x:1137,y:963,t:1526930155711};\\\", \\\"{x:1136,y:960,t:1526930155729};\\\", \\\"{x:1136,y:959,t:1526930155744};\\\", \\\"{x:1135,y:958,t:1526930155762};\\\", \\\"{x:1134,y:958,t:1526930156070};\\\", \\\"{x:1133,y:958,t:1526930156085};\\\", \\\"{x:1131,y:958,t:1526930156095};\\\", \\\"{x:1130,y:958,t:1526930156112};\\\", \\\"{x:1128,y:958,t:1526930156129};\\\", \\\"{x:1126,y:958,t:1526930156145};\\\", \\\"{x:1125,y:958,t:1526930156162};\\\", \\\"{x:1124,y:957,t:1526930156179};\\\", \\\"{x:1123,y:957,t:1526930156195};\\\", \\\"{x:1121,y:957,t:1526930156212};\\\", \\\"{x:1118,y:955,t:1526930156229};\\\", \\\"{x:1116,y:955,t:1526930156245};\\\", \\\"{x:1114,y:955,t:1526930156310};\\\", \\\"{x:1113,y:955,t:1526930156318};\\\", \\\"{x:1111,y:954,t:1526930156329};\\\", \\\"{x:1109,y:953,t:1526930156346};\\\", \\\"{x:1106,y:953,t:1526930156362};\\\", \\\"{x:1101,y:951,t:1526930156379};\\\", \\\"{x:1099,y:950,t:1526930156396};\\\", \\\"{x:1092,y:948,t:1526930156412};\\\", \\\"{x:1080,y:943,t:1526930156429};\\\", \\\"{x:1076,y:941,t:1526930156446};\\\", \\\"{x:1074,y:941,t:1526930156463};\\\", \\\"{x:1074,y:940,t:1526930156480};\\\", \\\"{x:1074,y:939,t:1526930156496};\\\", \\\"{x:1074,y:938,t:1526930156514};\\\", \\\"{x:1073,y:936,t:1526930156529};\\\", \\\"{x:1072,y:936,t:1526930156565};\\\", \\\"{x:1072,y:935,t:1526930156597};\\\", \\\"{x:1073,y:935,t:1526930156613};\\\", \\\"{x:1075,y:933,t:1526930156630};\\\", \\\"{x:1076,y:933,t:1526930156646};\\\", \\\"{x:1078,y:931,t:1526930156663};\\\", \\\"{x:1079,y:931,t:1526930156681};\\\", \\\"{x:1080,y:931,t:1526930156701};\\\", \\\"{x:1081,y:930,t:1526930156714};\\\", \\\"{x:1082,y:928,t:1526930156733};\\\", \\\"{x:1082,y:927,t:1526930156749};\\\", \\\"{x:1083,y:925,t:1526930156763};\\\", \\\"{x:1084,y:920,t:1526930156782};\\\", \\\"{x:1084,y:917,t:1526930156797};\\\", \\\"{x:1085,y:914,t:1526930156813};\\\", \\\"{x:1085,y:911,t:1526930156830};\\\", \\\"{x:1085,y:910,t:1526930156848};\\\", \\\"{x:1086,y:908,t:1526930156863};\\\", \\\"{x:1087,y:906,t:1526930156893};\\\", \\\"{x:1088,y:904,t:1526930156917};\\\", \\\"{x:1089,y:903,t:1526930156941};\\\", \\\"{x:1091,y:902,t:1526930156965};\\\", \\\"{x:1091,y:901,t:1526930156980};\\\", \\\"{x:1092,y:900,t:1526930156998};\\\", \\\"{x:1095,y:897,t:1526930157022};\\\", \\\"{x:1095,y:896,t:1526930157037};\\\", \\\"{x:1096,y:894,t:1526930157047};\\\", \\\"{x:1098,y:891,t:1526930157064};\\\", \\\"{x:1100,y:887,t:1526930157081};\\\", \\\"{x:1100,y:885,t:1526930157098};\\\", \\\"{x:1103,y:882,t:1526930157115};\\\", \\\"{x:1106,y:878,t:1526930157131};\\\", \\\"{x:1109,y:874,t:1526930157148};\\\", \\\"{x:1113,y:872,t:1526930157165};\\\", \\\"{x:1117,y:868,t:1526930157181};\\\", \\\"{x:1121,y:865,t:1526930157198};\\\", \\\"{x:1124,y:861,t:1526930157214};\\\", \\\"{x:1129,y:857,t:1526930157231};\\\", \\\"{x:1132,y:853,t:1526930157248};\\\", \\\"{x:1135,y:849,t:1526930157264};\\\", \\\"{x:1137,y:844,t:1526930157281};\\\", \\\"{x:1139,y:841,t:1526930157298};\\\", \\\"{x:1139,y:839,t:1526930157314};\\\", \\\"{x:1140,y:838,t:1526930157333};\\\", \\\"{x:1141,y:837,t:1526930157348};\\\", \\\"{x:1143,y:834,t:1526930157365};\\\", \\\"{x:1144,y:830,t:1526930157381};\\\", \\\"{x:1146,y:827,t:1526930157398};\\\", \\\"{x:1148,y:822,t:1526930157416};\\\", \\\"{x:1150,y:819,t:1526930157431};\\\", \\\"{x:1152,y:817,t:1526930157448};\\\", \\\"{x:1154,y:813,t:1526930157466};\\\", \\\"{x:1156,y:811,t:1526930157482};\\\", \\\"{x:1159,y:808,t:1526930157498};\\\", \\\"{x:1161,y:804,t:1526930157515};\\\", \\\"{x:1165,y:798,t:1526930157533};\\\", \\\"{x:1169,y:792,t:1526930157548};\\\", \\\"{x:1176,y:788,t:1526930157565};\\\", \\\"{x:1180,y:785,t:1526930157583};\\\", \\\"{x:1183,y:781,t:1526930157598};\\\", \\\"{x:1185,y:779,t:1526930157615};\\\", \\\"{x:1185,y:777,t:1526930157632};\\\", \\\"{x:1185,y:775,t:1526930157649};\\\", \\\"{x:1186,y:774,t:1526930157665};\\\", \\\"{x:1186,y:772,t:1526930157846};\\\", \\\"{x:1187,y:771,t:1526930158837};\\\", \\\"{x:1187,y:770,t:1526930158851};\\\", \\\"{x:1188,y:768,t:1526930158869};\\\", \\\"{x:1189,y:765,t:1526930158885};\\\", \\\"{x:1189,y:764,t:1526930158933};\\\", \\\"{x:1189,y:763,t:1526930158941};\\\", \\\"{x:1189,y:762,t:1526930158958};\\\", \\\"{x:1191,y:761,t:1526930158968};\\\", \\\"{x:1192,y:759,t:1526930158984};\\\", \\\"{x:1194,y:756,t:1526930159001};\\\", \\\"{x:1196,y:752,t:1526930159018};\\\", \\\"{x:1199,y:746,t:1526930159035};\\\", \\\"{x:1202,y:738,t:1526930159052};\\\", \\\"{x:1210,y:719,t:1526930159068};\\\", \\\"{x:1214,y:712,t:1526930159085};\\\", \\\"{x:1224,y:696,t:1526930159102};\\\", \\\"{x:1233,y:684,t:1526930159119};\\\", \\\"{x:1241,y:673,t:1526930159135};\\\", \\\"{x:1246,y:659,t:1526930159152};\\\", \\\"{x:1254,y:648,t:1526930159169};\\\", \\\"{x:1257,y:641,t:1526930159185};\\\", \\\"{x:1259,y:635,t:1526930159202};\\\", \\\"{x:1264,y:626,t:1526930159219};\\\", \\\"{x:1264,y:621,t:1526930159235};\\\", \\\"{x:1265,y:620,t:1526930159268};\\\", \\\"{x:1266,y:619,t:1526930159286};\\\", \\\"{x:1266,y:617,t:1526930159302};\\\", \\\"{x:1267,y:615,t:1526930159319};\\\", \\\"{x:1268,y:612,t:1526930159336};\\\", \\\"{x:1270,y:608,t:1526930159352};\\\", \\\"{x:1273,y:604,t:1526930159369};\\\", \\\"{x:1275,y:602,t:1526930159385};\\\", \\\"{x:1277,y:599,t:1526930159403};\\\", \\\"{x:1278,y:598,t:1526930159419};\\\", \\\"{x:1279,y:597,t:1526930159436};\\\", \\\"{x:1279,y:595,t:1526930159453};\\\", \\\"{x:1280,y:593,t:1526930159469};\\\", \\\"{x:1281,y:593,t:1526930159486};\\\", \\\"{x:1281,y:592,t:1526930159503};\\\", \\\"{x:1281,y:590,t:1526930159518};\\\", \\\"{x:1281,y:586,t:1526930159535};\\\", \\\"{x:1284,y:580,t:1526930159553};\\\", \\\"{x:1284,y:575,t:1526930159570};\\\", \\\"{x:1284,y:571,t:1526930159586};\\\", \\\"{x:1284,y:569,t:1526930159602};\\\", \\\"{x:1285,y:566,t:1526930159620};\\\", \\\"{x:1285,y:565,t:1526930159636};\\\", \\\"{x:1285,y:563,t:1526930159653};\\\", \\\"{x:1285,y:562,t:1526930159676};\\\", \\\"{x:1286,y:561,t:1526930159700};\\\", \\\"{x:1286,y:560,t:1526930159708};\\\", \\\"{x:1286,y:561,t:1526930160036};\\\", \\\"{x:1288,y:564,t:1526930160044};\\\", \\\"{x:1290,y:566,t:1526930160053};\\\", \\\"{x:1292,y:569,t:1526930160070};\\\", \\\"{x:1295,y:575,t:1526930160087};\\\", \\\"{x:1299,y:582,t:1526930160104};\\\", \\\"{x:1301,y:585,t:1526930160120};\\\", \\\"{x:1302,y:590,t:1526930160137};\\\", \\\"{x:1304,y:592,t:1526930160154};\\\", \\\"{x:1305,y:594,t:1526930160173};\\\", \\\"{x:1305,y:595,t:1526930160187};\\\", \\\"{x:1306,y:596,t:1526930160203};\\\", \\\"{x:1307,y:597,t:1526930160236};\\\", \\\"{x:1307,y:599,t:1526930160244};\\\", \\\"{x:1307,y:602,t:1526930160253};\\\", \\\"{x:1310,y:607,t:1526930160271};\\\", \\\"{x:1312,y:610,t:1526930160292};\\\", \\\"{x:1312,y:613,t:1526930160304};\\\", \\\"{x:1312,y:620,t:1526930160321};\\\", \\\"{x:1315,y:626,t:1526930160338};\\\", \\\"{x:1319,y:632,t:1526930160355};\\\", \\\"{x:1322,y:636,t:1526930160371};\\\", \\\"{x:1322,y:637,t:1526930160388};\\\", \\\"{x:1323,y:638,t:1526930160405};\\\", \\\"{x:1326,y:644,t:1526930160422};\\\", \\\"{x:1332,y:656,t:1526930160437};\\\", \\\"{x:1338,y:669,t:1526930160454};\\\", \\\"{x:1344,y:685,t:1526930160471};\\\", \\\"{x:1348,y:700,t:1526930160488};\\\", \\\"{x:1353,y:710,t:1526930160505};\\\", \\\"{x:1357,y:721,t:1526930160522};\\\", \\\"{x:1362,y:734,t:1526930160538};\\\", \\\"{x:1366,y:745,t:1526930160554};\\\", \\\"{x:1367,y:745,t:1526930160572};\\\", \\\"{x:1367,y:748,t:1526930160589};\\\", \\\"{x:1367,y:749,t:1526930160605};\\\", \\\"{x:1367,y:751,t:1526930160622};\\\", \\\"{x:1368,y:753,t:1526930160638};\\\", \\\"{x:1370,y:759,t:1526930160655};\\\", \\\"{x:1375,y:772,t:1526930160672};\\\", \\\"{x:1381,y:784,t:1526930160689};\\\", \\\"{x:1389,y:793,t:1526930160704};\\\", \\\"{x:1391,y:797,t:1526930160722};\\\", \\\"{x:1393,y:800,t:1526930160739};\\\", \\\"{x:1398,y:808,t:1526930160756};\\\", \\\"{x:1402,y:813,t:1526930160771};\\\", \\\"{x:1408,y:828,t:1526930160789};\\\", \\\"{x:1416,y:837,t:1526930160806};\\\", \\\"{x:1417,y:838,t:1526930160821};\\\", \\\"{x:1419,y:839,t:1526930160839};\\\", \\\"{x:1419,y:838,t:1526930160973};\\\", \\\"{x:1417,y:834,t:1526930160989};\\\", \\\"{x:1417,y:833,t:1526930161006};\\\", \\\"{x:1417,y:831,t:1526930161023};\\\", \\\"{x:1416,y:831,t:1526930161039};\\\", \\\"{x:1415,y:830,t:1526930161056};\\\", \\\"{x:1412,y:827,t:1526930161073};\\\", \\\"{x:1408,y:822,t:1526930161090};\\\", \\\"{x:1403,y:817,t:1526930161106};\\\", \\\"{x:1401,y:814,t:1526930161123};\\\", \\\"{x:1400,y:814,t:1526930161140};\\\", \\\"{x:1399,y:812,t:1526930161156};\\\", \\\"{x:1398,y:810,t:1526930161173};\\\", \\\"{x:1395,y:807,t:1526930161189};\\\", \\\"{x:1389,y:800,t:1526930161206};\\\", \\\"{x:1382,y:792,t:1526930161223};\\\", \\\"{x:1378,y:787,t:1526930161239};\\\", \\\"{x:1376,y:783,t:1526930161257};\\\", \\\"{x:1375,y:782,t:1526930161276};\\\", \\\"{x:1375,y:781,t:1526930161292};\\\", \\\"{x:1374,y:780,t:1526930161308};\\\", \\\"{x:1370,y:778,t:1526930161324};\\\", \\\"{x:1368,y:776,t:1526930161340};\\\", \\\"{x:1365,y:772,t:1526930161356};\\\", \\\"{x:1364,y:772,t:1526930161373};\\\", \\\"{x:1363,y:771,t:1526930161390};\\\", \\\"{x:1362,y:770,t:1526930161407};\\\", \\\"{x:1361,y:769,t:1526930161424};\\\", \\\"{x:1357,y:765,t:1526930161440};\\\", \\\"{x:1354,y:762,t:1526930161457};\\\", \\\"{x:1350,y:756,t:1526930161474};\\\", \\\"{x:1348,y:753,t:1526930161491};\\\", \\\"{x:1347,y:752,t:1526930161506};\\\", \\\"{x:1345,y:751,t:1526930161523};\\\", \\\"{x:1344,y:749,t:1526930161540};\\\", \\\"{x:1344,y:747,t:1526930161557};\\\", \\\"{x:1340,y:741,t:1526930161574};\\\", \\\"{x:1336,y:737,t:1526930161591};\\\", \\\"{x:1333,y:733,t:1526930161607};\\\", \\\"{x:1333,y:732,t:1526930161645};\\\", \\\"{x:1332,y:732,t:1526930161658};\\\", \\\"{x:1332,y:731,t:1526930161674};\\\", \\\"{x:1331,y:730,t:1526930161690};\\\", \\\"{x:1331,y:728,t:1526930161708};\\\", \\\"{x:1330,y:728,t:1526930161724};\\\", \\\"{x:1329,y:727,t:1526930161741};\\\", \\\"{x:1329,y:726,t:1526930161758};\\\", \\\"{x:1329,y:724,t:1526930161775};\\\", \\\"{x:1328,y:721,t:1526930161791};\\\", \\\"{x:1326,y:717,t:1526930161808};\\\", \\\"{x:1326,y:714,t:1526930161825};\\\", \\\"{x:1324,y:711,t:1526930161841};\\\", \\\"{x:1321,y:705,t:1526930161858};\\\", \\\"{x:1321,y:704,t:1526930161875};\\\", \\\"{x:1318,y:701,t:1526930161892};\\\", \\\"{x:1315,y:697,t:1526930161908};\\\", \\\"{x:1311,y:691,t:1526930161924};\\\", \\\"{x:1308,y:688,t:1526930161942};\\\", \\\"{x:1306,y:682,t:1526930161958};\\\", \\\"{x:1303,y:675,t:1526930161975};\\\", \\\"{x:1301,y:666,t:1526930161991};\\\", \\\"{x:1298,y:656,t:1526930162008};\\\", \\\"{x:1298,y:651,t:1526930162024};\\\", \\\"{x:1297,y:644,t:1526930162042};\\\", \\\"{x:1295,y:636,t:1526930162059};\\\", \\\"{x:1294,y:629,t:1526930162075};\\\", \\\"{x:1293,y:620,t:1526930162092};\\\", \\\"{x:1293,y:616,t:1526930162108};\\\", \\\"{x:1291,y:611,t:1526930162125};\\\", \\\"{x:1289,y:606,t:1526930162142};\\\", \\\"{x:1289,y:602,t:1526930162159};\\\", \\\"{x:1288,y:600,t:1526930162174};\\\", \\\"{x:1287,y:598,t:1526930162192};\\\", \\\"{x:1286,y:596,t:1526930162208};\\\", \\\"{x:1286,y:595,t:1526930162226};\\\", \\\"{x:1285,y:593,t:1526930162242};\\\", \\\"{x:1284,y:591,t:1526930162259};\\\", \\\"{x:1284,y:588,t:1526930162276};\\\", \\\"{x:1283,y:587,t:1526930162292};\\\", \\\"{x:1281,y:585,t:1526930162309};\\\", \\\"{x:1281,y:583,t:1526930162332};\\\", \\\"{x:1281,y:582,t:1526930162348};\\\", \\\"{x:1281,y:580,t:1526930162364};\\\", \\\"{x:1282,y:578,t:1526930162380};\\\", \\\"{x:1282,y:575,t:1526930162397};\\\", \\\"{x:1284,y:574,t:1526930162409};\\\", \\\"{x:1285,y:573,t:1526930162425};\\\", \\\"{x:1285,y:570,t:1526930162443};\\\", \\\"{x:1285,y:568,t:1526930162459};\\\", \\\"{x:1287,y:567,t:1526930162476};\\\", \\\"{x:1288,y:567,t:1526930162492};\\\", \\\"{x:1290,y:565,t:1526930162516};\\\", \\\"{x:1291,y:563,t:1526930162556};\\\", \\\"{x:1292,y:563,t:1526930162564};\\\", \\\"{x:1293,y:561,t:1526930162577};\\\", \\\"{x:1293,y:560,t:1526930162604};\\\", \\\"{x:1294,y:559,t:1526930162620};\\\", \\\"{x:1295,y:558,t:1526930162652};\\\", \\\"{x:1297,y:556,t:1526930162708};\\\", \\\"{x:1297,y:555,t:1526930162724};\\\", \\\"{x:1298,y:555,t:1526930162732};\\\", \\\"{x:1299,y:553,t:1526930162748};\\\", \\\"{x:1300,y:551,t:1526930162764};\\\", \\\"{x:1300,y:550,t:1526930162777};\\\", \\\"{x:1301,y:549,t:1526930162793};\\\", \\\"{x:1301,y:548,t:1526930162809};\\\", \\\"{x:1301,y:546,t:1526930162827};\\\", \\\"{x:1302,y:546,t:1526930162844};\\\", \\\"{x:1302,y:545,t:1526930162860};\\\", \\\"{x:1304,y:543,t:1526930162877};\\\", \\\"{x:1304,y:542,t:1526930162916};\\\", \\\"{x:1303,y:541,t:1526930163108};\\\", \\\"{x:1301,y:541,t:1526930163116};\\\", \\\"{x:1297,y:541,t:1526930163128};\\\", \\\"{x:1292,y:541,t:1526930163144};\\\", \\\"{x:1287,y:540,t:1526930163161};\\\", \\\"{x:1285,y:540,t:1526930163178};\\\", \\\"{x:1285,y:539,t:1526930163340};\\\", \\\"{x:1286,y:538,t:1526930163356};\\\", \\\"{x:1289,y:536,t:1526930163364};\\\", \\\"{x:1292,y:535,t:1526930163378};\\\", \\\"{x:1294,y:534,t:1526930163394};\\\", \\\"{x:1299,y:532,t:1526930163412};\\\", \\\"{x:1303,y:531,t:1526930163428};\\\", \\\"{x:1306,y:529,t:1526930163445};\\\", \\\"{x:1309,y:528,t:1526930163462};\\\", \\\"{x:1313,y:526,t:1526930163478};\\\", \\\"{x:1315,y:525,t:1526930163495};\\\", \\\"{x:1318,y:523,t:1526930163512};\\\", \\\"{x:1321,y:521,t:1526930163529};\\\", \\\"{x:1324,y:518,t:1526930163545};\\\", \\\"{x:1327,y:517,t:1526930163562};\\\", \\\"{x:1328,y:516,t:1526930163578};\\\", \\\"{x:1331,y:514,t:1526930163595};\\\", \\\"{x:1333,y:512,t:1526930163611};\\\", \\\"{x:1335,y:510,t:1526930163629};\\\", \\\"{x:1337,y:510,t:1526930163644};\\\", \\\"{x:1339,y:508,t:1526930163661};\\\", \\\"{x:1343,y:505,t:1526930163679};\\\", \\\"{x:1344,y:504,t:1526930163696};\\\", \\\"{x:1346,y:502,t:1526930163711};\\\", \\\"{x:1348,y:502,t:1526930163729};\\\", \\\"{x:1352,y:499,t:1526930163745};\\\", \\\"{x:1354,y:497,t:1526930163762};\\\", \\\"{x:1357,y:495,t:1526930163779};\\\", \\\"{x:1361,y:492,t:1526930163796};\\\", \\\"{x:1362,y:491,t:1526930163813};\\\", \\\"{x:1364,y:488,t:1526930163829};\\\", \\\"{x:1366,y:487,t:1526930163846};\\\", \\\"{x:1370,y:484,t:1526930163863};\\\", \\\"{x:1374,y:483,t:1526930163879};\\\", \\\"{x:1376,y:481,t:1526930163896};\\\", \\\"{x:1379,y:479,t:1526930163913};\\\", \\\"{x:1382,y:476,t:1526930163929};\\\", \\\"{x:1385,y:475,t:1526930163946};\\\", \\\"{x:1385,y:474,t:1526930163963};\\\", \\\"{x:1388,y:471,t:1526930163980};\\\", \\\"{x:1391,y:470,t:1526930163996};\\\", \\\"{x:1392,y:468,t:1526930164013};\\\", \\\"{x:1395,y:466,t:1526930164030};\\\", \\\"{x:1397,y:465,t:1526930164045};\\\", \\\"{x:1399,y:464,t:1526930164063};\\\", \\\"{x:1400,y:463,t:1526930164084};\\\", \\\"{x:1400,y:462,t:1526930164097};\\\", \\\"{x:1402,y:459,t:1526930164113};\\\", \\\"{x:1405,y:456,t:1526930164130};\\\", \\\"{x:1409,y:455,t:1526930164147};\\\", \\\"{x:1409,y:454,t:1526930164163};\\\", \\\"{x:1410,y:454,t:1526930164180};\\\", \\\"{x:1408,y:454,t:1526930164252};\\\", \\\"{x:1406,y:454,t:1526930164264};\\\", \\\"{x:1404,y:454,t:1526930164284};\\\", \\\"{x:1403,y:455,t:1526930164300};\\\", \\\"{x:1402,y:455,t:1526930164380};\\\", \\\"{x:1401,y:455,t:1526930164397};\\\", \\\"{x:1400,y:457,t:1526930164461};\\\", \\\"{x:1399,y:457,t:1526930164524};\\\", \\\"{x:1398,y:458,t:1526930164588};\\\", \\\"{x:1397,y:458,t:1526930164812};\\\", \\\"{x:1396,y:459,t:1526930164820};\\\", \\\"{x:1396,y:460,t:1526930164831};\\\", \\\"{x:1394,y:462,t:1526930164848};\\\", \\\"{x:1393,y:462,t:1526930164864};\\\", \\\"{x:1393,y:463,t:1526930164882};\\\", \\\"{x:1391,y:463,t:1526930164924};\\\", \\\"{x:1390,y:463,t:1526930165156};\\\", \\\"{x:1386,y:462,t:1526930165166};\\\", \\\"{x:1374,y:457,t:1526930165182};\\\", \\\"{x:1366,y:455,t:1526930165199};\\\", \\\"{x:1352,y:454,t:1526930165216};\\\", \\\"{x:1325,y:454,t:1526930165232};\\\", \\\"{x:1292,y:454,t:1526930165249};\\\", \\\"{x:1245,y:454,t:1526930165266};\\\", \\\"{x:1154,y:465,t:1526930165283};\\\", \\\"{x:1052,y:475,t:1526930165299};\\\", \\\"{x:885,y:493,t:1526930165316};\\\", \\\"{x:836,y:510,t:1526930165333};\\\", \\\"{x:748,y:521,t:1526930165350};\\\", \\\"{x:688,y:534,t:1526930165367};\\\", \\\"{x:642,y:543,t:1526930165384};\\\", \\\"{x:603,y:555,t:1526930165400};\\\", \\\"{x:577,y:562,t:1526930165417};\\\", \\\"{x:565,y:572,t:1526930165433};\\\", \\\"{x:555,y:581,t:1526930165450};\\\", \\\"{x:547,y:592,t:1526930165465};\\\", \\\"{x:543,y:604,t:1526930165486};\\\", \\\"{x:537,y:623,t:1526930165499};\\\", \\\"{x:535,y:641,t:1526930165517};\\\", \\\"{x:531,y:659,t:1526930165533};\\\", \\\"{x:528,y:678,t:1526930165550};\\\", \\\"{x:524,y:691,t:1526930165566};\\\", \\\"{x:521,y:700,t:1526930165583};\\\", \\\"{x:521,y:708,t:1526930165599};\\\", \\\"{x:521,y:709,t:1526930165616};\\\", \\\"{x:520,y:711,t:1526930165633};\\\", \\\"{x:520,y:713,t:1526930165650};\\\", \\\"{x:520,y:715,t:1526930165668};\\\", \\\"{x:520,y:716,t:1526930165683};\\\", \\\"{x:519,y:720,t:1526930165700};\\\", \\\"{x:519,y:723,t:1526930165716};\\\", \\\"{x:518,y:725,t:1526930165733};\\\", \\\"{x:518,y:727,t:1526930165750};\\\", \\\"{x:517,y:730,t:1526930165767};\\\", \\\"{x:517,y:731,t:1526930165784};\\\", \\\"{x:516,y:734,t:1526930165800};\\\", \\\"{x:513,y:739,t:1526930165817};\\\", \\\"{x:512,y:742,t:1526930165834};\\\", \\\"{x:512,y:744,t:1526930165850};\\\", \\\"{x:512,y:745,t:1526930166100};\\\", \\\"{x:513,y:745,t:1526930166117};\\\", \\\"{x:518,y:745,t:1526930166133};\\\", \\\"{x:536,y:744,t:1526930166149};\\\", \\\"{x:559,y:744,t:1526930166166};\\\", \\\"{x:581,y:743,t:1526930166184};\\\", \\\"{x:604,y:742,t:1526930166200};\\\", \\\"{x:627,y:742,t:1526930166217};\\\", \\\"{x:647,y:740,t:1526930166233};\\\", \\\"{x:665,y:738,t:1526930166249};\\\", \\\"{x:679,y:732,t:1526930166266};\\\", \\\"{x:709,y:724,t:1526930166283};\\\", \\\"{x:720,y:723,t:1526930166300};\\\", \\\"{x:730,y:721,t:1526930166316};\\\", \\\"{x:743,y:718,t:1526930166333};\\\", \\\"{x:748,y:716,t:1526930166350};\\\", \\\"{x:751,y:715,t:1526930166367};\\\", \\\"{x:752,y:714,t:1526930166383};\\\", \\\"{x:754,y:714,t:1526930166400};\\\", \\\"{x:753,y:714,t:1526930166820};\\\", \\\"{x:752,y:714,t:1526930166844};\\\", \\\"{x:751,y:714,t:1526930166851};\\\", \\\"{x:750,y:715,t:1526930166868};\\\", \\\"{x:749,y:715,t:1526930166884};\\\", \\\"{x:748,y:715,t:1526930166900};\\\", \\\"{x:748,y:716,t:1526930166924};\\\", \\\"{x:748,y:721,t:1526930166934};\\\", \\\"{x:747,y:731,t:1526930166950};\\\", \\\"{x:747,y:738,t:1526930166967};\\\", \\\"{x:747,y:759,t:1526930167015};\\\", \\\"{x:747,y:763,t:1526930167020};\\\", \\\"{x:747,y:766,t:1526930167034};\\\", \\\"{x:750,y:776,t:1526930167051};\\\", \\\"{x:754,y:787,t:1526930167067};\\\", \\\"{x:756,y:793,t:1526930167083};\\\" ] }, { \\\"rt\\\": 12755, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 14, \\\"time_elapsed\\\": 531851, \\\"internal_node_id\\\": \\\"0.0-6.0-4.0\\\", \\\"subject\\\": \\\"GQ35Z\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"charlie\\\", \\\"condition\\\": \\\"111\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"ends\\\", \\\"q\\\": 10, \\\"clicks\\\": 1, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XInside-YFull\\\", \\\"correct\\\": 1, \\\"orth_correct\\\": 0, \\\"answer\\\": [ \\\"E\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-4\\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:757,y:797,t:1526930167254};\\\", \\\"{x:758,y:797,t:1526930167268};\\\", \\\"{x:759,y:798,t:1526930167300};\\\", \\\"{x:759,y:800,t:1526930167356};\\\", \\\"{x:762,y:800,t:1526930167368};\\\", \\\"{x:766,y:802,t:1526930167384};\\\", \\\"{x:768,y:804,t:1526930167400};\\\", \\\"{x:772,y:807,t:1526930167418};\\\", \\\"{x:774,y:807,t:1526930167451};\\\", \\\"{x:677,y:776,t:1526930168125};\\\", \\\"{x:677,y:776,t:1526930168221};\\\", \\\"{x:675,y:776,t:1526930168532};\\\", \\\"{x:675,y:773,t:1526930169084};\\\", \\\"{x:677,y:772,t:1526930169100};\\\", \\\"{x:678,y:771,t:1526930169107};\\\", \\\"{x:681,y:771,t:1526930169124};\\\", \\\"{x:682,y:771,t:1526930169136};\\\", \\\"{x:689,y:771,t:1526930169152};\\\", \\\"{x:695,y:771,t:1526930169169};\\\", \\\"{x:702,y:771,t:1526930169186};\\\", \\\"{x:710,y:771,t:1526930169202};\\\", \\\"{x:713,y:771,t:1526930169218};\\\", \\\"{x:720,y:771,t:1526930169235};\\\", \\\"{x:724,y:771,t:1526930169253};\\\", \\\"{x:731,y:771,t:1526930169269};\\\", \\\"{x:740,y:771,t:1526930169286};\\\", \\\"{x:743,y:771,t:1526930169303};\\\", \\\"{x:746,y:771,t:1526930169319};\\\", \\\"{x:748,y:771,t:1526930169452};\\\", \\\"{x:748,y:770,t:1526930169459};\\\", \\\"{x:750,y:769,t:1526930169475};\\\", \\\"{x:751,y:769,t:1526930169492};\\\", \\\"{x:753,y:768,t:1526930169503};\\\", \\\"{x:755,y:767,t:1526930169519};\\\", \\\"{x:761,y:765,t:1526930169536};\\\", \\\"{x:767,y:764,t:1526930169553};\\\", \\\"{x:778,y:760,t:1526930169569};\\\", \\\"{x:792,y:756,t:1526930169586};\\\", \\\"{x:802,y:753,t:1526930169603};\\\", \\\"{x:826,y:744,t:1526930169619};\\\", \\\"{x:857,y:732,t:1526930169636};\\\", \\\"{x:879,y:723,t:1526930169653};\\\", \\\"{x:898,y:716,t:1526930169669};\\\", \\\"{x:909,y:712,t:1526930169686};\\\", \\\"{x:925,y:708,t:1526930169703};\\\", \\\"{x:940,y:706,t:1526930169719};\\\", \\\"{x:953,y:703,t:1526930169736};\\\", \\\"{x:963,y:702,t:1526930169754};\\\", \\\"{x:977,y:699,t:1526930169769};\\\", \\\"{x:988,y:698,t:1526930169787};\\\", \\\"{x:1002,y:697,t:1526930169804};\\\", \\\"{x:1014,y:697,t:1526930169821};\\\", \\\"{x:1016,y:697,t:1526930169837};\\\", \\\"{x:1022,y:697,t:1526930169853};\\\", \\\"{x:1033,y:697,t:1526930169870};\\\", \\\"{x:1044,y:697,t:1526930169886};\\\", \\\"{x:1052,y:697,t:1526930169903};\\\", \\\"{x:1061,y:697,t:1526930169920};\\\", \\\"{x:1071,y:698,t:1526930169937};\\\", \\\"{x:1088,y:700,t:1526930169953};\\\", \\\"{x:1103,y:705,t:1526930169970};\\\", \\\"{x:1120,y:709,t:1526930169986};\\\", \\\"{x:1133,y:709,t:1526930170003};\\\", \\\"{x:1147,y:709,t:1526930170020};\\\", \\\"{x:1157,y:709,t:1526930170036};\\\", \\\"{x:1165,y:709,t:1526930170053};\\\", \\\"{x:1178,y:710,t:1526930170070};\\\", \\\"{x:1189,y:711,t:1526930170086};\\\", \\\"{x:1207,y:714,t:1526930170103};\\\", \\\"{x:1217,y:716,t:1526930170120};\\\", \\\"{x:1226,y:716,t:1526930170136};\\\", \\\"{x:1229,y:717,t:1526930170153};\\\", \\\"{x:1235,y:717,t:1526930170170};\\\", \\\"{x:1241,y:718,t:1526930170187};\\\", \\\"{x:1251,y:719,t:1526930170203};\\\", \\\"{x:1264,y:720,t:1526930170220};\\\", \\\"{x:1272,y:722,t:1526930170237};\\\", \\\"{x:1279,y:722,t:1526930170254};\\\", \\\"{x:1281,y:722,t:1526930170271};\\\", \\\"{x:1283,y:722,t:1526930170286};\\\", \\\"{x:1286,y:722,t:1526930170304};\\\", \\\"{x:1291,y:722,t:1526930170321};\\\", \\\"{x:1294,y:722,t:1526930170337};\\\", \\\"{x:1297,y:722,t:1526930170353};\\\", \\\"{x:1300,y:722,t:1526930170370};\\\", \\\"{x:1303,y:722,t:1526930170387};\\\", \\\"{x:1305,y:722,t:1526930170403};\\\", \\\"{x:1310,y:722,t:1526930170421};\\\", \\\"{x:1315,y:722,t:1526930170437};\\\", \\\"{x:1318,y:722,t:1526930170454};\\\", \\\"{x:1323,y:722,t:1526930170471};\\\", \\\"{x:1324,y:722,t:1526930170488};\\\", \\\"{x:1325,y:722,t:1526930170503};\\\", \\\"{x:1326,y:722,t:1526930170520};\\\", \\\"{x:1326,y:720,t:1526930170564};\\\", \\\"{x:1326,y:717,t:1526930170572};\\\", \\\"{x:1325,y:716,t:1526930170587};\\\", \\\"{x:1324,y:715,t:1526930170766};\\\", \\\"{x:1323,y:715,t:1526930170821};\\\", \\\"{x:1322,y:715,t:1526930170853};\\\", \\\"{x:1321,y:715,t:1526930170861};\\\", \\\"{x:1319,y:715,t:1526930171244};\\\", \\\"{x:1317,y:715,t:1526930171254};\\\", \\\"{x:1314,y:715,t:1526930171271};\\\", \\\"{x:1311,y:715,t:1526930171287};\\\", \\\"{x:1310,y:715,t:1526930171396};\\\", \\\"{x:1309,y:715,t:1526930171404};\\\", \\\"{x:1305,y:715,t:1526930171421};\\\", \\\"{x:1303,y:714,t:1526930171437};\\\", \\\"{x:1298,y:714,t:1526930171455};\\\", \\\"{x:1293,y:714,t:1526930171472};\\\", \\\"{x:1291,y:714,t:1526930171487};\\\", \\\"{x:1288,y:714,t:1526930171505};\\\", \\\"{x:1287,y:714,t:1526930171533};\\\", \\\"{x:1285,y:714,t:1526930171557};\\\", \\\"{x:1284,y:714,t:1526930171622};\\\", \\\"{x:1286,y:713,t:1526930172245};\\\", \\\"{x:1287,y:712,t:1526930172255};\\\", \\\"{x:1290,y:711,t:1526930172273};\\\", \\\"{x:1292,y:709,t:1526930172289};\\\", \\\"{x:1294,y:709,t:1526930172305};\\\", \\\"{x:1296,y:709,t:1526930172322};\\\", \\\"{x:1298,y:709,t:1526930172341};\\\", \\\"{x:1299,y:708,t:1526930172356};\\\", \\\"{x:1300,y:708,t:1526930172376};\\\", \\\"{x:1302,y:707,t:1526930172457};\\\", \\\"{x:1305,y:706,t:1526930172473};\\\", \\\"{x:1309,y:704,t:1526930172481};\\\", \\\"{x:1310,y:703,t:1526930172497};\\\", \\\"{x:1312,y:702,t:1526930172554};\\\", \\\"{x:1313,y:702,t:1526930172561};\\\", \\\"{x:1316,y:702,t:1526930172576};\\\", \\\"{x:1323,y:701,t:1526930172593};\\\", \\\"{x:1327,y:701,t:1526930172609};\\\", \\\"{x:1330,y:701,t:1526930172705};\\\", \\\"{x:1333,y:701,t:1526930172721};\\\", \\\"{x:1335,y:701,t:1526930172729};\\\", \\\"{x:1336,y:701,t:1526930172744};\\\", \\\"{x:1338,y:702,t:1526930172760};\\\", \\\"{x:1340,y:702,t:1526930172777};\\\", \\\"{x:1341,y:702,t:1526930172873};\\\", \\\"{x:1344,y:704,t:1526930172881};\\\", \\\"{x:1344,y:705,t:1526930172905};\\\", \\\"{x:1345,y:706,t:1526930172921};\\\", \\\"{x:1346,y:707,t:1526930172929};\\\", \\\"{x:1347,y:707,t:1526930172943};\\\", \\\"{x:1350,y:711,t:1526930172960};\\\", \\\"{x:1354,y:716,t:1526930172977};\\\", \\\"{x:1359,y:719,t:1526930172994};\\\", \\\"{x:1362,y:721,t:1526930173011};\\\", \\\"{x:1364,y:723,t:1526930173027};\\\", \\\"{x:1365,y:724,t:1526930173043};\\\", \\\"{x:1366,y:726,t:1526930173060};\\\", \\\"{x:1366,y:727,t:1526930173077};\\\", \\\"{x:1368,y:730,t:1526930173094};\\\", \\\"{x:1368,y:732,t:1526930173110};\\\", \\\"{x:1369,y:733,t:1526930173127};\\\", \\\"{x:1371,y:735,t:1526930173144};\\\", \\\"{x:1372,y:736,t:1526930173161};\\\", \\\"{x:1363,y:731,t:1526930173385};\\\", \\\"{x:1351,y:725,t:1526930173393};\\\", \\\"{x:1342,y:718,t:1526930173410};\\\", \\\"{x:1340,y:717,t:1526930173427};\\\", \\\"{x:1340,y:716,t:1526930173465};\\\", \\\"{x:1340,y:713,t:1526930173585};\\\", \\\"{x:1340,y:712,t:1526930173594};\\\", \\\"{x:1335,y:707,t:1526930173611};\\\", \\\"{x:1325,y:698,t:1526930173627};\\\", \\\"{x:1309,y:687,t:1526930173644};\\\", \\\"{x:1293,y:679,t:1526930173661};\\\", \\\"{x:1277,y:672,t:1526930173677};\\\", \\\"{x:1262,y:665,t:1526930173694};\\\", \\\"{x:1245,y:660,t:1526930173711};\\\", \\\"{x:1226,y:653,t:1526930173727};\\\", \\\"{x:1202,y:648,t:1526930173744};\\\", \\\"{x:1180,y:645,t:1526930173761};\\\", \\\"{x:1166,y:643,t:1526930173777};\\\", \\\"{x:1157,y:643,t:1526930173795};\\\", \\\"{x:1145,y:643,t:1526930173811};\\\", \\\"{x:1133,y:643,t:1526930173827};\\\", \\\"{x:1114,y:645,t:1526930173845};\\\", \\\"{x:1092,y:645,t:1526930173861};\\\", \\\"{x:1069,y:645,t:1526930173877};\\\", \\\"{x:1038,y:645,t:1526930173894};\\\", \\\"{x:999,y:645,t:1526930173911};\\\", \\\"{x:937,y:645,t:1526930173927};\\\", \\\"{x:879,y:645,t:1526930173944};\\\", \\\"{x:796,y:648,t:1526930173960};\\\", \\\"{x:741,y:642,t:1526930173977};\\\", \\\"{x:690,y:640,t:1526930173994};\\\", \\\"{x:654,y:636,t:1526930174011};\\\", \\\"{x:634,y:632,t:1526930174028};\\\", \\\"{x:612,y:630,t:1526930174044};\\\", \\\"{x:598,y:629,t:1526930174060};\\\", \\\"{x:592,y:629,t:1526930174077};\\\", \\\"{x:586,y:629,t:1526930174093};\\\", \\\"{x:578,y:629,t:1526930174110};\\\", \\\"{x:574,y:627,t:1526930174127};\\\", \\\"{x:567,y:627,t:1526930174143};\\\", \\\"{x:550,y:626,t:1526930174159};\\\", \\\"{x:532,y:626,t:1526930174177};\\\", \\\"{x:514,y:624,t:1526930174193};\\\", \\\"{x:492,y:622,t:1526930174211};\\\", \\\"{x:470,y:621,t:1526930174226};\\\", \\\"{x:450,y:619,t:1526930174245};\\\", \\\"{x:426,y:614,t:1526930174260};\\\", \\\"{x:405,y:611,t:1526930174278};\\\", \\\"{x:382,y:607,t:1526930174294};\\\", \\\"{x:365,y:604,t:1526930174311};\\\", \\\"{x:353,y:600,t:1526930174328};\\\", \\\"{x:341,y:597,t:1526930174344};\\\", \\\"{x:334,y:595,t:1526930174361};\\\", \\\"{x:325,y:593,t:1526930174378};\\\", \\\"{x:319,y:591,t:1526930174394};\\\", \\\"{x:313,y:589,t:1526930174412};\\\", \\\"{x:309,y:587,t:1526930174428};\\\", \\\"{x:305,y:585,t:1526930174445};\\\", \\\"{x:302,y:583,t:1526930174462};\\\", \\\"{x:299,y:582,t:1526930174477};\\\", \\\"{x:292,y:578,t:1526930174495};\\\", \\\"{x:286,y:575,t:1526930174512};\\\", \\\"{x:275,y:572,t:1526930174528};\\\", \\\"{x:266,y:570,t:1526930174545};\\\", \\\"{x:261,y:567,t:1526930174561};\\\", \\\"{x:255,y:567,t:1526930174578};\\\", \\\"{x:252,y:564,t:1526930174595};\\\", \\\"{x:246,y:563,t:1526930174612};\\\", \\\"{x:236,y:562,t:1526930174629};\\\", \\\"{x:228,y:558,t:1526930174644};\\\", \\\"{x:225,y:558,t:1526930174662};\\\", \\\"{x:224,y:557,t:1526930174677};\\\", \\\"{x:224,y:556,t:1526930174728};\\\", \\\"{x:224,y:553,t:1526930174744};\\\", \\\"{x:226,y:550,t:1526930174761};\\\", \\\"{x:234,y:548,t:1526930174777};\\\", \\\"{x:242,y:545,t:1526930174794};\\\", \\\"{x:247,y:543,t:1526930174811};\\\", \\\"{x:256,y:543,t:1526930174828};\\\", \\\"{x:270,y:542,t:1526930174844};\\\", \\\"{x:278,y:542,t:1526930174862};\\\", \\\"{x:286,y:540,t:1526930174877};\\\", \\\"{x:299,y:540,t:1526930174894};\\\", \\\"{x:310,y:540,t:1526930174911};\\\", \\\"{x:335,y:540,t:1526930174928};\\\", \\\"{x:347,y:540,t:1526930174945};\\\", \\\"{x:361,y:540,t:1526930174961};\\\", \\\"{x:373,y:540,t:1526930174979};\\\", \\\"{x:395,y:539,t:1526930174995};\\\", \\\"{x:416,y:539,t:1526930175012};\\\", \\\"{x:442,y:538,t:1526930175029};\\\", \\\"{x:469,y:537,t:1526930175044};\\\", \\\"{x:489,y:533,t:1526930175061};\\\", \\\"{x:505,y:532,t:1526930175080};\\\", \\\"{x:514,y:530,t:1526930175094};\\\", \\\"{x:523,y:529,t:1526930175112};\\\", \\\"{x:539,y:527,t:1526930175129};\\\", \\\"{x:548,y:524,t:1526930175145};\\\", \\\"{x:560,y:523,t:1526930175161};\\\", \\\"{x:569,y:522,t:1526930175178};\\\", \\\"{x:572,y:522,t:1526930175196};\\\", \\\"{x:573,y:522,t:1526930175212};\\\", \\\"{x:580,y:520,t:1526930175229};\\\", \\\"{x:584,y:520,t:1526930175245};\\\", \\\"{x:585,y:519,t:1526930175262};\\\", \\\"{x:586,y:518,t:1526930175337};\\\", \\\"{x:587,y:516,t:1526930175380};\\\", \\\"{x:588,y:516,t:1526930175416};\\\", \\\"{x:589,y:515,t:1526930175428};\\\", \\\"{x:590,y:515,t:1526930175446};\\\", \\\"{x:594,y:513,t:1526930175462};\\\", \\\"{x:601,y:512,t:1526930175479};\\\", \\\"{x:605,y:511,t:1526930175495};\\\", \\\"{x:606,y:510,t:1526930175511};\\\", \\\"{x:607,y:510,t:1526930175528};\\\", \\\"{x:608,y:510,t:1526930175952};\\\", \\\"{x:612,y:510,t:1526930175962};\\\", \\\"{x:621,y:512,t:1526930175979};\\\", \\\"{x:637,y:517,t:1526930175995};\\\", \\\"{x:661,y:523,t:1526930176013};\\\", \\\"{x:678,y:531,t:1526930176030};\\\", \\\"{x:698,y:543,t:1526930176045};\\\", \\\"{x:729,y:552,t:1526930176063};\\\", \\\"{x:765,y:562,t:1526930176080};\\\", \\\"{x:798,y:574,t:1526930176096};\\\", \\\"{x:834,y:589,t:1526930176113};\\\", \\\"{x:877,y:602,t:1526930176130};\\\", \\\"{x:890,y:608,t:1526930176145};\\\", \\\"{x:917,y:618,t:1526930176162};\\\", \\\"{x:936,y:624,t:1526930176179};\\\", \\\"{x:963,y:631,t:1526930176196};\\\", \\\"{x:982,y:641,t:1526930176213};\\\", \\\"{x:1003,y:649,t:1526930176230};\\\", \\\"{x:1026,y:658,t:1526930176246};\\\", \\\"{x:1046,y:665,t:1526930176263};\\\", \\\"{x:1065,y:670,t:1526930176280};\\\", \\\"{x:1084,y:676,t:1526930176296};\\\", \\\"{x:1116,y:686,t:1526930176313};\\\", \\\"{x:1132,y:691,t:1526930176330};\\\", \\\"{x:1150,y:694,t:1526930176345};\\\", \\\"{x:1164,y:696,t:1526930176362};\\\", \\\"{x:1178,y:697,t:1526930176380};\\\", \\\"{x:1199,y:702,t:1526930176396};\\\", \\\"{x:1216,y:703,t:1526930176412};\\\", \\\"{x:1228,y:705,t:1526930176430};\\\", \\\"{x:1244,y:706,t:1526930176446};\\\", \\\"{x:1258,y:708,t:1526930176463};\\\", \\\"{x:1267,y:710,t:1526930176479};\\\", \\\"{x:1273,y:710,t:1526930176496};\\\", \\\"{x:1282,y:710,t:1526930176513};\\\", \\\"{x:1292,y:710,t:1526930176530};\\\", \\\"{x:1303,y:710,t:1526930176547};\\\", \\\"{x:1321,y:710,t:1526930176563};\\\", \\\"{x:1337,y:710,t:1526930176580};\\\", \\\"{x:1351,y:710,t:1526930176597};\\\", \\\"{x:1362,y:710,t:1526930176613};\\\", \\\"{x:1371,y:710,t:1526930176630};\\\", \\\"{x:1374,y:710,t:1526930176647};\\\", \\\"{x:1374,y:711,t:1526930176793};\\\", \\\"{x:1374,y:712,t:1526930176808};\\\", \\\"{x:1373,y:713,t:1526930176841};\\\", \\\"{x:1372,y:713,t:1526930176865};\\\", \\\"{x:1371,y:713,t:1526930176881};\\\", \\\"{x:1370,y:713,t:1526930176929};\\\", \\\"{x:1369,y:714,t:1526930176948};\\\", \\\"{x:1368,y:714,t:1526930177001};\\\", \\\"{x:1367,y:715,t:1526930177025};\\\", \\\"{x:1366,y:715,t:1526930177089};\\\", \\\"{x:1365,y:716,t:1526930177097};\\\", \\\"{x:1364,y:717,t:1526930177137};\\\", \\\"{x:1363,y:717,t:1526930177288};\\\", \\\"{x:1362,y:717,t:1526930177321};\\\", \\\"{x:1359,y:720,t:1526930177874};\\\", \\\"{x:1358,y:720,t:1526930177897};\\\", \\\"{x:1356,y:720,t:1526930177914};\\\", \\\"{x:1355,y:720,t:1526930177931};\\\", \\\"{x:1350,y:720,t:1526930177949};\\\", \\\"{x:1347,y:720,t:1526930177964};\\\", \\\"{x:1329,y:719,t:1526930177981};\\\", \\\"{x:1312,y:717,t:1526930177998};\\\", \\\"{x:1304,y:717,t:1526930178014};\\\", \\\"{x:1303,y:717,t:1526930178031};\\\", \\\"{x:1302,y:717,t:1526930178049};\\\", \\\"{x:1301,y:717,t:1526930178064};\\\", \\\"{x:1298,y:717,t:1526930178081};\\\", \\\"{x:1296,y:717,t:1526930178098};\\\", \\\"{x:1291,y:717,t:1526930178114};\\\", \\\"{x:1285,y:717,t:1526930178131};\\\", \\\"{x:1282,y:717,t:1526930178148};\\\", \\\"{x:1277,y:717,t:1526930178165};\\\", \\\"{x:1273,y:717,t:1526930178181};\\\", \\\"{x:1270,y:717,t:1526930178198};\\\", \\\"{x:1266,y:717,t:1526930178214};\\\", \\\"{x:1265,y:717,t:1526930178231};\\\", \\\"{x:1261,y:717,t:1526930178248};\\\", \\\"{x:1259,y:717,t:1526930178265};\\\", \\\"{x:1256,y:717,t:1526930178281};\\\", \\\"{x:1255,y:717,t:1526930178298};\\\", \\\"{x:1253,y:717,t:1526930178315};\\\", \\\"{x:1251,y:717,t:1526930178331};\\\", \\\"{x:1249,y:717,t:1526930178348};\\\", \\\"{x:1247,y:717,t:1526930178365};\\\", \\\"{x:1246,y:718,t:1526930178381};\\\", \\\"{x:1244,y:718,t:1526930178398};\\\", \\\"{x:1240,y:718,t:1526930178415};\\\", \\\"{x:1239,y:719,t:1526930178431};\\\", \\\"{x:1237,y:719,t:1526930178448};\\\", \\\"{x:1236,y:719,t:1526930178473};\\\", \\\"{x:1234,y:720,t:1526930178481};\\\", \\\"{x:1233,y:720,t:1526930178498};\\\", \\\"{x:1232,y:720,t:1526930178515};\\\", \\\"{x:1231,y:720,t:1526930178532};\\\", \\\"{x:1230,y:720,t:1526930178569};\\\", \\\"{x:1228,y:720,t:1526930178754};\\\", \\\"{x:1223,y:720,t:1526930178765};\\\", \\\"{x:1212,y:718,t:1526930178782};\\\", \\\"{x:1194,y:715,t:1526930178798};\\\", \\\"{x:1162,y:709,t:1526930178815};\\\", \\\"{x:1116,y:705,t:1526930178832};\\\", \\\"{x:1075,y:705,t:1526930178848};\\\", \\\"{x:1062,y:706,t:1526930178865};\\\", \\\"{x:1040,y:711,t:1526930178882};\\\", \\\"{x:1016,y:718,t:1526930178898};\\\", \\\"{x:999,y:724,t:1526930178916};\\\", \\\"{x:972,y:737,t:1526930178933};\\\", \\\"{x:935,y:756,t:1526930178948};\\\", \\\"{x:902,y:769,t:1526930178965};\\\", \\\"{x:858,y:786,t:1526930178983};\\\", \\\"{x:802,y:806,t:1526930178999};\\\", \\\"{x:771,y:816,t:1526930179015};\\\", \\\"{x:729,y:820,t:1526930179032};\\\", \\\"{x:694,y:821,t:1526930179048};\\\", \\\"{x:643,y:822,t:1526930179065};\\\", \\\"{x:626,y:822,t:1526930179082};\\\", \\\"{x:615,y:822,t:1526930179099};\\\", \\\"{x:602,y:822,t:1526930179115};\\\", \\\"{x:597,y:820,t:1526930179132};\\\", \\\"{x:593,y:819,t:1526930179149};\\\", \\\"{x:589,y:817,t:1526930179165};\\\", \\\"{x:588,y:817,t:1526930179182};\\\", \\\"{x:587,y:817,t:1526930179208};\\\", \\\"{x:586,y:817,t:1526930179217};\\\", \\\"{x:585,y:817,t:1526930179232};\\\", \\\"{x:579,y:815,t:1526930179249};\\\", \\\"{x:573,y:813,t:1526930179265};\\\", \\\"{x:566,y:809,t:1526930179282};\\\", \\\"{x:560,y:809,t:1526930179299};\\\", \\\"{x:556,y:807,t:1526930179315};\\\", \\\"{x:549,y:805,t:1526930179332};\\\", \\\"{x:543,y:804,t:1526930179349};\\\", \\\"{x:540,y:803,t:1526930179365};\\\", \\\"{x:536,y:801,t:1526930179382};\\\", \\\"{x:527,y:799,t:1526930179399};\\\", \\\"{x:519,y:796,t:1526930179415};\\\", \\\"{x:513,y:794,t:1526930179432};\\\", \\\"{x:507,y:789,t:1526930179449};\\\", \\\"{x:503,y:788,t:1526930179466};\\\", \\\"{x:499,y:786,t:1526930179482};\\\", \\\"{x:495,y:785,t:1526930179499};\\\", \\\"{x:492,y:783,t:1526930179516};\\\", \\\"{x:486,y:779,t:1526930179532};\\\", \\\"{x:479,y:776,t:1526930179549};\\\", \\\"{x:473,y:774,t:1526930179566};\\\", \\\"{x:471,y:772,t:1526930179582};\\\", \\\"{x:468,y:769,t:1526930179599};\\\", \\\"{x:464,y:761,t:1526930179616};\\\", \\\"{x:464,y:750,t:1526930179634};\\\", \\\"{x:470,y:742,t:1526930179649};\\\", \\\"{x:477,y:739,t:1526930179665};\\\", \\\"{x:479,y:738,t:1526930179682};\\\", \\\"{x:480,y:738,t:1526930179699};\\\", \\\"{x:481,y:738,t:1526930179716};\\\", \\\"{x:483,y:738,t:1526930180144};\\\", \\\"{x:488,y:738,t:1526930180152};\\\", \\\"{x:493,y:738,t:1526930180166};\\\", \\\"{x:507,y:738,t:1526930180183};\\\", \\\"{x:521,y:738,t:1526930180199};\\\", \\\"{x:535,y:739,t:1526930180215};\\\", \\\"{x:545,y:742,t:1526930180232};\\\", \\\"{x:554,y:744,t:1526930180248};\\\", \\\"{x:562,y:745,t:1526930180265};\\\", \\\"{x:567,y:747,t:1526930180283};\\\", \\\"{x:569,y:747,t:1526930180769};\\\", \\\"{x:571,y:747,t:1526930180801};\\\", \\\"{x:572,y:747,t:1526930180816};\\\", \\\"{x:581,y:747,t:1526930180832};\\\", \\\"{x:589,y:747,t:1526930180850};\\\", \\\"{x:599,y:747,t:1526930180866};\\\", \\\"{x:611,y:747,t:1526930180883};\\\", \\\"{x:623,y:747,t:1526930180899};\\\", \\\"{x:634,y:749,t:1526930180916};\\\", \\\"{x:641,y:752,t:1526930180933};\\\", \\\"{x:653,y:754,t:1526930180950};\\\", \\\"{x:666,y:758,t:1526930180967};\\\", \\\"{x:679,y:761,t:1526930180983};\\\", \\\"{x:699,y:769,t:1526930181001};\\\", \\\"{x:710,y:772,t:1526930181016};\\\", \\\"{x:742,y:782,t:1526930181076};\\\", \\\"{x:748,y:784,t:1526930181083};\\\", \\\"{x:767,y:791,t:1526930181099};\\\", \\\"{x:781,y:797,t:1526930181117};\\\", \\\"{x:792,y:801,t:1526930181132};\\\", \\\"{x:803,y:803,t:1526930181149};\\\" ] }, { \\\"rt\\\": 10497, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 15, \\\"time_elapsed\\\": 543588, \\\"internal_node_id\\\": \\\"0.0-6.0-5.0\\\", \\\"subject\\\": \\\"GQ35Z\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"charlie\\\", \\\"condition\\\": \\\"111\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"starttime\\\", \\\"q\\\": 11, \\\"clicks\\\": 2.5, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XInside-YFull\\\", \\\"correct\\\": 1, \\\"orth_correct\\\": 0, \\\"answer\\\": [ \\\"M\\\", \\\"L\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-11 AM-M \\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:819,y:806,t:1526930181248};\\\", \\\"{x:820,y:806,t:1526930181609};\\\", \\\"{x:738,y:790,t:1526930182212};\\\", \\\"{x:738,y:790,t:1526930182337};\\\", \\\"{x:737,y:789,t:1526930182553};\\\", \\\"{x:751,y:792,t:1526930182569};\\\", \\\"{x:775,y:801,t:1526930182585};\\\", \\\"{x:799,y:809,t:1526930182601};\\\", \\\"{x:837,y:820,t:1526930182618};\\\", \\\"{x:883,y:829,t:1526930182635};\\\", \\\"{x:907,y:835,t:1526930182651};\\\", \\\"{x:927,y:843,t:1526930182668};\\\", \\\"{x:942,y:848,t:1526930182685};\\\", \\\"{x:960,y:855,t:1526930182701};\\\", \\\"{x:981,y:861,t:1526930182719};\\\", \\\"{x:996,y:868,t:1526930182735};\\\", \\\"{x:1012,y:876,t:1526930182751};\\\", \\\"{x:1033,y:887,t:1526930182769};\\\", \\\"{x:1042,y:890,t:1526930182785};\\\", \\\"{x:1048,y:896,t:1526930182801};\\\", \\\"{x:1056,y:906,t:1526930182818};\\\", \\\"{x:1062,y:914,t:1526930182836};\\\", \\\"{x:1068,y:924,t:1526930182851};\\\", \\\"{x:1078,y:932,t:1526930182869};\\\", \\\"{x:1088,y:944,t:1526930182885};\\\", \\\"{x:1100,y:958,t:1526930182901};\\\", \\\"{x:1109,y:972,t:1526930182918};\\\", \\\"{x:1114,y:980,t:1526930182935};\\\", \\\"{x:1115,y:985,t:1526930182951};\\\", \\\"{x:1115,y:986,t:1526930182968};\\\", \\\"{x:1115,y:988,t:1526930182984};\\\", \\\"{x:1115,y:990,t:1526930183009};\\\", \\\"{x:1116,y:994,t:1526930183018};\\\", \\\"{x:1116,y:995,t:1526930183036};\\\", \\\"{x:1116,y:997,t:1526930183051};\\\", \\\"{x:1116,y:998,t:1526930183069};\\\", \\\"{x:1116,y:1001,t:1526930183086};\\\", \\\"{x:1116,y:1002,t:1526930183101};\\\", \\\"{x:1117,y:1002,t:1526930183377};\\\", \\\"{x:1121,y:1002,t:1526930183385};\\\", \\\"{x:1128,y:1002,t:1526930183402};\\\", \\\"{x:1136,y:1002,t:1526930183419};\\\", \\\"{x:1142,y:1002,t:1526930183435};\\\", \\\"{x:1148,y:1002,t:1526930183452};\\\", \\\"{x:1155,y:1002,t:1526930183469};\\\", \\\"{x:1159,y:1002,t:1526930183485};\\\", \\\"{x:1163,y:1002,t:1526930183502};\\\", \\\"{x:1166,y:1003,t:1526930183518};\\\", \\\"{x:1171,y:1003,t:1526930183536};\\\", \\\"{x:1173,y:1003,t:1526930183553};\\\", \\\"{x:1176,y:1003,t:1526930183569};\\\", \\\"{x:1183,y:1003,t:1526930183585};\\\", \\\"{x:1194,y:1003,t:1526930183602};\\\", \\\"{x:1200,y:1003,t:1526930183619};\\\", \\\"{x:1212,y:1003,t:1526930183636};\\\", \\\"{x:1224,y:1003,t:1526930183653};\\\", \\\"{x:1236,y:1005,t:1526930183670};\\\", \\\"{x:1247,y:1005,t:1526930183685};\\\", \\\"{x:1256,y:1005,t:1526930183702};\\\", \\\"{x:1263,y:1005,t:1526930183719};\\\", \\\"{x:1268,y:1004,t:1526930183735};\\\", \\\"{x:1273,y:1001,t:1526930183752};\\\", \\\"{x:1286,y:993,t:1526930183768};\\\", \\\"{x:1293,y:987,t:1526930183786};\\\", \\\"{x:1297,y:984,t:1526930183802};\\\", \\\"{x:1301,y:980,t:1526930183819};\\\", \\\"{x:1307,y:974,t:1526930183836};\\\", \\\"{x:1312,y:968,t:1526930183852};\\\", \\\"{x:1318,y:963,t:1526930183870};\\\", \\\"{x:1324,y:958,t:1526930183885};\\\", \\\"{x:1329,y:954,t:1526930183902};\\\", \\\"{x:1336,y:951,t:1526930183920};\\\", \\\"{x:1337,y:950,t:1526930183936};\\\", \\\"{x:1339,y:950,t:1526930183953};\\\", \\\"{x:1340,y:949,t:1526930183970};\\\", \\\"{x:1342,y:948,t:1526930183985};\\\", \\\"{x:1345,y:947,t:1526930184009};\\\", \\\"{x:1347,y:946,t:1526930184019};\\\", \\\"{x:1350,y:946,t:1526930184036};\\\", \\\"{x:1353,y:945,t:1526930184052};\\\", \\\"{x:1353,y:944,t:1526930184069};\\\", \\\"{x:1354,y:943,t:1526930184087};\\\", \\\"{x:1355,y:943,t:1526930184104};\\\", \\\"{x:1356,y:943,t:1526930184119};\\\", \\\"{x:1360,y:939,t:1526930184136};\\\", \\\"{x:1363,y:936,t:1526930184152};\\\", \\\"{x:1364,y:935,t:1526930184169};\\\", \\\"{x:1364,y:934,t:1526930184186};\\\", \\\"{x:1365,y:931,t:1526930184202};\\\", \\\"{x:1367,y:930,t:1526930184219};\\\", \\\"{x:1369,y:928,t:1526930184236};\\\", \\\"{x:1370,y:927,t:1526930184252};\\\", \\\"{x:1371,y:926,t:1526930184269};\\\", \\\"{x:1372,y:924,t:1526930184286};\\\", \\\"{x:1372,y:922,t:1526930184302};\\\", \\\"{x:1374,y:921,t:1526930184319};\\\", \\\"{x:1375,y:919,t:1526930184336};\\\", \\\"{x:1376,y:918,t:1526930184353};\\\", \\\"{x:1376,y:916,t:1526930184369};\\\", \\\"{x:1377,y:915,t:1526930184386};\\\", \\\"{x:1380,y:912,t:1526930184402};\\\", \\\"{x:1380,y:910,t:1526930184419};\\\", \\\"{x:1382,y:908,t:1526930184436};\\\", \\\"{x:1382,y:906,t:1526930184457};\\\", \\\"{x:1382,y:905,t:1526930184470};\\\", \\\"{x:1382,y:904,t:1526930184649};\\\", \\\"{x:1381,y:902,t:1526930184659};\\\", \\\"{x:1378,y:901,t:1526930184669};\\\", \\\"{x:1371,y:899,t:1526930184686};\\\", \\\"{x:1360,y:897,t:1526930184702};\\\", \\\"{x:1351,y:896,t:1526930184719};\\\", \\\"{x:1325,y:895,t:1526930184736};\\\", \\\"{x:1296,y:890,t:1526930184753};\\\", \\\"{x:1243,y:882,t:1526930184769};\\\", \\\"{x:1153,y:860,t:1526930184786};\\\", \\\"{x:1047,y:840,t:1526930184803};\\\", \\\"{x:945,y:818,t:1526930184819};\\\", \\\"{x:867,y:794,t:1526930184835};\\\", \\\"{x:827,y:781,t:1526930184852};\\\", \\\"{x:794,y:773,t:1526930184869};\\\", \\\"{x:771,y:764,t:1526930184886};\\\", \\\"{x:751,y:755,t:1526930184903};\\\", \\\"{x:733,y:747,t:1526930184919};\\\", \\\"{x:712,y:733,t:1526930184936};\\\", \\\"{x:697,y:721,t:1526930184953};\\\", \\\"{x:684,y:707,t:1526930184970};\\\", \\\"{x:671,y:693,t:1526930184986};\\\", \\\"{x:661,y:682,t:1526930185003};\\\", \\\"{x:655,y:677,t:1526930185020};\\\", \\\"{x:655,y:675,t:1526930185041};\\\", \\\"{x:655,y:674,t:1526930185057};\\\", \\\"{x:655,y:673,t:1526930185073};\\\", \\\"{x:657,y:672,t:1526930185087};\\\", \\\"{x:657,y:670,t:1526930185103};\\\", \\\"{x:659,y:660,t:1526930185120};\\\", \\\"{x:660,y:648,t:1526930185136};\\\", \\\"{x:660,y:643,t:1526930185153};\\\", \\\"{x:663,y:639,t:1526930185171};\\\", \\\"{x:667,y:635,t:1526930185186};\\\", \\\"{x:671,y:630,t:1526930185204};\\\", \\\"{x:676,y:627,t:1526930185219};\\\", \\\"{x:689,y:622,t:1526930185236};\\\", \\\"{x:710,y:616,t:1526930185252};\\\", \\\"{x:739,y:613,t:1526930185271};\\\", \\\"{x:762,y:610,t:1526930185287};\\\", \\\"{x:784,y:604,t:1526930185303};\\\", \\\"{x:794,y:603,t:1526930185319};\\\", \\\"{x:796,y:602,t:1526930185344};\\\", \\\"{x:799,y:601,t:1526930185360};\\\", \\\"{x:800,y:601,t:1526930185369};\\\", \\\"{x:804,y:600,t:1526930185387};\\\", \\\"{x:805,y:599,t:1526930185403};\\\", \\\"{x:806,y:598,t:1526930185420};\\\", \\\"{x:807,y:598,t:1526930185437};\\\", \\\"{x:807,y:597,t:1526930185453};\\\", \\\"{x:806,y:594,t:1526930185470};\\\", \\\"{x:795,y:589,t:1526930185487};\\\", \\\"{x:758,y:580,t:1526930185504};\\\", \\\"{x:713,y:575,t:1526930185520};\\\", \\\"{x:631,y:569,t:1526930185537};\\\", \\\"{x:575,y:569,t:1526930185554};\\\", \\\"{x:543,y:565,t:1526930185570};\\\", \\\"{x:497,y:571,t:1526930185588};\\\", \\\"{x:479,y:577,t:1526930185603};\\\", \\\"{x:466,y:580,t:1526930185620};\\\", \\\"{x:460,y:584,t:1526930185637};\\\", \\\"{x:458,y:585,t:1526930185654};\\\", \\\"{x:458,y:586,t:1526930185704};\\\", \\\"{x:457,y:586,t:1526930185720};\\\", \\\"{x:455,y:587,t:1526930185737};\\\", \\\"{x:451,y:588,t:1526930185754};\\\", \\\"{x:447,y:588,t:1526930185770};\\\", \\\"{x:441,y:588,t:1526930185787};\\\", \\\"{x:434,y:586,t:1526930185804};\\\", \\\"{x:425,y:576,t:1526930185820};\\\", \\\"{x:413,y:565,t:1526930185837};\\\", \\\"{x:399,y:551,t:1526930185856};\\\", \\\"{x:395,y:546,t:1526930185871};\\\", \\\"{x:392,y:542,t:1526930185887};\\\", \\\"{x:392,y:538,t:1526930185903};\\\", \\\"{x:391,y:536,t:1526930185921};\\\", \\\"{x:390,y:535,t:1526930185937};\\\", \\\"{x:389,y:535,t:1526930185954};\\\", \\\"{x:388,y:534,t:1526930185971};\\\", \\\"{x:387,y:534,t:1526930186072};\\\", \\\"{x:386,y:534,t:1526930186087};\\\", \\\"{x:384,y:535,t:1526930186105};\\\", \\\"{x:383,y:536,t:1526930186121};\\\", \\\"{x:382,y:537,t:1526930186207};\\\", \\\"{x:382,y:537,t:1526930186269};\\\", \\\"{x:384,y:537,t:1526930187553};\\\", \\\"{x:392,y:542,t:1526930187561};\\\", \\\"{x:398,y:547,t:1526930187573};\\\", \\\"{x:413,y:556,t:1526930187589};\\\", \\\"{x:423,y:563,t:1526930187605};\\\", \\\"{x:435,y:569,t:1526930187622};\\\", \\\"{x:439,y:574,t:1526930187638};\\\", \\\"{x:444,y:576,t:1526930187654};\\\", \\\"{x:455,y:580,t:1526930187671};\\\", \\\"{x:468,y:584,t:1526930187689};\\\", \\\"{x:484,y:588,t:1526930187705};\\\", \\\"{x:501,y:590,t:1526930187722};\\\", \\\"{x:523,y:595,t:1526930187739};\\\", \\\"{x:557,y:596,t:1526930187754};\\\", \\\"{x:582,y:596,t:1526930187772};\\\", \\\"{x:611,y:596,t:1526930187788};\\\", \\\"{x:638,y:593,t:1526930187805};\\\", \\\"{x:662,y:589,t:1526930187822};\\\", \\\"{x:677,y:588,t:1526930187838};\\\", \\\"{x:685,y:586,t:1526930187855};\\\", \\\"{x:698,y:583,t:1526930187872};\\\", \\\"{x:713,y:582,t:1526930187889};\\\", \\\"{x:727,y:582,t:1526930187906};\\\", \\\"{x:735,y:582,t:1526930187922};\\\", \\\"{x:744,y:581,t:1526930187939};\\\", \\\"{x:751,y:581,t:1526930187955};\\\", \\\"{x:761,y:581,t:1526930187972};\\\", \\\"{x:765,y:581,t:1526930187989};\\\", \\\"{x:772,y:581,t:1526930188005};\\\", \\\"{x:778,y:581,t:1526930188022};\\\", \\\"{x:781,y:581,t:1526930188038};\\\", \\\"{x:785,y:583,t:1526930188055};\\\", \\\"{x:791,y:584,t:1526930188072};\\\", \\\"{x:791,y:585,t:1526930188089};\\\", \\\"{x:792,y:585,t:1526930188112};\\\", \\\"{x:792,y:586,t:1526930188121};\\\", \\\"{x:780,y:588,t:1526930188138};\\\", \\\"{x:757,y:588,t:1526930188155};\\\", \\\"{x:703,y:588,t:1526930188173};\\\", \\\"{x:582,y:579,t:1526930188189};\\\", \\\"{x:462,y:571,t:1526930188207};\\\", \\\"{x:334,y:569,t:1526930188222};\\\", \\\"{x:203,y:560,t:1526930188239};\\\", \\\"{x:72,y:558,t:1526930188256};\\\", \\\"{x:32,y:561,t:1526930188272};\\\", \\\"{x:25,y:564,t:1526930188289};\\\", \\\"{x:24,y:565,t:1526930188306};\\\", \\\"{x:24,y:566,t:1526930188323};\\\", \\\"{x:25,y:568,t:1526930188339};\\\", \\\"{x:26,y:569,t:1526930188356};\\\", \\\"{x:27,y:571,t:1526930188376};\\\", \\\"{x:28,y:573,t:1526930188390};\\\", \\\"{x:29,y:579,t:1526930188406};\\\", \\\"{x:32,y:584,t:1526930188424};\\\", \\\"{x:39,y:593,t:1526930188440};\\\", \\\"{x:48,y:600,t:1526930188457};\\\", \\\"{x:51,y:602,t:1526930188474};\\\", \\\"{x:55,y:605,t:1526930188491};\\\", \\\"{x:64,y:607,t:1526930188505};\\\", \\\"{x:76,y:609,t:1526930188522};\\\", \\\"{x:90,y:612,t:1526930188540};\\\", \\\"{x:104,y:612,t:1526930188555};\\\", \\\"{x:111,y:613,t:1526930188572};\\\", \\\"{x:117,y:613,t:1526930188589};\\\", \\\"{x:127,y:615,t:1526930188605};\\\", \\\"{x:146,y:620,t:1526930188622};\\\", \\\"{x:158,y:622,t:1526930188639};\\\", \\\"{x:179,y:626,t:1526930188656};\\\", \\\"{x:204,y:628,t:1526930188673};\\\", \\\"{x:217,y:629,t:1526930188689};\\\", \\\"{x:234,y:630,t:1526930188705};\\\", \\\"{x:258,y:634,t:1526930188723};\\\", \\\"{x:280,y:637,t:1526930188738};\\\", \\\"{x:305,y:637,t:1526930188756};\\\", \\\"{x:327,y:637,t:1526930188772};\\\", \\\"{x:331,y:637,t:1526930188790};\\\", \\\"{x:345,y:635,t:1526930188805};\\\", \\\"{x:360,y:634,t:1526930188822};\\\", \\\"{x:370,y:633,t:1526930188839};\\\", \\\"{x:373,y:632,t:1526930188856};\\\", \\\"{x:373,y:631,t:1526930188881};\\\", \\\"{x:373,y:630,t:1526930188920};\\\", \\\"{x:373,y:629,t:1526930188944};\\\", \\\"{x:373,y:628,t:1526930188956};\\\", \\\"{x:373,y:627,t:1526930188973};\\\", \\\"{x:373,y:626,t:1526930188999};\\\", \\\"{x:373,y:625,t:1526930189008};\\\", \\\"{x:373,y:624,t:1526930189024};\\\", \\\"{x:384,y:626,t:1526930189297};\\\", \\\"{x:397,y:631,t:1526930189306};\\\", \\\"{x:419,y:637,t:1526930189324};\\\", \\\"{x:443,y:645,t:1526930189341};\\\", \\\"{x:461,y:653,t:1526930189356};\\\", \\\"{x:477,y:656,t:1526930189373};\\\", \\\"{x:486,y:659,t:1526930189390};\\\", \\\"{x:489,y:660,t:1526930189406};\\\", \\\"{x:491,y:661,t:1526930189423};\\\", \\\"{x:492,y:662,t:1526930189441};\\\", \\\"{x:492,y:664,t:1526930189537};\\\", \\\"{x:491,y:664,t:1526930189592};\\\", \\\"{x:484,y:664,t:1526930189607};\\\", \\\"{x:467,y:656,t:1526930189623};\\\", \\\"{x:459,y:653,t:1526930189640};\\\", \\\"{x:457,y:651,t:1526930189657};\\\", \\\"{x:456,y:650,t:1526930189673};\\\", \\\"{x:453,y:648,t:1526930189690};\\\", \\\"{x:440,y:642,t:1526930189707};\\\", \\\"{x:434,y:640,t:1526930189723};\\\", \\\"{x:431,y:639,t:1526930189740};\\\", \\\"{x:428,y:638,t:1526930189759};\\\", \\\"{x:427,y:637,t:1526930189773};\\\", \\\"{x:424,y:637,t:1526930189789};\\\", \\\"{x:415,y:634,t:1526930189807};\\\", \\\"{x:392,y:625,t:1526930189824};\\\", \\\"{x:389,y:623,t:1526930189840};\\\", \\\"{x:386,y:623,t:1526930189857};\\\", \\\"{x:386,y:621,t:1526930190063};\\\", \\\"{x:390,y:621,t:1526930190074};\\\", \\\"{x:391,y:621,t:1526930190090};\\\", \\\"{x:398,y:621,t:1526930190107};\\\", \\\"{x:409,y:623,t:1526930190123};\\\", \\\"{x:426,y:632,t:1526930190140};\\\", \\\"{x:440,y:639,t:1526930190157};\\\", \\\"{x:456,y:643,t:1526930190174};\\\", \\\"{x:469,y:650,t:1526930190189};\\\", \\\"{x:480,y:654,t:1526930190207};\\\", \\\"{x:495,y:659,t:1526930190224};\\\", \\\"{x:503,y:663,t:1526930190240};\\\", \\\"{x:507,y:666,t:1526930190256};\\\", \\\"{x:510,y:669,t:1526930190274};\\\", \\\"{x:511,y:671,t:1526930190291};\\\", \\\"{x:516,y:677,t:1526930190307};\\\", \\\"{x:521,y:685,t:1526930190324};\\\", \\\"{x:525,y:689,t:1526930190341};\\\", \\\"{x:528,y:696,t:1526930190357};\\\", \\\"{x:530,y:702,t:1526930190374};\\\", \\\"{x:530,y:706,t:1526930190391};\\\", \\\"{x:528,y:708,t:1526930190407};\\\", \\\"{x:525,y:711,t:1526930190424};\\\", \\\"{x:522,y:714,t:1526930190441};\\\", \\\"{x:519,y:720,t:1526930190459};\\\", \\\"{x:516,y:723,t:1526930190474};\\\", \\\"{x:511,y:727,t:1526930190491};\\\", \\\"{x:508,y:730,t:1526930190507};\\\", \\\"{x:504,y:733,t:1526930190524};\\\", \\\"{x:502,y:734,t:1526930190541};\\\", \\\"{x:501,y:736,t:1526930190557};\\\", \\\"{x:500,y:736,t:1526930190574};\\\", \\\"{x:499,y:737,t:1526930190632};\\\", \\\"{x:498,y:738,t:1526930190688};\\\", \\\"{x:497,y:738,t:1526930190744};\\\", \\\"{x:496,y:738,t:1526930192344};\\\", \\\"{x:494,y:737,t:1526930192359};\\\", \\\"{x:488,y:734,t:1526930192376};\\\", \\\"{x:485,y:733,t:1526930192392};\\\", \\\"{x:484,y:733,t:1526930192440};\\\", \\\"{x:484,y:732,t:1526930192480};\\\" ] }, { \\\"rt\\\": 13030, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 16, \\\"time_elapsed\\\": 557816, \\\"internal_node_id\\\": \\\"0.0-6.0-6.0\\\", \\\"subject\\\": \\\"GQ35Z\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"charlie\\\", \\\"condition\\\": \\\"111\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"starts\\\", \\\"q\\\": 12, \\\"clicks\\\": 1, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XInside-YFull\\\", \\\"correct\\\": 1, \\\"orth_correct\\\": 0, \\\"answer\\\": [ \\\"G\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-B -X -F -F -G -G \\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:482,y:732,t:1526930193289};\\\", \\\"{x:481,y:732,t:1526930193337};\\\", \\\"{x:476,y:732,t:1526930193729};\\\", \\\"{x:440,y:732,t:1526930193746};\\\", \\\"{x:399,y:731,t:1526930193761};\\\", \\\"{x:370,y:729,t:1526930193777};\\\", \\\"{x:352,y:727,t:1526930193794};\\\", \\\"{x:348,y:728,t:1526930193810};\\\", \\\"{x:348,y:729,t:1526930193827};\\\", \\\"{x:347,y:729,t:1526930193848};\\\", \\\"{x:350,y:732,t:1526930194393};\\\", \\\"{x:357,y:732,t:1526930194400};\\\", \\\"{x:358,y:732,t:1526930194411};\\\", \\\"{x:359,y:732,t:1526930194497};\\\", \\\"{x:360,y:732,t:1526930194511};\\\", \\\"{x:361,y:732,t:1526930194544};\\\", \\\"{x:364,y:730,t:1526930194561};\\\", \\\"{x:374,y:730,t:1526930194578};\\\", \\\"{x:389,y:730,t:1526930194594};\\\", \\\"{x:402,y:734,t:1526930194612};\\\", \\\"{x:412,y:736,t:1526930194628};\\\", \\\"{x:421,y:740,t:1526930194645};\\\", \\\"{x:427,y:742,t:1526930194662};\\\", \\\"{x:435,y:746,t:1526930194679};\\\", \\\"{x:447,y:751,t:1526930194696};\\\", \\\"{x:458,y:760,t:1526930194712};\\\", \\\"{x:473,y:770,t:1526930194728};\\\", \\\"{x:506,y:788,t:1526930194744};\\\", \\\"{x:531,y:794,t:1526930194761};\\\", \\\"{x:558,y:801,t:1526930194777};\\\", \\\"{x:578,y:806,t:1526930194794};\\\", \\\"{x:594,y:806,t:1526930194811};\\\", \\\"{x:610,y:806,t:1526930194827};\\\", \\\"{x:616,y:806,t:1526930194844};\\\", \\\"{x:627,y:803,t:1526930194861};\\\", \\\"{x:637,y:797,t:1526930194877};\\\", \\\"{x:647,y:793,t:1526930194894};\\\", \\\"{x:650,y:792,t:1526930194912};\\\", \\\"{x:652,y:791,t:1526930194928};\\\", \\\"{x:654,y:790,t:1526930195033};\\\", \\\"{x:656,y:789,t:1526930195044};\\\", \\\"{x:659,y:788,t:1526930195061};\\\", \\\"{x:663,y:786,t:1526930195078};\\\", \\\"{x:676,y:781,t:1526930195094};\\\", \\\"{x:690,y:778,t:1526930195112};\\\", \\\"{x:696,y:774,t:1526930195128};\\\", \\\"{x:700,y:773,t:1526930195144};\\\", \\\"{x:702,y:772,t:1526930195161};\\\", \\\"{x:703,y:771,t:1526930195178};\\\", \\\"{x:705,y:771,t:1526930195194};\\\", \\\"{x:706,y:771,t:1526930195240};\\\", \\\"{x:717,y:771,t:1526930195248};\\\", \\\"{x:719,y:771,t:1526930195262};\\\", \\\"{x:721,y:771,t:1526930195279};\\\", \\\"{x:727,y:773,t:1526930195295};\\\", \\\"{x:734,y:776,t:1526930195312};\\\", \\\"{x:744,y:784,t:1526930195328};\\\", \\\"{x:763,y:784,t:1526930195344};\\\", \\\"{x:768,y:786,t:1526930195362};\\\", \\\"{x:777,y:786,t:1526930195378};\\\", \\\"{x:777,y:787,t:1526930195657};\\\", \\\"{x:778,y:787,t:1526930195664};\\\", \\\"{x:778,y:788,t:1526930196441};\\\", \\\"{x:778,y:789,t:1526930196456};\\\", \\\"{x:776,y:788,t:1526930196961};\\\", \\\"{x:775,y:787,t:1526930196977};\\\", \\\"{x:775,y:786,t:1526930196984};\\\", \\\"{x:774,y:786,t:1526930196997};\\\", \\\"{x:772,y:786,t:1526930197200};\\\", \\\"{x:771,y:787,t:1526930197213};\\\", \\\"{x:768,y:788,t:1526930197229};\\\", \\\"{x:764,y:792,t:1526930197247};\\\", \\\"{x:756,y:794,t:1526930197263};\\\", \\\"{x:751,y:795,t:1526930197280};\\\", \\\"{x:747,y:795,t:1526930197296};\\\", \\\"{x:747,y:796,t:1526930197713};\\\", \\\"{x:747,y:797,t:1526930197730};\\\", \\\"{x:749,y:798,t:1526930197746};\\\", \\\"{x:751,y:800,t:1526930197764};\\\", \\\"{x:757,y:800,t:1526930197779};\\\", \\\"{x:768,y:801,t:1526930197797};\\\", \\\"{x:781,y:803,t:1526930197814};\\\", \\\"{x:791,y:803,t:1526930197829};\\\", \\\"{x:804,y:805,t:1526930197846};\\\", \\\"{x:817,y:805,t:1526930197863};\\\", \\\"{x:843,y:806,t:1526930197880};\\\", \\\"{x:901,y:813,t:1526930197897};\\\", \\\"{x:945,y:815,t:1526930197914};\\\", \\\"{x:998,y:815,t:1526930197931};\\\", \\\"{x:1072,y:822,t:1526930197947};\\\", \\\"{x:1106,y:822,t:1526930197964};\\\", \\\"{x:1137,y:823,t:1526930197980};\\\", \\\"{x:1163,y:823,t:1526930197998};\\\", \\\"{x:1185,y:819,t:1526930198014};\\\", \\\"{x:1203,y:814,t:1526930198031};\\\", \\\"{x:1216,y:811,t:1526930198048};\\\", \\\"{x:1222,y:811,t:1526930198064};\\\", \\\"{x:1226,y:809,t:1526930198081};\\\", \\\"{x:1230,y:807,t:1526930198097};\\\", \\\"{x:1234,y:803,t:1526930198114};\\\", \\\"{x:1243,y:795,t:1526930198131};\\\", \\\"{x:1251,y:790,t:1526930198147};\\\", \\\"{x:1268,y:780,t:1526930198164};\\\", \\\"{x:1291,y:773,t:1526930198181};\\\", \\\"{x:1315,y:768,t:1526930198197};\\\", \\\"{x:1330,y:766,t:1526930198213};\\\", \\\"{x:1350,y:759,t:1526930198233};\\\", \\\"{x:1366,y:756,t:1526930198247};\\\", \\\"{x:1387,y:751,t:1526930198263};\\\", \\\"{x:1401,y:750,t:1526930198280};\\\", \\\"{x:1412,y:750,t:1526930198297};\\\", \\\"{x:1425,y:750,t:1526930198313};\\\", \\\"{x:1436,y:750,t:1526930198330};\\\", \\\"{x:1453,y:750,t:1526930198347};\\\", \\\"{x:1473,y:755,t:1526930198364};\\\", \\\"{x:1483,y:759,t:1526930198381};\\\", \\\"{x:1500,y:764,t:1526930198397};\\\", \\\"{x:1519,y:769,t:1526930198413};\\\", \\\"{x:1542,y:776,t:1526930198431};\\\", \\\"{x:1557,y:782,t:1526930198448};\\\", \\\"{x:1569,y:790,t:1526930198464};\\\", \\\"{x:1581,y:800,t:1526930198480};\\\", \\\"{x:1586,y:804,t:1526930198498};\\\", \\\"{x:1591,y:807,t:1526930198514};\\\", \\\"{x:1593,y:810,t:1526930198531};\\\", \\\"{x:1593,y:811,t:1526930198548};\\\", \\\"{x:1593,y:813,t:1526930198564};\\\", \\\"{x:1593,y:814,t:1526930198581};\\\", \\\"{x:1593,y:815,t:1526930198598};\\\", \\\"{x:1590,y:817,t:1526930198614};\\\", \\\"{x:1586,y:820,t:1526930198631};\\\", \\\"{x:1573,y:823,t:1526930198648};\\\", \\\"{x:1553,y:823,t:1526930198664};\\\", \\\"{x:1537,y:823,t:1526930198681};\\\", \\\"{x:1529,y:823,t:1526930198698};\\\", \\\"{x:1517,y:821,t:1526930198713};\\\", \\\"{x:1509,y:819,t:1526930198731};\\\", \\\"{x:1505,y:818,t:1526930198748};\\\", \\\"{x:1499,y:818,t:1526930198764};\\\", \\\"{x:1497,y:817,t:1526930198781};\\\", \\\"{x:1490,y:816,t:1526930198798};\\\", \\\"{x:1484,y:813,t:1526930198814};\\\", \\\"{x:1479,y:812,t:1526930198831};\\\", \\\"{x:1475,y:811,t:1526930198848};\\\", \\\"{x:1468,y:809,t:1526930198864};\\\", \\\"{x:1462,y:808,t:1526930198881};\\\", \\\"{x:1457,y:805,t:1526930198898};\\\", \\\"{x:1450,y:804,t:1526930198914};\\\", \\\"{x:1444,y:801,t:1526930198931};\\\", \\\"{x:1442,y:801,t:1526930198948};\\\", \\\"{x:1440,y:801,t:1526930198965};\\\", \\\"{x:1436,y:801,t:1526930198981};\\\", \\\"{x:1433,y:801,t:1526930198997};\\\", \\\"{x:1431,y:801,t:1526930199015};\\\", \\\"{x:1429,y:801,t:1526930199031};\\\", \\\"{x:1418,y:801,t:1526930199048};\\\", \\\"{x:1410,y:799,t:1526930199064};\\\", \\\"{x:1405,y:799,t:1526930199080};\\\", \\\"{x:1400,y:797,t:1526930199097};\\\", \\\"{x:1397,y:797,t:1526930199114};\\\", \\\"{x:1393,y:795,t:1526930199130};\\\", \\\"{x:1390,y:793,t:1526930199147};\\\", \\\"{x:1385,y:790,t:1526930199165};\\\", \\\"{x:1382,y:788,t:1526930199180};\\\", \\\"{x:1379,y:785,t:1526930199197};\\\", \\\"{x:1379,y:784,t:1526930199215};\\\", \\\"{x:1377,y:782,t:1526930199231};\\\", \\\"{x:1376,y:780,t:1526930199248};\\\", \\\"{x:1375,y:776,t:1526930199265};\\\", \\\"{x:1373,y:772,t:1526930199281};\\\", \\\"{x:1367,y:765,t:1526930199297};\\\", \\\"{x:1364,y:761,t:1526930199315};\\\", \\\"{x:1363,y:759,t:1526930199332};\\\", \\\"{x:1363,y:756,t:1526930199348};\\\", \\\"{x:1363,y:754,t:1526930199364};\\\", \\\"{x:1363,y:753,t:1526930199382};\\\", \\\"{x:1361,y:748,t:1526930199398};\\\", \\\"{x:1361,y:744,t:1526930199414};\\\", \\\"{x:1360,y:740,t:1526930199432};\\\", \\\"{x:1359,y:738,t:1526930199456};\\\", \\\"{x:1359,y:736,t:1526930199465};\\\", \\\"{x:1359,y:735,t:1526930199489};\\\", \\\"{x:1358,y:734,t:1526930199498};\\\", \\\"{x:1357,y:732,t:1526930199515};\\\", \\\"{x:1356,y:727,t:1526930199532};\\\", \\\"{x:1354,y:724,t:1526930199548};\\\", \\\"{x:1354,y:721,t:1526930199565};\\\", \\\"{x:1353,y:719,t:1526930199582};\\\", \\\"{x:1352,y:717,t:1526930199598};\\\", \\\"{x:1352,y:716,t:1526930199615};\\\", \\\"{x:1351,y:712,t:1526930199632};\\\", \\\"{x:1350,y:709,t:1526930199648};\\\", \\\"{x:1350,y:708,t:1526930199665};\\\", \\\"{x:1350,y:707,t:1526930199689};\\\", \\\"{x:1350,y:705,t:1526930201039};\\\", \\\"{x:1350,y:703,t:1526930201048};\\\", \\\"{x:1350,y:701,t:1526930201065};\\\", \\\"{x:1350,y:699,t:1526930201082};\\\", \\\"{x:1350,y:698,t:1526930201103};\\\", \\\"{x:1349,y:698,t:1526930201295};\\\", \\\"{x:1348,y:695,t:1526930201303};\\\", \\\"{x:1348,y:693,t:1526930201318};\\\", \\\"{x:1348,y:691,t:1526930201332};\\\", \\\"{x:1348,y:689,t:1526930201349};\\\", \\\"{x:1348,y:687,t:1526930201365};\\\", \\\"{x:1348,y:686,t:1526930201382};\\\", \\\"{x:1350,y:682,t:1526930201399};\\\", \\\"{x:1350,y:680,t:1526930201415};\\\", \\\"{x:1351,y:679,t:1526930201432};\\\", \\\"{x:1351,y:675,t:1526930201449};\\\", \\\"{x:1351,y:671,t:1526930201465};\\\", \\\"{x:1352,y:669,t:1526930201482};\\\", \\\"{x:1354,y:664,t:1526930201500};\\\", \\\"{x:1355,y:661,t:1526930201515};\\\", \\\"{x:1357,y:658,t:1526930201532};\\\", \\\"{x:1358,y:657,t:1526930201549};\\\", \\\"{x:1360,y:655,t:1526930201565};\\\", \\\"{x:1362,y:651,t:1526930201582};\\\", \\\"{x:1366,y:646,t:1526930201599};\\\", \\\"{x:1369,y:641,t:1526930201616};\\\", \\\"{x:1372,y:635,t:1526930201632};\\\", \\\"{x:1377,y:628,t:1526930201649};\\\", \\\"{x:1379,y:624,t:1526930201666};\\\", \\\"{x:1382,y:620,t:1526930201682};\\\", \\\"{x:1383,y:616,t:1526930201699};\\\", \\\"{x:1385,y:611,t:1526930201716};\\\", \\\"{x:1387,y:606,t:1526930201732};\\\", \\\"{x:1389,y:600,t:1526930201749};\\\", \\\"{x:1391,y:596,t:1526930201766};\\\", \\\"{x:1392,y:594,t:1526930201782};\\\", \\\"{x:1395,y:591,t:1526930201799};\\\", \\\"{x:1396,y:589,t:1526930201817};\\\", \\\"{x:1397,y:587,t:1526930201832};\\\", \\\"{x:1398,y:587,t:1526930201849};\\\", \\\"{x:1399,y:583,t:1526930201866};\\\", \\\"{x:1399,y:582,t:1526930201882};\\\", \\\"{x:1401,y:580,t:1526930201899};\\\", \\\"{x:1401,y:579,t:1526930201916};\\\", \\\"{x:1402,y:579,t:1526930201932};\\\", \\\"{x:1403,y:578,t:1526930201949};\\\", \\\"{x:1403,y:576,t:1526930201967};\\\", \\\"{x:1405,y:573,t:1526930201982};\\\", \\\"{x:1410,y:560,t:1526930201999};\\\", \\\"{x:1413,y:556,t:1526930202016};\\\", \\\"{x:1414,y:554,t:1526930202033};\\\", \\\"{x:1414,y:553,t:1526930202049};\\\", \\\"{x:1414,y:552,t:1526930202527};\\\", \\\"{x:1412,y:554,t:1526930202551};\\\", \\\"{x:1408,y:554,t:1526930202567};\\\", \\\"{x:1354,y:566,t:1526930202583};\\\", \\\"{x:1261,y:573,t:1526930202601};\\\", \\\"{x:1136,y:576,t:1526930202617};\\\", \\\"{x:984,y:578,t:1526930202634};\\\", \\\"{x:828,y:574,t:1526930202651};\\\", \\\"{x:678,y:572,t:1526930202667};\\\", \\\"{x:550,y:577,t:1526930202684};\\\", \\\"{x:460,y:581,t:1526930202701};\\\", \\\"{x:437,y:581,t:1526930202717};\\\", \\\"{x:432,y:583,t:1526930202733};\\\", \\\"{x:434,y:583,t:1526930202791};\\\", \\\"{x:440,y:581,t:1526930202800};\\\", \\\"{x:452,y:578,t:1526930202817};\\\", \\\"{x:460,y:576,t:1526930202833};\\\", \\\"{x:470,y:572,t:1526930202850};\\\", \\\"{x:477,y:570,t:1526930202867};\\\", \\\"{x:482,y:568,t:1526930202883};\\\", \\\"{x:497,y:565,t:1526930202900};\\\", \\\"{x:521,y:562,t:1526930202917};\\\", \\\"{x:559,y:562,t:1526930202933};\\\", \\\"{x:619,y:556,t:1526930202951};\\\", \\\"{x:692,y:550,t:1526930202967};\\\", \\\"{x:720,y:545,t:1526930202984};\\\", \\\"{x:740,y:542,t:1526930203000};\\\", \\\"{x:756,y:541,t:1526930203017};\\\", \\\"{x:776,y:541,t:1526930203034};\\\", \\\"{x:783,y:541,t:1526930203050};\\\", \\\"{x:789,y:541,t:1526930203067};\\\", \\\"{x:792,y:541,t:1526930203084};\\\", \\\"{x:796,y:539,t:1526930203119};\\\", \\\"{x:800,y:539,t:1526930203134};\\\", \\\"{x:807,y:539,t:1526930203150};\\\", \\\"{x:811,y:539,t:1526930203167};\\\", \\\"{x:814,y:539,t:1526930203185};\\\", \\\"{x:815,y:539,t:1526930203327};\\\", \\\"{x:817,y:539,t:1526930203334};\\\", \\\"{x:822,y:539,t:1526930203350};\\\", \\\"{x:828,y:539,t:1526930203367};\\\", \\\"{x:829,y:539,t:1526930203384};\\\", \\\"{x:830,y:539,t:1526930203783};\\\", \\\"{x:830,y:540,t:1526930203791};\\\", \\\"{x:830,y:542,t:1526930203806};\\\", \\\"{x:829,y:544,t:1526930203818};\\\", \\\"{x:827,y:547,t:1526930203834};\\\", \\\"{x:824,y:551,t:1526930203851};\\\", \\\"{x:821,y:554,t:1526930203868};\\\", \\\"{x:817,y:556,t:1526930203885};\\\", \\\"{x:813,y:558,t:1526930203901};\\\", \\\"{x:802,y:563,t:1526930203918};\\\", \\\"{x:788,y:568,t:1526930203934};\\\", \\\"{x:768,y:577,t:1526930203951};\\\", \\\"{x:756,y:584,t:1526930203968};\\\", \\\"{x:741,y:587,t:1526930203984};\\\", \\\"{x:714,y:594,t:1526930204001};\\\", \\\"{x:693,y:600,t:1526930204018};\\\", \\\"{x:676,y:606,t:1526930204034};\\\", \\\"{x:660,y:612,t:1526930204051};\\\", \\\"{x:648,y:623,t:1526930204068};\\\", \\\"{x:634,y:631,t:1526930204086};\\\", \\\"{x:625,y:637,t:1526930204102};\\\", \\\"{x:619,y:641,t:1526930204118};\\\", \\\"{x:609,y:648,t:1526930204135};\\\", \\\"{x:601,y:654,t:1526930204151};\\\", \\\"{x:596,y:658,t:1526930204168};\\\", \\\"{x:589,y:663,t:1526930204185};\\\", \\\"{x:584,y:668,t:1526930204201};\\\", \\\"{x:575,y:673,t:1526930204218};\\\", \\\"{x:568,y:678,t:1526930204235};\\\", \\\"{x:564,y:681,t:1526930204251};\\\", \\\"{x:563,y:682,t:1526930204268};\\\", \\\"{x:559,y:686,t:1526930204286};\\\", \\\"{x:555,y:689,t:1526930204301};\\\", \\\"{x:551,y:693,t:1526930204318};\\\", \\\"{x:545,y:698,t:1526930204335};\\\", \\\"{x:542,y:700,t:1526930204351};\\\", \\\"{x:539,y:702,t:1526930204368};\\\", \\\"{x:537,y:704,t:1526930204385};\\\", \\\"{x:537,y:705,t:1526930204401};\\\", \\\"{x:534,y:707,t:1526930204418};\\\", \\\"{x:532,y:708,t:1526930204435};\\\", \\\"{x:531,y:709,t:1526930204451};\\\", \\\"{x:530,y:710,t:1526930204468};\\\", \\\"{x:529,y:711,t:1526930204486};\\\", \\\"{x:528,y:711,t:1526930204501};\\\", \\\"{x:527,y:713,t:1526930204518};\\\", \\\"{x:525,y:713,t:1526930204535};\\\", \\\"{x:525,y:715,t:1526930204551};\\\", \\\"{x:523,y:716,t:1526930204568};\\\", \\\"{x:523,y:717,t:1526930204585};\\\", \\\"{x:521,y:719,t:1526930204602};\\\", \\\"{x:520,y:719,t:1526930204623};\\\", \\\"{x:520,y:720,t:1526930204640};\\\", \\\"{x:520,y:721,t:1526930204652};\\\", \\\"{x:519,y:722,t:1526930204670};\\\", \\\"{x:518,y:722,t:1526930204685};\\\", \\\"{x:518,y:723,t:1526930204702};\\\", \\\"{x:517,y:723,t:1526930204719};\\\", \\\"{x:517,y:724,t:1526930204736};\\\", \\\"{x:515,y:724,t:1526930204752};\\\", \\\"{x:515,y:725,t:1526930204768};\\\", \\\"{x:514,y:726,t:1526930204785};\\\", \\\"{x:514,y:727,t:1526930204807};\\\", \\\"{x:513,y:727,t:1526930204818};\\\", \\\"{x:512,y:729,t:1526930204835};\\\", \\\"{x:511,y:730,t:1526930204852};\\\", \\\"{x:511,y:731,t:1526930204871};\\\", \\\"{x:511,y:732,t:1526930204885};\\\", \\\"{x:511,y:733,t:1526930204911};\\\" ] }, { \\\"rt\\\": 14874, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 17, \\\"time_elapsed\\\": 573937, \\\"internal_node_id\\\": \\\"0.0-6.0-7.0\\\", \\\"subject\\\": \\\"GQ35Z\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"charlie\\\", \\\"condition\\\": \\\"111\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"meets\\\", \\\"q\\\": 13, \\\"clicks\\\": 2, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XInside-YFull\\\", \\\"correct\\\": 1, \\\"orth_correct\\\": 0, \\\"answer\\\": [ \\\"E\\\", \\\"F\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-X -X -O -Z \\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:519,y:739,t:1526930208831};\\\", \\\"{x:536,y:749,t:1526930208839};\\\", \\\"{x:558,y:762,t:1526930208854};\\\", \\\"{x:584,y:776,t:1526930208870};\\\", \\\"{x:625,y:790,t:1526930208889};\\\", \\\"{x:655,y:794,t:1526930208906};\\\", \\\"{x:710,y:797,t:1526930208922};\\\", \\\"{x:776,y:804,t:1526930208938};\\\", \\\"{x:824,y:811,t:1526930208955};\\\", \\\"{x:850,y:816,t:1526930208973};\\\", \\\"{x:878,y:820,t:1526930208989};\\\", \\\"{x:910,y:828,t:1526930209006};\\\", \\\"{x:937,y:833,t:1526930209022};\\\", \\\"{x:945,y:833,t:1526930209039};\\\", \\\"{x:947,y:833,t:1526930209575};\\\", \\\"{x:950,y:833,t:1526930209589};\\\", \\\"{x:951,y:833,t:1526930209606};\\\", \\\"{x:953,y:833,t:1526930209623};\\\", \\\"{x:960,y:835,t:1526930209639};\\\", \\\"{x:963,y:835,t:1526930209657};\\\", \\\"{x:968,y:835,t:1526930209673};\\\", \\\"{x:970,y:835,t:1526930209690};\\\", \\\"{x:974,y:831,t:1526930209707};\\\", \\\"{x:986,y:831,t:1526930209723};\\\", \\\"{x:995,y:831,t:1526930209739};\\\", \\\"{x:1006,y:831,t:1526930209756};\\\", \\\"{x:1014,y:831,t:1526930209772};\\\", \\\"{x:1030,y:831,t:1526930209789};\\\", \\\"{x:1048,y:831,t:1526930209806};\\\", \\\"{x:1072,y:831,t:1526930209823};\\\", \\\"{x:1110,y:830,t:1526930209839};\\\", \\\"{x:1134,y:828,t:1526930209857};\\\", \\\"{x:1152,y:827,t:1526930209872};\\\", \\\"{x:1163,y:826,t:1526930209890};\\\", \\\"{x:1173,y:825,t:1526930209907};\\\", \\\"{x:1182,y:823,t:1526930209922};\\\", \\\"{x:1193,y:822,t:1526930209939};\\\", \\\"{x:1206,y:821,t:1526930209957};\\\", \\\"{x:1220,y:821,t:1526930209973};\\\", \\\"{x:1233,y:821,t:1526930209990};\\\", \\\"{x:1251,y:821,t:1526930210006};\\\", \\\"{x:1265,y:821,t:1526930210022};\\\", \\\"{x:1291,y:821,t:1526930210039};\\\", \\\"{x:1304,y:821,t:1526930210057};\\\", \\\"{x:1322,y:821,t:1526930210073};\\\", \\\"{x:1326,y:821,t:1526930210090};\\\", \\\"{x:1331,y:821,t:1526930210106};\\\", \\\"{x:1339,y:821,t:1526930210123};\\\", \\\"{x:1347,y:821,t:1526930210140};\\\", \\\"{x:1353,y:822,t:1526930210156};\\\", \\\"{x:1354,y:823,t:1526930210174};\\\", \\\"{x:1355,y:823,t:1526930210189};\\\", \\\"{x:1360,y:824,t:1526930210206};\\\", \\\"{x:1364,y:826,t:1526930210223};\\\", \\\"{x:1366,y:826,t:1526930210263};\\\", \\\"{x:1369,y:827,t:1526930210273};\\\", \\\"{x:1372,y:830,t:1526930210290};\\\", \\\"{x:1376,y:833,t:1526930210307};\\\", \\\"{x:1378,y:837,t:1526930210324};\\\", \\\"{x:1379,y:838,t:1526930210340};\\\", \\\"{x:1382,y:840,t:1526930210356};\\\", \\\"{x:1384,y:842,t:1526930210374};\\\", \\\"{x:1386,y:844,t:1526930210389};\\\", \\\"{x:1387,y:845,t:1526930210406};\\\", \\\"{x:1389,y:849,t:1526930210423};\\\", \\\"{x:1390,y:849,t:1526930210447};\\\", \\\"{x:1394,y:852,t:1526930210511};\\\", \\\"{x:1394,y:853,t:1526930210523};\\\", \\\"{x:1396,y:855,t:1526930210539};\\\", \\\"{x:1397,y:858,t:1526930210556};\\\", \\\"{x:1398,y:860,t:1526930210574};\\\", \\\"{x:1398,y:861,t:1526930210590};\\\", \\\"{x:1401,y:864,t:1526930210607};\\\", \\\"{x:1402,y:865,t:1526930210647};\\\", \\\"{x:1404,y:865,t:1526930210671};\\\", \\\"{x:1407,y:865,t:1526930210687};\\\", \\\"{x:1409,y:865,t:1526930210695};\\\", \\\"{x:1410,y:865,t:1526930210706};\\\", \\\"{x:1414,y:864,t:1526930210723};\\\", \\\"{x:1418,y:863,t:1526930210741};\\\", \\\"{x:1422,y:860,t:1526930210756};\\\", \\\"{x:1429,y:856,t:1526930210773};\\\", \\\"{x:1433,y:854,t:1526930210799};\\\", \\\"{x:1434,y:853,t:1526930210807};\\\", \\\"{x:1437,y:852,t:1526930210824};\\\", \\\"{x:1441,y:850,t:1526930210841};\\\", \\\"{x:1447,y:848,t:1526930210857};\\\", \\\"{x:1451,y:848,t:1526930210873};\\\", \\\"{x:1456,y:848,t:1526930210890};\\\", \\\"{x:1458,y:847,t:1526930210907};\\\", \\\"{x:1460,y:846,t:1526930210923};\\\", \\\"{x:1461,y:845,t:1526930210941};\\\", \\\"{x:1466,y:844,t:1526930210958};\\\", \\\"{x:1469,y:842,t:1526930210974};\\\", \\\"{x:1470,y:840,t:1526930210991};\\\", \\\"{x:1472,y:838,t:1526930211008};\\\", \\\"{x:1474,y:837,t:1526930211023};\\\", \\\"{x:1476,y:835,t:1526930211041};\\\", \\\"{x:1477,y:833,t:1526930211058};\\\", \\\"{x:1478,y:833,t:1526930211073};\\\", \\\"{x:1479,y:829,t:1526930211090};\\\", \\\"{x:1480,y:826,t:1526930211107};\\\", \\\"{x:1483,y:821,t:1526930211123};\\\", \\\"{x:1486,y:816,t:1526930211141};\\\", \\\"{x:1489,y:811,t:1526930211158};\\\", \\\"{x:1492,y:809,t:1526930211173};\\\", \\\"{x:1494,y:807,t:1526930211190};\\\", \\\"{x:1497,y:802,t:1526930211207};\\\", \\\"{x:1499,y:799,t:1526930211223};\\\", \\\"{x:1502,y:796,t:1526930211241};\\\", \\\"{x:1505,y:793,t:1526930211257};\\\", \\\"{x:1509,y:789,t:1526930211273};\\\", \\\"{x:1510,y:784,t:1526930211291};\\\", \\\"{x:1513,y:777,t:1526930211308};\\\", \\\"{x:1515,y:771,t:1526930211324};\\\", \\\"{x:1518,y:766,t:1526930211341};\\\", \\\"{x:1524,y:759,t:1526930211358};\\\", \\\"{x:1531,y:748,t:1526930211375};\\\", \\\"{x:1536,y:737,t:1526930211391};\\\", \\\"{x:1542,y:725,t:1526930211407};\\\", \\\"{x:1549,y:715,t:1526930211425};\\\", \\\"{x:1555,y:709,t:1526930211441};\\\", \\\"{x:1559,y:700,t:1526930211457};\\\", \\\"{x:1560,y:692,t:1526930211475};\\\", \\\"{x:1564,y:686,t:1526930211491};\\\", \\\"{x:1564,y:681,t:1526930211507};\\\", \\\"{x:1565,y:675,t:1526930211524};\\\", \\\"{x:1567,y:670,t:1526930211541};\\\", \\\"{x:1567,y:665,t:1526930211557};\\\", \\\"{x:1568,y:663,t:1526930211575};\\\", \\\"{x:1569,y:658,t:1526930211590};\\\", \\\"{x:1569,y:655,t:1526930211607};\\\", \\\"{x:1571,y:651,t:1526930211624};\\\", \\\"{x:1571,y:649,t:1526930211641};\\\", \\\"{x:1572,y:647,t:1526930211658};\\\", \\\"{x:1572,y:644,t:1526930211674};\\\", \\\"{x:1572,y:643,t:1526930211691};\\\", \\\"{x:1572,y:641,t:1526930211707};\\\", \\\"{x:1572,y:639,t:1526930211724};\\\", \\\"{x:1572,y:636,t:1526930211741};\\\", \\\"{x:1572,y:633,t:1526930211758};\\\", \\\"{x:1571,y:630,t:1526930211775};\\\", \\\"{x:1569,y:623,t:1526930211791};\\\", \\\"{x:1559,y:606,t:1526930211807};\\\", \\\"{x:1556,y:600,t:1526930211825};\\\", \\\"{x:1555,y:595,t:1526930211842};\\\", \\\"{x:1555,y:592,t:1526930211857};\\\", \\\"{x:1553,y:588,t:1526930211875};\\\", \\\"{x:1553,y:584,t:1526930211892};\\\", \\\"{x:1553,y:581,t:1526930211907};\\\", \\\"{x:1552,y:578,t:1526930211925};\\\", \\\"{x:1552,y:575,t:1526930211942};\\\", \\\"{x:1551,y:573,t:1526930211957};\\\", \\\"{x:1551,y:572,t:1526930211974};\\\", \\\"{x:1550,y:567,t:1526930211991};\\\", \\\"{x:1549,y:565,t:1526930212007};\\\", \\\"{x:1549,y:564,t:1526930212025};\\\", \\\"{x:1548,y:561,t:1526930212041};\\\", \\\"{x:1546,y:559,t:1526930212057};\\\", \\\"{x:1545,y:557,t:1526930212075};\\\", \\\"{x:1543,y:555,t:1526930212092};\\\", \\\"{x:1542,y:553,t:1526930212108};\\\", \\\"{x:1540,y:550,t:1526930212125};\\\", \\\"{x:1539,y:549,t:1526930212143};\\\", \\\"{x:1538,y:547,t:1526930212158};\\\", \\\"{x:1536,y:547,t:1526930212175};\\\", \\\"{x:1533,y:547,t:1526930212191};\\\", \\\"{x:1530,y:547,t:1526930212207};\\\", \\\"{x:1527,y:547,t:1526930212225};\\\", \\\"{x:1526,y:547,t:1526930212242};\\\", \\\"{x:1524,y:547,t:1526930212259};\\\", \\\"{x:1523,y:546,t:1526930212274};\\\", \\\"{x:1522,y:546,t:1526930212291};\\\", \\\"{x:1521,y:546,t:1526930212311};\\\", \\\"{x:1520,y:546,t:1526930212367};\\\", \\\"{x:1519,y:546,t:1526930212375};\\\", \\\"{x:1518,y:546,t:1526930212392};\\\", \\\"{x:1517,y:546,t:1526930212448};\\\", \\\"{x:1516,y:546,t:1526930212459};\\\", \\\"{x:1514,y:546,t:1526930212474};\\\", \\\"{x:1513,y:546,t:1526930212491};\\\", \\\"{x:1511,y:546,t:1526930212511};\\\", \\\"{x:1510,y:548,t:1526930212525};\\\", \\\"{x:1507,y:549,t:1526930212543};\\\", \\\"{x:1506,y:549,t:1526930212567};\\\", \\\"{x:1504,y:550,t:1526930212591};\\\", \\\"{x:1503,y:550,t:1526930212609};\\\", \\\"{x:1501,y:550,t:1526930212624};\\\", \\\"{x:1499,y:551,t:1526930212641};\\\", \\\"{x:1497,y:552,t:1526930212659};\\\", \\\"{x:1495,y:552,t:1526930212675};\\\", \\\"{x:1494,y:553,t:1526930212692};\\\", \\\"{x:1493,y:554,t:1526930212736};\\\", \\\"{x:1492,y:554,t:1526930212783};\\\", \\\"{x:1492,y:557,t:1526930212887};\\\", \\\"{x:1493,y:559,t:1526930212895};\\\", \\\"{x:1494,y:562,t:1526930212909};\\\", \\\"{x:1495,y:570,t:1526930212925};\\\", \\\"{x:1496,y:579,t:1526930212942};\\\", \\\"{x:1500,y:589,t:1526930212959};\\\", \\\"{x:1505,y:599,t:1526930212976};\\\", \\\"{x:1511,y:609,t:1526930212992};\\\", \\\"{x:1519,y:618,t:1526930213009};\\\", \\\"{x:1527,y:625,t:1526930213025};\\\", \\\"{x:1533,y:632,t:1526930213042};\\\", \\\"{x:1538,y:639,t:1526930213059};\\\", \\\"{x:1548,y:644,t:1526930213075};\\\", \\\"{x:1555,y:648,t:1526930213093};\\\", \\\"{x:1560,y:650,t:1526930213109};\\\", \\\"{x:1566,y:651,t:1526930213126};\\\", \\\"{x:1570,y:652,t:1526930213142};\\\", \\\"{x:1571,y:654,t:1526930213159};\\\", \\\"{x:1579,y:658,t:1526930213175};\\\", \\\"{x:1588,y:662,t:1526930213193};\\\", \\\"{x:1601,y:668,t:1526930213209};\\\", \\\"{x:1611,y:671,t:1526930213226};\\\", \\\"{x:1614,y:674,t:1526930213242};\\\", \\\"{x:1616,y:676,t:1526930213258};\\\", \\\"{x:1617,y:678,t:1526930213275};\\\", \\\"{x:1620,y:678,t:1526930213293};\\\", \\\"{x:1622,y:681,t:1526930213309};\\\", \\\"{x:1624,y:683,t:1526930213326};\\\", \\\"{x:1627,y:686,t:1526930213342};\\\", \\\"{x:1628,y:687,t:1526930213367};\\\", \\\"{x:1628,y:688,t:1526930213415};\\\", \\\"{x:1627,y:688,t:1526930213471};\\\", \\\"{x:1626,y:688,t:1526930213479};\\\", \\\"{x:1625,y:689,t:1526930213493};\\\", \\\"{x:1623,y:690,t:1526930213509};\\\", \\\"{x:1622,y:690,t:1526930213527};\\\", \\\"{x:1620,y:690,t:1526930213543};\\\", \\\"{x:1619,y:691,t:1526930213559};\\\", \\\"{x:1617,y:693,t:1526930213576};\\\", \\\"{x:1615,y:695,t:1526930213593};\\\", \\\"{x:1611,y:697,t:1526930213610};\\\", \\\"{x:1605,y:700,t:1526930213626};\\\", \\\"{x:1600,y:703,t:1526930213643};\\\", \\\"{x:1594,y:706,t:1526930213659};\\\", \\\"{x:1590,y:709,t:1526930213676};\\\", \\\"{x:1586,y:713,t:1526930213692};\\\", \\\"{x:1579,y:721,t:1526930213710};\\\", \\\"{x:1573,y:731,t:1526930213726};\\\", \\\"{x:1564,y:748,t:1526930213743};\\\", \\\"{x:1560,y:756,t:1526930213759};\\\", \\\"{x:1556,y:766,t:1526930213776};\\\", \\\"{x:1554,y:774,t:1526930213792};\\\", \\\"{x:1550,y:787,t:1526930213810};\\\", \\\"{x:1545,y:798,t:1526930213826};\\\", \\\"{x:1537,y:808,t:1526930213843};\\\", \\\"{x:1534,y:814,t:1526930213859};\\\", \\\"{x:1531,y:818,t:1526930213876};\\\", \\\"{x:1531,y:824,t:1526930213892};\\\", \\\"{x:1527,y:831,t:1526930213910};\\\", \\\"{x:1524,y:840,t:1526930213926};\\\", \\\"{x:1520,y:847,t:1526930213943};\\\", \\\"{x:1515,y:855,t:1526930213960};\\\", \\\"{x:1511,y:859,t:1526930213977};\\\", \\\"{x:1510,y:866,t:1526930213992};\\\", \\\"{x:1508,y:873,t:1526930214010};\\\", \\\"{x:1507,y:880,t:1526930214027};\\\", \\\"{x:1506,y:885,t:1526930214043};\\\", \\\"{x:1503,y:890,t:1526930214060};\\\", \\\"{x:1502,y:894,t:1526930214077};\\\", \\\"{x:1502,y:897,t:1526930214093};\\\", \\\"{x:1500,y:902,t:1526930214110};\\\", \\\"{x:1500,y:906,t:1526930214127};\\\", \\\"{x:1500,y:913,t:1526930214142};\\\", \\\"{x:1499,y:918,t:1526930214160};\\\", \\\"{x:1498,y:922,t:1526930214176};\\\", \\\"{x:1497,y:924,t:1526930214193};\\\", \\\"{x:1495,y:926,t:1526930214210};\\\", \\\"{x:1494,y:926,t:1526930214227};\\\", \\\"{x:1493,y:929,t:1526930214243};\\\", \\\"{x:1493,y:932,t:1526930214260};\\\", \\\"{x:1492,y:934,t:1526930214276};\\\", \\\"{x:1492,y:936,t:1526930214293};\\\", \\\"{x:1491,y:939,t:1526930214310};\\\", \\\"{x:1489,y:942,t:1526930214326};\\\", \\\"{x:1488,y:943,t:1526930214343};\\\", \\\"{x:1488,y:946,t:1526930214360};\\\", \\\"{x:1487,y:948,t:1526930214376};\\\", \\\"{x:1486,y:950,t:1526930214393};\\\", \\\"{x:1485,y:951,t:1526930214410};\\\", \\\"{x:1484,y:952,t:1526930214426};\\\", \\\"{x:1484,y:954,t:1526930214487};\\\", \\\"{x:1482,y:955,t:1526930214511};\\\", \\\"{x:1482,y:957,t:1526930214526};\\\", \\\"{x:1481,y:959,t:1526930214575};\\\", \\\"{x:1481,y:960,t:1526930214631};\\\", \\\"{x:1480,y:960,t:1526930214647};\\\", \\\"{x:1481,y:960,t:1526930216791};\\\", \\\"{x:1482,y:960,t:1526930216847};\\\", \\\"{x:1484,y:960,t:1526930216927};\\\", \\\"{x:1475,y:955,t:1526930218063};\\\", \\\"{x:1395,y:919,t:1526930218080};\\\", \\\"{x:1274,y:865,t:1526930218095};\\\", \\\"{x:1155,y:817,t:1526930218112};\\\", \\\"{x:1041,y:775,t:1526930218130};\\\", \\\"{x:947,y:738,t:1526930218146};\\\", \\\"{x:909,y:722,t:1526930218162};\\\", \\\"{x:894,y:709,t:1526930218180};\\\", \\\"{x:885,y:698,t:1526930218196};\\\", \\\"{x:879,y:684,t:1526930218213};\\\", \\\"{x:871,y:668,t:1526930218230};\\\", \\\"{x:865,y:652,t:1526930218246};\\\", \\\"{x:858,y:634,t:1526930218263};\\\", \\\"{x:853,y:617,t:1526930218280};\\\", \\\"{x:849,y:604,t:1526930218297};\\\", \\\"{x:848,y:597,t:1526930218313};\\\", \\\"{x:846,y:591,t:1526930218330};\\\", \\\"{x:846,y:588,t:1526930218347};\\\", \\\"{x:846,y:583,t:1526930218363};\\\", \\\"{x:846,y:576,t:1526930218380};\\\", \\\"{x:845,y:567,t:1526930218397};\\\", \\\"{x:841,y:556,t:1526930218413};\\\", \\\"{x:841,y:554,t:1526930218430};\\\", \\\"{x:841,y:547,t:1526930218447};\\\", \\\"{x:841,y:543,t:1526930218463};\\\", \\\"{x:841,y:539,t:1526930218480};\\\", \\\"{x:841,y:533,t:1526930218496};\\\", \\\"{x:840,y:530,t:1526930218513};\\\", \\\"{x:840,y:526,t:1526930218530};\\\", \\\"{x:840,y:525,t:1526930218546};\\\", \\\"{x:840,y:524,t:1526930218563};\\\", \\\"{x:840,y:522,t:1526930218607};\\\", \\\"{x:840,y:521,t:1526930218615};\\\", \\\"{x:840,y:520,t:1526930218629};\\\", \\\"{x:840,y:519,t:1526930218647};\\\", \\\"{x:840,y:517,t:1526930218712};\\\", \\\"{x:840,y:516,t:1526930218730};\\\", \\\"{x:840,y:512,t:1526930218746};\\\", \\\"{x:839,y:512,t:1526930219071};\\\", \\\"{x:836,y:512,t:1526930219080};\\\", \\\"{x:829,y:513,t:1526930219097};\\\", \\\"{x:822,y:515,t:1526930219114};\\\", \\\"{x:813,y:518,t:1526930219132};\\\", \\\"{x:806,y:521,t:1526930219147};\\\", \\\"{x:800,y:523,t:1526930219164};\\\", \\\"{x:791,y:524,t:1526930219181};\\\", \\\"{x:782,y:526,t:1526930219197};\\\", \\\"{x:764,y:530,t:1526930219214};\\\", \\\"{x:735,y:532,t:1526930219231};\\\", \\\"{x:717,y:536,t:1526930219248};\\\", \\\"{x:696,y:539,t:1526930219264};\\\", \\\"{x:672,y:539,t:1526930219281};\\\", \\\"{x:653,y:539,t:1526930219297};\\\", \\\"{x:631,y:539,t:1526930219314};\\\", \\\"{x:613,y:539,t:1526930219332};\\\", \\\"{x:598,y:539,t:1526930219347};\\\", \\\"{x:578,y:541,t:1526930219364};\\\", \\\"{x:550,y:544,t:1526930219381};\\\", \\\"{x:534,y:547,t:1526930219397};\\\", \\\"{x:519,y:548,t:1526930219414};\\\", \\\"{x:498,y:552,t:1526930219431};\\\", \\\"{x:488,y:553,t:1526930219447};\\\", \\\"{x:480,y:554,t:1526930219464};\\\", \\\"{x:476,y:554,t:1526930219480};\\\", \\\"{x:474,y:554,t:1526930219497};\\\", \\\"{x:473,y:554,t:1526930219514};\\\", \\\"{x:468,y:554,t:1526930219531};\\\", \\\"{x:461,y:554,t:1526930219547};\\\", \\\"{x:457,y:552,t:1526930219564};\\\", \\\"{x:448,y:549,t:1526930219581};\\\", \\\"{x:444,y:547,t:1526930219597};\\\", \\\"{x:433,y:542,t:1526930219613};\\\", \\\"{x:429,y:535,t:1526930219630};\\\", \\\"{x:425,y:534,t:1526930219647};\\\", \\\"{x:424,y:534,t:1526930219663};\\\", \\\"{x:422,y:534,t:1526930219758};\\\", \\\"{x:421,y:534,t:1526930219766};\\\", \\\"{x:418,y:535,t:1526930219783};\\\", \\\"{x:418,y:538,t:1526930219796};\\\", \\\"{x:418,y:542,t:1526930219814};\\\", \\\"{x:419,y:548,t:1526930219831};\\\", \\\"{x:422,y:551,t:1526930219848};\\\", \\\"{x:424,y:552,t:1526930219863};\\\", \\\"{x:432,y:554,t:1526930219881};\\\", \\\"{x:441,y:555,t:1526930219898};\\\", \\\"{x:455,y:558,t:1526930219914};\\\", \\\"{x:479,y:564,t:1526930219932};\\\", \\\"{x:497,y:568,t:1526930219948};\\\", \\\"{x:520,y:571,t:1526930219964};\\\", \\\"{x:542,y:573,t:1526930219981};\\\", \\\"{x:565,y:576,t:1526930219997};\\\", \\\"{x:600,y:576,t:1526930220015};\\\", \\\"{x:629,y:576,t:1526930220031};\\\", \\\"{x:650,y:576,t:1526930220048};\\\", \\\"{x:676,y:576,t:1526930220065};\\\", \\\"{x:697,y:576,t:1526930220080};\\\", \\\"{x:716,y:575,t:1526930220097};\\\", \\\"{x:729,y:573,t:1526930220115};\\\", \\\"{x:744,y:573,t:1526930220131};\\\", \\\"{x:752,y:573,t:1526930220147};\\\", \\\"{x:763,y:573,t:1526930220165};\\\", \\\"{x:770,y:573,t:1526930220181};\\\", \\\"{x:776,y:571,t:1526930220198};\\\", \\\"{x:782,y:570,t:1526930220214};\\\", \\\"{x:783,y:569,t:1526930220247};\\\", \\\"{x:784,y:569,t:1526930220263};\\\", \\\"{x:786,y:567,t:1526930220271};\\\", \\\"{x:787,y:567,t:1526930220281};\\\", \\\"{x:788,y:567,t:1526930220298};\\\", \\\"{x:788,y:566,t:1526930220319};\\\", \\\"{x:789,y:565,t:1526930220331};\\\", \\\"{x:789,y:561,t:1526930220359};\\\", \\\"{x:788,y:559,t:1526930220367};\\\", \\\"{x:785,y:557,t:1526930220381};\\\", \\\"{x:782,y:552,t:1526930220398};\\\", \\\"{x:778,y:549,t:1526930220415};\\\", \\\"{x:774,y:544,t:1526930220431};\\\", \\\"{x:768,y:538,t:1526930220448};\\\", \\\"{x:758,y:529,t:1526930220464};\\\", \\\"{x:752,y:521,t:1526930220482};\\\", \\\"{x:748,y:512,t:1526930220498};\\\", \\\"{x:746,y:504,t:1526930220514};\\\", \\\"{x:743,y:499,t:1526930220532};\\\", \\\"{x:740,y:494,t:1526930220547};\\\", \\\"{x:737,y:491,t:1526930220564};\\\", \\\"{x:734,y:489,t:1526930220582};\\\", \\\"{x:731,y:488,t:1526930220597};\\\", \\\"{x:724,y:484,t:1526930220615};\\\", \\\"{x:716,y:484,t:1526930220632};\\\", \\\"{x:708,y:484,t:1526930220648};\\\", \\\"{x:701,y:484,t:1526930220665};\\\", \\\"{x:691,y:484,t:1526930220682};\\\", \\\"{x:680,y:484,t:1526930220698};\\\", \\\"{x:669,y:484,t:1526930220715};\\\", \\\"{x:661,y:484,t:1526930220732};\\\", \\\"{x:650,y:487,t:1526930220748};\\\", \\\"{x:646,y:488,t:1526930220765};\\\", \\\"{x:638,y:489,t:1526930220781};\\\", \\\"{x:635,y:489,t:1526930220798};\\\", \\\"{x:631,y:491,t:1526930220815};\\\", \\\"{x:629,y:492,t:1526930220838};\\\", \\\"{x:627,y:492,t:1526930220849};\\\", \\\"{x:626,y:493,t:1526930220865};\\\", \\\"{x:623,y:493,t:1526930220882};\\\", \\\"{x:622,y:494,t:1526930220899};\\\", \\\"{x:622,y:495,t:1526930220915};\\\", \\\"{x:621,y:496,t:1526930220931};\\\", \\\"{x:619,y:496,t:1526930220949};\\\", \\\"{x:618,y:497,t:1526930220975};\\\", \\\"{x:616,y:498,t:1526930221006};\\\", \\\"{x:615,y:498,t:1526930221030};\\\", \\\"{x:614,y:498,t:1526930221039};\\\", \\\"{x:614,y:498,t:1526930221082};\\\", \\\"{x:614,y:499,t:1526930221135};\\\", \\\"{x:614,y:500,t:1526930221149};\\\", \\\"{x:617,y:505,t:1526930221165};\\\", \\\"{x:621,y:515,t:1526930221182};\\\", \\\"{x:625,y:541,t:1526930221199};\\\", \\\"{x:628,y:567,t:1526930221216};\\\", \\\"{x:631,y:594,t:1526930221232};\\\", \\\"{x:634,y:625,t:1526930221249};\\\", \\\"{x:630,y:648,t:1526930221266};\\\", \\\"{x:626,y:671,t:1526930221282};\\\", \\\"{x:620,y:689,t:1526930221299};\\\", \\\"{x:616,y:706,t:1526930221316};\\\", \\\"{x:609,y:719,t:1526930221332};\\\", \\\"{x:604,y:730,t:1526930221348};\\\", \\\"{x:600,y:736,t:1526930221365};\\\", \\\"{x:595,y:741,t:1526930221381};\\\", \\\"{x:587,y:743,t:1526930221399};\\\", \\\"{x:582,y:749,t:1526930221416};\\\", \\\"{x:578,y:752,t:1526930221432};\\\", \\\"{x:575,y:754,t:1526930221448};\\\", \\\"{x:572,y:756,t:1526930221466};\\\", \\\"{x:565,y:759,t:1526930221481};\\\", \\\"{x:553,y:762,t:1526930221499};\\\", \\\"{x:543,y:765,t:1526930221516};\\\", \\\"{x:534,y:766,t:1526930221533};\\\", \\\"{x:524,y:766,t:1526930221549};\\\", \\\"{x:519,y:766,t:1526930221566};\\\", \\\"{x:513,y:763,t:1526930221582};\\\", \\\"{x:511,y:761,t:1526930221599};\\\", \\\"{x:510,y:761,t:1526930221616};\\\", \\\"{x:509,y:760,t:1526930221633};\\\", \\\"{x:509,y:758,t:1526930221863};\\\", \\\"{x:509,y:757,t:1526930221871};\\\", \\\"{x:509,y:755,t:1526930221883};\\\", \\\"{x:509,y:751,t:1526930221899};\\\", \\\"{x:510,y:750,t:1526930221915};\\\", \\\"{x:510,y:748,t:1526930221932};\\\", \\\"{x:511,y:746,t:1526930221948};\\\", \\\"{x:512,y:744,t:1526930221965};\\\", \\\"{x:512,y:743,t:1526930222134};\\\", \\\"{x:515,y:742,t:1526930222150};\\\", \\\"{x:524,y:742,t:1526930222165};\\\", \\\"{x:544,y:744,t:1526930222182};\\\", \\\"{x:562,y:748,t:1526930222199};\\\", \\\"{x:585,y:754,t:1526930222215};\\\", \\\"{x:626,y:762,t:1526930222233};\\\", \\\"{x:654,y:768,t:1526930222250};\\\", \\\"{x:681,y:773,t:1526930222266};\\\", \\\"{x:713,y:780,t:1526930222283};\\\", \\\"{x:743,y:792,t:1526930222300};\\\", \\\"{x:759,y:800,t:1526930222316};\\\", \\\"{x:777,y:802,t:1526930222333};\\\", \\\"{x:797,y:805,t:1526930222350};\\\", \\\"{x:811,y:805,t:1526930222366};\\\", \\\"{x:827,y:806,t:1526930222382};\\\", \\\"{x:834,y:807,t:1526930222400};\\\", \\\"{x:837,y:808,t:1526930222416};\\\", \\\"{x:840,y:808,t:1526930222433};\\\" ] }, { \\\"rt\\\": 11951, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 18, \\\"time_elapsed\\\": 587077, \\\"internal_node_id\\\": \\\"0.0-6.0-8.0\\\", \\\"subject\\\": \\\"GQ35Z\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"charlie\\\", \\\"condition\\\": \\\"111\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"endtime\\\", \\\"q\\\": 14, \\\"clicks\\\": 1, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XInside-YFull\\\", \\\"correct\\\": 1, \\\"orth_correct\\\": 0, \\\"answer\\\": [ \\\"X\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"\\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:840,y:809,t:1526930223775};\\\", \\\"{x:840,y:809,t:1526930223785};\\\", \\\"{x:744,y:801,t:1526930224120};\\\", \\\"{x:744,y:801,t:1526930224247};\\\", \\\"{x:743,y:800,t:1526930224734};\\\", \\\"{x:743,y:799,t:1526930224751};\\\", \\\"{x:745,y:797,t:1526930224768};\\\", \\\"{x:747,y:797,t:1526930224785};\\\", \\\"{x:749,y:795,t:1526930224801};\\\", \\\"{x:754,y:794,t:1526930224818};\\\", \\\"{x:759,y:794,t:1526930224835};\\\", \\\"{x:766,y:794,t:1526930224852};\\\", \\\"{x:776,y:795,t:1526930224868};\\\", \\\"{x:790,y:800,t:1526930224885};\\\", \\\"{x:807,y:810,t:1526930224902};\\\", \\\"{x:828,y:816,t:1526930224917};\\\", \\\"{x:855,y:826,t:1526930224935};\\\", \\\"{x:872,y:831,t:1526930224952};\\\", \\\"{x:893,y:838,t:1526930224968};\\\", \\\"{x:911,y:843,t:1526930224985};\\\", \\\"{x:929,y:849,t:1526930225002};\\\", \\\"{x:948,y:853,t:1526930225018};\\\", \\\"{x:959,y:854,t:1526930225035};\\\", \\\"{x:966,y:855,t:1526930225052};\\\", \\\"{x:974,y:857,t:1526930225068};\\\", \\\"{x:986,y:860,t:1526930225086};\\\", \\\"{x:1008,y:866,t:1526930225102};\\\", \\\"{x:1024,y:873,t:1526930225118};\\\", \\\"{x:1051,y:878,t:1526930225134};\\\", \\\"{x:1065,y:881,t:1526930225152};\\\", \\\"{x:1079,y:887,t:1526930225168};\\\", \\\"{x:1088,y:889,t:1526930225185};\\\", \\\"{x:1103,y:893,t:1526930225202};\\\", \\\"{x:1114,y:896,t:1526930225219};\\\", \\\"{x:1130,y:901,t:1526930225235};\\\", \\\"{x:1146,y:909,t:1526930225252};\\\", \\\"{x:1162,y:916,t:1526930225268};\\\", \\\"{x:1182,y:926,t:1526930225285};\\\", \\\"{x:1199,y:934,t:1526930225303};\\\", \\\"{x:1220,y:941,t:1526930225319};\\\", \\\"{x:1221,y:941,t:1526930225351};\\\", \\\"{x:1224,y:940,t:1526930225751};\\\", \\\"{x:1225,y:940,t:1526930225759};\\\", \\\"{x:1225,y:938,t:1526930225769};\\\", \\\"{x:1226,y:939,t:1526930225822};\\\", \\\"{x:1230,y:939,t:1526930225836};\\\", \\\"{x:1247,y:932,t:1526930225852};\\\", \\\"{x:1259,y:930,t:1526930225870};\\\", \\\"{x:1277,y:929,t:1526930225886};\\\", \\\"{x:1293,y:929,t:1526930225902};\\\", \\\"{x:1320,y:929,t:1526930225919};\\\", \\\"{x:1336,y:931,t:1526930225936};\\\", \\\"{x:1352,y:932,t:1526930225952};\\\", \\\"{x:1372,y:937,t:1526930225969};\\\", \\\"{x:1394,y:939,t:1526930225986};\\\", \\\"{x:1411,y:942,t:1526930226003};\\\", \\\"{x:1429,y:943,t:1526930226019};\\\", \\\"{x:1431,y:944,t:1526930226036};\\\", \\\"{x:1443,y:944,t:1526930226052};\\\", \\\"{x:1459,y:949,t:1526930226069};\\\", \\\"{x:1475,y:949,t:1526930226086};\\\", \\\"{x:1490,y:949,t:1526930226103};\\\", \\\"{x:1503,y:949,t:1526930226119};\\\", \\\"{x:1509,y:949,t:1526930226136};\\\", \\\"{x:1513,y:949,t:1526930226152};\\\", \\\"{x:1522,y:949,t:1526930226169};\\\", \\\"{x:1537,y:949,t:1526930226186};\\\", \\\"{x:1543,y:949,t:1526930226203};\\\", \\\"{x:1549,y:948,t:1526930226219};\\\", \\\"{x:1556,y:948,t:1526930226236};\\\", \\\"{x:1572,y:949,t:1526930226253};\\\", \\\"{x:1582,y:953,t:1526930226269};\\\", \\\"{x:1587,y:954,t:1526930226287};\\\", \\\"{x:1590,y:956,t:1526930226303};\\\", \\\"{x:1595,y:958,t:1526930226319};\\\", \\\"{x:1599,y:958,t:1526930226336};\\\", \\\"{x:1605,y:960,t:1526930226353};\\\", \\\"{x:1607,y:962,t:1526930226369};\\\", \\\"{x:1612,y:964,t:1526930226386};\\\", \\\"{x:1617,y:965,t:1526930226403};\\\", \\\"{x:1620,y:966,t:1526930226419};\\\", \\\"{x:1624,y:966,t:1526930226436};\\\", \\\"{x:1625,y:966,t:1526930226559};\\\", \\\"{x:1624,y:968,t:1526930226575};\\\", \\\"{x:1623,y:968,t:1526930226590};\\\", \\\"{x:1621,y:968,t:1526930226603};\\\", \\\"{x:1613,y:968,t:1526930226619};\\\", \\\"{x:1605,y:968,t:1526930226636};\\\", \\\"{x:1604,y:968,t:1526930226653};\\\", \\\"{x:1598,y:968,t:1526930226669};\\\", \\\"{x:1589,y:968,t:1526930226686};\\\", \\\"{x:1580,y:968,t:1526930226703};\\\", \\\"{x:1572,y:968,t:1526930226720};\\\", \\\"{x:1568,y:968,t:1526930226736};\\\", \\\"{x:1567,y:968,t:1526930226753};\\\", \\\"{x:1564,y:968,t:1526930226770};\\\", \\\"{x:1562,y:968,t:1526930226823};\\\", \\\"{x:1557,y:968,t:1526930226838};\\\", \\\"{x:1555,y:968,t:1526930226853};\\\", \\\"{x:1550,y:966,t:1526930226870};\\\", \\\"{x:1549,y:966,t:1526930226999};\\\", \\\"{x:1549,y:965,t:1526930227030};\\\", \\\"{x:1549,y:964,t:1526930227046};\\\", \\\"{x:1549,y:963,t:1526930227055};\\\", \\\"{x:1548,y:960,t:1526930227071};\\\", \\\"{x:1548,y:959,t:1526930227087};\\\", \\\"{x:1547,y:956,t:1526930227103};\\\", \\\"{x:1546,y:954,t:1526930227167};\\\", \\\"{x:1546,y:952,t:1526930227182};\\\", \\\"{x:1546,y:950,t:1526930227199};\\\", \\\"{x:1546,y:949,t:1526930227206};\\\", \\\"{x:1546,y:948,t:1526930227231};\\\", \\\"{x:1545,y:947,t:1526930227239};\\\", \\\"{x:1545,y:945,t:1526930227359};\\\", \\\"{x:1543,y:944,t:1526930227370};\\\", \\\"{x:1543,y:943,t:1526930227387};\\\", \\\"{x:1542,y:942,t:1526930227403};\\\", \\\"{x:1540,y:941,t:1526930227420};\\\", \\\"{x:1538,y:938,t:1526930227437};\\\", \\\"{x:1537,y:937,t:1526930227453};\\\", \\\"{x:1536,y:936,t:1526930227471};\\\", \\\"{x:1536,y:935,t:1526930227663};\\\", \\\"{x:1536,y:934,t:1526930227670};\\\", \\\"{x:1535,y:932,t:1526930227688};\\\", \\\"{x:1528,y:929,t:1526930227704};\\\", \\\"{x:1523,y:923,t:1526930227720};\\\", \\\"{x:1521,y:921,t:1526930227737};\\\", \\\"{x:1520,y:919,t:1526930227755};\\\", \\\"{x:1520,y:918,t:1526930227770};\\\", \\\"{x:1518,y:916,t:1526930227787};\\\", \\\"{x:1518,y:912,t:1526930227804};\\\", \\\"{x:1518,y:907,t:1526930227820};\\\", \\\"{x:1517,y:906,t:1526930227837};\\\", \\\"{x:1514,y:901,t:1526930227854};\\\", \\\"{x:1511,y:897,t:1526930227870};\\\", \\\"{x:1507,y:891,t:1526930227887};\\\", \\\"{x:1505,y:886,t:1526930227904};\\\", \\\"{x:1500,y:877,t:1526930227920};\\\", \\\"{x:1489,y:868,t:1526930227938};\\\", \\\"{x:1484,y:864,t:1526930227954};\\\", \\\"{x:1463,y:857,t:1526930227970};\\\", \\\"{x:1419,y:848,t:1526930227987};\\\", \\\"{x:1370,y:836,t:1526930228004};\\\", \\\"{x:1309,y:823,t:1526930228020};\\\", \\\"{x:1256,y:815,t:1526930228037};\\\", \\\"{x:1221,y:809,t:1526930228054};\\\", \\\"{x:1191,y:797,t:1526930228070};\\\", \\\"{x:1156,y:787,t:1526930228087};\\\", \\\"{x:1135,y:779,t:1526930228104};\\\", \\\"{x:1120,y:771,t:1526930228121};\\\", \\\"{x:1104,y:764,t:1526930228137};\\\", \\\"{x:1090,y:754,t:1526930228154};\\\", \\\"{x:1070,y:740,t:1526930228171};\\\", \\\"{x:1046,y:722,t:1526930228187};\\\", \\\"{x:1019,y:702,t:1526930228204};\\\", \\\"{x:993,y:683,t:1526930228221};\\\", \\\"{x:966,y:669,t:1526930228238};\\\", \\\"{x:940,y:663,t:1526930228254};\\\", \\\"{x:911,y:656,t:1526930228271};\\\", \\\"{x:896,y:654,t:1526930228287};\\\", \\\"{x:871,y:649,t:1526930228304};\\\", \\\"{x:846,y:648,t:1526930228321};\\\", \\\"{x:820,y:645,t:1526930228337};\\\", \\\"{x:791,y:642,t:1526930228354};\\\", \\\"{x:759,y:641,t:1526930228371};\\\", \\\"{x:728,y:636,t:1526930228387};\\\", \\\"{x:703,y:633,t:1526930228404};\\\", \\\"{x:684,y:633,t:1526930228421};\\\", \\\"{x:673,y:632,t:1526930228437};\\\", \\\"{x:668,y:632,t:1526930228454};\\\", \\\"{x:664,y:632,t:1526930228471};\\\", \\\"{x:651,y:632,t:1526930228487};\\\", \\\"{x:589,y:650,t:1526930228504};\\\", \\\"{x:538,y:659,t:1526930228521};\\\", \\\"{x:517,y:662,t:1526930228538};\\\", \\\"{x:510,y:662,t:1526930228554};\\\", \\\"{x:503,y:662,t:1526930228571};\\\", \\\"{x:496,y:662,t:1526930228589};\\\", \\\"{x:491,y:661,t:1526930228604};\\\", \\\"{x:486,y:659,t:1526930228621};\\\", \\\"{x:482,y:658,t:1526930228638};\\\", \\\"{x:464,y:649,t:1526930228655};\\\", \\\"{x:445,y:645,t:1526930228671};\\\", \\\"{x:424,y:638,t:1526930228689};\\\", \\\"{x:403,y:628,t:1526930228707};\\\", \\\"{x:376,y:622,t:1526930228722};\\\", \\\"{x:349,y:621,t:1526930228738};\\\", \\\"{x:322,y:615,t:1526930228756};\\\", \\\"{x:296,y:611,t:1526930228771};\\\", \\\"{x:279,y:608,t:1526930228788};\\\", \\\"{x:265,y:607,t:1526930228806};\\\", \\\"{x:258,y:604,t:1526930228821};\\\", \\\"{x:254,y:602,t:1526930228838};\\\", \\\"{x:252,y:600,t:1526930228855};\\\", \\\"{x:252,y:599,t:1526930228926};\\\", \\\"{x:252,y:598,t:1526930228942};\\\", \\\"{x:255,y:596,t:1526930228955};\\\", \\\"{x:261,y:592,t:1526930228972};\\\", \\\"{x:277,y:584,t:1526930228988};\\\", \\\"{x:317,y:576,t:1526930229005};\\\", \\\"{x:372,y:570,t:1526930229021};\\\", \\\"{x:434,y:560,t:1526930229039};\\\", \\\"{x:546,y:556,t:1526930229055};\\\", \\\"{x:619,y:553,t:1526930229073};\\\", \\\"{x:708,y:553,t:1526930229089};\\\", \\\"{x:811,y:568,t:1526930229106};\\\", \\\"{x:892,y:582,t:1526930229122};\\\", \\\"{x:951,y:597,t:1526930229138};\\\", \\\"{x:981,y:603,t:1526930229155};\\\", \\\"{x:1005,y:606,t:1526930229173};\\\", \\\"{x:1023,y:606,t:1526930229188};\\\", \\\"{x:1028,y:606,t:1526930229205};\\\", \\\"{x:1031,y:606,t:1526930229222};\\\", \\\"{x:1031,y:602,t:1526930229303};\\\", \\\"{x:1026,y:598,t:1526930229310};\\\", \\\"{x:1019,y:594,t:1526930229322};\\\", \\\"{x:1000,y:592,t:1526930229338};\\\", \\\"{x:978,y:590,t:1526930229356};\\\", \\\"{x:960,y:590,t:1526930229372};\\\", \\\"{x:939,y:590,t:1526930229389};\\\", \\\"{x:929,y:591,t:1526930229405};\\\", \\\"{x:924,y:591,t:1526930229422};\\\", \\\"{x:917,y:591,t:1526930229438};\\\", \\\"{x:901,y:590,t:1526930229455};\\\", \\\"{x:877,y:588,t:1526930229472};\\\", \\\"{x:854,y:588,t:1526930229489};\\\", \\\"{x:828,y:588,t:1526930229505};\\\", \\\"{x:794,y:588,t:1526930229523};\\\", \\\"{x:773,y:587,t:1526930229539};\\\", \\\"{x:755,y:583,t:1526930229555};\\\", \\\"{x:744,y:583,t:1526930229572};\\\", \\\"{x:740,y:583,t:1526930229589};\\\", \\\"{x:738,y:583,t:1526930229605};\\\", \\\"{x:737,y:583,t:1526930229647};\\\", \\\"{x:734,y:583,t:1526930229655};\\\", \\\"{x:724,y:585,t:1526930229672};\\\", \\\"{x:719,y:586,t:1526930229691};\\\", \\\"{x:716,y:587,t:1526930229705};\\\", \\\"{x:703,y:587,t:1526930229722};\\\", \\\"{x:696,y:587,t:1526930229739};\\\", \\\"{x:693,y:587,t:1526930229755};\\\", \\\"{x:689,y:586,t:1526930229773};\\\", \\\"{x:688,y:586,t:1526930229789};\\\", \\\"{x:687,y:585,t:1526930229806};\\\", \\\"{x:684,y:584,t:1526930229823};\\\", \\\"{x:676,y:584,t:1526930229839};\\\", \\\"{x:665,y:583,t:1526930229855};\\\", \\\"{x:659,y:583,t:1526930229872};\\\", \\\"{x:650,y:580,t:1526930229889};\\\", \\\"{x:647,y:579,t:1526930229906};\\\", \\\"{x:645,y:579,t:1526930229922};\\\", \\\"{x:644,y:579,t:1526930229939};\\\", \\\"{x:643,y:579,t:1526930229966};\\\", \\\"{x:641,y:579,t:1526930229975};\\\", \\\"{x:639,y:579,t:1526930229989};\\\", \\\"{x:629,y:579,t:1526930230006};\\\", \\\"{x:624,y:579,t:1526930230022};\\\", \\\"{x:617,y:580,t:1526930230039};\\\", \\\"{x:615,y:581,t:1526930230056};\\\", \\\"{x:614,y:581,t:1526930230072};\\\", \\\"{x:612,y:581,t:1526930230089};\\\", \\\"{x:606,y:582,t:1526930230106};\\\", \\\"{x:601,y:584,t:1526930230119};\\\", \\\"{x:598,y:584,t:1526930230139};\\\", \\\"{x:596,y:585,t:1526930230156};\\\", \\\"{x:596,y:585,t:1526930230214};\\\", \\\"{x:596,y:586,t:1526930230334};\\\", \\\"{x:596,y:587,t:1526930230342};\\\", \\\"{x:596,y:588,t:1526930230527};\\\", \\\"{x:598,y:588,t:1526930230550};\\\", \\\"{x:599,y:588,t:1526930230583};\\\", \\\"{x:601,y:588,t:1526930230607};\\\", \\\"{x:603,y:587,t:1526930230783};\\\", \\\"{x:604,y:587,t:1526930230799};\\\", \\\"{x:605,y:587,t:1526930230870};\\\", \\\"{x:607,y:587,t:1526930230902};\\\", \\\"{x:612,y:587,t:1526930230910};\\\", \\\"{x:614,y:589,t:1526930230923};\\\", \\\"{x:619,y:592,t:1526930230940};\\\", \\\"{x:621,y:593,t:1526930230956};\\\", \\\"{x:624,y:595,t:1526930230974};\\\", \\\"{x:629,y:601,t:1526930230991};\\\", \\\"{x:643,y:613,t:1526930231007};\\\", \\\"{x:670,y:637,t:1526930231024};\\\", \\\"{x:715,y:667,t:1526930231040};\\\", \\\"{x:740,y:687,t:1526930231056};\\\", \\\"{x:754,y:699,t:1526930231073};\\\", \\\"{x:762,y:705,t:1526930231090};\\\", \\\"{x:765,y:709,t:1526930231106};\\\", \\\"{x:769,y:712,t:1526930231123};\\\", \\\"{x:770,y:713,t:1526930231140};\\\", \\\"{x:772,y:715,t:1526930231157};\\\", \\\"{x:766,y:720,t:1526930232092};\\\", \\\"{x:765,y:720,t:1526930232106};\\\", \\\"{x:764,y:721,t:1526930232123};\\\", \\\"{x:762,y:722,t:1526930232139};\\\", \\\"{x:761,y:722,t:1526930232158};\\\", \\\"{x:759,y:723,t:1526930232173};\\\", \\\"{x:755,y:727,t:1526930232189};\\\", \\\"{x:751,y:728,t:1526930232206};\\\", \\\"{x:747,y:730,t:1526930232222};\\\", \\\"{x:742,y:730,t:1526930232239};\\\", \\\"{x:738,y:730,t:1526930232256};\\\", \\\"{x:733,y:731,t:1526930232272};\\\", \\\"{x:726,y:731,t:1526930232290};\\\", \\\"{x:721,y:731,t:1526930232306};\\\", \\\"{x:717,y:731,t:1526930232323};\\\", \\\"{x:714,y:731,t:1526930232339};\\\", \\\"{x:708,y:733,t:1526930232356};\\\", \\\"{x:707,y:733,t:1526930232372};\\\", \\\"{x:706,y:733,t:1526930232393};\\\", \\\"{x:703,y:733,t:1526930232410};\\\", \\\"{x:702,y:733,t:1526930232426};\\\", \\\"{x:674,y:728,t:1526930232727};\\\", \\\"{x:670,y:727,t:1526930232743};\\\", \\\"{x:669,y:727,t:1526930232759};\\\", \\\"{x:668,y:727,t:1526930232776};\\\", \\\"{x:667,y:727,t:1526930232810};\\\", \\\"{x:665,y:727,t:1526930232843};\\\", \\\"{x:664,y:727,t:1526930232890};\\\", \\\"{x:662,y:727,t:1526930232906};\\\", \\\"{x:661,y:727,t:1526930232922};\\\", \\\"{x:660,y:728,t:1526930232938};\\\", \\\"{x:659,y:729,t:1526930232946};\\\", \\\"{x:657,y:729,t:1526930232959};\\\", \\\"{x:657,y:730,t:1526930232976};\\\", \\\"{x:654,y:731,t:1526930232993};\\\", \\\"{x:652,y:732,t:1526930233009};\\\", \\\"{x:651,y:732,t:1526930233026};\\\", \\\"{x:645,y:735,t:1526930233042};\\\", \\\"{x:643,y:736,t:1526930233059};\\\", \\\"{x:642,y:736,t:1526930233076};\\\", \\\"{x:632,y:737,t:1526930233093};\\\", \\\"{x:617,y:739,t:1526930233109};\\\", \\\"{x:604,y:741,t:1526930233126};\\\", \\\"{x:591,y:741,t:1526930233143};\\\", \\\"{x:579,y:741,t:1526930233159};\\\", \\\"{x:574,y:741,t:1526930233176};\\\", \\\"{x:571,y:741,t:1526930233193};\\\", \\\"{x:567,y:742,t:1526930233209};\\\", \\\"{x:549,y:744,t:1526930233227};\\\", \\\"{x:534,y:744,t:1526930233243};\\\", \\\"{x:523,y:744,t:1526930233259};\\\", \\\"{x:516,y:744,t:1526930233279};\\\", \\\"{x:515,y:744,t:1526930233296};\\\" ] }, { \\\"rt\\\": 14111, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 19, \\\"time_elapsed\\\": 602421, \\\"internal_node_id\\\": \\\"0.0-6.0-9.0\\\", \\\"subject\\\": \\\"GQ35Z\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"charlie\\\", \\\"condition\\\": \\\"111\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"midpoint\\\", \\\"q\\\": 15, \\\"clicks\\\": 2, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XInside-YFull\\\", \\\"correct\\\": 1, \\\"orth_correct\\\": 0, \\\"answer\\\": [ \\\"K\\\", \\\"X\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-01 PM-02 PM-X -X -X -4\\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:518,y:744,t:1526930239946};\\\", \\\"{x:524,y:745,t:1526930239954};\\\", \\\"{x:530,y:749,t:1526930239967};\\\", \\\"{x:545,y:755,t:1526930239984};\\\", \\\"{x:562,y:760,t:1526930240002};\\\", \\\"{x:586,y:771,t:1526930240018};\\\", \\\"{x:610,y:782,t:1526930240034};\\\", \\\"{x:633,y:790,t:1526930240049};\\\", \\\"{x:735,y:817,t:1526930240066};\\\", \\\"{x:773,y:828,t:1526930240083};\\\", \\\"{x:820,y:835,t:1526930240100};\\\", \\\"{x:848,y:838,t:1526930240116};\\\", \\\"{x:868,y:839,t:1526930240133};\\\", \\\"{x:887,y:842,t:1526930240149};\\\", \\\"{x:908,y:845,t:1526930240167};\\\", \\\"{x:926,y:850,t:1526930240184};\\\", \\\"{x:947,y:855,t:1526930240199};\\\", \\\"{x:968,y:860,t:1526930240216};\\\", \\\"{x:999,y:866,t:1526930240233};\\\", \\\"{x:1083,y:882,t:1526930240250};\\\", \\\"{x:1146,y:895,t:1526930240266};\\\", \\\"{x:1173,y:899,t:1526930240283};\\\", \\\"{x:1191,y:901,t:1526930240300};\\\", \\\"{x:1202,y:905,t:1526930240316};\\\", \\\"{x:1210,y:906,t:1526930240333};\\\", \\\"{x:1218,y:906,t:1526930240350};\\\", \\\"{x:1223,y:906,t:1526930240366};\\\", \\\"{x:1226,y:906,t:1526930240383};\\\", \\\"{x:1228,y:906,t:1526930240400};\\\", \\\"{x:1230,y:906,t:1526930240416};\\\", \\\"{x:1238,y:906,t:1526930240433};\\\", \\\"{x:1249,y:904,t:1526930240449};\\\", \\\"{x:1253,y:904,t:1526930240466};\\\", \\\"{x:1255,y:904,t:1526930240483};\\\", \\\"{x:1257,y:904,t:1526930240506};\\\", \\\"{x:1261,y:904,t:1526930240522};\\\", \\\"{x:1262,y:904,t:1526930240538};\\\", \\\"{x:1263,y:904,t:1526930240550};\\\", \\\"{x:1266,y:904,t:1526930240566};\\\", \\\"{x:1271,y:904,t:1526930240583};\\\", \\\"{x:1273,y:905,t:1526930240601};\\\", \\\"{x:1276,y:906,t:1526930240616};\\\", \\\"{x:1281,y:906,t:1526930240634};\\\", \\\"{x:1283,y:907,t:1526930240649};\\\", \\\"{x:1286,y:909,t:1526930240666};\\\", \\\"{x:1290,y:909,t:1526930240683};\\\", \\\"{x:1295,y:910,t:1526930240700};\\\", \\\"{x:1297,y:910,t:1526930240716};\\\", \\\"{x:1304,y:913,t:1526930240733};\\\", \\\"{x:1306,y:915,t:1526930240750};\\\", \\\"{x:1314,y:918,t:1526930240766};\\\", \\\"{x:1318,y:919,t:1526930240784};\\\", \\\"{x:1319,y:920,t:1526930240800};\\\", \\\"{x:1321,y:920,t:1526930240816};\\\", \\\"{x:1322,y:921,t:1526930240833};\\\", \\\"{x:1323,y:922,t:1526930240850};\\\", \\\"{x:1326,y:924,t:1526930240866};\\\", \\\"{x:1327,y:924,t:1526930240924};\\\", \\\"{x:1328,y:925,t:1526930240933};\\\", \\\"{x:1332,y:928,t:1526930240951};\\\", \\\"{x:1336,y:929,t:1526930240967};\\\", \\\"{x:1338,y:931,t:1526930240983};\\\", \\\"{x:1339,y:932,t:1526930241000};\\\", \\\"{x:1343,y:934,t:1526930241016};\\\", \\\"{x:1346,y:936,t:1526930241033};\\\", \\\"{x:1355,y:943,t:1526930241050};\\\", \\\"{x:1364,y:948,t:1526930241066};\\\", \\\"{x:1373,y:953,t:1526930241084};\\\", \\\"{x:1382,y:957,t:1526930241100};\\\", \\\"{x:1390,y:961,t:1526930241116};\\\", \\\"{x:1397,y:965,t:1526930241133};\\\", \\\"{x:1401,y:966,t:1526930241150};\\\", \\\"{x:1402,y:967,t:1526930241168};\\\", \\\"{x:1403,y:967,t:1526930241183};\\\", \\\"{x:1405,y:968,t:1526930241200};\\\", \\\"{x:1407,y:969,t:1526930241217};\\\", \\\"{x:1408,y:970,t:1526930241234};\\\", \\\"{x:1412,y:975,t:1526930241250};\\\", \\\"{x:1414,y:977,t:1526930241268};\\\", \\\"{x:1416,y:978,t:1526930241284};\\\", \\\"{x:1417,y:979,t:1526930241300};\\\", \\\"{x:1420,y:982,t:1526930241317};\\\", \\\"{x:1422,y:985,t:1526930241334};\\\", \\\"{x:1424,y:987,t:1526930241350};\\\", \\\"{x:1427,y:991,t:1526930241368};\\\", \\\"{x:1429,y:994,t:1526930241383};\\\", \\\"{x:1429,y:995,t:1526930241400};\\\", \\\"{x:1429,y:996,t:1526930241418};\\\", \\\"{x:1426,y:996,t:1526930241441};\\\", \\\"{x:1422,y:996,t:1526930241450};\\\", \\\"{x:1417,y:997,t:1526930241467};\\\", \\\"{x:1415,y:997,t:1526930241484};\\\", \\\"{x:1414,y:997,t:1526930241501};\\\", \\\"{x:1409,y:997,t:1526930241517};\\\", \\\"{x:1405,y:997,t:1526930241533};\\\", \\\"{x:1401,y:997,t:1526930241551};\\\", \\\"{x:1398,y:997,t:1526930241568};\\\", \\\"{x:1396,y:997,t:1526930241583};\\\", \\\"{x:1396,y:996,t:1526930241609};\\\", \\\"{x:1395,y:996,t:1526930241626};\\\", \\\"{x:1393,y:996,t:1526930241633};\\\", \\\"{x:1392,y:996,t:1526930241650};\\\", \\\"{x:1391,y:996,t:1526930241667};\\\", \\\"{x:1390,y:996,t:1526930241683};\\\", \\\"{x:1388,y:996,t:1526930241700};\\\", \\\"{x:1389,y:996,t:1526930241883};\\\", \\\"{x:1390,y:996,t:1526930241890};\\\", \\\"{x:1392,y:996,t:1526930241900};\\\", \\\"{x:1398,y:996,t:1526930241918};\\\", \\\"{x:1400,y:996,t:1526930241934};\\\", \\\"{x:1402,y:996,t:1526930241950};\\\", \\\"{x:1405,y:996,t:1526930241967};\\\", \\\"{x:1409,y:996,t:1526930241985};\\\", \\\"{x:1411,y:997,t:1526930242000};\\\", \\\"{x:1414,y:997,t:1526930242018};\\\", \\\"{x:1418,y:997,t:1526930242034};\\\", \\\"{x:1424,y:997,t:1526930242051};\\\", \\\"{x:1429,y:997,t:1526930242067};\\\", \\\"{x:1435,y:997,t:1526930242084};\\\", \\\"{x:1439,y:997,t:1526930242100};\\\", \\\"{x:1441,y:997,t:1526930242117};\\\", \\\"{x:1442,y:997,t:1526930242134};\\\", \\\"{x:1443,y:997,t:1526930242170};\\\", \\\"{x:1445,y:996,t:1526930242184};\\\", \\\"{x:1448,y:996,t:1526930242200};\\\", \\\"{x:1453,y:995,t:1526930242217};\\\", \\\"{x:1457,y:992,t:1526930242234};\\\", \\\"{x:1457,y:991,t:1526930242314};\\\", \\\"{x:1458,y:988,t:1526930242322};\\\", \\\"{x:1459,y:986,t:1526930242335};\\\", \\\"{x:1461,y:984,t:1526930242350};\\\", \\\"{x:1461,y:983,t:1526930242378};\\\", \\\"{x:1461,y:982,t:1526930242435};\\\", \\\"{x:1461,y:981,t:1526930242514};\\\", \\\"{x:1461,y:980,t:1526930242554};\\\", \\\"{x:1462,y:980,t:1526930242567};\\\", \\\"{x:1462,y:979,t:1526930242585};\\\", \\\"{x:1463,y:977,t:1526930242600};\\\", \\\"{x:1464,y:975,t:1526930242626};\\\", \\\"{x:1466,y:975,t:1526930242650};\\\", \\\"{x:1468,y:974,t:1526930242658};\\\", \\\"{x:1469,y:973,t:1526930242674};\\\", \\\"{x:1471,y:972,t:1526930242690};\\\", \\\"{x:1472,y:972,t:1526930242701};\\\", \\\"{x:1473,y:971,t:1526930242717};\\\", \\\"{x:1474,y:971,t:1526930242734};\\\", \\\"{x:1476,y:971,t:1526930242751};\\\", \\\"{x:1478,y:971,t:1526930242767};\\\", \\\"{x:1481,y:969,t:1526930242784};\\\", \\\"{x:1483,y:969,t:1526930242801};\\\", \\\"{x:1485,y:968,t:1526930242818};\\\", \\\"{x:1486,y:968,t:1526930242834};\\\", \\\"{x:1488,y:967,t:1526930242922};\\\", \\\"{x:1488,y:966,t:1526930242946};\\\", \\\"{x:1488,y:965,t:1526930242954};\\\", \\\"{x:1488,y:963,t:1526930242970};\\\", \\\"{x:1488,y:962,t:1526930242985};\\\", \\\"{x:1489,y:959,t:1526930243001};\\\", \\\"{x:1489,y:958,t:1526930243018};\\\", \\\"{x:1489,y:956,t:1526930243035};\\\", \\\"{x:1490,y:954,t:1526930243051};\\\", \\\"{x:1490,y:950,t:1526930243067};\\\", \\\"{x:1490,y:948,t:1526930243084};\\\", \\\"{x:1492,y:946,t:1526930243101};\\\", \\\"{x:1492,y:945,t:1526930243117};\\\", \\\"{x:1494,y:944,t:1526930243162};\\\", \\\"{x:1494,y:943,t:1526930243178};\\\", \\\"{x:1494,y:942,t:1526930243186};\\\", \\\"{x:1494,y:941,t:1526930243201};\\\", \\\"{x:1495,y:939,t:1526930243217};\\\", \\\"{x:1496,y:931,t:1526930243234};\\\", \\\"{x:1496,y:926,t:1526930243252};\\\", \\\"{x:1496,y:919,t:1526930243267};\\\", \\\"{x:1496,y:912,t:1526930243284};\\\", \\\"{x:1496,y:903,t:1526930243302};\\\", \\\"{x:1496,y:892,t:1526930243318};\\\", \\\"{x:1492,y:879,t:1526930243334};\\\", \\\"{x:1488,y:867,t:1526930243352};\\\", \\\"{x:1487,y:861,t:1526930243368};\\\", \\\"{x:1487,y:855,t:1526930243384};\\\", \\\"{x:1486,y:849,t:1526930243402};\\\", \\\"{x:1484,y:842,t:1526930243418};\\\", \\\"{x:1484,y:838,t:1526930243434};\\\", \\\"{x:1484,y:836,t:1526930243452};\\\", \\\"{x:1483,y:833,t:1526930243469};\\\", \\\"{x:1482,y:830,t:1526930243485};\\\", \\\"{x:1481,y:828,t:1526930243501};\\\", \\\"{x:1480,y:827,t:1526930243517};\\\", \\\"{x:1478,y:827,t:1526930243922};\\\", \\\"{x:1477,y:827,t:1526930243945};\\\", \\\"{x:1477,y:828,t:1526930243961};\\\", \\\"{x:1477,y:830,t:1526930243970};\\\", \\\"{x:1477,y:832,t:1526930243994};\\\", \\\"{x:1478,y:834,t:1526930244138};\\\", \\\"{x:1478,y:835,t:1526930244179};\\\", \\\"{x:1480,y:835,t:1526930245035};\\\", \\\"{x:1481,y:835,t:1526930245146};\\\", \\\"{x:1484,y:834,t:1526930245177};\\\", \\\"{x:1485,y:833,t:1526930245610};\\\", \\\"{x:1485,y:832,t:1526930245634};\\\", \\\"{x:1485,y:831,t:1526930245738};\\\", \\\"{x:1485,y:829,t:1526930246498};\\\", \\\"{x:1486,y:828,t:1526930246506};\\\", \\\"{x:1487,y:828,t:1526930246520};\\\", \\\"{x:1487,y:827,t:1526930246537};\\\", \\\"{x:1487,y:826,t:1526930246552};\\\", \\\"{x:1487,y:825,t:1526930246570};\\\", \\\"{x:1487,y:823,t:1526930246778};\\\", \\\"{x:1487,y:822,t:1526930246786};\\\", \\\"{x:1487,y:820,t:1526930246802};\\\", \\\"{x:1487,y:819,t:1526930246820};\\\", \\\"{x:1486,y:818,t:1526930247306};\\\", \\\"{x:1483,y:818,t:1526930247320};\\\", \\\"{x:1473,y:817,t:1526930247336};\\\", \\\"{x:1453,y:812,t:1526930247353};\\\", \\\"{x:1407,y:797,t:1526930247370};\\\", \\\"{x:1333,y:776,t:1526930247385};\\\", \\\"{x:1247,y:751,t:1526930247402};\\\", \\\"{x:1169,y:731,t:1526930247420};\\\", \\\"{x:1119,y:715,t:1526930247436};\\\", \\\"{x:1062,y:695,t:1526930247452};\\\", \\\"{x:1001,y:669,t:1526930247469};\\\", \\\"{x:936,y:633,t:1526930247486};\\\", \\\"{x:877,y:617,t:1526930247503};\\\", \\\"{x:843,y:601,t:1526930247520};\\\", \\\"{x:825,y:591,t:1526930247540};\\\", \\\"{x:816,y:588,t:1526930247557};\\\", \\\"{x:811,y:586,t:1526930247573};\\\", \\\"{x:806,y:585,t:1526930247591};\\\", \\\"{x:804,y:585,t:1526930247607};\\\", \\\"{x:805,y:583,t:1526930247802};\\\", \\\"{x:811,y:582,t:1526930247809};\\\", \\\"{x:812,y:582,t:1526930247824};\\\", \\\"{x:813,y:582,t:1526930247842};\\\", \\\"{x:814,y:582,t:1526930247858};\\\", \\\"{x:815,y:582,t:1526930247882};\\\", \\\"{x:815,y:581,t:1526930247892};\\\", \\\"{x:815,y:580,t:1526930247946};\\\", \\\"{x:814,y:578,t:1526930247958};\\\", \\\"{x:804,y:574,t:1526930247975};\\\", \\\"{x:793,y:571,t:1526930247991};\\\", \\\"{x:781,y:569,t:1526930248006};\\\", \\\"{x:766,y:566,t:1526930248023};\\\", \\\"{x:749,y:566,t:1526930248040};\\\", \\\"{x:712,y:573,t:1526930248058};\\\", \\\"{x:700,y:574,t:1526930248074};\\\", \\\"{x:687,y:576,t:1526930248090};\\\", \\\"{x:679,y:580,t:1526930248108};\\\", \\\"{x:678,y:580,t:1526930248124};\\\", \\\"{x:678,y:581,t:1526930248209};\\\", \\\"{x:678,y:583,t:1526930248224};\\\", \\\"{x:678,y:584,t:1526930248240};\\\", \\\"{x:674,y:587,t:1526930248257};\\\", \\\"{x:671,y:588,t:1526930248273};\\\", \\\"{x:668,y:589,t:1526930248291};\\\", \\\"{x:666,y:590,t:1526930248308};\\\", \\\"{x:665,y:590,t:1526930248325};\\\", \\\"{x:664,y:591,t:1526930248340};\\\", \\\"{x:661,y:591,t:1526930248357};\\\", \\\"{x:656,y:591,t:1526930248375};\\\", \\\"{x:652,y:591,t:1526930248390};\\\", \\\"{x:649,y:591,t:1526930248407};\\\", \\\"{x:642,y:591,t:1526930248425};\\\", \\\"{x:635,y:591,t:1526930248441};\\\", \\\"{x:631,y:590,t:1526930248458};\\\", \\\"{x:629,y:590,t:1526930248490};\\\", \\\"{x:628,y:590,t:1526930248498};\\\", \\\"{x:627,y:590,t:1526930248513};\\\", \\\"{x:626,y:590,t:1526930248524};\\\", \\\"{x:625,y:590,t:1526930248541};\\\", \\\"{x:621,y:590,t:1526930248558};\\\", \\\"{x:617,y:590,t:1526930248575};\\\", \\\"{x:615,y:592,t:1526930248592};\\\", \\\"{x:614,y:592,t:1526930248618};\\\", \\\"{x:614,y:593,t:1526930248890};\\\", \\\"{x:607,y:592,t:1526930249242};\\\", \\\"{x:596,y:588,t:1526930249258};\\\", \\\"{x:593,y:588,t:1526930249274};\\\", \\\"{x:590,y:588,t:1526930249292};\\\", \\\"{x:582,y:588,t:1526930249309};\\\", \\\"{x:572,y:588,t:1526930249326};\\\", \\\"{x:563,y:588,t:1526930249341};\\\", \\\"{x:549,y:590,t:1526930249359};\\\", \\\"{x:539,y:591,t:1526930249375};\\\", \\\"{x:528,y:594,t:1526930249391};\\\", \\\"{x:518,y:595,t:1526930249408};\\\", \\\"{x:500,y:595,t:1526930249425};\\\", \\\"{x:484,y:595,t:1526930249442};\\\", \\\"{x:476,y:595,t:1526930249458};\\\", \\\"{x:467,y:595,t:1526930249475};\\\", \\\"{x:451,y:593,t:1526930249491};\\\", \\\"{x:432,y:586,t:1526930249508};\\\", \\\"{x:411,y:582,t:1526930249526};\\\", \\\"{x:398,y:578,t:1526930249542};\\\", \\\"{x:390,y:575,t:1526930249558};\\\", \\\"{x:384,y:573,t:1526930249575};\\\", \\\"{x:381,y:573,t:1526930249591};\\\", \\\"{x:380,y:572,t:1526930249608};\\\", \\\"{x:378,y:572,t:1526930249649};\\\", \\\"{x:377,y:572,t:1526930249659};\\\", \\\"{x:377,y:573,t:1526930249675};\\\", \\\"{x:376,y:573,t:1526930249705};\\\", \\\"{x:376,y:574,t:1526930249721};\\\", \\\"{x:376,y:575,t:1526930249730};\\\", \\\"{x:376,y:576,t:1526930249742};\\\", \\\"{x:376,y:578,t:1526930249810};\\\", \\\"{x:376,y:581,t:1526930249826};\\\", \\\"{x:376,y:583,t:1526930249842};\\\", \\\"{x:376,y:584,t:1526930249859};\\\", \\\"{x:376,y:585,t:1526930249889};\\\", \\\"{x:375,y:585,t:1526930249897};\\\", \\\"{x:375,y:586,t:1526930250058};\\\", \\\"{x:375,y:586,t:1526930250061};\\\", \\\"{x:376,y:590,t:1526930250075};\\\", \\\"{x:389,y:600,t:1526930250093};\\\", \\\"{x:403,y:608,t:1526930250109};\\\", \\\"{x:421,y:623,t:1526930250126};\\\", \\\"{x:446,y:641,t:1526930250142};\\\", \\\"{x:464,y:659,t:1526930250161};\\\", \\\"{x:479,y:674,t:1526930250175};\\\", \\\"{x:494,y:692,t:1526930250192};\\\", \\\"{x:510,y:715,t:1526930250210};\\\", \\\"{x:515,y:724,t:1526930250225};\\\", \\\"{x:518,y:732,t:1526930250243};\\\", \\\"{x:518,y:734,t:1526930250260};\\\", \\\"{x:518,y:735,t:1526930250289};\\\", \\\"{x:518,y:736,t:1526930250353};\\\", \\\"{x:518,y:737,t:1526930250362};\\\", \\\"{x:517,y:738,t:1526930250386};\\\", \\\"{x:517,y:739,t:1526930250402};\\\", \\\"{x:516,y:740,t:1526930250538};\\\", \\\"{x:514,y:740,t:1526930250553};\\\", \\\"{x:513,y:740,t:1526930250596};\\\", \\\"{x:518,y:743,t:1526930250793};\\\", \\\"{x:530,y:744,t:1526930250809};\\\", \\\"{x:549,y:745,t:1526930250826};\\\", \\\"{x:566,y:748,t:1526930250843};\\\", \\\"{x:584,y:747,t:1526930250859};\\\", \\\"{x:602,y:747,t:1526930250877};\\\", \\\"{x:620,y:747,t:1526930250893};\\\", \\\"{x:639,y:748,t:1526930250910};\\\", \\\"{x:651,y:749,t:1526930250926};\\\", \\\"{x:669,y:749,t:1526930250943};\\\", \\\"{x:683,y:749,t:1526930250959};\\\", \\\"{x:691,y:749,t:1526930250977};\\\", \\\"{x:698,y:747,t:1526930250993};\\\", \\\"{x:700,y:746,t:1526930251009};\\\", \\\"{x:701,y:746,t:1526930251050};\\\", \\\"{x:639,y:739,t:1526930251547};\\\", \\\"{x:639,y:739,t:1526930251634};\\\" ] }, { \\\"rt\\\": 157147, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 20, \\\"time_elapsed\\\": 760792, \\\"internal_node_id\\\": \\\"0.0-7.0-0.0\\\", \\\"subject\\\": \\\"GQ35Z\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"charlie\\\", \\\"condition\\\": \\\"111\\\", \\\"q\\\": 16, \\\"answer\\\": \\\"Any event that is on a positive sloped line intersecting 12pm or any event whose x-coordinate shifted to the left by their (y-coordinate divided by 2) is 12pm. \\\", \\\"block\\\": \\\"triangular_testing\\\" }, { \\\"rt\\\": 7546, \\\"responses\\\": \\\"{\\\\\\\"Q0\\\\\\\":\\\\\\\"19\\\\\\\",\\\\\\\"Q1\\\\\\\":\\\\\\\"Israel\\\\\\\"}\\\", \\\"block\\\": \\\"demo-1\\\", \\\"trial_type\\\": \\\"survey-text\\\", \\\"trial_index\\\": 21, \\\"time_elapsed\\\": 769344, \\\"internal_node_id\\\": \\\"0.0-8.0\\\", \\\"subject\\\": \\\"GQ35Z\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"charlie\\\", \\\"condition\\\": \\\"111\\\" }, { \\\"rt\\\": 25139, \\\"responses\\\": \\\"{\\\\\\\"Q0\\\\\\\":\\\\\\\"Other\\\\\\\",\\\\\\\"Q1\\\\\\\":\\\\\\\"First\\\\\\\",\\\\\\\"Q2\\\\\\\":\\\\\\\"Social Sciences (incl. CogSci)\\\\\\\",\\\\\\\"Q3\\\\\\\":\\\\\\\"Male\\\\\\\"}\\\", \\\"block\\\": \\\"demo-2\\\", \\\"trial_type\\\": \\\"survey-multi-choice\\\", \\\"trial_index\\\": 22, \\\"time_elapsed\\\": 795496, \\\"internal_node_id\\\": \\\"0.0-9.0\\\", \\\"subject\\\": \\\"GQ35Z\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"charlie\\\", \\\"condition\\\": \\\"111\\\" }, { \\\"rt\\\": 28646, \\\"url\\\": \\\"../views/src/external/debrief.html\\\", \\\"block\\\": \\\"debrief\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 23, \\\"time_elapsed\\\": 825478, \\\"internal_node_id\\\": \\\"0.0-10.0\\\", \\\"subject\\\": \\\"GQ35Z\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"charlie\\\", \\\"condition\\\": \\\"111\\\" } ]\",\"parentNode\":{\"id\":2765}}],[],[]]}"
    }
  ],
  "initialDom": "{\"f\":\"initialize\",\"args\":[1,[{\"nodeType\":10,\"id\":2,\"name\":\"html\",\"publicId\":\"\",\"systemId\":\"\"},{\"nodeType\":1,\"id\":3,\"tagName\":\"HTML\",\"attributes\":{\"class\":\"fa-events-icons-ready\"},\"childNodes\":[{\"nodeType\":1,\"id\":4,\"tagName\":\"HEAD\",\"attributes\":{},\"childNodes\":[{\"nodeType\":3,\"id\":5,\"textContent\":\" \"},{\"nodeType\":1,\"id\":6,\"tagName\":\"TITLE\",\"attributes\":{},\"childNodes\":[{\"nodeType\":3,\"id\":7,\"textContent\":\"FOX2YP\"}]},{\"nodeType\":3,\"id\":8,\"textContent\":\" \"},{\"nodeType\":8,\"id\":9},{\"nodeType\":3,\"id\":10,\"textContent\":\" \"},{\"nodeType\":1,\"id\":11,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":12,\"textContent\":\" \"},{\"nodeType\":1,\"id\":13,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":14,\"textContent\":\" \"},{\"nodeType\":1,\"id\":15,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":16,\"textContent\":\" \"},{\"nodeType\":1,\"id\":17,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":18,\"textContent\":\" \"},{\"nodeType\":1,\"id\":19,\"tagName\":\"SCRIPT\"},{\"nodeType\":1,\"id\":20,\"tagName\":\"LINK\",\"attributes\":{\"href\":\"https://use.fontawesome.com/945539d961.css\",\"media\":\"all\",\"rel\":\"stylesheet\"}},{\"nodeType\":3,\"id\":21,\"textContent\":\" \"},{\"nodeType\":8,\"id\":22},{\"nodeType\":3,\"id\":23,\"textContent\":\" \"},{\"nodeType\":1,\"id\":24,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":25,\"textContent\":\" \"},{\"nodeType\":1,\"id\":26,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":27,\"textContent\":\" \"},{\"nodeType\":1,\"id\":28,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":29,\"textContent\":\" \"},{\"nodeType\":1,\"id\":30,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":31,\"textContent\":\" \"},{\"nodeType\":1,\"id\":32,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":33,\"textContent\":\" \"},{\"nodeType\":1,\"id\":34,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":35,\"textContent\":\" \"},{\"nodeType\":1,\"id\":36,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":37,\"textContent\":\" \"},{\"nodeType\":8,\"id\":38},{\"nodeType\":3,\"id\":39,\"textContent\":\" \"},{\"nodeType\":1,\"id\":40,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":41,\"textContent\":\" \"},{\"nodeType\":8,\"id\":42},{\"nodeType\":3,\"id\":43,\"textContent\":\" \"},{\"nodeType\":8,\"id\":44},{\"nodeType\":3,\"id\":45,\"textContent\":\" \"},{\"nodeType\":1,\"id\":46,\"tagName\":\"LINK\",\"attributes\":{\"href\":\"../views/jsPsych/css/jspsych.css\",\"rel\":\"stylesheet\",\"type\":\"text/css\"}},{\"nodeType\":3,\"id\":47,\"textContent\":\" \"},{\"nodeType\":1,\"id\":48,\"tagName\":\"LINK\",\"attributes\":{\"href\":\"../css/styles.css\",\"rel\":\"stylesheet\",\"type\":\"text/css\"}},{\"nodeType\":3,\"id\":49,\"textContent\":\" \"},{\"nodeType\":1,\"id\":50,\"tagName\":\"SCRIPT\"},{\"nodeType\":1,\"id\":51,\"tagName\":\"SCRIPT\"}]},{\"nodeType\":3,\"id\":52,\"textContent\":\" \"},{\"nodeType\":8,\"id\":53},{\"nodeType\":3,\"id\":54,\"textContent\":\" \"},{\"nodeType\":1,\"id\":55,\"tagName\":\"BODY\",\"attributes\":{\"class\":\"jspsych-display-element\"},\"childNodes\":[{\"nodeType\":3,\"id\":56,\"textContent\":\" \"},{\"nodeType\":1,\"id\":57,\"tagName\":\"META\",\"attributes\":{\"charset\":\"utf-8\"}},{\"nodeType\":3,\"id\":58,\"textContent\":\" \"},{\"nodeType\":8,\"id\":59},{\"nodeType\":3,\"id\":60,\"textContent\":\" \"},{\"nodeType\":1,\"id\":61,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":62,\"textContent\":\" \"},{\"nodeType\":1,\"id\":63,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":64,\"textContent\":\" \"},{\"nodeType\":1,\"id\":65,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":66,\"textContent\":\" \"},{\"nodeType\":1,\"id\":67,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":68,\"textContent\":\" \"},{\"nodeType\":1,\"id\":69,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":70,\"textContent\":\" \"},{\"nodeType\":1,\"id\":71,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":72,\"textContent\":\" \"},{\"nodeType\":1,\"id\":73,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"stimulus\"},\"childNodes\":[{\"nodeType\":3,\"id\":74,\"textContent\":\" \"},{\"nodeType\":1,\"id\":75,\"tagName\":\"P\",\"attributes\":{\"class\":\"userid\",\"id\":\"userid\"},\"childNodes\":[{\"nodeType\":3,\"id\":76,\"textContent\":\"GQ35Z\"}]},{\"nodeType\":3,\"id\":77,\"textContent\":\" \"},{\"nodeType\":1,\"id\":78,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"userinput\"},\"childNodes\":[{\"nodeType\":3,\"id\":79,\"textContent\":\" \"},{\"nodeType\":8,\"id\":80},{\"nodeType\":3,\"id\":81,\"textContent\":\" \"},{\"nodeType\":1,\"id\":82,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"legend\",\"id\":\"hint-interactive\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":83,\"textContent\":\" \"},{\"nodeType\":1,\"id\":84,\"tagName\":\"P\",\"attributes\":{},\"childNodes\":[{\"nodeType\":3,\"id\":85,\"textContent\":\"Hint: Hover your mouse over the data points in the graph\"}]},{\"nodeType\":3,\"id\":86,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":87,\"textContent\":\" \"},{\"nodeType\":8,\"id\":88},{\"nodeType\":3,\"id\":89,\"textContent\":\" \"},{\"nodeType\":8,\"id\":90},{\"nodeType\":3,\"id\":91,\"textContent\":\" \"},{\"nodeType\":1,\"id\":92,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"test\"},\"childNodes\":[{\"nodeType\":3,\"id\":93,\"textContent\":\" \"},{\"nodeType\":1,\"id\":94,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"acme\",\"id\":\"acme.starttime\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":95,\"textContent\":\" \"},{\"nodeType\":1,\"id\":96,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":97,\"textContent\":\"Which shift(s) start at 11 am? \"}]},{\"nodeType\":3,\"id\":98,\"textContent\":\" \"},{\"nodeType\":1,\"id\":99,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":100,\"textContent\":\" \"},{\"nodeType\":1,\"id\":101,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":102,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":103,\"textContent\":\" \"},{\"nodeType\":1,\"id\":104,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":105,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":106,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":107,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":108,\"textContent\":\" \"},{\"nodeType\":1,\"id\":109,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":110,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":111,\"textContent\":\" \"},{\"nodeType\":1,\"id\":112,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":113,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":114,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":115,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":116,\"textContent\":\" \"},{\"nodeType\":1,\"id\":117,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":118,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":119,\"textContent\":\" \"},{\"nodeType\":1,\"id\":120,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":121,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":122,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":123,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":124,\"textContent\":\" \"},{\"nodeType\":1,\"id\":125,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":126,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":127,\"textContent\":\" \"},{\"nodeType\":1,\"id\":128,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":129,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":130,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":131,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":132,\"textContent\":\" \"},{\"nodeType\":1,\"id\":133,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":134,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":135,\"textContent\":\" \"},{\"nodeType\":1,\"id\":136,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":137,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":138,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":139,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":140,\"textContent\":\" \"},{\"nodeType\":1,\"id\":141,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":142,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":143,\"textContent\":\" \"},{\"nodeType\":1,\"id\":144,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":145,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":146,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":147,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":148,\"textContent\":\" \"},{\"nodeType\":1,\"id\":149,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":150,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":151,\"textContent\":\" \"},{\"nodeType\":1,\"id\":152,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":153,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":154,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":155,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":156,\"textContent\":\" \"},{\"nodeType\":1,\"id\":157,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":158,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":159,\"textContent\":\" \"},{\"nodeType\":1,\"id\":160,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":161,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":162,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":163,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":164,\"textContent\":\" \"},{\"nodeType\":1,\"id\":165,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":166,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":167,\"textContent\":\" \"},{\"nodeType\":1,\"id\":168,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":169,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":170,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":171,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":172,\"textContent\":\" \"},{\"nodeType\":1,\"id\":173,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":174,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":175,\"textContent\":\" \"},{\"nodeType\":1,\"id\":176,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":177,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":178,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":179,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":180,\"textContent\":\" \"},{\"nodeType\":1,\"id\":181,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":182,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":183,\"textContent\":\" \"},{\"nodeType\":1,\"id\":184,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"U\",\"value\":\"\"}},{\"nodeType\":3,\"id\":185,\"textContent\":\"U \"},{\"nodeType\":1,\"id\":186,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":187,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":188,\"textContent\":\" \"},{\"nodeType\":1,\"id\":189,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":190,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":191,\"textContent\":\" \"},{\"nodeType\":1,\"id\":192,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":193,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":194,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":195,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":196,\"textContent\":\" \"},{\"nodeType\":1,\"id\":197,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":198,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":199,\"textContent\":\" \"},{\"nodeType\":1,\"id\":200,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":201,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":202,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":203,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":204,\"textContent\":\" \"},{\"nodeType\":1,\"id\":205,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":206,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":207,\"textContent\":\" \"},{\"nodeType\":1,\"id\":208,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":209,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":210,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":211,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":212,\"textContent\":\" \"},{\"nodeType\":1,\"id\":213,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":214,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":215,\"textContent\":\" \"},{\"nodeType\":1,\"id\":216,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":217,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":218,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":219,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":220,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":221,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":222,\"textContent\":\" \"},{\"nodeType\":1,\"id\":223,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"acme\",\"id\":\"acme.starts\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":224,\"textContent\":\" \"},{\"nodeType\":1,\"id\":225,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":226,\"textContent\":\"Which shift(s) start at the same time as D?\"}]},{\"nodeType\":3,\"id\":227,\"textContent\":\" \"},{\"nodeType\":1,\"id\":228,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":229,\"textContent\":\" \"},{\"nodeType\":1,\"id\":230,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":231,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":232,\"textContent\":\" \"},{\"nodeType\":1,\"id\":233,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":234,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":235,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":236,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":237,\"textContent\":\" \"},{\"nodeType\":1,\"id\":238,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":239,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":240,\"textContent\":\" \"},{\"nodeType\":1,\"id\":241,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":242,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":243,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":244,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":245,\"textContent\":\" \"},{\"nodeType\":1,\"id\":246,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":247,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":248,\"textContent\":\" \"},{\"nodeType\":1,\"id\":249,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":250,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":251,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":252,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":253,\"textContent\":\" \"},{\"nodeType\":1,\"id\":254,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":255,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":256,\"textContent\":\" \"},{\"nodeType\":1,\"id\":257,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":258,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":259,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":260,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":261,\"textContent\":\" \"},{\"nodeType\":1,\"id\":262,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":263,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":264,\"textContent\":\" \"},{\"nodeType\":1,\"id\":265,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":266,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":267,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":268,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":269,\"textContent\":\" \"},{\"nodeType\":1,\"id\":270,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":271,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":272,\"textContent\":\" \"},{\"nodeType\":1,\"id\":273,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":274,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":275,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":276,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":277,\"textContent\":\" \"},{\"nodeType\":1,\"id\":278,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":279,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":280,\"textContent\":\" \"},{\"nodeType\":1,\"id\":281,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":282,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":283,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":284,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":285,\"textContent\":\" \"},{\"nodeType\":1,\"id\":286,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":287,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":288,\"textContent\":\" \"},{\"nodeType\":1,\"id\":289,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":290,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":291,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":292,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":293,\"textContent\":\" \"},{\"nodeType\":1,\"id\":294,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":295,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":296,\"textContent\":\" \"},{\"nodeType\":1,\"id\":297,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":298,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":299,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":300,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":301,\"textContent\":\" \"},{\"nodeType\":1,\"id\":302,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":303,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":304,\"textContent\":\" \"},{\"nodeType\":1,\"id\":305,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":306,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":307,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":308,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":309,\"textContent\":\" \"},{\"nodeType\":1,\"id\":310,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":311,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":312,\"textContent\":\" \"},{\"nodeType\":1,\"id\":313,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"U\",\"value\":\"\"}},{\"nodeType\":3,\"id\":314,\"textContent\":\"U \"},{\"nodeType\":1,\"id\":315,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":316,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":317,\"textContent\":\" \"},{\"nodeType\":1,\"id\":318,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":319,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":320,\"textContent\":\" \"},{\"nodeType\":1,\"id\":321,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":322,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":323,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":324,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":325,\"textContent\":\" \"},{\"nodeType\":1,\"id\":326,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":327,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":328,\"textContent\":\" \"},{\"nodeType\":1,\"id\":329,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":330,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":331,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":332,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":333,\"textContent\":\" \"},{\"nodeType\":1,\"id\":334,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":335,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":336,\"textContent\":\" \"},{\"nodeType\":1,\"id\":337,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":338,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":339,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":340,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":341,\"textContent\":\" \"},{\"nodeType\":1,\"id\":342,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":343,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":344,\"textContent\":\" \"},{\"nodeType\":1,\"id\":345,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":346,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":347,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":348,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":349,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":350,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":351,\"textContent\":\" \"},{\"nodeType\":1,\"id\":352,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"acme\",\"id\":\"acme.meets\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":353,\"textContent\":\" \"},{\"nodeType\":1,\"id\":354,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":355,\"textContent\":\"Which shift(s) begin when C ends?\"}]},{\"nodeType\":3,\"id\":356,\"textContent\":\" \"},{\"nodeType\":1,\"id\":357,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":358,\"textContent\":\" \"},{\"nodeType\":1,\"id\":359,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":360,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":361,\"textContent\":\" \"},{\"nodeType\":1,\"id\":362,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":363,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":364,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":365,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":366,\"textContent\":\" \"},{\"nodeType\":1,\"id\":367,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":368,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":369,\"textContent\":\" \"},{\"nodeType\":1,\"id\":370,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":371,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":372,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":373,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":374,\"textContent\":\" \"},{\"nodeType\":1,\"id\":375,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":376,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":377,\"textContent\":\" \"},{\"nodeType\":1,\"id\":378,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":379,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":380,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":381,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":382,\"textContent\":\" \"},{\"nodeType\":1,\"id\":383,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":384,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":385,\"textContent\":\" \"},{\"nodeType\":1,\"id\":386,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":387,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":388,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":389,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":390,\"textContent\":\" \"},{\"nodeType\":1,\"id\":391,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":392,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":393,\"textContent\":\" \"},{\"nodeType\":1,\"id\":394,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":395,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":396,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":397,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":398,\"textContent\":\" \"},{\"nodeType\":1,\"id\":399,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":400,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":401,\"textContent\":\" \"},{\"nodeType\":1,\"id\":402,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":403,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":404,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":405,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":406,\"textContent\":\" \"},{\"nodeType\":1,\"id\":407,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":408,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":409,\"textContent\":\" \"},{\"nodeType\":1,\"id\":410,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":411,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":412,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":413,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":414,\"textContent\":\" \"},{\"nodeType\":1,\"id\":415,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":416,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":417,\"textContent\":\" \"},{\"nodeType\":1,\"id\":418,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":419,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":420,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":421,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":422,\"textContent\":\" \"},{\"nodeType\":1,\"id\":423,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":424,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":425,\"textContent\":\" \"},{\"nodeType\":1,\"id\":426,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":427,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":428,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":429,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":430,\"textContent\":\" \"},{\"nodeType\":1,\"id\":431,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":432,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":433,\"textContent\":\" \"},{\"nodeType\":1,\"id\":434,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":435,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":436,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":437,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":438,\"textContent\":\" \"},{\"nodeType\":1,\"id\":439,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":440,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":441,\"textContent\":\" \"},{\"nodeType\":1,\"id\":442,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"U\",\"value\":\"\"}},{\"nodeType\":3,\"id\":443,\"textContent\":\"U \"},{\"nodeType\":1,\"id\":444,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":445,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":446,\"textContent\":\" \"},{\"nodeType\":1,\"id\":447,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":448,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":449,\"textContent\":\" \"},{\"nodeType\":1,\"id\":450,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":451,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":452,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":453,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":454,\"textContent\":\" \"},{\"nodeType\":1,\"id\":455,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":456,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":457,\"textContent\":\" \"},{\"nodeType\":1,\"id\":458,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":459,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":460,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":461,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":462,\"textContent\":\" \"},{\"nodeType\":1,\"id\":463,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":464,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":465,\"textContent\":\" \"},{\"nodeType\":1,\"id\":466,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":467,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":468,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":469,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":470,\"textContent\":\" \"},{\"nodeType\":1,\"id\":471,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":472,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":473,\"textContent\":\" \"},{\"nodeType\":1,\"id\":474,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":475,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":476,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":477,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":478,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":479,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":480,\"textContent\":\" \"},{\"nodeType\":1,\"id\":481,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"acme\",\"id\":\"acme.endtime\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":482,\"textContent\":\" \"},{\"nodeType\":1,\"id\":483,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":484,\"textContent\":\" Which shift(s) end at 4 pm?\"}]},{\"nodeType\":3,\"id\":485,\"textContent\":\" \"},{\"nodeType\":1,\"id\":486,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":487,\"textContent\":\" \"},{\"nodeType\":1,\"id\":488,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":489,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":490,\"textContent\":\" \"},{\"nodeType\":1,\"id\":491,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":492,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":493,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":494,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":495,\"textContent\":\" \"},{\"nodeType\":1,\"id\":496,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":497,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":498,\"textContent\":\" \"},{\"nodeType\":1,\"id\":499,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":500,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":501,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":502,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":503,\"textContent\":\" \"},{\"nodeType\":1,\"id\":504,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":505,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":506,\"textContent\":\" \"},{\"nodeType\":1,\"id\":507,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":508,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":509,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":510,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":511,\"textContent\":\" \"},{\"nodeType\":1,\"id\":512,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":513,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":514,\"textContent\":\" \"},{\"nodeType\":1,\"id\":515,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":516,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":517,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":518,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":519,\"textContent\":\" \"},{\"nodeType\":1,\"id\":520,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":521,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":522,\"textContent\":\" \"},{\"nodeType\":1,\"id\":523,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":524,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":525,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":526,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":527,\"textContent\":\" \"},{\"nodeType\":1,\"id\":528,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":529,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":530,\"textContent\":\" \"},{\"nodeType\":1,\"id\":531,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":532,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":533,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":534,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":535,\"textContent\":\" \"},{\"nodeType\":1,\"id\":536,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":537,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":538,\"textContent\":\" \"},{\"nodeType\":1,\"id\":539,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":540,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":541,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":542,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":543,\"textContent\":\" \"},{\"nodeType\":1,\"id\":544,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":545,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":546,\"textContent\":\" \"},{\"nodeType\":1,\"id\":547,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":548,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":549,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":550,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":551,\"textContent\":\" \"},{\"nodeType\":1,\"id\":552,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":553,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":554,\"textContent\":\" \"},{\"nodeType\":1,\"id\":555,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":556,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":557,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":558,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":559,\"textContent\":\" \"},{\"nodeType\":1,\"id\":560,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":561,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":562,\"textContent\":\" \"},{\"nodeType\":1,\"id\":563,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":564,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":565,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":566,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":567,\"textContent\":\" \"},{\"nodeType\":1,\"id\":568,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":569,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":570,\"textContent\":\" \"},{\"nodeType\":1,\"id\":571,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"U\",\"value\":\"\"}},{\"nodeType\":3,\"id\":572,\"textContent\":\"U \"},{\"nodeType\":1,\"id\":573,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":574,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":575,\"textContent\":\" \"},{\"nodeType\":1,\"id\":576,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":577,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":578,\"textContent\":\" \"},{\"nodeType\":1,\"id\":579,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":580,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":581,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":582,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":583,\"textContent\":\" \"},{\"nodeType\":1,\"id\":584,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":585,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":586,\"textContent\":\" \"},{\"nodeType\":1,\"id\":587,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":588,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":589,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":590,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":591,\"textContent\":\" \"},{\"nodeType\":1,\"id\":592,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":593,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":594,\"textContent\":\" \"},{\"nodeType\":1,\"id\":595,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":596,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":597,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":598,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":599,\"textContent\":\" \"},{\"nodeType\":1,\"id\":600,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":601,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":602,\"textContent\":\" \"},{\"nodeType\":1,\"id\":603,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":604,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":605,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":606,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":607,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":608,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":609,\"textContent\":\" \"},{\"nodeType\":1,\"id\":610,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"acme\",\"id\":\"acme.midpoint\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":611,\"textContent\":\" \"},{\"nodeType\":1,\"id\":612,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":613,\"textContent\":\"Coffee breaks happen halfway through a shift.\"},{\"nodeType\":1,\"id\":614,\"tagName\":\"BR\",\"attributes\":{}},{\"nodeType\":3,\"id\":615,\"textContent\":\" Which shift(s) share a break with I?\"}]},{\"nodeType\":3,\"id\":616,\"textContent\":\" \"},{\"nodeType\":1,\"id\":617,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":618,\"textContent\":\" \"},{\"nodeType\":1,\"id\":619,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":620,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":621,\"textContent\":\" \"},{\"nodeType\":1,\"id\":622,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":623,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":624,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":625,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":626,\"textContent\":\" \"},{\"nodeType\":1,\"id\":627,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":628,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":629,\"textContent\":\" \"},{\"nodeType\":1,\"id\":630,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":631,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":632,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":633,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":634,\"textContent\":\" \"},{\"nodeType\":1,\"id\":635,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":636,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":637,\"textContent\":\" \"},{\"nodeType\":1,\"id\":638,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":639,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":640,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":641,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":642,\"textContent\":\" \"},{\"nodeType\":1,\"id\":643,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":644,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":645,\"textContent\":\" \"},{\"nodeType\":1,\"id\":646,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":647,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":648,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":649,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":650,\"textContent\":\" \"},{\"nodeType\":1,\"id\":651,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":652,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":653,\"textContent\":\" \"},{\"nodeType\":1,\"id\":654,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":655,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":656,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":657,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":658,\"textContent\":\" \"},{\"nodeType\":1,\"id\":659,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":660,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":661,\"textContent\":\" \"},{\"nodeType\":1,\"id\":662,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":663,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":664,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":665,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":666,\"textContent\":\" \"},{\"nodeType\":1,\"id\":667,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":668,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":669,\"textContent\":\" \"},{\"nodeType\":1,\"id\":670,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":671,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":672,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":673,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":674,\"textContent\":\" \"},{\"nodeType\":1,\"id\":675,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":676,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":677,\"textContent\":\" \"},{\"nodeType\":1,\"id\":678,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":679,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":680,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":681,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":682,\"textContent\":\" \"},{\"nodeType\":1,\"id\":683,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":684,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":685,\"textContent\":\" \"},{\"nodeType\":1,\"id\":686,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":687,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":688,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":689,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":690,\"textContent\":\" \"},{\"nodeType\":1,\"id\":691,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":692,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":693,\"textContent\":\" \"},{\"nodeType\":1,\"id\":694,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":695,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":696,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":697,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":698,\"textContent\":\" \"},{\"nodeType\":1,\"id\":699,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":700,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":701,\"textContent\":\" \"},{\"nodeType\":1,\"id\":702,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"U\",\"value\":\"\"}},{\"nodeType\":3,\"id\":703,\"textContent\":\"U \"},{\"nodeType\":1,\"id\":704,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":705,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":706,\"textContent\":\" \"},{\"nodeType\":1,\"id\":707,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":708,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":709,\"textContent\":\" \"},{\"nodeType\":1,\"id\":710,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":711,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":712,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":713,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":714,\"textContent\":\" \"},{\"nodeType\":1,\"id\":715,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":716,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":717,\"textContent\":\" \"},{\"nodeType\":1,\"id\":718,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":719,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":720,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":721,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":722,\"textContent\":\" \"},{\"nodeType\":1,\"id\":723,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":724,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":725,\"textContent\":\" \"},{\"nodeType\":1,\"id\":726,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":727,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":728,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":729,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":730,\"textContent\":\" \"},{\"nodeType\":1,\"id\":731,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":732,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":733,\"textContent\":\" \"},{\"nodeType\":1,\"id\":734,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":735,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":736,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":737,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":738,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":739,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":740,\"textContent\":\" \"},{\"nodeType\":1,\"id\":741,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.duration\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":742,\"textContent\":\" \"},{\"nodeType\":1,\"id\":743,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":744,\"textContent\":\"Which shift(s) are six hours long?\"}]},{\"nodeType\":3,\"id\":745,\"textContent\":\" \"},{\"nodeType\":1,\"id\":746,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":747,\"textContent\":\" \"},{\"nodeType\":1,\"id\":748,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":749,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":750,\"textContent\":\" \"},{\"nodeType\":1,\"id\":751,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":752,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":753,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":754,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":755,\"textContent\":\" \"},{\"nodeType\":1,\"id\":756,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":757,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":758,\"textContent\":\" \"},{\"nodeType\":1,\"id\":759,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":760,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":761,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":762,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":763,\"textContent\":\" \"},{\"nodeType\":1,\"id\":764,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":765,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":766,\"textContent\":\" \"},{\"nodeType\":1,\"id\":767,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":768,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":769,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":770,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":771,\"textContent\":\" \"},{\"nodeType\":1,\"id\":772,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":773,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":774,\"textContent\":\" \"},{\"nodeType\":1,\"id\":775,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":776,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":777,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":778,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":779,\"textContent\":\" \"},{\"nodeType\":1,\"id\":780,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":781,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":782,\"textContent\":\" \"},{\"nodeType\":1,\"id\":783,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":784,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":785,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":786,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":787,\"textContent\":\" \"},{\"nodeType\":1,\"id\":788,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":789,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":790,\"textContent\":\" \"},{\"nodeType\":1,\"id\":791,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":792,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":793,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":794,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":795,\"textContent\":\" \"},{\"nodeType\":1,\"id\":796,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":797,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":798,\"textContent\":\" \"},{\"nodeType\":1,\"id\":799,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":800,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":801,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":802,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":803,\"textContent\":\" \"},{\"nodeType\":1,\"id\":804,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":805,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":806,\"textContent\":\" \"},{\"nodeType\":1,\"id\":807,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":808,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":809,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":810,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":811,\"textContent\":\" \"},{\"nodeType\":1,\"id\":812,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":813,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":814,\"textContent\":\" \"},{\"nodeType\":1,\"id\":815,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":816,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":817,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":818,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":819,\"textContent\":\" \"},{\"nodeType\":1,\"id\":820,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":821,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":822,\"textContent\":\" \"},{\"nodeType\":1,\"id\":823,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":824,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":825,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":826,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":827,\"textContent\":\" \"},{\"nodeType\":1,\"id\":828,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":829,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":830,\"textContent\":\" \"},{\"nodeType\":1,\"id\":831,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":832,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":833,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":834,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":835,\"textContent\":\" \"},{\"nodeType\":1,\"id\":836,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":837,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":838,\"textContent\":\" \"},{\"nodeType\":1,\"id\":839,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":840,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":841,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":842,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":843,\"textContent\":\" \"},{\"nodeType\":1,\"id\":844,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":845,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":846,\"textContent\":\" \"},{\"nodeType\":1,\"id\":847,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":848,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":849,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":850,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":851,\"textContent\":\" \"},{\"nodeType\":1,\"id\":852,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":853,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":854,\"textContent\":\" \"},{\"nodeType\":1,\"id\":855,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":856,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":857,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":858,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":859,\"textContent\":\" \"},{\"nodeType\":1,\"id\":860,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":861,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":862,\"textContent\":\" \"},{\"nodeType\":1,\"id\":863,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":864,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":865,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":866,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":867,\"textContent\":\" \"},{\"nodeType\":1,\"id\":868,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":869,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":870,\"textContent\":\" \"},{\"nodeType\":1,\"id\":871,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":872,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":873,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":874,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":875,\"textContent\":\" \"},{\"nodeType\":1,\"id\":876,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":877,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":878,\"textContent\":\" \"},{\"nodeType\":1,\"id\":879,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":880,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":881,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":882,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":883,\"textContent\":\" \"},{\"nodeType\":1,\"id\":884,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":885,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":886,\"textContent\":\" \"},{\"nodeType\":1,\"id\":887,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":888,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":889,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":890,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":891,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":892,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":893,\"textContent\":\" \"},{\"nodeType\":1,\"id\":894,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.duration+starts\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":895,\"textContent\":\" \"},{\"nodeType\":1,\"id\":896,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":897,\"textContent\":\"Which 2 shifts less than 5 hours long start at the same time?\"}]},{\"nodeType\":3,\"id\":898,\"textContent\":\" \"},{\"nodeType\":1,\"id\":899,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":900,\"textContent\":\" \"},{\"nodeType\":1,\"id\":901,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":902,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":903,\"textContent\":\" \"},{\"nodeType\":1,\"id\":904,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":905,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":906,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":907,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":908,\"textContent\":\" \"},{\"nodeType\":1,\"id\":909,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":910,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":911,\"textContent\":\" \"},{\"nodeType\":1,\"id\":912,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":913,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":914,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":915,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":916,\"textContent\":\" \"},{\"nodeType\":1,\"id\":917,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":918,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":919,\"textContent\":\" \"},{\"nodeType\":1,\"id\":920,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":921,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":922,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":923,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":924,\"textContent\":\" \"},{\"nodeType\":1,\"id\":925,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":926,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":927,\"textContent\":\" \"},{\"nodeType\":1,\"id\":928,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":929,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":930,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":931,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":932,\"textContent\":\" \"},{\"nodeType\":1,\"id\":933,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":934,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":935,\"textContent\":\" \"},{\"nodeType\":1,\"id\":936,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":937,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":938,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":939,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":940,\"textContent\":\" \"},{\"nodeType\":1,\"id\":941,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":942,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":943,\"textContent\":\" \"},{\"nodeType\":1,\"id\":944,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":945,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":946,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":947,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":948,\"textContent\":\" \"},{\"nodeType\":1,\"id\":949,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":950,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":951,\"textContent\":\" \"},{\"nodeType\":1,\"id\":952,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":953,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":954,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":955,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":956,\"textContent\":\" \"},{\"nodeType\":1,\"id\":957,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":958,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":959,\"textContent\":\" \"},{\"nodeType\":1,\"id\":960,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":961,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":962,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":963,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":964,\"textContent\":\" \"},{\"nodeType\":1,\"id\":965,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":966,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":967,\"textContent\":\" \"},{\"nodeType\":1,\"id\":968,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":969,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":970,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":971,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":972,\"textContent\":\" \"},{\"nodeType\":1,\"id\":973,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":974,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":975,\"textContent\":\" \"},{\"nodeType\":1,\"id\":976,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":977,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":978,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":979,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":980,\"textContent\":\" \"},{\"nodeType\":1,\"id\":981,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":982,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":983,\"textContent\":\" \"},{\"nodeType\":1,\"id\":984,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":985,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":986,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":987,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":988,\"textContent\":\" \"},{\"nodeType\":1,\"id\":989,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":990,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":991,\"textContent\":\" \"},{\"nodeType\":1,\"id\":992,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":993,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":994,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":995,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":996,\"textContent\":\" \"},{\"nodeType\":1,\"id\":997,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":998,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":999,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1000,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1001,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":1002,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1003,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1004,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1005,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1006,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1007,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1008,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1009,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":1010,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1011,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1012,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1013,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1014,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1015,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1016,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1017,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":1018,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1019,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1020,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1021,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1022,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1023,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1024,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1025,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":1026,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1027,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1028,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1029,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1030,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1031,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1032,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1033,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":1034,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1035,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1036,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1037,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1038,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1039,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1040,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1041,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":1042,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1043,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1044,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1045,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1046,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1047,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.duration+contained\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":1048,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1049,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":1050,\"textContent\":\"Which shift(s) under 7 hours long starts before B starts, and ends after X ends?\"}]},{\"nodeType\":3,\"id\":1051,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1052,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":1053,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1054,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1055,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1056,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1057,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1058,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":1059,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1060,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1061,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1062,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1063,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1064,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1065,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1066,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":1067,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1068,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1069,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1070,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1071,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1072,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1073,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1074,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":1075,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1076,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1077,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1078,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1079,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1080,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1081,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1082,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":1083,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1084,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1085,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1086,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1087,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1088,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1089,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1090,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":1091,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1092,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1093,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1094,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1095,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1096,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1097,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1098,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":1099,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1100,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1101,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1102,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1103,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1104,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1105,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1106,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":1107,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1108,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1109,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1110,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1111,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1112,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1113,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1114,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":1115,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1116,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1117,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1118,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1119,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1120,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1121,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1122,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":1123,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1124,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1125,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1126,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1127,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1128,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1129,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1130,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":1131,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1132,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1133,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1134,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1135,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1136,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1137,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1138,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":1139,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1140,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1141,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1142,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1143,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1144,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1145,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1146,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":1147,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1148,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1149,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1150,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1151,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1152,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1153,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1154,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":1155,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1156,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1157,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1158,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1159,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1160,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1161,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1162,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":1163,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1164,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1165,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1166,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1167,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1168,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1169,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1170,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":1171,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1172,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1173,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1174,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1175,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1176,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1177,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1178,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":1179,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1180,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1181,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1182,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1183,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1184,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1185,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1186,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":1187,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1188,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1189,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1190,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1191,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1192,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1193,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1194,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":1195,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1196,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1197,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1198,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1199,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1200,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.starttime+before+endtime+during\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":1201,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1202,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":1203,\"textContent\":\"Which shift(s) begins before J begins and ends during B?\"}]},{\"nodeType\":3,\"id\":1204,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1205,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":1206,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1207,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1208,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1209,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1210,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1211,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":1212,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1213,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1214,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1215,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1216,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1217,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1218,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1219,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":1220,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1221,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1222,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1223,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1224,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1225,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1226,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1227,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":1228,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1229,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1230,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1231,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1232,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1233,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1234,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1235,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":1236,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1237,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1238,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1239,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1240,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1241,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1242,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1243,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":1244,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1245,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1246,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1247,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1248,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1249,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1250,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1251,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":1252,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1253,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1254,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1255,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1256,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1257,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1258,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1259,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":1260,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1261,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1262,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1263,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1264,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1265,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1266,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1267,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":1268,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1269,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1270,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1271,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1272,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1273,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1274,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1275,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":1276,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1277,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1278,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1279,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1280,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1281,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1282,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1283,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":1284,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1285,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1286,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1287,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1288,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1289,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1290,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1291,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":1292,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1293,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1294,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1295,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1296,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1297,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1298,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1299,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":1300,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1301,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1302,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1303,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1304,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1305,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1306,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1307,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":1308,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1309,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1310,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1311,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1312,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1313,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1314,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1315,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":1316,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1317,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1318,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1319,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1320,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1321,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1322,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1323,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":1324,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1325,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1326,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1327,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1328,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1329,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1330,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1331,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":1332,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1333,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1334,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1335,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1336,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1337,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1338,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1339,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":1340,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1341,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1342,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1343,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1344,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1345,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1346,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1347,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":1348,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1349,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1350,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1351,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1352,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1353,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.ends\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":1354,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1355,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":1356,\"textContent\":\"Which shift(s) end at the same time as F?\"}]},{\"nodeType\":3,\"id\":1357,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1358,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":1359,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1360,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1361,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1362,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1363,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1364,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":1365,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1366,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1367,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1368,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1369,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1370,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1371,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1372,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":1373,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1374,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1375,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1376,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1377,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1378,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1379,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1380,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":1381,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1382,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1383,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1384,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1385,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1386,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1387,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1388,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":1389,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1390,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1391,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1392,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1393,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1394,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1395,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1396,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":1397,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1398,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1399,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1400,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1401,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1402,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1403,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1404,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":1405,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1406,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1407,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1408,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1409,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1410,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1411,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1412,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":1413,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1414,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1415,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1416,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1417,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1418,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1419,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1420,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":1421,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1422,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1423,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1424,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1425,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1426,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1427,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1428,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":1429,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1430,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1431,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1432,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1433,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1434,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1435,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1436,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":1437,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1438,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1439,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1440,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1441,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1442,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1443,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1444,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":1445,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1446,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1447,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1448,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1449,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1450,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1451,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1452,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":1453,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1454,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1455,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1456,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1457,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1458,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1459,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1460,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":1461,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1462,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1463,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1464,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1465,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1466,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1467,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1468,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":1469,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1470,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1471,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1472,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1473,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1474,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1475,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1476,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":1477,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1478,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1479,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1480,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1481,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1482,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1483,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1484,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":1485,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1486,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1487,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1488,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1489,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1490,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1491,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1492,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":1493,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1494,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1495,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1496,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1497,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1498,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1499,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1500,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":1501,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1502,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1503,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1504,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1505,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1506,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.starttime\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":1507,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1508,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":1509,\"textContent\":\"Which shift(s) start at 12pm?\"}]},{\"nodeType\":3,\"id\":1510,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1511,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":1512,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1513,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1514,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1515,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1516,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1517,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":1518,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1519,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1520,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1521,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1522,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1523,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1524,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1525,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":1526,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1527,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1528,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1529,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1530,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1531,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1532,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1533,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":1534,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1535,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1536,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1537,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1538,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1539,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1540,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1541,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":1542,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1543,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1544,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1545,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1546,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1547,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1548,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1549,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":1550,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1551,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1552,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1553,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1554,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1555,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1556,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1557,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":1558,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1559,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1560,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1561,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1562,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1563,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1564,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1565,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":1566,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1567,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1568,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1569,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1570,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1571,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1572,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1573,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":1574,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1575,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1576,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1577,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1578,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1579,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1580,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1581,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":1582,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1583,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1584,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1585,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1586,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1587,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1588,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1589,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":1590,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1591,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1592,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1593,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1594,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1595,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1596,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1597,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":1598,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1599,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1600,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1601,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1602,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1603,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1604,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1605,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":1606,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1607,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1608,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1609,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1610,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1611,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1612,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1613,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":1614,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1615,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1616,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1617,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1618,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1619,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1620,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1621,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":1622,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1623,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1624,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1625,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1626,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1627,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1628,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1629,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":1630,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1631,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1632,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1633,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1634,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1635,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1636,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1637,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":1638,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1639,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1640,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1641,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1642,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1643,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1644,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1645,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":1646,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1647,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1648,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1649,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1650,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1651,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1652,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1653,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":1654,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1655,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1656,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1657,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1658,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1659,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.starts\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":1660,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1661,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":1662,\"textContent\":\"Which shift(s) start at the same time as F?\"}]},{\"nodeType\":3,\"id\":1663,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1664,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":1665,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1666,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1667,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1668,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1669,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1670,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":1671,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1672,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1673,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1674,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1675,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1676,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1677,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1678,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":1679,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1680,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1681,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1682,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1683,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1684,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1685,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1686,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":1687,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1688,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1689,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1690,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1691,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1692,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1693,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1694,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":1695,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1696,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1697,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1698,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1699,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1700,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1701,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1702,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":1703,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1704,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1705,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1706,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1707,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1708,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1709,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1710,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":1711,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1712,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1713,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1714,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1715,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1716,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1717,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1718,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":1719,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1720,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1721,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1722,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1723,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1724,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1725,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1726,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":1727,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1728,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1729,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1730,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1731,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1732,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1733,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1734,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":1735,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1736,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1737,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1738,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1739,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1740,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1741,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1742,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":1743,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1744,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1745,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1746,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1747,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1748,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1749,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1750,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":1751,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1752,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1753,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1754,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1755,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1756,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1757,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1758,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":1759,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1760,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1761,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1762,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1763,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1764,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1765,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1766,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":1767,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1768,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1769,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1770,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1771,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1772,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1773,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1774,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":1775,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1776,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1777,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1778,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1779,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1780,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1781,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1782,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":1783,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1784,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1785,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1786,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1787,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1788,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1789,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1790,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":1791,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1792,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1793,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1794,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1795,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1796,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1797,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1798,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":1799,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1800,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1801,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1802,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1803,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1804,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1805,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1806,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":1807,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1808,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1809,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1810,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1811,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1812,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.meets\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":1813,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1814,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":1815,\"textContent\":\"Which 2 shifts end when Z begins?\"}]},{\"nodeType\":3,\"id\":1816,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1817,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":1818,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1819,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1820,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1821,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1822,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1823,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":1824,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1825,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1826,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1827,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1828,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1829,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1830,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1831,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":1832,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1833,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1834,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1835,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1836,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1837,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1838,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1839,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":1840,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1841,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1842,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1843,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1844,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1845,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1846,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1847,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":1848,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1849,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1850,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1851,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1852,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1853,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1854,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1855,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":1856,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1857,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1858,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1859,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1860,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1861,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1862,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1863,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":1864,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1865,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1866,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1867,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1868,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1869,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1870,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1871,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":1872,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1873,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1874,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1875,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1876,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1877,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1878,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1879,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":1880,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1881,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1882,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1883,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1884,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1885,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1886,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1887,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":1888,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1889,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1890,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1891,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1892,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1893,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1894,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1895,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":1896,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1897,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1898,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1899,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1900,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1901,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1902,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1903,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":1904,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1905,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1906,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1907,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1908,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1909,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1910,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1911,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":1912,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1913,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1914,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1915,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1916,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1917,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1918,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1919,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":1920,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1921,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1922,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1923,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1924,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1925,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1926,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1927,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":1928,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1929,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1930,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1931,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1932,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1933,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1934,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1935,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":1936,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1937,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1938,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1939,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1940,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1941,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1942,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1943,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":1944,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1945,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1946,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1947,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1948,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1949,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1950,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1951,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":1952,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1953,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1954,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1955,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1956,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1957,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1958,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1959,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":1960,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1961,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1962,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1963,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1964,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1965,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.endtime\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":1966,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1967,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":1968,\"textContent\":\"Which shift(s) end at 3pm?\"}]},{\"nodeType\":3,\"id\":1969,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1970,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":1971,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1972,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1973,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1974,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1975,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1976,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":1977,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1978,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1979,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1980,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1981,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1982,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1983,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1984,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":1985,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1986,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1987,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1988,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1989,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1990,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1991,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1992,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":1993,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1994,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1995,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1996,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1997,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1998,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1999,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2000,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":2001,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2002,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2003,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2004,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2005,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2006,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2007,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2008,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":2009,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2010,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2011,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2012,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2013,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2014,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2015,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2016,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":2017,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2018,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2019,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2020,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2021,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2022,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2023,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2024,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":2025,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2026,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2027,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2028,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2029,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2030,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2031,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2032,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":2033,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2034,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2035,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2036,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2037,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2038,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2039,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2040,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":2041,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2042,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2043,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2044,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2045,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2046,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2047,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2048,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":2049,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2050,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2051,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2052,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2053,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2054,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2055,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2056,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":2057,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2058,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2059,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2060,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2061,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2062,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2063,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2064,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":2065,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2066,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2067,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2068,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2069,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2070,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2071,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2072,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":2073,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2074,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2075,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2076,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2077,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2078,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2079,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2080,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":2081,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2082,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2083,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2084,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2085,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2086,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2087,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2088,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":2089,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2090,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2091,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2092,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2093,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2094,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2095,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2096,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":2097,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2098,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2099,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2100,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2101,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2102,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2103,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2104,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":2105,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2106,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2107,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2108,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2109,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2110,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2111,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2112,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":2113,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2114,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2115,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2116,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2117,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2118,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.midpoint\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":2119,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2120,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":2121,\"textContent\":\"Coffee breaks happen halfway through a shift. \"},{\"nodeType\":1,\"id\":2122,\"tagName\":\"BR\",\"attributes\":{}},{\"nodeType\":3,\"id\":2123,\"textContent\":\"Which shifts share a break at 2pm?\"}]},{\"nodeType\":3,\"id\":2124,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2125,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":2126,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2127,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2128,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2129,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2130,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2131,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":2132,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2133,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2134,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2135,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2136,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2137,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2138,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2139,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":2140,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2141,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2142,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2143,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2144,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2145,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2146,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2147,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":2148,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2149,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2150,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2151,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2152,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2153,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2154,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2155,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":2156,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2157,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2158,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2159,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2160,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2161,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2162,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2163,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":2164,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2165,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2166,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2167,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2168,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2169,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2170,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2171,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":2172,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2173,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2174,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2175,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2176,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2177,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2178,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2179,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":2180,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2181,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2182,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2183,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2184,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2185,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2186,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2187,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":2188,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2189,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2190,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2191,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2192,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2193,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2194,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2195,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":2196,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2197,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2198,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2199,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2200,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2201,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2202,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2203,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":2204,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2205,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2206,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2207,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2208,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2209,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2210,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2211,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":2212,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2213,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2214,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2215,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2216,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2217,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2218,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2219,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":2220,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2221,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2222,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2223,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2224,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2225,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2226,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2227,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":2228,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2229,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2230,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2231,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2232,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2233,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2234,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2235,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":2236,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2237,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2238,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2239,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2240,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2241,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2242,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2243,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":2244,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2245,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2246,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2247,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2248,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2249,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2250,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2251,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":2252,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2253,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2254,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2255,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2256,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2257,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2258,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2259,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":2260,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2261,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2262,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2263,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2264,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2265,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2266,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2267,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":2268,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2269,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2270,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2271,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2272,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2273,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\".strategy\",\"style\":\"display: block;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2274,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2275,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":2276,\"textContent\":\"Please describe how to determine what event(s) start at 12pm?\"}]},{\"nodeType\":3,\"id\":2277,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2278,\"tagName\":\"TEXTAREA\",\"attributes\":{\"id\":\"strategyAnswer\",\"rows\":\"5\",\"cols\":\"80\"}},{\"nodeType\":3,\"id\":2279,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2280,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2281,\"textContent\":\" \"},{\"nodeType\":8,\"id\":2282},{\"nodeType\":3,\"id\":2283,\"textContent\":\" \"},{\"nodeType\":8,\"id\":2284},{\"nodeType\":3,\"id\":2285,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2286,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"fixbottom\"},\"childNodes\":[{\"nodeType\":3,\"id\":2287,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2288,\"tagName\":\"BUTTON\",\"attributes\":{\"type\":\"button\",\"id\":\"testingButton\",\"style\":\"display:none;\",\"class\":\"btn\"},\"childNodes\":[{\"nodeType\":3,\"id\":2289,\"textContent\":\"SUBMIT\"}]},{\"nodeType\":3,\"id\":2290,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2291,\"tagName\":\"BUTTON\",\"attributes\":{\"type\":\"button\",\"id\":\"strategyButton\",\"style\":\"display: block;\",\"class\":\"btn\"},\"childNodes\":[{\"nodeType\":3,\"id\":2292,\"textContent\":\"SUBMIT\"}]},{\"nodeType\":3,\"id\":2293,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2294,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2295,\"textContent\":\" \"},{\"nodeType\":8,\"id\":2296},{\"nodeType\":3,\"id\":2297,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2298,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"d3container\"},\"childNodes\":[{\"nodeType\":1,\"id\":2299,\"tagName\":\"svg\",\"attributes\":{\"width\":\"930\",\"height\":\"915\"},\"childNodes\":[{\"nodeType\":1,\"id\":2300,\"tagName\":\"g\",\"attributes\":{\"transform\":\"translate(100,25)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2301,\"tagName\":\"g\",\"attributes\":{\"class\":\"leaders\"}},{\"nodeType\":1,\"id\":2302,\"tagName\":\"g\",\"attributes\":{\"class\":\"static-scaffold\"}},{\"nodeType\":1,\"id\":2303,\"tagName\":\"g\",\"attributes\":{\"class\":\"xaxis\",\"transform\":\"translate(0,800)\",\"fill\":\"none\",\"font-size\":\"10\",\"font-family\":\"sans-serif\",\"text-anchor\":\"middle\"},\"childNodes\":[{\"nodeType\":1,\"id\":2304,\"tagName\":\"path\",\"attributes\":{\"class\":\"domain\",\"stroke\":\"#000\",\"d\":\"M0.5,6V0.5H800.5V6\"}},{\"nodeType\":1,\"id\":2305,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0.5,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2306,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2307,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2308,\"textContent\":\"08 AM\"}]}]},{\"nodeType\":1,\"id\":2309,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(33.83333333333333,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2310,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2311,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2312,\"textContent\":\"08:30\"}]}]},{\"nodeType\":1,\"id\":2313,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(67.16666666666666,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2314,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2315,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2316,\"textContent\":\"09 AM\"}]}]},{\"nodeType\":1,\"id\":2317,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(100.5,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2318,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2319,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2320,\"textContent\":\"09:30\"}]}]},{\"nodeType\":1,\"id\":2321,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(133.83333333333331,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2322,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2323,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2324,\"textContent\":\"10 AM\"}]}]},{\"nodeType\":1,\"id\":2325,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(167.16666666666669,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2326,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2327,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2328,\"textContent\":\"10:30\"}]}]},{\"nodeType\":1,\"id\":2329,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(200.5,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2330,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2331,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2332,\"textContent\":\"11 AM\"}]}]},{\"nodeType\":1,\"id\":2333,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(233.83333333333334,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2334,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2335,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2336,\"textContent\":\"11:30\"}]}]},{\"nodeType\":1,\"id\":2337,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(267.16666666666663,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2338,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2339,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2340,\"textContent\":\"12 PM\"}]}]},{\"nodeType\":1,\"id\":2341,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(300.5,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2342,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2343,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2344,\"textContent\":\"12:30\"}]}]},{\"nodeType\":1,\"id\":2345,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(333.83333333333337,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2346,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2347,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2348,\"textContent\":\"01 PM\"}]}]},{\"nodeType\":1,\"id\":2349,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(367.16666666666663,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2350,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2351,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2352,\"textContent\":\"01:30\"}]}]},{\"nodeType\":1,\"id\":2353,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(400.5,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2354,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2355,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2356,\"textContent\":\"02 PM\"}]}]},{\"nodeType\":1,\"id\":2357,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(433.8333333333333,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2358,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2359,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2360,\"textContent\":\"02:30\"}]}]},{\"nodeType\":1,\"id\":2361,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(467.1666666666667,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2362,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2363,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2364,\"textContent\":\"03 PM\"}]}]},{\"nodeType\":1,\"id\":2365,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(500.5,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2366,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2367,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2368,\"textContent\":\"03:30\"}]}]},{\"nodeType\":1,\"id\":2369,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(533.8333333333333,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2370,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2371,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2372,\"textContent\":\"04 PM\"}]}]},{\"nodeType\":1,\"id\":2373,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(567.1666666666667,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2374,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2375,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2376,\"textContent\":\"04:30\"}]}]},{\"nodeType\":1,\"id\":2377,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(600.5,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2378,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2379,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2380,\"textContent\":\"05 PM\"}]}]},{\"nodeType\":1,\"id\":2381,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(633.8333333333333,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2382,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2383,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2384,\"textContent\":\"05:30\"}]}]},{\"nodeType\":1,\"id\":2385,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(667.1666666666667,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2386,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2387,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2388,\"textContent\":\"06 PM\"}]}]},{\"nodeType\":1,\"id\":2389,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(700.5,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2390,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2391,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2392,\"textContent\":\"06:30\"}]}]},{\"nodeType\":1,\"id\":2393,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(733.8333333333333,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2394,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2395,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2396,\"textContent\":\"07 PM\"}]}]},{\"nodeType\":1,\"id\":2397,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(767.1666666666667,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2398,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2399,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2400,\"textContent\":\"07:30\"}]}]},{\"nodeType\":1,\"id\":2401,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(800.5,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2402,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2403,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2404,\"textContent\":\"08 PM\"}]}]},{\"nodeType\":1,\"id\":2405,\"tagName\":\"g\",\"attributes\":{\"class\":\"axisTitle\"},\"childNodes\":[{\"nodeType\":1,\"id\":2406,\"tagName\":\"text\",\"attributes\":{\"x\":\"533.3333333333334\",\"y\":\"80\",\"style\":\"text-anchor: end;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2407,\"textContent\":\"START & END TIME (time of day)\"}]}]}]},{\"nodeType\":1,\"id\":2408,\"tagName\":\"g\",\"attributes\":{\"class\":\"yaxis\",\"fill\":\"none\",\"font-size\":\"10\",\"font-family\":\"sans-serif\",\"text-anchor\":\"end\"},\"childNodes\":[{\"nodeType\":1,\"id\":2409,\"tagName\":\"path\",\"attributes\":{\"class\":\"domain\",\"stroke\":\"#000\",\"d\":\"M-15,800.5H0.5V0.5H-15\"}},{\"nodeType\":1,\"id\":2410,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,800.5)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2411,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2412,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2413,\"textContent\":\"0\"}]}]},{\"nodeType\":1,\"id\":2414,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,733.8333333333334)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2415,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2416,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2417,\"textContent\":\"1\"}]}]},{\"nodeType\":1,\"id\":2418,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,667.1666666666667)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2419,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2420,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2421,\"textContent\":\"2\"}]}]},{\"nodeType\":1,\"id\":2422,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,600.5)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2423,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2424,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2425,\"textContent\":\"3\"}]}]},{\"nodeType\":1,\"id\":2426,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,533.8333333333334)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2427,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2428,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2429,\"textContent\":\"4\"}]}]},{\"nodeType\":1,\"id\":2430,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,467.16666666666663)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2431,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2432,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2433,\"textContent\":\"5\"}]}]},{\"nodeType\":1,\"id\":2434,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,400.5)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2435,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2436,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2437,\"textContent\":\"6\"}]}]},{\"nodeType\":1,\"id\":2438,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,333.8333333333333)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2439,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2440,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2441,\"textContent\":\"7\"}]}]},{\"nodeType\":1,\"id\":2442,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,267.16666666666674)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2443,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2444,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2445,\"textContent\":\"8\"}]}]},{\"nodeType\":1,\"id\":2446,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,200.5)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2447,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2448,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2449,\"textContent\":\"9\"}]}]},{\"nodeType\":1,\"id\":2450,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,133.83333333333326)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2451,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2452,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2453,\"textContent\":\"10\"}]}]},{\"nodeType\":1,\"id\":2454,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,67.16666666666674)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2455,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2456,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2457,\"textContent\":\"11\"}]}]},{\"nodeType\":1,\"id\":2458,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,0.5)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2459,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2460,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2461,\"textContent\":\"12\"}]}]},{\"nodeType\":1,\"id\":2462,\"tagName\":\"g\",\"attributes\":{\"class\":\"axisTitle\"},\"childNodes\":[{\"nodeType\":1,\"id\":2463,\"tagName\":\"text\",\"attributes\":{\"transform\":\"rotate(-90)\",\"x\":\"-350\",\"y\":\"-60\",\"style\":\"text-anchor: end;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2464,\"textContent\":\"DURATION (in hours)\"}]}]}]},{\"nodeType\":1,\"id\":2465,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2466,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2467,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"733.3333333333334\",\"y2\":\"733.3333333333334\"}}]},{\"nodeType\":1,\"id\":2468,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2469,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"666.6666666666667\",\"y2\":\"666.6666666666667\"}}]},{\"nodeType\":1,\"id\":2470,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2471,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"600\",\"y2\":\"600\"}}]},{\"nodeType\":1,\"id\":2472,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2473,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"533.3333333333334\",\"y2\":\"533.3333333333334\"}}]},{\"nodeType\":1,\"id\":2474,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2475,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"466.66666666666663\",\"y2\":\"466.66666666666663\"}}]},{\"nodeType\":1,\"id\":2476,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2477,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"400\",\"y2\":\"400\"}}]},{\"nodeType\":1,\"id\":2478,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2479,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"333.3333333333333\",\"y2\":\"333.3333333333333\"}}]},{\"nodeType\":1,\"id\":2480,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2481,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"266.66666666666674\",\"y2\":\"266.66666666666674\"}}]},{\"nodeType\":1,\"id\":2482,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2483,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"200\",\"y2\":\"200\"}}]},{\"nodeType\":1,\"id\":2484,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2485,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"133.33333333333326\",\"y2\":\"133.33333333333326\"}}]},{\"nodeType\":1,\"id\":2486,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2487,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"66.66666666666674\",\"y2\":\"66.66666666666674\"}}]},{\"nodeType\":1,\"id\":2488,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2489,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"0\",\"y2\":\"0\"}}]}]},{\"nodeType\":1,\"id\":2490,\"tagName\":\"g\",\"attributes\":{\"class\":\"xgrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2491,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"0\",\"y1\":\"800\",\"x2\":\"400\",\"y2\":\"0\"}},{\"nodeType\":1,\"id\":2492,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"800\",\"y1\":\"800\",\"x2\":\"400\",\"y2\":\"0\"}},{\"nodeType\":1,\"id\":2493,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"66.66666666666666\",\"y1\":\"800\",\"x2\":\"433.3333333333333\",\"y2\":\"66.66666666666674\"}},{\"nodeType\":1,\"id\":2494,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"733.3333333333333\",\"y1\":\"800\",\"x2\":\"366.66666666666663\",\"y2\":\"66.66666666666674\"}},{\"nodeType\":1,\"id\":2495,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"133.33333333333331\",\"y1\":\"800\",\"x2\":\"466.6666666666667\",\"y2\":\"133.33333333333326\"}},{\"nodeType\":1,\"id\":2496,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"666.6666666666667\",\"y1\":\"800\",\"x2\":\"333.33333333333337\",\"y2\":\"133.33333333333326\"}},{\"nodeType\":1,\"id\":2497,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"200\",\"y1\":\"800\",\"x2\":\"500\",\"y2\":\"200\"}},{\"nodeType\":1,\"id\":2498,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"600\",\"y1\":\"800\",\"x2\":\"300\",\"y2\":\"200\"}},{\"nodeType\":1,\"id\":2499,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"266.66666666666663\",\"y1\":\"800\",\"x2\":\"533.3333333333333\",\"y2\":\"266.66666666666674\"}},{\"nodeType\":1,\"id\":2500,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"533.3333333333333\",\"y1\":\"800\",\"x2\":\"266.66666666666663\",\"y2\":\"266.66666666666674\"}},{\"nodeType\":1,\"id\":2501,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"333.33333333333337\",\"y1\":\"800\",\"x2\":\"566.6666666666667\",\"y2\":\"333.3333333333333\"}},{\"nodeType\":1,\"id\":2502,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"466.6666666666667\",\"y1\":\"800\",\"x2\":\"233.33333333333334\",\"y2\":\"333.3333333333333\"}},{\"nodeType\":1,\"id\":2503,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"400\",\"y1\":\"800\",\"x2\":\"600\",\"y2\":\"400\"}},{\"nodeType\":1,\"id\":2504,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"400\",\"y1\":\"800\",\"x2\":\"200\",\"y2\":\"400\"}},{\"nodeType\":1,\"id\":2505,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"466.6666666666667\",\"y1\":\"800\",\"x2\":\"633.3333333333333\",\"y2\":\"466.66666666666663\"}},{\"nodeType\":1,\"id\":2506,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"333.33333333333337\",\"y1\":\"800\",\"x2\":\"166.66666666666669\",\"y2\":\"466.66666666666663\"}},{\"nodeType\":1,\"id\":2507,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"533.3333333333333\",\"y1\":\"800\",\"x2\":\"666.6666666666667\",\"y2\":\"533.3333333333334\"}},{\"nodeType\":1,\"id\":2508,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"266.66666666666663\",\"y1\":\"800\",\"x2\":\"133.33333333333331\",\"y2\":\"533.3333333333334\"}},{\"nodeType\":1,\"id\":2509,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"600\",\"y1\":\"800\",\"x2\":\"700\",\"y2\":\"600\"}},{\"nodeType\":1,\"id\":2510,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"200\",\"y1\":\"800\",\"x2\":\"100\",\"y2\":\"600\"}},{\"nodeType\":1,\"id\":2511,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"666.6666666666667\",\"y1\":\"800\",\"x2\":\"733.3333333333333\",\"y2\":\"666.6666666666667\"}},{\"nodeType\":1,\"id\":2512,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"133.33333333333331\",\"y1\":\"800\",\"x2\":\"66.66666666666666\",\"y2\":\"666.6666666666667\"}},{\"nodeType\":1,\"id\":2513,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"733.3333333333333\",\"y1\":\"800\",\"x2\":\"766.6666666666667\",\"y2\":\"733.3333333333334\"}},{\"nodeType\":1,\"id\":2514,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"66.66666666666666\",\"y1\":\"800\",\"x2\":\"33.33333333333333\",\"y2\":\"733.3333333333334\"}}]},{\"nodeType\":1,\"id\":2515,\"tagName\":\"g\",\"attributes\":{\"class\":\"data\"},\"childNodes\":[{\"nodeType\":1,\"id\":2516,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2517,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"333.33333333333337\",\"cy\":\"266.66666666666674\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2518,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"328.33333333333337\",\"y\":\"258.66666666666674\"},\"childNodes\":[{\"nodeType\":3,\"id\":2519,\"textContent\":\"A \"}]}]},{\"nodeType\":1,\"id\":2520,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2521,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"266.66666666666663\",\"cy\":\"600\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2522,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"261.66666666666663\",\"y\":\"592\"},\"childNodes\":[{\"nodeType\":3,\"id\":2523,\"textContent\":\"B \"}]}]},{\"nodeType\":1,\"id\":2524,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2525,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"366.66666666666663\",\"cy\":\"466.66666666666663\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2526,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"361.66666666666663\",\"y\":\"458.66666666666663\"},\"childNodes\":[{\"nodeType\":3,\"id\":2527,\"textContent\":\"C \"}]}]},{\"nodeType\":1,\"id\":2528,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2529,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"666.6666666666667\",\"cy\":\"666.6666666666667\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2530,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"661.6666666666667\",\"y\":\"658.6666666666667\"},\"childNodes\":[{\"nodeType\":3,\"id\":2531,\"textContent\":\"D \"}]}]},{\"nodeType\":1,\"id\":2532,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2533,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"200\",\"cy\":\"400\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2534,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"195\",\"y\":\"392\"},\"childNodes\":[{\"nodeType\":3,\"id\":2535,\"textContent\":\"E \"}]}]},{\"nodeType\":1,\"id\":2536,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2537,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"266.66666666666663\",\"cy\":\"533.3333333333334\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2538,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"261.66666666666663\",\"y\":\"525.3333333333334\"},\"childNodes\":[{\"nodeType\":3,\"id\":2539,\"textContent\":\"F \"}]}]},{\"nodeType\":1,\"id\":2540,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2541,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"333.33333333333337\",\"cy\":\"400\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2542,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"328.33333333333337\",\"y\":\"392\"},\"childNodes\":[{\"nodeType\":3,\"id\":2543,\"textContent\":\"G \"}]}]},{\"nodeType\":1,\"id\":2544,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2545,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"500\",\"cy\":\"466.66666666666663\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2546,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"495\",\"y\":\"458.66666666666663\"},\"childNodes\":[{\"nodeType\":3,\"id\":2547,\"textContent\":\"H \"}]}]},{\"nodeType\":1,\"id\":2548,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2549,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"100\",\"cy\":\"600\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2550,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"95\",\"y\":\"592\"},\"childNodes\":[{\"nodeType\":3,\"id\":2551,\"textContent\":\"I \"}]}]},{\"nodeType\":1,\"id\":2552,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2553,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"133.33333333333331\",\"cy\":\"666.6666666666667\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2554,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"128.33333333333331\",\"y\":\"658.6666666666667\"},\"childNodes\":[{\"nodeType\":3,\"id\":2555,\"textContent\":\"J \"}]}]},{\"nodeType\":1,\"id\":2556,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2557,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"400\",\"cy\":\"133.33333333333326\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2558,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"395\",\"y\":\"125.33333333333326\"},\"childNodes\":[{\"nodeType\":3,\"id\":2559,\"textContent\":\"K \"}]}]},{\"nodeType\":1,\"id\":2560,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2561,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"500\",\"cy\":\"333.3333333333333\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2562,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"495\",\"y\":\"325.3333333333333\"},\"childNodes\":[{\"nodeType\":3,\"id\":2563,\"textContent\":\"L \"}]}]},{\"nodeType\":1,\"id\":2564,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2565,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"300\",\"cy\":\"733.3333333333334\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2566,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"295\",\"y\":\"725.3333333333334\"},\"childNodes\":[{\"nodeType\":3,\"id\":2567,\"textContent\":\"M \"}]}]},{\"nodeType\":1,\"id\":2568,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2569,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"600\",\"cy\":\"666.6666666666667\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2570,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"595\",\"y\":\"658.6666666666667\"},\"childNodes\":[{\"nodeType\":3,\"id\":2571,\"textContent\":\"N \"}]}]},{\"nodeType\":1,\"id\":2572,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2573,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"433.3333333333333\",\"cy\":\"600\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2574,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"428.3333333333333\",\"y\":\"592\"},\"childNodes\":[{\"nodeType\":3,\"id\":2575,\"textContent\":\"O \"}]}]},{\"nodeType\":1,\"id\":2576,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2577,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"500\",\"cy\":\"200\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2578,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"495\",\"y\":\"192\"},\"childNodes\":[{\"nodeType\":3,\"id\":2579,\"textContent\":\"P \"}]}]},{\"nodeType\":1,\"id\":2580,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2581,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"533.3333333333333\",\"cy\":\"533.3333333333334\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2582,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"528.3333333333333\",\"y\":\"525.3333333333334\"},\"childNodes\":[{\"nodeType\":3,\"id\":2583,\"textContent\":\"Z \"}]}]},{\"nodeType\":1,\"id\":2584,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2585,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"400\",\"cy\":\"666.6666666666667\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2586,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"395\",\"y\":\"658.6666666666667\"},\"childNodes\":[{\"nodeType\":3,\"id\":2587,\"textContent\":\"X \"}]}]}]}]}]}]},{\"nodeType\":3,\"id\":2588,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2589,\"textContent\":\" \"},{\"nodeType\":8,\"id\":2590},{\"nodeType\":3,\"id\":2591,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2592,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":2593,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2594,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":2595,\"textContent\":\" \"}]}]}]]}",
  "useCssProxy": true,
  "loadTimes": "es: 252, dom: 1053, initialDom: 1141",
  "javascriptErrors": []
}