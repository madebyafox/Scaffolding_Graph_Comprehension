var MF = MF || {};MF.RecordingData = MF.RecordingData || {};MF.RecordingData["session"] = {
  "id": "7a9ca8a739d5798437aa79a9b07bca03",
  "created": "2018-05-29T10:03:19.014463-07:00",
  "lastActivity": "2018-05-29T10:05:05.642108-07:00",
  "pageViews": [
    {
      "id": "052918108d5624e78b65f8d9460166b0a2b13026",
      "startTime": "2018-05-29T10:03:19.014463-07:00",
      "endTime": "2018-05-29T10:05:05.642108-07:00",
      "title": "FOX2YP",
      "uri": "https://warm-citadel-75324.herokuapp.com/",
      "websitePage": "/",
      "visitTime": 107017,
      "engagementTime": 65491,
      "scroll": 100.0,
      "tags": [
        "form-interact"
      ],
      "friction": 0,
      "annotations": []
    }
  ],
  "duration": 107017,
  "engagementTime": 65491,
  "totalFriction": 0,
  "country": "us",
  "region": "CA",
  "city": "La Jolla",
  "isp": "University of California, San Diego",
  "ip": "128.54.68.36",
  "lang": "en-US",
  "userAgent": "Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/66.0.3359.181 Safari/537.36",
  "browser": "Chrome",
  "browserVersion": "66.0.3359.181",
  "os": "Windows",
  "osVersion": "7",
  "device": "Desktop",
  "referrer": "",
  "referrerType": "",
  "screenRes": "1920x1200",
  "tags": [
    "form-interact"
  ],
  "variables": [],
  "watched": false,
  "starred": false,
  "lng": -117.2359,
  "lat": 32.8807,
  "visitorId": "9c36112c0ccf3ce4306f5145fcc24203",
  "gdpr": false
}