var MF = MF || {};MF.RecordingData = MF.RecordingData || {};MF.RecordingData["session"] = {
  "id": "74e6d72152a9f4d4502b3fc6e1880774",
  "created": "2018-06-01T11:14:41.5112833-07:00",
  "lastActivity": "2018-06-01T11:14:51.3365344-07:00",
  "pageViews": [
    {
      "id": "06014125c42cac61750b9575d3c75ec50a0fd1a5",
      "startTime": "2018-06-01T11:14:41.5112833-07:00",
      "endTime": "2018-06-01T11:14:51.3365344-07:00",
      "title": "FOX2YP",
      "uri": "https://warm-citadel-75324.herokuapp.com/",
      "websitePage": "/14",
      "visitTime": 9839,
      "engagementTime": 9740,
      "scroll": 100.0,
      "tags": [
        "form-interact"
      ],
      "friction": 0,
      "annotations": []
    }
  ],
  "duration": 9839,
  "engagementTime": 9740,
  "totalFriction": 0,
  "country": "us",
  "region": "CA",
  "city": "La Jolla",
  "isp": "University of California, San Diego",
  "ip": "128.54.68.27",
  "lang": "en-US",
  "userAgent": "Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/66.0.3359.181 Safari/537.36",
  "browser": "Chrome",
  "browserVersion": "66.0.3359.181",
  "os": "Windows",
  "osVersion": "7",
  "device": "Desktop",
  "referrer": "",
  "referrerType": "",
  "screenRes": "1920x1200",
  "tags": [
    "form-interact"
  ],
  "variables": [
    "SID=AG2V3",
    "CONDITION=311",
    "TRI_CORRECT=1"
  ],
  "watched": false,
  "starred": false,
  "lng": -117.2359,
  "lat": 32.8807,
  "visitorId": "a66dd31be34a05f0626a7fe784d51935",
  "gdpr": false
}