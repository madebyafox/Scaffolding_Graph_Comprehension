var MF = MF || {};MF.RecordingData = MF.RecordingData || {};MF.RecordingData["06011783fe62c5a6b33827b5d8639e232d990bc7"] = {
  "startTime": "2018-06-01T18:14:17.1883833Z",
  "websitePageUrl": "/16",
  "visitTime": 113164,
  "engagementTime": 106350,
  "pageTitle": "FOX2YP",
  "url": "https://warm-citadel-75324.herokuapp.com/",
  "viewportWidth": 1920,
  "viewportHeight": 1200,
  "tags": [
    "form-interact",
    "submit"
  ],
  "session": {
    "id": "2cdf926ff156fea7024d4787daea6085",
    "created": "2018-06-01T18:14:17.1883833+00:00",
    "lastActivity": "0001-01-01T00:00:00+00:00",
    "pages": 1,
    "duration": 0,
    "engagementTime": 0,
    "totalFriction": 0,
    "country": "us",
    "region": "CA",
    "city": "La Jolla",
    "isp": "University of California, San Diego",
    "ip": "###.###.###.###",
    "lang": "en-US",
    "userAgent": "Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/66.0.3359.181 Safari/537.36",
    "browser": "Chrome",
    "browserVersion": "66.0.3359.181",
    "os": "Windows",
    "osVersion": "7",
    "device": "Desktop",
    "referrer": "",
    "referrerType": "",
    "screenRes": "1920x1200",
    "entryPage": "/16",
    "tags": [
      "form-interact",
      "submit"
    ],
    "variables": [
      "SID=HW2SN",
      "CONDITION=311"
    ],
    "watched": false,
    "starred": false,
    "lng": 32.8807,
    "lat": 32.8807,
    "visitorId": "a184fa66648be8acbdb178740025c63b",
    "gdpr": false,
    "visitorName": null,
    "playbackUrl": "https://us.mouseflow.com/websites/e0c9ff05-6fcb-4c4a-8173-e5a0724987b1/recordings/2cdf926ff156fea7024d4787daea6085/play"
  },
  "events": [
    {
      "t": 2,
      "e": 2,
      "ty": 14,
      "x": 0,
      "y": 1199
    },
    {
      "t": 247,
      "e": 247,
      "ty": 0,
      "x": 1920,
      "y": 1200
    },
    {
      "t": 2101,
      "e": 2101,
      "ty": 2,
      "x": 538,
      "y": 727
    },
    {
      "t": 2200,
      "e": 2200,
      "ty": 2,
      "x": 537,
      "y": 720
    },
    {
      "t": 2251,
      "e": 2251,
      "ty": 41,
      "x": 49449,
      "y": 39332,
      "ta": "> div.stimulus > div"
    },
    {
      "t": 2300,
      "e": 2300,
      "ty": 2,
      "x": 536,
      "y": 717
    },
    {
      "t": 2401,
      "e": 2401,
      "ty": 2,
      "x": 535,
      "y": 716
    },
    {
      "t": 2501,
      "e": 2501,
      "ty": 41,
      "x": 49225,
      "y": 39221,
      "ta": "> div.stimulus > div"
    },
    {
      "t": 5001,
      "e": 5001,
      "ty": 2,
      "x": 594,
      "y": 723
    },
    {
      "t": 5001,
      "e": 5001,
      "ty": 41,
      "x": 55857,
      "y": 39609,
      "ta": "> div.stimulus > div"
    },
    {
      "t": 5101,
      "e": 5101,
      "ty": 2,
      "x": 677,
      "y": 738
    },
    {
      "t": 5201,
      "e": 5201,
      "ty": 2,
      "x": 761,
      "y": 754
    },
    {
      "t": 5251,
      "e": 5251,
      "ty": 41,
      "x": 3383,
      "y": 44979,
      "ta": "> div.stimulus > div:[2] > svg"
    },
    {
      "t": 5301,
      "e": 5301,
      "ty": 2,
      "x": 908,
      "y": 777
    },
    {
      "t": 5401,
      "e": 5401,
      "ty": 2,
      "x": 955,
      "y": 785
    },
    {
      "t": 5501,
      "e": 5501,
      "ty": 41,
      "x": 11910,
      "y": 46340,
      "ta": "> div.stimulus > div:[2] > svg"
    },
    {
      "t": 7101,
      "e": 7101,
      "ty": 2,
      "x": 962,
      "y": 790
    },
    {
      "t": 7201,
      "e": 7201,
      "ty": 2,
      "x": 963,
      "y": 790
    },
    {
      "t": 7251,
      "e": 7251,
      "ty": 41,
      "x": 12473,
      "y": 46698,
      "ta": "> div.stimulus > div:[2] > svg"
    },
    {
      "t": 8251,
      "e": 8251,
      "ty": 41,
      "x": 12755,
      "y": 47127,
      "ta": "> div.stimulus > div:[2] > svg"
    },
    {
      "t": 8301,
      "e": 8301,
      "ty": 2,
      "x": 983,
      "y": 802
    },
    {
      "t": 8401,
      "e": 8401,
      "ty": 2,
      "x": 1020,
      "y": 816
    },
    {
      "t": 8501,
      "e": 8501,
      "ty": 2,
      "x": 1057,
      "y": 845
    },
    {
      "t": 8501,
      "e": 8501,
      "ty": 41,
      "x": 19097,
      "y": 50637,
      "ta": "> div.stimulus > div:[2] > svg"
    },
    {
      "t": 8601,
      "e": 8601,
      "ty": 2,
      "x": 1092,
      "y": 871
    },
    {
      "t": 8701,
      "e": 8701,
      "ty": 2,
      "x": 1124,
      "y": 897
    },
    {
      "t": 8751,
      "e": 8751,
      "ty": 41,
      "x": 24664,
      "y": 55078,
      "ta": "> div.stimulus > div:[2] > svg"
    },
    {
      "t": 8801,
      "e": 8801,
      "ty": 2,
      "x": 1138,
      "y": 909
    },
    {
      "t": 8901,
      "e": 8901,
      "ty": 2,
      "x": 1156,
      "y": 933
    },
    {
      "t": 9001,
      "e": 9001,
      "ty": 2,
      "x": 1167,
      "y": 950
    },
    {
      "t": 9001,
      "e": 9001,
      "ty": 41,
      "x": 26849,
      "y": 58157,
      "ta": "> div.stimulus > div:[2] > svg"
    },
    {
      "t": 9101,
      "e": 9101,
      "ty": 2,
      "x": 1167,
      "y": 956
    },
    {
      "t": 9201,
      "e": 9201,
      "ty": 2,
      "x": 1148,
      "y": 965
    },
    {
      "t": 9252,
      "e": 9252,
      "ty": 41,
      "x": 25369,
      "y": 59232,
      "ta": "> div.stimulus > div:[2] > svg"
    },
    {
      "t": 9301,
      "e": 9301,
      "ty": 2,
      "x": 1146,
      "y": 965
    },
    {
      "t": 10001,
      "e": 10001,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 11105,
      "e": 11105,
      "ty": 2,
      "x": 1147,
      "y": 966
    },
    {
      "t": 11255,
      "e": 11255,
      "ty": 41,
      "x": 25439,
      "y": 59303,
      "ta": "> div.stimulus > div:[2] > svg"
    },
    {
      "t": 11404,
      "e": 11404,
      "ty": 2,
      "x": 1152,
      "y": 956
    },
    {
      "t": 11504,
      "e": 11504,
      "ty": 2,
      "x": 1177,
      "y": 915
    },
    {
      "t": 11504,
      "e": 11504,
      "ty": 41,
      "x": 5983,
      "y": 59636,
      "ta": "> div.stimulus > div:[2] > svg > g > g:[6] > line:[9]"
    },
    {
      "t": 11604,
      "e": 11604,
      "ty": 2,
      "x": 1135,
      "y": 804
    },
    {
      "t": 11704,
      "e": 11704,
      "ty": 2,
      "x": 696,
      "y": 654
    },
    {
      "t": 11755,
      "e": 11755,
      "ty": 41,
      "x": 58555,
      "y": 34457,
      "ta": "> div.stimulus > div"
    },
    {
      "t": 11804,
      "e": 11804,
      "ty": 2,
      "x": 617,
      "y": 629
    },
    {
      "t": 11905,
      "e": 11905,
      "ty": 2,
      "x": 595,
      "y": 618
    },
    {
      "t": 11949,
      "e": 11949,
      "ty": 6,
      "x": 579,
      "y": 603,
      "ta": "#strategyAnswer"
    },
    {
      "t": 12004,
      "e": 12004,
      "ty": 2,
      "x": 572,
      "y": 593
    },
    {
      "t": 12004,
      "e": 12004,
      "ty": 41,
      "x": 53384,
      "y": 56850,
      "ta": "#strategyAnswer"
    },
    {
      "t": 12227,
      "e": 12227,
      "ty": 3,
      "x": 572,
      "y": 593,
      "ta": "#strategyAnswer"
    },
    {
      "t": 12228,
      "e": 12228,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 12337,
      "e": 12337,
      "ty": 4,
      "x": 53384,
      "y": 56850,
      "ta": "#strategyAnswer"
    },
    {
      "t": 12337,
      "e": 12337,
      "ty": 5,
      "x": 572,
      "y": 593,
      "ta": "#strategyAnswer"
    },
    {
      "t": 13614,
      "e": 13614,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "16"
    },
    {
      "t": 14021,
      "e": 14021,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "71"
    },
    {
      "t": 14021,
      "e": 14021,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 14108,
      "e": 14108,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "G"
    },
    {
      "t": 14132,
      "e": 14132,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "G"
    },
    {
      "t": 14197,
      "e": 14197,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "79"
    },
    {
      "t": 14197,
      "e": 14197,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 14284,
      "e": 14284,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 14284,
      "e": 14284,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 14340,
      "e": 14340,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Go "
    },
    {
      "t": 14412,
      "e": 14412,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Go "
    },
    {
      "t": 14445,
      "e": 14445,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 14445,
      "e": 14445,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 14516,
      "e": 14516,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Go t"
    },
    {
      "t": 14524,
      "e": 14524,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "79"
    },
    {
      "t": 14525,
      "e": 14525,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 14604,
      "e": 14604,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 14604,
      "e": 14604,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 14628,
      "e": 14628,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||o "
    },
    {
      "t": 14700,
      "e": 14700,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 14700,
      "e": 14700,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 14732,
      "e": 14732,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 14773,
      "e": 14773,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 14949,
      "e": 14949,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "72"
    },
    {
      "t": 14950,
      "e": 14950,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 15044,
      "e": 15044,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||h"
    },
    {
      "t": 15100,
      "e": 15100,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 15101,
      "e": 15101,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 15189,
      "e": 15189,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||e"
    },
    {
      "t": 15221,
      "e": 15221,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 15222,
      "e": 15222,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 15349,
      "e": 15349,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 15597,
      "e": 15597,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "49"
    },
    {
      "t": 15597,
      "e": 15597,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 15717,
      "e": 15717,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "50"
    },
    {
      "t": 15717,
      "e": 15717,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 15748,
      "e": 15748,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||12"
    },
    {
      "t": 15805,
      "e": 15805,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 16645,
      "e": 16645,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "80"
    },
    {
      "t": 16646,
      "e": 16646,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 16724,
      "e": 16724,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||p"
    },
    {
      "t": 17061,
      "e": 17061,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "77"
    },
    {
      "t": 17062,
      "e": 17062,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 17196,
      "e": 17196,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 17196,
      "e": 17196,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 17220,
      "e": 17220,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||m "
    },
    {
      "t": 17324,
      "e": 17324,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 17405,
      "e": 17405,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "16"
    },
    {
      "t": 17501,
      "e": 17501,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "83"
    },
    {
      "t": 17501,
      "e": 17501,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 17607,
      "e": 17607,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Go to the 12pm S"
    },
    {
      "t": 17628,
      "e": 17628,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||S"
    },
    {
      "t": 17653,
      "e": 17653,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 17669,
      "e": 17669,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 17669,
      "e": 17669,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 17748,
      "e": 17748,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 18317,
      "e": 18317,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 18396,
      "e": 18396,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Go to the 12pm S"
    },
    {
      "t": 18492,
      "e": 18492,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 18548,
      "e": 18548,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Go to the 12pm "
    },
    {
      "t": 18796,
      "e": 18796,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "16"
    },
    {
      "t": 19296,
      "e": 19296,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "16"
    },
    {
      "t": 19329,
      "e": 19329,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "16"
    },
    {
      "t": 19363,
      "e": 19363,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "16"
    },
    {
      "t": 19395,
      "e": 19395,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "16"
    },
    {
      "t": 19428,
      "e": 19428,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "16"
    },
    {
      "t": 19461,
      "e": 19461,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "16"
    },
    {
      "t": 19494,
      "e": 19494,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "16"
    },
    {
      "t": 19527,
      "e": 19527,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "16"
    },
    {
      "t": 19560,
      "e": 19560,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "16"
    },
    {
      "t": 19593,
      "e": 19593,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "16"
    },
    {
      "t": 19626,
      "e": 19626,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "16"
    },
    {
      "t": 19659,
      "e": 19659,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "16"
    },
    {
      "t": 19692,
      "e": 19692,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "16"
    },
    {
      "t": 19725,
      "e": 19725,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "16"
    },
    {
      "t": 19758,
      "e": 19758,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "16"
    },
    {
      "t": 19791,
      "e": 19791,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "16"
    },
    {
      "t": 19824,
      "e": 19824,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "16"
    },
    {
      "t": 19857,
      "e": 19857,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "16"
    },
    {
      "t": 19891,
      "e": 19891,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "16"
    },
    {
      "t": 19923,
      "e": 19923,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "16"
    },
    {
      "t": 19956,
      "e": 19956,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "16"
    },
    {
      "t": 19988,
      "e": 19988,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "16"
    },
    {
      "t": 20005,
      "e": 20005,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 20021,
      "e": 20021,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "16"
    },
    {
      "t": 20055,
      "e": 20055,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "16"
    },
    {
      "t": 20087,
      "e": 20087,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "16"
    },
    {
      "t": 20121,
      "e": 20121,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "16"
    },
    {
      "t": 20153,
      "e": 20153,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "16"
    },
    {
      "t": 20186,
      "e": 20186,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "16"
    },
    {
      "t": 20220,
      "e": 20220,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "16"
    },
    {
      "t": 20253,
      "e": 20253,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "16"
    },
    {
      "t": 20286,
      "e": 20286,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "16"
    },
    {
      "t": 20319,
      "e": 20319,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "16"
    },
    {
      "t": 20351,
      "e": 20351,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "16"
    },
    {
      "t": 20384,
      "e": 20384,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "16"
    },
    {
      "t": 20417,
      "e": 20417,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "16"
    },
    {
      "t": 20450,
      "e": 20450,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "16"
    },
    {
      "t": 20484,
      "e": 20484,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "16"
    },
    {
      "t": 20517,
      "e": 20517,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "16"
    },
    {
      "t": 20550,
      "e": 20550,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "16"
    },
    {
      "t": 20583,
      "e": 20583,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "16"
    },
    {
      "t": 20616,
      "e": 20616,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "16"
    },
    {
      "t": 20649,
      "e": 20649,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "16"
    },
    {
      "t": 20682,
      "e": 20682,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "16"
    },
    {
      "t": 20715,
      "e": 20715,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "16"
    },
    {
      "t": 20748,
      "e": 20748,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "16"
    },
    {
      "t": 20781,
      "e": 20781,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "16"
    },
    {
      "t": 20814,
      "e": 20814,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "16"
    },
    {
      "t": 20847,
      "e": 20847,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "16"
    },
    {
      "t": 20880,
      "e": 20880,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "16"
    },
    {
      "t": 20913,
      "e": 20913,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "16"
    },
    {
      "t": 20946,
      "e": 20946,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "16"
    },
    {
      "t": 20979,
      "e": 20979,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "16"
    },
    {
      "t": 21012,
      "e": 21012,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "16"
    },
    {
      "t": 21046,
      "e": 21046,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "16"
    },
    {
      "t": 21078,
      "e": 21078,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "16"
    },
    {
      "t": 21111,
      "e": 21111,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "16"
    },
    {
      "t": 21125,
      "e": 21125,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 27004,
      "e": 26125,
      "ty": 2,
      "x": 489,
      "y": 568
    },
    {
      "t": 27005,
      "e": 26126,
      "ty": 41,
      "x": 44054,
      "y": 36623,
      "ta": "#strategyAnswer"
    },
    {
      "t": 27104,
      "e": 26225,
      "ty": 2,
      "x": 501,
      "y": 568
    },
    {
      "t": 27255,
      "e": 26376,
      "ty": 41,
      "x": 45403,
      "y": 36623,
      "ta": "#strategyAnswer"
    },
    {
      "t": 27304,
      "e": 26425,
      "ty": 2,
      "x": 502,
      "y": 568
    },
    {
      "t": 27490,
      "e": 26611,
      "ty": 3,
      "x": 502,
      "y": 568,
      "ta": "#strategyAnswer"
    },
    {
      "t": 27504,
      "e": 26625,
      "ty": 41,
      "x": 45515,
      "y": 36623,
      "ta": "#strategyAnswer"
    },
    {
      "t": 27604,
      "e": 26725,
      "ty": 2,
      "x": 387,
      "y": 569
    },
    {
      "t": 27645,
      "e": 26766,
      "ty": 7,
      "x": 61,
      "y": 577,
      "ta": "#strategyAnswer"
    },
    {
      "t": 27704,
      "e": 26825,
      "ty": 2,
      "x": 0,
      "y": 578
    },
    {
      "t": 27754,
      "e": 26875,
      "ty": 41,
      "x": 0,
      "y": 32019,
      "ta": "html"
    },
    {
      "t": 27945,
      "e": 27066,
      "ty": 4,
      "x": 0,
      "y": 32019,
      "ta": "html"
    },
    {
      "t": 28540,
      "e": 27661,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "16"
    },
    {
      "t": 28669,
      "e": 27790,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "70"
    },
    {
      "t": 28670,
      "e": 27791,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 28764,
      "e": 27885,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "F"
    },
    {
      "t": 28765,
      "e": 27886,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "F"
    },
    {
      "t": 28884,
      "e": 28005,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "79"
    },
    {
      "t": 28885,
      "e": 28006,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 28972,
      "e": 28093,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Fo"
    },
    {
      "t": 29052,
      "e": 28173,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "76"
    },
    {
      "t": 29052,
      "e": 28173,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 29141,
      "e": 28262,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Fol"
    },
    {
      "t": 29173,
      "e": 28294,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "76"
    },
    {
      "t": 29173,
      "e": 28294,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 29244,
      "e": 28365,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Foll"
    },
    {
      "t": 29516,
      "e": 28637,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "79"
    },
    {
      "t": 29516,
      "e": 28637,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 29588,
      "e": 28709,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||o"
    },
    {
      "t": 29612,
      "e": 28733,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "87"
    },
    {
      "t": 29612,
      "e": 28733,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 29700,
      "e": 28821,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||w"
    },
    {
      "t": 29796,
      "e": 28917,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 29797,
      "e": 28918,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 29940,
      "e": 29061,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 30004,
      "e": 29125,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 30221,
      "e": 29342,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 30221,
      "e": 29342,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 30276,
      "e": 29397,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 30317,
      "e": 29438,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "72"
    },
    {
      "t": 30317,
      "e": 29438,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 30436,
      "e": 29557,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||h"
    },
    {
      "t": 30452,
      "e": 29573,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 30452,
      "e": 29573,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 30541,
      "e": 29662,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||e"
    },
    {
      "t": 30548,
      "e": 29669,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 30550,
      "e": 29671,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 30708,
      "e": 29829,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 30717,
      "e": 29838,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 30717,
      "e": 29838,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 30780,
      "e": 29901,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 30852,
      "e": 29973,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "73"
    },
    {
      "t": 30852,
      "e": 29973,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 30972,
      "e": 30093,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||i"
    },
    {
      "t": 31236,
      "e": 30357,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "77"
    },
    {
      "t": 31237,
      "e": 30358,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 31381,
      "e": 30502,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||m"
    },
    {
      "t": 31404,
      "e": 30525,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 31405,
      "e": 30526,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 31485,
      "e": 30606,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||e"
    },
    {
      "t": 31492,
      "e": 30613,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 31494,
      "e": 30615,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 31604,
      "e": 30725,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 31636,
      "e": 30757,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 31636,
      "e": 30757,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 31797,
      "e": 30918,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||a"
    },
    {
      "t": 31941,
      "e": 31062,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "88"
    },
    {
      "t": 31941,
      "e": 31062,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 32133,
      "e": 31254,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||x"
    },
    {
      "t": 32188,
      "e": 31309,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "73"
    },
    {
      "t": 32189,
      "e": 31310,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 32340,
      "e": 31461,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "83"
    },
    {
      "t": 32340,
      "e": 31461,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 32348,
      "e": 31469,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||is"
    },
    {
      "t": 32412,
      "e": 31533,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 32725,
      "e": 31846,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 32726,
      "e": 31847,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 32876,
      "e": 31997,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "85"
    },
    {
      "t": 32876,
      "e": 31997,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 32917,
      "e": 32038,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| u"
    },
    {
      "t": 32989,
      "e": 32110,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 33068,
      "e": 32189,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "78"
    },
    {
      "t": 33069,
      "e": 32190,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 33172,
      "e": 32293,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||n"
    },
    {
      "t": 33188,
      "e": 32309,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 33188,
      "e": 32309,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 33268,
      "e": 32389,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 33300,
      "e": 32421,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "73"
    },
    {
      "t": 33301,
      "e": 32422,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 33380,
      "e": 32501,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||i"
    },
    {
      "t": 33509,
      "e": 32630,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "76"
    },
    {
      "t": 33509,
      "e": 32630,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 33628,
      "e": 32749,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||l"
    },
    {
      "t": 33636,
      "e": 32757,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 33637,
      "e": 32758,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 33806,
      "e": 32927,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Follow the time axis until "
    },
    {
      "t": 33836,
      "e": 32957,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "89"
    },
    {
      "t": 33837,
      "e": 32958,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 33844,
      "e": 32965,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| y"
    },
    {
      "t": 33971,
      "e": 33092,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 34028,
      "e": 33149,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "79"
    },
    {
      "t": 34028,
      "e": 33149,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 34124,
      "e": 33245,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "85"
    },
    {
      "t": 34124,
      "e": 33245,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 34205,
      "e": 33326,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||ou"
    },
    {
      "t": 34228,
      "e": 33349,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 34230,
      "e": 33351,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 34252,
      "e": 33373,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 34380,
      "e": 33501,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "72"
    },
    {
      "t": 34380,
      "e": 33501,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 34404,
      "e": 33525,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||h"
    },
    {
      "t": 34572,
      "e": 33693,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 34573,
      "e": 33694,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "73"
    },
    {
      "t": 34576,
      "e": 33697,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 34668,
      "e": 33789,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||i"
    },
    {
      "t": 34684,
      "e": 33805,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 34684,
      "e": 33805,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 34724,
      "e": 33845,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 34764,
      "e": 33885,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 34765,
      "e": 33886,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 34860,
      "e": 33981,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 35244,
      "e": 34365,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "49"
    },
    {
      "t": 35245,
      "e": 34366,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 35380,
      "e": 34501,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||1"
    },
    {
      "t": 35380,
      "e": 34501,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "50"
    },
    {
      "t": 35381,
      "e": 34502,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 35452,
      "e": 34573,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||2"
    },
    {
      "t": 35692,
      "e": 34813,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "80"
    },
    {
      "t": 35693,
      "e": 34814,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 35807,
      "e": 34928,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Follow the time axis until you hit 12p"
    },
    {
      "t": 35821,
      "e": 34942,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||p"
    },
    {
      "t": 35893,
      "e": 35014,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "77"
    },
    {
      "t": 35893,
      "e": 35014,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 35979,
      "e": 35100,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||m"
    },
    {
      "t": 36253,
      "e": 35374,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "188"
    },
    {
      "t": 36253,
      "e": 35374,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 36372,
      "e": 35493,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||,"
    },
    {
      "t": 37083,
      "e": 36204,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 37083,
      "e": 36204,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 37207,
      "e": 36328,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Follow the time axis until you hit 12pm, "
    },
    {
      "t": 37228,
      "e": 36349,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 37309,
      "e": 36430,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 37309,
      "e": 36430,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 37372,
      "e": 36493,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "72"
    },
    {
      "t": 37372,
      "e": 36493,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 37411,
      "e": 36532,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||th"
    },
    {
      "t": 37451,
      "e": 36572,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 37508,
      "e": 36629,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 37509,
      "e": 36630,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 37596,
      "e": 36717,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||e"
    },
    {
      "t": 37612,
      "e": 36733,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "78"
    },
    {
      "t": 37613,
      "e": 36734,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 37715,
      "e": 36836,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 37716,
      "e": 36837,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 37740,
      "e": 36837,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||n "
    },
    {
      "t": 37787,
      "e": 36884,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "70"
    },
    {
      "t": 37789,
      "e": 36886,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 37836,
      "e": 36933,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||f"
    },
    {
      "t": 37901,
      "e": 36998,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "79"
    },
    {
      "t": 37901,
      "e": 36998,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 37908,
      "e": 37005,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||o"
    },
    {
      "t": 37957,
      "e": 37054,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 38085,
      "e": 37182,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "76"
    },
    {
      "t": 38085,
      "e": 37182,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 38139,
      "e": 37236,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||l"
    },
    {
      "t": 38227,
      "e": 37324,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "76"
    },
    {
      "t": 38228,
      "e": 37325,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 38317,
      "e": 37414,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||l"
    },
    {
      "t": 38444,
      "e": 37541,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "79"
    },
    {
      "t": 38446,
      "e": 37543,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 38508,
      "e": 37605,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||o"
    },
    {
      "t": 38540,
      "e": 37637,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "87"
    },
    {
      "t": 38540,
      "e": 37637,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 38668,
      "e": 37765,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||w"
    },
    {
      "t": 38701,
      "e": 37798,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 38701,
      "e": 37798,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 38806,
      "e": 37903,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Follow the time axis until you hit 12pm, then follow "
    },
    {
      "t": 38835,
      "e": 37932,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 38860,
      "e": 37957,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 38860,
      "e": 37957,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 38949,
      "e": 38046,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "72"
    },
    {
      "t": 38950,
      "e": 38047,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 38964,
      "e": 38061,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||th"
    },
    {
      "t": 39059,
      "e": 38156,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 39059,
      "e": 38156,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 39084,
      "e": 38181,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||e"
    },
    {
      "t": 39092,
      "e": 38189,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 39092,
      "e": 38189,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 39140,
      "e": 38237,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 39221,
      "e": 38318,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 40445,
      "e": 39542,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "68"
    },
    {
      "t": 40445,
      "e": 39542,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 40547,
      "e": 39644,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "73"
    },
    {
      "t": 40547,
      "e": 39644,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 40564,
      "e": 39661,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||di"
    },
    {
      "t": 40644,
      "e": 39741,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 40644,
      "e": 39741,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 40651,
      "e": 39748,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||a"
    },
    {
      "t": 40780,
      "e": 39877,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 40805,
      "e": 39902,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "71"
    },
    {
      "t": 40805,
      "e": 39902,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 40892,
      "e": 39989,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||g"
    },
    {
      "t": 41196,
      "e": 40293,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "79"
    },
    {
      "t": 41197,
      "e": 40294,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 41315,
      "e": 40412,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||o"
    },
    {
      "t": 41332,
      "e": 40429,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "78"
    },
    {
      "t": 41333,
      "e": 40430,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 41436,
      "e": 40533,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||n"
    },
    {
      "t": 41620,
      "e": 40717,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 41620,
      "e": 40717,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 41764,
      "e": 40861,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||a"
    },
    {
      "t": 41780,
      "e": 40877,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "76"
    },
    {
      "t": 41781,
      "e": 40878,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 41900,
      "e": 40997,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 41900,
      "e": 40997,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 41908,
      "e": 41005,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||l "
    },
    {
      "t": 42036,
      "e": 41133,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 44444,
      "e": 43541,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "76"
    },
    {
      "t": 44445,
      "e": 43542,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 44555,
      "e": 43652,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||l"
    },
    {
      "t": 44733,
      "e": 43830,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "73"
    },
    {
      "t": 44733,
      "e": 43830,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 44828,
      "e": 43925,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||i"
    },
    {
      "t": 44916,
      "e": 44013,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "78"
    },
    {
      "t": 44917,
      "e": 44014,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 44988,
      "e": 44085,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 44988,
      "e": 44085,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 45012,
      "e": 44109,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||ne"
    },
    {
      "t": 45060,
      "e": 44157,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 46140,
      "e": 45237,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 46140,
      "e": 45237,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 46268,
      "e": 45365,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 46349,
      "e": 45446,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "71"
    },
    {
      "t": 46351,
      "e": 45448,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 46428,
      "e": 45525,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "79"
    },
    {
      "t": 46428,
      "e": 45525,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 46436,
      "e": 45533,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||go"
    },
    {
      "t": 46524,
      "e": 45621,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "73"
    },
    {
      "t": 46524,
      "e": 45621,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 46572,
      "e": 45669,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||i"
    },
    {
      "t": 46692,
      "e": 45789,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 46701,
      "e": 45798,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "78"
    },
    {
      "t": 46701,
      "e": 45798,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 46763,
      "e": 45860,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "71"
    },
    {
      "t": 46764,
      "e": 45861,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 46835,
      "e": 45932,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 46836,
      "e": 45933,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 46844,
      "e": 45941,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||ng "
    },
    {
      "t": 46851,
      "e": 45948,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 46933,
      "e": 46030,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "70"
    },
    {
      "t": 46933,
      "e": 46030,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 47004,
      "e": 46101,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||f"
    },
    {
      "t": 47028,
      "e": 46125,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 47069,
      "e": 46166,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "79"
    },
    {
      "t": 47069,
      "e": 46166,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 47179,
      "e": 46276,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||o"
    },
    {
      "t": 47180,
      "e": 46277,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "82"
    },
    {
      "t": 47180,
      "e": 46277,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 47253,
      "e": 46350,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||r"
    },
    {
      "t": 47388,
      "e": 46485,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "87"
    },
    {
      "t": 47389,
      "e": 46486,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 47484,
      "e": 46581,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 47484,
      "e": 46581,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 47563,
      "e": 46660,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||wa"
    },
    {
      "t": 47629,
      "e": 46726,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 47637,
      "e": 46734,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "82"
    },
    {
      "t": 47638,
      "e": 46735,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 47716,
      "e": 46813,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||r"
    },
    {
      "t": 47844,
      "e": 46941,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "68"
    },
    {
      "t": 47845,
      "e": 46942,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 47980,
      "e": 47077,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||d"
    },
    {
      "t": 48373,
      "e": 47470,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "190"
    },
    {
      "t": 48374,
      "e": 47471,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 48459,
      "e": 47556,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||."
    },
    {
      "t": 48932,
      "e": 48029,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 49028,
      "e": 48030,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Follow the time axis until you hit 12pm, then follow the diagonal line going forward"
    },
    {
      "t": 49229,
      "e": 48231,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 49229,
      "e": 48231,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 49339,
      "e": 48341,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "85"
    },
    {
      "t": 49340,
      "e": 48342,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 49380,
      "e": 48382,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| u"
    },
    {
      "t": 49443,
      "e": 48445,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 49548,
      "e": 48550,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "78"
    },
    {
      "t": 49549,
      "e": 48551,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 49619,
      "e": 48621,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 49619,
      "e": 48621,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 49635,
      "e": 48637,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||nt"
    },
    {
      "t": 49707,
      "e": 48709,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 49747,
      "e": 48749,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "73"
    },
    {
      "t": 49749,
      "e": 48751,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 49811,
      "e": 48813,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||i"
    },
    {
      "t": 50043,
      "e": 49045,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "76"
    },
    {
      "t": 50044,
      "e": 49046,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 50164,
      "e": 49166,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||l"
    },
    {
      "t": 50269,
      "e": 49271,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 50269,
      "e": 49271,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 50405,
      "e": 49407,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Follow the time axis until you hit 12pm, then follow the diagonal line going forward until "
    },
    {
      "t": 50420,
      "e": 49422,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 50525,
      "e": 49527,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "89"
    },
    {
      "t": 50525,
      "e": 49527,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 50635,
      "e": 49637,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||y"
    },
    {
      "t": 50756,
      "e": 49758,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "79"
    },
    {
      "t": 50757,
      "e": 49759,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 50941,
      "e": 49943,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "85"
    },
    {
      "t": 50941,
      "e": 49943,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 50948,
      "e": 49950,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||ou"
    },
    {
      "t": 51035,
      "e": 50037,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 51036,
      "e": 50038,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 51124,
      "e": 50126,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 51180,
      "e": 50182,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 51373,
      "e": 50375,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 51872,
      "e": 50874,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 51904,
      "e": 50906,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 51937,
      "e": 50939,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 51971,
      "e": 50973,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 52004,
      "e": 51006,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 52036,
      "e": 51038,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 52070,
      "e": 51072,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 52102,
      "e": 51104,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 52132,
      "e": 51134,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Follow the time axis until you hit 12pm, then follow the diagonal line going forward u"
    },
    {
      "t": 52333,
      "e": 51335,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 52404,
      "e": 51406,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Follow the time axis until you hit 12pm, then follow the diagonal line going forward "
    },
    {
      "t": 52492,
      "e": 51494,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 52556,
      "e": 51558,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Follow the time axis until you hit 12pm, then follow the diagonal line going forward"
    },
    {
      "t": 52852,
      "e": 51854,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "190"
    },
    {
      "t": 52853,
      "e": 51855,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 52899,
      "e": 51901,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||."
    },
    {
      "t": 53006,
      "e": 52008,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Follow the time axis until you hit 12pm, then follow the diagonal line going forward."
    },
    {
      "t": 53156,
      "e": 52158,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 53157,
      "e": 52159,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 53259,
      "e": 52261,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 53396,
      "e": 52398,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "16"
    },
    {
      "t": 53525,
      "e": 52527,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "79"
    },
    {
      "t": 53525,
      "e": 52527,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 53635,
      "e": 52637,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||O"
    },
    {
      "t": 53668,
      "e": 52670,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 53748,
      "e": 52750,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "78"
    },
    {
      "t": 53752,
      "e": 52754,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 53891,
      "e": 52893,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||n"
    },
    {
      "t": 53916,
      "e": 52894,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 53917,
      "e": 52895,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 53931,
      "e": 52909,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 53932,
      "e": 52910,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 54020,
      "e": 52998,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| t"
    },
    {
      "t": 54028,
      "e": 53006,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "72"
    },
    {
      "t": 54029,
      "e": 53007,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 54051,
      "e": 53029,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||h"
    },
    {
      "t": 54115,
      "e": 53093,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 54139,
      "e": 53117,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 54139,
      "e": 53117,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 54292,
      "e": 53270,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||a"
    },
    {
      "t": 54308,
      "e": 53286,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 54309,
      "e": 53287,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 54403,
      "e": 53381,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 54435,
      "e": 53413,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 54435,
      "e": 53413,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 54572,
      "e": 53550,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "71"
    },
    {
      "t": 54573,
      "e": 53551,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 54595,
      "e": 53573,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| g"
    },
    {
      "t": 54700,
      "e": 53678,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 54708,
      "e": 53686,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "73"
    },
    {
      "t": 54708,
      "e": 53686,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 54787,
      "e": 53765,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||i"
    },
    {
      "t": 54787,
      "e": 53765,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 54787,
      "e": 53765,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 54859,
      "e": 53837,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "68"
    },
    {
      "t": 54859,
      "e": 53837,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 54899,
      "e": 53877,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||ad"
    },
    {
      "t": 54980,
      "e": 53958,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 55172,
      "e": 54150,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 55244,
      "e": 54222,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Follow the time axis until you hit 12pm, then follow the diagonal line going forward. On that gia"
    },
    {
      "t": 55316,
      "e": 54294,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 55364,
      "e": 54342,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Follow the time axis until you hit 12pm, then follow the diagonal line going forward. On that gi"
    },
    {
      "t": 55436,
      "e": 54414,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 55516,
      "e": 54494,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Follow the time axis until you hit 12pm, then follow the diagonal line going forward. On that g"
    },
    {
      "t": 55588,
      "e": 54566,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 55652,
      "e": 54630,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Follow the time axis until you hit 12pm, then follow the diagonal line going forward. On that "
    },
    {
      "t": 56004,
      "e": 54982,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "68"
    },
    {
      "t": 56005,
      "e": 54983,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 56093,
      "e": 55071,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "73"
    },
    {
      "t": 56093,
      "e": 55071,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 56131,
      "e": 55109,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||di"
    },
    {
      "t": 56180,
      "e": 55158,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 56188,
      "e": 55166,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 56188,
      "e": 55166,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 56292,
      "e": 55270,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "71"
    },
    {
      "t": 56292,
      "e": 55270,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 56315,
      "e": 55293,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||ag"
    },
    {
      "t": 56372,
      "e": 55350,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 56420,
      "e": 55398,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "79"
    },
    {
      "t": 56421,
      "e": 55399,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 56523,
      "e": 55501,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "78"
    },
    {
      "t": 56524,
      "e": 55502,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 56540,
      "e": 55518,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||on"
    },
    {
      "t": 56611,
      "e": 55589,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 56660,
      "e": 55638,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 56661,
      "e": 55639,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 56787,
      "e": 55765,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "76"
    },
    {
      "t": 56787,
      "e": 55765,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 56795,
      "e": 55773,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||al"
    },
    {
      "t": 56851,
      "e": 55829,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 56852,
      "e": 55830,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 56876,
      "e": 55854,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 57007,
      "e": 55985,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Follow the time axis until you hit 12pm, then follow the diagonal line going forward. On that diagonal "
    },
    {
      "t": 57036,
      "e": 56014,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 57044,
      "e": 56022,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "76"
    },
    {
      "t": 57045,
      "e": 56023,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 57207,
      "e": 56024,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Follow the time axis until you hit 12pm, then follow the diagonal line going forward. On that diagonal l"
    },
    {
      "t": 57212,
      "e": 56029,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||l"
    },
    {
      "t": 57348,
      "e": 56165,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "73"
    },
    {
      "t": 57349,
      "e": 56166,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 57468,
      "e": 56285,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||i"
    },
    {
      "t": 57548,
      "e": 56365,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "78"
    },
    {
      "t": 57548,
      "e": 56365,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 57645,
      "e": 56462,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 57645,
      "e": 56462,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 57675,
      "e": 56492,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||ne"
    },
    {
      "t": 57715,
      "e": 56532,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 57756,
      "e": 56573,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 57756,
      "e": 56573,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 57875,
      "e": 56692,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 57875,
      "e": 56692,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 57883,
      "e": 56700,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| a"
    },
    {
      "t": 57996,
      "e": 56813,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "82"
    },
    {
      "t": 57996,
      "e": 56813,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 58011,
      "e": 56828,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||r"
    },
    {
      "t": 58067,
      "e": 56884,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 58068,
      "e": 56885,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 58115,
      "e": 56932,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||e"
    },
    {
      "t": 58116,
      "e": 56933,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 58116,
      "e": 56933,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 58124,
      "e": 56941,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 58260,
      "e": 57077,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 58261,
      "e": 57078,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 58261,
      "e": 57078,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 58284,
      "e": 57101,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "72"
    },
    {
      "t": 58284,
      "e": 57101,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 58323,
      "e": 57140,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 58324,
      "e": 57141,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 58347,
      "e": 57164,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||the"
    },
    {
      "t": 58388,
      "e": 57205,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 58388,
      "e": 57205,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 58403,
      "e": 57220,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 58427,
      "e": 57244,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 58516,
      "e": 57333,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 58516,
      "e": 57333,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 58523,
      "e": 57340,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||e"
    },
    {
      "t": 58572,
      "e": 57389,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 58675,
      "e": 57492,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "86"
    },
    {
      "t": 58675,
      "e": 57492,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 58796,
      "e": 57613,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||v"
    },
    {
      "t": 58804,
      "e": 57621,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 58804,
      "e": 57621,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 58899,
      "e": 57716,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||e"
    },
    {
      "t": 58900,
      "e": 57717,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "78"
    },
    {
      "t": 58900,
      "e": 57717,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 59005,
      "e": 57822,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Follow the time axis until you hit 12pm, then follow the diagonal line going forward. On that diagonal line are the even"
    },
    {
      "t": 59011,
      "e": 57828,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 59012,
      "e": 57829,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 59043,
      "e": 57860,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||nt"
    },
    {
      "t": 59092,
      "e": 57909,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "83"
    },
    {
      "t": 59092,
      "e": 57909,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 59123,
      "e": 57940,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||s"
    },
    {
      "t": 59187,
      "e": 58004,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 59187,
      "e": 58004,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 59195,
      "e": 58012,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 59291,
      "e": 58108,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 59291,
      "e": 58108,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 59307,
      "e": 58124,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 59339,
      "e": 58156,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "72"
    },
    {
      "t": 59340,
      "e": 58157,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 59356,
      "e": 58173,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||h"
    },
    {
      "t": 59435,
      "e": 58252,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 59436,
      "e": 58253,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 59483,
      "e": 58300,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||a"
    },
    {
      "t": 59523,
      "e": 58340,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 59524,
      "e": 58341,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 59555,
      "e": 58372,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 59563,
      "e": 58380,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 59563,
      "e": 58380,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 59611,
      "e": 58428,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 59691,
      "e": 58508,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "87"
    },
    {
      "t": 59692,
      "e": 58509,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 59715,
      "e": 58532,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||w"
    },
    {
      "t": 59795,
      "e": 58612,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "73"
    },
    {
      "t": 59796,
      "e": 58613,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 59819,
      "e": 58636,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||i"
    },
    {
      "t": 59876,
      "e": 58693,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 59996,
      "e": 58813,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "76"
    },
    {
      "t": 59997,
      "e": 58814,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 60067,
      "e": 58884,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||l"
    },
    {
      "t": 60140,
      "e": 58957,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "76"
    },
    {
      "t": 60140,
      "e": 58957,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 60171,
      "e": 58988,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 60171,
      "e": 58988,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 60195,
      "e": 59012,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||l "
    },
    {
      "t": 60308,
      "e": 59125,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "79"
    },
    {
      "t": 60313,
      "e": 59130,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 60339,
      "e": 59156,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||o"
    },
    {
      "t": 60411,
      "e": 59228,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 60419,
      "e": 59236,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "67"
    },
    {
      "t": 60420,
      "e": 59237,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 60475,
      "e": 59292,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||c"
    },
    {
      "t": 60556,
      "e": 59373,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "67"
    },
    {
      "t": 60557,
      "e": 59374,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 60644,
      "e": 59461,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||c"
    },
    {
      "t": 60651,
      "e": 59468,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "85"
    },
    {
      "t": 60651,
      "e": 59468,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 60787,
      "e": 59604,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||u"
    },
    {
      "t": 60821,
      "e": 59605,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "82"
    },
    {
      "t": 60821,
      "e": 59605,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 60907,
      "e": 59691,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||r"
    },
    {
      "t": 60932,
      "e": 59716,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 60932,
      "e": 59716,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 61043,
      "e": 59827,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 61044,
      "e": 59828,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 61067,
      "e": 59851,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| a"
    },
    {
      "t": 61180,
      "e": 59964,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 61212,
      "e": 59996,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 61212,
      "e": 59996,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 61323,
      "e": 60107,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 61698,
      "e": 60482,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 61771,
      "e": 60555,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Follow the time axis until you hit 12pm, then follow the diagonal line going forward. On that diagonal line are the events that will occur a"
    },
    {
      "t": 61795,
      "e": 60579,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 62296,
      "e": 61080,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 62327,
      "e": 61111,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 62361,
      "e": 61145,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 62379,
      "e": 61163,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Follow the time axis until you hit 12pm, then follow the diagonal line going forward. On that diagonal line are the events that will occ"
    },
    {
      "t": 62476,
      "e": 61260,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 62548,
      "e": 61332,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Follow the time axis until you hit 12pm, then follow the diagonal line going forward. On that diagonal line are the events that will oc"
    },
    {
      "t": 62635,
      "e": 61419,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 62684,
      "e": 61468,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Follow the time axis until you hit 12pm, then follow the diagonal line going forward. On that diagonal line are the events that will o"
    },
    {
      "t": 62787,
      "e": 61571,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 62835,
      "e": 61619,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Follow the time axis until you hit 12pm, then follow the diagonal line going forward. On that diagonal line are the events that will "
    },
    {
      "t": 62859,
      "e": 61643,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "83"
    },
    {
      "t": 62860,
      "e": 61644,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 62955,
      "e": 61739,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||s"
    },
    {
      "t": 63060,
      "e": 61844,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 63060,
      "e": 61844,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 63131,
      "e": 61915,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "82"
    },
    {
      "t": 63132,
      "e": 61916,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 63179,
      "e": 61963,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||ar"
    },
    {
      "t": 63203,
      "e": 61987,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 63564,
      "e": 62348,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 63629,
      "e": 62349,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Follow the time axis until you hit 12pm, then follow the diagonal line going forward. On that diagonal line are the events that will sa"
    },
    {
      "t": 63996,
      "e": 62716,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 64076,
      "e": 62796,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Follow the time axis until you hit 12pm, then follow the diagonal line going forward. On that diagonal line are the events that will s"
    },
    {
      "t": 64155,
      "e": 62875,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 64155,
      "e": 62875,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 64171,
      "e": 62891,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 64292,
      "e": 63012,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 64292,
      "e": 63012,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 64380,
      "e": 63100,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "82"
    },
    {
      "t": 64381,
      "e": 63101,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 64427,
      "e": 63147,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||ar"
    },
    {
      "t": 64451,
      "e": 63171,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 64563,
      "e": 63283,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 64564,
      "e": 63284,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 64627,
      "e": 63347,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 64643,
      "e": 63363,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 64643,
      "e": 63363,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 64779,
      "e": 63499,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 64956,
      "e": 63676,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 64956,
      "e": 63676,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 65083,
      "e": 63803,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||a"
    },
    {
      "t": 65107,
      "e": 63827,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 65107,
      "e": 63827,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 65164,
      "e": 63884,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 65196,
      "e": 63916,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 65197,
      "e": 63917,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 65315,
      "e": 64035,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 65363,
      "e": 64083,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "49"
    },
    {
      "t": 65363,
      "e": 64083,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 65459,
      "e": 64179,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "50"
    },
    {
      "t": 65460,
      "e": 64180,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 65508,
      "e": 64228,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||12"
    },
    {
      "t": 65540,
      "e": 64260,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 65540,
      "e": 64260,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 65547,
      "e": 64267,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 65699,
      "e": 64419,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 65996,
      "e": 64716,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 66052,
      "e": 64772,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Follow the time axis until you hit 12pm, then follow the diagonal line going forward. On that diagonal line are the events that will start at 12"
    },
    {
      "t": 66244,
      "e": 64964,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "80"
    },
    {
      "t": 66244,
      "e": 64964,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 66339,
      "e": 65059,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||p"
    },
    {
      "t": 66468,
      "e": 65188,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "77"
    },
    {
      "t": 66468,
      "e": 65188,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 66547,
      "e": 65267,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||m"
    },
    {
      "t": 66644,
      "e": 65364,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "190"
    },
    {
      "t": 66644,
      "e": 65364,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 66732,
      "e": 65452,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||."
    },
    {
      "t": 67605,
      "e": 66325,
      "ty": 2,
      "x": 87,
      "y": 585
    },
    {
      "t": 67678,
      "e": 66398,
      "ty": 6,
      "x": 99,
      "y": 592,
      "ta": "#strategyAnswer"
    },
    {
      "t": 67704,
      "e": 66424,
      "ty": 2,
      "x": 103,
      "y": 595
    },
    {
      "t": 67727,
      "e": 66447,
      "ty": 7,
      "x": 121,
      "y": 608,
      "ta": "#strategyAnswer"
    },
    {
      "t": 67755,
      "e": 66475,
      "ty": 41,
      "x": 4148,
      "y": 62480,
      "ta": "> div.stimulus > div > div:[2]"
    },
    {
      "t": 67805,
      "e": 66525,
      "ty": 2,
      "x": 171,
      "y": 630
    },
    {
      "t": 67904,
      "e": 66624,
      "ty": 2,
      "x": 282,
      "y": 648
    },
    {
      "t": 68004,
      "e": 66724,
      "ty": 2,
      "x": 331,
      "y": 654
    },
    {
      "t": 68005,
      "e": 66725,
      "ty": 41,
      "x": 5807,
      "y": 21145,
      "ta": "> div.stimulus > div > div:[3]"
    },
    {
      "t": 68105,
      "e": 66825,
      "ty": 2,
      "x": 334,
      "y": 654
    },
    {
      "t": 68146,
      "e": 66866,
      "ty": 6,
      "x": 344,
      "y": 656,
      "ta": "#strategyButton"
    },
    {
      "t": 68204,
      "e": 66924,
      "ty": 2,
      "x": 350,
      "y": 657
    },
    {
      "t": 68254,
      "e": 66974,
      "ty": 41,
      "x": 13328,
      "y": 8221,
      "ta": "#strategyButton"
    },
    {
      "t": 68304,
      "e": 67024,
      "ty": 2,
      "x": 365,
      "y": 659
    },
    {
      "t": 68404,
      "e": 67124,
      "ty": 2,
      "x": 366,
      "y": 659
    },
    {
      "t": 68441,
      "e": 67161,
      "ty": 3,
      "x": 366,
      "y": 659,
      "ta": "#strategyButton"
    },
    {
      "t": 68444,
      "e": 67162,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Follow the time axis until you hit 12pm, then follow the diagonal line going forward. On that diagonal line are the events that will start at 12pm."
    },
    {
      "t": 68444,
      "e": 67162,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 68444,
      "e": 67162,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#strategyButton"
    },
    {
      "t": 68505,
      "e": 67223,
      "ty": 41,
      "x": 14967,
      "y": 8221,
      "ta": "#strategyButton"
    },
    {
      "t": 68519,
      "e": 67237,
      "ty": 4,
      "x": 14967,
      "y": 8221,
      "ta": "#strategyButton"
    },
    {
      "t": 68530,
      "e": 67248,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#strategyButton"
    },
    {
      "t": 68531,
      "e": 67249,
      "ty": 5,
      "x": 366,
      "y": 659,
      "ta": "#strategyButton"
    },
    {
      "t": 68536,
      "e": 67254,
      "ty": 38,
      "x": 1,
      "y": 0
    },
    {
      "t": 68904,
      "e": 67622,
      "ty": 2,
      "x": 373,
      "y": 664
    },
    {
      "t": 69005,
      "e": 67723,
      "ty": 41,
      "x": 12569,
      "y": 36340,
      "ta": "html > body"
    },
    {
      "t": 69539,
      "e": 68257,
      "ty": 38,
      "x": 2,
      "y": 0
    },
    {
      "t": 70105,
      "e": 68823,
      "ty": 2,
      "x": 424,
      "y": 654
    },
    {
      "t": 70205,
      "e": 68923,
      "ty": 2,
      "x": 589,
      "y": 625
    },
    {
      "t": 70254,
      "e": 68972,
      "ty": 41,
      "x": 22143,
      "y": 33626,
      "ta": "html > body"
    },
    {
      "t": 70305,
      "e": 69023,
      "ty": 2,
      "x": 727,
      "y": 599
    },
    {
      "t": 70379,
      "e": 69097,
      "ty": 6,
      "x": 823,
      "y": 573,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 70405,
      "e": 69123,
      "ty": 2,
      "x": 847,
      "y": 571
    },
    {
      "t": 70504,
      "e": 69222,
      "ty": 2,
      "x": 880,
      "y": 567
    },
    {
      "t": 70505,
      "e": 69223,
      "ty": 41,
      "x": 15572,
      "y": 40569,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 70605,
      "e": 69323,
      "ty": 2,
      "x": 882,
      "y": 566
    },
    {
      "t": 70648,
      "e": 69366,
      "ty": 3,
      "x": 882,
      "y": 566,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 70649,
      "e": 69367,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 70736,
      "e": 69454,
      "ty": 4,
      "x": 16005,
      "y": 37448,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 70736,
      "e": 69454,
      "ty": 5,
      "x": 882,
      "y": 566,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 70755,
      "e": 69473,
      "ty": 41,
      "x": 16005,
      "y": 37448,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 71624,
      "e": 70342,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "49"
    },
    {
      "t": 71624,
      "e": 70342,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 71712,
      "e": 70430,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "1"
    },
    {
      "t": 71792,
      "e": 70510,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "57"
    },
    {
      "t": 71792,
      "e": 70510,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 71864,
      "e": 70582,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "19"
    },
    {
      "t": 72072,
      "e": 70790,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "9"
    },
    {
      "t": 72073,
      "e": 70791,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "19"
    },
    {
      "t": 72073,
      "e": 70791,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 72074,
      "e": 70792,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 72167,
      "e": 70885,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": ""
    },
    {
      "t": 73489,
      "e": 72207,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "16"
    },
    {
      "t": 73576,
      "e": 72294,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "85"
    },
    {
      "t": 73577,
      "e": 72295,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 73704,
      "e": 72422,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "U"
    },
    {
      "t": 73720,
      "e": 72438,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "U"
    },
    {
      "t": 74136,
      "e": 72854,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "78"
    },
    {
      "t": 74137,
      "e": 72855,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 74303,
      "e": 73021,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "73"
    },
    {
      "t": 74304,
      "e": 73022,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 74343,
      "e": 73061,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "Uni"
    },
    {
      "t": 74448,
      "e": 73166,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "Uni"
    },
    {
      "t": 74527,
      "e": 73245,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "84"
    },
    {
      "t": 74529,
      "e": 73247,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 74631,
      "e": 73349,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "69"
    },
    {
      "t": 74631,
      "e": 73349,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 74663,
      "e": 73381,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "Unite"
    },
    {
      "t": 74728,
      "e": 73446,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "+||"
    },
    {
      "t": 74816,
      "e": 73534,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "68"
    },
    {
      "t": 74816,
      "e": 73534,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 74904,
      "e": 73622,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "+||d"
    },
    {
      "t": 74911,
      "e": 73629,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "32"
    },
    {
      "t": 74911,
      "e": 73629,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 74999,
      "e": 73717,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "16"
    },
    {
      "t": 75048,
      "e": 73766,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "+|| "
    },
    {
      "t": 75064,
      "e": 73782,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "83"
    },
    {
      "t": 75064,
      "e": 73782,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 75152,
      "e": 73870,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "+||S"
    },
    {
      "t": 75208,
      "e": 73926,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "+||"
    },
    {
      "t": 75408,
      "e": 74126,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "84"
    },
    {
      "t": 75409,
      "e": 74127,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 75511,
      "e": 74229,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "+||t"
    },
    {
      "t": 75551,
      "e": 74269,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "65"
    },
    {
      "t": 75552,
      "e": 74270,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 75656,
      "e": 74374,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "+||a"
    },
    {
      "t": 75952,
      "e": 74670,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "84"
    },
    {
      "t": 75953,
      "e": 74671,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 76079,
      "e": 74797,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "+||t"
    },
    {
      "t": 76087,
      "e": 74805,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "69"
    },
    {
      "t": 76088,
      "e": 74806,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 76168,
      "e": 74886,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "83"
    },
    {
      "t": 76168,
      "e": 74886,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 76240,
      "e": 74958,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "+||es"
    },
    {
      "t": 76280,
      "e": 74998,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "+||"
    },
    {
      "t": 76597,
      "e": 75315,
      "ty": 7,
      "x": 853,
      "y": 533,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 76609,
      "e": 75327,
      "ty": 2,
      "x": 798,
      "y": 476
    },
    {
      "t": 76710,
      "e": 75428,
      "ty": 2,
      "x": 705,
      "y": 409
    },
    {
      "t": 76759,
      "e": 75477,
      "ty": 41,
      "x": 25862,
      "y": 26092,
      "ta": "html > body"
    },
    {
      "t": 76806,
      "e": 75524,
      "ty": 6,
      "x": 814,
      "y": 556,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 76809,
      "e": 75527,
      "ty": 2,
      "x": 814,
      "y": 556
    },
    {
      "t": 76823,
      "e": 75541,
      "ty": 7,
      "x": 841,
      "y": 582,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 76856,
      "e": 75574,
      "ty": 6,
      "x": 890,
      "y": 649,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 76873,
      "e": 75591,
      "ty": 7,
      "x": 908,
      "y": 673,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 76890,
      "e": 75608,
      "ty": 6,
      "x": 917,
      "y": 684,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 76909,
      "e": 75627,
      "ty": 2,
      "x": 922,
      "y": 691
    },
    {
      "t": 76990,
      "e": 75708,
      "ty": 7,
      "x": 942,
      "y": 710,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 77010,
      "e": 75728,
      "ty": 2,
      "x": 953,
      "y": 720
    },
    {
      "t": 77010,
      "e": 75728,
      "ty": 41,
      "x": 32543,
      "y": 39442,
      "ta": "html > body"
    },
    {
      "t": 77109,
      "e": 75827,
      "ty": 2,
      "x": 1008,
      "y": 755
    },
    {
      "t": 77210,
      "e": 75928,
      "ty": 2,
      "x": 1002,
      "y": 723
    },
    {
      "t": 77259,
      "e": 75977,
      "ty": 41,
      "x": 34058,
      "y": 38999,
      "ta": "html > body"
    },
    {
      "t": 77307,
      "e": 76025,
      "ty": 6,
      "x": 994,
      "y": 708,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 77309,
      "e": 76027,
      "ty": 2,
      "x": 994,
      "y": 708
    },
    {
      "t": 77410,
      "e": 76128,
      "ty": 2,
      "x": 993,
      "y": 706
    },
    {
      "t": 77509,
      "e": 76227,
      "ty": 41,
      "x": 50033,
      "y": 59577,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 77716,
      "e": 76434,
      "ty": 3,
      "x": 993,
      "y": 706,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 77718,
      "e": 76436,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "United States"
    },
    {
      "t": 77718,
      "e": 76436,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 77719,
      "e": 76437,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 77787,
      "e": 76505,
      "ty": 4,
      "x": 50033,
      "y": 59577,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 77788,
      "e": 76506,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 77788,
      "e": 76506,
      "ty": 5,
      "x": 993,
      "y": 706,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 77789,
      "e": 76507,
      "ty": 38,
      "x": 3,
      "y": 0
    },
    {
      "t": 78804,
      "e": 77522,
      "ty": 38,
      "x": 4,
      "y": 0
    },
    {
      "t": 79509,
      "e": 78227,
      "ty": 2,
      "x": 973,
      "y": 620
    },
    {
      "t": 79509,
      "e": 78227,
      "ty": 41,
      "x": 35973,
      "y": 11702,
      "ta": "#jspsych-survey-multi-choice-2 > p"
    },
    {
      "t": 79609,
      "e": 78327,
      "ty": 2,
      "x": 914,
      "y": 421
    },
    {
      "t": 79709,
      "e": 78427,
      "ty": 2,
      "x": 906,
      "y": 370
    },
    {
      "t": 79759,
      "e": 78477,
      "ty": 41,
      "x": 20072,
      "y": 35108,
      "ta": "#jspsych-survey-multi-choice-1 > p"
    },
    {
      "t": 79808,
      "e": 78526,
      "ty": 2,
      "x": 904,
      "y": 360
    },
    {
      "t": 79909,
      "e": 78627,
      "ty": 2,
      "x": 865,
      "y": 256
    },
    {
      "t": 80008,
      "e": 78726,
      "ty": 2,
      "x": 855,
      "y": 237
    },
    {
      "t": 80008,
      "e": 78726,
      "ty": 41,
      "x": 27496,
      "y": 26214,
      "ta": "#jspsych-survey-multi-choice-option-0-0 > label"
    },
    {
      "t": 80108,
      "e": 78826,
      "ty": 2,
      "x": 850,
      "y": 232
    },
    {
      "t": 80209,
      "e": 78927,
      "ty": 2,
      "x": 842,
      "y": 231
    },
    {
      "t": 80258,
      "e": 78976,
      "ty": 41,
      "x": 11118,
      "y": 6553,
      "ta": "#jspsych-survey-multi-choice-option-0-0 > label"
    },
    {
      "t": 80308,
      "e": 79026,
      "ty": 2,
      "x": 829,
      "y": 230
    },
    {
      "t": 80409,
      "e": 79127,
      "ty": 2,
      "x": 825,
      "y": 229
    },
    {
      "t": 80509,
      "e": 79227,
      "ty": 2,
      "x": 824,
      "y": 228
    },
    {
      "t": 80510,
      "e": 79228,
      "ty": 41,
      "x": 611,
      "y": 7021,
      "ta": "#jspsych-survey-multi-choice-option-0-0"
    },
    {
      "t": 80636,
      "e": 79354,
      "ty": 3,
      "x": 824,
      "y": 228,
      "ta": "#jspsych-survey-multi-choice-option-0-0"
    },
    {
      "t": 80740,
      "e": 79458,
      "ty": 4,
      "x": 611,
      "y": 7021,
      "ta": "#jspsych-survey-multi-choice-option-0-0"
    },
    {
      "t": 80740,
      "e": 79458,
      "ty": 5,
      "x": 824,
      "y": 228,
      "ta": "#jspsych-survey-multi-choice-option-0-0"
    },
    {
      "t": 81109,
      "e": 79827,
      "ty": 2,
      "x": 824,
      "y": 233
    },
    {
      "t": 81208,
      "e": 79926,
      "ty": 2,
      "x": 824,
      "y": 236
    },
    {
      "t": 81213,
      "e": 79931,
      "ty": 3,
      "x": 824,
      "y": 236,
      "ta": "#jspsych-survey-multi-choice-option-0-0 > label"
    },
    {
      "t": 81258,
      "e": 79976,
      "ty": 41,
      "x": 2111,
      "y": 26214,
      "ta": "#jspsych-survey-multi-choice-option-0-0 > label"
    },
    {
      "t": 81307,
      "e": 80025,
      "ty": 4,
      "x": 2111,
      "y": 26214,
      "ta": "#jspsych-survey-multi-choice-option-0-0 > label"
    },
    {
      "t": 81307,
      "e": 80025,
      "ty": 5,
      "x": 824,
      "y": 237,
      "ta": "#jspsych-survey-multi-choice-option-0-0 > label"
    },
    {
      "t": 81308,
      "e": 80026,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-0[0]_mf"
    },
    {
      "t": 81309,
      "e": 80027,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-0[0]_mf",
      "v": "English"
    },
    {
      "t": 81309,
      "e": 80027,
      "ty": 2,
      "x": 824,
      "y": 237
    },
    {
      "t": 81878,
      "e": 80596,
      "ty": 6,
      "x": 826,
      "y": 294,
      "ta": "jspsych-survey-multi-choice-response-0[2]_mf"
    },
    {
      "t": 81893,
      "e": 80611,
      "ty": 7,
      "x": 833,
      "y": 316,
      "ta": "jspsych-survey-multi-choice-response-0[2]_mf"
    },
    {
      "t": 81893,
      "e": 80611,
      "ty": 6,
      "x": 833,
      "y": 316,
      "ta": "jspsych-survey-multi-choice-response-0[3]_mf"
    },
    {
      "t": 81908,
      "e": 80626,
      "ty": 2,
      "x": 833,
      "y": 316
    },
    {
      "t": 81926,
      "e": 80644,
      "ty": 7,
      "x": 841,
      "y": 336,
      "ta": "jspsych-survey-multi-choice-response-0[3]_mf"
    },
    {
      "t": 82008,
      "e": 80726,
      "ty": 2,
      "x": 841,
      "y": 351
    },
    {
      "t": 82008,
      "e": 80726,
      "ty": 41,
      "x": 4646,
      "y": 14198,
      "ta": "#jspsych-survey-multi-choice-form"
    },
    {
      "t": 82108,
      "e": 80826,
      "ty": 2,
      "x": 841,
      "y": 367
    },
    {
      "t": 82208,
      "e": 80926,
      "ty": 2,
      "x": 837,
      "y": 380
    },
    {
      "t": 82258,
      "e": 80976,
      "ty": 41,
      "x": 3697,
      "y": 63194,
      "ta": "#jspsych-survey-multi-choice-1 > p"
    },
    {
      "t": 82308,
      "e": 81026,
      "ty": 2,
      "x": 836,
      "y": 388
    },
    {
      "t": 82408,
      "e": 81126,
      "ty": 2,
      "x": 833,
      "y": 396
    },
    {
      "t": 82508,
      "e": 81226,
      "ty": 2,
      "x": 831,
      "y": 399
    },
    {
      "t": 82509,
      "e": 81227,
      "ty": 41,
      "x": 2273,
      "y": 11915,
      "ta": "#jspsych-survey-multi-choice-1"
    },
    {
      "t": 82608,
      "e": 81326,
      "ty": 2,
      "x": 831,
      "y": 405
    },
    {
      "t": 82758,
      "e": 81476,
      "ty": 41,
      "x": 11212,
      "y": 3276,
      "ta": "#jspsych-survey-multi-choice-option-1-0 > label"
    },
    {
      "t": 82809,
      "e": 81527,
      "ty": 2,
      "x": 831,
      "y": 406
    },
    {
      "t": 83653,
      "e": 82371,
      "ty": 6,
      "x": 830,
      "y": 408,
      "ta": "jspsych-survey-multi-choice-response-1[0]_mf"
    },
    {
      "t": 83709,
      "e": 82427,
      "ty": 2,
      "x": 830,
      "y": 409
    },
    {
      "t": 83759,
      "e": 82477,
      "ty": 41,
      "x": 18037,
      "y": 5041,
      "ta": "jspsych-survey-multi-choice-response-1[0]_mf"
    },
    {
      "t": 83956,
      "e": 82674,
      "ty": 3,
      "x": 830,
      "y": 409,
      "ta": "jspsych-survey-multi-choice-response-1[0]_mf"
    },
    {
      "t": 83958,
      "e": 82676,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-0[0]_mf"
    },
    {
      "t": 83960,
      "e": 82678,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-1[0]_mf"
    },
    {
      "t": 84075,
      "e": 82793,
      "ty": 4,
      "x": 18037,
      "y": 5041,
      "ta": "jspsych-survey-multi-choice-response-1[0]_mf"
    },
    {
      "t": 84075,
      "e": 82793,
      "ty": 5,
      "x": 830,
      "y": 409,
      "ta": "jspsych-survey-multi-choice-response-1[0]_mf"
    },
    {
      "t": 84075,
      "e": 82793,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-1[0]_mf",
      "v": "First"
    },
    {
      "t": 84509,
      "e": 83227,
      "ty": 2,
      "x": 830,
      "y": 411
    },
    {
      "t": 84509,
      "e": 83227,
      "ty": 41,
      "x": 18037,
      "y": 15123,
      "ta": "jspsych-survey-multi-choice-response-1[0]_mf"
    },
    {
      "t": 84609,
      "e": 83327,
      "ty": 2,
      "x": 831,
      "y": 420
    },
    {
      "t": 84628,
      "e": 83346,
      "ty": 3,
      "x": 831,
      "y": 420,
      "ta": "jspsych-survey-multi-choice-response-1[0]_mf"
    },
    {
      "t": 84709,
      "e": 83427,
      "ty": 2,
      "x": 832,
      "y": 420
    },
    {
      "t": 84724,
      "e": 83442,
      "ty": 4,
      "x": 28120,
      "y": 60493,
      "ta": "jspsych-survey-multi-choice-response-1[0]_mf"
    },
    {
      "t": 84725,
      "e": 83443,
      "ty": 5,
      "x": 832,
      "y": 420,
      "ta": "jspsych-survey-multi-choice-response-1[0]_mf"
    },
    {
      "t": 84758,
      "e": 83476,
      "ty": 41,
      "x": 28120,
      "y": 60493,
      "ta": "jspsych-survey-multi-choice-response-1[0]_mf"
    },
    {
      "t": 85308,
      "e": 84026,
      "ty": 7,
      "x": 833,
      "y": 426,
      "ta": "jspsych-survey-multi-choice-response-1[0]_mf"
    },
    {
      "t": 85310,
      "e": 84028,
      "ty": 2,
      "x": 833,
      "y": 426
    },
    {
      "t": 85331,
      "e": 84049,
      "ty": 6,
      "x": 833,
      "y": 446,
      "ta": "jspsych-survey-multi-choice-response-1[1]_mf"
    },
    {
      "t": 85345,
      "e": 84063,
      "ty": 7,
      "x": 835,
      "y": 459,
      "ta": "jspsych-survey-multi-choice-response-1[1]_mf"
    },
    {
      "t": 85363,
      "e": 84081,
      "ty": 6,
      "x": 835,
      "y": 464,
      "ta": "jspsych-survey-multi-choice-response-1[2]_mf"
    },
    {
      "t": 85396,
      "e": 84114,
      "ty": 7,
      "x": 837,
      "y": 484,
      "ta": "jspsych-survey-multi-choice-response-1[2]_mf"
    },
    {
      "t": 85409,
      "e": 84127,
      "ty": 2,
      "x": 837,
      "y": 484
    },
    {
      "t": 85508,
      "e": 84226,
      "ty": 2,
      "x": 844,
      "y": 566
    },
    {
      "t": 85508,
      "e": 84226,
      "ty": 41,
      "x": 5358,
      "y": 58513,
      "ta": "#jspsych-survey-multi-choice-option-1-5"
    },
    {
      "t": 85608,
      "e": 84326,
      "ty": 2,
      "x": 845,
      "y": 628
    },
    {
      "t": 85709,
      "e": 84427,
      "ty": 2,
      "x": 845,
      "y": 647
    },
    {
      "t": 85759,
      "e": 84477,
      "ty": 41,
      "x": 5595,
      "y": 10832,
      "ta": "#jspsych-survey-multi-choice-2"
    },
    {
      "t": 85809,
      "e": 84527,
      "ty": 2,
      "x": 845,
      "y": 660
    },
    {
      "t": 85909,
      "e": 84627,
      "ty": 2,
      "x": 844,
      "y": 662
    },
    {
      "t": 86009,
      "e": 84727,
      "ty": 2,
      "x": 844,
      "y": 663
    },
    {
      "t": 86009,
      "e": 84727,
      "ty": 41,
      "x": 5358,
      "y": 4681,
      "ta": "#jspsych-survey-multi-choice-option-2-0"
    },
    {
      "t": 86109,
      "e": 84827,
      "ty": 2,
      "x": 844,
      "y": 667
    },
    {
      "t": 86259,
      "e": 84977,
      "ty": 41,
      "x": 6062,
      "y": 9830,
      "ta": "#jspsych-survey-multi-choice-option-2-0 > label"
    },
    {
      "t": 86308,
      "e": 85026,
      "ty": 2,
      "x": 844,
      "y": 677
    },
    {
      "t": 86509,
      "e": 85227,
      "ty": 41,
      "x": 6062,
      "y": 39321,
      "ta": "#jspsych-survey-multi-choice-option-2-0 > label"
    },
    {
      "t": 87309,
      "e": 86027,
      "ty": 2,
      "x": 843,
      "y": 679
    },
    {
      "t": 87409,
      "e": 86127,
      "ty": 2,
      "x": 838,
      "y": 693
    },
    {
      "t": 87468,
      "e": 86186,
      "ty": 6,
      "x": 838,
      "y": 696,
      "ta": "jspsych-survey-multi-choice-response-2[1]_mf"
    },
    {
      "t": 87509,
      "e": 86227,
      "ty": 2,
      "x": 837,
      "y": 698
    },
    {
      "t": 87509,
      "e": 86227,
      "ty": 41,
      "x": 53325,
      "y": 10082,
      "ta": "jspsych-survey-multi-choice-response-2[1]_mf"
    },
    {
      "t": 87608,
      "e": 86326,
      "ty": 2,
      "x": 837,
      "y": 700
    },
    {
      "t": 87759,
      "e": 86477,
      "ty": 41,
      "x": 53325,
      "y": 20164,
      "ta": "jspsych-survey-multi-choice-response-2[1]_mf"
    },
    {
      "t": 87990,
      "e": 86708,
      "ty": 3,
      "x": 837,
      "y": 700,
      "ta": "jspsych-survey-multi-choice-response-2[1]_mf"
    },
    {
      "t": 87990,
      "e": 86708,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-1[0]_mf"
    },
    {
      "t": 87991,
      "e": 86709,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-2[1]_mf"
    },
    {
      "t": 88083,
      "e": 86801,
      "ty": 4,
      "x": 53325,
      "y": 20164,
      "ta": "jspsych-survey-multi-choice-response-2[1]_mf"
    },
    {
      "t": 88083,
      "e": 86801,
      "ty": 5,
      "x": 837,
      "y": 700,
      "ta": "jspsych-survey-multi-choice-response-2[1]_mf"
    },
    {
      "t": 88083,
      "e": 86801,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-2[1]_mf",
      "v": "Social Sciences (incl. CogSci)"
    },
    {
      "t": 89258,
      "e": 87976,
      "ty": 41,
      "x": 53325,
      "y": 30246,
      "ta": "jspsych-survey-multi-choice-response-2[1]_mf"
    },
    {
      "t": 89283,
      "e": 88001,
      "ty": 7,
      "x": 842,
      "y": 705,
      "ta": "jspsych-survey-multi-choice-response-2[1]_mf"
    },
    {
      "t": 89309,
      "e": 88027,
      "ty": 2,
      "x": 844,
      "y": 706
    },
    {
      "t": 89409,
      "e": 88127,
      "ty": 2,
      "x": 845,
      "y": 707
    },
    {
      "t": 89509,
      "e": 88227,
      "ty": 41,
      "x": 5941,
      "y": 45874,
      "ta": "#jspsych-survey-multi-choice-option-2-1 > label"
    },
    {
      "t": 89759,
      "e": 88477,
      "ty": 41,
      "x": 6445,
      "y": 55704,
      "ta": "#jspsych-survey-multi-choice-option-2-1 > label"
    },
    {
      "t": 89809,
      "e": 88527,
      "ty": 2,
      "x": 848,
      "y": 712
    },
    {
      "t": 89908,
      "e": 88626,
      "ty": 2,
      "x": 849,
      "y": 713
    },
    {
      "t": 90009,
      "e": 88727,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 90011,
      "e": 88729,
      "ty": 41,
      "x": 6544,
      "y": 56172,
      "ta": "#jspsych-survey-multi-choice-option-2-1"
    },
    {
      "t": 90409,
      "e": 89127,
      "ty": 2,
      "x": 850,
      "y": 719
    },
    {
      "t": 90509,
      "e": 89227,
      "ty": 2,
      "x": 851,
      "y": 724
    },
    {
      "t": 90509,
      "e": 89227,
      "ty": 41,
      "x": 7423,
      "y": 9830,
      "ta": "#jspsych-survey-multi-choice-option-2-2 > label"
    },
    {
      "t": 90609,
      "e": 89327,
      "ty": 2,
      "x": 852,
      "y": 731
    },
    {
      "t": 90708,
      "e": 89426,
      "ty": 2,
      "x": 853,
      "y": 737
    },
    {
      "t": 90759,
      "e": 89477,
      "ty": 41,
      "x": 8443,
      "y": 4681,
      "ta": "#jspsych-survey-multi-choice-option-2-3"
    },
    {
      "t": 90809,
      "e": 89527,
      "ty": 2,
      "x": 860,
      "y": 758
    },
    {
      "t": 90908,
      "e": 89626,
      "ty": 2,
      "x": 877,
      "y": 816
    },
    {
      "t": 91008,
      "e": 89726,
      "ty": 2,
      "x": 898,
      "y": 865
    },
    {
      "t": 91008,
      "e": 89726,
      "ty": 41,
      "x": 18173,
      "y": 52607,
      "ta": "#jspsych-survey-multi-choice-form"
    },
    {
      "t": 91109,
      "e": 89827,
      "ty": 2,
      "x": 899,
      "y": 895
    },
    {
      "t": 91209,
      "e": 89927,
      "ty": 2,
      "x": 884,
      "y": 933
    },
    {
      "t": 91259,
      "e": 89977,
      "ty": 41,
      "x": 56336,
      "y": 52428,
      "ta": "#jspsych-survey-multi-choice-option-3-0 > label"
    },
    {
      "t": 91309,
      "e": 90027,
      "ty": 2,
      "x": 860,
      "y": 946
    },
    {
      "t": 91408,
      "e": 90126,
      "ty": 2,
      "x": 842,
      "y": 955
    },
    {
      "t": 91509,
      "e": 90227,
      "ty": 2,
      "x": 842,
      "y": 957
    },
    {
      "t": 91509,
      "e": 90227,
      "ty": 41,
      "x": 16646,
      "y": 13107,
      "ta": "#jspsych-survey-multi-choice-option-3-1 > label"
    },
    {
      "t": 91608,
      "e": 90326,
      "ty": 2,
      "x": 842,
      "y": 960
    },
    {
      "t": 91748,
      "e": 90466,
      "ty": 6,
      "x": 839,
      "y": 960,
      "ta": "jspsych-survey-multi-choice-response-3[1]_mf"
    },
    {
      "t": 91759,
      "e": 90477,
      "ty": 41,
      "x": 63408,
      "y": 20164,
      "ta": "jspsych-survey-multi-choice-response-3[1]_mf"
    },
    {
      "t": 91808,
      "e": 90526,
      "ty": 2,
      "x": 837,
      "y": 960
    },
    {
      "t": 91909,
      "e": 90627,
      "ty": 2,
      "x": 829,
      "y": 957
    },
    {
      "t": 91933,
      "e": 90651,
      "ty": 3,
      "x": 829,
      "y": 957,
      "ta": "jspsych-survey-multi-choice-response-3[1]_mf"
    },
    {
      "t": 91934,
      "e": 90652,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-2[1]_mf"
    },
    {
      "t": 91935,
      "e": 90653,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-3[1]_mf"
    },
    {
      "t": 92010,
      "e": 90728,
      "ty": 41,
      "x": 12996,
      "y": 5041,
      "ta": "jspsych-survey-multi-choice-response-3[1]_mf"
    },
    {
      "t": 92028,
      "e": 90746,
      "ty": 4,
      "x": 12996,
      "y": 5041,
      "ta": "jspsych-survey-multi-choice-response-3[1]_mf"
    },
    {
      "t": 92028,
      "e": 90746,
      "ty": 5,
      "x": 829,
      "y": 957,
      "ta": "jspsych-survey-multi-choice-response-3[1]_mf"
    },
    {
      "t": 92029,
      "e": 90747,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-3[1]_mf",
      "v": "Female"
    },
    {
      "t": 92309,
      "e": 91027,
      "ty": 2,
      "x": 829,
      "y": 958
    },
    {
      "t": 92413,
      "e": 91131,
      "ty": 3,
      "x": 829,
      "y": 958,
      "ta": "jspsych-survey-multi-choice-response-3[1]_mf"
    },
    {
      "t": 92490,
      "e": 91208,
      "ty": 4,
      "x": 23079,
      "y": 10082,
      "ta": "jspsych-survey-multi-choice-response-3[1]_mf"
    },
    {
      "t": 92491,
      "e": 91209,
      "ty": 5,
      "x": 831,
      "y": 958,
      "ta": "jspsych-survey-multi-choice-response-3[1]_mf"
    },
    {
      "t": 92509,
      "e": 91227,
      "ty": 2,
      "x": 831,
      "y": 958
    },
    {
      "t": 92509,
      "e": 91227,
      "ty": 41,
      "x": 23079,
      "y": 10082,
      "ta": "jspsych-survey-multi-choice-response-3[1]_mf"
    },
    {
      "t": 92759,
      "e": 91477,
      "ty": 41,
      "x": 28120,
      "y": 25205,
      "ta": "jspsych-survey-multi-choice-response-3[1]_mf"
    },
    {
      "t": 92809,
      "e": 91527,
      "ty": 2,
      "x": 834,
      "y": 963
    },
    {
      "t": 92909,
      "e": 91627,
      "ty": 2,
      "x": 834,
      "y": 964
    },
    {
      "t": 93003,
      "e": 91721,
      "ty": 7,
      "x": 837,
      "y": 969,
      "ta": "jspsych-survey-multi-choice-response-3[1]_mf"
    },
    {
      "t": 93009,
      "e": 91727,
      "ty": 2,
      "x": 837,
      "y": 969
    },
    {
      "t": 93009,
      "e": 91727,
      "ty": 41,
      "x": 12601,
      "y": 52428,
      "ta": "#jspsych-survey-multi-choice-option-3-1 > label"
    },
    {
      "t": 93108,
      "e": 91826,
      "ty": 2,
      "x": 856,
      "y": 989
    },
    {
      "t": 93203,
      "e": 91921,
      "ty": 6,
      "x": 878,
      "y": 1010,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 93209,
      "e": 91927,
      "ty": 2,
      "x": 878,
      "y": 1010
    },
    {
      "t": 93259,
      "e": 91977,
      "ty": 41,
      "x": 28644,
      "y": 19859,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 93309,
      "e": 92027,
      "ty": 2,
      "x": 885,
      "y": 1015
    },
    {
      "t": 93409,
      "e": 92127,
      "ty": 2,
      "x": 886,
      "y": 1016
    },
    {
      "t": 93509,
      "e": 92227,
      "ty": 41,
      "x": 29159,
      "y": 21845,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 95131,
      "e": 93849,
      "ty": 3,
      "x": 886,
      "y": 1016,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 95132,
      "e": 93850,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-3[1]_mf"
    },
    {
      "t": 95132,
      "e": 93850,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 95243,
      "e": 93961,
      "ty": 4,
      "x": 29159,
      "y": 21845,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 95244,
      "e": 93962,
      "ty": 5,
      "x": 886,
      "y": 1016,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 95245,
      "e": 93963,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 95247,
      "e": 93965,
      "ty": 13,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-multi-choice-form"
    },
    {
      "t": 95247,
      "e": 93965,
      "ty": 38,
      "x": 5,
      "y": 0
    },
    {
      "t": 96608,
      "e": 95326,
      "ty": 38,
      "x": 6,
      "y": 0
    },
    {
      "t": 97909,
      "e": 96627,
      "ty": 2,
      "x": 895,
      "y": 1008
    },
    {
      "t": 98009,
      "e": 96727,
      "ty": 2,
      "x": 939,
      "y": 967
    },
    {
      "t": 98009,
      "e": 96727,
      "ty": 41,
      "x": 31758,
      "y": 58216,
      "ta": "> div.masterdiv > div:[2]"
    },
    {
      "t": 98109,
      "e": 96827,
      "ty": 2,
      "x": 948,
      "y": 947
    },
    {
      "t": 98209,
      "e": 96927,
      "ty": 2,
      "x": 952,
      "y": 927
    },
    {
      "t": 98260,
      "e": 96978,
      "ty": 41,
      "x": 32398,
      "y": 55377,
      "ta": "> div.masterdiv > div:[2]"
    },
    {
      "t": 98309,
      "e": 97027,
      "ty": 2,
      "x": 952,
      "y": 926
    },
    {
      "t": 98364,
      "e": 97082,
      "ty": 3,
      "x": 952,
      "y": 926,
      "ta": "> div.masterdiv > div:[2]"
    },
    {
      "t": 98524,
      "e": 97242,
      "ty": 4,
      "x": 32398,
      "y": 55377,
      "ta": "> div.masterdiv > div:[2]"
    },
    {
      "t": 98525,
      "e": 97243,
      "ty": 5,
      "x": 952,
      "y": 926,
      "ta": "> div.masterdiv > div:[2]"
    },
    {
      "t": 99009,
      "e": 97727,
      "ty": 2,
      "x": 938,
      "y": 920
    },
    {
      "t": 99009,
      "e": 97727,
      "ty": 41,
      "x": 31709,
      "y": 54961,
      "ta": "> div.masterdiv > div:[2]"
    },
    {
      "t": 100009,
      "e": 98727,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 109541,
      "e": 102727,
      "ty": 3,
      "x": 938,
      "y": 920,
      "ta": "> div.masterdiv > div:[2]"
    },
    {
      "t": 109667,
      "e": 102853,
      "ty": 4,
      "x": 31709,
      "y": 54961,
      "ta": "> div.masterdiv > div:[2]"
    },
    {
      "t": 109668,
      "e": 102854,
      "ty": 5,
      "x": 938,
      "y": 920,
      "ta": "> div.masterdiv > div:[2]"
    },
    {
      "t": 110066,
      "e": 103252,
      "ty": 3,
      "x": 938,
      "y": 920,
      "ta": "> div.masterdiv > div:[2]"
    },
    {
      "t": 110194,
      "e": 103380,
      "ty": 4,
      "x": 31709,
      "y": 54961,
      "ta": "> div.masterdiv > div:[2]"
    },
    {
      "t": 110194,
      "e": 103380,
      "ty": 5,
      "x": 938,
      "y": 920,
      "ta": "> div.masterdiv > div:[2]"
    },
    {
      "t": 110409,
      "e": 103595,
      "ty": 2,
      "x": 937,
      "y": 942
    },
    {
      "t": 110509,
      "e": 103695,
      "ty": 2,
      "x": 937,
      "y": 1036
    },
    {
      "t": 110509,
      "e": 103695,
      "ty": 41,
      "x": 31660,
      "y": 62994,
      "ta": "> div.masterdiv > div:[2]"
    },
    {
      "t": 110550,
      "e": 103736,
      "ty": 6,
      "x": 943,
      "y": 1072,
      "ta": "#start"
    },
    {
      "t": 110608,
      "e": 103794,
      "ty": 2,
      "x": 944,
      "y": 1078
    },
    {
      "t": 110708,
      "e": 103894,
      "ty": 2,
      "x": 946,
      "y": 1088
    },
    {
      "t": 110759,
      "e": 103945,
      "ty": 41,
      "x": 22664,
      "y": 43007,
      "ta": "#start"
    },
    {
      "t": 110809,
      "e": 103995,
      "ty": 2,
      "x": 952,
      "y": 1098
    },
    {
      "t": 111008,
      "e": 104194,
      "ty": 41,
      "x": 23210,
      "y": 48789,
      "ta": "#start"
    },
    {
      "t": 111044,
      "e": 104230,
      "ty": 3,
      "x": 952,
      "y": 1098,
      "ta": "#start"
    },
    {
      "t": 111045,
      "e": 104231,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#start"
    },
    {
      "t": 111139,
      "e": 104325,
      "ty": 4,
      "x": 23210,
      "y": 48789,
      "ta": "#start"
    },
    {
      "t": 111141,
      "e": 104327,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#start"
    },
    {
      "t": 111141,
      "e": 104327,
      "ty": 5,
      "x": 952,
      "y": 1098,
      "ta": "#start"
    },
    {
      "t": 111143,
      "e": 104329,
      "ty": 38,
      "x": 7,
      "y": 0
    },
    {
      "t": 112009,
      "e": 105195,
      "ty": 2,
      "x": 977,
      "y": 777
    },
    {
      "t": 112009,
      "e": 105195,
      "ty": 41,
      "x": 33370,
      "y": 42600,
      "ta": "html > body"
    },
    {
      "t": 112108,
      "e": 105294,
      "ty": 2,
      "x": 988,
      "y": 689
    },
    {
      "t": 112173,
      "e": 105359,
      "ty": 38,
      "x": 8,
      "y": 0
    },
    {
      "t": 112652,
      "e": 105838,
      "ty": 2,
      "x": 906,
      "y": 686
    },
    {
      "t": 112652,
      "e": 105838,
      "ty": 41,
      "x": 30580,
      "y": 32797,
      "ta": "#jspsych-data-display"
    },
    {
      "t": 112708,
      "e": 105894,
      "ty": 2,
      "x": 905,
      "y": 685
    },
    {
      "t": 112758,
      "e": 105944,
      "ty": 41,
      "x": 30540,
      "y": 32796,
      "ta": "#jspsych-data-display"
    },
    {
      "t": 112808,
      "e": 105994,
      "ty": 2,
      "x": 904,
      "y": 685
    },
    {
      "t": 112909,
      "e": 106095,
      "ty": 2,
      "x": 901,
      "y": 684
    },
    {
      "t": 113008,
      "e": 106194,
      "ty": 2,
      "x": 900,
      "y": 684
    },
    {
      "t": 113009,
      "e": 106195,
      "ty": 41,
      "x": 30335,
      "y": 32796,
      "ta": "#jspsych-data-display"
    },
    {
      "t": 113164,
      "e": 106350,
      "ty": 20,
      "x": 0,
      "y": 0
    }
  ],
  "domMutations": [
    {
      "sequence": 1,
      "data": "{\"f\":\"applyChanged\",\"args\":[[{\"id\":56},{\"id\":57},{\"id\":58},{\"id\":59},{\"id\":60},{\"id\":61},{\"id\":62},{\"id\":63},{\"id\":64},{\"id\":65},{\"id\":66},{\"id\":67},{\"id\":68},{\"id\":69},{\"id\":70},{\"id\":71},{\"id\":72},{\"id\":73},{\"id\":74},{\"id\":75},{\"id\":76},{\"id\":77},{\"id\":78},{\"id\":79},{\"id\":80},{\"id\":81},{\"id\":82},{\"id\":83},{\"id\":84},{\"id\":85},{\"id\":86},{\"id\":87},{\"id\":88},{\"id\":89},{\"id\":90},{\"id\":91},{\"id\":92},{\"id\":93},{\"id\":94},{\"id\":95},{\"id\":96},{\"id\":97},{\"id\":98},{\"id\":99},{\"id\":100},{\"id\":101},{\"id\":102},{\"id\":103},{\"id\":104},{\"id\":105},{\"id\":106},{\"id\":107},{\"id\":108},{\"id\":109},{\"id\":110},{\"id\":111},{\"id\":112},{\"id\":113},{\"id\":114},{\"id\":115},{\"id\":116},{\"id\":117},{\"id\":118},{\"id\":119},{\"id\":120},{\"id\":121},{\"id\":122},{\"id\":123},{\"id\":124},{\"id\":125},{\"id\":126},{\"id\":127},{\"id\":128},{\"id\":129},{\"id\":130},{\"id\":131},{\"id\":132},{\"id\":133},{\"id\":134},{\"id\":135},{\"id\":136},{\"id\":137},{\"id\":138},{\"id\":139},{\"id\":140},{\"id\":141},{\"id\":142},{\"id\":143},{\"id\":144},{\"id\":145},{\"id\":146},{\"id\":147},{\"id\":148},{\"id\":149},{\"id\":150},{\"id\":151},{\"id\":152},{\"id\":153},{\"id\":154},{\"id\":155},{\"id\":156},{\"id\":157},{\"id\":158},{\"id\":159},{\"id\":160},{\"id\":161},{\"id\":162},{\"id\":163},{\"id\":164},{\"id\":165},{\"id\":166},{\"id\":167},{\"id\":168},{\"id\":169},{\"id\":170},{\"id\":171},{\"id\":172},{\"id\":173},{\"id\":174},{\"id\":175},{\"id\":176},{\"id\":177},{\"id\":178},{\"id\":179},{\"id\":180},{\"id\":181},{\"id\":182},{\"id\":183},{\"id\":184},{\"id\":185},{\"id\":186},{\"id\":187},{\"id\":188},{\"id\":189},{\"id\":190},{\"id\":191},{\"id\":192},{\"id\":193},{\"id\":194},{\"id\":195},{\"id\":196},{\"id\":197},{\"id\":198},{\"id\":199},{\"id\":200},{\"id\":201},{\"id\":202},{\"id\":203},{\"id\":204},{\"id\":205},{\"id\":206},{\"id\":207},{\"id\":208},{\"id\":209},{\"id\":210},{\"id\":211},{\"id\":212},{\"id\":213},{\"id\":214},{\"id\":215},{\"id\":216},{\"id\":217},{\"id\":218},{\"id\":219},{\"id\":220},{\"id\":221},{\"id\":222},{\"id\":223},{\"id\":224},{\"id\":225},{\"id\":226},{\"id\":227},{\"id\":228},{\"id\":229},{\"id\":230},{\"id\":231},{\"id\":232},{\"id\":233},{\"id\":234},{\"id\":235},{\"id\":236},{\"id\":237},{\"id\":238},{\"id\":239},{\"id\":240},{\"id\":241},{\"id\":242},{\"id\":243},{\"id\":244},{\"id\":245},{\"id\":246},{\"id\":247},{\"id\":248},{\"id\":249},{\"id\":250},{\"id\":251},{\"id\":252},{\"id\":253},{\"id\":254},{\"id\":255},{\"id\":256},{\"id\":257},{\"id\":258},{\"id\":259},{\"id\":260},{\"id\":261},{\"id\":262},{\"id\":263},{\"id\":264},{\"id\":265},{\"id\":266},{\"id\":267},{\"id\":268},{\"id\":269},{\"id\":270},{\"id\":271},{\"id\":272},{\"id\":273},{\"id\":274},{\"id\":275},{\"id\":276},{\"id\":277},{\"id\":278},{\"id\":279},{\"id\":280},{\"id\":281},{\"id\":282},{\"id\":283},{\"id\":284},{\"id\":285},{\"id\":286},{\"id\":287},{\"id\":288},{\"id\":289},{\"id\":290},{\"id\":291},{\"id\":292},{\"id\":293},{\"id\":294},{\"id\":295},{\"id\":296},{\"id\":297},{\"id\":298},{\"id\":299},{\"id\":300},{\"id\":301},{\"id\":302},{\"id\":303},{\"id\":304},{\"id\":305},{\"id\":306},{\"id\":307},{\"id\":308},{\"id\":309},{\"id\":310},{\"id\":311},{\"id\":312},{\"id\":313},{\"id\":314},{\"id\":315},{\"id\":316},{\"id\":317},{\"id\":318},{\"id\":319},{\"id\":320},{\"id\":321},{\"id\":322},{\"id\":323},{\"id\":324},{\"id\":325},{\"id\":326},{\"id\":327},{\"id\":328},{\"id\":329},{\"id\":330},{\"id\":331},{\"id\":332},{\"id\":333},{\"id\":334},{\"id\":335},{\"id\":336},{\"id\":337},{\"id\":338},{\"id\":339},{\"id\":340},{\"id\":341},{\"id\":342},{\"id\":343},{\"id\":344},{\"id\":345},{\"id\":346},{\"id\":347},{\"id\":348},{\"id\":349},{\"id\":350},{\"id\":351},{\"id\":352},{\"id\":353},{\"id\":354},{\"id\":355},{\"id\":356},{\"id\":357},{\"id\":358},{\"id\":359},{\"id\":360},{\"id\":361},{\"id\":362},{\"id\":363},{\"id\":364},{\"id\":365},{\"id\":366},{\"id\":367},{\"id\":368},{\"id\":369},{\"id\":370},{\"id\":371},{\"id\":372},{\"id\":373},{\"id\":374},{\"id\":375},{\"id\":376},{\"id\":377},{\"id\":378},{\"id\":379},{\"id\":380},{\"id\":381},{\"id\":382},{\"id\":383},{\"id\":384},{\"id\":385},{\"id\":386},{\"id\":387},{\"id\":388},{\"id\":389},{\"id\":390},{\"id\":391},{\"id\":392},{\"id\":393},{\"id\":394},{\"id\":395},{\"id\":396},{\"id\":397},{\"id\":398},{\"id\":399},{\"id\":400},{\"id\":401},{\"id\":402},{\"id\":403},{\"id\":404},{\"id\":405},{\"id\":406},{\"id\":407},{\"id\":408},{\"id\":409},{\"id\":410},{\"id\":411},{\"id\":412},{\"id\":413},{\"id\":414},{\"id\":415},{\"id\":416},{\"id\":417},{\"id\":418},{\"id\":419},{\"id\":420},{\"id\":421},{\"id\":422},{\"id\":423},{\"id\":424},{\"id\":425},{\"id\":426},{\"id\":427},{\"id\":428},{\"id\":429},{\"id\":430},{\"id\":431},{\"id\":432},{\"id\":433},{\"id\":434},{\"id\":435},{\"id\":436},{\"id\":437},{\"id\":438},{\"id\":439},{\"id\":440},{\"id\":441},{\"id\":442},{\"id\":443},{\"id\":444},{\"id\":445},{\"id\":446},{\"id\":447},{\"id\":448},{\"id\":449},{\"id\":450},{\"id\":451},{\"id\":452},{\"id\":453},{\"id\":454},{\"id\":455},{\"id\":456},{\"id\":457},{\"id\":458},{\"id\":459},{\"id\":460},{\"id\":461},{\"id\":462},{\"id\":463},{\"id\":464},{\"id\":465},{\"id\":466},{\"id\":467},{\"id\":468},{\"id\":469},{\"id\":470},{\"id\":471},{\"id\":472},{\"id\":473},{\"id\":474},{\"id\":475},{\"id\":476},{\"id\":477},{\"id\":478},{\"id\":479},{\"id\":480},{\"id\":481},{\"id\":482},{\"id\":483},{\"id\":484},{\"id\":485},{\"id\":486},{\"id\":487},{\"id\":488},{\"id\":489},{\"id\":490},{\"id\":491},{\"id\":492},{\"id\":493},{\"id\":494},{\"id\":495},{\"id\":496},{\"id\":497},{\"id\":498},{\"id\":499},{\"id\":500},{\"id\":501},{\"id\":502},{\"id\":503},{\"id\":504},{\"id\":505},{\"id\":506},{\"id\":507},{\"id\":508},{\"id\":509},{\"id\":510},{\"id\":511},{\"id\":512},{\"id\":513},{\"id\":514},{\"id\":515},{\"id\":516},{\"id\":517},{\"id\":518},{\"id\":519},{\"id\":520},{\"id\":521},{\"id\":522},{\"id\":523},{\"id\":524},{\"id\":525},{\"id\":526},{\"id\":527},{\"id\":528},{\"id\":529},{\"id\":530},{\"id\":531},{\"id\":532},{\"id\":533},{\"id\":534},{\"id\":535},{\"id\":536},{\"id\":537},{\"id\":538},{\"id\":539},{\"id\":540},{\"id\":541},{\"id\":542},{\"id\":543},{\"id\":544},{\"id\":545},{\"id\":546},{\"id\":547},{\"id\":548},{\"id\":549},{\"id\":550},{\"id\":551},{\"id\":552},{\"id\":553},{\"id\":554},{\"id\":555},{\"id\":556},{\"id\":557},{\"id\":558},{\"id\":559},{\"id\":560},{\"id\":561},{\"id\":562},{\"id\":563},{\"id\":564},{\"id\":565},{\"id\":566},{\"id\":567},{\"id\":568},{\"id\":569},{\"id\":570},{\"id\":571},{\"id\":572},{\"id\":573},{\"id\":574},{\"id\":575},{\"id\":576},{\"id\":577},{\"id\":578},{\"id\":579},{\"id\":580},{\"id\":581},{\"id\":582},{\"id\":583},{\"id\":584},{\"id\":585},{\"id\":586},{\"id\":587},{\"id\":588},{\"id\":589},{\"id\":590},{\"id\":591},{\"id\":592},{\"id\":593},{\"id\":594},{\"id\":595},{\"id\":596},{\"id\":597},{\"id\":598},{\"id\":599},{\"id\":600},{\"id\":601},{\"id\":602},{\"id\":603},{\"id\":604},{\"id\":605},{\"id\":606},{\"id\":607},{\"id\":608},{\"id\":609},{\"id\":610},{\"id\":611},{\"id\":612},{\"id\":613},{\"id\":614},{\"id\":615},{\"id\":616},{\"id\":617},{\"id\":618},{\"id\":619},{\"id\":620},{\"id\":621},{\"id\":622},{\"id\":623},{\"id\":624},{\"id\":625},{\"id\":626},{\"id\":627},{\"id\":628},{\"id\":629},{\"id\":630},{\"id\":631},{\"id\":632},{\"id\":633},{\"id\":634},{\"id\":635},{\"id\":636},{\"id\":637},{\"id\":638},{\"id\":639},{\"id\":640},{\"id\":641},{\"id\":642},{\"id\":643},{\"id\":644},{\"id\":645},{\"id\":646},{\"id\":647},{\"id\":648},{\"id\":649},{\"id\":650},{\"id\":651},{\"id\":652},{\"id\":653},{\"id\":654},{\"id\":655},{\"id\":656},{\"id\":657},{\"id\":658},{\"id\":659},{\"id\":660},{\"id\":661},{\"id\":662},{\"id\":663},{\"id\":664},{\"id\":665},{\"id\":666},{\"id\":667},{\"id\":668},{\"id\":669},{\"id\":670},{\"id\":671},{\"id\":672},{\"id\":673},{\"id\":674},{\"id\":675},{\"id\":676},{\"id\":677},{\"id\":678},{\"id\":679},{\"id\":680},{\"id\":681},{\"id\":682},{\"id\":683},{\"id\":684},{\"id\":685},{\"id\":686},{\"id\":687},{\"id\":688},{\"id\":689},{\"id\":690},{\"id\":691},{\"id\":692},{\"id\":693},{\"id\":694},{\"id\":695},{\"id\":696},{\"id\":697},{\"id\":698},{\"id\":699},{\"id\":700},{\"id\":701},{\"id\":702},{\"id\":703},{\"id\":704},{\"id\":705},{\"id\":706},{\"id\":707},{\"id\":708},{\"id\":709},{\"id\":710},{\"id\":711},{\"id\":712},{\"id\":713},{\"id\":714},{\"id\":715},{\"id\":716},{\"id\":717},{\"id\":718},{\"id\":719},{\"id\":720},{\"id\":721},{\"id\":722},{\"id\":723},{\"id\":724},{\"id\":725},{\"id\":726},{\"id\":727},{\"id\":728},{\"id\":729},{\"id\":730},{\"id\":731},{\"id\":732},{\"id\":733},{\"id\":734},{\"id\":735},{\"id\":736},{\"id\":737},{\"id\":738},{\"id\":739},{\"id\":740},{\"id\":741},{\"id\":742},{\"id\":743},{\"id\":744},{\"id\":745},{\"id\":746},{\"id\":747},{\"id\":748},{\"id\":749},{\"id\":750},{\"id\":751},{\"id\":752},{\"id\":753},{\"id\":754},{\"id\":755},{\"id\":756},{\"id\":757},{\"id\":758},{\"id\":759},{\"id\":760},{\"id\":761},{\"id\":762},{\"id\":763},{\"id\":764},{\"id\":765},{\"id\":766},{\"id\":767},{\"id\":768},{\"id\":769},{\"id\":770},{\"id\":771},{\"id\":772},{\"id\":773},{\"id\":774},{\"id\":775},{\"id\":776},{\"id\":777},{\"id\":778},{\"id\":779},{\"id\":780},{\"id\":781},{\"id\":782},{\"id\":783},{\"id\":784},{\"id\":785},{\"id\":786},{\"id\":787},{\"id\":788},{\"id\":789},{\"id\":790},{\"id\":791},{\"id\":792},{\"id\":793},{\"id\":794},{\"id\":795},{\"id\":796},{\"id\":797},{\"id\":798},{\"id\":799},{\"id\":800},{\"id\":801},{\"id\":802},{\"id\":803},{\"id\":804},{\"id\":805},{\"id\":806},{\"id\":807},{\"id\":808},{\"id\":809},{\"id\":810},{\"id\":811},{\"id\":812},{\"id\":813},{\"id\":814},{\"id\":815},{\"id\":816},{\"id\":817},{\"id\":818},{\"id\":819},{\"id\":820},{\"id\":821},{\"id\":822},{\"id\":823},{\"id\":824},{\"id\":825},{\"id\":826},{\"id\":827},{\"id\":828},{\"id\":829},{\"id\":830},{\"id\":831},{\"id\":832},{\"id\":833},{\"id\":834},{\"id\":835},{\"id\":836},{\"id\":837},{\"id\":838},{\"id\":839},{\"id\":840},{\"id\":841},{\"id\":842},{\"id\":843},{\"id\":844},{\"id\":845},{\"id\":846},{\"id\":847},{\"id\":848},{\"id\":849},{\"id\":850},{\"id\":851},{\"id\":852},{\"id\":853},{\"id\":854},{\"id\":855},{\"id\":856},{\"id\":857},{\"id\":858},{\"id\":859},{\"id\":860},{\"id\":861},{\"id\":862},{\"id\":863},{\"id\":864},{\"id\":865},{\"id\":866},{\"id\":867},{\"id\":868},{\"id\":869},{\"id\":870},{\"id\":871},{\"id\":872},{\"id\":873},{\"id\":874},{\"id\":875},{\"id\":876},{\"id\":877},{\"id\":878},{\"id\":879},{\"id\":880},{\"id\":881},{\"id\":882},{\"id\":883},{\"id\":884},{\"id\":885},{\"id\":886},{\"id\":887},{\"id\":888},{\"id\":889},{\"id\":890},{\"id\":891},{\"id\":892},{\"id\":893},{\"id\":894},{\"id\":895},{\"id\":896},{\"id\":897},{\"id\":898},{\"id\":899},{\"id\":900},{\"id\":901},{\"id\":902},{\"id\":903},{\"id\":904},{\"id\":905},{\"id\":906},{\"id\":907},{\"id\":908},{\"id\":909},{\"id\":910},{\"id\":911},{\"id\":912},{\"id\":913},{\"id\":914},{\"id\":915},{\"id\":916},{\"id\":917},{\"id\":918},{\"id\":919},{\"id\":920},{\"id\":921},{\"id\":922},{\"id\":923},{\"id\":924},{\"id\":925},{\"id\":926},{\"id\":927},{\"id\":928},{\"id\":929},{\"id\":930},{\"id\":931},{\"id\":932},{\"id\":933},{\"id\":934},{\"id\":935},{\"id\":936},{\"id\":937},{\"id\":938},{\"id\":939},{\"id\":940},{\"id\":941},{\"id\":942},{\"id\":943},{\"id\":944},{\"id\":945},{\"id\":946},{\"id\":947},{\"id\":948},{\"id\":949},{\"id\":950},{\"id\":951},{\"id\":952},{\"id\":953},{\"id\":954},{\"id\":955},{\"id\":956},{\"id\":957},{\"id\":958},{\"id\":959},{\"id\":960},{\"id\":961},{\"id\":962},{\"id\":963},{\"id\":964},{\"id\":965},{\"id\":966},{\"id\":967},{\"id\":968},{\"id\":969},{\"id\":970},{\"id\":971},{\"id\":972},{\"id\":973},{\"id\":974},{\"id\":975},{\"id\":976},{\"id\":977},{\"id\":978},{\"id\":979},{\"id\":980},{\"id\":981},{\"id\":982},{\"id\":983},{\"id\":984},{\"id\":985},{\"id\":986},{\"id\":987},{\"id\":988},{\"id\":989},{\"id\":990},{\"id\":991},{\"id\":992},{\"id\":993},{\"id\":994},{\"id\":995},{\"id\":996},{\"id\":997},{\"id\":998},{\"id\":999},{\"id\":1000},{\"id\":1001},{\"id\":1002},{\"id\":1003},{\"id\":1004},{\"id\":1005},{\"id\":1006},{\"id\":1007},{\"id\":1008},{\"id\":1009},{\"id\":1010},{\"id\":1011},{\"id\":1012},{\"id\":1013},{\"id\":1014},{\"id\":1015},{\"id\":1016},{\"id\":1017},{\"id\":1018},{\"id\":1019},{\"id\":1020},{\"id\":1021},{\"id\":1022},{\"id\":1023},{\"id\":1024},{\"id\":1025},{\"id\":1026},{\"id\":1027},{\"id\":1028},{\"id\":1029},{\"id\":1030},{\"id\":1031},{\"id\":1032},{\"id\":1033},{\"id\":1034},{\"id\":1035},{\"id\":1036},{\"id\":1037},{\"id\":1038},{\"id\":1039},{\"id\":1040},{\"id\":1041},{\"id\":1042},{\"id\":1043},{\"id\":1044},{\"id\":1045},{\"id\":1046},{\"id\":1047},{\"id\":1048},{\"id\":1049},{\"id\":1050},{\"id\":1051},{\"id\":1052},{\"id\":1053},{\"id\":1054},{\"id\":1055},{\"id\":1056},{\"id\":1057},{\"id\":1058},{\"id\":1059},{\"id\":1060},{\"id\":1061},{\"id\":1062},{\"id\":1063},{\"id\":1064},{\"id\":1065},{\"id\":1066},{\"id\":1067},{\"id\":1068},{\"id\":1069},{\"id\":1070},{\"id\":1071},{\"id\":1072},{\"id\":1073},{\"id\":1074},{\"id\":1075},{\"id\":1076},{\"id\":1077},{\"id\":1078},{\"id\":1079},{\"id\":1080},{\"id\":1081},{\"id\":1082},{\"id\":1083},{\"id\":1084},{\"id\":1085},{\"id\":1086},{\"id\":1087},{\"id\":1088},{\"id\":1089},{\"id\":1090},{\"id\":1091},{\"id\":1092},{\"id\":1093},{\"id\":1094},{\"id\":1095},{\"id\":1096},{\"id\":1097},{\"id\":1098},{\"id\":1099},{\"id\":1100},{\"id\":1101},{\"id\":1102},{\"id\":1103},{\"id\":1104},{\"id\":1105},{\"id\":1106},{\"id\":1107},{\"id\":1108},{\"id\":1109},{\"id\":1110},{\"id\":1111},{\"id\":1112},{\"id\":1113},{\"id\":1114},{\"id\":1115},{\"id\":1116},{\"id\":1117},{\"id\":1118},{\"id\":1119},{\"id\":1120},{\"id\":1121},{\"id\":1122},{\"id\":1123},{\"id\":1124},{\"id\":1125},{\"id\":1126},{\"id\":1127},{\"id\":1128},{\"id\":1129},{\"id\":1130},{\"id\":1131},{\"id\":1132},{\"id\":1133},{\"id\":1134},{\"id\":1135},{\"id\":1136},{\"id\":1137},{\"id\":1138},{\"id\":1139},{\"id\":1140},{\"id\":1141},{\"id\":1142},{\"id\":1143},{\"id\":1144},{\"id\":1145},{\"id\":1146},{\"id\":1147},{\"id\":1148},{\"id\":1149},{\"id\":1150},{\"id\":1151},{\"id\":1152},{\"id\":1153},{\"id\":1154},{\"id\":1155},{\"id\":1156},{\"id\":1157},{\"id\":1158},{\"id\":1159},{\"id\":1160},{\"id\":1161},{\"id\":1162},{\"id\":1163},{\"id\":1164},{\"id\":1165},{\"id\":1166},{\"id\":1167},{\"id\":1168},{\"id\":1169},{\"id\":1170},{\"id\":1171},{\"id\":1172},{\"id\":1173},{\"id\":1174},{\"id\":1175},{\"id\":1176},{\"id\":1177},{\"id\":1178},{\"id\":1179},{\"id\":1180},{\"id\":1181},{\"id\":1182},{\"id\":1183},{\"id\":1184},{\"id\":1185},{\"id\":1186},{\"id\":1187},{\"id\":1188},{\"id\":1189},{\"id\":1190},{\"id\":1191},{\"id\":1192},{\"id\":1193},{\"id\":1194},{\"id\":1195},{\"id\":1196},{\"id\":1197},{\"id\":1198},{\"id\":1199},{\"id\":1200},{\"id\":1201},{\"id\":1202},{\"id\":1203},{\"id\":1204},{\"id\":1205},{\"id\":1206},{\"id\":1207},{\"id\":1208},{\"id\":1209},{\"id\":1210},{\"id\":1211},{\"id\":1212},{\"id\":1213},{\"id\":1214},{\"id\":1215},{\"id\":1216},{\"id\":1217},{\"id\":1218},{\"id\":1219},{\"id\":1220},{\"id\":1221},{\"id\":1222},{\"id\":1223},{\"id\":1224},{\"id\":1225},{\"id\":1226},{\"id\":1227},{\"id\":1228},{\"id\":1229},{\"id\":1230},{\"id\":1231},{\"id\":1232},{\"id\":1233},{\"id\":1234},{\"id\":1235},{\"id\":1236},{\"id\":1237},{\"id\":1238},{\"id\":1239},{\"id\":1240},{\"id\":1241},{\"id\":1242},{\"id\":1243},{\"id\":1244},{\"id\":1245},{\"id\":1246},{\"id\":1247},{\"id\":1248},{\"id\":1249},{\"id\":1250},{\"id\":1251},{\"id\":1252},{\"id\":1253},{\"id\":1254},{\"id\":1255},{\"id\":1256},{\"id\":1257},{\"id\":1258},{\"id\":1259},{\"id\":1260},{\"id\":1261},{\"id\":1262},{\"id\":1263},{\"id\":1264},{\"id\":1265},{\"id\":1266},{\"id\":1267},{\"id\":1268},{\"id\":1269},{\"id\":1270},{\"id\":1271},{\"id\":1272},{\"id\":1273},{\"id\":1274},{\"id\":1275},{\"id\":1276},{\"id\":1277},{\"id\":1278},{\"id\":1279},{\"id\":1280},{\"id\":1281},{\"id\":1282},{\"id\":1283},{\"id\":1284},{\"id\":1285},{\"id\":1286},{\"id\":1287},{\"id\":1288},{\"id\":1289},{\"id\":1290},{\"id\":1291},{\"id\":1292},{\"id\":1293},{\"id\":1294},{\"id\":1295},{\"id\":1296},{\"id\":1297},{\"id\":1298},{\"id\":1299},{\"id\":1300},{\"id\":1301},{\"id\":1302},{\"id\":1303},{\"id\":1304},{\"id\":1305},{\"id\":1306},{\"id\":1307},{\"id\":1308},{\"id\":1309},{\"id\":1310},{\"id\":1311},{\"id\":1312},{\"id\":1313},{\"id\":1314},{\"id\":1315},{\"id\":1316},{\"id\":1317},{\"id\":1318},{\"id\":1319},{\"id\":1320},{\"id\":1321},{\"id\":1322},{\"id\":1323},{\"id\":1324},{\"id\":1325},{\"id\":1326},{\"id\":1327},{\"id\":1328},{\"id\":1329},{\"id\":1330},{\"id\":1331},{\"id\":1332},{\"id\":1333},{\"id\":1334},{\"id\":1335},{\"id\":1336},{\"id\":1337},{\"id\":1338},{\"id\":1339},{\"id\":1340},{\"id\":1341},{\"id\":1342},{\"id\":1343},{\"id\":1344},{\"id\":1345},{\"id\":1346},{\"id\":1347},{\"id\":1348},{\"id\":1349},{\"id\":1350},{\"id\":1351},{\"id\":1352},{\"id\":1353},{\"id\":1354},{\"id\":1355},{\"id\":1356},{\"id\":1357},{\"id\":1358},{\"id\":1359},{\"id\":1360},{\"id\":1361},{\"id\":1362},{\"id\":1363},{\"id\":1364},{\"id\":1365},{\"id\":1366},{\"id\":1367},{\"id\":1368},{\"id\":1369},{\"id\":1370},{\"id\":1371},{\"id\":1372},{\"id\":1373},{\"id\":1374},{\"id\":1375},{\"id\":1376},{\"id\":1377},{\"id\":1378},{\"id\":1379},{\"id\":1380},{\"id\":1381},{\"id\":1382},{\"id\":1383},{\"id\":1384},{\"id\":1385},{\"id\":1386},{\"id\":1387},{\"id\":1388},{\"id\":1389},{\"id\":1390},{\"id\":1391},{\"id\":1392},{\"id\":1393},{\"id\":1394},{\"id\":1395},{\"id\":1396},{\"id\":1397},{\"id\":1398},{\"id\":1399},{\"id\":1400},{\"id\":1401},{\"id\":1402},{\"id\":1403},{\"id\":1404},{\"id\":1405},{\"id\":1406},{\"id\":1407},{\"id\":1408},{\"id\":1409},{\"id\":1410},{\"id\":1411},{\"id\":1412},{\"id\":1413},{\"id\":1414},{\"id\":1415},{\"id\":1416},{\"id\":1417},{\"id\":1418},{\"id\":1419},{\"id\":1420},{\"id\":1421},{\"id\":1422},{\"id\":1423},{\"id\":1424},{\"id\":1425},{\"id\":1426},{\"id\":1427},{\"id\":1428},{\"id\":1429},{\"id\":1430},{\"id\":1431},{\"id\":1432},{\"id\":1433},{\"id\":1434},{\"id\":1435},{\"id\":1436},{\"id\":1437},{\"id\":1438},{\"id\":1439},{\"id\":1440},{\"id\":1441},{\"id\":1442},{\"id\":1443},{\"id\":1444},{\"id\":1445},{\"id\":1446},{\"id\":1447},{\"id\":1448},{\"id\":1449},{\"id\":1450},{\"id\":1451},{\"id\":1452},{\"id\":1453},{\"id\":1454},{\"id\":1455},{\"id\":1456},{\"id\":1457},{\"id\":1458},{\"id\":1459},{\"id\":1460},{\"id\":1461},{\"id\":1462},{\"id\":1463},{\"id\":1464},{\"id\":1465},{\"id\":1466},{\"id\":1467},{\"id\":1468},{\"id\":1469},{\"id\":1470},{\"id\":1471},{\"id\":1472},{\"id\":1473},{\"id\":1474},{\"id\":1475},{\"id\":1476},{\"id\":1477},{\"id\":1478},{\"id\":1479},{\"id\":1480},{\"id\":1481},{\"id\":1482},{\"id\":1483},{\"id\":1484},{\"id\":1485},{\"id\":1486},{\"id\":1487},{\"id\":1488},{\"id\":1489},{\"id\":1490},{\"id\":1491},{\"id\":1492},{\"id\":1493},{\"id\":1494},{\"id\":1495},{\"id\":1496},{\"id\":1497},{\"id\":1498},{\"id\":1499},{\"id\":1500},{\"id\":1501},{\"id\":1502},{\"id\":1503},{\"id\":1504},{\"id\":1505},{\"id\":1506},{\"id\":1507},{\"id\":1508},{\"id\":1509},{\"id\":1510},{\"id\":1511},{\"id\":1512},{\"id\":1513},{\"id\":1514},{\"id\":1515},{\"id\":1516},{\"id\":1517},{\"id\":1518},{\"id\":1519},{\"id\":1520},{\"id\":1521},{\"id\":1522},{\"id\":1523},{\"id\":1524},{\"id\":1525},{\"id\":1526},{\"id\":1527},{\"id\":1528},{\"id\":1529},{\"id\":1530},{\"id\":1531},{\"id\":1532},{\"id\":1533},{\"id\":1534},{\"id\":1535},{\"id\":1536},{\"id\":1537},{\"id\":1538},{\"id\":1539},{\"id\":1540},{\"id\":1541},{\"id\":1542},{\"id\":1543},{\"id\":1544},{\"id\":1545},{\"id\":1546},{\"id\":1547},{\"id\":1548},{\"id\":1549},{\"id\":1550},{\"id\":1551},{\"id\":1552},{\"id\":1553},{\"id\":1554},{\"id\":1555},{\"id\":1556},{\"id\":1557},{\"id\":1558},{\"id\":1559},{\"id\":1560},{\"id\":1561},{\"id\":1562},{\"id\":1563},{\"id\":1564},{\"id\":1565},{\"id\":1566},{\"id\":1567},{\"id\":1568},{\"id\":1569},{\"id\":1570},{\"id\":1571},{\"id\":1572},{\"id\":1573},{\"id\":1574},{\"id\":1575},{\"id\":1576},{\"id\":1577},{\"id\":1578},{\"id\":1579},{\"id\":1580},{\"id\":1581},{\"id\":1582},{\"id\":1583},{\"id\":1584},{\"id\":1585},{\"id\":1586},{\"id\":1587},{\"id\":1588},{\"id\":1589},{\"id\":1590},{\"id\":1591},{\"id\":1592},{\"id\":1593},{\"id\":1594},{\"id\":1595},{\"id\":1596},{\"id\":1597},{\"id\":1598},{\"id\":1599},{\"id\":1600},{\"id\":1601},{\"id\":1602},{\"id\":1603},{\"id\":1604},{\"id\":1605},{\"id\":1606},{\"id\":1607},{\"id\":1608},{\"id\":1609},{\"id\":1610},{\"id\":1611},{\"id\":1612},{\"id\":1613},{\"id\":1614},{\"id\":1615},{\"id\":1616},{\"id\":1617},{\"id\":1618},{\"id\":1619},{\"id\":1620},{\"id\":1621},{\"id\":1622},{\"id\":1623},{\"id\":1624},{\"id\":1625},{\"id\":1626},{\"id\":1627},{\"id\":1628},{\"id\":1629},{\"id\":1630},{\"id\":1631},{\"id\":1632},{\"id\":1633},{\"id\":1634},{\"id\":1635},{\"id\":1636},{\"id\":1637},{\"id\":1638},{\"id\":1639},{\"id\":1640},{\"id\":1641},{\"id\":1642},{\"id\":1643},{\"id\":1644},{\"id\":1645},{\"id\":1646},{\"id\":1647},{\"id\":1648},{\"id\":1649},{\"id\":1650},{\"id\":1651},{\"id\":1652},{\"id\":1653},{\"id\":1654},{\"id\":1655},{\"id\":1656},{\"id\":1657},{\"id\":1658},{\"id\":1659},{\"id\":1660},{\"id\":1661},{\"id\":1662},{\"id\":1663},{\"id\":1664},{\"id\":1665},{\"id\":1666},{\"id\":1667},{\"id\":1668},{\"id\":1669},{\"id\":1670},{\"id\":1671},{\"id\":1672},{\"id\":1673},{\"id\":1674},{\"id\":1675},{\"id\":1676},{\"id\":1677},{\"id\":1678},{\"id\":1679},{\"id\":1680},{\"id\":1681},{\"id\":1682},{\"id\":1683},{\"id\":1684},{\"id\":1685},{\"id\":1686},{\"id\":1687},{\"id\":1688},{\"id\":1689},{\"id\":1690},{\"id\":1691},{\"id\":1692},{\"id\":1693},{\"id\":1694},{\"id\":1695},{\"id\":1696},{\"id\":1697},{\"id\":1698},{\"id\":1699},{\"id\":1700},{\"id\":1701},{\"id\":1702},{\"id\":1703},{\"id\":1704},{\"id\":1705},{\"id\":1706},{\"id\":1707},{\"id\":1708},{\"id\":1709},{\"id\":1710},{\"id\":1711},{\"id\":1712},{\"id\":1713},{\"id\":1714},{\"id\":1715},{\"id\":1716},{\"id\":1717},{\"id\":1718},{\"id\":1719},{\"id\":1720},{\"id\":1721},{\"id\":1722},{\"id\":1723},{\"id\":1724},{\"id\":1725},{\"id\":1726},{\"id\":1727},{\"id\":1728},{\"id\":1729},{\"id\":1730},{\"id\":1731},{\"id\":1732},{\"id\":1733},{\"id\":1734},{\"id\":1735},{\"id\":1736},{\"id\":1737},{\"id\":1738},{\"id\":1739},{\"id\":1740},{\"id\":1741},{\"id\":1742},{\"id\":1743},{\"id\":1744},{\"id\":1745},{\"id\":1746},{\"id\":1747},{\"id\":1748},{\"id\":1749},{\"id\":1750},{\"id\":1751},{\"id\":1752},{\"id\":1753},{\"id\":1754},{\"id\":1755},{\"id\":1756},{\"id\":1757},{\"id\":1758},{\"id\":1759},{\"id\":1760},{\"id\":1761},{\"id\":1762},{\"id\":1763},{\"id\":1764},{\"id\":1765},{\"id\":1766},{\"id\":1767},{\"id\":1768},{\"id\":1769},{\"id\":1770},{\"id\":1771},{\"id\":1772},{\"id\":1773},{\"id\":1774},{\"id\":1775},{\"id\":1776},{\"id\":1777},{\"id\":1778},{\"id\":1779},{\"id\":1780},{\"id\":1781},{\"id\":1782},{\"id\":1783},{\"id\":1784},{\"id\":1785},{\"id\":1786},{\"id\":1787},{\"id\":1788},{\"id\":1789},{\"id\":1790},{\"id\":1791},{\"id\":1792},{\"id\":1793},{\"id\":1794},{\"id\":1795},{\"id\":1796},{\"id\":1797},{\"id\":1798},{\"id\":1799},{\"id\":1800},{\"id\":1801},{\"id\":1802},{\"id\":1803},{\"id\":1804},{\"id\":1805},{\"id\":1806},{\"id\":1807},{\"id\":1808},{\"id\":1809},{\"id\":1810},{\"id\":1811},{\"id\":1812},{\"id\":1813},{\"id\":1814},{\"id\":1815},{\"id\":1816},{\"id\":1817},{\"id\":1818},{\"id\":1819},{\"id\":1820},{\"id\":1821},{\"id\":1822},{\"id\":1823},{\"id\":1824},{\"id\":1825},{\"id\":1826},{\"id\":1827},{\"id\":1828},{\"id\":1829},{\"id\":1830},{\"id\":1831},{\"id\":1832},{\"id\":1833},{\"id\":1834},{\"id\":1835},{\"id\":1836},{\"id\":1837},{\"id\":1838},{\"id\":1839},{\"id\":1840},{\"id\":1841},{\"id\":1842},{\"id\":1843},{\"id\":1844},{\"id\":1845},{\"id\":1846},{\"id\":1847},{\"id\":1848},{\"id\":1849},{\"id\":1850},{\"id\":1851},{\"id\":1852},{\"id\":1853},{\"id\":1854},{\"id\":1855},{\"id\":1856},{\"id\":1857},{\"id\":1858},{\"id\":1859},{\"id\":1860},{\"id\":1861},{\"id\":1862},{\"id\":1863},{\"id\":1864},{\"id\":1865},{\"id\":1866},{\"id\":1867},{\"id\":1868},{\"id\":1869},{\"id\":1870},{\"id\":1871},{\"id\":1872},{\"id\":1873},{\"id\":1874},{\"id\":1875},{\"id\":1876},{\"id\":1877},{\"id\":1878},{\"id\":1879},{\"id\":1880},{\"id\":1881},{\"id\":1882},{\"id\":1883},{\"id\":1884},{\"id\":1885},{\"id\":1886},{\"id\":1887},{\"id\":1888},{\"id\":1889},{\"id\":1890},{\"id\":1891},{\"id\":1892},{\"id\":1893},{\"id\":1894},{\"id\":1895},{\"id\":1896},{\"id\":1897},{\"id\":1898},{\"id\":1899},{\"id\":1900},{\"id\":1901},{\"id\":1902},{\"id\":1903},{\"id\":1904},{\"id\":1905},{\"id\":1906},{\"id\":1907},{\"id\":1908},{\"id\":1909},{\"id\":1910},{\"id\":1911},{\"id\":1912},{\"id\":1913},{\"id\":1914},{\"id\":1915},{\"id\":1916},{\"id\":1917},{\"id\":1918},{\"id\":1919},{\"id\":1920},{\"id\":1921},{\"id\":1922},{\"id\":1923},{\"id\":1924},{\"id\":1925},{\"id\":1926},{\"id\":1927},{\"id\":1928},{\"id\":1929},{\"id\":1930},{\"id\":1931},{\"id\":1932},{\"id\":1933},{\"id\":1934},{\"id\":1935},{\"id\":1936},{\"id\":1937},{\"id\":1938},{\"id\":1939},{\"id\":1940},{\"id\":1941},{\"id\":1942},{\"id\":1943},{\"id\":1944},{\"id\":1945},{\"id\":1946},{\"id\":1947},{\"id\":1948},{\"id\":1949},{\"id\":1950},{\"id\":1951},{\"id\":1952},{\"id\":1953},{\"id\":1954},{\"id\":1955},{\"id\":1956},{\"id\":1957},{\"id\":1958},{\"id\":1959},{\"id\":1960},{\"id\":1961},{\"id\":1962},{\"id\":1963},{\"id\":1964},{\"id\":1965},{\"id\":1966},{\"id\":1967},{\"id\":1968},{\"id\":1969},{\"id\":1970},{\"id\":1971},{\"id\":1972},{\"id\":1973},{\"id\":1974},{\"id\":1975},{\"id\":1976},{\"id\":1977},{\"id\":1978},{\"id\":1979},{\"id\":1980},{\"id\":1981},{\"id\":1982},{\"id\":1983},{\"id\":1984},{\"id\":1985},{\"id\":1986},{\"id\":1987},{\"id\":1988},{\"id\":1989},{\"id\":1990},{\"id\":1991},{\"id\":1992},{\"id\":1993},{\"id\":1994},{\"id\":1995},{\"id\":1996},{\"id\":1997},{\"id\":1998},{\"id\":1999},{\"id\":2000},{\"id\":2001},{\"id\":2002},{\"id\":2003},{\"id\":2004},{\"id\":2005},{\"id\":2006},{\"id\":2007},{\"id\":2008},{\"id\":2009},{\"id\":2010},{\"id\":2011},{\"id\":2012},{\"id\":2013},{\"id\":2014},{\"id\":2015},{\"id\":2016},{\"id\":2017},{\"id\":2018},{\"id\":2019},{\"id\":2020},{\"id\":2021},{\"id\":2022},{\"id\":2023},{\"id\":2024},{\"id\":2025},{\"id\":2026},{\"id\":2027},{\"id\":2028},{\"id\":2029},{\"id\":2030},{\"id\":2031},{\"id\":2032},{\"id\":2033},{\"id\":2034},{\"id\":2035},{\"id\":2036},{\"id\":2037},{\"id\":2038},{\"id\":2039},{\"id\":2040},{\"id\":2041},{\"id\":2042},{\"id\":2043},{\"id\":2044},{\"id\":2045},{\"id\":2046},{\"id\":2047},{\"id\":2048},{\"id\":2049},{\"id\":2050},{\"id\":2051},{\"id\":2052},{\"id\":2053},{\"id\":2054},{\"id\":2055},{\"id\":2056},{\"id\":2057},{\"id\":2058},{\"id\":2059},{\"id\":2060},{\"id\":2061},{\"id\":2062},{\"id\":2063},{\"id\":2064},{\"id\":2065},{\"id\":2066},{\"id\":2067},{\"id\":2068},{\"id\":2069},{\"id\":2070},{\"id\":2071},{\"id\":2072},{\"id\":2073},{\"id\":2074},{\"id\":2075},{\"id\":2076},{\"id\":2077},{\"id\":2078},{\"id\":2079},{\"id\":2080},{\"id\":2081},{\"id\":2082},{\"id\":2083},{\"id\":2084},{\"id\":2085},{\"id\":2086},{\"id\":2087},{\"id\":2088},{\"id\":2089},{\"id\":2090},{\"id\":2091},{\"id\":2092},{\"id\":2093},{\"id\":2094},{\"id\":2095},{\"id\":2096},{\"id\":2097},{\"id\":2098},{\"id\":2099},{\"id\":2100},{\"id\":2101},{\"id\":2102},{\"id\":2103},{\"id\":2104},{\"id\":2105},{\"id\":2106},{\"id\":2107},{\"id\":2108},{\"id\":2109},{\"id\":2110},{\"id\":2111},{\"id\":2112},{\"id\":2113},{\"id\":2114},{\"id\":2115},{\"id\":2116},{\"id\":2117},{\"id\":2118},{\"id\":2119},{\"id\":2120},{\"id\":2121},{\"id\":2122},{\"id\":2123},{\"id\":2124},{\"id\":2125},{\"id\":2126},{\"id\":2127},{\"id\":2128},{\"id\":2129},{\"id\":2130},{\"id\":2131},{\"id\":2132},{\"id\":2133},{\"id\":2134},{\"id\":2135},{\"id\":2136},{\"id\":2137},{\"id\":2138},{\"id\":2139},{\"id\":2140},{\"id\":2141},{\"id\":2142},{\"id\":2143},{\"id\":2144},{\"id\":2145},{\"id\":2146},{\"id\":2147},{\"id\":2148},{\"id\":2149},{\"id\":2150},{\"id\":2151},{\"id\":2152},{\"id\":2153},{\"id\":2154},{\"id\":2155},{\"id\":2156},{\"id\":2157},{\"id\":2158},{\"id\":2159},{\"id\":2160},{\"id\":2161},{\"id\":2162},{\"id\":2163},{\"id\":2164},{\"id\":2165},{\"id\":2166},{\"id\":2167},{\"id\":2168},{\"id\":2169},{\"id\":2170},{\"id\":2171},{\"id\":2172},{\"id\":2173},{\"id\":2174},{\"id\":2175},{\"id\":2176},{\"id\":2177},{\"id\":2178},{\"id\":2179},{\"id\":2180},{\"id\":2181},{\"id\":2182},{\"id\":2183},{\"id\":2184},{\"id\":2185},{\"id\":2186},{\"id\":2187},{\"id\":2188},{\"id\":2189},{\"id\":2190},{\"id\":2191},{\"id\":2192},{\"id\":2193},{\"id\":2194},{\"id\":2195},{\"id\":2196},{\"id\":2197},{\"id\":2198},{\"id\":2199},{\"id\":2200},{\"id\":2201},{\"id\":2202},{\"id\":2203},{\"id\":2204},{\"id\":2205},{\"id\":2206},{\"id\":2207},{\"id\":2208},{\"id\":2209},{\"id\":2210},{\"id\":2211},{\"id\":2212},{\"id\":2213},{\"id\":2214},{\"id\":2215},{\"id\":2216},{\"id\":2217},{\"id\":2218},{\"id\":2219},{\"id\":2220},{\"id\":2221},{\"id\":2222},{\"id\":2223},{\"id\":2224},{\"id\":2225},{\"id\":2226},{\"id\":2227},{\"id\":2228},{\"id\":2229},{\"id\":2230},{\"id\":2231},{\"id\":2232},{\"id\":2233},{\"id\":2234},{\"id\":2235},{\"id\":2236},{\"id\":2237},{\"id\":2238},{\"id\":2239},{\"id\":2240},{\"id\":2241},{\"id\":2242},{\"id\":2243},{\"id\":2244},{\"id\":2245},{\"id\":2246},{\"id\":2247},{\"id\":2248},{\"id\":2249},{\"id\":2250},{\"id\":2251},{\"id\":2252},{\"id\":2253},{\"id\":2254},{\"id\":2255},{\"id\":2256},{\"id\":2257},{\"id\":2258},{\"id\":2259},{\"id\":2260},{\"id\":2261},{\"id\":2262},{\"id\":2263},{\"id\":2264},{\"id\":2265},{\"id\":2266},{\"id\":2267},{\"id\":2268},{\"id\":2269},{\"id\":2270},{\"id\":2271},{\"id\":2272},{\"id\":2273},{\"id\":2274},{\"id\":2275},{\"id\":2276},{\"id\":2277},{\"id\":2278},{\"id\":2279},{\"id\":2280},{\"id\":2281},{\"id\":2282},{\"id\":2283},{\"id\":2284},{\"id\":2285},{\"id\":2286},{\"id\":2287},{\"id\":2288},{\"id\":2289},{\"id\":2290},{\"id\":2291},{\"id\":2292},{\"id\":2293},{\"id\":2294},{\"id\":2295},{\"id\":2296},{\"id\":2297},{\"id\":2298},{\"id\":2299},{\"id\":2300},{\"id\":2301},{\"id\":2302},{\"id\":2303},{\"id\":2304},{\"id\":2305},{\"id\":2306},{\"id\":2307},{\"id\":2308},{\"id\":2309},{\"id\":2310},{\"id\":2311},{\"id\":2312},{\"id\":2313},{\"id\":2314},{\"id\":2315},{\"id\":2316},{\"id\":2317},{\"id\":2318},{\"id\":2319},{\"id\":2320},{\"id\":2321},{\"id\":2322},{\"id\":2323},{\"id\":2324},{\"id\":2325},{\"id\":2326},{\"id\":2327},{\"id\":2328},{\"id\":2329},{\"id\":2330},{\"id\":2331},{\"id\":2332},{\"id\":2333},{\"id\":2334},{\"id\":2335},{\"id\":2336},{\"id\":2337},{\"id\":2338},{\"id\":2339},{\"id\":2340},{\"id\":2341},{\"id\":2342},{\"id\":2343},{\"id\":2344},{\"id\":2345},{\"id\":2346},{\"id\":2347},{\"id\":2348},{\"id\":2349},{\"id\":2350},{\"id\":2351},{\"id\":2352},{\"id\":2353},{\"id\":2354},{\"id\":2355},{\"id\":2356},{\"id\":2357},{\"id\":2358},{\"id\":2359},{\"id\":2360},{\"id\":2361},{\"id\":2362},{\"id\":2363},{\"id\":2364},{\"id\":2365},{\"id\":2366},{\"id\":2367},{\"id\":2368},{\"id\":2369},{\"id\":2370},{\"id\":2371},{\"id\":2372},{\"id\":2373},{\"id\":2374},{\"id\":2375},{\"id\":2376},{\"id\":2377},{\"id\":2378},{\"id\":2379},{\"id\":2380},{\"id\":2381},{\"id\":2382},{\"id\":2383},{\"id\":2384},{\"id\":2385},{\"id\":2386},{\"id\":2387},{\"id\":2388},{\"id\":2389},{\"id\":2390},{\"id\":2391},{\"id\":2392},{\"id\":2393},{\"id\":2394},{\"id\":2395},{\"id\":2396},{\"id\":2397},{\"id\":2398},{\"id\":2399},{\"id\":2400},{\"id\":2401},{\"id\":2402},{\"id\":2403},{\"id\":2404},{\"id\":2405},{\"id\":2406},{\"id\":2407},{\"id\":2408},{\"id\":2409},{\"id\":2410},{\"id\":2411},{\"id\":2412},{\"id\":2413},{\"id\":2414},{\"id\":2415},{\"id\":2416},{\"id\":2417},{\"id\":2418},{\"id\":2419},{\"id\":2420},{\"id\":2421},{\"id\":2422},{\"id\":2423},{\"id\":2424},{\"id\":2425},{\"id\":2426},{\"id\":2427},{\"id\":2428},{\"id\":2429},{\"id\":2430},{\"id\":2431},{\"id\":2432},{\"id\":2433},{\"id\":2434},{\"id\":2435},{\"id\":2436},{\"id\":2437},{\"id\":2438},{\"id\":2439},{\"id\":2440},{\"id\":2441},{\"id\":2442},{\"id\":2443},{\"id\":2444},{\"id\":2445},{\"id\":2446},{\"id\":2447},{\"id\":2448},{\"id\":2449},{\"id\":2450},{\"id\":2451},{\"id\":2452},{\"id\":2453},{\"id\":2454},{\"id\":2455},{\"id\":2456},{\"id\":2457},{\"id\":2458},{\"id\":2459},{\"id\":2460},{\"id\":2461},{\"id\":2462},{\"id\":2463},{\"id\":2464},{\"id\":2465},{\"id\":2466},{\"id\":2467},{\"id\":2468},{\"id\":2469},{\"id\":2470},{\"id\":2471},{\"id\":2472},{\"id\":2473},{\"id\":2474},{\"id\":2475},{\"id\":2476},{\"id\":2477},{\"id\":2478},{\"id\":2479},{\"id\":2480},{\"id\":2481},{\"id\":2482},{\"id\":2483},{\"id\":2484},{\"id\":2485},{\"id\":2486},{\"id\":2487},{\"id\":2488},{\"id\":2489},{\"id\":2490},{\"id\":2491},{\"id\":2492},{\"id\":2493},{\"id\":2494},{\"id\":2495},{\"id\":2496},{\"id\":2497},{\"id\":2498},{\"id\":2499},{\"id\":2500},{\"id\":2501},{\"id\":2502},{\"id\":2503},{\"id\":2504},{\"id\":2505},{\"id\":2506},{\"id\":2507},{\"id\":2508},{\"id\":2509},{\"id\":2510},{\"id\":2511},{\"id\":2512},{\"id\":2513},{\"id\":2514},{\"id\":2515},{\"id\":2516},{\"id\":2517},{\"id\":2518},{\"id\":2519},{\"id\":2520},{\"id\":2521},{\"id\":2522},{\"id\":2523},{\"id\":2524},{\"id\":2525},{\"id\":2526},{\"id\":2527},{\"id\":2528},{\"id\":2529},{\"id\":2530},{\"id\":2531},{\"id\":2532},{\"id\":2533},{\"id\":2534},{\"id\":2535},{\"id\":2536},{\"id\":2537},{\"id\":2538},{\"id\":2539},{\"id\":2540},{\"id\":2541},{\"id\":2542},{\"id\":2543},{\"id\":2544},{\"id\":2545},{\"id\":2546},{\"id\":2547},{\"id\":2548},{\"id\":2549},{\"id\":2550},{\"id\":2551},{\"id\":2552},{\"id\":2553},{\"id\":2554},{\"id\":2555},{\"id\":2556},{\"id\":2557},{\"id\":2558},{\"id\":2559},{\"id\":2560},{\"id\":2561},{\"id\":2562},{\"id\":2563},{\"id\":2564},{\"id\":2565},{\"id\":2566},{\"id\":2567},{\"id\":2568},{\"id\":2569},{\"id\":2570},{\"id\":2571},{\"id\":2572},{\"id\":2573},{\"id\":2574},{\"id\":2575},{\"id\":2576},{\"id\":2577},{\"id\":2578},{\"id\":2579},{\"id\":2580},{\"id\":2581},{\"id\":2582},{\"id\":2583},{\"id\":2584},{\"id\":2585},{\"id\":2586},{\"id\":2587},{\"id\":2588},{\"id\":2589},{\"id\":2590},{\"id\":2591},{\"id\":2592},{\"nodeType\":3,\"id\":2596,\"textContent\":\" // Track clicks on page $(document).ready(function() { $(\\\".control\\\").click(function(e) { e.stopImmediatePropagation(); clicks = clicks + 1; console.log(clicks); }); }); $('.userid').html(sid); // console.log(\\\"start of clicked array: \\\"+clicked); // console.log(\\\"start of hovered string: \\\"+hovered); //set correct answers for each question var triangular_answers = { \\\"acme.starttime.1\\\" : [\\\"F\\\"], \\\"acme.starts.1\\\" : [\\\"K\\\"], \\\"acme.meets.1\\\" : [\\\"F\\\"], \\\"acme.endtime.1\\\" : [\\\"H\\\"], \\\"acme.midpoint.1\\\" : [\\\"O\\\"], \\\"acme.starttime.2\\\" : [\\\"F\\\"], \\\"acme.starts.2\\\" : [\\\"K\\\"], \\\"acme.meets.2\\\" : [\\\"F\\\"], \\\"acme.endtime.2\\\" : [\\\"H\\\"], \\\"acme.midpoint.2\\\" : [\\\"A\\\"], \\\"bigset.duration.1\\\" : [\\\"E\\\",\\\"G\\\"], \\\"bigset.duration+starts.1\\\" : [\\\"X\\\",\\\"O\\\"], \\\"bigset.duration+contained.1\\\" : [\\\"G\\\"], \\\"bigset.starttime+before+endtime+during.1\\\": [\\\"I\\\"], \\\"bigset.ends.1\\\" : [\\\"E\\\"], \\\"bigset.duration.2\\\" : [\\\"E\\\",\\\"G\\\"], \\\"bigset.duration+starts.2\\\" : [\\\"X\\\",\\\"O\\\"], \\\"bigset.duration+contained.2\\\" : [\\\"G\\\"], \\\"bigset.starttime+before+endtime+during.2\\\":[\\\"I\\\"], \\\"bigset.ends.2\\\" : [\\\"E\\\"], \\\"bigset.starttime.1\\\" : [\\\"M\\\",\\\"L\\\"], \\\"bigset.starts.1\\\" : [\\\"G\\\"], \\\"bigset.meets.1\\\" : [\\\"E\\\",\\\"F\\\"], \\\"bigset.endtime.1\\\" : [\\\"X\\\"], \\\"bigset.midpoint.1\\\" : [\\\"K\\\",\\\"X\\\"], \\\"bigset.starttime.2\\\" : [\\\"M\\\",\\\"L\\\"], \\\"bigset.starts.2\\\" : [\\\"G\\\"], \\\"bigset.meets.2\\\" : [\\\"E\\\",\\\"F\\\"], \\\"bigset.endtime.2\\\" : [\\\"X\\\"], \\\"bigset.midpoint.2\\\" : [\\\"K\\\",\\\"X\\\"] } var orthogonal_answers = { \\\"acme.starttime.1\\\" : [\\\"A\\\"], \\\"acme.starts.1\\\" : [\\\"E\\\"], \\\"acme.meets.1\\\" : [\\\"Z\\\"], \\\"acme.endtime.1\\\" : [\\\"U\\\"], \\\"acme.midpoint.1\\\" : [\\\"U\\\"], \\\"acme.starttime.2\\\" : [\\\"0\\\"], \\\"acme.starts.2\\\" : [\\\"0\\\"], \\\"acme.meets.2\\\" : [\\\"0\\\"], \\\"acme.endtime.2\\\" : [\\\"0\\\"], \\\"acme.midpoint.2\\\" : [\\\"0\\\"], \\\"bigset.duration.1\\\" : [\\\"E\\\",\\\"G\\\"], \\\"bigset.duration+starts.1\\\" : [\\\"F\\\",\\\"B\\\"], \\\"bigset.duration+contained.1\\\" : [\\\"E\\\"], \\\"bigset.starttime+before+endtime+during.1\\\": [\\\"I\\\"], \\\"bigset.ends.1\\\" : [\\\"X\\\"], \\\"bigset.duration.2\\\" : [\\\"E\\\",\\\"G\\\"], \\\"bigset.duration+starts.2\\\" : [\\\"F\\\",\\\"B\\\"], \\\"bigset.duration+contained.2\\\" : [\\\"E\\\"], \\\"bigset.starttime+before+endtime+during.2\\\":[\\\"I\\\"], \\\"bigset.ends.2\\\" : [\\\"X\\\"], \\\"bigset.starttime.1\\\" : [\\\"F\\\",\\\"B\\\"], \\\"bigset.starts.1\\\" : [\\\"B\\\"], \\\"bigset.meets.1\\\" : [\\\"F\\\",\\\"X\\\"], \\\"bigset.endtime.1\\\" : [\\\"B\\\"], \\\"bigset.midpoint.1\\\" : [\\\"E\\\",\\\"F\\\"], \\\"bigset.starttime.2\\\" : [\\\"F\\\",\\\"B\\\"], \\\"bigset.starts.2\\\" : [\\\"B\\\"], \\\"bigset.meets.2\\\" : [\\\"F\\\",\\\"X\\\"], \\\"bigset.endtime.2\\\" : [\\\"B\\\"], \\\"bigset.midpoint.2\\\" : [\\\"E\\\",\\\"F\\\"] } //display the question and answer buttons based on input values from jsPsych document.getElementById(scenario+\\\".\\\"+question).style.display = \\\"block\\\"; if (question == \\\"strategy\\\") {document.getElementById(\\\"strategyButton\\\").style.display = \\\"block\\\";} else {document.getElementById(\\\"testingButton\\\").style.display = \\\"block\\\";} //---------SET PROPERTIES OF THE GRAPH -------------// // set the dimensions and margins of the graph var margin = {top: 25, right: 30, bottom: 90, left: 100}, width = 800, height = 800; var intersects = false; //default value for intersects scaffold var xAxisTitle, yAxisTitle; var datafile =\\\"\\\"; // SET AXIS VALUES if (axis == 1){ axis = \\\"Orthogonal-XInside-YFull\\\"; } else if (axis == 2){ axis = \\\"Orthogonal-XInside-YPartial\\\"; } else if (axis ==3){ axis = \\\"Triangular-XInside-YInside\\\"; } else if (axis ==4){ axis = \\\"Orthogonal-XInside-YInside\\\"; } else if (axis ==5){ axis = \\\"Orthogonal-XFull-YFull\\\"; } // SET EXPLICIT SCAFFOLD FEATURES if (explicit ==2 && axis != \\\"diagonal\\\"){ scaffold = 2; intersects = false; } else if (explicit == 2 && axis == \\\"diagonal\\\"){ scaffold = 2; intersects = false; } //TODO: not sure if above two lines are still valid since leaders are now generated on the fly else if (explicit == 3){ $('#hint-interactive').css(\\\"display\\\",\\\"block\\\"); //display textimage scaffold intersects = true; } //SET DATA FILE FOR IMPLICIT SCAFFOLD if (impasse == 1){ datafile = \\\"../views/src/data/acme_nonimpasse.csv\\\"; } else if (impasse == 2){ datafile = \\\"../views/src/data/acme_impasse.csv\\\"; } //OVERRIDE DATA FILE FOR NON-SCAFFOLD QUESTIONS if (q > 5) { //override data file if q# is greater than 5 datafile = \\\"../views/src/data/bigset.csv\\\"; console.log(\\\"override data file\\\"); $('#orthogonal-image').css(\\\"display\\\",\\\"none\\\"); //display textimage scaffold $('#diagonal-image').css(\\\"display\\\",\\\"none\\\"); //display textimage scaffold $('#hint-interactive').css(\\\"display\\\",\\\"none\\\"); //display textimage scaffold intersects = false; } // //---------CREATE THE SVG ------------------------// var svg = d3.select(\\\".d3container\\\").append(\\\"svg\\\") .attr(\\\"width\\\", width + margin.left + margin.right) .attr(\\\"height\\\", height + margin.top + margin.bottom) .append(\\\"g\\\") .attr(\\\"transform\\\", \\\"translate(\\\" + margin.left + \\\",\\\" + margin.top + \\\")\\\"); //---------DRAW THE GRAPH ------------------------// xAxisTitle = \\\"START & END TIME (time of day)\\\"; yAxisTitle = \\\"DURATION (in hours)\\\"; drawTriangleModel(datafile,intersects,axis,scaffold,q); \"},{\"id\":2593},{\"id\":2594},{\"nodeType\":3,\"id\":2597,\"textContent\":\" //MOUSE LOGGING SCRIPT var mouseLog = [] var xwidth = $(document).width(); var xheight = $(document).width(); mouseLog.push(\\\"{x:\\\"+xwidth+\\\",y:\\\"+xheight+\\\",t:\\\"+\\\"0};\\\") document.onmousemove = function(e){ var pageCoords = \\\"{x:\\\" + e.pageX + \\\",y:\\\"+ e.pageY +\\\",t:\\\"+ Date.now()+ \\\"};\\\" ; mouseLog.push(pageCoords); // console.log(pageCoords); }; \"},{\"id\":2595}],[],[],[]]}"
    },
    {
      "sequence": 2,
      "data": "{\"f\":\"applyChanged\",\"args\":[[],[{\"nodeType\":1,\"id\":2598,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-text-preamble\",\"class\":\"jspsych-survey-text-preamble\"},\"parentNode\":{\"id\":55}},{\"nodeType\":1,\"id\":2599,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-text-0\",\"class\":\"jspsych-survey-text-question\"},\"previousSibling\":{\"id\":2598},\"parentNode\":{\"id\":55}},{\"nodeType\":1,\"id\":2600,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-text-1\",\"class\":\"jspsych-survey-text-question\"},\"previousSibling\":{\"id\":2599},\"parentNode\":{\"id\":55}},{\"nodeType\":1,\"id\":2601,\"tagName\":\"BUTTON\",\"attributes\":{\"id\":\"jspsych-survey-text-next\",\"class\":\"jspsych-btn jspsych-survey-text\"},\"previousSibling\":{\"id\":2600},\"parentNode\":{\"id\":55}},{\"nodeType\":1,\"id\":2602,\"tagName\":\"P\",\"attributes\":{\"class\":\"jspsych-survey-text\"},\"parentNode\":{\"id\":2599}},{\"nodeType\":1,\"id\":2603,\"tagName\":\"TEXTAREA\",\"attributes\":{\"name\":\"#jspsych-survey-text-response-0\",\"cols\":\"40\",\"rows\":\"1\"},\"previousSibling\":{\"id\":2602},\"parentNode\":{\"id\":2599}},{\"nodeType\":3,\"id\":2604,\"textContent\":\"What is your age?\",\"parentNode\":{\"id\":2602}},{\"nodeType\":1,\"id\":2605,\"tagName\":\"P\",\"attributes\":{\"class\":\"jspsych-survey-text\"},\"parentNode\":{\"id\":2600}},{\"nodeType\":1,\"id\":2606,\"tagName\":\"TEXTAREA\",\"attributes\":{\"name\":\"#jspsych-survey-text-response-1\",\"cols\":\"40\",\"rows\":\"1\"},\"previousSibling\":{\"id\":2605},\"parentNode\":{\"id\":2600}},{\"nodeType\":3,\"id\":2607,\"textContent\":\"In what country were you born?\",\"parentNode\":{\"id\":2605}},{\"nodeType\":3,\"id\":2608,\"textContent\":\"Submit Answers\",\"parentNode\":{\"id\":2601}}],[],[]]}"
    },
    {
      "sequence": 3,
      "data": "{\"f\":\"applyChanged\",\"args\":[[{\"id\":2598},{\"id\":2599},{\"id\":2602},{\"id\":2604},{\"id\":2603},{\"id\":2600},{\"id\":2605},{\"id\":2607},{\"id\":2606},{\"id\":2601},{\"id\":2608}],[],[],[]]}"
    },
    {
      "sequence": 4,
      "data": "{\"f\":\"applyChanged\",\"args\":[[],[{\"nodeType\":1,\"id\":2609,\"tagName\":\"FORM\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-form\"},\"parentNode\":{\"id\":55}},{\"nodeType\":1,\"id\":2610,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-preamble\",\"class\":\"jspsych-survey-multi-choice-preamble\"},\"parentNode\":{\"id\":2609}},{\"nodeType\":1,\"id\":2611,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-0\",\"class\":\"jspsych-survey-multi-choice-question jspsych-survey-multi-choice-horizontal\"},\"previousSibling\":{\"id\":2610},\"parentNode\":{\"id\":2609}},{\"nodeType\":1,\"id\":2612,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-1\",\"class\":\"jspsych-survey-multi-choice-question jspsych-survey-multi-choice-horizontal\"},\"previousSibling\":{\"id\":2611},\"parentNode\":{\"id\":2609}},{\"nodeType\":1,\"id\":2613,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-2\",\"class\":\"jspsych-survey-multi-choice-question jspsych-survey-multi-choice-horizontal\"},\"previousSibling\":{\"id\":2612},\"parentNode\":{\"id\":2609}},{\"nodeType\":1,\"id\":2614,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-3\",\"class\":\"jspsych-survey-multi-choice-question jspsych-survey-multi-choice-horizontal\"},\"previousSibling\":{\"id\":2613},\"parentNode\":{\"id\":2609}},{\"nodeType\":1,\"id\":2615,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"submit\",\"id\":\"jspsych-survey-multi-choice-next\",\"class\":\"jspsych-survey-multi-choice jspsych-btn\",\"value\":\"Submit Answers\"},\"previousSibling\":{\"id\":2614},\"parentNode\":{\"id\":2609}},{\"nodeType\":1,\"id\":2616,\"tagName\":\"P\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text survey-multi-choice\"},\"parentNode\":{\"id\":2611}},{\"nodeType\":1,\"id\":2617,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-0-0\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2616},\"parentNode\":{\"id\":2611}},{\"nodeType\":1,\"id\":2618,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-0-1\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2617},\"parentNode\":{\"id\":2611}},{\"nodeType\":1,\"id\":2619,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-0-2\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2618},\"parentNode\":{\"id\":2611}},{\"nodeType\":1,\"id\":2620,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-0-3\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2619},\"parentNode\":{\"id\":2611}},{\"nodeType\":3,\"id\":2621,\"textContent\":\"What is your first language?\",\"parentNode\":{\"id\":2616}},{\"nodeType\":1,\"id\":2622,\"tagName\":\"SPAN\",\"attributes\":{\"class\":\"required\"},\"previousSibling\":{\"id\":2621},\"parentNode\":{\"id\":2616}},{\"nodeType\":1,\"id\":2623,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2617}},{\"nodeType\":1,\"id\":2624,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-0\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2623}},{\"nodeType\":3,\"id\":2625,\"textContent\":\"English\",\"previousSibling\":{\"id\":2624},\"parentNode\":{\"id\":2623}},{\"nodeType\":1,\"id\":2626,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2618}},{\"nodeType\":1,\"id\":2627,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-0\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2626}},{\"nodeType\":3,\"id\":2628,\"textContent\":\"Spanish\",\"previousSibling\":{\"id\":2627},\"parentNode\":{\"id\":2626}},{\"nodeType\":1,\"id\":2629,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2619}},{\"nodeType\":1,\"id\":2630,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-0\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2629}},{\"nodeType\":3,\"id\":2631,\"textContent\":\"Mandarin or Cantonese\",\"previousSibling\":{\"id\":2630},\"parentNode\":{\"id\":2629}},{\"nodeType\":1,\"id\":2632,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2620}},{\"nodeType\":1,\"id\":2633,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-0\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2632}},{\"nodeType\":3,\"id\":2634,\"textContent\":\"Other\",\"previousSibling\":{\"id\":2633},\"parentNode\":{\"id\":2632}},{\"nodeType\":3,\"id\":2635,\"textContent\":\"*\",\"parentNode\":{\"id\":2622}},{\"nodeType\":1,\"id\":2636,\"tagName\":\"P\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text survey-multi-choice\"},\"parentNode\":{\"id\":2612}},{\"nodeType\":1,\"id\":2637,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-1-0\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2636},\"parentNode\":{\"id\":2612}},{\"nodeType\":1,\"id\":2638,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-1-1\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2637},\"parentNode\":{\"id\":2612}},{\"nodeType\":1,\"id\":2639,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-1-2\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2638},\"parentNode\":{\"id\":2612}},{\"nodeType\":1,\"id\":2640,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-1-3\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2639},\"parentNode\":{\"id\":2612}},{\"nodeType\":1,\"id\":2641,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-1-4\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2640},\"parentNode\":{\"id\":2612}},{\"nodeType\":1,\"id\":2642,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-1-5\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2641},\"parentNode\":{\"id\":2612}},{\"nodeType\":1,\"id\":2643,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-1-6\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2642},\"parentNode\":{\"id\":2612}},{\"nodeType\":3,\"id\":2644,\"textContent\":\"What is your year in school?\",\"parentNode\":{\"id\":2636}},{\"nodeType\":1,\"id\":2645,\"tagName\":\"SPAN\",\"attributes\":{\"class\":\"required\"},\"previousSibling\":{\"id\":2644},\"parentNode\":{\"id\":2636}},{\"nodeType\":1,\"id\":2646,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2637}},{\"nodeType\":1,\"id\":2647,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-1\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2646}},{\"nodeType\":3,\"id\":2648,\"textContent\":\"First\",\"previousSibling\":{\"id\":2647},\"parentNode\":{\"id\":2646}},{\"nodeType\":1,\"id\":2649,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2638}},{\"nodeType\":1,\"id\":2650,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-1\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2649}},{\"nodeType\":3,\"id\":2651,\"textContent\":\"Second\",\"previousSibling\":{\"id\":2650},\"parentNode\":{\"id\":2649}},{\"nodeType\":1,\"id\":2652,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2639}},{\"nodeType\":1,\"id\":2653,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-1\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2652}},{\"nodeType\":3,\"id\":2654,\"textContent\":\"Third\",\"previousSibling\":{\"id\":2653},\"parentNode\":{\"id\":2652}},{\"nodeType\":1,\"id\":2655,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2640}},{\"nodeType\":1,\"id\":2656,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-1\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2655}},{\"nodeType\":3,\"id\":2657,\"textContent\":\"Fourth\",\"previousSibling\":{\"id\":2656},\"parentNode\":{\"id\":2655}},{\"nodeType\":1,\"id\":2658,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2641}},{\"nodeType\":1,\"id\":2659,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-1\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2658}},{\"nodeType\":3,\"id\":2660,\"textContent\":\"Fifth\",\"previousSibling\":{\"id\":2659},\"parentNode\":{\"id\":2658}},{\"nodeType\":1,\"id\":2661,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2642}},{\"nodeType\":1,\"id\":2662,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-1\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2661}},{\"nodeType\":3,\"id\":2663,\"textContent\":\"Graduate\",\"previousSibling\":{\"id\":2662},\"parentNode\":{\"id\":2661}},{\"nodeType\":1,\"id\":2664,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2643}},{\"nodeType\":1,\"id\":2665,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-1\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2664}},{\"nodeType\":3,\"id\":2666,\"textContent\":\"Other\",\"previousSibling\":{\"id\":2665},\"parentNode\":{\"id\":2664}},{\"nodeType\":3,\"id\":2667,\"textContent\":\"*\",\"parentNode\":{\"id\":2645}},{\"nodeType\":1,\"id\":2668,\"tagName\":\"P\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text survey-multi-choice\"},\"parentNode\":{\"id\":2613}},{\"nodeType\":1,\"id\":2669,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-2-0\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2668},\"parentNode\":{\"id\":2613}},{\"nodeType\":1,\"id\":2670,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-2-1\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2669},\"parentNode\":{\"id\":2613}},{\"nodeType\":1,\"id\":2671,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-2-2\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2670},\"parentNode\":{\"id\":2613}},{\"nodeType\":1,\"id\":2672,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-2-3\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2671},\"parentNode\":{\"id\":2613}},{\"nodeType\":1,\"id\":2673,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-2-4\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2672},\"parentNode\":{\"id\":2613}},{\"nodeType\":1,\"id\":2674,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-2-5\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2673},\"parentNode\":{\"id\":2613}},{\"nodeType\":1,\"id\":2675,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-2-6\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2674},\"parentNode\":{\"id\":2613}},{\"nodeType\":3,\"id\":2676,\"textContent\":\"What is your major area of study?\",\"parentNode\":{\"id\":2668}},{\"nodeType\":1,\"id\":2677,\"tagName\":\"SPAN\",\"attributes\":{\"class\":\"required\"},\"previousSibling\":{\"id\":2676},\"parentNode\":{\"id\":2668}},{\"nodeType\":1,\"id\":2678,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2669}},{\"nodeType\":1,\"id\":2679,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-2\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2678}},{\"nodeType\":3,\"id\":2680,\"textContent\":\"Math or Computer Sciences\",\"previousSibling\":{\"id\":2679},\"parentNode\":{\"id\":2678}},{\"nodeType\":1,\"id\":2681,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2670}},{\"nodeType\":1,\"id\":2682,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-2\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2681}},{\"nodeType\":3,\"id\":2683,\"textContent\":\"Social Sciences (incl. CogSci)\",\"previousSibling\":{\"id\":2682},\"parentNode\":{\"id\":2681}},{\"nodeType\":1,\"id\":2684,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2671}},{\"nodeType\":1,\"id\":2685,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-2\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2684}},{\"nodeType\":3,\"id\":2686,\"textContent\":\"Biomedical & Health Sciences\",\"previousSibling\":{\"id\":2685},\"parentNode\":{\"id\":2684}},{\"nodeType\":1,\"id\":2687,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2672}},{\"nodeType\":1,\"id\":2688,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-2\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2687}},{\"nodeType\":3,\"id\":2689,\"textContent\":\"Natural Sciences\",\"previousSibling\":{\"id\":2688},\"parentNode\":{\"id\":2687}},{\"nodeType\":1,\"id\":2690,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2673}},{\"nodeType\":1,\"id\":2691,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-2\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2690}},{\"nodeType\":3,\"id\":2692,\"textContent\":\"Engineering\",\"previousSibling\":{\"id\":2691},\"parentNode\":{\"id\":2690}},{\"nodeType\":1,\"id\":2693,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2674}},{\"nodeType\":1,\"id\":2694,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-2\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2693}},{\"nodeType\":3,\"id\":2695,\"textContent\":\"Humanities\",\"previousSibling\":{\"id\":2694},\"parentNode\":{\"id\":2693}},{\"nodeType\":1,\"id\":2696,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2675}},{\"nodeType\":1,\"id\":2697,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-2\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2696}},{\"nodeType\":3,\"id\":2698,\"textContent\":\"Fine Arts\",\"previousSibling\":{\"id\":2697},\"parentNode\":{\"id\":2696}},{\"nodeType\":3,\"id\":2699,\"textContent\":\"*\",\"parentNode\":{\"id\":2677}},{\"nodeType\":1,\"id\":2700,\"tagName\":\"P\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text survey-multi-choice\"},\"parentNode\":{\"id\":2614}},{\"nodeType\":1,\"id\":2701,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-3-0\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2700},\"parentNode\":{\"id\":2614}},{\"nodeType\":1,\"id\":2702,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-3-1\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2701},\"parentNode\":{\"id\":2614}},{\"nodeType\":1,\"id\":2703,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-3-2\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2702},\"parentNode\":{\"id\":2614}},{\"nodeType\":3,\"id\":2704,\"textContent\":\"What is your gender?\",\"parentNode\":{\"id\":2700}},{\"nodeType\":1,\"id\":2705,\"tagName\":\"SPAN\",\"attributes\":{\"class\":\"required\"},\"previousSibling\":{\"id\":2704},\"parentNode\":{\"id\":2700}},{\"nodeType\":1,\"id\":2706,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2701}},{\"nodeType\":1,\"id\":2707,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-3\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2706}},{\"nodeType\":3,\"id\":2708,\"textContent\":\"Male\",\"previousSibling\":{\"id\":2707},\"parentNode\":{\"id\":2706}},{\"nodeType\":1,\"id\":2709,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2702}},{\"nodeType\":1,\"id\":2710,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-3\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2709}},{\"nodeType\":3,\"id\":2711,\"textContent\":\"Female\",\"previousSibling\":{\"id\":2710},\"parentNode\":{\"id\":2709}},{\"nodeType\":1,\"id\":2712,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2703}},{\"nodeType\":1,\"id\":2713,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-3\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2712}},{\"nodeType\":3,\"id\":2714,\"textContent\":\"Other\",\"previousSibling\":{\"id\":2713},\"parentNode\":{\"id\":2712}},{\"nodeType\":3,\"id\":2715,\"textContent\":\"*\",\"parentNode\":{\"id\":2705}}],[],[]]}"
    },
    {
      "sequence": 5,
      "data": "{\"f\":\"applyChanged\",\"args\":[[{\"id\":2609},{\"id\":2610},{\"id\":2611},{\"id\":2616},{\"id\":2621},{\"id\":2622},{\"id\":2635},{\"id\":2617},{\"id\":2623},{\"id\":2624},{\"id\":2625},{\"id\":2618},{\"id\":2626},{\"id\":2627},{\"id\":2628},{\"id\":2619},{\"id\":2629},{\"id\":2630},{\"id\":2631},{\"id\":2620},{\"id\":2632},{\"id\":2633},{\"id\":2634},{\"id\":2612},{\"id\":2636},{\"id\":2644},{\"id\":2645},{\"id\":2667},{\"id\":2637},{\"id\":2646},{\"id\":2647},{\"id\":2648},{\"id\":2638},{\"id\":2649},{\"id\":2650},{\"id\":2651},{\"id\":2639},{\"id\":2652},{\"id\":2653},{\"id\":2654},{\"id\":2640},{\"id\":2655},{\"id\":2656},{\"id\":2657},{\"id\":2641},{\"id\":2658},{\"id\":2659},{\"id\":2660},{\"id\":2642},{\"id\":2661},{\"id\":2662},{\"id\":2663},{\"id\":2643},{\"id\":2664},{\"id\":2665},{\"id\":2666},{\"id\":2613},{\"id\":2668},{\"id\":2676},{\"id\":2677},{\"id\":2699},{\"id\":2669},{\"id\":2678},{\"id\":2679},{\"id\":2680},{\"id\":2670},{\"id\":2681},{\"id\":2682},{\"id\":2683},{\"id\":2671},{\"id\":2684},{\"id\":2685},{\"id\":2686},{\"id\":2672},{\"id\":2687},{\"id\":2688},{\"id\":2689},{\"id\":2673},{\"id\":2690},{\"id\":2691},{\"id\":2692},{\"id\":2674},{\"id\":2693},{\"id\":2694},{\"id\":2695},{\"id\":2675},{\"id\":2696},{\"id\":2697},{\"id\":2698},{\"id\":2614},{\"id\":2700},{\"id\":2704},{\"id\":2705},{\"id\":2715},{\"id\":2701},{\"id\":2706},{\"id\":2707},{\"id\":2708},{\"id\":2702},{\"id\":2709},{\"id\":2710},{\"id\":2711},{\"id\":2703},{\"id\":2712},{\"id\":2713},{\"id\":2714},{\"id\":2615}],[],[],[]]}"
    },
    {
      "sequence": 6,
      "data": "{\"f\":\"applyChanged\",\"args\":[[],[{\"nodeType\":1,\"id\":2716,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"masterdiv\"},\"parentNode\":{\"id\":55}},{\"nodeType\":3,\"id\":2717,\"textContent\":\" \",\"previousSibling\":{\"id\":2716},\"parentNode\":{\"id\":55}},{\"nodeType\":3,\"id\":2718,\"textContent\":\" \",\"parentNode\":{\"id\":2716}},{\"nodeType\":1,\"id\":2719,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"top\"},\"previousSibling\":{\"id\":2718},\"parentNode\":{\"id\":2716}},{\"nodeType\":3,\"id\":2720,\"textContent\":\" \",\"previousSibling\":{\"id\":2719},\"parentNode\":{\"id\":2716}},{\"nodeType\":1,\"id\":2721,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"instructions\"},\"previousSibling\":{\"id\":2720},\"parentNode\":{\"id\":2716}},{\"nodeType\":3,\"id\":2722,\"textContent\":\" \",\"previousSibling\":{\"id\":2721},\"parentNode\":{\"id\":2716}},{\"nodeType\":1,\"id\":2723,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bottom\"},\"previousSibling\":{\"id\":2722},\"parentNode\":{\"id\":2716}},{\"nodeType\":3,\"id\":2724,\"textContent\":\" \",\"previousSibling\":{\"id\":2723},\"parentNode\":{\"id\":2716}},{\"nodeType\":3,\"id\":2725,\"textContent\":\" \",\"parentNode\":{\"id\":2719}},{\"nodeType\":1,\"id\":2726,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bcent\"},\"previousSibling\":{\"id\":2725},\"parentNode\":{\"id\":2719}},{\"nodeType\":3,\"id\":2727,\"textContent\":\" \",\"previousSibling\":{\"id\":2726},\"parentNode\":{\"id\":2719}},{\"nodeType\":3,\"id\":2728,\"textContent\":\" \",\"parentNode\":{\"id\":2726}},{\"nodeType\":1,\"id\":2729,\"tagName\":\"H3\",\"attributes\":{},\"previousSibling\":{\"id\":2728},\"parentNode\":{\"id\":2726}},{\"nodeType\":3,\"id\":2730,\"textContent\":\" \",\"previousSibling\":{\"id\":2729},\"parentNode\":{\"id\":2726}},{\"nodeType\":3,\"id\":2731,\"textContent\":\"DEBRIEFING\",\"parentNode\":{\"id\":2729}},{\"nodeType\":3,\"id\":2732,\"textContent\":\" \",\"parentNode\":{\"id\":2721}},{\"nodeType\":1,\"id\":2733,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"vcent\"},\"previousSibling\":{\"id\":2732},\"parentNode\":{\"id\":2721}},{\"nodeType\":3,\"id\":2734,\"textContent\":\" \",\"previousSibling\":{\"id\":2733},\"parentNode\":{\"id\":2721}},{\"nodeType\":3,\"id\":2735,\"textContent\":\" \",\"parentNode\":{\"id\":2733}},{\"nodeType\":1,\"id\":2736,\"tagName\":\"P\",\"attributes\":{\"style\":\"font-style:italic\"},\"previousSibling\":{\"id\":2735},\"parentNode\":{\"id\":2733}},{\"nodeType\":1,\"id\":2737,\"tagName\":\"P\",\"attributes\":{},\"previousSibling\":{\"id\":2736},\"parentNode\":{\"id\":2733}},{\"nodeType\":3,\"id\":2738,\"textContent\":\" \",\"previousSibling\":{\"id\":2737},\"parentNode\":{\"id\":2733}},{\"nodeType\":1,\"id\":2739,\"tagName\":\"P\",\"attributes\":{},\"previousSibling\":{\"id\":2738},\"parentNode\":{\"id\":2733}},{\"nodeType\":3,\"id\":2740,\"textContent\":\" \",\"previousSibling\":{\"id\":2739},\"parentNode\":{\"id\":2733}},{\"nodeType\":1,\"id\":2741,\"tagName\":\"P\",\"attributes\":{},\"previousSibling\":{\"id\":2740},\"parentNode\":{\"id\":2733}},{\"nodeType\":3,\"id\":2742,\"textContent\":\" \",\"previousSibling\":{\"id\":2741},\"parentNode\":{\"id\":2733}},{\"nodeType\":1,\"id\":2743,\"tagName\":\"P\",\"attributes\":{\"style\":\"font-style:bold;\"},\"previousSibling\":{\"id\":2742},\"parentNode\":{\"id\":2733}},{\"nodeType\":3,\"id\":2744,\"textContent\":\" \",\"previousSibling\":{\"id\":2743},\"parentNode\":{\"id\":2733}},{\"nodeType\":1,\"id\":2745,\"tagName\":\"P\",\"attributes\":{\"style\":\"font-style:italic;\"},\"previousSibling\":{\"id\":2744},\"parentNode\":{\"id\":2733}},{\"nodeType\":3,\"id\":2746,\"textContent\":\" \",\"previousSibling\":{\"id\":2745},\"parentNode\":{\"id\":2733}},{\"nodeType\":3,\"id\":2747,\"textContent\":\"Thank you very much for your participation! This debriefing will tell you more about the study, what you did, and why. \",\"parentNode\":{\"id\":2736}},{\"nodeType\":3,\"id\":2748,\"textContent\":\" \",\"parentNode\":{\"id\":2737}},{\"nodeType\":1,\"id\":2749,\"tagName\":\"B\",\"attributes\":{},\"previousSibling\":{\"id\":2748},\"parentNode\":{\"id\":2737}},{\"nodeType\":3,\"id\":2750,\"textContent\":\" You have just used a series of pictures (charts, graphs and diagrams) accompanied by different types of instructions to answer a series of problem solving questions. While you were using the pictures, we measured where you clicked, scrolled and pointed with the computer mouse. We also measured the accuracy of your responses and the time it took to complete each question.\",\"previousSibling\":{\"id\":2749},\"parentNode\":{\"id\":2737}},{\"nodeType\":3,\"id\":2751,\"textContent\":\"What did you just do?\",\"parentNode\":{\"id\":2749}},{\"nodeType\":3,\"id\":2752,\"textContent\":\" \",\"parentNode\":{\"id\":2739}},{\"nodeType\":1,\"id\":2753,\"tagName\":\"B\",\"attributes\":{},\"previousSibling\":{\"id\":2752},\"parentNode\":{\"id\":2739}},{\"nodeType\":3,\"id\":2754,\"textContent\":\" Researchers of learning and cognition have long been interested in how graphic displays of information can be used to communicate, solve problems, and generate insights. As powerful as graphics may be in their communicative efficiency, they're not always immediately intuitive to understand. In short, we know a great deal more about learning with representations than we do about the learning of representations. In this project we are building upon previous research on reading and graph comprehension to explore how readers make sense of unfamiliar representations. The instructions you saw for each type of graph are known as “scaffolding techniques”, and we will compare your performance with the scaffolding techniques you saw with the performance of other participants to determine which types of instructions are most effective in helping humans to make sense of unfamiliar graphs. \",\"previousSibling\":{\"id\":2753},\"parentNode\":{\"id\":2739}},{\"nodeType\":3,\"id\":2755,\"textContent\":\"Why did we have you do it?\",\"parentNode\":{\"id\":2753}},{\"nodeType\":1,\"id\":2756,\"tagName\":\"B\",\"attributes\":{},\"parentNode\":{\"id\":2741}},{\"nodeType\":3,\"id\":2757,\"textContent\":\" We expect that you will have found some of the graphics more difficult to use than others. We also expect that with the assistance of the instructions, after solving several problems you will learn to use the difficult graphics so that you can answer the questions even more quickly than without. If you would like to receive a copy of the results of the study, or have any further questions, please contact the researchers Primary Researcher: Amy Fox : a2fox@ucsd.edu Faculty Advisor : Dr. Jim Hollan : hollan@ucsd.edu \",\"previousSibling\":{\"id\":2756},\"parentNode\":{\"id\":2741}},{\"nodeType\":3,\"id\":2758,\"textContent\":\"What do we expect to find?\",\"parentNode\":{\"id\":2756}},{\"nodeType\":3,\"id\":2759,\"textContent\":\"It is important that you do not discuss this experiment with other students who might participate after you. They must participate in the same way as you did, without any knowledge of what the experiment entails, or the reasoning behind it.\",\"parentNode\":{\"id\":2743}},{\"nodeType\":3,\"id\":2760,\"textContent\":\"Thank you for your time! We hope you enjoyed participating in this study as much as we enjoyed designing it.\",\"parentNode\":{\"id\":2745}},{\"nodeType\":3,\"id\":2761,\"textContent\":\" \",\"parentNode\":{\"id\":2723}},{\"nodeType\":1,\"id\":2762,\"tagName\":\"BUTTON\",\"attributes\":{\"class\":\"btn\",\"type\":\"button\",\"id\":\"start\"},\"previousSibling\":{\"id\":2761},\"parentNode\":{\"id\":2723}},{\"nodeType\":3,\"id\":2763,\"textContent\":\" \",\"previousSibling\":{\"id\":2762},\"parentNode\":{\"id\":2723}},{\"nodeType\":3,\"id\":2764,\"textContent\":\"FINISH\",\"parentNode\":{\"id\":2762}}],[],[]]}"
    },
    {
      "sequence": 7,
      "data": "{\"f\":\"applyChanged\",\"args\":[[{\"id\":2716},{\"id\":2718},{\"id\":2719},{\"id\":2725},{\"id\":2726},{\"id\":2728},{\"id\":2729},{\"id\":2731},{\"id\":2730},{\"id\":2727},{\"id\":2720},{\"id\":2721},{\"id\":2732},{\"id\":2733},{\"id\":2735},{\"id\":2736},{\"id\":2747},{\"id\":2737},{\"id\":2748},{\"id\":2749},{\"id\":2751},{\"id\":2750},{\"id\":2738},{\"id\":2739},{\"id\":2752},{\"id\":2753},{\"id\":2755},{\"id\":2754},{\"id\":2740},{\"id\":2741},{\"id\":2756},{\"id\":2758},{\"id\":2757},{\"id\":2742},{\"id\":2743},{\"id\":2759},{\"id\":2744},{\"id\":2745},{\"id\":2760},{\"id\":2746},{\"id\":2734},{\"id\":2722},{\"id\":2723},{\"id\":2761},{\"id\":2762},{\"id\":2764},{\"id\":2763},{\"id\":2724},{\"id\":2717}],[],[],[]]}"
    },
    {
      "sequence": 8,
      "data": "{\"f\":\"applyChanged\",\"args\":[[],[{\"nodeType\":1,\"id\":2765,\"tagName\":\"PRE\",\"attributes\":{\"id\":\"jspsych-data-display\"},\"parentNode\":{\"id\":55}},{\"nodeType\":3,\"id\":2766,\"textContent\":\"[ { \\\"rt\\\": 124300, \\\"stimulus\\\": \\\"img/phone.png\\\", \\\"key_press\\\": 13, \\\"block\\\": \\\"phone\\\", \\\"trial_type\\\": \\\"single-stim\\\", \\\"trial_index\\\": 0, \\\"time_elapsed\\\": 124305, \\\"internal_node_id\\\": \\\"0.0-0.0\\\", \\\"subject\\\": \\\"HW2SN\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"xray\\\", \\\"condition\\\": \\\"311\\\" }, { \\\"rt\\\": 11756, \\\"url\\\": \\\"../views/src/external/consent.html\\\", \\\"block\\\": \\\"consent\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 1, \\\"time_elapsed\\\": 137401, \\\"internal_node_id\\\": \\\"0.0-1.0\\\", \\\"subject\\\": \\\"HW2SN\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"xray\\\", \\\"condition\\\": \\\"311\\\" }, { \\\"rt\\\": 7069, \\\"responses\\\": \\\"{\\\\\\\"Q0\\\\\\\":\\\\\\\"XRAY\\\\\\\",\\\\\\\"Q1\\\\\\\":\\\\\\\"311\\\\\\\"}\\\", \\\"block\\\": \\\"codes\\\", \\\"trial_type\\\": \\\"survey-text\\\", \\\"trial_index\\\": 2, \\\"time_elapsed\\\": 145477, \\\"internal_node_id\\\": \\\"0.0-2.0\\\", \\\"subject\\\": \\\"HW2SN\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"xray\\\", \\\"condition\\\": \\\"311\\\" }, { \\\"rt\\\": 14459, \\\"url\\\": \\\"../views/src/external/instructions_lab.html\\\", \\\"block\\\": \\\"instructions_lab\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 3, \\\"time_elapsed\\\": 161027, \\\"internal_node_id\\\": \\\"0.0-3.0\\\", \\\"subject\\\": \\\"HW2SN\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"xray\\\", \\\"condition\\\": \\\"311\\\" }, { \\\"rt\\\": 8342, \\\"stimulus\\\": \\\"img/acme.png\\\", \\\"key_press\\\": 13, \\\"block\\\": \\\"scenario\\\", \\\"trial_type\\\": \\\"single-stim\\\", \\\"trial_index\\\": 4, \\\"time_elapsed\\\": 170373, \\\"internal_node_id\\\": \\\"0.0-4.0\\\", \\\"subject\\\": \\\"HW2SN\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"xray\\\", \\\"condition\\\": \\\"311\\\" }, { \\\"rt\\\": 46091, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 5, \\\"time_elapsed\\\": 217830, \\\"internal_node_id\\\": \\\"0.0-5.0-0.0\\\", \\\"subject\\\": \\\"HW2SN\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"xray\\\", \\\"condition\\\": \\\"311\\\", \\\"scenario\\\": \\\"acme\\\", \\\"question\\\": \\\"starttime\\\", \\\"q\\\": 1, \\\"clicks\\\": 2, \\\"explicit\\\": 3, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XInside-YFull\\\", \\\"correct\\\": 1, \\\"orth_correct\\\": 0, \\\"answer\\\": [ \\\"F\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"X \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"U \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-1-11 AM-A -Z -Z -Z -Z -F -F -F -C -C -C -A -A -A -O -O -K -U -U -U -G -F \\\", \\\"block\\\": \\\"triangular_scaffolded\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:1005,y:1022,t:1527876566519};\\\", \\\"{x:1008,y:1021,t:1527876566535};\\\", \\\"{x:1007,y:1019,t:1527876566973};\\\", \\\"{x:1008,y:1019,t:1527876567469};\\\", \\\"{x:1009,y:1019,t:1527876567486};\\\", \\\"{x:1010,y:1019,t:1527876567502};\\\", \\\"{x:1012,y:1019,t:1527876567519};\\\", \\\"{x:1016,y:1019,t:1527876567536};\\\", \\\"{x:1019,y:1017,t:1527876567552};\\\", \\\"{x:1023,y:1010,t:1527876567569};\\\", \\\"{x:1030,y:1001,t:1527876567586};\\\", \\\"{x:1034,y:991,t:1527876567603};\\\", \\\"{x:1038,y:979,t:1527876567620};\\\", \\\"{x:1040,y:972,t:1527876567636};\\\", \\\"{x:1041,y:964,t:1527876567653};\\\", \\\"{x:1042,y:950,t:1527876567669};\\\", \\\"{x:1042,y:942,t:1527876567686};\\\", \\\"{x:1042,y:934,t:1527876567702};\\\", \\\"{x:1042,y:925,t:1527876567719};\\\", \\\"{x:1044,y:917,t:1527876567736};\\\", \\\"{x:1045,y:910,t:1527876567753};\\\", \\\"{x:1048,y:904,t:1527876567769};\\\", \\\"{x:1048,y:902,t:1527876567786};\\\", \\\"{x:1048,y:900,t:1527876567803};\\\", \\\"{x:1049,y:897,t:1527876567819};\\\", \\\"{x:1050,y:895,t:1527876567840};\\\", \\\"{x:1052,y:893,t:1527876567856};\\\", \\\"{x:1053,y:893,t:1527876567881};\\\", \\\"{x:1058,y:893,t:1527876567897};\\\", \\\"{x:1060,y:893,t:1527876567907};\\\", \\\"{x:1074,y:895,t:1527876567924};\\\", \\\"{x:1095,y:901,t:1527876567941};\\\", \\\"{x:1118,y:909,t:1527876567957};\\\", \\\"{x:1149,y:918,t:1527876567973};\\\", \\\"{x:1182,y:927,t:1527876567991};\\\", \\\"{x:1223,y:935,t:1527876568007};\\\", \\\"{x:1253,y:940,t:1527876568023};\\\", \\\"{x:1281,y:941,t:1527876568040};\\\", \\\"{x:1309,y:941,t:1527876568057};\\\", \\\"{x:1322,y:941,t:1527876568073};\\\", \\\"{x:1332,y:943,t:1527876568090};\\\", \\\"{x:1341,y:944,t:1527876568107};\\\", \\\"{x:1347,y:944,t:1527876568125};\\\", \\\"{x:1346,y:945,t:1527876568248};\\\", \\\"{x:1344,y:946,t:1527876568256};\\\", \\\"{x:1337,y:948,t:1527876568274};\\\", \\\"{x:1332,y:950,t:1527876568289};\\\", \\\"{x:1324,y:954,t:1527876568306};\\\", \\\"{x:1314,y:960,t:1527876568324};\\\", \\\"{x:1305,y:963,t:1527876568340};\\\", \\\"{x:1302,y:963,t:1527876568356};\\\", \\\"{x:1300,y:963,t:1527876568373};\\\", \\\"{x:1299,y:963,t:1527876568389};\\\", \\\"{x:1298,y:964,t:1527876568407};\\\", \\\"{x:1297,y:965,t:1527876568423};\\\", \\\"{x:1296,y:965,t:1527876568440};\\\", \\\"{x:1295,y:966,t:1527876568457};\\\", \\\"{x:1290,y:969,t:1527876568474};\\\", \\\"{x:1285,y:972,t:1527876568490};\\\", \\\"{x:1280,y:973,t:1527876568507};\\\", \\\"{x:1273,y:976,t:1527876568524};\\\", \\\"{x:1270,y:977,t:1527876568540};\\\", \\\"{x:1269,y:977,t:1527876568557};\\\", \\\"{x:1267,y:977,t:1527876568592};\\\", \\\"{x:1267,y:978,t:1527876568607};\\\", \\\"{x:1266,y:978,t:1527876568664};\\\", \\\"{x:1266,y:977,t:1527876568673};\\\", \\\"{x:1265,y:974,t:1527876568690};\\\", \\\"{x:1265,y:973,t:1527876568706};\\\", \\\"{x:1265,y:971,t:1527876568723};\\\", \\\"{x:1265,y:968,t:1527876568741};\\\", \\\"{x:1265,y:967,t:1527876568756};\\\", \\\"{x:1265,y:965,t:1527876568776};\\\", \\\"{x:1266,y:965,t:1527876568801};\\\", \\\"{x:1267,y:965,t:1527876568825};\\\", \\\"{x:1269,y:965,t:1527876568840};\\\", \\\"{x:1270,y:965,t:1527876568975};\\\", \\\"{x:1271,y:965,t:1527876569016};\\\", \\\"{x:1272,y:965,t:1527876569024};\\\", \\\"{x:1273,y:965,t:1527876569040};\\\", \\\"{x:1274,y:965,t:1527876569057};\\\", \\\"{x:1275,y:965,t:1527876569073};\\\", \\\"{x:1276,y:965,t:1527876569104};\\\", \\\"{x:1277,y:964,t:1527876570224};\\\", \\\"{x:1277,y:961,t:1527876570242};\\\", \\\"{x:1277,y:957,t:1527876570257};\\\", \\\"{x:1277,y:950,t:1527876570274};\\\", \\\"{x:1277,y:941,t:1527876570291};\\\", \\\"{x:1275,y:935,t:1527876570308};\\\", \\\"{x:1273,y:927,t:1527876570324};\\\", \\\"{x:1273,y:922,t:1527876570343};\\\", \\\"{x:1273,y:916,t:1527876570357};\\\", \\\"{x:1273,y:909,t:1527876570375};\\\", \\\"{x:1273,y:905,t:1527876570392};\\\", \\\"{x:1273,y:899,t:1527876570408};\\\", \\\"{x:1273,y:895,t:1527876570425};\\\", \\\"{x:1273,y:894,t:1527876570441};\\\", \\\"{x:1273,y:891,t:1527876570457};\\\", \\\"{x:1273,y:888,t:1527876570475};\\\", \\\"{x:1273,y:885,t:1527876570492};\\\", \\\"{x:1273,y:881,t:1527876570508};\\\", \\\"{x:1273,y:878,t:1527876570524};\\\", \\\"{x:1273,y:874,t:1527876570542};\\\", \\\"{x:1273,y:868,t:1527876570559};\\\", \\\"{x:1273,y:858,t:1527876570575};\\\", \\\"{x:1273,y:853,t:1527876570592};\\\", \\\"{x:1273,y:847,t:1527876570608};\\\", \\\"{x:1273,y:842,t:1527876570625};\\\", \\\"{x:1273,y:841,t:1527876570642};\\\", \\\"{x:1273,y:839,t:1527876570659};\\\", \\\"{x:1273,y:838,t:1527876570697};\\\", \\\"{x:1273,y:837,t:1527876570713};\\\", \\\"{x:1273,y:836,t:1527876570777};\\\", \\\"{x:1275,y:836,t:1527876570809};\\\", \\\"{x:1275,y:835,t:1527876571097};\\\", \\\"{x:1275,y:834,t:1527876571109};\\\", \\\"{x:1277,y:832,t:1527876571135};\\\", \\\"{x:1278,y:827,t:1527876571159};\\\", \\\"{x:1280,y:826,t:1527876571175};\\\", \\\"{x:1280,y:825,t:1527876571577};\\\", \\\"{x:1282,y:825,t:1527876576009};\\\", \\\"{x:1294,y:838,t:1527876576021};\\\", \\\"{x:1311,y:856,t:1527876576030};\\\", \\\"{x:1344,y:890,t:1527876576047};\\\", \\\"{x:1369,y:908,t:1527876576063};\\\", \\\"{x:1392,y:919,t:1527876576080};\\\", \\\"{x:1398,y:920,t:1527876576097};\\\", \\\"{x:1400,y:920,t:1527876576113};\\\", \\\"{x:1401,y:921,t:1527876576129};\\\", \\\"{x:1398,y:921,t:1527876576249};\\\", \\\"{x:1396,y:921,t:1527876576264};\\\", \\\"{x:1386,y:919,t:1527876576280};\\\", \\\"{x:1376,y:919,t:1527876576297};\\\", \\\"{x:1368,y:919,t:1527876576315};\\\", \\\"{x:1367,y:919,t:1527876576330};\\\", \\\"{x:1365,y:918,t:1527876576352};\\\", \\\"{x:1365,y:917,t:1527876576377};\\\", \\\"{x:1365,y:916,t:1527876576385};\\\", \\\"{x:1365,y:915,t:1527876576449};\\\", \\\"{x:1364,y:909,t:1527876576465};\\\", \\\"{x:1363,y:904,t:1527876576481};\\\", \\\"{x:1360,y:901,t:1527876576498};\\\", \\\"{x:1357,y:897,t:1527876576514};\\\", \\\"{x:1356,y:896,t:1527876576530};\\\", \\\"{x:1356,y:895,t:1527876576553};\\\", \\\"{x:1355,y:895,t:1527876576569};\\\", \\\"{x:1354,y:894,t:1527876576857};\\\", \\\"{x:1353,y:893,t:1527876576873};\\\", \\\"{x:1353,y:892,t:1527876576905};\\\", \\\"{x:1353,y:891,t:1527876577298};\\\", \\\"{x:1349,y:892,t:1527876577320};\\\", \\\"{x:1344,y:896,t:1527876577330};\\\", \\\"{x:1335,y:902,t:1527876577348};\\\", \\\"{x:1327,y:905,t:1527876577364};\\\", \\\"{x:1321,y:908,t:1527876577381};\\\", \\\"{x:1321,y:907,t:1527876577536};\\\", \\\"{x:1321,y:906,t:1527876577548};\\\", \\\"{x:1324,y:905,t:1527876577563};\\\", \\\"{x:1327,y:904,t:1527876577581};\\\", \\\"{x:1331,y:901,t:1527876577598};\\\", \\\"{x:1335,y:900,t:1527876577615};\\\", \\\"{x:1337,y:898,t:1527876577631};\\\", \\\"{x:1342,y:896,t:1527876577650};\\\", \\\"{x:1343,y:894,t:1527876578745};\\\", \\\"{x:1346,y:884,t:1527876578754};\\\", \\\"{x:1349,y:873,t:1527876578765};\\\", \\\"{x:1352,y:860,t:1527876578782};\\\", \\\"{x:1357,y:848,t:1527876578799};\\\", \\\"{x:1359,y:839,t:1527876578815};\\\", \\\"{x:1364,y:823,t:1527876578832};\\\", \\\"{x:1367,y:818,t:1527876578849};\\\", \\\"{x:1368,y:813,t:1527876578865};\\\", \\\"{x:1370,y:807,t:1527876578882};\\\", \\\"{x:1371,y:801,t:1527876578899};\\\", \\\"{x:1371,y:799,t:1527876578916};\\\", \\\"{x:1372,y:795,t:1527876578932};\\\", \\\"{x:1372,y:793,t:1527876578949};\\\", \\\"{x:1374,y:791,t:1527876578966};\\\", \\\"{x:1374,y:790,t:1527876578991};\\\", \\\"{x:1374,y:789,t:1527876579008};\\\", \\\"{x:1375,y:788,t:1527876579016};\\\", \\\"{x:1375,y:787,t:1527876579032};\\\", \\\"{x:1376,y:782,t:1527876579048};\\\", \\\"{x:1379,y:774,t:1527876579065};\\\", \\\"{x:1382,y:764,t:1527876579084};\\\", \\\"{x:1383,y:758,t:1527876579098};\\\", \\\"{x:1385,y:752,t:1527876579117};\\\", \\\"{x:1386,y:749,t:1527876579132};\\\", \\\"{x:1386,y:748,t:1527876579148};\\\", \\\"{x:1386,y:746,t:1527876579473};\\\", \\\"{x:1386,y:742,t:1527876579484};\\\", \\\"{x:1389,y:738,t:1527876579499};\\\", \\\"{x:1389,y:736,t:1527876579516};\\\", \\\"{x:1389,y:735,t:1527876579534};\\\", \\\"{x:1387,y:735,t:1527876579706};\\\", \\\"{x:1386,y:736,t:1527876579716};\\\", \\\"{x:1383,y:740,t:1527876579733};\\\", \\\"{x:1380,y:745,t:1527876579750};\\\", \\\"{x:1378,y:749,t:1527876579766};\\\", \\\"{x:1377,y:750,t:1527876579783};\\\", \\\"{x:1377,y:751,t:1527876579801};\\\", \\\"{x:1375,y:753,t:1527876579817};\\\", \\\"{x:1375,y:754,t:1527876579897};\\\", \\\"{x:1374,y:755,t:1527876579905};\\\", \\\"{x:1373,y:757,t:1527876579917};\\\", \\\"{x:1373,y:758,t:1527876579937};\\\", \\\"{x:1373,y:759,t:1527876580105};\\\", \\\"{x:1374,y:760,t:1527876580116};\\\", \\\"{x:1377,y:761,t:1527876580137};\\\", \\\"{x:1381,y:762,t:1527876580149};\\\", \\\"{x:1382,y:763,t:1527876580166};\\\", \\\"{x:1382,y:764,t:1527876584008};\\\", \\\"{x:1381,y:764,t:1527876586160};\\\", \\\"{x:1380,y:764,t:1527876586170};\\\", \\\"{x:1379,y:766,t:1527876589289};\\\", \\\"{x:1375,y:767,t:1527876589298};\\\", \\\"{x:1369,y:769,t:1527876589308};\\\", \\\"{x:1349,y:772,t:1527876589324};\\\", \\\"{x:1334,y:772,t:1527876589340};\\\", \\\"{x:1318,y:772,t:1527876589356};\\\", \\\"{x:1288,y:772,t:1527876589373};\\\", \\\"{x:1235,y:772,t:1527876589390};\\\", \\\"{x:1171,y:772,t:1527876589406};\\\", \\\"{x:1035,y:772,t:1527876589423};\\\", \\\"{x:949,y:772,t:1527876589440};\\\", \\\"{x:879,y:772,t:1527876589456};\\\", \\\"{x:829,y:772,t:1527876589473};\\\", \\\"{x:793,y:772,t:1527876589490};\\\", \\\"{x:774,y:772,t:1527876589506};\\\", \\\"{x:762,y:772,t:1527876589523};\\\", \\\"{x:760,y:772,t:1527876589540};\\\", \\\"{x:759,y:772,t:1527876589556};\\\", \\\"{x:756,y:772,t:1527876589573};\\\", \\\"{x:749,y:771,t:1527876589590};\\\", \\\"{x:734,y:768,t:1527876589607};\\\", \\\"{x:698,y:764,t:1527876589623};\\\", \\\"{x:673,y:760,t:1527876589640};\\\", \\\"{x:647,y:756,t:1527876589657};\\\", \\\"{x:624,y:753,t:1527876589673};\\\", \\\"{x:600,y:746,t:1527876589691};\\\", \\\"{x:581,y:734,t:1527876589708};\\\", \\\"{x:564,y:720,t:1527876589724};\\\", \\\"{x:549,y:705,t:1527876589740};\\\", \\\"{x:536,y:688,t:1527876589757};\\\", \\\"{x:527,y:674,t:1527876589774};\\\", \\\"{x:518,y:662,t:1527876589790};\\\", \\\"{x:509,y:640,t:1527876589807};\\\", \\\"{x:503,y:626,t:1527876589824};\\\", \\\"{x:497,y:617,t:1527876589842};\\\", \\\"{x:492,y:607,t:1527876589857};\\\", \\\"{x:488,y:602,t:1527876589873};\\\", \\\"{x:484,y:596,t:1527876589890};\\\", \\\"{x:480,y:591,t:1527876589906};\\\", \\\"{x:474,y:586,t:1527876589924};\\\", \\\"{x:465,y:582,t:1527876589941};\\\", \\\"{x:456,y:581,t:1527876589957};\\\", \\\"{x:445,y:579,t:1527876589975};\\\", \\\"{x:432,y:579,t:1527876589991};\\\", \\\"{x:420,y:579,t:1527876590007};\\\", \\\"{x:398,y:579,t:1527876590024};\\\", \\\"{x:386,y:579,t:1527876590041};\\\", \\\"{x:377,y:579,t:1527876590058};\\\", \\\"{x:369,y:581,t:1527876590075};\\\", \\\"{x:368,y:582,t:1527876590091};\\\", \\\"{x:367,y:582,t:1527876590167};\\\", \\\"{x:365,y:583,t:1527876590192};\\\", \\\"{x:365,y:584,t:1527876590208};\\\", \\\"{x:364,y:585,t:1527876590224};\\\", \\\"{x:363,y:587,t:1527876590241};\\\", \\\"{x:362,y:589,t:1527876590258};\\\", \\\"{x:362,y:590,t:1527876590274};\\\", \\\"{x:362,y:591,t:1527876590291};\\\", \\\"{x:362,y:592,t:1527876590308};\\\", \\\"{x:363,y:593,t:1527876590335};\\\", \\\"{x:364,y:594,t:1527876590367};\\\", \\\"{x:365,y:594,t:1527876590376};\\\", \\\"{x:366,y:594,t:1527876590391};\\\", \\\"{x:368,y:596,t:1527876591089};\\\", \\\"{x:370,y:596,t:1527876591104};\\\", \\\"{x:372,y:597,t:1527876591120};\\\", \\\"{x:374,y:598,t:1527876591592};\\\", \\\"{x:380,y:600,t:1527876591610};\\\", \\\"{x:388,y:602,t:1527876591625};\\\", \\\"{x:407,y:608,t:1527876591642};\\\", \\\"{x:441,y:610,t:1527876591659};\\\", \\\"{x:485,y:613,t:1527876591675};\\\", \\\"{x:524,y:613,t:1527876591692};\\\", \\\"{x:551,y:613,t:1527876591709};\\\", \\\"{x:565,y:613,t:1527876591725};\\\", \\\"{x:569,y:613,t:1527876591742};\\\", \\\"{x:570,y:613,t:1527876591759};\\\", \\\"{x:569,y:613,t:1527876591847};\\\", \\\"{x:566,y:613,t:1527876591859};\\\", \\\"{x:553,y:608,t:1527876591877};\\\", \\\"{x:536,y:603,t:1527876591892};\\\", \\\"{x:518,y:601,t:1527876591910};\\\", \\\"{x:499,y:601,t:1527876591926};\\\", \\\"{x:482,y:601,t:1527876591945};\\\", \\\"{x:462,y:601,t:1527876591959};\\\", \\\"{x:451,y:601,t:1527876591975};\\\", \\\"{x:445,y:601,t:1527876591992};\\\", \\\"{x:443,y:601,t:1527876592009};\\\", \\\"{x:441,y:600,t:1527876592088};\\\", \\\"{x:439,y:600,t:1527876592103};\\\", \\\"{x:437,y:600,t:1527876592119};\\\", \\\"{x:436,y:600,t:1527876592128};\\\", \\\"{x:435,y:600,t:1527876592142};\\\", \\\"{x:433,y:600,t:1527876592159};\\\", \\\"{x:430,y:599,t:1527876592175};\\\", \\\"{x:427,y:599,t:1527876592192};\\\", \\\"{x:423,y:599,t:1527876592209};\\\", \\\"{x:419,y:599,t:1527876592226};\\\", \\\"{x:418,y:599,t:1527876592242};\\\", \\\"{x:417,y:599,t:1527876592259};\\\", \\\"{x:416,y:599,t:1527876592277};\\\", \\\"{x:420,y:601,t:1527876592794};\\\", \\\"{x:494,y:634,t:1527876592810};\\\", \\\"{x:629,y:669,t:1527876592827};\\\", \\\"{x:803,y:721,t:1527876592844};\\\", \\\"{x:977,y:743,t:1527876592860};\\\", \\\"{x:1138,y:765,t:1527876592876};\\\", \\\"{x:1243,y:767,t:1527876592893};\\\", \\\"{x:1307,y:767,t:1527876592910};\\\", \\\"{x:1334,y:767,t:1527876592927};\\\", \\\"{x:1333,y:767,t:1527876593016};\\\", \\\"{x:1330,y:766,t:1527876593026};\\\", \\\"{x:1316,y:759,t:1527876593043};\\\", \\\"{x:1297,y:756,t:1527876593061};\\\", \\\"{x:1287,y:756,t:1527876593076};\\\", \\\"{x:1273,y:756,t:1527876593094};\\\", \\\"{x:1256,y:762,t:1527876593110};\\\", \\\"{x:1243,y:768,t:1527876593127};\\\", \\\"{x:1236,y:775,t:1527876593143};\\\", \\\"{x:1235,y:778,t:1527876593160};\\\", \\\"{x:1233,y:784,t:1527876593176};\\\", \\\"{x:1232,y:787,t:1527876593194};\\\", \\\"{x:1231,y:791,t:1527876593211};\\\", \\\"{x:1231,y:793,t:1527876593227};\\\", \\\"{x:1229,y:796,t:1527876593243};\\\", \\\"{x:1226,y:801,t:1527876593261};\\\", \\\"{x:1223,y:804,t:1527876593277};\\\", \\\"{x:1221,y:808,t:1527876593293};\\\", \\\"{x:1220,y:809,t:1527876593311};\\\", \\\"{x:1220,y:811,t:1527876593328};\\\", \\\"{x:1221,y:813,t:1527876593343};\\\", \\\"{x:1221,y:815,t:1527876593360};\\\", \\\"{x:1222,y:818,t:1527876593377};\\\", \\\"{x:1222,y:819,t:1527876593400};\\\", \\\"{x:1222,y:820,t:1527876593424};\\\", \\\"{x:1222,y:821,t:1527876593448};\\\", \\\"{x:1222,y:823,t:1527876593481};\\\", \\\"{x:1222,y:824,t:1527876593494};\\\", \\\"{x:1221,y:825,t:1527876593510};\\\", \\\"{x:1218,y:828,t:1527876593530};\\\", \\\"{x:1217,y:829,t:1527876593543};\\\", \\\"{x:1214,y:831,t:1527876593561};\\\", \\\"{x:1209,y:834,t:1527876593578};\\\", \\\"{x:1208,y:835,t:1527876593594};\\\", \\\"{x:1207,y:835,t:1527876593679};\\\", \\\"{x:1205,y:835,t:1527876593696};\\\", \\\"{x:1204,y:835,t:1527876593752};\\\", \\\"{x:1203,y:834,t:1527876593841};\\\", \\\"{x:1203,y:833,t:1527876593857};\\\", \\\"{x:1203,y:832,t:1527876593871};\\\", \\\"{x:1203,y:831,t:1527876594057};\\\", \\\"{x:1204,y:831,t:1527876594097};\\\", \\\"{x:1209,y:831,t:1527876594115};\\\", \\\"{x:1215,y:835,t:1527876594127};\\\", \\\"{x:1220,y:838,t:1527876594162};\\\", \\\"{x:1219,y:838,t:1527876594296};\\\", \\\"{x:1217,y:838,t:1527876594311};\\\", \\\"{x:1216,y:838,t:1527876594328};\\\", \\\"{x:1216,y:837,t:1527876594345};\\\", \\\"{x:1214,y:835,t:1527876594364};\\\", \\\"{x:1213,y:834,t:1527876594377};\\\", \\\"{x:1212,y:832,t:1527876594394};\\\", \\\"{x:1211,y:831,t:1527876594411};\\\", \\\"{x:1211,y:829,t:1527876597144};\\\", \\\"{x:1212,y:828,t:1527876597152};\\\", \\\"{x:1215,y:828,t:1527876597164};\\\", \\\"{x:1221,y:828,t:1527876597183};\\\", \\\"{x:1224,y:828,t:1527876597196};\\\", \\\"{x:1227,y:828,t:1527876597213};\\\", \\\"{x:1228,y:828,t:1527876597609};\\\", \\\"{x:1231,y:828,t:1527876597616};\\\", \\\"{x:1234,y:828,t:1527876597630};\\\", \\\"{x:1239,y:828,t:1527876597648};\\\", \\\"{x:1242,y:828,t:1527876597664};\\\", \\\"{x:1243,y:828,t:1527876597785};\\\", \\\"{x:1244,y:828,t:1527876597798};\\\", \\\"{x:1245,y:828,t:1527876597814};\\\", \\\"{x:1247,y:828,t:1527876597832};\\\", \\\"{x:1253,y:828,t:1527876597848};\\\", \\\"{x:1260,y:828,t:1527876597865};\\\", \\\"{x:1268,y:828,t:1527876597881};\\\", \\\"{x:1278,y:828,t:1527876597902};\\\", \\\"{x:1286,y:828,t:1527876597914};\\\", \\\"{x:1293,y:828,t:1527876597931};\\\", \\\"{x:1296,y:828,t:1527876597948};\\\", \\\"{x:1297,y:828,t:1527876597963};\\\", \\\"{x:1298,y:828,t:1527876598152};\\\", \\\"{x:1298,y:829,t:1527876598168};\\\", \\\"{x:1296,y:830,t:1527876598185};\\\", \\\"{x:1294,y:830,t:1527876598198};\\\", \\\"{x:1288,y:831,t:1527876598216};\\\", \\\"{x:1283,y:831,t:1527876598236};\\\", \\\"{x:1279,y:831,t:1527876598247};\\\", \\\"{x:1278,y:831,t:1527876598271};\\\", \\\"{x:1279,y:829,t:1527876598743};\\\", \\\"{x:1279,y:828,t:1527876598759};\\\", \\\"{x:1279,y:826,t:1527876599000};\\\", \\\"{x:1280,y:822,t:1527876599019};\\\", \\\"{x:1283,y:813,t:1527876599033};\\\", \\\"{x:1285,y:802,t:1527876599049};\\\", \\\"{x:1286,y:795,t:1527876599065};\\\", \\\"{x:1288,y:790,t:1527876599082};\\\", \\\"{x:1288,y:787,t:1527876599256};\\\", \\\"{x:1288,y:783,t:1527876599265};\\\", \\\"{x:1288,y:773,t:1527876599282};\\\", \\\"{x:1288,y:755,t:1527876599299};\\\", \\\"{x:1289,y:739,t:1527876599315};\\\", \\\"{x:1292,y:722,t:1527876599332};\\\", \\\"{x:1294,y:706,t:1527876599350};\\\", \\\"{x:1297,y:691,t:1527876599366};\\\", \\\"{x:1298,y:684,t:1527876599382};\\\", \\\"{x:1299,y:677,t:1527876599399};\\\", \\\"{x:1299,y:671,t:1527876599416};\\\", \\\"{x:1300,y:665,t:1527876599432};\\\", \\\"{x:1301,y:664,t:1527876599449};\\\", \\\"{x:1301,y:662,t:1527876599466};\\\", \\\"{x:1301,y:661,t:1527876599482};\\\", \\\"{x:1301,y:659,t:1527876599499};\\\", \\\"{x:1301,y:658,t:1527876599516};\\\", \\\"{x:1301,y:656,t:1527876599536};\\\", \\\"{x:1302,y:656,t:1527876599548};\\\", \\\"{x:1302,y:655,t:1527876599565};\\\", \\\"{x:1303,y:653,t:1527876599582};\\\", \\\"{x:1303,y:652,t:1527876599598};\\\", \\\"{x:1304,y:650,t:1527876599655};\\\", \\\"{x:1306,y:648,t:1527876599665};\\\", \\\"{x:1307,y:644,t:1527876599682};\\\", \\\"{x:1308,y:642,t:1527876599698};\\\", \\\"{x:1311,y:638,t:1527876599715};\\\", \\\"{x:1312,y:635,t:1527876599735};\\\", \\\"{x:1312,y:634,t:1527876599749};\\\", \\\"{x:1313,y:632,t:1527876599765};\\\", \\\"{x:1313,y:631,t:1527876599791};\\\", \\\"{x:1314,y:631,t:1527876599799};\\\", \\\"{x:1314,y:630,t:1527876599816};\\\", \\\"{x:1314,y:628,t:1527876599833};\\\", \\\"{x:1315,y:625,t:1527876599855};\\\", \\\"{x:1317,y:624,t:1527876600608};\\\", \\\"{x:1321,y:621,t:1527876600616};\\\", \\\"{x:1328,y:617,t:1527876600633};\\\", \\\"{x:1332,y:615,t:1527876600649};\\\", \\\"{x:1340,y:610,t:1527876600667};\\\", \\\"{x:1347,y:606,t:1527876600682};\\\", \\\"{x:1350,y:605,t:1527876600700};\\\", \\\"{x:1351,y:603,t:1527876600716};\\\", \\\"{x:1352,y:603,t:1527876600732};\\\", \\\"{x:1353,y:603,t:1527876600749};\\\", \\\"{x:1354,y:602,t:1527876600767};\\\", \\\"{x:1355,y:601,t:1527876600793};\\\", \\\"{x:1356,y:600,t:1527876600799};\\\", \\\"{x:1358,y:599,t:1527876600816};\\\", \\\"{x:1361,y:596,t:1527876600832};\\\", \\\"{x:1364,y:593,t:1527876600850};\\\", \\\"{x:1366,y:592,t:1527876600867};\\\", \\\"{x:1368,y:590,t:1527876600883};\\\", \\\"{x:1372,y:588,t:1527876600899};\\\", \\\"{x:1376,y:585,t:1527876600916};\\\", \\\"{x:1380,y:583,t:1527876600932};\\\", \\\"{x:1386,y:582,t:1527876600950};\\\", \\\"{x:1389,y:580,t:1527876600966};\\\", \\\"{x:1390,y:580,t:1527876600982};\\\", \\\"{x:1391,y:579,t:1527876600999};\\\", \\\"{x:1396,y:578,t:1527876601017};\\\", \\\"{x:1401,y:578,t:1527876601033};\\\", \\\"{x:1408,y:578,t:1527876601050};\\\", \\\"{x:1416,y:578,t:1527876601067};\\\", \\\"{x:1423,y:578,t:1527876601084};\\\", \\\"{x:1430,y:578,t:1527876601100};\\\", \\\"{x:1439,y:581,t:1527876601117};\\\", \\\"{x:1444,y:585,t:1527876601134};\\\", \\\"{x:1446,y:586,t:1527876601149};\\\", \\\"{x:1448,y:586,t:1527876601167};\\\", \\\"{x:1449,y:586,t:1527876601184};\\\", \\\"{x:1451,y:587,t:1527876601200};\\\", \\\"{x:1452,y:587,t:1527876601216};\\\", \\\"{x:1456,y:587,t:1527876601234};\\\", \\\"{x:1458,y:587,t:1527876601250};\\\", \\\"{x:1462,y:587,t:1527876601267};\\\", \\\"{x:1466,y:587,t:1527876601284};\\\", \\\"{x:1473,y:583,t:1527876601300};\\\", \\\"{x:1490,y:577,t:1527876601317};\\\", \\\"{x:1508,y:566,t:1527876601334};\\\", \\\"{x:1523,y:554,t:1527876601350};\\\", \\\"{x:1536,y:542,t:1527876601367};\\\", \\\"{x:1550,y:526,t:1527876601384};\\\", \\\"{x:1557,y:518,t:1527876601400};\\\", \\\"{x:1559,y:513,t:1527876601417};\\\", \\\"{x:1562,y:507,t:1527876601434};\\\", \\\"{x:1563,y:501,t:1527876601451};\\\", \\\"{x:1564,y:498,t:1527876601467};\\\", \\\"{x:1564,y:491,t:1527876601484};\\\", \\\"{x:1567,y:481,t:1527876601500};\\\", \\\"{x:1568,y:472,t:1527876601517};\\\", \\\"{x:1568,y:466,t:1527876601535};\\\", \\\"{x:1568,y:462,t:1527876601551};\\\", \\\"{x:1568,y:461,t:1527876601567};\\\", \\\"{x:1568,y:467,t:1527876601633};\\\", \\\"{x:1568,y:475,t:1527876601640};\\\", \\\"{x:1568,y:486,t:1527876601650};\\\", \\\"{x:1568,y:505,t:1527876601666};\\\", \\\"{x:1568,y:515,t:1527876601683};\\\", \\\"{x:1568,y:523,t:1527876601701};\\\", \\\"{x:1568,y:533,t:1527876601717};\\\", \\\"{x:1568,y:548,t:1527876601734};\\\", \\\"{x:1566,y:563,t:1527876601750};\\\", \\\"{x:1565,y:573,t:1527876601767};\\\", \\\"{x:1557,y:586,t:1527876601783};\\\", \\\"{x:1552,y:595,t:1527876601800};\\\", \\\"{x:1547,y:605,t:1527876601817};\\\", \\\"{x:1543,y:610,t:1527876601834};\\\", \\\"{x:1542,y:613,t:1527876601851};\\\", \\\"{x:1540,y:616,t:1527876601867};\\\", \\\"{x:1538,y:619,t:1527876601884};\\\", \\\"{x:1536,y:621,t:1527876601901};\\\", \\\"{x:1534,y:624,t:1527876601917};\\\", \\\"{x:1531,y:627,t:1527876601933};\\\", \\\"{x:1530,y:628,t:1527876601951};\\\", \\\"{x:1529,y:629,t:1527876601968};\\\", \\\"{x:1527,y:631,t:1527876601984};\\\", \\\"{x:1524,y:632,t:1527876602001};\\\", \\\"{x:1523,y:632,t:1527876602024};\\\", \\\"{x:1522,y:632,t:1527876602057};\\\", \\\"{x:1521,y:632,t:1527876602068};\\\", \\\"{x:1519,y:632,t:1527876602086};\\\", \\\"{x:1518,y:632,t:1527876602100};\\\", \\\"{x:1516,y:632,t:1527876602118};\\\", \\\"{x:1514,y:631,t:1527876602133};\\\", \\\"{x:1511,y:630,t:1527876602150};\\\", \\\"{x:1510,y:629,t:1527876602167};\\\", \\\"{x:1510,y:630,t:1527876602713};\\\", \\\"{x:1510,y:638,t:1527876602734};\\\", \\\"{x:1509,y:646,t:1527876602751};\\\", \\\"{x:1508,y:666,t:1527876602768};\\\", \\\"{x:1506,y:682,t:1527876602784};\\\", \\\"{x:1504,y:703,t:1527876602800};\\\", \\\"{x:1501,y:723,t:1527876602817};\\\", \\\"{x:1499,y:738,t:1527876602835};\\\", \\\"{x:1497,y:744,t:1527876602852};\\\", \\\"{x:1496,y:751,t:1527876602867};\\\", \\\"{x:1495,y:755,t:1527876602885};\\\", \\\"{x:1495,y:756,t:1527876602901};\\\", \\\"{x:1495,y:758,t:1527876602918};\\\", \\\"{x:1495,y:759,t:1527876602952};\\\", \\\"{x:1495,y:763,t:1527876602967};\\\", \\\"{x:1495,y:769,t:1527876602984};\\\", \\\"{x:1495,y:773,t:1527876603002};\\\", \\\"{x:1494,y:780,t:1527876603018};\\\", \\\"{x:1494,y:786,t:1527876603035};\\\", \\\"{x:1492,y:796,t:1527876603052};\\\", \\\"{x:1490,y:807,t:1527876603067};\\\", \\\"{x:1486,y:814,t:1527876603085};\\\", \\\"{x:1483,y:820,t:1527876603102};\\\", \\\"{x:1482,y:824,t:1527876603118};\\\", \\\"{x:1480,y:825,t:1527876603138};\\\", \\\"{x:1480,y:827,t:1527876603152};\\\", \\\"{x:1480,y:828,t:1527876603191};\\\", \\\"{x:1480,y:830,t:1527876603248};\\\", \\\"{x:1480,y:832,t:1527876603263};\\\", \\\"{x:1480,y:834,t:1527876603271};\\\", \\\"{x:1479,y:835,t:1527876603285};\\\", \\\"{x:1476,y:841,t:1527876603319};\\\", \\\"{x:1475,y:841,t:1527876603334};\\\", \\\"{x:1476,y:841,t:1527876603512};\\\", \\\"{x:1476,y:839,t:1527876603528};\\\", \\\"{x:1477,y:837,t:1527876603536};\\\", \\\"{x:1478,y:834,t:1527876603555};\\\", \\\"{x:1479,y:834,t:1527876603568};\\\", \\\"{x:1480,y:833,t:1527876603719};\\\", \\\"{x:1482,y:833,t:1527876603735};\\\", \\\"{x:1486,y:831,t:1527876603751};\\\", \\\"{x:1494,y:830,t:1527876603770};\\\", \\\"{x:1503,y:827,t:1527876603786};\\\", \\\"{x:1518,y:822,t:1527876603801};\\\", \\\"{x:1531,y:817,t:1527876603819};\\\", \\\"{x:1544,y:812,t:1527876603835};\\\", \\\"{x:1555,y:805,t:1527876603852};\\\", \\\"{x:1568,y:800,t:1527876603868};\\\", \\\"{x:1579,y:794,t:1527876603886};\\\", \\\"{x:1590,y:790,t:1527876603902};\\\", \\\"{x:1597,y:786,t:1527876603919};\\\", \\\"{x:1605,y:783,t:1527876603935};\\\", \\\"{x:1608,y:781,t:1527876603952};\\\", \\\"{x:1612,y:781,t:1527876603969};\\\", \\\"{x:1614,y:781,t:1527876603986};\\\", \\\"{x:1616,y:779,t:1527876604002};\\\", \\\"{x:1621,y:778,t:1527876604019};\\\", \\\"{x:1623,y:778,t:1527876604036};\\\", \\\"{x:1625,y:778,t:1527876604052};\\\", \\\"{x:1628,y:777,t:1527876604069};\\\", \\\"{x:1633,y:776,t:1527876604086};\\\", \\\"{x:1637,y:776,t:1527876604102};\\\", \\\"{x:1641,y:775,t:1527876604119};\\\", \\\"{x:1646,y:774,t:1527876604136};\\\", \\\"{x:1651,y:772,t:1527876604153};\\\", \\\"{x:1655,y:770,t:1527876604169};\\\", \\\"{x:1658,y:767,t:1527876604186};\\\", \\\"{x:1659,y:767,t:1527876604287};\\\", \\\"{x:1659,y:766,t:1527876604302};\\\", \\\"{x:1659,y:764,t:1527876604318};\\\", \\\"{x:1659,y:761,t:1527876604335};\\\", \\\"{x:1659,y:759,t:1527876604353};\\\", \\\"{x:1657,y:758,t:1527876604375};\\\", \\\"{x:1656,y:758,t:1527876604399};\\\", \\\"{x:1654,y:758,t:1527876604681};\\\", \\\"{x:1650,y:758,t:1527876604692};\\\", \\\"{x:1645,y:758,t:1527876604702};\\\", \\\"{x:1586,y:762,t:1527876604735};\\\", \\\"{x:1534,y:762,t:1527876604752};\\\", \\\"{x:1469,y:765,t:1527876604769};\\\", \\\"{x:1382,y:765,t:1527876604787};\\\", \\\"{x:1194,y:765,t:1527876604819};\\\", \\\"{x:1094,y:765,t:1527876604835};\\\", \\\"{x:1013,y:765,t:1527876604852};\\\", \\\"{x:938,y:765,t:1527876604870};\\\", \\\"{x:907,y:765,t:1527876604886};\\\", \\\"{x:885,y:765,t:1527876604903};\\\", \\\"{x:871,y:765,t:1527876604919};\\\", \\\"{x:868,y:765,t:1527876604935};\\\", \\\"{x:864,y:767,t:1527876604952};\\\", \\\"{x:859,y:769,t:1527876604970};\\\", \\\"{x:853,y:771,t:1527876604985};\\\", \\\"{x:846,y:771,t:1527876605003};\\\", \\\"{x:838,y:771,t:1527876605020};\\\", \\\"{x:825,y:771,t:1527876605037};\\\", \\\"{x:812,y:771,t:1527876605053};\\\", \\\"{x:793,y:771,t:1527876605070};\\\", \\\"{x:767,y:771,t:1527876605087};\\\", \\\"{x:735,y:771,t:1527876605103};\\\", \\\"{x:682,y:771,t:1527876605119};\\\", \\\"{x:645,y:771,t:1527876605136};\\\", \\\"{x:612,y:771,t:1527876605152};\\\", \\\"{x:587,y:774,t:1527876605170};\\\", \\\"{x:577,y:775,t:1527876605187};\\\", \\\"{x:575,y:776,t:1527876605203};\\\", \\\"{x:573,y:776,t:1527876605231};\\\", \\\"{x:571,y:776,t:1527876605239};\\\", \\\"{x:569,y:778,t:1527876605255};\\\", \\\"{x:566,y:778,t:1527876605271};\\\", \\\"{x:565,y:778,t:1527876605287};\\\", \\\"{x:560,y:778,t:1527876605303};\\\", \\\"{x:556,y:778,t:1527876605320};\\\", \\\"{x:554,y:778,t:1527876605337};\\\", \\\"{x:551,y:778,t:1527876605353};\\\", \\\"{x:545,y:778,t:1527876605370};\\\", \\\"{x:540,y:778,t:1527876605387};\\\", \\\"{x:531,y:772,t:1527876605403};\\\", \\\"{x:523,y:767,t:1527876605422};\\\", \\\"{x:513,y:760,t:1527876605437};\\\", \\\"{x:506,y:753,t:1527876605453};\\\", \\\"{x:502,y:749,t:1527876605470};\\\", \\\"{x:501,y:748,t:1527876605487};\\\" ] }, { \\\"rt\\\": 9820, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 6, \\\"time_elapsed\\\": 228885, \\\"internal_node_id\\\": \\\"0.0-5.0-1.0\\\", \\\"subject\\\": \\\"HW2SN\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"xray\\\", \\\"condition\\\": \\\"311\\\", \\\"scenario\\\": \\\"acme\\\", \\\"question\\\": \\\"starts\\\", \\\"q\\\": 2, \\\"clicks\\\": 1, \\\"explicit\\\": 3, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XInside-YFull\\\", \\\"correct\\\": 1, \\\"orth_correct\\\": 0, \\\"answer\\\": [ \\\"K\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"X \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"U \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-F -F -D -K \\\", \\\"block\\\": \\\"triangular_scaffolded\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:501,y:745,t:1527876608472};\\\", \\\"{x:501,y:731,t:1527876608482};\\\", \\\"{x:501,y:730,t:1527876608488};\\\", \\\"{x:503,y:728,t:1527876608928};\\\", \\\"{x:504,y:728,t:1527876608940};\\\", \\\"{x:506,y:727,t:1527876608956};\\\", \\\"{x:508,y:727,t:1527876608972};\\\", \\\"{x:513,y:725,t:1527876608990};\\\", \\\"{x:520,y:724,t:1527876609006};\\\", \\\"{x:533,y:723,t:1527876609023};\\\", \\\"{x:538,y:722,t:1527876609040};\\\", \\\"{x:545,y:720,t:1527876609056};\\\", \\\"{x:550,y:719,t:1527876609073};\\\", \\\"{x:557,y:716,t:1527876609090};\\\", \\\"{x:567,y:711,t:1527876609106};\\\", \\\"{x:577,y:706,t:1527876609123};\\\", \\\"{x:590,y:702,t:1527876609140};\\\", \\\"{x:606,y:697,t:1527876609156};\\\", \\\"{x:632,y:689,t:1527876609173};\\\", \\\"{x:660,y:682,t:1527876609192};\\\", \\\"{x:697,y:671,t:1527876609206};\\\", \\\"{x:760,y:662,t:1527876609223};\\\", \\\"{x:772,y:659,t:1527876609240};\\\", \\\"{x:772,y:660,t:1527876609496};\\\", \\\"{x:773,y:661,t:1527876609552};\\\", \\\"{x:778,y:662,t:1527876609559};\\\", \\\"{x:784,y:663,t:1527876609573};\\\", \\\"{x:799,y:668,t:1527876609590};\\\", \\\"{x:829,y:679,t:1527876609607};\\\", \\\"{x:842,y:684,t:1527876609623};\\\", \\\"{x:875,y:694,t:1527876609640};\\\", \\\"{x:896,y:699,t:1527876609657};\\\", \\\"{x:917,y:705,t:1527876609674};\\\", \\\"{x:935,y:707,t:1527876609690};\\\", \\\"{x:955,y:710,t:1527876609707};\\\", \\\"{x:971,y:712,t:1527876609723};\\\", \\\"{x:991,y:717,t:1527876609741};\\\", \\\"{x:1008,y:719,t:1527876609757};\\\", \\\"{x:1021,y:721,t:1527876609774};\\\", \\\"{x:1039,y:724,t:1527876609790};\\\", \\\"{x:1073,y:729,t:1527876609808};\\\", \\\"{x:1099,y:732,t:1527876609824};\\\", \\\"{x:1122,y:732,t:1527876609841};\\\", \\\"{x:1149,y:732,t:1527876609857};\\\", \\\"{x:1178,y:732,t:1527876609875};\\\", \\\"{x:1207,y:732,t:1527876609891};\\\", \\\"{x:1235,y:732,t:1527876609908};\\\", \\\"{x:1258,y:726,t:1527876609925};\\\", \\\"{x:1285,y:719,t:1527876609940};\\\", \\\"{x:1306,y:711,t:1527876609958};\\\", \\\"{x:1327,y:702,t:1527876609974};\\\", \\\"{x:1338,y:698,t:1527876609990};\\\", \\\"{x:1347,y:691,t:1527876610007};\\\", \\\"{x:1350,y:688,t:1527876610024};\\\", \\\"{x:1350,y:687,t:1527876610040};\\\", \\\"{x:1352,y:685,t:1527876610057};\\\", \\\"{x:1352,y:684,t:1527876610080};\\\", \\\"{x:1352,y:682,t:1527876610090};\\\", \\\"{x:1352,y:681,t:1527876610107};\\\", \\\"{x:1353,y:680,t:1527876610124};\\\", \\\"{x:1359,y:680,t:1527876610832};\\\", \\\"{x:1370,y:680,t:1527876610841};\\\", \\\"{x:1401,y:682,t:1527876610858};\\\", \\\"{x:1436,y:685,t:1527876610874};\\\", \\\"{x:1462,y:687,t:1527876610891};\\\", \\\"{x:1483,y:687,t:1527876610908};\\\", \\\"{x:1492,y:687,t:1527876610924};\\\", \\\"{x:1494,y:687,t:1527876610941};\\\", \\\"{x:1495,y:687,t:1527876611137};\\\", \\\"{x:1495,y:688,t:1527876611144};\\\", \\\"{x:1495,y:691,t:1527876611159};\\\", \\\"{x:1495,y:693,t:1527876611175};\\\", \\\"{x:1495,y:694,t:1527876611191};\\\", \\\"{x:1493,y:696,t:1527876611528};\\\", \\\"{x:1491,y:699,t:1527876611542};\\\", \\\"{x:1476,y:709,t:1527876611558};\\\", \\\"{x:1444,y:733,t:1527876611576};\\\", \\\"{x:1422,y:746,t:1527876611592};\\\", \\\"{x:1403,y:755,t:1527876611609};\\\", \\\"{x:1389,y:759,t:1527876611625};\\\", \\\"{x:1380,y:763,t:1527876611650};\\\", \\\"{x:1376,y:764,t:1527876611658};\\\", \\\"{x:1376,y:763,t:1527876611984};\\\", \\\"{x:1376,y:759,t:1527876611995};\\\", \\\"{x:1377,y:751,t:1527876612009};\\\", \\\"{x:1379,y:742,t:1527876612025};\\\", \\\"{x:1383,y:733,t:1527876612042};\\\", \\\"{x:1386,y:722,t:1527876612059};\\\", \\\"{x:1391,y:707,t:1527876612074};\\\", \\\"{x:1398,y:686,t:1527876612091};\\\", \\\"{x:1406,y:662,t:1527876612109};\\\", \\\"{x:1415,y:639,t:1527876612125};\\\", \\\"{x:1422,y:614,t:1527876612142};\\\", \\\"{x:1430,y:592,t:1527876612158};\\\", \\\"{x:1432,y:587,t:1527876612175};\\\", \\\"{x:1432,y:585,t:1527876612192};\\\", \\\"{x:1433,y:584,t:1527876612215};\\\", \\\"{x:1434,y:583,t:1527876612224};\\\", \\\"{x:1435,y:582,t:1527876612242};\\\", \\\"{x:1438,y:578,t:1527876612495};\\\", \\\"{x:1443,y:573,t:1527876612508};\\\", \\\"{x:1483,y:556,t:1527876612525};\\\", \\\"{x:1525,y:535,t:1527876612542};\\\", \\\"{x:1554,y:522,t:1527876612558};\\\", \\\"{x:1560,y:518,t:1527876612576};\\\", \\\"{x:1563,y:515,t:1527876612591};\\\", \\\"{x:1565,y:511,t:1527876612608};\\\", \\\"{x:1569,y:501,t:1527876612626};\\\", \\\"{x:1572,y:492,t:1527876612641};\\\", \\\"{x:1578,y:480,t:1527876612659};\\\", \\\"{x:1584,y:470,t:1527876612675};\\\", \\\"{x:1585,y:467,t:1527876612691};\\\", \\\"{x:1587,y:465,t:1527876612709};\\\", \\\"{x:1587,y:463,t:1527876612726};\\\", \\\"{x:1587,y:459,t:1527876612742};\\\", \\\"{x:1590,y:452,t:1527876612759};\\\", \\\"{x:1591,y:450,t:1527876612775};\\\", \\\"{x:1593,y:446,t:1527876612793};\\\", \\\"{x:1596,y:443,t:1527876612809};\\\", \\\"{x:1599,y:440,t:1527876612826};\\\", \\\"{x:1601,y:438,t:1527876612843};\\\", \\\"{x:1603,y:437,t:1527876612859};\\\", \\\"{x:1607,y:437,t:1527876612875};\\\", \\\"{x:1611,y:435,t:1527876612892};\\\", \\\"{x:1615,y:433,t:1527876612909};\\\", \\\"{x:1617,y:431,t:1527876612925};\\\", \\\"{x:1618,y:430,t:1527876612950};\\\", \\\"{x:1618,y:433,t:1527876614496};\\\", \\\"{x:1599,y:484,t:1527876614537};\\\", \\\"{x:1593,y:493,t:1527876614544};\\\", \\\"{x:1582,y:512,t:1527876614560};\\\", \\\"{x:1575,y:525,t:1527876614577};\\\", \\\"{x:1569,y:538,t:1527876614594};\\\", \\\"{x:1561,y:556,t:1527876614610};\\\", \\\"{x:1552,y:572,t:1527876614627};\\\", \\\"{x:1542,y:588,t:1527876614644};\\\", \\\"{x:1534,y:601,t:1527876614660};\\\", \\\"{x:1526,y:609,t:1527876614677};\\\", \\\"{x:1522,y:612,t:1527876614693};\\\", \\\"{x:1521,y:614,t:1527876614904};\\\", \\\"{x:1521,y:615,t:1527876614920};\\\", \\\"{x:1521,y:617,t:1527876614977};\\\", \\\"{x:1521,y:618,t:1527876614995};\\\", \\\"{x:1520,y:621,t:1527876615012};\\\", \\\"{x:1518,y:624,t:1527876615028};\\\", \\\"{x:1516,y:625,t:1527876615048};\\\", \\\"{x:1515,y:627,t:1527876615061};\\\", \\\"{x:1514,y:628,t:1527876615077};\\\", \\\"{x:1513,y:628,t:1527876615094};\\\", \\\"{x:1511,y:628,t:1527876615568};\\\", \\\"{x:1505,y:628,t:1527876615580};\\\", \\\"{x:1482,y:635,t:1527876615595};\\\", \\\"{x:1414,y:651,t:1527876615610};\\\", \\\"{x:1302,y:671,t:1527876615628};\\\", \\\"{x:1188,y:687,t:1527876615645};\\\", \\\"{x:1073,y:699,t:1527876615661};\\\", \\\"{x:968,y:709,t:1527876615678};\\\", \\\"{x:873,y:709,t:1527876615694};\\\", \\\"{x:842,y:709,t:1527876615710};\\\", \\\"{x:832,y:709,t:1527876615727};\\\", \\\"{x:831,y:709,t:1527876615745};\\\", \\\"{x:829,y:709,t:1527876615775};\\\", \\\"{x:828,y:709,t:1527876615783};\\\", \\\"{x:827,y:709,t:1527876615795};\\\", \\\"{x:825,y:708,t:1527876615811};\\\", \\\"{x:822,y:708,t:1527876615828};\\\", \\\"{x:818,y:705,t:1527876615845};\\\", \\\"{x:816,y:704,t:1527876615862};\\\", \\\"{x:811,y:697,t:1527876615878};\\\", \\\"{x:781,y:659,t:1527876615894};\\\", \\\"{x:738,y:625,t:1527876615912};\\\", \\\"{x:688,y:602,t:1527876615929};\\\", \\\"{x:645,y:594,t:1527876615945};\\\", \\\"{x:578,y:594,t:1527876615961};\\\", \\\"{x:514,y:594,t:1527876615977};\\\", \\\"{x:452,y:594,t:1527876615996};\\\", \\\"{x:407,y:602,t:1527876616012};\\\", \\\"{x:371,y:611,t:1527876616029};\\\", \\\"{x:345,y:618,t:1527876616045};\\\", \\\"{x:340,y:620,t:1527876616062};\\\", \\\"{x:351,y:626,t:1527876616078};\\\", \\\"{x:358,y:628,t:1527876616095};\\\", \\\"{x:358,y:629,t:1527876616384};\\\", \\\"{x:358,y:630,t:1527876616395};\\\", \\\"{x:359,y:630,t:1527876616412};\\\", \\\"{x:361,y:631,t:1527876616454};\\\", \\\"{x:364,y:631,t:1527876616462};\\\", \\\"{x:365,y:631,t:1527876616478};\\\", \\\"{x:368,y:633,t:1527876616495};\\\", \\\"{x:371,y:634,t:1527876616512};\\\", \\\"{x:372,y:634,t:1527876616528};\\\", \\\"{x:375,y:634,t:1527876616546};\\\", \\\"{x:377,y:634,t:1527876616562};\\\", \\\"{x:377,y:634,t:1527876616621};\\\", \\\"{x:379,y:634,t:1527876616855};\\\", \\\"{x:384,y:636,t:1527876616863};\\\", \\\"{x:392,y:643,t:1527876616879};\\\", \\\"{x:403,y:652,t:1527876616897};\\\", \\\"{x:418,y:660,t:1527876616913};\\\", \\\"{x:430,y:667,t:1527876616929};\\\", \\\"{x:443,y:674,t:1527876616946};\\\", \\\"{x:454,y:678,t:1527876616962};\\\", \\\"{x:466,y:686,t:1527876616979};\\\", \\\"{x:475,y:690,t:1527876616996};\\\", \\\"{x:481,y:694,t:1527876617012};\\\", \\\"{x:486,y:697,t:1527876617028};\\\", \\\"{x:490,y:701,t:1527876617046};\\\", \\\"{x:492,y:706,t:1527876617062};\\\", \\\"{x:497,y:713,t:1527876617078};\\\", \\\"{x:501,y:720,t:1527876617096};\\\", \\\"{x:502,y:724,t:1527876617112};\\\", \\\"{x:502,y:725,t:1527876617129};\\\", \\\"{x:502,y:727,t:1527876617146};\\\", \\\"{x:502,y:732,t:1527876617162};\\\", \\\"{x:501,y:740,t:1527876617180};\\\", \\\"{x:500,y:744,t:1527876617196};\\\", \\\"{x:499,y:745,t:1527876617213};\\\", \\\"{x:499,y:747,t:1527876617229};\\\" ] }, { \\\"rt\\\": 10884, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 7, \\\"time_elapsed\\\": 241049, \\\"internal_node_id\\\": \\\"0.0-5.0-2.0\\\", \\\"subject\\\": \\\"HW2SN\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"xray\\\", \\\"condition\\\": \\\"311\\\", \\\"scenario\\\": \\\"acme\\\", \\\"question\\\": \\\"meets\\\", \\\"q\\\": 3, \\\"clicks\\\": 1.5, \\\"explicit\\\": 3, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XInside-YFull\\\", \\\"correct\\\": 1, \\\"orth_correct\\\": 0, \\\"answer\\\": [ \\\"F\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"X \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"U \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-C -C -C -C -F -F \\\", \\\"block\\\": \\\"triangular_scaffolded\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:499,y:744,t:1527876619503};\\\", \\\"{x:499,y:737,t:1527876619513};\\\", \\\"{x:500,y:723,t:1527876619530};\\\", \\\"{x:508,y:708,t:1527876619547};\\\", \\\"{x:519,y:690,t:1527876619564};\\\", \\\"{x:534,y:678,t:1527876619582};\\\", \\\"{x:549,y:671,t:1527876619597};\\\", \\\"{x:568,y:663,t:1527876619614};\\\", \\\"{x:597,y:656,t:1527876619630};\\\", \\\"{x:610,y:652,t:1527876619648};\\\", \\\"{x:623,y:651,t:1527876619665};\\\", \\\"{x:634,y:649,t:1527876619681};\\\", \\\"{x:646,y:647,t:1527876619699};\\\", \\\"{x:647,y:647,t:1527876619714};\\\", \\\"{x:647,y:645,t:1527876620016};\\\", \\\"{x:648,y:643,t:1527876620031};\\\", \\\"{x:649,y:643,t:1527876620048};\\\", \\\"{x:650,y:643,t:1527876620066};\\\", \\\"{x:653,y:643,t:1527876620081};\\\", \\\"{x:659,y:643,t:1527876620098};\\\", \\\"{x:668,y:643,t:1527876620115};\\\", \\\"{x:674,y:643,t:1527876620131};\\\", \\\"{x:678,y:643,t:1527876620148};\\\", \\\"{x:679,y:643,t:1527876620165};\\\", \\\"{x:680,y:640,t:1527876620272};\\\", \\\"{x:680,y:634,t:1527876620283};\\\", \\\"{x:663,y:621,t:1527876620299};\\\", \\\"{x:628,y:594,t:1527876620317};\\\", \\\"{x:584,y:559,t:1527876620333};\\\", \\\"{x:545,y:523,t:1527876620349};\\\", \\\"{x:535,y:516,t:1527876620364};\\\", \\\"{x:533,y:514,t:1527876620382};\\\", \\\"{x:530,y:512,t:1527876620398};\\\", \\\"{x:527,y:510,t:1527876620414};\\\", \\\"{x:524,y:508,t:1527876620432};\\\", \\\"{x:523,y:508,t:1527876620448};\\\", \\\"{x:521,y:507,t:1527876620465};\\\", \\\"{x:518,y:505,t:1527876620482};\\\", \\\"{x:516,y:504,t:1527876620498};\\\", \\\"{x:516,y:503,t:1527876620515};\\\", \\\"{x:517,y:503,t:1527876620583};\\\", \\\"{x:522,y:504,t:1527876620599};\\\", \\\"{x:540,y:516,t:1527876620615};\\\", \\\"{x:578,y:533,t:1527876620633};\\\", \\\"{x:625,y:546,t:1527876620650};\\\", \\\"{x:687,y:567,t:1527876620666};\\\", \\\"{x:750,y:579,t:1527876620682};\\\", \\\"{x:811,y:589,t:1527876620699};\\\", \\\"{x:867,y:604,t:1527876620715};\\\", \\\"{x:910,y:614,t:1527876620732};\\\", \\\"{x:935,y:618,t:1527876620749};\\\", \\\"{x:954,y:620,t:1527876620766};\\\", \\\"{x:965,y:623,t:1527876620782};\\\", \\\"{x:976,y:624,t:1527876620799};\\\", \\\"{x:984,y:625,t:1527876620815};\\\", \\\"{x:989,y:626,t:1527876620832};\\\", \\\"{x:993,y:626,t:1527876620849};\\\", \\\"{x:999,y:626,t:1527876620865};\\\", \\\"{x:1004,y:627,t:1527876620882};\\\", \\\"{x:1009,y:628,t:1527876620899};\\\", \\\"{x:1018,y:631,t:1527876620915};\\\", \\\"{x:1031,y:635,t:1527876620932};\\\", \\\"{x:1053,y:644,t:1527876620950};\\\", \\\"{x:1077,y:654,t:1527876620965};\\\", \\\"{x:1108,y:668,t:1527876620982};\\\", \\\"{x:1160,y:691,t:1527876620999};\\\", \\\"{x:1185,y:708,t:1527876621015};\\\", \\\"{x:1206,y:724,t:1527876621032};\\\", \\\"{x:1232,y:743,t:1527876621049};\\\", \\\"{x:1252,y:758,t:1527876621066};\\\", \\\"{x:1265,y:771,t:1527876621082};\\\", \\\"{x:1278,y:784,t:1527876621100};\\\", \\\"{x:1283,y:790,t:1527876621116};\\\", \\\"{x:1283,y:792,t:1527876621133};\\\", \\\"{x:1284,y:794,t:1527876621149};\\\", \\\"{x:1284,y:796,t:1527876621167};\\\", \\\"{x:1285,y:796,t:1527876621183};\\\", \\\"{x:1285,y:797,t:1527876621200};\\\", \\\"{x:1285,y:798,t:1527876621217};\\\", \\\"{x:1285,y:799,t:1527876621232};\\\", \\\"{x:1285,y:800,t:1527876621249};\\\", \\\"{x:1285,y:801,t:1527876621266};\\\", \\\"{x:1284,y:802,t:1527876621287};\\\", \\\"{x:1282,y:803,t:1527876621303};\\\", \\\"{x:1280,y:803,t:1527876621317};\\\", \\\"{x:1276,y:805,t:1527876621333};\\\", \\\"{x:1269,y:806,t:1527876621350};\\\", \\\"{x:1261,y:807,t:1527876621367};\\\", \\\"{x:1253,y:809,t:1527876621382};\\\", \\\"{x:1245,y:810,t:1527876621400};\\\", \\\"{x:1243,y:811,t:1527876621417};\\\", \\\"{x:1241,y:811,t:1527876621433};\\\", \\\"{x:1239,y:813,t:1527876621450};\\\", \\\"{x:1237,y:813,t:1527876621467};\\\", \\\"{x:1232,y:814,t:1527876621483};\\\", \\\"{x:1228,y:814,t:1527876621500};\\\", \\\"{x:1223,y:815,t:1527876621517};\\\", \\\"{x:1220,y:817,t:1527876621533};\\\", \\\"{x:1214,y:818,t:1527876621550};\\\", \\\"{x:1209,y:819,t:1527876621567};\\\", \\\"{x:1206,y:820,t:1527876621583};\\\", \\\"{x:1205,y:821,t:1527876621663};\\\", \\\"{x:1205,y:822,t:1527876621711};\\\", \\\"{x:1205,y:823,t:1527876621718};\\\", \\\"{x:1205,y:824,t:1527876621735};\\\", \\\"{x:1205,y:825,t:1527876621749};\\\", \\\"{x:1205,y:826,t:1527876621767};\\\", \\\"{x:1206,y:827,t:1527876621806};\\\", \\\"{x:1209,y:828,t:1527876621823};\\\", \\\"{x:1214,y:833,t:1527876621833};\\\", \\\"{x:1218,y:836,t:1527876621850};\\\", \\\"{x:1222,y:837,t:1527876621866};\\\", \\\"{x:1224,y:837,t:1527876621883};\\\", \\\"{x:1225,y:837,t:1527876621983};\\\", \\\"{x:1226,y:835,t:1527876622000};\\\", \\\"{x:1226,y:834,t:1527876622017};\\\", \\\"{x:1226,y:833,t:1527876622033};\\\", \\\"{x:1225,y:832,t:1527876622050};\\\", \\\"{x:1224,y:831,t:1527876622071};\\\", \\\"{x:1222,y:831,t:1527876622088};\\\", \\\"{x:1221,y:831,t:1527876622100};\\\", \\\"{x:1219,y:830,t:1527876622119};\\\", \\\"{x:1218,y:830,t:1527876622158};\\\", \\\"{x:1216,y:830,t:1527876622183};\\\", \\\"{x:1215,y:830,t:1527876622255};\\\", \\\"{x:1213,y:830,t:1527876622271};\\\", \\\"{x:1212,y:830,t:1527876622287};\\\", \\\"{x:1211,y:831,t:1527876622301};\\\", \\\"{x:1210,y:831,t:1527876622317};\\\", \\\"{x:1208,y:832,t:1527876622336};\\\", \\\"{x:1209,y:832,t:1527876622947};\\\", \\\"{x:1211,y:832,t:1527876622990};\\\", \\\"{x:1212,y:832,t:1527876623000};\\\", \\\"{x:1214,y:833,t:1527876623017};\\\", \\\"{x:1215,y:833,t:1527876623034};\\\", \\\"{x:1216,y:834,t:1527876623050};\\\", \\\"{x:1218,y:834,t:1527876623640};\\\", \\\"{x:1224,y:833,t:1527876623655};\\\", \\\"{x:1238,y:829,t:1527876623667};\\\", \\\"{x:1254,y:826,t:1527876623684};\\\", \\\"{x:1271,y:823,t:1527876623701};\\\", \\\"{x:1286,y:821,t:1527876623718};\\\", \\\"{x:1291,y:820,t:1527876623734};\\\", \\\"{x:1293,y:820,t:1527876623752};\\\", \\\"{x:1295,y:819,t:1527876623769};\\\", \\\"{x:1297,y:817,t:1527876623784};\\\", \\\"{x:1302,y:813,t:1527876623801};\\\", \\\"{x:1307,y:811,t:1527876623819};\\\", \\\"{x:1312,y:808,t:1527876623834};\\\", \\\"{x:1316,y:806,t:1527876623851};\\\", \\\"{x:1323,y:800,t:1527876623868};\\\", \\\"{x:1329,y:795,t:1527876623885};\\\", \\\"{x:1333,y:792,t:1527876623902};\\\", \\\"{x:1341,y:787,t:1527876623919};\\\", \\\"{x:1352,y:782,t:1527876623934};\\\", \\\"{x:1364,y:777,t:1527876623951};\\\", \\\"{x:1371,y:773,t:1527876623968};\\\", \\\"{x:1377,y:770,t:1527876623985};\\\", \\\"{x:1380,y:769,t:1527876624001};\\\", \\\"{x:1382,y:769,t:1527876624017};\\\", \\\"{x:1382,y:768,t:1527876624047};\\\", \\\"{x:1383,y:767,t:1527876624068};\\\", \\\"{x:1385,y:766,t:1527876624084};\\\", \\\"{x:1387,y:763,t:1527876624101};\\\", \\\"{x:1388,y:763,t:1527876624119};\\\", \\\"{x:1389,y:761,t:1527876624136};\\\", \\\"{x:1388,y:761,t:1527876624480};\\\", \\\"{x:1387,y:761,t:1527876624487};\\\", \\\"{x:1387,y:762,t:1527876624502};\\\", \\\"{x:1386,y:763,t:1527876624521};\\\", \\\"{x:1385,y:764,t:1527876624615};\\\", \\\"{x:1384,y:764,t:1527876624639};\\\", \\\"{x:1382,y:765,t:1527876624663};\\\", \\\"{x:1382,y:766,t:1527876624671};\\\", \\\"{x:1382,y:767,t:1527876624687};\\\", \\\"{x:1381,y:767,t:1527876624701};\\\", \\\"{x:1380,y:768,t:1527876624718};\\\", \\\"{x:1367,y:773,t:1527876625686};\\\", \\\"{x:1344,y:777,t:1527876625702};\\\", \\\"{x:1304,y:781,t:1527876625719};\\\", \\\"{x:1245,y:781,t:1527876625737};\\\", \\\"{x:1178,y:781,t:1527876625752};\\\", \\\"{x:1123,y:781,t:1527876625769};\\\", \\\"{x:1081,y:781,t:1527876625787};\\\", \\\"{x:1055,y:781,t:1527876625803};\\\", \\\"{x:1037,y:779,t:1527876625819};\\\", \\\"{x:1031,y:776,t:1527876625836};\\\", \\\"{x:1027,y:775,t:1527876625853};\\\", \\\"{x:1024,y:774,t:1527876625869};\\\", \\\"{x:1023,y:773,t:1527876625886};\\\", \\\"{x:1016,y:771,t:1527876625903};\\\", \\\"{x:1004,y:767,t:1527876625919};\\\", \\\"{x:984,y:762,t:1527876625936};\\\", \\\"{x:956,y:755,t:1527876625953};\\\", \\\"{x:929,y:750,t:1527876625969};\\\", \\\"{x:910,y:745,t:1527876625986};\\\", \\\"{x:887,y:739,t:1527876626002};\\\", \\\"{x:861,y:733,t:1527876626019};\\\", \\\"{x:835,y:726,t:1527876626036};\\\", \\\"{x:804,y:716,t:1527876626052};\\\", \\\"{x:779,y:711,t:1527876626069};\\\", \\\"{x:733,y:700,t:1527876626087};\\\", \\\"{x:680,y:692,t:1527876626102};\\\", \\\"{x:624,y:684,t:1527876626120};\\\", \\\"{x:593,y:677,t:1527876626136};\\\", \\\"{x:576,y:672,t:1527876626153};\\\", \\\"{x:568,y:669,t:1527876626169};\\\", \\\"{x:564,y:667,t:1527876626186};\\\", \\\"{x:549,y:663,t:1527876626203};\\\", \\\"{x:518,y:658,t:1527876626220};\\\", \\\"{x:462,y:650,t:1527876626237};\\\", \\\"{x:434,y:641,t:1527876626254};\\\", \\\"{x:431,y:638,t:1527876626270};\\\", \\\"{x:429,y:636,t:1527876626286};\\\", \\\"{x:431,y:634,t:1527876626302};\\\", \\\"{x:433,y:634,t:1527876626320};\\\", \\\"{x:426,y:633,t:1527876626568};\\\", \\\"{x:420,y:631,t:1527876626575};\\\", \\\"{x:418,y:630,t:1527876626587};\\\", \\\"{x:405,y:627,t:1527876626604};\\\", \\\"{x:388,y:622,t:1527876626620};\\\", \\\"{x:374,y:620,t:1527876626637};\\\", \\\"{x:359,y:614,t:1527876626653};\\\", \\\"{x:332,y:611,t:1527876626670};\\\", \\\"{x:315,y:609,t:1527876626687};\\\", \\\"{x:294,y:606,t:1527876626703};\\\", \\\"{x:277,y:604,t:1527876626720};\\\", \\\"{x:273,y:603,t:1527876626737};\\\", \\\"{x:272,y:603,t:1527876626767};\\\", \\\"{x:271,y:603,t:1527876626783};\\\", \\\"{x:270,y:603,t:1527876626799};\\\", \\\"{x:268,y:603,t:1527876626806};\\\", \\\"{x:267,y:603,t:1527876626821};\\\", \\\"{x:262,y:605,t:1527876626838};\\\", \\\"{x:253,y:609,t:1527876626853};\\\", \\\"{x:235,y:615,t:1527876626871};\\\", \\\"{x:220,y:620,t:1527876626887};\\\", \\\"{x:204,y:622,t:1527876626903};\\\", \\\"{x:193,y:624,t:1527876626920};\\\", \\\"{x:179,y:624,t:1527876626938};\\\", \\\"{x:167,y:625,t:1527876626953};\\\", \\\"{x:158,y:626,t:1527876626971};\\\", \\\"{x:153,y:626,t:1527876626987};\\\", \\\"{x:150,y:624,t:1527876627003};\\\", \\\"{x:150,y:628,t:1527876627055};\\\", \\\"{x:152,y:634,t:1527876627071};\\\", \\\"{x:157,y:638,t:1527876627087};\\\", \\\"{x:167,y:645,t:1527876627104};\\\", \\\"{x:177,y:648,t:1527876627121};\\\", \\\"{x:191,y:648,t:1527876627137};\\\", \\\"{x:209,y:646,t:1527876627153};\\\", \\\"{x:235,y:639,t:1527876627170};\\\", \\\"{x:265,y:630,t:1527876627188};\\\", \\\"{x:297,y:620,t:1527876627204};\\\", \\\"{x:328,y:612,t:1527876627221};\\\", \\\"{x:351,y:604,t:1527876627238};\\\", \\\"{x:366,y:597,t:1527876627254};\\\", \\\"{x:369,y:596,t:1527876627270};\\\", \\\"{x:370,y:595,t:1527876627287};\\\", \\\"{x:371,y:594,t:1527876627398};\\\", \\\"{x:372,y:594,t:1527876627407};\\\", \\\"{x:373,y:594,t:1527876627712};\\\", \\\"{x:380,y:598,t:1527876627722};\\\", \\\"{x:389,y:612,t:1527876627737};\\\", \\\"{x:402,y:624,t:1527876627754};\\\", \\\"{x:412,y:634,t:1527876627771};\\\", \\\"{x:422,y:643,t:1527876627788};\\\", \\\"{x:431,y:651,t:1527876627805};\\\", \\\"{x:443,y:664,t:1527876627822};\\\", \\\"{x:454,y:675,t:1527876627837};\\\", \\\"{x:465,y:689,t:1527876627859};\\\", \\\"{x:467,y:691,t:1527876627875};\\\", \\\"{x:468,y:692,t:1527876627891};\\\", \\\"{x:470,y:693,t:1527876627922};\\\", \\\"{x:471,y:694,t:1527876627930};\\\", \\\"{x:471,y:697,t:1527876627940};\\\", \\\"{x:475,y:702,t:1527876627958};\\\", \\\"{x:476,y:706,t:1527876627975};\\\", \\\"{x:477,y:707,t:1527876627991};\\\", \\\"{x:476,y:706,t:1527876628018};\\\", \\\"{x:474,y:700,t:1527876628026};\\\", \\\"{x:472,y:696,t:1527876628041};\\\", \\\"{x:461,y:673,t:1527876628060};\\\", \\\"{x:450,y:655,t:1527876628075};\\\", \\\"{x:438,y:636,t:1527876628092};\\\", \\\"{x:433,y:626,t:1527876628108};\\\", \\\"{x:431,y:623,t:1527876628125};\\\", \\\"{x:429,y:619,t:1527876628141};\\\", \\\"{x:427,y:617,t:1527876628158};\\\", \\\"{x:427,y:616,t:1527876628175};\\\", \\\"{x:426,y:616,t:1527876628192};\\\", \\\"{x:423,y:612,t:1527876628207};\\\", \\\"{x:420,y:609,t:1527876628225};\\\", \\\"{x:416,y:607,t:1527876628242};\\\", \\\"{x:415,y:606,t:1527876628257};\\\", \\\"{x:414,y:606,t:1527876628282};\\\", \\\"{x:413,y:605,t:1527876628298};\\\", \\\"{x:412,y:605,t:1527876628308};\\\", \\\"{x:408,y:604,t:1527876628324};\\\", \\\"{x:404,y:601,t:1527876628341};\\\", \\\"{x:397,y:595,t:1527876628358};\\\", \\\"{x:391,y:591,t:1527876628375};\\\", \\\"{x:379,y:585,t:1527876628392};\\\", \\\"{x:371,y:582,t:1527876628408};\\\", \\\"{x:368,y:580,t:1527876628425};\\\", \\\"{x:371,y:581,t:1527876628531};\\\", \\\"{x:374,y:581,t:1527876628542};\\\", \\\"{x:381,y:585,t:1527876628546};\\\", \\\"{x:382,y:588,t:1527876628560};\\\", \\\"{x:384,y:590,t:1527876628576};\\\", \\\"{x:385,y:591,t:1527876628592};\\\", \\\"{x:387,y:593,t:1527876628609};\\\", \\\"{x:388,y:594,t:1527876628625};\\\", \\\"{x:389,y:594,t:1527876629163};\\\", \\\"{x:390,y:597,t:1527876629176};\\\", \\\"{x:397,y:613,t:1527876629194};\\\", \\\"{x:406,y:628,t:1527876629209};\\\", \\\"{x:420,y:650,t:1527876629226};\\\", \\\"{x:434,y:667,t:1527876629242};\\\", \\\"{x:439,y:674,t:1527876629259};\\\", \\\"{x:444,y:681,t:1527876629276};\\\", \\\"{x:451,y:689,t:1527876629292};\\\", \\\"{x:455,y:695,t:1527876629309};\\\", \\\"{x:459,y:700,t:1527876629326};\\\", \\\"{x:463,y:705,t:1527876629342};\\\", \\\"{x:466,y:709,t:1527876629358};\\\", \\\"{x:469,y:715,t:1527876629376};\\\", \\\"{x:471,y:719,t:1527876629392};\\\", \\\"{x:472,y:721,t:1527876629408};\\\", \\\"{x:473,y:722,t:1527876629434};\\\", \\\"{x:474,y:723,t:1527876629474};\\\", \\\"{x:476,y:726,t:1527876629482};\\\", \\\"{x:478,y:730,t:1527876629493};\\\", \\\"{x:481,y:735,t:1527876629509};\\\", \\\"{x:483,y:737,t:1527876629527};\\\", \\\"{x:484,y:739,t:1527876629543};\\\", \\\"{x:486,y:742,t:1527876629559};\\\", \\\"{x:488,y:744,t:1527876629576};\\\", \\\"{x:488,y:745,t:1527876629593};\\\", \\\"{x:489,y:745,t:1527876629730};\\\", \\\"{x:489,y:745,t:1527876629804};\\\" ] }, { \\\"rt\\\": 12481, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 8, \\\"time_elapsed\\\": 254840, \\\"internal_node_id\\\": \\\"0.0-5.0-3.0\\\", \\\"subject\\\": \\\"HW2SN\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"xray\\\", \\\"condition\\\": \\\"311\\\", \\\"scenario\\\": \\\"acme\\\", \\\"question\\\": \\\"endtime\\\", \\\"q\\\": 4, \\\"clicks\\\": 1, \\\"explicit\\\": 3, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XInside-YFull\\\", \\\"correct\\\": 1, \\\"orth_correct\\\": 0, \\\"answer\\\": [ \\\"H\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"X \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"U \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-B -H -H \\\", \\\"block\\\": \\\"triangular_scaffolded\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:491,y:747,t:1527876631658};\\\", \\\"{x:493,y:746,t:1527876631666};\\\", \\\"{x:493,y:745,t:1527876631682};\\\", \\\"{x:494,y:744,t:1527876632035};\\\", \\\"{x:493,y:744,t:1527876632051};\\\", \\\"{x:494,y:744,t:1527876632139};\\\", \\\"{x:496,y:742,t:1527876632147};\\\", \\\"{x:498,y:741,t:1527876632163};\\\", \\\"{x:500,y:740,t:1527876632180};\\\", \\\"{x:507,y:740,t:1527876632197};\\\", \\\"{x:512,y:739,t:1527876632213};\\\", \\\"{x:528,y:736,t:1527876632232};\\\", \\\"{x:535,y:735,t:1527876632247};\\\", \\\"{x:538,y:734,t:1527876632262};\\\", \\\"{x:543,y:732,t:1527876632278};\\\", \\\"{x:547,y:731,t:1527876632295};\\\", \\\"{x:549,y:730,t:1527876632312};\\\", \\\"{x:552,y:729,t:1527876632327};\\\", \\\"{x:556,y:728,t:1527876632344};\\\", \\\"{x:563,y:727,t:1527876632362};\\\", \\\"{x:571,y:725,t:1527876632378};\\\", \\\"{x:581,y:723,t:1527876632394};\\\", \\\"{x:590,y:723,t:1527876632412};\\\", \\\"{x:598,y:722,t:1527876632428};\\\", \\\"{x:609,y:719,t:1527876632445};\\\", \\\"{x:622,y:719,t:1527876632462};\\\", \\\"{x:634,y:719,t:1527876632478};\\\", \\\"{x:652,y:719,t:1527876632495};\\\", \\\"{x:674,y:719,t:1527876632512};\\\", \\\"{x:703,y:719,t:1527876632528};\\\", \\\"{x:731,y:719,t:1527876632545};\\\", \\\"{x:783,y:720,t:1527876632562};\\\", \\\"{x:817,y:723,t:1527876632578};\\\", \\\"{x:862,y:730,t:1527876632595};\\\", \\\"{x:905,y:738,t:1527876632612};\\\", \\\"{x:946,y:742,t:1527876632629};\\\", \\\"{x:985,y:742,t:1527876632646};\\\", \\\"{x:986,y:742,t:1527876632662};\\\", \\\"{x:987,y:743,t:1527876633011};\\\", \\\"{x:990,y:745,t:1527876633018};\\\", \\\"{x:995,y:746,t:1527876633029};\\\", \\\"{x:1004,y:749,t:1527876633046};\\\", \\\"{x:1018,y:752,t:1527876633062};\\\", \\\"{x:1039,y:761,t:1527876633079};\\\", \\\"{x:1072,y:770,t:1527876633096};\\\", \\\"{x:1112,y:781,t:1527876633112};\\\", \\\"{x:1159,y:795,t:1527876633129};\\\", \\\"{x:1217,y:805,t:1527876633147};\\\", \\\"{x:1251,y:810,t:1527876633162};\\\", \\\"{x:1292,y:817,t:1527876633179};\\\", \\\"{x:1332,y:822,t:1527876633196};\\\", \\\"{x:1355,y:824,t:1527876633212};\\\", \\\"{x:1369,y:827,t:1527876633230};\\\", \\\"{x:1381,y:830,t:1527876633246};\\\", \\\"{x:1388,y:833,t:1527876633263};\\\", \\\"{x:1395,y:835,t:1527876633279};\\\", \\\"{x:1398,y:836,t:1527876633296};\\\", \\\"{x:1401,y:837,t:1527876633379};\\\", \\\"{x:1405,y:837,t:1527876633397};\\\", \\\"{x:1413,y:840,t:1527876633413};\\\", \\\"{x:1425,y:843,t:1527876633429};\\\", \\\"{x:1443,y:847,t:1527876633447};\\\", \\\"{x:1466,y:851,t:1527876633464};\\\", \\\"{x:1492,y:853,t:1527876633480};\\\", \\\"{x:1517,y:854,t:1527876633496};\\\", \\\"{x:1541,y:854,t:1527876633514};\\\", \\\"{x:1558,y:857,t:1527876633529};\\\", \\\"{x:1575,y:859,t:1527876633546};\\\", \\\"{x:1576,y:861,t:1527876633627};\\\", \\\"{x:1578,y:861,t:1527876633635};\\\", \\\"{x:1581,y:863,t:1527876633647};\\\", \\\"{x:1592,y:870,t:1527876633664};\\\", \\\"{x:1604,y:875,t:1527876633680};\\\", \\\"{x:1618,y:878,t:1527876633697};\\\", \\\"{x:1633,y:881,t:1527876633713};\\\", \\\"{x:1654,y:885,t:1527876633731};\\\", \\\"{x:1665,y:886,t:1527876633747};\\\", \\\"{x:1670,y:886,t:1527876633763};\\\", \\\"{x:1674,y:886,t:1527876633781};\\\", \\\"{x:1676,y:886,t:1527876633797};\\\", \\\"{x:1678,y:885,t:1527876633814};\\\", \\\"{x:1680,y:882,t:1527876633831};\\\", \\\"{x:1683,y:879,t:1527876633846};\\\", \\\"{x:1686,y:874,t:1527876633864};\\\", \\\"{x:1689,y:870,t:1527876633881};\\\", \\\"{x:1691,y:865,t:1527876633897};\\\", \\\"{x:1695,y:859,t:1527876633914};\\\", \\\"{x:1701,y:849,t:1527876633930};\\\", \\\"{x:1702,y:843,t:1527876633947};\\\", \\\"{x:1705,y:836,t:1527876633964};\\\", \\\"{x:1706,y:831,t:1527876633981};\\\", \\\"{x:1706,y:828,t:1527876633997};\\\", \\\"{x:1706,y:827,t:1527876634014};\\\", \\\"{x:1706,y:825,t:1527876634042};\\\", \\\"{x:1705,y:825,t:1527876634179};\\\", \\\"{x:1704,y:825,t:1527876634187};\\\", \\\"{x:1703,y:825,t:1527876634198};\\\", \\\"{x:1702,y:825,t:1527876634214};\\\", \\\"{x:1700,y:825,t:1527876634231};\\\", \\\"{x:1699,y:825,t:1527876634247};\\\", \\\"{x:1698,y:825,t:1527876634264};\\\", \\\"{x:1697,y:825,t:1527876634281};\\\", \\\"{x:1696,y:825,t:1527876634314};\\\", \\\"{x:1695,y:825,t:1527876634403};\\\", \\\"{x:1693,y:825,t:1527876634414};\\\", \\\"{x:1690,y:825,t:1527876634431};\\\", \\\"{x:1686,y:827,t:1527876634452};\\\", \\\"{x:1684,y:828,t:1527876634464};\\\", \\\"{x:1684,y:829,t:1527876636267};\\\", \\\"{x:1679,y:828,t:1527876638075};\\\", \\\"{x:1671,y:826,t:1527876638085};\\\", \\\"{x:1645,y:816,t:1527876638099};\\\", \\\"{x:1615,y:808,t:1527876638116};\\\", \\\"{x:1572,y:787,t:1527876638132};\\\", \\\"{x:1528,y:767,t:1527876638149};\\\", \\\"{x:1499,y:752,t:1527876638166};\\\", \\\"{x:1484,y:741,t:1527876638183};\\\", \\\"{x:1474,y:734,t:1527876638199};\\\", \\\"{x:1470,y:728,t:1527876638216};\\\", \\\"{x:1468,y:723,t:1527876638234};\\\", \\\"{x:1466,y:720,t:1527876638249};\\\", \\\"{x:1465,y:716,t:1527876638266};\\\", \\\"{x:1462,y:710,t:1527876638283};\\\", \\\"{x:1460,y:708,t:1527876638300};\\\", \\\"{x:1459,y:707,t:1527876638316};\\\", \\\"{x:1459,y:705,t:1527876638338};\\\", \\\"{x:1459,y:704,t:1527876638349};\\\", \\\"{x:1459,y:699,t:1527876638366};\\\", \\\"{x:1457,y:690,t:1527876638384};\\\", \\\"{x:1456,y:681,t:1527876638399};\\\", \\\"{x:1452,y:668,t:1527876638416};\\\", \\\"{x:1448,y:656,t:1527876638433};\\\", \\\"{x:1439,y:640,t:1527876638450};\\\", \\\"{x:1428,y:621,t:1527876638467};\\\", \\\"{x:1424,y:610,t:1527876638483};\\\", \\\"{x:1422,y:606,t:1527876638499};\\\", \\\"{x:1420,y:601,t:1527876638516};\\\", \\\"{x:1418,y:596,t:1527876638533};\\\", \\\"{x:1415,y:591,t:1527876638551};\\\", \\\"{x:1411,y:582,t:1527876638567};\\\", \\\"{x:1410,y:577,t:1527876638584};\\\", \\\"{x:1407,y:572,t:1527876638601};\\\", \\\"{x:1407,y:567,t:1527876638616};\\\", \\\"{x:1405,y:563,t:1527876638634};\\\", \\\"{x:1403,y:559,t:1527876638651};\\\", \\\"{x:1402,y:559,t:1527876638675};\\\", \\\"{x:1402,y:557,t:1527876638690};\\\", \\\"{x:1402,y:556,t:1527876638715};\\\", \\\"{x:1402,y:554,t:1527876638723};\\\", \\\"{x:1401,y:554,t:1527876638733};\\\", \\\"{x:1402,y:554,t:1527876638899};\\\", \\\"{x:1403,y:554,t:1527876638915};\\\", \\\"{x:1404,y:554,t:1527876638947};\\\", \\\"{x:1405,y:554,t:1527876638963};\\\", \\\"{x:1406,y:554,t:1527876638971};\\\", \\\"{x:1407,y:554,t:1527876639043};\\\", \\\"{x:1408,y:554,t:1527876639058};\\\", \\\"{x:1410,y:556,t:1527876639067};\\\", \\\"{x:1411,y:557,t:1527876639107};\\\", \\\"{x:1411,y:559,t:1527876639134};\\\", \\\"{x:1413,y:561,t:1527876639150};\\\", \\\"{x:1414,y:563,t:1527876639167};\\\", \\\"{x:1415,y:566,t:1527876639183};\\\", \\\"{x:1416,y:567,t:1527876639200};\\\", \\\"{x:1416,y:568,t:1527876640067};\\\", \\\"{x:1415,y:568,t:1527876641058};\\\", \\\"{x:1407,y:570,t:1527876641071};\\\", \\\"{x:1389,y:576,t:1527876641085};\\\", \\\"{x:1353,y:583,t:1527876641102};\\\", \\\"{x:1299,y:591,t:1527876641118};\\\", \\\"{x:1215,y:592,t:1527876641136};\\\", \\\"{x:1145,y:594,t:1527876641152};\\\", \\\"{x:1079,y:601,t:1527876641168};\\\", \\\"{x:1032,y:601,t:1527876641185};\\\", \\\"{x:962,y:601,t:1527876641201};\\\", \\\"{x:930,y:601,t:1527876641218};\\\", \\\"{x:904,y:604,t:1527876641235};\\\", \\\"{x:882,y:605,t:1527876641253};\\\", \\\"{x:855,y:605,t:1527876641268};\\\", \\\"{x:829,y:605,t:1527876641285};\\\", \\\"{x:807,y:605,t:1527876641302};\\\", \\\"{x:788,y:605,t:1527876641318};\\\", \\\"{x:761,y:605,t:1527876641335};\\\", \\\"{x:724,y:607,t:1527876641352};\\\", \\\"{x:680,y:613,t:1527876641369};\\\", \\\"{x:642,y:614,t:1527876641385};\\\", \\\"{x:604,y:614,t:1527876641402};\\\", \\\"{x:580,y:614,t:1527876641419};\\\", \\\"{x:555,y:617,t:1527876641436};\\\", \\\"{x:544,y:618,t:1527876641453};\\\", \\\"{x:538,y:622,t:1527876641468};\\\", \\\"{x:534,y:623,t:1527876641485};\\\", \\\"{x:529,y:625,t:1527876641502};\\\", \\\"{x:522,y:627,t:1527876641519};\\\", \\\"{x:513,y:632,t:1527876641535};\\\", \\\"{x:499,y:638,t:1527876641552};\\\", \\\"{x:489,y:643,t:1527876641569};\\\", \\\"{x:476,y:646,t:1527876641585};\\\", \\\"{x:465,y:647,t:1527876641602};\\\", \\\"{x:455,y:647,t:1527876641619};\\\", \\\"{x:444,y:650,t:1527876641636};\\\", \\\"{x:432,y:651,t:1527876641652};\\\", \\\"{x:420,y:651,t:1527876641669};\\\", \\\"{x:398,y:651,t:1527876641685};\\\", \\\"{x:370,y:651,t:1527876641702};\\\", \\\"{x:333,y:650,t:1527876641719};\\\", \\\"{x:308,y:646,t:1527876641736};\\\", \\\"{x:294,y:642,t:1527876641752};\\\", \\\"{x:284,y:638,t:1527876641769};\\\", \\\"{x:280,y:638,t:1527876641785};\\\", \\\"{x:271,y:635,t:1527876641803};\\\", \\\"{x:253,y:633,t:1527876641819};\\\", \\\"{x:241,y:629,t:1527876641835};\\\", \\\"{x:238,y:629,t:1527876641852};\\\", \\\"{x:239,y:629,t:1527876641939};\\\", \\\"{x:240,y:629,t:1527876641953};\\\", \\\"{x:241,y:629,t:1527876641970};\\\", \\\"{x:242,y:629,t:1527876641986};\\\", \\\"{x:251,y:630,t:1527876642002};\\\", \\\"{x:262,y:630,t:1527876642020};\\\", \\\"{x:285,y:630,t:1527876642038};\\\", \\\"{x:344,y:630,t:1527876642052};\\\", \\\"{x:419,y:630,t:1527876642069};\\\", \\\"{x:505,y:630,t:1527876642086};\\\", \\\"{x:580,y:630,t:1527876642102};\\\", \\\"{x:638,y:630,t:1527876642120};\\\", \\\"{x:667,y:630,t:1527876642136};\\\", \\\"{x:678,y:629,t:1527876642152};\\\", \\\"{x:680,y:629,t:1527876642169};\\\", \\\"{x:676,y:625,t:1527876642282};\\\", \\\"{x:671,y:622,t:1527876642290};\\\", \\\"{x:667,y:618,t:1527876642302};\\\", \\\"{x:659,y:612,t:1527876642320};\\\", \\\"{x:652,y:605,t:1527876642337};\\\", \\\"{x:649,y:603,t:1527876642353};\\\", \\\"{x:647,y:601,t:1527876642369};\\\", \\\"{x:646,y:600,t:1527876642386};\\\", \\\"{x:645,y:599,t:1527876642403};\\\", \\\"{x:644,y:598,t:1527876642419};\\\", \\\"{x:641,y:596,t:1527876642437};\\\", \\\"{x:640,y:596,t:1527876642453};\\\", \\\"{x:636,y:595,t:1527876642469};\\\", \\\"{x:627,y:592,t:1527876642486};\\\", \\\"{x:617,y:589,t:1527876642503};\\\", \\\"{x:609,y:587,t:1527876642519};\\\", \\\"{x:607,y:587,t:1527876642536};\\\", \\\"{x:609,y:587,t:1527876642658};\\\", \\\"{x:610,y:587,t:1527876642670};\\\", \\\"{x:612,y:587,t:1527876642687};\\\", \\\"{x:613,y:587,t:1527876642704};\\\", \\\"{x:613,y:591,t:1527876643002};\\\", \\\"{x:611,y:601,t:1527876643009};\\\", \\\"{x:609,y:614,t:1527876643022};\\\", \\\"{x:593,y:647,t:1527876643037};\\\", \\\"{x:583,y:667,t:1527876643054};\\\", \\\"{x:576,y:677,t:1527876643070};\\\", \\\"{x:575,y:682,t:1527876643086};\\\", \\\"{x:573,y:686,t:1527876643103};\\\", \\\"{x:571,y:694,t:1527876643122};\\\", \\\"{x:564,y:709,t:1527876643137};\\\", \\\"{x:556,y:724,t:1527876643153};\\\", \\\"{x:547,y:740,t:1527876643170};\\\", \\\"{x:544,y:742,t:1527876643187};\\\", \\\"{x:541,y:744,t:1527876643203};\\\", \\\"{x:538,y:746,t:1527876643221};\\\", \\\"{x:533,y:749,t:1527876643236};\\\", \\\"{x:532,y:750,t:1527876643253};\\\", \\\"{x:531,y:750,t:1527876643270};\\\", \\\"{x:530,y:751,t:1527876643287};\\\", \\\"{x:529,y:753,t:1527876643304};\\\", \\\"{x:527,y:757,t:1527876643321};\\\", \\\"{x:527,y:758,t:1527876643337};\\\", \\\"{x:527,y:759,t:1527876643354};\\\", \\\"{x:526,y:759,t:1527876643459};\\\" ] }, { \\\"rt\\\": 34405, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 9, \\\"time_elapsed\\\": 290567, \\\"internal_node_id\\\": \\\"0.0-5.0-4.0\\\", \\\"subject\\\": \\\"HW2SN\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"xray\\\", \\\"condition\\\": \\\"311\\\", \\\"scenario\\\": \\\"acme\\\", \\\"question\\\": \\\"midpoint\\\", \\\"q\\\": 5, \\\"clicks\\\": 1, \\\"explicit\\\": 3, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XInside-YFull\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 0, \\\"answer\\\": [ \\\"Z\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"X \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"U \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-I -I -O -O -F -F -Z -A -A -A -C -I -I -Z \\\", \\\"block\\\": \\\"triangular_scaffolded\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:526,y:748,t:1527876645483};\\\", \\\"{x:524,y:708,t:1527876645496};\\\", \\\"{x:516,y:607,t:1527876645506};\\\", \\\"{x:501,y:515,t:1527876645523};\\\", \\\"{x:488,y:460,t:1527876645538};\\\", \\\"{x:480,y:436,t:1527876645555};\\\", \\\"{x:478,y:427,t:1527876645572};\\\", \\\"{x:478,y:425,t:1527876645588};\\\", \\\"{x:478,y:426,t:1527876645795};\\\", \\\"{x:478,y:430,t:1527876645805};\\\", \\\"{x:478,y:434,t:1527876645823};\\\", \\\"{x:478,y:437,t:1527876645839};\\\", \\\"{x:480,y:441,t:1527876645855};\\\", \\\"{x:480,y:445,t:1527876645873};\\\", \\\"{x:481,y:448,t:1527876645888};\\\", \\\"{x:482,y:450,t:1527876645905};\\\", \\\"{x:482,y:451,t:1527876645930};\\\", \\\"{x:483,y:451,t:1527876645953};\\\", \\\"{x:483,y:452,t:1527876645962};\\\", \\\"{x:483,y:453,t:1527876645972};\\\", \\\"{x:484,y:454,t:1527876645990};\\\", \\\"{x:484,y:458,t:1527876646005};\\\", \\\"{x:487,y:462,t:1527876646022};\\\", \\\"{x:487,y:464,t:1527876646040};\\\", \\\"{x:487,y:465,t:1527876646056};\\\", \\\"{x:488,y:468,t:1527876646073};\\\", \\\"{x:490,y:475,t:1527876646089};\\\", \\\"{x:490,y:477,t:1527876646107};\\\", \\\"{x:491,y:479,t:1527876646122};\\\", \\\"{x:492,y:486,t:1527876646139};\\\", \\\"{x:494,y:487,t:1527876646155};\\\", \\\"{x:494,y:489,t:1527876646172};\\\", \\\"{x:495,y:492,t:1527876646190};\\\", \\\"{x:496,y:493,t:1527876646206};\\\", \\\"{x:497,y:493,t:1527876647674};\\\", \\\"{x:499,y:496,t:1527876647690};\\\", \\\"{x:508,y:503,t:1527876647707};\\\", \\\"{x:511,y:506,t:1527876647724};\\\", \\\"{x:512,y:506,t:1527876648955};\\\", \\\"{x:516,y:506,t:1527876648962};\\\", \\\"{x:521,y:506,t:1527876648975};\\\", \\\"{x:528,y:506,t:1527876648992};\\\", \\\"{x:533,y:506,t:1527876649008};\\\", \\\"{x:538,y:506,t:1527876649025};\\\", \\\"{x:551,y:504,t:1527876649042};\\\", \\\"{x:558,y:503,t:1527876649058};\\\", \\\"{x:559,y:503,t:1527876649075};\\\", \\\"{x:561,y:503,t:1527876649379};\\\", \\\"{x:562,y:503,t:1527876649392};\\\", \\\"{x:563,y:501,t:1527876649409};\\\", \\\"{x:564,y:501,t:1527876649499};\\\", \\\"{x:567,y:501,t:1527876649509};\\\", \\\"{x:583,y:503,t:1527876649525};\\\", \\\"{x:608,y:513,t:1527876649542};\\\", \\\"{x:647,y:521,t:1527876649559};\\\", \\\"{x:697,y:533,t:1527876649575};\\\", \\\"{x:738,y:538,t:1527876649592};\\\", \\\"{x:764,y:542,t:1527876649609};\\\", \\\"{x:787,y:545,t:1527876649625};\\\", \\\"{x:807,y:549,t:1527876649642};\\\", \\\"{x:814,y:552,t:1527876649659};\\\", \\\"{x:818,y:553,t:1527876649675};\\\", \\\"{x:824,y:555,t:1527876649692};\\\", \\\"{x:831,y:558,t:1527876649711};\\\", \\\"{x:840,y:560,t:1527876649726};\\\", \\\"{x:871,y:565,t:1527876649759};\\\", \\\"{x:880,y:567,t:1527876649768};\\\", \\\"{x:897,y:567,t:1527876649785};\\\", \\\"{x:913,y:567,t:1527876649800};\\\", \\\"{x:930,y:569,t:1527876649817};\\\", \\\"{x:945,y:569,t:1527876649834};\\\", \\\"{x:957,y:570,t:1527876649852};\\\", \\\"{x:970,y:571,t:1527876649868};\\\", \\\"{x:978,y:571,t:1527876649893};\\\", \\\"{x:983,y:573,t:1527876649909};\\\", \\\"{x:989,y:574,t:1527876649925};\\\", \\\"{x:997,y:575,t:1527876649943};\\\", \\\"{x:1006,y:578,t:1527876649958};\\\", \\\"{x:1011,y:580,t:1527876649976};\\\", \\\"{x:1016,y:582,t:1527876649993};\\\", \\\"{x:1018,y:583,t:1527876650009};\\\", \\\"{x:1019,y:584,t:1527876650025};\\\", \\\"{x:1021,y:584,t:1527876650395};\\\", \\\"{x:1025,y:585,t:1527876650410};\\\", \\\"{x:1041,y:588,t:1527876650426};\\\", \\\"{x:1058,y:592,t:1527876650443};\\\", \\\"{x:1080,y:597,t:1527876650459};\\\", \\\"{x:1102,y:600,t:1527876650476};\\\", \\\"{x:1124,y:603,t:1527876650493};\\\", \\\"{x:1146,y:603,t:1527876650510};\\\", \\\"{x:1165,y:603,t:1527876650526};\\\", \\\"{x:1176,y:603,t:1527876650543};\\\", \\\"{x:1180,y:603,t:1527876650560};\\\", \\\"{x:1181,y:603,t:1527876650576};\\\", \\\"{x:1183,y:603,t:1527876650739};\\\", \\\"{x:1188,y:601,t:1527876650747};\\\", \\\"{x:1192,y:596,t:1527876650760};\\\", \\\"{x:1200,y:588,t:1527876650776};\\\", \\\"{x:1209,y:583,t:1527876650793};\\\", \\\"{x:1223,y:573,t:1527876650811};\\\", \\\"{x:1232,y:568,t:1527876650826};\\\", \\\"{x:1240,y:563,t:1527876650843};\\\", \\\"{x:1249,y:558,t:1527876650860};\\\", \\\"{x:1257,y:554,t:1527876650877};\\\", \\\"{x:1262,y:551,t:1527876650894};\\\", \\\"{x:1266,y:547,t:1527876650910};\\\", \\\"{x:1273,y:542,t:1527876650926};\\\", \\\"{x:1278,y:538,t:1527876650943};\\\", \\\"{x:1287,y:532,t:1527876650960};\\\", \\\"{x:1296,y:526,t:1527876650976};\\\", \\\"{x:1305,y:519,t:1527876650993};\\\", \\\"{x:1322,y:509,t:1527876651010};\\\", \\\"{x:1330,y:504,t:1527876651026};\\\", \\\"{x:1335,y:500,t:1527876651043};\\\", \\\"{x:1338,y:497,t:1527876651060};\\\", \\\"{x:1341,y:495,t:1527876651076};\\\", \\\"{x:1342,y:495,t:1527876651093};\\\", \\\"{x:1342,y:494,t:1527876651110};\\\", \\\"{x:1342,y:493,t:1527876651219};\\\", \\\"{x:1341,y:493,t:1527876651234};\\\", \\\"{x:1338,y:493,t:1527876651243};\\\", \\\"{x:1333,y:494,t:1527876651260};\\\", \\\"{x:1329,y:495,t:1527876651276};\\\", \\\"{x:1326,y:496,t:1527876651293};\\\", \\\"{x:1324,y:497,t:1527876651310};\\\", \\\"{x:1323,y:497,t:1527876651354};\\\", \\\"{x:1321,y:497,t:1527876651362};\\\", \\\"{x:1321,y:498,t:1527876651376};\\\", \\\"{x:1319,y:499,t:1527876651400};\\\", \\\"{x:1317,y:501,t:1527876651409};\\\", \\\"{x:1316,y:501,t:1527876651490};\\\", \\\"{x:1314,y:502,t:1527876651497};\\\", \\\"{x:1313,y:502,t:1527876651509};\\\", \\\"{x:1311,y:503,t:1527876651528};\\\", \\\"{x:1308,y:504,t:1527876651544};\\\", \\\"{x:1307,y:504,t:1527876651560};\\\", \\\"{x:1308,y:503,t:1527876651827};\\\", \\\"{x:1310,y:502,t:1527876651844};\\\", \\\"{x:1313,y:501,t:1527876651865};\\\", \\\"{x:1314,y:500,t:1527876651877};\\\", \\\"{x:1314,y:499,t:1527876651893};\\\", \\\"{x:1314,y:500,t:1527876658259};\\\", \\\"{x:1314,y:503,t:1527876658270};\\\", \\\"{x:1314,y:509,t:1527876658281};\\\", \\\"{x:1314,y:515,t:1527876658299};\\\", \\\"{x:1314,y:520,t:1527876658316};\\\", \\\"{x:1314,y:524,t:1527876658332};\\\", \\\"{x:1314,y:527,t:1527876658349};\\\", \\\"{x:1314,y:530,t:1527876658366};\\\", \\\"{x:1314,y:533,t:1527876658383};\\\", \\\"{x:1313,y:537,t:1527876658398};\\\", \\\"{x:1313,y:541,t:1527876658416};\\\", \\\"{x:1312,y:547,t:1527876658432};\\\", \\\"{x:1312,y:549,t:1527876658449};\\\", \\\"{x:1312,y:554,t:1527876658465};\\\", \\\"{x:1312,y:556,t:1527876658483};\\\", \\\"{x:1311,y:558,t:1527876658499};\\\", \\\"{x:1311,y:560,t:1527876658516};\\\", \\\"{x:1310,y:563,t:1527876658533};\\\", \\\"{x:1310,y:565,t:1527876658549};\\\", \\\"{x:1310,y:567,t:1527876658566};\\\", \\\"{x:1310,y:568,t:1527876658583};\\\", \\\"{x:1309,y:572,t:1527876658599};\\\", \\\"{x:1309,y:574,t:1527876658617};\\\", \\\"{x:1309,y:578,t:1527876658633};\\\", \\\"{x:1308,y:581,t:1527876658649};\\\", \\\"{x:1307,y:583,t:1527876658666};\\\", \\\"{x:1307,y:584,t:1527876658683};\\\", \\\"{x:1307,y:585,t:1527876658729};\\\", \\\"{x:1307,y:586,t:1527876658753};\\\", \\\"{x:1307,y:587,t:1527876658776};\\\", \\\"{x:1307,y:588,t:1527876658808};\\\", \\\"{x:1307,y:589,t:1527876658817};\\\", \\\"{x:1307,y:591,t:1527876658833};\\\", \\\"{x:1307,y:593,t:1527876658858};\\\", \\\"{x:1307,y:594,t:1527876658873};\\\", \\\"{x:1307,y:596,t:1527876658889};\\\", \\\"{x:1307,y:598,t:1527876658914};\\\", \\\"{x:1307,y:599,t:1527876658929};\\\", \\\"{x:1307,y:600,t:1527876658945};\\\", \\\"{x:1308,y:602,t:1527876658962};\\\", \\\"{x:1308,y:603,t:1527876658978};\\\", \\\"{x:1308,y:604,t:1527876658994};\\\", \\\"{x:1308,y:605,t:1527876659011};\\\", \\\"{x:1310,y:607,t:1527876659020};\\\", \\\"{x:1310,y:609,t:1527876659041};\\\", \\\"{x:1310,y:610,t:1527876659065};\\\", \\\"{x:1310,y:612,t:1527876659097};\\\", \\\"{x:1311,y:612,t:1527876659105};\\\", \\\"{x:1311,y:613,t:1527876659121};\\\", \\\"{x:1312,y:614,t:1527876659154};\\\", \\\"{x:1312,y:615,t:1527876659166};\\\", \\\"{x:1312,y:616,t:1527876659183};\\\", \\\"{x:1313,y:617,t:1527876659200};\\\", \\\"{x:1313,y:619,t:1527876659219};\\\", \\\"{x:1314,y:620,t:1527876659250};\\\", \\\"{x:1314,y:621,t:1527876659282};\\\", \\\"{x:1314,y:622,t:1527876659300};\\\", \\\"{x:1315,y:623,t:1527876659317};\\\", \\\"{x:1315,y:624,t:1527876659362};\\\", \\\"{x:1315,y:625,t:1527876659389};\\\", \\\"{x:1315,y:626,t:1527876659417};\\\", \\\"{x:1316,y:627,t:1527876659441};\\\", \\\"{x:1316,y:628,t:1527876659457};\\\", \\\"{x:1316,y:629,t:1527876659481};\\\", \\\"{x:1316,y:630,t:1527876659489};\\\", \\\"{x:1316,y:631,t:1527876659505};\\\", \\\"{x:1316,y:633,t:1527876659521};\\\", \\\"{x:1316,y:634,t:1527876659569};\\\", \\\"{x:1316,y:637,t:1527876660645};\\\", \\\"{x:1331,y:663,t:1527876660667};\\\", \\\"{x:1346,y:689,t:1527876660684};\\\", \\\"{x:1363,y:714,t:1527876660701};\\\", \\\"{x:1377,y:735,t:1527876660718};\\\", \\\"{x:1388,y:745,t:1527876660734};\\\", \\\"{x:1394,y:752,t:1527876660751};\\\", \\\"{x:1395,y:753,t:1527876660768};\\\", \\\"{x:1395,y:754,t:1527876660850};\\\", \\\"{x:1394,y:754,t:1527876660985};\\\", \\\"{x:1392,y:754,t:1527876661001};\\\", \\\"{x:1388,y:754,t:1527876661017};\\\", \\\"{x:1384,y:755,t:1527876661034};\\\", \\\"{x:1380,y:757,t:1527876661051};\\\", \\\"{x:1377,y:757,t:1527876661068};\\\", \\\"{x:1377,y:758,t:1527876661106};\\\", \\\"{x:1376,y:758,t:1527876661258};\\\", \\\"{x:1374,y:759,t:1527876661274};\\\", \\\"{x:1373,y:759,t:1527876661421};\\\", \\\"{x:1372,y:760,t:1527876661435};\\\", \\\"{x:1370,y:760,t:1527876661458};\\\", \\\"{x:1370,y:761,t:1527876661587};\\\", \\\"{x:1370,y:763,t:1527876661603};\\\", \\\"{x:1369,y:763,t:1527876661619};\\\", \\\"{x:1368,y:765,t:1527876661643};\\\", \\\"{x:1367,y:767,t:1527876661659};\\\", \\\"{x:1366,y:768,t:1527876661674};\\\", \\\"{x:1365,y:769,t:1527876661685};\\\", \\\"{x:1364,y:770,t:1527876661702};\\\", \\\"{x:1364,y:771,t:1527876661738};\\\", \\\"{x:1364,y:770,t:1527876662026};\\\", \\\"{x:1364,y:769,t:1527876662035};\\\", \\\"{x:1365,y:768,t:1527876662058};\\\", \\\"{x:1366,y:768,t:1527876662193};\\\", \\\"{x:1369,y:768,t:1527876662202};\\\", \\\"{x:1370,y:768,t:1527876662219};\\\", \\\"{x:1371,y:768,t:1527876662235};\\\", \\\"{x:1372,y:768,t:1527876662265};\\\", \\\"{x:1373,y:768,t:1527876662330};\\\", \\\"{x:1374,y:768,t:1527876662338};\\\", \\\"{x:1375,y:767,t:1527876662352};\\\", \\\"{x:1377,y:765,t:1527876662371};\\\", \\\"{x:1380,y:763,t:1527876662385};\\\", \\\"{x:1381,y:762,t:1527876662402};\\\", \\\"{x:1382,y:761,t:1527876662419};\\\", \\\"{x:1383,y:760,t:1527876662538};\\\", \\\"{x:1384,y:760,t:1527876662552};\\\", \\\"{x:1385,y:760,t:1527876662577};\\\", \\\"{x:1386,y:760,t:1527876662626};\\\", \\\"{x:1387,y:761,t:1527876663178};\\\", \\\"{x:1387,y:767,t:1527876663186};\\\", \\\"{x:1386,y:780,t:1527876663203};\\\", \\\"{x:1382,y:792,t:1527876663219};\\\", \\\"{x:1381,y:802,t:1527876663236};\\\", \\\"{x:1380,y:807,t:1527876663253};\\\", \\\"{x:1379,y:811,t:1527876663269};\\\", \\\"{x:1378,y:818,t:1527876663286};\\\", \\\"{x:1377,y:823,t:1527876663303};\\\", \\\"{x:1376,y:836,t:1527876663319};\\\", \\\"{x:1373,y:853,t:1527876663336};\\\", \\\"{x:1366,y:879,t:1527876663353};\\\", \\\"{x:1361,y:893,t:1527876663369};\\\", \\\"{x:1357,y:899,t:1527876663386};\\\", \\\"{x:1355,y:901,t:1527876663403};\\\", \\\"{x:1354,y:902,t:1527876663482};\\\", \\\"{x:1354,y:904,t:1527876663490};\\\", \\\"{x:1353,y:905,t:1527876663505};\\\", \\\"{x:1353,y:906,t:1527876663520};\\\", \\\"{x:1351,y:908,t:1527876663536};\\\", \\\"{x:1351,y:909,t:1527876663553};\\\", \\\"{x:1350,y:909,t:1527876663649};\\\", \\\"{x:1350,y:908,t:1527876663657};\\\", \\\"{x:1350,y:907,t:1527876663670};\\\", \\\"{x:1350,y:905,t:1527876663686};\\\", \\\"{x:1348,y:901,t:1527876663705};\\\", \\\"{x:1348,y:899,t:1527876663720};\\\", \\\"{x:1348,y:898,t:1527876663736};\\\", \\\"{x:1348,y:897,t:1527876663753};\\\", \\\"{x:1347,y:897,t:1527876663880};\\\", \\\"{x:1347,y:896,t:1527876664634};\\\", \\\"{x:1346,y:896,t:1527876664642};\\\", \\\"{x:1346,y:895,t:1527876664655};\\\", \\\"{x:1345,y:895,t:1527876664671};\\\", \\\"{x:1345,y:894,t:1527876664687};\\\", \\\"{x:1345,y:893,t:1527876664762};\\\", \\\"{x:1344,y:893,t:1527876664772};\\\", \\\"{x:1343,y:892,t:1527876664790};\\\", \\\"{x:1342,y:892,t:1527876664809};\\\", \\\"{x:1342,y:891,t:1527876664821};\\\", \\\"{x:1340,y:890,t:1527876664837};\\\", \\\"{x:1339,y:888,t:1527876664854};\\\", \\\"{x:1336,y:886,t:1527876664871};\\\", \\\"{x:1333,y:883,t:1527876664887};\\\", \\\"{x:1328,y:879,t:1527876664904};\\\", \\\"{x:1316,y:872,t:1527876664921};\\\", \\\"{x:1309,y:867,t:1527876664937};\\\", \\\"{x:1302,y:864,t:1527876664954};\\\", \\\"{x:1298,y:861,t:1527876664971};\\\", \\\"{x:1295,y:860,t:1527876664987};\\\", \\\"{x:1294,y:860,t:1527876665005};\\\", \\\"{x:1294,y:859,t:1527876665021};\\\", \\\"{x:1293,y:859,t:1527876665037};\\\", \\\"{x:1292,y:857,t:1527876665114};\\\", \\\"{x:1290,y:855,t:1527876665138};\\\", \\\"{x:1290,y:854,t:1527876665170};\\\", \\\"{x:1290,y:852,t:1527876665178};\\\", \\\"{x:1290,y:851,t:1527876665189};\\\", \\\"{x:1288,y:848,t:1527876665204};\\\", \\\"{x:1288,y:846,t:1527876665221};\\\", \\\"{x:1288,y:842,t:1527876665238};\\\", \\\"{x:1288,y:838,t:1527876665255};\\\", \\\"{x:1287,y:835,t:1527876665271};\\\", \\\"{x:1287,y:834,t:1527876665289};\\\", \\\"{x:1286,y:831,t:1527876665307};\\\", \\\"{x:1285,y:830,t:1527876665321};\\\", \\\"{x:1284,y:828,t:1527876665338};\\\", \\\"{x:1284,y:826,t:1527876665354};\\\", \\\"{x:1283,y:826,t:1527876665371};\\\", \\\"{x:1282,y:825,t:1527876665388};\\\", \\\"{x:1282,y:824,t:1527876665410};\\\", \\\"{x:1281,y:823,t:1527876665433};\\\", \\\"{x:1279,y:822,t:1527876665674};\\\", \\\"{x:1278,y:822,t:1527876665706};\\\", \\\"{x:1277,y:822,t:1527876665721};\\\", \\\"{x:1277,y:823,t:1527876665738};\\\", \\\"{x:1276,y:824,t:1527876665755};\\\", \\\"{x:1275,y:825,t:1527876665773};\\\", \\\"{x:1275,y:827,t:1527876665803};\\\", \\\"{x:1275,y:828,t:1527876665826};\\\", \\\"{x:1274,y:829,t:1527876665842};\\\", \\\"{x:1274,y:830,t:1527876666187};\\\", \\\"{x:1273,y:831,t:1527876666194};\\\", \\\"{x:1273,y:833,t:1527876666210};\\\", \\\"{x:1273,y:834,t:1527876666223};\\\", \\\"{x:1273,y:835,t:1527876666239};\\\", \\\"{x:1273,y:836,t:1527876666467};\\\", \\\"{x:1273,y:837,t:1527876666522};\\\", \\\"{x:1274,y:837,t:1527876666546};\\\", \\\"{x:1275,y:838,t:1527876666562};\\\", \\\"{x:1276,y:838,t:1527876666594};\\\", \\\"{x:1277,y:838,t:1527876666802};\\\", \\\"{x:1279,y:838,t:1527876666810};\\\", \\\"{x:1279,y:837,t:1527876666822};\\\", \\\"{x:1279,y:835,t:1527876666842};\\\", \\\"{x:1280,y:832,t:1527876666855};\\\", \\\"{x:1280,y:831,t:1527876666872};\\\", \\\"{x:1281,y:829,t:1527876666889};\\\", \\\"{x:1279,y:829,t:1527876667914};\\\", \\\"{x:1278,y:829,t:1527876667946};\\\", \\\"{x:1273,y:831,t:1527876667973};\\\", \\\"{x:1268,y:833,t:1527876667990};\\\", \\\"{x:1267,y:833,t:1527876668006};\\\", \\\"{x:1264,y:835,t:1527876668023};\\\", \\\"{x:1262,y:835,t:1527876668040};\\\", \\\"{x:1261,y:835,t:1527876668056};\\\", \\\"{x:1260,y:835,t:1527876668081};\\\", \\\"{x:1259,y:835,t:1527876668097};\\\", \\\"{x:1258,y:837,t:1527876668113};\\\", \\\"{x:1256,y:837,t:1527876668123};\\\", \\\"{x:1253,y:837,t:1527876668140};\\\", \\\"{x:1248,y:838,t:1527876668157};\\\", \\\"{x:1245,y:838,t:1527876668173};\\\", \\\"{x:1240,y:839,t:1527876668190};\\\", \\\"{x:1237,y:839,t:1527876668208};\\\", \\\"{x:1233,y:839,t:1527876668223};\\\", \\\"{x:1230,y:839,t:1527876668240};\\\", \\\"{x:1224,y:839,t:1527876668257};\\\", \\\"{x:1222,y:839,t:1527876668274};\\\", \\\"{x:1220,y:839,t:1527876668290};\\\", \\\"{x:1219,y:839,t:1527876668308};\\\", \\\"{x:1217,y:839,t:1527876668324};\\\", \\\"{x:1216,y:839,t:1527876668349};\\\", \\\"{x:1215,y:839,t:1527876668361};\\\", \\\"{x:1214,y:839,t:1527876668377};\\\", \\\"{x:1213,y:839,t:1527876668418};\\\", \\\"{x:1212,y:838,t:1527876668866};\\\", \\\"{x:1211,y:837,t:1527876669147};\\\", \\\"{x:1211,y:835,t:1527876669158};\\\", \\\"{x:1211,y:834,t:1527876669182};\\\", \\\"{x:1211,y:832,t:1527876669224};\\\", \\\"{x:1208,y:832,t:1527876670029};\\\", \\\"{x:1193,y:834,t:1527876670041};\\\", \\\"{x:1169,y:834,t:1527876670058};\\\", \\\"{x:1145,y:836,t:1527876670075};\\\", \\\"{x:1117,y:839,t:1527876670092};\\\", \\\"{x:1080,y:842,t:1527876670108};\\\", \\\"{x:1038,y:842,t:1527876670125};\\\", \\\"{x:988,y:842,t:1527876670142};\\\", \\\"{x:945,y:840,t:1527876670158};\\\", \\\"{x:891,y:833,t:1527876670175};\\\", \\\"{x:849,y:819,t:1527876670191};\\\", \\\"{x:816,y:806,t:1527876670208};\\\", \\\"{x:758,y:777,t:1527876670225};\\\", \\\"{x:731,y:762,t:1527876670242};\\\", \\\"{x:709,y:749,t:1527876670258};\\\", \\\"{x:692,y:745,t:1527876670276};\\\", \\\"{x:668,y:742,t:1527876670292};\\\", \\\"{x:637,y:742,t:1527876670308};\\\", \\\"{x:607,y:741,t:1527876670325};\\\", \\\"{x:577,y:735,t:1527876670342};\\\", \\\"{x:554,y:729,t:1527876670358};\\\", \\\"{x:515,y:723,t:1527876670375};\\\", \\\"{x:476,y:717,t:1527876670392};\\\", \\\"{x:451,y:717,t:1527876670408};\\\", \\\"{x:415,y:717,t:1527876670425};\\\", \\\"{x:390,y:717,t:1527876670442};\\\", \\\"{x:366,y:717,t:1527876670458};\\\", \\\"{x:358,y:717,t:1527876670475};\\\", \\\"{x:359,y:713,t:1527876670546};\\\", \\\"{x:366,y:710,t:1527876670559};\\\", \\\"{x:386,y:702,t:1527876670575};\\\", \\\"{x:426,y:695,t:1527876670595};\\\", \\\"{x:471,y:690,t:1527876670608};\\\", \\\"{x:546,y:690,t:1527876670625};\\\", \\\"{x:602,y:690,t:1527876670642};\\\", \\\"{x:663,y:690,t:1527876670659};\\\", \\\"{x:710,y:685,t:1527876670675};\\\", \\\"{x:750,y:678,t:1527876670693};\\\", \\\"{x:773,y:673,t:1527876670709};\\\", \\\"{x:792,y:667,t:1527876670725};\\\", \\\"{x:802,y:663,t:1527876670742};\\\", \\\"{x:804,y:661,t:1527876670759};\\\", \\\"{x:806,y:660,t:1527876670775};\\\", \\\"{x:808,y:659,t:1527876670809};\\\", \\\"{x:809,y:657,t:1527876670825};\\\", \\\"{x:810,y:655,t:1527876670842};\\\", \\\"{x:811,y:655,t:1527876670859};\\\", \\\"{x:811,y:654,t:1527876670922};\\\", \\\"{x:810,y:651,t:1527876670930};\\\", \\\"{x:798,y:651,t:1527876670943};\\\", \\\"{x:761,y:651,t:1527876670960};\\\", \\\"{x:730,y:651,t:1527876670975};\\\", \\\"{x:709,y:651,t:1527876670993};\\\", \\\"{x:680,y:644,t:1527876671009};\\\", \\\"{x:639,y:631,t:1527876671026};\\\", \\\"{x:590,y:622,t:1527876671043};\\\", \\\"{x:542,y:614,t:1527876671059};\\\", \\\"{x:486,y:606,t:1527876671076};\\\", \\\"{x:447,y:601,t:1527876671092};\\\", \\\"{x:441,y:600,t:1527876671110};\\\", \\\"{x:437,y:600,t:1527876671466};\\\", \\\"{x:434,y:600,t:1527876671477};\\\", \\\"{x:427,y:597,t:1527876671493};\\\", \\\"{x:415,y:595,t:1527876671510};\\\", \\\"{x:407,y:594,t:1527876671527};\\\", \\\"{x:399,y:594,t:1527876671543};\\\", \\\"{x:391,y:594,t:1527876671559};\\\", \\\"{x:377,y:594,t:1527876671577};\\\", \\\"{x:359,y:594,t:1527876671592};\\\", \\\"{x:347,y:598,t:1527876671609};\\\", \\\"{x:340,y:601,t:1527876671626};\\\", \\\"{x:338,y:601,t:1527876672034};\\\", \\\"{x:337,y:601,t:1527876672043};\\\", \\\"{x:336,y:601,t:1527876672081};\\\", \\\"{x:335,y:602,t:1527876672094};\\\", \\\"{x:332,y:603,t:1527876672111};\\\", \\\"{x:325,y:604,t:1527876672127};\\\", \\\"{x:317,y:605,t:1527876672144};\\\", \\\"{x:305,y:608,t:1527876672161};\\\", \\\"{x:282,y:611,t:1527876672177};\\\", \\\"{x:266,y:612,t:1527876672196};\\\", \\\"{x:258,y:616,t:1527876672210};\\\", \\\"{x:256,y:616,t:1527876672226};\\\", \\\"{x:254,y:616,t:1527876672297};\\\", \\\"{x:253,y:616,t:1527876672313};\\\", \\\"{x:249,y:616,t:1527876672326};\\\", \\\"{x:230,y:615,t:1527876672343};\\\", \\\"{x:197,y:606,t:1527876672361};\\\", \\\"{x:166,y:601,t:1527876672377};\\\", \\\"{x:133,y:598,t:1527876672394};\\\", \\\"{x:119,y:598,t:1527876672410};\\\", \\\"{x:112,y:596,t:1527876672426};\\\", \\\"{x:110,y:596,t:1527876672444};\\\", \\\"{x:109,y:594,t:1527876672562};\\\", \\\"{x:111,y:594,t:1527876672577};\\\", \\\"{x:135,y:608,t:1527876672594};\\\", \\\"{x:142,y:610,t:1527876672611};\\\", \\\"{x:147,y:612,t:1527876672627};\\\", \\\"{x:150,y:613,t:1527876672644};\\\", \\\"{x:157,y:613,t:1527876673274};\\\", \\\"{x:169,y:613,t:1527876673281};\\\", \\\"{x:181,y:613,t:1527876673295};\\\", \\\"{x:229,y:613,t:1527876673312};\\\", \\\"{x:282,y:613,t:1527876673328};\\\", \\\"{x:344,y:612,t:1527876673345};\\\", \\\"{x:466,y:612,t:1527876673361};\\\", \\\"{x:549,y:604,t:1527876673378};\\\", \\\"{x:614,y:599,t:1527876673395};\\\", \\\"{x:662,y:593,t:1527876673411};\\\", \\\"{x:696,y:588,t:1527876673428};\\\", \\\"{x:719,y:583,t:1527876673446};\\\", \\\"{x:736,y:577,t:1527876673462};\\\", \\\"{x:755,y:572,t:1527876673477};\\\", \\\"{x:768,y:569,t:1527876673494};\\\", \\\"{x:779,y:567,t:1527876673512};\\\", \\\"{x:785,y:563,t:1527876673527};\\\", \\\"{x:794,y:562,t:1527876673545};\\\", \\\"{x:818,y:554,t:1527876673561};\\\", \\\"{x:841,y:551,t:1527876673577};\\\", \\\"{x:869,y:543,t:1527876673594};\\\", \\\"{x:889,y:537,t:1527876673611};\\\", \\\"{x:911,y:529,t:1527876673628};\\\", \\\"{x:936,y:524,t:1527876673644};\\\", \\\"{x:961,y:518,t:1527876673661};\\\", \\\"{x:990,y:513,t:1527876673678};\\\", \\\"{x:1021,y:511,t:1527876673694};\\\", \\\"{x:1056,y:508,t:1527876673711};\\\", \\\"{x:1090,y:508,t:1527876673728};\\\", \\\"{x:1126,y:508,t:1527876673745};\\\", \\\"{x:1170,y:508,t:1527876673762};\\\", \\\"{x:1192,y:508,t:1527876673777};\\\", \\\"{x:1208,y:508,t:1527876673795};\\\", \\\"{x:1216,y:507,t:1527876673812};\\\", \\\"{x:1217,y:507,t:1527876673874};\\\", \\\"{x:1218,y:507,t:1527876673890};\\\", \\\"{x:1219,y:507,t:1527876673906};\\\", \\\"{x:1220,y:507,t:1527876673922};\\\", \\\"{x:1223,y:507,t:1527876673929};\\\", \\\"{x:1227,y:506,t:1527876673945};\\\", \\\"{x:1242,y:504,t:1527876673961};\\\", \\\"{x:1253,y:502,t:1527876673979};\\\", \\\"{x:1259,y:501,t:1527876673995};\\\", \\\"{x:1264,y:500,t:1527876674012};\\\", \\\"{x:1268,y:500,t:1527876674029};\\\", \\\"{x:1270,y:499,t:1527876674045};\\\", \\\"{x:1271,y:499,t:1527876674062};\\\", \\\"{x:1273,y:499,t:1527876674078};\\\", \\\"{x:1274,y:499,t:1527876674095};\\\", \\\"{x:1276,y:499,t:1527876674111};\\\", \\\"{x:1279,y:499,t:1527876674128};\\\", \\\"{x:1282,y:499,t:1527876674144};\\\", \\\"{x:1290,y:499,t:1527876674161};\\\", \\\"{x:1293,y:499,t:1527876674178};\\\", \\\"{x:1298,y:499,t:1527876674195};\\\", \\\"{x:1299,y:499,t:1527876674211};\\\", \\\"{x:1300,y:498,t:1527876674228};\\\", \\\"{x:1301,y:498,t:1527876674244};\\\", \\\"{x:1303,y:498,t:1527876674262};\\\", \\\"{x:1305,y:498,t:1527876674279};\\\", \\\"{x:1306,y:498,t:1527876674296};\\\", \\\"{x:1307,y:498,t:1527876674321};\\\", \\\"{x:1308,y:498,t:1527876674338};\\\", \\\"{x:1310,y:498,t:1527876674349};\\\", \\\"{x:1314,y:500,t:1527876674361};\\\", \\\"{x:1317,y:500,t:1527876674378};\\\", \\\"{x:1318,y:501,t:1527876674395};\\\", \\\"{x:1319,y:501,t:1527876674412};\\\", \\\"{x:1319,y:500,t:1527876674514};\\\", \\\"{x:1319,y:505,t:1527876676717};\\\", \\\"{x:1321,y:525,t:1527876676731};\\\", \\\"{x:1325,y:545,t:1527876676746};\\\", \\\"{x:1326,y:556,t:1527876676763};\\\", \\\"{x:1327,y:559,t:1527876676780};\\\", \\\"{x:1327,y:560,t:1527876676801};\\\", \\\"{x:1327,y:561,t:1527876676813};\\\", \\\"{x:1327,y:563,t:1527876676830};\\\", \\\"{x:1328,y:566,t:1527876676846};\\\", \\\"{x:1328,y:568,t:1527876676863};\\\", \\\"{x:1328,y:570,t:1527876676881};\\\", \\\"{x:1328,y:571,t:1527876676897};\\\", \\\"{x:1328,y:572,t:1527876676914};\\\", \\\"{x:1329,y:573,t:1527876676931};\\\", \\\"{x:1329,y:576,t:1527876676947};\\\", \\\"{x:1330,y:577,t:1527876676964};\\\", \\\"{x:1330,y:578,t:1527876677075};\\\", \\\"{x:1330,y:582,t:1527876677082};\\\", \\\"{x:1331,y:590,t:1527876677097};\\\", \\\"{x:1331,y:596,t:1527876677114};\\\", \\\"{x:1332,y:605,t:1527876677131};\\\", \\\"{x:1335,y:618,t:1527876677147};\\\", \\\"{x:1337,y:636,t:1527876677164};\\\", \\\"{x:1341,y:656,t:1527876677181};\\\", \\\"{x:1349,y:689,t:1527876677198};\\\", \\\"{x:1360,y:738,t:1527876677214};\\\", \\\"{x:1369,y:776,t:1527876677231};\\\", \\\"{x:1376,y:809,t:1527876677248};\\\", \\\"{x:1379,y:829,t:1527876677264};\\\", \\\"{x:1380,y:837,t:1527876677281};\\\", \\\"{x:1380,y:841,t:1527876677297};\\\", \\\"{x:1380,y:842,t:1527876677338};\\\", \\\"{x:1380,y:844,t:1527876677348};\\\", \\\"{x:1380,y:850,t:1527876677365};\\\", \\\"{x:1379,y:863,t:1527876677380};\\\", \\\"{x:1377,y:882,t:1527876677398};\\\", \\\"{x:1374,y:894,t:1527876677415};\\\", \\\"{x:1374,y:895,t:1527876677431};\\\", \\\"{x:1374,y:896,t:1527876677642};\\\", \\\"{x:1372,y:896,t:1527876677650};\\\", \\\"{x:1371,y:896,t:1527876677666};\\\", \\\"{x:1369,y:895,t:1527876677681};\\\", \\\"{x:1368,y:895,t:1527876677706};\\\", \\\"{x:1367,y:895,t:1527876677722};\\\", \\\"{x:1366,y:895,t:1527876677738};\\\", \\\"{x:1365,y:895,t:1527876677748};\\\", \\\"{x:1362,y:895,t:1527876677765};\\\", \\\"{x:1359,y:897,t:1527876677782};\\\", \\\"{x:1357,y:900,t:1527876677798};\\\", \\\"{x:1354,y:903,t:1527876677815};\\\", \\\"{x:1352,y:904,t:1527876677832};\\\", \\\"{x:1351,y:904,t:1527876678043};\\\", \\\"{x:1350,y:904,t:1527876678057};\\\", \\\"{x:1350,y:903,t:1527876678074};\\\", \\\"{x:1348,y:902,t:1527876678094};\\\", \\\"{x:1348,y:901,t:1527876678115};\\\", \\\"{x:1348,y:900,t:1527876678131};\\\", \\\"{x:1348,y:898,t:1527876678147};\\\", \\\"{x:1347,y:898,t:1527876678378};\\\", \\\"{x:1344,y:896,t:1527876678385};\\\", \\\"{x:1310,y:892,t:1527876678415};\\\", \\\"{x:1247,y:890,t:1527876678432};\\\", \\\"{x:1140,y:882,t:1527876678448};\\\", \\\"{x:1021,y:882,t:1527876678465};\\\", \\\"{x:871,y:882,t:1527876678482};\\\", \\\"{x:810,y:882,t:1527876678499};\\\", \\\"{x:782,y:882,t:1527876678515};\\\", \\\"{x:770,y:880,t:1527876678532};\\\", \\\"{x:767,y:879,t:1527876678549};\\\", \\\"{x:766,y:878,t:1527876678570};\\\", \\\"{x:766,y:877,t:1527876678586};\\\", \\\"{x:766,y:876,t:1527876678599};\\\", \\\"{x:766,y:872,t:1527876678615};\\\", \\\"{x:766,y:868,t:1527876678632};\\\", \\\"{x:758,y:858,t:1527876678649};\\\", \\\"{x:729,y:842,t:1527876678666};\\\", \\\"{x:699,y:827,t:1527876678682};\\\", \\\"{x:672,y:813,t:1527876678699};\\\", \\\"{x:654,y:808,t:1527876678716};\\\", \\\"{x:637,y:806,t:1527876678732};\\\", \\\"{x:620,y:803,t:1527876678749};\\\", \\\"{x:611,y:803,t:1527876678766};\\\", \\\"{x:603,y:803,t:1527876678782};\\\", \\\"{x:600,y:803,t:1527876678799};\\\", \\\"{x:598,y:803,t:1527876678816};\\\", \\\"{x:597,y:803,t:1527876678832};\\\", \\\"{x:596,y:803,t:1527876678848};\\\", \\\"{x:594,y:803,t:1527876678865};\\\", \\\"{x:592,y:803,t:1527876678881};\\\", \\\"{x:589,y:800,t:1527876678899};\\\", \\\"{x:583,y:796,t:1527876678916};\\\", \\\"{x:577,y:792,t:1527876678931};\\\", \\\"{x:570,y:787,t:1527876678948};\\\", \\\"{x:563,y:783,t:1527876678966};\\\", \\\"{x:557,y:780,t:1527876678982};\\\", \\\"{x:554,y:779,t:1527876678999};\\\", \\\"{x:551,y:777,t:1527876679015};\\\", \\\"{x:549,y:775,t:1527876679033};\\\", \\\"{x:547,y:775,t:1527876679048};\\\", \\\"{x:546,y:775,t:1527876679066};\\\", \\\"{x:544,y:773,t:1527876679083};\\\", \\\"{x:541,y:773,t:1527876679098};\\\", \\\"{x:540,y:773,t:1527876679178};\\\", \\\"{x:540,y:772,t:1527876679186};\\\" ] }, { \\\"rt\\\": 14157, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 10, \\\"time_elapsed\\\": 306011, \\\"internal_node_id\\\": \\\"0.0-6.0-0.0\\\", \\\"subject\\\": \\\"HW2SN\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"xray\\\", \\\"condition\\\": \\\"311\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"duration\\\", \\\"q\\\": 6, \\\"clicks\\\": 2, \\\"explicit\\\": 3, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XInside-YFull\\\", \\\"correct\\\": 1, \\\"orth_correct\\\": 1, \\\"answer\\\": [ \\\"E\\\", \\\"G\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-E -E -E -E -E -E -G -G -G -E \\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:539,y:772,t:1527876681137};\\\", \\\"{x:539,y:773,t:1527876681151};\\\", \\\"{x:542,y:775,t:1527876681166};\\\", \\\"{x:544,y:775,t:1527876681578};\\\", \\\"{x:545,y:774,t:1527876681585};\\\", \\\"{x:547,y:773,t:1527876681601};\\\", \\\"{x:548,y:772,t:1527876681618};\\\", \\\"{x:549,y:771,t:1527876681635};\\\", \\\"{x:550,y:771,t:1527876681651};\\\", \\\"{x:551,y:771,t:1527876681668};\\\", \\\"{x:553,y:769,t:1527876681685};\\\", \\\"{x:560,y:768,t:1527876681701};\\\", \\\"{x:572,y:766,t:1527876681718};\\\", \\\"{x:585,y:764,t:1527876681735};\\\", \\\"{x:606,y:761,t:1527876681751};\\\", \\\"{x:629,y:758,t:1527876681768};\\\", \\\"{x:671,y:752,t:1527876681786};\\\", \\\"{x:702,y:747,t:1527876681801};\\\", \\\"{x:738,y:743,t:1527876681818};\\\", \\\"{x:783,y:736,t:1527876681835};\\\", \\\"{x:818,y:732,t:1527876681851};\\\", \\\"{x:847,y:727,t:1527876681868};\\\", \\\"{x:872,y:720,t:1527876681885};\\\", \\\"{x:895,y:715,t:1527876681901};\\\", \\\"{x:918,y:707,t:1527876681918};\\\", \\\"{x:943,y:700,t:1527876681936};\\\", \\\"{x:972,y:693,t:1527876681952};\\\", \\\"{x:997,y:686,t:1527876681969};\\\", \\\"{x:1026,y:675,t:1527876681985};\\\", \\\"{x:1044,y:666,t:1527876682002};\\\", \\\"{x:1059,y:655,t:1527876682018};\\\", \\\"{x:1073,y:644,t:1527876682036};\\\", \\\"{x:1089,y:630,t:1527876682052};\\\", \\\"{x:1103,y:621,t:1527876682069};\\\", \\\"{x:1113,y:614,t:1527876682086};\\\", \\\"{x:1117,y:610,t:1527876682102};\\\", \\\"{x:1119,y:609,t:1527876682118};\\\", \\\"{x:1120,y:608,t:1527876682219};\\\", \\\"{x:1120,y:606,t:1527876682235};\\\", \\\"{x:1120,y:601,t:1527876682253};\\\", \\\"{x:1116,y:594,t:1527876682268};\\\", \\\"{x:1111,y:588,t:1527876682286};\\\", \\\"{x:1106,y:582,t:1527876682302};\\\", \\\"{x:1103,y:578,t:1527876682318};\\\", \\\"{x:1101,y:575,t:1527876682335};\\\", \\\"{x:1101,y:574,t:1527876682361};\\\", \\\"{x:1101,y:572,t:1527876682369};\\\", \\\"{x:1100,y:571,t:1527876682385};\\\", \\\"{x:1100,y:568,t:1527876682401};\\\", \\\"{x:1112,y:563,t:1527876682417};\\\", \\\"{x:1131,y:559,t:1527876682435};\\\", \\\"{x:1150,y:556,t:1527876682452};\\\", \\\"{x:1168,y:552,t:1527876682468};\\\", \\\"{x:1194,y:552,t:1527876682485};\\\", \\\"{x:1218,y:552,t:1527876682502};\\\", \\\"{x:1239,y:552,t:1527876682518};\\\", \\\"{x:1254,y:552,t:1527876682535};\\\", \\\"{x:1263,y:551,t:1527876682552};\\\", \\\"{x:1266,y:551,t:1527876682568};\\\", \\\"{x:1268,y:551,t:1527876682666};\\\", \\\"{x:1273,y:553,t:1527876682674};\\\", \\\"{x:1275,y:554,t:1527876682685};\\\", \\\"{x:1280,y:556,t:1527876682703};\\\", \\\"{x:1281,y:557,t:1527876682719};\\\", \\\"{x:1282,y:557,t:1527876682735};\\\", \\\"{x:1283,y:558,t:1527876682925};\\\", \\\"{x:1283,y:560,t:1527876682951};\\\", \\\"{x:1283,y:561,t:1527876682977};\\\", \\\"{x:1283,y:563,t:1527876682985};\\\", \\\"{x:1282,y:564,t:1527876683002};\\\", \\\"{x:1280,y:565,t:1527876683018};\\\", \\\"{x:1279,y:565,t:1527876683474};\\\", \\\"{x:1278,y:565,t:1527876683487};\\\", \\\"{x:1277,y:565,t:1527876683503};\\\", \\\"{x:1275,y:565,t:1527876683520};\\\", \\\"{x:1274,y:564,t:1527876683536};\\\", \\\"{x:1274,y:563,t:1527876683552};\\\", \\\"{x:1274,y:561,t:1527876683570};\\\", \\\"{x:1274,y:560,t:1527876683586};\\\", \\\"{x:1274,y:559,t:1527876683603};\\\", \\\"{x:1274,y:558,t:1527876683619};\\\", \\\"{x:1274,y:557,t:1527876683637};\\\", \\\"{x:1274,y:555,t:1527876683653};\\\", \\\"{x:1274,y:554,t:1527876683670};\\\", \\\"{x:1274,y:551,t:1527876683686};\\\", \\\"{x:1274,y:548,t:1527876683703};\\\", \\\"{x:1274,y:545,t:1527876683720};\\\", \\\"{x:1274,y:544,t:1527876683737};\\\", \\\"{x:1274,y:542,t:1527876683754};\\\", \\\"{x:1274,y:545,t:1527876683898};\\\", \\\"{x:1274,y:549,t:1527876683906};\\\", \\\"{x:1277,y:555,t:1527876683920};\\\", \\\"{x:1278,y:562,t:1527876683937};\\\", \\\"{x:1281,y:572,t:1527876683955};\\\", \\\"{x:1282,y:575,t:1527876683969};\\\", \\\"{x:1282,y:574,t:1527876684241};\\\", \\\"{x:1282,y:573,t:1527876684256};\\\", \\\"{x:1282,y:572,t:1527876684610};\\\", \\\"{x:1282,y:569,t:1527876684620};\\\", \\\"{x:1283,y:564,t:1527876684637};\\\", \\\"{x:1284,y:560,t:1527876684653};\\\", \\\"{x:1284,y:558,t:1527876684670};\\\", \\\"{x:1284,y:557,t:1527876684688};\\\", \\\"{x:1285,y:556,t:1527876684714};\\\", \\\"{x:1285,y:557,t:1527876685218};\\\", \\\"{x:1284,y:558,t:1527876685226};\\\", \\\"{x:1282,y:561,t:1527876685237};\\\", \\\"{x:1280,y:563,t:1527876685254};\\\", \\\"{x:1279,y:565,t:1527876685270};\\\", \\\"{x:1279,y:566,t:1527876685287};\\\", \\\"{x:1279,y:567,t:1527876685305};\\\", \\\"{x:1278,y:568,t:1527876686026};\\\", \\\"{x:1278,y:566,t:1527876686050};\\\", \\\"{x:1278,y:565,t:1527876686057};\\\", \\\"{x:1278,y:564,t:1527876686089};\\\", \\\"{x:1280,y:564,t:1527876686377};\\\", \\\"{x:1284,y:564,t:1527876686388};\\\", \\\"{x:1294,y:564,t:1527876686407};\\\", \\\"{x:1303,y:564,t:1527876686421};\\\", \\\"{x:1317,y:565,t:1527876686438};\\\", \\\"{x:1332,y:566,t:1527876686456};\\\", \\\"{x:1346,y:566,t:1527876686472};\\\", \\\"{x:1358,y:569,t:1527876686489};\\\", \\\"{x:1372,y:571,t:1527876686505};\\\", \\\"{x:1378,y:571,t:1527876686522};\\\", \\\"{x:1379,y:572,t:1527876686539};\\\", \\\"{x:1380,y:572,t:1527876686666};\\\", \\\"{x:1382,y:572,t:1527876686673};\\\", \\\"{x:1384,y:572,t:1527876686689};\\\", \\\"{x:1386,y:572,t:1527876686706};\\\", \\\"{x:1393,y:571,t:1527876686722};\\\", \\\"{x:1397,y:569,t:1527876686738};\\\", \\\"{x:1406,y:565,t:1527876686755};\\\", \\\"{x:1414,y:562,t:1527876686772};\\\", \\\"{x:1420,y:561,t:1527876686789};\\\", \\\"{x:1425,y:559,t:1527876686806};\\\", \\\"{x:1433,y:557,t:1527876686821};\\\", \\\"{x:1438,y:556,t:1527876686838};\\\", \\\"{x:1441,y:555,t:1527876686855};\\\", \\\"{x:1442,y:554,t:1527876686873};\\\", \\\"{x:1441,y:554,t:1527876686994};\\\", \\\"{x:1439,y:554,t:1527876687009};\\\", \\\"{x:1438,y:554,t:1527876687022};\\\", \\\"{x:1436,y:554,t:1527876687039};\\\", \\\"{x:1433,y:554,t:1527876687055};\\\", \\\"{x:1432,y:554,t:1527876687097};\\\", \\\"{x:1431,y:554,t:1527876687105};\\\", \\\"{x:1430,y:556,t:1527876687122};\\\", \\\"{x:1428,y:559,t:1527876687139};\\\", \\\"{x:1423,y:562,t:1527876687155};\\\", \\\"{x:1416,y:566,t:1527876687173};\\\", \\\"{x:1411,y:569,t:1527876687190};\\\", \\\"{x:1405,y:570,t:1527876687206};\\\", \\\"{x:1402,y:570,t:1527876687223};\\\", \\\"{x:1401,y:571,t:1527876687239};\\\", \\\"{x:1401,y:569,t:1527876687354};\\\", \\\"{x:1401,y:567,t:1527876687372};\\\", \\\"{x:1405,y:564,t:1527876687389};\\\", \\\"{x:1406,y:564,t:1527876687406};\\\", \\\"{x:1408,y:564,t:1527876687423};\\\", \\\"{x:1409,y:564,t:1527876687440};\\\", \\\"{x:1411,y:564,t:1527876687473};\\\", \\\"{x:1412,y:563,t:1527876687490};\\\", \\\"{x:1414,y:563,t:1527876687514};\\\", \\\"{x:1415,y:563,t:1527876687531};\\\", \\\"{x:1415,y:562,t:1527876687545};\\\", \\\"{x:1414,y:562,t:1527876688174};\\\", \\\"{x:1413,y:562,t:1527876688182};\\\", \\\"{x:1411,y:562,t:1527876688193};\\\", \\\"{x:1408,y:561,t:1527876688212};\\\", \\\"{x:1404,y:561,t:1527876688226};\\\", \\\"{x:1403,y:561,t:1527876688243};\\\", \\\"{x:1401,y:561,t:1527876688261};\\\", \\\"{x:1398,y:560,t:1527876688277};\\\", \\\"{x:1390,y:560,t:1527876688294};\\\", \\\"{x:1381,y:560,t:1527876688311};\\\", \\\"{x:1364,y:563,t:1527876688328};\\\", \\\"{x:1346,y:563,t:1527876688344};\\\", \\\"{x:1330,y:564,t:1527876688361};\\\", \\\"{x:1316,y:565,t:1527876688378};\\\", \\\"{x:1310,y:567,t:1527876688394};\\\", \\\"{x:1308,y:567,t:1527876688411};\\\", \\\"{x:1307,y:567,t:1527876688430};\\\", \\\"{x:1306,y:567,t:1527876688446};\\\", \\\"{x:1305,y:567,t:1527876688461};\\\", \\\"{x:1302,y:567,t:1527876688478};\\\", \\\"{x:1298,y:568,t:1527876688494};\\\", \\\"{x:1297,y:568,t:1527876688511};\\\", \\\"{x:1296,y:568,t:1527876688528};\\\", \\\"{x:1295,y:568,t:1527876688550};\\\", \\\"{x:1294,y:568,t:1527876688574};\\\", \\\"{x:1293,y:568,t:1527876688581};\\\", \\\"{x:1292,y:568,t:1527876688594};\\\", \\\"{x:1289,y:568,t:1527876688611};\\\", \\\"{x:1286,y:568,t:1527876688628};\\\", \\\"{x:1283,y:567,t:1527876688644};\\\", \\\"{x:1280,y:566,t:1527876688660};\\\", \\\"{x:1279,y:566,t:1527876688678};\\\", \\\"{x:1277,y:564,t:1527876688694};\\\", \\\"{x:1276,y:564,t:1527876688711};\\\", \\\"{x:1275,y:563,t:1527876688728};\\\", \\\"{x:1274,y:563,t:1527876688766};\\\", \\\"{x:1270,y:563,t:1527876690031};\\\", \\\"{x:1252,y:565,t:1527876690046};\\\", \\\"{x:1190,y:566,t:1527876690062};\\\", \\\"{x:1148,y:566,t:1527876690079};\\\", \\\"{x:1106,y:566,t:1527876690096};\\\", \\\"{x:1068,y:569,t:1527876690113};\\\", \\\"{x:1042,y:571,t:1527876690129};\\\", \\\"{x:1025,y:572,t:1527876690145};\\\", \\\"{x:1018,y:572,t:1527876690163};\\\", \\\"{x:1017,y:572,t:1527876690178};\\\", \\\"{x:1016,y:572,t:1527876690196};\\\", \\\"{x:1014,y:572,t:1527876690557};\\\", \\\"{x:1005,y:571,t:1527876690573};\\\", \\\"{x:1000,y:570,t:1527876690582};\\\", \\\"{x:999,y:570,t:1527876690595};\\\", \\\"{x:998,y:570,t:1527876690613};\\\", \\\"{x:996,y:570,t:1527876690630};\\\", \\\"{x:992,y:570,t:1527876690646};\\\", \\\"{x:987,y:571,t:1527876690662};\\\", \\\"{x:981,y:571,t:1527876690679};\\\", \\\"{x:972,y:572,t:1527876690696};\\\", \\\"{x:962,y:575,t:1527876690711};\\\", \\\"{x:947,y:576,t:1527876690730};\\\", \\\"{x:925,y:579,t:1527876690745};\\\", \\\"{x:896,y:581,t:1527876690762};\\\", \\\"{x:861,y:581,t:1527876690778};\\\", \\\"{x:829,y:582,t:1527876690793};\\\", \\\"{x:804,y:584,t:1527876690812};\\\", \\\"{x:788,y:587,t:1527876690829};\\\", \\\"{x:786,y:588,t:1527876690846};\\\", \\\"{x:785,y:588,t:1527876690901};\\\", \\\"{x:781,y:590,t:1527876690913};\\\", \\\"{x:778,y:591,t:1527876690929};\\\", \\\"{x:763,y:592,t:1527876690947};\\\", \\\"{x:741,y:593,t:1527876690964};\\\", \\\"{x:711,y:593,t:1527876690980};\\\", \\\"{x:672,y:593,t:1527876690997};\\\", \\\"{x:622,y:593,t:1527876691012};\\\", \\\"{x:538,y:593,t:1527876691029};\\\", \\\"{x:492,y:597,t:1527876691048};\\\", \\\"{x:449,y:597,t:1527876691063};\\\", \\\"{x:416,y:597,t:1527876691079};\\\", \\\"{x:389,y:597,t:1527876691096};\\\", \\\"{x:364,y:597,t:1527876691112};\\\", \\\"{x:337,y:597,t:1527876691129};\\\", \\\"{x:307,y:597,t:1527876691147};\\\", \\\"{x:281,y:597,t:1527876691163};\\\", \\\"{x:267,y:597,t:1527876691180};\\\", \\\"{x:263,y:597,t:1527876691197};\\\", \\\"{x:256,y:595,t:1527876691213};\\\", \\\"{x:251,y:594,t:1527876691229};\\\", \\\"{x:247,y:593,t:1527876691247};\\\", \\\"{x:240,y:593,t:1527876691263};\\\", \\\"{x:235,y:593,t:1527876691279};\\\", \\\"{x:232,y:593,t:1527876691296};\\\", \\\"{x:225,y:595,t:1527876691314};\\\", \\\"{x:214,y:601,t:1527876691330};\\\", \\\"{x:203,y:609,t:1527876691346};\\\", \\\"{x:194,y:614,t:1527876691363};\\\", \\\"{x:189,y:617,t:1527876691380};\\\", \\\"{x:187,y:620,t:1527876691396};\\\", \\\"{x:184,y:623,t:1527876691413};\\\", \\\"{x:181,y:627,t:1527876691430};\\\", \\\"{x:175,y:633,t:1527876691446};\\\", \\\"{x:171,y:641,t:1527876691464};\\\", \\\"{x:170,y:645,t:1527876691480};\\\", \\\"{x:170,y:648,t:1527876691496};\\\", \\\"{x:170,y:649,t:1527876691513};\\\", \\\"{x:170,y:650,t:1527876691529};\\\", \\\"{x:173,y:650,t:1527876691580};\\\", \\\"{x:178,y:650,t:1527876691596};\\\", \\\"{x:206,y:650,t:1527876691613};\\\", \\\"{x:244,y:647,t:1527876691629};\\\", \\\"{x:289,y:639,t:1527876691647};\\\", \\\"{x:338,y:635,t:1527876691664};\\\", \\\"{x:363,y:630,t:1527876691681};\\\", \\\"{x:383,y:627,t:1527876691697};\\\", \\\"{x:391,y:624,t:1527876691713};\\\", \\\"{x:392,y:623,t:1527876691730};\\\", \\\"{x:392,y:622,t:1527876691749};\\\", \\\"{x:392,y:621,t:1527876691763};\\\", \\\"{x:392,y:620,t:1527876691780};\\\", \\\"{x:393,y:616,t:1527876691797};\\\", \\\"{x:393,y:610,t:1527876691813};\\\", \\\"{x:393,y:605,t:1527876691830};\\\", \\\"{x:393,y:601,t:1527876691848};\\\", \\\"{x:393,y:598,t:1527876691865};\\\", \\\"{x:393,y:595,t:1527876691879};\\\", \\\"{x:393,y:590,t:1527876691897};\\\", \\\"{x:395,y:584,t:1527876691914};\\\", \\\"{x:396,y:577,t:1527876691931};\\\", \\\"{x:398,y:565,t:1527876691948};\\\", \\\"{x:402,y:556,t:1527876691964};\\\", \\\"{x:407,y:550,t:1527876691982};\\\", \\\"{x:413,y:546,t:1527876691996};\\\", \\\"{x:427,y:538,t:1527876692014};\\\", \\\"{x:438,y:536,t:1527876692031};\\\", \\\"{x:461,y:536,t:1527876692047};\\\", \\\"{x:491,y:536,t:1527876692063};\\\", \\\"{x:536,y:536,t:1527876692082};\\\", \\\"{x:580,y:536,t:1527876692096};\\\", \\\"{x:616,y:532,t:1527876692114};\\\", \\\"{x:654,y:530,t:1527876692131};\\\", \\\"{x:671,y:525,t:1527876692147};\\\", \\\"{x:672,y:525,t:1527876692163};\\\", \\\"{x:670,y:523,t:1527876692206};\\\", \\\"{x:669,y:523,t:1527876692213};\\\", \\\"{x:667,y:521,t:1527876692230};\\\", \\\"{x:666,y:519,t:1527876692247};\\\", \\\"{x:664,y:516,t:1527876692264};\\\", \\\"{x:660,y:513,t:1527876692281};\\\", \\\"{x:657,y:511,t:1527876692298};\\\", \\\"{x:653,y:509,t:1527876692313};\\\", \\\"{x:649,y:508,t:1527876692330};\\\", \\\"{x:645,y:506,t:1527876692347};\\\", \\\"{x:641,y:505,t:1527876692364};\\\", \\\"{x:639,y:504,t:1527876692381};\\\", \\\"{x:636,y:504,t:1527876692397};\\\", \\\"{x:634,y:502,t:1527876692421};\\\", \\\"{x:633,y:502,t:1527876692430};\\\", \\\"{x:631,y:502,t:1527876692448};\\\", \\\"{x:630,y:502,t:1527876692463};\\\", \\\"{x:628,y:501,t:1527876692480};\\\", \\\"{x:626,y:500,t:1527876692526};\\\", \\\"{x:625,y:499,t:1527876692542};\\\", \\\"{x:623,y:498,t:1527876692558};\\\", \\\"{x:621,y:498,t:1527876692582};\\\", \\\"{x:618,y:496,t:1527876692598};\\\", \\\"{x:615,y:495,t:1527876692614};\\\", \\\"{x:613,y:495,t:1527876692631};\\\", \\\"{x:612,y:495,t:1527876692647};\\\", \\\"{x:612,y:494,t:1527876692664};\\\", \\\"{x:612,y:499,t:1527876693070};\\\", \\\"{x:619,y:506,t:1527876693082};\\\", \\\"{x:627,y:512,t:1527876693098};\\\", \\\"{x:629,y:513,t:1527876693114};\\\", \\\"{x:633,y:515,t:1527876693131};\\\", \\\"{x:638,y:518,t:1527876693148};\\\", \\\"{x:641,y:518,t:1527876693165};\\\", \\\"{x:643,y:518,t:1527876693181};\\\", \\\"{x:644,y:518,t:1527876693198};\\\", \\\"{x:645,y:519,t:1527876693220};\\\", \\\"{x:646,y:519,t:1527876693232};\\\", \\\"{x:652,y:521,t:1527876693248};\\\", \\\"{x:659,y:521,t:1527876693264};\\\", \\\"{x:664,y:522,t:1527876693281};\\\", \\\"{x:672,y:522,t:1527876693297};\\\", \\\"{x:686,y:522,t:1527876693314};\\\", \\\"{x:697,y:523,t:1527876693332};\\\", \\\"{x:705,y:524,t:1527876693347};\\\", \\\"{x:710,y:525,t:1527876693365};\\\", \\\"{x:716,y:526,t:1527876693381};\\\", \\\"{x:723,y:529,t:1527876693397};\\\", \\\"{x:730,y:530,t:1527876693416};\\\", \\\"{x:744,y:536,t:1527876693431};\\\", \\\"{x:756,y:545,t:1527876693448};\\\", \\\"{x:768,y:550,t:1527876693465};\\\", \\\"{x:779,y:553,t:1527876693482};\\\", \\\"{x:787,y:553,t:1527876693498};\\\", \\\"{x:794,y:554,t:1527876693515};\\\", \\\"{x:795,y:554,t:1527876693534};\\\", \\\"{x:796,y:554,t:1527876693548};\\\", \\\"{x:800,y:553,t:1527876693564};\\\", \\\"{x:816,y:544,t:1527876693581};\\\", \\\"{x:826,y:539,t:1527876693599};\\\", \\\"{x:833,y:534,t:1527876693614};\\\", \\\"{x:834,y:534,t:1527876693631};\\\", \\\"{x:833,y:534,t:1527876693949};\\\", \\\"{x:811,y:545,t:1527876693965};\\\", \\\"{x:784,y:562,t:1527876693982};\\\", \\\"{x:751,y:579,t:1527876693999};\\\", \\\"{x:720,y:593,t:1527876694016};\\\", \\\"{x:698,y:604,t:1527876694033};\\\", \\\"{x:685,y:611,t:1527876694048};\\\", \\\"{x:675,y:616,t:1527876694065};\\\", \\\"{x:663,y:627,t:1527876694081};\\\", \\\"{x:652,y:639,t:1527876694099};\\\", \\\"{x:643,y:649,t:1527876694115};\\\", \\\"{x:636,y:656,t:1527876694131};\\\", \\\"{x:626,y:664,t:1527876694148};\\\", \\\"{x:608,y:681,t:1527876694165};\\\", \\\"{x:599,y:689,t:1527876694181};\\\", \\\"{x:593,y:694,t:1527876694199};\\\", \\\"{x:588,y:698,t:1527876694216};\\\", \\\"{x:580,y:704,t:1527876694232};\\\", \\\"{x:577,y:706,t:1527876694249};\\\", \\\"{x:575,y:708,t:1527876694266};\\\", \\\"{x:575,y:709,t:1527876694318};\\\", \\\"{x:575,y:711,t:1527876694333};\\\", \\\"{x:575,y:716,t:1527876694348};\\\", \\\"{x:575,y:721,t:1527876694365};\\\", \\\"{x:574,y:722,t:1527876694382};\\\", \\\"{x:572,y:724,t:1527876694399};\\\", \\\"{x:570,y:726,t:1527876694415};\\\", \\\"{x:569,y:728,t:1527876694433};\\\", \\\"{x:567,y:728,t:1527876694449};\\\", \\\"{x:565,y:728,t:1527876694466};\\\", \\\"{x:562,y:728,t:1527876694484};\\\", \\\"{x:559,y:728,t:1527876694499};\\\", \\\"{x:556,y:728,t:1527876694516};\\\", \\\"{x:554,y:728,t:1527876694532};\\\", \\\"{x:543,y:728,t:1527876694549};\\\", \\\"{x:530,y:730,t:1527876694566};\\\", \\\"{x:523,y:731,t:1527876694583};\\\", \\\"{x:519,y:731,t:1527876694599};\\\" ] }, { \\\"rt\\\": 20612, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 11, \\\"time_elapsed\\\": 327852, \\\"internal_node_id\\\": \\\"0.0-6.0-1.0\\\", \\\"subject\\\": \\\"HW2SN\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"xray\\\", \\\"condition\\\": \\\"311\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"duration+starts\\\", \\\"q\\\": 7, \\\"clicks\\\": 2.5, \\\"explicit\\\": 3, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XInside-YFull\\\", \\\"correct\\\": 1, \\\"orth_correct\\\": 0, \\\"answer\\\": [ \\\"X\\\", \\\"O\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-F -F \\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:523,y:731,t:1527876699783};\\\", \\\"{x:526,y:731,t:1527876699794};\\\", \\\"{x:542,y:731,t:1527876699811};\\\", \\\"{x:562,y:731,t:1527876699827};\\\", \\\"{x:582,y:731,t:1527876699844};\\\", \\\"{x:620,y:731,t:1527876699860};\\\", \\\"{x:634,y:731,t:1527876699870};\\\", \\\"{x:665,y:731,t:1527876699887};\\\", \\\"{x:697,y:731,t:1527876699903};\\\", \\\"{x:721,y:731,t:1527876699920};\\\", \\\"{x:742,y:731,t:1527876699936};\\\", \\\"{x:762,y:731,t:1527876699954};\\\", \\\"{x:778,y:731,t:1527876699970};\\\", \\\"{x:794,y:731,t:1527876699986};\\\", \\\"{x:804,y:730,t:1527876700003};\\\", \\\"{x:815,y:729,t:1527876700019};\\\", \\\"{x:829,y:726,t:1527876700037};\\\", \\\"{x:840,y:724,t:1527876700053};\\\", \\\"{x:849,y:721,t:1527876700071};\\\", \\\"{x:860,y:719,t:1527876700087};\\\", \\\"{x:873,y:715,t:1527876700104};\\\", \\\"{x:887,y:712,t:1527876700121};\\\", \\\"{x:903,y:710,t:1527876700137};\\\", \\\"{x:918,y:707,t:1527876700154};\\\", \\\"{x:935,y:703,t:1527876700171};\\\", \\\"{x:950,y:699,t:1527876700186};\\\", \\\"{x:967,y:695,t:1527876700204};\\\", \\\"{x:991,y:688,t:1527876700221};\\\", \\\"{x:1003,y:684,t:1527876700237};\\\", \\\"{x:1017,y:680,t:1527876700254};\\\", \\\"{x:1028,y:676,t:1527876700272};\\\", \\\"{x:1038,y:674,t:1527876700287};\\\", \\\"{x:1046,y:671,t:1527876700304};\\\", \\\"{x:1053,y:669,t:1527876700322};\\\", \\\"{x:1058,y:666,t:1527876700337};\\\", \\\"{x:1066,y:662,t:1527876700354};\\\", \\\"{x:1075,y:657,t:1527876700371};\\\", \\\"{x:1084,y:652,t:1527876700387};\\\", \\\"{x:1092,y:647,t:1527876700404};\\\", \\\"{x:1103,y:638,t:1527876700421};\\\", \\\"{x:1109,y:632,t:1527876700437};\\\", \\\"{x:1115,y:627,t:1527876700454};\\\", \\\"{x:1121,y:622,t:1527876700470};\\\", \\\"{x:1126,y:618,t:1527876700488};\\\", \\\"{x:1130,y:616,t:1527876700504};\\\", \\\"{x:1132,y:614,t:1527876700521};\\\", \\\"{x:1133,y:614,t:1527876700565};\\\", \\\"{x:1133,y:615,t:1527876700750};\\\", \\\"{x:1132,y:615,t:1527876700758};\\\", \\\"{x:1132,y:616,t:1527876700806};\\\", \\\"{x:1132,y:617,t:1527876700862};\\\", \\\"{x:1132,y:618,t:1527876700878};\\\", \\\"{x:1131,y:618,t:1527876700894};\\\", \\\"{x:1131,y:619,t:1527876700926};\\\", \\\"{x:1130,y:621,t:1527876700998};\\\", \\\"{x:1130,y:623,t:1527876701023};\\\", \\\"{x:1130,y:627,t:1527876701038};\\\", \\\"{x:1129,y:631,t:1527876701056};\\\", \\\"{x:1128,y:636,t:1527876701071};\\\", \\\"{x:1128,y:640,t:1527876701088};\\\", \\\"{x:1128,y:646,t:1527876701105};\\\", \\\"{x:1128,y:651,t:1527876701121};\\\", \\\"{x:1128,y:654,t:1527876701139};\\\", \\\"{x:1127,y:658,t:1527876701155};\\\", \\\"{x:1127,y:661,t:1527876701172};\\\", \\\"{x:1127,y:665,t:1527876701188};\\\", \\\"{x:1127,y:669,t:1527876701205};\\\", \\\"{x:1127,y:672,t:1527876701222};\\\", \\\"{x:1127,y:674,t:1527876701238};\\\", \\\"{x:1127,y:675,t:1527876701256};\\\", \\\"{x:1127,y:677,t:1527876701272};\\\", \\\"{x:1127,y:678,t:1527876701288};\\\", \\\"{x:1127,y:680,t:1527876701350};\\\", \\\"{x:1127,y:681,t:1527876701374};\\\", \\\"{x:1127,y:682,t:1527876701397};\\\", \\\"{x:1129,y:684,t:1527876701414};\\\", \\\"{x:1130,y:685,t:1527876701421};\\\", \\\"{x:1133,y:686,t:1527876701439};\\\", \\\"{x:1140,y:688,t:1527876701455};\\\", \\\"{x:1153,y:689,t:1527876701472};\\\", \\\"{x:1169,y:691,t:1527876701488};\\\", \\\"{x:1185,y:693,t:1527876701505};\\\", \\\"{x:1200,y:695,t:1527876701522};\\\", \\\"{x:1215,y:695,t:1527876701537};\\\", \\\"{x:1229,y:698,t:1527876701554};\\\", \\\"{x:1241,y:699,t:1527876701572};\\\", \\\"{x:1252,y:700,t:1527876701589};\\\", \\\"{x:1258,y:700,t:1527876701604};\\\", \\\"{x:1264,y:700,t:1527876701621};\\\", \\\"{x:1267,y:700,t:1527876701638};\\\", \\\"{x:1270,y:700,t:1527876701654};\\\", \\\"{x:1274,y:700,t:1527876701671};\\\", \\\"{x:1281,y:700,t:1527876701689};\\\", \\\"{x:1287,y:700,t:1527876701705};\\\", \\\"{x:1293,y:700,t:1527876701722};\\\", \\\"{x:1301,y:700,t:1527876701739};\\\", \\\"{x:1307,y:700,t:1527876701755};\\\", \\\"{x:1314,y:700,t:1527876701772};\\\", \\\"{x:1321,y:700,t:1527876701789};\\\", \\\"{x:1326,y:700,t:1527876701804};\\\", \\\"{x:1330,y:700,t:1527876701822};\\\", \\\"{x:1337,y:699,t:1527876701839};\\\", \\\"{x:1342,y:699,t:1527876701854};\\\", \\\"{x:1347,y:699,t:1527876701873};\\\", \\\"{x:1349,y:699,t:1527876701889};\\\", \\\"{x:1350,y:699,t:1527876701905};\\\", \\\"{x:1351,y:699,t:1527876701942};\\\", \\\"{x:1352,y:699,t:1527876701965};\\\", \\\"{x:1353,y:699,t:1527876701983};\\\", \\\"{x:1354,y:699,t:1527876702000};\\\", \\\"{x:1355,y:699,t:1527876702022};\\\", \\\"{x:1355,y:697,t:1527876702126};\\\", \\\"{x:1354,y:697,t:1527876702140};\\\", \\\"{x:1351,y:697,t:1527876702157};\\\", \\\"{x:1348,y:694,t:1527876702172};\\\", \\\"{x:1346,y:694,t:1527876702190};\\\", \\\"{x:1345,y:694,t:1527876702206};\\\", \\\"{x:1345,y:695,t:1527876711309};\\\", \\\"{x:1348,y:699,t:1527876711317};\\\", \\\"{x:1349,y:702,t:1527876711331};\\\", \\\"{x:1352,y:704,t:1527876711349};\\\", \\\"{x:1354,y:707,t:1527876711365};\\\", \\\"{x:1356,y:709,t:1527876711381};\\\", \\\"{x:1360,y:713,t:1527876711398};\\\", \\\"{x:1364,y:717,t:1527876711415};\\\", \\\"{x:1370,y:723,t:1527876711430};\\\", \\\"{x:1377,y:728,t:1527876711448};\\\", \\\"{x:1382,y:732,t:1527876711464};\\\", \\\"{x:1386,y:735,t:1527876711482};\\\", \\\"{x:1390,y:737,t:1527876711497};\\\", \\\"{x:1392,y:739,t:1527876711515};\\\", \\\"{x:1396,y:740,t:1527876711531};\\\", \\\"{x:1399,y:743,t:1527876711548};\\\", \\\"{x:1405,y:747,t:1527876711564};\\\", \\\"{x:1415,y:755,t:1527876711580};\\\", \\\"{x:1422,y:760,t:1527876711597};\\\", \\\"{x:1429,y:763,t:1527876711614};\\\", \\\"{x:1434,y:764,t:1527876711631};\\\", \\\"{x:1437,y:766,t:1527876711647};\\\", \\\"{x:1438,y:767,t:1527876711664};\\\", \\\"{x:1439,y:767,t:1527876711681};\\\", \\\"{x:1441,y:770,t:1527876711697};\\\", \\\"{x:1443,y:773,t:1527876711714};\\\", \\\"{x:1445,y:777,t:1527876711732};\\\", \\\"{x:1447,y:781,t:1527876711747};\\\", \\\"{x:1448,y:783,t:1527876711764};\\\", \\\"{x:1449,y:787,t:1527876711781};\\\", \\\"{x:1450,y:788,t:1527876711797};\\\", \\\"{x:1450,y:790,t:1527876711821};\\\", \\\"{x:1451,y:791,t:1527876711831};\\\", \\\"{x:1452,y:791,t:1527876711894};\\\", \\\"{x:1453,y:791,t:1527876711902};\\\", \\\"{x:1456,y:791,t:1527876711917};\\\", \\\"{x:1457,y:790,t:1527876711932};\\\", \\\"{x:1459,y:788,t:1527876711949};\\\", \\\"{x:1463,y:782,t:1527876711965};\\\", \\\"{x:1468,y:777,t:1527876711984};\\\", \\\"{x:1474,y:770,t:1527876711999};\\\", \\\"{x:1477,y:767,t:1527876712014};\\\", \\\"{x:1478,y:766,t:1527876712031};\\\", \\\"{x:1480,y:765,t:1527876712049};\\\", \\\"{x:1481,y:763,t:1527876712065};\\\", \\\"{x:1483,y:762,t:1527876712082};\\\", \\\"{x:1483,y:761,t:1527876712099};\\\", \\\"{x:1481,y:762,t:1527876712214};\\\", \\\"{x:1474,y:768,t:1527876712221};\\\", \\\"{x:1466,y:780,t:1527876712232};\\\", \\\"{x:1445,y:802,t:1527876712249};\\\", \\\"{x:1414,y:824,t:1527876712265};\\\", \\\"{x:1376,y:846,t:1527876712281};\\\", \\\"{x:1340,y:865,t:1527876712298};\\\", \\\"{x:1321,y:869,t:1527876712316};\\\", \\\"{x:1318,y:869,t:1527876712332};\\\", \\\"{x:1314,y:869,t:1527876713062};\\\", \\\"{x:1305,y:869,t:1527876713070};\\\", \\\"{x:1291,y:869,t:1527876713082};\\\", \\\"{x:1262,y:869,t:1527876713100};\\\", \\\"{x:1222,y:869,t:1527876713116};\\\", \\\"{x:1156,y:869,t:1527876713133};\\\", \\\"{x:1050,y:869,t:1527876713150};\\\", \\\"{x:1004,y:869,t:1527876713166};\\\", \\\"{x:974,y:862,t:1527876713183};\\\", \\\"{x:943,y:854,t:1527876713200};\\\", \\\"{x:913,y:850,t:1527876713215};\\\", \\\"{x:898,y:847,t:1527876713233};\\\", \\\"{x:888,y:844,t:1527876713250};\\\", \\\"{x:875,y:838,t:1527876713266};\\\", \\\"{x:868,y:834,t:1527876713282};\\\", \\\"{x:859,y:827,t:1527876713299};\\\", \\\"{x:855,y:824,t:1527876713316};\\\", \\\"{x:849,y:817,t:1527876713333};\\\", \\\"{x:840,y:804,t:1527876713349};\\\", \\\"{x:836,y:797,t:1527876713366};\\\", \\\"{x:833,y:792,t:1527876713383};\\\", \\\"{x:830,y:780,t:1527876713399};\\\", \\\"{x:827,y:770,t:1527876713416};\\\", \\\"{x:825,y:764,t:1527876713433};\\\", \\\"{x:824,y:761,t:1527876713449};\\\", \\\"{x:823,y:757,t:1527876713466};\\\", \\\"{x:821,y:751,t:1527876713483};\\\", \\\"{x:819,y:746,t:1527876713500};\\\", \\\"{x:817,y:743,t:1527876713517};\\\", \\\"{x:813,y:739,t:1527876713532};\\\", \\\"{x:803,y:727,t:1527876713550};\\\", \\\"{x:786,y:715,t:1527876713567};\\\", \\\"{x:763,y:702,t:1527876713582};\\\", \\\"{x:731,y:684,t:1527876713600};\\\", \\\"{x:702,y:672,t:1527876713617};\\\", \\\"{x:679,y:661,t:1527876713632};\\\", \\\"{x:659,y:650,t:1527876713650};\\\", \\\"{x:644,y:641,t:1527876713667};\\\", \\\"{x:633,y:635,t:1527876713683};\\\", \\\"{x:625,y:630,t:1527876713701};\\\", \\\"{x:622,y:630,t:1527876713716};\\\", \\\"{x:618,y:628,t:1527876713749};\\\", \\\"{x:616,y:628,t:1527876713764};\\\", \\\"{x:608,y:628,t:1527876713781};\\\", \\\"{x:610,y:628,t:1527876713868};\\\", \\\"{x:617,y:626,t:1527876713881};\\\", \\\"{x:641,y:619,t:1527876713897};\\\", \\\"{x:686,y:606,t:1527876713915};\\\", \\\"{x:747,y:589,t:1527876713932};\\\", \\\"{x:803,y:579,t:1527876713948};\\\", \\\"{x:841,y:579,t:1527876713965};\\\", \\\"{x:843,y:579,t:1527876713981};\\\", \\\"{x:845,y:579,t:1527876714070};\\\", \\\"{x:846,y:579,t:1527876714085};\\\", \\\"{x:845,y:579,t:1527876714718};\\\", \\\"{x:844,y:579,t:1527876714733};\\\", \\\"{x:842,y:579,t:1527876714749};\\\", \\\"{x:836,y:579,t:1527876714765};\\\", \\\"{x:829,y:579,t:1527876714782};\\\", \\\"{x:819,y:579,t:1527876714800};\\\", \\\"{x:804,y:579,t:1527876714815};\\\", \\\"{x:787,y:581,t:1527876714832};\\\", \\\"{x:758,y:585,t:1527876714848};\\\", \\\"{x:730,y:588,t:1527876714865};\\\", \\\"{x:705,y:590,t:1527876714883};\\\", \\\"{x:697,y:592,t:1527876714899};\\\", \\\"{x:696,y:592,t:1527876714915};\\\", \\\"{x:695,y:592,t:1527876714989};\\\", \\\"{x:692,y:592,t:1527876715037};\\\", \\\"{x:691,y:592,t:1527876715048};\\\", \\\"{x:685,y:588,t:1527876715065};\\\", \\\"{x:674,y:582,t:1527876715082};\\\", \\\"{x:665,y:579,t:1527876715098};\\\", \\\"{x:657,y:578,t:1527876715115};\\\", \\\"{x:652,y:576,t:1527876715132};\\\", \\\"{x:649,y:576,t:1527876715148};\\\", \\\"{x:648,y:576,t:1527876715348};\\\", \\\"{x:643,y:576,t:1527876715366};\\\", \\\"{x:635,y:580,t:1527876715382};\\\", \\\"{x:629,y:582,t:1527876715399};\\\", \\\"{x:626,y:584,t:1527876715415};\\\", \\\"{x:619,y:588,t:1527876715433};\\\", \\\"{x:613,y:592,t:1527876715450};\\\", \\\"{x:610,y:595,t:1527876715466};\\\", \\\"{x:610,y:596,t:1527876715482};\\\", \\\"{x:608,y:597,t:1527876715525};\\\", \\\"{x:607,y:599,t:1527876715532};\\\", \\\"{x:606,y:599,t:1527876715549};\\\", \\\"{x:606,y:600,t:1527876715565};\\\", \\\"{x:603,y:599,t:1527876715597};\\\", \\\"{x:601,y:594,t:1527876715604};\\\", \\\"{x:600,y:591,t:1527876715616};\\\", \\\"{x:597,y:581,t:1527876715632};\\\", \\\"{x:595,y:571,t:1527876715649};\\\", \\\"{x:594,y:568,t:1527876715666};\\\", \\\"{x:594,y:567,t:1527876715701};\\\", \\\"{x:595,y:567,t:1527876715716};\\\", \\\"{x:603,y:568,t:1527876715734};\\\", \\\"{x:607,y:569,t:1527876715749};\\\", \\\"{x:607,y:572,t:1527876715956};\\\", \\\"{x:607,y:580,t:1527876715966};\\\", \\\"{x:602,y:597,t:1527876715984};\\\", \\\"{x:595,y:621,t:1527876716000};\\\", \\\"{x:587,y:645,t:1527876716016};\\\", \\\"{x:578,y:667,t:1527876716034};\\\", \\\"{x:573,y:686,t:1527876716049};\\\", \\\"{x:570,y:695,t:1527876716066};\\\", \\\"{x:570,y:700,t:1527876716083};\\\", \\\"{x:569,y:702,t:1527876716099};\\\", \\\"{x:568,y:707,t:1527876716116};\\\", \\\"{x:568,y:708,t:1527876716132};\\\", \\\"{x:567,y:709,t:1527876716149};\\\", \\\"{x:566,y:711,t:1527876716167};\\\", \\\"{x:565,y:713,t:1527876716184};\\\", \\\"{x:563,y:715,t:1527876716200};\\\", \\\"{x:562,y:716,t:1527876716217};\\\", \\\"{x:561,y:716,t:1527876716233};\\\", \\\"{x:560,y:717,t:1527876716269};\\\", \\\"{x:558,y:717,t:1527876716293};\\\", \\\"{x:555,y:718,t:1527876716309};\\\", \\\"{x:553,y:719,t:1527876716325};\\\", \\\"{x:549,y:721,t:1527876716334};\\\", \\\"{x:545,y:724,t:1527876716350};\\\", \\\"{x:540,y:728,t:1527876716367};\\\", \\\"{x:532,y:733,t:1527876716383};\\\", \\\"{x:526,y:737,t:1527876716400};\\\", \\\"{x:525,y:738,t:1527876716417};\\\" ] }, { \\\"rt\\\": 35400, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 12, \\\"time_elapsed\\\": 364538, \\\"internal_node_id\\\": \\\"0.0-6.0-2.0\\\", \\\"subject\\\": \\\"HW2SN\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"xray\\\", \\\"condition\\\": \\\"311\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"duration+contained\\\", \\\"q\\\": 8, \\\"clicks\\\": 1, \\\"explicit\\\": 3, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XInside-YFull\\\", \\\"correct\\\": 1, \\\"orth_correct\\\": 0, \\\"answer\\\": [ \\\"G\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-E -B -B -X -X -G \\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:525,y:736,t:1527876719133};\\\", \\\"{x:540,y:729,t:1527876719160};\\\", \\\"{x:545,y:726,t:1527876719168};\\\", \\\"{x:555,y:724,t:1527876719185};\\\", \\\"{x:561,y:722,t:1527876719202};\\\", \\\"{x:578,y:720,t:1527876719219};\\\", \\\"{x:600,y:720,t:1527876719236};\\\", \\\"{x:636,y:720,t:1527876719252};\\\", \\\"{x:662,y:720,t:1527876719268};\\\", \\\"{x:689,y:720,t:1527876719285};\\\", \\\"{x:712,y:720,t:1527876719302};\\\", \\\"{x:734,y:720,t:1527876719319};\\\", \\\"{x:752,y:722,t:1527876719335};\\\", \\\"{x:766,y:724,t:1527876719352};\\\", \\\"{x:779,y:727,t:1527876719368};\\\", \\\"{x:787,y:729,t:1527876719385};\\\", \\\"{x:792,y:731,t:1527876719403};\\\", \\\"{x:792,y:732,t:1527876719637};\\\", \\\"{x:795,y:741,t:1527876719654};\\\", \\\"{x:799,y:753,t:1527876719669};\\\", \\\"{x:801,y:759,t:1527876719686};\\\", \\\"{x:802,y:765,t:1527876719703};\\\", \\\"{x:804,y:769,t:1527876719720};\\\", \\\"{x:805,y:770,t:1527876719830};\\\", \\\"{x:807,y:771,t:1527876719838};\\\", \\\"{x:809,y:771,t:1527876719853};\\\", \\\"{x:810,y:772,t:1527876720117};\\\", \\\"{x:811,y:773,t:1527876720148};\\\", \\\"{x:812,y:774,t:1527876720156};\\\", \\\"{x:813,y:774,t:1527876720173};\\\", \\\"{x:815,y:776,t:1527876720189};\\\", \\\"{x:816,y:776,t:1527876720203};\\\", \\\"{x:817,y:776,t:1527876720219};\\\", \\\"{x:817,y:777,t:1527876720237};\\\", \\\"{x:818,y:777,t:1527876720278};\\\", \\\"{x:825,y:777,t:1527876720933};\\\", \\\"{x:840,y:777,t:1527876720940};\\\", \\\"{x:855,y:777,t:1527876720953};\\\", \\\"{x:903,y:772,t:1527876720970};\\\", \\\"{x:964,y:753,t:1527876720986};\\\", \\\"{x:1024,y:733,t:1527876721004};\\\", \\\"{x:1107,y:690,t:1527876721020};\\\", \\\"{x:1171,y:660,t:1527876721037};\\\", \\\"{x:1243,y:626,t:1527876721054};\\\", \\\"{x:1295,y:605,t:1527876721071};\\\", \\\"{x:1324,y:588,t:1527876721086};\\\", \\\"{x:1345,y:577,t:1527876721104};\\\", \\\"{x:1355,y:568,t:1527876721120};\\\", \\\"{x:1357,y:565,t:1527876721138};\\\", \\\"{x:1357,y:563,t:1527876721153};\\\", \\\"{x:1357,y:558,t:1527876721170};\\\", \\\"{x:1355,y:551,t:1527876721186};\\\", \\\"{x:1345,y:541,t:1527876721203};\\\", \\\"{x:1316,y:526,t:1527876721220};\\\", \\\"{x:1290,y:520,t:1527876721238};\\\", \\\"{x:1257,y:516,t:1527876721254};\\\", \\\"{x:1230,y:516,t:1527876721270};\\\", \\\"{x:1207,y:516,t:1527876721288};\\\", \\\"{x:1193,y:515,t:1527876721303};\\\", \\\"{x:1185,y:513,t:1527876721320};\\\", \\\"{x:1181,y:509,t:1527876721338};\\\", \\\"{x:1179,y:505,t:1527876721354};\\\", \\\"{x:1176,y:501,t:1527876721371};\\\", \\\"{x:1176,y:500,t:1527876721388};\\\", \\\"{x:1175,y:500,t:1527876721437};\\\", \\\"{x:1173,y:500,t:1527876721454};\\\", \\\"{x:1171,y:500,t:1527876721471};\\\", \\\"{x:1170,y:500,t:1527876721510};\\\", \\\"{x:1168,y:500,t:1527876721684};\\\", \\\"{x:1167,y:500,t:1527876721700};\\\", \\\"{x:1167,y:501,t:1527876724550};\\\", \\\"{x:1169,y:504,t:1527876724557};\\\", \\\"{x:1175,y:512,t:1527876724573};\\\", \\\"{x:1182,y:519,t:1527876724591};\\\", \\\"{x:1189,y:525,t:1527876724607};\\\", \\\"{x:1195,y:528,t:1527876724623};\\\", \\\"{x:1206,y:534,t:1527876724640};\\\", \\\"{x:1215,y:540,t:1527876724657};\\\", \\\"{x:1230,y:547,t:1527876724674};\\\", \\\"{x:1240,y:550,t:1527876724690};\\\", \\\"{x:1246,y:551,t:1527876724707};\\\", \\\"{x:1248,y:552,t:1527876724724};\\\", \\\"{x:1249,y:552,t:1527876724741};\\\", \\\"{x:1251,y:552,t:1527876724838};\\\", \\\"{x:1252,y:552,t:1527876724845};\\\", \\\"{x:1253,y:553,t:1527876724858};\\\", \\\"{x:1254,y:553,t:1527876724875};\\\", \\\"{x:1258,y:554,t:1527876724891};\\\", \\\"{x:1264,y:555,t:1527876724907};\\\", \\\"{x:1268,y:557,t:1527876724924};\\\", \\\"{x:1275,y:561,t:1527876724941};\\\", \\\"{x:1278,y:562,t:1527876724957};\\\", \\\"{x:1279,y:562,t:1527876724974};\\\", \\\"{x:1279,y:563,t:1527876724989};\\\", \\\"{x:1283,y:570,t:1527876735215};\\\", \\\"{x:1289,y:589,t:1527876735232};\\\", \\\"{x:1297,y:605,t:1527876735248};\\\", \\\"{x:1306,y:625,t:1527876735265};\\\", \\\"{x:1318,y:663,t:1527876735282};\\\", \\\"{x:1328,y:697,t:1527876735298};\\\", \\\"{x:1336,y:720,t:1527876735315};\\\", \\\"{x:1341,y:739,t:1527876735332};\\\", \\\"{x:1342,y:742,t:1527876735348};\\\", \\\"{x:1342,y:743,t:1527876735437};\\\", \\\"{x:1342,y:745,t:1527876735448};\\\", \\\"{x:1342,y:747,t:1527876735466};\\\", \\\"{x:1342,y:748,t:1527876735482};\\\", \\\"{x:1344,y:750,t:1527876735646};\\\", \\\"{x:1345,y:751,t:1527876735653};\\\", \\\"{x:1346,y:751,t:1527876735666};\\\", \\\"{x:1347,y:753,t:1527876735683};\\\", \\\"{x:1348,y:753,t:1527876735694};\\\", \\\"{x:1349,y:753,t:1527876735724};\\\", \\\"{x:1349,y:753,t:1527876735845};\\\", \\\"{x:1349,y:755,t:1527876735965};\\\", \\\"{x:1349,y:757,t:1527876735983};\\\", \\\"{x:1347,y:760,t:1527876736000};\\\", \\\"{x:1345,y:763,t:1527876736015};\\\", \\\"{x:1351,y:766,t:1527876745085};\\\", \\\"{x:1365,y:769,t:1527876745094};\\\", \\\"{x:1379,y:774,t:1527876745107};\\\", \\\"{x:1408,y:781,t:1527876745122};\\\", \\\"{x:1434,y:785,t:1527876745139};\\\", \\\"{x:1461,y:787,t:1527876745156};\\\", \\\"{x:1465,y:789,t:1527876745173};\\\", \\\"{x:1466,y:790,t:1527876745324};\\\", \\\"{x:1466,y:792,t:1527876745339};\\\", \\\"{x:1466,y:795,t:1527876745356};\\\", \\\"{x:1466,y:798,t:1527876745373};\\\", \\\"{x:1466,y:800,t:1527876745389};\\\", \\\"{x:1466,y:803,t:1527876745406};\\\", \\\"{x:1469,y:806,t:1527876745423};\\\", \\\"{x:1469,y:807,t:1527876745439};\\\", \\\"{x:1470,y:809,t:1527876745456};\\\", \\\"{x:1471,y:812,t:1527876745473};\\\", \\\"{x:1473,y:813,t:1527876745489};\\\", \\\"{x:1475,y:817,t:1527876745506};\\\", \\\"{x:1477,y:819,t:1527876745523};\\\", \\\"{x:1477,y:820,t:1527876745539};\\\", \\\"{x:1479,y:823,t:1527876745556};\\\", \\\"{x:1480,y:823,t:1527876745573};\\\", \\\"{x:1480,y:824,t:1527876745589};\\\", \\\"{x:1481,y:826,t:1527876745607};\\\", \\\"{x:1482,y:826,t:1527876745640};\\\", \\\"{x:1483,y:827,t:1527876746909};\\\", \\\"{x:1483,y:828,t:1527876746948};\\\", \\\"{x:1482,y:828,t:1527876746973};\\\", \\\"{x:1482,y:829,t:1527876747022};\\\", \\\"{x:1481,y:829,t:1527876747427};\\\", \\\"{x:1481,y:830,t:1527876747573};\\\", \\\"{x:1479,y:829,t:1527876749017};\\\", \\\"{x:1479,y:827,t:1527876749030};\\\", \\\"{x:1475,y:821,t:1527876749047};\\\", \\\"{x:1474,y:815,t:1527876749063};\\\", \\\"{x:1470,y:808,t:1527876749079};\\\", \\\"{x:1466,y:798,t:1527876749097};\\\", \\\"{x:1461,y:787,t:1527876749113};\\\", \\\"{x:1457,y:774,t:1527876749130};\\\", \\\"{x:1451,y:755,t:1527876749147};\\\", \\\"{x:1443,y:736,t:1527876749163};\\\", \\\"{x:1434,y:716,t:1527876749181};\\\", \\\"{x:1424,y:701,t:1527876749197};\\\", \\\"{x:1418,y:690,t:1527876749214};\\\", \\\"{x:1415,y:683,t:1527876749230};\\\", \\\"{x:1412,y:675,t:1527876749246};\\\", \\\"{x:1409,y:661,t:1527876749263};\\\", \\\"{x:1404,y:646,t:1527876749279};\\\", \\\"{x:1401,y:636,t:1527876749296};\\\", \\\"{x:1401,y:630,t:1527876749313};\\\", \\\"{x:1401,y:626,t:1527876749330};\\\", \\\"{x:1401,y:620,t:1527876749346};\\\", \\\"{x:1401,y:614,t:1527876749363};\\\", \\\"{x:1401,y:605,t:1527876749380};\\\", \\\"{x:1401,y:594,t:1527876749395};\\\", \\\"{x:1401,y:590,t:1527876749413};\\\", \\\"{x:1402,y:586,t:1527876749430};\\\", \\\"{x:1402,y:585,t:1527876749446};\\\", \\\"{x:1402,y:584,t:1527876749463};\\\", \\\"{x:1402,y:583,t:1527876749585};\\\", \\\"{x:1403,y:582,t:1527876749597};\\\", \\\"{x:1404,y:580,t:1527876749613};\\\", \\\"{x:1405,y:577,t:1527876749630};\\\", \\\"{x:1405,y:576,t:1527876749647};\\\", \\\"{x:1405,y:575,t:1527876749663};\\\", \\\"{x:1407,y:573,t:1527876749680};\\\", \\\"{x:1407,y:571,t:1527876749704};\\\", \\\"{x:1408,y:570,t:1527876749728};\\\", \\\"{x:1409,y:569,t:1527876749753};\\\", \\\"{x:1409,y:568,t:1527876749776};\\\", \\\"{x:1409,y:567,t:1527876749792};\\\", \\\"{x:1410,y:566,t:1527876749808};\\\", \\\"{x:1410,y:565,t:1527876749830};\\\", \\\"{x:1411,y:565,t:1527876749856};\\\", \\\"{x:1411,y:564,t:1527876749913};\\\", \\\"{x:1412,y:563,t:1527876749952};\\\", \\\"{x:1413,y:563,t:1527876749968};\\\", \\\"{x:1413,y:561,t:1527876749991};\\\", \\\"{x:1414,y:561,t:1527876750026};\\\", \\\"{x:1412,y:564,t:1527876750664};\\\", \\\"{x:1399,y:575,t:1527876750682};\\\", \\\"{x:1372,y:584,t:1527876750698};\\\", \\\"{x:1329,y:593,t:1527876750715};\\\", \\\"{x:1279,y:599,t:1527876750731};\\\", \\\"{x:1232,y:605,t:1527876750747};\\\", \\\"{x:1176,y:605,t:1527876750765};\\\", \\\"{x:1117,y:605,t:1527876750781};\\\", \\\"{x:1053,y:605,t:1527876750797};\\\", \\\"{x:992,y:605,t:1527876750814};\\\", \\\"{x:939,y:605,t:1527876750832};\\\", \\\"{x:882,y:605,t:1527876750847};\\\", \\\"{x:856,y:605,t:1527876750864};\\\", \\\"{x:839,y:605,t:1527876750880};\\\", \\\"{x:829,y:605,t:1527876750897};\\\", \\\"{x:820,y:606,t:1527876750914};\\\", \\\"{x:811,y:608,t:1527876750930};\\\", \\\"{x:796,y:610,t:1527876750947};\\\", \\\"{x:778,y:614,t:1527876750963};\\\", \\\"{x:754,y:615,t:1527876750981};\\\", \\\"{x:726,y:619,t:1527876750997};\\\", \\\"{x:698,y:626,t:1527876751015};\\\", \\\"{x:669,y:635,t:1527876751032};\\\", \\\"{x:649,y:641,t:1527876751047};\\\", \\\"{x:629,y:646,t:1527876751063};\\\", \\\"{x:614,y:648,t:1527876751080};\\\", \\\"{x:602,y:648,t:1527876751098};\\\", \\\"{x:594,y:648,t:1527876751114};\\\", \\\"{x:588,y:647,t:1527876751131};\\\", \\\"{x:580,y:643,t:1527876751148};\\\", \\\"{x:571,y:636,t:1527876751164};\\\", \\\"{x:558,y:625,t:1527876751181};\\\", \\\"{x:545,y:614,t:1527876751198};\\\", \\\"{x:539,y:608,t:1527876751214};\\\", \\\"{x:535,y:599,t:1527876751232};\\\", \\\"{x:535,y:593,t:1527876751249};\\\", \\\"{x:536,y:588,t:1527876751265};\\\", \\\"{x:548,y:576,t:1527876751281};\\\", \\\"{x:567,y:564,t:1527876751298};\\\", \\\"{x:590,y:552,t:1527876751315};\\\", \\\"{x:608,y:547,t:1527876751331};\\\", \\\"{x:628,y:542,t:1527876751349};\\\", \\\"{x:654,y:536,t:1527876751365};\\\", \\\"{x:679,y:532,t:1527876751381};\\\", \\\"{x:705,y:530,t:1527876751398};\\\", \\\"{x:720,y:527,t:1527876751414};\\\", \\\"{x:731,y:527,t:1527876751432};\\\", \\\"{x:762,y:529,t:1527876751448};\\\", \\\"{x:787,y:537,t:1527876751465};\\\", \\\"{x:810,y:544,t:1527876751481};\\\", \\\"{x:827,y:549,t:1527876751498};\\\", \\\"{x:839,y:552,t:1527876751515};\\\", \\\"{x:845,y:555,t:1527876751531};\\\", \\\"{x:847,y:556,t:1527876751548};\\\", \\\"{x:847,y:557,t:1527876751608};\\\", \\\"{x:847,y:558,t:1527876751615};\\\", \\\"{x:847,y:553,t:1527876751730};\\\", \\\"{x:846,y:539,t:1527876751748};\\\", \\\"{x:845,y:532,t:1527876751765};\\\", \\\"{x:842,y:527,t:1527876751782};\\\", \\\"{x:840,y:524,t:1527876751799};\\\", \\\"{x:838,y:523,t:1527876751814};\\\", \\\"{x:837,y:527,t:1527876752081};\\\", \\\"{x:839,y:534,t:1527876752099};\\\", \\\"{x:841,y:538,t:1527876752115};\\\", \\\"{x:841,y:539,t:1527876752131};\\\", \\\"{x:841,y:540,t:1527876752447};\\\", \\\"{x:841,y:545,t:1527876752455};\\\", \\\"{x:834,y:554,t:1527876752465};\\\", \\\"{x:811,y:568,t:1527876752483};\\\", \\\"{x:774,y:588,t:1527876752499};\\\", \\\"{x:733,y:602,t:1527876752516};\\\", \\\"{x:687,y:621,t:1527876752532};\\\", \\\"{x:647,y:640,t:1527876752550};\\\", \\\"{x:623,y:653,t:1527876752565};\\\", \\\"{x:610,y:662,t:1527876752581};\\\", \\\"{x:606,y:671,t:1527876752599};\\\", \\\"{x:604,y:675,t:1527876752616};\\\", \\\"{x:601,y:680,t:1527876752632};\\\", \\\"{x:597,y:685,t:1527876752649};\\\", \\\"{x:589,y:693,t:1527876752666};\\\", \\\"{x:582,y:699,t:1527876752682};\\\", \\\"{x:578,y:703,t:1527876752699};\\\", \\\"{x:574,y:707,t:1527876752716};\\\", \\\"{x:571,y:709,t:1527876752732};\\\", \\\"{x:568,y:712,t:1527876752749};\\\", \\\"{x:567,y:713,t:1527876752768};\\\", \\\"{x:565,y:715,t:1527876752783};\\\", \\\"{x:551,y:726,t:1527876752800};\\\", \\\"{x:535,y:744,t:1527876752816};\\\", \\\"{x:519,y:764,t:1527876752833};\\\", \\\"{x:508,y:776,t:1527876752849};\\\", \\\"{x:508,y:778,t:1527876752866};\\\", \\\"{x:508,y:776,t:1527876752991};\\\", \\\"{x:508,y:770,t:1527876752999};\\\", \\\"{x:505,y:757,t:1527876753015};\\\", \\\"{x:504,y:747,t:1527876753032};\\\", \\\"{x:504,y:739,t:1527876753049};\\\", \\\"{x:503,y:729,t:1527876753066};\\\", \\\"{x:503,y:727,t:1527876753083};\\\" ] }, { \\\"rt\\\": 27278, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 13, \\\"time_elapsed\\\": 393104, \\\"internal_node_id\\\": \\\"0.0-6.0-3.0\\\", \\\"subject\\\": \\\"HW2SN\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"xray\\\", \\\"condition\\\": \\\"311\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"starttime+before+endtime+during\\\", \\\"q\\\": 9, \\\"clicks\\\": 1, \\\"explicit\\\": 3, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XInside-YFull\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 0, \\\"answer\\\": [ \\\"E\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-4-J -J -J -E -E \\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:505,y:726,t:1527876755889};\\\", \\\"{x:509,y:725,t:1527876755901};\\\", \\\"{x:525,y:725,t:1527876755919};\\\", \\\"{x:554,y:725,t:1527876755935};\\\", \\\"{x:572,y:725,t:1527876755954};\\\", \\\"{x:593,y:721,t:1527876755968};\\\", \\\"{x:609,y:720,t:1527876755985};\\\", \\\"{x:623,y:720,t:1527876756001};\\\", \\\"{x:634,y:719,t:1527876756018};\\\", \\\"{x:643,y:717,t:1527876756035};\\\", \\\"{x:652,y:717,t:1527876756052};\\\", \\\"{x:664,y:717,t:1527876756067};\\\", \\\"{x:678,y:717,t:1527876756085};\\\", \\\"{x:691,y:715,t:1527876756102};\\\", \\\"{x:705,y:714,t:1527876756118};\\\", \\\"{x:725,y:710,t:1527876756135};\\\", \\\"{x:740,y:704,t:1527876756152};\\\", \\\"{x:754,y:700,t:1527876756168};\\\", \\\"{x:769,y:699,t:1527876756185};\\\", \\\"{x:784,y:696,t:1527876756202};\\\", \\\"{x:797,y:693,t:1527876756218};\\\", \\\"{x:809,y:689,t:1527876756235};\\\", \\\"{x:820,y:685,t:1527876756253};\\\", \\\"{x:825,y:684,t:1527876756269};\\\", \\\"{x:829,y:682,t:1527876756285};\\\", \\\"{x:831,y:682,t:1527876756302};\\\", \\\"{x:832,y:683,t:1527876757153};\\\", \\\"{x:832,y:684,t:1527876757170};\\\", \\\"{x:833,y:684,t:1527876758944};\\\", \\\"{x:834,y:684,t:1527876758955};\\\", \\\"{x:835,y:685,t:1527876758972};\\\", \\\"{x:836,y:685,t:1527876758992};\\\", \\\"{x:837,y:685,t:1527876759006};\\\", \\\"{x:838,y:685,t:1527876759022};\\\", \\\"{x:841,y:686,t:1527876759039};\\\", \\\"{x:843,y:686,t:1527876759064};\\\", \\\"{x:844,y:686,t:1527876759087};\\\", \\\"{x:846,y:686,t:1527876759105};\\\", \\\"{x:849,y:686,t:1527876759121};\\\", \\\"{x:850,y:686,t:1527876759152};\\\", \\\"{x:853,y:686,t:1527876760040};\\\", \\\"{x:858,y:686,t:1527876760056};\\\", \\\"{x:864,y:686,t:1527876760073};\\\", \\\"{x:868,y:686,t:1527876760089};\\\", \\\"{x:870,y:686,t:1527876760108};\\\", \\\"{x:872,y:686,t:1527876760123};\\\", \\\"{x:875,y:686,t:1527876760140};\\\", \\\"{x:878,y:686,t:1527876760157};\\\", \\\"{x:882,y:686,t:1527876760172};\\\", \\\"{x:884,y:686,t:1527876760189};\\\", \\\"{x:887,y:686,t:1527876760207};\\\", \\\"{x:888,y:686,t:1527876760223};\\\", \\\"{x:891,y:686,t:1527876760239};\\\", \\\"{x:892,y:686,t:1527876760320};\\\", \\\"{x:893,y:686,t:1527876760592};\\\", \\\"{x:895,y:689,t:1527876760607};\\\", \\\"{x:917,y:693,t:1527876760624};\\\", \\\"{x:937,y:695,t:1527876760640};\\\", \\\"{x:959,y:697,t:1527876760657};\\\", \\\"{x:980,y:698,t:1527876760673};\\\", \\\"{x:996,y:698,t:1527876760691};\\\", \\\"{x:1006,y:698,t:1527876760709};\\\", \\\"{x:1014,y:698,t:1527876760724};\\\", \\\"{x:1022,y:698,t:1527876760741};\\\", \\\"{x:1030,y:700,t:1527876760756};\\\", \\\"{x:1042,y:700,t:1527876760774};\\\", \\\"{x:1057,y:700,t:1527876760791};\\\", \\\"{x:1086,y:700,t:1527876760809};\\\", \\\"{x:1105,y:700,t:1527876760823};\\\", \\\"{x:1128,y:700,t:1527876760840};\\\", \\\"{x:1150,y:700,t:1527876760856};\\\", \\\"{x:1168,y:700,t:1527876760873};\\\", \\\"{x:1188,y:700,t:1527876760890};\\\", \\\"{x:1202,y:700,t:1527876760906};\\\", \\\"{x:1212,y:700,t:1527876760923};\\\", \\\"{x:1216,y:700,t:1527876760941};\\\", \\\"{x:1218,y:700,t:1527876760957};\\\", \\\"{x:1219,y:700,t:1527876760973};\\\", \\\"{x:1221,y:700,t:1527876760990};\\\", \\\"{x:1225,y:700,t:1527876761007};\\\", \\\"{x:1228,y:700,t:1527876761023};\\\", \\\"{x:1236,y:699,t:1527876761040};\\\", \\\"{x:1241,y:699,t:1527876761057};\\\", \\\"{x:1248,y:698,t:1527876761074};\\\", \\\"{x:1253,y:698,t:1527876761090};\\\", \\\"{x:1257,y:697,t:1527876761107};\\\", \\\"{x:1258,y:697,t:1527876761123};\\\", \\\"{x:1259,y:697,t:1527876761712};\\\", \\\"{x:1260,y:702,t:1527876761727};\\\", \\\"{x:1260,y:708,t:1527876761742};\\\", \\\"{x:1260,y:722,t:1527876761758};\\\", \\\"{x:1260,y:739,t:1527876761775};\\\", \\\"{x:1260,y:757,t:1527876761792};\\\", \\\"{x:1259,y:762,t:1527876761808};\\\", \\\"{x:1256,y:770,t:1527876761825};\\\", \\\"{x:1253,y:778,t:1527876761842};\\\", \\\"{x:1249,y:786,t:1527876761858};\\\", \\\"{x:1245,y:793,t:1527876761875};\\\", \\\"{x:1239,y:801,t:1527876761892};\\\", \\\"{x:1231,y:810,t:1527876761908};\\\", \\\"{x:1226,y:815,t:1527876761925};\\\", \\\"{x:1219,y:819,t:1527876761942};\\\", \\\"{x:1215,y:822,t:1527876761958};\\\", \\\"{x:1214,y:823,t:1527876761975};\\\", \\\"{x:1213,y:825,t:1527876761994};\\\", \\\"{x:1212,y:826,t:1527876762009};\\\", \\\"{x:1211,y:829,t:1527876762025};\\\", \\\"{x:1211,y:830,t:1527876762041};\\\", \\\"{x:1211,y:832,t:1527876762058};\\\", \\\"{x:1211,y:830,t:1527876772216};\\\", \\\"{x:1211,y:828,t:1527876772223};\\\", \\\"{x:1211,y:825,t:1527876772235};\\\", \\\"{x:1213,y:823,t:1527876772254};\\\", \\\"{x:1214,y:822,t:1527876772269};\\\", \\\"{x:1215,y:821,t:1527876772286};\\\", \\\"{x:1216,y:821,t:1527876772303};\\\", \\\"{x:1216,y:820,t:1527876772479};\\\", \\\"{x:1217,y:819,t:1527876772487};\\\", \\\"{x:1218,y:818,t:1527876772502};\\\", \\\"{x:1219,y:817,t:1527876772519};\\\", \\\"{x:1219,y:816,t:1527876772543};\\\", \\\"{x:1220,y:815,t:1527876772552};\\\", \\\"{x:1221,y:814,t:1527876772569};\\\", \\\"{x:1223,y:810,t:1527876772586};\\\", \\\"{x:1225,y:808,t:1527876772603};\\\", \\\"{x:1227,y:805,t:1527876772619};\\\", \\\"{x:1228,y:803,t:1527876772635};\\\", \\\"{x:1229,y:801,t:1527876772653};\\\", \\\"{x:1231,y:798,t:1527876772670};\\\", \\\"{x:1232,y:795,t:1527876772687};\\\", \\\"{x:1234,y:791,t:1527876772703};\\\", \\\"{x:1235,y:790,t:1527876772718};\\\", \\\"{x:1236,y:788,t:1527876772736};\\\", \\\"{x:1238,y:785,t:1527876772752};\\\", \\\"{x:1239,y:784,t:1527876772769};\\\", \\\"{x:1239,y:782,t:1527876772786};\\\", \\\"{x:1239,y:781,t:1527876772803};\\\", \\\"{x:1240,y:780,t:1527876772819};\\\", \\\"{x:1242,y:778,t:1527876772835};\\\", \\\"{x:1246,y:771,t:1527876772853};\\\", \\\"{x:1249,y:766,t:1527876772869};\\\", \\\"{x:1251,y:764,t:1527876772886};\\\", \\\"{x:1253,y:760,t:1527876772903};\\\", \\\"{x:1253,y:759,t:1527876772920};\\\", \\\"{x:1255,y:756,t:1527876772936};\\\", \\\"{x:1256,y:755,t:1527876772959};\\\", \\\"{x:1256,y:754,t:1527876772970};\\\", \\\"{x:1256,y:753,t:1527876772986};\\\", \\\"{x:1260,y:751,t:1527876773003};\\\", \\\"{x:1260,y:750,t:1527876773019};\\\", \\\"{x:1261,y:749,t:1527876773036};\\\", \\\"{x:1262,y:747,t:1527876773054};\\\", \\\"{x:1263,y:747,t:1527876773070};\\\", \\\"{x:1263,y:746,t:1527876773088};\\\", \\\"{x:1263,y:745,t:1527876773103};\\\", \\\"{x:1264,y:744,t:1527876773120};\\\", \\\"{x:1265,y:743,t:1527876773136};\\\", \\\"{x:1265,y:742,t:1527876773153};\\\", \\\"{x:1266,y:742,t:1527876773170};\\\", \\\"{x:1267,y:741,t:1527876773186};\\\", \\\"{x:1267,y:740,t:1527876773208};\\\", \\\"{x:1267,y:739,t:1527876773220};\\\", \\\"{x:1267,y:738,t:1527876773237};\\\", \\\"{x:1269,y:737,t:1527876773254};\\\", \\\"{x:1269,y:735,t:1527876773270};\\\", \\\"{x:1272,y:731,t:1527876773288};\\\", \\\"{x:1274,y:728,t:1527876773303};\\\", \\\"{x:1278,y:720,t:1527876773320};\\\", \\\"{x:1286,y:709,t:1527876773336};\\\", \\\"{x:1290,y:701,t:1527876773353};\\\", \\\"{x:1293,y:695,t:1527876773370};\\\", \\\"{x:1296,y:692,t:1527876773387};\\\", \\\"{x:1298,y:690,t:1527876773402};\\\", \\\"{x:1298,y:688,t:1527876773420};\\\", \\\"{x:1299,y:685,t:1527876773437};\\\", \\\"{x:1302,y:682,t:1527876773453};\\\", \\\"{x:1305,y:676,t:1527876773470};\\\", \\\"{x:1308,y:670,t:1527876773487};\\\", \\\"{x:1310,y:665,t:1527876773503};\\\", \\\"{x:1311,y:661,t:1527876773520};\\\", \\\"{x:1312,y:657,t:1527876773537};\\\", \\\"{x:1313,y:655,t:1527876773553};\\\", \\\"{x:1314,y:652,t:1527876773570};\\\", \\\"{x:1314,y:649,t:1527876773587};\\\", \\\"{x:1314,y:648,t:1527876773604};\\\", \\\"{x:1314,y:646,t:1527876773620};\\\", \\\"{x:1314,y:644,t:1527876773637};\\\", \\\"{x:1314,y:643,t:1527876773654};\\\", \\\"{x:1315,y:642,t:1527876773671};\\\", \\\"{x:1315,y:640,t:1527876773687};\\\", \\\"{x:1315,y:637,t:1527876773704};\\\", \\\"{x:1316,y:634,t:1527876773720};\\\", \\\"{x:1316,y:632,t:1527876773737};\\\", \\\"{x:1317,y:630,t:1527876773754};\\\", \\\"{x:1317,y:627,t:1527876773770};\\\", \\\"{x:1317,y:625,t:1527876773800};\\\", \\\"{x:1317,y:620,t:1527876774872};\\\", \\\"{x:1312,y:602,t:1527876774888};\\\", \\\"{x:1307,y:590,t:1527876774905};\\\", \\\"{x:1298,y:576,t:1527876774922};\\\", \\\"{x:1292,y:566,t:1527876774938};\\\", \\\"{x:1289,y:563,t:1527876774956};\\\", \\\"{x:1289,y:561,t:1527876774973};\\\", \\\"{x:1286,y:559,t:1527876774988};\\\", \\\"{x:1285,y:557,t:1527876775005};\\\", \\\"{x:1285,y:556,t:1527876775023};\\\", \\\"{x:1284,y:556,t:1527876775038};\\\", \\\"{x:1283,y:557,t:1527876776184};\\\", \\\"{x:1282,y:559,t:1527876776200};\\\", \\\"{x:1280,y:561,t:1527876776224};\\\", \\\"{x:1276,y:565,t:1527876776736};\\\", \\\"{x:1265,y:568,t:1527876776745};\\\", \\\"{x:1249,y:573,t:1527876776758};\\\", \\\"{x:1188,y:590,t:1527876776773};\\\", \\\"{x:1110,y:612,t:1527876776791};\\\", \\\"{x:950,y:638,t:1527876776807};\\\", \\\"{x:850,y:654,t:1527876776824};\\\", \\\"{x:758,y:665,t:1527876776840};\\\", \\\"{x:700,y:674,t:1527876776858};\\\", \\\"{x:668,y:678,t:1527876776873};\\\", \\\"{x:647,y:679,t:1527876776890};\\\", \\\"{x:635,y:679,t:1527876776908};\\\", \\\"{x:632,y:679,t:1527876776925};\\\", \\\"{x:627,y:679,t:1527876776940};\\\", \\\"{x:623,y:679,t:1527876776957};\\\", \\\"{x:608,y:678,t:1527876776975};\\\", \\\"{x:591,y:678,t:1527876776991};\\\", \\\"{x:564,y:675,t:1527876777007};\\\", \\\"{x:551,y:673,t:1527876777023};\\\", \\\"{x:538,y:671,t:1527876777040};\\\", \\\"{x:528,y:668,t:1527876777057};\\\", \\\"{x:520,y:664,t:1527876777074};\\\", \\\"{x:516,y:663,t:1527876777090};\\\", \\\"{x:511,y:662,t:1527876777109};\\\", \\\"{x:507,y:659,t:1527876777124};\\\", \\\"{x:494,y:657,t:1527876777142};\\\", \\\"{x:472,y:649,t:1527876777157};\\\", \\\"{x:439,y:641,t:1527876777174};\\\", \\\"{x:394,y:633,t:1527876777185};\\\", \\\"{x:331,y:628,t:1527876777202};\\\", \\\"{x:294,y:626,t:1527876777219};\\\", \\\"{x:287,y:626,t:1527876777235};\\\", \\\"{x:286,y:626,t:1527876777262};\\\", \\\"{x:284,y:626,t:1527876777270};\\\", \\\"{x:281,y:626,t:1527876777285};\\\", \\\"{x:271,y:629,t:1527876777302};\\\", \\\"{x:241,y:639,t:1527876777319};\\\", \\\"{x:232,y:643,t:1527876777335};\\\", \\\"{x:230,y:644,t:1527876777351};\\\", \\\"{x:231,y:644,t:1527876777391};\\\", \\\"{x:228,y:643,t:1527876777616};\\\", \\\"{x:228,y:641,t:1527876777624};\\\", \\\"{x:228,y:638,t:1527876777637};\\\", \\\"{x:228,y:633,t:1527876777652};\\\", \\\"{x:228,y:630,t:1527876777669};\\\", \\\"{x:228,y:629,t:1527876777686};\\\", \\\"{x:228,y:628,t:1527876777710};\\\", \\\"{x:229,y:628,t:1527876777719};\\\", \\\"{x:241,y:627,t:1527876777736};\\\", \\\"{x:270,y:625,t:1527876777752};\\\", \\\"{x:323,y:625,t:1527876777769};\\\", \\\"{x:386,y:620,t:1527876777787};\\\", \\\"{x:466,y:613,t:1527876777804};\\\", \\\"{x:538,y:606,t:1527876777819};\\\", \\\"{x:591,y:598,t:1527876777836};\\\", \\\"{x:620,y:593,t:1527876777853};\\\", \\\"{x:642,y:591,t:1527876777869};\\\", \\\"{x:659,y:588,t:1527876777886};\\\", \\\"{x:670,y:587,t:1527876777902};\\\", \\\"{x:675,y:587,t:1527876777919};\\\", \\\"{x:680,y:586,t:1527876777936};\\\", \\\"{x:686,y:584,t:1527876777952};\\\", \\\"{x:697,y:582,t:1527876777969};\\\", \\\"{x:715,y:577,t:1527876777986};\\\", \\\"{x:735,y:573,t:1527876778003};\\\", \\\"{x:749,y:571,t:1527876778019};\\\", \\\"{x:757,y:570,t:1527876778036};\\\", \\\"{x:758,y:570,t:1527876778053};\\\", \\\"{x:759,y:570,t:1527876778069};\\\", \\\"{x:755,y:570,t:1527876778103};\\\", \\\"{x:735,y:570,t:1527876778118};\\\", \\\"{x:706,y:570,t:1527876778137};\\\", \\\"{x:664,y:570,t:1527876778153};\\\", \\\"{x:612,y:574,t:1527876778169};\\\", \\\"{x:581,y:579,t:1527876778187};\\\", \\\"{x:565,y:581,t:1527876778203};\\\", \\\"{x:561,y:582,t:1527876778219};\\\", \\\"{x:559,y:582,t:1527876778287};\\\", \\\"{x:556,y:584,t:1527876778303};\\\", \\\"{x:549,y:590,t:1527876778319};\\\", \\\"{x:534,y:599,t:1527876778337};\\\", \\\"{x:519,y:605,t:1527876778356};\\\", \\\"{x:507,y:609,t:1527876778369};\\\", \\\"{x:498,y:611,t:1527876778386};\\\", \\\"{x:495,y:611,t:1527876778403};\\\", \\\"{x:492,y:611,t:1527876778420};\\\", \\\"{x:490,y:611,t:1527876778436};\\\", \\\"{x:485,y:611,t:1527876778453};\\\", \\\"{x:483,y:613,t:1527876778470};\\\", \\\"{x:480,y:613,t:1527876778486};\\\", \\\"{x:478,y:613,t:1527876778502};\\\", \\\"{x:473,y:611,t:1527876778520};\\\", \\\"{x:469,y:601,t:1527876778536};\\\", \\\"{x:464,y:587,t:1527876778554};\\\", \\\"{x:461,y:576,t:1527876778569};\\\", \\\"{x:457,y:563,t:1527876778585};\\\", \\\"{x:454,y:548,t:1527876778604};\\\", \\\"{x:449,y:531,t:1527876778620};\\\", \\\"{x:447,y:525,t:1527876778635};\\\", \\\"{x:446,y:521,t:1527876778653};\\\", \\\"{x:445,y:519,t:1527876778670};\\\", \\\"{x:444,y:516,t:1527876778688};\\\", \\\"{x:446,y:516,t:1527876778815};\\\", \\\"{x:447,y:516,t:1527876778823};\\\", \\\"{x:454,y:516,t:1527876778837};\\\", \\\"{x:469,y:516,t:1527876778853};\\\", \\\"{x:487,y:516,t:1527876778870};\\\", \\\"{x:511,y:514,t:1527876778890};\\\", \\\"{x:517,y:512,t:1527876778903};\\\", \\\"{x:518,y:512,t:1527876778920};\\\", \\\"{x:519,y:512,t:1527876778990};\\\", \\\"{x:520,y:512,t:1527876779003};\\\", \\\"{x:522,y:512,t:1527876779019};\\\", \\\"{x:525,y:512,t:1527876779037};\\\", \\\"{x:529,y:512,t:1527876779053};\\\", \\\"{x:535,y:512,t:1527876779070};\\\", \\\"{x:544,y:512,t:1527876779087};\\\", \\\"{x:550,y:512,t:1527876779104};\\\", \\\"{x:560,y:512,t:1527876779120};\\\", \\\"{x:568,y:510,t:1527876779137};\\\", \\\"{x:571,y:509,t:1527876779154};\\\", \\\"{x:572,y:509,t:1527876779170};\\\", \\\"{x:573,y:509,t:1527876779187};\\\", \\\"{x:575,y:507,t:1527876779207};\\\", \\\"{x:577,y:505,t:1527876779220};\\\", \\\"{x:581,y:502,t:1527876779237};\\\", \\\"{x:586,y:499,t:1527876779254};\\\", \\\"{x:588,y:497,t:1527876779270};\\\", \\\"{x:589,y:496,t:1527876779287};\\\", \\\"{x:591,y:495,t:1527876779304};\\\", \\\"{x:594,y:494,t:1527876779320};\\\", \\\"{x:604,y:490,t:1527876779337};\\\", \\\"{x:615,y:486,t:1527876779355};\\\", \\\"{x:628,y:480,t:1527876779370};\\\", \\\"{x:637,y:476,t:1527876779387};\\\", \\\"{x:641,y:474,t:1527876779404};\\\", \\\"{x:644,y:472,t:1527876779420};\\\", \\\"{x:645,y:473,t:1527876779503};\\\", \\\"{x:645,y:478,t:1527876779520};\\\", \\\"{x:645,y:481,t:1527876779538};\\\", \\\"{x:640,y:484,t:1527876779554};\\\", \\\"{x:628,y:490,t:1527876779572};\\\", \\\"{x:627,y:490,t:1527876779587};\\\", \\\"{x:624,y:490,t:1527876779603};\\\", \\\"{x:623,y:490,t:1527876779620};\\\", \\\"{x:620,y:490,t:1527876779638};\\\", \\\"{x:620,y:491,t:1527876779743};\\\", \\\"{x:620,y:492,t:1527876779767};\\\", \\\"{x:621,y:492,t:1527876780624};\\\", \\\"{x:620,y:501,t:1527876780639};\\\", \\\"{x:611,y:534,t:1527876780657};\\\", \\\"{x:602,y:555,t:1527876780671};\\\", \\\"{x:596,y:568,t:1527876780689};\\\", \\\"{x:592,y:581,t:1527876780705};\\\", \\\"{x:587,y:596,t:1527876780721};\\\", \\\"{x:581,y:613,t:1527876780738};\\\", \\\"{x:577,y:632,t:1527876780755};\\\", \\\"{x:570,y:652,t:1527876780771};\\\", \\\"{x:567,y:666,t:1527876780788};\\\", \\\"{x:565,y:674,t:1527876780805};\\\", \\\"{x:559,y:682,t:1527876780821};\\\", \\\"{x:557,y:684,t:1527876780838};\\\", \\\"{x:556,y:687,t:1527876780855};\\\", \\\"{x:554,y:691,t:1527876780871};\\\", \\\"{x:553,y:692,t:1527876780887};\\\", \\\"{x:552,y:693,t:1527876780905};\\\", \\\"{x:550,y:695,t:1527876780921};\\\", \\\"{x:550,y:696,t:1527876780938};\\\", \\\"{x:547,y:698,t:1527876780955};\\\", \\\"{x:543,y:701,t:1527876780972};\\\", \\\"{x:539,y:704,t:1527876780988};\\\", \\\"{x:535,y:706,t:1527876781005};\\\", \\\"{x:532,y:706,t:1527876781022};\\\", \\\"{x:531,y:708,t:1527876781135};\\\", \\\"{x:529,y:711,t:1527876781143};\\\", \\\"{x:527,y:717,t:1527876781155};\\\", \\\"{x:523,y:727,t:1527876781173};\\\", \\\"{x:522,y:734,t:1527876781188};\\\", \\\"{x:520,y:739,t:1527876781205};\\\", \\\"{x:519,y:742,t:1527876781222};\\\", \\\"{x:519,y:743,t:1527876781239};\\\", \\\"{x:518,y:743,t:1527876781463};\\\", \\\"{x:517,y:742,t:1527876781479};\\\", \\\"{x:517,y:741,t:1527876781490};\\\", \\\"{x:517,y:738,t:1527876781508};\\\", \\\"{x:516,y:737,t:1527876781523};\\\" ] }, { \\\"rt\\\": 7115, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 14, \\\"time_elapsed\\\": 401602, \\\"internal_node_id\\\": \\\"0.0-6.0-4.0\\\", \\\"subject\\\": \\\"HW2SN\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"xray\\\", \\\"condition\\\": \\\"311\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"ends\\\", \\\"q\\\": 10, \\\"clicks\\\": 1, \\\"explicit\\\": 3, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XInside-YFull\\\", \\\"correct\\\": 1, \\\"orth_correct\\\": 0, \\\"answer\\\": [ \\\"E\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-6-F -F \\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:516,y:736,t:1527876783702};\\\", \\\"{x:521,y:722,t:1527876783724};\\\", \\\"{x:528,y:698,t:1527876783741};\\\", \\\"{x:539,y:667,t:1527876783758};\\\", \\\"{x:558,y:618,t:1527876783774};\\\", \\\"{x:580,y:559,t:1527876783790};\\\", \\\"{x:612,y:485,t:1527876783807};\\\", \\\"{x:617,y:471,t:1527876783824};\\\", \\\"{x:619,y:464,t:1527876783840};\\\", \\\"{x:621,y:459,t:1527876783857};\\\", \\\"{x:622,y:457,t:1527876783874};\\\", \\\"{x:622,y:455,t:1527876783890};\\\", \\\"{x:622,y:453,t:1527876783976};\\\", \\\"{x:621,y:453,t:1527876783990};\\\", \\\"{x:625,y:453,t:1527876784128};\\\", \\\"{x:637,y:453,t:1527876784142};\\\", \\\"{x:648,y:455,t:1527876784158};\\\", \\\"{x:659,y:464,t:1527876784175};\\\", \\\"{x:662,y:465,t:1527876784192};\\\", \\\"{x:664,y:465,t:1527876784319};\\\", \\\"{x:666,y:467,t:1527876784327};\\\", \\\"{x:668,y:468,t:1527876784343};\\\", \\\"{x:670,y:468,t:1527876784357};\\\", \\\"{x:670,y:469,t:1527876784374};\\\", \\\"{x:671,y:469,t:1527876784438};\\\", \\\"{x:673,y:469,t:1527876784455};\\\", \\\"{x:674,y:469,t:1527876784478};\\\", \\\"{x:676,y:469,t:1527876785839};\\\", \\\"{x:678,y:469,t:1527876785847};\\\", \\\"{x:681,y:470,t:1527876785859};\\\", \\\"{x:685,y:471,t:1527876785876};\\\", \\\"{x:688,y:472,t:1527876785892};\\\", \\\"{x:692,y:473,t:1527876785909};\\\", \\\"{x:696,y:474,t:1527876785926};\\\", \\\"{x:700,y:475,t:1527876785943};\\\", \\\"{x:707,y:478,t:1527876785960};\\\", \\\"{x:712,y:479,t:1527876785975};\\\", \\\"{x:719,y:481,t:1527876785992};\\\", \\\"{x:732,y:484,t:1527876786009};\\\", \\\"{x:749,y:489,t:1527876786027};\\\", \\\"{x:766,y:494,t:1527876786042};\\\", \\\"{x:780,y:495,t:1527876786059};\\\", \\\"{x:790,y:498,t:1527876786076};\\\", \\\"{x:794,y:498,t:1527876786092};\\\", \\\"{x:800,y:500,t:1527876786109};\\\", \\\"{x:809,y:502,t:1527876786126};\\\", \\\"{x:814,y:502,t:1527876786142};\\\", \\\"{x:820,y:503,t:1527876786159};\\\", \\\"{x:825,y:503,t:1527876786176};\\\", \\\"{x:831,y:505,t:1527876786192};\\\", \\\"{x:837,y:506,t:1527876786209};\\\", \\\"{x:843,y:507,t:1527876786226};\\\", \\\"{x:851,y:507,t:1527876786243};\\\", \\\"{x:861,y:510,t:1527876786259};\\\", \\\"{x:870,y:512,t:1527876786277};\\\", \\\"{x:882,y:516,t:1527876786292};\\\", \\\"{x:893,y:520,t:1527876786309};\\\", \\\"{x:921,y:526,t:1527876786327};\\\", \\\"{x:948,y:536,t:1527876786342};\\\", \\\"{x:967,y:542,t:1527876786360};\\\", \\\"{x:992,y:549,t:1527876786377};\\\", \\\"{x:1014,y:556,t:1527876786392};\\\", \\\"{x:1036,y:561,t:1527876786409};\\\", \\\"{x:1059,y:569,t:1527876786427};\\\", \\\"{x:1082,y:575,t:1527876786443};\\\", \\\"{x:1110,y:583,t:1527876786459};\\\", \\\"{x:1150,y:594,t:1527876786476};\\\", \\\"{x:1175,y:601,t:1527876786493};\\\", \\\"{x:1196,y:605,t:1527876786509};\\\", \\\"{x:1227,y:611,t:1527876786527};\\\", \\\"{x:1244,y:613,t:1527876786543};\\\", \\\"{x:1257,y:616,t:1527876786560};\\\", \\\"{x:1266,y:618,t:1527876786577};\\\", \\\"{x:1273,y:620,t:1527876786593};\\\", \\\"{x:1279,y:622,t:1527876786609};\\\", \\\"{x:1283,y:624,t:1527876786626};\\\", \\\"{x:1286,y:626,t:1527876786643};\\\", \\\"{x:1290,y:628,t:1527876786660};\\\", \\\"{x:1295,y:632,t:1527876786676};\\\", \\\"{x:1298,y:635,t:1527876786693};\\\", \\\"{x:1302,y:639,t:1527876786710};\\\", \\\"{x:1308,y:647,t:1527876786726};\\\", \\\"{x:1312,y:653,t:1527876786743};\\\", \\\"{x:1318,y:661,t:1527876786759};\\\", \\\"{x:1322,y:667,t:1527876786777};\\\", \\\"{x:1328,y:676,t:1527876786794};\\\", \\\"{x:1340,y:691,t:1527876786809};\\\", \\\"{x:1354,y:706,t:1527876786826};\\\", \\\"{x:1369,y:724,t:1527876786844};\\\", \\\"{x:1380,y:739,t:1527876786860};\\\", \\\"{x:1388,y:746,t:1527876786877};\\\", \\\"{x:1392,y:749,t:1527876786894};\\\", \\\"{x:1393,y:748,t:1527876786984};\\\", \\\"{x:1393,y:744,t:1527876786994};\\\", \\\"{x:1391,y:738,t:1527876787010};\\\", \\\"{x:1389,y:732,t:1527876787027};\\\", \\\"{x:1386,y:727,t:1527876787044};\\\", \\\"{x:1382,y:721,t:1527876787060};\\\", \\\"{x:1379,y:716,t:1527876787077};\\\", \\\"{x:1377,y:715,t:1527876787094};\\\", \\\"{x:1377,y:714,t:1527876787110};\\\", \\\"{x:1376,y:713,t:1527876787127};\\\", \\\"{x:1372,y:708,t:1527876787143};\\\", \\\"{x:1368,y:705,t:1527876787160};\\\", \\\"{x:1365,y:702,t:1527876787177};\\\", \\\"{x:1362,y:699,t:1527876787194};\\\", \\\"{x:1360,y:697,t:1527876787210};\\\", \\\"{x:1358,y:696,t:1527876787227};\\\", \\\"{x:1357,y:696,t:1527876787247};\\\", \\\"{x:1356,y:696,t:1527876787279};\\\", \\\"{x:1355,y:695,t:1527876787294};\\\", \\\"{x:1354,y:695,t:1527876787311};\\\", \\\"{x:1352,y:695,t:1527876787330};\\\", \\\"{x:1350,y:693,t:1527876787343};\\\", \\\"{x:1348,y:692,t:1527876787360};\\\", \\\"{x:1347,y:691,t:1527876787376};\\\", \\\"{x:1345,y:691,t:1527876788543};\\\", \\\"{x:1338,y:680,t:1527876788551};\\\", \\\"{x:1333,y:667,t:1527876788560};\\\", \\\"{x:1323,y:647,t:1527876788577};\\\", \\\"{x:1312,y:631,t:1527876788594};\\\", \\\"{x:1300,y:616,t:1527876788610};\\\", \\\"{x:1285,y:598,t:1527876788627};\\\", \\\"{x:1277,y:589,t:1527876788644};\\\", \\\"{x:1268,y:584,t:1527876788660};\\\", \\\"{x:1250,y:578,t:1527876788678};\\\", \\\"{x:1202,y:572,t:1527876788694};\\\", \\\"{x:1152,y:572,t:1527876788711};\\\", \\\"{x:1069,y:572,t:1527876788727};\\\", \\\"{x:971,y:572,t:1527876788744};\\\", \\\"{x:891,y:572,t:1527876788761};\\\", \\\"{x:825,y:576,t:1527876788777};\\\", \\\"{x:772,y:584,t:1527876788794};\\\", \\\"{x:721,y:587,t:1527876788812};\\\", \\\"{x:667,y:595,t:1527876788829};\\\", \\\"{x:622,y:596,t:1527876788844};\\\", \\\"{x:600,y:596,t:1527876788861};\\\", \\\"{x:586,y:596,t:1527876788878};\\\", \\\"{x:574,y:596,t:1527876788894};\\\", \\\"{x:553,y:596,t:1527876788911};\\\", \\\"{x:526,y:596,t:1527876788928};\\\", \\\"{x:500,y:596,t:1527876788944};\\\", \\\"{x:478,y:594,t:1527876788961};\\\", \\\"{x:457,y:594,t:1527876788978};\\\", \\\"{x:433,y:594,t:1527876788995};\\\", \\\"{x:424,y:594,t:1527876789011};\\\", \\\"{x:423,y:594,t:1527876789028};\\\", \\\"{x:422,y:593,t:1527876789097};\\\", \\\"{x:421,y:592,t:1527876789111};\\\", \\\"{x:420,y:588,t:1527876789128};\\\", \\\"{x:418,y:581,t:1527876789146};\\\", \\\"{x:410,y:567,t:1527876789162};\\\", \\\"{x:400,y:552,t:1527876789179};\\\", \\\"{x:395,y:541,t:1527876789196};\\\", \\\"{x:395,y:538,t:1527876789211};\\\", \\\"{x:395,y:535,t:1527876789228};\\\", \\\"{x:400,y:530,t:1527876789245};\\\", \\\"{x:416,y:523,t:1527876789261};\\\", \\\"{x:450,y:519,t:1527876789278};\\\", \\\"{x:489,y:518,t:1527876789295};\\\", \\\"{x:535,y:516,t:1527876789312};\\\", \\\"{x:569,y:516,t:1527876789328};\\\", \\\"{x:591,y:513,t:1527876789345};\\\", \\\"{x:602,y:511,t:1527876789361};\\\", \\\"{x:603,y:511,t:1527876789378};\\\", \\\"{x:604,y:511,t:1527876789463};\\\", \\\"{x:604,y:510,t:1527876789478};\\\", \\\"{x:605,y:508,t:1527876789495};\\\", \\\"{x:606,y:506,t:1527876789513};\\\", \\\"{x:608,y:505,t:1527876789529};\\\", \\\"{x:609,y:503,t:1527876789545};\\\", \\\"{x:609,y:507,t:1527876789726};\\\", \\\"{x:606,y:514,t:1527876789734};\\\", \\\"{x:601,y:526,t:1527876789747};\\\", \\\"{x:596,y:547,t:1527876789762};\\\", \\\"{x:594,y:568,t:1527876789779};\\\", \\\"{x:588,y:598,t:1527876789795};\\\", \\\"{x:582,y:642,t:1527876789812};\\\", \\\"{x:576,y:669,t:1527876789828};\\\", \\\"{x:571,y:685,t:1527876789845};\\\", \\\"{x:568,y:693,t:1527876789863};\\\", \\\"{x:568,y:694,t:1527876789878};\\\", \\\"{x:567,y:694,t:1527876789902};\\\", \\\"{x:567,y:696,t:1527876789926};\\\", \\\"{x:566,y:698,t:1527876789934};\\\", \\\"{x:564,y:701,t:1527876789946};\\\", \\\"{x:563,y:704,t:1527876789962};\\\", \\\"{x:561,y:706,t:1527876789978};\\\", \\\"{x:560,y:708,t:1527876789995};\\\", \\\"{x:557,y:708,t:1527876790012};\\\", \\\"{x:551,y:705,t:1527876790028};\\\", \\\"{x:548,y:703,t:1527876790046};\\\", \\\"{x:546,y:704,t:1527876790079};\\\", \\\"{x:546,y:710,t:1527876790095};\\\", \\\"{x:545,y:723,t:1527876790113};\\\", \\\"{x:545,y:732,t:1527876790129};\\\", \\\"{x:545,y:734,t:1527876790145};\\\" ] }, { \\\"rt\\\": 11659, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 15, \\\"time_elapsed\\\": 414589, \\\"internal_node_id\\\": \\\"0.0-6.0-5.0\\\", \\\"subject\\\": \\\"HW2SN\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"xray\\\", \\\"condition\\\": \\\"311\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"starttime\\\", \\\"q\\\": 11, \\\"clicks\\\": 2, \\\"explicit\\\": 3, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XInside-YFull\\\", \\\"correct\\\": 1, \\\"orth_correct\\\": 0, \\\"answer\\\": [ \\\"M\\\", \\\"L\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-3-M -M \\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:553,y:734,t:1527876794680};\\\", \\\"{x:584,y:734,t:1527876794691};\\\", \\\"{x:677,y:742,t:1527876794707};\\\", \\\"{x:767,y:763,t:1527876794723};\\\", \\\"{x:811,y:773,t:1527876794733};\\\", \\\"{x:896,y:793,t:1527876794750};\\\", \\\"{x:982,y:803,t:1527876794766};\\\", \\\"{x:1110,y:803,t:1527876794782};\\\", \\\"{x:1187,y:803,t:1527876794800};\\\", \\\"{x:1227,y:803,t:1527876794815};\\\", \\\"{x:1246,y:806,t:1527876794833};\\\", \\\"{x:1256,y:808,t:1527876794849};\\\", \\\"{x:1275,y:808,t:1527876794866};\\\", \\\"{x:1278,y:808,t:1527876794883};\\\", \\\"{x:1277,y:808,t:1527876795192};\\\", \\\"{x:1275,y:806,t:1527876795200};\\\", \\\"{x:1266,y:805,t:1527876795217};\\\", \\\"{x:1227,y:794,t:1527876795233};\\\", \\\"{x:1199,y:786,t:1527876795250};\\\", \\\"{x:1191,y:783,t:1527876795267};\\\", \\\"{x:1184,y:782,t:1527876795284};\\\", \\\"{x:1172,y:779,t:1527876795300};\\\", \\\"{x:1153,y:776,t:1527876795317};\\\", \\\"{x:1125,y:766,t:1527876795334};\\\", \\\"{x:1091,y:757,t:1527876795350};\\\", \\\"{x:1039,y:747,t:1527876795367};\\\", \\\"{x:1025,y:746,t:1527876795383};\\\", \\\"{x:1025,y:745,t:1527876797518};\\\", \\\"{x:1057,y:762,t:1527876797535};\\\", \\\"{x:1118,y:790,t:1527876797553};\\\", \\\"{x:1163,y:804,t:1527876797568};\\\", \\\"{x:1221,y:812,t:1527876797585};\\\", \\\"{x:1264,y:813,t:1527876797602};\\\", \\\"{x:1290,y:813,t:1527876797618};\\\", \\\"{x:1305,y:813,t:1527876797634};\\\", \\\"{x:1309,y:813,t:1527876797652};\\\", \\\"{x:1310,y:815,t:1527876797668};\\\", \\\"{x:1311,y:815,t:1527876797687};\\\", \\\"{x:1312,y:816,t:1527876797702};\\\", \\\"{x:1322,y:820,t:1527876797720};\\\", \\\"{x:1333,y:824,t:1527876797735};\\\", \\\"{x:1339,y:827,t:1527876797752};\\\", \\\"{x:1342,y:830,t:1527876797769};\\\", \\\"{x:1346,y:837,t:1527876797785};\\\", \\\"{x:1351,y:843,t:1527876797802};\\\", \\\"{x:1352,y:847,t:1527876797819};\\\", \\\"{x:1353,y:849,t:1527876797835};\\\", \\\"{x:1354,y:852,t:1527876797852};\\\", \\\"{x:1357,y:856,t:1527876797869};\\\", \\\"{x:1362,y:858,t:1527876797885};\\\", \\\"{x:1366,y:860,t:1527876797903};\\\", \\\"{x:1372,y:863,t:1527876797919};\\\", \\\"{x:1374,y:864,t:1527876797935};\\\", \\\"{x:1375,y:864,t:1527876797952};\\\", \\\"{x:1375,y:865,t:1527876797969};\\\", \\\"{x:1376,y:868,t:1527876797985};\\\", \\\"{x:1377,y:873,t:1527876798002};\\\", \\\"{x:1378,y:878,t:1527876798019};\\\", \\\"{x:1378,y:880,t:1527876798034};\\\", \\\"{x:1378,y:881,t:1527876798051};\\\", \\\"{x:1378,y:882,t:1527876798071};\\\", \\\"{x:1379,y:882,t:1527876798343};\\\", \\\"{x:1379,y:883,t:1527876798367};\\\", \\\"{x:1380,y:884,t:1527876798383};\\\", \\\"{x:1381,y:884,t:1527876798432};\\\", \\\"{x:1381,y:885,t:1527876798439};\\\", \\\"{x:1382,y:885,t:1527876798452};\\\", \\\"{x:1382,y:887,t:1527876798479};\\\", \\\"{x:1382,y:888,t:1527876798495};\\\", \\\"{x:1382,y:889,t:1527876798511};\\\", \\\"{x:1382,y:891,t:1527876798527};\\\", \\\"{x:1382,y:892,t:1527876798546};\\\", \\\"{x:1382,y:893,t:1527876798552};\\\", \\\"{x:1382,y:895,t:1527876798568};\\\", \\\"{x:1376,y:892,t:1527876800663};\\\", \\\"{x:1366,y:885,t:1527876800670};\\\", \\\"{x:1340,y:870,t:1527876800687};\\\", \\\"{x:1293,y:852,t:1527876800703};\\\", \\\"{x:1244,y:839,t:1527876800721};\\\", \\\"{x:1183,y:822,t:1527876800737};\\\", \\\"{x:1140,y:809,t:1527876800754};\\\", \\\"{x:1106,y:799,t:1527876800770};\\\", \\\"{x:1081,y:790,t:1527876800787};\\\", \\\"{x:1061,y:781,t:1527876800804};\\\", \\\"{x:1046,y:773,t:1527876800820};\\\", \\\"{x:1030,y:762,t:1527876800837};\\\", \\\"{x:1018,y:754,t:1527876800854};\\\", \\\"{x:998,y:742,t:1527876800871};\\\", \\\"{x:990,y:737,t:1527876800887};\\\", \\\"{x:975,y:732,t:1527876800904};\\\", \\\"{x:958,y:727,t:1527876800921};\\\", \\\"{x:931,y:718,t:1527876800937};\\\", \\\"{x:903,y:711,t:1527876800954};\\\", \\\"{x:863,y:699,t:1527876800971};\\\", \\\"{x:821,y:688,t:1527876800987};\\\", \\\"{x:794,y:682,t:1527876801004};\\\", \\\"{x:774,y:678,t:1527876801021};\\\", \\\"{x:753,y:674,t:1527876801038};\\\", \\\"{x:731,y:671,t:1527876801054};\\\", \\\"{x:705,y:665,t:1527876801071};\\\", \\\"{x:681,y:657,t:1527876801089};\\\", \\\"{x:653,y:652,t:1527876801104};\\\", \\\"{x:626,y:649,t:1527876801121};\\\", \\\"{x:604,y:645,t:1527876801138};\\\", \\\"{x:587,y:640,t:1527876801154};\\\", \\\"{x:577,y:638,t:1527876801171};\\\", \\\"{x:566,y:635,t:1527876801188};\\\", \\\"{x:555,y:631,t:1527876801206};\\\", \\\"{x:538,y:626,t:1527876801221};\\\", \\\"{x:503,y:612,t:1527876801238};\\\", \\\"{x:439,y:588,t:1527876801255};\\\", \\\"{x:389,y:572,t:1527876801271};\\\", \\\"{x:341,y:558,t:1527876801288};\\\", \\\"{x:312,y:550,t:1527876801305};\\\", \\\"{x:294,y:546,t:1527876801322};\\\", \\\"{x:289,y:544,t:1527876801338};\\\", \\\"{x:291,y:544,t:1527876801510};\\\", \\\"{x:295,y:544,t:1527876801522};\\\", \\\"{x:303,y:545,t:1527876801537};\\\", \\\"{x:312,y:545,t:1527876801554};\\\", \\\"{x:322,y:545,t:1527876801572};\\\", \\\"{x:335,y:543,t:1527876801587};\\\", \\\"{x:352,y:538,t:1527876801605};\\\", \\\"{x:371,y:532,t:1527876801622};\\\", \\\"{x:385,y:530,t:1527876801638};\\\", \\\"{x:396,y:529,t:1527876801654};\\\", \\\"{x:397,y:529,t:1527876801672};\\\", \\\"{x:396,y:529,t:1527876801879};\\\", \\\"{x:394,y:529,t:1527876801888};\\\", \\\"{x:390,y:528,t:1527876801904};\\\", \\\"{x:385,y:528,t:1527876801922};\\\", \\\"{x:384,y:528,t:1527876801939};\\\", \\\"{x:383,y:530,t:1527876802166};\\\", \\\"{x:385,y:536,t:1527876802174};\\\", \\\"{x:388,y:543,t:1527876802188};\\\", \\\"{x:393,y:554,t:1527876802205};\\\", \\\"{x:397,y:563,t:1527876802222};\\\", \\\"{x:401,y:576,t:1527876802239};\\\", \\\"{x:402,y:582,t:1527876802255};\\\", \\\"{x:402,y:589,t:1527876802272};\\\", \\\"{x:402,y:602,t:1527876802289};\\\", \\\"{x:401,y:613,t:1527876802306};\\\", \\\"{x:398,y:624,t:1527876802322};\\\", \\\"{x:396,y:629,t:1527876802339};\\\", \\\"{x:394,y:632,t:1527876802357};\\\", \\\"{x:391,y:635,t:1527876802371};\\\", \\\"{x:390,y:635,t:1527876802439};\\\", \\\"{x:389,y:635,t:1527876802470};\\\", \\\"{x:387,y:635,t:1527876802478};\\\", \\\"{x:387,y:634,t:1527876802488};\\\", \\\"{x:387,y:629,t:1527876802506};\\\", \\\"{x:387,y:628,t:1527876802522};\\\", \\\"{x:387,y:627,t:1527876802539};\\\", \\\"{x:387,y:626,t:1527876802574};\\\", \\\"{x:387,y:625,t:1527876802588};\\\", \\\"{x:386,y:624,t:1527876802605};\\\", \\\"{x:385,y:623,t:1527876802621};\\\", \\\"{x:385,y:628,t:1527876802846};\\\", \\\"{x:390,y:639,t:1527876802856};\\\", \\\"{x:410,y:664,t:1527876802873};\\\", \\\"{x:429,y:682,t:1527876802889};\\\", \\\"{x:452,y:695,t:1527876802906};\\\", \\\"{x:471,y:704,t:1527876802922};\\\", \\\"{x:484,y:709,t:1527876802939};\\\", \\\"{x:492,y:712,t:1527876802955};\\\", \\\"{x:497,y:715,t:1527876802973};\\\", \\\"{x:499,y:717,t:1527876802990};\\\", \\\"{x:500,y:719,t:1527876803006};\\\", \\\"{x:500,y:720,t:1527876803023};\\\", \\\"{x:501,y:721,t:1527876803152};\\\", \\\"{x:501,y:724,t:1527876803159};\\\", \\\"{x:501,y:728,t:1527876803173};\\\", \\\"{x:501,y:735,t:1527876803190};\\\", \\\"{x:502,y:737,t:1527876803206};\\\" ] }, { \\\"rt\\\": 6671, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 16, \\\"time_elapsed\\\": 422518, \\\"internal_node_id\\\": \\\"0.0-6.0-6.0\\\", \\\"subject\\\": \\\"HW2SN\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"xray\\\", \\\"condition\\\": \\\"311\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"starts\\\", \\\"q\\\": 12, \\\"clicks\\\": 1, \\\"explicit\\\": 3, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XInside-YFull\\\", \\\"correct\\\": 1, \\\"orth_correct\\\": 0, \\\"answer\\\": [ \\\"G\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-4-F \\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:504,y:738,t:1527876805206};\\\", \\\"{x:505,y:738,t:1527876805214};\\\", \\\"{x:507,y:738,t:1527876805224};\\\", \\\"{x:509,y:737,t:1527876805241};\\\", \\\"{x:511,y:736,t:1527876805318};\\\", \\\"{x:513,y:735,t:1527876805327};\\\", \\\"{x:515,y:734,t:1527876805341};\\\", \\\"{x:520,y:731,t:1527876805358};\\\", \\\"{x:523,y:731,t:1527876805374};\\\", \\\"{x:527,y:729,t:1527876805392};\\\", \\\"{x:529,y:728,t:1527876805408};\\\", \\\"{x:533,y:726,t:1527876805425};\\\", \\\"{x:534,y:726,t:1527876805441};\\\", \\\"{x:535,y:725,t:1527876805458};\\\", \\\"{x:540,y:725,t:1527876806383};\\\", \\\"{x:551,y:725,t:1527876806392};\\\", \\\"{x:591,y:727,t:1527876806411};\\\", \\\"{x:634,y:728,t:1527876806425};\\\", \\\"{x:698,y:728,t:1527876806442};\\\", \\\"{x:759,y:728,t:1527876806459};\\\", \\\"{x:826,y:728,t:1527876806474};\\\", \\\"{x:885,y:728,t:1527876806492};\\\", \\\"{x:916,y:728,t:1527876806508};\\\", \\\"{x:938,y:728,t:1527876806525};\\\", \\\"{x:957,y:723,t:1527876806542};\\\", \\\"{x:965,y:721,t:1527876806558};\\\", \\\"{x:975,y:718,t:1527876806575};\\\", \\\"{x:983,y:714,t:1527876806592};\\\", \\\"{x:993,y:710,t:1527876806609};\\\", \\\"{x:1003,y:706,t:1527876806625};\\\", \\\"{x:1017,y:703,t:1527876806642};\\\", \\\"{x:1031,y:702,t:1527876806659};\\\", \\\"{x:1045,y:700,t:1527876806676};\\\", \\\"{x:1058,y:700,t:1527876806692};\\\", \\\"{x:1073,y:698,t:1527876806709};\\\", \\\"{x:1097,y:698,t:1527876806727};\\\", \\\"{x:1114,y:698,t:1527876806742};\\\", \\\"{x:1140,y:696,t:1527876806760};\\\", \\\"{x:1172,y:696,t:1527876806776};\\\", \\\"{x:1219,y:696,t:1527876806792};\\\", \\\"{x:1253,y:696,t:1527876806809};\\\", \\\"{x:1280,y:696,t:1527876806826};\\\", \\\"{x:1304,y:694,t:1527876806842};\\\", \\\"{x:1317,y:692,t:1527876806860};\\\", \\\"{x:1321,y:691,t:1527876806876};\\\", \\\"{x:1322,y:691,t:1527876806991};\\\", \\\"{x:1323,y:691,t:1527876807175};\\\", \\\"{x:1327,y:691,t:1527876807194};\\\", \\\"{x:1330,y:691,t:1527876807209};\\\", \\\"{x:1334,y:691,t:1527876807226};\\\", \\\"{x:1338,y:691,t:1527876807244};\\\", \\\"{x:1344,y:690,t:1527876807260};\\\", \\\"{x:1347,y:690,t:1527876807277};\\\", \\\"{x:1350,y:689,t:1527876807294};\\\", \\\"{x:1351,y:689,t:1527876807310};\\\", \\\"{x:1340,y:689,t:1527876808132};\\\", \\\"{x:1310,y:689,t:1527876808148};\\\", \\\"{x:1279,y:691,t:1527876808165};\\\", \\\"{x:1247,y:694,t:1527876808182};\\\", \\\"{x:1218,y:695,t:1527876808198};\\\", \\\"{x:1196,y:695,t:1527876808215};\\\", \\\"{x:1181,y:693,t:1527876808231};\\\", \\\"{x:1170,y:690,t:1527876808247};\\\", \\\"{x:1161,y:687,t:1527876808265};\\\", \\\"{x:1150,y:685,t:1527876808281};\\\", \\\"{x:1133,y:681,t:1527876808299};\\\", \\\"{x:1103,y:673,t:1527876808315};\\\", \\\"{x:1080,y:671,t:1527876808331};\\\", \\\"{x:1052,y:665,t:1527876808348};\\\", \\\"{x:1023,y:662,t:1527876808365};\\\", \\\"{x:995,y:660,t:1527876808383};\\\", \\\"{x:958,y:656,t:1527876808399};\\\", \\\"{x:923,y:653,t:1527876808414};\\\", \\\"{x:897,y:651,t:1527876808432};\\\", \\\"{x:877,y:649,t:1527876808449};\\\", \\\"{x:862,y:645,t:1527876808464};\\\", \\\"{x:852,y:644,t:1527876808482};\\\", \\\"{x:839,y:643,t:1527876808499};\\\", \\\"{x:831,y:640,t:1527876808515};\\\", \\\"{x:822,y:639,t:1527876808532};\\\", \\\"{x:814,y:638,t:1527876808549};\\\", \\\"{x:806,y:637,t:1527876808565};\\\", \\\"{x:798,y:635,t:1527876808582};\\\", \\\"{x:787,y:631,t:1527876808600};\\\", \\\"{x:777,y:625,t:1527876808614};\\\", \\\"{x:765,y:619,t:1527876808631};\\\", \\\"{x:752,y:611,t:1527876808649};\\\", \\\"{x:738,y:600,t:1527876808664};\\\", \\\"{x:723,y:591,t:1527876808681};\\\", \\\"{x:699,y:582,t:1527876808698};\\\", \\\"{x:676,y:575,t:1527876808714};\\\", \\\"{x:651,y:568,t:1527876808731};\\\", \\\"{x:631,y:562,t:1527876808748};\\\", \\\"{x:617,y:558,t:1527876808766};\\\", \\\"{x:609,y:554,t:1527876808781};\\\", \\\"{x:603,y:551,t:1527876808799};\\\", \\\"{x:598,y:549,t:1527876808815};\\\", \\\"{x:595,y:548,t:1527876808831};\\\", \\\"{x:593,y:548,t:1527876808970};\\\", \\\"{x:590,y:548,t:1527876808981};\\\", \\\"{x:583,y:551,t:1527876808998};\\\", \\\"{x:573,y:555,t:1527876809014};\\\", \\\"{x:561,y:557,t:1527876809032};\\\", \\\"{x:549,y:560,t:1527876809049};\\\", \\\"{x:535,y:560,t:1527876809064};\\\", \\\"{x:525,y:561,t:1527876809082};\\\", \\\"{x:517,y:563,t:1527876809099};\\\", \\\"{x:511,y:565,t:1527876809116};\\\", \\\"{x:502,y:566,t:1527876809132};\\\", \\\"{x:493,y:567,t:1527876809149};\\\", \\\"{x:485,y:568,t:1527876809165};\\\", \\\"{x:477,y:569,t:1527876809181};\\\", \\\"{x:469,y:570,t:1527876809198};\\\", \\\"{x:462,y:572,t:1527876809215};\\\", \\\"{x:453,y:573,t:1527876809232};\\\", \\\"{x:446,y:573,t:1527876809248};\\\", \\\"{x:443,y:573,t:1527876809266};\\\", \\\"{x:439,y:573,t:1527876809283};\\\", \\\"{x:437,y:573,t:1527876809298};\\\", \\\"{x:430,y:573,t:1527876809316};\\\", \\\"{x:423,y:572,t:1527876809332};\\\", \\\"{x:415,y:571,t:1527876809349};\\\", \\\"{x:402,y:571,t:1527876809365};\\\", \\\"{x:385,y:571,t:1527876809382};\\\", \\\"{x:364,y:571,t:1527876809398};\\\", \\\"{x:341,y:571,t:1527876809415};\\\", \\\"{x:322,y:571,t:1527876809432};\\\", \\\"{x:304,y:571,t:1527876809448};\\\", \\\"{x:284,y:571,t:1527876809465};\\\", \\\"{x:255,y:571,t:1527876809482};\\\", \\\"{x:239,y:571,t:1527876809498};\\\", \\\"{x:226,y:571,t:1527876809516};\\\", \\\"{x:218,y:571,t:1527876809532};\\\", \\\"{x:213,y:571,t:1527876809548};\\\", \\\"{x:212,y:571,t:1527876809618};\\\", \\\"{x:211,y:571,t:1527876809633};\\\", \\\"{x:207,y:572,t:1527876809649};\\\", \\\"{x:203,y:577,t:1527876809665};\\\", \\\"{x:201,y:582,t:1527876809682};\\\", \\\"{x:200,y:583,t:1527876809699};\\\", \\\"{x:200,y:584,t:1527876809754};\\\", \\\"{x:198,y:584,t:1527876809770};\\\", \\\"{x:197,y:585,t:1527876809782};\\\", \\\"{x:194,y:587,t:1527876809799};\\\", \\\"{x:192,y:588,t:1527876809816};\\\", \\\"{x:191,y:588,t:1527876809832};\\\", \\\"{x:194,y:588,t:1527876809908};\\\", \\\"{x:203,y:586,t:1527876809917};\\\", \\\"{x:232,y:577,t:1527876809932};\\\", \\\"{x:308,y:560,t:1527876809950};\\\", \\\"{x:395,y:545,t:1527876809966};\\\", \\\"{x:487,y:541,t:1527876809982};\\\", \\\"{x:557,y:541,t:1527876810000};\\\", \\\"{x:602,y:541,t:1527876810017};\\\", \\\"{x:626,y:541,t:1527876810032};\\\", \\\"{x:636,y:541,t:1527876810050};\\\", \\\"{x:637,y:541,t:1527876810066};\\\", \\\"{x:638,y:541,t:1527876810130};\\\", \\\"{x:642,y:539,t:1527876810139};\\\", \\\"{x:649,y:538,t:1527876810149};\\\", \\\"{x:670,y:531,t:1527876810166};\\\", \\\"{x:691,y:527,t:1527876810182};\\\", \\\"{x:713,y:527,t:1527876810199};\\\", \\\"{x:731,y:527,t:1527876810218};\\\", \\\"{x:745,y:527,t:1527876810232};\\\", \\\"{x:755,y:527,t:1527876810249};\\\", \\\"{x:774,y:528,t:1527876810266};\\\", \\\"{x:789,y:528,t:1527876810282};\\\", \\\"{x:803,y:528,t:1527876810299};\\\", \\\"{x:813,y:531,t:1527876810317};\\\", \\\"{x:823,y:532,t:1527876810333};\\\", \\\"{x:826,y:533,t:1527876810350};\\\", \\\"{x:829,y:533,t:1527876810411};\\\", \\\"{x:832,y:535,t:1527876810419};\\\", \\\"{x:834,y:537,t:1527876810433};\\\", \\\"{x:837,y:540,t:1527876810450};\\\", \\\"{x:838,y:541,t:1527876810730};\\\", \\\"{x:837,y:545,t:1527876810738};\\\", \\\"{x:828,y:553,t:1527876810749};\\\", \\\"{x:802,y:573,t:1527876810767};\\\", \\\"{x:758,y:603,t:1527876810784};\\\", \\\"{x:714,y:630,t:1527876810801};\\\", \\\"{x:677,y:655,t:1527876810817};\\\", \\\"{x:656,y:667,t:1527876810833};\\\", \\\"{x:641,y:677,t:1527876810849};\\\", \\\"{x:617,y:691,t:1527876810866};\\\", \\\"{x:601,y:704,t:1527876810883};\\\", \\\"{x:590,y:711,t:1527876810900};\\\", \\\"{x:582,y:713,t:1527876810916};\\\", \\\"{x:575,y:716,t:1527876810933};\\\", \\\"{x:569,y:719,t:1527876810950};\\\", \\\"{x:567,y:721,t:1527876810967};\\\", \\\"{x:564,y:721,t:1527876811010};\\\", \\\"{x:563,y:723,t:1527876811019};\\\", \\\"{x:561,y:723,t:1527876811033};\\\", \\\"{x:559,y:725,t:1527876811050};\\\", \\\"{x:558,y:725,t:1527876811107};\\\", \\\"{x:557,y:726,t:1527876811118};\\\", \\\"{x:548,y:734,t:1527876811133};\\\", \\\"{x:541,y:741,t:1527876811150};\\\", \\\"{x:537,y:743,t:1527876811168};\\\" ] }, { \\\"rt\\\": 12344, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 17, \\\"time_elapsed\\\": 436192, \\\"internal_node_id\\\": \\\"0.0-6.0-7.0\\\", \\\"subject\\\": \\\"HW2SN\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"xray\\\", \\\"condition\\\": \\\"311\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"meets\\\", \\\"q\\\": 13, \\\"clicks\\\": 2, \\\"explicit\\\": 3, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XInside-YFull\\\", \\\"correct\\\": 1, \\\"orth_correct\\\": 0, \\\"answer\\\": [ \\\"E\\\", \\\"F\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-B -Z \\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:538,y:743,t:1527876813195};\\\", \\\"{x:547,y:743,t:1527876813202};\\\", \\\"{x:568,y:743,t:1527876813221};\\\", \\\"{x:593,y:748,t:1527876813236};\\\", \\\"{x:615,y:749,t:1527876813251};\\\", \\\"{x:633,y:751,t:1527876813268};\\\", \\\"{x:651,y:754,t:1527876813284};\\\", \\\"{x:661,y:754,t:1527876813301};\\\", \\\"{x:662,y:755,t:1527876813322};\\\", \\\"{x:663,y:755,t:1527876813338};\\\", \\\"{x:665,y:755,t:1527876814636};\\\", \\\"{x:672,y:754,t:1527876814652};\\\", \\\"{x:684,y:751,t:1527876814669};\\\", \\\"{x:701,y:749,t:1527876814685};\\\", \\\"{x:722,y:748,t:1527876814702};\\\", \\\"{x:745,y:748,t:1527876814719};\\\", \\\"{x:772,y:747,t:1527876814735};\\\", \\\"{x:799,y:747,t:1527876814752};\\\", \\\"{x:825,y:747,t:1527876814769};\\\", \\\"{x:846,y:747,t:1527876814785};\\\", \\\"{x:866,y:747,t:1527876814802};\\\", \\\"{x:890,y:747,t:1527876814819};\\\", \\\"{x:907,y:747,t:1527876814835};\\\", \\\"{x:922,y:747,t:1527876814852};\\\", \\\"{x:931,y:747,t:1527876814869};\\\", \\\"{x:945,y:747,t:1527876814885};\\\", \\\"{x:966,y:747,t:1527876814902};\\\", \\\"{x:990,y:747,t:1527876814919};\\\", \\\"{x:1017,y:747,t:1527876814935};\\\", \\\"{x:1046,y:747,t:1527876814952};\\\", \\\"{x:1070,y:746,t:1527876814969};\\\", \\\"{x:1099,y:746,t:1527876814986};\\\", \\\"{x:1126,y:746,t:1527876815002};\\\", \\\"{x:1160,y:746,t:1527876815019};\\\", \\\"{x:1185,y:746,t:1527876815035};\\\", \\\"{x:1208,y:746,t:1527876815053};\\\", \\\"{x:1230,y:746,t:1527876815069};\\\", \\\"{x:1251,y:746,t:1527876815085};\\\", \\\"{x:1267,y:746,t:1527876815102};\\\", \\\"{x:1282,y:746,t:1527876815119};\\\", \\\"{x:1299,y:746,t:1527876815135};\\\", \\\"{x:1314,y:746,t:1527876815152};\\\", \\\"{x:1327,y:746,t:1527876815170};\\\", \\\"{x:1340,y:746,t:1527876815185};\\\", \\\"{x:1349,y:744,t:1527876815202};\\\", \\\"{x:1354,y:743,t:1527876815220};\\\", \\\"{x:1354,y:742,t:1527876815235};\\\", \\\"{x:1356,y:742,t:1527876815572};\\\", \\\"{x:1356,y:741,t:1527876815585};\\\", \\\"{x:1357,y:740,t:1527876815602};\\\", \\\"{x:1357,y:737,t:1527876815619};\\\", \\\"{x:1358,y:736,t:1527876815659};\\\", \\\"{x:1358,y:735,t:1527876815692};\\\", \\\"{x:1358,y:734,t:1527876815715};\\\", \\\"{x:1359,y:734,t:1527876816972};\\\", \\\"{x:1362,y:733,t:1527876816986};\\\", \\\"{x:1367,y:730,t:1527876817002};\\\", \\\"{x:1383,y:729,t:1527876817019};\\\", \\\"{x:1395,y:729,t:1527876817037};\\\", \\\"{x:1409,y:728,t:1527876817052};\\\", \\\"{x:1422,y:728,t:1527876817070};\\\", \\\"{x:1435,y:728,t:1527876817086};\\\", \\\"{x:1448,y:726,t:1527876817102};\\\", \\\"{x:1456,y:726,t:1527876817119};\\\", \\\"{x:1464,y:726,t:1527876817137};\\\", \\\"{x:1471,y:726,t:1527876817152};\\\", \\\"{x:1478,y:726,t:1527876817169};\\\", \\\"{x:1482,y:726,t:1527876817187};\\\", \\\"{x:1486,y:726,t:1527876817202};\\\", \\\"{x:1495,y:726,t:1527876817219};\\\", \\\"{x:1502,y:726,t:1527876817236};\\\", \\\"{x:1510,y:726,t:1527876817252};\\\", \\\"{x:1520,y:726,t:1527876817269};\\\", \\\"{x:1526,y:726,t:1527876817286};\\\", \\\"{x:1531,y:725,t:1527876817302};\\\", \\\"{x:1538,y:724,t:1527876817319};\\\", \\\"{x:1550,y:720,t:1527876817336};\\\", \\\"{x:1560,y:718,t:1527876817353};\\\", \\\"{x:1569,y:715,t:1527876817369};\\\", \\\"{x:1575,y:713,t:1527876817386};\\\", \\\"{x:1580,y:711,t:1527876817401};\\\", \\\"{x:1585,y:711,t:1527876817418};\\\", \\\"{x:1588,y:711,t:1527876817436};\\\", \\\"{x:1591,y:711,t:1527876817452};\\\", \\\"{x:1594,y:709,t:1527876817468};\\\", \\\"{x:1596,y:708,t:1527876817486};\\\", \\\"{x:1597,y:707,t:1527876817501};\\\", \\\"{x:1598,y:707,t:1527876817519};\\\", \\\"{x:1599,y:707,t:1527876817535};\\\", \\\"{x:1600,y:706,t:1527876817551};\\\", \\\"{x:1600,y:705,t:1527876817579};\\\", \\\"{x:1600,y:704,t:1527876817587};\\\", \\\"{x:1601,y:704,t:1527876817601};\\\", \\\"{x:1602,y:702,t:1527876817619};\\\", \\\"{x:1602,y:700,t:1527876817636};\\\", \\\"{x:1603,y:699,t:1527876817651};\\\", \\\"{x:1604,y:696,t:1527876817669};\\\", \\\"{x:1605,y:694,t:1527876817686};\\\", \\\"{x:1605,y:693,t:1527876817706};\\\", \\\"{x:1606,y:691,t:1527876817722};\\\", \\\"{x:1607,y:689,t:1527876817739};\\\", \\\"{x:1608,y:688,t:1527876817752};\\\", \\\"{x:1608,y:687,t:1527876817769};\\\", \\\"{x:1609,y:686,t:1527876817786};\\\", \\\"{x:1610,y:685,t:1527876817802};\\\", \\\"{x:1611,y:684,t:1527876817827};\\\", \\\"{x:1610,y:684,t:1527876818595};\\\", \\\"{x:1609,y:688,t:1527876818604};\\\", \\\"{x:1605,y:692,t:1527876818620};\\\", \\\"{x:1598,y:701,t:1527876818636};\\\", \\\"{x:1592,y:706,t:1527876818653};\\\", \\\"{x:1587,y:710,t:1527876818669};\\\", \\\"{x:1584,y:713,t:1527876818686};\\\", \\\"{x:1581,y:717,t:1527876818703};\\\", \\\"{x:1577,y:725,t:1527876818719};\\\", \\\"{x:1571,y:733,t:1527876818736};\\\", \\\"{x:1567,y:738,t:1527876818752};\\\", \\\"{x:1565,y:742,t:1527876818769};\\\", \\\"{x:1564,y:744,t:1527876818786};\\\", \\\"{x:1561,y:748,t:1527876818803};\\\", \\\"{x:1560,y:753,t:1527876818820};\\\", \\\"{x:1560,y:754,t:1527876818836};\\\", \\\"{x:1559,y:758,t:1527876818853};\\\", \\\"{x:1558,y:762,t:1527876818869};\\\", \\\"{x:1557,y:767,t:1527876818887};\\\", \\\"{x:1555,y:773,t:1527876818903};\\\", \\\"{x:1552,y:779,t:1527876818919};\\\", \\\"{x:1550,y:783,t:1527876818936};\\\", \\\"{x:1548,y:787,t:1527876818952};\\\", \\\"{x:1547,y:790,t:1527876818969};\\\", \\\"{x:1546,y:794,t:1527876818987};\\\", \\\"{x:1545,y:797,t:1527876819002};\\\", \\\"{x:1542,y:805,t:1527876819019};\\\", \\\"{x:1537,y:814,t:1527876819037};\\\", \\\"{x:1532,y:825,t:1527876819053};\\\", \\\"{x:1529,y:835,t:1527876819069};\\\", \\\"{x:1527,y:842,t:1527876819086};\\\", \\\"{x:1525,y:846,t:1527876819103};\\\", \\\"{x:1525,y:849,t:1527876819119};\\\", \\\"{x:1524,y:851,t:1527876819147};\\\", \\\"{x:1524,y:853,t:1527876819163};\\\", \\\"{x:1523,y:855,t:1527876819171};\\\", \\\"{x:1523,y:856,t:1527876819186};\\\", \\\"{x:1521,y:860,t:1527876819203};\\\", \\\"{x:1521,y:863,t:1527876819219};\\\", \\\"{x:1520,y:867,t:1527876819236};\\\", \\\"{x:1516,y:877,t:1527876819253};\\\", \\\"{x:1513,y:887,t:1527876819269};\\\", \\\"{x:1511,y:896,t:1527876819286};\\\", \\\"{x:1508,y:903,t:1527876819303};\\\", \\\"{x:1506,y:907,t:1527876819319};\\\", \\\"{x:1506,y:908,t:1527876819337};\\\", \\\"{x:1506,y:909,t:1527876819353};\\\", \\\"{x:1506,y:910,t:1527876819500};\\\", \\\"{x:1505,y:911,t:1527876819507};\\\", \\\"{x:1505,y:912,t:1527876819520};\\\", \\\"{x:1505,y:913,t:1527876819536};\\\", \\\"{x:1504,y:916,t:1527876819553};\\\", \\\"{x:1504,y:918,t:1527876819569};\\\", \\\"{x:1502,y:923,t:1527876819587};\\\", \\\"{x:1500,y:925,t:1527876819603};\\\", \\\"{x:1498,y:930,t:1527876819619};\\\", \\\"{x:1497,y:932,t:1527876819636};\\\", \\\"{x:1494,y:936,t:1527876819653};\\\", \\\"{x:1493,y:938,t:1527876819669};\\\", \\\"{x:1491,y:941,t:1527876819687};\\\", \\\"{x:1490,y:943,t:1527876819703};\\\", \\\"{x:1489,y:944,t:1527876819720};\\\", \\\"{x:1487,y:948,t:1527876819736};\\\", \\\"{x:1487,y:950,t:1527876819754};\\\", \\\"{x:1486,y:950,t:1527876819769};\\\", \\\"{x:1485,y:952,t:1527876819786};\\\", \\\"{x:1485,y:953,t:1527876819803};\\\", \\\"{x:1485,y:954,t:1527876819916};\\\", \\\"{x:1485,y:955,t:1527876819923};\\\", \\\"{x:1484,y:956,t:1527876819936};\\\", \\\"{x:1483,y:958,t:1527876819953};\\\", \\\"{x:1482,y:960,t:1527876819969};\\\", \\\"{x:1481,y:960,t:1527876819987};\\\", \\\"{x:1480,y:961,t:1527876820003};\\\", \\\"{x:1478,y:961,t:1527876820772};\\\", \\\"{x:1471,y:957,t:1527876820787};\\\", \\\"{x:1445,y:927,t:1527876820803};\\\", \\\"{x:1422,y:906,t:1527876820820};\\\", \\\"{x:1397,y:886,t:1527876820836};\\\", \\\"{x:1368,y:867,t:1527876820853};\\\", \\\"{x:1316,y:828,t:1527876820869};\\\", \\\"{x:1269,y:795,t:1527876820886};\\\", \\\"{x:1240,y:780,t:1527876820903};\\\", \\\"{x:1216,y:771,t:1527876820919};\\\", \\\"{x:1191,y:764,t:1527876820936};\\\", \\\"{x:1162,y:755,t:1527876820953};\\\", \\\"{x:1135,y:746,t:1527876820969};\\\", \\\"{x:1114,y:739,t:1527876820986};\\\", \\\"{x:1073,y:723,t:1527876821002};\\\", \\\"{x:1046,y:714,t:1527876821019};\\\", \\\"{x:1011,y:704,t:1527876821036};\\\", \\\"{x:970,y:694,t:1527876821053};\\\", \\\"{x:904,y:677,t:1527876821068};\\\", \\\"{x:818,y:652,t:1527876821085};\\\", \\\"{x:764,y:642,t:1527876821103};\\\", \\\"{x:753,y:638,t:1527876821118};\\\", \\\"{x:752,y:638,t:1527876821138};\\\", \\\"{x:752,y:637,t:1527876821363};\\\", \\\"{x:752,y:635,t:1527876821379};\\\", \\\"{x:752,y:632,t:1527876821387};\\\", \\\"{x:751,y:621,t:1527876821404};\\\", \\\"{x:740,y:605,t:1527876821419};\\\", \\\"{x:724,y:586,t:1527876821436};\\\", \\\"{x:710,y:569,t:1527876821453};\\\", \\\"{x:691,y:551,t:1527876821475};\\\", \\\"{x:676,y:539,t:1527876821492};\\\", \\\"{x:664,y:532,t:1527876821509};\\\", \\\"{x:656,y:527,t:1527876821524};\\\", \\\"{x:653,y:524,t:1527876821542};\\\", \\\"{x:647,y:520,t:1527876821558};\\\", \\\"{x:645,y:518,t:1527876821575};\\\", \\\"{x:642,y:516,t:1527876821592};\\\", \\\"{x:637,y:513,t:1527876821609};\\\", \\\"{x:632,y:509,t:1527876821624};\\\", \\\"{x:626,y:504,t:1527876821641};\\\", \\\"{x:625,y:503,t:1527876821674};\\\", \\\"{x:625,y:502,t:1527876821682};\\\", \\\"{x:623,y:502,t:1527876821698};\\\", \\\"{x:623,y:501,t:1527876821708};\\\", \\\"{x:621,y:500,t:1527876821725};\\\", \\\"{x:618,y:499,t:1527876821742};\\\", \\\"{x:613,y:497,t:1527876821758};\\\", \\\"{x:610,y:495,t:1527876821775};\\\", \\\"{x:608,y:495,t:1527876821792};\\\", \\\"{x:608,y:494,t:1527876821866};\\\", \\\"{x:608,y:494,t:1527876821919};\\\", \\\"{x:614,y:494,t:1527876821978};\\\", \\\"{x:625,y:494,t:1527876821991};\\\", \\\"{x:641,y:494,t:1527876822009};\\\", \\\"{x:652,y:494,t:1527876822026};\\\", \\\"{x:657,y:494,t:1527876822041};\\\", \\\"{x:660,y:494,t:1527876822059};\\\", \\\"{x:663,y:494,t:1527876822075};\\\", \\\"{x:665,y:494,t:1527876822093};\\\", \\\"{x:671,y:494,t:1527876822109};\\\", \\\"{x:679,y:494,t:1527876822126};\\\", \\\"{x:694,y:494,t:1527876822142};\\\", \\\"{x:712,y:494,t:1527876822159};\\\", \\\"{x:727,y:494,t:1527876822177};\\\", \\\"{x:741,y:494,t:1527876822193};\\\", \\\"{x:749,y:494,t:1527876822209};\\\", \\\"{x:763,y:494,t:1527876822226};\\\", \\\"{x:770,y:494,t:1527876822242};\\\", \\\"{x:773,y:494,t:1527876822258};\\\", \\\"{x:774,y:494,t:1527876822276};\\\", \\\"{x:776,y:494,t:1527876822291};\\\", \\\"{x:779,y:494,t:1527876822308};\\\", \\\"{x:783,y:496,t:1527876822325};\\\", \\\"{x:785,y:497,t:1527876822343};\\\", \\\"{x:788,y:497,t:1527876822359};\\\", \\\"{x:790,y:497,t:1527876822376};\\\", \\\"{x:796,y:497,t:1527876822393};\\\", \\\"{x:802,y:497,t:1527876822408};\\\", \\\"{x:806,y:497,t:1527876822425};\\\", \\\"{x:808,y:498,t:1527876822442};\\\", \\\"{x:810,y:498,t:1527876822459};\\\", \\\"{x:814,y:500,t:1527876822476};\\\", \\\"{x:816,y:500,t:1527876822493};\\\", \\\"{x:818,y:500,t:1527876822508};\\\", \\\"{x:818,y:501,t:1527876822525};\\\", \\\"{x:819,y:501,t:1527876822543};\\\", \\\"{x:822,y:502,t:1527876822559};\\\", \\\"{x:823,y:503,t:1527876822576};\\\", \\\"{x:825,y:503,t:1527876822592};\\\", \\\"{x:825,y:504,t:1527876822610};\\\", \\\"{x:826,y:504,t:1527876822643};\\\", \\\"{x:828,y:504,t:1527876822660};\\\", \\\"{x:828,y:504,t:1527876822714};\\\", \\\"{x:828,y:513,t:1527876822819};\\\", \\\"{x:821,y:527,t:1527876822827};\\\", \\\"{x:796,y:557,t:1527876822843};\\\", \\\"{x:759,y:594,t:1527876822859};\\\", \\\"{x:706,y:637,t:1527876822877};\\\", \\\"{x:659,y:668,t:1527876822892};\\\", \\\"{x:637,y:692,t:1527876822910};\\\", \\\"{x:613,y:709,t:1527876822927};\\\", \\\"{x:596,y:721,t:1527876822943};\\\", \\\"{x:584,y:730,t:1527876822960};\\\", \\\"{x:575,y:736,t:1527876822977};\\\", \\\"{x:574,y:738,t:1527876822993};\\\", \\\"{x:573,y:738,t:1527876823010};\\\", \\\"{x:571,y:740,t:1527876823027};\\\", \\\"{x:569,y:742,t:1527876823044};\\\", \\\"{x:565,y:745,t:1527876823060};\\\", \\\"{x:560,y:748,t:1527876823077};\\\", \\\"{x:557,y:748,t:1527876823094};\\\", \\\"{x:556,y:748,t:1527876823110};\\\", \\\"{x:555,y:748,t:1527876823138};\\\", \\\"{x:554,y:748,t:1527876823146};\\\", \\\"{x:552,y:748,t:1527876823163};\\\", \\\"{x:550,y:747,t:1527876823176};\\\", \\\"{x:545,y:743,t:1527876823193};\\\", \\\"{x:541,y:740,t:1527876823211};\\\", \\\"{x:540,y:737,t:1527876823427};\\\", \\\"{x:563,y:702,t:1527876823444};\\\", \\\"{x:612,y:644,t:1527876823461};\\\", \\\"{x:682,y:574,t:1527876823478};\\\", \\\"{x:762,y:508,t:1527876823495};\\\", \\\"{x:835,y:450,t:1527876823510};\\\", \\\"{x:900,y:416,t:1527876823527};\\\", \\\"{x:935,y:406,t:1527876823543};\\\", \\\"{x:949,y:403,t:1527876823559};\\\", \\\"{x:950,y:403,t:1527876823577};\\\", \\\"{x:951,y:403,t:1527876823650};\\\", \\\"{x:951,y:408,t:1527876823660};\\\", \\\"{x:945,y:429,t:1527876823677};\\\", \\\"{x:932,y:452,t:1527876823693};\\\", \\\"{x:916,y:465,t:1527876823710};\\\", \\\"{x:900,y:473,t:1527876823727};\\\", \\\"{x:885,y:477,t:1527876823744};\\\", \\\"{x:871,y:480,t:1527876823761};\\\", \\\"{x:856,y:485,t:1527876823777};\\\", \\\"{x:839,y:495,t:1527876823794};\\\", \\\"{x:830,y:500,t:1527876823810};\\\", \\\"{x:827,y:502,t:1527876823827};\\\", \\\"{x:826,y:502,t:1527876823844};\\\", \\\"{x:822,y:505,t:1527876824235};\\\", \\\"{x:817,y:514,t:1527876824244};\\\", \\\"{x:799,y:544,t:1527876824261};\\\", \\\"{x:777,y:575,t:1527876824277};\\\", \\\"{x:755,y:603,t:1527876824294};\\\", \\\"{x:735,y:629,t:1527876824310};\\\", \\\"{x:706,y:652,t:1527876824328};\\\", \\\"{x:680,y:671,t:1527876824344};\\\", \\\"{x:657,y:685,t:1527876824361};\\\", \\\"{x:634,y:696,t:1527876824377};\\\", \\\"{x:604,y:707,t:1527876824394};\\\", \\\"{x:582,y:713,t:1527876824410};\\\", \\\"{x:561,y:720,t:1527876824428};\\\", \\\"{x:541,y:726,t:1527876824444};\\\", \\\"{x:531,y:731,t:1527876824461};\\\", \\\"{x:523,y:735,t:1527876824478};\\\", \\\"{x:519,y:738,t:1527876824493};\\\", \\\"{x:514,y:742,t:1527876824511};\\\", \\\"{x:511,y:747,t:1527876824528};\\\", \\\"{x:510,y:748,t:1527876824546};\\\", \\\"{x:510,y:749,t:1527876824561};\\\", \\\"{x:507,y:755,t:1527876824579};\\\", \\\"{x:507,y:756,t:1527876824594};\\\", \\\"{x:507,y:754,t:1527876824692};\\\", \\\"{x:507,y:752,t:1527876824711};\\\", \\\"{x:507,y:750,t:1527876824728};\\\", \\\"{x:507,y:747,t:1527876824745};\\\" ] }, { \\\"rt\\\": 5537, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 18, \\\"time_elapsed\\\": 443054, \\\"internal_node_id\\\": \\\"0.0-6.0-8.0\\\", \\\"subject\\\": \\\"HW2SN\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"xray\\\", \\\"condition\\\": \\\"311\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"endtime\\\", \\\"q\\\": 14, \\\"clicks\\\": 1.5, \\\"explicit\\\": 3, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XInside-YFull\\\", \\\"correct\\\": 1, \\\"orth_correct\\\": 0, \\\"answer\\\": [ \\\"X\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"\\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:513,y:746,t:1527876826995};\\\", \\\"{x:529,y:750,t:1527876827003};\\\", \\\"{x:557,y:751,t:1527876827014};\\\", \\\"{x:632,y:758,t:1527876827031};\\\", \\\"{x:647,y:758,t:1527876827047};\\\", \\\"{x:648,y:758,t:1527876827322};\\\", \\\"{x:652,y:758,t:1527876827338};\\\", \\\"{x:659,y:758,t:1527876827346};\\\", \\\"{x:673,y:758,t:1527876827363};\\\", \\\"{x:688,y:758,t:1527876827380};\\\", \\\"{x:700,y:758,t:1527876827396};\\\", \\\"{x:711,y:758,t:1527876827413};\\\", \\\"{x:727,y:757,t:1527876827430};\\\", \\\"{x:749,y:757,t:1527876827446};\\\", \\\"{x:772,y:757,t:1527876827463};\\\", \\\"{x:796,y:757,t:1527876827480};\\\", \\\"{x:822,y:757,t:1527876827496};\\\", \\\"{x:861,y:764,t:1527876827513};\\\", \\\"{x:924,y:773,t:1527876827531};\\\", \\\"{x:951,y:778,t:1527876827547};\\\", \\\"{x:982,y:783,t:1527876827564};\\\", \\\"{x:1019,y:788,t:1527876827580};\\\", \\\"{x:1049,y:788,t:1527876827597};\\\", \\\"{x:1082,y:795,t:1527876827614};\\\", \\\"{x:1118,y:798,t:1527876827631};\\\", \\\"{x:1160,y:804,t:1527876827648};\\\", \\\"{x:1208,y:818,t:1527876827664};\\\", \\\"{x:1256,y:825,t:1527876827681};\\\", \\\"{x:1303,y:839,t:1527876827697};\\\", \\\"{x:1350,y:850,t:1527876827714};\\\", \\\"{x:1416,y:868,t:1527876827731};\\\", \\\"{x:1439,y:874,t:1527876827747};\\\", \\\"{x:1456,y:880,t:1527876827764};\\\", \\\"{x:1470,y:885,t:1527876827781};\\\", \\\"{x:1481,y:891,t:1527876827798};\\\", \\\"{x:1491,y:898,t:1527876827814};\\\", \\\"{x:1499,y:903,t:1527876827831};\\\", \\\"{x:1502,y:906,t:1527876827847};\\\", \\\"{x:1507,y:911,t:1527876827864};\\\", \\\"{x:1514,y:917,t:1527876827881};\\\", \\\"{x:1524,y:923,t:1527876827898};\\\", \\\"{x:1530,y:927,t:1527876827914};\\\", \\\"{x:1535,y:931,t:1527876827931};\\\", \\\"{x:1537,y:932,t:1527876827955};\\\", \\\"{x:1538,y:933,t:1527876827987};\\\", \\\"{x:1538,y:934,t:1527876827998};\\\", \\\"{x:1539,y:936,t:1527876828018};\\\", \\\"{x:1539,y:937,t:1527876828035};\\\", \\\"{x:1541,y:939,t:1527876828048};\\\", \\\"{x:1543,y:944,t:1527876828064};\\\", \\\"{x:1546,y:947,t:1527876828080};\\\", \\\"{x:1548,y:949,t:1527876828097};\\\", \\\"{x:1548,y:950,t:1527876828131};\\\", \\\"{x:1548,y:951,t:1527876828171};\\\", \\\"{x:1548,y:953,t:1527876828220};\\\", \\\"{x:1546,y:953,t:1527876828394};\\\", \\\"{x:1542,y:949,t:1527876828402};\\\", \\\"{x:1538,y:943,t:1527876828414};\\\", \\\"{x:1528,y:929,t:1527876828430};\\\", \\\"{x:1518,y:914,t:1527876828447};\\\", \\\"{x:1502,y:896,t:1527876828464};\\\", \\\"{x:1485,y:877,t:1527876828481};\\\", \\\"{x:1477,y:865,t:1527876828497};\\\", \\\"{x:1461,y:846,t:1527876828514};\\\", \\\"{x:1454,y:835,t:1527876828530};\\\", \\\"{x:1451,y:827,t:1527876828547};\\\", \\\"{x:1449,y:822,t:1527876828565};\\\", \\\"{x:1449,y:819,t:1527876828581};\\\", \\\"{x:1448,y:818,t:1527876828597};\\\", \\\"{x:1448,y:816,t:1527876828867};\\\", \\\"{x:1448,y:815,t:1527876828882};\\\", \\\"{x:1448,y:814,t:1527876828898};\\\", \\\"{x:1448,y:813,t:1527876829067};\\\", \\\"{x:1438,y:809,t:1527876829081};\\\", \\\"{x:1343,y:790,t:1527876829098};\\\", \\\"{x:1242,y:772,t:1527876829115};\\\", \\\"{x:1139,y:750,t:1527876829132};\\\", \\\"{x:1017,y:714,t:1527876829149};\\\", \\\"{x:914,y:684,t:1527876829164};\\\", \\\"{x:818,y:660,t:1527876829181};\\\", \\\"{x:755,y:645,t:1527876829198};\\\", \\\"{x:713,y:636,t:1527876829214};\\\", \\\"{x:695,y:631,t:1527876829233};\\\", \\\"{x:691,y:630,t:1527876829248};\\\", \\\"{x:690,y:630,t:1527876829274};\\\", \\\"{x:689,y:630,t:1527876829281};\\\", \\\"{x:689,y:629,t:1527876829353};\\\", \\\"{x:689,y:628,t:1527876829370};\\\", \\\"{x:687,y:627,t:1527876829381};\\\", \\\"{x:684,y:627,t:1527876829398};\\\", \\\"{x:677,y:625,t:1527876829415};\\\", \\\"{x:664,y:624,t:1527876829431};\\\", \\\"{x:646,y:622,t:1527876829448};\\\", \\\"{x:623,y:619,t:1527876829466};\\\", \\\"{x:602,y:618,t:1527876829481};\\\", \\\"{x:569,y:617,t:1527876829499};\\\", \\\"{x:551,y:614,t:1527876829515};\\\", \\\"{x:537,y:614,t:1527876829531};\\\", \\\"{x:526,y:612,t:1527876829548};\\\", \\\"{x:518,y:609,t:1527876829565};\\\", \\\"{x:515,y:608,t:1527876829581};\\\", \\\"{x:514,y:607,t:1527876829598};\\\", \\\"{x:510,y:606,t:1527876829615};\\\", \\\"{x:503,y:602,t:1527876829631};\\\", \\\"{x:494,y:601,t:1527876829650};\\\", \\\"{x:481,y:598,t:1527876829665};\\\", \\\"{x:460,y:590,t:1527876829682};\\\", \\\"{x:447,y:587,t:1527876829698};\\\", \\\"{x:436,y:580,t:1527876829715};\\\", \\\"{x:429,y:576,t:1527876829732};\\\", \\\"{x:419,y:569,t:1527876829748};\\\", \\\"{x:415,y:566,t:1527876829765};\\\", \\\"{x:414,y:565,t:1527876829786};\\\", \\\"{x:414,y:564,t:1527876829818};\\\", \\\"{x:416,y:563,t:1527876829832};\\\", \\\"{x:425,y:560,t:1527876829849};\\\", \\\"{x:441,y:559,t:1527876829865};\\\", \\\"{x:479,y:554,t:1527876829882};\\\", \\\"{x:505,y:554,t:1527876829899};\\\", \\\"{x:533,y:554,t:1527876829915};\\\", \\\"{x:559,y:554,t:1527876829932};\\\", \\\"{x:574,y:554,t:1527876829948};\\\", \\\"{x:585,y:554,t:1527876829965};\\\", \\\"{x:588,y:554,t:1527876829982};\\\", \\\"{x:590,y:554,t:1527876830091};\\\", \\\"{x:591,y:555,t:1527876830099};\\\", \\\"{x:592,y:555,t:1527876830115};\\\", \\\"{x:594,y:555,t:1527876830132};\\\", \\\"{x:594,y:558,t:1527876830218};\\\", \\\"{x:594,y:561,t:1527876830232};\\\", \\\"{x:595,y:563,t:1527876830249};\\\", \\\"{x:596,y:565,t:1527876830265};\\\", \\\"{x:597,y:566,t:1527876830282};\\\", \\\"{x:598,y:568,t:1527876830298};\\\", \\\"{x:598,y:571,t:1527876830570};\\\", \\\"{x:596,y:582,t:1527876830583};\\\", \\\"{x:589,y:614,t:1527876830601};\\\", \\\"{x:582,y:642,t:1527876830617};\\\", \\\"{x:574,y:661,t:1527876830632};\\\", \\\"{x:568,y:670,t:1527876830649};\\\", \\\"{x:565,y:675,t:1527876830665};\\\", \\\"{x:557,y:682,t:1527876830682};\\\", \\\"{x:553,y:684,t:1527876830698};\\\", \\\"{x:550,y:686,t:1527876830714};\\\", \\\"{x:547,y:689,t:1527876830732};\\\", \\\"{x:541,y:694,t:1527876830749};\\\", \\\"{x:535,y:698,t:1527876830765};\\\", \\\"{x:531,y:703,t:1527876830782};\\\", \\\"{x:529,y:705,t:1527876830799};\\\", \\\"{x:528,y:705,t:1527876830866};\\\", \\\"{x:529,y:695,t:1527876830883};\\\", \\\"{x:538,y:677,t:1527876830899};\\\", \\\"{x:547,y:664,t:1527876830916};\\\", \\\"{x:558,y:649,t:1527876830932};\\\", \\\"{x:571,y:632,t:1527876830948};\\\", \\\"{x:584,y:618,t:1527876830966};\\\", \\\"{x:594,y:608,t:1527876830982};\\\", \\\"{x:603,y:600,t:1527876831000};\\\", \\\"{x:606,y:595,t:1527876831016};\\\", \\\"{x:610,y:589,t:1527876831033};\\\", \\\"{x:612,y:587,t:1527876831049};\\\", \\\"{x:613,y:586,t:1527876831066};\\\", \\\"{x:614,y:585,t:1527876831122};\\\", \\\"{x:615,y:584,t:1527876831132};\\\", \\\"{x:614,y:584,t:1527876831386};\\\", \\\"{x:605,y:597,t:1527876831400};\\\", \\\"{x:577,y:646,t:1527876831416};\\\", \\\"{x:553,y:676,t:1527876831433};\\\", \\\"{x:524,y:691,t:1527876831450};\\\", \\\"{x:515,y:696,t:1527876831466};\\\", \\\"{x:511,y:699,t:1527876831483};\\\", \\\"{x:509,y:705,t:1527876831500};\\\", \\\"{x:509,y:712,t:1527876831516};\\\", \\\"{x:507,y:720,t:1527876831534};\\\", \\\"{x:507,y:726,t:1527876831550};\\\", \\\"{x:506,y:731,t:1527876831566};\\\", \\\"{x:505,y:735,t:1527876831584};\\\", \\\"{x:505,y:739,t:1527876831600};\\\", \\\"{x:504,y:742,t:1527876831616};\\\", \\\"{x:504,y:743,t:1527876831633};\\\", \\\"{x:504,y:744,t:1527876831650};\\\", \\\"{x:505,y:745,t:1527876831666};\\\", \\\"{x:506,y:745,t:1527876831762};\\\", \\\"{x:506,y:745,t:1527876831808};\\\", \\\"{x:505,y:744,t:1527876832723};\\\", \\\"{x:505,y:743,t:1527876832738};\\\", \\\"{x:505,y:742,t:1527876832762};\\\" ] }, { \\\"rt\\\": 23428, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 19, \\\"time_elapsed\\\": 467719, \\\"internal_node_id\\\": \\\"0.0-6.0-9.0\\\", \\\"subject\\\": \\\"HW2SN\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"xray\\\", \\\"condition\\\": \\\"311\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"midpoint\\\", \\\"q\\\": 15, \\\"clicks\\\": 2, \\\"explicit\\\": 3, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XInside-YFull\\\", \\\"correct\\\": 1, \\\"orth_correct\\\": 0, \\\"answer\\\": [ \\\"K\\\", \\\"X\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-J -J -B -M -M -M -M -X -X \\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:505,y:741,t:1527876834051};\\\", \\\"{x:527,y:738,t:1527876834067};\\\", \\\"{x:560,y:736,t:1527876834085};\\\", \\\"{x:613,y:736,t:1527876834102};\\\", \\\"{x:677,y:736,t:1527876834117};\\\", \\\"{x:739,y:736,t:1527876834134};\\\", \\\"{x:783,y:736,t:1527876834151};\\\", \\\"{x:812,y:736,t:1527876834168};\\\", \\\"{x:824,y:736,t:1527876834184};\\\", \\\"{x:825,y:736,t:1527876834201};\\\", \\\"{x:826,y:736,t:1527876834234};\\\", \\\"{x:826,y:735,t:1527876834770};\\\", \\\"{x:824,y:734,t:1527876834786};\\\", \\\"{x:823,y:733,t:1527876834802};\\\", \\\"{x:822,y:733,t:1527876834818};\\\", \\\"{x:819,y:727,t:1527876835066};\\\", \\\"{x:819,y:721,t:1527876835075};\\\", \\\"{x:819,y:717,t:1527876835086};\\\", \\\"{x:819,y:714,t:1527876835102};\\\", \\\"{x:819,y:713,t:1527876835119};\\\", \\\"{x:819,y:712,t:1527876836097};\\\", \\\"{x:823,y:712,t:1527876836105};\\\", \\\"{x:823,y:714,t:1527876836118};\\\", \\\"{x:825,y:715,t:1527876836395};\\\", \\\"{x:827,y:715,t:1527876836402};\\\", \\\"{x:837,y:714,t:1527876836418};\\\", \\\"{x:847,y:712,t:1527876836435};\\\", \\\"{x:863,y:712,t:1527876836452};\\\", \\\"{x:878,y:712,t:1527876836468};\\\", \\\"{x:886,y:712,t:1527876836485};\\\", \\\"{x:896,y:713,t:1527876836502};\\\", \\\"{x:909,y:716,t:1527876836519};\\\", \\\"{x:929,y:723,t:1527876836535};\\\", \\\"{x:958,y:733,t:1527876836553};\\\", \\\"{x:996,y:743,t:1527876836569};\\\", \\\"{x:1033,y:754,t:1527876836586};\\\", \\\"{x:1092,y:773,t:1527876836603};\\\", \\\"{x:1133,y:783,t:1527876836618};\\\", \\\"{x:1173,y:795,t:1527876836635};\\\", \\\"{x:1210,y:808,t:1527876836652};\\\", \\\"{x:1241,y:817,t:1527876836669};\\\", \\\"{x:1267,y:827,t:1527876836686};\\\", \\\"{x:1287,y:836,t:1527876836703};\\\", \\\"{x:1307,y:844,t:1527876836718};\\\", \\\"{x:1325,y:853,t:1527876836736};\\\", \\\"{x:1340,y:858,t:1527876836753};\\\", \\\"{x:1356,y:864,t:1527876836770};\\\", \\\"{x:1364,y:869,t:1527876836786};\\\", \\\"{x:1378,y:875,t:1527876836802};\\\", \\\"{x:1386,y:878,t:1527876836819};\\\", \\\"{x:1393,y:881,t:1527876836836};\\\", \\\"{x:1399,y:884,t:1527876836852};\\\", \\\"{x:1404,y:886,t:1527876836869};\\\", \\\"{x:1409,y:890,t:1527876836886};\\\", \\\"{x:1416,y:892,t:1527876836903};\\\", \\\"{x:1420,y:894,t:1527876836919};\\\", \\\"{x:1424,y:896,t:1527876836936};\\\", \\\"{x:1426,y:896,t:1527876836953};\\\", \\\"{x:1427,y:897,t:1527876836970};\\\", \\\"{x:1427,y:898,t:1527876836994};\\\", \\\"{x:1428,y:900,t:1527876837019};\\\", \\\"{x:1429,y:903,t:1527876837036};\\\", \\\"{x:1431,y:905,t:1527876837053};\\\", \\\"{x:1433,y:909,t:1527876837070};\\\", \\\"{x:1437,y:912,t:1527876837086};\\\", \\\"{x:1438,y:913,t:1527876837103};\\\", \\\"{x:1440,y:915,t:1527876837120};\\\", \\\"{x:1441,y:917,t:1527876837136};\\\", \\\"{x:1441,y:918,t:1527876837153};\\\", \\\"{x:1442,y:919,t:1527876837170};\\\", \\\"{x:1444,y:921,t:1527876837186};\\\", \\\"{x:1446,y:924,t:1527876837202};\\\", \\\"{x:1448,y:928,t:1527876837220};\\\", \\\"{x:1451,y:934,t:1527876837236};\\\", \\\"{x:1455,y:939,t:1527876837253};\\\", \\\"{x:1458,y:943,t:1527876837270};\\\", \\\"{x:1459,y:944,t:1527876837286};\\\", \\\"{x:1460,y:946,t:1527876837303};\\\", \\\"{x:1461,y:946,t:1527876837320};\\\", \\\"{x:1461,y:948,t:1527876837339};\\\", \\\"{x:1461,y:949,t:1527876837362};\\\", \\\"{x:1461,y:950,t:1527876837370};\\\", \\\"{x:1461,y:951,t:1527876837394};\\\", \\\"{x:1462,y:953,t:1527876837411};\\\", \\\"{x:1462,y:955,t:1527876837420};\\\", \\\"{x:1463,y:957,t:1527876837436};\\\", \\\"{x:1465,y:958,t:1527876837453};\\\", \\\"{x:1466,y:959,t:1527876837469};\\\", \\\"{x:1467,y:960,t:1527876837490};\\\", \\\"{x:1468,y:960,t:1527876837502};\\\", \\\"{x:1470,y:960,t:1527876837519};\\\", \\\"{x:1472,y:961,t:1527876837535};\\\", \\\"{x:1475,y:962,t:1527876837552};\\\", \\\"{x:1477,y:962,t:1527876837569};\\\", \\\"{x:1478,y:962,t:1527876837586};\\\", \\\"{x:1479,y:962,t:1527876837603};\\\", \\\"{x:1480,y:962,t:1527876837620};\\\", \\\"{x:1481,y:962,t:1527876841731};\\\", \\\"{x:1480,y:958,t:1527876841739};\\\", \\\"{x:1452,y:940,t:1527876841755};\\\", \\\"{x:1413,y:924,t:1527876841770};\\\", \\\"{x:1383,y:915,t:1527876841788};\\\", \\\"{x:1365,y:912,t:1527876841804};\\\", \\\"{x:1351,y:909,t:1527876841821};\\\", \\\"{x:1345,y:907,t:1527876841838};\\\", \\\"{x:1342,y:905,t:1527876841854};\\\", \\\"{x:1341,y:904,t:1527876841872};\\\", \\\"{x:1339,y:903,t:1527876841888};\\\", \\\"{x:1336,y:900,t:1527876841904};\\\", \\\"{x:1330,y:896,t:1527876841922};\\\", \\\"{x:1320,y:891,t:1527876841939};\\\", \\\"{x:1311,y:887,t:1527876841955};\\\", \\\"{x:1297,y:881,t:1527876841971};\\\", \\\"{x:1283,y:874,t:1527876841988};\\\", \\\"{x:1274,y:868,t:1527876842004};\\\", \\\"{x:1263,y:862,t:1527876842021};\\\", \\\"{x:1254,y:856,t:1527876842038};\\\", \\\"{x:1244,y:851,t:1527876842054};\\\", \\\"{x:1237,y:846,t:1527876842071};\\\", \\\"{x:1229,y:840,t:1527876842088};\\\", \\\"{x:1213,y:823,t:1527876842105};\\\", \\\"{x:1195,y:804,t:1527876842122};\\\", \\\"{x:1172,y:783,t:1527876842139};\\\", \\\"{x:1162,y:773,t:1527876842154};\\\", \\\"{x:1153,y:764,t:1527876842171};\\\", \\\"{x:1149,y:758,t:1527876842188};\\\", \\\"{x:1143,y:751,t:1527876842204};\\\", \\\"{x:1139,y:747,t:1527876842221};\\\", \\\"{x:1137,y:745,t:1527876842238};\\\", \\\"{x:1138,y:745,t:1527876842331};\\\", \\\"{x:1141,y:745,t:1527876842338};\\\", \\\"{x:1143,y:746,t:1527876842354};\\\", \\\"{x:1149,y:750,t:1527876842371};\\\", \\\"{x:1161,y:758,t:1527876842389};\\\", \\\"{x:1172,y:767,t:1527876842404};\\\", \\\"{x:1178,y:772,t:1527876842421};\\\", \\\"{x:1180,y:773,t:1527876842438};\\\", \\\"{x:1180,y:774,t:1527876842454};\\\", \\\"{x:1181,y:774,t:1527876842470};\\\", \\\"{x:1183,y:776,t:1527876842866};\\\", \\\"{x:1186,y:780,t:1527876842873};\\\", \\\"{x:1191,y:786,t:1527876842888};\\\", \\\"{x:1197,y:793,t:1527876842905};\\\", \\\"{x:1201,y:799,t:1527876842921};\\\", \\\"{x:1205,y:803,t:1527876842938};\\\", \\\"{x:1207,y:806,t:1527876842953};\\\", \\\"{x:1208,y:806,t:1527876842978};\\\", \\\"{x:1208,y:808,t:1527876842993};\\\", \\\"{x:1209,y:809,t:1527876843026};\\\", \\\"{x:1210,y:810,t:1527876843042};\\\", \\\"{x:1211,y:811,t:1527876843058};\\\", \\\"{x:1211,y:812,t:1527876843091};\\\", \\\"{x:1211,y:807,t:1527876843907};\\\", \\\"{x:1216,y:791,t:1527876843921};\\\", \\\"{x:1230,y:754,t:1527876843938};\\\", \\\"{x:1240,y:731,t:1527876843955};\\\", \\\"{x:1251,y:706,t:1527876843972};\\\", \\\"{x:1261,y:685,t:1527876843988};\\\", \\\"{x:1268,y:674,t:1527876844005};\\\", \\\"{x:1276,y:663,t:1527876844022};\\\", \\\"{x:1281,y:656,t:1527876844038};\\\", \\\"{x:1284,y:652,t:1527876844055};\\\", \\\"{x:1284,y:651,t:1527876844074};\\\", \\\"{x:1284,y:650,t:1527876844091};\\\", \\\"{x:1284,y:649,t:1527876844105};\\\", \\\"{x:1287,y:640,t:1527876844122};\\\", \\\"{x:1288,y:635,t:1527876844138};\\\", \\\"{x:1288,y:631,t:1527876844155};\\\", \\\"{x:1288,y:627,t:1527876844172};\\\", \\\"{x:1288,y:624,t:1527876844188};\\\", \\\"{x:1288,y:623,t:1527876844205};\\\", \\\"{x:1287,y:621,t:1527876844222};\\\", \\\"{x:1284,y:615,t:1527876844239};\\\", \\\"{x:1282,y:611,t:1527876844256};\\\", \\\"{x:1278,y:604,t:1527876844272};\\\", \\\"{x:1273,y:596,t:1527876844288};\\\", \\\"{x:1269,y:589,t:1527876844306};\\\", \\\"{x:1263,y:579,t:1527876844322};\\\", \\\"{x:1262,y:577,t:1527876844338};\\\", \\\"{x:1262,y:582,t:1527876844459};\\\", \\\"{x:1264,y:584,t:1527876844473};\\\", \\\"{x:1268,y:594,t:1527876844488};\\\", \\\"{x:1274,y:603,t:1527876844505};\\\", \\\"{x:1284,y:621,t:1527876844522};\\\", \\\"{x:1293,y:636,t:1527876844538};\\\", \\\"{x:1302,y:651,t:1527876844555};\\\", \\\"{x:1308,y:662,t:1527876844573};\\\", \\\"{x:1314,y:669,t:1527876844588};\\\", \\\"{x:1317,y:678,t:1527876844605};\\\", \\\"{x:1322,y:687,t:1527876844622};\\\", \\\"{x:1327,y:695,t:1527876844638};\\\", \\\"{x:1331,y:702,t:1527876844655};\\\", \\\"{x:1334,y:709,t:1527876844672};\\\", \\\"{x:1338,y:718,t:1527876844688};\\\", \\\"{x:1344,y:726,t:1527876844705};\\\", \\\"{x:1351,y:742,t:1527876844722};\\\", \\\"{x:1354,y:745,t:1527876844738};\\\", \\\"{x:1355,y:749,t:1527876844755};\\\", \\\"{x:1357,y:752,t:1527876844772};\\\", \\\"{x:1358,y:754,t:1527876844789};\\\", \\\"{x:1358,y:757,t:1527876844805};\\\", \\\"{x:1359,y:761,t:1527876844822};\\\", \\\"{x:1360,y:767,t:1527876844838};\\\", \\\"{x:1360,y:770,t:1527876844855};\\\", \\\"{x:1360,y:771,t:1527876844872};\\\", \\\"{x:1360,y:772,t:1527876844888};\\\", \\\"{x:1360,y:773,t:1527876844905};\\\", \\\"{x:1360,y:774,t:1527876844931};\\\", \\\"{x:1360,y:775,t:1527876845266};\\\", \\\"{x:1360,y:776,t:1527876845298};\\\", \\\"{x:1360,y:777,t:1527876845339};\\\", \\\"{x:1361,y:778,t:1527876845355};\\\", \\\"{x:1360,y:778,t:1527876845611};\\\", \\\"{x:1359,y:778,t:1527876845622};\\\", \\\"{x:1357,y:776,t:1527876845640};\\\", \\\"{x:1356,y:772,t:1527876845656};\\\", \\\"{x:1354,y:772,t:1527876845672};\\\", \\\"{x:1353,y:769,t:1527876845698};\\\", \\\"{x:1353,y:767,t:1527876845739};\\\", \\\"{x:1351,y:765,t:1527876845758};\\\", \\\"{x:1351,y:764,t:1527876845772};\\\", \\\"{x:1350,y:763,t:1527876845789};\\\", \\\"{x:1350,y:762,t:1527876845833};\\\", \\\"{x:1352,y:765,t:1527876846554};\\\", \\\"{x:1356,y:771,t:1527876846564};\\\", \\\"{x:1359,y:778,t:1527876846572};\\\", \\\"{x:1364,y:786,t:1527876846589};\\\", \\\"{x:1367,y:792,t:1527876846606};\\\", \\\"{x:1370,y:797,t:1527876846622};\\\", \\\"{x:1371,y:801,t:1527876846638};\\\", \\\"{x:1374,y:806,t:1527876846656};\\\", \\\"{x:1377,y:813,t:1527876846671};\\\", \\\"{x:1379,y:819,t:1527876846689};\\\", \\\"{x:1382,y:830,t:1527876846705};\\\", \\\"{x:1383,y:834,t:1527876846722};\\\", \\\"{x:1384,y:839,t:1527876846739};\\\", \\\"{x:1385,y:844,t:1527876846756};\\\", \\\"{x:1385,y:845,t:1527876846771};\\\", \\\"{x:1385,y:848,t:1527876846789};\\\", \\\"{x:1385,y:851,t:1527876846805};\\\", \\\"{x:1385,y:857,t:1527876846822};\\\", \\\"{x:1385,y:861,t:1527876846839};\\\", \\\"{x:1385,y:864,t:1527876846856};\\\", \\\"{x:1385,y:866,t:1527876846872};\\\", \\\"{x:1385,y:868,t:1527876846889};\\\", \\\"{x:1385,y:870,t:1527876846906};\\\", \\\"{x:1383,y:874,t:1527876846922};\\\", \\\"{x:1382,y:880,t:1527876846940};\\\", \\\"{x:1380,y:885,t:1527876846956};\\\", \\\"{x:1379,y:889,t:1527876846972};\\\", \\\"{x:1377,y:893,t:1527876846990};\\\", \\\"{x:1377,y:895,t:1527876847006};\\\", \\\"{x:1375,y:897,t:1527876847023};\\\", \\\"{x:1375,y:899,t:1527876847039};\\\", \\\"{x:1374,y:900,t:1527876847056};\\\", \\\"{x:1374,y:901,t:1527876847072};\\\", \\\"{x:1374,y:903,t:1527876847089};\\\", \\\"{x:1372,y:904,t:1527876847106};\\\", \\\"{x:1372,y:903,t:1527876847627};\\\", \\\"{x:1372,y:902,t:1527876847640};\\\", \\\"{x:1372,y:901,t:1527876847656};\\\", \\\"{x:1372,y:900,t:1527876847673};\\\", \\\"{x:1372,y:899,t:1527876847714};\\\", \\\"{x:1373,y:896,t:1527876850435};\\\", \\\"{x:1376,y:894,t:1527876850443};\\\", \\\"{x:1377,y:892,t:1527876850457};\\\", \\\"{x:1380,y:889,t:1527876850473};\\\", \\\"{x:1383,y:886,t:1527876850489};\\\", \\\"{x:1384,y:884,t:1527876850506};\\\", \\\"{x:1386,y:882,t:1527876850523};\\\", \\\"{x:1389,y:878,t:1527876850540};\\\", \\\"{x:1390,y:877,t:1527876850557};\\\", \\\"{x:1396,y:873,t:1527876850573};\\\", \\\"{x:1397,y:871,t:1527876850590};\\\", \\\"{x:1399,y:868,t:1527876850607};\\\", \\\"{x:1402,y:866,t:1527876850623};\\\", \\\"{x:1406,y:862,t:1527876850640};\\\", \\\"{x:1411,y:859,t:1527876850657};\\\", \\\"{x:1414,y:856,t:1527876850674};\\\", \\\"{x:1420,y:852,t:1527876850690};\\\", \\\"{x:1424,y:849,t:1527876850707};\\\", \\\"{x:1428,y:847,t:1527876850723};\\\", \\\"{x:1431,y:845,t:1527876850740};\\\", \\\"{x:1434,y:844,t:1527876850758};\\\", \\\"{x:1437,y:843,t:1527876850773};\\\", \\\"{x:1438,y:843,t:1527876850791};\\\", \\\"{x:1441,y:842,t:1527876850808};\\\", \\\"{x:1441,y:841,t:1527876850824};\\\", \\\"{x:1443,y:841,t:1527876850840};\\\", \\\"{x:1446,y:841,t:1527876850858};\\\", \\\"{x:1449,y:841,t:1527876850874};\\\", \\\"{x:1452,y:841,t:1527876850891};\\\", \\\"{x:1454,y:841,t:1527876850908};\\\", \\\"{x:1458,y:842,t:1527876850925};\\\", \\\"{x:1460,y:842,t:1527876850941};\\\", \\\"{x:1464,y:842,t:1527876850957};\\\", \\\"{x:1466,y:842,t:1527876850974};\\\", \\\"{x:1467,y:842,t:1527876851002};\\\", \\\"{x:1469,y:842,t:1527876851035};\\\", \\\"{x:1470,y:842,t:1527876851042};\\\", \\\"{x:1471,y:842,t:1527876851058};\\\", \\\"{x:1473,y:838,t:1527876851075};\\\", \\\"{x:1474,y:835,t:1527876851090};\\\", \\\"{x:1475,y:834,t:1527876851107};\\\", \\\"{x:1476,y:832,t:1527876851124};\\\", \\\"{x:1477,y:831,t:1527876851140};\\\", \\\"{x:1478,y:830,t:1527876851170};\\\", \\\"{x:1478,y:829,t:1527876851202};\\\", \\\"{x:1479,y:828,t:1527876851234};\\\", \\\"{x:1477,y:823,t:1527876853154};\\\", \\\"{x:1458,y:815,t:1527876853162};\\\", \\\"{x:1428,y:808,t:1527876853174};\\\", \\\"{x:1359,y:791,t:1527876853191};\\\", \\\"{x:1275,y:776,t:1527876853208};\\\", \\\"{x:1203,y:767,t:1527876853224};\\\", \\\"{x:1138,y:757,t:1527876853241};\\\", \\\"{x:1053,y:744,t:1527876853258};\\\", \\\"{x:1013,y:740,t:1527876853274};\\\", \\\"{x:990,y:734,t:1527876853291};\\\", \\\"{x:974,y:727,t:1527876853308};\\\", \\\"{x:962,y:720,t:1527876853325};\\\", \\\"{x:953,y:715,t:1527876853341};\\\", \\\"{x:938,y:711,t:1527876853358};\\\", \\\"{x:923,y:707,t:1527876853374};\\\", \\\"{x:908,y:704,t:1527876853391};\\\", \\\"{x:898,y:699,t:1527876853408};\\\", \\\"{x:878,y:694,t:1527876853424};\\\", \\\"{x:857,y:691,t:1527876853440};\\\", \\\"{x:830,y:689,t:1527876853457};\\\", \\\"{x:809,y:686,t:1527876853473};\\\", \\\"{x:786,y:683,t:1527876853490};\\\", \\\"{x:755,y:679,t:1527876853508};\\\", \\\"{x:722,y:674,t:1527876853524};\\\", \\\"{x:674,y:666,t:1527876853541};\\\", \\\"{x:618,y:658,t:1527876853557};\\\", \\\"{x:565,y:650,t:1527876853574};\\\", \\\"{x:506,y:642,t:1527876853591};\\\", \\\"{x:464,y:635,t:1527876853609};\\\", \\\"{x:436,y:629,t:1527876853624};\\\", \\\"{x:419,y:624,t:1527876853633};\\\", \\\"{x:414,y:623,t:1527876853650};\\\", \\\"{x:413,y:622,t:1527876853667};\\\", \\\"{x:411,y:621,t:1527876853684};\\\", \\\"{x:410,y:619,t:1527876853700};\\\", \\\"{x:409,y:619,t:1527876853717};\\\", \\\"{x:408,y:618,t:1527876853734};\\\", \\\"{x:408,y:617,t:1527876853971};\\\", \\\"{x:409,y:612,t:1527876853985};\\\", \\\"{x:416,y:607,t:1527876854001};\\\", \\\"{x:420,y:601,t:1527876854018};\\\", \\\"{x:420,y:600,t:1527876854041};\\\", \\\"{x:420,y:599,t:1527876854050};\\\", \\\"{x:420,y:598,t:1527876854067};\\\", \\\"{x:420,y:596,t:1527876854084};\\\", \\\"{x:419,y:593,t:1527876854101};\\\", \\\"{x:415,y:590,t:1527876854118};\\\", \\\"{x:410,y:589,t:1527876854134};\\\", \\\"{x:409,y:588,t:1527876854151};\\\", \\\"{x:408,y:587,t:1527876854168};\\\", \\\"{x:407,y:587,t:1527876854185};\\\", \\\"{x:406,y:587,t:1527876854201};\\\", \\\"{x:405,y:587,t:1527876854233};\\\", \\\"{x:403,y:587,t:1527876854242};\\\", \\\"{x:400,y:588,t:1527876854257};\\\", \\\"{x:398,y:588,t:1527876854269};\\\", \\\"{x:393,y:591,t:1527876854287};\\\", \\\"{x:391,y:592,t:1527876854301};\\\", \\\"{x:391,y:593,t:1527876854594};\\\", \\\"{x:396,y:596,t:1527876854602};\\\", \\\"{x:413,y:602,t:1527876854618};\\\", \\\"{x:435,y:607,t:1527876854635};\\\", \\\"{x:457,y:612,t:1527876854653};\\\", \\\"{x:484,y:616,t:1527876854668};\\\", \\\"{x:512,y:617,t:1527876854686};\\\", \\\"{x:537,y:617,t:1527876854702};\\\", \\\"{x:551,y:617,t:1527876854718};\\\", \\\"{x:557,y:617,t:1527876854735};\\\", \\\"{x:561,y:617,t:1527876854752};\\\", \\\"{x:563,y:617,t:1527876854768};\\\", \\\"{x:565,y:617,t:1527876854785};\\\", \\\"{x:566,y:617,t:1527876854802};\\\", \\\"{x:568,y:617,t:1527876854818};\\\", \\\"{x:573,y:617,t:1527876854835};\\\", \\\"{x:581,y:617,t:1527876854852};\\\", \\\"{x:595,y:617,t:1527876854867};\\\", \\\"{x:611,y:617,t:1527876854885};\\\", \\\"{x:626,y:617,t:1527876854902};\\\", \\\"{x:643,y:617,t:1527876854918};\\\", \\\"{x:658,y:617,t:1527876854935};\\\", \\\"{x:668,y:617,t:1527876854952};\\\", \\\"{x:671,y:617,t:1527876854968};\\\", \\\"{x:672,y:616,t:1527876854985};\\\", \\\"{x:673,y:615,t:1527876855066};\\\", \\\"{x:673,y:613,t:1527876855075};\\\", \\\"{x:672,y:610,t:1527876855085};\\\", \\\"{x:669,y:607,t:1527876855103};\\\", \\\"{x:664,y:602,t:1527876855119};\\\", \\\"{x:659,y:599,t:1527876855135};\\\", \\\"{x:655,y:596,t:1527876855151};\\\", \\\"{x:649,y:594,t:1527876855169};\\\", \\\"{x:643,y:593,t:1527876855185};\\\", \\\"{x:637,y:589,t:1527876855202};\\\", \\\"{x:633,y:587,t:1527876855219};\\\", \\\"{x:631,y:586,t:1527876855235};\\\", \\\"{x:629,y:586,t:1527876855298};\\\", \\\"{x:628,y:586,t:1527876855314};\\\", \\\"{x:627,y:585,t:1527876855322};\\\", \\\"{x:626,y:585,t:1527876855335};\\\", \\\"{x:625,y:584,t:1527876855352};\\\", \\\"{x:624,y:584,t:1527876855368};\\\", \\\"{x:622,y:591,t:1527876855658};\\\", \\\"{x:621,y:599,t:1527876855669};\\\", \\\"{x:617,y:614,t:1527876855686};\\\", \\\"{x:615,y:626,t:1527876855702};\\\", \\\"{x:609,y:637,t:1527876855718};\\\", \\\"{x:602,y:648,t:1527876855737};\\\", \\\"{x:596,y:658,t:1527876855752};\\\", \\\"{x:593,y:664,t:1527876855768};\\\", \\\"{x:585,y:677,t:1527876855785};\\\", \\\"{x:577,y:688,t:1527876855802};\\\", \\\"{x:568,y:700,t:1527876855819};\\\", \\\"{x:562,y:704,t:1527876855837};\\\", \\\"{x:558,y:708,t:1527876855852};\\\", \\\"{x:558,y:709,t:1527876855869};\\\", \\\"{x:557,y:710,t:1527876855886};\\\", \\\"{x:556,y:710,t:1527876855903};\\\", \\\"{x:556,y:711,t:1527876855921};\\\", \\\"{x:554,y:711,t:1527876855937};\\\", \\\"{x:554,y:712,t:1527876855953};\\\", \\\"{x:551,y:716,t:1527876855970};\\\", \\\"{x:545,y:724,t:1527876855985};\\\", \\\"{x:544,y:726,t:1527876856003};\\\", \\\"{x:542,y:729,t:1527876856019};\\\", \\\"{x:541,y:732,t:1527876856037};\\\", \\\"{x:541,y:733,t:1527876856053};\\\", \\\"{x:541,y:734,t:1527876856069};\\\", \\\"{x:541,y:735,t:1527876856087};\\\", \\\"{x:541,y:736,t:1527876856104};\\\", \\\"{x:541,y:737,t:1527876856119};\\\", \\\"{x:541,y:738,t:1527876856283};\\\", \\\"{x:541,y:741,t:1527876856290};\\\", \\\"{x:541,y:742,t:1527876856303};\\\", \\\"{x:541,y:743,t:1527876856320};\\\" ] }, { \\\"rt\\\": 68276, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 20, \\\"time_elapsed\\\": 537266, \\\"internal_node_id\\\": \\\"0.0-7.0-0.0\\\", \\\"subject\\\": \\\"HW2SN\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"xray\\\", \\\"condition\\\": \\\"311\\\", \\\"q\\\": 16, \\\"answer\\\": \\\"Follow the time axis until you hit 12pm, then follow the diagonal line going forward. On that diagonal line are the events that will start at 12pm.\\\", \\\"block\\\": \\\"triangular_testing\\\" }, { \\\"rt\\\": 8250, \\\"responses\\\": \\\"{\\\\\\\"Q0\\\\\\\":\\\\\\\"19\\\\\\\",\\\\\\\"Q1\\\\\\\":\\\\\\\"United States\\\\\\\"}\\\", \\\"block\\\": \\\"demo-1\\\", \\\"trial_type\\\": \\\"survey-text\\\", \\\"trial_index\\\": 21, \\\"time_elapsed\\\": 546523, \\\"internal_node_id\\\": \\\"0.0-8.0\\\", \\\"subject\\\": \\\"HW2SN\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"xray\\\", \\\"condition\\\": \\\"311\\\" }, { \\\"rt\\\": 16442, \\\"responses\\\": \\\"{\\\\\\\"Q0\\\\\\\":\\\\\\\"English\\\\\\\",\\\\\\\"Q1\\\\\\\":\\\\\\\"First\\\\\\\",\\\\\\\"Q2\\\\\\\":\\\\\\\"Social Sciences (incl. CogSci)\\\\\\\",\\\\\\\"Q3\\\\\\\":\\\\\\\"Female\\\\\\\"}\\\", \\\"block\\\": \\\"demo-2\\\", \\\"trial_type\\\": \\\"survey-multi-choice\\\", \\\"trial_index\\\": 22, \\\"time_elapsed\\\": 563981, \\\"internal_node_id\\\": \\\"0.0-9.0\\\", \\\"subject\\\": \\\"HW2SN\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"xray\\\", \\\"condition\\\": \\\"311\\\" }, { \\\"rt\\\": 14540, \\\"url\\\": \\\"../views/src/external/debrief.html\\\", \\\"block\\\": \\\"debrief\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 23, \\\"time_elapsed\\\": 579876, \\\"internal_node_id\\\": \\\"0.0-10.0\\\", \\\"subject\\\": \\\"HW2SN\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"xray\\\", \\\"condition\\\": \\\"311\\\" } ]\",\"parentNode\":{\"id\":2765}}],[],[]]}"
    }
  ],
  "initialDom": "{\"f\":\"initialize\",\"args\":[1,[{\"nodeType\":10,\"id\":2,\"name\":\"html\",\"publicId\":\"\",\"systemId\":\"\"},{\"nodeType\":1,\"id\":3,\"tagName\":\"HTML\",\"attributes\":{\"class\":\"fa-events-icons-ready\"},\"childNodes\":[{\"nodeType\":1,\"id\":4,\"tagName\":\"HEAD\",\"attributes\":{},\"childNodes\":[{\"nodeType\":3,\"id\":5,\"textContent\":\" \"},{\"nodeType\":1,\"id\":6,\"tagName\":\"TITLE\",\"attributes\":{},\"childNodes\":[{\"nodeType\":3,\"id\":7,\"textContent\":\"FOX2YP\"}]},{\"nodeType\":3,\"id\":8,\"textContent\":\" \"},{\"nodeType\":8,\"id\":9},{\"nodeType\":3,\"id\":10,\"textContent\":\" \"},{\"nodeType\":1,\"id\":11,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":12,\"textContent\":\" \"},{\"nodeType\":1,\"id\":13,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":14,\"textContent\":\" \"},{\"nodeType\":1,\"id\":15,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":16,\"textContent\":\" \"},{\"nodeType\":1,\"id\":17,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":18,\"textContent\":\" \"},{\"nodeType\":1,\"id\":19,\"tagName\":\"SCRIPT\"},{\"nodeType\":1,\"id\":20,\"tagName\":\"LINK\",\"attributes\":{\"href\":\"https://use.fontawesome.com/945539d961.css\",\"media\":\"all\",\"rel\":\"stylesheet\"}},{\"nodeType\":3,\"id\":21,\"textContent\":\" \"},{\"nodeType\":8,\"id\":22},{\"nodeType\":3,\"id\":23,\"textContent\":\" \"},{\"nodeType\":1,\"id\":24,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":25,\"textContent\":\" \"},{\"nodeType\":1,\"id\":26,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":27,\"textContent\":\" \"},{\"nodeType\":1,\"id\":28,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":29,\"textContent\":\" \"},{\"nodeType\":1,\"id\":30,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":31,\"textContent\":\" \"},{\"nodeType\":1,\"id\":32,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":33,\"textContent\":\" \"},{\"nodeType\":1,\"id\":34,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":35,\"textContent\":\" \"},{\"nodeType\":1,\"id\":36,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":37,\"textContent\":\" \"},{\"nodeType\":8,\"id\":38},{\"nodeType\":3,\"id\":39,\"textContent\":\" \"},{\"nodeType\":1,\"id\":40,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":41,\"textContent\":\" \"},{\"nodeType\":8,\"id\":42},{\"nodeType\":3,\"id\":43,\"textContent\":\" \"},{\"nodeType\":8,\"id\":44},{\"nodeType\":3,\"id\":45,\"textContent\":\" \"},{\"nodeType\":1,\"id\":46,\"tagName\":\"LINK\",\"attributes\":{\"href\":\"../views/jsPsych/css/jspsych.css\",\"rel\":\"stylesheet\",\"type\":\"text/css\"}},{\"nodeType\":3,\"id\":47,\"textContent\":\" \"},{\"nodeType\":1,\"id\":48,\"tagName\":\"LINK\",\"attributes\":{\"href\":\"../css/styles.css\",\"rel\":\"stylesheet\",\"type\":\"text/css\"}},{\"nodeType\":3,\"id\":49,\"textContent\":\" \"},{\"nodeType\":1,\"id\":50,\"tagName\":\"SCRIPT\"},{\"nodeType\":1,\"id\":51,\"tagName\":\"SCRIPT\"}]},{\"nodeType\":3,\"id\":52,\"textContent\":\" \"},{\"nodeType\":8,\"id\":53},{\"nodeType\":3,\"id\":54,\"textContent\":\" \"},{\"nodeType\":1,\"id\":55,\"tagName\":\"BODY\",\"attributes\":{\"class\":\"jspsych-display-element\"},\"childNodes\":[{\"nodeType\":3,\"id\":56,\"textContent\":\" \"},{\"nodeType\":1,\"id\":57,\"tagName\":\"META\",\"attributes\":{\"charset\":\"utf-8\"}},{\"nodeType\":3,\"id\":58,\"textContent\":\" \"},{\"nodeType\":8,\"id\":59},{\"nodeType\":3,\"id\":60,\"textContent\":\" \"},{\"nodeType\":1,\"id\":61,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":62,\"textContent\":\" \"},{\"nodeType\":1,\"id\":63,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":64,\"textContent\":\" \"},{\"nodeType\":1,\"id\":65,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":66,\"textContent\":\" \"},{\"nodeType\":1,\"id\":67,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":68,\"textContent\":\" \"},{\"nodeType\":1,\"id\":69,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":70,\"textContent\":\" \"},{\"nodeType\":1,\"id\":71,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":72,\"textContent\":\" \"},{\"nodeType\":1,\"id\":73,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"stimulus\"},\"childNodes\":[{\"nodeType\":3,\"id\":74,\"textContent\":\" \"},{\"nodeType\":1,\"id\":75,\"tagName\":\"P\",\"attributes\":{\"class\":\"userid\",\"id\":\"userid\"},\"childNodes\":[{\"nodeType\":3,\"id\":76,\"textContent\":\"HW2SN\"}]},{\"nodeType\":3,\"id\":77,\"textContent\":\" \"},{\"nodeType\":1,\"id\":78,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"userinput\"},\"childNodes\":[{\"nodeType\":3,\"id\":79,\"textContent\":\" \"},{\"nodeType\":8,\"id\":80},{\"nodeType\":3,\"id\":81,\"textContent\":\" \"},{\"nodeType\":1,\"id\":82,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"legend\",\"id\":\"hint-interactive\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":83,\"textContent\":\" \"},{\"nodeType\":1,\"id\":84,\"tagName\":\"P\",\"attributes\":{},\"childNodes\":[{\"nodeType\":3,\"id\":85,\"textContent\":\"Hint: Hover your mouse over the data points in the graph\"}]},{\"nodeType\":3,\"id\":86,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":87,\"textContent\":\" \"},{\"nodeType\":8,\"id\":88},{\"nodeType\":3,\"id\":89,\"textContent\":\" \"},{\"nodeType\":8,\"id\":90},{\"nodeType\":3,\"id\":91,\"textContent\":\" \"},{\"nodeType\":1,\"id\":92,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"test\"},\"childNodes\":[{\"nodeType\":3,\"id\":93,\"textContent\":\" \"},{\"nodeType\":1,\"id\":94,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"acme\",\"id\":\"acme.starttime\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":95,\"textContent\":\" \"},{\"nodeType\":1,\"id\":96,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":97,\"textContent\":\"Which shift(s) start at 11 am? \"}]},{\"nodeType\":3,\"id\":98,\"textContent\":\" \"},{\"nodeType\":1,\"id\":99,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":100,\"textContent\":\" \"},{\"nodeType\":1,\"id\":101,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":102,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":103,\"textContent\":\" \"},{\"nodeType\":1,\"id\":104,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":105,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":106,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":107,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":108,\"textContent\":\" \"},{\"nodeType\":1,\"id\":109,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":110,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":111,\"textContent\":\" \"},{\"nodeType\":1,\"id\":112,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":113,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":114,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":115,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":116,\"textContent\":\" \"},{\"nodeType\":1,\"id\":117,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":118,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":119,\"textContent\":\" \"},{\"nodeType\":1,\"id\":120,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":121,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":122,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":123,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":124,\"textContent\":\" \"},{\"nodeType\":1,\"id\":125,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":126,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":127,\"textContent\":\" \"},{\"nodeType\":1,\"id\":128,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":129,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":130,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":131,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":132,\"textContent\":\" \"},{\"nodeType\":1,\"id\":133,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":134,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":135,\"textContent\":\" \"},{\"nodeType\":1,\"id\":136,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":137,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":138,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":139,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":140,\"textContent\":\" \"},{\"nodeType\":1,\"id\":141,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":142,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":143,\"textContent\":\" \"},{\"nodeType\":1,\"id\":144,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":145,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":146,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":147,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":148,\"textContent\":\" \"},{\"nodeType\":1,\"id\":149,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":150,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":151,\"textContent\":\" \"},{\"nodeType\":1,\"id\":152,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":153,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":154,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":155,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":156,\"textContent\":\" \"},{\"nodeType\":1,\"id\":157,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":158,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":159,\"textContent\":\" \"},{\"nodeType\":1,\"id\":160,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":161,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":162,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":163,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":164,\"textContent\":\" \"},{\"nodeType\":1,\"id\":165,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":166,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":167,\"textContent\":\" \"},{\"nodeType\":1,\"id\":168,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":169,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":170,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":171,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":172,\"textContent\":\" \"},{\"nodeType\":1,\"id\":173,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":174,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":175,\"textContent\":\" \"},{\"nodeType\":1,\"id\":176,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":177,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":178,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":179,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":180,\"textContent\":\" \"},{\"nodeType\":1,\"id\":181,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":182,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":183,\"textContent\":\" \"},{\"nodeType\":1,\"id\":184,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"U\",\"value\":\"\"}},{\"nodeType\":3,\"id\":185,\"textContent\":\"U \"},{\"nodeType\":1,\"id\":186,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":187,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":188,\"textContent\":\" \"},{\"nodeType\":1,\"id\":189,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":190,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":191,\"textContent\":\" \"},{\"nodeType\":1,\"id\":192,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":193,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":194,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":195,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":196,\"textContent\":\" \"},{\"nodeType\":1,\"id\":197,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":198,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":199,\"textContent\":\" \"},{\"nodeType\":1,\"id\":200,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":201,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":202,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":203,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":204,\"textContent\":\" \"},{\"nodeType\":1,\"id\":205,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":206,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":207,\"textContent\":\" \"},{\"nodeType\":1,\"id\":208,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":209,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":210,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":211,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":212,\"textContent\":\" \"},{\"nodeType\":1,\"id\":213,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":214,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":215,\"textContent\":\" \"},{\"nodeType\":1,\"id\":216,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":217,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":218,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":219,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":220,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":221,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":222,\"textContent\":\" \"},{\"nodeType\":1,\"id\":223,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"acme\",\"id\":\"acme.starts\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":224,\"textContent\":\" \"},{\"nodeType\":1,\"id\":225,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":226,\"textContent\":\"Which shift(s) start at the same time as D?\"}]},{\"nodeType\":3,\"id\":227,\"textContent\":\" \"},{\"nodeType\":1,\"id\":228,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":229,\"textContent\":\" \"},{\"nodeType\":1,\"id\":230,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":231,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":232,\"textContent\":\" \"},{\"nodeType\":1,\"id\":233,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":234,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":235,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":236,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":237,\"textContent\":\" \"},{\"nodeType\":1,\"id\":238,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":239,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":240,\"textContent\":\" \"},{\"nodeType\":1,\"id\":241,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":242,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":243,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":244,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":245,\"textContent\":\" \"},{\"nodeType\":1,\"id\":246,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":247,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":248,\"textContent\":\" \"},{\"nodeType\":1,\"id\":249,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":250,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":251,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":252,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":253,\"textContent\":\" \"},{\"nodeType\":1,\"id\":254,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":255,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":256,\"textContent\":\" \"},{\"nodeType\":1,\"id\":257,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":258,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":259,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":260,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":261,\"textContent\":\" \"},{\"nodeType\":1,\"id\":262,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":263,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":264,\"textContent\":\" \"},{\"nodeType\":1,\"id\":265,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":266,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":267,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":268,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":269,\"textContent\":\" \"},{\"nodeType\":1,\"id\":270,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":271,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":272,\"textContent\":\" \"},{\"nodeType\":1,\"id\":273,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":274,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":275,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":276,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":277,\"textContent\":\" \"},{\"nodeType\":1,\"id\":278,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":279,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":280,\"textContent\":\" \"},{\"nodeType\":1,\"id\":281,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":282,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":283,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":284,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":285,\"textContent\":\" \"},{\"nodeType\":1,\"id\":286,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":287,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":288,\"textContent\":\" \"},{\"nodeType\":1,\"id\":289,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":290,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":291,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":292,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":293,\"textContent\":\" \"},{\"nodeType\":1,\"id\":294,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":295,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":296,\"textContent\":\" \"},{\"nodeType\":1,\"id\":297,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":298,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":299,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":300,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":301,\"textContent\":\" \"},{\"nodeType\":1,\"id\":302,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":303,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":304,\"textContent\":\" \"},{\"nodeType\":1,\"id\":305,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":306,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":307,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":308,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":309,\"textContent\":\" \"},{\"nodeType\":1,\"id\":310,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":311,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":312,\"textContent\":\" \"},{\"nodeType\":1,\"id\":313,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"U\",\"value\":\"\"}},{\"nodeType\":3,\"id\":314,\"textContent\":\"U \"},{\"nodeType\":1,\"id\":315,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":316,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":317,\"textContent\":\" \"},{\"nodeType\":1,\"id\":318,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":319,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":320,\"textContent\":\" \"},{\"nodeType\":1,\"id\":321,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":322,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":323,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":324,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":325,\"textContent\":\" \"},{\"nodeType\":1,\"id\":326,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":327,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":328,\"textContent\":\" \"},{\"nodeType\":1,\"id\":329,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":330,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":331,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":332,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":333,\"textContent\":\" \"},{\"nodeType\":1,\"id\":334,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":335,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":336,\"textContent\":\" \"},{\"nodeType\":1,\"id\":337,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":338,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":339,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":340,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":341,\"textContent\":\" \"},{\"nodeType\":1,\"id\":342,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":343,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":344,\"textContent\":\" \"},{\"nodeType\":1,\"id\":345,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":346,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":347,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":348,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":349,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":350,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":351,\"textContent\":\" \"},{\"nodeType\":1,\"id\":352,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"acme\",\"id\":\"acme.meets\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":353,\"textContent\":\" \"},{\"nodeType\":1,\"id\":354,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":355,\"textContent\":\"Which shift(s) begin when C ends?\"}]},{\"nodeType\":3,\"id\":356,\"textContent\":\" \"},{\"nodeType\":1,\"id\":357,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":358,\"textContent\":\" \"},{\"nodeType\":1,\"id\":359,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":360,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":361,\"textContent\":\" \"},{\"nodeType\":1,\"id\":362,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":363,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":364,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":365,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":366,\"textContent\":\" \"},{\"nodeType\":1,\"id\":367,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":368,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":369,\"textContent\":\" \"},{\"nodeType\":1,\"id\":370,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":371,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":372,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":373,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":374,\"textContent\":\" \"},{\"nodeType\":1,\"id\":375,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":376,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":377,\"textContent\":\" \"},{\"nodeType\":1,\"id\":378,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":379,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":380,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":381,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":382,\"textContent\":\" \"},{\"nodeType\":1,\"id\":383,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":384,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":385,\"textContent\":\" \"},{\"nodeType\":1,\"id\":386,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":387,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":388,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":389,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":390,\"textContent\":\" \"},{\"nodeType\":1,\"id\":391,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":392,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":393,\"textContent\":\" \"},{\"nodeType\":1,\"id\":394,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":395,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":396,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":397,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":398,\"textContent\":\" \"},{\"nodeType\":1,\"id\":399,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":400,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":401,\"textContent\":\" \"},{\"nodeType\":1,\"id\":402,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":403,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":404,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":405,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":406,\"textContent\":\" \"},{\"nodeType\":1,\"id\":407,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":408,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":409,\"textContent\":\" \"},{\"nodeType\":1,\"id\":410,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":411,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":412,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":413,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":414,\"textContent\":\" \"},{\"nodeType\":1,\"id\":415,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":416,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":417,\"textContent\":\" \"},{\"nodeType\":1,\"id\":418,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":419,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":420,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":421,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":422,\"textContent\":\" \"},{\"nodeType\":1,\"id\":423,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":424,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":425,\"textContent\":\" \"},{\"nodeType\":1,\"id\":426,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":427,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":428,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":429,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":430,\"textContent\":\" \"},{\"nodeType\":1,\"id\":431,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":432,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":433,\"textContent\":\" \"},{\"nodeType\":1,\"id\":434,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":435,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":436,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":437,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":438,\"textContent\":\" \"},{\"nodeType\":1,\"id\":439,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":440,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":441,\"textContent\":\" \"},{\"nodeType\":1,\"id\":442,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"U\",\"value\":\"\"}},{\"nodeType\":3,\"id\":443,\"textContent\":\"U \"},{\"nodeType\":1,\"id\":444,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":445,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":446,\"textContent\":\" \"},{\"nodeType\":1,\"id\":447,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":448,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":449,\"textContent\":\" \"},{\"nodeType\":1,\"id\":450,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":451,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":452,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":453,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":454,\"textContent\":\" \"},{\"nodeType\":1,\"id\":455,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":456,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":457,\"textContent\":\" \"},{\"nodeType\":1,\"id\":458,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":459,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":460,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":461,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":462,\"textContent\":\" \"},{\"nodeType\":1,\"id\":463,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":464,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":465,\"textContent\":\" \"},{\"nodeType\":1,\"id\":466,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":467,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":468,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":469,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":470,\"textContent\":\" \"},{\"nodeType\":1,\"id\":471,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":472,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":473,\"textContent\":\" \"},{\"nodeType\":1,\"id\":474,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":475,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":476,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":477,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":478,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":479,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":480,\"textContent\":\" \"},{\"nodeType\":1,\"id\":481,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"acme\",\"id\":\"acme.endtime\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":482,\"textContent\":\" \"},{\"nodeType\":1,\"id\":483,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":484,\"textContent\":\" Which shift(s) end at 4 pm?\"}]},{\"nodeType\":3,\"id\":485,\"textContent\":\" \"},{\"nodeType\":1,\"id\":486,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":487,\"textContent\":\" \"},{\"nodeType\":1,\"id\":488,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":489,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":490,\"textContent\":\" \"},{\"nodeType\":1,\"id\":491,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":492,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":493,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":494,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":495,\"textContent\":\" \"},{\"nodeType\":1,\"id\":496,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":497,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":498,\"textContent\":\" \"},{\"nodeType\":1,\"id\":499,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":500,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":501,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":502,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":503,\"textContent\":\" \"},{\"nodeType\":1,\"id\":504,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":505,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":506,\"textContent\":\" \"},{\"nodeType\":1,\"id\":507,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":508,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":509,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":510,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":511,\"textContent\":\" \"},{\"nodeType\":1,\"id\":512,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":513,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":514,\"textContent\":\" \"},{\"nodeType\":1,\"id\":515,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":516,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":517,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":518,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":519,\"textContent\":\" \"},{\"nodeType\":1,\"id\":520,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":521,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":522,\"textContent\":\" \"},{\"nodeType\":1,\"id\":523,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":524,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":525,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":526,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":527,\"textContent\":\" \"},{\"nodeType\":1,\"id\":528,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":529,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":530,\"textContent\":\" \"},{\"nodeType\":1,\"id\":531,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":532,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":533,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":534,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":535,\"textContent\":\" \"},{\"nodeType\":1,\"id\":536,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":537,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":538,\"textContent\":\" \"},{\"nodeType\":1,\"id\":539,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":540,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":541,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":542,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":543,\"textContent\":\" \"},{\"nodeType\":1,\"id\":544,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":545,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":546,\"textContent\":\" \"},{\"nodeType\":1,\"id\":547,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":548,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":549,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":550,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":551,\"textContent\":\" \"},{\"nodeType\":1,\"id\":552,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":553,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":554,\"textContent\":\" \"},{\"nodeType\":1,\"id\":555,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":556,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":557,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":558,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":559,\"textContent\":\" \"},{\"nodeType\":1,\"id\":560,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":561,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":562,\"textContent\":\" \"},{\"nodeType\":1,\"id\":563,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":564,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":565,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":566,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":567,\"textContent\":\" \"},{\"nodeType\":1,\"id\":568,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":569,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":570,\"textContent\":\" \"},{\"nodeType\":1,\"id\":571,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"U\",\"value\":\"\"}},{\"nodeType\":3,\"id\":572,\"textContent\":\"U \"},{\"nodeType\":1,\"id\":573,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":574,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":575,\"textContent\":\" \"},{\"nodeType\":1,\"id\":576,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":577,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":578,\"textContent\":\" \"},{\"nodeType\":1,\"id\":579,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":580,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":581,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":582,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":583,\"textContent\":\" \"},{\"nodeType\":1,\"id\":584,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":585,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":586,\"textContent\":\" \"},{\"nodeType\":1,\"id\":587,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":588,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":589,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":590,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":591,\"textContent\":\" \"},{\"nodeType\":1,\"id\":592,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":593,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":594,\"textContent\":\" \"},{\"nodeType\":1,\"id\":595,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":596,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":597,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":598,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":599,\"textContent\":\" \"},{\"nodeType\":1,\"id\":600,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":601,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":602,\"textContent\":\" \"},{\"nodeType\":1,\"id\":603,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":604,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":605,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":606,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":607,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":608,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":609,\"textContent\":\" \"},{\"nodeType\":1,\"id\":610,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"acme\",\"id\":\"acme.midpoint\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":611,\"textContent\":\" \"},{\"nodeType\":1,\"id\":612,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":613,\"textContent\":\"Coffee breaks happen halfway through a shift.\"},{\"nodeType\":1,\"id\":614,\"tagName\":\"BR\",\"attributes\":{}},{\"nodeType\":3,\"id\":615,\"textContent\":\" Which shift(s) share a break with I?\"}]},{\"nodeType\":3,\"id\":616,\"textContent\":\" \"},{\"nodeType\":1,\"id\":617,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":618,\"textContent\":\" \"},{\"nodeType\":1,\"id\":619,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":620,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":621,\"textContent\":\" \"},{\"nodeType\":1,\"id\":622,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":623,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":624,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":625,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":626,\"textContent\":\" \"},{\"nodeType\":1,\"id\":627,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":628,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":629,\"textContent\":\" \"},{\"nodeType\":1,\"id\":630,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":631,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":632,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":633,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":634,\"textContent\":\" \"},{\"nodeType\":1,\"id\":635,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":636,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":637,\"textContent\":\" \"},{\"nodeType\":1,\"id\":638,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":639,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":640,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":641,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":642,\"textContent\":\" \"},{\"nodeType\":1,\"id\":643,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":644,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":645,\"textContent\":\" \"},{\"nodeType\":1,\"id\":646,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":647,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":648,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":649,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":650,\"textContent\":\" \"},{\"nodeType\":1,\"id\":651,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":652,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":653,\"textContent\":\" \"},{\"nodeType\":1,\"id\":654,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":655,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":656,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":657,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":658,\"textContent\":\" \"},{\"nodeType\":1,\"id\":659,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":660,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":661,\"textContent\":\" \"},{\"nodeType\":1,\"id\":662,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":663,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":664,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":665,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":666,\"textContent\":\" \"},{\"nodeType\":1,\"id\":667,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":668,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":669,\"textContent\":\" \"},{\"nodeType\":1,\"id\":670,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":671,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":672,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":673,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":674,\"textContent\":\" \"},{\"nodeType\":1,\"id\":675,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":676,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":677,\"textContent\":\" \"},{\"nodeType\":1,\"id\":678,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":679,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":680,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":681,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":682,\"textContent\":\" \"},{\"nodeType\":1,\"id\":683,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":684,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":685,\"textContent\":\" \"},{\"nodeType\":1,\"id\":686,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":687,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":688,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":689,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":690,\"textContent\":\" \"},{\"nodeType\":1,\"id\":691,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":692,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":693,\"textContent\":\" \"},{\"nodeType\":1,\"id\":694,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":695,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":696,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":697,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":698,\"textContent\":\" \"},{\"nodeType\":1,\"id\":699,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":700,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":701,\"textContent\":\" \"},{\"nodeType\":1,\"id\":702,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"U\",\"value\":\"\"}},{\"nodeType\":3,\"id\":703,\"textContent\":\"U \"},{\"nodeType\":1,\"id\":704,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":705,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":706,\"textContent\":\" \"},{\"nodeType\":1,\"id\":707,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":708,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":709,\"textContent\":\" \"},{\"nodeType\":1,\"id\":710,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":711,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":712,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":713,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":714,\"textContent\":\" \"},{\"nodeType\":1,\"id\":715,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":716,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":717,\"textContent\":\" \"},{\"nodeType\":1,\"id\":718,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":719,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":720,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":721,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":722,\"textContent\":\" \"},{\"nodeType\":1,\"id\":723,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":724,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":725,\"textContent\":\" \"},{\"nodeType\":1,\"id\":726,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":727,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":728,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":729,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":730,\"textContent\":\" \"},{\"nodeType\":1,\"id\":731,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":732,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":733,\"textContent\":\" \"},{\"nodeType\":1,\"id\":734,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":735,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":736,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":737,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":738,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":739,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":740,\"textContent\":\" \"},{\"nodeType\":1,\"id\":741,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.duration\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":742,\"textContent\":\" \"},{\"nodeType\":1,\"id\":743,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":744,\"textContent\":\"Which shift(s) are six hours long?\"}]},{\"nodeType\":3,\"id\":745,\"textContent\":\" \"},{\"nodeType\":1,\"id\":746,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":747,\"textContent\":\" \"},{\"nodeType\":1,\"id\":748,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":749,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":750,\"textContent\":\" \"},{\"nodeType\":1,\"id\":751,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":752,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":753,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":754,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":755,\"textContent\":\" \"},{\"nodeType\":1,\"id\":756,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":757,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":758,\"textContent\":\" \"},{\"nodeType\":1,\"id\":759,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":760,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":761,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":762,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":763,\"textContent\":\" \"},{\"nodeType\":1,\"id\":764,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":765,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":766,\"textContent\":\" \"},{\"nodeType\":1,\"id\":767,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":768,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":769,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":770,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":771,\"textContent\":\" \"},{\"nodeType\":1,\"id\":772,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":773,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":774,\"textContent\":\" \"},{\"nodeType\":1,\"id\":775,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":776,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":777,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":778,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":779,\"textContent\":\" \"},{\"nodeType\":1,\"id\":780,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":781,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":782,\"textContent\":\" \"},{\"nodeType\":1,\"id\":783,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":784,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":785,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":786,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":787,\"textContent\":\" \"},{\"nodeType\":1,\"id\":788,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":789,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":790,\"textContent\":\" \"},{\"nodeType\":1,\"id\":791,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":792,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":793,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":794,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":795,\"textContent\":\" \"},{\"nodeType\":1,\"id\":796,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":797,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":798,\"textContent\":\" \"},{\"nodeType\":1,\"id\":799,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":800,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":801,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":802,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":803,\"textContent\":\" \"},{\"nodeType\":1,\"id\":804,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":805,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":806,\"textContent\":\" \"},{\"nodeType\":1,\"id\":807,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":808,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":809,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":810,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":811,\"textContent\":\" \"},{\"nodeType\":1,\"id\":812,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":813,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":814,\"textContent\":\" \"},{\"nodeType\":1,\"id\":815,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":816,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":817,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":818,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":819,\"textContent\":\" \"},{\"nodeType\":1,\"id\":820,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":821,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":822,\"textContent\":\" \"},{\"nodeType\":1,\"id\":823,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":824,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":825,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":826,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":827,\"textContent\":\" \"},{\"nodeType\":1,\"id\":828,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":829,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":830,\"textContent\":\" \"},{\"nodeType\":1,\"id\":831,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":832,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":833,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":834,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":835,\"textContent\":\" \"},{\"nodeType\":1,\"id\":836,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":837,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":838,\"textContent\":\" \"},{\"nodeType\":1,\"id\":839,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":840,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":841,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":842,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":843,\"textContent\":\" \"},{\"nodeType\":1,\"id\":844,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":845,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":846,\"textContent\":\" \"},{\"nodeType\":1,\"id\":847,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":848,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":849,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":850,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":851,\"textContent\":\" \"},{\"nodeType\":1,\"id\":852,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":853,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":854,\"textContent\":\" \"},{\"nodeType\":1,\"id\":855,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":856,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":857,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":858,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":859,\"textContent\":\" \"},{\"nodeType\":1,\"id\":860,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":861,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":862,\"textContent\":\" \"},{\"nodeType\":1,\"id\":863,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":864,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":865,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":866,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":867,\"textContent\":\" \"},{\"nodeType\":1,\"id\":868,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":869,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":870,\"textContent\":\" \"},{\"nodeType\":1,\"id\":871,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":872,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":873,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":874,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":875,\"textContent\":\" \"},{\"nodeType\":1,\"id\":876,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":877,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":878,\"textContent\":\" \"},{\"nodeType\":1,\"id\":879,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":880,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":881,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":882,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":883,\"textContent\":\" \"},{\"nodeType\":1,\"id\":884,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":885,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":886,\"textContent\":\" \"},{\"nodeType\":1,\"id\":887,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":888,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":889,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":890,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":891,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":892,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":893,\"textContent\":\" \"},{\"nodeType\":1,\"id\":894,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.duration+starts\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":895,\"textContent\":\" \"},{\"nodeType\":1,\"id\":896,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":897,\"textContent\":\"Which 2 shifts less than 5 hours long start at the same time?\"}]},{\"nodeType\":3,\"id\":898,\"textContent\":\" \"},{\"nodeType\":1,\"id\":899,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":900,\"textContent\":\" \"},{\"nodeType\":1,\"id\":901,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":902,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":903,\"textContent\":\" \"},{\"nodeType\":1,\"id\":904,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":905,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":906,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":907,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":908,\"textContent\":\" \"},{\"nodeType\":1,\"id\":909,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":910,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":911,\"textContent\":\" \"},{\"nodeType\":1,\"id\":912,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":913,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":914,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":915,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":916,\"textContent\":\" \"},{\"nodeType\":1,\"id\":917,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":918,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":919,\"textContent\":\" \"},{\"nodeType\":1,\"id\":920,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":921,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":922,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":923,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":924,\"textContent\":\" \"},{\"nodeType\":1,\"id\":925,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":926,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":927,\"textContent\":\" \"},{\"nodeType\":1,\"id\":928,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":929,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":930,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":931,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":932,\"textContent\":\" \"},{\"nodeType\":1,\"id\":933,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":934,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":935,\"textContent\":\" \"},{\"nodeType\":1,\"id\":936,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":937,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":938,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":939,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":940,\"textContent\":\" \"},{\"nodeType\":1,\"id\":941,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":942,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":943,\"textContent\":\" \"},{\"nodeType\":1,\"id\":944,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":945,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":946,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":947,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":948,\"textContent\":\" \"},{\"nodeType\":1,\"id\":949,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":950,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":951,\"textContent\":\" \"},{\"nodeType\":1,\"id\":952,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":953,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":954,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":955,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":956,\"textContent\":\" \"},{\"nodeType\":1,\"id\":957,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":958,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":959,\"textContent\":\" \"},{\"nodeType\":1,\"id\":960,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":961,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":962,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":963,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":964,\"textContent\":\" \"},{\"nodeType\":1,\"id\":965,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":966,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":967,\"textContent\":\" \"},{\"nodeType\":1,\"id\":968,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":969,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":970,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":971,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":972,\"textContent\":\" \"},{\"nodeType\":1,\"id\":973,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":974,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":975,\"textContent\":\" \"},{\"nodeType\":1,\"id\":976,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":977,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":978,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":979,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":980,\"textContent\":\" \"},{\"nodeType\":1,\"id\":981,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":982,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":983,\"textContent\":\" \"},{\"nodeType\":1,\"id\":984,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":985,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":986,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":987,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":988,\"textContent\":\" \"},{\"nodeType\":1,\"id\":989,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":990,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":991,\"textContent\":\" \"},{\"nodeType\":1,\"id\":992,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":993,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":994,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":995,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":996,\"textContent\":\" \"},{\"nodeType\":1,\"id\":997,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":998,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":999,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1000,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1001,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":1002,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1003,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1004,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1005,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1006,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1007,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1008,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1009,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":1010,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1011,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1012,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1013,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1014,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1015,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1016,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1017,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":1018,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1019,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1020,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1021,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1022,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1023,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1024,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1025,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":1026,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1027,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1028,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1029,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1030,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1031,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1032,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1033,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":1034,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1035,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1036,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1037,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1038,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1039,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1040,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1041,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":1042,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1043,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1044,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1045,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1046,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1047,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.duration+contained\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":1048,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1049,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":1050,\"textContent\":\"Which shift(s) under 7 hours long starts before B starts, and ends after X ends?\"}]},{\"nodeType\":3,\"id\":1051,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1052,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":1053,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1054,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1055,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1056,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1057,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1058,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":1059,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1060,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1061,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1062,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1063,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1064,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1065,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1066,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":1067,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1068,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1069,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1070,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1071,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1072,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1073,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1074,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":1075,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1076,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1077,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1078,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1079,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1080,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1081,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1082,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":1083,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1084,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1085,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1086,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1087,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1088,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1089,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1090,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":1091,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1092,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1093,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1094,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1095,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1096,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1097,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1098,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":1099,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1100,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1101,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1102,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1103,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1104,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1105,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1106,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":1107,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1108,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1109,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1110,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1111,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1112,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1113,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1114,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":1115,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1116,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1117,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1118,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1119,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1120,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1121,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1122,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":1123,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1124,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1125,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1126,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1127,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1128,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1129,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1130,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":1131,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1132,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1133,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1134,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1135,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1136,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1137,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1138,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":1139,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1140,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1141,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1142,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1143,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1144,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1145,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1146,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":1147,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1148,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1149,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1150,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1151,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1152,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1153,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1154,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":1155,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1156,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1157,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1158,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1159,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1160,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1161,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1162,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":1163,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1164,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1165,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1166,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1167,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1168,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1169,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1170,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":1171,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1172,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1173,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1174,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1175,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1176,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1177,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1178,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":1179,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1180,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1181,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1182,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1183,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1184,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1185,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1186,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":1187,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1188,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1189,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1190,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1191,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1192,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1193,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1194,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":1195,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1196,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1197,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1198,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1199,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1200,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.starttime+before+endtime+during\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":1201,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1202,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":1203,\"textContent\":\"Which shift(s) begins before J begins and ends during B?\"}]},{\"nodeType\":3,\"id\":1204,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1205,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":1206,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1207,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1208,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1209,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1210,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1211,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":1212,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1213,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1214,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1215,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1216,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1217,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1218,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1219,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":1220,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1221,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1222,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1223,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1224,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1225,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1226,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1227,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":1228,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1229,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1230,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1231,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1232,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1233,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1234,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1235,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":1236,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1237,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1238,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1239,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1240,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1241,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1242,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1243,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":1244,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1245,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1246,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1247,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1248,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1249,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1250,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1251,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":1252,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1253,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1254,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1255,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1256,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1257,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1258,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1259,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":1260,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1261,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1262,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1263,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1264,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1265,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1266,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1267,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":1268,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1269,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1270,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1271,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1272,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1273,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1274,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1275,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":1276,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1277,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1278,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1279,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1280,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1281,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1282,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1283,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":1284,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1285,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1286,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1287,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1288,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1289,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1290,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1291,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":1292,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1293,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1294,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1295,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1296,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1297,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1298,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1299,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":1300,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1301,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1302,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1303,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1304,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1305,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1306,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1307,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":1308,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1309,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1310,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1311,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1312,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1313,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1314,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1315,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":1316,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1317,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1318,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1319,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1320,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1321,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1322,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1323,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":1324,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1325,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1326,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1327,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1328,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1329,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1330,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1331,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":1332,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1333,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1334,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1335,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1336,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1337,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1338,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1339,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":1340,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1341,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1342,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1343,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1344,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1345,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1346,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1347,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":1348,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1349,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1350,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1351,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1352,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1353,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.ends\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":1354,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1355,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":1356,\"textContent\":\"Which shift(s) end at the same time as F?\"}]},{\"nodeType\":3,\"id\":1357,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1358,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":1359,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1360,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1361,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1362,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1363,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1364,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":1365,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1366,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1367,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1368,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1369,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1370,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1371,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1372,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":1373,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1374,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1375,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1376,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1377,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1378,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1379,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1380,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":1381,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1382,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1383,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1384,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1385,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1386,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1387,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1388,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":1389,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1390,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1391,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1392,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1393,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1394,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1395,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1396,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":1397,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1398,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1399,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1400,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1401,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1402,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1403,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1404,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":1405,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1406,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1407,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1408,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1409,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1410,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1411,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1412,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":1413,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1414,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1415,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1416,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1417,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1418,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1419,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1420,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":1421,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1422,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1423,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1424,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1425,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1426,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1427,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1428,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":1429,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1430,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1431,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1432,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1433,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1434,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1435,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1436,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":1437,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1438,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1439,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1440,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1441,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1442,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1443,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1444,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":1445,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1446,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1447,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1448,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1449,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1450,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1451,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1452,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":1453,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1454,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1455,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1456,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1457,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1458,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1459,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1460,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":1461,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1462,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1463,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1464,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1465,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1466,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1467,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1468,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":1469,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1470,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1471,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1472,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1473,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1474,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1475,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1476,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":1477,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1478,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1479,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1480,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1481,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1482,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1483,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1484,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":1485,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1486,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1487,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1488,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1489,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1490,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1491,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1492,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":1493,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1494,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1495,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1496,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1497,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1498,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1499,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1500,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":1501,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1502,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1503,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1504,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1505,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1506,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.starttime\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":1507,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1508,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":1509,\"textContent\":\"Which shift(s) start at 12pm?\"}]},{\"nodeType\":3,\"id\":1510,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1511,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":1512,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1513,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1514,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1515,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1516,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1517,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":1518,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1519,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1520,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1521,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1522,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1523,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1524,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1525,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":1526,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1527,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1528,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1529,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1530,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1531,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1532,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1533,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":1534,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1535,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1536,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1537,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1538,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1539,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1540,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1541,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":1542,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1543,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1544,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1545,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1546,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1547,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1548,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1549,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":1550,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1551,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1552,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1553,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1554,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1555,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1556,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1557,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":1558,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1559,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1560,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1561,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1562,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1563,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1564,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1565,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":1566,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1567,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1568,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1569,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1570,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1571,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1572,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1573,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":1574,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1575,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1576,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1577,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1578,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1579,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1580,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1581,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":1582,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1583,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1584,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1585,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1586,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1587,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1588,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1589,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":1590,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1591,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1592,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1593,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1594,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1595,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1596,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1597,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":1598,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1599,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1600,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1601,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1602,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1603,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1604,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1605,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":1606,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1607,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1608,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1609,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1610,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1611,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1612,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1613,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":1614,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1615,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1616,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1617,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1618,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1619,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1620,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1621,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":1622,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1623,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1624,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1625,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1626,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1627,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1628,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1629,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":1630,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1631,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1632,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1633,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1634,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1635,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1636,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1637,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":1638,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1639,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1640,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1641,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1642,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1643,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1644,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1645,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":1646,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1647,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1648,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1649,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1650,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1651,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1652,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1653,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":1654,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1655,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1656,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1657,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1658,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1659,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.starts\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":1660,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1661,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":1662,\"textContent\":\"Which shift(s) start at the same time as F?\"}]},{\"nodeType\":3,\"id\":1663,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1664,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":1665,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1666,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1667,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1668,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1669,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1670,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":1671,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1672,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1673,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1674,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1675,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1676,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1677,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1678,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":1679,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1680,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1681,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1682,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1683,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1684,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1685,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1686,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":1687,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1688,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1689,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1690,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1691,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1692,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1693,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1694,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":1695,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1696,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1697,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1698,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1699,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1700,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1701,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1702,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":1703,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1704,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1705,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1706,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1707,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1708,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1709,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1710,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":1711,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1712,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1713,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1714,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1715,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1716,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1717,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1718,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":1719,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1720,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1721,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1722,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1723,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1724,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1725,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1726,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":1727,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1728,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1729,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1730,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1731,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1732,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1733,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1734,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":1735,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1736,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1737,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1738,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1739,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1740,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1741,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1742,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":1743,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1744,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1745,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1746,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1747,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1748,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1749,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1750,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":1751,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1752,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1753,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1754,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1755,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1756,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1757,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1758,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":1759,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1760,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1761,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1762,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1763,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1764,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1765,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1766,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":1767,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1768,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1769,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1770,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1771,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1772,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1773,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1774,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":1775,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1776,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1777,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1778,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1779,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1780,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1781,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1782,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":1783,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1784,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1785,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1786,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1787,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1788,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1789,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1790,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":1791,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1792,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1793,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1794,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1795,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1796,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1797,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1798,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":1799,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1800,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1801,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1802,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1803,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1804,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1805,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1806,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":1807,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1808,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1809,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1810,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1811,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1812,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.meets\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":1813,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1814,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":1815,\"textContent\":\"Which 2 shifts end when Z begins?\"}]},{\"nodeType\":3,\"id\":1816,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1817,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":1818,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1819,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1820,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1821,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1822,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1823,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":1824,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1825,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1826,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1827,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1828,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1829,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1830,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1831,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":1832,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1833,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1834,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1835,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1836,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1837,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1838,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1839,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":1840,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1841,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1842,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1843,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1844,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1845,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1846,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1847,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":1848,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1849,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1850,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1851,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1852,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1853,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1854,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1855,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":1856,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1857,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1858,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1859,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1860,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1861,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1862,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1863,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":1864,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1865,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1866,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1867,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1868,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1869,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1870,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1871,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":1872,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1873,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1874,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1875,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1876,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1877,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1878,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1879,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":1880,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1881,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1882,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1883,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1884,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1885,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1886,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1887,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":1888,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1889,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1890,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1891,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1892,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1893,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1894,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1895,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":1896,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1897,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1898,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1899,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1900,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1901,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1902,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1903,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":1904,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1905,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1906,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1907,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1908,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1909,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1910,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1911,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":1912,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1913,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1914,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1915,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1916,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1917,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1918,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1919,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":1920,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1921,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1922,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1923,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1924,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1925,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1926,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1927,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":1928,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1929,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1930,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1931,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1932,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1933,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1934,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1935,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":1936,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1937,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1938,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1939,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1940,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1941,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1942,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1943,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":1944,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1945,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1946,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1947,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1948,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1949,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1950,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1951,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":1952,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1953,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1954,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1955,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1956,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1957,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1958,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1959,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":1960,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1961,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1962,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1963,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1964,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1965,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.endtime\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":1966,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1967,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":1968,\"textContent\":\"Which shift(s) end at 3pm?\"}]},{\"nodeType\":3,\"id\":1969,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1970,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":1971,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1972,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1973,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1974,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1975,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1976,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":1977,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1978,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1979,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1980,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1981,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1982,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1983,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1984,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":1985,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1986,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1987,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1988,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1989,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1990,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1991,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1992,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":1993,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1994,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1995,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1996,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1997,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1998,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1999,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2000,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":2001,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2002,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2003,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2004,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2005,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2006,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2007,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2008,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":2009,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2010,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2011,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2012,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2013,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2014,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2015,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2016,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":2017,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2018,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2019,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2020,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2021,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2022,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2023,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2024,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":2025,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2026,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2027,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2028,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2029,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2030,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2031,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2032,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":2033,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2034,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2035,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2036,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2037,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2038,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2039,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2040,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":2041,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2042,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2043,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2044,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2045,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2046,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2047,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2048,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":2049,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2050,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2051,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2052,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2053,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2054,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2055,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2056,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":2057,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2058,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2059,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2060,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2061,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2062,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2063,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2064,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":2065,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2066,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2067,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2068,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2069,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2070,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2071,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2072,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":2073,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2074,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2075,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2076,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2077,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2078,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2079,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2080,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":2081,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2082,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2083,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2084,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2085,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2086,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2087,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2088,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":2089,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2090,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2091,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2092,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2093,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2094,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2095,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2096,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":2097,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2098,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2099,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2100,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2101,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2102,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2103,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2104,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":2105,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2106,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2107,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2108,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2109,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2110,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2111,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2112,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":2113,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2114,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2115,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2116,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2117,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2118,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.midpoint\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":2119,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2120,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":2121,\"textContent\":\"Coffee breaks happen halfway through a shift. \"},{\"nodeType\":1,\"id\":2122,\"tagName\":\"BR\",\"attributes\":{}},{\"nodeType\":3,\"id\":2123,\"textContent\":\"Which shifts share a break at 2pm?\"}]},{\"nodeType\":3,\"id\":2124,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2125,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":2126,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2127,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2128,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2129,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2130,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2131,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":2132,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2133,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2134,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2135,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2136,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2137,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2138,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2139,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":2140,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2141,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2142,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2143,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2144,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2145,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2146,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2147,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":2148,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2149,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2150,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2151,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2152,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2153,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2154,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2155,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":2156,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2157,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2158,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2159,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2160,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2161,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2162,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2163,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":2164,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2165,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2166,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2167,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2168,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2169,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2170,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2171,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":2172,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2173,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2174,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2175,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2176,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2177,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2178,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2179,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":2180,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2181,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2182,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2183,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2184,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2185,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2186,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2187,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":2188,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2189,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2190,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2191,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2192,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2193,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2194,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2195,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":2196,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2197,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2198,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2199,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2200,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2201,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2202,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2203,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":2204,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2205,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2206,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2207,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2208,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2209,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2210,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2211,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":2212,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2213,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2214,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2215,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2216,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2217,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2218,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2219,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":2220,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2221,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2222,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2223,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2224,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2225,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2226,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2227,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":2228,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2229,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2230,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2231,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2232,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2233,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2234,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2235,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":2236,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2237,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2238,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2239,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2240,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2241,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2242,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2243,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":2244,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2245,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2246,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2247,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2248,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2249,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2250,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2251,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":2252,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2253,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2254,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2255,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2256,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2257,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2258,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2259,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":2260,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2261,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2262,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2263,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2264,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2265,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2266,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2267,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":2268,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2269,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2270,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2271,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2272,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2273,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\".strategy\",\"style\":\"display: block;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2274,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2275,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":2276,\"textContent\":\"Please describe how to determine what event(s) start at 12pm?\"}]},{\"nodeType\":3,\"id\":2277,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2278,\"tagName\":\"TEXTAREA\",\"attributes\":{\"id\":\"strategyAnswer\",\"rows\":\"5\",\"cols\":\"80\"}},{\"nodeType\":3,\"id\":2279,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2280,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2281,\"textContent\":\" \"},{\"nodeType\":8,\"id\":2282},{\"nodeType\":3,\"id\":2283,\"textContent\":\" \"},{\"nodeType\":8,\"id\":2284},{\"nodeType\":3,\"id\":2285,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2286,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"fixbottom\"},\"childNodes\":[{\"nodeType\":3,\"id\":2287,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2288,\"tagName\":\"BUTTON\",\"attributes\":{\"type\":\"button\",\"id\":\"testingButton\",\"style\":\"display:none;\",\"class\":\"btn\"},\"childNodes\":[{\"nodeType\":3,\"id\":2289,\"textContent\":\"SUBMIT\"}]},{\"nodeType\":3,\"id\":2290,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2291,\"tagName\":\"BUTTON\",\"attributes\":{\"type\":\"button\",\"id\":\"strategyButton\",\"style\":\"display: block;\",\"class\":\"btn\"},\"childNodes\":[{\"nodeType\":3,\"id\":2292,\"textContent\":\"SUBMIT\"}]},{\"nodeType\":3,\"id\":2293,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2294,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2295,\"textContent\":\" \"},{\"nodeType\":8,\"id\":2296},{\"nodeType\":3,\"id\":2297,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2298,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"d3container\"},\"childNodes\":[{\"nodeType\":1,\"id\":2299,\"tagName\":\"svg\",\"attributes\":{\"width\":\"930\",\"height\":\"915\"},\"childNodes\":[{\"nodeType\":1,\"id\":2300,\"tagName\":\"g\",\"attributes\":{\"transform\":\"translate(100,25)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2301,\"tagName\":\"g\",\"attributes\":{\"class\":\"leaders\"}},{\"nodeType\":1,\"id\":2302,\"tagName\":\"g\",\"attributes\":{\"class\":\"static-scaffold\"}},{\"nodeType\":1,\"id\":2303,\"tagName\":\"g\",\"attributes\":{\"class\":\"xaxis\",\"transform\":\"translate(0,800)\",\"fill\":\"none\",\"font-size\":\"10\",\"font-family\":\"sans-serif\",\"text-anchor\":\"middle\"},\"childNodes\":[{\"nodeType\":1,\"id\":2304,\"tagName\":\"path\",\"attributes\":{\"class\":\"domain\",\"stroke\":\"#000\",\"d\":\"M0.5,6V0.5H800.5V6\"}},{\"nodeType\":1,\"id\":2305,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0.5,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2306,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2307,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2308,\"textContent\":\"08 AM\"}]}]},{\"nodeType\":1,\"id\":2309,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(33.83333333333333,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2310,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2311,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2312,\"textContent\":\"08:30\"}]}]},{\"nodeType\":1,\"id\":2313,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(67.16666666666666,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2314,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2315,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2316,\"textContent\":\"09 AM\"}]}]},{\"nodeType\":1,\"id\":2317,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(100.5,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2318,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2319,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2320,\"textContent\":\"09:30\"}]}]},{\"nodeType\":1,\"id\":2321,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(133.83333333333331,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2322,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2323,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2324,\"textContent\":\"10 AM\"}]}]},{\"nodeType\":1,\"id\":2325,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(167.16666666666669,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2326,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2327,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2328,\"textContent\":\"10:30\"}]}]},{\"nodeType\":1,\"id\":2329,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(200.5,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2330,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2331,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2332,\"textContent\":\"11 AM\"}]}]},{\"nodeType\":1,\"id\":2333,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(233.83333333333334,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2334,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2335,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2336,\"textContent\":\"11:30\"}]}]},{\"nodeType\":1,\"id\":2337,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(267.16666666666663,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2338,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2339,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2340,\"textContent\":\"12 PM\"}]}]},{\"nodeType\":1,\"id\":2341,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(300.5,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2342,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2343,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2344,\"textContent\":\"12:30\"}]}]},{\"nodeType\":1,\"id\":2345,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(333.83333333333337,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2346,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2347,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2348,\"textContent\":\"01 PM\"}]}]},{\"nodeType\":1,\"id\":2349,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(367.16666666666663,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2350,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2351,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2352,\"textContent\":\"01:30\"}]}]},{\"nodeType\":1,\"id\":2353,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(400.5,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2354,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2355,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2356,\"textContent\":\"02 PM\"}]}]},{\"nodeType\":1,\"id\":2357,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(433.8333333333333,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2358,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2359,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2360,\"textContent\":\"02:30\"}]}]},{\"nodeType\":1,\"id\":2361,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(467.1666666666667,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2362,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2363,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2364,\"textContent\":\"03 PM\"}]}]},{\"nodeType\":1,\"id\":2365,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(500.5,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2366,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2367,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2368,\"textContent\":\"03:30\"}]}]},{\"nodeType\":1,\"id\":2369,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(533.8333333333333,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2370,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2371,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2372,\"textContent\":\"04 PM\"}]}]},{\"nodeType\":1,\"id\":2373,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(567.1666666666667,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2374,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2375,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2376,\"textContent\":\"04:30\"}]}]},{\"nodeType\":1,\"id\":2377,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(600.5,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2378,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2379,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2380,\"textContent\":\"05 PM\"}]}]},{\"nodeType\":1,\"id\":2381,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(633.8333333333333,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2382,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2383,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2384,\"textContent\":\"05:30\"}]}]},{\"nodeType\":1,\"id\":2385,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(667.1666666666667,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2386,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2387,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2388,\"textContent\":\"06 PM\"}]}]},{\"nodeType\":1,\"id\":2389,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(700.5,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2390,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2391,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2392,\"textContent\":\"06:30\"}]}]},{\"nodeType\":1,\"id\":2393,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(733.8333333333333,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2394,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2395,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2396,\"textContent\":\"07 PM\"}]}]},{\"nodeType\":1,\"id\":2397,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(767.1666666666667,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2398,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2399,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2400,\"textContent\":\"07:30\"}]}]},{\"nodeType\":1,\"id\":2401,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(800.5,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2402,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2403,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2404,\"textContent\":\"08 PM\"}]}]},{\"nodeType\":1,\"id\":2405,\"tagName\":\"g\",\"attributes\":{\"class\":\"axisTitle\"},\"childNodes\":[{\"nodeType\":1,\"id\":2406,\"tagName\":\"text\",\"attributes\":{\"x\":\"533.3333333333334\",\"y\":\"80\",\"style\":\"text-anchor: end;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2407,\"textContent\":\"START & END TIME (time of day)\"}]}]}]},{\"nodeType\":1,\"id\":2408,\"tagName\":\"g\",\"attributes\":{\"class\":\"yaxis\",\"fill\":\"none\",\"font-size\":\"10\",\"font-family\":\"sans-serif\",\"text-anchor\":\"end\"},\"childNodes\":[{\"nodeType\":1,\"id\":2409,\"tagName\":\"path\",\"attributes\":{\"class\":\"domain\",\"stroke\":\"#000\",\"d\":\"M-15,800.5H0.5V0.5H-15\"}},{\"nodeType\":1,\"id\":2410,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,800.5)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2411,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2412,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2413,\"textContent\":\"0\"}]}]},{\"nodeType\":1,\"id\":2414,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,733.8333333333334)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2415,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2416,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2417,\"textContent\":\"1\"}]}]},{\"nodeType\":1,\"id\":2418,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,667.1666666666667)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2419,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2420,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2421,\"textContent\":\"2\"}]}]},{\"nodeType\":1,\"id\":2422,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,600.5)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2423,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2424,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2425,\"textContent\":\"3\"}]}]},{\"nodeType\":1,\"id\":2426,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,533.8333333333334)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2427,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2428,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2429,\"textContent\":\"4\"}]}]},{\"nodeType\":1,\"id\":2430,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,467.16666666666663)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2431,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2432,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2433,\"textContent\":\"5\"}]}]},{\"nodeType\":1,\"id\":2434,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,400.5)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2435,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2436,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2437,\"textContent\":\"6\"}]}]},{\"nodeType\":1,\"id\":2438,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,333.8333333333333)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2439,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2440,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2441,\"textContent\":\"7\"}]}]},{\"nodeType\":1,\"id\":2442,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,267.16666666666674)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2443,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2444,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2445,\"textContent\":\"8\"}]}]},{\"nodeType\":1,\"id\":2446,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,200.5)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2447,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2448,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2449,\"textContent\":\"9\"}]}]},{\"nodeType\":1,\"id\":2450,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,133.83333333333326)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2451,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2452,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2453,\"textContent\":\"10\"}]}]},{\"nodeType\":1,\"id\":2454,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,67.16666666666674)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2455,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2456,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2457,\"textContent\":\"11\"}]}]},{\"nodeType\":1,\"id\":2458,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,0.5)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2459,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2460,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2461,\"textContent\":\"12\"}]}]},{\"nodeType\":1,\"id\":2462,\"tagName\":\"g\",\"attributes\":{\"class\":\"axisTitle\"},\"childNodes\":[{\"nodeType\":1,\"id\":2463,\"tagName\":\"text\",\"attributes\":{\"transform\":\"rotate(-90)\",\"x\":\"-350\",\"y\":\"-60\",\"style\":\"text-anchor: end;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2464,\"textContent\":\"DURATION (in hours)\"}]}]}]},{\"nodeType\":1,\"id\":2465,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2466,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2467,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"733.3333333333334\",\"y2\":\"733.3333333333334\"}}]},{\"nodeType\":1,\"id\":2468,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2469,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"666.6666666666667\",\"y2\":\"666.6666666666667\"}}]},{\"nodeType\":1,\"id\":2470,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2471,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"600\",\"y2\":\"600\"}}]},{\"nodeType\":1,\"id\":2472,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2473,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"533.3333333333334\",\"y2\":\"533.3333333333334\"}}]},{\"nodeType\":1,\"id\":2474,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2475,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"466.66666666666663\",\"y2\":\"466.66666666666663\"}}]},{\"nodeType\":1,\"id\":2476,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2477,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"400\",\"y2\":\"400\"}}]},{\"nodeType\":1,\"id\":2478,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2479,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"333.3333333333333\",\"y2\":\"333.3333333333333\"}}]},{\"nodeType\":1,\"id\":2480,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2481,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"266.66666666666674\",\"y2\":\"266.66666666666674\"}}]},{\"nodeType\":1,\"id\":2482,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2483,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"200\",\"y2\":\"200\"}}]},{\"nodeType\":1,\"id\":2484,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2485,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"133.33333333333326\",\"y2\":\"133.33333333333326\"}}]},{\"nodeType\":1,\"id\":2486,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2487,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"66.66666666666674\",\"y2\":\"66.66666666666674\"}}]},{\"nodeType\":1,\"id\":2488,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2489,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"0\",\"y2\":\"0\"}}]}]},{\"nodeType\":1,\"id\":2490,\"tagName\":\"g\",\"attributes\":{\"class\":\"xgrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2491,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"0\",\"y1\":\"800\",\"x2\":\"400\",\"y2\":\"0\"}},{\"nodeType\":1,\"id\":2492,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"800\",\"y1\":\"800\",\"x2\":\"400\",\"y2\":\"0\"}},{\"nodeType\":1,\"id\":2493,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"66.66666666666666\",\"y1\":\"800\",\"x2\":\"433.3333333333333\",\"y2\":\"66.66666666666674\"}},{\"nodeType\":1,\"id\":2494,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"733.3333333333333\",\"y1\":\"800\",\"x2\":\"366.66666666666663\",\"y2\":\"66.66666666666674\"}},{\"nodeType\":1,\"id\":2495,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"133.33333333333331\",\"y1\":\"800\",\"x2\":\"466.6666666666667\",\"y2\":\"133.33333333333326\"}},{\"nodeType\":1,\"id\":2496,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"666.6666666666667\",\"y1\":\"800\",\"x2\":\"333.33333333333337\",\"y2\":\"133.33333333333326\"}},{\"nodeType\":1,\"id\":2497,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"200\",\"y1\":\"800\",\"x2\":\"500\",\"y2\":\"200\"}},{\"nodeType\":1,\"id\":2498,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"600\",\"y1\":\"800\",\"x2\":\"300\",\"y2\":\"200\"}},{\"nodeType\":1,\"id\":2499,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"266.66666666666663\",\"y1\":\"800\",\"x2\":\"533.3333333333333\",\"y2\":\"266.66666666666674\"}},{\"nodeType\":1,\"id\":2500,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"533.3333333333333\",\"y1\":\"800\",\"x2\":\"266.66666666666663\",\"y2\":\"266.66666666666674\"}},{\"nodeType\":1,\"id\":2501,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"333.33333333333337\",\"y1\":\"800\",\"x2\":\"566.6666666666667\",\"y2\":\"333.3333333333333\"}},{\"nodeType\":1,\"id\":2502,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"466.6666666666667\",\"y1\":\"800\",\"x2\":\"233.33333333333334\",\"y2\":\"333.3333333333333\"}},{\"nodeType\":1,\"id\":2503,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"400\",\"y1\":\"800\",\"x2\":\"600\",\"y2\":\"400\"}},{\"nodeType\":1,\"id\":2504,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"400\",\"y1\":\"800\",\"x2\":\"200\",\"y2\":\"400\"}},{\"nodeType\":1,\"id\":2505,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"466.6666666666667\",\"y1\":\"800\",\"x2\":\"633.3333333333333\",\"y2\":\"466.66666666666663\"}},{\"nodeType\":1,\"id\":2506,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"333.33333333333337\",\"y1\":\"800\",\"x2\":\"166.66666666666669\",\"y2\":\"466.66666666666663\"}},{\"nodeType\":1,\"id\":2507,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"533.3333333333333\",\"y1\":\"800\",\"x2\":\"666.6666666666667\",\"y2\":\"533.3333333333334\"}},{\"nodeType\":1,\"id\":2508,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"266.66666666666663\",\"y1\":\"800\",\"x2\":\"133.33333333333331\",\"y2\":\"533.3333333333334\"}},{\"nodeType\":1,\"id\":2509,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"600\",\"y1\":\"800\",\"x2\":\"700\",\"y2\":\"600\"}},{\"nodeType\":1,\"id\":2510,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"200\",\"y1\":\"800\",\"x2\":\"100\",\"y2\":\"600\"}},{\"nodeType\":1,\"id\":2511,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"666.6666666666667\",\"y1\":\"800\",\"x2\":\"733.3333333333333\",\"y2\":\"666.6666666666667\"}},{\"nodeType\":1,\"id\":2512,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"133.33333333333331\",\"y1\":\"800\",\"x2\":\"66.66666666666666\",\"y2\":\"666.6666666666667\"}},{\"nodeType\":1,\"id\":2513,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"733.3333333333333\",\"y1\":\"800\",\"x2\":\"766.6666666666667\",\"y2\":\"733.3333333333334\"}},{\"nodeType\":1,\"id\":2514,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"66.66666666666666\",\"y1\":\"800\",\"x2\":\"33.33333333333333\",\"y2\":\"733.3333333333334\"}}]},{\"nodeType\":1,\"id\":2515,\"tagName\":\"g\",\"attributes\":{\"class\":\"data\"},\"childNodes\":[{\"nodeType\":1,\"id\":2516,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2517,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"333.33333333333337\",\"cy\":\"266.66666666666674\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2518,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"328.33333333333337\",\"y\":\"258.66666666666674\"},\"childNodes\":[{\"nodeType\":3,\"id\":2519,\"textContent\":\"A \"}]}]},{\"nodeType\":1,\"id\":2520,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2521,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"266.66666666666663\",\"cy\":\"600\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2522,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"261.66666666666663\",\"y\":\"592\"},\"childNodes\":[{\"nodeType\":3,\"id\":2523,\"textContent\":\"B \"}]}]},{\"nodeType\":1,\"id\":2524,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2525,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"366.66666666666663\",\"cy\":\"466.66666666666663\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2526,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"361.66666666666663\",\"y\":\"458.66666666666663\"},\"childNodes\":[{\"nodeType\":3,\"id\":2527,\"textContent\":\"C \"}]}]},{\"nodeType\":1,\"id\":2528,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2529,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"666.6666666666667\",\"cy\":\"666.6666666666667\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2530,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"661.6666666666667\",\"y\":\"658.6666666666667\"},\"childNodes\":[{\"nodeType\":3,\"id\":2531,\"textContent\":\"D \"}]}]},{\"nodeType\":1,\"id\":2532,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2533,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"200\",\"cy\":\"400\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2534,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"195\",\"y\":\"392\"},\"childNodes\":[{\"nodeType\":3,\"id\":2535,\"textContent\":\"E \"}]}]},{\"nodeType\":1,\"id\":2536,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2537,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"266.66666666666663\",\"cy\":\"533.3333333333334\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2538,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"261.66666666666663\",\"y\":\"525.3333333333334\"},\"childNodes\":[{\"nodeType\":3,\"id\":2539,\"textContent\":\"F \"}]}]},{\"nodeType\":1,\"id\":2540,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2541,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"333.33333333333337\",\"cy\":\"400\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2542,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"328.33333333333337\",\"y\":\"392\"},\"childNodes\":[{\"nodeType\":3,\"id\":2543,\"textContent\":\"G \"}]}]},{\"nodeType\":1,\"id\":2544,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2545,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"500\",\"cy\":\"466.66666666666663\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2546,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"495\",\"y\":\"458.66666666666663\"},\"childNodes\":[{\"nodeType\":3,\"id\":2547,\"textContent\":\"H \"}]}]},{\"nodeType\":1,\"id\":2548,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2549,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"100\",\"cy\":\"600\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2550,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"95\",\"y\":\"592\"},\"childNodes\":[{\"nodeType\":3,\"id\":2551,\"textContent\":\"I \"}]}]},{\"nodeType\":1,\"id\":2552,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2553,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"133.33333333333331\",\"cy\":\"666.6666666666667\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2554,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"128.33333333333331\",\"y\":\"658.6666666666667\"},\"childNodes\":[{\"nodeType\":3,\"id\":2555,\"textContent\":\"J \"}]}]},{\"nodeType\":1,\"id\":2556,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2557,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"400\",\"cy\":\"133.33333333333326\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2558,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"395\",\"y\":\"125.33333333333326\"},\"childNodes\":[{\"nodeType\":3,\"id\":2559,\"textContent\":\"K \"}]}]},{\"nodeType\":1,\"id\":2560,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2561,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"500\",\"cy\":\"333.3333333333333\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2562,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"495\",\"y\":\"325.3333333333333\"},\"childNodes\":[{\"nodeType\":3,\"id\":2563,\"textContent\":\"L \"}]}]},{\"nodeType\":1,\"id\":2564,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2565,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"300\",\"cy\":\"733.3333333333334\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2566,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"295\",\"y\":\"725.3333333333334\"},\"childNodes\":[{\"nodeType\":3,\"id\":2567,\"textContent\":\"M \"}]}]},{\"nodeType\":1,\"id\":2568,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2569,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"600\",\"cy\":\"666.6666666666667\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2570,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"595\",\"y\":\"658.6666666666667\"},\"childNodes\":[{\"nodeType\":3,\"id\":2571,\"textContent\":\"N \"}]}]},{\"nodeType\":1,\"id\":2572,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2573,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"433.3333333333333\",\"cy\":\"600\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2574,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"428.3333333333333\",\"y\":\"592\"},\"childNodes\":[{\"nodeType\":3,\"id\":2575,\"textContent\":\"O \"}]}]},{\"nodeType\":1,\"id\":2576,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2577,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"500\",\"cy\":\"200\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2578,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"495\",\"y\":\"192\"},\"childNodes\":[{\"nodeType\":3,\"id\":2579,\"textContent\":\"P \"}]}]},{\"nodeType\":1,\"id\":2580,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2581,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"533.3333333333333\",\"cy\":\"533.3333333333334\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2582,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"528.3333333333333\",\"y\":\"525.3333333333334\"},\"childNodes\":[{\"nodeType\":3,\"id\":2583,\"textContent\":\"Z \"}]}]},{\"nodeType\":1,\"id\":2584,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2585,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"400\",\"cy\":\"666.6666666666667\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2586,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"395\",\"y\":\"658.6666666666667\"},\"childNodes\":[{\"nodeType\":3,\"id\":2587,\"textContent\":\"X \"}]}]}]}]}]}]},{\"nodeType\":3,\"id\":2588,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2589,\"textContent\":\" \"},{\"nodeType\":8,\"id\":2590},{\"nodeType\":3,\"id\":2591,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2592,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":2593,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2594,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":2595,\"textContent\":\" \"}]}]}]]}",
  "useCssProxy": true,
  "loadTimes": "es: 230, dom: 980, initialDom: 1042",
  "javascriptErrors": []
}