var MF = MF || {};MF.RecordingData = MF.RecordingData || {};MF.RecordingData["05213044b6a18147154496088ead1e54ef1e47e8"] = {
  "startTime": "2018-05-21T19:07:30.0618408Z",
  "websitePageUrl": "/",
  "visitTime": 202057,
  "engagementTime": 69848,
  "pageTitle": "FOX2YP",
  "url": "https://warm-citadel-75324.herokuapp.com/",
  "viewportWidth": 929,
  "viewportHeight": 1047,
  "tags": [
    "form-interact"
  ],
  "session": {
    "id": "5ba2b70d2798cae63729425ed8c60e4b",
    "created": "2018-05-21T19:07:30.0618408+00:00",
    "lastActivity": "0001-01-01T00:00:00+00:00",
    "pages": 1,
    "duration": 0,
    "engagementTime": 0,
    "totalFriction": 0,
    "country": "us",
    "region": "CA",
    "city": "La Jolla",
    "isp": "University of California, San Diego",
    "ip": "###.###.###.###",
    "lang": "en-US",
    "userAgent": "Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/66.0.3359.181 Safari/537.36",
    "browser": "Chrome",
    "browserVersion": "66.0.3359.181",
    "os": "Windows",
    "osVersion": "7",
    "device": "Desktop",
    "referrer": "",
    "referrerType": "",
    "screenRes": "1920x1200",
    "entryPage": "/",
    "tags": [
      "form-interact"
    ],
    "variables": [],
    "watched": false,
    "starred": false,
    "lng": 32.8807,
    "lat": 32.8807,
    "visitorId": "59825d75b58471e2cfb5b3683abbac21",
    "gdpr": false,
    "visitorName": null,
    "playbackUrl": "https://us.mouseflow.com/websites/e0c9ff05-6fcb-4c4a-8173-e5a0724987b1/recordings/5ba2b70d2798cae63729425ed8c60e4b/play"
  },
  "events": [
    {
      "t": 102,
      "e": 102,
      "ty": 0,
      "x": 929,
      "y": 1047
    },
    {
      "t": 197,
      "e": 197,
      "ty": 14,
      "x": 0,
      "y": 1046
    },
    {
      "t": 3301,
      "e": 3301,
      "ty": 0,
      "x": 1920,
      "y": 1094
    },
    {
      "t": 3301,
      "e": 3301,
      "ty": 2,
      "x": 1307,
      "y": 30
    },
    {
      "t": 3502,
      "e": 3502,
      "ty": 41,
      "x": 44734,
      "y": 1338,
      "ta": "html > body"
    },
    {
      "t": 3601,
      "e": 3601,
      "ty": 2,
      "x": 1306,
      "y": 31
    },
    {
      "t": 3701,
      "e": 3701,
      "ty": 2,
      "x": 1200,
      "y": 82
    },
    {
      "t": 3752,
      "e": 3752,
      "ty": 41,
      "x": 33887,
      "y": 368,
      "ta": "#jspsych-single-stim-stimulus"
    },
    {
      "t": 3801,
      "e": 3801,
      "ty": 2,
      "x": 629,
      "y": 247
    },
    {
      "t": 3901,
      "e": 3901,
      "ty": 2,
      "x": 83,
      "y": 404
    },
    {
      "t": 4001,
      "e": 4001,
      "ty": 2,
      "x": 78,
      "y": 427
    },
    {
      "t": 4002,
      "e": 4002,
      "ty": 41,
      "x": 2410,
      "y": 25495,
      "ta": "html > body"
    },
    {
      "t": 4102,
      "e": 4102,
      "ty": 2,
      "x": 226,
      "y": 567
    },
    {
      "t": 4201,
      "e": 4201,
      "ty": 2,
      "x": 325,
      "y": 607
    },
    {
      "t": 4251,
      "e": 4251,
      "ty": 41,
      "x": 10916,
      "y": 36448,
      "ta": "html > body"
    },
    {
      "t": 4301,
      "e": 4301,
      "ty": 2,
      "x": 326,
      "y": 608
    },
    {
      "t": 4501,
      "e": 4501,
      "ty": 41,
      "x": 10951,
      "y": 36509,
      "ta": "html > body"
    },
    {
      "t": 10002,
      "e": 9501,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 22601,
      "e": 9501,
      "ty": 0,
      "x": 1920,
      "y": 1200
    },
    {
      "t": 22601,
      "e": 9501,
      "ty": 2,
      "x": 326,
      "y": 674
    },
    {
      "t": 22751,
      "e": 9651,
      "ty": 41,
      "x": 10951,
      "y": 36894,
      "ta": "html > body"
    },
    {
      "t": 30001,
      "e": 14651,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 146810,
      "e": 14651,
      "ty": 2,
      "x": 409,
      "y": 662
    },
    {
      "t": 146909,
      "e": 14750,
      "ty": 2,
      "x": 647,
      "y": 642
    },
    {
      "t": 147009,
      "e": 14850,
      "ty": 2,
      "x": 844,
      "y": 617
    },
    {
      "t": 147009,
      "e": 14850,
      "ty": 41,
      "x": 27085,
      "y": 55656,
      "ta": "> div.masterdiv > div:[2] > div > p:[2]"
    },
    {
      "t": 147109,
      "e": 14950,
      "ty": 2,
      "x": 846,
      "y": 664
    },
    {
      "t": 147209,
      "e": 15050,
      "ty": 2,
      "x": 887,
      "y": 812
    },
    {
      "t": 147260,
      "e": 15101,
      "ty": 41,
      "x": 30676,
      "y": 19912,
      "ta": "> div.masterdiv > div:[2] > div > p:[4]"
    },
    {
      "t": 147310,
      "e": 15151,
      "ty": 2,
      "x": 919,
      "y": 880
    },
    {
      "t": 147409,
      "e": 15250,
      "ty": 2,
      "x": 911,
      "y": 929
    },
    {
      "t": 147509,
      "e": 15350,
      "ty": 2,
      "x": 883,
      "y": 943
    },
    {
      "t": 147510,
      "e": 15351,
      "ty": 41,
      "x": 29003,
      "y": 56554,
      "ta": "> div.masterdiv > div:[2]"
    },
    {
      "t": 147610,
      "e": 15451,
      "ty": 2,
      "x": 846,
      "y": 943
    },
    {
      "t": 147710,
      "e": 15551,
      "ty": 2,
      "x": 842,
      "y": 943
    },
    {
      "t": 147760,
      "e": 15601,
      "ty": 41,
      "x": 26544,
      "y": 56485,
      "ta": "> div.masterdiv > div:[2]"
    },
    {
      "t": 147810,
      "e": 15651,
      "ty": 2,
      "x": 827,
      "y": 937
    },
    {
      "t": 147909,
      "e": 15750,
      "ty": 2,
      "x": 817,
      "y": 926
    },
    {
      "t": 148009,
      "e": 15850,
      "ty": 2,
      "x": 815,
      "y": 925
    },
    {
      "t": 148009,
      "e": 15850,
      "ty": 41,
      "x": 37887,
      "y": 45925,
      "ta": "> div.masterdiv > div:[2] > div > div > label > div"
    },
    {
      "t": 148024,
      "e": 15865,
      "ty": 3,
      "x": 815,
      "y": 925,
      "ta": "> div.masterdiv > div:[2] > div > div > label > div"
    },
    {
      "t": 148110,
      "e": 15951,
      "ty": 2,
      "x": 814,
      "y": 925
    },
    {
      "t": 148121,
      "e": 15962,
      "ty": 4,
      "x": 34610,
      "y": 45925,
      "ta": "> div.masterdiv > div:[2] > div > div > label > div"
    },
    {
      "t": 148121,
      "e": 15962,
      "ty": 5,
      "x": 814,
      "y": 925,
      "ta": "> div.masterdiv > div:[2] > div > div > label > div"
    },
    {
      "t": 148121,
      "e": 15962,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#consent_checkbox"
    },
    {
      "t": 148124,
      "e": 15965,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#consent_checkbox",
      "v": "on"
    },
    {
      "t": 148259,
      "e": 16100,
      "ty": 41,
      "x": 26937,
      "y": 57454,
      "ta": "> div.masterdiv > div:[2]"
    },
    {
      "t": 148310,
      "e": 16151,
      "ty": 2,
      "x": 889,
      "y": 1001
    },
    {
      "t": 148409,
      "e": 16250,
      "ty": 2,
      "x": 912,
      "y": 1030
    },
    {
      "t": 148509,
      "e": 16350,
      "ty": 2,
      "x": 913,
      "y": 1043
    },
    {
      "t": 148510,
      "e": 16351,
      "ty": 41,
      "x": 30479,
      "y": 63479,
      "ta": "> div.masterdiv > div:[2]"
    },
    {
      "t": 148609,
      "e": 16450,
      "ty": 2,
      "x": 915,
      "y": 1051
    },
    {
      "t": 148710,
      "e": 16551,
      "ty": 2,
      "x": 941,
      "y": 1082
    },
    {
      "t": 148760,
      "e": 16601,
      "ty": 41,
      "x": 28125,
      "y": 50717,
      "ta": "#start"
    },
    {
      "t": 148809,
      "e": 16650,
      "ty": 2,
      "x": 970,
      "y": 1107
    },
    {
      "t": 148909,
      "e": 16750,
      "ty": 2,
      "x": 971,
      "y": 1108
    },
    {
      "t": 149010,
      "e": 16851,
      "ty": 2,
      "x": 973,
      "y": 1103
    },
    {
      "t": 149010,
      "e": 16851,
      "ty": 41,
      "x": 34678,
      "y": 58427,
      "ta": "#start"
    },
    {
      "t": 149109,
      "e": 16950,
      "ty": 2,
      "x": 974,
      "y": 1096
    },
    {
      "t": 149210,
      "e": 17051,
      "ty": 2,
      "x": 974,
      "y": 1091
    },
    {
      "t": 149260,
      "e": 17101,
      "ty": 41,
      "x": 35225,
      "y": 35297,
      "ta": "#start"
    },
    {
      "t": 149441,
      "e": 17282,
      "ty": 3,
      "x": 974,
      "y": 1091,
      "ta": "#start"
    },
    {
      "t": 149441,
      "e": 17282,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#consent_checkbox"
    },
    {
      "t": 149441,
      "e": 17282,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#start"
    },
    {
      "t": 149576,
      "e": 17417,
      "ty": 4,
      "x": 35225,
      "y": 35297,
      "ta": "#start"
    },
    {
      "t": 149579,
      "e": 17420,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#start"
    },
    {
      "t": 149580,
      "e": 17421,
      "ty": 38,
      "x": 1,
      "y": 0
    },
    {
      "t": 149580,
      "e": 17421,
      "ty": 5,
      "x": 974,
      "y": 1091,
      "ta": "#start"
    },
    {
      "t": 149909,
      "e": 17750,
      "ty": 2,
      "x": 877,
      "y": 1079
    },
    {
      "t": 150009,
      "e": 17850,
      "ty": 2,
      "x": 623,
      "y": 985
    },
    {
      "t": 150009,
      "e": 17850,
      "ty": 41,
      "x": 21179,
      "y": 54123,
      "ta": "html > body"
    },
    {
      "t": 150109,
      "e": 17950,
      "ty": 2,
      "x": 521,
      "y": 903
    },
    {
      "t": 150208,
      "e": 18049,
      "ty": 2,
      "x": 515,
      "y": 861
    },
    {
      "t": 150260,
      "e": 18101,
      "ty": 41,
      "x": 17459,
      "y": 46090,
      "ta": "html > body"
    },
    {
      "t": 150308,
      "e": 18149,
      "ty": 2,
      "x": 514,
      "y": 824
    },
    {
      "t": 150409,
      "e": 18250,
      "ty": 2,
      "x": 489,
      "y": 752
    },
    {
      "t": 150509,
      "e": 18350,
      "ty": 2,
      "x": 450,
      "y": 682
    },
    {
      "t": 150509,
      "e": 18350,
      "ty": 41,
      "x": 15221,
      "y": 37337,
      "ta": "html > body"
    },
    {
      "t": 150586,
      "e": 18427,
      "ty": 38,
      "x": 2,
      "y": 0
    },
    {
      "t": 150610,
      "e": 18451,
      "ty": 2,
      "x": 414,
      "y": 621
    },
    {
      "t": 150709,
      "e": 18550,
      "ty": 2,
      "x": 384,
      "y": 570
    },
    {
      "t": 150759,
      "e": 18600,
      "ty": 41,
      "x": 11812,
      "y": 28418,
      "ta": "html > body"
    },
    {
      "t": 150809,
      "e": 18650,
      "ty": 2,
      "x": 314,
      "y": 474
    },
    {
      "t": 150909,
      "e": 18750,
      "ty": 2,
      "x": 300,
      "y": 454
    },
    {
      "t": 151008,
      "e": 18849,
      "ty": 2,
      "x": 298,
      "y": 453
    },
    {
      "t": 151010,
      "e": 18851,
      "ty": 41,
      "x": 9986,
      "y": 24651,
      "ta": "html > body"
    },
    {
      "t": 151109,
      "e": 18950,
      "ty": 2,
      "x": 526,
      "y": 416
    },
    {
      "t": 151209,
      "e": 19050,
      "ty": 2,
      "x": 1004,
      "y": 512
    },
    {
      "t": 151258,
      "e": 19099,
      "ty": 41,
      "x": 49313,
      "y": 1409,
      "ta": "#jspsych-survey-text-0"
    },
    {
      "t": 151309,
      "e": 19150,
      "ty": 2,
      "x": 1036,
      "y": 547
    },
    {
      "t": 151335,
      "e": 19176,
      "ty": 6,
      "x": 1021,
      "y": 588,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 151353,
      "e": 19194,
      "ty": 7,
      "x": 1011,
      "y": 612,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 151408,
      "e": 19249,
      "ty": 2,
      "x": 990,
      "y": 641
    },
    {
      "t": 151509,
      "e": 19350,
      "ty": 2,
      "x": 963,
      "y": 641
    },
    {
      "t": 151509,
      "e": 19350,
      "ty": 41,
      "x": 33524,
      "y": 18724,
      "ta": "#jspsych-survey-text-1 > p"
    },
    {
      "t": 151609,
      "e": 19450,
      "ty": 2,
      "x": 941,
      "y": 621
    },
    {
      "t": 151709,
      "e": 19550,
      "ty": 2,
      "x": 936,
      "y": 611
    },
    {
      "t": 151758,
      "e": 19599,
      "ty": 41,
      "x": 27684,
      "y": 62716,
      "ta": "#jspsych-survey-text-0"
    },
    {
      "t": 151809,
      "e": 19650,
      "ty": 2,
      "x": 936,
      "y": 610
    },
    {
      "t": 151852,
      "e": 19693,
      "ty": 6,
      "x": 933,
      "y": 605,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 151908,
      "e": 19749,
      "ty": 2,
      "x": 932,
      "y": 603
    },
    {
      "t": 152008,
      "e": 19849,
      "ty": 2,
      "x": 932,
      "y": 602
    },
    {
      "t": 152009,
      "e": 19850,
      "ty": 41,
      "x": 26819,
      "y": 49931,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 152049,
      "e": 19890,
      "ty": 3,
      "x": 932,
      "y": 602,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 152050,
      "e": 19891,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 152177,
      "e": 20018,
      "ty": 4,
      "x": 26819,
      "y": 49931,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 152177,
      "e": 20018,
      "ty": 5,
      "x": 932,
      "y": 602,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 153228,
      "e": 21069,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "16"
    },
    {
      "t": 153292,
      "e": 21133,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "67"
    },
    {
      "t": 153292,
      "e": 21133,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 153389,
      "e": 21230,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "C"
    },
    {
      "t": 153452,
      "e": 21293,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "C"
    },
    {
      "t": 153757,
      "e": 21598,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "72"
    },
    {
      "t": 153757,
      "e": 21598,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 153853,
      "e": 21694,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "Ch"
    },
    {
      "t": 153884,
      "e": 21725,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "65"
    },
    {
      "t": 153885,
      "e": 21726,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 153989,
      "e": 21830,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "Cha"
    },
    {
      "t": 154036,
      "e": 21877,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "82"
    },
    {
      "t": 154036,
      "e": 21877,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 154108,
      "e": 21949,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "76"
    },
    {
      "t": 154108,
      "e": 21949,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 154124,
      "e": 21965,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "Charl"
    },
    {
      "t": 154188,
      "e": 22029,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "+||"
    },
    {
      "t": 154308,
      "e": 22149,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "73"
    },
    {
      "t": 154308,
      "e": 22149,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 154396,
      "e": 22237,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "+||i"
    },
    {
      "t": 154596,
      "e": 22437,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "69"
    },
    {
      "t": 154597,
      "e": 22438,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 154677,
      "e": 22518,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "+||e"
    },
    {
      "t": 155608,
      "e": 23449,
      "ty": 2,
      "x": 932,
      "y": 606
    },
    {
      "t": 155622,
      "e": 23463,
      "ty": 7,
      "x": 934,
      "y": 610,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 155709,
      "e": 23550,
      "ty": 2,
      "x": 930,
      "y": 642
    },
    {
      "t": 155759,
      "e": 23600,
      "ty": 41,
      "x": 23791,
      "y": 34529,
      "ta": "#jspsych-survey-text-1"
    },
    {
      "t": 155809,
      "e": 23601,
      "ty": 2,
      "x": 909,
      "y": 675
    },
    {
      "t": 155840,
      "e": 23632,
      "ty": 6,
      "x": 904,
      "y": 679,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 155909,
      "e": 23701,
      "ty": 2,
      "x": 895,
      "y": 682
    },
    {
      "t": 156008,
      "e": 23800,
      "ty": 2,
      "x": 885,
      "y": 687
    },
    {
      "t": 156009,
      "e": 23801,
      "ty": 41,
      "x": 16654,
      "y": 24965,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 156109,
      "e": 23901,
      "ty": 2,
      "x": 877,
      "y": 689
    },
    {
      "t": 156209,
      "e": 24001,
      "ty": 2,
      "x": 876,
      "y": 689
    },
    {
      "t": 156259,
      "e": 24051,
      "ty": 41,
      "x": 14707,
      "y": 31207,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 156409,
      "e": 24201,
      "ty": 2,
      "x": 873,
      "y": 690
    },
    {
      "t": 156509,
      "e": 24301,
      "ty": 2,
      "x": 872,
      "y": 687
    },
    {
      "t": 156509,
      "e": 24301,
      "ty": 41,
      "x": 13842,
      "y": 24965,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 156713,
      "e": 24505,
      "ty": 3,
      "x": 872,
      "y": 687,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 156713,
      "e": 24505,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "Charlie"
    },
    {
      "t": 156714,
      "e": 24506,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 156714,
      "e": 24506,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 156889,
      "e": 24681,
      "ty": 4,
      "x": 13842,
      "y": 24965,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 156890,
      "e": 24682,
      "ty": 5,
      "x": 872,
      "y": 687,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 157409,
      "e": 25201,
      "ty": 2,
      "x": 858,
      "y": 689
    },
    {
      "t": 157508,
      "e": 25300,
      "ty": 2,
      "x": 842,
      "y": 697
    },
    {
      "t": 157509,
      "e": 25301,
      "ty": 41,
      "x": 7353,
      "y": 56172,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 157610,
      "e": 25402,
      "ty": 2,
      "x": 837,
      "y": 699
    },
    {
      "t": 157698,
      "e": 25490,
      "ty": 7,
      "x": 835,
      "y": 701,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 157709,
      "e": 25501,
      "ty": 2,
      "x": 835,
      "y": 701
    },
    {
      "t": 157760,
      "e": 25552,
      "ty": 41,
      "x": 5839,
      "y": 60602,
      "ta": "#jspsych-survey-text-1"
    },
    {
      "t": 157809,
      "e": 25601,
      "ty": 2,
      "x": 834,
      "y": 701
    },
    {
      "t": 157958,
      "e": 25750,
      "ty": 6,
      "x": 830,
      "y": 699,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 158009,
      "e": 25801,
      "ty": 2,
      "x": 825,
      "y": 683
    },
    {
      "t": 158009,
      "e": 25801,
      "ty": 41,
      "x": 3676,
      "y": 12482,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 158025,
      "e": 25817,
      "ty": 7,
      "x": 824,
      "y": 675,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 158109,
      "e": 25901,
      "ty": 2,
      "x": 822,
      "y": 667
    },
    {
      "t": 158209,
      "e": 26001,
      "ty": 2,
      "x": 822,
      "y": 656
    },
    {
      "t": 158259,
      "e": 26051,
      "ty": 41,
      "x": 3244,
      "y": 32767,
      "ta": "#jspsych-survey-text-1 > p"
    },
    {
      "t": 158309,
      "e": 26101,
      "ty": 2,
      "x": 825,
      "y": 644
    },
    {
      "t": 158409,
      "e": 26201,
      "ty": 2,
      "x": 827,
      "y": 633
    },
    {
      "t": 158509,
      "e": 26301,
      "ty": 2,
      "x": 827,
      "y": 621
    },
    {
      "t": 158509,
      "e": 26301,
      "ty": 41,
      "x": 4109,
      "y": 4228,
      "ta": "#jspsych-survey-text-1"
    },
    {
      "t": 158609,
      "e": 26401,
      "ty": 2,
      "x": 827,
      "y": 615
    },
    {
      "t": 158709,
      "e": 26501,
      "ty": 2,
      "x": 828,
      "y": 612
    },
    {
      "t": 158760,
      "e": 26552,
      "ty": 41,
      "x": 4325,
      "y": 62011,
      "ta": "#jspsych-survey-text-0"
    },
    {
      "t": 158808,
      "e": 26600,
      "ty": 2,
      "x": 828,
      "y": 610
    },
    {
      "t": 158909,
      "e": 26701,
      "ty": 2,
      "x": 837,
      "y": 631
    },
    {
      "t": 159008,
      "e": 26800,
      "ty": 2,
      "x": 843,
      "y": 653
    },
    {
      "t": 159009,
      "e": 26801,
      "ty": 41,
      "x": 7570,
      "y": 46810,
      "ta": "#jspsych-survey-text-1 > p"
    },
    {
      "t": 159109,
      "e": 26901,
      "ty": 2,
      "x": 847,
      "y": 661
    },
    {
      "t": 159209,
      "e": 27001,
      "ty": 2,
      "x": 850,
      "y": 672
    },
    {
      "t": 159259,
      "e": 27051,
      "ty": 41,
      "x": 9084,
      "y": 40166,
      "ta": "#jspsych-survey-text-1"
    },
    {
      "t": 159410,
      "e": 27202,
      "ty": 2,
      "x": 851,
      "y": 673
    },
    {
      "t": 159509,
      "e": 27301,
      "ty": 41,
      "x": 9300,
      "y": 40871,
      "ta": "#jspsych-survey-text-1"
    },
    {
      "t": 160609,
      "e": 28401,
      "ty": 2,
      "x": 843,
      "y": 653
    },
    {
      "t": 160659,
      "e": 28451,
      "ty": 6,
      "x": 850,
      "y": 600,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 160692,
      "e": 28484,
      "ty": 7,
      "x": 861,
      "y": 574,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 160709,
      "e": 28501,
      "ty": 2,
      "x": 861,
      "y": 574
    },
    {
      "t": 160759,
      "e": 28551,
      "ty": 41,
      "x": 12544,
      "y": 25745,
      "ta": "#jspsych-survey-text-0 > p"
    },
    {
      "t": 160809,
      "e": 28601,
      "ty": 2,
      "x": 866,
      "y": 548
    },
    {
      "t": 160909,
      "e": 28701,
      "ty": 2,
      "x": 849,
      "y": 571
    },
    {
      "t": 160943,
      "e": 28735,
      "ty": 6,
      "x": 837,
      "y": 589,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 161009,
      "e": 28801,
      "ty": 2,
      "x": 830,
      "y": 604
    },
    {
      "t": 161009,
      "e": 28801,
      "ty": 41,
      "x": 4758,
      "y": 56172,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 161109,
      "e": 28901,
      "ty": 2,
      "x": 829,
      "y": 605
    },
    {
      "t": 161256,
      "e": 29048,
      "ty": 3,
      "x": 829,
      "y": 605,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 161256,
      "e": 29048,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 161256,
      "e": 29048,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 161259,
      "e": 29051,
      "ty": 41,
      "x": 4542,
      "y": 59293,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 161360,
      "e": 29152,
      "ty": 4,
      "x": 4542,
      "y": 59293,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 161360,
      "e": 29152,
      "ty": 5,
      "x": 829,
      "y": 605,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 161440,
      "e": 29232,
      "ty": 3,
      "x": 829,
      "y": 605,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 161528,
      "e": 29320,
      "ty": 4,
      "x": 4542,
      "y": 59293,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 161528,
      "e": 29320,
      "ty": 5,
      "x": 829,
      "y": 605,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 162093,
      "e": 29885,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "20"
    },
    {
      "t": 162220,
      "e": 30012,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "+||"
    },
    {
      "t": 162805,
      "e": 30597,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "67"
    },
    {
      "t": 162805,
      "e": 30597,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 162948,
      "e": 30740,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "C"
    },
    {
      "t": 162964,
      "e": 30756,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "72"
    },
    {
      "t": 162964,
      "e": 30756,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 163060,
      "e": 30852,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "CH"
    },
    {
      "t": 163092,
      "e": 30884,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "65"
    },
    {
      "t": 163092,
      "e": 30884,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 163189,
      "e": 30981,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "CHA"
    },
    {
      "t": 163229,
      "e": 31021,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "82"
    },
    {
      "t": 163230,
      "e": 31022,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 163309,
      "e": 31101,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "CHAR"
    },
    {
      "t": 163348,
      "e": 31140,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "76"
    },
    {
      "t": 163349,
      "e": 31141,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 163404,
      "e": 31196,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "+||L"
    },
    {
      "t": 163493,
      "e": 31285,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "73"
    },
    {
      "t": 163494,
      "e": 31286,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 163581,
      "e": 31373,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "+||I"
    },
    {
      "t": 163581,
      "e": 31373,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "69"
    },
    {
      "t": 163581,
      "e": 31373,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 163661,
      "e": 31453,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "+||E"
    },
    {
      "t": 164042,
      "e": 31834,
      "ty": 7,
      "x": 829,
      "y": 607,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 164109,
      "e": 31901,
      "ty": 2,
      "x": 986,
      "y": 243
    },
    {
      "t": 164209,
      "e": 32001,
      "ty": 2,
      "x": 984,
      "y": 94
    },
    {
      "t": 164259,
      "e": 32051,
      "ty": 41,
      "x": 33852,
      "y": 4708,
      "ta": "html > body"
    },
    {
      "t": 164309,
      "e": 32101,
      "ty": 2,
      "x": 1000,
      "y": 139
    },
    {
      "t": 164409,
      "e": 32201,
      "ty": 2,
      "x": 960,
      "y": 445
    },
    {
      "t": 164446,
      "e": 32238,
      "ty": 6,
      "x": 927,
      "y": 595,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 164462,
      "e": 32254,
      "ty": 7,
      "x": 906,
      "y": 633,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 164496,
      "e": 32288,
      "ty": 6,
      "x": 866,
      "y": 690,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 164509,
      "e": 32301,
      "ty": 2,
      "x": 866,
      "y": 690
    },
    {
      "t": 164509,
      "e": 32301,
      "ty": 41,
      "x": 12544,
      "y": 34327,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 164512,
      "e": 32304,
      "ty": 7,
      "x": 855,
      "y": 701,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 164609,
      "e": 32401,
      "ty": 2,
      "x": 827,
      "y": 714
    },
    {
      "t": 164709,
      "e": 32501,
      "ty": 2,
      "x": 811,
      "y": 717
    },
    {
      "t": 164760,
      "e": 32552,
      "ty": 41,
      "x": 648,
      "y": 61306,
      "ta": "#jspsych-survey-text-1"
    },
    {
      "t": 164763,
      "e": 32555,
      "ty": 6,
      "x": 811,
      "y": 699,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 164809,
      "e": 32601,
      "ty": 2,
      "x": 812,
      "y": 694
    },
    {
      "t": 164909,
      "e": 32701,
      "ty": 2,
      "x": 815,
      "y": 688
    },
    {
      "t": 164962,
      "e": 32754,
      "ty": 3,
      "x": 815,
      "y": 688,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 164962,
      "e": 32754,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "CHARLIE"
    },
    {
      "t": 164963,
      "e": 32755,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 164964,
      "e": 32756,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 165009,
      "e": 32801,
      "ty": 41,
      "x": 1514,
      "y": 28086,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 165073,
      "e": 32865,
      "ty": 4,
      "x": 1514,
      "y": 28086,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 165073,
      "e": 32865,
      "ty": 5,
      "x": 815,
      "y": 688,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 165604,
      "e": 33396,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "49"
    },
    {
      "t": 165604,
      "e": 33396,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 165692,
      "e": 33484,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "1"
    },
    {
      "t": 165828,
      "e": 33620,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "49"
    },
    {
      "t": 165828,
      "e": 33620,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 165900,
      "e": 33692,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "11"
    },
    {
      "t": 166015,
      "e": 33807,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "11"
    },
    {
      "t": 166068,
      "e": 33860,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "49"
    },
    {
      "t": 166068,
      "e": 33860,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 166097,
      "e": 33889,
      "ty": 7,
      "x": 849,
      "y": 701,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 166109,
      "e": 33901,
      "ty": 2,
      "x": 849,
      "y": 701
    },
    {
      "t": 166141,
      "e": 33933,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "11*"
    },
    {
      "t": 166147,
      "e": 33939,
      "ty": 6,
      "x": 896,
      "y": 716,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 166210,
      "e": 34002,
      "ty": 2,
      "x": 918,
      "y": 721
    },
    {
      "t": 166259,
      "e": 34051,
      "ty": 41,
      "x": 12925,
      "y": 25816,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 166309,
      "e": 34101,
      "ty": 2,
      "x": 923,
      "y": 721
    },
    {
      "t": 166409,
      "e": 34201,
      "ty": 2,
      "x": 927,
      "y": 720
    },
    {
      "t": 166510,
      "e": 34302,
      "ty": 2,
      "x": 930,
      "y": 720
    },
    {
      "t": 166510,
      "e": 34302,
      "ty": 41,
      "x": 17563,
      "y": 23830,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 166609,
      "e": 34401,
      "ty": 2,
      "x": 932,
      "y": 720
    },
    {
      "t": 166649,
      "e": 34441,
      "ty": 3,
      "x": 932,
      "y": 720,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 166649,
      "e": 34441,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "11*"
    },
    {
      "t": 166649,
      "e": 34441,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 166649,
      "e": 34441,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 166759,
      "e": 34551,
      "ty": 41,
      "x": 18594,
      "y": 23830,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 166817,
      "e": 34609,
      "ty": 4,
      "x": 18594,
      "y": 23830,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 166817,
      "e": 34609,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 166818,
      "e": 34609,
      "ty": 5,
      "x": 932,
      "y": 720,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 166819,
      "e": 34610,
      "ty": 38,
      "x": 3,
      "y": 0
    },
    {
      "t": 167900,
      "e": 35691,
      "ty": 38,
      "x": 4,
      "y": 0
    },
    {
      "t": 167928,
      "e": 35719,
      "ty": 6,
      "x": 932,
      "y": 720,
      "ta": "> div.masterdiv > div:[2] > div > ul > li:[2]"
    },
    {
      "t": 169609,
      "e": 37400,
      "ty": 2,
      "x": 933,
      "y": 723
    },
    {
      "t": 169633,
      "e": 37424,
      "ty": 7,
      "x": 933,
      "y": 740,
      "ta": "> div.masterdiv > div:[2] > div > ul > li:[2]"
    },
    {
      "t": 169633,
      "e": 37424,
      "ty": 6,
      "x": 933,
      "y": 740,
      "ta": "> div.masterdiv > div:[2] > div > ul > li:[3]"
    },
    {
      "t": 169649,
      "e": 37440,
      "ty": 7,
      "x": 933,
      "y": 759,
      "ta": "> div.masterdiv > div:[2] > div > ul > li:[3]"
    },
    {
      "t": 169649,
      "e": 37440,
      "ty": 6,
      "x": 933,
      "y": 759,
      "ta": "> div.masterdiv > div:[2] > div > ul > li:[4]"
    },
    {
      "t": 169683,
      "e": 37474,
      "ty": 7,
      "x": 933,
      "y": 806,
      "ta": "> div.masterdiv > div:[2] > div > ul > li:[4]"
    },
    {
      "t": 169709,
      "e": 37500,
      "ty": 2,
      "x": 933,
      "y": 831
    },
    {
      "t": 169759,
      "e": 37550,
      "ty": 41,
      "x": 31562,
      "y": 54961,
      "ta": "> div.masterdiv > div:[2]"
    },
    {
      "t": 169809,
      "e": 37600,
      "ty": 2,
      "x": 945,
      "y": 984
    },
    {
      "t": 169910,
      "e": 37701,
      "ty": 2,
      "x": 950,
      "y": 1025
    },
    {
      "t": 170010,
      "e": 37801,
      "ty": 2,
      "x": 950,
      "y": 1036
    },
    {
      "t": 170010,
      "e": 37801,
      "ty": 41,
      "x": 32300,
      "y": 62994,
      "ta": "> div.masterdiv > div:[2]"
    },
    {
      "t": 170109,
      "e": 37900,
      "ty": 2,
      "x": 950,
      "y": 1055
    },
    {
      "t": 170149,
      "e": 37940,
      "ty": 6,
      "x": 950,
      "y": 1072,
      "ta": "#start"
    },
    {
      "t": 170209,
      "e": 38000,
      "ty": 2,
      "x": 949,
      "y": 1090
    },
    {
      "t": 170260,
      "e": 38051,
      "ty": 41,
      "x": 21571,
      "y": 43007,
      "ta": "#start"
    },
    {
      "t": 170309,
      "e": 38100,
      "ty": 2,
      "x": 949,
      "y": 1099
    },
    {
      "t": 170410,
      "e": 38201,
      "ty": 2,
      "x": 949,
      "y": 1105
    },
    {
      "t": 170424,
      "e": 38215,
      "ty": 7,
      "x": 949,
      "y": 1107,
      "ta": "#start"
    },
    {
      "t": 170509,
      "e": 38300,
      "ty": 2,
      "x": 949,
      "y": 1110
    },
    {
      "t": 170509,
      "e": 38300,
      "ty": 41,
      "x": 27852,
      "y": 20670,
      "ta": "> div.masterdiv > div:[3]"
    },
    {
      "t": 170710,
      "e": 38501,
      "ty": 2,
      "x": 949,
      "y": 1111
    },
    {
      "t": 170760,
      "e": 38551,
      "ty": 41,
      "x": 27852,
      "y": 21224,
      "ta": "> div.masterdiv > div:[3]"
    },
    {
      "t": 170909,
      "e": 38700,
      "ty": 2,
      "x": 949,
      "y": 1113
    },
    {
      "t": 171009,
      "e": 38800,
      "ty": 2,
      "x": 949,
      "y": 1120
    },
    {
      "t": 171009,
      "e": 38800,
      "ty": 41,
      "x": 27852,
      "y": 26210,
      "ta": "> div.masterdiv > div:[3]"
    },
    {
      "t": 171210,
      "e": 39001,
      "ty": 2,
      "x": 949,
      "y": 1122
    },
    {
      "t": 171260,
      "e": 39051,
      "ty": 41,
      "x": 27852,
      "y": 27318,
      "ta": "> div.masterdiv > div:[3]"
    },
    {
      "t": 171509,
      "e": 39300,
      "ty": 2,
      "x": 949,
      "y": 1124
    },
    {
      "t": 171509,
      "e": 39300,
      "ty": 41,
      "x": 27852,
      "y": 28426,
      "ta": "> div.masterdiv > div:[3]"
    },
    {
      "t": 172710,
      "e": 40501,
      "ty": 2,
      "x": 957,
      "y": 1120
    },
    {
      "t": 172760,
      "e": 40551,
      "ty": 41,
      "x": 33469,
      "y": 23994,
      "ta": "> div.masterdiv > div:[3]"
    },
    {
      "t": 172810,
      "e": 40601,
      "ty": 2,
      "x": 962,
      "y": 1115
    },
    {
      "t": 172909,
      "e": 40700,
      "ty": 2,
      "x": 964,
      "y": 1112
    },
    {
      "t": 173003,
      "e": 40794,
      "ty": 6,
      "x": 970,
      "y": 1106,
      "ta": "#start"
    },
    {
      "t": 173010,
      "e": 40801,
      "ty": 2,
      "x": 970,
      "y": 1106
    },
    {
      "t": 173010,
      "e": 40801,
      "ty": 41,
      "x": 33040,
      "y": 64209,
      "ta": "#start"
    },
    {
      "t": 173109,
      "e": 40900,
      "ty": 2,
      "x": 974,
      "y": 1100
    },
    {
      "t": 173210,
      "e": 41001,
      "ty": 2,
      "x": 975,
      "y": 1097
    },
    {
      "t": 173259,
      "e": 41050,
      "ty": 41,
      "x": 35771,
      "y": 46862,
      "ta": "#start"
    },
    {
      "t": 173410,
      "e": 41201,
      "ty": 2,
      "x": 976,
      "y": 1094
    },
    {
      "t": 173510,
      "e": 41301,
      "ty": 2,
      "x": 978,
      "y": 1091
    },
    {
      "t": 173510,
      "e": 41301,
      "ty": 41,
      "x": 37409,
      "y": 35297,
      "ta": "#start"
    },
    {
      "t": 173610,
      "e": 41401,
      "ty": 2,
      "x": 992,
      "y": 1074
    },
    {
      "t": 173637,
      "e": 41428,
      "ty": 7,
      "x": 996,
      "y": 1070,
      "ta": "#start"
    },
    {
      "t": 173709,
      "e": 41500,
      "ty": 2,
      "x": 1002,
      "y": 1062
    },
    {
      "t": 173760,
      "e": 41551,
      "ty": 41,
      "x": 34858,
      "y": 64656,
      "ta": "> div.masterdiv > div:[2]"
    },
    {
      "t": 173809,
      "e": 41600,
      "ty": 2,
      "x": 1003,
      "y": 1060
    },
    {
      "t": 174010,
      "e": 41801,
      "ty": 41,
      "x": 34907,
      "y": 64656,
      "ta": "> div.masterdiv > div:[2]"
    },
    {
      "t": 174210,
      "e": 42001,
      "ty": 2,
      "x": 1001,
      "y": 1061
    },
    {
      "t": 174259,
      "e": 42050,
      "ty": 41,
      "x": 34661,
      "y": 65141,
      "ta": "> div.masterdiv > div:[2]"
    },
    {
      "t": 174304,
      "e": 42095,
      "ty": 6,
      "x": 996,
      "y": 1074,
      "ta": "#start"
    },
    {
      "t": 174309,
      "e": 42100,
      "ty": 2,
      "x": 996,
      "y": 1074
    },
    {
      "t": 174409,
      "e": 42200,
      "ty": 2,
      "x": 994,
      "y": 1086
    },
    {
      "t": 174510,
      "e": 42301,
      "ty": 2,
      "x": 993,
      "y": 1090
    },
    {
      "t": 174510,
      "e": 42301,
      "ty": 41,
      "x": 45601,
      "y": 33369,
      "ta": "#start"
    },
    {
      "t": 175010,
      "e": 42801,
      "ty": 2,
      "x": 991,
      "y": 1094
    },
    {
      "t": 175010,
      "e": 42801,
      "ty": 41,
      "x": 44509,
      "y": 41079,
      "ta": "#start"
    },
    {
      "t": 175108,
      "e": 42899,
      "ty": 2,
      "x": 986,
      "y": 1101
    },
    {
      "t": 175210,
      "e": 43001,
      "ty": 2,
      "x": 986,
      "y": 1102
    },
    {
      "t": 175260,
      "e": 43051,
      "ty": 41,
      "x": 41778,
      "y": 56499,
      "ta": "#start"
    },
    {
      "t": 176506,
      "e": 44297,
      "ty": 7,
      "x": 985,
      "y": 1107,
      "ta": "#start"
    },
    {
      "t": 176509,
      "e": 44300,
      "ty": 2,
      "x": 985,
      "y": 1107
    },
    {
      "t": 176509,
      "e": 44300,
      "ty": 41,
      "x": 44704,
      "y": 19008,
      "ta": "> div.masterdiv > div:[3]"
    },
    {
      "t": 176608,
      "e": 44399,
      "ty": 2,
      "x": 975,
      "y": 1117
    },
    {
      "t": 176708,
      "e": 44499,
      "ty": 2,
      "x": 950,
      "y": 1138
    },
    {
      "t": 176759,
      "e": 44550,
      "ty": 41,
      "x": 24575,
      "y": 41168,
      "ta": "> div.masterdiv > div:[3]"
    },
    {
      "t": 176808,
      "e": 44599,
      "ty": 2,
      "x": 933,
      "y": 1155
    },
    {
      "t": 176908,
      "e": 44699,
      "ty": 2,
      "x": 925,
      "y": 1160
    },
    {
      "t": 177008,
      "e": 44799,
      "ty": 41,
      "x": 16617,
      "y": 48370,
      "ta": "> div.masterdiv > div:[3]"
    },
    {
      "t": 177508,
      "e": 45299,
      "ty": 2,
      "x": 925,
      "y": 1157
    },
    {
      "t": 177509,
      "e": 45300,
      "ty": 41,
      "x": 16617,
      "y": 46708,
      "ta": "> div.masterdiv > div:[3]"
    },
    {
      "t": 177609,
      "e": 45400,
      "ty": 2,
      "x": 925,
      "y": 1149
    },
    {
      "t": 177709,
      "e": 45500,
      "ty": 2,
      "x": 927,
      "y": 1144
    },
    {
      "t": 177759,
      "e": 45550,
      "ty": 41,
      "x": 17554,
      "y": 37844,
      "ta": "> div.masterdiv > div:[3]"
    },
    {
      "t": 177809,
      "e": 45600,
      "ty": 2,
      "x": 927,
      "y": 1139
    },
    {
      "t": 178009,
      "e": 45800,
      "ty": 41,
      "x": 17554,
      "y": 36736,
      "ta": "> div.masterdiv > div:[3]"
    },
    {
      "t": 178108,
      "e": 45899,
      "ty": 2,
      "x": 927,
      "y": 1136
    },
    {
      "t": 178209,
      "e": 46000,
      "ty": 2,
      "x": 927,
      "y": 1135
    },
    {
      "t": 178259,
      "e": 46050,
      "ty": 41,
      "x": 17554,
      "y": 34520,
      "ta": "> div.masterdiv > div:[3]"
    },
    {
      "t": 178909,
      "e": 46700,
      "ty": 2,
      "x": 930,
      "y": 1129
    },
    {
      "t": 179009,
      "e": 46800,
      "ty": 2,
      "x": 934,
      "y": 1121
    },
    {
      "t": 179010,
      "e": 46801,
      "ty": 41,
      "x": 20830,
      "y": 26764,
      "ta": "> div.masterdiv > div:[3]"
    },
    {
      "t": 179109,
      "e": 46900,
      "ty": 2,
      "x": 938,
      "y": 1115
    },
    {
      "t": 179259,
      "e": 47050,
      "ty": 41,
      "x": 22703,
      "y": 23440,
      "ta": "> div.masterdiv > div:[3]"
    },
    {
      "t": 180012,
      "e": 47803,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 180412,
      "e": 48203,
      "ty": 2,
      "x": 933,
      "y": 1119
    },
    {
      "t": 180513,
      "e": 48304,
      "ty": 41,
      "x": 20362,
      "y": 25656,
      "ta": "> div.masterdiv > div:[3]"
    },
    {
      "t": 180912,
      "e": 48703,
      "ty": 2,
      "x": 919,
      "y": 1125
    },
    {
      "t": 181013,
      "e": 48804,
      "ty": 2,
      "x": 805,
      "y": 1199
    },
    {
      "t": 181112,
      "e": 48903,
      "ty": 2,
      "x": 698,
      "y": 1199
    },
    {
      "t": 181212,
      "e": 49003,
      "ty": 2,
      "x": 561,
      "y": 1199
    },
    {
      "t": 181312,
      "e": 49103,
      "ty": 2,
      "x": 508,
      "y": 1199
    },
    {
      "t": 181413,
      "e": 49204,
      "ty": 2,
      "x": 472,
      "y": 1194
    },
    {
      "t": 181513,
      "e": 49304,
      "ty": 2,
      "x": 464,
      "y": 1194
    },
    {
      "t": 181613,
      "e": 49404,
      "ty": 2,
      "x": 452,
      "y": 1193
    },
    {
      "t": 181712,
      "e": 49503,
      "ty": 2,
      "x": 445,
      "y": 1189
    },
    {
      "t": 181812,
      "e": 49603,
      "ty": 2,
      "x": 441,
      "y": 1189
    },
    {
      "t": 181912,
      "e": 49703,
      "ty": 2,
      "x": 433,
      "y": 1189
    },
    {
      "t": 182013,
      "e": 49804,
      "ty": 2,
      "x": 428,
      "y": 1186
    },
    {
      "t": 182112,
      "e": 49903,
      "ty": 2,
      "x": 427,
      "y": 1186
    },
    {
      "t": 182212,
      "e": 50003,
      "ty": 2,
      "x": 423,
      "y": 1185
    },
    {
      "t": 182313,
      "e": 50104,
      "ty": 2,
      "x": 416,
      "y": 1184
    },
    {
      "t": 182413,
      "e": 50204,
      "ty": 2,
      "x": 402,
      "y": 1177
    },
    {
      "t": 182513,
      "e": 50304,
      "ty": 2,
      "x": 392,
      "y": 1174
    },
    {
      "t": 182513,
      "e": 50304,
      "ty": 41,
      "x": 13224,
      "y": 64593,
      "ta": "> div.masterdiv"
    },
    {
      "t": 182612,
      "e": 50403,
      "ty": 2,
      "x": 384,
      "y": 1171
    },
    {
      "t": 182712,
      "e": 50503,
      "ty": 2,
      "x": 378,
      "y": 1171
    },
    {
      "t": 182763,
      "e": 50554,
      "ty": 41,
      "x": 12673,
      "y": 64316,
      "ta": "> div.masterdiv"
    },
    {
      "t": 182813,
      "e": 50604,
      "ty": 2,
      "x": 373,
      "y": 1168
    },
    {
      "t": 182912,
      "e": 50703,
      "ty": 2,
      "x": 366,
      "y": 1168
    },
    {
      "t": 183013,
      "e": 50804,
      "ty": 2,
      "x": 355,
      "y": 1163
    },
    {
      "t": 183013,
      "e": 50804,
      "ty": 41,
      "x": 11949,
      "y": 63983,
      "ta": "> div.masterdiv"
    },
    {
      "t": 183112,
      "e": 50903,
      "ty": 2,
      "x": 340,
      "y": 1157
    },
    {
      "t": 183212,
      "e": 51003,
      "ty": 2,
      "x": 312,
      "y": 1148
    },
    {
      "t": 183262,
      "e": 51053,
      "ty": 41,
      "x": 9780,
      "y": 62765,
      "ta": "> div.masterdiv"
    },
    {
      "t": 183313,
      "e": 51104,
      "ty": 2,
      "x": 278,
      "y": 1136
    },
    {
      "t": 183413,
      "e": 51204,
      "ty": 2,
      "x": 260,
      "y": 1129
    },
    {
      "t": 183512,
      "e": 51303,
      "ty": 2,
      "x": 253,
      "y": 1125
    },
    {
      "t": 183512,
      "e": 51303,
      "ty": 41,
      "x": 8437,
      "y": 61878,
      "ta": "> div.masterdiv"
    },
    {
      "t": 183612,
      "e": 51403,
      "ty": 2,
      "x": 249,
      "y": 1125
    },
    {
      "t": 183713,
      "e": 51504,
      "ty": 2,
      "x": 242,
      "y": 1124
    },
    {
      "t": 183763,
      "e": 51554,
      "ty": 41,
      "x": 7748,
      "y": 61657,
      "ta": "> div.masterdiv"
    },
    {
      "t": 183813,
      "e": 51604,
      "ty": 2,
      "x": 215,
      "y": 1108
    },
    {
      "t": 183912,
      "e": 51703,
      "ty": 2,
      "x": 61,
      "y": 995
    },
    {
      "t": 184012,
      "e": 51803,
      "ty": 2,
      "x": 0,
      "y": 871
    },
    {
      "t": 184012,
      "e": 51803,
      "ty": 41,
      "x": 0,
      "y": 48251,
      "ta": "html"
    },
    {
      "t": 184112,
      "e": 51903,
      "ty": 2,
      "x": 112,
      "y": 702
    },
    {
      "t": 184213,
      "e": 52004,
      "ty": 2,
      "x": 409,
      "y": 627
    },
    {
      "t": 184263,
      "e": 52054,
      "ty": 41,
      "x": 7455,
      "y": 36,
      "ta": "> div.masterdiv > div:[2] > div > p:[2]"
    },
    {
      "t": 184312,
      "e": 52103,
      "ty": 2,
      "x": 490,
      "y": 621
    },
    {
      "t": 184413,
      "e": 52204,
      "ty": 2,
      "x": 495,
      "y": 611
    },
    {
      "t": 184513,
      "e": 52304,
      "ty": 2,
      "x": 467,
      "y": 543
    },
    {
      "t": 184513,
      "e": 52304,
      "ty": 41,
      "x": 8537,
      "y": 32517,
      "ta": "> div.masterdiv > div:[2] > div > table"
    },
    {
      "t": 184531,
      "e": 52322,
      "ty": 6,
      "x": 455,
      "y": 526,
      "ta": "#da1"
    },
    {
      "t": 184564,
      "e": 52355,
      "ty": 7,
      "x": 439,
      "y": 508,
      "ta": "#da1"
    },
    {
      "t": 184612,
      "e": 52403,
      "ty": 2,
      "x": 415,
      "y": 482
    },
    {
      "t": 184713,
      "e": 52504,
      "ty": 2,
      "x": 386,
      "y": 455
    },
    {
      "t": 184763,
      "e": 52554,
      "ty": 41,
      "x": 4011,
      "y": 47999,
      "ta": "> div.masterdiv > div:[2] > div > p"
    },
    {
      "t": 184813,
      "e": 52604,
      "ty": 2,
      "x": 363,
      "y": 438
    },
    {
      "t": 184912,
      "e": 52703,
      "ty": 2,
      "x": 360,
      "y": 433
    },
    {
      "t": 185012,
      "e": 52803,
      "ty": 2,
      "x": 359,
      "y": 431
    },
    {
      "t": 185012,
      "e": 52803,
      "ty": 41,
      "x": 3224,
      "y": 29274,
      "ta": "> div.masterdiv > div:[2] > div > p"
    },
    {
      "t": 185213,
      "e": 53004,
      "ty": 2,
      "x": 357,
      "y": 431
    },
    {
      "t": 185263,
      "e": 53054,
      "ty": 41,
      "x": 3126,
      "y": 31615,
      "ta": "> div.masterdiv > div:[2] > div > p"
    },
    {
      "t": 185312,
      "e": 53103,
      "ty": 2,
      "x": 353,
      "y": 435
    },
    {
      "t": 185413,
      "e": 53204,
      "ty": 2,
      "x": 347,
      "y": 448
    },
    {
      "t": 185513,
      "e": 53304,
      "ty": 2,
      "x": 346,
      "y": 473
    },
    {
      "t": 185513,
      "e": 53304,
      "ty": 41,
      "x": 2585,
      "y": 10382,
      "ta": "> div.masterdiv > div:[2] > div"
    },
    {
      "t": 185612,
      "e": 53403,
      "ty": 2,
      "x": 346,
      "y": 484
    },
    {
      "t": 185712,
      "e": 53503,
      "ty": 2,
      "x": 346,
      "y": 501
    },
    {
      "t": 185750,
      "e": 53541,
      "ty": 6,
      "x": 344,
      "y": 513,
      "ta": "#da1"
    },
    {
      "t": 185762,
      "e": 53553,
      "ty": 41,
      "x": 1151,
      "y": 3327,
      "ta": "#da1"
    },
    {
      "t": 185813,
      "e": 53604,
      "ty": 2,
      "x": 343,
      "y": 525
    },
    {
      "t": 185833,
      "e": 53624,
      "ty": 7,
      "x": 342,
      "y": 536,
      "ta": "#da1"
    },
    {
      "t": 185913,
      "e": 53704,
      "ty": 2,
      "x": 340,
      "y": 545
    },
    {
      "t": 186012,
      "e": 53803,
      "ty": 2,
      "x": 337,
      "y": 556
    },
    {
      "t": 186013,
      "e": 53804,
      "ty": 41,
      "x": 386,
      "y": 11739,
      "ta": "> div.masterdiv > div:[2] > div > table > tbody > tr:[4] > td:[2]"
    },
    {
      "t": 186112,
      "e": 53903,
      "ty": 2,
      "x": 335,
      "y": 563
    },
    {
      "t": 186213,
      "e": 54004,
      "ty": 2,
      "x": 335,
      "y": 564
    },
    {
      "t": 186263,
      "e": 54054,
      "ty": 41,
      "x": 168,
      "y": 30463,
      "ta": "> div.masterdiv > div:[2] > div > table > tbody > tr:[4] > td:[2]"
    },
    {
      "t": 186512,
      "e": 54303,
      "ty": 2,
      "x": 334,
      "y": 566
    },
    {
      "t": 186513,
      "e": 54304,
      "ty": 41,
      "x": 59,
      "y": 35144,
      "ta": "> div.masterdiv > div:[2] > div > table > tbody > tr:[4] > td:[2]"
    },
    {
      "t": 186612,
      "e": 54403,
      "ty": 2,
      "x": 313,
      "y": 642
    },
    {
      "t": 186713,
      "e": 54504,
      "ty": 2,
      "x": 277,
      "y": 769
    },
    {
      "t": 186763,
      "e": 54554,
      "ty": 41,
      "x": 9091,
      "y": 43486,
      "ta": "> div.masterdiv"
    },
    {
      "t": 186813,
      "e": 54604,
      "ty": 2,
      "x": 267,
      "y": 811
    },
    {
      "t": 186913,
      "e": 54704,
      "ty": 2,
      "x": 264,
      "y": 820
    },
    {
      "t": 187012,
      "e": 54803,
      "ty": 41,
      "x": 8816,
      "y": 44982,
      "ta": "> div.masterdiv"
    },
    {
      "t": 187112,
      "e": 54903,
      "ty": 2,
      "x": 258,
      "y": 842
    },
    {
      "t": 187212,
      "e": 55003,
      "ty": 2,
      "x": 256,
      "y": 852
    },
    {
      "t": 187263,
      "e": 55054,
      "ty": 41,
      "x": 8540,
      "y": 46755,
      "ta": "> div.masterdiv"
    },
    {
      "t": 187513,
      "e": 55304,
      "ty": 2,
      "x": 268,
      "y": 857
    },
    {
      "t": 187514,
      "e": 55305,
      "ty": 41,
      "x": 8953,
      "y": 47032,
      "ta": "> div.masterdiv"
    },
    {
      "t": 187613,
      "e": 55404,
      "ty": 2,
      "x": 535,
      "y": 918
    },
    {
      "t": 187712,
      "e": 55503,
      "ty": 2,
      "x": 848,
      "y": 1056
    },
    {
      "t": 187763,
      "e": 55554,
      "ty": 41,
      "x": 28413,
      "y": 65279,
      "ta": "> div.masterdiv > div:[2]"
    },
    {
      "t": 187813,
      "e": 55604,
      "ty": 2,
      "x": 871,
      "y": 1076
    },
    {
      "t": 187913,
      "e": 55704,
      "ty": 2,
      "x": 764,
      "y": 1151
    },
    {
      "t": 188013,
      "e": 55804,
      "ty": 2,
      "x": 752,
      "y": 1157
    },
    {
      "t": 188013,
      "e": 55804,
      "ty": 41,
      "x": 25621,
      "y": 63651,
      "ta": "> div.masterdiv"
    },
    {
      "t": 188113,
      "e": 55904,
      "ty": 2,
      "x": 774,
      "y": 1132
    },
    {
      "t": 188213,
      "e": 56004,
      "ty": 2,
      "x": 781,
      "y": 1110
    },
    {
      "t": 188263,
      "e": 56054,
      "ty": 41,
      "x": 26654,
      "y": 60770,
      "ta": "> div.masterdiv"
    },
    {
      "t": 188312,
      "e": 56103,
      "ty": 2,
      "x": 782,
      "y": 1105
    },
    {
      "t": 188413,
      "e": 56204,
      "ty": 2,
      "x": 859,
      "y": 1094
    },
    {
      "t": 188451,
      "e": 56242,
      "ty": 6,
      "x": 910,
      "y": 1094,
      "ta": "#start"
    },
    {
      "t": 188512,
      "e": 56303,
      "ty": 2,
      "x": 920,
      "y": 1092
    },
    {
      "t": 188512,
      "e": 56303,
      "ty": 41,
      "x": 5734,
      "y": 37224,
      "ta": "#start"
    },
    {
      "t": 188612,
      "e": 56403,
      "ty": 2,
      "x": 927,
      "y": 1088
    },
    {
      "t": 188712,
      "e": 56503,
      "ty": 2,
      "x": 938,
      "y": 1087
    },
    {
      "t": 188763,
      "e": 56554,
      "ty": 41,
      "x": 17749,
      "y": 27587,
      "ta": "#start"
    },
    {
      "t": 188813,
      "e": 56604,
      "ty": 2,
      "x": 943,
      "y": 1087
    },
    {
      "t": 189013,
      "e": 56804,
      "ty": 41,
      "x": 18295,
      "y": 27587,
      "ta": "#start"
    },
    {
      "t": 190012,
      "e": 57803,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 190867,
      "e": 58658,
      "ty": 3,
      "x": 943,
      "y": 1087,
      "ta": "#start"
    },
    {
      "t": 190868,
      "e": 58659,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#start"
    },
    {
      "t": 191052,
      "e": 58843,
      "ty": 4,
      "x": 18295,
      "y": 27587,
      "ta": "#start"
    },
    {
      "t": 191052,
      "e": 58843,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#start"
    },
    {
      "t": 191052,
      "e": 58843,
      "ty": 5,
      "x": 943,
      "y": 1087,
      "ta": "#start"
    },
    {
      "t": 191054,
      "e": 58845,
      "ty": 38,
      "x": 5,
      "y": 0
    },
    {
      "t": 192054,
      "e": 59845,
      "ty": 38,
      "x": 6,
      "y": 0
    },
    {
      "t": 192113,
      "e": 59904,
      "ty": 2,
      "x": 909,
      "y": 1101
    },
    {
      "t": 192213,
      "e": 60004,
      "ty": 2,
      "x": 894,
      "y": 1109
    },
    {
      "t": 192263,
      "e": 60054,
      "ty": 41,
      "x": 29754,
      "y": 61601,
      "ta": "html > body"
    },
    {
      "t": 192313,
      "e": 60104,
      "ty": 2,
      "x": 852,
      "y": 1131
    },
    {
      "t": 192412,
      "e": 60203,
      "ty": 2,
      "x": 800,
      "y": 1161
    },
    {
      "t": 192512,
      "e": 60303,
      "ty": 2,
      "x": 759,
      "y": 1177
    },
    {
      "t": 192512,
      "e": 60303,
      "ty": 41,
      "x": 25862,
      "y": 64759,
      "ta": "html > body"
    },
    {
      "t": 192613,
      "e": 60404,
      "ty": 2,
      "x": 742,
      "y": 1182
    },
    {
      "t": 192712,
      "e": 60503,
      "ty": 2,
      "x": 737,
      "y": 1182
    },
    {
      "t": 192763,
      "e": 60554,
      "ty": 41,
      "x": 25036,
      "y": 65036,
      "ta": "html > body"
    },
    {
      "t": 192812,
      "e": 60603,
      "ty": 2,
      "x": 735,
      "y": 1182
    },
    {
      "t": 193513,
      "e": 61304,
      "ty": 2,
      "x": 734,
      "y": 1178
    },
    {
      "t": 193513,
      "e": 61304,
      "ty": 41,
      "x": 25001,
      "y": 64814,
      "ta": "html > body"
    },
    {
      "t": 193613,
      "e": 61404,
      "ty": 2,
      "x": 729,
      "y": 1169
    },
    {
      "t": 193713,
      "e": 61504,
      "ty": 2,
      "x": 704,
      "y": 1148
    },
    {
      "t": 193763,
      "e": 61554,
      "ty": 41,
      "x": 22694,
      "y": 62211,
      "ta": "html > body"
    },
    {
      "t": 193813,
      "e": 61604,
      "ty": 2,
      "x": 624,
      "y": 1119
    },
    {
      "t": 193913,
      "e": 61704,
      "ty": 2,
      "x": 570,
      "y": 1100
    },
    {
      "t": 194013,
      "e": 61804,
      "ty": 2,
      "x": 541,
      "y": 1092
    },
    {
      "t": 194013,
      "e": 61804,
      "ty": 41,
      "x": 18355,
      "y": 60050,
      "ta": "html > body"
    },
    {
      "t": 194113,
      "e": 61904,
      "ty": 2,
      "x": 485,
      "y": 1078
    },
    {
      "t": 194213,
      "e": 62004,
      "ty": 2,
      "x": 104,
      "y": 966
    },
    {
      "t": 194263,
      "e": 62054,
      "ty": 41,
      "x": 0,
      "y": 51796,
      "ta": "html"
    },
    {
      "t": 194313,
      "e": 62104,
      "ty": 2,
      "x": 0,
      "y": 918
    },
    {
      "t": 194413,
      "e": 62204,
      "ty": 2,
      "x": 0,
      "y": 912
    },
    {
      "t": 194513,
      "e": 62304,
      "ty": 2,
      "x": 0,
      "y": 907
    },
    {
      "t": 194513,
      "e": 62304,
      "ty": 41,
      "x": 0,
      "y": 50245,
      "ta": "html"
    },
    {
      "t": 194613,
      "e": 62404,
      "ty": 2,
      "x": 14,
      "y": 870
    },
    {
      "t": 194712,
      "e": 62503,
      "ty": 2,
      "x": 31,
      "y": 853
    },
    {
      "t": 194763,
      "e": 62554,
      "ty": 41,
      "x": 895,
      "y": 46533,
      "ta": "html > body"
    },
    {
      "t": 194813,
      "e": 62604,
      "ty": 2,
      "x": 34,
      "y": 848
    },
    {
      "t": 195413,
      "e": 63204,
      "ty": 2,
      "x": 34,
      "y": 845
    },
    {
      "t": 195513,
      "e": 63304,
      "ty": 2,
      "x": 27,
      "y": 838
    },
    {
      "t": 195513,
      "e": 63304,
      "ty": 41,
      "x": 654,
      "y": 45979,
      "ta": "html > body"
    },
    {
      "t": 195613,
      "e": 63404,
      "ty": 2,
      "x": 22,
      "y": 833
    },
    {
      "t": 195713,
      "e": 63504,
      "ty": 2,
      "x": 19,
      "y": 829
    },
    {
      "t": 195764,
      "e": 63555,
      "ty": 41,
      "x": 344,
      "y": 45370,
      "ta": "html > body"
    },
    {
      "t": 195813,
      "e": 63604,
      "ty": 2,
      "x": 17,
      "y": 827
    },
    {
      "t": 195913,
      "e": 63704,
      "ty": 2,
      "x": 14,
      "y": 824
    },
    {
      "t": 196013,
      "e": 63804,
      "ty": 2,
      "x": 13,
      "y": 821
    },
    {
      "t": 196013,
      "e": 63804,
      "ty": 41,
      "x": 172,
      "y": 45038,
      "ta": "html > body"
    },
    {
      "t": 196113,
      "e": 63904,
      "ty": 2,
      "x": 12,
      "y": 818
    },
    {
      "t": 196213,
      "e": 64004,
      "ty": 2,
      "x": 12,
      "y": 816
    },
    {
      "t": 196263,
      "e": 64054,
      "ty": 41,
      "x": 137,
      "y": 44761,
      "ta": "html > body"
    },
    {
      "t": 196615,
      "e": 64406,
      "ty": 2,
      "x": 12,
      "y": 815
    },
    {
      "t": 196763,
      "e": 64554,
      "ty": 41,
      "x": 137,
      "y": 44705,
      "ta": "html > body"
    },
    {
      "t": 198213,
      "e": 66004,
      "ty": 2,
      "x": 16,
      "y": 812
    },
    {
      "t": 198264,
      "e": 66055,
      "ty": 41,
      "x": 1653,
      "y": 43930,
      "ta": "html > body"
    },
    {
      "t": 198313,
      "e": 66104,
      "ty": 2,
      "x": 156,
      "y": 793
    },
    {
      "t": 198413,
      "e": 66204,
      "ty": 2,
      "x": 399,
      "y": 760
    },
    {
      "t": 198513,
      "e": 66304,
      "ty": 2,
      "x": 471,
      "y": 731
    },
    {
      "t": 198513,
      "e": 66304,
      "ty": 41,
      "x": 9053,
      "y": 45462,
      "ta": "#jspsych-single-stim-stimulus"
    },
    {
      "t": 198613,
      "e": 66404,
      "ty": 2,
      "x": 500,
      "y": 723
    },
    {
      "t": 198713,
      "e": 66504,
      "ty": 2,
      "x": 506,
      "y": 723
    },
    {
      "t": 198763,
      "e": 66554,
      "ty": 41,
      "x": 10801,
      "y": 44841,
      "ta": "#jspsych-single-stim-stimulus"
    },
    {
      "t": 198814,
      "e": 66605,
      "ty": 2,
      "x": 509,
      "y": 723
    },
    {
      "t": 198913,
      "e": 66704,
      "ty": 2,
      "x": 559,
      "y": 738
    },
    {
      "t": 199013,
      "e": 66804,
      "ty": 2,
      "x": 718,
      "y": 808
    },
    {
      "t": 199014,
      "e": 66805,
      "ty": 41,
      "x": 21044,
      "y": 51441,
      "ta": "#jspsych-single-stim-stimulus"
    },
    {
      "t": 199113,
      "e": 66904,
      "ty": 2,
      "x": 1012,
      "y": 1031
    },
    {
      "t": 199213,
      "e": 67004,
      "ty": 2,
      "x": 1103,
      "y": 1098
    },
    {
      "t": 199263,
      "e": 67054,
      "ty": 41,
      "x": 37743,
      "y": 60604,
      "ta": "html > body"
    },
    {
      "t": 199313,
      "e": 67104,
      "ty": 2,
      "x": 1104,
      "y": 1102
    },
    {
      "t": 199413,
      "e": 67204,
      "ty": 2,
      "x": 1091,
      "y": 1097
    },
    {
      "t": 199513,
      "e": 67304,
      "ty": 2,
      "x": 1023,
      "y": 1049
    },
    {
      "t": 199513,
      "e": 67304,
      "ty": 41,
      "x": 34954,
      "y": 57668,
      "ta": "html > body"
    },
    {
      "t": 199613,
      "e": 67404,
      "ty": 2,
      "x": 999,
      "y": 1034
    },
    {
      "t": 199713,
      "e": 67504,
      "ty": 2,
      "x": 993,
      "y": 1031
    },
    {
      "t": 199763,
      "e": 67554,
      "ty": 41,
      "x": 43214,
      "y": 50321,
      "ta": "> p"
    },
    {
      "t": 199813,
      "e": 67604,
      "ty": 2,
      "x": 985,
      "y": 1028
    },
    {
      "t": 199913,
      "e": 67704,
      "ty": 2,
      "x": 983,
      "y": 1026
    },
    {
      "t": 200014,
      "e": 67805,
      "ty": 41,
      "x": 41090,
      "y": 43299,
      "ta": "> p"
    },
    {
      "t": 200014,
      "e": 67805,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 201055,
      "e": 68846,
      "ty": 38,
      "x": 7,
      "y": 0
    },
    {
      "t": 201112,
      "e": 68903,
      "ty": 1,
      "x": 0,
      "y": 5
    },
    {
      "t": 201213,
      "e": 69004,
      "ty": 1,
      "x": 0,
      "y": 16
    },
    {
      "t": 202057,
      "e": 69848,
      "ty": 20,
      "x": 0,
      "y": 0
    }
  ],
  "domMutations": [
    {
      "sequence": 1,
      "data": "{\"f\":\"applyChanged\",\"args\":[[{\"id\":60},{\"id\":63},{\"id\":64},{\"id\":74},{\"id\":75},{\"id\":77},{\"id\":78},{\"id\":80},{\"id\":79},{\"id\":76},{\"id\":65},{\"id\":66},{\"id\":67},{\"id\":68},{\"id\":81},{\"id\":82},{\"id\":84},{\"id\":85},{\"id\":97},{\"id\":86},{\"id\":87},{\"id\":98},{\"id\":88},{\"id\":89},{\"id\":99},{\"id\":90},{\"id\":91},{\"id\":100},{\"id\":92},{\"id\":93},{\"id\":94},{\"id\":95},{\"id\":101},{\"id\":102},{\"id\":104},{\"id\":105},{\"id\":106},{\"id\":107},{\"id\":108},{\"id\":103},{\"id\":96},{\"id\":83},{\"id\":69},{\"id\":70},{\"id\":71},{\"id\":109},{\"id\":110},{\"id\":112},{\"id\":111},{\"id\":72},{\"id\":73},{\"id\":61},{\"id\":62}],[],[],[]]}"
    },
    {
      "sequence": 2,
      "data": "{\"f\":\"applyChanged\",\"args\":[[],[{\"nodeType\":1,\"id\":113,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-text-preamble\",\"class\":\"jspsych-survey-text-preamble\"},\"parentNode\":{\"id\":55}},{\"nodeType\":1,\"id\":114,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-text-0\",\"class\":\"jspsych-survey-text-question\"},\"previousSibling\":{\"id\":113},\"parentNode\":{\"id\":55}},{\"nodeType\":1,\"id\":115,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-text-1\",\"class\":\"jspsych-survey-text-question\"},\"previousSibling\":{\"id\":114},\"parentNode\":{\"id\":55}},{\"nodeType\":1,\"id\":116,\"tagName\":\"BUTTON\",\"attributes\":{\"id\":\"jspsych-survey-text-next\",\"class\":\"jspsych-btn jspsych-survey-text\"},\"previousSibling\":{\"id\":115},\"parentNode\":{\"id\":55}},{\"nodeType\":1,\"id\":117,\"tagName\":\"P\",\"attributes\":{},\"parentNode\":{\"id\":113}},{\"nodeType\":3,\"id\":118,\"textContent\":\"Please enter the following information from your participant card\",\"parentNode\":{\"id\":117}},{\"nodeType\":1,\"id\":119,\"tagName\":\"P\",\"attributes\":{\"class\":\"jspsych-survey-text\"},\"parentNode\":{\"id\":114}},{\"nodeType\":1,\"id\":120,\"tagName\":\"TEXTAREA\",\"attributes\":{\"name\":\"#jspsych-survey-text-response-0\",\"cols\":\"40\",\"rows\":\"1\"},\"previousSibling\":{\"id\":119},\"parentNode\":{\"id\":114}},{\"nodeType\":3,\"id\":121,\"textContent\":\"Session code: \",\"parentNode\":{\"id\":119}},{\"nodeType\":1,\"id\":122,\"tagName\":\"P\",\"attributes\":{\"class\":\"jspsych-survey-text\"},\"parentNode\":{\"id\":115}},{\"nodeType\":1,\"id\":123,\"tagName\":\"TEXTAREA\",\"attributes\":{\"name\":\"#jspsych-survey-text-response-1\",\"cols\":\"40\",\"rows\":\"1\"},\"previousSibling\":{\"id\":122},\"parentNode\":{\"id\":115}},{\"nodeType\":3,\"id\":124,\"textContent\":\"Condition code: \",\"parentNode\":{\"id\":122}},{\"nodeType\":3,\"id\":125,\"textContent\":\"Submit Answers\",\"parentNode\":{\"id\":116}}],[],[]]}"
    },
    {
      "sequence": 3,
      "data": "{\"f\":\"applyChanged\",\"args\":[[{\"id\":113},{\"id\":117},{\"id\":118},{\"id\":114},{\"id\":119},{\"id\":121},{\"id\":120},{\"id\":115},{\"id\":122},{\"id\":124},{\"id\":123},{\"id\":116},{\"id\":125}],[],[],[]]}"
    },
    {
      "sequence": 4,
      "data": "{\"f\":\"applyChanged\",\"args\":[[],[{\"nodeType\":1,\"id\":126,\"tagName\":\"SCRIPT\",\"parentNode\":{\"id\":55}},{\"nodeType\":3,\"id\":127,\"textContent\":\" \",\"previousSibling\":{\"id\":126},\"parentNode\":{\"id\":55}},{\"nodeType\":1,\"id\":128,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"masterdiv\"},\"previousSibling\":{\"id\":127},\"parentNode\":{\"id\":55}},{\"nodeType\":8,\"id\":129,\"previousSibling\":{\"id\":128},\"parentNode\":{\"id\":55}},{\"nodeType\":3,\"id\":130,\"textContent\":\" \",\"previousSibling\":{\"id\":129},\"parentNode\":{\"id\":55}},{\"nodeType\":3,\"id\":131,\"textContent\":\" \\t//set text of scenario descriptions based on scenario randomization order in main switch(scenarios[0]) { case \\\"acme\\\": $('#da1').text(\\\"Answer 15 questions to help a manager coordinate a factory shift schedule.\\\"); break; } \",\"parentNode\":{\"id\":126}},{\"nodeType\":3,\"id\":132,\"textContent\":\" \",\"parentNode\":{\"id\":128}},{\"nodeType\":1,\"id\":133,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"top\"},\"previousSibling\":{\"id\":132},\"parentNode\":{\"id\":128}},{\"nodeType\":8,\"id\":134,\"previousSibling\":{\"id\":133},\"parentNode\":{\"id\":128}},{\"nodeType\":3,\"id\":135,\"textContent\":\" \",\"previousSibling\":{\"id\":134},\"parentNode\":{\"id\":128}},{\"nodeType\":1,\"id\":136,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"instructions\"},\"previousSibling\":{\"id\":135},\"parentNode\":{\"id\":128}},{\"nodeType\":3,\"id\":137,\"textContent\":\" \",\"previousSibling\":{\"id\":136},\"parentNode\":{\"id\":128}},{\"nodeType\":8,\"id\":138,\"previousSibling\":{\"id\":137},\"parentNode\":{\"id\":128}},{\"nodeType\":3,\"id\":139,\"textContent\":\" \",\"previousSibling\":{\"id\":138},\"parentNode\":{\"id\":128}},{\"nodeType\":1,\"id\":140,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bottom\"},\"previousSibling\":{\"id\":139},\"parentNode\":{\"id\":128}},{\"nodeType\":8,\"id\":141,\"previousSibling\":{\"id\":140},\"parentNode\":{\"id\":128}},{\"nodeType\":3,\"id\":142,\"textContent\":\" \",\"previousSibling\":{\"id\":141},\"parentNode\":{\"id\":128}},{\"nodeType\":3,\"id\":143,\"textContent\":\" \",\"parentNode\":{\"id\":133}},{\"nodeType\":1,\"id\":144,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bcent\"},\"previousSibling\":{\"id\":143},\"parentNode\":{\"id\":133}},{\"nodeType\":3,\"id\":145,\"textContent\":\" \",\"previousSibling\":{\"id\":144},\"parentNode\":{\"id\":133}},{\"nodeType\":3,\"id\":146,\"textContent\":\" \",\"parentNode\":{\"id\":144}},{\"nodeType\":1,\"id\":147,\"tagName\":\"H1\",\"attributes\":{},\"previousSibling\":{\"id\":146},\"parentNode\":{\"id\":144}},{\"nodeType\":3,\"id\":148,\"textContent\":\" \",\"previousSibling\":{\"id\":147},\"parentNode\":{\"id\":144}},{\"nodeType\":3,\"id\":149,\"textContent\":\"Instructions\",\"parentNode\":{\"id\":147}},{\"nodeType\":3,\"id\":150,\"textContent\":\" \",\"parentNode\":{\"id\":136}},{\"nodeType\":1,\"id\":151,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"vcent\"},\"previousSibling\":{\"id\":150},\"parentNode\":{\"id\":136}},{\"nodeType\":3,\"id\":152,\"textContent\":\" \",\"previousSibling\":{\"id\":151},\"parentNode\":{\"id\":136}},{\"nodeType\":8,\"id\":153,\"previousSibling\":{\"id\":152},\"parentNode\":{\"id\":136}},{\"nodeType\":3,\"id\":154,\"textContent\":\" \",\"previousSibling\":{\"id\":153},\"parentNode\":{\"id\":136}},{\"nodeType\":3,\"id\":155,\"textContent\":\" \",\"parentNode\":{\"id\":151}},{\"nodeType\":1,\"id\":156,\"tagName\":\"P\",\"attributes\":{},\"previousSibling\":{\"id\":155},\"parentNode\":{\"id\":151}},{\"nodeType\":1,\"id\":157,\"tagName\":\"TABLE\",\"attributes\":{\"cellspacing\":\"0\",\"cellpadding\":\"0\",\"border\":\"0\",\"style\":\"display:block;\"},\"previousSibling\":{\"id\":156},\"parentNode\":{\"id\":151}},{\"nodeType\":3,\"id\":158,\"textContent\":\" \",\"previousSibling\":{\"id\":157},\"parentNode\":{\"id\":151}},{\"nodeType\":1,\"id\":159,\"tagName\":\"P\",\"attributes\":{},\"previousSibling\":{\"id\":158},\"parentNode\":{\"id\":151}},{\"nodeType\":3,\"id\":160,\"textContent\":\" \",\"previousSibling\":{\"id\":159},\"parentNode\":{\"id\":151}},{\"nodeType\":1,\"id\":161,\"tagName\":\"UL\",\"attributes\":{\"class\":\"fa-ul\"},\"previousSibling\":{\"id\":160},\"parentNode\":{\"id\":151}},{\"nodeType\":3,\"id\":162,\"textContent\":\" \",\"previousSibling\":{\"id\":161},\"parentNode\":{\"id\":151}},{\"nodeType\":1,\"id\":163,\"tagName\":\"P\",\"attributes\":{},\"previousSibling\":{\"id\":162},\"parentNode\":{\"id\":151}},{\"nodeType\":3,\"id\":164,\"textContent\":\" \",\"previousSibling\":{\"id\":163},\"parentNode\":{\"id\":151}},{\"nodeType\":3,\"id\":165,\"textContent\":\"We are interested in learning about how people make decisions about time. In this study, you are going to solve a series of problems about scheduling events. To help you solve the problems, we are going to give you a variety of graphs and diagrams. You are going to complete \",\"parentNode\":{\"id\":156}},{\"nodeType\":1,\"id\":166,\"tagName\":\"I\",\"attributes\":{},\"previousSibling\":{\"id\":165},\"parentNode\":{\"id\":156}},{\"nodeType\":3,\"id\":167,\"textContent\":\" of the activities on this computer. \",\"previousSibling\":{\"id\":166},\"parentNode\":{\"id\":156}},{\"nodeType\":3,\"id\":168,\"textContent\":\"all\",\"parentNode\":{\"id\":166}},{\"nodeType\":3,\"id\":169,\"textContent\":\" \",\"parentNode\":{\"id\":157}},{\"nodeType\":1,\"id\":170,\"tagName\":\"TBODY\",\"attributes\":{},\"previousSibling\":{\"id\":169},\"parentNode\":{\"id\":157}},{\"nodeType\":1,\"id\":171,\"tagName\":\"TR\",\"attributes\":{},\"parentNode\":{\"id\":170}},{\"nodeType\":3,\"id\":172,\"textContent\":\" \",\"previousSibling\":{\"id\":171},\"parentNode\":{\"id\":170}},{\"nodeType\":1,\"id\":173,\"tagName\":\"TR\",\"attributes\":{},\"previousSibling\":{\"id\":172},\"parentNode\":{\"id\":170}},{\"nodeType\":3,\"id\":174,\"textContent\":\" \\t\",\"previousSibling\":{\"id\":173},\"parentNode\":{\"id\":170}},{\"nodeType\":1,\"id\":175,\"tagName\":\"TR\",\"attributes\":{\"height\":\"15\"},\"previousSibling\":{\"id\":174},\"parentNode\":{\"id\":170}},{\"nodeType\":3,\"id\":176,\"textContent\":\" \\t\",\"previousSibling\":{\"id\":175},\"parentNode\":{\"id\":170}},{\"nodeType\":1,\"id\":177,\"tagName\":\"TR\",\"attributes\":{},\"previousSibling\":{\"id\":176},\"parentNode\":{\"id\":170}},{\"nodeType\":3,\"id\":178,\"textContent\":\" \",\"previousSibling\":{\"id\":177},\"parentNode\":{\"id\":170}},{\"nodeType\":1,\"id\":179,\"tagName\":\"TR\",\"attributes\":{},\"previousSibling\":{\"id\":178},\"parentNode\":{\"id\":170}},{\"nodeType\":3,\"id\":180,\"textContent\":\" \",\"previousSibling\":{\"id\":179},\"parentNode\":{\"id\":170}},{\"nodeType\":3,\"id\":181,\"textContent\":\" \",\"parentNode\":{\"id\":171}},{\"nodeType\":1,\"id\":182,\"tagName\":\"TD\",\"attributes\":{\"width\":\"40\",\"rowspan\":\"2\"},\"previousSibling\":{\"id\":181},\"parentNode\":{\"id\":171}},{\"nodeType\":3,\"id\":183,\"textContent\":\" \",\"previousSibling\":{\"id\":182},\"parentNode\":{\"id\":171}},{\"nodeType\":1,\"id\":184,\"tagName\":\"TD\",\"attributes\":{},\"previousSibling\":{\"id\":183},\"parentNode\":{\"id\":171}},{\"nodeType\":3,\"id\":185,\"textContent\":\" \",\"previousSibling\":{\"id\":184},\"parentNode\":{\"id\":171}},{\"nodeType\":1,\"id\":186,\"tagName\":\"A\",\"attributes\":{\"class\":\"fa fa-desktop fa-lg\"},\"parentNode\":{\"id\":182}},{\"nodeType\":3,\"id\":187,\"textContent\":\"Acme Factory [20 minutes]\",\"parentNode\":{\"id\":184}},{\"nodeType\":3,\"id\":188,\"textContent\":\" \",\"parentNode\":{\"id\":173}},{\"nodeType\":1,\"id\":189,\"tagName\":\"TD\",\"attributes\":{},\"previousSibling\":{\"id\":188},\"parentNode\":{\"id\":173}},{\"nodeType\":3,\"id\":190,\"textContent\":\" \",\"previousSibling\":{\"id\":189},\"parentNode\":{\"id\":173}},{\"nodeType\":1,\"id\":191,\"tagName\":\"A\",\"attributes\":{\"id\":\"da1\",\"class\":\"subheading\"},\"parentNode\":{\"id\":189}},{\"nodeType\":3,\"id\":192,\"textContent\":\"Answer 15 questions to help a manager coordinate a factory shift schedule.\",\"parentNode\":{\"id\":191}},{\"nodeType\":3,\"id\":193,\"textContent\":\" \",\"parentNode\":{\"id\":177}},{\"nodeType\":1,\"id\":194,\"tagName\":\"TD\",\"attributes\":{\"rowspan\":\"2\"},\"previousSibling\":{\"id\":193},\"parentNode\":{\"id\":177}},{\"nodeType\":3,\"id\":195,\"textContent\":\" \",\"previousSibling\":{\"id\":194},\"parentNode\":{\"id\":177}},{\"nodeType\":1,\"id\":196,\"tagName\":\"TD\",\"attributes\":{},\"previousSibling\":{\"id\":195},\"parentNode\":{\"id\":177}},{\"nodeType\":3,\"id\":197,\"textContent\":\" \",\"previousSibling\":{\"id\":196},\"parentNode\":{\"id\":177}},{\"nodeType\":1,\"id\":198,\"tagName\":\"A\",\"attributes\":{\"class\":\"fa fa-desktop fa-lg\"},\"parentNode\":{\"id\":194}},{\"nodeType\":3,\"id\":199,\"textContent\":\"Final Survey [5 minutes]\",\"parentNode\":{\"id\":196}},{\"nodeType\":3,\"id\":200,\"textContent\":\" \",\"parentNode\":{\"id\":179}},{\"nodeType\":1,\"id\":201,\"tagName\":\"TD\",\"attributes\":{},\"previousSibling\":{\"id\":200},\"parentNode\":{\"id\":179}},{\"nodeType\":3,\"id\":202,\"textContent\":\" \",\"previousSibling\":{\"id\":201},\"parentNode\":{\"id\":179}},{\"nodeType\":1,\"id\":203,\"tagName\":\"I\",\"attributes\":{},\"parentNode\":{\"id\":201}},{\"nodeType\":3,\"id\":204,\"textContent\":\"Complete a demographic survey and feedback on your experience.\",\"parentNode\":{\"id\":203}},{\"nodeType\":1,\"id\":205,\"tagName\":\"B\",\"attributes\":{},\"parentNode\":{\"id\":159}},{\"nodeType\":3,\"id\":206,\"textContent\":\" \",\"previousSibling\":{\"id\":205},\"parentNode\":{\"id\":159}},{\"nodeType\":3,\"id\":207,\"textContent\":\"To ensure accurate results, please:\",\"parentNode\":{\"id\":205}},{\"nodeType\":3,\"id\":208,\"textContent\":\" \\t\",\"parentNode\":{\"id\":161}},{\"nodeType\":1,\"id\":209,\"tagName\":\"LI\",\"attributes\":{},\"previousSibling\":{\"id\":208},\"parentNode\":{\"id\":161}},{\"nodeType\":3,\"id\":210,\"textContent\":\" \\t\",\"previousSibling\":{\"id\":209},\"parentNode\":{\"id\":161}},{\"nodeType\":1,\"id\":211,\"tagName\":\"LI\",\"attributes\":{},\"previousSibling\":{\"id\":210},\"parentNode\":{\"id\":161}},{\"nodeType\":3,\"id\":212,\"textContent\":\" \\t\",\"previousSibling\":{\"id\":211},\"parentNode\":{\"id\":161}},{\"nodeType\":1,\"id\":213,\"tagName\":\"LI\",\"attributes\":{},\"previousSibling\":{\"id\":212},\"parentNode\":{\"id\":161}},{\"nodeType\":3,\"id\":214,\"textContent\":\" \\t\",\"previousSibling\":{\"id\":213},\"parentNode\":{\"id\":161}},{\"nodeType\":1,\"id\":215,\"tagName\":\"LI\",\"attributes\":{},\"previousSibling\":{\"id\":214},\"parentNode\":{\"id\":161}},{\"nodeType\":3,\"id\":216,\"textContent\":\" \",\"previousSibling\":{\"id\":215},\"parentNode\":{\"id\":161}},{\"nodeType\":1,\"id\":217,\"tagName\":\"I\",\"attributes\":{\"class\":\"fa-li fa fa-check\",\"style\":\"color:green\"},\"parentNode\":{\"id\":209}},{\"nodeType\":3,\"id\":218,\"textContent\":\"DO read all instructions \",\"previousSibling\":{\"id\":217},\"parentNode\":{\"id\":209}},{\"nodeType\":1,\"id\":219,\"tagName\":\"I\",\"attributes\":{},\"previousSibling\":{\"id\":218},\"parentNode\":{\"id\":209}},{\"nodeType\":3,\"id\":220,\"textContent\":\" \",\"previousSibling\":{\"id\":219},\"parentNode\":{\"id\":209}},{\"nodeType\":3,\"id\":221,\"textContent\":\"carefully\",\"parentNode\":{\"id\":219}},{\"nodeType\":1,\"id\":222,\"tagName\":\"I\",\"attributes\":{\"class\":\"fa-li fa fa-close\",\"style\":\"color:#EA4335\"},\"parentNode\":{\"id\":211}},{\"nodeType\":3,\"id\":223,\"textContent\":\"DO NOT close this browser window\",\"previousSibling\":{\"id\":222},\"parentNode\":{\"id\":211}},{\"nodeType\":1,\"id\":224,\"tagName\":\"I\",\"attributes\":{\"class\":\"fa-li fa fa-close\",\"style\":\"color:#EA4335\"},\"parentNode\":{\"id\":213}},{\"nodeType\":3,\"id\":225,\"textContent\":\"DO NOT try to return to a previous page \",\"previousSibling\":{\"id\":224},\"parentNode\":{\"id\":213}},{\"nodeType\":1,\"id\":226,\"tagName\":\"I\",\"attributes\":{\"class\":\"fa-li fa fa-close\",\"style\":\"color:#EA4335\"},\"parentNode\":{\"id\":215}},{\"nodeType\":3,\"id\":227,\"textContent\":\"DO NOT use the back button on the mouse or web browser\",\"previousSibling\":{\"id\":226},\"parentNode\":{\"id\":215}},{\"nodeType\":3,\"id\":228,\"textContent\":\"If you have questions at any time, please raise your hand and the experimenter will assist you. \",\"parentNode\":{\"id\":163}},{\"nodeType\":3,\"id\":229,\"textContent\":\" \\t\",\"parentNode\":{\"id\":140}},{\"nodeType\":1,\"id\":230,\"tagName\":\"BUTTON\",\"attributes\":{\"class\":\"btn\",\"type\":\"button\",\"id\":\"start\"},\"previousSibling\":{\"id\":229},\"parentNode\":{\"id\":140}},{\"nodeType\":3,\"id\":231,\"textContent\":\" \",\"previousSibling\":{\"id\":230},\"parentNode\":{\"id\":140}},{\"nodeType\":3,\"id\":232,\"textContent\":\"BEGIN\",\"parentNode\":{\"id\":230}}],[],[]]}"
    },
    {
      "sequence": 5,
      "data": "{\"f\":\"applyChanged\",\"args\":[[{\"id\":126},{\"id\":131},{\"id\":127},{\"id\":128},{\"id\":132},{\"id\":133},{\"id\":143},{\"id\":144},{\"id\":146},{\"id\":147},{\"id\":149},{\"id\":148},{\"id\":145},{\"id\":134},{\"id\":135},{\"id\":136},{\"id\":150},{\"id\":151},{\"id\":155},{\"id\":156},{\"id\":165},{\"id\":166},{\"id\":168},{\"id\":167},{\"id\":157},{\"id\":169},{\"id\":170},{\"id\":171},{\"id\":181},{\"id\":182},{\"id\":186},{\"id\":183},{\"id\":184},{\"id\":187},{\"id\":185},{\"id\":172},{\"id\":173},{\"id\":188},{\"id\":189},{\"id\":191},{\"id\":192},{\"id\":190},{\"id\":174},{\"id\":175},{\"id\":176},{\"id\":177},{\"id\":193},{\"id\":194},{\"id\":198},{\"id\":195},{\"id\":196},{\"id\":199},{\"id\":197},{\"id\":178},{\"id\":179},{\"id\":200},{\"id\":201},{\"id\":203},{\"id\":204},{\"id\":202},{\"id\":180},{\"id\":158},{\"id\":159},{\"id\":205},{\"id\":207},{\"id\":206},{\"id\":160},{\"id\":161},{\"id\":208},{\"id\":209},{\"id\":217},{\"id\":218},{\"id\":219},{\"id\":221},{\"id\":220},{\"id\":210},{\"id\":211},{\"id\":222},{\"id\":223},{\"id\":212},{\"id\":213},{\"id\":224},{\"id\":225},{\"id\":214},{\"id\":215},{\"id\":226},{\"id\":227},{\"id\":216},{\"id\":162},{\"id\":163},{\"id\":228},{\"id\":164},{\"id\":152},{\"id\":153},{\"id\":154},{\"id\":137},{\"id\":138},{\"id\":139},{\"id\":140},{\"id\":229},{\"id\":230},{\"id\":232},{\"id\":231},{\"id\":141},{\"id\":142},{\"id\":129},{\"id\":130}],[],[],[]]}"
    },
    {
      "sequence": 6,
      "data": "{\"f\":\"applyChanged\",\"args\":[[],[{\"nodeType\":1,\"id\":233,\"tagName\":\"IMG\",\"attributes\":{\"src\":\"img/acme.png\",\"id\":\"jspsych-single-stim-stimulus\"},\"parentNode\":{\"id\":55}},{\"nodeType\":1,\"id\":234,\"tagName\":\"P\",\"attributes\":{\"style\":\"font-style:italic;\"},\"previousSibling\":{\"id\":233},\"parentNode\":{\"id\":55}},{\"nodeType\":3,\"id\":235,\"textContent\":\"Press enter to continue\",\"parentNode\":{\"id\":234}}],[],[]]}"
    },
    {
      "sequence": 7,
      "data": "{\"f\":\"applyChanged\",\"args\":[[{\"id\":233},{\"id\":234},{\"id\":235}],[],[],[]]}"
    }
  ],
  "initialDom": "{\"f\":\"initialize\",\"args\":[1,[{\"nodeType\":10,\"id\":2,\"name\":\"html\",\"publicId\":\"\",\"systemId\":\"\"},{\"nodeType\":1,\"id\":3,\"tagName\":\"HTML\",\"attributes\":{\"class\":\"fa-events-icons-ready\"},\"childNodes\":[{\"nodeType\":1,\"id\":4,\"tagName\":\"HEAD\",\"attributes\":{},\"childNodes\":[{\"nodeType\":3,\"id\":5,\"textContent\":\" \"},{\"nodeType\":1,\"id\":6,\"tagName\":\"TITLE\",\"attributes\":{},\"childNodes\":[{\"nodeType\":3,\"id\":7,\"textContent\":\"FOX2YP\"}]},{\"nodeType\":3,\"id\":8,\"textContent\":\" \"},{\"nodeType\":8,\"id\":9},{\"nodeType\":3,\"id\":10,\"textContent\":\" \"},{\"nodeType\":1,\"id\":11,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":12,\"textContent\":\" \"},{\"nodeType\":1,\"id\":13,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":14,\"textContent\":\" \"},{\"nodeType\":1,\"id\":15,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":16,\"textContent\":\" \"},{\"nodeType\":1,\"id\":17,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":18,\"textContent\":\" \"},{\"nodeType\":1,\"id\":19,\"tagName\":\"SCRIPT\"},{\"nodeType\":1,\"id\":20,\"tagName\":\"LINK\",\"attributes\":{\"href\":\"https://use.fontawesome.com/945539d961.css\",\"media\":\"all\",\"rel\":\"stylesheet\"}},{\"nodeType\":3,\"id\":21,\"textContent\":\" \"},{\"nodeType\":8,\"id\":22},{\"nodeType\":3,\"id\":23,\"textContent\":\" \"},{\"nodeType\":1,\"id\":24,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":25,\"textContent\":\" \"},{\"nodeType\":1,\"id\":26,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":27,\"textContent\":\" \"},{\"nodeType\":1,\"id\":28,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":29,\"textContent\":\" \"},{\"nodeType\":1,\"id\":30,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":31,\"textContent\":\" \"},{\"nodeType\":1,\"id\":32,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":33,\"textContent\":\" \"},{\"nodeType\":1,\"id\":34,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":35,\"textContent\":\" \"},{\"nodeType\":1,\"id\":36,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":37,\"textContent\":\" \"},{\"nodeType\":8,\"id\":38},{\"nodeType\":3,\"id\":39,\"textContent\":\" \"},{\"nodeType\":1,\"id\":40,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":41,\"textContent\":\" \"},{\"nodeType\":8,\"id\":42},{\"nodeType\":3,\"id\":43,\"textContent\":\" \"},{\"nodeType\":8,\"id\":44},{\"nodeType\":3,\"id\":45,\"textContent\":\" \"},{\"nodeType\":1,\"id\":46,\"tagName\":\"LINK\",\"attributes\":{\"href\":\"../views/jsPsych/css/jspsych.css\",\"rel\":\"stylesheet\",\"type\":\"text/css\"}},{\"nodeType\":3,\"id\":47,\"textContent\":\" \"},{\"nodeType\":1,\"id\":48,\"tagName\":\"LINK\",\"attributes\":{\"href\":\"../css/styles.css\",\"rel\":\"stylesheet\",\"type\":\"text/css\"}},{\"nodeType\":3,\"id\":49,\"textContent\":\" \"},{\"nodeType\":1,\"id\":50,\"tagName\":\"SCRIPT\"},{\"nodeType\":1,\"id\":51,\"tagName\":\"SCRIPT\"}]},{\"nodeType\":3,\"id\":52,\"textContent\":\" \"},{\"nodeType\":8,\"id\":53},{\"nodeType\":3,\"id\":54,\"textContent\":\" \"},{\"nodeType\":1,\"id\":55,\"tagName\":\"BODY\",\"attributes\":{\"class\":\"jspsych-display-element\"},\"childNodes\":[{\"nodeType\":3,\"id\":56,\"textContent\":\" \"},{\"nodeType\":1,\"id\":57,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":58,\"textContent\":\" \"},{\"nodeType\":1,\"id\":59,\"tagName\":\"IMG\",\"attributes\":{\"src\":\"img/phone.png\",\"id\":\"jspsych-single-stim-stimulus\"}}]}]}]]}",
  "useCssProxy": true,
  "loadTimes": "es: 114, dom: 520, initialDom: 532",
  "javascriptErrors": []
}