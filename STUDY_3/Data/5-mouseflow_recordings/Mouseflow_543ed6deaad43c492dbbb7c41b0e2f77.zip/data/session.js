var MF = MF || {};MF.RecordingData = MF.RecordingData || {};MF.RecordingData["session"] = {
  "id": "543ed6deaad43c492dbbb7c41b0e2f77",
  "created": "2018-05-25T10:39:11.0252756-07:00",
  "lastActivity": "2018-05-25T10:45:50.4282771-07:00",
  "pageViews": [
    {
      "id": "05251138c4bd1ee293ca71c63feee7208bc201bc",
      "startTime": "2018-05-25T10:39:11.0252756-07:00",
      "endTime": "2018-05-25T10:45:50.4282771-07:00",
      "title": "FOX2YP",
      "uri": "https://warm-citadel-75324.herokuapp.com/",
      "websitePage": "/16",
      "visitTime": 399447,
      "engagementTime": 235109,
      "scroll": 100.0,
      "tags": [
        "form-interact",
        "submit"
      ],
      "friction": 0,
      "annotations": []
    }
  ],
  "duration": 399447,
  "engagementTime": 235109,
  "totalFriction": 0,
  "country": "us",
  "region": "CA",
  "city": "La Jolla",
  "isp": "University of California, San Diego",
  "ip": "128.54.68.22",
  "lang": "en-US",
  "userAgent": "Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/66.0.3359.181 Safari/537.36",
  "browser": "Chrome",
  "browserVersion": "66.0.3359.181",
  "os": "Windows",
  "osVersion": "7",
  "device": "Desktop",
  "referrer": "",
  "referrerType": "",
  "screenRes": "1920x1200",
  "tags": [
    "form-interact",
    "submit"
  ],
  "variables": [
    "SID=BF0KE",
    "CONDITION=115"
  ],
  "watched": false,
  "starred": false,
  "lng": -117.2359,
  "lat": 32.8807,
  "visitorId": "4cb405f467eff23434d6ae13f81b8f66",
  "gdpr": false
}