var MF = MF || {};MF.RecordingData = MF.RecordingData || {};MF.RecordingData["session"] = {
  "id": "3762f8067c75257d909bc7f55554fe71",
  "created": "2018-05-15T17:11:45.9155864-07:00",
  "lastActivity": "2018-05-15T17:13:24.1742653-07:00",
  "pageViews": [
    {
      "id": "05154607adba8260299682a28227312744d69352",
      "startTime": "2018-05-15T17:11:45.9155864-07:00",
      "endTime": "2018-05-15T17:13:24.1742653-07:00",
      "title": "FOX2YP",
      "uri": "https://warm-citadel-75324.herokuapp.com/",
      "websitePage": "/15",
      "visitTime": 98387,
      "engagementTime": 95190,
      "scroll": 100.0,
      "tags": [
        "form-interact",
        "submit"
      ],
      "friction": 0,
      "annotations": []
    }
  ],
  "duration": 98387,
  "engagementTime": 95190,
  "totalFriction": 0,
  "country": "us",
  "region": "CA",
  "city": "La Jolla",
  "isp": "University of California, San Diego",
  "ip": "128.54.68.29",
  "lang": "en-US",
  "userAgent": "Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/66.0.3359.170 Safari/537.36",
  "browser": "Chrome",
  "browserVersion": "66.0.3359.170",
  "os": "Windows",
  "osVersion": "7",
  "device": "Desktop",
  "referrer": "",
  "referrerType": "",
  "screenRes": "1920x1200",
  "tags": [
    "form-interact",
    "submit"
  ],
  "variables": [
    "SID=X9GRY",
    "CONDITION=121",
    "TRI_CORRECT=1"
  ],
  "watched": false,
  "starred": false,
  "lng": -117.2359,
  "lat": 32.8807,
  "visitorId": "b97ef437b7ad78ee13f9f489956ca646",
  "gdpr": false
}