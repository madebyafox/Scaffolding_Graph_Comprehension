var MF = MF || {};MF.RecordingData = MF.RecordingData || {};MF.RecordingData["05141476836bda79fd26e6b1ce10dd5276c7b219"] = {
  "startTime": "2018-05-14T21:06:14.9022098Z",
  "websitePageUrl": "/",
  "visitTime": 198512,
  "engagementTime": 47669,
  "pageTitle": "FOX2YP",
  "url": "https://warm-citadel-75324.herokuapp.com/",
  "viewportWidth": 1920,
  "viewportHeight": 1094,
  "tags": [
    "form-interact"
  ],
  "session": {
    "id": "c1013be63ec9468f33aea9861ce4a7d0",
    "created": "2018-05-14T21:06:14.9022098+00:00",
    "lastActivity": "0001-01-01T00:00:00+00:00",
    "pages": 1,
    "duration": 0,
    "engagementTime": 0,
    "totalFriction": 0,
    "country": "us",
    "region": "CA",
    "city": "La Jolla",
    "isp": "University of California, San Diego",
    "ip": "###.###.###.###",
    "lang": "en-US",
    "userAgent": "Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/66.0.3359.170 Safari/537.36",
    "browser": "Chrome",
    "browserVersion": "66.0.3359.170",
    "os": "Windows",
    "osVersion": "7",
    "device": "Desktop",
    "referrer": "",
    "referrerType": "",
    "screenRes": "1920x1200",
    "entryPage": "/",
    "tags": [
      "form-interact"
    ],
    "variables": [],
    "watched": false,
    "starred": false,
    "lng": 32.8807,
    "lat": 32.8807,
    "visitorId": "640d9ea5ef3c62463302c3fa74e42c81",
    "gdpr": false,
    "visitorName": null,
    "playbackUrl": "https://us.mouseflow.com/websites/e0c9ff05-6fcb-4c4a-8173-e5a0724987b1/recordings/c1013be63ec9468f33aea9861ce4a7d0/play"
  },
  "events": [
    {
      "t": 100,
      "e": 100,
      "ty": 0,
      "x": 1920,
      "y": 1094
    },
    {
      "t": 394,
      "e": 394,
      "ty": 14,
      "x": 0,
      "y": 1093
    },
    {
      "t": 10005,
      "e": 5100,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 33474,
      "e": 5100,
      "ty": 40,
      "x": 0,
      "y": 0
    },
    {
      "t": 33504,
      "e": 5130,
      "ty": 0,
      "x": 1920,
      "y": 1200
    },
    {
      "t": 33505,
      "e": 5131,
      "ty": 2,
      "x": 846,
      "y": 56
    },
    {
      "t": 33505,
      "e": 5131,
      "ty": 41,
      "x": 28858,
      "y": 2659,
      "ta": "html > body"
    },
    {
      "t": 40002,
      "e": 10131,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 160233,
      "e": 10131,
      "ty": 2,
      "x": 815,
      "y": 247
    },
    {
      "t": 160284,
      "e": 10182,
      "ty": 41,
      "x": 23198,
      "y": 2604,
      "ta": "> div.masterdiv > div:[2] > div > p:[2]"
    },
    {
      "t": 160332,
      "e": 10230,
      "ty": 2,
      "x": 765,
      "y": 427
    },
    {
      "t": 160432,
      "e": 10330,
      "ty": 2,
      "x": 712,
      "y": 1059
    },
    {
      "t": 160532,
      "e": 10430,
      "ty": 2,
      "x": 932,
      "y": 1199
    },
    {
      "t": 160633,
      "e": 10531,
      "ty": 2,
      "x": 1113,
      "y": 1199
    },
    {
      "t": 160733,
      "e": 10631,
      "ty": 2,
      "x": 1181,
      "y": 1108
    },
    {
      "t": 160783,
      "e": 10681,
      "ty": 41,
      "x": 44156,
      "y": 27153,
      "ta": "> div.masterdiv > div:[2] > div > div"
    },
    {
      "t": 160832,
      "e": 10730,
      "ty": 2,
      "x": 1132,
      "y": 705
    },
    {
      "t": 160932,
      "e": 10830,
      "ty": 2,
      "x": 1054,
      "y": 669
    },
    {
      "t": 161032,
      "e": 10930,
      "ty": 2,
      "x": 666,
      "y": 919
    },
    {
      "t": 161033,
      "e": 10931,
      "ty": 41,
      "x": 18328,
      "y": 31672,
      "ta": "> div.masterdiv > div:[2] > div > div"
    },
    {
      "t": 161132,
      "e": 11030,
      "ty": 2,
      "x": 664,
      "y": 941
    },
    {
      "t": 161233,
      "e": 11131,
      "ty": 2,
      "x": 774,
      "y": 941
    },
    {
      "t": 161282,
      "e": 11180,
      "ty": 41,
      "x": 25658,
      "y": 56831,
      "ta": "> div.masterdiv > div:[2]"
    },
    {
      "t": 161332,
      "e": 11230,
      "ty": 2,
      "x": 818,
      "y": 947
    },
    {
      "t": 161433,
      "e": 11331,
      "ty": 2,
      "x": 823,
      "y": 929
    },
    {
      "t": 161533,
      "e": 11431,
      "ty": 2,
      "x": 817,
      "y": 918
    },
    {
      "t": 161533,
      "e": 11431,
      "ty": 41,
      "x": 44440,
      "y": 22988,
      "ta": "> div.masterdiv > div:[2] > div > div > label > div"
    },
    {
      "t": 161604,
      "e": 11502,
      "ty": 3,
      "x": 816,
      "y": 917,
      "ta": "> div.masterdiv > div:[2] > div > div > label > div"
    },
    {
      "t": 161633,
      "e": 11531,
      "ty": 2,
      "x": 816,
      "y": 917
    },
    {
      "t": 161659,
      "e": 11557,
      "ty": 4,
      "x": 41164,
      "y": 19711,
      "ta": "> div.masterdiv > div:[2] > div > div > label > div"
    },
    {
      "t": 161659,
      "e": 11557,
      "ty": 5,
      "x": 816,
      "y": 917,
      "ta": "> div.masterdiv > div:[2] > div > div > label > div"
    },
    {
      "t": 161661,
      "e": 11559,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#consent_checkbox"
    },
    {
      "t": 161664,
      "e": 11562,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#consent_checkbox",
      "v": "on"
    },
    {
      "t": 161783,
      "e": 11681,
      "ty": 41,
      "x": 27036,
      "y": 58701,
      "ta": "> div.masterdiv > div:[2]"
    },
    {
      "t": 161832,
      "e": 11730,
      "ty": 2,
      "x": 927,
      "y": 1096
    },
    {
      "t": 161946,
      "e": 11844,
      "ty": 2,
      "x": 951,
      "y": 1125
    },
    {
      "t": 162033,
      "e": 11931,
      "ty": 2,
      "x": 969,
      "y": 1113
    },
    {
      "t": 162033,
      "e": 11931,
      "ty": 41,
      "x": 37214,
      "y": 22332,
      "ta": "> div.masterdiv > div:[3]"
    },
    {
      "t": 162133,
      "e": 12031,
      "ty": 2,
      "x": 976,
      "y": 1095
    },
    {
      "t": 162228,
      "e": 12126,
      "ty": 3,
      "x": 976,
      "y": 1092,
      "ta": "#start"
    },
    {
      "t": 162230,
      "e": 12128,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#consent_checkbox"
    },
    {
      "t": 162231,
      "e": 12129,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#start"
    },
    {
      "t": 162233,
      "e": 12131,
      "ty": 2,
      "x": 976,
      "y": 1092
    },
    {
      "t": 162298,
      "e": 12196,
      "ty": 41,
      "x": 36317,
      "y": 37224,
      "ta": "#start"
    },
    {
      "t": 162298,
      "e": 12196,
      "ty": 4,
      "x": 36317,
      "y": 37224,
      "ta": "#start"
    },
    {
      "t": 162299,
      "e": 12197,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#start"
    },
    {
      "t": 162301,
      "e": 12199,
      "ty": 38,
      "x": 1,
      "y": 0
    },
    {
      "t": 162301,
      "e": 12199,
      "ty": 5,
      "x": 976,
      "y": 1092,
      "ta": "#start"
    },
    {
      "t": 162734,
      "e": 12632,
      "ty": 2,
      "x": 449,
      "y": 696
    },
    {
      "t": 162782,
      "e": 12680,
      "ty": 41,
      "x": 0,
      "y": 19333,
      "ta": "html"
    },
    {
      "t": 162832,
      "e": 12730,
      "ty": 2,
      "x": 0,
      "y": 186
    },
    {
      "t": 162945,
      "e": 12843,
      "ty": 2,
      "x": 0,
      "y": 185
    },
    {
      "t": 163039,
      "e": 12937,
      "ty": 41,
      "x": 0,
      "y": 10248,
      "ta": "html"
    },
    {
      "t": 163233,
      "e": 13131,
      "ty": 2,
      "x": 0,
      "y": 183
    },
    {
      "t": 163296,
      "e": 13194,
      "ty": 41,
      "x": 0,
      "y": 10137,
      "ta": "html"
    },
    {
      "t": 163319,
      "e": 13217,
      "ty": 38,
      "x": 2,
      "y": 0
    },
    {
      "t": 163533,
      "e": 13431,
      "ty": 2,
      "x": 12,
      "y": 176
    },
    {
      "t": 163533,
      "e": 13431,
      "ty": 41,
      "x": 137,
      "y": 9306,
      "ta": "html > body"
    },
    {
      "t": 163632,
      "e": 13530,
      "ty": 2,
      "x": 41,
      "y": 166
    },
    {
      "t": 163732,
      "e": 13630,
      "ty": 2,
      "x": 573,
      "y": 279
    },
    {
      "t": 163783,
      "e": 13681,
      "ty": 41,
      "x": 30752,
      "y": 21217,
      "ta": "html > body"
    },
    {
      "t": 163833,
      "e": 13731,
      "ty": 2,
      "x": 936,
      "y": 412
    },
    {
      "t": 163932,
      "e": 13830,
      "ty": 2,
      "x": 954,
      "y": 539
    },
    {
      "t": 164032,
      "e": 13930,
      "ty": 6,
      "x": 958,
      "y": 590,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 164033,
      "e": 13931,
      "ty": 2,
      "x": 958,
      "y": 590
    },
    {
      "t": 164033,
      "e": 13931,
      "ty": 41,
      "x": 32443,
      "y": 12482,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 164150,
      "e": 14048,
      "ty": 2,
      "x": 958,
      "y": 596
    },
    {
      "t": 164244,
      "e": 14142,
      "ty": 2,
      "x": 958,
      "y": 597
    },
    {
      "t": 164291,
      "e": 14189,
      "ty": 41,
      "x": 32443,
      "y": 34327,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 164388,
      "e": 14286,
      "ty": 3,
      "x": 958,
      "y": 597,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 164390,
      "e": 14288,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 164450,
      "e": 14348,
      "ty": 4,
      "x": 32443,
      "y": 34327,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 164451,
      "e": 14349,
      "ty": 5,
      "x": 958,
      "y": 597,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 165288,
      "e": 15186,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "16"
    },
    {
      "t": 165472,
      "e": 15370,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "84"
    },
    {
      "t": 165472,
      "e": 15370,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 165534,
      "e": 15432,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "T"
    },
    {
      "t": 165643,
      "e": 15541,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "T"
    },
    {
      "t": 165671,
      "e": 15569,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "82"
    },
    {
      "t": 165671,
      "e": 15569,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 165735,
      "e": 15633,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "TR"
    },
    {
      "t": 165843,
      "e": 15741,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "TR"
    },
    {
      "t": 165871,
      "e": 15769,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "69"
    },
    {
      "t": 165872,
      "e": 15770,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 165942,
      "e": 15840,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "TRE"
    },
    {
      "t": 166045,
      "e": 15943,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "TRE"
    },
    {
      "t": 166062,
      "e": 15960,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "69"
    },
    {
      "t": 166064,
      "e": 15962,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 166143,
      "e": 16041,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "TREE"
    },
    {
      "t": 166224,
      "e": 16122,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "+||"
    },
    {
      "t": 167133,
      "e": 17031,
      "ty": 2,
      "x": 959,
      "y": 601
    },
    {
      "t": 167152,
      "e": 17050,
      "ty": 7,
      "x": 959,
      "y": 612,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 167233,
      "e": 17131,
      "ty": 2,
      "x": 959,
      "y": 642
    },
    {
      "t": 167283,
      "e": 17181,
      "ty": 41,
      "x": 32659,
      "y": 53832,
      "ta": "#jspsych-survey-text-1 > p"
    },
    {
      "t": 167333,
      "e": 17231,
      "ty": 2,
      "x": 961,
      "y": 663
    },
    {
      "t": 167435,
      "e": 17333,
      "ty": 2,
      "x": 961,
      "y": 664
    },
    {
      "t": 167469,
      "e": 17367,
      "ty": 6,
      "x": 962,
      "y": 679,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 167533,
      "e": 17431,
      "ty": 2,
      "x": 962,
      "y": 699
    },
    {
      "t": 167533,
      "e": 17431,
      "ty": 41,
      "x": 33308,
      "y": 62414,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 167833,
      "e": 17731,
      "ty": 2,
      "x": 962,
      "y": 697
    },
    {
      "t": 167935,
      "e": 17833,
      "ty": 2,
      "x": 960,
      "y": 690
    },
    {
      "t": 167964,
      "e": 17862,
      "ty": 3,
      "x": 960,
      "y": 690,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 167965,
      "e": 17863,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "TREE"
    },
    {
      "t": 167966,
      "e": 17864,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 167966,
      "e": 17864,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 168035,
      "e": 17933,
      "ty": 41,
      "x": 32875,
      "y": 34327,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 168074,
      "e": 17972,
      "ty": 4,
      "x": 32875,
      "y": 34327,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 168074,
      "e": 17972,
      "ty": 5,
      "x": 960,
      "y": 690,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 168839,
      "e": 18737,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "49"
    },
    {
      "t": 168840,
      "e": 18738,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 168902,
      "e": 18800,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "1"
    },
    {
      "t": 169136,
      "e": 19034,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "49"
    },
    {
      "t": 169136,
      "e": 19034,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 169198,
      "e": 19096,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "11"
    },
    {
      "t": 169351,
      "e": 19249,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "49"
    },
    {
      "t": 169351,
      "e": 19249,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 169425,
      "e": 19251,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "11*"
    },
    {
      "t": 169804,
      "e": 19630,
      "ty": 7,
      "x": 960,
      "y": 700,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 169821,
      "e": 19647,
      "ty": 6,
      "x": 960,
      "y": 712,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 169833,
      "e": 19659,
      "ty": 2,
      "x": 960,
      "y": 712
    },
    {
      "t": 169933,
      "e": 19759,
      "ty": 2,
      "x": 962,
      "y": 737
    },
    {
      "t": 170048,
      "e": 19874,
      "ty": 41,
      "x": 34055,
      "y": 57591,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 170938,
      "e": 20764,
      "ty": 2,
      "x": 958,
      "y": 727
    },
    {
      "t": 171036,
      "e": 20862,
      "ty": 41,
      "x": 31994,
      "y": 37732,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 171845,
      "e": 21671,
      "ty": 3,
      "x": 958,
      "y": 727,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 171846,
      "e": 21672,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "11*"
    },
    {
      "t": 171846,
      "e": 21672,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 171847,
      "e": 21673,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 171987,
      "e": 21813,
      "ty": 4,
      "x": 31994,
      "y": 37732,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 171991,
      "e": 21817,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 171993,
      "e": 21819,
      "ty": 5,
      "x": 958,
      "y": 727,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 171996,
      "e": 21822,
      "ty": 38,
      "x": 3,
      "y": 0
    },
    {
      "t": 173091,
      "e": 22917,
      "ty": 38,
      "x": 4,
      "y": 0
    },
    {
      "t": 173119,
      "e": 22945,
      "ty": 6,
      "x": 958,
      "y": 727,
      "ta": "> div.masterdiv > div:[2] > div > ul > li:[3]"
    },
    {
      "t": 178788,
      "e": 27945,
      "ty": 7,
      "x": 950,
      "y": 726,
      "ta": "> div.masterdiv > div:[2] > div > ul > li:[3]"
    },
    {
      "t": 178789,
      "e": 27946,
      "ty": 6,
      "x": 950,
      "y": 726,
      "ta": "> div.masterdiv > div:[2] > div > ul > li:[2]"
    },
    {
      "t": 178810,
      "e": 27967,
      "ty": 7,
      "x": 893,
      "y": 689,
      "ta": "> div.masterdiv > div:[2] > div > ul > li:[2]"
    },
    {
      "t": 178810,
      "e": 27967,
      "ty": 6,
      "x": 893,
      "y": 689,
      "ta": "> div.masterdiv > div:[2] > div > ul > li"
    },
    {
      "t": 178833,
      "e": 27990,
      "ty": 2,
      "x": 866,
      "y": 674
    },
    {
      "t": 178842,
      "e": 27999,
      "ty": 7,
      "x": 778,
      "y": 625,
      "ta": "> div.masterdiv > div:[2] > div > ul > li"
    },
    {
      "t": 178933,
      "e": 28090,
      "ty": 2,
      "x": 441,
      "y": 434
    },
    {
      "t": 179033,
      "e": 28190,
      "ty": 2,
      "x": 428,
      "y": 430
    },
    {
      "t": 179033,
      "e": 28190,
      "ty": 41,
      "x": 6619,
      "y": 28104,
      "ta": "> div.masterdiv > div:[2] > div > p"
    },
    {
      "t": 179133,
      "e": 28290,
      "ty": 2,
      "x": 417,
      "y": 430
    },
    {
      "t": 179233,
      "e": 28390,
      "ty": 2,
      "x": 411,
      "y": 448
    },
    {
      "t": 179283,
      "e": 28440,
      "ty": 41,
      "x": 5782,
      "y": 59701,
      "ta": "> div.masterdiv > div:[2] > div > p"
    },
    {
      "t": 179334,
      "e": 28491,
      "ty": 2,
      "x": 410,
      "y": 461
    },
    {
      "t": 179433,
      "e": 28590,
      "ty": 2,
      "x": 409,
      "y": 472
    },
    {
      "t": 179505,
      "e": 28662,
      "ty": 2,
      "x": 408,
      "y": 477
    },
    {
      "t": 179506,
      "e": 28663,
      "ty": 41,
      "x": 5635,
      "y": 11002,
      "ta": "> div.masterdiv > div:[2] > div"
    },
    {
      "t": 179616,
      "e": 28773,
      "ty": 2,
      "x": 408,
      "y": 481
    },
    {
      "t": 179704,
      "e": 28861,
      "ty": 2,
      "x": 406,
      "y": 485
    },
    {
      "t": 179763,
      "e": 28920,
      "ty": 41,
      "x": 7801,
      "y": 21101,
      "ta": "> div.masterdiv > div:[2] > div > table > tbody > tr > td:[2]"
    },
    {
      "t": 179804,
      "e": 28961,
      "ty": 2,
      "x": 404,
      "y": 494
    },
    {
      "t": 179904,
      "e": 29061,
      "ty": 2,
      "x": 398,
      "y": 508
    },
    {
      "t": 179949,
      "e": 29106,
      "ty": 6,
      "x": 396,
      "y": 513,
      "ta": "#da1"
    },
    {
      "t": 180018,
      "e": 29175,
      "ty": 2,
      "x": 396,
      "y": 514
    },
    {
      "t": 180018,
      "e": 29175,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 180020,
      "e": 29177,
      "ty": 41,
      "x": 6827,
      "y": 6604,
      "ta": "#da1"
    },
    {
      "t": 180305,
      "e": 29462,
      "ty": 2,
      "x": 392,
      "y": 521
    },
    {
      "t": 180414,
      "e": 29571,
      "ty": 2,
      "x": 390,
      "y": 523
    },
    {
      "t": 180507,
      "e": 29664,
      "ty": 41,
      "x": 6172,
      "y": 36095,
      "ta": "#da1"
    },
    {
      "t": 180883,
      "e": 30040,
      "ty": 7,
      "x": 392,
      "y": 511,
      "ta": "#da1"
    },
    {
      "t": 180904,
      "e": 30061,
      "ty": 2,
      "x": 396,
      "y": 503
    },
    {
      "t": 181004,
      "e": 30161,
      "ty": 2,
      "x": 404,
      "y": 485
    },
    {
      "t": 181005,
      "e": 30162,
      "ty": 41,
      "x": 7692,
      "y": 11739,
      "ta": "> div.masterdiv > div:[2] > div > table > tbody > tr > td:[2]"
    },
    {
      "t": 181113,
      "e": 30270,
      "ty": 2,
      "x": 404,
      "y": 484
    },
    {
      "t": 181270,
      "e": 30427,
      "ty": 41,
      "x": 7692,
      "y": 9398,
      "ta": "> div.masterdiv > div:[2] > div > table > tbody > tr > td:[2]"
    },
    {
      "t": 182665,
      "e": 31822,
      "ty": 6,
      "x": 402,
      "y": 525,
      "ta": "#da1"
    },
    {
      "t": 182683,
      "e": 31840,
      "ty": 7,
      "x": 402,
      "y": 549,
      "ta": "#da1"
    },
    {
      "t": 182705,
      "e": 31862,
      "ty": 2,
      "x": 401,
      "y": 578
    },
    {
      "t": 182756,
      "e": 31913,
      "ty": 41,
      "x": 5635,
      "y": 38579,
      "ta": "> div.masterdiv > div:[2] > div"
    },
    {
      "t": 182765,
      "e": 31922,
      "ty": 6,
      "x": 414,
      "y": 680,
      "ta": "> div.masterdiv > div:[2] > div > ul > li"
    },
    {
      "t": 182782,
      "e": 31939,
      "ty": 7,
      "x": 421,
      "y": 704,
      "ta": "> div.masterdiv > div:[2] > div > ul > li"
    },
    {
      "t": 182783,
      "e": 31940,
      "ty": 6,
      "x": 421,
      "y": 704,
      "ta": "> div.masterdiv > div:[2] > div > ul > li:[2]"
    },
    {
      "t": 182804,
      "e": 31961,
      "ty": 2,
      "x": 424,
      "y": 711
    },
    {
      "t": 182914,
      "e": 32071,
      "ty": 2,
      "x": 436,
      "y": 722
    },
    {
      "t": 183008,
      "e": 32165,
      "ty": 41,
      "x": 5268,
      "y": 53868,
      "ta": "> div.masterdiv > div:[2] > div > ul > li:[2]"
    },
    {
      "t": 183439,
      "e": 32596,
      "ty": 7,
      "x": 447,
      "y": 730,
      "ta": "> div.masterdiv > div:[2] > div > ul > li:[2]"
    },
    {
      "t": 183441,
      "e": 32598,
      "ty": 6,
      "x": 447,
      "y": 730,
      "ta": "> div.masterdiv > div:[2] > div > ul > li:[3]"
    },
    {
      "t": 183501,
      "e": 32658,
      "ty": 7,
      "x": 470,
      "y": 758,
      "ta": "> div.masterdiv > div:[2] > div > ul > li:[3]"
    },
    {
      "t": 183501,
      "e": 32658,
      "ty": 6,
      "x": 470,
      "y": 758,
      "ta": "> div.masterdiv > div:[2] > div > ul > li:[4]"
    },
    {
      "t": 183504,
      "e": 32661,
      "ty": 2,
      "x": 470,
      "y": 758
    },
    {
      "t": 183505,
      "e": 32662,
      "ty": 41,
      "x": 6990,
      "y": 7058,
      "ta": "> div.masterdiv > div:[2] > div > ul > li:[4]"
    },
    {
      "t": 183551,
      "e": 32708,
      "ty": 7,
      "x": 483,
      "y": 787,
      "ta": "> div.masterdiv > div:[2] > div > ul > li:[4]"
    },
    {
      "t": 183604,
      "e": 32761,
      "ty": 2,
      "x": 524,
      "y": 831
    },
    {
      "t": 183704,
      "e": 32861,
      "ty": 2,
      "x": 644,
      "y": 911
    },
    {
      "t": 183755,
      "e": 32912,
      "ty": 41,
      "x": 19558,
      "y": 55585,
      "ta": "> div.masterdiv > div:[2]"
    },
    {
      "t": 183804,
      "e": 32961,
      "ty": 2,
      "x": 722,
      "y": 936
    },
    {
      "t": 183904,
      "e": 33061,
      "ty": 2,
      "x": 879,
      "y": 977
    },
    {
      "t": 184004,
      "e": 33161,
      "ty": 2,
      "x": 945,
      "y": 994
    },
    {
      "t": 184005,
      "e": 33162,
      "ty": 41,
      "x": 32054,
      "y": 60086,
      "ta": "> div.masterdiv > div:[2]"
    },
    {
      "t": 184104,
      "e": 33261,
      "ty": 2,
      "x": 939,
      "y": 1002
    },
    {
      "t": 184214,
      "e": 33371,
      "ty": 2,
      "x": 937,
      "y": 1003
    },
    {
      "t": 184261,
      "e": 33418,
      "ty": 41,
      "x": 31660,
      "y": 60709,
      "ta": "> div.masterdiv > div:[2]"
    },
    {
      "t": 184605,
      "e": 33762,
      "ty": 2,
      "x": 934,
      "y": 1006
    },
    {
      "t": 184704,
      "e": 33861,
      "ty": 2,
      "x": 925,
      "y": 1014
    },
    {
      "t": 184755,
      "e": 33912,
      "ty": 41,
      "x": 31021,
      "y": 62579,
      "ta": "> div.masterdiv > div:[2]"
    },
    {
      "t": 184805,
      "e": 33962,
      "ty": 2,
      "x": 929,
      "y": 1063
    },
    {
      "t": 184817,
      "e": 33974,
      "ty": 6,
      "x": 933,
      "y": 1073,
      "ta": "#start"
    },
    {
      "t": 184904,
      "e": 34061,
      "ty": 2,
      "x": 937,
      "y": 1090
    },
    {
      "t": 185016,
      "e": 34173,
      "ty": 41,
      "x": 15018,
      "y": 33369,
      "ta": "#start"
    },
    {
      "t": 185813,
      "e": 34970,
      "ty": 2,
      "x": 938,
      "y": 1091
    },
    {
      "t": 185905,
      "e": 35062,
      "ty": 2,
      "x": 941,
      "y": 1091
    },
    {
      "t": 186020,
      "e": 35177,
      "ty": 2,
      "x": 944,
      "y": 1090
    },
    {
      "t": 186020,
      "e": 35177,
      "ty": 41,
      "x": 18841,
      "y": 33369,
      "ta": "#start"
    },
    {
      "t": 187177,
      "e": 36334,
      "ty": 3,
      "x": 944,
      "y": 1090,
      "ta": "#start"
    },
    {
      "t": 187178,
      "e": 36335,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#start"
    },
    {
      "t": 187294,
      "e": 36451,
      "ty": 4,
      "x": 18841,
      "y": 33369,
      "ta": "#start"
    },
    {
      "t": 187295,
      "e": 36452,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#start"
    },
    {
      "t": 187295,
      "e": 36452,
      "ty": 5,
      "x": 944,
      "y": 1090,
      "ta": "#start"
    },
    {
      "t": 187297,
      "e": 36454,
      "ty": 38,
      "x": 5,
      "y": 0
    },
    {
      "t": 188263,
      "e": 37420,
      "ty": 41,
      "x": 32233,
      "y": 59884,
      "ta": "html > body"
    },
    {
      "t": 188311,
      "e": 37468,
      "ty": 38,
      "x": 6,
      "y": 0
    },
    {
      "t": 188311,
      "e": 37468,
      "ty": 2,
      "x": 944,
      "y": 1089
    },
    {
      "t": 188604,
      "e": 37761,
      "ty": 2,
      "x": 935,
      "y": 1094
    },
    {
      "t": 188705,
      "e": 37862,
      "ty": 2,
      "x": 928,
      "y": 1097
    },
    {
      "t": 188755,
      "e": 37912,
      "ty": 41,
      "x": 31579,
      "y": 60383,
      "ta": "html > body"
    },
    {
      "t": 188819,
      "e": 37976,
      "ty": 2,
      "x": 924,
      "y": 1099
    },
    {
      "t": 188905,
      "e": 38062,
      "ty": 2,
      "x": 913,
      "y": 1103
    },
    {
      "t": 189004,
      "e": 38161,
      "ty": 2,
      "x": 903,
      "y": 1106
    },
    {
      "t": 189004,
      "e": 38161,
      "ty": 41,
      "x": 30821,
      "y": 60826,
      "ta": "html > body"
    },
    {
      "t": 189105,
      "e": 38262,
      "ty": 2,
      "x": 901,
      "y": 1107
    },
    {
      "t": 189205,
      "e": 38362,
      "ty": 2,
      "x": 900,
      "y": 1107
    },
    {
      "t": 189269,
      "e": 38426,
      "ty": 41,
      "x": 30718,
      "y": 60881,
      "ta": "html > body"
    },
    {
      "t": 190019,
      "e": 39176,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 193311,
      "e": 42468,
      "ty": 2,
      "x": 898,
      "y": 1107
    },
    {
      "t": 193405,
      "e": 42562,
      "ty": 2,
      "x": 899,
      "y": 1094
    },
    {
      "t": 193504,
      "e": 42661,
      "ty": 2,
      "x": 907,
      "y": 1087
    },
    {
      "t": 193505,
      "e": 42662,
      "ty": 41,
      "x": 30959,
      "y": 59773,
      "ta": "html > body"
    },
    {
      "t": 193605,
      "e": 42762,
      "ty": 2,
      "x": 915,
      "y": 1079
    },
    {
      "t": 193704,
      "e": 42861,
      "ty": 2,
      "x": 919,
      "y": 1075
    },
    {
      "t": 193755,
      "e": 42912,
      "ty": 41,
      "x": 31407,
      "y": 58942,
      "ta": "html > body"
    },
    {
      "t": 193810,
      "e": 42967,
      "ty": 2,
      "x": 921,
      "y": 1069
    },
    {
      "t": 193905,
      "e": 43062,
      "ty": 2,
      "x": 923,
      "y": 1064
    },
    {
      "t": 194012,
      "e": 43169,
      "ty": 2,
      "x": 924,
      "y": 1062
    },
    {
      "t": 194012,
      "e": 43169,
      "ty": 41,
      "x": 31544,
      "y": 58388,
      "ta": "html > body"
    },
    {
      "t": 194105,
      "e": 43262,
      "ty": 2,
      "x": 925,
      "y": 1056
    },
    {
      "t": 194205,
      "e": 43362,
      "ty": 2,
      "x": 927,
      "y": 1047
    },
    {
      "t": 194255,
      "e": 43412,
      "ty": 41,
      "x": 31717,
      "y": 57003,
      "ta": "html > body"
    },
    {
      "t": 194305,
      "e": 43462,
      "ty": 2,
      "x": 932,
      "y": 1026
    },
    {
      "t": 194405,
      "e": 43562,
      "ty": 2,
      "x": 934,
      "y": 1014
    },
    {
      "t": 194509,
      "e": 43666,
      "ty": 41,
      "x": 23742,
      "y": 15213,
      "ta": "> p"
    },
    {
      "t": 195006,
      "e": 44163,
      "ty": 2,
      "x": 934,
      "y": 1012
    },
    {
      "t": 195007,
      "e": 44164,
      "ty": 41,
      "x": 23742,
      "y": 10532,
      "ta": "> p"
    },
    {
      "t": 195105,
      "e": 44262,
      "ty": 2,
      "x": 992,
      "y": 1013
    },
    {
      "t": 195255,
      "e": 44412,
      "ty": 41,
      "x": 44276,
      "y": 12872,
      "ta": "> p"
    },
    {
      "t": 197406,
      "e": 46563,
      "ty": 2,
      "x": 992,
      "y": 1015
    },
    {
      "t": 197493,
      "e": 46650,
      "ty": 38,
      "x": 7,
      "y": 0
    },
    {
      "t": 197510,
      "e": 46667,
      "ty": 2,
      "x": 991,
      "y": 1016
    },
    {
      "t": 197510,
      "e": 46667,
      "ty": 41,
      "x": 33852,
      "y": 55840,
      "ta": "html > body"
    },
    {
      "t": 198017,
      "e": 47174,
      "ty": 2,
      "x": 990,
      "y": 1017
    },
    {
      "t": 198017,
      "e": 47174,
      "ty": 41,
      "x": 33817,
      "y": 55895,
      "ta": "html > body"
    },
    {
      "t": 198114,
      "e": 47271,
      "ty": 2,
      "x": 988,
      "y": 1018
    },
    {
      "t": 198255,
      "e": 47412,
      "ty": 41,
      "x": 33748,
      "y": 55951,
      "ta": "html > body"
    },
    {
      "t": 198512,
      "e": 47669,
      "ty": 20,
      "x": 0,
      "y": 0
    }
  ],
  "domMutations": [
    {
      "sequence": 1,
      "data": "{\"f\":\"applyChanged\",\"args\":[[{\"id\":60},{\"id\":63},{\"id\":64},{\"id\":74},{\"id\":75},{\"id\":77},{\"id\":78},{\"id\":80},{\"id\":79},{\"id\":76},{\"id\":65},{\"id\":66},{\"id\":67},{\"id\":68},{\"id\":81},{\"id\":82},{\"id\":84},{\"id\":85},{\"id\":97},{\"id\":86},{\"id\":87},{\"id\":98},{\"id\":88},{\"id\":89},{\"id\":99},{\"id\":90},{\"id\":91},{\"id\":100},{\"id\":92},{\"id\":93},{\"id\":94},{\"id\":95},{\"id\":101},{\"id\":102},{\"id\":104},{\"id\":105},{\"id\":106},{\"id\":107},{\"id\":108},{\"id\":103},{\"id\":96},{\"id\":83},{\"id\":69},{\"id\":70},{\"id\":71},{\"id\":109},{\"id\":110},{\"id\":112},{\"id\":111},{\"id\":72},{\"id\":73},{\"id\":61},{\"id\":62}],[],[],[]]}"
    },
    {
      "sequence": 2,
      "data": "{\"f\":\"applyChanged\",\"args\":[[],[{\"nodeType\":1,\"id\":113,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-text-preamble\",\"class\":\"jspsych-survey-text-preamble\"},\"parentNode\":{\"id\":55}},{\"nodeType\":1,\"id\":114,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-text-0\",\"class\":\"jspsych-survey-text-question\"},\"previousSibling\":{\"id\":113},\"parentNode\":{\"id\":55}},{\"nodeType\":1,\"id\":115,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-text-1\",\"class\":\"jspsych-survey-text-question\"},\"previousSibling\":{\"id\":114},\"parentNode\":{\"id\":55}},{\"nodeType\":1,\"id\":116,\"tagName\":\"BUTTON\",\"attributes\":{\"id\":\"jspsych-survey-text-next\",\"class\":\"jspsych-btn jspsych-survey-text\"},\"previousSibling\":{\"id\":115},\"parentNode\":{\"id\":55}},{\"nodeType\":1,\"id\":117,\"tagName\":\"P\",\"attributes\":{},\"parentNode\":{\"id\":113}},{\"nodeType\":3,\"id\":118,\"textContent\":\"Please enter the following information from your participant card\",\"parentNode\":{\"id\":117}},{\"nodeType\":1,\"id\":119,\"tagName\":\"P\",\"attributes\":{\"class\":\"jspsych-survey-text\"},\"parentNode\":{\"id\":114}},{\"nodeType\":1,\"id\":120,\"tagName\":\"TEXTAREA\",\"attributes\":{\"name\":\"#jspsych-survey-text-response-0\",\"cols\":\"40\",\"rows\":\"1\"},\"previousSibling\":{\"id\":119},\"parentNode\":{\"id\":114}},{\"nodeType\":3,\"id\":121,\"textContent\":\"Session code: \",\"parentNode\":{\"id\":119}},{\"nodeType\":1,\"id\":122,\"tagName\":\"P\",\"attributes\":{\"class\":\"jspsych-survey-text\"},\"parentNode\":{\"id\":115}},{\"nodeType\":1,\"id\":123,\"tagName\":\"TEXTAREA\",\"attributes\":{\"name\":\"#jspsych-survey-text-response-1\",\"cols\":\"40\",\"rows\":\"1\"},\"previousSibling\":{\"id\":122},\"parentNode\":{\"id\":115}},{\"nodeType\":3,\"id\":124,\"textContent\":\"Condition code: \",\"parentNode\":{\"id\":122}},{\"nodeType\":3,\"id\":125,\"textContent\":\"Submit Answers\",\"parentNode\":{\"id\":116}}],[],[]]}"
    },
    {
      "sequence": 3,
      "data": "{\"f\":\"applyChanged\",\"args\":[[{\"id\":113},{\"id\":117},{\"id\":118},{\"id\":114},{\"id\":119},{\"id\":121},{\"id\":120},{\"id\":115},{\"id\":122},{\"id\":124},{\"id\":123},{\"id\":116},{\"id\":125}],[],[],[]]}"
    },
    {
      "sequence": 4,
      "data": "{\"f\":\"applyChanged\",\"args\":[[],[{\"nodeType\":1,\"id\":126,\"tagName\":\"SCRIPT\",\"parentNode\":{\"id\":55}},{\"nodeType\":3,\"id\":127,\"textContent\":\" \",\"previousSibling\":{\"id\":126},\"parentNode\":{\"id\":55}},{\"nodeType\":1,\"id\":128,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"masterdiv\"},\"previousSibling\":{\"id\":127},\"parentNode\":{\"id\":55}},{\"nodeType\":8,\"id\":129,\"previousSibling\":{\"id\":128},\"parentNode\":{\"id\":55}},{\"nodeType\":3,\"id\":130,\"textContent\":\" \",\"previousSibling\":{\"id\":129},\"parentNode\":{\"id\":55}},{\"nodeType\":3,\"id\":131,\"textContent\":\" \\t//set text of scenario descriptions based on scenario randomization order in main switch(scenarios[0]) { case \\\"acme\\\": $('#da1').text(\\\"Answer 15 questions to help a manager coordinate a factory shift schedule.\\\"); break; } \",\"parentNode\":{\"id\":126}},{\"nodeType\":3,\"id\":132,\"textContent\":\" \",\"parentNode\":{\"id\":128}},{\"nodeType\":1,\"id\":133,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"top\"},\"previousSibling\":{\"id\":132},\"parentNode\":{\"id\":128}},{\"nodeType\":8,\"id\":134,\"previousSibling\":{\"id\":133},\"parentNode\":{\"id\":128}},{\"nodeType\":3,\"id\":135,\"textContent\":\" \",\"previousSibling\":{\"id\":134},\"parentNode\":{\"id\":128}},{\"nodeType\":1,\"id\":136,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"instructions\"},\"previousSibling\":{\"id\":135},\"parentNode\":{\"id\":128}},{\"nodeType\":3,\"id\":137,\"textContent\":\" \",\"previousSibling\":{\"id\":136},\"parentNode\":{\"id\":128}},{\"nodeType\":8,\"id\":138,\"previousSibling\":{\"id\":137},\"parentNode\":{\"id\":128}},{\"nodeType\":3,\"id\":139,\"textContent\":\" \",\"previousSibling\":{\"id\":138},\"parentNode\":{\"id\":128}},{\"nodeType\":1,\"id\":140,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bottom\"},\"previousSibling\":{\"id\":139},\"parentNode\":{\"id\":128}},{\"nodeType\":8,\"id\":141,\"previousSibling\":{\"id\":140},\"parentNode\":{\"id\":128}},{\"nodeType\":3,\"id\":142,\"textContent\":\" \",\"previousSibling\":{\"id\":141},\"parentNode\":{\"id\":128}},{\"nodeType\":3,\"id\":143,\"textContent\":\" \",\"parentNode\":{\"id\":133}},{\"nodeType\":1,\"id\":144,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bcent\"},\"previousSibling\":{\"id\":143},\"parentNode\":{\"id\":133}},{\"nodeType\":3,\"id\":145,\"textContent\":\" \",\"previousSibling\":{\"id\":144},\"parentNode\":{\"id\":133}},{\"nodeType\":3,\"id\":146,\"textContent\":\" \",\"parentNode\":{\"id\":144}},{\"nodeType\":1,\"id\":147,\"tagName\":\"H1\",\"attributes\":{},\"previousSibling\":{\"id\":146},\"parentNode\":{\"id\":144}},{\"nodeType\":3,\"id\":148,\"textContent\":\" \",\"previousSibling\":{\"id\":147},\"parentNode\":{\"id\":144}},{\"nodeType\":3,\"id\":149,\"textContent\":\"Instructions\",\"parentNode\":{\"id\":147}},{\"nodeType\":3,\"id\":150,\"textContent\":\" \",\"parentNode\":{\"id\":136}},{\"nodeType\":1,\"id\":151,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"vcent\"},\"previousSibling\":{\"id\":150},\"parentNode\":{\"id\":136}},{\"nodeType\":3,\"id\":152,\"textContent\":\" \",\"previousSibling\":{\"id\":151},\"parentNode\":{\"id\":136}},{\"nodeType\":8,\"id\":153,\"previousSibling\":{\"id\":152},\"parentNode\":{\"id\":136}},{\"nodeType\":3,\"id\":154,\"textContent\":\" \",\"previousSibling\":{\"id\":153},\"parentNode\":{\"id\":136}},{\"nodeType\":3,\"id\":155,\"textContent\":\" \",\"parentNode\":{\"id\":151}},{\"nodeType\":1,\"id\":156,\"tagName\":\"P\",\"attributes\":{},\"previousSibling\":{\"id\":155},\"parentNode\":{\"id\":151}},{\"nodeType\":1,\"id\":157,\"tagName\":\"TABLE\",\"attributes\":{\"cellspacing\":\"0\",\"cellpadding\":\"0\",\"border\":\"0\",\"style\":\"display:block;\"},\"previousSibling\":{\"id\":156},\"parentNode\":{\"id\":151}},{\"nodeType\":3,\"id\":158,\"textContent\":\" \",\"previousSibling\":{\"id\":157},\"parentNode\":{\"id\":151}},{\"nodeType\":1,\"id\":159,\"tagName\":\"P\",\"attributes\":{},\"previousSibling\":{\"id\":158},\"parentNode\":{\"id\":151}},{\"nodeType\":3,\"id\":160,\"textContent\":\" \",\"previousSibling\":{\"id\":159},\"parentNode\":{\"id\":151}},{\"nodeType\":1,\"id\":161,\"tagName\":\"UL\",\"attributes\":{\"class\":\"fa-ul\"},\"previousSibling\":{\"id\":160},\"parentNode\":{\"id\":151}},{\"nodeType\":3,\"id\":162,\"textContent\":\" \",\"previousSibling\":{\"id\":161},\"parentNode\":{\"id\":151}},{\"nodeType\":1,\"id\":163,\"tagName\":\"P\",\"attributes\":{},\"previousSibling\":{\"id\":162},\"parentNode\":{\"id\":151}},{\"nodeType\":3,\"id\":164,\"textContent\":\" \",\"previousSibling\":{\"id\":163},\"parentNode\":{\"id\":151}},{\"nodeType\":3,\"id\":165,\"textContent\":\"We are interested in learning about how people make decisions about time. In this study, you are going to solve a series of problems about scheduling events. To help you solve the problems, we are going to give you a variety of graphs and diagrams. You are going to complete \",\"parentNode\":{\"id\":156}},{\"nodeType\":1,\"id\":166,\"tagName\":\"I\",\"attributes\":{},\"previousSibling\":{\"id\":165},\"parentNode\":{\"id\":156}},{\"nodeType\":3,\"id\":167,\"textContent\":\" of the activities on this computer. \",\"previousSibling\":{\"id\":166},\"parentNode\":{\"id\":156}},{\"nodeType\":3,\"id\":168,\"textContent\":\"all\",\"parentNode\":{\"id\":166}},{\"nodeType\":3,\"id\":169,\"textContent\":\" \",\"parentNode\":{\"id\":157}},{\"nodeType\":1,\"id\":170,\"tagName\":\"TBODY\",\"attributes\":{},\"previousSibling\":{\"id\":169},\"parentNode\":{\"id\":157}},{\"nodeType\":1,\"id\":171,\"tagName\":\"TR\",\"attributes\":{},\"parentNode\":{\"id\":170}},{\"nodeType\":3,\"id\":172,\"textContent\":\" \",\"previousSibling\":{\"id\":171},\"parentNode\":{\"id\":170}},{\"nodeType\":1,\"id\":173,\"tagName\":\"TR\",\"attributes\":{},\"previousSibling\":{\"id\":172},\"parentNode\":{\"id\":170}},{\"nodeType\":3,\"id\":174,\"textContent\":\" \\t\",\"previousSibling\":{\"id\":173},\"parentNode\":{\"id\":170}},{\"nodeType\":1,\"id\":175,\"tagName\":\"TR\",\"attributes\":{\"height\":\"15\"},\"previousSibling\":{\"id\":174},\"parentNode\":{\"id\":170}},{\"nodeType\":3,\"id\":176,\"textContent\":\" \\t\",\"previousSibling\":{\"id\":175},\"parentNode\":{\"id\":170}},{\"nodeType\":1,\"id\":177,\"tagName\":\"TR\",\"attributes\":{},\"previousSibling\":{\"id\":176},\"parentNode\":{\"id\":170}},{\"nodeType\":3,\"id\":178,\"textContent\":\" \",\"previousSibling\":{\"id\":177},\"parentNode\":{\"id\":170}},{\"nodeType\":1,\"id\":179,\"tagName\":\"TR\",\"attributes\":{},\"previousSibling\":{\"id\":178},\"parentNode\":{\"id\":170}},{\"nodeType\":3,\"id\":180,\"textContent\":\" \",\"previousSibling\":{\"id\":179},\"parentNode\":{\"id\":170}},{\"nodeType\":3,\"id\":181,\"textContent\":\" \",\"parentNode\":{\"id\":171}},{\"nodeType\":1,\"id\":182,\"tagName\":\"TD\",\"attributes\":{\"width\":\"40\",\"rowspan\":\"2\"},\"previousSibling\":{\"id\":181},\"parentNode\":{\"id\":171}},{\"nodeType\":3,\"id\":183,\"textContent\":\" \",\"previousSibling\":{\"id\":182},\"parentNode\":{\"id\":171}},{\"nodeType\":1,\"id\":184,\"tagName\":\"TD\",\"attributes\":{},\"previousSibling\":{\"id\":183},\"parentNode\":{\"id\":171}},{\"nodeType\":3,\"id\":185,\"textContent\":\" \",\"previousSibling\":{\"id\":184},\"parentNode\":{\"id\":171}},{\"nodeType\":1,\"id\":186,\"tagName\":\"A\",\"attributes\":{\"class\":\"fa fa-desktop fa-lg\"},\"parentNode\":{\"id\":182}},{\"nodeType\":3,\"id\":187,\"textContent\":\"Acme Factory [20 minutes]\",\"parentNode\":{\"id\":184}},{\"nodeType\":3,\"id\":188,\"textContent\":\" \",\"parentNode\":{\"id\":173}},{\"nodeType\":1,\"id\":189,\"tagName\":\"TD\",\"attributes\":{},\"previousSibling\":{\"id\":188},\"parentNode\":{\"id\":173}},{\"nodeType\":3,\"id\":190,\"textContent\":\" \",\"previousSibling\":{\"id\":189},\"parentNode\":{\"id\":173}},{\"nodeType\":1,\"id\":191,\"tagName\":\"A\",\"attributes\":{\"id\":\"da1\",\"class\":\"subheading\"},\"parentNode\":{\"id\":189}},{\"nodeType\":3,\"id\":192,\"textContent\":\"Answer 15 questions to help a manager coordinate a factory shift schedule.\",\"parentNode\":{\"id\":191}},{\"nodeType\":3,\"id\":193,\"textContent\":\" \",\"parentNode\":{\"id\":177}},{\"nodeType\":1,\"id\":194,\"tagName\":\"TD\",\"attributes\":{\"rowspan\":\"2\"},\"previousSibling\":{\"id\":193},\"parentNode\":{\"id\":177}},{\"nodeType\":3,\"id\":195,\"textContent\":\" \",\"previousSibling\":{\"id\":194},\"parentNode\":{\"id\":177}},{\"nodeType\":1,\"id\":196,\"tagName\":\"TD\",\"attributes\":{},\"previousSibling\":{\"id\":195},\"parentNode\":{\"id\":177}},{\"nodeType\":3,\"id\":197,\"textContent\":\" \",\"previousSibling\":{\"id\":196},\"parentNode\":{\"id\":177}},{\"nodeType\":1,\"id\":198,\"tagName\":\"A\",\"attributes\":{\"class\":\"fa fa-desktop fa-lg\"},\"parentNode\":{\"id\":194}},{\"nodeType\":3,\"id\":199,\"textContent\":\"Final Survey [5 minutes]\",\"parentNode\":{\"id\":196}},{\"nodeType\":3,\"id\":200,\"textContent\":\" \",\"parentNode\":{\"id\":179}},{\"nodeType\":1,\"id\":201,\"tagName\":\"TD\",\"attributes\":{},\"previousSibling\":{\"id\":200},\"parentNode\":{\"id\":179}},{\"nodeType\":3,\"id\":202,\"textContent\":\" \",\"previousSibling\":{\"id\":201},\"parentNode\":{\"id\":179}},{\"nodeType\":1,\"id\":203,\"tagName\":\"I\",\"attributes\":{},\"parentNode\":{\"id\":201}},{\"nodeType\":3,\"id\":204,\"textContent\":\"Complete a demographic survey and feedback on your experience.\",\"parentNode\":{\"id\":203}},{\"nodeType\":1,\"id\":205,\"tagName\":\"B\",\"attributes\":{},\"parentNode\":{\"id\":159}},{\"nodeType\":3,\"id\":206,\"textContent\":\" \",\"previousSibling\":{\"id\":205},\"parentNode\":{\"id\":159}},{\"nodeType\":3,\"id\":207,\"textContent\":\"To ensure accurate results, please:\",\"parentNode\":{\"id\":205}},{\"nodeType\":3,\"id\":208,\"textContent\":\" \\t\",\"parentNode\":{\"id\":161}},{\"nodeType\":1,\"id\":209,\"tagName\":\"LI\",\"attributes\":{},\"previousSibling\":{\"id\":208},\"parentNode\":{\"id\":161}},{\"nodeType\":3,\"id\":210,\"textContent\":\" \\t\",\"previousSibling\":{\"id\":209},\"parentNode\":{\"id\":161}},{\"nodeType\":1,\"id\":211,\"tagName\":\"LI\",\"attributes\":{},\"previousSibling\":{\"id\":210},\"parentNode\":{\"id\":161}},{\"nodeType\":3,\"id\":212,\"textContent\":\" \\t\",\"previousSibling\":{\"id\":211},\"parentNode\":{\"id\":161}},{\"nodeType\":1,\"id\":213,\"tagName\":\"LI\",\"attributes\":{},\"previousSibling\":{\"id\":212},\"parentNode\":{\"id\":161}},{\"nodeType\":3,\"id\":214,\"textContent\":\" \\t\",\"previousSibling\":{\"id\":213},\"parentNode\":{\"id\":161}},{\"nodeType\":1,\"id\":215,\"tagName\":\"LI\",\"attributes\":{},\"previousSibling\":{\"id\":214},\"parentNode\":{\"id\":161}},{\"nodeType\":3,\"id\":216,\"textContent\":\" \",\"previousSibling\":{\"id\":215},\"parentNode\":{\"id\":161}},{\"nodeType\":1,\"id\":217,\"tagName\":\"I\",\"attributes\":{\"class\":\"fa-li fa fa-check\",\"style\":\"color:green\"},\"parentNode\":{\"id\":209}},{\"nodeType\":3,\"id\":218,\"textContent\":\"DO read all instructions \",\"previousSibling\":{\"id\":217},\"parentNode\":{\"id\":209}},{\"nodeType\":1,\"id\":219,\"tagName\":\"I\",\"attributes\":{},\"previousSibling\":{\"id\":218},\"parentNode\":{\"id\":209}},{\"nodeType\":3,\"id\":220,\"textContent\":\" \",\"previousSibling\":{\"id\":219},\"parentNode\":{\"id\":209}},{\"nodeType\":3,\"id\":221,\"textContent\":\"carefully\",\"parentNode\":{\"id\":219}},{\"nodeType\":1,\"id\":222,\"tagName\":\"I\",\"attributes\":{\"class\":\"fa-li fa fa-close\",\"style\":\"color:#EA4335\"},\"parentNode\":{\"id\":211}},{\"nodeType\":3,\"id\":223,\"textContent\":\"DO NOT close this browser window\",\"previousSibling\":{\"id\":222},\"parentNode\":{\"id\":211}},{\"nodeType\":1,\"id\":224,\"tagName\":\"I\",\"attributes\":{\"class\":\"fa-li fa fa-close\",\"style\":\"color:#EA4335\"},\"parentNode\":{\"id\":213}},{\"nodeType\":3,\"id\":225,\"textContent\":\"DO NOT try to return to a previous page \",\"previousSibling\":{\"id\":224},\"parentNode\":{\"id\":213}},{\"nodeType\":1,\"id\":226,\"tagName\":\"I\",\"attributes\":{\"class\":\"fa-li fa fa-close\",\"style\":\"color:#EA4335\"},\"parentNode\":{\"id\":215}},{\"nodeType\":3,\"id\":227,\"textContent\":\"DO NOT use the back button on the mouse or web browser\",\"previousSibling\":{\"id\":226},\"parentNode\":{\"id\":215}},{\"nodeType\":3,\"id\":228,\"textContent\":\"If you have questions at any time, please raise your hand and the experimenter will assist you. \",\"parentNode\":{\"id\":163}},{\"nodeType\":3,\"id\":229,\"textContent\":\" \\t\",\"parentNode\":{\"id\":140}},{\"nodeType\":1,\"id\":230,\"tagName\":\"BUTTON\",\"attributes\":{\"class\":\"btn\",\"type\":\"button\",\"id\":\"start\"},\"previousSibling\":{\"id\":229},\"parentNode\":{\"id\":140}},{\"nodeType\":3,\"id\":231,\"textContent\":\" \",\"previousSibling\":{\"id\":230},\"parentNode\":{\"id\":140}},{\"nodeType\":3,\"id\":232,\"textContent\":\"BEGIN\",\"parentNode\":{\"id\":230}}],[],[]]}"
    },
    {
      "sequence": 5,
      "data": "{\"f\":\"applyChanged\",\"args\":[[{\"id\":126},{\"id\":131},{\"id\":127},{\"id\":128},{\"id\":132},{\"id\":133},{\"id\":143},{\"id\":144},{\"id\":146},{\"id\":147},{\"id\":149},{\"id\":148},{\"id\":145},{\"id\":134},{\"id\":135},{\"id\":136},{\"id\":150},{\"id\":151},{\"id\":155},{\"id\":156},{\"id\":165},{\"id\":166},{\"id\":168},{\"id\":167},{\"id\":157},{\"id\":169},{\"id\":170},{\"id\":171},{\"id\":181},{\"id\":182},{\"id\":186},{\"id\":183},{\"id\":184},{\"id\":187},{\"id\":185},{\"id\":172},{\"id\":173},{\"id\":188},{\"id\":189},{\"id\":191},{\"id\":192},{\"id\":190},{\"id\":174},{\"id\":175},{\"id\":176},{\"id\":177},{\"id\":193},{\"id\":194},{\"id\":198},{\"id\":195},{\"id\":196},{\"id\":199},{\"id\":197},{\"id\":178},{\"id\":179},{\"id\":200},{\"id\":201},{\"id\":203},{\"id\":204},{\"id\":202},{\"id\":180},{\"id\":158},{\"id\":159},{\"id\":205},{\"id\":207},{\"id\":206},{\"id\":160},{\"id\":161},{\"id\":208},{\"id\":209},{\"id\":217},{\"id\":218},{\"id\":219},{\"id\":221},{\"id\":220},{\"id\":210},{\"id\":211},{\"id\":222},{\"id\":223},{\"id\":212},{\"id\":213},{\"id\":224},{\"id\":225},{\"id\":214},{\"id\":215},{\"id\":226},{\"id\":227},{\"id\":216},{\"id\":162},{\"id\":163},{\"id\":228},{\"id\":164},{\"id\":152},{\"id\":153},{\"id\":154},{\"id\":137},{\"id\":138},{\"id\":139},{\"id\":140},{\"id\":229},{\"id\":230},{\"id\":232},{\"id\":231},{\"id\":141},{\"id\":142},{\"id\":129},{\"id\":130}],[],[],[]]}"
    },
    {
      "sequence": 6,
      "data": "{\"f\":\"applyChanged\",\"args\":[[],[{\"nodeType\":1,\"id\":233,\"tagName\":\"IMG\",\"attributes\":{\"src\":\"img/acme.png\",\"id\":\"jspsych-single-stim-stimulus\"},\"parentNode\":{\"id\":55}},{\"nodeType\":1,\"id\":234,\"tagName\":\"P\",\"attributes\":{\"style\":\"font-style:italic;\"},\"previousSibling\":{\"id\":233},\"parentNode\":{\"id\":55}},{\"nodeType\":3,\"id\":235,\"textContent\":\"Press enter to continue\",\"parentNode\":{\"id\":234}}],[],[]]}"
    },
    {
      "sequence": 7,
      "data": "{\"f\":\"applyChanged\",\"args\":[[{\"id\":233},{\"id\":234},{\"id\":235}],[],[],[]]}"
    }
  ],
  "initialDom": "{\"f\":\"initialize\",\"args\":[1,[{\"nodeType\":10,\"id\":2,\"name\":\"html\",\"publicId\":\"\",\"systemId\":\"\"},{\"nodeType\":1,\"id\":3,\"tagName\":\"HTML\",\"attributes\":{\"class\":\"fa-events-icons-ready\"},\"childNodes\":[{\"nodeType\":1,\"id\":4,\"tagName\":\"HEAD\",\"attributes\":{},\"childNodes\":[{\"nodeType\":3,\"id\":5,\"textContent\":\" \"},{\"nodeType\":1,\"id\":6,\"tagName\":\"TITLE\",\"attributes\":{},\"childNodes\":[{\"nodeType\":3,\"id\":7,\"textContent\":\"FOX2YP\"}]},{\"nodeType\":3,\"id\":8,\"textContent\":\" \"},{\"nodeType\":8,\"id\":9},{\"nodeType\":3,\"id\":10,\"textContent\":\" \"},{\"nodeType\":1,\"id\":11,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":12,\"textContent\":\" \"},{\"nodeType\":1,\"id\":13,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":14,\"textContent\":\" \"},{\"nodeType\":1,\"id\":15,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":16,\"textContent\":\" \"},{\"nodeType\":1,\"id\":17,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":18,\"textContent\":\" \"},{\"nodeType\":1,\"id\":19,\"tagName\":\"SCRIPT\"},{\"nodeType\":1,\"id\":20,\"tagName\":\"LINK\",\"attributes\":{\"href\":\"https://use.fontawesome.com/945539d961.css\",\"media\":\"all\",\"rel\":\"stylesheet\"}},{\"nodeType\":3,\"id\":21,\"textContent\":\" \"},{\"nodeType\":8,\"id\":22},{\"nodeType\":3,\"id\":23,\"textContent\":\" \"},{\"nodeType\":1,\"id\":24,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":25,\"textContent\":\" \"},{\"nodeType\":1,\"id\":26,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":27,\"textContent\":\" \"},{\"nodeType\":1,\"id\":28,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":29,\"textContent\":\" \"},{\"nodeType\":1,\"id\":30,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":31,\"textContent\":\" \"},{\"nodeType\":1,\"id\":32,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":33,\"textContent\":\" \"},{\"nodeType\":1,\"id\":34,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":35,\"textContent\":\" \"},{\"nodeType\":1,\"id\":36,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":37,\"textContent\":\" \"},{\"nodeType\":8,\"id\":38},{\"nodeType\":3,\"id\":39,\"textContent\":\" \"},{\"nodeType\":1,\"id\":40,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":41,\"textContent\":\" \"},{\"nodeType\":8,\"id\":42},{\"nodeType\":3,\"id\":43,\"textContent\":\" \"},{\"nodeType\":8,\"id\":44},{\"nodeType\":3,\"id\":45,\"textContent\":\" \"},{\"nodeType\":1,\"id\":46,\"tagName\":\"LINK\",\"attributes\":{\"href\":\"../views/jsPsych/css/jspsych.css\",\"rel\":\"stylesheet\",\"type\":\"text/css\"}},{\"nodeType\":3,\"id\":47,\"textContent\":\" \"},{\"nodeType\":1,\"id\":48,\"tagName\":\"LINK\",\"attributes\":{\"href\":\"../css/styles.css\",\"rel\":\"stylesheet\",\"type\":\"text/css\"}},{\"nodeType\":3,\"id\":49,\"textContent\":\" \"},{\"nodeType\":1,\"id\":50,\"tagName\":\"SCRIPT\"},{\"nodeType\":1,\"id\":51,\"tagName\":\"SCRIPT\"}]},{\"nodeType\":3,\"id\":52,\"textContent\":\" \"},{\"nodeType\":8,\"id\":53},{\"nodeType\":3,\"id\":54,\"textContent\":\" \"},{\"nodeType\":1,\"id\":55,\"tagName\":\"BODY\",\"attributes\":{\"class\":\"jspsych-display-element\"},\"childNodes\":[{\"nodeType\":3,\"id\":56,\"textContent\":\" \"},{\"nodeType\":1,\"id\":57,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":58,\"textContent\":\" \"},{\"nodeType\":1,\"id\":59,\"tagName\":\"IMG\",\"attributes\":{\"src\":\"img/phone.png\",\"id\":\"jspsych-single-stim-stimulus\"}}]}]}]]}",
  "useCssProxy": true,
  "loadTimes": "es: 170, dom: 1064, initialDom: 1067",
  "javascriptErrors": []
}