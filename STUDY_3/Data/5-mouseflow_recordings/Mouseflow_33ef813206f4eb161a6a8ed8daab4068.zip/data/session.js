var MF = MF || {};MF.RecordingData = MF.RecordingData || {};MF.RecordingData["session"] = {
  "id": "33ef813206f4eb161a6a8ed8daab4068",
  "created": "2018-06-04T13:20:03.0590413-07:00",
  "lastActivity": "2018-06-04T13:21:27.3822491-07:00",
  "pageViews": [
    {
      "id": "060403521cd56303ca9f61c42cb32ef236e942ac",
      "startTime": "2018-06-04T13:20:03.1744488-07:00",
      "endTime": "2018-06-04T13:21:27.3822491-07:00",
      "title": "FOX2YP",
      "uri": "https://warm-citadel-75324.herokuapp.com/",
      "websitePage": "/5",
      "visitTime": 84270,
      "engagementTime": 73967,
      "scroll": 100.0,
      "tags": [
        "form-interact"
      ],
      "friction": 0,
      "annotations": []
    }
  ],
  "duration": 84270,
  "engagementTime": 73967,
  "totalFriction": 0,
  "country": "us",
  "region": "CA",
  "city": "La Jolla",
  "isp": "University of California, San Diego",
  "ip": "128.54.68.36",
  "lang": "en-US",
  "userAgent": "Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/66.0.3359.181 Safari/537.36",
  "browser": "Chrome",
  "browserVersion": "66.0.3359.181",
  "os": "Windows",
  "osVersion": "7",
  "device": "Desktop",
  "referrer": "",
  "referrerType": "",
  "screenRes": "1920x1200",
  "tags": [
    "form-interact"
  ],
  "variables": [
    "SID=VVH1B",
    "CONDITION=211"
  ],
  "watched": false,
  "starred": false,
  "lng": -117.2359,
  "lat": 32.8807,
  "visitorId": "4142a660c5c5425ea56686c36613468b",
  "gdpr": false
}