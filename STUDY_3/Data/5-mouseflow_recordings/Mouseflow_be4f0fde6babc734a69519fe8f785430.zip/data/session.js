var MF = MF || {};MF.RecordingData = MF.RecordingData || {};MF.RecordingData["session"] = {
  "id": "be4f0fde6babc734a69519fe8f785430",
  "created": "2018-05-29T15:15:27.0634258-07:00",
  "lastActivity": "2018-05-29T15:15:42.7730598-07:00",
  "pageViews": [
    {
      "id": "052927804c301c9da8e54f3255909dbeb790e65d",
      "startTime": "2018-05-29T15:15:27.0634258-07:00",
      "endTime": "2018-05-29T15:15:42.7730598-07:00",
      "title": "FOX2YP",
      "uri": "https://warm-citadel-75324.herokuapp.com/",
      "websitePage": "/10",
      "visitTime": 15830,
      "engagementTime": 13351,
      "scroll": 100.0,
      "tags": [
        "form-interact"
      ],
      "friction": 0,
      "annotations": []
    }
  ],
  "duration": 15830,
  "engagementTime": 13351,
  "totalFriction": 0,
  "country": "us",
  "region": "CA",
  "city": "La Jolla",
  "isp": "University of California, San Diego",
  "ip": "128.54.68.32",
  "lang": "en-US",
  "userAgent": "Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/66.0.3359.181 Safari/537.36",
  "browser": "Chrome",
  "browserVersion": "66.0.3359.181",
  "os": "Windows",
  "osVersion": "7",
  "device": "Desktop",
  "referrer": "",
  "referrerType": "",
  "screenRes": "1920x1200",
  "tags": [
    "form-interact"
  ],
  "variables": [
    "SID=8TUB0",
    "CONDITION=114"
  ],
  "watched": false,
  "starred": false,
  "lng": -117.2359,
  "lat": 32.8807,
  "visitorId": "9ac6e8e08481fff3c0fa4b0722d047ad",
  "gdpr": false
}