var MF = MF || {};MF.RecordingData = MF.RecordingData || {};MF.RecordingData["session"] = {
  "id": "efa42ef4bf996c3c469cd7d605dd14ea",
  "created": "2018-05-24T12:03:27.1754753-07:00",
  "lastActivity": "2018-05-24T12:06:04.4160452-07:00",
  "pageViews": [
    {
      "id": "05242749774d583abc237bc33ba05e32143a2d78",
      "startTime": "2018-05-24T12:03:27.2719197-07:00",
      "endTime": "2018-05-24T12:06:04.4160452-07:00",
      "title": "FOX2YP",
      "uri": "https://warm-citadel-75324.herokuapp.com/",
      "websitePage": "/",
      "visitTime": 157255,
      "engagementTime": 72362,
      "scroll": 100.0,
      "tags": [
        "form-interact"
      ],
      "friction": 0,
      "annotations": []
    }
  ],
  "duration": 157255,
  "engagementTime": 72362,
  "totalFriction": 0,
  "country": "us",
  "region": "CA",
  "city": "La Jolla",
  "isp": "University of California, San Diego",
  "ip": "128.54.68.36",
  "lang": "en-US",
  "userAgent": "Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/66.0.3359.181 Safari/537.36",
  "browser": "Chrome",
  "browserVersion": "66.0.3359.181",
  "os": "Windows",
  "osVersion": "7",
  "device": "Desktop",
  "referrer": "",
  "referrerType": "",
  "screenRes": "1920x1200",
  "tags": [
    "form-interact"
  ],
  "variables": [],
  "watched": false,
  "starred": false,
  "lng": -117.2359,
  "lat": 32.8807,
  "visitorId": "c4ef6c87815b75dd4779d1e1fae7f436",
  "gdpr": false
}