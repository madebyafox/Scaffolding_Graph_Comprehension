var MF = MF || {};MF.RecordingData = MF.RecordingData || {};MF.RecordingData["session"] = {
  "id": "9c361844ae4fb925e35926b9dd0a9b1d",
  "created": "2018-05-29T16:07:37.0009118-07:00",
  "lastActivity": "2018-05-29T16:08:34.8621502-07:00",
  "pageViews": [
    {
      "id": "0529369434af935cefdbfbf9236b1712feddaac3",
      "startTime": "2018-05-29T16:07:37.0009118-07:00",
      "endTime": "2018-05-29T16:08:34.8621502-07:00",
      "title": "FOX2YP",
      "uri": "https://warm-citadel-75324.herokuapp.com/",
      "websitePage": "/3",
      "visitTime": 57918,
      "engagementTime": 26465,
      "scroll": 100.0,
      "tags": [
        "form-interact"
      ],
      "friction": 0,
      "annotations": []
    }
  ],
  "duration": 57918,
  "engagementTime": 26465,
  "totalFriction": 0,
  "country": "us",
  "region": "CA",
  "city": "La Jolla",
  "isp": "University of California, San Diego",
  "ip": "128.54.68.37",
  "lang": "en-US",
  "userAgent": "Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/66.0.3359.181 Safari/537.36",
  "browser": "Chrome",
  "browserVersion": "66.0.3359.181",
  "os": "Windows",
  "osVersion": "7",
  "device": "Desktop",
  "referrer": "",
  "referrerType": "",
  "screenRes": "1920x1200",
  "tags": [
    "form-interact"
  ],
  "variables": [
    "SID=8FE87",
    "CONDITION=113",
    "ORTH_CORRECT=1"
  ],
  "watched": false,
  "starred": false,
  "lng": -117.2359,
  "lat": 32.8807,
  "visitorId": "599a113e157bd6ad4215c19a34ae1953",
  "gdpr": false
}