var MF = MF || {};MF.RecordingData = MF.RecordingData || {};MF.RecordingData["session"] = {
  "id": "a9197023d17f054d6d62edbb0d28d5e7",
  "created": "2018-06-01T10:09:44.5354218-07:00",
  "lastActivity": "2018-06-01T10:10:08.7158279-07:00",
  "pageViews": [
    {
      "id": "0601446489474692d95d9d41c7c87868c652817f",
      "startTime": "2018-06-01T10:09:44.7655596-07:00",
      "endTime": "2018-06-01T10:10:08.7158279-07:00",
      "title": "FOX2YP",
      "uri": "https://warm-citadel-75324.herokuapp.com/",
      "websitePage": "/3",
      "visitTime": 24220,
      "engagementTime": 24220,
      "scroll": 100.0,
      "tags": [
        "form-interact"
      ],
      "friction": 0,
      "annotations": []
    }
  ],
  "duration": 24220,
  "engagementTime": 24220,
  "totalFriction": 0,
  "country": "us",
  "region": "CA",
  "city": "La Jolla",
  "isp": "University of California, San Diego",
  "ip": "128.54.68.32",
  "lang": "en-US",
  "userAgent": "Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/66.0.3359.181 Safari/537.36",
  "browser": "Chrome",
  "browserVersion": "66.0.3359.181",
  "os": "Windows",
  "osVersion": "7",
  "device": "Desktop",
  "referrer": "",
  "referrerType": "",
  "screenRes": "1920x1200",
  "tags": [
    "form-interact"
  ],
  "variables": [
    "SID=MWJFN",
    "CONDITION=115",
    "ORTH_CORRECT=1"
  ],
  "watched": false,
  "starred": false,
  "lng": -117.2359,
  "lat": 32.8807,
  "visitorId": "f10b51593b0456d8ab352aa7d76ba15e",
  "gdpr": false
}