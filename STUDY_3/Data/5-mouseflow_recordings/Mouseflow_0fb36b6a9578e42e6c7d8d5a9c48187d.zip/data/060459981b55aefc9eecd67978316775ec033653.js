var MF = MF || {};MF.RecordingData = MF.RecordingData || {};MF.RecordingData["060459981b55aefc9eecd67978316775ec033653"] = {
  "startTime": "2018-06-04T19:09:59.5726902Z",
  "websitePageUrl": "/",
  "visitTime": 129432,
  "engagementTime": 33334,
  "pageTitle": "FOX2YP",
  "url": "https://warm-citadel-75324.herokuapp.com/",
  "viewportWidth": 929,
  "viewportHeight": 1047,
  "tags": [
    "form-interact"
  ],
  "session": {
    "id": "0fb36b6a9578e42e6c7d8d5a9c48187d",
    "created": "2018-06-04T19:09:59.3195114+00:00",
    "lastActivity": "0001-01-01T00:00:00+00:00",
    "pages": 1,
    "duration": 0,
    "engagementTime": 0,
    "totalFriction": 0,
    "country": "us",
    "region": "CA",
    "city": "La Jolla",
    "isp": "University of California, San Diego",
    "ip": "###.###.###.###",
    "lang": "en-US",
    "userAgent": "Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/66.0.3359.181 Safari/537.36",
    "browser": "Chrome",
    "browserVersion": "66.0.3359.181",
    "os": "Windows",
    "osVersion": "7",
    "device": "Desktop",
    "referrer": "",
    "referrerType": "",
    "screenRes": "1920x1200",
    "entryPage": "/",
    "tags": [
      "form-interact"
    ],
    "variables": [],
    "watched": false,
    "starred": false,
    "lng": 32.8807,
    "lat": 32.8807,
    "visitorId": "330a619d168b32e3a375266171e2dd2d",
    "gdpr": false,
    "visitorName": null,
    "playbackUrl": "https://us.mouseflow.com/websites/e0c9ff05-6fcb-4c4a-8173-e5a0724987b1/recordings/0fb36b6a9578e42e6c7d8d5a9c48187d/play"
  },
  "events": [
    {
      "t": 101,
      "e": 101,
      "ty": 0,
      "x": 929,
      "y": 1047
    },
    {
      "t": 266,
      "e": 266,
      "ty": 14,
      "x": 0,
      "y": 1046
    },
    {
      "t": 850,
      "e": 850,
      "ty": 40,
      "x": 0,
      "y": 0
    },
    {
      "t": 900,
      "e": 900,
      "ty": 2,
      "x": 68,
      "y": 3
    },
    {
      "t": 1000,
      "e": 1000,
      "ty": 2,
      "x": 216,
      "y": 32
    },
    {
      "t": 1000,
      "e": 1000,
      "ty": 41,
      "x": 14946,
      "y": 1527,
      "ta": "html > body"
    },
    {
      "t": 1146,
      "e": 1146,
      "ty": 40,
      "x": 0,
      "y": 0
    },
    {
      "t": 1200,
      "e": 1200,
      "ty": 2,
      "x": 254,
      "y": 0
    },
    {
      "t": 1250,
      "e": 1250,
      "ty": 41,
      "x": 18252,
      "y": 0,
      "ta": "html"
    },
    {
      "t": 2800,
      "e": 2800,
      "ty": 0,
      "x": 1920,
      "y": 1094
    },
    {
      "t": 10001,
      "e": 7800,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 103898,
      "e": 7800,
      "ty": 2,
      "x": 315,
      "y": 58
    },
    {
      "t": 103999,
      "e": 7901,
      "ty": 41,
      "x": 10572,
      "y": 3042,
      "ta": "> div.masterdiv"
    },
    {
      "t": 104198,
      "e": 8100,
      "ty": 2,
      "x": 321,
      "y": 60
    },
    {
      "t": 104249,
      "e": 8151,
      "ty": 41,
      "x": 10985,
      "y": 2981,
      "ta": "> div.masterdiv"
    },
    {
      "t": 104299,
      "e": 8201,
      "ty": 2,
      "x": 333,
      "y": 56
    },
    {
      "t": 104398,
      "e": 8300,
      "ty": 2,
      "x": 466,
      "y": 185
    },
    {
      "t": 104499,
      "e": 8401,
      "ty": 2,
      "x": 501,
      "y": 242
    },
    {
      "t": 104499,
      "e": 8401,
      "ty": 41,
      "x": 10210,
      "y": 9606,
      "ta": "> div.masterdiv > div:[2]"
    },
    {
      "t": 104598,
      "e": 8500,
      "ty": 2,
      "x": 504,
      "y": 243
    },
    {
      "t": 104749,
      "e": 8651,
      "ty": 41,
      "x": 10358,
      "y": 9682,
      "ta": "> div.masterdiv > div:[2]"
    },
    {
      "t": 105498,
      "e": 9400,
      "ty": 2,
      "x": 510,
      "y": 243
    },
    {
      "t": 105499,
      "e": 9401,
      "ty": 41,
      "x": 10653,
      "y": 9682,
      "ta": "> div.masterdiv > div:[2]"
    },
    {
      "t": 105599,
      "e": 9501,
      "ty": 2,
      "x": 514,
      "y": 201
    },
    {
      "t": 105698,
      "e": 9600,
      "ty": 2,
      "x": 514,
      "y": 200
    },
    {
      "t": 105749,
      "e": 9651,
      "ty": 41,
      "x": 10850,
      "y": 6411,
      "ta": "> div.masterdiv > div:[2]"
    },
    {
      "t": 105799,
      "e": 9701,
      "ty": 0,
      "x": 1920,
      "y": 1200
    },
    {
      "t": 105799,
      "e": 9701,
      "ty": 2,
      "x": 514,
      "y": 266
    },
    {
      "t": 105998,
      "e": 9900,
      "ty": 41,
      "x": 10850,
      "y": 9674,
      "ta": "> div.masterdiv > div:[2]"
    },
    {
      "t": 106249,
      "e": 10151,
      "ty": 41,
      "x": 12030,
      "y": 49163,
      "ta": "> div.masterdiv > div:[2] > div > p"
    },
    {
      "t": 106299,
      "e": 10201,
      "ty": 2,
      "x": 658,
      "y": 606
    },
    {
      "t": 106398,
      "e": 10300,
      "ty": 2,
      "x": 854,
      "y": 1199
    },
    {
      "t": 106498,
      "e": 10400,
      "ty": 2,
      "x": 842,
      "y": 1199
    },
    {
      "t": 106699,
      "e": 10601,
      "ty": 2,
      "x": 842,
      "y": 1184
    },
    {
      "t": 106749,
      "e": 10651,
      "ty": 41,
      "x": 28824,
      "y": 63152,
      "ta": "> div.masterdiv"
    },
    {
      "t": 106798,
      "e": 10700,
      "ty": 2,
      "x": 845,
      "y": 1127
    },
    {
      "t": 106898,
      "e": 10800,
      "ty": 2,
      "x": 786,
      "y": 1017
    },
    {
      "t": 106998,
      "e": 10900,
      "ty": 2,
      "x": 765,
      "y": 969
    },
    {
      "t": 106999,
      "e": 10901,
      "ty": 41,
      "x": 23198,
      "y": 58354,
      "ta": "> div.masterdiv > div:[2]"
    },
    {
      "t": 107098,
      "e": 11000,
      "ty": 2,
      "x": 765,
      "y": 967
    },
    {
      "t": 107198,
      "e": 11100,
      "ty": 2,
      "x": 775,
      "y": 957
    },
    {
      "t": 107249,
      "e": 11151,
      "ty": 41,
      "x": 24723,
      "y": 56277,
      "ta": "> div.masterdiv > div:[2]"
    },
    {
      "t": 107298,
      "e": 11200,
      "ty": 2,
      "x": 799,
      "y": 936
    },
    {
      "t": 107399,
      "e": 11301,
      "ty": 2,
      "x": 805,
      "y": 934
    },
    {
      "t": 107498,
      "e": 11400,
      "ty": 2,
      "x": 808,
      "y": 931
    },
    {
      "t": 107499,
      "e": 11401,
      "ty": 41,
      "x": 25314,
      "y": 58790,
      "ta": "> div.masterdiv > div:[2] > div > div"
    },
    {
      "t": 107598,
      "e": 11500,
      "ty": 2,
      "x": 809,
      "y": 928
    },
    {
      "t": 107615,
      "e": 11517,
      "ty": 3,
      "x": 809,
      "y": 927,
      "ta": "> div.masterdiv > div:[2] > div > div > label > div"
    },
    {
      "t": 107698,
      "e": 11600,
      "ty": 2,
      "x": 809,
      "y": 927
    },
    {
      "t": 107749,
      "e": 11651,
      "ty": 41,
      "x": 18226,
      "y": 52479,
      "ta": "> div.masterdiv > div:[2] > div > div > label > div"
    },
    {
      "t": 107776,
      "e": 11678,
      "ty": 4,
      "x": 18226,
      "y": 52479,
      "ta": "> div.masterdiv > div:[2] > div > div > label > div"
    },
    {
      "t": 107777,
      "e": 11679,
      "ty": 5,
      "x": 809,
      "y": 927,
      "ta": "> div.masterdiv > div:[2] > div > div > label > div"
    },
    {
      "t": 107780,
      "e": 11682,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#consent_checkbox"
    },
    {
      "t": 107791,
      "e": 11693,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#consent_checkbox",
      "v": "on"
    },
    {
      "t": 107999,
      "e": 11901,
      "ty": 2,
      "x": 906,
      "y": 1103
    },
    {
      "t": 107999,
      "e": 11901,
      "ty": 41,
      "x": 7723,
      "y": 16792,
      "ta": "> div.masterdiv > div:[3]"
    },
    {
      "t": 108099,
      "e": 12001,
      "ty": 2,
      "x": 919,
      "y": 1113
    },
    {
      "t": 108199,
      "e": 12101,
      "ty": 2,
      "x": 930,
      "y": 1084
    },
    {
      "t": 108248,
      "e": 12150,
      "ty": 41,
      "x": 31463,
      "y": 64933,
      "ta": "> div.masterdiv > div:[2]"
    },
    {
      "t": 108298,
      "e": 12200,
      "ty": 2,
      "x": 933,
      "y": 1064
    },
    {
      "t": 108398,
      "e": 12300,
      "ty": 2,
      "x": 931,
      "y": 1101
    },
    {
      "t": 108472,
      "e": 12374,
      "ty": 3,
      "x": 931,
      "y": 1101,
      "ta": "#start"
    },
    {
      "t": 108474,
      "e": 12376,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#consent_checkbox"
    },
    {
      "t": 108475,
      "e": 12377,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#start"
    },
    {
      "t": 108499,
      "e": 12401,
      "ty": 41,
      "x": 11741,
      "y": 54572,
      "ta": "#start"
    },
    {
      "t": 108599,
      "e": 12501,
      "ty": 4,
      "x": 11741,
      "y": 54572,
      "ta": "#start"
    },
    {
      "t": 108600,
      "e": 12502,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#start"
    },
    {
      "t": 108602,
      "e": 12504,
      "ty": 38,
      "x": 1,
      "y": 0
    },
    {
      "t": 108602,
      "e": 12504,
      "ty": 5,
      "x": 931,
      "y": 1101,
      "ta": "#start"
    },
    {
      "t": 109498,
      "e": 13400,
      "ty": 2,
      "x": 841,
      "y": 943
    },
    {
      "t": 109499,
      "e": 13401,
      "ty": 41,
      "x": 28686,
      "y": 51796,
      "ta": "html > body"
    },
    {
      "t": 109609,
      "e": 13511,
      "ty": 38,
      "x": 2,
      "y": 0
    },
    {
      "t": 109998,
      "e": 13900,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 110098,
      "e": 14000,
      "ty": 2,
      "x": 859,
      "y": 899
    },
    {
      "t": 110198,
      "e": 14100,
      "ty": 2,
      "x": 883,
      "y": 769
    },
    {
      "t": 110248,
      "e": 14150,
      "ty": 41,
      "x": 17519,
      "y": 60602,
      "ta": "#jspsych-survey-text-1"
    },
    {
      "t": 110261,
      "e": 14163,
      "ty": 6,
      "x": 890,
      "y": 682,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 110278,
      "e": 14180,
      "ty": 7,
      "x": 890,
      "y": 669,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 110298,
      "e": 14200,
      "ty": 2,
      "x": 890,
      "y": 663
    },
    {
      "t": 110399,
      "e": 14301,
      "ty": 2,
      "x": 890,
      "y": 647
    },
    {
      "t": 110498,
      "e": 14400,
      "ty": 2,
      "x": 884,
      "y": 617
    },
    {
      "t": 110499,
      "e": 14401,
      "ty": 41,
      "x": 16437,
      "y": 1409,
      "ta": "#jspsych-survey-text-1"
    },
    {
      "t": 110530,
      "e": 14432,
      "ty": 6,
      "x": 881,
      "y": 599,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 110563,
      "e": 14465,
      "ty": 7,
      "x": 876,
      "y": 579,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 110599,
      "e": 14501,
      "ty": 2,
      "x": 876,
      "y": 579
    },
    {
      "t": 110671,
      "e": 14573,
      "ty": 3,
      "x": 876,
      "y": 579,
      "ta": "#jspsych-survey-text-0"
    },
    {
      "t": 110749,
      "e": 14651,
      "ty": 41,
      "x": 14707,
      "y": 40166,
      "ta": "#jspsych-survey-text-0"
    },
    {
      "t": 110775,
      "e": 14677,
      "ty": 4,
      "x": 14707,
      "y": 40166,
      "ta": "#jspsych-survey-text-0"
    },
    {
      "t": 110776,
      "e": 14678,
      "ty": 5,
      "x": 876,
      "y": 579,
      "ta": "#jspsych-survey-text-0"
    },
    {
      "t": 111047,
      "e": 14949,
      "ty": 6,
      "x": 875,
      "y": 587,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 111099,
      "e": 15001,
      "ty": 2,
      "x": 875,
      "y": 599
    },
    {
      "t": 111144,
      "e": 15046,
      "ty": 3,
      "x": 874,
      "y": 599,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 111146,
      "e": 15048,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 111198,
      "e": 15100,
      "ty": 2,
      "x": 874,
      "y": 599
    },
    {
      "t": 111249,
      "e": 15151,
      "ty": 41,
      "x": 14274,
      "y": 40569,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 111255,
      "e": 15157,
      "ty": 4,
      "x": 14274,
      "y": 40569,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 111255,
      "e": 15157,
      "ty": 5,
      "x": 874,
      "y": 599,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 111296,
      "e": 15198,
      "ty": 7,
      "x": 891,
      "y": 607,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 111298,
      "e": 15200,
      "ty": 2,
      "x": 891,
      "y": 607
    },
    {
      "t": 111399,
      "e": 15301,
      "ty": 2,
      "x": 901,
      "y": 612
    },
    {
      "t": 111499,
      "e": 15401,
      "ty": 41,
      "x": 20114,
      "y": 63420,
      "ta": "#jspsych-survey-text-0"
    },
    {
      "t": 111932,
      "e": 15834,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "16"
    },
    {
      "t": 112202,
      "e": 16104,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "89"
    },
    {
      "t": 112202,
      "e": 16104,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 112290,
      "e": 16192,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "Y"
    },
    {
      "t": 112491,
      "e": 16393,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "65"
    },
    {
      "t": 112492,
      "e": 16394,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 112603,
      "e": 16505,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "YA"
    },
    {
      "t": 112643,
      "e": 16545,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "YA"
    },
    {
      "t": 113235,
      "e": 17137,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "78"
    },
    {
      "t": 113236,
      "e": 17138,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 113314,
      "e": 17216,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "YAN"
    },
    {
      "t": 113451,
      "e": 17353,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "75"
    },
    {
      "t": 113451,
      "e": 17353,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 113571,
      "e": 17473,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "YANK"
    },
    {
      "t": 113586,
      "e": 17488,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "69"
    },
    {
      "t": 113587,
      "e": 17489,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 113674,
      "e": 17576,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "+||E"
    },
    {
      "t": 113754,
      "e": 17656,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "69"
    },
    {
      "t": 113755,
      "e": 17657,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 113827,
      "e": 17729,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "+||E"
    },
    {
      "t": 113915,
      "e": 17817,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "+||"
    },
    {
      "t": 114100,
      "e": 18002,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "9"
    },
    {
      "t": 114101,
      "e": 18003,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "YANKEE"
    },
    {
      "t": 114101,
      "e": 18003,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 114102,
      "e": 18004,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 114210,
      "e": 18112,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": ""
    },
    {
      "t": 114963,
      "e": 18865,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "51"
    },
    {
      "t": 114964,
      "e": 18866,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 115091,
      "e": 18993,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "3"
    },
    {
      "t": 115106,
      "e": 19008,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "49"
    },
    {
      "t": 115107,
      "e": 19009,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 115195,
      "e": 19097,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "31"
    },
    {
      "t": 115259,
      "e": 19161,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "49"
    },
    {
      "t": 115260,
      "e": 19162,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 115348,
      "e": 19250,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "31*"
    },
    {
      "t": 115999,
      "e": 19901,
      "ty": 2,
      "x": 932,
      "y": 640
    },
    {
      "t": 115999,
      "e": 19901,
      "ty": 41,
      "x": 26819,
      "y": 16383,
      "ta": "#jspsych-survey-text-1 > p"
    },
    {
      "t": 116099,
      "e": 20001,
      "ty": 2,
      "x": 952,
      "y": 674
    },
    {
      "t": 116199,
      "e": 20101,
      "ty": 2,
      "x": 952,
      "y": 677
    },
    {
      "t": 116208,
      "e": 20110,
      "ty": 6,
      "x": 952,
      "y": 679,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 116248,
      "e": 20150,
      "ty": 41,
      "x": 31145,
      "y": 28086,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 116267,
      "e": 20169,
      "ty": 7,
      "x": 951,
      "y": 710,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 116267,
      "e": 20169,
      "ty": 6,
      "x": 951,
      "y": 710,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 116299,
      "e": 20201,
      "ty": 2,
      "x": 950,
      "y": 719
    },
    {
      "t": 116359,
      "e": 20261,
      "ty": 3,
      "x": 949,
      "y": 720,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 116360,
      "e": 20262,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "31*"
    },
    {
      "t": 116360,
      "e": 20262,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 116360,
      "e": 20262,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 116399,
      "e": 20301,
      "ty": 2,
      "x": 949,
      "y": 720
    },
    {
      "t": 116455,
      "e": 20357,
      "ty": 4,
      "x": 27355,
      "y": 23830,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 116458,
      "e": 20360,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 116460,
      "e": 20362,
      "ty": 5,
      "x": 949,
      "y": 720,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 116460,
      "e": 20362,
      "ty": 38,
      "x": 3,
      "y": 0
    },
    {
      "t": 116499,
      "e": 20401,
      "ty": 41,
      "x": 32405,
      "y": 39442,
      "ta": "html > body"
    },
    {
      "t": 117548,
      "e": 21450,
      "ty": 38,
      "x": 4,
      "y": 0
    },
    {
      "t": 117579,
      "e": 21481,
      "ty": 6,
      "x": 949,
      "y": 720,
      "ta": "> div.masterdiv > div:[2] > div > ul > li:[2]"
    },
    {
      "t": 120000,
      "e": 23902,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 122000,
      "e": 25902,
      "ty": 2,
      "x": 949,
      "y": 721
    },
    {
      "t": 122000,
      "e": 25902,
      "ty": 41,
      "x": 31258,
      "y": 51528,
      "ta": "> div.masterdiv > div:[2] > div > ul > li:[2]"
    },
    {
      "t": 122025,
      "e": 25927,
      "ty": 7,
      "x": 891,
      "y": 729,
      "ta": "> div.masterdiv > div:[2] > div > ul > li:[2]"
    },
    {
      "t": 122027,
      "e": 25929,
      "ty": 6,
      "x": 891,
      "y": 729,
      "ta": "> div.masterdiv > div:[2] > div > ul > li:[3]"
    },
    {
      "t": 122100,
      "e": 26002,
      "ty": 2,
      "x": 891,
      "y": 729
    },
    {
      "t": 122159,
      "e": 26061,
      "ty": 7,
      "x": 866,
      "y": 799,
      "ta": "> div.masterdiv > div:[2] > div > ul > li:[3]"
    },
    {
      "t": 122201,
      "e": 26103,
      "ty": 2,
      "x": 821,
      "y": 1166
    },
    {
      "t": 122301,
      "e": 26203,
      "ty": 2,
      "x": 807,
      "y": 1199
    },
    {
      "t": 122400,
      "e": 26302,
      "ty": 2,
      "x": 807,
      "y": 1197
    },
    {
      "t": 122500,
      "e": 26402,
      "ty": 2,
      "x": 811,
      "y": 1144
    },
    {
      "t": 122501,
      "e": 26403,
      "ty": 41,
      "x": 27653,
      "y": 62931,
      "ta": "> div.masterdiv"
    },
    {
      "t": 122600,
      "e": 26502,
      "ty": 2,
      "x": 812,
      "y": 1139
    },
    {
      "t": 122675,
      "e": 26577,
      "ty": 6,
      "x": 951,
      "y": 1100,
      "ta": "#start"
    },
    {
      "t": 122700,
      "e": 26602,
      "ty": 2,
      "x": 994,
      "y": 1095
    },
    {
      "t": 122751,
      "e": 26653,
      "ty": 41,
      "x": 55431,
      "y": 33369,
      "ta": "#start"
    },
    {
      "t": 122800,
      "e": 26702,
      "ty": 2,
      "x": 1011,
      "y": 1090
    },
    {
      "t": 123003,
      "e": 26905,
      "ty": 3,
      "x": 1011,
      "y": 1090,
      "ta": "#start"
    },
    {
      "t": 123004,
      "e": 26906,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#start"
    },
    {
      "t": 123097,
      "e": 26999,
      "ty": 4,
      "x": 55431,
      "y": 33369,
      "ta": "#start"
    },
    {
      "t": 123099,
      "e": 27001,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#start"
    },
    {
      "t": 123101,
      "e": 27003,
      "ty": 5,
      "x": 1011,
      "y": 1090,
      "ta": "#start"
    },
    {
      "t": 123107,
      "e": 27009,
      "ty": 38,
      "x": 5,
      "y": 0
    },
    {
      "t": 123700,
      "e": 27602,
      "ty": 2,
      "x": 1012,
      "y": 1089
    },
    {
      "t": 123750,
      "e": 27652,
      "ty": 41,
      "x": 34575,
      "y": 59884,
      "ta": "html > body"
    },
    {
      "t": 124103,
      "e": 28005,
      "ty": 38,
      "x": 6,
      "y": 0
    },
    {
      "t": 124501,
      "e": 28403,
      "ty": 2,
      "x": 1012,
      "y": 1077
    },
    {
      "t": 124501,
      "e": 28403,
      "ty": 41,
      "x": 34575,
      "y": 59219,
      "ta": "html > body"
    },
    {
      "t": 124600,
      "e": 28502,
      "ty": 2,
      "x": 1012,
      "y": 1066
    },
    {
      "t": 124700,
      "e": 28602,
      "ty": 2,
      "x": 1012,
      "y": 1065
    },
    {
      "t": 124750,
      "e": 28652,
      "ty": 41,
      "x": 34541,
      "y": 57391,
      "ta": "html > body"
    },
    {
      "t": 124800,
      "e": 28702,
      "ty": 2,
      "x": 1006,
      "y": 1008
    },
    {
      "t": 124901,
      "e": 28803,
      "ty": 2,
      "x": 1003,
      "y": 999
    },
    {
      "t": 125001,
      "e": 28903,
      "ty": 41,
      "x": 34265,
      "y": 54898,
      "ta": "html > body"
    },
    {
      "t": 125400,
      "e": 29302,
      "ty": 2,
      "x": 1003,
      "y": 1032
    },
    {
      "t": 125501,
      "e": 29403,
      "ty": 41,
      "x": 48170,
      "y": 57343,
      "ta": "> p"
    },
    {
      "t": 126001,
      "e": 29903,
      "ty": 2,
      "x": 1003,
      "y": 1033
    },
    {
      "t": 126001,
      "e": 29903,
      "ty": 41,
      "x": 48170,
      "y": 59683,
      "ta": "> p"
    },
    {
      "t": 127601,
      "e": 31503,
      "ty": 2,
      "x": 1003,
      "y": 1032
    },
    {
      "t": 127701,
      "e": 31603,
      "ty": 2,
      "x": 1030,
      "y": 991
    },
    {
      "t": 127751,
      "e": 31653,
      "ty": 41,
      "x": 35229,
      "y": 54400,
      "ta": "html > body"
    },
    {
      "t": 127800,
      "e": 31702,
      "ty": 2,
      "x": 1031,
      "y": 990
    },
    {
      "t": 128430,
      "e": 32332,
      "ty": 38,
      "x": 7,
      "y": 0
    },
    {
      "t": 129432,
      "e": 33334,
      "ty": 20,
      "x": 0,
      "y": 0
    }
  ],
  "domMutations": [
    {
      "sequence": 1,
      "data": "{\"f\":\"applyChanged\",\"args\":[[{\"id\":60},{\"id\":63},{\"id\":64},{\"id\":74},{\"id\":75},{\"id\":77},{\"id\":78},{\"id\":80},{\"id\":79},{\"id\":76},{\"id\":65},{\"id\":66},{\"id\":67},{\"id\":68},{\"id\":81},{\"id\":82},{\"id\":84},{\"id\":85},{\"id\":97},{\"id\":86},{\"id\":87},{\"id\":98},{\"id\":88},{\"id\":89},{\"id\":99},{\"id\":90},{\"id\":91},{\"id\":100},{\"id\":92},{\"id\":93},{\"id\":94},{\"id\":95},{\"id\":101},{\"id\":102},{\"id\":104},{\"id\":105},{\"id\":106},{\"id\":107},{\"id\":108},{\"id\":103},{\"id\":96},{\"id\":83},{\"id\":69},{\"id\":70},{\"id\":71},{\"id\":109},{\"id\":110},{\"id\":112},{\"id\":111},{\"id\":72},{\"id\":73},{\"id\":61},{\"id\":62}],[],[],[]]}"
    },
    {
      "sequence": 2,
      "data": "{\"f\":\"applyChanged\",\"args\":[[],[{\"nodeType\":1,\"id\":113,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-text-preamble\",\"class\":\"jspsych-survey-text-preamble\"},\"parentNode\":{\"id\":55}},{\"nodeType\":1,\"id\":114,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-text-0\",\"class\":\"jspsych-survey-text-question\"},\"previousSibling\":{\"id\":113},\"parentNode\":{\"id\":55}},{\"nodeType\":1,\"id\":115,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-text-1\",\"class\":\"jspsych-survey-text-question\"},\"previousSibling\":{\"id\":114},\"parentNode\":{\"id\":55}},{\"nodeType\":1,\"id\":116,\"tagName\":\"BUTTON\",\"attributes\":{\"id\":\"jspsych-survey-text-next\",\"class\":\"jspsych-btn jspsych-survey-text\"},\"previousSibling\":{\"id\":115},\"parentNode\":{\"id\":55}},{\"nodeType\":1,\"id\":117,\"tagName\":\"P\",\"attributes\":{},\"parentNode\":{\"id\":113}},{\"nodeType\":3,\"id\":118,\"textContent\":\"Please enter the following information from your participant card\",\"parentNode\":{\"id\":117}},{\"nodeType\":1,\"id\":119,\"tagName\":\"P\",\"attributes\":{\"class\":\"jspsych-survey-text\"},\"parentNode\":{\"id\":114}},{\"nodeType\":1,\"id\":120,\"tagName\":\"TEXTAREA\",\"attributes\":{\"name\":\"#jspsych-survey-text-response-0\",\"cols\":\"40\",\"rows\":\"1\"},\"previousSibling\":{\"id\":119},\"parentNode\":{\"id\":114}},{\"nodeType\":3,\"id\":121,\"textContent\":\"Session code: \",\"parentNode\":{\"id\":119}},{\"nodeType\":1,\"id\":122,\"tagName\":\"P\",\"attributes\":{\"class\":\"jspsych-survey-text\"},\"parentNode\":{\"id\":115}},{\"nodeType\":1,\"id\":123,\"tagName\":\"TEXTAREA\",\"attributes\":{\"name\":\"#jspsych-survey-text-response-1\",\"cols\":\"40\",\"rows\":\"1\"},\"previousSibling\":{\"id\":122},\"parentNode\":{\"id\":115}},{\"nodeType\":3,\"id\":124,\"textContent\":\"Condition code: \",\"parentNode\":{\"id\":122}},{\"nodeType\":3,\"id\":125,\"textContent\":\"Submit Answers\",\"parentNode\":{\"id\":116}}],[],[]]}"
    },
    {
      "sequence": 3,
      "data": "{\"f\":\"applyChanged\",\"args\":[[{\"id\":113},{\"id\":117},{\"id\":118},{\"id\":114},{\"id\":119},{\"id\":121},{\"id\":120},{\"id\":115},{\"id\":122},{\"id\":124},{\"id\":123},{\"id\":116},{\"id\":125}],[],[],[]]}"
    },
    {
      "sequence": 4,
      "data": "{\"f\":\"applyChanged\",\"args\":[[],[{\"nodeType\":1,\"id\":126,\"tagName\":\"SCRIPT\",\"parentNode\":{\"id\":55}},{\"nodeType\":3,\"id\":127,\"textContent\":\" \",\"previousSibling\":{\"id\":126},\"parentNode\":{\"id\":55}},{\"nodeType\":1,\"id\":128,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"masterdiv\"},\"previousSibling\":{\"id\":127},\"parentNode\":{\"id\":55}},{\"nodeType\":8,\"id\":129,\"previousSibling\":{\"id\":128},\"parentNode\":{\"id\":55}},{\"nodeType\":3,\"id\":130,\"textContent\":\" \",\"previousSibling\":{\"id\":129},\"parentNode\":{\"id\":55}},{\"nodeType\":3,\"id\":131,\"textContent\":\" \\t//set text of scenario descriptions based on scenario randomization order in main switch(scenarios[0]) { case \\\"acme\\\": $('#da1').text(\\\"Answer 15 questions to help a manager coordinate a factory shift schedule.\\\"); break; } \",\"parentNode\":{\"id\":126}},{\"nodeType\":3,\"id\":132,\"textContent\":\" \",\"parentNode\":{\"id\":128}},{\"nodeType\":1,\"id\":133,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"top\"},\"previousSibling\":{\"id\":132},\"parentNode\":{\"id\":128}},{\"nodeType\":8,\"id\":134,\"previousSibling\":{\"id\":133},\"parentNode\":{\"id\":128}},{\"nodeType\":3,\"id\":135,\"textContent\":\" \",\"previousSibling\":{\"id\":134},\"parentNode\":{\"id\":128}},{\"nodeType\":1,\"id\":136,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"instructions\"},\"previousSibling\":{\"id\":135},\"parentNode\":{\"id\":128}},{\"nodeType\":3,\"id\":137,\"textContent\":\" \",\"previousSibling\":{\"id\":136},\"parentNode\":{\"id\":128}},{\"nodeType\":8,\"id\":138,\"previousSibling\":{\"id\":137},\"parentNode\":{\"id\":128}},{\"nodeType\":3,\"id\":139,\"textContent\":\" \",\"previousSibling\":{\"id\":138},\"parentNode\":{\"id\":128}},{\"nodeType\":1,\"id\":140,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bottom\"},\"previousSibling\":{\"id\":139},\"parentNode\":{\"id\":128}},{\"nodeType\":8,\"id\":141,\"previousSibling\":{\"id\":140},\"parentNode\":{\"id\":128}},{\"nodeType\":3,\"id\":142,\"textContent\":\" \",\"previousSibling\":{\"id\":141},\"parentNode\":{\"id\":128}},{\"nodeType\":3,\"id\":143,\"textContent\":\" \",\"parentNode\":{\"id\":133}},{\"nodeType\":1,\"id\":144,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bcent\"},\"previousSibling\":{\"id\":143},\"parentNode\":{\"id\":133}},{\"nodeType\":3,\"id\":145,\"textContent\":\" \",\"previousSibling\":{\"id\":144},\"parentNode\":{\"id\":133}},{\"nodeType\":3,\"id\":146,\"textContent\":\" \",\"parentNode\":{\"id\":144}},{\"nodeType\":1,\"id\":147,\"tagName\":\"H1\",\"attributes\":{},\"previousSibling\":{\"id\":146},\"parentNode\":{\"id\":144}},{\"nodeType\":3,\"id\":148,\"textContent\":\" \",\"previousSibling\":{\"id\":147},\"parentNode\":{\"id\":144}},{\"nodeType\":3,\"id\":149,\"textContent\":\"Instructions\",\"parentNode\":{\"id\":147}},{\"nodeType\":3,\"id\":150,\"textContent\":\" \",\"parentNode\":{\"id\":136}},{\"nodeType\":1,\"id\":151,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"vcent\"},\"previousSibling\":{\"id\":150},\"parentNode\":{\"id\":136}},{\"nodeType\":3,\"id\":152,\"textContent\":\" \",\"previousSibling\":{\"id\":151},\"parentNode\":{\"id\":136}},{\"nodeType\":8,\"id\":153,\"previousSibling\":{\"id\":152},\"parentNode\":{\"id\":136}},{\"nodeType\":3,\"id\":154,\"textContent\":\" \",\"previousSibling\":{\"id\":153},\"parentNode\":{\"id\":136}},{\"nodeType\":3,\"id\":155,\"textContent\":\" \",\"parentNode\":{\"id\":151}},{\"nodeType\":1,\"id\":156,\"tagName\":\"P\",\"attributes\":{},\"previousSibling\":{\"id\":155},\"parentNode\":{\"id\":151}},{\"nodeType\":1,\"id\":157,\"tagName\":\"TABLE\",\"attributes\":{\"cellspacing\":\"0\",\"cellpadding\":\"0\",\"border\":\"0\",\"style\":\"display:block;\"},\"previousSibling\":{\"id\":156},\"parentNode\":{\"id\":151}},{\"nodeType\":3,\"id\":158,\"textContent\":\" \",\"previousSibling\":{\"id\":157},\"parentNode\":{\"id\":151}},{\"nodeType\":1,\"id\":159,\"tagName\":\"P\",\"attributes\":{},\"previousSibling\":{\"id\":158},\"parentNode\":{\"id\":151}},{\"nodeType\":3,\"id\":160,\"textContent\":\" \",\"previousSibling\":{\"id\":159},\"parentNode\":{\"id\":151}},{\"nodeType\":1,\"id\":161,\"tagName\":\"UL\",\"attributes\":{\"class\":\"fa-ul\"},\"previousSibling\":{\"id\":160},\"parentNode\":{\"id\":151}},{\"nodeType\":3,\"id\":162,\"textContent\":\" \",\"previousSibling\":{\"id\":161},\"parentNode\":{\"id\":151}},{\"nodeType\":1,\"id\":163,\"tagName\":\"P\",\"attributes\":{},\"previousSibling\":{\"id\":162},\"parentNode\":{\"id\":151}},{\"nodeType\":3,\"id\":164,\"textContent\":\" \",\"previousSibling\":{\"id\":163},\"parentNode\":{\"id\":151}},{\"nodeType\":3,\"id\":165,\"textContent\":\"We are interested in learning about how people make decisions about time. In this study, you are going to solve a series of problems about scheduling events. To help you solve the problems, we are going to give you a variety of graphs and diagrams. You are going to complete \",\"parentNode\":{\"id\":156}},{\"nodeType\":1,\"id\":166,\"tagName\":\"I\",\"attributes\":{},\"previousSibling\":{\"id\":165},\"parentNode\":{\"id\":156}},{\"nodeType\":3,\"id\":167,\"textContent\":\" of the activities on this computer. \",\"previousSibling\":{\"id\":166},\"parentNode\":{\"id\":156}},{\"nodeType\":3,\"id\":168,\"textContent\":\"all\",\"parentNode\":{\"id\":166}},{\"nodeType\":3,\"id\":169,\"textContent\":\" \",\"parentNode\":{\"id\":157}},{\"nodeType\":1,\"id\":170,\"tagName\":\"TBODY\",\"attributes\":{},\"previousSibling\":{\"id\":169},\"parentNode\":{\"id\":157}},{\"nodeType\":1,\"id\":171,\"tagName\":\"TR\",\"attributes\":{},\"parentNode\":{\"id\":170}},{\"nodeType\":3,\"id\":172,\"textContent\":\" \",\"previousSibling\":{\"id\":171},\"parentNode\":{\"id\":170}},{\"nodeType\":1,\"id\":173,\"tagName\":\"TR\",\"attributes\":{},\"previousSibling\":{\"id\":172},\"parentNode\":{\"id\":170}},{\"nodeType\":3,\"id\":174,\"textContent\":\" \\t\",\"previousSibling\":{\"id\":173},\"parentNode\":{\"id\":170}},{\"nodeType\":1,\"id\":175,\"tagName\":\"TR\",\"attributes\":{\"height\":\"15\"},\"previousSibling\":{\"id\":174},\"parentNode\":{\"id\":170}},{\"nodeType\":3,\"id\":176,\"textContent\":\" \\t\",\"previousSibling\":{\"id\":175},\"parentNode\":{\"id\":170}},{\"nodeType\":1,\"id\":177,\"tagName\":\"TR\",\"attributes\":{},\"previousSibling\":{\"id\":176},\"parentNode\":{\"id\":170}},{\"nodeType\":3,\"id\":178,\"textContent\":\" \",\"previousSibling\":{\"id\":177},\"parentNode\":{\"id\":170}},{\"nodeType\":1,\"id\":179,\"tagName\":\"TR\",\"attributes\":{},\"previousSibling\":{\"id\":178},\"parentNode\":{\"id\":170}},{\"nodeType\":3,\"id\":180,\"textContent\":\" \",\"previousSibling\":{\"id\":179},\"parentNode\":{\"id\":170}},{\"nodeType\":3,\"id\":181,\"textContent\":\" \",\"parentNode\":{\"id\":171}},{\"nodeType\":1,\"id\":182,\"tagName\":\"TD\",\"attributes\":{\"width\":\"40\",\"rowspan\":\"2\"},\"previousSibling\":{\"id\":181},\"parentNode\":{\"id\":171}},{\"nodeType\":3,\"id\":183,\"textContent\":\" \",\"previousSibling\":{\"id\":182},\"parentNode\":{\"id\":171}},{\"nodeType\":1,\"id\":184,\"tagName\":\"TD\",\"attributes\":{},\"previousSibling\":{\"id\":183},\"parentNode\":{\"id\":171}},{\"nodeType\":3,\"id\":185,\"textContent\":\" \",\"previousSibling\":{\"id\":184},\"parentNode\":{\"id\":171}},{\"nodeType\":1,\"id\":186,\"tagName\":\"A\",\"attributes\":{\"class\":\"fa fa-desktop fa-lg\"},\"parentNode\":{\"id\":182}},{\"nodeType\":3,\"id\":187,\"textContent\":\"Acme Factory [20 minutes]\",\"parentNode\":{\"id\":184}},{\"nodeType\":3,\"id\":188,\"textContent\":\" \",\"parentNode\":{\"id\":173}},{\"nodeType\":1,\"id\":189,\"tagName\":\"TD\",\"attributes\":{},\"previousSibling\":{\"id\":188},\"parentNode\":{\"id\":173}},{\"nodeType\":3,\"id\":190,\"textContent\":\" \",\"previousSibling\":{\"id\":189},\"parentNode\":{\"id\":173}},{\"nodeType\":1,\"id\":191,\"tagName\":\"A\",\"attributes\":{\"id\":\"da1\",\"class\":\"subheading\"},\"parentNode\":{\"id\":189}},{\"nodeType\":3,\"id\":192,\"textContent\":\"Answer 15 questions to help a manager coordinate a factory shift schedule.\",\"parentNode\":{\"id\":191}},{\"nodeType\":3,\"id\":193,\"textContent\":\" \",\"parentNode\":{\"id\":177}},{\"nodeType\":1,\"id\":194,\"tagName\":\"TD\",\"attributes\":{\"rowspan\":\"2\"},\"previousSibling\":{\"id\":193},\"parentNode\":{\"id\":177}},{\"nodeType\":3,\"id\":195,\"textContent\":\" \",\"previousSibling\":{\"id\":194},\"parentNode\":{\"id\":177}},{\"nodeType\":1,\"id\":196,\"tagName\":\"TD\",\"attributes\":{},\"previousSibling\":{\"id\":195},\"parentNode\":{\"id\":177}},{\"nodeType\":3,\"id\":197,\"textContent\":\" \",\"previousSibling\":{\"id\":196},\"parentNode\":{\"id\":177}},{\"nodeType\":1,\"id\":198,\"tagName\":\"A\",\"attributes\":{\"class\":\"fa fa-desktop fa-lg\"},\"parentNode\":{\"id\":194}},{\"nodeType\":3,\"id\":199,\"textContent\":\"Final Survey [5 minutes]\",\"parentNode\":{\"id\":196}},{\"nodeType\":3,\"id\":200,\"textContent\":\" \",\"parentNode\":{\"id\":179}},{\"nodeType\":1,\"id\":201,\"tagName\":\"TD\",\"attributes\":{},\"previousSibling\":{\"id\":200},\"parentNode\":{\"id\":179}},{\"nodeType\":3,\"id\":202,\"textContent\":\" \",\"previousSibling\":{\"id\":201},\"parentNode\":{\"id\":179}},{\"nodeType\":1,\"id\":203,\"tagName\":\"I\",\"attributes\":{},\"parentNode\":{\"id\":201}},{\"nodeType\":3,\"id\":204,\"textContent\":\"Complete a demographic survey and feedback on your experience.\",\"parentNode\":{\"id\":203}},{\"nodeType\":1,\"id\":205,\"tagName\":\"B\",\"attributes\":{},\"parentNode\":{\"id\":159}},{\"nodeType\":3,\"id\":206,\"textContent\":\" \",\"previousSibling\":{\"id\":205},\"parentNode\":{\"id\":159}},{\"nodeType\":3,\"id\":207,\"textContent\":\"To ensure accurate results, please:\",\"parentNode\":{\"id\":205}},{\"nodeType\":3,\"id\":208,\"textContent\":\" \\t\",\"parentNode\":{\"id\":161}},{\"nodeType\":1,\"id\":209,\"tagName\":\"LI\",\"attributes\":{},\"previousSibling\":{\"id\":208},\"parentNode\":{\"id\":161}},{\"nodeType\":3,\"id\":210,\"textContent\":\" \\t\",\"previousSibling\":{\"id\":209},\"parentNode\":{\"id\":161}},{\"nodeType\":1,\"id\":211,\"tagName\":\"LI\",\"attributes\":{},\"previousSibling\":{\"id\":210},\"parentNode\":{\"id\":161}},{\"nodeType\":3,\"id\":212,\"textContent\":\" \\t\",\"previousSibling\":{\"id\":211},\"parentNode\":{\"id\":161}},{\"nodeType\":1,\"id\":213,\"tagName\":\"LI\",\"attributes\":{},\"previousSibling\":{\"id\":212},\"parentNode\":{\"id\":161}},{\"nodeType\":3,\"id\":214,\"textContent\":\" \\t\",\"previousSibling\":{\"id\":213},\"parentNode\":{\"id\":161}},{\"nodeType\":1,\"id\":215,\"tagName\":\"LI\",\"attributes\":{},\"previousSibling\":{\"id\":214},\"parentNode\":{\"id\":161}},{\"nodeType\":3,\"id\":216,\"textContent\":\" \",\"previousSibling\":{\"id\":215},\"parentNode\":{\"id\":161}},{\"nodeType\":1,\"id\":217,\"tagName\":\"I\",\"attributes\":{\"class\":\"fa-li fa fa-check\",\"style\":\"color:green\"},\"parentNode\":{\"id\":209}},{\"nodeType\":3,\"id\":218,\"textContent\":\"DO read all instructions \",\"previousSibling\":{\"id\":217},\"parentNode\":{\"id\":209}},{\"nodeType\":1,\"id\":219,\"tagName\":\"I\",\"attributes\":{},\"previousSibling\":{\"id\":218},\"parentNode\":{\"id\":209}},{\"nodeType\":3,\"id\":220,\"textContent\":\" \",\"previousSibling\":{\"id\":219},\"parentNode\":{\"id\":209}},{\"nodeType\":3,\"id\":221,\"textContent\":\"carefully\",\"parentNode\":{\"id\":219}},{\"nodeType\":1,\"id\":222,\"tagName\":\"I\",\"attributes\":{\"class\":\"fa-li fa fa-close\",\"style\":\"color:#EA4335\"},\"parentNode\":{\"id\":211}},{\"nodeType\":3,\"id\":223,\"textContent\":\"DO NOT close this browser window\",\"previousSibling\":{\"id\":222},\"parentNode\":{\"id\":211}},{\"nodeType\":1,\"id\":224,\"tagName\":\"I\",\"attributes\":{\"class\":\"fa-li fa fa-close\",\"style\":\"color:#EA4335\"},\"parentNode\":{\"id\":213}},{\"nodeType\":3,\"id\":225,\"textContent\":\"DO NOT try to return to a previous page \",\"previousSibling\":{\"id\":224},\"parentNode\":{\"id\":213}},{\"nodeType\":1,\"id\":226,\"tagName\":\"I\",\"attributes\":{\"class\":\"fa-li fa fa-close\",\"style\":\"color:#EA4335\"},\"parentNode\":{\"id\":215}},{\"nodeType\":3,\"id\":227,\"textContent\":\"DO NOT use the back button on the mouse or web browser\",\"previousSibling\":{\"id\":226},\"parentNode\":{\"id\":215}},{\"nodeType\":3,\"id\":228,\"textContent\":\"If you have questions at any time, please raise your hand and the experimenter will assist you. \",\"parentNode\":{\"id\":163}},{\"nodeType\":3,\"id\":229,\"textContent\":\" \\t\",\"parentNode\":{\"id\":140}},{\"nodeType\":1,\"id\":230,\"tagName\":\"BUTTON\",\"attributes\":{\"class\":\"btn\",\"type\":\"button\",\"id\":\"start\"},\"previousSibling\":{\"id\":229},\"parentNode\":{\"id\":140}},{\"nodeType\":3,\"id\":231,\"textContent\":\" \",\"previousSibling\":{\"id\":230},\"parentNode\":{\"id\":140}},{\"nodeType\":3,\"id\":232,\"textContent\":\"BEGIN\",\"parentNode\":{\"id\":230}}],[],[]]}"
    },
    {
      "sequence": 5,
      "data": "{\"f\":\"applyChanged\",\"args\":[[{\"id\":126},{\"id\":131},{\"id\":127},{\"id\":128},{\"id\":132},{\"id\":133},{\"id\":143},{\"id\":144},{\"id\":146},{\"id\":147},{\"id\":149},{\"id\":148},{\"id\":145},{\"id\":134},{\"id\":135},{\"id\":136},{\"id\":150},{\"id\":151},{\"id\":155},{\"id\":156},{\"id\":165},{\"id\":166},{\"id\":168},{\"id\":167},{\"id\":157},{\"id\":169},{\"id\":170},{\"id\":171},{\"id\":181},{\"id\":182},{\"id\":186},{\"id\":183},{\"id\":184},{\"id\":187},{\"id\":185},{\"id\":172},{\"id\":173},{\"id\":188},{\"id\":189},{\"id\":191},{\"id\":192},{\"id\":190},{\"id\":174},{\"id\":175},{\"id\":176},{\"id\":177},{\"id\":193},{\"id\":194},{\"id\":198},{\"id\":195},{\"id\":196},{\"id\":199},{\"id\":197},{\"id\":178},{\"id\":179},{\"id\":200},{\"id\":201},{\"id\":203},{\"id\":204},{\"id\":202},{\"id\":180},{\"id\":158},{\"id\":159},{\"id\":205},{\"id\":207},{\"id\":206},{\"id\":160},{\"id\":161},{\"id\":208},{\"id\":209},{\"id\":217},{\"id\":218},{\"id\":219},{\"id\":221},{\"id\":220},{\"id\":210},{\"id\":211},{\"id\":222},{\"id\":223},{\"id\":212},{\"id\":213},{\"id\":224},{\"id\":225},{\"id\":214},{\"id\":215},{\"id\":226},{\"id\":227},{\"id\":216},{\"id\":162},{\"id\":163},{\"id\":228},{\"id\":164},{\"id\":152},{\"id\":153},{\"id\":154},{\"id\":137},{\"id\":138},{\"id\":139},{\"id\":140},{\"id\":229},{\"id\":230},{\"id\":232},{\"id\":231},{\"id\":141},{\"id\":142},{\"id\":129},{\"id\":130}],[],[],[]]}"
    },
    {
      "sequence": 6,
      "data": "{\"f\":\"applyChanged\",\"args\":[[],[{\"nodeType\":1,\"id\":233,\"tagName\":\"IMG\",\"attributes\":{\"src\":\"img/acme.png\",\"id\":\"jspsych-single-stim-stimulus\"},\"parentNode\":{\"id\":55}},{\"nodeType\":1,\"id\":234,\"tagName\":\"P\",\"attributes\":{\"style\":\"font-style:italic;\"},\"previousSibling\":{\"id\":233},\"parentNode\":{\"id\":55}},{\"nodeType\":3,\"id\":235,\"textContent\":\"Press enter to continue\",\"parentNode\":{\"id\":234}}],[],[]]}"
    },
    {
      "sequence": 7,
      "data": "{\"f\":\"applyChanged\",\"args\":[[{\"id\":233},{\"id\":234},{\"id\":235}],[],[],[]]}"
    }
  ],
  "initialDom": "{\"f\":\"initialize\",\"args\":[1,[{\"nodeType\":10,\"id\":2,\"name\":\"html\",\"publicId\":\"\",\"systemId\":\"\"},{\"nodeType\":1,\"id\":3,\"tagName\":\"HTML\",\"attributes\":{\"class\":\"fa-events-icons-ready\"},\"childNodes\":[{\"nodeType\":1,\"id\":4,\"tagName\":\"HEAD\",\"attributes\":{},\"childNodes\":[{\"nodeType\":3,\"id\":5,\"textContent\":\" \"},{\"nodeType\":1,\"id\":6,\"tagName\":\"TITLE\",\"attributes\":{},\"childNodes\":[{\"nodeType\":3,\"id\":7,\"textContent\":\"FOX2YP\"}]},{\"nodeType\":3,\"id\":8,\"textContent\":\" \"},{\"nodeType\":8,\"id\":9},{\"nodeType\":3,\"id\":10,\"textContent\":\" \"},{\"nodeType\":1,\"id\":11,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":12,\"textContent\":\" \"},{\"nodeType\":1,\"id\":13,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":14,\"textContent\":\" \"},{\"nodeType\":1,\"id\":15,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":16,\"textContent\":\" \"},{\"nodeType\":1,\"id\":17,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":18,\"textContent\":\" \"},{\"nodeType\":1,\"id\":19,\"tagName\":\"SCRIPT\"},{\"nodeType\":1,\"id\":20,\"tagName\":\"LINK\",\"attributes\":{\"href\":\"https://use.fontawesome.com/945539d961.css\",\"media\":\"all\",\"rel\":\"stylesheet\"}},{\"nodeType\":3,\"id\":21,\"textContent\":\" \"},{\"nodeType\":8,\"id\":22},{\"nodeType\":3,\"id\":23,\"textContent\":\" \"},{\"nodeType\":1,\"id\":24,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":25,\"textContent\":\" \"},{\"nodeType\":1,\"id\":26,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":27,\"textContent\":\" \"},{\"nodeType\":1,\"id\":28,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":29,\"textContent\":\" \"},{\"nodeType\":1,\"id\":30,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":31,\"textContent\":\" \"},{\"nodeType\":1,\"id\":32,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":33,\"textContent\":\" \"},{\"nodeType\":1,\"id\":34,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":35,\"textContent\":\" \"},{\"nodeType\":1,\"id\":36,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":37,\"textContent\":\" \"},{\"nodeType\":8,\"id\":38},{\"nodeType\":3,\"id\":39,\"textContent\":\" \"},{\"nodeType\":1,\"id\":40,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":41,\"textContent\":\" \"},{\"nodeType\":8,\"id\":42},{\"nodeType\":3,\"id\":43,\"textContent\":\" \"},{\"nodeType\":8,\"id\":44},{\"nodeType\":3,\"id\":45,\"textContent\":\" \"},{\"nodeType\":1,\"id\":46,\"tagName\":\"LINK\",\"attributes\":{\"href\":\"../views/jsPsych/css/jspsych.css\",\"rel\":\"stylesheet\",\"type\":\"text/css\"}},{\"nodeType\":3,\"id\":47,\"textContent\":\" \"},{\"nodeType\":1,\"id\":48,\"tagName\":\"LINK\",\"attributes\":{\"href\":\"../css/styles.css\",\"rel\":\"stylesheet\",\"type\":\"text/css\"}},{\"nodeType\":3,\"id\":49,\"textContent\":\" \"},{\"nodeType\":1,\"id\":50,\"tagName\":\"SCRIPT\"},{\"nodeType\":1,\"id\":51,\"tagName\":\"SCRIPT\"}]},{\"nodeType\":3,\"id\":52,\"textContent\":\" \"},{\"nodeType\":8,\"id\":53},{\"nodeType\":3,\"id\":54,\"textContent\":\" \"},{\"nodeType\":1,\"id\":55,\"tagName\":\"BODY\",\"attributes\":{\"class\":\"jspsych-display-element\"},\"childNodes\":[{\"nodeType\":3,\"id\":56,\"textContent\":\" \"},{\"nodeType\":1,\"id\":57,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":58,\"textContent\":\" \"},{\"nodeType\":1,\"id\":59,\"tagName\":\"IMG\",\"attributes\":{\"src\":\"img/phone.png\",\"id\":\"jspsych-single-stim-stimulus\"}}]}]}]]}",
  "useCssProxy": true,
  "loadTimes": "es: 245, dom: 584, initialDom: 592",
  "javascriptErrors": []
}