var MF = MF || {};MF.RecordingData = MF.RecordingData || {};MF.RecordingData["05243522f37dd4de9cbcd7db7060a48fcb144227"] = {
  "startTime": "2018-05-24T19:03:36.2580495Z",
  "websitePageUrl": "/",
  "visitTime": 141158,
  "engagementTime": 49964,
  "pageTitle": "FOX2YP",
  "url": "https://warm-citadel-75324.herokuapp.com/",
  "viewportWidth": 1888,
  "viewportHeight": 1067,
  "tags": [
    "form-interact"
  ],
  "session": {
    "id": "7cfa22f11016cd0048e7f1ed838042c2",
    "created": "2018-05-24T19:03:36.1337755+00:00",
    "lastActivity": "0001-01-01T00:00:00+00:00",
    "pages": 1,
    "duration": 0,
    "engagementTime": 0,
    "totalFriction": 0,
    "country": "us",
    "region": "CA",
    "city": "La Jolla",
    "isp": "University of California, San Diego",
    "ip": "###.###.###.###",
    "lang": "en-US",
    "userAgent": "Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/66.0.3359.181 Safari/537.36",
    "browser": "Chrome",
    "browserVersion": "66.0.3359.181",
    "os": "Windows",
    "osVersion": "7",
    "device": "Desktop",
    "referrer": "",
    "referrerType": "",
    "screenRes": "1920x1200",
    "entryPage": "/",
    "tags": [
      "form-interact"
    ],
    "variables": [],
    "watched": false,
    "starred": false,
    "lng": 32.8807,
    "lat": 32.8807,
    "visitorId": "a4e298ed7abd374519982b3c19a07f1d",
    "gdpr": false,
    "visitorName": null,
    "playbackUrl": "https://us.mouseflow.com/websites/e0c9ff05-6fcb-4c4a-8173-e5a0724987b1/recordings/7cfa22f11016cd0048e7f1ed838042c2/play"
  },
  "events": [
    {
      "t": 101,
      "e": 101,
      "ty": 0,
      "x": 1888,
      "y": 1067
    },
    {
      "t": 373,
      "e": 373,
      "ty": 14,
      "x": 0,
      "y": 1066
    },
    {
      "t": 9686,
      "e": 5101,
      "ty": 40,
      "x": 0,
      "y": 0
    },
    {
      "t": 9705,
      "e": 5120,
      "ty": 0,
      "x": 1920,
      "y": 1200
    },
    {
      "t": 9705,
      "e": 5120,
      "ty": 2,
      "x": 322,
      "y": 63
    },
    {
      "t": 9750,
      "e": 5165,
      "ty": 41,
      "x": 10813,
      "y": 3046,
      "ta": "html > body"
    },
    {
      "t": 10000,
      "e": 5415,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 70204,
      "e": 10165,
      "ty": 2,
      "x": 326,
      "y": 63
    },
    {
      "t": 70254,
      "e": 10215,
      "ty": 41,
      "x": 11054,
      "y": 3046,
      "ta": "> div.masterdiv"
    },
    {
      "t": 70304,
      "e": 10265,
      "ty": 2,
      "x": 329,
      "y": 63
    },
    {
      "t": 70754,
      "e": 10715,
      "ty": 41,
      "x": 11915,
      "y": 2326,
      "ta": "> div.masterdiv"
    },
    {
      "t": 70803,
      "e": 10764,
      "ty": 2,
      "x": 445,
      "y": 11
    },
    {
      "t": 70903,
      "e": 10864,
      "ty": 2,
      "x": 425,
      "y": 102
    },
    {
      "t": 71004,
      "e": 10965,
      "ty": 2,
      "x": 540,
      "y": 706
    },
    {
      "t": 71004,
      "e": 10965,
      "ty": 41,
      "x": 12129,
      "y": 15454,
      "ta": "> div.masterdiv > div:[2] > div > p:[3]"
    },
    {
      "t": 71103,
      "e": 11064,
      "ty": 2,
      "x": 789,
      "y": 1199
    },
    {
      "t": 71204,
      "e": 11165,
      "ty": 2,
      "x": 1080,
      "y": 1199
    },
    {
      "t": 71254,
      "e": 11215,
      "ty": 41,
      "x": 38398,
      "y": 64150,
      "ta": "> div.masterdiv"
    },
    {
      "t": 71303,
      "e": 11264,
      "ty": 2,
      "x": 1125,
      "y": 1161
    },
    {
      "t": 71504,
      "e": 11465,
      "ty": 2,
      "x": 1090,
      "y": 1181
    },
    {
      "t": 71504,
      "e": 11465,
      "ty": 41,
      "x": 37261,
      "y": 64981,
      "ta": "> div.masterdiv"
    },
    {
      "t": 71603,
      "e": 11564,
      "ty": 2,
      "x": 918,
      "y": 1184
    },
    {
      "t": 71703,
      "e": 11664,
      "ty": 2,
      "x": 703,
      "y": 956
    },
    {
      "t": 71753,
      "e": 11714,
      "ty": 41,
      "x": 18033,
      "y": 61291,
      "ta": "> div.masterdiv > div:[2] > div"
    },
    {
      "t": 71804,
      "e": 11765,
      "ty": 2,
      "x": 660,
      "y": 893
    },
    {
      "t": 71904,
      "e": 11865,
      "ty": 2,
      "x": 689,
      "y": 875
    },
    {
      "t": 72003,
      "e": 11964,
      "ty": 2,
      "x": 728,
      "y": 862
    },
    {
      "t": 72004,
      "e": 11965,
      "ty": 41,
      "x": 21378,
      "y": 36296,
      "ta": "> div.masterdiv > div:[2] > div > p:[4]"
    },
    {
      "t": 72104,
      "e": 12065,
      "ty": 2,
      "x": 771,
      "y": 853
    },
    {
      "t": 72203,
      "e": 12164,
      "ty": 2,
      "x": 779,
      "y": 851
    },
    {
      "t": 72254,
      "e": 12215,
      "ty": 41,
      "x": 24281,
      "y": 33956,
      "ta": "> div.masterdiv > div:[2] > div > p:[4]"
    },
    {
      "t": 72303,
      "e": 12264,
      "ty": 2,
      "x": 788,
      "y": 876
    },
    {
      "t": 72404,
      "e": 12365,
      "ty": 2,
      "x": 793,
      "y": 903
    },
    {
      "t": 72504,
      "e": 12465,
      "ty": 2,
      "x": 793,
      "y": 914
    },
    {
      "t": 72504,
      "e": 12465,
      "ty": 41,
      "x": 24576,
      "y": 20373,
      "ta": "> div.masterdiv > div:[2] > div > div"
    },
    {
      "t": 72604,
      "e": 12565,
      "ty": 2,
      "x": 794,
      "y": 925
    },
    {
      "t": 72702,
      "e": 12663,
      "ty": 2,
      "x": 803,
      "y": 928
    },
    {
      "t": 72753,
      "e": 12714,
      "ty": 41,
      "x": 8396,
      "y": 55755,
      "ta": "> div.masterdiv > div:[2] > div > div > label > div"
    },
    {
      "t": 72804,
      "e": 12765,
      "ty": 2,
      "x": 809,
      "y": 930
    },
    {
      "t": 73004,
      "e": 12965,
      "ty": 41,
      "x": 18226,
      "y": 62309,
      "ta": "> div.masterdiv > div:[2] > div > div > label > div"
    },
    {
      "t": 73113,
      "e": 13074,
      "ty": 3,
      "x": 809,
      "y": 930,
      "ta": "> div.masterdiv > div:[2] > div > div > label > div"
    },
    {
      "t": 73175,
      "e": 13136,
      "ty": 4,
      "x": 18226,
      "y": 62309,
      "ta": "> div.masterdiv > div:[2] > div > div > label > div"
    },
    {
      "t": 73175,
      "e": 13136,
      "ty": 5,
      "x": 809,
      "y": 930,
      "ta": "> div.masterdiv > div:[2] > div > div > label > div"
    },
    {
      "t": 73177,
      "e": 13138,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#consent_checkbox"
    },
    {
      "t": 73180,
      "e": 13141,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#consent_checkbox",
      "v": "on"
    },
    {
      "t": 73504,
      "e": 13465,
      "ty": 2,
      "x": 977,
      "y": 1031
    },
    {
      "t": 73504,
      "e": 13465,
      "ty": 41,
      "x": 33628,
      "y": 62648,
      "ta": "> div.masterdiv > div:[2]"
    },
    {
      "t": 73603,
      "e": 13564,
      "ty": 2,
      "x": 1083,
      "y": 1118
    },
    {
      "t": 73754,
      "e": 13715,
      "ty": 41,
      "x": 36882,
      "y": 61490,
      "ta": "> div.masterdiv"
    },
    {
      "t": 73803,
      "e": 13764,
      "ty": 2,
      "x": 1022,
      "y": 1114
    },
    {
      "t": 73904,
      "e": 13865,
      "ty": 2,
      "x": 971,
      "y": 1107
    },
    {
      "t": 74004,
      "e": 13965,
      "ty": 2,
      "x": 964,
      "y": 1107
    },
    {
      "t": 74004,
      "e": 13965,
      "ty": 41,
      "x": 34873,
      "y": 19008,
      "ta": "> div.masterdiv > div:[3]"
    },
    {
      "t": 74204,
      "e": 14165,
      "ty": 2,
      "x": 958,
      "y": 1095
    },
    {
      "t": 74253,
      "e": 14214,
      "ty": 41,
      "x": 24848,
      "y": 31442,
      "ta": "#start"
    },
    {
      "t": 74303,
      "e": 14264,
      "ty": 2,
      "x": 955,
      "y": 1089
    },
    {
      "t": 74360,
      "e": 14321,
      "ty": 3,
      "x": 955,
      "y": 1089,
      "ta": "#start"
    },
    {
      "t": 74360,
      "e": 14321,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#consent_checkbox"
    },
    {
      "t": 74362,
      "e": 14323,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#start"
    },
    {
      "t": 74432,
      "e": 14393,
      "ty": 4,
      "x": 24848,
      "y": 31442,
      "ta": "#start"
    },
    {
      "t": 74436,
      "e": 14397,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#start"
    },
    {
      "t": 74439,
      "e": 14400,
      "ty": 38,
      "x": 1,
      "y": 0
    },
    {
      "t": 74439,
      "e": 14400,
      "ty": 5,
      "x": 955,
      "y": 1089,
      "ta": "#start"
    },
    {
      "t": 75444,
      "e": 15405,
      "ty": 38,
      "x": 2,
      "y": 0
    },
    {
      "t": 76202,
      "e": 16163,
      "ty": 2,
      "x": 941,
      "y": 1058
    },
    {
      "t": 76253,
      "e": 16214,
      "ty": 41,
      "x": 31131,
      "y": 55286,
      "ta": "html > body"
    },
    {
      "t": 76302,
      "e": 16263,
      "ty": 2,
      "x": 908,
      "y": 1004
    },
    {
      "t": 76403,
      "e": 16364,
      "ty": 2,
      "x": 925,
      "y": 865
    },
    {
      "t": 76502,
      "e": 16463,
      "ty": 2,
      "x": 925,
      "y": 495
    },
    {
      "t": 76503,
      "e": 16464,
      "ty": 41,
      "x": 28328,
      "y": 44470,
      "ta": "#jspsych-survey-text-preamble > p"
    },
    {
      "t": 76602,
      "e": 16563,
      "ty": 2,
      "x": 925,
      "y": 492
    },
    {
      "t": 76703,
      "e": 16664,
      "ty": 2,
      "x": 900,
      "y": 527
    },
    {
      "t": 76745,
      "e": 16706,
      "ty": 6,
      "x": 838,
      "y": 586,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 76753,
      "e": 16714,
      "ty": 41,
      "x": 6488,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 76778,
      "e": 16739,
      "ty": 7,
      "x": 810,
      "y": 609,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 76802,
      "e": 16763,
      "ty": 2,
      "x": 810,
      "y": 609
    },
    {
      "t": 76903,
      "e": 16864,
      "ty": 2,
      "x": 810,
      "y": 610
    },
    {
      "t": 77003,
      "e": 16964,
      "ty": 41,
      "x": 432,
      "y": 62011,
      "ta": "#jspsych-survey-text-0"
    },
    {
      "t": 77102,
      "e": 17063,
      "ty": 2,
      "x": 813,
      "y": 607
    },
    {
      "t": 77112,
      "e": 17073,
      "ty": 6,
      "x": 815,
      "y": 605,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 77202,
      "e": 17163,
      "ty": 2,
      "x": 818,
      "y": 602
    },
    {
      "t": 77253,
      "e": 17214,
      "ty": 41,
      "x": 2162,
      "y": 49931,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 77329,
      "e": 17290,
      "ty": 3,
      "x": 818,
      "y": 602,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 77331,
      "e": 17292,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 77383,
      "e": 17344,
      "ty": 4,
      "x": 2162,
      "y": 49931,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 77383,
      "e": 17344,
      "ty": 5,
      "x": 818,
      "y": 602,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 77678,
      "e": 17639,
      "ty": 7,
      "x": 802,
      "y": 608,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 77703,
      "e": 17664,
      "ty": 2,
      "x": 785,
      "y": 612
    },
    {
      "t": 77753,
      "e": 17714,
      "ty": 41,
      "x": 25793,
      "y": 33958,
      "ta": "html > body"
    },
    {
      "t": 77802,
      "e": 17763,
      "ty": 2,
      "x": 739,
      "y": 627
    },
    {
      "t": 77903,
      "e": 17864,
      "ty": 2,
      "x": 699,
      "y": 639
    },
    {
      "t": 78003,
      "e": 17964,
      "ty": 2,
      "x": 588,
      "y": 656
    },
    {
      "t": 78003,
      "e": 17964,
      "ty": 41,
      "x": 19973,
      "y": 35897,
      "ta": "html > body"
    },
    {
      "t": 79643,
      "e": 19604,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "75"
    },
    {
      "t": 79643,
      "e": 19604,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 79723,
      "e": 19684,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "k"
    },
    {
      "t": 79820,
      "e": 19781,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "73"
    },
    {
      "t": 79821,
      "e": 19782,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 79899,
      "e": 19860,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "ki"
    },
    {
      "t": 80003,
      "e": 19964,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 80008,
      "e": 19969,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "ki"
    },
    {
      "t": 80051,
      "e": 20012,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "76"
    },
    {
      "t": 80051,
      "e": 20012,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 80139,
      "e": 20100,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "kil"
    },
    {
      "t": 80243,
      "e": 20204,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "79"
    },
    {
      "t": 80244,
      "e": 20205,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 80307,
      "e": 20268,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "kilo"
    },
    {
      "t": 80408,
      "e": 20369,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "kilo"
    },
    {
      "t": 82003,
      "e": 21964,
      "ty": 2,
      "x": 613,
      "y": 713
    },
    {
      "t": 82003,
      "e": 21964,
      "ty": 41,
      "x": 20834,
      "y": 39055,
      "ta": "html > body"
    },
    {
      "t": 82103,
      "e": 22064,
      "ty": 2,
      "x": 640,
      "y": 745
    },
    {
      "t": 82203,
      "e": 22164,
      "ty": 2,
      "x": 652,
      "y": 754
    },
    {
      "t": 82254,
      "e": 22215,
      "ty": 41,
      "x": 22281,
      "y": 41437,
      "ta": "html > body"
    },
    {
      "t": 82303,
      "e": 22264,
      "ty": 2,
      "x": 669,
      "y": 757
    },
    {
      "t": 82403,
      "e": 22364,
      "ty": 2,
      "x": 838,
      "y": 735
    },
    {
      "t": 82502,
      "e": 22463,
      "ty": 2,
      "x": 850,
      "y": 721
    },
    {
      "t": 82502,
      "e": 22463,
      "ty": 41,
      "x": 28996,
      "y": 39498,
      "ta": "html > body"
    },
    {
      "t": 82533,
      "e": 22494,
      "ty": 6,
      "x": 852,
      "y": 697,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 82600,
      "e": 22561,
      "ty": 7,
      "x": 854,
      "y": 678,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 82603,
      "e": 22564,
      "ty": 2,
      "x": 854,
      "y": 678
    },
    {
      "t": 82753,
      "e": 22714,
      "ty": 41,
      "x": 9949,
      "y": 44394,
      "ta": "#jspsych-survey-text-1"
    },
    {
      "t": 82783,
      "e": 22744,
      "ty": 6,
      "x": 848,
      "y": 679,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 82803,
      "e": 22764,
      "ty": 2,
      "x": 845,
      "y": 681
    },
    {
      "t": 82903,
      "e": 22864,
      "ty": 2,
      "x": 840,
      "y": 686
    },
    {
      "t": 83003,
      "e": 22964,
      "ty": 41,
      "x": 6921,
      "y": 21845,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 83032,
      "e": 22993,
      "ty": 3,
      "x": 840,
      "y": 686,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 83033,
      "e": 22994,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "kilo"
    },
    {
      "t": 83034,
      "e": 22995,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 83034,
      "e": 22995,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 83119,
      "e": 23080,
      "ty": 4,
      "x": 6921,
      "y": 21845,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 83119,
      "e": 23080,
      "ty": 5,
      "x": 840,
      "y": 686,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 83403,
      "e": 23364,
      "ty": 2,
      "x": 839,
      "y": 686
    },
    {
      "t": 83503,
      "e": 23464,
      "ty": 41,
      "x": 6704,
      "y": 21845,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 84524,
      "e": 24485,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "49"
    },
    {
      "t": 84524,
      "e": 24485,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 84586,
      "e": 24547,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "1"
    },
    {
      "t": 84707,
      "e": 24668,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "49"
    },
    {
      "t": 84707,
      "e": 24668,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 84762,
      "e": 24723,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "11"
    },
    {
      "t": 85755,
      "e": 25716,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "51"
    },
    {
      "t": 85755,
      "e": 25716,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 85827,
      "e": 25788,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "11*"
    },
    {
      "t": 87087,
      "e": 27048,
      "ty": 7,
      "x": 932,
      "y": 701,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 87104,
      "e": 27065,
      "ty": 2,
      "x": 953,
      "y": 701
    },
    {
      "t": 87144,
      "e": 27105,
      "ty": 6,
      "x": 958,
      "y": 699,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 87203,
      "e": 27164,
      "ty": 2,
      "x": 960,
      "y": 698
    },
    {
      "t": 87237,
      "e": 27198,
      "ty": 7,
      "x": 993,
      "y": 709,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 87238,
      "e": 27199,
      "ty": 6,
      "x": 993,
      "y": 709,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 87253,
      "e": 27214,
      "ty": 7,
      "x": 1029,
      "y": 726,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 87254,
      "e": 27215,
      "ty": 41,
      "x": 35160,
      "y": 39775,
      "ta": "html > body"
    },
    {
      "t": 87303,
      "e": 27264,
      "ty": 2,
      "x": 1077,
      "y": 743
    },
    {
      "t": 87403,
      "e": 27364,
      "ty": 2,
      "x": 1081,
      "y": 747
    },
    {
      "t": 87504,
      "e": 27465,
      "ty": 2,
      "x": 1087,
      "y": 748
    },
    {
      "t": 87504,
      "e": 27465,
      "ty": 41,
      "x": 37158,
      "y": 40993,
      "ta": "html > body"
    },
    {
      "t": 88703,
      "e": 28664,
      "ty": 2,
      "x": 1082,
      "y": 747
    },
    {
      "t": 88754,
      "e": 28715,
      "ty": 41,
      "x": 36986,
      "y": 40938,
      "ta": "html > body"
    },
    {
      "t": 89003,
      "e": 28964,
      "ty": 2,
      "x": 1066,
      "y": 741
    },
    {
      "t": 89003,
      "e": 28964,
      "ty": 41,
      "x": 36435,
      "y": 40606,
      "ta": "html > body"
    },
    {
      "t": 89104,
      "e": 29065,
      "ty": 2,
      "x": 1052,
      "y": 736
    },
    {
      "t": 89203,
      "e": 29164,
      "ty": 2,
      "x": 1034,
      "y": 736
    },
    {
      "t": 89222,
      "e": 29183,
      "ty": 6,
      "x": 1019,
      "y": 736,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 89253,
      "e": 29214,
      "ty": 41,
      "x": 58794,
      "y": 55605,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 89303,
      "e": 29264,
      "ty": 2,
      "x": 997,
      "y": 735
    },
    {
      "t": 89503,
      "e": 29464,
      "ty": 41,
      "x": 52094,
      "y": 53619,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 90003,
      "e": 29964,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 90169,
      "e": 30130,
      "ty": 3,
      "x": 997,
      "y": 735,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 90169,
      "e": 30130,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "11*"
    },
    {
      "t": 90170,
      "e": 30131,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 90171,
      "e": 30132,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 90231,
      "e": 30192,
      "ty": 4,
      "x": 52094,
      "y": 53619,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 90232,
      "e": 30193,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 90232,
      "e": 30193,
      "ty": 5,
      "x": 997,
      "y": 735,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 90232,
      "e": 30193,
      "ty": 38,
      "x": 3,
      "y": 0
    },
    {
      "t": 91319,
      "e": 31280,
      "ty": 38,
      "x": 4,
      "y": 0
    },
    {
      "t": 91351,
      "e": 31312,
      "ty": 6,
      "x": 997,
      "y": 735,
      "ta": "> div.masterdiv > div:[2] > div > ul > li:[3]"
    },
    {
      "t": 100003,
      "e": 36312,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 122706,
      "e": 36312,
      "ty": 2,
      "x": 999,
      "y": 740
    },
    {
      "t": 122707,
      "e": 36313,
      "ty": 7,
      "x": 1001,
      "y": 758,
      "ta": "> div.masterdiv > div:[2] > div > ul > li:[3]"
    },
    {
      "t": 122708,
      "e": 36314,
      "ty": 6,
      "x": 1001,
      "y": 758,
      "ta": "> div.masterdiv > div:[2] > div > ul > li:[4]"
    },
    {
      "t": 122719,
      "e": 36325,
      "ty": 7,
      "x": 1004,
      "y": 784,
      "ta": "> div.masterdiv > div:[2] > div > ul > li:[4]"
    },
    {
      "t": 122756,
      "e": 36362,
      "ty": 41,
      "x": 35104,
      "y": 50391,
      "ta": "> div.masterdiv > div:[2]"
    },
    {
      "t": 122806,
      "e": 36412,
      "ty": 2,
      "x": 1007,
      "y": 908
    },
    {
      "t": 122906,
      "e": 36512,
      "ty": 2,
      "x": 1009,
      "y": 988
    },
    {
      "t": 122987,
      "e": 36593,
      "ty": 6,
      "x": 972,
      "y": 1085,
      "ta": "#start"
    },
    {
      "t": 123006,
      "e": 36612,
      "ty": 2,
      "x": 970,
      "y": 1106
    },
    {
      "t": 123006,
      "e": 36612,
      "ty": 41,
      "x": 33040,
      "y": 64209,
      "ta": "#start"
    },
    {
      "t": 123020,
      "e": 36626,
      "ty": 7,
      "x": 968,
      "y": 1120,
      "ta": "#start"
    },
    {
      "t": 123106,
      "e": 36712,
      "ty": 2,
      "x": 961,
      "y": 1136
    },
    {
      "t": 123206,
      "e": 36812,
      "ty": 2,
      "x": 960,
      "y": 1137
    },
    {
      "t": 123256,
      "e": 36862,
      "ty": 41,
      "x": 33469,
      "y": 29534,
      "ta": "> div.masterdiv > div:[3]"
    },
    {
      "t": 123306,
      "e": 36912,
      "ty": 2,
      "x": 962,
      "y": 1113
    },
    {
      "t": 123506,
      "e": 37112,
      "ty": 2,
      "x": 962,
      "y": 1109
    },
    {
      "t": 123506,
      "e": 37112,
      "ty": 41,
      "x": 33937,
      "y": 20116,
      "ta": "> div.masterdiv > div:[3]"
    },
    {
      "t": 123518,
      "e": 37124,
      "ty": 6,
      "x": 962,
      "y": 1105,
      "ta": "#start"
    },
    {
      "t": 123606,
      "e": 37212,
      "ty": 2,
      "x": 962,
      "y": 1094
    },
    {
      "t": 123757,
      "e": 37363,
      "ty": 41,
      "x": 28671,
      "y": 41079,
      "ta": "#start"
    },
    {
      "t": 124060,
      "e": 37666,
      "ty": 3,
      "x": 962,
      "y": 1094,
      "ta": "#start"
    },
    {
      "t": 124061,
      "e": 37667,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#start"
    },
    {
      "t": 124147,
      "e": 37753,
      "ty": 4,
      "x": 28671,
      "y": 41079,
      "ta": "#start"
    },
    {
      "t": 124149,
      "e": 37755,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#start"
    },
    {
      "t": 124150,
      "e": 37756,
      "ty": 5,
      "x": 962,
      "y": 1094,
      "ta": "#start"
    },
    {
      "t": 124153,
      "e": 37759,
      "ty": 38,
      "x": 5,
      "y": 0
    },
    {
      "t": 125153,
      "e": 38759,
      "ty": 38,
      "x": 6,
      "y": 0
    },
    {
      "t": 126606,
      "e": 40212,
      "ty": 2,
      "x": 962,
      "y": 1093
    },
    {
      "t": 126706,
      "e": 40312,
      "ty": 2,
      "x": 1200,
      "y": 1010
    },
    {
      "t": 126757,
      "e": 40363,
      "ty": 41,
      "x": 43012,
      "y": 54954,
      "ta": "html > body"
    },
    {
      "t": 126806,
      "e": 40412,
      "ty": 2,
      "x": 1301,
      "y": 980
    },
    {
      "t": 126906,
      "e": 40512,
      "ty": 2,
      "x": 1437,
      "y": 899
    },
    {
      "t": 127006,
      "e": 40612,
      "ty": 2,
      "x": 1464,
      "y": 860
    },
    {
      "t": 127006,
      "e": 40612,
      "ty": 41,
      "x": 57258,
      "y": 55479,
      "ta": "#jspsych-single-stim-stimulus"
    },
    {
      "t": 127106,
      "e": 40712,
      "ty": 2,
      "x": 1464,
      "y": 856
    },
    {
      "t": 127206,
      "e": 40812,
      "ty": 2,
      "x": 1382,
      "y": 820
    },
    {
      "t": 127256,
      "e": 40862,
      "ty": 41,
      "x": 52403,
      "y": 51674,
      "ta": "#jspsych-single-stim-stimulus"
    },
    {
      "t": 127307,
      "e": 40913,
      "ty": 2,
      "x": 1363,
      "y": 811
    },
    {
      "t": 127506,
      "e": 41112,
      "ty": 41,
      "x": 52355,
      "y": 51674,
      "ta": "#jspsych-single-stim-stimulus"
    },
    {
      "t": 127606,
      "e": 41212,
      "ty": 2,
      "x": 1512,
      "y": 1001
    },
    {
      "t": 127706,
      "e": 41312,
      "ty": 2,
      "x": 1582,
      "y": 1053
    },
    {
      "t": 127756,
      "e": 41362,
      "ty": 41,
      "x": 54239,
      "y": 57890,
      "ta": "html > body"
    },
    {
      "t": 127806,
      "e": 41412,
      "ty": 2,
      "x": 1571,
      "y": 1050
    },
    {
      "t": 127906,
      "e": 41512,
      "ty": 2,
      "x": 1560,
      "y": 1043
    },
    {
      "t": 128006,
      "e": 41612,
      "ty": 2,
      "x": 1556,
      "y": 1040
    },
    {
      "t": 128007,
      "e": 41613,
      "ty": 41,
      "x": 53309,
      "y": 57170,
      "ta": "html > body"
    },
    {
      "t": 130007,
      "e": 43613,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 137807,
      "e": 46613,
      "ty": 2,
      "x": 1514,
      "y": 1035
    },
    {
      "t": 137906,
      "e": 46712,
      "ty": 2,
      "x": 1352,
      "y": 1029
    },
    {
      "t": 138007,
      "e": 46813,
      "ty": 2,
      "x": 1299,
      "y": 1039
    },
    {
      "t": 138007,
      "e": 46813,
      "ty": 41,
      "x": 44459,
      "y": 57114,
      "ta": "html > body"
    },
    {
      "t": 138106,
      "e": 46912,
      "ty": 2,
      "x": 1199,
      "y": 1041
    },
    {
      "t": 138207,
      "e": 47013,
      "ty": 2,
      "x": 1049,
      "y": 1014
    },
    {
      "t": 138257,
      "e": 47063,
      "ty": 41,
      "x": 34162,
      "y": 55064,
      "ta": "html > body"
    },
    {
      "t": 138306,
      "e": 47112,
      "ty": 2,
      "x": 994,
      "y": 1000
    },
    {
      "t": 138506,
      "e": 47312,
      "ty": 41,
      "x": 33955,
      "y": 54954,
      "ta": "html > body"
    },
    {
      "t": 138706,
      "e": 47512,
      "ty": 2,
      "x": 1029,
      "y": 954
    },
    {
      "t": 138756,
      "e": 47562,
      "ty": 41,
      "x": 36286,
      "y": 62467,
      "ta": "#jspsych-single-stim-stimulus"
    },
    {
      "t": 138806,
      "e": 47612,
      "ty": 2,
      "x": 1039,
      "y": 946
    },
    {
      "t": 138906,
      "e": 47712,
      "ty": 2,
      "x": 1044,
      "y": 944
    },
    {
      "t": 139006,
      "e": 47812,
      "ty": 41,
      "x": 36869,
      "y": 62002,
      "ta": "#jspsych-single-stim-stimulus"
    },
    {
      "t": 140153,
      "e": 48959,
      "ty": 38,
      "x": 7,
      "y": 0
    },
    {
      "t": 141158,
      "e": 49964,
      "ty": 20,
      "x": 0,
      "y": 0
    }
  ],
  "domMutations": [
    {
      "sequence": 1,
      "data": "{\"f\":\"applyChanged\",\"args\":[[{\"id\":60},{\"id\":63},{\"id\":64},{\"id\":74},{\"id\":75},{\"id\":77},{\"id\":78},{\"id\":80},{\"id\":79},{\"id\":76},{\"id\":65},{\"id\":66},{\"id\":67},{\"id\":68},{\"id\":81},{\"id\":82},{\"id\":84},{\"id\":85},{\"id\":97},{\"id\":86},{\"id\":87},{\"id\":98},{\"id\":88},{\"id\":89},{\"id\":99},{\"id\":90},{\"id\":91},{\"id\":100},{\"id\":92},{\"id\":93},{\"id\":94},{\"id\":95},{\"id\":101},{\"id\":102},{\"id\":104},{\"id\":105},{\"id\":106},{\"id\":107},{\"id\":108},{\"id\":103},{\"id\":96},{\"id\":83},{\"id\":69},{\"id\":70},{\"id\":71},{\"id\":109},{\"id\":110},{\"id\":112},{\"id\":111},{\"id\":72},{\"id\":73},{\"id\":61},{\"id\":62}],[],[],[]]}"
    },
    {
      "sequence": 2,
      "data": "{\"f\":\"applyChanged\",\"args\":[[],[{\"nodeType\":1,\"id\":113,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-text-preamble\",\"class\":\"jspsych-survey-text-preamble\"},\"parentNode\":{\"id\":55}},{\"nodeType\":1,\"id\":114,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-text-0\",\"class\":\"jspsych-survey-text-question\"},\"previousSibling\":{\"id\":113},\"parentNode\":{\"id\":55}},{\"nodeType\":1,\"id\":115,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-text-1\",\"class\":\"jspsych-survey-text-question\"},\"previousSibling\":{\"id\":114},\"parentNode\":{\"id\":55}},{\"nodeType\":1,\"id\":116,\"tagName\":\"BUTTON\",\"attributes\":{\"id\":\"jspsych-survey-text-next\",\"class\":\"jspsych-btn jspsych-survey-text\"},\"previousSibling\":{\"id\":115},\"parentNode\":{\"id\":55}},{\"nodeType\":1,\"id\":117,\"tagName\":\"P\",\"attributes\":{},\"parentNode\":{\"id\":113}},{\"nodeType\":3,\"id\":118,\"textContent\":\"Please enter the following information from your participant card\",\"parentNode\":{\"id\":117}},{\"nodeType\":1,\"id\":119,\"tagName\":\"P\",\"attributes\":{\"class\":\"jspsych-survey-text\"},\"parentNode\":{\"id\":114}},{\"nodeType\":1,\"id\":120,\"tagName\":\"TEXTAREA\",\"attributes\":{\"name\":\"#jspsych-survey-text-response-0\",\"cols\":\"40\",\"rows\":\"1\"},\"previousSibling\":{\"id\":119},\"parentNode\":{\"id\":114}},{\"nodeType\":3,\"id\":121,\"textContent\":\"Session code: \",\"parentNode\":{\"id\":119}},{\"nodeType\":1,\"id\":122,\"tagName\":\"P\",\"attributes\":{\"class\":\"jspsych-survey-text\"},\"parentNode\":{\"id\":115}},{\"nodeType\":1,\"id\":123,\"tagName\":\"TEXTAREA\",\"attributes\":{\"name\":\"#jspsych-survey-text-response-1\",\"cols\":\"40\",\"rows\":\"1\"},\"previousSibling\":{\"id\":122},\"parentNode\":{\"id\":115}},{\"nodeType\":3,\"id\":124,\"textContent\":\"Condition code: \",\"parentNode\":{\"id\":122}},{\"nodeType\":3,\"id\":125,\"textContent\":\"Submit Answers\",\"parentNode\":{\"id\":116}}],[],[]]}"
    },
    {
      "sequence": 3,
      "data": "{\"f\":\"applyChanged\",\"args\":[[{\"id\":113},{\"id\":117},{\"id\":118},{\"id\":114},{\"id\":119},{\"id\":121},{\"id\":120},{\"id\":115},{\"id\":122},{\"id\":124},{\"id\":123},{\"id\":116},{\"id\":125}],[],[],[]]}"
    },
    {
      "sequence": 4,
      "data": "{\"f\":\"applyChanged\",\"args\":[[],[{\"nodeType\":1,\"id\":126,\"tagName\":\"SCRIPT\",\"parentNode\":{\"id\":55}},{\"nodeType\":3,\"id\":127,\"textContent\":\" \",\"previousSibling\":{\"id\":126},\"parentNode\":{\"id\":55}},{\"nodeType\":1,\"id\":128,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"masterdiv\"},\"previousSibling\":{\"id\":127},\"parentNode\":{\"id\":55}},{\"nodeType\":8,\"id\":129,\"previousSibling\":{\"id\":128},\"parentNode\":{\"id\":55}},{\"nodeType\":3,\"id\":130,\"textContent\":\" \",\"previousSibling\":{\"id\":129},\"parentNode\":{\"id\":55}},{\"nodeType\":3,\"id\":131,\"textContent\":\" \\t//set text of scenario descriptions based on scenario randomization order in main switch(scenarios[0]) { case \\\"acme\\\": $('#da1').text(\\\"Answer 15 questions to help a manager coordinate a factory shift schedule.\\\"); break; } \",\"parentNode\":{\"id\":126}},{\"nodeType\":3,\"id\":132,\"textContent\":\" \",\"parentNode\":{\"id\":128}},{\"nodeType\":1,\"id\":133,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"top\"},\"previousSibling\":{\"id\":132},\"parentNode\":{\"id\":128}},{\"nodeType\":8,\"id\":134,\"previousSibling\":{\"id\":133},\"parentNode\":{\"id\":128}},{\"nodeType\":3,\"id\":135,\"textContent\":\" \",\"previousSibling\":{\"id\":134},\"parentNode\":{\"id\":128}},{\"nodeType\":1,\"id\":136,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"instructions\"},\"previousSibling\":{\"id\":135},\"parentNode\":{\"id\":128}},{\"nodeType\":3,\"id\":137,\"textContent\":\" \",\"previousSibling\":{\"id\":136},\"parentNode\":{\"id\":128}},{\"nodeType\":8,\"id\":138,\"previousSibling\":{\"id\":137},\"parentNode\":{\"id\":128}},{\"nodeType\":3,\"id\":139,\"textContent\":\" \",\"previousSibling\":{\"id\":138},\"parentNode\":{\"id\":128}},{\"nodeType\":1,\"id\":140,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bottom\"},\"previousSibling\":{\"id\":139},\"parentNode\":{\"id\":128}},{\"nodeType\":8,\"id\":141,\"previousSibling\":{\"id\":140},\"parentNode\":{\"id\":128}},{\"nodeType\":3,\"id\":142,\"textContent\":\" \",\"previousSibling\":{\"id\":141},\"parentNode\":{\"id\":128}},{\"nodeType\":3,\"id\":143,\"textContent\":\" \",\"parentNode\":{\"id\":133}},{\"nodeType\":1,\"id\":144,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bcent\"},\"previousSibling\":{\"id\":143},\"parentNode\":{\"id\":133}},{\"nodeType\":3,\"id\":145,\"textContent\":\" \",\"previousSibling\":{\"id\":144},\"parentNode\":{\"id\":133}},{\"nodeType\":3,\"id\":146,\"textContent\":\" \",\"parentNode\":{\"id\":144}},{\"nodeType\":1,\"id\":147,\"tagName\":\"H1\",\"attributes\":{},\"previousSibling\":{\"id\":146},\"parentNode\":{\"id\":144}},{\"nodeType\":3,\"id\":148,\"textContent\":\" \",\"previousSibling\":{\"id\":147},\"parentNode\":{\"id\":144}},{\"nodeType\":3,\"id\":149,\"textContent\":\"Instructions\",\"parentNode\":{\"id\":147}},{\"nodeType\":3,\"id\":150,\"textContent\":\" \",\"parentNode\":{\"id\":136}},{\"nodeType\":1,\"id\":151,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"vcent\"},\"previousSibling\":{\"id\":150},\"parentNode\":{\"id\":136}},{\"nodeType\":3,\"id\":152,\"textContent\":\" \",\"previousSibling\":{\"id\":151},\"parentNode\":{\"id\":136}},{\"nodeType\":8,\"id\":153,\"previousSibling\":{\"id\":152},\"parentNode\":{\"id\":136}},{\"nodeType\":3,\"id\":154,\"textContent\":\" \",\"previousSibling\":{\"id\":153},\"parentNode\":{\"id\":136}},{\"nodeType\":3,\"id\":155,\"textContent\":\" \",\"parentNode\":{\"id\":151}},{\"nodeType\":1,\"id\":156,\"tagName\":\"P\",\"attributes\":{},\"previousSibling\":{\"id\":155},\"parentNode\":{\"id\":151}},{\"nodeType\":1,\"id\":157,\"tagName\":\"TABLE\",\"attributes\":{\"cellspacing\":\"0\",\"cellpadding\":\"0\",\"border\":\"0\",\"style\":\"display:block;\"},\"previousSibling\":{\"id\":156},\"parentNode\":{\"id\":151}},{\"nodeType\":3,\"id\":158,\"textContent\":\" \",\"previousSibling\":{\"id\":157},\"parentNode\":{\"id\":151}},{\"nodeType\":1,\"id\":159,\"tagName\":\"P\",\"attributes\":{},\"previousSibling\":{\"id\":158},\"parentNode\":{\"id\":151}},{\"nodeType\":3,\"id\":160,\"textContent\":\" \",\"previousSibling\":{\"id\":159},\"parentNode\":{\"id\":151}},{\"nodeType\":1,\"id\":161,\"tagName\":\"UL\",\"attributes\":{\"class\":\"fa-ul\"},\"previousSibling\":{\"id\":160},\"parentNode\":{\"id\":151}},{\"nodeType\":3,\"id\":162,\"textContent\":\" \",\"previousSibling\":{\"id\":161},\"parentNode\":{\"id\":151}},{\"nodeType\":1,\"id\":163,\"tagName\":\"P\",\"attributes\":{},\"previousSibling\":{\"id\":162},\"parentNode\":{\"id\":151}},{\"nodeType\":3,\"id\":164,\"textContent\":\" \",\"previousSibling\":{\"id\":163},\"parentNode\":{\"id\":151}},{\"nodeType\":3,\"id\":165,\"textContent\":\"We are interested in learning about how people make decisions about time. In this study, you are going to solve a series of problems about scheduling events. To help you solve the problems, we are going to give you a variety of graphs and diagrams. You are going to complete \",\"parentNode\":{\"id\":156}},{\"nodeType\":1,\"id\":166,\"tagName\":\"I\",\"attributes\":{},\"previousSibling\":{\"id\":165},\"parentNode\":{\"id\":156}},{\"nodeType\":3,\"id\":167,\"textContent\":\" of the activities on this computer. \",\"previousSibling\":{\"id\":166},\"parentNode\":{\"id\":156}},{\"nodeType\":3,\"id\":168,\"textContent\":\"all\",\"parentNode\":{\"id\":166}},{\"nodeType\":3,\"id\":169,\"textContent\":\" \",\"parentNode\":{\"id\":157}},{\"nodeType\":1,\"id\":170,\"tagName\":\"TBODY\",\"attributes\":{},\"previousSibling\":{\"id\":169},\"parentNode\":{\"id\":157}},{\"nodeType\":1,\"id\":171,\"tagName\":\"TR\",\"attributes\":{},\"parentNode\":{\"id\":170}},{\"nodeType\":3,\"id\":172,\"textContent\":\" \",\"previousSibling\":{\"id\":171},\"parentNode\":{\"id\":170}},{\"nodeType\":1,\"id\":173,\"tagName\":\"TR\",\"attributes\":{},\"previousSibling\":{\"id\":172},\"parentNode\":{\"id\":170}},{\"nodeType\":3,\"id\":174,\"textContent\":\" \\t\",\"previousSibling\":{\"id\":173},\"parentNode\":{\"id\":170}},{\"nodeType\":1,\"id\":175,\"tagName\":\"TR\",\"attributes\":{\"height\":\"15\"},\"previousSibling\":{\"id\":174},\"parentNode\":{\"id\":170}},{\"nodeType\":3,\"id\":176,\"textContent\":\" \\t\",\"previousSibling\":{\"id\":175},\"parentNode\":{\"id\":170}},{\"nodeType\":1,\"id\":177,\"tagName\":\"TR\",\"attributes\":{},\"previousSibling\":{\"id\":176},\"parentNode\":{\"id\":170}},{\"nodeType\":3,\"id\":178,\"textContent\":\" \",\"previousSibling\":{\"id\":177},\"parentNode\":{\"id\":170}},{\"nodeType\":1,\"id\":179,\"tagName\":\"TR\",\"attributes\":{},\"previousSibling\":{\"id\":178},\"parentNode\":{\"id\":170}},{\"nodeType\":3,\"id\":180,\"textContent\":\" \",\"previousSibling\":{\"id\":179},\"parentNode\":{\"id\":170}},{\"nodeType\":3,\"id\":181,\"textContent\":\" \",\"parentNode\":{\"id\":171}},{\"nodeType\":1,\"id\":182,\"tagName\":\"TD\",\"attributes\":{\"width\":\"40\",\"rowspan\":\"2\"},\"previousSibling\":{\"id\":181},\"parentNode\":{\"id\":171}},{\"nodeType\":3,\"id\":183,\"textContent\":\" \",\"previousSibling\":{\"id\":182},\"parentNode\":{\"id\":171}},{\"nodeType\":1,\"id\":184,\"tagName\":\"TD\",\"attributes\":{},\"previousSibling\":{\"id\":183},\"parentNode\":{\"id\":171}},{\"nodeType\":3,\"id\":185,\"textContent\":\" \",\"previousSibling\":{\"id\":184},\"parentNode\":{\"id\":171}},{\"nodeType\":1,\"id\":186,\"tagName\":\"A\",\"attributes\":{\"class\":\"fa fa-desktop fa-lg\"},\"parentNode\":{\"id\":182}},{\"nodeType\":3,\"id\":187,\"textContent\":\"Acme Factory [20 minutes]\",\"parentNode\":{\"id\":184}},{\"nodeType\":3,\"id\":188,\"textContent\":\" \",\"parentNode\":{\"id\":173}},{\"nodeType\":1,\"id\":189,\"tagName\":\"TD\",\"attributes\":{},\"previousSibling\":{\"id\":188},\"parentNode\":{\"id\":173}},{\"nodeType\":3,\"id\":190,\"textContent\":\" \",\"previousSibling\":{\"id\":189},\"parentNode\":{\"id\":173}},{\"nodeType\":1,\"id\":191,\"tagName\":\"A\",\"attributes\":{\"id\":\"da1\",\"class\":\"subheading\"},\"parentNode\":{\"id\":189}},{\"nodeType\":3,\"id\":192,\"textContent\":\"Answer 15 questions to help a manager coordinate a factory shift schedule.\",\"parentNode\":{\"id\":191}},{\"nodeType\":3,\"id\":193,\"textContent\":\" \",\"parentNode\":{\"id\":177}},{\"nodeType\":1,\"id\":194,\"tagName\":\"TD\",\"attributes\":{\"rowspan\":\"2\"},\"previousSibling\":{\"id\":193},\"parentNode\":{\"id\":177}},{\"nodeType\":3,\"id\":195,\"textContent\":\" \",\"previousSibling\":{\"id\":194},\"parentNode\":{\"id\":177}},{\"nodeType\":1,\"id\":196,\"tagName\":\"TD\",\"attributes\":{},\"previousSibling\":{\"id\":195},\"parentNode\":{\"id\":177}},{\"nodeType\":3,\"id\":197,\"textContent\":\" \",\"previousSibling\":{\"id\":196},\"parentNode\":{\"id\":177}},{\"nodeType\":1,\"id\":198,\"tagName\":\"A\",\"attributes\":{\"class\":\"fa fa-desktop fa-lg\"},\"parentNode\":{\"id\":194}},{\"nodeType\":3,\"id\":199,\"textContent\":\"Final Survey [5 minutes]\",\"parentNode\":{\"id\":196}},{\"nodeType\":3,\"id\":200,\"textContent\":\" \",\"parentNode\":{\"id\":179}},{\"nodeType\":1,\"id\":201,\"tagName\":\"TD\",\"attributes\":{},\"previousSibling\":{\"id\":200},\"parentNode\":{\"id\":179}},{\"nodeType\":3,\"id\":202,\"textContent\":\" \",\"previousSibling\":{\"id\":201},\"parentNode\":{\"id\":179}},{\"nodeType\":1,\"id\":203,\"tagName\":\"I\",\"attributes\":{},\"parentNode\":{\"id\":201}},{\"nodeType\":3,\"id\":204,\"textContent\":\"Complete a demographic survey and feedback on your experience.\",\"parentNode\":{\"id\":203}},{\"nodeType\":1,\"id\":205,\"tagName\":\"B\",\"attributes\":{},\"parentNode\":{\"id\":159}},{\"nodeType\":3,\"id\":206,\"textContent\":\" \",\"previousSibling\":{\"id\":205},\"parentNode\":{\"id\":159}},{\"nodeType\":3,\"id\":207,\"textContent\":\"To ensure accurate results, please:\",\"parentNode\":{\"id\":205}},{\"nodeType\":3,\"id\":208,\"textContent\":\" \\t\",\"parentNode\":{\"id\":161}},{\"nodeType\":1,\"id\":209,\"tagName\":\"LI\",\"attributes\":{},\"previousSibling\":{\"id\":208},\"parentNode\":{\"id\":161}},{\"nodeType\":3,\"id\":210,\"textContent\":\" \\t\",\"previousSibling\":{\"id\":209},\"parentNode\":{\"id\":161}},{\"nodeType\":1,\"id\":211,\"tagName\":\"LI\",\"attributes\":{},\"previousSibling\":{\"id\":210},\"parentNode\":{\"id\":161}},{\"nodeType\":3,\"id\":212,\"textContent\":\" \\t\",\"previousSibling\":{\"id\":211},\"parentNode\":{\"id\":161}},{\"nodeType\":1,\"id\":213,\"tagName\":\"LI\",\"attributes\":{},\"previousSibling\":{\"id\":212},\"parentNode\":{\"id\":161}},{\"nodeType\":3,\"id\":214,\"textContent\":\" \\t\",\"previousSibling\":{\"id\":213},\"parentNode\":{\"id\":161}},{\"nodeType\":1,\"id\":215,\"tagName\":\"LI\",\"attributes\":{},\"previousSibling\":{\"id\":214},\"parentNode\":{\"id\":161}},{\"nodeType\":3,\"id\":216,\"textContent\":\" \",\"previousSibling\":{\"id\":215},\"parentNode\":{\"id\":161}},{\"nodeType\":1,\"id\":217,\"tagName\":\"I\",\"attributes\":{\"class\":\"fa-li fa fa-check\",\"style\":\"color:green\"},\"parentNode\":{\"id\":209}},{\"nodeType\":3,\"id\":218,\"textContent\":\"DO read all instructions \",\"previousSibling\":{\"id\":217},\"parentNode\":{\"id\":209}},{\"nodeType\":1,\"id\":219,\"tagName\":\"I\",\"attributes\":{},\"previousSibling\":{\"id\":218},\"parentNode\":{\"id\":209}},{\"nodeType\":3,\"id\":220,\"textContent\":\" \",\"previousSibling\":{\"id\":219},\"parentNode\":{\"id\":209}},{\"nodeType\":3,\"id\":221,\"textContent\":\"carefully\",\"parentNode\":{\"id\":219}},{\"nodeType\":1,\"id\":222,\"tagName\":\"I\",\"attributes\":{\"class\":\"fa-li fa fa-close\",\"style\":\"color:#EA4335\"},\"parentNode\":{\"id\":211}},{\"nodeType\":3,\"id\":223,\"textContent\":\"DO NOT close this browser window\",\"previousSibling\":{\"id\":222},\"parentNode\":{\"id\":211}},{\"nodeType\":1,\"id\":224,\"tagName\":\"I\",\"attributes\":{\"class\":\"fa-li fa fa-close\",\"style\":\"color:#EA4335\"},\"parentNode\":{\"id\":213}},{\"nodeType\":3,\"id\":225,\"textContent\":\"DO NOT try to return to a previous page \",\"previousSibling\":{\"id\":224},\"parentNode\":{\"id\":213}},{\"nodeType\":1,\"id\":226,\"tagName\":\"I\",\"attributes\":{\"class\":\"fa-li fa fa-close\",\"style\":\"color:#EA4335\"},\"parentNode\":{\"id\":215}},{\"nodeType\":3,\"id\":227,\"textContent\":\"DO NOT use the back button on the mouse or web browser\",\"previousSibling\":{\"id\":226},\"parentNode\":{\"id\":215}},{\"nodeType\":3,\"id\":228,\"textContent\":\"If you have questions at any time, please raise your hand and the experimenter will assist you. \",\"parentNode\":{\"id\":163}},{\"nodeType\":3,\"id\":229,\"textContent\":\" \\t\",\"parentNode\":{\"id\":140}},{\"nodeType\":1,\"id\":230,\"tagName\":\"BUTTON\",\"attributes\":{\"class\":\"btn\",\"type\":\"button\",\"id\":\"start\"},\"previousSibling\":{\"id\":229},\"parentNode\":{\"id\":140}},{\"nodeType\":3,\"id\":231,\"textContent\":\" \",\"previousSibling\":{\"id\":230},\"parentNode\":{\"id\":140}},{\"nodeType\":3,\"id\":232,\"textContent\":\"BEGIN\",\"parentNode\":{\"id\":230}}],[],[]]}"
    },
    {
      "sequence": 5,
      "data": "{\"f\":\"applyChanged\",\"args\":[[{\"id\":126},{\"id\":131},{\"id\":127},{\"id\":128},{\"id\":132},{\"id\":133},{\"id\":143},{\"id\":144},{\"id\":146},{\"id\":147},{\"id\":149},{\"id\":148},{\"id\":145},{\"id\":134},{\"id\":135},{\"id\":136},{\"id\":150},{\"id\":151},{\"id\":155},{\"id\":156},{\"id\":165},{\"id\":166},{\"id\":168},{\"id\":167},{\"id\":157},{\"id\":169},{\"id\":170},{\"id\":171},{\"id\":181},{\"id\":182},{\"id\":186},{\"id\":183},{\"id\":184},{\"id\":187},{\"id\":185},{\"id\":172},{\"id\":173},{\"id\":188},{\"id\":189},{\"id\":191},{\"id\":192},{\"id\":190},{\"id\":174},{\"id\":175},{\"id\":176},{\"id\":177},{\"id\":193},{\"id\":194},{\"id\":198},{\"id\":195},{\"id\":196},{\"id\":199},{\"id\":197},{\"id\":178},{\"id\":179},{\"id\":200},{\"id\":201},{\"id\":203},{\"id\":204},{\"id\":202},{\"id\":180},{\"id\":158},{\"id\":159},{\"id\":205},{\"id\":207},{\"id\":206},{\"id\":160},{\"id\":161},{\"id\":208},{\"id\":209},{\"id\":217},{\"id\":218},{\"id\":219},{\"id\":221},{\"id\":220},{\"id\":210},{\"id\":211},{\"id\":222},{\"id\":223},{\"id\":212},{\"id\":213},{\"id\":224},{\"id\":225},{\"id\":214},{\"id\":215},{\"id\":226},{\"id\":227},{\"id\":216},{\"id\":162},{\"id\":163},{\"id\":228},{\"id\":164},{\"id\":152},{\"id\":153},{\"id\":154},{\"id\":137},{\"id\":138},{\"id\":139},{\"id\":140},{\"id\":229},{\"id\":230},{\"id\":232},{\"id\":231},{\"id\":141},{\"id\":142},{\"id\":129},{\"id\":130}],[],[],[]]}"
    },
    {
      "sequence": 6,
      "data": "{\"f\":\"applyChanged\",\"args\":[[],[{\"nodeType\":1,\"id\":233,\"tagName\":\"IMG\",\"attributes\":{\"src\":\"img/acme.png\",\"id\":\"jspsych-single-stim-stimulus\"},\"parentNode\":{\"id\":55}},{\"nodeType\":1,\"id\":234,\"tagName\":\"P\",\"attributes\":{\"style\":\"font-style:italic;\"},\"previousSibling\":{\"id\":233},\"parentNode\":{\"id\":55}},{\"nodeType\":3,\"id\":235,\"textContent\":\"Press enter to continue\",\"parentNode\":{\"id\":234}}],[],[]]}"
    },
    {
      "sequence": 7,
      "data": "{\"f\":\"applyChanged\",\"args\":[[{\"id\":233},{\"id\":234},{\"id\":235}],[],[],[]]}"
    }
  ],
  "initialDom": "{\"f\":\"initialize\",\"args\":[1,[{\"nodeType\":10,\"id\":2,\"name\":\"html\",\"publicId\":\"\",\"systemId\":\"\"},{\"nodeType\":1,\"id\":3,\"tagName\":\"HTML\",\"attributes\":{\"class\":\"fa-events-icons-ready\"},\"childNodes\":[{\"nodeType\":1,\"id\":4,\"tagName\":\"HEAD\",\"attributes\":{},\"childNodes\":[{\"nodeType\":3,\"id\":5,\"textContent\":\" \"},{\"nodeType\":1,\"id\":6,\"tagName\":\"TITLE\",\"attributes\":{},\"childNodes\":[{\"nodeType\":3,\"id\":7,\"textContent\":\"FOX2YP\"}]},{\"nodeType\":3,\"id\":8,\"textContent\":\" \"},{\"nodeType\":8,\"id\":9},{\"nodeType\":3,\"id\":10,\"textContent\":\" \"},{\"nodeType\":1,\"id\":11,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":12,\"textContent\":\" \"},{\"nodeType\":1,\"id\":13,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":14,\"textContent\":\" \"},{\"nodeType\":1,\"id\":15,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":16,\"textContent\":\" \"},{\"nodeType\":1,\"id\":17,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":18,\"textContent\":\" \"},{\"nodeType\":1,\"id\":19,\"tagName\":\"SCRIPT\"},{\"nodeType\":1,\"id\":20,\"tagName\":\"LINK\",\"attributes\":{\"href\":\"https://use.fontawesome.com/945539d961.css\",\"media\":\"all\",\"rel\":\"stylesheet\"}},{\"nodeType\":3,\"id\":21,\"textContent\":\" \"},{\"nodeType\":8,\"id\":22},{\"nodeType\":3,\"id\":23,\"textContent\":\" \"},{\"nodeType\":1,\"id\":24,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":25,\"textContent\":\" \"},{\"nodeType\":1,\"id\":26,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":27,\"textContent\":\" \"},{\"nodeType\":1,\"id\":28,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":29,\"textContent\":\" \"},{\"nodeType\":1,\"id\":30,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":31,\"textContent\":\" \"},{\"nodeType\":1,\"id\":32,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":33,\"textContent\":\" \"},{\"nodeType\":1,\"id\":34,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":35,\"textContent\":\" \"},{\"nodeType\":1,\"id\":36,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":37,\"textContent\":\" \"},{\"nodeType\":8,\"id\":38},{\"nodeType\":3,\"id\":39,\"textContent\":\" \"},{\"nodeType\":1,\"id\":40,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":41,\"textContent\":\" \"},{\"nodeType\":8,\"id\":42},{\"nodeType\":3,\"id\":43,\"textContent\":\" \"},{\"nodeType\":8,\"id\":44},{\"nodeType\":3,\"id\":45,\"textContent\":\" \"},{\"nodeType\":1,\"id\":46,\"tagName\":\"LINK\",\"attributes\":{\"href\":\"../views/jsPsych/css/jspsych.css\",\"rel\":\"stylesheet\",\"type\":\"text/css\"}},{\"nodeType\":3,\"id\":47,\"textContent\":\" \"},{\"nodeType\":1,\"id\":48,\"tagName\":\"LINK\",\"attributes\":{\"href\":\"../css/styles.css\",\"rel\":\"stylesheet\",\"type\":\"text/css\"}},{\"nodeType\":3,\"id\":49,\"textContent\":\" \"},{\"nodeType\":1,\"id\":50,\"tagName\":\"SCRIPT\"},{\"nodeType\":1,\"id\":51,\"tagName\":\"SCRIPT\"}]},{\"nodeType\":3,\"id\":52,\"textContent\":\" \"},{\"nodeType\":8,\"id\":53},{\"nodeType\":3,\"id\":54,\"textContent\":\" \"},{\"nodeType\":1,\"id\":55,\"tagName\":\"BODY\",\"attributes\":{\"class\":\"jspsych-display-element\"},\"childNodes\":[{\"nodeType\":3,\"id\":56,\"textContent\":\" \"},{\"nodeType\":1,\"id\":57,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":58,\"textContent\":\" \"},{\"nodeType\":1,\"id\":59,\"tagName\":\"IMG\",\"attributes\":{\"src\":\"img/phone.png\",\"id\":\"jspsych-single-stim-stimulus\"}}]}]}]]}",
  "useCssProxy": true,
  "loadTimes": "es: 106, dom: 658, initialDom: 662",
  "javascriptErrors": []
}