var MF = MF || {};MF.RecordingData = MF.RecordingData || {};MF.RecordingData["session"] = {
  "id": "5ba7e7640c72759ad38441c5658a0354",
  "created": "2018-05-24T12:06:22.2493753-07:00",
  "lastActivity": "2018-05-24T12:06:58.9453753-07:00",
  "pageViews": [
    {
      "id": "0524223812875d7a841fb3d39224413bfb5365eb",
      "startTime": "2018-05-24T12:06:22.2493753-07:00",
      "endTime": "2018-05-24T12:06:58.9453753-07:00",
      "title": "FOX2YP",
      "uri": "https://warm-citadel-75324.herokuapp.com/",
      "websitePage": "/3",
      "visitTime": 36696,
      "engagementTime": 27247,
      "scroll": 100.0,
      "tags": [
        "form-interact"
      ],
      "friction": 0,
      "annotations": []
    }
  ],
  "duration": 36696,
  "engagementTime": 27247,
  "totalFriction": 0,
  "country": "us",
  "region": "CA",
  "city": "La Jolla",
  "isp": "University of California, San Diego",
  "ip": "128.54.68.25",
  "lang": "en-US",
  "userAgent": "Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/66.0.3359.181 Safari/537.36",
  "browser": "Chrome",
  "browserVersion": "66.0.3359.181",
  "os": "Windows",
  "osVersion": "7",
  "device": "Desktop",
  "referrer": "",
  "referrerType": "",
  "screenRes": "1920x1200",
  "tags": [
    "form-interact"
  ],
  "variables": [
    "SID=M3NXB",
    "CONDITION=113"
  ],
  "watched": false,
  "starred": false,
  "lng": -117.2359,
  "lat": 32.8807,
  "visitorId": "a6212864a9c1a71ff4dfa02bd904603d",
  "gdpr": false
}