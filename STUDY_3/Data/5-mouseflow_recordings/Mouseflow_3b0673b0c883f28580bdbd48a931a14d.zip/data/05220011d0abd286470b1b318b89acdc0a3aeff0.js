var MF = MF || {};MF.RecordingData = MF.RecordingData || {};MF.RecordingData["05220011d0abd286470b1b318b89acdc0a3aeff0"] = {
  "startTime": "2018-05-22T19:23:00.0007088Z",
  "websitePageUrl": "/16",
  "visitTime": 125732,
  "engagementTime": 102650,
  "pageTitle": "FOX2YP",
  "url": "https://warm-citadel-75324.herokuapp.com/",
  "viewportWidth": 1920,
  "viewportHeight": 1200,
  "tags": [
    "form-interact",
    "submit"
  ],
  "session": {
    "id": "3b0673b0c883f28580bdbd48a931a14d",
    "created": "2018-05-22T19:23:00.0007088+00:00",
    "lastActivity": "0001-01-01T00:00:00+00:00",
    "pages": 1,
    "duration": 0,
    "engagementTime": 0,
    "totalFriction": 0,
    "country": "us",
    "region": "CA",
    "city": "La Jolla",
    "isp": "University of California, San Diego",
    "ip": "###.###.###.###",
    "lang": "en-US",
    "userAgent": "Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/66.0.3359.181 Safari/537.36",
    "browser": "Chrome",
    "browserVersion": "66.0.3359.181",
    "os": "Windows",
    "osVersion": "7",
    "device": "Desktop",
    "referrer": "",
    "referrerType": "",
    "screenRes": "1920x1200",
    "entryPage": "/16",
    "tags": [
      "form-interact",
      "submit"
    ],
    "variables": [
      "SID=6Y93F",
      "CONDITION=111"
    ],
    "watched": false,
    "starred": false,
    "lng": 32.8807,
    "lat": 32.8807,
    "visitorId": "f814e3d11d2d3b57a409e3a028d6617b",
    "gdpr": false,
    "visitorName": null,
    "playbackUrl": "https://us.mouseflow.com/websites/e0c9ff05-6fcb-4c4a-8173-e5a0724987b1/recordings/3b0673b0c883f28580bdbd48a931a14d/play"
  },
  "events": [
    {
      "t": 2,
      "e": 2,
      "ty": 14,
      "x": 0,
      "y": 1199
    },
    {
      "t": 101,
      "e": 101,
      "ty": 0,
      "x": 1920,
      "y": 1200
    },
    {
      "t": 649,
      "e": 649,
      "ty": 38,
      "x": 1,
      "y": 0
    },
    {
      "t": 1701,
      "e": 1701,
      "ty": 2,
      "x": 504,
      "y": 735
    },
    {
      "t": 1751,
      "e": 1751,
      "ty": 41,
      "x": 44953,
      "y": 39719,
      "ta": "> div.stimulus > div"
    },
    {
      "t": 1801,
      "e": 1801,
      "ty": 2,
      "x": 491,
      "y": 720
    },
    {
      "t": 1900,
      "e": 1900,
      "ty": 2,
      "x": 479,
      "y": 712
    },
    {
      "t": 2001,
      "e": 2001,
      "ty": 2,
      "x": 447,
      "y": 693
    },
    {
      "t": 2001,
      "e": 2001,
      "ty": 41,
      "x": 60107,
      "y": 46703,
      "ta": "> div.stimulus > div > div:[3]"
    },
    {
      "t": 2041,
      "e": 2041,
      "ty": 6,
      "x": 440,
      "y": 688,
      "ta": "#strategyButton"
    },
    {
      "t": 2101,
      "e": 2101,
      "ty": 2,
      "x": 437,
      "y": 686
    },
    {
      "t": 2201,
      "e": 2201,
      "ty": 2,
      "x": 436,
      "y": 686
    },
    {
      "t": 2251,
      "e": 2251,
      "ty": 41,
      "x": 53195,
      "y": 60264,
      "ta": "#strategyButton"
    },
    {
      "t": 2301,
      "e": 2301,
      "ty": 2,
      "x": 435,
      "y": 680
    },
    {
      "t": 2374,
      "e": 2374,
      "ty": 7,
      "x": 450,
      "y": 649,
      "ta": "#strategyButton"
    },
    {
      "t": 2400,
      "e": 2400,
      "ty": 2,
      "x": 456,
      "y": 643
    },
    {
      "t": 2501,
      "e": 2501,
      "ty": 2,
      "x": 480,
      "y": 630
    },
    {
      "t": 2501,
      "e": 2501,
      "ty": 41,
      "x": 43042,
      "y": 34457,
      "ta": "> div.stimulus > div"
    },
    {
      "t": 2601,
      "e": 2601,
      "ty": 2,
      "x": 509,
      "y": 609
    },
    {
      "t": 2642,
      "e": 2642,
      "ty": 6,
      "x": 515,
      "y": 602,
      "ta": "#strategyAnswer"
    },
    {
      "t": 2701,
      "e": 2701,
      "ty": 2,
      "x": 524,
      "y": 587
    },
    {
      "t": 2751,
      "e": 2751,
      "ty": 41,
      "x": 48325,
      "y": 43904,
      "ta": "#strategyAnswer"
    },
    {
      "t": 2801,
      "e": 2801,
      "ty": 2,
      "x": 531,
      "y": 569
    },
    {
      "t": 2901,
      "e": 2901,
      "ty": 2,
      "x": 531,
      "y": 565
    },
    {
      "t": 3001,
      "e": 3001,
      "ty": 41,
      "x": 48775,
      "y": 34196,
      "ta": "#strategyAnswer"
    },
    {
      "t": 3077,
      "e": 3077,
      "ty": 3,
      "x": 531,
      "y": 565,
      "ta": "#strategyAnswer"
    },
    {
      "t": 3079,
      "e": 3079,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 3228,
      "e": 3228,
      "ty": 4,
      "x": 48775,
      "y": 34196,
      "ta": "#strategyAnswer"
    },
    {
      "t": 3229,
      "e": 3229,
      "ty": 5,
      "x": 531,
      "y": 565,
      "ta": "#strategyAnswer"
    },
    {
      "t": 4300,
      "e": 4300,
      "ty": 2,
      "x": 531,
      "y": 581
    },
    {
      "t": 4375,
      "e": 4375,
      "ty": 7,
      "x": 538,
      "y": 608,
      "ta": "#strategyAnswer"
    },
    {
      "t": 4400,
      "e": 4400,
      "ty": 2,
      "x": 542,
      "y": 613
    },
    {
      "t": 4501,
      "e": 4501,
      "ty": 2,
      "x": 558,
      "y": 645
    },
    {
      "t": 4501,
      "e": 4501,
      "ty": 41,
      "x": 51810,
      "y": 35288,
      "ta": "> div.stimulus > div"
    },
    {
      "t": 4601,
      "e": 4601,
      "ty": 2,
      "x": 566,
      "y": 671
    },
    {
      "t": 4701,
      "e": 4701,
      "ty": 2,
      "x": 586,
      "y": 750
    },
    {
      "t": 4751,
      "e": 4751,
      "ty": 41,
      "x": 56644,
      "y": 42766,
      "ta": "> div.stimulus > div"
    },
    {
      "t": 4800,
      "e": 4800,
      "ty": 2,
      "x": 614,
      "y": 804
    },
    {
      "t": 4901,
      "e": 4901,
      "ty": 2,
      "x": 685,
      "y": 880
    },
    {
      "t": 5001,
      "e": 5001,
      "ty": 2,
      "x": 730,
      "y": 899
    },
    {
      "t": 5001,
      "e": 5001,
      "ty": 41,
      "x": 2864,
      "y": 54032,
      "ta": "> div.stimulus > div:[2]"
    },
    {
      "t": 5101,
      "e": 5101,
      "ty": 2,
      "x": 825,
      "y": 921
    },
    {
      "t": 5201,
      "e": 5201,
      "ty": 2,
      "x": 914,
      "y": 927
    },
    {
      "t": 5251,
      "e": 5251,
      "ty": 41,
      "x": 11698,
      "y": 57441,
      "ta": "> div.stimulus > div:[2] > svg"
    },
    {
      "t": 5301,
      "e": 5301,
      "ty": 2,
      "x": 1007,
      "y": 960
    },
    {
      "t": 5401,
      "e": 5401,
      "ty": 2,
      "x": 1096,
      "y": 974
    },
    {
      "t": 5501,
      "e": 5501,
      "ty": 2,
      "x": 1113,
      "y": 982
    },
    {
      "t": 5501,
      "e": 5501,
      "ty": 41,
      "x": 23044,
      "y": 60449,
      "ta": "> div.stimulus > div:[2] > svg"
    },
    {
      "t": 5601,
      "e": 5601,
      "ty": 2,
      "x": 1114,
      "y": 982
    },
    {
      "t": 5701,
      "e": 5701,
      "ty": 2,
      "x": 1117,
      "y": 982
    },
    {
      "t": 5751,
      "e": 5751,
      "ty": 41,
      "x": 29386,
      "y": 59232,
      "ta": "> div.stimulus > div:[2] > svg"
    },
    {
      "t": 5801,
      "e": 5801,
      "ty": 2,
      "x": 1228,
      "y": 952
    },
    {
      "t": 5901,
      "e": 5901,
      "ty": 2,
      "x": 1228,
      "y": 954
    },
    {
      "t": 6001,
      "e": 6001,
      "ty": 2,
      "x": 1170,
      "y": 960
    },
    {
      "t": 6002,
      "e": 6002,
      "ty": 41,
      "x": 27060,
      "y": 58874,
      "ta": "> div.stimulus > div:[2] > svg"
    },
    {
      "t": 6101,
      "e": 6101,
      "ty": 2,
      "x": 1161,
      "y": 964
    },
    {
      "t": 6201,
      "e": 6201,
      "ty": 2,
      "x": 1179,
      "y": 955
    },
    {
      "t": 6252,
      "e": 6252,
      "ty": 41,
      "x": 32768,
      "y": 55937,
      "ta": "> div.stimulus > div:[2] > svg"
    },
    {
      "t": 6301,
      "e": 6301,
      "ty": 2,
      "x": 1418,
      "y": 885
    },
    {
      "t": 6401,
      "e": 6401,
      "ty": 2,
      "x": 1514,
      "y": 837
    },
    {
      "t": 6501,
      "e": 6501,
      "ty": 2,
      "x": 1577,
      "y": 778
    },
    {
      "t": 6501,
      "e": 6501,
      "ty": 41,
      "x": 55741,
      "y": 45838,
      "ta": "> div.stimulus > div:[2] > svg"
    },
    {
      "t": 6601,
      "e": 6601,
      "ty": 2,
      "x": 1608,
      "y": 720
    },
    {
      "t": 6701,
      "e": 6701,
      "ty": 2,
      "x": 1663,
      "y": 672
    },
    {
      "t": 6752,
      "e": 6752,
      "ty": 41,
      "x": 62012,
      "y": 38031,
      "ta": "> div.stimulus > div:[2] > svg"
    },
    {
      "t": 6801,
      "e": 6801,
      "ty": 2,
      "x": 1666,
      "y": 669
    },
    {
      "t": 10001,
      "e": 10001,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 11705,
      "e": 11705,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "16"
    },
    {
      "t": 11881,
      "e": 11881,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "66"
    },
    {
      "t": 11881,
      "e": 11881,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 11927,
      "e": 11927,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "B"
    },
    {
      "t": 12024,
      "e": 12024,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "B"
    },
    {
      "t": 12208,
      "e": 12208,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "89"
    },
    {
      "t": 12209,
      "e": 12209,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 12303,
      "e": 12303,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "By"
    },
    {
      "t": 12481,
      "e": 12481,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 12482,
      "e": 12482,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 12567,
      "e": 12567,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "By "
    },
    {
      "t": 12921,
      "e": 12921,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "76"
    },
    {
      "t": 12921,
      "e": 12921,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 12999,
      "e": 12999,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "By l"
    },
    {
      "t": 13137,
      "e": 13137,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "79"
    },
    {
      "t": 13137,
      "e": 13137,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 13184,
      "e": 13184,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||o"
    },
    {
      "t": 13272,
      "e": 13272,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "79"
    },
    {
      "t": 13273,
      "e": 13273,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 13344,
      "e": 13344,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||o"
    },
    {
      "t": 13680,
      "e": 13680,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "75"
    },
    {
      "t": 13682,
      "e": 13682,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 13768,
      "e": 13768,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||k"
    },
    {
      "t": 13880,
      "e": 13880,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "73"
    },
    {
      "t": 13880,
      "e": 13880,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 14003,
      "e": 14003,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "By looki"
    },
    {
      "t": 14007,
      "e": 14007,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "78"
    },
    {
      "t": 14007,
      "e": 14007,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 14063,
      "e": 14063,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||in"
    },
    {
      "t": 14127,
      "e": 14127,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 14216,
      "e": 14216,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "71"
    },
    {
      "t": 14216,
      "e": 14216,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 14296,
      "e": 14296,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||g"
    },
    {
      "t": 14320,
      "e": 14320,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 14321,
      "e": 14321,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 14431,
      "e": 14431,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 14463,
      "e": 14463,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 14463,
      "e": 14463,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 14584,
      "e": 14584,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 14585,
      "e": 14585,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 14615,
      "e": 14615,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||at"
    },
    {
      "t": 14695,
      "e": 14695,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 14696,
      "e": 14696,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 14711,
      "e": 14711,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 14800,
      "e": 14800,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 14839,
      "e": 14839,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 14840,
      "e": 14840,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 14945,
      "e": 14945,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "72"
    },
    {
      "t": 14945,
      "e": 14945,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 14959,
      "e": 14959,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||th"
    },
    {
      "t": 15047,
      "e": 15047,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 15080,
      "e": 15080,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 15080,
      "e": 15080,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 15204,
      "e": 15204,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "By looking at the"
    },
    {
      "t": 15217,
      "e": 15217,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 15217,
      "e": 15217,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 15224,
      "e": 15224,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||e "
    },
    {
      "t": 15311,
      "e": 15311,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 16040,
      "e": 16040,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "88"
    },
    {
      "t": 16041,
      "e": 16041,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 16127,
      "e": 16127,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||x"
    },
    {
      "t": 16159,
      "e": 16159,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 16160,
      "e": 16160,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 16272,
      "e": 16272,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 16384,
      "e": 16384,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 16385,
      "e": 16385,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 16503,
      "e": 16503,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||a"
    },
    {
      "t": 17288,
      "e": 17288,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "88"
    },
    {
      "t": 17290,
      "e": 17290,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 17403,
      "e": 17403,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "By looking at the x ax"
    },
    {
      "t": 17407,
      "e": 17407,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||x"
    },
    {
      "t": 17593,
      "e": 17593,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "73"
    },
    {
      "t": 17593,
      "e": 17593,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 17703,
      "e": 17703,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||i"
    },
    {
      "t": 17736,
      "e": 17736,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "83"
    },
    {
      "t": 17736,
      "e": 17736,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 17857,
      "e": 17857,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||s"
    },
    {
      "t": 17944,
      "e": 17944,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 17945,
      "e": 17945,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 18071,
      "e": 18071,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 18223,
      "e": 18223,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 18224,
      "e": 18224,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 18336,
      "e": 18336,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||a"
    },
    {
      "t": 18449,
      "e": 18449,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "78"
    },
    {
      "t": 18449,
      "e": 18449,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 18543,
      "e": 18543,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||n"
    },
    {
      "t": 18560,
      "e": 18560,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "68"
    },
    {
      "t": 18560,
      "e": 18560,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 18664,
      "e": 18664,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||d"
    },
    {
      "t": 18671,
      "e": 18671,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 18673,
      "e": 18673,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 18760,
      "e": 18760,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 18824,
      "e": 18824,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "83"
    },
    {
      "t": 18825,
      "e": 18825,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 18903,
      "e": 18903,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||s"
    },
    {
      "t": 19004,
      "e": 19004,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "By looking at the x axis and s"
    },
    {
      "t": 19160,
      "e": 19160,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 19161,
      "e": 19161,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 19207,
      "e": 19207,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||e"
    },
    {
      "t": 19295,
      "e": 19295,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 19295,
      "e": 19295,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 19384,
      "e": 19384,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||e"
    },
    {
      "t": 19424,
      "e": 19424,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "73"
    },
    {
      "t": 19425,
      "e": 19425,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 19512,
      "e": 19512,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "78"
    },
    {
      "t": 19512,
      "e": 19512,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 19591,
      "e": 19591,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||in"
    },
    {
      "t": 19616,
      "e": 19616,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 19624,
      "e": 19624,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "71"
    },
    {
      "t": 19625,
      "e": 19625,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 19712,
      "e": 19712,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||g"
    },
    {
      "t": 19760,
      "e": 19760,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 19762,
      "e": 19762,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 19855,
      "e": 19855,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 19912,
      "e": 19912,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "87"
    },
    {
      "t": 19912,
      "e": 19912,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 20001,
      "e": 20001,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 20040,
      "e": 20040,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||w"
    },
    {
      "t": 20080,
      "e": 20080,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "72"
    },
    {
      "t": 20081,
      "e": 20081,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 20159,
      "e": 20159,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "73"
    },
    {
      "t": 20160,
      "e": 20160,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 20199,
      "e": 20199,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||hi"
    },
    {
      "t": 20263,
      "e": 20263,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 20296,
      "e": 20296,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "67"
    },
    {
      "t": 20296,
      "e": 20296,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 20384,
      "e": 20384,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||c"
    },
    {
      "t": 20400,
      "e": 20400,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "72"
    },
    {
      "t": 20400,
      "e": 20400,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 20487,
      "e": 20487,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||h"
    },
    {
      "t": 20632,
      "e": 20632,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 20633,
      "e": 20633,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 20736,
      "e": 20736,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 21072,
      "e": 21072,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "80"
    },
    {
      "t": 21073,
      "e": 21073,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 21183,
      "e": 21183,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "79"
    },
    {
      "t": 21183,
      "e": 21183,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 21263,
      "e": 21263,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||po"
    },
    {
      "t": 21296,
      "e": 21296,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 21416,
      "e": 21416,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "73"
    },
    {
      "t": 21417,
      "e": 21417,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 21480,
      "e": 21480,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||i"
    },
    {
      "t": 21604,
      "e": 21604,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "By looking at the x axis and seeing which poi"
    },
    {
      "t": 21608,
      "e": 21608,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "78"
    },
    {
      "t": 21609,
      "e": 21609,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 21703,
      "e": 21703,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||n"
    },
    {
      "t": 21719,
      "e": 21719,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 21720,
      "e": 21720,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 21816,
      "e": 21816,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 21832,
      "e": 21832,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 21832,
      "e": 21832,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 21928,
      "e": 21928,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 22184,
      "e": 22184,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "67"
    },
    {
      "t": 22185,
      "e": 22185,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 22287,
      "e": 22287,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||c"
    },
    {
      "t": 22319,
      "e": 22319,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "79"
    },
    {
      "t": 22319,
      "e": 22319,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 22375,
      "e": 22375,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||o"
    },
    {
      "t": 22496,
      "e": 22496,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "73"
    },
    {
      "t": 22497,
      "e": 22497,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 22600,
      "e": 22600,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "78"
    },
    {
      "t": 22600,
      "e": 22600,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 22631,
      "e": 22631,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||in"
    },
    {
      "t": 22679,
      "e": 22679,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 23136,
      "e": 23136,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "67"
    },
    {
      "t": 23136,
      "e": 23136,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 23207,
      "e": 23207,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||c"
    },
    {
      "t": 23223,
      "e": 23223,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "73"
    },
    {
      "t": 23224,
      "e": 23224,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 23303,
      "e": 23303,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||i"
    },
    {
      "t": 23368,
      "e": 23368,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "68"
    },
    {
      "t": 23368,
      "e": 23368,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 23471,
      "e": 23471,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 23472,
      "e": 23472,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 23543,
      "e": 23543,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||de"
    },
    {
      "t": 23607,
      "e": 23607,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 23728,
      "e": 23728,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "83"
    },
    {
      "t": 23729,
      "e": 23729,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 23815,
      "e": 23815,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||s"
    },
    {
      "t": 23871,
      "e": 23871,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 23871,
      "e": 23871,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 23976,
      "e": 23976,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "87"
    },
    {
      "t": 23977,
      "e": 23977,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 23983,
      "e": 23983,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| w"
    },
    {
      "t": 24063,
      "e": 24063,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 24103,
      "e": 24103,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "73"
    },
    {
      "t": 24103,
      "e": 24103,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 24176,
      "e": 24176,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||i"
    },
    {
      "t": 24208,
      "e": 24208,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 24208,
      "e": 24208,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 24296,
      "e": 24296,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 24304,
      "e": 24304,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "72"
    },
    {
      "t": 24304,
      "e": 24304,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 24392,
      "e": 24392,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||h"
    },
    {
      "t": 24552,
      "e": 24552,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 24553,
      "e": 24553,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 24631,
      "e": 24631,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 30001,
      "e": 29631,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 34251,
      "e": 29631,
      "ty": 41,
      "x": 60321,
      "y": 37315,
      "ta": "> div.stimulus > div:[2] > svg"
    },
    {
      "t": 34300,
      "e": 29680,
      "ty": 2,
      "x": 1560,
      "y": 647
    },
    {
      "t": 34401,
      "e": 29781,
      "ty": 2,
      "x": 1531,
      "y": 646
    },
    {
      "t": 34501,
      "e": 29881,
      "ty": 2,
      "x": 1540,
      "y": 634
    },
    {
      "t": 34502,
      "e": 29882,
      "ty": 41,
      "x": 53133,
      "y": 35524,
      "ta": "> div.stimulus > div:[2] > svg"
    },
    {
      "t": 34601,
      "e": 29981,
      "ty": 2,
      "x": 1105,
      "y": 685
    },
    {
      "t": 34701,
      "e": 30081,
      "ty": 2,
      "x": 882,
      "y": 699
    },
    {
      "t": 34751,
      "e": 30131,
      "ty": 41,
      "x": 3383,
      "y": 40108,
      "ta": "> div.stimulus > div:[2] > svg"
    },
    {
      "t": 34800,
      "e": 30180,
      "ty": 2,
      "x": 802,
      "y": 690
    },
    {
      "t": 34901,
      "e": 30281,
      "ty": 2,
      "x": 769,
      "y": 678
    },
    {
      "t": 35001,
      "e": 30381,
      "ty": 2,
      "x": 779,
      "y": 654
    },
    {
      "t": 35002,
      "e": 30382,
      "ty": 41,
      "x": 5676,
      "y": 36637,
      "ta": "> div.stimulus > div:[2]"
    },
    {
      "t": 35101,
      "e": 30481,
      "ty": 2,
      "x": 799,
      "y": 634
    },
    {
      "t": 35252,
      "e": 30632,
      "ty": 41,
      "x": 917,
      "y": 35524,
      "ta": "> div.stimulus > div:[2] > svg"
    },
    {
      "t": 36025,
      "e": 31405,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 36025,
      "e": 31405,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 36119,
      "e": 31499,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 36120,
      "e": 31500,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 36231,
      "e": 31611,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "67"
    },
    {
      "t": 36231,
      "e": 31611,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 36263,
      "e": 31643,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||eac"
    },
    {
      "t": 36367,
      "e": 31747,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "72"
    },
    {
      "t": 36368,
      "e": 31748,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 36375,
      "e": 31755,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||h"
    },
    {
      "t": 36383,
      "e": 31763,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 36447,
      "e": 31827,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 36623,
      "e": 32003,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 36625,
      "e": 32005,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 36720,
      "e": 32100,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 36800,
      "e": 32180,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 36801,
      "e": 32181,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 36903,
      "e": 32283,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "73"
    },
    {
      "t": 36903,
      "e": 32283,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 36911,
      "e": 32291,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||ti"
    },
    {
      "t": 37008,
      "e": 32388,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "77"
    },
    {
      "t": 37008,
      "e": 32388,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 37079,
      "e": 32459,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||m"
    },
    {
      "t": 37111,
      "e": 32491,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 37135,
      "e": 32515,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 37135,
      "e": 32515,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 37225,
      "e": 32605,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||e"
    },
    {
      "t": 38455,
      "e": 33835,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 38512,
      "e": 33892,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "By looking at the x axis and seeing which point coincides with each tim"
    },
    {
      "t": 38607,
      "e": 33987,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 38670,
      "e": 34050,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "By looking at the x axis and seeing which point coincides with each ti"
    },
    {
      "t": 38759,
      "e": 34139,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 38825,
      "e": 34205,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "By looking at the x axis and seeing which point coincides with each t"
    },
    {
      "t": 38927,
      "e": 34307,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 38983,
      "e": 34363,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "By looking at the x axis and seeing which point coincides with each "
    },
    {
      "t": 39064,
      "e": 34444,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 39143,
      "e": 34523,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "By looking at the x axis and seeing which point coincides with each"
    },
    {
      "t": 39223,
      "e": 34603,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 39295,
      "e": 34675,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "By looking at the x axis and seeing which point coincides with eac"
    },
    {
      "t": 39391,
      "e": 34771,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 39455,
      "e": 34835,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "By looking at the x axis and seeing which point coincides with ea"
    },
    {
      "t": 39542,
      "e": 34922,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 39607,
      "e": 34987,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "By looking at the x axis and seeing which point coincides with e"
    },
    {
      "t": 39720,
      "e": 35100,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 39783,
      "e": 35100,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "By looking at the x axis and seeing which point coincides with "
    },
    {
      "t": 43127,
      "e": 38444,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 43128,
      "e": 38445,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 43238,
      "e": 38555,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 43247,
      "e": 38564,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "72"
    },
    {
      "t": 43247,
      "e": 38564,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 43368,
      "e": 38685,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||h"
    },
    {
      "t": 43407,
      "e": 38724,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 43408,
      "e": 38725,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 43527,
      "e": 38844,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||e"
    },
    {
      "t": 44239,
      "e": 39556,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 44240,
      "e": 39557,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 44351,
      "e": 39668,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 44759,
      "e": 40076,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 44760,
      "e": 40077,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 44846,
      "e": 40163,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "73"
    },
    {
      "t": 44847,
      "e": 40164,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 44878,
      "e": 40195,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||ti"
    },
    {
      "t": 44919,
      "e": 40236,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "77"
    },
    {
      "t": 44919,
      "e": 40236,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 45015,
      "e": 40332,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||m"
    },
    {
      "t": 45047,
      "e": 40364,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 45087,
      "e": 40404,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 45088,
      "e": 40405,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 45203,
      "e": 40520,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "By looking at the x axis and seeing which point coincides with the time"
    },
    {
      "t": 45207,
      "e": 40524,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||e"
    },
    {
      "t": 45231,
      "e": 40548,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 45231,
      "e": 40548,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 45343,
      "e": 40660,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 45767,
      "e": 41084,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "49"
    },
    {
      "t": 45767,
      "e": 41084,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 45879,
      "e": 41196,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "50"
    },
    {
      "t": 45880,
      "e": 41197,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 45968,
      "e": 41285,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||12"
    },
    {
      "t": 46000,
      "e": 41317,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 46240,
      "e": 41557,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 46241,
      "e": 41558,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 46303,
      "e": 41620,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 46404,
      "e": 41721,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "By looking at the x axis and seeing which point coincides with the time 12 "
    },
    {
      "t": 46520,
      "e": 41837,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "80"
    },
    {
      "t": 46521,
      "e": 41838,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 46647,
      "e": 41964,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "77"
    },
    {
      "t": 46647,
      "e": 41964,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 46654,
      "e": 41971,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||pm"
    },
    {
      "t": 46752,
      "e": 42069,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 47501,
      "e": 42818,
      "ty": 2,
      "x": 796,
      "y": 619
    },
    {
      "t": 47501,
      "e": 42818,
      "ty": 41,
      "x": 705,
      "y": 34450,
      "ta": "> div.stimulus > div:[2] > svg"
    },
    {
      "t": 47601,
      "e": 42918,
      "ty": 2,
      "x": 774,
      "y": 637
    },
    {
      "t": 47702,
      "e": 43019,
      "ty": 2,
      "x": 668,
      "y": 735
    },
    {
      "t": 47752,
      "e": 43069,
      "ty": 41,
      "x": 62714,
      "y": 40772,
      "ta": "> div.stimulus > div"
    },
    {
      "t": 47801,
      "e": 43118,
      "ty": 2,
      "x": 655,
      "y": 744
    },
    {
      "t": 47901,
      "e": 43218,
      "ty": 2,
      "x": 619,
      "y": 716
    },
    {
      "t": 48002,
      "e": 43319,
      "ty": 41,
      "x": 58667,
      "y": 39221,
      "ta": "> div.stimulus > div"
    },
    {
      "t": 48486,
      "e": 43803,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 48551,
      "e": 43868,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "By looking at the x axis and seeing which point coincides with the time 12 p"
    },
    {
      "t": 48639,
      "e": 43956,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 48703,
      "e": 44020,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "By looking at the x axis and seeing which point coincides with the time 12 "
    },
    {
      "t": 48791,
      "e": 44108,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 48862,
      "e": 44179,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "By looking at the x axis and seeing which point coincides with the time 12"
    },
    {
      "t": 48958,
      "e": 44275,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 48983,
      "e": 44300,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "By looking at the x axis and seeing which point coincides with the time 1"
    },
    {
      "t": 49872,
      "e": 45189,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "50"
    },
    {
      "t": 49873,
      "e": 45190,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 49942,
      "e": 45259,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||2"
    },
    {
      "t": 50001,
      "e": 45318,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 50438,
      "e": 45755,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "80"
    },
    {
      "t": 50439,
      "e": 45756,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 50542,
      "e": 45859,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||p"
    },
    {
      "t": 50567,
      "e": 45884,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "77"
    },
    {
      "t": 50567,
      "e": 45884,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 50647,
      "e": 45964,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||m"
    },
    {
      "t": 51647,
      "e": 46964,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "190"
    },
    {
      "t": 51648,
      "e": 46965,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 51710,
      "e": 47027,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||."
    },
    {
      "t": 52548,
      "e": 47865,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 52612,
      "e": 47929,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "By looking at the x axis and seeing which point coincides with the time 12pm"
    },
    {
      "t": 53199,
      "e": 48516,
      "ty": 2,
      "x": 553,
      "y": 694
    },
    {
      "t": 53250,
      "e": 48567,
      "ty": 41,
      "x": 51023,
      "y": 38002,
      "ta": "> div.stimulus > div"
    },
    {
      "t": 53299,
      "e": 48616,
      "ty": 2,
      "x": 539,
      "y": 692
    },
    {
      "t": 53399,
      "e": 48716,
      "ty": 2,
      "x": 460,
      "y": 686
    },
    {
      "t": 53413,
      "e": 48730,
      "ty": 6,
      "x": 451,
      "y": 684,
      "ta": "#strategyButton"
    },
    {
      "t": 53499,
      "e": 48816,
      "ty": 2,
      "x": 439,
      "y": 682
    },
    {
      "t": 53499,
      "e": 48816,
      "ty": 41,
      "x": 54834,
      "y": 52554,
      "ta": "#strategyButton"
    },
    {
      "t": 53705,
      "e": 49022,
      "ty": 3,
      "x": 439,
      "y": 682,
      "ta": "#strategyButton"
    },
    {
      "t": 53707,
      "e": 49024,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "By looking at the x axis and seeing which point coincides with the time 12pm"
    },
    {
      "t": 53709,
      "e": 49026,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 53709,
      "e": 49026,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#strategyButton"
    },
    {
      "t": 53792,
      "e": 49109,
      "ty": 4,
      "x": 54834,
      "y": 52554,
      "ta": "#strategyButton"
    },
    {
      "t": 53802,
      "e": 49119,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#strategyButton"
    },
    {
      "t": 53802,
      "e": 49119,
      "ty": 5,
      "x": 439,
      "y": 682,
      "ta": "#strategyButton"
    },
    {
      "t": 53808,
      "e": 49125,
      "ty": 38,
      "x": 2,
      "y": 0
    },
    {
      "t": 54249,
      "e": 49566,
      "ty": 41,
      "x": 14980,
      "y": 37171,
      "ta": "html > body"
    },
    {
      "t": 54299,
      "e": 49616,
      "ty": 2,
      "x": 444,
      "y": 679
    },
    {
      "t": 54500,
      "e": 49817,
      "ty": 41,
      "x": 15014,
      "y": 37171,
      "ta": "html > body"
    },
    {
      "t": 54808,
      "e": 50125,
      "ty": 38,
      "x": 3,
      "y": 0
    },
    {
      "t": 55500,
      "e": 50817,
      "ty": 2,
      "x": 495,
      "y": 659
    },
    {
      "t": 55500,
      "e": 50817,
      "ty": 41,
      "x": 16771,
      "y": 36063,
      "ta": "html > body"
    },
    {
      "t": 55599,
      "e": 50916,
      "ty": 2,
      "x": 578,
      "y": 625
    },
    {
      "t": 55699,
      "e": 51016,
      "ty": 2,
      "x": 689,
      "y": 559
    },
    {
      "t": 55749,
      "e": 51066,
      "ty": 41,
      "x": 27515,
      "y": 29360,
      "ta": "html > body"
    },
    {
      "t": 55799,
      "e": 51116,
      "ty": 2,
      "x": 882,
      "y": 529
    },
    {
      "t": 55899,
      "e": 51216,
      "ty": 2,
      "x": 899,
      "y": 523
    },
    {
      "t": 55965,
      "e": 51282,
      "ty": 6,
      "x": 895,
      "y": 568,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 55982,
      "e": 51299,
      "ty": 7,
      "x": 893,
      "y": 580,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 55999,
      "e": 51316,
      "ty": 2,
      "x": 888,
      "y": 590
    },
    {
      "t": 55999,
      "e": 51316,
      "ty": 41,
      "x": 17302,
      "y": 4932,
      "ta": "#jspsych-survey-text-1"
    },
    {
      "t": 56100,
      "e": 51417,
      "ty": 2,
      "x": 885,
      "y": 595
    },
    {
      "t": 56199,
      "e": 51516,
      "ty": 2,
      "x": 885,
      "y": 596
    },
    {
      "t": 56249,
      "e": 51566,
      "ty": 41,
      "x": 17086,
      "y": 1409,
      "ta": "#jspsych-survey-text-1"
    },
    {
      "t": 56299,
      "e": 51616,
      "ty": 2,
      "x": 890,
      "y": 577
    },
    {
      "t": 56448,
      "e": 51765,
      "ty": 6,
      "x": 893,
      "y": 574,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 56499,
      "e": 51816,
      "ty": 2,
      "x": 900,
      "y": 562
    },
    {
      "t": 56499,
      "e": 51816,
      "ty": 41,
      "x": 19898,
      "y": 24965,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 56599,
      "e": 51916,
      "ty": 2,
      "x": 901,
      "y": 558
    },
    {
      "t": 56649,
      "e": 51966,
      "ty": 3,
      "x": 901,
      "y": 558,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 56651,
      "e": 51968,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 56749,
      "e": 52066,
      "ty": 41,
      "x": 20114,
      "y": 12482,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 56752,
      "e": 52069,
      "ty": 4,
      "x": 20114,
      "y": 12482,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 56753,
      "e": 52070,
      "ty": 5,
      "x": 901,
      "y": 558,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 57166,
      "e": 52483,
      "ty": 7,
      "x": 1163,
      "y": 590,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 57199,
      "e": 52516,
      "ty": 2,
      "x": 1366,
      "y": 604
    },
    {
      "t": 57250,
      "e": 52567,
      "ty": 41,
      "x": 54721,
      "y": 31908,
      "ta": "html > body"
    },
    {
      "t": 57298,
      "e": 52615,
      "ty": 2,
      "x": 1641,
      "y": 560
    },
    {
      "t": 57399,
      "e": 52716,
      "ty": 2,
      "x": 1661,
      "y": 535
    },
    {
      "t": 57500,
      "e": 52817,
      "ty": 2,
      "x": 1657,
      "y": 529
    },
    {
      "t": 57500,
      "e": 52817,
      "ty": 41,
      "x": 56787,
      "y": 28861,
      "ta": "html > body"
    },
    {
      "t": 57599,
      "e": 52916,
      "ty": 2,
      "x": 1644,
      "y": 523
    },
    {
      "t": 57749,
      "e": 53066,
      "ty": 41,
      "x": 56305,
      "y": 28474,
      "ta": "html > body"
    },
    {
      "t": 57799,
      "e": 53116,
      "ty": 2,
      "x": 1642,
      "y": 521
    },
    {
      "t": 57999,
      "e": 53316,
      "ty": 41,
      "x": 56271,
      "y": 28418,
      "ta": "html > body"
    },
    {
      "t": 58756,
      "e": 54073,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "50"
    },
    {
      "t": 58758,
      "e": 54075,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 58828,
      "e": 54145,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "2"
    },
    {
      "t": 58917,
      "e": 54234,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "50"
    },
    {
      "t": 58917,
      "e": 54234,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 59029,
      "e": 54346,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "22"
    },
    {
      "t": 59399,
      "e": 54716,
      "ty": 2,
      "x": 1502,
      "y": 560
    },
    {
      "t": 59500,
      "e": 54817,
      "ty": 2,
      "x": 990,
      "y": 726
    },
    {
      "t": 59500,
      "e": 54817,
      "ty": 41,
      "x": 33817,
      "y": 39775,
      "ta": "html > body"
    },
    {
      "t": 59598,
      "e": 54915,
      "ty": 2,
      "x": 922,
      "y": 755
    },
    {
      "t": 59699,
      "e": 55016,
      "ty": 2,
      "x": 919,
      "y": 729
    },
    {
      "t": 59718,
      "e": 55035,
      "ty": 6,
      "x": 923,
      "y": 701,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 59749,
      "e": 55066,
      "ty": 41,
      "x": 15501,
      "y": 17873,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 59751,
      "e": 55068,
      "ty": 7,
      "x": 931,
      "y": 671,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 59784,
      "e": 55101,
      "ty": 6,
      "x": 933,
      "y": 667,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 59799,
      "e": 55116,
      "ty": 2,
      "x": 933,
      "y": 667
    },
    {
      "t": 59899,
      "e": 55216,
      "ty": 2,
      "x": 935,
      "y": 667
    },
    {
      "t": 60000,
      "e": 55317,
      "ty": 41,
      "x": 27468,
      "y": 62414,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 60000,
      "e": 55317,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 60198,
      "e": 55515,
      "ty": 2,
      "x": 938,
      "y": 663
    },
    {
      "t": 60249,
      "e": 55566,
      "ty": 41,
      "x": 28333,
      "y": 49931,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 60298,
      "e": 55615,
      "ty": 2,
      "x": 939,
      "y": 663
    },
    {
      "t": 60329,
      "e": 55646,
      "ty": 3,
      "x": 939,
      "y": 663,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 60330,
      "e": 55647,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "22"
    },
    {
      "t": 60330,
      "e": 55647,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 60331,
      "e": 55648,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 60440,
      "e": 55757,
      "ty": 4,
      "x": 28333,
      "y": 49931,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 60440,
      "e": 55757,
      "ty": 5,
      "x": 939,
      "y": 663,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 60585,
      "e": 55902,
      "ty": 7,
      "x": 1180,
      "y": 636,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 60598,
      "e": 55915,
      "ty": 2,
      "x": 1180,
      "y": 636
    },
    {
      "t": 60699,
      "e": 56016,
      "ty": 2,
      "x": 1919,
      "y": 434
    },
    {
      "t": 61197,
      "e": 56514,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "16"
    },
    {
      "t": 61309,
      "e": 56626,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "85"
    },
    {
      "t": 61309,
      "e": 56626,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 61387,
      "e": 56704,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "U"
    },
    {
      "t": 61412,
      "e": 56729,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "U"
    },
    {
      "t": 61612,
      "e": 56929,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "78"
    },
    {
      "t": 61613,
      "e": 56930,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 61732,
      "e": 57049,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "73"
    },
    {
      "t": 61733,
      "e": 57050,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 61772,
      "e": 57089,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "Uni"
    },
    {
      "t": 61837,
      "e": 57154,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "Uni"
    },
    {
      "t": 61908,
      "e": 57225,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "84"
    },
    {
      "t": 61909,
      "e": 57226,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 62036,
      "e": 57353,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "Unit"
    },
    {
      "t": 62060,
      "e": 57377,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "69"
    },
    {
      "t": 62060,
      "e": 57377,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 62157,
      "e": 57474,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "+||e"
    },
    {
      "t": 62284,
      "e": 57601,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "68"
    },
    {
      "t": 62286,
      "e": 57603,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 62363,
      "e": 57680,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "+||d"
    },
    {
      "t": 62516,
      "e": 57833,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "32"
    },
    {
      "t": 62517,
      "e": 57834,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 62621,
      "e": 57938,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "+|| "
    },
    {
      "t": 62925,
      "e": 58242,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "16"
    },
    {
      "t": 63005,
      "e": 58322,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "83"
    },
    {
      "t": 63005,
      "e": 58322,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 63084,
      "e": 58401,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "+||S"
    },
    {
      "t": 63124,
      "e": 58441,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "+||"
    },
    {
      "t": 63237,
      "e": 58554,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "84"
    },
    {
      "t": 63237,
      "e": 58554,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 63300,
      "e": 58617,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "65"
    },
    {
      "t": 63300,
      "e": 58617,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 63332,
      "e": 58649,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "+||ta"
    },
    {
      "t": 63436,
      "e": 58753,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "84"
    },
    {
      "t": 63436,
      "e": 58753,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 63460,
      "e": 58777,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "+||t"
    },
    {
      "t": 63485,
      "e": 58802,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "69"
    },
    {
      "t": 63486,
      "e": 58803,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 63556,
      "e": 58873,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "+||e"
    },
    {
      "t": 63565,
      "e": 58882,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "+||"
    },
    {
      "t": 63676,
      "e": 58993,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "83"
    },
    {
      "t": 63677,
      "e": 58994,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 63771,
      "e": 59088,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "+||s"
    },
    {
      "t": 64398,
      "e": 59715,
      "ty": 2,
      "x": 1917,
      "y": 430
    },
    {
      "t": 64498,
      "e": 59815,
      "ty": 2,
      "x": 1857,
      "y": 467
    },
    {
      "t": 64498,
      "e": 59815,
      "ty": 41,
      "x": 63675,
      "y": 25427,
      "ta": "html > body"
    },
    {
      "t": 64599,
      "e": 59916,
      "ty": 2,
      "x": 1768,
      "y": 482
    },
    {
      "t": 64698,
      "e": 60015,
      "ty": 2,
      "x": 1567,
      "y": 428
    },
    {
      "t": 64749,
      "e": 60066,
      "ty": 41,
      "x": 43873,
      "y": 24541,
      "ta": "html > body"
    },
    {
      "t": 64788,
      "e": 60105,
      "ty": 6,
      "x": 1011,
      "y": 555,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 64798,
      "e": 60115,
      "ty": 2,
      "x": 1011,
      "y": 555
    },
    {
      "t": 64804,
      "e": 60121,
      "ty": 7,
      "x": 933,
      "y": 624,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 64898,
      "e": 60215,
      "ty": 2,
      "x": 673,
      "y": 857
    },
    {
      "t": 64999,
      "e": 60316,
      "ty": 2,
      "x": 678,
      "y": 858
    },
    {
      "t": 64999,
      "e": 60316,
      "ty": 41,
      "x": 23073,
      "y": 47087,
      "ta": "html > body"
    },
    {
      "t": 65099,
      "e": 60416,
      "ty": 2,
      "x": 809,
      "y": 813
    },
    {
      "t": 65198,
      "e": 60515,
      "ty": 2,
      "x": 894,
      "y": 768
    },
    {
      "t": 65249,
      "e": 60566,
      "ty": 41,
      "x": 30684,
      "y": 41714,
      "ta": "html > body"
    },
    {
      "t": 65298,
      "e": 60615,
      "ty": 2,
      "x": 903,
      "y": 752
    },
    {
      "t": 65373,
      "e": 60690,
      "ty": 6,
      "x": 937,
      "y": 705,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 65399,
      "e": 60716,
      "ty": 2,
      "x": 940,
      "y": 698
    },
    {
      "t": 65456,
      "e": 60773,
      "ty": 7,
      "x": 968,
      "y": 672,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 65499,
      "e": 60816,
      "ty": 2,
      "x": 972,
      "y": 669
    },
    {
      "t": 65499,
      "e": 60816,
      "ty": 41,
      "x": 35471,
      "y": 60602,
      "ta": "#jspsych-survey-text-1"
    },
    {
      "t": 65673,
      "e": 60990,
      "ty": 6,
      "x": 967,
      "y": 677,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 65698,
      "e": 61015,
      "ty": 2,
      "x": 967,
      "y": 679
    },
    {
      "t": 65749,
      "e": 61066,
      "ty": 41,
      "x": 36117,
      "y": 7943,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 65799,
      "e": 61116,
      "ty": 2,
      "x": 966,
      "y": 683
    },
    {
      "t": 65898,
      "e": 61215,
      "ty": 2,
      "x": 962,
      "y": 696
    },
    {
      "t": 65999,
      "e": 61316,
      "ty": 2,
      "x": 962,
      "y": 697
    },
    {
      "t": 65999,
      "e": 61316,
      "ty": 41,
      "x": 34055,
      "y": 41704,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 67497,
      "e": 62814,
      "ty": 3,
      "x": 962,
      "y": 697,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 67498,
      "e": 62815,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "United States"
    },
    {
      "t": 67500,
      "e": 62817,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 67500,
      "e": 62817,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 67583,
      "e": 62900,
      "ty": 4,
      "x": 34055,
      "y": 41704,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 67585,
      "e": 62902,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 67585,
      "e": 62902,
      "ty": 5,
      "x": 962,
      "y": 697,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 67585,
      "e": 62902,
      "ty": 38,
      "x": 4,
      "y": 0
    },
    {
      "t": 68610,
      "e": 63927,
      "ty": 38,
      "x": 5,
      "y": 0
    },
    {
      "t": 69498,
      "e": 64815,
      "ty": 2,
      "x": 980,
      "y": 559
    },
    {
      "t": 69499,
      "e": 64816,
      "ty": 41,
      "x": 37634,
      "y": 42129,
      "ta": "#jspsych-survey-multi-choice-option-1-5"
    },
    {
      "t": 69599,
      "e": 64916,
      "ty": 2,
      "x": 970,
      "y": 522
    },
    {
      "t": 69699,
      "e": 65016,
      "ty": 2,
      "x": 968,
      "y": 508
    },
    {
      "t": 69748,
      "e": 65065,
      "ty": 41,
      "x": 32413,
      "y": 63194,
      "ta": "#jspsych-survey-multi-choice-option-1-2"
    },
    {
      "t": 69798,
      "e": 65115,
      "ty": 2,
      "x": 929,
      "y": 436
    },
    {
      "t": 69898,
      "e": 65215,
      "ty": 2,
      "x": 926,
      "y": 436
    },
    {
      "t": 69999,
      "e": 65316,
      "ty": 41,
      "x": 24818,
      "y": 16383,
      "ta": "#jspsych-survey-multi-choice-option-1-1"
    },
    {
      "t": 69999,
      "e": 65316,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 70248,
      "e": 65565,
      "ty": 41,
      "x": 24818,
      "y": 42129,
      "ta": "#jspsych-survey-multi-choice-1 > p"
    },
    {
      "t": 70298,
      "e": 65615,
      "ty": 2,
      "x": 912,
      "y": 297
    },
    {
      "t": 70399,
      "e": 65716,
      "ty": 2,
      "x": 812,
      "y": 0
    },
    {
      "t": 70499,
      "e": 65816,
      "ty": 2,
      "x": 811,
      "y": 39
    },
    {
      "t": 70499,
      "e": 65816,
      "ty": 41,
      "x": 27653,
      "y": 1717,
      "ta": "html > body"
    },
    {
      "t": 70599,
      "e": 65916,
      "ty": 2,
      "x": 835,
      "y": 169
    },
    {
      "t": 70699,
      "e": 66016,
      "ty": 2,
      "x": 835,
      "y": 207
    },
    {
      "t": 70748,
      "e": 66065,
      "ty": 41,
      "x": 3222,
      "y": 11613,
      "ta": "#jspsych-survey-multi-choice-0"
    },
    {
      "t": 70799,
      "e": 66116,
      "ty": 2,
      "x": 835,
      "y": 220
    },
    {
      "t": 70807,
      "e": 66124,
      "ty": 6,
      "x": 835,
      "y": 234,
      "ta": "jspsych-survey-multi-choice-response-0[0]_mf"
    },
    {
      "t": 70824,
      "e": 66141,
      "ty": 7,
      "x": 833,
      "y": 247,
      "ta": "jspsych-survey-multi-choice-response-0[0]_mf"
    },
    {
      "t": 70898,
      "e": 66215,
      "ty": 2,
      "x": 833,
      "y": 254
    },
    {
      "t": 70999,
      "e": 66316,
      "ty": 41,
      "x": 2747,
      "y": 2340,
      "ta": "#jspsych-survey-multi-choice-option-0-1"
    },
    {
      "t": 71199,
      "e": 66516,
      "ty": 2,
      "x": 832,
      "y": 251
    },
    {
      "t": 71248,
      "e": 66565,
      "ty": 41,
      "x": 2510,
      "y": 60853,
      "ta": "#jspsych-survey-multi-choice-option-0-0"
    },
    {
      "t": 71299,
      "e": 66616,
      "ty": 2,
      "x": 832,
      "y": 249
    },
    {
      "t": 71385,
      "e": 66702,
      "ty": 6,
      "x": 832,
      "y": 244,
      "ta": "jspsych-survey-multi-choice-response-0[0]_mf"
    },
    {
      "t": 71399,
      "e": 66716,
      "ty": 2,
      "x": 832,
      "y": 244
    },
    {
      "t": 71499,
      "e": 66816,
      "ty": 41,
      "x": 28120,
      "y": 60493,
      "ta": "jspsych-survey-multi-choice-response-0[0]_mf"
    },
    {
      "t": 71599,
      "e": 66916,
      "ty": 2,
      "x": 832,
      "y": 241
    },
    {
      "t": 71699,
      "e": 67016,
      "ty": 2,
      "x": 831,
      "y": 238
    },
    {
      "t": 71749,
      "e": 67066,
      "ty": 41,
      "x": 23079,
      "y": 30246,
      "ta": "jspsych-survey-multi-choice-response-0[0]_mf"
    },
    {
      "t": 71825,
      "e": 67142,
      "ty": 3,
      "x": 831,
      "y": 238,
      "ta": "jspsych-survey-multi-choice-response-0[0]_mf"
    },
    {
      "t": 71826,
      "e": 67143,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-0[0]_mf"
    },
    {
      "t": 71928,
      "e": 67245,
      "ty": 4,
      "x": 23079,
      "y": 30246,
      "ta": "jspsych-survey-multi-choice-response-0[0]_mf"
    },
    {
      "t": 71929,
      "e": 67246,
      "ty": 5,
      "x": 831,
      "y": 238,
      "ta": "jspsych-survey-multi-choice-response-0[0]_mf"
    },
    {
      "t": 71930,
      "e": 67247,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-0[0]_mf",
      "v": "English"
    },
    {
      "t": 72249,
      "e": 67566,
      "ty": 41,
      "x": 23079,
      "y": 45370,
      "ta": "jspsych-survey-multi-choice-response-0[0]_mf"
    },
    {
      "t": 72261,
      "e": 67578,
      "ty": 7,
      "x": 839,
      "y": 248,
      "ta": "jspsych-survey-multi-choice-response-0[0]_mf"
    },
    {
      "t": 72298,
      "e": 67615,
      "ty": 2,
      "x": 868,
      "y": 406
    },
    {
      "t": 72398,
      "e": 67715,
      "ty": 2,
      "x": 819,
      "y": 796
    },
    {
      "t": 72499,
      "e": 67816,
      "ty": 2,
      "x": 811,
      "y": 823
    },
    {
      "t": 72499,
      "e": 67816,
      "ty": 41,
      "x": 27653,
      "y": 45148,
      "ta": "html > body"
    },
    {
      "t": 72599,
      "e": 67916,
      "ty": 2,
      "x": 815,
      "y": 808
    },
    {
      "t": 72661,
      "e": 67978,
      "ty": 6,
      "x": 827,
      "y": 756,
      "ta": "jspsych-survey-multi-choice-response-2[3]_mf"
    },
    {
      "t": 72677,
      "e": 67994,
      "ty": 7,
      "x": 827,
      "y": 740,
      "ta": "jspsych-survey-multi-choice-response-2[3]_mf"
    },
    {
      "t": 72698,
      "e": 68015,
      "ty": 2,
      "x": 834,
      "y": 716
    },
    {
      "t": 72711,
      "e": 68028,
      "ty": 6,
      "x": 837,
      "y": 699,
      "ta": "jspsych-survey-multi-choice-response-2[1]_mf"
    },
    {
      "t": 72727,
      "e": 68044,
      "ty": 7,
      "x": 838,
      "y": 691,
      "ta": "jspsych-survey-multi-choice-response-2[1]_mf"
    },
    {
      "t": 72749,
      "e": 68066,
      "ty": 41,
      "x": 5121,
      "y": 7021,
      "ta": "#jspsych-survey-multi-choice-option-2-0"
    },
    {
      "t": 72799,
      "e": 68116,
      "ty": 2,
      "x": 847,
      "y": 605
    },
    {
      "t": 72898,
      "e": 68215,
      "ty": 2,
      "x": 844,
      "y": 550
    },
    {
      "t": 72999,
      "e": 68316,
      "ty": 2,
      "x": 844,
      "y": 537
    },
    {
      "t": 72999,
      "e": 68316,
      "ty": 41,
      "x": 5358,
      "y": 56172,
      "ta": "#jspsych-survey-multi-choice-option-1-4"
    },
    {
      "t": 73099,
      "e": 68416,
      "ty": 2,
      "x": 853,
      "y": 474
    },
    {
      "t": 73198,
      "e": 68515,
      "ty": 2,
      "x": 855,
      "y": 402
    },
    {
      "t": 73249,
      "e": 68566,
      "ty": 41,
      "x": 7968,
      "y": 10290,
      "ta": "#jspsych-survey-multi-choice-1"
    },
    {
      "t": 73298,
      "e": 68615,
      "ty": 2,
      "x": 854,
      "y": 391
    },
    {
      "t": 73399,
      "e": 68716,
      "ty": 2,
      "x": 853,
      "y": 390
    },
    {
      "t": 73499,
      "e": 68816,
      "ty": 2,
      "x": 851,
      "y": 391
    },
    {
      "t": 73500,
      "e": 68817,
      "ty": 41,
      "x": 7019,
      "y": 9749,
      "ta": "#jspsych-survey-multi-choice-1"
    },
    {
      "t": 73899,
      "e": 69216,
      "ty": 2,
      "x": 849,
      "y": 414
    },
    {
      "t": 73998,
      "e": 69315,
      "ty": 2,
      "x": 842,
      "y": 441
    },
    {
      "t": 73999,
      "e": 69316,
      "ty": 41,
      "x": 16436,
      "y": 26214,
      "ta": "#jspsych-survey-multi-choice-option-1-1 > label"
    },
    {
      "t": 74062,
      "e": 69316,
      "ty": 6,
      "x": 837,
      "y": 466,
      "ta": "jspsych-survey-multi-choice-response-1[2]_mf"
    },
    {
      "t": 74098,
      "e": 69352,
      "ty": 2,
      "x": 835,
      "y": 470
    },
    {
      "t": 74111,
      "e": 69365,
      "ty": 7,
      "x": 833,
      "y": 479,
      "ta": "jspsych-survey-multi-choice-response-1[2]_mf"
    },
    {
      "t": 74198,
      "e": 69452,
      "ty": 2,
      "x": 828,
      "y": 490
    },
    {
      "t": 74212,
      "e": 69466,
      "ty": 6,
      "x": 826,
      "y": 494,
      "ta": "jspsych-survey-multi-choice-response-1[3]_mf"
    },
    {
      "t": 74228,
      "e": 69482,
      "ty": 7,
      "x": 825,
      "y": 500,
      "ta": "jspsych-survey-multi-choice-response-1[3]_mf"
    },
    {
      "t": 74248,
      "e": 69502,
      "ty": 41,
      "x": 3211,
      "y": 42597,
      "ta": "#jspsych-survey-multi-choice-option-1-3 > label"
    },
    {
      "t": 74298,
      "e": 69552,
      "ty": 2,
      "x": 825,
      "y": 502
    },
    {
      "t": 74399,
      "e": 69653,
      "ty": 2,
      "x": 825,
      "y": 503
    },
    {
      "t": 74500,
      "e": 69754,
      "ty": 41,
      "x": 3211,
      "y": 45874,
      "ta": "#jspsych-survey-multi-choice-option-1-3 > label"
    },
    {
      "t": 75099,
      "e": 70353,
      "ty": 2,
      "x": 825,
      "y": 502
    },
    {
      "t": 75249,
      "e": 70503,
      "ty": 41,
      "x": 3211,
      "y": 32767,
      "ta": "#jspsych-survey-multi-choice-option-1-3 > label"
    },
    {
      "t": 75299,
      "e": 70553,
      "ty": 2,
      "x": 825,
      "y": 498
    },
    {
      "t": 75399,
      "e": 70653,
      "ty": 2,
      "x": 825,
      "y": 493
    },
    {
      "t": 75414,
      "e": 70668,
      "ty": 6,
      "x": 826,
      "y": 492,
      "ta": "jspsych-survey-multi-choice-response-1[3]_mf"
    },
    {
      "t": 75499,
      "e": 70753,
      "ty": 2,
      "x": 826,
      "y": 492
    },
    {
      "t": 75500,
      "e": 70754,
      "ty": 41,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-1[3]_mf"
    },
    {
      "t": 76921,
      "e": 72175,
      "ty": 7,
      "x": 826,
      "y": 491,
      "ta": "jspsych-survey-multi-choice-response-1[3]_mf"
    },
    {
      "t": 76999,
      "e": 72253,
      "ty": 2,
      "x": 826,
      "y": 491
    },
    {
      "t": 76999,
      "e": 72253,
      "ty": 41,
      "x": 4109,
      "y": 6553,
      "ta": "#jspsych-survey-multi-choice-option-1-3 > label"
    },
    {
      "t": 77097,
      "e": 72351,
      "ty": 3,
      "x": 826,
      "y": 491,
      "ta": "#jspsych-survey-multi-choice-option-1-3 > label"
    },
    {
      "t": 77097,
      "e": 72351,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-0[0]_mf"
    },
    {
      "t": 77151,
      "e": 72405,
      "ty": 4,
      "x": 4109,
      "y": 6553,
      "ta": "#jspsych-survey-multi-choice-option-1-3 > label"
    },
    {
      "t": 77151,
      "e": 72405,
      "ty": 5,
      "x": 826,
      "y": 491,
      "ta": "#jspsych-survey-multi-choice-option-1-3 > label"
    },
    {
      "t": 77152,
      "e": 72406,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-1[3]_mf"
    },
    {
      "t": 77152,
      "e": 72406,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-1[3]_mf",
      "v": "Fourth"
    },
    {
      "t": 77382,
      "e": 72636,
      "ty": 6,
      "x": 829,
      "y": 492,
      "ta": "jspsych-survey-multi-choice-response-1[3]_mf"
    },
    {
      "t": 77399,
      "e": 72653,
      "ty": 2,
      "x": 831,
      "y": 495
    },
    {
      "t": 77499,
      "e": 72753,
      "ty": 2,
      "x": 834,
      "y": 499
    },
    {
      "t": 77499,
      "e": 72753,
      "ty": 41,
      "x": 38202,
      "y": 35288,
      "ta": "jspsych-survey-multi-choice-response-1[3]_mf"
    },
    {
      "t": 77785,
      "e": 73039,
      "ty": 7,
      "x": 848,
      "y": 499,
      "ta": "jspsych-survey-multi-choice-response-1[3]_mf"
    },
    {
      "t": 77799,
      "e": 73053,
      "ty": 2,
      "x": 853,
      "y": 499
    },
    {
      "t": 77899,
      "e": 73153,
      "ty": 2,
      "x": 955,
      "y": 493
    },
    {
      "t": 78000,
      "e": 73254,
      "ty": 41,
      "x": 31701,
      "y": 18724,
      "ta": "#jspsych-survey-multi-choice-option-1-3"
    },
    {
      "t": 78099,
      "e": 73353,
      "ty": 2,
      "x": 974,
      "y": 499
    },
    {
      "t": 78199,
      "e": 73453,
      "ty": 2,
      "x": 1169,
      "y": 579
    },
    {
      "t": 78249,
      "e": 73503,
      "ty": 41,
      "x": 41910,
      "y": 33459,
      "ta": "html > body"
    },
    {
      "t": 78299,
      "e": 73553,
      "ty": 2,
      "x": 1225,
      "y": 613
    },
    {
      "t": 78499,
      "e": 73753,
      "ty": 41,
      "x": 41910,
      "y": 33515,
      "ta": "html > body"
    },
    {
      "t": 78749,
      "e": 74003,
      "ty": 41,
      "x": 41497,
      "y": 34789,
      "ta": "html > body"
    },
    {
      "t": 78799,
      "e": 74053,
      "ty": 2,
      "x": 1160,
      "y": 717
    },
    {
      "t": 78899,
      "e": 74153,
      "ty": 2,
      "x": 1090,
      "y": 798
    },
    {
      "t": 78999,
      "e": 74253,
      "ty": 2,
      "x": 1072,
      "y": 812
    },
    {
      "t": 79000,
      "e": 74254,
      "ty": 41,
      "x": 59468,
      "y": 25745,
      "ta": "#jspsych-survey-multi-choice-option-2-5"
    },
    {
      "t": 79099,
      "e": 74353,
      "ty": 2,
      "x": 1032,
      "y": 839
    },
    {
      "t": 79199,
      "e": 74453,
      "ty": 2,
      "x": 957,
      "y": 852
    },
    {
      "t": 79249,
      "e": 74503,
      "ty": 41,
      "x": 16987,
      "y": 52158,
      "ta": "#jspsych-survey-multi-choice-form"
    },
    {
      "t": 79298,
      "e": 74552,
      "ty": 2,
      "x": 828,
      "y": 858
    },
    {
      "t": 79399,
      "e": 74653,
      "ty": 2,
      "x": 795,
      "y": 858
    },
    {
      "t": 79500,
      "e": 74754,
      "ty": 41,
      "x": 26964,
      "y": 47087,
      "ta": "html > body"
    },
    {
      "t": 79500,
      "e": 74754,
      "ty": 2,
      "x": 791,
      "y": 858
    },
    {
      "t": 79599,
      "e": 74853,
      "ty": 2,
      "x": 786,
      "y": 837
    },
    {
      "t": 79698,
      "e": 74952,
      "ty": 2,
      "x": 912,
      "y": 686
    },
    {
      "t": 79749,
      "e": 75003,
      "ty": 41,
      "x": 28884,
      "y": 22937,
      "ta": "#jspsych-survey-multi-choice-option-2-0 > label"
    },
    {
      "t": 79799,
      "e": 75053,
      "ty": 2,
      "x": 929,
      "y": 672
    },
    {
      "t": 79999,
      "e": 75253,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 80099,
      "e": 75353,
      "ty": 2,
      "x": 930,
      "y": 672
    },
    {
      "t": 80250,
      "e": 75504,
      "ty": 41,
      "x": 29153,
      "y": 22937,
      "ta": "#jspsych-survey-multi-choice-option-2-0 > label"
    },
    {
      "t": 80499,
      "e": 75753,
      "ty": 2,
      "x": 915,
      "y": 720
    },
    {
      "t": 80499,
      "e": 75753,
      "ty": 41,
      "x": 22208,
      "y": 7021,
      "ta": "#jspsych-survey-multi-choice-option-2-2"
    },
    {
      "t": 80599,
      "e": 75853,
      "ty": 2,
      "x": 894,
      "y": 758
    },
    {
      "t": 80699,
      "e": 75953,
      "ty": 2,
      "x": 891,
      "y": 766
    },
    {
      "t": 80749,
      "e": 76003,
      "ty": 41,
      "x": 29031,
      "y": 55704,
      "ta": "#jspsych-survey-multi-choice-option-2-3 > label"
    },
    {
      "t": 80799,
      "e": 76053,
      "ty": 2,
      "x": 889,
      "y": 767
    },
    {
      "t": 80899,
      "e": 76153,
      "ty": 2,
      "x": 871,
      "y": 808
    },
    {
      "t": 80999,
      "e": 76253,
      "ty": 2,
      "x": 861,
      "y": 827
    },
    {
      "t": 80999,
      "e": 76253,
      "ty": 41,
      "x": 9392,
      "y": 60853,
      "ta": "#jspsych-survey-multi-choice-option-2-5"
    },
    {
      "t": 81099,
      "e": 76353,
      "ty": 2,
      "x": 855,
      "y": 807
    },
    {
      "t": 81199,
      "e": 76453,
      "ty": 2,
      "x": 853,
      "y": 787
    },
    {
      "t": 81249,
      "e": 76503,
      "ty": 41,
      "x": 17118,
      "y": 16383,
      "ta": "#jspsych-survey-multi-choice-option-2-4 > label"
    },
    {
      "t": 81299,
      "e": 76553,
      "ty": 2,
      "x": 847,
      "y": 773
    },
    {
      "t": 81384,
      "e": 76638,
      "ty": 6,
      "x": 831,
      "y": 735,
      "ta": "jspsych-survey-multi-choice-response-2[2]_mf"
    },
    {
      "t": 81399,
      "e": 76653,
      "ty": 2,
      "x": 831,
      "y": 735
    },
    {
      "t": 81499,
      "e": 76753,
      "ty": 2,
      "x": 826,
      "y": 727
    },
    {
      "t": 81499,
      "e": 76753,
      "ty": 41,
      "x": 0,
      "y": 15123,
      "ta": "jspsych-survey-multi-choice-response-2[2]_mf"
    },
    {
      "t": 81518,
      "e": 76772,
      "ty": 7,
      "x": 824,
      "y": 722,
      "ta": "jspsych-survey-multi-choice-response-2[2]_mf"
    },
    {
      "t": 81599,
      "e": 76853,
      "ty": 2,
      "x": 820,
      "y": 720
    },
    {
      "t": 81700,
      "e": 76954,
      "ty": 2,
      "x": 818,
      "y": 718
    },
    {
      "t": 81749,
      "e": 77003,
      "ty": 41,
      "x": 27894,
      "y": 39332,
      "ta": "html > body"
    },
    {
      "t": 82099,
      "e": 77353,
      "ty": 2,
      "x": 822,
      "y": 723
    },
    {
      "t": 82199,
      "e": 77453,
      "ty": 2,
      "x": 824,
      "y": 725
    },
    {
      "t": 82217,
      "e": 77471,
      "ty": 6,
      "x": 827,
      "y": 728,
      "ta": "jspsych-survey-multi-choice-response-2[2]_mf"
    },
    {
      "t": 82249,
      "e": 77503,
      "ty": 41,
      "x": 7955,
      "y": 20164,
      "ta": "jspsych-survey-multi-choice-response-2[2]_mf"
    },
    {
      "t": 82299,
      "e": 77553,
      "ty": 2,
      "x": 829,
      "y": 728
    },
    {
      "t": 82399,
      "e": 77653,
      "ty": 2,
      "x": 829,
      "y": 729
    },
    {
      "t": 82499,
      "e": 77753,
      "ty": 41,
      "x": 12996,
      "y": 25205,
      "ta": "jspsych-survey-multi-choice-response-2[2]_mf"
    },
    {
      "t": 82599,
      "e": 77853,
      "ty": 2,
      "x": 833,
      "y": 729
    },
    {
      "t": 82681,
      "e": 77935,
      "ty": 3,
      "x": 833,
      "y": 728,
      "ta": "jspsych-survey-multi-choice-response-2[2]_mf"
    },
    {
      "t": 82682,
      "e": 77936,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-1[3]_mf"
    },
    {
      "t": 82683,
      "e": 77937,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-2[2]_mf"
    },
    {
      "t": 82699,
      "e": 77953,
      "ty": 2,
      "x": 833,
      "y": 728
    },
    {
      "t": 82749,
      "e": 78003,
      "ty": 41,
      "x": 33161,
      "y": 20164,
      "ta": "jspsych-survey-multi-choice-response-2[2]_mf"
    },
    {
      "t": 82776,
      "e": 78030,
      "ty": 4,
      "x": 33161,
      "y": 20164,
      "ta": "jspsych-survey-multi-choice-response-2[2]_mf"
    },
    {
      "t": 82776,
      "e": 78030,
      "ty": 5,
      "x": 833,
      "y": 728,
      "ta": "jspsych-survey-multi-choice-response-2[2]_mf"
    },
    {
      "t": 82776,
      "e": 78030,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-2[2]_mf",
      "v": "Biomedical & Health Sciences"
    },
    {
      "t": 82999,
      "e": 78253,
      "ty": 2,
      "x": 833,
      "y": 730
    },
    {
      "t": 82999,
      "e": 78253,
      "ty": 41,
      "x": 33161,
      "y": 30246,
      "ta": "jspsych-survey-multi-choice-response-2[2]_mf"
    },
    {
      "t": 83019,
      "e": 78273,
      "ty": 7,
      "x": 828,
      "y": 743,
      "ta": "jspsych-survey-multi-choice-response-2[2]_mf"
    },
    {
      "t": 83099,
      "e": 78353,
      "ty": 2,
      "x": 798,
      "y": 822
    },
    {
      "t": 83199,
      "e": 78453,
      "ty": 2,
      "x": 782,
      "y": 920
    },
    {
      "t": 83250,
      "e": 78504,
      "ty": 41,
      "x": 26654,
      "y": 50522,
      "ta": "html > body"
    },
    {
      "t": 83799,
      "e": 79053,
      "ty": 2,
      "x": 782,
      "y": 921
    },
    {
      "t": 83999,
      "e": 79253,
      "ty": 2,
      "x": 811,
      "y": 947
    },
    {
      "t": 83999,
      "e": 79253,
      "ty": 41,
      "x": 27653,
      "y": 52018,
      "ta": "html > body"
    },
    {
      "t": 84099,
      "e": 79353,
      "ty": 2,
      "x": 815,
      "y": 954
    },
    {
      "t": 84199,
      "e": 79453,
      "ty": 2,
      "x": 817,
      "y": 954
    },
    {
      "t": 84249,
      "e": 79503,
      "ty": 41,
      "x": 27963,
      "y": 52405,
      "ta": "html > body"
    },
    {
      "t": 84299,
      "e": 79553,
      "ty": 2,
      "x": 824,
      "y": 951
    },
    {
      "t": 84399,
      "e": 79653,
      "ty": 2,
      "x": 827,
      "y": 948
    },
    {
      "t": 84471,
      "e": 79725,
      "ty": 6,
      "x": 833,
      "y": 938,
      "ta": "jspsych-survey-multi-choice-response-3[0]_mf"
    },
    {
      "t": 84500,
      "e": 79754,
      "ty": 2,
      "x": 835,
      "y": 935
    },
    {
      "t": 84500,
      "e": 79754,
      "ty": 41,
      "x": 43243,
      "y": 35288,
      "ta": "jspsych-survey-multi-choice-response-3[0]_mf"
    },
    {
      "t": 84592,
      "e": 79846,
      "ty": 7,
      "x": 838,
      "y": 927,
      "ta": "jspsych-survey-multi-choice-response-3[0]_mf"
    },
    {
      "t": 84599,
      "e": 79853,
      "ty": 2,
      "x": 838,
      "y": 927
    },
    {
      "t": 84699,
      "e": 79953,
      "ty": 2,
      "x": 838,
      "y": 924
    },
    {
      "t": 84749,
      "e": 80003,
      "ty": 41,
      "x": 3934,
      "y": 7021,
      "ta": "#jspsych-survey-multi-choice-option-3-0"
    },
    {
      "t": 84904,
      "e": 80158,
      "ty": 3,
      "x": 838,
      "y": 924,
      "ta": "#jspsych-survey-multi-choice-option-3-0"
    },
    {
      "t": 84906,
      "e": 80160,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-2[2]_mf"
    },
    {
      "t": 85000,
      "e": 80254,
      "ty": 4,
      "x": 3934,
      "y": 7021,
      "ta": "#jspsych-survey-multi-choice-option-3-0"
    },
    {
      "t": 85007,
      "e": 80261,
      "ty": 5,
      "x": 838,
      "y": 924,
      "ta": "#jspsych-survey-multi-choice-option-3-0"
    },
    {
      "t": 85199,
      "e": 80453,
      "ty": 2,
      "x": 842,
      "y": 921
    },
    {
      "t": 85249,
      "e": 80503,
      "ty": 41,
      "x": 25753,
      "y": 0,
      "ta": "#jspsych-survey-multi-choice-option-3-0 > label"
    },
    {
      "t": 85299,
      "e": 80553,
      "ty": 2,
      "x": 846,
      "y": 930
    },
    {
      "t": 85399,
      "e": 80653,
      "ty": 2,
      "x": 846,
      "y": 931
    },
    {
      "t": 85499,
      "e": 80753,
      "ty": 2,
      "x": 846,
      "y": 932
    },
    {
      "t": 85499,
      "e": 80753,
      "ty": 41,
      "x": 26845,
      "y": 22937,
      "ta": "#jspsych-survey-multi-choice-option-3-0 > label"
    },
    {
      "t": 85699,
      "e": 80953,
      "ty": 2,
      "x": 846,
      "y": 933
    },
    {
      "t": 85749,
      "e": 81003,
      "ty": 41,
      "x": 22476,
      "y": 32767,
      "ta": "#jspsych-survey-multi-choice-option-3-0 > label"
    },
    {
      "t": 85799,
      "e": 81053,
      "ty": 2,
      "x": 841,
      "y": 935
    },
    {
      "t": 85833,
      "e": 81087,
      "ty": 6,
      "x": 839,
      "y": 936,
      "ta": "jspsych-survey-multi-choice-response-3[0]_mf"
    },
    {
      "t": 85899,
      "e": 81153,
      "ty": 2,
      "x": 838,
      "y": 936
    },
    {
      "t": 85999,
      "e": 81253,
      "ty": 41,
      "x": 58367,
      "y": 40329,
      "ta": "jspsych-survey-multi-choice-response-3[0]_mf"
    },
    {
      "t": 86145,
      "e": 81399,
      "ty": 3,
      "x": 838,
      "y": 936,
      "ta": "jspsych-survey-multi-choice-response-3[0]_mf"
    },
    {
      "t": 86145,
      "e": 81399,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-3[0]_mf"
    },
    {
      "t": 86234,
      "e": 81401,
      "ty": 4,
      "x": 58367,
      "y": 40329,
      "ta": "jspsych-survey-multi-choice-response-3[0]_mf"
    },
    {
      "t": 86236,
      "e": 81403,
      "ty": 5,
      "x": 838,
      "y": 936,
      "ta": "jspsych-survey-multi-choice-response-3[0]_mf"
    },
    {
      "t": 86237,
      "e": 81404,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-3[0]_mf",
      "v": "Male"
    },
    {
      "t": 86537,
      "e": 81704,
      "ty": 7,
      "x": 843,
      "y": 936,
      "ta": "jspsych-survey-multi-choice-response-3[0]_mf"
    },
    {
      "t": 86599,
      "e": 81766,
      "ty": 2,
      "x": 883,
      "y": 932
    },
    {
      "t": 86699,
      "e": 81866,
      "ty": 2,
      "x": 960,
      "y": 926
    },
    {
      "t": 86749,
      "e": 81916,
      "ty": 41,
      "x": 32888,
      "y": 11702,
      "ta": "#jspsych-survey-multi-choice-option-3-0"
    },
    {
      "t": 90900,
      "e": 86067,
      "ty": 2,
      "x": 948,
      "y": 912
    },
    {
      "t": 91000,
      "e": 86167,
      "ty": 2,
      "x": 944,
      "y": 928
    },
    {
      "t": 91000,
      "e": 86167,
      "ty": 41,
      "x": 29090,
      "y": 16383,
      "ta": "#jspsych-survey-multi-choice-option-3-0"
    },
    {
      "t": 91100,
      "e": 86267,
      "ty": 2,
      "x": 929,
      "y": 984
    },
    {
      "t": 91199,
      "e": 86366,
      "ty": 2,
      "x": 922,
      "y": 995
    },
    {
      "t": 91244,
      "e": 86411,
      "ty": 6,
      "x": 928,
      "y": 1014,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 91249,
      "e": 86416,
      "ty": 41,
      "x": 50806,
      "y": 17873,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 91298,
      "e": 86465,
      "ty": 2,
      "x": 934,
      "y": 1029
    },
    {
      "t": 91342,
      "e": 86509,
      "ty": 7,
      "x": 940,
      "y": 1041,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 91399,
      "e": 86566,
      "ty": 2,
      "x": 948,
      "y": 1058
    },
    {
      "t": 91498,
      "e": 86665,
      "ty": 2,
      "x": 948,
      "y": 1060
    },
    {
      "t": 91498,
      "e": 86665,
      "ty": 41,
      "x": 32371,
      "y": 58277,
      "ta": "html > body"
    },
    {
      "t": 91599,
      "e": 86766,
      "ty": 2,
      "x": 947,
      "y": 1058
    },
    {
      "t": 91699,
      "e": 86866,
      "ty": 2,
      "x": 933,
      "y": 1055
    },
    {
      "t": 91748,
      "e": 86915,
      "ty": 41,
      "x": 31613,
      "y": 58000,
      "ta": "html > body"
    },
    {
      "t": 91799,
      "e": 86966,
      "ty": 2,
      "x": 925,
      "y": 1055
    },
    {
      "t": 91898,
      "e": 87065,
      "ty": 2,
      "x": 892,
      "y": 1039
    },
    {
      "t": 91998,
      "e": 87165,
      "ty": 2,
      "x": 890,
      "y": 1038
    },
    {
      "t": 91999,
      "e": 87166,
      "ty": 41,
      "x": 30374,
      "y": 57059,
      "ta": "html > body"
    },
    {
      "t": 92097,
      "e": 87264,
      "ty": 6,
      "x": 889,
      "y": 1036,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 92098,
      "e": 87265,
      "ty": 2,
      "x": 889,
      "y": 1036
    },
    {
      "t": 92199,
      "e": 87366,
      "ty": 2,
      "x": 889,
      "y": 1035
    },
    {
      "t": 92248,
      "e": 87415,
      "ty": 41,
      "x": 30705,
      "y": 55605,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 92298,
      "e": 87465,
      "ty": 2,
      "x": 889,
      "y": 1033
    },
    {
      "t": 92398,
      "e": 87565,
      "ty": 2,
      "x": 889,
      "y": 1032
    },
    {
      "t": 92498,
      "e": 87665,
      "ty": 41,
      "x": 30705,
      "y": 53619,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 92585,
      "e": 87752,
      "ty": 3,
      "x": 889,
      "y": 1032,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 92585,
      "e": 87752,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-3[0]_mf"
    },
    {
      "t": 92586,
      "e": 87753,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 92671,
      "e": 87838,
      "ty": 4,
      "x": 30705,
      "y": 53619,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 92671,
      "e": 87838,
      "ty": 5,
      "x": 889,
      "y": 1032,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 92673,
      "e": 87840,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 92675,
      "e": 87842,
      "ty": 13,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-multi-choice-form"
    },
    {
      "t": 92675,
      "e": 87842,
      "ty": 38,
      "x": 6,
      "y": 0
    },
    {
      "t": 93099,
      "e": 88266,
      "ty": 2,
      "x": 1113,
      "y": 988
    },
    {
      "t": 93198,
      "e": 88365,
      "ty": 2,
      "x": 1267,
      "y": 927
    },
    {
      "t": 93249,
      "e": 88416,
      "ty": 41,
      "x": 43391,
      "y": 50854,
      "ta": "html > body"
    },
    {
      "t": 93298,
      "e": 88465,
      "ty": 2,
      "x": 1273,
      "y": 920
    },
    {
      "t": 93399,
      "e": 88566,
      "ty": 2,
      "x": 1319,
      "y": 859
    },
    {
      "t": 93498,
      "e": 88665,
      "ty": 2,
      "x": 1284,
      "y": 775
    },
    {
      "t": 93499,
      "e": 88666,
      "ty": 41,
      "x": 43942,
      "y": 42489,
      "ta": "html > body"
    },
    {
      "t": 93599,
      "e": 88766,
      "ty": 2,
      "x": 1213,
      "y": 709
    },
    {
      "t": 93698,
      "e": 88865,
      "ty": 2,
      "x": 1189,
      "y": 693
    },
    {
      "t": 93749,
      "e": 88916,
      "ty": 41,
      "x": 40257,
      "y": 37614,
      "ta": "html > body"
    },
    {
      "t": 93798,
      "e": 88965,
      "ty": 2,
      "x": 1171,
      "y": 687
    },
    {
      "t": 93999,
      "e": 89166,
      "ty": 41,
      "x": 40051,
      "y": 37614,
      "ta": "html > body"
    },
    {
      "t": 94028,
      "e": 89195,
      "ty": 38,
      "x": 7,
      "y": 0
    },
    {
      "t": 94799,
      "e": 89966,
      "ty": 2,
      "x": 1167,
      "y": 691
    },
    {
      "t": 94898,
      "e": 90065,
      "ty": 2,
      "x": 1164,
      "y": 694
    },
    {
      "t": 94998,
      "e": 90165,
      "ty": 2,
      "x": 1150,
      "y": 705
    },
    {
      "t": 94999,
      "e": 90166,
      "ty": 41,
      "x": 42139,
      "y": 21366,
      "ta": "> div.masterdiv > div:[2] > div > p:[4]"
    },
    {
      "t": 95099,
      "e": 90266,
      "ty": 2,
      "x": 1127,
      "y": 714
    },
    {
      "t": 95199,
      "e": 90366,
      "ty": 2,
      "x": 1101,
      "y": 728
    },
    {
      "t": 95248,
      "e": 90415,
      "ty": 41,
      "x": 39286,
      "y": 35409,
      "ta": "> div.masterdiv > div:[2] > div > p:[4]"
    },
    {
      "t": 95298,
      "e": 90465,
      "ty": 2,
      "x": 1081,
      "y": 733
    },
    {
      "t": 95399,
      "e": 90566,
      "ty": 2,
      "x": 1036,
      "y": 744
    },
    {
      "t": 95499,
      "e": 90666,
      "ty": 2,
      "x": 1005,
      "y": 744
    },
    {
      "t": 95499,
      "e": 90666,
      "ty": 41,
      "x": 35005,
      "y": 44186,
      "ta": "> div.masterdiv > div:[2] > div > p:[4]"
    },
    {
      "t": 95598,
      "e": 90765,
      "ty": 2,
      "x": 965,
      "y": 743
    },
    {
      "t": 95699,
      "e": 90866,
      "ty": 2,
      "x": 918,
      "y": 735
    },
    {
      "t": 95748,
      "e": 90915,
      "ty": 41,
      "x": 29495,
      "y": 38920,
      "ta": "> div.masterdiv > div:[2] > div > p:[4]"
    },
    {
      "t": 95798,
      "e": 90965,
      "ty": 2,
      "x": 861,
      "y": 734
    },
    {
      "t": 95898,
      "e": 91065,
      "ty": 2,
      "x": 781,
      "y": 735
    },
    {
      "t": 95999,
      "e": 91166,
      "ty": 2,
      "x": 755,
      "y": 736
    },
    {
      "t": 95999,
      "e": 91166,
      "ty": 41,
      "x": 22706,
      "y": 39505,
      "ta": "> div.masterdiv > div:[2] > div > p:[4]"
    },
    {
      "t": 96199,
      "e": 91366,
      "ty": 2,
      "x": 818,
      "y": 708
    },
    {
      "t": 96249,
      "e": 91416,
      "ty": 41,
      "x": 26839,
      "y": 14344,
      "ta": "> div.masterdiv > div:[2] > div > p:[4]"
    },
    {
      "t": 96299,
      "e": 91466,
      "ty": 2,
      "x": 864,
      "y": 684
    },
    {
      "t": 96398,
      "e": 91565,
      "ty": 2,
      "x": 912,
      "y": 681
    },
    {
      "t": 96498,
      "e": 91665,
      "ty": 2,
      "x": 938,
      "y": 681
    },
    {
      "t": 96498,
      "e": 91665,
      "ty": 41,
      "x": 31709,
      "y": 7323,
      "ta": "> div.masterdiv > div:[2] > div > p:[4]"
    },
    {
      "t": 96599,
      "e": 91766,
      "ty": 2,
      "x": 957,
      "y": 670
    },
    {
      "t": 96698,
      "e": 91865,
      "ty": 2,
      "x": 960,
      "y": 666
    },
    {
      "t": 96749,
      "e": 91916,
      "ty": 41,
      "x": 32792,
      "y": 38384,
      "ta": "> div.masterdiv > div:[2] > div"
    },
    {
      "t": 99999,
      "e": 95166,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 119998,
      "e": 96916,
      "ty": 2,
      "x": 935,
      "y": 980
    },
    {
      "t": 119998,
      "e": 96916,
      "ty": 41,
      "x": 31562,
      "y": 59116,
      "ta": "> div.masterdiv > div:[2]"
    },
    {
      "t": 120015,
      "e": 96933,
      "ty": 6,
      "x": 935,
      "y": 1074,
      "ta": "#start"
    },
    {
      "t": 120030,
      "e": 96948,
      "ty": 7,
      "x": 935,
      "y": 1158,
      "ta": "#start"
    },
    {
      "t": 120098,
      "e": 97016,
      "ty": 2,
      "x": 935,
      "y": 1199
    },
    {
      "t": 120197,
      "e": 97115,
      "ty": 2,
      "x": 948,
      "y": 1199
    },
    {
      "t": 120248,
      "e": 97166,
      "ty": 41,
      "x": 33469,
      "y": 57787,
      "ta": "> div.masterdiv > div:[3]"
    },
    {
      "t": 120297,
      "e": 97215,
      "ty": 2,
      "x": 976,
      "y": 1135
    },
    {
      "t": 120347,
      "e": 97265,
      "ty": 6,
      "x": 986,
      "y": 1101,
      "ta": "#start"
    },
    {
      "t": 120397,
      "e": 97315,
      "ty": 2,
      "x": 988,
      "y": 1097
    },
    {
      "t": 120498,
      "e": 97416,
      "ty": 41,
      "x": 42870,
      "y": 46862,
      "ta": "#start"
    },
    {
      "t": 121246,
      "e": 98164,
      "ty": 41,
      "x": 43416,
      "y": 43007,
      "ta": "#start"
    },
    {
      "t": 121298,
      "e": 98216,
      "ty": 2,
      "x": 990,
      "y": 1095
    },
    {
      "t": 121497,
      "e": 98415,
      "ty": 41,
      "x": 43963,
      "y": 43007,
      "ta": "#start"
    },
    {
      "t": 121897,
      "e": 98815,
      "ty": 2,
      "x": 991,
      "y": 1094
    },
    {
      "t": 121997,
      "e": 98915,
      "ty": 41,
      "x": 44509,
      "y": 41079,
      "ta": "#start"
    },
    {
      "t": 122847,
      "e": 99765,
      "ty": 3,
      "x": 991,
      "y": 1094,
      "ta": "#start"
    },
    {
      "t": 122848,
      "e": 99766,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#start"
    },
    {
      "t": 122948,
      "e": 99866,
      "ty": 4,
      "x": 44509,
      "y": 41079,
      "ta": "#start"
    },
    {
      "t": 122949,
      "e": 99867,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#start"
    },
    {
      "t": 122950,
      "e": 99868,
      "ty": 5,
      "x": 991,
      "y": 1094,
      "ta": "#start"
    },
    {
      "t": 122950,
      "e": 99868,
      "ty": 38,
      "x": 8,
      "y": 0
    },
    {
      "t": 123696,
      "e": 100614,
      "ty": 2,
      "x": 1019,
      "y": 1078
    },
    {
      "t": 123747,
      "e": 100665,
      "ty": 41,
      "x": 35092,
      "y": 58776,
      "ta": "html > body"
    },
    {
      "t": 123797,
      "e": 100715,
      "ty": 2,
      "x": 1041,
      "y": 1054
    },
    {
      "t": 123897,
      "e": 100815,
      "ty": 2,
      "x": 1056,
      "y": 1042
    },
    {
      "t": 123986,
      "e": 100904,
      "ty": 38,
      "x": 9,
      "y": 0
    },
    {
      "t": 124973,
      "e": 101891,
      "ty": 2,
      "x": 1086,
      "y": 1021
    },
    {
      "t": 124973,
      "e": 101891,
      "ty": 41,
      "x": 40246,
      "y": 32845,
      "ta": "#jspsych-data-display"
    },
    {
      "t": 125197,
      "e": 102115,
      "ty": 2,
      "x": 1099,
      "y": 1013
    },
    {
      "t": 125246,
      "e": 102164,
      "ty": 41,
      "x": 42198,
      "y": 32841,
      "ta": "#jspsych-data-display"
    },
    {
      "t": 125297,
      "e": 102215,
      "ty": 2,
      "x": 1139,
      "y": 992
    },
    {
      "t": 125397,
      "e": 102315,
      "ty": 2,
      "x": 1140,
      "y": 991
    },
    {
      "t": 125497,
      "e": 102415,
      "ty": 2,
      "x": 1141,
      "y": 990
    },
    {
      "t": 125497,
      "e": 102415,
      "ty": 41,
      "x": 43498,
      "y": 32839,
      "ta": "#jspsych-data-display"
    },
    {
      "t": 125697,
      "e": 102615,
      "ty": 2,
      "x": 1145,
      "y": 987
    },
    {
      "t": 125732,
      "e": 102650,
      "ty": 20,
      "x": 0,
      "y": 0
    }
  ],
  "domMutations": [
    {
      "sequence": 1,
      "data": "{\"f\":\"applyChanged\",\"args\":[[],[{\"nodeType\":1,\"id\":2311,\"tagName\":\"g\",\"attributes\":{\"class\":\"xaxis\",\"transform\":\"translate(0,800)\",\"fill\":\"none\",\"font-size\":\"10\",\"font-family\":\"sans-serif\",\"text-anchor\":\"middle\"},\"previousSibling\":{\"id\":2302},\"parentNode\":{\"id\":2300}},{\"nodeType\":1,\"id\":2312,\"tagName\":\"g\",\"attributes\":{\"class\":\"yaxis\",\"fill\":\"none\",\"font-size\":\"10\",\"font-family\":\"sans-serif\",\"text-anchor\":\"end\"},\"previousSibling\":{\"id\":2311},\"parentNode\":{\"id\":2300}},{\"nodeType\":1,\"id\":2313,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"previousSibling\":{\"id\":2312},\"parentNode\":{\"id\":2300}},{\"nodeType\":1,\"id\":2314,\"tagName\":\"g\",\"attributes\":{\"class\":\"xgrid\"},\"previousSibling\":{\"id\":2313},\"parentNode\":{\"id\":2300}},{\"nodeType\":1,\"id\":2315,\"tagName\":\"g\",\"attributes\":{\"class\":\"data\"},\"previousSibling\":{\"id\":2314},\"parentNode\":{\"id\":2300}},{\"nodeType\":1,\"id\":2316,\"tagName\":\"path\",\"attributes\":{\"class\":\"domain\",\"stroke\":\"#000\",\"d\":\"M0.5,6V0.5H800.5V6\"},\"parentNode\":{\"id\":2311}},{\"nodeType\":1,\"id\":2317,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0.5,0)\"},\"previousSibling\":{\"id\":2316},\"parentNode\":{\"id\":2311}},{\"nodeType\":1,\"id\":2318,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(33.83333333333333,0)\"},\"previousSibling\":{\"id\":2317},\"parentNode\":{\"id\":2311}},{\"nodeType\":1,\"id\":2319,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(67.16666666666666,0)\"},\"previousSibling\":{\"id\":2318},\"parentNode\":{\"id\":2311}},{\"nodeType\":1,\"id\":2320,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(100.5,0)\"},\"previousSibling\":{\"id\":2319},\"parentNode\":{\"id\":2311}},{\"nodeType\":1,\"id\":2321,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(133.83333333333331,0)\"},\"previousSibling\":{\"id\":2320},\"parentNode\":{\"id\":2311}},{\"nodeType\":1,\"id\":2322,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(167.16666666666669,0)\"},\"previousSibling\":{\"id\":2321},\"parentNode\":{\"id\":2311}},{\"nodeType\":1,\"id\":2323,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(200.5,0)\"},\"previousSibling\":{\"id\":2322},\"parentNode\":{\"id\":2311}},{\"nodeType\":1,\"id\":2324,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(233.83333333333334,0)\"},\"previousSibling\":{\"id\":2323},\"parentNode\":{\"id\":2311}},{\"nodeType\":1,\"id\":2325,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(267.16666666666663,0)\"},\"previousSibling\":{\"id\":2324},\"parentNode\":{\"id\":2311}},{\"nodeType\":1,\"id\":2326,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(300.5,0)\"},\"previousSibling\":{\"id\":2325},\"parentNode\":{\"id\":2311}},{\"nodeType\":1,\"id\":2327,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(333.83333333333337,0)\"},\"previousSibling\":{\"id\":2326},\"parentNode\":{\"id\":2311}},{\"nodeType\":1,\"id\":2328,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(367.16666666666663,0)\"},\"previousSibling\":{\"id\":2327},\"parentNode\":{\"id\":2311}},{\"nodeType\":1,\"id\":2329,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(400.5,0)\"},\"previousSibling\":{\"id\":2328},\"parentNode\":{\"id\":2311}},{\"nodeType\":1,\"id\":2330,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(433.8333333333333,0)\"},\"previousSibling\":{\"id\":2329},\"parentNode\":{\"id\":2311}},{\"nodeType\":1,\"id\":2331,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(467.1666666666667,0)\"},\"previousSibling\":{\"id\":2330},\"parentNode\":{\"id\":2311}},{\"nodeType\":1,\"id\":2332,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(500.5,0)\"},\"previousSibling\":{\"id\":2331},\"parentNode\":{\"id\":2311}},{\"nodeType\":1,\"id\":2333,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(533.8333333333333,0)\"},\"previousSibling\":{\"id\":2332},\"parentNode\":{\"id\":2311}},{\"nodeType\":1,\"id\":2334,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(567.1666666666667,0)\"},\"previousSibling\":{\"id\":2333},\"parentNode\":{\"id\":2311}},{\"nodeType\":1,\"id\":2335,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(600.5,0)\"},\"previousSibling\":{\"id\":2334},\"parentNode\":{\"id\":2311}},{\"nodeType\":1,\"id\":2336,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(633.8333333333333,0)\"},\"previousSibling\":{\"id\":2335},\"parentNode\":{\"id\":2311}},{\"nodeType\":1,\"id\":2337,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(667.1666666666667,0)\"},\"previousSibling\":{\"id\":2336},\"parentNode\":{\"id\":2311}},{\"nodeType\":1,\"id\":2338,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(700.5,0)\"},\"previousSibling\":{\"id\":2337},\"parentNode\":{\"id\":2311}},{\"nodeType\":1,\"id\":2339,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(733.8333333333333,0)\"},\"previousSibling\":{\"id\":2338},\"parentNode\":{\"id\":2311}},{\"nodeType\":1,\"id\":2340,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(767.1666666666667,0)\"},\"previousSibling\":{\"id\":2339},\"parentNode\":{\"id\":2311}},{\"nodeType\":1,\"id\":2341,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(800.5,0)\"},\"previousSibling\":{\"id\":2340},\"parentNode\":{\"id\":2311}},{\"nodeType\":1,\"id\":2342,\"tagName\":\"g\",\"attributes\":{\"class\":\"axisTitle\"},\"previousSibling\":{\"id\":2341},\"parentNode\":{\"id\":2311}},{\"nodeType\":1,\"id\":2343,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"},\"parentNode\":{\"id\":2317}},{\"nodeType\":1,\"id\":2344,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"previousSibling\":{\"id\":2343},\"parentNode\":{\"id\":2317}},{\"nodeType\":1,\"id\":2345,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"},\"parentNode\":{\"id\":2318}},{\"nodeType\":1,\"id\":2346,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"previousSibling\":{\"id\":2345},\"parentNode\":{\"id\":2318}},{\"nodeType\":1,\"id\":2347,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"},\"parentNode\":{\"id\":2319}},{\"nodeType\":1,\"id\":2348,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"previousSibling\":{\"id\":2347},\"parentNode\":{\"id\":2319}},{\"nodeType\":1,\"id\":2349,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"},\"parentNode\":{\"id\":2320}},{\"nodeType\":1,\"id\":2350,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"previousSibling\":{\"id\":2349},\"parentNode\":{\"id\":2320}},{\"nodeType\":1,\"id\":2351,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"},\"parentNode\":{\"id\":2321}},{\"nodeType\":1,\"id\":2352,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"previousSibling\":{\"id\":2351},\"parentNode\":{\"id\":2321}},{\"nodeType\":1,\"id\":2353,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"},\"parentNode\":{\"id\":2322}},{\"nodeType\":1,\"id\":2354,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"previousSibling\":{\"id\":2353},\"parentNode\":{\"id\":2322}},{\"nodeType\":1,\"id\":2355,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"},\"parentNode\":{\"id\":2323}},{\"nodeType\":1,\"id\":2356,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"previousSibling\":{\"id\":2355},\"parentNode\":{\"id\":2323}},{\"nodeType\":1,\"id\":2357,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"},\"parentNode\":{\"id\":2324}},{\"nodeType\":1,\"id\":2358,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"previousSibling\":{\"id\":2357},\"parentNode\":{\"id\":2324}},{\"nodeType\":1,\"id\":2359,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"},\"parentNode\":{\"id\":2325}},{\"nodeType\":1,\"id\":2360,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"previousSibling\":{\"id\":2359},\"parentNode\":{\"id\":2325}},{\"nodeType\":1,\"id\":2361,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"},\"parentNode\":{\"id\":2326}},{\"nodeType\":1,\"id\":2362,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"previousSibling\":{\"id\":2361},\"parentNode\":{\"id\":2326}},{\"nodeType\":1,\"id\":2363,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"},\"parentNode\":{\"id\":2327}},{\"nodeType\":1,\"id\":2364,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"previousSibling\":{\"id\":2363},\"parentNode\":{\"id\":2327}},{\"nodeType\":1,\"id\":2365,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"},\"parentNode\":{\"id\":2328}},{\"nodeType\":1,\"id\":2366,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"previousSibling\":{\"id\":2365},\"parentNode\":{\"id\":2328}},{\"nodeType\":1,\"id\":2367,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"},\"parentNode\":{\"id\":2329}},{\"nodeType\":1,\"id\":2368,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"previousSibling\":{\"id\":2367},\"parentNode\":{\"id\":2329}},{\"nodeType\":1,\"id\":2369,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"},\"parentNode\":{\"id\":2330}},{\"nodeType\":1,\"id\":2370,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"previousSibling\":{\"id\":2369},\"parentNode\":{\"id\":2330}},{\"nodeType\":1,\"id\":2371,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"},\"parentNode\":{\"id\":2331}},{\"nodeType\":1,\"id\":2372,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"previousSibling\":{\"id\":2371},\"parentNode\":{\"id\":2331}},{\"nodeType\":1,\"id\":2373,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"},\"parentNode\":{\"id\":2332}},{\"nodeType\":1,\"id\":2374,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"previousSibling\":{\"id\":2373},\"parentNode\":{\"id\":2332}},{\"nodeType\":1,\"id\":2375,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"},\"parentNode\":{\"id\":2333}},{\"nodeType\":1,\"id\":2376,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"previousSibling\":{\"id\":2375},\"parentNode\":{\"id\":2333}},{\"nodeType\":1,\"id\":2377,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"},\"parentNode\":{\"id\":2334}},{\"nodeType\":1,\"id\":2378,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"previousSibling\":{\"id\":2377},\"parentNode\":{\"id\":2334}},{\"nodeType\":1,\"id\":2379,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"},\"parentNode\":{\"id\":2335}},{\"nodeType\":1,\"id\":2380,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"previousSibling\":{\"id\":2379},\"parentNode\":{\"id\":2335}},{\"nodeType\":1,\"id\":2381,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"},\"parentNode\":{\"id\":2336}},{\"nodeType\":1,\"id\":2382,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"previousSibling\":{\"id\":2381},\"parentNode\":{\"id\":2336}},{\"nodeType\":1,\"id\":2383,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"},\"parentNode\":{\"id\":2337}},{\"nodeType\":1,\"id\":2384,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"previousSibling\":{\"id\":2383},\"parentNode\":{\"id\":2337}},{\"nodeType\":1,\"id\":2385,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"},\"parentNode\":{\"id\":2338}},{\"nodeType\":1,\"id\":2386,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"previousSibling\":{\"id\":2385},\"parentNode\":{\"id\":2338}},{\"nodeType\":1,\"id\":2387,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"},\"parentNode\":{\"id\":2339}},{\"nodeType\":1,\"id\":2388,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"previousSibling\":{\"id\":2387},\"parentNode\":{\"id\":2339}},{\"nodeType\":1,\"id\":2389,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"},\"parentNode\":{\"id\":2340}},{\"nodeType\":1,\"id\":2390,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"previousSibling\":{\"id\":2389},\"parentNode\":{\"id\":2340}},{\"nodeType\":1,\"id\":2391,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"},\"parentNode\":{\"id\":2341}},{\"nodeType\":1,\"id\":2392,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"previousSibling\":{\"id\":2391},\"parentNode\":{\"id\":2341}},{\"nodeType\":3,\"id\":2393,\"textContent\":\"08 AM\",\"parentNode\":{\"id\":2344}},{\"nodeType\":3,\"id\":2394,\"textContent\":\"08:30\",\"parentNode\":{\"id\":2346}},{\"nodeType\":3,\"id\":2395,\"textContent\":\"09 AM\",\"parentNode\":{\"id\":2348}},{\"nodeType\":3,\"id\":2396,\"textContent\":\"09:30\",\"parentNode\":{\"id\":2350}},{\"nodeType\":3,\"id\":2397,\"textContent\":\"10 AM\",\"parentNode\":{\"id\":2352}},{\"nodeType\":3,\"id\":2398,\"textContent\":\"10:30\",\"parentNode\":{\"id\":2354}},{\"nodeType\":3,\"id\":2399,\"textContent\":\"11 AM\",\"parentNode\":{\"id\":2356}},{\"nodeType\":3,\"id\":2400,\"textContent\":\"11:30\",\"parentNode\":{\"id\":2358}},{\"nodeType\":3,\"id\":2401,\"textContent\":\"12 PM\",\"parentNode\":{\"id\":2360}},{\"nodeType\":3,\"id\":2402,\"textContent\":\"12:30\",\"parentNode\":{\"id\":2362}},{\"nodeType\":3,\"id\":2403,\"textContent\":\"01 PM\",\"parentNode\":{\"id\":2364}},{\"nodeType\":3,\"id\":2404,\"textContent\":\"01:30\",\"parentNode\":{\"id\":2366}},{\"nodeType\":3,\"id\":2405,\"textContent\":\"02 PM\",\"parentNode\":{\"id\":2368}},{\"nodeType\":3,\"id\":2406,\"textContent\":\"02:30\",\"parentNode\":{\"id\":2370}},{\"nodeType\":3,\"id\":2407,\"textContent\":\"03 PM\",\"parentNode\":{\"id\":2372}},{\"nodeType\":3,\"id\":2408,\"textContent\":\"03:30\",\"parentNode\":{\"id\":2374}},{\"nodeType\":3,\"id\":2409,\"textContent\":\"04 PM\",\"parentNode\":{\"id\":2376}},{\"nodeType\":3,\"id\":2410,\"textContent\":\"04:30\",\"parentNode\":{\"id\":2378}},{\"nodeType\":3,\"id\":2411,\"textContent\":\"05 PM\",\"parentNode\":{\"id\":2380}},{\"nodeType\":3,\"id\":2412,\"textContent\":\"05:30\",\"parentNode\":{\"id\":2382}},{\"nodeType\":3,\"id\":2413,\"textContent\":\"06 PM\",\"parentNode\":{\"id\":2384}},{\"nodeType\":3,\"id\":2414,\"textContent\":\"06:30\",\"parentNode\":{\"id\":2386}},{\"nodeType\":3,\"id\":2415,\"textContent\":\"07 PM\",\"parentNode\":{\"id\":2388}},{\"nodeType\":3,\"id\":2416,\"textContent\":\"07:30\",\"parentNode\":{\"id\":2390}},{\"nodeType\":3,\"id\":2417,\"textContent\":\"08 PM\",\"parentNode\":{\"id\":2392}},{\"nodeType\":1,\"id\":2418,\"tagName\":\"text\",\"attributes\":{\"x\":\"533.3333333333334\",\"y\":\"80\",\"style\":\"text-anchor: end;\"},\"parentNode\":{\"id\":2342}},{\"nodeType\":3,\"id\":2419,\"textContent\":\"START & END TIME (time of day)\",\"parentNode\":{\"id\":2418}},{\"nodeType\":1,\"id\":2420,\"tagName\":\"path\",\"attributes\":{\"class\":\"domain\",\"stroke\":\"#000\",\"d\":\"M-15,800.5H0.5V0.5H-15\"},\"parentNode\":{\"id\":2312}},{\"nodeType\":1,\"id\":2421,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,800.5)\"},\"previousSibling\":{\"id\":2420},\"parentNode\":{\"id\":2312}},{\"nodeType\":1,\"id\":2422,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,733.8333333333334)\"},\"previousSibling\":{\"id\":2421},\"parentNode\":{\"id\":2312}},{\"nodeType\":1,\"id\":2423,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,667.1666666666667)\"},\"previousSibling\":{\"id\":2422},\"parentNode\":{\"id\":2312}},{\"nodeType\":1,\"id\":2424,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,600.5)\"},\"previousSibling\":{\"id\":2423},\"parentNode\":{\"id\":2312}},{\"nodeType\":1,\"id\":2425,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,533.8333333333334)\"},\"previousSibling\":{\"id\":2424},\"parentNode\":{\"id\":2312}},{\"nodeType\":1,\"id\":2426,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,467.16666666666663)\"},\"previousSibling\":{\"id\":2425},\"parentNode\":{\"id\":2312}},{\"nodeType\":1,\"id\":2427,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,400.5)\"},\"previousSibling\":{\"id\":2426},\"parentNode\":{\"id\":2312}},{\"nodeType\":1,\"id\":2428,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,333.8333333333333)\"},\"previousSibling\":{\"id\":2427},\"parentNode\":{\"id\":2312}},{\"nodeType\":1,\"id\":2429,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,267.16666666666674)\"},\"previousSibling\":{\"id\":2428},\"parentNode\":{\"id\":2312}},{\"nodeType\":1,\"id\":2430,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,200.5)\"},\"previousSibling\":{\"id\":2429},\"parentNode\":{\"id\":2312}},{\"nodeType\":1,\"id\":2431,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,133.83333333333326)\"},\"previousSibling\":{\"id\":2430},\"parentNode\":{\"id\":2312}},{\"nodeType\":1,\"id\":2432,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,67.16666666666674)\"},\"previousSibling\":{\"id\":2431},\"parentNode\":{\"id\":2312}},{\"nodeType\":1,\"id\":2433,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,0.5)\"},\"previousSibling\":{\"id\":2432},\"parentNode\":{\"id\":2312}},{\"nodeType\":1,\"id\":2434,\"tagName\":\"g\",\"attributes\":{\"class\":\"axisTitle\"},\"previousSibling\":{\"id\":2433},\"parentNode\":{\"id\":2312}},{\"nodeType\":1,\"id\":2435,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"},\"parentNode\":{\"id\":2421}},{\"nodeType\":1,\"id\":2436,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"previousSibling\":{\"id\":2435},\"parentNode\":{\"id\":2421}},{\"nodeType\":1,\"id\":2437,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"},\"parentNode\":{\"id\":2422}},{\"nodeType\":1,\"id\":2438,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"previousSibling\":{\"id\":2437},\"parentNode\":{\"id\":2422}},{\"nodeType\":1,\"id\":2439,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"},\"parentNode\":{\"id\":2423}},{\"nodeType\":1,\"id\":2440,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"previousSibling\":{\"id\":2439},\"parentNode\":{\"id\":2423}},{\"nodeType\":1,\"id\":2441,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"},\"parentNode\":{\"id\":2424}},{\"nodeType\":1,\"id\":2442,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"previousSibling\":{\"id\":2441},\"parentNode\":{\"id\":2424}},{\"nodeType\":1,\"id\":2443,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"},\"parentNode\":{\"id\":2425}},{\"nodeType\":1,\"id\":2444,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"previousSibling\":{\"id\":2443},\"parentNode\":{\"id\":2425}},{\"nodeType\":1,\"id\":2445,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"},\"parentNode\":{\"id\":2426}},{\"nodeType\":1,\"id\":2446,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"previousSibling\":{\"id\":2445},\"parentNode\":{\"id\":2426}},{\"nodeType\":1,\"id\":2447,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"},\"parentNode\":{\"id\":2427}},{\"nodeType\":1,\"id\":2448,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"previousSibling\":{\"id\":2447},\"parentNode\":{\"id\":2427}},{\"nodeType\":1,\"id\":2449,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"},\"parentNode\":{\"id\":2428}},{\"nodeType\":1,\"id\":2450,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"previousSibling\":{\"id\":2449},\"parentNode\":{\"id\":2428}},{\"nodeType\":1,\"id\":2451,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"},\"parentNode\":{\"id\":2429}},{\"nodeType\":1,\"id\":2452,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"previousSibling\":{\"id\":2451},\"parentNode\":{\"id\":2429}},{\"nodeType\":1,\"id\":2453,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"},\"parentNode\":{\"id\":2430}},{\"nodeType\":1,\"id\":2454,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"previousSibling\":{\"id\":2453},\"parentNode\":{\"id\":2430}},{\"nodeType\":1,\"id\":2455,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"},\"parentNode\":{\"id\":2431}},{\"nodeType\":1,\"id\":2456,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"previousSibling\":{\"id\":2455},\"parentNode\":{\"id\":2431}},{\"nodeType\":1,\"id\":2457,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"},\"parentNode\":{\"id\":2432}},{\"nodeType\":1,\"id\":2458,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"previousSibling\":{\"id\":2457},\"parentNode\":{\"id\":2432}},{\"nodeType\":1,\"id\":2459,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"},\"parentNode\":{\"id\":2433}},{\"nodeType\":1,\"id\":2460,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"previousSibling\":{\"id\":2459},\"parentNode\":{\"id\":2433}},{\"nodeType\":3,\"id\":2461,\"textContent\":\"0\",\"parentNode\":{\"id\":2436}},{\"nodeType\":3,\"id\":2462,\"textContent\":\"1\",\"parentNode\":{\"id\":2438}},{\"nodeType\":3,\"id\":2463,\"textContent\":\"2\",\"parentNode\":{\"id\":2440}},{\"nodeType\":3,\"id\":2464,\"textContent\":\"3\",\"parentNode\":{\"id\":2442}},{\"nodeType\":3,\"id\":2465,\"textContent\":\"4\",\"parentNode\":{\"id\":2444}},{\"nodeType\":3,\"id\":2466,\"textContent\":\"5\",\"parentNode\":{\"id\":2446}},{\"nodeType\":3,\"id\":2467,\"textContent\":\"6\",\"parentNode\":{\"id\":2448}},{\"nodeType\":3,\"id\":2468,\"textContent\":\"7\",\"parentNode\":{\"id\":2450}},{\"nodeType\":3,\"id\":2469,\"textContent\":\"8\",\"parentNode\":{\"id\":2452}},{\"nodeType\":3,\"id\":2470,\"textContent\":\"9\",\"parentNode\":{\"id\":2454}},{\"nodeType\":3,\"id\":2471,\"textContent\":\"10\",\"parentNode\":{\"id\":2456}},{\"nodeType\":3,\"id\":2472,\"textContent\":\"11\",\"parentNode\":{\"id\":2458}},{\"nodeType\":3,\"id\":2473,\"textContent\":\"12\",\"parentNode\":{\"id\":2460}},{\"nodeType\":1,\"id\":2474,\"tagName\":\"text\",\"attributes\":{\"transform\":\"rotate(-90)\",\"x\":\"-350\",\"y\":\"-60\",\"style\":\"text-anchor: end;\"},\"parentNode\":{\"id\":2434}},{\"nodeType\":3,\"id\":2475,\"textContent\":\"DURATION (in hours)\",\"parentNode\":{\"id\":2474}},{\"nodeType\":1,\"id\":2476,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"parentNode\":{\"id\":2313}},{\"nodeType\":1,\"id\":2477,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"previousSibling\":{\"id\":2476},\"parentNode\":{\"id\":2313}},{\"nodeType\":1,\"id\":2478,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"previousSibling\":{\"id\":2477},\"parentNode\":{\"id\":2313}},{\"nodeType\":1,\"id\":2479,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"previousSibling\":{\"id\":2478},\"parentNode\":{\"id\":2313}},{\"nodeType\":1,\"id\":2480,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"previousSibling\":{\"id\":2479},\"parentNode\":{\"id\":2313}},{\"nodeType\":1,\"id\":2481,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"previousSibling\":{\"id\":2480},\"parentNode\":{\"id\":2313}},{\"nodeType\":1,\"id\":2482,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"previousSibling\":{\"id\":2481},\"parentNode\":{\"id\":2313}},{\"nodeType\":1,\"id\":2483,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"previousSibling\":{\"id\":2482},\"parentNode\":{\"id\":2313}},{\"nodeType\":1,\"id\":2484,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"previousSibling\":{\"id\":2483},\"parentNode\":{\"id\":2313}},{\"nodeType\":1,\"id\":2485,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"previousSibling\":{\"id\":2484},\"parentNode\":{\"id\":2313}},{\"nodeType\":1,\"id\":2486,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"previousSibling\":{\"id\":2485},\"parentNode\":{\"id\":2313}},{\"nodeType\":1,\"id\":2487,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"previousSibling\":{\"id\":2486},\"parentNode\":{\"id\":2313}},{\"nodeType\":1,\"id\":2488,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"733.3333333333334\",\"y2\":\"733.3333333333334\"},\"parentNode\":{\"id\":2476}},{\"nodeType\":1,\"id\":2489,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"666.6666666666667\",\"y2\":\"666.6666666666667\"},\"parentNode\":{\"id\":2477}},{\"nodeType\":1,\"id\":2490,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"600\",\"y2\":\"600\"},\"parentNode\":{\"id\":2478}},{\"nodeType\":1,\"id\":2491,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"533.3333333333334\",\"y2\":\"533.3333333333334\"},\"parentNode\":{\"id\":2479}},{\"nodeType\":1,\"id\":2492,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"466.66666666666663\",\"y2\":\"466.66666666666663\"},\"parentNode\":{\"id\":2480}},{\"nodeType\":1,\"id\":2493,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"400\",\"y2\":\"400\"},\"parentNode\":{\"id\":2481}},{\"nodeType\":1,\"id\":2494,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"333.3333333333333\",\"y2\":\"333.3333333333333\"},\"parentNode\":{\"id\":2482}},{\"nodeType\":1,\"id\":2495,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"266.66666666666674\",\"y2\":\"266.66666666666674\"},\"parentNode\":{\"id\":2483}},{\"nodeType\":1,\"id\":2496,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"200\",\"y2\":\"200\"},\"parentNode\":{\"id\":2484}},{\"nodeType\":1,\"id\":2497,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"133.33333333333326\",\"y2\":\"133.33333333333326\"},\"parentNode\":{\"id\":2485}},{\"nodeType\":1,\"id\":2498,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"66.66666666666674\",\"y2\":\"66.66666666666674\"},\"parentNode\":{\"id\":2486}},{\"nodeType\":1,\"id\":2499,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"0\",\"y2\":\"0\"},\"parentNode\":{\"id\":2487}},{\"nodeType\":1,\"id\":2500,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"0\",\"y1\":\"800\",\"x2\":\"400\",\"y2\":\"0\"},\"parentNode\":{\"id\":2314}},{\"nodeType\":1,\"id\":2501,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"800\",\"y1\":\"800\",\"x2\":\"400\",\"y2\":\"0\"},\"previousSibling\":{\"id\":2500},\"parentNode\":{\"id\":2314}},{\"nodeType\":1,\"id\":2502,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"66.66666666666666\",\"y1\":\"800\",\"x2\":\"433.3333333333333\",\"y2\":\"66.66666666666674\"},\"previousSibling\":{\"id\":2501},\"parentNode\":{\"id\":2314}},{\"nodeType\":1,\"id\":2503,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"733.3333333333333\",\"y1\":\"800\",\"x2\":\"366.66666666666663\",\"y2\":\"66.66666666666674\"},\"previousSibling\":{\"id\":2502},\"parentNode\":{\"id\":2314}},{\"nodeType\":1,\"id\":2504,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"133.33333333333331\",\"y1\":\"800\",\"x2\":\"466.6666666666667\",\"y2\":\"133.33333333333326\"},\"previousSibling\":{\"id\":2503},\"parentNode\":{\"id\":2314}},{\"nodeType\":1,\"id\":2505,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"666.6666666666667\",\"y1\":\"800\",\"x2\":\"333.33333333333337\",\"y2\":\"133.33333333333326\"},\"previousSibling\":{\"id\":2504},\"parentNode\":{\"id\":2314}},{\"nodeType\":1,\"id\":2506,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"200\",\"y1\":\"800\",\"x2\":\"500\",\"y2\":\"200\"},\"previousSibling\":{\"id\":2505},\"parentNode\":{\"id\":2314}},{\"nodeType\":1,\"id\":2507,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"600\",\"y1\":\"800\",\"x2\":\"300\",\"y2\":\"200\"},\"previousSibling\":{\"id\":2506},\"parentNode\":{\"id\":2314}},{\"nodeType\":1,\"id\":2508,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"266.66666666666663\",\"y1\":\"800\",\"x2\":\"533.3333333333333\",\"y2\":\"266.66666666666674\"},\"previousSibling\":{\"id\":2507},\"parentNode\":{\"id\":2314}},{\"nodeType\":1,\"id\":2509,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"533.3333333333333\",\"y1\":\"800\",\"x2\":\"266.66666666666663\",\"y2\":\"266.66666666666674\"},\"previousSibling\":{\"id\":2508},\"parentNode\":{\"id\":2314}},{\"nodeType\":1,\"id\":2510,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"333.33333333333337\",\"y1\":\"800\",\"x2\":\"566.6666666666667\",\"y2\":\"333.3333333333333\"},\"previousSibling\":{\"id\":2509},\"parentNode\":{\"id\":2314}},{\"nodeType\":1,\"id\":2511,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"466.6666666666667\",\"y1\":\"800\",\"x2\":\"233.33333333333334\",\"y2\":\"333.3333333333333\"},\"previousSibling\":{\"id\":2510},\"parentNode\":{\"id\":2314}},{\"nodeType\":1,\"id\":2512,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"400\",\"y1\":\"800\",\"x2\":\"600\",\"y2\":\"400\"},\"previousSibling\":{\"id\":2511},\"parentNode\":{\"id\":2314}},{\"nodeType\":1,\"id\":2513,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"400\",\"y1\":\"800\",\"x2\":\"200\",\"y2\":\"400\"},\"previousSibling\":{\"id\":2512},\"parentNode\":{\"id\":2314}},{\"nodeType\":1,\"id\":2514,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"466.6666666666667\",\"y1\":\"800\",\"x2\":\"633.3333333333333\",\"y2\":\"466.66666666666663\"},\"previousSibling\":{\"id\":2513},\"parentNode\":{\"id\":2314}},{\"nodeType\":1,\"id\":2515,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"333.33333333333337\",\"y1\":\"800\",\"x2\":\"166.66666666666669\",\"y2\":\"466.66666666666663\"},\"previousSibling\":{\"id\":2514},\"parentNode\":{\"id\":2314}},{\"nodeType\":1,\"id\":2516,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"533.3333333333333\",\"y1\":\"800\",\"x2\":\"666.6666666666667\",\"y2\":\"533.3333333333334\"},\"previousSibling\":{\"id\":2515},\"parentNode\":{\"id\":2314}},{\"nodeType\":1,\"id\":2517,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"266.66666666666663\",\"y1\":\"800\",\"x2\":\"133.33333333333331\",\"y2\":\"533.3333333333334\"},\"previousSibling\":{\"id\":2516},\"parentNode\":{\"id\":2314}},{\"nodeType\":1,\"id\":2518,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"600\",\"y1\":\"800\",\"x2\":\"700\",\"y2\":\"600\"},\"previousSibling\":{\"id\":2517},\"parentNode\":{\"id\":2314}},{\"nodeType\":1,\"id\":2519,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"200\",\"y1\":\"800\",\"x2\":\"100\",\"y2\":\"600\"},\"previousSibling\":{\"id\":2518},\"parentNode\":{\"id\":2314}},{\"nodeType\":1,\"id\":2520,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"666.6666666666667\",\"y1\":\"800\",\"x2\":\"733.3333333333333\",\"y2\":\"666.6666666666667\"},\"previousSibling\":{\"id\":2519},\"parentNode\":{\"id\":2314}},{\"nodeType\":1,\"id\":2521,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"133.33333333333331\",\"y1\":\"800\",\"x2\":\"66.66666666666666\",\"y2\":\"666.6666666666667\"},\"previousSibling\":{\"id\":2520},\"parentNode\":{\"id\":2314}},{\"nodeType\":1,\"id\":2522,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"733.3333333333333\",\"y1\":\"800\",\"x2\":\"766.6666666666667\",\"y2\":\"733.3333333333334\"},\"previousSibling\":{\"id\":2521},\"parentNode\":{\"id\":2314}},{\"nodeType\":1,\"id\":2523,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"66.66666666666666\",\"y1\":\"800\",\"x2\":\"33.33333333333333\",\"y2\":\"733.3333333333334\"},\"previousSibling\":{\"id\":2522},\"parentNode\":{\"id\":2314}},{\"nodeType\":1,\"id\":2524,\"tagName\":\"g\",\"attributes\":{},\"parentNode\":{\"id\":2315}},{\"nodeType\":1,\"id\":2525,\"tagName\":\"g\",\"attributes\":{},\"previousSibling\":{\"id\":2524},\"parentNode\":{\"id\":2315}},{\"nodeType\":1,\"id\":2526,\"tagName\":\"g\",\"attributes\":{},\"previousSibling\":{\"id\":2525},\"parentNode\":{\"id\":2315}},{\"nodeType\":1,\"id\":2527,\"tagName\":\"g\",\"attributes\":{},\"previousSibling\":{\"id\":2526},\"parentNode\":{\"id\":2315}},{\"nodeType\":1,\"id\":2528,\"tagName\":\"g\",\"attributes\":{},\"previousSibling\":{\"id\":2527},\"parentNode\":{\"id\":2315}},{\"nodeType\":1,\"id\":2529,\"tagName\":\"g\",\"attributes\":{},\"previousSibling\":{\"id\":2528},\"parentNode\":{\"id\":2315}},{\"nodeType\":1,\"id\":2530,\"tagName\":\"g\",\"attributes\":{},\"previousSibling\":{\"id\":2529},\"parentNode\":{\"id\":2315}},{\"nodeType\":1,\"id\":2531,\"tagName\":\"g\",\"attributes\":{},\"previousSibling\":{\"id\":2530},\"parentNode\":{\"id\":2315}},{\"nodeType\":1,\"id\":2532,\"tagName\":\"g\",\"attributes\":{},\"previousSibling\":{\"id\":2531},\"parentNode\":{\"id\":2315}},{\"nodeType\":1,\"id\":2533,\"tagName\":\"g\",\"attributes\":{},\"previousSibling\":{\"id\":2532},\"parentNode\":{\"id\":2315}},{\"nodeType\":1,\"id\":2534,\"tagName\":\"g\",\"attributes\":{},\"previousSibling\":{\"id\":2533},\"parentNode\":{\"id\":2315}},{\"nodeType\":1,\"id\":2535,\"tagName\":\"g\",\"attributes\":{},\"previousSibling\":{\"id\":2534},\"parentNode\":{\"id\":2315}},{\"nodeType\":1,\"id\":2536,\"tagName\":\"g\",\"attributes\":{},\"previousSibling\":{\"id\":2535},\"parentNode\":{\"id\":2315}},{\"nodeType\":1,\"id\":2537,\"tagName\":\"g\",\"attributes\":{},\"previousSibling\":{\"id\":2536},\"parentNode\":{\"id\":2315}},{\"nodeType\":1,\"id\":2538,\"tagName\":\"g\",\"attributes\":{},\"previousSibling\":{\"id\":2537},\"parentNode\":{\"id\":2315}},{\"nodeType\":1,\"id\":2539,\"tagName\":\"g\",\"attributes\":{},\"previousSibling\":{\"id\":2538},\"parentNode\":{\"id\":2315}},{\"nodeType\":1,\"id\":2540,\"tagName\":\"g\",\"attributes\":{},\"previousSibling\":{\"id\":2539},\"parentNode\":{\"id\":2315}},{\"nodeType\":1,\"id\":2541,\"tagName\":\"g\",\"attributes\":{},\"previousSibling\":{\"id\":2540},\"parentNode\":{\"id\":2315}},{\"nodeType\":1,\"id\":2542,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"333.33333333333337\",\"cy\":\"266.66666666666674\",\"r\":\"6\",\"selected\":\"false\"},\"parentNode\":{\"id\":2524}},{\"nodeType\":1,\"id\":2543,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"328.33333333333337\",\"y\":\"258.66666666666674\"},\"previousSibling\":{\"id\":2542},\"parentNode\":{\"id\":2524}},{\"nodeType\":1,\"id\":2544,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"266.66666666666663\",\"cy\":\"600\",\"r\":\"6\",\"selected\":\"false\"},\"parentNode\":{\"id\":2525}},{\"nodeType\":1,\"id\":2545,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"261.66666666666663\",\"y\":\"592\"},\"previousSibling\":{\"id\":2544},\"parentNode\":{\"id\":2525}},{\"nodeType\":1,\"id\":2546,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"366.66666666666663\",\"cy\":\"466.66666666666663\",\"r\":\"6\",\"selected\":\"false\"},\"parentNode\":{\"id\":2526}},{\"nodeType\":1,\"id\":2547,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"361.66666666666663\",\"y\":\"458.66666666666663\"},\"previousSibling\":{\"id\":2546},\"parentNode\":{\"id\":2526}},{\"nodeType\":1,\"id\":2548,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"666.6666666666667\",\"cy\":\"666.6666666666667\",\"r\":\"6\",\"selected\":\"false\"},\"parentNode\":{\"id\":2527}},{\"nodeType\":1,\"id\":2549,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"661.6666666666667\",\"y\":\"658.6666666666667\"},\"previousSibling\":{\"id\":2548},\"parentNode\":{\"id\":2527}},{\"nodeType\":1,\"id\":2550,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"200\",\"cy\":\"400\",\"r\":\"6\",\"selected\":\"false\"},\"parentNode\":{\"id\":2528}},{\"nodeType\":1,\"id\":2551,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"195\",\"y\":\"392\"},\"previousSibling\":{\"id\":2550},\"parentNode\":{\"id\":2528}},{\"nodeType\":1,\"id\":2552,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"266.66666666666663\",\"cy\":\"533.3333333333334\",\"r\":\"6\",\"selected\":\"false\"},\"parentNode\":{\"id\":2529}},{\"nodeType\":1,\"id\":2553,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"261.66666666666663\",\"y\":\"525.3333333333334\"},\"previousSibling\":{\"id\":2552},\"parentNode\":{\"id\":2529}},{\"nodeType\":1,\"id\":2554,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"333.33333333333337\",\"cy\":\"400\",\"r\":\"6\",\"selected\":\"false\"},\"parentNode\":{\"id\":2530}},{\"nodeType\":1,\"id\":2555,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"328.33333333333337\",\"y\":\"392\"},\"previousSibling\":{\"id\":2554},\"parentNode\":{\"id\":2530}},{\"nodeType\":1,\"id\":2556,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"500\",\"cy\":\"466.66666666666663\",\"r\":\"6\",\"selected\":\"false\"},\"parentNode\":{\"id\":2531}},{\"nodeType\":1,\"id\":2557,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"495\",\"y\":\"458.66666666666663\"},\"previousSibling\":{\"id\":2556},\"parentNode\":{\"id\":2531}},{\"nodeType\":1,\"id\":2558,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"100\",\"cy\":\"600\",\"r\":\"6\",\"selected\":\"false\"},\"parentNode\":{\"id\":2532}},{\"nodeType\":1,\"id\":2559,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"95\",\"y\":\"592\"},\"previousSibling\":{\"id\":2558},\"parentNode\":{\"id\":2532}},{\"nodeType\":1,\"id\":2560,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"133.33333333333331\",\"cy\":\"666.6666666666667\",\"r\":\"6\",\"selected\":\"false\"},\"parentNode\":{\"id\":2533}},{\"nodeType\":1,\"id\":2561,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"128.33333333333331\",\"y\":\"658.6666666666667\"},\"previousSibling\":{\"id\":2560},\"parentNode\":{\"id\":2533}},{\"nodeType\":1,\"id\":2562,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"400\",\"cy\":\"133.33333333333326\",\"r\":\"6\",\"selected\":\"false\"},\"parentNode\":{\"id\":2534}},{\"nodeType\":1,\"id\":2563,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"395\",\"y\":\"125.33333333333326\"},\"previousSibling\":{\"id\":2562},\"parentNode\":{\"id\":2534}},{\"nodeType\":1,\"id\":2564,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"500\",\"cy\":\"333.3333333333333\",\"r\":\"6\",\"selected\":\"false\"},\"parentNode\":{\"id\":2535}},{\"nodeType\":1,\"id\":2565,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"495\",\"y\":\"325.3333333333333\"},\"previousSibling\":{\"id\":2564},\"parentNode\":{\"id\":2535}},{\"nodeType\":1,\"id\":2566,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"300\",\"cy\":\"733.3333333333334\",\"r\":\"6\",\"selected\":\"false\"},\"parentNode\":{\"id\":2536}},{\"nodeType\":1,\"id\":2567,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"295\",\"y\":\"725.3333333333334\"},\"previousSibling\":{\"id\":2566},\"parentNode\":{\"id\":2536}},{\"nodeType\":1,\"id\":2568,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"600\",\"cy\":\"666.6666666666667\",\"r\":\"6\",\"selected\":\"false\"},\"parentNode\":{\"id\":2537}},{\"nodeType\":1,\"id\":2569,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"595\",\"y\":\"658.6666666666667\"},\"previousSibling\":{\"id\":2568},\"parentNode\":{\"id\":2537}},{\"nodeType\":1,\"id\":2570,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"433.3333333333333\",\"cy\":\"600\",\"r\":\"6\",\"selected\":\"false\"},\"parentNode\":{\"id\":2538}},{\"nodeType\":1,\"id\":2571,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"428.3333333333333\",\"y\":\"592\"},\"previousSibling\":{\"id\":2570},\"parentNode\":{\"id\":2538}},{\"nodeType\":1,\"id\":2572,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"500\",\"cy\":\"200\",\"r\":\"6\",\"selected\":\"false\"},\"parentNode\":{\"id\":2539}},{\"nodeType\":1,\"id\":2573,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"495\",\"y\":\"192\"},\"previousSibling\":{\"id\":2572},\"parentNode\":{\"id\":2539}},{\"nodeType\":1,\"id\":2574,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"533.3333333333333\",\"cy\":\"533.3333333333334\",\"r\":\"6\",\"selected\":\"false\"},\"parentNode\":{\"id\":2540}},{\"nodeType\":1,\"id\":2575,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"528.3333333333333\",\"y\":\"525.3333333333334\"},\"previousSibling\":{\"id\":2574},\"parentNode\":{\"id\":2540}},{\"nodeType\":1,\"id\":2576,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"400\",\"cy\":\"666.6666666666667\",\"r\":\"6\",\"selected\":\"false\"},\"parentNode\":{\"id\":2541}},{\"nodeType\":1,\"id\":2577,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"395\",\"y\":\"658.6666666666667\"},\"previousSibling\":{\"id\":2576},\"parentNode\":{\"id\":2541}},{\"nodeType\":3,\"id\":2578,\"textContent\":\"A \",\"parentNode\":{\"id\":2543}},{\"nodeType\":3,\"id\":2579,\"textContent\":\"B \",\"parentNode\":{\"id\":2545}},{\"nodeType\":3,\"id\":2580,\"textContent\":\"C \",\"parentNode\":{\"id\":2547}},{\"nodeType\":3,\"id\":2581,\"textContent\":\"D \",\"parentNode\":{\"id\":2549}},{\"nodeType\":3,\"id\":2582,\"textContent\":\"E \",\"parentNode\":{\"id\":2551}},{\"nodeType\":3,\"id\":2583,\"textContent\":\"F \",\"parentNode\":{\"id\":2553}},{\"nodeType\":3,\"id\":2584,\"textContent\":\"G \",\"parentNode\":{\"id\":2555}},{\"nodeType\":3,\"id\":2585,\"textContent\":\"H \",\"parentNode\":{\"id\":2557}},{\"nodeType\":3,\"id\":2586,\"textContent\":\"I \",\"parentNode\":{\"id\":2559}},{\"nodeType\":3,\"id\":2587,\"textContent\":\"J \",\"parentNode\":{\"id\":2561}},{\"nodeType\":3,\"id\":2588,\"textContent\":\"K \",\"parentNode\":{\"id\":2563}},{\"nodeType\":3,\"id\":2589,\"textContent\":\"L \",\"parentNode\":{\"id\":2565}},{\"nodeType\":3,\"id\":2590,\"textContent\":\"M \",\"parentNode\":{\"id\":2567}},{\"nodeType\":3,\"id\":2591,\"textContent\":\"N \",\"parentNode\":{\"id\":2569}},{\"nodeType\":3,\"id\":2592,\"textContent\":\"O \",\"parentNode\":{\"id\":2571}},{\"nodeType\":3,\"id\":2593,\"textContent\":\"P \",\"parentNode\":{\"id\":2573}},{\"nodeType\":3,\"id\":2594,\"textContent\":\"Z \",\"parentNode\":{\"id\":2575}},{\"nodeType\":3,\"id\":2595,\"textContent\":\"X \",\"parentNode\":{\"id\":2577}}],[],[]]}"
    },
    {
      "sequence": 2,
      "data": "{\"f\":\"applyChanged\",\"args\":[[{\"id\":56},{\"id\":57},{\"id\":58},{\"id\":59},{\"id\":60},{\"id\":61},{\"id\":62},{\"id\":63},{\"id\":64},{\"id\":65},{\"id\":66},{\"id\":67},{\"id\":68},{\"id\":69},{\"id\":70},{\"id\":71},{\"id\":72},{\"id\":73},{\"id\":74},{\"id\":75},{\"id\":76},{\"id\":77},{\"id\":78},{\"id\":79},{\"id\":80},{\"id\":81},{\"id\":82},{\"id\":83},{\"id\":84},{\"id\":85},{\"id\":86},{\"id\":87},{\"id\":88},{\"id\":89},{\"id\":90},{\"id\":91},{\"id\":92},{\"id\":93},{\"id\":94},{\"id\":95},{\"id\":96},{\"id\":97},{\"id\":98},{\"id\":99},{\"id\":100},{\"id\":101},{\"id\":102},{\"id\":103},{\"id\":104},{\"id\":105},{\"id\":106},{\"id\":107},{\"id\":108},{\"id\":109},{\"id\":110},{\"id\":111},{\"id\":112},{\"id\":113},{\"id\":114},{\"id\":115},{\"id\":116},{\"id\":117},{\"id\":118},{\"id\":119},{\"id\":120},{\"id\":121},{\"id\":122},{\"id\":123},{\"id\":124},{\"id\":125},{\"id\":126},{\"id\":127},{\"id\":128},{\"id\":129},{\"id\":130},{\"id\":131},{\"id\":132},{\"id\":133},{\"id\":134},{\"id\":135},{\"id\":136},{\"id\":137},{\"id\":138},{\"id\":139},{\"id\":140},{\"id\":141},{\"id\":142},{\"id\":143},{\"id\":144},{\"id\":145},{\"id\":146},{\"id\":147},{\"id\":148},{\"id\":149},{\"id\":150},{\"id\":151},{\"id\":152},{\"id\":153},{\"id\":154},{\"id\":155},{\"id\":156},{\"id\":157},{\"id\":158},{\"id\":159},{\"id\":160},{\"id\":161},{\"id\":162},{\"id\":163},{\"id\":164},{\"id\":165},{\"id\":166},{\"id\":167},{\"id\":168},{\"id\":169},{\"id\":170},{\"id\":171},{\"id\":172},{\"id\":173},{\"id\":174},{\"id\":175},{\"id\":176},{\"id\":177},{\"id\":178},{\"id\":179},{\"id\":180},{\"id\":181},{\"id\":182},{\"id\":183},{\"id\":184},{\"id\":185},{\"id\":186},{\"id\":187},{\"id\":188},{\"id\":189},{\"id\":190},{\"id\":191},{\"id\":192},{\"id\":193},{\"id\":194},{\"id\":195},{\"id\":196},{\"id\":197},{\"id\":198},{\"id\":199},{\"id\":200},{\"id\":201},{\"id\":202},{\"id\":203},{\"id\":204},{\"id\":205},{\"id\":206},{\"id\":207},{\"id\":208},{\"id\":209},{\"id\":210},{\"id\":211},{\"id\":212},{\"id\":213},{\"id\":214},{\"id\":215},{\"id\":216},{\"id\":217},{\"id\":218},{\"id\":219},{\"id\":220},{\"id\":221},{\"id\":222},{\"id\":223},{\"id\":224},{\"id\":225},{\"id\":226},{\"id\":227},{\"id\":228},{\"id\":229},{\"id\":230},{\"id\":231},{\"id\":232},{\"id\":233},{\"id\":234},{\"id\":235},{\"id\":236},{\"id\":237},{\"id\":238},{\"id\":239},{\"id\":240},{\"id\":241},{\"id\":242},{\"id\":243},{\"id\":244},{\"id\":245},{\"id\":246},{\"id\":247},{\"id\":248},{\"id\":249},{\"id\":250},{\"id\":251},{\"id\":252},{\"id\":253},{\"id\":254},{\"id\":255},{\"id\":256},{\"id\":257},{\"id\":258},{\"id\":259},{\"id\":260},{\"id\":261},{\"id\":262},{\"id\":263},{\"id\":264},{\"id\":265},{\"id\":266},{\"id\":267},{\"id\":268},{\"id\":269},{\"id\":270},{\"id\":271},{\"id\":272},{\"id\":273},{\"id\":274},{\"id\":275},{\"id\":276},{\"id\":277},{\"id\":278},{\"id\":279},{\"id\":280},{\"id\":281},{\"id\":282},{\"id\":283},{\"id\":284},{\"id\":285},{\"id\":286},{\"id\":287},{\"id\":288},{\"id\":289},{\"id\":290},{\"id\":291},{\"id\":292},{\"id\":293},{\"id\":294},{\"id\":295},{\"id\":296},{\"id\":297},{\"id\":298},{\"id\":299},{\"id\":300},{\"id\":301},{\"id\":302},{\"id\":303},{\"id\":304},{\"id\":305},{\"id\":306},{\"id\":307},{\"id\":308},{\"id\":309},{\"id\":310},{\"id\":311},{\"id\":312},{\"id\":313},{\"id\":314},{\"id\":315},{\"id\":316},{\"id\":317},{\"id\":318},{\"id\":319},{\"id\":320},{\"id\":321},{\"id\":322},{\"id\":323},{\"id\":324},{\"id\":325},{\"id\":326},{\"id\":327},{\"id\":328},{\"id\":329},{\"id\":330},{\"id\":331},{\"id\":332},{\"id\":333},{\"id\":334},{\"id\":335},{\"id\":336},{\"id\":337},{\"id\":338},{\"id\":339},{\"id\":340},{\"id\":341},{\"id\":342},{\"id\":343},{\"id\":344},{\"id\":345},{\"id\":346},{\"id\":347},{\"id\":348},{\"id\":349},{\"id\":350},{\"id\":351},{\"id\":352},{\"id\":353},{\"id\":354},{\"id\":355},{\"id\":356},{\"id\":357},{\"id\":358},{\"id\":359},{\"id\":360},{\"id\":361},{\"id\":362},{\"id\":363},{\"id\":364},{\"id\":365},{\"id\":366},{\"id\":367},{\"id\":368},{\"id\":369},{\"id\":370},{\"id\":371},{\"id\":372},{\"id\":373},{\"id\":374},{\"id\":375},{\"id\":376},{\"id\":377},{\"id\":378},{\"id\":379},{\"id\":380},{\"id\":381},{\"id\":382},{\"id\":383},{\"id\":384},{\"id\":385},{\"id\":386},{\"id\":387},{\"id\":388},{\"id\":389},{\"id\":390},{\"id\":391},{\"id\":392},{\"id\":393},{\"id\":394},{\"id\":395},{\"id\":396},{\"id\":397},{\"id\":398},{\"id\":399},{\"id\":400},{\"id\":401},{\"id\":402},{\"id\":403},{\"id\":404},{\"id\":405},{\"id\":406},{\"id\":407},{\"id\":408},{\"id\":409},{\"id\":410},{\"id\":411},{\"id\":412},{\"id\":413},{\"id\":414},{\"id\":415},{\"id\":416},{\"id\":417},{\"id\":418},{\"id\":419},{\"id\":420},{\"id\":421},{\"id\":422},{\"id\":423},{\"id\":424},{\"id\":425},{\"id\":426},{\"id\":427},{\"id\":428},{\"id\":429},{\"id\":430},{\"id\":431},{\"id\":432},{\"id\":433},{\"id\":434},{\"id\":435},{\"id\":436},{\"id\":437},{\"id\":438},{\"id\":439},{\"id\":440},{\"id\":441},{\"id\":442},{\"id\":443},{\"id\":444},{\"id\":445},{\"id\":446},{\"id\":447},{\"id\":448},{\"id\":449},{\"id\":450},{\"id\":451},{\"id\":452},{\"id\":453},{\"id\":454},{\"id\":455},{\"id\":456},{\"id\":457},{\"id\":458},{\"id\":459},{\"id\":460},{\"id\":461},{\"id\":462},{\"id\":463},{\"id\":464},{\"id\":465},{\"id\":466},{\"id\":467},{\"id\":468},{\"id\":469},{\"id\":470},{\"id\":471},{\"id\":472},{\"id\":473},{\"id\":474},{\"id\":475},{\"id\":476},{\"id\":477},{\"id\":478},{\"id\":479},{\"id\":480},{\"id\":481},{\"id\":482},{\"id\":483},{\"id\":484},{\"id\":485},{\"id\":486},{\"id\":487},{\"id\":488},{\"id\":489},{\"id\":490},{\"id\":491},{\"id\":492},{\"id\":493},{\"id\":494},{\"id\":495},{\"id\":496},{\"id\":497},{\"id\":498},{\"id\":499},{\"id\":500},{\"id\":501},{\"id\":502},{\"id\":503},{\"id\":504},{\"id\":505},{\"id\":506},{\"id\":507},{\"id\":508},{\"id\":509},{\"id\":510},{\"id\":511},{\"id\":512},{\"id\":513},{\"id\":514},{\"id\":515},{\"id\":516},{\"id\":517},{\"id\":518},{\"id\":519},{\"id\":520},{\"id\":521},{\"id\":522},{\"id\":523},{\"id\":524},{\"id\":525},{\"id\":526},{\"id\":527},{\"id\":528},{\"id\":529},{\"id\":530},{\"id\":531},{\"id\":532},{\"id\":533},{\"id\":534},{\"id\":535},{\"id\":536},{\"id\":537},{\"id\":538},{\"id\":539},{\"id\":540},{\"id\":541},{\"id\":542},{\"id\":543},{\"id\":544},{\"id\":545},{\"id\":546},{\"id\":547},{\"id\":548},{\"id\":549},{\"id\":550},{\"id\":551},{\"id\":552},{\"id\":553},{\"id\":554},{\"id\":555},{\"id\":556},{\"id\":557},{\"id\":558},{\"id\":559},{\"id\":560},{\"id\":561},{\"id\":562},{\"id\":563},{\"id\":564},{\"id\":565},{\"id\":566},{\"id\":567},{\"id\":568},{\"id\":569},{\"id\":570},{\"id\":571},{\"id\":572},{\"id\":573},{\"id\":574},{\"id\":575},{\"id\":576},{\"id\":577},{\"id\":578},{\"id\":579},{\"id\":580},{\"id\":581},{\"id\":582},{\"id\":583},{\"id\":584},{\"id\":585},{\"id\":586},{\"id\":587},{\"id\":588},{\"id\":589},{\"id\":590},{\"id\":591},{\"id\":592},{\"id\":593},{\"id\":594},{\"id\":595},{\"id\":596},{\"id\":597},{\"id\":598},{\"id\":599},{\"id\":600},{\"id\":601},{\"id\":602},{\"id\":603},{\"id\":604},{\"id\":605},{\"id\":606},{\"id\":607},{\"id\":608},{\"id\":609},{\"id\":610},{\"id\":611},{\"id\":612},{\"id\":613},{\"id\":614},{\"id\":615},{\"id\":616},{\"id\":617},{\"id\":618},{\"id\":619},{\"id\":620},{\"id\":621},{\"id\":622},{\"id\":623},{\"id\":624},{\"id\":625},{\"id\":626},{\"id\":627},{\"id\":628},{\"id\":629},{\"id\":630},{\"id\":631},{\"id\":632},{\"id\":633},{\"id\":634},{\"id\":635},{\"id\":636},{\"id\":637},{\"id\":638},{\"id\":639},{\"id\":640},{\"id\":641},{\"id\":642},{\"id\":643},{\"id\":644},{\"id\":645},{\"id\":646},{\"id\":647},{\"id\":648},{\"id\":649},{\"id\":650},{\"id\":651},{\"id\":652},{\"id\":653},{\"id\":654},{\"id\":655},{\"id\":656},{\"id\":657},{\"id\":658},{\"id\":659},{\"id\":660},{\"id\":661},{\"id\":662},{\"id\":663},{\"id\":664},{\"id\":665},{\"id\":666},{\"id\":667},{\"id\":668},{\"id\":669},{\"id\":670},{\"id\":671},{\"id\":672},{\"id\":673},{\"id\":674},{\"id\":675},{\"id\":676},{\"id\":677},{\"id\":678},{\"id\":679},{\"id\":680},{\"id\":681},{\"id\":682},{\"id\":683},{\"id\":684},{\"id\":685},{\"id\":686},{\"id\":687},{\"id\":688},{\"id\":689},{\"id\":690},{\"id\":691},{\"id\":692},{\"id\":693},{\"id\":694},{\"id\":695},{\"id\":696},{\"id\":697},{\"id\":698},{\"id\":699},{\"id\":700},{\"id\":701},{\"id\":702},{\"id\":703},{\"id\":704},{\"id\":705},{\"id\":706},{\"id\":707},{\"id\":708},{\"id\":709},{\"id\":710},{\"id\":711},{\"id\":712},{\"id\":713},{\"id\":714},{\"id\":715},{\"id\":716},{\"id\":717},{\"id\":718},{\"id\":719},{\"id\":720},{\"id\":721},{\"id\":722},{\"id\":723},{\"id\":724},{\"id\":725},{\"id\":726},{\"id\":727},{\"id\":728},{\"id\":729},{\"id\":730},{\"id\":731},{\"id\":732},{\"id\":733},{\"id\":734},{\"id\":735},{\"id\":736},{\"id\":737},{\"id\":738},{\"id\":739},{\"id\":740},{\"id\":741},{\"id\":742},{\"id\":743},{\"id\":744},{\"id\":745},{\"id\":746},{\"id\":747},{\"id\":748},{\"id\":749},{\"id\":750},{\"id\":751},{\"id\":752},{\"id\":753},{\"id\":754},{\"id\":755},{\"id\":756},{\"id\":757},{\"id\":758},{\"id\":759},{\"id\":760},{\"id\":761},{\"id\":762},{\"id\":763},{\"id\":764},{\"id\":765},{\"id\":766},{\"id\":767},{\"id\":768},{\"id\":769},{\"id\":770},{\"id\":771},{\"id\":772},{\"id\":773},{\"id\":774},{\"id\":775},{\"id\":776},{\"id\":777},{\"id\":778},{\"id\":779},{\"id\":780},{\"id\":781},{\"id\":782},{\"id\":783},{\"id\":784},{\"id\":785},{\"id\":786},{\"id\":787},{\"id\":788},{\"id\":789},{\"id\":790},{\"id\":791},{\"id\":792},{\"id\":793},{\"id\":794},{\"id\":795},{\"id\":796},{\"id\":797},{\"id\":798},{\"id\":799},{\"id\":800},{\"id\":801},{\"id\":802},{\"id\":803},{\"id\":804},{\"id\":805},{\"id\":806},{\"id\":807},{\"id\":808},{\"id\":809},{\"id\":810},{\"id\":811},{\"id\":812},{\"id\":813},{\"id\":814},{\"id\":815},{\"id\":816},{\"id\":817},{\"id\":818},{\"id\":819},{\"id\":820},{\"id\":821},{\"id\":822},{\"id\":823},{\"id\":824},{\"id\":825},{\"id\":826},{\"id\":827},{\"id\":828},{\"id\":829},{\"id\":830},{\"id\":831},{\"id\":832},{\"id\":833},{\"id\":834},{\"id\":835},{\"id\":836},{\"id\":837},{\"id\":838},{\"id\":839},{\"id\":840},{\"id\":841},{\"id\":842},{\"id\":843},{\"id\":844},{\"id\":845},{\"id\":846},{\"id\":847},{\"id\":848},{\"id\":849},{\"id\":850},{\"id\":851},{\"id\":852},{\"id\":853},{\"id\":854},{\"id\":855},{\"id\":856},{\"id\":857},{\"id\":858},{\"id\":859},{\"id\":860},{\"id\":861},{\"id\":862},{\"id\":863},{\"id\":864},{\"id\":865},{\"id\":866},{\"id\":867},{\"id\":868},{\"id\":869},{\"id\":870},{\"id\":871},{\"id\":872},{\"id\":873},{\"id\":874},{\"id\":875},{\"id\":876},{\"id\":877},{\"id\":878},{\"id\":879},{\"id\":880},{\"id\":881},{\"id\":882},{\"id\":883},{\"id\":884},{\"id\":885},{\"id\":886},{\"id\":887},{\"id\":888},{\"id\":889},{\"id\":890},{\"id\":891},{\"id\":892},{\"id\":893},{\"id\":894},{\"id\":895},{\"id\":896},{\"id\":897},{\"id\":898},{\"id\":899},{\"id\":900},{\"id\":901},{\"id\":902},{\"id\":903},{\"id\":904},{\"id\":905},{\"id\":906},{\"id\":907},{\"id\":908},{\"id\":909},{\"id\":910},{\"id\":911},{\"id\":912},{\"id\":913},{\"id\":914},{\"id\":915},{\"id\":916},{\"id\":917},{\"id\":918},{\"id\":919},{\"id\":920},{\"id\":921},{\"id\":922},{\"id\":923},{\"id\":924},{\"id\":925},{\"id\":926},{\"id\":927},{\"id\":928},{\"id\":929},{\"id\":930},{\"id\":931},{\"id\":932},{\"id\":933},{\"id\":934},{\"id\":935},{\"id\":936},{\"id\":937},{\"id\":938},{\"id\":939},{\"id\":940},{\"id\":941},{\"id\":942},{\"id\":943},{\"id\":944},{\"id\":945},{\"id\":946},{\"id\":947},{\"id\":948},{\"id\":949},{\"id\":950},{\"id\":951},{\"id\":952},{\"id\":953},{\"id\":954},{\"id\":955},{\"id\":956},{\"id\":957},{\"id\":958},{\"id\":959},{\"id\":960},{\"id\":961},{\"id\":962},{\"id\":963},{\"id\":964},{\"id\":965},{\"id\":966},{\"id\":967},{\"id\":968},{\"id\":969},{\"id\":970},{\"id\":971},{\"id\":972},{\"id\":973},{\"id\":974},{\"id\":975},{\"id\":976},{\"id\":977},{\"id\":978},{\"id\":979},{\"id\":980},{\"id\":981},{\"id\":982},{\"id\":983},{\"id\":984},{\"id\":985},{\"id\":986},{\"id\":987},{\"id\":988},{\"id\":989},{\"id\":990},{\"id\":991},{\"id\":992},{\"id\":993},{\"id\":994},{\"id\":995},{\"id\":996},{\"id\":997},{\"id\":998},{\"id\":999},{\"id\":1000},{\"id\":1001},{\"id\":1002},{\"id\":1003},{\"id\":1004},{\"id\":1005},{\"id\":1006},{\"id\":1007},{\"id\":1008},{\"id\":1009},{\"id\":1010},{\"id\":1011},{\"id\":1012},{\"id\":1013},{\"id\":1014},{\"id\":1015},{\"id\":1016},{\"id\":1017},{\"id\":1018},{\"id\":1019},{\"id\":1020},{\"id\":1021},{\"id\":1022},{\"id\":1023},{\"id\":1024},{\"id\":1025},{\"id\":1026},{\"id\":1027},{\"id\":1028},{\"id\":1029},{\"id\":1030},{\"id\":1031},{\"id\":1032},{\"id\":1033},{\"id\":1034},{\"id\":1035},{\"id\":1036},{\"id\":1037},{\"id\":1038},{\"id\":1039},{\"id\":1040},{\"id\":1041},{\"id\":1042},{\"id\":1043},{\"id\":1044},{\"id\":1045},{\"id\":1046},{\"id\":1047},{\"id\":1048},{\"id\":1049},{\"id\":1050},{\"id\":1051},{\"id\":1052},{\"id\":1053},{\"id\":1054},{\"id\":1055},{\"id\":1056},{\"id\":1057},{\"id\":1058},{\"id\":1059},{\"id\":1060},{\"id\":1061},{\"id\":1062},{\"id\":1063},{\"id\":1064},{\"id\":1065},{\"id\":1066},{\"id\":1067},{\"id\":1068},{\"id\":1069},{\"id\":1070},{\"id\":1071},{\"id\":1072},{\"id\":1073},{\"id\":1074},{\"id\":1075},{\"id\":1076},{\"id\":1077},{\"id\":1078},{\"id\":1079},{\"id\":1080},{\"id\":1081},{\"id\":1082},{\"id\":1083},{\"id\":1084},{\"id\":1085},{\"id\":1086},{\"id\":1087},{\"id\":1088},{\"id\":1089},{\"id\":1090},{\"id\":1091},{\"id\":1092},{\"id\":1093},{\"id\":1094},{\"id\":1095},{\"id\":1096},{\"id\":1097},{\"id\":1098},{\"id\":1099},{\"id\":1100},{\"id\":1101},{\"id\":1102},{\"id\":1103},{\"id\":1104},{\"id\":1105},{\"id\":1106},{\"id\":1107},{\"id\":1108},{\"id\":1109},{\"id\":1110},{\"id\":1111},{\"id\":1112},{\"id\":1113},{\"id\":1114},{\"id\":1115},{\"id\":1116},{\"id\":1117},{\"id\":1118},{\"id\":1119},{\"id\":1120},{\"id\":1121},{\"id\":1122},{\"id\":1123},{\"id\":1124},{\"id\":1125},{\"id\":1126},{\"id\":1127},{\"id\":1128},{\"id\":1129},{\"id\":1130},{\"id\":1131},{\"id\":1132},{\"id\":1133},{\"id\":1134},{\"id\":1135},{\"id\":1136},{\"id\":1137},{\"id\":1138},{\"id\":1139},{\"id\":1140},{\"id\":1141},{\"id\":1142},{\"id\":1143},{\"id\":1144},{\"id\":1145},{\"id\":1146},{\"id\":1147},{\"id\":1148},{\"id\":1149},{\"id\":1150},{\"id\":1151},{\"id\":1152},{\"id\":1153},{\"id\":1154},{\"id\":1155},{\"id\":1156},{\"id\":1157},{\"id\":1158},{\"id\":1159},{\"id\":1160},{\"id\":1161},{\"id\":1162},{\"id\":1163},{\"id\":1164},{\"id\":1165},{\"id\":1166},{\"id\":1167},{\"id\":1168},{\"id\":1169},{\"id\":1170},{\"id\":1171},{\"id\":1172},{\"id\":1173},{\"id\":1174},{\"id\":1175},{\"id\":1176},{\"id\":1177},{\"id\":1178},{\"id\":1179},{\"id\":1180},{\"id\":1181},{\"id\":1182},{\"id\":1183},{\"id\":1184},{\"id\":1185},{\"id\":1186},{\"id\":1187},{\"id\":1188},{\"id\":1189},{\"id\":1190},{\"id\":1191},{\"id\":1192},{\"id\":1193},{\"id\":1194},{\"id\":1195},{\"id\":1196},{\"id\":1197},{\"id\":1198},{\"id\":1199},{\"id\":1200},{\"id\":1201},{\"id\":1202},{\"id\":1203},{\"id\":1204},{\"id\":1205},{\"id\":1206},{\"id\":1207},{\"id\":1208},{\"id\":1209},{\"id\":1210},{\"id\":1211},{\"id\":1212},{\"id\":1213},{\"id\":1214},{\"id\":1215},{\"id\":1216},{\"id\":1217},{\"id\":1218},{\"id\":1219},{\"id\":1220},{\"id\":1221},{\"id\":1222},{\"id\":1223},{\"id\":1224},{\"id\":1225},{\"id\":1226},{\"id\":1227},{\"id\":1228},{\"id\":1229},{\"id\":1230},{\"id\":1231},{\"id\":1232},{\"id\":1233},{\"id\":1234},{\"id\":1235},{\"id\":1236},{\"id\":1237},{\"id\":1238},{\"id\":1239},{\"id\":1240},{\"id\":1241},{\"id\":1242},{\"id\":1243},{\"id\":1244},{\"id\":1245},{\"id\":1246},{\"id\":1247},{\"id\":1248},{\"id\":1249},{\"id\":1250},{\"id\":1251},{\"id\":1252},{\"id\":1253},{\"id\":1254},{\"id\":1255},{\"id\":1256},{\"id\":1257},{\"id\":1258},{\"id\":1259},{\"id\":1260},{\"id\":1261},{\"id\":1262},{\"id\":1263},{\"id\":1264},{\"id\":1265},{\"id\":1266},{\"id\":1267},{\"id\":1268},{\"id\":1269},{\"id\":1270},{\"id\":1271},{\"id\":1272},{\"id\":1273},{\"id\":1274},{\"id\":1275},{\"id\":1276},{\"id\":1277},{\"id\":1278},{\"id\":1279},{\"id\":1280},{\"id\":1281},{\"id\":1282},{\"id\":1283},{\"id\":1284},{\"id\":1285},{\"id\":1286},{\"id\":1287},{\"id\":1288},{\"id\":1289},{\"id\":1290},{\"id\":1291},{\"id\":1292},{\"id\":1293},{\"id\":1294},{\"id\":1295},{\"id\":1296},{\"id\":1297},{\"id\":1298},{\"id\":1299},{\"id\":1300},{\"id\":1301},{\"id\":1302},{\"id\":1303},{\"id\":1304},{\"id\":1305},{\"id\":1306},{\"id\":1307},{\"id\":1308},{\"id\":1309},{\"id\":1310},{\"id\":1311},{\"id\":1312},{\"id\":1313},{\"id\":1314},{\"id\":1315},{\"id\":1316},{\"id\":1317},{\"id\":1318},{\"id\":1319},{\"id\":1320},{\"id\":1321},{\"id\":1322},{\"id\":1323},{\"id\":1324},{\"id\":1325},{\"id\":1326},{\"id\":1327},{\"id\":1328},{\"id\":1329},{\"id\":1330},{\"id\":1331},{\"id\":1332},{\"id\":1333},{\"id\":1334},{\"id\":1335},{\"id\":1336},{\"id\":1337},{\"id\":1338},{\"id\":1339},{\"id\":1340},{\"id\":1341},{\"id\":1342},{\"id\":1343},{\"id\":1344},{\"id\":1345},{\"id\":1346},{\"id\":1347},{\"id\":1348},{\"id\":1349},{\"id\":1350},{\"id\":1351},{\"id\":1352},{\"id\":1353},{\"id\":1354},{\"id\":1355},{\"id\":1356},{\"id\":1357},{\"id\":1358},{\"id\":1359},{\"id\":1360},{\"id\":1361},{\"id\":1362},{\"id\":1363},{\"id\":1364},{\"id\":1365},{\"id\":1366},{\"id\":1367},{\"id\":1368},{\"id\":1369},{\"id\":1370},{\"id\":1371},{\"id\":1372},{\"id\":1373},{\"id\":1374},{\"id\":1375},{\"id\":1376},{\"id\":1377},{\"id\":1378},{\"id\":1379},{\"id\":1380},{\"id\":1381},{\"id\":1382},{\"id\":1383},{\"id\":1384},{\"id\":1385},{\"id\":1386},{\"id\":1387},{\"id\":1388},{\"id\":1389},{\"id\":1390},{\"id\":1391},{\"id\":1392},{\"id\":1393},{\"id\":1394},{\"id\":1395},{\"id\":1396},{\"id\":1397},{\"id\":1398},{\"id\":1399},{\"id\":1400},{\"id\":1401},{\"id\":1402},{\"id\":1403},{\"id\":1404},{\"id\":1405},{\"id\":1406},{\"id\":1407},{\"id\":1408},{\"id\":1409},{\"id\":1410},{\"id\":1411},{\"id\":1412},{\"id\":1413},{\"id\":1414},{\"id\":1415},{\"id\":1416},{\"id\":1417},{\"id\":1418},{\"id\":1419},{\"id\":1420},{\"id\":1421},{\"id\":1422},{\"id\":1423},{\"id\":1424},{\"id\":1425},{\"id\":1426},{\"id\":1427},{\"id\":1428},{\"id\":1429},{\"id\":1430},{\"id\":1431},{\"id\":1432},{\"id\":1433},{\"id\":1434},{\"id\":1435},{\"id\":1436},{\"id\":1437},{\"id\":1438},{\"id\":1439},{\"id\":1440},{\"id\":1441},{\"id\":1442},{\"id\":1443},{\"id\":1444},{\"id\":1445},{\"id\":1446},{\"id\":1447},{\"id\":1448},{\"id\":1449},{\"id\":1450},{\"id\":1451},{\"id\":1452},{\"id\":1453},{\"id\":1454},{\"id\":1455},{\"id\":1456},{\"id\":1457},{\"id\":1458},{\"id\":1459},{\"id\":1460},{\"id\":1461},{\"id\":1462},{\"id\":1463},{\"id\":1464},{\"id\":1465},{\"id\":1466},{\"id\":1467},{\"id\":1468},{\"id\":1469},{\"id\":1470},{\"id\":1471},{\"id\":1472},{\"id\":1473},{\"id\":1474},{\"id\":1475},{\"id\":1476},{\"id\":1477},{\"id\":1478},{\"id\":1479},{\"id\":1480},{\"id\":1481},{\"id\":1482},{\"id\":1483},{\"id\":1484},{\"id\":1485},{\"id\":1486},{\"id\":1487},{\"id\":1488},{\"id\":1489},{\"id\":1490},{\"id\":1491},{\"id\":1492},{\"id\":1493},{\"id\":1494},{\"id\":1495},{\"id\":1496},{\"id\":1497},{\"id\":1498},{\"id\":1499},{\"id\":1500},{\"id\":1501},{\"id\":1502},{\"id\":1503},{\"id\":1504},{\"id\":1505},{\"id\":1506},{\"id\":1507},{\"id\":1508},{\"id\":1509},{\"id\":1510},{\"id\":1511},{\"id\":1512},{\"id\":1513},{\"id\":1514},{\"id\":1515},{\"id\":1516},{\"id\":1517},{\"id\":1518},{\"id\":1519},{\"id\":1520},{\"id\":1521},{\"id\":1522},{\"id\":1523},{\"id\":1524},{\"id\":1525},{\"id\":1526},{\"id\":1527},{\"id\":1528},{\"id\":1529},{\"id\":1530},{\"id\":1531},{\"id\":1532},{\"id\":1533},{\"id\":1534},{\"id\":1535},{\"id\":1536},{\"id\":1537},{\"id\":1538},{\"id\":1539},{\"id\":1540},{\"id\":1541},{\"id\":1542},{\"id\":1543},{\"id\":1544},{\"id\":1545},{\"id\":1546},{\"id\":1547},{\"id\":1548},{\"id\":1549},{\"id\":1550},{\"id\":1551},{\"id\":1552},{\"id\":1553},{\"id\":1554},{\"id\":1555},{\"id\":1556},{\"id\":1557},{\"id\":1558},{\"id\":1559},{\"id\":1560},{\"id\":1561},{\"id\":1562},{\"id\":1563},{\"id\":1564},{\"id\":1565},{\"id\":1566},{\"id\":1567},{\"id\":1568},{\"id\":1569},{\"id\":1570},{\"id\":1571},{\"id\":1572},{\"id\":1573},{\"id\":1574},{\"id\":1575},{\"id\":1576},{\"id\":1577},{\"id\":1578},{\"id\":1579},{\"id\":1580},{\"id\":1581},{\"id\":1582},{\"id\":1583},{\"id\":1584},{\"id\":1585},{\"id\":1586},{\"id\":1587},{\"id\":1588},{\"id\":1589},{\"id\":1590},{\"id\":1591},{\"id\":1592},{\"id\":1593},{\"id\":1594},{\"id\":1595},{\"id\":1596},{\"id\":1597},{\"id\":1598},{\"id\":1599},{\"id\":1600},{\"id\":1601},{\"id\":1602},{\"id\":1603},{\"id\":1604},{\"id\":1605},{\"id\":1606},{\"id\":1607},{\"id\":1608},{\"id\":1609},{\"id\":1610},{\"id\":1611},{\"id\":1612},{\"id\":1613},{\"id\":1614},{\"id\":1615},{\"id\":1616},{\"id\":1617},{\"id\":1618},{\"id\":1619},{\"id\":1620},{\"id\":1621},{\"id\":1622},{\"id\":1623},{\"id\":1624},{\"id\":1625},{\"id\":1626},{\"id\":1627},{\"id\":1628},{\"id\":1629},{\"id\":1630},{\"id\":1631},{\"id\":1632},{\"id\":1633},{\"id\":1634},{\"id\":1635},{\"id\":1636},{\"id\":1637},{\"id\":1638},{\"id\":1639},{\"id\":1640},{\"id\":1641},{\"id\":1642},{\"id\":1643},{\"id\":1644},{\"id\":1645},{\"id\":1646},{\"id\":1647},{\"id\":1648},{\"id\":1649},{\"id\":1650},{\"id\":1651},{\"id\":1652},{\"id\":1653},{\"id\":1654},{\"id\":1655},{\"id\":1656},{\"id\":1657},{\"id\":1658},{\"id\":1659},{\"id\":1660},{\"id\":1661},{\"id\":1662},{\"id\":1663},{\"id\":1664},{\"id\":1665},{\"id\":1666},{\"id\":1667},{\"id\":1668},{\"id\":1669},{\"id\":1670},{\"id\":1671},{\"id\":1672},{\"id\":1673},{\"id\":1674},{\"id\":1675},{\"id\":1676},{\"id\":1677},{\"id\":1678},{\"id\":1679},{\"id\":1680},{\"id\":1681},{\"id\":1682},{\"id\":1683},{\"id\":1684},{\"id\":1685},{\"id\":1686},{\"id\":1687},{\"id\":1688},{\"id\":1689},{\"id\":1690},{\"id\":1691},{\"id\":1692},{\"id\":1693},{\"id\":1694},{\"id\":1695},{\"id\":1696},{\"id\":1697},{\"id\":1698},{\"id\":1699},{\"id\":1700},{\"id\":1701},{\"id\":1702},{\"id\":1703},{\"id\":1704},{\"id\":1705},{\"id\":1706},{\"id\":1707},{\"id\":1708},{\"id\":1709},{\"id\":1710},{\"id\":1711},{\"id\":1712},{\"id\":1713},{\"id\":1714},{\"id\":1715},{\"id\":1716},{\"id\":1717},{\"id\":1718},{\"id\":1719},{\"id\":1720},{\"id\":1721},{\"id\":1722},{\"id\":1723},{\"id\":1724},{\"id\":1725},{\"id\":1726},{\"id\":1727},{\"id\":1728},{\"id\":1729},{\"id\":1730},{\"id\":1731},{\"id\":1732},{\"id\":1733},{\"id\":1734},{\"id\":1735},{\"id\":1736},{\"id\":1737},{\"id\":1738},{\"id\":1739},{\"id\":1740},{\"id\":1741},{\"id\":1742},{\"id\":1743},{\"id\":1744},{\"id\":1745},{\"id\":1746},{\"id\":1747},{\"id\":1748},{\"id\":1749},{\"id\":1750},{\"id\":1751},{\"id\":1752},{\"id\":1753},{\"id\":1754},{\"id\":1755},{\"id\":1756},{\"id\":1757},{\"id\":1758},{\"id\":1759},{\"id\":1760},{\"id\":1761},{\"id\":1762},{\"id\":1763},{\"id\":1764},{\"id\":1765},{\"id\":1766},{\"id\":1767},{\"id\":1768},{\"id\":1769},{\"id\":1770},{\"id\":1771},{\"id\":1772},{\"id\":1773},{\"id\":1774},{\"id\":1775},{\"id\":1776},{\"id\":1777},{\"id\":1778},{\"id\":1779},{\"id\":1780},{\"id\":1781},{\"id\":1782},{\"id\":1783},{\"id\":1784},{\"id\":1785},{\"id\":1786},{\"id\":1787},{\"id\":1788},{\"id\":1789},{\"id\":1790},{\"id\":1791},{\"id\":1792},{\"id\":1793},{\"id\":1794},{\"id\":1795},{\"id\":1796},{\"id\":1797},{\"id\":1798},{\"id\":1799},{\"id\":1800},{\"id\":1801},{\"id\":1802},{\"id\":1803},{\"id\":1804},{\"id\":1805},{\"id\":1806},{\"id\":1807},{\"id\":1808},{\"id\":1809},{\"id\":1810},{\"id\":1811},{\"id\":1812},{\"id\":1813},{\"id\":1814},{\"id\":1815},{\"id\":1816},{\"id\":1817},{\"id\":1818},{\"id\":1819},{\"id\":1820},{\"id\":1821},{\"id\":1822},{\"id\":1823},{\"id\":1824},{\"id\":1825},{\"id\":1826},{\"id\":1827},{\"id\":1828},{\"id\":1829},{\"id\":1830},{\"id\":1831},{\"id\":1832},{\"id\":1833},{\"id\":1834},{\"id\":1835},{\"id\":1836},{\"id\":1837},{\"id\":1838},{\"id\":1839},{\"id\":1840},{\"id\":1841},{\"id\":1842},{\"id\":1843},{\"id\":1844},{\"id\":1845},{\"id\":1846},{\"id\":1847},{\"id\":1848},{\"id\":1849},{\"id\":1850},{\"id\":1851},{\"id\":1852},{\"id\":1853},{\"id\":1854},{\"id\":1855},{\"id\":1856},{\"id\":1857},{\"id\":1858},{\"id\":1859},{\"id\":1860},{\"id\":1861},{\"id\":1862},{\"id\":1863},{\"id\":1864},{\"id\":1865},{\"id\":1866},{\"id\":1867},{\"id\":1868},{\"id\":1869},{\"id\":1870},{\"id\":1871},{\"id\":1872},{\"id\":1873},{\"id\":1874},{\"id\":1875},{\"id\":1876},{\"id\":1877},{\"id\":1878},{\"id\":1879},{\"id\":1880},{\"id\":1881},{\"id\":1882},{\"id\":1883},{\"id\":1884},{\"id\":1885},{\"id\":1886},{\"id\":1887},{\"id\":1888},{\"id\":1889},{\"id\":1890},{\"id\":1891},{\"id\":1892},{\"id\":1893},{\"id\":1894},{\"id\":1895},{\"id\":1896},{\"id\":1897},{\"id\":1898},{\"id\":1899},{\"id\":1900},{\"id\":1901},{\"id\":1902},{\"id\":1903},{\"id\":1904},{\"id\":1905},{\"id\":1906},{\"id\":1907},{\"id\":1908},{\"id\":1909},{\"id\":1910},{\"id\":1911},{\"id\":1912},{\"id\":1913},{\"id\":1914},{\"id\":1915},{\"id\":1916},{\"id\":1917},{\"id\":1918},{\"id\":1919},{\"id\":1920},{\"id\":1921},{\"id\":1922},{\"id\":1923},{\"id\":1924},{\"id\":1925},{\"id\":1926},{\"id\":1927},{\"id\":1928},{\"id\":1929},{\"id\":1930},{\"id\":1931},{\"id\":1932},{\"id\":1933},{\"id\":1934},{\"id\":1935},{\"id\":1936},{\"id\":1937},{\"id\":1938},{\"id\":1939},{\"id\":1940},{\"id\":1941},{\"id\":1942},{\"id\":1943},{\"id\":1944},{\"id\":1945},{\"id\":1946},{\"id\":1947},{\"id\":1948},{\"id\":1949},{\"id\":1950},{\"id\":1951},{\"id\":1952},{\"id\":1953},{\"id\":1954},{\"id\":1955},{\"id\":1956},{\"id\":1957},{\"id\":1958},{\"id\":1959},{\"id\":1960},{\"id\":1961},{\"id\":1962},{\"id\":1963},{\"id\":1964},{\"id\":1965},{\"id\":1966},{\"id\":1967},{\"id\":1968},{\"id\":1969},{\"id\":1970},{\"id\":1971},{\"id\":1972},{\"id\":1973},{\"id\":1974},{\"id\":1975},{\"id\":1976},{\"id\":1977},{\"id\":1978},{\"id\":1979},{\"id\":1980},{\"id\":1981},{\"id\":1982},{\"id\":1983},{\"id\":1984},{\"id\":1985},{\"id\":1986},{\"id\":1987},{\"id\":1988},{\"id\":1989},{\"id\":1990},{\"id\":1991},{\"id\":1992},{\"id\":1993},{\"id\":1994},{\"id\":1995},{\"id\":1996},{\"id\":1997},{\"id\":1998},{\"id\":1999},{\"id\":2000},{\"id\":2001},{\"id\":2002},{\"id\":2003},{\"id\":2004},{\"id\":2005},{\"id\":2006},{\"id\":2007},{\"id\":2008},{\"id\":2009},{\"id\":2010},{\"id\":2011},{\"id\":2012},{\"id\":2013},{\"id\":2014},{\"id\":2015},{\"id\":2016},{\"id\":2017},{\"id\":2018},{\"id\":2019},{\"id\":2020},{\"id\":2021},{\"id\":2022},{\"id\":2023},{\"id\":2024},{\"id\":2025},{\"id\":2026},{\"id\":2027},{\"id\":2028},{\"id\":2029},{\"id\":2030},{\"id\":2031},{\"id\":2032},{\"id\":2033},{\"id\":2034},{\"id\":2035},{\"id\":2036},{\"id\":2037},{\"id\":2038},{\"id\":2039},{\"id\":2040},{\"id\":2041},{\"id\":2042},{\"id\":2043},{\"id\":2044},{\"id\":2045},{\"id\":2046},{\"id\":2047},{\"id\":2048},{\"id\":2049},{\"id\":2050},{\"id\":2051},{\"id\":2052},{\"id\":2053},{\"id\":2054},{\"id\":2055},{\"id\":2056},{\"id\":2057},{\"id\":2058},{\"id\":2059},{\"id\":2060},{\"id\":2061},{\"id\":2062},{\"id\":2063},{\"id\":2064},{\"id\":2065},{\"id\":2066},{\"id\":2067},{\"id\":2068},{\"id\":2069},{\"id\":2070},{\"id\":2071},{\"id\":2072},{\"id\":2073},{\"id\":2074},{\"id\":2075},{\"id\":2076},{\"id\":2077},{\"id\":2078},{\"id\":2079},{\"id\":2080},{\"id\":2081},{\"id\":2082},{\"id\":2083},{\"id\":2084},{\"id\":2085},{\"id\":2086},{\"id\":2087},{\"id\":2088},{\"id\":2089},{\"id\":2090},{\"id\":2091},{\"id\":2092},{\"id\":2093},{\"id\":2094},{\"id\":2095},{\"id\":2096},{\"id\":2097},{\"id\":2098},{\"id\":2099},{\"id\":2100},{\"id\":2101},{\"id\":2102},{\"id\":2103},{\"id\":2104},{\"id\":2105},{\"id\":2106},{\"id\":2107},{\"id\":2108},{\"id\":2109},{\"id\":2110},{\"id\":2111},{\"id\":2112},{\"id\":2113},{\"id\":2114},{\"id\":2115},{\"id\":2116},{\"id\":2117},{\"id\":2118},{\"id\":2119},{\"id\":2120},{\"id\":2121},{\"id\":2122},{\"id\":2123},{\"id\":2124},{\"id\":2125},{\"id\":2126},{\"id\":2127},{\"id\":2128},{\"id\":2129},{\"id\":2130},{\"id\":2131},{\"id\":2132},{\"id\":2133},{\"id\":2134},{\"id\":2135},{\"id\":2136},{\"id\":2137},{\"id\":2138},{\"id\":2139},{\"id\":2140},{\"id\":2141},{\"id\":2142},{\"id\":2143},{\"id\":2144},{\"id\":2145},{\"id\":2146},{\"id\":2147},{\"id\":2148},{\"id\":2149},{\"id\":2150},{\"id\":2151},{\"id\":2152},{\"id\":2153},{\"id\":2154},{\"id\":2155},{\"id\":2156},{\"id\":2157},{\"id\":2158},{\"id\":2159},{\"id\":2160},{\"id\":2161},{\"id\":2162},{\"id\":2163},{\"id\":2164},{\"id\":2165},{\"id\":2166},{\"id\":2167},{\"id\":2168},{\"id\":2169},{\"id\":2170},{\"id\":2171},{\"id\":2172},{\"id\":2173},{\"id\":2174},{\"id\":2175},{\"id\":2176},{\"id\":2177},{\"id\":2178},{\"id\":2179},{\"id\":2180},{\"id\":2181},{\"id\":2182},{\"id\":2183},{\"id\":2184},{\"id\":2185},{\"id\":2186},{\"id\":2187},{\"id\":2188},{\"id\":2189},{\"id\":2190},{\"id\":2191},{\"id\":2192},{\"id\":2193},{\"id\":2194},{\"id\":2195},{\"id\":2196},{\"id\":2197},{\"id\":2198},{\"id\":2199},{\"id\":2200},{\"id\":2201},{\"id\":2202},{\"id\":2203},{\"id\":2204},{\"id\":2205},{\"id\":2206},{\"id\":2207},{\"id\":2208},{\"id\":2209},{\"id\":2210},{\"id\":2211},{\"id\":2212},{\"id\":2213},{\"id\":2214},{\"id\":2215},{\"id\":2216},{\"id\":2217},{\"id\":2218},{\"id\":2219},{\"id\":2220},{\"id\":2221},{\"id\":2222},{\"id\":2223},{\"id\":2224},{\"id\":2225},{\"id\":2226},{\"id\":2227},{\"id\":2228},{\"id\":2229},{\"id\":2230},{\"id\":2231},{\"id\":2232},{\"id\":2233},{\"id\":2234},{\"id\":2235},{\"id\":2236},{\"id\":2237},{\"id\":2238},{\"id\":2239},{\"id\":2240},{\"id\":2241},{\"id\":2242},{\"id\":2243},{\"id\":2244},{\"id\":2245},{\"id\":2246},{\"id\":2247},{\"id\":2248},{\"id\":2249},{\"id\":2250},{\"id\":2251},{\"id\":2252},{\"id\":2253},{\"id\":2254},{\"id\":2255},{\"id\":2256},{\"id\":2257},{\"id\":2258},{\"id\":2259},{\"id\":2260},{\"id\":2261},{\"id\":2262},{\"id\":2263},{\"id\":2264},{\"id\":2265},{\"id\":2266},{\"id\":2267},{\"id\":2268},{\"id\":2269},{\"id\":2270},{\"id\":2271},{\"id\":2272},{\"id\":2273},{\"id\":2274},{\"id\":2275},{\"id\":2276},{\"id\":2277},{\"id\":2278},{\"id\":2279},{\"id\":2280},{\"id\":2281},{\"id\":2282},{\"id\":2283},{\"id\":2284},{\"id\":2285},{\"id\":2286},{\"id\":2287},{\"id\":2288},{\"id\":2289},{\"id\":2290},{\"id\":2291},{\"id\":2292},{\"id\":2293},{\"id\":2294},{\"id\":2295},{\"id\":2296},{\"id\":2297},{\"id\":2298},{\"id\":2299},{\"id\":2300},{\"id\":2301},{\"id\":2302},{\"id\":2311},{\"id\":2316},{\"id\":2317},{\"id\":2343},{\"id\":2344},{\"id\":2393},{\"id\":2318},{\"id\":2345},{\"id\":2346},{\"id\":2394},{\"id\":2319},{\"id\":2347},{\"id\":2348},{\"id\":2395},{\"id\":2320},{\"id\":2349},{\"id\":2350},{\"id\":2396},{\"id\":2321},{\"id\":2351},{\"id\":2352},{\"id\":2397},{\"id\":2322},{\"id\":2353},{\"id\":2354},{\"id\":2398},{\"id\":2323},{\"id\":2355},{\"id\":2356},{\"id\":2399},{\"id\":2324},{\"id\":2357},{\"id\":2358},{\"id\":2400},{\"id\":2325},{\"id\":2359},{\"id\":2360},{\"id\":2401},{\"id\":2326},{\"id\":2361},{\"id\":2362},{\"id\":2402},{\"id\":2327},{\"id\":2363},{\"id\":2364},{\"id\":2403},{\"id\":2328},{\"id\":2365},{\"id\":2366},{\"id\":2404},{\"id\":2329},{\"id\":2367},{\"id\":2368},{\"id\":2405},{\"id\":2330},{\"id\":2369},{\"id\":2370},{\"id\":2406},{\"id\":2331},{\"id\":2371},{\"id\":2372},{\"id\":2407},{\"id\":2332},{\"id\":2373},{\"id\":2374},{\"id\":2408},{\"id\":2333},{\"id\":2375},{\"id\":2376},{\"id\":2409},{\"id\":2334},{\"id\":2377},{\"id\":2378},{\"id\":2410},{\"id\":2335},{\"id\":2379},{\"id\":2380},{\"id\":2411},{\"id\":2336},{\"id\":2381},{\"id\":2382},{\"id\":2412},{\"id\":2337},{\"id\":2383},{\"id\":2384},{\"id\":2413},{\"id\":2338},{\"id\":2385},{\"id\":2386},{\"id\":2414},{\"id\":2339},{\"id\":2387},{\"id\":2388},{\"id\":2415},{\"id\":2340},{\"id\":2389},{\"id\":2390},{\"id\":2416},{\"id\":2341},{\"id\":2391},{\"id\":2392},{\"id\":2417},{\"id\":2342},{\"id\":2418},{\"id\":2419},{\"id\":2312},{\"id\":2420},{\"id\":2421},{\"id\":2435},{\"id\":2436},{\"id\":2461},{\"id\":2422},{\"id\":2437},{\"id\":2438},{\"id\":2462},{\"id\":2423},{\"id\":2439},{\"id\":2440},{\"id\":2463},{\"id\":2424},{\"id\":2441},{\"id\":2442},{\"id\":2464},{\"id\":2425},{\"id\":2443},{\"id\":2444},{\"id\":2465},{\"id\":2426},{\"id\":2445},{\"id\":2446},{\"id\":2466},{\"id\":2427},{\"id\":2447},{\"id\":2448},{\"id\":2467},{\"id\":2428},{\"id\":2449},{\"id\":2450},{\"id\":2468},{\"id\":2429},{\"id\":2451},{\"id\":2452},{\"id\":2469},{\"id\":2430},{\"id\":2453},{\"id\":2454},{\"id\":2470},{\"id\":2431},{\"id\":2455},{\"id\":2456},{\"id\":2471},{\"id\":2432},{\"id\":2457},{\"id\":2458},{\"id\":2472},{\"id\":2433},{\"id\":2459},{\"id\":2460},{\"id\":2473},{\"id\":2434},{\"id\":2474},{\"id\":2475},{\"id\":2313},{\"id\":2476},{\"id\":2488},{\"id\":2477},{\"id\":2489},{\"id\":2478},{\"id\":2490},{\"id\":2479},{\"id\":2491},{\"id\":2480},{\"id\":2492},{\"id\":2481},{\"id\":2493},{\"id\":2482},{\"id\":2494},{\"id\":2483},{\"id\":2495},{\"id\":2484},{\"id\":2496},{\"id\":2485},{\"id\":2497},{\"id\":2486},{\"id\":2498},{\"id\":2487},{\"id\":2499},{\"id\":2314},{\"id\":2500},{\"id\":2501},{\"id\":2502},{\"id\":2503},{\"id\":2504},{\"id\":2505},{\"id\":2506},{\"id\":2507},{\"id\":2508},{\"id\":2509},{\"id\":2510},{\"id\":2511},{\"id\":2512},{\"id\":2513},{\"id\":2514},{\"id\":2515},{\"id\":2516},{\"id\":2517},{\"id\":2518},{\"id\":2519},{\"id\":2520},{\"id\":2521},{\"id\":2522},{\"id\":2523},{\"id\":2315},{\"id\":2524},{\"id\":2542},{\"id\":2543},{\"id\":2578},{\"id\":2525},{\"id\":2544},{\"id\":2545},{\"id\":2579},{\"id\":2526},{\"id\":2546},{\"id\":2547},{\"id\":2580},{\"id\":2527},{\"id\":2548},{\"id\":2549},{\"id\":2581},{\"id\":2528},{\"id\":2550},{\"id\":2551},{\"id\":2582},{\"id\":2529},{\"id\":2552},{\"id\":2553},{\"id\":2583},{\"id\":2530},{\"id\":2554},{\"id\":2555},{\"id\":2584},{\"id\":2531},{\"id\":2556},{\"id\":2557},{\"id\":2585},{\"id\":2532},{\"id\":2558},{\"id\":2559},{\"id\":2586},{\"id\":2533},{\"id\":2560},{\"id\":2561},{\"id\":2587},{\"id\":2534},{\"id\":2562},{\"id\":2563},{\"id\":2588},{\"id\":2535},{\"id\":2564},{\"id\":2565},{\"id\":2589},{\"id\":2536},{\"id\":2566},{\"id\":2567},{\"id\":2590},{\"id\":2537},{\"id\":2568},{\"id\":2569},{\"id\":2591},{\"id\":2538},{\"id\":2570},{\"id\":2571},{\"id\":2592},{\"id\":2539},{\"id\":2572},{\"id\":2573},{\"id\":2593},{\"id\":2540},{\"id\":2574},{\"id\":2575},{\"id\":2594},{\"id\":2541},{\"id\":2576},{\"id\":2577},{\"id\":2595},{\"id\":2303},{\"id\":2304},{\"id\":2305},{\"id\":2306},{\"id\":2307},{\"nodeType\":3,\"id\":2596,\"textContent\":\" // Track clicks on page $(document).ready(function() { $(\\\".control\\\").click(function(e) { e.stopImmediatePropagation(); clicks = clicks + 1; console.log(clicks); }); }); $('.userid').html(sid); // console.log(\\\"start of clicked array: \\\"+clicked); // console.log(\\\"start of hovered string: \\\"+hovered); //set correct answers for each question var triangular_answers = { \\\"acme.starttime.1\\\" : [\\\"F\\\"], \\\"acme.starts.1\\\" : [\\\"K\\\"], \\\"acme.meets.1\\\" : [\\\"F\\\"], \\\"acme.endtime.1\\\" : [\\\"H\\\"], \\\"acme.midpoint.1\\\" : [\\\"O\\\"], \\\"acme.starttime.2\\\" : [\\\"F\\\"], \\\"acme.starts.2\\\" : [\\\"K\\\"], \\\"acme.meets.2\\\" : [\\\"F\\\"], \\\"acme.endtime.2\\\" : [\\\"H\\\"], \\\"acme.midpoint.2\\\" : [\\\"A\\\"], \\\"bigset.duration.1\\\" : [\\\"E\\\",\\\"G\\\"], \\\"bigset.duration+starts.1\\\" : [\\\"X\\\",\\\"O\\\"], \\\"bigset.duration+contained.1\\\" : [\\\"G\\\"], \\\"bigset.starttime+before+endtime+during.1\\\": [\\\"I\\\"], \\\"bigset.ends.1\\\" : [\\\"E\\\"], \\\"bigset.duration.2\\\" : [\\\"E\\\",\\\"G\\\"], \\\"bigset.duration+starts.2\\\" : [\\\"X\\\",\\\"O\\\"], \\\"bigset.duration+contained.2\\\" : [\\\"G\\\"], \\\"bigset.starttime+before+endtime+during.2\\\":[\\\"I\\\"], \\\"bigset.ends.2\\\" : [\\\"E\\\"], \\\"bigset.starttime.1\\\" : [\\\"M\\\",\\\"L\\\"], \\\"bigset.starts.1\\\" : [\\\"G\\\"], \\\"bigset.meets.1\\\" : [\\\"E\\\",\\\"F\\\"], \\\"bigset.endtime.1\\\" : [\\\"X\\\"], \\\"bigset.midpoint.1\\\" : [\\\"K\\\",\\\"X\\\"], \\\"bigset.starttime.2\\\" : [\\\"M\\\",\\\"L\\\"], \\\"bigset.starts.2\\\" : [\\\"G\\\"], \\\"bigset.meets.2\\\" : [\\\"E\\\",\\\"F\\\"], \\\"bigset.endtime.2\\\" : [\\\"X\\\"], \\\"bigset.midpoint.2\\\" : [\\\"K\\\",\\\"X\\\"] } var orthogonal_answers = { \\\"acme.starttime.1\\\" : [\\\"A\\\"], \\\"acme.starts.1\\\" : [\\\"E\\\"], \\\"acme.meets.1\\\" : [\\\"Z\\\"], \\\"acme.endtime.1\\\" : [\\\"U\\\"], \\\"acme.midpoint.1\\\" : [\\\"U\\\"], \\\"acme.starttime.2\\\" : [\\\"0\\\"], \\\"acme.starts.2\\\" : [\\\"0\\\"], \\\"acme.meets.2\\\" : [\\\"0\\\"], \\\"acme.endtime.2\\\" : [\\\"0\\\"], \\\"acme.midpoint.2\\\" : [\\\"0\\\"], \\\"bigset.duration.1\\\" : [\\\"E\\\",\\\"G\\\"], \\\"bigset.duration+starts.1\\\" : [\\\"F\\\",\\\"B\\\"], \\\"bigset.duration+contained.1\\\" : [\\\"E\\\"], \\\"bigset.starttime+before+endtime+during.1\\\": [\\\"I\\\"], \\\"bigset.ends.1\\\" : [\\\"X\\\"], \\\"bigset.duration.2\\\" : [\\\"E\\\",\\\"G\\\"], \\\"bigset.duration+starts.2\\\" : [\\\"F\\\",\\\"B\\\"], \\\"bigset.duration+contained.2\\\" : [\\\"E\\\"], \\\"bigset.starttime+before+endtime+during.2\\\":[\\\"I\\\"], \\\"bigset.ends.2\\\" : [\\\"X\\\"], \\\"bigset.starttime.1\\\" : [\\\"F\\\",\\\"B\\\"], \\\"bigset.starts.1\\\" : [\\\"B\\\"], \\\"bigset.meets.1\\\" : [\\\"F\\\",\\\"X\\\"], \\\"bigset.endtime.1\\\" : [\\\"B\\\"], \\\"bigset.midpoint.1\\\" : [\\\"E\\\",\\\"F\\\"], \\\"bigset.starttime.2\\\" : [\\\"F\\\",\\\"B\\\"], \\\"bigset.starts.2\\\" : [\\\"B\\\"], \\\"bigset.meets.2\\\" : [\\\"F\\\",\\\"X\\\"], \\\"bigset.endtime.2\\\" : [\\\"B\\\"], \\\"bigset.midpoint.2\\\" : [\\\"E\\\",\\\"F\\\"] } //display the question and answer buttons based on input values from jsPsych document.getElementById(scenario+\\\".\\\"+question).style.display = \\\"block\\\"; if (question == \\\"strategy\\\") {document.getElementById(\\\"strategyButton\\\").style.display = \\\"block\\\";} else {document.getElementById(\\\"testingButton\\\").style.display = \\\"block\\\";} //---------SET PROPERTIES OF THE GRAPH -------------// // set the dimensions and margins of the graph var margin = {top: 25, right: 30, bottom: 90, left: 100}, width = 800, height = 800; var intersects = false; //default value for intersects scaffold var xAxisTitle, yAxisTitle; var datafile =\\\"\\\"; // SET AXIS VALUES if (axis == 1){ axis = \\\"Orthogonal-XInside-YFull\\\"; } else if (axis == 2){ axis = \\\"Orthogonal-XInside-YPartial\\\"; } else if (axis ==3){ axis = \\\"Triangular-XInside-YInside\\\"; } else if (axis ==4){ axis = \\\"Orthogonal-XInside-YInside\\\"; } else if (axis ==5){ axis = \\\"Orthogonal-XFull-YFull\\\"; } // SET EXPLICIT SCAFFOLD FEATURES if (explicit ==2 && axis != \\\"diagonal\\\"){ scaffold = 2; intersects = false; } else if (explicit == 2 && axis == \\\"diagonal\\\"){ scaffold = 2; intersects = false; } //TODO: not sure if above two lines are still valid since leaders are now generated on the fly else if (explicit == 3){ $('#hint-interactive').css(\\\"display\\\",\\\"block\\\"); //display textimage scaffold intersects = true; } //SET DATA FILE FOR IMPLICIT SCAFFOLD if (impasse == 1){ datafile = \\\"../views/src/data/acme_nonimpasse.csv\\\"; } else if (impasse == 2){ datafile = \\\"../views/src/data/acme_impasse.csv\\\"; } //OVERRIDE DATA FILE FOR NON-SCAFFOLD QUESTIONS if (q > 5) { //override data file if q# is greater than 5 datafile = \\\"../views/src/data/bigset.csv\\\"; console.log(\\\"override data file\\\"); $('#orthogonal-image').css(\\\"display\\\",\\\"none\\\"); //display textimage scaffold $('#diagonal-image').css(\\\"display\\\",\\\"none\\\"); //display textimage scaffold $('#hint-interactive').css(\\\"display\\\",\\\"none\\\"); //display textimage scaffold intersects = false; } // //---------CREATE THE SVG ------------------------// var svg = d3.select(\\\".d3container\\\").append(\\\"svg\\\") .attr(\\\"width\\\", width + margin.left + margin.right) .attr(\\\"height\\\", height + margin.top + margin.bottom) .append(\\\"g\\\") .attr(\\\"transform\\\", \\\"translate(\\\" + margin.left + \\\",\\\" + margin.top + \\\")\\\"); //---------DRAW THE GRAPH ------------------------// xAxisTitle = \\\"START & END TIME (time of day)\\\"; yAxisTitle = \\\"DURATION (in hours)\\\"; drawTriangleModel(datafile,intersects,axis,scaffold,q); \"},{\"id\":2308},{\"id\":2309},{\"nodeType\":3,\"id\":2597,\"textContent\":\" //MOUSE LOGGING SCRIPT var mouseLog = [] var xwidth = $(document).width(); var xheight = $(document).width(); mouseLog.push(\\\"{x:\\\"+xwidth+\\\",y:\\\"+xheight+\\\",t:\\\"+\\\"0};\\\") document.onmousemove = function(e){ var pageCoords = \\\"{x:\\\" + e.pageX + \\\",y:\\\"+ e.pageY +\\\",t:\\\"+ Date.now()+ \\\"};\\\" ; mouseLog.push(pageCoords); // console.log(pageCoords); }; \"},{\"id\":2310}],[],[],[]]}"
    },
    {
      "sequence": 3,
      "data": "{\"f\":\"applyChanged\",\"args\":[[],[{\"nodeType\":1,\"id\":2598,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-text-preamble\",\"class\":\"jspsych-survey-text-preamble\"},\"parentNode\":{\"id\":55}},{\"nodeType\":1,\"id\":2599,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-text-0\",\"class\":\"jspsych-survey-text-question\"},\"previousSibling\":{\"id\":2598},\"parentNode\":{\"id\":55}},{\"nodeType\":1,\"id\":2600,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-text-1\",\"class\":\"jspsych-survey-text-question\"},\"previousSibling\":{\"id\":2599},\"parentNode\":{\"id\":55}},{\"nodeType\":1,\"id\":2601,\"tagName\":\"BUTTON\",\"attributes\":{\"id\":\"jspsych-survey-text-next\",\"class\":\"jspsych-btn jspsych-survey-text\"},\"previousSibling\":{\"id\":2600},\"parentNode\":{\"id\":55}},{\"nodeType\":1,\"id\":2602,\"tagName\":\"P\",\"attributes\":{\"class\":\"jspsych-survey-text\"},\"parentNode\":{\"id\":2599}},{\"nodeType\":1,\"id\":2603,\"tagName\":\"TEXTAREA\",\"attributes\":{\"name\":\"#jspsych-survey-text-response-0\",\"cols\":\"40\",\"rows\":\"1\"},\"previousSibling\":{\"id\":2602},\"parentNode\":{\"id\":2599}},{\"nodeType\":3,\"id\":2604,\"textContent\":\"What is your age?\",\"parentNode\":{\"id\":2602}},{\"nodeType\":1,\"id\":2605,\"tagName\":\"P\",\"attributes\":{\"class\":\"jspsych-survey-text\"},\"parentNode\":{\"id\":2600}},{\"nodeType\":1,\"id\":2606,\"tagName\":\"TEXTAREA\",\"attributes\":{\"name\":\"#jspsych-survey-text-response-1\",\"cols\":\"40\",\"rows\":\"1\"},\"previousSibling\":{\"id\":2605},\"parentNode\":{\"id\":2600}},{\"nodeType\":3,\"id\":2607,\"textContent\":\"In what country were you born?\",\"parentNode\":{\"id\":2605}},{\"nodeType\":3,\"id\":2608,\"textContent\":\"Submit Answers\",\"parentNode\":{\"id\":2601}}],[],[]]}"
    },
    {
      "sequence": 4,
      "data": "{\"f\":\"applyChanged\",\"args\":[[{\"id\":2598},{\"id\":2599},{\"id\":2602},{\"id\":2604},{\"id\":2603},{\"id\":2600},{\"id\":2605},{\"id\":2607},{\"id\":2606},{\"id\":2601},{\"id\":2608}],[],[],[]]}"
    },
    {
      "sequence": 5,
      "data": "{\"f\":\"applyChanged\",\"args\":[[],[{\"nodeType\":1,\"id\":2609,\"tagName\":\"FORM\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-form\"},\"parentNode\":{\"id\":55}},{\"nodeType\":1,\"id\":2610,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-preamble\",\"class\":\"jspsych-survey-multi-choice-preamble\"},\"parentNode\":{\"id\":2609}},{\"nodeType\":1,\"id\":2611,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-0\",\"class\":\"jspsych-survey-multi-choice-question jspsych-survey-multi-choice-horizontal\"},\"previousSibling\":{\"id\":2610},\"parentNode\":{\"id\":2609}},{\"nodeType\":1,\"id\":2612,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-1\",\"class\":\"jspsych-survey-multi-choice-question jspsych-survey-multi-choice-horizontal\"},\"previousSibling\":{\"id\":2611},\"parentNode\":{\"id\":2609}},{\"nodeType\":1,\"id\":2613,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-2\",\"class\":\"jspsych-survey-multi-choice-question jspsych-survey-multi-choice-horizontal\"},\"previousSibling\":{\"id\":2612},\"parentNode\":{\"id\":2609}},{\"nodeType\":1,\"id\":2614,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-3\",\"class\":\"jspsych-survey-multi-choice-question jspsych-survey-multi-choice-horizontal\"},\"previousSibling\":{\"id\":2613},\"parentNode\":{\"id\":2609}},{\"nodeType\":1,\"id\":2615,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"submit\",\"id\":\"jspsych-survey-multi-choice-next\",\"class\":\"jspsych-survey-multi-choice jspsych-btn\",\"value\":\"Submit Answers\"},\"previousSibling\":{\"id\":2614},\"parentNode\":{\"id\":2609}},{\"nodeType\":1,\"id\":2616,\"tagName\":\"P\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text survey-multi-choice\"},\"parentNode\":{\"id\":2611}},{\"nodeType\":1,\"id\":2617,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-0-0\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2616},\"parentNode\":{\"id\":2611}},{\"nodeType\":1,\"id\":2618,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-0-1\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2617},\"parentNode\":{\"id\":2611}},{\"nodeType\":1,\"id\":2619,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-0-2\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2618},\"parentNode\":{\"id\":2611}},{\"nodeType\":1,\"id\":2620,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-0-3\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2619},\"parentNode\":{\"id\":2611}},{\"nodeType\":3,\"id\":2621,\"textContent\":\"What is your first language?\",\"parentNode\":{\"id\":2616}},{\"nodeType\":1,\"id\":2622,\"tagName\":\"SPAN\",\"attributes\":{\"class\":\"required\"},\"previousSibling\":{\"id\":2621},\"parentNode\":{\"id\":2616}},{\"nodeType\":1,\"id\":2623,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2617}},{\"nodeType\":1,\"id\":2624,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-0\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2623}},{\"nodeType\":3,\"id\":2625,\"textContent\":\"English\",\"previousSibling\":{\"id\":2624},\"parentNode\":{\"id\":2623}},{\"nodeType\":1,\"id\":2626,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2618}},{\"nodeType\":1,\"id\":2627,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-0\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2626}},{\"nodeType\":3,\"id\":2628,\"textContent\":\"Spanish\",\"previousSibling\":{\"id\":2627},\"parentNode\":{\"id\":2626}},{\"nodeType\":1,\"id\":2629,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2619}},{\"nodeType\":1,\"id\":2630,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-0\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2629}},{\"nodeType\":3,\"id\":2631,\"textContent\":\"Mandarin or Cantonese\",\"previousSibling\":{\"id\":2630},\"parentNode\":{\"id\":2629}},{\"nodeType\":1,\"id\":2632,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2620}},{\"nodeType\":1,\"id\":2633,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-0\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2632}},{\"nodeType\":3,\"id\":2634,\"textContent\":\"Other\",\"previousSibling\":{\"id\":2633},\"parentNode\":{\"id\":2632}},{\"nodeType\":3,\"id\":2635,\"textContent\":\"*\",\"parentNode\":{\"id\":2622}},{\"nodeType\":1,\"id\":2636,\"tagName\":\"P\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text survey-multi-choice\"},\"parentNode\":{\"id\":2612}},{\"nodeType\":1,\"id\":2637,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-1-0\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2636},\"parentNode\":{\"id\":2612}},{\"nodeType\":1,\"id\":2638,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-1-1\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2637},\"parentNode\":{\"id\":2612}},{\"nodeType\":1,\"id\":2639,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-1-2\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2638},\"parentNode\":{\"id\":2612}},{\"nodeType\":1,\"id\":2640,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-1-3\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2639},\"parentNode\":{\"id\":2612}},{\"nodeType\":1,\"id\":2641,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-1-4\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2640},\"parentNode\":{\"id\":2612}},{\"nodeType\":1,\"id\":2642,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-1-5\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2641},\"parentNode\":{\"id\":2612}},{\"nodeType\":1,\"id\":2643,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-1-6\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2642},\"parentNode\":{\"id\":2612}},{\"nodeType\":3,\"id\":2644,\"textContent\":\"What is your year in school?\",\"parentNode\":{\"id\":2636}},{\"nodeType\":1,\"id\":2645,\"tagName\":\"SPAN\",\"attributes\":{\"class\":\"required\"},\"previousSibling\":{\"id\":2644},\"parentNode\":{\"id\":2636}},{\"nodeType\":1,\"id\":2646,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2637}},{\"nodeType\":1,\"id\":2647,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-1\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2646}},{\"nodeType\":3,\"id\":2648,\"textContent\":\"First\",\"previousSibling\":{\"id\":2647},\"parentNode\":{\"id\":2646}},{\"nodeType\":1,\"id\":2649,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2638}},{\"nodeType\":1,\"id\":2650,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-1\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2649}},{\"nodeType\":3,\"id\":2651,\"textContent\":\"Second\",\"previousSibling\":{\"id\":2650},\"parentNode\":{\"id\":2649}},{\"nodeType\":1,\"id\":2652,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2639}},{\"nodeType\":1,\"id\":2653,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-1\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2652}},{\"nodeType\":3,\"id\":2654,\"textContent\":\"Third\",\"previousSibling\":{\"id\":2653},\"parentNode\":{\"id\":2652}},{\"nodeType\":1,\"id\":2655,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2640}},{\"nodeType\":1,\"id\":2656,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-1\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2655}},{\"nodeType\":3,\"id\":2657,\"textContent\":\"Fourth\",\"previousSibling\":{\"id\":2656},\"parentNode\":{\"id\":2655}},{\"nodeType\":1,\"id\":2658,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2641}},{\"nodeType\":1,\"id\":2659,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-1\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2658}},{\"nodeType\":3,\"id\":2660,\"textContent\":\"Fifth\",\"previousSibling\":{\"id\":2659},\"parentNode\":{\"id\":2658}},{\"nodeType\":1,\"id\":2661,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2642}},{\"nodeType\":1,\"id\":2662,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-1\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2661}},{\"nodeType\":3,\"id\":2663,\"textContent\":\"Graduate\",\"previousSibling\":{\"id\":2662},\"parentNode\":{\"id\":2661}},{\"nodeType\":1,\"id\":2664,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2643}},{\"nodeType\":1,\"id\":2665,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-1\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2664}},{\"nodeType\":3,\"id\":2666,\"textContent\":\"Other\",\"previousSibling\":{\"id\":2665},\"parentNode\":{\"id\":2664}},{\"nodeType\":3,\"id\":2667,\"textContent\":\"*\",\"parentNode\":{\"id\":2645}},{\"nodeType\":1,\"id\":2668,\"tagName\":\"P\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text survey-multi-choice\"},\"parentNode\":{\"id\":2613}},{\"nodeType\":1,\"id\":2669,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-2-0\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2668},\"parentNode\":{\"id\":2613}},{\"nodeType\":1,\"id\":2670,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-2-1\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2669},\"parentNode\":{\"id\":2613}},{\"nodeType\":1,\"id\":2671,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-2-2\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2670},\"parentNode\":{\"id\":2613}},{\"nodeType\":1,\"id\":2672,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-2-3\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2671},\"parentNode\":{\"id\":2613}},{\"nodeType\":1,\"id\":2673,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-2-4\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2672},\"parentNode\":{\"id\":2613}},{\"nodeType\":1,\"id\":2674,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-2-5\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2673},\"parentNode\":{\"id\":2613}},{\"nodeType\":1,\"id\":2675,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-2-6\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2674},\"parentNode\":{\"id\":2613}},{\"nodeType\":3,\"id\":2676,\"textContent\":\"What is your major area of study?\",\"parentNode\":{\"id\":2668}},{\"nodeType\":1,\"id\":2677,\"tagName\":\"SPAN\",\"attributes\":{\"class\":\"required\"},\"previousSibling\":{\"id\":2676},\"parentNode\":{\"id\":2668}},{\"nodeType\":1,\"id\":2678,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2669}},{\"nodeType\":1,\"id\":2679,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-2\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2678}},{\"nodeType\":3,\"id\":2680,\"textContent\":\"Math or Computer Sciences\",\"previousSibling\":{\"id\":2679},\"parentNode\":{\"id\":2678}},{\"nodeType\":1,\"id\":2681,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2670}},{\"nodeType\":1,\"id\":2682,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-2\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2681}},{\"nodeType\":3,\"id\":2683,\"textContent\":\"Social Sciences (incl. CogSci)\",\"previousSibling\":{\"id\":2682},\"parentNode\":{\"id\":2681}},{\"nodeType\":1,\"id\":2684,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2671}},{\"nodeType\":1,\"id\":2685,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-2\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2684}},{\"nodeType\":3,\"id\":2686,\"textContent\":\"Biomedical & Health Sciences\",\"previousSibling\":{\"id\":2685},\"parentNode\":{\"id\":2684}},{\"nodeType\":1,\"id\":2687,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2672}},{\"nodeType\":1,\"id\":2688,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-2\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2687}},{\"nodeType\":3,\"id\":2689,\"textContent\":\"Natural Sciences\",\"previousSibling\":{\"id\":2688},\"parentNode\":{\"id\":2687}},{\"nodeType\":1,\"id\":2690,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2673}},{\"nodeType\":1,\"id\":2691,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-2\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2690}},{\"nodeType\":3,\"id\":2692,\"textContent\":\"Engineering\",\"previousSibling\":{\"id\":2691},\"parentNode\":{\"id\":2690}},{\"nodeType\":1,\"id\":2693,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2674}},{\"nodeType\":1,\"id\":2694,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-2\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2693}},{\"nodeType\":3,\"id\":2695,\"textContent\":\"Humanities\",\"previousSibling\":{\"id\":2694},\"parentNode\":{\"id\":2693}},{\"nodeType\":1,\"id\":2696,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2675}},{\"nodeType\":1,\"id\":2697,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-2\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2696}},{\"nodeType\":3,\"id\":2698,\"textContent\":\"Fine Arts\",\"previousSibling\":{\"id\":2697},\"parentNode\":{\"id\":2696}},{\"nodeType\":3,\"id\":2699,\"textContent\":\"*\",\"parentNode\":{\"id\":2677}},{\"nodeType\":1,\"id\":2700,\"tagName\":\"P\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text survey-multi-choice\"},\"parentNode\":{\"id\":2614}},{\"nodeType\":1,\"id\":2701,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-3-0\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2700},\"parentNode\":{\"id\":2614}},{\"nodeType\":1,\"id\":2702,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-3-1\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2701},\"parentNode\":{\"id\":2614}},{\"nodeType\":1,\"id\":2703,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-3-2\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2702},\"parentNode\":{\"id\":2614}},{\"nodeType\":3,\"id\":2704,\"textContent\":\"What is your gender?\",\"parentNode\":{\"id\":2700}},{\"nodeType\":1,\"id\":2705,\"tagName\":\"SPAN\",\"attributes\":{\"class\":\"required\"},\"previousSibling\":{\"id\":2704},\"parentNode\":{\"id\":2700}},{\"nodeType\":1,\"id\":2706,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2701}},{\"nodeType\":1,\"id\":2707,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-3\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2706}},{\"nodeType\":3,\"id\":2708,\"textContent\":\"Male\",\"previousSibling\":{\"id\":2707},\"parentNode\":{\"id\":2706}},{\"nodeType\":1,\"id\":2709,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2702}},{\"nodeType\":1,\"id\":2710,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-3\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2709}},{\"nodeType\":3,\"id\":2711,\"textContent\":\"Female\",\"previousSibling\":{\"id\":2710},\"parentNode\":{\"id\":2709}},{\"nodeType\":1,\"id\":2712,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2703}},{\"nodeType\":1,\"id\":2713,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-3\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2712}},{\"nodeType\":3,\"id\":2714,\"textContent\":\"Other\",\"previousSibling\":{\"id\":2713},\"parentNode\":{\"id\":2712}},{\"nodeType\":3,\"id\":2715,\"textContent\":\"*\",\"parentNode\":{\"id\":2705}}],[],[]]}"
    },
    {
      "sequence": 6,
      "data": "{\"f\":\"applyChanged\",\"args\":[[{\"id\":2609},{\"id\":2610},{\"id\":2611},{\"id\":2616},{\"id\":2621},{\"id\":2622},{\"id\":2635},{\"id\":2617},{\"id\":2623},{\"id\":2624},{\"id\":2625},{\"id\":2618},{\"id\":2626},{\"id\":2627},{\"id\":2628},{\"id\":2619},{\"id\":2629},{\"id\":2630},{\"id\":2631},{\"id\":2620},{\"id\":2632},{\"id\":2633},{\"id\":2634},{\"id\":2612},{\"id\":2636},{\"id\":2644},{\"id\":2645},{\"id\":2667},{\"id\":2637},{\"id\":2646},{\"id\":2647},{\"id\":2648},{\"id\":2638},{\"id\":2649},{\"id\":2650},{\"id\":2651},{\"id\":2639},{\"id\":2652},{\"id\":2653},{\"id\":2654},{\"id\":2640},{\"id\":2655},{\"id\":2656},{\"id\":2657},{\"id\":2641},{\"id\":2658},{\"id\":2659},{\"id\":2660},{\"id\":2642},{\"id\":2661},{\"id\":2662},{\"id\":2663},{\"id\":2643},{\"id\":2664},{\"id\":2665},{\"id\":2666},{\"id\":2613},{\"id\":2668},{\"id\":2676},{\"id\":2677},{\"id\":2699},{\"id\":2669},{\"id\":2678},{\"id\":2679},{\"id\":2680},{\"id\":2670},{\"id\":2681},{\"id\":2682},{\"id\":2683},{\"id\":2671},{\"id\":2684},{\"id\":2685},{\"id\":2686},{\"id\":2672},{\"id\":2687},{\"id\":2688},{\"id\":2689},{\"id\":2673},{\"id\":2690},{\"id\":2691},{\"id\":2692},{\"id\":2674},{\"id\":2693},{\"id\":2694},{\"id\":2695},{\"id\":2675},{\"id\":2696},{\"id\":2697},{\"id\":2698},{\"id\":2614},{\"id\":2700},{\"id\":2704},{\"id\":2705},{\"id\":2715},{\"id\":2701},{\"id\":2706},{\"id\":2707},{\"id\":2708},{\"id\":2702},{\"id\":2709},{\"id\":2710},{\"id\":2711},{\"id\":2703},{\"id\":2712},{\"id\":2713},{\"id\":2714},{\"id\":2615}],[],[],[]]}"
    },
    {
      "sequence": 7,
      "data": "{\"f\":\"applyChanged\",\"args\":[[],[{\"nodeType\":1,\"id\":2716,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"masterdiv\"},\"parentNode\":{\"id\":55}},{\"nodeType\":3,\"id\":2717,\"textContent\":\" \",\"previousSibling\":{\"id\":2716},\"parentNode\":{\"id\":55}},{\"nodeType\":3,\"id\":2718,\"textContent\":\" \",\"parentNode\":{\"id\":2716}},{\"nodeType\":1,\"id\":2719,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"top\"},\"previousSibling\":{\"id\":2718},\"parentNode\":{\"id\":2716}},{\"nodeType\":3,\"id\":2720,\"textContent\":\" \",\"previousSibling\":{\"id\":2719},\"parentNode\":{\"id\":2716}},{\"nodeType\":1,\"id\":2721,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"instructions\"},\"previousSibling\":{\"id\":2720},\"parentNode\":{\"id\":2716}},{\"nodeType\":3,\"id\":2722,\"textContent\":\" \",\"previousSibling\":{\"id\":2721},\"parentNode\":{\"id\":2716}},{\"nodeType\":1,\"id\":2723,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bottom\"},\"previousSibling\":{\"id\":2722},\"parentNode\":{\"id\":2716}},{\"nodeType\":3,\"id\":2724,\"textContent\":\" \",\"previousSibling\":{\"id\":2723},\"parentNode\":{\"id\":2716}},{\"nodeType\":3,\"id\":2725,\"textContent\":\" \",\"parentNode\":{\"id\":2719}},{\"nodeType\":1,\"id\":2726,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bcent\"},\"previousSibling\":{\"id\":2725},\"parentNode\":{\"id\":2719}},{\"nodeType\":3,\"id\":2727,\"textContent\":\" \",\"previousSibling\":{\"id\":2726},\"parentNode\":{\"id\":2719}},{\"nodeType\":3,\"id\":2728,\"textContent\":\" \",\"parentNode\":{\"id\":2726}},{\"nodeType\":1,\"id\":2729,\"tagName\":\"H3\",\"attributes\":{},\"previousSibling\":{\"id\":2728},\"parentNode\":{\"id\":2726}},{\"nodeType\":3,\"id\":2730,\"textContent\":\" \",\"previousSibling\":{\"id\":2729},\"parentNode\":{\"id\":2726}},{\"nodeType\":3,\"id\":2731,\"textContent\":\"DEBRIEFING\",\"parentNode\":{\"id\":2729}},{\"nodeType\":3,\"id\":2732,\"textContent\":\" \",\"parentNode\":{\"id\":2721}},{\"nodeType\":1,\"id\":2733,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"vcent\"},\"previousSibling\":{\"id\":2732},\"parentNode\":{\"id\":2721}},{\"nodeType\":3,\"id\":2734,\"textContent\":\" \",\"previousSibling\":{\"id\":2733},\"parentNode\":{\"id\":2721}},{\"nodeType\":3,\"id\":2735,\"textContent\":\" \",\"parentNode\":{\"id\":2733}},{\"nodeType\":1,\"id\":2736,\"tagName\":\"P\",\"attributes\":{\"style\":\"font-style:italic\"},\"previousSibling\":{\"id\":2735},\"parentNode\":{\"id\":2733}},{\"nodeType\":1,\"id\":2737,\"tagName\":\"P\",\"attributes\":{},\"previousSibling\":{\"id\":2736},\"parentNode\":{\"id\":2733}},{\"nodeType\":3,\"id\":2738,\"textContent\":\" \",\"previousSibling\":{\"id\":2737},\"parentNode\":{\"id\":2733}},{\"nodeType\":1,\"id\":2739,\"tagName\":\"P\",\"attributes\":{},\"previousSibling\":{\"id\":2738},\"parentNode\":{\"id\":2733}},{\"nodeType\":3,\"id\":2740,\"textContent\":\" \",\"previousSibling\":{\"id\":2739},\"parentNode\":{\"id\":2733}},{\"nodeType\":1,\"id\":2741,\"tagName\":\"P\",\"attributes\":{},\"previousSibling\":{\"id\":2740},\"parentNode\":{\"id\":2733}},{\"nodeType\":3,\"id\":2742,\"textContent\":\" \",\"previousSibling\":{\"id\":2741},\"parentNode\":{\"id\":2733}},{\"nodeType\":1,\"id\":2743,\"tagName\":\"P\",\"attributes\":{\"style\":\"font-style:bold;\"},\"previousSibling\":{\"id\":2742},\"parentNode\":{\"id\":2733}},{\"nodeType\":3,\"id\":2744,\"textContent\":\" \",\"previousSibling\":{\"id\":2743},\"parentNode\":{\"id\":2733}},{\"nodeType\":1,\"id\":2745,\"tagName\":\"P\",\"attributes\":{\"style\":\"font-style:italic;\"},\"previousSibling\":{\"id\":2744},\"parentNode\":{\"id\":2733}},{\"nodeType\":3,\"id\":2746,\"textContent\":\" \",\"previousSibling\":{\"id\":2745},\"parentNode\":{\"id\":2733}},{\"nodeType\":3,\"id\":2747,\"textContent\":\"Thank you very much for your participation! This debriefing will tell you more about the study, what you did, and why. \",\"parentNode\":{\"id\":2736}},{\"nodeType\":3,\"id\":2748,\"textContent\":\" \",\"parentNode\":{\"id\":2737}},{\"nodeType\":1,\"id\":2749,\"tagName\":\"B\",\"attributes\":{},\"previousSibling\":{\"id\":2748},\"parentNode\":{\"id\":2737}},{\"nodeType\":3,\"id\":2750,\"textContent\":\" You have just used a series of pictures (charts, graphs and diagrams) accompanied by different types of instructions to answer a series of problem solving questions. While you were using the pictures, we measured where you clicked, scrolled and pointed with the computer mouse. We also measured the accuracy of your responses and the time it took to complete each question.\",\"previousSibling\":{\"id\":2749},\"parentNode\":{\"id\":2737}},{\"nodeType\":3,\"id\":2751,\"textContent\":\"What did you just do?\",\"parentNode\":{\"id\":2749}},{\"nodeType\":3,\"id\":2752,\"textContent\":\" \",\"parentNode\":{\"id\":2739}},{\"nodeType\":1,\"id\":2753,\"tagName\":\"B\",\"attributes\":{},\"previousSibling\":{\"id\":2752},\"parentNode\":{\"id\":2739}},{\"nodeType\":3,\"id\":2754,\"textContent\":\" Researchers of learning and cognition have long been interested in how graphic displays of information can be used to communicate, solve problems, and generate insights. As powerful as graphics may be in their communicative efficiency, they're not always immediately intuitive to understand. In short, we know a great deal more about learning with representations than we do about the learning of representations. In this project we are building upon previous research on reading and graph comprehension to explore how readers make sense of unfamiliar representations. The instructions you saw for each type of graph are known as “scaffolding techniques”, and we will compare your performance with the scaffolding techniques you saw with the performance of other participants to determine which types of instructions are most effective in helping humans to make sense of unfamiliar graphs. \",\"previousSibling\":{\"id\":2753},\"parentNode\":{\"id\":2739}},{\"nodeType\":3,\"id\":2755,\"textContent\":\"Why did we have you do it?\",\"parentNode\":{\"id\":2753}},{\"nodeType\":1,\"id\":2756,\"tagName\":\"B\",\"attributes\":{},\"parentNode\":{\"id\":2741}},{\"nodeType\":3,\"id\":2757,\"textContent\":\" We expect that you will have found some of the graphics more difficult to use than others. We also expect that with the assistance of the instructions, after solving several problems you will learn to use the difficult graphics so that you can answer the questions even more quickly than without. If you would like to receive a copy of the results of the study, or have any further questions, please contact the researchers Primary Researcher: Amy Fox : a2fox@ucsd.edu Faculty Advisor : Dr. Jim Hollan : hollan@ucsd.edu \",\"previousSibling\":{\"id\":2756},\"parentNode\":{\"id\":2741}},{\"nodeType\":3,\"id\":2758,\"textContent\":\"What do we expect to find?\",\"parentNode\":{\"id\":2756}},{\"nodeType\":3,\"id\":2759,\"textContent\":\"It is important that you do not discuss this experiment with other students who might participate after you. They must participate in the same way as you did, without any knowledge of what the experiment entails, or the reasoning behind it.\",\"parentNode\":{\"id\":2743}},{\"nodeType\":3,\"id\":2760,\"textContent\":\"Thank you for your time! We hope you enjoyed participating in this study as much as we enjoyed designing it.\",\"parentNode\":{\"id\":2745}},{\"nodeType\":3,\"id\":2761,\"textContent\":\" \",\"parentNode\":{\"id\":2723}},{\"nodeType\":1,\"id\":2762,\"tagName\":\"BUTTON\",\"attributes\":{\"class\":\"btn\",\"type\":\"button\",\"id\":\"start\"},\"previousSibling\":{\"id\":2761},\"parentNode\":{\"id\":2723}},{\"nodeType\":3,\"id\":2763,\"textContent\":\" \",\"previousSibling\":{\"id\":2762},\"parentNode\":{\"id\":2723}},{\"nodeType\":3,\"id\":2764,\"textContent\":\"FINISH\",\"parentNode\":{\"id\":2762}}],[],[]]}"
    },
    {
      "sequence": 8,
      "data": "{\"f\":\"applyChanged\",\"args\":[[{\"id\":2716},{\"id\":2718},{\"id\":2719},{\"id\":2725},{\"id\":2726},{\"id\":2728},{\"id\":2729},{\"id\":2731},{\"id\":2730},{\"id\":2727},{\"id\":2720},{\"id\":2721},{\"id\":2732},{\"id\":2733},{\"id\":2735},{\"id\":2736},{\"id\":2747},{\"id\":2737},{\"id\":2748},{\"id\":2749},{\"id\":2751},{\"id\":2750},{\"id\":2738},{\"id\":2739},{\"id\":2752},{\"id\":2753},{\"id\":2755},{\"id\":2754},{\"id\":2740},{\"id\":2741},{\"id\":2756},{\"id\":2758},{\"id\":2757},{\"id\":2742},{\"id\":2743},{\"id\":2759},{\"id\":2744},{\"id\":2745},{\"id\":2760},{\"id\":2746},{\"id\":2734},{\"id\":2722},{\"id\":2723},{\"id\":2761},{\"id\":2762},{\"id\":2764},{\"id\":2763},{\"id\":2724},{\"id\":2717}],[],[],[]]}"
    },
    {
      "sequence": 9,
      "data": "{\"f\":\"applyChanged\",\"args\":[[],[{\"nodeType\":1,\"id\":2765,\"tagName\":\"PRE\",\"attributes\":{\"id\":\"jspsych-data-display\"},\"parentNode\":{\"id\":55}},{\"nodeType\":3,\"id\":2766,\"textContent\":\"[ { \\\"rt\\\": 17546, \\\"stimulus\\\": \\\"img/phone.png\\\", \\\"key_press\\\": 13, \\\"block\\\": \\\"phone\\\", \\\"trial_type\\\": \\\"single-stim\\\", \\\"trial_index\\\": 0, \\\"time_elapsed\\\": 17552, \\\"internal_node_id\\\": \\\"0.0-0.0\\\", \\\"subject\\\": \\\"6Y93F\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"foxtrot\\\", \\\"condition\\\": \\\"111\\\" }, { \\\"rt\\\": 4855, \\\"url\\\": \\\"../views/src/external/consent.html\\\", \\\"block\\\": \\\"consent\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 1, \\\"time_elapsed\\\": 23504, \\\"internal_node_id\\\": \\\"0.0-1.0\\\", \\\"subject\\\": \\\"6Y93F\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"foxtrot\\\", \\\"condition\\\": \\\"111\\\" }, { \\\"rt\\\": 14609, \\\"responses\\\": \\\"{\\\\\\\"Q0\\\\\\\":\\\\\\\"foxtrot\\\\\\\",\\\\\\\"Q1\\\\\\\":\\\\\\\"111\\\\\\\"}\\\", \\\"block\\\": \\\"codes\\\", \\\"trial_type\\\": \\\"survey-text\\\", \\\"trial_index\\\": 2, \\\"time_elapsed\\\": 39119, \\\"internal_node_id\\\": \\\"0.0-2.0\\\", \\\"subject\\\": \\\"6Y93F\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"foxtrot\\\", \\\"condition\\\": \\\"111\\\" }, { \\\"rt\\\": 16174, \\\"url\\\": \\\"../views/src/external/instructions_lab.html\\\", \\\"block\\\": \\\"instructions_lab\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 3, \\\"time_elapsed\\\": 56385, \\\"internal_node_id\\\": \\\"0.0-3.0\\\", \\\"subject\\\": \\\"6Y93F\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"foxtrot\\\", \\\"condition\\\": \\\"111\\\" }, { \\\"rt\\\": 16794, \\\"stimulus\\\": \\\"img/acme.png\\\", \\\"key_press\\\": 13, \\\"block\\\": \\\"scenario\\\", \\\"trial_type\\\": \\\"single-stim\\\", \\\"trial_index\\\": 4, \\\"time_elapsed\\\": 74182, \\\"internal_node_id\\\": \\\"0.0-4.0\\\", \\\"subject\\\": \\\"6Y93F\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"foxtrot\\\", \\\"condition\\\": \\\"111\\\" }, { \\\"rt\\\": 102636, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 5, \\\"time_elapsed\\\": 178036, \\\"internal_node_id\\\": \\\"0.0-5.0-0.0\\\", \\\"subject\\\": \\\"6Y93F\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"foxtrot\\\", \\\"condition\\\": \\\"111\\\", \\\"scenario\\\": \\\"acme\\\", \\\"question\\\": \\\"starttime\\\", \\\"q\\\": 1, \\\"clicks\\\": 1, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XInside-YFull\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 1, \\\"answer\\\": [ \\\"A\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"X \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"U \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-J -J -A -A -A -A -11 AM-12 PM-01 PM-03 PM-04 PM-05 PM-06 PM-07 PM-B \\\", \\\"block\\\": \\\"triangular_scaffolded\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:983,y:864,t:1527016076085};\\\", \\\"{x:981,y:837,t:1527016076091};\\\", \\\"{x:969,y:787,t:1527016076105};\\\", \\\"{x:951,y:692,t:1527016076122};\\\", \\\"{x:960,y:677,t:1527016076138};\\\", \\\"{x:967,y:664,t:1527016076155};\\\", \\\"{x:972,y:657,t:1527016076172};\\\", \\\"{x:980,y:646,t:1527016076189};\\\", \\\"{x:990,y:638,t:1527016076205};\\\", \\\"{x:1003,y:627,t:1527016076223};\\\", \\\"{x:1010,y:621,t:1527016076238};\\\", \\\"{x:1011,y:621,t:1527016076255};\\\", \\\"{x:1012,y:621,t:1527016076323};\\\", \\\"{x:1012,y:622,t:1527016076363};\\\", \\\"{x:1013,y:622,t:1527016076540};\\\", \\\"{x:1014,y:621,t:1527016076563};\\\", \\\"{x:1015,y:621,t:1527016076573};\\\", \\\"{x:1018,y:614,t:1527016076590};\\\", \\\"{x:1019,y:611,t:1527016076605};\\\", \\\"{x:1019,y:610,t:1527016076623};\\\", \\\"{x:1018,y:609,t:1527016077499};\\\", \\\"{x:1017,y:609,t:1527016077563};\\\", \\\"{x:1015,y:609,t:1527016077574};\\\", \\\"{x:1007,y:609,t:1527016077590};\\\", \\\"{x:1002,y:609,t:1527016077607};\\\", \\\"{x:997,y:609,t:1527016077624};\\\", \\\"{x:996,y:609,t:1527016077640};\\\", \\\"{x:996,y:608,t:1527016077683};\\\", \\\"{x:995,y:607,t:1527016077699};\\\", \\\"{x:995,y:604,t:1527016077731};\\\", \\\"{x:996,y:596,t:1527016077740};\\\", \\\"{x:1010,y:577,t:1527016077757};\\\", \\\"{x:1020,y:560,t:1527016077774};\\\", \\\"{x:1042,y:538,t:1527016077790};\\\", \\\"{x:1050,y:528,t:1527016077807};\\\", \\\"{x:1055,y:522,t:1527016077824};\\\", \\\"{x:1058,y:521,t:1527016077840};\\\", \\\"{x:1068,y:513,t:1527016077867};\\\", \\\"{x:1073,y:510,t:1527016077875};\\\", \\\"{x:1078,y:501,t:1527016077890};\\\", \\\"{x:1088,y:488,t:1527016077906};\\\", \\\"{x:1100,y:480,t:1527016077923};\\\", \\\"{x:1114,y:468,t:1527016077939};\\\", \\\"{x:1140,y:455,t:1527016077956};\\\", \\\"{x:1144,y:453,t:1527016077974};\\\", \\\"{x:1154,y:449,t:1527016077990};\\\", \\\"{x:1155,y:449,t:1527016078006};\\\", \\\"{x:1157,y:448,t:1527016078024};\\\", \\\"{x:1157,y:447,t:1527016078042};\\\", \\\"{x:1161,y:447,t:1527016078211};\\\", \\\"{x:1172,y:447,t:1527016078224};\\\", \\\"{x:1188,y:447,t:1527016078241};\\\", \\\"{x:1202,y:445,t:1527016078257};\\\", \\\"{x:1205,y:445,t:1527016078274};\\\", \\\"{x:1227,y:445,t:1527016078291};\\\", \\\"{x:1229,y:445,t:1527016078306};\\\", \\\"{x:1231,y:445,t:1527016078323};\\\", \\\"{x:1232,y:442,t:1527016078676};\\\", \\\"{x:1241,y:432,t:1527016078691};\\\", \\\"{x:1252,y:424,t:1527016078708};\\\", \\\"{x:1263,y:417,t:1527016078724};\\\", \\\"{x:1266,y:413,t:1527016078741};\\\", \\\"{x:1267,y:413,t:1527016078759};\\\", \\\"{x:1267,y:412,t:1527016078803};\\\", \\\"{x:1274,y:411,t:1527016078811};\\\", \\\"{x:1279,y:409,t:1527016078824};\\\", \\\"{x:1323,y:411,t:1527016078841};\\\", \\\"{x:1411,y:421,t:1527016078859};\\\", \\\"{x:1448,y:420,t:1527016078875};\\\", \\\"{x:1493,y:419,t:1527016078891};\\\", \\\"{x:1496,y:420,t:1527016078908};\\\", \\\"{x:1503,y:424,t:1527016078925};\\\", \\\"{x:1511,y:428,t:1527016078941};\\\", \\\"{x:1516,y:429,t:1527016078958};\\\", \\\"{x:1517,y:429,t:1527016078987};\\\", \\\"{x:1517,y:432,t:1527016079107};\\\", \\\"{x:1511,y:432,t:1527016079124};\\\", \\\"{x:1507,y:436,t:1527016079141};\\\", \\\"{x:1502,y:439,t:1527016079158};\\\", \\\"{x:1499,y:443,t:1527016079175};\\\", \\\"{x:1498,y:444,t:1527016079195};\\\", \\\"{x:1498,y:445,t:1527016079219};\\\", \\\"{x:1498,y:446,t:1527016079227};\\\", \\\"{x:1496,y:448,t:1527016079243};\\\", \\\"{x:1495,y:448,t:1527016079258};\\\", \\\"{x:1494,y:450,t:1527016079275};\\\", \\\"{x:1491,y:452,t:1527016079290};\\\", \\\"{x:1487,y:454,t:1527016079307};\\\", \\\"{x:1484,y:456,t:1527016079325};\\\", \\\"{x:1483,y:457,t:1527016079341};\\\", \\\"{x:1481,y:458,t:1527016079358};\\\", \\\"{x:1480,y:458,t:1527016079375};\\\", \\\"{x:1477,y:460,t:1527016079392};\\\", \\\"{x:1476,y:461,t:1527016079408};\\\", \\\"{x:1474,y:461,t:1527016079476};\\\", \\\"{x:1473,y:463,t:1527016079499};\\\", \\\"{x:1472,y:465,t:1527016079523};\\\", \\\"{x:1471,y:465,t:1527016079531};\\\", \\\"{x:1470,y:465,t:1527016079542};\\\", \\\"{x:1469,y:466,t:1527016079558};\\\", \\\"{x:1468,y:466,t:1527016079659};\\\", \\\"{x:1467,y:466,t:1527016080067};\\\", \\\"{x:1465,y:466,t:1527016080075};\\\", \\\"{x:1463,y:463,t:1527016080092};\\\", \\\"{x:1460,y:460,t:1527016080109};\\\", \\\"{x:1459,y:458,t:1527016080125};\\\", \\\"{x:1458,y:458,t:1527016080142};\\\", \\\"{x:1457,y:457,t:1527016080179};\\\", \\\"{x:1456,y:455,t:1527016080308};\\\", \\\"{x:1455,y:454,t:1527016080380};\\\", \\\"{x:1455,y:453,t:1527016080403};\\\", \\\"{x:1454,y:453,t:1527016081899};\\\", \\\"{x:1451,y:452,t:1527016081910};\\\", \\\"{x:1447,y:450,t:1527016081927};\\\", \\\"{x:1445,y:449,t:1527016081947};\\\", \\\"{x:1443,y:449,t:1527016081971};\\\", \\\"{x:1443,y:448,t:1527016081994};\\\", \\\"{x:1442,y:448,t:1527016082009};\\\", \\\"{x:1439,y:446,t:1527016082050};\\\", \\\"{x:1438,y:446,t:1527016082059};\\\", \\\"{x:1437,y:445,t:1527016082077};\\\", \\\"{x:1435,y:443,t:1527016082106};\\\", \\\"{x:1434,y:443,t:1527016082114};\\\", \\\"{x:1433,y:443,t:1527016082126};\\\", \\\"{x:1431,y:442,t:1527016082142};\\\", \\\"{x:1430,y:441,t:1527016082160};\\\", \\\"{x:1428,y:440,t:1527016082177};\\\", \\\"{x:1425,y:440,t:1527016082193};\\\", \\\"{x:1423,y:439,t:1527016082209};\\\", \\\"{x:1421,y:438,t:1527016082235};\\\", \\\"{x:1420,y:438,t:1527016082331};\\\", \\\"{x:1420,y:436,t:1527016082627};\\\", \\\"{x:1420,y:435,t:1527016082667};\\\", \\\"{x:1419,y:433,t:1527016082782};\\\", \\\"{x:1418,y:432,t:1527016082874};\\\", \\\"{x:1417,y:431,t:1527016082979};\\\", \\\"{x:1416,y:431,t:1527016087723};\\\", \\\"{x:1414,y:429,t:1527016089530};\\\", \\\"{x:1412,y:427,t:1527016089546};\\\", \\\"{x:1411,y:427,t:1527016089587};\\\", \\\"{x:1410,y:426,t:1527016089600};\\\", \\\"{x:1409,y:426,t:1527016089617};\\\", \\\"{x:1407,y:425,t:1527016089632};\\\", \\\"{x:1406,y:424,t:1527016089650};\\\", \\\"{x:1397,y:422,t:1527016089666};\\\", \\\"{x:1390,y:422,t:1527016089683};\\\", \\\"{x:1386,y:422,t:1527016089699};\\\", \\\"{x:1381,y:422,t:1527016089716};\\\", \\\"{x:1380,y:422,t:1527016089732};\\\", \\\"{x:1376,y:422,t:1527016089749};\\\", \\\"{x:1372,y:422,t:1527016089770};\\\", \\\"{x:1371,y:422,t:1527016089782};\\\", \\\"{x:1367,y:420,t:1527016089799};\\\", \\\"{x:1362,y:418,t:1527016089816};\\\", \\\"{x:1346,y:418,t:1527016089832};\\\", \\\"{x:1338,y:418,t:1527016089849};\\\", \\\"{x:1329,y:418,t:1527016089867};\\\", \\\"{x:1327,y:419,t:1527016089882};\\\", \\\"{x:1324,y:419,t:1527016089899};\\\", \\\"{x:1323,y:420,t:1527016089916};\\\", \\\"{x:1321,y:420,t:1527016089932};\\\", \\\"{x:1318,y:422,t:1527016089949};\\\", \\\"{x:1320,y:422,t:1527016090170};\\\", \\\"{x:1321,y:423,t:1527016090595};\\\", \\\"{x:1317,y:426,t:1527016090610};\\\", \\\"{x:1311,y:433,t:1527016090619};\\\", \\\"{x:1301,y:439,t:1527016090634};\\\", \\\"{x:1288,y:456,t:1527016090650};\\\", \\\"{x:1268,y:475,t:1527016090667};\\\", \\\"{x:1262,y:481,t:1527016090683};\\\", \\\"{x:1255,y:486,t:1527016090699};\\\", \\\"{x:1255,y:487,t:1527016091115};\\\", \\\"{x:1255,y:488,t:1527016091123};\\\", \\\"{x:1255,y:489,t:1527016091133};\\\", \\\"{x:1250,y:498,t:1527016091150};\\\", \\\"{x:1242,y:513,t:1527016091168};\\\", \\\"{x:1233,y:530,t:1527016091183};\\\", \\\"{x:1227,y:545,t:1527016091200};\\\", \\\"{x:1222,y:549,t:1527016091218};\\\", \\\"{x:1217,y:563,t:1527016091234};\\\", \\\"{x:1208,y:590,t:1527016091251};\\\", \\\"{x:1207,y:612,t:1527016091266};\\\", \\\"{x:1209,y:628,t:1527016091283};\\\", \\\"{x:1211,y:648,t:1527016091301};\\\", \\\"{x:1222,y:672,t:1527016091317};\\\", \\\"{x:1234,y:694,t:1527016091333};\\\", \\\"{x:1245,y:709,t:1527016091350};\\\", \\\"{x:1260,y:728,t:1527016091368};\\\", \\\"{x:1272,y:747,t:1527016091383};\\\", \\\"{x:1278,y:763,t:1527016091400};\\\", \\\"{x:1281,y:771,t:1527016091418};\\\", \\\"{x:1282,y:777,t:1527016091433};\\\", \\\"{x:1282,y:786,t:1527016091450};\\\", \\\"{x:1282,y:790,t:1527016091466};\\\", \\\"{x:1283,y:800,t:1527016091483};\\\", \\\"{x:1288,y:811,t:1527016091500};\\\", \\\"{x:1290,y:813,t:1527016091518};\\\", \\\"{x:1292,y:815,t:1527016091533};\\\", \\\"{x:1294,y:817,t:1527016091571};\\\", \\\"{x:1295,y:820,t:1527016091587};\\\", \\\"{x:1298,y:826,t:1527016091601};\\\", \\\"{x:1303,y:841,t:1527016091617};\\\", \\\"{x:1303,y:857,t:1527016091634};\\\", \\\"{x:1303,y:863,t:1527016091651};\\\", \\\"{x:1303,y:864,t:1527016091875};\\\", \\\"{x:1302,y:864,t:1527016091885};\\\", \\\"{x:1297,y:864,t:1527016091900};\\\", \\\"{x:1289,y:862,t:1527016091916};\\\", \\\"{x:1286,y:861,t:1527016091934};\\\", \\\"{x:1285,y:861,t:1527016091949};\\\", \\\"{x:1283,y:859,t:1527016092075};\\\", \\\"{x:1283,y:857,t:1527016092084};\\\", \\\"{x:1283,y:852,t:1527016092101};\\\", \\\"{x:1283,y:849,t:1527016092118};\\\", \\\"{x:1286,y:844,t:1527016092134};\\\", \\\"{x:1289,y:837,t:1527016092151};\\\", \\\"{x:1293,y:832,t:1527016092167};\\\", \\\"{x:1297,y:828,t:1527016092185};\\\", \\\"{x:1299,y:821,t:1527016092201};\\\", \\\"{x:1299,y:820,t:1527016092379};\\\", \\\"{x:1298,y:820,t:1527016092403};\\\", \\\"{x:1297,y:820,t:1527016092427};\\\", \\\"{x:1296,y:820,t:1527016092435};\\\", \\\"{x:1293,y:820,t:1527016092451};\\\", \\\"{x:1290,y:822,t:1527016092468};\\\", \\\"{x:1285,y:825,t:1527016092484};\\\", \\\"{x:1285,y:826,t:1527016092931};\\\", \\\"{x:1285,y:827,t:1527016093163};\\\", \\\"{x:1285,y:828,t:1527016093171};\\\", \\\"{x:1285,y:829,t:1527016093186};\\\", \\\"{x:1283,y:830,t:1527016093307};\\\", \\\"{x:1282,y:830,t:1527016093321};\\\", \\\"{x:1280,y:830,t:1527016093335};\\\", \\\"{x:1277,y:829,t:1527016093351};\\\", \\\"{x:1276,y:829,t:1527016093367};\\\", \\\"{x:1276,y:828,t:1527016094042};\\\", \\\"{x:1276,y:827,t:1527016094052};\\\", \\\"{x:1279,y:827,t:1527016094068};\\\", \\\"{x:1281,y:825,t:1527016094085};\\\", \\\"{x:1283,y:824,t:1527016094102};\\\", \\\"{x:1285,y:824,t:1527016094119};\\\", \\\"{x:1281,y:824,t:1527016094577};\\\", \\\"{x:1277,y:826,t:1527016094586};\\\", \\\"{x:1262,y:825,t:1527016094602};\\\", \\\"{x:1260,y:825,t:1527016094619};\\\", \\\"{x:1259,y:825,t:1527016094636};\\\", \\\"{x:1255,y:824,t:1527016094652};\\\", \\\"{x:1250,y:820,t:1527016094669};\\\", \\\"{x:1246,y:820,t:1527016094685};\\\", \\\"{x:1244,y:819,t:1527016094702};\\\", \\\"{x:1243,y:818,t:1527016094719};\\\", \\\"{x:1247,y:814,t:1527016094890};\\\", \\\"{x:1253,y:812,t:1527016094903};\\\", \\\"{x:1254,y:811,t:1527016094919};\\\", \\\"{x:1254,y:810,t:1527016094937};\\\", \\\"{x:1255,y:810,t:1527016094953};\\\", \\\"{x:1255,y:808,t:1527016095177};\\\", \\\"{x:1255,y:807,t:1527016095193};\\\", \\\"{x:1256,y:806,t:1527016095226};\\\", \\\"{x:1257,y:805,t:1527016095235};\\\", \\\"{x:1257,y:803,t:1527016095253};\\\", \\\"{x:1259,y:802,t:1527016095274};\\\", \\\"{x:1261,y:800,t:1527016095285};\\\", \\\"{x:1262,y:800,t:1527016095313};\\\", \\\"{x:1263,y:800,t:1527016095394};\\\", \\\"{x:1271,y:798,t:1527016095513};\\\", \\\"{x:1277,y:796,t:1527016095522};\\\", \\\"{x:1284,y:795,t:1527016095536};\\\", \\\"{x:1291,y:792,t:1527016095552};\\\", \\\"{x:1295,y:792,t:1527016095570};\\\", \\\"{x:1297,y:791,t:1527016095586};\\\", \\\"{x:1298,y:790,t:1527016095633};\\\", \\\"{x:1300,y:789,t:1527016095650};\\\", \\\"{x:1301,y:788,t:1527016095657};\\\", \\\"{x:1303,y:788,t:1527016095670};\\\", \\\"{x:1309,y:785,t:1527016095686};\\\", \\\"{x:1318,y:780,t:1527016095703};\\\", \\\"{x:1330,y:773,t:1527016095719};\\\", \\\"{x:1345,y:768,t:1527016095736};\\\", \\\"{x:1356,y:761,t:1527016095753};\\\", \\\"{x:1368,y:754,t:1527016095770};\\\", \\\"{x:1373,y:750,t:1527016095786};\\\", \\\"{x:1373,y:748,t:1527016095802};\\\", \\\"{x:1375,y:747,t:1527016095820};\\\", \\\"{x:1379,y:742,t:1527016095857};\\\", \\\"{x:1387,y:734,t:1527016095870};\\\", \\\"{x:1394,y:730,t:1527016095887};\\\", \\\"{x:1399,y:725,t:1527016095902};\\\", \\\"{x:1401,y:724,t:1527016095920};\\\", \\\"{x:1402,y:722,t:1527016095937};\\\", \\\"{x:1403,y:721,t:1527016096314};\\\", \\\"{x:1405,y:720,t:1527016096322};\\\", \\\"{x:1406,y:719,t:1527016096338};\\\", \\\"{x:1407,y:719,t:1527016096354};\\\", \\\"{x:1408,y:718,t:1527016096369};\\\", \\\"{x:1409,y:718,t:1527016096513};\\\", \\\"{x:1411,y:719,t:1527016098202};\\\", \\\"{x:1413,y:729,t:1527016098209};\\\", \\\"{x:1418,y:741,t:1527016098221};\\\", \\\"{x:1418,y:761,t:1527016098238};\\\", \\\"{x:1420,y:785,t:1527016098255};\\\", \\\"{x:1420,y:808,t:1527016098271};\\\", \\\"{x:1414,y:833,t:1527016098287};\\\", \\\"{x:1406,y:846,t:1527016098305};\\\", \\\"{x:1397,y:855,t:1527016098321};\\\", \\\"{x:1388,y:869,t:1527016098338};\\\", \\\"{x:1381,y:881,t:1527016098355};\\\", \\\"{x:1376,y:893,t:1527016098372};\\\", \\\"{x:1372,y:900,t:1527016098388};\\\", \\\"{x:1371,y:900,t:1527016098489};\\\", \\\"{x:1370,y:901,t:1527016098505};\\\", \\\"{x:1340,y:914,t:1527016098521};\\\", \\\"{x:1316,y:926,t:1527016098538};\\\", \\\"{x:1302,y:941,t:1527016098555};\\\", \\\"{x:1282,y:963,t:1527016098572};\\\", \\\"{x:1271,y:973,t:1527016098588};\\\", \\\"{x:1270,y:973,t:1527016098605};\\\", \\\"{x:1269,y:974,t:1527016098622};\\\", \\\"{x:1272,y:974,t:1527016098770};\\\", \\\"{x:1276,y:974,t:1527016098777};\\\", \\\"{x:1277,y:974,t:1527016098789};\\\", \\\"{x:1284,y:974,t:1527016098804};\\\", \\\"{x:1287,y:974,t:1527016098822};\\\", \\\"{x:1294,y:974,t:1527016098839};\\\", \\\"{x:1295,y:974,t:1527016098855};\\\", \\\"{x:1297,y:974,t:1527016098872};\\\", \\\"{x:1300,y:974,t:1527016098890};\\\", \\\"{x:1302,y:974,t:1527016098905};\\\", \\\"{x:1310,y:974,t:1527016098922};\\\", \\\"{x:1319,y:974,t:1527016098939};\\\", \\\"{x:1322,y:974,t:1527016098955};\\\", \\\"{x:1325,y:974,t:1527016098971};\\\", \\\"{x:1327,y:974,t:1527016098989};\\\", \\\"{x:1328,y:974,t:1527016099010};\\\", \\\"{x:1330,y:974,t:1527016099041};\\\", \\\"{x:1332,y:974,t:1527016099065};\\\", \\\"{x:1333,y:973,t:1527016099074};\\\", \\\"{x:1335,y:971,t:1527016099089};\\\", \\\"{x:1337,y:971,t:1527016099105};\\\", \\\"{x:1339,y:970,t:1527016099122};\\\", \\\"{x:1341,y:969,t:1527016099161};\\\", \\\"{x:1342,y:969,t:1527016099172};\\\", \\\"{x:1345,y:968,t:1527016099189};\\\", \\\"{x:1353,y:965,t:1527016099206};\\\", \\\"{x:1356,y:965,t:1527016099222};\\\", \\\"{x:1357,y:965,t:1527016099239};\\\", \\\"{x:1358,y:965,t:1527016099255};\\\", \\\"{x:1366,y:964,t:1527016099272};\\\", \\\"{x:1373,y:964,t:1527016099288};\\\", \\\"{x:1378,y:964,t:1527016099306};\\\", \\\"{x:1380,y:964,t:1527016099337};\\\", \\\"{x:1381,y:964,t:1527016099442};\\\", \\\"{x:1382,y:964,t:1527016099457};\\\", \\\"{x:1390,y:964,t:1527016099473};\\\", \\\"{x:1393,y:967,t:1527016099489};\\\", \\\"{x:1401,y:967,t:1527016099506};\\\", \\\"{x:1423,y:970,t:1527016099522};\\\", \\\"{x:1435,y:970,t:1527016099539};\\\", \\\"{x:1440,y:970,t:1527016099556};\\\", \\\"{x:1441,y:970,t:1527016099730};\\\", \\\"{x:1441,y:968,t:1527016099739};\\\", \\\"{x:1447,y:967,t:1527016099756};\\\", \\\"{x:1452,y:966,t:1527016099773};\\\", \\\"{x:1454,y:966,t:1527016099789};\\\", \\\"{x:1455,y:966,t:1527016099806};\\\", \\\"{x:1459,y:965,t:1527016100026};\\\", \\\"{x:1460,y:965,t:1527016100039};\\\", \\\"{x:1467,y:965,t:1527016100056};\\\", \\\"{x:1485,y:965,t:1527016100073};\\\", \\\"{x:1490,y:968,t:1527016100089};\\\", \\\"{x:1509,y:973,t:1527016100106};\\\", \\\"{x:1513,y:973,t:1527016100123};\\\", \\\"{x:1514,y:973,t:1527016100140};\\\", \\\"{x:1516,y:973,t:1527016100346};\\\", \\\"{x:1520,y:973,t:1527016100355};\\\", \\\"{x:1529,y:972,t:1527016100373};\\\", \\\"{x:1545,y:972,t:1527016100390};\\\", \\\"{x:1559,y:972,t:1527016100406};\\\", \\\"{x:1577,y:972,t:1527016100423};\\\", \\\"{x:1585,y:972,t:1527016100440};\\\", \\\"{x:1600,y:973,t:1527016100456};\\\", \\\"{x:1606,y:973,t:1527016100473};\\\", \\\"{x:1607,y:973,t:1527016100489};\\\", \\\"{x:1607,y:974,t:1527016100721};\\\", \\\"{x:1609,y:974,t:1527016100882};\\\", \\\"{x:1610,y:974,t:1527016100890};\\\", \\\"{x:1615,y:974,t:1527016100907};\\\", \\\"{x:1623,y:973,t:1527016100923};\\\", \\\"{x:1642,y:973,t:1527016100940};\\\", \\\"{x:1652,y:973,t:1527016100957};\\\", \\\"{x:1670,y:972,t:1527016100973};\\\", \\\"{x:1674,y:970,t:1527016100991};\\\", \\\"{x:1678,y:970,t:1527016101007};\\\", \\\"{x:1680,y:970,t:1527016101024};\\\", \\\"{x:1681,y:970,t:1527016101201};\\\", \\\"{x:1682,y:970,t:1527016101369};\\\", \\\"{x:1684,y:970,t:1527016101377};\\\", \\\"{x:1686,y:970,t:1527016101390};\\\", \\\"{x:1694,y:972,t:1527016101407};\\\", \\\"{x:1703,y:973,t:1527016101424};\\\", \\\"{x:1710,y:974,t:1527016101440};\\\", \\\"{x:1719,y:976,t:1527016101457};\\\", \\\"{x:1733,y:978,t:1527016101474};\\\", \\\"{x:1735,y:978,t:1527016101490};\\\", \\\"{x:1736,y:978,t:1527016101507};\\\", \\\"{x:1738,y:978,t:1527016101524};\\\", \\\"{x:1741,y:978,t:1527016101540};\\\", \\\"{x:1744,y:978,t:1527016101557};\\\", \\\"{x:1746,y:979,t:1527016101574};\\\", \\\"{x:1748,y:979,t:1527016101591};\\\", \\\"{x:1748,y:980,t:1527016101607};\\\", \\\"{x:1749,y:980,t:1527016101624};\\\", \\\"{x:1751,y:981,t:1527016101721};\\\", \\\"{x:1753,y:981,t:1527016101729};\\\", \\\"{x:1755,y:981,t:1527016101741};\\\", \\\"{x:1760,y:982,t:1527016101757};\\\", \\\"{x:1769,y:984,t:1527016101775};\\\", \\\"{x:1780,y:984,t:1527016101791};\\\", \\\"{x:1789,y:984,t:1527016101807};\\\", \\\"{x:1795,y:984,t:1527016101824};\\\", \\\"{x:1802,y:983,t:1527016101840};\\\", \\\"{x:1805,y:983,t:1527016101857};\\\", \\\"{x:1810,y:982,t:1527016101874};\\\", \\\"{x:1816,y:981,t:1527016101891};\\\", \\\"{x:1822,y:980,t:1527016101907};\\\", \\\"{x:1825,y:979,t:1527016101924};\\\", \\\"{x:1826,y:979,t:1527016102290};\\\", \\\"{x:1826,y:978,t:1527016102345};\\\", \\\"{x:1826,y:977,t:1527016102369};\\\", \\\"{x:1826,y:976,t:1527016102385};\\\", \\\"{x:1826,y:975,t:1527016102394};\\\", \\\"{x:1826,y:974,t:1527016102409};\\\", \\\"{x:1826,y:972,t:1527016102425};\\\", \\\"{x:1826,y:970,t:1527016102441};\\\", \\\"{x:1826,y:968,t:1527016102458};\\\", \\\"{x:1825,y:966,t:1527016102475};\\\", \\\"{x:1824,y:964,t:1527016102491};\\\", \\\"{x:1823,y:963,t:1527016102530};\\\", \\\"{x:1822,y:961,t:1527016102609};\\\", \\\"{x:1821,y:961,t:1527016102801};\\\", \\\"{x:1821,y:960,t:1527016102810};\\\", \\\"{x:1819,y:960,t:1527016103010};\\\", \\\"{x:1819,y:959,t:1527016103241};\\\", \\\"{x:1818,y:959,t:1527016106299};\\\", \\\"{x:1818,y:958,t:1527016106722};\\\", \\\"{x:1818,y:957,t:1527016106730};\\\", \\\"{x:1816,y:957,t:1527016106810};\\\", \\\"{x:1813,y:956,t:1527016106835};\\\", \\\"{x:1812,y:955,t:1527016106845};\\\", \\\"{x:1811,y:955,t:1527016106862};\\\", \\\"{x:1810,y:954,t:1527016106879};\\\", \\\"{x:1809,y:954,t:1527016106895};\\\", \\\"{x:1809,y:953,t:1527016106912};\\\", \\\"{x:1807,y:952,t:1527016106928};\\\", \\\"{x:1806,y:951,t:1527016106961};\\\", \\\"{x:1804,y:951,t:1527016106985};\\\", \\\"{x:1803,y:951,t:1527016106994};\\\", \\\"{x:1801,y:950,t:1527016107011};\\\", \\\"{x:1798,y:948,t:1527016107028};\\\", \\\"{x:1796,y:948,t:1527016107045};\\\", \\\"{x:1793,y:946,t:1527016107061};\\\", \\\"{x:1789,y:944,t:1527016107078};\\\", \\\"{x:1788,y:944,t:1527016107106};\\\", \\\"{x:1784,y:943,t:1527016107122};\\\", \\\"{x:1784,y:942,t:1527016107138};\\\", \\\"{x:1783,y:942,t:1527016107146};\\\", \\\"{x:1781,y:942,t:1527016107162};\\\", \\\"{x:1779,y:940,t:1527016107178};\\\", \\\"{x:1778,y:938,t:1527016107194};\\\", \\\"{x:1773,y:936,t:1527016107212};\\\", \\\"{x:1772,y:934,t:1527016107228};\\\", \\\"{x:1767,y:930,t:1527016107246};\\\", \\\"{x:1763,y:929,t:1527016107262};\\\", \\\"{x:1759,y:924,t:1527016107279};\\\", \\\"{x:1755,y:919,t:1527016107296};\\\", \\\"{x:1754,y:918,t:1527016107312};\\\", \\\"{x:1749,y:913,t:1527016107329};\\\", \\\"{x:1746,y:910,t:1527016107346};\\\", \\\"{x:1744,y:904,t:1527016107362};\\\", \\\"{x:1737,y:895,t:1527016107379};\\\", \\\"{x:1730,y:883,t:1527016107396};\\\", \\\"{x:1723,y:875,t:1527016107412};\\\", \\\"{x:1717,y:865,t:1527016107429};\\\", \\\"{x:1713,y:859,t:1527016107446};\\\", \\\"{x:1709,y:855,t:1527016107462};\\\", \\\"{x:1705,y:849,t:1527016107479};\\\", \\\"{x:1698,y:841,t:1527016107495};\\\", \\\"{x:1698,y:839,t:1527016107512};\\\", \\\"{x:1697,y:837,t:1527016107530};\\\", \\\"{x:1693,y:831,t:1527016107546};\\\", \\\"{x:1691,y:826,t:1527016107562};\\\", \\\"{x:1689,y:823,t:1527016107579};\\\", \\\"{x:1686,y:820,t:1527016107596};\\\", \\\"{x:1683,y:817,t:1527016107612};\\\", \\\"{x:1681,y:813,t:1527016107629};\\\", \\\"{x:1680,y:812,t:1527016107646};\\\", \\\"{x:1678,y:811,t:1527016107662};\\\", \\\"{x:1678,y:810,t:1527016107679};\\\", \\\"{x:1677,y:810,t:1527016107696};\\\", \\\"{x:1677,y:808,t:1527016107763};\\\", \\\"{x:1675,y:808,t:1527016107786};\\\", \\\"{x:1673,y:807,t:1527016107796};\\\", \\\"{x:1669,y:803,t:1527016107813};\\\", \\\"{x:1668,y:802,t:1527016107829};\\\", \\\"{x:1667,y:801,t:1527016107846};\\\", \\\"{x:1665,y:800,t:1527016107863};\\\", \\\"{x:1661,y:798,t:1527016107879};\\\", \\\"{x:1659,y:797,t:1527016107896};\\\", \\\"{x:1657,y:795,t:1527016107913};\\\", \\\"{x:1655,y:794,t:1527016107930};\\\", \\\"{x:1654,y:794,t:1527016107946};\\\", \\\"{x:1652,y:793,t:1527016107962};\\\", \\\"{x:1650,y:792,t:1527016107979};\\\", \\\"{x:1648,y:791,t:1527016107996};\\\", \\\"{x:1645,y:788,t:1527016108013};\\\", \\\"{x:1641,y:787,t:1527016108029};\\\", \\\"{x:1637,y:784,t:1527016108046};\\\", \\\"{x:1633,y:782,t:1527016108063};\\\", \\\"{x:1630,y:781,t:1527016108079};\\\", \\\"{x:1626,y:780,t:1527016108096};\\\", \\\"{x:1625,y:777,t:1527016108113};\\\", \\\"{x:1624,y:776,t:1527016108130};\\\", \\\"{x:1619,y:774,t:1527016108146};\\\", \\\"{x:1616,y:773,t:1527016108163};\\\", \\\"{x:1615,y:773,t:1527016108186};\\\", \\\"{x:1614,y:773,t:1527016108202};\\\", \\\"{x:1614,y:772,t:1527016108213};\\\", \\\"{x:1613,y:771,t:1527016108235};\\\", \\\"{x:1611,y:771,t:1527016109186};\\\", \\\"{x:1610,y:771,t:1527016109218};\\\", \\\"{x:1609,y:771,t:1527016109250};\\\", \\\"{x:1608,y:771,t:1527016109266};\\\", \\\"{x:1607,y:771,t:1527016109280};\\\", \\\"{x:1602,y:771,t:1527016109296};\\\", \\\"{x:1594,y:770,t:1527016109314};\\\", \\\"{x:1585,y:769,t:1527016109330};\\\", \\\"{x:1565,y:764,t:1527016109347};\\\", \\\"{x:1545,y:759,t:1527016109364};\\\", \\\"{x:1483,y:743,t:1527016109380};\\\", \\\"{x:1393,y:726,t:1527016109397};\\\", \\\"{x:1314,y:707,t:1527016109413};\\\", \\\"{x:1249,y:697,t:1527016109430};\\\", \\\"{x:1181,y:681,t:1527016109447};\\\", \\\"{x:1130,y:674,t:1527016109464};\\\", \\\"{x:1093,y:667,t:1527016109479};\\\", \\\"{x:1071,y:662,t:1527016109497};\\\", \\\"{x:1036,y:647,t:1527016109514};\\\", \\\"{x:1020,y:640,t:1527016109530};\\\", \\\"{x:1004,y:634,t:1527016109547};\\\", \\\"{x:924,y:617,t:1527016109563};\\\", \\\"{x:879,y:606,t:1527016109581};\\\", \\\"{x:832,y:596,t:1527016109597};\\\", \\\"{x:764,y:592,t:1527016109611};\\\", \\\"{x:710,y:581,t:1527016109627};\\\", \\\"{x:661,y:565,t:1527016109645};\\\", \\\"{x:602,y:548,t:1527016109667};\\\", \\\"{x:566,y:538,t:1527016109684};\\\", \\\"{x:535,y:525,t:1527016109701};\\\", \\\"{x:508,y:520,t:1527016109717};\\\", \\\"{x:497,y:517,t:1527016109734};\\\", \\\"{x:493,y:514,t:1527016109750};\\\", \\\"{x:491,y:513,t:1527016109768};\\\", \\\"{x:490,y:513,t:1527016109783};\\\", \\\"{x:488,y:513,t:1527016109800};\\\", \\\"{x:484,y:513,t:1527016109817};\\\", \\\"{x:480,y:513,t:1527016109833};\\\", \\\"{x:469,y:512,t:1527016109850};\\\", \\\"{x:460,y:510,t:1527016109868};\\\", \\\"{x:453,y:512,t:1527016109883};\\\", \\\"{x:449,y:515,t:1527016109900};\\\", \\\"{x:440,y:515,t:1527016109918};\\\", \\\"{x:439,y:516,t:1527016109934};\\\", \\\"{x:438,y:516,t:1527016109950};\\\", \\\"{x:437,y:518,t:1527016109978};\\\", \\\"{x:436,y:519,t:1527016109986};\\\", \\\"{x:435,y:519,t:1527016110002};\\\", \\\"{x:431,y:519,t:1527016110016};\\\", \\\"{x:420,y:519,t:1527016110034};\\\", \\\"{x:404,y:519,t:1527016110051};\\\", \\\"{x:375,y:519,t:1527016110067};\\\", \\\"{x:364,y:517,t:1527016110086};\\\", \\\"{x:343,y:516,t:1527016110101};\\\", \\\"{x:331,y:515,t:1527016110117};\\\", \\\"{x:312,y:515,t:1527016110134};\\\", \\\"{x:300,y:515,t:1527016110150};\\\", \\\"{x:294,y:515,t:1527016110167};\\\", \\\"{x:293,y:515,t:1527016110185};\\\", \\\"{x:291,y:515,t:1527016110201};\\\", \\\"{x:290,y:515,t:1527016110217};\\\", \\\"{x:283,y:515,t:1527016110235};\\\", \\\"{x:277,y:513,t:1527016110251};\\\", \\\"{x:275,y:513,t:1527016110273};\\\", \\\"{x:271,y:514,t:1527016110286};\\\", \\\"{x:268,y:516,t:1527016110301};\\\", \\\"{x:258,y:516,t:1527016110317};\\\", \\\"{x:249,y:516,t:1527016110335};\\\", \\\"{x:245,y:516,t:1527016110351};\\\", \\\"{x:234,y:516,t:1527016110368};\\\", \\\"{x:229,y:516,t:1527016110385};\\\", \\\"{x:220,y:516,t:1527016110401};\\\", \\\"{x:212,y:516,t:1527016110418};\\\", \\\"{x:202,y:516,t:1527016110434};\\\", \\\"{x:201,y:516,t:1527016110458};\\\", \\\"{x:198,y:516,t:1527016110468};\\\", \\\"{x:196,y:516,t:1527016110485};\\\", \\\"{x:193,y:516,t:1527016110502};\\\", \\\"{x:187,y:516,t:1527016110519};\\\", \\\"{x:183,y:517,t:1527016110535};\\\", \\\"{x:179,y:517,t:1527016110551};\\\", \\\"{x:175,y:517,t:1527016110568};\\\", \\\"{x:171,y:517,t:1527016110585};\\\", \\\"{x:165,y:518,t:1527016110602};\\\", \\\"{x:161,y:518,t:1527016110618};\\\", \\\"{x:158,y:520,t:1527016110639};\\\", \\\"{x:157,y:520,t:1527016111786};\\\", \\\"{x:156,y:520,t:1527016111810};\\\", \\\"{x:156,y:522,t:1527016111826};\\\", \\\"{x:156,y:523,t:1527016111842};\\\", \\\"{x:155,y:523,t:1527016111853};\\\", \\\"{x:154,y:523,t:1527016112322};\\\", \\\"{x:154,y:522,t:1527016112378};\\\", \\\"{x:154,y:521,t:1527016112402};\\\", \\\"{x:155,y:520,t:1527016112420};\\\", \\\"{x:158,y:519,t:1527016112450};\\\", \\\"{x:158,y:518,t:1527016112482};\\\", \\\"{x:159,y:518,t:1527016112578};\\\", \\\"{x:161,y:517,t:1527016112594};\\\", \\\"{x:161,y:516,t:1527016112618};\\\", \\\"{x:163,y:516,t:1527016112626};\\\", \\\"{x:165,y:516,t:1527016112637};\\\", \\\"{x:185,y:516,t:1527016112654};\\\", \\\"{x:212,y:519,t:1527016112671};\\\", \\\"{x:269,y:529,t:1527016112687};\\\", \\\"{x:308,y:536,t:1527016112702};\\\", \\\"{x:345,y:546,t:1527016112720};\\\", \\\"{x:360,y:548,t:1527016112736};\\\", \\\"{x:365,y:551,t:1527016112752};\\\", \\\"{x:387,y:561,t:1527016112769};\\\", \\\"{x:396,y:566,t:1527016112786};\\\", \\\"{x:406,y:571,t:1527016112803};\\\", \\\"{x:416,y:577,t:1527016112819};\\\", \\\"{x:432,y:589,t:1527016112837};\\\", \\\"{x:456,y:603,t:1527016112852};\\\", \\\"{x:507,y:619,t:1527016112870};\\\", \\\"{x:546,y:628,t:1527016112888};\\\", \\\"{x:557,y:638,t:1527016112903};\\\", \\\"{x:562,y:639,t:1527016112919};\\\", \\\"{x:563,y:639,t:1527016112936};\\\", \\\"{x:562,y:639,t:1527016112970};\\\", \\\"{x:555,y:636,t:1527016112977};\\\", \\\"{x:550,y:635,t:1527016112987};\\\", \\\"{x:539,y:626,t:1527016113003};\\\", \\\"{x:524,y:624,t:1527016113020};\\\", \\\"{x:502,y:619,t:1527016113039};\\\", \\\"{x:486,y:611,t:1527016113054};\\\", \\\"{x:480,y:611,t:1527016113070};\\\", \\\"{x:467,y:608,t:1527016113087};\\\", \\\"{x:447,y:608,t:1527016113104};\\\", \\\"{x:434,y:605,t:1527016113120};\\\", \\\"{x:432,y:604,t:1527016113136};\\\", \\\"{x:431,y:602,t:1527016113154};\\\", \\\"{x:430,y:602,t:1527016113170};\\\", \\\"{x:430,y:601,t:1527016113194};\\\", \\\"{x:430,y:600,t:1527016113203};\\\", \\\"{x:429,y:597,t:1527016113220};\\\", \\\"{x:429,y:596,t:1527016113241};\\\", \\\"{x:429,y:594,t:1527016113255};\\\", \\\"{x:429,y:592,t:1527016113274};\\\", \\\"{x:428,y:589,t:1527016113290};\\\", \\\"{x:427,y:589,t:1527016113306};\\\", \\\"{x:426,y:587,t:1527016113321};\\\", \\\"{x:420,y:577,t:1527016113339};\\\", \\\"{x:411,y:567,t:1527016113354};\\\", \\\"{x:403,y:556,t:1527016113370};\\\", \\\"{x:396,y:549,t:1527016113386};\\\", \\\"{x:394,y:548,t:1527016113404};\\\", \\\"{x:391,y:546,t:1527016113421};\\\", \\\"{x:389,y:542,t:1527016113436};\\\", \\\"{x:387,y:542,t:1527016113453};\\\", \\\"{x:386,y:540,t:1527016113471};\\\", \\\"{x:385,y:540,t:1527016113489};\\\", \\\"{x:384,y:540,t:1527016113578};\\\", \\\"{x:384,y:539,t:1527016113588};\\\", \\\"{x:384,y:536,t:1527016113605};\\\", \\\"{x:387,y:534,t:1527016113620};\\\", \\\"{x:388,y:534,t:1527016113637};\\\", \\\"{x:389,y:532,t:1527016113715};\\\", \\\"{x:390,y:532,t:1527016113722};\\\", \\\"{x:390,y:531,t:1527016121322};\\\", \\\"{x:394,y:532,t:1527016121330};\\\", \\\"{x:397,y:533,t:1527016121344};\\\", \\\"{x:399,y:533,t:1527016121360};\\\", \\\"{x:403,y:535,t:1527016121377};\\\", \\\"{x:404,y:535,t:1527016121393};\\\", \\\"{x:405,y:537,t:1527016121410};\\\", \\\"{x:406,y:537,t:1527016121427};\\\", \\\"{x:407,y:537,t:1527016121444};\\\", \\\"{x:408,y:538,t:1527016121460};\\\", \\\"{x:409,y:538,t:1527016121477};\\\", \\\"{x:409,y:539,t:1527016121531};\\\", \\\"{x:409,y:540,t:1527016121544};\\\", \\\"{x:410,y:540,t:1527016121682};\\\", \\\"{x:410,y:541,t:1527016122682};\\\", \\\"{x:410,y:542,t:1527016127794};\\\", \\\"{x:413,y:545,t:1527016127803};\\\", \\\"{x:414,y:546,t:1527016127817};\\\", \\\"{x:417,y:549,t:1527016127833};\\\", \\\"{x:418,y:550,t:1527016127848};\\\", \\\"{x:423,y:558,t:1527016127864};\\\", \\\"{x:437,y:567,t:1527016127882};\\\", \\\"{x:442,y:573,t:1527016127897};\\\", \\\"{x:451,y:580,t:1527016127915};\\\", \\\"{x:457,y:591,t:1527016127933};\\\", \\\"{x:457,y:600,t:1527016127948};\\\", \\\"{x:465,y:611,t:1527016127965};\\\", \\\"{x:469,y:612,t:1527016127982};\\\", \\\"{x:472,y:614,t:1527016128337};\\\", \\\"{x:474,y:621,t:1527016128350};\\\", \\\"{x:479,y:640,t:1527016128364};\\\", \\\"{x:482,y:662,t:1527016128382};\\\", \\\"{x:487,y:683,t:1527016128398};\\\", \\\"{x:487,y:688,t:1527016128415};\\\", \\\"{x:491,y:696,t:1527016128432};\\\", \\\"{x:499,y:701,t:1527016128449};\\\", \\\"{x:505,y:709,t:1527016128465};\\\", \\\"{x:508,y:714,t:1527016128482};\\\", \\\"{x:515,y:723,t:1527016128499};\\\", \\\"{x:519,y:728,t:1527016128515};\\\", \\\"{x:520,y:730,t:1527016128532};\\\", \\\"{x:521,y:733,t:1527016128549};\\\", \\\"{x:521,y:734,t:1527016128585};\\\", \\\"{x:521,y:736,t:1527016128600};\\\", \\\"{x:523,y:738,t:1527016128617};\\\", \\\"{x:524,y:738,t:1527016128730};\\\", \\\"{x:525,y:734,t:1527016128739};\\\", \\\"{x:525,y:730,t:1527016128748};\\\", \\\"{x:528,y:725,t:1527016128766};\\\", \\\"{x:528,y:724,t:1527016128782};\\\", \\\"{x:528,y:720,t:1527016128799};\\\", \\\"{x:527,y:718,t:1527016128816};\\\", \\\"{x:527,y:717,t:1527016128833};\\\", \\\"{x:527,y:715,t:1527016128865};\\\", \\\"{x:526,y:715,t:1527016128873};\\\", \\\"{x:525,y:714,t:1527016128937};\\\", \\\"{x:525,y:712,t:1527016129738};\\\", \\\"{x:525,y:711,t:1527016129777};\\\", \\\"{x:525,y:710,t:1527016129786};\\\", \\\"{x:527,y:710,t:1527016129818};\\\", \\\"{x:527,y:709,t:1527016129834};\\\", \\\"{x:528,y:708,t:1527016129858};\\\", \\\"{x:528,y:707,t:1527016129868};\\\", \\\"{x:528,y:706,t:1527016129922};\\\", \\\"{x:529,y:705,t:1527016129946};\\\", \\\"{x:528,y:705,t:1527016132956};\\\", \\\"{x:526,y:706,t:1527016132980};\\\", \\\"{x:526,y:707,t:1527016133003};\\\", \\\"{x:525,y:707,t:1527016133044};\\\", \\\"{x:522,y:710,t:1527016133067};\\\", \\\"{x:520,y:710,t:1527016133092};\\\", \\\"{x:519,y:711,t:1527016133115};\\\", \\\"{x:519,y:712,t:1527016133131};\\\", \\\"{x:517,y:713,t:1527016133147};\\\", \\\"{x:517,y:714,t:1527016133163};\\\", \\\"{x:516,y:714,t:1527016133187};\\\", \\\"{x:516,y:715,t:1527016133260};\\\", \\\"{x:515,y:715,t:1527016133267};\\\", \\\"{x:514,y:716,t:1527016133284};\\\", \\\"{x:514,y:717,t:1527016133308};\\\", \\\"{x:513,y:717,t:1527016133316};\\\", \\\"{x:511,y:718,t:1527016133380};\\\", \\\"{x:512,y:719,t:1527016140484};\\\", \\\"{x:519,y:719,t:1527016140491};\\\", \\\"{x:526,y:720,t:1527016140502};\\\", \\\"{x:538,y:720,t:1527016140518};\\\", \\\"{x:547,y:720,t:1527016140535};\\\", \\\"{x:562,y:721,t:1527016140552};\\\", \\\"{x:581,y:724,t:1527016140568};\\\", \\\"{x:608,y:730,t:1527016140585};\\\", \\\"{x:631,y:736,t:1527016140602};\\\", \\\"{x:663,y:742,t:1527016140619};\\\", \\\"{x:669,y:747,t:1527016140635};\\\", \\\"{x:688,y:751,t:1527016140652};\\\", \\\"{x:692,y:751,t:1527016140669};\\\", \\\"{x:696,y:753,t:1527016140685};\\\", \\\"{x:701,y:754,t:1527016140702};\\\", \\\"{x:706,y:756,t:1527016140765};\\\", \\\"{x:707,y:756,t:1527016140783};\\\", \\\"{x:709,y:756,t:1527016140786};\\\", \\\"{x:710,y:757,t:1527016140800};\\\", \\\"{x:711,y:758,t:1527016140818};\\\", \\\"{x:713,y:758,t:1527016140858};\\\", \\\"{x:717,y:758,t:1527016140868};\\\", \\\"{x:719,y:758,t:1527016140906};\\\" ] }, { \\\"rt\\\": 30829, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 6, \\\"time_elapsed\\\": 210402, \\\"internal_node_id\\\": \\\"0.0-5.0-1.0\\\", \\\"subject\\\": \\\"6Y93F\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"foxtrot\\\", \\\"condition\\\": \\\"111\\\", \\\"scenario\\\": \\\"acme\\\", \\\"question\\\": \\\"starts\\\", \\\"q\\\": 2, \\\"clicks\\\": 1, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XInside-YFull\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 1, \\\"answer\\\": [ \\\"E\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"X \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"U \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"\\\", \\\"block\\\": \\\"triangular_scaffolded\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:722,y:758,t:1527016142324};\\\", \\\"{x:723,y:758,t:1527016142337};\\\", \\\"{x:728,y:757,t:1527016142354};\\\", \\\"{x:732,y:755,t:1527016142370};\\\", \\\"{x:742,y:751,t:1527016142387};\\\", \\\"{x:747,y:748,t:1527016142403};\\\", \\\"{x:759,y:744,t:1527016142420};\\\", \\\"{x:765,y:743,t:1527016142437};\\\", \\\"{x:781,y:739,t:1527016142453};\\\", \\\"{x:795,y:738,t:1527016142469};\\\", \\\"{x:806,y:735,t:1527016142486};\\\", \\\"{x:816,y:734,t:1527016142504};\\\", \\\"{x:824,y:734,t:1527016142519};\\\", \\\"{x:830,y:734,t:1527016142537};\\\", \\\"{x:838,y:734,t:1527016142554};\\\", \\\"{x:845,y:732,t:1527016142569};\\\", \\\"{x:852,y:730,t:1527016142586};\\\", \\\"{x:853,y:730,t:1527016142756};\\\", \\\"{x:854,y:730,t:1527016142771};\\\", \\\"{x:857,y:730,t:1527016142795};\\\", \\\"{x:860,y:730,t:1527016142804};\\\", \\\"{x:863,y:730,t:1527016142821};\\\", \\\"{x:870,y:730,t:1527016142836};\\\", \\\"{x:881,y:730,t:1527016142853};\\\", \\\"{x:884,y:730,t:1527016142870};\\\", \\\"{x:890,y:730,t:1527016142887};\\\", \\\"{x:892,y:730,t:1527016142904};\\\", \\\"{x:900,y:730,t:1527016142920};\\\", \\\"{x:906,y:730,t:1527016142937};\\\", \\\"{x:917,y:729,t:1527016142954};\\\", \\\"{x:929,y:729,t:1527016142971};\\\", \\\"{x:934,y:729,t:1527016142986};\\\", \\\"{x:936,y:729,t:1527016143003};\\\", \\\"{x:951,y:728,t:1527016143021};\\\", \\\"{x:970,y:728,t:1527016143037};\\\", \\\"{x:1004,y:725,t:1527016143055};\\\", \\\"{x:1019,y:727,t:1527016143071};\\\", \\\"{x:1036,y:727,t:1527016143087};\\\", \\\"{x:1072,y:728,t:1527016143104};\\\", \\\"{x:1083,y:730,t:1527016143121};\\\", \\\"{x:1093,y:732,t:1527016143137};\\\", \\\"{x:1104,y:735,t:1527016143154};\\\", \\\"{x:1105,y:736,t:1527016143171};\\\", \\\"{x:1106,y:737,t:1527016143195};\\\", \\\"{x:1108,y:738,t:1527016143580};\\\", \\\"{x:1112,y:740,t:1527016143587};\\\", \\\"{x:1132,y:751,t:1527016143604};\\\", \\\"{x:1141,y:755,t:1527016143621};\\\", \\\"{x:1156,y:762,t:1527016143638};\\\", \\\"{x:1231,y:786,t:1527016143654};\\\", \\\"{x:1306,y:808,t:1527016143671};\\\", \\\"{x:1386,y:830,t:1527016143689};\\\", \\\"{x:1476,y:861,t:1527016143705};\\\", \\\"{x:1518,y:876,t:1527016143721};\\\", \\\"{x:1556,y:890,t:1527016143738};\\\", \\\"{x:1578,y:898,t:1527016143754};\\\", \\\"{x:1606,y:906,t:1527016143771};\\\", \\\"{x:1614,y:907,t:1527016143787};\\\", \\\"{x:1616,y:907,t:1527016143805};\\\", \\\"{x:1617,y:908,t:1527016143821};\\\", \\\"{x:1622,y:908,t:1527016143838};\\\", \\\"{x:1625,y:908,t:1527016143855};\\\", \\\"{x:1629,y:908,t:1527016143872};\\\", \\\"{x:1634,y:908,t:1527016143887};\\\", \\\"{x:1637,y:906,t:1527016143905};\\\", \\\"{x:1639,y:905,t:1527016143921};\\\", \\\"{x:1640,y:903,t:1527016143938};\\\", \\\"{x:1640,y:902,t:1527016143956};\\\", \\\"{x:1640,y:898,t:1527016143972};\\\", \\\"{x:1636,y:895,t:1527016143987};\\\", \\\"{x:1633,y:892,t:1527016144004};\\\", \\\"{x:1630,y:890,t:1527016144020};\\\", \\\"{x:1627,y:888,t:1527016144038};\\\", \\\"{x:1626,y:887,t:1527016144055};\\\", \\\"{x:1624,y:886,t:1527016144070};\\\", \\\"{x:1618,y:883,t:1527016144087};\\\", \\\"{x:1616,y:882,t:1527016144104};\\\", \\\"{x:1613,y:880,t:1527016144121};\\\", \\\"{x:1606,y:879,t:1527016144137};\\\", \\\"{x:1601,y:876,t:1527016144154};\\\", \\\"{x:1598,y:873,t:1527016144171};\\\", \\\"{x:1595,y:871,t:1527016144188};\\\", \\\"{x:1594,y:870,t:1527016144205};\\\", \\\"{x:1593,y:868,t:1527016144227};\\\", \\\"{x:1592,y:868,t:1527016144238};\\\", \\\"{x:1592,y:867,t:1527016144255};\\\", \\\"{x:1592,y:863,t:1527016144272};\\\", \\\"{x:1592,y:857,t:1527016144288};\\\", \\\"{x:1593,y:848,t:1527016144306};\\\", \\\"{x:1594,y:845,t:1527016144322};\\\", \\\"{x:1594,y:841,t:1527016144338};\\\", \\\"{x:1596,y:838,t:1527016144355};\\\", \\\"{x:1596,y:837,t:1527016144483};\\\", \\\"{x:1596,y:834,t:1527016144530};\\\", \\\"{x:1590,y:832,t:1527016144539};\\\", \\\"{x:1580,y:823,t:1527016144555};\\\", \\\"{x:1567,y:818,t:1527016144571};\\\", \\\"{x:1554,y:817,t:1527016144588};\\\", \\\"{x:1553,y:816,t:1527016144604};\\\", \\\"{x:1550,y:811,t:1527016144621};\\\", \\\"{x:1545,y:801,t:1527016144639};\\\", \\\"{x:1540,y:795,t:1527016144654};\\\", \\\"{x:1529,y:780,t:1527016144672};\\\", \\\"{x:1514,y:768,t:1527016144689};\\\", \\\"{x:1495,y:757,t:1527016144704};\\\", \\\"{x:1493,y:754,t:1527016144722};\\\", \\\"{x:1491,y:751,t:1527016145411};\\\", \\\"{x:1487,y:747,t:1527016145422};\\\", \\\"{x:1482,y:737,t:1527016145439};\\\", \\\"{x:1476,y:726,t:1527016145456};\\\", \\\"{x:1466,y:711,t:1527016145472};\\\", \\\"{x:1455,y:687,t:1527016145489};\\\", \\\"{x:1443,y:663,t:1527016145506};\\\", \\\"{x:1435,y:650,t:1527016145521};\\\", \\\"{x:1430,y:642,t:1527016145540};\\\", \\\"{x:1428,y:636,t:1527016145556};\\\", \\\"{x:1426,y:631,t:1527016145571};\\\", \\\"{x:1425,y:629,t:1527016145589};\\\", \\\"{x:1424,y:628,t:1527016145606};\\\", \\\"{x:1421,y:627,t:1527016145623};\\\", \\\"{x:1418,y:623,t:1527016145639};\\\", \\\"{x:1415,y:619,t:1527016145659};\\\", \\\"{x:1412,y:616,t:1527016145673};\\\", \\\"{x:1409,y:614,t:1527016145689};\\\", \\\"{x:1408,y:612,t:1527016145706};\\\", \\\"{x:1405,y:607,t:1527016145723};\\\", \\\"{x:1404,y:607,t:1527016145739};\\\", \\\"{x:1404,y:606,t:1527016145756};\\\", \\\"{x:1404,y:603,t:1527016145867};\\\", \\\"{x:1404,y:601,t:1527016145876};\\\", \\\"{x:1401,y:600,t:1527016145888};\\\", \\\"{x:1398,y:597,t:1527016145905};\\\", \\\"{x:1390,y:591,t:1527016145922};\\\", \\\"{x:1388,y:590,t:1527016145939};\\\", \\\"{x:1382,y:584,t:1527016145955};\\\", \\\"{x:1380,y:581,t:1527016145972};\\\", \\\"{x:1380,y:580,t:1527016146059};\\\", \\\"{x:1380,y:575,t:1527016146072};\\\", \\\"{x:1380,y:573,t:1527016146089};\\\", \\\"{x:1382,y:570,t:1527016146106};\\\", \\\"{x:1385,y:565,t:1527016146122};\\\", \\\"{x:1388,y:563,t:1527016146139};\\\", \\\"{x:1392,y:558,t:1527016146156};\\\", \\\"{x:1399,y:553,t:1527016146172};\\\", \\\"{x:1403,y:549,t:1527016146189};\\\", \\\"{x:1408,y:539,t:1527016146205};\\\", \\\"{x:1412,y:533,t:1527016146223};\\\", \\\"{x:1416,y:529,t:1527016146240};\\\", \\\"{x:1419,y:526,t:1527016146255};\\\", \\\"{x:1421,y:524,t:1527016146273};\\\", \\\"{x:1423,y:523,t:1527016146356};\\\", \\\"{x:1424,y:522,t:1527016146451};\\\", \\\"{x:1424,y:520,t:1527016146459};\\\", \\\"{x:1425,y:519,t:1527016146473};\\\", \\\"{x:1425,y:517,t:1527016146490};\\\", \\\"{x:1427,y:515,t:1527016146506};\\\", \\\"{x:1428,y:513,t:1527016146700};\\\", \\\"{x:1429,y:512,t:1527016146740};\\\", \\\"{x:1431,y:508,t:1527016146771};\\\", \\\"{x:1431,y:507,t:1527016146787};\\\", \\\"{x:1432,y:506,t:1527016146819};\\\", \\\"{x:1433,y:505,t:1527016146827};\\\", \\\"{x:1434,y:504,t:1527016146843};\\\", \\\"{x:1434,y:503,t:1527016146857};\\\", \\\"{x:1435,y:500,t:1527016146874};\\\", \\\"{x:1435,y:499,t:1527016146890};\\\", \\\"{x:1435,y:498,t:1527016146924};\\\", \\\"{x:1434,y:498,t:1527016148612};\\\", \\\"{x:1432,y:498,t:1527016148625};\\\", \\\"{x:1428,y:498,t:1527016148641};\\\", \\\"{x:1426,y:499,t:1527016148658};\\\", \\\"{x:1425,y:499,t:1527016148700};\\\", \\\"{x:1424,y:499,t:1527016148708};\\\", \\\"{x:1421,y:500,t:1527016148732};\\\", \\\"{x:1420,y:501,t:1527016148741};\\\", \\\"{x:1415,y:503,t:1527016148758};\\\", \\\"{x:1407,y:508,t:1527016148775};\\\", \\\"{x:1396,y:512,t:1527016148792};\\\", \\\"{x:1386,y:518,t:1527016148808};\\\", \\\"{x:1380,y:522,t:1527016148825};\\\", \\\"{x:1361,y:534,t:1527016148842};\\\", \\\"{x:1347,y:547,t:1527016148858};\\\", \\\"{x:1342,y:552,t:1527016148875};\\\", \\\"{x:1326,y:561,t:1527016148892};\\\", \\\"{x:1319,y:561,t:1527016148908};\\\", \\\"{x:1310,y:563,t:1527016148926};\\\", \\\"{x:1303,y:567,t:1527016148942};\\\", \\\"{x:1286,y:573,t:1527016148958};\\\", \\\"{x:1258,y:585,t:1527016148976};\\\", \\\"{x:1230,y:597,t:1527016148992};\\\", \\\"{x:1219,y:606,t:1527016149008};\\\", \\\"{x:1202,y:613,t:1527016149025};\\\", \\\"{x:1183,y:621,t:1527016149042};\\\", \\\"{x:1160,y:627,t:1527016149058};\\\", \\\"{x:1125,y:643,t:1527016149075};\\\", \\\"{x:1103,y:643,t:1527016149092};\\\", \\\"{x:1091,y:646,t:1527016149108};\\\", \\\"{x:1083,y:651,t:1527016149125};\\\", \\\"{x:1060,y:659,t:1527016149142};\\\", \\\"{x:996,y:663,t:1527016149158};\\\", \\\"{x:919,y:673,t:1527016149176};\\\", \\\"{x:814,y:682,t:1527016149192};\\\", \\\"{x:765,y:689,t:1527016149208};\\\", \\\"{x:715,y:698,t:1527016149225};\\\", \\\"{x:655,y:700,t:1527016149242};\\\", \\\"{x:617,y:698,t:1527016149258};\\\", \\\"{x:607,y:697,t:1527016149275};\\\", \\\"{x:586,y:697,t:1527016149292};\\\", \\\"{x:576,y:696,t:1527016149309};\\\", \\\"{x:571,y:694,t:1527016149325};\\\", \\\"{x:562,y:694,t:1527016149342};\\\", \\\"{x:547,y:694,t:1527016149359};\\\", \\\"{x:539,y:694,t:1527016149375};\\\", \\\"{x:533,y:691,t:1527016149391};\\\", \\\"{x:523,y:693,t:1527016149408};\\\", \\\"{x:504,y:688,t:1527016149425};\\\", \\\"{x:471,y:681,t:1527016149442};\\\", \\\"{x:416,y:658,t:1527016149460};\\\", \\\"{x:383,y:645,t:1527016149477};\\\", \\\"{x:354,y:628,t:1527016149492};\\\", \\\"{x:342,y:619,t:1527016149509};\\\", \\\"{x:333,y:613,t:1527016149521};\\\", \\\"{x:315,y:601,t:1527016149538};\\\", \\\"{x:289,y:594,t:1527016149555};\\\", \\\"{x:260,y:585,t:1527016149577};\\\", \\\"{x:248,y:580,t:1527016149592};\\\", \\\"{x:241,y:574,t:1527016149609};\\\", \\\"{x:231,y:569,t:1527016149626};\\\", \\\"{x:223,y:565,t:1527016149642};\\\", \\\"{x:221,y:564,t:1527016149658};\\\", \\\"{x:219,y:562,t:1527016149676};\\\", \\\"{x:218,y:561,t:1527016149692};\\\", \\\"{x:217,y:560,t:1527016149709};\\\", \\\"{x:215,y:558,t:1527016149725};\\\", \\\"{x:212,y:558,t:1527016149742};\\\", \\\"{x:210,y:558,t:1527016149763};\\\", \\\"{x:209,y:558,t:1527016149786};\\\", \\\"{x:208,y:558,t:1527016149963};\\\", \\\"{x:206,y:559,t:1527016149976};\\\", \\\"{x:200,y:563,t:1527016149993};\\\", \\\"{x:196,y:565,t:1527016150009};\\\", \\\"{x:192,y:572,t:1527016150026};\\\", \\\"{x:188,y:587,t:1527016150045};\\\", \\\"{x:184,y:595,t:1527016150058};\\\", \\\"{x:183,y:598,t:1527016150076};\\\", \\\"{x:182,y:606,t:1527016150093};\\\", \\\"{x:180,y:610,t:1527016150109};\\\", \\\"{x:179,y:616,t:1527016150126};\\\", \\\"{x:175,y:624,t:1527016150143};\\\", \\\"{x:175,y:627,t:1527016150158};\\\", \\\"{x:174,y:629,t:1527016150175};\\\", \\\"{x:173,y:629,t:1527016150387};\\\", \\\"{x:170,y:629,t:1527016150475};\\\", \\\"{x:166,y:631,t:1527016150494};\\\", \\\"{x:161,y:633,t:1527016150510};\\\", \\\"{x:157,y:635,t:1527016150526};\\\", \\\"{x:155,y:636,t:1527016150543};\\\", \\\"{x:154,y:636,t:1527016150571};\\\", \\\"{x:157,y:636,t:1527016151059};\\\", \\\"{x:163,y:635,t:1527016151077};\\\", \\\"{x:165,y:633,t:1527016151094};\\\", \\\"{x:170,y:628,t:1527016151110};\\\", \\\"{x:186,y:622,t:1527016151128};\\\", \\\"{x:213,y:616,t:1527016151145};\\\", \\\"{x:228,y:611,t:1527016151160};\\\", \\\"{x:310,y:613,t:1527016151177};\\\", \\\"{x:422,y:617,t:1527016151194};\\\", \\\"{x:534,y:613,t:1527016151210};\\\", \\\"{x:622,y:605,t:1527016151228};\\\", \\\"{x:714,y:606,t:1527016151244};\\\", \\\"{x:798,y:619,t:1527016151261};\\\", \\\"{x:849,y:622,t:1527016151277};\\\", \\\"{x:921,y:631,t:1527016151294};\\\", \\\"{x:944,y:636,t:1527016151310};\\\", \\\"{x:959,y:637,t:1527016151327};\\\", \\\"{x:966,y:639,t:1527016151344};\\\", \\\"{x:970,y:639,t:1527016151360};\\\", \\\"{x:971,y:639,t:1527016151376};\\\", \\\"{x:972,y:639,t:1527016151394};\\\", \\\"{x:973,y:639,t:1527016151410};\\\", \\\"{x:979,y:639,t:1527016151427};\\\", \\\"{x:981,y:639,t:1527016151445};\\\", \\\"{x:983,y:639,t:1527016151462};\\\", \\\"{x:985,y:640,t:1527016151477};\\\", \\\"{x:989,y:641,t:1527016151494};\\\", \\\"{x:991,y:641,t:1527016151511};\\\", \\\"{x:993,y:642,t:1527016151527};\\\", \\\"{x:994,y:642,t:1527016151544};\\\", \\\"{x:995,y:642,t:1527016151571};\\\", \\\"{x:996,y:642,t:1527016151788};\\\", \\\"{x:996,y:643,t:1527016151795};\\\", \\\"{x:993,y:644,t:1527016151811};\\\", \\\"{x:990,y:647,t:1527016151827};\\\", \\\"{x:984,y:647,t:1527016151844};\\\", \\\"{x:983,y:648,t:1527016151861};\\\", \\\"{x:982,y:649,t:1527016151891};\\\", \\\"{x:978,y:650,t:1527016151899};\\\", \\\"{x:977,y:650,t:1527016151915};\\\", \\\"{x:975,y:650,t:1527016151927};\\\", \\\"{x:969,y:651,t:1527016151944};\\\", \\\"{x:966,y:652,t:1527016151961};\\\", \\\"{x:965,y:652,t:1527016151978};\\\", \\\"{x:961,y:652,t:1527016151994};\\\", \\\"{x:955,y:652,t:1527016152011};\\\", \\\"{x:947,y:652,t:1527016152028};\\\", \\\"{x:941,y:652,t:1527016152044};\\\", \\\"{x:937,y:652,t:1527016152061};\\\", \\\"{x:934,y:652,t:1527016152078};\\\", \\\"{x:932,y:652,t:1527016152107};\\\", \\\"{x:931,y:652,t:1527016152123};\\\", \\\"{x:927,y:652,t:1527016152179};\\\", \\\"{x:924,y:652,t:1527016152194};\\\", \\\"{x:917,y:652,t:1527016152211};\\\", \\\"{x:916,y:652,t:1527016152228};\\\", \\\"{x:910,y:651,t:1527016152244};\\\", \\\"{x:909,y:651,t:1527016152261};\\\", \\\"{x:904,y:651,t:1527016152278};\\\", \\\"{x:899,y:651,t:1527016152294};\\\", \\\"{x:895,y:651,t:1527016152311};\\\", \\\"{x:893,y:652,t:1527016152328};\\\", \\\"{x:888,y:652,t:1527016152345};\\\", \\\"{x:886,y:652,t:1527016152361};\\\", \\\"{x:881,y:652,t:1527016152378};\\\", \\\"{x:878,y:652,t:1527016152395};\\\", \\\"{x:875,y:652,t:1527016152411};\\\", \\\"{x:873,y:652,t:1527016152428};\\\", \\\"{x:871,y:653,t:1527016152445};\\\", \\\"{x:866,y:654,t:1527016152461};\\\", \\\"{x:860,y:654,t:1527016152478};\\\", \\\"{x:855,y:654,t:1527016152495};\\\", \\\"{x:850,y:654,t:1527016152511};\\\", \\\"{x:849,y:653,t:1527016152528};\\\", \\\"{x:848,y:653,t:1527016152545};\\\", \\\"{x:846,y:653,t:1527016152659};\\\", \\\"{x:844,y:653,t:1527016152667};\\\", \\\"{x:841,y:652,t:1527016152691};\\\", \\\"{x:839,y:652,t:1527016152811};\\\", \\\"{x:838,y:652,t:1527016152828};\\\", \\\"{x:837,y:652,t:1527016152845};\\\", \\\"{x:836,y:652,t:1527016152996};\\\", \\\"{x:835,y:652,t:1527016153012};\\\", \\\"{x:833,y:652,t:1527016153028};\\\", \\\"{x:831,y:651,t:1527016153045};\\\", \\\"{x:829,y:651,t:1527016153075};\\\", \\\"{x:828,y:651,t:1527016153099};\\\", \\\"{x:826,y:651,t:1527016153139};\\\", \\\"{x:825,y:651,t:1527016153147};\\\", \\\"{x:822,y:651,t:1527016153162};\\\", \\\"{x:815,y:651,t:1527016153179};\\\", \\\"{x:809,y:651,t:1527016153195};\\\", \\\"{x:804,y:649,t:1527016153212};\\\", \\\"{x:798,y:649,t:1527016153229};\\\", \\\"{x:795,y:648,t:1527016153245};\\\", \\\"{x:794,y:648,t:1527016153262};\\\", \\\"{x:792,y:648,t:1527016153555};\\\", \\\"{x:790,y:648,t:1527016153587};\\\", \\\"{x:788,y:648,t:1527016153603};\\\", \\\"{x:787,y:648,t:1527016153619};\\\", \\\"{x:784,y:648,t:1527016153629};\\\", \\\"{x:782,y:648,t:1527016153646};\\\", \\\"{x:780,y:648,t:1527016153732};\\\", \\\"{x:779,y:648,t:1527016153746};\\\", \\\"{x:778,y:648,t:1527016153771};\\\", \\\"{x:777,y:648,t:1527016153794};\\\", \\\"{x:775,y:648,t:1527016153811};\\\", \\\"{x:774,y:648,t:1527016153826};\\\", \\\"{x:773,y:648,t:1527016153835};\\\", \\\"{x:772,y:648,t:1527016153846};\\\", \\\"{x:771,y:648,t:1527016153899};\\\", \\\"{x:770,y:648,t:1527016153912};\\\", \\\"{x:769,y:648,t:1527016153929};\\\", \\\"{x:767,y:648,t:1527016153947};\\\", \\\"{x:764,y:648,t:1527016153963};\\\", \\\"{x:761,y:648,t:1527016153979};\\\", \\\"{x:760,y:648,t:1527016153996};\\\", \\\"{x:759,y:648,t:1527016154075};\\\", \\\"{x:757,y:648,t:1527016154083};\\\", \\\"{x:757,y:647,t:1527016154115};\\\", \\\"{x:755,y:647,t:1527016154138};\\\", \\\"{x:753,y:647,t:1527016154146};\\\", \\\"{x:752,y:646,t:1527016154163};\\\", \\\"{x:751,y:646,t:1527016154186};\\\", \\\"{x:749,y:646,t:1527016159715};\\\", \\\"{x:747,y:646,t:1527016159803};\\\", \\\"{x:745,y:646,t:1527016159817};\\\", \\\"{x:739,y:648,t:1527016159834};\\\", \\\"{x:732,y:651,t:1527016159851};\\\", \\\"{x:730,y:652,t:1527016159867};\\\", \\\"{x:726,y:652,t:1527016159885};\\\", \\\"{x:724,y:652,t:1527016159900};\\\", \\\"{x:722,y:651,t:1527016159918};\\\", \\\"{x:722,y:650,t:1527016160026};\\\", \\\"{x:721,y:650,t:1527016160747};\\\", \\\"{x:719,y:650,t:1527016160762};\\\", \\\"{x:718,y:650,t:1527016160770};\\\", \\\"{x:717,y:650,t:1527016160794};\\\", \\\"{x:716,y:650,t:1527016160818};\\\", \\\"{x:715,y:650,t:1527016160833};\\\", \\\"{x:713,y:650,t:1527016160978};\\\", \\\"{x:712,y:650,t:1527016160994};\\\", \\\"{x:710,y:650,t:1527016161011};\\\", \\\"{x:709,y:650,t:1527016161323};\\\", \\\"{x:707,y:649,t:1527016161335};\\\", \\\"{x:706,y:649,t:1527016161354};\\\", \\\"{x:705,y:649,t:1527016162043};\\\", \\\"{x:704,y:649,t:1527016162059};\\\", \\\"{x:703,y:649,t:1527016162075};\\\", \\\"{x:701,y:649,t:1527016162098};\\\", \\\"{x:700,y:649,t:1527016162130};\\\", \\\"{x:699,y:649,t:1527016162275};\\\", \\\"{x:697,y:649,t:1527016162298};\\\", \\\"{x:696,y:649,t:1527016162314};\\\", \\\"{x:694,y:649,t:1527016163427};\\\", \\\"{x:692,y:649,t:1527016164507};\\\", \\\"{x:691,y:649,t:1527016164522};\\\", \\\"{x:687,y:650,t:1527016164538};\\\", \\\"{x:671,y:657,t:1527016164556};\\\", \\\"{x:632,y:663,t:1527016164571};\\\", \\\"{x:590,y:665,t:1527016164587};\\\", \\\"{x:562,y:668,t:1527016164604};\\\", \\\"{x:546,y:668,t:1527016164620};\\\", \\\"{x:543,y:668,t:1527016164637};\\\", \\\"{x:541,y:668,t:1527016164843};\\\", \\\"{x:540,y:668,t:1527016164859};\\\", \\\"{x:538,y:670,t:1527016165306};\\\", \\\"{x:537,y:671,t:1527016165322};\\\", \\\"{x:535,y:676,t:1527016165363};\\\", \\\"{x:532,y:679,t:1527016165379};\\\", \\\"{x:531,y:681,t:1527016165389};\\\", \\\"{x:528,y:685,t:1527016165404};\\\", \\\"{x:524,y:689,t:1527016165422};\\\", \\\"{x:523,y:692,t:1527016165438};\\\", \\\"{x:522,y:694,t:1527016165454};\\\", \\\"{x:519,y:696,t:1527016165472};\\\", \\\"{x:515,y:699,t:1527016165488};\\\", \\\"{x:515,y:700,t:1527016165539};\\\", \\\"{x:515,y:701,t:1527016165564};\\\", \\\"{x:514,y:702,t:1527016165572};\\\", \\\"{x:512,y:704,t:1527016165588};\\\", \\\"{x:508,y:710,t:1527016165605};\\\", \\\"{x:500,y:718,t:1527016165621};\\\", \\\"{x:482,y:737,t:1527016165639};\\\", \\\"{x:467,y:756,t:1527016165655};\\\", \\\"{x:466,y:757,t:1527016165671};\\\", \\\"{x:466,y:755,t:1527016165947};\\\", \\\"{x:467,y:753,t:1527016165955};\\\", \\\"{x:469,y:748,t:1527016165973};\\\", \\\"{x:471,y:745,t:1527016165988};\\\", \\\"{x:472,y:744,t:1527016166005};\\\", \\\"{x:472,y:742,t:1527016166022};\\\", \\\"{x:475,y:740,t:1527016166038};\\\", \\\"{x:477,y:738,t:1527016166055};\\\", \\\"{x:479,y:736,t:1527016166072};\\\", \\\"{x:481,y:733,t:1527016166089};\\\", \\\"{x:482,y:729,t:1527016166105};\\\", \\\"{x:484,y:726,t:1527016166122};\\\", \\\"{x:485,y:725,t:1527016166138};\\\", \\\"{x:486,y:725,t:1527016166162};\\\", \\\"{x:486,y:724,t:1527016166179};\\\" ] }, { \\\"rt\\\": 43190, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 7, \\\"time_elapsed\\\": 254865, \\\"internal_node_id\\\": \\\"0.0-5.0-2.0\\\", \\\"subject\\\": \\\"6Y93F\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"foxtrot\\\", \\\"condition\\\": \\\"111\\\", \\\"scenario\\\": \\\"acme\\\", \\\"question\\\": \\\"meets\\\", \\\"q\\\": 3, \\\"clicks\\\": 1, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XInside-YFull\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 1, \\\"answer\\\": [ \\\"Z\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"X \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"U \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-H -F -F -C \\\", \\\"block\\\": \\\"triangular_scaffolded\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:487,y:724,t:1527016173675};\\\", \\\"{x:497,y:724,t:1527016173760};\\\", \\\"{x:498,y:724,t:1527016173768};\\\", \\\"{x:500,y:724,t:1527016173777};\\\", \\\"{x:528,y:728,t:1527016173794};\\\", \\\"{x:550,y:729,t:1527016173812};\\\", \\\"{x:582,y:730,t:1527016173828};\\\", \\\"{x:613,y:730,t:1527016173845};\\\", \\\"{x:640,y:731,t:1527016173861};\\\", \\\"{x:663,y:735,t:1527016173877};\\\", \\\"{x:678,y:737,t:1527016173896};\\\", \\\"{x:686,y:737,t:1527016173912};\\\", \\\"{x:688,y:737,t:1527016173927};\\\", \\\"{x:690,y:737,t:1527016173945};\\\", \\\"{x:691,y:737,t:1527016173961};\\\", \\\"{x:692,y:737,t:1527016173978};\\\", \\\"{x:694,y:737,t:1527016173994};\\\", \\\"{x:695,y:737,t:1527016174042};\\\", \\\"{x:696,y:737,t:1527016174050};\\\", \\\"{x:698,y:737,t:1527016174062};\\\", \\\"{x:705,y:739,t:1527016174078};\\\", \\\"{x:716,y:740,t:1527016174094};\\\", \\\"{x:728,y:741,t:1527016174111};\\\", \\\"{x:738,y:741,t:1527016174128};\\\", \\\"{x:763,y:742,t:1527016174145};\\\", \\\"{x:770,y:742,t:1527016174162};\\\", \\\"{x:803,y:746,t:1527016174179};\\\", \\\"{x:810,y:746,t:1527016174195};\\\", \\\"{x:817,y:745,t:1527016174212};\\\", \\\"{x:827,y:745,t:1527016174229};\\\", \\\"{x:844,y:750,t:1527016174245};\\\", \\\"{x:862,y:755,t:1527016174262};\\\", \\\"{x:883,y:757,t:1527016174278};\\\", \\\"{x:908,y:761,t:1527016174294};\\\", \\\"{x:938,y:762,t:1527016174312};\\\", \\\"{x:992,y:762,t:1527016174330};\\\", \\\"{x:1078,y:762,t:1527016174345};\\\", \\\"{x:1170,y:762,t:1527016174362};\\\", \\\"{x:1286,y:763,t:1527016174379};\\\", \\\"{x:1393,y:756,t:1527016174395};\\\", \\\"{x:1513,y:752,t:1527016174411};\\\", \\\"{x:1618,y:753,t:1527016174429};\\\", \\\"{x:1713,y:753,t:1527016174445};\\\", \\\"{x:1801,y:760,t:1527016174462};\\\", \\\"{x:1838,y:761,t:1527016174479};\\\", \\\"{x:1853,y:761,t:1527016174495};\\\", \\\"{x:1857,y:761,t:1527016174512};\\\", \\\"{x:1863,y:756,t:1527016174529};\\\", \\\"{x:1869,y:753,t:1527016174545};\\\", \\\"{x:1872,y:750,t:1527016174562};\\\", \\\"{x:1878,y:748,t:1527016174579};\\\", \\\"{x:1879,y:746,t:1527016174595};\\\", \\\"{x:1882,y:744,t:1527016174612};\\\", \\\"{x:1884,y:744,t:1527016174629};\\\", \\\"{x:1887,y:743,t:1527016174645};\\\", \\\"{x:1891,y:741,t:1527016174662};\\\", \\\"{x:1895,y:740,t:1527016174678};\\\", \\\"{x:1903,y:738,t:1527016174695};\\\", \\\"{x:1907,y:735,t:1527016174712};\\\", \\\"{x:1912,y:732,t:1527016174729};\\\", \\\"{x:1915,y:729,t:1527016174747};\\\", \\\"{x:1919,y:719,t:1527016174762};\\\", \\\"{x:1919,y:699,t:1527016174779};\\\", \\\"{x:1919,y:689,t:1527016174796};\\\", \\\"{x:1919,y:682,t:1527016174813};\\\", \\\"{x:1919,y:681,t:1527016174829};\\\", \\\"{x:1919,y:678,t:1527016174851};\\\", \\\"{x:1919,y:676,t:1527016174883};\\\", \\\"{x:1915,y:675,t:1527016174896};\\\", \\\"{x:1904,y:672,t:1527016174912};\\\", \\\"{x:1884,y:670,t:1527016174929};\\\", \\\"{x:1876,y:669,t:1527016174946};\\\", \\\"{x:1865,y:666,t:1527016174962};\\\", \\\"{x:1855,y:666,t:1527016174980};\\\", \\\"{x:1834,y:666,t:1527016174996};\\\", \\\"{x:1822,y:666,t:1527016175013};\\\", \\\"{x:1813,y:666,t:1527016175030};\\\", \\\"{x:1802,y:666,t:1527016175046};\\\", \\\"{x:1796,y:666,t:1527016175063};\\\", \\\"{x:1789,y:666,t:1527016175079};\\\", \\\"{x:1772,y:666,t:1527016175096};\\\", \\\"{x:1766,y:666,t:1527016175113};\\\", \\\"{x:1764,y:666,t:1527016175129};\\\", \\\"{x:1760,y:666,t:1527016175146};\\\", \\\"{x:1754,y:666,t:1527016175163};\\\", \\\"{x:1749,y:666,t:1527016175180};\\\", \\\"{x:1747,y:666,t:1527016175196};\\\", \\\"{x:1739,y:666,t:1527016175213};\\\", \\\"{x:1723,y:666,t:1527016175229};\\\", \\\"{x:1718,y:666,t:1527016175245};\\\", \\\"{x:1715,y:664,t:1527016175262};\\\", \\\"{x:1711,y:664,t:1527016175279};\\\", \\\"{x:1705,y:664,t:1527016175295};\\\", \\\"{x:1694,y:662,t:1527016175312};\\\", \\\"{x:1689,y:660,t:1527016175330};\\\", \\\"{x:1682,y:659,t:1527016175346};\\\", \\\"{x:1665,y:658,t:1527016175362};\\\", \\\"{x:1658,y:658,t:1527016175380};\\\", \\\"{x:1638,y:658,t:1527016175396};\\\", \\\"{x:1623,y:658,t:1527016175413};\\\", \\\"{x:1614,y:658,t:1527016175430};\\\", \\\"{x:1600,y:653,t:1527016175446};\\\", \\\"{x:1587,y:653,t:1527016175463};\\\", \\\"{x:1586,y:653,t:1527016175483};\\\", \\\"{x:1584,y:652,t:1527016175496};\\\", \\\"{x:1584,y:651,t:1527016175515};\\\", \\\"{x:1583,y:651,t:1527016175530};\\\", \\\"{x:1583,y:650,t:1527016175547};\\\", \\\"{x:1580,y:649,t:1527016175563};\\\", \\\"{x:1575,y:646,t:1527016175580};\\\", \\\"{x:1572,y:644,t:1527016175597};\\\", \\\"{x:1568,y:644,t:1527016175613};\\\", \\\"{x:1565,y:643,t:1527016175630};\\\", \\\"{x:1565,y:644,t:1527016176411};\\\", \\\"{x:1565,y:646,t:1527016176418};\\\", \\\"{x:1565,y:648,t:1527016176431};\\\", \\\"{x:1565,y:650,t:1527016176447};\\\", \\\"{x:1566,y:653,t:1527016176490};\\\", \\\"{x:1566,y:654,t:1527016176523};\\\", \\\"{x:1566,y:655,t:1527016176539};\\\", \\\"{x:1566,y:656,t:1527016176547};\\\", \\\"{x:1568,y:657,t:1527016176675};\\\", \\\"{x:1569,y:657,t:1527016176739};\\\", \\\"{x:1569,y:653,t:1527016177259};\\\", \\\"{x:1568,y:648,t:1527016177267};\\\", \\\"{x:1568,y:644,t:1527016177281};\\\", \\\"{x:1576,y:623,t:1527016177298};\\\", \\\"{x:1579,y:615,t:1527016177315};\\\", \\\"{x:1581,y:614,t:1527016177339};\\\", \\\"{x:1581,y:613,t:1527016177355};\\\", \\\"{x:1581,y:612,t:1527016177387};\\\", \\\"{x:1580,y:610,t:1527016177459};\\\", \\\"{x:1579,y:610,t:1527016177466};\\\", \\\"{x:1577,y:609,t:1527016177480};\\\", \\\"{x:1575,y:609,t:1527016177497};\\\", \\\"{x:1572,y:609,t:1527016177515};\\\", \\\"{x:1571,y:609,t:1527016177531};\\\", \\\"{x:1569,y:608,t:1527016177570};\\\", \\\"{x:1568,y:608,t:1527016177610};\\\", \\\"{x:1566,y:608,t:1527016177618};\\\", \\\"{x:1565,y:608,t:1527016177632};\\\", \\\"{x:1563,y:608,t:1527016177650};\\\", \\\"{x:1561,y:608,t:1527016177665};\\\", \\\"{x:1556,y:608,t:1527016177681};\\\", \\\"{x:1546,y:607,t:1527016177698};\\\", \\\"{x:1540,y:606,t:1527016177714};\\\", \\\"{x:1538,y:606,t:1527016177732};\\\", \\\"{x:1533,y:605,t:1527016177748};\\\", \\\"{x:1529,y:604,t:1527016177765};\\\", \\\"{x:1526,y:602,t:1527016177782};\\\", \\\"{x:1521,y:599,t:1527016177797};\\\", \\\"{x:1511,y:592,t:1527016177815};\\\", \\\"{x:1498,y:585,t:1527016177832};\\\", \\\"{x:1482,y:580,t:1527016177849};\\\", \\\"{x:1468,y:575,t:1527016177865};\\\", \\\"{x:1447,y:567,t:1527016177882};\\\", \\\"{x:1435,y:564,t:1527016177898};\\\", \\\"{x:1420,y:559,t:1527016177915};\\\", \\\"{x:1412,y:555,t:1527016177932};\\\", \\\"{x:1408,y:554,t:1527016177949};\\\", \\\"{x:1405,y:552,t:1527016177966};\\\", \\\"{x:1402,y:552,t:1527016177981};\\\", \\\"{x:1394,y:547,t:1527016177999};\\\", \\\"{x:1393,y:546,t:1527016178014};\\\", \\\"{x:1387,y:543,t:1527016178031};\\\", \\\"{x:1380,y:539,t:1527016178049};\\\", \\\"{x:1366,y:536,t:1527016178064};\\\", \\\"{x:1345,y:533,t:1527016178082};\\\", \\\"{x:1336,y:530,t:1527016178097};\\\", \\\"{x:1335,y:529,t:1527016178115};\\\", \\\"{x:1334,y:529,t:1527016178131};\\\", \\\"{x:1334,y:528,t:1527016178308};\\\", \\\"{x:1335,y:525,t:1527016178315};\\\", \\\"{x:1338,y:524,t:1527016178332};\\\", \\\"{x:1339,y:523,t:1527016178349};\\\", \\\"{x:1345,y:518,t:1527016178364};\\\", \\\"{x:1347,y:516,t:1527016178381};\\\", \\\"{x:1349,y:516,t:1527016178398};\\\", \\\"{x:1351,y:515,t:1527016178414};\\\", \\\"{x:1352,y:514,t:1527016178700};\\\", \\\"{x:1352,y:512,t:1527016178717};\\\", \\\"{x:1353,y:511,t:1527016178732};\\\", \\\"{x:1358,y:509,t:1527016178749};\\\", \\\"{x:1364,y:508,t:1527016178766};\\\", \\\"{x:1370,y:508,t:1527016178782};\\\", \\\"{x:1374,y:508,t:1527016178799};\\\", \\\"{x:1375,y:508,t:1527016178816};\\\", \\\"{x:1378,y:508,t:1527016178833};\\\", \\\"{x:1379,y:506,t:1527016178891};\\\", \\\"{x:1381,y:504,t:1527016178898};\\\", \\\"{x:1388,y:497,t:1527016178916};\\\", \\\"{x:1397,y:490,t:1527016178933};\\\", \\\"{x:1406,y:482,t:1527016178948};\\\", \\\"{x:1419,y:463,t:1527016178966};\\\", \\\"{x:1423,y:456,t:1527016178983};\\\", \\\"{x:1428,y:450,t:1527016178999};\\\", \\\"{x:1432,y:441,t:1527016179016};\\\", \\\"{x:1432,y:439,t:1527016179033};\\\", \\\"{x:1436,y:430,t:1527016179049};\\\", \\\"{x:1440,y:421,t:1527016179066};\\\", \\\"{x:1442,y:416,t:1527016179082};\\\", \\\"{x:1443,y:415,t:1527016179099};\\\", \\\"{x:1443,y:413,t:1527016179115};\\\", \\\"{x:1443,y:421,t:1527016179235};\\\", \\\"{x:1443,y:422,t:1527016179249};\\\", \\\"{x:1447,y:441,t:1527016179267};\\\", \\\"{x:1447,y:457,t:1527016179283};\\\", \\\"{x:1451,y:465,t:1527016179299};\\\", \\\"{x:1451,y:482,t:1527016179316};\\\", \\\"{x:1450,y:492,t:1527016179333};\\\", \\\"{x:1450,y:512,t:1527016179350};\\\", \\\"{x:1450,y:538,t:1527016179366};\\\", \\\"{x:1447,y:561,t:1527016179383};\\\", \\\"{x:1444,y:583,t:1527016179400};\\\", \\\"{x:1438,y:599,t:1527016179416};\\\", \\\"{x:1436,y:607,t:1527016179434};\\\", \\\"{x:1430,y:615,t:1527016179450};\\\", \\\"{x:1425,y:619,t:1527016179467};\\\", \\\"{x:1419,y:624,t:1527016179482};\\\", \\\"{x:1411,y:629,t:1527016179500};\\\", \\\"{x:1403,y:638,t:1527016179516};\\\", \\\"{x:1396,y:643,t:1527016179532};\\\", \\\"{x:1393,y:644,t:1527016179550};\\\", \\\"{x:1388,y:650,t:1527016179566};\\\", \\\"{x:1385,y:653,t:1527016179583};\\\", \\\"{x:1377,y:664,t:1527016179600};\\\", \\\"{x:1367,y:669,t:1527016179616};\\\", \\\"{x:1365,y:671,t:1527016179633};\\\", \\\"{x:1364,y:671,t:1527016179682};\\\", \\\"{x:1362,y:671,t:1527016179722};\\\", \\\"{x:1362,y:672,t:1527016179883};\\\", \\\"{x:1362,y:677,t:1527016179901};\\\", \\\"{x:1369,y:693,t:1527016179917};\\\", \\\"{x:1376,y:715,t:1527016179933};\\\", \\\"{x:1381,y:734,t:1527016179950};\\\", \\\"{x:1383,y:750,t:1527016179967};\\\", \\\"{x:1383,y:759,t:1527016179986};\\\", \\\"{x:1383,y:766,t:1527016180000};\\\", \\\"{x:1381,y:767,t:1527016180016};\\\", \\\"{x:1381,y:769,t:1527016180032};\\\", \\\"{x:1381,y:773,t:1527016180050};\\\", \\\"{x:1381,y:777,t:1527016180066};\\\", \\\"{x:1381,y:779,t:1527016180083};\\\", \\\"{x:1380,y:780,t:1527016180099};\\\", \\\"{x:1378,y:783,t:1527016180116};\\\", \\\"{x:1373,y:790,t:1527016180132};\\\", \\\"{x:1372,y:795,t:1527016180150};\\\", \\\"{x:1367,y:805,t:1527016180167};\\\", \\\"{x:1363,y:813,t:1527016180183};\\\", \\\"{x:1361,y:814,t:1527016180199};\\\", \\\"{x:1357,y:817,t:1527016180217};\\\", \\\"{x:1356,y:827,t:1527016180234};\\\", \\\"{x:1354,y:832,t:1527016180250};\\\", \\\"{x:1354,y:840,t:1527016180267};\\\", \\\"{x:1354,y:844,t:1527016180283};\\\", \\\"{x:1354,y:848,t:1527016180300};\\\", \\\"{x:1355,y:853,t:1527016180316};\\\", \\\"{x:1355,y:860,t:1527016180334};\\\", \\\"{x:1353,y:868,t:1527016180350};\\\", \\\"{x:1352,y:869,t:1527016180367};\\\", \\\"{x:1352,y:871,t:1527016180384};\\\", \\\"{x:1352,y:872,t:1527016180400};\\\", \\\"{x:1350,y:872,t:1527016180475};\\\", \\\"{x:1346,y:871,t:1527016180491};\\\", \\\"{x:1341,y:870,t:1527016180500};\\\", \\\"{x:1325,y:866,t:1527016180517};\\\", \\\"{x:1310,y:864,t:1527016180535};\\\", \\\"{x:1293,y:861,t:1527016180550};\\\", \\\"{x:1286,y:860,t:1527016180567};\\\", \\\"{x:1284,y:860,t:1527016180584};\\\", \\\"{x:1279,y:859,t:1527016180601};\\\", \\\"{x:1276,y:857,t:1527016180617};\\\", \\\"{x:1273,y:857,t:1527016180635};\\\", \\\"{x:1272,y:857,t:1527016180651};\\\", \\\"{x:1271,y:857,t:1527016180739};\\\", \\\"{x:1269,y:857,t:1527016180750};\\\", \\\"{x:1265,y:857,t:1527016180767};\\\", \\\"{x:1261,y:857,t:1527016180784};\\\", \\\"{x:1257,y:856,t:1527016180801};\\\", \\\"{x:1255,y:856,t:1527016180817};\\\", \\\"{x:1250,y:854,t:1527016180834};\\\", \\\"{x:1248,y:854,t:1527016180851};\\\", \\\"{x:1247,y:854,t:1527016180867};\\\", \\\"{x:1245,y:854,t:1527016180890};\\\", \\\"{x:1242,y:853,t:1527016180907};\\\", \\\"{x:1240,y:853,t:1527016180917};\\\", \\\"{x:1234,y:853,t:1527016180934};\\\", \\\"{x:1233,y:852,t:1527016180951};\\\", \\\"{x:1232,y:851,t:1527016181162};\\\", \\\"{x:1231,y:850,t:1527016181171};\\\", \\\"{x:1230,y:848,t:1527016181184};\\\", \\\"{x:1228,y:847,t:1527016181201};\\\", \\\"{x:1226,y:845,t:1527016181219};\\\", \\\"{x:1224,y:842,t:1527016181235};\\\", \\\"{x:1222,y:840,t:1527016181307};\\\", \\\"{x:1221,y:839,t:1527016181387};\\\", \\\"{x:1220,y:838,t:1527016181451};\\\", \\\"{x:1219,y:837,t:1527016181468};\\\", \\\"{x:1218,y:837,t:1527016181547};\\\", \\\"{x:1217,y:836,t:1527016181651};\\\", \\\"{x:1217,y:835,t:1527016181988};\\\", \\\"{x:1217,y:834,t:1527016182226};\\\", \\\"{x:1217,y:833,t:1527016182939};\\\", \\\"{x:1217,y:832,t:1527016183058};\\\", \\\"{x:1215,y:831,t:1527016183082};\\\", \\\"{x:1214,y:831,t:1527016183091};\\\", \\\"{x:1209,y:830,t:1527016183107};\\\", \\\"{x:1205,y:829,t:1527016183119};\\\", \\\"{x:1195,y:827,t:1527016183136};\\\", \\\"{x:1190,y:827,t:1527016183152};\\\", \\\"{x:1172,y:823,t:1527016183169};\\\", \\\"{x:1092,y:812,t:1527016183185};\\\", \\\"{x:999,y:802,t:1527016183202};\\\", \\\"{x:902,y:791,t:1527016183219};\\\", \\\"{x:799,y:787,t:1527016183235};\\\", \\\"{x:694,y:779,t:1527016183253};\\\", \\\"{x:627,y:777,t:1527016183269};\\\", \\\"{x:595,y:773,t:1527016183286};\\\", \\\"{x:565,y:765,t:1527016183304};\\\", \\\"{x:551,y:761,t:1527016183319};\\\", \\\"{x:548,y:761,t:1527016183336};\\\", \\\"{x:546,y:761,t:1527016183353};\\\", \\\"{x:543,y:761,t:1527016183378};\\\", \\\"{x:542,y:761,t:1527016183402};\\\", \\\"{x:541,y:760,t:1527016183442};\\\", \\\"{x:541,y:759,t:1527016183452};\\\", \\\"{x:539,y:755,t:1527016183469};\\\", \\\"{x:539,y:753,t:1527016183486};\\\", \\\"{x:536,y:745,t:1527016183504};\\\", \\\"{x:533,y:739,t:1527016183519};\\\", \\\"{x:530,y:734,t:1527016183537};\\\", \\\"{x:529,y:732,t:1527016183552};\\\", \\\"{x:528,y:729,t:1527016183568};\\\", \\\"{x:527,y:726,t:1527016183584};\\\", \\\"{x:526,y:721,t:1527016183600};\\\", \\\"{x:526,y:720,t:1527016183674};\\\", \\\"{x:526,y:719,t:1527016184107};\\\", \\\"{x:525,y:718,t:1527016184178};\\\", \\\"{x:524,y:718,t:1527016184426};\\\", \\\"{x:524,y:717,t:1527016184522};\\\", \\\"{x:524,y:716,t:1527016184534};\\\", \\\"{x:524,y:715,t:1527016184551};\\\", \\\"{x:524,y:714,t:1527016184568};\\\", \\\"{x:524,y:712,t:1527016184584};\\\", \\\"{x:526,y:710,t:1527016184601};\\\", \\\"{x:532,y:705,t:1527016184618};\\\", \\\"{x:534,y:703,t:1527016184634};\\\", \\\"{x:540,y:701,t:1527016184651};\\\", \\\"{x:544,y:699,t:1527016184669};\\\", \\\"{x:547,y:696,t:1527016184684};\\\", \\\"{x:552,y:694,t:1527016184701};\\\", \\\"{x:554,y:694,t:1527016184719};\\\", \\\"{x:562,y:694,t:1527016184737};\\\", \\\"{x:591,y:694,t:1527016184754};\\\", \\\"{x:627,y:694,t:1527016184770};\\\", \\\"{x:654,y:694,t:1527016184787};\\\", \\\"{x:712,y:695,t:1527016184804};\\\", \\\"{x:781,y:695,t:1527016184820};\\\", \\\"{x:846,y:697,t:1527016184837};\\\", \\\"{x:903,y:698,t:1527016184853};\\\", \\\"{x:1011,y:702,t:1527016184870};\\\", \\\"{x:1096,y:707,t:1527016184887};\\\", \\\"{x:1179,y:718,t:1527016184904};\\\", \\\"{x:1237,y:725,t:1527016184919};\\\", \\\"{x:1340,y:743,t:1527016184937};\\\", \\\"{x:1467,y:754,t:1527016184954};\\\", \\\"{x:1499,y:762,t:1527016184970};\\\", \\\"{x:1526,y:759,t:1527016184987};\\\", \\\"{x:1538,y:759,t:1527016185005};\\\", \\\"{x:1550,y:755,t:1527016185020};\\\", \\\"{x:1558,y:754,t:1527016185037};\\\", \\\"{x:1562,y:753,t:1527016185054};\\\", \\\"{x:1558,y:753,t:1527016185314};\\\", \\\"{x:1556,y:758,t:1527016185321};\\\", \\\"{x:1553,y:762,t:1527016185337};\\\", \\\"{x:1549,y:765,t:1527016185354};\\\", \\\"{x:1548,y:766,t:1527016185371};\\\", \\\"{x:1548,y:765,t:1527016186515};\\\", \\\"{x:1548,y:763,t:1527016186523};\\\", \\\"{x:1548,y:762,t:1527016186539};\\\", \\\"{x:1548,y:761,t:1527016186556};\\\", \\\"{x:1549,y:759,t:1527016186571};\\\", \\\"{x:1549,y:758,t:1527016186589};\\\", \\\"{x:1549,y:756,t:1527016186605};\\\", \\\"{x:1551,y:752,t:1527016186622};\\\", \\\"{x:1551,y:750,t:1527016186638};\\\", \\\"{x:1552,y:745,t:1527016186655};\\\", \\\"{x:1554,y:739,t:1527016186673};\\\", \\\"{x:1557,y:728,t:1527016186688};\\\", \\\"{x:1561,y:719,t:1527016186705};\\\", \\\"{x:1564,y:707,t:1527016186722};\\\", \\\"{x:1568,y:695,t:1527016186739};\\\", \\\"{x:1571,y:688,t:1527016186756};\\\", \\\"{x:1572,y:682,t:1527016186772};\\\", \\\"{x:1576,y:675,t:1527016186789};\\\", \\\"{x:1580,y:670,t:1527016186805};\\\", \\\"{x:1581,y:667,t:1527016186822};\\\", \\\"{x:1589,y:658,t:1527016186839};\\\", \\\"{x:1597,y:652,t:1527016186855};\\\", \\\"{x:1600,y:645,t:1527016186872};\\\", \\\"{x:1602,y:640,t:1527016186889};\\\", \\\"{x:1605,y:640,t:1527016186905};\\\", \\\"{x:1609,y:632,t:1527016186922};\\\", \\\"{x:1611,y:630,t:1527016186938};\\\", \\\"{x:1611,y:627,t:1527016186956};\\\", \\\"{x:1612,y:625,t:1527016186972};\\\", \\\"{x:1612,y:624,t:1527016187090};\\\", \\\"{x:1612,y:623,t:1527016187105};\\\", \\\"{x:1612,y:622,t:1527016187651};\\\", \\\"{x:1612,y:621,t:1527016187658};\\\", \\\"{x:1613,y:618,t:1527016187674};\\\", \\\"{x:1617,y:615,t:1527016187689};\\\", \\\"{x:1618,y:615,t:1527016187730};\\\", \\\"{x:1617,y:616,t:1527016188811};\\\", \\\"{x:1616,y:617,t:1527016190474};\\\", \\\"{x:1616,y:618,t:1527016190498};\\\", \\\"{x:1615,y:618,t:1527016190508};\\\", \\\"{x:1614,y:619,t:1527016190529};\\\", \\\"{x:1613,y:619,t:1527016190593};\\\", \\\"{x:1611,y:619,t:1527016191663};\\\", \\\"{x:1611,y:620,t:1527016192175};\\\", \\\"{x:1611,y:621,t:1527016192327};\\\", \\\"{x:1611,y:622,t:1527016193150};\\\", \\\"{x:1611,y:623,t:1527016193478};\\\", \\\"{x:1610,y:624,t:1527016193903};\\\", \\\"{x:1609,y:625,t:1527016194055};\\\", \\\"{x:1607,y:625,t:1527016194862};\\\", \\\"{x:1607,y:626,t:1527016194879};\\\", \\\"{x:1606,y:626,t:1527016194895};\\\", \\\"{x:1605,y:627,t:1527016195678};\\\", \\\"{x:1604,y:627,t:1527016196599};\\\", \\\"{x:1604,y:628,t:1527016196607};\\\", \\\"{x:1603,y:628,t:1527016196807};\\\", \\\"{x:1602,y:630,t:1527016196823};\\\", \\\"{x:1601,y:630,t:1527016196834};\\\", \\\"{x:1601,y:631,t:1527016196854};\\\", \\\"{x:1600,y:631,t:1527016197647};\\\", \\\"{x:1599,y:633,t:1527016197799};\\\", \\\"{x:1598,y:634,t:1527016197814};\\\", \\\"{x:1597,y:635,t:1527016197854};\\\", \\\"{x:1597,y:636,t:1527016197878};\\\", \\\"{x:1595,y:637,t:1527016197942};\\\", \\\"{x:1592,y:638,t:1527016197958};\\\", \\\"{x:1589,y:639,t:1527016197968};\\\", \\\"{x:1584,y:642,t:1527016197985};\\\", \\\"{x:1582,y:644,t:1527016198001};\\\", \\\"{x:1580,y:644,t:1527016198018};\\\", \\\"{x:1580,y:643,t:1527016198503};\\\", \\\"{x:1582,y:637,t:1527016198518};\\\", \\\"{x:1582,y:636,t:1527016198536};\\\", \\\"{x:1582,y:634,t:1527016198552};\\\", \\\"{x:1582,y:633,t:1527016198568};\\\", \\\"{x:1582,y:632,t:1527016198631};\\\", \\\"{x:1582,y:631,t:1527016200512};\\\", \\\"{x:1582,y:630,t:1527016201536};\\\", \\\"{x:1584,y:629,t:1527016201582};\\\", \\\"{x:1584,y:628,t:1527016201806};\\\", \\\"{x:1585,y:628,t:1527016201822};\\\", \\\"{x:1586,y:627,t:1527016201846};\\\", \\\"{x:1587,y:627,t:1527016201862};\\\", \\\"{x:1588,y:627,t:1527016201959};\\\", \\\"{x:1589,y:626,t:1527016202030};\\\", \\\"{x:1590,y:626,t:1527016202046};\\\", \\\"{x:1591,y:625,t:1527016202214};\\\", \\\"{x:1590,y:625,t:1527016210984};\\\", \\\"{x:1588,y:625,t:1527016211015};\\\", \\\"{x:1586,y:625,t:1527016211029};\\\", \\\"{x:1584,y:625,t:1527016211046};\\\", \\\"{x:1581,y:625,t:1527016211061};\\\", \\\"{x:1580,y:626,t:1527016211078};\\\", \\\"{x:1574,y:628,t:1527016211096};\\\", \\\"{x:1573,y:628,t:1527016211111};\\\", \\\"{x:1568,y:630,t:1527016211128};\\\", \\\"{x:1566,y:630,t:1527016211145};\\\", \\\"{x:1564,y:630,t:1527016211162};\\\", \\\"{x:1562,y:630,t:1527016211178};\\\", \\\"{x:1561,y:630,t:1527016211195};\\\", \\\"{x:1560,y:630,t:1527016211212};\\\", \\\"{x:1555,y:630,t:1527016211228};\\\", \\\"{x:1546,y:631,t:1527016211245};\\\", \\\"{x:1536,y:635,t:1527016211262};\\\", \\\"{x:1529,y:637,t:1527016211279};\\\", \\\"{x:1513,y:637,t:1527016211295};\\\", \\\"{x:1492,y:639,t:1527016211312};\\\", \\\"{x:1484,y:640,t:1527016211328};\\\", \\\"{x:1479,y:640,t:1527016211345};\\\", \\\"{x:1472,y:640,t:1527016211363};\\\", \\\"{x:1471,y:640,t:1527016211391};\\\", \\\"{x:1467,y:643,t:1527016211399};\\\", \\\"{x:1466,y:644,t:1527016211413};\\\", \\\"{x:1459,y:647,t:1527016211429};\\\", \\\"{x:1445,y:653,t:1527016211446};\\\", \\\"{x:1427,y:661,t:1527016211462};\\\", \\\"{x:1409,y:670,t:1527016211479};\\\", \\\"{x:1392,y:678,t:1527016211495};\\\", \\\"{x:1381,y:678,t:1527016211513};\\\", \\\"{x:1369,y:679,t:1527016211528};\\\", \\\"{x:1362,y:680,t:1527016211546};\\\", \\\"{x:1359,y:680,t:1527016211562};\\\", \\\"{x:1356,y:682,t:1527016211579};\\\", \\\"{x:1352,y:682,t:1527016211596};\\\", \\\"{x:1349,y:685,t:1527016211612};\\\", \\\"{x:1334,y:691,t:1527016211629};\\\", \\\"{x:1312,y:703,t:1527016211646};\\\", \\\"{x:1302,y:712,t:1527016211663};\\\", \\\"{x:1246,y:727,t:1527016211679};\\\", \\\"{x:1214,y:735,t:1527016211696};\\\", \\\"{x:1191,y:737,t:1527016211713};\\\", \\\"{x:1186,y:739,t:1527016211730};\\\", \\\"{x:1168,y:737,t:1527016211746};\\\", \\\"{x:1165,y:736,t:1527016211763};\\\", \\\"{x:1163,y:735,t:1527016211780};\\\", \\\"{x:1161,y:735,t:1527016211848};\\\", \\\"{x:1160,y:735,t:1527016211863};\\\", \\\"{x:1158,y:737,t:1527016211879};\\\", \\\"{x:1157,y:737,t:1527016211911};\\\", \\\"{x:1156,y:737,t:1527016211967};\\\", \\\"{x:1155,y:737,t:1527016212047};\\\", \\\"{x:1151,y:737,t:1527016212062};\\\", \\\"{x:1145,y:737,t:1527016212079};\\\", \\\"{x:1136,y:738,t:1527016212095};\\\", \\\"{x:1132,y:738,t:1527016212112};\\\", \\\"{x:1128,y:738,t:1527016212129};\\\", \\\"{x:1127,y:738,t:1527016212166};\\\", \\\"{x:1127,y:740,t:1527016212179};\\\", \\\"{x:1125,y:742,t:1527016212223};\\\", \\\"{x:1123,y:742,t:1527016212255};\\\", \\\"{x:1122,y:742,t:1527016212263};\\\", \\\"{x:1121,y:742,t:1527016212608};\\\", \\\"{x:1116,y:742,t:1527016212656};\\\", \\\"{x:1107,y:742,t:1527016212663};\\\", \\\"{x:1086,y:742,t:1527016212680};\\\", \\\"{x:1069,y:740,t:1527016212697};\\\", \\\"{x:1042,y:736,t:1527016212714};\\\", \\\"{x:1019,y:732,t:1527016212729};\\\", \\\"{x:997,y:727,t:1527016212746};\\\", \\\"{x:982,y:725,t:1527016212764};\\\", \\\"{x:952,y:716,t:1527016212780};\\\", \\\"{x:930,y:705,t:1527016212797};\\\", \\\"{x:900,y:702,t:1527016212813};\\\", \\\"{x:894,y:696,t:1527016212830};\\\", \\\"{x:871,y:692,t:1527016212847};\\\", \\\"{x:846,y:682,t:1527016212863};\\\", \\\"{x:835,y:678,t:1527016212880};\\\", \\\"{x:829,y:673,t:1527016212897};\\\", \\\"{x:823,y:669,t:1527016212914};\\\", \\\"{x:818,y:664,t:1527016212929};\\\", \\\"{x:815,y:661,t:1527016212947};\\\", \\\"{x:814,y:655,t:1527016212963};\\\", \\\"{x:819,y:645,t:1527016212979};\\\", \\\"{x:824,y:640,t:1527016212996};\\\", \\\"{x:831,y:632,t:1527016213013};\\\", \\\"{x:840,y:622,t:1527016213029};\\\", \\\"{x:853,y:610,t:1527016213048};\\\", \\\"{x:856,y:608,t:1527016213063};\\\", \\\"{x:857,y:606,t:1527016213079};\\\", \\\"{x:860,y:602,t:1527016213097};\\\", \\\"{x:866,y:596,t:1527016213114};\\\", \\\"{x:873,y:591,t:1527016213131};\\\", \\\"{x:877,y:586,t:1527016213147};\\\", \\\"{x:879,y:584,t:1527016213164};\\\", \\\"{x:880,y:584,t:1527016213181};\\\", \\\"{x:880,y:582,t:1527016213198};\\\", \\\"{x:880,y:581,t:1527016213215};\\\", \\\"{x:878,y:579,t:1527016213231};\\\", \\\"{x:866,y:576,t:1527016213248};\\\", \\\"{x:843,y:575,t:1527016213265};\\\", \\\"{x:819,y:569,t:1527016213281};\\\", \\\"{x:773,y:566,t:1527016213298};\\\", \\\"{x:738,y:563,t:1527016213314};\\\", \\\"{x:724,y:563,t:1527016213331};\\\", \\\"{x:710,y:563,t:1527016213349};\\\", \\\"{x:684,y:565,t:1527016213365};\\\", \\\"{x:662,y:565,t:1527016213381};\\\", \\\"{x:649,y:565,t:1527016213398};\\\", \\\"{x:642,y:566,t:1527016213415};\\\", \\\"{x:630,y:566,t:1527016213431};\\\", \\\"{x:625,y:566,t:1527016213448};\\\", \\\"{x:622,y:565,t:1527016213465};\\\", \\\"{x:615,y:565,t:1527016213482};\\\", \\\"{x:604,y:564,t:1527016213498};\\\", \\\"{x:596,y:561,t:1527016213517};\\\", \\\"{x:589,y:561,t:1527016213532};\\\", \\\"{x:584,y:561,t:1527016213548};\\\", \\\"{x:563,y:562,t:1527016213565};\\\", \\\"{x:541,y:575,t:1527016213582};\\\", \\\"{x:531,y:578,t:1527016213598};\\\", \\\"{x:517,y:584,t:1527016213616};\\\", \\\"{x:503,y:585,t:1527016213631};\\\", \\\"{x:490,y:588,t:1527016213649};\\\", \\\"{x:486,y:589,t:1527016213665};\\\", \\\"{x:484,y:590,t:1527016213681};\\\", \\\"{x:477,y:593,t:1527016213698};\\\", \\\"{x:472,y:596,t:1527016213715};\\\", \\\"{x:469,y:598,t:1527016213732};\\\", \\\"{x:456,y:603,t:1527016213749};\\\", \\\"{x:437,y:611,t:1527016213766};\\\", \\\"{x:427,y:615,t:1527016213783};\\\", \\\"{x:424,y:615,t:1527016213798};\\\", \\\"{x:413,y:619,t:1527016213816};\\\", \\\"{x:400,y:621,t:1527016213834};\\\", \\\"{x:395,y:623,t:1527016213848};\\\", \\\"{x:386,y:623,t:1527016213865};\\\", \\\"{x:383,y:623,t:1527016213882};\\\", \\\"{x:379,y:623,t:1527016213898};\\\", \\\"{x:370,y:619,t:1527016213915};\\\", \\\"{x:361,y:617,t:1527016213932};\\\", \\\"{x:347,y:619,t:1527016213948};\\\", \\\"{x:344,y:619,t:1527016213965};\\\", \\\"{x:329,y:618,t:1527016213982};\\\", \\\"{x:319,y:614,t:1527016213998};\\\", \\\"{x:307,y:612,t:1527016214016};\\\", \\\"{x:304,y:610,t:1527016214032};\\\", \\\"{x:303,y:610,t:1527016214048};\\\", \\\"{x:299,y:609,t:1527016214065};\\\", \\\"{x:285,y:608,t:1527016214082};\\\", \\\"{x:276,y:606,t:1527016214098};\\\", \\\"{x:271,y:605,t:1527016214117};\\\", \\\"{x:269,y:605,t:1527016214132};\\\", \\\"{x:258,y:607,t:1527016214149};\\\", \\\"{x:251,y:610,t:1527016214165};\\\", \\\"{x:244,y:612,t:1527016214182};\\\", \\\"{x:243,y:612,t:1527016214198};\\\", \\\"{x:243,y:611,t:1527016214351};\\\", \\\"{x:243,y:610,t:1527016214366};\\\", \\\"{x:242,y:608,t:1527016214799};\\\", \\\"{x:228,y:603,t:1527016214816};\\\", \\\"{x:215,y:596,t:1527016214832};\\\", \\\"{x:203,y:588,t:1527016214850};\\\", \\\"{x:192,y:581,t:1527016214867};\\\", \\\"{x:185,y:579,t:1527016214882};\\\", \\\"{x:183,y:577,t:1527016214899};\\\", \\\"{x:181,y:575,t:1527016214927};\\\", \\\"{x:176,y:573,t:1527016214938};\\\", \\\"{x:169,y:570,t:1527016214949};\\\", \\\"{x:163,y:568,t:1527016214966};\\\", \\\"{x:164,y:569,t:1527016215423};\\\", \\\"{x:166,y:571,t:1527016215433};\\\", \\\"{x:184,y:587,t:1527016215451};\\\", \\\"{x:222,y:610,t:1527016215466};\\\", \\\"{x:298,y:654,t:1527016215484};\\\", \\\"{x:370,y:674,t:1527016215501};\\\", \\\"{x:482,y:713,t:1527016215517};\\\", \\\"{x:577,y:743,t:1527016215533};\\\", \\\"{x:622,y:764,t:1527016215550};\\\", \\\"{x:633,y:769,t:1527016215566};\\\", \\\"{x:633,y:774,t:1527016215583};\\\", \\\"{x:632,y:773,t:1527016215662};\\\", \\\"{x:632,y:772,t:1527016215678};\\\", \\\"{x:632,y:771,t:1527016215687};\\\", \\\"{x:632,y:769,t:1527016215701};\\\", \\\"{x:621,y:760,t:1527016215718};\\\", \\\"{x:608,y:747,t:1527016215734};\\\", \\\"{x:602,y:740,t:1527016215750};\\\", \\\"{x:595,y:731,t:1527016215767};\\\", \\\"{x:589,y:729,t:1527016215784};\\\", \\\"{x:582,y:725,t:1527016215802};\\\", \\\"{x:577,y:721,t:1527016215818};\\\", \\\"{x:569,y:717,t:1527016215834};\\\", \\\"{x:558,y:714,t:1527016215852};\\\", \\\"{x:553,y:711,t:1527016215868};\\\", \\\"{x:541,y:707,t:1527016215882};\\\", \\\"{x:530,y:704,t:1527016215900};\\\", \\\"{x:525,y:704,t:1527016215916};\\\", \\\"{x:519,y:704,t:1527016215933};\\\", \\\"{x:517,y:704,t:1527016215950};\\\", \\\"{x:509,y:703,t:1527016215967};\\\", \\\"{x:503,y:702,t:1527016215983};\\\", \\\"{x:500,y:702,t:1527016215999};\\\", \\\"{x:499,y:703,t:1527016216087};\\\", \\\"{x:499,y:704,t:1527016216103};\\\", \\\"{x:499,y:705,t:1527016216115};\\\", \\\"{x:497,y:706,t:1527016216133};\\\", \\\"{x:496,y:708,t:1527016216149};\\\", \\\"{x:495,y:711,t:1527016216166};\\\", \\\"{x:494,y:715,t:1527016216183};\\\", \\\"{x:494,y:716,t:1527016216823};\\\", \\\"{x:494,y:717,t:1527016216863};\\\", \\\"{x:494,y:718,t:1527016216871};\\\", \\\"{x:494,y:719,t:1527016216885};\\\", \\\"{x:498,y:722,t:1527016216901};\\\", \\\"{x:502,y:723,t:1527016216918};\\\", \\\"{x:518,y:725,t:1527016216935};\\\", \\\"{x:532,y:730,t:1527016216950};\\\", \\\"{x:544,y:733,t:1527016216968};\\\", \\\"{x:565,y:734,t:1527016216984};\\\", \\\"{x:582,y:741,t:1527016217002};\\\", \\\"{x:606,y:746,t:1527016217018};\\\", \\\"{x:617,y:755,t:1527016217035};\\\", \\\"{x:630,y:756,t:1527016217051};\\\", \\\"{x:648,y:761,t:1527016217067};\\\", \\\"{x:659,y:765,t:1527016217085};\\\", \\\"{x:669,y:769,t:1527016217102};\\\", \\\"{x:683,y:771,t:1527016217117};\\\", \\\"{x:696,y:771,t:1527016217135};\\\", \\\"{x:701,y:773,t:1527016217151};\\\", \\\"{x:702,y:774,t:1527016217167};\\\", \\\"{x:707,y:774,t:1527016217185};\\\", \\\"{x:713,y:774,t:1527016217201};\\\", \\\"{x:718,y:774,t:1527016217217};\\\", \\\"{x:728,y:775,t:1527016217234};\\\", \\\"{x:737,y:777,t:1527016217252};\\\", \\\"{x:742,y:782,t:1527016217268};\\\", \\\"{x:750,y:787,t:1527016217284};\\\", \\\"{x:765,y:796,t:1527016217302};\\\", \\\"{x:784,y:800,t:1527016217319};\\\", \\\"{x:795,y:802,t:1527016217335};\\\", \\\"{x:803,y:803,t:1527016217352};\\\", \\\"{x:806,y:805,t:1527016217369};\\\", \\\"{x:810,y:806,t:1527016217385};\\\", \\\"{x:812,y:806,t:1527016217402};\\\", \\\"{x:815,y:806,t:1527016217419};\\\", \\\"{x:819,y:806,t:1527016217435};\\\", \\\"{x:821,y:806,t:1527016217451};\\\", \\\"{x:823,y:806,t:1527016217566};\\\", \\\"{x:824,y:806,t:1527016217590};\\\", \\\"{x:826,y:806,t:1527016217622};\\\", \\\"{x:828,y:806,t:1527016217634};\\\" ] }, { \\\"rt\\\": 83369, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 8, \\\"time_elapsed\\\": 339450, \\\"internal_node_id\\\": \\\"0.0-5.0-3.0\\\", \\\"subject\\\": \\\"6Y93F\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"foxtrot\\\", \\\"condition\\\": \\\"111\\\", \\\"scenario\\\": \\\"acme\\\", \\\"question\\\": \\\"endtime\\\", \\\"q\\\": 4, \\\"clicks\\\": 4, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XInside-YFull\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 0, \\\"answer\\\": [ \\\"O\\\", \\\"U\\\", \\\"D\\\", \\\"E\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"X \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"U \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-01 PM-02 PM-4-A -A -O -Z -Z -04 PM-03 PM\\\", \\\"block\\\": \\\"triangular_scaffolded\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:829,y:806,t:1527016217814};\\\", \\\"{x:830,y:806,t:1527016218223};\\\", \\\"{x:831,y:806,t:1527016218342};\\\", \\\"{x:832,y:806,t:1527016218712};\\\", \\\"{x:834,y:806,t:1527016218719};\\\", \\\"{x:838,y:806,t:1527016218736};\\\", \\\"{x:841,y:804,t:1527016218753};\\\", \\\"{x:842,y:802,t:1527016218775};\\\", \\\"{x:850,y:800,t:1527016218785};\\\", \\\"{x:868,y:796,t:1527016218802};\\\", \\\"{x:870,y:795,t:1527016218819};\\\", \\\"{x:881,y:794,t:1527016218836};\\\", \\\"{x:912,y:800,t:1527016218852};\\\", \\\"{x:926,y:803,t:1527016218869};\\\", \\\"{x:930,y:803,t:1527016218886};\\\", \\\"{x:938,y:803,t:1527016218902};\\\", \\\"{x:940,y:803,t:1527016218920};\\\", \\\"{x:941,y:803,t:1527016218967};\\\", \\\"{x:941,y:802,t:1527016219335};\\\", \\\"{x:941,y:801,t:1527016219353};\\\", \\\"{x:941,y:800,t:1527016219369};\\\", \\\"{x:940,y:800,t:1527016219399};\\\", \\\"{x:939,y:799,t:1527016219407};\\\", \\\"{x:939,y:798,t:1527016219420};\\\", \\\"{x:938,y:797,t:1527016219437};\\\", \\\"{x:936,y:796,t:1527016219453};\\\", \\\"{x:935,y:795,t:1527016219511};\\\", \\\"{x:935,y:794,t:1527016219575};\\\", \\\"{x:935,y:792,t:1527016219591};\\\", \\\"{x:935,y:791,t:1527016219604};\\\", \\\"{x:936,y:787,t:1527016219620};\\\", \\\"{x:939,y:785,t:1527016219636};\\\", \\\"{x:942,y:783,t:1527016219653};\\\", \\\"{x:945,y:782,t:1527016219669};\\\", \\\"{x:945,y:781,t:1527016219686};\\\", \\\"{x:946,y:780,t:1527016219935};\\\", \\\"{x:955,y:777,t:1527016219943};\\\", \\\"{x:958,y:777,t:1527016219954};\\\", \\\"{x:993,y:771,t:1527016219970};\\\", \\\"{x:1066,y:767,t:1527016219987};\\\", \\\"{x:1126,y:764,t:1527016220004};\\\", \\\"{x:1233,y:771,t:1527016220020};\\\", \\\"{x:1253,y:774,t:1527016220037};\\\", \\\"{x:1268,y:777,t:1527016220054};\\\", \\\"{x:1287,y:777,t:1527016220071};\\\", \\\"{x:1289,y:777,t:1527016220119};\\\", \\\"{x:1290,y:777,t:1527016220168};\\\", \\\"{x:1292,y:777,t:1527016220191};\\\", \\\"{x:1295,y:777,t:1527016220310};\\\", \\\"{x:1297,y:777,t:1527016220321};\\\", \\\"{x:1303,y:776,t:1527016220336};\\\", \\\"{x:1309,y:776,t:1527016220353};\\\", \\\"{x:1311,y:776,t:1527016220371};\\\", \\\"{x:1312,y:776,t:1527016220386};\\\", \\\"{x:1313,y:775,t:1527016220403};\\\", \\\"{x:1310,y:775,t:1527016222471};\\\", \\\"{x:1298,y:770,t:1527016222489};\\\", \\\"{x:1293,y:767,t:1527016222506};\\\", \\\"{x:1289,y:766,t:1527016222522};\\\", \\\"{x:1289,y:765,t:1527016222599};\\\", \\\"{x:1288,y:765,t:1527016222615};\\\", \\\"{x:1285,y:765,t:1527016222631};\\\", \\\"{x:1283,y:765,t:1527016222647};\\\", \\\"{x:1281,y:766,t:1527016222744};\\\", \\\"{x:1280,y:766,t:1527016222756};\\\", \\\"{x:1279,y:769,t:1527016222772};\\\", \\\"{x:1279,y:777,t:1527016222789};\\\", \\\"{x:1283,y:792,t:1527016222806};\\\", \\\"{x:1297,y:813,t:1527016222823};\\\", \\\"{x:1317,y:835,t:1527016222839};\\\", \\\"{x:1342,y:856,t:1527016222856};\\\", \\\"{x:1376,y:889,t:1527016222872};\\\", \\\"{x:1399,y:904,t:1527016222889};\\\", \\\"{x:1410,y:908,t:1527016222906};\\\", \\\"{x:1419,y:909,t:1527016222924};\\\", \\\"{x:1423,y:909,t:1527016222939};\\\", \\\"{x:1428,y:908,t:1527016223087};\\\", \\\"{x:1435,y:903,t:1527016223095};\\\", \\\"{x:1447,y:896,t:1527016223106};\\\", \\\"{x:1489,y:881,t:1527016223124};\\\", \\\"{x:1518,y:865,t:1527016223139};\\\", \\\"{x:1541,y:852,t:1527016223156};\\\", \\\"{x:1559,y:839,t:1527016223173};\\\", \\\"{x:1574,y:829,t:1527016223189};\\\", \\\"{x:1581,y:827,t:1527016223206};\\\", \\\"{x:1582,y:826,t:1527016223223};\\\", \\\"{x:1580,y:826,t:1527016223360};\\\", \\\"{x:1576,y:829,t:1527016223373};\\\", \\\"{x:1572,y:834,t:1527016223390};\\\", \\\"{x:1570,y:842,t:1527016223406};\\\", \\\"{x:1560,y:861,t:1527016223423};\\\", \\\"{x:1556,y:873,t:1527016223440};\\\", \\\"{x:1556,y:878,t:1527016223456};\\\", \\\"{x:1556,y:879,t:1527016223542};\\\", \\\"{x:1557,y:879,t:1527016223555};\\\", \\\"{x:1560,y:879,t:1527016223574};\\\", \\\"{x:1561,y:879,t:1527016223590};\\\", \\\"{x:1563,y:879,t:1527016223605};\\\", \\\"{x:1565,y:879,t:1527016223622};\\\", \\\"{x:1567,y:881,t:1527016223640};\\\", \\\"{x:1574,y:882,t:1527016223655};\\\", \\\"{x:1577,y:882,t:1527016223672};\\\", \\\"{x:1578,y:884,t:1527016223690};\\\", \\\"{x:1580,y:884,t:1527016223710};\\\", \\\"{x:1581,y:884,t:1527016223722};\\\", \\\"{x:1582,y:885,t:1527016223740};\\\", \\\"{x:1582,y:887,t:1527016223755};\\\", \\\"{x:1584,y:891,t:1527016223773};\\\", \\\"{x:1585,y:895,t:1527016223790};\\\", \\\"{x:1588,y:903,t:1527016223806};\\\", \\\"{x:1594,y:916,t:1527016223823};\\\", \\\"{x:1598,y:924,t:1527016223840};\\\", \\\"{x:1604,y:928,t:1527016223856};\\\", \\\"{x:1607,y:931,t:1527016223872};\\\", \\\"{x:1609,y:931,t:1527016223890};\\\", \\\"{x:1612,y:931,t:1527016223906};\\\", \\\"{x:1614,y:931,t:1527016224024};\\\", \\\"{x:1615,y:931,t:1527016224047};\\\", \\\"{x:1616,y:931,t:1527016224062};\\\", \\\"{x:1618,y:931,t:1527016224073};\\\", \\\"{x:1620,y:925,t:1527016224090};\\\", \\\"{x:1624,y:916,t:1527016224107};\\\", \\\"{x:1627,y:901,t:1527016224123};\\\", \\\"{x:1631,y:884,t:1527016224140};\\\", \\\"{x:1631,y:881,t:1527016224157};\\\", \\\"{x:1631,y:877,t:1527016224173};\\\", \\\"{x:1634,y:869,t:1527016224190};\\\", \\\"{x:1634,y:865,t:1527016224207};\\\", \\\"{x:1634,y:862,t:1527016224231};\\\", \\\"{x:1634,y:861,t:1527016224240};\\\", \\\"{x:1635,y:859,t:1527016224257};\\\", \\\"{x:1635,y:856,t:1527016224273};\\\", \\\"{x:1636,y:852,t:1527016224290};\\\", \\\"{x:1636,y:851,t:1527016224307};\\\", \\\"{x:1637,y:850,t:1527016224324};\\\", \\\"{x:1638,y:849,t:1527016224368};\\\", \\\"{x:1638,y:848,t:1527016224399};\\\", \\\"{x:1638,y:849,t:1527016224511};\\\", \\\"{x:1639,y:857,t:1527016224524};\\\", \\\"{x:1639,y:863,t:1527016224540};\\\", \\\"{x:1639,y:870,t:1527016224558};\\\", \\\"{x:1639,y:874,t:1527016224574};\\\", \\\"{x:1638,y:878,t:1527016224590};\\\", \\\"{x:1637,y:881,t:1527016224608};\\\", \\\"{x:1637,y:884,t:1527016224735};\\\", \\\"{x:1636,y:887,t:1527016224743};\\\", \\\"{x:1634,y:888,t:1527016224757};\\\", \\\"{x:1629,y:894,t:1527016224775};\\\", \\\"{x:1625,y:902,t:1527016224790};\\\", \\\"{x:1621,y:904,t:1527016224807};\\\", \\\"{x:1615,y:910,t:1527016224824};\\\", \\\"{x:1613,y:913,t:1527016224841};\\\", \\\"{x:1612,y:913,t:1527016224943};\\\", \\\"{x:1611,y:913,t:1527016224956};\\\", \\\"{x:1608,y:912,t:1527016224974};\\\", \\\"{x:1598,y:907,t:1527016224991};\\\", \\\"{x:1594,y:901,t:1527016225007};\\\", \\\"{x:1592,y:895,t:1527016225024};\\\", \\\"{x:1590,y:888,t:1527016225041};\\\", \\\"{x:1590,y:880,t:1527016225057};\\\", \\\"{x:1590,y:876,t:1527016225074};\\\", \\\"{x:1590,y:867,t:1527016225091};\\\", \\\"{x:1588,y:854,t:1527016225107};\\\", \\\"{x:1588,y:847,t:1527016225123};\\\", \\\"{x:1588,y:842,t:1527016225141};\\\", \\\"{x:1588,y:837,t:1527016225157};\\\", \\\"{x:1588,y:828,t:1527016225175};\\\", \\\"{x:1586,y:822,t:1527016225191};\\\", \\\"{x:1586,y:820,t:1527016225207};\\\", \\\"{x:1586,y:818,t:1527016225247};\\\", \\\"{x:1588,y:812,t:1527016225257};\\\", \\\"{x:1590,y:809,t:1527016225274};\\\", \\\"{x:1597,y:799,t:1527016225291};\\\", \\\"{x:1604,y:791,t:1527016225307};\\\", \\\"{x:1605,y:784,t:1527016225323};\\\", \\\"{x:1611,y:772,t:1527016225340};\\\", \\\"{x:1613,y:765,t:1527016225358};\\\", \\\"{x:1615,y:760,t:1527016225374};\\\", \\\"{x:1618,y:748,t:1527016225390};\\\", \\\"{x:1623,y:738,t:1527016225407};\\\", \\\"{x:1625,y:724,t:1527016225424};\\\", \\\"{x:1629,y:711,t:1527016225441};\\\", \\\"{x:1632,y:698,t:1527016225457};\\\", \\\"{x:1637,y:679,t:1527016225474};\\\", \\\"{x:1640,y:669,t:1527016225491};\\\", \\\"{x:1643,y:656,t:1527016225508};\\\", \\\"{x:1644,y:649,t:1527016225524};\\\", \\\"{x:1644,y:643,t:1527016225541};\\\", \\\"{x:1645,y:638,t:1527016225558};\\\", \\\"{x:1645,y:637,t:1527016225574};\\\", \\\"{x:1645,y:633,t:1527016225591};\\\", \\\"{x:1645,y:630,t:1527016225608};\\\", \\\"{x:1645,y:627,t:1527016225625};\\\", \\\"{x:1642,y:624,t:1527016225641};\\\", \\\"{x:1642,y:621,t:1527016225657};\\\", \\\"{x:1641,y:620,t:1527016225674};\\\", \\\"{x:1640,y:620,t:1527016225691};\\\", \\\"{x:1638,y:619,t:1527016225707};\\\", \\\"{x:1633,y:619,t:1527016225723};\\\", \\\"{x:1632,y:619,t:1527016225775};\\\", \\\"{x:1621,y:619,t:1527016225790};\\\", \\\"{x:1603,y:628,t:1527016225808};\\\", \\\"{x:1582,y:632,t:1527016225825};\\\", \\\"{x:1565,y:631,t:1527016225841};\\\", \\\"{x:1555,y:633,t:1527016225858};\\\", \\\"{x:1530,y:635,t:1527016225875};\\\", \\\"{x:1519,y:637,t:1527016225890};\\\", \\\"{x:1507,y:640,t:1527016225908};\\\", \\\"{x:1504,y:642,t:1527016225925};\\\", \\\"{x:1476,y:649,t:1527016225940};\\\", \\\"{x:1444,y:662,t:1527016225958};\\\", \\\"{x:1366,y:692,t:1527016225974};\\\", \\\"{x:1272,y:705,t:1527016225990};\\\", \\\"{x:1178,y:715,t:1527016226007};\\\", \\\"{x:1058,y:710,t:1527016226025};\\\", \\\"{x:997,y:704,t:1527016226041};\\\", \\\"{x:962,y:698,t:1527016226057};\\\", \\\"{x:957,y:698,t:1527016226575};\\\", \\\"{x:942,y:695,t:1527016226592};\\\", \\\"{x:933,y:690,t:1527016226608};\\\", \\\"{x:920,y:686,t:1527016226625};\\\", \\\"{x:917,y:682,t:1527016226642};\\\", \\\"{x:911,y:680,t:1527016226658};\\\", \\\"{x:910,y:680,t:1527016226675};\\\", \\\"{x:908,y:679,t:1527016226691};\\\", \\\"{x:907,y:678,t:1527016226708};\\\", \\\"{x:906,y:677,t:1527016226724};\\\", \\\"{x:899,y:676,t:1527016226742};\\\", \\\"{x:888,y:672,t:1527016226758};\\\", \\\"{x:883,y:672,t:1527016226774};\\\", \\\"{x:881,y:670,t:1527016226792};\\\", \\\"{x:880,y:669,t:1527016226809};\\\", \\\"{x:879,y:669,t:1527016226825};\\\", \\\"{x:875,y:665,t:1527016226842};\\\", \\\"{x:874,y:663,t:1527016226858};\\\", \\\"{x:873,y:663,t:1527016226875};\\\", \\\"{x:872,y:662,t:1527016226895};\\\", \\\"{x:871,y:660,t:1527016226926};\\\", \\\"{x:867,y:659,t:1527016226942};\\\", \\\"{x:853,y:658,t:1527016226959};\\\", \\\"{x:849,y:658,t:1527016226975};\\\", \\\"{x:832,y:655,t:1527016226992};\\\", \\\"{x:825,y:653,t:1527016227009};\\\", \\\"{x:815,y:649,t:1527016227025};\\\", \\\"{x:808,y:644,t:1527016227041};\\\", \\\"{x:804,y:640,t:1527016227059};\\\", \\\"{x:793,y:637,t:1527016227075};\\\", \\\"{x:779,y:636,t:1527016227092};\\\", \\\"{x:765,y:632,t:1527016227109};\\\", \\\"{x:756,y:631,t:1527016227125};\\\", \\\"{x:744,y:627,t:1527016227142};\\\", \\\"{x:728,y:628,t:1527016227158};\\\", \\\"{x:723,y:627,t:1527016227177};\\\", \\\"{x:713,y:626,t:1527016227191};\\\", \\\"{x:685,y:619,t:1527016227209};\\\", \\\"{x:672,y:612,t:1527016227227};\\\", \\\"{x:657,y:606,t:1527016227243};\\\", \\\"{x:641,y:600,t:1527016227260};\\\", \\\"{x:625,y:593,t:1527016227275};\\\", \\\"{x:611,y:590,t:1527016227293};\\\", \\\"{x:602,y:587,t:1527016227310};\\\", \\\"{x:594,y:583,t:1527016227325};\\\", \\\"{x:571,y:581,t:1527016227342};\\\", \\\"{x:558,y:579,t:1527016227359};\\\", \\\"{x:538,y:577,t:1527016227375};\\\", \\\"{x:534,y:577,t:1527016227393};\\\", \\\"{x:517,y:571,t:1527016227410};\\\", \\\"{x:505,y:563,t:1527016227426};\\\", \\\"{x:491,y:556,t:1527016227443};\\\", \\\"{x:487,y:554,t:1527016227460};\\\", \\\"{x:485,y:554,t:1527016227476};\\\", \\\"{x:484,y:554,t:1527016227494};\\\", \\\"{x:483,y:554,t:1527016227510};\\\", \\\"{x:477,y:554,t:1527016227525};\\\", \\\"{x:472,y:554,t:1527016227543};\\\", \\\"{x:466,y:554,t:1527016227560};\\\", \\\"{x:461,y:554,t:1527016227576};\\\", \\\"{x:458,y:554,t:1527016227592};\\\", \\\"{x:454,y:553,t:1527016227609};\\\", \\\"{x:452,y:553,t:1527016227630};\\\", \\\"{x:451,y:553,t:1527016227642};\\\", \\\"{x:449,y:553,t:1527016227660};\\\", \\\"{x:447,y:553,t:1527016227675};\\\", \\\"{x:444,y:553,t:1527016227693};\\\", \\\"{x:437,y:554,t:1527016227709};\\\", \\\"{x:436,y:554,t:1527016227725};\\\", \\\"{x:434,y:556,t:1527016227742};\\\", \\\"{x:426,y:561,t:1527016227760};\\\", \\\"{x:423,y:563,t:1527016227777};\\\", \\\"{x:421,y:564,t:1527016227793};\\\", \\\"{x:416,y:566,t:1527016227810};\\\", \\\"{x:413,y:568,t:1527016227827};\\\", \\\"{x:412,y:568,t:1527016227843};\\\", \\\"{x:411,y:568,t:1527016227859};\\\", \\\"{x:410,y:568,t:1527016227878};\\\", \\\"{x:409,y:569,t:1527016227895};\\\", \\\"{x:407,y:571,t:1527016227910};\\\", \\\"{x:397,y:574,t:1527016227926};\\\", \\\"{x:391,y:578,t:1527016227944};\\\", \\\"{x:382,y:582,t:1527016227960};\\\", \\\"{x:375,y:585,t:1527016227977};\\\", \\\"{x:365,y:589,t:1527016227993};\\\", \\\"{x:359,y:590,t:1527016228010};\\\", \\\"{x:353,y:591,t:1527016228026};\\\", \\\"{x:351,y:591,t:1527016228042};\\\", \\\"{x:348,y:591,t:1527016228059};\\\", \\\"{x:345,y:592,t:1527016228077};\\\", \\\"{x:344,y:593,t:1527016228126};\\\", \\\"{x:343,y:594,t:1527016228144};\\\", \\\"{x:340,y:595,t:1527016228190};\\\", \\\"{x:339,y:595,t:1527016228199};\\\", \\\"{x:337,y:597,t:1527016228210};\\\", \\\"{x:333,y:597,t:1527016228227};\\\", \\\"{x:331,y:597,t:1527016228246};\\\", \\\"{x:331,y:598,t:1527016228260};\\\", \\\"{x:321,y:600,t:1527016228277};\\\", \\\"{x:307,y:602,t:1527016228294};\\\", \\\"{x:303,y:602,t:1527016228311};\\\", \\\"{x:297,y:601,t:1527016228327};\\\", \\\"{x:279,y:602,t:1527016228344};\\\", \\\"{x:260,y:605,t:1527016228363};\\\", \\\"{x:248,y:605,t:1527016228376};\\\", \\\"{x:246,y:605,t:1527016228393};\\\", \\\"{x:241,y:605,t:1527016228410};\\\", \\\"{x:240,y:604,t:1527016228743};\\\", \\\"{x:243,y:602,t:1527016228822};\\\", \\\"{x:244,y:602,t:1527016228829};\\\", \\\"{x:248,y:601,t:1527016228843};\\\", \\\"{x:259,y:601,t:1527016228860};\\\", \\\"{x:273,y:601,t:1527016228878};\\\", \\\"{x:299,y:601,t:1527016228893};\\\", \\\"{x:313,y:604,t:1527016228910};\\\", \\\"{x:336,y:615,t:1527016228927};\\\", \\\"{x:366,y:623,t:1527016228944};\\\", \\\"{x:380,y:637,t:1527016228961};\\\", \\\"{x:393,y:648,t:1527016228977};\\\", \\\"{x:412,y:655,t:1527016228994};\\\", \\\"{x:423,y:659,t:1527016229011};\\\", \\\"{x:425,y:660,t:1527016229026};\\\", \\\"{x:427,y:660,t:1527016229043};\\\", \\\"{x:429,y:660,t:1527016229061};\\\", \\\"{x:430,y:658,t:1527016229076};\\\", \\\"{x:432,y:658,t:1527016229094};\\\", \\\"{x:440,y:654,t:1527016229111};\\\", \\\"{x:449,y:653,t:1527016229126};\\\", \\\"{x:463,y:651,t:1527016229143};\\\", \\\"{x:485,y:648,t:1527016229161};\\\", \\\"{x:494,y:646,t:1527016229176};\\\", \\\"{x:511,y:644,t:1527016229194};\\\", \\\"{x:520,y:641,t:1527016229210};\\\", \\\"{x:529,y:640,t:1527016229227};\\\", \\\"{x:536,y:639,t:1527016229245};\\\", \\\"{x:544,y:639,t:1527016229261};\\\", \\\"{x:558,y:639,t:1527016229278};\\\", \\\"{x:560,y:639,t:1527016229293};\\\", \\\"{x:572,y:639,t:1527016229310};\\\", \\\"{x:574,y:640,t:1527016229327};\\\", \\\"{x:579,y:640,t:1527016229344};\\\", \\\"{x:583,y:640,t:1527016229361};\\\", \\\"{x:589,y:640,t:1527016229377};\\\", \\\"{x:599,y:640,t:1527016229393};\\\", \\\"{x:610,y:640,t:1527016229411};\\\", \\\"{x:622,y:640,t:1527016229428};\\\", \\\"{x:640,y:641,t:1527016229444};\\\", \\\"{x:663,y:641,t:1527016229462};\\\", \\\"{x:690,y:641,t:1527016229478};\\\", \\\"{x:714,y:642,t:1527016229493};\\\", \\\"{x:765,y:631,t:1527016229511};\\\", \\\"{x:792,y:623,t:1527016229528};\\\", \\\"{x:813,y:618,t:1527016229545};\\\", \\\"{x:820,y:617,t:1527016229560};\\\", \\\"{x:833,y:613,t:1527016229578};\\\", \\\"{x:838,y:612,t:1527016229594};\\\", \\\"{x:842,y:610,t:1527016229610};\\\", \\\"{x:843,y:610,t:1527016229627};\\\", \\\"{x:843,y:609,t:1527016229645};\\\", \\\"{x:845,y:607,t:1527016229660};\\\", \\\"{x:850,y:606,t:1527016229678};\\\", \\\"{x:855,y:604,t:1527016229693};\\\", \\\"{x:864,y:599,t:1527016229711};\\\", \\\"{x:868,y:596,t:1527016229728};\\\", \\\"{x:870,y:593,t:1527016229745};\\\", \\\"{x:869,y:594,t:1527016229822};\\\", \\\"{x:868,y:594,t:1527016229830};\\\", \\\"{x:865,y:594,t:1527016229845};\\\", \\\"{x:862,y:595,t:1527016229861};\\\", \\\"{x:857,y:596,t:1527016229877};\\\", \\\"{x:854,y:596,t:1527016229894};\\\", \\\"{x:853,y:596,t:1527016229911};\\\", \\\"{x:852,y:596,t:1527016229928};\\\", \\\"{x:850,y:599,t:1527016229950};\\\", \\\"{x:849,y:599,t:1527016229962};\\\", \\\"{x:847,y:599,t:1527016229978};\\\", \\\"{x:844,y:601,t:1527016229995};\\\", \\\"{x:842,y:602,t:1527016230012};\\\", \\\"{x:841,y:602,t:1527016230030};\\\", \\\"{x:838,y:604,t:1527016230094};\\\", \\\"{x:837,y:604,t:1527016230126};\\\", \\\"{x:833,y:606,t:1527016230502};\\\", \\\"{x:829,y:606,t:1527016230511};\\\", \\\"{x:824,y:606,t:1527016230530};\\\", \\\"{x:809,y:606,t:1527016230545};\\\", \\\"{x:803,y:604,t:1527016230562};\\\", \\\"{x:792,y:600,t:1527016230579};\\\", \\\"{x:769,y:598,t:1527016230595};\\\", \\\"{x:751,y:595,t:1527016230612};\\\", \\\"{x:698,y:591,t:1527016230630};\\\", \\\"{x:614,y:591,t:1527016230645};\\\", \\\"{x:474,y:583,t:1527016230663};\\\", \\\"{x:397,y:576,t:1527016230680};\\\", \\\"{x:369,y:561,t:1527016230695};\\\", \\\"{x:347,y:559,t:1527016230711};\\\", \\\"{x:335,y:557,t:1527016230728};\\\", \\\"{x:323,y:556,t:1527016230745};\\\", \\\"{x:316,y:553,t:1527016230762};\\\", \\\"{x:307,y:553,t:1527016230779};\\\", \\\"{x:305,y:553,t:1527016230796};\\\", \\\"{x:301,y:554,t:1527016230812};\\\", \\\"{x:300,y:554,t:1527016230829};\\\", \\\"{x:299,y:554,t:1527016230846};\\\", \\\"{x:297,y:554,t:1527016231174};\\\", \\\"{x:294,y:555,t:1527016231182};\\\", \\\"{x:290,y:557,t:1527016231197};\\\", \\\"{x:273,y:565,t:1527016231215};\\\", \\\"{x:263,y:567,t:1527016231234};\\\", \\\"{x:253,y:571,t:1527016231247};\\\", \\\"{x:247,y:572,t:1527016231263};\\\", \\\"{x:243,y:572,t:1527016231279};\\\", \\\"{x:236,y:573,t:1527016231296};\\\", \\\"{x:232,y:574,t:1527016231312};\\\", \\\"{x:230,y:574,t:1527016231328};\\\", \\\"{x:228,y:574,t:1527016231346};\\\", \\\"{x:227,y:574,t:1527016231382};\\\", \\\"{x:224,y:574,t:1527016231396};\\\", \\\"{x:216,y:574,t:1527016231413};\\\", \\\"{x:211,y:574,t:1527016231428};\\\", \\\"{x:197,y:584,t:1527016231448};\\\", \\\"{x:188,y:587,t:1527016231463};\\\", \\\"{x:183,y:590,t:1527016231479};\\\", \\\"{x:183,y:593,t:1527016231495};\\\", \\\"{x:177,y:598,t:1527016231513};\\\", \\\"{x:173,y:602,t:1527016231529};\\\", \\\"{x:171,y:606,t:1527016231546};\\\", \\\"{x:168,y:610,t:1527016231563};\\\", \\\"{x:166,y:613,t:1527016231579};\\\", \\\"{x:163,y:619,t:1527016231595};\\\", \\\"{x:160,y:625,t:1527016231613};\\\", \\\"{x:154,y:635,t:1527016231629};\\\", \\\"{x:151,y:642,t:1527016231645};\\\", \\\"{x:150,y:642,t:1527016231663};\\\", \\\"{x:150,y:644,t:1527016231679};\\\", \\\"{x:151,y:644,t:1527016231903};\\\", \\\"{x:153,y:644,t:1527016232238};\\\", \\\"{x:156,y:644,t:1527016232246};\\\", \\\"{x:165,y:644,t:1527016232263};\\\", \\\"{x:186,y:654,t:1527016232282};\\\", \\\"{x:282,y:680,t:1527016232297};\\\", \\\"{x:417,y:717,t:1527016232312};\\\", \\\"{x:472,y:725,t:1527016232330};\\\", \\\"{x:508,y:728,t:1527016232347};\\\", \\\"{x:634,y:756,t:1527016232363};\\\", \\\"{x:698,y:772,t:1527016232380};\\\", \\\"{x:722,y:778,t:1527016232397};\\\", \\\"{x:730,y:783,t:1527016232412};\\\", \\\"{x:731,y:783,t:1527016232430};\\\", \\\"{x:734,y:783,t:1527016232445};\\\", \\\"{x:737,y:783,t:1527016232463};\\\", \\\"{x:744,y:784,t:1527016232494};\\\", \\\"{x:748,y:785,t:1527016232502};\\\", \\\"{x:751,y:785,t:1527016232514};\\\", \\\"{x:770,y:788,t:1527016232530};\\\", \\\"{x:780,y:788,t:1527016232547};\\\", \\\"{x:785,y:788,t:1527016232564};\\\", \\\"{x:786,y:788,t:1527016232580};\\\", \\\"{x:789,y:788,t:1527016232597};\\\", \\\"{x:807,y:787,t:1527016232615};\\\", \\\"{x:835,y:781,t:1527016232631};\\\", \\\"{x:848,y:776,t:1527016232647};\\\", \\\"{x:855,y:775,t:1527016232664};\\\", \\\"{x:861,y:773,t:1527016232680};\\\", \\\"{x:862,y:773,t:1527016232697};\\\", \\\"{x:863,y:773,t:1527016232713};\\\", \\\"{x:862,y:773,t:1527016232894};\\\", \\\"{x:861,y:773,t:1527016232911};\\\", \\\"{x:860,y:773,t:1527016232926};\\\", \\\"{x:859,y:773,t:1527016232934};\\\", \\\"{x:858,y:773,t:1527016232947};\\\", \\\"{x:848,y:774,t:1527016267098};\\\", \\\"{x:825,y:783,t:1527016267114};\\\", \\\"{x:819,y:788,t:1527016267130};\\\", \\\"{x:817,y:788,t:1527016267147};\\\", \\\"{x:811,y:786,t:1527016267164};\\\", \\\"{x:801,y:782,t:1527016267180};\\\", \\\"{x:793,y:778,t:1527016267197};\\\", \\\"{x:772,y:772,t:1527016267213};\\\", \\\"{x:751,y:764,t:1527016267230};\\\", \\\"{x:742,y:760,t:1527016267247};\\\", \\\"{x:736,y:758,t:1527016267264};\\\", \\\"{x:729,y:757,t:1527016267281};\\\", \\\"{x:726,y:757,t:1527016267297};\\\", \\\"{x:724,y:757,t:1527016267314};\\\", \\\"{x:723,y:757,t:1527016267331};\\\", \\\"{x:720,y:757,t:1527016267546};\\\", \\\"{x:719,y:757,t:1527016267571};\\\", \\\"{x:719,y:756,t:1527016267581};\\\", \\\"{x:716,y:755,t:1527016267598};\\\", \\\"{x:713,y:753,t:1527016267614};\\\", \\\"{x:708,y:749,t:1527016267631};\\\", \\\"{x:701,y:740,t:1527016267648};\\\", \\\"{x:695,y:722,t:1527016267664};\\\", \\\"{x:693,y:695,t:1527016267681};\\\", \\\"{x:693,y:668,t:1527016267697};\\\", \\\"{x:687,y:642,t:1527016267714};\\\", \\\"{x:687,y:620,t:1527016267731};\\\", \\\"{x:668,y:591,t:1527016267748};\\\", \\\"{x:661,y:578,t:1527016267758};\\\", \\\"{x:647,y:561,t:1527016267775};\\\", \\\"{x:637,y:551,t:1527016267792};\\\", \\\"{x:629,y:546,t:1527016267812};\\\", \\\"{x:628,y:546,t:1527016267832};\\\", \\\"{x:627,y:545,t:1527016267845};\\\", \\\"{x:622,y:543,t:1527016267863};\\\", \\\"{x:619,y:542,t:1527016267879};\\\", \\\"{x:618,y:542,t:1527016267895};\\\", \\\"{x:617,y:542,t:1527016267953};\\\", \\\"{x:617,y:544,t:1527016267977};\\\", \\\"{x:614,y:557,t:1527016267995};\\\", \\\"{x:614,y:567,t:1527016268011};\\\", \\\"{x:614,y:570,t:1527016268029};\\\", \\\"{x:614,y:576,t:1527016268046};\\\", \\\"{x:613,y:582,t:1527016268063};\\\", \\\"{x:612,y:584,t:1527016268078};\\\", \\\"{x:611,y:587,t:1527016268096};\\\", \\\"{x:611,y:589,t:1527016268609};\\\", \\\"{x:618,y:594,t:1527016268617};\\\", \\\"{x:627,y:598,t:1527016268629};\\\", \\\"{x:635,y:604,t:1527016268645};\\\", \\\"{x:671,y:620,t:1527016268664};\\\", \\\"{x:701,y:638,t:1527016268678};\\\", \\\"{x:710,y:643,t:1527016268696};\\\", \\\"{x:746,y:670,t:1527016268713};\\\", \\\"{x:766,y:689,t:1527016268729};\\\", \\\"{x:778,y:709,t:1527016268746};\\\", \\\"{x:792,y:735,t:1527016268763};\\\", \\\"{x:801,y:749,t:1527016268779};\\\", \\\"{x:801,y:756,t:1527016268796};\\\", \\\"{x:801,y:761,t:1527016268813};\\\", \\\"{x:801,y:762,t:1527016268829};\\\", \\\"{x:801,y:763,t:1527016268881};\\\", \\\"{x:800,y:765,t:1527016268896};\\\", \\\"{x:796,y:772,t:1527016268912};\\\", \\\"{x:792,y:780,t:1527016268929};\\\", \\\"{x:790,y:791,t:1527016268945};\\\", \\\"{x:789,y:795,t:1527016268963};\\\", \\\"{x:786,y:797,t:1527016268979};\\\", \\\"{x:786,y:799,t:1527016268996};\\\", \\\"{x:785,y:799,t:1527016269346};\\\", \\\"{x:784,y:801,t:1527016274866};\\\", \\\"{x:796,y:813,t:1527016274883};\\\", \\\"{x:808,y:824,t:1527016274899};\\\", \\\"{x:833,y:833,t:1527016274915};\\\", \\\"{x:849,y:841,t:1527016274933};\\\", \\\"{x:869,y:848,t:1527016274949};\\\", \\\"{x:877,y:853,t:1527016274966};\\\", \\\"{x:885,y:855,t:1527016274982};\\\", \\\"{x:891,y:859,t:1527016274998};\\\", \\\"{x:894,y:861,t:1527016275015};\\\", \\\"{x:897,y:861,t:1527016275033};\\\", \\\"{x:907,y:865,t:1527016275050};\\\", \\\"{x:924,y:868,t:1527016275065};\\\", \\\"{x:942,y:872,t:1527016275083};\\\", \\\"{x:953,y:876,t:1527016275099};\\\", \\\"{x:987,y:883,t:1527016275116};\\\", \\\"{x:1008,y:892,t:1527016275133};\\\", \\\"{x:1040,y:899,t:1527016275150};\\\", \\\"{x:1140,y:913,t:1527016275166};\\\", \\\"{x:1230,y:918,t:1527016275183};\\\", \\\"{x:1308,y:918,t:1527016275200};\\\", \\\"{x:1358,y:919,t:1527016275216};\\\", \\\"{x:1419,y:919,t:1527016275232};\\\", \\\"{x:1455,y:915,t:1527016275250};\\\", \\\"{x:1464,y:911,t:1527016275266};\\\", \\\"{x:1466,y:911,t:1527016275283};\\\", \\\"{x:1464,y:911,t:1527016275393};\\\", \\\"{x:1459,y:909,t:1527016275402};\\\", \\\"{x:1458,y:909,t:1527016275415};\\\", \\\"{x:1451,y:905,t:1527016275433};\\\", \\\"{x:1438,y:903,t:1527016275450};\\\", \\\"{x:1432,y:903,t:1527016275466};\\\", \\\"{x:1429,y:903,t:1527016275483};\\\", \\\"{x:1415,y:903,t:1527016275500};\\\", \\\"{x:1408,y:905,t:1527016275516};\\\", \\\"{x:1399,y:907,t:1527016275533};\\\", \\\"{x:1394,y:910,t:1527016275550};\\\", \\\"{x:1390,y:912,t:1527016275566};\\\", \\\"{x:1384,y:913,t:1527016275583};\\\", \\\"{x:1374,y:917,t:1527016275600};\\\", \\\"{x:1372,y:918,t:1527016275616};\\\", \\\"{x:1368,y:922,t:1527016275633};\\\", \\\"{x:1362,y:928,t:1527016275650};\\\", \\\"{x:1362,y:929,t:1527016275666};\\\", \\\"{x:1358,y:934,t:1527016275683};\\\", \\\"{x:1358,y:940,t:1527016275700};\\\", \\\"{x:1358,y:946,t:1527016275715};\\\", \\\"{x:1362,y:952,t:1527016275732};\\\", \\\"{x:1363,y:959,t:1527016275750};\\\", \\\"{x:1365,y:961,t:1527016275766};\\\", \\\"{x:1367,y:964,t:1527016275783};\\\", \\\"{x:1366,y:964,t:1527016275978};\\\", \\\"{x:1365,y:964,t:1527016275994};\\\", \\\"{x:1364,y:967,t:1527016276082};\\\", \\\"{x:1380,y:984,t:1527016276099};\\\", \\\"{x:1387,y:989,t:1527016276117};\\\", \\\"{x:1399,y:992,t:1527016276133};\\\", \\\"{x:1401,y:992,t:1527016276150};\\\", \\\"{x:1402,y:992,t:1527016276166};\\\", \\\"{x:1403,y:992,t:1527016276394};\\\", \\\"{x:1403,y:990,t:1527016276402};\\\", \\\"{x:1403,y:988,t:1527016276418};\\\", \\\"{x:1403,y:987,t:1527016276432};\\\", \\\"{x:1403,y:986,t:1527016276450};\\\", \\\"{x:1403,y:985,t:1527016276498};\\\", \\\"{x:1405,y:983,t:1527016276514};\\\", \\\"{x:1410,y:982,t:1527016276522};\\\", \\\"{x:1413,y:982,t:1527016276533};\\\", \\\"{x:1418,y:979,t:1527016276550};\\\", \\\"{x:1426,y:977,t:1527016276566};\\\", \\\"{x:1434,y:974,t:1527016276583};\\\", \\\"{x:1444,y:974,t:1527016276600};\\\", \\\"{x:1456,y:972,t:1527016276617};\\\", \\\"{x:1477,y:970,t:1527016276632};\\\", \\\"{x:1485,y:968,t:1527016276649};\\\", \\\"{x:1487,y:968,t:1527016276667};\\\", \\\"{x:1487,y:967,t:1527016276683};\\\", \\\"{x:1488,y:967,t:1527016276921};\\\", \\\"{x:1494,y:967,t:1527016276933};\\\", \\\"{x:1504,y:967,t:1527016276949};\\\", \\\"{x:1515,y:964,t:1527016276967};\\\", \\\"{x:1517,y:961,t:1527016276984};\\\", \\\"{x:1523,y:960,t:1527016277000};\\\", \\\"{x:1528,y:960,t:1527016277017};\\\", \\\"{x:1530,y:960,t:1527016277034};\\\", \\\"{x:1537,y:960,t:1527016277178};\\\", \\\"{x:1549,y:960,t:1527016277186};\\\", \\\"{x:1572,y:957,t:1527016277200};\\\", \\\"{x:1675,y:960,t:1527016277217};\\\", \\\"{x:1772,y:961,t:1527016277233};\\\", \\\"{x:1825,y:949,t:1527016277250};\\\", \\\"{x:1889,y:921,t:1527016277267};\\\", \\\"{x:1912,y:908,t:1527016277284};\\\", \\\"{x:1918,y:901,t:1527016277299};\\\", \\\"{x:1919,y:901,t:1527016277329};\\\", \\\"{x:1914,y:901,t:1527016277337};\\\", \\\"{x:1910,y:899,t:1527016277353};\\\", \\\"{x:1903,y:899,t:1527016277369};\\\", \\\"{x:1900,y:899,t:1527016277387};\\\", \\\"{x:1899,y:899,t:1527016277403};\\\", \\\"{x:1898,y:899,t:1527016277424};\\\", \\\"{x:1897,y:899,t:1527016277436};\\\", \\\"{x:1895,y:899,t:1527016277453};\\\", \\\"{x:1886,y:899,t:1527016277469};\\\", \\\"{x:1862,y:891,t:1527016277487};\\\", \\\"{x:1765,y:878,t:1527016277503};\\\", \\\"{x:1658,y:839,t:1527016277519};\\\", \\\"{x:1557,y:817,t:1527016277536};\\\", \\\"{x:1414,y:809,t:1527016277554};\\\", \\\"{x:1375,y:809,t:1527016277572};\\\", \\\"{x:1322,y:798,t:1527016277586};\\\", \\\"{x:1234,y:762,t:1527016277603};\\\", \\\"{x:1130,y:722,t:1527016277619};\\\", \\\"{x:1089,y:711,t:1527016277637};\\\", \\\"{x:1059,y:697,t:1527016277653};\\\", \\\"{x:1041,y:689,t:1527016277670};\\\", \\\"{x:989,y:671,t:1527016277686};\\\", \\\"{x:909,y:653,t:1527016277703};\\\", \\\"{x:828,y:649,t:1527016277720};\\\", \\\"{x:794,y:652,t:1527016277736};\\\", \\\"{x:762,y:651,t:1527016277753};\\\", \\\"{x:753,y:648,t:1527016277769};\\\", \\\"{x:737,y:647,t:1527016277786};\\\", \\\"{x:730,y:647,t:1527016277803};\\\", \\\"{x:726,y:647,t:1527016277820};\\\", \\\"{x:724,y:647,t:1527016277842};\\\", \\\"{x:723,y:647,t:1527016277854};\\\", \\\"{x:723,y:645,t:1527016277912};\\\", \\\"{x:723,y:642,t:1527016277921};\\\", \\\"{x:729,y:637,t:1527016277936};\\\", \\\"{x:756,y:618,t:1527016277953};\\\", \\\"{x:770,y:602,t:1527016277971};\\\", \\\"{x:791,y:589,t:1527016277986};\\\", \\\"{x:807,y:578,t:1527016278004};\\\", \\\"{x:823,y:572,t:1527016278021};\\\", \\\"{x:828,y:566,t:1527016278037};\\\", \\\"{x:831,y:563,t:1527016278053};\\\", \\\"{x:832,y:562,t:1527016278070};\\\", \\\"{x:832,y:561,t:1527016278086};\\\", \\\"{x:833,y:555,t:1527016278103};\\\", \\\"{x:833,y:554,t:1527016278120};\\\", \\\"{x:834,y:550,t:1527016278136};\\\", \\\"{x:835,y:548,t:1527016278154};\\\", \\\"{x:835,y:547,t:1527016278170};\\\", \\\"{x:835,y:544,t:1527016278186};\\\", \\\"{x:835,y:542,t:1527016278204};\\\", \\\"{x:835,y:540,t:1527016278225};\\\", \\\"{x:835,y:536,t:1527016278237};\\\", \\\"{x:836,y:533,t:1527016278253};\\\", \\\"{x:840,y:527,t:1527016278270};\\\", \\\"{x:842,y:522,t:1527016278286};\\\", \\\"{x:843,y:520,t:1527016278303};\\\", \\\"{x:843,y:517,t:1527016278320};\\\", \\\"{x:846,y:514,t:1527016278338};\\\", \\\"{x:846,y:512,t:1527016278353};\\\", \\\"{x:846,y:511,t:1527016278371};\\\", \\\"{x:846,y:510,t:1527016278569};\\\", \\\"{x:846,y:511,t:1527016278576};\\\", \\\"{x:845,y:511,t:1527016278587};\\\", \\\"{x:844,y:512,t:1527016278604};\\\", \\\"{x:843,y:512,t:1527016278921};\\\", \\\"{x:844,y:516,t:1527016278937};\\\", \\\"{x:846,y:531,t:1527016278955};\\\", \\\"{x:850,y:540,t:1527016278970};\\\", \\\"{x:855,y:561,t:1527016278988};\\\", \\\"{x:859,y:569,t:1527016279004};\\\", \\\"{x:872,y:595,t:1527016279021};\\\", \\\"{x:894,y:631,t:1527016279037};\\\", \\\"{x:909,y:654,t:1527016279055};\\\", \\\"{x:921,y:666,t:1527016279071};\\\", \\\"{x:932,y:680,t:1527016279087};\\\", \\\"{x:937,y:686,t:1527016279104};\\\", \\\"{x:941,y:696,t:1527016279121};\\\", \\\"{x:946,y:712,t:1527016279138};\\\", \\\"{x:948,y:723,t:1527016279154};\\\", \\\"{x:949,y:729,t:1527016279171};\\\", \\\"{x:950,y:732,t:1527016279187};\\\", \\\"{x:950,y:734,t:1527016279204};\\\", \\\"{x:949,y:737,t:1527016279222};\\\", \\\"{x:949,y:738,t:1527016279237};\\\", \\\"{x:947,y:739,t:1527016279255};\\\", \\\"{x:946,y:740,t:1527016279289};\\\", \\\"{x:942,y:741,t:1527016279314};\\\", \\\"{x:940,y:742,t:1527016279330};\\\", \\\"{x:938,y:744,t:1527016279338};\\\", \\\"{x:937,y:746,t:1527016279354};\\\", \\\"{x:932,y:748,t:1527016279371};\\\", \\\"{x:928,y:754,t:1527016279388};\\\", \\\"{x:923,y:758,t:1527016279405};\\\", \\\"{x:915,y:763,t:1527016279422};\\\", \\\"{x:910,y:769,t:1527016279438};\\\", \\\"{x:906,y:772,t:1527016279455};\\\", \\\"{x:899,y:777,t:1527016279472};\\\", \\\"{x:897,y:777,t:1527016279488};\\\", \\\"{x:893,y:775,t:1527016279505};\\\", \\\"{x:890,y:774,t:1527016279522};\\\", \\\"{x:895,y:778,t:1527016279962};\\\", \\\"{x:900,y:787,t:1527016279972};\\\", \\\"{x:919,y:801,t:1527016279989};\\\", \\\"{x:940,y:813,t:1527016280006};\\\", \\\"{x:956,y:829,t:1527016280021};\\\", \\\"{x:973,y:837,t:1527016280039};\\\", \\\"{x:1012,y:854,t:1527016280056};\\\", \\\"{x:1052,y:860,t:1527016280072};\\\", \\\"{x:1078,y:863,t:1527016280089};\\\", \\\"{x:1110,y:868,t:1527016280105};\\\", \\\"{x:1126,y:869,t:1527016280122};\\\", \\\"{x:1136,y:870,t:1527016280139};\\\", \\\"{x:1138,y:870,t:1527016280156};\\\", \\\"{x:1144,y:868,t:1527016280173};\\\", \\\"{x:1145,y:867,t:1527016280234};\\\", \\\"{x:1146,y:867,t:1527016280249};\\\", \\\"{x:1147,y:866,t:1527016280265};\\\", \\\"{x:1151,y:864,t:1527016280274};\\\", \\\"{x:1155,y:863,t:1527016280289};\\\", \\\"{x:1166,y:859,t:1527016280306};\\\", \\\"{x:1177,y:858,t:1527016280322};\\\", \\\"{x:1194,y:855,t:1527016280338};\\\", \\\"{x:1200,y:855,t:1527016280356};\\\", \\\"{x:1226,y:860,t:1527016280373};\\\", \\\"{x:1258,y:868,t:1527016280388};\\\", \\\"{x:1312,y:871,t:1527016280405};\\\", \\\"{x:1368,y:878,t:1527016280423};\\\", \\\"{x:1389,y:874,t:1527016280439};\\\", \\\"{x:1406,y:872,t:1527016280456};\\\", \\\"{x:1407,y:870,t:1527016280473};\\\", \\\"{x:1410,y:870,t:1527016280488};\\\", \\\"{x:1409,y:872,t:1527016280650};\\\", \\\"{x:1409,y:873,t:1527016280657};\\\", \\\"{x:1406,y:876,t:1527016280673};\\\", \\\"{x:1398,y:884,t:1527016280690};\\\", \\\"{x:1392,y:889,t:1527016280706};\\\", \\\"{x:1387,y:892,t:1527016280723};\\\", \\\"{x:1385,y:892,t:1527016280740};\\\", \\\"{x:1384,y:892,t:1527016280761};\\\", \\\"{x:1384,y:893,t:1527016281058};\\\", \\\"{x:1382,y:894,t:1527016281106};\\\", \\\"{x:1379,y:895,t:1527016281123};\\\", \\\"{x:1374,y:896,t:1527016281140};\\\", \\\"{x:1373,y:896,t:1527016281157};\\\", \\\"{x:1371,y:898,t:1527016281173};\\\", \\\"{x:1370,y:899,t:1527016281234};\\\", \\\"{x:1369,y:899,t:1527016281242};\\\", \\\"{x:1366,y:901,t:1527016281257};\\\", \\\"{x:1364,y:903,t:1527016281273};\\\", \\\"{x:1360,y:905,t:1527016281290};\\\", \\\"{x:1359,y:906,t:1527016281307};\\\", \\\"{x:1357,y:906,t:1527016281324};\\\", \\\"{x:1356,y:906,t:1527016281346};\\\", \\\"{x:1355,y:906,t:1527016281418};\\\", \\\"{x:1351,y:906,t:1527016281866};\\\", \\\"{x:1350,y:906,t:1527016281874};\\\", \\\"{x:1345,y:906,t:1527016281891};\\\", \\\"{x:1343,y:906,t:1527016281914};\\\", \\\"{x:1342,y:906,t:1527016281924};\\\", \\\"{x:1338,y:906,t:1527016281941};\\\", \\\"{x:1336,y:905,t:1527016281957};\\\", \\\"{x:1334,y:905,t:1527016282034};\\\", \\\"{x:1332,y:905,t:1527016282041};\\\", \\\"{x:1332,y:904,t:1527016282057};\\\", \\\"{x:1330,y:904,t:1527016282074};\\\", \\\"{x:1327,y:902,t:1527016282106};\\\", \\\"{x:1325,y:900,t:1527016282113};\\\", \\\"{x:1321,y:897,t:1527016282124};\\\", \\\"{x:1305,y:885,t:1527016282141};\\\", \\\"{x:1292,y:873,t:1527016282158};\\\", \\\"{x:1292,y:872,t:1527016282174};\\\", \\\"{x:1289,y:870,t:1527016282191};\\\", \\\"{x:1288,y:868,t:1527016282208};\\\", \\\"{x:1288,y:866,t:1527016282224};\\\", \\\"{x:1285,y:861,t:1527016282241};\\\", \\\"{x:1285,y:858,t:1527016282257};\\\", \\\"{x:1284,y:854,t:1527016282274};\\\", \\\"{x:1281,y:850,t:1527016282291};\\\", \\\"{x:1281,y:849,t:1527016282314};\\\", \\\"{x:1281,y:848,t:1527016282324};\\\", \\\"{x:1280,y:847,t:1527016282341};\\\", \\\"{x:1279,y:846,t:1527016282358};\\\", \\\"{x:1279,y:844,t:1527016282378};\\\", \\\"{x:1279,y:841,t:1527016282391};\\\", \\\"{x:1279,y:839,t:1527016282408};\\\", \\\"{x:1279,y:837,t:1527016282425};\\\", \\\"{x:1279,y:836,t:1527016282440};\\\", \\\"{x:1279,y:835,t:1527016282836};\\\", \\\"{x:1279,y:829,t:1527016282841};\\\", \\\"{x:1282,y:822,t:1527016282858};\\\", \\\"{x:1286,y:819,t:1527016282875};\\\", \\\"{x:1296,y:810,t:1527016282892};\\\", \\\"{x:1298,y:808,t:1527016282907};\\\", \\\"{x:1299,y:808,t:1527016283210};\\\", \\\"{x:1301,y:806,t:1527016283225};\\\", \\\"{x:1306,y:726,t:1527016283242};\\\", \\\"{x:1318,y:629,t:1527016283259};\\\", \\\"{x:1317,y:542,t:1527016283276};\\\", \\\"{x:1317,y:487,t:1527016283292};\\\", \\\"{x:1322,y:463,t:1527016283309};\\\", \\\"{x:1324,y:455,t:1527016283325};\\\", \\\"{x:1326,y:452,t:1527016283342};\\\", \\\"{x:1326,y:451,t:1527016283376};\\\", \\\"{x:1327,y:450,t:1527016283391};\\\", \\\"{x:1327,y:448,t:1527016283408};\\\", \\\"{x:1327,y:445,t:1527016283425};\\\", \\\"{x:1329,y:439,t:1527016283442};\\\", \\\"{x:1329,y:431,t:1527016283458};\\\", \\\"{x:1329,y:426,t:1527016283475};\\\", \\\"{x:1323,y:430,t:1527016283530};\\\", \\\"{x:1315,y:441,t:1527016283543};\\\", \\\"{x:1309,y:455,t:1527016283559};\\\", \\\"{x:1305,y:462,t:1527016283576};\\\", \\\"{x:1303,y:466,t:1527016283592};\\\", \\\"{x:1303,y:469,t:1527016283609};\\\", \\\"{x:1303,y:470,t:1527016283818};\\\", \\\"{x:1304,y:473,t:1527016283826};\\\", \\\"{x:1305,y:478,t:1527016283842};\\\", \\\"{x:1305,y:481,t:1527016283859};\\\", \\\"{x:1305,y:483,t:1527016283876};\\\", \\\"{x:1305,y:486,t:1527016283891};\\\", \\\"{x:1305,y:487,t:1527016283962};\\\", \\\"{x:1305,y:490,t:1527016283977};\\\", \\\"{x:1305,y:492,t:1527016283992};\\\", \\\"{x:1305,y:494,t:1527016284009};\\\", \\\"{x:1305,y:497,t:1527016284025};\\\", \\\"{x:1305,y:502,t:1527016284043};\\\", \\\"{x:1304,y:514,t:1527016284058};\\\", \\\"{x:1304,y:528,t:1527016284075};\\\", \\\"{x:1303,y:539,t:1527016284092};\\\", \\\"{x:1303,y:552,t:1527016284109};\\\", \\\"{x:1302,y:566,t:1527016284126};\\\", \\\"{x:1302,y:582,t:1527016284143};\\\", \\\"{x:1304,y:593,t:1527016284158};\\\", \\\"{x:1297,y:612,t:1527016284175};\\\", \\\"{x:1284,y:643,t:1527016284193};\\\", \\\"{x:1275,y:658,t:1527016284209};\\\", \\\"{x:1271,y:663,t:1527016284225};\\\", \\\"{x:1270,y:664,t:1527016284243};\\\", \\\"{x:1272,y:664,t:1527016284450};\\\", \\\"{x:1276,y:661,t:1527016284466};\\\", \\\"{x:1282,y:657,t:1527016284476};\\\", \\\"{x:1289,y:654,t:1527016284493};\\\", \\\"{x:1294,y:650,t:1527016284510};\\\", \\\"{x:1297,y:647,t:1527016284526};\\\", \\\"{x:1299,y:646,t:1527016284543};\\\", \\\"{x:1300,y:645,t:1527016284560};\\\", \\\"{x:1301,y:644,t:1527016284634};\\\", \\\"{x:1302,y:644,t:1527016284722};\\\", \\\"{x:1304,y:643,t:1527016284730};\\\", \\\"{x:1308,y:641,t:1527016284743};\\\", \\\"{x:1318,y:636,t:1527016284760};\\\", \\\"{x:1327,y:633,t:1527016284778};\\\", \\\"{x:1329,y:631,t:1527016284793};\\\", \\\"{x:1333,y:631,t:1527016284810};\\\", \\\"{x:1339,y:631,t:1527016284827};\\\", \\\"{x:1341,y:631,t:1527016284843};\\\", \\\"{x:1342,y:631,t:1527016284865};\\\", \\\"{x:1344,y:630,t:1527016284890};\\\", \\\"{x:1344,y:629,t:1527016284898};\\\", \\\"{x:1346,y:629,t:1527016284914};\\\", \\\"{x:1347,y:628,t:1527016284929};\\\", \\\"{x:1350,y:628,t:1527016284946};\\\", \\\"{x:1351,y:628,t:1527016284960};\\\", \\\"{x:1363,y:628,t:1527016284977};\\\", \\\"{x:1367,y:628,t:1527016284994};\\\", \\\"{x:1368,y:628,t:1527016285010};\\\", \\\"{x:1379,y:628,t:1527016285027};\\\", \\\"{x:1394,y:626,t:1527016285043};\\\", \\\"{x:1397,y:626,t:1527016285060};\\\", \\\"{x:1398,y:626,t:1527016285077};\\\", \\\"{x:1399,y:626,t:1527016285094};\\\", \\\"{x:1395,y:626,t:1527016285241};\\\", \\\"{x:1386,y:626,t:1527016285250};\\\", \\\"{x:1382,y:626,t:1527016285260};\\\", \\\"{x:1380,y:626,t:1527016285290};\\\", \\\"{x:1383,y:626,t:1527016285634};\\\", \\\"{x:1386,y:626,t:1527016285650};\\\", \\\"{x:1390,y:626,t:1527016285661};\\\", \\\"{x:1392,y:626,t:1527016285677};\\\", \\\"{x:1396,y:626,t:1527016285694};\\\", \\\"{x:1402,y:626,t:1527016285711};\\\", \\\"{x:1416,y:626,t:1527016285727};\\\", \\\"{x:1431,y:626,t:1527016285744};\\\", \\\"{x:1439,y:626,t:1527016285761};\\\", \\\"{x:1441,y:627,t:1527016285778};\\\", \\\"{x:1444,y:628,t:1527016285801};\\\", \\\"{x:1446,y:629,t:1527016285811};\\\", \\\"{x:1447,y:629,t:1527016285890};\\\", \\\"{x:1448,y:629,t:1527016286842};\\\", \\\"{x:1449,y:629,t:1527016286858};\\\", \\\"{x:1449,y:630,t:1527016286865};\\\", \\\"{x:1446,y:630,t:1527016286879};\\\", \\\"{x:1433,y:628,t:1527016286896};\\\", \\\"{x:1427,y:627,t:1527016286912};\\\", \\\"{x:1416,y:627,t:1527016286929};\\\", \\\"{x:1413,y:628,t:1527016286945};\\\", \\\"{x:1412,y:628,t:1527016286962};\\\", \\\"{x:1410,y:628,t:1527016286980};\\\", \\\"{x:1405,y:628,t:1527016286995};\\\", \\\"{x:1404,y:628,t:1527016287012};\\\", \\\"{x:1398,y:628,t:1527016287029};\\\", \\\"{x:1391,y:634,t:1527016287045};\\\", \\\"{x:1387,y:634,t:1527016287062};\\\", \\\"{x:1385,y:635,t:1527016287079};\\\", \\\"{x:1384,y:635,t:1527016287098};\\\", \\\"{x:1382,y:635,t:1527016287112};\\\", \\\"{x:1378,y:637,t:1527016287129};\\\", \\\"{x:1375,y:638,t:1527016287145};\\\", \\\"{x:1374,y:639,t:1527016287162};\\\", \\\"{x:1372,y:640,t:1527016287178};\\\", \\\"{x:1363,y:649,t:1527016287194};\\\", \\\"{x:1358,y:653,t:1527016287211};\\\", \\\"{x:1354,y:660,t:1527016287229};\\\", \\\"{x:1349,y:669,t:1527016287244};\\\", \\\"{x:1346,y:671,t:1527016287262};\\\", \\\"{x:1346,y:673,t:1527016287279};\\\", \\\"{x:1344,y:673,t:1527016287296};\\\", \\\"{x:1343,y:673,t:1527016287320};\\\", \\\"{x:1343,y:676,t:1527016287425};\\\", \\\"{x:1343,y:680,t:1527016287433};\\\", \\\"{x:1343,y:683,t:1527016287446};\\\", \\\"{x:1347,y:701,t:1527016287463};\\\", \\\"{x:1353,y:713,t:1527016287478};\\\", \\\"{x:1354,y:719,t:1527016287496};\\\", \\\"{x:1354,y:722,t:1527016287512};\\\", \\\"{x:1353,y:727,t:1527016287529};\\\", \\\"{x:1352,y:735,t:1527016287546};\\\", \\\"{x:1351,y:743,t:1527016287562};\\\", \\\"{x:1351,y:746,t:1527016287585};\\\", \\\"{x:1350,y:752,t:1527016287596};\\\", \\\"{x:1350,y:756,t:1527016287611};\\\", \\\"{x:1350,y:764,t:1527016287629};\\\", \\\"{x:1351,y:779,t:1527016287646};\\\", \\\"{x:1347,y:791,t:1527016287662};\\\", \\\"{x:1345,y:795,t:1527016287679};\\\", \\\"{x:1343,y:803,t:1527016287696};\\\", \\\"{x:1340,y:809,t:1527016287713};\\\", \\\"{x:1335,y:822,t:1527016287728};\\\", \\\"{x:1328,y:832,t:1527016287746};\\\", \\\"{x:1327,y:840,t:1527016287763};\\\", \\\"{x:1327,y:844,t:1527016287779};\\\", \\\"{x:1327,y:848,t:1527016287796};\\\", \\\"{x:1332,y:854,t:1527016288153};\\\", \\\"{x:1337,y:861,t:1527016288163};\\\", \\\"{x:1340,y:864,t:1527016288180};\\\", \\\"{x:1343,y:872,t:1527016288196};\\\", \\\"{x:1348,y:881,t:1527016288213};\\\", \\\"{x:1353,y:894,t:1527016288231};\\\", \\\"{x:1362,y:912,t:1527016288247};\\\", \\\"{x:1370,y:936,t:1527016288263};\\\", \\\"{x:1378,y:957,t:1527016288281};\\\", \\\"{x:1384,y:972,t:1527016288297};\\\", \\\"{x:1384,y:973,t:1527016288314};\\\", \\\"{x:1384,y:974,t:1527016288361};\\\", \\\"{x:1384,y:975,t:1527016288393};\\\", \\\"{x:1386,y:974,t:1527016288521};\\\", \\\"{x:1389,y:973,t:1527016288530};\\\", \\\"{x:1392,y:971,t:1527016288547};\\\", \\\"{x:1395,y:968,t:1527016288563};\\\", \\\"{x:1396,y:968,t:1527016288580};\\\", \\\"{x:1398,y:967,t:1527016288597};\\\", \\\"{x:1399,y:967,t:1527016288826};\\\", \\\"{x:1399,y:966,t:1527016288841};\\\", \\\"{x:1400,y:966,t:1527016288849};\\\", \\\"{x:1401,y:965,t:1527016288864};\\\", \\\"{x:1402,y:965,t:1527016288880};\\\", \\\"{x:1404,y:964,t:1527016288897};\\\", \\\"{x:1405,y:964,t:1527016288914};\\\", \\\"{x:1407,y:964,t:1527016288945};\\\", \\\"{x:1409,y:964,t:1527016288961};\\\", \\\"{x:1412,y:964,t:1527016288970};\\\", \\\"{x:1417,y:964,t:1527016288980};\\\", \\\"{x:1431,y:964,t:1527016288997};\\\", \\\"{x:1445,y:963,t:1527016289014};\\\", \\\"{x:1457,y:963,t:1527016289030};\\\", \\\"{x:1470,y:960,t:1527016289048};\\\", \\\"{x:1471,y:960,t:1527016289065};\\\", \\\"{x:1472,y:959,t:1527016289080};\\\", \\\"{x:1473,y:959,t:1527016289097};\\\", \\\"{x:1475,y:959,t:1527016289154};\\\", \\\"{x:1477,y:958,t:1527016289165};\\\", \\\"{x:1479,y:957,t:1527016289181};\\\", \\\"{x:1484,y:957,t:1527016289362};\\\", \\\"{x:1491,y:957,t:1527016289370};\\\", \\\"{x:1493,y:957,t:1527016289385};\\\", \\\"{x:1494,y:957,t:1527016289397};\\\", \\\"{x:1502,y:958,t:1527016289415};\\\", \\\"{x:1504,y:960,t:1527016289431};\\\", \\\"{x:1510,y:960,t:1527016289448};\\\", \\\"{x:1519,y:959,t:1527016289626};\\\", \\\"{x:1530,y:959,t:1527016289633};\\\", \\\"{x:1547,y:958,t:1527016289648};\\\", \\\"{x:1549,y:958,t:1527016289664};\\\", \\\"{x:1584,y:965,t:1527016289682};\\\", \\\"{x:1595,y:971,t:1527016289699};\\\", \\\"{x:1598,y:972,t:1527016289714};\\\", \\\"{x:1605,y:973,t:1527016289731};\\\", \\\"{x:1608,y:976,t:1527016289748};\\\", \\\"{x:1609,y:976,t:1527016290993};\\\", \\\"{x:1608,y:976,t:1527016291001};\\\", \\\"{x:1606,y:976,t:1527016291015};\\\", \\\"{x:1605,y:976,t:1527016291058};\\\", \\\"{x:1604,y:976,t:1527016291073};\\\", \\\"{x:1603,y:976,t:1527016291114};\\\", \\\"{x:1601,y:976,t:1527016291137};\\\", \\\"{x:1600,y:976,t:1527016291149};\\\", \\\"{x:1596,y:975,t:1527016291166};\\\", \\\"{x:1593,y:975,t:1527016291186};\\\", \\\"{x:1586,y:973,t:1527016291199};\\\", \\\"{x:1578,y:973,t:1527016291216};\\\", \\\"{x:1564,y:970,t:1527016291232};\\\", \\\"{x:1548,y:964,t:1527016291250};\\\", \\\"{x:1534,y:957,t:1527016291265};\\\", \\\"{x:1530,y:952,t:1527016291282};\\\", \\\"{x:1523,y:947,t:1527016291299};\\\", \\\"{x:1516,y:944,t:1527016291316};\\\", \\\"{x:1505,y:939,t:1527016291333};\\\", \\\"{x:1498,y:937,t:1527016291350};\\\", \\\"{x:1485,y:931,t:1527016291366};\\\", \\\"{x:1479,y:925,t:1527016291382};\\\", \\\"{x:1463,y:920,t:1527016291400};\\\", \\\"{x:1444,y:914,t:1527016291417};\\\", \\\"{x:1433,y:910,t:1527016291434};\\\", \\\"{x:1426,y:910,t:1527016291449};\\\", \\\"{x:1423,y:909,t:1527016291467};\\\", \\\"{x:1419,y:908,t:1527016291483};\\\", \\\"{x:1416,y:906,t:1527016291499};\\\", \\\"{x:1415,y:905,t:1527016291529};\\\", \\\"{x:1414,y:904,t:1527016291545};\\\", \\\"{x:1412,y:902,t:1527016291570};\\\", \\\"{x:1408,y:901,t:1527016291583};\\\", \\\"{x:1404,y:898,t:1527016291599};\\\", \\\"{x:1399,y:897,t:1527016291617};\\\", \\\"{x:1390,y:893,t:1527016291633};\\\", \\\"{x:1388,y:892,t:1527016291649};\\\", \\\"{x:1385,y:890,t:1527016291667};\\\", \\\"{x:1384,y:890,t:1527016291689};\\\", \\\"{x:1382,y:890,t:1527016291746};\\\", \\\"{x:1382,y:889,t:1527016291754};\\\", \\\"{x:1380,y:889,t:1527016291766};\\\", \\\"{x:1378,y:888,t:1527016291783};\\\", \\\"{x:1377,y:887,t:1527016291799};\\\", \\\"{x:1375,y:887,t:1527016291817};\\\", \\\"{x:1375,y:886,t:1527016291840};\\\", \\\"{x:1374,y:884,t:1527016291993};\\\", \\\"{x:1373,y:884,t:1527016292001};\\\", \\\"{x:1371,y:884,t:1527016292016};\\\", \\\"{x:1368,y:884,t:1527016292034};\\\", \\\"{x:1363,y:884,t:1527016292050};\\\", \\\"{x:1362,y:884,t:1527016292066};\\\", \\\"{x:1362,y:883,t:1527016292104};\\\", \\\"{x:1362,y:882,t:1527016292249};\\\", \\\"{x:1361,y:881,t:1527016292273};\\\", \\\"{x:1361,y:879,t:1527016292283};\\\", \\\"{x:1358,y:873,t:1527016292300};\\\", \\\"{x:1358,y:872,t:1527016292317};\\\", \\\"{x:1357,y:871,t:1527016292466};\\\", \\\"{x:1355,y:871,t:1527016292521};\\\", \\\"{x:1354,y:871,t:1527016292577};\\\", \\\"{x:1350,y:871,t:1527016292617};\\\", \\\"{x:1342,y:870,t:1527016292634};\\\", \\\"{x:1335,y:870,t:1527016292650};\\\", \\\"{x:1316,y:871,t:1527016292666};\\\", \\\"{x:1302,y:883,t:1527016292684};\\\", \\\"{x:1289,y:890,t:1527016292700};\\\", \\\"{x:1267,y:900,t:1527016292716};\\\", \\\"{x:1264,y:908,t:1527016292733};\\\", \\\"{x:1263,y:908,t:1527016292750};\\\", \\\"{x:1263,y:910,t:1527016292767};\\\", \\\"{x:1263,y:911,t:1527016292785};\\\", \\\"{x:1263,y:913,t:1527016292800};\\\", \\\"{x:1263,y:914,t:1527016292817};\\\", \\\"{x:1254,y:919,t:1527016292834};\\\", \\\"{x:1250,y:919,t:1527016292850};\\\", \\\"{x:1249,y:919,t:1527016292867};\\\", \\\"{x:1246,y:919,t:1527016292885};\\\", \\\"{x:1244,y:919,t:1527016292900};\\\", \\\"{x:1231,y:912,t:1527016292917};\\\", \\\"{x:1214,y:902,t:1527016292935};\\\", \\\"{x:1201,y:894,t:1527016292950};\\\", \\\"{x:1193,y:887,t:1527016292968};\\\", \\\"{x:1178,y:879,t:1527016292985};\\\", \\\"{x:1165,y:871,t:1527016293002};\\\", \\\"{x:1159,y:867,t:1527016293018};\\\", \\\"{x:1139,y:856,t:1527016293034};\\\", \\\"{x:1075,y:826,t:1527016293051};\\\", \\\"{x:1063,y:819,t:1527016293067};\\\", \\\"{x:1004,y:803,t:1527016293084};\\\", \\\"{x:931,y:792,t:1527016293102};\\\", \\\"{x:876,y:787,t:1527016293117};\\\", \\\"{x:848,y:782,t:1527016293134};\\\", \\\"{x:834,y:779,t:1527016293151};\\\", \\\"{x:804,y:766,t:1527016293168};\\\", \\\"{x:770,y:750,t:1527016293184};\\\", \\\"{x:745,y:738,t:1527016293201};\\\", \\\"{x:727,y:736,t:1527016293217};\\\", \\\"{x:692,y:730,t:1527016293234};\\\", \\\"{x:662,y:727,t:1527016293252};\\\", \\\"{x:612,y:727,t:1527016293267};\\\", \\\"{x:582,y:727,t:1527016293284};\\\", \\\"{x:542,y:727,t:1527016293302};\\\", \\\"{x:518,y:727,t:1527016293317};\\\", \\\"{x:474,y:727,t:1527016293334};\\\", \\\"{x:460,y:727,t:1527016293346};\\\", \\\"{x:449,y:728,t:1527016293364};\\\", \\\"{x:447,y:730,t:1527016293379};\\\", \\\"{x:448,y:726,t:1527016293513};\\\", \\\"{x:450,y:726,t:1527016293530};\\\", \\\"{x:451,y:725,t:1527016293560};\\\", \\\"{x:453,y:725,t:1527016293568};\\\", \\\"{x:453,y:724,t:1527016293584};\\\", \\\"{x:454,y:723,t:1527016293597};\\\", \\\"{x:455,y:723,t:1527016293625};\\\", \\\"{x:457,y:722,t:1527016293633};\\\", \\\"{x:460,y:720,t:1527016293647};\\\", \\\"{x:464,y:717,t:1527016293664};\\\", \\\"{x:477,y:712,t:1527016293681};\\\", \\\"{x:477,y:711,t:1527016293697};\\\", \\\"{x:479,y:710,t:1527016300321};\\\", \\\"{x:492,y:710,t:1527016300334};\\\", \\\"{x:512,y:716,t:1527016300351};\\\", \\\"{x:557,y:730,t:1527016300368};\\\", \\\"{x:567,y:732,t:1527016300385};\\\", \\\"{x:562,y:732,t:1527016300529};\\\", \\\"{x:557,y:732,t:1527016300537};\\\", \\\"{x:556,y:732,t:1527016300554};\\\", \\\"{x:555,y:733,t:1527016300571};\\\", \\\"{x:551,y:735,t:1527016300588};\\\", \\\"{x:548,y:735,t:1527016300605};\\\", \\\"{x:547,y:735,t:1527016300621};\\\", \\\"{x:546,y:735,t:1527016300857};\\\", \\\"{x:542,y:732,t:1527016300871};\\\", \\\"{x:538,y:724,t:1527016300888};\\\", \\\"{x:534,y:721,t:1527016300905};\\\", \\\"{x:534,y:719,t:1527016300922};\\\", \\\"{x:533,y:717,t:1527016300938};\\\", \\\"{x:531,y:713,t:1527016300955};\\\", \\\"{x:529,y:710,t:1527016300971};\\\", \\\"{x:526,y:709,t:1527016300988};\\\", \\\"{x:528,y:709,t:1527016301657};\\\", \\\"{x:531,y:709,t:1527016301673};\\\", \\\"{x:532,y:710,t:1527016301689};\\\", \\\"{x:536,y:712,t:1527016301705};\\\", \\\"{x:544,y:719,t:1527016301722};\\\", \\\"{x:560,y:725,t:1527016301739};\\\", \\\"{x:569,y:731,t:1527016301755};\\\", \\\"{x:580,y:738,t:1527016301772};\\\", \\\"{x:590,y:740,t:1527016301789};\\\", \\\"{x:593,y:742,t:1527016301805};\\\", \\\"{x:600,y:744,t:1527016301822};\\\", \\\"{x:602,y:744,t:1527016301839};\\\", \\\"{x:606,y:745,t:1527016301856};\\\", \\\"{x:607,y:745,t:1527016301897};\\\" ] }, { \\\"rt\\\": 129807, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 9, \\\"time_elapsed\\\": 470793, \\\"internal_node_id\\\": \\\"0.0-5.0-4.0\\\", \\\"subject\\\": \\\"6Y93F\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"foxtrot\\\", \\\"condition\\\": \\\"111\\\", \\\"scenario\\\": \\\"acme\\\", \\\"question\\\": \\\"midpoint\\\", \\\"q\\\": 5, \\\"clicks\\\": 2, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XInside-YFull\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 0, \\\"answer\\\": [ \\\"O\\\", \\\"F\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"X \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"U \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"\\\", \\\"block\\\": \\\"triangular_scaffolded\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:608,y:745,t:1527016303354};\\\", \\\"{x:610,y:747,t:1527016303393};\\\", \\\"{x:615,y:750,t:1527016303407};\\\", \\\"{x:626,y:755,t:1527016303423};\\\", \\\"{x:651,y:763,t:1527016303441};\\\", \\\"{x:655,y:765,t:1527016303457};\\\", \\\"{x:664,y:765,t:1527016303474};\\\", \\\"{x:666,y:765,t:1527016303491};\\\", \\\"{x:670,y:765,t:1527016303507};\\\", \\\"{x:673,y:765,t:1527016303523};\\\", \\\"{x:674,y:765,t:1527016303553};\\\", \\\"{x:675,y:764,t:1527016312132};\\\", \\\"{x:675,y:763,t:1527016312140};\\\", \\\"{x:675,y:762,t:1527016312165};\\\", \\\"{x:675,y:763,t:1527016412278};\\\", \\\"{x:673,y:768,t:1527016412296};\\\", \\\"{x:672,y:768,t:1527016412312};\\\", \\\"{x:652,y:754,t:1527016412329};\\\", \\\"{x:607,y:723,t:1527016412346};\\\", \\\"{x:515,y:677,t:1527016412362};\\\", \\\"{x:411,y:636,t:1527016412379};\\\", \\\"{x:324,y:591,t:1527016412396};\\\", \\\"{x:302,y:574,t:1527016412418};\\\", \\\"{x:289,y:567,t:1527016412434};\\\", \\\"{x:284,y:564,t:1527016412451};\\\", \\\"{x:281,y:561,t:1527016412468};\\\", \\\"{x:277,y:558,t:1527016412485};\\\", \\\"{x:276,y:556,t:1527016412502};\\\", \\\"{x:275,y:555,t:1527016412605};\\\", \\\"{x:275,y:554,t:1527016412618};\\\", \\\"{x:277,y:554,t:1527016412646};\\\", \\\"{x:281,y:554,t:1527016412654};\\\", \\\"{x:286,y:557,t:1527016412668};\\\", \\\"{x:296,y:561,t:1527016412685};\\\", \\\"{x:300,y:563,t:1527016412702};\\\", \\\"{x:308,y:567,t:1527016412718};\\\", \\\"{x:321,y:573,t:1527016412735};\\\", \\\"{x:336,y:578,t:1527016412752};\\\", \\\"{x:349,y:585,t:1527016412768};\\\", \\\"{x:360,y:589,t:1527016412785};\\\", \\\"{x:370,y:589,t:1527016412801};\\\", \\\"{x:373,y:592,t:1527016412818};\\\", \\\"{x:374,y:592,t:1527016412835};\\\", \\\"{x:374,y:591,t:1527016412998};\\\", \\\"{x:374,y:589,t:1527016413005};\\\", \\\"{x:374,y:588,t:1527016413019};\\\", \\\"{x:374,y:584,t:1527016413035};\\\", \\\"{x:375,y:581,t:1527016413052};\\\", \\\"{x:375,y:581,t:1527016413175};\\\", \\\"{x:381,y:581,t:1527016413486};\\\", \\\"{x:391,y:583,t:1527016413502};\\\", \\\"{x:409,y:595,t:1527016413519};\\\", \\\"{x:428,y:609,t:1527016413536};\\\", \\\"{x:449,y:624,t:1527016413553};\\\", \\\"{x:449,y:625,t:1527016413568};\\\", \\\"{x:453,y:632,t:1527016413586};\\\", \\\"{x:489,y:659,t:1527016413604};\\\", \\\"{x:496,y:665,t:1527016413619};\\\", \\\"{x:506,y:680,t:1527016413636};\\\", \\\"{x:511,y:688,t:1527016413653};\\\", \\\"{x:512,y:691,t:1527016413669};\\\", \\\"{x:512,y:695,t:1527016413686};\\\", \\\"{x:500,y:633,t:1527016414357};\\\", \\\"{x:493,y:560,t:1527016414370};\\\", \\\"{x:482,y:500,t:1527016414387};\\\", \\\"{x:482,y:499,t:1527016414403};\\\", \\\"{x:465,y:496,t:1527016428941};\\\", \\\"{x:449,y:496,t:1527016428950};\\\", \\\"{x:404,y:528,t:1527016428968};\\\", \\\"{x:378,y:548,t:1527016428985};\\\", \\\"{x:297,y:627,t:1527016429001};\\\", \\\"{x:220,y:733,t:1527016429014};\\\", \\\"{x:144,y:853,t:1527016429031};\\\", \\\"{x:97,y:938,t:1527016429048};\\\", \\\"{x:96,y:944,t:1527016429325};\\\", \\\"{x:80,y:964,t:1527016429333};\\\", \\\"{x:76,y:970,t:1527016429348};\\\", \\\"{x:62,y:990,t:1527016429365};\\\", \\\"{x:60,y:993,t:1527016429381};\\\", \\\"{x:67,y:993,t:1527016429421};\\\", \\\"{x:72,y:993,t:1527016429431};\\\", \\\"{x:102,y:971,t:1527016429448};\\\", \\\"{x:143,y:931,t:1527016429465};\\\", \\\"{x:202,y:840,t:1527016429481};\\\", \\\"{x:244,y:756,t:1527016429498};\\\", \\\"{x:267,y:710,t:1527016429515};\\\", \\\"{x:291,y:668,t:1527016429531};\\\", \\\"{x:311,y:637,t:1527016429548};\\\", \\\"{x:325,y:614,t:1527016429565};\\\", \\\"{x:348,y:592,t:1527016429582};\\\", \\\"{x:368,y:570,t:1527016429598};\\\", \\\"{x:384,y:555,t:1527016429614};\\\", \\\"{x:401,y:542,t:1527016429632};\\\", \\\"{x:409,y:533,t:1527016429649};\\\", \\\"{x:416,y:526,t:1527016429665};\\\", \\\"{x:419,y:525,t:1527016429683};\\\", \\\"{x:422,y:531,t:1527016429742};\\\", \\\"{x:428,y:544,t:1527016429749};\\\", \\\"{x:440,y:563,t:1527016429765};\\\", \\\"{x:456,y:583,t:1527016429781};\\\", \\\"{x:477,y:600,t:1527016429799};\\\", \\\"{x:491,y:609,t:1527016429815};\\\", \\\"{x:502,y:618,t:1527016429833};\\\", \\\"{x:512,y:625,t:1527016429848};\\\", \\\"{x:512,y:626,t:1527016429865};\\\", \\\"{x:514,y:626,t:1527016429882};\\\", \\\"{x:514,y:627,t:1527016430086};\\\", \\\"{x:517,y:627,t:1527016430158};\\\", \\\"{x:520,y:627,t:1527016430165};\\\", \\\"{x:534,y:616,t:1527016430183};\\\", \\\"{x:540,y:610,t:1527016430198};\\\", \\\"{x:540,y:607,t:1527016430215};\\\", \\\"{x:544,y:605,t:1527016430233};\\\", \\\"{x:551,y:595,t:1527016430250};\\\", \\\"{x:567,y:581,t:1527016430266};\\\", \\\"{x:593,y:574,t:1527016430282};\\\", \\\"{x:609,y:568,t:1527016430299};\\\", \\\"{x:622,y:557,t:1527016430315};\\\", \\\"{x:637,y:549,t:1527016430332};\\\", \\\"{x:647,y:547,t:1527016430349};\\\", \\\"{x:661,y:546,t:1527016430365};\\\", \\\"{x:669,y:544,t:1527016430383};\\\", \\\"{x:670,y:544,t:1527016430399};\\\", \\\"{x:671,y:543,t:1527016430429};\\\", \\\"{x:672,y:543,t:1527016430436};\\\", \\\"{x:673,y:543,t:1527016430449};\\\", \\\"{x:682,y:541,t:1527016430465};\\\", \\\"{x:696,y:541,t:1527016430483};\\\", \\\"{x:700,y:540,t:1527016430499};\\\", \\\"{x:713,y:539,t:1527016430515};\\\", \\\"{x:720,y:539,t:1527016430533};\\\", \\\"{x:738,y:539,t:1527016430549};\\\", \\\"{x:753,y:541,t:1527016430566};\\\", \\\"{x:770,y:551,t:1527016430582};\\\", \\\"{x:799,y:552,t:1527016430600};\\\", \\\"{x:814,y:554,t:1527016430615};\\\", \\\"{x:815,y:554,t:1527016430632};\\\", \\\"{x:815,y:553,t:1527016430649};\\\", \\\"{x:817,y:552,t:1527016430830};\\\", \\\"{x:822,y:547,t:1527016430837};\\\", \\\"{x:825,y:544,t:1527016430850};\\\", \\\"{x:832,y:535,t:1527016430867};\\\", \\\"{x:836,y:532,t:1527016430882};\\\", \\\"{x:838,y:530,t:1527016430899};\\\", \\\"{x:838,y:529,t:1527016430916};\\\", \\\"{x:839,y:529,t:1527016431157};\\\", \\\"{x:839,y:530,t:1527016431166};\\\", \\\"{x:826,y:550,t:1527016431184};\\\", \\\"{x:814,y:568,t:1527016431200};\\\", \\\"{x:778,y:614,t:1527016431217};\\\", \\\"{x:753,y:647,t:1527016431234};\\\", \\\"{x:733,y:663,t:1527016431249};\\\", \\\"{x:719,y:680,t:1527016431267};\\\", \\\"{x:704,y:695,t:1527016431282};\\\", \\\"{x:700,y:701,t:1527016431299};\\\", \\\"{x:699,y:701,t:1527016431316};\\\", \\\"{x:696,y:702,t:1527016431332};\\\", \\\"{x:688,y:705,t:1527016431348};\\\", \\\"{x:678,y:705,t:1527016431367};\\\", \\\"{x:666,y:705,t:1527016431382};\\\", \\\"{x:657,y:705,t:1527016431399};\\\", \\\"{x:649,y:702,t:1527016431416};\\\", \\\"{x:642,y:699,t:1527016431433};\\\", \\\"{x:626,y:692,t:1527016431450};\\\", \\\"{x:606,y:680,t:1527016431465};\\\", \\\"{x:591,y:673,t:1527016431482};\\\", \\\"{x:566,y:667,t:1527016431499};\\\", \\\"{x:551,y:667,t:1527016431515};\\\", \\\"{x:539,y:667,t:1527016431533};\\\", \\\"{x:519,y:673,t:1527016431549};\\\", \\\"{x:519,y:678,t:1527016431565};\\\", \\\"{x:514,y:682,t:1527016431582};\\\", \\\"{x:511,y:686,t:1527016431599};\\\", \\\"{x:509,y:689,t:1527016431615};\\\", \\\"{x:507,y:689,t:1527016431633};\\\", \\\"{x:505,y:694,t:1527016431649};\\\", \\\"{x:502,y:700,t:1527016431666};\\\", \\\"{x:501,y:704,t:1527016431683};\\\", \\\"{x:499,y:713,t:1527016431699};\\\", \\\"{x:498,y:718,t:1527016431716};\\\", \\\"{x:493,y:729,t:1527016431732};\\\", \\\"{x:492,y:741,t:1527016431750};\\\", \\\"{x:492,y:744,t:1527016431766};\\\", \\\"{x:492,y:747,t:1527016431783};\\\", \\\"{x:492,y:748,t:1527016432025};\\\", \\\"{x:493,y:748,t:1527016432038};\\\", \\\"{x:493,y:747,t:1527016432054};\\\", \\\"{x:493,y:744,t:1527016432841};\\\", \\\"{x:497,y:741,t:1527016432854};\\\", \\\"{x:515,y:736,t:1527016432871};\\\", \\\"{x:532,y:731,t:1527016432888};\\\", \\\"{x:543,y:729,t:1527016432904};\\\", \\\"{x:558,y:723,t:1527016432921};\\\", \\\"{x:579,y:722,t:1527016432938};\\\", \\\"{x:598,y:721,t:1527016432955};\\\", \\\"{x:608,y:721,t:1527016432971};\\\", \\\"{x:612,y:721,t:1527016432988};\\\", \\\"{x:616,y:719,t:1527016433005};\\\", \\\"{x:618,y:718,t:1527016433022};\\\", \\\"{x:618,y:716,t:1527016433038};\\\", \\\"{x:619,y:714,t:1527016433055};\\\" ] }, { \\\"rt\\\": 37559, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 10, \\\"time_elapsed\\\": 509872, \\\"internal_node_id\\\": \\\"0.0-6.0-0.0\\\", \\\"subject\\\": \\\"6Y93F\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"foxtrot\\\", \\\"condition\\\": \\\"111\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"duration\\\", \\\"q\\\": 6, \\\"clicks\\\": 2, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XInside-YFull\\\", \\\"correct\\\": 1, \\\"orth_correct\\\": 1, \\\"answer\\\": [ \\\"E\\\", \\\"G\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"\\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:620,y:714,t:1527016434706};\\\", \\\"{x:621,y:714,t:1527016434729};\\\", \\\"{x:623,y:714,t:1527016434745};\\\", \\\"{x:628,y:714,t:1527016434756};\\\", \\\"{x:633,y:714,t:1527016434774};\\\", \\\"{x:651,y:714,t:1527016434789};\\\", \\\"{x:653,y:714,t:1527016434807};\\\", \\\"{x:654,y:714,t:1527016434824};\\\", \\\"{x:655,y:713,t:1527016434839};\\\", \\\"{x:656,y:709,t:1527016434856};\\\", \\\"{x:658,y:706,t:1527016434873};\\\", \\\"{x:658,y:707,t:1527016435129};\\\", \\\"{x:658,y:709,t:1527016435140};\\\", \\\"{x:658,y:712,t:1527016435156};\\\", \\\"{x:658,y:718,t:1527016435173};\\\", \\\"{x:658,y:723,t:1527016435191};\\\", \\\"{x:658,y:725,t:1527016435207};\\\", \\\"{x:658,y:726,t:1527016435385};\\\", \\\"{x:655,y:723,t:1527016447921};\\\", \\\"{x:650,y:720,t:1527016447934};\\\", \\\"{x:648,y:712,t:1527016447949};\\\", \\\"{x:646,y:702,t:1527016447967};\\\", \\\"{x:646,y:688,t:1527016447984};\\\", \\\"{x:648,y:677,t:1527016448000};\\\", \\\"{x:650,y:664,t:1527016448017};\\\", \\\"{x:650,y:656,t:1527016448034};\\\", \\\"{x:649,y:643,t:1527016448050};\\\", \\\"{x:643,y:628,t:1527016448068};\\\", \\\"{x:643,y:613,t:1527016448085};\\\", \\\"{x:645,y:598,t:1527016448101};\\\", \\\"{x:649,y:586,t:1527016448110};\\\", \\\"{x:650,y:576,t:1527016448125};\\\", \\\"{x:652,y:562,t:1527016448150};\\\", \\\"{x:652,y:553,t:1527016448167};\\\", \\\"{x:646,y:545,t:1527016448184};\\\", \\\"{x:637,y:530,t:1527016448201};\\\", \\\"{x:633,y:520,t:1527016448217};\\\", \\\"{x:624,y:511,t:1527016448234};\\\", \\\"{x:621,y:505,t:1527016448251};\\\", \\\"{x:619,y:502,t:1527016448267};\\\", \\\"{x:615,y:498,t:1527016448284};\\\", \\\"{x:613,y:495,t:1527016448300};\\\", \\\"{x:609,y:491,t:1527016448317};\\\", \\\"{x:605,y:489,t:1527016448334};\\\", \\\"{x:604,y:488,t:1527016448350};\\\", \\\"{x:603,y:488,t:1527016448464};\\\", \\\"{x:602,y:488,t:1527016448545};\\\", \\\"{x:602,y:489,t:1527016448553};\\\", \\\"{x:603,y:491,t:1527016448567};\\\", \\\"{x:603,y:493,t:1527016448584};\\\", \\\"{x:604,y:494,t:1527016448601};\\\", \\\"{x:604,y:495,t:1527016448616};\\\", \\\"{x:607,y:497,t:1527016448729};\\\", \\\"{x:607,y:499,t:1527016448736};\\\", \\\"{x:608,y:501,t:1527016448751};\\\", \\\"{x:610,y:505,t:1527016448767};\\\", \\\"{x:611,y:506,t:1527016448784};\\\", \\\"{x:613,y:507,t:1527016448800};\\\", \\\"{x:615,y:507,t:1527016449096};\\\", \\\"{x:637,y:510,t:1527016449105};\\\", \\\"{x:678,y:519,t:1527016449118};\\\", \\\"{x:734,y:528,t:1527016449134};\\\", \\\"{x:844,y:555,t:1527016449151};\\\", \\\"{x:957,y:567,t:1527016449168};\\\", \\\"{x:1045,y:583,t:1527016449185};\\\", \\\"{x:1057,y:591,t:1527016449200};\\\", \\\"{x:1066,y:591,t:1527016449218};\\\", \\\"{x:1064,y:591,t:1527016449329};\\\", \\\"{x:1062,y:591,t:1527016449337};\\\", \\\"{x:1060,y:591,t:1527016449353};\\\", \\\"{x:1052,y:590,t:1527016449367};\\\", \\\"{x:1030,y:586,t:1527016449383};\\\", \\\"{x:994,y:581,t:1527016449401};\\\", \\\"{x:959,y:573,t:1527016449416};\\\", \\\"{x:936,y:570,t:1527016449434};\\\", \\\"{x:931,y:570,t:1527016449449};\\\", \\\"{x:918,y:570,t:1527016449468};\\\", \\\"{x:905,y:563,t:1527016449485};\\\", \\\"{x:898,y:561,t:1527016449501};\\\", \\\"{x:887,y:557,t:1527016449518};\\\", \\\"{x:883,y:557,t:1527016449535};\\\", \\\"{x:877,y:557,t:1527016449551};\\\", \\\"{x:870,y:557,t:1527016449568};\\\", \\\"{x:869,y:557,t:1527016449657};\\\", \\\"{x:869,y:556,t:1527016449689};\\\", \\\"{x:864,y:553,t:1527016449702};\\\", \\\"{x:857,y:551,t:1527016449718};\\\", \\\"{x:853,y:549,t:1527016449735};\\\", \\\"{x:851,y:549,t:1527016449752};\\\", \\\"{x:849,y:547,t:1527016449825};\\\", \\\"{x:848,y:546,t:1527016449835};\\\", \\\"{x:847,y:545,t:1527016449852};\\\", \\\"{x:842,y:542,t:1527016449868};\\\", \\\"{x:838,y:539,t:1527016449885};\\\", \\\"{x:832,y:535,t:1527016449902};\\\", \\\"{x:828,y:532,t:1527016449919};\\\", \\\"{x:827,y:531,t:1527016449937};\\\", \\\"{x:823,y:537,t:1527016450345};\\\", \\\"{x:819,y:547,t:1527016450353};\\\", \\\"{x:811,y:554,t:1527016450368};\\\", \\\"{x:799,y:573,t:1527016450386};\\\", \\\"{x:790,y:596,t:1527016450402};\\\", \\\"{x:782,y:620,t:1527016450419};\\\", \\\"{x:765,y:643,t:1527016450435};\\\", \\\"{x:759,y:649,t:1527016450452};\\\", \\\"{x:750,y:658,t:1527016450469};\\\", \\\"{x:741,y:668,t:1527016450486};\\\", \\\"{x:739,y:670,t:1527016450502};\\\", \\\"{x:736,y:674,t:1527016450519};\\\", \\\"{x:733,y:680,t:1527016450536};\\\", \\\"{x:724,y:688,t:1527016450552};\\\", \\\"{x:718,y:701,t:1527016450569};\\\", \\\"{x:713,y:710,t:1527016450585};\\\", \\\"{x:708,y:718,t:1527016450603};\\\", \\\"{x:706,y:721,t:1527016450619};\\\", \\\"{x:705,y:723,t:1527016451249};\\\", \\\"{x:703,y:724,t:1527016451257};\\\", \\\"{x:702,y:724,t:1527016451281};\\\", \\\"{x:701,y:724,t:1527016451944};\\\", \\\"{x:700,y:724,t:1527016451956};\\\", \\\"{x:689,y:728,t:1527016451973};\\\", \\\"{x:681,y:731,t:1527016451988};\\\", \\\"{x:673,y:733,t:1527016452005};\\\", \\\"{x:662,y:738,t:1527016452023};\\\", \\\"{x:651,y:744,t:1527016452039};\\\", \\\"{x:636,y:749,t:1527016452056};\\\", \\\"{x:627,y:751,t:1527016452072};\\\", \\\"{x:624,y:751,t:1527016452090};\\\", \\\"{x:622,y:751,t:1527016452106};\\\", \\\"{x:621,y:751,t:1527016452128};\\\", \\\"{x:620,y:751,t:1527016452144};\\\", \\\"{x:619,y:751,t:1527016452168};\\\", \\\"{x:617,y:752,t:1527016452176};\\\", \\\"{x:615,y:753,t:1527016452190};\\\", \\\"{x:610,y:756,t:1527016452206};\\\", \\\"{x:601,y:759,t:1527016452223};\\\", \\\"{x:589,y:764,t:1527016452240};\\\", \\\"{x:581,y:769,t:1527016452257};\\\", \\\"{x:579,y:770,t:1527016452273};\\\", \\\"{x:577,y:770,t:1527016452290};\\\", \\\"{x:575,y:770,t:1527016452307};\\\", \\\"{x:573,y:770,t:1527016452323};\\\", \\\"{x:571,y:770,t:1527016452340};\\\", \\\"{x:570,y:771,t:1527016452357};\\\", \\\"{x:570,y:772,t:1527016452392};\\\", \\\"{x:568,y:773,t:1527016452408};\\\", \\\"{x:565,y:774,t:1527016452424};\\\", \\\"{x:562,y:776,t:1527016452440};\\\", \\\"{x:560,y:776,t:1527016452457};\\\", \\\"{x:559,y:777,t:1527016452474};\\\", \\\"{x:558,y:777,t:1527016452577};\\\", \\\"{x:556,y:778,t:1527016452600};\\\", \\\"{x:555,y:778,t:1527016452625};\\\", \\\"{x:553,y:778,t:1527016456209};\\\", \\\"{x:550,y:778,t:1527016456216};\\\", \\\"{x:544,y:775,t:1527016456233};\\\", \\\"{x:541,y:775,t:1527016456250};\\\", \\\"{x:536,y:774,t:1527016456266};\\\", \\\"{x:524,y:770,t:1527016456284};\\\", \\\"{x:523,y:769,t:1527016456299};\\\", \\\"{x:517,y:767,t:1527016456317};\\\", \\\"{x:513,y:765,t:1527016456333};\\\", \\\"{x:511,y:763,t:1527016456350};\\\", \\\"{x:510,y:762,t:1527016456367};\\\", \\\"{x:509,y:761,t:1527016456384};\\\", \\\"{x:508,y:760,t:1527016456400};\\\", \\\"{x:505,y:758,t:1527016456417};\\\", \\\"{x:505,y:757,t:1527016456504};\\\", \\\"{x:505,y:756,t:1527016456520};\\\", \\\"{x:505,y:754,t:1527016456536};\\\", \\\"{x:505,y:752,t:1527016456550};\\\", \\\"{x:506,y:743,t:1527016456567};\\\", \\\"{x:509,y:737,t:1527016456590};\\\", \\\"{x:510,y:736,t:1527016456607};\\\", \\\"{x:510,y:735,t:1527016456688};\\\", \\\"{x:512,y:732,t:1527016456737};\\\", \\\"{x:513,y:731,t:1527016456777};\\\" ] }, { \\\"rt\\\": 37869, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 11, \\\"time_elapsed\\\": 548996, \\\"internal_node_id\\\": \\\"0.0-6.0-1.0\\\", \\\"subject\\\": \\\"6Y93F\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"foxtrot\\\", \\\"condition\\\": \\\"111\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"duration+starts\\\", \\\"q\\\": 7, \\\"clicks\\\": 2, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XInside-YFull\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 1, \\\"answer\\\": [ \\\"F\\\", \\\"B\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"\\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:517,y:730,t:1527016474976};\\\", \\\"{x:525,y:730,t:1527016474994};\\\", \\\"{x:536,y:730,t:1527016475010};\\\", \\\"{x:542,y:730,t:1527016475027};\\\", \\\"{x:551,y:730,t:1527016475043};\\\", \\\"{x:553,y:730,t:1527016475088};\\\", \\\"{x:555,y:730,t:1527016475136};\\\", \\\"{x:557,y:730,t:1527016475143};\\\", \\\"{x:563,y:731,t:1527016475161};\\\", \\\"{x:569,y:733,t:1527016475178};\\\", \\\"{x:574,y:733,t:1527016475194};\\\", \\\"{x:576,y:733,t:1527016475203};\\\", \\\"{x:588,y:733,t:1527016475221};\\\", \\\"{x:590,y:733,t:1527016475236};\\\", \\\"{x:598,y:734,t:1527016475253};\\\", \\\"{x:601,y:734,t:1527016475271};\\\", \\\"{x:603,y:734,t:1527016475287};\\\", \\\"{x:609,y:737,t:1527016475303};\\\", \\\"{x:618,y:739,t:1527016475320};\\\", \\\"{x:628,y:740,t:1527016475337};\\\", \\\"{x:630,y:742,t:1527016475354};\\\", \\\"{x:633,y:743,t:1527016475370};\\\", \\\"{x:638,y:743,t:1527016475386};\\\", \\\"{x:640,y:743,t:1527016475404};\\\", \\\"{x:642,y:743,t:1527016475421};\\\", \\\"{x:643,y:743,t:1527016475436};\\\", \\\"{x:644,y:743,t:1527016475454};\\\", \\\"{x:645,y:743,t:1527016501844};\\\", \\\"{x:645,y:744,t:1527016501852};\\\", \\\"{x:645,y:745,t:1527016501868};\\\", \\\"{x:643,y:746,t:1527016501884};\\\", \\\"{x:642,y:746,t:1527016501894};\\\", \\\"{x:637,y:748,t:1527016501912};\\\", \\\"{x:636,y:748,t:1527016501928};\\\", \\\"{x:635,y:749,t:1527016501944};\\\", \\\"{x:635,y:748,t:1527016504211};\\\", \\\"{x:635,y:746,t:1527016504347};\\\", \\\"{x:635,y:745,t:1527016504411};\\\", \\\"{x:635,y:743,t:1527016504571};\\\", \\\"{x:635,y:740,t:1527016504756};\\\", \\\"{x:635,y:739,t:1527016504972};\\\", \\\"{x:637,y:738,t:1527016505115};\\\", \\\"{x:638,y:738,t:1527016505148};\\\", \\\"{x:641,y:736,t:1527016505323};\\\", \\\"{x:641,y:734,t:1527016506259};\\\", \\\"{x:637,y:729,t:1527016506268};\\\", \\\"{x:636,y:727,t:1527016506278};\\\", \\\"{x:633,y:719,t:1527016506295};\\\", \\\"{x:627,y:704,t:1527016506312};\\\", \\\"{x:620,y:691,t:1527016506328};\\\", \\\"{x:603,y:676,t:1527016506345};\\\", \\\"{x:585,y:663,t:1527016506362};\\\", \\\"{x:571,y:652,t:1527016506378};\\\", \\\"{x:561,y:642,t:1527016506395};\\\", \\\"{x:554,y:636,t:1527016506412};\\\", \\\"{x:543,y:629,t:1527016506429};\\\", \\\"{x:535,y:622,t:1527016506446};\\\", \\\"{x:525,y:615,t:1527016506466};\\\", \\\"{x:515,y:606,t:1527016506482};\\\", \\\"{x:500,y:597,t:1527016506499};\\\", \\\"{x:482,y:581,t:1527016506517};\\\", \\\"{x:473,y:574,t:1527016506533};\\\", \\\"{x:463,y:565,t:1527016506550};\\\", \\\"{x:456,y:555,t:1527016506567};\\\", \\\"{x:454,y:553,t:1527016506583};\\\", \\\"{x:454,y:550,t:1527016506601};\\\", \\\"{x:462,y:542,t:1527016506618};\\\", \\\"{x:477,y:533,t:1527016506634};\\\", \\\"{x:500,y:519,t:1527016506651};\\\", \\\"{x:521,y:508,t:1527016506668};\\\", \\\"{x:538,y:496,t:1527016506684};\\\", \\\"{x:555,y:488,t:1527016506701};\\\", \\\"{x:566,y:484,t:1527016506718};\\\", \\\"{x:570,y:481,t:1527016506733};\\\", \\\"{x:580,y:478,t:1527016506751};\\\", \\\"{x:581,y:478,t:1527016506787};\\\", \\\"{x:584,y:478,t:1527016506801};\\\", \\\"{x:587,y:478,t:1527016506818};\\\", \\\"{x:591,y:478,t:1527016506833};\\\", \\\"{x:594,y:478,t:1527016506850};\\\", \\\"{x:601,y:476,t:1527016506866};\\\", \\\"{x:606,y:476,t:1527016506883};\\\", \\\"{x:610,y:474,t:1527016506901};\\\", \\\"{x:617,y:473,t:1527016506917};\\\", \\\"{x:621,y:473,t:1527016506934};\\\", \\\"{x:635,y:473,t:1527016506950};\\\", \\\"{x:649,y:478,t:1527016506968};\\\", \\\"{x:667,y:482,t:1527016506983};\\\", \\\"{x:668,y:483,t:1527016507000};\\\", \\\"{x:680,y:486,t:1527016507019};\\\", \\\"{x:694,y:488,t:1527016507035};\\\", \\\"{x:713,y:492,t:1527016507051};\\\", \\\"{x:730,y:494,t:1527016507068};\\\", \\\"{x:741,y:494,t:1527016507085};\\\", \\\"{x:755,y:494,t:1527016507100};\\\", \\\"{x:762,y:494,t:1527016507118};\\\", \\\"{x:768,y:494,t:1527016507135};\\\", \\\"{x:774,y:494,t:1527016507151};\\\", \\\"{x:781,y:495,t:1527016507167};\\\", \\\"{x:783,y:495,t:1527016507185};\\\", \\\"{x:784,y:495,t:1527016507201};\\\", \\\"{x:786,y:495,t:1527016507356};\\\", \\\"{x:787,y:495,t:1527016507372};\\\", \\\"{x:789,y:495,t:1527016507384};\\\", \\\"{x:791,y:495,t:1527016507401};\\\", \\\"{x:805,y:495,t:1527016507417};\\\", \\\"{x:808,y:495,t:1527016507435};\\\", \\\"{x:809,y:495,t:1527016507499};\\\", \\\"{x:811,y:495,t:1527016507507};\\\", \\\"{x:812,y:495,t:1527016507518};\\\", \\\"{x:813,y:495,t:1527016507535};\\\", \\\"{x:815,y:495,t:1527016507552};\\\", \\\"{x:819,y:495,t:1527016507567};\\\", \\\"{x:821,y:495,t:1527016507585};\\\", \\\"{x:832,y:500,t:1527016507602};\\\", \\\"{x:838,y:502,t:1527016507618};\\\", \\\"{x:839,y:503,t:1527016507635};\\\", \\\"{x:839,y:504,t:1527016508052};\\\", \\\"{x:813,y:504,t:1527016508069};\\\", \\\"{x:769,y:505,t:1527016508085};\\\", \\\"{x:655,y:509,t:1527016508102};\\\", \\\"{x:564,y:505,t:1527016508118};\\\", \\\"{x:433,y:514,t:1527016508135};\\\", \\\"{x:309,y:522,t:1527016508152};\\\", \\\"{x:194,y:533,t:1527016508170};\\\", \\\"{x:103,y:542,t:1527016508185};\\\", \\\"{x:55,y:545,t:1527016508202};\\\", \\\"{x:49,y:548,t:1527016508218};\\\", \\\"{x:40,y:548,t:1527016508235};\\\", \\\"{x:38,y:548,t:1527016508251};\\\", \\\"{x:34,y:548,t:1527016508269};\\\", \\\"{x:29,y:549,t:1527016508286};\\\", \\\"{x:27,y:551,t:1527016508302};\\\", \\\"{x:25,y:553,t:1527016508318};\\\", \\\"{x:23,y:554,t:1527016508335};\\\", \\\"{x:23,y:555,t:1527016508353};\\\", \\\"{x:24,y:556,t:1527016508388};\\\", \\\"{x:27,y:556,t:1527016508402};\\\", \\\"{x:40,y:549,t:1527016508419};\\\", \\\"{x:62,y:543,t:1527016508436};\\\", \\\"{x:65,y:540,t:1527016508453};\\\", \\\"{x:69,y:539,t:1527016508469};\\\", \\\"{x:73,y:539,t:1527016508485};\\\", \\\"{x:74,y:539,t:1527016508571};\\\", \\\"{x:74,y:540,t:1527016508699};\\\", \\\"{x:80,y:542,t:1527016508708};\\\", \\\"{x:81,y:547,t:1527016508719};\\\", \\\"{x:96,y:554,t:1527016508735};\\\", \\\"{x:109,y:561,t:1527016508752};\\\", \\\"{x:114,y:561,t:1527016508769};\\\", \\\"{x:115,y:561,t:1527016508786};\\\", \\\"{x:117,y:561,t:1527016508804};\\\", \\\"{x:119,y:560,t:1527016508819};\\\", \\\"{x:121,y:556,t:1527016508836};\\\", \\\"{x:123,y:554,t:1527016508853};\\\", \\\"{x:125,y:551,t:1527016508869};\\\", \\\"{x:126,y:550,t:1527016508886};\\\", \\\"{x:127,y:550,t:1527016508902};\\\", \\\"{x:128,y:549,t:1527016508972};\\\", \\\"{x:129,y:548,t:1527016508986};\\\", \\\"{x:130,y:548,t:1527016509002};\\\", \\\"{x:132,y:548,t:1527016509267};\\\", \\\"{x:134,y:546,t:1527016509284};\\\", \\\"{x:137,y:546,t:1527016509299};\\\", \\\"{x:141,y:545,t:1527016509307};\\\", \\\"{x:143,y:545,t:1527016509319};\\\", \\\"{x:151,y:545,t:1527016509336};\\\", \\\"{x:154,y:543,t:1527016509353};\\\", \\\"{x:155,y:543,t:1527016509419};\\\", \\\"{x:155,y:542,t:1527016509435};\\\", \\\"{x:156,y:542,t:1527016509459};\\\", \\\"{x:156,y:542,t:1527016509489};\\\", \\\"{x:169,y:545,t:1527016509667};\\\", \\\"{x:192,y:567,t:1527016509676};\\\", \\\"{x:228,y:588,t:1527016509686};\\\", \\\"{x:307,y:635,t:1527016509703};\\\", \\\"{x:401,y:698,t:1527016509720};\\\", \\\"{x:525,y:774,t:1527016509737};\\\", \\\"{x:648,y:840,t:1527016509753};\\\", \\\"{x:763,y:887,t:1527016509770};\\\", \\\"{x:849,y:910,t:1527016509787};\\\", \\\"{x:857,y:913,t:1527016509803};\\\", \\\"{x:857,y:912,t:1527016509819};\\\", \\\"{x:857,y:905,t:1527016509837};\\\", \\\"{x:852,y:893,t:1527016509853};\\\", \\\"{x:845,y:878,t:1527016509870};\\\", \\\"{x:838,y:873,t:1527016509886};\\\", \\\"{x:824,y:860,t:1527016509903};\\\", \\\"{x:814,y:852,t:1527016509919};\\\", \\\"{x:802,y:843,t:1527016509937};\\\", \\\"{x:790,y:835,t:1527016509953};\\\", \\\"{x:774,y:827,t:1527016509970};\\\", \\\"{x:763,y:820,t:1527016509987};\\\", \\\"{x:737,y:809,t:1527016510002};\\\", \\\"{x:689,y:781,t:1527016510020};\\\", \\\"{x:642,y:764,t:1527016510037};\\\", \\\"{x:632,y:755,t:1527016510053};\\\", \\\"{x:622,y:751,t:1527016510070};\\\", \\\"{x:620,y:751,t:1527016510087};\\\", \\\"{x:616,y:751,t:1527016510102};\\\", \\\"{x:611,y:751,t:1527016510119};\\\", \\\"{x:605,y:751,t:1527016510136};\\\", \\\"{x:602,y:751,t:1527016510153};\\\", \\\"{x:601,y:751,t:1527016510170};\\\", \\\"{x:596,y:750,t:1527016510186};\\\", \\\"{x:594,y:749,t:1527016510203};\\\", \\\"{x:590,y:749,t:1527016510252};\\\", \\\"{x:587,y:749,t:1527016510259};\\\", \\\"{x:583,y:749,t:1527016510270};\\\", \\\"{x:577,y:749,t:1527016510287};\\\", \\\"{x:572,y:749,t:1527016510304};\\\", \\\"{x:564,y:746,t:1527016510320};\\\", \\\"{x:551,y:741,t:1527016510336};\\\", \\\"{x:540,y:735,t:1527016510353};\\\", \\\"{x:529,y:729,t:1527016510369};\\\", \\\"{x:523,y:726,t:1527016510385};\\\", \\\"{x:518,y:724,t:1527016510404};\\\", \\\"{x:518,y:723,t:1527016510419};\\\", \\\"{x:521,y:720,t:1527016511019};\\\", \\\"{x:522,y:720,t:1527016511027};\\\", \\\"{x:528,y:720,t:1527016511038};\\\", \\\"{x:543,y:726,t:1527016511054};\\\", \\\"{x:551,y:731,t:1527016511070};\\\", \\\"{x:579,y:741,t:1527016511087};\\\", \\\"{x:634,y:751,t:1527016511104};\\\", \\\"{x:717,y:765,t:1527016511121};\\\", \\\"{x:781,y:773,t:1527016511137};\\\", \\\"{x:785,y:774,t:1527016511153};\\\", \\\"{x:802,y:774,t:1527016511171};\\\", \\\"{x:805,y:773,t:1527016511188};\\\", \\\"{x:808,y:771,t:1527016511204};\\\", \\\"{x:808,y:770,t:1527016511220};\\\", \\\"{x:807,y:770,t:1527016511451};\\\", \\\"{x:806,y:770,t:1527016511467};\\\", \\\"{x:804,y:770,t:1527016511483};\\\", \\\"{x:803,y:770,t:1527016511491};\\\", \\\"{x:802,y:770,t:1527016511516};\\\" ] }, { \\\"rt\\\": 49070, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 12, \\\"time_elapsed\\\": 599270, \\\"internal_node_id\\\": \\\"0.0-6.0-2.0\\\", \\\"subject\\\": \\\"6Y93F\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"foxtrot\\\", \\\"condition\\\": \\\"111\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"duration+contained\\\", \\\"q\\\": 8, \\\"clicks\\\": 1, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XInside-YFull\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 1, \\\"answer\\\": [ \\\"E\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-B -B -J -E -I \\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:801,y:770,t:1527016511908};\\\", \\\"{x:800,y:770,t:1527016511921};\\\", \\\"{x:798,y:770,t:1527016511938};\\\", \\\"{x:797,y:770,t:1527016511979};\\\", \\\"{x:794,y:770,t:1527016512731};\\\", \\\"{x:793,y:770,t:1527016512739};\\\", \\\"{x:787,y:770,t:1527016512764};\\\", \\\"{x:784,y:769,t:1527016512772};\\\", \\\"{x:779,y:766,t:1527016512788};\\\", \\\"{x:774,y:764,t:1527016512820};\\\", \\\"{x:774,y:763,t:1527016512827};\\\", \\\"{x:767,y:763,t:1527016512839};\\\", \\\"{x:766,y:761,t:1527016512859};\\\", \\\"{x:763,y:761,t:1527016512872};\\\", \\\"{x:759,y:761,t:1527016512889};\\\", \\\"{x:752,y:761,t:1527016512906};\\\", \\\"{x:745,y:760,t:1527016512922};\\\", \\\"{x:743,y:758,t:1527016512939};\\\", \\\"{x:741,y:758,t:1527016513116};\\\", \\\"{x:738,y:758,t:1527016513123};\\\", \\\"{x:737,y:757,t:1527016513139};\\\", \\\"{x:736,y:756,t:1527016513204};\\\", \\\"{x:735,y:755,t:1527016513275};\\\", \\\"{x:734,y:755,t:1527016513307};\\\", \\\"{x:735,y:752,t:1527016514052};\\\", \\\"{x:741,y:749,t:1527016514059};\\\", \\\"{x:746,y:743,t:1527016514072};\\\", \\\"{x:767,y:729,t:1527016514090};\\\", \\\"{x:796,y:714,t:1527016514107};\\\", \\\"{x:847,y:699,t:1527016514123};\\\", \\\"{x:892,y:686,t:1527016514140};\\\", \\\"{x:917,y:679,t:1527016514157};\\\", \\\"{x:935,y:671,t:1527016514173};\\\", \\\"{x:943,y:668,t:1527016514190};\\\", \\\"{x:966,y:657,t:1527016514207};\\\", \\\"{x:982,y:650,t:1527016514223};\\\", \\\"{x:987,y:648,t:1527016514240};\\\", \\\"{x:990,y:648,t:1527016514257};\\\", \\\"{x:999,y:643,t:1527016514419};\\\", \\\"{x:1004,y:638,t:1527016514427};\\\", \\\"{x:1011,y:634,t:1527016514440};\\\", \\\"{x:1015,y:632,t:1527016514457};\\\", \\\"{x:1019,y:630,t:1527016514499};\\\", \\\"{x:1022,y:628,t:1527016514507};\\\", \\\"{x:1029,y:623,t:1527016514523};\\\", \\\"{x:1035,y:618,t:1527016514540};\\\", \\\"{x:1046,y:616,t:1527016514557};\\\", \\\"{x:1056,y:611,t:1527016514575};\\\", \\\"{x:1062,y:609,t:1527016514590};\\\", \\\"{x:1066,y:605,t:1527016514607};\\\", \\\"{x:1068,y:605,t:1527016514624};\\\", \\\"{x:1070,y:603,t:1527016514640};\\\", \\\"{x:1072,y:603,t:1527016514657};\\\", \\\"{x:1074,y:603,t:1527016514674};\\\", \\\"{x:1078,y:605,t:1527016514689};\\\", \\\"{x:1079,y:605,t:1527016515124};\\\", \\\"{x:1083,y:605,t:1527016515141};\\\", \\\"{x:1091,y:605,t:1527016515158};\\\", \\\"{x:1100,y:603,t:1527016515174};\\\", \\\"{x:1116,y:594,t:1527016515192};\\\", \\\"{x:1135,y:588,t:1527016515208};\\\", \\\"{x:1148,y:579,t:1527016515225};\\\", \\\"{x:1159,y:578,t:1527016515241};\\\", \\\"{x:1182,y:578,t:1527016515257};\\\", \\\"{x:1194,y:578,t:1527016515274};\\\", \\\"{x:1231,y:585,t:1527016515291};\\\", \\\"{x:1251,y:590,t:1527016515307};\\\", \\\"{x:1260,y:591,t:1527016515324};\\\", \\\"{x:1266,y:592,t:1527016515341};\\\", \\\"{x:1268,y:592,t:1527016515358};\\\", \\\"{x:1270,y:592,t:1527016515374};\\\", \\\"{x:1273,y:592,t:1527016515391};\\\", \\\"{x:1276,y:590,t:1527016515408};\\\", \\\"{x:1279,y:589,t:1527016515424};\\\", \\\"{x:1281,y:589,t:1527016515443};\\\", \\\"{x:1282,y:589,t:1527016515458};\\\", \\\"{x:1284,y:589,t:1527016515474};\\\", \\\"{x:1299,y:591,t:1527016515491};\\\", \\\"{x:1307,y:593,t:1527016515508};\\\", \\\"{x:1318,y:598,t:1527016515524};\\\", \\\"{x:1326,y:600,t:1527016515541};\\\", \\\"{x:1330,y:601,t:1527016515558};\\\", \\\"{x:1333,y:601,t:1527016515574};\\\", \\\"{x:1338,y:601,t:1527016515591};\\\", \\\"{x:1342,y:601,t:1527016515608};\\\", \\\"{x:1344,y:600,t:1527016515624};\\\", \\\"{x:1345,y:600,t:1527016515659};\\\", \\\"{x:1345,y:601,t:1527016515675};\\\", \\\"{x:1347,y:602,t:1527016515691};\\\", \\\"{x:1349,y:604,t:1527016515708};\\\", \\\"{x:1351,y:605,t:1527016515725};\\\", \\\"{x:1351,y:606,t:1527016515741};\\\", \\\"{x:1351,y:608,t:1527016515759};\\\", \\\"{x:1349,y:610,t:1527016515775};\\\", \\\"{x:1347,y:611,t:1527016515791};\\\", \\\"{x:1347,y:612,t:1527016515811};\\\", \\\"{x:1346,y:612,t:1527016515883};\\\", \\\"{x:1344,y:614,t:1527016515899};\\\", \\\"{x:1343,y:614,t:1527016516091};\\\", \\\"{x:1338,y:623,t:1527016516108};\\\", \\\"{x:1337,y:624,t:1527016516139};\\\", \\\"{x:1336,y:627,t:1527016516155};\\\", \\\"{x:1335,y:627,t:1527016516171};\\\", \\\"{x:1334,y:629,t:1527016516179};\\\", \\\"{x:1333,y:629,t:1527016516192};\\\", \\\"{x:1332,y:629,t:1527016516208};\\\", \\\"{x:1328,y:630,t:1527016516225};\\\", \\\"{x:1324,y:632,t:1527016516242};\\\", \\\"{x:1320,y:635,t:1527016516258};\\\", \\\"{x:1308,y:640,t:1527016516274};\\\", \\\"{x:1305,y:642,t:1527016516292};\\\", \\\"{x:1303,y:644,t:1527016516307};\\\", \\\"{x:1301,y:645,t:1527016516331};\\\", \\\"{x:1302,y:645,t:1527016516571};\\\", \\\"{x:1307,y:644,t:1527016516579};\\\", \\\"{x:1310,y:644,t:1527016516592};\\\", \\\"{x:1315,y:642,t:1527016516608};\\\", \\\"{x:1321,y:640,t:1527016516625};\\\", \\\"{x:1326,y:640,t:1527016516642};\\\", \\\"{x:1344,y:651,t:1527016516659};\\\", \\\"{x:1358,y:669,t:1527016516675};\\\", \\\"{x:1370,y:685,t:1527016516692};\\\", \\\"{x:1384,y:706,t:1527016516709};\\\", \\\"{x:1396,y:724,t:1527016516725};\\\", \\\"{x:1407,y:739,t:1527016516742};\\\", \\\"{x:1414,y:749,t:1527016516759};\\\", \\\"{x:1418,y:757,t:1527016516775};\\\", \\\"{x:1426,y:770,t:1527016516792};\\\", \\\"{x:1437,y:784,t:1527016516809};\\\", \\\"{x:1450,y:798,t:1527016516826};\\\", \\\"{x:1465,y:820,t:1527016516842};\\\", \\\"{x:1488,y:857,t:1527016516859};\\\", \\\"{x:1493,y:877,t:1527016516875};\\\", \\\"{x:1495,y:885,t:1527016516892};\\\", \\\"{x:1493,y:896,t:1527016516909};\\\", \\\"{x:1492,y:900,t:1527016516925};\\\", \\\"{x:1491,y:903,t:1527016517011};\\\", \\\"{x:1490,y:903,t:1527016517026};\\\", \\\"{x:1480,y:903,t:1527016517042};\\\", \\\"{x:1472,y:895,t:1527016517060};\\\", \\\"{x:1463,y:888,t:1527016517076};\\\", \\\"{x:1455,y:879,t:1527016517093};\\\", \\\"{x:1450,y:877,t:1527016517109};\\\", \\\"{x:1437,y:870,t:1527016517126};\\\", \\\"{x:1435,y:870,t:1527016517142};\\\", \\\"{x:1427,y:866,t:1527016517160};\\\", \\\"{x:1423,y:866,t:1527016517176};\\\", \\\"{x:1416,y:866,t:1527016517192};\\\", \\\"{x:1414,y:863,t:1527016517209};\\\", \\\"{x:1413,y:860,t:1527016517226};\\\", \\\"{x:1412,y:860,t:1527016517291};\\\", \\\"{x:1412,y:859,t:1527016517307};\\\", \\\"{x:1412,y:857,t:1527016517315};\\\", \\\"{x:1411,y:856,t:1527016517326};\\\", \\\"{x:1405,y:849,t:1527016517342};\\\", \\\"{x:1401,y:843,t:1527016517359};\\\", \\\"{x:1397,y:839,t:1527016517376};\\\", \\\"{x:1385,y:824,t:1527016517394};\\\", \\\"{x:1367,y:812,t:1527016517409};\\\", \\\"{x:1360,y:804,t:1527016517426};\\\", \\\"{x:1345,y:795,t:1527016517443};\\\", \\\"{x:1333,y:787,t:1527016517459};\\\", \\\"{x:1331,y:785,t:1527016517516};\\\", \\\"{x:1330,y:784,t:1527016517539};\\\", \\\"{x:1329,y:784,t:1527016517548};\\\", \\\"{x:1329,y:783,t:1527016517560};\\\", \\\"{x:1328,y:781,t:1527016517576};\\\", \\\"{x:1328,y:780,t:1527016517595};\\\", \\\"{x:1326,y:778,t:1527016517609};\\\", \\\"{x:1325,y:774,t:1527016517626};\\\", \\\"{x:1324,y:771,t:1527016517643};\\\", \\\"{x:1324,y:770,t:1527016517659};\\\", \\\"{x:1323,y:770,t:1527016517683};\\\", \\\"{x:1323,y:769,t:1527016517875};\\\", \\\"{x:1323,y:768,t:1527016517963};\\\", \\\"{x:1323,y:767,t:1527016517976};\\\", \\\"{x:1323,y:765,t:1527016517993};\\\", \\\"{x:1323,y:764,t:1527016518010};\\\", \\\"{x:1323,y:763,t:1527016519083};\\\", \\\"{x:1323,y:762,t:1527016519107};\\\", \\\"{x:1323,y:761,t:1527016519131};\\\", \\\"{x:1323,y:759,t:1527016519163};\\\", \\\"{x:1323,y:757,t:1527016519178};\\\", \\\"{x:1328,y:754,t:1527016519194};\\\", \\\"{x:1349,y:749,t:1527016519212};\\\", \\\"{x:1360,y:747,t:1527016519228};\\\", \\\"{x:1365,y:747,t:1527016519244};\\\", \\\"{x:1373,y:747,t:1527016519261};\\\", \\\"{x:1383,y:746,t:1527016519278};\\\", \\\"{x:1387,y:746,t:1527016519294};\\\", \\\"{x:1399,y:754,t:1527016519311};\\\", \\\"{x:1400,y:757,t:1527016519327};\\\", \\\"{x:1411,y:757,t:1527016519344};\\\", \\\"{x:1421,y:758,t:1527016519361};\\\", \\\"{x:1422,y:759,t:1527016519377};\\\", \\\"{x:1429,y:759,t:1527016519395};\\\", \\\"{x:1440,y:759,t:1527016519411};\\\", \\\"{x:1445,y:760,t:1527016519427};\\\", \\\"{x:1451,y:760,t:1527016519445};\\\", \\\"{x:1457,y:765,t:1527016519461};\\\", \\\"{x:1469,y:771,t:1527016519477};\\\", \\\"{x:1482,y:776,t:1527016519494};\\\", \\\"{x:1498,y:786,t:1527016519512};\\\", \\\"{x:1501,y:789,t:1527016519527};\\\", \\\"{x:1505,y:794,t:1527016519544};\\\", \\\"{x:1507,y:796,t:1527016519562};\\\", \\\"{x:1512,y:797,t:1527016519577};\\\", \\\"{x:1513,y:798,t:1527016519594};\\\", \\\"{x:1517,y:800,t:1527016519611};\\\", \\\"{x:1518,y:801,t:1527016519628};\\\", \\\"{x:1518,y:802,t:1527016519739};\\\", \\\"{x:1518,y:803,t:1527016519755};\\\", \\\"{x:1518,y:805,t:1527016519779};\\\", \\\"{x:1518,y:806,t:1527016519803};\\\", \\\"{x:1518,y:807,t:1527016519843};\\\", \\\"{x:1518,y:808,t:1527016519851};\\\", \\\"{x:1518,y:809,t:1527016519861};\\\", \\\"{x:1518,y:811,t:1527016519883};\\\", \\\"{x:1518,y:812,t:1527016519899};\\\", \\\"{x:1518,y:814,t:1527016519911};\\\", \\\"{x:1516,y:820,t:1527016519928};\\\", \\\"{x:1514,y:824,t:1527016519945};\\\", \\\"{x:1510,y:825,t:1527016519962};\\\", \\\"{x:1505,y:827,t:1527016519979};\\\", \\\"{x:1504,y:829,t:1527016519994};\\\", \\\"{x:1502,y:831,t:1527016520011};\\\", \\\"{x:1501,y:831,t:1527016520029};\\\", \\\"{x:1500,y:833,t:1527016520051};\\\", \\\"{x:1499,y:834,t:1527016520061};\\\", \\\"{x:1494,y:836,t:1527016520078};\\\", \\\"{x:1490,y:841,t:1527016520096};\\\", \\\"{x:1486,y:842,t:1527016520111};\\\", \\\"{x:1485,y:843,t:1527016520128};\\\", \\\"{x:1484,y:843,t:1527016520419};\\\", \\\"{x:1485,y:842,t:1527016520603};\\\", \\\"{x:1487,y:840,t:1527016520627};\\\", \\\"{x:1487,y:838,t:1527016520634};\\\", \\\"{x:1487,y:837,t:1527016521075};\\\", \\\"{x:1488,y:835,t:1527016521123};\\\", \\\"{x:1490,y:835,t:1527016521138};\\\", \\\"{x:1492,y:832,t:1527016521155};\\\", \\\"{x:1494,y:831,t:1527016521163};\\\", \\\"{x:1498,y:830,t:1527016521179};\\\", \\\"{x:1507,y:829,t:1527016521195};\\\", \\\"{x:1520,y:825,t:1527016521212};\\\", \\\"{x:1526,y:824,t:1527016521229};\\\", \\\"{x:1552,y:829,t:1527016521245};\\\", \\\"{x:1569,y:835,t:1527016521263};\\\", \\\"{x:1592,y:844,t:1527016521279};\\\", \\\"{x:1612,y:852,t:1527016521296};\\\", \\\"{x:1625,y:859,t:1527016521312};\\\", \\\"{x:1638,y:862,t:1527016521329};\\\", \\\"{x:1644,y:862,t:1527016521346};\\\", \\\"{x:1649,y:862,t:1527016521363};\\\", \\\"{x:1646,y:865,t:1527016521476};\\\", \\\"{x:1643,y:865,t:1527016521483};\\\", \\\"{x:1641,y:866,t:1527016521496};\\\", \\\"{x:1641,y:867,t:1527016521513};\\\", \\\"{x:1637,y:869,t:1527016521529};\\\", \\\"{x:1636,y:869,t:1527016521547};\\\", \\\"{x:1635,y:869,t:1527016521562};\\\", \\\"{x:1621,y:869,t:1527016521579};\\\", \\\"{x:1607,y:868,t:1527016521597};\\\", \\\"{x:1602,y:866,t:1527016521613};\\\", \\\"{x:1569,y:858,t:1527016521630};\\\", \\\"{x:1551,y:852,t:1527016521647};\\\", \\\"{x:1535,y:848,t:1527016521662};\\\", \\\"{x:1518,y:848,t:1527016521680};\\\", \\\"{x:1504,y:848,t:1527016521696};\\\", \\\"{x:1497,y:848,t:1527016521714};\\\", \\\"{x:1496,y:847,t:1527016521730};\\\", \\\"{x:1494,y:846,t:1527016521746};\\\", \\\"{x:1493,y:846,t:1527016521803};\\\", \\\"{x:1492,y:846,t:1527016521813};\\\", \\\"{x:1486,y:845,t:1527016521830};\\\", \\\"{x:1479,y:843,t:1527016521846};\\\", \\\"{x:1465,y:843,t:1527016521863};\\\", \\\"{x:1458,y:843,t:1527016521879};\\\", \\\"{x:1441,y:839,t:1527016521896};\\\", \\\"{x:1420,y:833,t:1527016521914};\\\", \\\"{x:1395,y:826,t:1527016521929};\\\", \\\"{x:1371,y:820,t:1527016521946};\\\", \\\"{x:1345,y:813,t:1527016521962};\\\", \\\"{x:1339,y:813,t:1527016521980};\\\", \\\"{x:1334,y:811,t:1527016521996};\\\", \\\"{x:1325,y:809,t:1527016522014};\\\", \\\"{x:1321,y:808,t:1527016522029};\\\", \\\"{x:1318,y:806,t:1527016522046};\\\", \\\"{x:1317,y:804,t:1527016522063};\\\", \\\"{x:1317,y:803,t:1527016522115};\\\", \\\"{x:1317,y:801,t:1527016522129};\\\", \\\"{x:1318,y:797,t:1527016522146};\\\", \\\"{x:1334,y:790,t:1527016522163};\\\", \\\"{x:1351,y:781,t:1527016522180};\\\", \\\"{x:1357,y:775,t:1527016522196};\\\", \\\"{x:1360,y:772,t:1527016522213};\\\", \\\"{x:1363,y:770,t:1527016522229};\\\", \\\"{x:1364,y:769,t:1527016522246};\\\", \\\"{x:1365,y:768,t:1527016522579};\\\", \\\"{x:1365,y:767,t:1527016522779};\\\", \\\"{x:1366,y:766,t:1527016522787};\\\", \\\"{x:1366,y:763,t:1527016522797};\\\", \\\"{x:1366,y:762,t:1527016522813};\\\", \\\"{x:1366,y:761,t:1527016525843};\\\", \\\"{x:1364,y:761,t:1527016525851};\\\", \\\"{x:1362,y:761,t:1527016525867};\\\", \\\"{x:1357,y:762,t:1527016525883};\\\", \\\"{x:1348,y:764,t:1527016525900};\\\", \\\"{x:1344,y:764,t:1527016525917};\\\", \\\"{x:1339,y:764,t:1527016525933};\\\", \\\"{x:1336,y:764,t:1527016525995};\\\", \\\"{x:1335,y:764,t:1527016526003};\\\", \\\"{x:1332,y:764,t:1527016526017};\\\", \\\"{x:1326,y:768,t:1527016526032};\\\", \\\"{x:1323,y:771,t:1527016526050};\\\", \\\"{x:1315,y:775,t:1527016526067};\\\", \\\"{x:1306,y:784,t:1527016526083};\\\", \\\"{x:1297,y:784,t:1527016526099};\\\", \\\"{x:1289,y:788,t:1527016526116};\\\", \\\"{x:1283,y:788,t:1527016526133};\\\", \\\"{x:1281,y:789,t:1527016526149};\\\", \\\"{x:1276,y:790,t:1527016526166};\\\", \\\"{x:1270,y:793,t:1527016526183};\\\", \\\"{x:1267,y:796,t:1527016526199};\\\", \\\"{x:1257,y:805,t:1527016526216};\\\", \\\"{x:1248,y:815,t:1527016526233};\\\", \\\"{x:1240,y:821,t:1527016526249};\\\", \\\"{x:1235,y:825,t:1527016526267};\\\", \\\"{x:1229,y:831,t:1527016526283};\\\", \\\"{x:1228,y:831,t:1527016526299};\\\", \\\"{x:1227,y:832,t:1527016526379};\\\", \\\"{x:1226,y:832,t:1527016526411};\\\", \\\"{x:1223,y:832,t:1527016526435};\\\", \\\"{x:1222,y:832,t:1527016526449};\\\", \\\"{x:1220,y:835,t:1527016526467};\\\", \\\"{x:1220,y:836,t:1527016526483};\\\", \\\"{x:1219,y:836,t:1527016527323};\\\", \\\"{x:1219,y:834,t:1527016528779};\\\", \\\"{x:1217,y:830,t:1527016532795};\\\", \\\"{x:1217,y:828,t:1527016532804};\\\", \\\"{x:1217,y:826,t:1527016532821};\\\", \\\"{x:1216,y:821,t:1527016532839};\\\", \\\"{x:1216,y:820,t:1527016532855};\\\", \\\"{x:1216,y:819,t:1527016532971};\\\", \\\"{x:1216,y:817,t:1527016533803};\\\", \\\"{x:1216,y:816,t:1527016533810};\\\", \\\"{x:1216,y:815,t:1527016533826};\\\", \\\"{x:1218,y:812,t:1527016533839};\\\", \\\"{x:1221,y:810,t:1527016533855};\\\", \\\"{x:1223,y:806,t:1527016533873};\\\", \\\"{x:1226,y:804,t:1527016533888};\\\", \\\"{x:1229,y:799,t:1527016533906};\\\", \\\"{x:1239,y:789,t:1527016533922};\\\", \\\"{x:1243,y:784,t:1527016533939};\\\", \\\"{x:1248,y:773,t:1527016533956};\\\", \\\"{x:1251,y:766,t:1527016533973};\\\", \\\"{x:1254,y:756,t:1527016533990};\\\", \\\"{x:1258,y:742,t:1527016534006};\\\", \\\"{x:1259,y:741,t:1527016534023};\\\", \\\"{x:1259,y:740,t:1527016534040};\\\", \\\"{x:1259,y:738,t:1527016534056};\\\", \\\"{x:1261,y:735,t:1527016534073};\\\", \\\"{x:1261,y:730,t:1527016534090};\\\", \\\"{x:1261,y:722,t:1527016534106};\\\", \\\"{x:1261,y:712,t:1527016534123};\\\", \\\"{x:1261,y:707,t:1527016534140};\\\", \\\"{x:1259,y:695,t:1527016534155};\\\", \\\"{x:1257,y:680,t:1527016534172};\\\", \\\"{x:1257,y:667,t:1527016534189};\\\", \\\"{x:1256,y:649,t:1527016534206};\\\", \\\"{x:1256,y:640,t:1527016534223};\\\", \\\"{x:1256,y:631,t:1527016534239};\\\", \\\"{x:1256,y:630,t:1527016534256};\\\", \\\"{x:1256,y:626,t:1527016534272};\\\", \\\"{x:1256,y:625,t:1527016534289};\\\", \\\"{x:1256,y:624,t:1527016534307};\\\", \\\"{x:1256,y:622,t:1527016534323};\\\", \\\"{x:1256,y:621,t:1527016534340};\\\", \\\"{x:1257,y:615,t:1527016534357};\\\", \\\"{x:1260,y:612,t:1527016534372};\\\", \\\"{x:1260,y:610,t:1527016534394};\\\", \\\"{x:1261,y:609,t:1527016534406};\\\", \\\"{x:1263,y:607,t:1527016534423};\\\", \\\"{x:1266,y:604,t:1527016534439};\\\", \\\"{x:1267,y:601,t:1527016534456};\\\", \\\"{x:1267,y:599,t:1527016534472};\\\", \\\"{x:1268,y:598,t:1527016534490};\\\", \\\"{x:1268,y:597,t:1527016534507};\\\", \\\"{x:1270,y:595,t:1527016534523};\\\", \\\"{x:1270,y:594,t:1527016534540};\\\", \\\"{x:1271,y:590,t:1527016534556};\\\", \\\"{x:1273,y:586,t:1527016534573};\\\", \\\"{x:1274,y:584,t:1527016534589};\\\", \\\"{x:1275,y:583,t:1527016534607};\\\", \\\"{x:1275,y:581,t:1527016534623};\\\", \\\"{x:1276,y:580,t:1527016534715};\\\", \\\"{x:1277,y:579,t:1527016534723};\\\", \\\"{x:1277,y:578,t:1527016534762};\\\", \\\"{x:1277,y:577,t:1527016534979};\\\", \\\"{x:1278,y:576,t:1527016535140};\\\", \\\"{x:1278,y:575,t:1527016535157};\\\", \\\"{x:1278,y:573,t:1527016535795};\\\", \\\"{x:1278,y:572,t:1527016535867};\\\", \\\"{x:1279,y:571,t:1527016535923};\\\", \\\"{x:1281,y:570,t:1527016538627};\\\", \\\"{x:1282,y:568,t:1527016538683};\\\", \\\"{x:1280,y:568,t:1527016540787};\\\", \\\"{x:1274,y:570,t:1527016540803};\\\", \\\"{x:1268,y:575,t:1527016540811};\\\", \\\"{x:1258,y:581,t:1527016540828};\\\", \\\"{x:1246,y:587,t:1527016540845};\\\", \\\"{x:1240,y:590,t:1527016540861};\\\", \\\"{x:1221,y:593,t:1527016540878};\\\", \\\"{x:1201,y:595,t:1527016540895};\\\", \\\"{x:1199,y:595,t:1527016540912};\\\", \\\"{x:1197,y:596,t:1527016540927};\\\", \\\"{x:1196,y:596,t:1527016540945};\\\", \\\"{x:1200,y:595,t:1527016541082};\\\", \\\"{x:1201,y:595,t:1527016541095};\\\", \\\"{x:1204,y:594,t:1527016541130};\\\", \\\"{x:1207,y:591,t:1527016541145};\\\", \\\"{x:1227,y:584,t:1527016541162};\\\", \\\"{x:1228,y:583,t:1527016541178};\\\", \\\"{x:1231,y:581,t:1527016541195};\\\", \\\"{x:1228,y:583,t:1527016541259};\\\", \\\"{x:1226,y:585,t:1527016541267};\\\", \\\"{x:1222,y:587,t:1527016541278};\\\", \\\"{x:1217,y:592,t:1527016541295};\\\", \\\"{x:1206,y:596,t:1527016541311};\\\", \\\"{x:1197,y:601,t:1527016541328};\\\", \\\"{x:1177,y:604,t:1527016541345};\\\", \\\"{x:1153,y:606,t:1527016541362};\\\", \\\"{x:1107,y:614,t:1527016541378};\\\", \\\"{x:1083,y:621,t:1527016541395};\\\", \\\"{x:1052,y:633,t:1527016541412};\\\", \\\"{x:999,y:639,t:1527016541428};\\\", \\\"{x:951,y:653,t:1527016541445};\\\", \\\"{x:928,y:658,t:1527016541462};\\\", \\\"{x:911,y:666,t:1527016541479};\\\", \\\"{x:879,y:667,t:1527016541495};\\\", \\\"{x:866,y:668,t:1527016541512};\\\", \\\"{x:837,y:668,t:1527016541528};\\\", \\\"{x:821,y:662,t:1527016541545};\\\", \\\"{x:802,y:654,t:1527016541562};\\\", \\\"{x:793,y:652,t:1527016541579};\\\", \\\"{x:786,y:651,t:1527016541595};\\\", \\\"{x:784,y:648,t:1527016541611};\\\", \\\"{x:771,y:643,t:1527016541629};\\\", \\\"{x:759,y:638,t:1527016541645};\\\", \\\"{x:749,y:634,t:1527016541662};\\\", \\\"{x:734,y:629,t:1527016541679};\\\", \\\"{x:720,y:622,t:1527016541696};\\\", \\\"{x:718,y:622,t:1527016541712};\\\", \\\"{x:715,y:615,t:1527016541728};\\\", \\\"{x:706,y:599,t:1527016541745};\\\", \\\"{x:695,y:586,t:1527016541762};\\\", \\\"{x:678,y:561,t:1527016541779};\\\", \\\"{x:669,y:551,t:1527016541796};\\\", \\\"{x:665,y:542,t:1527016541812};\\\", \\\"{x:665,y:535,t:1527016541829};\\\", \\\"{x:665,y:534,t:1527016541845};\\\", \\\"{x:665,y:530,t:1527016541862};\\\", \\\"{x:666,y:528,t:1527016541878};\\\", \\\"{x:666,y:525,t:1527016541895};\\\", \\\"{x:664,y:521,t:1527016541913};\\\", \\\"{x:658,y:516,t:1527016541929};\\\", \\\"{x:655,y:514,t:1527016541945};\\\", \\\"{x:651,y:511,t:1527016541962};\\\", \\\"{x:646,y:509,t:1527016541979};\\\", \\\"{x:642,y:509,t:1527016541997};\\\", \\\"{x:632,y:509,t:1527016542011};\\\", \\\"{x:629,y:509,t:1527016542029};\\\", \\\"{x:618,y:509,t:1527016542046};\\\", \\\"{x:612,y:509,t:1527016542062};\\\", \\\"{x:603,y:509,t:1527016542079};\\\", \\\"{x:600,y:509,t:1527016542095};\\\", \\\"{x:598,y:509,t:1527016542112};\\\", \\\"{x:598,y:508,t:1527016542259};\\\", \\\"{x:598,y:506,t:1527016542274};\\\", \\\"{x:600,y:505,t:1527016542283};\\\", \\\"{x:601,y:504,t:1527016542296};\\\", \\\"{x:605,y:502,t:1527016542312};\\\", \\\"{x:606,y:502,t:1527016542611};\\\", \\\"{x:607,y:502,t:1527016542627};\\\", \\\"{x:608,y:502,t:1527016542659};\\\", \\\"{x:610,y:502,t:1527016542683};\\\", \\\"{x:616,y:502,t:1527016542699};\\\", \\\"{x:627,y:510,t:1527016542713};\\\", \\\"{x:630,y:515,t:1527016542730};\\\", \\\"{x:686,y:539,t:1527016542748};\\\", \\\"{x:757,y:580,t:1527016542763};\\\", \\\"{x:840,y:629,t:1527016542780};\\\", \\\"{x:944,y:691,t:1527016542797};\\\", \\\"{x:1063,y:751,t:1527016542813};\\\", \\\"{x:1162,y:790,t:1527016542829};\\\", \\\"{x:1229,y:824,t:1527016542846};\\\", \\\"{x:1236,y:833,t:1527016542863};\\\", \\\"{x:1240,y:838,t:1527016542882};\\\", \\\"{x:1256,y:849,t:1527016542896};\\\", \\\"{x:1263,y:852,t:1527016542913};\\\", \\\"{x:1264,y:852,t:1527016542930};\\\", \\\"{x:1269,y:852,t:1527016542946};\\\", \\\"{x:1276,y:849,t:1527016542963};\\\", \\\"{x:1277,y:848,t:1527016542980};\\\", \\\"{x:1278,y:848,t:1527016543018};\\\", \\\"{x:1279,y:840,t:1527016552415};\\\", \\\"{x:1278,y:828,t:1527016552424};\\\", \\\"{x:1272,y:820,t:1527016552440};\\\", \\\"{x:1269,y:805,t:1527016552457};\\\", \\\"{x:1276,y:791,t:1527016552474};\\\", \\\"{x:1280,y:784,t:1527016552490};\\\", \\\"{x:1285,y:779,t:1527016552507};\\\", \\\"{x:1294,y:775,t:1527016552523};\\\", \\\"{x:1297,y:773,t:1527016552541};\\\", \\\"{x:1298,y:773,t:1527016552558};\\\", \\\"{x:1292,y:771,t:1527016552574};\\\", \\\"{x:1285,y:771,t:1527016552591};\\\", \\\"{x:1275,y:773,t:1527016553111};\\\", \\\"{x:1259,y:777,t:1527016553126};\\\", \\\"{x:1232,y:778,t:1527016553142};\\\", \\\"{x:1222,y:782,t:1527016553159};\\\", \\\"{x:1215,y:783,t:1527016553176};\\\", \\\"{x:1212,y:783,t:1527016553192};\\\", \\\"{x:1202,y:783,t:1527016553208};\\\", \\\"{x:1193,y:781,t:1527016553225};\\\", \\\"{x:1192,y:781,t:1527016553242};\\\", \\\"{x:1190,y:781,t:1527016553262};\\\", \\\"{x:1185,y:781,t:1527016553276};\\\", \\\"{x:1183,y:781,t:1527016553292};\\\", \\\"{x:1180,y:781,t:1527016553310};\\\", \\\"{x:1176,y:780,t:1527016553325};\\\", \\\"{x:1175,y:771,t:1527016553342};\\\", \\\"{x:1175,y:768,t:1527016553359};\\\", \\\"{x:1175,y:763,t:1527016553376};\\\", \\\"{x:1171,y:761,t:1527016553393};\\\", \\\"{x:1169,y:759,t:1527016553409};\\\", \\\"{x:1157,y:759,t:1527016553430};\\\", \\\"{x:1155,y:759,t:1527016553442};\\\", \\\"{x:1150,y:759,t:1527016553459};\\\", \\\"{x:1141,y:761,t:1527016553477};\\\", \\\"{x:1136,y:761,t:1527016553492};\\\", \\\"{x:1123,y:761,t:1527016553509};\\\", \\\"{x:1118,y:761,t:1527016553526};\\\", \\\"{x:1114,y:759,t:1527016553543};\\\", \\\"{x:1093,y:753,t:1527016553559};\\\", \\\"{x:1084,y:750,t:1527016553576};\\\", \\\"{x:1076,y:745,t:1527016553594};\\\", \\\"{x:1071,y:741,t:1527016553609};\\\", \\\"{x:1070,y:741,t:1527016554056};\\\", \\\"{x:1068,y:745,t:1527016554063};\\\", \\\"{x:1066,y:747,t:1527016554078};\\\", \\\"{x:1036,y:752,t:1527016554095};\\\", \\\"{x:1019,y:755,t:1527016554110};\\\", \\\"{x:1009,y:755,t:1527016554127};\\\", \\\"{x:993,y:755,t:1527016554144};\\\", \\\"{x:977,y:755,t:1527016554161};\\\", \\\"{x:951,y:754,t:1527016554178};\\\", \\\"{x:922,y:753,t:1527016554195};\\\", \\\"{x:883,y:741,t:1527016554212};\\\", \\\"{x:864,y:734,t:1527016554227};\\\", \\\"{x:832,y:725,t:1527016554245};\\\", \\\"{x:812,y:720,t:1527016554262};\\\", \\\"{x:786,y:708,t:1527016554278};\\\", \\\"{x:750,y:698,t:1527016554295};\\\", \\\"{x:735,y:694,t:1527016554312};\\\", \\\"{x:713,y:689,t:1527016554329};\\\", \\\"{x:703,y:688,t:1527016554345};\\\", \\\"{x:696,y:688,t:1527016554362};\\\", \\\"{x:693,y:688,t:1527016554391};\\\", \\\"{x:692,y:688,t:1527016554407};\\\", \\\"{x:690,y:688,t:1527016554416};\\\", \\\"{x:689,y:688,t:1527016554471};\\\", \\\"{x:689,y:689,t:1527016554479};\\\", \\\"{x:684,y:690,t:1527016554495};\\\", \\\"{x:678,y:694,t:1527016554512};\\\", \\\"{x:673,y:698,t:1527016554529};\\\", \\\"{x:659,y:707,t:1527016554546};\\\", \\\"{x:637,y:722,t:1527016554562};\\\", \\\"{x:621,y:733,t:1527016554579};\\\", \\\"{x:621,y:738,t:1527016554595};\\\", \\\"{x:614,y:743,t:1527016554613};\\\", \\\"{x:612,y:743,t:1527016554629};\\\", \\\"{x:610,y:743,t:1527016554646};\\\", \\\"{x:611,y:742,t:1527016555262};\\\", \\\"{x:613,y:740,t:1527016555336};\\\", \\\"{x:613,y:739,t:1527016555351};\\\", \\\"{x:616,y:735,t:1527016555364};\\\", \\\"{x:619,y:732,t:1527016555381};\\\", \\\"{x:624,y:727,t:1527016555398};\\\", \\\"{x:632,y:724,t:1527016555414};\\\", \\\"{x:633,y:723,t:1527016555431};\\\", \\\"{x:641,y:718,t:1527016555448};\\\", \\\"{x:697,y:704,t:1527016555465};\\\", \\\"{x:822,y:681,t:1527016555481};\\\", \\\"{x:991,y:661,t:1527016555498};\\\", \\\"{x:1098,y:632,t:1527016555514};\\\", \\\"{x:1242,y:608,t:1527016555530};\\\", \\\"{x:1346,y:600,t:1527016555548};\\\", \\\"{x:1457,y:584,t:1527016555565};\\\", \\\"{x:1531,y:568,t:1527016555582};\\\", \\\"{x:1567,y:561,t:1527016555597};\\\", \\\"{x:1579,y:555,t:1527016555614};\\\", \\\"{x:1575,y:555,t:1527016555792};\\\", \\\"{x:1565,y:559,t:1527016555799};\\\", \\\"{x:1553,y:565,t:1527016555814};\\\", \\\"{x:1543,y:562,t:1527016555832};\\\", \\\"{x:1531,y:562,t:1527016555850};\\\", \\\"{x:1525,y:563,t:1527016555865};\\\", \\\"{x:1517,y:566,t:1527016555883};\\\", \\\"{x:1511,y:567,t:1527016555900};\\\", \\\"{x:1500,y:572,t:1527016555916};\\\", \\\"{x:1499,y:572,t:1527016555933};\\\", \\\"{x:1498,y:572,t:1527016555992};\\\", \\\"{x:1497,y:572,t:1527016556007};\\\", \\\"{x:1496,y:572,t:1527016556017};\\\", \\\"{x:1495,y:572,t:1527016556055};\\\", \\\"{x:1490,y:572,t:1527016556067};\\\", \\\"{x:1475,y:570,t:1527016556083};\\\", \\\"{x:1464,y:568,t:1527016556099};\\\", \\\"{x:1446,y:568,t:1527016556116};\\\", \\\"{x:1439,y:563,t:1527016556133};\\\", \\\"{x:1430,y:556,t:1527016556151};\\\", \\\"{x:1419,y:551,t:1527016556167};\\\", \\\"{x:1394,y:546,t:1527016556183};\\\", \\\"{x:1390,y:546,t:1527016556200};\\\", \\\"{x:1389,y:546,t:1527016556231};\\\", \\\"{x:1386,y:546,t:1527016556239};\\\", \\\"{x:1383,y:546,t:1527016556250};\\\", \\\"{x:1378,y:546,t:1527016556266};\\\", \\\"{x:1371,y:546,t:1527016556284};\\\", \\\"{x:1370,y:546,t:1527016556300};\\\", \\\"{x:1365,y:551,t:1527016556317};\\\", \\\"{x:1357,y:555,t:1527016556333};\\\", \\\"{x:1335,y:560,t:1527016556350};\\\", \\\"{x:1329,y:569,t:1527016556367};\\\", \\\"{x:1321,y:572,t:1527016556391};\\\", \\\"{x:1320,y:572,t:1527016556401};\\\", \\\"{x:1312,y:575,t:1527016556418};\\\", \\\"{x:1294,y:587,t:1527016556434};\\\", \\\"{x:1257,y:602,t:1527016556450};\\\", \\\"{x:1239,y:617,t:1527016556467};\\\", \\\"{x:1217,y:633,t:1527016556484};\\\", \\\"{x:1215,y:635,t:1527016556500};\\\", \\\"{x:1213,y:635,t:1527016556983};\\\", \\\"{x:1212,y:638,t:1527016556991};\\\", \\\"{x:1205,y:645,t:1527016557002};\\\", \\\"{x:1195,y:653,t:1527016557019};\\\", \\\"{x:1185,y:663,t:1527016557035};\\\", \\\"{x:1150,y:686,t:1527016557052};\\\", \\\"{x:1123,y:702,t:1527016557068};\\\", \\\"{x:1102,y:718,t:1527016557087};\\\", \\\"{x:1089,y:730,t:1527016557102};\\\", \\\"{x:1085,y:731,t:1527016557119};\\\", \\\"{x:1080,y:734,t:1527016557520};\\\", \\\"{x:1059,y:738,t:1527016557536};\\\", \\\"{x:1031,y:744,t:1527016557554};\\\", \\\"{x:975,y:752,t:1527016557570};\\\", \\\"{x:930,y:753,t:1527016557586};\\\", \\\"{x:850,y:757,t:1527016557603};\\\", \\\"{x:755,y:756,t:1527016557620};\\\", \\\"{x:691,y:756,t:1527016557636};\\\", \\\"{x:667,y:756,t:1527016557653};\\\", \\\"{x:591,y:763,t:1527016557670};\\\", \\\"{x:538,y:773,t:1527016557687};\\\", \\\"{x:525,y:777,t:1527016557703};\\\", \\\"{x:524,y:776,t:1527016558903};\\\", \\\"{x:521,y:775,t:1527016558911};\\\", \\\"{x:520,y:774,t:1527016558924};\\\", \\\"{x:516,y:770,t:1527016558940};\\\", \\\"{x:515,y:769,t:1527016558957};\\\", \\\"{x:512,y:765,t:1527016558974};\\\", \\\"{x:509,y:764,t:1527016558990};\\\", \\\"{x:506,y:763,t:1527016559006};\\\", \\\"{x:505,y:762,t:1527016559023};\\\", \\\"{x:503,y:760,t:1527016559040};\\\", \\\"{x:501,y:759,t:1527016559056};\\\", \\\"{x:500,y:758,t:1527016559079};\\\", \\\"{x:500,y:756,t:1527016559279};\\\", \\\"{x:501,y:755,t:1527016559290};\\\", \\\"{x:505,y:752,t:1527016559308};\\\", \\\"{x:508,y:750,t:1527016559324};\\\", \\\"{x:513,y:746,t:1527016559340};\\\", \\\"{x:514,y:746,t:1527016559366};\\\", \\\"{x:515,y:745,t:1527016559487};\\\", \\\"{x:517,y:745,t:1527016559510};\\\", \\\"{x:517,y:744,t:1527016559527};\\\" ] }, { \\\"rt\\\": 33682, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 13, \\\"time_elapsed\\\": 634159, \\\"internal_node_id\\\": \\\"0.0-6.0-3.0\\\", \\\"subject\\\": \\\"6Y93F\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"foxtrot\\\", \\\"condition\\\": \\\"111\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"starttime+before+endtime+during\\\", \\\"q\\\": 9, \\\"clicks\\\": 1, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XInside-YFull\\\", \\\"correct\\\": 1, \\\"orth_correct\\\": 1, \\\"answer\\\": [ \\\"I\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-J -I -11 AM-10 AM-10 AM-10 AM-11 AM-12 PM\\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:521,y:744,t:1527016562847};\\\", \\\"{x:525,y:744,t:1527016562870};\\\", \\\"{x:528,y:744,t:1527016562883};\\\", \\\"{x:529,y:744,t:1527016562900};\\\", \\\"{x:539,y:744,t:1527016562916};\\\", \\\"{x:547,y:744,t:1527016562933};\\\", \\\"{x:560,y:743,t:1527016562951};\\\", \\\"{x:585,y:744,t:1527016562967};\\\", \\\"{x:591,y:744,t:1527016562984};\\\", \\\"{x:595,y:744,t:1527016563000};\\\", \\\"{x:603,y:746,t:1527016563016};\\\", \\\"{x:615,y:748,t:1527016563033};\\\", \\\"{x:622,y:751,t:1527016563050};\\\", \\\"{x:627,y:751,t:1527016563066};\\\", \\\"{x:628,y:751,t:1527016563083};\\\", \\\"{x:632,y:751,t:1527016563100};\\\", \\\"{x:643,y:751,t:1527016563116};\\\", \\\"{x:647,y:753,t:1527016563134};\\\", \\\"{x:650,y:753,t:1527016563150};\\\", \\\"{x:652,y:753,t:1527016563166};\\\", \\\"{x:653,y:753,t:1527016563183};\\\", \\\"{x:657,y:753,t:1527016563200};\\\", \\\"{x:661,y:752,t:1527016563217};\\\", \\\"{x:674,y:751,t:1527016563233};\\\", \\\"{x:676,y:751,t:1527016563250};\\\", \\\"{x:681,y:754,t:1527016563266};\\\", \\\"{x:687,y:754,t:1527016563283};\\\", \\\"{x:707,y:756,t:1527016563300};\\\", \\\"{x:723,y:756,t:1527016563316};\\\", \\\"{x:741,y:756,t:1527016563333};\\\", \\\"{x:774,y:756,t:1527016563351};\\\", \\\"{x:785,y:752,t:1527016563367};\\\", \\\"{x:802,y:749,t:1527016563383};\\\", \\\"{x:813,y:745,t:1527016563400};\\\", \\\"{x:826,y:743,t:1527016563416};\\\", \\\"{x:834,y:741,t:1527016563433};\\\", \\\"{x:846,y:739,t:1527016563450};\\\", \\\"{x:860,y:739,t:1527016563466};\\\", \\\"{x:876,y:738,t:1527016563483};\\\", \\\"{x:880,y:736,t:1527016563499};\\\", \\\"{x:884,y:731,t:1527016563516};\\\", \\\"{x:895,y:731,t:1527016563533};\\\", \\\"{x:900,y:731,t:1527016563549};\\\", \\\"{x:912,y:730,t:1527016563566};\\\", \\\"{x:935,y:720,t:1527016563583};\\\", \\\"{x:944,y:717,t:1527016563600};\\\", \\\"{x:962,y:712,t:1527016563616};\\\", \\\"{x:987,y:711,t:1527016563633};\\\", \\\"{x:991,y:711,t:1527016563650};\\\", \\\"{x:1005,y:710,t:1527016563666};\\\", \\\"{x:1024,y:700,t:1527016563683};\\\", \\\"{x:1044,y:695,t:1527016563701};\\\", \\\"{x:1075,y:684,t:1527016563717};\\\", \\\"{x:1130,y:679,t:1527016563734};\\\", \\\"{x:1131,y:679,t:1527016563751};\\\", \\\"{x:1138,y:679,t:1527016563767};\\\", \\\"{x:1142,y:679,t:1527016563783};\\\", \\\"{x:1155,y:679,t:1527016563800};\\\", \\\"{x:1165,y:681,t:1527016563818};\\\", \\\"{x:1167,y:682,t:1527016563833};\\\", \\\"{x:1168,y:682,t:1527016564351};\\\", \\\"{x:1173,y:682,t:1527016564367};\\\", \\\"{x:1180,y:677,t:1527016564383};\\\", \\\"{x:1188,y:671,t:1527016564400};\\\", \\\"{x:1197,y:666,t:1527016564417};\\\", \\\"{x:1210,y:653,t:1527016564433};\\\", \\\"{x:1225,y:639,t:1527016564450};\\\", \\\"{x:1239,y:624,t:1527016564467};\\\", \\\"{x:1257,y:610,t:1527016564484};\\\", \\\"{x:1264,y:604,t:1527016564501};\\\", \\\"{x:1272,y:598,t:1527016564518};\\\", \\\"{x:1275,y:594,t:1527016564534};\\\", \\\"{x:1283,y:583,t:1527016564551};\\\", \\\"{x:1285,y:582,t:1527016564567};\\\", \\\"{x:1285,y:583,t:1527016567567};\\\", \\\"{x:1284,y:587,t:1527016567586};\\\", \\\"{x:1280,y:588,t:1527016567602};\\\", \\\"{x:1279,y:590,t:1527016567619};\\\", \\\"{x:1278,y:594,t:1527016567635};\\\", \\\"{x:1276,y:597,t:1527016567651};\\\", \\\"{x:1276,y:598,t:1527016567669};\\\", \\\"{x:1276,y:599,t:1527016567687};\\\", \\\"{x:1276,y:600,t:1527016567702};\\\", \\\"{x:1275,y:605,t:1527016567719};\\\", \\\"{x:1275,y:609,t:1527016567735};\\\", \\\"{x:1276,y:611,t:1527016567751};\\\", \\\"{x:1276,y:613,t:1527016567768};\\\", \\\"{x:1276,y:615,t:1527016567786};\\\", \\\"{x:1276,y:618,t:1527016567803};\\\", \\\"{x:1276,y:621,t:1527016567819};\\\", \\\"{x:1276,y:622,t:1527016567835};\\\", \\\"{x:1276,y:625,t:1527016567852};\\\", \\\"{x:1275,y:625,t:1527016568063};\\\", \\\"{x:1274,y:625,t:1527016568104};\\\", \\\"{x:1272,y:625,t:1527016568487};\\\", \\\"{x:1270,y:625,t:1527016568562};\\\", \\\"{x:1270,y:624,t:1527016568694};\\\", \\\"{x:1269,y:624,t:1527016568702};\\\", \\\"{x:1269,y:623,t:1527016568808};\\\", \\\"{x:1269,y:621,t:1527016568819};\\\", \\\"{x:1269,y:619,t:1527016568847};\\\", \\\"{x:1269,y:618,t:1527016568855};\\\", \\\"{x:1273,y:615,t:1527016568869};\\\", \\\"{x:1275,y:615,t:1527016568885};\\\", \\\"{x:1280,y:612,t:1527016568903};\\\", \\\"{x:1281,y:611,t:1527016568919};\\\", \\\"{x:1281,y:610,t:1527016568935};\\\", \\\"{x:1282,y:611,t:1527016569415};\\\", \\\"{x:1282,y:616,t:1527016569423};\\\", \\\"{x:1277,y:630,t:1527016569437};\\\", \\\"{x:1268,y:654,t:1527016569454};\\\", \\\"{x:1250,y:697,t:1527016569470};\\\", \\\"{x:1241,y:733,t:1527016569487};\\\", \\\"{x:1230,y:754,t:1527016569504};\\\", \\\"{x:1221,y:770,t:1527016569520};\\\", \\\"{x:1219,y:784,t:1527016569536};\\\", \\\"{x:1218,y:793,t:1527016569553};\\\", \\\"{x:1215,y:800,t:1527016569569};\\\", \\\"{x:1213,y:807,t:1527016569587};\\\", \\\"{x:1211,y:810,t:1527016569603};\\\", \\\"{x:1209,y:813,t:1527016569620};\\\", \\\"{x:1208,y:814,t:1527016569943};\\\", \\\"{x:1208,y:816,t:1527016569953};\\\", \\\"{x:1208,y:817,t:1527016570071};\\\", \\\"{x:1207,y:817,t:1527016570287};\\\", \\\"{x:1206,y:816,t:1527016570303};\\\", \\\"{x:1204,y:812,t:1527016570320};\\\", \\\"{x:1201,y:809,t:1527016570336};\\\", \\\"{x:1201,y:806,t:1527016570354};\\\", \\\"{x:1198,y:801,t:1527016570369};\\\", \\\"{x:1194,y:796,t:1527016570387};\\\", \\\"{x:1185,y:783,t:1527016570404};\\\", \\\"{x:1181,y:778,t:1527016570419};\\\", \\\"{x:1181,y:776,t:1527016570437};\\\", \\\"{x:1181,y:775,t:1527016570454};\\\", \\\"{x:1180,y:773,t:1527016570469};\\\", \\\"{x:1179,y:772,t:1527016570566};\\\", \\\"{x:1180,y:776,t:1527016570757};\\\", \\\"{x:1182,y:788,t:1527016570769};\\\", \\\"{x:1186,y:796,t:1527016570786};\\\", \\\"{x:1192,y:805,t:1527016570803};\\\", \\\"{x:1192,y:812,t:1527016570819};\\\", \\\"{x:1194,y:820,t:1527016570836};\\\", \\\"{x:1195,y:823,t:1527016570854};\\\", \\\"{x:1196,y:824,t:1527016570951};\\\", \\\"{x:1197,y:824,t:1527016571063};\\\", \\\"{x:1200,y:824,t:1527016571071};\\\", \\\"{x:1203,y:825,t:1527016571087};\\\", \\\"{x:1208,y:826,t:1527016571103};\\\", \\\"{x:1210,y:828,t:1527016571124};\\\", \\\"{x:1221,y:833,t:1527016571137};\\\", \\\"{x:1230,y:837,t:1527016571153};\\\", \\\"{x:1237,y:841,t:1527016571170};\\\", \\\"{x:1244,y:845,t:1527016571186};\\\", \\\"{x:1243,y:845,t:1527016571446};\\\", \\\"{x:1242,y:845,t:1527016571454};\\\", \\\"{x:1237,y:845,t:1527016571470};\\\", \\\"{x:1236,y:845,t:1527016571486};\\\", \\\"{x:1235,y:845,t:1527016571503};\\\", \\\"{x:1234,y:845,t:1527016571520};\\\", \\\"{x:1231,y:845,t:1527016571537};\\\", \\\"{x:1230,y:845,t:1527016571566};\\\", \\\"{x:1229,y:845,t:1527016571623};\\\", \\\"{x:1227,y:845,t:1527016571636};\\\", \\\"{x:1226,y:845,t:1527016571653};\\\", \\\"{x:1222,y:845,t:1527016571671};\\\", \\\"{x:1220,y:845,t:1527016571686};\\\", \\\"{x:1216,y:844,t:1527016571704};\\\", \\\"{x:1213,y:840,t:1527016571721};\\\", \\\"{x:1208,y:837,t:1527016571737};\\\", \\\"{x:1206,y:835,t:1527016571754};\\\", \\\"{x:1205,y:834,t:1527016571770};\\\", \\\"{x:1205,y:831,t:1527016571786};\\\", \\\"{x:1202,y:827,t:1527016571803};\\\", \\\"{x:1202,y:825,t:1527016571854};\\\", \\\"{x:1201,y:825,t:1527016571871};\\\", \\\"{x:1200,y:825,t:1527016571886};\\\", \\\"{x:1199,y:825,t:1527016571903};\\\", \\\"{x:1198,y:825,t:1527016571920};\\\", \\\"{x:1196,y:825,t:1527016571937};\\\", \\\"{x:1195,y:824,t:1527016571974};\\\", \\\"{x:1192,y:823,t:1527016571990};\\\", \\\"{x:1192,y:822,t:1527016572006};\\\", \\\"{x:1192,y:821,t:1527016572020};\\\", \\\"{x:1192,y:819,t:1527016572037};\\\", \\\"{x:1191,y:817,t:1527016572053};\\\", \\\"{x:1188,y:812,t:1527016572070};\\\", \\\"{x:1186,y:810,t:1527016572087};\\\", \\\"{x:1184,y:809,t:1527016572104};\\\", \\\"{x:1181,y:806,t:1527016572121};\\\", \\\"{x:1180,y:802,t:1527016572137};\\\", \\\"{x:1178,y:800,t:1527016572153};\\\", \\\"{x:1178,y:799,t:1527016572823};\\\", \\\"{x:1178,y:798,t:1527016572935};\\\", \\\"{x:1179,y:798,t:1527016572943};\\\", \\\"{x:1179,y:797,t:1527016573183};\\\", \\\"{x:1179,y:796,t:1527016573335};\\\", \\\"{x:1180,y:794,t:1527016573351};\\\", \\\"{x:1181,y:792,t:1527016573360};\\\", \\\"{x:1182,y:791,t:1527016573370};\\\", \\\"{x:1184,y:788,t:1527016573388};\\\", \\\"{x:1184,y:787,t:1527016573405};\\\", \\\"{x:1184,y:786,t:1527016573423};\\\", \\\"{x:1185,y:784,t:1527016573438};\\\", \\\"{x:1186,y:779,t:1527016573455};\\\", \\\"{x:1186,y:777,t:1527016573471};\\\", \\\"{x:1186,y:775,t:1527016573488};\\\", \\\"{x:1185,y:772,t:1527016573511};\\\", \\\"{x:1185,y:770,t:1527016573534};\\\", \\\"{x:1184,y:770,t:1527016573543};\\\", \\\"{x:1184,y:769,t:1527016573575};\\\", \\\"{x:1183,y:767,t:1527016573600};\\\", \\\"{x:1183,y:766,t:1527016573630};\\\", \\\"{x:1183,y:765,t:1527016573639};\\\", \\\"{x:1183,y:764,t:1527016573678};\\\", \\\"{x:1183,y:762,t:1527016574415};\\\", \\\"{x:1185,y:761,t:1527016574423};\\\", \\\"{x:1185,y:759,t:1527016574439};\\\", \\\"{x:1188,y:759,t:1527016574600};\\\", \\\"{x:1193,y:759,t:1527016574607};\\\", \\\"{x:1197,y:759,t:1527016574622};\\\", \\\"{x:1203,y:759,t:1527016574639};\\\", \\\"{x:1205,y:759,t:1527016574655};\\\", \\\"{x:1213,y:764,t:1527016574672};\\\", \\\"{x:1217,y:766,t:1527016574689};\\\", \\\"{x:1218,y:766,t:1527016574705};\\\", \\\"{x:1220,y:768,t:1527016574816};\\\", \\\"{x:1230,y:780,t:1527016574822};\\\", \\\"{x:1239,y:791,t:1527016574839};\\\", \\\"{x:1253,y:805,t:1527016574855};\\\", \\\"{x:1257,y:812,t:1527016574872};\\\", \\\"{x:1263,y:819,t:1527016574889};\\\", \\\"{x:1267,y:828,t:1527016574905};\\\", \\\"{x:1269,y:834,t:1527016574921};\\\", \\\"{x:1272,y:853,t:1527016574939};\\\", \\\"{x:1279,y:874,t:1527016574955};\\\", \\\"{x:1284,y:882,t:1527016574972};\\\", \\\"{x:1293,y:899,t:1527016574989};\\\", \\\"{x:1304,y:914,t:1527016575005};\\\", \\\"{x:1304,y:915,t:1527016575022};\\\", \\\"{x:1304,y:918,t:1527016575039};\\\", \\\"{x:1304,y:921,t:1527016575055};\\\", \\\"{x:1304,y:925,t:1527016575072};\\\", \\\"{x:1304,y:927,t:1527016575089};\\\", \\\"{x:1303,y:928,t:1527016575119};\\\", \\\"{x:1302,y:930,t:1527016575127};\\\", \\\"{x:1302,y:933,t:1527016575139};\\\", \\\"{x:1300,y:936,t:1527016575155};\\\", \\\"{x:1299,y:937,t:1527016575172};\\\", \\\"{x:1299,y:938,t:1527016575271};\\\", \\\"{x:1296,y:939,t:1527016575289};\\\", \\\"{x:1295,y:940,t:1527016575327};\\\", \\\"{x:1293,y:942,t:1527016575351};\\\", \\\"{x:1293,y:944,t:1527016575360};\\\", \\\"{x:1292,y:944,t:1527016575371};\\\", \\\"{x:1291,y:946,t:1527016575390};\\\", \\\"{x:1290,y:946,t:1527016575440};\\\", \\\"{x:1289,y:946,t:1527016575591};\\\", \\\"{x:1290,y:946,t:1527016575607};\\\", \\\"{x:1294,y:946,t:1527016575622};\\\", \\\"{x:1297,y:946,t:1527016575639};\\\", \\\"{x:1304,y:945,t:1527016575656};\\\", \\\"{x:1314,y:945,t:1527016575672};\\\", \\\"{x:1317,y:945,t:1527016575689};\\\", \\\"{x:1321,y:945,t:1527016575887};\\\", \\\"{x:1330,y:945,t:1527016575895};\\\", \\\"{x:1335,y:945,t:1527016575906};\\\", \\\"{x:1338,y:945,t:1527016575922};\\\", \\\"{x:1343,y:945,t:1527016575939};\\\", \\\"{x:1345,y:945,t:1527016575955};\\\", \\\"{x:1348,y:945,t:1527016575972};\\\", \\\"{x:1349,y:943,t:1527016575988};\\\", \\\"{x:1350,y:943,t:1527016576039};\\\", \\\"{x:1349,y:943,t:1527016576167};\\\", \\\"{x:1347,y:943,t:1527016576174};\\\", \\\"{x:1346,y:943,t:1527016576189};\\\", \\\"{x:1341,y:944,t:1527016576206};\\\", \\\"{x:1322,y:950,t:1527016576222};\\\", \\\"{x:1311,y:959,t:1527016576239};\\\", \\\"{x:1295,y:970,t:1527016576257};\\\", \\\"{x:1285,y:978,t:1527016576273};\\\", \\\"{x:1271,y:985,t:1527016576289};\\\", \\\"{x:1265,y:990,t:1527016576306};\\\", \\\"{x:1255,y:998,t:1527016576322};\\\", \\\"{x:1249,y:1004,t:1527016576339};\\\", \\\"{x:1247,y:1005,t:1527016576356};\\\", \\\"{x:1246,y:1006,t:1527016576372};\\\", \\\"{x:1246,y:1007,t:1527016576471};\\\", \\\"{x:1244,y:1006,t:1527016576479};\\\", \\\"{x:1243,y:1004,t:1527016576503};\\\", \\\"{x:1242,y:1001,t:1527016576510};\\\", \\\"{x:1241,y:999,t:1527016576527};\\\", \\\"{x:1238,y:994,t:1527016576539};\\\", \\\"{x:1236,y:984,t:1527016576556};\\\", \\\"{x:1235,y:981,t:1527016576573};\\\", \\\"{x:1233,y:975,t:1527016576589};\\\", \\\"{x:1231,y:971,t:1527016576606};\\\", \\\"{x:1229,y:967,t:1527016576624};\\\", \\\"{x:1228,y:966,t:1527016576639};\\\", \\\"{x:1228,y:960,t:1527016576656};\\\", \\\"{x:1227,y:958,t:1527016576673};\\\", \\\"{x:1227,y:956,t:1527016576689};\\\", \\\"{x:1226,y:956,t:1527016576879};\\\", \\\"{x:1220,y:958,t:1527016576889};\\\", \\\"{x:1210,y:963,t:1527016576906};\\\", \\\"{x:1196,y:971,t:1527016576923};\\\", \\\"{x:1188,y:974,t:1527016576940};\\\", \\\"{x:1181,y:978,t:1527016576956};\\\", \\\"{x:1181,y:979,t:1527016576973};\\\", \\\"{x:1180,y:980,t:1527016576990};\\\", \\\"{x:1179,y:981,t:1527016577006};\\\", \\\"{x:1179,y:982,t:1527016577071};\\\", \\\"{x:1179,y:983,t:1527016577263};\\\", \\\"{x:1180,y:982,t:1527016577273};\\\", \\\"{x:1185,y:980,t:1527016577290};\\\", \\\"{x:1188,y:977,t:1527016577305};\\\", \\\"{x:1194,y:975,t:1527016577323};\\\", \\\"{x:1197,y:975,t:1527016577340};\\\", \\\"{x:1203,y:975,t:1527016577355};\\\", \\\"{x:1206,y:975,t:1527016577407};\\\", \\\"{x:1208,y:974,t:1527016577423};\\\", \\\"{x:1216,y:972,t:1527016577439};\\\", \\\"{x:1222,y:970,t:1527016577456};\\\", \\\"{x:1225,y:969,t:1527016577472};\\\", \\\"{x:1226,y:967,t:1527016577490};\\\", \\\"{x:1227,y:967,t:1527016577535};\\\", \\\"{x:1230,y:965,t:1527016577561};\\\", \\\"{x:1231,y:965,t:1527016577573};\\\", \\\"{x:1236,y:965,t:1527016577590};\\\", \\\"{x:1245,y:966,t:1527016577607};\\\", \\\"{x:1247,y:967,t:1527016577623};\\\", \\\"{x:1248,y:968,t:1527016577640};\\\", \\\"{x:1248,y:969,t:1527016577657};\\\", \\\"{x:1255,y:972,t:1527016577895};\\\", \\\"{x:1260,y:975,t:1527016577907};\\\", \\\"{x:1281,y:978,t:1527016577923};\\\", \\\"{x:1296,y:978,t:1527016577940};\\\", \\\"{x:1304,y:978,t:1527016577957};\\\", \\\"{x:1305,y:978,t:1527016577973};\\\", \\\"{x:1306,y:978,t:1527016578151};\\\", \\\"{x:1309,y:978,t:1527016578160};\\\", \\\"{x:1313,y:978,t:1527016578173};\\\", \\\"{x:1317,y:976,t:1527016578190};\\\", \\\"{x:1321,y:974,t:1527016578207};\\\", \\\"{x:1322,y:973,t:1527016578231};\\\", \\\"{x:1323,y:972,t:1527016578526};\\\", \\\"{x:1325,y:972,t:1527016578539};\\\", \\\"{x:1326,y:972,t:1527016578556};\\\", \\\"{x:1327,y:971,t:1527016578573};\\\", \\\"{x:1328,y:971,t:1527016578622};\\\", \\\"{x:1330,y:970,t:1527016578640};\\\", \\\"{x:1331,y:970,t:1527016578656};\\\", \\\"{x:1334,y:970,t:1527016578674};\\\", \\\"{x:1338,y:970,t:1527016578690};\\\", \\\"{x:1339,y:970,t:1527016578707};\\\", \\\"{x:1343,y:970,t:1527016578723};\\\", \\\"{x:1345,y:969,t:1527016578740};\\\", \\\"{x:1345,y:967,t:1527016578783};\\\", \\\"{x:1346,y:966,t:1527016578887};\\\", \\\"{x:1347,y:966,t:1527016578895};\\\", \\\"{x:1348,y:966,t:1527016578911};\\\", \\\"{x:1348,y:965,t:1527016578924};\\\", \\\"{x:1352,y:963,t:1527016578940};\\\", \\\"{x:1356,y:963,t:1527016578957};\\\", \\\"{x:1363,y:960,t:1527016578975};\\\", \\\"{x:1366,y:960,t:1527016578990};\\\", \\\"{x:1381,y:960,t:1527016579007};\\\", \\\"{x:1389,y:959,t:1527016579024};\\\", \\\"{x:1390,y:959,t:1527016579040};\\\", \\\"{x:1391,y:959,t:1527016579057};\\\", \\\"{x:1390,y:960,t:1527016579248};\\\", \\\"{x:1389,y:960,t:1527016579257};\\\", \\\"{x:1387,y:961,t:1527016579274};\\\", \\\"{x:1385,y:962,t:1527016579291};\\\", \\\"{x:1384,y:964,t:1527016579307};\\\", \\\"{x:1383,y:964,t:1527016579983};\\\", \\\"{x:1378,y:963,t:1527016579991};\\\", \\\"{x:1372,y:955,t:1527016580008};\\\", \\\"{x:1354,y:939,t:1527016580024};\\\", \\\"{x:1337,y:925,t:1527016580041};\\\", \\\"{x:1314,y:908,t:1527016580057};\\\", \\\"{x:1313,y:908,t:1527016580074};\\\", \\\"{x:1303,y:901,t:1527016580091};\\\", \\\"{x:1299,y:892,t:1527016580108};\\\", \\\"{x:1282,y:879,t:1527016580124};\\\", \\\"{x:1263,y:858,t:1527016580142};\\\", \\\"{x:1235,y:832,t:1527016580158};\\\", \\\"{x:1183,y:796,t:1527016580174};\\\", \\\"{x:1159,y:776,t:1527016580191};\\\", \\\"{x:1143,y:766,t:1527016580208};\\\", \\\"{x:1128,y:759,t:1527016580224};\\\", \\\"{x:1113,y:751,t:1527016580241};\\\", \\\"{x:1098,y:745,t:1527016580258};\\\", \\\"{x:1089,y:738,t:1527016580274};\\\", \\\"{x:1063,y:725,t:1527016580290};\\\", \\\"{x:1009,y:703,t:1527016580307};\\\", \\\"{x:969,y:691,t:1527016580324};\\\", \\\"{x:922,y:667,t:1527016580341};\\\", \\\"{x:879,y:640,t:1527016580358};\\\", \\\"{x:860,y:630,t:1527016580376};\\\", \\\"{x:833,y:616,t:1527016580391};\\\", \\\"{x:803,y:605,t:1527016580407};\\\", \\\"{x:764,y:595,t:1527016580431};\\\", \\\"{x:753,y:591,t:1527016580447};\\\", \\\"{x:743,y:588,t:1527016580463};\\\", \\\"{x:731,y:585,t:1527016580480};\\\", \\\"{x:716,y:581,t:1527016580498};\\\", \\\"{x:697,y:580,t:1527016580513};\\\", \\\"{x:683,y:578,t:1527016580530};\\\", \\\"{x:662,y:576,t:1527016580547};\\\", \\\"{x:659,y:576,t:1527016580564};\\\", \\\"{x:652,y:575,t:1527016580581};\\\", \\\"{x:648,y:575,t:1527016580597};\\\", \\\"{x:637,y:575,t:1527016580614};\\\", \\\"{x:612,y:579,t:1527016580630};\\\", \\\"{x:604,y:583,t:1527016580648};\\\", \\\"{x:600,y:585,t:1527016580664};\\\", \\\"{x:594,y:587,t:1527016580681};\\\", \\\"{x:592,y:588,t:1527016580698};\\\", \\\"{x:591,y:589,t:1527016580714};\\\", \\\"{x:590,y:589,t:1527016580730};\\\", \\\"{x:592,y:589,t:1527016581775};\\\", \\\"{x:593,y:589,t:1527016581783};\\\", \\\"{x:595,y:589,t:1527016581797};\\\", \\\"{x:600,y:585,t:1527016581816};\\\", \\\"{x:602,y:584,t:1527016581831};\\\", \\\"{x:606,y:580,t:1527016581848};\\\", \\\"{x:609,y:577,t:1527016581865};\\\", \\\"{x:612,y:577,t:1527016581881};\\\", \\\"{x:615,y:574,t:1527016581899};\\\", \\\"{x:617,y:573,t:1527016581915};\\\", \\\"{x:620,y:570,t:1527016581931};\\\", \\\"{x:622,y:569,t:1527016581949};\\\", \\\"{x:624,y:568,t:1527016581965};\\\", \\\"{x:624,y:567,t:1527016581981};\\\", \\\"{x:628,y:565,t:1527016581998};\\\", \\\"{x:629,y:563,t:1527016582016};\\\", \\\"{x:630,y:561,t:1527016582031};\\\", \\\"{x:631,y:561,t:1527016582048};\\\", \\\"{x:632,y:559,t:1527016582078};\\\", \\\"{x:632,y:558,t:1527016582150};\\\", \\\"{x:631,y:558,t:1527016582164};\\\", \\\"{x:630,y:557,t:1527016582190};\\\", \\\"{x:628,y:555,t:1527016582215};\\\", \\\"{x:625,y:549,t:1527016582232};\\\", \\\"{x:617,y:536,t:1527016582249};\\\", \\\"{x:607,y:524,t:1527016582265};\\\", \\\"{x:591,y:517,t:1527016582282};\\\", \\\"{x:585,y:510,t:1527016582298};\\\", \\\"{x:575,y:508,t:1527016582315};\\\", \\\"{x:564,y:504,t:1527016582331};\\\", \\\"{x:563,y:504,t:1527016582350};\\\", \\\"{x:556,y:504,t:1527016582365};\\\", \\\"{x:548,y:504,t:1527016582382};\\\", \\\"{x:538,y:504,t:1527016582398};\\\", \\\"{x:537,y:505,t:1527016582430};\\\", \\\"{x:535,y:506,t:1527016582438};\\\", \\\"{x:531,y:508,t:1527016582449};\\\", \\\"{x:528,y:511,t:1527016582465};\\\", \\\"{x:526,y:516,t:1527016582482};\\\", \\\"{x:518,y:519,t:1527016582499};\\\", \\\"{x:507,y:526,t:1527016582516};\\\", \\\"{x:490,y:532,t:1527016582532};\\\", \\\"{x:478,y:538,t:1527016582549};\\\", \\\"{x:460,y:544,t:1527016582564};\\\", \\\"{x:342,y:548,t:1527016582582};\\\", \\\"{x:329,y:543,t:1527016582599};\\\", \\\"{x:297,y:536,t:1527016582615};\\\", \\\"{x:264,y:531,t:1527016582632};\\\", \\\"{x:246,y:531,t:1527016582649};\\\", \\\"{x:231,y:531,t:1527016582665};\\\", \\\"{x:227,y:531,t:1527016582681};\\\", \\\"{x:216,y:531,t:1527016582699};\\\", \\\"{x:208,y:531,t:1527016582715};\\\", \\\"{x:196,y:529,t:1527016582732};\\\", \\\"{x:186,y:529,t:1527016582750};\\\", \\\"{x:185,y:527,t:1527016582870};\\\", \\\"{x:181,y:525,t:1527016582882};\\\", \\\"{x:172,y:522,t:1527016582899};\\\", \\\"{x:167,y:522,t:1527016582915};\\\", \\\"{x:158,y:516,t:1527016582933};\\\", \\\"{x:147,y:510,t:1527016582948};\\\", \\\"{x:142,y:508,t:1527016582966};\\\", \\\"{x:138,y:506,t:1527016582983};\\\", \\\"{x:137,y:505,t:1527016582998};\\\", \\\"{x:135,y:503,t:1527016583015};\\\", \\\"{x:134,y:502,t:1527016583032};\\\", \\\"{x:135,y:502,t:1527016583162};\\\", \\\"{x:136,y:502,t:1527016583165};\\\", \\\"{x:137,y:502,t:1527016583254};\\\", \\\"{x:138,y:502,t:1527016583310};\\\", \\\"{x:140,y:502,t:1527016583342};\\\", \\\"{x:141,y:502,t:1527016583358};\\\", \\\"{x:144,y:502,t:1527016583365};\\\", \\\"{x:148,y:503,t:1527016583382};\\\", \\\"{x:150,y:504,t:1527016583399};\\\", \\\"{x:154,y:505,t:1527016583415};\\\", \\\"{x:160,y:505,t:1527016583432};\\\", \\\"{x:165,y:505,t:1527016583449};\\\", \\\"{x:171,y:504,t:1527016583466};\\\", \\\"{x:173,y:504,t:1527016583483};\\\", \\\"{x:172,y:504,t:1527016583671};\\\", \\\"{x:171,y:505,t:1527016583684};\\\", \\\"{x:166,y:505,t:1527016583699};\\\", \\\"{x:166,y:506,t:1527016584078};\\\", \\\"{x:172,y:509,t:1527016584086};\\\", \\\"{x:179,y:511,t:1527016584100};\\\", \\\"{x:202,y:520,t:1527016584117};\\\", \\\"{x:242,y:536,t:1527016584134};\\\", \\\"{x:270,y:542,t:1527016584150};\\\", \\\"{x:343,y:565,t:1527016584167};\\\", \\\"{x:408,y:585,t:1527016584183};\\\", \\\"{x:523,y:624,t:1527016584200};\\\", \\\"{x:532,y:627,t:1527016584217};\\\", \\\"{x:549,y:638,t:1527016584234};\\\", \\\"{x:578,y:655,t:1527016584249};\\\", \\\"{x:635,y:673,t:1527016584266};\\\", \\\"{x:651,y:682,t:1527016584284};\\\", \\\"{x:662,y:693,t:1527016584300};\\\", \\\"{x:667,y:702,t:1527016584317};\\\", \\\"{x:683,y:722,t:1527016584334};\\\", \\\"{x:689,y:730,t:1527016584349};\\\", \\\"{x:713,y:752,t:1527016584366};\\\", \\\"{x:730,y:763,t:1527016584383};\\\", \\\"{x:746,y:779,t:1527016584400};\\\", \\\"{x:758,y:788,t:1527016584416};\\\", \\\"{x:766,y:792,t:1527016584433};\\\", \\\"{x:760,y:794,t:1527016593086};\\\", \\\"{x:753,y:796,t:1527016593094};\\\", \\\"{x:749,y:798,t:1527016593110};\\\", \\\"{x:748,y:799,t:1527016593126};\\\", \\\"{x:748,y:774,t:1527016593263};\\\", \\\"{x:742,y:685,t:1527016593276};\\\", \\\"{x:713,y:518,t:1527016593293};\\\", \\\"{x:664,y:346,t:1527016593311};\\\", \\\"{x:641,y:300,t:1527016593326};\\\", \\\"{x:637,y:295,t:1527016593343};\\\", \\\"{x:636,y:298,t:1527016593414};\\\", \\\"{x:633,y:301,t:1527016593426};\\\", \\\"{x:627,y:309,t:1527016593443};\\\", \\\"{x:620,y:319,t:1527016593460};\\\", \\\"{x:612,y:333,t:1527016593477};\\\", \\\"{x:593,y:383,t:1527016593493};\\\", \\\"{x:560,y:529,t:1527016593512};\\\", \\\"{x:543,y:598,t:1527016593526};\\\", \\\"{x:527,y:698,t:1527016593543};\\\", \\\"{x:526,y:701,t:1527016593557};\\\", \\\"{x:508,y:785,t:1527016593574};\\\", \\\"{x:509,y:794,t:1527016593590};\\\", \\\"{x:509,y:798,t:1527016593608};\\\", \\\"{x:509,y:796,t:1527016593847};\\\", \\\"{x:511,y:792,t:1527016593858};\\\", \\\"{x:511,y:788,t:1527016593876};\\\", \\\"{x:511,y:787,t:1527016593892};\\\", \\\"{x:511,y:782,t:1527016593908};\\\", \\\"{x:513,y:777,t:1527016593925};\\\", \\\"{x:513,y:776,t:1527016593941};\\\", \\\"{x:515,y:770,t:1527016593959};\\\", \\\"{x:515,y:769,t:1527016593975};\\\", \\\"{x:517,y:763,t:1527016593991};\\\", \\\"{x:520,y:748,t:1527016594010};\\\", \\\"{x:526,y:735,t:1527016594025};\\\", \\\"{x:528,y:722,t:1527016594040};\\\", \\\"{x:534,y:710,t:1527016594057};\\\", \\\"{x:536,y:707,t:1527016594072};\\\", \\\"{x:535,y:708,t:1527016594222};\\\", \\\"{x:534,y:712,t:1527016594229};\\\", \\\"{x:533,y:713,t:1527016594241};\\\", \\\"{x:533,y:717,t:1527016594258};\\\", \\\"{x:532,y:718,t:1527016594275};\\\", \\\"{x:532,y:721,t:1527016594293};\\\", \\\"{x:531,y:722,t:1527016594308};\\\", \\\"{x:531,y:723,t:1527016594495};\\\", \\\"{x:531,y:724,t:1527016594534};\\\", \\\"{x:529,y:725,t:1527016594542};\\\", \\\"{x:528,y:726,t:1527016594558};\\\", \\\"{x:528,y:728,t:1527016595150};\\\" ] }, { \\\"rt\\\": 123331, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 14, \\\"time_elapsed\\\": 758715, \\\"internal_node_id\\\": \\\"0.0-6.0-4.0\\\", \\\"subject\\\": \\\"6Y93F\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"foxtrot\\\", \\\"condition\\\": \\\"111\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"ends\\\", \\\"q\\\": 10, \\\"clicks\\\": 1.5, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XInside-YFull\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 1, \\\"answer\\\": [ \\\"X\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-H -E -Z -Z -F -10 AM-02 PM-X -E -C -J -B -O -O -Z -02 PM-X -O -X -X -K -K \\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:532,y:729,t:1527016597726};\\\", \\\"{x:562,y:726,t:1527016597750};\\\", \\\"{x:576,y:728,t:1527016597764};\\\", \\\"{x:591,y:734,t:1527016597780};\\\", \\\"{x:607,y:739,t:1527016597794};\\\", \\\"{x:612,y:742,t:1527016597811};\\\", \\\"{x:621,y:742,t:1527016597827};\\\", \\\"{x:626,y:742,t:1527016597844};\\\", \\\"{x:644,y:742,t:1527016597860};\\\", \\\"{x:661,y:742,t:1527016597877};\\\", \\\"{x:681,y:743,t:1527016597893};\\\", \\\"{x:693,y:743,t:1527016597911};\\\", \\\"{x:698,y:744,t:1527016597927};\\\", \\\"{x:699,y:744,t:1527016597944};\\\", \\\"{x:701,y:744,t:1527016597961};\\\", \\\"{x:710,y:744,t:1527016597978};\\\", \\\"{x:722,y:746,t:1527016597995};\\\", \\\"{x:726,y:750,t:1527016598012};\\\", \\\"{x:746,y:753,t:1527016598027};\\\", \\\"{x:766,y:753,t:1527016598045};\\\", \\\"{x:783,y:753,t:1527016598061};\\\", \\\"{x:798,y:753,t:1527016598077};\\\", \\\"{x:814,y:753,t:1527016598094};\\\", \\\"{x:815,y:753,t:1527016598535};\\\", \\\"{x:817,y:753,t:1527016598566};\\\", \\\"{x:818,y:752,t:1527016598578};\\\", \\\"{x:820,y:751,t:1527016598595};\\\", \\\"{x:827,y:748,t:1527016598611};\\\", \\\"{x:833,y:748,t:1527016598629};\\\", \\\"{x:843,y:746,t:1527016598644};\\\", \\\"{x:847,y:743,t:1527016598662};\\\", \\\"{x:923,y:739,t:1527016598678};\\\", \\\"{x:1030,y:747,t:1527016598695};\\\", \\\"{x:1053,y:751,t:1527016598712};\\\", \\\"{x:1135,y:758,t:1527016598728};\\\", \\\"{x:1202,y:768,t:1527016598744};\\\", \\\"{x:1266,y:775,t:1527016598761};\\\", \\\"{x:1286,y:780,t:1527016598779};\\\", \\\"{x:1287,y:781,t:1527016598795};\\\", \\\"{x:1292,y:781,t:1527016599311};\\\", \\\"{x:1309,y:775,t:1527016599329};\\\", \\\"{x:1317,y:772,t:1527016599344};\\\", \\\"{x:1323,y:768,t:1527016599362};\\\", \\\"{x:1327,y:768,t:1527016599379};\\\", \\\"{x:1340,y:759,t:1527016599395};\\\", \\\"{x:1358,y:750,t:1527016599411};\\\", \\\"{x:1363,y:748,t:1527016599428};\\\", \\\"{x:1366,y:746,t:1527016599445};\\\", \\\"{x:1368,y:746,t:1527016599461};\\\", \\\"{x:1378,y:744,t:1527016599478};\\\", \\\"{x:1383,y:744,t:1527016599495};\\\", \\\"{x:1384,y:744,t:1527016599511};\\\", \\\"{x:1387,y:744,t:1527016599566};\\\", \\\"{x:1388,y:744,t:1527016599579};\\\", \\\"{x:1391,y:744,t:1527016599595};\\\", \\\"{x:1392,y:744,t:1527016599611};\\\", \\\"{x:1391,y:744,t:1527016600319};\\\", \\\"{x:1390,y:744,t:1527016600335};\\\", \\\"{x:1388,y:744,t:1527016600346};\\\", \\\"{x:1383,y:747,t:1527016600363};\\\", \\\"{x:1383,y:748,t:1527016600379};\\\", \\\"{x:1381,y:748,t:1527016600581};\\\", \\\"{x:1378,y:748,t:1527016600596};\\\", \\\"{x:1376,y:748,t:1527016600612};\\\", \\\"{x:1374,y:748,t:1527016600629};\\\", \\\"{x:1370,y:746,t:1527016601471};\\\", \\\"{x:1369,y:744,t:1527016601479};\\\", \\\"{x:1368,y:741,t:1527016601497};\\\", \\\"{x:1372,y:731,t:1527016601513};\\\", \\\"{x:1385,y:718,t:1527016601529};\\\", \\\"{x:1392,y:709,t:1527016601546};\\\", \\\"{x:1408,y:693,t:1527016601562};\\\", \\\"{x:1430,y:681,t:1527016601580};\\\", \\\"{x:1435,y:676,t:1527016601596};\\\", \\\"{x:1450,y:666,t:1527016601613};\\\", \\\"{x:1472,y:650,t:1527016601630};\\\", \\\"{x:1482,y:643,t:1527016601647};\\\", \\\"{x:1485,y:641,t:1527016601662};\\\", \\\"{x:1488,y:640,t:1527016601680};\\\", \\\"{x:1496,y:635,t:1527016601697};\\\", \\\"{x:1501,y:632,t:1527016601713};\\\", \\\"{x:1510,y:626,t:1527016601729};\\\", \\\"{x:1518,y:617,t:1527016601747};\\\", \\\"{x:1524,y:613,t:1527016601763};\\\", \\\"{x:1529,y:609,t:1527016601780};\\\", \\\"{x:1529,y:608,t:1527016601796};\\\", \\\"{x:1530,y:608,t:1527016601855};\\\", \\\"{x:1534,y:609,t:1527016601863};\\\", \\\"{x:1541,y:610,t:1527016601879};\\\", \\\"{x:1555,y:615,t:1527016601897};\\\", \\\"{x:1559,y:616,t:1527016601913};\\\", \\\"{x:1561,y:616,t:1527016601929};\\\", \\\"{x:1567,y:617,t:1527016601946};\\\", \\\"{x:1568,y:617,t:1527016601962};\\\", \\\"{x:1568,y:618,t:1527016601990};\\\", \\\"{x:1571,y:618,t:1527016601998};\\\", \\\"{x:1574,y:621,t:1527016602013};\\\", \\\"{x:1578,y:625,t:1527016602032};\\\", \\\"{x:1582,y:639,t:1527016602047};\\\", \\\"{x:1582,y:663,t:1527016602063};\\\", \\\"{x:1586,y:699,t:1527016602079};\\\", \\\"{x:1592,y:729,t:1527016602096};\\\", \\\"{x:1591,y:740,t:1527016602112};\\\", \\\"{x:1582,y:757,t:1527016602129};\\\", \\\"{x:1577,y:775,t:1527016602146};\\\", \\\"{x:1569,y:792,t:1527016602163};\\\", \\\"{x:1559,y:799,t:1527016602179};\\\", \\\"{x:1550,y:805,t:1527016602196};\\\", \\\"{x:1544,y:812,t:1527016602213};\\\", \\\"{x:1537,y:817,t:1527016602229};\\\", \\\"{x:1534,y:818,t:1527016602246};\\\", \\\"{x:1532,y:823,t:1527016602263};\\\", \\\"{x:1524,y:826,t:1527016602280};\\\", \\\"{x:1520,y:828,t:1527016602296};\\\", \\\"{x:1516,y:830,t:1527016602313};\\\", \\\"{x:1509,y:833,t:1527016602330};\\\", \\\"{x:1501,y:837,t:1527016602346};\\\", \\\"{x:1496,y:842,t:1527016602363};\\\", \\\"{x:1479,y:853,t:1527016602380};\\\", \\\"{x:1468,y:862,t:1527016602397};\\\", \\\"{x:1451,y:876,t:1527016602413};\\\", \\\"{x:1449,y:878,t:1527016602430};\\\", \\\"{x:1445,y:881,t:1527016602446};\\\", \\\"{x:1445,y:882,t:1527016602470};\\\", \\\"{x:1445,y:883,t:1527016602486};\\\", \\\"{x:1445,y:884,t:1527016602510};\\\", \\\"{x:1445,y:886,t:1527016602526};\\\", \\\"{x:1445,y:889,t:1527016602534};\\\", \\\"{x:1445,y:892,t:1527016602547};\\\", \\\"{x:1444,y:901,t:1527016602564};\\\", \\\"{x:1441,y:906,t:1527016602580};\\\", \\\"{x:1440,y:908,t:1527016602597};\\\", \\\"{x:1440,y:909,t:1527016602613};\\\", \\\"{x:1441,y:911,t:1527016602653};\\\", \\\"{x:1442,y:912,t:1527016602663};\\\", \\\"{x:1449,y:913,t:1527016602679};\\\", \\\"{x:1452,y:913,t:1527016602696};\\\", \\\"{x:1458,y:913,t:1527016602713};\\\", \\\"{x:1472,y:911,t:1527016602733};\\\", \\\"{x:1483,y:909,t:1527016602746};\\\", \\\"{x:1532,y:889,t:1527016602764};\\\", \\\"{x:1571,y:877,t:1527016602779};\\\", \\\"{x:1619,y:860,t:1527016602797};\\\", \\\"{x:1690,y:832,t:1527016602813};\\\", \\\"{x:1715,y:825,t:1527016602830};\\\", \\\"{x:1727,y:817,t:1527016602846};\\\", \\\"{x:1730,y:815,t:1527016602864};\\\", \\\"{x:1735,y:812,t:1527016602918};\\\", \\\"{x:1739,y:809,t:1527016602930};\\\", \\\"{x:1744,y:804,t:1527016602946};\\\", \\\"{x:1745,y:802,t:1527016602964};\\\", \\\"{x:1749,y:798,t:1527016602981};\\\", \\\"{x:1752,y:797,t:1527016602997};\\\", \\\"{x:1752,y:796,t:1527016603014};\\\", \\\"{x:1754,y:794,t:1527016603030};\\\", \\\"{x:1754,y:791,t:1527016603095};\\\", \\\"{x:1748,y:787,t:1527016603102};\\\", \\\"{x:1747,y:786,t:1527016603114};\\\", \\\"{x:1745,y:786,t:1527016603150};\\\", \\\"{x:1740,y:785,t:1527016603164};\\\", \\\"{x:1723,y:785,t:1527016603181};\\\", \\\"{x:1716,y:785,t:1527016603197};\\\", \\\"{x:1689,y:791,t:1527016603214};\\\", \\\"{x:1663,y:799,t:1527016603230};\\\", \\\"{x:1650,y:800,t:1527016603246};\\\", \\\"{x:1635,y:808,t:1527016603264};\\\", \\\"{x:1610,y:815,t:1527016603281};\\\", \\\"{x:1605,y:817,t:1527016603297};\\\", \\\"{x:1601,y:817,t:1527016603313};\\\", \\\"{x:1596,y:817,t:1527016603331};\\\", \\\"{x:1591,y:817,t:1527016603347};\\\", \\\"{x:1575,y:816,t:1527016603364};\\\", \\\"{x:1563,y:810,t:1527016603380};\\\", \\\"{x:1544,y:800,t:1527016603396};\\\", \\\"{x:1515,y:781,t:1527016603414};\\\", \\\"{x:1493,y:768,t:1527016603430};\\\", \\\"{x:1475,y:754,t:1527016603447};\\\", \\\"{x:1459,y:742,t:1527016603463};\\\", \\\"{x:1443,y:726,t:1527016603481};\\\", \\\"{x:1423,y:711,t:1527016603496};\\\", \\\"{x:1397,y:690,t:1527016603513};\\\", \\\"{x:1369,y:665,t:1527016603531};\\\", \\\"{x:1321,y:629,t:1527016603546};\\\", \\\"{x:1294,y:609,t:1527016603563};\\\", \\\"{x:1268,y:583,t:1527016603580};\\\", \\\"{x:1253,y:566,t:1527016603598};\\\", \\\"{x:1252,y:565,t:1527016603613};\\\", \\\"{x:1252,y:561,t:1527016603630};\\\", \\\"{x:1252,y:552,t:1527016603648};\\\", \\\"{x:1255,y:538,t:1527016603663};\\\", \\\"{x:1258,y:529,t:1527016603681};\\\", \\\"{x:1261,y:518,t:1527016603697};\\\", \\\"{x:1268,y:507,t:1527016603714};\\\", \\\"{x:1274,y:503,t:1527016603731};\\\", \\\"{x:1277,y:500,t:1527016603748};\\\", \\\"{x:1280,y:497,t:1527016603763};\\\", \\\"{x:1282,y:497,t:1527016603790};\\\", \\\"{x:1284,y:497,t:1527016603798};\\\", \\\"{x:1285,y:515,t:1527016603814};\\\", \\\"{x:1284,y:534,t:1527016603830};\\\", \\\"{x:1283,y:551,t:1527016603848};\\\", \\\"{x:1273,y:572,t:1527016603864};\\\", \\\"{x:1266,y:599,t:1527016603881};\\\", \\\"{x:1262,y:601,t:1527016603898};\\\", \\\"{x:1262,y:608,t:1527016603914};\\\", \\\"{x:1262,y:610,t:1527016603930};\\\", \\\"{x:1264,y:610,t:1527016603948};\\\", \\\"{x:1265,y:610,t:1527016603966};\\\", \\\"{x:1266,y:612,t:1527016603981};\\\", \\\"{x:1269,y:616,t:1527016603998};\\\", \\\"{x:1275,y:620,t:1527016604014};\\\", \\\"{x:1284,y:623,t:1527016604030};\\\", \\\"{x:1288,y:623,t:1527016604048};\\\", \\\"{x:1306,y:625,t:1527016604064};\\\", \\\"{x:1313,y:626,t:1527016604081};\\\", \\\"{x:1341,y:636,t:1527016604098};\\\", \\\"{x:1422,y:639,t:1527016604114};\\\", \\\"{x:1435,y:642,t:1527016604131};\\\", \\\"{x:1444,y:651,t:1527016604148};\\\", \\\"{x:1444,y:652,t:1527016604231};\\\", \\\"{x:1441,y:656,t:1527016604248};\\\", \\\"{x:1427,y:664,t:1527016604264};\\\", \\\"{x:1423,y:668,t:1527016604281};\\\", \\\"{x:1421,y:669,t:1527016604298};\\\", \\\"{x:1417,y:671,t:1527016604315};\\\", \\\"{x:1417,y:672,t:1527016604727};\\\", \\\"{x:1417,y:674,t:1527016604751};\\\", \\\"{x:1413,y:679,t:1527016604765};\\\", \\\"{x:1401,y:683,t:1527016604781};\\\", \\\"{x:1374,y:700,t:1527016604798};\\\", \\\"{x:1359,y:708,t:1527016604814};\\\", \\\"{x:1343,y:716,t:1527016604830};\\\", \\\"{x:1337,y:717,t:1527016604848};\\\", \\\"{x:1336,y:719,t:1527016604865};\\\", \\\"{x:1336,y:720,t:1527016604926};\\\", \\\"{x:1335,y:720,t:1527016605199};\\\", \\\"{x:1335,y:718,t:1527016605215};\\\", \\\"{x:1335,y:716,t:1527016605232};\\\", \\\"{x:1335,y:715,t:1527016605303};\\\", \\\"{x:1337,y:715,t:1527016605315};\\\", \\\"{x:1342,y:712,t:1527016605332};\\\", \\\"{x:1349,y:707,t:1527016605348};\\\", \\\"{x:1352,y:706,t:1527016605365};\\\", \\\"{x:1354,y:704,t:1527016605382};\\\", \\\"{x:1356,y:703,t:1527016605398};\\\", \\\"{x:1357,y:703,t:1527016605654};\\\", \\\"{x:1358,y:701,t:1527016605693};\\\", \\\"{x:1361,y:701,t:1527016605702};\\\", \\\"{x:1365,y:701,t:1527016605715};\\\", \\\"{x:1375,y:701,t:1527016605732};\\\", \\\"{x:1387,y:701,t:1527016605747};\\\", \\\"{x:1401,y:701,t:1527016605765};\\\", \\\"{x:1412,y:701,t:1527016605781};\\\", \\\"{x:1415,y:701,t:1527016605798};\\\", \\\"{x:1419,y:702,t:1527016605814};\\\", \\\"{x:1422,y:703,t:1527016605838};\\\", \\\"{x:1424,y:703,t:1527016605855};\\\", \\\"{x:1424,y:704,t:1527016605911};\\\", \\\"{x:1424,y:706,t:1527016605958};\\\", \\\"{x:1424,y:707,t:1527016605966};\\\", \\\"{x:1421,y:708,t:1527016605982};\\\", \\\"{x:1419,y:709,t:1527016605998};\\\", \\\"{x:1419,y:710,t:1527016606014};\\\", \\\"{x:1419,y:711,t:1527016606678};\\\", \\\"{x:1418,y:711,t:1527016606957};\\\", \\\"{x:1417,y:711,t:1527016606989};\\\", \\\"{x:1415,y:711,t:1527016607518};\\\", \\\"{x:1413,y:711,t:1527016607542};\\\", \\\"{x:1412,y:711,t:1527016607575};\\\", \\\"{x:1410,y:711,t:1527016607638};\\\", \\\"{x:1408,y:711,t:1527016607649};\\\", \\\"{x:1408,y:710,t:1527016608703};\\\", \\\"{x:1408,y:709,t:1527016608782};\\\", \\\"{x:1410,y:709,t:1527016608800};\\\", \\\"{x:1420,y:707,t:1527016608817};\\\", \\\"{x:1430,y:706,t:1527016608834};\\\", \\\"{x:1444,y:706,t:1527016608850};\\\", \\\"{x:1462,y:702,t:1527016608867};\\\", \\\"{x:1474,y:702,t:1527016608883};\\\", \\\"{x:1484,y:702,t:1527016608900};\\\", \\\"{x:1490,y:702,t:1527016608917};\\\", \\\"{x:1492,y:702,t:1527016608932};\\\", \\\"{x:1494,y:702,t:1527016608949};\\\", \\\"{x:1493,y:702,t:1527016609231};\\\", \\\"{x:1492,y:702,t:1527016609279};\\\", \\\"{x:1491,y:702,t:1527016609510};\\\", \\\"{x:1491,y:701,t:1527016609678};\\\", \\\"{x:1495,y:701,t:1527016609686};\\\", \\\"{x:1499,y:701,t:1527016609700};\\\", \\\"{x:1509,y:701,t:1527016609717};\\\", \\\"{x:1520,y:701,t:1527016609734};\\\", \\\"{x:1525,y:701,t:1527016609750};\\\", \\\"{x:1527,y:701,t:1527016609767};\\\", \\\"{x:1532,y:701,t:1527016609784};\\\", \\\"{x:1534,y:701,t:1527016609800};\\\", \\\"{x:1536,y:701,t:1527016610111};\\\", \\\"{x:1540,y:701,t:1527016610118};\\\", \\\"{x:1548,y:701,t:1527016610134};\\\", \\\"{x:1581,y:703,t:1527016610150};\\\", \\\"{x:1624,y:704,t:1527016610167};\\\", \\\"{x:1635,y:707,t:1527016610184};\\\", \\\"{x:1638,y:708,t:1527016610201};\\\", \\\"{x:1639,y:708,t:1527016610217};\\\", \\\"{x:1639,y:709,t:1527016610438};\\\", \\\"{x:1638,y:709,t:1527016610454};\\\", \\\"{x:1637,y:709,t:1527016610525};\\\", \\\"{x:1635,y:709,t:1527016610533};\\\", \\\"{x:1633,y:709,t:1527016610605};\\\", \\\"{x:1630,y:707,t:1527016610616};\\\", \\\"{x:1627,y:705,t:1527016610633};\\\", \\\"{x:1621,y:702,t:1527016610651};\\\", \\\"{x:1617,y:702,t:1527016610711};\\\", \\\"{x:1616,y:702,t:1527016610719};\\\", \\\"{x:1611,y:704,t:1527016610734};\\\", \\\"{x:1607,y:704,t:1527016610751};\\\", \\\"{x:1601,y:704,t:1527016610768};\\\", \\\"{x:1598,y:704,t:1527016610784};\\\", \\\"{x:1600,y:704,t:1527016610935};\\\", \\\"{x:1601,y:704,t:1527016611039};\\\", \\\"{x:1603,y:704,t:1527016611182};\\\", \\\"{x:1604,y:704,t:1527016611319};\\\", \\\"{x:1605,y:704,t:1527016611334};\\\", \\\"{x:1606,y:704,t:1527016611351};\\\", \\\"{x:1608,y:704,t:1527016611446};\\\", \\\"{x:1609,y:704,t:1527016611462};\\\", \\\"{x:1610,y:704,t:1527016611479};\\\", \\\"{x:1610,y:703,t:1527016611502};\\\", \\\"{x:1611,y:703,t:1527016611550};\\\", \\\"{x:1611,y:702,t:1527016611568};\\\", \\\"{x:1613,y:700,t:1527016612346};\\\", \\\"{x:1603,y:699,t:1527016626131};\\\", \\\"{x:1588,y:697,t:1527016626146};\\\", \\\"{x:1519,y:698,t:1527016626162};\\\", \\\"{x:1411,y:698,t:1527016626179};\\\", \\\"{x:1344,y:701,t:1527016626196};\\\", \\\"{x:1225,y:700,t:1527016626213};\\\", \\\"{x:1189,y:696,t:1527016626230};\\\", \\\"{x:1094,y:699,t:1527016626246};\\\", \\\"{x:1024,y:702,t:1527016626262};\\\", \\\"{x:946,y:702,t:1527016626279};\\\", \\\"{x:886,y:704,t:1527016626295};\\\", \\\"{x:795,y:698,t:1527016626312};\\\", \\\"{x:651,y:690,t:1527016626329};\\\", \\\"{x:541,y:686,t:1527016626346};\\\", \\\"{x:431,y:678,t:1527016626362};\\\", \\\"{x:325,y:674,t:1527016626380};\\\", \\\"{x:230,y:676,t:1527016626395};\\\", \\\"{x:172,y:691,t:1527016626413};\\\", \\\"{x:167,y:694,t:1527016626429};\\\", \\\"{x:167,y:693,t:1527016626761};\\\", \\\"{x:186,y:677,t:1527016626779};\\\", \\\"{x:204,y:661,t:1527016626798};\\\", \\\"{x:231,y:639,t:1527016626811};\\\", \\\"{x:242,y:634,t:1527016626829};\\\", \\\"{x:243,y:634,t:1527016626852};\\\", \\\"{x:244,y:634,t:1527016626873};\\\", \\\"{x:245,y:634,t:1527016626886};\\\", \\\"{x:254,y:632,t:1527016626902};\\\", \\\"{x:261,y:630,t:1527016626920};\\\", \\\"{x:264,y:629,t:1527016626936};\\\", \\\"{x:280,y:622,t:1527016626955};\\\", \\\"{x:283,y:622,t:1527016626970};\\\", \\\"{x:298,y:622,t:1527016626988};\\\", \\\"{x:316,y:618,t:1527016627005};\\\", \\\"{x:344,y:619,t:1527016627020};\\\", \\\"{x:381,y:619,t:1527016627038};\\\", \\\"{x:392,y:619,t:1527016627055};\\\", \\\"{x:400,y:619,t:1527016627071};\\\", \\\"{x:412,y:623,t:1527016627087};\\\", \\\"{x:413,y:623,t:1527016627104};\\\", \\\"{x:415,y:623,t:1527016627120};\\\", \\\"{x:416,y:623,t:1527016627137};\\\", \\\"{x:418,y:624,t:1527016627154};\\\", \\\"{x:423,y:626,t:1527016627171};\\\", \\\"{x:424,y:626,t:1527016627224};\\\", \\\"{x:427,y:626,t:1527016627237};\\\", \\\"{x:436,y:626,t:1527016627255};\\\", \\\"{x:446,y:615,t:1527016627270};\\\", \\\"{x:480,y:603,t:1527016627287};\\\", \\\"{x:518,y:585,t:1527016627306};\\\", \\\"{x:529,y:576,t:1527016627321};\\\", \\\"{x:536,y:574,t:1527016627337};\\\", \\\"{x:541,y:574,t:1527016627354};\\\", \\\"{x:541,y:573,t:1527016627372};\\\", \\\"{x:543,y:573,t:1527016627387};\\\", \\\"{x:544,y:573,t:1527016627404};\\\", \\\"{x:547,y:573,t:1527016627422};\\\", \\\"{x:548,y:574,t:1527016627437};\\\", \\\"{x:550,y:576,t:1527016627513};\\\", \\\"{x:552,y:578,t:1527016627553};\\\", \\\"{x:554,y:579,t:1527016627561};\\\", \\\"{x:554,y:580,t:1527016627572};\\\", \\\"{x:564,y:588,t:1527016627589};\\\", \\\"{x:579,y:599,t:1527016627605};\\\", \\\"{x:593,y:608,t:1527016627623};\\\", \\\"{x:598,y:610,t:1527016627637};\\\", \\\"{x:602,y:610,t:1527016627656};\\\", \\\"{x:609,y:610,t:1527016627672};\\\", \\\"{x:610,y:610,t:1527016627687};\\\", \\\"{x:617,y:604,t:1527016627705};\\\", \\\"{x:618,y:602,t:1527016627722};\\\", \\\"{x:618,y:601,t:1527016627810};\\\", \\\"{x:618,y:599,t:1527016627826};\\\", \\\"{x:618,y:596,t:1527016627838};\\\", \\\"{x:616,y:591,t:1527016627855};\\\", \\\"{x:610,y:586,t:1527016627872};\\\", \\\"{x:604,y:579,t:1527016627887};\\\", \\\"{x:599,y:575,t:1527016627904};\\\", \\\"{x:596,y:571,t:1527016627922};\\\", \\\"{x:595,y:569,t:1527016627939};\\\", \\\"{x:593,y:568,t:1527016627955};\\\", \\\"{x:593,y:567,t:1527016628081};\\\", \\\"{x:592,y:567,t:1527016628825};\\\", \\\"{x:592,y:568,t:1527016629210};\\\", \\\"{x:591,y:569,t:1527016629228};\\\", \\\"{x:590,y:570,t:1527016629244};\\\", \\\"{x:589,y:572,t:1527016629449};\\\", \\\"{x:588,y:572,t:1527016629481};\\\", \\\"{x:587,y:573,t:1527016629514};\\\", \\\"{x:586,y:574,t:1527016629569};\\\", \\\"{x:586,y:575,t:1527016629578};\\\", \\\"{x:585,y:577,t:1527016629595};\\\", \\\"{x:584,y:579,t:1527016629612};\\\", \\\"{x:583,y:581,t:1527016629628};\\\", \\\"{x:583,y:585,t:1527016629646};\\\", \\\"{x:580,y:589,t:1527016629662};\\\", \\\"{x:580,y:593,t:1527016629679};\\\", \\\"{x:580,y:596,t:1527016629696};\\\", \\\"{x:580,y:598,t:1527016629713};\\\", \\\"{x:580,y:602,t:1527016629721};\\\", \\\"{x:581,y:609,t:1527016629738};\\\", \\\"{x:584,y:613,t:1527016629757};\\\", \\\"{x:585,y:614,t:1527016629772};\\\", \\\"{x:589,y:621,t:1527016629790};\\\", \\\"{x:594,y:631,t:1527016629807};\\\", \\\"{x:604,y:647,t:1527016629823};\\\", \\\"{x:609,y:654,t:1527016629840};\\\", \\\"{x:630,y:678,t:1527016629857};\\\", \\\"{x:646,y:694,t:1527016629874};\\\", \\\"{x:654,y:702,t:1527016629890};\\\", \\\"{x:670,y:715,t:1527016629907};\\\", \\\"{x:690,y:729,t:1527016629924};\\\", \\\"{x:703,y:738,t:1527016629940};\\\", \\\"{x:720,y:754,t:1527016629958};\\\", \\\"{x:734,y:767,t:1527016629974};\\\", \\\"{x:756,y:788,t:1527016629990};\\\", \\\"{x:801,y:818,t:1527016630008};\\\", \\\"{x:870,y:861,t:1527016630024};\\\", \\\"{x:920,y:881,t:1527016630041};\\\", \\\"{x:1082,y:932,t:1527016630058};\\\", \\\"{x:1226,y:974,t:1527016630075};\\\", \\\"{x:1345,y:991,t:1527016630093};\\\", \\\"{x:1454,y:996,t:1527016630107};\\\", \\\"{x:1462,y:994,t:1527016630124};\\\", \\\"{x:1478,y:990,t:1527016630142};\\\", \\\"{x:1481,y:986,t:1527016630157};\\\", \\\"{x:1483,y:982,t:1527016630175};\\\", \\\"{x:1485,y:980,t:1527016630192};\\\", \\\"{x:1485,y:977,t:1527016630208};\\\", \\\"{x:1485,y:972,t:1527016630224};\\\", \\\"{x:1479,y:961,t:1527016630242};\\\", \\\"{x:1476,y:958,t:1527016630258};\\\", \\\"{x:1474,y:955,t:1527016630274};\\\", \\\"{x:1474,y:953,t:1527016630297};\\\", \\\"{x:1474,y:951,t:1527016630314};\\\", \\\"{x:1474,y:950,t:1527016630324};\\\", \\\"{x:1473,y:947,t:1527016630342};\\\", \\\"{x:1475,y:935,t:1527016630359};\\\", \\\"{x:1484,y:913,t:1527016630374};\\\", \\\"{x:1490,y:893,t:1527016630391};\\\", \\\"{x:1497,y:874,t:1527016630409};\\\", \\\"{x:1501,y:866,t:1527016630424};\\\", \\\"{x:1504,y:861,t:1527016630441};\\\", \\\"{x:1521,y:849,t:1527016630458};\\\", \\\"{x:1527,y:843,t:1527016630476};\\\", \\\"{x:1530,y:840,t:1527016630544};\\\", \\\"{x:1531,y:839,t:1527016630558};\\\", \\\"{x:1532,y:839,t:1527016630681};\\\", \\\"{x:1535,y:839,t:1527016630692};\\\", \\\"{x:1538,y:839,t:1527016630708};\\\", \\\"{x:1541,y:840,t:1527016630725};\\\", \\\"{x:1543,y:840,t:1527016630742};\\\", \\\"{x:1544,y:840,t:1527016630759};\\\", \\\"{x:1547,y:840,t:1527016630776};\\\", \\\"{x:1547,y:839,t:1527016630809};\\\", \\\"{x:1549,y:837,t:1527016630825};\\\", \\\"{x:1551,y:837,t:1527016630842};\\\", \\\"{x:1553,y:837,t:1527016630860};\\\", \\\"{x:1554,y:836,t:1527016630875};\\\", \\\"{x:1555,y:835,t:1527016630892};\\\", \\\"{x:1555,y:834,t:1527016630914};\\\", \\\"{x:1557,y:834,t:1527016630925};\\\", \\\"{x:1559,y:834,t:1527016630942};\\\", \\\"{x:1561,y:833,t:1527016630960};\\\", \\\"{x:1563,y:832,t:1527016630976};\\\", \\\"{x:1566,y:831,t:1527016630993};\\\", \\\"{x:1576,y:831,t:1527016631009};\\\", \\\"{x:1580,y:831,t:1527016631026};\\\", \\\"{x:1583,y:830,t:1527016631043};\\\", \\\"{x:1588,y:830,t:1527016631059};\\\", \\\"{x:1590,y:830,t:1527016631076};\\\", \\\"{x:1590,y:829,t:1527016631562};\\\", \\\"{x:1590,y:828,t:1527016631962};\\\", \\\"{x:1585,y:828,t:1527016631978};\\\", \\\"{x:1580,y:833,t:1527016631995};\\\", \\\"{x:1578,y:834,t:1527016632012};\\\", \\\"{x:1577,y:834,t:1527016632034};\\\", \\\"{x:1577,y:832,t:1527016632065};\\\", \\\"{x:1583,y:823,t:1527016632077};\\\", \\\"{x:1627,y:800,t:1527016632094};\\\", \\\"{x:1702,y:771,t:1527016632112};\\\", \\\"{x:1710,y:766,t:1527016632129};\\\", \\\"{x:1709,y:769,t:1527016632218};\\\", \\\"{x:1704,y:773,t:1527016632229};\\\", \\\"{x:1683,y:789,t:1527016632245};\\\", \\\"{x:1665,y:794,t:1527016632261};\\\", \\\"{x:1660,y:797,t:1527016632278};\\\", \\\"{x:1660,y:798,t:1527016632313};\\\", \\\"{x:1661,y:800,t:1527016632329};\\\", \\\"{x:1661,y:805,t:1527016632345};\\\", \\\"{x:1656,y:812,t:1527016632362};\\\", \\\"{x:1641,y:826,t:1527016632379};\\\", \\\"{x:1630,y:834,t:1527016632396};\\\", \\\"{x:1628,y:835,t:1527016632411};\\\", \\\"{x:1627,y:836,t:1527016632474};\\\", \\\"{x:1626,y:836,t:1527016632489};\\\", \\\"{x:1625,y:836,t:1527016632497};\\\", \\\"{x:1624,y:836,t:1527016632513};\\\", \\\"{x:1620,y:836,t:1527016632529};\\\", \\\"{x:1619,y:836,t:1527016632545};\\\", \\\"{x:1618,y:836,t:1527016632610};\\\", \\\"{x:1617,y:836,t:1527016632628};\\\", \\\"{x:1614,y:835,t:1527016632645};\\\", \\\"{x:1610,y:833,t:1527016632662};\\\", \\\"{x:1604,y:832,t:1527016632678};\\\", \\\"{x:1602,y:832,t:1527016632695};\\\", \\\"{x:1598,y:832,t:1527016632712};\\\", \\\"{x:1597,y:832,t:1527016632729};\\\", \\\"{x:1597,y:833,t:1527016632745};\\\", \\\"{x:1595,y:833,t:1527016632762};\\\", \\\"{x:1594,y:833,t:1527016632778};\\\", \\\"{x:1590,y:833,t:1527016632795};\\\", \\\"{x:1585,y:831,t:1527016632812};\\\", \\\"{x:1581,y:831,t:1527016632830};\\\", \\\"{x:1576,y:831,t:1527016632845};\\\", \\\"{x:1572,y:833,t:1527016632862};\\\", \\\"{x:1571,y:834,t:1527016632879};\\\", \\\"{x:1570,y:834,t:1527016632914};\\\", \\\"{x:1569,y:834,t:1527016632945};\\\", \\\"{x:1567,y:834,t:1527016632978};\\\", \\\"{x:1566,y:833,t:1527016633074};\\\", \\\"{x:1566,y:832,t:1527016633097};\\\", \\\"{x:1566,y:829,t:1527016633113};\\\", \\\"{x:1570,y:826,t:1527016633130};\\\", \\\"{x:1577,y:822,t:1527016633146};\\\", \\\"{x:1584,y:820,t:1527016633163};\\\", \\\"{x:1586,y:819,t:1527016633180};\\\", \\\"{x:1590,y:817,t:1527016633197};\\\", \\\"{x:1595,y:817,t:1527016633213};\\\", \\\"{x:1598,y:814,t:1527016633230};\\\", \\\"{x:1603,y:814,t:1527016633247};\\\", \\\"{x:1606,y:811,t:1527016633264};\\\", \\\"{x:1607,y:810,t:1527016633282};\\\", \\\"{x:1609,y:810,t:1527016633361};\\\", \\\"{x:1610,y:810,t:1527016633410};\\\", \\\"{x:1610,y:811,t:1527016633473};\\\", \\\"{x:1606,y:812,t:1527016634650};\\\", \\\"{x:1602,y:812,t:1527016634666};\\\", \\\"{x:1601,y:812,t:1527016634683};\\\", \\\"{x:1598,y:812,t:1527016634700};\\\", \\\"{x:1589,y:808,t:1527016634716};\\\", \\\"{x:1575,y:804,t:1527016634733};\\\", \\\"{x:1563,y:801,t:1527016634750};\\\", \\\"{x:1550,y:801,t:1527016634766};\\\", \\\"{x:1545,y:799,t:1527016634785};\\\", \\\"{x:1544,y:799,t:1527016634800};\\\", \\\"{x:1541,y:798,t:1527016634817};\\\", \\\"{x:1540,y:797,t:1527016635113};\\\", \\\"{x:1539,y:793,t:1527016635290};\\\", \\\"{x:1538,y:793,t:1527016635300};\\\", \\\"{x:1537,y:792,t:1527016635338};\\\", \\\"{x:1536,y:791,t:1527016635402};\\\", \\\"{x:1534,y:789,t:1527016635417};\\\", \\\"{x:1529,y:786,t:1527016635434};\\\", \\\"{x:1516,y:779,t:1527016635450};\\\", \\\"{x:1507,y:773,t:1527016635468};\\\", \\\"{x:1494,y:762,t:1527016635484};\\\", \\\"{x:1472,y:744,t:1527016635500};\\\", \\\"{x:1456,y:731,t:1527016635517};\\\", \\\"{x:1426,y:711,t:1527016635535};\\\", \\\"{x:1401,y:695,t:1527016635551};\\\", \\\"{x:1379,y:678,t:1527016635568};\\\", \\\"{x:1364,y:668,t:1527016635584};\\\", \\\"{x:1360,y:667,t:1527016635600};\\\", \\\"{x:1360,y:666,t:1527016635618};\\\", \\\"{x:1360,y:665,t:1527016635634};\\\", \\\"{x:1360,y:663,t:1527016635651};\\\", \\\"{x:1360,y:662,t:1527016635667};\\\", \\\"{x:1360,y:661,t:1527016635685};\\\", \\\"{x:1361,y:661,t:1527016635713};\\\", \\\"{x:1365,y:660,t:1527016635729};\\\", \\\"{x:1365,y:659,t:1527016635737};\\\", \\\"{x:1371,y:656,t:1527016635752};\\\", \\\"{x:1372,y:655,t:1527016635768};\\\", \\\"{x:1382,y:660,t:1527016635784};\\\", \\\"{x:1395,y:669,t:1527016635801};\\\", \\\"{x:1399,y:672,t:1527016635818};\\\", \\\"{x:1400,y:673,t:1527016635835};\\\", \\\"{x:1401,y:675,t:1527016635851};\\\", \\\"{x:1402,y:675,t:1527016635869};\\\", \\\"{x:1402,y:676,t:1527016635885};\\\", \\\"{x:1403,y:677,t:1527016635902};\\\", \\\"{x:1403,y:678,t:1527016635918};\\\", \\\"{x:1403,y:679,t:1527016635935};\\\", \\\"{x:1403,y:681,t:1527016635951};\\\", \\\"{x:1403,y:685,t:1527016635969};\\\", \\\"{x:1402,y:688,t:1527016635985};\\\", \\\"{x:1403,y:692,t:1527016636002};\\\", \\\"{x:1404,y:693,t:1527016636018};\\\", \\\"{x:1405,y:693,t:1527016636058};\\\", \\\"{x:1407,y:693,t:1527016636069};\\\", \\\"{x:1411,y:693,t:1527016636086};\\\", \\\"{x:1414,y:693,t:1527016636102};\\\", \\\"{x:1423,y:693,t:1527016636119};\\\", \\\"{x:1436,y:693,t:1527016636136};\\\", \\\"{x:1458,y:696,t:1527016636152};\\\", \\\"{x:1468,y:699,t:1527016636169};\\\", \\\"{x:1483,y:707,t:1527016636185};\\\", \\\"{x:1489,y:707,t:1527016636201};\\\", \\\"{x:1494,y:710,t:1527016636218};\\\", \\\"{x:1497,y:710,t:1527016636236};\\\", \\\"{x:1499,y:710,t:1527016636466};\\\", \\\"{x:1505,y:710,t:1527016636474};\\\", \\\"{x:1511,y:708,t:1527016636486};\\\", \\\"{x:1525,y:705,t:1527016636503};\\\", \\\"{x:1538,y:703,t:1527016636519};\\\", \\\"{x:1550,y:703,t:1527016636535};\\\", \\\"{x:1558,y:702,t:1527016636552};\\\", \\\"{x:1560,y:700,t:1527016636568};\\\", \\\"{x:1561,y:700,t:1527016636712};\\\", \\\"{x:1565,y:700,t:1527016636720};\\\", \\\"{x:1581,y:702,t:1527016636736};\\\", \\\"{x:1591,y:702,t:1527016636752};\\\", \\\"{x:1607,y:708,t:1527016636768};\\\", \\\"{x:1631,y:714,t:1527016636786};\\\", \\\"{x:1653,y:720,t:1527016636803};\\\", \\\"{x:1656,y:720,t:1527016636819};\\\", \\\"{x:1656,y:721,t:1527016637073};\\\", \\\"{x:1655,y:721,t:1527016637087};\\\", \\\"{x:1651,y:722,t:1527016637104};\\\", \\\"{x:1649,y:723,t:1527016637121};\\\", \\\"{x:1645,y:724,t:1527016637153};\\\", \\\"{x:1633,y:732,t:1527016637171};\\\", \\\"{x:1629,y:735,t:1527016637188};\\\", \\\"{x:1618,y:746,t:1527016637204};\\\", \\\"{x:1608,y:754,t:1527016637221};\\\", \\\"{x:1600,y:760,t:1527016637238};\\\", \\\"{x:1593,y:765,t:1527016637254};\\\", \\\"{x:1591,y:769,t:1527016637270};\\\", \\\"{x:1590,y:772,t:1527016637288};\\\", \\\"{x:1588,y:777,t:1527016637304};\\\", \\\"{x:1586,y:789,t:1527016637321};\\\", \\\"{x:1581,y:810,t:1527016637337};\\\", \\\"{x:1581,y:828,t:1527016637354};\\\", \\\"{x:1579,y:839,t:1527016637371};\\\", \\\"{x:1577,y:853,t:1527016637387};\\\", \\\"{x:1574,y:864,t:1527016637405};\\\", \\\"{x:1570,y:874,t:1527016637421};\\\", \\\"{x:1561,y:886,t:1527016637438};\\\", \\\"{x:1558,y:889,t:1527016637455};\\\", \\\"{x:1556,y:890,t:1527016637471};\\\", \\\"{x:1555,y:890,t:1527016637521};\\\", \\\"{x:1541,y:890,t:1527016637538};\\\", \\\"{x:1528,y:888,t:1527016637555};\\\", \\\"{x:1525,y:888,t:1527016637572};\\\", \\\"{x:1521,y:888,t:1527016637588};\\\", \\\"{x:1517,y:888,t:1527016637604};\\\", \\\"{x:1516,y:888,t:1527016637649};\\\", \\\"{x:1516,y:886,t:1527016637657};\\\", \\\"{x:1516,y:880,t:1527016637672};\\\", \\\"{x:1514,y:877,t:1527016637688};\\\", \\\"{x:1512,y:874,t:1527016637705};\\\", \\\"{x:1512,y:872,t:1527016637721};\\\", \\\"{x:1512,y:871,t:1527016637739};\\\", \\\"{x:1512,y:869,t:1527016637818};\\\", \\\"{x:1512,y:868,t:1527016637833};\\\", \\\"{x:1512,y:864,t:1527016637841};\\\", \\\"{x:1512,y:862,t:1527016637855};\\\", \\\"{x:1512,y:853,t:1527016637872};\\\", \\\"{x:1510,y:839,t:1527016637889};\\\", \\\"{x:1510,y:834,t:1527016637905};\\\", \\\"{x:1510,y:828,t:1527016637921};\\\", \\\"{x:1511,y:824,t:1527016637939};\\\", \\\"{x:1517,y:815,t:1527016637955};\\\", \\\"{x:1519,y:808,t:1527016637972};\\\", \\\"{x:1521,y:805,t:1527016637989};\\\", \\\"{x:1523,y:800,t:1527016638006};\\\", \\\"{x:1523,y:798,t:1527016638022};\\\", \\\"{x:1526,y:794,t:1527016638038};\\\", \\\"{x:1526,y:788,t:1527016638056};\\\", \\\"{x:1526,y:782,t:1527016638071};\\\", \\\"{x:1526,y:776,t:1527016638089};\\\", \\\"{x:1526,y:773,t:1527016638106};\\\", \\\"{x:1526,y:772,t:1527016638123};\\\", \\\"{x:1526,y:770,t:1527016638139};\\\", \\\"{x:1527,y:769,t:1527016638265};\\\", \\\"{x:1525,y:769,t:1527016638634};\\\", \\\"{x:1520,y:773,t:1527016638642};\\\", \\\"{x:1512,y:780,t:1527016638657};\\\", \\\"{x:1512,y:783,t:1527016638673};\\\", \\\"{x:1511,y:786,t:1527016638689};\\\", \\\"{x:1503,y:798,t:1527016638707};\\\", \\\"{x:1498,y:805,t:1527016638724};\\\", \\\"{x:1493,y:813,t:1527016638740};\\\", \\\"{x:1489,y:819,t:1527016638757};\\\", \\\"{x:1488,y:820,t:1527016638773};\\\", \\\"{x:1487,y:823,t:1527016638790};\\\", \\\"{x:1485,y:826,t:1527016638807};\\\", \\\"{x:1483,y:828,t:1527016638824};\\\", \\\"{x:1480,y:835,t:1527016638839};\\\", \\\"{x:1478,y:836,t:1527016638857};\\\", \\\"{x:1474,y:844,t:1527016638873};\\\", \\\"{x:1465,y:856,t:1527016638891};\\\", \\\"{x:1453,y:870,t:1527016638907};\\\", \\\"{x:1443,y:880,t:1527016638924};\\\", \\\"{x:1437,y:889,t:1527016638941};\\\", \\\"{x:1433,y:894,t:1527016638956};\\\", \\\"{x:1429,y:899,t:1527016638974};\\\", \\\"{x:1428,y:900,t:1527016638990};\\\", \\\"{x:1428,y:895,t:1527016639425};\\\", \\\"{x:1429,y:891,t:1527016639441};\\\", \\\"{x:1431,y:885,t:1527016639457};\\\", \\\"{x:1438,y:878,t:1527016639475};\\\", \\\"{x:1440,y:873,t:1527016639492};\\\", \\\"{x:1441,y:871,t:1527016639508};\\\", \\\"{x:1444,y:865,t:1527016639525};\\\", \\\"{x:1451,y:848,t:1527016639542};\\\", \\\"{x:1459,y:827,t:1527016639558};\\\", \\\"{x:1463,y:823,t:1527016639575};\\\", \\\"{x:1469,y:818,t:1527016639592};\\\", \\\"{x:1474,y:808,t:1527016639609};\\\", \\\"{x:1478,y:795,t:1527016639625};\\\", \\\"{x:1488,y:783,t:1527016639641};\\\", \\\"{x:1496,y:764,t:1527016639659};\\\", \\\"{x:1499,y:755,t:1527016639675};\\\", \\\"{x:1503,y:743,t:1527016639692};\\\", \\\"{x:1506,y:734,t:1527016639709};\\\", \\\"{x:1507,y:729,t:1527016639725};\\\", \\\"{x:1508,y:725,t:1527016639742};\\\", \\\"{x:1508,y:723,t:1527016639758};\\\", \\\"{x:1508,y:722,t:1527016639775};\\\", \\\"{x:1507,y:718,t:1527016639792};\\\", \\\"{x:1494,y:710,t:1527016639809};\\\", \\\"{x:1489,y:707,t:1527016639826};\\\", \\\"{x:1488,y:707,t:1527016639849};\\\", \\\"{x:1487,y:706,t:1527016639858};\\\", \\\"{x:1482,y:700,t:1527016639876};\\\", \\\"{x:1472,y:691,t:1527016639891};\\\", \\\"{x:1464,y:682,t:1527016639908};\\\", \\\"{x:1456,y:671,t:1527016639925};\\\", \\\"{x:1454,y:667,t:1527016639941};\\\", \\\"{x:1449,y:665,t:1527016639958};\\\", \\\"{x:1449,y:663,t:1527016640065};\\\", \\\"{x:1449,y:662,t:1527016640081};\\\", \\\"{x:1449,y:661,t:1527016640093};\\\", \\\"{x:1449,y:660,t:1527016640109};\\\", \\\"{x:1449,y:659,t:1527016640337};\\\", \\\"{x:1449,y:658,t:1527016640353};\\\", \\\"{x:1448,y:656,t:1527016640361};\\\", \\\"{x:1448,y:655,t:1527016640393};\\\", \\\"{x:1448,y:654,t:1527016640433};\\\", \\\"{x:1448,y:653,t:1527016640473};\\\", \\\"{x:1448,y:652,t:1527016640481};\\\", \\\"{x:1448,y:651,t:1527016640512};\\\", \\\"{x:1447,y:651,t:1527016640730};\\\", \\\"{x:1445,y:651,t:1527016640906};\\\", \\\"{x:1443,y:651,t:1527016640913};\\\", \\\"{x:1441,y:651,t:1527016640928};\\\", \\\"{x:1437,y:651,t:1527016640944};\\\", \\\"{x:1435,y:651,t:1527016640961};\\\", \\\"{x:1428,y:651,t:1527016640978};\\\", \\\"{x:1421,y:651,t:1527016640994};\\\", \\\"{x:1416,y:651,t:1527016641011};\\\", \\\"{x:1413,y:651,t:1527016641028};\\\", \\\"{x:1412,y:651,t:1527016641337};\\\", \\\"{x:1410,y:651,t:1527016641345};\\\", \\\"{x:1404,y:648,t:1527016641361};\\\", \\\"{x:1399,y:643,t:1527016641378};\\\", \\\"{x:1396,y:639,t:1527016641395};\\\", \\\"{x:1393,y:637,t:1527016641412};\\\", \\\"{x:1392,y:637,t:1527016641441};\\\", \\\"{x:1391,y:636,t:1527016641465};\\\", \\\"{x:1391,y:634,t:1527016641489};\\\", \\\"{x:1391,y:631,t:1527016641497};\\\", \\\"{x:1389,y:628,t:1527016641512};\\\", \\\"{x:1381,y:624,t:1527016641529};\\\", \\\"{x:1378,y:623,t:1527016641545};\\\", \\\"{x:1371,y:619,t:1527016641562};\\\", \\\"{x:1362,y:612,t:1527016641579};\\\", \\\"{x:1346,y:611,t:1527016641595};\\\", \\\"{x:1341,y:607,t:1527016641612};\\\", \\\"{x:1331,y:602,t:1527016641629};\\\", \\\"{x:1322,y:598,t:1527016641645};\\\", \\\"{x:1314,y:594,t:1527016641661};\\\", \\\"{x:1306,y:589,t:1527016641679};\\\", \\\"{x:1298,y:583,t:1527016641695};\\\", \\\"{x:1289,y:577,t:1527016641711};\\\", \\\"{x:1282,y:574,t:1527016641729};\\\", \\\"{x:1275,y:567,t:1527016641745};\\\", \\\"{x:1271,y:565,t:1527016641761};\\\", \\\"{x:1268,y:563,t:1527016641778};\\\", \\\"{x:1267,y:562,t:1527016641795};\\\", \\\"{x:1266,y:562,t:1527016641849};\\\", \\\"{x:1266,y:561,t:1527016641873};\\\", \\\"{x:1266,y:560,t:1527016641889};\\\", \\\"{x:1266,y:559,t:1527016641905};\\\", \\\"{x:1265,y:559,t:1527016641929};\\\", \\\"{x:1265,y:558,t:1527016642217};\\\", \\\"{x:1267,y:558,t:1527016642233};\\\", \\\"{x:1268,y:558,t:1527016642247};\\\", \\\"{x:1272,y:558,t:1527016642263};\\\", \\\"{x:1273,y:558,t:1527016642282};\\\", \\\"{x:1274,y:558,t:1527016642393};\\\", \\\"{x:1276,y:558,t:1527016642401};\\\", \\\"{x:1279,y:558,t:1527016642414};\\\", \\\"{x:1283,y:558,t:1527016642429};\\\", \\\"{x:1289,y:558,t:1527016642447};\\\", \\\"{x:1296,y:558,t:1527016642464};\\\", \\\"{x:1313,y:560,t:1527016642481};\\\", \\\"{x:1322,y:559,t:1527016642497};\\\", \\\"{x:1324,y:559,t:1527016642513};\\\", \\\"{x:1325,y:559,t:1527016642530};\\\", \\\"{x:1326,y:559,t:1527016642547};\\\", \\\"{x:1327,y:558,t:1527016642563};\\\", \\\"{x:1331,y:559,t:1527016642580};\\\", \\\"{x:1341,y:561,t:1527016642597};\\\", \\\"{x:1345,y:563,t:1527016642613};\\\", \\\"{x:1346,y:563,t:1527016642809};\\\", \\\"{x:1347,y:564,t:1527016642818};\\\", \\\"{x:1350,y:564,t:1527016642874};\\\", \\\"{x:1355,y:564,t:1527016642881};\\\", \\\"{x:1360,y:564,t:1527016642898};\\\", \\\"{x:1377,y:568,t:1527016642914};\\\", \\\"{x:1394,y:569,t:1527016642931};\\\", \\\"{x:1405,y:571,t:1527016642948};\\\", \\\"{x:1418,y:571,t:1527016642965};\\\", \\\"{x:1423,y:572,t:1527016642981};\\\", \\\"{x:1426,y:572,t:1527016642998};\\\", \\\"{x:1427,y:573,t:1527016643015};\\\", \\\"{x:1429,y:573,t:1527016643361};\\\", \\\"{x:1431,y:573,t:1527016643369};\\\", \\\"{x:1436,y:573,t:1527016643382};\\\", \\\"{x:1448,y:567,t:1527016643399};\\\", \\\"{x:1453,y:567,t:1527016643414};\\\", \\\"{x:1460,y:566,t:1527016643432};\\\", \\\"{x:1462,y:563,t:1527016643449};\\\", \\\"{x:1464,y:563,t:1527016643473};\\\", \\\"{x:1465,y:563,t:1527016643482};\\\", \\\"{x:1468,y:563,t:1527016643498};\\\", \\\"{x:1472,y:563,t:1527016643514};\\\", \\\"{x:1474,y:562,t:1527016643531};\\\", \\\"{x:1476,y:562,t:1527016643738};\\\", \\\"{x:1482,y:562,t:1527016643748};\\\", \\\"{x:1485,y:560,t:1527016643766};\\\", \\\"{x:1491,y:559,t:1527016643783};\\\", \\\"{x:1500,y:559,t:1527016643799};\\\", \\\"{x:1514,y:559,t:1527016643816};\\\", \\\"{x:1520,y:559,t:1527016643833};\\\", \\\"{x:1521,y:559,t:1527016643849};\\\", \\\"{x:1522,y:559,t:1527016644161};\\\", \\\"{x:1523,y:559,t:1527016644194};\\\", \\\"{x:1524,y:559,t:1527016644201};\\\", \\\"{x:1529,y:559,t:1527016644217};\\\", \\\"{x:1532,y:559,t:1527016644233};\\\", \\\"{x:1541,y:559,t:1527016644250};\\\", \\\"{x:1561,y:560,t:1527016644267};\\\", \\\"{x:1570,y:561,t:1527016644284};\\\", \\\"{x:1581,y:564,t:1527016644300};\\\", \\\"{x:1586,y:566,t:1527016644317};\\\", \\\"{x:1589,y:567,t:1527016644333};\\\", \\\"{x:1589,y:568,t:1527016644350};\\\", \\\"{x:1590,y:568,t:1527016644593};\\\", \\\"{x:1592,y:568,t:1527016644601};\\\", \\\"{x:1593,y:568,t:1527016644625};\\\", \\\"{x:1597,y:568,t:1527016644634};\\\", \\\"{x:1603,y:568,t:1527016644652};\\\", \\\"{x:1607,y:569,t:1527016644668};\\\", \\\"{x:1608,y:570,t:1527016644684};\\\", \\\"{x:1609,y:570,t:1527016644701};\\\", \\\"{x:1610,y:570,t:1527016644721};\\\", \\\"{x:1610,y:571,t:1527016644834};\\\", \\\"{x:1610,y:575,t:1527016644852};\\\", \\\"{x:1608,y:583,t:1527016644867};\\\", \\\"{x:1598,y:590,t:1527016644885};\\\", \\\"{x:1582,y:598,t:1527016644901};\\\", \\\"{x:1568,y:609,t:1527016644918};\\\", \\\"{x:1557,y:611,t:1527016644935};\\\", \\\"{x:1544,y:614,t:1527016644951};\\\", \\\"{x:1530,y:614,t:1527016644968};\\\", \\\"{x:1504,y:617,t:1527016644985};\\\", \\\"{x:1498,y:617,t:1527016645001};\\\", \\\"{x:1495,y:618,t:1527016645018};\\\", \\\"{x:1493,y:618,t:1527016645035};\\\", \\\"{x:1492,y:618,t:1527016645053};\\\", \\\"{x:1477,y:618,t:1527016645068};\\\", \\\"{x:1465,y:618,t:1527016645085};\\\", \\\"{x:1445,y:621,t:1527016645102};\\\", \\\"{x:1426,y:625,t:1527016645119};\\\", \\\"{x:1415,y:630,t:1527016645135};\\\", \\\"{x:1405,y:633,t:1527016645152};\\\", \\\"{x:1391,y:638,t:1527016645168};\\\", \\\"{x:1387,y:643,t:1527016645185};\\\", \\\"{x:1371,y:652,t:1527016645202};\\\", \\\"{x:1360,y:660,t:1527016645219};\\\", \\\"{x:1347,y:669,t:1527016645235};\\\", \\\"{x:1335,y:681,t:1527016645252};\\\", \\\"{x:1326,y:690,t:1527016645269};\\\", \\\"{x:1322,y:698,t:1527016645285};\\\", \\\"{x:1317,y:705,t:1527016645302};\\\", \\\"{x:1304,y:721,t:1527016645319};\\\", \\\"{x:1289,y:739,t:1527016645335};\\\", \\\"{x:1276,y:753,t:1527016645352};\\\", \\\"{x:1268,y:759,t:1527016645369};\\\", \\\"{x:1258,y:766,t:1527016645385};\\\", \\\"{x:1254,y:770,t:1527016645402};\\\", \\\"{x:1244,y:777,t:1527016645419};\\\", \\\"{x:1236,y:783,t:1527016645436};\\\", \\\"{x:1228,y:790,t:1527016645452};\\\", \\\"{x:1221,y:798,t:1527016645469};\\\", \\\"{x:1214,y:804,t:1527016645485};\\\", \\\"{x:1207,y:812,t:1527016645502};\\\", \\\"{x:1201,y:821,t:1527016645519};\\\", \\\"{x:1197,y:828,t:1527016645536};\\\", \\\"{x:1195,y:834,t:1527016645552};\\\", \\\"{x:1195,y:838,t:1527016645569};\\\", \\\"{x:1192,y:844,t:1527016645586};\\\", \\\"{x:1191,y:847,t:1527016645603};\\\", \\\"{x:1191,y:848,t:1527016645649};\\\", \\\"{x:1190,y:849,t:1527016645754};\\\", \\\"{x:1192,y:848,t:1527016645970};\\\", \\\"{x:1197,y:838,t:1527016645987};\\\", \\\"{x:1201,y:832,t:1527016646003};\\\", \\\"{x:1201,y:831,t:1527016646041};\\\", \\\"{x:1202,y:827,t:1527016646053};\\\", \\\"{x:1212,y:821,t:1527016646070};\\\", \\\"{x:1228,y:807,t:1527016646087};\\\", \\\"{x:1244,y:791,t:1527016646103};\\\", \\\"{x:1262,y:783,t:1527016646120};\\\", \\\"{x:1274,y:775,t:1527016646137};\\\", \\\"{x:1277,y:774,t:1527016646154};\\\", \\\"{x:1280,y:772,t:1527016646170};\\\", \\\"{x:1282,y:768,t:1527016646187};\\\", \\\"{x:1286,y:765,t:1527016646204};\\\", \\\"{x:1292,y:764,t:1527016646219};\\\", \\\"{x:1298,y:760,t:1527016646237};\\\", \\\"{x:1304,y:759,t:1527016646254};\\\", \\\"{x:1308,y:759,t:1527016646270};\\\", \\\"{x:1309,y:759,t:1527016646289};\\\", \\\"{x:1312,y:760,t:1527016646345};\\\", \\\"{x:1313,y:760,t:1527016646361};\\\", \\\"{x:1318,y:761,t:1527016646377};\\\", \\\"{x:1324,y:761,t:1527016646387};\\\", \\\"{x:1344,y:761,t:1527016646405};\\\", \\\"{x:1348,y:761,t:1527016646420};\\\", \\\"{x:1354,y:761,t:1527016646438};\\\", \\\"{x:1359,y:761,t:1527016646455};\\\", \\\"{x:1360,y:761,t:1527016646471};\\\", \\\"{x:1361,y:762,t:1527016646656};\\\", \\\"{x:1363,y:764,t:1527016646801};\\\", \\\"{x:1366,y:764,t:1527016646912};\\\", \\\"{x:1367,y:764,t:1527016646921};\\\", \\\"{x:1374,y:764,t:1527016646937};\\\", \\\"{x:1375,y:764,t:1527016647001};\\\", \\\"{x:1376,y:764,t:1527016647113};\\\", \\\"{x:1377,y:764,t:1527016647122};\\\", \\\"{x:1384,y:765,t:1527016647139};\\\", \\\"{x:1393,y:765,t:1527016647155};\\\", \\\"{x:1402,y:765,t:1527016647172};\\\", \\\"{x:1403,y:765,t:1527016647189};\\\", \\\"{x:1410,y:765,t:1527016647205};\\\", \\\"{x:1416,y:765,t:1527016647222};\\\", \\\"{x:1417,y:765,t:1527016647239};\\\", \\\"{x:1418,y:765,t:1527016647809};\\\", \\\"{x:1424,y:765,t:1527016647823};\\\", \\\"{x:1437,y:769,t:1527016647840};\\\", \\\"{x:1447,y:774,t:1527016647857};\\\", \\\"{x:1463,y:774,t:1527016647873};\\\", \\\"{x:1470,y:774,t:1527016647890};\\\", \\\"{x:1471,y:774,t:1527016647913};\\\", \\\"{x:1473,y:773,t:1527016648321};\\\", \\\"{x:1473,y:772,t:1527016648329};\\\", \\\"{x:1477,y:771,t:1527016648341};\\\", \\\"{x:1483,y:770,t:1527016648357};\\\", \\\"{x:1493,y:767,t:1527016648374};\\\", \\\"{x:1511,y:764,t:1527016648392};\\\", \\\"{x:1521,y:762,t:1527016648408};\\\", \\\"{x:1534,y:759,t:1527016648424};\\\", \\\"{x:1543,y:759,t:1527016648441};\\\", \\\"{x:1544,y:759,t:1527016648458};\\\", \\\"{x:1546,y:758,t:1527016648489};\\\", \\\"{x:1548,y:757,t:1527016648529};\\\", \\\"{x:1549,y:757,t:1527016648553};\\\", \\\"{x:1548,y:757,t:1527016649577};\\\", \\\"{x:1541,y:755,t:1527016649593};\\\", \\\"{x:1538,y:754,t:1527016649611};\\\", \\\"{x:1524,y:754,t:1527016649626};\\\", \\\"{x:1516,y:754,t:1527016649643};\\\", \\\"{x:1509,y:753,t:1527016649660};\\\", \\\"{x:1495,y:753,t:1527016649676};\\\", \\\"{x:1479,y:751,t:1527016649693};\\\", \\\"{x:1470,y:750,t:1527016649709};\\\", \\\"{x:1455,y:744,t:1527016649727};\\\", \\\"{x:1448,y:737,t:1527016649742};\\\", \\\"{x:1440,y:734,t:1527016649760};\\\", \\\"{x:1438,y:732,t:1527016649776};\\\", \\\"{x:1431,y:727,t:1527016649793};\\\", \\\"{x:1425,y:724,t:1527016649809};\\\", \\\"{x:1411,y:722,t:1527016649826};\\\", \\\"{x:1402,y:722,t:1527016649843};\\\", \\\"{x:1393,y:722,t:1527016649860};\\\", \\\"{x:1391,y:722,t:1527016649877};\\\", \\\"{x:1387,y:722,t:1527016649894};\\\", \\\"{x:1383,y:720,t:1527016649910};\\\", \\\"{x:1381,y:719,t:1527016649926};\\\", \\\"{x:1381,y:718,t:1527016649944};\\\", \\\"{x:1379,y:718,t:1527016649960};\\\", \\\"{x:1379,y:716,t:1527016649977};\\\", \\\"{x:1378,y:716,t:1527016649994};\\\", \\\"{x:1377,y:715,t:1527016650025};\\\", \\\"{x:1376,y:715,t:1527016650033};\\\", \\\"{x:1374,y:715,t:1527016650049};\\\", \\\"{x:1373,y:715,t:1527016650121};\\\", \\\"{x:1371,y:714,t:1527016650137};\\\", \\\"{x:1370,y:713,t:1527016650169};\\\", \\\"{x:1369,y:711,t:1527016650185};\\\", \\\"{x:1367,y:710,t:1527016650200};\\\", \\\"{x:1367,y:709,t:1527016650290};\\\", \\\"{x:1367,y:708,t:1527016650297};\\\", \\\"{x:1368,y:707,t:1527016650321};\\\", \\\"{x:1368,y:706,t:1527016650345};\\\", \\\"{x:1368,y:705,t:1527016650361};\\\", \\\"{x:1368,y:704,t:1527016650379};\\\", \\\"{x:1369,y:702,t:1527016650394};\\\", \\\"{x:1369,y:701,t:1527016650411};\\\", \\\"{x:1369,y:700,t:1527016650562};\\\", \\\"{x:1369,y:699,t:1527016650578};\\\", \\\"{x:1367,y:696,t:1527016650596};\\\", \\\"{x:1364,y:694,t:1527016650611};\\\", \\\"{x:1362,y:694,t:1527016650628};\\\", \\\"{x:1363,y:693,t:1527016650689};\\\", \\\"{x:1365,y:691,t:1527016650696};\\\", \\\"{x:1366,y:690,t:1527016650712};\\\", \\\"{x:1370,y:689,t:1527016650728};\\\", \\\"{x:1378,y:686,t:1527016650744};\\\", \\\"{x:1385,y:685,t:1527016650763};\\\", \\\"{x:1391,y:683,t:1527016650778};\\\", \\\"{x:1393,y:682,t:1527016650795};\\\", \\\"{x:1395,y:682,t:1527016650812};\\\", \\\"{x:1396,y:682,t:1527016650829};\\\", \\\"{x:1398,y:682,t:1527016651024};\\\", \\\"{x:1402,y:685,t:1527016651032};\\\", \\\"{x:1408,y:688,t:1527016651045};\\\", \\\"{x:1419,y:691,t:1527016651061};\\\", \\\"{x:1437,y:698,t:1527016651079};\\\", \\\"{x:1453,y:701,t:1527016651096};\\\", \\\"{x:1467,y:710,t:1527016651111};\\\", \\\"{x:1479,y:714,t:1527016651129};\\\", \\\"{x:1480,y:714,t:1527016651152};\\\", \\\"{x:1480,y:713,t:1527016651417};\\\", \\\"{x:1482,y:712,t:1527016651430};\\\", \\\"{x:1496,y:710,t:1527016651446};\\\", \\\"{x:1511,y:710,t:1527016651463};\\\", \\\"{x:1541,y:710,t:1527016651481};\\\", \\\"{x:1558,y:712,t:1527016651497};\\\", \\\"{x:1559,y:712,t:1527016651513};\\\", \\\"{x:1560,y:712,t:1527016651530};\\\", \\\"{x:1561,y:712,t:1527016651978};\\\", \\\"{x:1564,y:712,t:1527016651984};\\\", \\\"{x:1567,y:711,t:1527016651997};\\\", \\\"{x:1569,y:710,t:1527016652014};\\\", \\\"{x:1571,y:709,t:1527016652031};\\\", \\\"{x:1572,y:709,t:1527016652047};\\\", \\\"{x:1575,y:707,t:1527016652064};\\\", \\\"{x:1581,y:706,t:1527016652081};\\\", \\\"{x:1585,y:705,t:1527016652097};\\\", \\\"{x:1587,y:705,t:1527016652137};\\\", \\\"{x:1588,y:705,t:1527016652148};\\\", \\\"{x:1590,y:705,t:1527016652164};\\\", \\\"{x:1593,y:705,t:1527016652181};\\\", \\\"{x:1595,y:705,t:1527016652201};\\\", \\\"{x:1595,y:704,t:1527016652233};\\\", \\\"{x:1596,y:704,t:1527016652248};\\\", \\\"{x:1597,y:703,t:1527016652265};\\\", \\\"{x:1600,y:703,t:1527016652281};\\\", \\\"{x:1601,y:703,t:1527016652298};\\\", \\\"{x:1602,y:703,t:1527016652316};\\\", \\\"{x:1599,y:703,t:1527016652729};\\\", \\\"{x:1598,y:703,t:1527016652769};\\\", \\\"{x:1597,y:703,t:1527016652782};\\\", \\\"{x:1595,y:702,t:1527016652800};\\\", \\\"{x:1594,y:701,t:1527016652825};\\\", \\\"{x:1592,y:700,t:1527016652841};\\\", \\\"{x:1591,y:699,t:1527016652864};\\\", \\\"{x:1590,y:699,t:1527016652889};\\\", \\\"{x:1590,y:698,t:1527016652899};\\\", \\\"{x:1588,y:697,t:1527016652916};\\\", \\\"{x:1587,y:696,t:1527016652937};\\\", \\\"{x:1585,y:695,t:1527016652969};\\\", \\\"{x:1585,y:694,t:1527016652982};\\\", \\\"{x:1585,y:693,t:1527016653161};\\\", \\\"{x:1584,y:693,t:1527016653169};\\\", \\\"{x:1583,y:691,t:1527016653183};\\\", \\\"{x:1582,y:684,t:1527016653199};\\\", \\\"{x:1582,y:680,t:1527016653216};\\\", \\\"{x:1574,y:664,t:1527016653233};\\\", \\\"{x:1571,y:660,t:1527016653250};\\\", \\\"{x:1570,y:658,t:1527016653267};\\\", \\\"{x:1569,y:654,t:1527016653283};\\\", \\\"{x:1569,y:652,t:1527016653321};\\\", \\\"{x:1569,y:649,t:1527016653333};\\\", \\\"{x:1567,y:644,t:1527016653350};\\\", \\\"{x:1567,y:629,t:1527016653366};\\\", \\\"{x:1567,y:621,t:1527016653383};\\\", \\\"{x:1566,y:611,t:1527016653400};\\\", \\\"{x:1566,y:596,t:1527016653417};\\\", \\\"{x:1566,y:594,t:1527016653433};\\\", \\\"{x:1566,y:591,t:1527016653450};\\\", \\\"{x:1567,y:590,t:1527016653481};\\\", \\\"{x:1567,y:588,t:1527016653489};\\\", \\\"{x:1567,y:587,t:1527016653500};\\\", \\\"{x:1567,y:585,t:1527016653537};\\\", \\\"{x:1568,y:583,t:1527016653550};\\\", \\\"{x:1569,y:582,t:1527016653593};\\\", \\\"{x:1569,y:581,t:1527016653601};\\\", \\\"{x:1569,y:580,t:1527016653617};\\\", \\\"{x:1569,y:579,t:1527016653634};\\\", \\\"{x:1569,y:578,t:1527016653657};\\\", \\\"{x:1567,y:577,t:1527016653667};\\\", \\\"{x:1565,y:575,t:1527016653684};\\\", \\\"{x:1556,y:569,t:1527016653701};\\\", \\\"{x:1549,y:566,t:1527016653717};\\\", \\\"{x:1545,y:564,t:1527016653735};\\\", \\\"{x:1541,y:562,t:1527016653750};\\\", \\\"{x:1540,y:560,t:1527016653767};\\\", \\\"{x:1536,y:559,t:1527016653784};\\\", \\\"{x:1535,y:558,t:1527016653801};\\\", \\\"{x:1534,y:557,t:1527016653817};\\\", \\\"{x:1532,y:556,t:1527016653834};\\\", \\\"{x:1529,y:554,t:1527016653851};\\\", \\\"{x:1524,y:552,t:1527016653868};\\\", \\\"{x:1511,y:548,t:1527016653884};\\\", \\\"{x:1498,y:541,t:1527016653901};\\\", \\\"{x:1494,y:538,t:1527016653917};\\\", \\\"{x:1483,y:529,t:1527016653935};\\\", \\\"{x:1481,y:526,t:1527016653951};\\\", \\\"{x:1479,y:526,t:1527016654593};\\\", \\\"{x:1473,y:527,t:1527016654602};\\\", \\\"{x:1466,y:537,t:1527016654619};\\\", \\\"{x:1462,y:548,t:1527016654635};\\\", \\\"{x:1446,y:580,t:1527016654652};\\\", \\\"{x:1440,y:600,t:1527016654669};\\\", \\\"{x:1438,y:614,t:1527016654685};\\\", \\\"{x:1438,y:623,t:1527016654703};\\\", \\\"{x:1439,y:624,t:1527016654729};\\\", \\\"{x:1439,y:626,t:1527016654761};\\\", \\\"{x:1439,y:627,t:1527016654769};\\\", \\\"{x:1439,y:628,t:1527016654786};\\\", \\\"{x:1437,y:636,t:1527016654803};\\\", \\\"{x:1428,y:656,t:1527016654819};\\\", \\\"{x:1422,y:675,t:1527016654836};\\\", \\\"{x:1419,y:682,t:1527016654853};\\\", \\\"{x:1419,y:688,t:1527016654870};\\\", \\\"{x:1417,y:692,t:1527016654886};\\\", \\\"{x:1414,y:705,t:1527016654903};\\\", \\\"{x:1409,y:719,t:1527016654920};\\\", \\\"{x:1408,y:721,t:1527016654936};\\\", \\\"{x:1408,y:723,t:1527016654953};\\\", \\\"{x:1408,y:722,t:1527016655441};\\\", \\\"{x:1408,y:721,t:1527016655453};\\\", \\\"{x:1410,y:719,t:1527016655473};\\\", \\\"{x:1410,y:718,t:1527016655487};\\\", \\\"{x:1412,y:717,t:1527016655504};\\\", \\\"{x:1413,y:716,t:1527016655521};\\\", \\\"{x:1417,y:714,t:1527016655537};\\\", \\\"{x:1419,y:713,t:1527016655554};\\\", \\\"{x:1423,y:709,t:1527016655570};\\\", \\\"{x:1426,y:705,t:1527016655587};\\\", \\\"{x:1427,y:705,t:1527016655605};\\\", \\\"{x:1427,y:704,t:1527016655620};\\\", \\\"{x:1428,y:703,t:1527016655641};\\\", \\\"{x:1429,y:702,t:1527016655657};\\\", \\\"{x:1430,y:701,t:1527016655689};\\\", \\\"{x:1432,y:700,t:1527016655728};\\\", \\\"{x:1435,y:700,t:1527016655737};\\\", \\\"{x:1448,y:697,t:1527016655753};\\\", \\\"{x:1470,y:697,t:1527016655771};\\\", \\\"{x:1495,y:698,t:1527016655787};\\\", \\\"{x:1506,y:699,t:1527016655804};\\\", \\\"{x:1528,y:702,t:1527016655821};\\\", \\\"{x:1535,y:702,t:1527016655836};\\\", \\\"{x:1537,y:702,t:1527016655854};\\\", \\\"{x:1536,y:702,t:1527016655977};\\\", \\\"{x:1535,y:702,t:1527016655987};\\\", \\\"{x:1528,y:701,t:1527016656004};\\\", \\\"{x:1519,y:701,t:1527016656021};\\\", \\\"{x:1516,y:700,t:1527016656038};\\\", \\\"{x:1510,y:700,t:1527016656055};\\\", \\\"{x:1506,y:699,t:1527016656071};\\\", \\\"{x:1508,y:698,t:1527016656216};\\\", \\\"{x:1509,y:698,t:1527016656224};\\\", \\\"{x:1511,y:697,t:1527016656237};\\\", \\\"{x:1515,y:694,t:1527016656255};\\\", \\\"{x:1536,y:694,t:1527016656272};\\\", \\\"{x:1544,y:694,t:1527016656287};\\\", \\\"{x:1546,y:694,t:1527016656320};\\\", \\\"{x:1549,y:694,t:1527016656602};\\\", \\\"{x:1553,y:694,t:1527016656609};\\\", \\\"{x:1561,y:695,t:1527016656623};\\\", \\\"{x:1570,y:696,t:1527016656639};\\\", \\\"{x:1598,y:699,t:1527016656656};\\\", \\\"{x:1607,y:700,t:1527016656672};\\\", \\\"{x:1614,y:700,t:1527016656689};\\\", \\\"{x:1618,y:700,t:1527016656706};\\\", \\\"{x:1619,y:700,t:1527016657337};\\\", \\\"{x:1621,y:700,t:1527016662314};\\\", \\\"{x:1622,y:703,t:1527016662329};\\\", \\\"{x:1626,y:708,t:1527016662337};\\\", \\\"{x:1626,y:715,t:1527016662350};\\\", \\\"{x:1626,y:747,t:1527016662367};\\\", \\\"{x:1622,y:778,t:1527016662383};\\\", \\\"{x:1618,y:811,t:1527016662399};\\\", \\\"{x:1597,y:844,t:1527016662416};\\\", \\\"{x:1586,y:859,t:1527016662433};\\\", \\\"{x:1570,y:879,t:1527016662450};\\\", \\\"{x:1554,y:904,t:1527016662467};\\\", \\\"{x:1537,y:926,t:1527016662483};\\\", \\\"{x:1513,y:947,t:1527016662499};\\\", \\\"{x:1500,y:961,t:1527016662516};\\\", \\\"{x:1487,y:967,t:1527016662534};\\\", \\\"{x:1485,y:968,t:1527016662549};\\\", \\\"{x:1483,y:969,t:1527016662567};\\\", \\\"{x:1482,y:969,t:1527016662617};\\\", \\\"{x:1477,y:961,t:1527016662634};\\\", \\\"{x:1470,y:954,t:1527016662651};\\\", \\\"{x:1467,y:951,t:1527016662667};\\\", \\\"{x:1464,y:945,t:1527016662683};\\\", \\\"{x:1464,y:941,t:1527016662701};\\\", \\\"{x:1462,y:936,t:1527016662717};\\\", \\\"{x:1460,y:932,t:1527016662734};\\\", \\\"{x:1458,y:928,t:1527016662751};\\\", \\\"{x:1458,y:926,t:1527016662766};\\\", \\\"{x:1458,y:924,t:1527016662784};\\\", \\\"{x:1456,y:921,t:1527016662801};\\\", \\\"{x:1456,y:919,t:1527016662818};\\\", \\\"{x:1455,y:918,t:1527016662834};\\\", \\\"{x:1455,y:916,t:1527016662850};\\\", \\\"{x:1454,y:915,t:1527016662867};\\\", \\\"{x:1453,y:914,t:1527016662888};\\\", \\\"{x:1453,y:913,t:1527016662904};\\\", \\\"{x:1453,y:911,t:1527016662921};\\\", \\\"{x:1453,y:909,t:1527016662937};\\\", \\\"{x:1452,y:907,t:1527016662952};\\\", \\\"{x:1451,y:905,t:1527016662985};\\\", \\\"{x:1450,y:904,t:1527016663105};\\\", \\\"{x:1448,y:904,t:1527016663118};\\\", \\\"{x:1447,y:903,t:1527016663321};\\\", \\\"{x:1447,y:902,t:1527016663336};\\\", \\\"{x:1447,y:901,t:1527016663352};\\\", \\\"{x:1451,y:895,t:1527016663368};\\\", \\\"{x:1454,y:894,t:1527016663385};\\\", \\\"{x:1457,y:891,t:1527016663402};\\\", \\\"{x:1459,y:890,t:1527016663418};\\\", \\\"{x:1460,y:888,t:1527016663434};\\\", \\\"{x:1462,y:885,t:1527016663451};\\\", \\\"{x:1462,y:883,t:1527016663520};\\\", \\\"{x:1462,y:882,t:1527016663535};\\\", \\\"{x:1462,y:881,t:1527016663681};\\\", \\\"{x:1461,y:881,t:1527016663697};\\\", \\\"{x:1451,y:880,t:1527016663704};\\\", \\\"{x:1441,y:876,t:1527016663719};\\\", \\\"{x:1434,y:873,t:1527016663735};\\\", \\\"{x:1432,y:872,t:1527016663752};\\\", \\\"{x:1426,y:872,t:1527016663769};\\\", \\\"{x:1424,y:871,t:1527016663786};\\\", \\\"{x:1419,y:869,t:1527016663803};\\\", \\\"{x:1418,y:869,t:1527016663818};\\\", \\\"{x:1414,y:868,t:1527016663836};\\\", \\\"{x:1409,y:866,t:1527016663852};\\\", \\\"{x:1405,y:866,t:1527016663869};\\\", \\\"{x:1403,y:866,t:1527016663886};\\\", \\\"{x:1402,y:865,t:1527016663944};\\\", \\\"{x:1402,y:863,t:1527016663969};\\\", \\\"{x:1402,y:862,t:1527016663986};\\\", \\\"{x:1406,y:857,t:1527016664002};\\\", \\\"{x:1410,y:853,t:1527016664020};\\\", \\\"{x:1418,y:850,t:1527016664035};\\\", \\\"{x:1425,y:847,t:1527016664052};\\\", \\\"{x:1437,y:840,t:1527016664070};\\\", \\\"{x:1444,y:836,t:1527016664087};\\\", \\\"{x:1450,y:834,t:1527016664103};\\\", \\\"{x:1451,y:832,t:1527016664161};\\\", \\\"{x:1450,y:830,t:1527016664249};\\\", \\\"{x:1437,y:824,t:1527016664257};\\\", \\\"{x:1433,y:823,t:1527016664270};\\\", \\\"{x:1402,y:816,t:1527016664287};\\\", \\\"{x:1380,y:811,t:1527016664303};\\\", \\\"{x:1300,y:802,t:1527016664320};\\\", \\\"{x:1226,y:790,t:1527016664337};\\\", \\\"{x:1213,y:785,t:1527016664354};\\\", \\\"{x:1200,y:782,t:1527016664370};\\\", \\\"{x:1197,y:779,t:1527016664387};\\\", \\\"{x:1196,y:778,t:1527016664482};\\\", \\\"{x:1196,y:777,t:1527016664489};\\\", \\\"{x:1197,y:775,t:1527016664504};\\\", \\\"{x:1214,y:767,t:1527016664521};\\\", \\\"{x:1218,y:761,t:1527016664536};\\\", \\\"{x:1221,y:760,t:1527016664554};\\\", \\\"{x:1230,y:758,t:1527016664571};\\\", \\\"{x:1238,y:757,t:1527016664587};\\\", \\\"{x:1251,y:755,t:1527016664603};\\\", \\\"{x:1258,y:753,t:1527016664621};\\\", \\\"{x:1272,y:751,t:1527016664638};\\\", \\\"{x:1278,y:751,t:1527016664654};\\\", \\\"{x:1282,y:751,t:1527016664671};\\\", \\\"{x:1285,y:751,t:1527016664688};\\\", \\\"{x:1286,y:751,t:1527016665209};\\\", \\\"{x:1287,y:749,t:1527016665222};\\\", \\\"{x:1288,y:749,t:1527016665257};\\\", \\\"{x:1290,y:749,t:1527016665289};\\\", \\\"{x:1290,y:748,t:1527016665305};\\\", \\\"{x:1291,y:747,t:1527016665322};\\\", \\\"{x:1293,y:746,t:1527016666473};\\\", \\\"{x:1298,y:743,t:1527016666490};\\\", \\\"{x:1307,y:738,t:1527016666507};\\\", \\\"{x:1316,y:736,t:1527016666523};\\\", \\\"{x:1327,y:732,t:1527016666540};\\\", \\\"{x:1333,y:730,t:1527016666558};\\\", \\\"{x:1335,y:728,t:1527016666574};\\\", \\\"{x:1343,y:725,t:1527016666591};\\\", \\\"{x:1353,y:722,t:1527016666608};\\\", \\\"{x:1361,y:717,t:1527016666623};\\\", \\\"{x:1373,y:710,t:1527016666641};\\\", \\\"{x:1380,y:707,t:1527016666658};\\\", \\\"{x:1391,y:702,t:1527016666674};\\\", \\\"{x:1400,y:698,t:1527016666691};\\\", \\\"{x:1404,y:697,t:1527016666707};\\\", \\\"{x:1406,y:695,t:1527016666725};\\\", \\\"{x:1407,y:694,t:1527016666752};\\\", \\\"{x:1407,y:693,t:1527016666769};\\\", \\\"{x:1408,y:693,t:1527016667096};\\\", \\\"{x:1409,y:694,t:1527016667112};\\\", \\\"{x:1409,y:699,t:1527016667127};\\\", \\\"{x:1409,y:701,t:1527016667141};\\\", \\\"{x:1410,y:705,t:1527016667158};\\\", \\\"{x:1412,y:713,t:1527016667174};\\\", \\\"{x:1414,y:724,t:1527016667191};\\\", \\\"{x:1418,y:731,t:1527016667208};\\\", \\\"{x:1422,y:743,t:1527016667224};\\\", \\\"{x:1422,y:751,t:1527016667241};\\\", \\\"{x:1428,y:765,t:1527016667258};\\\", \\\"{x:1431,y:779,t:1527016667275};\\\", \\\"{x:1436,y:793,t:1527016667291};\\\", \\\"{x:1436,y:804,t:1527016667308};\\\", \\\"{x:1437,y:820,t:1527016667325};\\\", \\\"{x:1437,y:823,t:1527016667342};\\\", \\\"{x:1435,y:828,t:1527016667358};\\\", \\\"{x:1435,y:829,t:1527016667375};\\\", \\\"{x:1435,y:830,t:1527016667392};\\\", \\\"{x:1433,y:831,t:1527016667409};\\\", \\\"{x:1432,y:831,t:1527016667864};\\\", \\\"{x:1434,y:830,t:1527016667897};\\\", \\\"{x:1437,y:830,t:1527016667910};\\\", \\\"{x:1445,y:828,t:1527016667927};\\\", \\\"{x:1449,y:824,t:1527016667943};\\\", \\\"{x:1451,y:823,t:1527016667960};\\\", \\\"{x:1451,y:820,t:1527016667985};\\\", \\\"{x:1451,y:819,t:1527016667993};\\\", \\\"{x:1453,y:816,t:1527016668010};\\\", \\\"{x:1457,y:813,t:1527016668027};\\\", \\\"{x:1461,y:809,t:1527016668043};\\\", \\\"{x:1464,y:806,t:1527016668060};\\\", \\\"{x:1464,y:805,t:1527016668077};\\\", \\\"{x:1466,y:803,t:1527016668094};\\\", \\\"{x:1468,y:801,t:1527016668110};\\\", \\\"{x:1470,y:800,t:1527016668126};\\\", \\\"{x:1474,y:799,t:1527016668144};\\\", \\\"{x:1475,y:798,t:1527016668160};\\\", \\\"{x:1477,y:797,t:1527016668177};\\\", \\\"{x:1478,y:797,t:1527016668200};\\\", \\\"{x:1478,y:798,t:1527016668968};\\\", \\\"{x:1478,y:800,t:1527016668979};\\\", \\\"{x:1478,y:801,t:1527016668995};\\\", \\\"{x:1477,y:804,t:1527016669012};\\\", \\\"{x:1477,y:805,t:1527016669029};\\\", \\\"{x:1477,y:814,t:1527016669045};\\\", \\\"{x:1477,y:816,t:1527016669062};\\\", \\\"{x:1477,y:817,t:1527016669079};\\\", \\\"{x:1478,y:818,t:1527016669096};\\\", \\\"{x:1479,y:820,t:1527016669112};\\\", \\\"{x:1481,y:823,t:1527016669128};\\\", \\\"{x:1482,y:823,t:1527016669146};\\\", \\\"{x:1483,y:824,t:1527016669264};\\\", \\\"{x:1484,y:824,t:1527016669281};\\\", \\\"{x:1488,y:821,t:1527016669296};\\\", \\\"{x:1496,y:803,t:1527016669313};\\\", \\\"{x:1501,y:794,t:1527016669329};\\\", \\\"{x:1506,y:788,t:1527016669346};\\\", \\\"{x:1508,y:786,t:1527016669363};\\\", \\\"{x:1509,y:785,t:1527016669379};\\\", \\\"{x:1510,y:783,t:1527016669396};\\\", \\\"{x:1511,y:781,t:1527016669412};\\\", \\\"{x:1514,y:777,t:1527016669429};\\\", \\\"{x:1516,y:775,t:1527016669445};\\\", \\\"{x:1518,y:773,t:1527016669463};\\\", \\\"{x:1518,y:772,t:1527016669479};\\\", \\\"{x:1519,y:771,t:1527016669497};\\\", \\\"{x:1516,y:770,t:1527016669553};\\\", \\\"{x:1509,y:770,t:1527016669563};\\\", \\\"{x:1500,y:765,t:1527016669579};\\\", \\\"{x:1490,y:763,t:1527016669596};\\\", \\\"{x:1483,y:763,t:1527016669613};\\\", \\\"{x:1465,y:763,t:1527016669629};\\\", \\\"{x:1453,y:763,t:1527016669646};\\\", \\\"{x:1445,y:762,t:1527016669663};\\\", \\\"{x:1428,y:763,t:1527016669681};\\\", \\\"{x:1424,y:763,t:1527016669696};\\\", \\\"{x:1408,y:764,t:1527016669713};\\\", \\\"{x:1396,y:767,t:1527016669730};\\\", \\\"{x:1387,y:768,t:1527016669746};\\\", \\\"{x:1375,y:770,t:1527016669763};\\\", \\\"{x:1364,y:770,t:1527016669779};\\\", \\\"{x:1358,y:772,t:1527016669797};\\\", \\\"{x:1357,y:772,t:1527016669813};\\\", \\\"{x:1357,y:771,t:1527016669888};\\\", \\\"{x:1357,y:769,t:1527016669896};\\\", \\\"{x:1358,y:768,t:1527016669914};\\\", \\\"{x:1359,y:768,t:1527016669930};\\\", \\\"{x:1374,y:768,t:1527016669947};\\\", \\\"{x:1398,y:770,t:1527016669964};\\\", \\\"{x:1408,y:771,t:1527016669980};\\\", \\\"{x:1416,y:771,t:1527016669997};\\\", \\\"{x:1417,y:771,t:1527016670014};\\\", \\\"{x:1419,y:771,t:1527016670030};\\\", \\\"{x:1425,y:772,t:1527016670113};\\\", \\\"{x:1433,y:774,t:1527016670131};\\\", \\\"{x:1438,y:775,t:1527016670147};\\\", \\\"{x:1439,y:775,t:1527016670249};\\\", \\\"{x:1440,y:775,t:1527016670264};\\\", \\\"{x:1433,y:775,t:1527016670384};\\\", \\\"{x:1428,y:773,t:1527016670398};\\\", \\\"{x:1410,y:767,t:1527016670414};\\\", \\\"{x:1403,y:767,t:1527016670431};\\\", \\\"{x:1399,y:767,t:1527016670448};\\\", \\\"{x:1398,y:767,t:1527016670695};\\\", \\\"{x:1396,y:767,t:1527016670719};\\\", \\\"{x:1393,y:767,t:1527016670731};\\\", \\\"{x:1390,y:767,t:1527016670748};\\\", \\\"{x:1386,y:767,t:1527016670765};\\\", \\\"{x:1385,y:767,t:1527016670792};\\\", \\\"{x:1385,y:768,t:1527016670841};\\\", \\\"{x:1384,y:768,t:1527016670873};\\\", \\\"{x:1383,y:768,t:1527016670921};\\\", \\\"{x:1383,y:769,t:1527016670993};\\\", \\\"{x:1387,y:769,t:1527016671104};\\\", \\\"{x:1394,y:766,t:1527016671116};\\\", \\\"{x:1407,y:763,t:1527016671132};\\\", \\\"{x:1421,y:761,t:1527016671149};\\\", \\\"{x:1428,y:761,t:1527016671165};\\\", \\\"{x:1430,y:760,t:1527016671183};\\\", \\\"{x:1431,y:759,t:1527016671199};\\\", \\\"{x:1432,y:759,t:1527016671216};\\\", \\\"{x:1432,y:758,t:1527016671265};\\\", \\\"{x:1431,y:759,t:1527016671392};\\\", \\\"{x:1429,y:759,t:1527016671401};\\\", \\\"{x:1427,y:759,t:1527016671416};\\\", \\\"{x:1422,y:761,t:1527016671432};\\\", \\\"{x:1418,y:764,t:1527016671450};\\\", \\\"{x:1417,y:765,t:1527016671529};\\\", \\\"{x:1416,y:765,t:1527016671560};\\\", \\\"{x:1418,y:765,t:1527016671673};\\\", \\\"{x:1423,y:765,t:1527016671682};\\\", \\\"{x:1425,y:765,t:1527016671699};\\\", \\\"{x:1431,y:761,t:1527016671717};\\\", \\\"{x:1441,y:760,t:1527016671733};\\\", \\\"{x:1446,y:758,t:1527016671750};\\\", \\\"{x:1449,y:758,t:1527016671767};\\\", \\\"{x:1452,y:757,t:1527016671785};\\\", \\\"{x:1454,y:757,t:1527016671801};\\\", \\\"{x:1456,y:757,t:1527016671816};\\\", \\\"{x:1460,y:757,t:1527016671834};\\\", \\\"{x:1462,y:757,t:1527016671850};\\\", \\\"{x:1462,y:756,t:1527016671867};\\\", \\\"{x:1464,y:755,t:1527016671888};\\\", \\\"{x:1465,y:755,t:1527016671900};\\\", \\\"{x:1467,y:754,t:1527016671917};\\\", \\\"{x:1468,y:754,t:1527016671993};\\\", \\\"{x:1469,y:754,t:1527016672001};\\\", \\\"{x:1472,y:754,t:1527016672017};\\\", \\\"{x:1482,y:752,t:1527016672034};\\\", \\\"{x:1491,y:751,t:1527016672051};\\\", \\\"{x:1510,y:753,t:1527016672067};\\\", \\\"{x:1514,y:756,t:1527016672084};\\\", \\\"{x:1527,y:757,t:1527016672101};\\\", \\\"{x:1532,y:758,t:1527016672118};\\\", \\\"{x:1537,y:759,t:1527016672134};\\\", \\\"{x:1538,y:760,t:1527016672225};\\\", \\\"{x:1539,y:762,t:1527016672292};\\\", \\\"{x:1539,y:765,t:1527016672304};\\\", \\\"{x:1538,y:775,t:1527016672322};\\\", \\\"{x:1534,y:786,t:1527016672339};\\\", \\\"{x:1533,y:792,t:1527016672355};\\\", \\\"{x:1530,y:797,t:1527016672371};\\\", \\\"{x:1526,y:805,t:1527016672388};\\\", \\\"{x:1523,y:813,t:1527016672404};\\\", \\\"{x:1519,y:820,t:1527016672421};\\\", \\\"{x:1512,y:828,t:1527016672439};\\\", \\\"{x:1507,y:832,t:1527016672455};\\\", \\\"{x:1505,y:834,t:1527016672472};\\\", \\\"{x:1503,y:834,t:1527016672489};\\\", \\\"{x:1502,y:834,t:1527016672564};\\\", \\\"{x:1499,y:834,t:1527016672580};\\\", \\\"{x:1495,y:834,t:1527016672588};\\\", \\\"{x:1486,y:829,t:1527016672606};\\\", \\\"{x:1480,y:825,t:1527016672622};\\\", \\\"{x:1474,y:824,t:1527016672640};\\\", \\\"{x:1472,y:823,t:1527016672655};\\\", \\\"{x:1474,y:823,t:1527016672932};\\\", \\\"{x:1477,y:823,t:1527016672940};\\\", \\\"{x:1484,y:824,t:1527016672955};\\\", \\\"{x:1489,y:825,t:1527016672973};\\\", \\\"{x:1496,y:825,t:1527016672989};\\\", \\\"{x:1499,y:825,t:1527016673006};\\\", \\\"{x:1503,y:825,t:1527016673022};\\\", \\\"{x:1504,y:825,t:1527016673039};\\\", \\\"{x:1505,y:825,t:1527016673057};\\\", \\\"{x:1506,y:825,t:1527016673092};\\\", \\\"{x:1507,y:825,t:1527016673116};\\\", \\\"{x:1510,y:825,t:1527016673132};\\\", \\\"{x:1512,y:825,t:1527016673156};\\\", \\\"{x:1513,y:825,t:1527016673188};\\\", \\\"{x:1514,y:825,t:1527016673196};\\\", \\\"{x:1515,y:825,t:1527016673207};\\\", \\\"{x:1522,y:825,t:1527016673222};\\\", \\\"{x:1532,y:827,t:1527016673239};\\\", \\\"{x:1543,y:828,t:1527016673256};\\\", \\\"{x:1547,y:828,t:1527016673274};\\\", \\\"{x:1551,y:828,t:1527016673290};\\\", \\\"{x:1556,y:829,t:1527016673306};\\\", \\\"{x:1562,y:830,t:1527016673517};\\\", \\\"{x:1569,y:832,t:1527016673524};\\\", \\\"{x:1583,y:833,t:1527016673540};\\\", \\\"{x:1600,y:833,t:1527016673557};\\\", \\\"{x:1617,y:833,t:1527016673574};\\\", \\\"{x:1628,y:833,t:1527016673590};\\\", \\\"{x:1633,y:833,t:1527016673606};\\\", \\\"{x:1636,y:832,t:1527016673624};\\\", \\\"{x:1637,y:832,t:1527016673641};\\\", \\\"{x:1636,y:832,t:1527016673876};\\\", \\\"{x:1630,y:828,t:1527016673891};\\\", \\\"{x:1620,y:826,t:1527016673908};\\\", \\\"{x:1602,y:822,t:1527016673924};\\\", \\\"{x:1598,y:821,t:1527016673940};\\\", \\\"{x:1582,y:818,t:1527016673958};\\\", \\\"{x:1571,y:818,t:1527016673974};\\\", \\\"{x:1561,y:817,t:1527016673992};\\\", \\\"{x:1546,y:817,t:1527016674008};\\\", \\\"{x:1528,y:813,t:1527016674024};\\\", \\\"{x:1493,y:807,t:1527016674042};\\\", \\\"{x:1410,y:798,t:1527016674058};\\\", \\\"{x:1346,y:788,t:1527016674074};\\\", \\\"{x:1217,y:775,t:1527016674092};\\\", \\\"{x:1125,y:756,t:1527016674108};\\\", \\\"{x:1014,y:742,t:1527016674125};\\\", \\\"{x:1003,y:739,t:1527016674142};\\\", \\\"{x:939,y:719,t:1527016674158};\\\", \\\"{x:891,y:707,t:1527016674174};\\\", \\\"{x:850,y:704,t:1527016674191};\\\", \\\"{x:807,y:698,t:1527016674208};\\\", \\\"{x:758,y:690,t:1527016674224};\\\", \\\"{x:704,y:681,t:1527016674242};\\\", \\\"{x:689,y:674,t:1527016674258};\\\", \\\"{x:688,y:672,t:1527016674274};\\\", \\\"{x:683,y:669,t:1527016674292};\\\", \\\"{x:682,y:669,t:1527016674316};\\\", \\\"{x:681,y:669,t:1527016674332};\\\", \\\"{x:681,y:667,t:1527016674342};\\\", \\\"{x:679,y:662,t:1527016674358};\\\", \\\"{x:679,y:656,t:1527016674376};\\\", \\\"{x:676,y:650,t:1527016674391};\\\", \\\"{x:675,y:650,t:1527016674408};\\\", \\\"{x:667,y:645,t:1527016674425};\\\", \\\"{x:662,y:640,t:1527016674441};\\\", \\\"{x:660,y:636,t:1527016674458};\\\", \\\"{x:656,y:625,t:1527016674477};\\\", \\\"{x:654,y:620,t:1527016674491};\\\", \\\"{x:653,y:616,t:1527016674508};\\\", \\\"{x:652,y:613,t:1527016674525};\\\", \\\"{x:648,y:607,t:1527016674542};\\\", \\\"{x:647,y:605,t:1527016674559};\\\", \\\"{x:641,y:595,t:1527016674576};\\\", \\\"{x:637,y:589,t:1527016674592};\\\", \\\"{x:637,y:575,t:1527016674612};\\\", \\\"{x:637,y:569,t:1527016674629};\\\", \\\"{x:637,y:567,t:1527016674646};\\\", \\\"{x:637,y:564,t:1527016674664};\\\", \\\"{x:636,y:558,t:1527016674680};\\\", \\\"{x:636,y:555,t:1527016674696};\\\", \\\"{x:636,y:551,t:1527016674713};\\\", \\\"{x:636,y:550,t:1527016674730};\\\", \\\"{x:636,y:548,t:1527016674746};\\\", \\\"{x:636,y:547,t:1527016674772};\\\", \\\"{x:635,y:547,t:1527016674949};\\\", \\\"{x:631,y:547,t:1527016674963};\\\", \\\"{x:628,y:547,t:1527016674981};\\\", \\\"{x:626,y:547,t:1527016674998};\\\", \\\"{x:619,y:549,t:1527016675015};\\\", \\\"{x:618,y:552,t:1527016675031};\\\", \\\"{x:615,y:556,t:1527016675048};\\\", \\\"{x:613,y:559,t:1527016675063};\\\", \\\"{x:611,y:561,t:1527016675079};\\\", \\\"{x:608,y:566,t:1527016675096};\\\", \\\"{x:607,y:569,t:1527016675113};\\\", \\\"{x:606,y:571,t:1527016675129};\\\", \\\"{x:605,y:574,t:1527016675146};\\\", \\\"{x:602,y:581,t:1527016675163};\\\", \\\"{x:601,y:582,t:1527016675187};\\\", \\\"{x:605,y:584,t:1527016675947};\\\", \\\"{x:620,y:590,t:1527016675965};\\\", \\\"{x:631,y:595,t:1527016675981};\\\", \\\"{x:711,y:615,t:1527016675997};\\\", \\\"{x:765,y:636,t:1527016676015};\\\", \\\"{x:924,y:676,t:1527016676030};\\\", \\\"{x:1064,y:704,t:1527016676048};\\\", \\\"{x:1215,y:741,t:1527016676064};\\\", \\\"{x:1367,y:765,t:1527016676080};\\\", \\\"{x:1481,y:798,t:1527016676097};\\\", \\\"{x:1552,y:804,t:1527016676115};\\\", \\\"{x:1581,y:808,t:1527016676130};\\\", \\\"{x:1586,y:808,t:1527016676147};\\\", \\\"{x:1591,y:808,t:1527016676164};\\\", \\\"{x:1593,y:808,t:1527016676180};\\\", \\\"{x:1597,y:809,t:1527016676197};\\\", \\\"{x:1598,y:810,t:1527016676252};\\\", \\\"{x:1599,y:811,t:1527016676292};\\\", \\\"{x:1600,y:811,t:1527016676300};\\\", \\\"{x:1600,y:812,t:1527016676314};\\\", \\\"{x:1600,y:813,t:1527016676332};\\\", \\\"{x:1600,y:816,t:1527016676347};\\\", \\\"{x:1602,y:822,t:1527016676364};\\\", \\\"{x:1604,y:837,t:1527016676381};\\\", \\\"{x:1609,y:861,t:1527016676398};\\\", \\\"{x:1616,y:871,t:1527016676414};\\\", \\\"{x:1618,y:871,t:1527016693029};\\\", \\\"{x:1627,y:869,t:1527016693043};\\\", \\\"{x:1630,y:866,t:1527016693060};\\\", \\\"{x:1632,y:865,t:1527016693078};\\\", \\\"{x:1633,y:862,t:1527016693094};\\\", \\\"{x:1635,y:857,t:1527016693111};\\\", \\\"{x:1635,y:850,t:1527016693127};\\\", \\\"{x:1635,y:840,t:1527016693144};\\\", \\\"{x:1639,y:824,t:1527016693160};\\\", \\\"{x:1654,y:804,t:1527016693177};\\\", \\\"{x:1664,y:794,t:1527016693193};\\\", \\\"{x:1686,y:779,t:1527016693211};\\\", \\\"{x:1725,y:749,t:1527016693228};\\\", \\\"{x:1748,y:726,t:1527016693243};\\\", \\\"{x:1767,y:705,t:1527016693260};\\\", \\\"{x:1783,y:686,t:1527016693278};\\\", \\\"{x:1801,y:668,t:1527016693293};\\\", \\\"{x:1824,y:650,t:1527016693310};\\\", \\\"{x:1832,y:640,t:1527016693328};\\\", \\\"{x:1837,y:633,t:1527016693343};\\\", \\\"{x:1839,y:620,t:1527016693360};\\\", \\\"{x:1844,y:600,t:1527016693377};\\\", \\\"{x:1845,y:580,t:1527016693393};\\\", \\\"{x:1845,y:566,t:1527016693410};\\\", \\\"{x:1840,y:537,t:1527016693428};\\\", \\\"{x:1824,y:514,t:1527016693444};\\\", \\\"{x:1808,y:494,t:1527016693460};\\\", \\\"{x:1790,y:477,t:1527016693477};\\\", \\\"{x:1760,y:464,t:1527016693494};\\\", \\\"{x:1726,y:452,t:1527016693510};\\\", \\\"{x:1708,y:441,t:1527016693527};\\\", \\\"{x:1701,y:437,t:1527016693544};\\\", \\\"{x:1695,y:433,t:1527016693560};\\\", \\\"{x:1682,y:428,t:1527016693578};\\\", \\\"{x:1670,y:422,t:1527016693594};\\\", \\\"{x:1661,y:419,t:1527016693610};\\\", \\\"{x:1653,y:415,t:1527016693628};\\\", \\\"{x:1646,y:412,t:1527016693644};\\\", \\\"{x:1638,y:409,t:1527016693660};\\\", \\\"{x:1630,y:403,t:1527016693677};\\\", \\\"{x:1625,y:401,t:1527016693694};\\\", \\\"{x:1620,y:398,t:1527016693711};\\\", \\\"{x:1618,y:397,t:1527016693728};\\\", \\\"{x:1611,y:389,t:1527016693745};\\\", \\\"{x:1601,y:383,t:1527016693760};\\\", \\\"{x:1592,y:376,t:1527016693778};\\\", \\\"{x:1588,y:374,t:1527016693794};\\\", \\\"{x:1571,y:360,t:1527016693811};\\\", \\\"{x:1543,y:340,t:1527016693828};\\\", \\\"{x:1516,y:323,t:1527016693844};\\\", \\\"{x:1496,y:310,t:1527016693860};\\\", \\\"{x:1481,y:302,t:1527016693877};\\\", \\\"{x:1479,y:300,t:1527016693894};\\\", \\\"{x:1477,y:298,t:1527016693911};\\\", \\\"{x:1476,y:297,t:1527016693927};\\\", \\\"{x:1476,y:296,t:1527016694019};\\\", \\\"{x:1476,y:295,t:1527016694043};\\\", \\\"{x:1476,y:293,t:1527016694062};\\\", \\\"{x:1476,y:292,t:1527016694077};\\\", \\\"{x:1476,y:290,t:1527016694132};\\\", \\\"{x:1476,y:289,t:1527016694164};\\\", \\\"{x:1477,y:289,t:1527016694177};\\\", \\\"{x:1481,y:289,t:1527016694194};\\\", \\\"{x:1485,y:290,t:1527016694212};\\\", \\\"{x:1488,y:292,t:1527016694228};\\\", \\\"{x:1490,y:292,t:1527016694251};\\\", \\\"{x:1491,y:292,t:1527016694276};\\\", \\\"{x:1492,y:292,t:1527016694372};\\\", \\\"{x:1494,y:292,t:1527016694380};\\\", \\\"{x:1498,y:292,t:1527016694396};\\\", \\\"{x:1506,y:292,t:1527016694411};\\\", \\\"{x:1512,y:292,t:1527016694427};\\\", \\\"{x:1517,y:292,t:1527016694444};\\\", \\\"{x:1520,y:292,t:1527016694461};\\\", \\\"{x:1522,y:292,t:1527016694479};\\\", \\\"{x:1525,y:292,t:1527016694494};\\\", \\\"{x:1531,y:292,t:1527016694511};\\\", \\\"{x:1532,y:292,t:1527016694528};\\\", \\\"{x:1533,y:292,t:1527016694544};\\\", \\\"{x:1534,y:292,t:1527016694562};\\\", \\\"{x:1535,y:292,t:1527016694796};\\\", \\\"{x:1536,y:292,t:1527016694811};\\\", \\\"{x:1537,y:292,t:1527016694828};\\\", \\\"{x:1538,y:292,t:1527016694844};\\\", \\\"{x:1545,y:293,t:1527016694861};\\\", \\\"{x:1556,y:297,t:1527016694878};\\\", \\\"{x:1560,y:298,t:1527016694895};\\\", \\\"{x:1562,y:298,t:1527016694912};\\\", \\\"{x:1562,y:299,t:1527016695076};\\\", \\\"{x:1559,y:299,t:1527016695286};\\\", \\\"{x:1558,y:301,t:1527016695804};\\\", \\\"{x:1557,y:301,t:1527016695812};\\\", \\\"{x:1555,y:302,t:1527016695843};\\\", \\\"{x:1553,y:303,t:1527016698132};\\\", \\\"{x:1552,y:305,t:1527016698164};\\\", \\\"{x:1551,y:305,t:1527016698181};\\\", \\\"{x:1550,y:305,t:1527016698204};\\\", \\\"{x:1549,y:306,t:1527016698219};\\\", \\\"{x:1548,y:306,t:1527016698235};\\\", \\\"{x:1547,y:307,t:1527016698316};\\\", \\\"{x:1546,y:307,t:1527016698331};\\\", \\\"{x:1546,y:309,t:1527016698347};\\\", \\\"{x:1545,y:309,t:1527016698364};\\\", \\\"{x:1544,y:309,t:1527016699860};\\\", \\\"{x:1543,y:311,t:1527016699868};\\\", \\\"{x:1540,y:312,t:1527016699882};\\\", \\\"{x:1535,y:315,t:1527016699899};\\\", \\\"{x:1526,y:319,t:1527016699915};\\\", \\\"{x:1523,y:320,t:1527016699932};\\\", \\\"{x:1520,y:320,t:1527016699949};\\\", \\\"{x:1521,y:319,t:1527016700100};\\\", \\\"{x:1528,y:315,t:1527016700115};\\\", \\\"{x:1529,y:312,t:1527016700132};\\\", \\\"{x:1531,y:310,t:1527016700148};\\\", \\\"{x:1536,y:306,t:1527016700166};\\\", \\\"{x:1537,y:306,t:1527016700182};\\\", \\\"{x:1540,y:304,t:1527016700198};\\\", \\\"{x:1543,y:304,t:1527016700216};\\\", \\\"{x:1546,y:301,t:1527016700233};\\\", \\\"{x:1548,y:300,t:1527016700248};\\\", \\\"{x:1549,y:300,t:1527016700268};\\\", \\\"{x:1550,y:300,t:1527016700731};\\\", \\\"{x:1552,y:300,t:1527016700740};\\\", \\\"{x:1553,y:300,t:1527016700749};\\\", \\\"{x:1553,y:299,t:1527016700765};\\\", \\\"{x:1558,y:297,t:1527016700782};\\\", \\\"{x:1562,y:295,t:1527016700799};\\\", \\\"{x:1573,y:295,t:1527016700816};\\\", \\\"{x:1584,y:295,t:1527016700832};\\\", \\\"{x:1591,y:295,t:1527016700850};\\\", \\\"{x:1598,y:295,t:1527016700866};\\\", \\\"{x:1608,y:295,t:1527016700882};\\\", \\\"{x:1614,y:295,t:1527016700899};\\\", \\\"{x:1617,y:295,t:1527016700915};\\\", \\\"{x:1620,y:295,t:1527016700932};\\\", \\\"{x:1623,y:295,t:1527016700949};\\\", \\\"{x:1625,y:295,t:1527016700966};\\\", \\\"{x:1629,y:295,t:1527016700983};\\\", \\\"{x:1631,y:295,t:1527016700999};\\\", \\\"{x:1635,y:295,t:1527016701016};\\\", \\\"{x:1636,y:296,t:1527016701033};\\\", \\\"{x:1637,y:296,t:1527016701085};\\\", \\\"{x:1639,y:296,t:1527016701099};\\\", \\\"{x:1640,y:297,t:1527016701388};\\\", \\\"{x:1640,y:298,t:1527016703116};\\\", \\\"{x:1640,y:299,t:1527016703132};\\\", \\\"{x:1640,y:301,t:1527016703220};\\\", \\\"{x:1640,y:304,t:1527016703234};\\\", \\\"{x:1638,y:304,t:1527016703250};\\\", \\\"{x:1630,y:307,t:1527016703268};\\\", \\\"{x:1625,y:308,t:1527016703285};\\\", \\\"{x:1620,y:311,t:1527016703301};\\\", \\\"{x:1613,y:313,t:1527016703317};\\\", \\\"{x:1608,y:313,t:1527016703335};\\\", \\\"{x:1601,y:315,t:1527016703351};\\\", \\\"{x:1596,y:315,t:1527016703367};\\\", \\\"{x:1588,y:315,t:1527016703385};\\\", \\\"{x:1586,y:315,t:1527016703401};\\\", \\\"{x:1578,y:315,t:1527016703417};\\\", \\\"{x:1567,y:315,t:1527016703434};\\\", \\\"{x:1561,y:315,t:1527016703451};\\\", \\\"{x:1559,y:316,t:1527016703468};\\\", \\\"{x:1547,y:316,t:1527016703486};\\\", \\\"{x:1533,y:316,t:1527016703502};\\\", \\\"{x:1527,y:316,t:1527016703517};\\\", \\\"{x:1525,y:316,t:1527016703534};\\\", \\\"{x:1521,y:316,t:1527016703555};\\\", \\\"{x:1517,y:315,t:1527016703568};\\\", \\\"{x:1511,y:313,t:1527016703585};\\\", \\\"{x:1506,y:311,t:1527016703601};\\\", \\\"{x:1503,y:310,t:1527016703617};\\\", \\\"{x:1502,y:310,t:1527016703634};\\\", \\\"{x:1501,y:310,t:1527016703651};\\\", \\\"{x:1499,y:310,t:1527016704035};\\\", \\\"{x:1496,y:310,t:1527016704051};\\\", \\\"{x:1492,y:310,t:1527016704068};\\\", \\\"{x:1487,y:311,t:1527016704085};\\\", \\\"{x:1486,y:311,t:1527016704292};\\\", \\\"{x:1485,y:311,t:1527016706172};\\\", \\\"{x:1485,y:312,t:1527016706195};\\\", \\\"{x:1485,y:313,t:1527016706211};\\\", \\\"{x:1485,y:315,t:1527016706292};\\\", \\\"{x:1485,y:316,t:1527016706331};\\\", \\\"{x:1485,y:318,t:1527016706347};\\\", \\\"{x:1485,y:320,t:1527016706355};\\\", \\\"{x:1486,y:321,t:1527016706369};\\\", \\\"{x:1490,y:325,t:1527016706387};\\\", \\\"{x:1495,y:330,t:1527016706411};\\\", \\\"{x:1498,y:338,t:1527016706419};\\\", \\\"{x:1511,y:352,t:1527016706437};\\\", \\\"{x:1522,y:361,t:1527016706454};\\\", \\\"{x:1527,y:366,t:1527016706470};\\\", \\\"{x:1542,y:376,t:1527016706487};\\\", \\\"{x:1560,y:387,t:1527016706503};\\\", \\\"{x:1571,y:393,t:1527016706520};\\\", \\\"{x:1573,y:395,t:1527016706547};\\\", \\\"{x:1574,y:395,t:1527016706748};\\\", \\\"{x:1575,y:395,t:1527016706755};\\\", \\\"{x:1577,y:392,t:1527016706771};\\\", \\\"{x:1579,y:387,t:1527016706787};\\\", \\\"{x:1583,y:380,t:1527016706803};\\\", \\\"{x:1585,y:377,t:1527016706821};\\\", \\\"{x:1586,y:376,t:1527016706868};\\\", \\\"{x:1586,y:374,t:1527016707796};\\\", \\\"{x:1586,y:372,t:1527016707811};\\\", \\\"{x:1586,y:371,t:1527016707860};\\\", \\\"{x:1586,y:370,t:1527016707871};\\\", \\\"{x:1588,y:369,t:1527016707964};\\\", \\\"{x:1588,y:368,t:1527016708028};\\\", \\\"{x:1588,y:367,t:1527016708044};\\\", \\\"{x:1588,y:366,t:1527016708067};\\\", \\\"{x:1548,y:353,t:1527016719532};\\\", \\\"{x:1485,y:342,t:1527016719546};\\\", \\\"{x:1411,y:345,t:1527016719562};\\\", \\\"{x:1373,y:359,t:1527016719580};\\\", \\\"{x:1333,y:381,t:1527016719595};\\\", \\\"{x:1268,y:426,t:1527016719613};\\\", \\\"{x:1178,y:513,t:1527016719629};\\\", \\\"{x:1060,y:611,t:1527016719646};\\\", \\\"{x:959,y:674,t:1527016719662};\\\", \\\"{x:853,y:728,t:1527016719680};\\\", \\\"{x:759,y:787,t:1527016719695};\\\", \\\"{x:658,y:828,t:1527016719713};\\\", \\\"{x:574,y:852,t:1527016719729};\\\", \\\"{x:538,y:856,t:1527016719746};\\\", \\\"{x:535,y:858,t:1527016719762};\\\", \\\"{x:527,y:860,t:1527016719780};\\\", \\\"{x:510,y:870,t:1527016719796};\\\", \\\"{x:492,y:877,t:1527016719813};\\\", \\\"{x:491,y:877,t:1527016719830};\\\", \\\"{x:489,y:877,t:1527016719891};\\\", \\\"{x:487,y:873,t:1527016719898};\\\", \\\"{x:487,y:870,t:1527016719913};\\\", \\\"{x:487,y:845,t:1527016719930};\\\", \\\"{x:487,y:825,t:1527016719947};\\\", \\\"{x:495,y:801,t:1527016719963};\\\", \\\"{x:505,y:784,t:1527016719980};\\\", \\\"{x:505,y:770,t:1527016719997};\\\", \\\"{x:508,y:759,t:1527016720013};\\\", \\\"{x:513,y:750,t:1527016720031};\\\", \\\"{x:519,y:739,t:1527016720047};\\\", \\\"{x:520,y:737,t:1527016720062};\\\" ] }, { \\\"rt\\\": 21803, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 15, \\\"time_elapsed\\\": 782038, \\\"internal_node_id\\\": \\\"0.0-6.0-5.0\\\", \\\"subject\\\": \\\"6Y93F\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"foxtrot\\\", \\\"condition\\\": \\\"111\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"starttime\\\", \\\"q\\\": 11, \\\"clicks\\\": 2, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XInside-YFull\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 1, \\\"answer\\\": [ \\\"F\\\", \\\"B\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-B -04 PM-11 AM-12 PM-B \\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:524,y:736,t:1527016723892};\\\", \\\"{x:526,y:736,t:1527016723907};\\\", \\\"{x:528,y:736,t:1527016723947};\\\", \\\"{x:530,y:736,t:1527016723957};\\\", \\\"{x:532,y:736,t:1527016723974};\\\", \\\"{x:536,y:736,t:1527016723990};\\\", \\\"{x:545,y:728,t:1527016724007};\\\", \\\"{x:597,y:723,t:1527016724025};\\\", \\\"{x:692,y:728,t:1527016724040};\\\", \\\"{x:763,y:732,t:1527016724057};\\\", \\\"{x:808,y:733,t:1527016724067};\\\", \\\"{x:845,y:737,t:1527016724085};\\\", \\\"{x:886,y:737,t:1527016724101};\\\", \\\"{x:927,y:740,t:1527016724118};\\\", \\\"{x:993,y:742,t:1527016724134};\\\", \\\"{x:1055,y:744,t:1527016724151};\\\", \\\"{x:1082,y:744,t:1527016724168};\\\", \\\"{x:1086,y:742,t:1527016724185};\\\", \\\"{x:1087,y:742,t:1527016724201};\\\", \\\"{x:1099,y:742,t:1527016724218};\\\", \\\"{x:1111,y:740,t:1527016724234};\\\", \\\"{x:1129,y:740,t:1527016724251};\\\", \\\"{x:1195,y:738,t:1527016724268};\\\", \\\"{x:1239,y:735,t:1527016724286};\\\", \\\"{x:1279,y:738,t:1527016724301};\\\", \\\"{x:1295,y:743,t:1527016724319};\\\", \\\"{x:1302,y:745,t:1527016724336};\\\", \\\"{x:1313,y:748,t:1527016724351};\\\", \\\"{x:1320,y:750,t:1527016724369};\\\", \\\"{x:1326,y:752,t:1527016724385};\\\", \\\"{x:1334,y:756,t:1527016724401};\\\", \\\"{x:1338,y:758,t:1527016724418};\\\", \\\"{x:1338,y:759,t:1527016724435};\\\", \\\"{x:1338,y:758,t:1527016724923};\\\", \\\"{x:1338,y:756,t:1527016724939};\\\", \\\"{x:1338,y:755,t:1527016725308};\\\", \\\"{x:1338,y:754,t:1527016725319};\\\", \\\"{x:1342,y:751,t:1527016725335};\\\", \\\"{x:1344,y:750,t:1527016725352};\\\", \\\"{x:1348,y:752,t:1527016725395};\\\", \\\"{x:1349,y:754,t:1527016725403};\\\", \\\"{x:1355,y:761,t:1527016725419};\\\", \\\"{x:1373,y:777,t:1527016725435};\\\", \\\"{x:1392,y:800,t:1527016725452};\\\", \\\"{x:1412,y:820,t:1527016725468};\\\", \\\"{x:1433,y:842,t:1527016725485};\\\", \\\"{x:1452,y:864,t:1527016725502};\\\", \\\"{x:1464,y:883,t:1527016725518};\\\", \\\"{x:1469,y:892,t:1527016725535};\\\", \\\"{x:1470,y:898,t:1527016725552};\\\", \\\"{x:1473,y:902,t:1527016725568};\\\", \\\"{x:1473,y:903,t:1527016725585};\\\", \\\"{x:1474,y:904,t:1527016725602};\\\", \\\"{x:1474,y:906,t:1527016725651};\\\", \\\"{x:1476,y:908,t:1527016725667};\\\", \\\"{x:1477,y:909,t:1527016725675};\\\", \\\"{x:1477,y:911,t:1527016725687};\\\", \\\"{x:1480,y:912,t:1527016725702};\\\", \\\"{x:1486,y:916,t:1527016725719};\\\", \\\"{x:1489,y:919,t:1527016725735};\\\", \\\"{x:1500,y:923,t:1527016725752};\\\", \\\"{x:1511,y:925,t:1527016725767};\\\", \\\"{x:1523,y:930,t:1527016725785};\\\", \\\"{x:1534,y:933,t:1527016725801};\\\", \\\"{x:1556,y:940,t:1527016725818};\\\", \\\"{x:1570,y:946,t:1527016725834};\\\", \\\"{x:1586,y:950,t:1527016725852};\\\", \\\"{x:1592,y:955,t:1527016725868};\\\", \\\"{x:1601,y:959,t:1527016725885};\\\", \\\"{x:1608,y:962,t:1527016725902};\\\", \\\"{x:1614,y:969,t:1527016725918};\\\", \\\"{x:1619,y:977,t:1527016725935};\\\", \\\"{x:1622,y:982,t:1527016725952};\\\", \\\"{x:1623,y:986,t:1527016725969};\\\", \\\"{x:1624,y:987,t:1527016726027};\\\", \\\"{x:1625,y:987,t:1527016726043};\\\", \\\"{x:1626,y:987,t:1527016726052};\\\", \\\"{x:1634,y:997,t:1527016726068};\\\", \\\"{x:1643,y:1007,t:1527016726085};\\\", \\\"{x:1655,y:1012,t:1527016726102};\\\", \\\"{x:1667,y:1017,t:1527016726118};\\\", \\\"{x:1669,y:1018,t:1527016726136};\\\", \\\"{x:1682,y:1020,t:1527016726152};\\\", \\\"{x:1685,y:1020,t:1527016726168};\\\", \\\"{x:1690,y:1020,t:1527016726185};\\\", \\\"{x:1694,y:1018,t:1527016726202};\\\", \\\"{x:1700,y:1016,t:1527016726218};\\\", \\\"{x:1700,y:1015,t:1527016726235};\\\", \\\"{x:1700,y:1014,t:1527016726315};\\\", \\\"{x:1700,y:1013,t:1527016726323};\\\", \\\"{x:1697,y:1013,t:1527016726339};\\\", \\\"{x:1692,y:1012,t:1527016726352};\\\", \\\"{x:1682,y:1012,t:1527016726369};\\\", \\\"{x:1663,y:1012,t:1527016726386};\\\", \\\"{x:1624,y:1012,t:1527016726402};\\\", \\\"{x:1591,y:1012,t:1527016726419};\\\", \\\"{x:1524,y:1012,t:1527016726436};\\\", \\\"{x:1451,y:1013,t:1527016726452};\\\", \\\"{x:1356,y:1016,t:1527016726469};\\\", \\\"{x:1275,y:1018,t:1527016726486};\\\", \\\"{x:1259,y:1027,t:1527016726502};\\\", \\\"{x:1200,y:1025,t:1527016726519};\\\", \\\"{x:1178,y:1027,t:1527016726535};\\\", \\\"{x:1166,y:1027,t:1527016726553};\\\", \\\"{x:1154,y:1026,t:1527016726570};\\\", \\\"{x:1153,y:1024,t:1527016726611};\\\", \\\"{x:1152,y:1024,t:1527016726876};\\\", \\\"{x:1150,y:1023,t:1527016726885};\\\", \\\"{x:1147,y:1022,t:1527016726903};\\\", \\\"{x:1142,y:1022,t:1527016726920};\\\", \\\"{x:1135,y:1020,t:1527016726935};\\\", \\\"{x:1133,y:1019,t:1527016726952};\\\", \\\"{x:1131,y:1018,t:1527016726970};\\\", \\\"{x:1125,y:1017,t:1527016726985};\\\", \\\"{x:1120,y:1015,t:1527016727002};\\\", \\\"{x:1117,y:1014,t:1527016727025};\\\", \\\"{x:1120,y:1014,t:1527016727170};\\\", \\\"{x:1121,y:1014,t:1527016727185};\\\", \\\"{x:1125,y:1013,t:1527016727202};\\\", \\\"{x:1136,y:1010,t:1527016727218};\\\", \\\"{x:1143,y:1008,t:1527016727235};\\\", \\\"{x:1146,y:1008,t:1527016727252};\\\", \\\"{x:1149,y:1008,t:1527016727270};\\\", \\\"{x:1157,y:1008,t:1527016727285};\\\", \\\"{x:1160,y:1008,t:1527016727302};\\\", \\\"{x:1163,y:1008,t:1527016727319};\\\", \\\"{x:1169,y:1007,t:1527016727335};\\\", \\\"{x:1176,y:1006,t:1527016727352};\\\", \\\"{x:1186,y:1004,t:1527016727369};\\\", \\\"{x:1203,y:1001,t:1527016727385};\\\", \\\"{x:1221,y:997,t:1527016727402};\\\", \\\"{x:1228,y:996,t:1527016727419};\\\", \\\"{x:1232,y:996,t:1527016727436};\\\", \\\"{x:1232,y:995,t:1527016727491};\\\", \\\"{x:1232,y:994,t:1527016727531};\\\", \\\"{x:1233,y:993,t:1527016727538};\\\", \\\"{x:1235,y:992,t:1527016727635};\\\", \\\"{x:1238,y:990,t:1527016727653};\\\", \\\"{x:1240,y:989,t:1527016727675};\\\", \\\"{x:1241,y:989,t:1527016727691};\\\", \\\"{x:1242,y:988,t:1527016727731};\\\", \\\"{x:1247,y:987,t:1527016727739};\\\", \\\"{x:1251,y:987,t:1527016727752};\\\", \\\"{x:1255,y:986,t:1527016727769};\\\", \\\"{x:1270,y:984,t:1527016727787};\\\", \\\"{x:1275,y:984,t:1527016727802};\\\", \\\"{x:1278,y:983,t:1527016727819};\\\", \\\"{x:1288,y:982,t:1527016727837};\\\", \\\"{x:1295,y:981,t:1527016727852};\\\", \\\"{x:1300,y:980,t:1527016727869};\\\", \\\"{x:1302,y:979,t:1527016727887};\\\", \\\"{x:1304,y:979,t:1527016727923};\\\", \\\"{x:1306,y:978,t:1527016727937};\\\", \\\"{x:1309,y:977,t:1527016728219};\\\", \\\"{x:1310,y:976,t:1527016728236};\\\", \\\"{x:1315,y:973,t:1527016728253};\\\", \\\"{x:1319,y:973,t:1527016728269};\\\", \\\"{x:1323,y:973,t:1527016728286};\\\", \\\"{x:1334,y:971,t:1527016728303};\\\", \\\"{x:1336,y:969,t:1527016728320};\\\", \\\"{x:1338,y:968,t:1527016728337};\\\", \\\"{x:1341,y:968,t:1527016728353};\\\", \\\"{x:1342,y:962,t:1527016729435};\\\", \\\"{x:1340,y:940,t:1527016729453};\\\", \\\"{x:1340,y:929,t:1527016729469};\\\", \\\"{x:1340,y:915,t:1527016729487};\\\", \\\"{x:1342,y:901,t:1527016729504};\\\", \\\"{x:1346,y:889,t:1527016729519};\\\", \\\"{x:1349,y:880,t:1527016729537};\\\", \\\"{x:1350,y:866,t:1527016729554};\\\", \\\"{x:1353,y:845,t:1527016729569};\\\", \\\"{x:1361,y:807,t:1527016729586};\\\", \\\"{x:1361,y:786,t:1527016729603};\\\", \\\"{x:1360,y:772,t:1527016729619};\\\", \\\"{x:1360,y:769,t:1527016729637};\\\", \\\"{x:1358,y:762,t:1527016729654};\\\", \\\"{x:1354,y:755,t:1527016729669};\\\", \\\"{x:1346,y:745,t:1527016729687};\\\", \\\"{x:1339,y:740,t:1527016729704};\\\", \\\"{x:1331,y:736,t:1527016729719};\\\", \\\"{x:1323,y:735,t:1527016729736};\\\", \\\"{x:1317,y:732,t:1527016729754};\\\", \\\"{x:1288,y:732,t:1527016729770};\\\", \\\"{x:1261,y:732,t:1527016729786};\\\", \\\"{x:1243,y:732,t:1527016729803};\\\", \\\"{x:1234,y:732,t:1527016729821};\\\", \\\"{x:1233,y:732,t:1527016729837};\\\", \\\"{x:1230,y:732,t:1527016729853};\\\", \\\"{x:1229,y:731,t:1527016729871};\\\", \\\"{x:1227,y:730,t:1527016729887};\\\", \\\"{x:1226,y:730,t:1527016729903};\\\", \\\"{x:1226,y:729,t:1527016729920};\\\", \\\"{x:1222,y:727,t:1527016729937};\\\", \\\"{x:1214,y:726,t:1527016729954};\\\", \\\"{x:1191,y:717,t:1527016729970};\\\", \\\"{x:1169,y:709,t:1527016729987};\\\", \\\"{x:1155,y:698,t:1527016730003};\\\", \\\"{x:1125,y:691,t:1527016730021};\\\", \\\"{x:1109,y:687,t:1527016730036};\\\", \\\"{x:1095,y:686,t:1527016730053};\\\", \\\"{x:1079,y:686,t:1527016730070};\\\", \\\"{x:1066,y:686,t:1527016730086};\\\", \\\"{x:1054,y:686,t:1527016730103};\\\", \\\"{x:1043,y:686,t:1527016730121};\\\", \\\"{x:1033,y:686,t:1527016730137};\\\", \\\"{x:1031,y:686,t:1527016730154};\\\", \\\"{x:1022,y:688,t:1527016730170};\\\", \\\"{x:1019,y:688,t:1527016730187};\\\", \\\"{x:1012,y:688,t:1527016730203};\\\", \\\"{x:1006,y:688,t:1527016730220};\\\", \\\"{x:1004,y:688,t:1527016730237};\\\", \\\"{x:1000,y:688,t:1527016730254};\\\", \\\"{x:988,y:686,t:1527016730271};\\\", \\\"{x:984,y:684,t:1527016730286};\\\", \\\"{x:978,y:683,t:1527016730304};\\\", \\\"{x:977,y:682,t:1527016730320};\\\", \\\"{x:966,y:680,t:1527016730336};\\\", \\\"{x:961,y:680,t:1527016730353};\\\", \\\"{x:955,y:680,t:1527016730370};\\\", \\\"{x:934,y:679,t:1527016730386};\\\", \\\"{x:921,y:676,t:1527016730404};\\\", \\\"{x:918,y:675,t:1527016730420};\\\", \\\"{x:912,y:673,t:1527016730437};\\\", \\\"{x:905,y:672,t:1527016730453};\\\", \\\"{x:895,y:672,t:1527016730470};\\\", \\\"{x:886,y:671,t:1527016730486};\\\", \\\"{x:880,y:670,t:1527016730503};\\\", \\\"{x:877,y:669,t:1527016730520};\\\", \\\"{x:877,y:668,t:1527016730554};\\\", \\\"{x:877,y:666,t:1527016730570};\\\", \\\"{x:876,y:664,t:1527016730706};\\\", \\\"{x:867,y:657,t:1527016730719};\\\", \\\"{x:849,y:639,t:1527016730736};\\\", \\\"{x:843,y:633,t:1527016730753};\\\", \\\"{x:822,y:623,t:1527016730772};\\\", \\\"{x:805,y:621,t:1527016730786};\\\", \\\"{x:796,y:617,t:1527016730803};\\\", \\\"{x:781,y:614,t:1527016730823};\\\", \\\"{x:776,y:612,t:1527016730841};\\\", \\\"{x:759,y:614,t:1527016730857};\\\", \\\"{x:701,y:614,t:1527016730874};\\\", \\\"{x:625,y:601,t:1527016730891};\\\", \\\"{x:542,y:592,t:1527016730907};\\\", \\\"{x:470,y:583,t:1527016730924};\\\", \\\"{x:397,y:578,t:1527016730941};\\\", \\\"{x:358,y:578,t:1527016730957};\\\", \\\"{x:339,y:574,t:1527016730974};\\\", \\\"{x:329,y:571,t:1527016730991};\\\", \\\"{x:325,y:566,t:1527016731007};\\\", \\\"{x:322,y:559,t:1527016731024};\\\", \\\"{x:318,y:552,t:1527016731041};\\\", \\\"{x:312,y:545,t:1527016731057};\\\", \\\"{x:310,y:542,t:1527016731074};\\\", \\\"{x:313,y:542,t:1527016731667};\\\", \\\"{x:314,y:542,t:1527016731674};\\\", \\\"{x:317,y:542,t:1527016731689};\\\", \\\"{x:331,y:548,t:1527016731706};\\\", \\\"{x:341,y:553,t:1527016731723};\\\", \\\"{x:349,y:561,t:1527016731739};\\\", \\\"{x:352,y:571,t:1527016731757};\\\", \\\"{x:359,y:577,t:1527016731772};\\\", \\\"{x:362,y:582,t:1527016731789};\\\", \\\"{x:366,y:588,t:1527016731805};\\\", \\\"{x:369,y:592,t:1527016731822};\\\", \\\"{x:375,y:602,t:1527016731841};\\\", \\\"{x:382,y:608,t:1527016731855};\\\", \\\"{x:389,y:611,t:1527016731875};\\\", \\\"{x:392,y:611,t:1527016731891};\\\", \\\"{x:393,y:611,t:1527016731908};\\\", \\\"{x:392,y:611,t:1527016731925};\\\", \\\"{x:392,y:609,t:1527016733344};\\\", \\\"{x:392,y:607,t:1527016733351};\\\", \\\"{x:392,y:604,t:1527016733363};\\\", \\\"{x:386,y:601,t:1527016733380};\\\", \\\"{x:382,y:597,t:1527016733399};\\\", \\\"{x:376,y:594,t:1527016733414};\\\", \\\"{x:351,y:592,t:1527016733430};\\\", \\\"{x:332,y:587,t:1527016733447};\\\", \\\"{x:313,y:583,t:1527016733464};\\\", \\\"{x:295,y:577,t:1527016733480};\\\", \\\"{x:291,y:574,t:1527016733496};\\\", \\\"{x:286,y:573,t:1527016733513};\\\", \\\"{x:285,y:572,t:1527016733530};\\\", \\\"{x:283,y:572,t:1527016733546};\\\", \\\"{x:277,y:572,t:1527016733564};\\\", \\\"{x:269,y:572,t:1527016733582};\\\", \\\"{x:258,y:572,t:1527016733596};\\\", \\\"{x:252,y:572,t:1527016733614};\\\", \\\"{x:250,y:573,t:1527016733654};\\\", \\\"{x:248,y:575,t:1527016733663};\\\", \\\"{x:245,y:576,t:1527016733681};\\\", \\\"{x:239,y:579,t:1527016733697};\\\", \\\"{x:237,y:581,t:1527016733714};\\\", \\\"{x:236,y:582,t:1527016733730};\\\", \\\"{x:235,y:582,t:1527016733748};\\\", \\\"{x:234,y:582,t:1527016733791};\\\", \\\"{x:232,y:582,t:1527016733799};\\\", \\\"{x:213,y:579,t:1527016733815};\\\", \\\"{x:207,y:570,t:1527016733831};\\\", \\\"{x:199,y:565,t:1527016733848};\\\", \\\"{x:194,y:562,t:1527016733866};\\\", \\\"{x:191,y:562,t:1527016733881};\\\", \\\"{x:182,y:556,t:1527016733897};\\\", \\\"{x:178,y:552,t:1527016733915};\\\", \\\"{x:176,y:550,t:1527016733931};\\\", \\\"{x:174,y:549,t:1527016733948};\\\", \\\"{x:172,y:548,t:1527016733966};\\\", \\\"{x:172,y:547,t:1527016733980};\\\", \\\"{x:171,y:546,t:1527016734070};\\\", \\\"{x:170,y:544,t:1527016734086};\\\", \\\"{x:169,y:544,t:1527016734099};\\\", \\\"{x:168,y:544,t:1527016734114};\\\", \\\"{x:167,y:543,t:1527016734134};\\\", \\\"{x:166,y:542,t:1527016734158};\\\", \\\"{x:165,y:541,t:1527016734182};\\\", \\\"{x:162,y:540,t:1527016734222};\\\", \\\"{x:162,y:539,t:1527016734254};\\\", \\\"{x:162,y:538,t:1527016734264};\\\", \\\"{x:164,y:540,t:1527016734688};\\\", \\\"{x:165,y:544,t:1527016734699};\\\", \\\"{x:171,y:550,t:1527016734716};\\\", \\\"{x:174,y:553,t:1527016734731};\\\", \\\"{x:175,y:553,t:1527016734749};\\\", \\\"{x:190,y:554,t:1527016734765};\\\", \\\"{x:228,y:555,t:1527016734782};\\\", \\\"{x:248,y:555,t:1527016734798};\\\", \\\"{x:272,y:554,t:1527016734815};\\\", \\\"{x:294,y:552,t:1527016734833};\\\", \\\"{x:311,y:551,t:1527016734848};\\\", \\\"{x:329,y:548,t:1527016734864};\\\", \\\"{x:348,y:545,t:1527016734882};\\\", \\\"{x:366,y:542,t:1527016734898};\\\", \\\"{x:373,y:542,t:1527016734914};\\\", \\\"{x:375,y:542,t:1527016734932};\\\", \\\"{x:378,y:541,t:1527016734948};\\\", \\\"{x:379,y:541,t:1527016734964};\\\", \\\"{x:380,y:540,t:1527016734982};\\\", \\\"{x:390,y:534,t:1527016734998};\\\", \\\"{x:404,y:529,t:1527016735015};\\\", \\\"{x:420,y:517,t:1527016735032};\\\", \\\"{x:433,y:514,t:1527016735048};\\\", \\\"{x:444,y:513,t:1527016735064};\\\", \\\"{x:461,y:511,t:1527016735081};\\\", \\\"{x:470,y:511,t:1527016735098};\\\", \\\"{x:481,y:513,t:1527016735115};\\\", \\\"{x:504,y:513,t:1527016735133};\\\", \\\"{x:564,y:516,t:1527016735148};\\\", \\\"{x:627,y:522,t:1527016735166};\\\", \\\"{x:673,y:523,t:1527016735181};\\\", \\\"{x:779,y:516,t:1527016735198};\\\", \\\"{x:829,y:516,t:1527016735215};\\\", \\\"{x:857,y:516,t:1527016735232};\\\", \\\"{x:873,y:516,t:1527016735248};\\\", \\\"{x:885,y:516,t:1527016735265};\\\", \\\"{x:901,y:516,t:1527016735281};\\\", \\\"{x:906,y:516,t:1527016735298};\\\", \\\"{x:912,y:516,t:1527016735315};\\\", \\\"{x:913,y:516,t:1527016735331};\\\", \\\"{x:914,y:516,t:1527016735358};\\\", \\\"{x:913,y:516,t:1527016735406};\\\", \\\"{x:910,y:516,t:1527016735416};\\\", \\\"{x:899,y:516,t:1527016735432};\\\", \\\"{x:885,y:516,t:1527016735449};\\\", \\\"{x:876,y:518,t:1527016735467};\\\", \\\"{x:872,y:519,t:1527016735482};\\\", \\\"{x:868,y:520,t:1527016735499};\\\", \\\"{x:866,y:520,t:1527016735527};\\\", \\\"{x:864,y:520,t:1527016735535};\\\", \\\"{x:863,y:520,t:1527016735550};\\\", \\\"{x:859,y:520,t:1527016735566};\\\", \\\"{x:857,y:520,t:1527016735583};\\\", \\\"{x:855,y:520,t:1527016735599};\\\", \\\"{x:852,y:520,t:1527016735616};\\\", \\\"{x:844,y:519,t:1527016735633};\\\", \\\"{x:842,y:518,t:1527016735650};\\\", \\\"{x:840,y:517,t:1527016735672};\\\", \\\"{x:837,y:515,t:1527016735716};\\\", \\\"{x:835,y:513,t:1527016735734};\\\", \\\"{x:834,y:512,t:1527016735749};\\\", \\\"{x:833,y:511,t:1527016735765};\\\", \\\"{x:832,y:510,t:1527016735783};\\\", \\\"{x:827,y:514,t:1527016736392};\\\", \\\"{x:823,y:519,t:1527016736399};\\\", \\\"{x:815,y:529,t:1527016736416};\\\", \\\"{x:808,y:537,t:1527016736432};\\\", \\\"{x:800,y:542,t:1527016736449};\\\", \\\"{x:792,y:548,t:1527016736467};\\\", \\\"{x:786,y:553,t:1527016736482};\\\", \\\"{x:783,y:554,t:1527016736499};\\\", \\\"{x:781,y:556,t:1527016736517};\\\", \\\"{x:779,y:558,t:1527016736550};\\\", \\\"{x:777,y:558,t:1527016736566};\\\", \\\"{x:775,y:559,t:1527016736583};\\\", \\\"{x:775,y:560,t:1527016736655};\\\", \\\"{x:774,y:560,t:1527016736703};\\\", \\\"{x:774,y:561,t:1527016736717};\\\", \\\"{x:773,y:561,t:1527016737511};\\\", \\\"{x:770,y:562,t:1527016737526};\\\", \\\"{x:770,y:565,t:1527016737538};\\\", \\\"{x:770,y:567,t:1527016737550};\\\", \\\"{x:768,y:571,t:1527016737568};\\\", \\\"{x:767,y:571,t:1527016737583};\\\", \\\"{x:767,y:572,t:1527016737601};\\\", \\\"{x:767,y:583,t:1527016739247};\\\", \\\"{x:767,y:604,t:1527016739256};\\\", \\\"{x:767,y:616,t:1527016739268};\\\", \\\"{x:765,y:645,t:1527016739284};\\\", \\\"{x:764,y:671,t:1527016739301};\\\", \\\"{x:734,y:753,t:1527016739318};\\\", \\\"{x:706,y:811,t:1527016739335};\\\", \\\"{x:700,y:820,t:1527016739351};\\\", \\\"{x:700,y:821,t:1527016739368};\\\", \\\"{x:699,y:822,t:1527016739454};\\\", \\\"{x:698,y:822,t:1527016739469};\\\", \\\"{x:697,y:821,t:1527016739486};\\\", \\\"{x:695,y:817,t:1527016739502};\\\", \\\"{x:694,y:817,t:1527016739519};\\\", \\\"{x:693,y:815,t:1527016739536};\\\", \\\"{x:691,y:813,t:1527016739552};\\\", \\\"{x:689,y:812,t:1527016739574};\\\", \\\"{x:688,y:812,t:1527016739607};\\\", \\\"{x:685,y:812,t:1527016739623};\\\", \\\"{x:684,y:812,t:1527016739636};\\\", \\\"{x:681,y:812,t:1527016739652};\\\", \\\"{x:680,y:812,t:1527016739669};\\\", \\\"{x:677,y:811,t:1527016739686};\\\", \\\"{x:675,y:809,t:1527016739702};\\\", \\\"{x:671,y:806,t:1527016739719};\\\", \\\"{x:665,y:797,t:1527016739736};\\\", \\\"{x:655,y:789,t:1527016739752};\\\", \\\"{x:637,y:772,t:1527016739769};\\\", \\\"{x:623,y:761,t:1527016739786};\\\", \\\"{x:605,y:745,t:1527016739802};\\\", \\\"{x:594,y:735,t:1527016739819};\\\", \\\"{x:590,y:730,t:1527016739836};\\\", \\\"{x:590,y:725,t:1527016739852};\\\", \\\"{x:576,y:717,t:1527016739868};\\\", \\\"{x:560,y:711,t:1527016739887};\\\", \\\"{x:552,y:706,t:1527016739902};\\\", \\\"{x:547,y:704,t:1527016739919};\\\", \\\"{x:544,y:704,t:1527016740007};\\\", \\\"{x:541,y:706,t:1527016740018};\\\", \\\"{x:534,y:715,t:1527016740036};\\\", \\\"{x:525,y:725,t:1527016740054};\\\", \\\"{x:519,y:734,t:1527016740069};\\\", \\\"{x:514,y:741,t:1527016740085};\\\", \\\"{x:512,y:742,t:1527016740102};\\\", \\\"{x:511,y:743,t:1527016740206};\\\" ] }, { \\\"rt\\\": 30171, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 16, \\\"time_elapsed\\\": 813413, \\\"internal_node_id\\\": \\\"0.0-6.0-6.0\\\", \\\"subject\\\": \\\"6Y93F\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"foxtrot\\\", \\\"condition\\\": \\\"111\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"starts\\\", \\\"q\\\": 12, \\\"clicks\\\": 1, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XInside-YFull\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 1, \\\"answer\\\": [ \\\"B\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-O -O \\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:512,y:743,t:1527016746119};\\\", \\\"{x:515,y:743,t:1527016746128};\\\", \\\"{x:516,y:742,t:1527016746164};\\\", \\\"{x:525,y:742,t:1527016746176};\\\", \\\"{x:530,y:742,t:1527016746193};\\\", \\\"{x:538,y:742,t:1527016746209};\\\", \\\"{x:546,y:742,t:1527016746226};\\\", \\\"{x:556,y:742,t:1527016746243};\\\", \\\"{x:566,y:744,t:1527016746259};\\\", \\\"{x:568,y:744,t:1527016746276};\\\", \\\"{x:569,y:745,t:1527016746291};\\\", \\\"{x:570,y:746,t:1527016746307};\\\", \\\"{x:573,y:746,t:1527016746323};\\\", \\\"{x:584,y:746,t:1527016746341};\\\", \\\"{x:593,y:747,t:1527016746356};\\\", \\\"{x:597,y:750,t:1527016746374};\\\", \\\"{x:598,y:751,t:1527016746391};\\\", \\\"{x:606,y:754,t:1527016746407};\\\", \\\"{x:627,y:759,t:1527016746424};\\\", \\\"{x:654,y:763,t:1527016746441};\\\", \\\"{x:680,y:764,t:1527016746457};\\\", \\\"{x:722,y:764,t:1527016746474};\\\", \\\"{x:765,y:765,t:1527016746492};\\\", \\\"{x:810,y:765,t:1527016746508};\\\", \\\"{x:836,y:761,t:1527016746524};\\\", \\\"{x:911,y:761,t:1527016746541};\\\", \\\"{x:1069,y:761,t:1527016746559};\\\", \\\"{x:1150,y:760,t:1527016746575};\\\", \\\"{x:1208,y:760,t:1527016746591};\\\", \\\"{x:1249,y:760,t:1527016746609};\\\", \\\"{x:1307,y:760,t:1527016746625};\\\", \\\"{x:1360,y:764,t:1527016746641};\\\", \\\"{x:1390,y:770,t:1527016746659};\\\", \\\"{x:1408,y:771,t:1527016746674};\\\", \\\"{x:1410,y:771,t:1527016746692};\\\", \\\"{x:1421,y:771,t:1527016746709};\\\", \\\"{x:1427,y:770,t:1527016746724};\\\", \\\"{x:1443,y:770,t:1527016746742};\\\", \\\"{x:1461,y:770,t:1527016746759};\\\", \\\"{x:1471,y:770,t:1527016746775};\\\", \\\"{x:1484,y:769,t:1527016746791};\\\", \\\"{x:1491,y:768,t:1527016746809};\\\", \\\"{x:1504,y:765,t:1527016746824};\\\", \\\"{x:1512,y:764,t:1527016746844};\\\", \\\"{x:1512,y:763,t:1527016746942};\\\", \\\"{x:1512,y:759,t:1527016746958};\\\", \\\"{x:1511,y:758,t:1527016746976};\\\", \\\"{x:1510,y:754,t:1527016746991};\\\", \\\"{x:1500,y:753,t:1527016747009};\\\", \\\"{x:1486,y:752,t:1527016747025};\\\", \\\"{x:1475,y:750,t:1527016747041};\\\", \\\"{x:1466,y:750,t:1527016747058};\\\", \\\"{x:1453,y:748,t:1527016747075};\\\", \\\"{x:1448,y:747,t:1527016747091};\\\", \\\"{x:1448,y:745,t:1527016747223};\\\", \\\"{x:1451,y:742,t:1527016747231};\\\", \\\"{x:1456,y:737,t:1527016747242};\\\", \\\"{x:1458,y:732,t:1527016747258};\\\", \\\"{x:1468,y:721,t:1527016747274};\\\", \\\"{x:1477,y:704,t:1527016747292};\\\", \\\"{x:1490,y:682,t:1527016747307};\\\", \\\"{x:1498,y:671,t:1527016747324};\\\", \\\"{x:1501,y:664,t:1527016747341};\\\", \\\"{x:1500,y:661,t:1527016747358};\\\", \\\"{x:1493,y:657,t:1527016747375};\\\", \\\"{x:1484,y:652,t:1527016747391};\\\", \\\"{x:1478,y:652,t:1527016747407};\\\", \\\"{x:1475,y:652,t:1527016747425};\\\", \\\"{x:1460,y:660,t:1527016747442};\\\", \\\"{x:1454,y:660,t:1527016747458};\\\", \\\"{x:1446,y:663,t:1527016747475};\\\", \\\"{x:1440,y:664,t:1527016747492};\\\", \\\"{x:1435,y:667,t:1527016747508};\\\", \\\"{x:1427,y:672,t:1527016747525};\\\", \\\"{x:1422,y:677,t:1527016747542};\\\", \\\"{x:1421,y:678,t:1527016747558};\\\", \\\"{x:1421,y:679,t:1527016747615};\\\", \\\"{x:1420,y:679,t:1527016747663};\\\", \\\"{x:1416,y:680,t:1527016747675};\\\", \\\"{x:1407,y:684,t:1527016747692};\\\", \\\"{x:1390,y:689,t:1527016747708};\\\", \\\"{x:1375,y:695,t:1527016747726};\\\", \\\"{x:1359,y:702,t:1527016747742};\\\", \\\"{x:1359,y:706,t:1527016747758};\\\", \\\"{x:1350,y:710,t:1527016747776};\\\", \\\"{x:1340,y:714,t:1527016747793};\\\", \\\"{x:1331,y:718,t:1527016747808};\\\", \\\"{x:1327,y:718,t:1527016747826};\\\", \\\"{x:1326,y:718,t:1527016747842};\\\", \\\"{x:1327,y:718,t:1527016747934};\\\", \\\"{x:1332,y:718,t:1527016747950};\\\", \\\"{x:1332,y:717,t:1527016747959};\\\", \\\"{x:1337,y:715,t:1527016747976};\\\", \\\"{x:1342,y:714,t:1527016747993};\\\", \\\"{x:1348,y:710,t:1527016748008};\\\", \\\"{x:1351,y:708,t:1527016748024};\\\", \\\"{x:1357,y:706,t:1527016748042};\\\", \\\"{x:1357,y:705,t:1527016748059};\\\", \\\"{x:1359,y:705,t:1527016748074};\\\", \\\"{x:1356,y:705,t:1527016748335};\\\", \\\"{x:1355,y:705,t:1527016748342};\\\", \\\"{x:1346,y:705,t:1527016748359};\\\", \\\"{x:1316,y:699,t:1527016748377};\\\", \\\"{x:1203,y:673,t:1527016748393};\\\", \\\"{x:1076,y:639,t:1527016748410};\\\", \\\"{x:955,y:605,t:1527016748426};\\\", \\\"{x:797,y:563,t:1527016748443};\\\", \\\"{x:652,y:528,t:1527016748459};\\\", \\\"{x:475,y:481,t:1527016748475};\\\", \\\"{x:323,y:437,t:1527016748492};\\\", \\\"{x:181,y:404,t:1527016748509};\\\", \\\"{x:0,y:345,t:1527016748526};\\\", \\\"{x:0,y:341,t:1527016748541};\\\", \\\"{x:0,y:333,t:1527016748559};\\\", \\\"{x:0,y:327,t:1527016748575};\\\", \\\"{x:2,y:328,t:1527016748687};\\\", \\\"{x:7,y:332,t:1527016748694};\\\", \\\"{x:12,y:336,t:1527016748709};\\\", \\\"{x:30,y:354,t:1527016748727};\\\", \\\"{x:69,y:370,t:1527016748742};\\\", \\\"{x:153,y:394,t:1527016748759};\\\", \\\"{x:252,y:420,t:1527016748776};\\\", \\\"{x:325,y:445,t:1527016748794};\\\", \\\"{x:366,y:453,t:1527016748809};\\\", \\\"{x:454,y:474,t:1527016748826};\\\", \\\"{x:479,y:486,t:1527016748844};\\\", \\\"{x:515,y:493,t:1527016748860};\\\", \\\"{x:525,y:502,t:1527016748876};\\\", \\\"{x:529,y:504,t:1527016748892};\\\", \\\"{x:531,y:504,t:1527016748908};\\\", \\\"{x:531,y:510,t:1527016749111};\\\", \\\"{x:533,y:517,t:1527016749125};\\\", \\\"{x:537,y:535,t:1527016749143};\\\", \\\"{x:545,y:544,t:1527016749159};\\\", \\\"{x:551,y:555,t:1527016749176};\\\", \\\"{x:556,y:562,t:1527016749194};\\\", \\\"{x:563,y:570,t:1527016749211};\\\", \\\"{x:569,y:572,t:1527016749226};\\\", \\\"{x:570,y:572,t:1527016749253};\\\", \\\"{x:571,y:572,t:1527016749262};\\\", \\\"{x:572,y:572,t:1527016749277};\\\", \\\"{x:573,y:572,t:1527016750528};\\\", \\\"{x:573,y:571,t:1527016750544};\\\", \\\"{x:569,y:566,t:1527016750561};\\\", \\\"{x:559,y:561,t:1527016750579};\\\", \\\"{x:541,y:553,t:1527016750595};\\\", \\\"{x:535,y:548,t:1527016750611};\\\", \\\"{x:520,y:540,t:1527016750627};\\\", \\\"{x:514,y:537,t:1527016750644};\\\", \\\"{x:511,y:535,t:1527016750660};\\\", \\\"{x:506,y:535,t:1527016750677};\\\", \\\"{x:504,y:535,t:1527016751719};\\\", \\\"{x:495,y:535,t:1527016751730};\\\", \\\"{x:491,y:535,t:1527016751745};\\\", \\\"{x:477,y:535,t:1527016751762};\\\", \\\"{x:460,y:532,t:1527016751778};\\\", \\\"{x:449,y:532,t:1527016751795};\\\", \\\"{x:424,y:531,t:1527016751812};\\\", \\\"{x:410,y:530,t:1527016751828};\\\", \\\"{x:392,y:529,t:1527016751844};\\\", \\\"{x:381,y:529,t:1527016751862};\\\", \\\"{x:361,y:529,t:1527016751878};\\\", \\\"{x:344,y:529,t:1527016751895};\\\", \\\"{x:330,y:529,t:1527016751912};\\\", \\\"{x:328,y:529,t:1527016751928};\\\", \\\"{x:325,y:527,t:1527016751945};\\\", \\\"{x:322,y:527,t:1527016751982};\\\", \\\"{x:321,y:527,t:1527016751998};\\\", \\\"{x:312,y:527,t:1527016752014};\\\", \\\"{x:306,y:529,t:1527016752028};\\\", \\\"{x:299,y:533,t:1527016752045};\\\", \\\"{x:275,y:534,t:1527016752062};\\\", \\\"{x:258,y:534,t:1527016752080};\\\", \\\"{x:246,y:534,t:1527016752095};\\\", \\\"{x:226,y:531,t:1527016752112};\\\", \\\"{x:224,y:531,t:1527016752127};\\\", \\\"{x:210,y:530,t:1527016752145};\\\", \\\"{x:201,y:530,t:1527016752162};\\\", \\\"{x:199,y:532,t:1527016752178};\\\", \\\"{x:198,y:532,t:1527016752206};\\\", \\\"{x:198,y:533,t:1527016752310};\\\", \\\"{x:197,y:533,t:1527016752390};\\\", \\\"{x:194,y:534,t:1527016752398};\\\", \\\"{x:193,y:534,t:1527016752412};\\\", \\\"{x:190,y:534,t:1527016752433};\\\", \\\"{x:189,y:534,t:1527016752446};\\\", \\\"{x:183,y:534,t:1527016752461};\\\", \\\"{x:181,y:534,t:1527016752479};\\\", \\\"{x:179,y:534,t:1527016752495};\\\", \\\"{x:177,y:533,t:1527016752512};\\\", \\\"{x:176,y:533,t:1527016752529};\\\", \\\"{x:174,y:533,t:1527016752549};\\\", \\\"{x:172,y:533,t:1527016752566};\\\", \\\"{x:173,y:533,t:1527016752999};\\\", \\\"{x:175,y:533,t:1527016753013};\\\", \\\"{x:219,y:548,t:1527016753030};\\\", \\\"{x:371,y:587,t:1527016753048};\\\", \\\"{x:452,y:614,t:1527016753063};\\\", \\\"{x:510,y:633,t:1527016753079};\\\", \\\"{x:550,y:641,t:1527016753096};\\\", \\\"{x:578,y:651,t:1527016753113};\\\", \\\"{x:620,y:665,t:1527016753129};\\\", \\\"{x:635,y:670,t:1527016753146};\\\", \\\"{x:648,y:671,t:1527016753163};\\\", \\\"{x:653,y:674,t:1527016753179};\\\", \\\"{x:654,y:674,t:1527016753196};\\\", \\\"{x:656,y:674,t:1527016753303};\\\", \\\"{x:658,y:674,t:1527016753327};\\\", \\\"{x:661,y:675,t:1527016753334};\\\", \\\"{x:664,y:675,t:1527016753346};\\\", \\\"{x:665,y:675,t:1527016753363};\\\", \\\"{x:669,y:675,t:1527016753379};\\\", \\\"{x:671,y:676,t:1527016753396};\\\", \\\"{x:671,y:677,t:1527016756407};\\\", \\\"{x:670,y:677,t:1527016756414};\\\", \\\"{x:667,y:677,t:1527016756431};\\\", \\\"{x:665,y:678,t:1527016756447};\\\", \\\"{x:659,y:678,t:1527016756465};\\\", \\\"{x:653,y:681,t:1527016756482};\\\", \\\"{x:644,y:687,t:1527016756497};\\\", \\\"{x:639,y:690,t:1527016756515};\\\", \\\"{x:639,y:691,t:1527016756551};\\\", \\\"{x:639,y:696,t:1527016756783};\\\", \\\"{x:639,y:707,t:1527016756799};\\\", \\\"{x:639,y:716,t:1527016756815};\\\", \\\"{x:638,y:728,t:1527016756832};\\\", \\\"{x:640,y:751,t:1527016756848};\\\", \\\"{x:647,y:776,t:1527016756864};\\\", \\\"{x:649,y:797,t:1527016756881};\\\", \\\"{x:652,y:807,t:1527016756898};\\\", \\\"{x:654,y:812,t:1527016756915};\\\", \\\"{x:656,y:815,t:1527016756931};\\\", \\\"{x:657,y:815,t:1527016756949};\\\", \\\"{x:657,y:817,t:1527016757455};\\\", \\\"{x:653,y:819,t:1527016757465};\\\", \\\"{x:650,y:824,t:1527016757482};\\\", \\\"{x:642,y:826,t:1527016757499};\\\", \\\"{x:639,y:828,t:1527016757515};\\\", \\\"{x:638,y:829,t:1527016757543};\\\", \\\"{x:636,y:829,t:1527016757767};\\\", \\\"{x:630,y:830,t:1527016757782};\\\", \\\"{x:624,y:830,t:1527016757798};\\\", \\\"{x:621,y:831,t:1527016757816};\\\", \\\"{x:620,y:831,t:1527016757831};\\\", \\\"{x:617,y:831,t:1527016757849};\\\", \\\"{x:616,y:831,t:1527016757866};\\\", \\\"{x:614,y:831,t:1527016757881};\\\", \\\"{x:613,y:831,t:1527016757902};\\\", \\\"{x:611,y:831,t:1527016757915};\\\", \\\"{x:610,y:831,t:1527016757931};\\\", \\\"{x:606,y:831,t:1527016757948};\\\", \\\"{x:603,y:829,t:1527016757966};\\\", \\\"{x:603,y:827,t:1527016757982};\\\", \\\"{x:598,y:823,t:1527016757998};\\\", \\\"{x:594,y:819,t:1527016758016};\\\", \\\"{x:586,y:814,t:1527016758033};\\\", \\\"{x:580,y:807,t:1527016758049};\\\", \\\"{x:573,y:799,t:1527016758066};\\\", \\\"{x:561,y:790,t:1527016758081};\\\", \\\"{x:545,y:781,t:1527016758099};\\\", \\\"{x:534,y:773,t:1527016758115};\\\", \\\"{x:528,y:769,t:1527016758133};\\\", \\\"{x:527,y:767,t:1527016758149};\\\", \\\"{x:526,y:765,t:1527016758165};\\\", \\\"{x:523,y:760,t:1527016758182};\\\", \\\"{x:523,y:759,t:1527016758199};\\\", \\\"{x:523,y:757,t:1527016758215};\\\", \\\"{x:522,y:757,t:1527016758232};\\\", \\\"{x:521,y:756,t:1527016758249};\\\", \\\"{x:520,y:755,t:1527016758266};\\\", \\\"{x:516,y:752,t:1527016758283};\\\", \\\"{x:511,y:750,t:1527016758298};\\\", \\\"{x:510,y:749,t:1527016758315};\\\", \\\"{x:510,y:748,t:1527016758328};\\\", \\\"{x:510,y:747,t:1527016758350};\\\", \\\"{x:510,y:746,t:1527016758373};\\\", \\\"{x:510,y:745,t:1527016758390};\\\", \\\"{x:510,y:744,t:1527016758405};\\\", \\\"{x:510,y:742,t:1527016758429};\\\", \\\"{x:510,y:741,t:1527016758446};\\\", \\\"{x:510,y:740,t:1527016759135};\\\" ] }, { \\\"rt\\\": 69086, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 17, \\\"time_elapsed\\\": 883714, \\\"internal_node_id\\\": \\\"0.0-6.0-7.0\\\", \\\"subject\\\": \\\"6Y93F\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"foxtrot\\\", \\\"condition\\\": \\\"111\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"meets\\\", \\\"q\\\": 13, \\\"clicks\\\": 2, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XInside-YFull\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 1, \\\"answer\\\": [ \\\"F\\\", \\\"X\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-4-G -G -Z -O -B -B \\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:516,y:736,t:1527016777717};\\\", \\\"{x:518,y:735,t:1527016777731};\\\", \\\"{x:531,y:729,t:1527016777755};\\\", \\\"{x:536,y:726,t:1527016777765};\\\", \\\"{x:544,y:722,t:1527016777781};\\\", \\\"{x:551,y:717,t:1527016777799};\\\", \\\"{x:554,y:716,t:1527016777816};\\\", \\\"{x:555,y:715,t:1527016777831};\\\", \\\"{x:558,y:713,t:1527016777849};\\\", \\\"{x:563,y:713,t:1527016777865};\\\", \\\"{x:566,y:711,t:1527016777882};\\\", \\\"{x:567,y:711,t:1527016777899};\\\", \\\"{x:567,y:710,t:1527016777916};\\\", \\\"{x:579,y:706,t:1527016777932};\\\", \\\"{x:583,y:701,t:1527016777949};\\\", \\\"{x:599,y:699,t:1527016777965};\\\", \\\"{x:613,y:699,t:1527016777983};\\\", \\\"{x:624,y:699,t:1527016777999};\\\", \\\"{x:653,y:698,t:1527016778016};\\\", \\\"{x:669,y:696,t:1527016778032};\\\", \\\"{x:716,y:696,t:1527016778049};\\\", \\\"{x:758,y:696,t:1527016778066};\\\", \\\"{x:777,y:696,t:1527016778084};\\\", \\\"{x:788,y:696,t:1527016778100};\\\", \\\"{x:801,y:694,t:1527016778116};\\\", \\\"{x:817,y:694,t:1527016778133};\\\", \\\"{x:849,y:693,t:1527016778149};\\\", \\\"{x:869,y:691,t:1527016778166};\\\", \\\"{x:912,y:687,t:1527016778184};\\\", \\\"{x:962,y:687,t:1527016778199};\\\", \\\"{x:1006,y:687,t:1527016778217};\\\", \\\"{x:1057,y:689,t:1527016778233};\\\", \\\"{x:1080,y:691,t:1527016778250};\\\", \\\"{x:1150,y:691,t:1527016778267};\\\", \\\"{x:1176,y:688,t:1527016778283};\\\", \\\"{x:1199,y:688,t:1527016778299};\\\", \\\"{x:1222,y:691,t:1527016778316};\\\", \\\"{x:1249,y:692,t:1527016778333};\\\", \\\"{x:1289,y:692,t:1527016778349};\\\", \\\"{x:1359,y:692,t:1527016778366};\\\", \\\"{x:1379,y:694,t:1527016778384};\\\", \\\"{x:1397,y:696,t:1527016778400};\\\", \\\"{x:1428,y:696,t:1527016778417};\\\", \\\"{x:1444,y:695,t:1527016778434};\\\", \\\"{x:1467,y:694,t:1527016778450};\\\", \\\"{x:1491,y:694,t:1527016778467};\\\", \\\"{x:1494,y:693,t:1527016778484};\\\", \\\"{x:1502,y:689,t:1527016778501};\\\", \\\"{x:1513,y:682,t:1527016778516};\\\", \\\"{x:1528,y:674,t:1527016778533};\\\", \\\"{x:1537,y:665,t:1527016778550};\\\", \\\"{x:1543,y:662,t:1527016778566};\\\", \\\"{x:1545,y:660,t:1527016778583};\\\", \\\"{x:1546,y:658,t:1527016778600};\\\", \\\"{x:1547,y:658,t:1527016778616};\\\", \\\"{x:1547,y:656,t:1527016778634};\\\", \\\"{x:1543,y:651,t:1527016778651};\\\", \\\"{x:1538,y:649,t:1527016778666};\\\", \\\"{x:1536,y:647,t:1527016778684};\\\", \\\"{x:1535,y:647,t:1527016778751};\\\", \\\"{x:1534,y:646,t:1527016778766};\\\", \\\"{x:1533,y:646,t:1527016778784};\\\", \\\"{x:1532,y:643,t:1527016778903};\\\", \\\"{x:1532,y:640,t:1527016778918};\\\", \\\"{x:1533,y:635,t:1527016778933};\\\", \\\"{x:1537,y:635,t:1527016778950};\\\", \\\"{x:1537,y:634,t:1527016779558};\\\", \\\"{x:1538,y:634,t:1527016779574};\\\", \\\"{x:1538,y:633,t:1527016779782};\\\", \\\"{x:1537,y:632,t:1527016779790};\\\", \\\"{x:1528,y:628,t:1527016779800};\\\", \\\"{x:1503,y:621,t:1527016779817};\\\", \\\"{x:1481,y:617,t:1527016779835};\\\", \\\"{x:1457,y:613,t:1527016779851};\\\", \\\"{x:1454,y:609,t:1527016779867};\\\", \\\"{x:1442,y:601,t:1527016779884};\\\", \\\"{x:1439,y:599,t:1527016779901};\\\", \\\"{x:1427,y:584,t:1527016779918};\\\", \\\"{x:1419,y:565,t:1527016779937};\\\", \\\"{x:1415,y:549,t:1527016779951};\\\", \\\"{x:1412,y:527,t:1527016779967};\\\", \\\"{x:1409,y:509,t:1527016779984};\\\", \\\"{x:1410,y:496,t:1527016780001};\\\", \\\"{x:1414,y:485,t:1527016780017};\\\", \\\"{x:1415,y:478,t:1527016780034};\\\", \\\"{x:1419,y:471,t:1527016780051};\\\", \\\"{x:1421,y:462,t:1527016780067};\\\", \\\"{x:1424,y:453,t:1527016780084};\\\", \\\"{x:1427,y:439,t:1527016780101};\\\", \\\"{x:1428,y:432,t:1527016780118};\\\", \\\"{x:1428,y:430,t:1527016780142};\\\", \\\"{x:1428,y:428,t:1527016780152};\\\", \\\"{x:1428,y:425,t:1527016780167};\\\", \\\"{x:1428,y:424,t:1527016780206};\\\", \\\"{x:1430,y:423,t:1527016780303};\\\", \\\"{x:1431,y:422,t:1527016780318};\\\", \\\"{x:1433,y:421,t:1527016780334};\\\", \\\"{x:1434,y:421,t:1527016780446};\\\", \\\"{x:1435,y:420,t:1527016780598};\\\", \\\"{x:1436,y:420,t:1527016780605};\\\", \\\"{x:1436,y:419,t:1527016780638};\\\", \\\"{x:1436,y:418,t:1527016781374};\\\", \\\"{x:1435,y:419,t:1527016781590};\\\", \\\"{x:1432,y:419,t:1527016781602};\\\", \\\"{x:1430,y:422,t:1527016781618};\\\", \\\"{x:1427,y:428,t:1527016781635};\\\", \\\"{x:1427,y:429,t:1527016781652};\\\", \\\"{x:1427,y:427,t:1527016782134};\\\", \\\"{x:1427,y:426,t:1527016782150};\\\", \\\"{x:1427,y:427,t:1527016782446};\\\", \\\"{x:1427,y:430,t:1527016782454};\\\", \\\"{x:1425,y:437,t:1527016782471};\\\", \\\"{x:1424,y:445,t:1527016782486};\\\", \\\"{x:1424,y:474,t:1527016782502};\\\", \\\"{x:1434,y:500,t:1527016782519};\\\", \\\"{x:1436,y:518,t:1527016782537};\\\", \\\"{x:1433,y:542,t:1527016782553};\\\", \\\"{x:1424,y:558,t:1527016782570};\\\", \\\"{x:1412,y:580,t:1527016782587};\\\", \\\"{x:1402,y:602,t:1527016782602};\\\", \\\"{x:1395,y:619,t:1527016782620};\\\", \\\"{x:1389,y:636,t:1527016782636};\\\", \\\"{x:1384,y:652,t:1527016782653};\\\", \\\"{x:1374,y:676,t:1527016782670};\\\", \\\"{x:1359,y:706,t:1527016782686};\\\", \\\"{x:1336,y:743,t:1527016782704};\\\", \\\"{x:1296,y:799,t:1527016782720};\\\", \\\"{x:1270,y:831,t:1527016782737};\\\", \\\"{x:1253,y:851,t:1527016782753};\\\", \\\"{x:1243,y:864,t:1527016782770};\\\", \\\"{x:1241,y:868,t:1527016782786};\\\", \\\"{x:1240,y:869,t:1527016782803};\\\", \\\"{x:1240,y:870,t:1527016782838};\\\", \\\"{x:1241,y:872,t:1527016782853};\\\", \\\"{x:1261,y:879,t:1527016782870};\\\", \\\"{x:1264,y:881,t:1527016782886};\\\", \\\"{x:1265,y:881,t:1527016782909};\\\", \\\"{x:1265,y:882,t:1527016783614};\\\", \\\"{x:1267,y:882,t:1527016783830};\\\", \\\"{x:1272,y:882,t:1527016783837};\\\", \\\"{x:1286,y:874,t:1527016783854};\\\", \\\"{x:1298,y:864,t:1527016783871};\\\", \\\"{x:1300,y:858,t:1527016783888};\\\", \\\"{x:1306,y:849,t:1527016783903};\\\", \\\"{x:1315,y:830,t:1527016783921};\\\", \\\"{x:1321,y:821,t:1527016783938};\\\", \\\"{x:1330,y:810,t:1527016783954};\\\", \\\"{x:1355,y:793,t:1527016783970};\\\", \\\"{x:1399,y:758,t:1527016783988};\\\", \\\"{x:1455,y:714,t:1527016784004};\\\", \\\"{x:1502,y:680,t:1527016784020};\\\", \\\"{x:1571,y:639,t:1527016784038};\\\", \\\"{x:1595,y:623,t:1527016784054};\\\", \\\"{x:1614,y:610,t:1527016784070};\\\", \\\"{x:1623,y:606,t:1527016784087};\\\", \\\"{x:1627,y:605,t:1527016784105};\\\", \\\"{x:1629,y:603,t:1527016784121};\\\", \\\"{x:1631,y:603,t:1527016784138};\\\", \\\"{x:1641,y:601,t:1527016784154};\\\", \\\"{x:1649,y:600,t:1527016784171};\\\", \\\"{x:1665,y:600,t:1527016784187};\\\", \\\"{x:1674,y:602,t:1527016784204};\\\", \\\"{x:1695,y:608,t:1527016784220};\\\", \\\"{x:1711,y:618,t:1527016784238};\\\", \\\"{x:1714,y:623,t:1527016784254};\\\", \\\"{x:1714,y:631,t:1527016784271};\\\", \\\"{x:1712,y:639,t:1527016784288};\\\", \\\"{x:1705,y:655,t:1527016784304};\\\", \\\"{x:1700,y:669,t:1527016784321};\\\", \\\"{x:1699,y:675,t:1527016784338};\\\", \\\"{x:1695,y:680,t:1527016784354};\\\", \\\"{x:1691,y:686,t:1527016784371};\\\", \\\"{x:1688,y:689,t:1527016784387};\\\", \\\"{x:1686,y:691,t:1527016784405};\\\", \\\"{x:1681,y:693,t:1527016784421};\\\", \\\"{x:1667,y:696,t:1527016784438};\\\", \\\"{x:1656,y:696,t:1527016784454};\\\", \\\"{x:1648,y:696,t:1527016784470};\\\", \\\"{x:1642,y:696,t:1527016784487};\\\", \\\"{x:1638,y:696,t:1527016784505};\\\", \\\"{x:1635,y:696,t:1527016784520};\\\", \\\"{x:1633,y:696,t:1527016785022};\\\", \\\"{x:1632,y:696,t:1527016785045};\\\", \\\"{x:1631,y:696,t:1527016785061};\\\", \\\"{x:1627,y:695,t:1527016785072};\\\", \\\"{x:1620,y:695,t:1527016785089};\\\", \\\"{x:1612,y:695,t:1527016785104};\\\", \\\"{x:1610,y:695,t:1527016785121};\\\", \\\"{x:1611,y:695,t:1527016785238};\\\", \\\"{x:1616,y:695,t:1527016785255};\\\", \\\"{x:1619,y:695,t:1527016785272};\\\", \\\"{x:1622,y:695,t:1527016785290};\\\", \\\"{x:1627,y:695,t:1527016785305};\\\", \\\"{x:1639,y:697,t:1527016785322};\\\", \\\"{x:1657,y:702,t:1527016785339};\\\", \\\"{x:1673,y:707,t:1527016785354};\\\", \\\"{x:1676,y:708,t:1527016785372};\\\", \\\"{x:1681,y:710,t:1527016785389};\\\", \\\"{x:1685,y:710,t:1527016785404};\\\", \\\"{x:1686,y:711,t:1527016785422};\\\", \\\"{x:1686,y:710,t:1527016786102};\\\", \\\"{x:1687,y:710,t:1527016786110};\\\", \\\"{x:1688,y:709,t:1527016786123};\\\", \\\"{x:1690,y:708,t:1527016786138};\\\", \\\"{x:1696,y:707,t:1527016786155};\\\", \\\"{x:1698,y:707,t:1527016786172};\\\", \\\"{x:1703,y:707,t:1527016786188};\\\", \\\"{x:1707,y:706,t:1527016786205};\\\", \\\"{x:1709,y:706,t:1527016786222};\\\", \\\"{x:1711,y:706,t:1527016786238};\\\", \\\"{x:1712,y:706,t:1527016786261};\\\", \\\"{x:1713,y:706,t:1527016786273};\\\", \\\"{x:1715,y:704,t:1527016786288};\\\", \\\"{x:1719,y:704,t:1527016786305};\\\", \\\"{x:1722,y:702,t:1527016786322};\\\", \\\"{x:1726,y:700,t:1527016786341};\\\", \\\"{x:1730,y:700,t:1527016786355};\\\", \\\"{x:1741,y:700,t:1527016786372};\\\", \\\"{x:1746,y:700,t:1527016786388};\\\", \\\"{x:1751,y:699,t:1527016786405};\\\", \\\"{x:1752,y:699,t:1527016786423};\\\", \\\"{x:1754,y:698,t:1527016786439};\\\", \\\"{x:1750,y:701,t:1527016787911};\\\", \\\"{x:1747,y:708,t:1527016787924};\\\", \\\"{x:1733,y:728,t:1527016787941};\\\", \\\"{x:1718,y:744,t:1527016787957};\\\", \\\"{x:1706,y:754,t:1527016787974};\\\", \\\"{x:1705,y:757,t:1527016787991};\\\", \\\"{x:1704,y:757,t:1527016788103};\\\", \\\"{x:1703,y:756,t:1527016788133};\\\", \\\"{x:1703,y:754,t:1527016788142};\\\", \\\"{x:1702,y:750,t:1527016788157};\\\", \\\"{x:1698,y:740,t:1527016788174};\\\", \\\"{x:1692,y:727,t:1527016788190};\\\", \\\"{x:1686,y:716,t:1527016788207};\\\", \\\"{x:1682,y:708,t:1527016788223};\\\", \\\"{x:1679,y:703,t:1527016788241};\\\", \\\"{x:1676,y:698,t:1527016788257};\\\", \\\"{x:1666,y:690,t:1527016788274};\\\", \\\"{x:1659,y:689,t:1527016788290};\\\", \\\"{x:1652,y:687,t:1527016788308};\\\", \\\"{x:1647,y:686,t:1527016788324};\\\", \\\"{x:1646,y:686,t:1527016788340};\\\", \\\"{x:1648,y:687,t:1527016788502};\\\", \\\"{x:1651,y:688,t:1527016788509};\\\", \\\"{x:1654,y:688,t:1527016788524};\\\", \\\"{x:1661,y:693,t:1527016788541};\\\", \\\"{x:1667,y:695,t:1527016788558};\\\", \\\"{x:1669,y:696,t:1527016788574};\\\", \\\"{x:1670,y:696,t:1527016788862};\\\", \\\"{x:1671,y:696,t:1527016788893};\\\", \\\"{x:1673,y:697,t:1527016788908};\\\", \\\"{x:1674,y:698,t:1527016788925};\\\", \\\"{x:1674,y:699,t:1527016788941};\\\", \\\"{x:1675,y:699,t:1527016788958};\\\", \\\"{x:1677,y:699,t:1527016789782};\\\", \\\"{x:1680,y:699,t:1527016789870};\\\", \\\"{x:1681,y:699,t:1527016789942};\\\", \\\"{x:1682,y:699,t:1527016790078};\\\", \\\"{x:1683,y:699,t:1527016790093};\\\", \\\"{x:1684,y:699,t:1527016790142};\\\", \\\"{x:1686,y:698,t:1527016790606};\\\", \\\"{x:1692,y:698,t:1527016790614};\\\", \\\"{x:1693,y:698,t:1527016790626};\\\", \\\"{x:1696,y:698,t:1527016790642};\\\", \\\"{x:1704,y:697,t:1527016790659};\\\", \\\"{x:1711,y:697,t:1527016790676};\\\", \\\"{x:1715,y:697,t:1527016790692};\\\", \\\"{x:1718,y:697,t:1527016790709};\\\", \\\"{x:1720,y:697,t:1527016790725};\\\", \\\"{x:1722,y:696,t:1527016790743};\\\", \\\"{x:1724,y:695,t:1527016790774};\\\", \\\"{x:1725,y:694,t:1527016790781};\\\", \\\"{x:1727,y:694,t:1527016790797};\\\", \\\"{x:1729,y:694,t:1527016790829};\\\", \\\"{x:1730,y:694,t:1527016790843};\\\", \\\"{x:1736,y:694,t:1527016790859};\\\", \\\"{x:1747,y:694,t:1527016790876};\\\", \\\"{x:1749,y:694,t:1527016790892};\\\", \\\"{x:1752,y:694,t:1527016792586};\\\", \\\"{x:1755,y:694,t:1527016792598};\\\", \\\"{x:1760,y:694,t:1527016792615};\\\", \\\"{x:1767,y:694,t:1527016792631};\\\", \\\"{x:1770,y:694,t:1527016792648};\\\", \\\"{x:1771,y:694,t:1527016792665};\\\", \\\"{x:1772,y:694,t:1527016792681};\\\", \\\"{x:1775,y:694,t:1527016792697};\\\", \\\"{x:1779,y:694,t:1527016792715};\\\", \\\"{x:1781,y:694,t:1527016792730};\\\", \\\"{x:1786,y:694,t:1527016792748};\\\", \\\"{x:1788,y:694,t:1527016792764};\\\", \\\"{x:1791,y:694,t:1527016792781};\\\", \\\"{x:1795,y:694,t:1527016792797};\\\", \\\"{x:1798,y:694,t:1527016792815};\\\", \\\"{x:1802,y:694,t:1527016792831};\\\", \\\"{x:1807,y:692,t:1527016792847};\\\", \\\"{x:1808,y:692,t:1527016793890};\\\", \\\"{x:1809,y:691,t:1527016793899};\\\", \\\"{x:1810,y:691,t:1527016793915};\\\", \\\"{x:1812,y:691,t:1527016793938};\\\", \\\"{x:1813,y:691,t:1527016793949};\\\", \\\"{x:1819,y:691,t:1527016793965};\\\", \\\"{x:1824,y:691,t:1527016793982};\\\", \\\"{x:1833,y:691,t:1527016793998};\\\", \\\"{x:1839,y:691,t:1527016794014};\\\", \\\"{x:1840,y:691,t:1527016794032};\\\", \\\"{x:1843,y:691,t:1527016794049};\\\", \\\"{x:1844,y:691,t:1527016794098};\\\", \\\"{x:1846,y:691,t:1527016794121};\\\", \\\"{x:1849,y:691,t:1527016794132};\\\", \\\"{x:1853,y:692,t:1527016794149};\\\", \\\"{x:1859,y:693,t:1527016794166};\\\", \\\"{x:1860,y:693,t:1527016794185};\\\", \\\"{x:1862,y:693,t:1527016794202};\\\", \\\"{x:1863,y:693,t:1527016794216};\\\", \\\"{x:1866,y:693,t:1527016794232};\\\", \\\"{x:1868,y:693,t:1527016794249};\\\", \\\"{x:1869,y:693,t:1527016794265};\\\", \\\"{x:1870,y:693,t:1527016794314};\\\", \\\"{x:1871,y:693,t:1527016794418};\\\", \\\"{x:1872,y:694,t:1527016794970};\\\", \\\"{x:1872,y:695,t:1527016795073};\\\", \\\"{x:1871,y:695,t:1527016795082};\\\", \\\"{x:1870,y:695,t:1527016795099};\\\", \\\"{x:1869,y:695,t:1527016795121};\\\", \\\"{x:1868,y:695,t:1527016795145};\\\", \\\"{x:1867,y:695,t:1527016795152};\\\", \\\"{x:1865,y:695,t:1527016795193};\\\", \\\"{x:1864,y:695,t:1527016795234};\\\", \\\"{x:1862,y:695,t:1527016795265};\\\", \\\"{x:1856,y:695,t:1527016795283};\\\", \\\"{x:1852,y:695,t:1527016795300};\\\", \\\"{x:1842,y:694,t:1527016795316};\\\", \\\"{x:1823,y:694,t:1527016795333};\\\", \\\"{x:1813,y:694,t:1527016795350};\\\", \\\"{x:1809,y:694,t:1527016795366};\\\", \\\"{x:1801,y:694,t:1527016795383};\\\", \\\"{x:1790,y:694,t:1527016795400};\\\", \\\"{x:1782,y:694,t:1527016795416};\\\", \\\"{x:1779,y:694,t:1527016795433};\\\", \\\"{x:1762,y:694,t:1527016795450};\\\", \\\"{x:1738,y:693,t:1527016795467};\\\", \\\"{x:1733,y:691,t:1527016795483};\\\", \\\"{x:1707,y:684,t:1527016795500};\\\", \\\"{x:1684,y:684,t:1527016795517};\\\", \\\"{x:1680,y:684,t:1527016795532};\\\", \\\"{x:1673,y:684,t:1527016795550};\\\", \\\"{x:1671,y:684,t:1527016795567};\\\", \\\"{x:1670,y:684,t:1527016795582};\\\", \\\"{x:1669,y:684,t:1527016795753};\\\", \\\"{x:1669,y:685,t:1527016795767};\\\", \\\"{x:1671,y:695,t:1527016795782};\\\", \\\"{x:1675,y:703,t:1527016795800};\\\", \\\"{x:1679,y:707,t:1527016795816};\\\", \\\"{x:1680,y:708,t:1527016795832};\\\", \\\"{x:1681,y:707,t:1527016796105};\\\", \\\"{x:1682,y:705,t:1527016796116};\\\", \\\"{x:1682,y:704,t:1527016796133};\\\", \\\"{x:1683,y:703,t:1527016796149};\\\", \\\"{x:1684,y:702,t:1527016796167};\\\", \\\"{x:1684,y:701,t:1527016796185};\\\", \\\"{x:1685,y:700,t:1527016796201};\\\", \\\"{x:1686,y:698,t:1527016796217};\\\", \\\"{x:1686,y:697,t:1527016796233};\\\", \\\"{x:1687,y:696,t:1527016796281};\\\", \\\"{x:1686,y:696,t:1527016799049};\\\", \\\"{x:1685,y:696,t:1527016799202};\\\", \\\"{x:1684,y:696,t:1527016799834};\\\", \\\"{x:1685,y:696,t:1527016802377};\\\", \\\"{x:1691,y:696,t:1527016802388};\\\", \\\"{x:1704,y:696,t:1527016802405};\\\", \\\"{x:1713,y:696,t:1527016802421};\\\", \\\"{x:1723,y:696,t:1527016802438};\\\", \\\"{x:1727,y:696,t:1527016802455};\\\", \\\"{x:1729,y:696,t:1527016802471};\\\", \\\"{x:1731,y:696,t:1527016802490};\\\", \\\"{x:1733,y:696,t:1527016802544};\\\", \\\"{x:1736,y:696,t:1527016802554};\\\", \\\"{x:1737,y:696,t:1527016802571};\\\", \\\"{x:1738,y:696,t:1527016802587};\\\", \\\"{x:1739,y:696,t:1527016802604};\\\", \\\"{x:1742,y:696,t:1527016803169};\\\", \\\"{x:1750,y:695,t:1527016803178};\\\", \\\"{x:1754,y:695,t:1527016803189};\\\", \\\"{x:1776,y:694,t:1527016803205};\\\", \\\"{x:1791,y:694,t:1527016803222};\\\", \\\"{x:1800,y:694,t:1527016803239};\\\", \\\"{x:1804,y:694,t:1527016803255};\\\", \\\"{x:1806,y:694,t:1527016803272};\\\", \\\"{x:1806,y:693,t:1527016803322};\\\", \\\"{x:1808,y:692,t:1527016803340};\\\", \\\"{x:1810,y:692,t:1527016803355};\\\", \\\"{x:1813,y:692,t:1527016803372};\\\", \\\"{x:1816,y:692,t:1527016803389};\\\", \\\"{x:1817,y:691,t:1527016805330};\\\", \\\"{x:1819,y:691,t:1527016805341};\\\", \\\"{x:1834,y:691,t:1527016805357};\\\", \\\"{x:1852,y:691,t:1527016805375};\\\", \\\"{x:1861,y:691,t:1527016805390};\\\", \\\"{x:1864,y:691,t:1527016805407};\\\", \\\"{x:1861,y:691,t:1527016806482};\\\", \\\"{x:1858,y:691,t:1527016806491};\\\", \\\"{x:1854,y:691,t:1527016806508};\\\", \\\"{x:1852,y:691,t:1527016806525};\\\", \\\"{x:1841,y:696,t:1527016806541};\\\", \\\"{x:1824,y:708,t:1527016806559};\\\", \\\"{x:1794,y:717,t:1527016806574};\\\", \\\"{x:1780,y:722,t:1527016806591};\\\", \\\"{x:1755,y:733,t:1527016806608};\\\", \\\"{x:1731,y:738,t:1527016806624};\\\", \\\"{x:1689,y:755,t:1527016806641};\\\", \\\"{x:1638,y:779,t:1527016806659};\\\", \\\"{x:1596,y:796,t:1527016806675};\\\", \\\"{x:1573,y:812,t:1527016806691};\\\", \\\"{x:1540,y:827,t:1527016806708};\\\", \\\"{x:1512,y:838,t:1527016806725};\\\", \\\"{x:1496,y:850,t:1527016806741};\\\", \\\"{x:1454,y:869,t:1527016806758};\\\", \\\"{x:1391,y:893,t:1527016806775};\\\", \\\"{x:1325,y:907,t:1527016806791};\\\", \\\"{x:1278,y:919,t:1527016806808};\\\", \\\"{x:1243,y:926,t:1527016806825};\\\", \\\"{x:1165,y:939,t:1527016806841};\\\", \\\"{x:1148,y:941,t:1527016806858};\\\", \\\"{x:1140,y:941,t:1527016806875};\\\", \\\"{x:1139,y:942,t:1527016806891};\\\", \\\"{x:1137,y:942,t:1527016806909};\\\", \\\"{x:1135,y:943,t:1527016806994};\\\", \\\"{x:1133,y:944,t:1527016807008};\\\", \\\"{x:1127,y:944,t:1527016807025};\\\", \\\"{x:1122,y:945,t:1527016807041};\\\", \\\"{x:1119,y:947,t:1527016807058};\\\", \\\"{x:1115,y:948,t:1527016807075};\\\", \\\"{x:1114,y:949,t:1527016807091};\\\", \\\"{x:1113,y:950,t:1527016807108};\\\", \\\"{x:1110,y:951,t:1527016807125};\\\", \\\"{x:1108,y:952,t:1527016807209};\\\", \\\"{x:1104,y:954,t:1527016807226};\\\", \\\"{x:1101,y:955,t:1527016807242};\\\", \\\"{x:1101,y:956,t:1527016807259};\\\", \\\"{x:1100,y:957,t:1527016807281};\\\", \\\"{x:1101,y:957,t:1527016807617};\\\", \\\"{x:1104,y:957,t:1527016807633};\\\", \\\"{x:1105,y:957,t:1527016807665};\\\", \\\"{x:1107,y:957,t:1527016807675};\\\", \\\"{x:1108,y:956,t:1527016807692};\\\", \\\"{x:1112,y:954,t:1527016807709};\\\", \\\"{x:1115,y:953,t:1527016807725};\\\", \\\"{x:1116,y:952,t:1527016807742};\\\", \\\"{x:1117,y:951,t:1527016807760};\\\", \\\"{x:1118,y:951,t:1527016807776};\\\", \\\"{x:1118,y:950,t:1527016807792};\\\", \\\"{x:1120,y:950,t:1527016807874};\\\", \\\"{x:1121,y:950,t:1527016807881};\\\", \\\"{x:1122,y:950,t:1527016807905};\\\", \\\"{x:1123,y:950,t:1527016807921};\\\", \\\"{x:1127,y:948,t:1527016807929};\\\", \\\"{x:1130,y:947,t:1527016807942};\\\", \\\"{x:1135,y:946,t:1527016807969};\\\", \\\"{x:1143,y:945,t:1527016807977};\\\", \\\"{x:1151,y:943,t:1527016807992};\\\", \\\"{x:1179,y:942,t:1527016808009};\\\", \\\"{x:1200,y:938,t:1527016808025};\\\", \\\"{x:1205,y:938,t:1527016808043};\\\", \\\"{x:1219,y:936,t:1527016808059};\\\", \\\"{x:1233,y:935,t:1527016808076};\\\", \\\"{x:1248,y:933,t:1527016808092};\\\", \\\"{x:1256,y:930,t:1527016808109};\\\", \\\"{x:1262,y:930,t:1527016808125};\\\", \\\"{x:1265,y:929,t:1527016808142};\\\", \\\"{x:1268,y:927,t:1527016818825};\\\", \\\"{x:1276,y:921,t:1527016818833};\\\", \\\"{x:1358,y:901,t:1527016818851};\\\", \\\"{x:1449,y:880,t:1527016818867};\\\", \\\"{x:1471,y:862,t:1527016818884};\\\", \\\"{x:1492,y:851,t:1527016818901};\\\", \\\"{x:1510,y:843,t:1527016818917};\\\", \\\"{x:1520,y:836,t:1527016818934};\\\", \\\"{x:1525,y:832,t:1527016818951};\\\", \\\"{x:1529,y:827,t:1527016818966};\\\", \\\"{x:1542,y:817,t:1527016818984};\\\", \\\"{x:1549,y:816,t:1527016819001};\\\", \\\"{x:1551,y:814,t:1527016819017};\\\", \\\"{x:1550,y:813,t:1527016819105};\\\", \\\"{x:1549,y:813,t:1527016819185};\\\", \\\"{x:1548,y:813,t:1527016819201};\\\", \\\"{x:1547,y:813,t:1527016819249};\\\", \\\"{x:1547,y:814,t:1527016819265};\\\", \\\"{x:1547,y:815,t:1527016819297};\\\", \\\"{x:1547,y:816,t:1527016819305};\\\", \\\"{x:1547,y:817,t:1527016819317};\\\", \\\"{x:1548,y:818,t:1527016819334};\\\", \\\"{x:1549,y:821,t:1527016819351};\\\", \\\"{x:1549,y:822,t:1527016819368};\\\", \\\"{x:1549,y:823,t:1527016819385};\\\", \\\"{x:1550,y:823,t:1527016819401};\\\", \\\"{x:1551,y:824,t:1527016819418};\\\", \\\"{x:1553,y:825,t:1527016819434};\\\", \\\"{x:1560,y:831,t:1527016819450};\\\", \\\"{x:1576,y:840,t:1527016819468};\\\", \\\"{x:1601,y:850,t:1527016819485};\\\", \\\"{x:1622,y:856,t:1527016819501};\\\", \\\"{x:1624,y:856,t:1527016819521};\\\", \\\"{x:1625,y:856,t:1527016819553};\\\", \\\"{x:1625,y:854,t:1527016819761};\\\", \\\"{x:1625,y:853,t:1527016819769};\\\", \\\"{x:1623,y:852,t:1527016819785};\\\", \\\"{x:1620,y:848,t:1527016819801};\\\", \\\"{x:1614,y:844,t:1527016819817};\\\", \\\"{x:1612,y:843,t:1527016819835};\\\", \\\"{x:1611,y:842,t:1527016819850};\\\", \\\"{x:1611,y:841,t:1527016819868};\\\", \\\"{x:1610,y:841,t:1527016819897};\\\", \\\"{x:1609,y:840,t:1527016819905};\\\", \\\"{x:1609,y:839,t:1527016819918};\\\", \\\"{x:1609,y:838,t:1527016819935};\\\", \\\"{x:1609,y:837,t:1527016819952};\\\", \\\"{x:1609,y:836,t:1527016819969};\\\", \\\"{x:1609,y:835,t:1527016819985};\\\", \\\"{x:1609,y:834,t:1527016820289};\\\", \\\"{x:1608,y:833,t:1527016820385};\\\", \\\"{x:1596,y:833,t:1527016820402};\\\", \\\"{x:1561,y:834,t:1527016820419};\\\", \\\"{x:1474,y:838,t:1527016820435};\\\", \\\"{x:1406,y:840,t:1527016820452};\\\", \\\"{x:1294,y:835,t:1527016820469};\\\", \\\"{x:1225,y:830,t:1527016820485};\\\", \\\"{x:1173,y:818,t:1527016820502};\\\", \\\"{x:1153,y:812,t:1527016820518};\\\", \\\"{x:1101,y:793,t:1527016820534};\\\", \\\"{x:1074,y:781,t:1527016820552};\\\", \\\"{x:1058,y:771,t:1527016820569};\\\", \\\"{x:1055,y:770,t:1527016820585};\\\", \\\"{x:1044,y:767,t:1527016820602};\\\", \\\"{x:1027,y:761,t:1527016820619};\\\", \\\"{x:1011,y:752,t:1527016820635};\\\", \\\"{x:984,y:738,t:1527016820651};\\\", \\\"{x:961,y:727,t:1527016820669};\\\", \\\"{x:907,y:700,t:1527016820685};\\\", \\\"{x:857,y:680,t:1527016820702};\\\", \\\"{x:838,y:667,t:1527016820719};\\\", \\\"{x:836,y:665,t:1527016820734};\\\", \\\"{x:836,y:664,t:1527016820752};\\\", \\\"{x:836,y:661,t:1527016820777};\\\", \\\"{x:836,y:659,t:1527016820793};\\\", \\\"{x:835,y:655,t:1527016820802};\\\", \\\"{x:832,y:641,t:1527016820819};\\\", \\\"{x:823,y:620,t:1527016820836};\\\", \\\"{x:797,y:592,t:1527016820852};\\\", \\\"{x:764,y:556,t:1527016820868};\\\", \\\"{x:716,y:517,t:1527016820888};\\\", \\\"{x:682,y:499,t:1527016820903};\\\", \\\"{x:643,y:470,t:1527016820920};\\\", \\\"{x:635,y:467,t:1527016820937};\\\", \\\"{x:633,y:467,t:1527016820953};\\\", \\\"{x:629,y:467,t:1527016820970};\\\", \\\"{x:626,y:467,t:1527016820987};\\\", \\\"{x:618,y:468,t:1527016821003};\\\", \\\"{x:612,y:480,t:1527016821020};\\\", \\\"{x:611,y:482,t:1527016821037};\\\", \\\"{x:607,y:494,t:1527016821054};\\\", \\\"{x:604,y:501,t:1527016821070};\\\", \\\"{x:602,y:505,t:1527016821087};\\\", \\\"{x:602,y:509,t:1527016821103};\\\", \\\"{x:607,y:524,t:1527016821121};\\\", \\\"{x:613,y:531,t:1527016821137};\\\", \\\"{x:614,y:534,t:1527016821155};\\\", \\\"{x:615,y:535,t:1527016821171};\\\", \\\"{x:618,y:538,t:1527016821187};\\\", \\\"{x:621,y:541,t:1527016821205};\\\", \\\"{x:624,y:545,t:1527016821222};\\\", \\\"{x:624,y:546,t:1527016821238};\\\", \\\"{x:625,y:552,t:1527016821254};\\\", \\\"{x:625,y:556,t:1527016821272};\\\", \\\"{x:625,y:558,t:1527016821311};\\\", \\\"{x:624,y:558,t:1527016821321};\\\", \\\"{x:624,y:559,t:1527016821344};\\\", \\\"{x:624,y:560,t:1527016821408};\\\", \\\"{x:624,y:561,t:1527016821424};\\\", \\\"{x:623,y:562,t:1527016821437};\\\", \\\"{x:621,y:563,t:1527016821455};\\\", \\\"{x:621,y:564,t:1527016821529};\\\", \\\"{x:621,y:566,t:1527016821545};\\\", \\\"{x:619,y:569,t:1527016821555};\\\", \\\"{x:618,y:573,t:1527016821571};\\\", \\\"{x:616,y:575,t:1527016821588};\\\", \\\"{x:615,y:576,t:1527016821632};\\\", \\\"{x:614,y:577,t:1527016821696};\\\", \\\"{x:615,y:586,t:1527016822161};\\\", \\\"{x:642,y:588,t:1527016822172};\\\", \\\"{x:744,y:602,t:1527016822190};\\\", \\\"{x:841,y:615,t:1527016822205};\\\", \\\"{x:964,y:638,t:1527016822222};\\\", \\\"{x:1102,y:671,t:1527016822239};\\\", \\\"{x:1242,y:703,t:1527016822255};\\\", \\\"{x:1379,y:733,t:1527016822271};\\\", \\\"{x:1576,y:778,t:1527016822287};\\\", \\\"{x:1703,y:809,t:1527016822305};\\\", \\\"{x:1776,y:833,t:1527016822321};\\\", \\\"{x:1794,y:841,t:1527016822338};\\\", \\\"{x:1799,y:842,t:1527016822356};\\\", \\\"{x:1797,y:842,t:1527016822440};\\\", \\\"{x:1796,y:842,t:1527016822490};\\\", \\\"{x:1794,y:842,t:1527016822505};\\\", \\\"{x:1792,y:842,t:1527016822522};\\\", \\\"{x:1776,y:836,t:1527016822539};\\\", \\\"{x:1766,y:833,t:1527016822555};\\\", \\\"{x:1759,y:833,t:1527016822572};\\\", \\\"{x:1740,y:832,t:1527016822589};\\\", \\\"{x:1728,y:832,t:1527016822606};\\\", \\\"{x:1703,y:832,t:1527016822622};\\\", \\\"{x:1688,y:832,t:1527016822638};\\\", \\\"{x:1673,y:831,t:1527016822655};\\\", \\\"{x:1670,y:830,t:1527016822671};\\\", \\\"{x:1669,y:827,t:1527016822688};\\\", \\\"{x:1669,y:826,t:1527016822705};\\\", \\\"{x:1669,y:825,t:1527016822722};\\\", \\\"{x:1669,y:823,t:1527016822768};\\\", \\\"{x:1669,y:818,t:1527016822776};\\\", \\\"{x:1663,y:811,t:1527016822788};\\\", \\\"{x:1648,y:795,t:1527016822805};\\\", \\\"{x:1635,y:783,t:1527016822823};\\\", \\\"{x:1622,y:772,t:1527016822839};\\\", \\\"{x:1610,y:761,t:1527016822855};\\\", \\\"{x:1588,y:748,t:1527016822873};\\\", \\\"{x:1568,y:740,t:1527016822889};\\\", \\\"{x:1555,y:736,t:1527016822906};\\\", \\\"{x:1537,y:732,t:1527016822922};\\\", \\\"{x:1519,y:732,t:1527016822938};\\\", \\\"{x:1514,y:732,t:1527016822955};\\\", \\\"{x:1513,y:732,t:1527016822973};\\\", \\\"{x:1509,y:732,t:1527016822989};\\\", \\\"{x:1505,y:735,t:1527016823006};\\\", \\\"{x:1502,y:739,t:1527016823023};\\\", \\\"{x:1502,y:742,t:1527016823039};\\\", \\\"{x:1505,y:749,t:1527016823056};\\\", \\\"{x:1516,y:762,t:1527016823073};\\\", \\\"{x:1523,y:770,t:1527016823089};\\\", \\\"{x:1532,y:773,t:1527016823105};\\\", \\\"{x:1538,y:780,t:1527016823123};\\\", \\\"{x:1546,y:781,t:1527016823140};\\\", \\\"{x:1554,y:784,t:1527016823156};\\\", \\\"{x:1562,y:787,t:1527016823173};\\\", \\\"{x:1567,y:789,t:1527016823190};\\\", \\\"{x:1570,y:791,t:1527016823205};\\\", \\\"{x:1571,y:792,t:1527016823257};\\\", \\\"{x:1571,y:793,t:1527016823305};\\\", \\\"{x:1568,y:794,t:1527016823323};\\\", \\\"{x:1567,y:796,t:1527016823340};\\\", \\\"{x:1566,y:796,t:1527016823356};\\\", \\\"{x:1565,y:799,t:1527016823372};\\\", \\\"{x:1549,y:807,t:1527016823390};\\\", \\\"{x:1531,y:817,t:1527016823406};\\\", \\\"{x:1511,y:831,t:1527016823423};\\\", \\\"{x:1501,y:841,t:1527016823440};\\\", \\\"{x:1477,y:857,t:1527016823456};\\\", \\\"{x:1440,y:881,t:1527016823473};\\\", \\\"{x:1422,y:893,t:1527016823490};\\\", \\\"{x:1415,y:898,t:1527016823506};\\\", \\\"{x:1414,y:900,t:1527016823523};\\\", \\\"{x:1414,y:895,t:1527016823866};\\\", \\\"{x:1416,y:890,t:1527016823872};\\\", \\\"{x:1434,y:858,t:1527016823890};\\\", \\\"{x:1447,y:837,t:1527016823907};\\\", \\\"{x:1451,y:830,t:1527016823924};\\\", \\\"{x:1458,y:819,t:1527016823940};\\\", \\\"{x:1468,y:807,t:1527016823956};\\\", \\\"{x:1478,y:791,t:1527016823974};\\\", \\\"{x:1488,y:777,t:1527016823990};\\\", \\\"{x:1493,y:769,t:1527016824006};\\\", \\\"{x:1497,y:762,t:1527016824024};\\\", \\\"{x:1500,y:760,t:1527016824040};\\\", \\\"{x:1503,y:754,t:1527016824057};\\\", \\\"{x:1503,y:751,t:1527016824073};\\\", \\\"{x:1503,y:746,t:1527016824090};\\\", \\\"{x:1503,y:744,t:1527016824107};\\\", \\\"{x:1497,y:741,t:1527016824123};\\\", \\\"{x:1486,y:732,t:1527016824140};\\\", \\\"{x:1470,y:728,t:1527016824157};\\\", \\\"{x:1448,y:726,t:1527016824173};\\\", \\\"{x:1432,y:724,t:1527016824189};\\\", \\\"{x:1415,y:724,t:1527016824206};\\\", \\\"{x:1397,y:729,t:1527016824224};\\\", \\\"{x:1386,y:734,t:1527016824239};\\\", \\\"{x:1364,y:744,t:1527016824257};\\\", \\\"{x:1351,y:748,t:1527016824274};\\\", \\\"{x:1343,y:750,t:1527016824291};\\\", \\\"{x:1339,y:750,t:1527016824307};\\\", \\\"{x:1341,y:749,t:1527016825178};\\\", \\\"{x:1344,y:748,t:1527016825191};\\\", \\\"{x:1347,y:746,t:1527016825207};\\\", \\\"{x:1351,y:744,t:1527016825225};\\\", \\\"{x:1352,y:743,t:1527016825241};\\\", \\\"{x:1352,y:742,t:1527016825281};\\\", \\\"{x:1352,y:741,t:1527016825297};\\\", \\\"{x:1352,y:740,t:1527016825308};\\\", \\\"{x:1352,y:739,t:1527016825324};\\\", \\\"{x:1352,y:737,t:1527016825344};\\\", \\\"{x:1354,y:735,t:1527016825362};\\\", \\\"{x:1355,y:734,t:1527016825373};\\\", \\\"{x:1355,y:733,t:1527016825391};\\\", \\\"{x:1355,y:729,t:1527016825407};\\\", \\\"{x:1356,y:727,t:1527016825424};\\\", \\\"{x:1358,y:723,t:1527016825440};\\\", \\\"{x:1359,y:719,t:1527016825458};\\\", \\\"{x:1360,y:714,t:1527016825476};\\\", \\\"{x:1362,y:707,t:1527016825491};\\\", \\\"{x:1362,y:703,t:1527016825508};\\\", \\\"{x:1362,y:700,t:1527016825525};\\\", \\\"{x:1362,y:696,t:1527016825542};\\\", \\\"{x:1362,y:694,t:1527016825558};\\\", \\\"{x:1361,y:693,t:1527016825574};\\\", \\\"{x:1360,y:693,t:1527016825826};\\\", \\\"{x:1359,y:693,t:1527016825841};\\\", \\\"{x:1360,y:693,t:1527016826001};\\\", \\\"{x:1364,y:693,t:1527016826009};\\\", \\\"{x:1372,y:693,t:1527016826025};\\\", \\\"{x:1386,y:693,t:1527016826042};\\\", \\\"{x:1398,y:693,t:1527016826058};\\\", \\\"{x:1405,y:693,t:1527016826075};\\\", \\\"{x:1407,y:693,t:1527016826092};\\\", \\\"{x:1409,y:693,t:1527016826108};\\\", \\\"{x:1410,y:693,t:1527016826168};\\\", \\\"{x:1412,y:693,t:1527016826561};\\\", \\\"{x:1419,y:693,t:1527016826575};\\\", \\\"{x:1430,y:697,t:1527016826592};\\\", \\\"{x:1436,y:700,t:1527016826608};\\\", \\\"{x:1446,y:701,t:1527016826624};\\\", \\\"{x:1450,y:702,t:1527016826641};\\\", \\\"{x:1454,y:703,t:1527016826659};\\\", \\\"{x:1456,y:705,t:1527016826688};\\\", \\\"{x:1457,y:705,t:1527016826849};\\\", \\\"{x:1458,y:705,t:1527016826873};\\\", \\\"{x:1462,y:706,t:1527016826880};\\\", \\\"{x:1465,y:706,t:1527016826892};\\\", \\\"{x:1468,y:707,t:1527016826908};\\\", \\\"{x:1469,y:707,t:1527016826926};\\\", \\\"{x:1470,y:707,t:1527016827057};\\\", \\\"{x:1471,y:707,t:1527016827153};\\\", \\\"{x:1474,y:707,t:1527016827176};\\\", \\\"{x:1477,y:707,t:1527016827192};\\\", \\\"{x:1492,y:704,t:1527016827209};\\\", \\\"{x:1495,y:700,t:1527016827226};\\\", \\\"{x:1506,y:694,t:1527016827242};\\\", \\\"{x:1517,y:693,t:1527016827259};\\\", \\\"{x:1522,y:692,t:1527016827276};\\\", \\\"{x:1525,y:692,t:1527016827292};\\\", \\\"{x:1526,y:692,t:1527016827309};\\\", \\\"{x:1530,y:692,t:1527016827489};\\\", \\\"{x:1539,y:692,t:1527016827496};\\\", \\\"{x:1551,y:692,t:1527016827509};\\\", \\\"{x:1579,y:697,t:1527016827526};\\\", \\\"{x:1596,y:702,t:1527016827543};\\\", \\\"{x:1598,y:703,t:1527016827559};\\\", \\\"{x:1604,y:707,t:1527016827576};\\\", \\\"{x:1606,y:707,t:1527016827593};\\\", \\\"{x:1606,y:708,t:1527016827608};\\\", \\\"{x:1607,y:709,t:1527016827633};\\\", \\\"{x:1607,y:710,t:1527016827793};\\\", \\\"{x:1607,y:712,t:1527016827810};\\\", \\\"{x:1599,y:713,t:1527016827827};\\\", \\\"{x:1595,y:713,t:1527016827843};\\\", \\\"{x:1566,y:714,t:1527016827860};\\\", \\\"{x:1547,y:715,t:1527016827876};\\\", \\\"{x:1513,y:719,t:1527016827893};\\\", \\\"{x:1479,y:720,t:1527016827910};\\\", \\\"{x:1454,y:721,t:1527016827926};\\\", \\\"{x:1441,y:722,t:1527016827943};\\\", \\\"{x:1441,y:721,t:1527016827969};\\\", \\\"{x:1436,y:720,t:1527016827977};\\\", \\\"{x:1424,y:720,t:1527016827993};\\\", \\\"{x:1408,y:720,t:1527016828010};\\\", \\\"{x:1405,y:720,t:1527016828026};\\\", \\\"{x:1400,y:720,t:1527016828043};\\\", \\\"{x:1391,y:720,t:1527016828060};\\\", \\\"{x:1388,y:719,t:1527016828077};\\\", \\\"{x:1385,y:717,t:1527016828093};\\\", \\\"{x:1379,y:715,t:1527016828110};\\\", \\\"{x:1369,y:715,t:1527016828126};\\\", \\\"{x:1355,y:712,t:1527016828143};\\\", \\\"{x:1343,y:711,t:1527016828161};\\\", \\\"{x:1340,y:711,t:1527016828176};\\\", \\\"{x:1335,y:710,t:1527016828193};\\\", \\\"{x:1261,y:696,t:1527016828211};\\\", \\\"{x:1185,y:684,t:1527016828227};\\\", \\\"{x:1093,y:668,t:1527016828243};\\\", \\\"{x:1019,y:650,t:1527016828260};\\\", \\\"{x:927,y:637,t:1527016828277};\\\", \\\"{x:859,y:631,t:1527016828294};\\\", \\\"{x:830,y:619,t:1527016828310};\\\", \\\"{x:755,y:609,t:1527016828327};\\\", \\\"{x:674,y:596,t:1527016828336};\\\", \\\"{x:601,y:582,t:1527016828353};\\\", \\\"{x:544,y:575,t:1527016828377};\\\", \\\"{x:537,y:574,t:1527016828393};\\\", \\\"{x:535,y:572,t:1527016828409};\\\", \\\"{x:534,y:571,t:1527016828426};\\\", \\\"{x:533,y:571,t:1527016828443};\\\", \\\"{x:536,y:568,t:1527016828609};\\\", \\\"{x:544,y:562,t:1527016828628};\\\", \\\"{x:545,y:562,t:1527016828643};\\\", \\\"{x:548,y:561,t:1527016828660};\\\", \\\"{x:549,y:561,t:1527016828729};\\\", \\\"{x:550,y:560,t:1527016828743};\\\", \\\"{x:551,y:559,t:1527016828945};\\\", \\\"{x:548,y:559,t:1527016828960};\\\", \\\"{x:538,y:558,t:1527016828976};\\\", \\\"{x:527,y:558,t:1527016828993};\\\", \\\"{x:512,y:558,t:1527016829010};\\\", \\\"{x:502,y:558,t:1527016829026};\\\", \\\"{x:494,y:559,t:1527016829042};\\\", \\\"{x:493,y:559,t:1527016829065};\\\", \\\"{x:492,y:559,t:1527016829075};\\\", \\\"{x:488,y:562,t:1527016829093};\\\", \\\"{x:483,y:562,t:1527016829110};\\\", \\\"{x:479,y:563,t:1527016829127};\\\", \\\"{x:476,y:564,t:1527016829143};\\\", \\\"{x:470,y:565,t:1527016829160};\\\", \\\"{x:462,y:565,t:1527016829178};\\\", \\\"{x:460,y:565,t:1527016829194};\\\", \\\"{x:453,y:565,t:1527016829211};\\\", \\\"{x:446,y:564,t:1527016829228};\\\", \\\"{x:437,y:563,t:1527016829244};\\\", \\\"{x:418,y:563,t:1527016829261};\\\", \\\"{x:400,y:562,t:1527016829279};\\\", \\\"{x:378,y:558,t:1527016829294};\\\", \\\"{x:365,y:556,t:1527016829313};\\\", \\\"{x:358,y:556,t:1527016829328};\\\", \\\"{x:344,y:552,t:1527016829345};\\\", \\\"{x:334,y:548,t:1527016829360};\\\", \\\"{x:332,y:547,t:1527016829378};\\\", \\\"{x:329,y:545,t:1527016829393};\\\", \\\"{x:327,y:544,t:1527016829410};\\\", \\\"{x:323,y:543,t:1527016829427};\\\", \\\"{x:320,y:541,t:1527016829444};\\\", \\\"{x:320,y:539,t:1527016829537};\\\", \\\"{x:320,y:538,t:1527016829544};\\\", \\\"{x:322,y:536,t:1527016829560};\\\", \\\"{x:324,y:536,t:1527016829592};\\\", \\\"{x:325,y:536,t:1527016829608};\\\", \\\"{x:326,y:536,t:1527016829616};\\\", \\\"{x:329,y:536,t:1527016829627};\\\", \\\"{x:338,y:528,t:1527016829645};\\\", \\\"{x:346,y:525,t:1527016829661};\\\", \\\"{x:350,y:524,t:1527016829679};\\\", \\\"{x:351,y:524,t:1527016829694};\\\", \\\"{x:351,y:523,t:1527016829727};\\\", \\\"{x:353,y:522,t:1527016829744};\\\", \\\"{x:354,y:521,t:1527016829761};\\\", \\\"{x:355,y:521,t:1527016829778};\\\", \\\"{x:356,y:520,t:1527016829793};\\\", \\\"{x:358,y:519,t:1527016829832};\\\", \\\"{x:358,y:518,t:1527016829844};\\\", \\\"{x:364,y:514,t:1527016829862};\\\", \\\"{x:372,y:511,t:1527016829877};\\\", \\\"{x:378,y:509,t:1527016829894};\\\", \\\"{x:385,y:505,t:1527016829911};\\\", \\\"{x:396,y:501,t:1527016829927};\\\", \\\"{x:420,y:496,t:1527016829944};\\\", \\\"{x:429,y:494,t:1527016829960};\\\", \\\"{x:430,y:494,t:1527016829978};\\\", \\\"{x:431,y:494,t:1527016830137};\\\", \\\"{x:432,y:492,t:1527016830153};\\\", \\\"{x:436,y:492,t:1527016830297};\\\", \\\"{x:444,y:492,t:1527016830313};\\\", \\\"{x:446,y:492,t:1527016830329};\\\", \\\"{x:455,y:494,t:1527016830345};\\\", \\\"{x:462,y:494,t:1527016830363};\\\", \\\"{x:475,y:494,t:1527016830379};\\\", \\\"{x:476,y:494,t:1527016830396};\\\", \\\"{x:477,y:494,t:1527016830413};\\\", \\\"{x:475,y:494,t:1527016830497};\\\", \\\"{x:460,y:494,t:1527016830512};\\\", \\\"{x:438,y:494,t:1527016830530};\\\", \\\"{x:416,y:494,t:1527016830546};\\\", \\\"{x:405,y:492,t:1527016830564};\\\", \\\"{x:387,y:492,t:1527016830580};\\\", \\\"{x:385,y:492,t:1527016830594};\\\", \\\"{x:371,y:492,t:1527016830612};\\\", \\\"{x:362,y:497,t:1527016830628};\\\", \\\"{x:361,y:502,t:1527016830645};\\\", \\\"{x:347,y:510,t:1527016830661};\\\", \\\"{x:337,y:515,t:1527016830678};\\\", \\\"{x:331,y:520,t:1527016830695};\\\", \\\"{x:326,y:523,t:1527016830711};\\\", \\\"{x:316,y:531,t:1527016830728};\\\", \\\"{x:310,y:538,t:1527016830744};\\\", \\\"{x:305,y:541,t:1527016830762};\\\", \\\"{x:295,y:552,t:1527016830778};\\\", \\\"{x:281,y:560,t:1527016830795};\\\", \\\"{x:261,y:577,t:1527016830812};\\\", \\\"{x:246,y:591,t:1527016830828};\\\", \\\"{x:218,y:610,t:1527016830847};\\\", \\\"{x:206,y:619,t:1527016830861};\\\", \\\"{x:185,y:624,t:1527016830879};\\\", \\\"{x:177,y:633,t:1527016830896};\\\", \\\"{x:168,y:641,t:1527016830912};\\\", \\\"{x:166,y:644,t:1527016830929};\\\", \\\"{x:167,y:644,t:1527016831089};\\\", \\\"{x:170,y:642,t:1527016831185};\\\", \\\"{x:180,y:641,t:1527016831197};\\\", \\\"{x:202,y:636,t:1527016831213};\\\", \\\"{x:227,y:634,t:1527016831229};\\\", \\\"{x:277,y:630,t:1527016831246};\\\", \\\"{x:361,y:628,t:1527016831263};\\\", \\\"{x:448,y:626,t:1527016831278};\\\", \\\"{x:484,y:626,t:1527016831295};\\\", \\\"{x:507,y:628,t:1527016831313};\\\", \\\"{x:520,y:631,t:1527016831328};\\\", \\\"{x:530,y:631,t:1527016831345};\\\", \\\"{x:532,y:631,t:1527016831363};\\\", \\\"{x:534,y:630,t:1527016831496};\\\", \\\"{x:537,y:626,t:1527016831512};\\\", \\\"{x:548,y:623,t:1527016831528};\\\", \\\"{x:568,y:620,t:1527016831545};\\\", \\\"{x:586,y:614,t:1527016831563};\\\", \\\"{x:599,y:613,t:1527016831579};\\\", \\\"{x:607,y:612,t:1527016831596};\\\", \\\"{x:609,y:611,t:1527016831612};\\\", \\\"{x:610,y:611,t:1527016831629};\\\", \\\"{x:610,y:612,t:1527016831689};\\\", \\\"{x:609,y:612,t:1527016831696};\\\", \\\"{x:610,y:612,t:1527016831921};\\\", \\\"{x:614,y:609,t:1527016831930};\\\", \\\"{x:632,y:599,t:1527016831947};\\\", \\\"{x:659,y:587,t:1527016831963};\\\", \\\"{x:673,y:578,t:1527016831980};\\\", \\\"{x:681,y:574,t:1527016831996};\\\", \\\"{x:705,y:562,t:1527016832013};\\\", \\\"{x:709,y:561,t:1527016832030};\\\", \\\"{x:721,y:559,t:1527016832046};\\\", \\\"{x:730,y:559,t:1527016832063};\\\", \\\"{x:736,y:559,t:1527016832079};\\\", \\\"{x:738,y:558,t:1527016832096};\\\", \\\"{x:740,y:557,t:1527016832112};\\\", \\\"{x:742,y:554,t:1527016832132};\\\", \\\"{x:744,y:554,t:1527016832147};\\\", \\\"{x:745,y:553,t:1527016832168};\\\", \\\"{x:746,y:553,t:1527016832179};\\\", \\\"{x:749,y:551,t:1527016832196};\\\", \\\"{x:754,y:549,t:1527016832213};\\\", \\\"{x:760,y:546,t:1527016832229};\\\", \\\"{x:767,y:541,t:1527016832246};\\\", \\\"{x:776,y:537,t:1527016832262};\\\", \\\"{x:787,y:530,t:1527016832280};\\\", \\\"{x:801,y:524,t:1527016832296};\\\", \\\"{x:804,y:522,t:1527016832313};\\\", \\\"{x:807,y:519,t:1527016832330};\\\", \\\"{x:810,y:517,t:1527016832348};\\\", \\\"{x:811,y:516,t:1527016832363};\\\", \\\"{x:811,y:515,t:1527016832432};\\\", \\\"{x:812,y:515,t:1527016832521};\\\", \\\"{x:816,y:513,t:1527016832530};\\\", \\\"{x:822,y:512,t:1527016832547};\\\", \\\"{x:827,y:509,t:1527016832564};\\\", \\\"{x:832,y:507,t:1527016832580};\\\", \\\"{x:837,y:505,t:1527016832597};\\\", \\\"{x:841,y:503,t:1527016832614};\\\", \\\"{x:842,y:503,t:1527016832629};\\\", \\\"{x:846,y:507,t:1527016833072};\\\", \\\"{x:846,y:509,t:1527016833080};\\\", \\\"{x:846,y:523,t:1527016833098};\\\", \\\"{x:846,y:533,t:1527016833114};\\\", \\\"{x:846,y:544,t:1527016833130};\\\", \\\"{x:846,y:547,t:1527016833146};\\\", \\\"{x:848,y:547,t:1527016833164};\\\", \\\"{x:848,y:548,t:1527016833256};\\\", \\\"{x:848,y:549,t:1527016833272};\\\", \\\"{x:848,y:551,t:1527016833296};\\\", \\\"{x:848,y:552,t:1527016833319};\\\", \\\"{x:848,y:554,t:1527016833330};\\\", \\\"{x:848,y:556,t:1527016833353};\\\", \\\"{x:847,y:559,t:1527016833364};\\\", \\\"{x:846,y:560,t:1527016833401};\\\", \\\"{x:845,y:561,t:1527016833414};\\\", \\\"{x:844,y:561,t:1527016836121};\\\", \\\"{x:844,y:560,t:1527016836408};\\\", \\\"{x:843,y:560,t:1527016836705};\\\", \\\"{x:842,y:560,t:1527016836768};\\\", \\\"{x:842,y:557,t:1527016836784};\\\", \\\"{x:842,y:555,t:1527016836802};\\\", \\\"{x:839,y:550,t:1527016836817};\\\", \\\"{x:839,y:548,t:1527016836833};\\\", \\\"{x:839,y:546,t:1527016836850};\\\", \\\"{x:839,y:545,t:1527016836867};\\\", \\\"{x:837,y:542,t:1527016836882};\\\", \\\"{x:837,y:541,t:1527016836899};\\\", \\\"{x:837,y:540,t:1527016836917};\\\", \\\"{x:837,y:539,t:1527016836932};\\\", \\\"{x:837,y:538,t:1527016837024};\\\", \\\"{x:836,y:537,t:1527016838401};\\\", \\\"{x:836,y:536,t:1527016838809};\\\", \\\"{x:836,y:535,t:1527016838818};\\\", \\\"{x:836,y:533,t:1527016838836};\\\", \\\"{x:836,y:532,t:1527016838851};\\\", \\\"{x:836,y:531,t:1527016838872};\\\", \\\"{x:836,y:530,t:1527016840321};\\\", \\\"{x:819,y:530,t:1527016840336};\\\", \\\"{x:790,y:542,t:1527016840353};\\\", \\\"{x:783,y:548,t:1527016840369};\\\", \\\"{x:781,y:553,t:1527016840386};\\\", \\\"{x:781,y:554,t:1527016840403};\\\", \\\"{x:779,y:555,t:1527016840480};\\\", \\\"{x:776,y:557,t:1527016840488};\\\", \\\"{x:773,y:561,t:1527016840502};\\\", \\\"{x:758,y:569,t:1527016840520};\\\", \\\"{x:748,y:573,t:1527016840536};\\\", \\\"{x:747,y:574,t:1527016840553};\\\", \\\"{x:741,y:577,t:1527016840568};\\\", \\\"{x:739,y:578,t:1527016840586};\\\", \\\"{x:738,y:580,t:1527016840603};\\\", \\\"{x:736,y:582,t:1527016840631};\\\", \\\"{x:733,y:586,t:1527016840640};\\\", \\\"{x:732,y:587,t:1527016840653};\\\", \\\"{x:726,y:598,t:1527016840671};\\\", \\\"{x:722,y:607,t:1527016840686};\\\", \\\"{x:721,y:609,t:1527016840702};\\\", \\\"{x:721,y:610,t:1527016840720};\\\", \\\"{x:720,y:610,t:1527016841625};\\\", \\\"{x:718,y:610,t:1527016841640};\\\", \\\"{x:718,y:611,t:1527016841656};\\\", \\\"{x:716,y:615,t:1527016841671};\\\", \\\"{x:703,y:630,t:1527016841688};\\\", \\\"{x:692,y:643,t:1527016841706};\\\", \\\"{x:683,y:661,t:1527016841720};\\\", \\\"{x:677,y:668,t:1527016841735};\\\", \\\"{x:672,y:677,t:1527016841750};\\\", \\\"{x:669,y:684,t:1527016841767};\\\", \\\"{x:665,y:688,t:1527016841785};\\\", \\\"{x:665,y:689,t:1527016841840};\\\", \\\"{x:663,y:689,t:1527016843384};\\\", \\\"{x:657,y:691,t:1527016843399};\\\", \\\"{x:655,y:693,t:1527016843415};\\\", \\\"{x:651,y:695,t:1527016843432};\\\", \\\"{x:648,y:697,t:1527016843448};\\\", \\\"{x:645,y:698,t:1527016843465};\\\", \\\"{x:642,y:701,t:1527016843482};\\\", \\\"{x:639,y:703,t:1527016843498};\\\", \\\"{x:638,y:704,t:1527016843515};\\\", \\\"{x:634,y:707,t:1527016843533};\\\", \\\"{x:629,y:711,t:1527016843548};\\\", \\\"{x:617,y:718,t:1527016843565};\\\", \\\"{x:605,y:727,t:1527016843582};\\\", \\\"{x:593,y:731,t:1527016843598};\\\", \\\"{x:587,y:732,t:1527016843616};\\\", \\\"{x:583,y:737,t:1527016843632};\\\", \\\"{x:573,y:741,t:1527016843648};\\\", \\\"{x:571,y:743,t:1527016843665};\\\", \\\"{x:569,y:745,t:1527016843688};\\\", \\\"{x:568,y:745,t:1527016843704};\\\", \\\"{x:566,y:745,t:1527016843728};\\\", \\\"{x:565,y:745,t:1527016843745};\\\", \\\"{x:564,y:746,t:1527016843753};\\\", \\\"{x:562,y:746,t:1527016843765};\\\", \\\"{x:559,y:746,t:1527016843781};\\\", \\\"{x:553,y:745,t:1527016843804};\\\", \\\"{x:552,y:744,t:1527016843822};\\\", \\\"{x:551,y:744,t:1527016843839};\\\", \\\"{x:549,y:744,t:1527016843855};\\\", \\\"{x:549,y:743,t:1527016844104};\\\" ] }, { \\\"rt\\\": 47743, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 18, \\\"time_elapsed\\\": 932989, \\\"internal_node_id\\\": \\\"0.0-6.0-8.0\\\", \\\"subject\\\": \\\"6Y93F\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"foxtrot\\\", \\\"condition\\\": \\\"111\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"endtime\\\", \\\"q\\\": 14, \\\"clicks\\\": 1, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XInside-YFull\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 1, \\\"answer\\\": [ \\\"B\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-G -B \\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:549,y:742,t:1527016847665};\\\", \\\"{x:550,y:742,t:1527016847675};\\\", \\\"{x:551,y:742,t:1527016847692};\\\", \\\"{x:559,y:736,t:1527016847708};\\\", \\\"{x:561,y:733,t:1527016847725};\\\", \\\"{x:566,y:729,t:1527016847743};\\\", \\\"{x:577,y:720,t:1527016847758};\\\", \\\"{x:587,y:712,t:1527016847775};\\\", \\\"{x:597,y:706,t:1527016847792};\\\", \\\"{x:600,y:705,t:1527016847808};\\\", \\\"{x:603,y:703,t:1527016847826};\\\", \\\"{x:604,y:701,t:1527016848232};\\\", \\\"{x:606,y:700,t:1527016848242};\\\", \\\"{x:610,y:694,t:1527016848260};\\\", \\\"{x:614,y:690,t:1527016848275};\\\", \\\"{x:617,y:687,t:1527016848293};\\\", \\\"{x:619,y:685,t:1527016848309};\\\", \\\"{x:620,y:685,t:1527016848325};\\\", \\\"{x:621,y:684,t:1527016848344};\\\", \\\"{x:622,y:684,t:1527016848409};\\\", \\\"{x:623,y:683,t:1527016848440};\\\", \\\"{x:626,y:682,t:1527016848481};\\\", \\\"{x:627,y:681,t:1527016848528};\\\", \\\"{x:628,y:681,t:1527016848543};\\\", \\\"{x:629,y:681,t:1527016851048};\\\", \\\"{x:633,y:678,t:1527016851080};\\\", \\\"{x:636,y:677,t:1527016851104};\\\", \\\"{x:640,y:676,t:1527016851112};\\\", \\\"{x:641,y:674,t:1527016851128};\\\", \\\"{x:644,y:672,t:1527016851144};\\\", \\\"{x:649,y:668,t:1527016851162};\\\", \\\"{x:658,y:666,t:1527016851179};\\\", \\\"{x:664,y:662,t:1527016851195};\\\", \\\"{x:668,y:662,t:1527016851211};\\\", \\\"{x:673,y:658,t:1527016851228};\\\", \\\"{x:681,y:657,t:1527016851245};\\\", \\\"{x:689,y:656,t:1527016851262};\\\", \\\"{x:693,y:654,t:1527016851278};\\\", \\\"{x:697,y:654,t:1527016851295};\\\", \\\"{x:703,y:653,t:1527016851311};\\\", \\\"{x:711,y:653,t:1527016851328};\\\", \\\"{x:713,y:653,t:1527016851344};\\\", \\\"{x:721,y:653,t:1527016851362};\\\", \\\"{x:738,y:653,t:1527016851378};\\\", \\\"{x:750,y:657,t:1527016851396};\\\", \\\"{x:766,y:661,t:1527016851412};\\\", \\\"{x:785,y:666,t:1527016851428};\\\", \\\"{x:800,y:668,t:1527016851445};\\\", \\\"{x:822,y:670,t:1527016851461};\\\", \\\"{x:833,y:670,t:1527016851478};\\\", \\\"{x:845,y:670,t:1527016851496};\\\", \\\"{x:859,y:670,t:1527016851512};\\\", \\\"{x:870,y:670,t:1527016851529};\\\", \\\"{x:879,y:670,t:1527016851545};\\\", \\\"{x:884,y:670,t:1527016851562};\\\", \\\"{x:897,y:664,t:1527016851579};\\\", \\\"{x:915,y:663,t:1527016851596};\\\", \\\"{x:928,y:663,t:1527016851611};\\\", \\\"{x:934,y:663,t:1527016851629};\\\", \\\"{x:951,y:666,t:1527016851646};\\\", \\\"{x:962,y:666,t:1527016851661};\\\", \\\"{x:978,y:667,t:1527016851678};\\\", \\\"{x:1001,y:671,t:1527016851697};\\\", \\\"{x:1015,y:670,t:1527016851713};\\\", \\\"{x:1037,y:669,t:1527016851729};\\\", \\\"{x:1056,y:669,t:1527016851746};\\\", \\\"{x:1073,y:667,t:1527016851762};\\\", \\\"{x:1081,y:666,t:1527016851779};\\\", \\\"{x:1090,y:665,t:1527016851796};\\\", \\\"{x:1096,y:664,t:1527016851813};\\\", \\\"{x:1108,y:664,t:1527016851829};\\\", \\\"{x:1123,y:664,t:1527016851846};\\\", \\\"{x:1133,y:664,t:1527016851862};\\\", \\\"{x:1147,y:661,t:1527016851878};\\\", \\\"{x:1171,y:661,t:1527016851897};\\\", \\\"{x:1183,y:658,t:1527016851912};\\\", \\\"{x:1220,y:656,t:1527016851929};\\\", \\\"{x:1228,y:654,t:1527016851946};\\\", \\\"{x:1265,y:654,t:1527016851962};\\\", \\\"{x:1291,y:651,t:1527016851978};\\\", \\\"{x:1313,y:645,t:1527016851996};\\\", \\\"{x:1315,y:642,t:1527016852013};\\\", \\\"{x:1323,y:642,t:1527016852028};\\\", \\\"{x:1326,y:641,t:1527016852046};\\\", \\\"{x:1332,y:641,t:1527016852063};\\\", \\\"{x:1333,y:641,t:1527016852079};\\\", \\\"{x:1339,y:641,t:1527016852096};\\\", \\\"{x:1340,y:641,t:1527016852112};\\\", \\\"{x:1341,y:642,t:1527016852128};\\\", \\\"{x:1343,y:643,t:1527016852160};\\\", \\\"{x:1345,y:646,t:1527016852176};\\\", \\\"{x:1346,y:647,t:1527016852200};\\\", \\\"{x:1349,y:649,t:1527016852212};\\\", \\\"{x:1350,y:650,t:1527016852229};\\\", \\\"{x:1352,y:656,t:1527016852246};\\\", \\\"{x:1357,y:663,t:1527016852263};\\\", \\\"{x:1370,y:675,t:1527016852280};\\\", \\\"{x:1378,y:689,t:1527016852296};\\\", \\\"{x:1384,y:698,t:1527016852312};\\\", \\\"{x:1390,y:710,t:1527016852330};\\\", \\\"{x:1393,y:723,t:1527016852346};\\\", \\\"{x:1394,y:739,t:1527016852363};\\\", \\\"{x:1394,y:751,t:1527016852380};\\\", \\\"{x:1394,y:755,t:1527016852396};\\\", \\\"{x:1391,y:765,t:1527016852412};\\\", \\\"{x:1382,y:774,t:1527016852429};\\\", \\\"{x:1369,y:784,t:1527016852446};\\\", \\\"{x:1366,y:784,t:1527016852462};\\\", \\\"{x:1364,y:784,t:1527016852479};\\\", \\\"{x:1364,y:785,t:1527016852917};\\\", \\\"{x:1364,y:788,t:1527016852957};\\\", \\\"{x:1364,y:791,t:1527016852972};\\\", \\\"{x:1365,y:794,t:1527016852984};\\\", \\\"{x:1368,y:800,t:1527016853002};\\\", \\\"{x:1371,y:804,t:1527016853017};\\\", \\\"{x:1374,y:807,t:1527016853034};\\\", \\\"{x:1380,y:810,t:1527016853051};\\\", \\\"{x:1389,y:815,t:1527016853067};\\\", \\\"{x:1408,y:827,t:1527016853084};\\\", \\\"{x:1423,y:836,t:1527016853101};\\\", \\\"{x:1437,y:848,t:1527016853119};\\\", \\\"{x:1452,y:857,t:1527016853134};\\\", \\\"{x:1468,y:863,t:1527016853151};\\\", \\\"{x:1473,y:867,t:1527016853168};\\\", \\\"{x:1474,y:869,t:1527016853581};\\\", \\\"{x:1475,y:870,t:1527016853597};\\\", \\\"{x:1477,y:872,t:1527016853604};\\\", \\\"{x:1481,y:874,t:1527016853618};\\\", \\\"{x:1492,y:876,t:1527016853635};\\\", \\\"{x:1498,y:878,t:1527016853651};\\\", \\\"{x:1516,y:886,t:1527016853668};\\\", \\\"{x:1532,y:894,t:1527016853685};\\\", \\\"{x:1536,y:898,t:1527016853701};\\\", \\\"{x:1548,y:904,t:1527016853718};\\\", \\\"{x:1551,y:905,t:1527016853735};\\\", \\\"{x:1554,y:911,t:1527016853757};\\\", \\\"{x:1555,y:913,t:1527016853768};\\\", \\\"{x:1555,y:919,t:1527016853785};\\\", \\\"{x:1555,y:922,t:1527016853801};\\\", \\\"{x:1555,y:926,t:1527016853818};\\\", \\\"{x:1554,y:931,t:1527016853835};\\\", \\\"{x:1554,y:930,t:1527016853989};\\\", \\\"{x:1555,y:927,t:1527016854004};\\\", \\\"{x:1555,y:926,t:1527016854018};\\\", \\\"{x:1555,y:924,t:1527016854035};\\\", \\\"{x:1555,y:913,t:1527016854053};\\\", \\\"{x:1555,y:909,t:1527016854069};\\\", \\\"{x:1555,y:906,t:1527016854085};\\\", \\\"{x:1554,y:905,t:1527016854101};\\\", \\\"{x:1554,y:903,t:1527016854118};\\\", \\\"{x:1553,y:899,t:1527016854135};\\\", \\\"{x:1553,y:895,t:1527016854152};\\\", \\\"{x:1553,y:893,t:1527016854168};\\\", \\\"{x:1553,y:888,t:1527016854185};\\\", \\\"{x:1553,y:880,t:1527016854203};\\\", \\\"{x:1555,y:874,t:1527016854218};\\\", \\\"{x:1555,y:867,t:1527016854235};\\\", \\\"{x:1556,y:858,t:1527016854252};\\\", \\\"{x:1558,y:853,t:1527016854268};\\\", \\\"{x:1558,y:846,t:1527016854285};\\\", \\\"{x:1558,y:840,t:1527016854302};\\\", \\\"{x:1558,y:839,t:1527016854380};\\\", \\\"{x:1558,y:838,t:1527016854413};\\\", \\\"{x:1558,y:837,t:1527016854420};\\\", \\\"{x:1558,y:836,t:1527016854437};\\\", \\\"{x:1557,y:836,t:1527016854533};\\\", \\\"{x:1556,y:836,t:1527016854573};\\\", \\\"{x:1556,y:835,t:1527016855085};\\\", \\\"{x:1555,y:834,t:1527016855102};\\\", \\\"{x:1555,y:835,t:1527016855332};\\\", \\\"{x:1555,y:838,t:1527016855340};\\\", \\\"{x:1555,y:841,t:1527016855353};\\\", \\\"{x:1555,y:846,t:1527016855369};\\\", \\\"{x:1555,y:850,t:1527016855386};\\\", \\\"{x:1555,y:854,t:1527016855402};\\\", \\\"{x:1555,y:855,t:1527016855685};\\\", \\\"{x:1554,y:855,t:1527016855716};\\\", \\\"{x:1552,y:855,t:1527016855811};\\\", \\\"{x:1552,y:853,t:1527016855819};\\\", \\\"{x:1550,y:848,t:1527016855836};\\\", \\\"{x:1549,y:842,t:1527016855852};\\\", \\\"{x:1547,y:834,t:1527016855869};\\\", \\\"{x:1547,y:832,t:1527016855886};\\\", \\\"{x:1545,y:826,t:1527016855903};\\\", \\\"{x:1544,y:826,t:1527016855932};\\\", \\\"{x:1543,y:825,t:1527016855964};\\\", \\\"{x:1543,y:827,t:1527016856188};\\\", \\\"{x:1542,y:828,t:1527016856203};\\\", \\\"{x:1541,y:828,t:1527016856460};\\\", \\\"{x:1540,y:827,t:1527016856476};\\\", \\\"{x:1539,y:826,t:1527016856491};\\\", \\\"{x:1538,y:824,t:1527016856523};\\\", \\\"{x:1538,y:823,t:1527016856564};\\\", \\\"{x:1538,y:822,t:1527016856588};\\\", \\\"{x:1535,y:820,t:1527016856924};\\\", \\\"{x:1533,y:820,t:1527016856937};\\\", \\\"{x:1530,y:817,t:1527016856954};\\\", \\\"{x:1528,y:815,t:1527016856970};\\\", \\\"{x:1528,y:814,t:1527016857005};\\\", \\\"{x:1526,y:813,t:1527016857021};\\\", \\\"{x:1524,y:812,t:1527016857037};\\\", \\\"{x:1520,y:810,t:1527016857054};\\\", \\\"{x:1512,y:806,t:1527016857071};\\\", \\\"{x:1505,y:802,t:1527016857087};\\\", \\\"{x:1497,y:796,t:1527016857105};\\\", \\\"{x:1489,y:790,t:1527016857120};\\\", \\\"{x:1477,y:780,t:1527016857137};\\\", \\\"{x:1470,y:770,t:1527016857155};\\\", \\\"{x:1461,y:761,t:1527016857170};\\\", \\\"{x:1454,y:758,t:1527016857187};\\\", \\\"{x:1453,y:756,t:1527016857204};\\\", \\\"{x:1451,y:755,t:1527016857228};\\\", \\\"{x:1449,y:755,t:1527016857238};\\\", \\\"{x:1444,y:752,t:1527016857254};\\\", \\\"{x:1440,y:751,t:1527016857272};\\\", \\\"{x:1436,y:750,t:1527016857287};\\\", \\\"{x:1434,y:749,t:1527016857304};\\\", \\\"{x:1432,y:748,t:1527016857321};\\\", \\\"{x:1428,y:748,t:1527016857338};\\\", \\\"{x:1425,y:748,t:1527016857354};\\\", \\\"{x:1424,y:748,t:1527016857371};\\\", \\\"{x:1422,y:748,t:1527016857485};\\\", \\\"{x:1422,y:749,t:1527016857580};\\\", \\\"{x:1422,y:750,t:1527016857588};\\\", \\\"{x:1422,y:751,t:1527016857604};\\\", \\\"{x:1422,y:752,t:1527016857660};\\\", \\\"{x:1422,y:753,t:1527016857988};\\\", \\\"{x:1422,y:754,t:1527016858005};\\\", \\\"{x:1422,y:756,t:1527016858029};\\\", \\\"{x:1422,y:757,t:1527016858044};\\\", \\\"{x:1422,y:758,t:1527016858068};\\\", \\\"{x:1422,y:760,t:1527016858084};\\\", \\\"{x:1422,y:764,t:1527016858108};\\\", \\\"{x:1423,y:764,t:1527016858121};\\\", \\\"{x:1423,y:766,t:1527016858138};\\\", \\\"{x:1424,y:767,t:1527016858156};\\\", \\\"{x:1424,y:769,t:1527016858180};\\\", \\\"{x:1424,y:770,t:1527016858212};\\\", \\\"{x:1428,y:771,t:1527016858493};\\\", \\\"{x:1434,y:771,t:1527016858505};\\\", \\\"{x:1442,y:771,t:1527016858521};\\\", \\\"{x:1452,y:771,t:1527016858538};\\\", \\\"{x:1460,y:771,t:1527016858556};\\\", \\\"{x:1473,y:772,t:1527016858573};\\\", \\\"{x:1475,y:773,t:1527016858588};\\\", \\\"{x:1478,y:773,t:1527016858805};\\\", \\\"{x:1488,y:773,t:1527016858822};\\\", \\\"{x:1496,y:775,t:1527016858839};\\\", \\\"{x:1514,y:775,t:1527016858855};\\\", \\\"{x:1517,y:775,t:1527016858872};\\\", \\\"{x:1527,y:775,t:1527016858889};\\\", \\\"{x:1531,y:775,t:1527016858906};\\\", \\\"{x:1536,y:775,t:1527016858922};\\\", \\\"{x:1542,y:776,t:1527016858940};\\\", \\\"{x:1545,y:778,t:1527016858956};\\\", \\\"{x:1547,y:778,t:1527016858972};\\\", \\\"{x:1548,y:778,t:1527016858989};\\\", \\\"{x:1549,y:778,t:1527016859005};\\\", \\\"{x:1550,y:778,t:1527016859022};\\\", \\\"{x:1552,y:779,t:1527016859040};\\\", \\\"{x:1553,y:779,t:1527016859068};\\\", \\\"{x:1554,y:779,t:1527016859612};\\\", \\\"{x:1554,y:778,t:1527016859844};\\\", \\\"{x:1554,y:777,t:1527016860565};\\\", \\\"{x:1554,y:776,t:1527016862029};\\\", \\\"{x:1554,y:775,t:1527016862132};\\\", \\\"{x:1554,y:772,t:1527016862142};\\\", \\\"{x:1554,y:771,t:1527016862158};\\\", \\\"{x:1554,y:770,t:1527016862181};\\\", \\\"{x:1554,y:769,t:1527016862197};\\\", \\\"{x:1554,y:768,t:1527016862212};\\\", \\\"{x:1554,y:767,t:1527016862603};\\\", \\\"{x:1554,y:766,t:1527016862724};\\\", \\\"{x:1553,y:765,t:1527016862740};\\\", \\\"{x:1552,y:763,t:1527016862804};\\\", \\\"{x:1552,y:765,t:1527016863156};\\\", \\\"{x:1552,y:770,t:1527016863164};\\\", \\\"{x:1551,y:774,t:1527016863176};\\\", \\\"{x:1548,y:787,t:1527016863192};\\\", \\\"{x:1545,y:799,t:1527016863209};\\\", \\\"{x:1543,y:809,t:1527016863226};\\\", \\\"{x:1536,y:816,t:1527016863252};\\\", \\\"{x:1535,y:818,t:1527016863260};\\\", \\\"{x:1534,y:819,t:1527016863749};\\\", \\\"{x:1534,y:824,t:1527016863759};\\\", \\\"{x:1538,y:830,t:1527016863775};\\\", \\\"{x:1538,y:831,t:1527016863909};\\\", \\\"{x:1538,y:832,t:1527016864093};\\\", \\\"{x:1540,y:833,t:1527016864110};\\\", \\\"{x:1542,y:840,t:1527016864127};\\\", \\\"{x:1544,y:846,t:1527016864143};\\\", \\\"{x:1545,y:854,t:1527016864159};\\\", \\\"{x:1546,y:862,t:1527016864176};\\\", \\\"{x:1546,y:864,t:1527016864193};\\\", \\\"{x:1546,y:867,t:1527016864209};\\\", \\\"{x:1546,y:872,t:1527016864226};\\\", \\\"{x:1548,y:874,t:1527016864244};\\\", \\\"{x:1549,y:877,t:1527016864259};\\\", \\\"{x:1552,y:879,t:1527016864276};\\\", \\\"{x:1552,y:881,t:1527016864293};\\\", \\\"{x:1552,y:871,t:1527016864404};\\\", \\\"{x:1552,y:866,t:1527016864412};\\\", \\\"{x:1549,y:862,t:1527016864427};\\\", \\\"{x:1545,y:846,t:1527016864443};\\\", \\\"{x:1534,y:822,t:1527016864460};\\\", \\\"{x:1530,y:803,t:1527016864476};\\\", \\\"{x:1525,y:783,t:1527016864493};\\\", \\\"{x:1523,y:772,t:1527016864511};\\\", \\\"{x:1523,y:767,t:1527016864526};\\\", \\\"{x:1521,y:764,t:1527016864543};\\\", \\\"{x:1521,y:763,t:1527016864559};\\\", \\\"{x:1521,y:761,t:1527016864576};\\\", \\\"{x:1521,y:760,t:1527016864594};\\\", \\\"{x:1522,y:757,t:1527016864610};\\\", \\\"{x:1522,y:754,t:1527016864626};\\\", \\\"{x:1522,y:751,t:1527016864643};\\\", \\\"{x:1522,y:749,t:1527016864660};\\\", \\\"{x:1524,y:748,t:1527016864724};\\\", \\\"{x:1527,y:748,t:1527016864732};\\\", \\\"{x:1528,y:748,t:1527016864744};\\\", \\\"{x:1531,y:748,t:1527016864760};\\\", \\\"{x:1535,y:749,t:1527016864777};\\\", \\\"{x:1537,y:752,t:1527016864793};\\\", \\\"{x:1539,y:756,t:1527016864810};\\\", \\\"{x:1541,y:758,t:1527016864826};\\\", \\\"{x:1543,y:759,t:1527016864844};\\\", \\\"{x:1546,y:760,t:1527016864860};\\\", \\\"{x:1546,y:761,t:1527016864877};\\\", \\\"{x:1547,y:762,t:1527016864893};\\\", \\\"{x:1548,y:762,t:1527016864916};\\\", \\\"{x:1548,y:763,t:1527016864928};\\\", \\\"{x:1545,y:763,t:1527016868828};\\\", \\\"{x:1517,y:743,t:1527016868836};\\\", \\\"{x:1444,y:709,t:1527016868847};\\\", \\\"{x:1352,y:678,t:1527016868863};\\\", \\\"{x:1232,y:657,t:1527016868881};\\\", \\\"{x:1074,y:628,t:1527016868896};\\\", \\\"{x:936,y:616,t:1527016868915};\\\", \\\"{x:828,y:612,t:1527016868931};\\\", \\\"{x:722,y:612,t:1527016868946};\\\", \\\"{x:583,y:593,t:1527016868964};\\\", \\\"{x:491,y:576,t:1527016868980};\\\", \\\"{x:397,y:555,t:1527016868997};\\\", \\\"{x:344,y:533,t:1527016869013};\\\", \\\"{x:292,y:521,t:1527016869030};\\\", \\\"{x:267,y:512,t:1527016869046};\\\", \\\"{x:257,y:509,t:1527016869063};\\\", \\\"{x:247,y:504,t:1527016869080};\\\", \\\"{x:242,y:504,t:1527016869096};\\\", \\\"{x:241,y:504,t:1527016869908};\\\", \\\"{x:239,y:504,t:1527016869916};\\\", \\\"{x:236,y:509,t:1527016869933};\\\", \\\"{x:234,y:512,t:1527016869949};\\\", \\\"{x:233,y:512,t:1527016869966};\\\", \\\"{x:229,y:515,t:1527016869983};\\\", \\\"{x:224,y:519,t:1527016870001};\\\", \\\"{x:221,y:522,t:1527016870016};\\\", \\\"{x:216,y:526,t:1527016870029};\\\", \\\"{x:215,y:526,t:1527016870051};\\\", \\\"{x:212,y:527,t:1527016870075};\\\", \\\"{x:209,y:527,t:1527016870083};\\\", \\\"{x:208,y:527,t:1527016870097};\\\", \\\"{x:205,y:528,t:1527016870114};\\\", \\\"{x:202,y:530,t:1527016870130};\\\", \\\"{x:195,y:531,t:1527016870147};\\\", \\\"{x:193,y:532,t:1527016870164};\\\", \\\"{x:192,y:533,t:1527016870180};\\\", \\\"{x:191,y:534,t:1527016870198};\\\", \\\"{x:190,y:534,t:1527016870214};\\\", \\\"{x:187,y:536,t:1527016870230};\\\", \\\"{x:186,y:536,t:1527016870252};\\\", \\\"{x:185,y:536,t:1527016870275};\\\", \\\"{x:185,y:537,t:1527016870292};\\\", \\\"{x:185,y:538,t:1527016870323};\\\", \\\"{x:183,y:540,t:1527016870340};\\\", \\\"{x:181,y:541,t:1527016870348};\\\", \\\"{x:179,y:541,t:1527016870365};\\\", \\\"{x:176,y:543,t:1527016870382};\\\", \\\"{x:184,y:549,t:1527016870812};\\\", \\\"{x:202,y:551,t:1527016870820};\\\", \\\"{x:216,y:556,t:1527016870831};\\\", \\\"{x:343,y:590,t:1527016870849};\\\", \\\"{x:424,y:616,t:1527016870865};\\\", \\\"{x:588,y:645,t:1527016870882};\\\", \\\"{x:737,y:680,t:1527016870898};\\\", \\\"{x:861,y:699,t:1527016870914};\\\", \\\"{x:1006,y:742,t:1527016870931};\\\", \\\"{x:1096,y:773,t:1527016870948};\\\", \\\"{x:1144,y:797,t:1527016870965};\\\", \\\"{x:1173,y:808,t:1527016870982};\\\", \\\"{x:1191,y:814,t:1527016870999};\\\", \\\"{x:1208,y:821,t:1527016871015};\\\", \\\"{x:1216,y:822,t:1527016871031};\\\", \\\"{x:1223,y:822,t:1527016871048};\\\", \\\"{x:1227,y:822,t:1527016871065};\\\", \\\"{x:1228,y:822,t:1527016871081};\\\", \\\"{x:1232,y:822,t:1527016871098};\\\", \\\"{x:1239,y:818,t:1527016871115};\\\", \\\"{x:1247,y:813,t:1527016871131};\\\", \\\"{x:1255,y:809,t:1527016871148};\\\", \\\"{x:1276,y:802,t:1527016871165};\\\", \\\"{x:1302,y:791,t:1527016871181};\\\", \\\"{x:1313,y:787,t:1527016871198};\\\", \\\"{x:1331,y:785,t:1527016871216};\\\", \\\"{x:1350,y:777,t:1527016871231};\\\", \\\"{x:1361,y:770,t:1527016871248};\\\", \\\"{x:1383,y:762,t:1527016871266};\\\", \\\"{x:1399,y:754,t:1527016871281};\\\", \\\"{x:1413,y:747,t:1527016871298};\\\", \\\"{x:1419,y:741,t:1527016871315};\\\", \\\"{x:1421,y:739,t:1527016871332};\\\", \\\"{x:1421,y:737,t:1527016871349};\\\", \\\"{x:1421,y:734,t:1527016871366};\\\", \\\"{x:1421,y:731,t:1527016871383};\\\", \\\"{x:1421,y:729,t:1527016871399};\\\", \\\"{x:1423,y:727,t:1527016871416};\\\", \\\"{x:1423,y:724,t:1527016871432};\\\", \\\"{x:1420,y:719,t:1527016871448};\\\", \\\"{x:1416,y:713,t:1527016871465};\\\", \\\"{x:1414,y:709,t:1527016871482};\\\", \\\"{x:1410,y:703,t:1527016871498};\\\", \\\"{x:1397,y:696,t:1527016871515};\\\", \\\"{x:1385,y:689,t:1527016871532};\\\", \\\"{x:1376,y:683,t:1527016871548};\\\", \\\"{x:1372,y:680,t:1527016871565};\\\", \\\"{x:1370,y:680,t:1527016871583};\\\", \\\"{x:1367,y:679,t:1527016871599};\\\", \\\"{x:1365,y:679,t:1527016871615};\\\", \\\"{x:1364,y:679,t:1527016871632};\\\", \\\"{x:1363,y:679,t:1527016871660};\\\", \\\"{x:1362,y:679,t:1527016871716};\\\", \\\"{x:1361,y:679,t:1527016871828};\\\", \\\"{x:1361,y:678,t:1527016872364};\\\", \\\"{x:1360,y:678,t:1527016872380};\\\", \\\"{x:1359,y:678,t:1527016872388};\\\", \\\"{x:1358,y:678,t:1527016872400};\\\", \\\"{x:1357,y:678,t:1527016872417};\\\", \\\"{x:1356,y:678,t:1527016872434};\\\", \\\"{x:1355,y:678,t:1527016872460};\\\", \\\"{x:1354,y:677,t:1527016872476};\\\", \\\"{x:1352,y:676,t:1527016872492};\\\", \\\"{x:1351,y:674,t:1527016872499};\\\", \\\"{x:1349,y:671,t:1527016872516};\\\", \\\"{x:1346,y:669,t:1527016872534};\\\", \\\"{x:1344,y:667,t:1527016872550};\\\", \\\"{x:1343,y:667,t:1527016872567};\\\", \\\"{x:1342,y:665,t:1527016872584};\\\", \\\"{x:1341,y:664,t:1527016872600};\\\", \\\"{x:1339,y:662,t:1527016872616};\\\", \\\"{x:1337,y:660,t:1527016872634};\\\", \\\"{x:1336,y:657,t:1527016872651};\\\", \\\"{x:1331,y:651,t:1527016872667};\\\", \\\"{x:1324,y:643,t:1527016872683};\\\", \\\"{x:1314,y:632,t:1527016872700};\\\", \\\"{x:1309,y:626,t:1527016872717};\\\", \\\"{x:1307,y:626,t:1527016872734};\\\", \\\"{x:1306,y:625,t:1527016872751};\\\", \\\"{x:1303,y:623,t:1527016872767};\\\", \\\"{x:1303,y:622,t:1527016872784};\\\", \\\"{x:1301,y:619,t:1527016872801};\\\", \\\"{x:1301,y:608,t:1527016872817};\\\", \\\"{x:1301,y:606,t:1527016872834};\\\", \\\"{x:1300,y:601,t:1527016872850};\\\", \\\"{x:1300,y:597,t:1527016872867};\\\", \\\"{x:1299,y:592,t:1527016872884};\\\", \\\"{x:1299,y:591,t:1527016872900};\\\", \\\"{x:1299,y:589,t:1527016873284};\\\", \\\"{x:1300,y:587,t:1527016873301};\\\", \\\"{x:1301,y:585,t:1527016873318};\\\", \\\"{x:1301,y:583,t:1527016873335};\\\", \\\"{x:1301,y:581,t:1527016873356};\\\", \\\"{x:1301,y:580,t:1527016873452};\\\", \\\"{x:1303,y:580,t:1527016873476};\\\", \\\"{x:1303,y:581,t:1527016873492};\\\", \\\"{x:1303,y:582,t:1527016873524};\\\", \\\"{x:1304,y:582,t:1527016873645};\\\", \\\"{x:1305,y:582,t:1527016873660};\\\", \\\"{x:1305,y:581,t:1527016873676};\\\", \\\"{x:1305,y:579,t:1527016873684};\\\", \\\"{x:1307,y:576,t:1527016873702};\\\", \\\"{x:1307,y:574,t:1527016873718};\\\", \\\"{x:1308,y:573,t:1527016873734};\\\", \\\"{x:1309,y:571,t:1527016873752};\\\", \\\"{x:1314,y:571,t:1527016873767};\\\", \\\"{x:1316,y:570,t:1527016873785};\\\", \\\"{x:1319,y:567,t:1527016873802};\\\", \\\"{x:1320,y:567,t:1527016873818};\\\", \\\"{x:1323,y:566,t:1527016873835};\\\", \\\"{x:1324,y:564,t:1527016873852};\\\", \\\"{x:1325,y:564,t:1527016873868};\\\", \\\"{x:1325,y:563,t:1527016873885};\\\", \\\"{x:1326,y:563,t:1527016873916};\\\", \\\"{x:1327,y:562,t:1527016873940};\\\", \\\"{x:1328,y:562,t:1527016873980};\\\", \\\"{x:1330,y:561,t:1527016874029};\\\", \\\"{x:1332,y:561,t:1527016874036};\\\", \\\"{x:1340,y:561,t:1527016874052};\\\", \\\"{x:1341,y:561,t:1527016874069};\\\", \\\"{x:1342,y:561,t:1527016874141};\\\", \\\"{x:1343,y:561,t:1527016874196};\\\", \\\"{x:1344,y:561,t:1527016874244};\\\", \\\"{x:1345,y:560,t:1527016874348};\\\", \\\"{x:1346,y:560,t:1527016876212};\\\", \\\"{x:1349,y:560,t:1527016876221};\\\", \\\"{x:1361,y:561,t:1527016876239};\\\", \\\"{x:1373,y:566,t:1527016876254};\\\", \\\"{x:1374,y:566,t:1527016876270};\\\", \\\"{x:1377,y:568,t:1527016876288};\\\", \\\"{x:1378,y:571,t:1527016876304};\\\", \\\"{x:1384,y:571,t:1527016876321};\\\", \\\"{x:1392,y:571,t:1527016876338};\\\", \\\"{x:1395,y:571,t:1527016876354};\\\", \\\"{x:1396,y:571,t:1527016876379};\\\", \\\"{x:1397,y:571,t:1527016876395};\\\", \\\"{x:1398,y:571,t:1527016876427};\\\", \\\"{x:1400,y:571,t:1527016876438};\\\", \\\"{x:1402,y:571,t:1527016876459};\\\", \\\"{x:1403,y:571,t:1527016876475};\\\", \\\"{x:1405,y:571,t:1527016876491};\\\", \\\"{x:1407,y:570,t:1527016876523};\\\", \\\"{x:1408,y:570,t:1527016876547};\\\", \\\"{x:1408,y:569,t:1527016876916};\\\", \\\"{x:1409,y:567,t:1527016876923};\\\", \\\"{x:1410,y:567,t:1527016876938};\\\", \\\"{x:1413,y:563,t:1527016876954};\\\", \\\"{x:1428,y:560,t:1527016876972};\\\", \\\"{x:1440,y:557,t:1527016876989};\\\", \\\"{x:1452,y:557,t:1527016877005};\\\", \\\"{x:1461,y:557,t:1527016877021};\\\", \\\"{x:1467,y:557,t:1527016877039};\\\", \\\"{x:1469,y:557,t:1527016877054};\\\", \\\"{x:1471,y:557,t:1527016877072};\\\", \\\"{x:1472,y:559,t:1527016877089};\\\", \\\"{x:1473,y:559,t:1527016877132};\\\", \\\"{x:1474,y:560,t:1527016877172};\\\", \\\"{x:1476,y:561,t:1527016877252};\\\", \\\"{x:1476,y:562,t:1527016877268};\\\", \\\"{x:1478,y:563,t:1527016878436};\\\", \\\"{x:1482,y:563,t:1527016878444};\\\", \\\"{x:1490,y:563,t:1527016878457};\\\", \\\"{x:1501,y:563,t:1527016878473};\\\", \\\"{x:1504,y:564,t:1527016878491};\\\", \\\"{x:1510,y:565,t:1527016878507};\\\", \\\"{x:1513,y:565,t:1527016878523};\\\", \\\"{x:1521,y:565,t:1527016878539};\\\", \\\"{x:1527,y:565,t:1527016878556};\\\", \\\"{x:1535,y:565,t:1527016878574};\\\", \\\"{x:1543,y:565,t:1527016878590};\\\", \\\"{x:1548,y:565,t:1527016878606};\\\", \\\"{x:1550,y:565,t:1527016878624};\\\", \\\"{x:1551,y:565,t:1527016878640};\\\", \\\"{x:1553,y:565,t:1527016878675};\\\", \\\"{x:1555,y:565,t:1527016878691};\\\", \\\"{x:1559,y:565,t:1527016878707};\\\", \\\"{x:1566,y:562,t:1527016878723};\\\", \\\"{x:1567,y:562,t:1527016878740};\\\", \\\"{x:1569,y:561,t:1527016878757};\\\", \\\"{x:1570,y:561,t:1527016878780};\\\", \\\"{x:1569,y:561,t:1527016878964};\\\", \\\"{x:1567,y:561,t:1527016878979};\\\", \\\"{x:1565,y:561,t:1527016878991};\\\", \\\"{x:1563,y:563,t:1527016879008};\\\", \\\"{x:1558,y:564,t:1527016879024};\\\", \\\"{x:1554,y:568,t:1527016879040};\\\", \\\"{x:1549,y:575,t:1527016879056};\\\", \\\"{x:1536,y:581,t:1527016879074};\\\", \\\"{x:1524,y:587,t:1527016879091};\\\", \\\"{x:1518,y:590,t:1527016879107};\\\", \\\"{x:1516,y:590,t:1527016879124};\\\", \\\"{x:1515,y:591,t:1527016879141};\\\", \\\"{x:1514,y:593,t:1527016879172};\\\", \\\"{x:1513,y:593,t:1527016879180};\\\", \\\"{x:1513,y:594,t:1527016879191};\\\", \\\"{x:1509,y:596,t:1527016879207};\\\", \\\"{x:1505,y:598,t:1527016879223};\\\", \\\"{x:1497,y:604,t:1527016879241};\\\", \\\"{x:1481,y:613,t:1527016879257};\\\", \\\"{x:1464,y:625,t:1527016879274};\\\", \\\"{x:1450,y:636,t:1527016879291};\\\", \\\"{x:1423,y:653,t:1527016879307};\\\", \\\"{x:1401,y:669,t:1527016879324};\\\", \\\"{x:1386,y:681,t:1527016879341};\\\", \\\"{x:1372,y:697,t:1527016879358};\\\", \\\"{x:1363,y:703,t:1527016879374};\\\", \\\"{x:1343,y:714,t:1527016879391};\\\", \\\"{x:1335,y:718,t:1527016879408};\\\", \\\"{x:1323,y:724,t:1527016879424};\\\", \\\"{x:1315,y:727,t:1527016879441};\\\", \\\"{x:1312,y:730,t:1527016879457};\\\", \\\"{x:1310,y:731,t:1527016879473};\\\", \\\"{x:1310,y:733,t:1527016879491};\\\", \\\"{x:1308,y:738,t:1527016879507};\\\", \\\"{x:1308,y:741,t:1527016879525};\\\", \\\"{x:1308,y:745,t:1527016879541};\\\", \\\"{x:1306,y:751,t:1527016879558};\\\", \\\"{x:1297,y:761,t:1527016879574};\\\", \\\"{x:1291,y:762,t:1527016879590};\\\", \\\"{x:1290,y:763,t:1527016879996};\\\", \\\"{x:1289,y:765,t:1527016880008};\\\", \\\"{x:1285,y:775,t:1527016880025};\\\", \\\"{x:1284,y:778,t:1527016880042};\\\", \\\"{x:1281,y:780,t:1527016880058};\\\", \\\"{x:1278,y:784,t:1527016880075};\\\", \\\"{x:1275,y:792,t:1527016880092};\\\", \\\"{x:1273,y:801,t:1527016880108};\\\", \\\"{x:1270,y:810,t:1527016880125};\\\", \\\"{x:1268,y:814,t:1527016880142};\\\", \\\"{x:1265,y:818,t:1527016880159};\\\", \\\"{x:1265,y:819,t:1527016880188};\\\", \\\"{x:1265,y:820,t:1527016880340};\\\", \\\"{x:1266,y:820,t:1527016880348};\\\", \\\"{x:1268,y:811,t:1527016880359};\\\", \\\"{x:1269,y:808,t:1527016880375};\\\", \\\"{x:1271,y:801,t:1527016880392};\\\", \\\"{x:1274,y:791,t:1527016880409};\\\", \\\"{x:1275,y:787,t:1527016880425};\\\", \\\"{x:1275,y:777,t:1527016880442};\\\", \\\"{x:1272,y:768,t:1527016880459};\\\", \\\"{x:1263,y:758,t:1527016880475};\\\", \\\"{x:1250,y:751,t:1527016880492};\\\", \\\"{x:1233,y:745,t:1527016880509};\\\", \\\"{x:1228,y:740,t:1527016880526};\\\", \\\"{x:1229,y:741,t:1527016880668};\\\", \\\"{x:1236,y:745,t:1527016880676};\\\", \\\"{x:1247,y:751,t:1527016880691};\\\", \\\"{x:1257,y:757,t:1527016880709};\\\", \\\"{x:1268,y:760,t:1527016880726};\\\", \\\"{x:1280,y:766,t:1527016880742};\\\", \\\"{x:1284,y:767,t:1527016880759};\\\", \\\"{x:1290,y:768,t:1527016880776};\\\", \\\"{x:1291,y:768,t:1527016880793};\\\", \\\"{x:1293,y:768,t:1527016880809};\\\", \\\"{x:1295,y:768,t:1527016881012};\\\", \\\"{x:1299,y:767,t:1527016881027};\\\", \\\"{x:1300,y:767,t:1527016881043};\\\", \\\"{x:1306,y:764,t:1527016881059};\\\", \\\"{x:1313,y:763,t:1527016881076};\\\", \\\"{x:1319,y:763,t:1527016881093};\\\", \\\"{x:1320,y:763,t:1527016881110};\\\", \\\"{x:1325,y:760,t:1527016881126};\\\", \\\"{x:1327,y:759,t:1527016881221};\\\", \\\"{x:1330,y:759,t:1527016881348};\\\", \\\"{x:1331,y:759,t:1527016881360};\\\", \\\"{x:1334,y:759,t:1527016881377};\\\", \\\"{x:1336,y:759,t:1527016881393};\\\", \\\"{x:1337,y:759,t:1527016881410};\\\", \\\"{x:1339,y:759,t:1527016881427};\\\", \\\"{x:1340,y:759,t:1527016882405};\\\", \\\"{x:1343,y:759,t:1527016882411};\\\", \\\"{x:1344,y:759,t:1527016882426};\\\", \\\"{x:1350,y:759,t:1527016882443};\\\", \\\"{x:1354,y:759,t:1527016882461};\\\", \\\"{x:1357,y:759,t:1527016882478};\\\", \\\"{x:1359,y:759,t:1527016882493};\\\", \\\"{x:1361,y:761,t:1527016882555};\\\", \\\"{x:1360,y:758,t:1527016884533};\\\", \\\"{x:1360,y:756,t:1527016884546};\\\", \\\"{x:1360,y:750,t:1527016884563};\\\", \\\"{x:1359,y:726,t:1527016884579};\\\", \\\"{x:1357,y:713,t:1527016884597};\\\", \\\"{x:1357,y:705,t:1527016884613};\\\", \\\"{x:1357,y:691,t:1527016884630};\\\", \\\"{x:1361,y:683,t:1527016884647};\\\", \\\"{x:1361,y:681,t:1527016884663};\\\", \\\"{x:1361,y:679,t:1527016884681};\\\", \\\"{x:1361,y:683,t:1527016884748};\\\", \\\"{x:1365,y:687,t:1527016884763};\\\", \\\"{x:1367,y:692,t:1527016884780};\\\", \\\"{x:1371,y:696,t:1527016884797};\\\", \\\"{x:1373,y:698,t:1527016884813};\\\", \\\"{x:1373,y:699,t:1527016884835};\\\", \\\"{x:1375,y:702,t:1527016884847};\\\", \\\"{x:1377,y:704,t:1527016884864};\\\", \\\"{x:1377,y:705,t:1527016884880};\\\", \\\"{x:1378,y:705,t:1527016884897};\\\", \\\"{x:1379,y:705,t:1527016884980};\\\", \\\"{x:1381,y:705,t:1527016885012};\\\", \\\"{x:1382,y:705,t:1527016885020};\\\", \\\"{x:1385,y:705,t:1527016885030};\\\", \\\"{x:1388,y:705,t:1527016885047};\\\", \\\"{x:1394,y:705,t:1527016885064};\\\", \\\"{x:1400,y:705,t:1527016885080};\\\", \\\"{x:1402,y:705,t:1527016885097};\\\", \\\"{x:1408,y:705,t:1527016885115};\\\", \\\"{x:1412,y:704,t:1527016885131};\\\", \\\"{x:1416,y:704,t:1527016885147};\\\", \\\"{x:1418,y:704,t:1527016885165};\\\", \\\"{x:1419,y:704,t:1527016885188};\\\", \\\"{x:1422,y:702,t:1527016885197};\\\", \\\"{x:1422,y:701,t:1527016885214};\\\", \\\"{x:1424,y:701,t:1527016885231};\\\", \\\"{x:1425,y:700,t:1527016885247};\\\", \\\"{x:1428,y:699,t:1527016885264};\\\", \\\"{x:1429,y:698,t:1527016885282};\\\", \\\"{x:1429,y:697,t:1527016885297};\\\", \\\"{x:1430,y:696,t:1527016885324};\\\", \\\"{x:1430,y:695,t:1527016885364};\\\", \\\"{x:1431,y:695,t:1527016885436};\\\", \\\"{x:1430,y:695,t:1527016885939};\\\", \\\"{x:1429,y:695,t:1527016885956};\\\", \\\"{x:1428,y:695,t:1527016885965};\\\", \\\"{x:1427,y:695,t:1527016885981};\\\", \\\"{x:1426,y:695,t:1527016885999};\\\", \\\"{x:1425,y:695,t:1527016886036};\\\", \\\"{x:1425,y:697,t:1527016886188};\\\", \\\"{x:1424,y:697,t:1527016886276};\\\", \\\"{x:1423,y:698,t:1527016886316};\\\", \\\"{x:1422,y:698,t:1527016886331};\\\", \\\"{x:1420,y:698,t:1527016886426};\\\", \\\"{x:1423,y:698,t:1527016886747};\\\", \\\"{x:1427,y:698,t:1527016886755};\\\", \\\"{x:1431,y:698,t:1527016886766};\\\", \\\"{x:1441,y:698,t:1527016886781};\\\", \\\"{x:1443,y:698,t:1527016886799};\\\", \\\"{x:1444,y:698,t:1527016886816};\\\", \\\"{x:1446,y:697,t:1527016886832};\\\", \\\"{x:1449,y:697,t:1527016886849};\\\", \\\"{x:1451,y:697,t:1527016886866};\\\", \\\"{x:1457,y:697,t:1527016886882};\\\", \\\"{x:1462,y:697,t:1527016886900};\\\", \\\"{x:1463,y:697,t:1527016886916};\\\", \\\"{x:1464,y:697,t:1527016887028};\\\", \\\"{x:1466,y:697,t:1527016887036};\\\", \\\"{x:1468,y:697,t:1527016887050};\\\", \\\"{x:1472,y:697,t:1527016887066};\\\", \\\"{x:1475,y:697,t:1527016887084};\\\", \\\"{x:1476,y:697,t:1527016887099};\\\", \\\"{x:1479,y:696,t:1527016887116};\\\", \\\"{x:1483,y:695,t:1527016887324};\\\", \\\"{x:1487,y:695,t:1527016887333};\\\", \\\"{x:1490,y:695,t:1527016887349};\\\", \\\"{x:1504,y:695,t:1527016887366};\\\", \\\"{x:1521,y:695,t:1527016887383};\\\", \\\"{x:1535,y:692,t:1527016887400};\\\", \\\"{x:1545,y:692,t:1527016887416};\\\", \\\"{x:1547,y:692,t:1527016887433};\\\", \\\"{x:1551,y:692,t:1527016887449};\\\", \\\"{x:1554,y:692,t:1527016887465};\\\", \\\"{x:1558,y:692,t:1527016887482};\\\", \\\"{x:1556,y:691,t:1527016887780};\\\", \\\"{x:1555,y:691,t:1527016887804};\\\", \\\"{x:1553,y:691,t:1527016888299};\\\", \\\"{x:1550,y:690,t:1527016888317};\\\", \\\"{x:1548,y:690,t:1527016888335};\\\", \\\"{x:1542,y:689,t:1527016888351};\\\", \\\"{x:1540,y:688,t:1527016888368};\\\", \\\"{x:1537,y:688,t:1527016888384};\\\", \\\"{x:1533,y:687,t:1527016888401};\\\", \\\"{x:1531,y:687,t:1527016888417};\\\", \\\"{x:1530,y:687,t:1527016888434};\\\", \\\"{x:1529,y:687,t:1527016888548};\\\", \\\"{x:1529,y:686,t:1527016888612};\\\", \\\"{x:1529,y:684,t:1527016888692};\\\", \\\"{x:1529,y:683,t:1527016888707};\\\", \\\"{x:1529,y:682,t:1527016888718};\\\", \\\"{x:1529,y:680,t:1527016888948};\\\", \\\"{x:1529,y:679,t:1527016888955};\\\", \\\"{x:1529,y:677,t:1527016888972};\\\", \\\"{x:1529,y:676,t:1527016889060};\\\", \\\"{x:1529,y:674,t:1527016889100};\\\", \\\"{x:1528,y:673,t:1527016889123};\\\", \\\"{x:1527,y:673,t:1527016889156};\\\", \\\"{x:1525,y:673,t:1527016889172};\\\", \\\"{x:1524,y:673,t:1527016889185};\\\", \\\"{x:1523,y:672,t:1527016889452};\\\", \\\"{x:1523,y:671,t:1527016889468};\\\", \\\"{x:1523,y:670,t:1527016889596};\\\", \\\"{x:1522,y:669,t:1527016889739};\\\", \\\"{x:1514,y:669,t:1527016889752};\\\", \\\"{x:1506,y:669,t:1527016889770};\\\", \\\"{x:1497,y:670,t:1527016889785};\\\", \\\"{x:1494,y:670,t:1527016889803};\\\", \\\"{x:1490,y:670,t:1527016889820};\\\", \\\"{x:1488,y:670,t:1527016891020};\\\", \\\"{x:1472,y:666,t:1527016891038};\\\", \\\"{x:1455,y:665,t:1527016891054};\\\", \\\"{x:1447,y:664,t:1527016891071};\\\", \\\"{x:1433,y:664,t:1527016891087};\\\", \\\"{x:1425,y:664,t:1527016891104};\\\", \\\"{x:1420,y:665,t:1527016891120};\\\", \\\"{x:1417,y:666,t:1527016891137};\\\", \\\"{x:1415,y:666,t:1527016891154};\\\", \\\"{x:1411,y:666,t:1527016891170};\\\", \\\"{x:1408,y:666,t:1527016891187};\\\", \\\"{x:1407,y:666,t:1527016891235};\\\", \\\"{x:1405,y:666,t:1527016891252};\\\", \\\"{x:1403,y:666,t:1527016891260};\\\", \\\"{x:1402,y:666,t:1527016891771};\\\", \\\"{x:1401,y:666,t:1527016891788};\\\", \\\"{x:1394,y:665,t:1527016891804};\\\", \\\"{x:1388,y:665,t:1527016891822};\\\", \\\"{x:1384,y:665,t:1527016891839};\\\", \\\"{x:1382,y:665,t:1527016891855};\\\", \\\"{x:1379,y:665,t:1527016891871};\\\", \\\"{x:1376,y:665,t:1527016891888};\\\", \\\"{x:1375,y:666,t:1527016891904};\\\", \\\"{x:1374,y:668,t:1527016891922};\\\", \\\"{x:1370,y:672,t:1527016892964};\\\", \\\"{x:1356,y:679,t:1527016892973};\\\", \\\"{x:1286,y:701,t:1527016892990};\\\", \\\"{x:1202,y:718,t:1527016893007};\\\", \\\"{x:1095,y:726,t:1527016893022};\\\", \\\"{x:993,y:734,t:1527016893039};\\\", \\\"{x:887,y:738,t:1527016893057};\\\", \\\"{x:818,y:745,t:1527016893072};\\\", \\\"{x:754,y:755,t:1527016893089};\\\", \\\"{x:733,y:767,t:1527016893106};\\\", \\\"{x:660,y:792,t:1527016893123};\\\", \\\"{x:602,y:811,t:1527016893139};\\\", \\\"{x:541,y:826,t:1527016893156};\\\", \\\"{x:519,y:833,t:1527016893172};\\\", \\\"{x:511,y:835,t:1527016893190};\\\", \\\"{x:510,y:833,t:1527016893732};\\\", \\\"{x:510,y:831,t:1527016893739};\\\", \\\"{x:508,y:828,t:1527016893756};\\\", \\\"{x:507,y:823,t:1527016893773};\\\", \\\"{x:507,y:822,t:1527016893803};\\\", \\\"{x:507,y:820,t:1527016893827};\\\", \\\"{x:507,y:818,t:1527016893840};\\\", \\\"{x:512,y:812,t:1527016893856};\\\", \\\"{x:517,y:797,t:1527016893874};\\\", \\\"{x:521,y:787,t:1527016893891};\\\", \\\"{x:526,y:779,t:1527016893907};\\\", \\\"{x:527,y:774,t:1527016893923};\\\", \\\"{x:528,y:770,t:1527016893940};\\\", \\\"{x:529,y:767,t:1527016893957};\\\", \\\"{x:530,y:763,t:1527016893974};\\\", \\\"{x:533,y:755,t:1527016893991};\\\", \\\"{x:534,y:752,t:1527016894008};\\\", \\\"{x:534,y:751,t:1527016894023};\\\", \\\"{x:534,y:750,t:1527016894040};\\\", \\\"{x:534,y:749,t:1527016894211};\\\", \\\"{x:534,y:748,t:1527016894227};\\\", \\\"{x:534,y:745,t:1527016894243};\\\", \\\"{x:534,y:743,t:1527016894259};\\\", \\\"{x:534,y:742,t:1527016894276};\\\", \\\"{x:534,y:738,t:1527016894294};\\\", \\\"{x:534,y:736,t:1527016895043};\\\", \\\"{x:535,y:735,t:1527016895051};\\\", \\\"{x:535,y:734,t:1527016895083};\\\" ] }, { \\\"rt\\\": 83324, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 19, \\\"time_elapsed\\\": 1017520, \\\"internal_node_id\\\": \\\"0.0-6.0-9.0\\\", \\\"subject\\\": \\\"6Y93F\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"foxtrot\\\", \\\"condition\\\": \\\"111\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"midpoint\\\", \\\"q\\\": 15, \\\"clicks\\\": 2.5, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XInside-YFull\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 0, \\\"answer\\\": [ \\\"E\\\", \\\"B\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-M -04 PM-03 PM-01 PM-B -F -F -G -B -M -C -G \\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:535,y:733,t:1527016896219};\\\", \\\"{x:535,y:732,t:1527016896259};\\\", \\\"{x:535,y:730,t:1527016896331};\\\", \\\"{x:539,y:725,t:1527016896347};\\\", \\\"{x:541,y:723,t:1527016896354};\\\", \\\"{x:574,y:698,t:1527016896452};\\\", \\\"{x:575,y:697,t:1527016896468};\\\", \\\"{x:579,y:692,t:1527016896485};\\\", \\\"{x:582,y:690,t:1527016896502};\\\", \\\"{x:585,y:686,t:1527016896517};\\\", \\\"{x:591,y:680,t:1527016896535};\\\", \\\"{x:600,y:674,t:1527016896551};\\\", \\\"{x:616,y:665,t:1527016896568};\\\", \\\"{x:627,y:659,t:1527016896585};\\\", \\\"{x:638,y:656,t:1527016896602};\\\", \\\"{x:657,y:648,t:1527016896618};\\\", \\\"{x:683,y:638,t:1527016896635};\\\", \\\"{x:704,y:637,t:1527016896652};\\\", \\\"{x:716,y:640,t:1527016896667};\\\", \\\"{x:719,y:637,t:1527016896685};\\\", \\\"{x:719,y:635,t:1527016896702};\\\", \\\"{x:719,y:634,t:1527016897188};\\\", \\\"{x:720,y:633,t:1527016897284};\\\", \\\"{x:722,y:631,t:1527016897291};\\\", \\\"{x:723,y:629,t:1527016897302};\\\", \\\"{x:731,y:624,t:1527016897321};\\\", \\\"{x:739,y:619,t:1527016897336};\\\", \\\"{x:751,y:612,t:1527016897353};\\\", \\\"{x:767,y:605,t:1527016897369};\\\", \\\"{x:777,y:599,t:1527016897386};\\\", \\\"{x:794,y:595,t:1527016897402};\\\", \\\"{x:807,y:592,t:1527016897419};\\\", \\\"{x:813,y:590,t:1527016897435};\\\", \\\"{x:825,y:589,t:1527016897452};\\\", \\\"{x:829,y:589,t:1527016897469};\\\", \\\"{x:832,y:589,t:1527016897485};\\\", \\\"{x:842,y:588,t:1527016897502};\\\", \\\"{x:844,y:586,t:1527016897519};\\\", \\\"{x:847,y:586,t:1527016897535};\\\", \\\"{x:848,y:586,t:1527016897552};\\\", \\\"{x:849,y:585,t:1527016898004};\\\", \\\"{x:849,y:584,t:1527016898075};\\\", \\\"{x:850,y:583,t:1527016898085};\\\", \\\"{x:850,y:582,t:1527016898130};\\\", \\\"{x:850,y:581,t:1527016898178};\\\", \\\"{x:851,y:580,t:1527016898315};\\\", \\\"{x:852,y:579,t:1527016898362};\\\", \\\"{x:852,y:578,t:1527016899820};\\\", \\\"{x:853,y:576,t:1527016899837};\\\", \\\"{x:858,y:575,t:1527016899853};\\\", \\\"{x:859,y:575,t:1527016899874};\\\", \\\"{x:860,y:575,t:1527016899962};\\\", \\\"{x:864,y:573,t:1527016900675};\\\", \\\"{x:871,y:572,t:1527016900688};\\\", \\\"{x:885,y:568,t:1527016900707};\\\", \\\"{x:898,y:566,t:1527016900721};\\\", \\\"{x:991,y:564,t:1527016900739};\\\", \\\"{x:1182,y:566,t:1527016900754};\\\", \\\"{x:1312,y:579,t:1527016900771};\\\", \\\"{x:1432,y:589,t:1527016900788};\\\", \\\"{x:1558,y:593,t:1527016900805};\\\", \\\"{x:1650,y:597,t:1527016900821};\\\", \\\"{x:1733,y:597,t:1527016900838};\\\", \\\"{x:1755,y:597,t:1527016900855};\\\", \\\"{x:1762,y:597,t:1527016900872};\\\", \\\"{x:1788,y:597,t:1527016900887};\\\", \\\"{x:1806,y:596,t:1527016900904};\\\", \\\"{x:1820,y:596,t:1527016900922};\\\", \\\"{x:1827,y:598,t:1527016900938};\\\", \\\"{x:1851,y:602,t:1527016900955};\\\", \\\"{x:1863,y:608,t:1527016900972};\\\", \\\"{x:1865,y:609,t:1527016900987};\\\", \\\"{x:1867,y:609,t:1527016901005};\\\", \\\"{x:1868,y:609,t:1527016901022};\\\", \\\"{x:1863,y:609,t:1527016901491};\\\", \\\"{x:1857,y:610,t:1527016901505};\\\", \\\"{x:1843,y:613,t:1527016901522};\\\", \\\"{x:1828,y:621,t:1527016901538};\\\", \\\"{x:1814,y:632,t:1527016901555};\\\", \\\"{x:1795,y:643,t:1527016901572};\\\", \\\"{x:1781,y:651,t:1527016901589};\\\", \\\"{x:1757,y:663,t:1527016901605};\\\", \\\"{x:1736,y:669,t:1527016901622};\\\", \\\"{x:1724,y:677,t:1527016901639};\\\", \\\"{x:1711,y:684,t:1527016901655};\\\", \\\"{x:1684,y:697,t:1527016901673};\\\", \\\"{x:1657,y:717,t:1527016901690};\\\", \\\"{x:1613,y:744,t:1527016901706};\\\", \\\"{x:1567,y:776,t:1527016901722};\\\", \\\"{x:1519,y:821,t:1527016901739};\\\", \\\"{x:1500,y:840,t:1527016901756};\\\", \\\"{x:1479,y:854,t:1527016901773};\\\", \\\"{x:1455,y:868,t:1527016901789};\\\", \\\"{x:1448,y:873,t:1527016901806};\\\", \\\"{x:1444,y:878,t:1527016901822};\\\", \\\"{x:1444,y:873,t:1527016901883};\\\", \\\"{x:1444,y:872,t:1527016901890};\\\", \\\"{x:1444,y:871,t:1527016902676};\\\", \\\"{x:1444,y:870,t:1527016902690};\\\", \\\"{x:1444,y:869,t:1527016902860};\\\", \\\"{x:1444,y:868,t:1527016902874};\\\", \\\"{x:1445,y:867,t:1527016902891};\\\", \\\"{x:1445,y:863,t:1527016903004};\\\", \\\"{x:1445,y:861,t:1527016903012};\\\", \\\"{x:1445,y:860,t:1527016903027};\\\", \\\"{x:1444,y:857,t:1527016903041};\\\", \\\"{x:1442,y:855,t:1527016903059};\\\", \\\"{x:1441,y:854,t:1527016903083};\\\", \\\"{x:1440,y:853,t:1527016903091};\\\", \\\"{x:1439,y:853,t:1527016903107};\\\", \\\"{x:1439,y:852,t:1527016903164};\\\", \\\"{x:1438,y:848,t:1527016904515};\\\", \\\"{x:1432,y:845,t:1527016904525};\\\", \\\"{x:1431,y:844,t:1527016904541};\\\", \\\"{x:1421,y:841,t:1527016904558};\\\", \\\"{x:1411,y:839,t:1527016904575};\\\", \\\"{x:1402,y:832,t:1527016904592};\\\", \\\"{x:1401,y:832,t:1527016904608};\\\", \\\"{x:1397,y:829,t:1527016904625};\\\", \\\"{x:1392,y:828,t:1527016904642};\\\", \\\"{x:1390,y:828,t:1527016904658};\\\", \\\"{x:1386,y:828,t:1527016904675};\\\", \\\"{x:1385,y:828,t:1527016905444};\\\", \\\"{x:1384,y:828,t:1527016905458};\\\", \\\"{x:1384,y:827,t:1527016905475};\\\", \\\"{x:1384,y:828,t:1527016905619};\\\", \\\"{x:1384,y:829,t:1527016905627};\\\", \\\"{x:1386,y:832,t:1527016905643};\\\", \\\"{x:1388,y:835,t:1527016905659};\\\", \\\"{x:1393,y:839,t:1527016905676};\\\", \\\"{x:1399,y:848,t:1527016905692};\\\", \\\"{x:1401,y:851,t:1527016905709};\\\", \\\"{x:1402,y:854,t:1527016905725};\\\", \\\"{x:1402,y:855,t:1527016905742};\\\", \\\"{x:1402,y:857,t:1527016905915};\\\", \\\"{x:1400,y:857,t:1527016905926};\\\", \\\"{x:1393,y:858,t:1527016905943};\\\", \\\"{x:1389,y:858,t:1527016905959};\\\", \\\"{x:1381,y:859,t:1527016905975};\\\", \\\"{x:1369,y:859,t:1527016905992};\\\", \\\"{x:1348,y:864,t:1527016906009};\\\", \\\"{x:1339,y:865,t:1527016906026};\\\", \\\"{x:1327,y:867,t:1527016906043};\\\", \\\"{x:1322,y:867,t:1527016906059};\\\", \\\"{x:1321,y:867,t:1527016906076};\\\", \\\"{x:1319,y:866,t:1527016906093};\\\", \\\"{x:1316,y:865,t:1527016906109};\\\", \\\"{x:1311,y:864,t:1527016906126};\\\", \\\"{x:1309,y:864,t:1527016906142};\\\", \\\"{x:1294,y:860,t:1527016906159};\\\", \\\"{x:1290,y:860,t:1527016906175};\\\", \\\"{x:1287,y:860,t:1527016906203};\\\", \\\"{x:1284,y:860,t:1527016906211};\\\", \\\"{x:1283,y:860,t:1527016906226};\\\", \\\"{x:1279,y:857,t:1527016906243};\\\", \\\"{x:1277,y:856,t:1527016906260};\\\", \\\"{x:1277,y:855,t:1527016906300};\\\", \\\"{x:1277,y:854,t:1527016906315};\\\", \\\"{x:1277,y:853,t:1527016906326};\\\", \\\"{x:1281,y:851,t:1527016906342};\\\", \\\"{x:1288,y:848,t:1527016906360};\\\", \\\"{x:1288,y:847,t:1527016906376};\\\", \\\"{x:1293,y:847,t:1527016906411};\\\", \\\"{x:1297,y:847,t:1527016906426};\\\", \\\"{x:1322,y:856,t:1527016906443};\\\", \\\"{x:1349,y:866,t:1527016906459};\\\", \\\"{x:1370,y:882,t:1527016906476};\\\", \\\"{x:1385,y:897,t:1527016906496};\\\", \\\"{x:1395,y:907,t:1527016906509};\\\", \\\"{x:1406,y:919,t:1527016906526};\\\", \\\"{x:1408,y:925,t:1527016906542};\\\", \\\"{x:1408,y:926,t:1527016906559};\\\", \\\"{x:1408,y:929,t:1527016906576};\\\", \\\"{x:1410,y:932,t:1527016906592};\\\", \\\"{x:1410,y:933,t:1527016906609};\\\", \\\"{x:1410,y:932,t:1527016906682};\\\", \\\"{x:1410,y:931,t:1527016906956};\\\", \\\"{x:1414,y:931,t:1527016907044};\\\", \\\"{x:1436,y:931,t:1527016907060};\\\", \\\"{x:1447,y:926,t:1527016907077};\\\", \\\"{x:1456,y:926,t:1527016907094};\\\", \\\"{x:1459,y:926,t:1527016907110};\\\", \\\"{x:1498,y:936,t:1527016907127};\\\", \\\"{x:1567,y:945,t:1527016907144};\\\", \\\"{x:1617,y:952,t:1527016907160};\\\", \\\"{x:1641,y:954,t:1527016907177};\\\", \\\"{x:1659,y:953,t:1527016907194};\\\", \\\"{x:1665,y:953,t:1527016907209};\\\", \\\"{x:1667,y:952,t:1527016907227};\\\", \\\"{x:1663,y:952,t:1527016907339};\\\", \\\"{x:1656,y:953,t:1527016907348};\\\", \\\"{x:1652,y:956,t:1527016907360};\\\", \\\"{x:1641,y:963,t:1527016907377};\\\", \\\"{x:1631,y:967,t:1527016907395};\\\", \\\"{x:1608,y:972,t:1527016907410};\\\", \\\"{x:1570,y:978,t:1527016907427};\\\", \\\"{x:1547,y:982,t:1527016907444};\\\", \\\"{x:1537,y:983,t:1527016907460};\\\", \\\"{x:1536,y:984,t:1527016907507};\\\", \\\"{x:1536,y:985,t:1527016907515};\\\", \\\"{x:1535,y:986,t:1527016907527};\\\", \\\"{x:1528,y:987,t:1527016907544};\\\", \\\"{x:1520,y:987,t:1527016907561};\\\", \\\"{x:1518,y:987,t:1527016907577};\\\", \\\"{x:1510,y:981,t:1527016907594};\\\", \\\"{x:1509,y:980,t:1527016907827};\\\", \\\"{x:1505,y:969,t:1527016907844};\\\", \\\"{x:1501,y:956,t:1527016907861};\\\", \\\"{x:1498,y:949,t:1527016907877};\\\", \\\"{x:1497,y:948,t:1527016907899};\\\", \\\"{x:1496,y:946,t:1527016907923};\\\", \\\"{x:1496,y:945,t:1527016908131};\\\", \\\"{x:1495,y:943,t:1527016908143};\\\", \\\"{x:1495,y:939,t:1527016908160};\\\", \\\"{x:1495,y:931,t:1527016908178};\\\", \\\"{x:1496,y:923,t:1527016908194};\\\", \\\"{x:1496,y:917,t:1527016908210};\\\", \\\"{x:1499,y:911,t:1527016908227};\\\", \\\"{x:1500,y:907,t:1527016908244};\\\", \\\"{x:1500,y:905,t:1527016908261};\\\", \\\"{x:1502,y:903,t:1527016908278};\\\", \\\"{x:1502,y:897,t:1527016908294};\\\", \\\"{x:1502,y:895,t:1527016908310};\\\", \\\"{x:1502,y:891,t:1527016908328};\\\", \\\"{x:1500,y:884,t:1527016908344};\\\", \\\"{x:1497,y:881,t:1527016908361};\\\", \\\"{x:1494,y:876,t:1527016908377};\\\", \\\"{x:1494,y:875,t:1527016908394};\\\", \\\"{x:1493,y:874,t:1527016908411};\\\", \\\"{x:1495,y:874,t:1527016909051};\\\", \\\"{x:1497,y:875,t:1527016909061};\\\", \\\"{x:1501,y:879,t:1527016909078};\\\", \\\"{x:1502,y:882,t:1527016909095};\\\", \\\"{x:1503,y:888,t:1527016909112};\\\", \\\"{x:1506,y:893,t:1527016909128};\\\", \\\"{x:1506,y:895,t:1527016909284};\\\", \\\"{x:1506,y:897,t:1527016909295};\\\", \\\"{x:1506,y:899,t:1527016909315};\\\", \\\"{x:1506,y:900,t:1527016909328};\\\", \\\"{x:1506,y:904,t:1527016909345};\\\", \\\"{x:1506,y:905,t:1527016909362};\\\", \\\"{x:1505,y:910,t:1527016909378};\\\", \\\"{x:1502,y:920,t:1527016909396};\\\", \\\"{x:1501,y:925,t:1527016909412};\\\", \\\"{x:1500,y:925,t:1527016909429};\\\", \\\"{x:1500,y:926,t:1527016909547};\\\", \\\"{x:1499,y:926,t:1527016909563};\\\", \\\"{x:1498,y:927,t:1527016909588};\\\", \\\"{x:1497,y:926,t:1527016910004};\\\", \\\"{x:1495,y:924,t:1527016910035};\\\", \\\"{x:1495,y:921,t:1527016910046};\\\", \\\"{x:1494,y:918,t:1527016910062};\\\", \\\"{x:1493,y:917,t:1527016910079};\\\", \\\"{x:1493,y:916,t:1527016910291};\\\", \\\"{x:1491,y:915,t:1527016910299};\\\", \\\"{x:1484,y:915,t:1527016910312};\\\", \\\"{x:1483,y:915,t:1527016910329};\\\", \\\"{x:1475,y:916,t:1527016910345};\\\", \\\"{x:1460,y:921,t:1527016910363};\\\", \\\"{x:1449,y:921,t:1527016910379};\\\", \\\"{x:1441,y:921,t:1527016910396};\\\", \\\"{x:1440,y:921,t:1527016910413};\\\", \\\"{x:1435,y:920,t:1527016910429};\\\", \\\"{x:1432,y:919,t:1527016910446};\\\", \\\"{x:1429,y:919,t:1527016910462};\\\", \\\"{x:1429,y:917,t:1527016910636};\\\", \\\"{x:1429,y:916,t:1527016910646};\\\", \\\"{x:1429,y:914,t:1527016910663};\\\", \\\"{x:1429,y:912,t:1527016910679};\\\", \\\"{x:1426,y:908,t:1527016910697};\\\", \\\"{x:1426,y:906,t:1527016910713};\\\", \\\"{x:1425,y:905,t:1527016910729};\\\", \\\"{x:1425,y:903,t:1527016910746};\\\", \\\"{x:1425,y:902,t:1527016910763};\\\", \\\"{x:1426,y:903,t:1527016910874};\\\", \\\"{x:1429,y:907,t:1527016910882};\\\", \\\"{x:1434,y:910,t:1527016910896};\\\", \\\"{x:1441,y:915,t:1527016910912};\\\", \\\"{x:1445,y:918,t:1527016910929};\\\", \\\"{x:1448,y:921,t:1527016910945};\\\", \\\"{x:1454,y:924,t:1527016910962};\\\", \\\"{x:1458,y:925,t:1527016910980};\\\", \\\"{x:1463,y:928,t:1527016910996};\\\", \\\"{x:1463,y:929,t:1527016911013};\\\", \\\"{x:1465,y:931,t:1527016911030};\\\", \\\"{x:1470,y:931,t:1527016911046};\\\", \\\"{x:1475,y:932,t:1527016911063};\\\", \\\"{x:1477,y:934,t:1527016911080};\\\", \\\"{x:1478,y:935,t:1527016911095};\\\", \\\"{x:1479,y:935,t:1527016911113};\\\", \\\"{x:1478,y:935,t:1527016911259};\\\", \\\"{x:1471,y:935,t:1527016911267};\\\", \\\"{x:1462,y:935,t:1527016911279};\\\", \\\"{x:1447,y:935,t:1527016911296};\\\", \\\"{x:1443,y:935,t:1527016911313};\\\", \\\"{x:1431,y:936,t:1527016911329};\\\", \\\"{x:1423,y:936,t:1527016911347};\\\", \\\"{x:1421,y:936,t:1527016911363};\\\", \\\"{x:1418,y:936,t:1527016911380};\\\", \\\"{x:1416,y:935,t:1527016911397};\\\", \\\"{x:1415,y:935,t:1527016911413};\\\", \\\"{x:1414,y:934,t:1527016911430};\\\", \\\"{x:1412,y:935,t:1527016911715};\\\", \\\"{x:1412,y:937,t:1527016911730};\\\", \\\"{x:1412,y:938,t:1527016911747};\\\", \\\"{x:1412,y:941,t:1527016911844};\\\", \\\"{x:1412,y:943,t:1527016911851};\\\", \\\"{x:1412,y:944,t:1527016911864};\\\", \\\"{x:1412,y:946,t:1527016911880};\\\", \\\"{x:1412,y:947,t:1527016911897};\\\", \\\"{x:1412,y:948,t:1527016911979};\\\", \\\"{x:1415,y:948,t:1527016911997};\\\", \\\"{x:1424,y:949,t:1527016912014};\\\", \\\"{x:1429,y:951,t:1527016912030};\\\", \\\"{x:1429,y:952,t:1527016912048};\\\", \\\"{x:1430,y:953,t:1527016912083};\\\", \\\"{x:1432,y:953,t:1527016912139};\\\", \\\"{x:1435,y:953,t:1527016912163};\\\", \\\"{x:1440,y:953,t:1527016912180};\\\", \\\"{x:1443,y:953,t:1527016912197};\\\", \\\"{x:1449,y:953,t:1527016912214};\\\", \\\"{x:1461,y:953,t:1527016912231};\\\", \\\"{x:1469,y:953,t:1527016912247};\\\", \\\"{x:1476,y:953,t:1527016912265};\\\", \\\"{x:1477,y:953,t:1527016912282};\\\", \\\"{x:1476,y:954,t:1527016912564};\\\", \\\"{x:1475,y:955,t:1527016912582};\\\", \\\"{x:1474,y:955,t:1527016912597};\\\", \\\"{x:1473,y:956,t:1527016912637};\\\", \\\"{x:1471,y:957,t:1527016912669};\\\", \\\"{x:1470,y:958,t:1527016912682};\\\", \\\"{x:1468,y:958,t:1527016912698};\\\", \\\"{x:1466,y:958,t:1527016912716};\\\", \\\"{x:1465,y:959,t:1527016912732};\\\", \\\"{x:1464,y:959,t:1527016912749};\\\", \\\"{x:1463,y:960,t:1527016912765};\\\", \\\"{x:1461,y:962,t:1527016912783};\\\", \\\"{x:1454,y:966,t:1527016912799};\\\", \\\"{x:1445,y:970,t:1527016912815};\\\", \\\"{x:1442,y:973,t:1527016912832};\\\", \\\"{x:1440,y:974,t:1527016912849};\\\", \\\"{x:1434,y:975,t:1527016912865};\\\", \\\"{x:1433,y:977,t:1527016912882};\\\", \\\"{x:1432,y:977,t:1527016912899};\\\", \\\"{x:1433,y:977,t:1527016913212};\\\", \\\"{x:1435,y:976,t:1527016913220};\\\", \\\"{x:1436,y:975,t:1527016913233};\\\", \\\"{x:1438,y:975,t:1527016913249};\\\", \\\"{x:1443,y:973,t:1527016913266};\\\", \\\"{x:1448,y:970,t:1527016913282};\\\", \\\"{x:1451,y:968,t:1527016913299};\\\", \\\"{x:1451,y:967,t:1527016913332};\\\", \\\"{x:1453,y:966,t:1527016913349};\\\", \\\"{x:1454,y:965,t:1527016913366};\\\", \\\"{x:1456,y:965,t:1527016913383};\\\", \\\"{x:1461,y:963,t:1527016913400};\\\", \\\"{x:1464,y:962,t:1527016913416};\\\", \\\"{x:1468,y:959,t:1527016913432};\\\", \\\"{x:1470,y:958,t:1527016913449};\\\", \\\"{x:1471,y:958,t:1527016913467};\\\", \\\"{x:1472,y:958,t:1527016913482};\\\", \\\"{x:1473,y:958,t:1527016913500};\\\", \\\"{x:1474,y:957,t:1527016913524};\\\", \\\"{x:1475,y:957,t:1527016913821};\\\", \\\"{x:1476,y:957,t:1527016913833};\\\", \\\"{x:1482,y:954,t:1527016913849};\\\", \\\"{x:1484,y:953,t:1527016913866};\\\", \\\"{x:1486,y:951,t:1527016913884};\\\", \\\"{x:1487,y:951,t:1527016913900};\\\", \\\"{x:1487,y:952,t:1527016917388};\\\", \\\"{x:1486,y:952,t:1527016917403};\\\", \\\"{x:1481,y:956,t:1527016917420};\\\", \\\"{x:1479,y:957,t:1527016917436};\\\", \\\"{x:1478,y:957,t:1527016917460};\\\", \\\"{x:1477,y:957,t:1527016917541};\\\", \\\"{x:1476,y:957,t:1527016917572};\\\", \\\"{x:1474,y:955,t:1527016917585};\\\", \\\"{x:1468,y:927,t:1527016917602};\\\", \\\"{x:1467,y:909,t:1527016917619};\\\", \\\"{x:1467,y:907,t:1527016917635};\\\", \\\"{x:1467,y:906,t:1527016917652};\\\", \\\"{x:1468,y:899,t:1527016917669};\\\", \\\"{x:1471,y:892,t:1527016917685};\\\", \\\"{x:1473,y:888,t:1527016917702};\\\", \\\"{x:1475,y:884,t:1527016917719};\\\", \\\"{x:1476,y:883,t:1527016917740};\\\", \\\"{x:1476,y:882,t:1527016917788};\\\", \\\"{x:1476,y:881,t:1527016918004};\\\", \\\"{x:1476,y:882,t:1527016918212};\\\", \\\"{x:1476,y:883,t:1527016918220};\\\", \\\"{x:1476,y:885,t:1527016918236};\\\", \\\"{x:1475,y:887,t:1527016918252};\\\", \\\"{x:1475,y:888,t:1527016918270};\\\", \\\"{x:1475,y:889,t:1527016918292};\\\", \\\"{x:1475,y:890,t:1527016918302};\\\", \\\"{x:1475,y:892,t:1527016918319};\\\", \\\"{x:1475,y:893,t:1527016918336};\\\", \\\"{x:1475,y:894,t:1527016918353};\\\", \\\"{x:1475,y:897,t:1527016918369};\\\", \\\"{x:1475,y:904,t:1527016918386};\\\", \\\"{x:1475,y:907,t:1527016918404};\\\", \\\"{x:1475,y:911,t:1527016918420};\\\", \\\"{x:1475,y:912,t:1527016918436};\\\", \\\"{x:1474,y:912,t:1527016919660};\\\", \\\"{x:1474,y:911,t:1527016919670};\\\", \\\"{x:1474,y:910,t:1527016919688};\\\", \\\"{x:1474,y:909,t:1527016919704};\\\", \\\"{x:1474,y:908,t:1527016919740};\\\", \\\"{x:1474,y:907,t:1527016919795};\\\", \\\"{x:1474,y:905,t:1527016919803};\\\", \\\"{x:1469,y:892,t:1527016919820};\\\", \\\"{x:1463,y:881,t:1527016919837};\\\", \\\"{x:1457,y:873,t:1527016919854};\\\", \\\"{x:1452,y:867,t:1527016919870};\\\", \\\"{x:1449,y:862,t:1527016919887};\\\", \\\"{x:1447,y:859,t:1527016919904};\\\", \\\"{x:1447,y:858,t:1527016919955};\\\", \\\"{x:1447,y:855,t:1527016919972};\\\", \\\"{x:1445,y:854,t:1527016919987};\\\", \\\"{x:1442,y:849,t:1527016920004};\\\", \\\"{x:1441,y:846,t:1527016920020};\\\", \\\"{x:1440,y:843,t:1527016920037};\\\", \\\"{x:1439,y:841,t:1527016920054};\\\", \\\"{x:1439,y:839,t:1527016920070};\\\", \\\"{x:1437,y:838,t:1527016920087};\\\", \\\"{x:1437,y:836,t:1527016920165};\\\", \\\"{x:1437,y:835,t:1527016920204};\\\", \\\"{x:1439,y:833,t:1527016920221};\\\", \\\"{x:1440,y:833,t:1527016920237};\\\", \\\"{x:1442,y:832,t:1527016920255};\\\", \\\"{x:1443,y:831,t:1527016920324};\\\", \\\"{x:1444,y:830,t:1527016920337};\\\", \\\"{x:1446,y:829,t:1527016920355};\\\", \\\"{x:1447,y:828,t:1527016920371};\\\", \\\"{x:1450,y:828,t:1527016920388};\\\", \\\"{x:1450,y:827,t:1527016920452};\\\", \\\"{x:1450,y:825,t:1527016920692};\\\", \\\"{x:1450,y:823,t:1527016920705};\\\", \\\"{x:1444,y:816,t:1527016920721};\\\", \\\"{x:1436,y:803,t:1527016920739};\\\", \\\"{x:1426,y:791,t:1527016920754};\\\", \\\"{x:1414,y:780,t:1527016920772};\\\", \\\"{x:1406,y:776,t:1527016920788};\\\", \\\"{x:1392,y:767,t:1527016920804};\\\", \\\"{x:1388,y:765,t:1527016920835};\\\", \\\"{x:1386,y:764,t:1527016920843};\\\", \\\"{x:1386,y:763,t:1527016920854};\\\", \\\"{x:1386,y:762,t:1527016920871};\\\", \\\"{x:1385,y:762,t:1527016920932};\\\", \\\"{x:1384,y:762,t:1527016920939};\\\", \\\"{x:1383,y:762,t:1527016920955};\\\", \\\"{x:1382,y:762,t:1527016920972};\\\", \\\"{x:1381,y:762,t:1527016920988};\\\", \\\"{x:1380,y:762,t:1527016921020};\\\", \\\"{x:1379,y:762,t:1527016921028};\\\", \\\"{x:1376,y:762,t:1527016921052};\\\", \\\"{x:1375,y:762,t:1527016921068};\\\", \\\"{x:1371,y:762,t:1527016921076};\\\", \\\"{x:1367,y:764,t:1527016921088};\\\", \\\"{x:1359,y:766,t:1527016921104};\\\", \\\"{x:1354,y:769,t:1527016921121};\\\", \\\"{x:1351,y:770,t:1527016921138};\\\", \\\"{x:1349,y:770,t:1527016921154};\\\", \\\"{x:1348,y:772,t:1527016921172};\\\", \\\"{x:1347,y:772,t:1527016921195};\\\", \\\"{x:1346,y:773,t:1527016921228};\\\", \\\"{x:1344,y:773,t:1527016921260};\\\", \\\"{x:1343,y:774,t:1527016921276};\\\", \\\"{x:1347,y:773,t:1527016921596};\\\", \\\"{x:1350,y:772,t:1527016921605};\\\", \\\"{x:1354,y:771,t:1527016921621};\\\", \\\"{x:1355,y:769,t:1527016921639};\\\", \\\"{x:1358,y:769,t:1527016921660};\\\", \\\"{x:1359,y:769,t:1527016921684};\\\", \\\"{x:1361,y:769,t:1527016921740};\\\", \\\"{x:1363,y:768,t:1527016921755};\\\", \\\"{x:1365,y:767,t:1527016921772};\\\", \\\"{x:1368,y:765,t:1527016921788};\\\", \\\"{x:1371,y:764,t:1527016921805};\\\", \\\"{x:1373,y:763,t:1527016921823};\\\", \\\"{x:1375,y:762,t:1527016921844};\\\", \\\"{x:1376,y:761,t:1527016921856};\\\", \\\"{x:1379,y:761,t:1527016921873};\\\", \\\"{x:1385,y:762,t:1527016921889};\\\", \\\"{x:1387,y:762,t:1527016921906};\\\", \\\"{x:1389,y:764,t:1527016921923};\\\", \\\"{x:1390,y:764,t:1527016921938};\\\", \\\"{x:1395,y:764,t:1527016921956};\\\", \\\"{x:1396,y:764,t:1527016922012};\\\", \\\"{x:1397,y:764,t:1527016922069};\\\", \\\"{x:1399,y:764,t:1527016922100};\\\", \\\"{x:1400,y:764,t:1527016922124};\\\", \\\"{x:1402,y:764,t:1527016922148};\\\", \\\"{x:1404,y:763,t:1527016922164};\\\", \\\"{x:1405,y:763,t:1527016922180};\\\", \\\"{x:1405,y:762,t:1527016922190};\\\", \\\"{x:1406,y:761,t:1527016922365};\\\", \\\"{x:1413,y:761,t:1527016923660};\\\", \\\"{x:1418,y:761,t:1527016923675};\\\", \\\"{x:1423,y:761,t:1527016923691};\\\", \\\"{x:1426,y:759,t:1527016923706};\\\", \\\"{x:1426,y:758,t:1527016923724};\\\", \\\"{x:1428,y:757,t:1527016923748};\\\", \\\"{x:1429,y:756,t:1527016923796};\\\", \\\"{x:1430,y:756,t:1527016923807};\\\", \\\"{x:1431,y:756,t:1527016923824};\\\", \\\"{x:1432,y:756,t:1527016923841};\\\", \\\"{x:1433,y:756,t:1527016923909};\\\", \\\"{x:1436,y:756,t:1527016923948};\\\", \\\"{x:1438,y:756,t:1527016923964};\\\", \\\"{x:1439,y:756,t:1527016923974};\\\", \\\"{x:1443,y:756,t:1527016923991};\\\", \\\"{x:1447,y:757,t:1527016924006};\\\", \\\"{x:1452,y:759,t:1527016924023};\\\", \\\"{x:1453,y:760,t:1527016924040};\\\", \\\"{x:1457,y:762,t:1527016924057};\\\", \\\"{x:1457,y:763,t:1527016924084};\\\", \\\"{x:1457,y:764,t:1527016924821};\\\", \\\"{x:1456,y:765,t:1527016925557};\\\", \\\"{x:1455,y:765,t:1527016926733};\\\", \\\"{x:1455,y:766,t:1527016926868};\\\", \\\"{x:1454,y:766,t:1527016926884};\\\", \\\"{x:1454,y:767,t:1527016926892};\\\", \\\"{x:1452,y:767,t:1527016927140};\\\", \\\"{x:1451,y:767,t:1527016927221};\\\", \\\"{x:1449,y:767,t:1527016927236};\\\", \\\"{x:1445,y:769,t:1527016927244};\\\", \\\"{x:1438,y:769,t:1527016927260};\\\", \\\"{x:1435,y:769,t:1527016927275};\\\", \\\"{x:1427,y:769,t:1527016927293};\\\", \\\"{x:1422,y:769,t:1527016927310};\\\", \\\"{x:1419,y:769,t:1527016927325};\\\", \\\"{x:1413,y:769,t:1527016927343};\\\", \\\"{x:1409,y:768,t:1527016927359};\\\", \\\"{x:1397,y:765,t:1527016927377};\\\", \\\"{x:1379,y:763,t:1527016927393};\\\", \\\"{x:1367,y:762,t:1527016927410};\\\", \\\"{x:1366,y:762,t:1527016927427};\\\", \\\"{x:1364,y:762,t:1527016927451};\\\", \\\"{x:1362,y:762,t:1527016927467};\\\", \\\"{x:1360,y:762,t:1527016927476};\\\", \\\"{x:1360,y:761,t:1527016927803};\\\", \\\"{x:1362,y:761,t:1527016927811};\\\", \\\"{x:1363,y:761,t:1527016927826};\\\", \\\"{x:1364,y:761,t:1527016927843};\\\", \\\"{x:1367,y:761,t:1527016927859};\\\", \\\"{x:1370,y:761,t:1527016927876};\\\", \\\"{x:1374,y:761,t:1527016927893};\\\", \\\"{x:1379,y:761,t:1527016927910};\\\", \\\"{x:1385,y:761,t:1527016927926};\\\", \\\"{x:1393,y:761,t:1527016927943};\\\", \\\"{x:1396,y:761,t:1527016927959};\\\", \\\"{x:1397,y:760,t:1527016927977};\\\", \\\"{x:1400,y:757,t:1527016927993};\\\", \\\"{x:1405,y:757,t:1527016928009};\\\", \\\"{x:1409,y:757,t:1527016928026};\\\", \\\"{x:1410,y:757,t:1527016928044};\\\", \\\"{x:1413,y:758,t:1527016928059};\\\", \\\"{x:1417,y:759,t:1527016928076};\\\", \\\"{x:1419,y:761,t:1527016928094};\\\", \\\"{x:1420,y:761,t:1527016928110};\\\", \\\"{x:1420,y:762,t:1527016928236};\\\", \\\"{x:1422,y:762,t:1527016928436};\\\", \\\"{x:1424,y:762,t:1527016928444};\\\", \\\"{x:1427,y:762,t:1527016928460};\\\", \\\"{x:1429,y:762,t:1527016928477};\\\", \\\"{x:1431,y:762,t:1527016928494};\\\", \\\"{x:1433,y:762,t:1527016928510};\\\", \\\"{x:1435,y:762,t:1527016928527};\\\", \\\"{x:1439,y:762,t:1527016928544};\\\", \\\"{x:1440,y:762,t:1527016928561};\\\", \\\"{x:1441,y:762,t:1527016928577};\\\", \\\"{x:1443,y:762,t:1527016928593};\\\", \\\"{x:1444,y:762,t:1527016929052};\\\", \\\"{x:1445,y:762,t:1527016929996};\\\", \\\"{x:1445,y:763,t:1527016930012};\\\", \\\"{x:1445,y:766,t:1527016930044};\\\", \\\"{x:1439,y:767,t:1527016930062};\\\", \\\"{x:1427,y:765,t:1527016930078};\\\", \\\"{x:1423,y:761,t:1527016930094};\\\", \\\"{x:1420,y:759,t:1527016930112};\\\", \\\"{x:1417,y:759,t:1527016930128};\\\", \\\"{x:1421,y:759,t:1527016930524};\\\", \\\"{x:1423,y:759,t:1527016930532};\\\", \\\"{x:1427,y:759,t:1527016930545};\\\", \\\"{x:1429,y:759,t:1527016930561};\\\", \\\"{x:1431,y:759,t:1527016930636};\\\", \\\"{x:1432,y:759,t:1527016930652};\\\", \\\"{x:1432,y:760,t:1527016930772};\\\", \\\"{x:1432,y:762,t:1527016930787};\\\", \\\"{x:1428,y:762,t:1527016930795};\\\", \\\"{x:1419,y:762,t:1527016930811};\\\", \\\"{x:1404,y:762,t:1527016930828};\\\", \\\"{x:1386,y:760,t:1527016930845};\\\", \\\"{x:1374,y:758,t:1527016930861};\\\", \\\"{x:1373,y:758,t:1527016930878};\\\", \\\"{x:1369,y:758,t:1527016930895};\\\", \\\"{x:1365,y:758,t:1527016930915};\\\", \\\"{x:1364,y:758,t:1527016930929};\\\", \\\"{x:1363,y:758,t:1527016930946};\\\", \\\"{x:1358,y:758,t:1527016930962};\\\", \\\"{x:1344,y:758,t:1527016930978};\\\", \\\"{x:1333,y:758,t:1527016930995};\\\", \\\"{x:1328,y:758,t:1527016931011};\\\", \\\"{x:1313,y:757,t:1527016931029};\\\", \\\"{x:1295,y:754,t:1527016931046};\\\", \\\"{x:1269,y:754,t:1527016931062};\\\", \\\"{x:1261,y:750,t:1527016931079};\\\", \\\"{x:1254,y:747,t:1527016931095};\\\", \\\"{x:1241,y:746,t:1527016931112};\\\", \\\"{x:1222,y:746,t:1527016931128};\\\", \\\"{x:1214,y:746,t:1527016931145};\\\", \\\"{x:1205,y:746,t:1527016931163};\\\", \\\"{x:1180,y:744,t:1527016931179};\\\", \\\"{x:1158,y:743,t:1527016931196};\\\", \\\"{x:1156,y:743,t:1527016931212};\\\", \\\"{x:1151,y:743,t:1527016931229};\\\", \\\"{x:1143,y:741,t:1527016931246};\\\", \\\"{x:1137,y:739,t:1527016931263};\\\", \\\"{x:1136,y:739,t:1527016931279};\\\", \\\"{x:1136,y:738,t:1527016931300};\\\", \\\"{x:1135,y:738,t:1527016931356};\\\", \\\"{x:1134,y:738,t:1527016931379};\\\", \\\"{x:1128,y:738,t:1527016931395};\\\", \\\"{x:1116,y:736,t:1527016931412};\\\", \\\"{x:1105,y:734,t:1527016931429};\\\", \\\"{x:1094,y:731,t:1527016931446};\\\", \\\"{x:1076,y:728,t:1527016931463};\\\", \\\"{x:1065,y:728,t:1527016931479};\\\", \\\"{x:1062,y:727,t:1527016931500};\\\", \\\"{x:1055,y:726,t:1527016931513};\\\", \\\"{x:1035,y:726,t:1527016931529};\\\", \\\"{x:1026,y:726,t:1527016931546};\\\", \\\"{x:1010,y:726,t:1527016931563};\\\", \\\"{x:999,y:726,t:1527016931580};\\\", \\\"{x:996,y:725,t:1527016931596};\\\", \\\"{x:994,y:723,t:1527016931613};\\\", \\\"{x:990,y:719,t:1527016931630};\\\", \\\"{x:983,y:717,t:1527016931646};\\\", \\\"{x:964,y:715,t:1527016931663};\\\", \\\"{x:954,y:715,t:1527016931680};\\\", \\\"{x:928,y:715,t:1527016931696};\\\", \\\"{x:892,y:715,t:1527016931712};\\\", \\\"{x:851,y:718,t:1527016931729};\\\", \\\"{x:782,y:718,t:1527016931746};\\\", \\\"{x:721,y:716,t:1527016931763};\\\", \\\"{x:659,y:708,t:1527016931780};\\\", \\\"{x:599,y:694,t:1527016931796};\\\", \\\"{x:585,y:685,t:1527016931812};\\\", \\\"{x:563,y:677,t:1527016931830};\\\", \\\"{x:552,y:675,t:1527016931846};\\\", \\\"{x:550,y:674,t:1527016931868};\\\", \\\"{x:547,y:674,t:1527016931879};\\\", \\\"{x:542,y:674,t:1527016931895};\\\", \\\"{x:537,y:675,t:1527016931912};\\\", \\\"{x:525,y:675,t:1527016931930};\\\", \\\"{x:521,y:675,t:1527016931946};\\\", \\\"{x:514,y:675,t:1527016931962};\\\", \\\"{x:484,y:660,t:1527016931981};\\\", \\\"{x:467,y:644,t:1527016931996};\\\", \\\"{x:455,y:634,t:1527016932012};\\\", \\\"{x:439,y:624,t:1527016932029};\\\", \\\"{x:425,y:613,t:1527016932046};\\\", \\\"{x:413,y:602,t:1527016932063};\\\", \\\"{x:406,y:594,t:1527016932081};\\\", \\\"{x:398,y:593,t:1527016932097};\\\", \\\"{x:391,y:593,t:1527016932114};\\\", \\\"{x:384,y:593,t:1527016932130};\\\", \\\"{x:383,y:592,t:1527016932147};\\\", \\\"{x:379,y:592,t:1527016932164};\\\", \\\"{x:363,y:590,t:1527016932182};\\\", \\\"{x:338,y:587,t:1527016932196};\\\", \\\"{x:312,y:578,t:1527016932214};\\\", \\\"{x:302,y:573,t:1527016932231};\\\", \\\"{x:289,y:572,t:1527016932247};\\\", \\\"{x:283,y:572,t:1527016932264};\\\", \\\"{x:276,y:573,t:1527016932281};\\\", \\\"{x:269,y:577,t:1527016932298};\\\", \\\"{x:260,y:578,t:1527016932314};\\\", \\\"{x:250,y:582,t:1527016932330};\\\", \\\"{x:244,y:582,t:1527016932347};\\\", \\\"{x:243,y:582,t:1527016932364};\\\", \\\"{x:240,y:581,t:1527016932381};\\\", \\\"{x:233,y:576,t:1527016932398};\\\", \\\"{x:227,y:574,t:1527016932414};\\\", \\\"{x:223,y:570,t:1527016932431};\\\", \\\"{x:217,y:570,t:1527016932447};\\\", \\\"{x:214,y:569,t:1527016932465};\\\", \\\"{x:211,y:569,t:1527016932481};\\\", \\\"{x:210,y:569,t:1527016932497};\\\", \\\"{x:209,y:569,t:1527016932514};\\\", \\\"{x:208,y:569,t:1527016932531};\\\", \\\"{x:206,y:567,t:1527016932548};\\\", \\\"{x:203,y:566,t:1527016932564};\\\", \\\"{x:202,y:566,t:1527016932595};\\\", \\\"{x:198,y:565,t:1527016932602};\\\", \\\"{x:195,y:565,t:1527016932614};\\\", \\\"{x:193,y:565,t:1527016932632};\\\", \\\"{x:192,y:565,t:1527016932648};\\\", \\\"{x:190,y:565,t:1527016932666};\\\", \\\"{x:189,y:565,t:1527016932681};\\\", \\\"{x:187,y:565,t:1527016932698};\\\", \\\"{x:185,y:565,t:1527016932714};\\\", \\\"{x:181,y:563,t:1527016932731};\\\", \\\"{x:177,y:562,t:1527016932748};\\\", \\\"{x:177,y:561,t:1527016932764};\\\", \\\"{x:176,y:561,t:1527016932828};\\\", \\\"{x:179,y:563,t:1527016933580};\\\", \\\"{x:189,y:563,t:1527016933587};\\\", \\\"{x:197,y:564,t:1527016933599};\\\", \\\"{x:210,y:565,t:1527016933615};\\\", \\\"{x:262,y:576,t:1527016933632};\\\", \\\"{x:347,y:595,t:1527016933650};\\\", \\\"{x:452,y:611,t:1527016933665};\\\", \\\"{x:565,y:638,t:1527016933682};\\\", \\\"{x:668,y:658,t:1527016933699};\\\", \\\"{x:809,y:677,t:1527016933715};\\\", \\\"{x:866,y:681,t:1527016933732};\\\", \\\"{x:956,y:689,t:1527016933749};\\\", \\\"{x:1008,y:695,t:1527016933765};\\\", \\\"{x:1076,y:713,t:1527016933782};\\\", \\\"{x:1096,y:720,t:1527016933800};\\\", \\\"{x:1130,y:726,t:1527016933815};\\\", \\\"{x:1146,y:733,t:1527016933833};\\\", \\\"{x:1164,y:740,t:1527016933849};\\\", \\\"{x:1186,y:747,t:1527016933866};\\\", \\\"{x:1198,y:754,t:1527016933882};\\\", \\\"{x:1236,y:760,t:1527016933900};\\\", \\\"{x:1260,y:760,t:1527016933916};\\\", \\\"{x:1288,y:760,t:1527016933932};\\\", \\\"{x:1299,y:758,t:1527016933950};\\\", \\\"{x:1310,y:757,t:1527016933966};\\\", \\\"{x:1312,y:757,t:1527016933983};\\\", \\\"{x:1317,y:757,t:1527016934000};\\\", \\\"{x:1323,y:756,t:1527016934017};\\\", \\\"{x:1329,y:755,t:1527016934033};\\\", \\\"{x:1334,y:755,t:1527016934050};\\\", \\\"{x:1337,y:755,t:1527016934067};\\\", \\\"{x:1342,y:754,t:1527016934084};\\\", \\\"{x:1343,y:753,t:1527016934100};\\\", \\\"{x:1345,y:750,t:1527016934117};\\\", \\\"{x:1346,y:749,t:1527016934132};\\\", \\\"{x:1346,y:748,t:1527016934196};\\\", \\\"{x:1346,y:746,t:1527016934212};\\\", \\\"{x:1346,y:743,t:1527016934221};\\\", \\\"{x:1346,y:740,t:1527016934233};\\\", \\\"{x:1344,y:738,t:1527016934250};\\\", \\\"{x:1343,y:736,t:1527016934267};\\\", \\\"{x:1343,y:735,t:1527016934283};\\\", \\\"{x:1338,y:732,t:1527016934300};\\\", \\\"{x:1337,y:731,t:1527016934317};\\\", \\\"{x:1337,y:727,t:1527016934334};\\\", \\\"{x:1337,y:719,t:1527016934350};\\\", \\\"{x:1337,y:714,t:1527016934367};\\\", \\\"{x:1338,y:707,t:1527016934384};\\\", \\\"{x:1341,y:704,t:1527016934400};\\\", \\\"{x:1342,y:702,t:1527016934416};\\\", \\\"{x:1342,y:701,t:1527016934451};\\\", \\\"{x:1344,y:701,t:1527016934476};\\\", \\\"{x:1345,y:699,t:1527016934515};\\\", \\\"{x:1346,y:698,t:1527016934523};\\\", \\\"{x:1348,y:693,t:1527016934533};\\\", \\\"{x:1349,y:691,t:1527016934555};\\\", \\\"{x:1349,y:690,t:1527016934579};\\\", \\\"{x:1350,y:687,t:1527016934587};\\\", \\\"{x:1350,y:683,t:1527016934600};\\\", \\\"{x:1350,y:681,t:1527016934616};\\\", \\\"{x:1350,y:679,t:1527016934699};\\\", \\\"{x:1350,y:677,t:1527016934707};\\\", \\\"{x:1350,y:673,t:1527016934716};\\\", \\\"{x:1350,y:662,t:1527016934733};\\\", \\\"{x:1349,y:653,t:1527016934750};\\\", \\\"{x:1349,y:646,t:1527016934767};\\\", \\\"{x:1348,y:641,t:1527016934784};\\\", \\\"{x:1346,y:639,t:1527016934801};\\\", \\\"{x:1345,y:638,t:1527016934817};\\\", \\\"{x:1338,y:633,t:1527016934833};\\\", \\\"{x:1336,y:633,t:1527016934851};\\\", \\\"{x:1335,y:633,t:1527016934867};\\\", \\\"{x:1325,y:632,t:1527016934884};\\\", \\\"{x:1322,y:630,t:1527016934901};\\\", \\\"{x:1321,y:630,t:1527016934932};\\\", \\\"{x:1321,y:629,t:1527016935098};\\\", \\\"{x:1321,y:628,t:1527016935107};\\\", \\\"{x:1321,y:625,t:1527016935118};\\\", \\\"{x:1324,y:621,t:1527016935133};\\\", \\\"{x:1328,y:618,t:1527016935151};\\\", \\\"{x:1330,y:618,t:1527016935168};\\\", \\\"{x:1331,y:616,t:1527016935187};\\\", \\\"{x:1332,y:616,t:1527016935292};\\\", \\\"{x:1333,y:616,t:1527016935508};\\\", \\\"{x:1336,y:616,t:1527016935564};\\\", \\\"{x:1339,y:616,t:1527016935580};\\\", \\\"{x:1340,y:616,t:1527016935596};\\\", \\\"{x:1341,y:616,t:1527016935604};\\\", \\\"{x:1343,y:615,t:1527016935619};\\\", \\\"{x:1344,y:615,t:1527016935635};\\\", \\\"{x:1346,y:614,t:1527016935652};\\\", \\\"{x:1348,y:612,t:1527016935668};\\\", \\\"{x:1350,y:611,t:1527016935700};\\\", \\\"{x:1350,y:610,t:1527016935780};\\\", \\\"{x:1350,y:609,t:1527016935859};\\\", \\\"{x:1349,y:605,t:1527016935869};\\\", \\\"{x:1346,y:597,t:1527016935885};\\\", \\\"{x:1346,y:590,t:1527016935901};\\\", \\\"{x:1344,y:585,t:1527016935919};\\\", \\\"{x:1344,y:581,t:1527016935935};\\\", \\\"{x:1344,y:580,t:1527016935951};\\\", \\\"{x:1344,y:579,t:1527016935968};\\\", \\\"{x:1344,y:577,t:1527016936068};\\\", \\\"{x:1345,y:574,t:1527016936086};\\\", \\\"{x:1348,y:571,t:1527016936102};\\\", \\\"{x:1350,y:569,t:1527016936119};\\\", \\\"{x:1351,y:568,t:1527016936135};\\\", \\\"{x:1352,y:567,t:1527016936276};\\\", \\\"{x:1352,y:566,t:1527016936396};\\\", \\\"{x:1351,y:566,t:1527016936492};\\\", \\\"{x:1351,y:565,t:1527016936503};\\\", \\\"{x:1350,y:563,t:1527016936532};\\\", \\\"{x:1349,y:563,t:1527016936564};\\\", \\\"{x:1348,y:563,t:1527016936571};\\\", \\\"{x:1346,y:563,t:1527016936596};\\\", \\\"{x:1342,y:563,t:1527016936604};\\\", \\\"{x:1341,y:563,t:1527016936619};\\\", \\\"{x:1337,y:562,t:1527016936636};\\\", \\\"{x:1336,y:562,t:1527016936653};\\\", \\\"{x:1335,y:562,t:1527016936669};\\\", \\\"{x:1335,y:560,t:1527016936860};\\\", \\\"{x:1337,y:560,t:1527016936870};\\\", \\\"{x:1341,y:557,t:1527016936886};\\\", \\\"{x:1343,y:556,t:1527016936903};\\\", \\\"{x:1344,y:556,t:1527016936932};\\\", \\\"{x:1345,y:556,t:1527016937140};\\\", \\\"{x:1349,y:555,t:1527016937153};\\\", \\\"{x:1358,y:555,t:1527016937170};\\\", \\\"{x:1376,y:559,t:1527016937187};\\\", \\\"{x:1395,y:564,t:1527016937203};\\\", \\\"{x:1402,y:566,t:1527016937220};\\\", \\\"{x:1403,y:566,t:1527016937237};\\\", \\\"{x:1404,y:566,t:1527016937668};\\\", \\\"{x:1405,y:566,t:1527016937699};\\\", \\\"{x:1406,y:566,t:1527016937836};\\\", \\\"{x:1407,y:566,t:1527016937854};\\\", \\\"{x:1407,y:565,t:1527016937871};\\\", \\\"{x:1408,y:565,t:1527016937892};\\\", \\\"{x:1408,y:564,t:1527016937908};\\\", \\\"{x:1409,y:564,t:1527016938765};\\\", \\\"{x:1410,y:564,t:1527016938771};\\\", \\\"{x:1412,y:564,t:1527016938788};\\\", \\\"{x:1417,y:563,t:1527016938805};\\\", \\\"{x:1429,y:563,t:1527016938823};\\\", \\\"{x:1445,y:563,t:1527016938839};\\\", \\\"{x:1466,y:563,t:1527016938855};\\\", \\\"{x:1472,y:563,t:1527016938872};\\\", \\\"{x:1477,y:563,t:1527016938889};\\\", \\\"{x:1479,y:563,t:1527016938905};\\\", \\\"{x:1478,y:563,t:1527016939100};\\\", \\\"{x:1478,y:564,t:1527016939140};\\\", \\\"{x:1477,y:566,t:1527016939172};\\\", \\\"{x:1471,y:569,t:1527016939189};\\\", \\\"{x:1463,y:571,t:1527016939206};\\\", \\\"{x:1460,y:572,t:1527016939223};\\\", \\\"{x:1456,y:572,t:1527016939239};\\\", \\\"{x:1450,y:572,t:1527016939256};\\\", \\\"{x:1447,y:572,t:1527016939272};\\\", \\\"{x:1446,y:572,t:1527016939289};\\\", \\\"{x:1445,y:572,t:1527016939306};\\\", \\\"{x:1443,y:572,t:1527016939322};\\\", \\\"{x:1438,y:574,t:1527016939339};\\\", \\\"{x:1435,y:575,t:1527016939356};\\\", \\\"{x:1434,y:576,t:1527016939373};\\\", \\\"{x:1433,y:576,t:1527016939390};\\\", \\\"{x:1434,y:575,t:1527016939476};\\\", \\\"{x:1434,y:573,t:1527016939580};\\\", \\\"{x:1435,y:572,t:1527016939589};\\\", \\\"{x:1436,y:571,t:1527016939607};\\\", \\\"{x:1437,y:570,t:1527016939627};\\\", \\\"{x:1439,y:569,t:1527016939644};\\\", \\\"{x:1439,y:568,t:1527016939660};\\\", \\\"{x:1442,y:567,t:1527016939675};\\\", \\\"{x:1443,y:566,t:1527016939708};\\\", \\\"{x:1445,y:565,t:1527016939732};\\\", \\\"{x:1445,y:566,t:1527016943316};\\\", \\\"{x:1444,y:569,t:1527016943327};\\\", \\\"{x:1441,y:587,t:1527016943344};\\\", \\\"{x:1428,y:614,t:1527016943361};\\\", \\\"{x:1399,y:665,t:1527016943377};\\\", \\\"{x:1386,y:700,t:1527016943395};\\\", \\\"{x:1357,y:734,t:1527016943410};\\\", \\\"{x:1310,y:796,t:1527016943428};\\\", \\\"{x:1280,y:826,t:1527016943444};\\\", \\\"{x:1258,y:848,t:1527016943461};\\\", \\\"{x:1252,y:859,t:1527016943477};\\\", \\\"{x:1250,y:861,t:1527016943495};\\\", \\\"{x:1249,y:861,t:1527016943511};\\\", \\\"{x:1249,y:862,t:1527016943531};\\\", \\\"{x:1248,y:862,t:1527016943563};\\\", \\\"{x:1247,y:862,t:1527016943579};\\\", \\\"{x:1246,y:861,t:1527016943594};\\\", \\\"{x:1243,y:852,t:1527016943611};\\\", \\\"{x:1242,y:847,t:1527016943627};\\\", \\\"{x:1242,y:841,t:1527016943644};\\\", \\\"{x:1240,y:835,t:1527016943661};\\\", \\\"{x:1240,y:834,t:1527016943677};\\\", \\\"{x:1238,y:831,t:1527016943694};\\\", \\\"{x:1236,y:826,t:1527016943711};\\\", \\\"{x:1236,y:819,t:1527016943727};\\\", \\\"{x:1236,y:817,t:1527016943745};\\\", \\\"{x:1236,y:814,t:1527016943762};\\\", \\\"{x:1235,y:808,t:1527016943778};\\\", \\\"{x:1235,y:804,t:1527016943795};\\\", \\\"{x:1240,y:789,t:1527016943811};\\\", \\\"{x:1243,y:784,t:1527016943828};\\\", \\\"{x:1246,y:778,t:1527016943844};\\\", \\\"{x:1248,y:777,t:1527016943862};\\\", \\\"{x:1249,y:775,t:1527016943878};\\\", \\\"{x:1249,y:773,t:1527016943987};\\\", \\\"{x:1249,y:772,t:1527016944436};\\\", \\\"{x:1250,y:771,t:1527016944446};\\\", \\\"{x:1251,y:768,t:1527016944595};\\\", \\\"{x:1255,y:765,t:1527016944612};\\\", \\\"{x:1260,y:763,t:1527016944629};\\\", \\\"{x:1273,y:759,t:1527016944646};\\\", \\\"{x:1284,y:756,t:1527016944663};\\\", \\\"{x:1300,y:756,t:1527016944679};\\\", \\\"{x:1312,y:756,t:1527016944695};\\\", \\\"{x:1320,y:756,t:1527016944713};\\\", \\\"{x:1325,y:760,t:1527016944730};\\\", \\\"{x:1330,y:763,t:1527016944746};\\\", \\\"{x:1332,y:763,t:1527016944763};\\\", \\\"{x:1333,y:763,t:1527016944779};\\\", \\\"{x:1334,y:763,t:1527016945132};\\\", \\\"{x:1338,y:763,t:1527016945147};\\\", \\\"{x:1345,y:764,t:1527016945163};\\\", \\\"{x:1354,y:765,t:1527016945181};\\\", \\\"{x:1361,y:765,t:1527016945196};\\\", \\\"{x:1375,y:765,t:1527016945212};\\\", \\\"{x:1377,y:765,t:1527016945229};\\\", \\\"{x:1378,y:765,t:1527016945246};\\\", \\\"{x:1379,y:765,t:1527016945332};\\\", \\\"{x:1379,y:766,t:1527016946708};\\\", \\\"{x:1381,y:766,t:1527016947747};\\\", \\\"{x:1386,y:764,t:1527016947754};\\\", \\\"{x:1391,y:761,t:1527016947765};\\\", \\\"{x:1399,y:755,t:1527016947782};\\\", \\\"{x:1402,y:757,t:1527016948755};\\\", \\\"{x:1402,y:760,t:1527016948766};\\\", \\\"{x:1402,y:767,t:1527016948784};\\\", \\\"{x:1402,y:769,t:1527016948800};\\\", \\\"{x:1404,y:772,t:1527016948817};\\\", \\\"{x:1404,y:781,t:1527016948833};\\\", \\\"{x:1404,y:782,t:1527016948963};\\\", \\\"{x:1404,y:784,t:1527016949060};\\\", \\\"{x:1400,y:789,t:1527016949075};\\\", \\\"{x:1391,y:798,t:1527016949084};\\\", \\\"{x:1384,y:807,t:1527016949101};\\\", \\\"{x:1380,y:812,t:1527016949118};\\\", \\\"{x:1377,y:813,t:1527016949134};\\\", \\\"{x:1374,y:818,t:1527016949150};\\\", \\\"{x:1373,y:819,t:1527016949168};\\\", \\\"{x:1372,y:820,t:1527016949620};\\\", \\\"{x:1370,y:821,t:1527016949635};\\\", \\\"{x:1368,y:823,t:1527016949651};\\\", \\\"{x:1366,y:824,t:1527016949667};\\\", \\\"{x:1365,y:824,t:1527016949706};\\\", \\\"{x:1364,y:826,t:1527016949762};\\\", \\\"{x:1363,y:827,t:1527016949770};\\\", \\\"{x:1362,y:829,t:1527016949786};\\\", \\\"{x:1362,y:830,t:1527016949801};\\\", \\\"{x:1362,y:832,t:1527016949819};\\\", \\\"{x:1362,y:834,t:1527016949834};\\\", \\\"{x:1362,y:844,t:1527016949851};\\\", \\\"{x:1364,y:852,t:1527016949868};\\\", \\\"{x:1365,y:857,t:1527016949884};\\\", \\\"{x:1368,y:859,t:1527016949901};\\\", \\\"{x:1368,y:861,t:1527016949918};\\\", \\\"{x:1368,y:863,t:1527016949988};\\\", \\\"{x:1369,y:863,t:1527016950001};\\\", \\\"{x:1369,y:864,t:1527016950027};\\\", \\\"{x:1371,y:867,t:1527016950163};\\\", \\\"{x:1371,y:870,t:1527016950172};\\\", \\\"{x:1371,y:871,t:1527016950185};\\\", \\\"{x:1373,y:876,t:1527016950201};\\\", \\\"{x:1373,y:877,t:1527016950218};\\\", \\\"{x:1374,y:880,t:1527016950235};\\\", \\\"{x:1375,y:881,t:1527016950251};\\\", \\\"{x:1376,y:880,t:1527016952356};\\\", \\\"{x:1379,y:869,t:1527016952371};\\\", \\\"{x:1399,y:826,t:1527016952387};\\\", \\\"{x:1415,y:792,t:1527016952405};\\\", \\\"{x:1440,y:755,t:1527016952422};\\\", \\\"{x:1458,y:711,t:1527016952438};\\\", \\\"{x:1468,y:685,t:1527016952454};\\\", \\\"{x:1483,y:658,t:1527016952471};\\\", \\\"{x:1495,y:634,t:1527016952488};\\\", \\\"{x:1506,y:618,t:1527016952504};\\\", \\\"{x:1513,y:603,t:1527016952521};\\\", \\\"{x:1516,y:592,t:1527016952538};\\\", \\\"{x:1518,y:590,t:1527016952555};\\\", \\\"{x:1517,y:589,t:1527016952698};\\\", \\\"{x:1505,y:589,t:1527016952706};\\\", \\\"{x:1497,y:589,t:1527016952721};\\\", \\\"{x:1471,y:594,t:1527016952738};\\\", \\\"{x:1444,y:611,t:1527016952754};\\\", \\\"{x:1420,y:625,t:1527016952771};\\\", \\\"{x:1392,y:636,t:1527016952788};\\\", \\\"{x:1384,y:643,t:1527016952804};\\\", \\\"{x:1375,y:646,t:1527016952821};\\\", \\\"{x:1374,y:646,t:1527016952839};\\\", \\\"{x:1372,y:646,t:1527016952915};\\\", \\\"{x:1367,y:644,t:1527016952923};\\\", \\\"{x:1363,y:635,t:1527016952939};\\\", \\\"{x:1351,y:615,t:1527016952955};\\\", \\\"{x:1340,y:603,t:1527016952971};\\\", \\\"{x:1337,y:602,t:1527016952988};\\\", \\\"{x:1335,y:600,t:1527016953006};\\\", \\\"{x:1332,y:596,t:1527016953021};\\\", \\\"{x:1330,y:595,t:1527016953038};\\\", \\\"{x:1328,y:593,t:1527016953056};\\\", \\\"{x:1322,y:593,t:1527016953180};\\\", \\\"{x:1320,y:593,t:1527016953189};\\\", \\\"{x:1312,y:592,t:1527016953205};\\\", \\\"{x:1304,y:591,t:1527016953222};\\\", \\\"{x:1297,y:591,t:1527016953239};\\\", \\\"{x:1295,y:591,t:1527016953256};\\\", \\\"{x:1292,y:589,t:1527016953272};\\\", \\\"{x:1291,y:589,t:1527016953475};\\\", \\\"{x:1291,y:587,t:1527016953488};\\\", \\\"{x:1291,y:580,t:1527016953506};\\\", \\\"{x:1291,y:577,t:1527016953523};\\\", \\\"{x:1291,y:576,t:1527016953547};\\\", \\\"{x:1291,y:575,t:1527016953675};\\\", \\\"{x:1290,y:573,t:1527016953707};\\\", \\\"{x:1290,y:572,t:1527016953723};\\\", \\\"{x:1290,y:569,t:1527016953740};\\\", \\\"{x:1290,y:568,t:1527016953828};\\\", \\\"{x:1292,y:567,t:1527016953839};\\\", \\\"{x:1293,y:565,t:1527016953875};\\\", \\\"{x:1295,y:563,t:1527016953890};\\\", \\\"{x:1300,y:563,t:1527016953906};\\\", \\\"{x:1303,y:561,t:1527016953923};\\\", \\\"{x:1305,y:561,t:1527016953939};\\\", \\\"{x:1307,y:561,t:1527016953956};\\\", \\\"{x:1308,y:561,t:1527016953979};\\\", \\\"{x:1309,y:561,t:1527016954003};\\\", \\\"{x:1310,y:561,t:1527016954011};\\\", \\\"{x:1312,y:561,t:1527016954023};\\\", \\\"{x:1313,y:561,t:1527016954040};\\\", \\\"{x:1316,y:560,t:1527016954057};\\\", \\\"{x:1324,y:556,t:1527016954073};\\\", \\\"{x:1330,y:556,t:1527016954089};\\\", \\\"{x:1331,y:556,t:1527016954107};\\\", \\\"{x:1332,y:556,t:1527016954123};\\\", \\\"{x:1334,y:555,t:1527016954147};\\\", \\\"{x:1336,y:555,t:1527016954163};\\\", \\\"{x:1339,y:552,t:1527016954173};\\\", \\\"{x:1345,y:552,t:1527016954190};\\\", \\\"{x:1351,y:552,t:1527016954207};\\\", \\\"{x:1352,y:552,t:1527016954224};\\\", \\\"{x:1360,y:552,t:1527016954239};\\\", \\\"{x:1363,y:551,t:1527016954257};\\\", \\\"{x:1368,y:550,t:1527016954275};\\\", \\\"{x:1369,y:550,t:1527016954289};\\\", \\\"{x:1370,y:550,t:1527016954388};\\\", \\\"{x:1371,y:550,t:1527016954403};\\\", \\\"{x:1373,y:550,t:1527016954411};\\\", \\\"{x:1374,y:550,t:1527016954423};\\\", \\\"{x:1377,y:550,t:1527016954440};\\\", \\\"{x:1383,y:550,t:1527016954457};\\\", \\\"{x:1386,y:550,t:1527016954475};\\\", \\\"{x:1388,y:550,t:1527016954490};\\\", \\\"{x:1391,y:550,t:1527016954507};\\\", \\\"{x:1392,y:550,t:1527016954700};\\\", \\\"{x:1392,y:551,t:1527016954755};\\\", \\\"{x:1395,y:553,t:1527016954764};\\\", \\\"{x:1397,y:556,t:1527016954779};\\\", \\\"{x:1398,y:556,t:1527016954796};\\\", \\\"{x:1398,y:557,t:1527016954811};\\\", \\\"{x:1399,y:558,t:1527016955708};\\\", \\\"{x:1397,y:560,t:1527016955724};\\\", \\\"{x:1391,y:563,t:1527016955742};\\\", \\\"{x:1384,y:564,t:1527016955759};\\\", \\\"{x:1373,y:564,t:1527016955774};\\\", \\\"{x:1362,y:568,t:1527016955791};\\\", \\\"{x:1349,y:568,t:1527016955808};\\\", \\\"{x:1338,y:564,t:1527016955824};\\\", \\\"{x:1335,y:564,t:1527016955841};\\\", \\\"{x:1334,y:564,t:1527016955858};\\\", \\\"{x:1325,y:563,t:1527016955874};\\\", \\\"{x:1319,y:560,t:1527016955892};\\\", \\\"{x:1317,y:559,t:1527016955908};\\\", \\\"{x:1315,y:559,t:1527016955925};\\\", \\\"{x:1313,y:558,t:1527016955941};\\\", \\\"{x:1312,y:558,t:1527016955958};\\\", \\\"{x:1311,y:558,t:1527016956019};\\\", \\\"{x:1312,y:556,t:1527016956027};\\\", \\\"{x:1317,y:555,t:1527016956041};\\\", \\\"{x:1326,y:550,t:1527016956058};\\\", \\\"{x:1329,y:549,t:1527016956075};\\\", \\\"{x:1330,y:549,t:1527016956187};\\\", \\\"{x:1333,y:549,t:1527016956202};\\\", \\\"{x:1336,y:549,t:1527016956218};\\\", \\\"{x:1337,y:549,t:1527016956226};\\\", \\\"{x:1338,y:549,t:1527016956250};\\\", \\\"{x:1342,y:551,t:1527016956322};\\\", \\\"{x:1344,y:553,t:1527016956330};\\\", \\\"{x:1345,y:554,t:1527016956342};\\\", \\\"{x:1347,y:556,t:1527016956358};\\\", \\\"{x:1352,y:560,t:1527016956378};\\\", \\\"{x:1355,y:561,t:1527016956392};\\\", \\\"{x:1364,y:564,t:1527016956408};\\\", \\\"{x:1377,y:567,t:1527016956425};\\\", \\\"{x:1393,y:569,t:1527016956442};\\\", \\\"{x:1401,y:569,t:1527016956459};\\\", \\\"{x:1405,y:569,t:1527016956475};\\\", \\\"{x:1406,y:569,t:1527016956579};\\\", \\\"{x:1408,y:569,t:1527016956595};\\\", \\\"{x:1409,y:569,t:1527016956708};\\\", \\\"{x:1410,y:569,t:1527016957019};\\\", \\\"{x:1411,y:569,t:1527016957027};\\\", \\\"{x:1412,y:569,t:1527016957204};\\\", \\\"{x:1414,y:569,t:1527016957243};\\\", \\\"{x:1414,y:568,t:1527016957268};\\\", \\\"{x:1414,y:567,t:1527016957619};\\\", \\\"{x:1414,y:566,t:1527016957827};\\\", \\\"{x:1415,y:566,t:1527016957851};\\\", \\\"{x:1416,y:566,t:1527016958188};\\\", \\\"{x:1416,y:565,t:1527016958228};\\\", \\\"{x:1417,y:563,t:1527016958244};\\\", \\\"{x:1418,y:562,t:1527016958315};\\\", \\\"{x:1419,y:562,t:1527016958420};\\\", \\\"{x:1421,y:562,t:1527016958428};\\\", \\\"{x:1422,y:568,t:1527016958444};\\\", \\\"{x:1424,y:577,t:1527016958461};\\\", \\\"{x:1424,y:580,t:1527016958477};\\\", \\\"{x:1427,y:585,t:1527016958494};\\\", \\\"{x:1428,y:588,t:1527016958511};\\\", \\\"{x:1428,y:593,t:1527016958527};\\\", \\\"{x:1428,y:595,t:1527016958545};\\\", \\\"{x:1429,y:598,t:1527016958561};\\\", \\\"{x:1429,y:599,t:1527016958578};\\\", \\\"{x:1431,y:599,t:1527016958763};\\\", \\\"{x:1431,y:597,t:1527016958779};\\\", \\\"{x:1430,y:595,t:1527016958795};\\\", \\\"{x:1428,y:587,t:1527016958812};\\\", \\\"{x:1427,y:583,t:1527016958829};\\\", \\\"{x:1425,y:580,t:1527016958845};\\\", \\\"{x:1425,y:579,t:1527016958862};\\\", \\\"{x:1425,y:577,t:1527016958878};\\\", \\\"{x:1424,y:577,t:1527016958895};\\\", \\\"{x:1423,y:576,t:1527016958915};\\\", \\\"{x:1423,y:574,t:1527016959028};\\\", \\\"{x:1423,y:573,t:1527016959123};\\\", \\\"{x:1423,y:571,t:1527016959131};\\\", \\\"{x:1423,y:570,t:1527016959146};\\\", \\\"{x:1428,y:568,t:1527016959162};\\\", \\\"{x:1438,y:566,t:1527016959179};\\\", \\\"{x:1447,y:565,t:1527016959195};\\\", \\\"{x:1455,y:564,t:1527016959213};\\\", \\\"{x:1461,y:562,t:1527016959229};\\\", \\\"{x:1466,y:562,t:1527016959246};\\\", \\\"{x:1469,y:562,t:1527016959263};\\\", \\\"{x:1471,y:561,t:1527016959279};\\\", \\\"{x:1471,y:560,t:1527016959295};\\\", \\\"{x:1472,y:560,t:1527016959347};\\\", \\\"{x:1473,y:560,t:1527016959363};\\\", \\\"{x:1475,y:560,t:1527016959387};\\\", \\\"{x:1477,y:560,t:1527016959428};\\\", \\\"{x:1478,y:560,t:1527016960763};\\\", \\\"{x:1480,y:560,t:1527016962340};\\\", \\\"{x:1483,y:567,t:1527016962349};\\\", \\\"{x:1486,y:569,t:1527016962366};\\\", \\\"{x:1486,y:568,t:1527016962723};\\\", \\\"{x:1486,y:566,t:1527016962779};\\\", \\\"{x:1486,y:565,t:1527016962803};\\\", \\\"{x:1486,y:564,t:1527016962899};\\\", \\\"{x:1486,y:563,t:1527016962917};\\\", \\\"{x:1486,y:562,t:1527016962934};\\\", \\\"{x:1485,y:561,t:1527016962979};\\\", \\\"{x:1484,y:561,t:1527016965515};\\\", \\\"{x:1482,y:561,t:1527016965523};\\\", \\\"{x:1480,y:561,t:1527016965536};\\\", \\\"{x:1479,y:561,t:1527016965554};\\\", \\\"{x:1475,y:561,t:1527016965570};\\\", \\\"{x:1466,y:561,t:1527016965587};\\\", \\\"{x:1459,y:560,t:1527016965603};\\\", \\\"{x:1447,y:565,t:1527016965620};\\\", \\\"{x:1403,y:565,t:1527016965636};\\\", \\\"{x:1329,y:569,t:1527016965653};\\\", \\\"{x:1248,y:571,t:1527016965670};\\\", \\\"{x:1167,y:572,t:1527016965686};\\\", \\\"{x:1118,y:571,t:1527016965702};\\\", \\\"{x:1104,y:569,t:1527016965720};\\\", \\\"{x:1090,y:572,t:1527016965736};\\\", \\\"{x:1084,y:572,t:1527016965752};\\\", \\\"{x:1061,y:571,t:1527016965769};\\\", \\\"{x:941,y:571,t:1527016965786};\\\", \\\"{x:820,y:571,t:1527016965802};\\\", \\\"{x:721,y:569,t:1527016965820};\\\", \\\"{x:622,y:560,t:1527016965836};\\\", \\\"{x:523,y:541,t:1527016965853};\\\", \\\"{x:462,y:537,t:1527016965874};\\\", \\\"{x:407,y:530,t:1527016965892};\\\", \\\"{x:389,y:524,t:1527016965907};\\\", \\\"{x:363,y:519,t:1527016965924};\\\", \\\"{x:345,y:513,t:1527016965942};\\\", \\\"{x:339,y:511,t:1527016965958};\\\", \\\"{x:336,y:509,t:1527016965974};\\\", \\\"{x:335,y:509,t:1527016965991};\\\", \\\"{x:334,y:509,t:1527016966122};\\\", \\\"{x:333,y:509,t:1527016966130};\\\", \\\"{x:333,y:510,t:1527016966171};\\\", \\\"{x:333,y:512,t:1527016966195};\\\", \\\"{x:333,y:514,t:1527016966209};\\\", \\\"{x:332,y:519,t:1527016966225};\\\", \\\"{x:331,y:525,t:1527016966242};\\\", \\\"{x:328,y:531,t:1527016966259};\\\", \\\"{x:326,y:537,t:1527016966275};\\\", \\\"{x:326,y:539,t:1527016966291};\\\", \\\"{x:325,y:543,t:1527016966308};\\\", \\\"{x:324,y:544,t:1527016966329};\\\", \\\"{x:322,y:545,t:1527016966346};\\\", \\\"{x:322,y:547,t:1527016966358};\\\", \\\"{x:321,y:553,t:1527016966374};\\\", \\\"{x:321,y:557,t:1527016966391};\\\", \\\"{x:320,y:562,t:1527016966408};\\\", \\\"{x:320,y:566,t:1527016966424};\\\", \\\"{x:320,y:570,t:1527016966442};\\\", \\\"{x:320,y:572,t:1527016966458};\\\", \\\"{x:320,y:575,t:1527016966475};\\\", \\\"{x:320,y:580,t:1527016966492};\\\", \\\"{x:321,y:581,t:1527016966509};\\\", \\\"{x:322,y:583,t:1527016966525};\\\", \\\"{x:323,y:586,t:1527016966541};\\\", \\\"{x:323,y:590,t:1527016966763};\\\", \\\"{x:322,y:591,t:1527016966775};\\\", \\\"{x:320,y:592,t:1527016966791};\\\", \\\"{x:321,y:592,t:1527016967171};\\\", \\\"{x:325,y:592,t:1527016967195};\\\", \\\"{x:331,y:592,t:1527016967209};\\\", \\\"{x:343,y:592,t:1527016967225};\\\", \\\"{x:364,y:592,t:1527016967243};\\\", \\\"{x:370,y:592,t:1527016967259};\\\", \\\"{x:372,y:592,t:1527016967276};\\\", \\\"{x:373,y:592,t:1527016967387};\\\", \\\"{x:366,y:592,t:1527016967659};\\\", \\\"{x:353,y:592,t:1527016967676};\\\", \\\"{x:339,y:592,t:1527016967693};\\\", \\\"{x:329,y:593,t:1527016967709};\\\", \\\"{x:323,y:594,t:1527016967726};\\\", \\\"{x:322,y:594,t:1527016967743};\\\", \\\"{x:325,y:591,t:1527016967835};\\\", \\\"{x:331,y:588,t:1527016967842};\\\", \\\"{x:338,y:582,t:1527016967860};\\\", \\\"{x:346,y:579,t:1527016967876};\\\", \\\"{x:359,y:572,t:1527016967894};\\\", \\\"{x:365,y:568,t:1527016967910};\\\", \\\"{x:371,y:566,t:1527016967926};\\\", \\\"{x:375,y:563,t:1527016967943};\\\", \\\"{x:379,y:561,t:1527016967959};\\\", \\\"{x:382,y:560,t:1527016967976};\\\", \\\"{x:386,y:558,t:1527016967992};\\\", \\\"{x:390,y:555,t:1527016968010};\\\", \\\"{x:396,y:551,t:1527016968026};\\\", \\\"{x:398,y:549,t:1527016968043};\\\", \\\"{x:401,y:548,t:1527016968059};\\\", \\\"{x:401,y:547,t:1527016968082};\\\", \\\"{x:399,y:546,t:1527016968163};\\\", \\\"{x:389,y:549,t:1527016968177};\\\", \\\"{x:373,y:554,t:1527016968193};\\\", \\\"{x:346,y:563,t:1527016968211};\\\", \\\"{x:343,y:563,t:1527016968228};\\\", \\\"{x:342,y:563,t:1527016968250};\\\", \\\"{x:342,y:564,t:1527016968260};\\\", \\\"{x:348,y:564,t:1527016968277};\\\", \\\"{x:352,y:564,t:1527016968292};\\\", \\\"{x:363,y:564,t:1527016968310};\\\", \\\"{x:383,y:560,t:1527016968328};\\\", \\\"{x:429,y:552,t:1527016968343};\\\", \\\"{x:477,y:539,t:1527016968359};\\\", \\\"{x:494,y:533,t:1527016968377};\\\", \\\"{x:500,y:530,t:1527016968394};\\\", \\\"{x:500,y:529,t:1527016968409};\\\", \\\"{x:503,y:527,t:1527016968426};\\\", \\\"{x:507,y:527,t:1527016968451};\\\", \\\"{x:512,y:525,t:1527016968460};\\\", \\\"{x:514,y:523,t:1527016968476};\\\", \\\"{x:517,y:519,t:1527016968494};\\\", \\\"{x:519,y:518,t:1527016968509};\\\", \\\"{x:524,y:516,t:1527016968526};\\\", \\\"{x:525,y:515,t:1527016968543};\\\", \\\"{x:526,y:515,t:1527016968563};\\\", \\\"{x:528,y:515,t:1527016968577};\\\", \\\"{x:530,y:515,t:1527016968594};\\\", \\\"{x:536,y:515,t:1527016968609};\\\", \\\"{x:540,y:515,t:1527016968627};\\\", \\\"{x:546,y:514,t:1527016968644};\\\", \\\"{x:550,y:513,t:1527016968659};\\\", \\\"{x:553,y:512,t:1527016968677};\\\", \\\"{x:556,y:511,t:1527016968694};\\\", \\\"{x:561,y:508,t:1527016968710};\\\", \\\"{x:574,y:507,t:1527016968726};\\\", \\\"{x:585,y:506,t:1527016968744};\\\", \\\"{x:586,y:506,t:1527016968762};\\\", \\\"{x:587,y:506,t:1527016968778};\\\", \\\"{x:588,y:506,t:1527016968794};\\\", \\\"{x:590,y:505,t:1527016968810};\\\", \\\"{x:592,y:505,t:1527016968827};\\\", \\\"{x:594,y:504,t:1527016968844};\\\", \\\"{x:597,y:504,t:1527016968978};\\\", \\\"{x:598,y:504,t:1527016969467};\\\", \\\"{x:599,y:504,t:1527016969483};\\\", \\\"{x:601,y:505,t:1527016969493};\\\", \\\"{x:603,y:519,t:1527016969509};\\\", \\\"{x:608,y:531,t:1527016969528};\\\", \\\"{x:619,y:553,t:1527016969545};\\\", \\\"{x:625,y:573,t:1527016969561};\\\", \\\"{x:634,y:588,t:1527016969578};\\\", \\\"{x:637,y:593,t:1527016969594};\\\", \\\"{x:642,y:613,t:1527016969611};\\\", \\\"{x:649,y:624,t:1527016969628};\\\", \\\"{x:648,y:643,t:1527016969644};\\\", \\\"{x:653,y:668,t:1527016969661};\\\", \\\"{x:643,y:683,t:1527016969677};\\\", \\\"{x:640,y:707,t:1527016969694};\\\", \\\"{x:638,y:713,t:1527016969711};\\\", \\\"{x:637,y:718,t:1527016969727};\\\", \\\"{x:637,y:720,t:1527016969745};\\\", \\\"{x:638,y:725,t:1527016969762};\\\", \\\"{x:639,y:733,t:1527016969778};\\\", \\\"{x:641,y:747,t:1527016969794};\\\", \\\"{x:642,y:748,t:1527016969812};\\\", \\\"{x:636,y:748,t:1527016972866};\\\", \\\"{x:628,y:748,t:1527016972873};\\\", \\\"{x:626,y:748,t:1527016972884};\\\", \\\"{x:606,y:748,t:1527016972901};\\\", \\\"{x:600,y:748,t:1527016972917};\\\", \\\"{x:595,y:750,t:1527016972934};\\\", \\\"{x:594,y:750,t:1527016972951};\\\", \\\"{x:589,y:750,t:1527016972968};\\\", \\\"{x:585,y:751,t:1527016972985};\\\", \\\"{x:581,y:755,t:1527016973001};\\\", \\\"{x:577,y:756,t:1527016973018};\\\", \\\"{x:573,y:757,t:1527016973035};\\\", \\\"{x:571,y:758,t:1527016973051};\\\", \\\"{x:570,y:758,t:1527016973068};\\\", \\\"{x:569,y:758,t:1527016973425};\\\", \\\"{x:568,y:758,t:1527016973448};\\\", \\\"{x:567,y:758,t:1527016973457};\\\", \\\"{x:564,y:756,t:1527016973471};\\\", \\\"{x:564,y:755,t:1527016973486};\\\", \\\"{x:563,y:752,t:1527016973501};\\\", \\\"{x:556,y:741,t:1527016973523};\\\", \\\"{x:555,y:736,t:1527016973538};\\\", \\\"{x:554,y:725,t:1527016973556};\\\", \\\"{x:563,y:708,t:1527016973573};\\\", \\\"{x:568,y:691,t:1527016973596};\\\", \\\"{x:574,y:675,t:1527016973611};\\\", \\\"{x:576,y:669,t:1527016973629};\\\", \\\"{x:579,y:664,t:1527016973645};\\\", \\\"{x:581,y:659,t:1527016973662};\\\", \\\"{x:586,y:653,t:1527016973678};\\\", \\\"{x:586,y:650,t:1527016973696};\\\", \\\"{x:587,y:646,t:1527016973712};\\\", \\\"{x:587,y:643,t:1527016973729};\\\", \\\"{x:587,y:640,t:1527016973745};\\\", \\\"{x:590,y:631,t:1527016973762};\\\", \\\"{x:592,y:620,t:1527016973779};\\\", \\\"{x:593,y:617,t:1527016973796};\\\", \\\"{x:593,y:616,t:1527016973813};\\\", \\\"{x:600,y:603,t:1527016973830};\\\", \\\"{x:606,y:590,t:1527016973845};\\\", \\\"{x:610,y:578,t:1527016973863};\\\", \\\"{x:612,y:570,t:1527016973879};\\\", \\\"{x:616,y:561,t:1527016973896};\\\", \\\"{x:616,y:558,t:1527016973912};\\\", \\\"{x:617,y:555,t:1527016973929};\\\", \\\"{x:617,y:554,t:1527016973946};\\\", \\\"{x:617,y:552,t:1527016973962};\\\", \\\"{x:617,y:551,t:1527016973979};\\\", \\\"{x:617,y:548,t:1527016973996};\\\", \\\"{x:617,y:545,t:1527016974013};\\\", \\\"{x:616,y:543,t:1527016974032};\\\", \\\"{x:616,y:541,t:1527016974046};\\\", \\\"{x:616,y:535,t:1527016974064};\\\", \\\"{x:615,y:529,t:1527016974080};\\\", \\\"{x:614,y:522,t:1527016974096};\\\", \\\"{x:614,y:521,t:1527016974113};\\\", \\\"{x:614,y:519,t:1527016974136};\\\", \\\"{x:614,y:517,t:1527016974152};\\\", \\\"{x:614,y:515,t:1527016974163};\\\", \\\"{x:614,y:514,t:1527016974192};\\\", \\\"{x:613,y:514,t:1527016974200};\\\", \\\"{x:613,y:513,t:1527016974212};\\\", \\\"{x:613,y:512,t:1527016974229};\\\", \\\"{x:613,y:514,t:1527016974552};\\\", \\\"{x:613,y:516,t:1527016974563};\\\", \\\"{x:618,y:534,t:1527016974581};\\\", \\\"{x:622,y:560,t:1527016974596};\\\", \\\"{x:625,y:578,t:1527016974613};\\\", \\\"{x:628,y:617,t:1527016974631};\\\", \\\"{x:622,y:658,t:1527016974646};\\\", \\\"{x:619,y:688,t:1527016974663};\\\", \\\"{x:606,y:730,t:1527016974680};\\\", \\\"{x:604,y:742,t:1527016974695};\\\", \\\"{x:599,y:751,t:1527016974713};\\\", \\\"{x:598,y:756,t:1527016974729};\\\", \\\"{x:598,y:757,t:1527016974747};\\\", \\\"{x:597,y:758,t:1527016974763};\\\", \\\"{x:595,y:771,t:1527016974779};\\\", \\\"{x:591,y:782,t:1527016974797};\\\", \\\"{x:588,y:789,t:1527016974813};\\\", \\\"{x:587,y:796,t:1527016974830};\\\", \\\"{x:586,y:798,t:1527016974847};\\\", \\\"{x:584,y:802,t:1527016974864};\\\", \\\"{x:584,y:803,t:1527016974993};\\\", \\\"{x:584,y:804,t:1527016975024};\\\", \\\"{x:584,y:805,t:1527016975040};\\\", \\\"{x:586,y:805,t:1527016975144};\\\", \\\"{x:591,y:804,t:1527016975161};\\\", \\\"{x:591,y:803,t:1527016975217};\\\", \\\"{x:591,y:801,t:1527016975305};\\\", \\\"{x:590,y:796,t:1527016975328};\\\", \\\"{x:587,y:794,t:1527016975345};\\\", \\\"{x:583,y:792,t:1527016975360};\\\", \\\"{x:580,y:791,t:1527016975368};\\\", \\\"{x:579,y:791,t:1527016975385};\\\", \\\"{x:574,y:791,t:1527016977201};\\\", \\\"{x:567,y:791,t:1527016977209};\\\", \\\"{x:564,y:791,t:1527016977220};\\\", \\\"{x:552,y:790,t:1527016977236};\\\", \\\"{x:536,y:786,t:1527016977253};\\\", \\\"{x:517,y:784,t:1527016977270};\\\", \\\"{x:501,y:781,t:1527016977287};\\\", \\\"{x:493,y:780,t:1527016977302};\\\", \\\"{x:488,y:779,t:1527016977319};\\\", \\\"{x:487,y:778,t:1527016977481};\\\", \\\"{x:487,y:776,t:1527016977489};\\\", \\\"{x:487,y:774,t:1527016977503};\\\", \\\"{x:492,y:763,t:1527016977522};\\\", \\\"{x:498,y:753,t:1527016977536};\\\", \\\"{x:504,y:750,t:1527016977553};\\\", \\\"{x:506,y:746,t:1527016977565};\\\", \\\"{x:509,y:743,t:1527016977581};\\\" ] }, { \\\"rt\\\": 53285, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 20, \\\"time_elapsed\\\": 1072340, \\\"internal_node_id\\\": \\\"0.0-7.0-0.0\\\", \\\"subject\\\": \\\"6Y93F\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"foxtrot\\\", \\\"condition\\\": \\\"111\\\", \\\"q\\\": 16, \\\"answer\\\": \\\"By looking at the x axis and seeing which point coincides with the time 12pm\\\", \\\"block\\\": \\\"triangular_testing\\\" }, { \\\"rt\\\": 12777, \\\"responses\\\": \\\"{\\\\\\\"Q0\\\\\\\":\\\\\\\"22\\\\\\\",\\\\\\\"Q1\\\\\\\":\\\\\\\"United States\\\\\\\"}\\\", \\\"block\\\": \\\"demo-1\\\", \\\"trial_type\\\": \\\"survey-text\\\", \\\"trial_index\\\": 21, \\\"time_elapsed\\\": 1086123, \\\"internal_node_id\\\": \\\"0.0-8.0\\\", \\\"subject\\\": \\\"6Y93F\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"foxtrot\\\", \\\"condition\\\": \\\"111\\\" }, { \\\"rt\\\": 24064, \\\"responses\\\": \\\"{\\\\\\\"Q0\\\\\\\":\\\\\\\"English\\\\\\\",\\\\\\\"Q1\\\\\\\":\\\\\\\"Fourth\\\\\\\",\\\\\\\"Q2\\\\\\\":\\\\\\\"Biomedical & Health Sciences\\\\\\\",\\\\\\\"Q3\\\\\\\":\\\\\\\"Male\\\\\\\"}\\\", \\\"block\\\": \\\"demo-2\\\", \\\"trial_type\\\": \\\"survey-multi-choice\\\", \\\"trial_index\\\": 22, \\\"time_elapsed\\\": 1111213, \\\"internal_node_id\\\": \\\"0.0-9.0\\\", \\\"subject\\\": \\\"6Y93F\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"foxtrot\\\", \\\"condition\\\": \\\"111\\\" }, { \\\"rt\\\": 28930, \\\"url\\\": \\\"../views/src/external/debrief.html\\\", \\\"block\\\": \\\"debrief\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 23, \\\"time_elapsed\\\": 1141488, \\\"internal_node_id\\\": \\\"0.0-10.0\\\", \\\"subject\\\": \\\"6Y93F\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"foxtrot\\\", \\\"condition\\\": \\\"111\\\" } ]\",\"parentNode\":{\"id\":2765}}],[],[]]}"
    }
  ],
  "initialDom": "{\"f\":\"initialize\",\"args\":[1,[{\"nodeType\":10,\"id\":2,\"name\":\"html\",\"publicId\":\"\",\"systemId\":\"\"},{\"nodeType\":1,\"id\":3,\"tagName\":\"HTML\",\"attributes\":{\"class\":\"fa-events-icons-ready\"},\"childNodes\":[{\"nodeType\":1,\"id\":4,\"tagName\":\"HEAD\",\"attributes\":{},\"childNodes\":[{\"nodeType\":3,\"id\":5,\"textContent\":\" \"},{\"nodeType\":1,\"id\":6,\"tagName\":\"TITLE\",\"attributes\":{},\"childNodes\":[{\"nodeType\":3,\"id\":7,\"textContent\":\"FOX2YP\"}]},{\"nodeType\":3,\"id\":8,\"textContent\":\" \"},{\"nodeType\":8,\"id\":9},{\"nodeType\":3,\"id\":10,\"textContent\":\" \"},{\"nodeType\":1,\"id\":11,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":12,\"textContent\":\" \"},{\"nodeType\":1,\"id\":13,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":14,\"textContent\":\" \"},{\"nodeType\":1,\"id\":15,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":16,\"textContent\":\" \"},{\"nodeType\":1,\"id\":17,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":18,\"textContent\":\" \"},{\"nodeType\":1,\"id\":19,\"tagName\":\"SCRIPT\"},{\"nodeType\":1,\"id\":20,\"tagName\":\"LINK\",\"attributes\":{\"href\":\"https://use.fontawesome.com/945539d961.css\",\"media\":\"all\",\"rel\":\"stylesheet\"}},{\"nodeType\":3,\"id\":21,\"textContent\":\" \"},{\"nodeType\":8,\"id\":22},{\"nodeType\":3,\"id\":23,\"textContent\":\" \"},{\"nodeType\":1,\"id\":24,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":25,\"textContent\":\" \"},{\"nodeType\":1,\"id\":26,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":27,\"textContent\":\" \"},{\"nodeType\":1,\"id\":28,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":29,\"textContent\":\" \"},{\"nodeType\":1,\"id\":30,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":31,\"textContent\":\" \"},{\"nodeType\":1,\"id\":32,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":33,\"textContent\":\" \"},{\"nodeType\":1,\"id\":34,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":35,\"textContent\":\" \"},{\"nodeType\":1,\"id\":36,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":37,\"textContent\":\" \"},{\"nodeType\":8,\"id\":38},{\"nodeType\":3,\"id\":39,\"textContent\":\" \"},{\"nodeType\":1,\"id\":40,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":41,\"textContent\":\" \"},{\"nodeType\":8,\"id\":42},{\"nodeType\":3,\"id\":43,\"textContent\":\" \"},{\"nodeType\":8,\"id\":44},{\"nodeType\":3,\"id\":45,\"textContent\":\" \"},{\"nodeType\":1,\"id\":46,\"tagName\":\"LINK\",\"attributes\":{\"href\":\"../views/jsPsych/css/jspsych.css\",\"rel\":\"stylesheet\",\"type\":\"text/css\"}},{\"nodeType\":3,\"id\":47,\"textContent\":\" \"},{\"nodeType\":1,\"id\":48,\"tagName\":\"LINK\",\"attributes\":{\"href\":\"../css/styles.css\",\"rel\":\"stylesheet\",\"type\":\"text/css\"}},{\"nodeType\":3,\"id\":49,\"textContent\":\" \"},{\"nodeType\":1,\"id\":50,\"tagName\":\"SCRIPT\"},{\"nodeType\":1,\"id\":51,\"tagName\":\"SCRIPT\"}]},{\"nodeType\":3,\"id\":52,\"textContent\":\" \"},{\"nodeType\":8,\"id\":53},{\"nodeType\":3,\"id\":54,\"textContent\":\" \"},{\"nodeType\":1,\"id\":55,\"tagName\":\"BODY\",\"attributes\":{\"class\":\"jspsych-display-element\"},\"childNodes\":[{\"nodeType\":3,\"id\":56,\"textContent\":\" \"},{\"nodeType\":1,\"id\":57,\"tagName\":\"META\",\"attributes\":{\"charset\":\"utf-8\"}},{\"nodeType\":3,\"id\":58,\"textContent\":\" \"},{\"nodeType\":8,\"id\":59},{\"nodeType\":3,\"id\":60,\"textContent\":\" \"},{\"nodeType\":1,\"id\":61,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":62,\"textContent\":\" \"},{\"nodeType\":1,\"id\":63,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":64,\"textContent\":\" \"},{\"nodeType\":1,\"id\":65,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":66,\"textContent\":\" \"},{\"nodeType\":1,\"id\":67,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":68,\"textContent\":\" \"},{\"nodeType\":1,\"id\":69,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":70,\"textContent\":\" \"},{\"nodeType\":1,\"id\":71,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":72,\"textContent\":\" \"},{\"nodeType\":1,\"id\":73,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"stimulus\"},\"childNodes\":[{\"nodeType\":3,\"id\":74,\"textContent\":\" \"},{\"nodeType\":1,\"id\":75,\"tagName\":\"P\",\"attributes\":{\"class\":\"userid\",\"id\":\"userid\"},\"childNodes\":[{\"nodeType\":3,\"id\":76,\"textContent\":\"6Y93F\"}]},{\"nodeType\":3,\"id\":77,\"textContent\":\" \"},{\"nodeType\":1,\"id\":78,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"userinput\"},\"childNodes\":[{\"nodeType\":3,\"id\":79,\"textContent\":\" \"},{\"nodeType\":8,\"id\":80},{\"nodeType\":3,\"id\":81,\"textContent\":\" \"},{\"nodeType\":1,\"id\":82,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"legend\",\"id\":\"hint-interactive\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":83,\"textContent\":\" \"},{\"nodeType\":1,\"id\":84,\"tagName\":\"P\",\"attributes\":{},\"childNodes\":[{\"nodeType\":3,\"id\":85,\"textContent\":\"Hint: Hover your mouse over the data points in the graph\"}]},{\"nodeType\":3,\"id\":86,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":87,\"textContent\":\" \"},{\"nodeType\":8,\"id\":88},{\"nodeType\":3,\"id\":89,\"textContent\":\" \"},{\"nodeType\":8,\"id\":90},{\"nodeType\":3,\"id\":91,\"textContent\":\" \"},{\"nodeType\":1,\"id\":92,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"test\"},\"childNodes\":[{\"nodeType\":3,\"id\":93,\"textContent\":\" \"},{\"nodeType\":1,\"id\":94,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"acme\",\"id\":\"acme.starttime\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":95,\"textContent\":\" \"},{\"nodeType\":1,\"id\":96,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":97,\"textContent\":\"Which shift(s) start at 11 am? \"}]},{\"nodeType\":3,\"id\":98,\"textContent\":\" \"},{\"nodeType\":1,\"id\":99,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":100,\"textContent\":\" \"},{\"nodeType\":1,\"id\":101,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":102,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":103,\"textContent\":\" \"},{\"nodeType\":1,\"id\":104,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":105,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":106,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":107,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":108,\"textContent\":\" \"},{\"nodeType\":1,\"id\":109,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":110,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":111,\"textContent\":\" \"},{\"nodeType\":1,\"id\":112,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":113,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":114,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":115,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":116,\"textContent\":\" \"},{\"nodeType\":1,\"id\":117,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":118,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":119,\"textContent\":\" \"},{\"nodeType\":1,\"id\":120,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":121,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":122,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":123,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":124,\"textContent\":\" \"},{\"nodeType\":1,\"id\":125,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":126,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":127,\"textContent\":\" \"},{\"nodeType\":1,\"id\":128,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":129,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":130,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":131,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":132,\"textContent\":\" \"},{\"nodeType\":1,\"id\":133,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":134,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":135,\"textContent\":\" \"},{\"nodeType\":1,\"id\":136,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":137,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":138,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":139,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":140,\"textContent\":\" \"},{\"nodeType\":1,\"id\":141,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":142,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":143,\"textContent\":\" \"},{\"nodeType\":1,\"id\":144,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":145,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":146,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":147,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":148,\"textContent\":\" \"},{\"nodeType\":1,\"id\":149,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":150,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":151,\"textContent\":\" \"},{\"nodeType\":1,\"id\":152,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":153,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":154,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":155,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":156,\"textContent\":\" \"},{\"nodeType\":1,\"id\":157,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":158,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":159,\"textContent\":\" \"},{\"nodeType\":1,\"id\":160,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":161,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":162,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":163,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":164,\"textContent\":\" \"},{\"nodeType\":1,\"id\":165,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":166,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":167,\"textContent\":\" \"},{\"nodeType\":1,\"id\":168,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":169,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":170,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":171,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":172,\"textContent\":\" \"},{\"nodeType\":1,\"id\":173,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":174,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":175,\"textContent\":\" \"},{\"nodeType\":1,\"id\":176,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":177,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":178,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":179,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":180,\"textContent\":\" \"},{\"nodeType\":1,\"id\":181,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":182,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":183,\"textContent\":\" \"},{\"nodeType\":1,\"id\":184,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"U\",\"value\":\"\"}},{\"nodeType\":3,\"id\":185,\"textContent\":\"U \"},{\"nodeType\":1,\"id\":186,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":187,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":188,\"textContent\":\" \"},{\"nodeType\":1,\"id\":189,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":190,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":191,\"textContent\":\" \"},{\"nodeType\":1,\"id\":192,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":193,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":194,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":195,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":196,\"textContent\":\" \"},{\"nodeType\":1,\"id\":197,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":198,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":199,\"textContent\":\" \"},{\"nodeType\":1,\"id\":200,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":201,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":202,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":203,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":204,\"textContent\":\" \"},{\"nodeType\":1,\"id\":205,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":206,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":207,\"textContent\":\" \"},{\"nodeType\":1,\"id\":208,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":209,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":210,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":211,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":212,\"textContent\":\" \"},{\"nodeType\":1,\"id\":213,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":214,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":215,\"textContent\":\" \"},{\"nodeType\":1,\"id\":216,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":217,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":218,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":219,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":220,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":221,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":222,\"textContent\":\" \"},{\"nodeType\":1,\"id\":223,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"acme\",\"id\":\"acme.starts\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":224,\"textContent\":\" \"},{\"nodeType\":1,\"id\":225,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":226,\"textContent\":\"Which shift(s) start at the same time as D?\"}]},{\"nodeType\":3,\"id\":227,\"textContent\":\" \"},{\"nodeType\":1,\"id\":228,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":229,\"textContent\":\" \"},{\"nodeType\":1,\"id\":230,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":231,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":232,\"textContent\":\" \"},{\"nodeType\":1,\"id\":233,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":234,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":235,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":236,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":237,\"textContent\":\" \"},{\"nodeType\":1,\"id\":238,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":239,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":240,\"textContent\":\" \"},{\"nodeType\":1,\"id\":241,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":242,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":243,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":244,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":245,\"textContent\":\" \"},{\"nodeType\":1,\"id\":246,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":247,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":248,\"textContent\":\" \"},{\"nodeType\":1,\"id\":249,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":250,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":251,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":252,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":253,\"textContent\":\" \"},{\"nodeType\":1,\"id\":254,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":255,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":256,\"textContent\":\" \"},{\"nodeType\":1,\"id\":257,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":258,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":259,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":260,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":261,\"textContent\":\" \"},{\"nodeType\":1,\"id\":262,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":263,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":264,\"textContent\":\" \"},{\"nodeType\":1,\"id\":265,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":266,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":267,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":268,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":269,\"textContent\":\" \"},{\"nodeType\":1,\"id\":270,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":271,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":272,\"textContent\":\" \"},{\"nodeType\":1,\"id\":273,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":274,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":275,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":276,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":277,\"textContent\":\" \"},{\"nodeType\":1,\"id\":278,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":279,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":280,\"textContent\":\" \"},{\"nodeType\":1,\"id\":281,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":282,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":283,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":284,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":285,\"textContent\":\" \"},{\"nodeType\":1,\"id\":286,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":287,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":288,\"textContent\":\" \"},{\"nodeType\":1,\"id\":289,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":290,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":291,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":292,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":293,\"textContent\":\" \"},{\"nodeType\":1,\"id\":294,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":295,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":296,\"textContent\":\" \"},{\"nodeType\":1,\"id\":297,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":298,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":299,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":300,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":301,\"textContent\":\" \"},{\"nodeType\":1,\"id\":302,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":303,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":304,\"textContent\":\" \"},{\"nodeType\":1,\"id\":305,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":306,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":307,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":308,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":309,\"textContent\":\" \"},{\"nodeType\":1,\"id\":310,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":311,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":312,\"textContent\":\" \"},{\"nodeType\":1,\"id\":313,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"U\",\"value\":\"\"}},{\"nodeType\":3,\"id\":314,\"textContent\":\"U \"},{\"nodeType\":1,\"id\":315,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":316,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":317,\"textContent\":\" \"},{\"nodeType\":1,\"id\":318,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":319,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":320,\"textContent\":\" \"},{\"nodeType\":1,\"id\":321,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":322,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":323,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":324,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":325,\"textContent\":\" \"},{\"nodeType\":1,\"id\":326,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":327,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":328,\"textContent\":\" \"},{\"nodeType\":1,\"id\":329,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":330,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":331,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":332,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":333,\"textContent\":\" \"},{\"nodeType\":1,\"id\":334,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":335,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":336,\"textContent\":\" \"},{\"nodeType\":1,\"id\":337,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":338,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":339,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":340,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":341,\"textContent\":\" \"},{\"nodeType\":1,\"id\":342,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":343,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":344,\"textContent\":\" \"},{\"nodeType\":1,\"id\":345,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":346,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":347,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":348,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":349,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":350,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":351,\"textContent\":\" \"},{\"nodeType\":1,\"id\":352,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"acme\",\"id\":\"acme.meets\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":353,\"textContent\":\" \"},{\"nodeType\":1,\"id\":354,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":355,\"textContent\":\"Which shift(s) begin when C ends?\"}]},{\"nodeType\":3,\"id\":356,\"textContent\":\" \"},{\"nodeType\":1,\"id\":357,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":358,\"textContent\":\" \"},{\"nodeType\":1,\"id\":359,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":360,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":361,\"textContent\":\" \"},{\"nodeType\":1,\"id\":362,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":363,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":364,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":365,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":366,\"textContent\":\" \"},{\"nodeType\":1,\"id\":367,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":368,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":369,\"textContent\":\" \"},{\"nodeType\":1,\"id\":370,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":371,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":372,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":373,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":374,\"textContent\":\" \"},{\"nodeType\":1,\"id\":375,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":376,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":377,\"textContent\":\" \"},{\"nodeType\":1,\"id\":378,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":379,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":380,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":381,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":382,\"textContent\":\" \"},{\"nodeType\":1,\"id\":383,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":384,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":385,\"textContent\":\" \"},{\"nodeType\":1,\"id\":386,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":387,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":388,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":389,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":390,\"textContent\":\" \"},{\"nodeType\":1,\"id\":391,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":392,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":393,\"textContent\":\" \"},{\"nodeType\":1,\"id\":394,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":395,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":396,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":397,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":398,\"textContent\":\" \"},{\"nodeType\":1,\"id\":399,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":400,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":401,\"textContent\":\" \"},{\"nodeType\":1,\"id\":402,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":403,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":404,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":405,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":406,\"textContent\":\" \"},{\"nodeType\":1,\"id\":407,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":408,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":409,\"textContent\":\" \"},{\"nodeType\":1,\"id\":410,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":411,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":412,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":413,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":414,\"textContent\":\" \"},{\"nodeType\":1,\"id\":415,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":416,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":417,\"textContent\":\" \"},{\"nodeType\":1,\"id\":418,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":419,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":420,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":421,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":422,\"textContent\":\" \"},{\"nodeType\":1,\"id\":423,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":424,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":425,\"textContent\":\" \"},{\"nodeType\":1,\"id\":426,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":427,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":428,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":429,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":430,\"textContent\":\" \"},{\"nodeType\":1,\"id\":431,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":432,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":433,\"textContent\":\" \"},{\"nodeType\":1,\"id\":434,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":435,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":436,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":437,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":438,\"textContent\":\" \"},{\"nodeType\":1,\"id\":439,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":440,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":441,\"textContent\":\" \"},{\"nodeType\":1,\"id\":442,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"U\",\"value\":\"\"}},{\"nodeType\":3,\"id\":443,\"textContent\":\"U \"},{\"nodeType\":1,\"id\":444,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":445,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":446,\"textContent\":\" \"},{\"nodeType\":1,\"id\":447,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":448,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":449,\"textContent\":\" \"},{\"nodeType\":1,\"id\":450,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":451,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":452,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":453,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":454,\"textContent\":\" \"},{\"nodeType\":1,\"id\":455,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":456,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":457,\"textContent\":\" \"},{\"nodeType\":1,\"id\":458,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":459,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":460,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":461,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":462,\"textContent\":\" \"},{\"nodeType\":1,\"id\":463,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":464,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":465,\"textContent\":\" \"},{\"nodeType\":1,\"id\":466,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":467,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":468,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":469,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":470,\"textContent\":\" \"},{\"nodeType\":1,\"id\":471,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":472,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":473,\"textContent\":\" \"},{\"nodeType\":1,\"id\":474,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":475,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":476,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":477,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":478,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":479,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":480,\"textContent\":\" \"},{\"nodeType\":1,\"id\":481,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"acme\",\"id\":\"acme.endtime\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":482,\"textContent\":\" \"},{\"nodeType\":1,\"id\":483,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":484,\"textContent\":\" Which shift(s) end at 4 pm?\"}]},{\"nodeType\":3,\"id\":485,\"textContent\":\" \"},{\"nodeType\":1,\"id\":486,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":487,\"textContent\":\" \"},{\"nodeType\":1,\"id\":488,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":489,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":490,\"textContent\":\" \"},{\"nodeType\":1,\"id\":491,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":492,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":493,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":494,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":495,\"textContent\":\" \"},{\"nodeType\":1,\"id\":496,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":497,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":498,\"textContent\":\" \"},{\"nodeType\":1,\"id\":499,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":500,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":501,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":502,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":503,\"textContent\":\" \"},{\"nodeType\":1,\"id\":504,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":505,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":506,\"textContent\":\" \"},{\"nodeType\":1,\"id\":507,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":508,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":509,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":510,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":511,\"textContent\":\" \"},{\"nodeType\":1,\"id\":512,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":513,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":514,\"textContent\":\" \"},{\"nodeType\":1,\"id\":515,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":516,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":517,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":518,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":519,\"textContent\":\" \"},{\"nodeType\":1,\"id\":520,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":521,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":522,\"textContent\":\" \"},{\"nodeType\":1,\"id\":523,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":524,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":525,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":526,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":527,\"textContent\":\" \"},{\"nodeType\":1,\"id\":528,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":529,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":530,\"textContent\":\" \"},{\"nodeType\":1,\"id\":531,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":532,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":533,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":534,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":535,\"textContent\":\" \"},{\"nodeType\":1,\"id\":536,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":537,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":538,\"textContent\":\" \"},{\"nodeType\":1,\"id\":539,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":540,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":541,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":542,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":543,\"textContent\":\" \"},{\"nodeType\":1,\"id\":544,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":545,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":546,\"textContent\":\" \"},{\"nodeType\":1,\"id\":547,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":548,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":549,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":550,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":551,\"textContent\":\" \"},{\"nodeType\":1,\"id\":552,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":553,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":554,\"textContent\":\" \"},{\"nodeType\":1,\"id\":555,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":556,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":557,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":558,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":559,\"textContent\":\" \"},{\"nodeType\":1,\"id\":560,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":561,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":562,\"textContent\":\" \"},{\"nodeType\":1,\"id\":563,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":564,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":565,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":566,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":567,\"textContent\":\" \"},{\"nodeType\":1,\"id\":568,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":569,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":570,\"textContent\":\" \"},{\"nodeType\":1,\"id\":571,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"U\",\"value\":\"\"}},{\"nodeType\":3,\"id\":572,\"textContent\":\"U \"},{\"nodeType\":1,\"id\":573,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":574,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":575,\"textContent\":\" \"},{\"nodeType\":1,\"id\":576,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":577,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":578,\"textContent\":\" \"},{\"nodeType\":1,\"id\":579,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":580,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":581,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":582,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":583,\"textContent\":\" \"},{\"nodeType\":1,\"id\":584,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":585,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":586,\"textContent\":\" \"},{\"nodeType\":1,\"id\":587,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":588,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":589,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":590,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":591,\"textContent\":\" \"},{\"nodeType\":1,\"id\":592,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":593,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":594,\"textContent\":\" \"},{\"nodeType\":1,\"id\":595,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":596,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":597,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":598,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":599,\"textContent\":\" \"},{\"nodeType\":1,\"id\":600,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":601,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":602,\"textContent\":\" \"},{\"nodeType\":1,\"id\":603,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":604,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":605,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":606,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":607,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":608,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":609,\"textContent\":\" \"},{\"nodeType\":1,\"id\":610,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"acme\",\"id\":\"acme.midpoint\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":611,\"textContent\":\" \"},{\"nodeType\":1,\"id\":612,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":613,\"textContent\":\"Coffee breaks happen halfway through a shift.\"},{\"nodeType\":1,\"id\":614,\"tagName\":\"BR\",\"attributes\":{}},{\"nodeType\":3,\"id\":615,\"textContent\":\" Which shift(s) share a break with I?\"}]},{\"nodeType\":3,\"id\":616,\"textContent\":\" \"},{\"nodeType\":1,\"id\":617,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":618,\"textContent\":\" \"},{\"nodeType\":1,\"id\":619,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":620,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":621,\"textContent\":\" \"},{\"nodeType\":1,\"id\":622,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":623,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":624,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":625,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":626,\"textContent\":\" \"},{\"nodeType\":1,\"id\":627,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":628,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":629,\"textContent\":\" \"},{\"nodeType\":1,\"id\":630,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":631,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":632,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":633,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":634,\"textContent\":\" \"},{\"nodeType\":1,\"id\":635,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":636,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":637,\"textContent\":\" \"},{\"nodeType\":1,\"id\":638,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":639,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":640,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":641,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":642,\"textContent\":\" \"},{\"nodeType\":1,\"id\":643,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":644,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":645,\"textContent\":\" \"},{\"nodeType\":1,\"id\":646,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":647,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":648,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":649,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":650,\"textContent\":\" \"},{\"nodeType\":1,\"id\":651,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":652,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":653,\"textContent\":\" \"},{\"nodeType\":1,\"id\":654,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":655,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":656,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":657,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":658,\"textContent\":\" \"},{\"nodeType\":1,\"id\":659,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":660,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":661,\"textContent\":\" \"},{\"nodeType\":1,\"id\":662,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":663,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":664,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":665,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":666,\"textContent\":\" \"},{\"nodeType\":1,\"id\":667,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":668,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":669,\"textContent\":\" \"},{\"nodeType\":1,\"id\":670,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":671,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":672,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":673,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":674,\"textContent\":\" \"},{\"nodeType\":1,\"id\":675,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":676,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":677,\"textContent\":\" \"},{\"nodeType\":1,\"id\":678,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":679,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":680,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":681,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":682,\"textContent\":\" \"},{\"nodeType\":1,\"id\":683,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":684,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":685,\"textContent\":\" \"},{\"nodeType\":1,\"id\":686,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":687,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":688,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":689,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":690,\"textContent\":\" \"},{\"nodeType\":1,\"id\":691,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":692,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":693,\"textContent\":\" \"},{\"nodeType\":1,\"id\":694,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":695,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":696,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":697,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":698,\"textContent\":\" \"},{\"nodeType\":1,\"id\":699,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":700,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":701,\"textContent\":\" \"},{\"nodeType\":1,\"id\":702,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"U\",\"value\":\"\"}},{\"nodeType\":3,\"id\":703,\"textContent\":\"U \"},{\"nodeType\":1,\"id\":704,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":705,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":706,\"textContent\":\" \"},{\"nodeType\":1,\"id\":707,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":708,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":709,\"textContent\":\" \"},{\"nodeType\":1,\"id\":710,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":711,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":712,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":713,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":714,\"textContent\":\" \"},{\"nodeType\":1,\"id\":715,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":716,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":717,\"textContent\":\" \"},{\"nodeType\":1,\"id\":718,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":719,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":720,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":721,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":722,\"textContent\":\" \"},{\"nodeType\":1,\"id\":723,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":724,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":725,\"textContent\":\" \"},{\"nodeType\":1,\"id\":726,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":727,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":728,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":729,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":730,\"textContent\":\" \"},{\"nodeType\":1,\"id\":731,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":732,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":733,\"textContent\":\" \"},{\"nodeType\":1,\"id\":734,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":735,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":736,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":737,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":738,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":739,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":740,\"textContent\":\" \"},{\"nodeType\":1,\"id\":741,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.duration\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":742,\"textContent\":\" \"},{\"nodeType\":1,\"id\":743,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":744,\"textContent\":\"Which shift(s) are six hours long?\"}]},{\"nodeType\":3,\"id\":745,\"textContent\":\" \"},{\"nodeType\":1,\"id\":746,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":747,\"textContent\":\" \"},{\"nodeType\":1,\"id\":748,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":749,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":750,\"textContent\":\" \"},{\"nodeType\":1,\"id\":751,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":752,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":753,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":754,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":755,\"textContent\":\" \"},{\"nodeType\":1,\"id\":756,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":757,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":758,\"textContent\":\" \"},{\"nodeType\":1,\"id\":759,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":760,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":761,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":762,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":763,\"textContent\":\" \"},{\"nodeType\":1,\"id\":764,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":765,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":766,\"textContent\":\" \"},{\"nodeType\":1,\"id\":767,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":768,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":769,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":770,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":771,\"textContent\":\" \"},{\"nodeType\":1,\"id\":772,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":773,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":774,\"textContent\":\" \"},{\"nodeType\":1,\"id\":775,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":776,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":777,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":778,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":779,\"textContent\":\" \"},{\"nodeType\":1,\"id\":780,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":781,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":782,\"textContent\":\" \"},{\"nodeType\":1,\"id\":783,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":784,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":785,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":786,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":787,\"textContent\":\" \"},{\"nodeType\":1,\"id\":788,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":789,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":790,\"textContent\":\" \"},{\"nodeType\":1,\"id\":791,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":792,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":793,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":794,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":795,\"textContent\":\" \"},{\"nodeType\":1,\"id\":796,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":797,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":798,\"textContent\":\" \"},{\"nodeType\":1,\"id\":799,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":800,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":801,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":802,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":803,\"textContent\":\" \"},{\"nodeType\":1,\"id\":804,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":805,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":806,\"textContent\":\" \"},{\"nodeType\":1,\"id\":807,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":808,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":809,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":810,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":811,\"textContent\":\" \"},{\"nodeType\":1,\"id\":812,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":813,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":814,\"textContent\":\" \"},{\"nodeType\":1,\"id\":815,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":816,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":817,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":818,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":819,\"textContent\":\" \"},{\"nodeType\":1,\"id\":820,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":821,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":822,\"textContent\":\" \"},{\"nodeType\":1,\"id\":823,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":824,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":825,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":826,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":827,\"textContent\":\" \"},{\"nodeType\":1,\"id\":828,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":829,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":830,\"textContent\":\" \"},{\"nodeType\":1,\"id\":831,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":832,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":833,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":834,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":835,\"textContent\":\" \"},{\"nodeType\":1,\"id\":836,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":837,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":838,\"textContent\":\" \"},{\"nodeType\":1,\"id\":839,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":840,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":841,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":842,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":843,\"textContent\":\" \"},{\"nodeType\":1,\"id\":844,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":845,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":846,\"textContent\":\" \"},{\"nodeType\":1,\"id\":847,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":848,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":849,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":850,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":851,\"textContent\":\" \"},{\"nodeType\":1,\"id\":852,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":853,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":854,\"textContent\":\" \"},{\"nodeType\":1,\"id\":855,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":856,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":857,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":858,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":859,\"textContent\":\" \"},{\"nodeType\":1,\"id\":860,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":861,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":862,\"textContent\":\" \"},{\"nodeType\":1,\"id\":863,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":864,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":865,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":866,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":867,\"textContent\":\" \"},{\"nodeType\":1,\"id\":868,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":869,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":870,\"textContent\":\" \"},{\"nodeType\":1,\"id\":871,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":872,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":873,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":874,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":875,\"textContent\":\" \"},{\"nodeType\":1,\"id\":876,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":877,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":878,\"textContent\":\" \"},{\"nodeType\":1,\"id\":879,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":880,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":881,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":882,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":883,\"textContent\":\" \"},{\"nodeType\":1,\"id\":884,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":885,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":886,\"textContent\":\" \"},{\"nodeType\":1,\"id\":887,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":888,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":889,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":890,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":891,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":892,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":893,\"textContent\":\" \"},{\"nodeType\":1,\"id\":894,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.duration+starts\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":895,\"textContent\":\" \"},{\"nodeType\":1,\"id\":896,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":897,\"textContent\":\"Which 2 shifts less than 5 hours long start at the same time?\"}]},{\"nodeType\":3,\"id\":898,\"textContent\":\" \"},{\"nodeType\":1,\"id\":899,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":900,\"textContent\":\" \"},{\"nodeType\":1,\"id\":901,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":902,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":903,\"textContent\":\" \"},{\"nodeType\":1,\"id\":904,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":905,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":906,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":907,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":908,\"textContent\":\" \"},{\"nodeType\":1,\"id\":909,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":910,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":911,\"textContent\":\" \"},{\"nodeType\":1,\"id\":912,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":913,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":914,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":915,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":916,\"textContent\":\" \"},{\"nodeType\":1,\"id\":917,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":918,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":919,\"textContent\":\" \"},{\"nodeType\":1,\"id\":920,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":921,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":922,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":923,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":924,\"textContent\":\" \"},{\"nodeType\":1,\"id\":925,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":926,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":927,\"textContent\":\" \"},{\"nodeType\":1,\"id\":928,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":929,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":930,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":931,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":932,\"textContent\":\" \"},{\"nodeType\":1,\"id\":933,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":934,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":935,\"textContent\":\" \"},{\"nodeType\":1,\"id\":936,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":937,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":938,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":939,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":940,\"textContent\":\" \"},{\"nodeType\":1,\"id\":941,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":942,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":943,\"textContent\":\" \"},{\"nodeType\":1,\"id\":944,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":945,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":946,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":947,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":948,\"textContent\":\" \"},{\"nodeType\":1,\"id\":949,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":950,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":951,\"textContent\":\" \"},{\"nodeType\":1,\"id\":952,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":953,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":954,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":955,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":956,\"textContent\":\" \"},{\"nodeType\":1,\"id\":957,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":958,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":959,\"textContent\":\" \"},{\"nodeType\":1,\"id\":960,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":961,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":962,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":963,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":964,\"textContent\":\" \"},{\"nodeType\":1,\"id\":965,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":966,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":967,\"textContent\":\" \"},{\"nodeType\":1,\"id\":968,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":969,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":970,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":971,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":972,\"textContent\":\" \"},{\"nodeType\":1,\"id\":973,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":974,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":975,\"textContent\":\" \"},{\"nodeType\":1,\"id\":976,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":977,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":978,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":979,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":980,\"textContent\":\" \"},{\"nodeType\":1,\"id\":981,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":982,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":983,\"textContent\":\" \"},{\"nodeType\":1,\"id\":984,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":985,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":986,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":987,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":988,\"textContent\":\" \"},{\"nodeType\":1,\"id\":989,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":990,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":991,\"textContent\":\" \"},{\"nodeType\":1,\"id\":992,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":993,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":994,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":995,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":996,\"textContent\":\" \"},{\"nodeType\":1,\"id\":997,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":998,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":999,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1000,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1001,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":1002,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1003,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1004,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1005,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1006,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1007,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1008,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1009,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":1010,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1011,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1012,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1013,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1014,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1015,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1016,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1017,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":1018,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1019,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1020,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1021,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1022,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1023,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1024,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1025,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":1026,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1027,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1028,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1029,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1030,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1031,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1032,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1033,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":1034,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1035,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1036,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1037,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1038,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1039,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1040,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1041,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":1042,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1043,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1044,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1045,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1046,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1047,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.duration+contained\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":1048,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1049,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":1050,\"textContent\":\"Which shift(s) under 7 hours long starts before B starts, and ends after X ends?\"}]},{\"nodeType\":3,\"id\":1051,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1052,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":1053,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1054,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1055,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1056,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1057,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1058,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":1059,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1060,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1061,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1062,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1063,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1064,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1065,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1066,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":1067,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1068,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1069,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1070,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1071,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1072,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1073,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1074,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":1075,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1076,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1077,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1078,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1079,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1080,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1081,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1082,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":1083,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1084,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1085,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1086,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1087,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1088,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1089,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1090,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":1091,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1092,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1093,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1094,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1095,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1096,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1097,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1098,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":1099,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1100,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1101,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1102,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1103,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1104,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1105,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1106,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":1107,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1108,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1109,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1110,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1111,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1112,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1113,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1114,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":1115,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1116,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1117,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1118,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1119,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1120,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1121,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1122,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":1123,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1124,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1125,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1126,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1127,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1128,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1129,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1130,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":1131,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1132,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1133,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1134,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1135,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1136,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1137,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1138,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":1139,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1140,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1141,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1142,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1143,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1144,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1145,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1146,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":1147,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1148,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1149,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1150,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1151,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1152,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1153,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1154,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":1155,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1156,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1157,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1158,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1159,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1160,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1161,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1162,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":1163,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1164,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1165,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1166,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1167,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1168,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1169,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1170,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":1171,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1172,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1173,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1174,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1175,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1176,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1177,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1178,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":1179,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1180,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1181,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1182,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1183,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1184,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1185,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1186,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":1187,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1188,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1189,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1190,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1191,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1192,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1193,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1194,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":1195,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1196,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1197,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1198,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1199,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1200,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.starttime+before+endtime+during\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":1201,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1202,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":1203,\"textContent\":\"Which shift(s) begins before J begins and ends during B?\"}]},{\"nodeType\":3,\"id\":1204,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1205,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":1206,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1207,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1208,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1209,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1210,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1211,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":1212,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1213,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1214,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1215,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1216,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1217,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1218,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1219,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":1220,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1221,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1222,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1223,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1224,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1225,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1226,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1227,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":1228,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1229,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1230,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1231,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1232,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1233,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1234,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1235,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":1236,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1237,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1238,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1239,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1240,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1241,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1242,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1243,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":1244,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1245,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1246,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1247,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1248,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1249,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1250,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1251,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":1252,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1253,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1254,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1255,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1256,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1257,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1258,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1259,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":1260,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1261,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1262,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1263,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1264,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1265,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1266,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1267,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":1268,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1269,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1270,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1271,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1272,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1273,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1274,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1275,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":1276,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1277,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1278,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1279,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1280,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1281,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1282,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1283,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":1284,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1285,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1286,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1287,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1288,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1289,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1290,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1291,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":1292,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1293,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1294,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1295,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1296,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1297,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1298,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1299,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":1300,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1301,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1302,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1303,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1304,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1305,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1306,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1307,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":1308,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1309,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1310,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1311,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1312,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1313,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1314,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1315,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":1316,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1317,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1318,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1319,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1320,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1321,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1322,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1323,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":1324,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1325,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1326,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1327,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1328,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1329,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1330,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1331,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":1332,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1333,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1334,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1335,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1336,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1337,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1338,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1339,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":1340,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1341,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1342,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1343,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1344,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1345,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1346,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1347,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":1348,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1349,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1350,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1351,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1352,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1353,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.ends\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":1354,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1355,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":1356,\"textContent\":\"Which shift(s) end at the same time as F?\"}]},{\"nodeType\":3,\"id\":1357,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1358,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":1359,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1360,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1361,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1362,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1363,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1364,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":1365,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1366,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1367,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1368,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1369,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1370,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1371,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1372,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":1373,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1374,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1375,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1376,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1377,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1378,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1379,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1380,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":1381,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1382,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1383,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1384,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1385,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1386,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1387,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1388,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":1389,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1390,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1391,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1392,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1393,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1394,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1395,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1396,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":1397,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1398,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1399,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1400,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1401,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1402,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1403,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1404,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":1405,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1406,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1407,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1408,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1409,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1410,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1411,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1412,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":1413,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1414,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1415,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1416,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1417,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1418,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1419,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1420,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":1421,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1422,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1423,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1424,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1425,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1426,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1427,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1428,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":1429,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1430,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1431,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1432,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1433,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1434,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1435,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1436,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":1437,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1438,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1439,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1440,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1441,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1442,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1443,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1444,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":1445,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1446,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1447,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1448,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1449,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1450,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1451,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1452,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":1453,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1454,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1455,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1456,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1457,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1458,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1459,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1460,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":1461,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1462,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1463,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1464,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1465,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1466,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1467,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1468,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":1469,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1470,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1471,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1472,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1473,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1474,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1475,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1476,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":1477,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1478,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1479,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1480,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1481,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1482,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1483,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1484,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":1485,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1486,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1487,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1488,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1489,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1490,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1491,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1492,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":1493,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1494,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1495,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1496,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1497,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1498,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1499,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1500,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":1501,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1502,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1503,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1504,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1505,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1506,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.starttime\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":1507,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1508,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":1509,\"textContent\":\"Which shift(s) start at 12pm?\"}]},{\"nodeType\":3,\"id\":1510,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1511,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":1512,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1513,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1514,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1515,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1516,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1517,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":1518,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1519,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1520,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1521,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1522,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1523,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1524,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1525,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":1526,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1527,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1528,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1529,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1530,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1531,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1532,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1533,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":1534,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1535,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1536,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1537,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1538,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1539,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1540,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1541,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":1542,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1543,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1544,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1545,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1546,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1547,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1548,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1549,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":1550,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1551,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1552,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1553,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1554,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1555,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1556,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1557,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":1558,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1559,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1560,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1561,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1562,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1563,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1564,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1565,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":1566,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1567,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1568,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1569,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1570,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1571,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1572,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1573,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":1574,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1575,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1576,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1577,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1578,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1579,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1580,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1581,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":1582,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1583,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1584,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1585,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1586,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1587,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1588,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1589,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":1590,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1591,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1592,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1593,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1594,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1595,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1596,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1597,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":1598,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1599,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1600,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1601,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1602,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1603,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1604,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1605,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":1606,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1607,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1608,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1609,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1610,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1611,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1612,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1613,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":1614,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1615,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1616,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1617,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1618,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1619,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1620,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1621,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":1622,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1623,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1624,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1625,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1626,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1627,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1628,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1629,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":1630,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1631,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1632,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1633,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1634,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1635,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1636,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1637,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":1638,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1639,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1640,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1641,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1642,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1643,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1644,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1645,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":1646,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1647,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1648,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1649,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1650,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1651,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1652,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1653,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":1654,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1655,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1656,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1657,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1658,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1659,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.starts\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":1660,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1661,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":1662,\"textContent\":\"Which shift(s) start at the same time as F?\"}]},{\"nodeType\":3,\"id\":1663,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1664,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":1665,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1666,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1667,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1668,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1669,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1670,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":1671,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1672,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1673,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1674,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1675,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1676,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1677,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1678,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":1679,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1680,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1681,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1682,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1683,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1684,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1685,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1686,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":1687,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1688,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1689,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1690,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1691,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1692,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1693,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1694,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":1695,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1696,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1697,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1698,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1699,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1700,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1701,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1702,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":1703,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1704,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1705,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1706,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1707,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1708,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1709,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1710,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":1711,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1712,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1713,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1714,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1715,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1716,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1717,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1718,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":1719,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1720,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1721,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1722,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1723,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1724,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1725,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1726,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":1727,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1728,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1729,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1730,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1731,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1732,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1733,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1734,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":1735,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1736,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1737,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1738,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1739,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1740,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1741,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1742,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":1743,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1744,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1745,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1746,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1747,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1748,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1749,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1750,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":1751,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1752,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1753,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1754,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1755,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1756,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1757,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1758,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":1759,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1760,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1761,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1762,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1763,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1764,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1765,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1766,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":1767,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1768,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1769,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1770,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1771,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1772,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1773,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1774,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":1775,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1776,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1777,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1778,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1779,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1780,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1781,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1782,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":1783,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1784,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1785,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1786,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1787,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1788,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1789,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1790,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":1791,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1792,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1793,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1794,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1795,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1796,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1797,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1798,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":1799,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1800,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1801,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1802,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1803,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1804,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1805,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1806,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":1807,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1808,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1809,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1810,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1811,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1812,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.meets\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":1813,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1814,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":1815,\"textContent\":\"Which 2 shifts end when Z begins?\"}]},{\"nodeType\":3,\"id\":1816,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1817,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":1818,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1819,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1820,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1821,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1822,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1823,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":1824,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1825,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1826,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1827,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1828,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1829,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1830,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1831,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":1832,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1833,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1834,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1835,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1836,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1837,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1838,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1839,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":1840,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1841,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1842,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1843,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1844,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1845,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1846,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1847,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":1848,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1849,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1850,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1851,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1852,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1853,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1854,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1855,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":1856,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1857,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1858,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1859,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1860,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1861,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1862,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1863,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":1864,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1865,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1866,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1867,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1868,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1869,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1870,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1871,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":1872,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1873,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1874,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1875,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1876,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1877,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1878,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1879,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":1880,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1881,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1882,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1883,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1884,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1885,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1886,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1887,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":1888,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1889,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1890,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1891,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1892,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1893,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1894,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1895,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":1896,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1897,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1898,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1899,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1900,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1901,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1902,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1903,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":1904,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1905,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1906,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1907,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1908,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1909,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1910,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1911,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":1912,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1913,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1914,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1915,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1916,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1917,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1918,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1919,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":1920,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1921,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1922,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1923,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1924,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1925,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1926,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1927,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":1928,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1929,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1930,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1931,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1932,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1933,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1934,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1935,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":1936,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1937,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1938,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1939,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1940,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1941,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1942,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1943,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":1944,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1945,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1946,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1947,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1948,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1949,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1950,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1951,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":1952,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1953,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1954,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1955,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1956,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1957,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1958,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1959,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":1960,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1961,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1962,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1963,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1964,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1965,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.endtime\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":1966,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1967,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":1968,\"textContent\":\"Which shift(s) end at 3pm?\"}]},{\"nodeType\":3,\"id\":1969,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1970,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":1971,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1972,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1973,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1974,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1975,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1976,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":1977,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1978,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1979,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1980,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1981,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1982,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1983,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1984,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":1985,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1986,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1987,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1988,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1989,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1990,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1991,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1992,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":1993,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1994,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1995,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1996,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1997,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1998,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1999,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2000,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":2001,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2002,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2003,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2004,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2005,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2006,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2007,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2008,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":2009,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2010,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2011,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2012,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2013,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2014,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2015,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2016,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":2017,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2018,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2019,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2020,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2021,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2022,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2023,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2024,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":2025,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2026,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2027,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2028,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2029,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2030,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2031,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2032,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":2033,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2034,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2035,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2036,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2037,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2038,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2039,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2040,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":2041,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2042,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2043,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2044,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2045,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2046,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2047,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2048,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":2049,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2050,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2051,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2052,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2053,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2054,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2055,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2056,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":2057,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2058,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2059,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2060,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2061,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2062,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2063,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2064,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":2065,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2066,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2067,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2068,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2069,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2070,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2071,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2072,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":2073,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2074,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2075,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2076,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2077,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2078,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2079,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2080,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":2081,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2082,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2083,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2084,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2085,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2086,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2087,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2088,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":2089,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2090,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2091,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2092,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2093,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2094,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2095,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2096,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":2097,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2098,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2099,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2100,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2101,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2102,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2103,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2104,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":2105,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2106,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2107,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2108,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2109,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2110,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2111,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2112,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":2113,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2114,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2115,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2116,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2117,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2118,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.midpoint\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":2119,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2120,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":2121,\"textContent\":\"Coffee breaks happen halfway through a shift. \"},{\"nodeType\":1,\"id\":2122,\"tagName\":\"BR\",\"attributes\":{}},{\"nodeType\":3,\"id\":2123,\"textContent\":\"Which shifts share a break at 2pm?\"}]},{\"nodeType\":3,\"id\":2124,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2125,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":2126,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2127,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2128,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2129,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2130,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2131,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":2132,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2133,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2134,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2135,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2136,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2137,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2138,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2139,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":2140,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2141,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2142,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2143,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2144,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2145,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2146,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2147,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":2148,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2149,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2150,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2151,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2152,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2153,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2154,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2155,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":2156,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2157,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2158,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2159,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2160,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2161,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2162,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2163,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":2164,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2165,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2166,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2167,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2168,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2169,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2170,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2171,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":2172,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2173,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2174,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2175,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2176,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2177,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2178,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2179,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":2180,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2181,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2182,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2183,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2184,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2185,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2186,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2187,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":2188,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2189,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2190,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2191,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2192,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2193,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2194,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2195,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":2196,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2197,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2198,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2199,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2200,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2201,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2202,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2203,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":2204,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2205,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2206,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2207,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2208,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2209,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2210,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2211,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":2212,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2213,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2214,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2215,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2216,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2217,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2218,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2219,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":2220,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2221,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2222,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2223,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2224,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2225,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2226,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2227,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":2228,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2229,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2230,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2231,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2232,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2233,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2234,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2235,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":2236,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2237,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2238,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2239,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2240,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2241,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2242,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2243,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":2244,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2245,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2246,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2247,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2248,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2249,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2250,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2251,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":2252,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2253,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2254,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2255,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2256,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2257,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2258,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2259,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":2260,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2261,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2262,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2263,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2264,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2265,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2266,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2267,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":2268,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2269,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2270,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2271,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2272,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2273,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\".strategy\",\"style\":\"display: block;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2274,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2275,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":2276,\"textContent\":\"Please describe how to determine what event(s) start at 12pm?\"}]},{\"nodeType\":3,\"id\":2277,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2278,\"tagName\":\"TEXTAREA\",\"attributes\":{\"id\":\"strategyAnswer\",\"rows\":\"5\",\"cols\":\"80\"}},{\"nodeType\":3,\"id\":2279,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2280,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2281,\"textContent\":\" \"},{\"nodeType\":8,\"id\":2282},{\"nodeType\":3,\"id\":2283,\"textContent\":\" \"},{\"nodeType\":8,\"id\":2284},{\"nodeType\":3,\"id\":2285,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2286,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"fixbottom\"},\"childNodes\":[{\"nodeType\":3,\"id\":2287,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2288,\"tagName\":\"BUTTON\",\"attributes\":{\"type\":\"button\",\"id\":\"testingButton\",\"style\":\"display:none;\",\"class\":\"btn\"},\"childNodes\":[{\"nodeType\":3,\"id\":2289,\"textContent\":\"SUBMIT\"}]},{\"nodeType\":3,\"id\":2290,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2291,\"tagName\":\"BUTTON\",\"attributes\":{\"type\":\"button\",\"id\":\"strategyButton\",\"style\":\"display: block;\",\"class\":\"btn\"},\"childNodes\":[{\"nodeType\":3,\"id\":2292,\"textContent\":\"SUBMIT\"}]},{\"nodeType\":3,\"id\":2293,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2294,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2295,\"textContent\":\" \"},{\"nodeType\":8,\"id\":2296},{\"nodeType\":3,\"id\":2297,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2298,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"d3container\"},\"childNodes\":[{\"nodeType\":1,\"id\":2299,\"tagName\":\"svg\",\"attributes\":{\"width\":\"930\",\"height\":\"915\"},\"childNodes\":[{\"nodeType\":1,\"id\":2300,\"tagName\":\"g\",\"attributes\":{\"transform\":\"translate(100,25)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2301,\"tagName\":\"g\",\"attributes\":{\"class\":\"leaders\"}},{\"nodeType\":1,\"id\":2302,\"tagName\":\"g\",\"attributes\":{\"class\":\"static-scaffold\"}}]}]}]},{\"nodeType\":3,\"id\":2303,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2304,\"textContent\":\" \"},{\"nodeType\":8,\"id\":2305},{\"nodeType\":3,\"id\":2306,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2307,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":2308,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2309,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":2310,\"textContent\":\" \"}]}]}]]}",
  "useCssProxy": true,
  "loadTimes": "es: 329, dom: 1883, initialDom: 1976",
  "javascriptErrors": []
}