var MF = MF || {};MF.RecordingData = MF.RecordingData || {};MF.RecordingData["session"] = {
  "id": "3b7d4eea9a066713fac746c0b08d6aae",
  "created": "2018-05-21T12:40:32.4606-07:00",
  "lastActivity": "2018-05-21T12:41:04.5336-07:00",
  "pageViews": [
    {
      "id": "052131846989d2731ab6cfea03f2f9b4ab79f37b",
      "startTime": "2018-05-21T12:40:32.4606-07:00",
      "endTime": "2018-05-21T12:41:04.5336-07:00",
      "title": "FOX2YP",
      "uri": "https://warm-citadel-75324.herokuapp.com/",
      "websitePage": "/2",
      "visitTime": 32073,
      "engagementTime": 34331,
      "scroll": 99.0,
      "tags": [
        "form-interact"
      ],
      "friction": 0,
      "annotations": []
    }
  ],
  "duration": 32073,
  "engagementTime": 34331,
  "totalFriction": 0,
  "country": "us",
  "region": "CA",
  "city": "La Jolla",
  "isp": "University of California, San Diego",
  "ip": "128.54.9.248",
  "lang": "en-us",
  "userAgent": "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_11_6) AppleWebKit/604.5.6 (KHTML, like Gecko) Version/11.0.3 Safari/604.5.6",
  "browser": "Safari",
  "browserVersion": "11.0.3",
  "os": "OS X",
  "osVersion": "10.11 El Capitan",
  "device": "Desktop",
  "referrer": "",
  "referrerType": "",
  "screenRes": "1440x900",
  "tags": [
    "form-interact"
  ],
  "variables": [
    "SID=ZYASS",
    "CONDITION=121"
  ],
  "watched": false,
  "starred": false,
  "lng": -117.2359,
  "lat": 32.8807,
  "visitorId": "b5b6795c0e03e42ce414a3e100bff176",
  "gdpr": false
}