var MF = MF || {};MF.RecordingData = MF.RecordingData || {};MF.RecordingData["session"] = {
  "id": "f88c721a248d1bc2e7c4960d3ff33f3a",
  "created": "2018-05-14T13:02:32.3154378-07:00",
  "lastActivity": "2018-05-14T13:05:23.2494378-07:00",
  "pageViews": [
    {
      "id": "0514320931270e4f77a08cd0eb8463df2c1c8508",
      "startTime": "2018-05-14T13:02:32.3154378-07:00",
      "endTime": "2018-05-14T13:05:23.2494378-07:00",
      "title": "FOX2YP",
      "uri": "https://warm-citadel-75324.herokuapp.com/",
      "websitePage": "/",
      "visitTime": 170934,
      "engagementTime": 79219,
      "scroll": 100.0,
      "tags": [
        "form-interact"
      ],
      "friction": 0,
      "annotations": []
    }
  ],
  "duration": 170934,
  "engagementTime": 79219,
  "totalFriction": 0,
  "country": "us",
  "region": "CA",
  "city": "La Jolla",
  "isp": "University of California, San Diego",
  "ip": "128.54.68.37",
  "lang": "en-US",
  "userAgent": "Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/66.0.3359.170 Safari/537.36",
  "browser": "Chrome",
  "browserVersion": "66.0.3359.170",
  "os": "Windows",
  "osVersion": "7",
  "device": "Desktop",
  "referrer": "",
  "referrerType": "",
  "screenRes": "1920x1200",
  "tags": [
    "form-interact"
  ],
  "variables": [],
  "watched": false,
  "starred": false,
  "lng": -117.2359,
  "lat": 32.8807,
  "visitorId": "18af262ecadefb28def99afa6e0da65a",
  "gdpr": false
}