var MF = MF || {};MF.RecordingData = MF.RecordingData || {};MF.RecordingData["session"] = {
  "id": "854bb6c779c119c26f23db1168bd4fe3",
  "created": "2018-05-21T12:16:46.7664751-07:00",
  "lastActivity": "2018-05-21T12:17:02.8454948-07:00",
  "pageViews": [
    {
      "id": "052146911c8f61f6231e482ee9fbe788d825fa07",
      "startTime": "2018-05-21T12:16:46.9482205-07:00",
      "endTime": "2018-05-21T12:17:02.8454948-07:00",
      "title": "FOX2YP",
      "uri": "https://warm-citadel-75324.herokuapp.com/",
      "websitePage": "/13",
      "visitTime": 16120,
      "engagementTime": 16118,
      "scroll": 100.0,
      "tags": [
        "form-interact"
      ],
      "friction": 0,
      "annotations": []
    }
  ],
  "duration": 16120,
  "engagementTime": 16118,
  "totalFriction": 0,
  "country": "us",
  "region": "CA",
  "city": "La Jolla",
  "isp": "University of California, San Diego",
  "ip": "128.54.68.34",
  "lang": "en-US",
  "userAgent": "Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/66.0.3359.181 Safari/537.36",
  "browser": "Chrome",
  "browserVersion": "66.0.3359.181",
  "os": "Windows",
  "osVersion": "7",
  "device": "Desktop",
  "referrer": "",
  "referrerType": "",
  "screenRes": "1920x1200",
  "tags": [
    "form-interact"
  ],
  "variables": [
    "SID=GQ35Z",
    "CONDITION=111",
    "TRI_CORRECT=1"
  ],
  "watched": false,
  "starred": false,
  "lng": -117.2359,
  "lat": 32.8807,
  "visitorId": "74baa56de7fc030209fb22808986f10c",
  "gdpr": false
}