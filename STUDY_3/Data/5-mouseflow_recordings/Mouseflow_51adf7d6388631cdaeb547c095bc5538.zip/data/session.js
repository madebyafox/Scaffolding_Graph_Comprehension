var MF = MF || {};MF.RecordingData = MF.RecordingData || {};MF.RecordingData["session"] = {
  "id": "51adf7d6388631cdaeb547c095bc5538",
  "created": "2018-05-22T16:05:57.6901296-07:00",
  "lastActivity": "2018-05-22T16:06:53.7581296-07:00",
  "pageViews": [
    {
      "id": "05225839a1632426adbeefe4e2902060e8819ebe",
      "startTime": "2018-05-22T16:05:57.6901296-07:00",
      "endTime": "2018-05-22T16:06:53.7581296-07:00",
      "title": "FOX2YP",
      "uri": "https://warm-citadel-75324.herokuapp.com/",
      "websitePage": "/1",
      "visitTime": 56068,
      "engagementTime": 46826,
      "scroll": 100.0,
      "tags": [
        "form-interact"
      ],
      "friction": 0,
      "annotations": []
    }
  ],
  "duration": 56068,
  "engagementTime": 46826,
  "totalFriction": 0,
  "country": "us",
  "region": "CA",
  "city": "La Jolla",
  "isp": "University of California, San Diego",
  "ip": "128.54.68.23",
  "lang": "en-US",
  "userAgent": "Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/66.0.3359.181 Safari/537.36",
  "browser": "Chrome",
  "browserVersion": "66.0.3359.181",
  "os": "Windows",
  "osVersion": "7",
  "device": "Desktop",
  "referrer": "",
  "referrerType": "",
  "screenRes": "1920x1200",
  "tags": [
    "form-interact"
  ],
  "variables": [
    "SID=E5L6P",
    "CONDITION=115",
    "ORTH_CORRECT=1"
  ],
  "watched": false,
  "starred": false,
  "lng": -117.2359,
  "lat": 32.8807,
  "visitorId": "87737b0c376ae0e375ba68ed9c0755eb",
  "gdpr": false
}