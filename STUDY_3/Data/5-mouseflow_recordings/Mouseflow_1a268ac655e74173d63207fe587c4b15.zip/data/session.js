var MF = MF || {};MF.RecordingData = MF.RecordingData || {};MF.RecordingData["session"] = {
  "id": "1a268ac655e74173d63207fe587c4b15",
  "created": "2018-05-29T12:07:51.0338667-07:00",
  "lastActivity": "2018-05-29T12:09:58.8316309-07:00",
  "pageViews": [
    {
      "id": "0529519795f16fdacc59f49d7bc9f0d2c223b659",
      "startTime": "2018-05-29T12:07:51.1968474-07:00",
      "endTime": "2018-05-29T12:09:58.8316309-07:00",
      "title": "FOX2YP",
      "uri": "https://warm-citadel-75324.herokuapp.com/",
      "websitePage": "/5",
      "visitTime": 128036,
      "engagementTime": 112405,
      "scroll": 100.0,
      "tags": [
        "form-interact"
      ],
      "friction": 0,
      "annotations": []
    }
  ],
  "duration": 128036,
  "engagementTime": 112405,
  "totalFriction": 0,
  "country": "us",
  "region": "CA",
  "city": "La Jolla",
  "isp": "University of California, San Diego",
  "ip": "128.54.68.29",
  "lang": "en-US",
  "userAgent": "Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/66.0.3359.181 Safari/537.36",
  "browser": "Chrome",
  "browserVersion": "66.0.3359.181",
  "os": "Windows",
  "osVersion": "7",
  "device": "Desktop",
  "referrer": "",
  "referrerType": "",
  "screenRes": "1920x1200",
  "tags": [
    "form-interact"
  ],
  "variables": [
    "SID=BWVFU",
    "CONDITION=114\n114",
    "ORTH_CORRECT=1"
  ],
  "watched": false,
  "starred": false,
  "lng": -117.2359,
  "lat": 32.8807,
  "visitorId": "93a441abeac9e3410c425e9077bc9b7c",
  "gdpr": false
}