var MF = MF || {};MF.RecordingData = MF.RecordingData || {};MF.RecordingData["session"] = {
  "id": "7ae92f4f24333da9ac67013ac51033b4",
  "created": "2018-05-29T10:10:30.9670677-07:00",
  "lastActivity": "2018-05-29T10:11:20.098944-07:00",
  "pageViews": [
    {
      "id": "05293108bc5160eb797f0c59d0808dffe21786c5",
      "startTime": "2018-05-29T10:10:31.0985362-07:00",
      "endTime": "2018-05-29T10:11:20.098944-07:00",
      "title": "FOX2YP",
      "uri": "https://warm-citadel-75324.herokuapp.com/",
      "websitePage": "/10",
      "visitTime": 49091,
      "engagementTime": 46592,
      "scroll": 100.0,
      "tags": [
        "form-interact"
      ],
      "friction": 0,
      "annotations": []
    }
  ],
  "duration": 49091,
  "engagementTime": 46592,
  "totalFriction": 0,
  "country": "us",
  "region": "CA",
  "city": "La Jolla",
  "isp": "University of California, San Diego",
  "ip": "128.54.68.23",
  "lang": "en-US",
  "userAgent": "Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/66.0.3359.181 Safari/537.36",
  "browser": "Chrome",
  "browserVersion": "66.0.3359.181",
  "os": "Windows",
  "osVersion": "7",
  "device": "Desktop",
  "referrer": "",
  "referrerType": "",
  "screenRes": "1920x1200",
  "tags": [
    "form-interact"
  ],
  "variables": [
    "SID=FR69M",
    "CONDITION=114"
  ],
  "watched": false,
  "starred": false,
  "lng": -117.2359,
  "lat": 32.8807,
  "visitorId": "2189f2d26829482db1c9c8a47403047e",
  "gdpr": false
}