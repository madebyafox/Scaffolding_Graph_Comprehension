var MF = MF || {};MF.RecordingData = MF.RecordingData || {};MF.RecordingData["session"] = {
  "id": "0d1ff68159e2dca2703ce7bc9ba13fd0",
  "created": "2018-05-21T12:57:50.350291-07:00",
  "lastActivity": "2018-05-21T12:58:04.4920809-07:00",
  "pageViews": [
    {
      "id": "052150689695dadb2ad79a5427dfa2c6e5b03f39",
      "startTime": "2018-05-21T12:57:50.4123212-07:00",
      "endTime": "2018-05-21T12:58:04.4920809-07:00",
      "title": "FOX2YP",
      "uri": "https://warm-citadel-75324.herokuapp.com/",
      "websitePage": "/11",
      "visitTime": 14123,
      "engagementTime": 14123,
      "scroll": 100.0,
      "tags": [
        "form-interact"
      ],
      "friction": 0,
      "annotations": []
    }
  ],
  "duration": 14123,
  "engagementTime": 14123,
  "totalFriction": 0,
  "country": "us",
  "region": "CA",
  "city": "La Jolla",
  "isp": "University of California, San Diego",
  "ip": "128.54.9.248",
  "lang": "en-us",
  "userAgent": "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_11_6) AppleWebKit/604.5.6 (KHTML, like Gecko) Version/11.0.3 Safari/604.5.6",
  "browser": "Safari",
  "browserVersion": "11.0.3",
  "os": "OS X",
  "osVersion": "10.11 El Capitan",
  "device": "Desktop",
  "referrer": "",
  "referrerType": "",
  "screenRes": "1440x900",
  "tags": [
    "form-interact"
  ],
  "variables": [
    "SID=WQKT9",
    "CONDITION=121",
    "TRI_CORRECT=1"
  ],
  "watched": false,
  "starred": false,
  "lng": -117.2359,
  "lat": 32.8807,
  "visitorId": "bf222d46e92c7fabbcaebcc76c3ba319",
  "gdpr": false
}