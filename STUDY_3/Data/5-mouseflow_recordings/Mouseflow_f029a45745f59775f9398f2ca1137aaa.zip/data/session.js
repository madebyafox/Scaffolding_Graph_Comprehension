var MF = MF || {};MF.RecordingData = MF.RecordingData || {};MF.RecordingData["session"] = {
  "id": "f029a45745f59775f9398f2ca1137aaa",
  "created": "2018-06-04T12:12:28.6603727-07:00",
  "lastActivity": "2018-06-04T12:13:05.469798-07:00",
  "pageViews": [
    {
      "id": "06042894709a78dbccb0e01714de698c7af4e501",
      "startTime": "2018-06-04T12:12:28.7653335-07:00",
      "endTime": "2018-06-04T12:13:05.469798-07:00",
      "title": "FOX2YP",
      "uri": "https://warm-citadel-75324.herokuapp.com/",
      "websitePage": "/1",
      "visitTime": 36795,
      "engagementTime": 33944,
      "scroll": 100.0,
      "tags": [
        "form-interact"
      ],
      "friction": 0,
      "annotations": []
    }
  ],
  "duration": 36795,
  "engagementTime": 33944,
  "totalFriction": 0,
  "country": "us",
  "region": "CA",
  "city": "La Jolla",
  "isp": "University of California, San Diego",
  "ip": "128.54.68.43",
  "lang": "en-US",
  "userAgent": "Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/67.0.3396.62 Safari/537.36",
  "browser": "Chrome",
  "browserVersion": "67.0.3396.62",
  "os": "Windows",
  "osVersion": "7",
  "device": "Desktop",
  "referrer": "",
  "referrerType": "",
  "screenRes": "1920x1200",
  "tags": [
    "form-interact"
  ],
  "variables": [
    "SID=6GNVQ",
    "CONDITION=311",
    "TRI_CORRECT=1"
  ],
  "watched": false,
  "starred": false,
  "lng": -117.2359,
  "lat": 32.8807,
  "visitorId": "db44eeeddafb3f9c46c0da4fe2bcd8b2",
  "gdpr": false
}