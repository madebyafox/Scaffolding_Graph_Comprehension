var MF = MF || {};MF.RecordingData = MF.RecordingData || {};MF.RecordingData["session"] = {
  "id": "2ec9ab7a28b2043192706ddce3190477",
  "created": "2018-05-16T11:03:44.6692915-07:00",
  "lastActivity": "2018-05-16T11:04:32.4742915-07:00",
  "pageViews": [
    {
      "id": "051644783847cd36ec86c0da8fd9cae43cb8ef22",
      "startTime": "2018-05-16T11:03:44.6692915-07:00",
      "endTime": "2018-05-16T11:04:32.4742915-07:00",
      "title": "FOX2YP",
      "uri": "https://warm-citadel-75324.herokuapp.com/",
      "websitePage": "/1",
      "visitTime": 47805,
      "engagementTime": 46814,
      "scroll": 100.0,
      "tags": [
        "form-interact"
      ],
      "friction": 0,
      "annotations": []
    }
  ],
  "duration": 47805,
  "engagementTime": 46814,
  "totalFriction": 0,
  "country": "us",
  "region": "CA",
  "city": "La Jolla",
  "isp": "University of California, San Diego",
  "ip": "128.54.68.26",
  "lang": "en-US",
  "userAgent": "Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/66.0.3359.170 Safari/537.36",
  "browser": "Chrome",
  "browserVersion": "66.0.3359.170",
  "os": "Windows",
  "osVersion": "7",
  "device": "Desktop",
  "referrer": "",
  "referrerType": "",
  "screenRes": "1920x1200",
  "tags": [
    "form-interact"
  ],
  "variables": [
    "SID=QUCDX",
    "CONDITION=111",
    "ORTH_CORRECT=1"
  ],
  "watched": false,
  "starred": false,
  "lng": -117.2359,
  "lat": 32.8807,
  "visitorId": "eb6395ecf3dde3b97e4af355593264fd",
  "gdpr": false
}