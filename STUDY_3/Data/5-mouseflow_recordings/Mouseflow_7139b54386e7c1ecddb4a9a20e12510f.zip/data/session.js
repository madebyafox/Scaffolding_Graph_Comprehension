var MF = MF || {};MF.RecordingData = MF.RecordingData || {};MF.RecordingData["session"] = {
  "id": "7139b54386e7c1ecddb4a9a20e12510f",
  "created": "2018-05-21T12:19:14.1217021-07:00",
  "lastActivity": "2018-05-21T12:19:35.7507021-07:00",
  "pageViews": [
    {
      "id": "052114734cedb4a332de9d1fb419bd26e6e5fb88",
      "startTime": "2018-05-21T12:19:14.1217021-07:00",
      "endTime": "2018-05-21T12:19:35.7507021-07:00",
      "title": "FOX2YP",
      "uri": "https://warm-citadel-75324.herokuapp.com/",
      "websitePage": "/13",
      "visitTime": 21629,
      "engagementTime": 21629,
      "scroll": 100.0,
      "tags": [
        "form-interact"
      ],
      "friction": 0,
      "annotations": []
    }
  ],
  "duration": 21629,
  "engagementTime": 21629,
  "totalFriction": 0,
  "country": "us",
  "region": "CA",
  "city": "La Jolla",
  "isp": "University of California, San Diego",
  "ip": "128.54.68.40",
  "lang": "en-US",
  "userAgent": "Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/66.0.3359.181 Safari/537.36",
  "browser": "Chrome",
  "browserVersion": "66.0.3359.181",
  "os": "Windows",
  "osVersion": "7",
  "device": "Desktop",
  "referrer": "",
  "referrerType": "",
  "screenRes": "1920x1200",
  "tags": [
    "form-interact"
  ],
  "variables": [
    "SID=F3GZE",
    "CONDITION=111",
    "TRI_CORRECT=1"
  ],
  "watched": false,
  "starred": false,
  "lng": -117.2359,
  "lat": 32.8807,
  "visitorId": "492ea89c9f7397b48f14568888f1786c",
  "gdpr": false
}