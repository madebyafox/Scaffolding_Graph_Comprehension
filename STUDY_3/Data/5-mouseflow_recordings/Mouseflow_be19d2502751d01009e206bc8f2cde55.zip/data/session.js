var MF = MF || {};MF.RecordingData = MF.RecordingData || {};MF.RecordingData["session"] = {
  "id": "be19d2502751d01009e206bc8f2cde55",
  "created": "2018-05-29T10:05:14.4559392-07:00",
  "lastActivity": "2018-05-29T10:05:29.605381-07:00",
  "pageViews": [
    {
      "id": "05291432f5a00e75e9ac7ee6e1b4a10dcaf319c4",
      "startTime": "2018-05-29T10:05:14.4559392-07:00",
      "endTime": "2018-05-29T10:05:29.605381-07:00",
      "title": "FOX2YP",
      "uri": "https://warm-citadel-75324.herokuapp.com/",
      "websitePage": "/1",
      "visitTime": 15243,
      "engagementTime": 15243,
      "scroll": 100.0,
      "tags": [
        "form-interact"
      ],
      "friction": 0,
      "annotations": []
    }
  ],
  "duration": 15243,
  "engagementTime": 15243,
  "totalFriction": 0,
  "country": "us",
  "region": "CA",
  "city": "La Jolla",
  "isp": "University of California, San Diego",
  "ip": "128.54.68.31",
  "lang": "en-US",
  "userAgent": "Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/66.0.3359.181 Safari/537.36",
  "browser": "Chrome",
  "browserVersion": "66.0.3359.181",
  "os": "Windows",
  "osVersion": "7",
  "device": "Desktop",
  "referrer": "",
  "referrerType": "",
  "screenRes": "1920x1200",
  "tags": [
    "form-interact"
  ],
  "variables": [
    "SID=8GUB2",
    "CONDITION=114",
    "ORTH_CORRECT=1"
  ],
  "watched": false,
  "starred": false,
  "lng": -117.2359,
  "lat": 32.8807,
  "visitorId": "83842213e94c77092cc950ee935178c6",
  "gdpr": false
}