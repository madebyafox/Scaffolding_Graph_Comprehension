var MF = MF || {};MF.RecordingData = MF.RecordingData || {};MF.RecordingData["session"] = {
  "id": "4b53aabf0c97ce614bd91c01e6f42963",
  "created": "2018-05-25T10:08:24.1417923-07:00",
  "lastActivity": "2018-05-25T10:08:43.0464946-07:00",
  "pageViews": [
    {
      "id": "0525240557f818e193d8df9e0b119984f5980fbd",
      "startTime": "2018-05-25T10:08:24.1494946-07:00",
      "endTime": "2018-05-25T10:08:43.0464946-07:00",
      "title": "FOX2YP",
      "uri": "https://warm-citadel-75324.herokuapp.com/",
      "websitePage": "/1",
      "visitTime": 18897,
      "engagementTime": 18876,
      "scroll": 100.0,
      "tags": [
        "form-interact"
      ],
      "friction": 0,
      "annotations": []
    }
  ],
  "duration": 18897,
  "engagementTime": 18876,
  "totalFriction": 0,
  "country": "us",
  "region": "CA",
  "city": "La Jolla",
  "isp": "University of California, San Diego",
  "ip": "128.54.68.28",
  "lang": "en-US",
  "userAgent": "Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/66.0.3359.181 Safari/537.36",
  "browser": "Chrome",
  "browserVersion": "66.0.3359.181",
  "os": "Windows",
  "osVersion": "7",
  "device": "Desktop",
  "referrer": "",
  "referrerType": "",
  "screenRes": "1920x1200",
  "tags": [
    "form-interact"
  ],
  "variables": [
    "SID=3A2HT",
    "CONDITION=115",
    "ORTH_CORRECT=1"
  ],
  "watched": false,
  "starred": false,
  "lng": -117.2359,
  "lat": 32.8807,
  "visitorId": "fadcb64d7cce62fe7f859e5678970e7f",
  "gdpr": false
}