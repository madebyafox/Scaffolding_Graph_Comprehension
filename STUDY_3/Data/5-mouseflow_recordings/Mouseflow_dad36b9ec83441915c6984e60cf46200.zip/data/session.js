var MF = MF || {};MF.RecordingData = MF.RecordingData || {};MF.RecordingData["session"] = {
  "id": "dad36b9ec83441915c6984e60cf46200",
  "created": "2018-05-25T11:11:25.9696011-07:00",
  "lastActivity": "2018-05-25T11:11:57.7026011-07:00",
  "pageViews": [
    {
      "id": "05252623ddb9f791370df33635fae50b7fb657d5",
      "startTime": "2018-05-25T11:11:25.9696011-07:00",
      "endTime": "2018-05-25T11:11:57.7026011-07:00",
      "title": "FOX2YP",
      "uri": "https://warm-citadel-75324.herokuapp.com/",
      "websitePage": "/8",
      "visitTime": 31733,
      "engagementTime": 30384,
      "scroll": 100.0,
      "tags": [
        "form-interact"
      ],
      "friction": 0,
      "annotations": []
    }
  ],
  "duration": 31733,
  "engagementTime": 30384,
  "totalFriction": 0,
  "country": "us",
  "region": "CA",
  "city": "La Jolla",
  "isp": "University of California, San Diego",
  "ip": "128.54.68.40",
  "lang": "en-US",
  "userAgent": "Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/66.0.3359.181 Safari/537.36",
  "browser": "Chrome",
  "browserVersion": "66.0.3359.181",
  "os": "Windows",
  "osVersion": "7",
  "device": "Desktop",
  "referrer": "",
  "referrerType": "",
  "screenRes": "1920x1200",
  "tags": [
    "form-interact"
  ],
  "variables": [
    "SID=DFQLY",
    "CONDITION=114",
    "TRI_CORRECT=1"
  ],
  "watched": false,
  "starred": false,
  "lng": -117.2359,
  "lat": 32.8807,
  "visitorId": "267adf81755214c46fe9a23408b705f3",
  "gdpr": false
}