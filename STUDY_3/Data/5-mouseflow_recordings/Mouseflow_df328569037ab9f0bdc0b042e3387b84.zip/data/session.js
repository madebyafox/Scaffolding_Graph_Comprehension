var MF = MF || {};MF.RecordingData = MF.RecordingData || {};MF.RecordingData["session"] = {
  "id": "df328569037ab9f0bdc0b042e3387b84",
  "created": "2018-06-04T12:31:19.1469594-07:00",
  "lastActivity": "2018-06-04T12:31:33.3199594-07:00",
  "pageViews": [
    {
      "id": "06041951880ed09f873c96e68e0cc68bed9ca878",
      "startTime": "2018-06-04T12:31:19.1469594-07:00",
      "endTime": "2018-06-04T12:31:33.3199594-07:00",
      "title": "FOX2YP",
      "uri": "https://warm-citadel-75324.herokuapp.com/",
      "websitePage": "/14",
      "visitTime": 14173,
      "engagementTime": 14122,
      "scroll": 100.0,
      "tags": [
        "form-interact"
      ],
      "friction": 0,
      "annotations": []
    }
  ],
  "duration": 14173,
  "engagementTime": 14122,
  "totalFriction": 0,
  "country": "us",
  "region": "CA",
  "city": "La Jolla",
  "isp": "University of California, San Diego",
  "ip": "128.54.68.28",
  "lang": "en-US",
  "userAgent": "Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/66.0.3359.181 Safari/537.36",
  "browser": "Chrome",
  "browserVersion": "66.0.3359.181",
  "os": "Windows",
  "osVersion": "7",
  "device": "Desktop",
  "referrer": "",
  "referrerType": "",
  "screenRes": "1920x1200",
  "tags": [
    "form-interact"
  ],
  "variables": [
    "SID=74OF5",
    "CONDITION=311\n311",
    "TRI_CORRECT=1"
  ],
  "watched": false,
  "starred": false,
  "lng": -117.2359,
  "lat": 32.8807,
  "visitorId": "c96a2ed37850b0b14c140a02551ccfa3",
  "gdpr": false
}