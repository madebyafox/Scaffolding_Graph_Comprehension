var MF = MF || {};MF.RecordingData = MF.RecordingData || {};MF.RecordingData["session"] = {
  "id": "e0df210ba10cf0d9f8abb5153ec25783",
  "created": "2018-06-04T13:20:39.988818-07:00",
  "lastActivity": "2018-06-04T13:20:52.269818-07:00",
  "pageViews": [
    {
      "id": "060440792c1632795f520b6498371d960edd4a8f",
      "startTime": "2018-06-04T13:20:39.988818-07:00",
      "endTime": "2018-06-04T13:20:52.269818-07:00",
      "title": "FOX2YP",
      "uri": "https://warm-citadel-75324.herokuapp.com/",
      "websitePage": "/6",
      "visitTime": 12281,
      "engagementTime": 12189,
      "scroll": 100.0,
      "tags": [
        "form-interact"
      ],
      "friction": 0,
      "annotations": []
    }
  ],
  "duration": 12281,
  "engagementTime": 12189,
  "totalFriction": 0,
  "country": "us",
  "region": "CA",
  "city": "La Jolla",
  "isp": "University of California, San Diego",
  "ip": "128.54.68.38",
  "lang": "en-US",
  "userAgent": "Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/66.0.3359.181 Safari/537.36",
  "browser": "Chrome",
  "browserVersion": "66.0.3359.181",
  "os": "Windows",
  "osVersion": "7",
  "device": "Desktop",
  "referrer": "",
  "referrerType": "",
  "screenRes": "1920x1200",
  "tags": [
    "form-interact"
  ],
  "variables": [
    "SID=MUULG",
    "CONDITION=211",
    "TRI_CORRECT=1",
    "ORTH_CORRECT=1"
  ],
  "watched": false,
  "starred": false,
  "lng": -117.2359,
  "lat": 32.8807,
  "visitorId": "7f77d6f5a9d76a5703e4a10d6e8d03a1",
  "gdpr": false
}