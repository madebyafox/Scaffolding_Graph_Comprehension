var MF = MF || {};MF.RecordingData = MF.RecordingData || {};MF.RecordingData["session"] = {
  "id": "d6afd05603188f0c53b85b094955519b",
  "created": "2018-05-21T12:18:06.9233717-07:00",
  "lastActivity": "2018-05-21T12:22:39.9827546-07:00",
  "pageViews": [
    {
      "id": "05210743e53619e40d7fd6eb7bee020ea8ddad7e",
      "startTime": "2018-05-21T12:18:06.9233717-07:00",
      "endTime": "2018-05-21T12:22:39.9827546-07:00",
      "title": "FOX2YP",
      "uri": "https://warm-citadel-75324.herokuapp.com/",
      "websitePage": "/5",
      "visitTime": 273273,
      "engagementTime": 242824,
      "scroll": 100.0,
      "tags": [
        "form-interact"
      ],
      "friction": 0,
      "annotations": []
    }
  ],
  "duration": 273273,
  "engagementTime": 242824,
  "totalFriction": 0,
  "country": "us",
  "region": "CA",
  "city": "La Jolla",
  "isp": "University of California, San Diego",
  "ip": "128.54.68.43",
  "lang": "en-US",
  "userAgent": "Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/66.0.3359.181 Safari/537.36",
  "browser": "Chrome",
  "browserVersion": "66.0.3359.181",
  "os": "Windows",
  "osVersion": "7",
  "device": "Desktop",
  "referrer": "",
  "referrerType": "",
  "screenRes": "1920x1200",
  "tags": [
    "form-interact"
  ],
  "variables": [
    "SID=J1JP6",
    "CONDITION=111"
  ],
  "watched": false,
  "starred": false,
  "lng": -117.2359,
  "lat": 32.8807,
  "visitorId": "6e9601f37087b5a28a7098524073c127",
  "gdpr": false
}