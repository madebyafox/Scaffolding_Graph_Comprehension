var MF = MF || {};MF.RecordingData = MF.RecordingData || {};MF.RecordingData["session"] = {
  "id": "7bd6b8e10d2c64a9e7ae53feabecfdfb",
  "created": "2018-05-29T16:14:32.7363551-07:00",
  "lastActivity": "2018-05-29T16:15:17.2563551-07:00",
  "pageViews": [
    {
      "id": "052932528154da6fd6b0bf6499fdbc4152601b09",
      "startTime": "2018-05-29T16:14:32.7363551-07:00",
      "endTime": "2018-05-29T16:15:17.2563551-07:00",
      "title": "FOX2YP",
      "uri": "https://warm-citadel-75324.herokuapp.com/",
      "websitePage": "/7",
      "visitTime": 44520,
      "engagementTime": 44318,
      "scroll": 100.0,
      "tags": [
        "form-interact"
      ],
      "friction": 0,
      "annotations": []
    }
  ],
  "duration": 44520,
  "engagementTime": 44318,
  "totalFriction": 0,
  "country": "us",
  "region": "CA",
  "city": "La Jolla",
  "isp": "University of California, San Diego",
  "ip": "128.54.68.48",
  "lang": "en-US",
  "userAgent": "Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/66.0.3359.181 Safari/537.36",
  "browser": "Chrome",
  "browserVersion": "66.0.3359.181",
  "os": "Windows",
  "osVersion": "7",
  "device": "Desktop",
  "referrer": "",
  "referrerType": "",
  "screenRes": "1920x1200",
  "tags": [
    "form-interact"
  ],
  "variables": [
    "SID=SQ6AK",
    "CONDITION=113"
  ],
  "watched": false,
  "starred": false,
  "lng": -117.2359,
  "lat": 32.8807,
  "visitorId": "8f3e3c0b7b786c3890abac56afa588d7",
  "gdpr": false
}