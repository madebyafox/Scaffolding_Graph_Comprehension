var MF = MF || {};MF.RecordingData = MF.RecordingData || {};MF.RecordingData["060436823ecd6a0b19ef699557c0056486962b18"] = {
  "startTime": "2018-06-04T20:30:36.8211043Z",
  "websitePageUrl": "/16",
  "visitTime": 54002,
  "engagementTime": 53864,
  "pageTitle": "FOX2YP",
  "url": "https://warm-citadel-75324.herokuapp.com/",
  "viewportWidth": 1920,
  "viewportHeight": 1200,
  "tags": [
    "form-interact",
    "submit"
  ],
  "session": {
    "id": "07d1cd781be295756c12ffd6f767f770",
    "created": "2018-06-04T20:30:36.8211043+00:00",
    "lastActivity": "0001-01-01T00:00:00+00:00",
    "pages": 1,
    "duration": 0,
    "engagementTime": 0,
    "totalFriction": 0,
    "country": "us",
    "region": "CA",
    "city": "La Jolla",
    "isp": "University of California, San Diego",
    "ip": "###.###.###.###",
    "lang": "en-US",
    "userAgent": "Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/66.0.3359.181 Safari/537.36",
    "browser": "Chrome",
    "browserVersion": "66.0.3359.181",
    "os": "Windows",
    "osVersion": "7",
    "device": "Desktop",
    "referrer": "",
    "referrerType": "",
    "screenRes": "1920x1200",
    "entryPage": "/16",
    "tags": [
      "form-interact",
      "submit"
    ],
    "variables": [
      "SID=MKTF4",
      "CONDITION=211"
    ],
    "watched": false,
    "starred": false,
    "lng": 32.8807,
    "lat": 32.8807,
    "visitorId": "564b338f188f546886c46b3fe2e2e20a",
    "gdpr": false,
    "visitorName": null,
    "playbackUrl": "https://us.mouseflow.com/websites/e0c9ff05-6fcb-4c4a-8173-e5a0724987b1/recordings/07d1cd781be295756c12ffd6f767f770/play"
  },
  "events": [
    {
      "t": 0,
      "e": 0,
      "ty": 0,
      "x": 1920,
      "y": 1200
    },
    {
      "t": 0,
      "e": 0,
      "ty": 1,
      "x": 8,
      "y": 16
    },
    {
      "t": 0,
      "e": 0,
      "ty": 14,
      "x": 0,
      "y": 1199
    },
    {
      "t": 99,
      "e": 99,
      "ty": 2,
      "x": 704,
      "y": 709
    },
    {
      "t": 250,
      "e": 250,
      "ty": 41,
      "x": 23968,
      "y": 38833,
      "ta": "html > body"
    },
    {
      "t": 300,
      "e": 300,
      "ty": 2,
      "x": 705,
      "y": 700
    },
    {
      "t": 603,
      "e": 603,
      "ty": 2,
      "x": 708,
      "y": 685
    },
    {
      "t": 604,
      "e": 604,
      "ty": 41,
      "x": 1601,
      "y": 38838,
      "ta": "> div.stimulus > div:[2]"
    },
    {
      "t": 899,
      "e": 899,
      "ty": 2,
      "x": 708,
      "y": 684
    },
    {
      "t": 1001,
      "e": 1001,
      "ty": 41,
      "x": 1601,
      "y": 38767,
      "ta": "> div.stimulus > div:[2]"
    },
    {
      "t": 1100,
      "e": 1100,
      "ty": 2,
      "x": 661,
      "y": 647
    },
    {
      "t": 1202,
      "e": 1202,
      "ty": 2,
      "x": 562,
      "y": 604
    },
    {
      "t": 1203,
      "e": 1203,
      "ty": 6,
      "x": 552,
      "y": 600,
      "ta": "#strategyAnswer"
    },
    {
      "t": 1249,
      "e": 1249,
      "ty": 41,
      "x": 47763,
      "y": 52804,
      "ta": "#strategyAnswer"
    },
    {
      "t": 1299,
      "e": 1299,
      "ty": 2,
      "x": 486,
      "y": 574
    },
    {
      "t": 1400,
      "e": 1400,
      "ty": 2,
      "x": 463,
      "y": 561
    },
    {
      "t": 1499,
      "e": 1499,
      "ty": 41,
      "x": 41131,
      "y": 30959,
      "ta": "#strategyAnswer"
    },
    {
      "t": 2514,
      "e": 2514,
      "ty": 3,
      "x": 463,
      "y": 561,
      "ta": "#strategyAnswer"
    },
    {
      "t": 2516,
      "e": 2516,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 2609,
      "e": 2609,
      "ty": 4,
      "x": 41131,
      "y": 30959,
      "ta": "#strategyAnswer"
    },
    {
      "t": 2609,
      "e": 2609,
      "ty": 5,
      "x": 463,
      "y": 561,
      "ta": "#strategyAnswer"
    },
    {
      "t": 2750,
      "e": 2750,
      "ty": 41,
      "x": 43716,
      "y": 5069,
      "ta": "#strategyAnswer"
    },
    {
      "t": 2754,
      "e": 2754,
      "ty": 7,
      "x": 515,
      "y": 492,
      "ta": "#strategyAnswer"
    },
    {
      "t": 2800,
      "e": 2800,
      "ty": 2,
      "x": 555,
      "y": 445
    },
    {
      "t": 2900,
      "e": 2900,
      "ty": 2,
      "x": 565,
      "y": 387
    },
    {
      "t": 3000,
      "e": 3000,
      "ty": 2,
      "x": 565,
      "y": 386
    },
    {
      "t": 3001,
      "e": 3001,
      "ty": 41,
      "x": 52597,
      "y": 20940,
      "ta": "> div.stimulus > div"
    },
    {
      "t": 3200,
      "e": 3200,
      "ty": 2,
      "x": 575,
      "y": 379
    },
    {
      "t": 3250,
      "e": 3250,
      "ty": 41,
      "x": 57206,
      "y": 19666,
      "ta": "> div.stimulus > div"
    },
    {
      "t": 3300,
      "e": 3300,
      "ty": 2,
      "x": 660,
      "y": 338
    },
    {
      "t": 3399,
      "e": 3399,
      "ty": 2,
      "x": 662,
      "y": 338
    },
    {
      "t": 3500,
      "e": 3500,
      "ty": 41,
      "x": 63501,
      "y": 18281,
      "ta": "> div.stimulus > div"
    },
    {
      "t": 3600,
      "e": 3600,
      "ty": 2,
      "x": 663,
      "y": 337
    },
    {
      "t": 3750,
      "e": 3750,
      "ty": 41,
      "x": 63613,
      "y": 18225,
      "ta": "> div.stimulus > div"
    },
    {
      "t": 7792,
      "e": 7792,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "16"
    },
    {
      "t": 8291,
      "e": 8291,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "16"
    },
    {
      "t": 8325,
      "e": 8325,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "16"
    },
    {
      "t": 8357,
      "e": 8357,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "16"
    },
    {
      "t": 8391,
      "e": 8391,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "16"
    },
    {
      "t": 8423,
      "e": 8423,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "16"
    },
    {
      "t": 8456,
      "e": 8456,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "16"
    },
    {
      "t": 8489,
      "e": 8489,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "16"
    },
    {
      "t": 8522,
      "e": 8522,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "16"
    },
    {
      "t": 8555,
      "e": 8555,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "16"
    },
    {
      "t": 8588,
      "e": 8588,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "16"
    },
    {
      "t": 8621,
      "e": 8621,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "16"
    },
    {
      "t": 8654,
      "e": 8654,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "16"
    },
    {
      "t": 8687,
      "e": 8687,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "16"
    },
    {
      "t": 8712,
      "e": 8712,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 8713,
      "e": 8713,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 8807,
      "e": 8807,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "T"
    },
    {
      "t": 8944,
      "e": 8944,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "T"
    },
    {
      "t": 9616,
      "e": 9616,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 9711,
      "e": 9711,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": ""
    },
    {
      "t": 10001,
      "e": 10001,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 10464,
      "e": 10464,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "16"
    },
    {
      "t": 10963,
      "e": 10963,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "16"
    },
    {
      "t": 10996,
      "e": 10996,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "16"
    },
    {
      "t": 11029,
      "e": 11029,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "16"
    },
    {
      "t": 11056,
      "e": 11056,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 11057,
      "e": 11057,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 11199,
      "e": 11199,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "72"
    },
    {
      "t": 11199,
      "e": 11199,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 11223,
      "e": 11223,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "TH"
    },
    {
      "t": 11231,
      "e": 11231,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "TH"
    },
    {
      "t": 11328,
      "e": 11328,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "TH"
    },
    {
      "t": 15423,
      "e": 15423,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 15535,
      "e": 15535,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "T"
    },
    {
      "t": 15912,
      "e": 15912,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "72"
    },
    {
      "t": 15912,
      "e": 15912,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 16048,
      "e": 16048,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Th"
    },
    {
      "t": 16056,
      "e": 16056,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 16056,
      "e": 16056,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 16135,
      "e": 16135,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 16135,
      "e": 16135,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 16151,
      "e": 16151,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "The "
    },
    {
      "t": 16215,
      "e": 16215,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 16263,
      "e": 16263,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "186"
    },
    {
      "t": 16263,
      "e": 16263,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 16327,
      "e": 16327,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "76"
    },
    {
      "t": 16327,
      "e": 16327,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 16375,
      "e": 16375,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||;l"
    },
    {
      "t": 16383,
      "e": 16383,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 17487,
      "e": 17487,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 17591,
      "e": 17591,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "The ;"
    },
    {
      "t": 17655,
      "e": 17655,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 17735,
      "e": 17735,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "The "
    },
    {
      "t": 18104,
      "e": 18104,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "76"
    },
    {
      "t": 18104,
      "e": 18104,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 18199,
      "e": 18199,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||l"
    },
    {
      "t": 18312,
      "e": 18312,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "73"
    },
    {
      "t": 18312,
      "e": 18312,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 18416,
      "e": 18416,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "78"
    },
    {
      "t": 18416,
      "e": 18416,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 18471,
      "e": 18471,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||in"
    },
    {
      "t": 18511,
      "e": 18511,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 18512,
      "e": 18512,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 18519,
      "e": 18519,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||e"
    },
    {
      "t": 18647,
      "e": 18647,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 18655,
      "e": 18655,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 18656,
      "e": 18656,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 18760,
      "e": 18760,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 19167,
      "e": 19167,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "76"
    },
    {
      "t": 19169,
      "e": 19169,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 19255,
      "e": 19255,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 19255,
      "e": 19255,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 19278,
      "e": 19278,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||le"
    },
    {
      "t": 19367,
      "e": 19367,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "70"
    },
    {
      "t": 19367,
      "e": 19367,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 19432,
      "e": 19432,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||f"
    },
    {
      "t": 19503,
      "e": 19503,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 19608,
      "e": 19608,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 19609,
      "e": 19609,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 19711,
      "e": 19711,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 19719,
      "e": 19719,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 19719,
      "e": 19719,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 19807,
      "e": 19807,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 20001,
      "e": 20001,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 20688,
      "e": 20688,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "79"
    },
    {
      "t": 20689,
      "e": 20689,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 20743,
      "e": 20743,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "70"
    },
    {
      "t": 20743,
      "e": 20743,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 20775,
      "e": 20775,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||of"
    },
    {
      "t": 20831,
      "e": 20831,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 20831,
      "e": 20831,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 20863,
      "e": 20863,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 20903,
      "e": 20903,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 20951,
      "e": 20951,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 20952,
      "e": 20952,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 21040,
      "e": 21040,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "72"
    },
    {
      "t": 21040,
      "e": 21040,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 21056,
      "e": 21056,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||th"
    },
    {
      "t": 21152,
      "e": 21152,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 21153,
      "e": 21153,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 21154,
      "e": 21154,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 21263,
      "e": 21263,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||e"
    },
    {
      "t": 21271,
      "e": 21271,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 21272,
      "e": 21272,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 21367,
      "e": 21367,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 26335,
      "e": 26335,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "80"
    },
    {
      "t": 26335,
      "e": 26335,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 26431,
      "e": 26431,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||p"
    },
    {
      "t": 26536,
      "e": 26536,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "79"
    },
    {
      "t": 26537,
      "e": 26537,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 26647,
      "e": 26647,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||o"
    },
    {
      "t": 26744,
      "e": 26744,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "73"
    },
    {
      "t": 26744,
      "e": 26744,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 26839,
      "e": 26839,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "78"
    },
    {
      "t": 26839,
      "e": 26839,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 26895,
      "e": 26895,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||in"
    },
    {
      "t": 26951,
      "e": 26951,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 26967,
      "e": 26967,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 26967,
      "e": 26967,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 27056,
      "e": 27056,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 27064,
      "e": 27064,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 27064,
      "e": 27064,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 27175,
      "e": 27175,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 27503,
      "e": 27503,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "73"
    },
    {
      "t": 27504,
      "e": 27504,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 27616,
      "e": 27616,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||i"
    },
    {
      "t": 27616,
      "e": 27616,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "83"
    },
    {
      "t": 27617,
      "e": 27617,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 27710,
      "e": 27710,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 27711,
      "e": 27711,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 27727,
      "e": 27727,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||s "
    },
    {
      "t": 27791,
      "e": 27791,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 27895,
      "e": 27895,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "87"
    },
    {
      "t": 27896,
      "e": 27896,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 28002,
      "e": 28002,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "The line left of the point is w"
    },
    {
      "t": 28007,
      "e": 28007,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||w"
    },
    {
      "t": 28023,
      "e": 28023,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "72"
    },
    {
      "t": 28023,
      "e": 28023,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 28111,
      "e": 28111,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||h"
    },
    {
      "t": 28119,
      "e": 28119,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 28120,
      "e": 28120,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 28239,
      "e": 28239,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "82"
    },
    {
      "t": 28239,
      "e": 28239,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 28247,
      "e": 28247,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||er"
    },
    {
      "t": 28360,
      "e": 28360,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 28360,
      "e": 28360,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 28391,
      "e": 28391,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||e"
    },
    {
      "t": 28487,
      "e": 28487,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 28615,
      "e": 28615,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 28703,
      "e": 28703,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "The line left of the point is wher"
    },
    {
      "t": 28784,
      "e": 28784,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 28855,
      "e": 28855,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "The line left of the point is whe"
    },
    {
      "t": 29224,
      "e": 29224,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "78"
    },
    {
      "t": 29224,
      "e": 29224,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 29334,
      "e": 29334,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||n"
    },
    {
      "t": 29335,
      "e": 29335,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 29336,
      "e": 29336,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 29447,
      "e": 29447,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "73"
    },
    {
      "t": 29448,
      "e": 29448,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 29455,
      "e": 29455,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| i"
    },
    {
      "t": 29543,
      "e": 29543,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 29640,
      "e": 29640,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 29640,
      "e": 29640,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 29727,
      "e": 29727,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 29728,
      "e": 29728,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 29735,
      "e": 29735,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t "
    },
    {
      "t": 29791,
      "e": 29791,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 29912,
      "e": 29912,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "83"
    },
    {
      "t": 29912,
      "e": 29912,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 29999,
      "e": 29999,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 30015,
      "e": 30015,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||s"
    },
    {
      "t": 30063,
      "e": 30063,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 30063,
      "e": 30063,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 30167,
      "e": 30167,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 30169,
      "e": 30169,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 30169,
      "e": 30169,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 30278,
      "e": 30278,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "82"
    },
    {
      "t": 30279,
      "e": 30279,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 30367,
      "e": 30367,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||ar"
    },
    {
      "t": 30392,
      "e": 30392,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 30463,
      "e": 30463,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 30463,
      "e": 30463,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 30567,
      "e": 30567,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 30623,
      "e": 30623,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "83"
    },
    {
      "t": 30624,
      "e": 30624,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 30727,
      "e": 30727,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "13"
    },
    {
      "t": 30729,
      "e": 30729,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 30734,
      "e": 30734,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||s\n"
    },
    {
      "t": 30814,
      "e": 30814,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 31600,
      "e": 31600,
      "ty": 2,
      "x": 650,
      "y": 383
    },
    {
      "t": 31700,
      "e": 31700,
      "ty": 2,
      "x": 418,
      "y": 357
    },
    {
      "t": 31750,
      "e": 31750,
      "ty": 41,
      "x": 37646,
      "y": 22823,
      "ta": "> div.stimulus > div"
    },
    {
      "t": 31799,
      "e": 31799,
      "ty": 2,
      "x": 409,
      "y": 690
    },
    {
      "t": 31900,
      "e": 31900,
      "ty": 2,
      "x": 442,
      "y": 787
    },
    {
      "t": 32000,
      "e": 32000,
      "ty": 2,
      "x": 424,
      "y": 739
    },
    {
      "t": 32001,
      "e": 32001,
      "ty": 41,
      "x": 36747,
      "y": 40495,
      "ta": "> div.stimulus > div"
    },
    {
      "t": 32100,
      "e": 32100,
      "ty": 2,
      "x": 416,
      "y": 719
    },
    {
      "t": 32195,
      "e": 32195,
      "ty": 6,
      "x": 400,
      "y": 676,
      "ta": "#strategyButton"
    },
    {
      "t": 32200,
      "e": 32200,
      "ty": 2,
      "x": 400,
      "y": 676
    },
    {
      "t": 32228,
      "e": 32228,
      "ty": 7,
      "x": 389,
      "y": 647,
      "ta": "#strategyButton"
    },
    {
      "t": 32250,
      "e": 32250,
      "ty": 41,
      "x": 32957,
      "y": 16557,
      "ta": "> div.stimulus > div > div:[3]"
    },
    {
      "t": 32300,
      "e": 32300,
      "ty": 2,
      "x": 388,
      "y": 646
    },
    {
      "t": 32370,
      "e": 32370,
      "ty": 3,
      "x": 388,
      "y": 646,
      "ta": "> div.stimulus > div > div:[3]"
    },
    {
      "t": 32370,
      "e": 32370,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "The line left of the point is when it starts\n"
    },
    {
      "t": 32371,
      "e": 32371,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 32401,
      "e": 32401,
      "ty": 4,
      "x": 32489,
      "y": 15902,
      "ta": "> div.stimulus > div > div:[3]"
    },
    {
      "t": 32402,
      "e": 32402,
      "ty": 5,
      "x": 388,
      "y": 646,
      "ta": "> div.stimulus > div > div:[3]"
    },
    {
      "t": 32428,
      "e": 32428,
      "ty": 6,
      "x": 372,
      "y": 657,
      "ta": "#strategyButton"
    },
    {
      "t": 32500,
      "e": 32500,
      "ty": 2,
      "x": 364,
      "y": 671
    },
    {
      "t": 32500,
      "e": 32500,
      "ty": 41,
      "x": 13874,
      "y": 31351,
      "ta": "#strategyButton"
    },
    {
      "t": 32600,
      "e": 32600,
      "ty": 2,
      "x": 364,
      "y": 672
    },
    {
      "t": 32618,
      "e": 32618,
      "ty": 3,
      "x": 364,
      "y": 672,
      "ta": "#strategyButton"
    },
    {
      "t": 32619,
      "e": 32619,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#strategyButton"
    },
    {
      "t": 32690,
      "e": 32690,
      "ty": 4,
      "x": 13874,
      "y": 33279,
      "ta": "#strategyButton"
    },
    {
      "t": 32703,
      "e": 32703,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#strategyButton"
    },
    {
      "t": 32704,
      "e": 32704,
      "ty": 5,
      "x": 364,
      "y": 672,
      "ta": "#strategyButton"
    },
    {
      "t": 32709,
      "e": 32709,
      "ty": 38,
      "x": 1,
      "y": 0
    },
    {
      "t": 32750,
      "e": 32750,
      "ty": 41,
      "x": 12259,
      "y": 36783,
      "ta": "html > body"
    },
    {
      "t": 32800,
      "e": 32800,
      "ty": 2,
      "x": 387,
      "y": 673
    },
    {
      "t": 32900,
      "e": 32900,
      "ty": 2,
      "x": 1257,
      "y": 618
    },
    {
      "t": 33000,
      "e": 33000,
      "ty": 2,
      "x": 1257,
      "y": 606
    },
    {
      "t": 33000,
      "e": 33000,
      "ty": 41,
      "x": 43012,
      "y": 33127,
      "ta": "html > body"
    },
    {
      "t": 33100,
      "e": 33100,
      "ty": 2,
      "x": 1236,
      "y": 594
    },
    {
      "t": 33200,
      "e": 33200,
      "ty": 2,
      "x": 1230,
      "y": 590
    },
    {
      "t": 33250,
      "e": 33250,
      "ty": 41,
      "x": 42082,
      "y": 32241,
      "ta": "html > body"
    },
    {
      "t": 33700,
      "e": 33700,
      "ty": 2,
      "x": 1229,
      "y": 589
    },
    {
      "t": 33711,
      "e": 33711,
      "ty": 38,
      "x": 2,
      "y": 0
    },
    {
      "t": 33750,
      "e": 33750,
      "ty": 41,
      "x": 42048,
      "y": 32185,
      "ta": "html > body"
    },
    {
      "t": 34079,
      "e": 34079,
      "ty": 6,
      "x": 1104,
      "y": 569,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 34099,
      "e": 34099,
      "ty": 2,
      "x": 1056,
      "y": 554
    },
    {
      "t": 34113,
      "e": 34113,
      "ty": 7,
      "x": 1003,
      "y": 539,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 34200,
      "e": 34200,
      "ty": 2,
      "x": 834,
      "y": 503
    },
    {
      "t": 34250,
      "e": 34250,
      "ty": 41,
      "x": 5623,
      "y": 9160,
      "ta": "#jspsych-survey-text-0"
    },
    {
      "t": 34300,
      "e": 34300,
      "ty": 2,
      "x": 825,
      "y": 509
    },
    {
      "t": 34400,
      "e": 34400,
      "ty": 2,
      "x": 838,
      "y": 544
    },
    {
      "t": 34500,
      "e": 34500,
      "ty": 2,
      "x": 843,
      "y": 550
    },
    {
      "t": 34501,
      "e": 34501,
      "ty": 41,
      "x": 7570,
      "y": 42280,
      "ta": "#jspsych-survey-text-0"
    },
    {
      "t": 34530,
      "e": 34530,
      "ty": 6,
      "x": 847,
      "y": 554,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 34600,
      "e": 34600,
      "ty": 2,
      "x": 848,
      "y": 555
    },
    {
      "t": 34705,
      "e": 34705,
      "ty": 3,
      "x": 848,
      "y": 555,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 34706,
      "e": 34706,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 34751,
      "e": 34751,
      "ty": 41,
      "x": 8651,
      "y": 3120,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 34809,
      "e": 34809,
      "ty": 4,
      "x": 8651,
      "y": 3120,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 34810,
      "e": 34810,
      "ty": 5,
      "x": 848,
      "y": 555,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 35296,
      "e": 35296,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "50"
    },
    {
      "t": 35296,
      "e": 35296,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 35399,
      "e": 35399,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "2"
    },
    {
      "t": 35413,
      "e": 35413,
      "ty": 7,
      "x": 859,
      "y": 577,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 35479,
      "e": 35479,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "50"
    },
    {
      "t": 35480,
      "e": 35480,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 35481,
      "e": 35481,
      "ty": 6,
      "x": 918,
      "y": 647,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 35500,
      "e": 35500,
      "ty": 2,
      "x": 919,
      "y": 648
    },
    {
      "t": 35501,
      "e": 35501,
      "ty": 41,
      "x": 24007,
      "y": 3120,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 35583,
      "e": 35583,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "22"
    },
    {
      "t": 35630,
      "e": 35630,
      "ty": 7,
      "x": 912,
      "y": 646,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 35700,
      "e": 35700,
      "ty": 2,
      "x": 911,
      "y": 645
    },
    {
      "t": 35750,
      "e": 35750,
      "ty": 41,
      "x": 22277,
      "y": 43690,
      "ta": "#jspsych-survey-text-1"
    },
    {
      "t": 35842,
      "e": 35842,
      "ty": 3,
      "x": 911,
      "y": 645,
      "ta": "#jspsych-survey-text-1"
    },
    {
      "t": 35843,
      "e": 35843,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "22"
    },
    {
      "t": 35843,
      "e": 35843,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 35913,
      "e": 35913,
      "ty": 4,
      "x": 22277,
      "y": 43690,
      "ta": "#jspsych-survey-text-1"
    },
    {
      "t": 35913,
      "e": 35913,
      "ty": 5,
      "x": 911,
      "y": 645,
      "ta": "#jspsych-survey-text-1"
    },
    {
      "t": 36201,
      "e": 36201,
      "ty": 2,
      "x": 905,
      "y": 645
    },
    {
      "t": 36251,
      "e": 36251,
      "ty": 41,
      "x": 20547,
      "y": 44394,
      "ta": "#jspsych-survey-text-1"
    },
    {
      "t": 36300,
      "e": 36300,
      "ty": 2,
      "x": 903,
      "y": 646
    },
    {
      "t": 36338,
      "e": 36338,
      "ty": 3,
      "x": 903,
      "y": 646,
      "ta": "#jspsych-survey-text-1"
    },
    {
      "t": 36442,
      "e": 36442,
      "ty": 4,
      "x": 20547,
      "y": 44394,
      "ta": "#jspsych-survey-text-1"
    },
    {
      "t": 36442,
      "e": 36442,
      "ty": 5,
      "x": 903,
      "y": 646,
      "ta": "#jspsych-survey-text-1"
    },
    {
      "t": 36498,
      "e": 36498,
      "ty": 6,
      "x": 903,
      "y": 647,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 36500,
      "e": 36500,
      "ty": 2,
      "x": 903,
      "y": 647
    },
    {
      "t": 36500,
      "e": 36500,
      "ty": 41,
      "x": 20547,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 36600,
      "e": 36600,
      "ty": 2,
      "x": 903,
      "y": 650
    },
    {
      "t": 36666,
      "e": 36666,
      "ty": 3,
      "x": 902,
      "y": 650,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 36667,
      "e": 36667,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 36700,
      "e": 36700,
      "ty": 2,
      "x": 902,
      "y": 650
    },
    {
      "t": 36750,
      "e": 36750,
      "ty": 41,
      "x": 20330,
      "y": 9362,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 36761,
      "e": 36761,
      "ty": 4,
      "x": 20330,
      "y": 9362,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 36761,
      "e": 36761,
      "ty": 5,
      "x": 902,
      "y": 650,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 37199,
      "e": 37199,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "16"
    },
    {
      "t": 37463,
      "e": 37463,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "85"
    },
    {
      "t": 37464,
      "e": 37464,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 37560,
      "e": 37560,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "U"
    },
    {
      "t": 37560,
      "e": 37560,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "U"
    },
    {
      "t": 37728,
      "e": 37728,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "188"
    },
    {
      "t": 37728,
      "e": 37728,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 37823,
      "e": 37823,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "U,"
    },
    {
      "t": 37855,
      "e": 37855,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "16"
    },
    {
      "t": 38039,
      "e": 38039,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "U,"
    },
    {
      "t": 38095,
      "e": 38095,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "8"
    },
    {
      "t": 38176,
      "e": 38176,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "U"
    },
    {
      "t": 38344,
      "e": 38344,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "190"
    },
    {
      "t": 38344,
      "e": 38344,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 38383,
      "e": 38345,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "U."
    },
    {
      "t": 38655,
      "e": 38617,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "16"
    },
    {
      "t": 38760,
      "e": 38722,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "83"
    },
    {
      "t": 38760,
      "e": 38722,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 38879,
      "e": 38841,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "U.S"
    },
    {
      "t": 38903,
      "e": 38865,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "U.S"
    },
    {
      "t": 39700,
      "e": 39662,
      "ty": 2,
      "x": 965,
      "y": 650
    },
    {
      "t": 39750,
      "e": 39712,
      "ty": 41,
      "x": 33957,
      "y": 15603,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 39784,
      "e": 39746,
      "ty": 7,
      "x": 978,
      "y": 676,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 39785,
      "e": 39747,
      "ty": 6,
      "x": 978,
      "y": 676,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 39800,
      "e": 39762,
      "ty": 2,
      "x": 980,
      "y": 679
    },
    {
      "t": 39900,
      "e": 39862,
      "ty": 2,
      "x": 974,
      "y": 693
    },
    {
      "t": 40001,
      "e": 39963,
      "ty": 2,
      "x": 969,
      "y": 695
    },
    {
      "t": 40001,
      "e": 39963,
      "ty": 41,
      "x": 37663,
      "y": 37732,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 40074,
      "e": 40036,
      "ty": 3,
      "x": 969,
      "y": 695,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 40075,
      "e": 40037,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "U.S"
    },
    {
      "t": 40076,
      "e": 40038,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 40076,
      "e": 40038,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 40137,
      "e": 40099,
      "ty": 4,
      "x": 37663,
      "y": 37732,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 40138,
      "e": 40100,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 40138,
      "e": 40100,
      "ty": 5,
      "x": 969,
      "y": 695,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 40138,
      "e": 40100,
      "ty": 38,
      "x": 3,
      "y": 0
    },
    {
      "t": 40250,
      "e": 40212,
      "ty": 41,
      "x": 33439,
      "y": 36783,
      "ta": "html > body"
    },
    {
      "t": 40300,
      "e": 40262,
      "ty": 2,
      "x": 981,
      "y": 592
    },
    {
      "t": 40401,
      "e": 40363,
      "ty": 2,
      "x": 864,
      "y": 471
    },
    {
      "t": 40501,
      "e": 40463,
      "ty": 2,
      "x": 830,
      "y": 460
    },
    {
      "t": 40501,
      "e": 40463,
      "ty": 41,
      "x": 28307,
      "y": 25039,
      "ta": "html > body"
    },
    {
      "t": 40601,
      "e": 40563,
      "ty": 2,
      "x": 808,
      "y": 464
    },
    {
      "t": 40750,
      "e": 40712,
      "ty": 41,
      "x": 27550,
      "y": 25261,
      "ta": "html > body"
    },
    {
      "t": 41162,
      "e": 41124,
      "ty": 38,
      "x": 4,
      "y": 0
    },
    {
      "t": 41700,
      "e": 41662,
      "ty": 2,
      "x": 894,
      "y": 702
    },
    {
      "t": 41750,
      "e": 41712,
      "ty": 41,
      "x": 19835,
      "y": 2340,
      "ta": "#jspsych-survey-multi-choice-option-2-2"
    },
    {
      "t": 41801,
      "e": 41763,
      "ty": 2,
      "x": 974,
      "y": 655
    },
    {
      "t": 41900,
      "e": 41862,
      "ty": 2,
      "x": 1022,
      "y": 436
    },
    {
      "t": 42001,
      "e": 41963,
      "ty": 2,
      "x": 877,
      "y": 389
    },
    {
      "t": 42001,
      "e": 41963,
      "ty": 41,
      "x": 13190,
      "y": 9207,
      "ta": "#jspsych-survey-multi-choice-1"
    },
    {
      "t": 42101,
      "e": 42063,
      "ty": 2,
      "x": 852,
      "y": 392
    },
    {
      "t": 42251,
      "e": 42213,
      "ty": 41,
      "x": 6782,
      "y": 10290,
      "ta": "#jspsych-survey-multi-choice-1"
    },
    {
      "t": 42300,
      "e": 42262,
      "ty": 2,
      "x": 837,
      "y": 332
    },
    {
      "t": 42336,
      "e": 42298,
      "ty": 6,
      "x": 827,
      "y": 298,
      "ta": "jspsych-survey-multi-choice-response-0[2]_mf"
    },
    {
      "t": 42353,
      "e": 42315,
      "ty": 7,
      "x": 825,
      "y": 290,
      "ta": "jspsych-survey-multi-choice-response-0[2]_mf"
    },
    {
      "t": 42400,
      "e": 42362,
      "ty": 2,
      "x": 818,
      "y": 278
    },
    {
      "t": 42500,
      "e": 42462,
      "ty": 2,
      "x": 812,
      "y": 253
    },
    {
      "t": 42500,
      "e": 42462,
      "ty": 41,
      "x": 27687,
      "y": 13572,
      "ta": "html > body"
    },
    {
      "t": 42600,
      "e": 42562,
      "ty": 2,
      "x": 824,
      "y": 232
    },
    {
      "t": 42636,
      "e": 42598,
      "ty": 6,
      "x": 826,
      "y": 232,
      "ta": "jspsych-survey-multi-choice-response-0[0]_mf"
    },
    {
      "t": 42653,
      "e": 42615,
      "ty": 7,
      "x": 827,
      "y": 231,
      "ta": "jspsych-survey-multi-choice-response-0[0]_mf"
    },
    {
      "t": 42700,
      "e": 42662,
      "ty": 2,
      "x": 828,
      "y": 231
    },
    {
      "t": 42751,
      "e": 42713,
      "ty": 41,
      "x": 6205,
      "y": 6553,
      "ta": "#jspsych-survey-multi-choice-option-0-0 > label"
    },
    {
      "t": 42801,
      "e": 42763,
      "ty": 2,
      "x": 829,
      "y": 231
    },
    {
      "t": 42802,
      "e": 42764,
      "ty": 6,
      "x": 829,
      "y": 232,
      "ta": "jspsych-survey-multi-choice-response-0[0]_mf"
    },
    {
      "t": 42901,
      "e": 42863,
      "ty": 2,
      "x": 830,
      "y": 234
    },
    {
      "t": 43001,
      "e": 42963,
      "ty": 41,
      "x": 18037,
      "y": 10082,
      "ta": "jspsych-survey-multi-choice-response-0[0]_mf"
    },
    {
      "t": 43065,
      "e": 43027,
      "ty": 3,
      "x": 830,
      "y": 234,
      "ta": "jspsych-survey-multi-choice-response-0[0]_mf"
    },
    {
      "t": 43067,
      "e": 43029,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-0[0]_mf"
    },
    {
      "t": 43137,
      "e": 43099,
      "ty": 4,
      "x": 18037,
      "y": 10082,
      "ta": "jspsych-survey-multi-choice-response-0[0]_mf"
    },
    {
      "t": 43138,
      "e": 43100,
      "ty": 5,
      "x": 830,
      "y": 234,
      "ta": "jspsych-survey-multi-choice-response-0[0]_mf"
    },
    {
      "t": 43138,
      "e": 43100,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-0[0]_mf",
      "v": "English"
    },
    {
      "t": 43249,
      "e": 43211,
      "ty": 41,
      "x": 18037,
      "y": 25205,
      "ta": "jspsych-survey-multi-choice-response-0[0]_mf"
    },
    {
      "t": 43258,
      "e": 43220,
      "ty": 7,
      "x": 835,
      "y": 245,
      "ta": "jspsych-survey-multi-choice-response-0[0]_mf"
    },
    {
      "t": 43300,
      "e": 43262,
      "ty": 2,
      "x": 858,
      "y": 276
    },
    {
      "t": 43400,
      "e": 43362,
      "ty": 2,
      "x": 881,
      "y": 318
    },
    {
      "t": 43500,
      "e": 43462,
      "ty": 2,
      "x": 888,
      "y": 363
    },
    {
      "t": 43501,
      "e": 43463,
      "ty": 41,
      "x": 15800,
      "y": 18724,
      "ta": "#jspsych-survey-multi-choice-1 > p"
    },
    {
      "t": 43601,
      "e": 43563,
      "ty": 2,
      "x": 854,
      "y": 388
    },
    {
      "t": 43701,
      "e": 43663,
      "ty": 2,
      "x": 840,
      "y": 402
    },
    {
      "t": 43705,
      "e": 43667,
      "ty": 6,
      "x": 839,
      "y": 408,
      "ta": "jspsych-survey-multi-choice-response-1[0]_mf"
    },
    {
      "t": 43751,
      "e": 43713,
      "ty": 41,
      "x": 53325,
      "y": 25205,
      "ta": "jspsych-survey-multi-choice-response-1[0]_mf"
    },
    {
      "t": 43801,
      "e": 43763,
      "ty": 2,
      "x": 837,
      "y": 416
    },
    {
      "t": 43837,
      "e": 43799,
      "ty": 7,
      "x": 840,
      "y": 420,
      "ta": "jspsych-survey-multi-choice-response-1[0]_mf"
    },
    {
      "t": 43900,
      "e": 43862,
      "ty": 2,
      "x": 841,
      "y": 431
    },
    {
      "t": 44000,
      "e": 43962,
      "ty": 2,
      "x": 846,
      "y": 471
    },
    {
      "t": 44002,
      "e": 43964,
      "ty": 41,
      "x": 25979,
      "y": 32767,
      "ta": "#jspsych-survey-multi-choice-option-1-2 > label"
    },
    {
      "t": 44100,
      "e": 44062,
      "ty": 2,
      "x": 846,
      "y": 492
    },
    {
      "t": 44200,
      "e": 44162,
      "ty": 2,
      "x": 845,
      "y": 509
    },
    {
      "t": 44249,
      "e": 44211,
      "ty": 41,
      "x": 5358,
      "y": 0,
      "ta": "#jspsych-survey-multi-choice-option-1-4"
    },
    {
      "t": 44300,
      "e": 44262,
      "ty": 2,
      "x": 842,
      "y": 517
    },
    {
      "t": 44354,
      "e": 44316,
      "ty": 6,
      "x": 839,
      "y": 520,
      "ta": "jspsych-survey-multi-choice-response-1[4]_mf"
    },
    {
      "t": 44399,
      "e": 44361,
      "ty": 2,
      "x": 838,
      "y": 520
    },
    {
      "t": 44499,
      "e": 44461,
      "ty": 2,
      "x": 830,
      "y": 522
    },
    {
      "t": 44500,
      "e": 44462,
      "ty": 41,
      "x": 18037,
      "y": 10082,
      "ta": "jspsych-survey-multi-choice-response-1[4]_mf"
    },
    {
      "t": 44521,
      "e": 44483,
      "ty": 7,
      "x": 828,
      "y": 517,
      "ta": "jspsych-survey-multi-choice-response-1[4]_mf"
    },
    {
      "t": 44588,
      "e": 44550,
      "ty": 6,
      "x": 827,
      "y": 503,
      "ta": "jspsych-survey-multi-choice-response-1[3]_mf"
    },
    {
      "t": 44600,
      "e": 44562,
      "ty": 2,
      "x": 827,
      "y": 503
    },
    {
      "t": 44699,
      "e": 44661,
      "ty": 2,
      "x": 827,
      "y": 501
    },
    {
      "t": 44750,
      "e": 44712,
      "ty": 41,
      "x": 2914,
      "y": 45370,
      "ta": "jspsych-survey-multi-choice-response-1[3]_mf"
    },
    {
      "t": 44770,
      "e": 44732,
      "ty": 3,
      "x": 827,
      "y": 501,
      "ta": "jspsych-survey-multi-choice-response-1[3]_mf"
    },
    {
      "t": 44771,
      "e": 44733,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-0[0]_mf"
    },
    {
      "t": 44771,
      "e": 44733,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-1[3]_mf"
    },
    {
      "t": 44849,
      "e": 44811,
      "ty": 4,
      "x": 2914,
      "y": 45370,
      "ta": "jspsych-survey-multi-choice-response-1[3]_mf"
    },
    {
      "t": 44850,
      "e": 44812,
      "ty": 5,
      "x": 827,
      "y": 501,
      "ta": "jspsych-survey-multi-choice-response-1[3]_mf"
    },
    {
      "t": 44851,
      "e": 44813,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-1[3]_mf",
      "v": "Fourth"
    },
    {
      "t": 44938,
      "e": 44900,
      "ty": 7,
      "x": 841,
      "y": 509,
      "ta": "jspsych-survey-multi-choice-response-1[3]_mf"
    },
    {
      "t": 45000,
      "e": 44962,
      "ty": 2,
      "x": 864,
      "y": 529
    },
    {
      "t": 45000,
      "e": 44962,
      "ty": 41,
      "x": 49827,
      "y": 39321,
      "ta": "#jspsych-survey-multi-choice-option-1-4 > label"
    },
    {
      "t": 45100,
      "e": 45062,
      "ty": 2,
      "x": 883,
      "y": 584
    },
    {
      "t": 45199,
      "e": 45161,
      "ty": 2,
      "x": 881,
      "y": 614
    },
    {
      "t": 45250,
      "e": 45212,
      "ty": 41,
      "x": 12715,
      "y": 23405,
      "ta": "#jspsych-survey-multi-choice-2 > p"
    },
    {
      "t": 45299,
      "e": 45261,
      "ty": 2,
      "x": 869,
      "y": 637
    },
    {
      "t": 45399,
      "e": 45361,
      "ty": 2,
      "x": 864,
      "y": 643
    },
    {
      "t": 45500,
      "e": 45462,
      "ty": 2,
      "x": 853,
      "y": 662
    },
    {
      "t": 45500,
      "e": 45462,
      "ty": 41,
      "x": 7494,
      "y": 2340,
      "ta": "#jspsych-survey-multi-choice-option-2-0"
    },
    {
      "t": 45600,
      "e": 45562,
      "ty": 2,
      "x": 852,
      "y": 667
    },
    {
      "t": 45700,
      "e": 45662,
      "ty": 2,
      "x": 852,
      "y": 690
    },
    {
      "t": 45750,
      "e": 45712,
      "ty": 41,
      "x": 7705,
      "y": 45874,
      "ta": "#jspsych-survey-multi-choice-option-2-1 > label"
    },
    {
      "t": 45800,
      "e": 45762,
      "ty": 2,
      "x": 850,
      "y": 716
    },
    {
      "t": 45900,
      "e": 45862,
      "ty": 2,
      "x": 841,
      "y": 727
    },
    {
      "t": 45923,
      "e": 45885,
      "ty": 6,
      "x": 838,
      "y": 731,
      "ta": "jspsych-survey-multi-choice-response-2[2]_mf"
    },
    {
      "t": 45989,
      "e": 45951,
      "ty": 7,
      "x": 832,
      "y": 737,
      "ta": "jspsych-survey-multi-choice-response-2[2]_mf"
    },
    {
      "t": 45999,
      "e": 45961,
      "ty": 2,
      "x": 832,
      "y": 737
    },
    {
      "t": 46000,
      "e": 45962,
      "ty": 41,
      "x": 2654,
      "y": 52428,
      "ta": "#jspsych-survey-multi-choice-option-2-2 > label"
    },
    {
      "t": 46100,
      "e": 46062,
      "ty": 2,
      "x": 832,
      "y": 741
    },
    {
      "t": 46200,
      "e": 46162,
      "ty": 2,
      "x": 830,
      "y": 741
    },
    {
      "t": 46250,
      "e": 46212,
      "ty": 41,
      "x": 1902,
      "y": 52428,
      "ta": "#jspsych-survey-multi-choice-option-2-2 > label"
    },
    {
      "t": 46299,
      "e": 46261,
      "ty": 2,
      "x": 828,
      "y": 737
    },
    {
      "t": 46378,
      "e": 46340,
      "ty": 6,
      "x": 828,
      "y": 736,
      "ta": "jspsych-survey-multi-choice-response-2[2]_mf"
    },
    {
      "t": 46399,
      "e": 46361,
      "ty": 2,
      "x": 828,
      "y": 736
    },
    {
      "t": 46500,
      "e": 46362,
      "ty": 2,
      "x": 828,
      "y": 735
    },
    {
      "t": 46502,
      "e": 46364,
      "ty": 41,
      "x": 7955,
      "y": 55452,
      "ta": "jspsych-survey-multi-choice-response-2[2]_mf"
    },
    {
      "t": 46800,
      "e": 46662,
      "ty": 2,
      "x": 828,
      "y": 734
    },
    {
      "t": 46881,
      "e": 46743,
      "ty": 3,
      "x": 828,
      "y": 734,
      "ta": "jspsych-survey-multi-choice-response-2[2]_mf"
    },
    {
      "t": 46882,
      "e": 46744,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-1[3]_mf"
    },
    {
      "t": 46884,
      "e": 46746,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-2[2]_mf"
    },
    {
      "t": 46945,
      "e": 46807,
      "ty": 4,
      "x": 7955,
      "y": 50411,
      "ta": "jspsych-survey-multi-choice-response-2[2]_mf"
    },
    {
      "t": 46945,
      "e": 46807,
      "ty": 5,
      "x": 828,
      "y": 734,
      "ta": "jspsych-survey-multi-choice-response-2[2]_mf"
    },
    {
      "t": 46945,
      "e": 46807,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-2[2]_mf",
      "v": "Biomedical & Health Sciences"
    },
    {
      "t": 46999,
      "e": 46861,
      "ty": 41,
      "x": 7955,
      "y": 50411,
      "ta": "jspsych-survey-multi-choice-response-2[2]_mf"
    },
    {
      "t": 47100,
      "e": 46962,
      "ty": 2,
      "x": 829,
      "y": 732
    },
    {
      "t": 47200,
      "e": 47062,
      "ty": 2,
      "x": 829,
      "y": 730
    },
    {
      "t": 47250,
      "e": 47112,
      "ty": 41,
      "x": 12996,
      "y": 30246,
      "ta": "jspsych-survey-multi-choice-response-2[2]_mf"
    },
    {
      "t": 47274,
      "e": 47136,
      "ty": 7,
      "x": 834,
      "y": 743,
      "ta": "jspsych-survey-multi-choice-response-2[2]_mf"
    },
    {
      "t": 47299,
      "e": 47161,
      "ty": 2,
      "x": 840,
      "y": 757
    },
    {
      "t": 47399,
      "e": 47261,
      "ty": 2,
      "x": 865,
      "y": 841
    },
    {
      "t": 47500,
      "e": 47362,
      "ty": 2,
      "x": 867,
      "y": 864
    },
    {
      "t": 47500,
      "e": 47362,
      "ty": 41,
      "x": 10816,
      "y": 52532,
      "ta": "#jspsych-survey-multi-choice-form"
    },
    {
      "t": 47600,
      "e": 47462,
      "ty": 2,
      "x": 860,
      "y": 877
    },
    {
      "t": 47700,
      "e": 47562,
      "ty": 2,
      "x": 851,
      "y": 893
    },
    {
      "t": 47750,
      "e": 47612,
      "ty": 41,
      "x": 6544,
      "y": 60853,
      "ta": "#jspsych-survey-multi-choice-3 > p"
    },
    {
      "t": 47799,
      "e": 47661,
      "ty": 2,
      "x": 847,
      "y": 913
    },
    {
      "t": 47900,
      "e": 47762,
      "ty": 2,
      "x": 846,
      "y": 923
    },
    {
      "t": 48000,
      "e": 47862,
      "ty": 2,
      "x": 842,
      "y": 925
    },
    {
      "t": 48000,
      "e": 47862,
      "ty": 41,
      "x": 22476,
      "y": 0,
      "ta": "#jspsych-survey-multi-choice-option-3-0 > label"
    },
    {
      "t": 48074,
      "e": 47936,
      "ty": 6,
      "x": 835,
      "y": 928,
      "ta": "jspsych-survey-multi-choice-response-3[0]_mf"
    },
    {
      "t": 48099,
      "e": 47961,
      "ty": 2,
      "x": 835,
      "y": 928
    },
    {
      "t": 48154,
      "e": 48016,
      "ty": 3,
      "x": 835,
      "y": 928,
      "ta": "jspsych-survey-multi-choice-response-3[0]_mf"
    },
    {
      "t": 48155,
      "e": 48017,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-2[2]_mf"
    },
    {
      "t": 48156,
      "e": 48018,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-3[0]_mf"
    },
    {
      "t": 48232,
      "e": 48094,
      "ty": 4,
      "x": 43243,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-3[0]_mf"
    },
    {
      "t": 48234,
      "e": 48096,
      "ty": 5,
      "x": 835,
      "y": 928,
      "ta": "jspsych-survey-multi-choice-response-3[0]_mf"
    },
    {
      "t": 48234,
      "e": 48096,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-3[0]_mf",
      "v": "Male"
    },
    {
      "t": 48250,
      "e": 48112,
      "ty": 41,
      "x": 43243,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-3[0]_mf"
    },
    {
      "t": 48299,
      "e": 48161,
      "ty": 2,
      "x": 836,
      "y": 932
    },
    {
      "t": 48307,
      "e": 48169,
      "ty": 7,
      "x": 840,
      "y": 941,
      "ta": "jspsych-survey-multi-choice-response-3[0]_mf"
    },
    {
      "t": 48400,
      "e": 48262,
      "ty": 2,
      "x": 846,
      "y": 975
    },
    {
      "t": 48503,
      "e": 48365,
      "ty": 2,
      "x": 866,
      "y": 995
    },
    {
      "t": 48504,
      "e": 48366,
      "ty": 41,
      "x": 44253,
      "y": 45874,
      "ta": "#jspsych-survey-multi-choice-option-3-2 > label"
    },
    {
      "t": 48595,
      "e": 48457,
      "ty": 6,
      "x": 871,
      "y": 1006,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 48603,
      "e": 48465,
      "ty": 2,
      "x": 871,
      "y": 1006
    },
    {
      "t": 48703,
      "e": 48565,
      "ty": 2,
      "x": 871,
      "y": 1019
    },
    {
      "t": 48717,
      "e": 48579,
      "ty": 3,
      "x": 871,
      "y": 1019,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 48719,
      "e": 48581,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-3[0]_mf"
    },
    {
      "t": 48719,
      "e": 48581,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 48754,
      "e": 48616,
      "ty": 41,
      "x": 21428,
      "y": 27802,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 48789,
      "e": 48651,
      "ty": 4,
      "x": 21428,
      "y": 27802,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 48789,
      "e": 48651,
      "ty": 5,
      "x": 871,
      "y": 1019,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 48795,
      "e": 48657,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 48796,
      "e": 48658,
      "ty": 13,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-multi-choice-form"
    },
    {
      "t": 48796,
      "e": 48658,
      "ty": 38,
      "x": 5,
      "y": 0
    },
    {
      "t": 48903,
      "e": 48765,
      "ty": 2,
      "x": 913,
      "y": 781
    },
    {
      "t": 49003,
      "e": 48865,
      "ty": 2,
      "x": 728,
      "y": 402
    },
    {
      "t": 49003,
      "e": 48865,
      "ty": 41,
      "x": 24795,
      "y": 21826,
      "ta": "html > body"
    },
    {
      "t": 49103,
      "e": 48965,
      "ty": 2,
      "x": 676,
      "y": 342
    },
    {
      "t": 49203,
      "e": 49065,
      "ty": 2,
      "x": 671,
      "y": 342
    },
    {
      "t": 49254,
      "e": 49116,
      "ty": 41,
      "x": 22763,
      "y": 18502,
      "ta": "html > body"
    },
    {
      "t": 49303,
      "e": 49165,
      "ty": 2,
      "x": 669,
      "y": 342
    },
    {
      "t": 49890,
      "e": 49752,
      "ty": 38,
      "x": 6,
      "y": 0
    },
    {
      "t": 50307,
      "e": 50169,
      "ty": 2,
      "x": 728,
      "y": 355
    },
    {
      "t": 50403,
      "e": 50265,
      "ty": 2,
      "x": 813,
      "y": 621
    },
    {
      "t": 50503,
      "e": 50365,
      "ty": 2,
      "x": 849,
      "y": 794
    },
    {
      "t": 50503,
      "e": 50365,
      "ty": 41,
      "x": 27331,
      "y": 53205,
      "ta": "> div.masterdiv > div:[2] > div"
    },
    {
      "t": 50604,
      "e": 50466,
      "ty": 2,
      "x": 890,
      "y": 853
    },
    {
      "t": 50703,
      "e": 50565,
      "ty": 2,
      "x": 923,
      "y": 939
    },
    {
      "t": 50754,
      "e": 50616,
      "ty": 41,
      "x": 31562,
      "y": 58493,
      "ta": "> div.masterdiv > div:[2]"
    },
    {
      "t": 50803,
      "e": 50665,
      "ty": 2,
      "x": 958,
      "y": 1033
    },
    {
      "t": 50829,
      "e": 50691,
      "ty": 6,
      "x": 974,
      "y": 1083,
      "ta": "#start"
    },
    {
      "t": 50903,
      "e": 50765,
      "ty": 2,
      "x": 975,
      "y": 1087
    },
    {
      "t": 51003,
      "e": 50865,
      "ty": 2,
      "x": 977,
      "y": 1091
    },
    {
      "t": 51004,
      "e": 50866,
      "ty": 41,
      "x": 36863,
      "y": 35297,
      "ta": "#start"
    },
    {
      "t": 51085,
      "e": 50947,
      "ty": 3,
      "x": 977,
      "y": 1092,
      "ta": "#start"
    },
    {
      "t": 51087,
      "e": 50949,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#start"
    },
    {
      "t": 51103,
      "e": 50965,
      "ty": 2,
      "x": 977,
      "y": 1092
    },
    {
      "t": 51156,
      "e": 51018,
      "ty": 4,
      "x": 36863,
      "y": 37224,
      "ta": "#start"
    },
    {
      "t": 51156,
      "e": 51018,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#start"
    },
    {
      "t": 51156,
      "e": 51018,
      "ty": 5,
      "x": 977,
      "y": 1092,
      "ta": "#start"
    },
    {
      "t": 51157,
      "e": 51019,
      "ty": 38,
      "x": 7,
      "y": 0
    },
    {
      "t": 51253,
      "e": 51115,
      "ty": 41,
      "x": 33370,
      "y": 60050,
      "ta": "html > body"
    },
    {
      "t": 51403,
      "e": 51265,
      "ty": 2,
      "x": 859,
      "y": 847
    },
    {
      "t": 51503,
      "e": 51365,
      "ty": 2,
      "x": 702,
      "y": 650
    },
    {
      "t": 51504,
      "e": 51366,
      "ty": 41,
      "x": 23899,
      "y": 35565,
      "ta": "html > body"
    },
    {
      "t": 51603,
      "e": 51465,
      "ty": 2,
      "x": 700,
      "y": 647
    },
    {
      "t": 51754,
      "e": 51616,
      "ty": 41,
      "x": 23830,
      "y": 35398,
      "ta": "html > body"
    },
    {
      "t": 52199,
      "e": 52061,
      "ty": 38,
      "x": 8,
      "y": 0
    },
    {
      "t": 53250,
      "e": 53112,
      "ty": 2,
      "x": 748,
      "y": 97
    },
    {
      "t": 53250,
      "e": 53112,
      "ty": 41,
      "x": 20262,
      "y": 32679,
      "ta": "#jspsych-data-display"
    },
    {
      "t": 53403,
      "e": 53265,
      "ty": 2,
      "x": 748,
      "y": 96
    },
    {
      "t": 53503,
      "e": 53365,
      "ty": 2,
      "x": 748,
      "y": 95
    },
    {
      "t": 53503,
      "e": 53365,
      "ty": 41,
      "x": 20262,
      "y": 32679,
      "ta": "#jspsych-data-display"
    },
    {
      "t": 53603,
      "e": 53465,
      "ty": 2,
      "x": 631,
      "y": 63
    },
    {
      "t": 53703,
      "e": 53565,
      "ty": 2,
      "x": 610,
      "y": 58
    },
    {
      "t": 53753,
      "e": 53615,
      "ty": 41,
      "x": 12103,
      "y": 32674,
      "ta": "#jspsych-data-display"
    },
    {
      "t": 53804,
      "e": 53666,
      "ty": 2,
      "x": 661,
      "y": 169
    },
    {
      "t": 53903,
      "e": 53765,
      "ty": 2,
      "x": 713,
      "y": 336
    },
    {
      "t": 54002,
      "e": 53864,
      "ty": 20,
      "x": 0,
      "y": 0
    }
  ],
  "domMutations": [
    {
      "sequence": 1,
      "data": "{\"f\":\"applyChanged\",\"args\":[[{\"id\":56},{\"id\":57},{\"id\":58},{\"id\":59},{\"id\":60},{\"id\":61},{\"id\":62},{\"id\":63},{\"id\":64},{\"id\":65},{\"id\":66},{\"id\":67},{\"id\":68},{\"id\":69},{\"id\":70},{\"id\":71},{\"id\":72},{\"id\":73},{\"id\":74},{\"id\":75},{\"id\":76},{\"id\":77},{\"id\":78},{\"id\":79},{\"id\":80},{\"id\":81},{\"id\":82},{\"id\":83},{\"id\":84},{\"id\":85},{\"id\":86},{\"id\":87},{\"id\":88},{\"id\":89},{\"id\":90},{\"id\":91},{\"id\":92},{\"id\":93},{\"id\":94},{\"id\":95},{\"id\":96},{\"id\":97},{\"id\":98},{\"id\":99},{\"id\":100},{\"id\":101},{\"id\":102},{\"id\":103},{\"id\":104},{\"id\":105},{\"id\":106},{\"id\":107},{\"id\":108},{\"id\":109},{\"id\":110},{\"id\":111},{\"id\":112},{\"id\":113},{\"id\":114},{\"id\":115},{\"id\":116},{\"id\":117},{\"id\":118},{\"id\":119},{\"id\":120},{\"id\":121},{\"id\":122},{\"id\":123},{\"id\":124},{\"id\":125},{\"id\":126},{\"id\":127},{\"id\":128},{\"id\":129},{\"id\":130},{\"id\":131},{\"id\":132},{\"id\":133},{\"id\":134},{\"id\":135},{\"id\":136},{\"id\":137},{\"id\":138},{\"id\":139},{\"id\":140},{\"id\":141},{\"id\":142},{\"id\":143},{\"id\":144},{\"id\":145},{\"id\":146},{\"id\":147},{\"id\":148},{\"id\":149},{\"id\":150},{\"id\":151},{\"id\":152},{\"id\":153},{\"id\":154},{\"id\":155},{\"id\":156},{\"id\":157},{\"id\":158},{\"id\":159},{\"id\":160},{\"id\":161},{\"id\":162},{\"id\":163},{\"id\":164},{\"id\":165},{\"id\":166},{\"id\":167},{\"id\":168},{\"id\":169},{\"id\":170},{\"id\":171},{\"id\":172},{\"id\":173},{\"id\":174},{\"id\":175},{\"id\":176},{\"id\":177},{\"id\":178},{\"id\":179},{\"id\":180},{\"id\":181},{\"id\":182},{\"id\":183},{\"id\":184},{\"id\":185},{\"id\":186},{\"id\":187},{\"id\":188},{\"id\":189},{\"id\":190},{\"id\":191},{\"id\":192},{\"id\":193},{\"id\":194},{\"id\":195},{\"id\":196},{\"id\":197},{\"id\":198},{\"id\":199},{\"id\":200},{\"id\":201},{\"id\":202},{\"id\":203},{\"id\":204},{\"id\":205},{\"id\":206},{\"id\":207},{\"id\":208},{\"id\":209},{\"id\":210},{\"id\":211},{\"id\":212},{\"id\":213},{\"id\":214},{\"id\":215},{\"id\":216},{\"id\":217},{\"id\":218},{\"id\":219},{\"id\":220},{\"id\":221},{\"id\":222},{\"id\":223},{\"id\":224},{\"id\":225},{\"id\":226},{\"id\":227},{\"id\":228},{\"id\":229},{\"id\":230},{\"id\":231},{\"id\":232},{\"id\":233},{\"id\":234},{\"id\":235},{\"id\":236},{\"id\":237},{\"id\":238},{\"id\":239},{\"id\":240},{\"id\":241},{\"id\":242},{\"id\":243},{\"id\":244},{\"id\":245},{\"id\":246},{\"id\":247},{\"id\":248},{\"id\":249},{\"id\":250},{\"id\":251},{\"id\":252},{\"id\":253},{\"id\":254},{\"id\":255},{\"id\":256},{\"id\":257},{\"id\":258},{\"id\":259},{\"id\":260},{\"id\":261},{\"id\":262},{\"id\":263},{\"id\":264},{\"id\":265},{\"id\":266},{\"id\":267},{\"id\":268},{\"id\":269},{\"id\":270},{\"id\":271},{\"id\":272},{\"id\":273},{\"id\":274},{\"id\":275},{\"id\":276},{\"id\":277},{\"id\":278},{\"id\":279},{\"id\":280},{\"id\":281},{\"id\":282},{\"id\":283},{\"id\":284},{\"id\":285},{\"id\":286},{\"id\":287},{\"id\":288},{\"id\":289},{\"id\":290},{\"id\":291},{\"id\":292},{\"id\":293},{\"id\":294},{\"id\":295},{\"id\":296},{\"id\":297},{\"id\":298},{\"id\":299},{\"id\":300},{\"id\":301},{\"id\":302},{\"id\":303},{\"id\":304},{\"id\":305},{\"id\":306},{\"id\":307},{\"id\":308},{\"id\":309},{\"id\":310},{\"id\":311},{\"id\":312},{\"id\":313},{\"id\":314},{\"id\":315},{\"id\":316},{\"id\":317},{\"id\":318},{\"id\":319},{\"id\":320},{\"id\":321},{\"id\":322},{\"id\":323},{\"id\":324},{\"id\":325},{\"id\":326},{\"id\":327},{\"id\":328},{\"id\":329},{\"id\":330},{\"id\":331},{\"id\":332},{\"id\":333},{\"id\":334},{\"id\":335},{\"id\":336},{\"id\":337},{\"id\":338},{\"id\":339},{\"id\":340},{\"id\":341},{\"id\":342},{\"id\":343},{\"id\":344},{\"id\":345},{\"id\":346},{\"id\":347},{\"id\":348},{\"id\":349},{\"id\":350},{\"id\":351},{\"id\":352},{\"id\":353},{\"id\":354},{\"id\":355},{\"id\":356},{\"id\":357},{\"id\":358},{\"id\":359},{\"id\":360},{\"id\":361},{\"id\":362},{\"id\":363},{\"id\":364},{\"id\":365},{\"id\":366},{\"id\":367},{\"id\":368},{\"id\":369},{\"id\":370},{\"id\":371},{\"id\":372},{\"id\":373},{\"id\":374},{\"id\":375},{\"id\":376},{\"id\":377},{\"id\":378},{\"id\":379},{\"id\":380},{\"id\":381},{\"id\":382},{\"id\":383},{\"id\":384},{\"id\":385},{\"id\":386},{\"id\":387},{\"id\":388},{\"id\":389},{\"id\":390},{\"id\":391},{\"id\":392},{\"id\":393},{\"id\":394},{\"id\":395},{\"id\":396},{\"id\":397},{\"id\":398},{\"id\":399},{\"id\":400},{\"id\":401},{\"id\":402},{\"id\":403},{\"id\":404},{\"id\":405},{\"id\":406},{\"id\":407},{\"id\":408},{\"id\":409},{\"id\":410},{\"id\":411},{\"id\":412},{\"id\":413},{\"id\":414},{\"id\":415},{\"id\":416},{\"id\":417},{\"id\":418},{\"id\":419},{\"id\":420},{\"id\":421},{\"id\":422},{\"id\":423},{\"id\":424},{\"id\":425},{\"id\":426},{\"id\":427},{\"id\":428},{\"id\":429},{\"id\":430},{\"id\":431},{\"id\":432},{\"id\":433},{\"id\":434},{\"id\":435},{\"id\":436},{\"id\":437},{\"id\":438},{\"id\":439},{\"id\":440},{\"id\":441},{\"id\":442},{\"id\":443},{\"id\":444},{\"id\":445},{\"id\":446},{\"id\":447},{\"id\":448},{\"id\":449},{\"id\":450},{\"id\":451},{\"id\":452},{\"id\":453},{\"id\":454},{\"id\":455},{\"id\":456},{\"id\":457},{\"id\":458},{\"id\":459},{\"id\":460},{\"id\":461},{\"id\":462},{\"id\":463},{\"id\":464},{\"id\":465},{\"id\":466},{\"id\":467},{\"id\":468},{\"id\":469},{\"id\":470},{\"id\":471},{\"id\":472},{\"id\":473},{\"id\":474},{\"id\":475},{\"id\":476},{\"id\":477},{\"id\":478},{\"id\":479},{\"id\":480},{\"id\":481},{\"id\":482},{\"id\":483},{\"id\":484},{\"id\":485},{\"id\":486},{\"id\":487},{\"id\":488},{\"id\":489},{\"id\":490},{\"id\":491},{\"id\":492},{\"id\":493},{\"id\":494},{\"id\":495},{\"id\":496},{\"id\":497},{\"id\":498},{\"id\":499},{\"id\":500},{\"id\":501},{\"id\":502},{\"id\":503},{\"id\":504},{\"id\":505},{\"id\":506},{\"id\":507},{\"id\":508},{\"id\":509},{\"id\":510},{\"id\":511},{\"id\":512},{\"id\":513},{\"id\":514},{\"id\":515},{\"id\":516},{\"id\":517},{\"id\":518},{\"id\":519},{\"id\":520},{\"id\":521},{\"id\":522},{\"id\":523},{\"id\":524},{\"id\":525},{\"id\":526},{\"id\":527},{\"id\":528},{\"id\":529},{\"id\":530},{\"id\":531},{\"id\":532},{\"id\":533},{\"id\":534},{\"id\":535},{\"id\":536},{\"id\":537},{\"id\":538},{\"id\":539},{\"id\":540},{\"id\":541},{\"id\":542},{\"id\":543},{\"id\":544},{\"id\":545},{\"id\":546},{\"id\":547},{\"id\":548},{\"id\":549},{\"id\":550},{\"id\":551},{\"id\":552},{\"id\":553},{\"id\":554},{\"id\":555},{\"id\":556},{\"id\":557},{\"id\":558},{\"id\":559},{\"id\":560},{\"id\":561},{\"id\":562},{\"id\":563},{\"id\":564},{\"id\":565},{\"id\":566},{\"id\":567},{\"id\":568},{\"id\":569},{\"id\":570},{\"id\":571},{\"id\":572},{\"id\":573},{\"id\":574},{\"id\":575},{\"id\":576},{\"id\":577},{\"id\":578},{\"id\":579},{\"id\":580},{\"id\":581},{\"id\":582},{\"id\":583},{\"id\":584},{\"id\":585},{\"id\":586},{\"id\":587},{\"id\":588},{\"id\":589},{\"id\":590},{\"id\":591},{\"id\":592},{\"id\":593},{\"id\":594},{\"id\":595},{\"id\":596},{\"id\":597},{\"id\":598},{\"id\":599},{\"id\":600},{\"id\":601},{\"id\":602},{\"id\":603},{\"id\":604},{\"id\":605},{\"id\":606},{\"id\":607},{\"id\":608},{\"id\":609},{\"id\":610},{\"id\":611},{\"id\":612},{\"id\":613},{\"id\":614},{\"id\":615},{\"id\":616},{\"id\":617},{\"id\":618},{\"id\":619},{\"id\":620},{\"id\":621},{\"id\":622},{\"id\":623},{\"id\":624},{\"id\":625},{\"id\":626},{\"id\":627},{\"id\":628},{\"id\":629},{\"id\":630},{\"id\":631},{\"id\":632},{\"id\":633},{\"id\":634},{\"id\":635},{\"id\":636},{\"id\":637},{\"id\":638},{\"id\":639},{\"id\":640},{\"id\":641},{\"id\":642},{\"id\":643},{\"id\":644},{\"id\":645},{\"id\":646},{\"id\":647},{\"id\":648},{\"id\":649},{\"id\":650},{\"id\":651},{\"id\":652},{\"id\":653},{\"id\":654},{\"id\":655},{\"id\":656},{\"id\":657},{\"id\":658},{\"id\":659},{\"id\":660},{\"id\":661},{\"id\":662},{\"id\":663},{\"id\":664},{\"id\":665},{\"id\":666},{\"id\":667},{\"id\":668},{\"id\":669},{\"id\":670},{\"id\":671},{\"id\":672},{\"id\":673},{\"id\":674},{\"id\":675},{\"id\":676},{\"id\":677},{\"id\":678},{\"id\":679},{\"id\":680},{\"id\":681},{\"id\":682},{\"id\":683},{\"id\":684},{\"id\":685},{\"id\":686},{\"id\":687},{\"id\":688},{\"id\":689},{\"id\":690},{\"id\":691},{\"id\":692},{\"id\":693},{\"id\":694},{\"id\":695},{\"id\":696},{\"id\":697},{\"id\":698},{\"id\":699},{\"id\":700},{\"id\":701},{\"id\":702},{\"id\":703},{\"id\":704},{\"id\":705},{\"id\":706},{\"id\":707},{\"id\":708},{\"id\":709},{\"id\":710},{\"id\":711},{\"id\":712},{\"id\":713},{\"id\":714},{\"id\":715},{\"id\":716},{\"id\":717},{\"id\":718},{\"id\":719},{\"id\":720},{\"id\":721},{\"id\":722},{\"id\":723},{\"id\":724},{\"id\":725},{\"id\":726},{\"id\":727},{\"id\":728},{\"id\":729},{\"id\":730},{\"id\":731},{\"id\":732},{\"id\":733},{\"id\":734},{\"id\":735},{\"id\":736},{\"id\":737},{\"id\":738},{\"id\":739},{\"id\":740},{\"id\":741},{\"id\":742},{\"id\":743},{\"id\":744},{\"id\":745},{\"id\":746},{\"id\":747},{\"id\":748},{\"id\":749},{\"id\":750},{\"id\":751},{\"id\":752},{\"id\":753},{\"id\":754},{\"id\":755},{\"id\":756},{\"id\":757},{\"id\":758},{\"id\":759},{\"id\":760},{\"id\":761},{\"id\":762},{\"id\":763},{\"id\":764},{\"id\":765},{\"id\":766},{\"id\":767},{\"id\":768},{\"id\":769},{\"id\":770},{\"id\":771},{\"id\":772},{\"id\":773},{\"id\":774},{\"id\":775},{\"id\":776},{\"id\":777},{\"id\":778},{\"id\":779},{\"id\":780},{\"id\":781},{\"id\":782},{\"id\":783},{\"id\":784},{\"id\":785},{\"id\":786},{\"id\":787},{\"id\":788},{\"id\":789},{\"id\":790},{\"id\":791},{\"id\":792},{\"id\":793},{\"id\":794},{\"id\":795},{\"id\":796},{\"id\":797},{\"id\":798},{\"id\":799},{\"id\":800},{\"id\":801},{\"id\":802},{\"id\":803},{\"id\":804},{\"id\":805},{\"id\":806},{\"id\":807},{\"id\":808},{\"id\":809},{\"id\":810},{\"id\":811},{\"id\":812},{\"id\":813},{\"id\":814},{\"id\":815},{\"id\":816},{\"id\":817},{\"id\":818},{\"id\":819},{\"id\":820},{\"id\":821},{\"id\":822},{\"id\":823},{\"id\":824},{\"id\":825},{\"id\":826},{\"id\":827},{\"id\":828},{\"id\":829},{\"id\":830},{\"id\":831},{\"id\":832},{\"id\":833},{\"id\":834},{\"id\":835},{\"id\":836},{\"id\":837},{\"id\":838},{\"id\":839},{\"id\":840},{\"id\":841},{\"id\":842},{\"id\":843},{\"id\":844},{\"id\":845},{\"id\":846},{\"id\":847},{\"id\":848},{\"id\":849},{\"id\":850},{\"id\":851},{\"id\":852},{\"id\":853},{\"id\":854},{\"id\":855},{\"id\":856},{\"id\":857},{\"id\":858},{\"id\":859},{\"id\":860},{\"id\":861},{\"id\":862},{\"id\":863},{\"id\":864},{\"id\":865},{\"id\":866},{\"id\":867},{\"id\":868},{\"id\":869},{\"id\":870},{\"id\":871},{\"id\":872},{\"id\":873},{\"id\":874},{\"id\":875},{\"id\":876},{\"id\":877},{\"id\":878},{\"id\":879},{\"id\":880},{\"id\":881},{\"id\":882},{\"id\":883},{\"id\":884},{\"id\":885},{\"id\":886},{\"id\":887},{\"id\":888},{\"id\":889},{\"id\":890},{\"id\":891},{\"id\":892},{\"id\":893},{\"id\":894},{\"id\":895},{\"id\":896},{\"id\":897},{\"id\":898},{\"id\":899},{\"id\":900},{\"id\":901},{\"id\":902},{\"id\":903},{\"id\":904},{\"id\":905},{\"id\":906},{\"id\":907},{\"id\":908},{\"id\":909},{\"id\":910},{\"id\":911},{\"id\":912},{\"id\":913},{\"id\":914},{\"id\":915},{\"id\":916},{\"id\":917},{\"id\":918},{\"id\":919},{\"id\":920},{\"id\":921},{\"id\":922},{\"id\":923},{\"id\":924},{\"id\":925},{\"id\":926},{\"id\":927},{\"id\":928},{\"id\":929},{\"id\":930},{\"id\":931},{\"id\":932},{\"id\":933},{\"id\":934},{\"id\":935},{\"id\":936},{\"id\":937},{\"id\":938},{\"id\":939},{\"id\":940},{\"id\":941},{\"id\":942},{\"id\":943},{\"id\":944},{\"id\":945},{\"id\":946},{\"id\":947},{\"id\":948},{\"id\":949},{\"id\":950},{\"id\":951},{\"id\":952},{\"id\":953},{\"id\":954},{\"id\":955},{\"id\":956},{\"id\":957},{\"id\":958},{\"id\":959},{\"id\":960},{\"id\":961},{\"id\":962},{\"id\":963},{\"id\":964},{\"id\":965},{\"id\":966},{\"id\":967},{\"id\":968},{\"id\":969},{\"id\":970},{\"id\":971},{\"id\":972},{\"id\":973},{\"id\":974},{\"id\":975},{\"id\":976},{\"id\":977},{\"id\":978},{\"id\":979},{\"id\":980},{\"id\":981},{\"id\":982},{\"id\":983},{\"id\":984},{\"id\":985},{\"id\":986},{\"id\":987},{\"id\":988},{\"id\":989},{\"id\":990},{\"id\":991},{\"id\":992},{\"id\":993},{\"id\":994},{\"id\":995},{\"id\":996},{\"id\":997},{\"id\":998},{\"id\":999},{\"id\":1000},{\"id\":1001},{\"id\":1002},{\"id\":1003},{\"id\":1004},{\"id\":1005},{\"id\":1006},{\"id\":1007},{\"id\":1008},{\"id\":1009},{\"id\":1010},{\"id\":1011},{\"id\":1012},{\"id\":1013},{\"id\":1014},{\"id\":1015},{\"id\":1016},{\"id\":1017},{\"id\":1018},{\"id\":1019},{\"id\":1020},{\"id\":1021},{\"id\":1022},{\"id\":1023},{\"id\":1024},{\"id\":1025},{\"id\":1026},{\"id\":1027},{\"id\":1028},{\"id\":1029},{\"id\":1030},{\"id\":1031},{\"id\":1032},{\"id\":1033},{\"id\":1034},{\"id\":1035},{\"id\":1036},{\"id\":1037},{\"id\":1038},{\"id\":1039},{\"id\":1040},{\"id\":1041},{\"id\":1042},{\"id\":1043},{\"id\":1044},{\"id\":1045},{\"id\":1046},{\"id\":1047},{\"id\":1048},{\"id\":1049},{\"id\":1050},{\"id\":1051},{\"id\":1052},{\"id\":1053},{\"id\":1054},{\"id\":1055},{\"id\":1056},{\"id\":1057},{\"id\":1058},{\"id\":1059},{\"id\":1060},{\"id\":1061},{\"id\":1062},{\"id\":1063},{\"id\":1064},{\"id\":1065},{\"id\":1066},{\"id\":1067},{\"id\":1068},{\"id\":1069},{\"id\":1070},{\"id\":1071},{\"id\":1072},{\"id\":1073},{\"id\":1074},{\"id\":1075},{\"id\":1076},{\"id\":1077},{\"id\":1078},{\"id\":1079},{\"id\":1080},{\"id\":1081},{\"id\":1082},{\"id\":1083},{\"id\":1084},{\"id\":1085},{\"id\":1086},{\"id\":1087},{\"id\":1088},{\"id\":1089},{\"id\":1090},{\"id\":1091},{\"id\":1092},{\"id\":1093},{\"id\":1094},{\"id\":1095},{\"id\":1096},{\"id\":1097},{\"id\":1098},{\"id\":1099},{\"id\":1100},{\"id\":1101},{\"id\":1102},{\"id\":1103},{\"id\":1104},{\"id\":1105},{\"id\":1106},{\"id\":1107},{\"id\":1108},{\"id\":1109},{\"id\":1110},{\"id\":1111},{\"id\":1112},{\"id\":1113},{\"id\":1114},{\"id\":1115},{\"id\":1116},{\"id\":1117},{\"id\":1118},{\"id\":1119},{\"id\":1120},{\"id\":1121},{\"id\":1122},{\"id\":1123},{\"id\":1124},{\"id\":1125},{\"id\":1126},{\"id\":1127},{\"id\":1128},{\"id\":1129},{\"id\":1130},{\"id\":1131},{\"id\":1132},{\"id\":1133},{\"id\":1134},{\"id\":1135},{\"id\":1136},{\"id\":1137},{\"id\":1138},{\"id\":1139},{\"id\":1140},{\"id\":1141},{\"id\":1142},{\"id\":1143},{\"id\":1144},{\"id\":1145},{\"id\":1146},{\"id\":1147},{\"id\":1148},{\"id\":1149},{\"id\":1150},{\"id\":1151},{\"id\":1152},{\"id\":1153},{\"id\":1154},{\"id\":1155},{\"id\":1156},{\"id\":1157},{\"id\":1158},{\"id\":1159},{\"id\":1160},{\"id\":1161},{\"id\":1162},{\"id\":1163},{\"id\":1164},{\"id\":1165},{\"id\":1166},{\"id\":1167},{\"id\":1168},{\"id\":1169},{\"id\":1170},{\"id\":1171},{\"id\":1172},{\"id\":1173},{\"id\":1174},{\"id\":1175},{\"id\":1176},{\"id\":1177},{\"id\":1178},{\"id\":1179},{\"id\":1180},{\"id\":1181},{\"id\":1182},{\"id\":1183},{\"id\":1184},{\"id\":1185},{\"id\":1186},{\"id\":1187},{\"id\":1188},{\"id\":1189},{\"id\":1190},{\"id\":1191},{\"id\":1192},{\"id\":1193},{\"id\":1194},{\"id\":1195},{\"id\":1196},{\"id\":1197},{\"id\":1198},{\"id\":1199},{\"id\":1200},{\"id\":1201},{\"id\":1202},{\"id\":1203},{\"id\":1204},{\"id\":1205},{\"id\":1206},{\"id\":1207},{\"id\":1208},{\"id\":1209},{\"id\":1210},{\"id\":1211},{\"id\":1212},{\"id\":1213},{\"id\":1214},{\"id\":1215},{\"id\":1216},{\"id\":1217},{\"id\":1218},{\"id\":1219},{\"id\":1220},{\"id\":1221},{\"id\":1222},{\"id\":1223},{\"id\":1224},{\"id\":1225},{\"id\":1226},{\"id\":1227},{\"id\":1228},{\"id\":1229},{\"id\":1230},{\"id\":1231},{\"id\":1232},{\"id\":1233},{\"id\":1234},{\"id\":1235},{\"id\":1236},{\"id\":1237},{\"id\":1238},{\"id\":1239},{\"id\":1240},{\"id\":1241},{\"id\":1242},{\"id\":1243},{\"id\":1244},{\"id\":1245},{\"id\":1246},{\"id\":1247},{\"id\":1248},{\"id\":1249},{\"id\":1250},{\"id\":1251},{\"id\":1252},{\"id\":1253},{\"id\":1254},{\"id\":1255},{\"id\":1256},{\"id\":1257},{\"id\":1258},{\"id\":1259},{\"id\":1260},{\"id\":1261},{\"id\":1262},{\"id\":1263},{\"id\":1264},{\"id\":1265},{\"id\":1266},{\"id\":1267},{\"id\":1268},{\"id\":1269},{\"id\":1270},{\"id\":1271},{\"id\":1272},{\"id\":1273},{\"id\":1274},{\"id\":1275},{\"id\":1276},{\"id\":1277},{\"id\":1278},{\"id\":1279},{\"id\":1280},{\"id\":1281},{\"id\":1282},{\"id\":1283},{\"id\":1284},{\"id\":1285},{\"id\":1286},{\"id\":1287},{\"id\":1288},{\"id\":1289},{\"id\":1290},{\"id\":1291},{\"id\":1292},{\"id\":1293},{\"id\":1294},{\"id\":1295},{\"id\":1296},{\"id\":1297},{\"id\":1298},{\"id\":1299},{\"id\":1300},{\"id\":1301},{\"id\":1302},{\"id\":1303},{\"id\":1304},{\"id\":1305},{\"id\":1306},{\"id\":1307},{\"id\":1308},{\"id\":1309},{\"id\":1310},{\"id\":1311},{\"id\":1312},{\"id\":1313},{\"id\":1314},{\"id\":1315},{\"id\":1316},{\"id\":1317},{\"id\":1318},{\"id\":1319},{\"id\":1320},{\"id\":1321},{\"id\":1322},{\"id\":1323},{\"id\":1324},{\"id\":1325},{\"id\":1326},{\"id\":1327},{\"id\":1328},{\"id\":1329},{\"id\":1330},{\"id\":1331},{\"id\":1332},{\"id\":1333},{\"id\":1334},{\"id\":1335},{\"id\":1336},{\"id\":1337},{\"id\":1338},{\"id\":1339},{\"id\":1340},{\"id\":1341},{\"id\":1342},{\"id\":1343},{\"id\":1344},{\"id\":1345},{\"id\":1346},{\"id\":1347},{\"id\":1348},{\"id\":1349},{\"id\":1350},{\"id\":1351},{\"id\":1352},{\"id\":1353},{\"id\":1354},{\"id\":1355},{\"id\":1356},{\"id\":1357},{\"id\":1358},{\"id\":1359},{\"id\":1360},{\"id\":1361},{\"id\":1362},{\"id\":1363},{\"id\":1364},{\"id\":1365},{\"id\":1366},{\"id\":1367},{\"id\":1368},{\"id\":1369},{\"id\":1370},{\"id\":1371},{\"id\":1372},{\"id\":1373},{\"id\":1374},{\"id\":1375},{\"id\":1376},{\"id\":1377},{\"id\":1378},{\"id\":1379},{\"id\":1380},{\"id\":1381},{\"id\":1382},{\"id\":1383},{\"id\":1384},{\"id\":1385},{\"id\":1386},{\"id\":1387},{\"id\":1388},{\"id\":1389},{\"id\":1390},{\"id\":1391},{\"id\":1392},{\"id\":1393},{\"id\":1394},{\"id\":1395},{\"id\":1396},{\"id\":1397},{\"id\":1398},{\"id\":1399},{\"id\":1400},{\"id\":1401},{\"id\":1402},{\"id\":1403},{\"id\":1404},{\"id\":1405},{\"id\":1406},{\"id\":1407},{\"id\":1408},{\"id\":1409},{\"id\":1410},{\"id\":1411},{\"id\":1412},{\"id\":1413},{\"id\":1414},{\"id\":1415},{\"id\":1416},{\"id\":1417},{\"id\":1418},{\"id\":1419},{\"id\":1420},{\"id\":1421},{\"id\":1422},{\"id\":1423},{\"id\":1424},{\"id\":1425},{\"id\":1426},{\"id\":1427},{\"id\":1428},{\"id\":1429},{\"id\":1430},{\"id\":1431},{\"id\":1432},{\"id\":1433},{\"id\":1434},{\"id\":1435},{\"id\":1436},{\"id\":1437},{\"id\":1438},{\"id\":1439},{\"id\":1440},{\"id\":1441},{\"id\":1442},{\"id\":1443},{\"id\":1444},{\"id\":1445},{\"id\":1446},{\"id\":1447},{\"id\":1448},{\"id\":1449},{\"id\":1450},{\"id\":1451},{\"id\":1452},{\"id\":1453},{\"id\":1454},{\"id\":1455},{\"id\":1456},{\"id\":1457},{\"id\":1458},{\"id\":1459},{\"id\":1460},{\"id\":1461},{\"id\":1462},{\"id\":1463},{\"id\":1464},{\"id\":1465},{\"id\":1466},{\"id\":1467},{\"id\":1468},{\"id\":1469},{\"id\":1470},{\"id\":1471},{\"id\":1472},{\"id\":1473},{\"id\":1474},{\"id\":1475},{\"id\":1476},{\"id\":1477},{\"id\":1478},{\"id\":1479},{\"id\":1480},{\"id\":1481},{\"id\":1482},{\"id\":1483},{\"id\":1484},{\"id\":1485},{\"id\":1486},{\"id\":1487},{\"id\":1488},{\"id\":1489},{\"id\":1490},{\"id\":1491},{\"id\":1492},{\"id\":1493},{\"id\":1494},{\"id\":1495},{\"id\":1496},{\"id\":1497},{\"id\":1498},{\"id\":1499},{\"id\":1500},{\"id\":1501},{\"id\":1502},{\"id\":1503},{\"id\":1504},{\"id\":1505},{\"id\":1506},{\"id\":1507},{\"id\":1508},{\"id\":1509},{\"id\":1510},{\"id\":1511},{\"id\":1512},{\"id\":1513},{\"id\":1514},{\"id\":1515},{\"id\":1516},{\"id\":1517},{\"id\":1518},{\"id\":1519},{\"id\":1520},{\"id\":1521},{\"id\":1522},{\"id\":1523},{\"id\":1524},{\"id\":1525},{\"id\":1526},{\"id\":1527},{\"id\":1528},{\"id\":1529},{\"id\":1530},{\"id\":1531},{\"id\":1532},{\"id\":1533},{\"id\":1534},{\"id\":1535},{\"id\":1536},{\"id\":1537},{\"id\":1538},{\"id\":1539},{\"id\":1540},{\"id\":1541},{\"id\":1542},{\"id\":1543},{\"id\":1544},{\"id\":1545},{\"id\":1546},{\"id\":1547},{\"id\":1548},{\"id\":1549},{\"id\":1550},{\"id\":1551},{\"id\":1552},{\"id\":1553},{\"id\":1554},{\"id\":1555},{\"id\":1556},{\"id\":1557},{\"id\":1558},{\"id\":1559},{\"id\":1560},{\"id\":1561},{\"id\":1562},{\"id\":1563},{\"id\":1564},{\"id\":1565},{\"id\":1566},{\"id\":1567},{\"id\":1568},{\"id\":1569},{\"id\":1570},{\"id\":1571},{\"id\":1572},{\"id\":1573},{\"id\":1574},{\"id\":1575},{\"id\":1576},{\"id\":1577},{\"id\":1578},{\"id\":1579},{\"id\":1580},{\"id\":1581},{\"id\":1582},{\"id\":1583},{\"id\":1584},{\"id\":1585},{\"id\":1586},{\"id\":1587},{\"id\":1588},{\"id\":1589},{\"id\":1590},{\"id\":1591},{\"id\":1592},{\"id\":1593},{\"id\":1594},{\"id\":1595},{\"id\":1596},{\"id\":1597},{\"id\":1598},{\"id\":1599},{\"id\":1600},{\"id\":1601},{\"id\":1602},{\"id\":1603},{\"id\":1604},{\"id\":1605},{\"id\":1606},{\"id\":1607},{\"id\":1608},{\"id\":1609},{\"id\":1610},{\"id\":1611},{\"id\":1612},{\"id\":1613},{\"id\":1614},{\"id\":1615},{\"id\":1616},{\"id\":1617},{\"id\":1618},{\"id\":1619},{\"id\":1620},{\"id\":1621},{\"id\":1622},{\"id\":1623},{\"id\":1624},{\"id\":1625},{\"id\":1626},{\"id\":1627},{\"id\":1628},{\"id\":1629},{\"id\":1630},{\"id\":1631},{\"id\":1632},{\"id\":1633},{\"id\":1634},{\"id\":1635},{\"id\":1636},{\"id\":1637},{\"id\":1638},{\"id\":1639},{\"id\":1640},{\"id\":1641},{\"id\":1642},{\"id\":1643},{\"id\":1644},{\"id\":1645},{\"id\":1646},{\"id\":1647},{\"id\":1648},{\"id\":1649},{\"id\":1650},{\"id\":1651},{\"id\":1652},{\"id\":1653},{\"id\":1654},{\"id\":1655},{\"id\":1656},{\"id\":1657},{\"id\":1658},{\"id\":1659},{\"id\":1660},{\"id\":1661},{\"id\":1662},{\"id\":1663},{\"id\":1664},{\"id\":1665},{\"id\":1666},{\"id\":1667},{\"id\":1668},{\"id\":1669},{\"id\":1670},{\"id\":1671},{\"id\":1672},{\"id\":1673},{\"id\":1674},{\"id\":1675},{\"id\":1676},{\"id\":1677},{\"id\":1678},{\"id\":1679},{\"id\":1680},{\"id\":1681},{\"id\":1682},{\"id\":1683},{\"id\":1684},{\"id\":1685},{\"id\":1686},{\"id\":1687},{\"id\":1688},{\"id\":1689},{\"id\":1690},{\"id\":1691},{\"id\":1692},{\"id\":1693},{\"id\":1694},{\"id\":1695},{\"id\":1696},{\"id\":1697},{\"id\":1698},{\"id\":1699},{\"id\":1700},{\"id\":1701},{\"id\":1702},{\"id\":1703},{\"id\":1704},{\"id\":1705},{\"id\":1706},{\"id\":1707},{\"id\":1708},{\"id\":1709},{\"id\":1710},{\"id\":1711},{\"id\":1712},{\"id\":1713},{\"id\":1714},{\"id\":1715},{\"id\":1716},{\"id\":1717},{\"id\":1718},{\"id\":1719},{\"id\":1720},{\"id\":1721},{\"id\":1722},{\"id\":1723},{\"id\":1724},{\"id\":1725},{\"id\":1726},{\"id\":1727},{\"id\":1728},{\"id\":1729},{\"id\":1730},{\"id\":1731},{\"id\":1732},{\"id\":1733},{\"id\":1734},{\"id\":1735},{\"id\":1736},{\"id\":1737},{\"id\":1738},{\"id\":1739},{\"id\":1740},{\"id\":1741},{\"id\":1742},{\"id\":1743},{\"id\":1744},{\"id\":1745},{\"id\":1746},{\"id\":1747},{\"id\":1748},{\"id\":1749},{\"id\":1750},{\"id\":1751},{\"id\":1752},{\"id\":1753},{\"id\":1754},{\"id\":1755},{\"id\":1756},{\"id\":1757},{\"id\":1758},{\"id\":1759},{\"id\":1760},{\"id\":1761},{\"id\":1762},{\"id\":1763},{\"id\":1764},{\"id\":1765},{\"id\":1766},{\"id\":1767},{\"id\":1768},{\"id\":1769},{\"id\":1770},{\"id\":1771},{\"id\":1772},{\"id\":1773},{\"id\":1774},{\"id\":1775},{\"id\":1776},{\"id\":1777},{\"id\":1778},{\"id\":1779},{\"id\":1780},{\"id\":1781},{\"id\":1782},{\"id\":1783},{\"id\":1784},{\"id\":1785},{\"id\":1786},{\"id\":1787},{\"id\":1788},{\"id\":1789},{\"id\":1790},{\"id\":1791},{\"id\":1792},{\"id\":1793},{\"id\":1794},{\"id\":1795},{\"id\":1796},{\"id\":1797},{\"id\":1798},{\"id\":1799},{\"id\":1800},{\"id\":1801},{\"id\":1802},{\"id\":1803},{\"id\":1804},{\"id\":1805},{\"id\":1806},{\"id\":1807},{\"id\":1808},{\"id\":1809},{\"id\":1810},{\"id\":1811},{\"id\":1812},{\"id\":1813},{\"id\":1814},{\"id\":1815},{\"id\":1816},{\"id\":1817},{\"id\":1818},{\"id\":1819},{\"id\":1820},{\"id\":1821},{\"id\":1822},{\"id\":1823},{\"id\":1824},{\"id\":1825},{\"id\":1826},{\"id\":1827},{\"id\":1828},{\"id\":1829},{\"id\":1830},{\"id\":1831},{\"id\":1832},{\"id\":1833},{\"id\":1834},{\"id\":1835},{\"id\":1836},{\"id\":1837},{\"id\":1838},{\"id\":1839},{\"id\":1840},{\"id\":1841},{\"id\":1842},{\"id\":1843},{\"id\":1844},{\"id\":1845},{\"id\":1846},{\"id\":1847},{\"id\":1848},{\"id\":1849},{\"id\":1850},{\"id\":1851},{\"id\":1852},{\"id\":1853},{\"id\":1854},{\"id\":1855},{\"id\":1856},{\"id\":1857},{\"id\":1858},{\"id\":1859},{\"id\":1860},{\"id\":1861},{\"id\":1862},{\"id\":1863},{\"id\":1864},{\"id\":1865},{\"id\":1866},{\"id\":1867},{\"id\":1868},{\"id\":1869},{\"id\":1870},{\"id\":1871},{\"id\":1872},{\"id\":1873},{\"id\":1874},{\"id\":1875},{\"id\":1876},{\"id\":1877},{\"id\":1878},{\"id\":1879},{\"id\":1880},{\"id\":1881},{\"id\":1882},{\"id\":1883},{\"id\":1884},{\"id\":1885},{\"id\":1886},{\"id\":1887},{\"id\":1888},{\"id\":1889},{\"id\":1890},{\"id\":1891},{\"id\":1892},{\"id\":1893},{\"id\":1894},{\"id\":1895},{\"id\":1896},{\"id\":1897},{\"id\":1898},{\"id\":1899},{\"id\":1900},{\"id\":1901},{\"id\":1902},{\"id\":1903},{\"id\":1904},{\"id\":1905},{\"id\":1906},{\"id\":1907},{\"id\":1908},{\"id\":1909},{\"id\":1910},{\"id\":1911},{\"id\":1912},{\"id\":1913},{\"id\":1914},{\"id\":1915},{\"id\":1916},{\"id\":1917},{\"id\":1918},{\"id\":1919},{\"id\":1920},{\"id\":1921},{\"id\":1922},{\"id\":1923},{\"id\":1924},{\"id\":1925},{\"id\":1926},{\"id\":1927},{\"id\":1928},{\"id\":1929},{\"id\":1930},{\"id\":1931},{\"id\":1932},{\"id\":1933},{\"id\":1934},{\"id\":1935},{\"id\":1936},{\"id\":1937},{\"id\":1938},{\"id\":1939},{\"id\":1940},{\"id\":1941},{\"id\":1942},{\"id\":1943},{\"id\":1944},{\"id\":1945},{\"id\":1946},{\"id\":1947},{\"id\":1948},{\"id\":1949},{\"id\":1950},{\"id\":1951},{\"id\":1952},{\"id\":1953},{\"id\":1954},{\"id\":1955},{\"id\":1956},{\"id\":1957},{\"id\":1958},{\"id\":1959},{\"id\":1960},{\"id\":1961},{\"id\":1962},{\"id\":1963},{\"id\":1964},{\"id\":1965},{\"id\":1966},{\"id\":1967},{\"id\":1968},{\"id\":1969},{\"id\":1970},{\"id\":1971},{\"id\":1972},{\"id\":1973},{\"id\":1974},{\"id\":1975},{\"id\":1976},{\"id\":1977},{\"id\":1978},{\"id\":1979},{\"id\":1980},{\"id\":1981},{\"id\":1982},{\"id\":1983},{\"id\":1984},{\"id\":1985},{\"id\":1986},{\"id\":1987},{\"id\":1988},{\"id\":1989},{\"id\":1990},{\"id\":1991},{\"id\":1992},{\"id\":1993},{\"id\":1994},{\"id\":1995},{\"id\":1996},{\"id\":1997},{\"id\":1998},{\"id\":1999},{\"id\":2000},{\"id\":2001},{\"id\":2002},{\"id\":2003},{\"id\":2004},{\"id\":2005},{\"id\":2006},{\"id\":2007},{\"id\":2008},{\"id\":2009},{\"id\":2010},{\"id\":2011},{\"id\":2012},{\"id\":2013},{\"id\":2014},{\"id\":2015},{\"id\":2016},{\"id\":2017},{\"id\":2018},{\"id\":2019},{\"id\":2020},{\"id\":2021},{\"id\":2022},{\"id\":2023},{\"id\":2024},{\"id\":2025},{\"id\":2026},{\"id\":2027},{\"id\":2028},{\"id\":2029},{\"id\":2030},{\"id\":2031},{\"id\":2032},{\"id\":2033},{\"id\":2034},{\"id\":2035},{\"id\":2036},{\"id\":2037},{\"id\":2038},{\"id\":2039},{\"id\":2040},{\"id\":2041},{\"id\":2042},{\"id\":2043},{\"id\":2044},{\"id\":2045},{\"id\":2046},{\"id\":2047},{\"id\":2048},{\"id\":2049},{\"id\":2050},{\"id\":2051},{\"id\":2052},{\"id\":2053},{\"id\":2054},{\"id\":2055},{\"id\":2056},{\"id\":2057},{\"id\":2058},{\"id\":2059},{\"id\":2060},{\"id\":2061},{\"id\":2062},{\"id\":2063},{\"id\":2064},{\"id\":2065},{\"id\":2066},{\"id\":2067},{\"id\":2068},{\"id\":2069},{\"id\":2070},{\"id\":2071},{\"id\":2072},{\"id\":2073},{\"id\":2074},{\"id\":2075},{\"id\":2076},{\"id\":2077},{\"id\":2078},{\"id\":2079},{\"id\":2080},{\"id\":2081},{\"id\":2082},{\"id\":2083},{\"id\":2084},{\"id\":2085},{\"id\":2086},{\"id\":2087},{\"id\":2088},{\"id\":2089},{\"id\":2090},{\"id\":2091},{\"id\":2092},{\"id\":2093},{\"id\":2094},{\"id\":2095},{\"id\":2096},{\"id\":2097},{\"id\":2098},{\"id\":2099},{\"id\":2100},{\"id\":2101},{\"id\":2102},{\"id\":2103},{\"id\":2104},{\"id\":2105},{\"id\":2106},{\"id\":2107},{\"id\":2108},{\"id\":2109},{\"id\":2110},{\"id\":2111},{\"id\":2112},{\"id\":2113},{\"id\":2114},{\"id\":2115},{\"id\":2116},{\"id\":2117},{\"id\":2118},{\"id\":2119},{\"id\":2120},{\"id\":2121},{\"id\":2122},{\"id\":2123},{\"id\":2124},{\"id\":2125},{\"id\":2126},{\"id\":2127},{\"id\":2128},{\"id\":2129},{\"id\":2130},{\"id\":2131},{\"id\":2132},{\"id\":2133},{\"id\":2134},{\"id\":2135},{\"id\":2136},{\"id\":2137},{\"id\":2138},{\"id\":2139},{\"id\":2140},{\"id\":2141},{\"id\":2142},{\"id\":2143},{\"id\":2144},{\"id\":2145},{\"id\":2146},{\"id\":2147},{\"id\":2148},{\"id\":2149},{\"id\":2150},{\"id\":2151},{\"id\":2152},{\"id\":2153},{\"id\":2154},{\"id\":2155},{\"id\":2156},{\"id\":2157},{\"id\":2158},{\"id\":2159},{\"id\":2160},{\"id\":2161},{\"id\":2162},{\"id\":2163},{\"id\":2164},{\"id\":2165},{\"id\":2166},{\"id\":2167},{\"id\":2168},{\"id\":2169},{\"id\":2170},{\"id\":2171},{\"id\":2172},{\"id\":2173},{\"id\":2174},{\"id\":2175},{\"id\":2176},{\"id\":2177},{\"id\":2178},{\"id\":2179},{\"id\":2180},{\"id\":2181},{\"id\":2182},{\"id\":2183},{\"id\":2184},{\"id\":2185},{\"id\":2186},{\"id\":2187},{\"id\":2188},{\"id\":2189},{\"id\":2190},{\"id\":2191},{\"id\":2192},{\"id\":2193},{\"id\":2194},{\"id\":2195},{\"id\":2196},{\"id\":2197},{\"id\":2198},{\"id\":2199},{\"id\":2200},{\"id\":2201},{\"id\":2202},{\"id\":2203},{\"id\":2204},{\"id\":2205},{\"id\":2206},{\"id\":2207},{\"id\":2208},{\"id\":2209},{\"id\":2210},{\"id\":2211},{\"id\":2212},{\"id\":2213},{\"id\":2214},{\"id\":2215},{\"id\":2216},{\"id\":2217},{\"id\":2218},{\"id\":2219},{\"id\":2220},{\"id\":2221},{\"id\":2222},{\"id\":2223},{\"id\":2224},{\"id\":2225},{\"id\":2226},{\"id\":2227},{\"id\":2228},{\"id\":2229},{\"id\":2230},{\"id\":2231},{\"id\":2232},{\"id\":2233},{\"id\":2234},{\"id\":2235},{\"id\":2236},{\"id\":2237},{\"id\":2238},{\"id\":2239},{\"id\":2240},{\"id\":2241},{\"id\":2242},{\"id\":2243},{\"id\":2244},{\"id\":2245},{\"id\":2246},{\"id\":2247},{\"id\":2248},{\"id\":2249},{\"id\":2250},{\"id\":2251},{\"id\":2252},{\"id\":2253},{\"id\":2254},{\"id\":2255},{\"id\":2256},{\"id\":2257},{\"id\":2258},{\"id\":2259},{\"id\":2260},{\"id\":2261},{\"id\":2262},{\"id\":2263},{\"id\":2264},{\"id\":2265},{\"id\":2266},{\"id\":2267},{\"id\":2268},{\"id\":2269},{\"id\":2270},{\"id\":2271},{\"id\":2272},{\"id\":2273},{\"id\":2274},{\"id\":2275},{\"id\":2276},{\"id\":2277},{\"id\":2278},{\"id\":2279},{\"id\":2280},{\"id\":2281},{\"id\":2282},{\"id\":2283},{\"id\":2284},{\"id\":2285},{\"id\":2286},{\"id\":2287},{\"id\":2288},{\"id\":2289},{\"id\":2290},{\"id\":2291},{\"id\":2292},{\"id\":2293},{\"id\":2294},{\"id\":2295},{\"id\":2296},{\"id\":2297},{\"id\":2298},{\"id\":2299},{\"id\":2300},{\"id\":2301},{\"id\":2302},{\"id\":2303},{\"id\":2304},{\"id\":2305},{\"id\":2306},{\"id\":2307},{\"id\":2308},{\"id\":2309},{\"id\":2310},{\"id\":2311},{\"id\":2312},{\"id\":2313},{\"id\":2314},{\"id\":2315},{\"id\":2316},{\"id\":2317},{\"id\":2318},{\"id\":2319},{\"id\":2320},{\"id\":2321},{\"id\":2322},{\"id\":2323},{\"id\":2324},{\"id\":2325},{\"id\":2326},{\"id\":2327},{\"id\":2328},{\"id\":2329},{\"id\":2330},{\"id\":2331},{\"id\":2332},{\"id\":2333},{\"id\":2334},{\"id\":2335},{\"id\":2336},{\"id\":2337},{\"id\":2338},{\"id\":2339},{\"id\":2340},{\"id\":2341},{\"id\":2342},{\"id\":2343},{\"id\":2344},{\"id\":2345},{\"id\":2346},{\"id\":2347},{\"id\":2348},{\"id\":2349},{\"id\":2350},{\"id\":2351},{\"id\":2352},{\"id\":2353},{\"id\":2354},{\"id\":2355},{\"id\":2356},{\"id\":2357},{\"id\":2358},{\"id\":2359},{\"id\":2360},{\"id\":2361},{\"id\":2362},{\"id\":2363},{\"id\":2364},{\"id\":2365},{\"id\":2366},{\"id\":2367},{\"id\":2368},{\"id\":2369},{\"id\":2370},{\"id\":2371},{\"id\":2372},{\"id\":2373},{\"id\":2374},{\"id\":2375},{\"id\":2376},{\"id\":2377},{\"id\":2378},{\"id\":2379},{\"id\":2380},{\"id\":2381},{\"id\":2382},{\"id\":2383},{\"id\":2384},{\"id\":2385},{\"id\":2386},{\"id\":2387},{\"id\":2388},{\"id\":2389},{\"id\":2390},{\"id\":2391},{\"id\":2392},{\"id\":2393},{\"id\":2394},{\"id\":2395},{\"id\":2396},{\"id\":2397},{\"id\":2398},{\"id\":2399},{\"id\":2400},{\"id\":2401},{\"id\":2402},{\"id\":2403},{\"id\":2404},{\"id\":2405},{\"id\":2406},{\"id\":2407},{\"id\":2408},{\"id\":2409},{\"id\":2410},{\"id\":2411},{\"id\":2412},{\"id\":2413},{\"id\":2414},{\"id\":2415},{\"id\":2416},{\"id\":2417},{\"id\":2418},{\"id\":2419},{\"id\":2420},{\"id\":2421},{\"id\":2422},{\"id\":2423},{\"id\":2424},{\"id\":2425},{\"id\":2426},{\"id\":2427},{\"id\":2428},{\"id\":2429},{\"id\":2430},{\"id\":2431},{\"id\":2432},{\"id\":2433},{\"id\":2434},{\"id\":2435},{\"id\":2436},{\"id\":2437},{\"id\":2438},{\"id\":2439},{\"id\":2440},{\"id\":2441},{\"id\":2442},{\"id\":2443},{\"id\":2444},{\"id\":2445},{\"id\":2446},{\"id\":2447},{\"id\":2448},{\"id\":2449},{\"id\":2450},{\"id\":2451},{\"id\":2452},{\"id\":2453},{\"id\":2454},{\"id\":2455},{\"id\":2456},{\"id\":2457},{\"id\":2458},{\"id\":2459},{\"id\":2460},{\"id\":2461},{\"id\":2462},{\"id\":2463},{\"id\":2464},{\"id\":2465},{\"id\":2466},{\"id\":2467},{\"id\":2468},{\"id\":2469},{\"id\":2470},{\"id\":2471},{\"id\":2472},{\"id\":2473},{\"id\":2474},{\"id\":2475},{\"id\":2476},{\"id\":2477},{\"id\":2478},{\"id\":2479},{\"id\":2480},{\"id\":2481},{\"id\":2482},{\"id\":2483},{\"id\":2484},{\"id\":2485},{\"id\":2486},{\"id\":2487},{\"id\":2488},{\"id\":2489},{\"id\":2490},{\"id\":2491},{\"id\":2492},{\"id\":2493},{\"id\":2494},{\"id\":2495},{\"id\":2496},{\"id\":2497},{\"id\":2498},{\"id\":2499},{\"id\":2500},{\"id\":2501},{\"id\":2502},{\"id\":2503},{\"id\":2504},{\"id\":2505},{\"id\":2506},{\"id\":2507},{\"id\":2508},{\"id\":2509},{\"id\":2510},{\"id\":2511},{\"id\":2512},{\"id\":2513},{\"id\":2514},{\"id\":2515},{\"id\":2516},{\"id\":2517},{\"id\":2518},{\"id\":2519},{\"id\":2520},{\"id\":2521},{\"id\":2522},{\"id\":2523},{\"id\":2524},{\"id\":2525},{\"id\":2526},{\"id\":2527},{\"id\":2528},{\"id\":2529},{\"id\":2530},{\"id\":2531},{\"id\":2532},{\"id\":2533},{\"id\":2534},{\"id\":2535},{\"id\":2536},{\"id\":2537},{\"id\":2538},{\"id\":2539},{\"id\":2540},{\"id\":2541},{\"id\":2542},{\"id\":2543},{\"id\":2544},{\"id\":2545},{\"id\":2546},{\"id\":2547},{\"id\":2548},{\"id\":2549},{\"id\":2550},{\"id\":2551},{\"id\":2552},{\"id\":2553},{\"id\":2554},{\"id\":2555},{\"id\":2556},{\"id\":2557},{\"id\":2558},{\"id\":2559},{\"id\":2560},{\"id\":2561},{\"id\":2562},{\"id\":2563},{\"id\":2564},{\"id\":2565},{\"id\":2566},{\"id\":2567},{\"id\":2568},{\"id\":2569},{\"id\":2570},{\"id\":2571},{\"id\":2572},{\"id\":2573},{\"id\":2574},{\"id\":2575},{\"id\":2576},{\"id\":2577},{\"id\":2578},{\"id\":2579},{\"id\":2580},{\"id\":2581},{\"id\":2582},{\"id\":2583},{\"id\":2584},{\"id\":2585},{\"id\":2586},{\"id\":2587},{\"id\":2588},{\"id\":2589},{\"id\":2590},{\"id\":2591},{\"id\":2592},{\"nodeType\":3,\"id\":2596,\"textContent\":\" // Track clicks on page $(document).ready(function() { $(\\\".control\\\").click(function(e) { e.stopImmediatePropagation(); clicks = clicks + 1; console.log(clicks); }); }); $('.userid').html(sid); // console.log(\\\"start of clicked array: \\\"+clicked); // console.log(\\\"start of hovered string: \\\"+hovered); //set correct answers for each question var triangular_answers = { \\\"acme.starttime.1\\\" : [\\\"F\\\"], \\\"acme.starts.1\\\" : [\\\"K\\\"], \\\"acme.meets.1\\\" : [\\\"F\\\"], \\\"acme.endtime.1\\\" : [\\\"H\\\"], \\\"acme.midpoint.1\\\" : [\\\"O\\\"], \\\"acme.starttime.2\\\" : [\\\"F\\\"], \\\"acme.starts.2\\\" : [\\\"K\\\"], \\\"acme.meets.2\\\" : [\\\"F\\\"], \\\"acme.endtime.2\\\" : [\\\"H\\\"], \\\"acme.midpoint.2\\\" : [\\\"A\\\"], \\\"bigset.duration.1\\\" : [\\\"E\\\",\\\"G\\\"], \\\"bigset.duration+starts.1\\\" : [\\\"X\\\",\\\"O\\\"], \\\"bigset.duration+contained.1\\\" : [\\\"G\\\"], \\\"bigset.starttime+before+endtime+during.1\\\": [\\\"I\\\"], \\\"bigset.ends.1\\\" : [\\\"E\\\"], \\\"bigset.duration.2\\\" : [\\\"E\\\",\\\"G\\\"], \\\"bigset.duration+starts.2\\\" : [\\\"X\\\",\\\"O\\\"], \\\"bigset.duration+contained.2\\\" : [\\\"G\\\"], \\\"bigset.starttime+before+endtime+during.2\\\":[\\\"I\\\"], \\\"bigset.ends.2\\\" : [\\\"E\\\"], \\\"bigset.starttime.1\\\" : [\\\"M\\\",\\\"L\\\"], \\\"bigset.starts.1\\\" : [\\\"G\\\"], \\\"bigset.meets.1\\\" : [\\\"E\\\",\\\"F\\\"], \\\"bigset.endtime.1\\\" : [\\\"X\\\"], \\\"bigset.midpoint.1\\\" : [\\\"K\\\",\\\"X\\\"], \\\"bigset.starttime.2\\\" : [\\\"M\\\",\\\"L\\\"], \\\"bigset.starts.2\\\" : [\\\"G\\\"], \\\"bigset.meets.2\\\" : [\\\"E\\\",\\\"F\\\"], \\\"bigset.endtime.2\\\" : [\\\"X\\\"], \\\"bigset.midpoint.2\\\" : [\\\"K\\\",\\\"X\\\"] } var orthogonal_answers = { \\\"acme.starttime.1\\\" : [\\\"A\\\"], \\\"acme.starts.1\\\" : [\\\"E\\\"], \\\"acme.meets.1\\\" : [\\\"Z\\\"], \\\"acme.endtime.1\\\" : [\\\"U\\\"], \\\"acme.midpoint.1\\\" : [\\\"U\\\"], \\\"acme.starttime.2\\\" : [\\\"0\\\"], \\\"acme.starts.2\\\" : [\\\"0\\\"], \\\"acme.meets.2\\\" : [\\\"0\\\"], \\\"acme.endtime.2\\\" : [\\\"0\\\"], \\\"acme.midpoint.2\\\" : [\\\"0\\\"], \\\"bigset.duration.1\\\" : [\\\"E\\\",\\\"G\\\"], \\\"bigset.duration+starts.1\\\" : [\\\"F\\\",\\\"B\\\"], \\\"bigset.duration+contained.1\\\" : [\\\"E\\\"], \\\"bigset.starttime+before+endtime+during.1\\\": [\\\"I\\\"], \\\"bigset.ends.1\\\" : [\\\"X\\\"], \\\"bigset.duration.2\\\" : [\\\"E\\\",\\\"G\\\"], \\\"bigset.duration+starts.2\\\" : [\\\"F\\\",\\\"B\\\"], \\\"bigset.duration+contained.2\\\" : [\\\"E\\\"], \\\"bigset.starttime+before+endtime+during.2\\\":[\\\"I\\\"], \\\"bigset.ends.2\\\" : [\\\"X\\\"], \\\"bigset.starttime.1\\\" : [\\\"F\\\",\\\"B\\\"], \\\"bigset.starts.1\\\" : [\\\"B\\\"], \\\"bigset.meets.1\\\" : [\\\"F\\\",\\\"X\\\"], \\\"bigset.endtime.1\\\" : [\\\"B\\\"], \\\"bigset.midpoint.1\\\" : [\\\"E\\\",\\\"F\\\"], \\\"bigset.starttime.2\\\" : [\\\"F\\\",\\\"B\\\"], \\\"bigset.starts.2\\\" : [\\\"B\\\"], \\\"bigset.meets.2\\\" : [\\\"F\\\",\\\"X\\\"], \\\"bigset.endtime.2\\\" : [\\\"B\\\"], \\\"bigset.midpoint.2\\\" : [\\\"E\\\",\\\"F\\\"] } //display the question and answer buttons based on input values from jsPsych document.getElementById(scenario+\\\".\\\"+question).style.display = \\\"block\\\"; if (question == \\\"strategy\\\") {document.getElementById(\\\"strategyButton\\\").style.display = \\\"block\\\";} else {document.getElementById(\\\"testingButton\\\").style.display = \\\"block\\\";} //---------SET PROPERTIES OF THE GRAPH -------------// // set the dimensions and margins of the graph var margin = {top: 25, right: 30, bottom: 90, left: 100}, width = 800, height = 800; var intersects = false; //default value for intersects scaffold var xAxisTitle, yAxisTitle; var datafile =\\\"\\\"; // SET AXIS VALUES if (axis == 1){ axis = \\\"Orthogonal-XInside-YFull\\\"; } else if (axis == 2){ axis = \\\"Orthogonal-XInside-YPartial\\\"; } else if (axis ==3){ axis = \\\"Triangular-XInside-YInside\\\"; } else if (axis ==4){ axis = \\\"Orthogonal-XInside-YInside\\\"; } else if (axis ==5){ axis = \\\"Orthogonal-XFull-YFull\\\"; } // SET EXPLICIT SCAFFOLD FEATURES if (explicit ==2 && axis != \\\"diagonal\\\"){ scaffold = 2; intersects = false; } else if (explicit == 2 && axis == \\\"diagonal\\\"){ scaffold = 2; intersects = false; } //TODO: not sure if above two lines are still valid since leaders are now generated on the fly else if (explicit == 3){ $('#hint-interactive').css(\\\"display\\\",\\\"block\\\"); //display textimage scaffold intersects = true; } //SET DATA FILE FOR IMPLICIT SCAFFOLD if (impasse == 1){ datafile = \\\"../views/src/data/acme_nonimpasse.csv\\\"; } else if (impasse == 2){ datafile = \\\"../views/src/data/acme_impasse.csv\\\"; } //OVERRIDE DATA FILE FOR NON-SCAFFOLD QUESTIONS if (q > 5) { //override data file if q# is greater than 5 datafile = \\\"../views/src/data/bigset.csv\\\"; console.log(\\\"override data file\\\"); $('#orthogonal-image').css(\\\"display\\\",\\\"none\\\"); //display textimage scaffold $('#diagonal-image').css(\\\"display\\\",\\\"none\\\"); //display textimage scaffold $('#hint-interactive').css(\\\"display\\\",\\\"none\\\"); //display textimage scaffold intersects = false; } // //---------CREATE THE SVG ------------------------// var svg = d3.select(\\\".d3container\\\").append(\\\"svg\\\") .attr(\\\"width\\\", width + margin.left + margin.right) .attr(\\\"height\\\", height + margin.top + margin.bottom) .append(\\\"g\\\") .attr(\\\"transform\\\", \\\"translate(\\\" + margin.left + \\\",\\\" + margin.top + \\\")\\\"); //---------DRAW THE GRAPH ------------------------// xAxisTitle = \\\"START & END TIME (time of day)\\\"; yAxisTitle = \\\"DURATION (in hours)\\\"; drawTriangleModel(datafile,intersects,axis,scaffold,q); \"},{\"id\":2593},{\"id\":2594},{\"nodeType\":3,\"id\":2597,\"textContent\":\" //MOUSE LOGGING SCRIPT var mouseLog = [] var xwidth = $(document).width(); var xheight = $(document).width(); mouseLog.push(\\\"{x:\\\"+xwidth+\\\",y:\\\"+xheight+\\\",t:\\\"+\\\"0};\\\") document.onmousemove = function(e){ var pageCoords = \\\"{x:\\\" + e.pageX + \\\",y:\\\"+ e.pageY +\\\",t:\\\"+ Date.now()+ \\\"};\\\" ; mouseLog.push(pageCoords); // console.log(pageCoords); }; \"},{\"id\":2595}],[],[],[]]}"
    },
    {
      "sequence": 2,
      "data": "{\"f\":\"applyChanged\",\"args\":[[],[{\"nodeType\":1,\"id\":2598,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-text-preamble\",\"class\":\"jspsych-survey-text-preamble\"},\"parentNode\":{\"id\":55}},{\"nodeType\":1,\"id\":2599,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-text-0\",\"class\":\"jspsych-survey-text-question\"},\"previousSibling\":{\"id\":2598},\"parentNode\":{\"id\":55}},{\"nodeType\":1,\"id\":2600,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-text-1\",\"class\":\"jspsych-survey-text-question\"},\"previousSibling\":{\"id\":2599},\"parentNode\":{\"id\":55}},{\"nodeType\":1,\"id\":2601,\"tagName\":\"BUTTON\",\"attributes\":{\"id\":\"jspsych-survey-text-next\",\"class\":\"jspsych-btn jspsych-survey-text\"},\"previousSibling\":{\"id\":2600},\"parentNode\":{\"id\":55}},{\"nodeType\":1,\"id\":2602,\"tagName\":\"P\",\"attributes\":{\"class\":\"jspsych-survey-text\"},\"parentNode\":{\"id\":2599}},{\"nodeType\":1,\"id\":2603,\"tagName\":\"TEXTAREA\",\"attributes\":{\"name\":\"#jspsych-survey-text-response-0\",\"cols\":\"40\",\"rows\":\"1\"},\"previousSibling\":{\"id\":2602},\"parentNode\":{\"id\":2599}},{\"nodeType\":3,\"id\":2604,\"textContent\":\"What is your age?\",\"parentNode\":{\"id\":2602}},{\"nodeType\":1,\"id\":2605,\"tagName\":\"P\",\"attributes\":{\"class\":\"jspsych-survey-text\"},\"parentNode\":{\"id\":2600}},{\"nodeType\":1,\"id\":2606,\"tagName\":\"TEXTAREA\",\"attributes\":{\"name\":\"#jspsych-survey-text-response-1\",\"cols\":\"40\",\"rows\":\"1\"},\"previousSibling\":{\"id\":2605},\"parentNode\":{\"id\":2600}},{\"nodeType\":3,\"id\":2607,\"textContent\":\"In what country were you born?\",\"parentNode\":{\"id\":2605}},{\"nodeType\":3,\"id\":2608,\"textContent\":\"Submit Answers\",\"parentNode\":{\"id\":2601}}],[],[]]}"
    },
    {
      "sequence": 3,
      "data": "{\"f\":\"applyChanged\",\"args\":[[{\"id\":2598},{\"id\":2599},{\"id\":2602},{\"id\":2604},{\"id\":2603},{\"id\":2600},{\"id\":2605},{\"id\":2607},{\"id\":2606},{\"id\":2601},{\"id\":2608}],[],[],[]]}"
    },
    {
      "sequence": 4,
      "data": "{\"f\":\"applyChanged\",\"args\":[[],[{\"nodeType\":1,\"id\":2609,\"tagName\":\"FORM\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-form\"},\"parentNode\":{\"id\":55}},{\"nodeType\":1,\"id\":2610,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-preamble\",\"class\":\"jspsych-survey-multi-choice-preamble\"},\"parentNode\":{\"id\":2609}},{\"nodeType\":1,\"id\":2611,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-0\",\"class\":\"jspsych-survey-multi-choice-question jspsych-survey-multi-choice-horizontal\"},\"previousSibling\":{\"id\":2610},\"parentNode\":{\"id\":2609}},{\"nodeType\":1,\"id\":2612,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-1\",\"class\":\"jspsych-survey-multi-choice-question jspsych-survey-multi-choice-horizontal\"},\"previousSibling\":{\"id\":2611},\"parentNode\":{\"id\":2609}},{\"nodeType\":1,\"id\":2613,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-2\",\"class\":\"jspsych-survey-multi-choice-question jspsych-survey-multi-choice-horizontal\"},\"previousSibling\":{\"id\":2612},\"parentNode\":{\"id\":2609}},{\"nodeType\":1,\"id\":2614,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-3\",\"class\":\"jspsych-survey-multi-choice-question jspsych-survey-multi-choice-horizontal\"},\"previousSibling\":{\"id\":2613},\"parentNode\":{\"id\":2609}},{\"nodeType\":1,\"id\":2615,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"submit\",\"id\":\"jspsych-survey-multi-choice-next\",\"class\":\"jspsych-survey-multi-choice jspsych-btn\",\"value\":\"Submit Answers\"},\"previousSibling\":{\"id\":2614},\"parentNode\":{\"id\":2609}},{\"nodeType\":1,\"id\":2616,\"tagName\":\"P\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text survey-multi-choice\"},\"parentNode\":{\"id\":2611}},{\"nodeType\":1,\"id\":2617,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-0-0\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2616},\"parentNode\":{\"id\":2611}},{\"nodeType\":1,\"id\":2618,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-0-1\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2617},\"parentNode\":{\"id\":2611}},{\"nodeType\":1,\"id\":2619,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-0-2\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2618},\"parentNode\":{\"id\":2611}},{\"nodeType\":1,\"id\":2620,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-0-3\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2619},\"parentNode\":{\"id\":2611}},{\"nodeType\":3,\"id\":2621,\"textContent\":\"What is your first language?\",\"parentNode\":{\"id\":2616}},{\"nodeType\":1,\"id\":2622,\"tagName\":\"SPAN\",\"attributes\":{\"class\":\"required\"},\"previousSibling\":{\"id\":2621},\"parentNode\":{\"id\":2616}},{\"nodeType\":1,\"id\":2623,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2617}},{\"nodeType\":1,\"id\":2624,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-0\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2623}},{\"nodeType\":3,\"id\":2625,\"textContent\":\"English\",\"previousSibling\":{\"id\":2624},\"parentNode\":{\"id\":2623}},{\"nodeType\":1,\"id\":2626,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2618}},{\"nodeType\":1,\"id\":2627,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-0\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2626}},{\"nodeType\":3,\"id\":2628,\"textContent\":\"Spanish\",\"previousSibling\":{\"id\":2627},\"parentNode\":{\"id\":2626}},{\"nodeType\":1,\"id\":2629,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2619}},{\"nodeType\":1,\"id\":2630,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-0\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2629}},{\"nodeType\":3,\"id\":2631,\"textContent\":\"Mandarin or Cantonese\",\"previousSibling\":{\"id\":2630},\"parentNode\":{\"id\":2629}},{\"nodeType\":1,\"id\":2632,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2620}},{\"nodeType\":1,\"id\":2633,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-0\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2632}},{\"nodeType\":3,\"id\":2634,\"textContent\":\"Other\",\"previousSibling\":{\"id\":2633},\"parentNode\":{\"id\":2632}},{\"nodeType\":3,\"id\":2635,\"textContent\":\"*\",\"parentNode\":{\"id\":2622}},{\"nodeType\":1,\"id\":2636,\"tagName\":\"P\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text survey-multi-choice\"},\"parentNode\":{\"id\":2612}},{\"nodeType\":1,\"id\":2637,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-1-0\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2636},\"parentNode\":{\"id\":2612}},{\"nodeType\":1,\"id\":2638,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-1-1\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2637},\"parentNode\":{\"id\":2612}},{\"nodeType\":1,\"id\":2639,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-1-2\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2638},\"parentNode\":{\"id\":2612}},{\"nodeType\":1,\"id\":2640,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-1-3\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2639},\"parentNode\":{\"id\":2612}},{\"nodeType\":1,\"id\":2641,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-1-4\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2640},\"parentNode\":{\"id\":2612}},{\"nodeType\":1,\"id\":2642,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-1-5\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2641},\"parentNode\":{\"id\":2612}},{\"nodeType\":1,\"id\":2643,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-1-6\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2642},\"parentNode\":{\"id\":2612}},{\"nodeType\":3,\"id\":2644,\"textContent\":\"What is your year in school?\",\"parentNode\":{\"id\":2636}},{\"nodeType\":1,\"id\":2645,\"tagName\":\"SPAN\",\"attributes\":{\"class\":\"required\"},\"previousSibling\":{\"id\":2644},\"parentNode\":{\"id\":2636}},{\"nodeType\":1,\"id\":2646,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2637}},{\"nodeType\":1,\"id\":2647,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-1\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2646}},{\"nodeType\":3,\"id\":2648,\"textContent\":\"First\",\"previousSibling\":{\"id\":2647},\"parentNode\":{\"id\":2646}},{\"nodeType\":1,\"id\":2649,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2638}},{\"nodeType\":1,\"id\":2650,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-1\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2649}},{\"nodeType\":3,\"id\":2651,\"textContent\":\"Second\",\"previousSibling\":{\"id\":2650},\"parentNode\":{\"id\":2649}},{\"nodeType\":1,\"id\":2652,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2639}},{\"nodeType\":1,\"id\":2653,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-1\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2652}},{\"nodeType\":3,\"id\":2654,\"textContent\":\"Third\",\"previousSibling\":{\"id\":2653},\"parentNode\":{\"id\":2652}},{\"nodeType\":1,\"id\":2655,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2640}},{\"nodeType\":1,\"id\":2656,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-1\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2655}},{\"nodeType\":3,\"id\":2657,\"textContent\":\"Fourth\",\"previousSibling\":{\"id\":2656},\"parentNode\":{\"id\":2655}},{\"nodeType\":1,\"id\":2658,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2641}},{\"nodeType\":1,\"id\":2659,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-1\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2658}},{\"nodeType\":3,\"id\":2660,\"textContent\":\"Fifth\",\"previousSibling\":{\"id\":2659},\"parentNode\":{\"id\":2658}},{\"nodeType\":1,\"id\":2661,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2642}},{\"nodeType\":1,\"id\":2662,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-1\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2661}},{\"nodeType\":3,\"id\":2663,\"textContent\":\"Graduate\",\"previousSibling\":{\"id\":2662},\"parentNode\":{\"id\":2661}},{\"nodeType\":1,\"id\":2664,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2643}},{\"nodeType\":1,\"id\":2665,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-1\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2664}},{\"nodeType\":3,\"id\":2666,\"textContent\":\"Other\",\"previousSibling\":{\"id\":2665},\"parentNode\":{\"id\":2664}},{\"nodeType\":3,\"id\":2667,\"textContent\":\"*\",\"parentNode\":{\"id\":2645}},{\"nodeType\":1,\"id\":2668,\"tagName\":\"P\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text survey-multi-choice\"},\"parentNode\":{\"id\":2613}},{\"nodeType\":1,\"id\":2669,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-2-0\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2668},\"parentNode\":{\"id\":2613}},{\"nodeType\":1,\"id\":2670,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-2-1\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2669},\"parentNode\":{\"id\":2613}},{\"nodeType\":1,\"id\":2671,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-2-2\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2670},\"parentNode\":{\"id\":2613}},{\"nodeType\":1,\"id\":2672,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-2-3\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2671},\"parentNode\":{\"id\":2613}},{\"nodeType\":1,\"id\":2673,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-2-4\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2672},\"parentNode\":{\"id\":2613}},{\"nodeType\":1,\"id\":2674,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-2-5\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2673},\"parentNode\":{\"id\":2613}},{\"nodeType\":1,\"id\":2675,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-2-6\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2674},\"parentNode\":{\"id\":2613}},{\"nodeType\":3,\"id\":2676,\"textContent\":\"What is your major area of study?\",\"parentNode\":{\"id\":2668}},{\"nodeType\":1,\"id\":2677,\"tagName\":\"SPAN\",\"attributes\":{\"class\":\"required\"},\"previousSibling\":{\"id\":2676},\"parentNode\":{\"id\":2668}},{\"nodeType\":1,\"id\":2678,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2669}},{\"nodeType\":1,\"id\":2679,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-2\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2678}},{\"nodeType\":3,\"id\":2680,\"textContent\":\"Math or Computer Sciences\",\"previousSibling\":{\"id\":2679},\"parentNode\":{\"id\":2678}},{\"nodeType\":1,\"id\":2681,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2670}},{\"nodeType\":1,\"id\":2682,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-2\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2681}},{\"nodeType\":3,\"id\":2683,\"textContent\":\"Social Sciences (incl. CogSci)\",\"previousSibling\":{\"id\":2682},\"parentNode\":{\"id\":2681}},{\"nodeType\":1,\"id\":2684,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2671}},{\"nodeType\":1,\"id\":2685,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-2\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2684}},{\"nodeType\":3,\"id\":2686,\"textContent\":\"Biomedical & Health Sciences\",\"previousSibling\":{\"id\":2685},\"parentNode\":{\"id\":2684}},{\"nodeType\":1,\"id\":2687,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2672}},{\"nodeType\":1,\"id\":2688,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-2\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2687}},{\"nodeType\":3,\"id\":2689,\"textContent\":\"Natural Sciences\",\"previousSibling\":{\"id\":2688},\"parentNode\":{\"id\":2687}},{\"nodeType\":1,\"id\":2690,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2673}},{\"nodeType\":1,\"id\":2691,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-2\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2690}},{\"nodeType\":3,\"id\":2692,\"textContent\":\"Engineering\",\"previousSibling\":{\"id\":2691},\"parentNode\":{\"id\":2690}},{\"nodeType\":1,\"id\":2693,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2674}},{\"nodeType\":1,\"id\":2694,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-2\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2693}},{\"nodeType\":3,\"id\":2695,\"textContent\":\"Humanities\",\"previousSibling\":{\"id\":2694},\"parentNode\":{\"id\":2693}},{\"nodeType\":1,\"id\":2696,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2675}},{\"nodeType\":1,\"id\":2697,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-2\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2696}},{\"nodeType\":3,\"id\":2698,\"textContent\":\"Fine Arts\",\"previousSibling\":{\"id\":2697},\"parentNode\":{\"id\":2696}},{\"nodeType\":3,\"id\":2699,\"textContent\":\"*\",\"parentNode\":{\"id\":2677}},{\"nodeType\":1,\"id\":2700,\"tagName\":\"P\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text survey-multi-choice\"},\"parentNode\":{\"id\":2614}},{\"nodeType\":1,\"id\":2701,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-3-0\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2700},\"parentNode\":{\"id\":2614}},{\"nodeType\":1,\"id\":2702,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-3-1\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2701},\"parentNode\":{\"id\":2614}},{\"nodeType\":1,\"id\":2703,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-3-2\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2702},\"parentNode\":{\"id\":2614}},{\"nodeType\":3,\"id\":2704,\"textContent\":\"What is your gender?\",\"parentNode\":{\"id\":2700}},{\"nodeType\":1,\"id\":2705,\"tagName\":\"SPAN\",\"attributes\":{\"class\":\"required\"},\"previousSibling\":{\"id\":2704},\"parentNode\":{\"id\":2700}},{\"nodeType\":1,\"id\":2706,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2701}},{\"nodeType\":1,\"id\":2707,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-3\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2706}},{\"nodeType\":3,\"id\":2708,\"textContent\":\"Male\",\"previousSibling\":{\"id\":2707},\"parentNode\":{\"id\":2706}},{\"nodeType\":1,\"id\":2709,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2702}},{\"nodeType\":1,\"id\":2710,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-3\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2709}},{\"nodeType\":3,\"id\":2711,\"textContent\":\"Female\",\"previousSibling\":{\"id\":2710},\"parentNode\":{\"id\":2709}},{\"nodeType\":1,\"id\":2712,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2703}},{\"nodeType\":1,\"id\":2713,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-3\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2712}},{\"nodeType\":3,\"id\":2714,\"textContent\":\"Other\",\"previousSibling\":{\"id\":2713},\"parentNode\":{\"id\":2712}},{\"nodeType\":3,\"id\":2715,\"textContent\":\"*\",\"parentNode\":{\"id\":2705}}],[],[]]}"
    },
    {
      "sequence": 5,
      "data": "{\"f\":\"applyChanged\",\"args\":[[{\"id\":2609},{\"id\":2610},{\"id\":2611},{\"id\":2616},{\"id\":2621},{\"id\":2622},{\"id\":2635},{\"id\":2617},{\"id\":2623},{\"id\":2624},{\"id\":2625},{\"id\":2618},{\"id\":2626},{\"id\":2627},{\"id\":2628},{\"id\":2619},{\"id\":2629},{\"id\":2630},{\"id\":2631},{\"id\":2620},{\"id\":2632},{\"id\":2633},{\"id\":2634},{\"id\":2612},{\"id\":2636},{\"id\":2644},{\"id\":2645},{\"id\":2667},{\"id\":2637},{\"id\":2646},{\"id\":2647},{\"id\":2648},{\"id\":2638},{\"id\":2649},{\"id\":2650},{\"id\":2651},{\"id\":2639},{\"id\":2652},{\"id\":2653},{\"id\":2654},{\"id\":2640},{\"id\":2655},{\"id\":2656},{\"id\":2657},{\"id\":2641},{\"id\":2658},{\"id\":2659},{\"id\":2660},{\"id\":2642},{\"id\":2661},{\"id\":2662},{\"id\":2663},{\"id\":2643},{\"id\":2664},{\"id\":2665},{\"id\":2666},{\"id\":2613},{\"id\":2668},{\"id\":2676},{\"id\":2677},{\"id\":2699},{\"id\":2669},{\"id\":2678},{\"id\":2679},{\"id\":2680},{\"id\":2670},{\"id\":2681},{\"id\":2682},{\"id\":2683},{\"id\":2671},{\"id\":2684},{\"id\":2685},{\"id\":2686},{\"id\":2672},{\"id\":2687},{\"id\":2688},{\"id\":2689},{\"id\":2673},{\"id\":2690},{\"id\":2691},{\"id\":2692},{\"id\":2674},{\"id\":2693},{\"id\":2694},{\"id\":2695},{\"id\":2675},{\"id\":2696},{\"id\":2697},{\"id\":2698},{\"id\":2614},{\"id\":2700},{\"id\":2704},{\"id\":2705},{\"id\":2715},{\"id\":2701},{\"id\":2706},{\"id\":2707},{\"id\":2708},{\"id\":2702},{\"id\":2709},{\"id\":2710},{\"id\":2711},{\"id\":2703},{\"id\":2712},{\"id\":2713},{\"id\":2714},{\"id\":2615}],[],[],[]]}"
    },
    {
      "sequence": 6,
      "data": "{\"f\":\"applyChanged\",\"args\":[[],[{\"nodeType\":1,\"id\":2716,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"masterdiv\"},\"parentNode\":{\"id\":55}},{\"nodeType\":3,\"id\":2717,\"textContent\":\" \",\"previousSibling\":{\"id\":2716},\"parentNode\":{\"id\":55}},{\"nodeType\":3,\"id\":2718,\"textContent\":\" \",\"parentNode\":{\"id\":2716}},{\"nodeType\":1,\"id\":2719,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"top\"},\"previousSibling\":{\"id\":2718},\"parentNode\":{\"id\":2716}},{\"nodeType\":3,\"id\":2720,\"textContent\":\" \",\"previousSibling\":{\"id\":2719},\"parentNode\":{\"id\":2716}},{\"nodeType\":1,\"id\":2721,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"instructions\"},\"previousSibling\":{\"id\":2720},\"parentNode\":{\"id\":2716}},{\"nodeType\":3,\"id\":2722,\"textContent\":\" \",\"previousSibling\":{\"id\":2721},\"parentNode\":{\"id\":2716}},{\"nodeType\":1,\"id\":2723,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bottom\"},\"previousSibling\":{\"id\":2722},\"parentNode\":{\"id\":2716}},{\"nodeType\":3,\"id\":2724,\"textContent\":\" \",\"previousSibling\":{\"id\":2723},\"parentNode\":{\"id\":2716}},{\"nodeType\":3,\"id\":2725,\"textContent\":\" \",\"parentNode\":{\"id\":2719}},{\"nodeType\":1,\"id\":2726,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bcent\"},\"previousSibling\":{\"id\":2725},\"parentNode\":{\"id\":2719}},{\"nodeType\":3,\"id\":2727,\"textContent\":\" \",\"previousSibling\":{\"id\":2726},\"parentNode\":{\"id\":2719}},{\"nodeType\":3,\"id\":2728,\"textContent\":\" \",\"parentNode\":{\"id\":2726}},{\"nodeType\":1,\"id\":2729,\"tagName\":\"H3\",\"attributes\":{},\"previousSibling\":{\"id\":2728},\"parentNode\":{\"id\":2726}},{\"nodeType\":3,\"id\":2730,\"textContent\":\" \",\"previousSibling\":{\"id\":2729},\"parentNode\":{\"id\":2726}},{\"nodeType\":3,\"id\":2731,\"textContent\":\"DEBRIEFING\",\"parentNode\":{\"id\":2729}},{\"nodeType\":3,\"id\":2732,\"textContent\":\" \",\"parentNode\":{\"id\":2721}},{\"nodeType\":1,\"id\":2733,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"vcent\"},\"previousSibling\":{\"id\":2732},\"parentNode\":{\"id\":2721}},{\"nodeType\":3,\"id\":2734,\"textContent\":\" \",\"previousSibling\":{\"id\":2733},\"parentNode\":{\"id\":2721}},{\"nodeType\":3,\"id\":2735,\"textContent\":\" \",\"parentNode\":{\"id\":2733}},{\"nodeType\":1,\"id\":2736,\"tagName\":\"P\",\"attributes\":{\"style\":\"font-style:italic\"},\"previousSibling\":{\"id\":2735},\"parentNode\":{\"id\":2733}},{\"nodeType\":1,\"id\":2737,\"tagName\":\"P\",\"attributes\":{},\"previousSibling\":{\"id\":2736},\"parentNode\":{\"id\":2733}},{\"nodeType\":3,\"id\":2738,\"textContent\":\" \",\"previousSibling\":{\"id\":2737},\"parentNode\":{\"id\":2733}},{\"nodeType\":1,\"id\":2739,\"tagName\":\"P\",\"attributes\":{},\"previousSibling\":{\"id\":2738},\"parentNode\":{\"id\":2733}},{\"nodeType\":3,\"id\":2740,\"textContent\":\" \",\"previousSibling\":{\"id\":2739},\"parentNode\":{\"id\":2733}},{\"nodeType\":1,\"id\":2741,\"tagName\":\"P\",\"attributes\":{},\"previousSibling\":{\"id\":2740},\"parentNode\":{\"id\":2733}},{\"nodeType\":3,\"id\":2742,\"textContent\":\" \",\"previousSibling\":{\"id\":2741},\"parentNode\":{\"id\":2733}},{\"nodeType\":1,\"id\":2743,\"tagName\":\"P\",\"attributes\":{\"style\":\"font-style:bold;\"},\"previousSibling\":{\"id\":2742},\"parentNode\":{\"id\":2733}},{\"nodeType\":3,\"id\":2744,\"textContent\":\" \",\"previousSibling\":{\"id\":2743},\"parentNode\":{\"id\":2733}},{\"nodeType\":1,\"id\":2745,\"tagName\":\"P\",\"attributes\":{\"style\":\"font-style:italic;\"},\"previousSibling\":{\"id\":2744},\"parentNode\":{\"id\":2733}},{\"nodeType\":3,\"id\":2746,\"textContent\":\" \",\"previousSibling\":{\"id\":2745},\"parentNode\":{\"id\":2733}},{\"nodeType\":3,\"id\":2747,\"textContent\":\"Thank you very much for your participation! This debriefing will tell you more about the study, what you did, and why. \",\"parentNode\":{\"id\":2736}},{\"nodeType\":3,\"id\":2748,\"textContent\":\" \",\"parentNode\":{\"id\":2737}},{\"nodeType\":1,\"id\":2749,\"tagName\":\"B\",\"attributes\":{},\"previousSibling\":{\"id\":2748},\"parentNode\":{\"id\":2737}},{\"nodeType\":3,\"id\":2750,\"textContent\":\" You have just used a series of pictures (charts, graphs and diagrams) accompanied by different types of instructions to answer a series of problem solving questions. While you were using the pictures, we measured where you clicked, scrolled and pointed with the computer mouse. We also measured the accuracy of your responses and the time it took to complete each question.\",\"previousSibling\":{\"id\":2749},\"parentNode\":{\"id\":2737}},{\"nodeType\":3,\"id\":2751,\"textContent\":\"What did you just do?\",\"parentNode\":{\"id\":2749}},{\"nodeType\":3,\"id\":2752,\"textContent\":\" \",\"parentNode\":{\"id\":2739}},{\"nodeType\":1,\"id\":2753,\"tagName\":\"B\",\"attributes\":{},\"previousSibling\":{\"id\":2752},\"parentNode\":{\"id\":2739}},{\"nodeType\":3,\"id\":2754,\"textContent\":\" Researchers of learning and cognition have long been interested in how graphic displays of information can be used to communicate, solve problems, and generate insights. As powerful as graphics may be in their communicative efficiency, they're not always immediately intuitive to understand. In short, we know a great deal more about learning with representations than we do about the learning of representations. In this project we are building upon previous research on reading and graph comprehension to explore how readers make sense of unfamiliar representations. The instructions you saw for each type of graph are known as “scaffolding techniques”, and we will compare your performance with the scaffolding techniques you saw with the performance of other participants to determine which types of instructions are most effective in helping humans to make sense of unfamiliar graphs. \",\"previousSibling\":{\"id\":2753},\"parentNode\":{\"id\":2739}},{\"nodeType\":3,\"id\":2755,\"textContent\":\"Why did we have you do it?\",\"parentNode\":{\"id\":2753}},{\"nodeType\":1,\"id\":2756,\"tagName\":\"B\",\"attributes\":{},\"parentNode\":{\"id\":2741}},{\"nodeType\":3,\"id\":2757,\"textContent\":\" We expect that you will have found some of the graphics more difficult to use than others. We also expect that with the assistance of the instructions, after solving several problems you will learn to use the difficult graphics so that you can answer the questions even more quickly than without. If you would like to receive a copy of the results of the study, or have any further questions, please contact the researchers Primary Researcher: Amy Fox : a2fox@ucsd.edu Faculty Advisor : Dr. Jim Hollan : hollan@ucsd.edu \",\"previousSibling\":{\"id\":2756},\"parentNode\":{\"id\":2741}},{\"nodeType\":3,\"id\":2758,\"textContent\":\"What do we expect to find?\",\"parentNode\":{\"id\":2756}},{\"nodeType\":3,\"id\":2759,\"textContent\":\"It is important that you do not discuss this experiment with other students who might participate after you. They must participate in the same way as you did, without any knowledge of what the experiment entails, or the reasoning behind it.\",\"parentNode\":{\"id\":2743}},{\"nodeType\":3,\"id\":2760,\"textContent\":\"Thank you for your time! We hope you enjoyed participating in this study as much as we enjoyed designing it.\",\"parentNode\":{\"id\":2745}},{\"nodeType\":3,\"id\":2761,\"textContent\":\" \",\"parentNode\":{\"id\":2723}},{\"nodeType\":1,\"id\":2762,\"tagName\":\"BUTTON\",\"attributes\":{\"class\":\"btn\",\"type\":\"button\",\"id\":\"start\"},\"previousSibling\":{\"id\":2761},\"parentNode\":{\"id\":2723}},{\"nodeType\":3,\"id\":2763,\"textContent\":\" \",\"previousSibling\":{\"id\":2762},\"parentNode\":{\"id\":2723}},{\"nodeType\":3,\"id\":2764,\"textContent\":\"FINISH\",\"parentNode\":{\"id\":2762}}],[],[]]}"
    },
    {
      "sequence": 7,
      "data": "{\"f\":\"applyChanged\",\"args\":[[{\"id\":2716},{\"id\":2718},{\"id\":2719},{\"id\":2725},{\"id\":2726},{\"id\":2728},{\"id\":2729},{\"id\":2731},{\"id\":2730},{\"id\":2727},{\"id\":2720},{\"id\":2721},{\"id\":2732},{\"id\":2733},{\"id\":2735},{\"id\":2736},{\"id\":2747},{\"id\":2737},{\"id\":2748},{\"id\":2749},{\"id\":2751},{\"id\":2750},{\"id\":2738},{\"id\":2739},{\"id\":2752},{\"id\":2753},{\"id\":2755},{\"id\":2754},{\"id\":2740},{\"id\":2741},{\"id\":2756},{\"id\":2758},{\"id\":2757},{\"id\":2742},{\"id\":2743},{\"id\":2759},{\"id\":2744},{\"id\":2745},{\"id\":2760},{\"id\":2746},{\"id\":2734},{\"id\":2722},{\"id\":2723},{\"id\":2761},{\"id\":2762},{\"id\":2764},{\"id\":2763},{\"id\":2724},{\"id\":2717}],[],[],[]]}"
    },
    {
      "sequence": 8,
      "data": "{\"f\":\"applyChanged\",\"args\":[[],[{\"nodeType\":1,\"id\":2765,\"tagName\":\"PRE\",\"attributes\":{\"id\":\"jspsych-data-display\"},\"parentNode\":{\"id\":55}},{\"nodeType\":3,\"id\":2766,\"textContent\":\"[ { \\\"rt\\\": 287648, \\\"stimulus\\\": \\\"img/phone.png\\\", \\\"key_press\\\": 13, \\\"block\\\": \\\"phone\\\", \\\"trial_type\\\": \\\"single-stim\\\", \\\"trial_index\\\": 0, \\\"time_elapsed\\\": 287655, \\\"internal_node_id\\\": \\\"0.0-0.0\\\", \\\"subject\\\": \\\"MKTF4\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"zulu\\\", \\\"condition\\\": \\\"211\\\" }, { \\\"rt\\\": 3613, \\\"url\\\": \\\"../views/src/external/consent.html\\\", \\\"block\\\": \\\"consent\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 1, \\\"time_elapsed\\\": 292598, \\\"internal_node_id\\\": \\\"0.0-1.0\\\", \\\"subject\\\": \\\"MKTF4\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"zulu\\\", \\\"condition\\\": \\\"211\\\" }, { \\\"rt\\\": 10145, \\\"responses\\\": \\\"{\\\\\\\"Q0\\\\\\\":\\\\\\\"ZULU\\\\\\\",\\\\\\\"Q1\\\\\\\":\\\\\\\"211\\\\\\\"}\\\", \\\"block\\\": \\\"codes\\\", \\\"trial_type\\\": \\\"survey-text\\\", \\\"trial_index\\\": 2, \\\"time_elapsed\\\": 303750, \\\"internal_node_id\\\": \\\"0.0-2.0\\\", \\\"subject\\\": \\\"MKTF4\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"zulu\\\", \\\"condition\\\": \\\"211\\\" }, { \\\"rt\\\": 18781, \\\"url\\\": \\\"../views/src/external/instructions_lab.html\\\", \\\"block\\\": \\\"instructions_lab\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 3, \\\"time_elapsed\\\": 323621, \\\"internal_node_id\\\": \\\"0.0-3.0\\\", \\\"subject\\\": \\\"MKTF4\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"zulu\\\", \\\"condition\\\": \\\"211\\\" }, { \\\"rt\\\": 9157, \\\"stimulus\\\": \\\"img/acme.png\\\", \\\"key_press\\\": 13, \\\"block\\\": \\\"scenario\\\", \\\"trial_type\\\": \\\"single-stim\\\", \\\"trial_index\\\": 4, \\\"time_elapsed\\\": 333780, \\\"internal_node_id\\\": \\\"0.0-4.0\\\", \\\"subject\\\": \\\"MKTF4\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"zulu\\\", \\\"condition\\\": \\\"211\\\" }, { \\\"rt\\\": 61289, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 5, \\\"time_elapsed\\\": 396436, \\\"internal_node_id\\\": \\\"0.0-5.0-0.0\\\", \\\"subject\\\": \\\"MKTF4\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"zulu\\\", \\\"condition\\\": \\\"211\\\", \\\"scenario\\\": \\\"acme\\\", \\\"question\\\": \\\"starttime\\\", \\\"q\\\": 1, \\\"clicks\\\": 1, \\\"explicit\\\": 2, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XInside-YFull\\\", \\\"correct\\\": 1, \\\"orth_correct\\\": 0, \\\"answer\\\": [ \\\"F\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"X \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"U \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-A -12 PM-A -A -12 PM-10 AM-A -A -11 AM\\\", \\\"block\\\": \\\"triangular_scaffolded\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:980,y:868,t:1528143449312};\\\", \\\"{x:1104,y:814,t:1528143449327};\\\", \\\"{x:1165,y:786,t:1528143449343};\\\", \\\"{x:1173,y:784,t:1528143449360};\\\", \\\"{x:1174,y:784,t:1528143449377};\\\", \\\"{x:1178,y:784,t:1528143449423};\\\", \\\"{x:1183,y:785,t:1528143449431};\\\", \\\"{x:1188,y:788,t:1528143449443};\\\", \\\"{x:1191,y:789,t:1528143449460};\\\", \\\"{x:1191,y:790,t:1528143449536};\\\", \\\"{x:1197,y:793,t:1528143449545};\\\", \\\"{x:1220,y:805,t:1528143449561};\\\", \\\"{x:1229,y:829,t:1528143449577};\\\", \\\"{x:1228,y:861,t:1528143449595};\\\", \\\"{x:1224,y:863,t:1528143449611};\\\", \\\"{x:1223,y:863,t:1528143449911};\\\", \\\"{x:1224,y:859,t:1528143449928};\\\", \\\"{x:1223,y:851,t:1528143449944};\\\", \\\"{x:1219,y:837,t:1528143449961};\\\", \\\"{x:1207,y:815,t:1528143449978};\\\", \\\"{x:1196,y:795,t:1528143449995};\\\", \\\"{x:1184,y:775,t:1528143450012};\\\", \\\"{x:1169,y:754,t:1528143450028};\\\", \\\"{x:1158,y:738,t:1528143450045};\\\", \\\"{x:1147,y:721,t:1528143450062};\\\", \\\"{x:1135,y:707,t:1528143450077};\\\", \\\"{x:1117,y:685,t:1528143450095};\\\", \\\"{x:1104,y:672,t:1528143450111};\\\", \\\"{x:1097,y:666,t:1528143450128};\\\", \\\"{x:1095,y:662,t:1528143450145};\\\", \\\"{x:1092,y:655,t:1528143450162};\\\", \\\"{x:1091,y:650,t:1528143450178};\\\", \\\"{x:1090,y:643,t:1528143450195};\\\", \\\"{x:1090,y:637,t:1528143450212};\\\", \\\"{x:1090,y:629,t:1528143450229};\\\", \\\"{x:1091,y:620,t:1528143450246};\\\", \\\"{x:1094,y:610,t:1528143450262};\\\", \\\"{x:1095,y:600,t:1528143450278};\\\", \\\"{x:1097,y:577,t:1528143450294};\\\", \\\"{x:1097,y:569,t:1528143450312};\\\", \\\"{x:1097,y:565,t:1528143450328};\\\", \\\"{x:1097,y:562,t:1528143450344};\\\", \\\"{x:1097,y:561,t:1528143450361};\\\", \\\"{x:1099,y:560,t:1528143450623};\\\", \\\"{x:1102,y:561,t:1528143450631};\\\", \\\"{x:1107,y:567,t:1528143450645};\\\", \\\"{x:1113,y:572,t:1528143450662};\\\", \\\"{x:1125,y:582,t:1528143450679};\\\", \\\"{x:1135,y:591,t:1528143450694};\\\", \\\"{x:1143,y:601,t:1528143450712};\\\", \\\"{x:1152,y:612,t:1528143450729};\\\", \\\"{x:1163,y:628,t:1528143450745};\\\", \\\"{x:1174,y:646,t:1528143450762};\\\", \\\"{x:1182,y:662,t:1528143450779};\\\", \\\"{x:1190,y:678,t:1528143450795};\\\", \\\"{x:1193,y:688,t:1528143450812};\\\", \\\"{x:1198,y:699,t:1528143450829};\\\", \\\"{x:1200,y:703,t:1528143450844};\\\", \\\"{x:1201,y:706,t:1528143450862};\\\", \\\"{x:1203,y:712,t:1528143450878};\\\", \\\"{x:1204,y:714,t:1528143450895};\\\", \\\"{x:1205,y:716,t:1528143450912};\\\", \\\"{x:1205,y:717,t:1528143451008};\\\", \\\"{x:1206,y:718,t:1528143451111};\\\", \\\"{x:1206,y:719,t:1528143451129};\\\", \\\"{x:1206,y:720,t:1528143451146};\\\", \\\"{x:1206,y:721,t:1528143451161};\\\", \\\"{x:1206,y:722,t:1528143451178};\\\", \\\"{x:1207,y:723,t:1528143451196};\\\", \\\"{x:1207,y:724,t:1528143451211};\\\", \\\"{x:1207,y:725,t:1528143451228};\\\", \\\"{x:1208,y:727,t:1528143451246};\\\", \\\"{x:1211,y:730,t:1528143451262};\\\", \\\"{x:1218,y:736,t:1528143451278};\\\", \\\"{x:1221,y:742,t:1528143451296};\\\", \\\"{x:1227,y:748,t:1528143451312};\\\", \\\"{x:1231,y:752,t:1528143451329};\\\", \\\"{x:1233,y:757,t:1528143451346};\\\", \\\"{x:1237,y:762,t:1528143451361};\\\", \\\"{x:1239,y:764,t:1528143451379};\\\", \\\"{x:1242,y:769,t:1528143451396};\\\", \\\"{x:1243,y:772,t:1528143451413};\\\", \\\"{x:1247,y:780,t:1528143451429};\\\", \\\"{x:1250,y:787,t:1528143451446};\\\", \\\"{x:1254,y:798,t:1528143451463};\\\", \\\"{x:1258,y:806,t:1528143451478};\\\", \\\"{x:1259,y:809,t:1528143451495};\\\", \\\"{x:1260,y:812,t:1528143451513};\\\", \\\"{x:1261,y:813,t:1528143451528};\\\", \\\"{x:1262,y:814,t:1528143451546};\\\", \\\"{x:1263,y:816,t:1528143451563};\\\", \\\"{x:1263,y:817,t:1528143451578};\\\", \\\"{x:1263,y:818,t:1528143451607};\\\", \\\"{x:1264,y:820,t:1528143451776};\\\", \\\"{x:1265,y:821,t:1528143451799};\\\", \\\"{x:1266,y:821,t:1528143451823};\\\", \\\"{x:1266,y:823,t:1528143451831};\\\", \\\"{x:1267,y:823,t:1528143451847};\\\", \\\"{x:1269,y:825,t:1528143451863};\\\", \\\"{x:1269,y:826,t:1528143451880};\\\", \\\"{x:1272,y:828,t:1528143451895};\\\", \\\"{x:1273,y:829,t:1528143451913};\\\", \\\"{x:1274,y:829,t:1528143451930};\\\", \\\"{x:1275,y:830,t:1528143451945};\\\", \\\"{x:1275,y:831,t:1528143451963};\\\", \\\"{x:1276,y:832,t:1528143451982};\\\", \\\"{x:1277,y:832,t:1528143451996};\\\", \\\"{x:1277,y:833,t:1528143452023};\\\", \\\"{x:1277,y:835,t:1528143452414};\\\", \\\"{x:1278,y:839,t:1528143452429};\\\", \\\"{x:1283,y:852,t:1528143452445};\\\", \\\"{x:1288,y:867,t:1528143452462};\\\", \\\"{x:1297,y:885,t:1528143452479};\\\", \\\"{x:1302,y:900,t:1528143452496};\\\", \\\"{x:1307,y:916,t:1528143452512};\\\", \\\"{x:1316,y:928,t:1528143452529};\\\", \\\"{x:1326,y:942,t:1528143452546};\\\", \\\"{x:1333,y:950,t:1528143452563};\\\", \\\"{x:1340,y:956,t:1528143452579};\\\", \\\"{x:1345,y:960,t:1528143452596};\\\", \\\"{x:1348,y:963,t:1528143452612};\\\", \\\"{x:1351,y:966,t:1528143452629};\\\", \\\"{x:1353,y:967,t:1528143452647};\\\", \\\"{x:1354,y:967,t:1528143452670};\\\", \\\"{x:1355,y:967,t:1528143452686};\\\", \\\"{x:1356,y:967,t:1528143452697};\\\", \\\"{x:1357,y:969,t:1528143452713};\\\", \\\"{x:1358,y:970,t:1528143452730};\\\", \\\"{x:1359,y:971,t:1528143452746};\\\", \\\"{x:1361,y:971,t:1528143452763};\\\", \\\"{x:1363,y:972,t:1528143452780};\\\", \\\"{x:1365,y:973,t:1528143452796};\\\", \\\"{x:1366,y:975,t:1528143452813};\\\", \\\"{x:1368,y:976,t:1528143452829};\\\", \\\"{x:1372,y:979,t:1528143452847};\\\", \\\"{x:1374,y:981,t:1528143452863};\\\", \\\"{x:1376,y:983,t:1528143452879};\\\", \\\"{x:1377,y:984,t:1528143452896};\\\", \\\"{x:1378,y:984,t:1528143453015};\\\", \\\"{x:1378,y:986,t:1528143453127};\\\", \\\"{x:1378,y:987,t:1528143453151};\\\", \\\"{x:1379,y:990,t:1528143453164};\\\", \\\"{x:1380,y:993,t:1528143453180};\\\", \\\"{x:1382,y:998,t:1528143453197};\\\", \\\"{x:1384,y:1001,t:1528143453214};\\\", \\\"{x:1388,y:1006,t:1528143453230};\\\", \\\"{x:1392,y:1010,t:1528143453247};\\\", \\\"{x:1396,y:1011,t:1528143453263};\\\", \\\"{x:1398,y:1012,t:1528143453281};\\\", \\\"{x:1397,y:1012,t:1528143453480};\\\", \\\"{x:1395,y:1008,t:1528143453486};\\\", \\\"{x:1392,y:1006,t:1528143453497};\\\", \\\"{x:1381,y:994,t:1528143453513};\\\", \\\"{x:1369,y:983,t:1528143453531};\\\", \\\"{x:1362,y:968,t:1528143453548};\\\", \\\"{x:1353,y:951,t:1528143453564};\\\", \\\"{x:1341,y:929,t:1528143453581};\\\", \\\"{x:1331,y:909,t:1528143453596};\\\", \\\"{x:1323,y:892,t:1528143453614};\\\", \\\"{x:1314,y:869,t:1528143453631};\\\", \\\"{x:1311,y:854,t:1528143453647};\\\", \\\"{x:1308,y:847,t:1528143453664};\\\", \\\"{x:1308,y:842,t:1528143453681};\\\", \\\"{x:1307,y:839,t:1528143453697};\\\", \\\"{x:1307,y:838,t:1528143453759};\\\", \\\"{x:1307,y:835,t:1528143453879};\\\", \\\"{x:1308,y:831,t:1528143453887};\\\", \\\"{x:1311,y:825,t:1528143453898};\\\", \\\"{x:1322,y:809,t:1528143453914};\\\", \\\"{x:1336,y:790,t:1528143453931};\\\", \\\"{x:1359,y:765,t:1528143453948};\\\", \\\"{x:1380,y:740,t:1528143453964};\\\", \\\"{x:1414,y:706,t:1528143453981};\\\", \\\"{x:1449,y:677,t:1528143453999};\\\", \\\"{x:1474,y:657,t:1528143454014};\\\", \\\"{x:1487,y:644,t:1528143454031};\\\", \\\"{x:1488,y:643,t:1528143454048};\\\", \\\"{x:1491,y:643,t:1528143454383};\\\", \\\"{x:1495,y:643,t:1528143454398};\\\", \\\"{x:1509,y:639,t:1528143454415};\\\", \\\"{x:1517,y:638,t:1528143454431};\\\", \\\"{x:1523,y:637,t:1528143454448};\\\", \\\"{x:1525,y:637,t:1528143454465};\\\", \\\"{x:1527,y:637,t:1528143454481};\\\", \\\"{x:1524,y:637,t:1528143454751};\\\", \\\"{x:1521,y:637,t:1528143454765};\\\", \\\"{x:1514,y:637,t:1528143454782};\\\", \\\"{x:1504,y:639,t:1528143454798};\\\", \\\"{x:1486,y:644,t:1528143454815};\\\", \\\"{x:1473,y:649,t:1528143454832};\\\", \\\"{x:1461,y:654,t:1528143454848};\\\", \\\"{x:1450,y:656,t:1528143454865};\\\", \\\"{x:1438,y:661,t:1528143454882};\\\", \\\"{x:1420,y:667,t:1528143454898};\\\", \\\"{x:1403,y:675,t:1528143454915};\\\", \\\"{x:1392,y:679,t:1528143454932};\\\", \\\"{x:1389,y:681,t:1528143454948};\\\", \\\"{x:1388,y:682,t:1528143454965};\\\", \\\"{x:1386,y:682,t:1528143454999};\\\", \\\"{x:1385,y:683,t:1528143455015};\\\", \\\"{x:1384,y:683,t:1528143455032};\\\", \\\"{x:1383,y:684,t:1528143455048};\\\", \\\"{x:1382,y:685,t:1528143455065};\\\", \\\"{x:1381,y:685,t:1528143455082};\\\", \\\"{x:1381,y:686,t:1528143455098};\\\", \\\"{x:1379,y:686,t:1528143455115};\\\", \\\"{x:1379,y:687,t:1528143455132};\\\", \\\"{x:1376,y:688,t:1528143455148};\\\", \\\"{x:1373,y:690,t:1528143455165};\\\", \\\"{x:1367,y:693,t:1528143455182};\\\", \\\"{x:1358,y:701,t:1528143455198};\\\", \\\"{x:1334,y:724,t:1528143455215};\\\", \\\"{x:1318,y:746,t:1528143455233};\\\", \\\"{x:1299,y:769,t:1528143455249};\\\", \\\"{x:1289,y:790,t:1528143455265};\\\", \\\"{x:1279,y:807,t:1528143455281};\\\", \\\"{x:1278,y:816,t:1528143455298};\\\", \\\"{x:1278,y:821,t:1528143455314};\\\", \\\"{x:1278,y:822,t:1528143455331};\\\", \\\"{x:1279,y:823,t:1528143455348};\\\", \\\"{x:1280,y:823,t:1528143455374};\\\", \\\"{x:1282,y:824,t:1528143455382};\\\", \\\"{x:1282,y:825,t:1528143455398};\\\", \\\"{x:1283,y:826,t:1528143455455};\\\", \\\"{x:1283,y:828,t:1528143455607};\\\", \\\"{x:1283,y:832,t:1528143455615};\\\", \\\"{x:1282,y:841,t:1528143455632};\\\", \\\"{x:1276,y:856,t:1528143455649};\\\", \\\"{x:1268,y:875,t:1528143455665};\\\", \\\"{x:1258,y:897,t:1528143455682};\\\", \\\"{x:1253,y:916,t:1528143455699};\\\", \\\"{x:1250,y:927,t:1528143455716};\\\", \\\"{x:1250,y:932,t:1528143455732};\\\", \\\"{x:1250,y:934,t:1528143455749};\\\", \\\"{x:1250,y:935,t:1528143455767};\\\", \\\"{x:1250,y:936,t:1528143455782};\\\", \\\"{x:1250,y:937,t:1528143455799};\\\", \\\"{x:1252,y:933,t:1528143456247};\\\", \\\"{x:1254,y:928,t:1528143456255};\\\", \\\"{x:1257,y:921,t:1528143456265};\\\", \\\"{x:1265,y:907,t:1528143456282};\\\", \\\"{x:1271,y:892,t:1528143456299};\\\", \\\"{x:1279,y:875,t:1528143456315};\\\", \\\"{x:1282,y:868,t:1528143456332};\\\", \\\"{x:1283,y:865,t:1528143456348};\\\", \\\"{x:1283,y:864,t:1528143456366};\\\", \\\"{x:1284,y:863,t:1528143456864};\\\", \\\"{x:1286,y:861,t:1528143457087};\\\", \\\"{x:1288,y:857,t:1528143457099};\\\", \\\"{x:1290,y:851,t:1528143457116};\\\", \\\"{x:1292,y:847,t:1528143457133};\\\", \\\"{x:1293,y:844,t:1528143457149};\\\", \\\"{x:1294,y:842,t:1528143457166};\\\", \\\"{x:1294,y:841,t:1528143457183};\\\", \\\"{x:1295,y:842,t:1528143457271};\\\", \\\"{x:1295,y:846,t:1528143457283};\\\", \\\"{x:1296,y:854,t:1528143457301};\\\", \\\"{x:1299,y:867,t:1528143457318};\\\", \\\"{x:1301,y:879,t:1528143457333};\\\", \\\"{x:1306,y:893,t:1528143457350};\\\", \\\"{x:1316,y:915,t:1528143457367};\\\", \\\"{x:1326,y:926,t:1528143457383};\\\", \\\"{x:1334,y:936,t:1528143457401};\\\", \\\"{x:1341,y:942,t:1528143457417};\\\", \\\"{x:1344,y:945,t:1528143457433};\\\", \\\"{x:1347,y:947,t:1528143457450};\\\", \\\"{x:1348,y:948,t:1528143457467};\\\", \\\"{x:1349,y:948,t:1528143457483};\\\", \\\"{x:1350,y:949,t:1528143457499};\\\", \\\"{x:1350,y:950,t:1528143457517};\\\", \\\"{x:1349,y:950,t:1528143457767};\\\", \\\"{x:1348,y:950,t:1528143457784};\\\", \\\"{x:1346,y:950,t:1528143457800};\\\", \\\"{x:1341,y:950,t:1528143457817};\\\", \\\"{x:1332,y:950,t:1528143457835};\\\", \\\"{x:1322,y:950,t:1528143457850};\\\", \\\"{x:1307,y:950,t:1528143457868};\\\", \\\"{x:1293,y:950,t:1528143457884};\\\", \\\"{x:1278,y:950,t:1528143457900};\\\", \\\"{x:1269,y:950,t:1528143457917};\\\", \\\"{x:1263,y:950,t:1528143457934};\\\", \\\"{x:1259,y:951,t:1528143457950};\\\", \\\"{x:1258,y:952,t:1528143457967};\\\", \\\"{x:1257,y:952,t:1528143457999};\\\", \\\"{x:1255,y:952,t:1528143458023};\\\", \\\"{x:1254,y:952,t:1528143458143};\\\", \\\"{x:1254,y:950,t:1528143458151};\\\", \\\"{x:1255,y:942,t:1528143458167};\\\", \\\"{x:1261,y:930,t:1528143458184};\\\", \\\"{x:1270,y:914,t:1528143458201};\\\", \\\"{x:1278,y:898,t:1528143458218};\\\", \\\"{x:1287,y:879,t:1528143458234};\\\", \\\"{x:1294,y:866,t:1528143458251};\\\", \\\"{x:1298,y:859,t:1528143458267};\\\", \\\"{x:1299,y:856,t:1528143458283};\\\", \\\"{x:1300,y:855,t:1528143458301};\\\", \\\"{x:1300,y:859,t:1528143458406};\\\", \\\"{x:1300,y:866,t:1528143458416};\\\", \\\"{x:1306,y:882,t:1528143458433};\\\", \\\"{x:1317,y:904,t:1528143458450};\\\", \\\"{x:1331,y:924,t:1528143458467};\\\", \\\"{x:1341,y:940,t:1528143458483};\\\", \\\"{x:1347,y:951,t:1528143458501};\\\", \\\"{x:1353,y:961,t:1528143458516};\\\", \\\"{x:1357,y:966,t:1528143458533};\\\", \\\"{x:1359,y:970,t:1528143458550};\\\", \\\"{x:1358,y:970,t:1528143458647};\\\", \\\"{x:1354,y:970,t:1528143458655};\\\", \\\"{x:1349,y:970,t:1528143458668};\\\", \\\"{x:1332,y:966,t:1528143458684};\\\", \\\"{x:1313,y:965,t:1528143458701};\\\", \\\"{x:1291,y:965,t:1528143458718};\\\", \\\"{x:1272,y:965,t:1528143458734};\\\", \\\"{x:1254,y:968,t:1528143458751};\\\", \\\"{x:1250,y:969,t:1528143458769};\\\", \\\"{x:1248,y:971,t:1528143458784};\\\", \\\"{x:1247,y:971,t:1528143458801};\\\", \\\"{x:1246,y:971,t:1528143458818};\\\", \\\"{x:1243,y:971,t:1528143458834};\\\", \\\"{x:1237,y:971,t:1528143458852};\\\", \\\"{x:1228,y:971,t:1528143458868};\\\", \\\"{x:1220,y:971,t:1528143458884};\\\", \\\"{x:1215,y:971,t:1528143458901};\\\", \\\"{x:1211,y:971,t:1528143458918};\\\", \\\"{x:1209,y:971,t:1528143458934};\\\", \\\"{x:1205,y:971,t:1528143458951};\\\", \\\"{x:1202,y:971,t:1528143458968};\\\", \\\"{x:1197,y:970,t:1528143458984};\\\", \\\"{x:1192,y:969,t:1528143459002};\\\", \\\"{x:1189,y:968,t:1528143459018};\\\", \\\"{x:1186,y:967,t:1528143459034};\\\", \\\"{x:1184,y:966,t:1528143459051};\\\", \\\"{x:1183,y:966,t:1528143459079};\\\", \\\"{x:1181,y:964,t:1528143459095};\\\", \\\"{x:1181,y:963,t:1528143459111};\\\", \\\"{x:1181,y:960,t:1528143459119};\\\", \\\"{x:1184,y:955,t:1528143459135};\\\", \\\"{x:1192,y:946,t:1528143459151};\\\", \\\"{x:1202,y:934,t:1528143459168};\\\", \\\"{x:1211,y:925,t:1528143459185};\\\", \\\"{x:1221,y:914,t:1528143459202};\\\", \\\"{x:1229,y:905,t:1528143459218};\\\", \\\"{x:1234,y:899,t:1528143459235};\\\", \\\"{x:1234,y:898,t:1528143459358};\\\", \\\"{x:1234,y:894,t:1528143459368};\\\", \\\"{x:1234,y:886,t:1528143459384};\\\", \\\"{x:1241,y:867,t:1528143459400};\\\", \\\"{x:1251,y:845,t:1528143459417};\\\", \\\"{x:1261,y:823,t:1528143459435};\\\", \\\"{x:1269,y:800,t:1528143459451};\\\", \\\"{x:1275,y:783,t:1528143459468};\\\", \\\"{x:1277,y:772,t:1528143459484};\\\", \\\"{x:1277,y:765,t:1528143459501};\\\", \\\"{x:1277,y:761,t:1528143459518};\\\", \\\"{x:1277,y:760,t:1528143459535};\\\", \\\"{x:1277,y:758,t:1528143459551};\\\", \\\"{x:1277,y:755,t:1528143459568};\\\", \\\"{x:1277,y:751,t:1528143459585};\\\", \\\"{x:1275,y:746,t:1528143459602};\\\", \\\"{x:1274,y:740,t:1528143459618};\\\", \\\"{x:1272,y:735,t:1528143459635};\\\", \\\"{x:1270,y:728,t:1528143459652};\\\", \\\"{x:1268,y:723,t:1528143459668};\\\", \\\"{x:1266,y:716,t:1528143459685};\\\", \\\"{x:1264,y:711,t:1528143459702};\\\", \\\"{x:1264,y:708,t:1528143459718};\\\", \\\"{x:1264,y:704,t:1528143459735};\\\", \\\"{x:1264,y:702,t:1528143459752};\\\", \\\"{x:1264,y:700,t:1528143459768};\\\", \\\"{x:1264,y:699,t:1528143459864};\\\", \\\"{x:1263,y:699,t:1528143459871};\\\", \\\"{x:1262,y:699,t:1528143460143};\\\", \\\"{x:1262,y:698,t:1528143461143};\\\", \\\"{x:1262,y:696,t:1528143461153};\\\", \\\"{x:1264,y:692,t:1528143461169};\\\", \\\"{x:1266,y:689,t:1528143461186};\\\", \\\"{x:1266,y:686,t:1528143461203};\\\", \\\"{x:1267,y:685,t:1528143461219};\\\", \\\"{x:1268,y:683,t:1528143461237};\\\", \\\"{x:1269,y:682,t:1528143461253};\\\", \\\"{x:1270,y:680,t:1528143461268};\\\", \\\"{x:1270,y:678,t:1528143461285};\\\", \\\"{x:1271,y:676,t:1528143461302};\\\", \\\"{x:1272,y:675,t:1528143461318};\\\", \\\"{x:1273,y:675,t:1528143461335};\\\", \\\"{x:1273,y:674,t:1528143461352};\\\", \\\"{x:1271,y:678,t:1528143461454};\\\", \\\"{x:1269,y:682,t:1528143461471};\\\", \\\"{x:1261,y:700,t:1528143461486};\\\", \\\"{x:1255,y:710,t:1528143461503};\\\", \\\"{x:1253,y:717,t:1528143461519};\\\", \\\"{x:1252,y:719,t:1528143461535};\\\", \\\"{x:1252,y:721,t:1528143461552};\\\", \\\"{x:1252,y:723,t:1528143461569};\\\", \\\"{x:1252,y:726,t:1528143461586};\\\", \\\"{x:1252,y:730,t:1528143461602};\\\", \\\"{x:1253,y:734,t:1528143461620};\\\", \\\"{x:1256,y:739,t:1528143461636};\\\", \\\"{x:1260,y:748,t:1528143461652};\\\", \\\"{x:1266,y:762,t:1528143461670};\\\", \\\"{x:1267,y:768,t:1528143461686};\\\", \\\"{x:1268,y:773,t:1528143461703};\\\", \\\"{x:1269,y:779,t:1528143461719};\\\", \\\"{x:1270,y:788,t:1528143461736};\\\", \\\"{x:1272,y:798,t:1528143461753};\\\", \\\"{x:1276,y:807,t:1528143461770};\\\", \\\"{x:1278,y:816,t:1528143461786};\\\", \\\"{x:1280,y:824,t:1528143461803};\\\", \\\"{x:1280,y:829,t:1528143461821};\\\", \\\"{x:1280,y:835,t:1528143461836};\\\", \\\"{x:1280,y:842,t:1528143461853};\\\", \\\"{x:1279,y:849,t:1528143461870};\\\", \\\"{x:1278,y:855,t:1528143461886};\\\", \\\"{x:1276,y:858,t:1528143461902};\\\", \\\"{x:1275,y:859,t:1528143461919};\\\", \\\"{x:1274,y:860,t:1528143461936};\\\", \\\"{x:1274,y:862,t:1528143461952};\\\", \\\"{x:1273,y:863,t:1528143461969};\\\", \\\"{x:1273,y:866,t:1528143461986};\\\", \\\"{x:1272,y:872,t:1528143462003};\\\", \\\"{x:1272,y:876,t:1528143462019};\\\", \\\"{x:1272,y:881,t:1528143462037};\\\", \\\"{x:1272,y:885,t:1528143462052};\\\", \\\"{x:1272,y:892,t:1528143462070};\\\", \\\"{x:1272,y:898,t:1528143462086};\\\", \\\"{x:1272,y:902,t:1528143462103};\\\", \\\"{x:1272,y:906,t:1528143462120};\\\", \\\"{x:1271,y:912,t:1528143462138};\\\", \\\"{x:1269,y:917,t:1528143462153};\\\", \\\"{x:1269,y:921,t:1528143462169};\\\", \\\"{x:1269,y:922,t:1528143462187};\\\", \\\"{x:1269,y:924,t:1528143462203};\\\", \\\"{x:1269,y:925,t:1528143462220};\\\", \\\"{x:1270,y:927,t:1528143462237};\\\", \\\"{x:1271,y:928,t:1528143462254};\\\", \\\"{x:1272,y:928,t:1528143462278};\\\", \\\"{x:1274,y:928,t:1528143462294};\\\", \\\"{x:1274,y:929,t:1528143462303};\\\", \\\"{x:1274,y:930,t:1528143462320};\\\", \\\"{x:1275,y:933,t:1528143462338};\\\", \\\"{x:1276,y:935,t:1528143462354};\\\", \\\"{x:1276,y:937,t:1528143462370};\\\", \\\"{x:1278,y:940,t:1528143462387};\\\", \\\"{x:1278,y:942,t:1528143462403};\\\", \\\"{x:1279,y:943,t:1528143462421};\\\", \\\"{x:1279,y:944,t:1528143462511};\\\", \\\"{x:1279,y:945,t:1528143462520};\\\", \\\"{x:1279,y:946,t:1528143462538};\\\", \\\"{x:1279,y:947,t:1528143462555};\\\", \\\"{x:1279,y:948,t:1528143462570};\\\", \\\"{x:1281,y:947,t:1528143462663};\\\", \\\"{x:1283,y:946,t:1528143462671};\\\", \\\"{x:1289,y:937,t:1528143462687};\\\", \\\"{x:1292,y:933,t:1528143462704};\\\", \\\"{x:1297,y:926,t:1528143462720};\\\", \\\"{x:1301,y:921,t:1528143462737};\\\", \\\"{x:1303,y:919,t:1528143462754};\\\", \\\"{x:1305,y:916,t:1528143462770};\\\", \\\"{x:1307,y:912,t:1528143462787};\\\", \\\"{x:1310,y:907,t:1528143462805};\\\", \\\"{x:1312,y:902,t:1528143462821};\\\", \\\"{x:1315,y:899,t:1528143462837};\\\", \\\"{x:1318,y:894,t:1528143462854};\\\", \\\"{x:1319,y:891,t:1528143462870};\\\", \\\"{x:1320,y:887,t:1528143462887};\\\", \\\"{x:1321,y:885,t:1528143462903};\\\", \\\"{x:1323,y:880,t:1528143462921};\\\", \\\"{x:1325,y:877,t:1528143462937};\\\", \\\"{x:1328,y:874,t:1528143462954};\\\", \\\"{x:1328,y:873,t:1528143462971};\\\", \\\"{x:1329,y:870,t:1528143462987};\\\", \\\"{x:1330,y:868,t:1528143463004};\\\", \\\"{x:1332,y:865,t:1528143463021};\\\", \\\"{x:1335,y:861,t:1528143463037};\\\", \\\"{x:1338,y:855,t:1528143463054};\\\", \\\"{x:1340,y:853,t:1528143463070};\\\", \\\"{x:1342,y:851,t:1528143463087};\\\", \\\"{x:1343,y:849,t:1528143463111};\\\", \\\"{x:1344,y:847,t:1528143463121};\\\", \\\"{x:1345,y:845,t:1528143463137};\\\", \\\"{x:1346,y:843,t:1528143463154};\\\", \\\"{x:1347,y:842,t:1528143463171};\\\", \\\"{x:1347,y:841,t:1528143463190};\\\", \\\"{x:1348,y:840,t:1528143463207};\\\", \\\"{x:1349,y:839,t:1528143463223};\\\", \\\"{x:1349,y:838,t:1528143463238};\\\", \\\"{x:1350,y:837,t:1528143463255};\\\", \\\"{x:1351,y:835,t:1528143463271};\\\", \\\"{x:1352,y:834,t:1528143463286};\\\", \\\"{x:1352,y:832,t:1528143463303};\\\", \\\"{x:1353,y:832,t:1528143463321};\\\", \\\"{x:1353,y:830,t:1528143463336};\\\", \\\"{x:1354,y:829,t:1528143463358};\\\", \\\"{x:1354,y:828,t:1528143463373};\\\", \\\"{x:1355,y:827,t:1528143463390};\\\", \\\"{x:1355,y:826,t:1528143463439};\\\", \\\"{x:1356,y:824,t:1528143463454};\\\", \\\"{x:1357,y:822,t:1528143463471};\\\", \\\"{x:1358,y:821,t:1528143463489};\\\", \\\"{x:1358,y:820,t:1528143463504};\\\", \\\"{x:1358,y:819,t:1528143463521};\\\", \\\"{x:1359,y:819,t:1528143463538};\\\", \\\"{x:1359,y:818,t:1528143463559};\\\", \\\"{x:1359,y:817,t:1528143463599};\\\", \\\"{x:1360,y:817,t:1528143463607};\\\", \\\"{x:1360,y:816,t:1528143463622};\\\", \\\"{x:1361,y:815,t:1528143463638};\\\", \\\"{x:1361,y:814,t:1528143463671};\\\", \\\"{x:1361,y:812,t:1528143463711};\\\", \\\"{x:1362,y:811,t:1528143463735};\\\", \\\"{x:1363,y:810,t:1528143463775};\\\", \\\"{x:1363,y:809,t:1528143463791};\\\", \\\"{x:1364,y:809,t:1528143463807};\\\", \\\"{x:1364,y:808,t:1528143463830};\\\", \\\"{x:1364,y:806,t:1528143463847};\\\", \\\"{x:1365,y:806,t:1528143463855};\\\", \\\"{x:1365,y:805,t:1528143463887};\\\", \\\"{x:1366,y:805,t:1528143463894};\\\", \\\"{x:1366,y:804,t:1528143463935};\\\", \\\"{x:1367,y:803,t:1528143463967};\\\", \\\"{x:1367,y:802,t:1528143463991};\\\", \\\"{x:1368,y:801,t:1528143464015};\\\", \\\"{x:1368,y:800,t:1528143464031};\\\", \\\"{x:1368,y:799,t:1528143464088};\\\", \\\"{x:1369,y:798,t:1528143464105};\\\", \\\"{x:1369,y:797,t:1528143464127};\\\", \\\"{x:1370,y:796,t:1528143464231};\\\", \\\"{x:1364,y:796,t:1528143464671};\\\", \\\"{x:1326,y:800,t:1528143464689};\\\", \\\"{x:1227,y:807,t:1528143464705};\\\", \\\"{x:1096,y:814,t:1528143464722};\\\", \\\"{x:968,y:814,t:1528143464738};\\\", \\\"{x:849,y:811,t:1528143464755};\\\", \\\"{x:774,y:800,t:1528143464772};\\\", \\\"{x:748,y:789,t:1528143464788};\\\", \\\"{x:736,y:781,t:1528143464805};\\\", \\\"{x:729,y:773,t:1528143464823};\\\", \\\"{x:729,y:771,t:1528143464839};\\\", \\\"{x:728,y:769,t:1528143464855};\\\", \\\"{x:728,y:767,t:1528143464893};\\\", \\\"{x:728,y:766,t:1528143464904};\\\", \\\"{x:730,y:762,t:1528143464922};\\\", \\\"{x:732,y:758,t:1528143464938};\\\", \\\"{x:733,y:755,t:1528143464955};\\\", \\\"{x:733,y:752,t:1528143464975};\\\", \\\"{x:732,y:749,t:1528143464989};\\\", \\\"{x:715,y:737,t:1528143465005};\\\", \\\"{x:629,y:713,t:1528143465021};\\\", \\\"{x:562,y:694,t:1528143465038};\\\", \\\"{x:517,y:674,t:1528143465055};\\\", \\\"{x:486,y:658,t:1528143465072};\\\", \\\"{x:460,y:648,t:1528143465089};\\\", \\\"{x:444,y:638,t:1528143465105};\\\", \\\"{x:438,y:633,t:1528143465122};\\\", \\\"{x:432,y:630,t:1528143465133};\\\", \\\"{x:430,y:628,t:1528143465150};\\\", \\\"{x:430,y:627,t:1528143465246};\\\", \\\"{x:430,y:626,t:1528143465262};\\\", \\\"{x:430,y:624,t:1528143465278};\\\", \\\"{x:430,y:623,t:1528143465286};\\\", \\\"{x:430,y:620,t:1528143465301};\\\", \\\"{x:428,y:608,t:1528143465318};\\\", \\\"{x:415,y:590,t:1528143465335};\\\", \\\"{x:409,y:582,t:1528143465359};\\\", \\\"{x:408,y:582,t:1528143465376};\\\", \\\"{x:408,y:581,t:1528143465392};\\\", \\\"{x:407,y:581,t:1528143465430};\\\", \\\"{x:407,y:580,t:1528143465441};\\\", \\\"{x:403,y:578,t:1528143465459};\\\", \\\"{x:401,y:577,t:1528143465476};\\\", \\\"{x:400,y:577,t:1528143465492};\\\", \\\"{x:399,y:577,t:1528143465518};\\\", \\\"{x:398,y:575,t:1528143465567};\\\", \\\"{x:397,y:575,t:1528143465577};\\\", \\\"{x:396,y:574,t:1528143465594};\\\", \\\"{x:392,y:572,t:1528143465608};\\\", \\\"{x:390,y:571,t:1528143465629};\\\", \\\"{x:389,y:571,t:1528143465661};\\\", \\\"{x:388,y:570,t:1528143465678};\\\", \\\"{x:387,y:569,t:1528143465710};\\\", \\\"{x:386,y:569,t:1528143465726};\\\", \\\"{x:385,y:568,t:1528143465901};\\\", \\\"{x:391,y:565,t:1528143465910};\\\", \\\"{x:449,y:570,t:1528143465926};\\\", \\\"{x:546,y:583,t:1528143465944};\\\", \\\"{x:666,y:600,t:1528143465958};\\\", \\\"{x:788,y:619,t:1528143465976};\\\", \\\"{x:904,y:637,t:1528143465992};\\\", \\\"{x:1029,y:656,t:1528143466008};\\\", \\\"{x:1135,y:670,t:1528143466026};\\\", \\\"{x:1212,y:680,t:1528143466043};\\\", \\\"{x:1269,y:692,t:1528143466058};\\\", \\\"{x:1297,y:695,t:1528143466076};\\\", \\\"{x:1312,y:698,t:1528143466093};\\\", \\\"{x:1313,y:699,t:1528143466126};\\\", \\\"{x:1313,y:701,t:1528143466142};\\\", \\\"{x:1313,y:709,t:1528143466159};\\\", \\\"{x:1308,y:721,t:1528143466176};\\\", \\\"{x:1300,y:737,t:1528143466193};\\\", \\\"{x:1289,y:754,t:1528143466209};\\\", \\\"{x:1274,y:772,t:1528143466226};\\\", \\\"{x:1246,y:796,t:1528143466243};\\\", \\\"{x:1224,y:814,t:1528143466259};\\\", \\\"{x:1197,y:833,t:1528143466276};\\\", \\\"{x:1167,y:849,t:1528143466293};\\\", \\\"{x:1132,y:864,t:1528143466311};\\\", \\\"{x:1107,y:871,t:1528143466326};\\\", \\\"{x:1085,y:875,t:1528143466343};\\\", \\\"{x:1068,y:877,t:1528143466360};\\\", \\\"{x:1057,y:879,t:1528143466377};\\\", \\\"{x:1052,y:879,t:1528143466393};\\\", \\\"{x:1051,y:880,t:1528143466410};\\\", \\\"{x:1050,y:880,t:1528143466427};\\\", \\\"{x:1055,y:882,t:1528143466535};\\\", \\\"{x:1061,y:886,t:1528143466543};\\\", \\\"{x:1083,y:895,t:1528143466561};\\\", \\\"{x:1109,y:907,t:1528143466577};\\\", \\\"{x:1137,y:917,t:1528143466594};\\\", \\\"{x:1160,y:925,t:1528143466610};\\\", \\\"{x:1180,y:932,t:1528143466626};\\\", \\\"{x:1194,y:939,t:1528143466644};\\\", \\\"{x:1201,y:940,t:1528143466660};\\\", \\\"{x:1203,y:942,t:1528143466676};\\\", \\\"{x:1205,y:943,t:1528143466693};\\\", \\\"{x:1211,y:946,t:1528143466710};\\\", \\\"{x:1212,y:947,t:1528143466727};\\\", \\\"{x:1215,y:948,t:1528143466743};\\\", \\\"{x:1216,y:949,t:1528143466761};\\\", \\\"{x:1217,y:950,t:1528143466777};\\\", \\\"{x:1218,y:950,t:1528143466814};\\\", \\\"{x:1219,y:952,t:1528143466828};\\\", \\\"{x:1220,y:952,t:1528143466844};\\\", \\\"{x:1221,y:953,t:1528143466860};\\\", \\\"{x:1223,y:956,t:1528143466876};\\\", \\\"{x:1224,y:957,t:1528143466893};\\\", \\\"{x:1226,y:959,t:1528143466910};\\\", \\\"{x:1232,y:962,t:1528143466926};\\\", \\\"{x:1235,y:963,t:1528143466942};\\\", \\\"{x:1239,y:964,t:1528143466960};\\\", \\\"{x:1243,y:965,t:1528143466977};\\\", \\\"{x:1245,y:966,t:1528143466992};\\\", \\\"{x:1250,y:967,t:1528143467010};\\\", \\\"{x:1252,y:967,t:1528143467027};\\\", \\\"{x:1257,y:968,t:1528143467043};\\\", \\\"{x:1261,y:969,t:1528143467060};\\\", \\\"{x:1263,y:970,t:1528143467077};\\\", \\\"{x:1265,y:970,t:1528143467093};\\\", \\\"{x:1267,y:971,t:1528143467109};\\\", \\\"{x:1269,y:972,t:1528143467134};\\\", \\\"{x:1270,y:972,t:1528143467197};\\\", \\\"{x:1270,y:973,t:1528143467210};\\\", \\\"{x:1272,y:973,t:1528143467227};\\\", \\\"{x:1273,y:973,t:1528143467244};\\\", \\\"{x:1274,y:974,t:1528143467260};\\\", \\\"{x:1275,y:974,t:1528143467286};\\\", \\\"{x:1277,y:975,t:1528143467310};\\\", \\\"{x:1279,y:976,t:1528143467327};\\\", \\\"{x:1283,y:977,t:1528143467344};\\\", \\\"{x:1286,y:978,t:1528143467360};\\\", \\\"{x:1291,y:979,t:1528143467378};\\\", \\\"{x:1292,y:979,t:1528143467395};\\\", \\\"{x:1293,y:980,t:1528143467411};\\\", \\\"{x:1295,y:980,t:1528143467428};\\\", \\\"{x:1296,y:980,t:1528143467446};\\\", \\\"{x:1296,y:981,t:1528143467551};\\\", \\\"{x:1296,y:982,t:1528143467647};\\\", \\\"{x:1295,y:982,t:1528143467686};\\\", \\\"{x:1295,y:981,t:1528143468055};\\\", \\\"{x:1295,y:980,t:1528143468062};\\\", \\\"{x:1295,y:978,t:1528143468077};\\\", \\\"{x:1295,y:973,t:1528143468094};\\\", \\\"{x:1295,y:964,t:1528143468111};\\\", \\\"{x:1295,y:951,t:1528143468128};\\\", \\\"{x:1295,y:939,t:1528143468144};\\\", \\\"{x:1293,y:921,t:1528143468161};\\\", \\\"{x:1289,y:909,t:1528143468178};\\\", \\\"{x:1283,y:897,t:1528143468194};\\\", \\\"{x:1281,y:887,t:1528143468211};\\\", \\\"{x:1278,y:881,t:1528143468229};\\\", \\\"{x:1275,y:874,t:1528143468245};\\\", \\\"{x:1271,y:869,t:1528143468261};\\\", \\\"{x:1268,y:861,t:1528143468278};\\\", \\\"{x:1266,y:859,t:1528143468294};\\\", \\\"{x:1266,y:858,t:1528143468318};\\\", \\\"{x:1266,y:857,t:1528143468334};\\\", \\\"{x:1266,y:856,t:1528143468344};\\\", \\\"{x:1266,y:855,t:1528143468361};\\\", \\\"{x:1266,y:853,t:1528143468379};\\\", \\\"{x:1266,y:854,t:1528143468512};\\\", \\\"{x:1266,y:855,t:1528143468529};\\\", \\\"{x:1266,y:856,t:1528143468647};\\\", \\\"{x:1269,y:856,t:1528143468695};\\\", \\\"{x:1275,y:855,t:1528143468712};\\\", \\\"{x:1282,y:853,t:1528143468729};\\\", \\\"{x:1292,y:849,t:1528143468746};\\\", \\\"{x:1308,y:843,t:1528143468762};\\\", \\\"{x:1325,y:838,t:1528143468779};\\\", \\\"{x:1345,y:830,t:1528143468796};\\\", \\\"{x:1370,y:823,t:1528143468812};\\\", \\\"{x:1396,y:816,t:1528143468829};\\\", \\\"{x:1408,y:810,t:1528143468846};\\\", \\\"{x:1410,y:808,t:1528143468861};\\\", \\\"{x:1412,y:807,t:1528143468878};\\\", \\\"{x:1408,y:809,t:1528143469111};\\\", \\\"{x:1401,y:815,t:1528143469118};\\\", \\\"{x:1393,y:820,t:1528143469129};\\\", \\\"{x:1374,y:832,t:1528143469145};\\\", \\\"{x:1358,y:842,t:1528143469163};\\\", \\\"{x:1342,y:853,t:1528143469179};\\\", \\\"{x:1331,y:861,t:1528143469195};\\\", \\\"{x:1328,y:863,t:1528143469212};\\\", \\\"{x:1327,y:865,t:1528143469228};\\\", \\\"{x:1325,y:866,t:1528143469303};\\\", \\\"{x:1325,y:867,t:1528143469319};\\\", \\\"{x:1323,y:868,t:1528143469328};\\\", \\\"{x:1322,y:869,t:1528143469350};\\\", \\\"{x:1321,y:870,t:1528143469362};\\\", \\\"{x:1320,y:874,t:1528143469379};\\\", \\\"{x:1319,y:877,t:1528143469395};\\\", \\\"{x:1316,y:882,t:1528143469413};\\\", \\\"{x:1314,y:887,t:1528143469429};\\\", \\\"{x:1312,y:892,t:1528143469446};\\\", \\\"{x:1308,y:903,t:1528143469463};\\\", \\\"{x:1305,y:911,t:1528143469479};\\\", \\\"{x:1302,y:917,t:1528143469496};\\\", \\\"{x:1301,y:919,t:1528143469512};\\\", \\\"{x:1300,y:922,t:1528143469529};\\\", \\\"{x:1300,y:923,t:1528143469545};\\\", \\\"{x:1300,y:925,t:1528143469566};\\\", \\\"{x:1300,y:922,t:1528143469711};\\\", \\\"{x:1302,y:916,t:1528143469718};\\\", \\\"{x:1304,y:912,t:1528143469729};\\\", \\\"{x:1313,y:898,t:1528143469745};\\\", \\\"{x:1320,y:885,t:1528143469762};\\\", \\\"{x:1327,y:871,t:1528143469780};\\\", \\\"{x:1330,y:862,t:1528143469796};\\\", \\\"{x:1333,y:854,t:1528143469813};\\\", \\\"{x:1334,y:845,t:1528143469829};\\\", \\\"{x:1341,y:831,t:1528143469846};\\\", \\\"{x:1344,y:823,t:1528143469862};\\\", \\\"{x:1348,y:817,t:1528143469880};\\\", \\\"{x:1351,y:811,t:1528143469897};\\\", \\\"{x:1355,y:807,t:1528143469913};\\\", \\\"{x:1357,y:804,t:1528143469929};\\\", \\\"{x:1359,y:800,t:1528143469947};\\\", \\\"{x:1361,y:798,t:1528143469963};\\\", \\\"{x:1361,y:796,t:1528143469980};\\\", \\\"{x:1362,y:794,t:1528143469997};\\\", \\\"{x:1364,y:794,t:1528143470012};\\\", \\\"{x:1365,y:792,t:1528143470030};\\\", \\\"{x:1368,y:788,t:1528143470047};\\\", \\\"{x:1371,y:785,t:1528143470062};\\\", \\\"{x:1372,y:784,t:1528143470080};\\\", \\\"{x:1372,y:783,t:1528143470183};\\\", \\\"{x:1373,y:781,t:1528143470223};\\\", \\\"{x:1374,y:781,t:1528143470230};\\\", \\\"{x:1375,y:780,t:1528143470247};\\\", \\\"{x:1375,y:779,t:1528143470263};\\\", \\\"{x:1376,y:778,t:1528143470319};\\\", \\\"{x:1377,y:778,t:1528143470367};\\\", \\\"{x:1377,y:777,t:1528143470380};\\\", \\\"{x:1378,y:776,t:1528143470407};\\\", \\\"{x:1380,y:774,t:1528143470456};\\\", \\\"{x:1380,y:773,t:1528143470463};\\\", \\\"{x:1381,y:772,t:1528143470479};\\\", \\\"{x:1382,y:772,t:1528143470496};\\\", \\\"{x:1383,y:771,t:1528143470514};\\\", \\\"{x:1384,y:771,t:1528143470530};\\\", \\\"{x:1384,y:770,t:1528143470551};\\\", \\\"{x:1385,y:770,t:1528143470967};\\\", \\\"{x:1386,y:773,t:1528143470980};\\\", \\\"{x:1387,y:777,t:1528143470997};\\\", \\\"{x:1387,y:779,t:1528143471014};\\\", \\\"{x:1389,y:786,t:1528143471030};\\\", \\\"{x:1391,y:790,t:1528143471046};\\\", \\\"{x:1391,y:793,t:1528143471064};\\\", \\\"{x:1392,y:796,t:1528143471081};\\\", \\\"{x:1394,y:798,t:1528143471097};\\\", \\\"{x:1394,y:799,t:1528143471114};\\\", \\\"{x:1395,y:801,t:1528143471131};\\\", \\\"{x:1395,y:802,t:1528143471150};\\\", \\\"{x:1395,y:803,t:1528143471163};\\\", \\\"{x:1397,y:806,t:1528143471181};\\\", \\\"{x:1398,y:808,t:1528143471198};\\\", \\\"{x:1400,y:810,t:1528143471214};\\\", \\\"{x:1401,y:811,t:1528143471231};\\\", \\\"{x:1402,y:812,t:1528143471247};\\\", \\\"{x:1402,y:814,t:1528143471264};\\\", \\\"{x:1404,y:815,t:1528143471280};\\\", \\\"{x:1405,y:817,t:1528143471297};\\\", \\\"{x:1406,y:818,t:1528143471313};\\\", \\\"{x:1407,y:819,t:1528143471331};\\\", \\\"{x:1409,y:821,t:1528143471347};\\\", \\\"{x:1410,y:822,t:1528143471364};\\\", \\\"{x:1411,y:823,t:1528143471382};\\\", \\\"{x:1412,y:824,t:1528143471414};\\\", \\\"{x:1413,y:825,t:1528143471471};\\\", \\\"{x:1414,y:826,t:1528143471495};\\\", \\\"{x:1415,y:827,t:1528143471511};\\\", \\\"{x:1416,y:828,t:1528143471559};\\\", \\\"{x:1416,y:829,t:1528143471599};\\\", \\\"{x:1417,y:831,t:1528143471622};\\\", \\\"{x:1417,y:832,t:1528143471639};\\\", \\\"{x:1418,y:833,t:1528143471663};\\\", \\\"{x:1419,y:835,t:1528143471703};\\\", \\\"{x:1419,y:836,t:1528143471719};\\\", \\\"{x:1420,y:836,t:1528143471731};\\\", \\\"{x:1420,y:838,t:1528143471747};\\\", \\\"{x:1420,y:839,t:1528143471766};\\\", \\\"{x:1421,y:841,t:1528143471798};\\\", \\\"{x:1422,y:841,t:1528143471815};\\\", \\\"{x:1422,y:842,t:1528143471831};\\\", \\\"{x:1423,y:844,t:1528143471848};\\\", \\\"{x:1423,y:846,t:1528143471864};\\\", \\\"{x:1425,y:849,t:1528143471880};\\\", \\\"{x:1426,y:850,t:1528143471897};\\\", \\\"{x:1426,y:853,t:1528143471914};\\\", \\\"{x:1426,y:855,t:1528143471930};\\\", \\\"{x:1427,y:858,t:1528143471947};\\\", \\\"{x:1428,y:859,t:1528143471964};\\\", \\\"{x:1429,y:860,t:1528143471980};\\\", \\\"{x:1429,y:861,t:1528143471997};\\\", \\\"{x:1429,y:862,t:1528143472013};\\\", \\\"{x:1430,y:864,t:1528143472031};\\\", \\\"{x:1431,y:866,t:1528143472047};\\\", \\\"{x:1432,y:868,t:1528143472065};\\\", \\\"{x:1432,y:869,t:1528143472081};\\\", \\\"{x:1433,y:872,t:1528143472098};\\\", \\\"{x:1433,y:874,t:1528143472115};\\\", \\\"{x:1435,y:877,t:1528143472132};\\\", \\\"{x:1435,y:879,t:1528143472148};\\\", \\\"{x:1436,y:881,t:1528143472165};\\\", \\\"{x:1437,y:884,t:1528143472182};\\\", \\\"{x:1438,y:889,t:1528143472198};\\\", \\\"{x:1440,y:894,t:1528143472215};\\\", \\\"{x:1441,y:896,t:1528143472231};\\\", \\\"{x:1442,y:900,t:1528143472248};\\\", \\\"{x:1443,y:902,t:1528143472265};\\\", \\\"{x:1443,y:903,t:1528143472663};\\\", \\\"{x:1444,y:903,t:1528143472743};\\\", \\\"{x:1445,y:903,t:1528143472759};\\\", \\\"{x:1446,y:903,t:1528143472799};\\\", \\\"{x:1447,y:902,t:1528143472863};\\\", \\\"{x:1448,y:901,t:1528143472935};\\\", \\\"{x:1449,y:900,t:1528143473279};\\\", \\\"{x:1450,y:899,t:1528143473319};\\\", \\\"{x:1449,y:899,t:1528143474495};\\\", \\\"{x:1443,y:899,t:1528143474503};\\\", \\\"{x:1433,y:899,t:1528143474517};\\\", \\\"{x:1411,y:899,t:1528143474533};\\\", \\\"{x:1391,y:899,t:1528143474550};\\\", \\\"{x:1358,y:901,t:1528143474566};\\\", \\\"{x:1336,y:906,t:1528143474582};\\\", \\\"{x:1317,y:914,t:1528143474600};\\\", \\\"{x:1301,y:921,t:1528143474617};\\\", \\\"{x:1288,y:928,t:1528143474633};\\\", \\\"{x:1282,y:929,t:1528143474650};\\\", \\\"{x:1281,y:930,t:1528143474667};\\\", \\\"{x:1279,y:931,t:1528143474684};\\\", \\\"{x:1277,y:932,t:1528143474700};\\\", \\\"{x:1274,y:934,t:1528143474726};\\\", \\\"{x:1272,y:934,t:1528143474735};\\\", \\\"{x:1271,y:935,t:1528143474749};\\\", \\\"{x:1268,y:937,t:1528143474767};\\\", \\\"{x:1268,y:938,t:1528143474799};\\\", \\\"{x:1267,y:938,t:1528143474822};\\\", \\\"{x:1266,y:938,t:1528143474855};\\\", \\\"{x:1265,y:937,t:1528143474957};\\\", \\\"{x:1265,y:933,t:1528143474965};\\\", \\\"{x:1269,y:924,t:1528143474984};\\\", \\\"{x:1278,y:912,t:1528143474999};\\\", \\\"{x:1289,y:903,t:1528143475016};\\\", \\\"{x:1296,y:900,t:1528143475033};\\\", \\\"{x:1300,y:898,t:1528143475050};\\\", \\\"{x:1301,y:898,t:1528143475103};\\\", \\\"{x:1303,y:899,t:1528143475117};\\\", \\\"{x:1303,y:910,t:1528143475134};\\\", \\\"{x:1303,y:928,t:1528143475150};\\\", \\\"{x:1303,y:935,t:1528143475167};\\\", \\\"{x:1297,y:944,t:1528143475184};\\\", \\\"{x:1288,y:951,t:1528143475201};\\\", \\\"{x:1274,y:957,t:1528143475217};\\\", \\\"{x:1252,y:962,t:1528143475234};\\\", \\\"{x:1226,y:962,t:1528143475251};\\\", \\\"{x:1192,y:962,t:1528143475267};\\\", \\\"{x:1154,y:959,t:1528143475284};\\\", \\\"{x:1090,y:940,t:1528143475301};\\\", \\\"{x:982,y:911,t:1528143475317};\\\", \\\"{x:877,y:879,t:1528143475334};\\\", \\\"{x:771,y:850,t:1528143475351};\\\", \\\"{x:732,y:831,t:1528143475366};\\\", \\\"{x:716,y:819,t:1528143475383};\\\", \\\"{x:707,y:806,t:1528143475400};\\\", \\\"{x:703,y:790,t:1528143475417};\\\", \\\"{x:701,y:781,t:1528143475433};\\\", \\\"{x:698,y:772,t:1528143475450};\\\", \\\"{x:695,y:764,t:1528143475467};\\\", \\\"{x:694,y:760,t:1528143475484};\\\", \\\"{x:693,y:754,t:1528143475501};\\\", \\\"{x:690,y:747,t:1528143475516};\\\", \\\"{x:687,y:740,t:1528143475534};\\\", \\\"{x:685,y:736,t:1528143475550};\\\", \\\"{x:682,y:731,t:1528143475568};\\\", \\\"{x:678,y:728,t:1528143475584};\\\", \\\"{x:668,y:723,t:1528143475601};\\\", \\\"{x:653,y:718,t:1528143475617};\\\", \\\"{x:642,y:718,t:1528143475633};\\\", \\\"{x:633,y:718,t:1528143475651};\\\", \\\"{x:624,y:722,t:1528143475668};\\\", \\\"{x:611,y:727,t:1528143475684};\\\", \\\"{x:595,y:730,t:1528143475700};\\\", \\\"{x:582,y:732,t:1528143475718};\\\", \\\"{x:575,y:733,t:1528143475734};\\\", \\\"{x:571,y:733,t:1528143475750};\\\", \\\"{x:570,y:733,t:1528143475768};\\\", \\\"{x:568,y:733,t:1528143475831};\\\", \\\"{x:567,y:733,t:1528143475838};\\\", \\\"{x:566,y:733,t:1528143475850};\\\", \\\"{x:564,y:733,t:1528143475868};\\\", \\\"{x:561,y:733,t:1528143475884};\\\", \\\"{x:557,y:731,t:1528143475900};\\\", \\\"{x:553,y:728,t:1528143475917};\\\", \\\"{x:546,y:725,t:1528143475933};\\\", \\\"{x:540,y:722,t:1528143475950};\\\", \\\"{x:538,y:721,t:1528143475967};\\\", \\\"{x:537,y:721,t:1528143476005};\\\", \\\"{x:536,y:721,t:1528143476022};\\\", \\\"{x:535,y:720,t:1528143476034};\\\", \\\"{x:534,y:720,t:1528143476094};\\\", \\\"{x:534,y:719,t:1528143480359};\\\", \\\"{x:534,y:718,t:1528143480431};\\\", \\\"{x:533,y:718,t:1528143480469};\\\", \\\"{x:532,y:717,t:1528143481102};\\\", \\\"{x:534,y:712,t:1528143481110};\\\", \\\"{x:541,y:704,t:1528143481122};\\\", \\\"{x:556,y:687,t:1528143481138};\\\", \\\"{x:574,y:665,t:1528143481154};\\\", \\\"{x:590,y:645,t:1528143481172};\\\", \\\"{x:604,y:625,t:1528143481189};\\\", \\\"{x:612,y:608,t:1528143481204};\\\", \\\"{x:625,y:586,t:1528143481222};\\\", \\\"{x:629,y:577,t:1528143481238};\\\", \\\"{x:632,y:568,t:1528143481255};\\\", \\\"{x:632,y:563,t:1528143481271};\\\", \\\"{x:632,y:561,t:1528143481288};\\\", \\\"{x:632,y:559,t:1528143481304};\\\", \\\"{x:632,y:558,t:1528143481321};\\\", \\\"{x:632,y:557,t:1528143481382};\\\", \\\"{x:632,y:556,t:1528143481389};\\\", \\\"{x:631,y:555,t:1528143481405};\\\", \\\"{x:629,y:552,t:1528143481421};\\\", \\\"{x:627,y:551,t:1528143481438};\\\", \\\"{x:626,y:551,t:1528143481454};\\\", \\\"{x:625,y:551,t:1528143481542};\\\", \\\"{x:624,y:550,t:1528143482287};\\\" ] }, { \\\"rt\\\": 27636, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 6, \\\"time_elapsed\\\": 425641, \\\"internal_node_id\\\": \\\"0.0-5.0-1.0\\\", \\\"subject\\\": \\\"MKTF4\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"zulu\\\", \\\"condition\\\": \\\"211\\\", \\\"scenario\\\": \\\"acme\\\", \\\"question\\\": \\\"starts\\\", \\\"q\\\": 2, \\\"clicks\\\": 1, \\\"explicit\\\": 2, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XInside-YFull\\\", \\\"correct\\\": 1, \\\"orth_correct\\\": 0, \\\"answer\\\": [ \\\"K\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"X \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"U \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-K -K -K -K -G -E -K -10 AM-11 AM-Z -K \\\", \\\"block\\\": \\\"triangular_scaffolded\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:650,y:511,t:1528143482465};\\\", \\\"{x:651,y:510,t:1528143482478};\\\", \\\"{x:671,y:497,t:1528143482659};\\\", \\\"{x:676,y:496,t:1528143482672};\\\", \\\"{x:681,y:493,t:1528143482689};\\\", \\\"{x:683,y:492,t:1528143482705};\\\", \\\"{x:685,y:490,t:1528143482822};\\\", \\\"{x:685,y:488,t:1528143482943};\\\", \\\"{x:685,y:487,t:1528143482957};\\\", \\\"{x:685,y:485,t:1528143482972};\\\", \\\"{x:685,y:481,t:1528143482990};\\\", \\\"{x:685,y:480,t:1528143483007};\\\", \\\"{x:685,y:477,t:1528143483022};\\\", \\\"{x:686,y:474,t:1528143483039};\\\", \\\"{x:687,y:472,t:1528143483057};\\\", \\\"{x:688,y:468,t:1528143483073};\\\", \\\"{x:690,y:463,t:1528143483090};\\\", \\\"{x:695,y:455,t:1528143483107};\\\", \\\"{x:696,y:449,t:1528143483123};\\\", \\\"{x:699,y:443,t:1528143483140};\\\", \\\"{x:700,y:439,t:1528143483157};\\\", \\\"{x:702,y:437,t:1528143483173};\\\", \\\"{x:702,y:436,t:1528143483255};\\\", \\\"{x:702,y:435,t:1528143483262};\\\", \\\"{x:703,y:435,t:1528143483286};\\\", \\\"{x:704,y:435,t:1528143483294};\\\", \\\"{x:705,y:435,t:1528143483307};\\\", \\\"{x:706,y:434,t:1528143483326};\\\", \\\"{x:707,y:434,t:1528143483350};\\\", \\\"{x:708,y:433,t:1528143483358};\\\", \\\"{x:709,y:433,t:1528143483678};\\\", \\\"{x:711,y:433,t:1528143483690};\\\", \\\"{x:719,y:432,t:1528143483707};\\\", \\\"{x:737,y:434,t:1528143483724};\\\", \\\"{x:765,y:440,t:1528143483740};\\\", \\\"{x:793,y:446,t:1528143483757};\\\", \\\"{x:827,y:455,t:1528143483774};\\\", \\\"{x:840,y:457,t:1528143483790};\\\", \\\"{x:846,y:459,t:1528143483807};\\\", \\\"{x:851,y:461,t:1528143483824};\\\", \\\"{x:859,y:463,t:1528143483841};\\\", \\\"{x:863,y:464,t:1528143483856};\\\", \\\"{x:871,y:466,t:1528143483873};\\\", \\\"{x:882,y:468,t:1528143483891};\\\", \\\"{x:897,y:473,t:1528143483907};\\\", \\\"{x:921,y:480,t:1528143483924};\\\", \\\"{x:946,y:487,t:1528143483941};\\\", \\\"{x:985,y:500,t:1528143483957};\\\", \\\"{x:1037,y:518,t:1528143483974};\\\", \\\"{x:1063,y:529,t:1528143483991};\\\", \\\"{x:1083,y:539,t:1528143484007};\\\", \\\"{x:1104,y:552,t:1528143484024};\\\", \\\"{x:1126,y:566,t:1528143484041};\\\", \\\"{x:1152,y:584,t:1528143484057};\\\", \\\"{x:1173,y:601,t:1528143484074};\\\", \\\"{x:1192,y:618,t:1528143484091};\\\", \\\"{x:1207,y:634,t:1528143484107};\\\", \\\"{x:1217,y:645,t:1528143484124};\\\", \\\"{x:1222,y:656,t:1528143484141};\\\", \\\"{x:1223,y:671,t:1528143484164};\\\", \\\"{x:1223,y:680,t:1528143484174};\\\", \\\"{x:1221,y:693,t:1528143484190};\\\", \\\"{x:1216,y:705,t:1528143484208};\\\", \\\"{x:1211,y:717,t:1528143484223};\\\", \\\"{x:1203,y:730,t:1528143484240};\\\", \\\"{x:1196,y:741,t:1528143484258};\\\", \\\"{x:1192,y:753,t:1528143484273};\\\", \\\"{x:1188,y:759,t:1528143484291};\\\", \\\"{x:1186,y:763,t:1528143484308};\\\", \\\"{x:1183,y:770,t:1528143484323};\\\", \\\"{x:1180,y:775,t:1528143484341};\\\", \\\"{x:1171,y:791,t:1528143484357};\\\", \\\"{x:1168,y:799,t:1528143484374};\\\", \\\"{x:1164,y:805,t:1528143484391};\\\", \\\"{x:1161,y:810,t:1528143484408};\\\", \\\"{x:1157,y:816,t:1528143484424};\\\", \\\"{x:1154,y:820,t:1528143484441};\\\", \\\"{x:1149,y:824,t:1528143484458};\\\", \\\"{x:1145,y:828,t:1528143484474};\\\", \\\"{x:1141,y:830,t:1528143484491};\\\", \\\"{x:1140,y:830,t:1528143484508};\\\", \\\"{x:1139,y:830,t:1528143484623};\\\", \\\"{x:1142,y:830,t:1528143484950};\\\", \\\"{x:1144,y:830,t:1528143484958};\\\", \\\"{x:1153,y:825,t:1528143484975};\\\", \\\"{x:1161,y:818,t:1528143484991};\\\", \\\"{x:1168,y:812,t:1528143485008};\\\", \\\"{x:1176,y:802,t:1528143485025};\\\", \\\"{x:1184,y:794,t:1528143485041};\\\", \\\"{x:1189,y:786,t:1528143485058};\\\", \\\"{x:1192,y:783,t:1528143485075};\\\", \\\"{x:1196,y:776,t:1528143485092};\\\", \\\"{x:1201,y:770,t:1528143485108};\\\", \\\"{x:1205,y:765,t:1528143485125};\\\", \\\"{x:1213,y:754,t:1528143485142};\\\", \\\"{x:1224,y:742,t:1528143485158};\\\", \\\"{x:1232,y:732,t:1528143485175};\\\", \\\"{x:1240,y:721,t:1528143485192};\\\", \\\"{x:1248,y:712,t:1528143485208};\\\", \\\"{x:1254,y:704,t:1528143485225};\\\", \\\"{x:1260,y:698,t:1528143485242};\\\", \\\"{x:1265,y:692,t:1528143485258};\\\", \\\"{x:1271,y:688,t:1528143485275};\\\", \\\"{x:1277,y:684,t:1528143485292};\\\", \\\"{x:1284,y:679,t:1528143485308};\\\", \\\"{x:1288,y:675,t:1528143485325};\\\", \\\"{x:1291,y:673,t:1528143485342};\\\", \\\"{x:1293,y:671,t:1528143485358};\\\", \\\"{x:1294,y:670,t:1528143485375};\\\", \\\"{x:1295,y:670,t:1528143485392};\\\", \\\"{x:1295,y:669,t:1528143485408};\\\", \\\"{x:1297,y:668,t:1528143485425};\\\", \\\"{x:1298,y:668,t:1528143485442};\\\", \\\"{x:1301,y:667,t:1528143485458};\\\", \\\"{x:1307,y:666,t:1528143485475};\\\", \\\"{x:1318,y:665,t:1528143485492};\\\", \\\"{x:1326,y:665,t:1528143485509};\\\", \\\"{x:1332,y:665,t:1528143485525};\\\", \\\"{x:1335,y:664,t:1528143485542};\\\", \\\"{x:1337,y:664,t:1528143485558};\\\", \\\"{x:1340,y:664,t:1528143485575};\\\", \\\"{x:1347,y:664,t:1528143485592};\\\", \\\"{x:1357,y:664,t:1528143485610};\\\", \\\"{x:1369,y:664,t:1528143485625};\\\", \\\"{x:1375,y:664,t:1528143485642};\\\", \\\"{x:1379,y:665,t:1528143485659};\\\", \\\"{x:1383,y:665,t:1528143485675};\\\", \\\"{x:1385,y:665,t:1528143485692};\\\", \\\"{x:1389,y:666,t:1528143485710};\\\", \\\"{x:1392,y:666,t:1528143485725};\\\", \\\"{x:1398,y:666,t:1528143485742};\\\", \\\"{x:1403,y:666,t:1528143485759};\\\", \\\"{x:1407,y:666,t:1528143485776};\\\", \\\"{x:1411,y:666,t:1528143485792};\\\", \\\"{x:1414,y:666,t:1528143485810};\\\", \\\"{x:1416,y:666,t:1528143485826};\\\", \\\"{x:1420,y:665,t:1528143485842};\\\", \\\"{x:1424,y:663,t:1528143485859};\\\", \\\"{x:1430,y:659,t:1528143485875};\\\", \\\"{x:1436,y:656,t:1528143485893};\\\", \\\"{x:1441,y:652,t:1528143485909};\\\", \\\"{x:1446,y:648,t:1528143485925};\\\", \\\"{x:1452,y:644,t:1528143485943};\\\", \\\"{x:1454,y:641,t:1528143485960};\\\", \\\"{x:1457,y:638,t:1528143485976};\\\", \\\"{x:1460,y:634,t:1528143485992};\\\", \\\"{x:1461,y:632,t:1528143486010};\\\", \\\"{x:1463,y:630,t:1528143486026};\\\", \\\"{x:1473,y:623,t:1528143486043};\\\", \\\"{x:1480,y:618,t:1528143486059};\\\", \\\"{x:1492,y:610,t:1528143486076};\\\", \\\"{x:1503,y:603,t:1528143486092};\\\", \\\"{x:1508,y:599,t:1528143486110};\\\", \\\"{x:1514,y:591,t:1528143486125};\\\", \\\"{x:1518,y:586,t:1528143486142};\\\", \\\"{x:1523,y:579,t:1528143486159};\\\", \\\"{x:1528,y:571,t:1528143486177};\\\", \\\"{x:1534,y:561,t:1528143486192};\\\", \\\"{x:1539,y:553,t:1528143486209};\\\", \\\"{x:1545,y:543,t:1528143486227};\\\", \\\"{x:1546,y:539,t:1528143486243};\\\", \\\"{x:1546,y:538,t:1528143486259};\\\", \\\"{x:1547,y:538,t:1528143486276};\\\", \\\"{x:1547,y:537,t:1528143486292};\\\", \\\"{x:1547,y:534,t:1528143486309};\\\", \\\"{x:1550,y:530,t:1528143486326};\\\", \\\"{x:1554,y:525,t:1528143486342};\\\", \\\"{x:1559,y:518,t:1528143486359};\\\", \\\"{x:1565,y:512,t:1528143486376};\\\", \\\"{x:1569,y:506,t:1528143486393};\\\", \\\"{x:1572,y:503,t:1528143486409};\\\", \\\"{x:1576,y:499,t:1528143486426};\\\", \\\"{x:1581,y:494,t:1528143486442};\\\", \\\"{x:1585,y:491,t:1528143486460};\\\", \\\"{x:1589,y:487,t:1528143486476};\\\", \\\"{x:1592,y:485,t:1528143486493};\\\", \\\"{x:1595,y:482,t:1528143486509};\\\", \\\"{x:1597,y:480,t:1528143486526};\\\", \\\"{x:1600,y:477,t:1528143486542};\\\", \\\"{x:1603,y:474,t:1528143486559};\\\", \\\"{x:1606,y:472,t:1528143486576};\\\", \\\"{x:1609,y:469,t:1528143486593};\\\", \\\"{x:1611,y:466,t:1528143486609};\\\", \\\"{x:1612,y:464,t:1528143486626};\\\", \\\"{x:1614,y:462,t:1528143486643};\\\", \\\"{x:1616,y:459,t:1528143486659};\\\", \\\"{x:1618,y:456,t:1528143486676};\\\", \\\"{x:1620,y:455,t:1528143486694};\\\", \\\"{x:1621,y:453,t:1528143486709};\\\", \\\"{x:1622,y:451,t:1528143486726};\\\", \\\"{x:1623,y:450,t:1528143486743};\\\", \\\"{x:1623,y:449,t:1528143486767};\\\", \\\"{x:1623,y:448,t:1528143486806};\\\", \\\"{x:1623,y:447,t:1528143486814};\\\", \\\"{x:1623,y:446,t:1528143486830};\\\", \\\"{x:1623,y:445,t:1528143486847};\\\", \\\"{x:1623,y:443,t:1528143486862};\\\", \\\"{x:1623,y:442,t:1528143486942};\\\", \\\"{x:1623,y:441,t:1528143486960};\\\", \\\"{x:1623,y:440,t:1528143486977};\\\", \\\"{x:1623,y:439,t:1528143487013};\\\", \\\"{x:1623,y:440,t:1528143487262};\\\", \\\"{x:1622,y:441,t:1528143487277};\\\", \\\"{x:1621,y:442,t:1528143487293};\\\", \\\"{x:1617,y:448,t:1528143487310};\\\", \\\"{x:1616,y:451,t:1528143487327};\\\", \\\"{x:1615,y:453,t:1528143487343};\\\", \\\"{x:1613,y:457,t:1528143487360};\\\", \\\"{x:1611,y:460,t:1528143487377};\\\", \\\"{x:1609,y:466,t:1528143487393};\\\", \\\"{x:1606,y:470,t:1528143487410};\\\", \\\"{x:1604,y:477,t:1528143487427};\\\", \\\"{x:1601,y:483,t:1528143487443};\\\", \\\"{x:1599,y:488,t:1528143487460};\\\", \\\"{x:1598,y:491,t:1528143487477};\\\", \\\"{x:1597,y:493,t:1528143487493};\\\", \\\"{x:1595,y:495,t:1528143487510};\\\", \\\"{x:1593,y:499,t:1528143487527};\\\", \\\"{x:1591,y:504,t:1528143487543};\\\", \\\"{x:1588,y:507,t:1528143487560};\\\", \\\"{x:1585,y:512,t:1528143487577};\\\", \\\"{x:1584,y:514,t:1528143487594};\\\", \\\"{x:1583,y:516,t:1528143487610};\\\", \\\"{x:1582,y:518,t:1528143487627};\\\", \\\"{x:1581,y:520,t:1528143487643};\\\", \\\"{x:1578,y:523,t:1528143487660};\\\", \\\"{x:1576,y:526,t:1528143487677};\\\", \\\"{x:1572,y:532,t:1528143487693};\\\", \\\"{x:1567,y:538,t:1528143487710};\\\", \\\"{x:1565,y:543,t:1528143487727};\\\", \\\"{x:1562,y:547,t:1528143487745};\\\", \\\"{x:1560,y:552,t:1528143487760};\\\", \\\"{x:1558,y:555,t:1528143487778};\\\", \\\"{x:1555,y:559,t:1528143487794};\\\", \\\"{x:1553,y:561,t:1528143487810};\\\", \\\"{x:1551,y:564,t:1528143487828};\\\", \\\"{x:1550,y:568,t:1528143487844};\\\", \\\"{x:1548,y:571,t:1528143487861};\\\", \\\"{x:1543,y:579,t:1528143487877};\\\", \\\"{x:1536,y:590,t:1528143487894};\\\", \\\"{x:1532,y:596,t:1528143487910};\\\", \\\"{x:1530,y:599,t:1528143487927};\\\", \\\"{x:1528,y:602,t:1528143487944};\\\", \\\"{x:1527,y:604,t:1528143487960};\\\", \\\"{x:1526,y:606,t:1528143487977};\\\", \\\"{x:1525,y:608,t:1528143487993};\\\", \\\"{x:1524,y:611,t:1528143488010};\\\", \\\"{x:1521,y:615,t:1528143488026};\\\", \\\"{x:1519,y:619,t:1528143488043};\\\", \\\"{x:1518,y:621,t:1528143488060};\\\", \\\"{x:1517,y:624,t:1528143488076};\\\", \\\"{x:1516,y:626,t:1528143488095};\\\", \\\"{x:1515,y:628,t:1528143488110};\\\", \\\"{x:1514,y:630,t:1528143488126};\\\", \\\"{x:1513,y:634,t:1528143488143};\\\", \\\"{x:1510,y:636,t:1528143488161};\\\", \\\"{x:1509,y:638,t:1528143488177};\\\", \\\"{x:1508,y:641,t:1528143488194};\\\", \\\"{x:1507,y:642,t:1528143488210};\\\", \\\"{x:1507,y:643,t:1528143488226};\\\", \\\"{x:1507,y:644,t:1528143488244};\\\", \\\"{x:1506,y:646,t:1528143488260};\\\", \\\"{x:1505,y:648,t:1528143488276};\\\", \\\"{x:1504,y:650,t:1528143488294};\\\", \\\"{x:1504,y:651,t:1528143488310};\\\", \\\"{x:1503,y:652,t:1528143488327};\\\", \\\"{x:1503,y:654,t:1528143488344};\\\", \\\"{x:1500,y:658,t:1528143488362};\\\", \\\"{x:1500,y:660,t:1528143488378};\\\", \\\"{x:1499,y:663,t:1528143488395};\\\", \\\"{x:1498,y:664,t:1528143488412};\\\", \\\"{x:1496,y:668,t:1528143488428};\\\", \\\"{x:1494,y:672,t:1528143488445};\\\", \\\"{x:1493,y:675,t:1528143488462};\\\", \\\"{x:1492,y:678,t:1528143488477};\\\", \\\"{x:1489,y:682,t:1528143488494};\\\", \\\"{x:1488,y:684,t:1528143488511};\\\", \\\"{x:1488,y:685,t:1528143488527};\\\", \\\"{x:1488,y:686,t:1528143488544};\\\", \\\"{x:1488,y:688,t:1528143488561};\\\", \\\"{x:1487,y:688,t:1528143488591};\\\", \\\"{x:1486,y:689,t:1528143488622};\\\", \\\"{x:1486,y:690,t:1528143488630};\\\", \\\"{x:1486,y:691,t:1528143488644};\\\", \\\"{x:1486,y:692,t:1528143488678};\\\", \\\"{x:1485,y:692,t:1528143488695};\\\", \\\"{x:1485,y:693,t:1528143488726};\\\", \\\"{x:1485,y:694,t:1528143488783};\\\", \\\"{x:1484,y:694,t:1528143488983};\\\", \\\"{x:1484,y:695,t:1528143489343};\\\", \\\"{x:1484,y:691,t:1528143489350};\\\", \\\"{x:1488,y:683,t:1528143489361};\\\", \\\"{x:1494,y:665,t:1528143489378};\\\", \\\"{x:1502,y:645,t:1528143489395};\\\", \\\"{x:1509,y:629,t:1528143489410};\\\", \\\"{x:1514,y:619,t:1528143489428};\\\", \\\"{x:1519,y:609,t:1528143489445};\\\", \\\"{x:1526,y:595,t:1528143489462};\\\", \\\"{x:1533,y:585,t:1528143489478};\\\", \\\"{x:1538,y:578,t:1528143489495};\\\", \\\"{x:1539,y:576,t:1528143489512};\\\", \\\"{x:1542,y:573,t:1528143489527};\\\", \\\"{x:1542,y:571,t:1528143489545};\\\", \\\"{x:1544,y:567,t:1528143489562};\\\", \\\"{x:1547,y:563,t:1528143489578};\\\", \\\"{x:1551,y:556,t:1528143489596};\\\", \\\"{x:1555,y:549,t:1528143489612};\\\", \\\"{x:1561,y:541,t:1528143489629};\\\", \\\"{x:1566,y:534,t:1528143489645};\\\", \\\"{x:1573,y:523,t:1528143489662};\\\", \\\"{x:1579,y:515,t:1528143489678};\\\", \\\"{x:1582,y:511,t:1528143489695};\\\", \\\"{x:1585,y:508,t:1528143489712};\\\", \\\"{x:1585,y:506,t:1528143489729};\\\", \\\"{x:1586,y:504,t:1528143489745};\\\", \\\"{x:1586,y:511,t:1528143489862};\\\", \\\"{x:1586,y:529,t:1528143489878};\\\", \\\"{x:1586,y:546,t:1528143489895};\\\", \\\"{x:1584,y:558,t:1528143489912};\\\", \\\"{x:1584,y:567,t:1528143489929};\\\", \\\"{x:1583,y:572,t:1528143489945};\\\", \\\"{x:1582,y:576,t:1528143489962};\\\", \\\"{x:1581,y:580,t:1528143489978};\\\", \\\"{x:1580,y:586,t:1528143489994};\\\", \\\"{x:1578,y:592,t:1528143490012};\\\", \\\"{x:1576,y:601,t:1528143490029};\\\", \\\"{x:1574,y:611,t:1528143490045};\\\", \\\"{x:1573,y:626,t:1528143490061};\\\", \\\"{x:1573,y:638,t:1528143490079};\\\", \\\"{x:1573,y:645,t:1528143490095};\\\", \\\"{x:1573,y:650,t:1528143490112};\\\", \\\"{x:1575,y:654,t:1528143490129};\\\", \\\"{x:1575,y:657,t:1528143490145};\\\", \\\"{x:1578,y:660,t:1528143490163};\\\", \\\"{x:1579,y:662,t:1528143490179};\\\", \\\"{x:1581,y:662,t:1528143490196};\\\", \\\"{x:1583,y:662,t:1528143490212};\\\", \\\"{x:1588,y:662,t:1528143490229};\\\", \\\"{x:1592,y:662,t:1528143490245};\\\", \\\"{x:1607,y:654,t:1528143490262};\\\", \\\"{x:1613,y:648,t:1528143490279};\\\", \\\"{x:1620,y:639,t:1528143490295};\\\", \\\"{x:1624,y:632,t:1528143490312};\\\", \\\"{x:1628,y:622,t:1528143490329};\\\", \\\"{x:1629,y:612,t:1528143490345};\\\", \\\"{x:1631,y:601,t:1528143490362};\\\", \\\"{x:1634,y:590,t:1528143490379};\\\", \\\"{x:1637,y:581,t:1528143490396};\\\", \\\"{x:1639,y:570,t:1528143490412};\\\", \\\"{x:1640,y:561,t:1528143490429};\\\", \\\"{x:1642,y:553,t:1528143490446};\\\", \\\"{x:1643,y:545,t:1528143490462};\\\", \\\"{x:1643,y:541,t:1528143490479};\\\", \\\"{x:1643,y:535,t:1528143490497};\\\", \\\"{x:1643,y:534,t:1528143490512};\\\", \\\"{x:1643,y:532,t:1528143490529};\\\", \\\"{x:1643,y:531,t:1528143490591};\\\", \\\"{x:1642,y:531,t:1528143490598};\\\", \\\"{x:1637,y:533,t:1528143490612};\\\", \\\"{x:1624,y:551,t:1528143490629};\\\", \\\"{x:1598,y:596,t:1528143490647};\\\", \\\"{x:1583,y:620,t:1528143490662};\\\", \\\"{x:1572,y:637,t:1528143490679};\\\", \\\"{x:1565,y:648,t:1528143490697};\\\", \\\"{x:1558,y:663,t:1528143490713};\\\", \\\"{x:1552,y:676,t:1528143490729};\\\", \\\"{x:1544,y:692,t:1528143490747};\\\", \\\"{x:1534,y:713,t:1528143490763};\\\", \\\"{x:1526,y:732,t:1528143490780};\\\", \\\"{x:1523,y:745,t:1528143490796};\\\", \\\"{x:1519,y:756,t:1528143490814};\\\", \\\"{x:1519,y:759,t:1528143490830};\\\", \\\"{x:1517,y:766,t:1528143490847};\\\", \\\"{x:1514,y:769,t:1528143490864};\\\", \\\"{x:1512,y:771,t:1528143490880};\\\", \\\"{x:1508,y:774,t:1528143490896};\\\", \\\"{x:1501,y:778,t:1528143490914};\\\", \\\"{x:1493,y:783,t:1528143490929};\\\", \\\"{x:1487,y:788,t:1528143490946};\\\", \\\"{x:1480,y:792,t:1528143490963};\\\", \\\"{x:1477,y:794,t:1528143490979};\\\", \\\"{x:1476,y:794,t:1528143490997};\\\", \\\"{x:1478,y:794,t:1528143491078};\\\", \\\"{x:1484,y:792,t:1528143491097};\\\", \\\"{x:1493,y:784,t:1528143491113};\\\", \\\"{x:1498,y:781,t:1528143491129};\\\", \\\"{x:1507,y:774,t:1528143491146};\\\", \\\"{x:1523,y:759,t:1528143491163};\\\", \\\"{x:1535,y:749,t:1528143491179};\\\", \\\"{x:1547,y:738,t:1528143491197};\\\", \\\"{x:1562,y:727,t:1528143491213};\\\", \\\"{x:1579,y:712,t:1528143491230};\\\", \\\"{x:1585,y:707,t:1528143491246};\\\", \\\"{x:1587,y:705,t:1528143491263};\\\", \\\"{x:1590,y:704,t:1528143491280};\\\", \\\"{x:1591,y:704,t:1528143491302};\\\", \\\"{x:1592,y:703,t:1528143491312};\\\", \\\"{x:1594,y:703,t:1528143491330};\\\", \\\"{x:1598,y:703,t:1528143491346};\\\", \\\"{x:1609,y:703,t:1528143491363};\\\", \\\"{x:1628,y:706,t:1528143491380};\\\", \\\"{x:1650,y:714,t:1528143491395};\\\", \\\"{x:1665,y:723,t:1528143491413};\\\", \\\"{x:1682,y:734,t:1528143491430};\\\", \\\"{x:1688,y:739,t:1528143491445};\\\", \\\"{x:1696,y:746,t:1528143491463};\\\", \\\"{x:1701,y:754,t:1528143491480};\\\", \\\"{x:1710,y:764,t:1528143491496};\\\", \\\"{x:1718,y:773,t:1528143491513};\\\", \\\"{x:1723,y:780,t:1528143491530};\\\", \\\"{x:1732,y:791,t:1528143491547};\\\", \\\"{x:1735,y:797,t:1528143491563};\\\", \\\"{x:1738,y:803,t:1528143491581};\\\", \\\"{x:1740,y:809,t:1528143491597};\\\", \\\"{x:1741,y:814,t:1528143491614};\\\", \\\"{x:1742,y:819,t:1528143491631};\\\", \\\"{x:1742,y:820,t:1528143491647};\\\", \\\"{x:1740,y:821,t:1528143491687};\\\", \\\"{x:1733,y:819,t:1528143491696};\\\", \\\"{x:1716,y:813,t:1528143491713};\\\", \\\"{x:1694,y:801,t:1528143491730};\\\", \\\"{x:1675,y:789,t:1528143491748};\\\", \\\"{x:1660,y:775,t:1528143491764};\\\", \\\"{x:1648,y:763,t:1528143491781};\\\", \\\"{x:1636,y:744,t:1528143491798};\\\", \\\"{x:1626,y:726,t:1528143491814};\\\", \\\"{x:1610,y:697,t:1528143491830};\\\", \\\"{x:1605,y:682,t:1528143491848};\\\", \\\"{x:1603,y:667,t:1528143491863};\\\", \\\"{x:1603,y:648,t:1528143491881};\\\", \\\"{x:1606,y:626,t:1528143491898};\\\", \\\"{x:1611,y:601,t:1528143491913};\\\", \\\"{x:1617,y:580,t:1528143491930};\\\", \\\"{x:1622,y:562,t:1528143491947};\\\", \\\"{x:1627,y:550,t:1528143491963};\\\", \\\"{x:1628,y:546,t:1528143491979};\\\", \\\"{x:1622,y:550,t:1528143492046};\\\", \\\"{x:1610,y:564,t:1528143492053};\\\", \\\"{x:1598,y:575,t:1528143492063};\\\", \\\"{x:1559,y:607,t:1528143492079};\\\", \\\"{x:1526,y:629,t:1528143492096};\\\", \\\"{x:1505,y:641,t:1528143492113};\\\", \\\"{x:1489,y:654,t:1528143492130};\\\", \\\"{x:1477,y:667,t:1528143492146};\\\", \\\"{x:1471,y:676,t:1528143492164};\\\", \\\"{x:1469,y:683,t:1528143492180};\\\", \\\"{x:1467,y:686,t:1528143492197};\\\", \\\"{x:1467,y:687,t:1528143492215};\\\", \\\"{x:1467,y:689,t:1528143492519};\\\", \\\"{x:1466,y:691,t:1528143492530};\\\", \\\"{x:1464,y:695,t:1528143492547};\\\", \\\"{x:1463,y:702,t:1528143492564};\\\", \\\"{x:1461,y:705,t:1528143492581};\\\", \\\"{x:1459,y:710,t:1528143492598};\\\", \\\"{x:1457,y:718,t:1528143492614};\\\", \\\"{x:1455,y:725,t:1528143492631};\\\", \\\"{x:1454,y:734,t:1528143492647};\\\", \\\"{x:1453,y:741,t:1528143492664};\\\", \\\"{x:1451,y:748,t:1528143492681};\\\", \\\"{x:1450,y:753,t:1528143492698};\\\", \\\"{x:1449,y:758,t:1528143492715};\\\", \\\"{x:1447,y:762,t:1528143492731};\\\", \\\"{x:1447,y:769,t:1528143492748};\\\", \\\"{x:1446,y:773,t:1528143492764};\\\", \\\"{x:1444,y:780,t:1528143492782};\\\", \\\"{x:1443,y:785,t:1528143492797};\\\", \\\"{x:1442,y:789,t:1528143492814};\\\", \\\"{x:1441,y:792,t:1528143492832};\\\", \\\"{x:1441,y:794,t:1528143492847};\\\", \\\"{x:1441,y:795,t:1528143492864};\\\", \\\"{x:1442,y:795,t:1528143492943};\\\", \\\"{x:1445,y:790,t:1528143492950};\\\", \\\"{x:1450,y:784,t:1528143492965};\\\", \\\"{x:1458,y:767,t:1528143492981};\\\", \\\"{x:1472,y:742,t:1528143492997};\\\", \\\"{x:1482,y:720,t:1528143493014};\\\", \\\"{x:1494,y:700,t:1528143493030};\\\", \\\"{x:1505,y:681,t:1528143493048};\\\", \\\"{x:1519,y:662,t:1528143493064};\\\", \\\"{x:1530,y:647,t:1528143493081};\\\", \\\"{x:1537,y:637,t:1528143493098};\\\", \\\"{x:1539,y:632,t:1528143493114};\\\", \\\"{x:1537,y:632,t:1528143493262};\\\", \\\"{x:1532,y:632,t:1528143493270};\\\", \\\"{x:1526,y:632,t:1528143493282};\\\", \\\"{x:1517,y:632,t:1528143493298};\\\", \\\"{x:1495,y:636,t:1528143493315};\\\", \\\"{x:1469,y:637,t:1528143493331};\\\", \\\"{x:1441,y:637,t:1528143493349};\\\", \\\"{x:1405,y:637,t:1528143493364};\\\", \\\"{x:1349,y:630,t:1528143493381};\\\", \\\"{x:1204,y:611,t:1528143493398};\\\", \\\"{x:1076,y:609,t:1528143493416};\\\", \\\"{x:954,y:609,t:1528143493431};\\\", \\\"{x:841,y:609,t:1528143493449};\\\", \\\"{x:760,y:609,t:1528143493465};\\\", \\\"{x:730,y:609,t:1528143493480};\\\", \\\"{x:722,y:609,t:1528143493495};\\\", \\\"{x:720,y:607,t:1528143493653};\\\", \\\"{x:718,y:606,t:1528143493665};\\\", \\\"{x:714,y:603,t:1528143493681};\\\", \\\"{x:705,y:600,t:1528143493698};\\\", \\\"{x:686,y:598,t:1528143493715};\\\", \\\"{x:658,y:596,t:1528143493731};\\\", \\\"{x:612,y:596,t:1528143493749};\\\", \\\"{x:565,y:596,t:1528143493765};\\\", \\\"{x:555,y:596,t:1528143493781};\\\", \\\"{x:552,y:595,t:1528143493798};\\\", \\\"{x:550,y:594,t:1528143493821};\\\", \\\"{x:547,y:594,t:1528143493862};\\\", \\\"{x:545,y:594,t:1528143493869};\\\", \\\"{x:542,y:594,t:1528143493882};\\\", \\\"{x:537,y:591,t:1528143493898};\\\", \\\"{x:531,y:590,t:1528143493915};\\\", \\\"{x:530,y:589,t:1528143493933};\\\", \\\"{x:530,y:588,t:1528143493949};\\\", \\\"{x:528,y:587,t:1528143493966};\\\", \\\"{x:527,y:585,t:1528143493982};\\\", \\\"{x:524,y:583,t:1528143493999};\\\", \\\"{x:523,y:583,t:1528143494015};\\\", \\\"{x:521,y:582,t:1528143494032};\\\", \\\"{x:524,y:579,t:1528143494055};\\\", \\\"{x:529,y:575,t:1528143494066};\\\", \\\"{x:549,y:565,t:1528143494083};\\\", \\\"{x:573,y:559,t:1528143494099};\\\", \\\"{x:593,y:553,t:1528143494115};\\\", \\\"{x:618,y:550,t:1528143494133};\\\", \\\"{x:630,y:548,t:1528143494148};\\\", \\\"{x:636,y:548,t:1528143494165};\\\", \\\"{x:639,y:548,t:1528143494181};\\\", \\\"{x:642,y:549,t:1528143494199};\\\", \\\"{x:644,y:551,t:1528143494215};\\\", \\\"{x:646,y:553,t:1528143494231};\\\", \\\"{x:650,y:554,t:1528143494249};\\\", \\\"{x:654,y:556,t:1528143494265};\\\", \\\"{x:664,y:557,t:1528143494282};\\\", \\\"{x:683,y:561,t:1528143494299};\\\", \\\"{x:708,y:561,t:1528143494315};\\\", \\\"{x:727,y:561,t:1528143494333};\\\", \\\"{x:731,y:561,t:1528143494348};\\\", \\\"{x:728,y:563,t:1528143494389};\\\", \\\"{x:722,y:567,t:1528143494400};\\\", \\\"{x:702,y:576,t:1528143494415};\\\", \\\"{x:665,y:590,t:1528143494432};\\\", \\\"{x:613,y:602,t:1528143494449};\\\", \\\"{x:563,y:608,t:1528143494464};\\\", \\\"{x:533,y:612,t:1528143494481};\\\", \\\"{x:509,y:612,t:1528143494499};\\\", \\\"{x:495,y:612,t:1528143494515};\\\", \\\"{x:478,y:611,t:1528143494532};\\\", \\\"{x:472,y:609,t:1528143494549};\\\", \\\"{x:459,y:607,t:1528143494565};\\\", \\\"{x:445,y:606,t:1528143494582};\\\", \\\"{x:418,y:604,t:1528143494599};\\\", \\\"{x:392,y:602,t:1528143494615};\\\", \\\"{x:366,y:602,t:1528143494632};\\\", \\\"{x:345,y:602,t:1528143494648};\\\", \\\"{x:329,y:602,t:1528143494666};\\\", \\\"{x:318,y:602,t:1528143494682};\\\", \\\"{x:313,y:602,t:1528143494699};\\\", \\\"{x:310,y:602,t:1528143494716};\\\", \\\"{x:306,y:603,t:1528143494732};\\\", \\\"{x:299,y:605,t:1528143494749};\\\", \\\"{x:292,y:606,t:1528143494767};\\\", \\\"{x:291,y:606,t:1528143494783};\\\", \\\"{x:296,y:604,t:1528143494838};\\\", \\\"{x:302,y:600,t:1528143494849};\\\", \\\"{x:320,y:594,t:1528143494867};\\\", \\\"{x:339,y:591,t:1528143494883};\\\", \\\"{x:358,y:591,t:1528143494899};\\\", \\\"{x:378,y:591,t:1528143494917};\\\", \\\"{x:387,y:591,t:1528143494932};\\\", \\\"{x:390,y:591,t:1528143494949};\\\", \\\"{x:390,y:592,t:1528143494981};\\\", \\\"{x:389,y:593,t:1528143494989};\\\", \\\"{x:389,y:594,t:1528143495053};\\\", \\\"{x:388,y:595,t:1528143495066};\\\", \\\"{x:387,y:597,t:1528143495083};\\\", \\\"{x:387,y:596,t:1528143495341};\\\", \\\"{x:388,y:596,t:1528143495398};\\\", \\\"{x:389,y:596,t:1528143495413};\\\", \\\"{x:391,y:596,t:1528143495429};\\\", \\\"{x:393,y:596,t:1528143495437};\\\", \\\"{x:399,y:596,t:1528143495449};\\\", \\\"{x:421,y:598,t:1528143495466};\\\", \\\"{x:464,y:610,t:1528143495482};\\\", \\\"{x:527,y:625,t:1528143495501};\\\", \\\"{x:614,y:640,t:1528143495516};\\\", \\\"{x:700,y:663,t:1528143495533};\\\", \\\"{x:754,y:685,t:1528143495549};\\\", \\\"{x:762,y:691,t:1528143495566};\\\", \\\"{x:764,y:697,t:1528143495583};\\\", \\\"{x:764,y:704,t:1528143495600};\\\", \\\"{x:764,y:711,t:1528143495615};\\\", \\\"{x:758,y:720,t:1528143495632};\\\", \\\"{x:748,y:732,t:1528143495650};\\\", \\\"{x:735,y:749,t:1528143495667};\\\", \\\"{x:721,y:762,t:1528143495684};\\\", \\\"{x:700,y:778,t:1528143495701};\\\", \\\"{x:667,y:797,t:1528143495718};\\\", \\\"{x:646,y:805,t:1528143495734};\\\", \\\"{x:629,y:813,t:1528143495749};\\\", \\\"{x:623,y:814,t:1528143495768};\\\", \\\"{x:621,y:816,t:1528143495783};\\\", \\\"{x:620,y:816,t:1528143495894};\\\", \\\"{x:624,y:816,t:1528143498735};\\\", \\\"{x:631,y:816,t:1528143498742};\\\", \\\"{x:642,y:816,t:1528143498755};\\\", \\\"{x:666,y:816,t:1528143498773};\\\", \\\"{x:731,y:836,t:1528143498790};\\\", \\\"{x:780,y:857,t:1528143498806};\\\", \\\"{x:818,y:877,t:1528143498822};\\\", \\\"{x:841,y:888,t:1528143498840};\\\", \\\"{x:848,y:893,t:1528143498856};\\\", \\\"{x:849,y:894,t:1528143498872};\\\", \\\"{x:849,y:895,t:1528143498889};\\\", \\\"{x:849,y:896,t:1528143498905};\\\", \\\"{x:851,y:900,t:1528143498923};\\\", \\\"{x:853,y:903,t:1528143498940};\\\", \\\"{x:858,y:905,t:1528143498956};\\\", \\\"{x:863,y:906,t:1528143498973};\\\", \\\"{x:886,y:909,t:1528143498989};\\\", \\\"{x:912,y:913,t:1528143499006};\\\", \\\"{x:943,y:918,t:1528143499022};\\\", \\\"{x:978,y:924,t:1528143499039};\\\", \\\"{x:1008,y:926,t:1528143499057};\\\", \\\"{x:1039,y:932,t:1528143499073};\\\", \\\"{x:1065,y:938,t:1528143499090};\\\", \\\"{x:1081,y:941,t:1528143499107};\\\", \\\"{x:1089,y:943,t:1528143499124};\\\", \\\"{x:1091,y:943,t:1528143499140};\\\", \\\"{x:1092,y:943,t:1528143499158};\\\", \\\"{x:1094,y:943,t:1528143499173};\\\", \\\"{x:1098,y:942,t:1528143499190};\\\", \\\"{x:1102,y:940,t:1528143499207};\\\", \\\"{x:1106,y:940,t:1528143499224};\\\", \\\"{x:1117,y:940,t:1528143499239};\\\", \\\"{x:1130,y:940,t:1528143499257};\\\", \\\"{x:1145,y:943,t:1528143499274};\\\", \\\"{x:1154,y:944,t:1528143499291};\\\", \\\"{x:1158,y:944,t:1528143499307};\\\", \\\"{x:1159,y:945,t:1528143499324};\\\", \\\"{x:1160,y:945,t:1528143499407};\\\", \\\"{x:1161,y:945,t:1528143499430};\\\", \\\"{x:1162,y:945,t:1528143499550};\\\", \\\"{x:1164,y:945,t:1528143499687};\\\", \\\"{x:1165,y:945,t:1528143499710};\\\", \\\"{x:1167,y:945,t:1528143499765};\\\", \\\"{x:1170,y:945,t:1528143499774};\\\", \\\"{x:1174,y:947,t:1528143499791};\\\", \\\"{x:1180,y:947,t:1528143499807};\\\", \\\"{x:1186,y:948,t:1528143499824};\\\", \\\"{x:1196,y:952,t:1528143499841};\\\", \\\"{x:1205,y:956,t:1528143499857};\\\", \\\"{x:1214,y:959,t:1528143499874};\\\", \\\"{x:1221,y:962,t:1528143499891};\\\", \\\"{x:1227,y:965,t:1528143499907};\\\", \\\"{x:1229,y:966,t:1528143499924};\\\", \\\"{x:1230,y:966,t:1528143499941};\\\", \\\"{x:1230,y:967,t:1528143499957};\\\", \\\"{x:1230,y:969,t:1528143499974};\\\", \\\"{x:1229,y:972,t:1528143499992};\\\", \\\"{x:1229,y:977,t:1528143500007};\\\", \\\"{x:1225,y:983,t:1528143500025};\\\", \\\"{x:1222,y:987,t:1528143500042};\\\", \\\"{x:1222,y:989,t:1528143500059};\\\", \\\"{x:1222,y:990,t:1528143500094};\\\", \\\"{x:1222,y:991,t:1528143500109};\\\", \\\"{x:1223,y:994,t:1528143500125};\\\", \\\"{x:1233,y:995,t:1528143500142};\\\", \\\"{x:1239,y:995,t:1528143500158};\\\", \\\"{x:1245,y:995,t:1528143500175};\\\", \\\"{x:1251,y:995,t:1528143500191};\\\", \\\"{x:1257,y:993,t:1528143500208};\\\", \\\"{x:1259,y:992,t:1528143500225};\\\", \\\"{x:1261,y:990,t:1528143500241};\\\", \\\"{x:1263,y:989,t:1528143500258};\\\", \\\"{x:1264,y:986,t:1528143500275};\\\", \\\"{x:1266,y:982,t:1528143500291};\\\", \\\"{x:1266,y:980,t:1528143500308};\\\", \\\"{x:1268,y:978,t:1528143500325};\\\", \\\"{x:1269,y:975,t:1528143500342};\\\", \\\"{x:1271,y:970,t:1528143500358};\\\", \\\"{x:1273,y:968,t:1528143500376};\\\", \\\"{x:1276,y:965,t:1528143500392};\\\", \\\"{x:1278,y:963,t:1528143500409};\\\", \\\"{x:1279,y:963,t:1528143500430};\\\", \\\"{x:1279,y:962,t:1528143500442};\\\", \\\"{x:1282,y:961,t:1528143500459};\\\", \\\"{x:1286,y:959,t:1528143500475};\\\", \\\"{x:1288,y:957,t:1528143500493};\\\", \\\"{x:1291,y:955,t:1528143500509};\\\", \\\"{x:1293,y:954,t:1528143500526};\\\", \\\"{x:1294,y:954,t:1528143500543};\\\", \\\"{x:1296,y:952,t:1528143500558};\\\", \\\"{x:1298,y:951,t:1528143500575};\\\", \\\"{x:1300,y:950,t:1528143500593};\\\", \\\"{x:1302,y:947,t:1528143500610};\\\", \\\"{x:1306,y:944,t:1528143500625};\\\", \\\"{x:1311,y:937,t:1528143500643};\\\", \\\"{x:1316,y:931,t:1528143500660};\\\", \\\"{x:1320,y:923,t:1528143500676};\\\", \\\"{x:1327,y:914,t:1528143500692};\\\", \\\"{x:1331,y:907,t:1528143500710};\\\", \\\"{x:1335,y:901,t:1528143500726};\\\", \\\"{x:1336,y:897,t:1528143500743};\\\", \\\"{x:1337,y:894,t:1528143500760};\\\", \\\"{x:1338,y:890,t:1528143500776};\\\", \\\"{x:1340,y:887,t:1528143500792};\\\", \\\"{x:1340,y:884,t:1528143500810};\\\", \\\"{x:1343,y:880,t:1528143500827};\\\", \\\"{x:1343,y:876,t:1528143500843};\\\", \\\"{x:1344,y:870,t:1528143500860};\\\", \\\"{x:1346,y:867,t:1528143500876};\\\", \\\"{x:1347,y:863,t:1528143500892};\\\", \\\"{x:1356,y:852,t:1528143500908};\\\", \\\"{x:1364,y:843,t:1528143500926};\\\", \\\"{x:1369,y:836,t:1528143500943};\\\", \\\"{x:1375,y:828,t:1528143500959};\\\", \\\"{x:1381,y:819,t:1528143500976};\\\", \\\"{x:1385,y:812,t:1528143500992};\\\", \\\"{x:1388,y:809,t:1528143501009};\\\", \\\"{x:1392,y:804,t:1528143501026};\\\", \\\"{x:1395,y:800,t:1528143501043};\\\", \\\"{x:1396,y:796,t:1528143501059};\\\", \\\"{x:1398,y:794,t:1528143501076};\\\", \\\"{x:1403,y:786,t:1528143501093};\\\", \\\"{x:1407,y:778,t:1528143501110};\\\", \\\"{x:1411,y:772,t:1528143501126};\\\", \\\"{x:1414,y:765,t:1528143501143};\\\", \\\"{x:1415,y:760,t:1528143501160};\\\", \\\"{x:1417,y:755,t:1528143501176};\\\", \\\"{x:1419,y:750,t:1528143501193};\\\", \\\"{x:1422,y:745,t:1528143501210};\\\", \\\"{x:1423,y:741,t:1528143501226};\\\", \\\"{x:1426,y:736,t:1528143501243};\\\", \\\"{x:1427,y:731,t:1528143501260};\\\", \\\"{x:1430,y:724,t:1528143501276};\\\", \\\"{x:1436,y:714,t:1528143501293};\\\", \\\"{x:1440,y:708,t:1528143501311};\\\", \\\"{x:1443,y:701,t:1528143501326};\\\", \\\"{x:1449,y:694,t:1528143501343};\\\", \\\"{x:1451,y:689,t:1528143501361};\\\", \\\"{x:1453,y:683,t:1528143501378};\\\", \\\"{x:1457,y:677,t:1528143501394};\\\", \\\"{x:1461,y:671,t:1528143501411};\\\", \\\"{x:1465,y:667,t:1528143501428};\\\", \\\"{x:1470,y:662,t:1528143501443};\\\", \\\"{x:1476,y:654,t:1528143501460};\\\", \\\"{x:1481,y:648,t:1528143501478};\\\", \\\"{x:1483,y:645,t:1528143501493};\\\", \\\"{x:1485,y:643,t:1528143501511};\\\", \\\"{x:1488,y:641,t:1528143501528};\\\", \\\"{x:1489,y:640,t:1528143501544};\\\", \\\"{x:1491,y:638,t:1528143501560};\\\", \\\"{x:1494,y:635,t:1528143501577};\\\", \\\"{x:1498,y:633,t:1528143501594};\\\", \\\"{x:1500,y:631,t:1528143501611};\\\", \\\"{x:1502,y:629,t:1528143501628};\\\", \\\"{x:1503,y:629,t:1528143501644};\\\", \\\"{x:1504,y:629,t:1528143501661};\\\", \\\"{x:1505,y:628,t:1528143501733};\\\", \\\"{x:1506,y:628,t:1528143501781};\\\", \\\"{x:1507,y:626,t:1528143502615};\\\", \\\"{x:1509,y:622,t:1528143502630};\\\", \\\"{x:1513,y:613,t:1528143502646};\\\", \\\"{x:1519,y:599,t:1528143502663};\\\", \\\"{x:1527,y:585,t:1528143502680};\\\", \\\"{x:1537,y:568,t:1528143502697};\\\", \\\"{x:1546,y:551,t:1528143502713};\\\", \\\"{x:1554,y:536,t:1528143502730};\\\", \\\"{x:1558,y:527,t:1528143502747};\\\", \\\"{x:1560,y:521,t:1528143502763};\\\", \\\"{x:1560,y:519,t:1528143502779};\\\", \\\"{x:1561,y:517,t:1528143502797};\\\", \\\"{x:1561,y:516,t:1528143502812};\\\", \\\"{x:1562,y:514,t:1528143502830};\\\", \\\"{x:1563,y:509,t:1528143502847};\\\", \\\"{x:1565,y:503,t:1528143502864};\\\", \\\"{x:1567,y:496,t:1528143502880};\\\", \\\"{x:1571,y:488,t:1528143502897};\\\", \\\"{x:1574,y:481,t:1528143502914};\\\", \\\"{x:1578,y:474,t:1528143502930};\\\", \\\"{x:1580,y:470,t:1528143502947};\\\", \\\"{x:1582,y:468,t:1528143502964};\\\", \\\"{x:1583,y:466,t:1528143502980};\\\", \\\"{x:1584,y:464,t:1528143502998};\\\", \\\"{x:1585,y:462,t:1528143503014};\\\", \\\"{x:1586,y:462,t:1528143503030};\\\", \\\"{x:1586,y:461,t:1528143503054};\\\", \\\"{x:1587,y:460,t:1528143503070};\\\", \\\"{x:1588,y:459,t:1528143503081};\\\", \\\"{x:1589,y:459,t:1528143503097};\\\", \\\"{x:1590,y:457,t:1528143503113};\\\", \\\"{x:1592,y:456,t:1528143503131};\\\", \\\"{x:1592,y:455,t:1528143503146};\\\", \\\"{x:1593,y:454,t:1528143503163};\\\", \\\"{x:1595,y:452,t:1528143503181};\\\", \\\"{x:1597,y:452,t:1528143503197};\\\", \\\"{x:1598,y:450,t:1528143503214};\\\", \\\"{x:1600,y:448,t:1528143503231};\\\", \\\"{x:1600,y:446,t:1528143503248};\\\", \\\"{x:1602,y:446,t:1528143503264};\\\", \\\"{x:1602,y:445,t:1528143503286};\\\", \\\"{x:1602,y:447,t:1528143503487};\\\", \\\"{x:1602,y:449,t:1528143503498};\\\", \\\"{x:1600,y:453,t:1528143503515};\\\", \\\"{x:1598,y:457,t:1528143503531};\\\", \\\"{x:1596,y:463,t:1528143503548};\\\", \\\"{x:1591,y:471,t:1528143503565};\\\", \\\"{x:1587,y:480,t:1528143503581};\\\", \\\"{x:1584,y:485,t:1528143503597};\\\", \\\"{x:1583,y:491,t:1528143503615};\\\", \\\"{x:1581,y:493,t:1528143503632};\\\", \\\"{x:1579,y:497,t:1528143503648};\\\", \\\"{x:1576,y:503,t:1528143503665};\\\", \\\"{x:1572,y:507,t:1528143503682};\\\", \\\"{x:1567,y:514,t:1528143503698};\\\", \\\"{x:1563,y:524,t:1528143503715};\\\", \\\"{x:1558,y:533,t:1528143503732};\\\", \\\"{x:1554,y:539,t:1528143503748};\\\", \\\"{x:1546,y:551,t:1528143503766};\\\", \\\"{x:1540,y:558,t:1528143503782};\\\", \\\"{x:1534,y:566,t:1528143503798};\\\", \\\"{x:1527,y:577,t:1528143503815};\\\", \\\"{x:1519,y:588,t:1528143503832};\\\", \\\"{x:1512,y:599,t:1528143503849};\\\", \\\"{x:1501,y:612,t:1528143503864};\\\", \\\"{x:1492,y:625,t:1528143503882};\\\", \\\"{x:1484,y:638,t:1528143503899};\\\", \\\"{x:1476,y:647,t:1528143503915};\\\", \\\"{x:1470,y:659,t:1528143503932};\\\", \\\"{x:1461,y:674,t:1528143503949};\\\", \\\"{x:1451,y:696,t:1528143503966};\\\", \\\"{x:1443,y:715,t:1528143503983};\\\", \\\"{x:1436,y:730,t:1528143503999};\\\", \\\"{x:1431,y:739,t:1528143504016};\\\", \\\"{x:1429,y:746,t:1528143504032};\\\", \\\"{x:1428,y:752,t:1528143504049};\\\", \\\"{x:1428,y:756,t:1528143504065};\\\", \\\"{x:1426,y:760,t:1528143504082};\\\", \\\"{x:1424,y:769,t:1528143504099};\\\", \\\"{x:1422,y:776,t:1528143504115};\\\", \\\"{x:1420,y:783,t:1528143504131};\\\", \\\"{x:1418,y:790,t:1528143504149};\\\", \\\"{x:1414,y:803,t:1528143504166};\\\", \\\"{x:1412,y:811,t:1528143504181};\\\", \\\"{x:1410,y:818,t:1528143504199};\\\", \\\"{x:1407,y:825,t:1528143504215};\\\", \\\"{x:1404,y:830,t:1528143504232};\\\", \\\"{x:1401,y:835,t:1528143504249};\\\", \\\"{x:1398,y:839,t:1528143504266};\\\", \\\"{x:1396,y:843,t:1528143504282};\\\", \\\"{x:1393,y:847,t:1528143504298};\\\", \\\"{x:1393,y:848,t:1528143504316};\\\", \\\"{x:1393,y:849,t:1528143504332};\\\", \\\"{x:1392,y:849,t:1528143504349};\\\", \\\"{x:1393,y:849,t:1528143504462};\\\", \\\"{x:1397,y:848,t:1528143504470};\\\", \\\"{x:1402,y:844,t:1528143504482};\\\", \\\"{x:1418,y:826,t:1528143504500};\\\", \\\"{x:1438,y:804,t:1528143504515};\\\", \\\"{x:1455,y:777,t:1528143504533};\\\", \\\"{x:1483,y:731,t:1528143504550};\\\", \\\"{x:1495,y:705,t:1528143504566};\\\", \\\"{x:1504,y:679,t:1528143504583};\\\", \\\"{x:1514,y:662,t:1528143504600};\\\", \\\"{x:1524,y:642,t:1528143504616};\\\", \\\"{x:1533,y:626,t:1528143504632};\\\", \\\"{x:1541,y:610,t:1528143504650};\\\", \\\"{x:1550,y:592,t:1528143504666};\\\", \\\"{x:1558,y:577,t:1528143504682};\\\", \\\"{x:1568,y:561,t:1528143504700};\\\", \\\"{x:1576,y:549,t:1528143504716};\\\", \\\"{x:1583,y:539,t:1528143504734};\\\", \\\"{x:1586,y:535,t:1528143504749};\\\", \\\"{x:1587,y:534,t:1528143504766};\\\", \\\"{x:1588,y:533,t:1528143504784};\\\", \\\"{x:1589,y:533,t:1528143504886};\\\", \\\"{x:1592,y:537,t:1528143504909};\\\", \\\"{x:1594,y:545,t:1528143504918};\\\", \\\"{x:1604,y:567,t:1528143504934};\\\", \\\"{x:1615,y:585,t:1528143504950};\\\", \\\"{x:1628,y:606,t:1528143504967};\\\", \\\"{x:1639,y:625,t:1528143504983};\\\", \\\"{x:1647,y:639,t:1528143505000};\\\", \\\"{x:1654,y:653,t:1528143505017};\\\", \\\"{x:1659,y:665,t:1528143505034};\\\", \\\"{x:1666,y:678,t:1528143505050};\\\", \\\"{x:1670,y:691,t:1528143505066};\\\", \\\"{x:1674,y:704,t:1528143505083};\\\", \\\"{x:1676,y:716,t:1528143505101};\\\", \\\"{x:1682,y:730,t:1528143505117};\\\", \\\"{x:1685,y:737,t:1528143505134};\\\", \\\"{x:1687,y:742,t:1528143505151};\\\", \\\"{x:1688,y:746,t:1528143505168};\\\", \\\"{x:1688,y:748,t:1528143505183};\\\", \\\"{x:1688,y:751,t:1528143505201};\\\", \\\"{x:1688,y:752,t:1528143505221};\\\", \\\"{x:1688,y:753,t:1528143505301};\\\", \\\"{x:1688,y:755,t:1528143505317};\\\", \\\"{x:1683,y:758,t:1528143505333};\\\", \\\"{x:1675,y:763,t:1528143505350};\\\", \\\"{x:1660,y:772,t:1528143505367};\\\", \\\"{x:1640,y:784,t:1528143505384};\\\", \\\"{x:1610,y:800,t:1528143505400};\\\", \\\"{x:1566,y:826,t:1528143505416};\\\", \\\"{x:1507,y:865,t:1528143505434};\\\", \\\"{x:1470,y:894,t:1528143505450};\\\", \\\"{x:1448,y:912,t:1528143505467};\\\", \\\"{x:1432,y:927,t:1528143505484};\\\", \\\"{x:1421,y:935,t:1528143505501};\\\", \\\"{x:1418,y:940,t:1528143505517};\\\", \\\"{x:1417,y:941,t:1528143505534};\\\", \\\"{x:1416,y:943,t:1528143505551};\\\", \\\"{x:1415,y:945,t:1528143505568};\\\", \\\"{x:1414,y:946,t:1528143505584};\\\", \\\"{x:1413,y:946,t:1528143505601};\\\", \\\"{x:1413,y:947,t:1528143505646};\\\", \\\"{x:1412,y:947,t:1528143505669};\\\", \\\"{x:1412,y:940,t:1528143505685};\\\", \\\"{x:1412,y:928,t:1528143505701};\\\", \\\"{x:1414,y:919,t:1528143505718};\\\", \\\"{x:1416,y:911,t:1528143505734};\\\", \\\"{x:1416,y:908,t:1528143505751};\\\", \\\"{x:1416,y:907,t:1528143505768};\\\", \\\"{x:1416,y:908,t:1528143505861};\\\", \\\"{x:1415,y:911,t:1528143505869};\\\", \\\"{x:1411,y:915,t:1528143505886};\\\", \\\"{x:1408,y:918,t:1528143505901};\\\", \\\"{x:1407,y:922,t:1528143505919};\\\", \\\"{x:1405,y:924,t:1528143505935};\\\", \\\"{x:1404,y:926,t:1528143505952};\\\", \\\"{x:1403,y:927,t:1528143505974};\\\", \\\"{x:1402,y:928,t:1528143505998};\\\", \\\"{x:1402,y:929,t:1528143506013};\\\", \\\"{x:1400,y:930,t:1528143506022};\\\", \\\"{x:1399,y:932,t:1528143506036};\\\", \\\"{x:1396,y:935,t:1528143506053};\\\", \\\"{x:1393,y:939,t:1528143506069};\\\", \\\"{x:1389,y:943,t:1528143506086};\\\", \\\"{x:1387,y:944,t:1528143506102};\\\", \\\"{x:1385,y:944,t:1528143506119};\\\", \\\"{x:1384,y:945,t:1528143506136};\\\", \\\"{x:1383,y:945,t:1528143506153};\\\", \\\"{x:1382,y:945,t:1528143506168};\\\", \\\"{x:1380,y:946,t:1528143506186};\\\", \\\"{x:1379,y:946,t:1528143506212};\\\", \\\"{x:1378,y:946,t:1528143506252};\\\", \\\"{x:1377,y:947,t:1528143506269};\\\", \\\"{x:1376,y:947,t:1528143506693};\\\", \\\"{x:1375,y:947,t:1528143506918};\\\", \\\"{x:1374,y:947,t:1528143506926};\\\", \\\"{x:1371,y:947,t:1528143507038};\\\", \\\"{x:1363,y:947,t:1528143507053};\\\", \\\"{x:1342,y:948,t:1528143507070};\\\", \\\"{x:1303,y:948,t:1528143507088};\\\", \\\"{x:1231,y:948,t:1528143507104};\\\", \\\"{x:1137,y:948,t:1528143507120};\\\", \\\"{x:1053,y:948,t:1528143507137};\\\", \\\"{x:1004,y:945,t:1528143507153};\\\", \\\"{x:974,y:942,t:1528143507170};\\\", \\\"{x:951,y:939,t:1528143507187};\\\", \\\"{x:936,y:935,t:1528143507204};\\\", \\\"{x:930,y:931,t:1528143507220};\\\", \\\"{x:911,y:921,t:1528143507237};\\\", \\\"{x:889,y:903,t:1528143507254};\\\", \\\"{x:847,y:864,t:1528143507270};\\\", \\\"{x:792,y:831,t:1528143507287};\\\", \\\"{x:747,y:809,t:1528143507304};\\\", \\\"{x:699,y:794,t:1528143507320};\\\", \\\"{x:657,y:782,t:1528143507337};\\\", \\\"{x:615,y:771,t:1528143507354};\\\", \\\"{x:576,y:760,t:1528143507372};\\\", \\\"{x:545,y:755,t:1528143507388};\\\", \\\"{x:523,y:751,t:1528143507404};\\\", \\\"{x:506,y:749,t:1528143507421};\\\", \\\"{x:502,y:749,t:1528143507437};\\\", \\\"{x:499,y:749,t:1528143507454};\\\", \\\"{x:499,y:748,t:1528143507556};\\\", \\\"{x:499,y:746,t:1528143507571};\\\", \\\"{x:499,y:741,t:1528143507587};\\\", \\\"{x:503,y:735,t:1528143507604};\\\", \\\"{x:508,y:721,t:1528143507621};\\\", \\\"{x:511,y:715,t:1528143507638};\\\", \\\"{x:514,y:709,t:1528143507654};\\\", \\\"{x:515,y:707,t:1528143507676};\\\", \\\"{x:514,y:707,t:1528143508093};\\\", \\\"{x:520,y:702,t:1528143510365};\\\", \\\"{x:530,y:691,t:1528143510377};\\\", \\\"{x:564,y:666,t:1528143510394};\\\", \\\"{x:617,y:629,t:1528143510411};\\\", \\\"{x:657,y:599,t:1528143510428};\\\", \\\"{x:685,y:577,t:1528143510444};\\\", \\\"{x:700,y:561,t:1528143510461};\\\", \\\"{x:707,y:553,t:1528143510478};\\\", \\\"{x:713,y:548,t:1528143510494};\\\", \\\"{x:715,y:546,t:1528143510511};\\\", \\\"{x:716,y:546,t:1528143511030};\\\", \\\"{x:719,y:544,t:1528143511044};\\\", \\\"{x:720,y:544,t:1528143511068};\\\", \\\"{x:721,y:543,t:1528143511085};\\\", \\\"{x:722,y:543,t:1528143511189};\\\" ] }, { \\\"rt\\\": 29218, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 7, \\\"time_elapsed\\\": 456088, \\\"internal_node_id\\\": \\\"0.0-5.0-2.0\\\", \\\"subject\\\": \\\"MKTF4\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"zulu\\\", \\\"condition\\\": \\\"211\\\", \\\"scenario\\\": \\\"acme\\\", \\\"question\\\": \\\"meets\\\", \\\"q\\\": 3, \\\"clicks\\\": 1, \\\"explicit\\\": 2, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XInside-YFull\\\", \\\"correct\\\": 1, \\\"orth_correct\\\": 0, \\\"answer\\\": [ \\\"F\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"X \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"U \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-A -11 AM-09 AM-C -F -F \\\", \\\"block\\\": \\\"triangular_scaffolded\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:724,y:543,t:1528143512141};\\\", \\\"{x:727,y:542,t:1528143512149};\\\", \\\"{x:728,y:539,t:1528143512162};\\\", \\\"{x:734,y:535,t:1528143512182};\\\", \\\"{x:738,y:532,t:1528143512196};\\\", \\\"{x:740,y:530,t:1528143512211};\\\", \\\"{x:742,y:528,t:1528143512229};\\\", \\\"{x:742,y:526,t:1528143512246};\\\", \\\"{x:744,y:524,t:1528143512262};\\\", \\\"{x:745,y:522,t:1528143512279};\\\", \\\"{x:747,y:522,t:1528143512374};\\\", \\\"{x:748,y:522,t:1528143512381};\\\", \\\"{x:753,y:522,t:1528143512397};\\\", \\\"{x:766,y:522,t:1528143512413};\\\", \\\"{x:796,y:522,t:1528143512429};\\\", \\\"{x:807,y:522,t:1528143512446};\\\", \\\"{x:816,y:522,t:1528143512463};\\\", \\\"{x:820,y:522,t:1528143512479};\\\", \\\"{x:828,y:521,t:1528143512498};\\\", \\\"{x:835,y:520,t:1528143512512};\\\", \\\"{x:852,y:517,t:1528143512529};\\\", \\\"{x:872,y:514,t:1528143512547};\\\", \\\"{x:890,y:511,t:1528143512563};\\\", \\\"{x:915,y:507,t:1528143512579};\\\", \\\"{x:933,y:505,t:1528143512596};\\\", \\\"{x:955,y:501,t:1528143512613};\\\", \\\"{x:969,y:499,t:1528143512629};\\\", \\\"{x:986,y:491,t:1528143512647};\\\", \\\"{x:1005,y:480,t:1528143512663};\\\", \\\"{x:1019,y:472,t:1528143512680};\\\", \\\"{x:1025,y:466,t:1528143512696};\\\", \\\"{x:1026,y:464,t:1528143512713};\\\", \\\"{x:1026,y:462,t:1528143512790};\\\", \\\"{x:1019,y:460,t:1528143512797};\\\", \\\"{x:987,y:454,t:1528143512813};\\\", \\\"{x:920,y:446,t:1528143512829};\\\", \\\"{x:839,y:431,t:1528143512846};\\\", \\\"{x:771,y:419,t:1528143512863};\\\", \\\"{x:718,y:409,t:1528143512880};\\\", \\\"{x:691,y:401,t:1528143512895};\\\", \\\"{x:665,y:400,t:1528143512913};\\\", \\\"{x:615,y:409,t:1528143512929};\\\", \\\"{x:540,y:433,t:1528143512946};\\\", \\\"{x:476,y:464,t:1528143512963};\\\", \\\"{x:421,y:495,t:1528143512980};\\\", \\\"{x:406,y:506,t:1528143512996};\\\", \\\"{x:403,y:509,t:1528143513013};\\\", \\\"{x:403,y:510,t:1528143513060};\\\", \\\"{x:403,y:511,t:1528143513068};\\\", \\\"{x:403,y:512,t:1528143513080};\\\", \\\"{x:405,y:514,t:1528143513096};\\\", \\\"{x:413,y:517,t:1528143513112};\\\", \\\"{x:434,y:519,t:1528143513130};\\\", \\\"{x:472,y:519,t:1528143513146};\\\", \\\"{x:515,y:513,t:1528143513163};\\\", \\\"{x:572,y:493,t:1528143513180};\\\", \\\"{x:591,y:480,t:1528143513196};\\\", \\\"{x:596,y:475,t:1528143513212};\\\", \\\"{x:598,y:472,t:1528143513229};\\\", \\\"{x:598,y:471,t:1528143513300};\\\", \\\"{x:594,y:471,t:1528143513312};\\\", \\\"{x:579,y:468,t:1528143513330};\\\", \\\"{x:554,y:468,t:1528143513347};\\\", \\\"{x:529,y:467,t:1528143513362};\\\", \\\"{x:503,y:467,t:1528143513380};\\\", \\\"{x:488,y:467,t:1528143513396};\\\", \\\"{x:483,y:467,t:1528143513413};\\\", \\\"{x:481,y:467,t:1528143513430};\\\", \\\"{x:480,y:468,t:1528143513500};\\\", \\\"{x:478,y:470,t:1528143513513};\\\", \\\"{x:474,y:472,t:1528143513530};\\\", \\\"{x:472,y:473,t:1528143513547};\\\", \\\"{x:470,y:474,t:1528143513581};\\\", \\\"{x:465,y:476,t:1528143513597};\\\", \\\"{x:461,y:479,t:1528143513613};\\\", \\\"{x:460,y:479,t:1528143513630};\\\", \\\"{x:460,y:478,t:1528143514116};\\\", \\\"{x:462,y:477,t:1528143514130};\\\", \\\"{x:466,y:476,t:1528143514147};\\\", \\\"{x:469,y:474,t:1528143514164};\\\", \\\"{x:473,y:473,t:1528143514180};\\\", \\\"{x:482,y:470,t:1528143514198};\\\", \\\"{x:489,y:469,t:1528143514215};\\\", \\\"{x:497,y:466,t:1528143514230};\\\", \\\"{x:507,y:466,t:1528143514247};\\\", \\\"{x:517,y:465,t:1528143514264};\\\", \\\"{x:525,y:464,t:1528143514281};\\\", \\\"{x:531,y:463,t:1528143514297};\\\", \\\"{x:539,y:463,t:1528143514315};\\\", \\\"{x:546,y:463,t:1528143514332};\\\", \\\"{x:552,y:463,t:1528143514348};\\\", \\\"{x:557,y:463,t:1528143514364};\\\", \\\"{x:562,y:463,t:1528143514381};\\\", \\\"{x:563,y:463,t:1528143514438};\\\", \\\"{x:564,y:463,t:1528143514534};\\\", \\\"{x:565,y:463,t:1528143514547};\\\", \\\"{x:569,y:463,t:1528143514565};\\\", \\\"{x:575,y:463,t:1528143514581};\\\", \\\"{x:580,y:463,t:1528143514597};\\\", \\\"{x:585,y:463,t:1528143514614};\\\", \\\"{x:588,y:463,t:1528143514632};\\\", \\\"{x:589,y:463,t:1528143514661};\\\", \\\"{x:589,y:464,t:1528143514966};\\\", \\\"{x:589,y:465,t:1528143514981};\\\", \\\"{x:584,y:469,t:1528143514998};\\\", \\\"{x:577,y:472,t:1528143515015};\\\", \\\"{x:568,y:474,t:1528143515031};\\\", \\\"{x:552,y:477,t:1528143515048};\\\", \\\"{x:527,y:481,t:1528143515065};\\\", \\\"{x:498,y:484,t:1528143515082};\\\", \\\"{x:473,y:486,t:1528143515099};\\\", \\\"{x:456,y:490,t:1528143515115};\\\", \\\"{x:446,y:490,t:1528143515132};\\\", \\\"{x:445,y:490,t:1528143515148};\\\", \\\"{x:446,y:490,t:1528143515421};\\\", \\\"{x:447,y:490,t:1528143515432};\\\", \\\"{x:450,y:489,t:1528143515448};\\\", \\\"{x:455,y:488,t:1528143515466};\\\", \\\"{x:460,y:486,t:1528143515482};\\\", \\\"{x:472,y:485,t:1528143515498};\\\", \\\"{x:495,y:485,t:1528143515516};\\\", \\\"{x:516,y:485,t:1528143515531};\\\", \\\"{x:534,y:485,t:1528143515549};\\\", \\\"{x:547,y:485,t:1528143515565};\\\", \\\"{x:551,y:485,t:1528143515581};\\\", \\\"{x:554,y:485,t:1528143515598};\\\", \\\"{x:560,y:485,t:1528143515616};\\\", \\\"{x:572,y:486,t:1528143515632};\\\", \\\"{x:583,y:486,t:1528143515649};\\\", \\\"{x:596,y:486,t:1528143515666};\\\", \\\"{x:617,y:486,t:1528143515682};\\\", \\\"{x:647,y:486,t:1528143515698};\\\", \\\"{x:701,y:489,t:1528143515716};\\\", \\\"{x:817,y:498,t:1528143515733};\\\", \\\"{x:866,y:506,t:1528143515750};\\\", \\\"{x:976,y:522,t:1528143515765};\\\", \\\"{x:1012,y:529,t:1528143515782};\\\", \\\"{x:1029,y:536,t:1528143515798};\\\", \\\"{x:1036,y:542,t:1528143515815};\\\", \\\"{x:1043,y:549,t:1528143515832};\\\", \\\"{x:1048,y:558,t:1528143515849};\\\", \\\"{x:1051,y:566,t:1528143515865};\\\", \\\"{x:1053,y:570,t:1528143515883};\\\", \\\"{x:1055,y:575,t:1528143515899};\\\", \\\"{x:1058,y:582,t:1528143515915};\\\", \\\"{x:1061,y:590,t:1528143515933};\\\", \\\"{x:1062,y:594,t:1528143515948};\\\", \\\"{x:1063,y:597,t:1528143515966};\\\", \\\"{x:1066,y:604,t:1528143515982};\\\", \\\"{x:1073,y:614,t:1528143516000};\\\", \\\"{x:1083,y:627,t:1528143516015};\\\", \\\"{x:1096,y:641,t:1528143516032};\\\", \\\"{x:1109,y:655,t:1528143516050};\\\", \\\"{x:1126,y:671,t:1528143516066};\\\", \\\"{x:1144,y:688,t:1528143516083};\\\", \\\"{x:1159,y:704,t:1528143516100};\\\", \\\"{x:1180,y:726,t:1528143516117};\\\", \\\"{x:1195,y:743,t:1528143516133};\\\", \\\"{x:1214,y:755,t:1528143516150};\\\", \\\"{x:1233,y:766,t:1528143516167};\\\", \\\"{x:1249,y:775,t:1528143516182};\\\", \\\"{x:1264,y:781,t:1528143516200};\\\", \\\"{x:1274,y:786,t:1528143516217};\\\", \\\"{x:1279,y:788,t:1528143516233};\\\", \\\"{x:1281,y:790,t:1528143516250};\\\", \\\"{x:1282,y:791,t:1528143516267};\\\", \\\"{x:1283,y:792,t:1528143516283};\\\", \\\"{x:1285,y:795,t:1528143516300};\\\", \\\"{x:1286,y:797,t:1528143516317};\\\", \\\"{x:1289,y:800,t:1528143516333};\\\", \\\"{x:1290,y:800,t:1528143516349};\\\", \\\"{x:1290,y:802,t:1528143516397};\\\", \\\"{x:1289,y:804,t:1528143516405};\\\", \\\"{x:1286,y:805,t:1528143516417};\\\", \\\"{x:1280,y:811,t:1528143516434};\\\", \\\"{x:1266,y:817,t:1528143516450};\\\", \\\"{x:1248,y:826,t:1528143516466};\\\", \\\"{x:1230,y:834,t:1528143516484};\\\", \\\"{x:1217,y:837,t:1528143516499};\\\", \\\"{x:1212,y:837,t:1528143516517};\\\", \\\"{x:1211,y:838,t:1528143516534};\\\", \\\"{x:1209,y:838,t:1528143516717};\\\", \\\"{x:1207,y:840,t:1528143516734};\\\", \\\"{x:1204,y:847,t:1528143516751};\\\", \\\"{x:1201,y:851,t:1528143516768};\\\", \\\"{x:1197,y:857,t:1528143516783};\\\", \\\"{x:1196,y:861,t:1528143516800};\\\", \\\"{x:1194,y:864,t:1528143516818};\\\", \\\"{x:1193,y:868,t:1528143516834};\\\", \\\"{x:1192,y:872,t:1528143516851};\\\", \\\"{x:1192,y:874,t:1528143516868};\\\", \\\"{x:1189,y:880,t:1528143516884};\\\", \\\"{x:1188,y:888,t:1528143516902};\\\", \\\"{x:1184,y:896,t:1528143516918};\\\", \\\"{x:1176,y:907,t:1528143516934};\\\", \\\"{x:1174,y:914,t:1528143516951};\\\", \\\"{x:1170,y:920,t:1528143516968};\\\", \\\"{x:1167,y:923,t:1528143516984};\\\", \\\"{x:1167,y:925,t:1528143517001};\\\", \\\"{x:1165,y:928,t:1528143517018};\\\", \\\"{x:1162,y:931,t:1528143517035};\\\", \\\"{x:1160,y:933,t:1528143517051};\\\", \\\"{x:1159,y:934,t:1528143517068};\\\", \\\"{x:1157,y:936,t:1528143517085};\\\", \\\"{x:1157,y:932,t:1528143517206};\\\", \\\"{x:1158,y:931,t:1528143517218};\\\", \\\"{x:1160,y:927,t:1528143517235};\\\", \\\"{x:1163,y:921,t:1528143517252};\\\", \\\"{x:1165,y:914,t:1528143517268};\\\", \\\"{x:1172,y:898,t:1528143517285};\\\", \\\"{x:1177,y:887,t:1528143517302};\\\", \\\"{x:1180,y:878,t:1528143517318};\\\", \\\"{x:1184,y:869,t:1528143517335};\\\", \\\"{x:1187,y:863,t:1528143517352};\\\", \\\"{x:1190,y:857,t:1528143517368};\\\", \\\"{x:1193,y:852,t:1528143517385};\\\", \\\"{x:1195,y:850,t:1528143517402};\\\", \\\"{x:1198,y:847,t:1528143517418};\\\", \\\"{x:1200,y:845,t:1528143517435};\\\", \\\"{x:1202,y:842,t:1528143517452};\\\", \\\"{x:1203,y:837,t:1528143517469};\\\", \\\"{x:1204,y:834,t:1528143517486};\\\", \\\"{x:1205,y:833,t:1528143517502};\\\", \\\"{x:1205,y:832,t:1528143517533};\\\", \\\"{x:1206,y:832,t:1528143517758};\\\", \\\"{x:1208,y:832,t:1528143517769};\\\", \\\"{x:1209,y:833,t:1528143517786};\\\", \\\"{x:1214,y:837,t:1528143517802};\\\", \\\"{x:1216,y:841,t:1528143517819};\\\", \\\"{x:1219,y:847,t:1528143517835};\\\", \\\"{x:1221,y:851,t:1528143517852};\\\", \\\"{x:1226,y:863,t:1528143517869};\\\", \\\"{x:1230,y:872,t:1528143517886};\\\", \\\"{x:1236,y:879,t:1528143517903};\\\", \\\"{x:1239,y:882,t:1528143517919};\\\", \\\"{x:1242,y:886,t:1528143517936};\\\", \\\"{x:1244,y:888,t:1528143517953};\\\", \\\"{x:1245,y:890,t:1528143517968};\\\", \\\"{x:1248,y:894,t:1528143517986};\\\", \\\"{x:1251,y:897,t:1528143518003};\\\", \\\"{x:1255,y:901,t:1528143518019};\\\", \\\"{x:1257,y:903,t:1528143518036};\\\", \\\"{x:1261,y:906,t:1528143518054};\\\", \\\"{x:1263,y:908,t:1528143518070};\\\", \\\"{x:1263,y:909,t:1528143518086};\\\", \\\"{x:1264,y:911,t:1528143518103};\\\", \\\"{x:1266,y:914,t:1528143518120};\\\", \\\"{x:1268,y:917,t:1528143518136};\\\", \\\"{x:1271,y:920,t:1528143518153};\\\", \\\"{x:1273,y:926,t:1528143518170};\\\", \\\"{x:1275,y:927,t:1528143518186};\\\", \\\"{x:1275,y:929,t:1528143518203};\\\", \\\"{x:1276,y:930,t:1528143518220};\\\", \\\"{x:1276,y:931,t:1528143518236};\\\", \\\"{x:1277,y:933,t:1528143518254};\\\", \\\"{x:1277,y:934,t:1528143518269};\\\", \\\"{x:1277,y:937,t:1528143518286};\\\", \\\"{x:1277,y:939,t:1528143518303};\\\", \\\"{x:1277,y:940,t:1528143518320};\\\", \\\"{x:1277,y:942,t:1528143518341};\\\", \\\"{x:1277,y:943,t:1528143518353};\\\", \\\"{x:1277,y:945,t:1528143518370};\\\", \\\"{x:1277,y:946,t:1528143518389};\\\", \\\"{x:1277,y:947,t:1528143518403};\\\", \\\"{x:1277,y:948,t:1528143518420};\\\", \\\"{x:1278,y:950,t:1528143518437};\\\", \\\"{x:1278,y:951,t:1528143518453};\\\", \\\"{x:1278,y:952,t:1528143518477};\\\", \\\"{x:1278,y:953,t:1528143518486};\\\", \\\"{x:1279,y:954,t:1528143518503};\\\", \\\"{x:1280,y:954,t:1528143518520};\\\", \\\"{x:1280,y:955,t:1528143518537};\\\", \\\"{x:1280,y:956,t:1528143518553};\\\", \\\"{x:1282,y:958,t:1528143518570};\\\", \\\"{x:1283,y:960,t:1528143518587};\\\", \\\"{x:1284,y:962,t:1528143518604};\\\", \\\"{x:1285,y:963,t:1528143518620};\\\", \\\"{x:1285,y:964,t:1528143518638};\\\", \\\"{x:1285,y:965,t:1528143518934};\\\", \\\"{x:1283,y:963,t:1528143519150};\\\", \\\"{x:1280,y:960,t:1528143519156};\\\", \\\"{x:1276,y:956,t:1528143519171};\\\", \\\"{x:1259,y:936,t:1528143519187};\\\", \\\"{x:1233,y:906,t:1528143519203};\\\", \\\"{x:1182,y:855,t:1528143519221};\\\", \\\"{x:1143,y:830,t:1528143519237};\\\", \\\"{x:1105,y:808,t:1528143519255};\\\", \\\"{x:1075,y:793,t:1528143519271};\\\", \\\"{x:1022,y:761,t:1528143519288};\\\", \\\"{x:960,y:725,t:1528143519304};\\\", \\\"{x:888,y:680,t:1528143519321};\\\", \\\"{x:832,y:642,t:1528143519339};\\\", \\\"{x:779,y:606,t:1528143519357};\\\", \\\"{x:759,y:590,t:1528143519371};\\\", \\\"{x:742,y:578,t:1528143519386};\\\", \\\"{x:739,y:574,t:1528143519401};\\\", \\\"{x:735,y:569,t:1528143519418};\\\", \\\"{x:733,y:567,t:1528143519435};\\\", \\\"{x:731,y:564,t:1528143519451};\\\", \\\"{x:725,y:563,t:1528143519468};\\\", \\\"{x:721,y:563,t:1528143519487};\\\", \\\"{x:714,y:563,t:1528143519502};\\\", \\\"{x:708,y:559,t:1528143519518};\\\", \\\"{x:693,y:555,t:1528143519535};\\\", \\\"{x:672,y:545,t:1528143519552};\\\", \\\"{x:638,y:531,t:1528143519568};\\\", \\\"{x:615,y:523,t:1528143519584};\\\", \\\"{x:595,y:516,t:1528143519601};\\\", \\\"{x:585,y:514,t:1528143519618};\\\", \\\"{x:580,y:511,t:1528143519635};\\\", \\\"{x:578,y:511,t:1528143519652};\\\", \\\"{x:575,y:511,t:1528143519668};\\\", \\\"{x:574,y:510,t:1528143519686};\\\", \\\"{x:573,y:510,t:1528143519703};\\\", \\\"{x:572,y:509,t:1528143519719};\\\", \\\"{x:571,y:509,t:1528143519736};\\\", \\\"{x:570,y:508,t:1528143519806};\\\", \\\"{x:569,y:508,t:1528143519819};\\\", \\\"{x:568,y:507,t:1528143519836};\\\", \\\"{x:556,y:503,t:1528143519854};\\\", \\\"{x:546,y:500,t:1528143519868};\\\", \\\"{x:530,y:495,t:1528143519886};\\\", \\\"{x:516,y:492,t:1528143519902};\\\", \\\"{x:508,y:489,t:1528143519918};\\\", \\\"{x:502,y:488,t:1528143519937};\\\", \\\"{x:497,y:486,t:1528143519953};\\\", \\\"{x:496,y:486,t:1528143519969};\\\", \\\"{x:495,y:486,t:1528143519985};\\\", \\\"{x:494,y:486,t:1528143520021};\\\", \\\"{x:492,y:486,t:1528143520237};\\\", \\\"{x:488,y:486,t:1528143520253};\\\", \\\"{x:483,y:486,t:1528143520269};\\\", \\\"{x:480,y:486,t:1528143520286};\\\", \\\"{x:478,y:486,t:1528143520302};\\\", \\\"{x:475,y:486,t:1528143520320};\\\", \\\"{x:473,y:486,t:1528143520341};\\\", \\\"{x:472,y:486,t:1528143520357};\\\", \\\"{x:470,y:486,t:1528143520370};\\\", \\\"{x:469,y:486,t:1528143520389};\\\", \\\"{x:472,y:486,t:1528143520534};\\\", \\\"{x:474,y:486,t:1528143520541};\\\", \\\"{x:475,y:486,t:1528143520553};\\\", \\\"{x:476,y:486,t:1528143520569};\\\", \\\"{x:477,y:485,t:1528143520585};\\\", \\\"{x:479,y:485,t:1528143520602};\\\", \\\"{x:481,y:484,t:1528143520619};\\\", \\\"{x:484,y:483,t:1528143520635};\\\", \\\"{x:497,y:483,t:1528143520652};\\\", \\\"{x:503,y:482,t:1528143520669};\\\", \\\"{x:508,y:482,t:1528143520686};\\\", \\\"{x:519,y:482,t:1528143520703};\\\", \\\"{x:529,y:482,t:1528143520719};\\\", \\\"{x:536,y:481,t:1528143520736};\\\", \\\"{x:542,y:481,t:1528143520752};\\\", \\\"{x:548,y:481,t:1528143520769};\\\", \\\"{x:551,y:481,t:1528143520787};\\\", \\\"{x:552,y:481,t:1528143520802};\\\", \\\"{x:553,y:481,t:1528143520819};\\\", \\\"{x:554,y:481,t:1528143520885};\\\", \\\"{x:555,y:481,t:1528143520901};\\\", \\\"{x:556,y:481,t:1528143520916};\\\", \\\"{x:559,y:481,t:1528143520925};\\\", \\\"{x:563,y:481,t:1528143520937};\\\", \\\"{x:577,y:481,t:1528143520953};\\\", \\\"{x:606,y:481,t:1528143520969};\\\", \\\"{x:639,y:481,t:1528143520987};\\\", \\\"{x:700,y:498,t:1528143521003};\\\", \\\"{x:766,y:516,t:1528143521021};\\\", \\\"{x:870,y:552,t:1528143521036};\\\", \\\"{x:924,y:578,t:1528143521052};\\\", \\\"{x:951,y:600,t:1528143521070};\\\", \\\"{x:967,y:625,t:1528143521087};\\\", \\\"{x:978,y:653,t:1528143521102};\\\", \\\"{x:984,y:675,t:1528143521120};\\\", \\\"{x:985,y:690,t:1528143521137};\\\", \\\"{x:985,y:700,t:1528143521153};\\\", \\\"{x:982,y:711,t:1528143521169};\\\", \\\"{x:979,y:724,t:1528143521186};\\\", \\\"{x:978,y:732,t:1528143521203};\\\", \\\"{x:975,y:741,t:1528143521219};\\\", \\\"{x:975,y:748,t:1528143521236};\\\", \\\"{x:975,y:756,t:1528143521254};\\\", \\\"{x:981,y:765,t:1528143521269};\\\", \\\"{x:991,y:777,t:1528143521287};\\\", \\\"{x:1008,y:790,t:1528143521304};\\\", \\\"{x:1023,y:801,t:1528143521320};\\\", \\\"{x:1040,y:811,t:1528143521337};\\\", \\\"{x:1057,y:821,t:1528143521353};\\\", \\\"{x:1066,y:826,t:1528143521370};\\\", \\\"{x:1073,y:831,t:1528143521387};\\\", \\\"{x:1083,y:837,t:1528143521404};\\\", \\\"{x:1091,y:844,t:1528143521420};\\\", \\\"{x:1098,y:850,t:1528143521436};\\\", \\\"{x:1100,y:852,t:1528143521454};\\\", \\\"{x:1100,y:853,t:1528143521470};\\\", \\\"{x:1100,y:854,t:1528143521493};\\\", \\\"{x:1100,y:855,t:1528143521504};\\\", \\\"{x:1101,y:859,t:1528143521520};\\\", \\\"{x:1103,y:863,t:1528143521537};\\\", \\\"{x:1105,y:868,t:1528143521554};\\\", \\\"{x:1107,y:875,t:1528143521570};\\\", \\\"{x:1107,y:878,t:1528143521587};\\\", \\\"{x:1107,y:882,t:1528143521604};\\\", \\\"{x:1107,y:889,t:1528143521620};\\\", \\\"{x:1107,y:896,t:1528143521638};\\\", \\\"{x:1107,y:900,t:1528143521655};\\\", \\\"{x:1107,y:905,t:1528143521670};\\\", \\\"{x:1108,y:909,t:1528143521687};\\\", \\\"{x:1108,y:911,t:1528143521704};\\\", \\\"{x:1109,y:913,t:1528143521721};\\\", \\\"{x:1109,y:914,t:1528143521737};\\\", \\\"{x:1109,y:916,t:1528143521754};\\\", \\\"{x:1109,y:917,t:1528143521771};\\\", \\\"{x:1111,y:921,t:1528143521787};\\\", \\\"{x:1111,y:922,t:1528143521805};\\\", \\\"{x:1111,y:923,t:1528143521821};\\\", \\\"{x:1112,y:925,t:1528143521836};\\\", \\\"{x:1113,y:927,t:1528143521854};\\\", \\\"{x:1114,y:928,t:1528143521871};\\\", \\\"{x:1115,y:929,t:1528143521886};\\\", \\\"{x:1116,y:930,t:1528143521904};\\\", \\\"{x:1116,y:931,t:1528143521920};\\\", \\\"{x:1117,y:932,t:1528143521936};\\\", \\\"{x:1118,y:933,t:1528143521953};\\\", \\\"{x:1119,y:934,t:1528143521980};\\\", \\\"{x:1117,y:924,t:1528143522037};\\\", \\\"{x:1089,y:877,t:1528143522054};\\\", \\\"{x:1047,y:813,t:1528143522071};\\\", \\\"{x:1015,y:761,t:1528143522087};\\\", \\\"{x:972,y:692,t:1528143522104};\\\", \\\"{x:921,y:622,t:1528143522121};\\\", \\\"{x:879,y:561,t:1528143522138};\\\", \\\"{x:855,y:531,t:1528143522154};\\\", \\\"{x:836,y:510,t:1528143522170};\\\", \\\"{x:831,y:506,t:1528143522187};\\\", \\\"{x:830,y:505,t:1528143522203};\\\", \\\"{x:829,y:505,t:1528143522220};\\\", \\\"{x:823,y:505,t:1528143522237};\\\", \\\"{x:808,y:505,t:1528143522253};\\\", \\\"{x:782,y:505,t:1528143522270};\\\", \\\"{x:746,y:507,t:1528143522287};\\\", \\\"{x:716,y:509,t:1528143522304};\\\", \\\"{x:689,y:514,t:1528143522320};\\\", \\\"{x:679,y:515,t:1528143522338};\\\", \\\"{x:676,y:515,t:1528143522354};\\\", \\\"{x:675,y:515,t:1528143522437};\\\", \\\"{x:684,y:513,t:1528143522455};\\\", \\\"{x:748,y:525,t:1528143522474};\\\", \\\"{x:845,y:555,t:1528143522488};\\\", \\\"{x:947,y:596,t:1528143522504};\\\", \\\"{x:1044,y:646,t:1528143522521};\\\", \\\"{x:1137,y:699,t:1528143522538};\\\", \\\"{x:1187,y:739,t:1528143522554};\\\", \\\"{x:1199,y:761,t:1528143522570};\\\", \\\"{x:1199,y:777,t:1528143522588};\\\", \\\"{x:1194,y:799,t:1528143522605};\\\", \\\"{x:1190,y:810,t:1528143522620};\\\", \\\"{x:1188,y:815,t:1528143522637};\\\", \\\"{x:1188,y:819,t:1528143522654};\\\", \\\"{x:1187,y:824,t:1528143522671};\\\", \\\"{x:1186,y:827,t:1528143522687};\\\", \\\"{x:1185,y:830,t:1528143522705};\\\", \\\"{x:1181,y:835,t:1528143522722};\\\", \\\"{x:1179,y:841,t:1528143522739};\\\", \\\"{x:1177,y:849,t:1528143522755};\\\", \\\"{x:1176,y:855,t:1528143522771};\\\", \\\"{x:1173,y:863,t:1528143522788};\\\", \\\"{x:1169,y:876,t:1528143522805};\\\", \\\"{x:1164,y:888,t:1528143522822};\\\", \\\"{x:1158,y:902,t:1528143522839};\\\", \\\"{x:1154,y:917,t:1528143522856};\\\", \\\"{x:1149,y:928,t:1528143522872};\\\", \\\"{x:1146,y:937,t:1528143522889};\\\", \\\"{x:1143,y:945,t:1528143522905};\\\", \\\"{x:1143,y:949,t:1528143522922};\\\", \\\"{x:1143,y:958,t:1528143522941};\\\", \\\"{x:1143,y:960,t:1528143522956};\\\", \\\"{x:1143,y:963,t:1528143522971};\\\", \\\"{x:1143,y:965,t:1528143522989};\\\", \\\"{x:1143,y:966,t:1528143523006};\\\", \\\"{x:1143,y:965,t:1528143523053};\\\", \\\"{x:1146,y:961,t:1528143523060};\\\", \\\"{x:1149,y:955,t:1528143523072};\\\", \\\"{x:1158,y:941,t:1528143523089};\\\", \\\"{x:1172,y:924,t:1528143523105};\\\", \\\"{x:1192,y:896,t:1528143523123};\\\", \\\"{x:1213,y:867,t:1528143523139};\\\", \\\"{x:1237,y:837,t:1528143523155};\\\", \\\"{x:1270,y:805,t:1528143523173};\\\", \\\"{x:1281,y:792,t:1528143523189};\\\", \\\"{x:1282,y:791,t:1528143523206};\\\", \\\"{x:1282,y:792,t:1528143523254};\\\", \\\"{x:1281,y:799,t:1528143523261};\\\", \\\"{x:1280,y:809,t:1528143523272};\\\", \\\"{x:1276,y:826,t:1528143523290};\\\", \\\"{x:1275,y:841,t:1528143523306};\\\", \\\"{x:1270,y:857,t:1528143523323};\\\", \\\"{x:1266,y:870,t:1528143523340};\\\", \\\"{x:1262,y:884,t:1528143523355};\\\", \\\"{x:1260,y:907,t:1528143523373};\\\", \\\"{x:1260,y:919,t:1528143523389};\\\", \\\"{x:1260,y:930,t:1528143523407};\\\", \\\"{x:1261,y:940,t:1528143523423};\\\", \\\"{x:1263,y:949,t:1528143523440};\\\", \\\"{x:1265,y:957,t:1528143523457};\\\", \\\"{x:1266,y:961,t:1528143523473};\\\", \\\"{x:1266,y:966,t:1528143523490};\\\", \\\"{x:1266,y:968,t:1528143523506};\\\", \\\"{x:1266,y:971,t:1528143523524};\\\", \\\"{x:1266,y:974,t:1528143523540};\\\", \\\"{x:1266,y:975,t:1528143523565};\\\", \\\"{x:1266,y:974,t:1528143523669};\\\", \\\"{x:1266,y:973,t:1528143523685};\\\", \\\"{x:1266,y:971,t:1528143523693};\\\", \\\"{x:1266,y:970,t:1528143523707};\\\", \\\"{x:1266,y:969,t:1528143523724};\\\", \\\"{x:1266,y:967,t:1528143523742};\\\", \\\"{x:1265,y:963,t:1528143523933};\\\", \\\"{x:1263,y:957,t:1528143523941};\\\", \\\"{x:1253,y:934,t:1528143523958};\\\", \\\"{x:1232,y:901,t:1528143523976};\\\", \\\"{x:1218,y:882,t:1528143523992};\\\", \\\"{x:1213,y:873,t:1528143524008};\\\", \\\"{x:1210,y:869,t:1528143524025};\\\", \\\"{x:1209,y:869,t:1528143524041};\\\", \\\"{x:1209,y:868,t:1528143524070};\\\", \\\"{x:1208,y:868,t:1528143524078};\\\", \\\"{x:1206,y:870,t:1528143524091};\\\", \\\"{x:1198,y:879,t:1528143524108};\\\", \\\"{x:1180,y:901,t:1528143524125};\\\", \\\"{x:1166,y:923,t:1528143524142};\\\", \\\"{x:1152,y:948,t:1528143524158};\\\", \\\"{x:1141,y:964,t:1528143524176};\\\", \\\"{x:1138,y:970,t:1528143524193};\\\", \\\"{x:1137,y:971,t:1528143524208};\\\", \\\"{x:1137,y:967,t:1528143524245};\\\", \\\"{x:1138,y:960,t:1528143524259};\\\", \\\"{x:1148,y:939,t:1528143524275};\\\", \\\"{x:1158,y:921,t:1528143524292};\\\", \\\"{x:1178,y:891,t:1528143524309};\\\", \\\"{x:1191,y:874,t:1528143524326};\\\", \\\"{x:1203,y:853,t:1528143524342};\\\", \\\"{x:1211,y:832,t:1528143524362};\\\", \\\"{x:1218,y:814,t:1528143524375};\\\", \\\"{x:1223,y:802,t:1528143524392};\\\", \\\"{x:1226,y:797,t:1528143524408};\\\", \\\"{x:1227,y:796,t:1528143524426};\\\", \\\"{x:1229,y:796,t:1528143524485};\\\", \\\"{x:1229,y:798,t:1528143524493};\\\", \\\"{x:1232,y:808,t:1528143524509};\\\", \\\"{x:1235,y:822,t:1528143524526};\\\", \\\"{x:1241,y:841,t:1528143524543};\\\", \\\"{x:1250,y:863,t:1528143524559};\\\", \\\"{x:1255,y:884,t:1528143524576};\\\", \\\"{x:1263,y:904,t:1528143524593};\\\", \\\"{x:1272,y:921,t:1528143524609};\\\", \\\"{x:1277,y:934,t:1528143524625};\\\", \\\"{x:1280,y:940,t:1528143524643};\\\", \\\"{x:1281,y:943,t:1528143524659};\\\", \\\"{x:1282,y:945,t:1528143524676};\\\", \\\"{x:1282,y:948,t:1528143524693};\\\", \\\"{x:1282,y:950,t:1528143524710};\\\", \\\"{x:1282,y:951,t:1528143524869};\\\", \\\"{x:1281,y:951,t:1528143524885};\\\", \\\"{x:1281,y:950,t:1528143524990};\\\", \\\"{x:1281,y:949,t:1528143524997};\\\", \\\"{x:1281,y:946,t:1528143525011};\\\", \\\"{x:1281,y:941,t:1528143525028};\\\", \\\"{x:1284,y:931,t:1528143525044};\\\", \\\"{x:1289,y:921,t:1528143525060};\\\", \\\"{x:1297,y:911,t:1528143525077};\\\", \\\"{x:1300,y:906,t:1528143525095};\\\", \\\"{x:1303,y:901,t:1528143525111};\\\", \\\"{x:1305,y:898,t:1528143525128};\\\", \\\"{x:1308,y:892,t:1528143525144};\\\", \\\"{x:1313,y:885,t:1528143525160};\\\", \\\"{x:1315,y:879,t:1528143525177};\\\", \\\"{x:1318,y:873,t:1528143525194};\\\", \\\"{x:1321,y:866,t:1528143525212};\\\", \\\"{x:1324,y:862,t:1528143525227};\\\", \\\"{x:1326,y:858,t:1528143525244};\\\", \\\"{x:1330,y:849,t:1528143525261};\\\", \\\"{x:1332,y:840,t:1528143525278};\\\", \\\"{x:1334,y:833,t:1528143525295};\\\", \\\"{x:1336,y:828,t:1528143525311};\\\", \\\"{x:1337,y:824,t:1528143525329};\\\", \\\"{x:1341,y:816,t:1528143525345};\\\", \\\"{x:1344,y:810,t:1528143525362};\\\", \\\"{x:1350,y:800,t:1528143525379};\\\", \\\"{x:1355,y:791,t:1528143525395};\\\", \\\"{x:1360,y:785,t:1528143525411};\\\", \\\"{x:1363,y:781,t:1528143525429};\\\", \\\"{x:1365,y:776,t:1528143525446};\\\", \\\"{x:1366,y:775,t:1528143525462};\\\", \\\"{x:1369,y:772,t:1528143525479};\\\", \\\"{x:1371,y:768,t:1528143525496};\\\", \\\"{x:1374,y:764,t:1528143525511};\\\", \\\"{x:1378,y:760,t:1528143525529};\\\", \\\"{x:1383,y:754,t:1528143525546};\\\", \\\"{x:1386,y:750,t:1528143525563};\\\", \\\"{x:1390,y:744,t:1528143525578};\\\", \\\"{x:1394,y:738,t:1528143525595};\\\", \\\"{x:1401,y:724,t:1528143525612};\\\", \\\"{x:1409,y:712,t:1528143525628};\\\", \\\"{x:1421,y:691,t:1528143525646};\\\", \\\"{x:1429,y:676,t:1528143525662};\\\", \\\"{x:1437,y:663,t:1528143525679};\\\", \\\"{x:1443,y:651,t:1528143525696};\\\", \\\"{x:1446,y:643,t:1528143525712};\\\", \\\"{x:1446,y:642,t:1528143525729};\\\", \\\"{x:1440,y:643,t:1528143525789};\\\", \\\"{x:1423,y:650,t:1528143525796};\\\", \\\"{x:1392,y:663,t:1528143525812};\\\", \\\"{x:1217,y:695,t:1528143525829};\\\", \\\"{x:1045,y:695,t:1528143525846};\\\", \\\"{x:891,y:695,t:1528143525861};\\\", \\\"{x:770,y:686,t:1528143525878};\\\", \\\"{x:702,y:674,t:1528143525896};\\\", \\\"{x:669,y:666,t:1528143525912};\\\", \\\"{x:658,y:662,t:1528143525929};\\\", \\\"{x:656,y:661,t:1528143525946};\\\", \\\"{x:655,y:660,t:1528143525973};\\\", \\\"{x:655,y:659,t:1528143525997};\\\", \\\"{x:654,y:654,t:1528143526013};\\\", \\\"{x:654,y:647,t:1528143526029};\\\", \\\"{x:651,y:639,t:1528143526046};\\\", \\\"{x:647,y:631,t:1528143526062};\\\", \\\"{x:643,y:625,t:1528143526074};\\\", \\\"{x:626,y:615,t:1528143526091};\\\", \\\"{x:584,y:603,t:1528143526107};\\\", \\\"{x:551,y:599,t:1528143526123};\\\", \\\"{x:525,y:595,t:1528143526140};\\\", \\\"{x:514,y:593,t:1528143526156};\\\", \\\"{x:506,y:591,t:1528143526173};\\\", \\\"{x:496,y:590,t:1528143526192};\\\", \\\"{x:483,y:590,t:1528143526207};\\\", \\\"{x:476,y:589,t:1528143526223};\\\", \\\"{x:474,y:589,t:1528143526241};\\\", \\\"{x:472,y:589,t:1528143526300};\\\", \\\"{x:470,y:589,t:1528143526309};\\\", \\\"{x:467,y:588,t:1528143526324};\\\", \\\"{x:459,y:586,t:1528143526340};\\\", \\\"{x:448,y:586,t:1528143526357};\\\", \\\"{x:443,y:586,t:1528143526374};\\\", \\\"{x:439,y:586,t:1528143526390};\\\", \\\"{x:436,y:585,t:1528143526408};\\\", \\\"{x:430,y:583,t:1528143526424};\\\", \\\"{x:423,y:581,t:1528143526440};\\\", \\\"{x:414,y:578,t:1528143526457};\\\", \\\"{x:410,y:578,t:1528143526474};\\\", \\\"{x:407,y:576,t:1528143526491};\\\", \\\"{x:405,y:576,t:1528143526508};\\\", \\\"{x:404,y:576,t:1528143526524};\\\", \\\"{x:402,y:574,t:1528143526543};\\\", \\\"{x:400,y:573,t:1528143526558};\\\", \\\"{x:397,y:572,t:1528143526574};\\\", \\\"{x:393,y:570,t:1528143526591};\\\", \\\"{x:390,y:568,t:1528143526607};\\\", \\\"{x:389,y:567,t:1528143526638};\\\", \\\"{x:392,y:569,t:1528143526964};\\\", \\\"{x:407,y:579,t:1528143526975};\\\", \\\"{x:470,y:617,t:1528143526991};\\\", \\\"{x:574,y:673,t:1528143527008};\\\", \\\"{x:702,y:745,t:1528143527024};\\\", \\\"{x:855,y:828,t:1528143527041};\\\", \\\"{x:978,y:895,t:1528143527058};\\\", \\\"{x:1079,y:952,t:1528143527075};\\\", \\\"{x:1144,y:989,t:1528143527090};\\\", \\\"{x:1208,y:1028,t:1528143527108};\\\", \\\"{x:1252,y:1062,t:1528143527125};\\\", \\\"{x:1259,y:1067,t:1528143527141};\\\", \\\"{x:1259,y:1068,t:1528143527158};\\\", \\\"{x:1259,y:1069,t:1528143527181};\\\", \\\"{x:1256,y:1070,t:1528143527196};\\\", \\\"{x:1252,y:1071,t:1528143527208};\\\", \\\"{x:1249,y:1072,t:1528143527225};\\\", \\\"{x:1244,y:1072,t:1528143527240};\\\", \\\"{x:1230,y:1070,t:1528143527258};\\\", \\\"{x:1211,y:1060,t:1528143527275};\\\", \\\"{x:1176,y:1041,t:1528143527291};\\\", \\\"{x:1133,y:1016,t:1528143527308};\\\", \\\"{x:1112,y:995,t:1528143527324};\\\", \\\"{x:1108,y:984,t:1528143527342};\\\", \\\"{x:1108,y:972,t:1528143527358};\\\", \\\"{x:1118,y:959,t:1528143527375};\\\", \\\"{x:1129,y:949,t:1528143527392};\\\", \\\"{x:1140,y:943,t:1528143527408};\\\", \\\"{x:1145,y:941,t:1528143527425};\\\", \\\"{x:1144,y:941,t:1528143527525};\\\", \\\"{x:1139,y:943,t:1528143527542};\\\", \\\"{x:1136,y:945,t:1528143527557};\\\", \\\"{x:1133,y:948,t:1528143527574};\\\", \\\"{x:1133,y:949,t:1528143527636};\\\", \\\"{x:1133,y:950,t:1528143527661};\\\", \\\"{x:1133,y:951,t:1528143527675};\\\", \\\"{x:1133,y:956,t:1528143527691};\\\", \\\"{x:1133,y:959,t:1528143527708};\\\", \\\"{x:1133,y:961,t:1528143527725};\\\", \\\"{x:1133,y:962,t:1528143527742};\\\", \\\"{x:1134,y:962,t:1528143527812};\\\", \\\"{x:1136,y:962,t:1528143527825};\\\", \\\"{x:1143,y:955,t:1528143527842};\\\", \\\"{x:1154,y:938,t:1528143527858};\\\", \\\"{x:1167,y:917,t:1528143527875};\\\", \\\"{x:1180,y:894,t:1528143527892};\\\", \\\"{x:1192,y:874,t:1528143527909};\\\", \\\"{x:1195,y:869,t:1528143527925};\\\", \\\"{x:1196,y:867,t:1528143527941};\\\", \\\"{x:1197,y:865,t:1528143527959};\\\", \\\"{x:1198,y:863,t:1528143527975};\\\", \\\"{x:1199,y:862,t:1528143527993};\\\", \\\"{x:1201,y:861,t:1528143528010};\\\", \\\"{x:1203,y:859,t:1528143528025};\\\", \\\"{x:1205,y:858,t:1528143528042};\\\", \\\"{x:1206,y:857,t:1528143528085};\\\", \\\"{x:1207,y:857,t:1528143528109};\\\", \\\"{x:1208,y:856,t:1528143528149};\\\", \\\"{x:1209,y:856,t:1528143528189};\\\", \\\"{x:1212,y:856,t:1528143528205};\\\", \\\"{x:1215,y:862,t:1528143528213};\\\", \\\"{x:1219,y:868,t:1528143528225};\\\", \\\"{x:1230,y:887,t:1528143528242};\\\", \\\"{x:1240,y:906,t:1528143528259};\\\", \\\"{x:1249,y:928,t:1528143528275};\\\", \\\"{x:1258,y:944,t:1528143528292};\\\", \\\"{x:1266,y:954,t:1528143528308};\\\", \\\"{x:1268,y:956,t:1528143528325};\\\", \\\"{x:1269,y:957,t:1528143528348};\\\", \\\"{x:1270,y:957,t:1528143528359};\\\", \\\"{x:1272,y:959,t:1528143528375};\\\", \\\"{x:1273,y:960,t:1528143528392};\\\", \\\"{x:1273,y:961,t:1528143528409};\\\", \\\"{x:1275,y:962,t:1528143528426};\\\", \\\"{x:1277,y:961,t:1528143528541};\\\", \\\"{x:1283,y:950,t:1528143528559};\\\", \\\"{x:1288,y:940,t:1528143528577};\\\", \\\"{x:1293,y:930,t:1528143528593};\\\", \\\"{x:1295,y:921,t:1528143528610};\\\", \\\"{x:1296,y:912,t:1528143528627};\\\", \\\"{x:1299,y:903,t:1528143528643};\\\", \\\"{x:1301,y:897,t:1528143528660};\\\", \\\"{x:1302,y:889,t:1528143528677};\\\", \\\"{x:1305,y:881,t:1528143528693};\\\", \\\"{x:1313,y:862,t:1528143528709};\\\", \\\"{x:1323,y:847,t:1528143528727};\\\", \\\"{x:1333,y:832,t:1528143528743};\\\", \\\"{x:1344,y:819,t:1528143528759};\\\", \\\"{x:1350,y:810,t:1528143528776};\\\", \\\"{x:1354,y:804,t:1528143528792};\\\", \\\"{x:1356,y:801,t:1528143528810};\\\", \\\"{x:1358,y:798,t:1528143528827};\\\", \\\"{x:1359,y:798,t:1528143528843};\\\", \\\"{x:1362,y:794,t:1528143528860};\\\", \\\"{x:1364,y:791,t:1528143528876};\\\", \\\"{x:1367,y:787,t:1528143528892};\\\", \\\"{x:1367,y:786,t:1528143528910};\\\", \\\"{x:1364,y:786,t:1528143529285};\\\", \\\"{x:1359,y:789,t:1528143529293};\\\", \\\"{x:1350,y:804,t:1528143529310};\\\", \\\"{x:1334,y:828,t:1528143529327};\\\", \\\"{x:1314,y:852,t:1528143529343};\\\", \\\"{x:1296,y:874,t:1528143529359};\\\", \\\"{x:1281,y:889,t:1528143529376};\\\", \\\"{x:1270,y:899,t:1528143529393};\\\", \\\"{x:1259,y:908,t:1528143529408};\\\", \\\"{x:1252,y:914,t:1528143529426};\\\", \\\"{x:1244,y:919,t:1528143529443};\\\", \\\"{x:1238,y:925,t:1528143529459};\\\", \\\"{x:1229,y:932,t:1528143529476};\\\", \\\"{x:1220,y:937,t:1528143529492};\\\", \\\"{x:1212,y:940,t:1528143529510};\\\", \\\"{x:1204,y:943,t:1528143529526};\\\", \\\"{x:1199,y:945,t:1528143529543};\\\", \\\"{x:1193,y:946,t:1528143529560};\\\", \\\"{x:1191,y:947,t:1528143529576};\\\", \\\"{x:1190,y:947,t:1528143529593};\\\", \\\"{x:1189,y:947,t:1528143529611};\\\", \\\"{x:1188,y:947,t:1528143529626};\\\", \\\"{x:1185,y:947,t:1528143529643};\\\", \\\"{x:1181,y:947,t:1528143529660};\\\", \\\"{x:1176,y:948,t:1528143529676};\\\", \\\"{x:1166,y:952,t:1528143529693};\\\", \\\"{x:1161,y:953,t:1528143529710};\\\", \\\"{x:1160,y:955,t:1528143529726};\\\", \\\"{x:1159,y:955,t:1528143529743};\\\", \\\"{x:1158,y:955,t:1528143530718};\\\", \\\"{x:1158,y:956,t:1528143530797};\\\", \\\"{x:1158,y:957,t:1528143530811};\\\", \\\"{x:1158,y:958,t:1528143530837};\\\", \\\"{x:1158,y:959,t:1528143531045};\\\", \\\"{x:1156,y:960,t:1528143531061};\\\", \\\"{x:1156,y:961,t:1528143531078};\\\", \\\"{x:1154,y:964,t:1528143531095};\\\", \\\"{x:1153,y:965,t:1528143531125};\\\", \\\"{x:1153,y:966,t:1528143531157};\\\", \\\"{x:1152,y:966,t:1528143531205};\\\", \\\"{x:1152,y:967,t:1528143531589};\\\", \\\"{x:1150,y:967,t:1528143531605};\\\", \\\"{x:1146,y:967,t:1528143531613};\\\", \\\"{x:1139,y:966,t:1528143531629};\\\", \\\"{x:1091,y:939,t:1528143531644};\\\", \\\"{x:1009,y:892,t:1528143531661};\\\", \\\"{x:877,y:815,t:1528143531679};\\\", \\\"{x:767,y:743,t:1528143531695};\\\", \\\"{x:690,y:680,t:1528143531712};\\\", \\\"{x:661,y:643,t:1528143531729};\\\", \\\"{x:657,y:630,t:1528143531743};\\\", \\\"{x:656,y:621,t:1528143531761};\\\", \\\"{x:656,y:620,t:1528143531777};\\\", \\\"{x:656,y:619,t:1528143531990};\\\", \\\"{x:675,y:623,t:1528143531997};\\\", \\\"{x:767,y:667,t:1528143532012};\\\", \\\"{x:899,y:721,t:1528143532028};\\\", \\\"{x:1055,y:776,t:1528143532044};\\\", \\\"{x:1181,y:808,t:1528143532062};\\\", \\\"{x:1242,y:817,t:1528143532078};\\\", \\\"{x:1249,y:819,t:1528143532095};\\\", \\\"{x:1249,y:820,t:1528143532132};\\\", \\\"{x:1247,y:823,t:1528143532145};\\\", \\\"{x:1240,y:828,t:1528143532162};\\\", \\\"{x:1234,y:837,t:1528143532179};\\\", \\\"{x:1232,y:841,t:1528143532195};\\\", \\\"{x:1228,y:845,t:1528143532212};\\\", \\\"{x:1223,y:848,t:1528143532229};\\\", \\\"{x:1221,y:848,t:1528143532245};\\\", \\\"{x:1220,y:848,t:1528143532277};\\\", \\\"{x:1218,y:848,t:1528143532293};\\\", \\\"{x:1215,y:848,t:1528143532301};\\\", \\\"{x:1214,y:844,t:1528143532312};\\\", \\\"{x:1211,y:841,t:1528143532330};\\\", \\\"{x:1208,y:838,t:1528143532346};\\\", \\\"{x:1207,y:836,t:1528143532362};\\\", \\\"{x:1206,y:836,t:1528143532438};\\\", \\\"{x:1205,y:836,t:1528143532446};\\\", \\\"{x:1194,y:846,t:1528143532462};\\\", \\\"{x:1183,y:859,t:1528143532480};\\\", \\\"{x:1176,y:869,t:1528143532496};\\\", \\\"{x:1172,y:874,t:1528143532513};\\\", \\\"{x:1170,y:880,t:1528143532530};\\\", \\\"{x:1167,y:888,t:1528143532545};\\\", \\\"{x:1162,y:899,t:1528143532562};\\\", \\\"{x:1153,y:912,t:1528143532580};\\\", \\\"{x:1147,y:923,t:1528143532596};\\\", \\\"{x:1143,y:931,t:1528143532613};\\\", \\\"{x:1139,y:941,t:1528143532629};\\\", \\\"{x:1138,y:944,t:1528143532646};\\\", \\\"{x:1138,y:945,t:1528143532670};\\\", \\\"{x:1138,y:946,t:1528143532725};\\\", \\\"{x:1138,y:947,t:1528143532741};\\\", \\\"{x:1139,y:947,t:1528143532909};\\\", \\\"{x:1140,y:946,t:1528143532917};\\\", \\\"{x:1142,y:944,t:1528143532930};\\\", \\\"{x:1143,y:942,t:1528143532946};\\\", \\\"{x:1144,y:940,t:1528143532963};\\\", \\\"{x:1145,y:940,t:1528143533069};\\\", \\\"{x:1146,y:939,t:1528143533080};\\\", \\\"{x:1148,y:936,t:1528143533097};\\\", \\\"{x:1150,y:934,t:1528143533113};\\\", \\\"{x:1153,y:926,t:1528143533129};\\\", \\\"{x:1157,y:920,t:1528143533147};\\\", \\\"{x:1162,y:913,t:1528143533163};\\\", \\\"{x:1166,y:908,t:1528143533179};\\\", \\\"{x:1171,y:899,t:1528143533197};\\\", \\\"{x:1175,y:893,t:1528143533213};\\\", \\\"{x:1178,y:886,t:1528143533229};\\\", \\\"{x:1180,y:881,t:1528143533246};\\\", \\\"{x:1183,y:875,t:1528143533264};\\\", \\\"{x:1186,y:868,t:1528143533279};\\\", \\\"{x:1188,y:864,t:1528143533297};\\\", \\\"{x:1191,y:857,t:1528143533314};\\\", \\\"{x:1194,y:851,t:1528143533330};\\\", \\\"{x:1196,y:844,t:1528143533346};\\\", \\\"{x:1200,y:838,t:1528143533363};\\\", \\\"{x:1203,y:835,t:1528143533379};\\\", \\\"{x:1205,y:832,t:1528143533396};\\\", \\\"{x:1205,y:831,t:1528143533413};\\\", \\\"{x:1207,y:831,t:1528143533630};\\\", \\\"{x:1210,y:836,t:1528143533647};\\\", \\\"{x:1213,y:839,t:1528143533664};\\\", \\\"{x:1217,y:845,t:1528143533680};\\\", \\\"{x:1221,y:854,t:1528143533696};\\\", \\\"{x:1226,y:861,t:1528143533714};\\\", \\\"{x:1232,y:870,t:1528143533730};\\\", \\\"{x:1240,y:878,t:1528143533747};\\\", \\\"{x:1247,y:886,t:1528143533763};\\\", \\\"{x:1250,y:890,t:1528143533780};\\\", \\\"{x:1253,y:893,t:1528143533797};\\\", \\\"{x:1255,y:895,t:1528143533813};\\\", \\\"{x:1256,y:895,t:1528143533829};\\\", \\\"{x:1256,y:896,t:1528143533847};\\\", \\\"{x:1257,y:899,t:1528143533864};\\\", \\\"{x:1259,y:904,t:1528143533881};\\\", \\\"{x:1261,y:909,t:1528143533897};\\\", \\\"{x:1262,y:913,t:1528143533914};\\\", \\\"{x:1263,y:915,t:1528143533931};\\\", \\\"{x:1263,y:917,t:1528143533946};\\\", \\\"{x:1264,y:920,t:1528143533964};\\\", \\\"{x:1265,y:926,t:1528143533981};\\\", \\\"{x:1266,y:932,t:1528143533997};\\\", \\\"{x:1268,y:938,t:1528143534013};\\\", \\\"{x:1271,y:946,t:1528143534031};\\\", \\\"{x:1274,y:953,t:1528143534047};\\\", \\\"{x:1279,y:959,t:1528143534064};\\\", \\\"{x:1280,y:961,t:1528143534080};\\\", \\\"{x:1281,y:963,t:1528143534097};\\\", \\\"{x:1281,y:962,t:1528143536821};\\\", \\\"{x:1282,y:960,t:1528143536853};\\\", \\\"{x:1283,y:960,t:1528143536893};\\\", \\\"{x:1283,y:959,t:1528143536965};\\\", \\\"{x:1283,y:958,t:1528143536989};\\\", \\\"{x:1284,y:958,t:1528143537013};\\\", \\\"{x:1285,y:958,t:1528143537029};\\\", \\\"{x:1285,y:957,t:1528143537036};\\\", \\\"{x:1286,y:957,t:1528143537126};\\\", \\\"{x:1286,y:955,t:1528143537165};\\\", \\\"{x:1286,y:954,t:1528143537213};\\\", \\\"{x:1287,y:952,t:1528143537229};\\\", \\\"{x:1287,y:951,t:1528143537269};\\\", \\\"{x:1288,y:950,t:1528143537282};\\\", \\\"{x:1288,y:949,t:1528143537298};\\\", \\\"{x:1289,y:949,t:1528143537316};\\\", \\\"{x:1289,y:948,t:1528143537332};\\\", \\\"{x:1289,y:946,t:1528143537349};\\\", \\\"{x:1289,y:945,t:1528143537366};\\\", \\\"{x:1290,y:945,t:1528143537383};\\\", \\\"{x:1290,y:943,t:1528143537399};\\\", \\\"{x:1291,y:941,t:1528143537415};\\\", \\\"{x:1292,y:940,t:1528143537433};\\\", \\\"{x:1293,y:938,t:1528143537449};\\\", \\\"{x:1293,y:935,t:1528143537466};\\\", \\\"{x:1297,y:928,t:1528143537483};\\\", \\\"{x:1298,y:925,t:1528143537499};\\\", \\\"{x:1299,y:922,t:1528143537516};\\\", \\\"{x:1301,y:918,t:1528143537533};\\\", \\\"{x:1304,y:913,t:1528143537549};\\\", \\\"{x:1304,y:911,t:1528143537565};\\\", \\\"{x:1307,y:906,t:1528143537583};\\\", \\\"{x:1311,y:902,t:1528143537599};\\\", \\\"{x:1311,y:900,t:1528143537616};\\\", \\\"{x:1312,y:896,t:1528143537633};\\\", \\\"{x:1315,y:892,t:1528143537649};\\\", \\\"{x:1317,y:890,t:1528143537666};\\\", \\\"{x:1320,y:884,t:1528143537682};\\\", \\\"{x:1323,y:880,t:1528143537699};\\\", \\\"{x:1325,y:876,t:1528143537715};\\\", \\\"{x:1327,y:870,t:1528143537732};\\\", \\\"{x:1329,y:867,t:1528143537749};\\\", \\\"{x:1334,y:862,t:1528143537767};\\\", \\\"{x:1336,y:857,t:1528143537783};\\\", \\\"{x:1339,y:849,t:1528143537799};\\\", \\\"{x:1342,y:842,t:1528143537816};\\\", \\\"{x:1344,y:838,t:1528143537833};\\\", \\\"{x:1345,y:835,t:1528143537848};\\\", \\\"{x:1346,y:833,t:1528143537866};\\\", \\\"{x:1346,y:831,t:1528143537884};\\\", \\\"{x:1348,y:827,t:1528143537899};\\\", \\\"{x:1348,y:823,t:1528143537916};\\\", \\\"{x:1348,y:821,t:1528143537933};\\\", \\\"{x:1348,y:820,t:1528143537950};\\\", \\\"{x:1349,y:818,t:1528143537966};\\\", \\\"{x:1349,y:817,t:1528143537982};\\\", \\\"{x:1350,y:815,t:1528143538004};\\\", \\\"{x:1350,y:814,t:1528143538028};\\\", \\\"{x:1351,y:813,t:1528143538044};\\\", \\\"{x:1351,y:812,t:1528143538084};\\\", \\\"{x:1352,y:812,t:1528143538100};\\\", \\\"{x:1352,y:810,t:1528143538116};\\\", \\\"{x:1353,y:808,t:1528143538148};\\\", \\\"{x:1354,y:808,t:1528143538156};\\\", \\\"{x:1354,y:807,t:1528143538172};\\\", \\\"{x:1355,y:806,t:1528143538182};\\\", \\\"{x:1355,y:805,t:1528143538199};\\\", \\\"{x:1356,y:805,t:1528143538220};\\\", \\\"{x:1356,y:804,t:1528143538236};\\\", \\\"{x:1357,y:802,t:1528143538252};\\\", \\\"{x:1357,y:801,t:1528143538265};\\\", \\\"{x:1358,y:801,t:1528143538284};\\\", \\\"{x:1358,y:800,t:1528143538301};\\\", \\\"{x:1359,y:799,t:1528143538317};\\\", \\\"{x:1360,y:798,t:1528143538333};\\\", \\\"{x:1361,y:797,t:1528143538349};\\\", \\\"{x:1361,y:796,t:1528143538366};\\\", \\\"{x:1362,y:795,t:1528143538397};\\\", \\\"{x:1363,y:794,t:1528143538421};\\\", \\\"{x:1363,y:793,t:1528143538446};\\\", \\\"{x:1364,y:793,t:1528143538461};\\\", \\\"{x:1364,y:791,t:1528143538477};\\\", \\\"{x:1365,y:790,t:1528143538509};\\\", \\\"{x:1366,y:789,t:1528143538541};\\\", \\\"{x:1366,y:788,t:1528143538590};\\\", \\\"{x:1367,y:788,t:1528143538638};\\\", \\\"{x:1368,y:786,t:1528143538669};\\\", \\\"{x:1369,y:785,t:1528143538742};\\\", \\\"{x:1369,y:784,t:1528143538758};\\\", \\\"{x:1370,y:783,t:1528143538773};\\\", \\\"{x:1371,y:782,t:1528143538814};\\\", \\\"{x:1372,y:781,t:1528143538828};\\\", \\\"{x:1373,y:780,t:1528143538877};\\\", \\\"{x:1373,y:779,t:1528143538909};\\\", \\\"{x:1374,y:778,t:1528143538941};\\\", \\\"{x:1375,y:777,t:1528143538966};\\\", \\\"{x:1375,y:776,t:1528143538998};\\\", \\\"{x:1376,y:776,t:1528143539062};\\\", \\\"{x:1376,y:775,t:1528143539526};\\\", \\\"{x:1372,y:775,t:1528143539533};\\\", \\\"{x:1343,y:781,t:1528143539550};\\\", \\\"{x:1288,y:787,t:1528143539566};\\\", \\\"{x:1202,y:797,t:1528143539584};\\\", \\\"{x:1102,y:797,t:1528143539600};\\\", \\\"{x:980,y:797,t:1528143539616};\\\", \\\"{x:856,y:797,t:1528143539633};\\\", \\\"{x:745,y:784,t:1528143539649};\\\", \\\"{x:678,y:773,t:1528143539666};\\\", \\\"{x:650,y:768,t:1528143539683};\\\", \\\"{x:646,y:768,t:1528143539700};\\\", \\\"{x:645,y:768,t:1528143539756};\\\", \\\"{x:645,y:767,t:1528143539767};\\\", \\\"{x:645,y:764,t:1528143539784};\\\", \\\"{x:646,y:758,t:1528143539801};\\\", \\\"{x:647,y:755,t:1528143539817};\\\", \\\"{x:647,y:754,t:1528143539834};\\\", \\\"{x:647,y:753,t:1528143539852};\\\", \\\"{x:646,y:752,t:1528143539885};\\\", \\\"{x:636,y:750,t:1528143539900};\\\", \\\"{x:622,y:746,t:1528143539917};\\\", \\\"{x:613,y:745,t:1528143539933};\\\", \\\"{x:608,y:743,t:1528143539950};\\\", \\\"{x:605,y:742,t:1528143539967};\\\", \\\"{x:603,y:742,t:1528143539984};\\\", \\\"{x:599,y:742,t:1528143540001};\\\", \\\"{x:594,y:738,t:1528143540016};\\\", \\\"{x:584,y:736,t:1528143540033};\\\", \\\"{x:577,y:732,t:1528143540051};\\\", \\\"{x:568,y:729,t:1528143540067};\\\", \\\"{x:563,y:728,t:1528143540085};\\\", \\\"{x:558,y:728,t:1528143540099};\\\", \\\"{x:557,y:728,t:1528143540116};\\\", \\\"{x:555,y:728,t:1528143540135};\\\", \\\"{x:554,y:728,t:1528143540151};\\\", \\\"{x:551,y:728,t:1528143540168};\\\", \\\"{x:549,y:728,t:1528143540184};\\\", \\\"{x:545,y:728,t:1528143540202};\\\", \\\"{x:543,y:728,t:1528143540219};\\\", \\\"{x:541,y:728,t:1528143540235};\\\", \\\"{x:538,y:727,t:1528143540251};\\\", \\\"{x:535,y:726,t:1528143540268};\\\", \\\"{x:532,y:726,t:1528143540285};\\\", \\\"{x:531,y:726,t:1528143540301};\\\", \\\"{x:531,y:724,t:1528143540684};\\\", \\\"{x:540,y:718,t:1528143540692};\\\", \\\"{x:554,y:712,t:1528143540702};\\\", \\\"{x:605,y:687,t:1528143540719};\\\", \\\"{x:677,y:654,t:1528143540735};\\\", \\\"{x:739,y:622,t:1528143540753};\\\", \\\"{x:784,y:590,t:1528143540770};\\\", \\\"{x:836,y:546,t:1528143540786};\\\", \\\"{x:866,y:519,t:1528143540802};\\\", \\\"{x:873,y:510,t:1528143540819};\\\", \\\"{x:875,y:506,t:1528143540836};\\\" ] }, { \\\"rt\\\": 25099, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 8, \\\"time_elapsed\\\": 482434, \\\"internal_node_id\\\": \\\"0.0-5.0-3.0\\\", \\\"subject\\\": \\\"MKTF4\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"zulu\\\", \\\"condition\\\": \\\"211\\\", \\\"scenario\\\": \\\"acme\\\", \\\"question\\\": \\\"endtime\\\", \\\"q\\\": 4, \\\"clicks\\\": 1.5, \\\"explicit\\\": 2, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XInside-YFull\\\", \\\"correct\\\": 1, \\\"orth_correct\\\": 0, \\\"answer\\\": [ \\\"H\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"X \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"U \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-04 PM-H \\\", \\\"block\\\": \\\"triangular_scaffolded\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:875,y:505,t:1528143543631};\\\", \\\"{x:859,y:492,t:1528143543637};\\\", \\\"{x:726,y:471,t:1528143543655};\\\", \\\"{x:599,y:459,t:1528143543671};\\\", \\\"{x:493,y:441,t:1528143543688};\\\", \\\"{x:403,y:424,t:1528143543705};\\\", \\\"{x:367,y:415,t:1528143543721};\\\", \\\"{x:365,y:414,t:1528143543739};\\\", \\\"{x:364,y:414,t:1528143543754};\\\", \\\"{x:364,y:413,t:1528143543771};\\\", \\\"{x:363,y:413,t:1528143543788};\\\", \\\"{x:368,y:413,t:1528143543901};\\\", \\\"{x:380,y:416,t:1528143543909};\\\", \\\"{x:388,y:421,t:1528143543922};\\\", \\\"{x:409,y:426,t:1528143543939};\\\", \\\"{x:442,y:432,t:1528143543955};\\\", \\\"{x:496,y:440,t:1528143543972};\\\", \\\"{x:587,y:447,t:1528143543989};\\\", \\\"{x:684,y:447,t:1528143544006};\\\", \\\"{x:819,y:457,t:1528143544022};\\\", \\\"{x:965,y:476,t:1528143544039};\\\", \\\"{x:1134,y:501,t:1528143544056};\\\", \\\"{x:1292,y:523,t:1528143544072};\\\", \\\"{x:1439,y:553,t:1528143544089};\\\", \\\"{x:1572,y:590,t:1528143544107};\\\", \\\"{x:1684,y:627,t:1528143544122};\\\", \\\"{x:1755,y:668,t:1528143544139};\\\", \\\"{x:1801,y:716,t:1528143544156};\\\", \\\"{x:1814,y:760,t:1528143544173};\\\", \\\"{x:1788,y:829,t:1528143544189};\\\", \\\"{x:1763,y:857,t:1528143544206};\\\", \\\"{x:1730,y:878,t:1528143544223};\\\", \\\"{x:1711,y:888,t:1528143544239};\\\", \\\"{x:1693,y:890,t:1528143544256};\\\", \\\"{x:1669,y:893,t:1528143544273};\\\", \\\"{x:1645,y:893,t:1528143544289};\\\", \\\"{x:1619,y:893,t:1528143544307};\\\", \\\"{x:1595,y:893,t:1528143544323};\\\", \\\"{x:1584,y:893,t:1528143544339};\\\", \\\"{x:1580,y:893,t:1528143544356};\\\", \\\"{x:1578,y:894,t:1528143544413};\\\", \\\"{x:1575,y:896,t:1528143544423};\\\", \\\"{x:1568,y:906,t:1528143544439};\\\", \\\"{x:1562,y:915,t:1528143544455};\\\", \\\"{x:1559,y:918,t:1528143544472};\\\", \\\"{x:1557,y:922,t:1528143544488};\\\", \\\"{x:1557,y:926,t:1528143544505};\\\", \\\"{x:1557,y:932,t:1528143544522};\\\", \\\"{x:1560,y:941,t:1528143544539};\\\", \\\"{x:1562,y:950,t:1528143544556};\\\", \\\"{x:1564,y:961,t:1528143544572};\\\", \\\"{x:1567,y:966,t:1528143544589};\\\", \\\"{x:1570,y:969,t:1528143544605};\\\", \\\"{x:1570,y:971,t:1528143544623};\\\", \\\"{x:1573,y:974,t:1528143544640};\\\", \\\"{x:1578,y:977,t:1528143544656};\\\", \\\"{x:1586,y:983,t:1528143544673};\\\", \\\"{x:1592,y:987,t:1528143544690};\\\", \\\"{x:1596,y:988,t:1528143544706};\\\", \\\"{x:1597,y:989,t:1528143544723};\\\", \\\"{x:1599,y:992,t:1528143544740};\\\", \\\"{x:1601,y:994,t:1528143544756};\\\", \\\"{x:1605,y:997,t:1528143544773};\\\", \\\"{x:1606,y:997,t:1528143544790};\\\", \\\"{x:1607,y:997,t:1528143544806};\\\", \\\"{x:1608,y:997,t:1528143544823};\\\", \\\"{x:1610,y:997,t:1528143544839};\\\", \\\"{x:1612,y:993,t:1528143544856};\\\", \\\"{x:1616,y:988,t:1528143544872};\\\", \\\"{x:1619,y:986,t:1528143544889};\\\", \\\"{x:1620,y:983,t:1528143544906};\\\", \\\"{x:1620,y:979,t:1528143544923};\\\", \\\"{x:1622,y:974,t:1528143544940};\\\", \\\"{x:1622,y:971,t:1528143544956};\\\", \\\"{x:1622,y:970,t:1528143544988};\\\", \\\"{x:1620,y:970,t:1528143545012};\\\", \\\"{x:1619,y:970,t:1528143545036};\\\", \\\"{x:1617,y:970,t:1528143545397};\\\", \\\"{x:1617,y:969,t:1528143545407};\\\", \\\"{x:1615,y:968,t:1528143545425};\\\", \\\"{x:1613,y:965,t:1528143545441};\\\", \\\"{x:1612,y:964,t:1528143545457};\\\", \\\"{x:1612,y:962,t:1528143545474};\\\", \\\"{x:1611,y:962,t:1528143545491};\\\", \\\"{x:1611,y:961,t:1528143545508};\\\", \\\"{x:1610,y:961,t:1528143545565};\\\", \\\"{x:1609,y:960,t:1528143545613};\\\", \\\"{x:1609,y:958,t:1528143545678};\\\", \\\"{x:1608,y:957,t:1528143545709};\\\", \\\"{x:1607,y:956,t:1528143545725};\\\", \\\"{x:1606,y:955,t:1528143545757};\\\", \\\"{x:1606,y:953,t:1528143545781};\\\", \\\"{x:1605,y:952,t:1528143545791};\\\", \\\"{x:1603,y:949,t:1528143545808};\\\", \\\"{x:1601,y:947,t:1528143545824};\\\", \\\"{x:1601,y:946,t:1528143545841};\\\", \\\"{x:1600,y:945,t:1528143545877};\\\", \\\"{x:1599,y:944,t:1528143545901};\\\", \\\"{x:1598,y:942,t:1528143545910};\\\", \\\"{x:1597,y:941,t:1528143545925};\\\", \\\"{x:1597,y:940,t:1528143545949};\\\", \\\"{x:1596,y:940,t:1528143545958};\\\", \\\"{x:1595,y:939,t:1528143545980};\\\", \\\"{x:1595,y:938,t:1528143545991};\\\", \\\"{x:1594,y:936,t:1528143546008};\\\", \\\"{x:1593,y:935,t:1528143546029};\\\", \\\"{x:1593,y:934,t:1528143546041};\\\", \\\"{x:1592,y:933,t:1528143546058};\\\", \\\"{x:1591,y:932,t:1528143546077};\\\", \\\"{x:1591,y:931,t:1528143546091};\\\", \\\"{x:1590,y:930,t:1528143546109};\\\", \\\"{x:1589,y:928,t:1528143546125};\\\", \\\"{x:1588,y:927,t:1528143546141};\\\", \\\"{x:1587,y:925,t:1528143546158};\\\", \\\"{x:1587,y:924,t:1528143546175};\\\", \\\"{x:1586,y:923,t:1528143546193};\\\", \\\"{x:1585,y:921,t:1528143546208};\\\", \\\"{x:1584,y:920,t:1528143546225};\\\", \\\"{x:1584,y:919,t:1528143546242};\\\", \\\"{x:1582,y:918,t:1528143546258};\\\", \\\"{x:1582,y:915,t:1528143546276};\\\", \\\"{x:1581,y:914,t:1528143546292};\\\", \\\"{x:1579,y:910,t:1528143546309};\\\", \\\"{x:1578,y:909,t:1528143546325};\\\", \\\"{x:1577,y:908,t:1528143546342};\\\", \\\"{x:1576,y:906,t:1528143546359};\\\", \\\"{x:1575,y:905,t:1528143546376};\\\", \\\"{x:1575,y:904,t:1528143546392};\\\", \\\"{x:1574,y:902,t:1528143546408};\\\", \\\"{x:1572,y:900,t:1528143546426};\\\", \\\"{x:1572,y:899,t:1528143546445};\\\", \\\"{x:1571,y:898,t:1528143546459};\\\", \\\"{x:1570,y:897,t:1528143546477};\\\", \\\"{x:1570,y:896,t:1528143546493};\\\", \\\"{x:1569,y:895,t:1528143546510};\\\", \\\"{x:1568,y:892,t:1528143546526};\\\", \\\"{x:1566,y:890,t:1528143546543};\\\", \\\"{x:1564,y:885,t:1528143546559};\\\", \\\"{x:1559,y:874,t:1528143546576};\\\", \\\"{x:1556,y:866,t:1528143546593};\\\", \\\"{x:1551,y:853,t:1528143546609};\\\", \\\"{x:1547,y:846,t:1528143546626};\\\", \\\"{x:1546,y:840,t:1528143546643};\\\", \\\"{x:1542,y:834,t:1528143546659};\\\", \\\"{x:1534,y:822,t:1528143546675};\\\", \\\"{x:1525,y:810,t:1528143546692};\\\", \\\"{x:1482,y:776,t:1528143546709};\\\", \\\"{x:1405,y:740,t:1528143546726};\\\", \\\"{x:1310,y:710,t:1528143546742};\\\", \\\"{x:1201,y:690,t:1528143546759};\\\", \\\"{x:1087,y:670,t:1528143546776};\\\", \\\"{x:972,y:651,t:1528143546792};\\\", \\\"{x:867,y:638,t:1528143546809};\\\", \\\"{x:784,y:625,t:1528143546826};\\\", \\\"{x:718,y:613,t:1528143546842};\\\", \\\"{x:665,y:603,t:1528143546861};\\\", \\\"{x:625,y:596,t:1528143546876};\\\", \\\"{x:607,y:593,t:1528143546892};\\\", \\\"{x:598,y:592,t:1528143546907};\\\", \\\"{x:595,y:591,t:1528143546923};\\\", \\\"{x:592,y:590,t:1528143546941};\\\", \\\"{x:590,y:590,t:1528143546957};\\\", \\\"{x:586,y:589,t:1528143546974};\\\", \\\"{x:576,y:589,t:1528143546990};\\\", \\\"{x:573,y:589,t:1528143547007};\\\", \\\"{x:572,y:589,t:1528143547024};\\\", \\\"{x:573,y:588,t:1528143547060};\\\", \\\"{x:578,y:585,t:1528143547074};\\\", \\\"{x:587,y:579,t:1528143547091};\\\", \\\"{x:591,y:577,t:1528143547108};\\\", \\\"{x:594,y:575,t:1528143547124};\\\", \\\"{x:595,y:573,t:1528143547142};\\\", \\\"{x:597,y:573,t:1528143547381};\\\", \\\"{x:599,y:573,t:1528143547391};\\\", \\\"{x:601,y:572,t:1528143547445};\\\", \\\"{x:602,y:572,t:1528143547685};\\\", \\\"{x:605,y:570,t:1528143547694};\\\", \\\"{x:610,y:568,t:1528143547708};\\\", \\\"{x:632,y:560,t:1528143547725};\\\", \\\"{x:680,y:559,t:1528143547742};\\\", \\\"{x:774,y:547,t:1528143547758};\\\", \\\"{x:900,y:537,t:1528143547775};\\\", \\\"{x:1018,y:527,t:1528143547791};\\\", \\\"{x:1113,y:525,t:1528143547808};\\\", \\\"{x:1177,y:525,t:1528143547824};\\\", \\\"{x:1201,y:525,t:1528143547842};\\\", \\\"{x:1205,y:525,t:1528143547858};\\\", \\\"{x:1206,y:525,t:1528143547916};\\\", \\\"{x:1212,y:526,t:1528143547925};\\\", \\\"{x:1222,y:531,t:1528143547942};\\\", \\\"{x:1245,y:538,t:1528143547958};\\\", \\\"{x:1270,y:543,t:1528143547975};\\\", \\\"{x:1289,y:546,t:1528143547992};\\\", \\\"{x:1294,y:547,t:1528143548008};\\\", \\\"{x:1295,y:547,t:1528143548025};\\\", \\\"{x:1296,y:547,t:1528143548043};\\\", \\\"{x:1300,y:547,t:1528143548059};\\\", \\\"{x:1306,y:547,t:1528143548076};\\\", \\\"{x:1307,y:548,t:1528143548092};\\\", \\\"{x:1309,y:548,t:1528143548109};\\\", \\\"{x:1310,y:548,t:1528143548125};\\\", \\\"{x:1311,y:548,t:1528143548261};\\\", \\\"{x:1301,y:548,t:1528143548430};\\\", \\\"{x:1280,y:548,t:1528143548442};\\\", \\\"{x:1213,y:548,t:1528143548459};\\\", \\\"{x:1133,y:548,t:1528143548477};\\\", \\\"{x:1008,y:560,t:1528143548493};\\\", \\\"{x:957,y:560,t:1528143548509};\\\", \\\"{x:928,y:560,t:1528143548527};\\\", \\\"{x:902,y:559,t:1528143548542};\\\", \\\"{x:869,y:553,t:1528143548559};\\\", \\\"{x:829,y:548,t:1528143548576};\\\", \\\"{x:801,y:543,t:1528143548593};\\\", \\\"{x:780,y:541,t:1528143548609};\\\", \\\"{x:762,y:537,t:1528143548626};\\\", \\\"{x:747,y:537,t:1528143548642};\\\", \\\"{x:730,y:537,t:1528143548658};\\\", \\\"{x:718,y:537,t:1528143548675};\\\", \\\"{x:705,y:540,t:1528143548692};\\\", \\\"{x:701,y:542,t:1528143548708};\\\", \\\"{x:696,y:542,t:1528143548726};\\\", \\\"{x:693,y:542,t:1528143548742};\\\", \\\"{x:689,y:543,t:1528143548759};\\\", \\\"{x:683,y:546,t:1528143548777};\\\", \\\"{x:678,y:547,t:1528143548792};\\\", \\\"{x:672,y:549,t:1528143548809};\\\", \\\"{x:669,y:550,t:1528143548825};\\\", \\\"{x:667,y:551,t:1528143548842};\\\", \\\"{x:662,y:552,t:1528143548858};\\\", \\\"{x:657,y:553,t:1528143548875};\\\", \\\"{x:650,y:554,t:1528143548892};\\\", \\\"{x:639,y:556,t:1528143548908};\\\", \\\"{x:635,y:556,t:1528143548925};\\\", \\\"{x:631,y:557,t:1528143548942};\\\", \\\"{x:628,y:557,t:1528143548959};\\\", \\\"{x:624,y:557,t:1528143548976};\\\", \\\"{x:623,y:557,t:1528143548993};\\\", \\\"{x:621,y:557,t:1528143549009};\\\", \\\"{x:620,y:557,t:1528143549026};\\\", \\\"{x:618,y:557,t:1528143549043};\\\", \\\"{x:617,y:557,t:1528143549059};\\\", \\\"{x:618,y:557,t:1528143549348};\\\", \\\"{x:623,y:556,t:1528143549359};\\\", \\\"{x:644,y:551,t:1528143549376};\\\", \\\"{x:715,y:562,t:1528143549393};\\\", \\\"{x:806,y:574,t:1528143549410};\\\", \\\"{x:908,y:587,t:1528143549427};\\\", \\\"{x:1031,y:606,t:1528143549443};\\\", \\\"{x:1129,y:624,t:1528143549460};\\\", \\\"{x:1228,y:650,t:1528143549476};\\\", \\\"{x:1249,y:657,t:1528143549492};\\\", \\\"{x:1261,y:662,t:1528143549508};\\\", \\\"{x:1266,y:667,t:1528143549526};\\\", \\\"{x:1267,y:669,t:1528143549543};\\\", \\\"{x:1269,y:671,t:1528143549559};\\\", \\\"{x:1270,y:674,t:1528143549577};\\\", \\\"{x:1270,y:678,t:1528143549593};\\\", \\\"{x:1270,y:679,t:1528143549609};\\\", \\\"{x:1269,y:682,t:1528143549626};\\\", \\\"{x:1269,y:684,t:1528143549643};\\\", \\\"{x:1270,y:686,t:1528143549805};\\\", \\\"{x:1276,y:689,t:1528143549813};\\\", \\\"{x:1283,y:691,t:1528143549826};\\\", \\\"{x:1306,y:700,t:1528143549842};\\\", \\\"{x:1344,y:716,t:1528143549859};\\\", \\\"{x:1380,y:731,t:1528143549877};\\\", \\\"{x:1413,y:746,t:1528143549892};\\\", \\\"{x:1460,y:777,t:1528143549909};\\\", \\\"{x:1482,y:794,t:1528143549926};\\\", \\\"{x:1502,y:810,t:1528143549942};\\\", \\\"{x:1510,y:816,t:1528143549960};\\\", \\\"{x:1511,y:817,t:1528143549977};\\\", \\\"{x:1511,y:819,t:1528143549992};\\\", \\\"{x:1511,y:820,t:1528143550013};\\\", \\\"{x:1511,y:822,t:1528143550027};\\\", \\\"{x:1511,y:824,t:1528143550043};\\\", \\\"{x:1509,y:826,t:1528143550060};\\\", \\\"{x:1507,y:829,t:1528143550075};\\\", \\\"{x:1506,y:830,t:1528143550093};\\\", \\\"{x:1504,y:833,t:1528143550109};\\\", \\\"{x:1503,y:833,t:1528143550125};\\\", \\\"{x:1503,y:835,t:1528143550143};\\\", \\\"{x:1503,y:836,t:1528143550160};\\\", \\\"{x:1503,y:838,t:1528143550175};\\\", \\\"{x:1503,y:840,t:1528143550193};\\\", \\\"{x:1503,y:843,t:1528143550210};\\\", \\\"{x:1505,y:846,t:1528143550225};\\\", \\\"{x:1508,y:847,t:1528143550241};\\\", \\\"{x:1510,y:850,t:1528143550259};\\\", \\\"{x:1512,y:853,t:1528143550274};\\\", \\\"{x:1513,y:864,t:1528143550291};\\\", \\\"{x:1514,y:871,t:1528143550308};\\\", \\\"{x:1518,y:879,t:1528143550325};\\\", \\\"{x:1518,y:884,t:1528143550342};\\\", \\\"{x:1519,y:885,t:1528143550359};\\\", \\\"{x:1520,y:889,t:1528143550375};\\\", \\\"{x:1522,y:891,t:1528143550391};\\\", \\\"{x:1522,y:892,t:1528143550413};\\\", \\\"{x:1522,y:893,t:1528143550428};\\\", \\\"{x:1523,y:895,t:1528143550443};\\\", \\\"{x:1525,y:897,t:1528143550458};\\\", \\\"{x:1525,y:899,t:1528143550476};\\\", \\\"{x:1527,y:902,t:1528143550493};\\\", \\\"{x:1529,y:906,t:1528143550509};\\\", \\\"{x:1532,y:911,t:1528143550526};\\\", \\\"{x:1533,y:913,t:1528143550543};\\\", \\\"{x:1533,y:915,t:1528143550565};\\\", \\\"{x:1534,y:915,t:1528143550575};\\\", \\\"{x:1534,y:916,t:1528143550613};\\\", \\\"{x:1532,y:916,t:1528143550677};\\\", \\\"{x:1521,y:914,t:1528143550692};\\\", \\\"{x:1472,y:902,t:1528143550709};\\\", \\\"{x:1447,y:899,t:1528143550724};\\\", \\\"{x:1420,y:896,t:1528143550742};\\\", \\\"{x:1390,y:891,t:1528143550759};\\\", \\\"{x:1333,y:879,t:1528143550775};\\\", \\\"{x:1267,y:860,t:1528143550791};\\\", \\\"{x:1135,y:808,t:1528143550808};\\\", \\\"{x:986,y:746,t:1528143550825};\\\", \\\"{x:809,y:687,t:1528143550841};\\\", \\\"{x:667,y:644,t:1528143550858};\\\", \\\"{x:578,y:615,t:1528143550875};\\\", \\\"{x:529,y:581,t:1528143550893};\\\", \\\"{x:522,y:573,t:1528143550911};\\\", \\\"{x:521,y:571,t:1528143550926};\\\", \\\"{x:521,y:574,t:1528143551036};\\\", \\\"{x:525,y:577,t:1528143551045};\\\", \\\"{x:542,y:586,t:1528143551061};\\\", \\\"{x:568,y:593,t:1528143551077};\\\", \\\"{x:600,y:597,t:1528143551094};\\\", \\\"{x:620,y:597,t:1528143551110};\\\", \\\"{x:630,y:592,t:1528143551127};\\\", \\\"{x:631,y:590,t:1528143551144};\\\", \\\"{x:631,y:587,t:1528143551161};\\\", \\\"{x:631,y:577,t:1528143551178};\\\", \\\"{x:618,y:563,t:1528143551194};\\\", \\\"{x:593,y:548,t:1528143551211};\\\", \\\"{x:549,y:525,t:1528143551228};\\\", \\\"{x:529,y:515,t:1528143551244};\\\", \\\"{x:523,y:512,t:1528143551261};\\\", \\\"{x:519,y:509,t:1528143551278};\\\", \\\"{x:517,y:506,t:1528143551293};\\\", \\\"{x:516,y:501,t:1528143551312};\\\", \\\"{x:516,y:494,t:1528143551327};\\\", \\\"{x:516,y:489,t:1528143551343};\\\", \\\"{x:516,y:487,t:1528143551361};\\\", \\\"{x:516,y:486,t:1528143551378};\\\", \\\"{x:516,y:484,t:1528143551404};\\\", \\\"{x:517,y:483,t:1528143551412};\\\", \\\"{x:522,y:482,t:1528143551428};\\\", \\\"{x:545,y:481,t:1528143551444};\\\", \\\"{x:701,y:539,t:1528143551460};\\\", \\\"{x:874,y:602,t:1528143551478};\\\", \\\"{x:1056,y:662,t:1528143551494};\\\", \\\"{x:1234,y:716,t:1528143551511};\\\", \\\"{x:1373,y:764,t:1528143551528};\\\", \\\"{x:1469,y:804,t:1528143551545};\\\", \\\"{x:1525,y:831,t:1528143551561};\\\", \\\"{x:1548,y:843,t:1528143551578};\\\", \\\"{x:1550,y:845,t:1528143551595};\\\", \\\"{x:1551,y:847,t:1528143551636};\\\", \\\"{x:1555,y:849,t:1528143551644};\\\", \\\"{x:1564,y:855,t:1528143551661};\\\", \\\"{x:1572,y:860,t:1528143551679};\\\", \\\"{x:1577,y:865,t:1528143551695};\\\", \\\"{x:1578,y:867,t:1528143551711};\\\", \\\"{x:1579,y:873,t:1528143551729};\\\", \\\"{x:1580,y:883,t:1528143551745};\\\", \\\"{x:1586,y:899,t:1528143551762};\\\", \\\"{x:1594,y:914,t:1528143551779};\\\", \\\"{x:1600,y:927,t:1528143551795};\\\", \\\"{x:1610,y:941,t:1528143551813};\\\", \\\"{x:1610,y:944,t:1528143551829};\\\", \\\"{x:1611,y:947,t:1528143551845};\\\", \\\"{x:1613,y:950,t:1528143551863};\\\", \\\"{x:1615,y:954,t:1528143551878};\\\", \\\"{x:1618,y:956,t:1528143551895};\\\", \\\"{x:1621,y:957,t:1528143551912};\\\", \\\"{x:1623,y:958,t:1528143551928};\\\", \\\"{x:1625,y:958,t:1528143551945};\\\", \\\"{x:1626,y:959,t:1528143552012};\\\", \\\"{x:1624,y:959,t:1528143552182};\\\", \\\"{x:1622,y:957,t:1528143552195};\\\", \\\"{x:1618,y:949,t:1528143552212};\\\", \\\"{x:1613,y:939,t:1528143552229};\\\", \\\"{x:1610,y:933,t:1528143552246};\\\", \\\"{x:1607,y:929,t:1528143552263};\\\", \\\"{x:1604,y:923,t:1528143552279};\\\", \\\"{x:1602,y:919,t:1528143552296};\\\", \\\"{x:1597,y:911,t:1528143552312};\\\", \\\"{x:1592,y:905,t:1528143552329};\\\", \\\"{x:1588,y:899,t:1528143552345};\\\", \\\"{x:1584,y:895,t:1528143552362};\\\", \\\"{x:1582,y:892,t:1528143552379};\\\", \\\"{x:1580,y:889,t:1528143552396};\\\", \\\"{x:1576,y:884,t:1528143552412};\\\", \\\"{x:1573,y:880,t:1528143552429};\\\", \\\"{x:1569,y:875,t:1528143552446};\\\", \\\"{x:1567,y:872,t:1528143552462};\\\", \\\"{x:1566,y:869,t:1528143552479};\\\", \\\"{x:1564,y:866,t:1528143552497};\\\", \\\"{x:1561,y:862,t:1528143552512};\\\", \\\"{x:1559,y:859,t:1528143552529};\\\", \\\"{x:1556,y:855,t:1528143552547};\\\", \\\"{x:1555,y:854,t:1528143552564};\\\", \\\"{x:1555,y:853,t:1528143552580};\\\", \\\"{x:1552,y:851,t:1528143552597};\\\", \\\"{x:1552,y:849,t:1528143552613};\\\", \\\"{x:1551,y:847,t:1528143552629};\\\", \\\"{x:1549,y:845,t:1528143552646};\\\", \\\"{x:1548,y:844,t:1528143552664};\\\", \\\"{x:1545,y:838,t:1528143552679};\\\", \\\"{x:1542,y:833,t:1528143552696};\\\", \\\"{x:1539,y:827,t:1528143552713};\\\", \\\"{x:1536,y:820,t:1528143552730};\\\", \\\"{x:1533,y:814,t:1528143552746};\\\", \\\"{x:1529,y:806,t:1528143552763};\\\", \\\"{x:1524,y:793,t:1528143552780};\\\", \\\"{x:1520,y:784,t:1528143552797};\\\", \\\"{x:1517,y:776,t:1528143552813};\\\", \\\"{x:1514,y:771,t:1528143552831};\\\", \\\"{x:1512,y:765,t:1528143552847};\\\", \\\"{x:1508,y:756,t:1528143552864};\\\", \\\"{x:1503,y:748,t:1528143552881};\\\", \\\"{x:1497,y:737,t:1528143552896};\\\", \\\"{x:1492,y:729,t:1528143552914};\\\", \\\"{x:1487,y:719,t:1528143552931};\\\", \\\"{x:1482,y:707,t:1528143552946};\\\", \\\"{x:1477,y:698,t:1528143552964};\\\", \\\"{x:1465,y:677,t:1528143552981};\\\", \\\"{x:1459,y:666,t:1528143552996};\\\", \\\"{x:1457,y:662,t:1528143553014};\\\", \\\"{x:1455,y:655,t:1528143553030};\\\", \\\"{x:1453,y:650,t:1528143553048};\\\", \\\"{x:1449,y:643,t:1528143553064};\\\", \\\"{x:1445,y:634,t:1528143553080};\\\", \\\"{x:1443,y:626,t:1528143553098};\\\", \\\"{x:1440,y:619,t:1528143553114};\\\", \\\"{x:1439,y:613,t:1528143553131};\\\", \\\"{x:1436,y:608,t:1528143553148};\\\", \\\"{x:1433,y:603,t:1528143553164};\\\", \\\"{x:1429,y:596,t:1528143553180};\\\", \\\"{x:1427,y:592,t:1528143553197};\\\", \\\"{x:1425,y:589,t:1528143553213};\\\", \\\"{x:1424,y:586,t:1528143553230};\\\", \\\"{x:1423,y:584,t:1528143553247};\\\", \\\"{x:1421,y:581,t:1528143553265};\\\", \\\"{x:1420,y:578,t:1528143553280};\\\", \\\"{x:1417,y:575,t:1528143553298};\\\", \\\"{x:1417,y:573,t:1528143553315};\\\", \\\"{x:1416,y:572,t:1528143553330};\\\", \\\"{x:1415,y:570,t:1528143553347};\\\", \\\"{x:1414,y:568,t:1528143553367};\\\", \\\"{x:1414,y:567,t:1528143553397};\\\", \\\"{x:1411,y:566,t:1528143564430};\\\", \\\"{x:1401,y:566,t:1528143564440};\\\", \\\"{x:1376,y:566,t:1528143564455};\\\", \\\"{x:1347,y:568,t:1528143564472};\\\", \\\"{x:1318,y:570,t:1528143564489};\\\", \\\"{x:1288,y:570,t:1528143564505};\\\", \\\"{x:1259,y:570,t:1528143564521};\\\", \\\"{x:1234,y:570,t:1528143564539};\\\", \\\"{x:1212,y:570,t:1528143564554};\\\", \\\"{x:1189,y:568,t:1528143564571};\\\", \\\"{x:1160,y:566,t:1528143564589};\\\", \\\"{x:1098,y:565,t:1528143564605};\\\", \\\"{x:1037,y:565,t:1528143564621};\\\", \\\"{x:967,y:565,t:1528143564639};\\\", \\\"{x:884,y:565,t:1528143564656};\\\", \\\"{x:801,y:573,t:1528143564671};\\\", \\\"{x:729,y:584,t:1528143564689};\\\", \\\"{x:685,y:594,t:1528143564706};\\\", \\\"{x:648,y:607,t:1528143564729};\\\", \\\"{x:638,y:611,t:1528143564747};\\\", \\\"{x:632,y:613,t:1528143564763};\\\", \\\"{x:627,y:616,t:1528143564780};\\\", \\\"{x:623,y:619,t:1528143564797};\\\", \\\"{x:620,y:621,t:1528143564813};\\\", \\\"{x:619,y:623,t:1528143564830};\\\", \\\"{x:615,y:631,t:1528143564847};\\\", \\\"{x:611,y:639,t:1528143564864};\\\", \\\"{x:606,y:648,t:1528143564881};\\\", \\\"{x:602,y:655,t:1528143564897};\\\", \\\"{x:599,y:659,t:1528143564914};\\\", \\\"{x:596,y:662,t:1528143564930};\\\", \\\"{x:593,y:666,t:1528143564947};\\\", \\\"{x:590,y:669,t:1528143564964};\\\", \\\"{x:586,y:674,t:1528143564981};\\\", \\\"{x:571,y:684,t:1528143564997};\\\", \\\"{x:563,y:687,t:1528143565015};\\\", \\\"{x:558,y:691,t:1528143565031};\\\", \\\"{x:555,y:691,t:1528143565048};\\\", \\\"{x:552,y:692,t:1528143565064};\\\", \\\"{x:550,y:693,t:1528143565081};\\\", \\\"{x:547,y:695,t:1528143565098};\\\", \\\"{x:544,y:697,t:1528143565115};\\\", \\\"{x:540,y:699,t:1528143565130};\\\", \\\"{x:537,y:701,t:1528143565149};\\\", \\\"{x:536,y:701,t:1528143565163};\\\", \\\"{x:535,y:702,t:1528143565181};\\\", \\\"{x:533,y:704,t:1528143565198};\\\", \\\"{x:532,y:705,t:1528143565214};\\\", \\\"{x:531,y:705,t:1528143565231};\\\", \\\"{x:530,y:706,t:1528143565309};\\\", \\\"{x:528,y:707,t:1528143565341};\\\", \\\"{x:528,y:708,t:1528143565518};\\\", \\\"{x:527,y:709,t:1528143565533};\\\", \\\"{x:525,y:710,t:1528143565549};\\\", \\\"{x:523,y:712,t:1528143565565};\\\", \\\"{x:521,y:714,t:1528143565582};\\\", \\\"{x:520,y:715,t:1528143565599};\\\", \\\"{x:519,y:716,t:1528143565902};\\\", \\\"{x:519,y:717,t:1528143565917};\\\", \\\"{x:519,y:720,t:1528143565933};\\\", \\\"{x:518,y:720,t:1528143566014};\\\", \\\"{x:517,y:722,t:1528143566078};\\\", \\\"{x:517,y:723,t:1528143566205};\\\", \\\"{x:516,y:723,t:1528143566217};\\\", \\\"{x:516,y:724,t:1528143566234};\\\", \\\"{x:515,y:725,t:1528143566269};\\\", \\\"{x:514,y:726,t:1528143566293};\\\", \\\"{x:521,y:730,t:1528143567166};\\\", \\\"{x:551,y:732,t:1528143567183};\\\", \\\"{x:592,y:730,t:1528143567199};\\\", \\\"{x:634,y:718,t:1528143567215};\\\", \\\"{x:656,y:708,t:1528143567233};\\\", \\\"{x:667,y:701,t:1528143567250};\\\", \\\"{x:675,y:694,t:1528143567265};\\\", \\\"{x:683,y:683,t:1528143567282};\\\", \\\"{x:693,y:668,t:1528143567300};\\\", \\\"{x:706,y:651,t:1528143567315};\\\", \\\"{x:718,y:636,t:1528143567332};\\\", \\\"{x:724,y:629,t:1528143567349};\\\", \\\"{x:727,y:625,t:1528143567366};\\\" ] }, { \\\"rt\\\": 126413, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 9, \\\"time_elapsed\\\": 610107, \\\"internal_node_id\\\": \\\"0.0-5.0-4.0\\\", \\\"subject\\\": \\\"MKTF4\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"zulu\\\", \\\"condition\\\": \\\"211\\\", \\\"scenario\\\": \\\"acme\\\", \\\"question\\\": \\\"midpoint\\\", \\\"q\\\": 5, \\\"clicks\\\": 5, \\\"explicit\\\": 2, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XInside-YFull\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 0, \\\"answer\\\": [ \\\"A\\\", \\\"I\\\", \\\"O\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"X \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"U \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-Z -C -11 AM-11 AM-11 AM-11 AM-12 PM-09 AM-U -F -H -H -F -F -F -O -O -Z \\\", \\\"block\\\": \\\"triangular_scaffolded\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:728,y:624,t:1528143576198};\\\", \\\"{x:742,y:621,t:1528143576205};\\\", \\\"{x:742,y:620,t:1528143576221};\\\", \\\"{x:742,y:617,t:1528143576277};\\\", \\\"{x:742,y:613,t:1528143576287};\\\", \\\"{x:743,y:603,t:1528143576304};\\\", \\\"{x:745,y:596,t:1528143576321};\\\", \\\"{x:750,y:587,t:1528143576339};\\\", \\\"{x:752,y:582,t:1528143576354};\\\", \\\"{x:752,y:578,t:1528143576371};\\\", \\\"{x:750,y:570,t:1528143576390};\\\", \\\"{x:749,y:562,t:1528143576407};\\\", \\\"{x:748,y:558,t:1528143576423};\\\", \\\"{x:748,y:556,t:1528143576440};\\\", \\\"{x:748,y:555,t:1528143576476};\\\", \\\"{x:753,y:555,t:1528143576490};\\\", \\\"{x:788,y:572,t:1528143576507};\\\", \\\"{x:814,y:590,t:1528143576524};\\\", \\\"{x:814,y:591,t:1528143576540};\\\", \\\"{x:814,y:590,t:1528143576741};\\\", \\\"{x:814,y:589,t:1528143576757};\\\", \\\"{x:814,y:587,t:1528143576783};\\\", \\\"{x:813,y:586,t:1528143576797};\\\", \\\"{x:812,y:586,t:1528143576973};\\\", \\\"{x:797,y:571,t:1528143576991};\\\", \\\"{x:755,y:546,t:1528143577008};\\\", \\\"{x:725,y:529,t:1528143577023};\\\", \\\"{x:684,y:515,t:1528143577041};\\\", \\\"{x:650,y:505,t:1528143577057};\\\", \\\"{x:621,y:495,t:1528143577074};\\\", \\\"{x:612,y:490,t:1528143577091};\\\", \\\"{x:603,y:486,t:1528143577107};\\\", \\\"{x:595,y:482,t:1528143577124};\\\", \\\"{x:591,y:481,t:1528143577140};\\\", \\\"{x:589,y:480,t:1528143577157};\\\", \\\"{x:583,y:477,t:1528143577174};\\\", \\\"{x:576,y:476,t:1528143577191};\\\", \\\"{x:563,y:474,t:1528143577207};\\\", \\\"{x:545,y:474,t:1528143577224};\\\", \\\"{x:528,y:474,t:1528143577241};\\\", \\\"{x:499,y:474,t:1528143577257};\\\", \\\"{x:460,y:474,t:1528143577274};\\\", \\\"{x:418,y:474,t:1528143577291};\\\", \\\"{x:379,y:474,t:1528143577307};\\\", \\\"{x:345,y:474,t:1528143577325};\\\", \\\"{x:324,y:474,t:1528143577341};\\\", \\\"{x:322,y:474,t:1528143577357};\\\", \\\"{x:321,y:474,t:1528143577405};\\\", \\\"{x:325,y:474,t:1528143577510};\\\", \\\"{x:336,y:474,t:1528143577526};\\\", \\\"{x:344,y:474,t:1528143577541};\\\", \\\"{x:357,y:474,t:1528143577559};\\\", \\\"{x:373,y:474,t:1528143577574};\\\", \\\"{x:382,y:475,t:1528143577592};\\\", \\\"{x:392,y:475,t:1528143577608};\\\", \\\"{x:399,y:475,t:1528143577625};\\\", \\\"{x:403,y:476,t:1528143577642};\\\", \\\"{x:406,y:476,t:1528143577658};\\\", \\\"{x:411,y:478,t:1528143577674};\\\", \\\"{x:414,y:478,t:1528143577691};\\\", \\\"{x:421,y:478,t:1528143577708};\\\", \\\"{x:439,y:478,t:1528143577725};\\\", \\\"{x:454,y:478,t:1528143577741};\\\", \\\"{x:465,y:478,t:1528143577759};\\\", \\\"{x:473,y:478,t:1528143577774};\\\", \\\"{x:476,y:478,t:1528143577792};\\\", \\\"{x:480,y:478,t:1528143577809};\\\", \\\"{x:483,y:478,t:1528143577825};\\\", \\\"{x:487,y:478,t:1528143577841};\\\", \\\"{x:491,y:478,t:1528143577858};\\\", \\\"{x:494,y:478,t:1528143577874};\\\", \\\"{x:501,y:478,t:1528143577891};\\\", \\\"{x:506,y:478,t:1528143577908};\\\", \\\"{x:510,y:478,t:1528143577925};\\\", \\\"{x:511,y:478,t:1528143577941};\\\", \\\"{x:512,y:478,t:1528143577957};\\\", \\\"{x:513,y:478,t:1528143577975};\\\", \\\"{x:513,y:479,t:1528143578028};\\\", \\\"{x:513,y:480,t:1528143578041};\\\", \\\"{x:513,y:483,t:1528143578057};\\\", \\\"{x:510,y:485,t:1528143578074};\\\", \\\"{x:505,y:488,t:1528143578091};\\\", \\\"{x:497,y:493,t:1528143578108};\\\", \\\"{x:486,y:497,t:1528143578124};\\\", \\\"{x:482,y:498,t:1528143578140};\\\", \\\"{x:476,y:501,t:1528143578158};\\\", \\\"{x:473,y:502,t:1528143578175};\\\", \\\"{x:469,y:503,t:1528143578191};\\\", \\\"{x:465,y:503,t:1528143578207};\\\", \\\"{x:463,y:504,t:1528143578225};\\\", \\\"{x:462,y:505,t:1528143578241};\\\", \\\"{x:461,y:505,t:1528143578261};\\\", \\\"{x:460,y:506,t:1528143578285};\\\", \\\"{x:459,y:506,t:1528143578301};\\\", \\\"{x:463,y:506,t:1528143578478};\\\", \\\"{x:465,y:506,t:1528143578492};\\\", \\\"{x:470,y:509,t:1528143578508};\\\", \\\"{x:478,y:510,t:1528143578525};\\\", \\\"{x:480,y:512,t:1528143578542};\\\", \\\"{x:481,y:512,t:1528143578558};\\\", \\\"{x:482,y:512,t:1528143578575};\\\", \\\"{x:483,y:512,t:1528143578637};\\\", \\\"{x:485,y:512,t:1528143578669};\\\", \\\"{x:489,y:511,t:1528143578677};\\\", \\\"{x:494,y:511,t:1528143578693};\\\", \\\"{x:500,y:511,t:1528143578709};\\\", \\\"{x:501,y:511,t:1528143578725};\\\", \\\"{x:501,y:510,t:1528143579205};\\\", \\\"{x:502,y:509,t:1528143579213};\\\", \\\"{x:503,y:508,t:1528143579225};\\\", \\\"{x:507,y:506,t:1528143579242};\\\", \\\"{x:510,y:504,t:1528143579260};\\\", \\\"{x:520,y:501,t:1528143579276};\\\", \\\"{x:540,y:499,t:1528143579292};\\\", \\\"{x:588,y:499,t:1528143579309};\\\", \\\"{x:663,y:499,t:1528143579326};\\\", \\\"{x:744,y:496,t:1528143579342};\\\", \\\"{x:820,y:494,t:1528143579359};\\\", \\\"{x:881,y:485,t:1528143579376};\\\", \\\"{x:945,y:477,t:1528143579393};\\\", \\\"{x:998,y:469,t:1528143579410};\\\", \\\"{x:1051,y:461,t:1528143579426};\\\", \\\"{x:1101,y:455,t:1528143579442};\\\", \\\"{x:1143,y:451,t:1528143579460};\\\", \\\"{x:1183,y:444,t:1528143579477};\\\", \\\"{x:1211,y:442,t:1528143579492};\\\", \\\"{x:1224,y:441,t:1528143579509};\\\", \\\"{x:1225,y:441,t:1528143579589};\\\", \\\"{x:1227,y:441,t:1528143579605};\\\", \\\"{x:1228,y:441,t:1528143579614};\\\", \\\"{x:1229,y:441,t:1528143579645};\\\", \\\"{x:1231,y:442,t:1528143579659};\\\", \\\"{x:1232,y:444,t:1528143579677};\\\", \\\"{x:1237,y:447,t:1528143579692};\\\", \\\"{x:1247,y:454,t:1528143579709};\\\", \\\"{x:1254,y:459,t:1528143579726};\\\", \\\"{x:1257,y:461,t:1528143579743};\\\", \\\"{x:1260,y:464,t:1528143579759};\\\", \\\"{x:1261,y:468,t:1528143579777};\\\", \\\"{x:1262,y:471,t:1528143579794};\\\", \\\"{x:1263,y:477,t:1528143579810};\\\", \\\"{x:1263,y:483,t:1528143579827};\\\", \\\"{x:1263,y:491,t:1528143579843};\\\", \\\"{x:1263,y:501,t:1528143579859};\\\", \\\"{x:1263,y:508,t:1528143579876};\\\", \\\"{x:1262,y:520,t:1528143579893};\\\", \\\"{x:1258,y:529,t:1528143579910};\\\", \\\"{x:1257,y:538,t:1528143579927};\\\", \\\"{x:1255,y:545,t:1528143579943};\\\", \\\"{x:1254,y:552,t:1528143579960};\\\", \\\"{x:1251,y:561,t:1528143579977};\\\", \\\"{x:1248,y:570,t:1528143579993};\\\", \\\"{x:1244,y:585,t:1528143580010};\\\", \\\"{x:1240,y:597,t:1528143580026};\\\", \\\"{x:1238,y:607,t:1528143580043};\\\", \\\"{x:1236,y:615,t:1528143580060};\\\", \\\"{x:1232,y:621,t:1528143580077};\\\", \\\"{x:1230,y:631,t:1528143580093};\\\", \\\"{x:1227,y:637,t:1528143580110};\\\", \\\"{x:1226,y:639,t:1528143580127};\\\", \\\"{x:1224,y:642,t:1528143580143};\\\", \\\"{x:1222,y:643,t:1528143580160};\\\", \\\"{x:1218,y:645,t:1528143580177};\\\", \\\"{x:1213,y:656,t:1528143580193};\\\", \\\"{x:1210,y:671,t:1528143580209};\\\", \\\"{x:1208,y:684,t:1528143580226};\\\", \\\"{x:1208,y:687,t:1528143580243};\\\", \\\"{x:1211,y:687,t:1528143580381};\\\", \\\"{x:1215,y:687,t:1528143580393};\\\", \\\"{x:1217,y:686,t:1528143580411};\\\", \\\"{x:1221,y:684,t:1528143580426};\\\", \\\"{x:1223,y:682,t:1528143580443};\\\", \\\"{x:1227,y:678,t:1528143580461};\\\", \\\"{x:1234,y:671,t:1528143580476};\\\", \\\"{x:1249,y:652,t:1528143580494};\\\", \\\"{x:1258,y:641,t:1528143580511};\\\", \\\"{x:1264,y:631,t:1528143580526};\\\", \\\"{x:1268,y:623,t:1528143580543};\\\", \\\"{x:1273,y:612,t:1528143580561};\\\", \\\"{x:1274,y:604,t:1528143580577};\\\", \\\"{x:1278,y:597,t:1528143580594};\\\", \\\"{x:1281,y:590,t:1528143580611};\\\", \\\"{x:1285,y:582,t:1528143580626};\\\", \\\"{x:1288,y:574,t:1528143580644};\\\", \\\"{x:1289,y:570,t:1528143580660};\\\", \\\"{x:1290,y:565,t:1528143580677};\\\", \\\"{x:1292,y:560,t:1528143580693};\\\", \\\"{x:1293,y:556,t:1528143580710};\\\", \\\"{x:1295,y:551,t:1528143580726};\\\", \\\"{x:1297,y:547,t:1528143580744};\\\", \\\"{x:1299,y:543,t:1528143580761};\\\", \\\"{x:1301,y:540,t:1528143580777};\\\", \\\"{x:1303,y:535,t:1528143580794};\\\", \\\"{x:1304,y:533,t:1528143580811};\\\", \\\"{x:1305,y:528,t:1528143580827};\\\", \\\"{x:1307,y:526,t:1528143580844};\\\", \\\"{x:1309,y:523,t:1528143580861};\\\", \\\"{x:1311,y:519,t:1528143580877};\\\", \\\"{x:1312,y:516,t:1528143580894};\\\", \\\"{x:1312,y:515,t:1528143580911};\\\", \\\"{x:1312,y:514,t:1528143580933};\\\", \\\"{x:1312,y:513,t:1528143580944};\\\", \\\"{x:1312,y:512,t:1528143580981};\\\", \\\"{x:1312,y:510,t:1528143581109};\\\", \\\"{x:1312,y:509,t:1528143581141};\\\", \\\"{x:1313,y:508,t:1528143581157};\\\", \\\"{x:1313,y:507,t:1528143581173};\\\", \\\"{x:1313,y:506,t:1528143581197};\\\", \\\"{x:1313,y:504,t:1528143583037};\\\", \\\"{x:1314,y:504,t:1528143583045};\\\", \\\"{x:1313,y:504,t:1528143588092};\\\", \\\"{x:1309,y:507,t:1528143588100};\\\", \\\"{x:1308,y:515,t:1528143588115};\\\", \\\"{x:1313,y:546,t:1528143588132};\\\", \\\"{x:1329,y:580,t:1528143588148};\\\", \\\"{x:1338,y:607,t:1528143588166};\\\", \\\"{x:1344,y:648,t:1528143588183};\\\", \\\"{x:1347,y:675,t:1528143588198};\\\", \\\"{x:1349,y:705,t:1528143588216};\\\", \\\"{x:1351,y:736,t:1528143588233};\\\", \\\"{x:1351,y:767,t:1528143588249};\\\", \\\"{x:1343,y:788,t:1528143588266};\\\", \\\"{x:1336,y:810,t:1528143588283};\\\", \\\"{x:1334,y:830,t:1528143588299};\\\", \\\"{x:1332,y:851,t:1528143588316};\\\", \\\"{x:1332,y:868,t:1528143588333};\\\", \\\"{x:1333,y:871,t:1528143588349};\\\", \\\"{x:1333,y:872,t:1528143588454};\\\", \\\"{x:1333,y:875,t:1528143588566};\\\", \\\"{x:1333,y:882,t:1528143588583};\\\", \\\"{x:1331,y:890,t:1528143588600};\\\", \\\"{x:1327,y:899,t:1528143588616};\\\", \\\"{x:1326,y:907,t:1528143588633};\\\", \\\"{x:1326,y:911,t:1528143588650};\\\", \\\"{x:1326,y:914,t:1528143588666};\\\", \\\"{x:1326,y:916,t:1528143588683};\\\", \\\"{x:1326,y:918,t:1528143588700};\\\", \\\"{x:1326,y:921,t:1528143588716};\\\", \\\"{x:1326,y:924,t:1528143588734};\\\", \\\"{x:1326,y:926,t:1528143588749};\\\", \\\"{x:1326,y:928,t:1528143588766};\\\", \\\"{x:1326,y:929,t:1528143588797};\\\", \\\"{x:1326,y:930,t:1528143588806};\\\", \\\"{x:1326,y:931,t:1528143588821};\\\", \\\"{x:1326,y:932,t:1528143588833};\\\", \\\"{x:1326,y:935,t:1528143588850};\\\", \\\"{x:1326,y:936,t:1528143588866};\\\", \\\"{x:1326,y:937,t:1528143588883};\\\", \\\"{x:1326,y:938,t:1528143588900};\\\", \\\"{x:1325,y:940,t:1528143588917};\\\", \\\"{x:1324,y:941,t:1528143588933};\\\", \\\"{x:1323,y:943,t:1528143588949};\\\", \\\"{x:1323,y:944,t:1528143588967};\\\", \\\"{x:1323,y:946,t:1528143588983};\\\", \\\"{x:1322,y:947,t:1528143589000};\\\", \\\"{x:1322,y:948,t:1528143589021};\\\", \\\"{x:1322,y:949,t:1528143589032};\\\", \\\"{x:1321,y:953,t:1528143589050};\\\", \\\"{x:1320,y:954,t:1528143589067};\\\", \\\"{x:1320,y:953,t:1528143589182};\\\", \\\"{x:1324,y:948,t:1528143589200};\\\", \\\"{x:1327,y:944,t:1528143589217};\\\", \\\"{x:1333,y:937,t:1528143589233};\\\", \\\"{x:1337,y:932,t:1528143589250};\\\", \\\"{x:1343,y:924,t:1528143589267};\\\", \\\"{x:1348,y:919,t:1528143589282};\\\", \\\"{x:1351,y:915,t:1528143589300};\\\", \\\"{x:1354,y:910,t:1528143589316};\\\", \\\"{x:1355,y:909,t:1528143589332};\\\", \\\"{x:1356,y:907,t:1528143589356};\\\", \\\"{x:1356,y:906,t:1528143589380};\\\", \\\"{x:1356,y:905,t:1528143589388};\\\", \\\"{x:1356,y:904,t:1528143589421};\\\", \\\"{x:1356,y:903,t:1528143589437};\\\", \\\"{x:1356,y:902,t:1528143589453};\\\", \\\"{x:1355,y:902,t:1528143589598};\\\", \\\"{x:1354,y:902,t:1528143589605};\\\", \\\"{x:1353,y:902,t:1528143589621};\\\", \\\"{x:1351,y:902,t:1528143589645};\\\", \\\"{x:1350,y:901,t:1528143589696};\\\", \\\"{x:1348,y:901,t:1528143589772};\\\", \\\"{x:1347,y:900,t:1528143590013};\\\", \\\"{x:1347,y:899,t:1528143590061};\\\", \\\"{x:1346,y:898,t:1528143590238};\\\", \\\"{x:1345,y:898,t:1528143590597};\\\", \\\"{x:1338,y:894,t:1528143590606};\\\", \\\"{x:1331,y:890,t:1528143590618};\\\", \\\"{x:1313,y:879,t:1528143590634};\\\", \\\"{x:1281,y:860,t:1528143590651};\\\", \\\"{x:1240,y:838,t:1528143590668};\\\", \\\"{x:1212,y:820,t:1528143590684};\\\", \\\"{x:1179,y:795,t:1528143590702};\\\", \\\"{x:1153,y:776,t:1528143590717};\\\", \\\"{x:1132,y:764,t:1528143590734};\\\", \\\"{x:1093,y:750,t:1528143590751};\\\", \\\"{x:1048,y:737,t:1528143590768};\\\", \\\"{x:1012,y:727,t:1528143590784};\\\", \\\"{x:978,y:717,t:1528143590801};\\\", \\\"{x:936,y:707,t:1528143590817};\\\", \\\"{x:900,y:702,t:1528143590834};\\\", \\\"{x:866,y:696,t:1528143590851};\\\", \\\"{x:839,y:696,t:1528143590868};\\\", \\\"{x:805,y:696,t:1528143590885};\\\", \\\"{x:783,y:696,t:1528143590900};\\\", \\\"{x:759,y:696,t:1528143590918};\\\", \\\"{x:734,y:696,t:1528143590935};\\\", \\\"{x:704,y:694,t:1528143590951};\\\", \\\"{x:671,y:689,t:1528143590968};\\\", \\\"{x:645,y:684,t:1528143590985};\\\", \\\"{x:630,y:679,t:1528143591001};\\\", \\\"{x:620,y:674,t:1528143591018};\\\", \\\"{x:609,y:668,t:1528143591035};\\\", \\\"{x:593,y:660,t:1528143591052};\\\", \\\"{x:576,y:652,t:1528143591067};\\\", \\\"{x:530,y:643,t:1528143591084};\\\", \\\"{x:474,y:641,t:1528143591103};\\\", \\\"{x:423,y:641,t:1528143591118};\\\", \\\"{x:387,y:641,t:1528143591135};\\\", \\\"{x:360,y:641,t:1528143591153};\\\", \\\"{x:347,y:641,t:1528143591169};\\\", \\\"{x:344,y:641,t:1528143591185};\\\", \\\"{x:343,y:641,t:1528143591201};\\\", \\\"{x:342,y:641,t:1528143591219};\\\", \\\"{x:341,y:641,t:1528143591235};\\\", \\\"{x:338,y:641,t:1528143591252};\\\", \\\"{x:332,y:641,t:1528143591268};\\\", \\\"{x:327,y:640,t:1528143591285};\\\", \\\"{x:319,y:637,t:1528143591302};\\\", \\\"{x:308,y:631,t:1528143591320};\\\", \\\"{x:297,y:623,t:1528143591336};\\\", \\\"{x:286,y:613,t:1528143591352};\\\", \\\"{x:272,y:596,t:1528143591369};\\\", \\\"{x:263,y:588,t:1528143591386};\\\", \\\"{x:259,y:585,t:1528143591402};\\\", \\\"{x:257,y:583,t:1528143591418};\\\", \\\"{x:256,y:583,t:1528143591436};\\\", \\\"{x:253,y:583,t:1528143591452};\\\", \\\"{x:240,y:589,t:1528143591470};\\\", \\\"{x:224,y:600,t:1528143591486};\\\", \\\"{x:210,y:610,t:1528143591502};\\\", \\\"{x:199,y:617,t:1528143591519};\\\", \\\"{x:189,y:624,t:1528143591536};\\\", \\\"{x:186,y:626,t:1528143591552};\\\", \\\"{x:184,y:626,t:1528143591613};\\\", \\\"{x:182,y:624,t:1528143591621};\\\", \\\"{x:178,y:620,t:1528143591637};\\\", \\\"{x:169,y:611,t:1528143591652};\\\", \\\"{x:166,y:604,t:1528143591670};\\\", \\\"{x:164,y:601,t:1528143591685};\\\", \\\"{x:164,y:596,t:1528143591703};\\\", \\\"{x:164,y:592,t:1528143591720};\\\", \\\"{x:162,y:589,t:1528143591735};\\\", \\\"{x:161,y:585,t:1528143591753};\\\", \\\"{x:160,y:582,t:1528143591769};\\\", \\\"{x:159,y:579,t:1528143591785};\\\", \\\"{x:158,y:579,t:1528143591802};\\\", \\\"{x:158,y:578,t:1528143591819};\\\", \\\"{x:158,y:577,t:1528143591835};\\\", \\\"{x:168,y:577,t:1528143592132};\\\", \\\"{x:217,y:594,t:1528143592141};\\\", \\\"{x:295,y:628,t:1528143592152};\\\", \\\"{x:480,y:713,t:1528143592170};\\\", \\\"{x:698,y:803,t:1528143592186};\\\", \\\"{x:936,y:884,t:1528143592202};\\\", \\\"{x:1126,y:937,t:1528143592220};\\\", \\\"{x:1235,y:967,t:1528143592236};\\\", \\\"{x:1257,y:971,t:1528143592252};\\\", \\\"{x:1264,y:972,t:1528143592270};\\\", \\\"{x:1266,y:972,t:1528143592287};\\\", \\\"{x:1267,y:972,t:1528143592302};\\\", \\\"{x:1271,y:972,t:1528143592320};\\\", \\\"{x:1272,y:972,t:1528143592337};\\\", \\\"{x:1273,y:971,t:1528143592373};\\\", \\\"{x:1273,y:968,t:1528143592387};\\\", \\\"{x:1270,y:962,t:1528143592403};\\\", \\\"{x:1270,y:957,t:1528143592420};\\\", \\\"{x:1273,y:944,t:1528143592437};\\\", \\\"{x:1277,y:936,t:1528143592453};\\\", \\\"{x:1278,y:931,t:1528143592470};\\\", \\\"{x:1278,y:929,t:1528143592487};\\\", \\\"{x:1278,y:927,t:1528143592502};\\\", \\\"{x:1278,y:923,t:1528143592520};\\\", \\\"{x:1278,y:921,t:1528143592537};\\\", \\\"{x:1278,y:920,t:1528143592553};\\\", \\\"{x:1277,y:919,t:1528143592570};\\\", \\\"{x:1276,y:919,t:1528143592621};\\\", \\\"{x:1273,y:921,t:1528143592637};\\\", \\\"{x:1273,y:928,t:1528143592653};\\\", \\\"{x:1274,y:934,t:1528143592670};\\\", \\\"{x:1280,y:941,t:1528143592688};\\\", \\\"{x:1284,y:947,t:1528143592704};\\\", \\\"{x:1288,y:954,t:1528143592720};\\\", \\\"{x:1291,y:963,t:1528143592738};\\\", \\\"{x:1292,y:967,t:1528143592753};\\\", \\\"{x:1293,y:969,t:1528143592771};\\\", \\\"{x:1294,y:969,t:1528143592797};\\\", \\\"{x:1295,y:969,t:1528143592805};\\\", \\\"{x:1296,y:969,t:1528143592838};\\\", \\\"{x:1297,y:968,t:1528143592966};\\\", \\\"{x:1298,y:968,t:1528143593046};\\\", \\\"{x:1299,y:968,t:1528143593054};\\\", \\\"{x:1300,y:967,t:1528143593070};\\\", \\\"{x:1303,y:966,t:1528143593087};\\\", \\\"{x:1305,y:965,t:1528143593109};\\\", \\\"{x:1307,y:965,t:1528143593120};\\\", \\\"{x:1308,y:965,t:1528143593137};\\\", \\\"{x:1310,y:964,t:1528143593155};\\\", \\\"{x:1310,y:963,t:1528143593333};\\\", \\\"{x:1311,y:963,t:1528143593340};\\\", \\\"{x:1312,y:963,t:1528143593357};\\\", \\\"{x:1313,y:962,t:1528143593370};\\\", \\\"{x:1319,y:962,t:1528143593387};\\\", \\\"{x:1322,y:962,t:1528143593403};\\\", \\\"{x:1324,y:962,t:1528143593421};\\\", \\\"{x:1325,y:962,t:1528143593437};\\\", \\\"{x:1325,y:963,t:1528143593541};\\\", \\\"{x:1324,y:963,t:1528143593557};\\\", \\\"{x:1323,y:963,t:1528143593573};\\\", \\\"{x:1321,y:963,t:1528143593587};\\\", \\\"{x:1320,y:964,t:1528143593604};\\\", \\\"{x:1318,y:965,t:1528143593622};\\\", \\\"{x:1317,y:966,t:1528143593636};\\\", \\\"{x:1316,y:966,t:1528143593654};\\\", \\\"{x:1314,y:967,t:1528143593671};\\\", \\\"{x:1313,y:967,t:1528143618318};\\\", \\\"{x:1313,y:968,t:1528143618540};\\\", \\\"{x:1311,y:970,t:1528143618553};\\\", \\\"{x:1306,y:972,t:1528143618568};\\\", \\\"{x:1302,y:974,t:1528143618586};\\\", \\\"{x:1261,y:974,t:1528143618602};\\\", \\\"{x:1124,y:938,t:1528143618619};\\\", \\\"{x:899,y:862,t:1528143618636};\\\", \\\"{x:482,y:684,t:1528143618653};\\\", \\\"{x:233,y:598,t:1528143618669};\\\", \\\"{x:56,y:541,t:1528143618686};\\\", \\\"{x:8,y:491,t:1528143618703};\\\", \\\"{x:8,y:481,t:1528143618724};\\\", \\\"{x:8,y:484,t:1528143618860};\\\", \\\"{x:8,y:487,t:1528143618874};\\\", \\\"{x:11,y:494,t:1528143618891};\\\", \\\"{x:20,y:506,t:1528143618908};\\\", \\\"{x:26,y:515,t:1528143618923};\\\", \\\"{x:34,y:525,t:1528143618941};\\\", \\\"{x:41,y:534,t:1528143618957};\\\", \\\"{x:50,y:545,t:1528143618975};\\\", \\\"{x:65,y:558,t:1528143618991};\\\", \\\"{x:82,y:567,t:1528143619006};\\\", \\\"{x:98,y:574,t:1528143619024};\\\", \\\"{x:113,y:578,t:1528143619039};\\\", \\\"{x:125,y:579,t:1528143619056};\\\", \\\"{x:137,y:579,t:1528143619073};\\\", \\\"{x:145,y:579,t:1528143619089};\\\", \\\"{x:159,y:580,t:1528143619106};\\\", \\\"{x:170,y:580,t:1528143619123};\\\", \\\"{x:173,y:580,t:1528143619141};\\\", \\\"{x:173,y:579,t:1528143619180};\\\", \\\"{x:173,y:578,t:1528143619190};\\\", \\\"{x:173,y:577,t:1528143619208};\\\", \\\"{x:173,y:576,t:1528143619224};\\\", \\\"{x:173,y:573,t:1528143619240};\\\", \\\"{x:173,y:572,t:1528143619258};\\\", \\\"{x:173,y:571,t:1528143619274};\\\", \\\"{x:172,y:571,t:1528143619348};\\\", \\\"{x:171,y:571,t:1528143619357};\\\", \\\"{x:170,y:571,t:1528143619380};\\\", \\\"{x:168,y:572,t:1528143619396};\\\", \\\"{x:167,y:573,t:1528143619412};\\\", \\\"{x:166,y:573,t:1528143619428};\\\", \\\"{x:164,y:573,t:1528143619440};\\\", \\\"{x:163,y:573,t:1528143619457};\\\", \\\"{x:164,y:571,t:1528143619591};\\\", \\\"{x:174,y:564,t:1528143619609};\\\", \\\"{x:187,y:557,t:1528143619625};\\\", \\\"{x:195,y:554,t:1528143619642};\\\", \\\"{x:203,y:551,t:1528143619659};\\\", \\\"{x:214,y:548,t:1528143619675};\\\", \\\"{x:237,y:542,t:1528143619692};\\\", \\\"{x:254,y:539,t:1528143619708};\\\", \\\"{x:272,y:537,t:1528143619724};\\\", \\\"{x:281,y:537,t:1528143619742};\\\", \\\"{x:286,y:537,t:1528143619758};\\\", \\\"{x:288,y:537,t:1528143619775};\\\", \\\"{x:291,y:537,t:1528143619792};\\\", \\\"{x:292,y:537,t:1528143619808};\\\", \\\"{x:295,y:537,t:1528143619825};\\\", \\\"{x:296,y:537,t:1528143619842};\\\", \\\"{x:299,y:537,t:1528143619858};\\\", \\\"{x:303,y:537,t:1528143619874};\\\", \\\"{x:305,y:537,t:1528143619892};\\\", \\\"{x:307,y:537,t:1528143619908};\\\", \\\"{x:311,y:537,t:1528143619925};\\\", \\\"{x:312,y:537,t:1528143619942};\\\", \\\"{x:314,y:537,t:1528143619959};\\\", \\\"{x:317,y:537,t:1528143619976};\\\", \\\"{x:320,y:537,t:1528143619992};\\\", \\\"{x:321,y:537,t:1528143620008};\\\", \\\"{x:322,y:537,t:1528143620025};\\\", \\\"{x:325,y:537,t:1528143620042};\\\", \\\"{x:327,y:537,t:1528143620058};\\\", \\\"{x:330,y:536,t:1528143620075};\\\", \\\"{x:332,y:536,t:1528143620091};\\\", \\\"{x:333,y:535,t:1528143620108};\\\", \\\"{x:334,y:535,t:1528143620139};\\\", \\\"{x:334,y:534,t:1528143620156};\\\", \\\"{x:336,y:534,t:1528143620172};\\\", \\\"{x:337,y:534,t:1528143620203};\\\", \\\"{x:339,y:534,t:1528143620228};\\\", \\\"{x:341,y:534,t:1528143620241};\\\", \\\"{x:356,y:534,t:1528143620258};\\\", \\\"{x:381,y:527,t:1528143620276};\\\", \\\"{x:382,y:527,t:1528143620292};\\\", \\\"{x:384,y:527,t:1528143620308};\\\", \\\"{x:385,y:526,t:1528143620667};\\\", \\\"{x:387,y:526,t:1528143620676};\\\", \\\"{x:388,y:525,t:1528143620692};\\\", \\\"{x:390,y:524,t:1528143620708};\\\", \\\"{x:391,y:524,t:1528143620725};\\\", \\\"{x:394,y:523,t:1528143620742};\\\", \\\"{x:409,y:525,t:1528143620758};\\\", \\\"{x:477,y:555,t:1528143620776};\\\", \\\"{x:597,y:597,t:1528143620793};\\\", \\\"{x:733,y:636,t:1528143620809};\\\", \\\"{x:844,y:671,t:1528143620826};\\\", \\\"{x:949,y:703,t:1528143620843};\\\", \\\"{x:1057,y:734,t:1528143620859};\\\", \\\"{x:1213,y:784,t:1528143620875};\\\", \\\"{x:1302,y:811,t:1528143620893};\\\", \\\"{x:1356,y:829,t:1528143620909};\\\", \\\"{x:1400,y:846,t:1528143620925};\\\", \\\"{x:1417,y:854,t:1528143620942};\\\", \\\"{x:1422,y:856,t:1528143620958};\\\", \\\"{x:1422,y:857,t:1528143620988};\\\", \\\"{x:1422,y:858,t:1528143621003};\\\", \\\"{x:1421,y:860,t:1528143621011};\\\", \\\"{x:1417,y:863,t:1528143621025};\\\", \\\"{x:1406,y:869,t:1528143621043};\\\", \\\"{x:1388,y:874,t:1528143621060};\\\", \\\"{x:1363,y:877,t:1528143621075};\\\", \\\"{x:1318,y:877,t:1528143621093};\\\", \\\"{x:1270,y:879,t:1528143621110};\\\", \\\"{x:1239,y:884,t:1528143621126};\\\", \\\"{x:1218,y:887,t:1528143621143};\\\", \\\"{x:1209,y:891,t:1528143621160};\\\", \\\"{x:1207,y:891,t:1528143621176};\\\", \\\"{x:1207,y:893,t:1528143621192};\\\", \\\"{x:1206,y:893,t:1528143621228};\\\", \\\"{x:1206,y:896,t:1528143621244};\\\", \\\"{x:1211,y:904,t:1528143621260};\\\", \\\"{x:1227,y:919,t:1528143621276};\\\", \\\"{x:1250,y:935,t:1528143621293};\\\", \\\"{x:1273,y:946,t:1528143621310};\\\", \\\"{x:1294,y:954,t:1528143621325};\\\", \\\"{x:1309,y:958,t:1528143621343};\\\", \\\"{x:1314,y:960,t:1528143621359};\\\", \\\"{x:1314,y:961,t:1528143621492};\\\", \\\"{x:1314,y:962,t:1528143621500};\\\", \\\"{x:1313,y:962,t:1528143621510};\\\", \\\"{x:1312,y:962,t:1528143621526};\\\", \\\"{x:1310,y:964,t:1528143621542};\\\", \\\"{x:1309,y:964,t:1528143621676};\\\", \\\"{x:1308,y:965,t:1528143621692};\\\", \\\"{x:1307,y:966,t:1528143621710};\\\", \\\"{x:1307,y:967,t:1528143621726};\\\", \\\"{x:1305,y:968,t:1528143621743};\\\", \\\"{x:1304,y:969,t:1528143621759};\\\", \\\"{x:1301,y:970,t:1528143621777};\\\", \\\"{x:1300,y:971,t:1528143621796};\\\", \\\"{x:1300,y:972,t:1528143621979};\\\", \\\"{x:1300,y:973,t:1528143621993};\\\", \\\"{x:1302,y:973,t:1528143622010};\\\", \\\"{x:1308,y:975,t:1528143622027};\\\", \\\"{x:1315,y:976,t:1528143622044};\\\", \\\"{x:1318,y:976,t:1528143622060};\\\", \\\"{x:1319,y:976,t:1528143622077};\\\", \\\"{x:1320,y:976,t:1528143622094};\\\", \\\"{x:1321,y:976,t:1528143622260};\\\", \\\"{x:1321,y:975,t:1528143622277};\\\", \\\"{x:1320,y:973,t:1528143622294};\\\", \\\"{x:1320,y:971,t:1528143622310};\\\", \\\"{x:1320,y:970,t:1528143622327};\\\", \\\"{x:1320,y:969,t:1528143622412};\\\", \\\"{x:1320,y:968,t:1528143622781};\\\", \\\"{x:1320,y:967,t:1528143622852};\\\", \\\"{x:1320,y:966,t:1528143622901};\\\", \\\"{x:1320,y:965,t:1528143622916};\\\", \\\"{x:1320,y:964,t:1528143640975};\\\", \\\"{x:1318,y:964,t:1528143641038};\\\", \\\"{x:1287,y:976,t:1528143641052};\\\", \\\"{x:1234,y:1000,t:1528143641069};\\\", \\\"{x:1231,y:1001,t:1528143641086};\\\", \\\"{x:1228,y:1003,t:1528143641198};\\\", \\\"{x:1223,y:1004,t:1528143641206};\\\", \\\"{x:1209,y:1008,t:1528143641218};\\\", \\\"{x:1157,y:1008,t:1528143641235};\\\", \\\"{x:1124,y:1007,t:1528143641252};\\\", \\\"{x:1117,y:1003,t:1528143641269};\\\", \\\"{x:1090,y:966,t:1528143641286};\\\", \\\"{x:1066,y:927,t:1528143641301};\\\", \\\"{x:1056,y:906,t:1528143641318};\\\", \\\"{x:1038,y:884,t:1528143641335};\\\", \\\"{x:986,y:841,t:1528143641352};\\\", \\\"{x:922,y:799,t:1528143641368};\\\", \\\"{x:898,y:784,t:1528143641384};\\\", \\\"{x:882,y:772,t:1528143641402};\\\", \\\"{x:870,y:763,t:1528143641418};\\\", \\\"{x:858,y:755,t:1528143641435};\\\", \\\"{x:850,y:746,t:1528143641452};\\\", \\\"{x:836,y:732,t:1528143641468};\\\", \\\"{x:761,y:685,t:1528143641485};\\\", \\\"{x:700,y:657,t:1528143641504};\\\", \\\"{x:674,y:647,t:1528143641518};\\\", \\\"{x:649,y:640,t:1528143641535};\\\", \\\"{x:640,y:636,t:1528143641547};\\\", \\\"{x:633,y:636,t:1528143641563};\\\", \\\"{x:628,y:635,t:1528143641580};\\\", \\\"{x:625,y:633,t:1528143641596};\\\", \\\"{x:624,y:633,t:1528143641621};\\\", \\\"{x:623,y:630,t:1528143641645};\\\", \\\"{x:621,y:625,t:1528143641653};\\\", \\\"{x:620,y:624,t:1528143641668};\\\", \\\"{x:616,y:611,t:1528143641685};\\\", \\\"{x:614,y:599,t:1528143641702};\\\", \\\"{x:613,y:588,t:1528143641720};\\\", \\\"{x:613,y:573,t:1528143641736};\\\", \\\"{x:613,y:559,t:1528143641752};\\\", \\\"{x:613,y:552,t:1528143641769};\\\", \\\"{x:612,y:548,t:1528143641787};\\\", \\\"{x:612,y:547,t:1528143641802};\\\", \\\"{x:612,y:546,t:1528143641819};\\\", \\\"{x:612,y:545,t:1528143641836};\\\", \\\"{x:612,y:543,t:1528143641852};\\\", \\\"{x:635,y:534,t:1528143641869};\\\", \\\"{x:671,y:528,t:1528143641885};\\\", \\\"{x:725,y:525,t:1528143641903};\\\", \\\"{x:771,y:522,t:1528143641919};\\\", \\\"{x:793,y:519,t:1528143641936};\\\", \\\"{x:804,y:516,t:1528143641951};\\\", \\\"{x:805,y:516,t:1528143641969};\\\", \\\"{x:807,y:516,t:1528143642013};\\\", \\\"{x:808,y:518,t:1528143642053};\\\", \\\"{x:809,y:519,t:1528143642069};\\\", \\\"{x:809,y:520,t:1528143642086};\\\", \\\"{x:809,y:521,t:1528143642108};\\\", \\\"{x:809,y:522,t:1528143642158};\\\", \\\"{x:810,y:524,t:1528143642197};\\\", \\\"{x:814,y:524,t:1528143642205};\\\", \\\"{x:816,y:525,t:1528143642219};\\\", \\\"{x:823,y:526,t:1528143642236};\\\", \\\"{x:830,y:527,t:1528143642254};\\\", \\\"{x:831,y:527,t:1528143642269};\\\", \\\"{x:832,y:528,t:1528143642557};\\\", \\\"{x:838,y:535,t:1528143642568};\\\", \\\"{x:856,y:562,t:1528143642587};\\\", \\\"{x:898,y:615,t:1528143642603};\\\", \\\"{x:949,y:665,t:1528143642621};\\\", \\\"{x:990,y:696,t:1528143642636};\\\", \\\"{x:1060,y:725,t:1528143642653};\\\", \\\"{x:1087,y:730,t:1528143642669};\\\", \\\"{x:1092,y:730,t:1528143642686};\\\", \\\"{x:1095,y:730,t:1528143642703};\\\", \\\"{x:1096,y:729,t:1528143642720};\\\", \\\"{x:1098,y:729,t:1528143642736};\\\", \\\"{x:1107,y:729,t:1528143642753};\\\", \\\"{x:1124,y:729,t:1528143642771};\\\", \\\"{x:1148,y:737,t:1528143642787};\\\", \\\"{x:1180,y:750,t:1528143642804};\\\", \\\"{x:1224,y:776,t:1528143642821};\\\", \\\"{x:1258,y:800,t:1528143642837};\\\", \\\"{x:1288,y:826,t:1528143642853};\\\", \\\"{x:1303,y:838,t:1528143642870};\\\", \\\"{x:1311,y:844,t:1528143642887};\\\", \\\"{x:1317,y:847,t:1528143642903};\\\", \\\"{x:1319,y:849,t:1528143642921};\\\", \\\"{x:1324,y:852,t:1528143642937};\\\", \\\"{x:1334,y:854,t:1528143642954};\\\", \\\"{x:1350,y:859,t:1528143642971};\\\", \\\"{x:1367,y:864,t:1528143642987};\\\", \\\"{x:1380,y:869,t:1528143643004};\\\", \\\"{x:1389,y:874,t:1528143643021};\\\", \\\"{x:1393,y:877,t:1528143643037};\\\", \\\"{x:1393,y:880,t:1528143643055};\\\", \\\"{x:1393,y:884,t:1528143643071};\\\", \\\"{x:1392,y:892,t:1528143643087};\\\", \\\"{x:1388,y:904,t:1528143643103};\\\", \\\"{x:1383,y:918,t:1528143643121};\\\", \\\"{x:1377,y:934,t:1528143643137};\\\", \\\"{x:1366,y:955,t:1528143643154};\\\", \\\"{x:1358,y:978,t:1528143643171};\\\", \\\"{x:1350,y:1005,t:1528143643188};\\\", \\\"{x:1344,y:1026,t:1528143643203};\\\", \\\"{x:1342,y:1045,t:1528143643221};\\\", \\\"{x:1339,y:1065,t:1528143643238};\\\", \\\"{x:1339,y:1069,t:1528143643254};\\\", \\\"{x:1339,y:1071,t:1528143643270};\\\", \\\"{x:1339,y:1074,t:1528143643287};\\\", \\\"{x:1339,y:1075,t:1528143643303};\\\", \\\"{x:1339,y:1077,t:1528143643320};\\\", \\\"{x:1340,y:1078,t:1528143643337};\\\", \\\"{x:1339,y:1080,t:1528143643438};\\\", \\\"{x:1337,y:1081,t:1528143643453};\\\", \\\"{x:1334,y:1080,t:1528143644462};\\\", \\\"{x:1323,y:1077,t:1528143644471};\\\", \\\"{x:1303,y:1071,t:1528143644488};\\\", \\\"{x:1289,y:1067,t:1528143644505};\\\", \\\"{x:1277,y:1061,t:1528143644522};\\\", \\\"{x:1255,y:1053,t:1528143644538};\\\", \\\"{x:1231,y:1040,t:1528143644554};\\\", \\\"{x:1203,y:1026,t:1528143644571};\\\", \\\"{x:1182,y:1014,t:1528143644588};\\\", \\\"{x:1173,y:1009,t:1528143644604};\\\", \\\"{x:1170,y:1007,t:1528143644621};\\\", \\\"{x:1170,y:1006,t:1528143644638};\\\", \\\"{x:1169,y:1003,t:1528143644654};\\\", \\\"{x:1168,y:1000,t:1528143644671};\\\", \\\"{x:1167,y:996,t:1528143644688};\\\", \\\"{x:1167,y:992,t:1528143644704};\\\", \\\"{x:1166,y:988,t:1528143644722};\\\", \\\"{x:1166,y:981,t:1528143644739};\\\", \\\"{x:1166,y:971,t:1528143644754};\\\", \\\"{x:1171,y:953,t:1528143644772};\\\", \\\"{x:1181,y:930,t:1528143644789};\\\", \\\"{x:1201,y:894,t:1528143644804};\\\", \\\"{x:1230,y:833,t:1528143644822};\\\", \\\"{x:1253,y:808,t:1528143644838};\\\", \\\"{x:1271,y:795,t:1528143644855};\\\", \\\"{x:1288,y:785,t:1528143644872};\\\", \\\"{x:1300,y:781,t:1528143644889};\\\", \\\"{x:1306,y:779,t:1528143644905};\\\", \\\"{x:1307,y:777,t:1528143644922};\\\", \\\"{x:1309,y:775,t:1528143644939};\\\", \\\"{x:1314,y:765,t:1528143644955};\\\", \\\"{x:1316,y:754,t:1528143644972};\\\", \\\"{x:1320,y:740,t:1528143644989};\\\", \\\"{x:1320,y:722,t:1528143645005};\\\", \\\"{x:1320,y:704,t:1528143645022};\\\", \\\"{x:1320,y:689,t:1528143645039};\\\", \\\"{x:1320,y:676,t:1528143645056};\\\", \\\"{x:1323,y:662,t:1528143645072};\\\", \\\"{x:1324,y:645,t:1528143645088};\\\", \\\"{x:1326,y:634,t:1528143645106};\\\", \\\"{x:1338,y:613,t:1528143645121};\\\", \\\"{x:1346,y:595,t:1528143645139};\\\", \\\"{x:1354,y:582,t:1528143645156};\\\", \\\"{x:1363,y:569,t:1528143645171};\\\", \\\"{x:1369,y:557,t:1528143645188};\\\", \\\"{x:1372,y:550,t:1528143645206};\\\", \\\"{x:1372,y:549,t:1528143645487};\\\", \\\"{x:1371,y:551,t:1528143645494};\\\", \\\"{x:1371,y:554,t:1528143645506};\\\", \\\"{x:1370,y:559,t:1528143645523};\\\", \\\"{x:1370,y:564,t:1528143645539};\\\", \\\"{x:1370,y:568,t:1528143645555};\\\", \\\"{x:1370,y:573,t:1528143645573};\\\", \\\"{x:1372,y:579,t:1528143645589};\\\", \\\"{x:1376,y:587,t:1528143645606};\\\", \\\"{x:1380,y:593,t:1528143645622};\\\", \\\"{x:1381,y:599,t:1528143645639};\\\", \\\"{x:1384,y:604,t:1528143645655};\\\", \\\"{x:1385,y:611,t:1528143645673};\\\", \\\"{x:1388,y:617,t:1528143645689};\\\", \\\"{x:1389,y:622,t:1528143645706};\\\", \\\"{x:1391,y:624,t:1528143645723};\\\", \\\"{x:1391,y:629,t:1528143645739};\\\", \\\"{x:1392,y:634,t:1528143645756};\\\", \\\"{x:1393,y:643,t:1528143645773};\\\", \\\"{x:1395,y:652,t:1528143645788};\\\", \\\"{x:1395,y:664,t:1528143645805};\\\", \\\"{x:1396,y:672,t:1528143645823};\\\", \\\"{x:1397,y:679,t:1528143645840};\\\", \\\"{x:1400,y:689,t:1528143645856};\\\", \\\"{x:1401,y:696,t:1528143645873};\\\", \\\"{x:1401,y:702,t:1528143645891};\\\", \\\"{x:1403,y:709,t:1528143645906};\\\", \\\"{x:1405,y:715,t:1528143645923};\\\", \\\"{x:1407,y:719,t:1528143645939};\\\", \\\"{x:1409,y:725,t:1528143645955};\\\", \\\"{x:1409,y:727,t:1528143645972};\\\", \\\"{x:1412,y:733,t:1528143645989};\\\", \\\"{x:1413,y:735,t:1528143646005};\\\", \\\"{x:1415,y:739,t:1528143646022};\\\", \\\"{x:1417,y:743,t:1528143646039};\\\", \\\"{x:1421,y:748,t:1528143646055};\\\", \\\"{x:1425,y:753,t:1528143646072};\\\", \\\"{x:1430,y:759,t:1528143646089};\\\", \\\"{x:1433,y:763,t:1528143646106};\\\", \\\"{x:1437,y:768,t:1528143646122};\\\", \\\"{x:1446,y:778,t:1528143646139};\\\", \\\"{x:1457,y:788,t:1528143646156};\\\", \\\"{x:1472,y:801,t:1528143646173};\\\", \\\"{x:1483,y:813,t:1528143646189};\\\", \\\"{x:1486,y:817,t:1528143646206};\\\", \\\"{x:1488,y:820,t:1528143646222};\\\", \\\"{x:1489,y:823,t:1528143646239};\\\", \\\"{x:1490,y:827,t:1528143646257};\\\", \\\"{x:1492,y:831,t:1528143646273};\\\", \\\"{x:1494,y:834,t:1528143646290};\\\", \\\"{x:1496,y:837,t:1528143646307};\\\", \\\"{x:1497,y:842,t:1528143646322};\\\", \\\"{x:1500,y:847,t:1528143646339};\\\", \\\"{x:1501,y:853,t:1528143646357};\\\", \\\"{x:1504,y:859,t:1528143646372};\\\", \\\"{x:1507,y:871,t:1528143646389};\\\", \\\"{x:1510,y:877,t:1528143646406};\\\", \\\"{x:1512,y:882,t:1528143646423};\\\", \\\"{x:1514,y:886,t:1528143646440};\\\", \\\"{x:1517,y:889,t:1528143646457};\\\", \\\"{x:1518,y:891,t:1528143646472};\\\", \\\"{x:1520,y:894,t:1528143646490};\\\", \\\"{x:1522,y:897,t:1528143646507};\\\", \\\"{x:1523,y:899,t:1528143646523};\\\", \\\"{x:1524,y:903,t:1528143646539};\\\", \\\"{x:1527,y:907,t:1528143646556};\\\", \\\"{x:1528,y:911,t:1528143646573};\\\", \\\"{x:1530,y:916,t:1528143646590};\\\", \\\"{x:1531,y:920,t:1528143646607};\\\", \\\"{x:1531,y:922,t:1528143646622};\\\", \\\"{x:1532,y:927,t:1528143646640};\\\", \\\"{x:1534,y:930,t:1528143646657};\\\", \\\"{x:1535,y:933,t:1528143646674};\\\", \\\"{x:1535,y:938,t:1528143646690};\\\", \\\"{x:1538,y:941,t:1528143646708};\\\", \\\"{x:1539,y:945,t:1528143646724};\\\", \\\"{x:1542,y:948,t:1528143646740};\\\", \\\"{x:1544,y:952,t:1528143646757};\\\", \\\"{x:1544,y:953,t:1528143646774};\\\", \\\"{x:1545,y:953,t:1528143646798};\\\", \\\"{x:1546,y:953,t:1528143646822};\\\", \\\"{x:1547,y:953,t:1528143646830};\\\", \\\"{x:1547,y:954,t:1528143646840};\\\", \\\"{x:1548,y:954,t:1528143646857};\\\", \\\"{x:1549,y:955,t:1528143646902};\\\", \\\"{x:1550,y:956,t:1528143646934};\\\", \\\"{x:1551,y:957,t:1528143646966};\\\", \\\"{x:1552,y:957,t:1528143646974};\\\", \\\"{x:1553,y:959,t:1528143646990};\\\", \\\"{x:1553,y:960,t:1528143647022};\\\", \\\"{x:1554,y:961,t:1528143647030};\\\", \\\"{x:1554,y:962,t:1528143647102};\\\", \\\"{x:1535,y:950,t:1528143665743};\\\", \\\"{x:1484,y:908,t:1528143665755};\\\", \\\"{x:1299,y:781,t:1528143665772};\\\", \\\"{x:1179,y:690,t:1528143665789};\\\", \\\"{x:1164,y:655,t:1528143665805};\\\", \\\"{x:1163,y:655,t:1528143665878};\\\", \\\"{x:1162,y:655,t:1528143665889};\\\", \\\"{x:1161,y:655,t:1528143665906};\\\", \\\"{x:1145,y:642,t:1528143665942};\\\", \\\"{x:1109,y:615,t:1528143665956};\\\", \\\"{x:1000,y:578,t:1528143665972};\\\", \\\"{x:907,y:561,t:1528143665990};\\\", \\\"{x:827,y:548,t:1528143666005};\\\", \\\"{x:796,y:543,t:1528143666038};\\\", \\\"{x:794,y:543,t:1528143666076};\\\", \\\"{x:792,y:543,t:1528143666093};\\\", \\\"{x:786,y:543,t:1528143666105};\\\", \\\"{x:774,y:543,t:1528143666121};\\\", \\\"{x:764,y:547,t:1528143666138};\\\", \\\"{x:760,y:548,t:1528143666155};\\\", \\\"{x:760,y:549,t:1528143666171};\\\", \\\"{x:758,y:549,t:1528143666188};\\\", \\\"{x:745,y:550,t:1528143666204};\\\", \\\"{x:730,y:550,t:1528143666221};\\\", \\\"{x:715,y:546,t:1528143666239};\\\", \\\"{x:702,y:541,t:1528143666255};\\\", \\\"{x:697,y:539,t:1528143666272};\\\", \\\"{x:695,y:539,t:1528143666288};\\\", \\\"{x:693,y:539,t:1528143666305};\\\", \\\"{x:690,y:538,t:1528143666322};\\\", \\\"{x:685,y:538,t:1528143666338};\\\", \\\"{x:680,y:538,t:1528143666355};\\\", \\\"{x:676,y:538,t:1528143666371};\\\", \\\"{x:671,y:538,t:1528143666388};\\\", \\\"{x:668,y:538,t:1528143666405};\\\", \\\"{x:666,y:538,t:1528143666421};\\\", \\\"{x:663,y:538,t:1528143666438};\\\", \\\"{x:659,y:538,t:1528143666455};\\\", \\\"{x:653,y:538,t:1528143666472};\\\", \\\"{x:650,y:538,t:1528143666489};\\\", \\\"{x:647,y:538,t:1528143666505};\\\", \\\"{x:645,y:538,t:1528143666534};\\\", \\\"{x:643,y:538,t:1528143666550};\\\", \\\"{x:641,y:538,t:1528143666565};\\\", \\\"{x:640,y:538,t:1528143666573};\\\", \\\"{x:639,y:538,t:1528143666588};\\\", \\\"{x:637,y:538,t:1528143666607};\\\", \\\"{x:635,y:537,t:1528143666622};\\\", \\\"{x:634,y:537,t:1528143666639};\\\", \\\"{x:633,y:537,t:1528143666662};\\\", \\\"{x:639,y:536,t:1528143667030};\\\", \\\"{x:654,y:534,t:1528143667039};\\\", \\\"{x:705,y:532,t:1528143667056};\\\", \\\"{x:778,y:532,t:1528143667074};\\\", \\\"{x:839,y:532,t:1528143667089};\\\", \\\"{x:869,y:532,t:1528143667106};\\\", \\\"{x:890,y:532,t:1528143667124};\\\", \\\"{x:913,y:532,t:1528143667139};\\\", \\\"{x:931,y:532,t:1528143667156};\\\", \\\"{x:950,y:532,t:1528143667172};\\\", \\\"{x:969,y:532,t:1528143667189};\\\", \\\"{x:995,y:532,t:1528143667207};\\\", \\\"{x:1019,y:532,t:1528143667223};\\\", \\\"{x:1041,y:532,t:1528143667240};\\\", \\\"{x:1063,y:532,t:1528143667256};\\\", \\\"{x:1081,y:532,t:1528143667274};\\\", \\\"{x:1104,y:532,t:1528143667290};\\\", \\\"{x:1128,y:532,t:1528143667306};\\\", \\\"{x:1155,y:532,t:1528143667324};\\\", \\\"{x:1195,y:530,t:1528143667339};\\\", \\\"{x:1253,y:523,t:1528143667357};\\\", \\\"{x:1340,y:515,t:1528143667374};\\\", \\\"{x:1365,y:510,t:1528143667390};\\\", \\\"{x:1378,y:506,t:1528143667407};\\\", \\\"{x:1380,y:505,t:1528143667423};\\\", \\\"{x:1382,y:503,t:1528143667439};\\\", \\\"{x:1383,y:503,t:1528143667457};\\\", \\\"{x:1384,y:503,t:1528143667474};\\\", \\\"{x:1384,y:501,t:1528143667490};\\\", \\\"{x:1385,y:500,t:1528143667506};\\\", \\\"{x:1386,y:498,t:1528143667524};\\\", \\\"{x:1387,y:497,t:1528143667540};\\\", \\\"{x:1387,y:495,t:1528143667557};\\\", \\\"{x:1387,y:489,t:1528143667574};\\\", \\\"{x:1388,y:485,t:1528143667590};\\\", \\\"{x:1388,y:480,t:1528143667606};\\\", \\\"{x:1390,y:475,t:1528143667623};\\\", \\\"{x:1391,y:470,t:1528143667640};\\\", \\\"{x:1393,y:467,t:1528143667657};\\\", \\\"{x:1395,y:466,t:1528143667674};\\\", \\\"{x:1396,y:464,t:1528143667726};\\\", \\\"{x:1397,y:463,t:1528143667740};\\\", \\\"{x:1398,y:460,t:1528143667757};\\\", \\\"{x:1400,y:458,t:1528143667774};\\\", \\\"{x:1401,y:456,t:1528143667790};\\\", \\\"{x:1401,y:454,t:1528143667808};\\\", \\\"{x:1402,y:453,t:1528143667823};\\\", \\\"{x:1402,y:452,t:1528143667840};\\\", \\\"{x:1403,y:451,t:1528143667857};\\\", \\\"{x:1404,y:450,t:1528143667874};\\\", \\\"{x:1404,y:449,t:1528143667901};\\\", \\\"{x:1404,y:448,t:1528143667925};\\\", \\\"{x:1405,y:448,t:1528143668037};\\\", \\\"{x:1406,y:447,t:1528143668190};\\\", \\\"{x:1407,y:447,t:1528143668207};\\\", \\\"{x:1409,y:446,t:1528143668238};\\\", \\\"{x:1410,y:446,t:1528143668335};\\\", \\\"{x:1411,y:444,t:1528143668398};\\\", \\\"{x:1413,y:444,t:1528143668407};\\\", \\\"{x:1413,y:443,t:1528143668423};\\\", \\\"{x:1414,y:442,t:1528143668445};\\\", \\\"{x:1414,y:443,t:1528143669294};\\\", \\\"{x:1414,y:444,t:1528143669307};\\\", \\\"{x:1414,y:446,t:1528143669324};\\\", \\\"{x:1414,y:447,t:1528143669341};\\\", \\\"{x:1414,y:449,t:1528143669358};\\\", \\\"{x:1414,y:450,t:1528143669382};\\\", \\\"{x:1414,y:451,t:1528143669391};\\\", \\\"{x:1414,y:452,t:1528143669408};\\\", \\\"{x:1414,y:453,t:1528143669425};\\\", \\\"{x:1414,y:457,t:1528143669441};\\\", \\\"{x:1414,y:461,t:1528143669458};\\\", \\\"{x:1414,y:464,t:1528143669475};\\\", \\\"{x:1414,y:469,t:1528143669491};\\\", \\\"{x:1414,y:475,t:1528143669508};\\\", \\\"{x:1413,y:482,t:1528143669525};\\\", \\\"{x:1412,y:491,t:1528143669541};\\\", \\\"{x:1408,y:511,t:1528143669558};\\\", \\\"{x:1406,y:525,t:1528143669575};\\\", \\\"{x:1402,y:540,t:1528143669591};\\\", \\\"{x:1400,y:556,t:1528143669608};\\\", \\\"{x:1397,y:571,t:1528143669624};\\\", \\\"{x:1395,y:588,t:1528143669640};\\\", \\\"{x:1395,y:610,t:1528143669658};\\\", \\\"{x:1395,y:632,t:1528143669675};\\\", \\\"{x:1392,y:655,t:1528143669691};\\\", \\\"{x:1392,y:677,t:1528143669708};\\\", \\\"{x:1391,y:703,t:1528143669725};\\\", \\\"{x:1391,y:722,t:1528143669741};\\\", \\\"{x:1390,y:740,t:1528143669758};\\\", \\\"{x:1390,y:746,t:1528143669775};\\\", \\\"{x:1389,y:748,t:1528143669791};\\\", \\\"{x:1389,y:749,t:1528143669809};\\\", \\\"{x:1389,y:750,t:1528143669825};\\\", \\\"{x:1388,y:751,t:1528143669846};\\\", \\\"{x:1388,y:753,t:1528143669927};\\\", \\\"{x:1388,y:755,t:1528143669941};\\\", \\\"{x:1387,y:759,t:1528143669958};\\\", \\\"{x:1385,y:765,t:1528143669976};\\\", \\\"{x:1383,y:773,t:1528143669992};\\\", \\\"{x:1381,y:781,t:1528143670008};\\\", \\\"{x:1380,y:789,t:1528143670025};\\\", \\\"{x:1380,y:797,t:1528143670041};\\\", \\\"{x:1382,y:809,t:1528143670058};\\\", \\\"{x:1385,y:817,t:1528143670075};\\\", \\\"{x:1386,y:823,t:1528143670092};\\\", \\\"{x:1389,y:830,t:1528143670109};\\\", \\\"{x:1390,y:832,t:1528143670126};\\\", \\\"{x:1390,y:836,t:1528143670142};\\\", \\\"{x:1393,y:827,t:1528143670213};\\\", \\\"{x:1394,y:810,t:1528143670224};\\\", \\\"{x:1400,y:778,t:1528143670241};\\\", \\\"{x:1407,y:753,t:1528143670258};\\\", \\\"{x:1418,y:720,t:1528143670275};\\\", \\\"{x:1422,y:699,t:1528143670291};\\\", \\\"{x:1423,y:680,t:1528143670307};\\\", \\\"{x:1423,y:662,t:1528143670325};\\\", \\\"{x:1423,y:630,t:1528143670340};\\\", \\\"{x:1420,y:603,t:1528143670357};\\\", \\\"{x:1415,y:584,t:1528143670374};\\\", \\\"{x:1414,y:566,t:1528143670391};\\\", \\\"{x:1412,y:556,t:1528143670408};\\\", \\\"{x:1411,y:548,t:1528143670424};\\\", \\\"{x:1410,y:544,t:1528143670442};\\\", \\\"{x:1408,y:539,t:1528143670458};\\\", \\\"{x:1408,y:536,t:1528143670474};\\\", \\\"{x:1407,y:529,t:1528143670492};\\\", \\\"{x:1407,y:522,t:1528143670508};\\\", \\\"{x:1407,y:518,t:1528143670525};\\\", \\\"{x:1407,y:513,t:1528143670542};\\\", \\\"{x:1407,y:510,t:1528143670558};\\\", \\\"{x:1407,y:508,t:1528143670575};\\\", \\\"{x:1407,y:507,t:1528143670592};\\\", \\\"{x:1404,y:509,t:1528143670766};\\\", \\\"{x:1402,y:516,t:1528143670775};\\\", \\\"{x:1397,y:524,t:1528143670792};\\\", \\\"{x:1394,y:530,t:1528143670809};\\\", \\\"{x:1392,y:533,t:1528143670826};\\\", \\\"{x:1392,y:537,t:1528143670842};\\\", \\\"{x:1391,y:544,t:1528143670859};\\\", \\\"{x:1391,y:548,t:1528143670876};\\\", \\\"{x:1391,y:553,t:1528143670892};\\\", \\\"{x:1391,y:560,t:1528143670909};\\\", \\\"{x:1391,y:570,t:1528143670925};\\\", \\\"{x:1391,y:587,t:1528143670942};\\\", \\\"{x:1391,y:597,t:1528143670959};\\\", \\\"{x:1391,y:609,t:1528143670974};\\\", \\\"{x:1391,y:619,t:1528143670991};\\\", \\\"{x:1391,y:623,t:1528143671008};\\\", \\\"{x:1391,y:627,t:1528143671024};\\\", \\\"{x:1391,y:630,t:1528143671041};\\\", \\\"{x:1391,y:633,t:1528143671059};\\\", \\\"{x:1391,y:638,t:1528143671074};\\\", \\\"{x:1390,y:642,t:1528143671092};\\\", \\\"{x:1389,y:645,t:1528143671109};\\\", \\\"{x:1389,y:648,t:1528143671125};\\\", \\\"{x:1388,y:658,t:1528143671142};\\\", \\\"{x:1387,y:666,t:1528143671159};\\\", \\\"{x:1387,y:675,t:1528143671174};\\\", \\\"{x:1387,y:685,t:1528143671192};\\\", \\\"{x:1387,y:693,t:1528143671209};\\\", \\\"{x:1387,y:697,t:1528143671225};\\\", \\\"{x:1387,y:702,t:1528143671242};\\\", \\\"{x:1387,y:707,t:1528143671259};\\\", \\\"{x:1387,y:713,t:1528143671275};\\\", \\\"{x:1387,y:720,t:1528143671291};\\\", \\\"{x:1387,y:725,t:1528143671309};\\\", \\\"{x:1387,y:734,t:1528143671325};\\\", \\\"{x:1387,y:752,t:1528143671342};\\\", \\\"{x:1387,y:763,t:1528143671359};\\\", \\\"{x:1387,y:774,t:1528143671375};\\\", \\\"{x:1387,y:783,t:1528143671392};\\\", \\\"{x:1386,y:793,t:1528143671409};\\\", \\\"{x:1385,y:802,t:1528143671425};\\\", \\\"{x:1385,y:810,t:1528143671442};\\\", \\\"{x:1385,y:820,t:1528143671459};\\\", \\\"{x:1383,y:830,t:1528143671475};\\\", \\\"{x:1383,y:835,t:1528143671492};\\\", \\\"{x:1383,y:839,t:1528143671509};\\\", \\\"{x:1383,y:841,t:1528143671526};\\\", \\\"{x:1383,y:842,t:1528143671542};\\\", \\\"{x:1383,y:843,t:1528143671560};\\\", \\\"{x:1383,y:844,t:1528143671576};\\\", \\\"{x:1383,y:840,t:1528143671662};\\\", \\\"{x:1381,y:831,t:1528143671676};\\\", \\\"{x:1381,y:820,t:1528143671692};\\\", \\\"{x:1381,y:806,t:1528143671709};\\\", \\\"{x:1381,y:782,t:1528143671725};\\\", \\\"{x:1381,y:765,t:1528143671743};\\\", \\\"{x:1381,y:745,t:1528143671759};\\\", \\\"{x:1381,y:724,t:1528143671777};\\\", \\\"{x:1381,y:705,t:1528143671792};\\\", \\\"{x:1381,y:690,t:1528143671809};\\\", \\\"{x:1381,y:672,t:1528143671826};\\\", \\\"{x:1381,y:656,t:1528143671842};\\\", \\\"{x:1381,y:645,t:1528143671859};\\\", \\\"{x:1381,y:632,t:1528143671876};\\\", \\\"{x:1381,y:615,t:1528143671892};\\\", \\\"{x:1381,y:596,t:1528143671909};\\\", \\\"{x:1379,y:563,t:1528143671926};\\\", \\\"{x:1377,y:545,t:1528143671942};\\\", \\\"{x:1376,y:524,t:1528143671958};\\\", \\\"{x:1376,y:503,t:1528143671976};\\\", \\\"{x:1376,y:483,t:1528143671992};\\\", \\\"{x:1376,y:464,t:1528143672009};\\\", \\\"{x:1380,y:443,t:1528143672025};\\\", \\\"{x:1384,y:423,t:1528143672042};\\\", \\\"{x:1385,y:407,t:1528143672059};\\\", \\\"{x:1387,y:397,t:1528143672076};\\\", \\\"{x:1388,y:390,t:1528143672092};\\\", \\\"{x:1389,y:382,t:1528143672109};\\\", \\\"{x:1389,y:377,t:1528143672125};\\\", \\\"{x:1389,y:373,t:1528143672142};\\\", \\\"{x:1389,y:370,t:1528143672159};\\\", \\\"{x:1389,y:369,t:1528143672189};\\\", \\\"{x:1389,y:368,t:1528143672196};\\\", \\\"{x:1389,y:367,t:1528143672405};\\\", \\\"{x:1411,y:367,t:1528143672413};\\\", \\\"{x:1458,y:367,t:1528143672425};\\\", \\\"{x:1558,y:367,t:1528143672442};\\\", \\\"{x:1671,y:367,t:1528143672459};\\\", \\\"{x:1725,y:367,t:1528143672475};\\\", \\\"{x:1730,y:367,t:1528143672493};\\\", \\\"{x:1726,y:367,t:1528143672542};\\\", \\\"{x:1716,y:374,t:1528143672558};\\\", \\\"{x:1701,y:385,t:1528143672576};\\\", \\\"{x:1685,y:396,t:1528143672593};\\\", \\\"{x:1666,y:410,t:1528143672609};\\\", \\\"{x:1645,y:430,t:1528143672625};\\\", \\\"{x:1619,y:465,t:1528143672642};\\\", \\\"{x:1591,y:506,t:1528143672659};\\\", \\\"{x:1560,y:554,t:1528143672676};\\\", \\\"{x:1522,y:605,t:1528143672692};\\\", \\\"{x:1491,y:641,t:1528143672709};\\\", \\\"{x:1466,y:666,t:1528143672726};\\\", \\\"{x:1455,y:676,t:1528143672743};\\\", \\\"{x:1446,y:687,t:1528143672759};\\\", \\\"{x:1435,y:702,t:1528143672776};\\\", \\\"{x:1428,y:714,t:1528143672793};\\\", \\\"{x:1421,y:727,t:1528143672809};\\\", \\\"{x:1417,y:734,t:1528143672826};\\\", \\\"{x:1414,y:741,t:1528143672843};\\\", \\\"{x:1411,y:749,t:1528143672859};\\\", \\\"{x:1411,y:756,t:1528143672876};\\\", \\\"{x:1411,y:763,t:1528143672893};\\\", \\\"{x:1411,y:770,t:1528143672909};\\\", \\\"{x:1411,y:783,t:1528143672926};\\\", \\\"{x:1411,y:795,t:1528143672943};\\\", \\\"{x:1411,y:804,t:1528143672959};\\\", \\\"{x:1411,y:815,t:1528143672976};\\\", \\\"{x:1411,y:821,t:1528143672994};\\\", \\\"{x:1411,y:826,t:1528143673010};\\\", \\\"{x:1411,y:828,t:1528143673026};\\\", \\\"{x:1411,y:830,t:1528143673044};\\\", \\\"{x:1411,y:831,t:1528143673061};\\\", \\\"{x:1411,y:833,t:1528143673078};\\\", \\\"{x:1410,y:834,t:1528143673094};\\\", \\\"{x:1409,y:836,t:1528143673109};\\\", \\\"{x:1408,y:837,t:1528143673126};\\\", \\\"{x:1408,y:838,t:1528143673143};\\\", \\\"{x:1406,y:840,t:1528143673161};\\\", \\\"{x:1405,y:841,t:1528143673176};\\\", \\\"{x:1404,y:843,t:1528143673193};\\\", \\\"{x:1402,y:845,t:1528143673210};\\\", \\\"{x:1401,y:847,t:1528143673226};\\\", \\\"{x:1398,y:850,t:1528143673243};\\\", \\\"{x:1397,y:851,t:1528143673260};\\\", \\\"{x:1395,y:853,t:1528143673276};\\\", \\\"{x:1395,y:854,t:1528143673293};\\\", \\\"{x:1394,y:854,t:1528143673310};\\\", \\\"{x:1393,y:856,t:1528143673326};\\\", \\\"{x:1391,y:858,t:1528143673343};\\\", \\\"{x:1391,y:859,t:1528143673360};\\\", \\\"{x:1389,y:861,t:1528143673376};\\\", \\\"{x:1388,y:862,t:1528143673393};\\\", \\\"{x:1386,y:864,t:1528143673410};\\\", \\\"{x:1385,y:865,t:1528143673426};\\\", \\\"{x:1379,y:866,t:1528143673443};\\\", \\\"{x:1374,y:867,t:1528143673460};\\\", \\\"{x:1365,y:869,t:1528143673476};\\\", \\\"{x:1364,y:870,t:1528143673493};\\\", \\\"{x:1361,y:870,t:1528143673510};\\\", \\\"{x:1360,y:870,t:1528143673854};\\\", \\\"{x:1359,y:870,t:1528143673877};\\\", \\\"{x:1358,y:870,t:1528143673926};\\\", \\\"{x:1356,y:870,t:1528143673943};\\\", \\\"{x:1355,y:870,t:1528143673960};\\\", \\\"{x:1353,y:870,t:1528143673977};\\\", \\\"{x:1351,y:870,t:1528143673998};\\\", \\\"{x:1350,y:870,t:1528143674030};\\\", \\\"{x:1348,y:870,t:1528143674046};\\\", \\\"{x:1348,y:869,t:1528143674060};\\\", \\\"{x:1347,y:869,t:1528143674078};\\\", \\\"{x:1346,y:868,t:1528143674126};\\\", \\\"{x:1345,y:868,t:1528143674143};\\\", \\\"{x:1344,y:868,t:1528143674310};\\\", \\\"{x:1342,y:867,t:1528143674336};\\\", \\\"{x:1341,y:867,t:1528143674350};\\\", \\\"{x:1338,y:867,t:1528143674360};\\\", \\\"{x:1335,y:866,t:1528143674378};\\\", \\\"{x:1332,y:866,t:1528143674393};\\\", \\\"{x:1331,y:866,t:1528143674410};\\\", \\\"{x:1329,y:866,t:1528143674429};\\\", \\\"{x:1327,y:866,t:1528143674445};\\\", \\\"{x:1325,y:866,t:1528143674460};\\\", \\\"{x:1323,y:866,t:1528143674478};\\\", \\\"{x:1320,y:866,t:1528143674493};\\\", \\\"{x:1318,y:866,t:1528143674510};\\\", \\\"{x:1316,y:866,t:1528143674527};\\\", \\\"{x:1315,y:865,t:1528143674544};\\\", \\\"{x:1314,y:865,t:1528143674560};\\\", \\\"{x:1312,y:864,t:1528143674577};\\\", \\\"{x:1309,y:864,t:1528143674594};\\\", \\\"{x:1305,y:863,t:1528143674610};\\\", \\\"{x:1300,y:863,t:1528143674627};\\\", \\\"{x:1297,y:863,t:1528143674644};\\\", \\\"{x:1295,y:863,t:1528143674660};\\\", \\\"{x:1294,y:863,t:1528143674677};\\\", \\\"{x:1292,y:863,t:1528143674726};\\\", \\\"{x:1291,y:862,t:1528143674853};\\\", \\\"{x:1291,y:861,t:1528143674966};\\\", \\\"{x:1291,y:860,t:1528143675022};\\\", \\\"{x:1291,y:859,t:1528143675166};\\\", \\\"{x:1291,y:858,t:1528143675197};\\\", \\\"{x:1291,y:857,t:1528143675212};\\\", \\\"{x:1292,y:856,t:1528143675246};\\\", \\\"{x:1292,y:855,t:1528143675302};\\\", \\\"{x:1292,y:854,t:1528143675317};\\\", \\\"{x:1294,y:853,t:1528143675335};\\\", \\\"{x:1294,y:852,t:1528143675358};\\\", \\\"{x:1295,y:851,t:1528143675414};\\\", \\\"{x:1295,y:850,t:1528143675501};\\\", \\\"{x:1296,y:848,t:1528143675542};\\\", \\\"{x:1296,y:847,t:1528143675622};\\\", \\\"{x:1297,y:847,t:1528143675637};\\\", \\\"{x:1298,y:846,t:1528143675653};\\\", \\\"{x:1299,y:846,t:1528143675678};\\\", \\\"{x:1300,y:844,t:1528143675741};\\\", \\\"{x:1301,y:844,t:1528143675790};\\\", \\\"{x:1301,y:842,t:1528143675893};\\\", \\\"{x:1302,y:841,t:1528143676110};\\\", \\\"{x:1302,y:839,t:1528143676806};\\\", \\\"{x:1302,y:838,t:1528143676870};\\\", \\\"{x:1301,y:837,t:1528143676902};\\\", \\\"{x:1300,y:836,t:1528143676918};\\\", \\\"{x:1299,y:835,t:1528143676936};\\\", \\\"{x:1298,y:835,t:1528143676945};\\\", \\\"{x:1297,y:835,t:1528143676961};\\\", \\\"{x:1295,y:834,t:1528143676977};\\\", \\\"{x:1294,y:833,t:1528143676994};\\\", \\\"{x:1293,y:833,t:1528143677010};\\\", \\\"{x:1292,y:833,t:1528143677053};\\\", \\\"{x:1291,y:832,t:1528143677093};\\\", \\\"{x:1290,y:831,t:1528143677494};\\\", \\\"{x:1290,y:828,t:1528143677512};\\\", \\\"{x:1291,y:824,t:1528143677528};\\\", \\\"{x:1292,y:821,t:1528143677545};\\\", \\\"{x:1293,y:818,t:1528143677562};\\\", \\\"{x:1295,y:814,t:1528143677578};\\\", \\\"{x:1296,y:811,t:1528143677595};\\\", \\\"{x:1296,y:808,t:1528143677612};\\\", \\\"{x:1298,y:803,t:1528143677628};\\\", \\\"{x:1300,y:792,t:1528143677646};\\\", \\\"{x:1304,y:786,t:1528143677662};\\\", \\\"{x:1305,y:779,t:1528143677678};\\\", \\\"{x:1305,y:773,t:1528143677696};\\\", \\\"{x:1307,y:767,t:1528143677713};\\\", \\\"{x:1308,y:760,t:1528143677728};\\\", \\\"{x:1308,y:752,t:1528143677746};\\\", \\\"{x:1309,y:742,t:1528143677762};\\\", \\\"{x:1312,y:729,t:1528143677778};\\\", \\\"{x:1313,y:718,t:1528143677796};\\\", \\\"{x:1314,y:709,t:1528143677812};\\\", \\\"{x:1315,y:700,t:1528143677828};\\\", \\\"{x:1316,y:689,t:1528143677846};\\\", \\\"{x:1316,y:684,t:1528143677862};\\\", \\\"{x:1317,y:678,t:1528143677878};\\\", \\\"{x:1318,y:674,t:1528143677895};\\\", \\\"{x:1318,y:671,t:1528143677912};\\\", \\\"{x:1318,y:670,t:1528143677928};\\\", \\\"{x:1318,y:667,t:1528143677944};\\\", \\\"{x:1318,y:665,t:1528143677962};\\\", \\\"{x:1318,y:664,t:1528143677978};\\\", \\\"{x:1318,y:663,t:1528143677995};\\\", \\\"{x:1318,y:662,t:1528143678012};\\\", \\\"{x:1318,y:661,t:1528143678037};\\\", \\\"{x:1318,y:660,t:1528143678094};\\\", \\\"{x:1318,y:659,t:1528143678109};\\\", \\\"{x:1318,y:658,t:1528143678117};\\\", \\\"{x:1317,y:658,t:1528143678129};\\\", \\\"{x:1316,y:656,t:1528143678145};\\\", \\\"{x:1316,y:655,t:1528143678162};\\\", \\\"{x:1315,y:654,t:1528143678179};\\\", \\\"{x:1315,y:653,t:1528143678195};\\\", \\\"{x:1315,y:652,t:1528143678212};\\\", \\\"{x:1315,y:651,t:1528143678229};\\\", \\\"{x:1315,y:650,t:1528143678245};\\\", \\\"{x:1315,y:649,t:1528143678262};\\\", \\\"{x:1315,y:648,t:1528143678294};\\\", \\\"{x:1315,y:647,t:1528143678318};\\\", \\\"{x:1315,y:646,t:1528143678334};\\\", \\\"{x:1315,y:645,t:1528143678382};\\\", \\\"{x:1315,y:644,t:1528143678395};\\\", \\\"{x:1315,y:643,t:1528143678413};\\\", \\\"{x:1316,y:641,t:1528143678453};\\\", \\\"{x:1317,y:640,t:1528143678710};\\\", \\\"{x:1318,y:639,t:1528143678910};\\\", \\\"{x:1318,y:638,t:1528143681735};\\\", \\\"{x:1317,y:638,t:1528143681862};\\\", \\\"{x:1316,y:637,t:1528143681886};\\\", \\\"{x:1315,y:636,t:1528143682398};\\\", \\\"{x:1314,y:636,t:1528143682477};\\\", \\\"{x:1313,y:636,t:1528143682502};\\\", \\\"{x:1312,y:636,t:1528143682646};\\\", \\\"{x:1311,y:636,t:1528143682702};\\\", \\\"{x:1310,y:636,t:1528143682807};\\\", \\\"{x:1314,y:633,t:1528143688823};\\\", \\\"{x:1315,y:633,t:1528143688843};\\\", \\\"{x:1317,y:632,t:1528143688860};\\\", \\\"{x:1319,y:631,t:1528143688877};\\\", \\\"{x:1320,y:630,t:1528143688893};\\\", \\\"{x:1322,y:629,t:1528143688911};\\\", \\\"{x:1325,y:627,t:1528143688927};\\\", \\\"{x:1325,y:626,t:1528143688943};\\\", \\\"{x:1327,y:624,t:1528143688960};\\\", \\\"{x:1328,y:623,t:1528143688977};\\\", \\\"{x:1329,y:621,t:1528143688993};\\\", \\\"{x:1330,y:619,t:1528143689011};\\\", \\\"{x:1331,y:617,t:1528143689027};\\\", \\\"{x:1331,y:612,t:1528143689043};\\\", \\\"{x:1331,y:606,t:1528143689060};\\\", \\\"{x:1331,y:601,t:1528143689077};\\\", \\\"{x:1331,y:596,t:1528143689093};\\\", \\\"{x:1329,y:590,t:1528143689111};\\\", \\\"{x:1326,y:585,t:1528143689127};\\\", \\\"{x:1324,y:582,t:1528143689144};\\\", \\\"{x:1322,y:577,t:1528143689160};\\\", \\\"{x:1321,y:576,t:1528143689177};\\\", \\\"{x:1321,y:573,t:1528143689195};\\\", \\\"{x:1321,y:572,t:1528143689210};\\\", \\\"{x:1321,y:571,t:1528143689303};\\\", \\\"{x:1321,y:570,t:1528143689326};\\\", \\\"{x:1319,y:569,t:1528143689334};\\\", \\\"{x:1319,y:567,t:1528143689343};\\\", \\\"{x:1318,y:565,t:1528143689359};\\\", \\\"{x:1317,y:563,t:1528143689376};\\\", \\\"{x:1317,y:562,t:1528143689393};\\\", \\\"{x:1316,y:560,t:1528143689410};\\\", \\\"{x:1315,y:560,t:1528143689427};\\\", \\\"{x:1315,y:557,t:1528143689444};\\\", \\\"{x:1314,y:556,t:1528143689460};\\\", \\\"{x:1313,y:553,t:1528143689477};\\\", \\\"{x:1313,y:551,t:1528143689493};\\\", \\\"{x:1313,y:549,t:1528143689510};\\\", \\\"{x:1313,y:548,t:1528143689527};\\\", \\\"{x:1313,y:546,t:1528143689544};\\\", \\\"{x:1313,y:545,t:1528143689560};\\\", \\\"{x:1313,y:542,t:1528143689577};\\\", \\\"{x:1313,y:540,t:1528143689594};\\\", \\\"{x:1313,y:537,t:1528143689610};\\\", \\\"{x:1313,y:536,t:1528143689627};\\\", \\\"{x:1313,y:535,t:1528143689644};\\\", \\\"{x:1313,y:534,t:1528143689662};\\\", \\\"{x:1313,y:533,t:1528143689677};\\\", \\\"{x:1313,y:532,t:1528143689694};\\\", \\\"{x:1313,y:530,t:1528143689710};\\\", \\\"{x:1313,y:529,t:1528143689735};\\\", \\\"{x:1313,y:528,t:1528143690167};\\\", \\\"{x:1313,y:527,t:1528143690182};\\\", \\\"{x:1313,y:526,t:1528143690194};\\\", \\\"{x:1313,y:525,t:1528143690215};\\\", \\\"{x:1313,y:524,t:1528143690228};\\\", \\\"{x:1313,y:523,t:1528143690255};\\\", \\\"{x:1313,y:522,t:1528143690279};\\\", \\\"{x:1313,y:521,t:1528143691103};\\\", \\\"{x:1313,y:523,t:1528143691151};\\\", \\\"{x:1313,y:527,t:1528143691162};\\\", \\\"{x:1313,y:535,t:1528143691179};\\\", \\\"{x:1313,y:545,t:1528143691194};\\\", \\\"{x:1313,y:557,t:1528143691211};\\\", \\\"{x:1313,y:569,t:1528143691228};\\\", \\\"{x:1313,y:584,t:1528143691244};\\\", \\\"{x:1313,y:603,t:1528143691262};\\\", \\\"{x:1313,y:619,t:1528143691279};\\\", \\\"{x:1318,y:641,t:1528143691296};\\\", \\\"{x:1322,y:655,t:1528143691311};\\\", \\\"{x:1328,y:665,t:1528143691328};\\\", \\\"{x:1333,y:672,t:1528143691345};\\\", \\\"{x:1336,y:676,t:1528143691361};\\\", \\\"{x:1337,y:680,t:1528143691378};\\\", \\\"{x:1339,y:685,t:1528143691395};\\\", \\\"{x:1339,y:694,t:1528143691412};\\\", \\\"{x:1339,y:706,t:1528143691428};\\\", \\\"{x:1339,y:723,t:1528143691445};\\\", \\\"{x:1339,y:739,t:1528143691461};\\\", \\\"{x:1341,y:755,t:1528143691479};\\\", \\\"{x:1343,y:767,t:1528143691495};\\\", \\\"{x:1343,y:770,t:1528143691511};\\\", \\\"{x:1344,y:776,t:1528143691528};\\\", \\\"{x:1345,y:781,t:1528143691545};\\\", \\\"{x:1345,y:786,t:1528143691562};\\\", \\\"{x:1345,y:797,t:1528143691578};\\\", \\\"{x:1345,y:807,t:1528143691596};\\\", \\\"{x:1345,y:815,t:1528143691611};\\\", \\\"{x:1344,y:823,t:1528143691628};\\\", \\\"{x:1343,y:832,t:1528143691652};\\\", \\\"{x:1343,y:835,t:1528143691660};\\\", \\\"{x:1342,y:843,t:1528143691678};\\\", \\\"{x:1339,y:849,t:1528143691694};\\\", \\\"{x:1335,y:857,t:1528143691710};\\\", \\\"{x:1330,y:867,t:1528143691727};\\\", \\\"{x:1325,y:880,t:1528143691744};\\\", \\\"{x:1323,y:889,t:1528143691760};\\\", \\\"{x:1320,y:895,t:1528143691778};\\\", \\\"{x:1319,y:901,t:1528143691794};\\\", \\\"{x:1318,y:906,t:1528143691811};\\\", \\\"{x:1317,y:908,t:1528143691828};\\\", \\\"{x:1316,y:910,t:1528143691845};\\\", \\\"{x:1316,y:912,t:1528143691861};\\\", \\\"{x:1316,y:916,t:1528143691878};\\\", \\\"{x:1316,y:917,t:1528143691894};\\\", \\\"{x:1316,y:919,t:1528143691911};\\\", \\\"{x:1316,y:920,t:1528143691950};\\\", \\\"{x:1318,y:920,t:1528143691967};\\\", \\\"{x:1320,y:920,t:1528143691978};\\\", \\\"{x:1328,y:916,t:1528143691995};\\\", \\\"{x:1339,y:909,t:1528143692011};\\\", \\\"{x:1346,y:904,t:1528143692028};\\\", \\\"{x:1348,y:903,t:1528143692045};\\\", \\\"{x:1352,y:901,t:1528143692062};\\\", \\\"{x:1353,y:900,t:1528143692182};\\\", \\\"{x:1352,y:900,t:1528143692903};\\\", \\\"{x:1351,y:900,t:1528143692935};\\\", \\\"{x:1349,y:900,t:1528143693071};\\\", \\\"{x:1348,y:900,t:1528143693086};\\\", \\\"{x:1345,y:900,t:1528143693095};\\\", \\\"{x:1338,y:900,t:1528143693113};\\\", \\\"{x:1328,y:900,t:1528143693129};\\\", \\\"{x:1314,y:898,t:1528143693146};\\\", \\\"{x:1301,y:896,t:1528143693161};\\\", \\\"{x:1287,y:894,t:1528143693179};\\\", \\\"{x:1277,y:894,t:1528143693194};\\\", \\\"{x:1264,y:893,t:1528143693211};\\\", \\\"{x:1256,y:891,t:1528143693229};\\\", \\\"{x:1246,y:890,t:1528143693244};\\\", \\\"{x:1234,y:889,t:1528143693262};\\\", \\\"{x:1226,y:889,t:1528143693278};\\\", \\\"{x:1217,y:889,t:1528143693294};\\\", \\\"{x:1209,y:889,t:1528143693312};\\\", \\\"{x:1200,y:889,t:1528143693329};\\\", \\\"{x:1192,y:889,t:1528143693345};\\\", \\\"{x:1189,y:889,t:1528143693362};\\\", \\\"{x:1187,y:889,t:1528143693379};\\\", \\\"{x:1187,y:890,t:1528143693395};\\\", \\\"{x:1186,y:890,t:1528143693412};\\\", \\\"{x:1185,y:890,t:1528143693446};\\\", \\\"{x:1183,y:890,t:1528143693687};\\\", \\\"{x:1176,y:890,t:1528143693696};\\\", \\\"{x:1153,y:887,t:1528143693712};\\\", \\\"{x:1116,y:881,t:1528143693729};\\\", \\\"{x:1064,y:868,t:1528143693746};\\\", \\\"{x:977,y:841,t:1528143693762};\\\", \\\"{x:876,y:804,t:1528143693779};\\\", \\\"{x:777,y:764,t:1528143693796};\\\", \\\"{x:688,y:720,t:1528143693812};\\\", \\\"{x:615,y:679,t:1528143693830};\\\", \\\"{x:532,y:640,t:1528143693848};\\\", \\\"{x:502,y:628,t:1528143693862};\\\", \\\"{x:486,y:621,t:1528143693879};\\\", \\\"{x:477,y:620,t:1528143693904};\\\", \\\"{x:476,y:621,t:1528143693981};\\\", \\\"{x:480,y:631,t:1528143693990};\\\", \\\"{x:485,y:640,t:1528143694004};\\\", \\\"{x:495,y:659,t:1528143694021};\\\", \\\"{x:501,y:671,t:1528143694037};\\\", \\\"{x:510,y:685,t:1528143694054};\\\", \\\"{x:512,y:695,t:1528143694070};\\\", \\\"{x:513,y:707,t:1528143694087};\\\", \\\"{x:514,y:714,t:1528143694103};\\\", \\\"{x:514,y:720,t:1528143694121};\\\", \\\"{x:514,y:723,t:1528143694138};\\\", \\\"{x:512,y:727,t:1528143694154};\\\", \\\"{x:508,y:732,t:1528143694170};\\\", \\\"{x:506,y:734,t:1528143694187};\\\", \\\"{x:505,y:736,t:1528143694203};\\\", \\\"{x:504,y:738,t:1528143694221};\\\", \\\"{x:512,y:738,t:1528143694725};\\\", \\\"{x:539,y:724,t:1528143694737};\\\", \\\"{x:637,y:669,t:1528143694755};\\\", \\\"{x:751,y:592,t:1528143694771};\\\", \\\"{x:848,y:505,t:1528143694788};\\\", \\\"{x:917,y:413,t:1528143694805};\\\", \\\"{x:940,y:353,t:1528143694821};\\\", \\\"{x:937,y:314,t:1528143694838};\\\", \\\"{x:925,y:298,t:1528143694854};\\\", \\\"{x:909,y:283,t:1528143694871};\\\", \\\"{x:896,y:276,t:1528143694888};\\\", \\\"{x:882,y:271,t:1528143694905};\\\", \\\"{x:872,y:269,t:1528143694921};\\\", \\\"{x:851,y:268,t:1528143694938};\\\", \\\"{x:818,y:268,t:1528143694955};\\\", \\\"{x:775,y:268,t:1528143694971};\\\", \\\"{x:721,y:288,t:1528143694988};\\\", \\\"{x:663,y:314,t:1528143695005};\\\", \\\"{x:578,y:366,t:1528143695022};\\\", \\\"{x:543,y:398,t:1528143695038};\\\", \\\"{x:536,y:413,t:1528143695055};\\\", \\\"{x:532,y:424,t:1528143695072};\\\", \\\"{x:532,y:431,t:1528143695088};\\\", \\\"{x:532,y:439,t:1528143695105};\\\", \\\"{x:534,y:446,t:1528143695122};\\\", \\\"{x:534,y:448,t:1528143695138};\\\", \\\"{x:535,y:449,t:1528143695155};\\\", \\\"{x:536,y:449,t:1528143695172};\\\", \\\"{x:537,y:450,t:1528143695188};\\\", \\\"{x:538,y:450,t:1528143695205};\\\", \\\"{x:539,y:451,t:1528143695222};\\\", \\\"{x:540,y:451,t:1528143695254};\\\", \\\"{x:549,y:445,t:1528143695625};\\\", \\\"{x:560,y:437,t:1528143695638};\\\", \\\"{x:568,y:431,t:1528143695655};\\\", \\\"{x:574,y:427,t:1528143695672};\\\", \\\"{x:578,y:424,t:1528143695689};\\\", \\\"{x:580,y:421,t:1528143695704};\\\", \\\"{x:581,y:421,t:1528143695721};\\\", \\\"{x:582,y:421,t:1528143695738};\\\", \\\"{x:583,y:419,t:1528143695766};\\\", \\\"{x:585,y:419,t:1528143695789};\\\", \\\"{x:587,y:418,t:1528143695806};\\\", \\\"{x:588,y:417,t:1528143695822};\\\", \\\"{x:590,y:416,t:1528143695839};\\\", \\\"{x:594,y:413,t:1528143695855};\\\", \\\"{x:595,y:411,t:1528143695872};\\\", \\\"{x:598,y:409,t:1528143695889};\\\", \\\"{x:600,y:408,t:1528143695905};\\\", \\\"{x:602,y:407,t:1528143695922};\\\" ] }, { \\\"rt\\\": 6382, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 10, \\\"time_elapsed\\\": 618043, \\\"internal_node_id\\\": \\\"0.0-6.0-0.0\\\", \\\"subject\\\": \\\"MKTF4\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"zulu\\\", \\\"condition\\\": \\\"211\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"duration\\\", \\\"q\\\": 6, \\\"clicks\\\": 2, \\\"explicit\\\": 2, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XInside-YFull\\\", \\\"correct\\\": 1, \\\"orth_correct\\\": 1, \\\"answer\\\": [ \\\"E\\\", \\\"G\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"\\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:604,y:404,t:1528143696121};\\\", \\\"{x:608,y:403,t:1528143696567};\\\", \\\"{x:632,y:396,t:1528143696574};\\\", \\\"{x:668,y:385,t:1528143696589};\\\", \\\"{x:724,y:378,t:1528143696606};\\\", \\\"{x:751,y:378,t:1528143696622};\\\", \\\"{x:784,y:378,t:1528143696639};\\\", \\\"{x:816,y:378,t:1528143696656};\\\", \\\"{x:837,y:378,t:1528143696673};\\\", \\\"{x:842,y:376,t:1528143696689};\\\", \\\"{x:844,y:376,t:1528143696706};\\\", \\\"{x:844,y:377,t:1528143697327};\\\", \\\"{x:843,y:379,t:1528143697340};\\\", \\\"{x:831,y:385,t:1528143697357};\\\", \\\"{x:808,y:395,t:1528143697373};\\\", \\\"{x:764,y:408,t:1528143697391};\\\", \\\"{x:741,y:413,t:1528143697406};\\\", \\\"{x:724,y:414,t:1528143697423};\\\", \\\"{x:703,y:419,t:1528143697440};\\\", \\\"{x:691,y:423,t:1528143697457};\\\", \\\"{x:687,y:424,t:1528143697474};\\\", \\\"{x:683,y:427,t:1528143697491};\\\", \\\"{x:681,y:427,t:1528143697519};\\\", \\\"{x:680,y:427,t:1528143697526};\\\", \\\"{x:676,y:428,t:1528143697540};\\\", \\\"{x:664,y:434,t:1528143697557};\\\", \\\"{x:656,y:438,t:1528143697574};\\\", \\\"{x:648,y:443,t:1528143697591};\\\", \\\"{x:648,y:444,t:1528143697607};\\\", \\\"{x:648,y:446,t:1528143697623};\\\", \\\"{x:648,y:452,t:1528143697640};\\\", \\\"{x:649,y:458,t:1528143697658};\\\", \\\"{x:657,y:469,t:1528143697673};\\\", \\\"{x:665,y:475,t:1528143697690};\\\", \\\"{x:671,y:477,t:1528143697707};\\\", \\\"{x:687,y:484,t:1528143697723};\\\", \\\"{x:781,y:495,t:1528143697742};\\\", \\\"{x:929,y:500,t:1528143697756};\\\", \\\"{x:979,y:499,t:1528143697774};\\\", \\\"{x:1016,y:491,t:1528143697790};\\\", \\\"{x:1025,y:488,t:1528143697806};\\\", \\\"{x:1026,y:488,t:1528143697853};\\\", \\\"{x:1027,y:488,t:1528143697862};\\\", \\\"{x:1028,y:488,t:1528143697874};\\\", \\\"{x:1030,y:488,t:1528143697934};\\\", \\\"{x:1031,y:488,t:1528143697942};\\\", \\\"{x:1032,y:489,t:1528143697957};\\\", \\\"{x:1032,y:496,t:1528143697974};\\\", \\\"{x:1031,y:500,t:1528143697990};\\\", \\\"{x:1030,y:504,t:1528143698007};\\\", \\\"{x:1028,y:511,t:1528143698024};\\\", \\\"{x:1026,y:518,t:1528143698041};\\\", \\\"{x:1024,y:525,t:1528143698057};\\\", \\\"{x:1021,y:535,t:1528143698074};\\\", \\\"{x:1016,y:547,t:1528143698090};\\\", \\\"{x:1011,y:561,t:1528143698106};\\\", \\\"{x:1006,y:572,t:1528143698124};\\\", \\\"{x:1003,y:581,t:1528143698140};\\\", \\\"{x:1002,y:594,t:1528143698157};\\\", \\\"{x:1002,y:618,t:1528143698173};\\\", \\\"{x:1005,y:631,t:1528143698191};\\\", \\\"{x:1011,y:642,t:1528143698207};\\\", \\\"{x:1021,y:651,t:1528143698224};\\\", \\\"{x:1041,y:659,t:1528143698241};\\\", \\\"{x:1073,y:665,t:1528143698257};\\\", \\\"{x:1106,y:665,t:1528143698274};\\\", \\\"{x:1120,y:662,t:1528143698291};\\\", \\\"{x:1128,y:658,t:1528143698307};\\\", \\\"{x:1132,y:655,t:1528143698324};\\\", \\\"{x:1137,y:647,t:1528143698342};\\\", \\\"{x:1143,y:635,t:1528143698357};\\\", \\\"{x:1148,y:616,t:1528143698374};\\\", \\\"{x:1151,y:602,t:1528143698391};\\\", \\\"{x:1151,y:589,t:1528143698407};\\\", \\\"{x:1151,y:581,t:1528143698424};\\\", \\\"{x:1150,y:574,t:1528143698442};\\\", \\\"{x:1144,y:569,t:1528143698457};\\\", \\\"{x:1136,y:565,t:1528143698474};\\\", \\\"{x:1133,y:563,t:1528143698491};\\\", \\\"{x:1129,y:561,t:1528143698508};\\\", \\\"{x:1127,y:561,t:1528143698524};\\\", \\\"{x:1126,y:560,t:1528143698542};\\\", \\\"{x:1124,y:560,t:1528143698582};\\\", \\\"{x:1126,y:560,t:1528143698695};\\\", \\\"{x:1131,y:560,t:1528143698709};\\\", \\\"{x:1140,y:562,t:1528143698724};\\\", \\\"{x:1150,y:562,t:1528143698741};\\\", \\\"{x:1170,y:565,t:1528143698758};\\\", \\\"{x:1186,y:567,t:1528143698774};\\\", \\\"{x:1208,y:569,t:1528143698792};\\\", \\\"{x:1253,y:576,t:1528143698808};\\\", \\\"{x:1289,y:580,t:1528143698824};\\\", \\\"{x:1311,y:581,t:1528143698842};\\\", \\\"{x:1326,y:581,t:1528143698858};\\\", \\\"{x:1333,y:581,t:1528143698875};\\\", \\\"{x:1335,y:581,t:1528143698891};\\\", \\\"{x:1336,y:581,t:1528143698909};\\\", \\\"{x:1338,y:581,t:1528143698925};\\\", \\\"{x:1345,y:580,t:1528143698941};\\\", \\\"{x:1374,y:575,t:1528143698959};\\\", \\\"{x:1393,y:575,t:1528143698975};\\\", \\\"{x:1411,y:575,t:1528143698991};\\\", \\\"{x:1420,y:575,t:1528143699009};\\\", \\\"{x:1422,y:575,t:1528143699026};\\\", \\\"{x:1423,y:575,t:1528143699046};\\\", \\\"{x:1416,y:578,t:1528143699111};\\\", \\\"{x:1409,y:580,t:1528143699125};\\\", \\\"{x:1373,y:583,t:1528143699142};\\\", \\\"{x:1248,y:583,t:1528143699158};\\\", \\\"{x:1113,y:583,t:1528143699175};\\\", \\\"{x:944,y:583,t:1528143699193};\\\", \\\"{x:773,y:583,t:1528143699208};\\\", \\\"{x:645,y:583,t:1528143699226};\\\", \\\"{x:576,y:583,t:1528143699241};\\\", \\\"{x:551,y:584,t:1528143699258};\\\", \\\"{x:546,y:585,t:1528143699275};\\\", \\\"{x:543,y:586,t:1528143699934};\\\", \\\"{x:540,y:587,t:1528143699942};\\\", \\\"{x:530,y:587,t:1528143699958};\\\", \\\"{x:516,y:587,t:1528143699975};\\\", \\\"{x:502,y:587,t:1528143699992};\\\", \\\"{x:484,y:584,t:1528143700012};\\\", \\\"{x:472,y:583,t:1528143700025};\\\", \\\"{x:466,y:583,t:1528143700042};\\\", \\\"{x:463,y:580,t:1528143700059};\\\", \\\"{x:462,y:580,t:1528143700074};\\\", \\\"{x:459,y:579,t:1528143700092};\\\", \\\"{x:455,y:577,t:1528143700108};\\\", \\\"{x:441,y:574,t:1528143700125};\\\", \\\"{x:420,y:570,t:1528143700142};\\\", \\\"{x:406,y:568,t:1528143700160};\\\", \\\"{x:401,y:567,t:1528143700175};\\\", \\\"{x:398,y:567,t:1528143700192};\\\", \\\"{x:396,y:566,t:1528143700214};\\\", \\\"{x:394,y:565,t:1528143700226};\\\", \\\"{x:388,y:561,t:1528143700242};\\\", \\\"{x:384,y:559,t:1528143700259};\\\", \\\"{x:381,y:557,t:1528143700276};\\\", \\\"{x:379,y:556,t:1528143700292};\\\", \\\"{x:377,y:555,t:1528143700310};\\\", \\\"{x:372,y:551,t:1528143700326};\\\", \\\"{x:369,y:549,t:1528143700341};\\\", \\\"{x:366,y:548,t:1528143700360};\\\", \\\"{x:361,y:546,t:1528143700375};\\\", \\\"{x:354,y:546,t:1528143700392};\\\", \\\"{x:348,y:545,t:1528143700409};\\\", \\\"{x:347,y:545,t:1528143700425};\\\", \\\"{x:348,y:543,t:1528143700462};\\\", \\\"{x:354,y:541,t:1528143700475};\\\", \\\"{x:371,y:532,t:1528143700492};\\\", \\\"{x:411,y:525,t:1528143700509};\\\", \\\"{x:447,y:516,t:1528143700526};\\\", \\\"{x:476,y:511,t:1528143700541};\\\", \\\"{x:479,y:511,t:1528143700559};\\\", \\\"{x:480,y:511,t:1528143700576};\\\", \\\"{x:482,y:511,t:1528143700621};\\\", \\\"{x:483,y:511,t:1528143700630};\\\", \\\"{x:484,y:511,t:1528143700643};\\\", \\\"{x:485,y:511,t:1528143700659};\\\", \\\"{x:489,y:512,t:1528143700676};\\\", \\\"{x:495,y:513,t:1528143700693};\\\", \\\"{x:512,y:515,t:1528143700711};\\\", \\\"{x:554,y:515,t:1528143700726};\\\", \\\"{x:584,y:515,t:1528143700743};\\\", \\\"{x:608,y:511,t:1528143700760};\\\", \\\"{x:609,y:510,t:1528143700776};\\\", \\\"{x:607,y:510,t:1528143700935};\\\", \\\"{x:609,y:509,t:1528143701134};\\\", \\\"{x:611,y:509,t:1528143701150};\\\", \\\"{x:612,y:509,t:1528143701160};\\\", \\\"{x:614,y:507,t:1528143701176};\\\", \\\"{x:615,y:507,t:1528143701193};\\\", \\\"{x:617,y:507,t:1528143701210};\\\", \\\"{x:624,y:507,t:1528143701226};\\\", \\\"{x:645,y:512,t:1528143701244};\\\", \\\"{x:675,y:519,t:1528143701261};\\\", \\\"{x:693,y:521,t:1528143701276};\\\", \\\"{x:713,y:524,t:1528143701293};\\\", \\\"{x:747,y:530,t:1528143701312};\\\", \\\"{x:760,y:531,t:1528143701325};\\\", \\\"{x:763,y:531,t:1528143701343};\\\", \\\"{x:764,y:531,t:1528143701360};\\\", \\\"{x:766,y:531,t:1528143701376};\\\", \\\"{x:767,y:531,t:1528143701393};\\\", \\\"{x:769,y:531,t:1528143701409};\\\", \\\"{x:770,y:531,t:1528143701426};\\\", \\\"{x:771,y:531,t:1528143701443};\\\", \\\"{x:772,y:531,t:1528143701460};\\\", \\\"{x:773,y:531,t:1528143701477};\\\", \\\"{x:775,y:531,t:1528143701494};\\\", \\\"{x:785,y:531,t:1528143701510};\\\", \\\"{x:792,y:531,t:1528143701528};\\\", \\\"{x:797,y:531,t:1528143701543};\\\", \\\"{x:801,y:531,t:1528143701561};\\\", \\\"{x:804,y:531,t:1528143701578};\\\", \\\"{x:812,y:534,t:1528143701594};\\\", \\\"{x:821,y:536,t:1528143701610};\\\", \\\"{x:828,y:538,t:1528143701628};\\\", \\\"{x:833,y:539,t:1528143701643};\\\", \\\"{x:835,y:539,t:1528143701660};\\\", \\\"{x:836,y:539,t:1528143701677};\\\", \\\"{x:834,y:540,t:1528143701845};\\\", \\\"{x:832,y:540,t:1528143701860};\\\", \\\"{x:828,y:542,t:1528143701877};\\\", \\\"{x:801,y:554,t:1528143701894};\\\", \\\"{x:760,y:575,t:1528143701911};\\\", \\\"{x:698,y:611,t:1528143701928};\\\", \\\"{x:621,y:653,t:1528143701943};\\\", \\\"{x:563,y:680,t:1528143701960};\\\", \\\"{x:544,y:689,t:1528143701977};\\\", \\\"{x:539,y:692,t:1528143701994};\\\", \\\"{x:536,y:694,t:1528143702010};\\\", \\\"{x:535,y:694,t:1528143702029};\\\", \\\"{x:535,y:695,t:1528143702045};\\\", \\\"{x:530,y:697,t:1528143702060};\\\", \\\"{x:524,y:701,t:1528143702077};\\\", \\\"{x:515,y:706,t:1528143702094};\\\", \\\"{x:513,y:708,t:1528143702110};\\\", \\\"{x:512,y:708,t:1528143702214};\\\", \\\"{x:512,y:709,t:1528143702237};\\\", \\\"{x:512,y:711,t:1528143702246};\\\", \\\"{x:512,y:714,t:1528143702260};\\\", \\\"{x:512,y:723,t:1528143702277};\\\", \\\"{x:509,y:742,t:1528143702293};\\\", \\\"{x:505,y:751,t:1528143702310};\\\", \\\"{x:504,y:753,t:1528143702327};\\\", \\\"{x:504,y:752,t:1528143702574};\\\", \\\"{x:504,y:751,t:1528143702581};\\\", \\\"{x:504,y:749,t:1528143702594};\\\", \\\"{x:504,y:748,t:1528143702611};\\\", \\\"{x:505,y:747,t:1528143702743};\\\", \\\"{x:508,y:747,t:1528143702750};\\\", \\\"{x:513,y:744,t:1528143702762};\\\", \\\"{x:537,y:729,t:1528143702777};\\\", \\\"{x:582,y:700,t:1528143702794};\\\", \\\"{x:649,y:654,t:1528143702811};\\\", \\\"{x:723,y:606,t:1528143702827};\\\", \\\"{x:778,y:562,t:1528143702844};\\\", \\\"{x:814,y:529,t:1528143702862};\\\", \\\"{x:831,y:511,t:1528143702877};\\\", \\\"{x:842,y:499,t:1528143702894};\\\", \\\"{x:849,y:492,t:1528143702911};\\\", \\\"{x:854,y:488,t:1528143702927};\\\", \\\"{x:860,y:483,t:1528143702944};\\\", \\\"{x:869,y:477,t:1528143702961};\\\", \\\"{x:878,y:472,t:1528143702977};\\\", \\\"{x:886,y:468,t:1528143702994};\\\", \\\"{x:888,y:466,t:1528143703011};\\\", \\\"{x:890,y:466,t:1528143703027};\\\", \\\"{x:890,y:465,t:1528143703044};\\\", \\\"{x:891,y:465,t:1528143703078};\\\", \\\"{x:893,y:463,t:1528143703094};\\\", \\\"{x:894,y:462,t:1528143703118};\\\", \\\"{x:894,y:461,t:1528143703151};\\\", \\\"{x:895,y:461,t:1528143703278};\\\", \\\"{x:896,y:461,t:1528143703367};\\\" ] }, { \\\"rt\\\": 45173, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 11, \\\"time_elapsed\\\": 664429, \\\"internal_node_id\\\": \\\"0.0-6.0-1.0\\\", \\\"subject\\\": \\\"MKTF4\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"zulu\\\", \\\"condition\\\": \\\"211\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"duration+starts\\\", \\\"q\\\": 7, \\\"clicks\\\": 6.5, \\\"explicit\\\": 2, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XInside-YFull\\\", \\\"correct\\\": 1, \\\"orth_correct\\\": 0, \\\"answer\\\": [ \\\"X\\\", \\\"O\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-3-F -M -F -C -C -X -M \\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:876,y:461,t:1528143704168};\\\", \\\"{x:867,y:461,t:1528143704179};\\\", \\\"{x:854,y:461,t:1528143704196};\\\", \\\"{x:838,y:461,t:1528143704212};\\\", \\\"{x:820,y:461,t:1528143704229};\\\", \\\"{x:794,y:461,t:1528143704245};\\\", \\\"{x:743,y:461,t:1528143704261};\\\", \\\"{x:693,y:461,t:1528143704279};\\\", \\\"{x:654,y:461,t:1528143704295};\\\", \\\"{x:622,y:461,t:1528143704312};\\\", \\\"{x:602,y:461,t:1528143704330};\\\", \\\"{x:593,y:461,t:1528143704345};\\\", \\\"{x:592,y:461,t:1528143704382};\\\", \\\"{x:591,y:461,t:1528143704406};\\\", \\\"{x:590,y:461,t:1528143704414};\\\", \\\"{x:588,y:461,t:1528143704430};\\\", \\\"{x:582,y:461,t:1528143704445};\\\", \\\"{x:574,y:465,t:1528143704462};\\\", \\\"{x:571,y:466,t:1528143704480};\\\", \\\"{x:568,y:468,t:1528143704495};\\\", \\\"{x:565,y:468,t:1528143704513};\\\", \\\"{x:564,y:469,t:1528143705022};\\\", \\\"{x:563,y:469,t:1528143705038};\\\", \\\"{x:562,y:470,t:1528143705047};\\\", \\\"{x:561,y:470,t:1528143705079};\\\", \\\"{x:560,y:470,t:1528143705094};\\\", \\\"{x:559,y:471,t:1528143705110};\\\", \\\"{x:558,y:471,t:1528143706055};\\\", \\\"{x:557,y:471,t:1528143706064};\\\", \\\"{x:555,y:472,t:1528143706081};\\\", \\\"{x:552,y:473,t:1528143706097};\\\", \\\"{x:551,y:473,t:1528143706113};\\\", \\\"{x:549,y:474,t:1528143706132};\\\", \\\"{x:543,y:474,t:1528143706148};\\\", \\\"{x:536,y:475,t:1528143706164};\\\", \\\"{x:529,y:475,t:1528143706181};\\\", \\\"{x:518,y:475,t:1528143706198};\\\", \\\"{x:505,y:475,t:1528143706214};\\\", \\\"{x:481,y:475,t:1528143706231};\\\", \\\"{x:460,y:475,t:1528143706248};\\\", \\\"{x:434,y:476,t:1528143706263};\\\", \\\"{x:410,y:476,t:1528143706281};\\\", \\\"{x:394,y:476,t:1528143706297};\\\", \\\"{x:381,y:478,t:1528143706314};\\\", \\\"{x:377,y:478,t:1528143706332};\\\", \\\"{x:376,y:478,t:1528143706415};\\\", \\\"{x:378,y:476,t:1528143707359};\\\", \\\"{x:381,y:472,t:1528143707366};\\\", \\\"{x:385,y:470,t:1528143707382};\\\", \\\"{x:399,y:464,t:1528143707399};\\\", \\\"{x:405,y:463,t:1528143707415};\\\", \\\"{x:408,y:461,t:1528143707432};\\\", \\\"{x:412,y:460,t:1528143707449};\\\", \\\"{x:413,y:460,t:1528143707464};\\\", \\\"{x:417,y:460,t:1528143707482};\\\", \\\"{x:423,y:458,t:1528143707499};\\\", \\\"{x:426,y:458,t:1528143707515};\\\", \\\"{x:430,y:457,t:1528143707533};\\\", \\\"{x:433,y:457,t:1528143707549};\\\", \\\"{x:435,y:457,t:1528143707565};\\\", \\\"{x:436,y:457,t:1528143707598};\\\", \\\"{x:438,y:457,t:1528143707934};\\\", \\\"{x:440,y:457,t:1528143707950};\\\", \\\"{x:442,y:458,t:1528143707965};\\\", \\\"{x:449,y:459,t:1528143707982};\\\", \\\"{x:458,y:463,t:1528143707999};\\\", \\\"{x:459,y:463,t:1528143708016};\\\", \\\"{x:460,y:463,t:1528143708047};\\\", \\\"{x:461,y:463,t:1528143708062};\\\", \\\"{x:462,y:463,t:1528143708111};\\\", \\\"{x:462,y:464,t:1528143708118};\\\", \\\"{x:463,y:464,t:1528143708246};\\\", \\\"{x:464,y:465,t:1528143708343};\\\", \\\"{x:465,y:466,t:1528143708359};\\\", \\\"{x:467,y:466,t:1528143708366};\\\", \\\"{x:470,y:469,t:1528143708382};\\\", \\\"{x:473,y:470,t:1528143708399};\\\", \\\"{x:478,y:472,t:1528143708416};\\\", \\\"{x:479,y:472,t:1528143708432};\\\", \\\"{x:482,y:473,t:1528143708449};\\\", \\\"{x:487,y:475,t:1528143708466};\\\", \\\"{x:493,y:477,t:1528143708483};\\\", \\\"{x:499,y:478,t:1528143708498};\\\", \\\"{x:501,y:478,t:1528143708516};\\\", \\\"{x:503,y:478,t:1528143708533};\\\", \\\"{x:505,y:479,t:1528143708549};\\\", \\\"{x:506,y:479,t:1528143708591};\\\", \\\"{x:507,y:479,t:1528143708614};\\\", \\\"{x:508,y:479,t:1528143708646};\\\", \\\"{x:510,y:479,t:1528143708671};\\\", \\\"{x:511,y:479,t:1528143708683};\\\", \\\"{x:513,y:479,t:1528143708700};\\\", \\\"{x:514,y:479,t:1528143708718};\\\", \\\"{x:516,y:479,t:1528143708743};\\\", \\\"{x:516,y:478,t:1528143708750};\\\", \\\"{x:517,y:478,t:1528143708766};\\\", \\\"{x:522,y:476,t:1528143708784};\\\", \\\"{x:524,y:475,t:1528143708800};\\\", \\\"{x:530,y:474,t:1528143708816};\\\", \\\"{x:534,y:472,t:1528143708833};\\\", \\\"{x:538,y:471,t:1528143708850};\\\", \\\"{x:542,y:471,t:1528143708866};\\\", \\\"{x:546,y:468,t:1528143708883};\\\", \\\"{x:552,y:466,t:1528143708900};\\\", \\\"{x:558,y:463,t:1528143708916};\\\", \\\"{x:570,y:458,t:1528143708933};\\\", \\\"{x:578,y:454,t:1528143708949};\\\", \\\"{x:589,y:450,t:1528143708966};\\\", \\\"{x:594,y:447,t:1528143708982};\\\", \\\"{x:598,y:445,t:1528143709000};\\\", \\\"{x:601,y:443,t:1528143709017};\\\", \\\"{x:604,y:442,t:1528143709033};\\\", \\\"{x:607,y:440,t:1528143709050};\\\", \\\"{x:609,y:439,t:1528143709067};\\\", \\\"{x:613,y:437,t:1528143709083};\\\", \\\"{x:614,y:436,t:1528143709100};\\\", \\\"{x:615,y:436,t:1528143709117};\\\", \\\"{x:617,y:435,t:1528143709133};\\\", \\\"{x:618,y:434,t:1528143709149};\\\", \\\"{x:619,y:433,t:1528143709166};\\\", \\\"{x:620,y:433,t:1528143709214};\\\", \\\"{x:619,y:434,t:1528143709823};\\\", \\\"{x:617,y:437,t:1528143709834};\\\", \\\"{x:613,y:443,t:1528143709850};\\\", \\\"{x:609,y:452,t:1528143709866};\\\", \\\"{x:609,y:467,t:1528143709884};\\\", \\\"{x:614,y:486,t:1528143709902};\\\", \\\"{x:622,y:499,t:1528143709919};\\\", \\\"{x:642,y:526,t:1528143709934};\\\", \\\"{x:667,y:551,t:1528143709950};\\\", \\\"{x:699,y:575,t:1528143709966};\\\", \\\"{x:731,y:598,t:1528143709982};\\\", \\\"{x:767,y:622,t:1528143709999};\\\", \\\"{x:802,y:643,t:1528143710017};\\\", \\\"{x:829,y:660,t:1528143710033};\\\", \\\"{x:849,y:675,t:1528143710051};\\\", \\\"{x:870,y:690,t:1528143710067};\\\", \\\"{x:883,y:699,t:1528143710083};\\\", \\\"{x:888,y:702,t:1528143710100};\\\", \\\"{x:891,y:705,t:1528143710117};\\\", \\\"{x:892,y:706,t:1528143710133};\\\", \\\"{x:894,y:706,t:1528143710550};\\\", \\\"{x:898,y:709,t:1528143710557};\\\", \\\"{x:908,y:716,t:1528143710569};\\\", \\\"{x:927,y:728,t:1528143710585};\\\", \\\"{x:955,y:743,t:1528143710603};\\\", \\\"{x:981,y:757,t:1528143710619};\\\", \\\"{x:1003,y:770,t:1528143710636};\\\", \\\"{x:1020,y:777,t:1528143710653};\\\", \\\"{x:1038,y:783,t:1528143710671};\\\", \\\"{x:1039,y:785,t:1528143710686};\\\", \\\"{x:1040,y:785,t:1528143710798};\\\", \\\"{x:1043,y:785,t:1528143710807};\\\", \\\"{x:1043,y:783,t:1528143711263};\\\", \\\"{x:1043,y:782,t:1528143711272};\\\", \\\"{x:1045,y:779,t:1528143711288};\\\", \\\"{x:1046,y:777,t:1528143711306};\\\", \\\"{x:1046,y:775,t:1528143711322};\\\", \\\"{x:1049,y:772,t:1528143711339};\\\", \\\"{x:1049,y:770,t:1528143711355};\\\", \\\"{x:1049,y:769,t:1528143711372};\\\", \\\"{x:1050,y:769,t:1528143711391};\\\", \\\"{x:1055,y:769,t:1528143711598};\\\", \\\"{x:1062,y:769,t:1528143711606};\\\", \\\"{x:1077,y:769,t:1528143711623};\\\", \\\"{x:1097,y:769,t:1528143711640};\\\", \\\"{x:1118,y:769,t:1528143711656};\\\", \\\"{x:1131,y:769,t:1528143711673};\\\", \\\"{x:1137,y:769,t:1528143711690};\\\", \\\"{x:1140,y:769,t:1528143711707};\\\", \\\"{x:1141,y:769,t:1528143711724};\\\", \\\"{x:1143,y:768,t:1528143711742};\\\", \\\"{x:1143,y:767,t:1528143711983};\\\", \\\"{x:1143,y:766,t:1528143711991};\\\", \\\"{x:1144,y:763,t:1528143712009};\\\", \\\"{x:1145,y:761,t:1528143712024};\\\", \\\"{x:1148,y:759,t:1528143712041};\\\", \\\"{x:1150,y:757,t:1528143712058};\\\", \\\"{x:1152,y:755,t:1528143712075};\\\", \\\"{x:1153,y:755,t:1528143712091};\\\", \\\"{x:1157,y:752,t:1528143712108};\\\", \\\"{x:1163,y:747,t:1528143712125};\\\", \\\"{x:1170,y:742,t:1528143712141};\\\", \\\"{x:1186,y:735,t:1528143712159};\\\", \\\"{x:1206,y:730,t:1528143712175};\\\", \\\"{x:1228,y:725,t:1528143712192};\\\", \\\"{x:1249,y:723,t:1528143712208};\\\", \\\"{x:1264,y:721,t:1528143712225};\\\", \\\"{x:1274,y:719,t:1528143712243};\\\", \\\"{x:1279,y:717,t:1528143712259};\\\", \\\"{x:1282,y:716,t:1528143712275};\\\", \\\"{x:1284,y:715,t:1528143712291};\\\", \\\"{x:1296,y:712,t:1528143712328};\\\", \\\"{x:1304,y:710,t:1528143712341};\\\", \\\"{x:1317,y:707,t:1528143712359};\\\", \\\"{x:1332,y:706,t:1528143712375};\\\", \\\"{x:1351,y:705,t:1528143712392};\\\", \\\"{x:1369,y:705,t:1528143712408};\\\", \\\"{x:1386,y:705,t:1528143712425};\\\", \\\"{x:1398,y:704,t:1528143712441};\\\", \\\"{x:1412,y:702,t:1528143712458};\\\", \\\"{x:1422,y:701,t:1528143712476};\\\", \\\"{x:1430,y:700,t:1528143712493};\\\", \\\"{x:1432,y:700,t:1528143712509};\\\", \\\"{x:1433,y:700,t:1528143712526};\\\", \\\"{x:1430,y:700,t:1528143712711};\\\", \\\"{x:1412,y:700,t:1528143712727};\\\", \\\"{x:1380,y:700,t:1528143712744};\\\", \\\"{x:1336,y:703,t:1528143712760};\\\", \\\"{x:1280,y:703,t:1528143712777};\\\", \\\"{x:1210,y:706,t:1528143712794};\\\", \\\"{x:1143,y:706,t:1528143712810};\\\", \\\"{x:1076,y:706,t:1528143712827};\\\", \\\"{x:1020,y:706,t:1528143712845};\\\", \\\"{x:978,y:706,t:1528143712861};\\\", \\\"{x:955,y:706,t:1528143712877};\\\", \\\"{x:942,y:706,t:1528143712894};\\\", \\\"{x:940,y:706,t:1528143712911};\\\", \\\"{x:939,y:706,t:1528143712962};\\\", \\\"{x:936,y:706,t:1528143712977};\\\", \\\"{x:935,y:706,t:1528143712993};\\\", \\\"{x:932,y:706,t:1528143713010};\\\", \\\"{x:930,y:706,t:1528143713030};\\\", \\\"{x:929,y:706,t:1528143713045};\\\", \\\"{x:927,y:706,t:1528143713070};\\\", \\\"{x:926,y:706,t:1528143713109};\\\", \\\"{x:924,y:706,t:1528143713166};\\\", \\\"{x:927,y:706,t:1528143714622};\\\", \\\"{x:932,y:704,t:1528143714633};\\\", \\\"{x:952,y:703,t:1528143714650};\\\", \\\"{x:1017,y:703,t:1528143714668};\\\", \\\"{x:1092,y:703,t:1528143714684};\\\", \\\"{x:1170,y:703,t:1528143714701};\\\", \\\"{x:1234,y:703,t:1528143714718};\\\", \\\"{x:1293,y:703,t:1528143714735};\\\", \\\"{x:1324,y:703,t:1528143714751};\\\", \\\"{x:1344,y:703,t:1528143714767};\\\", \\\"{x:1354,y:703,t:1528143714784};\\\", \\\"{x:1358,y:701,t:1528143714801};\\\", \\\"{x:1360,y:700,t:1528143714817};\\\", \\\"{x:1358,y:700,t:1528143715079};\\\", \\\"{x:1354,y:699,t:1528143715086};\\\", \\\"{x:1347,y:699,t:1528143715105};\\\", \\\"{x:1342,y:699,t:1528143715119};\\\", \\\"{x:1339,y:699,t:1528143715134};\\\", \\\"{x:1338,y:698,t:1528143715152};\\\", \\\"{x:1336,y:698,t:1528143715358};\\\", \\\"{x:1333,y:698,t:1528143715369};\\\", \\\"{x:1316,y:698,t:1528143715386};\\\", \\\"{x:1277,y:698,t:1528143715403};\\\", \\\"{x:1222,y:694,t:1528143715420};\\\", \\\"{x:1149,y:683,t:1528143715436};\\\", \\\"{x:1082,y:673,t:1528143715454};\\\", \\\"{x:1026,y:656,t:1528143715471};\\\", \\\"{x:1011,y:649,t:1528143715487};\\\", \\\"{x:1005,y:645,t:1528143715503};\\\", \\\"{x:1000,y:641,t:1528143715520};\\\", \\\"{x:992,y:633,t:1528143715538};\\\", \\\"{x:979,y:625,t:1528143715553};\\\", \\\"{x:970,y:617,t:1528143715569};\\\", \\\"{x:959,y:611,t:1528143715587};\\\", \\\"{x:948,y:606,t:1528143715604};\\\", \\\"{x:935,y:602,t:1528143715619};\\\", \\\"{x:922,y:598,t:1528143715637};\\\", \\\"{x:906,y:595,t:1528143715655};\\\", \\\"{x:889,y:592,t:1528143715672};\\\", \\\"{x:871,y:589,t:1528143715687};\\\", \\\"{x:851,y:586,t:1528143715705};\\\", \\\"{x:832,y:583,t:1528143715721};\\\", \\\"{x:814,y:581,t:1528143715738};\\\", \\\"{x:798,y:576,t:1528143715755};\\\", \\\"{x:788,y:576,t:1528143715771};\\\", \\\"{x:783,y:573,t:1528143715788};\\\", \\\"{x:780,y:572,t:1528143715805};\\\", \\\"{x:776,y:572,t:1528143715821};\\\", \\\"{x:774,y:572,t:1528143715838};\\\", \\\"{x:771,y:571,t:1528143715854};\\\", \\\"{x:769,y:571,t:1528143715872};\\\", \\\"{x:768,y:571,t:1528143715889};\\\", \\\"{x:766,y:571,t:1528143715905};\\\", \\\"{x:765,y:570,t:1528143715941};\\\", \\\"{x:763,y:570,t:1528143716022};\\\", \\\"{x:762,y:570,t:1528143716086};\\\", \\\"{x:761,y:570,t:1528143716118};\\\", \\\"{x:760,y:570,t:1528143716127};\\\", \\\"{x:759,y:570,t:1528143716166};\\\", \\\"{x:757,y:570,t:1528143716190};\\\", \\\"{x:756,y:570,t:1528143716223};\\\", \\\"{x:754,y:570,t:1528143716303};\\\", \\\"{x:753,y:570,t:1528143716759};\\\", \\\"{x:751,y:570,t:1528143716775};\\\", \\\"{x:750,y:570,t:1528143716789};\\\", \\\"{x:747,y:570,t:1528143716806};\\\", \\\"{x:744,y:570,t:1528143716822};\\\", \\\"{x:742,y:570,t:1528143716839};\\\", \\\"{x:737,y:570,t:1528143716856};\\\", \\\"{x:730,y:569,t:1528143716873};\\\", \\\"{x:715,y:568,t:1528143716890};\\\", \\\"{x:698,y:565,t:1528143716906};\\\", \\\"{x:676,y:562,t:1528143716924};\\\", \\\"{x:654,y:559,t:1528143716939};\\\", \\\"{x:637,y:557,t:1528143716956};\\\", \\\"{x:620,y:554,t:1528143716973};\\\", \\\"{x:609,y:553,t:1528143716988};\\\", \\\"{x:600,y:552,t:1528143717005};\\\", \\\"{x:592,y:552,t:1528143717023};\\\", \\\"{x:584,y:552,t:1528143717038};\\\", \\\"{x:576,y:552,t:1528143717056};\\\", \\\"{x:570,y:552,t:1528143717073};\\\", \\\"{x:566,y:552,t:1528143717090};\\\", \\\"{x:560,y:552,t:1528143717106};\\\", \\\"{x:552,y:552,t:1528143717122};\\\", \\\"{x:542,y:553,t:1528143717140};\\\", \\\"{x:529,y:555,t:1528143717156};\\\", \\\"{x:520,y:558,t:1528143717174};\\\", \\\"{x:507,y:562,t:1528143717189};\\\", \\\"{x:497,y:564,t:1528143717205};\\\", \\\"{x:485,y:568,t:1528143717223};\\\", \\\"{x:471,y:572,t:1528143717238};\\\", \\\"{x:457,y:575,t:1528143717255};\\\", \\\"{x:445,y:577,t:1528143717272};\\\", \\\"{x:436,y:578,t:1528143717290};\\\", \\\"{x:430,y:579,t:1528143717305};\\\", \\\"{x:427,y:579,t:1528143717322};\\\", \\\"{x:422,y:579,t:1528143717339};\\\", \\\"{x:415,y:579,t:1528143717356};\\\", \\\"{x:403,y:579,t:1528143717373};\\\", \\\"{x:378,y:579,t:1528143717390};\\\", \\\"{x:359,y:579,t:1528143717405};\\\", \\\"{x:341,y:579,t:1528143717423};\\\", \\\"{x:323,y:580,t:1528143717439};\\\", \\\"{x:306,y:583,t:1528143717456};\\\", \\\"{x:292,y:587,t:1528143717472};\\\", \\\"{x:280,y:590,t:1528143717490};\\\", \\\"{x:271,y:593,t:1528143717506};\\\", \\\"{x:262,y:596,t:1528143717523};\\\", \\\"{x:253,y:598,t:1528143717540};\\\", \\\"{x:249,y:599,t:1528143717556};\\\", \\\"{x:243,y:601,t:1528143717574};\\\", \\\"{x:235,y:603,t:1528143717590};\\\", \\\"{x:224,y:607,t:1528143717607};\\\", \\\"{x:214,y:608,t:1528143717623};\\\", \\\"{x:201,y:611,t:1528143717639};\\\", \\\"{x:193,y:612,t:1528143717657};\\\", \\\"{x:188,y:612,t:1528143717673};\\\", \\\"{x:186,y:612,t:1528143717689};\\\", \\\"{x:182,y:615,t:1528143717706};\\\", \\\"{x:179,y:615,t:1528143717723};\\\", \\\"{x:175,y:616,t:1528143717739};\\\", \\\"{x:181,y:616,t:1528143717806};\\\", \\\"{x:207,y:608,t:1528143717824};\\\", \\\"{x:244,y:601,t:1528143717839};\\\", \\\"{x:290,y:594,t:1528143717857};\\\", \\\"{x:314,y:590,t:1528143717873};\\\", \\\"{x:335,y:584,t:1528143717889};\\\", \\\"{x:346,y:580,t:1528143717907};\\\", \\\"{x:355,y:576,t:1528143717923};\\\", \\\"{x:374,y:570,t:1528143717940};\\\", \\\"{x:406,y:560,t:1528143717957};\\\", \\\"{x:452,y:552,t:1528143717973};\\\", \\\"{x:536,y:541,t:1528143717990};\\\", \\\"{x:570,y:536,t:1528143718007};\\\", \\\"{x:590,y:533,t:1528143718023};\\\", \\\"{x:600,y:531,t:1528143718040};\\\", \\\"{x:603,y:531,t:1528143718056};\\\", \\\"{x:608,y:530,t:1528143718073};\\\", \\\"{x:615,y:530,t:1528143718090};\\\", \\\"{x:623,y:530,t:1528143718107};\\\", \\\"{x:632,y:530,t:1528143718124};\\\", \\\"{x:640,y:530,t:1528143718140};\\\", \\\"{x:648,y:530,t:1528143718158};\\\", \\\"{x:659,y:530,t:1528143718174};\\\", \\\"{x:671,y:528,t:1528143718189};\\\", \\\"{x:688,y:528,t:1528143718207};\\\", \\\"{x:708,y:527,t:1528143718224};\\\", \\\"{x:726,y:525,t:1528143718241};\\\", \\\"{x:744,y:521,t:1528143718258};\\\", \\\"{x:756,y:517,t:1528143718274};\\\", \\\"{x:761,y:516,t:1528143718290};\\\", \\\"{x:764,y:515,t:1528143718306};\\\", \\\"{x:771,y:512,t:1528143718324};\\\", \\\"{x:777,y:510,t:1528143718340};\\\", \\\"{x:781,y:509,t:1528143718357};\\\", \\\"{x:785,y:508,t:1528143718374};\\\", \\\"{x:786,y:507,t:1528143718390};\\\", \\\"{x:790,y:505,t:1528143718565};\\\", \\\"{x:794,y:504,t:1528143718573};\\\", \\\"{x:800,y:503,t:1528143718591};\\\", \\\"{x:807,y:502,t:1528143718607};\\\", \\\"{x:811,y:501,t:1528143718624};\\\", \\\"{x:813,y:500,t:1528143718641};\\\", \\\"{x:814,y:501,t:1528143718862};\\\", \\\"{x:814,y:504,t:1528143718874};\\\", \\\"{x:815,y:512,t:1528143718891};\\\", \\\"{x:815,y:525,t:1528143718907};\\\", \\\"{x:815,y:540,t:1528143718924};\\\", \\\"{x:815,y:551,t:1528143718941};\\\", \\\"{x:815,y:555,t:1528143718958};\\\", \\\"{x:815,y:558,t:1528143718975};\\\", \\\"{x:815,y:559,t:1528143718991};\\\", \\\"{x:815,y:561,t:1528143719008};\\\", \\\"{x:815,y:564,t:1528143719025};\\\", \\\"{x:815,y:570,t:1528143719041};\\\", \\\"{x:815,y:573,t:1528143719057};\\\", \\\"{x:816,y:576,t:1528143719074};\\\", \\\"{x:817,y:577,t:1528143719091};\\\", \\\"{x:818,y:578,t:1528143719107};\\\", \\\"{x:820,y:582,t:1528143719123};\\\", \\\"{x:821,y:586,t:1528143719141};\\\", \\\"{x:826,y:591,t:1528143719156};\\\", \\\"{x:832,y:600,t:1528143719175};\\\", \\\"{x:834,y:604,t:1528143719191};\\\", \\\"{x:839,y:613,t:1528143719208};\\\", \\\"{x:842,y:615,t:1528143719223};\\\", \\\"{x:844,y:617,t:1528143719241};\\\", \\\"{x:845,y:615,t:1528143719327};\\\", \\\"{x:846,y:609,t:1528143719341};\\\", \\\"{x:846,y:600,t:1528143719359};\\\", \\\"{x:846,y:599,t:1528143719375};\\\", \\\"{x:845,y:599,t:1528143719478};\\\", \\\"{x:844,y:600,t:1528143719493};\\\", \\\"{x:844,y:601,t:1528143719508};\\\", \\\"{x:843,y:601,t:1528143719524};\\\", \\\"{x:843,y:602,t:1528143719541};\\\", \\\"{x:842,y:604,t:1528143719623};\\\", \\\"{x:842,y:605,t:1528143719640};\\\", \\\"{x:842,y:606,t:1528143719657};\\\", \\\"{x:841,y:607,t:1528143719685};\\\", \\\"{x:837,y:601,t:1528143719917};\\\", \\\"{x:836,y:590,t:1528143719925};\\\", \\\"{x:834,y:582,t:1528143719941};\\\", \\\"{x:832,y:570,t:1528143719958};\\\", \\\"{x:831,y:561,t:1528143719975};\\\", \\\"{x:829,y:550,t:1528143719992};\\\", \\\"{x:829,y:541,t:1528143720007};\\\", \\\"{x:829,y:532,t:1528143720025};\\\", \\\"{x:829,y:523,t:1528143720041};\\\", \\\"{x:828,y:520,t:1528143720057};\\\", \\\"{x:827,y:516,t:1528143720075};\\\", \\\"{x:827,y:515,t:1528143720092};\\\", \\\"{x:827,y:513,t:1528143720108};\\\", \\\"{x:825,y:511,t:1528143720125};\\\", \\\"{x:825,y:510,t:1528143720141};\\\", \\\"{x:825,y:508,t:1528143720157};\\\", \\\"{x:825,y:507,t:1528143720175};\\\", \\\"{x:824,y:507,t:1528143720221};\\\", \\\"{x:824,y:505,t:1528143720358};\\\", \\\"{x:824,y:503,t:1528143720382};\\\", \\\"{x:826,y:502,t:1528143720406};\\\", \\\"{x:827,y:502,t:1528143720438};\\\", \\\"{x:828,y:502,t:1528143720454};\\\", \\\"{x:830,y:501,t:1528143720470};\\\", \\\"{x:831,y:501,t:1528143720526};\\\", \\\"{x:831,y:500,t:1528143720910};\\\", \\\"{x:833,y:494,t:1528143720925};\\\", \\\"{x:836,y:481,t:1528143720942};\\\", \\\"{x:838,y:473,t:1528143720959};\\\", \\\"{x:840,y:462,t:1528143720975};\\\", \\\"{x:840,y:455,t:1528143720992};\\\", \\\"{x:840,y:451,t:1528143721009};\\\", \\\"{x:840,y:449,t:1528143721026};\\\", \\\"{x:840,y:448,t:1528143721042};\\\", \\\"{x:840,y:446,t:1528143721127};\\\", \\\"{x:840,y:444,t:1528143721143};\\\", \\\"{x:839,y:440,t:1528143721159};\\\", \\\"{x:837,y:436,t:1528143721177};\\\", \\\"{x:836,y:427,t:1528143721193};\\\", \\\"{x:832,y:417,t:1528143721209};\\\", \\\"{x:828,y:410,t:1528143721227};\\\", \\\"{x:823,y:402,t:1528143721243};\\\", \\\"{x:815,y:394,t:1528143721260};\\\", \\\"{x:811,y:388,t:1528143721277};\\\", \\\"{x:810,y:388,t:1528143721293};\\\", \\\"{x:810,y:387,t:1528143721310};\\\", \\\"{x:810,y:386,t:1528143721342};\\\", \\\"{x:809,y:386,t:1528143721375};\\\", \\\"{x:809,y:385,t:1528143721382};\\\", \\\"{x:808,y:384,t:1528143721398};\\\", \\\"{x:807,y:383,t:1528143721415};\\\", \\\"{x:806,y:382,t:1528143721438};\\\", \\\"{x:806,y:381,t:1528143721462};\\\", \\\"{x:805,y:380,t:1528143721519};\\\", \\\"{x:816,y:386,t:1528143721758};\\\", \\\"{x:831,y:394,t:1528143721766};\\\", \\\"{x:857,y:403,t:1528143721776};\\\", \\\"{x:920,y:426,t:1528143721793};\\\", \\\"{x:1009,y:455,t:1528143721811};\\\", \\\"{x:1095,y:478,t:1528143721827};\\\", \\\"{x:1165,y:503,t:1528143721844};\\\", \\\"{x:1206,y:519,t:1528143721861};\\\", \\\"{x:1225,y:529,t:1528143721877};\\\", \\\"{x:1235,y:538,t:1528143721894};\\\", \\\"{x:1243,y:548,t:1528143721909};\\\", \\\"{x:1247,y:551,t:1528143721926};\\\", \\\"{x:1249,y:553,t:1528143721943};\\\", \\\"{x:1251,y:555,t:1528143721959};\\\", \\\"{x:1251,y:556,t:1528143721975};\\\", \\\"{x:1251,y:557,t:1528143721992};\\\", \\\"{x:1254,y:561,t:1528143722010};\\\", \\\"{x:1254,y:569,t:1528143722026};\\\", \\\"{x:1254,y:581,t:1528143722043};\\\", \\\"{x:1254,y:598,t:1528143722060};\\\", \\\"{x:1256,y:614,t:1528143722076};\\\", \\\"{x:1263,y:630,t:1528143722093};\\\", \\\"{x:1277,y:645,t:1528143722109};\\\", \\\"{x:1287,y:649,t:1528143722127};\\\", \\\"{x:1298,y:651,t:1528143722143};\\\", \\\"{x:1306,y:652,t:1528143722161};\\\", \\\"{x:1310,y:652,t:1528143722177};\\\", \\\"{x:1313,y:652,t:1528143722194};\\\", \\\"{x:1317,y:653,t:1528143722210};\\\", \\\"{x:1320,y:653,t:1528143722228};\\\", \\\"{x:1325,y:653,t:1528143722244};\\\", \\\"{x:1327,y:654,t:1528143722260};\\\", \\\"{x:1328,y:654,t:1528143722279};\\\", \\\"{x:1330,y:654,t:1528143722294};\\\", \\\"{x:1335,y:657,t:1528143722310};\\\", \\\"{x:1341,y:659,t:1528143722327};\\\", \\\"{x:1348,y:663,t:1528143722343};\\\", \\\"{x:1351,y:663,t:1528143722361};\\\", \\\"{x:1352,y:664,t:1528143722391};\\\", \\\"{x:1353,y:665,t:1528143722511};\\\", \\\"{x:1352,y:666,t:1528143722543};\\\", \\\"{x:1349,y:668,t:1528143722561};\\\", \\\"{x:1346,y:669,t:1528143722577};\\\", \\\"{x:1342,y:671,t:1528143722594};\\\", \\\"{x:1338,y:672,t:1528143722610};\\\", \\\"{x:1336,y:673,t:1528143722628};\\\", \\\"{x:1330,y:675,t:1528143722645};\\\", \\\"{x:1325,y:676,t:1528143722661};\\\", \\\"{x:1320,y:677,t:1528143722678};\\\", \\\"{x:1312,y:681,t:1528143722694};\\\", \\\"{x:1305,y:685,t:1528143722710};\\\", \\\"{x:1300,y:687,t:1528143722727};\\\", \\\"{x:1296,y:689,t:1528143722745};\\\", \\\"{x:1293,y:692,t:1528143722760};\\\", \\\"{x:1290,y:695,t:1528143722778};\\\", \\\"{x:1289,y:697,t:1528143722794};\\\", \\\"{x:1288,y:700,t:1528143722810};\\\", \\\"{x:1288,y:704,t:1528143722828};\\\", \\\"{x:1288,y:710,t:1528143722845};\\\", \\\"{x:1288,y:713,t:1528143722861};\\\", \\\"{x:1291,y:720,t:1528143722878};\\\", \\\"{x:1300,y:726,t:1528143722894};\\\", \\\"{x:1308,y:731,t:1528143722911};\\\", \\\"{x:1317,y:736,t:1528143722927};\\\", \\\"{x:1326,y:740,t:1528143722945};\\\", \\\"{x:1333,y:746,t:1528143722961};\\\", \\\"{x:1342,y:750,t:1528143722977};\\\", \\\"{x:1353,y:754,t:1528143722994};\\\", \\\"{x:1365,y:759,t:1528143723011};\\\", \\\"{x:1375,y:763,t:1528143723028};\\\", \\\"{x:1390,y:770,t:1528143723045};\\\", \\\"{x:1401,y:778,t:1528143723061};\\\", \\\"{x:1412,y:787,t:1528143723078};\\\", \\\"{x:1427,y:806,t:1528143723094};\\\", \\\"{x:1436,y:819,t:1528143723112};\\\", \\\"{x:1440,y:827,t:1528143723127};\\\", \\\"{x:1440,y:832,t:1528143723145};\\\", \\\"{x:1440,y:837,t:1528143723162};\\\", \\\"{x:1440,y:841,t:1528143723178};\\\", \\\"{x:1440,y:845,t:1528143723195};\\\", \\\"{x:1440,y:848,t:1528143723211};\\\", \\\"{x:1440,y:851,t:1528143723227};\\\", \\\"{x:1440,y:853,t:1528143723245};\\\", \\\"{x:1440,y:857,t:1528143723262};\\\", \\\"{x:1444,y:862,t:1528143723278};\\\", \\\"{x:1458,y:871,t:1528143723294};\\\", \\\"{x:1475,y:875,t:1528143723311};\\\", \\\"{x:1505,y:879,t:1528143723328};\\\", \\\"{x:1547,y:884,t:1528143723344};\\\", \\\"{x:1590,y:887,t:1528143723362};\\\", \\\"{x:1616,y:888,t:1528143723377};\\\", \\\"{x:1626,y:890,t:1528143723394};\\\", \\\"{x:1628,y:891,t:1528143723411};\\\", \\\"{x:1629,y:892,t:1528143723428};\\\", \\\"{x:1629,y:893,t:1528143723444};\\\", \\\"{x:1625,y:897,t:1528143723462};\\\", \\\"{x:1616,y:906,t:1528143723478};\\\", \\\"{x:1593,y:919,t:1528143723494};\\\", \\\"{x:1566,y:925,t:1528143723512};\\\", \\\"{x:1534,y:931,t:1528143723528};\\\", \\\"{x:1482,y:937,t:1528143723544};\\\", \\\"{x:1428,y:939,t:1528143723561};\\\", \\\"{x:1375,y:939,t:1528143723577};\\\", \\\"{x:1342,y:936,t:1528143723594};\\\", \\\"{x:1326,y:933,t:1528143723611};\\\", \\\"{x:1323,y:931,t:1528143723628};\\\", \\\"{x:1322,y:931,t:1528143723644};\\\", \\\"{x:1321,y:929,t:1528143723661};\\\", \\\"{x:1319,y:927,t:1528143723677};\\\", \\\"{x:1319,y:926,t:1528143723759};\\\", \\\"{x:1320,y:926,t:1528143723799};\\\", \\\"{x:1321,y:926,t:1528143723863};\\\", \\\"{x:1323,y:926,t:1528143723878};\\\", \\\"{x:1324,y:927,t:1528143723926};\\\", \\\"{x:1325,y:927,t:1528143723967};\\\", \\\"{x:1325,y:926,t:1528143724175};\\\", \\\"{x:1325,y:925,t:1528143724190};\\\", \\\"{x:1325,y:924,t:1528143724207};\\\", \\\"{x:1325,y:923,t:1528143724214};\\\", \\\"{x:1325,y:922,t:1528143724239};\\\", \\\"{x:1325,y:920,t:1528143724382};\\\", \\\"{x:1326,y:919,t:1528143724471};\\\", \\\"{x:1326,y:918,t:1528143724511};\\\", \\\"{x:1328,y:917,t:1528143724542};\\\", \\\"{x:1330,y:916,t:1528143724550};\\\", \\\"{x:1332,y:915,t:1528143724567};\\\", \\\"{x:1334,y:914,t:1528143724579};\\\", \\\"{x:1338,y:913,t:1528143724596};\\\", \\\"{x:1343,y:912,t:1528143724612};\\\", \\\"{x:1350,y:911,t:1528143724629};\\\", \\\"{x:1360,y:910,t:1528143724646};\\\", \\\"{x:1372,y:907,t:1528143724662};\\\", \\\"{x:1378,y:904,t:1528143724679};\\\", \\\"{x:1380,y:903,t:1528143724696};\\\", \\\"{x:1381,y:903,t:1528143724713};\\\", \\\"{x:1381,y:902,t:1528143724730};\\\", \\\"{x:1384,y:900,t:1528143724745};\\\", \\\"{x:1388,y:896,t:1528143724763};\\\", \\\"{x:1390,y:893,t:1528143724779};\\\", \\\"{x:1391,y:892,t:1528143724795};\\\", \\\"{x:1394,y:888,t:1528143724812};\\\", \\\"{x:1395,y:885,t:1528143724829};\\\", \\\"{x:1396,y:884,t:1528143724846};\\\", \\\"{x:1398,y:881,t:1528143724862};\\\", \\\"{x:1398,y:879,t:1528143724878};\\\", \\\"{x:1400,y:877,t:1528143724895};\\\", \\\"{x:1401,y:876,t:1528143724912};\\\", \\\"{x:1404,y:873,t:1528143724928};\\\", \\\"{x:1406,y:871,t:1528143724945};\\\", \\\"{x:1411,y:869,t:1528143724962};\\\", \\\"{x:1420,y:865,t:1528143724978};\\\", \\\"{x:1429,y:863,t:1528143724996};\\\", \\\"{x:1445,y:858,t:1528143725012};\\\", \\\"{x:1463,y:857,t:1528143725029};\\\", \\\"{x:1483,y:857,t:1528143725045};\\\", \\\"{x:1513,y:857,t:1528143725062};\\\", \\\"{x:1528,y:857,t:1528143725079};\\\", \\\"{x:1534,y:857,t:1528143725096};\\\", \\\"{x:1539,y:857,t:1528143725113};\\\", \\\"{x:1543,y:857,t:1528143725129};\\\", \\\"{x:1547,y:857,t:1528143725146};\\\", \\\"{x:1552,y:857,t:1528143725163};\\\", \\\"{x:1557,y:857,t:1528143725179};\\\", \\\"{x:1562,y:857,t:1528143725196};\\\", \\\"{x:1566,y:857,t:1528143725213};\\\", \\\"{x:1570,y:857,t:1528143725229};\\\", \\\"{x:1575,y:857,t:1528143725245};\\\", \\\"{x:1580,y:857,t:1528143725263};\\\", \\\"{x:1581,y:857,t:1528143725280};\\\", \\\"{x:1579,y:857,t:1528143726174};\\\", \\\"{x:1572,y:857,t:1528143726182};\\\", \\\"{x:1561,y:857,t:1528143726197};\\\", \\\"{x:1538,y:857,t:1528143726215};\\\", \\\"{x:1512,y:857,t:1528143726229};\\\", \\\"{x:1480,y:857,t:1528143726246};\\\", \\\"{x:1470,y:857,t:1528143726264};\\\", \\\"{x:1467,y:857,t:1528143726280};\\\", \\\"{x:1466,y:857,t:1528143726297};\\\", \\\"{x:1465,y:857,t:1528143726335};\\\", \\\"{x:1462,y:856,t:1528143726351};\\\", \\\"{x:1460,y:856,t:1528143726366};\\\", \\\"{x:1458,y:856,t:1528143726380};\\\", \\\"{x:1447,y:855,t:1528143726397};\\\", \\\"{x:1430,y:854,t:1528143726413};\\\", \\\"{x:1409,y:854,t:1528143726429};\\\", \\\"{x:1368,y:854,t:1528143726447};\\\", \\\"{x:1334,y:854,t:1528143726463};\\\", \\\"{x:1292,y:854,t:1528143726480};\\\", \\\"{x:1247,y:854,t:1528143726496};\\\", \\\"{x:1199,y:854,t:1528143726514};\\\", \\\"{x:1146,y:854,t:1528143726531};\\\", \\\"{x:1102,y:854,t:1528143726547};\\\", \\\"{x:1052,y:850,t:1528143726563};\\\", \\\"{x:999,y:850,t:1528143726581};\\\", \\\"{x:944,y:845,t:1528143726597};\\\", \\\"{x:877,y:838,t:1528143726614};\\\", \\\"{x:843,y:832,t:1528143726630};\\\", \\\"{x:803,y:826,t:1528143726646};\\\", \\\"{x:763,y:820,t:1528143726663};\\\", \\\"{x:725,y:812,t:1528143726681};\\\", \\\"{x:696,y:802,t:1528143726697};\\\", \\\"{x:671,y:793,t:1528143726713};\\\", \\\"{x:647,y:779,t:1528143726731};\\\", \\\"{x:630,y:766,t:1528143726747};\\\", \\\"{x:609,y:748,t:1528143726763};\\\", \\\"{x:589,y:731,t:1528143726781};\\\", \\\"{x:572,y:716,t:1528143726796};\\\", \\\"{x:558,y:698,t:1528143726814};\\\", \\\"{x:541,y:675,t:1528143726830};\\\", \\\"{x:532,y:659,t:1528143726847};\\\", \\\"{x:524,y:645,t:1528143726863};\\\", \\\"{x:518,y:632,t:1528143726880};\\\", \\\"{x:511,y:621,t:1528143726900};\\\", \\\"{x:506,y:610,t:1528143726913};\\\", \\\"{x:502,y:600,t:1528143726930};\\\", \\\"{x:497,y:592,t:1528143726947};\\\", \\\"{x:495,y:585,t:1528143726964};\\\", \\\"{x:492,y:579,t:1528143726980};\\\", \\\"{x:490,y:573,t:1528143726997};\\\", \\\"{x:488,y:569,t:1528143727013};\\\", \\\"{x:488,y:565,t:1528143727030};\\\", \\\"{x:488,y:560,t:1528143727047};\\\", \\\"{x:488,y:554,t:1528143727065};\\\", \\\"{x:488,y:550,t:1528143727080};\\\", \\\"{x:488,y:546,t:1528143727097};\\\", \\\"{x:490,y:541,t:1528143727114};\\\", \\\"{x:493,y:537,t:1528143727131};\\\", \\\"{x:496,y:532,t:1528143727147};\\\", \\\"{x:497,y:530,t:1528143727164};\\\", \\\"{x:500,y:526,t:1528143727182};\\\", \\\"{x:504,y:522,t:1528143727198};\\\", \\\"{x:506,y:520,t:1528143727215};\\\", \\\"{x:509,y:518,t:1528143727231};\\\", \\\"{x:511,y:516,t:1528143727247};\\\", \\\"{x:514,y:515,t:1528143727264};\\\", \\\"{x:515,y:514,t:1528143727281};\\\", \\\"{x:516,y:513,t:1528143727297};\\\", \\\"{x:518,y:511,t:1528143727314};\\\", \\\"{x:520,y:510,t:1528143727330};\\\", \\\"{x:521,y:510,t:1528143727349};\\\", \\\"{x:522,y:510,t:1528143727365};\\\", \\\"{x:523,y:509,t:1528143727380};\\\", \\\"{x:524,y:508,t:1528143727397};\\\", \\\"{x:525,y:508,t:1528143727414};\\\", \\\"{x:525,y:507,t:1528143727430};\\\", \\\"{x:526,y:507,t:1528143727951};\\\", \\\"{x:526,y:505,t:1528143727966};\\\", \\\"{x:527,y:504,t:1528143727990};\\\", \\\"{x:529,y:502,t:1528143728014};\\\", \\\"{x:530,y:501,t:1528143728038};\\\", \\\"{x:531,y:499,t:1528143728054};\\\", \\\"{x:532,y:498,t:1528143728070};\\\", \\\"{x:532,y:497,t:1528143728081};\\\", \\\"{x:533,y:497,t:1528143728097};\\\", \\\"{x:533,y:496,t:1528143728114};\\\", \\\"{x:534,y:496,t:1528143728132};\\\", \\\"{x:535,y:495,t:1528143728359};\\\", \\\"{x:536,y:495,t:1528143728374};\\\", \\\"{x:537,y:494,t:1528143728390};\\\", \\\"{x:538,y:494,t:1528143728398};\\\", \\\"{x:542,y:494,t:1528143728414};\\\", \\\"{x:549,y:492,t:1528143728430};\\\", \\\"{x:560,y:492,t:1528143728447};\\\", \\\"{x:586,y:493,t:1528143728463};\\\", \\\"{x:645,y:501,t:1528143728481};\\\", \\\"{x:730,y:509,t:1528143728499};\\\", \\\"{x:829,y:519,t:1528143728514};\\\", \\\"{x:934,y:533,t:1528143728532};\\\", \\\"{x:1034,y:546,t:1528143728547};\\\", \\\"{x:1150,y:566,t:1528143728565};\\\", \\\"{x:1196,y:574,t:1528143728582};\\\", \\\"{x:1219,y:579,t:1528143728598};\\\", \\\"{x:1234,y:583,t:1528143728615};\\\", \\\"{x:1244,y:587,t:1528143728632};\\\", \\\"{x:1253,y:594,t:1528143728649};\\\", \\\"{x:1268,y:605,t:1528143728665};\\\", \\\"{x:1283,y:615,t:1528143728682};\\\", \\\"{x:1298,y:628,t:1528143728698};\\\", \\\"{x:1308,y:637,t:1528143728715};\\\", \\\"{x:1317,y:647,t:1528143728733};\\\", \\\"{x:1322,y:653,t:1528143728749};\\\", \\\"{x:1329,y:660,t:1528143728766};\\\", \\\"{x:1337,y:669,t:1528143728783};\\\", \\\"{x:1344,y:678,t:1528143728798};\\\", \\\"{x:1352,y:686,t:1528143728815};\\\", \\\"{x:1357,y:692,t:1528143728833};\\\", \\\"{x:1362,y:695,t:1528143728849};\\\", \\\"{x:1365,y:696,t:1528143728867};\\\", \\\"{x:1368,y:697,t:1528143728883};\\\", \\\"{x:1371,y:697,t:1528143728899};\\\", \\\"{x:1373,y:699,t:1528143728916};\\\", \\\"{x:1374,y:699,t:1528143728951};\\\", \\\"{x:1376,y:699,t:1528143728982};\\\", \\\"{x:1376,y:700,t:1528143729415};\\\", \\\"{x:1375,y:702,t:1528143729430};\\\", \\\"{x:1373,y:702,t:1528143729438};\\\", \\\"{x:1373,y:703,t:1528143729449};\\\", \\\"{x:1371,y:705,t:1528143729467};\\\", \\\"{x:1368,y:706,t:1528143729483};\\\", \\\"{x:1365,y:709,t:1528143729500};\\\", \\\"{x:1358,y:713,t:1528143729517};\\\", \\\"{x:1347,y:721,t:1528143729533};\\\", \\\"{x:1330,y:733,t:1528143729550};\\\", \\\"{x:1320,y:739,t:1528143729566};\\\", \\\"{x:1314,y:745,t:1528143729583};\\\", \\\"{x:1310,y:750,t:1528143729600};\\\", \\\"{x:1305,y:755,t:1528143729617};\\\", \\\"{x:1301,y:761,t:1528143729633};\\\", \\\"{x:1298,y:763,t:1528143729650};\\\", \\\"{x:1298,y:764,t:1528143729667};\\\", \\\"{x:1297,y:765,t:1528143729735};\\\", \\\"{x:1295,y:767,t:1528143729750};\\\", \\\"{x:1291,y:769,t:1528143729766};\\\", \\\"{x:1284,y:769,t:1528143729783};\\\", \\\"{x:1269,y:768,t:1528143729800};\\\", \\\"{x:1246,y:755,t:1528143729817};\\\", \\\"{x:1210,y:737,t:1528143729833};\\\", \\\"{x:1155,y:714,t:1528143729850};\\\", \\\"{x:1075,y:680,t:1528143729867};\\\", \\\"{x:978,y:640,t:1528143729884};\\\", \\\"{x:876,y:593,t:1528143729901};\\\", \\\"{x:807,y:562,t:1528143729916};\\\", \\\"{x:772,y:540,t:1528143729931};\\\", \\\"{x:758,y:531,t:1528143729948};\\\", \\\"{x:754,y:526,t:1528143729967};\\\", \\\"{x:753,y:526,t:1528143730030};\\\", \\\"{x:754,y:524,t:1528143730151};\\\", \\\"{x:761,y:520,t:1528143730167};\\\", \\\"{x:769,y:517,t:1528143730184};\\\", \\\"{x:777,y:513,t:1528143730200};\\\", \\\"{x:786,y:509,t:1528143730216};\\\", \\\"{x:791,y:507,t:1528143730234};\\\", \\\"{x:794,y:506,t:1528143730251};\\\", \\\"{x:797,y:505,t:1528143730268};\\\", \\\"{x:799,y:504,t:1528143730283};\\\", \\\"{x:800,y:504,t:1528143730300};\\\", \\\"{x:803,y:503,t:1528143730438};\\\", \\\"{x:807,y:503,t:1528143730452};\\\", \\\"{x:814,y:503,t:1528143730468};\\\", \\\"{x:821,y:502,t:1528143730484};\\\", \\\"{x:827,y:500,t:1528143730501};\\\", \\\"{x:828,y:500,t:1528143730518};\\\", \\\"{x:830,y:499,t:1528143730534};\\\", \\\"{x:831,y:499,t:1528143730662};\\\", \\\"{x:838,y:503,t:1528143730800};\\\", \\\"{x:839,y:509,t:1528143730817};\\\", \\\"{x:842,y:518,t:1528143730834};\\\", \\\"{x:844,y:530,t:1528143730850};\\\", \\\"{x:844,y:538,t:1528143730868};\\\", \\\"{x:844,y:545,t:1528143730883};\\\", \\\"{x:844,y:551,t:1528143730900};\\\", \\\"{x:844,y:558,t:1528143730918};\\\", \\\"{x:844,y:564,t:1528143730933};\\\", \\\"{x:840,y:573,t:1528143730950};\\\", \\\"{x:836,y:581,t:1528143730967};\\\", \\\"{x:836,y:585,t:1528143730984};\\\", \\\"{x:836,y:587,t:1528143731000};\\\", \\\"{x:836,y:588,t:1528143731038};\\\", \\\"{x:836,y:589,t:1528143731054};\\\", \\\"{x:836,y:590,t:1528143731068};\\\", \\\"{x:834,y:591,t:1528143731084};\\\", \\\"{x:834,y:592,t:1528143731142};\\\", \\\"{x:834,y:593,t:1528143731157};\\\", \\\"{x:834,y:594,t:1528143731168};\\\", \\\"{x:834,y:597,t:1528143731184};\\\", \\\"{x:834,y:600,t:1528143731200};\\\", \\\"{x:834,y:603,t:1528143731218};\\\", \\\"{x:834,y:604,t:1528143731235};\\\", \\\"{x:834,y:605,t:1528143731253};\\\", \\\"{x:834,y:606,t:1528143731268};\\\", \\\"{x:834,y:607,t:1528143731285};\\\", \\\"{x:834,y:608,t:1528143731301};\\\", \\\"{x:834,y:610,t:1528143731317};\\\", \\\"{x:834,y:611,t:1528143731334};\\\", \\\"{x:834,y:612,t:1528143731350};\\\", \\\"{x:834,y:613,t:1528143731373};\\\", \\\"{x:829,y:613,t:1528143731557};\\\", \\\"{x:820,y:612,t:1528143731568};\\\", \\\"{x:801,y:607,t:1528143731584};\\\", \\\"{x:778,y:600,t:1528143731602};\\\", \\\"{x:745,y:593,t:1528143731617};\\\", \\\"{x:712,y:584,t:1528143731635};\\\", \\\"{x:682,y:574,t:1528143731651};\\\", \\\"{x:659,y:562,t:1528143731667};\\\", \\\"{x:641,y:551,t:1528143731684};\\\", \\\"{x:622,y:539,t:1528143731702};\\\", \\\"{x:608,y:532,t:1528143731717};\\\", \\\"{x:595,y:526,t:1528143731735};\\\", \\\"{x:584,y:518,t:1528143731752};\\\", \\\"{x:569,y:510,t:1528143731767};\\\", \\\"{x:554,y:503,t:1528143731785};\\\", \\\"{x:544,y:498,t:1528143731801};\\\", \\\"{x:539,y:496,t:1528143731818};\\\", \\\"{x:537,y:496,t:1528143731834};\\\", \\\"{x:536,y:494,t:1528143731851};\\\", \\\"{x:533,y:494,t:1528143731867};\\\", \\\"{x:531,y:493,t:1528143731884};\\\", \\\"{x:527,y:492,t:1528143731901};\\\", \\\"{x:525,y:491,t:1528143731918};\\\", \\\"{x:523,y:491,t:1528143731934};\\\", \\\"{x:521,y:491,t:1528143731952};\\\", \\\"{x:520,y:490,t:1528143731968};\\\", \\\"{x:518,y:489,t:1528143731985};\\\", \\\"{x:521,y:486,t:1528143732207};\\\", \\\"{x:528,y:483,t:1528143732219};\\\", \\\"{x:554,y:481,t:1528143732234};\\\", \\\"{x:598,y:490,t:1528143732252};\\\", \\\"{x:675,y:509,t:1528143732268};\\\", \\\"{x:774,y:534,t:1528143732285};\\\", \\\"{x:959,y:583,t:1528143732301};\\\", \\\"{x:1083,y:616,t:1528143732318};\\\", \\\"{x:1187,y:653,t:1528143732334};\\\", \\\"{x:1278,y:692,t:1528143732351};\\\", \\\"{x:1347,y:721,t:1528143732368};\\\", \\\"{x:1387,y:742,t:1528143732384};\\\", \\\"{x:1407,y:751,t:1528143732401};\\\", \\\"{x:1413,y:755,t:1528143732419};\\\", \\\"{x:1411,y:755,t:1528143732535};\\\", \\\"{x:1396,y:752,t:1528143732552};\\\", \\\"{x:1371,y:744,t:1528143732569};\\\", \\\"{x:1339,y:734,t:1528143732587};\\\", \\\"{x:1293,y:724,t:1528143732602};\\\", \\\"{x:1240,y:709,t:1528143732619};\\\", \\\"{x:1187,y:693,t:1528143732636};\\\", \\\"{x:1131,y:679,t:1528143732652};\\\", \\\"{x:1080,y:659,t:1528143732669};\\\", \\\"{x:988,y:634,t:1528143732686};\\\", \\\"{x:928,y:614,t:1528143732703};\\\", \\\"{x:883,y:598,t:1528143732720};\\\", \\\"{x:852,y:590,t:1528143732737};\\\", \\\"{x:828,y:582,t:1528143732751};\\\", \\\"{x:812,y:574,t:1528143732769};\\\", \\\"{x:802,y:569,t:1528143732785};\\\", \\\"{x:791,y:563,t:1528143732802};\\\", \\\"{x:775,y:554,t:1528143732818};\\\", \\\"{x:759,y:547,t:1528143732835};\\\", \\\"{x:744,y:537,t:1528143732853};\\\", \\\"{x:732,y:531,t:1528143732868};\\\", \\\"{x:712,y:518,t:1528143732886};\\\", \\\"{x:696,y:512,t:1528143732903};\\\", \\\"{x:679,y:505,t:1528143732918};\\\", \\\"{x:657,y:496,t:1528143732936};\\\", \\\"{x:636,y:489,t:1528143732953};\\\", \\\"{x:622,y:485,t:1528143732969};\\\", \\\"{x:607,y:481,t:1528143732985};\\\", \\\"{x:589,y:475,t:1528143733003};\\\", \\\"{x:569,y:472,t:1528143733018};\\\", \\\"{x:543,y:469,t:1528143733036};\\\", \\\"{x:524,y:467,t:1528143733053};\\\", \\\"{x:512,y:464,t:1528143733069};\\\", \\\"{x:499,y:463,t:1528143733085};\\\", \\\"{x:496,y:462,t:1528143733103};\\\", \\\"{x:495,y:462,t:1528143733246};\\\", \\\"{x:495,y:463,t:1528143733261};\\\", \\\"{x:495,y:464,t:1528143733269};\\\", \\\"{x:504,y:470,t:1528143733286};\\\", \\\"{x:528,y:475,t:1528143733303};\\\", \\\"{x:585,y:481,t:1528143733319};\\\", \\\"{x:664,y:487,t:1528143733336};\\\", \\\"{x:734,y:487,t:1528143733353};\\\", \\\"{x:806,y:487,t:1528143733369};\\\", \\\"{x:871,y:488,t:1528143733386};\\\", \\\"{x:917,y:491,t:1528143733403};\\\", \\\"{x:956,y:497,t:1528143733420};\\\", \\\"{x:1004,y:504,t:1528143733436};\\\", \\\"{x:1073,y:522,t:1528143733453};\\\", \\\"{x:1184,y:555,t:1528143733470};\\\", \\\"{x:1265,y:577,t:1528143733486};\\\", \\\"{x:1328,y:592,t:1528143733502};\\\", \\\"{x:1365,y:599,t:1528143733520};\\\", \\\"{x:1382,y:600,t:1528143733537};\\\", \\\"{x:1384,y:601,t:1528143733554};\\\", \\\"{x:1382,y:601,t:1528143733631};\\\", \\\"{x:1377,y:603,t:1528143733638};\\\", \\\"{x:1361,y:604,t:1528143733654};\\\", \\\"{x:1334,y:609,t:1528143733671};\\\", \\\"{x:1297,y:610,t:1528143733688};\\\", \\\"{x:1241,y:610,t:1528143733704};\\\", \\\"{x:1199,y:610,t:1528143733721};\\\", \\\"{x:1172,y:610,t:1528143733738};\\\", \\\"{x:1164,y:611,t:1528143733754};\\\", \\\"{x:1166,y:613,t:1528143734055};\\\", \\\"{x:1170,y:614,t:1528143734062};\\\", \\\"{x:1177,y:615,t:1528143734072};\\\", \\\"{x:1193,y:619,t:1528143734089};\\\", \\\"{x:1215,y:620,t:1528143734106};\\\", \\\"{x:1243,y:623,t:1528143734123};\\\", \\\"{x:1272,y:623,t:1528143734139};\\\", \\\"{x:1294,y:623,t:1528143734156};\\\", \\\"{x:1308,y:623,t:1528143734174};\\\", \\\"{x:1319,y:623,t:1528143734190};\\\", \\\"{x:1326,y:623,t:1528143734206};\\\", \\\"{x:1335,y:623,t:1528143734223};\\\", \\\"{x:1352,y:623,t:1528143734241};\\\", \\\"{x:1371,y:623,t:1528143734257};\\\", \\\"{x:1389,y:623,t:1528143734273};\\\", \\\"{x:1398,y:623,t:1528143734290};\\\", \\\"{x:1404,y:623,t:1528143734307};\\\", \\\"{x:1407,y:623,t:1528143734324};\\\", \\\"{x:1412,y:623,t:1528143734340};\\\", \\\"{x:1414,y:623,t:1528143734357};\\\", \\\"{x:1416,y:623,t:1528143734374};\\\", \\\"{x:1417,y:623,t:1528143735335};\\\", \\\"{x:1420,y:623,t:1528143735375};\\\", \\\"{x:1424,y:623,t:1528143735382};\\\", \\\"{x:1425,y:623,t:1528143735395};\\\", \\\"{x:1429,y:624,t:1528143735413};\\\", \\\"{x:1435,y:624,t:1528143735428};\\\", \\\"{x:1439,y:625,t:1528143735446};\\\", \\\"{x:1445,y:625,t:1528143735462};\\\", \\\"{x:1446,y:625,t:1528143735479};\\\", \\\"{x:1447,y:625,t:1528143735495};\\\", \\\"{x:1449,y:625,t:1528143735512};\\\", \\\"{x:1450,y:625,t:1528143735529};\\\", \\\"{x:1452,y:626,t:1528143735545};\\\", \\\"{x:1453,y:626,t:1528143735563};\\\", \\\"{x:1454,y:626,t:1528143735580};\\\", \\\"{x:1455,y:627,t:1528143735623};\\\", \\\"{x:1456,y:628,t:1528143735654};\\\", \\\"{x:1456,y:629,t:1528143735695};\\\", \\\"{x:1456,y:630,t:1528143735959};\\\", \\\"{x:1455,y:631,t:1528143735982};\\\", \\\"{x:1454,y:631,t:1528143736006};\\\", \\\"{x:1453,y:631,t:1528143736023};\\\", \\\"{x:1452,y:632,t:1528143736048};\\\", \\\"{x:1450,y:633,t:1528143736064};\\\", \\\"{x:1449,y:633,t:1528143736142};\\\", \\\"{x:1446,y:633,t:1528143744736};\\\", \\\"{x:1419,y:632,t:1528143744746};\\\", \\\"{x:1322,y:621,t:1528143744762};\\\", \\\"{x:1197,y:600,t:1528143744778};\\\", \\\"{x:1067,y:581,t:1528143744795};\\\", \\\"{x:976,y:572,t:1528143744812};\\\", \\\"{x:945,y:568,t:1528143744829};\\\", \\\"{x:937,y:565,t:1528143744844};\\\", \\\"{x:936,y:565,t:1528143744862};\\\", \\\"{x:933,y:565,t:1528143744878};\\\", \\\"{x:930,y:565,t:1528143744887};\\\", \\\"{x:925,y:564,t:1528143744904};\\\", \\\"{x:919,y:564,t:1528143744921};\\\", \\\"{x:918,y:564,t:1528143744937};\\\", \\\"{x:917,y:564,t:1528143745023};\\\", \\\"{x:912,y:564,t:1528143745037};\\\", \\\"{x:890,y:564,t:1528143745054};\\\", \\\"{x:866,y:564,t:1528143745071};\\\", \\\"{x:822,y:564,t:1528143745087};\\\", \\\"{x:761,y:564,t:1528143745104};\\\", \\\"{x:710,y:564,t:1528143745122};\\\", \\\"{x:683,y:564,t:1528143745137};\\\", \\\"{x:674,y:564,t:1528143745154};\\\", \\\"{x:673,y:564,t:1528143745172};\\\", \\\"{x:672,y:564,t:1528143745191};\\\", \\\"{x:670,y:564,t:1528143745207};\\\", \\\"{x:667,y:564,t:1528143745221};\\\", \\\"{x:658,y:564,t:1528143745238};\\\", \\\"{x:645,y:564,t:1528143745255};\\\", \\\"{x:638,y:564,t:1528143745272};\\\", \\\"{x:637,y:564,t:1528143745289};\\\", \\\"{x:636,y:564,t:1528143745319};\\\", \\\"{x:635,y:564,t:1528143745327};\\\", \\\"{x:633,y:564,t:1528143745339};\\\", \\\"{x:630,y:564,t:1528143745354};\\\", \\\"{x:626,y:564,t:1528143745371};\\\", \\\"{x:623,y:565,t:1528143745388};\\\", \\\"{x:622,y:565,t:1528143745407};\\\", \\\"{x:620,y:566,t:1528143745422};\\\", \\\"{x:618,y:567,t:1528143745439};\\\", \\\"{x:616,y:567,t:1528143745454};\\\", \\\"{x:616,y:568,t:1528143745478};\\\", \\\"{x:633,y:568,t:1528143745622};\\\", \\\"{x:696,y:575,t:1528143745638};\\\", \\\"{x:746,y:575,t:1528143745656};\\\", \\\"{x:767,y:575,t:1528143745671};\\\", \\\"{x:781,y:575,t:1528143745688};\\\", \\\"{x:793,y:575,t:1528143745705};\\\", \\\"{x:803,y:575,t:1528143745721};\\\", \\\"{x:806,y:575,t:1528143745739};\\\", \\\"{x:807,y:575,t:1528143745755};\\\", \\\"{x:809,y:575,t:1528143745774};\\\", \\\"{x:810,y:575,t:1528143745847};\\\", \\\"{x:811,y:576,t:1528143745863};\\\", \\\"{x:813,y:576,t:1528143745872};\\\", \\\"{x:815,y:577,t:1528143745889};\\\", \\\"{x:819,y:579,t:1528143745906};\\\", \\\"{x:825,y:580,t:1528143745922};\\\", \\\"{x:834,y:580,t:1528143745939};\\\", \\\"{x:840,y:580,t:1528143745955};\\\", \\\"{x:842,y:580,t:1528143745973};\\\", \\\"{x:841,y:580,t:1528143746159};\\\", \\\"{x:845,y:579,t:1528143746407};\\\", \\\"{x:850,y:577,t:1528143746423};\\\", \\\"{x:854,y:575,t:1528143746439};\\\", \\\"{x:860,y:573,t:1528143746456};\\\", \\\"{x:888,y:573,t:1528143746473};\\\", \\\"{x:949,y:573,t:1528143746489};\\\", \\\"{x:1054,y:573,t:1528143746506};\\\", \\\"{x:1201,y:573,t:1528143746523};\\\", \\\"{x:1358,y:590,t:1528143746540};\\\", \\\"{x:1492,y:613,t:1528143746555};\\\", \\\"{x:1583,y:641,t:1528143746572};\\\", \\\"{x:1620,y:657,t:1528143746589};\\\", \\\"{x:1630,y:665,t:1528143746605};\\\", \\\"{x:1635,y:675,t:1528143746622};\\\", \\\"{x:1642,y:691,t:1528143746639};\\\", \\\"{x:1657,y:714,t:1528143746655};\\\", \\\"{x:1678,y:734,t:1528143746672};\\\", \\\"{x:1692,y:746,t:1528143746690};\\\", \\\"{x:1697,y:750,t:1528143746705};\\\", \\\"{x:1697,y:752,t:1528143746722};\\\", \\\"{x:1697,y:757,t:1528143746739};\\\", \\\"{x:1697,y:762,t:1528143746756};\\\", \\\"{x:1690,y:771,t:1528143746773};\\\", \\\"{x:1681,y:781,t:1528143746791};\\\", \\\"{x:1674,y:786,t:1528143746806};\\\", \\\"{x:1665,y:791,t:1528143746823};\\\", \\\"{x:1650,y:796,t:1528143746839};\\\", \\\"{x:1629,y:802,t:1528143746856};\\\", \\\"{x:1608,y:807,t:1528143746873};\\\", \\\"{x:1579,y:812,t:1528143746890};\\\", \\\"{x:1552,y:813,t:1528143746907};\\\", \\\"{x:1530,y:817,t:1528143746923};\\\", \\\"{x:1516,y:818,t:1528143746940};\\\", \\\"{x:1503,y:820,t:1528143746957};\\\", \\\"{x:1495,y:822,t:1528143746973};\\\", \\\"{x:1493,y:822,t:1528143746990};\\\", \\\"{x:1492,y:822,t:1528143747007};\\\", \\\"{x:1491,y:822,t:1528143747512};\\\", \\\"{x:1485,y:826,t:1528143747524};\\\", \\\"{x:1475,y:830,t:1528143747544};\\\", \\\"{x:1460,y:838,t:1528143747556};\\\", \\\"{x:1442,y:851,t:1528143747573};\\\", \\\"{x:1430,y:861,t:1528143747590};\\\", \\\"{x:1401,y:876,t:1528143747607};\\\", \\\"{x:1381,y:886,t:1528143747623};\\\", \\\"{x:1367,y:891,t:1528143747639};\\\", \\\"{x:1358,y:891,t:1528143747657};\\\", \\\"{x:1355,y:891,t:1528143747673};\\\", \\\"{x:1355,y:889,t:1528143747690};\\\", \\\"{x:1355,y:876,t:1528143747707};\\\", \\\"{x:1363,y:857,t:1528143747723};\\\", \\\"{x:1370,y:840,t:1528143747741};\\\", \\\"{x:1372,y:826,t:1528143747757};\\\", \\\"{x:1373,y:817,t:1528143747774};\\\", \\\"{x:1373,y:808,t:1528143747791};\\\", \\\"{x:1371,y:805,t:1528143747806};\\\", \\\"{x:1371,y:804,t:1528143747824};\\\", \\\"{x:1369,y:799,t:1528143747840};\\\", \\\"{x:1368,y:797,t:1528143747856};\\\", \\\"{x:1368,y:794,t:1528143747873};\\\", \\\"{x:1368,y:792,t:1528143747890};\\\", \\\"{x:1368,y:790,t:1528143747907};\\\", \\\"{x:1368,y:789,t:1528143747924};\\\", \\\"{x:1368,y:788,t:1528143747943};\\\", \\\"{x:1368,y:787,t:1528143747959};\\\", \\\"{x:1369,y:787,t:1528143747974};\\\", \\\"{x:1368,y:786,t:1528143748015};\\\", \\\"{x:1364,y:786,t:1528143748024};\\\", \\\"{x:1342,y:789,t:1528143748041};\\\", \\\"{x:1297,y:801,t:1528143748057};\\\", \\\"{x:1239,y:817,t:1528143748075};\\\", \\\"{x:1183,y:834,t:1528143748091};\\\", \\\"{x:1143,y:841,t:1528143748107};\\\", \\\"{x:1118,y:845,t:1528143748124};\\\", \\\"{x:1099,y:846,t:1528143748141};\\\", \\\"{x:1079,y:851,t:1528143748158};\\\", \\\"{x:1049,y:855,t:1528143748174};\\\", \\\"{x:1006,y:861,t:1528143748192};\\\", \\\"{x:980,y:864,t:1528143748207};\\\", \\\"{x:952,y:869,t:1528143748224};\\\", \\\"{x:926,y:875,t:1528143748241};\\\", \\\"{x:897,y:879,t:1528143748258};\\\", \\\"{x:875,y:879,t:1528143748274};\\\", \\\"{x:859,y:876,t:1528143748291};\\\", \\\"{x:839,y:871,t:1528143748308};\\\", \\\"{x:819,y:867,t:1528143748324};\\\", \\\"{x:793,y:864,t:1528143748341};\\\", \\\"{x:770,y:860,t:1528143748358};\\\", \\\"{x:732,y:847,t:1528143748373};\\\", \\\"{x:675,y:823,t:1528143748391};\\\", \\\"{x:642,y:802,t:1528143748407};\\\", \\\"{x:622,y:791,t:1528143748424};\\\", \\\"{x:609,y:782,t:1528143748441};\\\", \\\"{x:606,y:779,t:1528143748458};\\\", \\\"{x:604,y:778,t:1528143748474};\\\", \\\"{x:603,y:778,t:1528143748511};\\\", \\\"{x:600,y:776,t:1528143748524};\\\", \\\"{x:591,y:771,t:1528143748542};\\\", \\\"{x:575,y:765,t:1528143748558};\\\", \\\"{x:558,y:757,t:1528143748574};\\\", \\\"{x:545,y:753,t:1528143748592};\\\", \\\"{x:541,y:752,t:1528143748607};\\\", \\\"{x:538,y:751,t:1528143748625};\\\", \\\"{x:529,y:749,t:1528143748640};\\\", \\\"{x:516,y:741,t:1528143748657};\\\", \\\"{x:504,y:733,t:1528143748674};\\\", \\\"{x:500,y:730,t:1528143748691};\\\", \\\"{x:501,y:730,t:1528143749031};\\\", \\\"{x:544,y:716,t:1528143749042};\\\", \\\"{x:686,y:673,t:1528143749057};\\\", \\\"{x:822,y:628,t:1528143749074};\\\", \\\"{x:956,y:576,t:1528143749092};\\\", \\\"{x:1086,y:524,t:1528143749107};\\\", \\\"{x:1155,y:491,t:1528143749125};\\\", \\\"{x:1168,y:483,t:1528143749141};\\\", \\\"{x:1171,y:479,t:1528143749158};\\\", \\\"{x:1172,y:476,t:1528143749175};\\\", \\\"{x:1172,y:475,t:1528143749231};\\\", \\\"{x:1172,y:474,t:1528143749242};\\\", \\\"{x:1164,y:467,t:1528143749257};\\\", \\\"{x:1121,y:446,t:1528143749275};\\\", \\\"{x:1036,y:426,t:1528143749292};\\\", \\\"{x:935,y:410,t:1528143749308};\\\", \\\"{x:844,y:398,t:1528143749325};\\\", \\\"{x:794,y:392,t:1528143749342};\\\", \\\"{x:785,y:391,t:1528143749358};\\\" ] }, { \\\"rt\\\": 50876, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 12, \\\"time_elapsed\\\": 716571, \\\"internal_node_id\\\": \\\"0.0-6.0-2.0\\\", \\\"subject\\\": \\\"MKTF4\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"zulu\\\", \\\"condition\\\": \\\"211\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"duration+contained\\\", \\\"q\\\": 8, \\\"clicks\\\": 3, \\\"explicit\\\": 2, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XInside-YFull\\\", \\\"correct\\\": 1, \\\"orth_correct\\\": 0, \\\"answer\\\": [ \\\"G\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-G -C -C -O -B -B -G -E -C -N -N -F -J \\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:794,y:393,t:1528143756440};\\\", \\\"{x:827,y:412,t:1528143756448};\\\", \\\"{x:927,y:457,t:1528143756464};\\\", \\\"{x:1059,y:513,t:1528143756480};\\\", \\\"{x:1199,y:568,t:1528143756497};\\\", \\\"{x:1278,y:601,t:1528143756513};\\\", \\\"{x:1278,y:603,t:1528143756529};\\\", \\\"{x:1285,y:607,t:1528143756546};\\\", \\\"{x:1286,y:608,t:1528143756563};\\\", \\\"{x:1285,y:604,t:1528143756784};\\\", \\\"{x:1283,y:601,t:1528143756797};\\\", \\\"{x:1279,y:597,t:1528143756815};\\\", \\\"{x:1278,y:597,t:1528143756976};\\\", \\\"{x:1277,y:597,t:1528143756983};\\\", \\\"{x:1276,y:598,t:1528143756998};\\\", \\\"{x:1276,y:617,t:1528143757014};\\\", \\\"{x:1281,y:630,t:1528143757031};\\\", \\\"{x:1291,y:643,t:1528143757048};\\\", \\\"{x:1293,y:647,t:1528143757065};\\\", \\\"{x:1295,y:653,t:1528143757081};\\\", \\\"{x:1298,y:655,t:1528143757098};\\\", \\\"{x:1300,y:657,t:1528143757115};\\\", \\\"{x:1301,y:657,t:1528143757131};\\\", \\\"{x:1302,y:657,t:1528143757148};\\\", \\\"{x:1303,y:657,t:1528143757165};\\\", \\\"{x:1303,y:656,t:1528143757312};\\\", \\\"{x:1303,y:654,t:1528143757319};\\\", \\\"{x:1302,y:653,t:1528143757331};\\\", \\\"{x:1301,y:649,t:1528143757347};\\\", \\\"{x:1300,y:647,t:1528143757364};\\\", \\\"{x:1299,y:645,t:1528143757382};\\\", \\\"{x:1295,y:642,t:1528143757397};\\\", \\\"{x:1290,y:636,t:1528143757414};\\\", \\\"{x:1280,y:628,t:1528143757431};\\\", \\\"{x:1274,y:621,t:1528143757447};\\\", \\\"{x:1267,y:616,t:1528143757465};\\\", \\\"{x:1262,y:612,t:1528143757482};\\\", \\\"{x:1261,y:611,t:1528143757503};\\\", \\\"{x:1261,y:609,t:1528143757527};\\\", \\\"{x:1263,y:603,t:1528143757535};\\\", \\\"{x:1268,y:595,t:1528143757547};\\\", \\\"{x:1278,y:584,t:1528143757564};\\\", \\\"{x:1286,y:577,t:1528143757582};\\\", \\\"{x:1297,y:567,t:1528143757599};\\\", \\\"{x:1325,y:551,t:1528143757615};\\\", \\\"{x:1338,y:541,t:1528143757631};\\\", \\\"{x:1346,y:534,t:1528143757649};\\\", \\\"{x:1352,y:527,t:1528143757665};\\\", \\\"{x:1355,y:522,t:1528143757681};\\\", \\\"{x:1357,y:519,t:1528143757698};\\\", \\\"{x:1358,y:517,t:1528143757715};\\\", \\\"{x:1359,y:517,t:1528143757731};\\\", \\\"{x:1360,y:516,t:1528143757749};\\\", \\\"{x:1360,y:515,t:1528143757767};\\\", \\\"{x:1361,y:515,t:1528143757887};\\\", \\\"{x:1361,y:516,t:1528143757899};\\\", \\\"{x:1361,y:518,t:1528143757915};\\\", \\\"{x:1360,y:519,t:1528143757932};\\\", \\\"{x:1359,y:521,t:1528143757949};\\\", \\\"{x:1358,y:521,t:1528143758032};\\\", \\\"{x:1358,y:522,t:1528143759031};\\\", \\\"{x:1356,y:524,t:1528143759050};\\\", \\\"{x:1356,y:525,t:1528143759071};\\\", \\\"{x:1356,y:526,t:1528143759087};\\\", \\\"{x:1356,y:527,t:1528143759099};\\\", \\\"{x:1356,y:528,t:1528143767095};\\\", \\\"{x:1355,y:531,t:1528143767111};\\\", \\\"{x:1353,y:531,t:1528143767122};\\\", \\\"{x:1349,y:534,t:1528143767138};\\\", \\\"{x:1346,y:536,t:1528143767155};\\\", \\\"{x:1344,y:538,t:1528143767172};\\\", \\\"{x:1343,y:539,t:1528143767191};\\\", \\\"{x:1342,y:540,t:1528143767215};\\\", \\\"{x:1339,y:542,t:1528143767247};\\\", \\\"{x:1337,y:543,t:1528143767263};\\\", \\\"{x:1336,y:543,t:1528143767272};\\\", \\\"{x:1334,y:545,t:1528143767289};\\\", \\\"{x:1331,y:547,t:1528143767305};\\\", \\\"{x:1328,y:548,t:1528143767323};\\\", \\\"{x:1325,y:551,t:1528143767339};\\\", \\\"{x:1317,y:556,t:1528143767355};\\\", \\\"{x:1310,y:560,t:1528143767372};\\\", \\\"{x:1302,y:563,t:1528143767389};\\\", \\\"{x:1298,y:565,t:1528143767406};\\\", \\\"{x:1295,y:567,t:1528143767422};\\\", \\\"{x:1296,y:567,t:1528143770560};\\\", \\\"{x:1298,y:566,t:1528143770574};\\\", \\\"{x:1308,y:563,t:1528143770592};\\\", \\\"{x:1315,y:563,t:1528143770608};\\\", \\\"{x:1322,y:562,t:1528143770625};\\\", \\\"{x:1326,y:562,t:1528143770641};\\\", \\\"{x:1327,y:562,t:1528143770663};\\\", \\\"{x:1329,y:561,t:1528143770735};\\\", \\\"{x:1330,y:561,t:1528143770751};\\\", \\\"{x:1331,y:561,t:1528143770759};\\\", \\\"{x:1333,y:561,t:1528143770774};\\\", \\\"{x:1336,y:560,t:1528143770791};\\\", \\\"{x:1341,y:559,t:1528143770809};\\\", \\\"{x:1346,y:556,t:1528143770824};\\\", \\\"{x:1351,y:556,t:1528143770841};\\\", \\\"{x:1356,y:553,t:1528143770859};\\\", \\\"{x:1360,y:553,t:1528143770874};\\\", \\\"{x:1363,y:552,t:1528143770891};\\\", \\\"{x:1366,y:551,t:1528143770908};\\\", \\\"{x:1369,y:551,t:1528143770924};\\\", \\\"{x:1369,y:550,t:1528143770941};\\\", \\\"{x:1370,y:550,t:1528143770983};\\\", \\\"{x:1371,y:550,t:1528143770991};\\\", \\\"{x:1376,y:550,t:1528143771008};\\\", \\\"{x:1379,y:551,t:1528143771025};\\\", \\\"{x:1383,y:551,t:1528143771041};\\\", \\\"{x:1385,y:551,t:1528143771059};\\\", \\\"{x:1389,y:553,t:1528143771075};\\\", \\\"{x:1392,y:553,t:1528143771091};\\\", \\\"{x:1397,y:555,t:1528143771108};\\\", \\\"{x:1398,y:555,t:1528143771125};\\\", \\\"{x:1399,y:555,t:1528143771141};\\\", \\\"{x:1401,y:556,t:1528143771158};\\\", \\\"{x:1403,y:557,t:1528143771183};\\\", \\\"{x:1405,y:557,t:1528143771191};\\\", \\\"{x:1407,y:558,t:1528143771208};\\\", \\\"{x:1411,y:559,t:1528143771228};\\\", \\\"{x:1412,y:560,t:1528143771241};\\\", \\\"{x:1413,y:560,t:1528143771257};\\\", \\\"{x:1414,y:561,t:1528143771275};\\\", \\\"{x:1412,y:561,t:1528143773687};\\\", \\\"{x:1406,y:562,t:1528143773697};\\\", \\\"{x:1386,y:565,t:1528143773711};\\\", \\\"{x:1325,y:574,t:1528143773726};\\\", \\\"{x:1179,y:595,t:1528143773742};\\\", \\\"{x:1083,y:603,t:1528143773761};\\\", \\\"{x:1013,y:603,t:1528143773776};\\\", \\\"{x:976,y:603,t:1528143773794};\\\", \\\"{x:958,y:603,t:1528143773810};\\\", \\\"{x:941,y:602,t:1528143773828};\\\", \\\"{x:929,y:601,t:1528143773843};\\\", \\\"{x:919,y:599,t:1528143773860};\\\", \\\"{x:915,y:598,t:1528143773878};\\\", \\\"{x:915,y:597,t:1528143773966};\\\", \\\"{x:918,y:595,t:1528143773978};\\\", \\\"{x:919,y:594,t:1528143773995};\\\", \\\"{x:919,y:593,t:1528143774012};\\\", \\\"{x:919,y:592,t:1528143774029};\\\", \\\"{x:919,y:591,t:1528143774046};\\\", \\\"{x:919,y:589,t:1528143774061};\\\", \\\"{x:912,y:584,t:1528143774077};\\\", \\\"{x:896,y:579,t:1528143774095};\\\", \\\"{x:885,y:575,t:1528143774112};\\\", \\\"{x:874,y:572,t:1528143774128};\\\", \\\"{x:866,y:570,t:1528143774146};\\\", \\\"{x:862,y:569,t:1528143774162};\\\", \\\"{x:856,y:566,t:1528143774179};\\\", \\\"{x:853,y:564,t:1528143774194};\\\", \\\"{x:850,y:562,t:1528143774212};\\\", \\\"{x:847,y:559,t:1528143774228};\\\", \\\"{x:843,y:556,t:1528143774244};\\\", \\\"{x:839,y:553,t:1528143774262};\\\", \\\"{x:837,y:550,t:1528143774279};\\\", \\\"{x:836,y:549,t:1528143774294};\\\", \\\"{x:834,y:544,t:1528143774312};\\\", \\\"{x:833,y:543,t:1528143774328};\\\", \\\"{x:833,y:542,t:1528143774345};\\\", \\\"{x:833,y:541,t:1528143774361};\\\", \\\"{x:836,y:541,t:1528143774767};\\\", \\\"{x:867,y:541,t:1528143774779};\\\", \\\"{x:956,y:541,t:1528143774796};\\\", \\\"{x:1037,y:541,t:1528143774812};\\\", \\\"{x:1125,y:541,t:1528143774829};\\\", \\\"{x:1217,y:541,t:1528143774846};\\\", \\\"{x:1298,y:541,t:1528143774863};\\\", \\\"{x:1358,y:549,t:1528143774879};\\\", \\\"{x:1373,y:551,t:1528143774897};\\\", \\\"{x:1374,y:551,t:1528143774912};\\\", \\\"{x:1375,y:552,t:1528143774991};\\\", \\\"{x:1375,y:553,t:1528143774999};\\\", \\\"{x:1375,y:554,t:1528143775015};\\\", \\\"{x:1375,y:556,t:1528143775029};\\\", \\\"{x:1375,y:558,t:1528143775047};\\\", \\\"{x:1375,y:560,t:1528143775062};\\\", \\\"{x:1374,y:561,t:1528143775079};\\\", \\\"{x:1374,y:562,t:1528143775176};\\\", \\\"{x:1374,y:563,t:1528143775231};\\\", \\\"{x:1374,y:564,t:1528143775271};\\\", \\\"{x:1374,y:565,t:1528143775311};\\\", \\\"{x:1374,y:567,t:1528143776263};\\\", \\\"{x:1383,y:579,t:1528143776280};\\\", \\\"{x:1392,y:588,t:1528143776297};\\\", \\\"{x:1402,y:595,t:1528143776312};\\\", \\\"{x:1406,y:600,t:1528143776330};\\\", \\\"{x:1409,y:603,t:1528143776346};\\\", \\\"{x:1410,y:604,t:1528143776362};\\\", \\\"{x:1412,y:606,t:1528143776379};\\\", \\\"{x:1416,y:606,t:1528143776397};\\\", \\\"{x:1420,y:608,t:1528143776413};\\\", \\\"{x:1423,y:609,t:1528143776429};\\\", \\\"{x:1425,y:610,t:1528143776446};\\\", \\\"{x:1428,y:611,t:1528143776462};\\\", \\\"{x:1429,y:612,t:1528143776511};\\\", \\\"{x:1431,y:614,t:1528143776518};\\\", \\\"{x:1432,y:615,t:1528143776530};\\\", \\\"{x:1437,y:618,t:1528143776547};\\\", \\\"{x:1442,y:620,t:1528143776564};\\\", \\\"{x:1444,y:621,t:1528143776580};\\\", \\\"{x:1445,y:621,t:1528143776597};\\\", \\\"{x:1446,y:621,t:1528143776655};\\\", \\\"{x:1447,y:622,t:1528143776663};\\\", \\\"{x:1448,y:622,t:1528143776680};\\\", \\\"{x:1449,y:623,t:1528143777759};\\\", \\\"{x:1451,y:625,t:1528143777768};\\\", \\\"{x:1453,y:627,t:1528143777796};\\\", \\\"{x:1455,y:628,t:1528143777814};\\\", \\\"{x:1456,y:628,t:1528143777831};\\\", \\\"{x:1459,y:630,t:1528143777847};\\\", \\\"{x:1464,y:632,t:1528143777863};\\\", \\\"{x:1470,y:632,t:1528143777881};\\\", \\\"{x:1478,y:635,t:1528143777897};\\\", \\\"{x:1484,y:637,t:1528143777913};\\\", \\\"{x:1491,y:637,t:1528143777931};\\\", \\\"{x:1499,y:639,t:1528143777948};\\\", \\\"{x:1507,y:640,t:1528143777964};\\\", \\\"{x:1517,y:641,t:1528143777981};\\\", \\\"{x:1526,y:643,t:1528143777998};\\\", \\\"{x:1533,y:643,t:1528143778014};\\\", \\\"{x:1540,y:644,t:1528143778031};\\\", \\\"{x:1545,y:645,t:1528143778048};\\\", \\\"{x:1552,y:647,t:1528143778064};\\\", \\\"{x:1558,y:647,t:1528143778082};\\\", \\\"{x:1561,y:647,t:1528143778099};\\\", \\\"{x:1565,y:647,t:1528143778115};\\\", \\\"{x:1567,y:647,t:1528143778132};\\\", \\\"{x:1569,y:644,t:1528143778149};\\\", \\\"{x:1571,y:644,t:1528143778164};\\\", \\\"{x:1573,y:643,t:1528143778181};\\\", \\\"{x:1574,y:643,t:1528143778199};\\\", \\\"{x:1576,y:642,t:1528143778215};\\\", \\\"{x:1577,y:641,t:1528143778232};\\\", \\\"{x:1578,y:641,t:1528143778249};\\\", \\\"{x:1578,y:640,t:1528143778328};\\\", \\\"{x:1577,y:642,t:1528143778823};\\\", \\\"{x:1576,y:642,t:1528143778831};\\\", \\\"{x:1576,y:644,t:1528143778848};\\\", \\\"{x:1575,y:645,t:1528143778871};\\\", \\\"{x:1574,y:646,t:1528143778895};\\\", \\\"{x:1573,y:648,t:1528143778903};\\\", \\\"{x:1572,y:649,t:1528143778916};\\\", \\\"{x:1568,y:655,t:1528143778933};\\\", \\\"{x:1560,y:663,t:1528143778949};\\\", \\\"{x:1549,y:673,t:1528143778965};\\\", \\\"{x:1543,y:681,t:1528143778982};\\\", \\\"{x:1534,y:695,t:1528143778998};\\\", \\\"{x:1530,y:704,t:1528143779016};\\\", \\\"{x:1527,y:710,t:1528143779032};\\\", \\\"{x:1524,y:716,t:1528143779049};\\\", \\\"{x:1523,y:719,t:1528143779066};\\\", \\\"{x:1523,y:721,t:1528143779083};\\\", \\\"{x:1523,y:726,t:1528143779099};\\\", \\\"{x:1522,y:732,t:1528143779115};\\\", \\\"{x:1519,y:737,t:1528143779132};\\\", \\\"{x:1513,y:744,t:1528143779149};\\\", \\\"{x:1509,y:750,t:1528143779166};\\\", \\\"{x:1503,y:757,t:1528143779182};\\\", \\\"{x:1500,y:762,t:1528143779199};\\\", \\\"{x:1489,y:778,t:1528143779216};\\\", \\\"{x:1478,y:790,t:1528143779232};\\\", \\\"{x:1465,y:808,t:1528143779249};\\\", \\\"{x:1454,y:822,t:1528143779266};\\\", \\\"{x:1446,y:835,t:1528143779283};\\\", \\\"{x:1442,y:846,t:1528143779299};\\\", \\\"{x:1439,y:851,t:1528143779315};\\\", \\\"{x:1434,y:858,t:1528143779332};\\\", \\\"{x:1428,y:863,t:1528143779349};\\\", \\\"{x:1422,y:868,t:1528143779366};\\\", \\\"{x:1420,y:869,t:1528143779382};\\\", \\\"{x:1420,y:870,t:1528143779398};\\\", \\\"{x:1419,y:870,t:1528143779775};\\\", \\\"{x:1417,y:870,t:1528143779783};\\\", \\\"{x:1416,y:869,t:1528143779807};\\\", \\\"{x:1413,y:868,t:1528143779815};\\\", \\\"{x:1413,y:867,t:1528143779833};\\\", \\\"{x:1412,y:867,t:1528143779850};\\\", \\\"{x:1411,y:866,t:1528143779866};\\\", \\\"{x:1410,y:864,t:1528143779882};\\\", \\\"{x:1409,y:863,t:1528143779900};\\\", \\\"{x:1407,y:860,t:1528143779915};\\\", \\\"{x:1404,y:853,t:1528143779933};\\\", \\\"{x:1401,y:848,t:1528143779949};\\\", \\\"{x:1399,y:841,t:1528143779966};\\\", \\\"{x:1398,y:838,t:1528143779982};\\\", \\\"{x:1396,y:835,t:1528143779999};\\\", \\\"{x:1395,y:831,t:1528143780016};\\\", \\\"{x:1394,y:829,t:1528143780032};\\\", \\\"{x:1392,y:827,t:1528143780049};\\\", \\\"{x:1390,y:820,t:1528143780066};\\\", \\\"{x:1388,y:816,t:1528143780082};\\\", \\\"{x:1385,y:811,t:1528143780099};\\\", \\\"{x:1384,y:808,t:1528143780116};\\\", \\\"{x:1384,y:807,t:1528143780132};\\\", \\\"{x:1383,y:804,t:1528143780149};\\\", \\\"{x:1381,y:802,t:1528143780165};\\\", \\\"{x:1380,y:798,t:1528143780182};\\\", \\\"{x:1378,y:796,t:1528143780198};\\\", \\\"{x:1376,y:791,t:1528143780216};\\\", \\\"{x:1375,y:789,t:1528143780231};\\\", \\\"{x:1372,y:786,t:1528143780249};\\\", \\\"{x:1371,y:783,t:1528143780266};\\\", \\\"{x:1370,y:783,t:1528143780282};\\\", \\\"{x:1370,y:782,t:1528143780302};\\\", \\\"{x:1369,y:781,t:1528143780318};\\\", \\\"{x:1368,y:780,t:1528143780368};\\\", \\\"{x:1367,y:780,t:1528143780414};\\\", \\\"{x:1366,y:779,t:1528143780447};\\\", \\\"{x:1365,y:779,t:1528143780510};\\\", \\\"{x:1364,y:778,t:1528143780534};\\\", \\\"{x:1363,y:778,t:1528143780549};\\\", \\\"{x:1363,y:777,t:1528143780566};\\\", \\\"{x:1362,y:777,t:1528143780582};\\\", \\\"{x:1361,y:776,t:1528143780614};\\\", \\\"{x:1360,y:775,t:1528143780630};\\\", \\\"{x:1360,y:774,t:1528143780687};\\\", \\\"{x:1359,y:773,t:1528143780702};\\\", \\\"{x:1358,y:773,t:1528143780718};\\\", \\\"{x:1357,y:772,t:1528143780733};\\\", \\\"{x:1356,y:772,t:1528143780749};\\\", \\\"{x:1354,y:771,t:1528143780766};\\\", \\\"{x:1353,y:771,t:1528143780782};\\\", \\\"{x:1352,y:771,t:1528143780799};\\\", \\\"{x:1351,y:771,t:1528143780855};\\\", \\\"{x:1351,y:770,t:1528143780896};\\\", \\\"{x:1351,y:769,t:1528143780934};\\\", \\\"{x:1350,y:769,t:1528143780950};\\\", \\\"{x:1350,y:768,t:1528143780966};\\\", \\\"{x:1350,y:766,t:1528143780983};\\\", \\\"{x:1350,y:763,t:1528143780999};\\\", \\\"{x:1350,y:760,t:1528143781016};\\\", \\\"{x:1350,y:758,t:1528143781033};\\\", \\\"{x:1350,y:755,t:1528143781049};\\\", \\\"{x:1350,y:752,t:1528143781066};\\\", \\\"{x:1351,y:749,t:1528143781084};\\\", \\\"{x:1352,y:748,t:1528143781100};\\\", \\\"{x:1353,y:747,t:1528143781117};\\\", \\\"{x:1357,y:750,t:1528143781159};\\\", \\\"{x:1367,y:763,t:1528143781167};\\\", \\\"{x:1380,y:783,t:1528143781183};\\\", \\\"{x:1394,y:808,t:1528143781201};\\\", \\\"{x:1409,y:834,t:1528143781216};\\\", \\\"{x:1418,y:848,t:1528143781233};\\\", \\\"{x:1423,y:855,t:1528143781250};\\\", \\\"{x:1427,y:862,t:1528143781267};\\\", \\\"{x:1428,y:864,t:1528143781283};\\\", \\\"{x:1429,y:864,t:1528143781300};\\\", \\\"{x:1429,y:865,t:1528143781360};\\\", \\\"{x:1430,y:865,t:1528143781367};\\\", \\\"{x:1432,y:865,t:1528143781383};\\\", \\\"{x:1435,y:868,t:1528143781400};\\\", \\\"{x:1443,y:868,t:1528143781416};\\\", \\\"{x:1454,y:869,t:1528143781433};\\\", \\\"{x:1473,y:873,t:1528143781450};\\\", \\\"{x:1493,y:873,t:1528143781466};\\\", \\\"{x:1510,y:873,t:1528143781483};\\\", \\\"{x:1518,y:873,t:1528143781500};\\\", \\\"{x:1520,y:873,t:1528143781516};\\\", \\\"{x:1521,y:873,t:1528143781599};\\\", \\\"{x:1517,y:868,t:1528143781618};\\\", \\\"{x:1499,y:857,t:1528143781633};\\\", \\\"{x:1472,y:837,t:1528143781650};\\\", \\\"{x:1441,y:815,t:1528143781667};\\\", \\\"{x:1419,y:802,t:1528143781684};\\\", \\\"{x:1407,y:793,t:1528143781701};\\\", \\\"{x:1400,y:786,t:1528143781717};\\\", \\\"{x:1394,y:777,t:1528143781734};\\\", \\\"{x:1384,y:762,t:1528143781751};\\\", \\\"{x:1378,y:752,t:1528143781766};\\\", \\\"{x:1371,y:745,t:1528143781783};\\\", \\\"{x:1366,y:741,t:1528143781800};\\\", \\\"{x:1363,y:739,t:1528143781817};\\\", \\\"{x:1360,y:737,t:1528143781832};\\\", \\\"{x:1359,y:737,t:1528143781850};\\\", \\\"{x:1357,y:737,t:1528143781867};\\\", \\\"{x:1353,y:737,t:1528143781883};\\\", \\\"{x:1344,y:737,t:1528143781900};\\\", \\\"{x:1331,y:745,t:1528143781917};\\\", \\\"{x:1317,y:754,t:1528143781933};\\\", \\\"{x:1301,y:773,t:1528143781951};\\\", \\\"{x:1297,y:789,t:1528143781966};\\\", \\\"{x:1297,y:803,t:1528143781983};\\\", \\\"{x:1304,y:819,t:1528143782000};\\\", \\\"{x:1319,y:833,t:1528143782017};\\\", \\\"{x:1332,y:843,t:1528143782034};\\\", \\\"{x:1346,y:852,t:1528143782050};\\\", \\\"{x:1363,y:860,t:1528143782067};\\\", \\\"{x:1377,y:866,t:1528143782083};\\\", \\\"{x:1389,y:871,t:1528143782100};\\\", \\\"{x:1402,y:876,t:1528143782118};\\\", \\\"{x:1407,y:876,t:1528143782135};\\\", \\\"{x:1408,y:876,t:1528143782151};\\\", \\\"{x:1410,y:876,t:1528143782167};\\\", \\\"{x:1412,y:869,t:1528143782184};\\\", \\\"{x:1416,y:854,t:1528143782200};\\\", \\\"{x:1422,y:833,t:1528143782217};\\\", \\\"{x:1426,y:816,t:1528143782234};\\\", \\\"{x:1426,y:801,t:1528143782250};\\\", \\\"{x:1425,y:785,t:1528143782268};\\\", \\\"{x:1417,y:769,t:1528143782285};\\\", \\\"{x:1408,y:756,t:1528143782300};\\\", \\\"{x:1402,y:746,t:1528143782318};\\\", \\\"{x:1394,y:737,t:1528143782335};\\\", \\\"{x:1390,y:733,t:1528143782351};\\\", \\\"{x:1386,y:729,t:1528143782368};\\\", \\\"{x:1382,y:726,t:1528143782385};\\\", \\\"{x:1378,y:724,t:1528143782400};\\\", \\\"{x:1373,y:721,t:1528143782417};\\\", \\\"{x:1371,y:719,t:1528143782434};\\\", \\\"{x:1367,y:716,t:1528143782451};\\\", \\\"{x:1363,y:713,t:1528143782467};\\\", \\\"{x:1360,y:712,t:1528143782484};\\\", \\\"{x:1358,y:710,t:1528143782500};\\\", \\\"{x:1357,y:710,t:1528143782517};\\\", \\\"{x:1356,y:709,t:1528143782534};\\\", \\\"{x:1355,y:709,t:1528143782550};\\\", \\\"{x:1354,y:708,t:1528143782567};\\\", \\\"{x:1353,y:708,t:1528143782750};\\\", \\\"{x:1351,y:707,t:1528143782766};\\\", \\\"{x:1348,y:705,t:1528143782784};\\\", \\\"{x:1347,y:704,t:1528143782801};\\\", \\\"{x:1346,y:703,t:1528143782817};\\\", \\\"{x:1345,y:702,t:1528143782834};\\\", \\\"{x:1344,y:702,t:1528143783632};\\\", \\\"{x:1343,y:702,t:1528143783671};\\\", \\\"{x:1341,y:702,t:1528143783686};\\\", \\\"{x:1339,y:705,t:1528143783702};\\\", \\\"{x:1334,y:714,t:1528143783719};\\\", \\\"{x:1330,y:719,t:1528143783735};\\\", \\\"{x:1327,y:725,t:1528143783751};\\\", \\\"{x:1324,y:731,t:1528143783769};\\\", \\\"{x:1321,y:736,t:1528143783786};\\\", \\\"{x:1319,y:740,t:1528143783802};\\\", \\\"{x:1318,y:742,t:1528143783819};\\\", \\\"{x:1317,y:745,t:1528143783835};\\\", \\\"{x:1317,y:750,t:1528143783852};\\\", \\\"{x:1314,y:754,t:1528143783869};\\\", \\\"{x:1313,y:757,t:1528143783886};\\\", \\\"{x:1311,y:761,t:1528143783901};\\\", \\\"{x:1310,y:762,t:1528143783919};\\\", \\\"{x:1310,y:763,t:1528143783936};\\\", \\\"{x:1309,y:764,t:1528143783959};\\\", \\\"{x:1309,y:765,t:1528143783969};\\\", \\\"{x:1308,y:766,t:1528143783985};\\\", \\\"{x:1306,y:768,t:1528143784001};\\\", \\\"{x:1304,y:770,t:1528143784018};\\\", \\\"{x:1301,y:772,t:1528143784035};\\\", \\\"{x:1298,y:774,t:1528143784052};\\\", \\\"{x:1295,y:777,t:1528143784068};\\\", \\\"{x:1287,y:784,t:1528143784086};\\\", \\\"{x:1277,y:794,t:1528143784102};\\\", \\\"{x:1265,y:806,t:1528143784119};\\\", \\\"{x:1262,y:809,t:1528143784136};\\\", \\\"{x:1258,y:811,t:1528143784151};\\\", \\\"{x:1255,y:813,t:1528143784169};\\\", \\\"{x:1253,y:814,t:1528143784186};\\\", \\\"{x:1251,y:814,t:1528143784202};\\\", \\\"{x:1246,y:816,t:1528143784218};\\\", \\\"{x:1239,y:817,t:1528143784235};\\\", \\\"{x:1225,y:818,t:1528143784252};\\\", \\\"{x:1209,y:818,t:1528143784268};\\\", \\\"{x:1196,y:818,t:1528143784285};\\\", \\\"{x:1193,y:818,t:1528143784302};\\\", \\\"{x:1191,y:817,t:1528143784318};\\\", \\\"{x:1190,y:814,t:1528143784335};\\\", \\\"{x:1188,y:811,t:1528143784352};\\\", \\\"{x:1187,y:803,t:1528143784368};\\\", \\\"{x:1187,y:798,t:1528143784386};\\\", \\\"{x:1190,y:789,t:1528143784402};\\\", \\\"{x:1200,y:779,t:1528143784418};\\\", \\\"{x:1216,y:767,t:1528143784435};\\\", \\\"{x:1232,y:758,t:1528143784452};\\\", \\\"{x:1245,y:750,t:1528143784468};\\\", \\\"{x:1254,y:744,t:1528143784485};\\\", \\\"{x:1262,y:736,t:1528143784502};\\\", \\\"{x:1267,y:730,t:1528143784518};\\\", \\\"{x:1270,y:722,t:1528143784535};\\\", \\\"{x:1274,y:714,t:1528143784552};\\\", \\\"{x:1277,y:708,t:1528143784568};\\\", \\\"{x:1280,y:697,t:1528143784585};\\\", \\\"{x:1282,y:686,t:1528143784602};\\\", \\\"{x:1283,y:677,t:1528143784618};\\\", \\\"{x:1284,y:669,t:1528143784635};\\\", \\\"{x:1284,y:661,t:1528143784653};\\\", \\\"{x:1284,y:654,t:1528143784668};\\\", \\\"{x:1285,y:649,t:1528143784686};\\\", \\\"{x:1286,y:647,t:1528143784702};\\\", \\\"{x:1286,y:646,t:1528143784718};\\\", \\\"{x:1286,y:642,t:1528143784735};\\\", \\\"{x:1287,y:637,t:1528143784752};\\\", \\\"{x:1288,y:630,t:1528143784769};\\\", \\\"{x:1290,y:625,t:1528143784785};\\\", \\\"{x:1290,y:622,t:1528143784802};\\\", \\\"{x:1290,y:620,t:1528143784819};\\\", \\\"{x:1291,y:619,t:1528143784835};\\\", \\\"{x:1292,y:618,t:1528143784852};\\\", \\\"{x:1292,y:617,t:1528143784869};\\\", \\\"{x:1293,y:616,t:1528143784982};\\\", \\\"{x:1289,y:611,t:1528143786144};\\\", \\\"{x:1289,y:609,t:1528143786154};\\\", \\\"{x:1287,y:604,t:1528143786170};\\\", \\\"{x:1286,y:601,t:1528143786187};\\\", \\\"{x:1285,y:597,t:1528143786204};\\\", \\\"{x:1284,y:593,t:1528143786220};\\\", \\\"{x:1283,y:591,t:1528143786237};\\\", \\\"{x:1282,y:588,t:1528143786254};\\\", \\\"{x:1282,y:587,t:1528143786270};\\\", \\\"{x:1282,y:586,t:1528143786287};\\\", \\\"{x:1281,y:584,t:1528143786304};\\\", \\\"{x:1279,y:584,t:1528143786543};\\\", \\\"{x:1273,y:584,t:1528143786553};\\\", \\\"{x:1246,y:584,t:1528143786571};\\\", \\\"{x:1200,y:584,t:1528143786587};\\\", \\\"{x:1125,y:584,t:1528143786603};\\\", \\\"{x:1043,y:582,t:1528143786621};\\\", \\\"{x:973,y:569,t:1528143786636};\\\", \\\"{x:915,y:561,t:1528143786653};\\\", \\\"{x:858,y:551,t:1528143786672};\\\", \\\"{x:848,y:550,t:1528143786687};\\\", \\\"{x:847,y:550,t:1528143786704};\\\", \\\"{x:844,y:550,t:1528143786737};\\\", \\\"{x:829,y:554,t:1528143786753};\\\", \\\"{x:794,y:563,t:1528143786771};\\\", \\\"{x:733,y:576,t:1528143786788};\\\", \\\"{x:642,y:588,t:1528143786807};\\\", \\\"{x:533,y:588,t:1528143786822};\\\", \\\"{x:504,y:588,t:1528143786838};\\\", \\\"{x:495,y:588,t:1528143786855};\\\", \\\"{x:494,y:588,t:1528143786873};\\\", \\\"{x:493,y:587,t:1528143786894};\\\", \\\"{x:492,y:587,t:1528143786910};\\\", \\\"{x:492,y:584,t:1528143786926};\\\", \\\"{x:492,y:580,t:1528143786938};\\\", \\\"{x:502,y:570,t:1528143786956};\\\", \\\"{x:527,y:549,t:1528143786973};\\\", \\\"{x:586,y:517,t:1528143786988};\\\", \\\"{x:634,y:502,t:1528143787006};\\\", \\\"{x:662,y:494,t:1528143787022};\\\", \\\"{x:665,y:493,t:1528143787038};\\\", \\\"{x:666,y:493,t:1528143787070};\\\", \\\"{x:667,y:494,t:1528143787078};\\\", \\\"{x:670,y:500,t:1528143787088};\\\", \\\"{x:677,y:508,t:1528143787106};\\\", \\\"{x:680,y:512,t:1528143787121};\\\", \\\"{x:681,y:513,t:1528143787138};\\\", \\\"{x:681,y:514,t:1528143787156};\\\", \\\"{x:675,y:514,t:1528143787238};\\\", \\\"{x:664,y:511,t:1528143787253};\\\", \\\"{x:656,y:508,t:1528143787271};\\\", \\\"{x:651,y:506,t:1528143787289};\\\", \\\"{x:647,y:504,t:1528143787305};\\\", \\\"{x:645,y:504,t:1528143787322};\\\", \\\"{x:644,y:503,t:1528143787338};\\\", \\\"{x:641,y:502,t:1528143787354};\\\", \\\"{x:638,y:500,t:1528143787372};\\\", \\\"{x:636,y:499,t:1528143787389};\\\", \\\"{x:634,y:499,t:1528143787405};\\\", \\\"{x:633,y:499,t:1528143787422};\\\", \\\"{x:632,y:499,t:1528143787471};\\\", \\\"{x:631,y:499,t:1528143787479};\\\", \\\"{x:630,y:499,t:1528143787511};\\\", \\\"{x:629,y:499,t:1528143787527};\\\", \\\"{x:635,y:499,t:1528143787814};\\\", \\\"{x:644,y:499,t:1528143787823};\\\", \\\"{x:745,y:505,t:1528143787841};\\\", \\\"{x:885,y:518,t:1528143787857};\\\", \\\"{x:1050,y:531,t:1528143787872};\\\", \\\"{x:1224,y:537,t:1528143787890};\\\", \\\"{x:1346,y:537,t:1528143787906};\\\", \\\"{x:1377,y:537,t:1528143787922};\\\", \\\"{x:1381,y:537,t:1528143787940};\\\", \\\"{x:1378,y:537,t:1528143788047};\\\", \\\"{x:1363,y:538,t:1528143788057};\\\", \\\"{x:1314,y:538,t:1528143788073};\\\", \\\"{x:1258,y:538,t:1528143788090};\\\", \\\"{x:1228,y:538,t:1528143788107};\\\", \\\"{x:1220,y:538,t:1528143788123};\\\", \\\"{x:1222,y:538,t:1528143788240};\\\", \\\"{x:1230,y:542,t:1528143788256};\\\", \\\"{x:1242,y:548,t:1528143788273};\\\", \\\"{x:1253,y:553,t:1528143788290};\\\", \\\"{x:1258,y:554,t:1528143788306};\\\", \\\"{x:1259,y:555,t:1528143788324};\\\", \\\"{x:1260,y:555,t:1528143788503};\\\", \\\"{x:1260,y:557,t:1528143788519};\\\", \\\"{x:1259,y:558,t:1528143788527};\\\", \\\"{x:1258,y:559,t:1528143788540};\\\", \\\"{x:1249,y:574,t:1528143788556};\\\", \\\"{x:1237,y:591,t:1528143788574};\\\", \\\"{x:1217,y:619,t:1528143788590};\\\", \\\"{x:1179,y:669,t:1528143788606};\\\", \\\"{x:1164,y:689,t:1528143788624};\\\", \\\"{x:1157,y:703,t:1528143788640};\\\", \\\"{x:1155,y:708,t:1528143788657};\\\", \\\"{x:1155,y:710,t:1528143788674};\\\", \\\"{x:1155,y:712,t:1528143788691};\\\", \\\"{x:1156,y:712,t:1528143788707};\\\", \\\"{x:1159,y:711,t:1528143788724};\\\", \\\"{x:1166,y:699,t:1528143788741};\\\", \\\"{x:1177,y:684,t:1528143788757};\\\", \\\"{x:1192,y:666,t:1528143788774};\\\", \\\"{x:1224,y:632,t:1528143788791};\\\", \\\"{x:1244,y:613,t:1528143788807};\\\", \\\"{x:1258,y:594,t:1528143788824};\\\", \\\"{x:1267,y:582,t:1528143788841};\\\", \\\"{x:1271,y:577,t:1528143788857};\\\", \\\"{x:1271,y:576,t:1528143788887};\\\", \\\"{x:1273,y:576,t:1528143788927};\\\", \\\"{x:1274,y:576,t:1528143788943};\\\", \\\"{x:1276,y:576,t:1528143788958};\\\", \\\"{x:1277,y:576,t:1528143789247};\\\", \\\"{x:1277,y:577,t:1528143789271};\\\", \\\"{x:1278,y:579,t:1528143789287};\\\", \\\"{x:1278,y:580,t:1528143789303};\\\", \\\"{x:1278,y:581,t:1528143789319};\\\", \\\"{x:1278,y:582,t:1528143789360};\\\", \\\"{x:1279,y:583,t:1528143789439};\\\", \\\"{x:1280,y:584,t:1528143789568};\\\", \\\"{x:1281,y:585,t:1528143789662};\\\", \\\"{x:1282,y:587,t:1528143789677};\\\", \\\"{x:1283,y:587,t:1528143789691};\\\", \\\"{x:1289,y:591,t:1528143789708};\\\", \\\"{x:1300,y:600,t:1528143789725};\\\", \\\"{x:1314,y:613,t:1528143789740};\\\", \\\"{x:1333,y:635,t:1528143789757};\\\", \\\"{x:1372,y:701,t:1528143789774};\\\", \\\"{x:1384,y:740,t:1528143789790};\\\", \\\"{x:1391,y:768,t:1528143789807};\\\", \\\"{x:1392,y:773,t:1528143789824};\\\", \\\"{x:1394,y:776,t:1528143789841};\\\", \\\"{x:1396,y:776,t:1528143789858};\\\", \\\"{x:1393,y:773,t:1528143789943};\\\", \\\"{x:1389,y:768,t:1528143789958};\\\", \\\"{x:1364,y:734,t:1528143789974};\\\", \\\"{x:1330,y:688,t:1528143789990};\\\", \\\"{x:1279,y:628,t:1528143790007};\\\", \\\"{x:1224,y:579,t:1528143790024};\\\", \\\"{x:1157,y:535,t:1528143790040};\\\", \\\"{x:1070,y:504,t:1528143790058};\\\", \\\"{x:961,y:486,t:1528143790075};\\\", \\\"{x:832,y:476,t:1528143790090};\\\", \\\"{x:696,y:476,t:1528143790108};\\\", \\\"{x:583,y:476,t:1528143790125};\\\", \\\"{x:550,y:476,t:1528143790141};\\\", \\\"{x:547,y:477,t:1528143790157};\\\", \\\"{x:549,y:476,t:1528143790198};\\\", \\\"{x:553,y:475,t:1528143790214};\\\", \\\"{x:554,y:474,t:1528143790224};\\\", \\\"{x:561,y:471,t:1528143790240};\\\", \\\"{x:566,y:471,t:1528143790257};\\\", \\\"{x:579,y:473,t:1528143790274};\\\", \\\"{x:595,y:477,t:1528143790292};\\\", \\\"{x:613,y:485,t:1528143790307};\\\", \\\"{x:633,y:495,t:1528143790325};\\\", \\\"{x:643,y:501,t:1528143790341};\\\", \\\"{x:647,y:504,t:1528143790357};\\\", \\\"{x:648,y:504,t:1528143790374};\\\", \\\"{x:649,y:504,t:1528143790438};\\\", \\\"{x:647,y:505,t:1528143790462};\\\", \\\"{x:644,y:505,t:1528143790474};\\\", \\\"{x:634,y:505,t:1528143790492};\\\", \\\"{x:627,y:505,t:1528143790508};\\\", \\\"{x:619,y:502,t:1528143790525};\\\", \\\"{x:614,y:501,t:1528143790542};\\\", \\\"{x:613,y:499,t:1528143790557};\\\", \\\"{x:612,y:499,t:1528143790590};\\\", \\\"{x:611,y:499,t:1528143790598};\\\", \\\"{x:610,y:498,t:1528143790607};\\\", \\\"{x:609,y:498,t:1528143790638};\\\", \\\"{x:608,y:498,t:1528143790654};\\\", \\\"{x:625,y:498,t:1528143790894};\\\", \\\"{x:669,y:505,t:1528143790908};\\\", \\\"{x:804,y:524,t:1528143790926};\\\", \\\"{x:970,y:526,t:1528143790942};\\\", \\\"{x:1201,y:532,t:1528143790958};\\\", \\\"{x:1311,y:542,t:1528143790975};\\\", \\\"{x:1378,y:554,t:1528143790991};\\\", \\\"{x:1416,y:567,t:1528143791008};\\\", \\\"{x:1437,y:576,t:1528143791026};\\\", \\\"{x:1449,y:581,t:1528143791041};\\\", \\\"{x:1450,y:582,t:1528143791150};\\\", \\\"{x:1449,y:585,t:1528143791158};\\\", \\\"{x:1426,y:587,t:1528143791176};\\\", \\\"{x:1387,y:587,t:1528143791192};\\\", \\\"{x:1342,y:587,t:1528143791209};\\\", \\\"{x:1305,y:583,t:1528143791226};\\\", \\\"{x:1289,y:580,t:1528143791241};\\\", \\\"{x:1282,y:578,t:1528143791259};\\\", \\\"{x:1281,y:578,t:1528143791276};\\\", \\\"{x:1279,y:578,t:1528143791359};\\\", \\\"{x:1278,y:578,t:1528143791375};\\\", \\\"{x:1271,y:577,t:1528143791391};\\\", \\\"{x:1257,y:575,t:1528143791408};\\\", \\\"{x:1245,y:574,t:1528143791426};\\\", \\\"{x:1236,y:572,t:1528143791443};\\\", \\\"{x:1230,y:571,t:1528143791458};\\\", \\\"{x:1226,y:570,t:1528143791476};\\\", \\\"{x:1219,y:570,t:1528143791492};\\\", \\\"{x:1205,y:568,t:1528143791508};\\\", \\\"{x:1182,y:563,t:1528143791526};\\\", \\\"{x:1140,y:559,t:1528143791542};\\\", \\\"{x:1119,y:554,t:1528143791558};\\\", \\\"{x:1113,y:553,t:1528143791576};\\\", \\\"{x:1114,y:553,t:1528143791623};\\\", \\\"{x:1123,y:553,t:1528143791630};\\\", \\\"{x:1136,y:553,t:1528143791643};\\\", \\\"{x:1165,y:553,t:1528143791659};\\\", \\\"{x:1201,y:553,t:1528143791676};\\\", \\\"{x:1229,y:553,t:1528143791692};\\\", \\\"{x:1245,y:552,t:1528143791708};\\\", \\\"{x:1258,y:552,t:1528143791725};\\\", \\\"{x:1265,y:552,t:1528143791742};\\\", \\\"{x:1266,y:552,t:1528143791766};\\\", \\\"{x:1268,y:552,t:1528143791775};\\\", \\\"{x:1270,y:554,t:1528143791792};\\\", \\\"{x:1272,y:555,t:1528143791809};\\\", \\\"{x:1275,y:558,t:1528143791826};\\\", \\\"{x:1278,y:562,t:1528143791843};\\\", \\\"{x:1281,y:568,t:1528143791858};\\\", \\\"{x:1286,y:574,t:1528143791876};\\\", \\\"{x:1293,y:579,t:1528143791893};\\\", \\\"{x:1302,y:583,t:1528143791908};\\\", \\\"{x:1316,y:586,t:1528143791925};\\\", \\\"{x:1341,y:587,t:1528143791942};\\\", \\\"{x:1359,y:587,t:1528143791959};\\\", \\\"{x:1381,y:587,t:1528143791976};\\\", \\\"{x:1401,y:587,t:1528143791993};\\\", \\\"{x:1421,y:587,t:1528143792010};\\\", \\\"{x:1439,y:587,t:1528143792026};\\\", \\\"{x:1450,y:587,t:1528143792043};\\\", \\\"{x:1455,y:586,t:1528143792060};\\\", \\\"{x:1456,y:586,t:1528143792075};\\\", \\\"{x:1457,y:585,t:1528143792093};\\\", \\\"{x:1457,y:584,t:1528143792199};\\\", \\\"{x:1457,y:583,t:1528143792209};\\\", \\\"{x:1450,y:579,t:1528143792225};\\\", \\\"{x:1441,y:578,t:1528143792242};\\\", \\\"{x:1425,y:573,t:1528143792260};\\\", \\\"{x:1411,y:569,t:1528143792276};\\\", \\\"{x:1394,y:567,t:1528143792293};\\\", \\\"{x:1386,y:567,t:1528143792309};\\\", \\\"{x:1377,y:567,t:1528143792326};\\\", \\\"{x:1370,y:567,t:1528143792342};\\\", \\\"{x:1362,y:569,t:1528143792359};\\\", \\\"{x:1354,y:573,t:1528143792376};\\\", \\\"{x:1346,y:577,t:1528143792393};\\\", \\\"{x:1339,y:581,t:1528143792410};\\\", \\\"{x:1332,y:586,t:1528143792426};\\\", \\\"{x:1329,y:589,t:1528143792443};\\\", \\\"{x:1326,y:593,t:1528143792459};\\\", \\\"{x:1323,y:597,t:1528143792475};\\\", \\\"{x:1323,y:601,t:1528143792493};\\\", \\\"{x:1323,y:607,t:1528143792509};\\\", \\\"{x:1326,y:612,t:1528143792525};\\\", \\\"{x:1337,y:623,t:1528143792543};\\\", \\\"{x:1348,y:631,t:1528143792559};\\\", \\\"{x:1363,y:641,t:1528143792577};\\\", \\\"{x:1379,y:649,t:1528143792592};\\\", \\\"{x:1387,y:654,t:1528143792609};\\\", \\\"{x:1393,y:657,t:1528143792625};\\\", \\\"{x:1396,y:657,t:1528143792643};\\\", \\\"{x:1398,y:657,t:1528143792660};\\\", \\\"{x:1399,y:657,t:1528143792676};\\\", \\\"{x:1400,y:657,t:1528143792692};\\\", \\\"{x:1401,y:657,t:1528143792710};\\\", \\\"{x:1402,y:657,t:1528143792727};\\\", \\\"{x:1404,y:657,t:1528143792743};\\\", \\\"{x:1405,y:656,t:1528143792759};\\\", \\\"{x:1407,y:655,t:1528143792777};\\\", \\\"{x:1409,y:654,t:1528143792793};\\\", \\\"{x:1410,y:653,t:1528143792823};\\\", \\\"{x:1411,y:652,t:1528143792831};\\\", \\\"{x:1412,y:651,t:1528143792842};\\\", \\\"{x:1413,y:649,t:1528143792860};\\\", \\\"{x:1415,y:646,t:1528143792877};\\\", \\\"{x:1417,y:644,t:1528143792893};\\\", \\\"{x:1418,y:643,t:1528143792909};\\\", \\\"{x:1420,y:641,t:1528143792927};\\\", \\\"{x:1422,y:639,t:1528143792942};\\\", \\\"{x:1424,y:638,t:1528143792960};\\\", \\\"{x:1425,y:637,t:1528143792976};\\\", \\\"{x:1426,y:636,t:1528143793006};\\\", \\\"{x:1427,y:634,t:1528143793022};\\\", \\\"{x:1428,y:633,t:1528143793039};\\\", \\\"{x:1430,y:632,t:1528143793055};\\\", \\\"{x:1431,y:632,t:1528143793102};\\\", \\\"{x:1434,y:632,t:1528143793110};\\\", \\\"{x:1437,y:632,t:1528143793126};\\\", \\\"{x:1440,y:632,t:1528143793143};\\\", \\\"{x:1441,y:632,t:1528143793159};\\\", \\\"{x:1442,y:633,t:1528143793263};\\\", \\\"{x:1442,y:635,t:1528143793277};\\\", \\\"{x:1442,y:641,t:1528143793294};\\\", \\\"{x:1438,y:652,t:1528143793310};\\\", \\\"{x:1430,y:669,t:1528143793326};\\\", \\\"{x:1425,y:681,t:1528143793344};\\\", \\\"{x:1421,y:690,t:1528143793360};\\\", \\\"{x:1415,y:699,t:1528143793377};\\\", \\\"{x:1409,y:709,t:1528143793394};\\\", \\\"{x:1400,y:724,t:1528143793410};\\\", \\\"{x:1391,y:742,t:1528143793427};\\\", \\\"{x:1383,y:755,t:1528143793444};\\\", \\\"{x:1378,y:771,t:1528143793460};\\\", \\\"{x:1371,y:786,t:1528143793477};\\\", \\\"{x:1367,y:798,t:1528143793494};\\\", \\\"{x:1364,y:805,t:1528143793510};\\\", \\\"{x:1361,y:814,t:1528143793526};\\\", \\\"{x:1359,y:819,t:1528143793544};\\\", \\\"{x:1359,y:822,t:1528143793560};\\\", \\\"{x:1359,y:826,t:1528143793577};\\\", \\\"{x:1358,y:828,t:1528143793594};\\\", \\\"{x:1357,y:830,t:1528143793611};\\\", \\\"{x:1357,y:831,t:1528143793627};\\\", \\\"{x:1357,y:832,t:1528143793644};\\\", \\\"{x:1357,y:834,t:1528143793660};\\\", \\\"{x:1357,y:835,t:1528143793686};\\\", \\\"{x:1356,y:835,t:1528143793727};\\\", \\\"{x:1357,y:832,t:1528143793759};\\\", \\\"{x:1358,y:830,t:1528143793766};\\\", \\\"{x:1362,y:823,t:1528143793777};\\\", \\\"{x:1374,y:804,t:1528143793794};\\\", \\\"{x:1391,y:775,t:1528143793811};\\\", \\\"{x:1415,y:737,t:1528143793827};\\\", \\\"{x:1446,y:696,t:1528143793844};\\\", \\\"{x:1469,y:660,t:1528143793861};\\\", \\\"{x:1480,y:638,t:1528143793877};\\\", \\\"{x:1484,y:627,t:1528143793894};\\\", \\\"{x:1484,y:621,t:1528143793910};\\\", \\\"{x:1484,y:620,t:1528143793927};\\\", \\\"{x:1482,y:620,t:1528143794095};\\\", \\\"{x:1475,y:621,t:1528143794111};\\\", \\\"{x:1460,y:625,t:1528143794127};\\\", \\\"{x:1446,y:629,t:1528143794145};\\\", \\\"{x:1436,y:635,t:1528143794163};\\\", \\\"{x:1430,y:638,t:1528143794176};\\\", \\\"{x:1427,y:640,t:1528143794194};\\\", \\\"{x:1426,y:640,t:1528143794246};\\\", \\\"{x:1425,y:642,t:1528143794663};\\\", \\\"{x:1429,y:643,t:1528143794720};\\\", \\\"{x:1440,y:643,t:1528143794729};\\\", \\\"{x:1450,y:643,t:1528143794745};\\\", \\\"{x:1465,y:643,t:1528143794761};\\\", \\\"{x:1486,y:643,t:1528143794779};\\\", \\\"{x:1503,y:643,t:1528143794794};\\\", \\\"{x:1519,y:643,t:1528143794812};\\\", \\\"{x:1532,y:643,t:1528143794829};\\\", \\\"{x:1541,y:643,t:1528143794845};\\\", \\\"{x:1545,y:642,t:1528143794861};\\\", \\\"{x:1548,y:642,t:1528143794878};\\\", \\\"{x:1552,y:640,t:1528143794894};\\\", \\\"{x:1553,y:640,t:1528143794951};\\\", \\\"{x:1554,y:640,t:1528143794961};\\\", \\\"{x:1555,y:640,t:1528143794977};\\\", \\\"{x:1556,y:640,t:1528143795070};\\\", \\\"{x:1558,y:640,t:1528143795094};\\\", \\\"{x:1559,y:640,t:1528143795118};\\\", \\\"{x:1560,y:640,t:1528143795128};\\\", \\\"{x:1561,y:640,t:1528143795231};\\\", \\\"{x:1561,y:643,t:1528143795246};\\\", \\\"{x:1559,y:648,t:1528143795261};\\\", \\\"{x:1551,y:660,t:1528143795278};\\\", \\\"{x:1540,y:675,t:1528143795294};\\\", \\\"{x:1535,y:681,t:1528143795311};\\\", \\\"{x:1532,y:684,t:1528143795327};\\\", \\\"{x:1531,y:684,t:1528143795535};\\\", \\\"{x:1533,y:682,t:1528143795575};\\\", \\\"{x:1535,y:681,t:1528143795583};\\\", \\\"{x:1536,y:681,t:1528143795596};\\\", \\\"{x:1539,y:680,t:1528143795612};\\\", \\\"{x:1552,y:680,t:1528143795629};\\\", \\\"{x:1557,y:678,t:1528143795646};\\\", \\\"{x:1565,y:674,t:1528143795663};\\\", \\\"{x:1569,y:672,t:1528143795679};\\\", \\\"{x:1570,y:671,t:1528143795694};\\\", \\\"{x:1572,y:670,t:1528143795712};\\\", \\\"{x:1573,y:670,t:1528143795728};\\\", \\\"{x:1575,y:669,t:1528143795745};\\\", \\\"{x:1577,y:669,t:1528143795762};\\\", \\\"{x:1577,y:668,t:1528143795791};\\\", \\\"{x:1577,y:671,t:1528143795855};\\\", \\\"{x:1577,y:674,t:1528143795863};\\\", \\\"{x:1577,y:677,t:1528143795878};\\\", \\\"{x:1577,y:688,t:1528143795895};\\\", \\\"{x:1574,y:695,t:1528143795912};\\\", \\\"{x:1570,y:704,t:1528143795929};\\\", \\\"{x:1566,y:710,t:1528143795946};\\\", \\\"{x:1563,y:716,t:1528143795963};\\\", \\\"{x:1562,y:717,t:1528143795978};\\\", \\\"{x:1564,y:719,t:1528143796030};\\\", \\\"{x:1569,y:720,t:1528143796045};\\\", \\\"{x:1578,y:722,t:1528143796062};\\\", \\\"{x:1590,y:728,t:1528143796078};\\\", \\\"{x:1595,y:732,t:1528143796095};\\\", \\\"{x:1602,y:737,t:1528143796112};\\\", \\\"{x:1606,y:741,t:1528143796129};\\\", \\\"{x:1608,y:746,t:1528143796145};\\\", \\\"{x:1609,y:751,t:1528143796161};\\\", \\\"{x:1610,y:757,t:1528143796178};\\\", \\\"{x:1614,y:765,t:1528143796194};\\\", \\\"{x:1622,y:778,t:1528143796212};\\\", \\\"{x:1630,y:787,t:1528143796228};\\\", \\\"{x:1633,y:792,t:1528143796245};\\\", \\\"{x:1636,y:797,t:1528143796261};\\\", \\\"{x:1644,y:804,t:1528143796278};\\\", \\\"{x:1649,y:808,t:1528143796294};\\\", \\\"{x:1653,y:811,t:1528143796312};\\\", \\\"{x:1657,y:813,t:1528143796329};\\\", \\\"{x:1663,y:814,t:1528143796345};\\\", \\\"{x:1672,y:814,t:1528143796362};\\\", \\\"{x:1683,y:814,t:1528143796379};\\\", \\\"{x:1695,y:814,t:1528143796395};\\\", \\\"{x:1704,y:814,t:1528143796412};\\\", \\\"{x:1705,y:814,t:1528143796429};\\\", \\\"{x:1701,y:814,t:1528143796479};\\\", \\\"{x:1679,y:814,t:1528143796496};\\\", \\\"{x:1636,y:812,t:1528143796513};\\\", \\\"{x:1569,y:800,t:1528143796529};\\\", \\\"{x:1520,y:790,t:1528143796545};\\\", \\\"{x:1483,y:778,t:1528143796562};\\\", \\\"{x:1461,y:762,t:1528143796579};\\\", \\\"{x:1455,y:757,t:1528143796595};\\\", \\\"{x:1453,y:751,t:1528143796612};\\\", \\\"{x:1453,y:749,t:1528143796629};\\\", \\\"{x:1453,y:748,t:1528143796647};\\\", \\\"{x:1453,y:752,t:1528143796719};\\\", \\\"{x:1453,y:758,t:1528143796730};\\\", \\\"{x:1453,y:769,t:1528143796746};\\\", \\\"{x:1444,y:785,t:1528143796762};\\\", \\\"{x:1436,y:801,t:1528143796779};\\\", \\\"{x:1428,y:817,t:1528143796796};\\\", \\\"{x:1421,y:832,t:1528143796812};\\\", \\\"{x:1416,y:843,t:1528143796829};\\\", \\\"{x:1415,y:844,t:1528143796846};\\\", \\\"{x:1413,y:844,t:1528143796862};\\\", \\\"{x:1413,y:845,t:1528143796943};\\\", \\\"{x:1413,y:846,t:1528143796951};\\\", \\\"{x:1413,y:847,t:1528143796962};\\\", \\\"{x:1413,y:849,t:1528143796979};\\\", \\\"{x:1408,y:854,t:1528143796996};\\\", \\\"{x:1398,y:858,t:1528143797013};\\\", \\\"{x:1386,y:862,t:1528143797030};\\\", \\\"{x:1373,y:864,t:1528143797046};\\\", \\\"{x:1364,y:868,t:1528143797062};\\\", \\\"{x:1359,y:869,t:1528143797079};\\\", \\\"{x:1356,y:869,t:1528143797096};\\\", \\\"{x:1353,y:869,t:1528143797113};\\\", \\\"{x:1351,y:869,t:1528143797130};\\\", \\\"{x:1347,y:869,t:1528143797146};\\\", \\\"{x:1345,y:867,t:1528143797162};\\\", \\\"{x:1342,y:859,t:1528143797179};\\\", \\\"{x:1342,y:848,t:1528143797196};\\\", \\\"{x:1342,y:837,t:1528143797214};\\\", \\\"{x:1345,y:824,t:1528143797230};\\\", \\\"{x:1354,y:804,t:1528143797247};\\\", \\\"{x:1360,y:782,t:1528143797262};\\\", \\\"{x:1364,y:774,t:1528143797278};\\\", \\\"{x:1365,y:770,t:1528143797295};\\\", \\\"{x:1367,y:767,t:1528143797313};\\\", \\\"{x:1367,y:766,t:1528143797328};\\\", \\\"{x:1364,y:762,t:1528143797345};\\\", \\\"{x:1360,y:757,t:1528143797362};\\\", \\\"{x:1358,y:755,t:1528143797378};\\\", \\\"{x:1358,y:754,t:1528143797396};\\\", \\\"{x:1357,y:753,t:1528143797413};\\\", \\\"{x:1356,y:752,t:1528143797428};\\\", \\\"{x:1355,y:749,t:1528143797445};\\\", \\\"{x:1354,y:745,t:1528143797462};\\\", \\\"{x:1354,y:739,t:1528143797479};\\\", \\\"{x:1355,y:731,t:1528143797496};\\\", \\\"{x:1361,y:724,t:1528143797512};\\\", \\\"{x:1367,y:718,t:1528143797529};\\\", \\\"{x:1371,y:714,t:1528143797545};\\\", \\\"{x:1373,y:710,t:1528143797562};\\\", \\\"{x:1374,y:708,t:1528143797579};\\\", \\\"{x:1374,y:707,t:1528143797614};\\\", \\\"{x:1374,y:705,t:1528143797629};\\\", \\\"{x:1368,y:699,t:1528143797646};\\\", \\\"{x:1336,y:689,t:1528143797663};\\\", \\\"{x:1313,y:684,t:1528143797679};\\\", \\\"{x:1296,y:681,t:1528143797696};\\\", \\\"{x:1282,y:678,t:1528143797713};\\\", \\\"{x:1278,y:675,t:1528143797729};\\\", \\\"{x:1278,y:673,t:1528143797783};\\\", \\\"{x:1280,y:672,t:1528143797799};\\\", \\\"{x:1282,y:671,t:1528143797815};\\\", \\\"{x:1283,y:671,t:1528143797831};\\\", \\\"{x:1285,y:671,t:1528143797855};\\\", \\\"{x:1289,y:671,t:1528143797863};\\\", \\\"{x:1302,y:675,t:1528143797880};\\\", \\\"{x:1311,y:681,t:1528143797896};\\\", \\\"{x:1325,y:686,t:1528143797913};\\\", \\\"{x:1329,y:689,t:1528143797930};\\\", \\\"{x:1332,y:692,t:1528143797946};\\\", \\\"{x:1333,y:692,t:1528143797963};\\\", \\\"{x:1333,y:694,t:1528143797980};\\\", \\\"{x:1333,y:695,t:1528143797996};\\\", \\\"{x:1336,y:699,t:1528143798014};\\\", \\\"{x:1337,y:701,t:1528143798030};\\\", \\\"{x:1337,y:702,t:1528143798046};\\\", \\\"{x:1338,y:703,t:1528143798063};\\\", \\\"{x:1339,y:703,t:1528143798278};\\\", \\\"{x:1340,y:702,t:1528143798310};\\\", \\\"{x:1340,y:701,t:1528143798318};\\\", \\\"{x:1342,y:700,t:1528143798329};\\\", \\\"{x:1343,y:699,t:1528143798358};\\\", \\\"{x:1344,y:699,t:1528143798380};\\\", \\\"{x:1345,y:699,t:1528143798438};\\\", \\\"{x:1345,y:701,t:1528143798446};\\\", \\\"{x:1343,y:714,t:1528143798464};\\\", \\\"{x:1336,y:735,t:1528143798480};\\\", \\\"{x:1328,y:755,t:1528143798497};\\\", \\\"{x:1318,y:774,t:1528143798513};\\\", \\\"{x:1309,y:790,t:1528143798530};\\\", \\\"{x:1302,y:804,t:1528143798547};\\\", \\\"{x:1298,y:816,t:1528143798563};\\\", \\\"{x:1295,y:829,t:1528143798580};\\\", \\\"{x:1293,y:836,t:1528143798597};\\\", \\\"{x:1292,y:839,t:1528143798613};\\\", \\\"{x:1292,y:840,t:1528143798630};\\\", \\\"{x:1292,y:835,t:1528143798671};\\\", \\\"{x:1295,y:831,t:1528143798680};\\\", \\\"{x:1302,y:816,t:1528143798697};\\\", \\\"{x:1313,y:805,t:1528143798713};\\\", \\\"{x:1329,y:789,t:1528143798730};\\\", \\\"{x:1341,y:774,t:1528143798748};\\\", \\\"{x:1352,y:755,t:1528143798763};\\\", \\\"{x:1363,y:741,t:1528143798781};\\\", \\\"{x:1366,y:736,t:1528143798797};\\\", \\\"{x:1367,y:736,t:1528143798813};\\\", \\\"{x:1367,y:737,t:1528143798855};\\\", \\\"{x:1367,y:746,t:1528143798863};\\\", \\\"{x:1367,y:762,t:1528143798881};\\\", \\\"{x:1374,y:778,t:1528143798897};\\\", \\\"{x:1382,y:794,t:1528143798914};\\\", \\\"{x:1389,y:813,t:1528143798930};\\\", \\\"{x:1396,y:830,t:1528143798948};\\\", \\\"{x:1405,y:846,t:1528143798964};\\\", \\\"{x:1410,y:857,t:1528143798980};\\\", \\\"{x:1413,y:864,t:1528143798997};\\\", \\\"{x:1414,y:864,t:1528143799015};\\\", \\\"{x:1411,y:859,t:1528143799087};\\\", \\\"{x:1401,y:852,t:1528143799097};\\\", \\\"{x:1373,y:837,t:1528143799114};\\\", \\\"{x:1338,y:829,t:1528143799131};\\\", \\\"{x:1312,y:826,t:1528143799147};\\\", \\\"{x:1298,y:826,t:1528143799164};\\\", \\\"{x:1291,y:826,t:1528143799179};\\\", \\\"{x:1289,y:826,t:1528143799197};\\\", \\\"{x:1288,y:826,t:1528143799214};\\\", \\\"{x:1284,y:828,t:1528143799230};\\\", \\\"{x:1281,y:829,t:1528143799246};\\\", \\\"{x:1278,y:831,t:1528143799264};\\\", \\\"{x:1274,y:833,t:1528143799280};\\\", \\\"{x:1271,y:833,t:1528143799297};\\\", \\\"{x:1267,y:834,t:1528143799313};\\\", \\\"{x:1263,y:835,t:1528143799329};\\\", \\\"{x:1256,y:837,t:1528143799346};\\\", \\\"{x:1247,y:839,t:1528143799364};\\\", \\\"{x:1242,y:839,t:1528143799380};\\\", \\\"{x:1239,y:840,t:1528143799397};\\\", \\\"{x:1234,y:840,t:1528143799414};\\\", \\\"{x:1231,y:838,t:1528143799430};\\\", \\\"{x:1230,y:836,t:1528143799447};\\\", \\\"{x:1227,y:834,t:1528143799464};\\\", \\\"{x:1226,y:832,t:1528143799487};\\\", \\\"{x:1225,y:832,t:1528143799502};\\\", \\\"{x:1225,y:831,t:1528143799567};\\\", \\\"{x:1223,y:831,t:1528143799581};\\\", \\\"{x:1218,y:832,t:1528143799597};\\\", \\\"{x:1213,y:835,t:1528143799614};\\\", \\\"{x:1211,y:835,t:1528143799631};\\\", \\\"{x:1211,y:836,t:1528143799648};\\\", \\\"{x:1208,y:834,t:1528143799679};\\\", \\\"{x:1202,y:825,t:1528143799686};\\\", \\\"{x:1199,y:817,t:1528143799697};\\\", \\\"{x:1195,y:802,t:1528143799714};\\\", \\\"{x:1180,y:784,t:1528143799731};\\\", \\\"{x:1167,y:773,t:1528143799747};\\\", \\\"{x:1153,y:765,t:1528143799764};\\\", \\\"{x:1139,y:762,t:1528143799781};\\\", \\\"{x:1121,y:760,t:1528143799797};\\\", \\\"{x:1089,y:760,t:1528143799814};\\\", \\\"{x:1064,y:760,t:1528143799830};\\\", \\\"{x:1038,y:759,t:1528143799847};\\\", \\\"{x:1010,y:754,t:1528143799864};\\\", \\\"{x:989,y:752,t:1528143799881};\\\", \\\"{x:965,y:746,t:1528143799897};\\\", \\\"{x:943,y:734,t:1528143799913};\\\", \\\"{x:922,y:719,t:1528143799930};\\\", \\\"{x:902,y:700,t:1528143799947};\\\", \\\"{x:882,y:684,t:1528143799964};\\\", \\\"{x:863,y:669,t:1528143799980};\\\", \\\"{x:847,y:656,t:1528143799996};\\\", \\\"{x:828,y:645,t:1528143800014};\\\", \\\"{x:823,y:641,t:1528143800031};\\\", \\\"{x:818,y:641,t:1528143800047};\\\", \\\"{x:811,y:641,t:1528143800064};\\\", \\\"{x:782,y:657,t:1528143800081};\\\", \\\"{x:731,y:685,t:1528143800097};\\\", \\\"{x:652,y:727,t:1528143800114};\\\", \\\"{x:578,y:759,t:1528143800131};\\\", \\\"{x:515,y:783,t:1528143800148};\\\", \\\"{x:471,y:794,t:1528143800164};\\\", \\\"{x:442,y:802,t:1528143800181};\\\", \\\"{x:410,y:809,t:1528143800198};\\\", \\\"{x:396,y:811,t:1528143800214};\\\", \\\"{x:392,y:811,t:1528143800231};\\\", \\\"{x:391,y:812,t:1528143800248};\\\", \\\"{x:389,y:812,t:1528143800264};\\\", \\\"{x:388,y:812,t:1528143800281};\\\", \\\"{x:388,y:813,t:1528143800298};\\\", \\\"{x:387,y:813,t:1528143800318};\\\", \\\"{x:388,y:812,t:1528143800350};\\\", \\\"{x:402,y:800,t:1528143800363};\\\", \\\"{x:455,y:762,t:1528143800381};\\\", \\\"{x:496,y:728,t:1528143800399};\\\", \\\"{x:510,y:719,t:1528143800414};\\\", \\\"{x:514,y:717,t:1528143800431};\\\", \\\"{x:515,y:717,t:1528143800486};\\\", \\\"{x:515,y:720,t:1528143800502};\\\", \\\"{x:515,y:721,t:1528143800518};\\\", \\\"{x:514,y:722,t:1528143800534};\\\", \\\"{x:514,y:723,t:1528143800550};\\\", \\\"{x:512,y:725,t:1528143800566};\\\", \\\"{x:510,y:726,t:1528143800583};\\\", \\\"{x:509,y:727,t:1528143800599};\\\", \\\"{x:507,y:728,t:1528143800617};\\\", \\\"{x:507,y:729,t:1528143800633};\\\", \\\"{x:506,y:729,t:1528143800694};\\\", \\\"{x:513,y:722,t:1528143801190};\\\", \\\"{x:526,y:708,t:1528143801200};\\\", \\\"{x:558,y:676,t:1528143801217};\\\", \\\"{x:610,y:620,t:1528143801233};\\\", \\\"{x:671,y:567,t:1528143801249};\\\", \\\"{x:719,y:521,t:1528143801267};\\\", \\\"{x:748,y:491,t:1528143801282};\\\", \\\"{x:765,y:473,t:1528143801300};\\\", \\\"{x:774,y:464,t:1528143801317};\\\", \\\"{x:777,y:461,t:1528143801333};\\\", \\\"{x:778,y:459,t:1528143801350};\\\", \\\"{x:779,y:458,t:1528143801367};\\\" ] }, { \\\"rt\\\": 80413, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 13, \\\"time_elapsed\\\": 798202, \\\"internal_node_id\\\": \\\"0.0-6.0-3.0\\\", \\\"subject\\\": \\\"MKTF4\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"zulu\\\", \\\"condition\\\": \\\"211\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"starttime+before+endtime+during\\\", \\\"q\\\": 9, \\\"clicks\\\": 1.5, \\\"explicit\\\": 2, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XInside-YFull\\\", \\\"correct\\\": 1, \\\"orth_correct\\\": 1, \\\"answer\\\": [ \\\"I\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-X -J -J -F -F -F -F -E -M -M -O \\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:780,y:457,t:1528143804191};\\\", \\\"{x:788,y:450,t:1528143804202};\\\", \\\"{x:819,y:411,t:1528143804220};\\\", \\\"{x:843,y:381,t:1528143804237};\\\", \\\"{x:855,y:371,t:1528143804252};\\\", \\\"{x:855,y:370,t:1528143804719};\\\", \\\"{x:849,y:370,t:1528143804728};\\\", \\\"{x:784,y:400,t:1528143804745};\\\", \\\"{x:702,y:432,t:1528143804762};\\\", \\\"{x:616,y:459,t:1528143804779};\\\", \\\"{x:527,y:471,t:1528143804795};\\\", \\\"{x:445,y:476,t:1528143804812};\\\", \\\"{x:392,y:476,t:1528143804829};\\\", \\\"{x:375,y:469,t:1528143804845};\\\", \\\"{x:370,y:465,t:1528143804862};\\\", \\\"{x:369,y:465,t:1528143804879};\\\", \\\"{x:372,y:466,t:1528143805007};\\\", \\\"{x:378,y:468,t:1528143805015};\\\", \\\"{x:387,y:474,t:1528143805030};\\\", \\\"{x:401,y:480,t:1528143805044};\\\", \\\"{x:420,y:487,t:1528143805063};\\\", \\\"{x:439,y:491,t:1528143805079};\\\", \\\"{x:445,y:493,t:1528143805095};\\\", \\\"{x:452,y:494,t:1528143805110};\\\", \\\"{x:458,y:494,t:1528143805128};\\\", \\\"{x:464,y:494,t:1528143805144};\\\", \\\"{x:467,y:494,t:1528143805160};\\\", \\\"{x:469,y:494,t:1528143805178};\\\", \\\"{x:470,y:494,t:1528143805214};\\\", \\\"{x:472,y:494,t:1528143805239};\\\", \\\"{x:474,y:493,t:1528143805246};\\\", \\\"{x:476,y:493,t:1528143805260};\\\", \\\"{x:481,y:490,t:1528143805278};\\\", \\\"{x:485,y:488,t:1528143805294};\\\", \\\"{x:491,y:487,t:1528143805311};\\\", \\\"{x:506,y:484,t:1528143805328};\\\", \\\"{x:533,y:479,t:1528143805344};\\\", \\\"{x:583,y:476,t:1528143805361};\\\", \\\"{x:671,y:470,t:1528143805379};\\\", \\\"{x:789,y:460,t:1528143805396};\\\", \\\"{x:913,y:460,t:1528143805411};\\\", \\\"{x:1032,y:460,t:1528143805429};\\\", \\\"{x:1124,y:460,t:1528143805446};\\\", \\\"{x:1193,y:460,t:1528143805462};\\\", \\\"{x:1233,y:460,t:1528143805479};\\\", \\\"{x:1237,y:460,t:1528143805496};\\\", \\\"{x:1238,y:460,t:1528143805567};\\\", \\\"{x:1241,y:461,t:1528143805579};\\\", \\\"{x:1249,y:469,t:1528143805596};\\\", \\\"{x:1261,y:479,t:1528143805612};\\\", \\\"{x:1281,y:495,t:1528143805630};\\\", \\\"{x:1306,y:516,t:1528143805646};\\\", \\\"{x:1364,y:553,t:1528143805662};\\\", \\\"{x:1467,y:606,t:1528143805679};\\\", \\\"{x:1541,y:636,t:1528143805696};\\\", \\\"{x:1584,y:651,t:1528143805713};\\\", \\\"{x:1605,y:656,t:1528143805729};\\\", \\\"{x:1609,y:656,t:1528143805746};\\\", \\\"{x:1610,y:656,t:1528143805763};\\\", \\\"{x:1599,y:653,t:1528143805873};\\\", \\\"{x:1580,y:644,t:1528143805879};\\\", \\\"{x:1541,y:620,t:1528143805896};\\\", \\\"{x:1510,y:599,t:1528143805913};\\\", \\\"{x:1489,y:583,t:1528143805929};\\\", \\\"{x:1471,y:572,t:1528143805946};\\\", \\\"{x:1456,y:558,t:1528143805963};\\\", \\\"{x:1439,y:543,t:1528143805980};\\\", \\\"{x:1415,y:525,t:1528143805996};\\\", \\\"{x:1399,y:513,t:1528143806013};\\\", \\\"{x:1382,y:502,t:1528143806029};\\\", \\\"{x:1366,y:494,t:1528143806046};\\\", \\\"{x:1354,y:490,t:1528143806063};\\\", \\\"{x:1346,y:487,t:1528143806080};\\\", \\\"{x:1341,y:486,t:1528143806096};\\\", \\\"{x:1333,y:486,t:1528143806113};\\\", \\\"{x:1320,y:488,t:1528143806130};\\\", \\\"{x:1303,y:499,t:1528143806147};\\\", \\\"{x:1285,y:515,t:1528143806163};\\\", \\\"{x:1279,y:532,t:1528143806179};\\\", \\\"{x:1274,y:552,t:1528143806196};\\\", \\\"{x:1273,y:574,t:1528143806213};\\\", \\\"{x:1275,y:596,t:1528143806231};\\\", \\\"{x:1281,y:619,t:1528143806246};\\\", \\\"{x:1300,y:652,t:1528143806262};\\\", \\\"{x:1313,y:672,t:1528143806279};\\\", \\\"{x:1329,y:690,t:1528143806295};\\\", \\\"{x:1344,y:705,t:1528143806313};\\\", \\\"{x:1358,y:719,t:1528143806330};\\\", \\\"{x:1370,y:733,t:1528143806346};\\\", \\\"{x:1378,y:741,t:1528143806362};\\\", \\\"{x:1380,y:744,t:1528143806380};\\\", \\\"{x:1380,y:745,t:1528143806396};\\\", \\\"{x:1380,y:747,t:1528143806480};\\\", \\\"{x:1380,y:748,t:1528143806496};\\\", \\\"{x:1380,y:752,t:1528143806513};\\\", \\\"{x:1385,y:760,t:1528143806530};\\\", \\\"{x:1393,y:767,t:1528143806546};\\\", \\\"{x:1410,y:777,t:1528143806563};\\\", \\\"{x:1430,y:789,t:1528143806580};\\\", \\\"{x:1448,y:799,t:1528143806597};\\\", \\\"{x:1466,y:810,t:1528143806613};\\\", \\\"{x:1480,y:817,t:1528143806630};\\\", \\\"{x:1491,y:823,t:1528143806647};\\\", \\\"{x:1492,y:824,t:1528143806662};\\\", \\\"{x:1493,y:824,t:1528143806680};\\\", \\\"{x:1493,y:825,t:1528143806728};\\\", \\\"{x:1493,y:826,t:1528143806744};\\\", \\\"{x:1492,y:826,t:1528143806751};\\\", \\\"{x:1491,y:816,t:1528143806824};\\\", \\\"{x:1488,y:804,t:1528143806831};\\\", \\\"{x:1491,y:783,t:1528143806847};\\\", \\\"{x:1501,y:759,t:1528143806863};\\\", \\\"{x:1518,y:728,t:1528143806880};\\\", \\\"{x:1534,y:701,t:1528143806897};\\\", \\\"{x:1545,y:675,t:1528143806913};\\\", \\\"{x:1554,y:652,t:1528143806930};\\\", \\\"{x:1559,y:628,t:1528143806947};\\\", \\\"{x:1561,y:609,t:1528143806964};\\\", \\\"{x:1561,y:595,t:1528143806980};\\\", \\\"{x:1560,y:583,t:1528143806998};\\\", \\\"{x:1558,y:576,t:1528143807013};\\\", \\\"{x:1556,y:570,t:1528143807030};\\\", \\\"{x:1551,y:563,t:1528143807046};\\\", \\\"{x:1545,y:559,t:1528143807063};\\\", \\\"{x:1536,y:558,t:1528143807080};\\\", \\\"{x:1524,y:558,t:1528143807096};\\\", \\\"{x:1506,y:558,t:1528143807113};\\\", \\\"{x:1485,y:566,t:1528143807129};\\\", \\\"{x:1465,y:577,t:1528143807146};\\\", \\\"{x:1448,y:590,t:1528143807163};\\\", \\\"{x:1436,y:602,t:1528143807179};\\\", \\\"{x:1426,y:620,t:1528143807197};\\\", \\\"{x:1419,y:643,t:1528143807214};\\\", \\\"{x:1415,y:672,t:1528143807230};\\\", \\\"{x:1411,y:727,t:1528143807247};\\\", \\\"{x:1412,y:756,t:1528143807264};\\\", \\\"{x:1422,y:784,t:1528143807280};\\\", \\\"{x:1436,y:807,t:1528143807297};\\\", \\\"{x:1453,y:826,t:1528143807314};\\\", \\\"{x:1474,y:842,t:1528143807330};\\\", \\\"{x:1494,y:851,t:1528143807347};\\\", \\\"{x:1514,y:855,t:1528143807363};\\\", \\\"{x:1532,y:855,t:1528143807380};\\\", \\\"{x:1548,y:854,t:1528143807396};\\\", \\\"{x:1559,y:850,t:1528143807413};\\\", \\\"{x:1573,y:842,t:1528143807430};\\\", \\\"{x:1583,y:834,t:1528143807446};\\\", \\\"{x:1594,y:826,t:1528143807464};\\\", \\\"{x:1603,y:820,t:1528143807481};\\\", \\\"{x:1610,y:817,t:1528143807496};\\\", \\\"{x:1611,y:816,t:1528143807513};\\\", \\\"{x:1614,y:816,t:1528143807535};\\\", \\\"{x:1616,y:818,t:1528143807546};\\\", \\\"{x:1620,y:821,t:1528143807563};\\\", \\\"{x:1629,y:829,t:1528143807581};\\\", \\\"{x:1644,y:844,t:1528143807597};\\\", \\\"{x:1665,y:860,t:1528143807614};\\\", \\\"{x:1690,y:878,t:1528143807631};\\\", \\\"{x:1696,y:885,t:1528143807646};\\\", \\\"{x:1701,y:890,t:1528143807664};\\\", \\\"{x:1702,y:891,t:1528143807681};\\\", \\\"{x:1702,y:892,t:1528143807719};\\\", \\\"{x:1701,y:893,t:1528143807731};\\\", \\\"{x:1692,y:896,t:1528143807747};\\\", \\\"{x:1673,y:896,t:1528143807764};\\\", \\\"{x:1639,y:887,t:1528143807782};\\\", \\\"{x:1596,y:864,t:1528143807798};\\\", \\\"{x:1552,y:825,t:1528143807814};\\\", \\\"{x:1527,y:788,t:1528143807830};\\\", \\\"{x:1526,y:782,t:1528143807847};\\\", \\\"{x:1526,y:772,t:1528143807864};\\\", \\\"{x:1529,y:756,t:1528143807881};\\\", \\\"{x:1537,y:735,t:1528143807897};\\\", \\\"{x:1547,y:711,t:1528143807914};\\\", \\\"{x:1559,y:687,t:1528143807931};\\\", \\\"{x:1566,y:674,t:1528143807947};\\\", \\\"{x:1568,y:664,t:1528143807964};\\\", \\\"{x:1568,y:654,t:1528143807980};\\\", \\\"{x:1568,y:641,t:1528143807998};\\\", \\\"{x:1568,y:626,t:1528143808014};\\\", \\\"{x:1563,y:598,t:1528143808030};\\\", \\\"{x:1559,y:580,t:1528143808048};\\\", \\\"{x:1556,y:562,t:1528143808064};\\\", \\\"{x:1555,y:549,t:1528143808081};\\\", \\\"{x:1551,y:535,t:1528143808098};\\\", \\\"{x:1543,y:520,t:1528143808113};\\\", \\\"{x:1534,y:508,t:1528143808131};\\\", \\\"{x:1519,y:498,t:1528143808148};\\\", \\\"{x:1497,y:490,t:1528143808163};\\\", \\\"{x:1478,y:486,t:1528143808181};\\\", \\\"{x:1467,y:486,t:1528143808198};\\\", \\\"{x:1462,y:486,t:1528143808214};\\\", \\\"{x:1455,y:486,t:1528143808231};\\\", \\\"{x:1448,y:486,t:1528143808248};\\\", \\\"{x:1444,y:487,t:1528143808264};\\\", \\\"{x:1437,y:491,t:1528143808281};\\\", \\\"{x:1431,y:494,t:1528143808298};\\\", \\\"{x:1415,y:502,t:1528143808315};\\\", \\\"{x:1394,y:514,t:1528143808331};\\\", \\\"{x:1376,y:531,t:1528143808348};\\\", \\\"{x:1362,y:546,t:1528143808365};\\\", \\\"{x:1349,y:561,t:1528143808381};\\\", \\\"{x:1341,y:571,t:1528143808398};\\\", \\\"{x:1332,y:587,t:1528143808414};\\\", \\\"{x:1329,y:595,t:1528143808431};\\\", \\\"{x:1325,y:603,t:1528143808447};\\\", \\\"{x:1323,y:613,t:1528143808465};\\\", \\\"{x:1322,y:624,t:1528143808481};\\\", \\\"{x:1322,y:636,t:1528143808497};\\\", \\\"{x:1322,y:648,t:1528143808514};\\\", \\\"{x:1324,y:663,t:1528143808531};\\\", \\\"{x:1337,y:683,t:1528143808547};\\\", \\\"{x:1354,y:705,t:1528143808565};\\\", \\\"{x:1375,y:732,t:1528143808581};\\\", \\\"{x:1385,y:739,t:1528143808598};\\\", \\\"{x:1396,y:744,t:1528143808615};\\\", \\\"{x:1407,y:749,t:1528143808631};\\\", \\\"{x:1411,y:751,t:1528143808648};\\\", \\\"{x:1413,y:752,t:1528143808665};\\\", \\\"{x:1417,y:755,t:1528143808682};\\\", \\\"{x:1418,y:756,t:1528143808703};\\\", \\\"{x:1418,y:758,t:1528143808744};\\\", \\\"{x:1418,y:760,t:1528143808751};\\\", \\\"{x:1418,y:762,t:1528143808765};\\\", \\\"{x:1416,y:770,t:1528143808782};\\\", \\\"{x:1407,y:782,t:1528143808798};\\\", \\\"{x:1390,y:798,t:1528143808815};\\\", \\\"{x:1376,y:809,t:1528143808832};\\\", \\\"{x:1371,y:816,t:1528143808848};\\\", \\\"{x:1366,y:823,t:1528143808865};\\\", \\\"{x:1363,y:828,t:1528143808882};\\\", \\\"{x:1357,y:834,t:1528143808899};\\\", \\\"{x:1351,y:837,t:1528143808916};\\\", \\\"{x:1342,y:842,t:1528143808931};\\\", \\\"{x:1332,y:847,t:1528143808948};\\\", \\\"{x:1325,y:849,t:1528143808965};\\\", \\\"{x:1317,y:853,t:1528143808982};\\\", \\\"{x:1310,y:855,t:1528143808998};\\\", \\\"{x:1298,y:857,t:1528143809014};\\\", \\\"{x:1294,y:857,t:1528143809032};\\\", \\\"{x:1289,y:859,t:1528143809047};\\\", \\\"{x:1285,y:859,t:1528143809064};\\\", \\\"{x:1280,y:859,t:1528143809082};\\\", \\\"{x:1277,y:859,t:1528143809098};\\\", \\\"{x:1273,y:859,t:1528143809115};\\\", \\\"{x:1269,y:857,t:1528143809131};\\\", \\\"{x:1266,y:854,t:1528143809148};\\\", \\\"{x:1263,y:852,t:1528143809164};\\\", \\\"{x:1261,y:850,t:1528143809182};\\\", \\\"{x:1260,y:850,t:1528143809198};\\\", \\\"{x:1260,y:849,t:1528143809215};\\\", \\\"{x:1256,y:847,t:1528143809232};\\\", \\\"{x:1251,y:844,t:1528143809249};\\\", \\\"{x:1247,y:842,t:1528143809265};\\\", \\\"{x:1244,y:841,t:1528143809282};\\\", \\\"{x:1243,y:840,t:1528143809299};\\\", \\\"{x:1239,y:838,t:1528143809314};\\\", \\\"{x:1238,y:837,t:1528143809332};\\\", \\\"{x:1236,y:837,t:1528143809349};\\\", \\\"{x:1233,y:836,t:1528143809364};\\\", \\\"{x:1231,y:835,t:1528143809382};\\\", \\\"{x:1228,y:835,t:1528143809398};\\\", \\\"{x:1226,y:834,t:1528143809415};\\\", \\\"{x:1224,y:834,t:1528143809432};\\\", \\\"{x:1222,y:834,t:1528143809449};\\\", \\\"{x:1221,y:834,t:1528143809465};\\\", \\\"{x:1220,y:834,t:1528143809481};\\\", \\\"{x:1219,y:834,t:1528143809498};\\\", \\\"{x:1218,y:834,t:1528143809516};\\\", \\\"{x:1217,y:834,t:1528143809532};\\\", \\\"{x:1216,y:834,t:1528143809549};\\\", \\\"{x:1215,y:834,t:1528143810135};\\\", \\\"{x:1214,y:834,t:1528143810894};\\\", \\\"{x:1213,y:833,t:1528143810903};\\\", \\\"{x:1213,y:832,t:1528143811991};\\\", \\\"{x:1213,y:827,t:1528143819806};\\\", \\\"{x:1213,y:818,t:1528143819824};\\\", \\\"{x:1213,y:811,t:1528143819840};\\\", \\\"{x:1213,y:803,t:1528143819857};\\\", \\\"{x:1211,y:794,t:1528143819873};\\\", \\\"{x:1209,y:788,t:1528143819890};\\\", \\\"{x:1208,y:785,t:1528143819907};\\\", \\\"{x:1206,y:780,t:1528143819923};\\\", \\\"{x:1205,y:778,t:1528143819940};\\\", \\\"{x:1204,y:777,t:1528143819958};\\\", \\\"{x:1203,y:775,t:1528143819973};\\\", \\\"{x:1201,y:774,t:1528143819990};\\\", \\\"{x:1200,y:774,t:1528143820007};\\\", \\\"{x:1199,y:774,t:1528143820030};\\\", \\\"{x:1197,y:774,t:1528143820054};\\\", \\\"{x:1196,y:774,t:1528143820070};\\\", \\\"{x:1195,y:774,t:1528143820086};\\\", \\\"{x:1194,y:774,t:1528143820119};\\\", \\\"{x:1192,y:774,t:1528143820134};\\\", \\\"{x:1191,y:774,t:1528143820150};\\\", \\\"{x:1189,y:774,t:1528143820158};\\\", \\\"{x:1188,y:774,t:1528143820174};\\\", \\\"{x:1186,y:774,t:1528143820190};\\\", \\\"{x:1185,y:774,t:1528143820207};\\\", \\\"{x:1182,y:774,t:1528143820223};\\\", \\\"{x:1181,y:774,t:1528143820240};\\\", \\\"{x:1180,y:773,t:1528143820257};\\\", \\\"{x:1179,y:772,t:1528143820274};\\\", \\\"{x:1175,y:771,t:1528143823134};\\\", \\\"{x:1165,y:765,t:1528143823143};\\\", \\\"{x:1140,y:750,t:1528143823159};\\\", \\\"{x:1113,y:732,t:1528143823176};\\\", \\\"{x:1075,y:708,t:1528143823193};\\\", \\\"{x:1035,y:679,t:1528143823209};\\\", \\\"{x:1007,y:657,t:1528143823226};\\\", \\\"{x:988,y:639,t:1528143823242};\\\", \\\"{x:971,y:625,t:1528143823259};\\\", \\\"{x:950,y:611,t:1528143823276};\\\", \\\"{x:912,y:594,t:1528143823292};\\\", \\\"{x:873,y:585,t:1528143823308};\\\", \\\"{x:838,y:577,t:1528143823324};\\\", \\\"{x:814,y:573,t:1528143823340};\\\", \\\"{x:755,y:565,t:1528143823359};\\\", \\\"{x:697,y:559,t:1528143823376};\\\", \\\"{x:636,y:559,t:1528143823393};\\\", \\\"{x:574,y:559,t:1528143823409};\\\", \\\"{x:524,y:559,t:1528143823426};\\\", \\\"{x:504,y:559,t:1528143823444};\\\", \\\"{x:498,y:559,t:1528143823459};\\\", \\\"{x:496,y:559,t:1528143823476};\\\", \\\"{x:494,y:559,t:1528143823492};\\\", \\\"{x:493,y:559,t:1528143823509};\\\", \\\"{x:489,y:560,t:1528143823526};\\\", \\\"{x:486,y:560,t:1528143823542};\\\", \\\"{x:478,y:560,t:1528143823559};\\\", \\\"{x:466,y:562,t:1528143823576};\\\", \\\"{x:451,y:564,t:1528143823593};\\\", \\\"{x:439,y:567,t:1528143823609};\\\", \\\"{x:433,y:567,t:1528143823627};\\\", \\\"{x:430,y:567,t:1528143823643};\\\", \\\"{x:429,y:567,t:1528143823660};\\\", \\\"{x:424,y:567,t:1528143823677};\\\", \\\"{x:409,y:567,t:1528143823694};\\\", \\\"{x:379,y:558,t:1528143823711};\\\", \\\"{x:366,y:553,t:1528143823727};\\\", \\\"{x:357,y:546,t:1528143823743};\\\", \\\"{x:353,y:537,t:1528143823760};\\\", \\\"{x:353,y:524,t:1528143823777};\\\", \\\"{x:353,y:517,t:1528143823794};\\\", \\\"{x:353,y:514,t:1528143823810};\\\", \\\"{x:353,y:512,t:1528143823826};\\\", \\\"{x:352,y:512,t:1528143823870};\\\", \\\"{x:351,y:511,t:1528143823878};\\\", \\\"{x:350,y:511,t:1528143823926};\\\", \\\"{x:342,y:511,t:1528143823944};\\\", \\\"{x:328,y:511,t:1528143823961};\\\", \\\"{x:314,y:514,t:1528143823978};\\\", \\\"{x:298,y:516,t:1528143823994};\\\", \\\"{x:284,y:518,t:1528143824011};\\\", \\\"{x:275,y:519,t:1528143824027};\\\", \\\"{x:274,y:519,t:1528143824043};\\\", \\\"{x:270,y:519,t:1528143824060};\\\", \\\"{x:267,y:519,t:1528143824078};\\\", \\\"{x:254,y:518,t:1528143824094};\\\", \\\"{x:240,y:517,t:1528143824110};\\\", \\\"{x:231,y:515,t:1528143824127};\\\", \\\"{x:223,y:514,t:1528143824143};\\\", \\\"{x:218,y:514,t:1528143824160};\\\", \\\"{x:215,y:514,t:1528143824178};\\\", \\\"{x:209,y:514,t:1528143824193};\\\", \\\"{x:203,y:514,t:1528143824211};\\\", \\\"{x:197,y:515,t:1528143824228};\\\", \\\"{x:192,y:515,t:1528143824243};\\\", \\\"{x:186,y:515,t:1528143824261};\\\", \\\"{x:183,y:515,t:1528143824277};\\\", \\\"{x:181,y:515,t:1528143824293};\\\", \\\"{x:178,y:515,t:1528143824310};\\\", \\\"{x:176,y:515,t:1528143824328};\\\", \\\"{x:175,y:515,t:1528143824344};\\\", \\\"{x:173,y:515,t:1528143824361};\\\", \\\"{x:172,y:515,t:1528143824378};\\\", \\\"{x:173,y:514,t:1528143824895};\\\", \\\"{x:216,y:513,t:1528143824911};\\\", \\\"{x:279,y:525,t:1528143824929};\\\", \\\"{x:332,y:533,t:1528143824944};\\\", \\\"{x:392,y:545,t:1528143824962};\\\", \\\"{x:448,y:563,t:1528143824978};\\\", \\\"{x:478,y:576,t:1528143824994};\\\", \\\"{x:496,y:583,t:1528143825011};\\\", \\\"{x:503,y:586,t:1528143825028};\\\", \\\"{x:506,y:588,t:1528143825044};\\\", \\\"{x:507,y:589,t:1528143825062};\\\", \\\"{x:510,y:589,t:1528143825077};\\\", \\\"{x:512,y:590,t:1528143825093};\\\", \\\"{x:512,y:591,t:1528143825111};\\\", \\\"{x:513,y:592,t:1528143825127};\\\", \\\"{x:514,y:592,t:1528143825151};\\\", \\\"{x:515,y:592,t:1528143825174};\\\", \\\"{x:502,y:587,t:1528143825359};\\\", \\\"{x:475,y:574,t:1528143825368};\\\", \\\"{x:453,y:566,t:1528143825377};\\\", \\\"{x:417,y:557,t:1528143825394};\\\", \\\"{x:387,y:552,t:1528143825412};\\\", \\\"{x:366,y:546,t:1528143825428};\\\", \\\"{x:348,y:542,t:1528143825444};\\\", \\\"{x:339,y:541,t:1528143825462};\\\", \\\"{x:333,y:541,t:1528143825478};\\\", \\\"{x:330,y:541,t:1528143825494};\\\", \\\"{x:325,y:541,t:1528143825511};\\\", \\\"{x:317,y:541,t:1528143825528};\\\", \\\"{x:311,y:541,t:1528143825544};\\\", \\\"{x:307,y:541,t:1528143825561};\\\", \\\"{x:304,y:541,t:1528143825578};\\\", \\\"{x:299,y:541,t:1528143825594};\\\", \\\"{x:296,y:541,t:1528143825612};\\\", \\\"{x:292,y:540,t:1528143825628};\\\", \\\"{x:286,y:537,t:1528143825645};\\\", \\\"{x:276,y:534,t:1528143825662};\\\", \\\"{x:264,y:528,t:1528143825680};\\\", \\\"{x:257,y:525,t:1528143825694};\\\", \\\"{x:250,y:523,t:1528143825712};\\\", \\\"{x:240,y:521,t:1528143825728};\\\", \\\"{x:229,y:521,t:1528143825745};\\\", \\\"{x:213,y:521,t:1528143825761};\\\", \\\"{x:200,y:521,t:1528143825779};\\\", \\\"{x:192,y:521,t:1528143825795};\\\", \\\"{x:185,y:520,t:1528143825811};\\\", \\\"{x:182,y:520,t:1528143825829};\\\", \\\"{x:177,y:520,t:1528143825845};\\\", \\\"{x:175,y:519,t:1528143825862};\\\", \\\"{x:171,y:518,t:1528143825878};\\\", \\\"{x:170,y:518,t:1528143825895};\\\", \\\"{x:170,y:517,t:1528143825918};\\\", \\\"{x:169,y:516,t:1528143825942};\\\", \\\"{x:168,y:516,t:1528143825951};\\\", \\\"{x:165,y:513,t:1528143825962};\\\", \\\"{x:162,y:511,t:1528143825978};\\\", \\\"{x:159,y:508,t:1528143825996};\\\", \\\"{x:156,y:507,t:1528143826012};\\\", \\\"{x:155,y:506,t:1528143826028};\\\", \\\"{x:153,y:505,t:1528143826045};\\\", \\\"{x:158,y:504,t:1528143826646};\\\", \\\"{x:177,y:503,t:1528143826662};\\\", \\\"{x:223,y:507,t:1528143826679};\\\", \\\"{x:282,y:517,t:1528143826695};\\\", \\\"{x:334,y:530,t:1528143826713};\\\", \\\"{x:376,y:541,t:1528143826729};\\\", \\\"{x:399,y:548,t:1528143826745};\\\", \\\"{x:423,y:556,t:1528143826763};\\\", \\\"{x:441,y:563,t:1528143826780};\\\", \\\"{x:454,y:568,t:1528143826795};\\\", \\\"{x:463,y:571,t:1528143826812};\\\", \\\"{x:470,y:575,t:1528143826829};\\\", \\\"{x:474,y:577,t:1528143826845};\\\", \\\"{x:483,y:579,t:1528143826863};\\\", \\\"{x:493,y:580,t:1528143826880};\\\", \\\"{x:506,y:582,t:1528143826898};\\\", \\\"{x:513,y:583,t:1528143826912};\\\", \\\"{x:523,y:583,t:1528143826929};\\\", \\\"{x:535,y:586,t:1528143826947};\\\", \\\"{x:557,y:589,t:1528143826962};\\\", \\\"{x:578,y:594,t:1528143826979};\\\", \\\"{x:597,y:597,t:1528143826996};\\\", \\\"{x:614,y:599,t:1528143827012};\\\", \\\"{x:631,y:600,t:1528143827030};\\\", \\\"{x:650,y:602,t:1528143827046};\\\", \\\"{x:659,y:602,t:1528143827063};\\\", \\\"{x:666,y:602,t:1528143827079};\\\", \\\"{x:670,y:602,t:1528143827096};\\\", \\\"{x:675,y:602,t:1528143827112};\\\", \\\"{x:682,y:602,t:1528143827130};\\\", \\\"{x:696,y:602,t:1528143827147};\\\", \\\"{x:712,y:602,t:1528143827162};\\\", \\\"{x:731,y:602,t:1528143827180};\\\", \\\"{x:757,y:602,t:1528143827196};\\\", \\\"{x:785,y:602,t:1528143827212};\\\", \\\"{x:811,y:602,t:1528143827229};\\\", \\\"{x:840,y:602,t:1528143827246};\\\", \\\"{x:851,y:603,t:1528143827262};\\\", \\\"{x:861,y:604,t:1528143827280};\\\", \\\"{x:871,y:605,t:1528143827297};\\\", \\\"{x:885,y:607,t:1528143827312};\\\", \\\"{x:903,y:609,t:1528143827329};\\\", \\\"{x:920,y:613,t:1528143827346};\\\", \\\"{x:924,y:613,t:1528143827363};\\\", \\\"{x:926,y:613,t:1528143827380};\\\", \\\"{x:927,y:614,t:1528143827396};\\\", \\\"{x:930,y:616,t:1528143827412};\\\", \\\"{x:942,y:622,t:1528143827430};\\\", \\\"{x:969,y:633,t:1528143827447};\\\", \\\"{x:985,y:638,t:1528143827464};\\\", \\\"{x:997,y:643,t:1528143827479};\\\", \\\"{x:1011,y:645,t:1528143827497};\\\", \\\"{x:1027,y:650,t:1528143827513};\\\", \\\"{x:1049,y:653,t:1528143827530};\\\", \\\"{x:1073,y:654,t:1528143827547};\\\", \\\"{x:1105,y:655,t:1528143827564};\\\", \\\"{x:1131,y:655,t:1528143827580};\\\", \\\"{x:1157,y:655,t:1528143827596};\\\", \\\"{x:1177,y:655,t:1528143827614};\\\", \\\"{x:1205,y:655,t:1528143827629};\\\", \\\"{x:1214,y:653,t:1528143827647};\\\", \\\"{x:1218,y:653,t:1528143827663};\\\", \\\"{x:1219,y:653,t:1528143827681};\\\", \\\"{x:1220,y:653,t:1528143827710};\\\", \\\"{x:1220,y:652,t:1528143828054};\\\", \\\"{x:1223,y:651,t:1528143828064};\\\", \\\"{x:1226,y:649,t:1528143828082};\\\", \\\"{x:1228,y:648,t:1528143828097};\\\", \\\"{x:1231,y:647,t:1528143828115};\\\", \\\"{x:1233,y:646,t:1528143828132};\\\", \\\"{x:1234,y:646,t:1528143828149};\\\", \\\"{x:1235,y:646,t:1528143828164};\\\", \\\"{x:1236,y:646,t:1528143828182};\\\", \\\"{x:1246,y:646,t:1528143828198};\\\", \\\"{x:1259,y:646,t:1528143828214};\\\", \\\"{x:1275,y:649,t:1528143828231};\\\", \\\"{x:1291,y:653,t:1528143828248};\\\", \\\"{x:1307,y:658,t:1528143828266};\\\", \\\"{x:1317,y:662,t:1528143828282};\\\", \\\"{x:1325,y:666,t:1528143828299};\\\", \\\"{x:1331,y:669,t:1528143828315};\\\", \\\"{x:1338,y:672,t:1528143828332};\\\", \\\"{x:1341,y:674,t:1528143828348};\\\", \\\"{x:1342,y:674,t:1528143828366};\\\", \\\"{x:1343,y:675,t:1528143828381};\\\", \\\"{x:1344,y:675,t:1528143828399};\\\", \\\"{x:1344,y:676,t:1528143828422};\\\", \\\"{x:1344,y:677,t:1528143828433};\\\", \\\"{x:1344,y:679,t:1528143828448};\\\", \\\"{x:1344,y:681,t:1528143828465};\\\", \\\"{x:1343,y:684,t:1528143828483};\\\", \\\"{x:1343,y:687,t:1528143828499};\\\", \\\"{x:1343,y:691,t:1528143828516};\\\", \\\"{x:1345,y:695,t:1528143828533};\\\", \\\"{x:1348,y:699,t:1528143828550};\\\", \\\"{x:1352,y:703,t:1528143828566};\\\", \\\"{x:1361,y:708,t:1528143828582};\\\", \\\"{x:1365,y:711,t:1528143828599};\\\", \\\"{x:1368,y:712,t:1528143828616};\\\", \\\"{x:1369,y:714,t:1528143828632};\\\", \\\"{x:1369,y:713,t:1528143828799};\\\", \\\"{x:1368,y:710,t:1528143828817};\\\", \\\"{x:1368,y:707,t:1528143828833};\\\", \\\"{x:1367,y:706,t:1528143828850};\\\", \\\"{x:1366,y:704,t:1528143828867};\\\", \\\"{x:1365,y:703,t:1528143828887};\\\", \\\"{x:1364,y:703,t:1528143828935};\\\", \\\"{x:1362,y:702,t:1528143828958};\\\", \\\"{x:1361,y:702,t:1528143828974};\\\", \\\"{x:1360,y:701,t:1528143828984};\\\", \\\"{x:1358,y:700,t:1528143829001};\\\", \\\"{x:1357,y:699,t:1528143829017};\\\", \\\"{x:1356,y:699,t:1528143829034};\\\", \\\"{x:1353,y:698,t:1528143829052};\\\", \\\"{x:1351,y:697,t:1528143829066};\\\", \\\"{x:1350,y:696,t:1528143829083};\\\", \\\"{x:1349,y:696,t:1528143829100};\\\", \\\"{x:1348,y:696,t:1528143829166};\\\", \\\"{x:1347,y:693,t:1528143830022};\\\", \\\"{x:1344,y:688,t:1528143830036};\\\", \\\"{x:1340,y:682,t:1528143830053};\\\", \\\"{x:1335,y:675,t:1528143830070};\\\", \\\"{x:1329,y:655,t:1528143830086};\\\", \\\"{x:1327,y:642,t:1528143830103};\\\", \\\"{x:1326,y:631,t:1528143830119};\\\", \\\"{x:1324,y:619,t:1528143830137};\\\", \\\"{x:1321,y:608,t:1528143830153};\\\", \\\"{x:1317,y:598,t:1528143830169};\\\", \\\"{x:1312,y:588,t:1528143830186};\\\", \\\"{x:1307,y:578,t:1528143830202};\\\", \\\"{x:1298,y:569,t:1528143830220};\\\", \\\"{x:1292,y:563,t:1528143830236};\\\", \\\"{x:1283,y:557,t:1528143830254};\\\", \\\"{x:1279,y:555,t:1528143830269};\\\", \\\"{x:1276,y:553,t:1528143830287};\\\", \\\"{x:1274,y:553,t:1528143830304};\\\", \\\"{x:1273,y:553,t:1528143830326};\\\", \\\"{x:1272,y:553,t:1528143830336};\\\", \\\"{x:1271,y:553,t:1528143830354};\\\", \\\"{x:1270,y:553,t:1528143830370};\\\", \\\"{x:1269,y:553,t:1528143830398};\\\", \\\"{x:1268,y:553,t:1528143830406};\\\", \\\"{x:1267,y:553,t:1528143830470};\\\", \\\"{x:1266,y:553,t:1528143830494};\\\", \\\"{x:1265,y:553,t:1528143830542};\\\", \\\"{x:1265,y:554,t:1528143830554};\\\", \\\"{x:1264,y:555,t:1528143830571};\\\", \\\"{x:1263,y:555,t:1528143830587};\\\", \\\"{x:1263,y:556,t:1528143830604};\\\", \\\"{x:1261,y:558,t:1528143830621};\\\", \\\"{x:1260,y:560,t:1528143830638};\\\", \\\"{x:1258,y:563,t:1528143830654};\\\", \\\"{x:1256,y:566,t:1528143830671};\\\", \\\"{x:1255,y:567,t:1528143830688};\\\", \\\"{x:1254,y:569,t:1528143830705};\\\", \\\"{x:1253,y:570,t:1528143830721};\\\", \\\"{x:1252,y:572,t:1528143830739};\\\", \\\"{x:1252,y:573,t:1528143830755};\\\", \\\"{x:1252,y:576,t:1528143830771};\\\", \\\"{x:1252,y:577,t:1528143830788};\\\", \\\"{x:1252,y:578,t:1528143830805};\\\", \\\"{x:1252,y:579,t:1528143830855};\\\", \\\"{x:1253,y:579,t:1528143830872};\\\", \\\"{x:1261,y:579,t:1528143830888};\\\", \\\"{x:1268,y:579,t:1528143830905};\\\", \\\"{x:1276,y:577,t:1528143830922};\\\", \\\"{x:1283,y:575,t:1528143830937};\\\", \\\"{x:1288,y:572,t:1528143830955};\\\", \\\"{x:1290,y:572,t:1528143830972};\\\", \\\"{x:1292,y:570,t:1528143830989};\\\", \\\"{x:1292,y:569,t:1528143831223};\\\", \\\"{x:1291,y:569,t:1528143831239};\\\", \\\"{x:1290,y:569,t:1528143831256};\\\", \\\"{x:1288,y:569,t:1528143831274};\\\", \\\"{x:1287,y:569,t:1528143831289};\\\", \\\"{x:1286,y:569,t:1528143831311};\\\", \\\"{x:1285,y:569,t:1528143831327};\\\", \\\"{x:1284,y:569,t:1528143831351};\\\", \\\"{x:1283,y:569,t:1528143831438};\\\", \\\"{x:1282,y:569,t:1528143831671};\\\", \\\"{x:1288,y:571,t:1528143835223};\\\", \\\"{x:1300,y:584,t:1528143835233};\\\", \\\"{x:1313,y:595,t:1528143835250};\\\", \\\"{x:1326,y:610,t:1528143835266};\\\", \\\"{x:1337,y:625,t:1528143835283};\\\", \\\"{x:1349,y:642,t:1528143835300};\\\", \\\"{x:1359,y:658,t:1528143835315};\\\", \\\"{x:1372,y:677,t:1528143835333};\\\", \\\"{x:1382,y:696,t:1528143835350};\\\", \\\"{x:1392,y:728,t:1528143835367};\\\", \\\"{x:1398,y:751,t:1528143835383};\\\", \\\"{x:1402,y:770,t:1528143835399};\\\", \\\"{x:1402,y:787,t:1528143835417};\\\", \\\"{x:1402,y:798,t:1528143835433};\\\", \\\"{x:1402,y:803,t:1528143835450};\\\", \\\"{x:1402,y:807,t:1528143835466};\\\", \\\"{x:1401,y:807,t:1528143835483};\\\", \\\"{x:1400,y:809,t:1528143835503};\\\", \\\"{x:1399,y:809,t:1528143835517};\\\", \\\"{x:1395,y:809,t:1528143835534};\\\", \\\"{x:1387,y:809,t:1528143835550};\\\", \\\"{x:1370,y:807,t:1528143835567};\\\", \\\"{x:1357,y:804,t:1528143835583};\\\", \\\"{x:1348,y:800,t:1528143835600};\\\", \\\"{x:1343,y:799,t:1528143835616};\\\", \\\"{x:1338,y:796,t:1528143835633};\\\", \\\"{x:1334,y:794,t:1528143835650};\\\", \\\"{x:1331,y:791,t:1528143835667};\\\", \\\"{x:1329,y:788,t:1528143835684};\\\", \\\"{x:1327,y:784,t:1528143835700};\\\", \\\"{x:1326,y:782,t:1528143835718};\\\", \\\"{x:1325,y:777,t:1528143835733};\\\", \\\"{x:1325,y:770,t:1528143835751};\\\", \\\"{x:1326,y:767,t:1528143835767};\\\", \\\"{x:1328,y:766,t:1528143835783};\\\", \\\"{x:1329,y:766,t:1528143835801};\\\", \\\"{x:1331,y:766,t:1528143835817};\\\", \\\"{x:1333,y:765,t:1528143835834};\\\", \\\"{x:1334,y:765,t:1528143835851};\\\", \\\"{x:1335,y:765,t:1528143835867};\\\", \\\"{x:1336,y:765,t:1528143835885};\\\", \\\"{x:1337,y:765,t:1528143835903};\\\", \\\"{x:1337,y:766,t:1528143835959};\\\", \\\"{x:1337,y:767,t:1528143835983};\\\", \\\"{x:1337,y:768,t:1528143835991};\\\", \\\"{x:1337,y:769,t:1528143836000};\\\", \\\"{x:1337,y:770,t:1528143836017};\\\", \\\"{x:1337,y:773,t:1528143836035};\\\", \\\"{x:1336,y:773,t:1528143836079};\\\", \\\"{x:1335,y:773,t:1528143836095};\\\", \\\"{x:1334,y:773,t:1528143836110};\\\", \\\"{x:1333,y:773,t:1528143836119};\\\", \\\"{x:1332,y:773,t:1528143836143};\\\", \\\"{x:1331,y:773,t:1528143836175};\\\", \\\"{x:1330,y:772,t:1528143836185};\\\", \\\"{x:1328,y:773,t:1528143836271};\\\", \\\"{x:1328,y:774,t:1528143836302};\\\", \\\"{x:1328,y:775,t:1528143836415};\\\", \\\"{x:1327,y:778,t:1528143836431};\\\", \\\"{x:1325,y:780,t:1528143836438};\\\", \\\"{x:1324,y:784,t:1528143836452};\\\", \\\"{x:1320,y:792,t:1528143836468};\\\", \\\"{x:1315,y:806,t:1528143836486};\\\", \\\"{x:1305,y:825,t:1528143836502};\\\", \\\"{x:1297,y:839,t:1528143836519};\\\", \\\"{x:1290,y:851,t:1528143836536};\\\", \\\"{x:1287,y:859,t:1528143836553};\\\", \\\"{x:1283,y:867,t:1528143836570};\\\", \\\"{x:1279,y:874,t:1528143836585};\\\", \\\"{x:1277,y:878,t:1528143836602};\\\", \\\"{x:1275,y:884,t:1528143836620};\\\", \\\"{x:1274,y:887,t:1528143836635};\\\", \\\"{x:1273,y:888,t:1528143836653};\\\", \\\"{x:1273,y:890,t:1528143836670};\\\", \\\"{x:1273,y:889,t:1528143836823};\\\", \\\"{x:1275,y:884,t:1528143836836};\\\", \\\"{x:1283,y:872,t:1528143836854};\\\", \\\"{x:1299,y:852,t:1528143836871};\\\", \\\"{x:1306,y:841,t:1528143836887};\\\", \\\"{x:1312,y:830,t:1528143836903};\\\", \\\"{x:1316,y:824,t:1528143836920};\\\", \\\"{x:1321,y:816,t:1528143836936};\\\", \\\"{x:1324,y:810,t:1528143836954};\\\", \\\"{x:1327,y:807,t:1528143836969};\\\", \\\"{x:1330,y:804,t:1528143836986};\\\", \\\"{x:1331,y:803,t:1528143837003};\\\", \\\"{x:1332,y:802,t:1528143837031};\\\", \\\"{x:1332,y:801,t:1528143837055};\\\", \\\"{x:1333,y:801,t:1528143837071};\\\", \\\"{x:1331,y:801,t:1528143837183};\\\", \\\"{x:1329,y:802,t:1528143837190};\\\", \\\"{x:1324,y:806,t:1528143837204};\\\", \\\"{x:1315,y:816,t:1528143837221};\\\", \\\"{x:1307,y:832,t:1528143837238};\\\", \\\"{x:1299,y:848,t:1528143837254};\\\", \\\"{x:1291,y:873,t:1528143837270};\\\", \\\"{x:1288,y:883,t:1528143837287};\\\", \\\"{x:1288,y:889,t:1528143837304};\\\", \\\"{x:1288,y:899,t:1528143837320};\\\", \\\"{x:1288,y:911,t:1528143837337};\\\", \\\"{x:1288,y:925,t:1528143837353};\\\", \\\"{x:1288,y:934,t:1528143837370};\\\", \\\"{x:1288,y:937,t:1528143837387};\\\", \\\"{x:1288,y:940,t:1528143837404};\\\", \\\"{x:1288,y:941,t:1528143837430};\\\", \\\"{x:1287,y:942,t:1528143837510};\\\", \\\"{x:1286,y:942,t:1528143837521};\\\", \\\"{x:1285,y:942,t:1528143837558};\\\", \\\"{x:1284,y:942,t:1528143837575};\\\", \\\"{x:1283,y:942,t:1528143837590};\\\", \\\"{x:1282,y:942,t:1528143837604};\\\", \\\"{x:1281,y:944,t:1528143837621};\\\", \\\"{x:1279,y:944,t:1528143837638};\\\", \\\"{x:1277,y:945,t:1528143837654};\\\", \\\"{x:1276,y:945,t:1528143837671};\\\", \\\"{x:1274,y:945,t:1528143837689};\\\", \\\"{x:1273,y:947,t:1528143837705};\\\", \\\"{x:1272,y:947,t:1528143837721};\\\", \\\"{x:1270,y:948,t:1528143837739};\\\", \\\"{x:1269,y:949,t:1528143837774};\\\", \\\"{x:1269,y:950,t:1528143837791};\\\", \\\"{x:1268,y:950,t:1528143837806};\\\", \\\"{x:1267,y:951,t:1528143837847};\\\", \\\"{x:1266,y:951,t:1528143837879};\\\", \\\"{x:1266,y:952,t:1528143837943};\\\", \\\"{x:1266,y:953,t:1528143837959};\\\", \\\"{x:1265,y:953,t:1528143838127};\\\", \\\"{x:1264,y:954,t:1528143838142};\\\", \\\"{x:1266,y:943,t:1528143858551};\\\", \\\"{x:1277,y:928,t:1528143858558};\\\", \\\"{x:1291,y:904,t:1528143858572};\\\", \\\"{x:1326,y:858,t:1528143858589};\\\", \\\"{x:1347,y:822,t:1528143858605};\\\", \\\"{x:1362,y:796,t:1528143858622};\\\", \\\"{x:1364,y:790,t:1528143858638};\\\", \\\"{x:1365,y:786,t:1528143858656};\\\", \\\"{x:1366,y:784,t:1528143858672};\\\", \\\"{x:1366,y:783,t:1528143858694};\\\", \\\"{x:1366,y:781,t:1528143858718};\\\", \\\"{x:1367,y:781,t:1528143858727};\\\", \\\"{x:1367,y:780,t:1528143858750};\\\", \\\"{x:1366,y:778,t:1528143858895};\\\", \\\"{x:1363,y:775,t:1528143858906};\\\", \\\"{x:1359,y:772,t:1528143858924};\\\", \\\"{x:1358,y:771,t:1528143858940};\\\", \\\"{x:1357,y:770,t:1528143858956};\\\", \\\"{x:1357,y:769,t:1528143858973};\\\", \\\"{x:1356,y:769,t:1528143859103};\\\", \\\"{x:1356,y:773,t:1528143859111};\\\", \\\"{x:1356,y:779,t:1528143859123};\\\", \\\"{x:1356,y:791,t:1528143859141};\\\", \\\"{x:1356,y:802,t:1528143859157};\\\", \\\"{x:1356,y:815,t:1528143859174};\\\", \\\"{x:1360,y:830,t:1528143859189};\\\", \\\"{x:1362,y:843,t:1528143859207};\\\", \\\"{x:1366,y:853,t:1528143859223};\\\", \\\"{x:1372,y:865,t:1528143859240};\\\", \\\"{x:1376,y:876,t:1528143859257};\\\", \\\"{x:1381,y:884,t:1528143859273};\\\", \\\"{x:1384,y:891,t:1528143859290};\\\", \\\"{x:1386,y:895,t:1528143859307};\\\", \\\"{x:1388,y:899,t:1528143859323};\\\", \\\"{x:1391,y:902,t:1528143859340};\\\", \\\"{x:1393,y:906,t:1528143859357};\\\", \\\"{x:1400,y:912,t:1528143859374};\\\", \\\"{x:1403,y:917,t:1528143859390};\\\", \\\"{x:1407,y:920,t:1528143859407};\\\", \\\"{x:1409,y:923,t:1528143859424};\\\", \\\"{x:1411,y:926,t:1528143859440};\\\", \\\"{x:1414,y:930,t:1528143859457};\\\", \\\"{x:1416,y:931,t:1528143859474};\\\", \\\"{x:1418,y:934,t:1528143859491};\\\", \\\"{x:1420,y:937,t:1528143859507};\\\", \\\"{x:1421,y:938,t:1528143859524};\\\", \\\"{x:1422,y:939,t:1528143859541};\\\", \\\"{x:1424,y:941,t:1528143859557};\\\", \\\"{x:1425,y:942,t:1528143859574};\\\", \\\"{x:1426,y:943,t:1528143859605};\\\", \\\"{x:1427,y:943,t:1528143859654};\\\", \\\"{x:1428,y:942,t:1528143859966};\\\", \\\"{x:1428,y:940,t:1528143859975};\\\", \\\"{x:1430,y:937,t:1528143859992};\\\", \\\"{x:1430,y:936,t:1528143860008};\\\", \\\"{x:1430,y:935,t:1528143860025};\\\", \\\"{x:1429,y:932,t:1528143860042};\\\", \\\"{x:1429,y:931,t:1528143860059};\\\", \\\"{x:1429,y:932,t:1528143860238};\\\", \\\"{x:1430,y:933,t:1528143860245};\\\", \\\"{x:1431,y:933,t:1528143860259};\\\", \\\"{x:1433,y:933,t:1528143860276};\\\", \\\"{x:1434,y:933,t:1528143860292};\\\", \\\"{x:1436,y:934,t:1528143860325};\\\", \\\"{x:1437,y:935,t:1528143860343};\\\", \\\"{x:1438,y:938,t:1528143860359};\\\", \\\"{x:1440,y:940,t:1528143860376};\\\", \\\"{x:1441,y:941,t:1528143860393};\\\", \\\"{x:1443,y:942,t:1528143860409};\\\", \\\"{x:1447,y:943,t:1528143860426};\\\", \\\"{x:1450,y:944,t:1528143860443};\\\", \\\"{x:1451,y:945,t:1528143860460};\\\", \\\"{x:1453,y:946,t:1528143860476};\\\", \\\"{x:1454,y:947,t:1528143860493};\\\", \\\"{x:1456,y:949,t:1528143860510};\\\", \\\"{x:1456,y:948,t:1528143860742};\\\", \\\"{x:1456,y:947,t:1528143860750};\\\", \\\"{x:1455,y:944,t:1528143860761};\\\", \\\"{x:1452,y:940,t:1528143860777};\\\", \\\"{x:1447,y:933,t:1528143860794};\\\", \\\"{x:1446,y:931,t:1528143860810};\\\", \\\"{x:1444,y:927,t:1528143860827};\\\", \\\"{x:1441,y:922,t:1528143860844};\\\", \\\"{x:1437,y:916,t:1528143860860};\\\", \\\"{x:1433,y:912,t:1528143860878};\\\", \\\"{x:1431,y:907,t:1528143860894};\\\", \\\"{x:1431,y:905,t:1528143860911};\\\", \\\"{x:1430,y:897,t:1528143860927};\\\", \\\"{x:1430,y:886,t:1528143860944};\\\", \\\"{x:1429,y:868,t:1528143860961};\\\", \\\"{x:1424,y:849,t:1528143860977};\\\", \\\"{x:1422,y:841,t:1528143860994};\\\", \\\"{x:1417,y:827,t:1528143861011};\\\", \\\"{x:1413,y:821,t:1528143861027};\\\", \\\"{x:1409,y:814,t:1528143861044};\\\", \\\"{x:1403,y:803,t:1528143861061};\\\", \\\"{x:1398,y:795,t:1528143861078};\\\", \\\"{x:1394,y:790,t:1528143861094};\\\", \\\"{x:1392,y:788,t:1528143861112};\\\", \\\"{x:1390,y:785,t:1528143861128};\\\", \\\"{x:1388,y:783,t:1528143861144};\\\", \\\"{x:1386,y:781,t:1528143861161};\\\", \\\"{x:1384,y:781,t:1528143861179};\\\", \\\"{x:1381,y:779,t:1528143861196};\\\", \\\"{x:1377,y:779,t:1528143861211};\\\", \\\"{x:1374,y:778,t:1528143861229};\\\", \\\"{x:1370,y:778,t:1528143861246};\\\", \\\"{x:1368,y:778,t:1528143861261};\\\", \\\"{x:1365,y:778,t:1528143861279};\\\", \\\"{x:1360,y:778,t:1528143861295};\\\", \\\"{x:1350,y:778,t:1528143861312};\\\", \\\"{x:1340,y:777,t:1528143861328};\\\", \\\"{x:1325,y:775,t:1528143861346};\\\", \\\"{x:1313,y:775,t:1528143861363};\\\", \\\"{x:1301,y:774,t:1528143861379};\\\", \\\"{x:1287,y:773,t:1528143861396};\\\", \\\"{x:1272,y:773,t:1528143861412};\\\", \\\"{x:1255,y:773,t:1528143861429};\\\", \\\"{x:1233,y:772,t:1528143861445};\\\", \\\"{x:1182,y:772,t:1528143861462};\\\", \\\"{x:1149,y:772,t:1528143861479};\\\", \\\"{x:1099,y:772,t:1528143861495};\\\", \\\"{x:1036,y:776,t:1528143861512};\\\", \\\"{x:961,y:785,t:1528143861529};\\\", \\\"{x:880,y:798,t:1528143861545};\\\", \\\"{x:806,y:816,t:1528143861562};\\\", \\\"{x:730,y:840,t:1528143861579};\\\", \\\"{x:674,y:858,t:1528143861595};\\\", \\\"{x:624,y:872,t:1528143861612};\\\", \\\"{x:599,y:878,t:1528143861629};\\\", \\\"{x:574,y:881,t:1528143861645};\\\", \\\"{x:554,y:886,t:1528143861662};\\\", \\\"{x:533,y:895,t:1528143861679};\\\", \\\"{x:530,y:896,t:1528143861696};\\\", \\\"{x:528,y:895,t:1528143861966};\\\", \\\"{x:526,y:890,t:1528143861980};\\\", \\\"{x:525,y:886,t:1528143861996};\\\", \\\"{x:525,y:884,t:1528143862014};\\\", \\\"{x:526,y:882,t:1528143862030};\\\", \\\"{x:532,y:879,t:1528143862047};\\\", \\\"{x:539,y:874,t:1528143862064};\\\", \\\"{x:547,y:870,t:1528143862080};\\\", \\\"{x:559,y:865,t:1528143862098};\\\", \\\"{x:576,y:858,t:1528143862113};\\\", \\\"{x:593,y:851,t:1528143862130};\\\", \\\"{x:612,y:845,t:1528143862147};\\\", \\\"{x:633,y:839,t:1528143862164};\\\", \\\"{x:680,y:812,t:1528143862181};\\\", \\\"{x:767,y:765,t:1528143862198};\\\", \\\"{x:913,y:670,t:1528143862215};\\\", \\\"{x:1014,y:597,t:1528143862231};\\\", \\\"{x:1100,y:532,t:1528143862248};\\\", \\\"{x:1162,y:489,t:1528143862265};\\\", \\\"{x:1199,y:462,t:1528143862281};\\\", \\\"{x:1221,y:447,t:1528143862298};\\\", \\\"{x:1237,y:438,t:1528143862314};\\\", \\\"{x:1251,y:430,t:1528143862331};\\\", \\\"{x:1259,y:426,t:1528143862348};\\\", \\\"{x:1270,y:420,t:1528143862364};\\\", \\\"{x:1284,y:411,t:1528143862382};\\\", \\\"{x:1293,y:407,t:1528143862397};\\\", \\\"{x:1304,y:398,t:1528143862414};\\\", \\\"{x:1309,y:394,t:1528143862431};\\\", \\\"{x:1312,y:391,t:1528143862448};\\\", \\\"{x:1318,y:388,t:1528143862465};\\\", \\\"{x:1331,y:382,t:1528143862482};\\\", \\\"{x:1355,y:373,t:1528143862498};\\\", \\\"{x:1380,y:367,t:1528143862514};\\\", \\\"{x:1406,y:360,t:1528143862532};\\\", \\\"{x:1435,y:356,t:1528143862549};\\\", \\\"{x:1457,y:354,t:1528143862565};\\\", \\\"{x:1475,y:350,t:1528143862581};\\\", \\\"{x:1499,y:349,t:1528143862598};\\\", \\\"{x:1512,y:349,t:1528143862615};\\\", \\\"{x:1518,y:349,t:1528143862632};\\\", \\\"{x:1521,y:349,t:1528143862649};\\\", \\\"{x:1522,y:349,t:1528143862666};\\\", \\\"{x:1523,y:349,t:1528143862682};\\\", \\\"{x:1524,y:349,t:1528143862773};\\\", \\\"{x:1524,y:350,t:1528143862781};\\\", \\\"{x:1520,y:352,t:1528143862798};\\\", \\\"{x:1517,y:354,t:1528143862815};\\\", \\\"{x:1515,y:355,t:1528143862832};\\\", \\\"{x:1513,y:355,t:1528143862848};\\\", \\\"{x:1512,y:356,t:1528143862869};\\\", \\\"{x:1512,y:357,t:1528143862882};\\\", \\\"{x:1511,y:357,t:1528143862899};\\\", \\\"{x:1510,y:358,t:1528143862915};\\\", \\\"{x:1507,y:358,t:1528143862933};\\\", \\\"{x:1506,y:358,t:1528143862949};\\\", \\\"{x:1505,y:360,t:1528143862965};\\\", \\\"{x:1503,y:360,t:1528143862982};\\\", \\\"{x:1502,y:360,t:1528143862999};\\\", \\\"{x:1500,y:361,t:1528143863016};\\\", \\\"{x:1498,y:362,t:1528143863032};\\\", \\\"{x:1496,y:363,t:1528143863049};\\\", \\\"{x:1494,y:364,t:1528143863066};\\\", \\\"{x:1490,y:366,t:1528143863082};\\\", \\\"{x:1488,y:367,t:1528143863099};\\\", \\\"{x:1488,y:368,t:1528143863116};\\\", \\\"{x:1487,y:368,t:1528143863166};\\\", \\\"{x:1485,y:368,t:1528143863222};\\\", \\\"{x:1484,y:368,t:1528143863233};\\\", \\\"{x:1480,y:371,t:1528143863249};\\\", \\\"{x:1477,y:373,t:1528143863266};\\\", \\\"{x:1473,y:377,t:1528143863283};\\\", \\\"{x:1472,y:378,t:1528143863300};\\\", \\\"{x:1471,y:379,t:1528143863316};\\\", \\\"{x:1469,y:380,t:1528143863333};\\\", \\\"{x:1469,y:381,t:1528143863351};\\\", \\\"{x:1468,y:381,t:1528143863373};\\\", \\\"{x:1468,y:382,t:1528143863397};\\\", \\\"{x:1466,y:382,t:1528143863790};\\\", \\\"{x:1464,y:382,t:1528143863801};\\\", \\\"{x:1459,y:386,t:1528143863818};\\\", \\\"{x:1450,y:393,t:1528143863834};\\\", \\\"{x:1441,y:400,t:1528143863851};\\\", \\\"{x:1423,y:415,t:1528143863869};\\\", \\\"{x:1408,y:426,t:1528143863884};\\\", \\\"{x:1394,y:437,t:1528143863901};\\\", \\\"{x:1374,y:455,t:1528143863917};\\\", \\\"{x:1364,y:466,t:1528143863934};\\\", \\\"{x:1354,y:477,t:1528143863951};\\\", \\\"{x:1349,y:485,t:1528143863968};\\\", \\\"{x:1343,y:495,t:1528143863985};\\\", \\\"{x:1338,y:510,t:1528143864001};\\\", \\\"{x:1329,y:529,t:1528143864018};\\\", \\\"{x:1323,y:543,t:1528143864035};\\\", \\\"{x:1315,y:556,t:1528143864051};\\\", \\\"{x:1313,y:559,t:1528143864068};\\\", \\\"{x:1310,y:563,t:1528143864085};\\\", \\\"{x:1308,y:566,t:1528143864102};\\\", \\\"{x:1306,y:569,t:1528143864119};\\\", \\\"{x:1302,y:574,t:1528143864135};\\\", \\\"{x:1299,y:579,t:1528143864152};\\\", \\\"{x:1294,y:587,t:1528143864169};\\\", \\\"{x:1289,y:599,t:1528143864186};\\\", \\\"{x:1284,y:609,t:1528143864202};\\\", \\\"{x:1281,y:619,t:1528143864219};\\\", \\\"{x:1276,y:627,t:1528143864235};\\\", \\\"{x:1275,y:632,t:1528143864252};\\\", \\\"{x:1271,y:640,t:1528143864270};\\\", \\\"{x:1267,y:649,t:1528143864285};\\\", \\\"{x:1264,y:663,t:1528143864302};\\\", \\\"{x:1262,y:670,t:1528143864319};\\\", \\\"{x:1261,y:673,t:1528143864336};\\\", \\\"{x:1261,y:676,t:1528143864352};\\\", \\\"{x:1260,y:676,t:1528143864370};\\\", \\\"{x:1259,y:678,t:1528143864385};\\\", \\\"{x:1259,y:679,t:1528143864487};\\\", \\\"{x:1265,y:677,t:1528143864502};\\\", \\\"{x:1274,y:659,t:1528143864520};\\\", \\\"{x:1294,y:627,t:1528143864537};\\\", \\\"{x:1315,y:587,t:1528143864553};\\\", \\\"{x:1324,y:563,t:1528143864570};\\\", \\\"{x:1328,y:553,t:1528143864587};\\\", \\\"{x:1328,y:552,t:1528143864604};\\\", \\\"{x:1322,y:556,t:1528143864675};\\\", \\\"{x:1313,y:570,t:1528143864691};\\\", \\\"{x:1306,y:581,t:1528143864707};\\\", \\\"{x:1298,y:596,t:1528143864725};\\\", \\\"{x:1295,y:606,t:1528143864741};\\\", \\\"{x:1290,y:622,t:1528143864758};\\\", \\\"{x:1290,y:637,t:1528143864774};\\\", \\\"{x:1289,y:652,t:1528143864790};\\\", \\\"{x:1289,y:665,t:1528143864807};\\\", \\\"{x:1289,y:670,t:1528143864824};\\\", \\\"{x:1289,y:675,t:1528143864842};\\\", \\\"{x:1289,y:677,t:1528143864858};\\\", \\\"{x:1290,y:680,t:1528143864874};\\\", \\\"{x:1291,y:680,t:1528143864898};\\\", \\\"{x:1291,y:681,t:1528143864914};\\\", \\\"{x:1292,y:681,t:1528143864924};\\\", \\\"{x:1299,y:683,t:1528143864942};\\\", \\\"{x:1318,y:683,t:1528143864958};\\\", \\\"{x:1353,y:669,t:1528143864975};\\\", \\\"{x:1406,y:646,t:1528143864992};\\\", \\\"{x:1458,y:623,t:1528143865008};\\\", \\\"{x:1500,y:604,t:1528143865025};\\\", \\\"{x:1524,y:593,t:1528143865041};\\\", \\\"{x:1531,y:589,t:1528143865058};\\\", \\\"{x:1531,y:592,t:1528143865123};\\\", \\\"{x:1529,y:596,t:1528143865131};\\\", \\\"{x:1527,y:601,t:1528143865142};\\\", \\\"{x:1518,y:615,t:1528143865159};\\\", \\\"{x:1512,y:628,t:1528143865176};\\\", \\\"{x:1507,y:643,t:1528143865192};\\\", \\\"{x:1503,y:657,t:1528143865208};\\\", \\\"{x:1502,y:672,t:1528143865225};\\\", \\\"{x:1502,y:683,t:1528143865242};\\\", \\\"{x:1502,y:699,t:1528143865259};\\\", \\\"{x:1502,y:704,t:1528143865276};\\\", \\\"{x:1502,y:707,t:1528143865292};\\\", \\\"{x:1502,y:709,t:1528143865308};\\\", \\\"{x:1503,y:711,t:1528143865325};\\\", \\\"{x:1503,y:712,t:1528143865343};\\\", \\\"{x:1505,y:715,t:1528143865358};\\\", \\\"{x:1505,y:718,t:1528143865376};\\\", \\\"{x:1507,y:724,t:1528143865392};\\\", \\\"{x:1510,y:731,t:1528143865410};\\\", \\\"{x:1514,y:744,t:1528143865426};\\\", \\\"{x:1522,y:757,t:1528143865442};\\\", \\\"{x:1525,y:767,t:1528143865459};\\\", \\\"{x:1530,y:774,t:1528143865475};\\\", \\\"{x:1535,y:782,t:1528143865492};\\\", \\\"{x:1542,y:790,t:1528143865509};\\\", \\\"{x:1546,y:794,t:1528143865526};\\\", \\\"{x:1561,y:803,t:1528143865542};\\\", \\\"{x:1570,y:808,t:1528143865559};\\\", \\\"{x:1589,y:814,t:1528143865576};\\\", \\\"{x:1609,y:817,t:1528143865592};\\\", \\\"{x:1628,y:820,t:1528143865609};\\\", \\\"{x:1646,y:829,t:1528143865625};\\\", \\\"{x:1656,y:831,t:1528143865642};\\\", \\\"{x:1663,y:836,t:1528143865659};\\\", \\\"{x:1665,y:836,t:1528143865676};\\\", \\\"{x:1665,y:834,t:1528143865698};\\\", \\\"{x:1663,y:833,t:1528143865710};\\\", \\\"{x:1659,y:830,t:1528143865726};\\\", \\\"{x:1654,y:827,t:1528143865744};\\\", \\\"{x:1649,y:824,t:1528143865759};\\\", \\\"{x:1643,y:817,t:1528143865777};\\\", \\\"{x:1634,y:805,t:1528143865794};\\\", \\\"{x:1623,y:786,t:1528143865810};\\\", \\\"{x:1601,y:757,t:1528143865827};\\\", \\\"{x:1586,y:735,t:1528143865843};\\\", \\\"{x:1575,y:719,t:1528143865861};\\\", \\\"{x:1565,y:703,t:1528143865876};\\\", \\\"{x:1558,y:692,t:1528143865894};\\\", \\\"{x:1549,y:679,t:1528143865910};\\\", \\\"{x:1541,y:667,t:1528143865926};\\\", \\\"{x:1528,y:653,t:1528143865943};\\\", \\\"{x:1515,y:638,t:1528143865960};\\\", \\\"{x:1500,y:621,t:1528143865978};\\\", \\\"{x:1479,y:605,t:1528143865994};\\\", \\\"{x:1449,y:578,t:1528143866009};\\\", \\\"{x:1421,y:553,t:1528143866028};\\\", \\\"{x:1385,y:530,t:1528143866043};\\\", \\\"{x:1331,y:511,t:1528143866061};\\\", \\\"{x:1282,y:492,t:1528143866077};\\\", \\\"{x:1225,y:482,t:1528143866094};\\\", \\\"{x:1166,y:480,t:1528143866110};\\\", \\\"{x:1080,y:480,t:1528143866127};\\\", \\\"{x:990,y:483,t:1528143866145};\\\", \\\"{x:857,y:504,t:1528143866162};\\\", \\\"{x:713,y:521,t:1528143866177};\\\", \\\"{x:452,y:537,t:1528143866194};\\\", \\\"{x:283,y:537,t:1528143866215};\\\", \\\"{x:120,y:539,t:1528143866231};\\\", \\\"{x:8,y:539,t:1528143866248};\\\", \\\"{x:8,y:538,t:1528143866282};\\\", \\\"{x:21,y:544,t:1528143866499};\\\", \\\"{x:78,y:573,t:1528143866518};\\\", \\\"{x:135,y:604,t:1528143866533};\\\", \\\"{x:174,y:623,t:1528143866548};\\\", \\\"{x:223,y:650,t:1528143866565};\\\", \\\"{x:286,y:677,t:1528143866583};\\\", \\\"{x:324,y:691,t:1528143866598};\\\", \\\"{x:340,y:696,t:1528143866614};\\\", \\\"{x:350,y:699,t:1528143866632};\\\", \\\"{x:357,y:702,t:1528143866649};\\\", \\\"{x:373,y:705,t:1528143866666};\\\", \\\"{x:386,y:706,t:1528143866682};\\\", \\\"{x:397,y:707,t:1528143866699};\\\", \\\"{x:411,y:710,t:1528143866716};\\\", \\\"{x:423,y:712,t:1528143866732};\\\", \\\"{x:432,y:715,t:1528143866749};\\\", \\\"{x:442,y:717,t:1528143866766};\\\", \\\"{x:446,y:718,t:1528143866783};\\\", \\\"{x:448,y:719,t:1528143866799};\\\", \\\"{x:449,y:719,t:1528143866825};\\\", \\\"{x:451,y:719,t:1528143866833};\\\", \\\"{x:458,y:719,t:1528143866849};\\\", \\\"{x:465,y:719,t:1528143866866};\\\", \\\"{x:470,y:719,t:1528143866883};\\\", \\\"{x:471,y:719,t:1528143866900};\\\", \\\"{x:472,y:719,t:1528143866916};\\\", \\\"{x:473,y:719,t:1528143866933};\\\", \\\"{x:474,y:719,t:1528143866994};\\\", \\\"{x:475,y:721,t:1528143867003};\\\", \\\"{x:475,y:723,t:1528143867017};\\\", \\\"{x:477,y:725,t:1528143867032};\\\", \\\"{x:478,y:725,t:1528143867050};\\\", \\\"{x:479,y:726,t:1528143867066};\\\", \\\"{x:480,y:727,t:1528143867114};\\\", \\\"{x:480,y:728,t:1528143867154};\\\", \\\"{x:480,y:726,t:1528143868898};\\\", \\\"{x:480,y:725,t:1528143868905};\\\", \\\"{x:480,y:724,t:1528143868953};\\\", \\\"{x:480,y:722,t:1528143868970};\\\", \\\"{x:480,y:721,t:1528143869066};\\\", \\\"{x:480,y:720,t:1528143869090};\\\", \\\"{x:480,y:719,t:1528143869194};\\\", \\\"{x:480,y:718,t:1528143869209};\\\", \\\"{x:480,y:717,t:1528143869222};\\\", \\\"{x:480,y:712,t:1528143869234};\\\", \\\"{x:480,y:707,t:1528143869251};\\\", \\\"{x:480,y:701,t:1528143869267};\\\", \\\"{x:478,y:695,t:1528143869283};\\\", \\\"{x:477,y:692,t:1528143869301};\\\", \\\"{x:476,y:690,t:1528143869317};\\\", \\\"{x:476,y:693,t:1528143869577};\\\", \\\"{x:476,y:697,t:1528143869586};\\\", \\\"{x:476,y:701,t:1528143869602};\\\", \\\"{x:476,y:707,t:1528143869617};\\\", \\\"{x:477,y:711,t:1528143869634};\\\", \\\"{x:477,y:715,t:1528143869651};\\\", \\\"{x:477,y:716,t:1528143869668};\\\", \\\"{x:477,y:719,t:1528143869685};\\\", \\\"{x:478,y:721,t:1528143869701};\\\", \\\"{x:478,y:725,t:1528143869718};\\\", \\\"{x:478,y:726,t:1528143869734};\\\", \\\"{x:478,y:728,t:1528143869751};\\\", \\\"{x:478,y:729,t:1528143869769};\\\", \\\"{x:478,y:730,t:1528143869784};\\\", \\\"{x:478,y:731,t:1528143869801};\\\", \\\"{x:478,y:732,t:1528143869817};\\\", \\\"{x:478,y:733,t:1528143869834};\\\", \\\"{x:478,y:734,t:1528143869865};\\\", \\\"{x:478,y:735,t:1528143869913};\\\", \\\"{x:478,y:736,t:1528143869993};\\\", \\\"{x:478,y:737,t:1528143870057};\\\", \\\"{x:478,y:738,t:1528143870274};\\\", \\\"{x:478,y:739,t:1528143870290};\\\", \\\"{x:478,y:740,t:1528143870301};\\\", \\\"{x:478,y:741,t:1528143870321};\\\", \\\"{x:478,y:742,t:1528143870335};\\\", \\\"{x:478,y:744,t:1528143870351};\\\", \\\"{x:478,y:746,t:1528143870368};\\\", \\\"{x:479,y:746,t:1528143870481};\\\", \\\"{x:480,y:746,t:1528143870490};\\\", \\\"{x:483,y:747,t:1528143870501};\\\", \\\"{x:485,y:748,t:1528143870518};\\\", \\\"{x:487,y:748,t:1528143870535};\\\", \\\"{x:488,y:748,t:1528143870578};\\\", \\\"{x:489,y:748,t:1528143870593};\\\", \\\"{x:490,y:748,t:1528143870609};\\\", \\\"{x:491,y:748,t:1528143870657};\\\", \\\"{x:491,y:747,t:1528143870889};\\\", \\\"{x:491,y:745,t:1528143870905};\\\", \\\"{x:491,y:744,t:1528143870918};\\\", \\\"{x:491,y:741,t:1528143870935};\\\", \\\"{x:491,y:740,t:1528143870952};\\\", \\\"{x:491,y:739,t:1528143870968};\\\", \\\"{x:491,y:738,t:1528143882938};\\\", \\\"{x:494,y:727,t:1528143882946};\\\", \\\"{x:499,y:701,t:1528143882962};\\\", \\\"{x:503,y:687,t:1528143882979};\\\", \\\"{x:516,y:645,t:1528143882995};\\\", \\\"{x:541,y:590,t:1528143883012};\\\", \\\"{x:576,y:532,t:1528143883029};\\\", \\\"{x:605,y:495,t:1528143883045};\\\", \\\"{x:634,y:459,t:1528143883062};\\\", \\\"{x:654,y:434,t:1528143883079};\\\", \\\"{x:665,y:423,t:1528143883095};\\\", \\\"{x:670,y:416,t:1528143883112};\\\", \\\"{x:673,y:411,t:1528143883129};\\\", \\\"{x:675,y:409,t:1528143883145};\\\", \\\"{x:676,y:406,t:1528143883162};\\\", \\\"{x:677,y:404,t:1528143883179};\\\" ] }, { \\\"rt\\\": 15064, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 14, \\\"time_elapsed\\\": 814801, \\\"internal_node_id\\\": \\\"0.0-6.0-4.0\\\", \\\"subject\\\": \\\"MKTF4\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"zulu\\\", \\\"condition\\\": \\\"211\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"ends\\\", \\\"q\\\": 10, \\\"clicks\\\": 1, \\\"explicit\\\": 2, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XInside-YFull\\\", \\\"correct\\\": 1, \\\"orth_correct\\\": 0, \\\"answer\\\": [ \\\"E\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"\\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:689,y:403,t:1528143886426};\\\", \\\"{x:730,y:403,t:1528143886434};\\\", \\\"{x:805,y:406,t:1528143886448};\\\", \\\"{x:997,y:441,t:1528143886466};\\\", \\\"{x:1191,y:480,t:1528143886481};\\\", \\\"{x:1301,y:509,t:1528143886498};\\\", \\\"{x:1303,y:510,t:1528143886515};\\\", \\\"{x:1303,y:511,t:1528143886731};\\\", \\\"{x:1300,y:512,t:1528143886738};\\\", \\\"{x:1299,y:514,t:1528143886748};\\\", \\\"{x:1295,y:524,t:1528143886765};\\\", \\\"{x:1295,y:528,t:1528143886783};\\\", \\\"{x:1295,y:536,t:1528143886798};\\\", \\\"{x:1296,y:543,t:1528143886816};\\\", \\\"{x:1297,y:550,t:1528143886832};\\\", \\\"{x:1297,y:560,t:1528143886849};\\\", \\\"{x:1297,y:574,t:1528143886865};\\\", \\\"{x:1296,y:588,t:1528143886882};\\\", \\\"{x:1294,y:592,t:1528143886898};\\\", \\\"{x:1292,y:597,t:1528143886915};\\\", \\\"{x:1290,y:599,t:1528143886933};\\\", \\\"{x:1289,y:602,t:1528143886954};\\\", \\\"{x:1288,y:602,t:1528143886966};\\\", \\\"{x:1287,y:602,t:1528143886982};\\\", \\\"{x:1285,y:603,t:1528143886999};\\\", \\\"{x:1283,y:605,t:1528143887016};\\\", \\\"{x:1282,y:606,t:1528143887034};\\\", \\\"{x:1282,y:607,t:1528143887049};\\\", \\\"{x:1282,y:609,t:1528143887066};\\\", \\\"{x:1283,y:609,t:1528143887082};\\\", \\\"{x:1284,y:609,t:1528143887099};\\\", \\\"{x:1285,y:610,t:1528143887115};\\\", \\\"{x:1285,y:611,t:1528143887133};\\\", \\\"{x:1285,y:612,t:1528143887149};\\\", \\\"{x:1286,y:612,t:1528143887165};\\\", \\\"{x:1287,y:612,t:1528143887183};\\\", \\\"{x:1287,y:613,t:1528143887210};\\\", \\\"{x:1288,y:614,t:1528143887217};\\\", \\\"{x:1289,y:614,t:1528143887250};\\\", \\\"{x:1296,y:618,t:1528143887265};\\\", \\\"{x:1304,y:623,t:1528143887282};\\\", \\\"{x:1313,y:629,t:1528143887299};\\\", \\\"{x:1319,y:633,t:1528143887315};\\\", \\\"{x:1325,y:637,t:1528143887332};\\\", \\\"{x:1328,y:640,t:1528143887349};\\\", \\\"{x:1331,y:644,t:1528143887365};\\\", \\\"{x:1334,y:649,t:1528143887382};\\\", \\\"{x:1343,y:655,t:1528143887399};\\\", \\\"{x:1352,y:662,t:1528143887415};\\\", \\\"{x:1357,y:667,t:1528143887432};\\\", \\\"{x:1363,y:675,t:1528143887449};\\\", \\\"{x:1367,y:682,t:1528143887466};\\\", \\\"{x:1369,y:687,t:1528143887482};\\\", \\\"{x:1369,y:691,t:1528143887499};\\\", \\\"{x:1370,y:693,t:1528143887516};\\\", \\\"{x:1370,y:695,t:1528143887532};\\\", \\\"{x:1370,y:697,t:1528143887549};\\\", \\\"{x:1370,y:698,t:1528143887642};\\\", \\\"{x:1370,y:700,t:1528143887650};\\\", \\\"{x:1369,y:700,t:1528143887667};\\\", \\\"{x:1364,y:703,t:1528143887682};\\\", \\\"{x:1362,y:703,t:1528143887700};\\\", \\\"{x:1361,y:703,t:1528143887717};\\\", \\\"{x:1359,y:704,t:1528143887732};\\\", \\\"{x:1358,y:706,t:1528143887795};\\\", \\\"{x:1358,y:707,t:1528143887826};\\\", \\\"{x:1357,y:709,t:1528143887834};\\\", \\\"{x:1356,y:710,t:1528143887849};\\\", \\\"{x:1356,y:711,t:1528143887866};\\\", \\\"{x:1356,y:712,t:1528143887882};\\\", \\\"{x:1356,y:713,t:1528143887914};\\\", \\\"{x:1356,y:716,t:1528143888699};\\\", \\\"{x:1360,y:721,t:1528143888706};\\\", \\\"{x:1363,y:729,t:1528143888717};\\\", \\\"{x:1370,y:740,t:1528143888734};\\\", \\\"{x:1375,y:747,t:1528143888750};\\\", \\\"{x:1379,y:755,t:1528143888766};\\\", \\\"{x:1384,y:764,t:1528143888784};\\\", \\\"{x:1387,y:773,t:1528143888800};\\\", \\\"{x:1394,y:787,t:1528143888816};\\\", \\\"{x:1400,y:803,t:1528143888834};\\\", \\\"{x:1404,y:812,t:1528143888850};\\\", \\\"{x:1405,y:820,t:1528143888867};\\\", \\\"{x:1408,y:828,t:1528143888884};\\\", \\\"{x:1409,y:834,t:1528143888900};\\\", \\\"{x:1411,y:840,t:1528143888917};\\\", \\\"{x:1414,y:847,t:1528143888933};\\\", \\\"{x:1417,y:853,t:1528143888951};\\\", \\\"{x:1421,y:862,t:1528143888967};\\\", \\\"{x:1425,y:871,t:1528143888984};\\\", \\\"{x:1429,y:881,t:1528143889001};\\\", \\\"{x:1437,y:893,t:1528143889018};\\\", \\\"{x:1440,y:895,t:1528143889034};\\\", \\\"{x:1444,y:902,t:1528143889051};\\\", \\\"{x:1446,y:907,t:1528143889067};\\\", \\\"{x:1448,y:910,t:1528143889083};\\\", \\\"{x:1452,y:913,t:1528143889100};\\\", \\\"{x:1456,y:918,t:1528143889117};\\\", \\\"{x:1461,y:926,t:1528143889134};\\\", \\\"{x:1468,y:933,t:1528143889150};\\\", \\\"{x:1472,y:939,t:1528143889168};\\\", \\\"{x:1474,y:942,t:1528143889183};\\\", \\\"{x:1476,y:946,t:1528143889200};\\\", \\\"{x:1479,y:951,t:1528143889218};\\\", \\\"{x:1482,y:955,t:1528143889234};\\\", \\\"{x:1485,y:959,t:1528143889251};\\\", \\\"{x:1486,y:961,t:1528143889268};\\\", \\\"{x:1487,y:962,t:1528143889284};\\\", \\\"{x:1488,y:964,t:1528143889301};\\\", \\\"{x:1488,y:965,t:1528143889318};\\\", \\\"{x:1488,y:966,t:1528143889418};\\\", \\\"{x:1487,y:967,t:1528143889450};\\\", \\\"{x:1485,y:967,t:1528143889642};\\\", \\\"{x:1484,y:967,t:1528143889690};\\\", \\\"{x:1482,y:967,t:1528143889762};\\\", \\\"{x:1471,y:965,t:1528143891411};\\\", \\\"{x:1399,y:915,t:1528143891418};\\\", \\\"{x:1180,y:801,t:1528143891436};\\\", \\\"{x:958,y:719,t:1528143891453};\\\", \\\"{x:745,y:653,t:1528143891469};\\\", \\\"{x:562,y:591,t:1528143891487};\\\", \\\"{x:444,y:545,t:1528143891502};\\\", \\\"{x:400,y:519,t:1528143891518};\\\", \\\"{x:380,y:502,t:1528143891534};\\\", \\\"{x:371,y:489,t:1528143891551};\\\", \\\"{x:367,y:483,t:1528143891569};\\\", \\\"{x:367,y:481,t:1528143891585};\\\", \\\"{x:367,y:479,t:1528143891609};\\\", \\\"{x:369,y:479,t:1528143891619};\\\", \\\"{x:373,y:476,t:1528143891635};\\\", \\\"{x:383,y:473,t:1528143891652};\\\", \\\"{x:403,y:467,t:1528143891669};\\\", \\\"{x:462,y:468,t:1528143891685};\\\", \\\"{x:510,y:476,t:1528143891702};\\\", \\\"{x:539,y:482,t:1528143891719};\\\", \\\"{x:554,y:484,t:1528143891735};\\\", \\\"{x:567,y:486,t:1528143891752};\\\", \\\"{x:569,y:486,t:1528143891769};\\\", \\\"{x:569,y:487,t:1528143891929};\\\", \\\"{x:569,y:489,t:1528143891937};\\\", \\\"{x:569,y:490,t:1528143891952};\\\", \\\"{x:572,y:495,t:1528143891968};\\\", \\\"{x:583,y:501,t:1528143891985};\\\", \\\"{x:593,y:504,t:1528143892002};\\\", \\\"{x:598,y:506,t:1528143892018};\\\", \\\"{x:601,y:506,t:1528143892036};\\\", \\\"{x:602,y:506,t:1528143892052};\\\", \\\"{x:604,y:506,t:1528143892069};\\\", \\\"{x:622,y:508,t:1528143892394};\\\", \\\"{x:682,y:518,t:1528143892404};\\\", \\\"{x:831,y:538,t:1528143892420};\\\", \\\"{x:970,y:555,t:1528143892437};\\\", \\\"{x:1127,y:579,t:1528143892454};\\\", \\\"{x:1274,y:601,t:1528143892469};\\\", \\\"{x:1333,y:608,t:1528143892486};\\\", \\\"{x:1354,y:614,t:1528143892531};\\\", \\\"{x:1354,y:616,t:1528143892544};\\\", \\\"{x:1354,y:619,t:1528143892553};\\\", \\\"{x:1354,y:629,t:1528143892569};\\\", \\\"{x:1354,y:644,t:1528143892586};\\\", \\\"{x:1353,y:655,t:1528143892604};\\\", \\\"{x:1352,y:663,t:1528143892619};\\\", \\\"{x:1346,y:673,t:1528143892637};\\\", \\\"{x:1339,y:680,t:1528143892654};\\\", \\\"{x:1337,y:688,t:1528143892670};\\\", \\\"{x:1335,y:694,t:1528143892687};\\\", \\\"{x:1335,y:700,t:1528143892704};\\\", \\\"{x:1339,y:708,t:1528143892720};\\\", \\\"{x:1342,y:714,t:1528143892736};\\\", \\\"{x:1344,y:716,t:1528143892753};\\\", \\\"{x:1306,y:689,t:1528143893130};\\\", \\\"{x:1141,y:601,t:1528143893170};\\\", \\\"{x:1069,y:571,t:1528143893187};\\\", \\\"{x:1044,y:565,t:1528143893203};\\\", \\\"{x:1035,y:562,t:1528143893220};\\\", \\\"{x:1029,y:561,t:1528143893237};\\\", \\\"{x:1011,y:561,t:1528143893253};\\\", \\\"{x:955,y:564,t:1528143893270};\\\", \\\"{x:849,y:581,t:1528143893288};\\\", \\\"{x:694,y:588,t:1528143893304};\\\", \\\"{x:492,y:588,t:1528143893320};\\\", \\\"{x:233,y:546,t:1528143893338};\\\", \\\"{x:110,y:523,t:1528143893354};\\\", \\\"{x:71,y:511,t:1528143893370};\\\", \\\"{x:65,y:508,t:1528143893387};\\\", \\\"{x:65,y:505,t:1528143893403};\\\", \\\"{x:65,y:500,t:1528143893421};\\\", \\\"{x:65,y:491,t:1528143893437};\\\", \\\"{x:69,y:486,t:1528143893454};\\\", \\\"{x:78,y:478,t:1528143893471};\\\", \\\"{x:95,y:470,t:1528143893487};\\\", \\\"{x:158,y:459,t:1528143893504};\\\", \\\"{x:244,y:450,t:1528143893521};\\\", \\\"{x:345,y:448,t:1528143893537};\\\", \\\"{x:392,y:448,t:1528143893554};\\\", \\\"{x:416,y:448,t:1528143893570};\\\", \\\"{x:430,y:448,t:1528143893587};\\\", \\\"{x:440,y:448,t:1528143893604};\\\", \\\"{x:461,y:450,t:1528143893621};\\\", \\\"{x:493,y:454,t:1528143893637};\\\", \\\"{x:533,y:461,t:1528143893655};\\\", \\\"{x:576,y:468,t:1528143893672};\\\", \\\"{x:607,y:470,t:1528143893689};\\\", \\\"{x:627,y:471,t:1528143893705};\\\", \\\"{x:631,y:471,t:1528143893721};\\\", \\\"{x:638,y:471,t:1528143893738};\\\", \\\"{x:646,y:471,t:1528143893755};\\\", \\\"{x:662,y:474,t:1528143893772};\\\", \\\"{x:684,y:477,t:1528143893788};\\\", \\\"{x:713,y:481,t:1528143893805};\\\", \\\"{x:744,y:486,t:1528143893821};\\\", \\\"{x:784,y:493,t:1528143893839};\\\", \\\"{x:831,y:499,t:1528143893855};\\\", \\\"{x:887,y:507,t:1528143893870};\\\", \\\"{x:954,y:515,t:1528143893887};\\\", \\\"{x:1042,y:527,t:1528143893904};\\\", \\\"{x:1153,y:541,t:1528143893920};\\\", \\\"{x:1267,y:562,t:1528143893937};\\\", \\\"{x:1289,y:565,t:1528143893954};\\\", \\\"{x:1295,y:566,t:1528143893970};\\\", \\\"{x:1296,y:566,t:1528143894034};\\\", \\\"{x:1296,y:567,t:1528143894058};\\\", \\\"{x:1296,y:568,t:1528143894070};\\\", \\\"{x:1296,y:571,t:1528143894088};\\\", \\\"{x:1296,y:573,t:1528143894104};\\\", \\\"{x:1296,y:578,t:1528143894121};\\\", \\\"{x:1296,y:586,t:1528143894137};\\\", \\\"{x:1306,y:610,t:1528143894153};\\\", \\\"{x:1322,y:630,t:1528143894170};\\\", \\\"{x:1345,y:657,t:1528143894187};\\\", \\\"{x:1375,y:681,t:1528143894204};\\\", \\\"{x:1397,y:706,t:1528143894220};\\\", \\\"{x:1413,y:725,t:1528143894236};\\\", \\\"{x:1427,y:748,t:1528143894254};\\\", \\\"{x:1433,y:763,t:1528143894271};\\\", \\\"{x:1439,y:775,t:1528143894289};\\\", \\\"{x:1446,y:787,t:1528143894304};\\\", \\\"{x:1447,y:791,t:1528143894320};\\\", \\\"{x:1448,y:793,t:1528143894337};\\\", \\\"{x:1448,y:794,t:1528143894353};\\\", \\\"{x:1448,y:795,t:1528143894378};\\\", \\\"{x:1448,y:796,t:1528143894394};\\\", \\\"{x:1448,y:797,t:1528143894402};\\\", \\\"{x:1448,y:798,t:1528143894426};\\\", \\\"{x:1447,y:800,t:1528143894437};\\\", \\\"{x:1444,y:801,t:1528143894453};\\\", \\\"{x:1441,y:803,t:1528143894470};\\\", \\\"{x:1439,y:803,t:1528143894486};\\\", \\\"{x:1437,y:804,t:1528143894503};\\\", \\\"{x:1436,y:804,t:1528143894520};\\\", \\\"{x:1434,y:805,t:1528143894536};\\\", \\\"{x:1431,y:807,t:1528143894553};\\\", \\\"{x:1431,y:808,t:1528143894594};\\\", \\\"{x:1431,y:809,t:1528143894603};\\\", \\\"{x:1431,y:810,t:1528143894618};\\\", \\\"{x:1431,y:814,t:1528143894636};\\\", \\\"{x:1431,y:820,t:1528143894653};\\\", \\\"{x:1431,y:824,t:1528143894669};\\\", \\\"{x:1431,y:828,t:1528143894686};\\\", \\\"{x:1432,y:836,t:1528143894703};\\\", \\\"{x:1432,y:841,t:1528143894719};\\\", \\\"{x:1434,y:847,t:1528143894736};\\\", \\\"{x:1434,y:851,t:1528143894753};\\\", \\\"{x:1435,y:855,t:1528143894769};\\\", \\\"{x:1435,y:859,t:1528143894786};\\\", \\\"{x:1436,y:862,t:1528143894802};\\\", \\\"{x:1436,y:864,t:1528143894819};\\\", \\\"{x:1438,y:869,t:1528143894836};\\\", \\\"{x:1439,y:872,t:1528143894852};\\\", \\\"{x:1441,y:877,t:1528143894869};\\\", \\\"{x:1442,y:880,t:1528143894885};\\\", \\\"{x:1443,y:883,t:1528143894902};\\\", \\\"{x:1445,y:887,t:1528143894919};\\\", \\\"{x:1446,y:892,t:1528143894935};\\\", \\\"{x:1449,y:897,t:1528143894952};\\\", \\\"{x:1452,y:904,t:1528143894970};\\\", \\\"{x:1455,y:912,t:1528143894985};\\\", \\\"{x:1460,y:921,t:1528143895002};\\\", \\\"{x:1463,y:926,t:1528143895018};\\\", \\\"{x:1465,y:932,t:1528143895034};\\\", \\\"{x:1466,y:935,t:1528143895052};\\\", \\\"{x:1470,y:942,t:1528143895068};\\\", \\\"{x:1472,y:948,t:1528143895086};\\\", \\\"{x:1476,y:953,t:1528143895103};\\\", \\\"{x:1479,y:958,t:1528143895118};\\\", \\\"{x:1481,y:962,t:1528143895134};\\\", \\\"{x:1482,y:962,t:1528143895152};\\\", \\\"{x:1482,y:963,t:1528143895168};\\\", \\\"{x:1482,y:965,t:1528143895218};\\\", \\\"{x:1462,y:958,t:1528143898379};\\\", \\\"{x:1400,y:935,t:1528143898394};\\\", \\\"{x:1194,y:861,t:1528143898410};\\\", \\\"{x:1091,y:831,t:1528143898427};\\\", \\\"{x:1031,y:809,t:1528143898443};\\\", \\\"{x:988,y:793,t:1528143898460};\\\", \\\"{x:934,y:782,t:1528143898477};\\\", \\\"{x:902,y:776,t:1528143898493};\\\", \\\"{x:862,y:769,t:1528143898510};\\\", \\\"{x:825,y:764,t:1528143898526};\\\", \\\"{x:780,y:763,t:1528143898543};\\\", \\\"{x:719,y:763,t:1528143898560};\\\", \\\"{x:652,y:763,t:1528143898576};\\\", \\\"{x:601,y:763,t:1528143898593};\\\", \\\"{x:570,y:758,t:1528143898609};\\\", \\\"{x:515,y:743,t:1528143898627};\\\", \\\"{x:487,y:735,t:1528143898643};\\\", \\\"{x:462,y:728,t:1528143898658};\\\", \\\"{x:436,y:721,t:1528143898675};\\\", \\\"{x:410,y:719,t:1528143898691};\\\", \\\"{x:388,y:715,t:1528143898707};\\\", \\\"{x:379,y:714,t:1528143898724};\\\", \\\"{x:378,y:714,t:1528143898741};\\\", \\\"{x:379,y:715,t:1528143898801};\\\", \\\"{x:387,y:720,t:1528143898808};\\\", \\\"{x:396,y:722,t:1528143898824};\\\", \\\"{x:424,y:730,t:1528143898841};\\\", \\\"{x:438,y:733,t:1528143898858};\\\", \\\"{x:451,y:737,t:1528143898874};\\\", \\\"{x:466,y:740,t:1528143898891};\\\", \\\"{x:484,y:741,t:1528143898908};\\\", \\\"{x:491,y:741,t:1528143898924};\\\", \\\"{x:492,y:741,t:1528143898942};\\\", \\\"{x:492,y:742,t:1528143899057};\\\", \\\"{x:497,y:735,t:1528143899385};\\\", \\\"{x:513,y:698,t:1528143899393};\\\", \\\"{x:532,y:661,t:1528143899408};\\\", \\\"{x:568,y:584,t:1528143899425};\\\", \\\"{x:588,y:539,t:1528143899441};\\\", \\\"{x:612,y:491,t:1528143899458};\\\", \\\"{x:628,y:462,t:1528143899476};\\\", \\\"{x:635,y:453,t:1528143899491};\\\" ] }, { \\\"rt\\\": 12361, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 15, \\\"time_elapsed\\\": 828430, \\\"internal_node_id\\\": \\\"0.0-6.0-5.0\\\", \\\"subject\\\": \\\"MKTF4\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"zulu\\\", \\\"condition\\\": \\\"211\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"starttime\\\", \\\"q\\\": 11, \\\"clicks\\\": 2, \\\"explicit\\\": 2, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XInside-YFull\\\", \\\"correct\\\": 1, \\\"orth_correct\\\": 0, \\\"answer\\\": [ \\\"M\\\", \\\"L\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-F -12 PM-4-11 AM-12 PM-L \\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:627,y:452,t:1528143902690};\\\", \\\"{x:579,y:450,t:1528143902716};\\\", \\\"{x:579,y:449,t:1528143902729};\\\", \\\"{x:581,y:447,t:1528143902744};\\\", \\\"{x:600,y:440,t:1528143902761};\\\", \\\"{x:634,y:431,t:1528143902777};\\\", \\\"{x:640,y:433,t:1528143902795};\\\", \\\"{x:652,y:448,t:1528143902810};\\\", \\\"{x:686,y:484,t:1528143902828};\\\", \\\"{x:748,y:534,t:1528143902845};\\\", \\\"{x:838,y:582,t:1528143902862};\\\", \\\"{x:947,y:621,t:1528143902878};\\\", \\\"{x:1074,y:652,t:1528143902895};\\\", \\\"{x:1176,y:666,t:1528143902911};\\\", \\\"{x:1276,y:680,t:1528143902927};\\\", \\\"{x:1330,y:687,t:1528143902945};\\\", \\\"{x:1349,y:692,t:1528143902962};\\\", \\\"{x:1364,y:695,t:1528143902978};\\\", \\\"{x:1379,y:699,t:1528143902994};\\\", \\\"{x:1393,y:704,t:1528143903012};\\\", \\\"{x:1405,y:708,t:1528143903027};\\\", \\\"{x:1415,y:712,t:1528143903045};\\\", \\\"{x:1419,y:716,t:1528143903061};\\\", \\\"{x:1419,y:726,t:1528143903078};\\\", \\\"{x:1419,y:741,t:1528143903095};\\\", \\\"{x:1419,y:755,t:1528143903112};\\\", \\\"{x:1420,y:763,t:1528143903128};\\\", \\\"{x:1420,y:768,t:1528143903145};\\\", \\\"{x:1418,y:777,t:1528143903161};\\\", \\\"{x:1417,y:777,t:1528143903178};\\\", \\\"{x:1418,y:777,t:1528143903546};\\\", \\\"{x:1420,y:776,t:1528143903562};\\\", \\\"{x:1421,y:775,t:1528143903579};\\\", \\\"{x:1426,y:775,t:1528143903596};\\\", \\\"{x:1492,y:764,t:1528143903613};\\\", \\\"{x:1660,y:746,t:1528143903630};\\\", \\\"{x:1755,y:755,t:1528143903645};\\\", \\\"{x:1766,y:761,t:1528143903662};\\\", \\\"{x:1774,y:767,t:1528143903679};\\\", \\\"{x:1785,y:776,t:1528143903696};\\\", \\\"{x:1787,y:780,t:1528143903712};\\\", \\\"{x:1787,y:784,t:1528143903729};\\\", \\\"{x:1781,y:792,t:1528143903746};\\\", \\\"{x:1760,y:802,t:1528143903763};\\\", \\\"{x:1731,y:817,t:1528143903780};\\\", \\\"{x:1699,y:836,t:1528143903796};\\\", \\\"{x:1671,y:848,t:1528143903813};\\\", \\\"{x:1644,y:856,t:1528143903829};\\\", \\\"{x:1618,y:860,t:1528143903846};\\\", \\\"{x:1597,y:863,t:1528143903862};\\\", \\\"{x:1578,y:863,t:1528143903879};\\\", \\\"{x:1564,y:862,t:1528143903897};\\\", \\\"{x:1554,y:858,t:1528143903913};\\\", \\\"{x:1546,y:854,t:1528143903930};\\\", \\\"{x:1535,y:850,t:1528143903945};\\\", \\\"{x:1520,y:847,t:1528143903962};\\\", \\\"{x:1503,y:842,t:1528143903979};\\\", \\\"{x:1476,y:842,t:1528143903996};\\\", \\\"{x:1442,y:842,t:1528143904012};\\\", \\\"{x:1407,y:847,t:1528143904029};\\\", \\\"{x:1376,y:857,t:1528143904046};\\\", \\\"{x:1350,y:864,t:1528143904062};\\\", \\\"{x:1326,y:875,t:1528143904079};\\\", \\\"{x:1304,y:885,t:1528143904096};\\\", \\\"{x:1286,y:896,t:1528143904112};\\\", \\\"{x:1270,y:910,t:1528143904129};\\\", \\\"{x:1259,y:927,t:1528143904146};\\\", \\\"{x:1255,y:937,t:1528143904163};\\\", \\\"{x:1253,y:949,t:1528143904179};\\\", \\\"{x:1253,y:960,t:1528143904196};\\\", \\\"{x:1253,y:971,t:1528143904213};\\\", \\\"{x:1254,y:986,t:1528143904230};\\\", \\\"{x:1260,y:1002,t:1528143904247};\\\", \\\"{x:1265,y:1017,t:1528143904263};\\\", \\\"{x:1272,y:1028,t:1528143904279};\\\", \\\"{x:1281,y:1037,t:1528143904296};\\\", \\\"{x:1288,y:1042,t:1528143904314};\\\", \\\"{x:1297,y:1043,t:1528143904329};\\\", \\\"{x:1305,y:1044,t:1528143904346};\\\", \\\"{x:1310,y:1044,t:1528143904363};\\\", \\\"{x:1315,y:1044,t:1528143904379};\\\", \\\"{x:1321,y:1041,t:1528143904397};\\\", \\\"{x:1325,y:1037,t:1528143904413};\\\", \\\"{x:1330,y:1033,t:1528143904429};\\\", \\\"{x:1335,y:1019,t:1528143904446};\\\", \\\"{x:1339,y:1008,t:1528143904463};\\\", \\\"{x:1345,y:998,t:1528143904479};\\\", \\\"{x:1349,y:992,t:1528143904496};\\\", \\\"{x:1352,y:988,t:1528143904513};\\\", \\\"{x:1354,y:985,t:1528143904530};\\\", \\\"{x:1356,y:981,t:1528143904546};\\\", \\\"{x:1356,y:978,t:1528143904564};\\\", \\\"{x:1356,y:975,t:1528143904581};\\\", \\\"{x:1356,y:974,t:1528143904597};\\\", \\\"{x:1356,y:973,t:1528143904613};\\\", \\\"{x:1356,y:972,t:1528143904630};\\\", \\\"{x:1356,y:971,t:1528143904698};\\\", \\\"{x:1356,y:970,t:1528143904722};\\\", \\\"{x:1356,y:969,t:1528143904730};\\\", \\\"{x:1353,y:969,t:1528143904802};\\\", \\\"{x:1352,y:969,t:1528143904814};\\\", \\\"{x:1350,y:969,t:1528143904831};\\\", \\\"{x:1348,y:969,t:1528143904846};\\\", \\\"{x:1347,y:969,t:1528143905082};\\\", \\\"{x:1347,y:968,t:1528143905098};\\\", \\\"{x:1348,y:966,t:1528143905114};\\\", \\\"{x:1349,y:966,t:1528143905131};\\\", \\\"{x:1349,y:965,t:1528143905148};\\\", \\\"{x:1349,y:964,t:1528143905386};\\\", \\\"{x:1348,y:964,t:1528143905409};\\\", \\\"{x:1347,y:964,t:1528143905643};\\\", \\\"{x:1346,y:964,t:1528143905731};\\\", \\\"{x:1345,y:964,t:1528143905930};\\\", \\\"{x:1342,y:963,t:1528143905947};\\\", \\\"{x:1335,y:959,t:1528143905965};\\\", \\\"{x:1323,y:952,t:1528143905981};\\\", \\\"{x:1300,y:935,t:1528143905997};\\\", \\\"{x:1272,y:910,t:1528143906014};\\\", \\\"{x:1239,y:879,t:1528143906031};\\\", \\\"{x:1207,y:843,t:1528143906048};\\\", \\\"{x:1154,y:793,t:1528143906064};\\\", \\\"{x:1076,y:718,t:1528143906082};\\\", \\\"{x:1058,y:695,t:1528143906097};\\\", \\\"{x:1024,y:648,t:1528143906114};\\\", \\\"{x:1010,y:626,t:1528143906132};\\\", \\\"{x:992,y:600,t:1528143906148};\\\", \\\"{x:971,y:560,t:1528143906164};\\\", \\\"{x:953,y:524,t:1528143906181};\\\", \\\"{x:940,y:506,t:1528143906198};\\\", \\\"{x:909,y:486,t:1528143906214};\\\", \\\"{x:878,y:476,t:1528143906230};\\\", \\\"{x:830,y:475,t:1528143906248};\\\", \\\"{x:796,y:475,t:1528143906264};\\\", \\\"{x:763,y:478,t:1528143906281};\\\", \\\"{x:752,y:482,t:1528143906297};\\\", \\\"{x:744,y:485,t:1528143906313};\\\", \\\"{x:741,y:486,t:1528143906330};\\\", \\\"{x:738,y:486,t:1528143906348};\\\", \\\"{x:730,y:489,t:1528143906364};\\\", \\\"{x:720,y:491,t:1528143906381};\\\", \\\"{x:708,y:495,t:1528143906397};\\\", \\\"{x:701,y:496,t:1528143906414};\\\", \\\"{x:693,y:498,t:1528143906431};\\\", \\\"{x:686,y:499,t:1528143906447};\\\", \\\"{x:682,y:500,t:1528143906464};\\\", \\\"{x:678,y:501,t:1528143906480};\\\", \\\"{x:677,y:501,t:1528143906513};\\\", \\\"{x:675,y:501,t:1528143906561};\\\", \\\"{x:674,y:501,t:1528143906577};\\\", \\\"{x:672,y:501,t:1528143906593};\\\", \\\"{x:671,y:501,t:1528143906609};\\\", \\\"{x:671,y:502,t:1528143906625};\\\", \\\"{x:669,y:502,t:1528143906641};\\\", \\\"{x:668,y:502,t:1528143906666};\\\", \\\"{x:666,y:503,t:1528143906681};\\\", \\\"{x:665,y:504,t:1528143906698};\\\", \\\"{x:662,y:504,t:1528143906714};\\\", \\\"{x:660,y:505,t:1528143906730};\\\", \\\"{x:657,y:507,t:1528143906747};\\\", \\\"{x:655,y:508,t:1528143906764};\\\", \\\"{x:652,y:510,t:1528143906781};\\\", \\\"{x:648,y:512,t:1528143906798};\\\", \\\"{x:644,y:514,t:1528143906814};\\\", \\\"{x:642,y:517,t:1528143906831};\\\", \\\"{x:641,y:518,t:1528143906849};\\\", \\\"{x:640,y:519,t:1528143906863};\\\", \\\"{x:639,y:520,t:1528143906881};\\\", \\\"{x:639,y:522,t:1528143906898};\\\", \\\"{x:639,y:523,t:1528143906915};\\\", \\\"{x:647,y:526,t:1528143906933};\\\", \\\"{x:674,y:526,t:1528143906948};\\\", \\\"{x:725,y:526,t:1528143906966};\\\", \\\"{x:759,y:525,t:1528143906981};\\\", \\\"{x:794,y:519,t:1528143906998};\\\", \\\"{x:818,y:517,t:1528143907016};\\\", \\\"{x:828,y:517,t:1528143907031};\\\", \\\"{x:833,y:517,t:1528143907048};\\\", \\\"{x:838,y:518,t:1528143907065};\\\", \\\"{x:840,y:518,t:1528143907081};\\\", \\\"{x:841,y:519,t:1528143907098};\\\", \\\"{x:841,y:520,t:1528143907115};\\\", \\\"{x:841,y:525,t:1528143907132};\\\", \\\"{x:833,y:534,t:1528143907149};\\\", \\\"{x:817,y:545,t:1528143907165};\\\", \\\"{x:786,y:559,t:1528143907182};\\\", \\\"{x:741,y:574,t:1528143907198};\\\", \\\"{x:677,y:589,t:1528143907215};\\\", \\\"{x:616,y:589,t:1528143907232};\\\", \\\"{x:568,y:589,t:1528143907248};\\\", \\\"{x:531,y:587,t:1528143907265};\\\", \\\"{x:521,y:584,t:1528143907282};\\\", \\\"{x:518,y:584,t:1528143907298};\\\", \\\"{x:516,y:583,t:1528143907315};\\\", \\\"{x:515,y:583,t:1528143907331};\\\", \\\"{x:511,y:582,t:1528143907348};\\\", \\\"{x:503,y:579,t:1528143907365};\\\", \\\"{x:494,y:574,t:1528143907382};\\\", \\\"{x:485,y:571,t:1528143907399};\\\", \\\"{x:480,y:570,t:1528143907415};\\\", \\\"{x:477,y:568,t:1528143907430};\\\", \\\"{x:473,y:567,t:1528143907448};\\\", \\\"{x:459,y:566,t:1528143907465};\\\", \\\"{x:449,y:564,t:1528143907481};\\\", \\\"{x:438,y:562,t:1528143907499};\\\", \\\"{x:430,y:559,t:1528143907514};\\\", \\\"{x:426,y:558,t:1528143907532};\\\", \\\"{x:425,y:558,t:1528143907548};\\\", \\\"{x:424,y:557,t:1528143907564};\\\", \\\"{x:422,y:557,t:1528143907582};\\\", \\\"{x:421,y:557,t:1528143907598};\\\", \\\"{x:418,y:557,t:1528143907615};\\\", \\\"{x:416,y:559,t:1528143907632};\\\", \\\"{x:413,y:561,t:1528143907649};\\\", \\\"{x:412,y:562,t:1528143907665};\\\", \\\"{x:410,y:566,t:1528143907683};\\\", \\\"{x:409,y:569,t:1528143907699};\\\", \\\"{x:409,y:571,t:1528143907714};\\\", \\\"{x:407,y:575,t:1528143907732};\\\", \\\"{x:404,y:583,t:1528143907749};\\\", \\\"{x:402,y:589,t:1528143907766};\\\", \\\"{x:400,y:594,t:1528143907783};\\\", \\\"{x:399,y:595,t:1528143907799};\\\", \\\"{x:398,y:596,t:1528143907815};\\\", \\\"{x:397,y:597,t:1528143907832};\\\", \\\"{x:391,y:598,t:1528143907849};\\\", \\\"{x:382,y:593,t:1528143907866};\\\", \\\"{x:375,y:588,t:1528143907882};\\\", \\\"{x:370,y:580,t:1528143907899};\\\", \\\"{x:370,y:576,t:1528143907916};\\\", \\\"{x:370,y:568,t:1528143907931};\\\", \\\"{x:370,y:564,t:1528143907948};\\\", \\\"{x:370,y:560,t:1528143907966};\\\", \\\"{x:371,y:557,t:1528143907982};\\\", \\\"{x:371,y:556,t:1528143907999};\\\", \\\"{x:371,y:555,t:1528143908015};\\\", \\\"{x:371,y:554,t:1528143908130};\\\", \\\"{x:371,y:551,t:1528143908149};\\\", \\\"{x:372,y:549,t:1528143908166};\\\", \\\"{x:372,y:547,t:1528143908182};\\\", \\\"{x:373,y:545,t:1528143908199};\\\", \\\"{x:374,y:546,t:1528143908409};\\\", \\\"{x:374,y:553,t:1528143908417};\\\", \\\"{x:374,y:560,t:1528143908433};\\\", \\\"{x:376,y:573,t:1528143908449};\\\", \\\"{x:377,y:585,t:1528143908465};\\\", \\\"{x:377,y:596,t:1528143908483};\\\", \\\"{x:377,y:604,t:1528143908499};\\\", \\\"{x:377,y:608,t:1528143908516};\\\", \\\"{x:377,y:613,t:1528143908533};\\\", \\\"{x:377,y:615,t:1528143908549};\\\", \\\"{x:377,y:618,t:1528143908566};\\\", \\\"{x:379,y:619,t:1528143908582};\\\", \\\"{x:380,y:619,t:1528143908889};\\\", \\\"{x:411,y:619,t:1528143908899};\\\", \\\"{x:507,y:631,t:1528143908917};\\\", \\\"{x:607,y:646,t:1528143908933};\\\", \\\"{x:738,y:670,t:1528143908950};\\\", \\\"{x:877,y:711,t:1528143908966};\\\", \\\"{x:987,y:739,t:1528143908983};\\\", \\\"{x:1065,y:761,t:1528143909000};\\\", \\\"{x:1110,y:776,t:1528143909016};\\\", \\\"{x:1130,y:788,t:1528143909033};\\\", \\\"{x:1136,y:794,t:1528143909049};\\\", \\\"{x:1144,y:805,t:1528143909066};\\\", \\\"{x:1157,y:823,t:1528143909084};\\\", \\\"{x:1172,y:838,t:1528143909100};\\\", \\\"{x:1184,y:853,t:1528143909116};\\\", \\\"{x:1198,y:868,t:1528143909134};\\\", \\\"{x:1202,y:875,t:1528143909151};\\\", \\\"{x:1203,y:879,t:1528143909167};\\\", \\\"{x:1203,y:881,t:1528143909184};\\\", \\\"{x:1206,y:885,t:1528143909201};\\\", \\\"{x:1211,y:892,t:1528143909216};\\\", \\\"{x:1220,y:908,t:1528143909234};\\\", \\\"{x:1231,y:924,t:1528143909250};\\\", \\\"{x:1242,y:940,t:1528143909266};\\\", \\\"{x:1256,y:958,t:1528143909283};\\\", \\\"{x:1267,y:972,t:1528143909300};\\\", \\\"{x:1275,y:982,t:1528143909318};\\\", \\\"{x:1283,y:987,t:1528143909333};\\\", \\\"{x:1287,y:990,t:1528143909350};\\\", \\\"{x:1290,y:992,t:1528143909367};\\\", \\\"{x:1292,y:993,t:1528143909383};\\\", \\\"{x:1293,y:993,t:1528143909400};\\\", \\\"{x:1294,y:993,t:1528143909417};\\\", \\\"{x:1296,y:993,t:1528143909433};\\\", \\\"{x:1299,y:993,t:1528143909450};\\\", \\\"{x:1307,y:990,t:1528143909467};\\\", \\\"{x:1316,y:986,t:1528143909483};\\\", \\\"{x:1328,y:979,t:1528143909501};\\\", \\\"{x:1340,y:970,t:1528143909517};\\\", \\\"{x:1347,y:965,t:1528143909533};\\\", \\\"{x:1353,y:961,t:1528143909550};\\\", \\\"{x:1354,y:960,t:1528143909568};\\\", \\\"{x:1356,y:959,t:1528143909583};\\\", \\\"{x:1356,y:958,t:1528143909600};\\\", \\\"{x:1359,y:956,t:1528143909617};\\\", \\\"{x:1360,y:954,t:1528143909633};\\\", \\\"{x:1361,y:953,t:1528143909650};\\\", \\\"{x:1361,y:952,t:1528143909668};\\\", \\\"{x:1360,y:951,t:1528143909899};\\\", \\\"{x:1361,y:949,t:1528143909905};\\\", \\\"{x:1363,y:947,t:1528143909918};\\\", \\\"{x:1371,y:937,t:1528143909934};\\\", \\\"{x:1377,y:927,t:1528143909951};\\\", \\\"{x:1381,y:920,t:1528143909968};\\\", \\\"{x:1390,y:908,t:1528143909984};\\\", \\\"{x:1395,y:897,t:1528143910001};\\\", \\\"{x:1401,y:880,t:1528143910018};\\\", \\\"{x:1404,y:873,t:1528143910034};\\\", \\\"{x:1407,y:865,t:1528143910050};\\\", \\\"{x:1409,y:861,t:1528143910068};\\\", \\\"{x:1411,y:856,t:1528143910085};\\\", \\\"{x:1413,y:850,t:1528143910100};\\\", \\\"{x:1418,y:842,t:1528143910117};\\\", \\\"{x:1424,y:831,t:1528143910134};\\\", \\\"{x:1433,y:820,t:1528143910151};\\\", \\\"{x:1443,y:809,t:1528143910168};\\\", \\\"{x:1450,y:798,t:1528143910185};\\\", \\\"{x:1458,y:788,t:1528143910201};\\\", \\\"{x:1465,y:770,t:1528143910218};\\\", \\\"{x:1472,y:758,t:1528143910235};\\\", \\\"{x:1478,y:748,t:1528143910252};\\\", \\\"{x:1484,y:741,t:1528143910268};\\\", \\\"{x:1493,y:729,t:1528143910285};\\\", \\\"{x:1499,y:719,t:1528143910301};\\\", \\\"{x:1503,y:710,t:1528143910318};\\\", \\\"{x:1504,y:702,t:1528143910334};\\\", \\\"{x:1506,y:695,t:1528143910351};\\\", \\\"{x:1508,y:689,t:1528143910368};\\\", \\\"{x:1511,y:678,t:1528143910385};\\\", \\\"{x:1517,y:660,t:1528143910401};\\\", \\\"{x:1522,y:645,t:1528143910418};\\\", \\\"{x:1528,y:630,t:1528143910434};\\\", \\\"{x:1535,y:616,t:1528143910451};\\\", \\\"{x:1538,y:604,t:1528143910467};\\\", \\\"{x:1544,y:590,t:1528143910484};\\\", \\\"{x:1552,y:574,t:1528143910501};\\\", \\\"{x:1559,y:561,t:1528143910517};\\\", \\\"{x:1567,y:547,t:1528143910534};\\\", \\\"{x:1577,y:533,t:1528143910551};\\\", \\\"{x:1582,y:526,t:1528143910567};\\\", \\\"{x:1586,y:518,t:1528143910585};\\\", \\\"{x:1588,y:512,t:1528143910601};\\\", \\\"{x:1590,y:508,t:1528143910617};\\\", \\\"{x:1592,y:505,t:1528143910634};\\\", \\\"{x:1593,y:503,t:1528143910651};\\\", \\\"{x:1594,y:502,t:1528143910668};\\\", \\\"{x:1594,y:501,t:1528143911067};\\\", \\\"{x:1594,y:500,t:1528143911082};\\\", \\\"{x:1593,y:500,t:1528143911106};\\\", \\\"{x:1592,y:500,t:1528143911122};\\\", \\\"{x:1591,y:500,t:1528143911723};\\\", \\\"{x:1580,y:500,t:1528143911735};\\\", \\\"{x:1413,y:500,t:1528143911752};\\\", \\\"{x:1277,y:513,t:1528143911768};\\\", \\\"{x:1148,y:547,t:1528143911784};\\\", \\\"{x:1028,y:566,t:1528143911802};\\\", \\\"{x:914,y:582,t:1528143911818};\\\", \\\"{x:837,y:593,t:1528143911835};\\\", \\\"{x:789,y:600,t:1528143911852};\\\", \\\"{x:760,y:605,t:1528143911866};\\\", \\\"{x:739,y:610,t:1528143911883};\\\", \\\"{x:734,y:613,t:1528143911900};\\\", \\\"{x:726,y:618,t:1528143911916};\\\", \\\"{x:717,y:626,t:1528143911934};\\\", \\\"{x:701,y:640,t:1528143911951};\\\", \\\"{x:669,y:662,t:1528143911969};\\\", \\\"{x:652,y:675,t:1528143911985};\\\", \\\"{x:637,y:687,t:1528143912002};\\\", \\\"{x:627,y:696,t:1528143912019};\\\", \\\"{x:620,y:700,t:1528143912035};\\\", \\\"{x:616,y:703,t:1528143912052};\\\", \\\"{x:611,y:706,t:1528143912069};\\\", \\\"{x:598,y:709,t:1528143912085};\\\", \\\"{x:578,y:713,t:1528143912102};\\\", \\\"{x:550,y:718,t:1528143912119};\\\", \\\"{x:524,y:721,t:1528143912136};\\\", \\\"{x:504,y:726,t:1528143912152};\\\", \\\"{x:494,y:726,t:1528143912169};\\\", \\\"{x:490,y:726,t:1528143912185};\\\", \\\"{x:484,y:725,t:1528143912202};\\\", \\\"{x:481,y:725,t:1528143912220};\\\", \\\"{x:480,y:725,t:1528143912235};\\\", \\\"{x:479,y:725,t:1528143912377};\\\", \\\"{x:479,y:726,t:1528143912425};\\\", \\\"{x:480,y:726,t:1528143912441};\\\", \\\"{x:490,y:714,t:1528143913113};\\\", \\\"{x:520,y:679,t:1528143913121};\\\", \\\"{x:549,y:643,t:1528143913136};\\\", \\\"{x:637,y:539,t:1528143913153};\\\", \\\"{x:666,y:502,t:1528143913169};\\\", \\\"{x:676,y:483,t:1528143913186};\\\", \\\"{x:679,y:471,t:1528143913204};\\\", \\\"{x:679,y:464,t:1528143913219};\\\", \\\"{x:679,y:462,t:1528143913237};\\\", \\\"{x:679,y:460,t:1528143913254};\\\", \\\"{x:679,y:459,t:1528143913273};\\\", \\\"{x:679,y:460,t:1528143913960};\\\", \\\"{x:685,y:465,t:1528143913970};\\\", \\\"{x:690,y:466,t:1528143913986};\\\", \\\"{x:693,y:469,t:1528143914003};\\\", \\\"{x:700,y:472,t:1528143914020};\\\" ] }, { \\\"rt\\\": 19859, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 16, \\\"time_elapsed\\\": 849539, \\\"internal_node_id\\\": \\\"0.0-6.0-6.0\\\", \\\"subject\\\": \\\"MKTF4\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"zulu\\\", \\\"condition\\\": \\\"211\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"starts\\\", \\\"q\\\": 12, \\\"clicks\\\": 1, \\\"explicit\\\": 2, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XInside-YFull\\\", \\\"correct\\\": 1, \\\"orth_correct\\\": 0, \\\"answer\\\": [ \\\"G\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-F -F -F -10 AM-F \\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:717,y:481,t:1528143914132};\\\", \\\"{x:718,y:481,t:1528143914159};\\\", \\\"{x:719,y:481,t:1528143914344};\\\", \\\"{x:718,y:481,t:1528143914578};\\\", \\\"{x:711,y:481,t:1528143914587};\\\", \\\"{x:699,y:481,t:1528143914604};\\\", \\\"{x:678,y:481,t:1528143914622};\\\", \\\"{x:591,y:475,t:1528143914737};\\\", \\\"{x:590,y:473,t:1528143914755};\\\", \\\"{x:590,y:472,t:1528143914771};\\\", \\\"{x:589,y:472,t:1528143914787};\\\", \\\"{x:589,y:470,t:1528143915121};\\\", \\\"{x:590,y:470,t:1528143915193};\\\", \\\"{x:591,y:469,t:1528143915250};\\\", \\\"{x:592,y:468,t:1528143915314};\\\", \\\"{x:595,y:466,t:1528143915329};\\\", \\\"{x:595,y:465,t:1528143915338};\\\", \\\"{x:598,y:463,t:1528143915354};\\\", \\\"{x:599,y:462,t:1528143915372};\\\", \\\"{x:600,y:461,t:1528143915389};\\\", \\\"{x:601,y:460,t:1528143915405};\\\", \\\"{x:602,y:460,t:1528143915421};\\\", \\\"{x:603,y:460,t:1528143915801};\\\", \\\"{x:604,y:460,t:1528143916241};\\\", \\\"{x:605,y:460,t:1528143916369};\\\", \\\"{x:606,y:460,t:1528143916410};\\\", \\\"{x:607,y:459,t:1528143916442};\\\", \\\"{x:608,y:459,t:1528143916455};\\\", \\\"{x:616,y:455,t:1528143916472};\\\", \\\"{x:632,y:448,t:1528143916490};\\\", \\\"{x:638,y:446,t:1528143916506};\\\", \\\"{x:648,y:440,t:1528143916523};\\\", \\\"{x:653,y:436,t:1528143916540};\\\", \\\"{x:658,y:433,t:1528143916556};\\\", \\\"{x:662,y:430,t:1528143916573};\\\", \\\"{x:663,y:428,t:1528143916590};\\\", \\\"{x:663,y:429,t:1528143916658};\\\", \\\"{x:663,y:432,t:1528143916672};\\\", \\\"{x:663,y:438,t:1528143916689};\\\", \\\"{x:663,y:440,t:1528143916705};\\\", \\\"{x:662,y:443,t:1528143916882};\\\", \\\"{x:658,y:446,t:1528143916889};\\\", \\\"{x:645,y:459,t:1528143916907};\\\", \\\"{x:629,y:475,t:1528143916923};\\\", \\\"{x:613,y:490,t:1528143916942};\\\", \\\"{x:603,y:503,t:1528143916957};\\\", \\\"{x:597,y:510,t:1528143916972};\\\", \\\"{x:594,y:516,t:1528143916989};\\\", \\\"{x:592,y:519,t:1528143917007};\\\", \\\"{x:590,y:522,t:1528143917022};\\\", \\\"{x:590,y:525,t:1528143917040};\\\", \\\"{x:589,y:531,t:1528143917056};\\\", \\\"{x:587,y:541,t:1528143917073};\\\", \\\"{x:587,y:560,t:1528143917090};\\\", \\\"{x:594,y:573,t:1528143917107};\\\", \\\"{x:601,y:584,t:1528143917123};\\\", \\\"{x:608,y:595,t:1528143917139};\\\", \\\"{x:617,y:606,t:1528143917157};\\\", \\\"{x:629,y:618,t:1528143917172};\\\", \\\"{x:643,y:631,t:1528143917189};\\\", \\\"{x:654,y:641,t:1528143917206};\\\", \\\"{x:663,y:648,t:1528143917223};\\\", \\\"{x:668,y:652,t:1528143917239};\\\", \\\"{x:673,y:657,t:1528143917256};\\\", \\\"{x:685,y:674,t:1528143917272};\\\", \\\"{x:688,y:679,t:1528143917289};\\\", \\\"{x:690,y:681,t:1528143917307};\\\", \\\"{x:693,y:683,t:1528143917323};\\\", \\\"{x:694,y:684,t:1528143917345};\\\", \\\"{x:694,y:685,t:1528143917357};\\\", \\\"{x:694,y:686,t:1528143917393};\\\", \\\"{x:695,y:686,t:1528143917406};\\\", \\\"{x:695,y:687,t:1528143917424};\\\", \\\"{x:697,y:690,t:1528143917441};\\\", \\\"{x:697,y:692,t:1528143917456};\\\", \\\"{x:699,y:698,t:1528143917474};\\\", \\\"{x:699,y:702,t:1528143917491};\\\", \\\"{x:699,y:705,t:1528143917508};\\\", \\\"{x:699,y:707,t:1528143917523};\\\", \\\"{x:700,y:708,t:1528143917540};\\\", \\\"{x:700,y:709,t:1528143917558};\\\", \\\"{x:700,y:710,t:1528143917594};\\\", \\\"{x:699,y:711,t:1528143917607};\\\", \\\"{x:703,y:711,t:1528143917738};\\\", \\\"{x:729,y:711,t:1528143917746};\\\", \\\"{x:780,y:715,t:1528143917757};\\\", \\\"{x:866,y:716,t:1528143917774};\\\", \\\"{x:916,y:713,t:1528143917792};\\\", \\\"{x:941,y:704,t:1528143917808};\\\", \\\"{x:968,y:695,t:1528143917825};\\\", \\\"{x:1024,y:681,t:1528143917842};\\\", \\\"{x:1067,y:674,t:1528143917859};\\\", \\\"{x:1120,y:666,t:1528143917875};\\\", \\\"{x:1182,y:658,t:1528143917892};\\\", \\\"{x:1214,y:653,t:1528143917909};\\\", \\\"{x:1226,y:650,t:1528143917925};\\\", \\\"{x:1229,y:648,t:1528143917942};\\\", \\\"{x:1230,y:648,t:1528143917959};\\\", \\\"{x:1233,y:647,t:1528143917985};\\\", \\\"{x:1235,y:646,t:1528143917993};\\\", \\\"{x:1239,y:644,t:1528143918009};\\\", \\\"{x:1260,y:635,t:1528143918026};\\\", \\\"{x:1274,y:627,t:1528143918042};\\\", \\\"{x:1280,y:623,t:1528143918059};\\\", \\\"{x:1282,y:621,t:1528143918076};\\\", \\\"{x:1286,y:624,t:1528143918162};\\\", \\\"{x:1291,y:629,t:1528143918176};\\\", \\\"{x:1298,y:635,t:1528143918193};\\\", \\\"{x:1305,y:640,t:1528143918209};\\\", \\\"{x:1317,y:648,t:1528143918225};\\\", \\\"{x:1324,y:654,t:1528143918243};\\\", \\\"{x:1331,y:660,t:1528143918259};\\\", \\\"{x:1338,y:671,t:1528143918276};\\\", \\\"{x:1346,y:680,t:1528143918294};\\\", \\\"{x:1348,y:684,t:1528143918309};\\\", \\\"{x:1349,y:684,t:1528143918326};\\\", \\\"{x:1350,y:686,t:1528143918344};\\\", \\\"{x:1349,y:687,t:1528143918610};\\\", \\\"{x:1349,y:688,t:1528143918650};\\\", \\\"{x:1348,y:689,t:1528143918673};\\\", \\\"{x:1348,y:690,t:1528143918689};\\\", \\\"{x:1347,y:690,t:1528143918705};\\\", \\\"{x:1347,y:691,t:1528143918714};\\\", \\\"{x:1347,y:692,t:1528143918729};\\\", \\\"{x:1347,y:695,t:1528143918743};\\\", \\\"{x:1345,y:701,t:1528143918760};\\\", \\\"{x:1343,y:707,t:1528143918777};\\\", \\\"{x:1336,y:722,t:1528143918793};\\\", \\\"{x:1325,y:740,t:1528143918810};\\\", \\\"{x:1315,y:757,t:1528143918827};\\\", \\\"{x:1305,y:775,t:1528143918843};\\\", \\\"{x:1296,y:790,t:1528143918860};\\\", \\\"{x:1288,y:803,t:1528143918877};\\\", \\\"{x:1283,y:815,t:1528143918894};\\\", \\\"{x:1280,y:822,t:1528143918910};\\\", \\\"{x:1279,y:828,t:1528143918927};\\\", \\\"{x:1277,y:835,t:1528143918943};\\\", \\\"{x:1275,y:842,t:1528143918960};\\\", \\\"{x:1270,y:859,t:1528143918977};\\\", \\\"{x:1266,y:869,t:1528143918994};\\\", \\\"{x:1262,y:877,t:1528143919010};\\\", \\\"{x:1257,y:888,t:1528143919027};\\\", \\\"{x:1255,y:897,t:1528143919044};\\\", \\\"{x:1250,y:907,t:1528143919060};\\\", \\\"{x:1246,y:915,t:1528143919078};\\\", \\\"{x:1242,y:921,t:1528143919095};\\\", \\\"{x:1238,y:926,t:1528143919111};\\\", \\\"{x:1234,y:931,t:1528143919128};\\\", \\\"{x:1231,y:935,t:1528143919144};\\\", \\\"{x:1229,y:938,t:1528143919161};\\\", \\\"{x:1226,y:941,t:1528143919177};\\\", \\\"{x:1225,y:943,t:1528143919194};\\\", \\\"{x:1224,y:944,t:1528143919212};\\\", \\\"{x:1223,y:945,t:1528143919228};\\\", \\\"{x:1223,y:946,t:1528143919274};\\\", \\\"{x:1222,y:947,t:1528143919282};\\\", \\\"{x:1222,y:948,t:1528143919294};\\\", \\\"{x:1221,y:951,t:1528143919313};\\\", \\\"{x:1220,y:956,t:1528143919329};\\\", \\\"{x:1218,y:960,t:1528143919345};\\\", \\\"{x:1217,y:964,t:1528143919362};\\\", \\\"{x:1216,y:966,t:1528143919379};\\\", \\\"{x:1215,y:968,t:1528143919395};\\\", \\\"{x:1214,y:969,t:1528143919412};\\\", \\\"{x:1213,y:972,t:1528143919428};\\\", \\\"{x:1213,y:973,t:1528143919446};\\\", \\\"{x:1213,y:974,t:1528143919480};\\\", \\\"{x:1212,y:974,t:1528143919495};\\\", \\\"{x:1211,y:974,t:1528143924418};\\\", \\\"{x:1205,y:965,t:1528143924426};\\\", \\\"{x:1172,y:899,t:1528143924442};\\\", \\\"{x:1137,y:841,t:1528143924457};\\\", \\\"{x:1086,y:761,t:1528143924474};\\\", \\\"{x:1030,y:683,t:1528143924491};\\\", \\\"{x:978,y:622,t:1528143924508};\\\", \\\"{x:936,y:568,t:1528143924526};\\\", \\\"{x:910,y:534,t:1528143924541};\\\", \\\"{x:899,y:512,t:1528143924557};\\\", \\\"{x:892,y:494,t:1528143924579};\\\", \\\"{x:886,y:493,t:1528143924764};\\\", \\\"{x:880,y:493,t:1528143924772};\\\", \\\"{x:873,y:493,t:1528143924783};\\\", \\\"{x:843,y:497,t:1528143924799};\\\", \\\"{x:788,y:508,t:1528143924816};\\\", \\\"{x:731,y:520,t:1528143924832};\\\", \\\"{x:680,y:523,t:1528143924849};\\\", \\\"{x:645,y:523,t:1528143924865};\\\", \\\"{x:620,y:523,t:1528143924881};\\\", \\\"{x:611,y:525,t:1528143924900};\\\", \\\"{x:610,y:525,t:1528143924915};\\\", \\\"{x:615,y:525,t:1528143924964};\\\", \\\"{x:625,y:523,t:1528143924972};\\\", \\\"{x:638,y:519,t:1528143924983};\\\", \\\"{x:684,y:513,t:1528143924999};\\\", \\\"{x:738,y:505,t:1528143925017};\\\", \\\"{x:757,y:503,t:1528143925033};\\\", \\\"{x:771,y:503,t:1528143925049};\\\", \\\"{x:779,y:503,t:1528143925066};\\\", \\\"{x:784,y:504,t:1528143925082};\\\", \\\"{x:790,y:508,t:1528143925099};\\\", \\\"{x:803,y:517,t:1528143925116};\\\", \\\"{x:810,y:522,t:1528143925133};\\\", \\\"{x:820,y:528,t:1528143925149};\\\", \\\"{x:828,y:532,t:1528143925166};\\\", \\\"{x:830,y:533,t:1528143925182};\\\", \\\"{x:831,y:535,t:1528143925199};\\\", \\\"{x:831,y:536,t:1528143925216};\\\", \\\"{x:831,y:539,t:1528143925233};\\\", \\\"{x:829,y:541,t:1528143925249};\\\", \\\"{x:828,y:543,t:1528143925266};\\\", \\\"{x:827,y:543,t:1528143925283};\\\", \\\"{x:824,y:545,t:1528143925853};\\\", \\\"{x:809,y:554,t:1528143925866};\\\", \\\"{x:779,y:573,t:1528143925883};\\\", \\\"{x:708,y:604,t:1528143925900};\\\", \\\"{x:645,y:630,t:1528143925916};\\\", \\\"{x:587,y:654,t:1528143925933};\\\", \\\"{x:550,y:666,t:1528143925949};\\\", \\\"{x:534,y:672,t:1528143925966};\\\", \\\"{x:522,y:677,t:1528143925983};\\\", \\\"{x:517,y:679,t:1528143926000};\\\", \\\"{x:511,y:681,t:1528143926017};\\\", \\\"{x:503,y:681,t:1528143926034};\\\", \\\"{x:491,y:678,t:1528143926050};\\\", \\\"{x:468,y:661,t:1528143926068};\\\", \\\"{x:405,y:601,t:1528143926085};\\\", \\\"{x:373,y:558,t:1528143926100};\\\", \\\"{x:353,y:516,t:1528143926118};\\\", \\\"{x:347,y:491,t:1528143926133};\\\", \\\"{x:344,y:470,t:1528143926150};\\\", \\\"{x:344,y:454,t:1528143926166};\\\", \\\"{x:346,y:441,t:1528143926183};\\\", \\\"{x:352,y:430,t:1528143926200};\\\", \\\"{x:358,y:424,t:1528143926217};\\\", \\\"{x:363,y:417,t:1528143926233};\\\", \\\"{x:366,y:415,t:1528143926250};\\\", \\\"{x:370,y:412,t:1528143926267};\\\", \\\"{x:372,y:410,t:1528143926284};\\\", \\\"{x:373,y:409,t:1528143926300};\\\", \\\"{x:374,y:409,t:1528143926340};\\\", \\\"{x:376,y:408,t:1528143926352};\\\", \\\"{x:377,y:408,t:1528143926367};\\\", \\\"{x:379,y:407,t:1528143926384};\\\", \\\"{x:381,y:407,t:1528143926405};\\\", \\\"{x:382,y:407,t:1528143926493};\\\", \\\"{x:384,y:407,t:1528143926501};\\\", \\\"{x:385,y:407,t:1528143926517};\\\", \\\"{x:386,y:409,t:1528143926534};\\\", \\\"{x:388,y:411,t:1528143926552};\\\", \\\"{x:391,y:413,t:1528143926567};\\\", \\\"{x:392,y:414,t:1528143926584};\\\", \\\"{x:393,y:415,t:1528143926601};\\\", \\\"{x:394,y:416,t:1528143926618};\\\", \\\"{x:395,y:416,t:1528143926634};\\\", \\\"{x:396,y:417,t:1528143926651};\\\", \\\"{x:397,y:417,t:1528143926700};\\\", \\\"{x:397,y:418,t:1528143926717};\\\", \\\"{x:398,y:418,t:1528143926734};\\\", \\\"{x:400,y:420,t:1528143926753};\\\", \\\"{x:401,y:421,t:1528143926767};\\\", \\\"{x:402,y:422,t:1528143926845};\\\", \\\"{x:403,y:423,t:1528143926925};\\\", \\\"{x:404,y:423,t:1528143927076};\\\", \\\"{x:405,y:425,t:1528143927116};\\\", \\\"{x:406,y:426,t:1528143927149};\\\", \\\"{x:407,y:427,t:1528143927197};\\\", \\\"{x:408,y:428,t:1528143927309};\\\", \\\"{x:409,y:429,t:1528143927340};\\\", \\\"{x:410,y:430,t:1528143927868};\\\", \\\"{x:410,y:431,t:1528143928163};\\\", \\\"{x:411,y:432,t:1528143928645};\\\", \\\"{x:412,y:432,t:1528143928853};\\\", \\\"{x:412,y:433,t:1528143929197};\\\", \\\"{x:412,y:434,t:1528143929261};\\\", \\\"{x:413,y:437,t:1528143929271};\\\", \\\"{x:416,y:442,t:1528143929287};\\\", \\\"{x:418,y:447,t:1528143929304};\\\", \\\"{x:420,y:452,t:1528143929321};\\\", \\\"{x:423,y:459,t:1528143929337};\\\", \\\"{x:428,y:466,t:1528143929353};\\\", \\\"{x:434,y:474,t:1528143929370};\\\", \\\"{x:441,y:484,t:1528143929386};\\\", \\\"{x:447,y:491,t:1528143929405};\\\", \\\"{x:453,y:500,t:1528143929419};\\\", \\\"{x:457,y:505,t:1528143929436};\\\", \\\"{x:459,y:509,t:1528143929453};\\\", \\\"{x:460,y:512,t:1528143929469};\\\", \\\"{x:462,y:514,t:1528143929486};\\\", \\\"{x:462,y:515,t:1528143929503};\\\", \\\"{x:462,y:516,t:1528143929540};\\\", \\\"{x:462,y:517,t:1528143929613};\\\", \\\"{x:462,y:518,t:1528143929629};\\\", \\\"{x:464,y:518,t:1528143929917};\\\", \\\"{x:471,y:509,t:1528143929925};\\\", \\\"{x:479,y:497,t:1528143929936};\\\", \\\"{x:496,y:479,t:1528143929953};\\\", \\\"{x:517,y:461,t:1528143929970};\\\", \\\"{x:532,y:449,t:1528143929986};\\\", \\\"{x:541,y:442,t:1528143930003};\\\", \\\"{x:545,y:437,t:1528143930019};\\\", \\\"{x:548,y:435,t:1528143930036};\\\", \\\"{x:554,y:431,t:1528143930053};\\\", \\\"{x:559,y:428,t:1528143930070};\\\", \\\"{x:563,y:426,t:1528143930086};\\\", \\\"{x:567,y:424,t:1528143930103};\\\", \\\"{x:569,y:423,t:1528143930120};\\\", \\\"{x:570,y:422,t:1528143930136};\\\", \\\"{x:573,y:421,t:1528143930153};\\\", \\\"{x:573,y:420,t:1528143930170};\\\", \\\"{x:574,y:419,t:1528143930187};\\\", \\\"{x:576,y:419,t:1528143930203};\\\", \\\"{x:578,y:419,t:1528143930220};\\\", \\\"{x:580,y:417,t:1528143930238};\\\", \\\"{x:581,y:417,t:1528143930253};\\\", \\\"{x:583,y:417,t:1528143930270};\\\", \\\"{x:584,y:416,t:1528143930286};\\\", \\\"{x:586,y:416,t:1528143930304};\\\", \\\"{x:588,y:416,t:1528143930320};\\\", \\\"{x:593,y:416,t:1528143930338};\\\", \\\"{x:598,y:416,t:1528143930354};\\\", \\\"{x:603,y:416,t:1528143930371};\\\", \\\"{x:610,y:417,t:1528143930387};\\\", \\\"{x:615,y:417,t:1528143930404};\\\", \\\"{x:617,y:418,t:1528143930420};\\\", \\\"{x:619,y:418,t:1528143930437};\\\", \\\"{x:621,y:418,t:1528143930453};\\\", \\\"{x:622,y:418,t:1528143930477};\\\", \\\"{x:624,y:420,t:1528143930487};\\\", \\\"{x:626,y:420,t:1528143930503};\\\", \\\"{x:628,y:420,t:1528143930521};\\\", \\\"{x:629,y:420,t:1528143930538};\\\", \\\"{x:630,y:420,t:1528143930554};\\\", \\\"{x:631,y:421,t:1528143930571};\\\", \\\"{x:632,y:421,t:1528143930587};\\\", \\\"{x:633,y:421,t:1528143930604};\\\", \\\"{x:634,y:422,t:1528143930629};\\\", \\\"{x:635,y:422,t:1528143930652};\\\", \\\"{x:636,y:423,t:1528143930693};\\\", \\\"{x:638,y:423,t:1528143930741};\\\", \\\"{x:639,y:423,t:1528143930773};\\\", \\\"{x:640,y:423,t:1528143930821};\\\", \\\"{x:641,y:423,t:1528143930844};\\\", \\\"{x:642,y:423,t:1528143930932};\\\", \\\"{x:643,y:423,t:1528143930956};\\\", \\\"{x:644,y:423,t:1528143931020};\\\", \\\"{x:646,y:424,t:1528143931037};\\\", \\\"{x:651,y:427,t:1528143931054};\\\", \\\"{x:665,y:435,t:1528143931069};\\\", \\\"{x:689,y:450,t:1528143931087};\\\", \\\"{x:738,y:478,t:1528143931104};\\\", \\\"{x:813,y:530,t:1528143931122};\\\", \\\"{x:933,y:597,t:1528143931137};\\\", \\\"{x:1058,y:662,t:1528143931154};\\\", \\\"{x:1142,y:705,t:1528143931171};\\\", \\\"{x:1152,y:710,t:1528143931188};\\\", \\\"{x:1170,y:718,t:1528143931204};\\\", \\\"{x:1177,y:722,t:1528143931222};\\\", \\\"{x:1178,y:722,t:1528143931237};\\\", \\\"{x:1179,y:724,t:1528143931260};\\\", \\\"{x:1181,y:726,t:1528143931271};\\\", \\\"{x:1185,y:727,t:1528143931287};\\\", \\\"{x:1186,y:729,t:1528143931304};\\\", \\\"{x:1187,y:729,t:1528143931322};\\\", \\\"{x:1188,y:729,t:1528143931340};\\\", \\\"{x:1188,y:730,t:1528143931354};\\\", \\\"{x:1190,y:732,t:1528143931371};\\\", \\\"{x:1193,y:735,t:1528143931387};\\\", \\\"{x:1197,y:741,t:1528143931404};\\\", \\\"{x:1202,y:747,t:1528143931421};\\\", \\\"{x:1209,y:758,t:1528143931437};\\\", \\\"{x:1214,y:768,t:1528143931454};\\\", \\\"{x:1218,y:782,t:1528143931471};\\\", \\\"{x:1222,y:792,t:1528143931487};\\\", \\\"{x:1223,y:802,t:1528143931504};\\\", \\\"{x:1223,y:815,t:1528143931521};\\\", \\\"{x:1223,y:829,t:1528143931537};\\\", \\\"{x:1223,y:842,t:1528143931555};\\\", \\\"{x:1222,y:858,t:1528143931571};\\\", \\\"{x:1216,y:881,t:1528143931588};\\\", \\\"{x:1213,y:897,t:1528143931605};\\\", \\\"{x:1207,y:914,t:1528143931622};\\\", \\\"{x:1206,y:925,t:1528143931638};\\\", \\\"{x:1206,y:930,t:1528143931655};\\\", \\\"{x:1206,y:933,t:1528143931672};\\\", \\\"{x:1206,y:934,t:1528143931688};\\\", \\\"{x:1207,y:934,t:1528143931741};\\\", \\\"{x:1209,y:934,t:1528143931757};\\\", \\\"{x:1212,y:934,t:1528143931772};\\\", \\\"{x:1223,y:926,t:1528143931788};\\\", \\\"{x:1234,y:916,t:1528143931805};\\\", \\\"{x:1248,y:901,t:1528143931821};\\\", \\\"{x:1263,y:882,t:1528143931839};\\\", \\\"{x:1278,y:859,t:1528143931855};\\\", \\\"{x:1292,y:831,t:1528143931872};\\\", \\\"{x:1310,y:796,t:1528143931889};\\\", \\\"{x:1325,y:767,t:1528143931905};\\\", \\\"{x:1334,y:742,t:1528143931922};\\\", \\\"{x:1339,y:721,t:1528143931938};\\\", \\\"{x:1344,y:705,t:1528143931954};\\\", \\\"{x:1349,y:695,t:1528143931972};\\\", \\\"{x:1362,y:675,t:1528143931988};\\\", \\\"{x:1370,y:664,t:1528143932006};\\\", \\\"{x:1377,y:654,t:1528143932021};\\\", \\\"{x:1382,y:647,t:1528143932038};\\\", \\\"{x:1387,y:640,t:1528143932055};\\\", \\\"{x:1392,y:633,t:1528143932071};\\\", \\\"{x:1396,y:629,t:1528143932088};\\\", \\\"{x:1400,y:625,t:1528143932106};\\\", \\\"{x:1404,y:620,t:1528143932121};\\\", \\\"{x:1412,y:610,t:1528143932139};\\\", \\\"{x:1420,y:601,t:1528143932156};\\\", \\\"{x:1429,y:591,t:1528143932171};\\\", \\\"{x:1437,y:578,t:1528143932188};\\\", \\\"{x:1439,y:575,t:1528143932206};\\\", \\\"{x:1441,y:573,t:1528143932222};\\\", \\\"{x:1442,y:572,t:1528143932239};\\\", \\\"{x:1443,y:571,t:1528143932256};\\\", \\\"{x:1445,y:567,t:1528143932271};\\\", \\\"{x:1445,y:566,t:1528143932288};\\\", \\\"{x:1446,y:564,t:1528143932306};\\\", \\\"{x:1446,y:563,t:1528143932349};\\\", \\\"{x:1447,y:563,t:1528143932373};\\\", \\\"{x:1448,y:562,t:1528143932389};\\\", \\\"{x:1442,y:562,t:1528143932837};\\\", \\\"{x:1429,y:569,t:1528143932845};\\\", \\\"{x:1409,y:583,t:1528143932856};\\\", \\\"{x:1348,y:625,t:1528143932873};\\\", \\\"{x:1266,y:673,t:1528143932890};\\\", \\\"{x:1166,y:718,t:1528143932906};\\\", \\\"{x:1083,y:741,t:1528143932923};\\\", \\\"{x:1017,y:750,t:1528143932940};\\\", \\\"{x:947,y:750,t:1528143932956};\\\", \\\"{x:885,y:750,t:1528143932973};\\\", \\\"{x:861,y:750,t:1528143932990};\\\", \\\"{x:839,y:750,t:1528143933006};\\\", \\\"{x:823,y:751,t:1528143933023};\\\", \\\"{x:802,y:754,t:1528143933040};\\\", \\\"{x:779,y:756,t:1528143933056};\\\", \\\"{x:756,y:761,t:1528143933073};\\\", \\\"{x:734,y:764,t:1528143933090};\\\", \\\"{x:718,y:766,t:1528143933105};\\\", \\\"{x:704,y:767,t:1528143933123};\\\", \\\"{x:686,y:767,t:1528143933139};\\\", \\\"{x:660,y:767,t:1528143933156};\\\", \\\"{x:565,y:761,t:1528143933173};\\\", \\\"{x:507,y:753,t:1528143933191};\\\", \\\"{x:472,y:748,t:1528143933205};\\\", \\\"{x:459,y:745,t:1528143933222};\\\", \\\"{x:458,y:744,t:1528143933239};\\\", \\\"{x:457,y:743,t:1528143933268};\\\", \\\"{x:457,y:742,t:1528143933300};\\\", \\\"{x:457,y:740,t:1528143933308};\\\", \\\"{x:457,y:737,t:1528143933322};\\\", \\\"{x:459,y:734,t:1528143933340};\\\", \\\"{x:469,y:728,t:1528143933356};\\\", \\\"{x:479,y:722,t:1528143933372};\\\", \\\"{x:486,y:719,t:1528143933390};\\\", \\\"{x:495,y:717,t:1528143933406};\\\", \\\"{x:502,y:714,t:1528143933422};\\\", \\\"{x:504,y:713,t:1528143933439};\\\", \\\"{x:505,y:713,t:1528143933456};\\\", \\\"{x:505,y:715,t:1528143933701};\\\", \\\"{x:505,y:717,t:1528143933709};\\\", \\\"{x:505,y:720,t:1528143933725};\\\", \\\"{x:504,y:722,t:1528143933739};\\\", \\\"{x:503,y:726,t:1528143933755};\\\", \\\"{x:503,y:727,t:1528143933773};\\\", \\\"{x:502,y:728,t:1528143933789};\\\", \\\"{x:501,y:729,t:1528143933806};\\\", \\\"{x:506,y:729,t:1528143934059};\\\", \\\"{x:520,y:720,t:1528143934073};\\\", \\\"{x:535,y:706,t:1528143934089};\\\", \\\"{x:547,y:692,t:1528143934106};\\\", \\\"{x:553,y:676,t:1528143934123};\\\", \\\"{x:567,y:642,t:1528143934140};\\\", \\\"{x:576,y:612,t:1528143934156};\\\", \\\"{x:583,y:590,t:1528143934173};\\\", \\\"{x:593,y:558,t:1528143934190};\\\", \\\"{x:600,y:530,t:1528143934207};\\\", \\\"{x:605,y:507,t:1528143934223};\\\", \\\"{x:610,y:486,t:1528143934240};\\\", \\\"{x:615,y:469,t:1528143934257};\\\", \\\"{x:616,y:454,t:1528143934273};\\\", \\\"{x:617,y:444,t:1528143934290};\\\", \\\"{x:617,y:436,t:1528143934307};\\\", \\\"{x:617,y:432,t:1528143934324};\\\", \\\"{x:617,y:428,t:1528143934340};\\\", \\\"{x:616,y:428,t:1528143934428};\\\", \\\"{x:615,y:428,t:1528143934509};\\\", \\\"{x:615,y:427,t:1528143935068};\\\" ] }, { \\\"rt\\\": 17492, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 17, \\\"time_elapsed\\\": 868250, \\\"internal_node_id\\\": \\\"0.0-6.0-7.0\\\", \\\"subject\\\": \\\"MKTF4\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"zulu\\\", \\\"condition\\\": \\\"211\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"meets\\\", \\\"q\\\": 13, \\\"clicks\\\": 2.5, \\\"explicit\\\": 2, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XInside-YFull\\\", \\\"correct\\\": 1, \\\"orth_correct\\\": 0, \\\"answer\\\": [ \\\"E\\\", \\\"F\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-O -G -G -H -H -Z -Z \\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:615,y:426,t:1528143935339};\\\", \\\"{x:615,y:424,t:1528143935364};\\\", \\\"{x:615,y:423,t:1528143935373};\\\", \\\"{x:615,y:422,t:1528143935396};\\\", \\\"{x:616,y:420,t:1528143935407};\\\", \\\"{x:617,y:418,t:1528143935424};\\\", \\\"{x:618,y:415,t:1528143935441};\\\", \\\"{x:619,y:412,t:1528143935457};\\\", \\\"{x:620,y:410,t:1528143935474};\\\", \\\"{x:621,y:407,t:1528143935492};\\\", \\\"{x:622,y:406,t:1528143935507};\\\", \\\"{x:624,y:401,t:1528143935524};\\\", \\\"{x:625,y:398,t:1528143935541};\\\", \\\"{x:627,y:396,t:1528143935557};\\\", \\\"{x:627,y:394,t:1528143935575};\\\", \\\"{x:627,y:393,t:1528143935592};\\\", \\\"{x:629,y:388,t:1528143935683};\\\", \\\"{x:629,y:387,t:1528143935828};\\\", \\\"{x:627,y:387,t:1528143937165};\\\", \\\"{x:618,y:393,t:1528143937176};\\\", \\\"{x:593,y:401,t:1528143937192};\\\", \\\"{x:567,y:412,t:1528143937209};\\\", \\\"{x:545,y:421,t:1528143937226};\\\", \\\"{x:526,y:428,t:1528143937242};\\\", \\\"{x:512,y:432,t:1528143937259};\\\", \\\"{x:504,y:436,t:1528143937276};\\\", \\\"{x:497,y:438,t:1528143937293};\\\", \\\"{x:491,y:441,t:1528143937309};\\\", \\\"{x:487,y:443,t:1528143937326};\\\", \\\"{x:484,y:445,t:1528143937343};\\\", \\\"{x:481,y:446,t:1528143937360};\\\", \\\"{x:481,y:447,t:1528143937375};\\\", \\\"{x:484,y:447,t:1528143937445};\\\", \\\"{x:488,y:447,t:1528143937459};\\\", \\\"{x:500,y:448,t:1528143937475};\\\", \\\"{x:524,y:448,t:1528143937492};\\\", \\\"{x:546,y:453,t:1528143937510};\\\", \\\"{x:574,y:457,t:1528143937526};\\\", \\\"{x:605,y:461,t:1528143937543};\\\", \\\"{x:635,y:466,t:1528143937560};\\\", \\\"{x:677,y:479,t:1528143937576};\\\", \\\"{x:717,y:492,t:1528143937595};\\\", \\\"{x:770,y:509,t:1528143937610};\\\", \\\"{x:837,y:529,t:1528143937625};\\\", \\\"{x:921,y:555,t:1528143937643};\\\", \\\"{x:1011,y:587,t:1528143937659};\\\", \\\"{x:1175,y:638,t:1528143937676};\\\", \\\"{x:1288,y:671,t:1528143937692};\\\", \\\"{x:1387,y:707,t:1528143937709};\\\", \\\"{x:1461,y:737,t:1528143937725};\\\", \\\"{x:1519,y:764,t:1528143937743};\\\", \\\"{x:1562,y:787,t:1528143937760};\\\", \\\"{x:1590,y:802,t:1528143937775};\\\", \\\"{x:1607,y:810,t:1528143937793};\\\", \\\"{x:1615,y:814,t:1528143937810};\\\", \\\"{x:1621,y:819,t:1528143937825};\\\", \\\"{x:1625,y:822,t:1528143937843};\\\", \\\"{x:1627,y:825,t:1528143937859};\\\", \\\"{x:1628,y:825,t:1528143937876};\\\", \\\"{x:1628,y:826,t:1528143937892};\\\", \\\"{x:1628,y:827,t:1528143937924};\\\", \\\"{x:1628,y:828,t:1528143937941};\\\", \\\"{x:1628,y:829,t:1528143937956};\\\", \\\"{x:1626,y:832,t:1528143937964};\\\", \\\"{x:1622,y:833,t:1528143937976};\\\", \\\"{x:1611,y:840,t:1528143937992};\\\", \\\"{x:1599,y:845,t:1528143938008};\\\", \\\"{x:1594,y:848,t:1528143938026};\\\", \\\"{x:1588,y:852,t:1528143938041};\\\", \\\"{x:1585,y:854,t:1528143938059};\\\", \\\"{x:1584,y:855,t:1528143938075};\\\", \\\"{x:1584,y:856,t:1528143938091};\\\", \\\"{x:1584,y:860,t:1528143938109};\\\", \\\"{x:1591,y:867,t:1528143938125};\\\", \\\"{x:1608,y:871,t:1528143938141};\\\", \\\"{x:1624,y:873,t:1528143938159};\\\", \\\"{x:1643,y:876,t:1528143938174};\\\", \\\"{x:1661,y:878,t:1528143938191};\\\", \\\"{x:1677,y:883,t:1528143938208};\\\", \\\"{x:1695,y:884,t:1528143938225};\\\", \\\"{x:1710,y:887,t:1528143938242};\\\", \\\"{x:1728,y:889,t:1528143938259};\\\", \\\"{x:1738,y:889,t:1528143938275};\\\", \\\"{x:1745,y:889,t:1528143938292};\\\", \\\"{x:1746,y:889,t:1528143938309};\\\", \\\"{x:1746,y:886,t:1528143938356};\\\", \\\"{x:1744,y:868,t:1528143938375};\\\", \\\"{x:1725,y:839,t:1528143938392};\\\", \\\"{x:1701,y:805,t:1528143938408};\\\", \\\"{x:1681,y:770,t:1528143938425};\\\", \\\"{x:1673,y:743,t:1528143938442};\\\", \\\"{x:1663,y:709,t:1528143938458};\\\", \\\"{x:1661,y:679,t:1528143938475};\\\", \\\"{x:1661,y:646,t:1528143938492};\\\", \\\"{x:1661,y:620,t:1528143938508};\\\", \\\"{x:1661,y:589,t:1528143938525};\\\", \\\"{x:1661,y:571,t:1528143938541};\\\", \\\"{x:1661,y:560,t:1528143938558};\\\", \\\"{x:1661,y:546,t:1528143938575};\\\", \\\"{x:1661,y:535,t:1528143938591};\\\", \\\"{x:1661,y:521,t:1528143938608};\\\", \\\"{x:1661,y:505,t:1528143938625};\\\", \\\"{x:1661,y:491,t:1528143938641};\\\", \\\"{x:1661,y:481,t:1528143938658};\\\", \\\"{x:1656,y:467,t:1528143938674};\\\", \\\"{x:1651,y:458,t:1528143938691};\\\", \\\"{x:1649,y:456,t:1528143938708};\\\", \\\"{x:1648,y:455,t:1528143938724};\\\", \\\"{x:1646,y:454,t:1528143938741};\\\", \\\"{x:1646,y:453,t:1528143938758};\\\", \\\"{x:1645,y:453,t:1528143938774};\\\", \\\"{x:1641,y:451,t:1528143938791};\\\", \\\"{x:1633,y:445,t:1528143938808};\\\", \\\"{x:1626,y:442,t:1528143938824};\\\", \\\"{x:1625,y:442,t:1528143938841};\\\", \\\"{x:1624,y:442,t:1528143938857};\\\", \\\"{x:1622,y:442,t:1528143938874};\\\", \\\"{x:1613,y:442,t:1528143938891};\\\", \\\"{x:1597,y:450,t:1528143938907};\\\", \\\"{x:1570,y:466,t:1528143938924};\\\", \\\"{x:1519,y:495,t:1528143938940};\\\", \\\"{x:1484,y:514,t:1528143938957};\\\", \\\"{x:1461,y:528,t:1528143938974};\\\", \\\"{x:1448,y:534,t:1528143938991};\\\", \\\"{x:1444,y:537,t:1528143939007};\\\", \\\"{x:1443,y:537,t:1528143939024};\\\", \\\"{x:1443,y:538,t:1528143939040};\\\", \\\"{x:1440,y:538,t:1528143939057};\\\", \\\"{x:1436,y:541,t:1528143939074};\\\", \\\"{x:1429,y:547,t:1528143939090};\\\", \\\"{x:1422,y:552,t:1528143939107};\\\", \\\"{x:1415,y:557,t:1528143939124};\\\", \\\"{x:1409,y:562,t:1528143939141};\\\", \\\"{x:1397,y:573,t:1528143939157};\\\", \\\"{x:1393,y:579,t:1528143939174};\\\", \\\"{x:1389,y:584,t:1528143939190};\\\", \\\"{x:1386,y:588,t:1528143939207};\\\", \\\"{x:1383,y:592,t:1528143939223};\\\", \\\"{x:1382,y:595,t:1528143939240};\\\", \\\"{x:1379,y:600,t:1528143939257};\\\", \\\"{x:1376,y:605,t:1528143939273};\\\", \\\"{x:1372,y:610,t:1528143939290};\\\", \\\"{x:1370,y:614,t:1528143939307};\\\", \\\"{x:1366,y:620,t:1528143939323};\\\", \\\"{x:1363,y:625,t:1528143939340};\\\", \\\"{x:1356,y:632,t:1528143939356};\\\", \\\"{x:1353,y:636,t:1528143939372};\\\", \\\"{x:1351,y:638,t:1528143939390};\\\", \\\"{x:1348,y:642,t:1528143939406};\\\", \\\"{x:1345,y:646,t:1528143939423};\\\", \\\"{x:1343,y:649,t:1528143939440};\\\", \\\"{x:1341,y:650,t:1528143939456};\\\", \\\"{x:1339,y:651,t:1528143939473};\\\", \\\"{x:1337,y:653,t:1528143939490};\\\", \\\"{x:1336,y:655,t:1528143939506};\\\", \\\"{x:1334,y:656,t:1528143939523};\\\", \\\"{x:1329,y:659,t:1528143939539};\\\", \\\"{x:1325,y:663,t:1528143939556};\\\", \\\"{x:1315,y:669,t:1528143939572};\\\", \\\"{x:1311,y:672,t:1528143939589};\\\", \\\"{x:1307,y:675,t:1528143939606};\\\", \\\"{x:1300,y:680,t:1528143939623};\\\", \\\"{x:1295,y:684,t:1528143939639};\\\", \\\"{x:1291,y:689,t:1528143939656};\\\", \\\"{x:1284,y:694,t:1528143939673};\\\", \\\"{x:1281,y:697,t:1528143939690};\\\", \\\"{x:1279,y:699,t:1528143939706};\\\", \\\"{x:1275,y:701,t:1528143939722};\\\", \\\"{x:1273,y:704,t:1528143939739};\\\", \\\"{x:1272,y:705,t:1528143939756};\\\", \\\"{x:1270,y:709,t:1528143939772};\\\", \\\"{x:1266,y:715,t:1528143939788};\\\", \\\"{x:1264,y:722,t:1528143939806};\\\", \\\"{x:1261,y:731,t:1528143939822};\\\", \\\"{x:1258,y:745,t:1528143939839};\\\", \\\"{x:1258,y:761,t:1528143939856};\\\", \\\"{x:1261,y:781,t:1528143939872};\\\", \\\"{x:1268,y:799,t:1528143939889};\\\", \\\"{x:1282,y:816,t:1528143939905};\\\", \\\"{x:1301,y:833,t:1528143939922};\\\", \\\"{x:1329,y:846,t:1528143939939};\\\", \\\"{x:1369,y:861,t:1528143939955};\\\", \\\"{x:1414,y:873,t:1528143939972};\\\", \\\"{x:1490,y:882,t:1528143939988};\\\", \\\"{x:1542,y:887,t:1528143940005};\\\", \\\"{x:1581,y:887,t:1528143940022};\\\", \\\"{x:1611,y:884,t:1528143940039};\\\", \\\"{x:1642,y:876,t:1528143940055};\\\", \\\"{x:1665,y:865,t:1528143940072};\\\", \\\"{x:1682,y:858,t:1528143940089};\\\", \\\"{x:1696,y:853,t:1528143940105};\\\", \\\"{x:1703,y:849,t:1528143940122};\\\", \\\"{x:1707,y:847,t:1528143940138};\\\", \\\"{x:1709,y:846,t:1528143940155};\\\", \\\"{x:1709,y:845,t:1528143940172};\\\", \\\"{x:1710,y:843,t:1528143940189};\\\", \\\"{x:1710,y:842,t:1528143940205};\\\", \\\"{x:1710,y:840,t:1528143940221};\\\", \\\"{x:1710,y:836,t:1528143940239};\\\", \\\"{x:1707,y:832,t:1528143940256};\\\", \\\"{x:1702,y:828,t:1528143940271};\\\", \\\"{x:1695,y:824,t:1528143940288};\\\", \\\"{x:1687,y:822,t:1528143940305};\\\", \\\"{x:1674,y:818,t:1528143940321};\\\", \\\"{x:1653,y:808,t:1528143940338};\\\", \\\"{x:1618,y:794,t:1528143940355};\\\", \\\"{x:1560,y:769,t:1528143940371};\\\", \\\"{x:1505,y:745,t:1528143940389};\\\", \\\"{x:1463,y:724,t:1528143940405};\\\", \\\"{x:1449,y:712,t:1528143940421};\\\", \\\"{x:1442,y:701,t:1528143940438};\\\", \\\"{x:1436,y:689,t:1528143940455};\\\", \\\"{x:1433,y:683,t:1528143940471};\\\", \\\"{x:1432,y:676,t:1528143940488};\\\", \\\"{x:1432,y:669,t:1528143940504};\\\", \\\"{x:1432,y:663,t:1528143940521};\\\", \\\"{x:1434,y:657,t:1528143940538};\\\", \\\"{x:1439,y:651,t:1528143940554};\\\", \\\"{x:1446,y:644,t:1528143940571};\\\", \\\"{x:1455,y:638,t:1528143940587};\\\", \\\"{x:1471,y:629,t:1528143940604};\\\", \\\"{x:1483,y:624,t:1528143940620};\\\", \\\"{x:1495,y:621,t:1528143940637};\\\", \\\"{x:1506,y:621,t:1528143940654};\\\", \\\"{x:1515,y:621,t:1528143940671};\\\", \\\"{x:1521,y:622,t:1528143940687};\\\", \\\"{x:1527,y:627,t:1528143940704};\\\", \\\"{x:1535,y:634,t:1528143940721};\\\", \\\"{x:1548,y:644,t:1528143940738};\\\", \\\"{x:1562,y:655,t:1528143940755};\\\", \\\"{x:1569,y:660,t:1528143940770};\\\", \\\"{x:1572,y:663,t:1528143940787};\\\", \\\"{x:1572,y:664,t:1528143940804};\\\", \\\"{x:1572,y:668,t:1528143940821};\\\", \\\"{x:1572,y:670,t:1528143940837};\\\", \\\"{x:1573,y:673,t:1528143940854};\\\", \\\"{x:1574,y:677,t:1528143940870};\\\", \\\"{x:1575,y:680,t:1528143940887};\\\", \\\"{x:1575,y:681,t:1528143940903};\\\", \\\"{x:1576,y:683,t:1528143940920};\\\", \\\"{x:1577,y:685,t:1528143940937};\\\", \\\"{x:1579,y:687,t:1528143940953};\\\", \\\"{x:1582,y:689,t:1528143940970};\\\", \\\"{x:1586,y:691,t:1528143940987};\\\", \\\"{x:1589,y:691,t:1528143941003};\\\", \\\"{x:1594,y:694,t:1528143941020};\\\", \\\"{x:1596,y:695,t:1528143941037};\\\", \\\"{x:1599,y:696,t:1528143941053};\\\", \\\"{x:1600,y:697,t:1528143941070};\\\", \\\"{x:1602,y:698,t:1528143941086};\\\", \\\"{x:1602,y:699,t:1528143941103};\\\", \\\"{x:1602,y:703,t:1528143941120};\\\", \\\"{x:1602,y:706,t:1528143941136};\\\", \\\"{x:1602,y:709,t:1528143941153};\\\", \\\"{x:1602,y:712,t:1528143941170};\\\", \\\"{x:1602,y:716,t:1528143941186};\\\", \\\"{x:1600,y:720,t:1528143941203};\\\", \\\"{x:1597,y:726,t:1528143941220};\\\", \\\"{x:1595,y:732,t:1528143941236};\\\", \\\"{x:1591,y:741,t:1528143941253};\\\", \\\"{x:1589,y:746,t:1528143941269};\\\", \\\"{x:1585,y:754,t:1528143941286};\\\", \\\"{x:1583,y:760,t:1528143941303};\\\", \\\"{x:1580,y:767,t:1528143941319};\\\", \\\"{x:1576,y:775,t:1528143941336};\\\", \\\"{x:1571,y:783,t:1528143941353};\\\", \\\"{x:1569,y:788,t:1528143941369};\\\", \\\"{x:1567,y:792,t:1528143941386};\\\", \\\"{x:1564,y:797,t:1528143941402};\\\", \\\"{x:1563,y:800,t:1528143941419};\\\", \\\"{x:1561,y:807,t:1528143941437};\\\", \\\"{x:1557,y:813,t:1528143941452};\\\", \\\"{x:1555,y:819,t:1528143941469};\\\", \\\"{x:1553,y:824,t:1528143941486};\\\", \\\"{x:1549,y:833,t:1528143941503};\\\", \\\"{x:1548,y:836,t:1528143941520};\\\", \\\"{x:1545,y:842,t:1528143941536};\\\", \\\"{x:1543,y:846,t:1528143941552};\\\", \\\"{x:1541,y:849,t:1528143941569};\\\", \\\"{x:1539,y:854,t:1528143941586};\\\", \\\"{x:1537,y:858,t:1528143941602};\\\", \\\"{x:1533,y:866,t:1528143941619};\\\", \\\"{x:1531,y:870,t:1528143941635};\\\", \\\"{x:1526,y:878,t:1528143941653};\\\", \\\"{x:1523,y:884,t:1528143941668};\\\", \\\"{x:1519,y:892,t:1528143941685};\\\", \\\"{x:1516,y:898,t:1528143941702};\\\", \\\"{x:1513,y:905,t:1528143941720};\\\", \\\"{x:1511,y:910,t:1528143941735};\\\", \\\"{x:1510,y:913,t:1528143941752};\\\", \\\"{x:1509,y:916,t:1528143941768};\\\", \\\"{x:1507,y:920,t:1528143941786};\\\", \\\"{x:1505,y:923,t:1528143941802};\\\", \\\"{x:1503,y:929,t:1528143941818};\\\", \\\"{x:1500,y:933,t:1528143941835};\\\", \\\"{x:1497,y:939,t:1528143941853};\\\", \\\"{x:1496,y:945,t:1528143941869};\\\", \\\"{x:1493,y:948,t:1528143941885};\\\", \\\"{x:1493,y:951,t:1528143941901};\\\", \\\"{x:1493,y:952,t:1528143941918};\\\", \\\"{x:1493,y:953,t:1528143941934};\\\", \\\"{x:1492,y:955,t:1528143941950};\\\", \\\"{x:1491,y:956,t:1528143941967};\\\", \\\"{x:1491,y:957,t:1528143941984};\\\", \\\"{x:1490,y:958,t:1528143942001};\\\", \\\"{x:1490,y:959,t:1528143942017};\\\", \\\"{x:1489,y:960,t:1528143942034};\\\", \\\"{x:1489,y:961,t:1528143942050};\\\", \\\"{x:1488,y:962,t:1528143942067};\\\", \\\"{x:1487,y:962,t:1528143942085};\\\", \\\"{x:1486,y:963,t:1528143942101};\\\", \\\"{x:1486,y:964,t:1528143942118};\\\", \\\"{x:1485,y:965,t:1528143942134};\\\", \\\"{x:1485,y:966,t:1528143942151};\\\", \\\"{x:1484,y:966,t:1528143943029};\\\", \\\"{x:1483,y:966,t:1528143943037};\\\", \\\"{x:1482,y:966,t:1528143943076};\\\", \\\"{x:1482,y:967,t:1528143943581};\\\", \\\"{x:1466,y:962,t:1528143944085};\\\", \\\"{x:1420,y:943,t:1528143944097};\\\", \\\"{x:1313,y:899,t:1528143944114};\\\", \\\"{x:1125,y:840,t:1528143944132};\\\", \\\"{x:930,y:761,t:1528143944147};\\\", \\\"{x:684,y:669,t:1528143944165};\\\", \\\"{x:587,y:620,t:1528143944181};\\\", \\\"{x:526,y:583,t:1528143944197};\\\", \\\"{x:484,y:553,t:1528143944214};\\\", \\\"{x:462,y:537,t:1528143944230};\\\", \\\"{x:456,y:532,t:1528143944247};\\\", \\\"{x:454,y:531,t:1528143944264};\\\", \\\"{x:454,y:530,t:1528143944307};\\\", \\\"{x:456,y:527,t:1528143944316};\\\", \\\"{x:462,y:524,t:1528143944331};\\\", \\\"{x:493,y:512,t:1528143944348};\\\", \\\"{x:529,y:506,t:1528143944365};\\\", \\\"{x:577,y:499,t:1528143944382};\\\", \\\"{x:593,y:498,t:1528143944397};\\\", \\\"{x:601,y:495,t:1528143944415};\\\", \\\"{x:611,y:493,t:1528143944431};\\\", \\\"{x:626,y:493,t:1528143944448};\\\", \\\"{x:647,y:493,t:1528143944464};\\\", \\\"{x:675,y:493,t:1528143944482};\\\", \\\"{x:698,y:493,t:1528143944497};\\\", \\\"{x:724,y:493,t:1528143944516};\\\", \\\"{x:754,y:493,t:1528143944531};\\\", \\\"{x:766,y:495,t:1528143944548};\\\", \\\"{x:767,y:495,t:1528143944565};\\\", \\\"{x:769,y:495,t:1528143944581};\\\", \\\"{x:770,y:495,t:1528143944599};\\\", \\\"{x:772,y:495,t:1528143944614};\\\", \\\"{x:774,y:495,t:1528143944632};\\\", \\\"{x:775,y:495,t:1528143944648};\\\", \\\"{x:778,y:495,t:1528143944665};\\\", \\\"{x:780,y:495,t:1528143944682};\\\", \\\"{x:782,y:496,t:1528143944699};\\\", \\\"{x:790,y:497,t:1528143944715};\\\", \\\"{x:811,y:500,t:1528143944732};\\\", \\\"{x:826,y:500,t:1528143944749};\\\", \\\"{x:841,y:500,t:1528143944765};\\\", \\\"{x:851,y:500,t:1528143944782};\\\", \\\"{x:854,y:500,t:1528143944797};\\\", \\\"{x:855,y:501,t:1528143944892};\\\", \\\"{x:855,y:502,t:1528143944899};\\\", \\\"{x:853,y:504,t:1528143944915};\\\", \\\"{x:849,y:505,t:1528143944931};\\\", \\\"{x:846,y:507,t:1528143944949};\\\", \\\"{x:845,y:507,t:1528143944966};\\\", \\\"{x:843,y:507,t:1528143944982};\\\", \\\"{x:843,y:507,t:1528143944999};\\\", \\\"{x:840,y:508,t:1528143945015};\\\", \\\"{x:839,y:508,t:1528143945036};\\\", \\\"{x:838,y:508,t:1528143945077};\\\", \\\"{x:836,y:509,t:1528143945084};\\\", \\\"{x:834,y:509,t:1528143945099};\\\", \\\"{x:811,y:509,t:1528143945116};\\\", \\\"{x:789,y:513,t:1528143945132};\\\", \\\"{x:753,y:518,t:1528143945149};\\\", \\\"{x:722,y:523,t:1528143945166};\\\", \\\"{x:699,y:530,t:1528143945182};\\\", \\\"{x:687,y:533,t:1528143945199};\\\", \\\"{x:681,y:534,t:1528143945215};\\\", \\\"{x:679,y:534,t:1528143945231};\\\", \\\"{x:678,y:534,t:1528143945248};\\\", \\\"{x:677,y:534,t:1528143945292};\\\", \\\"{x:678,y:533,t:1528143945307};\\\", \\\"{x:682,y:528,t:1528143945315};\\\", \\\"{x:706,y:518,t:1528143945333};\\\", \\\"{x:772,y:502,t:1528143945349};\\\", \\\"{x:846,y:486,t:1528143945366};\\\", \\\"{x:855,y:483,t:1528143945381};\\\", \\\"{x:856,y:482,t:1528143945399};\\\", \\\"{x:857,y:482,t:1528143945525};\\\", \\\"{x:858,y:482,t:1528143945532};\\\", \\\"{x:858,y:483,t:1528143945588};\\\", \\\"{x:858,y:485,t:1528143945599};\\\", \\\"{x:855,y:490,t:1528143945617};\\\", \\\"{x:852,y:493,t:1528143945633};\\\", \\\"{x:849,y:496,t:1528143945648};\\\", \\\"{x:848,y:496,t:1528143945666};\\\", \\\"{x:846,y:497,t:1528143945682};\\\", \\\"{x:844,y:498,t:1528143945698};\\\", \\\"{x:842,y:498,t:1528143945723};\\\", \\\"{x:840,y:499,t:1528143945740};\\\", \\\"{x:838,y:499,t:1528143945900};\\\", \\\"{x:817,y:501,t:1528143945915};\\\", \\\"{x:795,y:504,t:1528143945932};\\\", \\\"{x:764,y:508,t:1528143945950};\\\", \\\"{x:730,y:514,t:1528143945965};\\\", \\\"{x:708,y:518,t:1528143945983};\\\", \\\"{x:694,y:519,t:1528143945999};\\\", \\\"{x:686,y:520,t:1528143946016};\\\", \\\"{x:683,y:521,t:1528143946033};\\\", \\\"{x:680,y:521,t:1528143946050};\\\", \\\"{x:679,y:521,t:1528143946065};\\\", \\\"{x:677,y:522,t:1528143946083};\\\", \\\"{x:675,y:521,t:1528143946172};\\\", \\\"{x:674,y:519,t:1528143946183};\\\", \\\"{x:672,y:514,t:1528143946202};\\\", \\\"{x:671,y:510,t:1528143946217};\\\", \\\"{x:670,y:509,t:1528143946244};\\\", \\\"{x:668,y:508,t:1528143946268};\\\", \\\"{x:666,y:508,t:1528143946283};\\\", \\\"{x:658,y:507,t:1528143946299};\\\", \\\"{x:639,y:507,t:1528143946317};\\\", \\\"{x:629,y:507,t:1528143946333};\\\", \\\"{x:626,y:507,t:1528143946349};\\\", \\\"{x:625,y:507,t:1528143946366};\\\", \\\"{x:624,y:507,t:1528143946382};\\\", \\\"{x:623,y:507,t:1528143946399};\\\", \\\"{x:621,y:507,t:1528143946416};\\\", \\\"{x:619,y:508,t:1528143946433};\\\", \\\"{x:630,y:511,t:1528143946644};\\\", \\\"{x:658,y:512,t:1528143946652};\\\", \\\"{x:681,y:512,t:1528143946667};\\\", \\\"{x:734,y:512,t:1528143946683};\\\", \\\"{x:837,y:512,t:1528143946700};\\\", \\\"{x:923,y:512,t:1528143946717};\\\", \\\"{x:1001,y:512,t:1528143946734};\\\", \\\"{x:1081,y:512,t:1528143946750};\\\", \\\"{x:1170,y:514,t:1528143946767};\\\", \\\"{x:1256,y:523,t:1528143946784};\\\", \\\"{x:1337,y:534,t:1528143946800};\\\", \\\"{x:1402,y:550,t:1528143946817};\\\", \\\"{x:1487,y:569,t:1528143946834};\\\", \\\"{x:1565,y:578,t:1528143946850};\\\", \\\"{x:1578,y:583,t:1528143946867};\\\", \\\"{x:1587,y:584,t:1528143946883};\\\", \\\"{x:1589,y:586,t:1528143946900};\\\", \\\"{x:1589,y:588,t:1528143946965};\\\", \\\"{x:1591,y:588,t:1528143946972};\\\", \\\"{x:1591,y:590,t:1528143946984};\\\", \\\"{x:1591,y:591,t:1528143947004};\\\", \\\"{x:1591,y:592,t:1528143947017};\\\", \\\"{x:1591,y:594,t:1528143947034};\\\", \\\"{x:1590,y:595,t:1528143947050};\\\", \\\"{x:1590,y:596,t:1528143947068};\\\", \\\"{x:1590,y:598,t:1528143947109};\\\", \\\"{x:1587,y:602,t:1528143947117};\\\", \\\"{x:1586,y:608,t:1528143947134};\\\", \\\"{x:1583,y:620,t:1528143947152};\\\", \\\"{x:1583,y:625,t:1528143947167};\\\", \\\"{x:1581,y:628,t:1528143947184};\\\", \\\"{x:1581,y:629,t:1528143947201};\\\", \\\"{x:1580,y:632,t:1528143947217};\\\", \\\"{x:1580,y:634,t:1528143947234};\\\", \\\"{x:1580,y:637,t:1528143947253};\\\", \\\"{x:1580,y:642,t:1528143947267};\\\", \\\"{x:1580,y:649,t:1528143947284};\\\", \\\"{x:1583,y:656,t:1528143947301};\\\", \\\"{x:1594,y:666,t:1528143947318};\\\", \\\"{x:1606,y:674,t:1528143947334};\\\", \\\"{x:1612,y:678,t:1528143947352};\\\", \\\"{x:1613,y:680,t:1528143947367};\\\", \\\"{x:1615,y:682,t:1528143947384};\\\", \\\"{x:1615,y:684,t:1528143947400};\\\", \\\"{x:1615,y:685,t:1528143947417};\\\", \\\"{x:1615,y:686,t:1528143947434};\\\", \\\"{x:1615,y:687,t:1528143947460};\\\", \\\"{x:1615,y:688,t:1528143947492};\\\", \\\"{x:1614,y:689,t:1528143947556};\\\", \\\"{x:1613,y:691,t:1528143947580};\\\", \\\"{x:1612,y:691,t:1528143947604};\\\", \\\"{x:1611,y:692,t:1528143947618};\\\", \\\"{x:1611,y:694,t:1528143947651};\\\", \\\"{x:1609,y:694,t:1528143947668};\\\", \\\"{x:1609,y:695,t:1528143948245};\\\", \\\"{x:1609,y:696,t:1528143948252};\\\", \\\"{x:1608,y:696,t:1528143948293};\\\", \\\"{x:1608,y:697,t:1528143948302};\\\", \\\"{x:1607,y:698,t:1528143948318};\\\", \\\"{x:1606,y:699,t:1528143948335};\\\", \\\"{x:1605,y:701,t:1528143948351};\\\", \\\"{x:1604,y:702,t:1528143948436};\\\", \\\"{x:1603,y:703,t:1528143948452};\\\", \\\"{x:1602,y:705,t:1528143948468};\\\", \\\"{x:1600,y:707,t:1528143948485};\\\", \\\"{x:1598,y:710,t:1528143948502};\\\", \\\"{x:1597,y:712,t:1528143948518};\\\", \\\"{x:1596,y:714,t:1528143948535};\\\", \\\"{x:1595,y:716,t:1528143948552};\\\", \\\"{x:1593,y:718,t:1528143948568};\\\", \\\"{x:1592,y:721,t:1528143948586};\\\", \\\"{x:1591,y:723,t:1528143948603};\\\", \\\"{x:1589,y:726,t:1528143948618};\\\", \\\"{x:1588,y:729,t:1528143948635};\\\", \\\"{x:1585,y:732,t:1528143948652};\\\", \\\"{x:1585,y:733,t:1528143948668};\\\", \\\"{x:1584,y:734,t:1528143948686};\\\", \\\"{x:1584,y:737,t:1528143948702};\\\", \\\"{x:1583,y:737,t:1528143948719};\\\", \\\"{x:1582,y:739,t:1528143948736};\\\", \\\"{x:1582,y:740,t:1528143948753};\\\", \\\"{x:1582,y:742,t:1528143948770};\\\", \\\"{x:1580,y:745,t:1528143948786};\\\", \\\"{x:1579,y:746,t:1528143948802};\\\", \\\"{x:1578,y:749,t:1528143948820};\\\", \\\"{x:1576,y:753,t:1528143948836};\\\", \\\"{x:1575,y:756,t:1528143948853};\\\", \\\"{x:1574,y:758,t:1528143948869};\\\", \\\"{x:1572,y:762,t:1528143948886};\\\", \\\"{x:1572,y:764,t:1528143948902};\\\", \\\"{x:1571,y:766,t:1528143948919};\\\", \\\"{x:1569,y:769,t:1528143948935};\\\", \\\"{x:1569,y:770,t:1528143948952};\\\", \\\"{x:1568,y:774,t:1528143948970};\\\", \\\"{x:1566,y:779,t:1528143948986};\\\", \\\"{x:1564,y:784,t:1528143949003};\\\", \\\"{x:1562,y:787,t:1528143949020};\\\", \\\"{x:1562,y:789,t:1528143949036};\\\", \\\"{x:1559,y:795,t:1528143949053};\\\", \\\"{x:1557,y:800,t:1528143949069};\\\", \\\"{x:1554,y:807,t:1528143949085};\\\", \\\"{x:1550,y:815,t:1528143949102};\\\", \\\"{x:1545,y:825,t:1528143949120};\\\", \\\"{x:1541,y:835,t:1528143949136};\\\", \\\"{x:1536,y:845,t:1528143949152};\\\", \\\"{x:1532,y:856,t:1528143949169};\\\", \\\"{x:1528,y:867,t:1528143949187};\\\", \\\"{x:1524,y:875,t:1528143949203};\\\", \\\"{x:1521,y:882,t:1528143949220};\\\", \\\"{x:1517,y:892,t:1528143949236};\\\", \\\"{x:1516,y:897,t:1528143949253};\\\", \\\"{x:1514,y:904,t:1528143949269};\\\", \\\"{x:1511,y:908,t:1528143949286};\\\", \\\"{x:1509,y:914,t:1528143949303};\\\", \\\"{x:1508,y:917,t:1528143949319};\\\", \\\"{x:1505,y:922,t:1528143949337};\\\", \\\"{x:1503,y:930,t:1528143949352};\\\", \\\"{x:1501,y:933,t:1528143949369};\\\", \\\"{x:1497,y:938,t:1528143949386};\\\", \\\"{x:1496,y:941,t:1528143949403};\\\", \\\"{x:1492,y:947,t:1528143949419};\\\", \\\"{x:1487,y:952,t:1528143949437};\\\", \\\"{x:1485,y:953,t:1528143949453};\\\", \\\"{x:1482,y:955,t:1528143949470};\\\", \\\"{x:1481,y:958,t:1528143949487};\\\", \\\"{x:1480,y:959,t:1528143949503};\\\", \\\"{x:1479,y:960,t:1528143949519};\\\", \\\"{x:1479,y:961,t:1528143949537};\\\", \\\"{x:1478,y:962,t:1528143949553};\\\", \\\"{x:1477,y:964,t:1528143949605};\\\", \\\"{x:1477,y:965,t:1528143949773};\\\", \\\"{x:1459,y:959,t:1528143951717};\\\", \\\"{x:1409,y:945,t:1528143951724};\\\", \\\"{x:1391,y:938,t:1528143951738};\\\", \\\"{x:1373,y:936,t:1528143951755};\\\", \\\"{x:1360,y:932,t:1528143951772};\\\", \\\"{x:1315,y:916,t:1528143951788};\\\", \\\"{x:1225,y:883,t:1528143951805};\\\", \\\"{x:1026,y:825,t:1528143951821};\\\", \\\"{x:826,y:793,t:1528143951839};\\\", \\\"{x:665,y:762,t:1528143951854};\\\", \\\"{x:546,y:728,t:1528143951873};\\\", \\\"{x:465,y:702,t:1528143951889};\\\", \\\"{x:391,y:671,t:1528143951921};\\\", \\\"{x:388,y:669,t:1528143951936};\\\", \\\"{x:386,y:668,t:1528143951952};\\\", \\\"{x:385,y:668,t:1528143951970};\\\", \\\"{x:383,y:667,t:1528143951986};\\\", \\\"{x:382,y:667,t:1528143952004};\\\", \\\"{x:381,y:667,t:1528143952021};\\\", \\\"{x:384,y:664,t:1528143952037};\\\", \\\"{x:391,y:659,t:1528143952054};\\\", \\\"{x:392,y:659,t:1528143952071};\\\", \\\"{x:394,y:659,t:1528143952088};\\\", \\\"{x:400,y:657,t:1528143952104};\\\", \\\"{x:406,y:656,t:1528143952121};\\\", \\\"{x:414,y:659,t:1528143952138};\\\", \\\"{x:426,y:669,t:1528143952154};\\\", \\\"{x:442,y:681,t:1528143952171};\\\", \\\"{x:462,y:695,t:1528143952187};\\\", \\\"{x:478,y:701,t:1528143952204};\\\", \\\"{x:493,y:707,t:1528143952221};\\\", \\\"{x:500,y:710,t:1528143952238};\\\", \\\"{x:502,y:711,t:1528143952254};\\\", \\\"{x:503,y:712,t:1528143952271};\\\", \\\"{x:503,y:713,t:1528143952412};\\\", \\\"{x:503,y:716,t:1528143952421};\\\", \\\"{x:503,y:723,t:1528143952439};\\\", \\\"{x:502,y:732,t:1528143952455};\\\", \\\"{x:502,y:737,t:1528143952471};\\\", \\\"{x:502,y:739,t:1528143952488};\\\", \\\"{x:507,y:724,t:1528143952884};\\\", \\\"{x:518,y:701,t:1528143952891};\\\", \\\"{x:528,y:682,t:1528143952905};\\\", \\\"{x:545,y:639,t:1528143952922};\\\", \\\"{x:554,y:611,t:1528143952938};\\\", \\\"{x:557,y:597,t:1528143952955};\\\", \\\"{x:557,y:575,t:1528143952972};\\\", \\\"{x:557,y:574,t:1528143952988};\\\", \\\"{x:557,y:572,t:1528143953005};\\\", \\\"{x:558,y:570,t:1528143953420};\\\", \\\"{x:562,y:566,t:1528143953427};\\\", \\\"{x:567,y:559,t:1528143953440};\\\", \\\"{x:571,y:554,t:1528143953456};\\\", \\\"{x:574,y:551,t:1528143953472};\\\", \\\"{x:576,y:548,t:1528143953489};\\\", \\\"{x:578,y:545,t:1528143953505};\\\", \\\"{x:582,y:541,t:1528143953522};\\\", \\\"{x:588,y:534,t:1528143953540};\\\", \\\"{x:591,y:532,t:1528143953555};\\\", \\\"{x:597,y:526,t:1528143953572};\\\", \\\"{x:599,y:525,t:1528143953589};\\\", \\\"{x:602,y:524,t:1528143953605};\\\", \\\"{x:605,y:521,t:1528143953622};\\\", \\\"{x:608,y:519,t:1528143953639};\\\", \\\"{x:609,y:518,t:1528143953656};\\\", \\\"{x:610,y:517,t:1528143953673};\\\", \\\"{x:611,y:516,t:1528143953690};\\\", \\\"{x:613,y:513,t:1528143953706};\\\", \\\"{x:620,y:507,t:1528143953737};\\\", \\\"{x:622,y:505,t:1528143953739};\\\", \\\"{x:623,y:504,t:1528143953755};\\\", \\\"{x:624,y:504,t:1528143953787};\\\", \\\"{x:624,y:503,t:1528143953803};\\\" ] }, { \\\"rt\\\": 8411, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 18, \\\"time_elapsed\\\": 877935, \\\"internal_node_id\\\": \\\"0.0-6.0-8.0\\\", \\\"subject\\\": \\\"MKTF4\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"zulu\\\", \\\"condition\\\": \\\"211\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"endtime\\\", \\\"q\\\": 14, \\\"clicks\\\": 1, \\\"explicit\\\": 2, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XInside-YFull\\\", \\\"correct\\\": 1, \\\"orth_correct\\\": 0, \\\"answer\\\": [ \\\"X\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-03 PM-02 PM-03 PM-04 PM-03 PM\\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:624,y:502,t:1528143954092};\\\", \\\"{x:625,y:502,t:1528143954112};\\\", \\\"{x:627,y:502,t:1528143954244};\\\", \\\"{x:631,y:496,t:1528143954256};\\\", \\\"{x:634,y:481,t:1528143954273};\\\", \\\"{x:636,y:469,t:1528143954291};\\\", \\\"{x:640,y:453,t:1528143954306};\\\", \\\"{x:642,y:391,t:1528143954391};\\\", \\\"{x:642,y:390,t:1528143954408};\\\", \\\"{x:642,y:389,t:1528143954423};\\\", \\\"{x:649,y:389,t:1528143954804};\\\", \\\"{x:667,y:392,t:1528143954812};\\\", \\\"{x:684,y:393,t:1528143954823};\\\", \\\"{x:727,y:400,t:1528143954839};\\\", \\\"{x:776,y:411,t:1528143954856};\\\", \\\"{x:828,y:424,t:1528143954873};\\\", \\\"{x:891,y:450,t:1528143954890};\\\", \\\"{x:949,y:476,t:1528143954906};\\\", \\\"{x:999,y:498,t:1528143954923};\\\", \\\"{x:1035,y:512,t:1528143954939};\\\", \\\"{x:1066,y:523,t:1528143954957};\\\", \\\"{x:1068,y:526,t:1528143954974};\\\", \\\"{x:1069,y:527,t:1528143954989};\\\", \\\"{x:1072,y:529,t:1528143955237};\\\", \\\"{x:1075,y:529,t:1528143955245};\\\", \\\"{x:1076,y:529,t:1528143955261};\\\", \\\"{x:1077,y:529,t:1528143955276};\\\", \\\"{x:1079,y:530,t:1528143955290};\\\", \\\"{x:1106,y:574,t:1528143955307};\\\", \\\"{x:1145,y:635,t:1528143955323};\\\", \\\"{x:1191,y:698,t:1528143955340};\\\", \\\"{x:1216,y:726,t:1528143955357};\\\", \\\"{x:1235,y:747,t:1528143955374};\\\", \\\"{x:1244,y:763,t:1528143955392};\\\", \\\"{x:1257,y:782,t:1528143955407};\\\", \\\"{x:1277,y:801,t:1528143955424};\\\", \\\"{x:1291,y:815,t:1528143955441};\\\", \\\"{x:1305,y:830,t:1528143955457};\\\", \\\"{x:1318,y:850,t:1528143955474};\\\", \\\"{x:1333,y:871,t:1528143955491};\\\", \\\"{x:1345,y:886,t:1528143955507};\\\", \\\"{x:1349,y:890,t:1528143955524};\\\", \\\"{x:1349,y:891,t:1528143955629};\\\", \\\"{x:1351,y:891,t:1528143955644};\\\", \\\"{x:1353,y:892,t:1528143955657};\\\", \\\"{x:1356,y:892,t:1528143955674};\\\", \\\"{x:1363,y:893,t:1528143955691};\\\", \\\"{x:1366,y:895,t:1528143955707};\\\", \\\"{x:1371,y:899,t:1528143955724};\\\", \\\"{x:1376,y:902,t:1528143955740};\\\", \\\"{x:1383,y:904,t:1528143955758};\\\", \\\"{x:1396,y:908,t:1528143955774};\\\", \\\"{x:1406,y:911,t:1528143955791};\\\", \\\"{x:1412,y:912,t:1528143955808};\\\", \\\"{x:1415,y:913,t:1528143955824};\\\", \\\"{x:1419,y:915,t:1528143955840};\\\", \\\"{x:1421,y:917,t:1528143955858};\\\", \\\"{x:1429,y:920,t:1528143955874};\\\", \\\"{x:1434,y:921,t:1528143955891};\\\", \\\"{x:1439,y:926,t:1528143955908};\\\", \\\"{x:1446,y:931,t:1528143955924};\\\", \\\"{x:1456,y:938,t:1528143955940};\\\", \\\"{x:1469,y:945,t:1528143955958};\\\", \\\"{x:1479,y:950,t:1528143955974};\\\", \\\"{x:1487,y:952,t:1528143955990};\\\", \\\"{x:1492,y:955,t:1528143956008};\\\", \\\"{x:1496,y:956,t:1528143956024};\\\", \\\"{x:1502,y:959,t:1528143956040};\\\", \\\"{x:1510,y:963,t:1528143956058};\\\", \\\"{x:1515,y:965,t:1528143956074};\\\", \\\"{x:1519,y:967,t:1528143956092};\\\", \\\"{x:1522,y:967,t:1528143956107};\\\", \\\"{x:1525,y:968,t:1528143956124};\\\", \\\"{x:1530,y:970,t:1528143956141};\\\", \\\"{x:1534,y:970,t:1528143956157};\\\", \\\"{x:1537,y:971,t:1528143956174};\\\", \\\"{x:1538,y:971,t:1528143956191};\\\", \\\"{x:1539,y:972,t:1528143956208};\\\", \\\"{x:1540,y:972,t:1528143956224};\\\", \\\"{x:1541,y:972,t:1528143956241};\\\", \\\"{x:1542,y:972,t:1528143956283};\\\", \\\"{x:1543,y:972,t:1528143956324};\\\", \\\"{x:1544,y:972,t:1528143956347};\\\", \\\"{x:1545,y:972,t:1528143956357};\\\", \\\"{x:1548,y:972,t:1528143956374};\\\", \\\"{x:1550,y:972,t:1528143956391};\\\", \\\"{x:1554,y:972,t:1528143956407};\\\", \\\"{x:1556,y:971,t:1528143956423};\\\", \\\"{x:1558,y:971,t:1528143956441};\\\", \\\"{x:1559,y:971,t:1528143956457};\\\", \\\"{x:1560,y:971,t:1528143956473};\\\", \\\"{x:1561,y:971,t:1528143956885};\\\", \\\"{x:1560,y:970,t:1528143957205};\\\", \\\"{x:1541,y:954,t:1528143957216};\\\", \\\"{x:1496,y:922,t:1528143957224};\\\", \\\"{x:1378,y:849,t:1528143957241};\\\", \\\"{x:1248,y:784,t:1528143957258};\\\", \\\"{x:1103,y:708,t:1528143957274};\\\", \\\"{x:946,y:612,t:1528143957292};\\\", \\\"{x:872,y:564,t:1528143957308};\\\", \\\"{x:819,y:528,t:1528143957325};\\\", \\\"{x:788,y:508,t:1528143957343};\\\", \\\"{x:773,y:499,t:1528143957359};\\\", \\\"{x:766,y:495,t:1528143957375};\\\", \\\"{x:765,y:495,t:1528143957392};\\\", \\\"{x:765,y:499,t:1528143957451};\\\", \\\"{x:765,y:513,t:1528143957459};\\\", \\\"{x:770,y:531,t:1528143957476};\\\", \\\"{x:779,y:546,t:1528143957492};\\\", \\\"{x:791,y:563,t:1528143957508};\\\", \\\"{x:803,y:578,t:1528143957525};\\\", \\\"{x:813,y:588,t:1528143957542};\\\", \\\"{x:828,y:595,t:1528143957558};\\\", \\\"{x:842,y:604,t:1528143957575};\\\", \\\"{x:859,y:608,t:1528143957592};\\\", \\\"{x:870,y:610,t:1528143957608};\\\", \\\"{x:874,y:610,t:1528143957625};\\\", \\\"{x:875,y:610,t:1528143957642};\\\", \\\"{x:867,y:610,t:1528143957700};\\\", \\\"{x:849,y:610,t:1528143957709};\\\", \\\"{x:794,y:613,t:1528143957725};\\\", \\\"{x:727,y:623,t:1528143957742};\\\", \\\"{x:647,y:634,t:1528143957760};\\\", \\\"{x:577,y:643,t:1528143957775};\\\", \\\"{x:541,y:649,t:1528143957792};\\\", \\\"{x:520,y:653,t:1528143957809};\\\", \\\"{x:504,y:656,t:1528143957825};\\\", \\\"{x:488,y:659,t:1528143957843};\\\", \\\"{x:453,y:660,t:1528143957859};\\\", \\\"{x:443,y:660,t:1528143957875};\\\", \\\"{x:426,y:660,t:1528143957893};\\\", \\\"{x:423,y:660,t:1528143957909};\\\", \\\"{x:421,y:660,t:1528143957925};\\\", \\\"{x:419,y:660,t:1528143957942};\\\", \\\"{x:415,y:658,t:1528143957960};\\\", \\\"{x:411,y:657,t:1528143957976};\\\", \\\"{x:403,y:652,t:1528143957992};\\\", \\\"{x:397,y:647,t:1528143958009};\\\", \\\"{x:386,y:637,t:1528143958026};\\\", \\\"{x:380,y:631,t:1528143958043};\\\", \\\"{x:378,y:626,t:1528143958059};\\\", \\\"{x:377,y:617,t:1528143958075};\\\", \\\"{x:377,y:606,t:1528143958092};\\\", \\\"{x:377,y:597,t:1528143958110};\\\", \\\"{x:379,y:589,t:1528143958126};\\\", \\\"{x:379,y:586,t:1528143958142};\\\", \\\"{x:381,y:582,t:1528143958159};\\\", \\\"{x:382,y:580,t:1528143958175};\\\", \\\"{x:384,y:578,t:1528143958192};\\\", \\\"{x:386,y:575,t:1528143958210};\\\", \\\"{x:388,y:572,t:1528143958226};\\\", \\\"{x:395,y:568,t:1528143958242};\\\", \\\"{x:397,y:567,t:1528143958259};\\\", \\\"{x:395,y:567,t:1528143958316};\\\", \\\"{x:388,y:569,t:1528143958327};\\\", \\\"{x:367,y:577,t:1528143958343};\\\", \\\"{x:343,y:587,t:1528143958359};\\\", \\\"{x:321,y:590,t:1528143958376};\\\", \\\"{x:307,y:593,t:1528143958392};\\\", \\\"{x:301,y:593,t:1528143958410};\\\", \\\"{x:295,y:597,t:1528143958427};\\\", \\\"{x:279,y:603,t:1528143958444};\\\", \\\"{x:275,y:606,t:1528143958460};\\\", \\\"{x:272,y:607,t:1528143958477};\\\", \\\"{x:272,y:608,t:1528143958494};\\\", \\\"{x:272,y:609,t:1528143958509};\\\", \\\"{x:299,y:612,t:1528143958529};\\\", \\\"{x:347,y:612,t:1528143958543};\\\", \\\"{x:405,y:612,t:1528143958559};\\\", \\\"{x:453,y:612,t:1528143958576};\\\", \\\"{x:481,y:612,t:1528143958593};\\\", \\\"{x:494,y:612,t:1528143958609};\\\", \\\"{x:501,y:611,t:1528143958626};\\\", \\\"{x:513,y:606,t:1528143958643};\\\", \\\"{x:525,y:601,t:1528143958659};\\\", \\\"{x:532,y:598,t:1528143958677};\\\", \\\"{x:536,y:596,t:1528143958694};\\\", \\\"{x:537,y:596,t:1528143958709};\\\", \\\"{x:538,y:595,t:1528143958726};\\\", \\\"{x:539,y:595,t:1528143958747};\\\", \\\"{x:541,y:594,t:1528143958759};\\\", \\\"{x:544,y:592,t:1528143958777};\\\", \\\"{x:546,y:591,t:1528143958794};\\\", \\\"{x:551,y:589,t:1528143958809};\\\", \\\"{x:556,y:588,t:1528143958826};\\\", \\\"{x:569,y:587,t:1528143958844};\\\", \\\"{x:577,y:587,t:1528143958859};\\\", \\\"{x:585,y:587,t:1528143958876};\\\", \\\"{x:595,y:587,t:1528143958894};\\\", \\\"{x:602,y:587,t:1528143958911};\\\", \\\"{x:610,y:587,t:1528143958926};\\\", \\\"{x:614,y:587,t:1528143958943};\\\", \\\"{x:617,y:587,t:1528143958960};\\\", \\\"{x:627,y:588,t:1528143959332};\\\", \\\"{x:648,y:598,t:1528143959344};\\\", \\\"{x:716,y:621,t:1528143959361};\\\", \\\"{x:813,y:646,t:1528143959377};\\\", \\\"{x:921,y:677,t:1528143959393};\\\", \\\"{x:1037,y:712,t:1528143959411};\\\", \\\"{x:1228,y:787,t:1528143959428};\\\", \\\"{x:1351,y:836,t:1528143959444};\\\", \\\"{x:1475,y:887,t:1528143959461};\\\", \\\"{x:1569,y:929,t:1528143959478};\\\", \\\"{x:1627,y:955,t:1528143959494};\\\", \\\"{x:1640,y:966,t:1528143959511};\\\", \\\"{x:1642,y:971,t:1528143959528};\\\", \\\"{x:1643,y:975,t:1528143959544};\\\", \\\"{x:1643,y:979,t:1528143959561};\\\", \\\"{x:1643,y:986,t:1528143959578};\\\", \\\"{x:1645,y:990,t:1528143959594};\\\", \\\"{x:1645,y:991,t:1528143959611};\\\", \\\"{x:1644,y:996,t:1528143959628};\\\", \\\"{x:1643,y:998,t:1528143959644};\\\", \\\"{x:1630,y:1004,t:1528143959661};\\\", \\\"{x:1610,y:1007,t:1528143959678};\\\", \\\"{x:1587,y:1008,t:1528143959694};\\\", \\\"{x:1565,y:1008,t:1528143959711};\\\", \\\"{x:1546,y:1006,t:1528143959728};\\\", \\\"{x:1530,y:1001,t:1528143959744};\\\", \\\"{x:1517,y:995,t:1528143959761};\\\", \\\"{x:1506,y:988,t:1528143959778};\\\", \\\"{x:1496,y:980,t:1528143959794};\\\", \\\"{x:1489,y:973,t:1528143959810};\\\", \\\"{x:1481,y:969,t:1528143959828};\\\", \\\"{x:1480,y:969,t:1528143959845};\\\", \\\"{x:1479,y:969,t:1528143959868};\\\", \\\"{x:1486,y:969,t:1528143959941};\\\", \\\"{x:1500,y:969,t:1528143959948};\\\", \\\"{x:1514,y:969,t:1528143959961};\\\", \\\"{x:1537,y:969,t:1528143959978};\\\", \\\"{x:1561,y:969,t:1528143959995};\\\", \\\"{x:1578,y:969,t:1528143960011};\\\", \\\"{x:1590,y:969,t:1528143960027};\\\", \\\"{x:1595,y:969,t:1528143960044};\\\", \\\"{x:1596,y:969,t:1528143960060};\\\", \\\"{x:1597,y:969,t:1528143960077};\\\", \\\"{x:1594,y:970,t:1528143960181};\\\", \\\"{x:1591,y:971,t:1528143960195};\\\", \\\"{x:1584,y:973,t:1528143960211};\\\", \\\"{x:1574,y:975,t:1528143960228};\\\", \\\"{x:1567,y:975,t:1528143960245};\\\", \\\"{x:1560,y:975,t:1528143960262};\\\", \\\"{x:1555,y:975,t:1528143960278};\\\", \\\"{x:1553,y:975,t:1528143960295};\\\", \\\"{x:1552,y:974,t:1528143960312};\\\", \\\"{x:1551,y:974,t:1528143960328};\\\", \\\"{x:1550,y:974,t:1528143960345};\\\", \\\"{x:1548,y:972,t:1528143961517};\\\", \\\"{x:1532,y:965,t:1528143961529};\\\", \\\"{x:1487,y:953,t:1528143961546};\\\", \\\"{x:1425,y:933,t:1528143961563};\\\", \\\"{x:1328,y:905,t:1528143961579};\\\", \\\"{x:1168,y:843,t:1528143961596};\\\", \\\"{x:1091,y:813,t:1528143961612};\\\", \\\"{x:1002,y:784,t:1528143961629};\\\", \\\"{x:944,y:768,t:1528143961647};\\\", \\\"{x:913,y:764,t:1528143961663};\\\", \\\"{x:891,y:762,t:1528143961678};\\\", \\\"{x:879,y:762,t:1528143961696};\\\", \\\"{x:872,y:763,t:1528143961713};\\\", \\\"{x:867,y:766,t:1528143961728};\\\", \\\"{x:860,y:767,t:1528143961746};\\\", \\\"{x:851,y:772,t:1528143961763};\\\", \\\"{x:842,y:776,t:1528143961779};\\\", \\\"{x:825,y:783,t:1528143961796};\\\", \\\"{x:821,y:786,t:1528143961813};\\\", \\\"{x:820,y:786,t:1528143961830};\\\", \\\"{x:818,y:787,t:1528143961846};\\\", \\\"{x:814,y:789,t:1528143961863};\\\", \\\"{x:805,y:793,t:1528143961880};\\\", \\\"{x:791,y:797,t:1528143961896};\\\", \\\"{x:778,y:800,t:1528143961913};\\\", \\\"{x:762,y:802,t:1528143961930};\\\", \\\"{x:747,y:802,t:1528143961946};\\\", \\\"{x:725,y:801,t:1528143961962};\\\", \\\"{x:682,y:790,t:1528143961979};\\\", \\\"{x:663,y:784,t:1528143961995};\\\", \\\"{x:650,y:780,t:1528143962013};\\\", \\\"{x:639,y:778,t:1528143962030};\\\", \\\"{x:627,y:773,t:1528143962045};\\\", \\\"{x:608,y:764,t:1528143962063};\\\", \\\"{x:591,y:758,t:1528143962079};\\\", \\\"{x:574,y:749,t:1528143962096};\\\", \\\"{x:565,y:745,t:1528143962112};\\\", \\\"{x:557,y:740,t:1528143962130};\\\", \\\"{x:556,y:739,t:1528143962145};\\\", \\\"{x:554,y:739,t:1528143962162};\\\", \\\"{x:552,y:739,t:1528143962195};\\\", \\\"{x:550,y:739,t:1528143962212};\\\", \\\"{x:549,y:739,t:1528143962331};\\\", \\\"{x:549,y:739,t:1528143962410};\\\", \\\"{x:549,y:736,t:1528143962539};\\\", \\\"{x:549,y:725,t:1528143962548};\\\", \\\"{x:555,y:718,t:1528143962562};\\\", \\\"{x:598,y:660,t:1528143962580};\\\", \\\"{x:639,y:604,t:1528143962596};\\\", \\\"{x:660,y:562,t:1528143962613};\\\", \\\"{x:675,y:496,t:1528143962629};\\\", \\\"{x:690,y:441,t:1528143962646};\\\", \\\"{x:696,y:401,t:1528143962663};\\\", \\\"{x:701,y:367,t:1528143962680};\\\", \\\"{x:708,y:337,t:1528143962697};\\\", \\\"{x:713,y:322,t:1528143962712};\\\", \\\"{x:717,y:307,t:1528143962730};\\\", \\\"{x:720,y:297,t:1528143962746};\\\", \\\"{x:720,y:293,t:1528143962763};\\\", \\\"{x:721,y:293,t:1528143963285};\\\", \\\"{x:724,y:293,t:1528143963300};\\\", \\\"{x:725,y:293,t:1528143963314};\\\", \\\"{x:729,y:291,t:1528143963330};\\\", \\\"{x:730,y:291,t:1528143963452};\\\" ] }, { \\\"rt\\\": 272069, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 19, \\\"time_elapsed\\\": 1151294, \\\"internal_node_id\\\": \\\"0.0-6.0-9.0\\\", \\\"subject\\\": \\\"MKTF4\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"zulu\\\", \\\"condition\\\": \\\"211\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"midpoint\\\", \\\"q\\\": 15, \\\"clicks\\\": 3.5, \\\"explicit\\\": 2, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XInside-YFull\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 0, \\\"answer\\\": [ \\\"G\\\", \\\"K\\\", \\\"X\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-03 PM-04 PM-03 PM-02 PM-03 PM-02 PM-12 PM-09 AM\\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:731,y:290,t:1528143966316};\\\", \\\"{x:731,y:282,t:1528143966332};\\\", \\\"{x:731,y:277,t:1528143966349};\\\", \\\"{x:731,y:276,t:1528143966366};\\\", \\\"{x:731,y:274,t:1528143966383};\\\", \\\"{x:731,y:273,t:1528143966399};\\\", \\\"{x:731,y:272,t:1528143966464};\\\", \\\"{x:731,y:271,t:1528143966483};\\\", \\\"{x:731,y:270,t:1528143966515};\\\", \\\"{x:732,y:269,t:1528143966627};\\\", \\\"{x:732,y:268,t:1528143966676};\\\", \\\"{x:732,y:267,t:1528143966852};\\\", \\\"{x:734,y:267,t:1528143966901};\\\", \\\"{x:778,y:308,t:1528143966916};\\\", \\\"{x:828,y:355,t:1528143966933};\\\", \\\"{x:872,y:400,t:1528143966950};\\\", \\\"{x:940,y:455,t:1528143966966};\\\", \\\"{x:999,y:496,t:1528143966983};\\\", \\\"{x:1050,y:537,t:1528143967000};\\\", \\\"{x:1104,y:575,t:1528143967017};\\\", \\\"{x:1135,y:598,t:1528143967033};\\\", \\\"{x:1149,y:609,t:1528143967050};\\\", \\\"{x:1155,y:614,t:1528143967066};\\\", \\\"{x:1156,y:615,t:1528143967083};\\\", \\\"{x:1158,y:616,t:1528143967100};\\\", \\\"{x:1157,y:616,t:1528143967164};\\\", \\\"{x:1157,y:613,t:1528143967172};\\\", \\\"{x:1157,y:610,t:1528143967183};\\\", \\\"{x:1158,y:608,t:1528143967460};\\\", \\\"{x:1161,y:608,t:1528143967468};\\\", \\\"{x:1163,y:608,t:1528143967483};\\\", \\\"{x:1169,y:607,t:1528143967500};\\\", \\\"{x:1174,y:607,t:1528143967517};\\\", \\\"{x:1185,y:628,t:1528143967533};\\\", \\\"{x:1205,y:664,t:1528143967550};\\\", \\\"{x:1220,y:694,t:1528143967567};\\\", \\\"{x:1229,y:716,t:1528143967584};\\\", \\\"{x:1236,y:736,t:1528143967601};\\\", \\\"{x:1241,y:754,t:1528143967618};\\\", \\\"{x:1250,y:777,t:1528143967633};\\\", \\\"{x:1262,y:798,t:1528143967650};\\\", \\\"{x:1273,y:817,t:1528143967668};\\\", \\\"{x:1292,y:846,t:1528143967684};\\\", \\\"{x:1309,y:866,t:1528143967700};\\\", \\\"{x:1321,y:876,t:1528143967717};\\\", \\\"{x:1332,y:883,t:1528143967734};\\\", \\\"{x:1340,y:889,t:1528143967750};\\\", \\\"{x:1349,y:896,t:1528143967768};\\\", \\\"{x:1357,y:900,t:1528143967785};\\\", \\\"{x:1370,y:905,t:1528143967801};\\\", \\\"{x:1383,y:908,t:1528143967817};\\\", \\\"{x:1386,y:908,t:1528143967834};\\\", \\\"{x:1386,y:909,t:1528143967850};\\\", \\\"{x:1387,y:909,t:1528143967867};\\\", \\\"{x:1388,y:910,t:1528143967900};\\\", \\\"{x:1390,y:910,t:1528143968031};\\\", \\\"{x:1392,y:909,t:1528143968036};\\\", \\\"{x:1394,y:909,t:1528143968052};\\\", \\\"{x:1395,y:909,t:1528143968068};\\\", \\\"{x:1399,y:907,t:1528143968084};\\\", \\\"{x:1404,y:905,t:1528143968101};\\\", \\\"{x:1409,y:902,t:1528143968117};\\\", \\\"{x:1414,y:901,t:1528143968134};\\\", \\\"{x:1421,y:901,t:1528143968151};\\\", \\\"{x:1427,y:901,t:1528143968167};\\\", \\\"{x:1434,y:903,t:1528143968184};\\\", \\\"{x:1445,y:909,t:1528143968201};\\\", \\\"{x:1454,y:915,t:1528143968217};\\\", \\\"{x:1462,y:921,t:1528143968234};\\\", \\\"{x:1466,y:924,t:1528143968251};\\\", \\\"{x:1470,y:926,t:1528143968268};\\\", \\\"{x:1473,y:928,t:1528143968284};\\\", \\\"{x:1475,y:930,t:1528143968302};\\\", \\\"{x:1479,y:932,t:1528143968318};\\\", \\\"{x:1480,y:933,t:1528143968334};\\\", \\\"{x:1482,y:936,t:1528143968351};\\\", \\\"{x:1483,y:939,t:1528143968368};\\\", \\\"{x:1486,y:946,t:1528143968384};\\\", \\\"{x:1487,y:949,t:1528143968401};\\\", \\\"{x:1487,y:952,t:1528143968418};\\\", \\\"{x:1487,y:954,t:1528143968435};\\\", \\\"{x:1487,y:956,t:1528143968452};\\\", \\\"{x:1487,y:959,t:1528143968467};\\\", \\\"{x:1487,y:962,t:1528143968484};\\\", \\\"{x:1487,y:963,t:1528143968509};\\\", \\\"{x:1487,y:964,t:1528143968804};\\\", \\\"{x:1486,y:964,t:1528143968828};\\\", \\\"{x:1485,y:964,t:1528143969220};\\\", \\\"{x:1491,y:964,t:1528143973781};\\\", \\\"{x:1498,y:964,t:1528143973788};\\\", \\\"{x:1514,y:967,t:1528143973805};\\\", \\\"{x:1528,y:968,t:1528143973822};\\\", \\\"{x:1533,y:968,t:1528143973838};\\\", \\\"{x:1534,y:968,t:1528143973860};\\\", \\\"{x:1535,y:968,t:1528143973884};\\\", \\\"{x:1537,y:968,t:1528143973900};\\\", \\\"{x:1538,y:968,t:1528143973908};\\\", \\\"{x:1540,y:970,t:1528143973922};\\\", \\\"{x:1542,y:970,t:1528143973938};\\\", \\\"{x:1546,y:970,t:1528143973955};\\\", \\\"{x:1549,y:970,t:1528143973971};\\\", \\\"{x:1553,y:971,t:1528143973988};\\\", \\\"{x:1556,y:971,t:1528143974005};\\\", \\\"{x:1562,y:971,t:1528143974022};\\\", \\\"{x:1567,y:971,t:1528143974038};\\\", \\\"{x:1570,y:971,t:1528143974056};\\\", \\\"{x:1573,y:971,t:1528143974072};\\\", \\\"{x:1575,y:971,t:1528143974089};\\\", \\\"{x:1579,y:971,t:1528143974105};\\\", \\\"{x:1589,y:969,t:1528143974122};\\\", \\\"{x:1596,y:968,t:1528143974138};\\\", \\\"{x:1603,y:966,t:1528143974156};\\\", \\\"{x:1607,y:965,t:1528143974172};\\\", \\\"{x:1608,y:965,t:1528143974212};\\\", \\\"{x:1609,y:965,t:1528143974412};\\\", \\\"{x:1610,y:965,t:1528143974428};\\\", \\\"{x:1612,y:965,t:1528143974439};\\\", \\\"{x:1615,y:965,t:1528143974456};\\\", \\\"{x:1619,y:966,t:1528143974472};\\\", \\\"{x:1622,y:966,t:1528143974489};\\\", \\\"{x:1623,y:967,t:1528143974506};\\\", \\\"{x:1625,y:967,t:1528143974540};\\\", \\\"{x:1626,y:968,t:1528143974740};\\\", \\\"{x:1625,y:969,t:1528143974764};\\\", \\\"{x:1624,y:969,t:1528143974780};\\\", \\\"{x:1623,y:969,t:1528143974788};\\\", \\\"{x:1620,y:969,t:1528143974805};\\\", \\\"{x:1619,y:969,t:1528143974884};\\\", \\\"{x:1617,y:969,t:1528143974988};\\\", \\\"{x:1616,y:969,t:1528143975005};\\\", \\\"{x:1615,y:969,t:1528143975036};\\\", \\\"{x:1614,y:969,t:1528143975044};\\\", \\\"{x:1613,y:969,t:1528143975101};\\\", \\\"{x:1612,y:969,t:1528143975140};\\\", \\\"{x:1611,y:969,t:1528143986447};\\\", \\\"{x:1610,y:969,t:1528144129094};\\\", \\\"{x:1608,y:969,t:1528144129133};\\\", \\\"{x:1602,y:969,t:1528144129146};\\\", \\\"{x:1593,y:969,t:1528144129164};\\\", \\\"{x:1578,y:969,t:1528144129179};\\\", \\\"{x:1548,y:969,t:1528144129197};\\\", \\\"{x:1536,y:969,t:1528144129213};\\\", \\\"{x:1526,y:969,t:1528144129230};\\\", \\\"{x:1524,y:969,t:1528144129245};\\\", \\\"{x:1523,y:969,t:1528144129262};\\\", \\\"{x:1521,y:969,t:1528144129280};\\\", \\\"{x:1520,y:969,t:1528144129296};\\\", \\\"{x:1518,y:969,t:1528144129313};\\\", \\\"{x:1515,y:969,t:1528144129329};\\\", \\\"{x:1513,y:969,t:1528144129346};\\\", \\\"{x:1512,y:969,t:1528144129363};\\\", \\\"{x:1509,y:969,t:1528144129379};\\\", \\\"{x:1507,y:969,t:1528144129395};\\\", \\\"{x:1505,y:969,t:1528144129412};\\\", \\\"{x:1504,y:969,t:1528144129430};\\\", \\\"{x:1502,y:969,t:1528144129446};\\\", \\\"{x:1500,y:969,t:1528144129463};\\\", \\\"{x:1499,y:969,t:1528144129480};\\\", \\\"{x:1497,y:968,t:1528144129497};\\\", \\\"{x:1496,y:968,t:1528144129513};\\\", \\\"{x:1493,y:967,t:1528144129530};\\\", \\\"{x:1492,y:967,t:1528144129547};\\\", \\\"{x:1490,y:966,t:1528144129563};\\\", \\\"{x:1488,y:966,t:1528144129580};\\\", \\\"{x:1486,y:965,t:1528144129596};\\\", \\\"{x:1484,y:965,t:1528144129613};\\\", \\\"{x:1483,y:965,t:1528144129630};\\\", \\\"{x:1482,y:965,t:1528144129646};\\\", \\\"{x:1481,y:965,t:1528144129663};\\\", \\\"{x:1480,y:965,t:1528144129708};\\\", \\\"{x:1479,y:965,t:1528144129764};\\\", \\\"{x:1467,y:965,t:1528144148717};\\\", \\\"{x:1425,y:959,t:1528144148727};\\\", \\\"{x:1352,y:945,t:1528144148744};\\\", \\\"{x:1297,y:923,t:1528144148760};\\\", \\\"{x:1219,y:887,t:1528144148777};\\\", \\\"{x:1161,y:850,t:1528144148795};\\\", \\\"{x:1132,y:821,t:1528144148811};\\\", \\\"{x:1095,y:777,t:1528144148827};\\\", \\\"{x:1016,y:705,t:1528144148844};\\\", \\\"{x:973,y:674,t:1528144148861};\\\", \\\"{x:948,y:652,t:1528144148878};\\\", \\\"{x:936,y:644,t:1528144148895};\\\", \\\"{x:934,y:642,t:1528144148910};\\\", \\\"{x:933,y:641,t:1528144148927};\\\", \\\"{x:932,y:640,t:1528144148940};\\\", \\\"{x:931,y:640,t:1528144149003};\\\", \\\"{x:927,y:640,t:1528144149010};\\\", \\\"{x:923,y:640,t:1528144149023};\\\", \\\"{x:915,y:639,t:1528144149040};\\\", \\\"{x:909,y:639,t:1528144149056};\\\", \\\"{x:902,y:639,t:1528144149073};\\\", \\\"{x:893,y:642,t:1528144149091};\\\", \\\"{x:877,y:646,t:1528144149107};\\\", \\\"{x:836,y:646,t:1528144149123};\\\", \\\"{x:784,y:646,t:1528144149140};\\\", \\\"{x:749,y:646,t:1528144149157};\\\", \\\"{x:738,y:646,t:1528144149174};\\\", \\\"{x:733,y:646,t:1528144149191};\\\", \\\"{x:732,y:646,t:1528144149220};\\\", \\\"{x:731,y:646,t:1528144149227};\\\", \\\"{x:730,y:645,t:1528144149242};\\\", \\\"{x:725,y:642,t:1528144149258};\\\", \\\"{x:722,y:641,t:1528144149274};\\\", \\\"{x:721,y:640,t:1528144149290};\\\", \\\"{x:720,y:638,t:1528144149306};\\\", \\\"{x:717,y:636,t:1528144149323};\\\", \\\"{x:709,y:631,t:1528144149340};\\\", \\\"{x:701,y:625,t:1528144149357};\\\", \\\"{x:687,y:619,t:1528144149373};\\\", \\\"{x:670,y:614,t:1528144149391};\\\", \\\"{x:661,y:610,t:1528144149407};\\\", \\\"{x:656,y:609,t:1528144149423};\\\", \\\"{x:652,y:607,t:1528144149441};\\\", \\\"{x:648,y:605,t:1528144149457};\\\", \\\"{x:647,y:604,t:1528144149473};\\\", \\\"{x:645,y:603,t:1528144149490};\\\", \\\"{x:643,y:603,t:1528144149515};\\\", \\\"{x:642,y:603,t:1528144149538};\\\", \\\"{x:641,y:603,t:1528144149555};\\\", \\\"{x:639,y:602,t:1528144149563};\\\", \\\"{x:636,y:602,t:1528144149573};\\\", \\\"{x:632,y:600,t:1528144149590};\\\", \\\"{x:629,y:599,t:1528144149607};\\\", \\\"{x:627,y:598,t:1528144149623};\\\", \\\"{x:624,y:596,t:1528144149641};\\\", \\\"{x:623,y:596,t:1528144149658};\\\", \\\"{x:621,y:596,t:1528144149674};\\\", \\\"{x:618,y:594,t:1528144149691};\\\", \\\"{x:617,y:594,t:1528144149708};\\\", \\\"{x:622,y:592,t:1528144149883};\\\", \\\"{x:644,y:592,t:1528144149890};\\\", \\\"{x:726,y:597,t:1528144149908};\\\", \\\"{x:889,y:641,t:1528144149925};\\\", \\\"{x:1076,y:689,t:1528144149941};\\\", \\\"{x:1240,y:746,t:1528144149957};\\\", \\\"{x:1369,y:799,t:1528144149974};\\\", \\\"{x:1453,y:840,t:1528144149991};\\\", \\\"{x:1486,y:867,t:1528144150008};\\\", \\\"{x:1502,y:886,t:1528144150025};\\\", \\\"{x:1513,y:906,t:1528144150042};\\\", \\\"{x:1519,y:921,t:1528144150057};\\\", \\\"{x:1524,y:931,t:1528144150075};\\\", \\\"{x:1537,y:956,t:1528144150091};\\\", \\\"{x:1545,y:968,t:1528144150109};\\\", \\\"{x:1547,y:972,t:1528144150125};\\\", \\\"{x:1547,y:974,t:1528144150142};\\\", \\\"{x:1547,y:975,t:1528144150171};\\\", \\\"{x:1547,y:977,t:1528144150179};\\\", \\\"{x:1546,y:978,t:1528144150191};\\\", \\\"{x:1544,y:980,t:1528144150208};\\\", \\\"{x:1542,y:982,t:1528144150226};\\\", \\\"{x:1541,y:982,t:1528144150242};\\\", \\\"{x:1539,y:982,t:1528144150268};\\\", \\\"{x:1537,y:982,t:1528144150275};\\\", \\\"{x:1529,y:981,t:1528144150293};\\\", \\\"{x:1517,y:974,t:1528144150309};\\\", \\\"{x:1503,y:967,t:1528144150326};\\\", \\\"{x:1493,y:960,t:1528144150343};\\\", \\\"{x:1487,y:957,t:1528144150359};\\\", \\\"{x:1482,y:955,t:1528144150376};\\\", \\\"{x:1480,y:953,t:1528144150393};\\\", \\\"{x:1479,y:953,t:1528144150410};\\\", \\\"{x:1478,y:953,t:1528144150428};\\\", \\\"{x:1477,y:953,t:1528144150443};\\\", \\\"{x:1476,y:953,t:1528144150508};\\\", \\\"{x:1474,y:954,t:1528144150524};\\\", \\\"{x:1473,y:955,t:1528144150540};\\\", \\\"{x:1473,y:957,t:1528144150556};\\\", \\\"{x:1473,y:958,t:1528144150563};\\\", \\\"{x:1473,y:959,t:1528144150577};\\\", \\\"{x:1474,y:962,t:1528144150594};\\\", \\\"{x:1475,y:963,t:1528144150610};\\\", \\\"{x:1476,y:963,t:1528144150627};\\\", \\\"{x:1460,y:956,t:1528144161813};\\\", \\\"{x:1393,y:930,t:1528144161819};\\\", \\\"{x:1318,y:908,t:1528144161833};\\\", \\\"{x:1204,y:871,t:1528144161848};\\\", \\\"{x:1151,y:846,t:1528144161866};\\\", \\\"{x:1102,y:827,t:1528144161883};\\\", \\\"{x:1082,y:817,t:1528144161900};\\\", \\\"{x:1069,y:807,t:1528144161916};\\\", \\\"{x:1068,y:807,t:1528144161932};\\\", \\\"{x:1066,y:805,t:1528144161988};\\\", \\\"{x:1062,y:802,t:1528144162000};\\\", \\\"{x:1048,y:792,t:1528144162016};\\\", \\\"{x:1023,y:777,t:1528144162033};\\\", \\\"{x:986,y:765,t:1528144162049};\\\", \\\"{x:955,y:755,t:1528144162066};\\\", \\\"{x:936,y:747,t:1528144162081};\\\", \\\"{x:935,y:737,t:1528144162099};\\\", \\\"{x:935,y:724,t:1528144162115};\\\", \\\"{x:935,y:711,t:1528144162132};\\\", \\\"{x:924,y:699,t:1528144162149};\\\", \\\"{x:902,y:683,t:1528144162166};\\\", \\\"{x:895,y:679,t:1528144162183};\\\", \\\"{x:894,y:677,t:1528144162388};\\\", \\\"{x:894,y:674,t:1528144162400};\\\", \\\"{x:892,y:671,t:1528144162417};\\\", \\\"{x:892,y:666,t:1528144162434};\\\", \\\"{x:888,y:656,t:1528144162451};\\\", \\\"{x:883,y:644,t:1528144162468};\\\", \\\"{x:881,y:639,t:1528144162484};\\\", \\\"{x:880,y:636,t:1528144162500};\\\", \\\"{x:879,y:632,t:1528144162517};\\\", \\\"{x:878,y:628,t:1528144162533};\\\", \\\"{x:876,y:626,t:1528144162551};\\\", \\\"{x:876,y:623,t:1528144162568};\\\", \\\"{x:873,y:619,t:1528144162583};\\\", \\\"{x:868,y:615,t:1528144162601};\\\", \\\"{x:861,y:608,t:1528144162618};\\\", \\\"{x:855,y:602,t:1528144162635};\\\", \\\"{x:845,y:594,t:1528144162651};\\\", \\\"{x:842,y:589,t:1528144162669};\\\", \\\"{x:841,y:587,t:1528144162684};\\\", \\\"{x:841,y:584,t:1528144162701};\\\", \\\"{x:839,y:580,t:1528144162719};\\\", \\\"{x:839,y:577,t:1528144162734};\\\", \\\"{x:839,y:575,t:1528144162752};\\\", \\\"{x:839,y:574,t:1528144162768};\\\", \\\"{x:839,y:572,t:1528144162785};\\\", \\\"{x:839,y:570,t:1528144162801};\\\", \\\"{x:839,y:569,t:1528144162819};\\\", \\\"{x:840,y:568,t:1528144162868};\\\", \\\"{x:841,y:568,t:1528144162986};\\\", \\\"{x:841,y:568,t:1528144163011};\\\", \\\"{x:841,y:571,t:1528144163123};\\\", \\\"{x:849,y:581,t:1528144163135};\\\", \\\"{x:872,y:600,t:1528144163151};\\\", \\\"{x:913,y:626,t:1528144163168};\\\", \\\"{x:959,y:649,t:1528144163185};\\\", \\\"{x:1000,y:665,t:1528144163201};\\\", \\\"{x:1035,y:680,t:1528144163218};\\\", \\\"{x:1106,y:703,t:1528144163234};\\\", \\\"{x:1186,y:724,t:1528144163252};\\\", \\\"{x:1278,y:753,t:1528144163268};\\\", \\\"{x:1377,y:794,t:1528144163285};\\\", \\\"{x:1427,y:823,t:1528144163302};\\\", \\\"{x:1433,y:828,t:1528144163318};\\\", \\\"{x:1433,y:829,t:1528144163338};\\\", \\\"{x:1433,y:831,t:1528144163352};\\\", \\\"{x:1433,y:838,t:1528144163368};\\\", \\\"{x:1436,y:845,t:1528144163385};\\\", \\\"{x:1436,y:849,t:1528144163402};\\\", \\\"{x:1436,y:850,t:1528144163418};\\\", \\\"{x:1430,y:850,t:1528144163450};\\\", \\\"{x:1415,y:850,t:1528144163458};\\\", \\\"{x:1394,y:840,t:1528144163468};\\\", \\\"{x:1319,y:805,t:1528144163485};\\\", \\\"{x:1240,y:763,t:1528144163502};\\\", \\\"{x:1151,y:717,t:1528144163519};\\\", \\\"{x:1082,y:676,t:1528144163535};\\\", \\\"{x:1044,y:653,t:1528144163552};\\\", \\\"{x:1015,y:637,t:1528144163568};\\\", \\\"{x:1005,y:632,t:1528144163585};\\\", \\\"{x:1000,y:629,t:1528144163602};\\\", \\\"{x:999,y:629,t:1528144163651};\\\", \\\"{x:993,y:629,t:1528144163669};\\\", \\\"{x:982,y:628,t:1528144163686};\\\", \\\"{x:964,y:628,t:1528144163703};\\\", \\\"{x:942,y:627,t:1528144163720};\\\", \\\"{x:923,y:627,t:1528144163734};\\\", \\\"{x:912,y:622,t:1528144163751};\\\", \\\"{x:901,y:616,t:1528144163768};\\\", \\\"{x:890,y:607,t:1528144163785};\\\", \\\"{x:879,y:599,t:1528144163801};\\\", \\\"{x:874,y:592,t:1528144163818};\\\", \\\"{x:867,y:580,t:1528144163835};\\\", \\\"{x:864,y:576,t:1528144163852};\\\", \\\"{x:864,y:572,t:1528144163869};\\\", \\\"{x:863,y:569,t:1528144163885};\\\", \\\"{x:862,y:566,t:1528144163902};\\\", \\\"{x:862,y:565,t:1528144163919};\\\", \\\"{x:861,y:563,t:1528144163947};\\\", \\\"{x:860,y:563,t:1528144163963};\\\", \\\"{x:859,y:562,t:1528144163971};\\\", \\\"{x:857,y:562,t:1528144163986};\\\", \\\"{x:854,y:560,t:1528144164002};\\\", \\\"{x:850,y:559,t:1528144164019};\\\", \\\"{x:846,y:558,t:1528144164035};\\\", \\\"{x:843,y:557,t:1528144164053};\\\", \\\"{x:840,y:556,t:1528144164069};\\\", \\\"{x:838,y:556,t:1528144164086};\\\", \\\"{x:837,y:556,t:1528144164102};\\\", \\\"{x:836,y:555,t:1528144164120};\\\", \\\"{x:837,y:555,t:1528144164291};\\\", \\\"{x:848,y:558,t:1528144164302};\\\", \\\"{x:890,y:576,t:1528144164319};\\\", \\\"{x:957,y:612,t:1528144164336};\\\", \\\"{x:1043,y:654,t:1528144164352};\\\", \\\"{x:1125,y:696,t:1528144164370};\\\", \\\"{x:1202,y:728,t:1528144164386};\\\", \\\"{x:1258,y:757,t:1528144164402};\\\", \\\"{x:1333,y:805,t:1528144164419};\\\", \\\"{x:1379,y:833,t:1528144164437};\\\", \\\"{x:1429,y:866,t:1528144164452};\\\", \\\"{x:1456,y:881,t:1528144164469};\\\", \\\"{x:1463,y:887,t:1528144164487};\\\", \\\"{x:1464,y:888,t:1528144164504};\\\", \\\"{x:1464,y:889,t:1528144164519};\\\", \\\"{x:1469,y:895,t:1528144164536};\\\", \\\"{x:1472,y:907,t:1528144164553};\\\", \\\"{x:1475,y:916,t:1528144164570};\\\", \\\"{x:1480,y:928,t:1528144164587};\\\", \\\"{x:1485,y:937,t:1528144164603};\\\", \\\"{x:1487,y:942,t:1528144164620};\\\", \\\"{x:1491,y:948,t:1528144164638};\\\", \\\"{x:1494,y:952,t:1528144164654};\\\", \\\"{x:1494,y:953,t:1528144164691};\\\", \\\"{x:1494,y:954,t:1528144164724};\\\", \\\"{x:1494,y:955,t:1528144164739};\\\", \\\"{x:1494,y:956,t:1528144164755};\\\", \\\"{x:1494,y:957,t:1528144164771};\\\", \\\"{x:1492,y:958,t:1528144164787};\\\", \\\"{x:1489,y:960,t:1528144164804};\\\", \\\"{x:1485,y:962,t:1528144164820};\\\", \\\"{x:1480,y:964,t:1528144164838};\\\", \\\"{x:1478,y:966,t:1528144164854};\\\", \\\"{x:1476,y:967,t:1528144164871};\\\", \\\"{x:1474,y:967,t:1528144164886};\\\", \\\"{x:1471,y:969,t:1528144164904};\\\", \\\"{x:1474,y:969,t:1528144165048};\\\", \\\"{x:1477,y:969,t:1528144165058};\\\", \\\"{x:1484,y:969,t:1528144165075};\\\", \\\"{x:1486,y:969,t:1528144165091};\\\", \\\"{x:1487,y:969,t:1528144165107};\\\", \\\"{x:1486,y:969,t:1528144165744};\\\", \\\"{x:1484,y:968,t:1528144165784};\\\", \\\"{x:1483,y:968,t:1528144165791};\\\", \\\"{x:1482,y:966,t:1528144165832};\\\", \\\"{x:1481,y:966,t:1528144165842};\\\", \\\"{x:1480,y:966,t:1528144165859};\\\", \\\"{x:1477,y:965,t:1528144165875};\\\", \\\"{x:1476,y:965,t:1528144165903};\\\", \\\"{x:1476,y:964,t:1528144165919};\\\", \\\"{x:1477,y:964,t:1528144167128};\\\", \\\"{x:1478,y:964,t:1528144191584};\\\", \\\"{x:1454,y:956,t:1528144191600};\\\", \\\"{x:1426,y:956,t:1528144191616};\\\", \\\"{x:1416,y:957,t:1528144191633};\\\", \\\"{x:1404,y:962,t:1528144191651};\\\", \\\"{x:1386,y:970,t:1528144191667};\\\", \\\"{x:1374,y:975,t:1528144191684};\\\", \\\"{x:1354,y:983,t:1528144191701};\\\", \\\"{x:1305,y:993,t:1528144191717};\\\", \\\"{x:1244,y:998,t:1528144191734};\\\", \\\"{x:1134,y:970,t:1528144191752};\\\", \\\"{x:1065,y:941,t:1528144191767};\\\", \\\"{x:997,y:902,t:1528144191784};\\\", \\\"{x:927,y:851,t:1528144191801};\\\", \\\"{x:863,y:807,t:1528144191817};\\\", \\\"{x:759,y:719,t:1528144191834};\\\", \\\"{x:596,y:580,t:1528144191852};\\\", \\\"{x:434,y:446,t:1528144191866};\\\", \\\"{x:296,y:350,t:1528144191883};\\\", \\\"{x:185,y:295,t:1528144191900};\\\", \\\"{x:165,y:290,t:1528144191916};\\\", \\\"{x:164,y:290,t:1528144191933};\\\", \\\"{x:163,y:290,t:1528144191950};\\\", \\\"{x:160,y:296,t:1528144191966};\\\", \\\"{x:157,y:312,t:1528144191983};\\\", \\\"{x:157,y:337,t:1528144192000};\\\", \\\"{x:162,y:357,t:1528144192017};\\\", \\\"{x:174,y:375,t:1528144192034};\\\", \\\"{x:191,y:395,t:1528144192050};\\\", \\\"{x:221,y:416,t:1528144192068};\\\", \\\"{x:263,y:447,t:1528144192084};\\\", \\\"{x:310,y:477,t:1528144192101};\\\", \\\"{x:327,y:490,t:1528144192118};\\\", \\\"{x:332,y:496,t:1528144192133};\\\", \\\"{x:338,y:506,t:1528144192153};\\\", \\\"{x:343,y:515,t:1528144192167};\\\", \\\"{x:352,y:526,t:1528144192183};\\\", \\\"{x:359,y:532,t:1528144192196};\\\", \\\"{x:370,y:540,t:1528144192212};\\\", \\\"{x:375,y:544,t:1528144192229};\\\", \\\"{x:378,y:546,t:1528144192245};\\\", \\\"{x:378,y:547,t:1528144192278};\\\", \\\"{x:378,y:550,t:1528144192294};\\\", \\\"{x:377,y:551,t:1528144192310};\\\", \\\"{x:377,y:552,t:1528144192318};\\\", \\\"{x:376,y:554,t:1528144192399};\\\", \\\"{x:376,y:560,t:1528144192412};\\\", \\\"{x:376,y:565,t:1528144192429};\\\", \\\"{x:377,y:571,t:1528144192446};\\\", \\\"{x:381,y:576,t:1528144192463};\\\", \\\"{x:382,y:578,t:1528144192480};\\\", \\\"{x:382,y:580,t:1528144192497};\\\", \\\"{x:404,y:580,t:1528144193007};\\\", \\\"{x:454,y:580,t:1528144193016};\\\", \\\"{x:516,y:586,t:1528144193030};\\\", \\\"{x:755,y:597,t:1528144193046};\\\", \\\"{x:924,y:601,t:1528144193063};\\\", \\\"{x:1093,y:601,t:1528144193079};\\\", \\\"{x:1216,y:596,t:1528144193096};\\\", \\\"{x:1304,y:587,t:1528144193113};\\\", \\\"{x:1334,y:585,t:1528144193129};\\\", \\\"{x:1343,y:580,t:1528144193146};\\\", \\\"{x:1345,y:577,t:1528144193164};\\\", \\\"{x:1345,y:580,t:1528144193206};\\\", \\\"{x:1344,y:586,t:1528144193215};\\\", \\\"{x:1340,y:595,t:1528144193230};\\\", \\\"{x:1319,y:642,t:1528144193246};\\\", \\\"{x:1307,y:682,t:1528144193264};\\\", \\\"{x:1299,y:722,t:1528144193279};\\\", \\\"{x:1298,y:749,t:1528144193297};\\\", \\\"{x:1302,y:774,t:1528144193314};\\\", \\\"{x:1306,y:787,t:1528144193330};\\\", \\\"{x:1309,y:792,t:1528144193346};\\\", \\\"{x:1310,y:793,t:1528144193364};\\\", \\\"{x:1310,y:794,t:1528144193390};\\\", \\\"{x:1311,y:794,t:1528144193519};\\\", \\\"{x:1318,y:794,t:1528144193530};\\\", \\\"{x:1337,y:803,t:1528144193547};\\\", \\\"{x:1341,y:806,t:1528144193563};\\\", \\\"{x:1345,y:810,t:1528144193580};\\\", \\\"{x:1349,y:813,t:1528144193596};\\\", \\\"{x:1352,y:816,t:1528144193613};\\\", \\\"{x:1354,y:819,t:1528144193630};\\\", \\\"{x:1355,y:820,t:1528144193647};\\\", \\\"{x:1357,y:827,t:1528144193664};\\\", \\\"{x:1363,y:838,t:1528144193681};\\\", \\\"{x:1368,y:846,t:1528144193697};\\\", \\\"{x:1373,y:851,t:1528144193714};\\\", \\\"{x:1387,y:861,t:1528144193731};\\\", \\\"{x:1406,y:871,t:1528144193747};\\\", \\\"{x:1430,y:880,t:1528144193764};\\\", \\\"{x:1459,y:893,t:1528144193781};\\\", \\\"{x:1485,y:903,t:1528144193798};\\\", \\\"{x:1494,y:907,t:1528144193814};\\\", \\\"{x:1494,y:908,t:1528144193831};\\\", \\\"{x:1496,y:912,t:1528144193847};\\\", \\\"{x:1496,y:917,t:1528144193864};\\\", \\\"{x:1497,y:921,t:1528144193881};\\\", \\\"{x:1499,y:925,t:1528144193898};\\\", \\\"{x:1499,y:926,t:1528144193914};\\\", \\\"{x:1499,y:928,t:1528144193931};\\\", \\\"{x:1499,y:929,t:1528144193948};\\\", \\\"{x:1499,y:931,t:1528144193963};\\\", \\\"{x:1499,y:932,t:1528144193980};\\\", \\\"{x:1495,y:936,t:1528144193998};\\\", \\\"{x:1492,y:941,t:1528144194013};\\\", \\\"{x:1491,y:943,t:1528144194031};\\\", \\\"{x:1490,y:945,t:1528144194095};\\\", \\\"{x:1489,y:946,t:1528144194127};\\\", \\\"{x:1488,y:947,t:1528144194136};\\\", \\\"{x:1488,y:949,t:1528144194148};\\\", \\\"{x:1486,y:951,t:1528144194165};\\\", \\\"{x:1485,y:953,t:1528144194183};\\\", \\\"{x:1484,y:955,t:1528144194215};\\\", \\\"{x:1484,y:956,t:1528144194231};\\\", \\\"{x:1483,y:956,t:1528144194249};\\\", \\\"{x:1482,y:958,t:1528144194265};\\\", \\\"{x:1482,y:959,t:1528144194281};\\\", \\\"{x:1481,y:960,t:1528144194311};\\\", \\\"{x:1481,y:961,t:1528144194351};\\\", \\\"{x:1480,y:962,t:1528144194400};\\\", \\\"{x:1479,y:954,t:1528144234659};\\\", \\\"{x:1446,y:909,t:1528144234667};\\\", \\\"{x:1398,y:835,t:1528144234683};\\\", \\\"{x:1389,y:811,t:1528144234700};\\\", \\\"{x:1373,y:811,t:1528144234938};\\\", \\\"{x:1323,y:811,t:1528144234949};\\\", \\\"{x:1199,y:784,t:1528144234967};\\\", \\\"{x:1113,y:773,t:1528144234984};\\\", \\\"{x:1016,y:759,t:1528144234999};\\\", \\\"{x:904,y:751,t:1528144235017};\\\", \\\"{x:768,y:751,t:1528144235034};\\\", \\\"{x:726,y:751,t:1528144235049};\\\", \\\"{x:701,y:751,t:1528144235066};\\\", \\\"{x:691,y:751,t:1528144235083};\\\", \\\"{x:686,y:752,t:1528144235099};\\\", \\\"{x:682,y:753,t:1528144235116};\\\", \\\"{x:678,y:756,t:1528144235134};\\\", \\\"{x:678,y:757,t:1528144235149};\\\", \\\"{x:677,y:758,t:1528144235167};\\\", \\\"{x:677,y:759,t:1528144235183};\\\", \\\"{x:675,y:760,t:1528144235209};\\\", \\\"{x:667,y:760,t:1528144235217};\\\", \\\"{x:636,y:751,t:1528144235233};\\\", \\\"{x:565,y:733,t:1528144235249};\\\", \\\"{x:492,y:731,t:1528144235266};\\\", \\\"{x:441,y:732,t:1528144235283};\\\", \\\"{x:408,y:737,t:1528144235301};\\\", \\\"{x:399,y:740,t:1528144235317};\\\", \\\"{x:397,y:740,t:1528144235333};\\\", \\\"{x:397,y:742,t:1528144235434};\\\", \\\"{x:411,y:747,t:1528144235450};\\\", \\\"{x:426,y:753,t:1528144235467};\\\", \\\"{x:439,y:757,t:1528144235483};\\\", \\\"{x:451,y:757,t:1528144235502};\\\", \\\"{x:460,y:757,t:1528144235516};\\\", \\\"{x:466,y:757,t:1528144235533};\\\", \\\"{x:469,y:757,t:1528144235550};\\\", \\\"{x:470,y:757,t:1528144235567};\\\", \\\"{x:471,y:756,t:1528144235583};\\\", \\\"{x:472,y:756,t:1528144235600};\\\", \\\"{x:474,y:755,t:1528144235616};\\\", \\\"{x:475,y:755,t:1528144235634};\\\", \\\"{x:477,y:754,t:1528144235650};\\\", \\\"{x:479,y:754,t:1528144236257};\\\", \\\"{x:534,y:761,t:1528144236267};\\\", \\\"{x:622,y:772,t:1528144236284};\\\", \\\"{x:645,y:773,t:1528144236301};\\\", \\\"{x:675,y:762,t:1528144236317};\\\", \\\"{x:697,y:752,t:1528144236334};\\\", \\\"{x:707,y:742,t:1528144236351};\\\", \\\"{x:710,y:733,t:1528144236367};\\\", \\\"{x:713,y:722,t:1528144236384};\\\", \\\"{x:716,y:719,t:1528144236402};\\\", \\\"{x:716,y:718,t:1528144236721};\\\", \\\"{x:715,y:717,t:1528144236745};\\\", \\\"{x:715,y:716,t:1528144236753};\\\", \\\"{x:706,y:711,t:1528144236784};\\\", \\\"{x:704,y:709,t:1528144236800};\\\", \\\"{x:704,y:706,t:1528144237049};\\\", \\\"{x:704,y:705,t:1528144237057};\\\", \\\"{x:705,y:700,t:1528144237067};\\\", \\\"{x:706,y:692,t:1528144237085};\\\", \\\"{x:706,y:689,t:1528144237101};\\\", \\\"{x:706,y:686,t:1528144237118};\\\", \\\"{x:707,y:685,t:1528144237137};\\\" ] }, { \\\"rt\\\": 32092, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 20, \\\"time_elapsed\\\": 1185018, \\\"internal_node_id\\\": \\\"0.0-7.0-0.0\\\", \\\"subject\\\": \\\"MKTF4\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"zulu\\\", \\\"condition\\\": \\\"211\\\", \\\"q\\\": 16, \\\"answer\\\": \\\"The line left of the point is when it starts\\\\n\\\", \\\"block\\\": \\\"triangular_testing\\\" }, { \\\"rt\\\": 6428, \\\"responses\\\": \\\"{\\\\\\\"Q0\\\\\\\":\\\\\\\"22\\\\\\\",\\\\\\\"Q1\\\\\\\":\\\\\\\"U.S\\\\\\\"}\\\", \\\"block\\\": \\\"demo-1\\\", \\\"trial_type\\\": \\\"survey-text\\\", \\\"trial_index\\\": 21, \\\"time_elapsed\\\": 1192452, \\\"internal_node_id\\\": \\\"0.0-8.0\\\", \\\"subject\\\": \\\"MKTF4\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"zulu\\\", \\\"condition\\\": \\\"211\\\" }, { \\\"rt\\\": 7633, \\\"responses\\\": \\\"{\\\\\\\"Q0\\\\\\\":\\\\\\\"English\\\\\\\",\\\\\\\"Q1\\\\\\\":\\\\\\\"Fourth\\\\\\\",\\\\\\\"Q2\\\\\\\":\\\\\\\"Biomedical & Health Sciences\\\\\\\",\\\\\\\"Q3\\\\\\\":\\\\\\\"Male\\\\\\\"}\\\", \\\"block\\\": \\\"demo-2\\\", \\\"trial_type\\\": \\\"survey-multi-choice\\\", \\\"trial_index\\\": 22, \\\"time_elapsed\\\": 1201110, \\\"internal_node_id\\\": \\\"0.0-9.0\\\", \\\"subject\\\": \\\"MKTF4\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"zulu\\\", \\\"condition\\\": \\\"211\\\" }, { \\\"rt\\\": 1274, \\\"url\\\": \\\"../views/src/external/debrief.html\\\", \\\"block\\\": \\\"debrief\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 23, \\\"time_elapsed\\\": 1203470, \\\"internal_node_id\\\": \\\"0.0-10.0\\\", \\\"subject\\\": \\\"MKTF4\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"zulu\\\", \\\"condition\\\": \\\"211\\\" } ]\",\"parentNode\":{\"id\":2765}}],[],[]]}"
    }
  ],
  "initialDom": "{\"f\":\"initialize\",\"args\":[1,[{\"nodeType\":10,\"id\":2,\"name\":\"html\",\"publicId\":\"\",\"systemId\":\"\"},{\"nodeType\":1,\"id\":3,\"tagName\":\"HTML\",\"attributes\":{\"class\":\"fa-events-icons-ready\"},\"childNodes\":[{\"nodeType\":1,\"id\":4,\"tagName\":\"HEAD\",\"attributes\":{},\"childNodes\":[{\"nodeType\":3,\"id\":5,\"textContent\":\" \"},{\"nodeType\":1,\"id\":6,\"tagName\":\"TITLE\",\"attributes\":{},\"childNodes\":[{\"nodeType\":3,\"id\":7,\"textContent\":\"FOX2YP\"}]},{\"nodeType\":3,\"id\":8,\"textContent\":\" \"},{\"nodeType\":8,\"id\":9},{\"nodeType\":3,\"id\":10,\"textContent\":\" \"},{\"nodeType\":1,\"id\":11,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":12,\"textContent\":\" \"},{\"nodeType\":1,\"id\":13,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":14,\"textContent\":\" \"},{\"nodeType\":1,\"id\":15,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":16,\"textContent\":\" \"},{\"nodeType\":1,\"id\":17,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":18,\"textContent\":\" \"},{\"nodeType\":1,\"id\":19,\"tagName\":\"SCRIPT\"},{\"nodeType\":1,\"id\":20,\"tagName\":\"LINK\",\"attributes\":{\"href\":\"https://use.fontawesome.com/945539d961.css\",\"media\":\"all\",\"rel\":\"stylesheet\"}},{\"nodeType\":3,\"id\":21,\"textContent\":\" \"},{\"nodeType\":8,\"id\":22},{\"nodeType\":3,\"id\":23,\"textContent\":\" \"},{\"nodeType\":1,\"id\":24,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":25,\"textContent\":\" \"},{\"nodeType\":1,\"id\":26,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":27,\"textContent\":\" \"},{\"nodeType\":1,\"id\":28,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":29,\"textContent\":\" \"},{\"nodeType\":1,\"id\":30,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":31,\"textContent\":\" \"},{\"nodeType\":1,\"id\":32,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":33,\"textContent\":\" \"},{\"nodeType\":1,\"id\":34,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":35,\"textContent\":\" \"},{\"nodeType\":1,\"id\":36,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":37,\"textContent\":\" \"},{\"nodeType\":8,\"id\":38},{\"nodeType\":3,\"id\":39,\"textContent\":\" \"},{\"nodeType\":1,\"id\":40,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":41,\"textContent\":\" \"},{\"nodeType\":8,\"id\":42},{\"nodeType\":3,\"id\":43,\"textContent\":\" \"},{\"nodeType\":8,\"id\":44},{\"nodeType\":3,\"id\":45,\"textContent\":\" \"},{\"nodeType\":1,\"id\":46,\"tagName\":\"LINK\",\"attributes\":{\"href\":\"../views/jsPsych/css/jspsych.css\",\"rel\":\"stylesheet\",\"type\":\"text/css\"}},{\"nodeType\":3,\"id\":47,\"textContent\":\" \"},{\"nodeType\":1,\"id\":48,\"tagName\":\"LINK\",\"attributes\":{\"href\":\"../css/styles.css\",\"rel\":\"stylesheet\",\"type\":\"text/css\"}},{\"nodeType\":3,\"id\":49,\"textContent\":\" \"},{\"nodeType\":1,\"id\":50,\"tagName\":\"SCRIPT\"},{\"nodeType\":1,\"id\":51,\"tagName\":\"SCRIPT\"}]},{\"nodeType\":3,\"id\":52,\"textContent\":\" \"},{\"nodeType\":8,\"id\":53},{\"nodeType\":3,\"id\":54,\"textContent\":\" \"},{\"nodeType\":1,\"id\":55,\"tagName\":\"BODY\",\"attributes\":{\"class\":\"jspsych-display-element\"},\"childNodes\":[{\"nodeType\":3,\"id\":56,\"textContent\":\" \"},{\"nodeType\":1,\"id\":57,\"tagName\":\"META\",\"attributes\":{\"charset\":\"utf-8\"}},{\"nodeType\":3,\"id\":58,\"textContent\":\" \"},{\"nodeType\":8,\"id\":59},{\"nodeType\":3,\"id\":60,\"textContent\":\" \"},{\"nodeType\":1,\"id\":61,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":62,\"textContent\":\" \"},{\"nodeType\":1,\"id\":63,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":64,\"textContent\":\" \"},{\"nodeType\":1,\"id\":65,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":66,\"textContent\":\" \"},{\"nodeType\":1,\"id\":67,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":68,\"textContent\":\" \"},{\"nodeType\":1,\"id\":69,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":70,\"textContent\":\" \"},{\"nodeType\":1,\"id\":71,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":72,\"textContent\":\" \"},{\"nodeType\":1,\"id\":73,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"stimulus\"},\"childNodes\":[{\"nodeType\":3,\"id\":74,\"textContent\":\" \"},{\"nodeType\":1,\"id\":75,\"tagName\":\"P\",\"attributes\":{\"class\":\"userid\",\"id\":\"userid\"},\"childNodes\":[{\"nodeType\":3,\"id\":76,\"textContent\":\"MKTF4\"}]},{\"nodeType\":3,\"id\":77,\"textContent\":\" \"},{\"nodeType\":1,\"id\":78,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"userinput\"},\"childNodes\":[{\"nodeType\":3,\"id\":79,\"textContent\":\" \"},{\"nodeType\":8,\"id\":80},{\"nodeType\":3,\"id\":81,\"textContent\":\" \"},{\"nodeType\":1,\"id\":82,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"legend\",\"id\":\"hint-interactive\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":83,\"textContent\":\" \"},{\"nodeType\":1,\"id\":84,\"tagName\":\"P\",\"attributes\":{},\"childNodes\":[{\"nodeType\":3,\"id\":85,\"textContent\":\"Hint: Hover your mouse over the data points in the graph\"}]},{\"nodeType\":3,\"id\":86,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":87,\"textContent\":\" \"},{\"nodeType\":8,\"id\":88},{\"nodeType\":3,\"id\":89,\"textContent\":\" \"},{\"nodeType\":8,\"id\":90},{\"nodeType\":3,\"id\":91,\"textContent\":\" \"},{\"nodeType\":1,\"id\":92,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"test\"},\"childNodes\":[{\"nodeType\":3,\"id\":93,\"textContent\":\" \"},{\"nodeType\":1,\"id\":94,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"acme\",\"id\":\"acme.starttime\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":95,\"textContent\":\" \"},{\"nodeType\":1,\"id\":96,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":97,\"textContent\":\"Which shift(s) start at 11 am? \"}]},{\"nodeType\":3,\"id\":98,\"textContent\":\" \"},{\"nodeType\":1,\"id\":99,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":100,\"textContent\":\" \"},{\"nodeType\":1,\"id\":101,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":102,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":103,\"textContent\":\" \"},{\"nodeType\":1,\"id\":104,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":105,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":106,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":107,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":108,\"textContent\":\" \"},{\"nodeType\":1,\"id\":109,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":110,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":111,\"textContent\":\" \"},{\"nodeType\":1,\"id\":112,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":113,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":114,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":115,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":116,\"textContent\":\" \"},{\"nodeType\":1,\"id\":117,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":118,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":119,\"textContent\":\" \"},{\"nodeType\":1,\"id\":120,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":121,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":122,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":123,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":124,\"textContent\":\" \"},{\"nodeType\":1,\"id\":125,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":126,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":127,\"textContent\":\" \"},{\"nodeType\":1,\"id\":128,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":129,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":130,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":131,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":132,\"textContent\":\" \"},{\"nodeType\":1,\"id\":133,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":134,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":135,\"textContent\":\" \"},{\"nodeType\":1,\"id\":136,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":137,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":138,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":139,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":140,\"textContent\":\" \"},{\"nodeType\":1,\"id\":141,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":142,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":143,\"textContent\":\" \"},{\"nodeType\":1,\"id\":144,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":145,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":146,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":147,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":148,\"textContent\":\" \"},{\"nodeType\":1,\"id\":149,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":150,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":151,\"textContent\":\" \"},{\"nodeType\":1,\"id\":152,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":153,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":154,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":155,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":156,\"textContent\":\" \"},{\"nodeType\":1,\"id\":157,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":158,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":159,\"textContent\":\" \"},{\"nodeType\":1,\"id\":160,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":161,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":162,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":163,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":164,\"textContent\":\" \"},{\"nodeType\":1,\"id\":165,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":166,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":167,\"textContent\":\" \"},{\"nodeType\":1,\"id\":168,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":169,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":170,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":171,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":172,\"textContent\":\" \"},{\"nodeType\":1,\"id\":173,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":174,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":175,\"textContent\":\" \"},{\"nodeType\":1,\"id\":176,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":177,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":178,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":179,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":180,\"textContent\":\" \"},{\"nodeType\":1,\"id\":181,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":182,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":183,\"textContent\":\" \"},{\"nodeType\":1,\"id\":184,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"U\",\"value\":\"\"}},{\"nodeType\":3,\"id\":185,\"textContent\":\"U \"},{\"nodeType\":1,\"id\":186,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":187,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":188,\"textContent\":\" \"},{\"nodeType\":1,\"id\":189,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":190,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":191,\"textContent\":\" \"},{\"nodeType\":1,\"id\":192,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":193,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":194,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":195,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":196,\"textContent\":\" \"},{\"nodeType\":1,\"id\":197,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":198,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":199,\"textContent\":\" \"},{\"nodeType\":1,\"id\":200,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":201,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":202,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":203,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":204,\"textContent\":\" \"},{\"nodeType\":1,\"id\":205,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":206,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":207,\"textContent\":\" \"},{\"nodeType\":1,\"id\":208,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":209,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":210,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":211,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":212,\"textContent\":\" \"},{\"nodeType\":1,\"id\":213,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":214,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":215,\"textContent\":\" \"},{\"nodeType\":1,\"id\":216,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":217,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":218,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":219,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":220,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":221,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":222,\"textContent\":\" \"},{\"nodeType\":1,\"id\":223,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"acme\",\"id\":\"acme.starts\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":224,\"textContent\":\" \"},{\"nodeType\":1,\"id\":225,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":226,\"textContent\":\"Which shift(s) start at the same time as D?\"}]},{\"nodeType\":3,\"id\":227,\"textContent\":\" \"},{\"nodeType\":1,\"id\":228,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":229,\"textContent\":\" \"},{\"nodeType\":1,\"id\":230,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":231,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":232,\"textContent\":\" \"},{\"nodeType\":1,\"id\":233,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":234,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":235,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":236,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":237,\"textContent\":\" \"},{\"nodeType\":1,\"id\":238,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":239,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":240,\"textContent\":\" \"},{\"nodeType\":1,\"id\":241,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":242,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":243,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":244,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":245,\"textContent\":\" \"},{\"nodeType\":1,\"id\":246,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":247,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":248,\"textContent\":\" \"},{\"nodeType\":1,\"id\":249,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":250,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":251,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":252,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":253,\"textContent\":\" \"},{\"nodeType\":1,\"id\":254,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":255,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":256,\"textContent\":\" \"},{\"nodeType\":1,\"id\":257,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":258,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":259,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":260,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":261,\"textContent\":\" \"},{\"nodeType\":1,\"id\":262,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":263,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":264,\"textContent\":\" \"},{\"nodeType\":1,\"id\":265,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":266,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":267,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":268,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":269,\"textContent\":\" \"},{\"nodeType\":1,\"id\":270,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":271,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":272,\"textContent\":\" \"},{\"nodeType\":1,\"id\":273,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":274,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":275,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":276,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":277,\"textContent\":\" \"},{\"nodeType\":1,\"id\":278,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":279,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":280,\"textContent\":\" \"},{\"nodeType\":1,\"id\":281,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":282,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":283,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":284,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":285,\"textContent\":\" \"},{\"nodeType\":1,\"id\":286,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":287,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":288,\"textContent\":\" \"},{\"nodeType\":1,\"id\":289,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":290,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":291,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":292,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":293,\"textContent\":\" \"},{\"nodeType\":1,\"id\":294,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":295,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":296,\"textContent\":\" \"},{\"nodeType\":1,\"id\":297,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":298,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":299,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":300,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":301,\"textContent\":\" \"},{\"nodeType\":1,\"id\":302,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":303,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":304,\"textContent\":\" \"},{\"nodeType\":1,\"id\":305,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":306,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":307,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":308,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":309,\"textContent\":\" \"},{\"nodeType\":1,\"id\":310,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":311,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":312,\"textContent\":\" \"},{\"nodeType\":1,\"id\":313,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"U\",\"value\":\"\"}},{\"nodeType\":3,\"id\":314,\"textContent\":\"U \"},{\"nodeType\":1,\"id\":315,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":316,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":317,\"textContent\":\" \"},{\"nodeType\":1,\"id\":318,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":319,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":320,\"textContent\":\" \"},{\"nodeType\":1,\"id\":321,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":322,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":323,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":324,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":325,\"textContent\":\" \"},{\"nodeType\":1,\"id\":326,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":327,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":328,\"textContent\":\" \"},{\"nodeType\":1,\"id\":329,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":330,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":331,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":332,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":333,\"textContent\":\" \"},{\"nodeType\":1,\"id\":334,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":335,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":336,\"textContent\":\" \"},{\"nodeType\":1,\"id\":337,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":338,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":339,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":340,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":341,\"textContent\":\" \"},{\"nodeType\":1,\"id\":342,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":343,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":344,\"textContent\":\" \"},{\"nodeType\":1,\"id\":345,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":346,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":347,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":348,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":349,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":350,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":351,\"textContent\":\" \"},{\"nodeType\":1,\"id\":352,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"acme\",\"id\":\"acme.meets\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":353,\"textContent\":\" \"},{\"nodeType\":1,\"id\":354,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":355,\"textContent\":\"Which shift(s) begin when C ends?\"}]},{\"nodeType\":3,\"id\":356,\"textContent\":\" \"},{\"nodeType\":1,\"id\":357,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":358,\"textContent\":\" \"},{\"nodeType\":1,\"id\":359,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":360,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":361,\"textContent\":\" \"},{\"nodeType\":1,\"id\":362,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":363,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":364,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":365,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":366,\"textContent\":\" \"},{\"nodeType\":1,\"id\":367,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":368,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":369,\"textContent\":\" \"},{\"nodeType\":1,\"id\":370,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":371,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":372,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":373,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":374,\"textContent\":\" \"},{\"nodeType\":1,\"id\":375,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":376,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":377,\"textContent\":\" \"},{\"nodeType\":1,\"id\":378,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":379,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":380,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":381,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":382,\"textContent\":\" \"},{\"nodeType\":1,\"id\":383,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":384,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":385,\"textContent\":\" \"},{\"nodeType\":1,\"id\":386,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":387,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":388,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":389,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":390,\"textContent\":\" \"},{\"nodeType\":1,\"id\":391,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":392,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":393,\"textContent\":\" \"},{\"nodeType\":1,\"id\":394,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":395,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":396,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":397,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":398,\"textContent\":\" \"},{\"nodeType\":1,\"id\":399,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":400,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":401,\"textContent\":\" \"},{\"nodeType\":1,\"id\":402,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":403,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":404,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":405,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":406,\"textContent\":\" \"},{\"nodeType\":1,\"id\":407,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":408,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":409,\"textContent\":\" \"},{\"nodeType\":1,\"id\":410,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":411,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":412,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":413,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":414,\"textContent\":\" \"},{\"nodeType\":1,\"id\":415,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":416,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":417,\"textContent\":\" \"},{\"nodeType\":1,\"id\":418,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":419,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":420,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":421,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":422,\"textContent\":\" \"},{\"nodeType\":1,\"id\":423,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":424,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":425,\"textContent\":\" \"},{\"nodeType\":1,\"id\":426,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":427,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":428,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":429,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":430,\"textContent\":\" \"},{\"nodeType\":1,\"id\":431,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":432,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":433,\"textContent\":\" \"},{\"nodeType\":1,\"id\":434,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":435,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":436,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":437,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":438,\"textContent\":\" \"},{\"nodeType\":1,\"id\":439,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":440,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":441,\"textContent\":\" \"},{\"nodeType\":1,\"id\":442,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"U\",\"value\":\"\"}},{\"nodeType\":3,\"id\":443,\"textContent\":\"U \"},{\"nodeType\":1,\"id\":444,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":445,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":446,\"textContent\":\" \"},{\"nodeType\":1,\"id\":447,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":448,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":449,\"textContent\":\" \"},{\"nodeType\":1,\"id\":450,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":451,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":452,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":453,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":454,\"textContent\":\" \"},{\"nodeType\":1,\"id\":455,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":456,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":457,\"textContent\":\" \"},{\"nodeType\":1,\"id\":458,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":459,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":460,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":461,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":462,\"textContent\":\" \"},{\"nodeType\":1,\"id\":463,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":464,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":465,\"textContent\":\" \"},{\"nodeType\":1,\"id\":466,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":467,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":468,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":469,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":470,\"textContent\":\" \"},{\"nodeType\":1,\"id\":471,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":472,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":473,\"textContent\":\" \"},{\"nodeType\":1,\"id\":474,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":475,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":476,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":477,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":478,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":479,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":480,\"textContent\":\" \"},{\"nodeType\":1,\"id\":481,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"acme\",\"id\":\"acme.endtime\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":482,\"textContent\":\" \"},{\"nodeType\":1,\"id\":483,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":484,\"textContent\":\" Which shift(s) end at 4 pm?\"}]},{\"nodeType\":3,\"id\":485,\"textContent\":\" \"},{\"nodeType\":1,\"id\":486,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":487,\"textContent\":\" \"},{\"nodeType\":1,\"id\":488,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":489,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":490,\"textContent\":\" \"},{\"nodeType\":1,\"id\":491,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":492,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":493,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":494,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":495,\"textContent\":\" \"},{\"nodeType\":1,\"id\":496,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":497,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":498,\"textContent\":\" \"},{\"nodeType\":1,\"id\":499,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":500,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":501,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":502,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":503,\"textContent\":\" \"},{\"nodeType\":1,\"id\":504,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":505,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":506,\"textContent\":\" \"},{\"nodeType\":1,\"id\":507,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":508,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":509,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":510,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":511,\"textContent\":\" \"},{\"nodeType\":1,\"id\":512,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":513,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":514,\"textContent\":\" \"},{\"nodeType\":1,\"id\":515,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":516,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":517,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":518,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":519,\"textContent\":\" \"},{\"nodeType\":1,\"id\":520,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":521,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":522,\"textContent\":\" \"},{\"nodeType\":1,\"id\":523,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":524,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":525,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":526,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":527,\"textContent\":\" \"},{\"nodeType\":1,\"id\":528,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":529,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":530,\"textContent\":\" \"},{\"nodeType\":1,\"id\":531,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":532,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":533,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":534,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":535,\"textContent\":\" \"},{\"nodeType\":1,\"id\":536,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":537,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":538,\"textContent\":\" \"},{\"nodeType\":1,\"id\":539,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":540,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":541,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":542,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":543,\"textContent\":\" \"},{\"nodeType\":1,\"id\":544,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":545,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":546,\"textContent\":\" \"},{\"nodeType\":1,\"id\":547,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":548,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":549,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":550,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":551,\"textContent\":\" \"},{\"nodeType\":1,\"id\":552,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":553,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":554,\"textContent\":\" \"},{\"nodeType\":1,\"id\":555,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":556,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":557,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":558,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":559,\"textContent\":\" \"},{\"nodeType\":1,\"id\":560,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":561,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":562,\"textContent\":\" \"},{\"nodeType\":1,\"id\":563,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":564,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":565,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":566,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":567,\"textContent\":\" \"},{\"nodeType\":1,\"id\":568,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":569,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":570,\"textContent\":\" \"},{\"nodeType\":1,\"id\":571,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"U\",\"value\":\"\"}},{\"nodeType\":3,\"id\":572,\"textContent\":\"U \"},{\"nodeType\":1,\"id\":573,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":574,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":575,\"textContent\":\" \"},{\"nodeType\":1,\"id\":576,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":577,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":578,\"textContent\":\" \"},{\"nodeType\":1,\"id\":579,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":580,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":581,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":582,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":583,\"textContent\":\" \"},{\"nodeType\":1,\"id\":584,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":585,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":586,\"textContent\":\" \"},{\"nodeType\":1,\"id\":587,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":588,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":589,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":590,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":591,\"textContent\":\" \"},{\"nodeType\":1,\"id\":592,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":593,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":594,\"textContent\":\" \"},{\"nodeType\":1,\"id\":595,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":596,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":597,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":598,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":599,\"textContent\":\" \"},{\"nodeType\":1,\"id\":600,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":601,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":602,\"textContent\":\" \"},{\"nodeType\":1,\"id\":603,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":604,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":605,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":606,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":607,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":608,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":609,\"textContent\":\" \"},{\"nodeType\":1,\"id\":610,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"acme\",\"id\":\"acme.midpoint\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":611,\"textContent\":\" \"},{\"nodeType\":1,\"id\":612,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":613,\"textContent\":\"Coffee breaks happen halfway through a shift.\"},{\"nodeType\":1,\"id\":614,\"tagName\":\"BR\",\"attributes\":{}},{\"nodeType\":3,\"id\":615,\"textContent\":\" Which shift(s) share a break with I?\"}]},{\"nodeType\":3,\"id\":616,\"textContent\":\" \"},{\"nodeType\":1,\"id\":617,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":618,\"textContent\":\" \"},{\"nodeType\":1,\"id\":619,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":620,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":621,\"textContent\":\" \"},{\"nodeType\":1,\"id\":622,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":623,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":624,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":625,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":626,\"textContent\":\" \"},{\"nodeType\":1,\"id\":627,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":628,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":629,\"textContent\":\" \"},{\"nodeType\":1,\"id\":630,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":631,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":632,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":633,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":634,\"textContent\":\" \"},{\"nodeType\":1,\"id\":635,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":636,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":637,\"textContent\":\" \"},{\"nodeType\":1,\"id\":638,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":639,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":640,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":641,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":642,\"textContent\":\" \"},{\"nodeType\":1,\"id\":643,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":644,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":645,\"textContent\":\" \"},{\"nodeType\":1,\"id\":646,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":647,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":648,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":649,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":650,\"textContent\":\" \"},{\"nodeType\":1,\"id\":651,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":652,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":653,\"textContent\":\" \"},{\"nodeType\":1,\"id\":654,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":655,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":656,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":657,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":658,\"textContent\":\" \"},{\"nodeType\":1,\"id\":659,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":660,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":661,\"textContent\":\" \"},{\"nodeType\":1,\"id\":662,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":663,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":664,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":665,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":666,\"textContent\":\" \"},{\"nodeType\":1,\"id\":667,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":668,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":669,\"textContent\":\" \"},{\"nodeType\":1,\"id\":670,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":671,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":672,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":673,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":674,\"textContent\":\" \"},{\"nodeType\":1,\"id\":675,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":676,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":677,\"textContent\":\" \"},{\"nodeType\":1,\"id\":678,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":679,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":680,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":681,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":682,\"textContent\":\" \"},{\"nodeType\":1,\"id\":683,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":684,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":685,\"textContent\":\" \"},{\"nodeType\":1,\"id\":686,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":687,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":688,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":689,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":690,\"textContent\":\" \"},{\"nodeType\":1,\"id\":691,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":692,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":693,\"textContent\":\" \"},{\"nodeType\":1,\"id\":694,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":695,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":696,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":697,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":698,\"textContent\":\" \"},{\"nodeType\":1,\"id\":699,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":700,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":701,\"textContent\":\" \"},{\"nodeType\":1,\"id\":702,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"U\",\"value\":\"\"}},{\"nodeType\":3,\"id\":703,\"textContent\":\"U \"},{\"nodeType\":1,\"id\":704,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":705,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":706,\"textContent\":\" \"},{\"nodeType\":1,\"id\":707,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":708,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":709,\"textContent\":\" \"},{\"nodeType\":1,\"id\":710,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":711,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":712,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":713,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":714,\"textContent\":\" \"},{\"nodeType\":1,\"id\":715,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":716,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":717,\"textContent\":\" \"},{\"nodeType\":1,\"id\":718,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":719,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":720,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":721,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":722,\"textContent\":\" \"},{\"nodeType\":1,\"id\":723,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":724,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":725,\"textContent\":\" \"},{\"nodeType\":1,\"id\":726,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":727,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":728,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":729,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":730,\"textContent\":\" \"},{\"nodeType\":1,\"id\":731,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":732,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":733,\"textContent\":\" \"},{\"nodeType\":1,\"id\":734,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":735,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":736,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":737,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":738,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":739,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":740,\"textContent\":\" \"},{\"nodeType\":1,\"id\":741,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.duration\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":742,\"textContent\":\" \"},{\"nodeType\":1,\"id\":743,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":744,\"textContent\":\"Which shift(s) are six hours long?\"}]},{\"nodeType\":3,\"id\":745,\"textContent\":\" \"},{\"nodeType\":1,\"id\":746,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":747,\"textContent\":\" \"},{\"nodeType\":1,\"id\":748,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":749,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":750,\"textContent\":\" \"},{\"nodeType\":1,\"id\":751,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":752,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":753,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":754,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":755,\"textContent\":\" \"},{\"nodeType\":1,\"id\":756,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":757,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":758,\"textContent\":\" \"},{\"nodeType\":1,\"id\":759,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":760,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":761,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":762,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":763,\"textContent\":\" \"},{\"nodeType\":1,\"id\":764,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":765,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":766,\"textContent\":\" \"},{\"nodeType\":1,\"id\":767,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":768,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":769,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":770,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":771,\"textContent\":\" \"},{\"nodeType\":1,\"id\":772,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":773,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":774,\"textContent\":\" \"},{\"nodeType\":1,\"id\":775,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":776,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":777,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":778,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":779,\"textContent\":\" \"},{\"nodeType\":1,\"id\":780,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":781,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":782,\"textContent\":\" \"},{\"nodeType\":1,\"id\":783,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":784,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":785,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":786,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":787,\"textContent\":\" \"},{\"nodeType\":1,\"id\":788,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":789,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":790,\"textContent\":\" \"},{\"nodeType\":1,\"id\":791,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":792,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":793,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":794,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":795,\"textContent\":\" \"},{\"nodeType\":1,\"id\":796,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":797,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":798,\"textContent\":\" \"},{\"nodeType\":1,\"id\":799,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":800,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":801,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":802,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":803,\"textContent\":\" \"},{\"nodeType\":1,\"id\":804,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":805,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":806,\"textContent\":\" \"},{\"nodeType\":1,\"id\":807,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":808,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":809,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":810,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":811,\"textContent\":\" \"},{\"nodeType\":1,\"id\":812,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":813,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":814,\"textContent\":\" \"},{\"nodeType\":1,\"id\":815,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":816,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":817,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":818,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":819,\"textContent\":\" \"},{\"nodeType\":1,\"id\":820,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":821,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":822,\"textContent\":\" \"},{\"nodeType\":1,\"id\":823,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":824,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":825,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":826,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":827,\"textContent\":\" \"},{\"nodeType\":1,\"id\":828,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":829,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":830,\"textContent\":\" \"},{\"nodeType\":1,\"id\":831,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":832,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":833,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":834,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":835,\"textContent\":\" \"},{\"nodeType\":1,\"id\":836,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":837,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":838,\"textContent\":\" \"},{\"nodeType\":1,\"id\":839,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":840,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":841,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":842,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":843,\"textContent\":\" \"},{\"nodeType\":1,\"id\":844,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":845,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":846,\"textContent\":\" \"},{\"nodeType\":1,\"id\":847,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":848,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":849,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":850,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":851,\"textContent\":\" \"},{\"nodeType\":1,\"id\":852,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":853,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":854,\"textContent\":\" \"},{\"nodeType\":1,\"id\":855,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":856,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":857,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":858,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":859,\"textContent\":\" \"},{\"nodeType\":1,\"id\":860,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":861,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":862,\"textContent\":\" \"},{\"nodeType\":1,\"id\":863,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":864,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":865,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":866,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":867,\"textContent\":\" \"},{\"nodeType\":1,\"id\":868,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":869,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":870,\"textContent\":\" \"},{\"nodeType\":1,\"id\":871,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":872,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":873,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":874,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":875,\"textContent\":\" \"},{\"nodeType\":1,\"id\":876,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":877,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":878,\"textContent\":\" \"},{\"nodeType\":1,\"id\":879,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":880,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":881,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":882,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":883,\"textContent\":\" \"},{\"nodeType\":1,\"id\":884,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":885,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":886,\"textContent\":\" \"},{\"nodeType\":1,\"id\":887,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":888,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":889,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":890,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":891,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":892,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":893,\"textContent\":\" \"},{\"nodeType\":1,\"id\":894,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.duration+starts\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":895,\"textContent\":\" \"},{\"nodeType\":1,\"id\":896,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":897,\"textContent\":\"Which 2 shifts less than 5 hours long start at the same time?\"}]},{\"nodeType\":3,\"id\":898,\"textContent\":\" \"},{\"nodeType\":1,\"id\":899,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":900,\"textContent\":\" \"},{\"nodeType\":1,\"id\":901,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":902,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":903,\"textContent\":\" \"},{\"nodeType\":1,\"id\":904,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":905,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":906,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":907,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":908,\"textContent\":\" \"},{\"nodeType\":1,\"id\":909,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":910,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":911,\"textContent\":\" \"},{\"nodeType\":1,\"id\":912,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":913,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":914,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":915,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":916,\"textContent\":\" \"},{\"nodeType\":1,\"id\":917,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":918,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":919,\"textContent\":\" \"},{\"nodeType\":1,\"id\":920,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":921,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":922,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":923,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":924,\"textContent\":\" \"},{\"nodeType\":1,\"id\":925,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":926,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":927,\"textContent\":\" \"},{\"nodeType\":1,\"id\":928,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":929,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":930,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":931,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":932,\"textContent\":\" \"},{\"nodeType\":1,\"id\":933,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":934,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":935,\"textContent\":\" \"},{\"nodeType\":1,\"id\":936,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":937,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":938,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":939,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":940,\"textContent\":\" \"},{\"nodeType\":1,\"id\":941,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":942,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":943,\"textContent\":\" \"},{\"nodeType\":1,\"id\":944,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":945,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":946,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":947,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":948,\"textContent\":\" \"},{\"nodeType\":1,\"id\":949,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":950,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":951,\"textContent\":\" \"},{\"nodeType\":1,\"id\":952,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":953,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":954,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":955,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":956,\"textContent\":\" \"},{\"nodeType\":1,\"id\":957,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":958,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":959,\"textContent\":\" \"},{\"nodeType\":1,\"id\":960,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":961,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":962,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":963,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":964,\"textContent\":\" \"},{\"nodeType\":1,\"id\":965,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":966,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":967,\"textContent\":\" \"},{\"nodeType\":1,\"id\":968,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":969,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":970,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":971,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":972,\"textContent\":\" \"},{\"nodeType\":1,\"id\":973,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":974,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":975,\"textContent\":\" \"},{\"nodeType\":1,\"id\":976,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":977,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":978,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":979,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":980,\"textContent\":\" \"},{\"nodeType\":1,\"id\":981,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":982,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":983,\"textContent\":\" \"},{\"nodeType\":1,\"id\":984,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":985,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":986,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":987,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":988,\"textContent\":\" \"},{\"nodeType\":1,\"id\":989,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":990,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":991,\"textContent\":\" \"},{\"nodeType\":1,\"id\":992,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":993,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":994,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":995,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":996,\"textContent\":\" \"},{\"nodeType\":1,\"id\":997,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":998,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":999,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1000,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1001,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":1002,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1003,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1004,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1005,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1006,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1007,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1008,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1009,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":1010,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1011,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1012,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1013,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1014,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1015,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1016,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1017,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":1018,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1019,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1020,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1021,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1022,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1023,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1024,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1025,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":1026,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1027,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1028,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1029,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1030,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1031,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1032,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1033,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":1034,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1035,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1036,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1037,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1038,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1039,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1040,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1041,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":1042,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1043,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1044,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1045,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1046,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1047,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.duration+contained\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":1048,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1049,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":1050,\"textContent\":\"Which shift(s) under 7 hours long starts before B starts, and ends after X ends?\"}]},{\"nodeType\":3,\"id\":1051,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1052,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":1053,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1054,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1055,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1056,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1057,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1058,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":1059,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1060,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1061,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1062,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1063,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1064,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1065,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1066,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":1067,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1068,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1069,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1070,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1071,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1072,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1073,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1074,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":1075,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1076,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1077,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1078,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1079,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1080,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1081,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1082,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":1083,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1084,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1085,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1086,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1087,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1088,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1089,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1090,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":1091,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1092,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1093,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1094,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1095,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1096,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1097,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1098,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":1099,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1100,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1101,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1102,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1103,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1104,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1105,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1106,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":1107,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1108,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1109,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1110,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1111,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1112,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1113,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1114,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":1115,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1116,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1117,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1118,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1119,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1120,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1121,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1122,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":1123,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1124,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1125,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1126,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1127,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1128,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1129,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1130,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":1131,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1132,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1133,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1134,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1135,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1136,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1137,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1138,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":1139,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1140,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1141,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1142,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1143,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1144,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1145,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1146,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":1147,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1148,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1149,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1150,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1151,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1152,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1153,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1154,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":1155,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1156,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1157,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1158,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1159,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1160,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1161,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1162,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":1163,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1164,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1165,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1166,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1167,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1168,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1169,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1170,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":1171,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1172,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1173,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1174,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1175,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1176,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1177,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1178,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":1179,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1180,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1181,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1182,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1183,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1184,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1185,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1186,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":1187,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1188,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1189,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1190,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1191,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1192,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1193,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1194,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":1195,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1196,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1197,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1198,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1199,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1200,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.starttime+before+endtime+during\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":1201,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1202,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":1203,\"textContent\":\"Which shift(s) begins before J begins and ends during B?\"}]},{\"nodeType\":3,\"id\":1204,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1205,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":1206,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1207,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1208,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1209,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1210,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1211,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":1212,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1213,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1214,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1215,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1216,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1217,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1218,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1219,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":1220,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1221,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1222,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1223,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1224,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1225,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1226,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1227,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":1228,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1229,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1230,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1231,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1232,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1233,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1234,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1235,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":1236,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1237,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1238,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1239,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1240,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1241,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1242,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1243,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":1244,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1245,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1246,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1247,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1248,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1249,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1250,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1251,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":1252,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1253,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1254,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1255,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1256,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1257,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1258,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1259,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":1260,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1261,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1262,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1263,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1264,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1265,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1266,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1267,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":1268,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1269,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1270,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1271,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1272,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1273,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1274,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1275,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":1276,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1277,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1278,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1279,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1280,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1281,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1282,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1283,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":1284,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1285,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1286,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1287,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1288,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1289,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1290,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1291,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":1292,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1293,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1294,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1295,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1296,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1297,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1298,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1299,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":1300,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1301,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1302,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1303,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1304,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1305,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1306,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1307,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":1308,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1309,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1310,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1311,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1312,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1313,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1314,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1315,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":1316,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1317,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1318,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1319,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1320,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1321,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1322,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1323,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":1324,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1325,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1326,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1327,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1328,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1329,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1330,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1331,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":1332,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1333,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1334,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1335,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1336,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1337,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1338,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1339,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":1340,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1341,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1342,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1343,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1344,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1345,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1346,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1347,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":1348,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1349,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1350,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1351,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1352,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1353,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.ends\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":1354,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1355,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":1356,\"textContent\":\"Which shift(s) end at the same time as F?\"}]},{\"nodeType\":3,\"id\":1357,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1358,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":1359,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1360,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1361,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1362,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1363,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1364,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":1365,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1366,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1367,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1368,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1369,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1370,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1371,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1372,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":1373,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1374,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1375,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1376,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1377,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1378,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1379,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1380,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":1381,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1382,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1383,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1384,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1385,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1386,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1387,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1388,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":1389,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1390,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1391,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1392,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1393,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1394,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1395,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1396,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":1397,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1398,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1399,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1400,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1401,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1402,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1403,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1404,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":1405,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1406,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1407,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1408,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1409,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1410,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1411,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1412,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":1413,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1414,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1415,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1416,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1417,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1418,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1419,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1420,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":1421,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1422,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1423,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1424,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1425,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1426,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1427,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1428,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":1429,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1430,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1431,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1432,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1433,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1434,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1435,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1436,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":1437,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1438,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1439,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1440,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1441,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1442,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1443,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1444,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":1445,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1446,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1447,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1448,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1449,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1450,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1451,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1452,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":1453,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1454,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1455,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1456,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1457,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1458,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1459,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1460,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":1461,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1462,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1463,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1464,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1465,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1466,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1467,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1468,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":1469,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1470,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1471,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1472,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1473,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1474,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1475,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1476,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":1477,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1478,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1479,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1480,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1481,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1482,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1483,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1484,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":1485,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1486,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1487,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1488,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1489,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1490,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1491,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1492,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":1493,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1494,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1495,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1496,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1497,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1498,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1499,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1500,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":1501,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1502,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1503,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1504,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1505,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1506,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.starttime\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":1507,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1508,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":1509,\"textContent\":\"Which shift(s) start at 12pm?\"}]},{\"nodeType\":3,\"id\":1510,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1511,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":1512,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1513,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1514,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1515,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1516,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1517,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":1518,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1519,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1520,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1521,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1522,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1523,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1524,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1525,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":1526,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1527,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1528,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1529,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1530,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1531,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1532,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1533,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":1534,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1535,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1536,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1537,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1538,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1539,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1540,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1541,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":1542,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1543,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1544,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1545,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1546,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1547,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1548,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1549,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":1550,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1551,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1552,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1553,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1554,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1555,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1556,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1557,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":1558,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1559,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1560,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1561,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1562,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1563,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1564,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1565,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":1566,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1567,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1568,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1569,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1570,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1571,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1572,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1573,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":1574,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1575,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1576,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1577,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1578,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1579,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1580,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1581,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":1582,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1583,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1584,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1585,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1586,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1587,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1588,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1589,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":1590,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1591,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1592,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1593,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1594,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1595,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1596,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1597,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":1598,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1599,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1600,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1601,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1602,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1603,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1604,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1605,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":1606,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1607,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1608,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1609,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1610,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1611,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1612,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1613,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":1614,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1615,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1616,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1617,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1618,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1619,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1620,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1621,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":1622,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1623,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1624,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1625,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1626,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1627,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1628,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1629,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":1630,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1631,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1632,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1633,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1634,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1635,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1636,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1637,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":1638,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1639,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1640,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1641,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1642,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1643,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1644,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1645,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":1646,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1647,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1648,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1649,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1650,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1651,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1652,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1653,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":1654,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1655,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1656,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1657,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1658,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1659,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.starts\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":1660,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1661,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":1662,\"textContent\":\"Which shift(s) start at the same time as F?\"}]},{\"nodeType\":3,\"id\":1663,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1664,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":1665,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1666,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1667,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1668,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1669,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1670,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":1671,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1672,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1673,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1674,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1675,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1676,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1677,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1678,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":1679,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1680,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1681,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1682,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1683,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1684,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1685,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1686,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":1687,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1688,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1689,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1690,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1691,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1692,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1693,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1694,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":1695,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1696,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1697,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1698,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1699,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1700,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1701,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1702,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":1703,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1704,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1705,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1706,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1707,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1708,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1709,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1710,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":1711,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1712,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1713,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1714,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1715,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1716,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1717,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1718,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":1719,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1720,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1721,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1722,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1723,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1724,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1725,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1726,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":1727,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1728,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1729,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1730,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1731,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1732,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1733,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1734,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":1735,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1736,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1737,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1738,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1739,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1740,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1741,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1742,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":1743,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1744,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1745,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1746,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1747,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1748,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1749,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1750,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":1751,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1752,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1753,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1754,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1755,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1756,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1757,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1758,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":1759,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1760,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1761,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1762,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1763,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1764,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1765,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1766,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":1767,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1768,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1769,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1770,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1771,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1772,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1773,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1774,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":1775,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1776,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1777,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1778,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1779,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1780,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1781,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1782,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":1783,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1784,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1785,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1786,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1787,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1788,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1789,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1790,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":1791,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1792,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1793,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1794,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1795,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1796,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1797,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1798,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":1799,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1800,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1801,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1802,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1803,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1804,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1805,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1806,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":1807,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1808,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1809,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1810,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1811,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1812,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.meets\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":1813,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1814,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":1815,\"textContent\":\"Which 2 shifts end when Z begins?\"}]},{\"nodeType\":3,\"id\":1816,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1817,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":1818,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1819,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1820,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1821,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1822,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1823,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":1824,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1825,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1826,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1827,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1828,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1829,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1830,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1831,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":1832,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1833,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1834,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1835,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1836,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1837,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1838,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1839,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":1840,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1841,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1842,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1843,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1844,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1845,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1846,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1847,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":1848,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1849,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1850,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1851,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1852,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1853,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1854,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1855,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":1856,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1857,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1858,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1859,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1860,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1861,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1862,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1863,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":1864,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1865,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1866,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1867,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1868,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1869,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1870,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1871,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":1872,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1873,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1874,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1875,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1876,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1877,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1878,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1879,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":1880,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1881,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1882,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1883,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1884,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1885,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1886,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1887,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":1888,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1889,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1890,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1891,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1892,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1893,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1894,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1895,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":1896,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1897,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1898,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1899,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1900,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1901,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1902,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1903,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":1904,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1905,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1906,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1907,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1908,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1909,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1910,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1911,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":1912,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1913,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1914,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1915,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1916,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1917,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1918,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1919,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":1920,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1921,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1922,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1923,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1924,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1925,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1926,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1927,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":1928,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1929,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1930,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1931,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1932,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1933,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1934,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1935,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":1936,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1937,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1938,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1939,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1940,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1941,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1942,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1943,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":1944,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1945,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1946,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1947,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1948,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1949,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1950,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1951,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":1952,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1953,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1954,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1955,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1956,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1957,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1958,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1959,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":1960,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1961,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1962,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1963,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1964,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1965,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.endtime\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":1966,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1967,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":1968,\"textContent\":\"Which shift(s) end at 3pm?\"}]},{\"nodeType\":3,\"id\":1969,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1970,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":1971,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1972,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1973,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1974,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1975,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1976,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":1977,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1978,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1979,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1980,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1981,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1982,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1983,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1984,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":1985,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1986,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1987,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1988,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1989,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1990,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1991,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1992,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":1993,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1994,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1995,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1996,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1997,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1998,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1999,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2000,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":2001,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2002,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2003,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2004,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2005,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2006,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2007,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2008,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":2009,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2010,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2011,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2012,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2013,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2014,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2015,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2016,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":2017,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2018,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2019,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2020,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2021,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2022,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2023,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2024,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":2025,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2026,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2027,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2028,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2029,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2030,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2031,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2032,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":2033,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2034,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2035,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2036,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2037,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2038,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2039,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2040,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":2041,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2042,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2043,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2044,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2045,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2046,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2047,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2048,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":2049,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2050,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2051,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2052,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2053,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2054,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2055,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2056,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":2057,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2058,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2059,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2060,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2061,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2062,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2063,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2064,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":2065,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2066,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2067,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2068,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2069,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2070,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2071,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2072,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":2073,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2074,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2075,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2076,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2077,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2078,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2079,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2080,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":2081,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2082,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2083,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2084,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2085,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2086,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2087,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2088,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":2089,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2090,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2091,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2092,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2093,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2094,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2095,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2096,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":2097,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2098,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2099,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2100,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2101,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2102,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2103,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2104,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":2105,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2106,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2107,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2108,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2109,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2110,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2111,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2112,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":2113,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2114,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2115,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2116,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2117,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2118,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.midpoint\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":2119,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2120,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":2121,\"textContent\":\"Coffee breaks happen halfway through a shift. \"},{\"nodeType\":1,\"id\":2122,\"tagName\":\"BR\",\"attributes\":{}},{\"nodeType\":3,\"id\":2123,\"textContent\":\"Which shifts share a break at 2pm?\"}]},{\"nodeType\":3,\"id\":2124,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2125,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":2126,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2127,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2128,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2129,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2130,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2131,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":2132,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2133,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2134,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2135,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2136,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2137,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2138,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2139,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":2140,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2141,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2142,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2143,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2144,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2145,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2146,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2147,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":2148,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2149,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2150,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2151,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2152,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2153,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2154,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2155,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":2156,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2157,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2158,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2159,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2160,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2161,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2162,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2163,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":2164,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2165,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2166,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2167,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2168,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2169,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2170,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2171,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":2172,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2173,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2174,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2175,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2176,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2177,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2178,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2179,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":2180,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2181,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2182,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2183,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2184,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2185,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2186,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2187,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":2188,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2189,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2190,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2191,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2192,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2193,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2194,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2195,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":2196,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2197,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2198,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2199,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2200,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2201,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2202,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2203,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":2204,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2205,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2206,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2207,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2208,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2209,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2210,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2211,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":2212,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2213,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2214,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2215,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2216,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2217,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2218,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2219,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":2220,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2221,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2222,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2223,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2224,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2225,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2226,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2227,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":2228,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2229,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2230,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2231,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2232,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2233,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2234,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2235,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":2236,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2237,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2238,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2239,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2240,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2241,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2242,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2243,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":2244,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2245,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2246,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2247,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2248,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2249,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2250,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2251,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":2252,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2253,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2254,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2255,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2256,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2257,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2258,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2259,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":2260,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2261,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2262,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2263,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2264,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2265,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2266,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2267,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":2268,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2269,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2270,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2271,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2272,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2273,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\".strategy\",\"style\":\"display: block;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2274,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2275,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":2276,\"textContent\":\"Please describe how to determine what event(s) start at 12pm?\"}]},{\"nodeType\":3,\"id\":2277,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2278,\"tagName\":\"TEXTAREA\",\"attributes\":{\"id\":\"strategyAnswer\",\"rows\":\"5\",\"cols\":\"80\"}},{\"nodeType\":3,\"id\":2279,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2280,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2281,\"textContent\":\" \"},{\"nodeType\":8,\"id\":2282},{\"nodeType\":3,\"id\":2283,\"textContent\":\" \"},{\"nodeType\":8,\"id\":2284},{\"nodeType\":3,\"id\":2285,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2286,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"fixbottom\"},\"childNodes\":[{\"nodeType\":3,\"id\":2287,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2288,\"tagName\":\"BUTTON\",\"attributes\":{\"type\":\"button\",\"id\":\"testingButton\",\"style\":\"display:none;\",\"class\":\"btn\"},\"childNodes\":[{\"nodeType\":3,\"id\":2289,\"textContent\":\"SUBMIT\"}]},{\"nodeType\":3,\"id\":2290,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2291,\"tagName\":\"BUTTON\",\"attributes\":{\"type\":\"button\",\"id\":\"strategyButton\",\"style\":\"display: block;\",\"class\":\"btn\"},\"childNodes\":[{\"nodeType\":3,\"id\":2292,\"textContent\":\"SUBMIT\"}]},{\"nodeType\":3,\"id\":2293,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2294,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2295,\"textContent\":\" \"},{\"nodeType\":8,\"id\":2296},{\"nodeType\":3,\"id\":2297,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2298,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"d3container\"},\"childNodes\":[{\"nodeType\":1,\"id\":2299,\"tagName\":\"svg\",\"attributes\":{\"width\":\"930\",\"height\":\"915\"},\"childNodes\":[{\"nodeType\":1,\"id\":2300,\"tagName\":\"g\",\"attributes\":{\"transform\":\"translate(100,25)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2301,\"tagName\":\"g\",\"attributes\":{\"class\":\"leaders\"}},{\"nodeType\":1,\"id\":2302,\"tagName\":\"g\",\"attributes\":{\"class\":\"static-scaffold\"}},{\"nodeType\":1,\"id\":2303,\"tagName\":\"g\",\"attributes\":{\"class\":\"xaxis\",\"transform\":\"translate(0,800)\",\"fill\":\"none\",\"font-size\":\"10\",\"font-family\":\"sans-serif\",\"text-anchor\":\"middle\"},\"childNodes\":[{\"nodeType\":1,\"id\":2304,\"tagName\":\"path\",\"attributes\":{\"class\":\"domain\",\"stroke\":\"#000\",\"d\":\"M0.5,6V0.5H800.5V6\"}},{\"nodeType\":1,\"id\":2305,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0.5,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2306,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2307,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2308,\"textContent\":\"08 AM\"}]}]},{\"nodeType\":1,\"id\":2309,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(33.83333333333333,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2310,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2311,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2312,\"textContent\":\"08:30\"}]}]},{\"nodeType\":1,\"id\":2313,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(67.16666666666666,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2314,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2315,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2316,\"textContent\":\"09 AM\"}]}]},{\"nodeType\":1,\"id\":2317,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(100.5,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2318,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2319,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2320,\"textContent\":\"09:30\"}]}]},{\"nodeType\":1,\"id\":2321,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(133.83333333333331,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2322,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2323,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2324,\"textContent\":\"10 AM\"}]}]},{\"nodeType\":1,\"id\":2325,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(167.16666666666669,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2326,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2327,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2328,\"textContent\":\"10:30\"}]}]},{\"nodeType\":1,\"id\":2329,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(200.5,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2330,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2331,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2332,\"textContent\":\"11 AM\"}]}]},{\"nodeType\":1,\"id\":2333,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(233.83333333333334,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2334,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2335,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2336,\"textContent\":\"11:30\"}]}]},{\"nodeType\":1,\"id\":2337,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(267.16666666666663,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2338,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2339,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2340,\"textContent\":\"12 PM\"}]}]},{\"nodeType\":1,\"id\":2341,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(300.5,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2342,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2343,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2344,\"textContent\":\"12:30\"}]}]},{\"nodeType\":1,\"id\":2345,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(333.83333333333337,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2346,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2347,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2348,\"textContent\":\"01 PM\"}]}]},{\"nodeType\":1,\"id\":2349,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(367.16666666666663,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2350,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2351,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2352,\"textContent\":\"01:30\"}]}]},{\"nodeType\":1,\"id\":2353,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(400.5,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2354,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2355,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2356,\"textContent\":\"02 PM\"}]}]},{\"nodeType\":1,\"id\":2357,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(433.8333333333333,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2358,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2359,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2360,\"textContent\":\"02:30\"}]}]},{\"nodeType\":1,\"id\":2361,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(467.1666666666667,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2362,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2363,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2364,\"textContent\":\"03 PM\"}]}]},{\"nodeType\":1,\"id\":2365,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(500.5,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2366,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2367,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2368,\"textContent\":\"03:30\"}]}]},{\"nodeType\":1,\"id\":2369,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(533.8333333333333,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2370,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2371,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2372,\"textContent\":\"04 PM\"}]}]},{\"nodeType\":1,\"id\":2373,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(567.1666666666667,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2374,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2375,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2376,\"textContent\":\"04:30\"}]}]},{\"nodeType\":1,\"id\":2377,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(600.5,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2378,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2379,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2380,\"textContent\":\"05 PM\"}]}]},{\"nodeType\":1,\"id\":2381,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(633.8333333333333,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2382,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2383,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2384,\"textContent\":\"05:30\"}]}]},{\"nodeType\":1,\"id\":2385,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(667.1666666666667,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2386,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2387,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2388,\"textContent\":\"06 PM\"}]}]},{\"nodeType\":1,\"id\":2389,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(700.5,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2390,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2391,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2392,\"textContent\":\"06:30\"}]}]},{\"nodeType\":1,\"id\":2393,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(733.8333333333333,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2394,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2395,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2396,\"textContent\":\"07 PM\"}]}]},{\"nodeType\":1,\"id\":2397,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(767.1666666666667,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2398,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2399,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2400,\"textContent\":\"07:30\"}]}]},{\"nodeType\":1,\"id\":2401,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(800.5,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2402,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2403,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2404,\"textContent\":\"08 PM\"}]}]},{\"nodeType\":1,\"id\":2405,\"tagName\":\"g\",\"attributes\":{\"class\":\"axisTitle\"},\"childNodes\":[{\"nodeType\":1,\"id\":2406,\"tagName\":\"text\",\"attributes\":{\"x\":\"533.3333333333334\",\"y\":\"80\",\"style\":\"text-anchor: end;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2407,\"textContent\":\"START & END TIME (time of day)\"}]}]}]},{\"nodeType\":1,\"id\":2408,\"tagName\":\"g\",\"attributes\":{\"class\":\"yaxis\",\"fill\":\"none\",\"font-size\":\"10\",\"font-family\":\"sans-serif\",\"text-anchor\":\"end\"},\"childNodes\":[{\"nodeType\":1,\"id\":2409,\"tagName\":\"path\",\"attributes\":{\"class\":\"domain\",\"stroke\":\"#000\",\"d\":\"M-15,800.5H0.5V0.5H-15\"}},{\"nodeType\":1,\"id\":2410,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,800.5)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2411,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2412,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2413,\"textContent\":\"0\"}]}]},{\"nodeType\":1,\"id\":2414,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,733.8333333333334)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2415,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2416,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2417,\"textContent\":\"1\"}]}]},{\"nodeType\":1,\"id\":2418,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,667.1666666666667)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2419,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2420,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2421,\"textContent\":\"2\"}]}]},{\"nodeType\":1,\"id\":2422,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,600.5)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2423,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2424,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2425,\"textContent\":\"3\"}]}]},{\"nodeType\":1,\"id\":2426,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,533.8333333333334)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2427,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2428,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2429,\"textContent\":\"4\"}]}]},{\"nodeType\":1,\"id\":2430,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,467.16666666666663)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2431,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2432,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2433,\"textContent\":\"5\"}]}]},{\"nodeType\":1,\"id\":2434,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,400.5)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2435,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2436,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2437,\"textContent\":\"6\"}]}]},{\"nodeType\":1,\"id\":2438,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,333.8333333333333)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2439,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2440,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2441,\"textContent\":\"7\"}]}]},{\"nodeType\":1,\"id\":2442,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,267.16666666666674)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2443,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2444,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2445,\"textContent\":\"8\"}]}]},{\"nodeType\":1,\"id\":2446,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,200.5)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2447,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2448,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2449,\"textContent\":\"9\"}]}]},{\"nodeType\":1,\"id\":2450,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,133.83333333333326)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2451,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2452,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2453,\"textContent\":\"10\"}]}]},{\"nodeType\":1,\"id\":2454,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,67.16666666666674)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2455,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2456,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2457,\"textContent\":\"11\"}]}]},{\"nodeType\":1,\"id\":2458,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,0.5)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2459,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2460,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2461,\"textContent\":\"12\"}]}]},{\"nodeType\":1,\"id\":2462,\"tagName\":\"g\",\"attributes\":{\"class\":\"axisTitle\"},\"childNodes\":[{\"nodeType\":1,\"id\":2463,\"tagName\":\"text\",\"attributes\":{\"transform\":\"rotate(-90)\",\"x\":\"-350\",\"y\":\"-60\",\"style\":\"text-anchor: end;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2464,\"textContent\":\"DURATION (in hours)\"}]}]}]},{\"nodeType\":1,\"id\":2465,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2466,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2467,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"733.3333333333334\",\"y2\":\"733.3333333333334\"}}]},{\"nodeType\":1,\"id\":2468,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2469,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"666.6666666666667\",\"y2\":\"666.6666666666667\"}}]},{\"nodeType\":1,\"id\":2470,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2471,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"600\",\"y2\":\"600\"}}]},{\"nodeType\":1,\"id\":2472,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2473,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"533.3333333333334\",\"y2\":\"533.3333333333334\"}}]},{\"nodeType\":1,\"id\":2474,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2475,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"466.66666666666663\",\"y2\":\"466.66666666666663\"}}]},{\"nodeType\":1,\"id\":2476,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2477,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"400\",\"y2\":\"400\"}}]},{\"nodeType\":1,\"id\":2478,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2479,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"333.3333333333333\",\"y2\":\"333.3333333333333\"}}]},{\"nodeType\":1,\"id\":2480,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2481,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"266.66666666666674\",\"y2\":\"266.66666666666674\"}}]},{\"nodeType\":1,\"id\":2482,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2483,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"200\",\"y2\":\"200\"}}]},{\"nodeType\":1,\"id\":2484,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2485,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"133.33333333333326\",\"y2\":\"133.33333333333326\"}}]},{\"nodeType\":1,\"id\":2486,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2487,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"66.66666666666674\",\"y2\":\"66.66666666666674\"}}]},{\"nodeType\":1,\"id\":2488,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2489,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"0\",\"y2\":\"0\"}}]}]},{\"nodeType\":1,\"id\":2490,\"tagName\":\"g\",\"attributes\":{\"class\":\"xgrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2491,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"0\",\"y1\":\"800\",\"x2\":\"400\",\"y2\":\"0\"}},{\"nodeType\":1,\"id\":2492,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"800\",\"y1\":\"800\",\"x2\":\"400\",\"y2\":\"0\"}},{\"nodeType\":1,\"id\":2493,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"66.66666666666666\",\"y1\":\"800\",\"x2\":\"433.3333333333333\",\"y2\":\"66.66666666666674\"}},{\"nodeType\":1,\"id\":2494,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"733.3333333333333\",\"y1\":\"800\",\"x2\":\"366.66666666666663\",\"y2\":\"66.66666666666674\"}},{\"nodeType\":1,\"id\":2495,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"133.33333333333331\",\"y1\":\"800\",\"x2\":\"466.6666666666667\",\"y2\":\"133.33333333333326\"}},{\"nodeType\":1,\"id\":2496,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"666.6666666666667\",\"y1\":\"800\",\"x2\":\"333.33333333333337\",\"y2\":\"133.33333333333326\"}},{\"nodeType\":1,\"id\":2497,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"200\",\"y1\":\"800\",\"x2\":\"500\",\"y2\":\"200\"}},{\"nodeType\":1,\"id\":2498,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"600\",\"y1\":\"800\",\"x2\":\"300\",\"y2\":\"200\"}},{\"nodeType\":1,\"id\":2499,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"266.66666666666663\",\"y1\":\"800\",\"x2\":\"533.3333333333333\",\"y2\":\"266.66666666666674\"}},{\"nodeType\":1,\"id\":2500,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"533.3333333333333\",\"y1\":\"800\",\"x2\":\"266.66666666666663\",\"y2\":\"266.66666666666674\"}},{\"nodeType\":1,\"id\":2501,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"333.33333333333337\",\"y1\":\"800\",\"x2\":\"566.6666666666667\",\"y2\":\"333.3333333333333\"}},{\"nodeType\":1,\"id\":2502,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"466.6666666666667\",\"y1\":\"800\",\"x2\":\"233.33333333333334\",\"y2\":\"333.3333333333333\"}},{\"nodeType\":1,\"id\":2503,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"400\",\"y1\":\"800\",\"x2\":\"600\",\"y2\":\"400\"}},{\"nodeType\":1,\"id\":2504,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"400\",\"y1\":\"800\",\"x2\":\"200\",\"y2\":\"400\"}},{\"nodeType\":1,\"id\":2505,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"466.6666666666667\",\"y1\":\"800\",\"x2\":\"633.3333333333333\",\"y2\":\"466.66666666666663\"}},{\"nodeType\":1,\"id\":2506,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"333.33333333333337\",\"y1\":\"800\",\"x2\":\"166.66666666666669\",\"y2\":\"466.66666666666663\"}},{\"nodeType\":1,\"id\":2507,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"533.3333333333333\",\"y1\":\"800\",\"x2\":\"666.6666666666667\",\"y2\":\"533.3333333333334\"}},{\"nodeType\":1,\"id\":2508,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"266.66666666666663\",\"y1\":\"800\",\"x2\":\"133.33333333333331\",\"y2\":\"533.3333333333334\"}},{\"nodeType\":1,\"id\":2509,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"600\",\"y1\":\"800\",\"x2\":\"700\",\"y2\":\"600\"}},{\"nodeType\":1,\"id\":2510,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"200\",\"y1\":\"800\",\"x2\":\"100\",\"y2\":\"600\"}},{\"nodeType\":1,\"id\":2511,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"666.6666666666667\",\"y1\":\"800\",\"x2\":\"733.3333333333333\",\"y2\":\"666.6666666666667\"}},{\"nodeType\":1,\"id\":2512,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"133.33333333333331\",\"y1\":\"800\",\"x2\":\"66.66666666666666\",\"y2\":\"666.6666666666667\"}},{\"nodeType\":1,\"id\":2513,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"733.3333333333333\",\"y1\":\"800\",\"x2\":\"766.6666666666667\",\"y2\":\"733.3333333333334\"}},{\"nodeType\":1,\"id\":2514,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"66.66666666666666\",\"y1\":\"800\",\"x2\":\"33.33333333333333\",\"y2\":\"733.3333333333334\"}}]},{\"nodeType\":1,\"id\":2515,\"tagName\":\"g\",\"attributes\":{\"class\":\"data\"},\"childNodes\":[{\"nodeType\":1,\"id\":2516,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2517,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"333.33333333333337\",\"cy\":\"266.66666666666674\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2518,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"328.33333333333337\",\"y\":\"258.66666666666674\"},\"childNodes\":[{\"nodeType\":3,\"id\":2519,\"textContent\":\"A \"}]}]},{\"nodeType\":1,\"id\":2520,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2521,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"266.66666666666663\",\"cy\":\"600\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2522,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"261.66666666666663\",\"y\":\"592\"},\"childNodes\":[{\"nodeType\":3,\"id\":2523,\"textContent\":\"B \"}]}]},{\"nodeType\":1,\"id\":2524,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2525,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"366.66666666666663\",\"cy\":\"466.66666666666663\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2526,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"361.66666666666663\",\"y\":\"458.66666666666663\"},\"childNodes\":[{\"nodeType\":3,\"id\":2527,\"textContent\":\"C \"}]}]},{\"nodeType\":1,\"id\":2528,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2529,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"666.6666666666667\",\"cy\":\"666.6666666666667\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2530,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"661.6666666666667\",\"y\":\"658.6666666666667\"},\"childNodes\":[{\"nodeType\":3,\"id\":2531,\"textContent\":\"D \"}]}]},{\"nodeType\":1,\"id\":2532,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2533,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"200\",\"cy\":\"400\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2534,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"195\",\"y\":\"392\"},\"childNodes\":[{\"nodeType\":3,\"id\":2535,\"textContent\":\"E \"}]}]},{\"nodeType\":1,\"id\":2536,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2537,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"266.66666666666663\",\"cy\":\"533.3333333333334\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2538,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"261.66666666666663\",\"y\":\"525.3333333333334\"},\"childNodes\":[{\"nodeType\":3,\"id\":2539,\"textContent\":\"F \"}]}]},{\"nodeType\":1,\"id\":2540,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2541,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"333.33333333333337\",\"cy\":\"400\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2542,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"328.33333333333337\",\"y\":\"392\"},\"childNodes\":[{\"nodeType\":3,\"id\":2543,\"textContent\":\"G \"}]}]},{\"nodeType\":1,\"id\":2544,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2545,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"500\",\"cy\":\"466.66666666666663\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2546,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"495\",\"y\":\"458.66666666666663\"},\"childNodes\":[{\"nodeType\":3,\"id\":2547,\"textContent\":\"H \"}]}]},{\"nodeType\":1,\"id\":2548,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2549,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"100\",\"cy\":\"600\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2550,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"95\",\"y\":\"592\"},\"childNodes\":[{\"nodeType\":3,\"id\":2551,\"textContent\":\"I \"}]}]},{\"nodeType\":1,\"id\":2552,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2553,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"133.33333333333331\",\"cy\":\"666.6666666666667\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2554,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"128.33333333333331\",\"y\":\"658.6666666666667\"},\"childNodes\":[{\"nodeType\":3,\"id\":2555,\"textContent\":\"J \"}]}]},{\"nodeType\":1,\"id\":2556,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2557,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"400\",\"cy\":\"133.33333333333326\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2558,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"395\",\"y\":\"125.33333333333326\"},\"childNodes\":[{\"nodeType\":3,\"id\":2559,\"textContent\":\"K \"}]}]},{\"nodeType\":1,\"id\":2560,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2561,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"500\",\"cy\":\"333.3333333333333\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2562,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"495\",\"y\":\"325.3333333333333\"},\"childNodes\":[{\"nodeType\":3,\"id\":2563,\"textContent\":\"L \"}]}]},{\"nodeType\":1,\"id\":2564,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2565,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"300\",\"cy\":\"733.3333333333334\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2566,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"295\",\"y\":\"725.3333333333334\"},\"childNodes\":[{\"nodeType\":3,\"id\":2567,\"textContent\":\"M \"}]}]},{\"nodeType\":1,\"id\":2568,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2569,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"600\",\"cy\":\"666.6666666666667\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2570,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"595\",\"y\":\"658.6666666666667\"},\"childNodes\":[{\"nodeType\":3,\"id\":2571,\"textContent\":\"N \"}]}]},{\"nodeType\":1,\"id\":2572,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2573,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"433.3333333333333\",\"cy\":\"600\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2574,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"428.3333333333333\",\"y\":\"592\"},\"childNodes\":[{\"nodeType\":3,\"id\":2575,\"textContent\":\"O \"}]}]},{\"nodeType\":1,\"id\":2576,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2577,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"500\",\"cy\":\"200\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2578,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"495\",\"y\":\"192\"},\"childNodes\":[{\"nodeType\":3,\"id\":2579,\"textContent\":\"P \"}]}]},{\"nodeType\":1,\"id\":2580,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2581,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"533.3333333333333\",\"cy\":\"533.3333333333334\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2582,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"528.3333333333333\",\"y\":\"525.3333333333334\"},\"childNodes\":[{\"nodeType\":3,\"id\":2583,\"textContent\":\"Z \"}]}]},{\"nodeType\":1,\"id\":2584,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2585,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"400\",\"cy\":\"666.6666666666667\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2586,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"395\",\"y\":\"658.6666666666667\"},\"childNodes\":[{\"nodeType\":3,\"id\":2587,\"textContent\":\"X \"}]}]}]}]}]}]},{\"nodeType\":3,\"id\":2588,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2589,\"textContent\":\" \"},{\"nodeType\":8,\"id\":2590},{\"nodeType\":3,\"id\":2591,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2592,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":2593,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2594,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":2595,\"textContent\":\" \"}]}]}]]}",
  "useCssProxy": true,
  "loadTimes": "es: 258, dom: 295, initialDom: 318",
  "javascriptErrors": []
}