var MF = MF || {};MF.RecordingData = MF.RecordingData || {};MF.RecordingData["session"] = {
  "id": "969acb651487f8d1c16f6600fabd2afc",
  "created": "2018-05-21T12:18:50.7844666-07:00",
  "lastActivity": "2018-05-21T12:19:40.7513456-07:00",
  "pageViews": [
    {
      "id": "05215122fc888394ad1cbfa5d42b08f9f6ce60ee",
      "startTime": "2018-05-21T12:18:51.074613-07:00",
      "endTime": "2018-05-21T12:19:40.7513456-07:00",
      "title": "FOX2YP",
      "uri": "https://warm-citadel-75324.herokuapp.com/",
      "websitePage": "/15",
      "visitTime": 50109,
      "engagementTime": 29558,
      "scroll": 100.0,
      "tags": [
        "form-interact"
      ],
      "friction": 0,
      "annotations": []
    }
  ],
  "duration": 50109,
  "engagementTime": 29558,
  "totalFriction": 0,
  "country": "us",
  "region": "CA",
  "city": "La Jolla",
  "isp": "University of California, San Diego",
  "ip": "128.54.68.22",
  "lang": "en-US",
  "userAgent": "Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/66.0.3359.181 Safari/537.36",
  "browser": "Chrome",
  "browserVersion": "66.0.3359.181",
  "os": "Windows",
  "osVersion": "7",
  "device": "Desktop",
  "referrer": "",
  "referrerType": "",
  "screenRes": "1920x1200",
  "tags": [
    "form-interact"
  ],
  "variables": [
    "SID=Q8EDD",
    "CONDITION=111",
    "ORTH_CORRECT=1"
  ],
  "watched": false,
  "starred": false,
  "lng": -117.2359,
  "lat": 32.8807,
  "visitorId": "7f983591efffc3b25140ee05c7e91cb3",
  "gdpr": false
}