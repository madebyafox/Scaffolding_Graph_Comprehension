var MF = MF || {};MF.RecordingData = MF.RecordingData || {};MF.RecordingData["05220076dd3d96d809ceaec14892f5a3bf66649c"] = {
  "startTime": "2018-05-22T23:17:01.0358457Z",
  "websitePageUrl": "/16",
  "visitTime": 95039,
  "engagementTime": 70239,
  "pageTitle": "FOX2YP",
  "url": "https://warm-citadel-75324.herokuapp.com/",
  "viewportWidth": 1920,
  "viewportHeight": 1200,
  "tags": [
    "form-interact",
    "submit"
  ],
  "session": {
    "id": "623bf11c522d58018d1d6b25434a6229",
    "created": "2018-05-22T23:17:00.6167656+00:00",
    "lastActivity": "0001-01-01T00:00:00+00:00",
    "pages": 1,
    "duration": 0,
    "engagementTime": 0,
    "totalFriction": 0,
    "country": "us",
    "region": "CA",
    "city": "La Jolla",
    "isp": "University of California, San Diego",
    "ip": "###.###.###.###",
    "lang": "en-US",
    "userAgent": "Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/66.0.3359.181 Safari/537.36",
    "browser": "Chrome",
    "browserVersion": "66.0.3359.181",
    "os": "Windows",
    "osVersion": "7",
    "device": "Desktop",
    "referrer": "",
    "referrerType": "",
    "screenRes": "1920x1200",
    "entryPage": "/16",
    "tags": [
      "form-interact",
      "submit"
    ],
    "variables": [
      "SID=Q0QHK",
      "CONDITION=115"
    ],
    "watched": false,
    "starred": false,
    "lng": 32.8807,
    "lat": 32.8807,
    "visitorId": "4c08052357303e879e046f982134ddfc",
    "gdpr": false,
    "visitorName": null,
    "playbackUrl": "https://us.mouseflow.com/websites/e0c9ff05-6fcb-4c4a-8173-e5a0724987b1/recordings/623bf11c522d58018d1d6b25434a6229/play"
  },
  "events": [
    {
      "t": 1,
      "e": 1,
      "ty": 14,
      "x": 0,
      "y": 1199
    },
    {
      "t": 100,
      "e": 100,
      "ty": 0,
      "x": 1920,
      "y": 1200
    },
    {
      "t": 100,
      "e": 100,
      "ty": 2,
      "x": 523,
      "y": 753
    },
    {
      "t": 250,
      "e": 250,
      "ty": 41,
      "x": 17735,
      "y": 41270,
      "ta": "html > body"
    },
    {
      "t": 510,
      "e": 510,
      "ty": 2,
      "x": 524,
      "y": 753
    },
    {
      "t": 510,
      "e": 510,
      "ty": 41,
      "x": 47988,
      "y": 41270,
      "ta": "> div.stimulus > div"
    },
    {
      "t": 648,
      "e": 648,
      "ty": 38,
      "x": 1,
      "y": 0
    },
    {
      "t": 1000,
      "e": 1000,
      "ty": 2,
      "x": 526,
      "y": 753
    },
    {
      "t": 1000,
      "e": 1000,
      "ty": 41,
      "x": 48213,
      "y": 41270,
      "ta": "> div.stimulus > div"
    },
    {
      "t": 1100,
      "e": 1100,
      "ty": 2,
      "x": 527,
      "y": 753
    },
    {
      "t": 1200,
      "e": 1200,
      "ty": 2,
      "x": 530,
      "y": 750
    },
    {
      "t": 1250,
      "e": 1250,
      "ty": 41,
      "x": 49337,
      "y": 39719,
      "ta": "> div.stimulus > div"
    },
    {
      "t": 1300,
      "e": 1300,
      "ty": 2,
      "x": 538,
      "y": 665
    },
    {
      "t": 1400,
      "e": 1400,
      "ty": 2,
      "x": 532,
      "y": 618
    },
    {
      "t": 1486,
      "e": 1486,
      "ty": 6,
      "x": 532,
      "y": 603,
      "ta": "#strategyAnswer"
    },
    {
      "t": 1500,
      "e": 1500,
      "ty": 2,
      "x": 532,
      "y": 603
    },
    {
      "t": 1500,
      "e": 1500,
      "ty": 41,
      "x": 48887,
      "y": 64940,
      "ta": "#strategyAnswer"
    },
    {
      "t": 1600,
      "e": 1600,
      "ty": 2,
      "x": 532,
      "y": 596
    },
    {
      "t": 1700,
      "e": 1700,
      "ty": 2,
      "x": 536,
      "y": 589
    },
    {
      "t": 1751,
      "e": 1751,
      "ty": 41,
      "x": 49337,
      "y": 53613,
      "ta": "#strategyAnswer"
    },
    {
      "t": 1850,
      "e": 1850,
      "ty": 3,
      "x": 536,
      "y": 589,
      "ta": "#strategyAnswer"
    },
    {
      "t": 1851,
      "e": 1851,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 1929,
      "e": 1929,
      "ty": 4,
      "x": 49337,
      "y": 53613,
      "ta": "#strategyAnswer"
    },
    {
      "t": 1929,
      "e": 1929,
      "ty": 5,
      "x": 536,
      "y": 589,
      "ta": "#strategyAnswer"
    },
    {
      "t": 2100,
      "e": 2100,
      "ty": 2,
      "x": 536,
      "y": 588
    },
    {
      "t": 2250,
      "e": 2250,
      "ty": 41,
      "x": 49337,
      "y": 52804,
      "ta": "#strategyAnswer"
    },
    {
      "t": 7717,
      "e": 7250,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "76"
    },
    {
      "t": 7719,
      "e": 7252,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 7812,
      "e": 7345,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "l"
    },
    {
      "t": 7949,
      "e": 7482,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "79"
    },
    {
      "t": 7950,
      "e": 7483,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 8028,
      "e": 7561,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "lo"
    },
    {
      "t": 8149,
      "e": 7682,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "79"
    },
    {
      "t": 8149,
      "e": 7682,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 8236,
      "e": 7769,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "loo"
    },
    {
      "t": 8430,
      "e": 7963,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "75"
    },
    {
      "t": 8431,
      "e": 7964,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 8500,
      "e": 8033,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "look"
    },
    {
      "t": 8602,
      "e": 8135,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "look"
    },
    {
      "t": 9021,
      "e": 8554,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 9021,
      "e": 8554,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 9148,
      "e": 8681,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 9292,
      "e": 8825,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 9293,
      "e": 8826,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 9403,
      "e": 8936,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "look a"
    },
    {
      "t": 9483,
      "e": 9016,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 9483,
      "e": 9016,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 9484,
      "e": 9017,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||at"
    },
    {
      "t": 9565,
      "e": 9098,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 9565,
      "e": 9098,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 9589,
      "e": 9122,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 9724,
      "e": 9257,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 9725,
      "e": 9258,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 9765,
      "e": 9298,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 9885,
      "e": 9418,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "72"
    },
    {
      "t": 9886,
      "e": 9419,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 9965,
      "e": 9498,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 9965,
      "e": 9498,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 9972,
      "e": 9505,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||he"
    },
    {
      "t": 10000,
      "e": 9533,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 10068,
      "e": 9601,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 10068,
      "e": 9601,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 10076,
      "e": 9609,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 10132,
      "e": 9665,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 10189,
      "e": 9722,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 10517,
      "e": 10050,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "88"
    },
    {
      "t": 10517,
      "e": 10050,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 10660,
      "e": 10193,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||x"
    },
    {
      "t": 10668,
      "e": 10201,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 10668,
      "e": 10201,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 10774,
      "e": 10307,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 10997,
      "e": 10530,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 10998,
      "e": 10531,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 11124,
      "e": 10657,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||a"
    },
    {
      "t": 11405,
      "e": 10938,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "88"
    },
    {
      "t": 11406,
      "e": 10939,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 11501,
      "e": 11034,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||x"
    },
    {
      "t": 11602,
      "e": 11135,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "look at the x ax"
    },
    {
      "t": 12462,
      "e": 11995,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 12462,
      "e": 11995,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 12597,
      "e": 12130,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||e"
    },
    {
      "t": 12612,
      "e": 12145,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "83"
    },
    {
      "t": 12613,
      "e": 12146,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 12684,
      "e": 12217,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 12685,
      "e": 12218,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 12725,
      "e": 12258,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||s "
    },
    {
      "t": 12805,
      "e": 12338,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 13149,
      "e": 12682,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 13237,
      "e": 12770,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "look at the x axes"
    },
    {
      "t": 13421,
      "e": 12954,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 13493,
      "e": 13026,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "look at the x axe"
    },
    {
      "t": 13603,
      "e": 13136,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "look at the x axe"
    },
    {
      "t": 13605,
      "e": 13138,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 13644,
      "e": 13177,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "look at the x ax"
    },
    {
      "t": 13756,
      "e": 13289,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 13805,
      "e": 13338,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "look at the x a"
    },
    {
      "t": 13917,
      "e": 13450,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 13973,
      "e": 13506,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "look at the x "
    },
    {
      "t": 14053,
      "e": 13586,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 14053,
      "e": 13586,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 14173,
      "e": 13706,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||a"
    },
    {
      "t": 14285,
      "e": 13818,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "88"
    },
    {
      "t": 14286,
      "e": 13819,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 14372,
      "e": 13905,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||x"
    },
    {
      "t": 14468,
      "e": 14001,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 14469,
      "e": 14002,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 14540,
      "e": 14073,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||e"
    },
    {
      "t": 14613,
      "e": 14146,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "83"
    },
    {
      "t": 14614,
      "e": 14147,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 14660,
      "e": 14193,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 14660,
      "e": 14193,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 14700,
      "e": 14233,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||s "
    },
    {
      "t": 14780,
      "e": 14313,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 14901,
      "e": 14434,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 14964,
      "e": 14497,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "look at the x axes"
    },
    {
      "t": 15646,
      "e": 15179,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "188"
    },
    {
      "t": 15647,
      "e": 15180,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 15716,
      "e": 15249,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||,"
    },
    {
      "t": 15789,
      "e": 15322,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 15789,
      "e": 15322,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 15877,
      "e": 15410,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 16285,
      "e": 15818,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "87"
    },
    {
      "t": 16285,
      "e": 15818,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 16348,
      "e": 15881,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "72"
    },
    {
      "t": 16348,
      "e": 15881,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 16380,
      "e": 15913,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||wh"
    },
    {
      "t": 16453,
      "e": 15986,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 16460,
      "e": 15993,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "73"
    },
    {
      "t": 16461,
      "e": 15994,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 16541,
      "e": 16074,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "67"
    },
    {
      "t": 16542,
      "e": 16075,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 16548,
      "e": 16081,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||ic"
    },
    {
      "t": 16652,
      "e": 16185,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "72"
    },
    {
      "t": 16652,
      "e": 16185,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 16741,
      "e": 16274,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 16741,
      "e": 16274,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 16749,
      "e": 16282,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||h "
    },
    {
      "t": 16756,
      "e": 16289,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 16868,
      "e": 16401,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 17125,
      "e": 16658,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "80"
    },
    {
      "t": 17126,
      "e": 16659,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 17277,
      "e": 16810,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "79"
    },
    {
      "t": 17278,
      "e": 16811,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 17292,
      "e": 16825,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||po"
    },
    {
      "t": 17356,
      "e": 16889,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 17485,
      "e": 17018,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "73"
    },
    {
      "t": 17485,
      "e": 17018,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 17573,
      "e": 17106,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "78"
    },
    {
      "t": 17574,
      "e": 17107,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 17604,
      "e": 17137,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||in"
    },
    {
      "t": 17700,
      "e": 17233,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 17708,
      "e": 17241,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 17708,
      "e": 17241,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 17852,
      "e": 17385,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 17884,
      "e": 17417,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 17885,
      "e": 17418,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 17956,
      "e": 17489,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 18245,
      "e": 17778,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 18332,
      "e": 17865,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "look at the x axes, which point"
    },
    {
      "t": 18396,
      "e": 17929,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "83"
    },
    {
      "t": 18397,
      "e": 17930,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 18477,
      "e": 18010,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 18478,
      "e": 18011,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 18492,
      "e": 18025,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||s "
    },
    {
      "t": 18564,
      "e": 18097,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 19869,
      "e": 19402,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "73"
    },
    {
      "t": 19870,
      "e": 19403,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 19973,
      "e": 19506,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||i"
    },
    {
      "t": 20001,
      "e": 19534,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 20020,
      "e": 19553,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "83"
    },
    {
      "t": 20020,
      "e": 19553,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 20116,
      "e": 19649,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 20116,
      "e": 19649,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 20140,
      "e": 19673,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||s "
    },
    {
      "t": 20228,
      "e": 19761,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 24469,
      "e": 24002,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "79"
    },
    {
      "t": 24470,
      "e": 24003,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 24564,
      "e": 24097,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "78"
    },
    {
      "t": 24564,
      "e": 24097,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 24597,
      "e": 24130,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||on"
    },
    {
      "t": 24685,
      "e": 24218,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 24692,
      "e": 24225,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 24693,
      "e": 24226,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 24802,
      "e": 24335,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "look at the x axes, which points is on "
    },
    {
      "t": 24820,
      "e": 24353,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 24820,
      "e": 24353,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 24852,
      "e": 24385,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| t"
    },
    {
      "t": 24917,
      "e": 24450,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "72"
    },
    {
      "t": 24917,
      "e": 24450,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 24988,
      "e": 24521,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 24988,
      "e": 24521,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 24995,
      "e": 24528,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||he"
    },
    {
      "t": 25076,
      "e": 24609,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 25077,
      "e": 24610,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 25093,
      "e": 24626,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 25117,
      "e": 24650,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 25204,
      "e": 24737,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 25253,
      "e": 24786,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "49"
    },
    {
      "t": 25254,
      "e": 24787,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 25404,
      "e": 24937,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "look at the x axes, which points is on the 1"
    },
    {
      "t": 25445,
      "e": 24978,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "50"
    },
    {
      "t": 25446,
      "e": 24979,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 25484,
      "e": 25017,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||12"
    },
    {
      "t": 25556,
      "e": 25089,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 25556,
      "e": 25089,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 25588,
      "e": 25121,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 25677,
      "e": 25210,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 25877,
      "e": 25410,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "20"
    },
    {
      "t": 26013,
      "e": 25546,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 26021,
      "e": 25554,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "80"
    },
    {
      "t": 26021,
      "e": 25554,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 26093,
      "e": 25626,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||P"
    },
    {
      "t": 26197,
      "e": 25730,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "20"
    },
    {
      "t": 26236,
      "e": 25769,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "77"
    },
    {
      "t": 26237,
      "e": 25770,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 26300,
      "e": 25833,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||m"
    },
    {
      "t": 26403,
      "e": 25936,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "look at the x axes, which points is on the 12 Pm"
    },
    {
      "t": 26429,
      "e": 25962,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 26436,
      "e": 25969,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 26438,
      "e": 25971,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 26548,
      "e": 26081,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 27605,
      "e": 27138,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 27660,
      "e": 27193,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "look at the x axes, which points is on the 12 Pm"
    },
    {
      "t": 27772,
      "e": 27305,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 27812,
      "e": 27345,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "look at the x axes, which points is on the 12 P"
    },
    {
      "t": 27925,
      "e": 27458,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 27973,
      "e": 27506,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "look at the x axes, which points is on the 12 "
    },
    {
      "t": 28413,
      "e": 27946,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "80"
    },
    {
      "t": 28414,
      "e": 27947,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 28524,
      "e": 28057,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||p"
    },
    {
      "t": 28565,
      "e": 28098,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "77"
    },
    {
      "t": 28565,
      "e": 28098,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 28653,
      "e": 28186,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||m"
    },
    {
      "t": 28685,
      "e": 28218,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 28686,
      "e": 28219,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 28802,
      "e": 28335,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "look at the x axes, which points is on the 12 pm "
    },
    {
      "t": 28804,
      "e": 28337,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 29733,
      "e": 29266,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "76"
    },
    {
      "t": 29734,
      "e": 29267,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 29844,
      "e": 29377,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||l"
    },
    {
      "t": 29852,
      "e": 29385,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 29852,
      "e": 29385,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 30000,
      "e": 29533,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 30006,
      "e": 29539,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "look at the x axes, which points is on the 12 pm la"
    },
    {
      "t": 30028,
      "e": 29561,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||a"
    },
    {
      "t": 30036,
      "e": 29569,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "66"
    },
    {
      "t": 30036,
      "e": 29569,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 30116,
      "e": 29649,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||b"
    },
    {
      "t": 30237,
      "e": 29770,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 30237,
      "e": 29770,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 30332,
      "e": 29865,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "76"
    },
    {
      "t": 30332,
      "e": 29865,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 30420,
      "e": 29953,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||el"
    },
    {
      "t": 30476,
      "e": 30009,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 31100,
      "e": 30633,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 31101,
      "e": 30634,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 31188,
      "e": 30721,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 31820,
      "e": 31353,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "80"
    },
    {
      "t": 31821,
      "e": 31354,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 31981,
      "e": 31514,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "79"
    },
    {
      "t": 31981,
      "e": 31514,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 31989,
      "e": 31522,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||po"
    },
    {
      "t": 32076,
      "e": 31609,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 32116,
      "e": 31649,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "83"
    },
    {
      "t": 32116,
      "e": 31649,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 32237,
      "e": 31770,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||s"
    },
    {
      "t": 32261,
      "e": 31794,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "73"
    },
    {
      "t": 32261,
      "e": 31794,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 32316,
      "e": 31849,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||i"
    },
    {
      "t": 32604,
      "e": 32137,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 32606,
      "e": 32139,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 32708,
      "e": 32241,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "73"
    },
    {
      "t": 32709,
      "e": 32242,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 32756,
      "e": 32289,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||ti"
    },
    {
      "t": 32796,
      "e": 32329,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "79"
    },
    {
      "t": 32797,
      "e": 32330,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 32820,
      "e": 32353,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||o"
    },
    {
      "t": 32901,
      "e": 32434,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "78"
    },
    {
      "t": 32902,
      "e": 32435,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 32925,
      "e": 32458,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||n"
    },
    {
      "t": 32980,
      "e": 32513,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 32996,
      "e": 32529,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 32997,
      "e": 32530,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 33092,
      "e": 32625,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 33462,
      "e": 32995,
      "ty": 7,
      "x": 327,
      "y": 606,
      "ta": "#strategyAnswer"
    },
    {
      "t": 33501,
      "e": 33034,
      "ty": 2,
      "x": 0,
      "y": 685
    },
    {
      "t": 33501,
      "e": 33034,
      "ty": 41,
      "x": 0,
      "y": 37947,
      "ta": "html"
    },
    {
      "t": 33601,
      "e": 33134,
      "ty": 2,
      "x": 8,
      "y": 729
    },
    {
      "t": 33701,
      "e": 33234,
      "ty": 2,
      "x": 322,
      "y": 752
    },
    {
      "t": 33751,
      "e": 33284,
      "ty": 41,
      "x": 64850,
      "y": 34069,
      "ta": "> div.stimulus > div"
    },
    {
      "t": 33801,
      "e": 33334,
      "ty": 2,
      "x": 696,
      "y": 606
    },
    {
      "t": 33901,
      "e": 33434,
      "ty": 2,
      "x": 646,
      "y": 615
    },
    {
      "t": 34001,
      "e": 33534,
      "ty": 2,
      "x": 470,
      "y": 649
    },
    {
      "t": 34001,
      "e": 33534,
      "ty": 41,
      "x": 41918,
      "y": 35509,
      "ta": "> div.stimulus > div"
    },
    {
      "t": 34047,
      "e": 33580,
      "ty": 6,
      "x": 433,
      "y": 657,
      "ta": "#strategyButton"
    },
    {
      "t": 34101,
      "e": 33634,
      "ty": 2,
      "x": 419,
      "y": 659
    },
    {
      "t": 34199,
      "e": 33732,
      "ty": 2,
      "x": 417,
      "y": 661
    },
    {
      "t": 34232,
      "e": 33765,
      "ty": 3,
      "x": 415,
      "y": 664,
      "ta": "#strategyButton"
    },
    {
      "t": 34233,
      "e": 33766,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "look at the x axes, which points is on the 12 pm label position "
    },
    {
      "t": 34233,
      "e": 33766,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 34234,
      "e": 33767,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#strategyButton"
    },
    {
      "t": 34250,
      "e": 33783,
      "ty": 41,
      "x": 41727,
      "y": 17859,
      "ta": "#strategyButton"
    },
    {
      "t": 34300,
      "e": 33833,
      "ty": 2,
      "x": 415,
      "y": 664
    },
    {
      "t": 34321,
      "e": 33854,
      "ty": 4,
      "x": 41727,
      "y": 17859,
      "ta": "#strategyButton"
    },
    {
      "t": 34336,
      "e": 33869,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#strategyButton"
    },
    {
      "t": 34336,
      "e": 33869,
      "ty": 5,
      "x": 415,
      "y": 664,
      "ta": "#strategyButton"
    },
    {
      "t": 34344,
      "e": 33877,
      "ty": 38,
      "x": 2,
      "y": 0
    },
    {
      "t": 35347,
      "e": 34880,
      "ty": 38,
      "x": 3,
      "y": 0
    },
    {
      "t": 35403,
      "e": 34936,
      "ty": 2,
      "x": 414,
      "y": 668
    },
    {
      "t": 35503,
      "e": 35036,
      "ty": 41,
      "x": 13981,
      "y": 36562,
      "ta": "html > body"
    },
    {
      "t": 35999,
      "e": 35532,
      "ty": 6,
      "x": 897,
      "y": 690,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 36003,
      "e": 35536,
      "ty": 2,
      "x": 897,
      "y": 690
    },
    {
      "t": 36003,
      "e": 35536,
      "ty": 41,
      "x": 555,
      "y": 27802,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 36049,
      "e": 35582,
      "ty": 7,
      "x": 1039,
      "y": 672,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 36091,
      "e": 35624,
      "ty": 6,
      "x": 1046,
      "y": 667,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 36104,
      "e": 35637,
      "ty": 2,
      "x": 1046,
      "y": 666
    },
    {
      "t": 36200,
      "e": 35733,
      "ty": 7,
      "x": 1035,
      "y": 638,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 36203,
      "e": 35736,
      "ty": 2,
      "x": 1035,
      "y": 638
    },
    {
      "t": 36253,
      "e": 35786,
      "ty": 41,
      "x": 46069,
      "y": 1409,
      "ta": "#jspsych-survey-text-1"
    },
    {
      "t": 36284,
      "e": 35817,
      "ty": 6,
      "x": 1016,
      "y": 568,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 36303,
      "e": 35836,
      "ty": 2,
      "x": 1015,
      "y": 568
    },
    {
      "t": 36403,
      "e": 35936,
      "ty": 2,
      "x": 1012,
      "y": 560
    },
    {
      "t": 36500,
      "e": 36033,
      "ty": 3,
      "x": 1011,
      "y": 558,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 36501,
      "e": 36034,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 36504,
      "e": 36037,
      "ty": 2,
      "x": 1011,
      "y": 558
    },
    {
      "t": 36504,
      "e": 36037,
      "ty": 41,
      "x": 43906,
      "y": 12482,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 36579,
      "e": 36112,
      "ty": 4,
      "x": 43906,
      "y": 12482,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 36579,
      "e": 36112,
      "ty": 5,
      "x": 1011,
      "y": 558,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 37287,
      "e": 36820,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "98"
    },
    {
      "t": 37288,
      "e": 36821,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 37383,
      "e": 36916,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "97"
    },
    {
      "t": 37383,
      "e": 36916,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 37399,
      "e": 36932,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "21"
    },
    {
      "t": 37495,
      "e": 37028,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "21"
    },
    {
      "t": 37836,
      "e": 37369,
      "ty": 7,
      "x": 1036,
      "y": 549,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 37903,
      "e": 37436,
      "ty": 2,
      "x": 1154,
      "y": 530
    },
    {
      "t": 38003,
      "e": 37536,
      "ty": 2,
      "x": 1032,
      "y": 490
    },
    {
      "t": 38003,
      "e": 37536,
      "ty": 41,
      "x": 48448,
      "y": 0,
      "ta": "#jspsych-survey-text-0"
    },
    {
      "t": 38102,
      "e": 37635,
      "ty": 6,
      "x": 1024,
      "y": 554,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 38104,
      "e": 37637,
      "ty": 2,
      "x": 1024,
      "y": 554
    },
    {
      "t": 38135,
      "e": 37668,
      "ty": 7,
      "x": 1018,
      "y": 589,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 38202,
      "e": 37735,
      "ty": 6,
      "x": 1001,
      "y": 647,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 38204,
      "e": 37737,
      "ty": 2,
      "x": 1001,
      "y": 647
    },
    {
      "t": 38254,
      "e": 37787,
      "ty": 41,
      "x": 41743,
      "y": 9362,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 38303,
      "e": 37836,
      "ty": 2,
      "x": 1001,
      "y": 650
    },
    {
      "t": 38596,
      "e": 38129,
      "ty": 3,
      "x": 1001,
      "y": 650,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 38598,
      "e": 38131,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "21"
    },
    {
      "t": 38599,
      "e": 38132,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 38599,
      "e": 38132,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 38667,
      "e": 38200,
      "ty": 4,
      "x": 41743,
      "y": 9362,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 38667,
      "e": 38200,
      "ty": 5,
      "x": 1001,
      "y": 650,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 40004,
      "e": 39537,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 41151,
      "e": 40684,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "67"
    },
    {
      "t": 41152,
      "e": 40685,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 41262,
      "e": 40795,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "72"
    },
    {
      "t": 41262,
      "e": 40795,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 41319,
      "e": 40852,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "ch"
    },
    {
      "t": 41383,
      "e": 40916,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "ch"
    },
    {
      "t": 41511,
      "e": 41044,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "78"
    },
    {
      "t": 41512,
      "e": 41045,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 41630,
      "e": 41163,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "chn"
    },
    {
      "t": 41968,
      "e": 41501,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "8"
    },
    {
      "t": 42040,
      "e": 41573,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "ch"
    },
    {
      "t": 42303,
      "e": 41836,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "73"
    },
    {
      "t": 42304,
      "e": 41837,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 42431,
      "e": 41964,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "chi"
    },
    {
      "t": 42503,
      "e": 42036,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "78"
    },
    {
      "t": 42504,
      "e": 42037,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 42592,
      "e": 42125,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "chin"
    },
    {
      "t": 42680,
      "e": 42213,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "65"
    },
    {
      "t": 42680,
      "e": 42213,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 42783,
      "e": 42316,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "+||a"
    },
    {
      "t": 43204,
      "e": 42737,
      "ty": 2,
      "x": 975,
      "y": 654
    },
    {
      "t": 43239,
      "e": 42772,
      "ty": 7,
      "x": 831,
      "y": 670,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 43253,
      "e": 42786,
      "ty": 41,
      "x": 4974,
      "y": 61306,
      "ta": "#jspsych-survey-text-1"
    },
    {
      "t": 43303,
      "e": 42836,
      "ty": 2,
      "x": 803,
      "y": 678
    },
    {
      "t": 43404,
      "e": 42937,
      "ty": 2,
      "x": 815,
      "y": 708
    },
    {
      "t": 43503,
      "e": 43036,
      "ty": 2,
      "x": 973,
      "y": 716
    },
    {
      "t": 43503,
      "e": 43036,
      "ty": 41,
      "x": 33232,
      "y": 39221,
      "ta": "html > body"
    },
    {
      "t": 43604,
      "e": 43137,
      "ty": 2,
      "x": 1076,
      "y": 716
    },
    {
      "t": 43660,
      "e": 43193,
      "ty": 3,
      "x": 1076,
      "y": 716,
      "ta": "html > body"
    },
    {
      "t": 43661,
      "e": 43194,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "china"
    },
    {
      "t": 43661,
      "e": 43194,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 43715,
      "e": 43248,
      "ty": 4,
      "x": 36779,
      "y": 39221,
      "ta": "html > body"
    },
    {
      "t": 43715,
      "e": 43248,
      "ty": 5,
      "x": 1076,
      "y": 716,
      "ta": "html > body"
    },
    {
      "t": 43754,
      "e": 43287,
      "ty": 41,
      "x": 36641,
      "y": 39110,
      "ta": "html > body"
    },
    {
      "t": 43774,
      "e": 43307,
      "ty": 6,
      "x": 1021,
      "y": 698,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 43803,
      "e": 43336,
      "ty": 2,
      "x": 985,
      "y": 690
    },
    {
      "t": 43824,
      "e": 43357,
      "ty": 7,
      "x": 893,
      "y": 677,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 43900,
      "e": 43433,
      "ty": 3,
      "x": 868,
      "y": 675,
      "ta": "#jspsych-survey-text-1"
    },
    {
      "t": 43903,
      "e": 43436,
      "ty": 2,
      "x": 868,
      "y": 675
    },
    {
      "t": 43979,
      "e": 43512,
      "ty": 4,
      "x": 12977,
      "y": 64830,
      "ta": "#jspsych-survey-text-1"
    },
    {
      "t": 43980,
      "e": 43513,
      "ty": 5,
      "x": 868,
      "y": 675,
      "ta": "#jspsych-survey-text-1"
    },
    {
      "t": 44004,
      "e": 43537,
      "ty": 41,
      "x": 12977,
      "y": 64830,
      "ta": "#jspsych-survey-text-1"
    },
    {
      "t": 44104,
      "e": 43637,
      "ty": 2,
      "x": 893,
      "y": 687
    },
    {
      "t": 44107,
      "e": 43640,
      "ty": 6,
      "x": 913,
      "y": 695,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 44196,
      "e": 43729,
      "ty": 3,
      "x": 948,
      "y": 701,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 44197,
      "e": 43730,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 44204,
      "e": 43737,
      "ty": 2,
      "x": 948,
      "y": 701
    },
    {
      "t": 44254,
      "e": 43787,
      "ty": 41,
      "x": 26840,
      "y": 49647,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 44267,
      "e": 43800,
      "ty": 4,
      "x": 26840,
      "y": 49647,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 44267,
      "e": 43800,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 44267,
      "e": 43800,
      "ty": 5,
      "x": 948,
      "y": 701,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 44267,
      "e": 43800,
      "ty": 38,
      "x": 4,
      "y": 0
    },
    {
      "t": 45290,
      "e": 44823,
      "ty": 38,
      "x": 5,
      "y": 0
    },
    {
      "t": 46303,
      "e": 45836,
      "ty": 2,
      "x": 949,
      "y": 701
    },
    {
      "t": 46404,
      "e": 45937,
      "ty": 2,
      "x": 1033,
      "y": 209
    },
    {
      "t": 46502,
      "e": 46035,
      "ty": 2,
      "x": 934,
      "y": 3
    },
    {
      "t": 46503,
      "e": 46036,
      "ty": 41,
      "x": 32164,
      "y": 166,
      "ta": "html"
    },
    {
      "t": 46603,
      "e": 46136,
      "ty": 2,
      "x": 910,
      "y": 45
    },
    {
      "t": 46703,
      "e": 46236,
      "ty": 2,
      "x": 939,
      "y": 165
    },
    {
      "t": 46753,
      "e": 46286,
      "ty": 41,
      "x": 27192,
      "y": 373,
      "ta": "#jspsych-survey-multi-choice-form"
    },
    {
      "t": 46803,
      "e": 46336,
      "ty": 2,
      "x": 927,
      "y": 172
    },
    {
      "t": 46903,
      "e": 46436,
      "ty": 2,
      "x": 868,
      "y": 223
    },
    {
      "t": 47003,
      "e": 46536,
      "ty": 2,
      "x": 855,
      "y": 245
    },
    {
      "t": 47003,
      "e": 46536,
      "ty": 41,
      "x": 27496,
      "y": 52428,
      "ta": "#jspsych-survey-multi-choice-option-0-0 > label"
    },
    {
      "t": 47103,
      "e": 46636,
      "ty": 2,
      "x": 854,
      "y": 255
    },
    {
      "t": 47202,
      "e": 46735,
      "ty": 2,
      "x": 854,
      "y": 269
    },
    {
      "t": 47253,
      "e": 46786,
      "ty": 41,
      "x": 24812,
      "y": 39321,
      "ta": "#jspsych-survey-multi-choice-option-0-1 > label"
    },
    {
      "t": 47403,
      "e": 46936,
      "ty": 2,
      "x": 856,
      "y": 282
    },
    {
      "t": 47503,
      "e": 47036,
      "ty": 2,
      "x": 862,
      "y": 296
    },
    {
      "t": 47503,
      "e": 47036,
      "ty": 41,
      "x": 12717,
      "y": 36044,
      "ta": "#jspsych-survey-multi-choice-option-0-2 > label"
    },
    {
      "t": 47603,
      "e": 47136,
      "ty": 2,
      "x": 868,
      "y": 312
    },
    {
      "t": 47703,
      "e": 47236,
      "ty": 2,
      "x": 869,
      "y": 317
    },
    {
      "t": 47753,
      "e": 47286,
      "ty": 41,
      "x": 47231,
      "y": 19660,
      "ta": "#jspsych-survey-multi-choice-option-0-3 > label"
    },
    {
      "t": 47802,
      "e": 47335,
      "ty": 2,
      "x": 868,
      "y": 318
    },
    {
      "t": 47903,
      "e": 47436,
      "ty": 2,
      "x": 868,
      "y": 297
    },
    {
      "t": 48003,
      "e": 47536,
      "ty": 2,
      "x": 868,
      "y": 296
    },
    {
      "t": 48003,
      "e": 47536,
      "ty": 3,
      "x": 868,
      "y": 296,
      "ta": "#jspsych-survey-multi-choice-option-0-2 > label"
    },
    {
      "t": 48006,
      "e": 47539,
      "ty": 41,
      "x": 14597,
      "y": 36044,
      "ta": "#jspsych-survey-multi-choice-option-0-2 > label"
    },
    {
      "t": 48083,
      "e": 47616,
      "ty": 4,
      "x": 14597,
      "y": 36044,
      "ta": "#jspsych-survey-multi-choice-option-0-2 > label"
    },
    {
      "t": 48083,
      "e": 47616,
      "ty": 5,
      "x": 868,
      "y": 296,
      "ta": "#jspsych-survey-multi-choice-option-0-2 > label"
    },
    {
      "t": 48083,
      "e": 47616,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-0[2]_mf"
    },
    {
      "t": 48083,
      "e": 47616,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-0[2]_mf",
      "v": "Mandarin or Cantonese"
    },
    {
      "t": 49402,
      "e": 48935,
      "ty": 2,
      "x": 868,
      "y": 390
    },
    {
      "t": 49503,
      "e": 49036,
      "ty": 2,
      "x": 857,
      "y": 491
    },
    {
      "t": 49503,
      "e": 49036,
      "ty": 41,
      "x": 31933,
      "y": 6553,
      "ta": "#jspsych-survey-multi-choice-option-1-3 > label"
    },
    {
      "t": 49603,
      "e": 49136,
      "ty": 2,
      "x": 852,
      "y": 514
    },
    {
      "t": 49703,
      "e": 49236,
      "ty": 2,
      "x": 850,
      "y": 557
    },
    {
      "t": 49753,
      "e": 49286,
      "ty": 41,
      "x": 19499,
      "y": 39321,
      "ta": "#jspsych-survey-multi-choice-option-1-5 > label"
    },
    {
      "t": 49903,
      "e": 49436,
      "ty": 2,
      "x": 851,
      "y": 532
    },
    {
      "t": 50003,
      "e": 49536,
      "ty": 2,
      "x": 852,
      "y": 521
    },
    {
      "t": 50003,
      "e": 49536,
      "ty": 41,
      "x": 35784,
      "y": 13107,
      "ta": "#jspsych-survey-multi-choice-option-1-4 > label"
    },
    {
      "t": 50103,
      "e": 49636,
      "ty": 2,
      "x": 855,
      "y": 510
    },
    {
      "t": 50202,
      "e": 49735,
      "ty": 2,
      "x": 866,
      "y": 475
    },
    {
      "t": 50253,
      "e": 49786,
      "ty": 41,
      "x": 48176,
      "y": 26214,
      "ta": "#jspsych-survey-multi-choice-option-1-2 > label"
    },
    {
      "t": 50303,
      "e": 49836,
      "ty": 2,
      "x": 867,
      "y": 469
    },
    {
      "t": 50365,
      "e": 49898,
      "ty": 3,
      "x": 867,
      "y": 469,
      "ta": "#jspsych-survey-multi-choice-option-1-2 > label"
    },
    {
      "t": 50366,
      "e": 49899,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-0[2]_mf"
    },
    {
      "t": 50435,
      "e": 49968,
      "ty": 4,
      "x": 48176,
      "y": 26214,
      "ta": "#jspsych-survey-multi-choice-option-1-2 > label"
    },
    {
      "t": 50435,
      "e": 49968,
      "ty": 5,
      "x": 867,
      "y": 469,
      "ta": "#jspsych-survey-multi-choice-option-1-2 > label"
    },
    {
      "t": 50435,
      "e": 49968,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-1[2]_mf"
    },
    {
      "t": 50435,
      "e": 49968,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-1[2]_mf",
      "v": "Third"
    },
    {
      "t": 52003,
      "e": 51536,
      "ty": 2,
      "x": 883,
      "y": 512
    },
    {
      "t": 52003,
      "e": 51536,
      "ty": 41,
      "x": 14614,
      "y": 63194,
      "ta": "#jspsych-survey-multi-choice-option-1-3"
    },
    {
      "t": 52102,
      "e": 51635,
      "ty": 2,
      "x": 943,
      "y": 604
    },
    {
      "t": 52203,
      "e": 51736,
      "ty": 2,
      "x": 948,
      "y": 633
    },
    {
      "t": 52253,
      "e": 51786,
      "ty": 41,
      "x": 30277,
      "y": 9478,
      "ta": "#jspsych-survey-multi-choice-2"
    },
    {
      "t": 52303,
      "e": 51836,
      "ty": 2,
      "x": 948,
      "y": 694
    },
    {
      "t": 52402,
      "e": 51935,
      "ty": 2,
      "x": 938,
      "y": 715
    },
    {
      "t": 52503,
      "e": 52036,
      "ty": 2,
      "x": 937,
      "y": 716
    },
    {
      "t": 52503,
      "e": 52036,
      "ty": 41,
      "x": 27429,
      "y": 63194,
      "ta": "#jspsych-survey-multi-choice-option-2-1"
    },
    {
      "t": 52753,
      "e": 52286,
      "ty": 41,
      "x": 29627,
      "y": 62258,
      "ta": "#jspsych-survey-multi-choice-option-2-1 > label"
    },
    {
      "t": 52803,
      "e": 52336,
      "ty": 2,
      "x": 939,
      "y": 712
    },
    {
      "t": 53203,
      "e": 52736,
      "ty": 2,
      "x": 941,
      "y": 726
    },
    {
      "t": 53253,
      "e": 52786,
      "ty": 41,
      "x": 30012,
      "y": 45874,
      "ta": "#jspsych-survey-multi-choice-option-2-2 > label"
    },
    {
      "t": 53303,
      "e": 52836,
      "ty": 2,
      "x": 937,
      "y": 751
    },
    {
      "t": 53404,
      "e": 52937,
      "ty": 2,
      "x": 936,
      "y": 757
    },
    {
      "t": 53503,
      "e": 53036,
      "ty": 2,
      "x": 932,
      "y": 768
    },
    {
      "t": 53506,
      "e": 53038,
      "ty": 41,
      "x": 46139,
      "y": 62258,
      "ta": "#jspsych-survey-multi-choice-option-2-3 > label"
    },
    {
      "t": 53603,
      "e": 53135,
      "ty": 2,
      "x": 927,
      "y": 794
    },
    {
      "t": 53702,
      "e": 53234,
      "ty": 2,
      "x": 919,
      "y": 812
    },
    {
      "t": 53753,
      "e": 53285,
      "ty": 41,
      "x": 21259,
      "y": 58513,
      "ta": "#jspsych-survey-multi-choice-option-2-5"
    },
    {
      "t": 53803,
      "e": 53335,
      "ty": 2,
      "x": 911,
      "y": 828
    },
    {
      "t": 53903,
      "e": 53435,
      "ty": 2,
      "x": 909,
      "y": 836
    },
    {
      "t": 54003,
      "e": 53535,
      "ty": 2,
      "x": 908,
      "y": 846
    },
    {
      "t": 54004,
      "e": 53536,
      "ty": 41,
      "x": 60999,
      "y": 42597,
      "ta": "#jspsych-survey-multi-choice-option-2-6 > label"
    },
    {
      "t": 54103,
      "e": 53635,
      "ty": 2,
      "x": 908,
      "y": 852
    },
    {
      "t": 54253,
      "e": 53785,
      "ty": 41,
      "x": 60999,
      "y": 62258,
      "ta": "#jspsych-survey-multi-choice-option-2-6 > label"
    },
    {
      "t": 54503,
      "e": 54035,
      "ty": 2,
      "x": 911,
      "y": 843
    },
    {
      "t": 54504,
      "e": 54036,
      "ty": 41,
      "x": 63113,
      "y": 32767,
      "ta": "#jspsych-survey-multi-choice-option-2-6 > label"
    },
    {
      "t": 54603,
      "e": 54135,
      "ty": 2,
      "x": 938,
      "y": 755
    },
    {
      "t": 54703,
      "e": 54235,
      "ty": 2,
      "x": 945,
      "y": 725
    },
    {
      "t": 54753,
      "e": 54285,
      "ty": 41,
      "x": 31016,
      "y": 13107,
      "ta": "#jspsych-survey-multi-choice-option-2-2 > label"
    },
    {
      "t": 54903,
      "e": 54435,
      "ty": 2,
      "x": 947,
      "y": 717
    },
    {
      "t": 55003,
      "e": 54535,
      "ty": 2,
      "x": 948,
      "y": 711
    },
    {
      "t": 55003,
      "e": 54535,
      "ty": 41,
      "x": 31895,
      "y": 58981,
      "ta": "#jspsych-survey-multi-choice-option-2-1 > label"
    },
    {
      "t": 55103,
      "e": 54635,
      "ty": 2,
      "x": 950,
      "y": 706
    },
    {
      "t": 55148,
      "e": 54680,
      "ty": 3,
      "x": 950,
      "y": 706,
      "ta": "#jspsych-survey-multi-choice-option-2-1 > label"
    },
    {
      "t": 55149,
      "e": 54681,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-1[2]_mf"
    },
    {
      "t": 55218,
      "e": 54750,
      "ty": 4,
      "x": 32399,
      "y": 42597,
      "ta": "#jspsych-survey-multi-choice-option-2-1 > label"
    },
    {
      "t": 55218,
      "e": 54750,
      "ty": 5,
      "x": 950,
      "y": 706,
      "ta": "#jspsych-survey-multi-choice-option-2-1 > label"
    },
    {
      "t": 55219,
      "e": 54751,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-2[1]_mf"
    },
    {
      "t": 55219,
      "e": 54751,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-2[1]_mf",
      "v": "Social Sciences (incl. CogSci)"
    },
    {
      "t": 55253,
      "e": 54785,
      "ty": 41,
      "x": 32399,
      "y": 42597,
      "ta": "#jspsych-survey-multi-choice-option-2-1 > label"
    },
    {
      "t": 56503,
      "e": 56035,
      "ty": 2,
      "x": 932,
      "y": 905
    },
    {
      "t": 56504,
      "e": 56036,
      "ty": 41,
      "x": 26242,
      "y": 15123,
      "ta": "#jspsych-survey-multi-choice-3"
    },
    {
      "t": 56603,
      "e": 56135,
      "ty": 2,
      "x": 912,
      "y": 943
    },
    {
      "t": 56703,
      "e": 56235,
      "ty": 2,
      "x": 890,
      "y": 964
    },
    {
      "t": 56753,
      "e": 56285,
      "ty": 41,
      "x": 51429,
      "y": 39321,
      "ta": "#jspsych-survey-multi-choice-option-3-1 > label"
    },
    {
      "t": 56803,
      "e": 56335,
      "ty": 2,
      "x": 871,
      "y": 965
    },
    {
      "t": 56903,
      "e": 56435,
      "ty": 2,
      "x": 859,
      "y": 956
    },
    {
      "t": 57003,
      "e": 56535,
      "ty": 2,
      "x": 856,
      "y": 951
    },
    {
      "t": 57003,
      "e": 56535,
      "ty": 41,
      "x": 8206,
      "y": 4681,
      "ta": "#jspsych-survey-multi-choice-option-3-1"
    },
    {
      "t": 57103,
      "e": 56635,
      "ty": 2,
      "x": 856,
      "y": 961
    },
    {
      "t": 57219,
      "e": 56751,
      "ty": 3,
      "x": 856,
      "y": 961,
      "ta": "#jspsych-survey-multi-choice-option-3-1 > label"
    },
    {
      "t": 57219,
      "e": 56751,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-2[1]_mf"
    },
    {
      "t": 57253,
      "e": 56785,
      "ty": 41,
      "x": 27970,
      "y": 26214,
      "ta": "#jspsych-survey-multi-choice-option-3-1 > label"
    },
    {
      "t": 57291,
      "e": 56823,
      "ty": 4,
      "x": 27970,
      "y": 26214,
      "ta": "#jspsych-survey-multi-choice-option-3-1 > label"
    },
    {
      "t": 57292,
      "e": 56824,
      "ty": 5,
      "x": 856,
      "y": 961,
      "ta": "#jspsych-survey-multi-choice-option-3-1 > label"
    },
    {
      "t": 57293,
      "e": 56825,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-3[1]_mf"
    },
    {
      "t": 57295,
      "e": 56827,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-3[1]_mf",
      "v": "Female"
    },
    {
      "t": 57403,
      "e": 56935,
      "ty": 2,
      "x": 857,
      "y": 964
    },
    {
      "t": 57451,
      "e": 56983,
      "ty": 6,
      "x": 861,
      "y": 1016,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 57503,
      "e": 57035,
      "ty": 2,
      "x": 863,
      "y": 1033
    },
    {
      "t": 57504,
      "e": 57036,
      "ty": 41,
      "x": 17305,
      "y": 55605,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 57603,
      "e": 57135,
      "ty": 2,
      "x": 864,
      "y": 1034
    },
    {
      "t": 57708,
      "e": 57240,
      "ty": 3,
      "x": 864,
      "y": 1034,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 57709,
      "e": 57241,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-3[1]_mf"
    },
    {
      "t": 57710,
      "e": 57242,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 57753,
      "e": 57285,
      "ty": 41,
      "x": 17821,
      "y": 57591,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 57819,
      "e": 57351,
      "ty": 4,
      "x": 17821,
      "y": 57591,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 57819,
      "e": 57351,
      "ty": 5,
      "x": 864,
      "y": 1034,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 57821,
      "e": 57353,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 57822,
      "e": 57354,
      "ty": 13,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-multi-choice-form"
    },
    {
      "t": 57823,
      "e": 57355,
      "ty": 38,
      "x": 6,
      "y": 0
    },
    {
      "t": 58918,
      "e": 58450,
      "ty": 38,
      "x": 7,
      "y": 0
    },
    {
      "t": 59255,
      "e": 57355,
      "ty": 41,
      "x": 28118,
      "y": 62855,
      "ta": "> div.masterdiv > div:[2]"
    },
    {
      "t": 59303,
      "e": 57403,
      "ty": 2,
      "x": 865,
      "y": 1034
    },
    {
      "t": 59403,
      "e": 57503,
      "ty": 2,
      "x": 869,
      "y": 1032
    },
    {
      "t": 59503,
      "e": 57603,
      "ty": 2,
      "x": 877,
      "y": 1033
    },
    {
      "t": 59503,
      "e": 57603,
      "ty": 41,
      "x": 28708,
      "y": 62786,
      "ta": "> div.masterdiv > div:[2]"
    },
    {
      "t": 59603,
      "e": 57703,
      "ty": 2,
      "x": 909,
      "y": 1056
    },
    {
      "t": 59703,
      "e": 57803,
      "ty": 2,
      "x": 911,
      "y": 1057
    },
    {
      "t": 59753,
      "e": 57853,
      "ty": 41,
      "x": 30430,
      "y": 64448,
      "ta": "> div.masterdiv > div:[2]"
    },
    {
      "t": 59803,
      "e": 57903,
      "ty": 2,
      "x": 912,
      "y": 1058
    },
    {
      "t": 59903,
      "e": 58003,
      "ty": 2,
      "x": 915,
      "y": 1060
    },
    {
      "t": 60003,
      "e": 58103,
      "ty": 2,
      "x": 917,
      "y": 1061
    },
    {
      "t": 60003,
      "e": 58103,
      "ty": 41,
      "x": 30676,
      "y": 64725,
      "ta": "> div.masterdiv > div:[2]"
    },
    {
      "t": 60103,
      "e": 58203,
      "ty": 2,
      "x": 918,
      "y": 1062
    },
    {
      "t": 60204,
      "e": 58304,
      "ty": 2,
      "x": 919,
      "y": 1063
    },
    {
      "t": 60253,
      "e": 58353,
      "ty": 41,
      "x": 30775,
      "y": 64864,
      "ta": "> div.masterdiv > div:[2]"
    },
    {
      "t": 60504,
      "e": 58604,
      "ty": 2,
      "x": 923,
      "y": 1063
    },
    {
      "t": 60504,
      "e": 58604,
      "ty": 41,
      "x": 30971,
      "y": 64864,
      "ta": "> div.masterdiv > div:[2]"
    },
    {
      "t": 60704,
      "e": 58804,
      "ty": 2,
      "x": 924,
      "y": 1063
    },
    {
      "t": 60754,
      "e": 58854,
      "ty": 41,
      "x": 31021,
      "y": 64864,
      "ta": "> div.masterdiv > div:[2]"
    },
    {
      "t": 61003,
      "e": 59103,
      "ty": 2,
      "x": 925,
      "y": 1063
    },
    {
      "t": 61004,
      "e": 59104,
      "ty": 41,
      "x": 31070,
      "y": 64864,
      "ta": "> div.masterdiv > div:[2]"
    },
    {
      "t": 61104,
      "e": 59204,
      "ty": 2,
      "x": 926,
      "y": 1063
    },
    {
      "t": 61204,
      "e": 59304,
      "ty": 2,
      "x": 927,
      "y": 1063
    },
    {
      "t": 61254,
      "e": 59354,
      "ty": 41,
      "x": 31266,
      "y": 64864,
      "ta": "> div.masterdiv > div:[2]"
    },
    {
      "t": 61303,
      "e": 59403,
      "ty": 2,
      "x": 930,
      "y": 1062
    },
    {
      "t": 61403,
      "e": 59503,
      "ty": 2,
      "x": 932,
      "y": 1061
    },
    {
      "t": 61504,
      "e": 59604,
      "ty": 41,
      "x": 31414,
      "y": 64725,
      "ta": "> div.masterdiv > div:[2]"
    },
    {
      "t": 61704,
      "e": 59804,
      "ty": 2,
      "x": 934,
      "y": 1059
    },
    {
      "t": 61754,
      "e": 59854,
      "ty": 41,
      "x": 31512,
      "y": 64587,
      "ta": "> div.masterdiv > div:[2]"
    },
    {
      "t": 61803,
      "e": 59903,
      "ty": 2,
      "x": 935,
      "y": 1059
    },
    {
      "t": 61904,
      "e": 60004,
      "ty": 2,
      "x": 938,
      "y": 1058
    },
    {
      "t": 62004,
      "e": 60104,
      "ty": 2,
      "x": 940,
      "y": 1056
    },
    {
      "t": 62004,
      "e": 60104,
      "ty": 41,
      "x": 31808,
      "y": 64379,
      "ta": "> div.masterdiv > div:[2]"
    },
    {
      "t": 62103,
      "e": 60203,
      "ty": 2,
      "x": 943,
      "y": 1053
    },
    {
      "t": 62203,
      "e": 60303,
      "ty": 2,
      "x": 945,
      "y": 1050
    },
    {
      "t": 62253,
      "e": 60353,
      "ty": 41,
      "x": 32103,
      "y": 63756,
      "ta": "> div.masterdiv > div:[2]"
    },
    {
      "t": 62304,
      "e": 60404,
      "ty": 2,
      "x": 947,
      "y": 1046
    },
    {
      "t": 62404,
      "e": 60504,
      "ty": 2,
      "x": 949,
      "y": 1044
    },
    {
      "t": 62503,
      "e": 60603,
      "ty": 2,
      "x": 949,
      "y": 1042
    },
    {
      "t": 62504,
      "e": 60604,
      "ty": 41,
      "x": 32250,
      "y": 63409,
      "ta": "> div.masterdiv > div:[2]"
    },
    {
      "t": 62604,
      "e": 60704,
      "ty": 2,
      "x": 953,
      "y": 1037
    },
    {
      "t": 62704,
      "e": 60804,
      "ty": 2,
      "x": 1210,
      "y": 874
    },
    {
      "t": 62754,
      "e": 60854,
      "ty": 41,
      "x": 50945,
      "y": 51793,
      "ta": "> div.masterdiv > div:[2] > div > p:[4]"
    },
    {
      "t": 62803,
      "e": 60903,
      "ty": 2,
      "x": 1355,
      "y": 716
    },
    {
      "t": 63004,
      "e": 61104,
      "ty": 41,
      "x": 52224,
      "y": 27803,
      "ta": "> div.masterdiv > div:[2] > div > p:[4]"
    },
    {
      "t": 70003,
      "e": 66104,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 90904,
      "e": 66104,
      "ty": 2,
      "x": 1634,
      "y": 562
    },
    {
      "t": 91003,
      "e": 66203,
      "ty": 2,
      "x": 1808,
      "y": 473
    },
    {
      "t": 91004,
      "e": 66204,
      "ty": 41,
      "x": 61987,
      "y": 25759,
      "ta": "> div.masterdiv"
    },
    {
      "t": 91103,
      "e": 66303,
      "ty": 2,
      "x": 1631,
      "y": 624
    },
    {
      "t": 91203,
      "e": 66403,
      "ty": 2,
      "x": 1210,
      "y": 951
    },
    {
      "t": 91253,
      "e": 66453,
      "ty": 41,
      "x": 36580,
      "y": 64310,
      "ta": "> div.masterdiv > div:[2]"
    },
    {
      "t": 91294,
      "e": 66494,
      "ty": 6,
      "x": 1021,
      "y": 1079,
      "ta": "#start"
    },
    {
      "t": 91303,
      "e": 66503,
      "ty": 2,
      "x": 1021,
      "y": 1079
    },
    {
      "t": 91404,
      "e": 66604,
      "ty": 2,
      "x": 1021,
      "y": 1081
    },
    {
      "t": 91504,
      "e": 66704,
      "ty": 41,
      "x": 60892,
      "y": 16022,
      "ta": "#start"
    },
    {
      "t": 91704,
      "e": 66904,
      "ty": 2,
      "x": 1020,
      "y": 1079
    },
    {
      "t": 91754,
      "e": 66954,
      "ty": 41,
      "x": 60346,
      "y": 12167,
      "ta": "#start"
    },
    {
      "t": 92004,
      "e": 67204,
      "ty": 2,
      "x": 1017,
      "y": 1081
    },
    {
      "t": 92004,
      "e": 67204,
      "ty": 41,
      "x": 58708,
      "y": 16022,
      "ta": "#start"
    },
    {
      "t": 92104,
      "e": 67304,
      "ty": 2,
      "x": 1016,
      "y": 1081
    },
    {
      "t": 92254,
      "e": 67454,
      "ty": 41,
      "x": 58162,
      "y": 16022,
      "ta": "#start"
    },
    {
      "t": 92420,
      "e": 67620,
      "ty": 3,
      "x": 1016,
      "y": 1081,
      "ta": "#start"
    },
    {
      "t": 92421,
      "e": 67621,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#start"
    },
    {
      "t": 92522,
      "e": 67722,
      "ty": 4,
      "x": 58162,
      "y": 16022,
      "ta": "#start"
    },
    {
      "t": 92522,
      "e": 67722,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#start"
    },
    {
      "t": 92522,
      "e": 67722,
      "ty": 5,
      "x": 1016,
      "y": 1081,
      "ta": "#start"
    },
    {
      "t": 92524,
      "e": 67724,
      "ty": 38,
      "x": 8,
      "y": 0
    },
    {
      "t": 93565,
      "e": 68765,
      "ty": 38,
      "x": 9,
      "y": 0
    },
    {
      "t": 94346,
      "e": 69546,
      "ty": 2,
      "x": 1009,
      "y": 1086
    },
    {
      "t": 94346,
      "e": 69546,
      "ty": 41,
      "x": 35308,
      "y": 32877,
      "ta": "#jspsych-data-display"
    },
    {
      "t": 94703,
      "e": 69903,
      "ty": 2,
      "x": 1014,
      "y": 1090
    },
    {
      "t": 94753,
      "e": 69953,
      "ty": 41,
      "x": 35565,
      "y": 32878,
      "ta": "#jspsych-data-display"
    },
    {
      "t": 94802,
      "e": 70002,
      "ty": 2,
      "x": 1014,
      "y": 1091
    },
    {
      "t": 95039,
      "e": 70239,
      "ty": 20,
      "x": 0,
      "y": 0
    }
  ],
  "domMutations": [
    {
      "sequence": 1,
      "data": "{\"f\":\"applyChanged\",\"args\":[[],[{\"nodeType\":1,\"id\":2311,\"tagName\":\"g\",\"attributes\":{\"class\":\"xaxis\",\"transform\":\"translate(0,800)\",\"fill\":\"none\",\"font-size\":\"10\",\"font-family\":\"sans-serif\",\"text-anchor\":\"middle\"},\"previousSibling\":{\"id\":2302},\"parentNode\":{\"id\":2300}},{\"nodeType\":1,\"id\":2312,\"tagName\":\"g\",\"attributes\":{\"class\":\"yaxis\",\"fill\":\"none\",\"font-size\":\"10\",\"font-family\":\"sans-serif\",\"text-anchor\":\"end\"},\"previousSibling\":{\"id\":2311},\"parentNode\":{\"id\":2300}},{\"nodeType\":1,\"id\":2313,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"previousSibling\":{\"id\":2312},\"parentNode\":{\"id\":2300}},{\"nodeType\":1,\"id\":2314,\"tagName\":\"g\",\"attributes\":{\"class\":\"xgrid\"},\"previousSibling\":{\"id\":2313},\"parentNode\":{\"id\":2300}},{\"nodeType\":1,\"id\":2315,\"tagName\":\"g\",\"attributes\":{\"class\":\"data\"},\"previousSibling\":{\"id\":2314},\"parentNode\":{\"id\":2300}},{\"nodeType\":1,\"id\":2316,\"tagName\":\"path\",\"attributes\":{\"class\":\"domain\",\"stroke\":\"#000\",\"d\":\"M0.5,6V0.5H800.5V6\"},\"parentNode\":{\"id\":2311}},{\"nodeType\":1,\"id\":2317,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0.5,0)\"},\"previousSibling\":{\"id\":2316},\"parentNode\":{\"id\":2311}},{\"nodeType\":1,\"id\":2318,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(33.83333333333333,0)\"},\"previousSibling\":{\"id\":2317},\"parentNode\":{\"id\":2311}},{\"nodeType\":1,\"id\":2319,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(67.16666666666666,0)\"},\"previousSibling\":{\"id\":2318},\"parentNode\":{\"id\":2311}},{\"nodeType\":1,\"id\":2320,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(100.5,0)\"},\"previousSibling\":{\"id\":2319},\"parentNode\":{\"id\":2311}},{\"nodeType\":1,\"id\":2321,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(133.83333333333331,0)\"},\"previousSibling\":{\"id\":2320},\"parentNode\":{\"id\":2311}},{\"nodeType\":1,\"id\":2322,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(167.16666666666669,0)\"},\"previousSibling\":{\"id\":2321},\"parentNode\":{\"id\":2311}},{\"nodeType\":1,\"id\":2323,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(200.5,0)\"},\"previousSibling\":{\"id\":2322},\"parentNode\":{\"id\":2311}},{\"nodeType\":1,\"id\":2324,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(233.83333333333334,0)\"},\"previousSibling\":{\"id\":2323},\"parentNode\":{\"id\":2311}},{\"nodeType\":1,\"id\":2325,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(267.16666666666663,0)\"},\"previousSibling\":{\"id\":2324},\"parentNode\":{\"id\":2311}},{\"nodeType\":1,\"id\":2326,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(300.5,0)\"},\"previousSibling\":{\"id\":2325},\"parentNode\":{\"id\":2311}},{\"nodeType\":1,\"id\":2327,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(333.83333333333337,0)\"},\"previousSibling\":{\"id\":2326},\"parentNode\":{\"id\":2311}},{\"nodeType\":1,\"id\":2328,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(367.16666666666663,0)\"},\"previousSibling\":{\"id\":2327},\"parentNode\":{\"id\":2311}},{\"nodeType\":1,\"id\":2329,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(400.5,0)\"},\"previousSibling\":{\"id\":2328},\"parentNode\":{\"id\":2311}},{\"nodeType\":1,\"id\":2330,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(433.8333333333333,0)\"},\"previousSibling\":{\"id\":2329},\"parentNode\":{\"id\":2311}},{\"nodeType\":1,\"id\":2331,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(467.1666666666667,0)\"},\"previousSibling\":{\"id\":2330},\"parentNode\":{\"id\":2311}},{\"nodeType\":1,\"id\":2332,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(500.5,0)\"},\"previousSibling\":{\"id\":2331},\"parentNode\":{\"id\":2311}},{\"nodeType\":1,\"id\":2333,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(533.8333333333333,0)\"},\"previousSibling\":{\"id\":2332},\"parentNode\":{\"id\":2311}},{\"nodeType\":1,\"id\":2334,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(567.1666666666667,0)\"},\"previousSibling\":{\"id\":2333},\"parentNode\":{\"id\":2311}},{\"nodeType\":1,\"id\":2335,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(600.5,0)\"},\"previousSibling\":{\"id\":2334},\"parentNode\":{\"id\":2311}},{\"nodeType\":1,\"id\":2336,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(633.8333333333333,0)\"},\"previousSibling\":{\"id\":2335},\"parentNode\":{\"id\":2311}},{\"nodeType\":1,\"id\":2337,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(667.1666666666667,0)\"},\"previousSibling\":{\"id\":2336},\"parentNode\":{\"id\":2311}},{\"nodeType\":1,\"id\":2338,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(700.5,0)\"},\"previousSibling\":{\"id\":2337},\"parentNode\":{\"id\":2311}},{\"nodeType\":1,\"id\":2339,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(733.8333333333333,0)\"},\"previousSibling\":{\"id\":2338},\"parentNode\":{\"id\":2311}},{\"nodeType\":1,\"id\":2340,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(767.1666666666667,0)\"},\"previousSibling\":{\"id\":2339},\"parentNode\":{\"id\":2311}},{\"nodeType\":1,\"id\":2341,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(800.5,0)\"},\"previousSibling\":{\"id\":2340},\"parentNode\":{\"id\":2311}},{\"nodeType\":1,\"id\":2342,\"tagName\":\"g\",\"attributes\":{\"class\":\"axisTitle\"},\"previousSibling\":{\"id\":2341},\"parentNode\":{\"id\":2311}},{\"nodeType\":1,\"id\":2343,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"},\"parentNode\":{\"id\":2317}},{\"nodeType\":1,\"id\":2344,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"previousSibling\":{\"id\":2343},\"parentNode\":{\"id\":2317}},{\"nodeType\":1,\"id\":2345,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"},\"parentNode\":{\"id\":2318}},{\"nodeType\":1,\"id\":2346,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"previousSibling\":{\"id\":2345},\"parentNode\":{\"id\":2318}},{\"nodeType\":1,\"id\":2347,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"},\"parentNode\":{\"id\":2319}},{\"nodeType\":1,\"id\":2348,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"previousSibling\":{\"id\":2347},\"parentNode\":{\"id\":2319}},{\"nodeType\":1,\"id\":2349,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"},\"parentNode\":{\"id\":2320}},{\"nodeType\":1,\"id\":2350,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"previousSibling\":{\"id\":2349},\"parentNode\":{\"id\":2320}},{\"nodeType\":1,\"id\":2351,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"},\"parentNode\":{\"id\":2321}},{\"nodeType\":1,\"id\":2352,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"previousSibling\":{\"id\":2351},\"parentNode\":{\"id\":2321}},{\"nodeType\":1,\"id\":2353,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"},\"parentNode\":{\"id\":2322}},{\"nodeType\":1,\"id\":2354,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"previousSibling\":{\"id\":2353},\"parentNode\":{\"id\":2322}},{\"nodeType\":1,\"id\":2355,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"},\"parentNode\":{\"id\":2323}},{\"nodeType\":1,\"id\":2356,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"previousSibling\":{\"id\":2355},\"parentNode\":{\"id\":2323}},{\"nodeType\":1,\"id\":2357,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"},\"parentNode\":{\"id\":2324}},{\"nodeType\":1,\"id\":2358,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"previousSibling\":{\"id\":2357},\"parentNode\":{\"id\":2324}},{\"nodeType\":1,\"id\":2359,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"},\"parentNode\":{\"id\":2325}},{\"nodeType\":1,\"id\":2360,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"previousSibling\":{\"id\":2359},\"parentNode\":{\"id\":2325}},{\"nodeType\":1,\"id\":2361,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"},\"parentNode\":{\"id\":2326}},{\"nodeType\":1,\"id\":2362,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"previousSibling\":{\"id\":2361},\"parentNode\":{\"id\":2326}},{\"nodeType\":1,\"id\":2363,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"},\"parentNode\":{\"id\":2327}},{\"nodeType\":1,\"id\":2364,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"previousSibling\":{\"id\":2363},\"parentNode\":{\"id\":2327}},{\"nodeType\":1,\"id\":2365,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"},\"parentNode\":{\"id\":2328}},{\"nodeType\":1,\"id\":2366,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"previousSibling\":{\"id\":2365},\"parentNode\":{\"id\":2328}},{\"nodeType\":1,\"id\":2367,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"},\"parentNode\":{\"id\":2329}},{\"nodeType\":1,\"id\":2368,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"previousSibling\":{\"id\":2367},\"parentNode\":{\"id\":2329}},{\"nodeType\":1,\"id\":2369,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"},\"parentNode\":{\"id\":2330}},{\"nodeType\":1,\"id\":2370,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"previousSibling\":{\"id\":2369},\"parentNode\":{\"id\":2330}},{\"nodeType\":1,\"id\":2371,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"},\"parentNode\":{\"id\":2331}},{\"nodeType\":1,\"id\":2372,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"previousSibling\":{\"id\":2371},\"parentNode\":{\"id\":2331}},{\"nodeType\":1,\"id\":2373,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"},\"parentNode\":{\"id\":2332}},{\"nodeType\":1,\"id\":2374,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"previousSibling\":{\"id\":2373},\"parentNode\":{\"id\":2332}},{\"nodeType\":1,\"id\":2375,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"},\"parentNode\":{\"id\":2333}},{\"nodeType\":1,\"id\":2376,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"previousSibling\":{\"id\":2375},\"parentNode\":{\"id\":2333}},{\"nodeType\":1,\"id\":2377,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"},\"parentNode\":{\"id\":2334}},{\"nodeType\":1,\"id\":2378,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"previousSibling\":{\"id\":2377},\"parentNode\":{\"id\":2334}},{\"nodeType\":1,\"id\":2379,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"},\"parentNode\":{\"id\":2335}},{\"nodeType\":1,\"id\":2380,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"previousSibling\":{\"id\":2379},\"parentNode\":{\"id\":2335}},{\"nodeType\":1,\"id\":2381,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"},\"parentNode\":{\"id\":2336}},{\"nodeType\":1,\"id\":2382,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"previousSibling\":{\"id\":2381},\"parentNode\":{\"id\":2336}},{\"nodeType\":1,\"id\":2383,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"},\"parentNode\":{\"id\":2337}},{\"nodeType\":1,\"id\":2384,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"previousSibling\":{\"id\":2383},\"parentNode\":{\"id\":2337}},{\"nodeType\":1,\"id\":2385,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"},\"parentNode\":{\"id\":2338}},{\"nodeType\":1,\"id\":2386,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"previousSibling\":{\"id\":2385},\"parentNode\":{\"id\":2338}},{\"nodeType\":1,\"id\":2387,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"},\"parentNode\":{\"id\":2339}},{\"nodeType\":1,\"id\":2388,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"previousSibling\":{\"id\":2387},\"parentNode\":{\"id\":2339}},{\"nodeType\":1,\"id\":2389,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"},\"parentNode\":{\"id\":2340}},{\"nodeType\":1,\"id\":2390,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"previousSibling\":{\"id\":2389},\"parentNode\":{\"id\":2340}},{\"nodeType\":1,\"id\":2391,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"},\"parentNode\":{\"id\":2341}},{\"nodeType\":1,\"id\":2392,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"previousSibling\":{\"id\":2391},\"parentNode\":{\"id\":2341}},{\"nodeType\":3,\"id\":2393,\"textContent\":\"08 AM\",\"parentNode\":{\"id\":2344}},{\"nodeType\":3,\"id\":2394,\"textContent\":\"08:30\",\"parentNode\":{\"id\":2346}},{\"nodeType\":3,\"id\":2395,\"textContent\":\"09 AM\",\"parentNode\":{\"id\":2348}},{\"nodeType\":3,\"id\":2396,\"textContent\":\"09:30\",\"parentNode\":{\"id\":2350}},{\"nodeType\":3,\"id\":2397,\"textContent\":\"10 AM\",\"parentNode\":{\"id\":2352}},{\"nodeType\":3,\"id\":2398,\"textContent\":\"10:30\",\"parentNode\":{\"id\":2354}},{\"nodeType\":3,\"id\":2399,\"textContent\":\"11 AM\",\"parentNode\":{\"id\":2356}},{\"nodeType\":3,\"id\":2400,\"textContent\":\"11:30\",\"parentNode\":{\"id\":2358}},{\"nodeType\":3,\"id\":2401,\"textContent\":\"12 PM\",\"parentNode\":{\"id\":2360}},{\"nodeType\":3,\"id\":2402,\"textContent\":\"12:30\",\"parentNode\":{\"id\":2362}},{\"nodeType\":3,\"id\":2403,\"textContent\":\"01 PM\",\"parentNode\":{\"id\":2364}},{\"nodeType\":3,\"id\":2404,\"textContent\":\"01:30\",\"parentNode\":{\"id\":2366}},{\"nodeType\":3,\"id\":2405,\"textContent\":\"02 PM\",\"parentNode\":{\"id\":2368}},{\"nodeType\":3,\"id\":2406,\"textContent\":\"02:30\",\"parentNode\":{\"id\":2370}},{\"nodeType\":3,\"id\":2407,\"textContent\":\"03 PM\",\"parentNode\":{\"id\":2372}},{\"nodeType\":3,\"id\":2408,\"textContent\":\"03:30\",\"parentNode\":{\"id\":2374}},{\"nodeType\":3,\"id\":2409,\"textContent\":\"04 PM\",\"parentNode\":{\"id\":2376}},{\"nodeType\":3,\"id\":2410,\"textContent\":\"04:30\",\"parentNode\":{\"id\":2378}},{\"nodeType\":3,\"id\":2411,\"textContent\":\"05 PM\",\"parentNode\":{\"id\":2380}},{\"nodeType\":3,\"id\":2412,\"textContent\":\"05:30\",\"parentNode\":{\"id\":2382}},{\"nodeType\":3,\"id\":2413,\"textContent\":\"06 PM\",\"parentNode\":{\"id\":2384}},{\"nodeType\":3,\"id\":2414,\"textContent\":\"06:30\",\"parentNode\":{\"id\":2386}},{\"nodeType\":3,\"id\":2415,\"textContent\":\"07 PM\",\"parentNode\":{\"id\":2388}},{\"nodeType\":3,\"id\":2416,\"textContent\":\"07:30\",\"parentNode\":{\"id\":2390}},{\"nodeType\":3,\"id\":2417,\"textContent\":\"08 PM\",\"parentNode\":{\"id\":2392}},{\"nodeType\":1,\"id\":2418,\"tagName\":\"text\",\"attributes\":{\"x\":\"533.3333333333334\",\"y\":\"80\",\"style\":\"text-anchor: end;\"},\"parentNode\":{\"id\":2342}},{\"nodeType\":3,\"id\":2419,\"textContent\":\"START & END TIME (time of day)\",\"parentNode\":{\"id\":2418}},{\"nodeType\":1,\"id\":2420,\"tagName\":\"path\",\"attributes\":{\"class\":\"domain\",\"stroke\":\"#000\",\"d\":\"M-15,800.5H0.5V0.5H-15\"},\"parentNode\":{\"id\":2312}},{\"nodeType\":1,\"id\":2421,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,800.5)\"},\"previousSibling\":{\"id\":2420},\"parentNode\":{\"id\":2312}},{\"nodeType\":1,\"id\":2422,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,733.8333333333334)\"},\"previousSibling\":{\"id\":2421},\"parentNode\":{\"id\":2312}},{\"nodeType\":1,\"id\":2423,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,667.1666666666667)\"},\"previousSibling\":{\"id\":2422},\"parentNode\":{\"id\":2312}},{\"nodeType\":1,\"id\":2424,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,600.5)\"},\"previousSibling\":{\"id\":2423},\"parentNode\":{\"id\":2312}},{\"nodeType\":1,\"id\":2425,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,533.8333333333334)\"},\"previousSibling\":{\"id\":2424},\"parentNode\":{\"id\":2312}},{\"nodeType\":1,\"id\":2426,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,467.16666666666663)\"},\"previousSibling\":{\"id\":2425},\"parentNode\":{\"id\":2312}},{\"nodeType\":1,\"id\":2427,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,400.5)\"},\"previousSibling\":{\"id\":2426},\"parentNode\":{\"id\":2312}},{\"nodeType\":1,\"id\":2428,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,333.8333333333333)\"},\"previousSibling\":{\"id\":2427},\"parentNode\":{\"id\":2312}},{\"nodeType\":1,\"id\":2429,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,267.16666666666674)\"},\"previousSibling\":{\"id\":2428},\"parentNode\":{\"id\":2312}},{\"nodeType\":1,\"id\":2430,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,200.5)\"},\"previousSibling\":{\"id\":2429},\"parentNode\":{\"id\":2312}},{\"nodeType\":1,\"id\":2431,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,133.83333333333326)\"},\"previousSibling\":{\"id\":2430},\"parentNode\":{\"id\":2312}},{\"nodeType\":1,\"id\":2432,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,67.16666666666674)\"},\"previousSibling\":{\"id\":2431},\"parentNode\":{\"id\":2312}},{\"nodeType\":1,\"id\":2433,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,0.5)\"},\"previousSibling\":{\"id\":2432},\"parentNode\":{\"id\":2312}},{\"nodeType\":1,\"id\":2434,\"tagName\":\"g\",\"attributes\":{\"class\":\"axisTitle\"},\"previousSibling\":{\"id\":2433},\"parentNode\":{\"id\":2312}},{\"nodeType\":1,\"id\":2435,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"},\"parentNode\":{\"id\":2421}},{\"nodeType\":1,\"id\":2436,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"previousSibling\":{\"id\":2435},\"parentNode\":{\"id\":2421}},{\"nodeType\":1,\"id\":2437,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"},\"parentNode\":{\"id\":2422}},{\"nodeType\":1,\"id\":2438,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"previousSibling\":{\"id\":2437},\"parentNode\":{\"id\":2422}},{\"nodeType\":1,\"id\":2439,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"},\"parentNode\":{\"id\":2423}},{\"nodeType\":1,\"id\":2440,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"previousSibling\":{\"id\":2439},\"parentNode\":{\"id\":2423}},{\"nodeType\":1,\"id\":2441,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"},\"parentNode\":{\"id\":2424}},{\"nodeType\":1,\"id\":2442,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"previousSibling\":{\"id\":2441},\"parentNode\":{\"id\":2424}},{\"nodeType\":1,\"id\":2443,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"},\"parentNode\":{\"id\":2425}},{\"nodeType\":1,\"id\":2444,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"previousSibling\":{\"id\":2443},\"parentNode\":{\"id\":2425}},{\"nodeType\":1,\"id\":2445,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"},\"parentNode\":{\"id\":2426}},{\"nodeType\":1,\"id\":2446,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"previousSibling\":{\"id\":2445},\"parentNode\":{\"id\":2426}},{\"nodeType\":1,\"id\":2447,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"},\"parentNode\":{\"id\":2427}},{\"nodeType\":1,\"id\":2448,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"previousSibling\":{\"id\":2447},\"parentNode\":{\"id\":2427}},{\"nodeType\":1,\"id\":2449,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"},\"parentNode\":{\"id\":2428}},{\"nodeType\":1,\"id\":2450,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"previousSibling\":{\"id\":2449},\"parentNode\":{\"id\":2428}},{\"nodeType\":1,\"id\":2451,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"},\"parentNode\":{\"id\":2429}},{\"nodeType\":1,\"id\":2452,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"previousSibling\":{\"id\":2451},\"parentNode\":{\"id\":2429}},{\"nodeType\":1,\"id\":2453,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"},\"parentNode\":{\"id\":2430}},{\"nodeType\":1,\"id\":2454,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"previousSibling\":{\"id\":2453},\"parentNode\":{\"id\":2430}},{\"nodeType\":1,\"id\":2455,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"},\"parentNode\":{\"id\":2431}},{\"nodeType\":1,\"id\":2456,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"previousSibling\":{\"id\":2455},\"parentNode\":{\"id\":2431}},{\"nodeType\":1,\"id\":2457,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"},\"parentNode\":{\"id\":2432}},{\"nodeType\":1,\"id\":2458,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"previousSibling\":{\"id\":2457},\"parentNode\":{\"id\":2432}},{\"nodeType\":1,\"id\":2459,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"},\"parentNode\":{\"id\":2433}},{\"nodeType\":1,\"id\":2460,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"previousSibling\":{\"id\":2459},\"parentNode\":{\"id\":2433}},{\"nodeType\":3,\"id\":2461,\"textContent\":\"0\",\"parentNode\":{\"id\":2436}},{\"nodeType\":3,\"id\":2462,\"textContent\":\"1\",\"parentNode\":{\"id\":2438}},{\"nodeType\":3,\"id\":2463,\"textContent\":\"2\",\"parentNode\":{\"id\":2440}},{\"nodeType\":3,\"id\":2464,\"textContent\":\"3\",\"parentNode\":{\"id\":2442}},{\"nodeType\":3,\"id\":2465,\"textContent\":\"4\",\"parentNode\":{\"id\":2444}},{\"nodeType\":3,\"id\":2466,\"textContent\":\"5\",\"parentNode\":{\"id\":2446}},{\"nodeType\":3,\"id\":2467,\"textContent\":\"6\",\"parentNode\":{\"id\":2448}},{\"nodeType\":3,\"id\":2468,\"textContent\":\"7\",\"parentNode\":{\"id\":2450}},{\"nodeType\":3,\"id\":2469,\"textContent\":\"8\",\"parentNode\":{\"id\":2452}},{\"nodeType\":3,\"id\":2470,\"textContent\":\"9\",\"parentNode\":{\"id\":2454}},{\"nodeType\":3,\"id\":2471,\"textContent\":\"10\",\"parentNode\":{\"id\":2456}},{\"nodeType\":3,\"id\":2472,\"textContent\":\"11\",\"parentNode\":{\"id\":2458}},{\"nodeType\":3,\"id\":2473,\"textContent\":\"12\",\"parentNode\":{\"id\":2460}},{\"nodeType\":1,\"id\":2474,\"tagName\":\"text\",\"attributes\":{\"transform\":\"rotate(-90)\",\"x\":\"-350\",\"y\":\"-60\",\"style\":\"text-anchor: end;\"},\"parentNode\":{\"id\":2434}},{\"nodeType\":3,\"id\":2475,\"textContent\":\"DURATION (in hours)\",\"parentNode\":{\"id\":2474}},{\"nodeType\":1,\"id\":2476,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"parentNode\":{\"id\":2313}},{\"nodeType\":1,\"id\":2477,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"previousSibling\":{\"id\":2476},\"parentNode\":{\"id\":2313}},{\"nodeType\":1,\"id\":2478,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"previousSibling\":{\"id\":2477},\"parentNode\":{\"id\":2313}},{\"nodeType\":1,\"id\":2479,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"previousSibling\":{\"id\":2478},\"parentNode\":{\"id\":2313}},{\"nodeType\":1,\"id\":2480,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"previousSibling\":{\"id\":2479},\"parentNode\":{\"id\":2313}},{\"nodeType\":1,\"id\":2481,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"previousSibling\":{\"id\":2480},\"parentNode\":{\"id\":2313}},{\"nodeType\":1,\"id\":2482,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"previousSibling\":{\"id\":2481},\"parentNode\":{\"id\":2313}},{\"nodeType\":1,\"id\":2483,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"previousSibling\":{\"id\":2482},\"parentNode\":{\"id\":2313}},{\"nodeType\":1,\"id\":2484,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"previousSibling\":{\"id\":2483},\"parentNode\":{\"id\":2313}},{\"nodeType\":1,\"id\":2485,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"previousSibling\":{\"id\":2484},\"parentNode\":{\"id\":2313}},{\"nodeType\":1,\"id\":2486,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"previousSibling\":{\"id\":2485},\"parentNode\":{\"id\":2313}},{\"nodeType\":1,\"id\":2487,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"previousSibling\":{\"id\":2486},\"parentNode\":{\"id\":2313}},{\"nodeType\":1,\"id\":2488,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"733.3333333333334\",\"y2\":\"733.3333333333334\"},\"parentNode\":{\"id\":2476}},{\"nodeType\":1,\"id\":2489,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"666.6666666666667\",\"y2\":\"666.6666666666667\"},\"parentNode\":{\"id\":2477}},{\"nodeType\":1,\"id\":2490,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"600\",\"y2\":\"600\"},\"parentNode\":{\"id\":2478}},{\"nodeType\":1,\"id\":2491,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"533.3333333333334\",\"y2\":\"533.3333333333334\"},\"parentNode\":{\"id\":2479}},{\"nodeType\":1,\"id\":2492,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"466.66666666666663\",\"y2\":\"466.66666666666663\"},\"parentNode\":{\"id\":2480}},{\"nodeType\":1,\"id\":2493,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"400\",\"y2\":\"400\"},\"parentNode\":{\"id\":2481}},{\"nodeType\":1,\"id\":2494,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"333.3333333333333\",\"y2\":\"333.3333333333333\"},\"parentNode\":{\"id\":2482}},{\"nodeType\":1,\"id\":2495,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"266.66666666666674\",\"y2\":\"266.66666666666674\"},\"parentNode\":{\"id\":2483}},{\"nodeType\":1,\"id\":2496,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"200\",\"y2\":\"200\"},\"parentNode\":{\"id\":2484}},{\"nodeType\":1,\"id\":2497,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"133.33333333333326\",\"y2\":\"133.33333333333326\"},\"parentNode\":{\"id\":2485}},{\"nodeType\":1,\"id\":2498,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"66.66666666666674\",\"y2\":\"66.66666666666674\"},\"parentNode\":{\"id\":2486}},{\"nodeType\":1,\"id\":2499,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"0\",\"y2\":\"0\"},\"parentNode\":{\"id\":2487}},{\"nodeType\":1,\"id\":2500,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"0\",\"y1\":\"800\",\"x2\":\"400\",\"y2\":\"0\"},\"parentNode\":{\"id\":2314}},{\"nodeType\":1,\"id\":2501,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"800\",\"y1\":\"800\",\"x2\":\"400\",\"y2\":\"0\"},\"previousSibling\":{\"id\":2500},\"parentNode\":{\"id\":2314}},{\"nodeType\":1,\"id\":2502,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"66.66666666666666\",\"y1\":\"800\",\"x2\":\"466.6666666666667\",\"y2\":\"0\"},\"previousSibling\":{\"id\":2501},\"parentNode\":{\"id\":2314}},{\"nodeType\":1,\"id\":2503,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"733.3333333333333\",\"y1\":\"800\",\"x2\":\"333.33333333333337\",\"y2\":\"0\"},\"previousSibling\":{\"id\":2502},\"parentNode\":{\"id\":2314}},{\"nodeType\":1,\"id\":2504,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"133.33333333333331\",\"y1\":\"800\",\"x2\":\"533.3333333333333\",\"y2\":\"0\"},\"previousSibling\":{\"id\":2503},\"parentNode\":{\"id\":2314}},{\"nodeType\":1,\"id\":2505,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"666.6666666666667\",\"y1\":\"800\",\"x2\":\"266.66666666666663\",\"y2\":\"0\"},\"previousSibling\":{\"id\":2504},\"parentNode\":{\"id\":2314}},{\"nodeType\":1,\"id\":2506,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"200\",\"y1\":\"800\",\"x2\":\"600\",\"y2\":\"0\"},\"previousSibling\":{\"id\":2505},\"parentNode\":{\"id\":2314}},{\"nodeType\":1,\"id\":2507,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"600\",\"y1\":\"800\",\"x2\":\"200\",\"y2\":\"0\"},\"previousSibling\":{\"id\":2506},\"parentNode\":{\"id\":2314}},{\"nodeType\":1,\"id\":2508,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"266.66666666666663\",\"y1\":\"800\",\"x2\":\"666.6666666666667\",\"y2\":\"0\"},\"previousSibling\":{\"id\":2507},\"parentNode\":{\"id\":2314}},{\"nodeType\":1,\"id\":2509,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"533.3333333333333\",\"y1\":\"800\",\"x2\":\"133.33333333333331\",\"y2\":\"0\"},\"previousSibling\":{\"id\":2508},\"parentNode\":{\"id\":2314}},{\"nodeType\":1,\"id\":2510,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"333.33333333333337\",\"y1\":\"800\",\"x2\":\"733.3333333333333\",\"y2\":\"0\"},\"previousSibling\":{\"id\":2509},\"parentNode\":{\"id\":2314}},{\"nodeType\":1,\"id\":2511,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"466.6666666666667\",\"y1\":\"800\",\"x2\":\"66.66666666666666\",\"y2\":\"0\"},\"previousSibling\":{\"id\":2510},\"parentNode\":{\"id\":2314}},{\"nodeType\":1,\"id\":2512,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"400\",\"y1\":\"800\",\"x2\":\"800\",\"y2\":\"0\"},\"previousSibling\":{\"id\":2511},\"parentNode\":{\"id\":2314}},{\"nodeType\":1,\"id\":2513,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"400\",\"y1\":\"800\",\"x2\":\"0\",\"y2\":\"0\"},\"previousSibling\":{\"id\":2512},\"parentNode\":{\"id\":2314}},{\"nodeType\":1,\"id\":2514,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"466.6666666666667\",\"y1\":\"800\",\"x2\":\"800\",\"y2\":\"133.33333333333326\"},\"previousSibling\":{\"id\":2513},\"parentNode\":{\"id\":2314}},{\"nodeType\":1,\"id\":2515,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"333.33333333333337\",\"y1\":\"800\",\"x2\":\"0\",\"y2\":\"133.33333333333326\"},\"previousSibling\":{\"id\":2514},\"parentNode\":{\"id\":2314}},{\"nodeType\":1,\"id\":2516,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"533.3333333333333\",\"y1\":\"800\",\"x2\":\"800\",\"y2\":\"266.66666666666674\"},\"previousSibling\":{\"id\":2515},\"parentNode\":{\"id\":2314}},{\"nodeType\":1,\"id\":2517,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"266.66666666666663\",\"y1\":\"800\",\"x2\":\"0\",\"y2\":\"266.66666666666674\"},\"previousSibling\":{\"id\":2516},\"parentNode\":{\"id\":2314}},{\"nodeType\":1,\"id\":2518,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"600\",\"y1\":\"800\",\"x2\":\"800\",\"y2\":\"400\"},\"previousSibling\":{\"id\":2517},\"parentNode\":{\"id\":2314}},{\"nodeType\":1,\"id\":2519,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"200\",\"y1\":\"800\",\"x2\":\"0\",\"y2\":\"400\"},\"previousSibling\":{\"id\":2518},\"parentNode\":{\"id\":2314}},{\"nodeType\":1,\"id\":2520,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"666.6666666666667\",\"y1\":\"800\",\"x2\":\"800\",\"y2\":\"533.3333333333334\"},\"previousSibling\":{\"id\":2519},\"parentNode\":{\"id\":2314}},{\"nodeType\":1,\"id\":2521,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"133.33333333333331\",\"y1\":\"800\",\"x2\":\"0\",\"y2\":\"533.3333333333334\"},\"previousSibling\":{\"id\":2520},\"parentNode\":{\"id\":2314}},{\"nodeType\":1,\"id\":2522,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"733.3333333333333\",\"y1\":\"800\",\"x2\":\"800\",\"y2\":\"666.6666666666667\"},\"previousSibling\":{\"id\":2521},\"parentNode\":{\"id\":2314}},{\"nodeType\":1,\"id\":2523,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"66.66666666666666\",\"y1\":\"800\",\"x2\":\"0\",\"y2\":\"666.6666666666667\"},\"previousSibling\":{\"id\":2522},\"parentNode\":{\"id\":2314}},{\"nodeType\":1,\"id\":2524,\"tagName\":\"g\",\"attributes\":{},\"parentNode\":{\"id\":2315}},{\"nodeType\":1,\"id\":2525,\"tagName\":\"g\",\"attributes\":{},\"previousSibling\":{\"id\":2524},\"parentNode\":{\"id\":2315}},{\"nodeType\":1,\"id\":2526,\"tagName\":\"g\",\"attributes\":{},\"previousSibling\":{\"id\":2525},\"parentNode\":{\"id\":2315}},{\"nodeType\":1,\"id\":2527,\"tagName\":\"g\",\"attributes\":{},\"previousSibling\":{\"id\":2526},\"parentNode\":{\"id\":2315}},{\"nodeType\":1,\"id\":2528,\"tagName\":\"g\",\"attributes\":{},\"previousSibling\":{\"id\":2527},\"parentNode\":{\"id\":2315}},{\"nodeType\":1,\"id\":2529,\"tagName\":\"g\",\"attributes\":{},\"previousSibling\":{\"id\":2528},\"parentNode\":{\"id\":2315}},{\"nodeType\":1,\"id\":2530,\"tagName\":\"g\",\"attributes\":{},\"previousSibling\":{\"id\":2529},\"parentNode\":{\"id\":2315}},{\"nodeType\":1,\"id\":2531,\"tagName\":\"g\",\"attributes\":{},\"previousSibling\":{\"id\":2530},\"parentNode\":{\"id\":2315}},{\"nodeType\":1,\"id\":2532,\"tagName\":\"g\",\"attributes\":{},\"previousSibling\":{\"id\":2531},\"parentNode\":{\"id\":2315}},{\"nodeType\":1,\"id\":2533,\"tagName\":\"g\",\"attributes\":{},\"previousSibling\":{\"id\":2532},\"parentNode\":{\"id\":2315}},{\"nodeType\":1,\"id\":2534,\"tagName\":\"g\",\"attributes\":{},\"previousSibling\":{\"id\":2533},\"parentNode\":{\"id\":2315}},{\"nodeType\":1,\"id\":2535,\"tagName\":\"g\",\"attributes\":{},\"previousSibling\":{\"id\":2534},\"parentNode\":{\"id\":2315}},{\"nodeType\":1,\"id\":2536,\"tagName\":\"g\",\"attributes\":{},\"previousSibling\":{\"id\":2535},\"parentNode\":{\"id\":2315}},{\"nodeType\":1,\"id\":2537,\"tagName\":\"g\",\"attributes\":{},\"previousSibling\":{\"id\":2536},\"parentNode\":{\"id\":2315}},{\"nodeType\":1,\"id\":2538,\"tagName\":\"g\",\"attributes\":{},\"previousSibling\":{\"id\":2537},\"parentNode\":{\"id\":2315}},{\"nodeType\":1,\"id\":2539,\"tagName\":\"g\",\"attributes\":{},\"previousSibling\":{\"id\":2538},\"parentNode\":{\"id\":2315}},{\"nodeType\":1,\"id\":2540,\"tagName\":\"g\",\"attributes\":{},\"previousSibling\":{\"id\":2539},\"parentNode\":{\"id\":2315}},{\"nodeType\":1,\"id\":2541,\"tagName\":\"g\",\"attributes\":{},\"previousSibling\":{\"id\":2540},\"parentNode\":{\"id\":2315}},{\"nodeType\":1,\"id\":2542,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"333.33333333333337\",\"cy\":\"266.66666666666674\",\"r\":\"6\",\"selected\":\"false\"},\"parentNode\":{\"id\":2524}},{\"nodeType\":1,\"id\":2543,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"328.33333333333337\",\"y\":\"258.66666666666674\"},\"previousSibling\":{\"id\":2542},\"parentNode\":{\"id\":2524}},{\"nodeType\":1,\"id\":2544,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"266.66666666666663\",\"cy\":\"600\",\"r\":\"6\",\"selected\":\"false\"},\"parentNode\":{\"id\":2525}},{\"nodeType\":1,\"id\":2545,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"261.66666666666663\",\"y\":\"592\"},\"previousSibling\":{\"id\":2544},\"parentNode\":{\"id\":2525}},{\"nodeType\":1,\"id\":2546,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"366.66666666666663\",\"cy\":\"466.66666666666663\",\"r\":\"6\",\"selected\":\"false\"},\"parentNode\":{\"id\":2526}},{\"nodeType\":1,\"id\":2547,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"361.66666666666663\",\"y\":\"458.66666666666663\"},\"previousSibling\":{\"id\":2546},\"parentNode\":{\"id\":2526}},{\"nodeType\":1,\"id\":2548,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"666.6666666666667\",\"cy\":\"666.6666666666667\",\"r\":\"6\",\"selected\":\"false\"},\"parentNode\":{\"id\":2527}},{\"nodeType\":1,\"id\":2549,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"661.6666666666667\",\"y\":\"658.6666666666667\"},\"previousSibling\":{\"id\":2548},\"parentNode\":{\"id\":2527}},{\"nodeType\":1,\"id\":2550,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"200\",\"cy\":\"400\",\"r\":\"6\",\"selected\":\"false\"},\"parentNode\":{\"id\":2528}},{\"nodeType\":1,\"id\":2551,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"195\",\"y\":\"392\"},\"previousSibling\":{\"id\":2550},\"parentNode\":{\"id\":2528}},{\"nodeType\":1,\"id\":2552,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"266.66666666666663\",\"cy\":\"533.3333333333334\",\"r\":\"6\",\"selected\":\"false\"},\"parentNode\":{\"id\":2529}},{\"nodeType\":1,\"id\":2553,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"261.66666666666663\",\"y\":\"525.3333333333334\"},\"previousSibling\":{\"id\":2552},\"parentNode\":{\"id\":2529}},{\"nodeType\":1,\"id\":2554,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"333.33333333333337\",\"cy\":\"400\",\"r\":\"6\",\"selected\":\"false\"},\"parentNode\":{\"id\":2530}},{\"nodeType\":1,\"id\":2555,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"328.33333333333337\",\"y\":\"392\"},\"previousSibling\":{\"id\":2554},\"parentNode\":{\"id\":2530}},{\"nodeType\":1,\"id\":2556,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"500\",\"cy\":\"466.66666666666663\",\"r\":\"6\",\"selected\":\"false\"},\"parentNode\":{\"id\":2531}},{\"nodeType\":1,\"id\":2557,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"495\",\"y\":\"458.66666666666663\"},\"previousSibling\":{\"id\":2556},\"parentNode\":{\"id\":2531}},{\"nodeType\":1,\"id\":2558,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"100\",\"cy\":\"600\",\"r\":\"6\",\"selected\":\"false\"},\"parentNode\":{\"id\":2532}},{\"nodeType\":1,\"id\":2559,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"95\",\"y\":\"592\"},\"previousSibling\":{\"id\":2558},\"parentNode\":{\"id\":2532}},{\"nodeType\":1,\"id\":2560,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"133.33333333333331\",\"cy\":\"666.6666666666667\",\"r\":\"6\",\"selected\":\"false\"},\"parentNode\":{\"id\":2533}},{\"nodeType\":1,\"id\":2561,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"128.33333333333331\",\"y\":\"658.6666666666667\"},\"previousSibling\":{\"id\":2560},\"parentNode\":{\"id\":2533}},{\"nodeType\":1,\"id\":2562,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"400\",\"cy\":\"133.33333333333326\",\"r\":\"6\",\"selected\":\"false\"},\"parentNode\":{\"id\":2534}},{\"nodeType\":1,\"id\":2563,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"395\",\"y\":\"125.33333333333326\"},\"previousSibling\":{\"id\":2562},\"parentNode\":{\"id\":2534}},{\"nodeType\":1,\"id\":2564,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"500\",\"cy\":\"333.3333333333333\",\"r\":\"6\",\"selected\":\"false\"},\"parentNode\":{\"id\":2535}},{\"nodeType\":1,\"id\":2565,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"495\",\"y\":\"325.3333333333333\"},\"previousSibling\":{\"id\":2564},\"parentNode\":{\"id\":2535}},{\"nodeType\":1,\"id\":2566,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"300\",\"cy\":\"733.3333333333334\",\"r\":\"6\",\"selected\":\"false\"},\"parentNode\":{\"id\":2536}},{\"nodeType\":1,\"id\":2567,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"295\",\"y\":\"725.3333333333334\"},\"previousSibling\":{\"id\":2566},\"parentNode\":{\"id\":2536}},{\"nodeType\":1,\"id\":2568,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"600\",\"cy\":\"666.6666666666667\",\"r\":\"6\",\"selected\":\"false\"},\"parentNode\":{\"id\":2537}},{\"nodeType\":1,\"id\":2569,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"595\",\"y\":\"658.6666666666667\"},\"previousSibling\":{\"id\":2568},\"parentNode\":{\"id\":2537}},{\"nodeType\":1,\"id\":2570,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"433.3333333333333\",\"cy\":\"600\",\"r\":\"6\",\"selected\":\"false\"},\"parentNode\":{\"id\":2538}},{\"nodeType\":1,\"id\":2571,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"428.3333333333333\",\"y\":\"592\"},\"previousSibling\":{\"id\":2570},\"parentNode\":{\"id\":2538}},{\"nodeType\":1,\"id\":2572,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"500\",\"cy\":\"200\",\"r\":\"6\",\"selected\":\"false\"},\"parentNode\":{\"id\":2539}},{\"nodeType\":1,\"id\":2573,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"495\",\"y\":\"192\"},\"previousSibling\":{\"id\":2572},\"parentNode\":{\"id\":2539}},{\"nodeType\":1,\"id\":2574,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"533.3333333333333\",\"cy\":\"533.3333333333334\",\"r\":\"6\",\"selected\":\"false\"},\"parentNode\":{\"id\":2540}},{\"nodeType\":1,\"id\":2575,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"528.3333333333333\",\"y\":\"525.3333333333334\"},\"previousSibling\":{\"id\":2574},\"parentNode\":{\"id\":2540}},{\"nodeType\":1,\"id\":2576,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"400\",\"cy\":\"666.6666666666667\",\"r\":\"6\",\"selected\":\"false\"},\"parentNode\":{\"id\":2541}},{\"nodeType\":1,\"id\":2577,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"395\",\"y\":\"658.6666666666667\"},\"previousSibling\":{\"id\":2576},\"parentNode\":{\"id\":2541}},{\"nodeType\":3,\"id\":2578,\"textContent\":\"A \",\"parentNode\":{\"id\":2543}},{\"nodeType\":3,\"id\":2579,\"textContent\":\"B \",\"parentNode\":{\"id\":2545}},{\"nodeType\":3,\"id\":2580,\"textContent\":\"C \",\"parentNode\":{\"id\":2547}},{\"nodeType\":3,\"id\":2581,\"textContent\":\"D \",\"parentNode\":{\"id\":2549}},{\"nodeType\":3,\"id\":2582,\"textContent\":\"E \",\"parentNode\":{\"id\":2551}},{\"nodeType\":3,\"id\":2583,\"textContent\":\"F \",\"parentNode\":{\"id\":2553}},{\"nodeType\":3,\"id\":2584,\"textContent\":\"G \",\"parentNode\":{\"id\":2555}},{\"nodeType\":3,\"id\":2585,\"textContent\":\"H \",\"parentNode\":{\"id\":2557}},{\"nodeType\":3,\"id\":2586,\"textContent\":\"I \",\"parentNode\":{\"id\":2559}},{\"nodeType\":3,\"id\":2587,\"textContent\":\"J \",\"parentNode\":{\"id\":2561}},{\"nodeType\":3,\"id\":2588,\"textContent\":\"K \",\"parentNode\":{\"id\":2563}},{\"nodeType\":3,\"id\":2589,\"textContent\":\"L \",\"parentNode\":{\"id\":2565}},{\"nodeType\":3,\"id\":2590,\"textContent\":\"M \",\"parentNode\":{\"id\":2567}},{\"nodeType\":3,\"id\":2591,\"textContent\":\"N \",\"parentNode\":{\"id\":2569}},{\"nodeType\":3,\"id\":2592,\"textContent\":\"O \",\"parentNode\":{\"id\":2571}},{\"nodeType\":3,\"id\":2593,\"textContent\":\"P \",\"parentNode\":{\"id\":2573}},{\"nodeType\":3,\"id\":2594,\"textContent\":\"Z \",\"parentNode\":{\"id\":2575}},{\"nodeType\":3,\"id\":2595,\"textContent\":\"X \",\"parentNode\":{\"id\":2577}}],[],[]]}"
    },
    {
      "sequence": 2,
      "data": "{\"f\":\"applyChanged\",\"args\":[[{\"id\":56},{\"id\":57},{\"id\":58},{\"id\":59},{\"id\":60},{\"id\":61},{\"id\":62},{\"id\":63},{\"id\":64},{\"id\":65},{\"id\":66},{\"id\":67},{\"id\":68},{\"id\":69},{\"id\":70},{\"id\":71},{\"id\":72},{\"id\":73},{\"id\":74},{\"id\":75},{\"id\":76},{\"id\":77},{\"id\":78},{\"id\":79},{\"id\":80},{\"id\":81},{\"id\":82},{\"id\":83},{\"id\":84},{\"id\":85},{\"id\":86},{\"id\":87},{\"id\":88},{\"id\":89},{\"id\":90},{\"id\":91},{\"id\":92},{\"id\":93},{\"id\":94},{\"id\":95},{\"id\":96},{\"id\":97},{\"id\":98},{\"id\":99},{\"id\":100},{\"id\":101},{\"id\":102},{\"id\":103},{\"id\":104},{\"id\":105},{\"id\":106},{\"id\":107},{\"id\":108},{\"id\":109},{\"id\":110},{\"id\":111},{\"id\":112},{\"id\":113},{\"id\":114},{\"id\":115},{\"id\":116},{\"id\":117},{\"id\":118},{\"id\":119},{\"id\":120},{\"id\":121},{\"id\":122},{\"id\":123},{\"id\":124},{\"id\":125},{\"id\":126},{\"id\":127},{\"id\":128},{\"id\":129},{\"id\":130},{\"id\":131},{\"id\":132},{\"id\":133},{\"id\":134},{\"id\":135},{\"id\":136},{\"id\":137},{\"id\":138},{\"id\":139},{\"id\":140},{\"id\":141},{\"id\":142},{\"id\":143},{\"id\":144},{\"id\":145},{\"id\":146},{\"id\":147},{\"id\":148},{\"id\":149},{\"id\":150},{\"id\":151},{\"id\":152},{\"id\":153},{\"id\":154},{\"id\":155},{\"id\":156},{\"id\":157},{\"id\":158},{\"id\":159},{\"id\":160},{\"id\":161},{\"id\":162},{\"id\":163},{\"id\":164},{\"id\":165},{\"id\":166},{\"id\":167},{\"id\":168},{\"id\":169},{\"id\":170},{\"id\":171},{\"id\":172},{\"id\":173},{\"id\":174},{\"id\":175},{\"id\":176},{\"id\":177},{\"id\":178},{\"id\":179},{\"id\":180},{\"id\":181},{\"id\":182},{\"id\":183},{\"id\":184},{\"id\":185},{\"id\":186},{\"id\":187},{\"id\":188},{\"id\":189},{\"id\":190},{\"id\":191},{\"id\":192},{\"id\":193},{\"id\":194},{\"id\":195},{\"id\":196},{\"id\":197},{\"id\":198},{\"id\":199},{\"id\":200},{\"id\":201},{\"id\":202},{\"id\":203},{\"id\":204},{\"id\":205},{\"id\":206},{\"id\":207},{\"id\":208},{\"id\":209},{\"id\":210},{\"id\":211},{\"id\":212},{\"id\":213},{\"id\":214},{\"id\":215},{\"id\":216},{\"id\":217},{\"id\":218},{\"id\":219},{\"id\":220},{\"id\":221},{\"id\":222},{\"id\":223},{\"id\":224},{\"id\":225},{\"id\":226},{\"id\":227},{\"id\":228},{\"id\":229},{\"id\":230},{\"id\":231},{\"id\":232},{\"id\":233},{\"id\":234},{\"id\":235},{\"id\":236},{\"id\":237},{\"id\":238},{\"id\":239},{\"id\":240},{\"id\":241},{\"id\":242},{\"id\":243},{\"id\":244},{\"id\":245},{\"id\":246},{\"id\":247},{\"id\":248},{\"id\":249},{\"id\":250},{\"id\":251},{\"id\":252},{\"id\":253},{\"id\":254},{\"id\":255},{\"id\":256},{\"id\":257},{\"id\":258},{\"id\":259},{\"id\":260},{\"id\":261},{\"id\":262},{\"id\":263},{\"id\":264},{\"id\":265},{\"id\":266},{\"id\":267},{\"id\":268},{\"id\":269},{\"id\":270},{\"id\":271},{\"id\":272},{\"id\":273},{\"id\":274},{\"id\":275},{\"id\":276},{\"id\":277},{\"id\":278},{\"id\":279},{\"id\":280},{\"id\":281},{\"id\":282},{\"id\":283},{\"id\":284},{\"id\":285},{\"id\":286},{\"id\":287},{\"id\":288},{\"id\":289},{\"id\":290},{\"id\":291},{\"id\":292},{\"id\":293},{\"id\":294},{\"id\":295},{\"id\":296},{\"id\":297},{\"id\":298},{\"id\":299},{\"id\":300},{\"id\":301},{\"id\":302},{\"id\":303},{\"id\":304},{\"id\":305},{\"id\":306},{\"id\":307},{\"id\":308},{\"id\":309},{\"id\":310},{\"id\":311},{\"id\":312},{\"id\":313},{\"id\":314},{\"id\":315},{\"id\":316},{\"id\":317},{\"id\":318},{\"id\":319},{\"id\":320},{\"id\":321},{\"id\":322},{\"id\":323},{\"id\":324},{\"id\":325},{\"id\":326},{\"id\":327},{\"id\":328},{\"id\":329},{\"id\":330},{\"id\":331},{\"id\":332},{\"id\":333},{\"id\":334},{\"id\":335},{\"id\":336},{\"id\":337},{\"id\":338},{\"id\":339},{\"id\":340},{\"id\":341},{\"id\":342},{\"id\":343},{\"id\":344},{\"id\":345},{\"id\":346},{\"id\":347},{\"id\":348},{\"id\":349},{\"id\":350},{\"id\":351},{\"id\":352},{\"id\":353},{\"id\":354},{\"id\":355},{\"id\":356},{\"id\":357},{\"id\":358},{\"id\":359},{\"id\":360},{\"id\":361},{\"id\":362},{\"id\":363},{\"id\":364},{\"id\":365},{\"id\":366},{\"id\":367},{\"id\":368},{\"id\":369},{\"id\":370},{\"id\":371},{\"id\":372},{\"id\":373},{\"id\":374},{\"id\":375},{\"id\":376},{\"id\":377},{\"id\":378},{\"id\":379},{\"id\":380},{\"id\":381},{\"id\":382},{\"id\":383},{\"id\":384},{\"id\":385},{\"id\":386},{\"id\":387},{\"id\":388},{\"id\":389},{\"id\":390},{\"id\":391},{\"id\":392},{\"id\":393},{\"id\":394},{\"id\":395},{\"id\":396},{\"id\":397},{\"id\":398},{\"id\":399},{\"id\":400},{\"id\":401},{\"id\":402},{\"id\":403},{\"id\":404},{\"id\":405},{\"id\":406},{\"id\":407},{\"id\":408},{\"id\":409},{\"id\":410},{\"id\":411},{\"id\":412},{\"id\":413},{\"id\":414},{\"id\":415},{\"id\":416},{\"id\":417},{\"id\":418},{\"id\":419},{\"id\":420},{\"id\":421},{\"id\":422},{\"id\":423},{\"id\":424},{\"id\":425},{\"id\":426},{\"id\":427},{\"id\":428},{\"id\":429},{\"id\":430},{\"id\":431},{\"id\":432},{\"id\":433},{\"id\":434},{\"id\":435},{\"id\":436},{\"id\":437},{\"id\":438},{\"id\":439},{\"id\":440},{\"id\":441},{\"id\":442},{\"id\":443},{\"id\":444},{\"id\":445},{\"id\":446},{\"id\":447},{\"id\":448},{\"id\":449},{\"id\":450},{\"id\":451},{\"id\":452},{\"id\":453},{\"id\":454},{\"id\":455},{\"id\":456},{\"id\":457},{\"id\":458},{\"id\":459},{\"id\":460},{\"id\":461},{\"id\":462},{\"id\":463},{\"id\":464},{\"id\":465},{\"id\":466},{\"id\":467},{\"id\":468},{\"id\":469},{\"id\":470},{\"id\":471},{\"id\":472},{\"id\":473},{\"id\":474},{\"id\":475},{\"id\":476},{\"id\":477},{\"id\":478},{\"id\":479},{\"id\":480},{\"id\":481},{\"id\":482},{\"id\":483},{\"id\":484},{\"id\":485},{\"id\":486},{\"id\":487},{\"id\":488},{\"id\":489},{\"id\":490},{\"id\":491},{\"id\":492},{\"id\":493},{\"id\":494},{\"id\":495},{\"id\":496},{\"id\":497},{\"id\":498},{\"id\":499},{\"id\":500},{\"id\":501},{\"id\":502},{\"id\":503},{\"id\":504},{\"id\":505},{\"id\":506},{\"id\":507},{\"id\":508},{\"id\":509},{\"id\":510},{\"id\":511},{\"id\":512},{\"id\":513},{\"id\":514},{\"id\":515},{\"id\":516},{\"id\":517},{\"id\":518},{\"id\":519},{\"id\":520},{\"id\":521},{\"id\":522},{\"id\":523},{\"id\":524},{\"id\":525},{\"id\":526},{\"id\":527},{\"id\":528},{\"id\":529},{\"id\":530},{\"id\":531},{\"id\":532},{\"id\":533},{\"id\":534},{\"id\":535},{\"id\":536},{\"id\":537},{\"id\":538},{\"id\":539},{\"id\":540},{\"id\":541},{\"id\":542},{\"id\":543},{\"id\":544},{\"id\":545},{\"id\":546},{\"id\":547},{\"id\":548},{\"id\":549},{\"id\":550},{\"id\":551},{\"id\":552},{\"id\":553},{\"id\":554},{\"id\":555},{\"id\":556},{\"id\":557},{\"id\":558},{\"id\":559},{\"id\":560},{\"id\":561},{\"id\":562},{\"id\":563},{\"id\":564},{\"id\":565},{\"id\":566},{\"id\":567},{\"id\":568},{\"id\":569},{\"id\":570},{\"id\":571},{\"id\":572},{\"id\":573},{\"id\":574},{\"id\":575},{\"id\":576},{\"id\":577},{\"id\":578},{\"id\":579},{\"id\":580},{\"id\":581},{\"id\":582},{\"id\":583},{\"id\":584},{\"id\":585},{\"id\":586},{\"id\":587},{\"id\":588},{\"id\":589},{\"id\":590},{\"id\":591},{\"id\":592},{\"id\":593},{\"id\":594},{\"id\":595},{\"id\":596},{\"id\":597},{\"id\":598},{\"id\":599},{\"id\":600},{\"id\":601},{\"id\":602},{\"id\":603},{\"id\":604},{\"id\":605},{\"id\":606},{\"id\":607},{\"id\":608},{\"id\":609},{\"id\":610},{\"id\":611},{\"id\":612},{\"id\":613},{\"id\":614},{\"id\":615},{\"id\":616},{\"id\":617},{\"id\":618},{\"id\":619},{\"id\":620},{\"id\":621},{\"id\":622},{\"id\":623},{\"id\":624},{\"id\":625},{\"id\":626},{\"id\":627},{\"id\":628},{\"id\":629},{\"id\":630},{\"id\":631},{\"id\":632},{\"id\":633},{\"id\":634},{\"id\":635},{\"id\":636},{\"id\":637},{\"id\":638},{\"id\":639},{\"id\":640},{\"id\":641},{\"id\":642},{\"id\":643},{\"id\":644},{\"id\":645},{\"id\":646},{\"id\":647},{\"id\":648},{\"id\":649},{\"id\":650},{\"id\":651},{\"id\":652},{\"id\":653},{\"id\":654},{\"id\":655},{\"id\":656},{\"id\":657},{\"id\":658},{\"id\":659},{\"id\":660},{\"id\":661},{\"id\":662},{\"id\":663},{\"id\":664},{\"id\":665},{\"id\":666},{\"id\":667},{\"id\":668},{\"id\":669},{\"id\":670},{\"id\":671},{\"id\":672},{\"id\":673},{\"id\":674},{\"id\":675},{\"id\":676},{\"id\":677},{\"id\":678},{\"id\":679},{\"id\":680},{\"id\":681},{\"id\":682},{\"id\":683},{\"id\":684},{\"id\":685},{\"id\":686},{\"id\":687},{\"id\":688},{\"id\":689},{\"id\":690},{\"id\":691},{\"id\":692},{\"id\":693},{\"id\":694},{\"id\":695},{\"id\":696},{\"id\":697},{\"id\":698},{\"id\":699},{\"id\":700},{\"id\":701},{\"id\":702},{\"id\":703},{\"id\":704},{\"id\":705},{\"id\":706},{\"id\":707},{\"id\":708},{\"id\":709},{\"id\":710},{\"id\":711},{\"id\":712},{\"id\":713},{\"id\":714},{\"id\":715},{\"id\":716},{\"id\":717},{\"id\":718},{\"id\":719},{\"id\":720},{\"id\":721},{\"id\":722},{\"id\":723},{\"id\":724},{\"id\":725},{\"id\":726},{\"id\":727},{\"id\":728},{\"id\":729},{\"id\":730},{\"id\":731},{\"id\":732},{\"id\":733},{\"id\":734},{\"id\":735},{\"id\":736},{\"id\":737},{\"id\":738},{\"id\":739},{\"id\":740},{\"id\":741},{\"id\":742},{\"id\":743},{\"id\":744},{\"id\":745},{\"id\":746},{\"id\":747},{\"id\":748},{\"id\":749},{\"id\":750},{\"id\":751},{\"id\":752},{\"id\":753},{\"id\":754},{\"id\":755},{\"id\":756},{\"id\":757},{\"id\":758},{\"id\":759},{\"id\":760},{\"id\":761},{\"id\":762},{\"id\":763},{\"id\":764},{\"id\":765},{\"id\":766},{\"id\":767},{\"id\":768},{\"id\":769},{\"id\":770},{\"id\":771},{\"id\":772},{\"id\":773},{\"id\":774},{\"id\":775},{\"id\":776},{\"id\":777},{\"id\":778},{\"id\":779},{\"id\":780},{\"id\":781},{\"id\":782},{\"id\":783},{\"id\":784},{\"id\":785},{\"id\":786},{\"id\":787},{\"id\":788},{\"id\":789},{\"id\":790},{\"id\":791},{\"id\":792},{\"id\":793},{\"id\":794},{\"id\":795},{\"id\":796},{\"id\":797},{\"id\":798},{\"id\":799},{\"id\":800},{\"id\":801},{\"id\":802},{\"id\":803},{\"id\":804},{\"id\":805},{\"id\":806},{\"id\":807},{\"id\":808},{\"id\":809},{\"id\":810},{\"id\":811},{\"id\":812},{\"id\":813},{\"id\":814},{\"id\":815},{\"id\":816},{\"id\":817},{\"id\":818},{\"id\":819},{\"id\":820},{\"id\":821},{\"id\":822},{\"id\":823},{\"id\":824},{\"id\":825},{\"id\":826},{\"id\":827},{\"id\":828},{\"id\":829},{\"id\":830},{\"id\":831},{\"id\":832},{\"id\":833},{\"id\":834},{\"id\":835},{\"id\":836},{\"id\":837},{\"id\":838},{\"id\":839},{\"id\":840},{\"id\":841},{\"id\":842},{\"id\":843},{\"id\":844},{\"id\":845},{\"id\":846},{\"id\":847},{\"id\":848},{\"id\":849},{\"id\":850},{\"id\":851},{\"id\":852},{\"id\":853},{\"id\":854},{\"id\":855},{\"id\":856},{\"id\":857},{\"id\":858},{\"id\":859},{\"id\":860},{\"id\":861},{\"id\":862},{\"id\":863},{\"id\":864},{\"id\":865},{\"id\":866},{\"id\":867},{\"id\":868},{\"id\":869},{\"id\":870},{\"id\":871},{\"id\":872},{\"id\":873},{\"id\":874},{\"id\":875},{\"id\":876},{\"id\":877},{\"id\":878},{\"id\":879},{\"id\":880},{\"id\":881},{\"id\":882},{\"id\":883},{\"id\":884},{\"id\":885},{\"id\":886},{\"id\":887},{\"id\":888},{\"id\":889},{\"id\":890},{\"id\":891},{\"id\":892},{\"id\":893},{\"id\":894},{\"id\":895},{\"id\":896},{\"id\":897},{\"id\":898},{\"id\":899},{\"id\":900},{\"id\":901},{\"id\":902},{\"id\":903},{\"id\":904},{\"id\":905},{\"id\":906},{\"id\":907},{\"id\":908},{\"id\":909},{\"id\":910},{\"id\":911},{\"id\":912},{\"id\":913},{\"id\":914},{\"id\":915},{\"id\":916},{\"id\":917},{\"id\":918},{\"id\":919},{\"id\":920},{\"id\":921},{\"id\":922},{\"id\":923},{\"id\":924},{\"id\":925},{\"id\":926},{\"id\":927},{\"id\":928},{\"id\":929},{\"id\":930},{\"id\":931},{\"id\":932},{\"id\":933},{\"id\":934},{\"id\":935},{\"id\":936},{\"id\":937},{\"id\":938},{\"id\":939},{\"id\":940},{\"id\":941},{\"id\":942},{\"id\":943},{\"id\":944},{\"id\":945},{\"id\":946},{\"id\":947},{\"id\":948},{\"id\":949},{\"id\":950},{\"id\":951},{\"id\":952},{\"id\":953},{\"id\":954},{\"id\":955},{\"id\":956},{\"id\":957},{\"id\":958},{\"id\":959},{\"id\":960},{\"id\":961},{\"id\":962},{\"id\":963},{\"id\":964},{\"id\":965},{\"id\":966},{\"id\":967},{\"id\":968},{\"id\":969},{\"id\":970},{\"id\":971},{\"id\":972},{\"id\":973},{\"id\":974},{\"id\":975},{\"id\":976},{\"id\":977},{\"id\":978},{\"id\":979},{\"id\":980},{\"id\":981},{\"id\":982},{\"id\":983},{\"id\":984},{\"id\":985},{\"id\":986},{\"id\":987},{\"id\":988},{\"id\":989},{\"id\":990},{\"id\":991},{\"id\":992},{\"id\":993},{\"id\":994},{\"id\":995},{\"id\":996},{\"id\":997},{\"id\":998},{\"id\":999},{\"id\":1000},{\"id\":1001},{\"id\":1002},{\"id\":1003},{\"id\":1004},{\"id\":1005},{\"id\":1006},{\"id\":1007},{\"id\":1008},{\"id\":1009},{\"id\":1010},{\"id\":1011},{\"id\":1012},{\"id\":1013},{\"id\":1014},{\"id\":1015},{\"id\":1016},{\"id\":1017},{\"id\":1018},{\"id\":1019},{\"id\":1020},{\"id\":1021},{\"id\":1022},{\"id\":1023},{\"id\":1024},{\"id\":1025},{\"id\":1026},{\"id\":1027},{\"id\":1028},{\"id\":1029},{\"id\":1030},{\"id\":1031},{\"id\":1032},{\"id\":1033},{\"id\":1034},{\"id\":1035},{\"id\":1036},{\"id\":1037},{\"id\":1038},{\"id\":1039},{\"id\":1040},{\"id\":1041},{\"id\":1042},{\"id\":1043},{\"id\":1044},{\"id\":1045},{\"id\":1046},{\"id\":1047},{\"id\":1048},{\"id\":1049},{\"id\":1050},{\"id\":1051},{\"id\":1052},{\"id\":1053},{\"id\":1054},{\"id\":1055},{\"id\":1056},{\"id\":1057},{\"id\":1058},{\"id\":1059},{\"id\":1060},{\"id\":1061},{\"id\":1062},{\"id\":1063},{\"id\":1064},{\"id\":1065},{\"id\":1066},{\"id\":1067},{\"id\":1068},{\"id\":1069},{\"id\":1070},{\"id\":1071},{\"id\":1072},{\"id\":1073},{\"id\":1074},{\"id\":1075},{\"id\":1076},{\"id\":1077},{\"id\":1078},{\"id\":1079},{\"id\":1080},{\"id\":1081},{\"id\":1082},{\"id\":1083},{\"id\":1084},{\"id\":1085},{\"id\":1086},{\"id\":1087},{\"id\":1088},{\"id\":1089},{\"id\":1090},{\"id\":1091},{\"id\":1092},{\"id\":1093},{\"id\":1094},{\"id\":1095},{\"id\":1096},{\"id\":1097},{\"id\":1098},{\"id\":1099},{\"id\":1100},{\"id\":1101},{\"id\":1102},{\"id\":1103},{\"id\":1104},{\"id\":1105},{\"id\":1106},{\"id\":1107},{\"id\":1108},{\"id\":1109},{\"id\":1110},{\"id\":1111},{\"id\":1112},{\"id\":1113},{\"id\":1114},{\"id\":1115},{\"id\":1116},{\"id\":1117},{\"id\":1118},{\"id\":1119},{\"id\":1120},{\"id\":1121},{\"id\":1122},{\"id\":1123},{\"id\":1124},{\"id\":1125},{\"id\":1126},{\"id\":1127},{\"id\":1128},{\"id\":1129},{\"id\":1130},{\"id\":1131},{\"id\":1132},{\"id\":1133},{\"id\":1134},{\"id\":1135},{\"id\":1136},{\"id\":1137},{\"id\":1138},{\"id\":1139},{\"id\":1140},{\"id\":1141},{\"id\":1142},{\"id\":1143},{\"id\":1144},{\"id\":1145},{\"id\":1146},{\"id\":1147},{\"id\":1148},{\"id\":1149},{\"id\":1150},{\"id\":1151},{\"id\":1152},{\"id\":1153},{\"id\":1154},{\"id\":1155},{\"id\":1156},{\"id\":1157},{\"id\":1158},{\"id\":1159},{\"id\":1160},{\"id\":1161},{\"id\":1162},{\"id\":1163},{\"id\":1164},{\"id\":1165},{\"id\":1166},{\"id\":1167},{\"id\":1168},{\"id\":1169},{\"id\":1170},{\"id\":1171},{\"id\":1172},{\"id\":1173},{\"id\":1174},{\"id\":1175},{\"id\":1176},{\"id\":1177},{\"id\":1178},{\"id\":1179},{\"id\":1180},{\"id\":1181},{\"id\":1182},{\"id\":1183},{\"id\":1184},{\"id\":1185},{\"id\":1186},{\"id\":1187},{\"id\":1188},{\"id\":1189},{\"id\":1190},{\"id\":1191},{\"id\":1192},{\"id\":1193},{\"id\":1194},{\"id\":1195},{\"id\":1196},{\"id\":1197},{\"id\":1198},{\"id\":1199},{\"id\":1200},{\"id\":1201},{\"id\":1202},{\"id\":1203},{\"id\":1204},{\"id\":1205},{\"id\":1206},{\"id\":1207},{\"id\":1208},{\"id\":1209},{\"id\":1210},{\"id\":1211},{\"id\":1212},{\"id\":1213},{\"id\":1214},{\"id\":1215},{\"id\":1216},{\"id\":1217},{\"id\":1218},{\"id\":1219},{\"id\":1220},{\"id\":1221},{\"id\":1222},{\"id\":1223},{\"id\":1224},{\"id\":1225},{\"id\":1226},{\"id\":1227},{\"id\":1228},{\"id\":1229},{\"id\":1230},{\"id\":1231},{\"id\":1232},{\"id\":1233},{\"id\":1234},{\"id\":1235},{\"id\":1236},{\"id\":1237},{\"id\":1238},{\"id\":1239},{\"id\":1240},{\"id\":1241},{\"id\":1242},{\"id\":1243},{\"id\":1244},{\"id\":1245},{\"id\":1246},{\"id\":1247},{\"id\":1248},{\"id\":1249},{\"id\":1250},{\"id\":1251},{\"id\":1252},{\"id\":1253},{\"id\":1254},{\"id\":1255},{\"id\":1256},{\"id\":1257},{\"id\":1258},{\"id\":1259},{\"id\":1260},{\"id\":1261},{\"id\":1262},{\"id\":1263},{\"id\":1264},{\"id\":1265},{\"id\":1266},{\"id\":1267},{\"id\":1268},{\"id\":1269},{\"id\":1270},{\"id\":1271},{\"id\":1272},{\"id\":1273},{\"id\":1274},{\"id\":1275},{\"id\":1276},{\"id\":1277},{\"id\":1278},{\"id\":1279},{\"id\":1280},{\"id\":1281},{\"id\":1282},{\"id\":1283},{\"id\":1284},{\"id\":1285},{\"id\":1286},{\"id\":1287},{\"id\":1288},{\"id\":1289},{\"id\":1290},{\"id\":1291},{\"id\":1292},{\"id\":1293},{\"id\":1294},{\"id\":1295},{\"id\":1296},{\"id\":1297},{\"id\":1298},{\"id\":1299},{\"id\":1300},{\"id\":1301},{\"id\":1302},{\"id\":1303},{\"id\":1304},{\"id\":1305},{\"id\":1306},{\"id\":1307},{\"id\":1308},{\"id\":1309},{\"id\":1310},{\"id\":1311},{\"id\":1312},{\"id\":1313},{\"id\":1314},{\"id\":1315},{\"id\":1316},{\"id\":1317},{\"id\":1318},{\"id\":1319},{\"id\":1320},{\"id\":1321},{\"id\":1322},{\"id\":1323},{\"id\":1324},{\"id\":1325},{\"id\":1326},{\"id\":1327},{\"id\":1328},{\"id\":1329},{\"id\":1330},{\"id\":1331},{\"id\":1332},{\"id\":1333},{\"id\":1334},{\"id\":1335},{\"id\":1336},{\"id\":1337},{\"id\":1338},{\"id\":1339},{\"id\":1340},{\"id\":1341},{\"id\":1342},{\"id\":1343},{\"id\":1344},{\"id\":1345},{\"id\":1346},{\"id\":1347},{\"id\":1348},{\"id\":1349},{\"id\":1350},{\"id\":1351},{\"id\":1352},{\"id\":1353},{\"id\":1354},{\"id\":1355},{\"id\":1356},{\"id\":1357},{\"id\":1358},{\"id\":1359},{\"id\":1360},{\"id\":1361},{\"id\":1362},{\"id\":1363},{\"id\":1364},{\"id\":1365},{\"id\":1366},{\"id\":1367},{\"id\":1368},{\"id\":1369},{\"id\":1370},{\"id\":1371},{\"id\":1372},{\"id\":1373},{\"id\":1374},{\"id\":1375},{\"id\":1376},{\"id\":1377},{\"id\":1378},{\"id\":1379},{\"id\":1380},{\"id\":1381},{\"id\":1382},{\"id\":1383},{\"id\":1384},{\"id\":1385},{\"id\":1386},{\"id\":1387},{\"id\":1388},{\"id\":1389},{\"id\":1390},{\"id\":1391},{\"id\":1392},{\"id\":1393},{\"id\":1394},{\"id\":1395},{\"id\":1396},{\"id\":1397},{\"id\":1398},{\"id\":1399},{\"id\":1400},{\"id\":1401},{\"id\":1402},{\"id\":1403},{\"id\":1404},{\"id\":1405},{\"id\":1406},{\"id\":1407},{\"id\":1408},{\"id\":1409},{\"id\":1410},{\"id\":1411},{\"id\":1412},{\"id\":1413},{\"id\":1414},{\"id\":1415},{\"id\":1416},{\"id\":1417},{\"id\":1418},{\"id\":1419},{\"id\":1420},{\"id\":1421},{\"id\":1422},{\"id\":1423},{\"id\":1424},{\"id\":1425},{\"id\":1426},{\"id\":1427},{\"id\":1428},{\"id\":1429},{\"id\":1430},{\"id\":1431},{\"id\":1432},{\"id\":1433},{\"id\":1434},{\"id\":1435},{\"id\":1436},{\"id\":1437},{\"id\":1438},{\"id\":1439},{\"id\":1440},{\"id\":1441},{\"id\":1442},{\"id\":1443},{\"id\":1444},{\"id\":1445},{\"id\":1446},{\"id\":1447},{\"id\":1448},{\"id\":1449},{\"id\":1450},{\"id\":1451},{\"id\":1452},{\"id\":1453},{\"id\":1454},{\"id\":1455},{\"id\":1456},{\"id\":1457},{\"id\":1458},{\"id\":1459},{\"id\":1460},{\"id\":1461},{\"id\":1462},{\"id\":1463},{\"id\":1464},{\"id\":1465},{\"id\":1466},{\"id\":1467},{\"id\":1468},{\"id\":1469},{\"id\":1470},{\"id\":1471},{\"id\":1472},{\"id\":1473},{\"id\":1474},{\"id\":1475},{\"id\":1476},{\"id\":1477},{\"id\":1478},{\"id\":1479},{\"id\":1480},{\"id\":1481},{\"id\":1482},{\"id\":1483},{\"id\":1484},{\"id\":1485},{\"id\":1486},{\"id\":1487},{\"id\":1488},{\"id\":1489},{\"id\":1490},{\"id\":1491},{\"id\":1492},{\"id\":1493},{\"id\":1494},{\"id\":1495},{\"id\":1496},{\"id\":1497},{\"id\":1498},{\"id\":1499},{\"id\":1500},{\"id\":1501},{\"id\":1502},{\"id\":1503},{\"id\":1504},{\"id\":1505},{\"id\":1506},{\"id\":1507},{\"id\":1508},{\"id\":1509},{\"id\":1510},{\"id\":1511},{\"id\":1512},{\"id\":1513},{\"id\":1514},{\"id\":1515},{\"id\":1516},{\"id\":1517},{\"id\":1518},{\"id\":1519},{\"id\":1520},{\"id\":1521},{\"id\":1522},{\"id\":1523},{\"id\":1524},{\"id\":1525},{\"id\":1526},{\"id\":1527},{\"id\":1528},{\"id\":1529},{\"id\":1530},{\"id\":1531},{\"id\":1532},{\"id\":1533},{\"id\":1534},{\"id\":1535},{\"id\":1536},{\"id\":1537},{\"id\":1538},{\"id\":1539},{\"id\":1540},{\"id\":1541},{\"id\":1542},{\"id\":1543},{\"id\":1544},{\"id\":1545},{\"id\":1546},{\"id\":1547},{\"id\":1548},{\"id\":1549},{\"id\":1550},{\"id\":1551},{\"id\":1552},{\"id\":1553},{\"id\":1554},{\"id\":1555},{\"id\":1556},{\"id\":1557},{\"id\":1558},{\"id\":1559},{\"id\":1560},{\"id\":1561},{\"id\":1562},{\"id\":1563},{\"id\":1564},{\"id\":1565},{\"id\":1566},{\"id\":1567},{\"id\":1568},{\"id\":1569},{\"id\":1570},{\"id\":1571},{\"id\":1572},{\"id\":1573},{\"id\":1574},{\"id\":1575},{\"id\":1576},{\"id\":1577},{\"id\":1578},{\"id\":1579},{\"id\":1580},{\"id\":1581},{\"id\":1582},{\"id\":1583},{\"id\":1584},{\"id\":1585},{\"id\":1586},{\"id\":1587},{\"id\":1588},{\"id\":1589},{\"id\":1590},{\"id\":1591},{\"id\":1592},{\"id\":1593},{\"id\":1594},{\"id\":1595},{\"id\":1596},{\"id\":1597},{\"id\":1598},{\"id\":1599},{\"id\":1600},{\"id\":1601},{\"id\":1602},{\"id\":1603},{\"id\":1604},{\"id\":1605},{\"id\":1606},{\"id\":1607},{\"id\":1608},{\"id\":1609},{\"id\":1610},{\"id\":1611},{\"id\":1612},{\"id\":1613},{\"id\":1614},{\"id\":1615},{\"id\":1616},{\"id\":1617},{\"id\":1618},{\"id\":1619},{\"id\":1620},{\"id\":1621},{\"id\":1622},{\"id\":1623},{\"id\":1624},{\"id\":1625},{\"id\":1626},{\"id\":1627},{\"id\":1628},{\"id\":1629},{\"id\":1630},{\"id\":1631},{\"id\":1632},{\"id\":1633},{\"id\":1634},{\"id\":1635},{\"id\":1636},{\"id\":1637},{\"id\":1638},{\"id\":1639},{\"id\":1640},{\"id\":1641},{\"id\":1642},{\"id\":1643},{\"id\":1644},{\"id\":1645},{\"id\":1646},{\"id\":1647},{\"id\":1648},{\"id\":1649},{\"id\":1650},{\"id\":1651},{\"id\":1652},{\"id\":1653},{\"id\":1654},{\"id\":1655},{\"id\":1656},{\"id\":1657},{\"id\":1658},{\"id\":1659},{\"id\":1660},{\"id\":1661},{\"id\":1662},{\"id\":1663},{\"id\":1664},{\"id\":1665},{\"id\":1666},{\"id\":1667},{\"id\":1668},{\"id\":1669},{\"id\":1670},{\"id\":1671},{\"id\":1672},{\"id\":1673},{\"id\":1674},{\"id\":1675},{\"id\":1676},{\"id\":1677},{\"id\":1678},{\"id\":1679},{\"id\":1680},{\"id\":1681},{\"id\":1682},{\"id\":1683},{\"id\":1684},{\"id\":1685},{\"id\":1686},{\"id\":1687},{\"id\":1688},{\"id\":1689},{\"id\":1690},{\"id\":1691},{\"id\":1692},{\"id\":1693},{\"id\":1694},{\"id\":1695},{\"id\":1696},{\"id\":1697},{\"id\":1698},{\"id\":1699},{\"id\":1700},{\"id\":1701},{\"id\":1702},{\"id\":1703},{\"id\":1704},{\"id\":1705},{\"id\":1706},{\"id\":1707},{\"id\":1708},{\"id\":1709},{\"id\":1710},{\"id\":1711},{\"id\":1712},{\"id\":1713},{\"id\":1714},{\"id\":1715},{\"id\":1716},{\"id\":1717},{\"id\":1718},{\"id\":1719},{\"id\":1720},{\"id\":1721},{\"id\":1722},{\"id\":1723},{\"id\":1724},{\"id\":1725},{\"id\":1726},{\"id\":1727},{\"id\":1728},{\"id\":1729},{\"id\":1730},{\"id\":1731},{\"id\":1732},{\"id\":1733},{\"id\":1734},{\"id\":1735},{\"id\":1736},{\"id\":1737},{\"id\":1738},{\"id\":1739},{\"id\":1740},{\"id\":1741},{\"id\":1742},{\"id\":1743},{\"id\":1744},{\"id\":1745},{\"id\":1746},{\"id\":1747},{\"id\":1748},{\"id\":1749},{\"id\":1750},{\"id\":1751},{\"id\":1752},{\"id\":1753},{\"id\":1754},{\"id\":1755},{\"id\":1756},{\"id\":1757},{\"id\":1758},{\"id\":1759},{\"id\":1760},{\"id\":1761},{\"id\":1762},{\"id\":1763},{\"id\":1764},{\"id\":1765},{\"id\":1766},{\"id\":1767},{\"id\":1768},{\"id\":1769},{\"id\":1770},{\"id\":1771},{\"id\":1772},{\"id\":1773},{\"id\":1774},{\"id\":1775},{\"id\":1776},{\"id\":1777},{\"id\":1778},{\"id\":1779},{\"id\":1780},{\"id\":1781},{\"id\":1782},{\"id\":1783},{\"id\":1784},{\"id\":1785},{\"id\":1786},{\"id\":1787},{\"id\":1788},{\"id\":1789},{\"id\":1790},{\"id\":1791},{\"id\":1792},{\"id\":1793},{\"id\":1794},{\"id\":1795},{\"id\":1796},{\"id\":1797},{\"id\":1798},{\"id\":1799},{\"id\":1800},{\"id\":1801},{\"id\":1802},{\"id\":1803},{\"id\":1804},{\"id\":1805},{\"id\":1806},{\"id\":1807},{\"id\":1808},{\"id\":1809},{\"id\":1810},{\"id\":1811},{\"id\":1812},{\"id\":1813},{\"id\":1814},{\"id\":1815},{\"id\":1816},{\"id\":1817},{\"id\":1818},{\"id\":1819},{\"id\":1820},{\"id\":1821},{\"id\":1822},{\"id\":1823},{\"id\":1824},{\"id\":1825},{\"id\":1826},{\"id\":1827},{\"id\":1828},{\"id\":1829},{\"id\":1830},{\"id\":1831},{\"id\":1832},{\"id\":1833},{\"id\":1834},{\"id\":1835},{\"id\":1836},{\"id\":1837},{\"id\":1838},{\"id\":1839},{\"id\":1840},{\"id\":1841},{\"id\":1842},{\"id\":1843},{\"id\":1844},{\"id\":1845},{\"id\":1846},{\"id\":1847},{\"id\":1848},{\"id\":1849},{\"id\":1850},{\"id\":1851},{\"id\":1852},{\"id\":1853},{\"id\":1854},{\"id\":1855},{\"id\":1856},{\"id\":1857},{\"id\":1858},{\"id\":1859},{\"id\":1860},{\"id\":1861},{\"id\":1862},{\"id\":1863},{\"id\":1864},{\"id\":1865},{\"id\":1866},{\"id\":1867},{\"id\":1868},{\"id\":1869},{\"id\":1870},{\"id\":1871},{\"id\":1872},{\"id\":1873},{\"id\":1874},{\"id\":1875},{\"id\":1876},{\"id\":1877},{\"id\":1878},{\"id\":1879},{\"id\":1880},{\"id\":1881},{\"id\":1882},{\"id\":1883},{\"id\":1884},{\"id\":1885},{\"id\":1886},{\"id\":1887},{\"id\":1888},{\"id\":1889},{\"id\":1890},{\"id\":1891},{\"id\":1892},{\"id\":1893},{\"id\":1894},{\"id\":1895},{\"id\":1896},{\"id\":1897},{\"id\":1898},{\"id\":1899},{\"id\":1900},{\"id\":1901},{\"id\":1902},{\"id\":1903},{\"id\":1904},{\"id\":1905},{\"id\":1906},{\"id\":1907},{\"id\":1908},{\"id\":1909},{\"id\":1910},{\"id\":1911},{\"id\":1912},{\"id\":1913},{\"id\":1914},{\"id\":1915},{\"id\":1916},{\"id\":1917},{\"id\":1918},{\"id\":1919},{\"id\":1920},{\"id\":1921},{\"id\":1922},{\"id\":1923},{\"id\":1924},{\"id\":1925},{\"id\":1926},{\"id\":1927},{\"id\":1928},{\"id\":1929},{\"id\":1930},{\"id\":1931},{\"id\":1932},{\"id\":1933},{\"id\":1934},{\"id\":1935},{\"id\":1936},{\"id\":1937},{\"id\":1938},{\"id\":1939},{\"id\":1940},{\"id\":1941},{\"id\":1942},{\"id\":1943},{\"id\":1944},{\"id\":1945},{\"id\":1946},{\"id\":1947},{\"id\":1948},{\"id\":1949},{\"id\":1950},{\"id\":1951},{\"id\":1952},{\"id\":1953},{\"id\":1954},{\"id\":1955},{\"id\":1956},{\"id\":1957},{\"id\":1958},{\"id\":1959},{\"id\":1960},{\"id\":1961},{\"id\":1962},{\"id\":1963},{\"id\":1964},{\"id\":1965},{\"id\":1966},{\"id\":1967},{\"id\":1968},{\"id\":1969},{\"id\":1970},{\"id\":1971},{\"id\":1972},{\"id\":1973},{\"id\":1974},{\"id\":1975},{\"id\":1976},{\"id\":1977},{\"id\":1978},{\"id\":1979},{\"id\":1980},{\"id\":1981},{\"id\":1982},{\"id\":1983},{\"id\":1984},{\"id\":1985},{\"id\":1986},{\"id\":1987},{\"id\":1988},{\"id\":1989},{\"id\":1990},{\"id\":1991},{\"id\":1992},{\"id\":1993},{\"id\":1994},{\"id\":1995},{\"id\":1996},{\"id\":1997},{\"id\":1998},{\"id\":1999},{\"id\":2000},{\"id\":2001},{\"id\":2002},{\"id\":2003},{\"id\":2004},{\"id\":2005},{\"id\":2006},{\"id\":2007},{\"id\":2008},{\"id\":2009},{\"id\":2010},{\"id\":2011},{\"id\":2012},{\"id\":2013},{\"id\":2014},{\"id\":2015},{\"id\":2016},{\"id\":2017},{\"id\":2018},{\"id\":2019},{\"id\":2020},{\"id\":2021},{\"id\":2022},{\"id\":2023},{\"id\":2024},{\"id\":2025},{\"id\":2026},{\"id\":2027},{\"id\":2028},{\"id\":2029},{\"id\":2030},{\"id\":2031},{\"id\":2032},{\"id\":2033},{\"id\":2034},{\"id\":2035},{\"id\":2036},{\"id\":2037},{\"id\":2038},{\"id\":2039},{\"id\":2040},{\"id\":2041},{\"id\":2042},{\"id\":2043},{\"id\":2044},{\"id\":2045},{\"id\":2046},{\"id\":2047},{\"id\":2048},{\"id\":2049},{\"id\":2050},{\"id\":2051},{\"id\":2052},{\"id\":2053},{\"id\":2054},{\"id\":2055},{\"id\":2056},{\"id\":2057},{\"id\":2058},{\"id\":2059},{\"id\":2060},{\"id\":2061},{\"id\":2062},{\"id\":2063},{\"id\":2064},{\"id\":2065},{\"id\":2066},{\"id\":2067},{\"id\":2068},{\"id\":2069},{\"id\":2070},{\"id\":2071},{\"id\":2072},{\"id\":2073},{\"id\":2074},{\"id\":2075},{\"id\":2076},{\"id\":2077},{\"id\":2078},{\"id\":2079},{\"id\":2080},{\"id\":2081},{\"id\":2082},{\"id\":2083},{\"id\":2084},{\"id\":2085},{\"id\":2086},{\"id\":2087},{\"id\":2088},{\"id\":2089},{\"id\":2090},{\"id\":2091},{\"id\":2092},{\"id\":2093},{\"id\":2094},{\"id\":2095},{\"id\":2096},{\"id\":2097},{\"id\":2098},{\"id\":2099},{\"id\":2100},{\"id\":2101},{\"id\":2102},{\"id\":2103},{\"id\":2104},{\"id\":2105},{\"id\":2106},{\"id\":2107},{\"id\":2108},{\"id\":2109},{\"id\":2110},{\"id\":2111},{\"id\":2112},{\"id\":2113},{\"id\":2114},{\"id\":2115},{\"id\":2116},{\"id\":2117},{\"id\":2118},{\"id\":2119},{\"id\":2120},{\"id\":2121},{\"id\":2122},{\"id\":2123},{\"id\":2124},{\"id\":2125},{\"id\":2126},{\"id\":2127},{\"id\":2128},{\"id\":2129},{\"id\":2130},{\"id\":2131},{\"id\":2132},{\"id\":2133},{\"id\":2134},{\"id\":2135},{\"id\":2136},{\"id\":2137},{\"id\":2138},{\"id\":2139},{\"id\":2140},{\"id\":2141},{\"id\":2142},{\"id\":2143},{\"id\":2144},{\"id\":2145},{\"id\":2146},{\"id\":2147},{\"id\":2148},{\"id\":2149},{\"id\":2150},{\"id\":2151},{\"id\":2152},{\"id\":2153},{\"id\":2154},{\"id\":2155},{\"id\":2156},{\"id\":2157},{\"id\":2158},{\"id\":2159},{\"id\":2160},{\"id\":2161},{\"id\":2162},{\"id\":2163},{\"id\":2164},{\"id\":2165},{\"id\":2166},{\"id\":2167},{\"id\":2168},{\"id\":2169},{\"id\":2170},{\"id\":2171},{\"id\":2172},{\"id\":2173},{\"id\":2174},{\"id\":2175},{\"id\":2176},{\"id\":2177},{\"id\":2178},{\"id\":2179},{\"id\":2180},{\"id\":2181},{\"id\":2182},{\"id\":2183},{\"id\":2184},{\"id\":2185},{\"id\":2186},{\"id\":2187},{\"id\":2188},{\"id\":2189},{\"id\":2190},{\"id\":2191},{\"id\":2192},{\"id\":2193},{\"id\":2194},{\"id\":2195},{\"id\":2196},{\"id\":2197},{\"id\":2198},{\"id\":2199},{\"id\":2200},{\"id\":2201},{\"id\":2202},{\"id\":2203},{\"id\":2204},{\"id\":2205},{\"id\":2206},{\"id\":2207},{\"id\":2208},{\"id\":2209},{\"id\":2210},{\"id\":2211},{\"id\":2212},{\"id\":2213},{\"id\":2214},{\"id\":2215},{\"id\":2216},{\"id\":2217},{\"id\":2218},{\"id\":2219},{\"id\":2220},{\"id\":2221},{\"id\":2222},{\"id\":2223},{\"id\":2224},{\"id\":2225},{\"id\":2226},{\"id\":2227},{\"id\":2228},{\"id\":2229},{\"id\":2230},{\"id\":2231},{\"id\":2232},{\"id\":2233},{\"id\":2234},{\"id\":2235},{\"id\":2236},{\"id\":2237},{\"id\":2238},{\"id\":2239},{\"id\":2240},{\"id\":2241},{\"id\":2242},{\"id\":2243},{\"id\":2244},{\"id\":2245},{\"id\":2246},{\"id\":2247},{\"id\":2248},{\"id\":2249},{\"id\":2250},{\"id\":2251},{\"id\":2252},{\"id\":2253},{\"id\":2254},{\"id\":2255},{\"id\":2256},{\"id\":2257},{\"id\":2258},{\"id\":2259},{\"id\":2260},{\"id\":2261},{\"id\":2262},{\"id\":2263},{\"id\":2264},{\"id\":2265},{\"id\":2266},{\"id\":2267},{\"id\":2268},{\"id\":2269},{\"id\":2270},{\"id\":2271},{\"id\":2272},{\"id\":2273},{\"id\":2274},{\"id\":2275},{\"id\":2276},{\"id\":2277},{\"id\":2278},{\"id\":2279},{\"id\":2280},{\"id\":2281},{\"id\":2282},{\"id\":2283},{\"id\":2284},{\"id\":2285},{\"id\":2286},{\"id\":2287},{\"id\":2288},{\"id\":2289},{\"id\":2290},{\"id\":2291},{\"id\":2292},{\"id\":2293},{\"id\":2294},{\"id\":2295},{\"id\":2296},{\"id\":2297},{\"id\":2298},{\"id\":2299},{\"id\":2300},{\"id\":2301},{\"id\":2302},{\"id\":2311},{\"id\":2316},{\"id\":2317},{\"id\":2343},{\"id\":2344},{\"id\":2393},{\"id\":2318},{\"id\":2345},{\"id\":2346},{\"id\":2394},{\"id\":2319},{\"id\":2347},{\"id\":2348},{\"id\":2395},{\"id\":2320},{\"id\":2349},{\"id\":2350},{\"id\":2396},{\"id\":2321},{\"id\":2351},{\"id\":2352},{\"id\":2397},{\"id\":2322},{\"id\":2353},{\"id\":2354},{\"id\":2398},{\"id\":2323},{\"id\":2355},{\"id\":2356},{\"id\":2399},{\"id\":2324},{\"id\":2357},{\"id\":2358},{\"id\":2400},{\"id\":2325},{\"id\":2359},{\"id\":2360},{\"id\":2401},{\"id\":2326},{\"id\":2361},{\"id\":2362},{\"id\":2402},{\"id\":2327},{\"id\":2363},{\"id\":2364},{\"id\":2403},{\"id\":2328},{\"id\":2365},{\"id\":2366},{\"id\":2404},{\"id\":2329},{\"id\":2367},{\"id\":2368},{\"id\":2405},{\"id\":2330},{\"id\":2369},{\"id\":2370},{\"id\":2406},{\"id\":2331},{\"id\":2371},{\"id\":2372},{\"id\":2407},{\"id\":2332},{\"id\":2373},{\"id\":2374},{\"id\":2408},{\"id\":2333},{\"id\":2375},{\"id\":2376},{\"id\":2409},{\"id\":2334},{\"id\":2377},{\"id\":2378},{\"id\":2410},{\"id\":2335},{\"id\":2379},{\"id\":2380},{\"id\":2411},{\"id\":2336},{\"id\":2381},{\"id\":2382},{\"id\":2412},{\"id\":2337},{\"id\":2383},{\"id\":2384},{\"id\":2413},{\"id\":2338},{\"id\":2385},{\"id\":2386},{\"id\":2414},{\"id\":2339},{\"id\":2387},{\"id\":2388},{\"id\":2415},{\"id\":2340},{\"id\":2389},{\"id\":2390},{\"id\":2416},{\"id\":2341},{\"id\":2391},{\"id\":2392},{\"id\":2417},{\"id\":2342},{\"id\":2418},{\"id\":2419},{\"id\":2312},{\"id\":2420},{\"id\":2421},{\"id\":2435},{\"id\":2436},{\"id\":2461},{\"id\":2422},{\"id\":2437},{\"id\":2438},{\"id\":2462},{\"id\":2423},{\"id\":2439},{\"id\":2440},{\"id\":2463},{\"id\":2424},{\"id\":2441},{\"id\":2442},{\"id\":2464},{\"id\":2425},{\"id\":2443},{\"id\":2444},{\"id\":2465},{\"id\":2426},{\"id\":2445},{\"id\":2446},{\"id\":2466},{\"id\":2427},{\"id\":2447},{\"id\":2448},{\"id\":2467},{\"id\":2428},{\"id\":2449},{\"id\":2450},{\"id\":2468},{\"id\":2429},{\"id\":2451},{\"id\":2452},{\"id\":2469},{\"id\":2430},{\"id\":2453},{\"id\":2454},{\"id\":2470},{\"id\":2431},{\"id\":2455},{\"id\":2456},{\"id\":2471},{\"id\":2432},{\"id\":2457},{\"id\":2458},{\"id\":2472},{\"id\":2433},{\"id\":2459},{\"id\":2460},{\"id\":2473},{\"id\":2434},{\"id\":2474},{\"id\":2475},{\"id\":2313},{\"id\":2476},{\"id\":2488},{\"id\":2477},{\"id\":2489},{\"id\":2478},{\"id\":2490},{\"id\":2479},{\"id\":2491},{\"id\":2480},{\"id\":2492},{\"id\":2481},{\"id\":2493},{\"id\":2482},{\"id\":2494},{\"id\":2483},{\"id\":2495},{\"id\":2484},{\"id\":2496},{\"id\":2485},{\"id\":2497},{\"id\":2486},{\"id\":2498},{\"id\":2487},{\"id\":2499},{\"id\":2314},{\"id\":2500},{\"id\":2501},{\"id\":2502},{\"id\":2503},{\"id\":2504},{\"id\":2505},{\"id\":2506},{\"id\":2507},{\"id\":2508},{\"id\":2509},{\"id\":2510},{\"id\":2511},{\"id\":2512},{\"id\":2513},{\"id\":2514},{\"id\":2515},{\"id\":2516},{\"id\":2517},{\"id\":2518},{\"id\":2519},{\"id\":2520},{\"id\":2521},{\"id\":2522},{\"id\":2523},{\"id\":2315},{\"id\":2524},{\"id\":2542},{\"id\":2543},{\"id\":2578},{\"id\":2525},{\"id\":2544},{\"id\":2545},{\"id\":2579},{\"id\":2526},{\"id\":2546},{\"id\":2547},{\"id\":2580},{\"id\":2527},{\"id\":2548},{\"id\":2549},{\"id\":2581},{\"id\":2528},{\"id\":2550},{\"id\":2551},{\"id\":2582},{\"id\":2529},{\"id\":2552},{\"id\":2553},{\"id\":2583},{\"id\":2530},{\"id\":2554},{\"id\":2555},{\"id\":2584},{\"id\":2531},{\"id\":2556},{\"id\":2557},{\"id\":2585},{\"id\":2532},{\"id\":2558},{\"id\":2559},{\"id\":2586},{\"id\":2533},{\"id\":2560},{\"id\":2561},{\"id\":2587},{\"id\":2534},{\"id\":2562},{\"id\":2563},{\"id\":2588},{\"id\":2535},{\"id\":2564},{\"id\":2565},{\"id\":2589},{\"id\":2536},{\"id\":2566},{\"id\":2567},{\"id\":2590},{\"id\":2537},{\"id\":2568},{\"id\":2569},{\"id\":2591},{\"id\":2538},{\"id\":2570},{\"id\":2571},{\"id\":2592},{\"id\":2539},{\"id\":2572},{\"id\":2573},{\"id\":2593},{\"id\":2540},{\"id\":2574},{\"id\":2575},{\"id\":2594},{\"id\":2541},{\"id\":2576},{\"id\":2577},{\"id\":2595},{\"id\":2303},{\"id\":2304},{\"id\":2305},{\"id\":2306},{\"id\":2307},{\"nodeType\":3,\"id\":2596,\"textContent\":\" // Track clicks on page $(document).ready(function() { $(\\\".control\\\").click(function(e) { e.stopImmediatePropagation(); clicks = clicks + 1; console.log(clicks); }); }); $('.userid').html(sid); // console.log(\\\"start of clicked array: \\\"+clicked); // console.log(\\\"start of hovered string: \\\"+hovered); //set correct answers for each question var triangular_answers = { \\\"acme.starttime.1\\\" : [\\\"F\\\"], \\\"acme.starts.1\\\" : [\\\"K\\\"], \\\"acme.meets.1\\\" : [\\\"F\\\"], \\\"acme.endtime.1\\\" : [\\\"H\\\"], \\\"acme.midpoint.1\\\" : [\\\"O\\\"], \\\"acme.starttime.2\\\" : [\\\"F\\\"], \\\"acme.starts.2\\\" : [\\\"K\\\"], \\\"acme.meets.2\\\" : [\\\"F\\\"], \\\"acme.endtime.2\\\" : [\\\"H\\\"], \\\"acme.midpoint.2\\\" : [\\\"A\\\"], \\\"bigset.duration.1\\\" : [\\\"E\\\",\\\"G\\\"], \\\"bigset.duration+starts.1\\\" : [\\\"X\\\",\\\"O\\\"], \\\"bigset.duration+contained.1\\\" : [\\\"G\\\"], \\\"bigset.starttime+before+endtime+during.1\\\": [\\\"I\\\"], \\\"bigset.ends.1\\\" : [\\\"E\\\"], \\\"bigset.duration.2\\\" : [\\\"E\\\",\\\"G\\\"], \\\"bigset.duration+starts.2\\\" : [\\\"X\\\",\\\"O\\\"], \\\"bigset.duration+contained.2\\\" : [\\\"G\\\"], \\\"bigset.starttime+before+endtime+during.2\\\":[\\\"I\\\"], \\\"bigset.ends.2\\\" : [\\\"E\\\"], \\\"bigset.starttime.1\\\" : [\\\"M\\\",\\\"L\\\"], \\\"bigset.starts.1\\\" : [\\\"G\\\"], \\\"bigset.meets.1\\\" : [\\\"E\\\",\\\"F\\\"], \\\"bigset.endtime.1\\\" : [\\\"X\\\"], \\\"bigset.midpoint.1\\\" : [\\\"K\\\",\\\"X\\\"], \\\"bigset.starttime.2\\\" : [\\\"M\\\",\\\"L\\\"], \\\"bigset.starts.2\\\" : [\\\"G\\\"], \\\"bigset.meets.2\\\" : [\\\"E\\\",\\\"F\\\"], \\\"bigset.endtime.2\\\" : [\\\"X\\\"], \\\"bigset.midpoint.2\\\" : [\\\"K\\\",\\\"X\\\"] } var orthogonal_answers = { \\\"acme.starttime.1\\\" : [\\\"A\\\"], \\\"acme.starts.1\\\" : [\\\"E\\\"], \\\"acme.meets.1\\\" : [\\\"Z\\\"], \\\"acme.endtime.1\\\" : [\\\"U\\\"], \\\"acme.midpoint.1\\\" : [\\\"U\\\"], \\\"acme.starttime.2\\\" : [\\\"0\\\"], \\\"acme.starts.2\\\" : [\\\"0\\\"], \\\"acme.meets.2\\\" : [\\\"0\\\"], \\\"acme.endtime.2\\\" : [\\\"0\\\"], \\\"acme.midpoint.2\\\" : [\\\"0\\\"], \\\"bigset.duration.1\\\" : [\\\"E\\\",\\\"G\\\"], \\\"bigset.duration+starts.1\\\" : [\\\"F\\\",\\\"B\\\"], \\\"bigset.duration+contained.1\\\" : [\\\"E\\\"], \\\"bigset.starttime+before+endtime+during.1\\\": [\\\"I\\\"], \\\"bigset.ends.1\\\" : [\\\"X\\\"], \\\"bigset.duration.2\\\" : [\\\"E\\\",\\\"G\\\"], \\\"bigset.duration+starts.2\\\" : [\\\"F\\\",\\\"B\\\"], \\\"bigset.duration+contained.2\\\" : [\\\"E\\\"], \\\"bigset.starttime+before+endtime+during.2\\\":[\\\"I\\\"], \\\"bigset.ends.2\\\" : [\\\"X\\\"], \\\"bigset.starttime.1\\\" : [\\\"F\\\",\\\"B\\\"], \\\"bigset.starts.1\\\" : [\\\"B\\\"], \\\"bigset.meets.1\\\" : [\\\"F\\\",\\\"X\\\"], \\\"bigset.endtime.1\\\" : [\\\"B\\\"], \\\"bigset.midpoint.1\\\" : [\\\"E\\\",\\\"F\\\"], \\\"bigset.starttime.2\\\" : [\\\"F\\\",\\\"B\\\"], \\\"bigset.starts.2\\\" : [\\\"B\\\"], \\\"bigset.meets.2\\\" : [\\\"F\\\",\\\"X\\\"], \\\"bigset.endtime.2\\\" : [\\\"B\\\"], \\\"bigset.midpoint.2\\\" : [\\\"E\\\",\\\"F\\\"] } //display the question and answer buttons based on input values from jsPsych document.getElementById(scenario+\\\".\\\"+question).style.display = \\\"block\\\"; if (question == \\\"strategy\\\") {document.getElementById(\\\"strategyButton\\\").style.display = \\\"block\\\";} else {document.getElementById(\\\"testingButton\\\").style.display = \\\"block\\\";} //---------SET PROPERTIES OF THE GRAPH -------------// // set the dimensions and margins of the graph var margin = {top: 25, right: 30, bottom: 90, left: 100}, width = 800, height = 800; var intersects = false; //default value for intersects scaffold var xAxisTitle, yAxisTitle; var datafile =\\\"\\\"; // SET AXIS VALUES if (axis == 1){ axis = \\\"Orthogonal-XInside-YFull\\\"; } else if (axis == 2){ axis = \\\"Orthogonal-XInside-YPartial\\\"; } else if (axis ==3){ axis = \\\"Triangular-XInside-YInside\\\"; } else if (axis ==4){ axis = \\\"Orthogonal-XInside-YInside\\\"; } else if (axis ==5){ axis = \\\"Orthogonal-XFull-YFull\\\"; } // SET EXPLICIT SCAFFOLD FEATURES if (explicit ==2 && axis != \\\"diagonal\\\"){ scaffold = 2; intersects = false; } else if (explicit == 2 && axis == \\\"diagonal\\\"){ scaffold = 2; intersects = false; } //TODO: not sure if above two lines are still valid since leaders are now generated on the fly else if (explicit == 3){ $('#hint-interactive').css(\\\"display\\\",\\\"block\\\"); //display textimage scaffold intersects = true; } //SET DATA FILE FOR IMPLICIT SCAFFOLD if (impasse == 1){ datafile = \\\"../views/src/data/acme_nonimpasse.csv\\\"; } else if (impasse == 2){ datafile = \\\"../views/src/data/acme_impasse.csv\\\"; } //OVERRIDE DATA FILE FOR NON-SCAFFOLD QUESTIONS if (q > 5) { //override data file if q# is greater than 5 datafile = \\\"../views/src/data/bigset.csv\\\"; console.log(\\\"override data file\\\"); $('#orthogonal-image').css(\\\"display\\\",\\\"none\\\"); //display textimage scaffold $('#diagonal-image').css(\\\"display\\\",\\\"none\\\"); //display textimage scaffold $('#hint-interactive').css(\\\"display\\\",\\\"none\\\"); //display textimage scaffold intersects = false; } // //---------CREATE THE SVG ------------------------// var svg = d3.select(\\\".d3container\\\").append(\\\"svg\\\") .attr(\\\"width\\\", width + margin.left + margin.right) .attr(\\\"height\\\", height + margin.top + margin.bottom) .append(\\\"g\\\") .attr(\\\"transform\\\", \\\"translate(\\\" + margin.left + \\\",\\\" + margin.top + \\\")\\\"); //---------DRAW THE GRAPH ------------------------// xAxisTitle = \\\"START & END TIME (time of day)\\\"; yAxisTitle = \\\"DURATION (in hours)\\\"; drawTriangleModel(datafile,intersects,axis,scaffold,q); \"},{\"id\":2308},{\"id\":2309},{\"nodeType\":3,\"id\":2597,\"textContent\":\" //MOUSE LOGGING SCRIPT var mouseLog = [] var xwidth = $(document).width(); var xheight = $(document).width(); mouseLog.push(\\\"{x:\\\"+xwidth+\\\",y:\\\"+xheight+\\\",t:\\\"+\\\"0};\\\") document.onmousemove = function(e){ var pageCoords = \\\"{x:\\\" + e.pageX + \\\",y:\\\"+ e.pageY +\\\",t:\\\"+ Date.now()+ \\\"};\\\" ; mouseLog.push(pageCoords); // console.log(pageCoords); }; \"},{\"id\":2310}],[],[],[]]}"
    },
    {
      "sequence": 3,
      "data": "{\"f\":\"applyChanged\",\"args\":[[],[{\"nodeType\":1,\"id\":2598,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-text-preamble\",\"class\":\"jspsych-survey-text-preamble\"},\"parentNode\":{\"id\":55}},{\"nodeType\":1,\"id\":2599,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-text-0\",\"class\":\"jspsych-survey-text-question\"},\"previousSibling\":{\"id\":2598},\"parentNode\":{\"id\":55}},{\"nodeType\":1,\"id\":2600,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-text-1\",\"class\":\"jspsych-survey-text-question\"},\"previousSibling\":{\"id\":2599},\"parentNode\":{\"id\":55}},{\"nodeType\":1,\"id\":2601,\"tagName\":\"BUTTON\",\"attributes\":{\"id\":\"jspsych-survey-text-next\",\"class\":\"jspsych-btn jspsych-survey-text\"},\"previousSibling\":{\"id\":2600},\"parentNode\":{\"id\":55}},{\"nodeType\":1,\"id\":2602,\"tagName\":\"P\",\"attributes\":{\"class\":\"jspsych-survey-text\"},\"parentNode\":{\"id\":2599}},{\"nodeType\":1,\"id\":2603,\"tagName\":\"TEXTAREA\",\"attributes\":{\"name\":\"#jspsych-survey-text-response-0\",\"cols\":\"40\",\"rows\":\"1\"},\"previousSibling\":{\"id\":2602},\"parentNode\":{\"id\":2599}},{\"nodeType\":3,\"id\":2604,\"textContent\":\"What is your age?\",\"parentNode\":{\"id\":2602}},{\"nodeType\":1,\"id\":2605,\"tagName\":\"P\",\"attributes\":{\"class\":\"jspsych-survey-text\"},\"parentNode\":{\"id\":2600}},{\"nodeType\":1,\"id\":2606,\"tagName\":\"TEXTAREA\",\"attributes\":{\"name\":\"#jspsych-survey-text-response-1\",\"cols\":\"40\",\"rows\":\"1\"},\"previousSibling\":{\"id\":2605},\"parentNode\":{\"id\":2600}},{\"nodeType\":3,\"id\":2607,\"textContent\":\"In what country were you born?\",\"parentNode\":{\"id\":2605}},{\"nodeType\":3,\"id\":2608,\"textContent\":\"Submit Answers\",\"parentNode\":{\"id\":2601}}],[],[]]}"
    },
    {
      "sequence": 4,
      "data": "{\"f\":\"applyChanged\",\"args\":[[{\"id\":2598},{\"id\":2599},{\"id\":2602},{\"id\":2604},{\"id\":2603},{\"id\":2600},{\"id\":2605},{\"id\":2607},{\"id\":2606},{\"id\":2601},{\"id\":2608}],[],[],[]]}"
    },
    {
      "sequence": 5,
      "data": "{\"f\":\"applyChanged\",\"args\":[[],[{\"nodeType\":1,\"id\":2609,\"tagName\":\"FORM\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-form\"},\"parentNode\":{\"id\":55}},{\"nodeType\":1,\"id\":2610,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-preamble\",\"class\":\"jspsych-survey-multi-choice-preamble\"},\"parentNode\":{\"id\":2609}},{\"nodeType\":1,\"id\":2611,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-0\",\"class\":\"jspsych-survey-multi-choice-question jspsych-survey-multi-choice-horizontal\"},\"previousSibling\":{\"id\":2610},\"parentNode\":{\"id\":2609}},{\"nodeType\":1,\"id\":2612,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-1\",\"class\":\"jspsych-survey-multi-choice-question jspsych-survey-multi-choice-horizontal\"},\"previousSibling\":{\"id\":2611},\"parentNode\":{\"id\":2609}},{\"nodeType\":1,\"id\":2613,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-2\",\"class\":\"jspsych-survey-multi-choice-question jspsych-survey-multi-choice-horizontal\"},\"previousSibling\":{\"id\":2612},\"parentNode\":{\"id\":2609}},{\"nodeType\":1,\"id\":2614,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-3\",\"class\":\"jspsych-survey-multi-choice-question jspsych-survey-multi-choice-horizontal\"},\"previousSibling\":{\"id\":2613},\"parentNode\":{\"id\":2609}},{\"nodeType\":1,\"id\":2615,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"submit\",\"id\":\"jspsych-survey-multi-choice-next\",\"class\":\"jspsych-survey-multi-choice jspsych-btn\",\"value\":\"Submit Answers\"},\"previousSibling\":{\"id\":2614},\"parentNode\":{\"id\":2609}},{\"nodeType\":1,\"id\":2616,\"tagName\":\"P\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text survey-multi-choice\"},\"parentNode\":{\"id\":2611}},{\"nodeType\":1,\"id\":2617,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-0-0\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2616},\"parentNode\":{\"id\":2611}},{\"nodeType\":1,\"id\":2618,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-0-1\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2617},\"parentNode\":{\"id\":2611}},{\"nodeType\":1,\"id\":2619,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-0-2\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2618},\"parentNode\":{\"id\":2611}},{\"nodeType\":1,\"id\":2620,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-0-3\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2619},\"parentNode\":{\"id\":2611}},{\"nodeType\":3,\"id\":2621,\"textContent\":\"What is your first language?\",\"parentNode\":{\"id\":2616}},{\"nodeType\":1,\"id\":2622,\"tagName\":\"SPAN\",\"attributes\":{\"class\":\"required\"},\"previousSibling\":{\"id\":2621},\"parentNode\":{\"id\":2616}},{\"nodeType\":1,\"id\":2623,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2617}},{\"nodeType\":1,\"id\":2624,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-0\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2623}},{\"nodeType\":3,\"id\":2625,\"textContent\":\"English\",\"previousSibling\":{\"id\":2624},\"parentNode\":{\"id\":2623}},{\"nodeType\":1,\"id\":2626,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2618}},{\"nodeType\":1,\"id\":2627,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-0\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2626}},{\"nodeType\":3,\"id\":2628,\"textContent\":\"Spanish\",\"previousSibling\":{\"id\":2627},\"parentNode\":{\"id\":2626}},{\"nodeType\":1,\"id\":2629,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2619}},{\"nodeType\":1,\"id\":2630,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-0\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2629}},{\"nodeType\":3,\"id\":2631,\"textContent\":\"Mandarin or Cantonese\",\"previousSibling\":{\"id\":2630},\"parentNode\":{\"id\":2629}},{\"nodeType\":1,\"id\":2632,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2620}},{\"nodeType\":1,\"id\":2633,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-0\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2632}},{\"nodeType\":3,\"id\":2634,\"textContent\":\"Other\",\"previousSibling\":{\"id\":2633},\"parentNode\":{\"id\":2632}},{\"nodeType\":3,\"id\":2635,\"textContent\":\"*\",\"parentNode\":{\"id\":2622}},{\"nodeType\":1,\"id\":2636,\"tagName\":\"P\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text survey-multi-choice\"},\"parentNode\":{\"id\":2612}},{\"nodeType\":1,\"id\":2637,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-1-0\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2636},\"parentNode\":{\"id\":2612}},{\"nodeType\":1,\"id\":2638,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-1-1\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2637},\"parentNode\":{\"id\":2612}},{\"nodeType\":1,\"id\":2639,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-1-2\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2638},\"parentNode\":{\"id\":2612}},{\"nodeType\":1,\"id\":2640,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-1-3\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2639},\"parentNode\":{\"id\":2612}},{\"nodeType\":1,\"id\":2641,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-1-4\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2640},\"parentNode\":{\"id\":2612}},{\"nodeType\":1,\"id\":2642,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-1-5\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2641},\"parentNode\":{\"id\":2612}},{\"nodeType\":1,\"id\":2643,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-1-6\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2642},\"parentNode\":{\"id\":2612}},{\"nodeType\":3,\"id\":2644,\"textContent\":\"What is your year in school?\",\"parentNode\":{\"id\":2636}},{\"nodeType\":1,\"id\":2645,\"tagName\":\"SPAN\",\"attributes\":{\"class\":\"required\"},\"previousSibling\":{\"id\":2644},\"parentNode\":{\"id\":2636}},{\"nodeType\":1,\"id\":2646,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2637}},{\"nodeType\":1,\"id\":2647,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-1\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2646}},{\"nodeType\":3,\"id\":2648,\"textContent\":\"First\",\"previousSibling\":{\"id\":2647},\"parentNode\":{\"id\":2646}},{\"nodeType\":1,\"id\":2649,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2638}},{\"nodeType\":1,\"id\":2650,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-1\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2649}},{\"nodeType\":3,\"id\":2651,\"textContent\":\"Second\",\"previousSibling\":{\"id\":2650},\"parentNode\":{\"id\":2649}},{\"nodeType\":1,\"id\":2652,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2639}},{\"nodeType\":1,\"id\":2653,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-1\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2652}},{\"nodeType\":3,\"id\":2654,\"textContent\":\"Third\",\"previousSibling\":{\"id\":2653},\"parentNode\":{\"id\":2652}},{\"nodeType\":1,\"id\":2655,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2640}},{\"nodeType\":1,\"id\":2656,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-1\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2655}},{\"nodeType\":3,\"id\":2657,\"textContent\":\"Fourth\",\"previousSibling\":{\"id\":2656},\"parentNode\":{\"id\":2655}},{\"nodeType\":1,\"id\":2658,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2641}},{\"nodeType\":1,\"id\":2659,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-1\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2658}},{\"nodeType\":3,\"id\":2660,\"textContent\":\"Fifth\",\"previousSibling\":{\"id\":2659},\"parentNode\":{\"id\":2658}},{\"nodeType\":1,\"id\":2661,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2642}},{\"nodeType\":1,\"id\":2662,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-1\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2661}},{\"nodeType\":3,\"id\":2663,\"textContent\":\"Graduate\",\"previousSibling\":{\"id\":2662},\"parentNode\":{\"id\":2661}},{\"nodeType\":1,\"id\":2664,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2643}},{\"nodeType\":1,\"id\":2665,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-1\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2664}},{\"nodeType\":3,\"id\":2666,\"textContent\":\"Other\",\"previousSibling\":{\"id\":2665},\"parentNode\":{\"id\":2664}},{\"nodeType\":3,\"id\":2667,\"textContent\":\"*\",\"parentNode\":{\"id\":2645}},{\"nodeType\":1,\"id\":2668,\"tagName\":\"P\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text survey-multi-choice\"},\"parentNode\":{\"id\":2613}},{\"nodeType\":1,\"id\":2669,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-2-0\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2668},\"parentNode\":{\"id\":2613}},{\"nodeType\":1,\"id\":2670,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-2-1\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2669},\"parentNode\":{\"id\":2613}},{\"nodeType\":1,\"id\":2671,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-2-2\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2670},\"parentNode\":{\"id\":2613}},{\"nodeType\":1,\"id\":2672,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-2-3\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2671},\"parentNode\":{\"id\":2613}},{\"nodeType\":1,\"id\":2673,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-2-4\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2672},\"parentNode\":{\"id\":2613}},{\"nodeType\":1,\"id\":2674,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-2-5\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2673},\"parentNode\":{\"id\":2613}},{\"nodeType\":1,\"id\":2675,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-2-6\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2674},\"parentNode\":{\"id\":2613}},{\"nodeType\":3,\"id\":2676,\"textContent\":\"What is your major area of study?\",\"parentNode\":{\"id\":2668}},{\"nodeType\":1,\"id\":2677,\"tagName\":\"SPAN\",\"attributes\":{\"class\":\"required\"},\"previousSibling\":{\"id\":2676},\"parentNode\":{\"id\":2668}},{\"nodeType\":1,\"id\":2678,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2669}},{\"nodeType\":1,\"id\":2679,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-2\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2678}},{\"nodeType\":3,\"id\":2680,\"textContent\":\"Math or Computer Sciences\",\"previousSibling\":{\"id\":2679},\"parentNode\":{\"id\":2678}},{\"nodeType\":1,\"id\":2681,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2670}},{\"nodeType\":1,\"id\":2682,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-2\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2681}},{\"nodeType\":3,\"id\":2683,\"textContent\":\"Social Sciences (incl. CogSci)\",\"previousSibling\":{\"id\":2682},\"parentNode\":{\"id\":2681}},{\"nodeType\":1,\"id\":2684,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2671}},{\"nodeType\":1,\"id\":2685,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-2\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2684}},{\"nodeType\":3,\"id\":2686,\"textContent\":\"Biomedical & Health Sciences\",\"previousSibling\":{\"id\":2685},\"parentNode\":{\"id\":2684}},{\"nodeType\":1,\"id\":2687,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2672}},{\"nodeType\":1,\"id\":2688,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-2\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2687}},{\"nodeType\":3,\"id\":2689,\"textContent\":\"Natural Sciences\",\"previousSibling\":{\"id\":2688},\"parentNode\":{\"id\":2687}},{\"nodeType\":1,\"id\":2690,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2673}},{\"nodeType\":1,\"id\":2691,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-2\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2690}},{\"nodeType\":3,\"id\":2692,\"textContent\":\"Engineering\",\"previousSibling\":{\"id\":2691},\"parentNode\":{\"id\":2690}},{\"nodeType\":1,\"id\":2693,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2674}},{\"nodeType\":1,\"id\":2694,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-2\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2693}},{\"nodeType\":3,\"id\":2695,\"textContent\":\"Humanities\",\"previousSibling\":{\"id\":2694},\"parentNode\":{\"id\":2693}},{\"nodeType\":1,\"id\":2696,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2675}},{\"nodeType\":1,\"id\":2697,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-2\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2696}},{\"nodeType\":3,\"id\":2698,\"textContent\":\"Fine Arts\",\"previousSibling\":{\"id\":2697},\"parentNode\":{\"id\":2696}},{\"nodeType\":3,\"id\":2699,\"textContent\":\"*\",\"parentNode\":{\"id\":2677}},{\"nodeType\":1,\"id\":2700,\"tagName\":\"P\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text survey-multi-choice\"},\"parentNode\":{\"id\":2614}},{\"nodeType\":1,\"id\":2701,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-3-0\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2700},\"parentNode\":{\"id\":2614}},{\"nodeType\":1,\"id\":2702,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-3-1\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2701},\"parentNode\":{\"id\":2614}},{\"nodeType\":1,\"id\":2703,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-3-2\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2702},\"parentNode\":{\"id\":2614}},{\"nodeType\":3,\"id\":2704,\"textContent\":\"What is your gender?\",\"parentNode\":{\"id\":2700}},{\"nodeType\":1,\"id\":2705,\"tagName\":\"SPAN\",\"attributes\":{\"class\":\"required\"},\"previousSibling\":{\"id\":2704},\"parentNode\":{\"id\":2700}},{\"nodeType\":1,\"id\":2706,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2701}},{\"nodeType\":1,\"id\":2707,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-3\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2706}},{\"nodeType\":3,\"id\":2708,\"textContent\":\"Male\",\"previousSibling\":{\"id\":2707},\"parentNode\":{\"id\":2706}},{\"nodeType\":1,\"id\":2709,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2702}},{\"nodeType\":1,\"id\":2710,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-3\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2709}},{\"nodeType\":3,\"id\":2711,\"textContent\":\"Female\",\"previousSibling\":{\"id\":2710},\"parentNode\":{\"id\":2709}},{\"nodeType\":1,\"id\":2712,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2703}},{\"nodeType\":1,\"id\":2713,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-3\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2712}},{\"nodeType\":3,\"id\":2714,\"textContent\":\"Other\",\"previousSibling\":{\"id\":2713},\"parentNode\":{\"id\":2712}},{\"nodeType\":3,\"id\":2715,\"textContent\":\"*\",\"parentNode\":{\"id\":2705}}],[],[]]}"
    },
    {
      "sequence": 6,
      "data": "{\"f\":\"applyChanged\",\"args\":[[{\"id\":2609},{\"id\":2610},{\"id\":2611},{\"id\":2616},{\"id\":2621},{\"id\":2622},{\"id\":2635},{\"id\":2617},{\"id\":2623},{\"id\":2624},{\"id\":2625},{\"id\":2618},{\"id\":2626},{\"id\":2627},{\"id\":2628},{\"id\":2619},{\"id\":2629},{\"id\":2630},{\"id\":2631},{\"id\":2620},{\"id\":2632},{\"id\":2633},{\"id\":2634},{\"id\":2612},{\"id\":2636},{\"id\":2644},{\"id\":2645},{\"id\":2667},{\"id\":2637},{\"id\":2646},{\"id\":2647},{\"id\":2648},{\"id\":2638},{\"id\":2649},{\"id\":2650},{\"id\":2651},{\"id\":2639},{\"id\":2652},{\"id\":2653},{\"id\":2654},{\"id\":2640},{\"id\":2655},{\"id\":2656},{\"id\":2657},{\"id\":2641},{\"id\":2658},{\"id\":2659},{\"id\":2660},{\"id\":2642},{\"id\":2661},{\"id\":2662},{\"id\":2663},{\"id\":2643},{\"id\":2664},{\"id\":2665},{\"id\":2666},{\"id\":2613},{\"id\":2668},{\"id\":2676},{\"id\":2677},{\"id\":2699},{\"id\":2669},{\"id\":2678},{\"id\":2679},{\"id\":2680},{\"id\":2670},{\"id\":2681},{\"id\":2682},{\"id\":2683},{\"id\":2671},{\"id\":2684},{\"id\":2685},{\"id\":2686},{\"id\":2672},{\"id\":2687},{\"id\":2688},{\"id\":2689},{\"id\":2673},{\"id\":2690},{\"id\":2691},{\"id\":2692},{\"id\":2674},{\"id\":2693},{\"id\":2694},{\"id\":2695},{\"id\":2675},{\"id\":2696},{\"id\":2697},{\"id\":2698},{\"id\":2614},{\"id\":2700},{\"id\":2704},{\"id\":2705},{\"id\":2715},{\"id\":2701},{\"id\":2706},{\"id\":2707},{\"id\":2708},{\"id\":2702},{\"id\":2709},{\"id\":2710},{\"id\":2711},{\"id\":2703},{\"id\":2712},{\"id\":2713},{\"id\":2714},{\"id\":2615}],[],[],[]]}"
    },
    {
      "sequence": 7,
      "data": "{\"f\":\"applyChanged\",\"args\":[[],[{\"nodeType\":1,\"id\":2716,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"masterdiv\"},\"parentNode\":{\"id\":55}},{\"nodeType\":3,\"id\":2717,\"textContent\":\" \",\"previousSibling\":{\"id\":2716},\"parentNode\":{\"id\":55}},{\"nodeType\":3,\"id\":2718,\"textContent\":\" \",\"parentNode\":{\"id\":2716}},{\"nodeType\":1,\"id\":2719,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"top\"},\"previousSibling\":{\"id\":2718},\"parentNode\":{\"id\":2716}},{\"nodeType\":3,\"id\":2720,\"textContent\":\" \",\"previousSibling\":{\"id\":2719},\"parentNode\":{\"id\":2716}},{\"nodeType\":1,\"id\":2721,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"instructions\"},\"previousSibling\":{\"id\":2720},\"parentNode\":{\"id\":2716}},{\"nodeType\":3,\"id\":2722,\"textContent\":\" \",\"previousSibling\":{\"id\":2721},\"parentNode\":{\"id\":2716}},{\"nodeType\":1,\"id\":2723,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bottom\"},\"previousSibling\":{\"id\":2722},\"parentNode\":{\"id\":2716}},{\"nodeType\":3,\"id\":2724,\"textContent\":\" \",\"previousSibling\":{\"id\":2723},\"parentNode\":{\"id\":2716}},{\"nodeType\":3,\"id\":2725,\"textContent\":\" \",\"parentNode\":{\"id\":2719}},{\"nodeType\":1,\"id\":2726,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bcent\"},\"previousSibling\":{\"id\":2725},\"parentNode\":{\"id\":2719}},{\"nodeType\":3,\"id\":2727,\"textContent\":\" \",\"previousSibling\":{\"id\":2726},\"parentNode\":{\"id\":2719}},{\"nodeType\":3,\"id\":2728,\"textContent\":\" \",\"parentNode\":{\"id\":2726}},{\"nodeType\":1,\"id\":2729,\"tagName\":\"H3\",\"attributes\":{},\"previousSibling\":{\"id\":2728},\"parentNode\":{\"id\":2726}},{\"nodeType\":3,\"id\":2730,\"textContent\":\" \",\"previousSibling\":{\"id\":2729},\"parentNode\":{\"id\":2726}},{\"nodeType\":3,\"id\":2731,\"textContent\":\"DEBRIEFING\",\"parentNode\":{\"id\":2729}},{\"nodeType\":3,\"id\":2732,\"textContent\":\" \",\"parentNode\":{\"id\":2721}},{\"nodeType\":1,\"id\":2733,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"vcent\"},\"previousSibling\":{\"id\":2732},\"parentNode\":{\"id\":2721}},{\"nodeType\":3,\"id\":2734,\"textContent\":\" \",\"previousSibling\":{\"id\":2733},\"parentNode\":{\"id\":2721}},{\"nodeType\":3,\"id\":2735,\"textContent\":\" \",\"parentNode\":{\"id\":2733}},{\"nodeType\":1,\"id\":2736,\"tagName\":\"P\",\"attributes\":{\"style\":\"font-style:italic\"},\"previousSibling\":{\"id\":2735},\"parentNode\":{\"id\":2733}},{\"nodeType\":1,\"id\":2737,\"tagName\":\"P\",\"attributes\":{},\"previousSibling\":{\"id\":2736},\"parentNode\":{\"id\":2733}},{\"nodeType\":3,\"id\":2738,\"textContent\":\" \",\"previousSibling\":{\"id\":2737},\"parentNode\":{\"id\":2733}},{\"nodeType\":1,\"id\":2739,\"tagName\":\"P\",\"attributes\":{},\"previousSibling\":{\"id\":2738},\"parentNode\":{\"id\":2733}},{\"nodeType\":3,\"id\":2740,\"textContent\":\" \",\"previousSibling\":{\"id\":2739},\"parentNode\":{\"id\":2733}},{\"nodeType\":1,\"id\":2741,\"tagName\":\"P\",\"attributes\":{},\"previousSibling\":{\"id\":2740},\"parentNode\":{\"id\":2733}},{\"nodeType\":3,\"id\":2742,\"textContent\":\" \",\"previousSibling\":{\"id\":2741},\"parentNode\":{\"id\":2733}},{\"nodeType\":1,\"id\":2743,\"tagName\":\"P\",\"attributes\":{\"style\":\"font-style:bold;\"},\"previousSibling\":{\"id\":2742},\"parentNode\":{\"id\":2733}},{\"nodeType\":3,\"id\":2744,\"textContent\":\" \",\"previousSibling\":{\"id\":2743},\"parentNode\":{\"id\":2733}},{\"nodeType\":1,\"id\":2745,\"tagName\":\"P\",\"attributes\":{\"style\":\"font-style:italic;\"},\"previousSibling\":{\"id\":2744},\"parentNode\":{\"id\":2733}},{\"nodeType\":3,\"id\":2746,\"textContent\":\" \",\"previousSibling\":{\"id\":2745},\"parentNode\":{\"id\":2733}},{\"nodeType\":3,\"id\":2747,\"textContent\":\"Thank you very much for your participation! This debriefing will tell you more about the study, what you did, and why. \",\"parentNode\":{\"id\":2736}},{\"nodeType\":3,\"id\":2748,\"textContent\":\" \",\"parentNode\":{\"id\":2737}},{\"nodeType\":1,\"id\":2749,\"tagName\":\"B\",\"attributes\":{},\"previousSibling\":{\"id\":2748},\"parentNode\":{\"id\":2737}},{\"nodeType\":3,\"id\":2750,\"textContent\":\" You have just used a series of pictures (charts, graphs and diagrams) accompanied by different types of instructions to answer a series of problem solving questions. While you were using the pictures, we measured where you clicked, scrolled and pointed with the computer mouse. We also measured the accuracy of your responses and the time it took to complete each question.\",\"previousSibling\":{\"id\":2749},\"parentNode\":{\"id\":2737}},{\"nodeType\":3,\"id\":2751,\"textContent\":\"What did you just do?\",\"parentNode\":{\"id\":2749}},{\"nodeType\":3,\"id\":2752,\"textContent\":\" \",\"parentNode\":{\"id\":2739}},{\"nodeType\":1,\"id\":2753,\"tagName\":\"B\",\"attributes\":{},\"previousSibling\":{\"id\":2752},\"parentNode\":{\"id\":2739}},{\"nodeType\":3,\"id\":2754,\"textContent\":\" Researchers of learning and cognition have long been interested in how graphic displays of information can be used to communicate, solve problems, and generate insights. As powerful as graphics may be in their communicative efficiency, they're not always immediately intuitive to understand. In short, we know a great deal more about learning with representations than we do about the learning of representations. In this project we are building upon previous research on reading and graph comprehension to explore how readers make sense of unfamiliar representations. The instructions you saw for each type of graph are known as “scaffolding techniques”, and we will compare your performance with the scaffolding techniques you saw with the performance of other participants to determine which types of instructions are most effective in helping humans to make sense of unfamiliar graphs. \",\"previousSibling\":{\"id\":2753},\"parentNode\":{\"id\":2739}},{\"nodeType\":3,\"id\":2755,\"textContent\":\"Why did we have you do it?\",\"parentNode\":{\"id\":2753}},{\"nodeType\":1,\"id\":2756,\"tagName\":\"B\",\"attributes\":{},\"parentNode\":{\"id\":2741}},{\"nodeType\":3,\"id\":2757,\"textContent\":\" We expect that you will have found some of the graphics more difficult to use than others. We also expect that with the assistance of the instructions, after solving several problems you will learn to use the difficult graphics so that you can answer the questions even more quickly than without. If you would like to receive a copy of the results of the study, or have any further questions, please contact the researchers Primary Researcher: Amy Fox : a2fox@ucsd.edu Faculty Advisor : Dr. Jim Hollan : hollan@ucsd.edu \",\"previousSibling\":{\"id\":2756},\"parentNode\":{\"id\":2741}},{\"nodeType\":3,\"id\":2758,\"textContent\":\"What do we expect to find?\",\"parentNode\":{\"id\":2756}},{\"nodeType\":3,\"id\":2759,\"textContent\":\"It is important that you do not discuss this experiment with other students who might participate after you. They must participate in the same way as you did, without any knowledge of what the experiment entails, or the reasoning behind it.\",\"parentNode\":{\"id\":2743}},{\"nodeType\":3,\"id\":2760,\"textContent\":\"Thank you for your time! We hope you enjoyed participating in this study as much as we enjoyed designing it.\",\"parentNode\":{\"id\":2745}},{\"nodeType\":3,\"id\":2761,\"textContent\":\" \",\"parentNode\":{\"id\":2723}},{\"nodeType\":1,\"id\":2762,\"tagName\":\"BUTTON\",\"attributes\":{\"class\":\"btn\",\"type\":\"button\",\"id\":\"start\"},\"previousSibling\":{\"id\":2761},\"parentNode\":{\"id\":2723}},{\"nodeType\":3,\"id\":2763,\"textContent\":\" \",\"previousSibling\":{\"id\":2762},\"parentNode\":{\"id\":2723}},{\"nodeType\":3,\"id\":2764,\"textContent\":\"FINISH\",\"parentNode\":{\"id\":2762}}],[],[]]}"
    },
    {
      "sequence": 8,
      "data": "{\"f\":\"applyChanged\",\"args\":[[{\"id\":2716},{\"id\":2718},{\"id\":2719},{\"id\":2725},{\"id\":2726},{\"id\":2728},{\"id\":2729},{\"id\":2731},{\"id\":2730},{\"id\":2727},{\"id\":2720},{\"id\":2721},{\"id\":2732},{\"id\":2733},{\"id\":2735},{\"id\":2736},{\"id\":2747},{\"id\":2737},{\"id\":2748},{\"id\":2749},{\"id\":2751},{\"id\":2750},{\"id\":2738},{\"id\":2739},{\"id\":2752},{\"id\":2753},{\"id\":2755},{\"id\":2754},{\"id\":2740},{\"id\":2741},{\"id\":2756},{\"id\":2758},{\"id\":2757},{\"id\":2742},{\"id\":2743},{\"id\":2759},{\"id\":2744},{\"id\":2745},{\"id\":2760},{\"id\":2746},{\"id\":2734},{\"id\":2722},{\"id\":2723},{\"id\":2761},{\"id\":2762},{\"id\":2764},{\"id\":2763},{\"id\":2724},{\"id\":2717}],[],[],[]]}"
    },
    {
      "sequence": 9,
      "data": "{\"f\":\"applyChanged\",\"args\":[[],[{\"nodeType\":1,\"id\":2765,\"tagName\":\"PRE\",\"attributes\":{\"id\":\"jspsych-data-display\"},\"parentNode\":{\"id\":55}},{\"nodeType\":3,\"id\":2766,\"textContent\":\"[ { \\\"rt\\\": 55668, \\\"stimulus\\\": \\\"img/phone.png\\\", \\\"key_press\\\": 13, \\\"block\\\": \\\"phone\\\", \\\"trial_type\\\": \\\"single-stim\\\", \\\"trial_index\\\": 0, \\\"time_elapsed\\\": 55672, \\\"internal_node_id\\\": \\\"0.0-0.0\\\", \\\"subject\\\": \\\"Q0QHK\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"juliet\\\", \\\"condition\\\": \\\"115\\\" }, { \\\"rt\\\": 4282, \\\"url\\\": \\\"../views/src/external/consent.html\\\", \\\"block\\\": \\\"consent\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 1, \\\"time_elapsed\\\": 61046, \\\"internal_node_id\\\": \\\"0.0-1.0\\\", \\\"subject\\\": \\\"Q0QHK\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"juliet\\\", \\\"condition\\\": \\\"115\\\" }, { \\\"rt\\\": 9172, \\\"responses\\\": \\\"{\\\\\\\"Q0\\\\\\\":\\\\\\\"juliet\\\\\\\",\\\\\\\"Q1\\\\\\\":\\\\\\\"115\\\\\\\"}\\\", \\\"block\\\": \\\"codes\\\", \\\"trial_type\\\": \\\"survey-text\\\", \\\"trial_index\\\": 2, \\\"time_elapsed\\\": 71225, \\\"internal_node_id\\\": \\\"0.0-2.0\\\", \\\"subject\\\": \\\"Q0QHK\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"juliet\\\", \\\"condition\\\": \\\"115\\\" }, { \\\"rt\\\": 33380, \\\"url\\\": \\\"../views/src/external/instructions_lab.html\\\", \\\"block\\\": \\\"instructions_lab\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 3, \\\"time_elapsed\\\": 105697, \\\"internal_node_id\\\": \\\"0.0-3.0\\\", \\\"subject\\\": \\\"Q0QHK\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"juliet\\\", \\\"condition\\\": \\\"115\\\" }, { \\\"rt\\\": 18037, \\\"stimulus\\\": \\\"img/acme.png\\\", \\\"key_press\\\": 13, \\\"block\\\": \\\"scenario\\\", \\\"trial_type\\\": \\\"single-stim\\\", \\\"trial_index\\\": 4, \\\"time_elapsed\\\": 124736, \\\"internal_node_id\\\": \\\"0.0-4.0\\\", \\\"subject\\\": \\\"Q0QHK\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"juliet\\\", \\\"condition\\\": \\\"115\\\" }, { \\\"rt\\\": 23858, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 5, \\\"time_elapsed\\\": 149808, \\\"internal_node_id\\\": \\\"0.0-5.0-0.0\\\", \\\"subject\\\": \\\"Q0QHK\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"juliet\\\", \\\"condition\\\": \\\"115\\\", \\\"scenario\\\": \\\"acme\\\", \\\"question\\\": \\\"starttime\\\", \\\"q\\\": 1, \\\"clicks\\\": 1, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XFull-YFull\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 1, \\\"answer\\\": [ \\\"A\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"X \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"U \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-11 AM-A \\\", \\\"block\\\": \\\"triangular_scaffolded\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:1009,y:828,t:1527030349377};\\\", \\\"{x:1009,y:824,t:1527030349384};\\\", \\\"{x:1009,y:823,t:1527030349401};\\\", \\\"{x:1009,y:821,t:1527030349688};\\\", \\\"{x:1005,y:816,t:1527030349701};\\\", \\\"{x:986,y:808,t:1527030349717};\\\", \\\"{x:969,y:802,t:1527030349735};\\\", \\\"{x:955,y:797,t:1527030349750};\\\", \\\"{x:950,y:795,t:1527030349766};\\\", \\\"{x:950,y:794,t:1527030350009};\\\", \\\"{x:950,y:793,t:1527030350040};\\\", \\\"{x:951,y:793,t:1527030350051};\\\", \\\"{x:952,y:792,t:1527030350067};\\\", \\\"{x:955,y:792,t:1527030350084};\\\", \\\"{x:960,y:789,t:1527030350101};\\\", \\\"{x:965,y:787,t:1527030350118};\\\", \\\"{x:972,y:786,t:1527030350135};\\\", \\\"{x:975,y:786,t:1527030350151};\\\", \\\"{x:981,y:786,t:1527030350168};\\\", \\\"{x:983,y:786,t:1527030350184};\\\", \\\"{x:987,y:786,t:1527030350200};\\\", \\\"{x:992,y:787,t:1527030350217};\\\", \\\"{x:999,y:790,t:1527030350234};\\\", \\\"{x:1006,y:793,t:1527030350251};\\\", \\\"{x:1020,y:798,t:1527030350267};\\\", \\\"{x:1033,y:803,t:1527030350284};\\\", \\\"{x:1048,y:808,t:1527030350301};\\\", \\\"{x:1057,y:810,t:1527030350318};\\\", \\\"{x:1065,y:811,t:1527030350334};\\\", \\\"{x:1069,y:812,t:1527030350351};\\\", \\\"{x:1071,y:812,t:1527030350368};\\\", \\\"{x:1072,y:813,t:1527030350719};\\\", \\\"{x:1075,y:816,t:1527030350734};\\\", \\\"{x:1079,y:818,t:1527030350751};\\\", \\\"{x:1082,y:821,t:1527030350767};\\\", \\\"{x:1084,y:821,t:1527030350784};\\\", \\\"{x:1085,y:822,t:1527030350801};\\\", \\\"{x:1087,y:823,t:1527030351569};\\\", \\\"{x:1090,y:826,t:1527030351585};\\\", \\\"{x:1091,y:828,t:1527030351601};\\\", \\\"{x:1092,y:830,t:1527030351618};\\\", \\\"{x:1092,y:832,t:1527030351635};\\\", \\\"{x:1092,y:835,t:1527030351651};\\\", \\\"{x:1092,y:836,t:1527030351668};\\\", \\\"{x:1092,y:837,t:1527030351686};\\\", \\\"{x:1093,y:839,t:1527030351701};\\\", \\\"{x:1093,y:841,t:1527030351720};\\\", \\\"{x:1093,y:842,t:1527030351751};\\\", \\\"{x:1094,y:845,t:1527030351768};\\\", \\\"{x:1097,y:847,t:1527030351785};\\\", \\\"{x:1101,y:850,t:1527030351801};\\\", \\\"{x:1106,y:854,t:1527030351819};\\\", \\\"{x:1110,y:857,t:1527030351835};\\\", \\\"{x:1117,y:861,t:1527030351851};\\\", \\\"{x:1126,y:863,t:1527030351868};\\\", \\\"{x:1135,y:866,t:1527030351885};\\\", \\\"{x:1144,y:869,t:1527030351901};\\\", \\\"{x:1161,y:874,t:1527030351918};\\\", \\\"{x:1186,y:880,t:1527030351935};\\\", \\\"{x:1201,y:883,t:1527030351951};\\\", \\\"{x:1216,y:888,t:1527030351968};\\\", \\\"{x:1225,y:891,t:1527030351985};\\\", \\\"{x:1238,y:898,t:1527030352001};\\\", \\\"{x:1250,y:906,t:1527030352018};\\\", \\\"{x:1266,y:917,t:1527030352035};\\\", \\\"{x:1280,y:928,t:1527030352052};\\\", \\\"{x:1292,y:935,t:1527030352068};\\\", \\\"{x:1299,y:939,t:1527030352085};\\\", \\\"{x:1303,y:941,t:1527030352102};\\\", \\\"{x:1304,y:942,t:1527030352119};\\\", \\\"{x:1304,y:943,t:1527030352175};\\\", \\\"{x:1304,y:944,t:1527030352198};\\\", \\\"{x:1304,y:945,t:1527030352223};\\\", \\\"{x:1304,y:946,t:1527030352235};\\\", \\\"{x:1305,y:947,t:1527030352252};\\\", \\\"{x:1305,y:948,t:1527030352268};\\\", \\\"{x:1305,y:951,t:1527030352285};\\\", \\\"{x:1305,y:953,t:1527030352302};\\\", \\\"{x:1305,y:956,t:1527030352318};\\\", \\\"{x:1304,y:958,t:1527030352335};\\\", \\\"{x:1299,y:961,t:1527030352352};\\\", \\\"{x:1294,y:963,t:1527030352369};\\\", \\\"{x:1294,y:964,t:1527030352385};\\\", \\\"{x:1292,y:964,t:1527030352402};\\\", \\\"{x:1291,y:964,t:1527030352423};\\\", \\\"{x:1291,y:965,t:1527030352435};\\\", \\\"{x:1290,y:965,t:1527030352768};\\\", \\\"{x:1289,y:965,t:1527030352786};\\\", \\\"{x:1288,y:965,t:1527030352803};\\\", \\\"{x:1287,y:966,t:1527030352833};\\\", \\\"{x:1286,y:966,t:1527030352840};\\\", \\\"{x:1285,y:966,t:1527030352853};\\\", \\\"{x:1283,y:968,t:1527030352870};\\\", \\\"{x:1282,y:969,t:1527030352885};\\\", \\\"{x:1281,y:969,t:1527030352904};\\\", \\\"{x:1281,y:970,t:1527030352920};\\\", \\\"{x:1280,y:970,t:1527030353161};\\\", \\\"{x:1280,y:968,t:1527030353184};\\\", \\\"{x:1280,y:967,t:1527030353208};\\\", \\\"{x:1279,y:966,t:1527030353220};\\\", \\\"{x:1278,y:964,t:1527030353237};\\\", \\\"{x:1278,y:962,t:1527030353253};\\\", \\\"{x:1278,y:960,t:1527030353270};\\\", \\\"{x:1278,y:959,t:1527030353287};\\\", \\\"{x:1278,y:956,t:1527030353303};\\\", \\\"{x:1277,y:955,t:1527030353319};\\\", \\\"{x:1277,y:950,t:1527030353336};\\\", \\\"{x:1277,y:939,t:1527030353353};\\\", \\\"{x:1276,y:938,t:1527030353369};\\\", \\\"{x:1276,y:937,t:1527030353387};\\\", \\\"{x:1276,y:934,t:1527030353403};\\\", \\\"{x:1276,y:932,t:1527030353420};\\\", \\\"{x:1276,y:931,t:1527030353440};\\\", \\\"{x:1276,y:929,t:1527030353456};\\\", \\\"{x:1276,y:928,t:1527030353480};\\\", \\\"{x:1276,y:927,t:1527030353504};\\\", \\\"{x:1276,y:926,t:1527030353520};\\\", \\\"{x:1275,y:925,t:1527030353537};\\\", \\\"{x:1275,y:923,t:1527030353553};\\\", \\\"{x:1274,y:918,t:1527030353570};\\\", \\\"{x:1272,y:912,t:1527030353587};\\\", \\\"{x:1271,y:906,t:1527030353603};\\\", \\\"{x:1270,y:899,t:1527030353620};\\\", \\\"{x:1268,y:891,t:1527030353636};\\\", \\\"{x:1268,y:886,t:1527030353654};\\\", \\\"{x:1268,y:881,t:1527030353670};\\\", \\\"{x:1268,y:879,t:1527030353686};\\\", \\\"{x:1268,y:873,t:1527030353704};\\\", \\\"{x:1268,y:870,t:1527030353720};\\\", \\\"{x:1268,y:867,t:1527030353736};\\\", \\\"{x:1268,y:864,t:1527030353754};\\\", \\\"{x:1268,y:859,t:1527030353770};\\\", \\\"{x:1268,y:857,t:1527030353787};\\\", \\\"{x:1268,y:851,t:1527030353804};\\\", \\\"{x:1268,y:844,t:1527030353820};\\\", \\\"{x:1269,y:840,t:1527030353837};\\\", \\\"{x:1269,y:839,t:1527030353854};\\\", \\\"{x:1269,y:838,t:1527030353870};\\\", \\\"{x:1270,y:836,t:1527030353887};\\\", \\\"{x:1271,y:836,t:1527030354064};\\\", \\\"{x:1272,y:836,t:1527030354072};\\\", \\\"{x:1274,y:836,t:1527030354088};\\\", \\\"{x:1275,y:836,t:1527030354112};\\\", \\\"{x:1276,y:835,t:1527030354177};\\\", \\\"{x:1277,y:834,t:1527030354190};\\\", \\\"{x:1278,y:834,t:1527030354202};\\\", \\\"{x:1279,y:832,t:1527030354220};\\\", \\\"{x:1281,y:832,t:1527030354235};\\\", \\\"{x:1282,y:831,t:1527030354253};\\\", \\\"{x:1283,y:831,t:1527030354270};\\\", \\\"{x:1284,y:830,t:1527030356113};\\\", \\\"{x:1280,y:828,t:1527030356122};\\\", \\\"{x:1259,y:825,t:1527030356139};\\\", \\\"{x:1225,y:820,t:1527030356155};\\\", \\\"{x:1147,y:809,t:1527030356171};\\\", \\\"{x:1030,y:785,t:1527030356188};\\\", \\\"{x:872,y:740,t:1527030356204};\\\", \\\"{x:693,y:686,t:1527030356222};\\\", \\\"{x:511,y:638,t:1527030356239};\\\", \\\"{x:362,y:598,t:1527030356255};\\\", \\\"{x:197,y:558,t:1527030356271};\\\", \\\"{x:130,y:539,t:1527030356289};\\\", \\\"{x:82,y:525,t:1527030356307};\\\", \\\"{x:63,y:519,t:1527030356323};\\\", \\\"{x:52,y:516,t:1527030356338};\\\", \\\"{x:48,y:515,t:1527030356356};\\\", \\\"{x:46,y:514,t:1527030356373};\\\", \\\"{x:45,y:514,t:1527030356389};\\\", \\\"{x:43,y:512,t:1527030356406};\\\", \\\"{x:43,y:513,t:1527030356479};\\\", \\\"{x:51,y:518,t:1527030356489};\\\", \\\"{x:76,y:529,t:1527030356506};\\\", \\\"{x:109,y:542,t:1527030356524};\\\", \\\"{x:144,y:548,t:1527030356540};\\\", \\\"{x:170,y:552,t:1527030356557};\\\", \\\"{x:188,y:554,t:1527030356573};\\\", \\\"{x:200,y:554,t:1527030356591};\\\", \\\"{x:204,y:554,t:1527030356606};\\\", \\\"{x:205,y:554,t:1527030356623};\\\", \\\"{x:207,y:554,t:1527030356696};\\\", \\\"{x:210,y:552,t:1527030356706};\\\", \\\"{x:223,y:546,t:1527030356723};\\\", \\\"{x:237,y:537,t:1527030356740};\\\", \\\"{x:253,y:527,t:1527030356757};\\\", \\\"{x:267,y:519,t:1527030356773};\\\", \\\"{x:283,y:510,t:1527030356793};\\\", \\\"{x:302,y:500,t:1527030356807};\\\", \\\"{x:310,y:495,t:1527030356822};\\\", \\\"{x:320,y:492,t:1527030356840};\\\", \\\"{x:326,y:489,t:1527030356857};\\\", \\\"{x:336,y:486,t:1527030356873};\\\", \\\"{x:342,y:486,t:1527030356890};\\\", \\\"{x:347,y:486,t:1527030356907};\\\", \\\"{x:353,y:486,t:1527030356923};\\\", \\\"{x:357,y:488,t:1527030356940};\\\", \\\"{x:361,y:492,t:1527030356957};\\\", \\\"{x:363,y:494,t:1527030356973};\\\", \\\"{x:364,y:498,t:1527030356990};\\\", \\\"{x:364,y:500,t:1527030357015};\\\", \\\"{x:364,y:501,t:1527030357023};\\\", \\\"{x:364,y:505,t:1527030357040};\\\", \\\"{x:365,y:511,t:1527030357058};\\\", \\\"{x:369,y:519,t:1527030357073};\\\", \\\"{x:371,y:524,t:1527030357090};\\\", \\\"{x:374,y:528,t:1527030357107};\\\", \\\"{x:376,y:529,t:1527030357124};\\\", \\\"{x:377,y:529,t:1527030357167};\\\", \\\"{x:379,y:529,t:1527030357199};\\\", \\\"{x:380,y:528,t:1527030357214};\\\", \\\"{x:385,y:531,t:1527030357567};\\\", \\\"{x:389,y:544,t:1527030357576};\\\", \\\"{x:395,y:558,t:1527030357590};\\\", \\\"{x:431,y:632,t:1527030357607};\\\", \\\"{x:469,y:698,t:1527030357624};\\\", \\\"{x:507,y:754,t:1527030357640};\\\", \\\"{x:522,y:779,t:1527030357657};\\\", \\\"{x:534,y:794,t:1527030357674};\\\", \\\"{x:543,y:803,t:1527030357691};\\\", \\\"{x:545,y:805,t:1527030357707};\\\", \\\"{x:546,y:805,t:1527030357724};\\\", \\\"{x:547,y:805,t:1527030357783};\\\", \\\"{x:548,y:805,t:1527030357799};\\\", \\\"{x:548,y:803,t:1527030357808};\\\", \\\"{x:548,y:800,t:1527030357824};\\\", \\\"{x:548,y:793,t:1527030357842};\\\", \\\"{x:548,y:786,t:1527030357858};\\\", \\\"{x:547,y:777,t:1527030357874};\\\", \\\"{x:544,y:765,t:1527030357892};\\\", \\\"{x:541,y:755,t:1527030357909};\\\", \\\"{x:539,y:743,t:1527030357925};\\\", \\\"{x:535,y:736,t:1527030357941};\\\", \\\"{x:534,y:733,t:1527030357959};\\\", \\\"{x:533,y:731,t:1527030357975};\\\", \\\"{x:532,y:730,t:1527030357991};\\\", \\\"{x:531,y:729,t:1527030358072};\\\", \\\"{x:531,y:728,t:1527030358079};\\\", \\\"{x:530,y:727,t:1527030358092};\\\", \\\"{x:529,y:724,t:1527030358108};\\\", \\\"{x:527,y:721,t:1527030358124};\\\", \\\"{x:527,y:719,t:1527030358141};\\\", \\\"{x:526,y:718,t:1527030358158};\\\", \\\"{x:526,y:717,t:1527030364575};\\\", \\\"{x:527,y:717,t:1527030364599};\\\", \\\"{x:528,y:716,t:1527030364615};\\\", \\\"{x:529,y:716,t:1527030365824};\\\", \\\"{x:529,y:718,t:1527030365831};\\\", \\\"{x:531,y:720,t:1527030365848};\\\", \\\"{x:531,y:721,t:1527030365859};\\\", \\\"{x:531,y:722,t:1527030365876};\\\", \\\"{x:532,y:723,t:1527030365893};\\\", \\\"{x:534,y:723,t:1527030366094};\\\", \\\"{x:534,y:723,t:1527030366190};\\\" ] }, { \\\"rt\\\": 11073, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 6, \\\"time_elapsed\\\": 162142, \\\"internal_node_id\\\": \\\"0.0-5.0-1.0\\\", \\\"subject\\\": \\\"Q0QHK\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"juliet\\\", \\\"condition\\\": \\\"115\\\", \\\"scenario\\\": \\\"acme\\\", \\\"question\\\": \\\"starts\\\", \\\"q\\\": 2, \\\"clicks\\\": 1, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XFull-YFull\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 1, \\\"answer\\\": [ \\\"E\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"X \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"U \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"\\\", \\\"block\\\": \\\"triangular_scaffolded\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:534,y:722,t:1527030369208};\\\", \\\"{x:534,y:720,t:1527030369215};\\\", \\\"{x:534,y:719,t:1527030369232};\\\", \\\"{x:535,y:718,t:1527030369255};\\\", \\\"{x:538,y:717,t:1527030370216};\\\", \\\"{x:540,y:714,t:1527030370232};\\\", \\\"{x:543,y:711,t:1527030370249};\\\", \\\"{x:547,y:710,t:1527030370264};\\\", \\\"{x:551,y:707,t:1527030370281};\\\", \\\"{x:556,y:704,t:1527030370299};\\\", \\\"{x:558,y:702,t:1527030370314};\\\", \\\"{x:561,y:700,t:1527030370332};\\\", \\\"{x:564,y:698,t:1527030370348};\\\", \\\"{x:567,y:696,t:1527030370365};\\\", \\\"{x:572,y:693,t:1527030370384};\\\", \\\"{x:574,y:692,t:1527030370401};\\\", \\\"{x:578,y:690,t:1527030370418};\\\", \\\"{x:581,y:688,t:1527030370434};\\\", \\\"{x:584,y:688,t:1527030370450};\\\", \\\"{x:588,y:687,t:1527030370467};\\\", \\\"{x:591,y:686,t:1527030370484};\\\", \\\"{x:594,y:685,t:1527030370500};\\\", \\\"{x:596,y:684,t:1527030370518};\\\", \\\"{x:600,y:682,t:1527030370534};\\\", \\\"{x:601,y:682,t:1527030370551};\\\", \\\"{x:604,y:681,t:1527030370567};\\\", \\\"{x:607,y:679,t:1527030370584};\\\", \\\"{x:611,y:677,t:1527030370601};\\\", \\\"{x:613,y:675,t:1527030370618};\\\", \\\"{x:615,y:674,t:1527030370635};\\\", \\\"{x:615,y:673,t:1527030370652};\\\", \\\"{x:616,y:673,t:1527030370668};\\\", \\\"{x:617,y:672,t:1527030370684};\\\", \\\"{x:618,y:671,t:1527030374288};\\\", \\\"{x:620,y:668,t:1527030374305};\\\", \\\"{x:624,y:664,t:1527030374322};\\\", \\\"{x:633,y:657,t:1527030374338};\\\", \\\"{x:640,y:651,t:1527030374355};\\\", \\\"{x:650,y:643,t:1527030374374};\\\", \\\"{x:662,y:631,t:1527030374388};\\\", \\\"{x:673,y:624,t:1527030374404};\\\", \\\"{x:686,y:614,t:1527030374421};\\\", \\\"{x:698,y:605,t:1527030374438};\\\", \\\"{x:709,y:595,t:1527030374454};\\\", \\\"{x:724,y:584,t:1527030374470};\\\", \\\"{x:740,y:573,t:1527030374489};\\\", \\\"{x:754,y:561,t:1527030374503};\\\", \\\"{x:771,y:547,t:1527030374520};\\\", \\\"{x:792,y:530,t:1527030374537};\\\", \\\"{x:834,y:498,t:1527030374554};\\\", \\\"{x:880,y:475,t:1527030374570};\\\", \\\"{x:936,y:457,t:1527030374588};\\\", \\\"{x:1021,y:436,t:1527030374604};\\\", \\\"{x:1101,y:427,t:1527030374621};\\\", \\\"{x:1179,y:418,t:1527030374638};\\\", \\\"{x:1257,y:418,t:1527030374654};\\\", \\\"{x:1365,y:418,t:1527030374671};\\\", \\\"{x:1426,y:418,t:1527030374688};\\\", \\\"{x:1484,y:422,t:1527030374704};\\\", \\\"{x:1527,y:429,t:1527030374721};\\\", \\\"{x:1550,y:434,t:1527030374738};\\\", \\\"{x:1570,y:441,t:1527030374754};\\\", \\\"{x:1582,y:444,t:1527030374771};\\\", \\\"{x:1586,y:445,t:1527030374788};\\\", \\\"{x:1592,y:446,t:1527030374804};\\\", \\\"{x:1597,y:449,t:1527030374821};\\\", \\\"{x:1601,y:451,t:1527030374838};\\\", \\\"{x:1602,y:452,t:1527030374855};\\\", \\\"{x:1602,y:453,t:1527030374912};\\\", \\\"{x:1602,y:455,t:1527030374922};\\\", \\\"{x:1604,y:461,t:1527030374939};\\\", \\\"{x:1605,y:464,t:1527030374956};\\\", \\\"{x:1605,y:469,t:1527030374971};\\\", \\\"{x:1605,y:471,t:1527030374989};\\\", \\\"{x:1605,y:473,t:1527030375006};\\\", \\\"{x:1605,y:474,t:1527030375048};\\\", \\\"{x:1605,y:476,t:1527030375088};\\\", \\\"{x:1605,y:477,t:1527030375105};\\\", \\\"{x:1605,y:479,t:1527030375121};\\\", \\\"{x:1605,y:483,t:1527030375139};\\\", \\\"{x:1603,y:490,t:1527030375155};\\\", \\\"{x:1601,y:495,t:1527030375172};\\\", \\\"{x:1600,y:500,t:1527030375188};\\\", \\\"{x:1598,y:503,t:1527030375205};\\\", \\\"{x:1596,y:507,t:1527030375221};\\\", \\\"{x:1593,y:511,t:1527030375239};\\\", \\\"{x:1591,y:513,t:1527030375256};\\\", \\\"{x:1590,y:513,t:1527030375271};\\\", \\\"{x:1589,y:514,t:1527030375289};\\\", \\\"{x:1588,y:514,t:1527030375320};\\\", \\\"{x:1587,y:514,t:1527030375343};\\\", \\\"{x:1585,y:514,t:1527030375360};\\\", \\\"{x:1581,y:515,t:1527030375372};\\\", \\\"{x:1564,y:517,t:1527030375388};\\\", \\\"{x:1534,y:519,t:1527030375405};\\\", \\\"{x:1489,y:519,t:1527030375422};\\\", \\\"{x:1425,y:529,t:1527030375438};\\\", \\\"{x:1336,y:536,t:1527030375454};\\\", \\\"{x:1283,y:536,t:1527030375472};\\\", \\\"{x:1243,y:543,t:1527030375487};\\\", \\\"{x:1220,y:547,t:1527030375505};\\\", \\\"{x:1203,y:553,t:1527030375521};\\\", \\\"{x:1186,y:557,t:1527030375538};\\\", \\\"{x:1175,y:557,t:1527030375555};\\\", \\\"{x:1166,y:557,t:1527030375572};\\\", \\\"{x:1158,y:557,t:1527030375587};\\\", \\\"{x:1151,y:556,t:1527030375605};\\\", \\\"{x:1143,y:556,t:1527030375622};\\\", \\\"{x:1129,y:556,t:1527030375638};\\\", \\\"{x:1100,y:556,t:1527030375654};\\\", \\\"{x:1079,y:552,t:1527030375672};\\\", \\\"{x:1057,y:548,t:1527030375688};\\\", \\\"{x:1032,y:548,t:1527030375705};\\\", \\\"{x:1003,y:547,t:1527030375722};\\\", \\\"{x:978,y:542,t:1527030375738};\\\", \\\"{x:948,y:542,t:1527030375755};\\\", \\\"{x:918,y:542,t:1527030375772};\\\", \\\"{x:887,y:542,t:1527030375788};\\\", \\\"{x:848,y:542,t:1527030375805};\\\", \\\"{x:805,y:541,t:1527030375822};\\\", \\\"{x:727,y:535,t:1527030375839};\\\", \\\"{x:668,y:533,t:1527030375855};\\\", \\\"{x:624,y:526,t:1527030375870};\\\", \\\"{x:506,y:507,t:1527030375886};\\\", \\\"{x:428,y:496,t:1527030375905};\\\", \\\"{x:375,y:488,t:1527030375921};\\\", \\\"{x:334,y:485,t:1527030375938};\\\", \\\"{x:307,y:481,t:1527030375956};\\\", \\\"{x:287,y:478,t:1527030375972};\\\", \\\"{x:275,y:477,t:1527030375988};\\\", \\\"{x:267,y:477,t:1527030376006};\\\", \\\"{x:260,y:478,t:1527030376023};\\\", \\\"{x:257,y:482,t:1527030376038};\\\", \\\"{x:253,y:489,t:1527030376056};\\\", \\\"{x:250,y:494,t:1527030376072};\\\", \\\"{x:249,y:502,t:1527030376088};\\\", \\\"{x:249,y:512,t:1527030376106};\\\", \\\"{x:246,y:518,t:1527030376122};\\\", \\\"{x:246,y:523,t:1527030376139};\\\", \\\"{x:245,y:526,t:1527030376155};\\\", \\\"{x:243,y:534,t:1527030376172};\\\", \\\"{x:242,y:545,t:1527030376190};\\\", \\\"{x:238,y:557,t:1527030376205};\\\", \\\"{x:235,y:566,t:1527030376221};\\\", \\\"{x:228,y:578,t:1527030376240};\\\", \\\"{x:224,y:582,t:1527030376257};\\\", \\\"{x:220,y:586,t:1527030376272};\\\", \\\"{x:216,y:589,t:1527030376288};\\\", \\\"{x:214,y:592,t:1527030376306};\\\", \\\"{x:212,y:594,t:1527030376322};\\\", \\\"{x:211,y:595,t:1527030376339};\\\", \\\"{x:211,y:596,t:1527030376356};\\\", \\\"{x:210,y:597,t:1527030376372};\\\", \\\"{x:209,y:597,t:1527030376390};\\\", \\\"{x:208,y:598,t:1527030376407};\\\", \\\"{x:207,y:600,t:1527030376422};\\\", \\\"{x:206,y:603,t:1527030376439};\\\", \\\"{x:203,y:609,t:1527030376456};\\\", \\\"{x:200,y:613,t:1527030376472};\\\", \\\"{x:196,y:616,t:1527030376489};\\\", \\\"{x:193,y:621,t:1527030376506};\\\", \\\"{x:191,y:623,t:1527030376523};\\\", \\\"{x:189,y:625,t:1527030376538};\\\", \\\"{x:188,y:626,t:1527030376556};\\\", \\\"{x:186,y:627,t:1527030376573};\\\", \\\"{x:184,y:629,t:1527030376588};\\\", \\\"{x:181,y:630,t:1527030376605};\\\", \\\"{x:178,y:631,t:1527030376622};\\\", \\\"{x:178,y:632,t:1527030376638};\\\", \\\"{x:175,y:632,t:1527030376655};\\\", \\\"{x:173,y:632,t:1527030376673};\\\", \\\"{x:172,y:632,t:1527030376905};\\\", \\\"{x:171,y:632,t:1527030376998};\\\", \\\"{x:177,y:635,t:1527030377006};\\\", \\\"{x:202,y:642,t:1527030377023};\\\", \\\"{x:267,y:658,t:1527030377040};\\\", \\\"{x:336,y:678,t:1527030377055};\\\", \\\"{x:412,y:692,t:1527030377072};\\\", \\\"{x:483,y:704,t:1527030377090};\\\", \\\"{x:540,y:716,t:1527030377106};\\\", \\\"{x:579,y:726,t:1527030377123};\\\", \\\"{x:603,y:733,t:1527030377139};\\\", \\\"{x:617,y:737,t:1527030377155};\\\", \\\"{x:623,y:739,t:1527030377173};\\\", \\\"{x:625,y:740,t:1527030377190};\\\", \\\"{x:626,y:741,t:1527030377279};\\\", \\\"{x:625,y:741,t:1527030377319};\\\", \\\"{x:621,y:741,t:1527030377327};\\\", \\\"{x:613,y:740,t:1527030377339};\\\", \\\"{x:597,y:736,t:1527030377356};\\\", \\\"{x:576,y:732,t:1527030377373};\\\", \\\"{x:557,y:731,t:1527030377391};\\\", \\\"{x:531,y:727,t:1527030377406};\\\", \\\"{x:523,y:726,t:1527030377423};\\\", \\\"{x:521,y:725,t:1527030377439};\\\", \\\"{x:520,y:725,t:1527030377457};\\\", \\\"{x:519,y:724,t:1527030379048};\\\", \\\"{x:519,y:723,t:1527030379058};\\\", \\\"{x:519,y:722,t:1527030379074};\\\", \\\"{x:519,y:721,t:1527030379095};\\\", \\\"{x:519,y:720,t:1527030379303};\\\", \\\"{x:519,y:719,t:1527030379319};\\\" ] }, { \\\"rt\\\": 47901, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 7, \\\"time_elapsed\\\": 211255, \\\"internal_node_id\\\": \\\"0.0-5.0-2.0\\\", \\\"subject\\\": \\\"Q0QHK\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"juliet\\\", \\\"condition\\\": \\\"115\\\", \\\"scenario\\\": \\\"acme\\\", \\\"question\\\": \\\"meets\\\", \\\"q\\\": 3, \\\"clicks\\\": 1, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XFull-YFull\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 1, \\\"answer\\\": [ \\\"Z\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"X \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"U \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-A -Z -A -Z -Z -12 PM-Z -Z -12 PM\\\", \\\"block\\\": \\\"triangular_scaffolded\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:520,y:718,t:1527030380751};\\\", \\\"{x:520,y:717,t:1527030380775};\\\", \\\"{x:521,y:717,t:1527030380783};\\\", \\\"{x:522,y:716,t:1527030380847};\\\", \\\"{x:523,y:715,t:1527030381488};\\\", \\\"{x:524,y:714,t:1527030381520};\\\", \\\"{x:525,y:714,t:1527030381576};\\\", \\\"{x:526,y:713,t:1527030381711};\\\", \\\"{x:526,y:712,t:1527030381759};\\\", \\\"{x:527,y:712,t:1527030381816};\\\", \\\"{x:528,y:711,t:1527030384135};\\\", \\\"{x:529,y:709,t:1527030384153};\\\", \\\"{x:529,y:708,t:1527030384175};\\\", \\\"{x:529,y:706,t:1527030384188};\\\", \\\"{x:530,y:705,t:1527030384207};\\\", \\\"{x:530,y:704,t:1527030384223};\\\", \\\"{x:530,y:703,t:1527030384711};\\\", \\\"{x:530,y:702,t:1527030384999};\\\", \\\"{x:530,y:701,t:1527030385015};\\\", \\\"{x:531,y:700,t:1527030385024};\\\", \\\"{x:531,y:699,t:1527030394135};\\\", \\\"{x:531,y:698,t:1527030394151};\\\", \\\"{x:531,y:697,t:1527030394166};\\\", \\\"{x:531,y:696,t:1527030394255};\\\", \\\"{x:531,y:695,t:1527030394295};\\\", \\\"{x:531,y:694,t:1527030396553};\\\", \\\"{x:531,y:693,t:1527030396617};\\\", \\\"{x:531,y:692,t:1527030396682};\\\", \\\"{x:531,y:691,t:1527030396713};\\\", \\\"{x:531,y:690,t:1527030396802};\\\", \\\"{x:531,y:689,t:1527030399554};\\\", \\\"{x:531,y:688,t:1527030399609};\\\", \\\"{x:531,y:687,t:1527030401754};\\\", \\\"{x:531,y:686,t:1527030401770};\\\", \\\"{x:531,y:685,t:1527030401779};\\\", \\\"{x:531,y:684,t:1527030401835};\\\", \\\"{x:531,y:683,t:1527030403930};\\\", \\\"{x:531,y:681,t:1527030403953};\\\", \\\"{x:531,y:679,t:1527030403964};\\\", \\\"{x:531,y:675,t:1527030403981};\\\", \\\"{x:533,y:671,t:1527030403997};\\\", \\\"{x:535,y:664,t:1527030404015};\\\", \\\"{x:536,y:659,t:1527030404031};\\\", \\\"{x:536,y:655,t:1527030404048};\\\", \\\"{x:537,y:652,t:1527030404064};\\\", \\\"{x:537,y:648,t:1527030404083};\\\", \\\"{x:537,y:646,t:1527030404098};\\\", \\\"{x:537,y:645,t:1527030404114};\\\", \\\"{x:537,y:643,t:1527030404152};\\\", \\\"{x:537,y:642,t:1527030404169};\\\", \\\"{x:537,y:640,t:1527030404185};\\\", \\\"{x:537,y:639,t:1527030404201};\\\", \\\"{x:537,y:636,t:1527030404214};\\\", \\\"{x:535,y:634,t:1527030404231};\\\", \\\"{x:535,y:629,t:1527030404248};\\\", \\\"{x:534,y:627,t:1527030404263};\\\", \\\"{x:532,y:621,t:1527030404280};\\\", \\\"{x:530,y:618,t:1527030404298};\\\", \\\"{x:530,y:617,t:1527030404314};\\\", \\\"{x:529,y:617,t:1527030404331};\\\", \\\"{x:527,y:615,t:1527030404586};\\\", \\\"{x:527,y:614,t:1527030404598};\\\", \\\"{x:525,y:612,t:1527030404617};\\\", \\\"{x:523,y:609,t:1527030404631};\\\", \\\"{x:521,y:606,t:1527030404648};\\\", \\\"{x:520,y:605,t:1527030404665};\\\", \\\"{x:519,y:604,t:1527030405122};\\\", \\\"{x:518,y:604,t:1527030405202};\\\", \\\"{x:517,y:604,t:1527030405290};\\\", \\\"{x:516,y:604,t:1527030405385};\\\", \\\"{x:515,y:604,t:1527030405698};\\\", \\\"{x:514,y:605,t:1527030405717};\\\", \\\"{x:513,y:605,t:1527030405733};\\\", \\\"{x:512,y:606,t:1527030405750};\\\", \\\"{x:512,y:607,t:1527030405777};\\\", \\\"{x:512,y:608,t:1527030405948};\\\", \\\"{x:512,y:610,t:1527030406002};\\\", \\\"{x:511,y:611,t:1527030406050};\\\", \\\"{x:511,y:613,t:1527030406171};\\\", \\\"{x:511,y:614,t:1527030406215};\\\", \\\"{x:510,y:615,t:1527030406233};\\\", \\\"{x:509,y:616,t:1527030406265};\\\", \\\"{x:509,y:617,t:1527030406297};\\\", \\\"{x:509,y:619,t:1527030406338};\\\", \\\"{x:508,y:621,t:1527030406354};\\\", \\\"{x:508,y:622,t:1527030406377};\\\", \\\"{x:508,y:623,t:1527030406458};\\\", \\\"{x:508,y:624,t:1527030406466};\\\", \\\"{x:508,y:625,t:1527030406483};\\\", \\\"{x:508,y:628,t:1527030406499};\\\", \\\"{x:508,y:630,t:1527030406516};\\\", \\\"{x:508,y:633,t:1527030406533};\\\", \\\"{x:508,y:636,t:1527030406549};\\\", \\\"{x:508,y:638,t:1527030406566};\\\", \\\"{x:509,y:643,t:1527030406584};\\\", \\\"{x:510,y:650,t:1527030406600};\\\", \\\"{x:510,y:655,t:1527030406617};\\\", \\\"{x:514,y:666,t:1527030406633};\\\", \\\"{x:517,y:673,t:1527030406649};\\\", \\\"{x:519,y:677,t:1527030406665};\\\", \\\"{x:524,y:684,t:1527030406682};\\\", \\\"{x:530,y:690,t:1527030406700};\\\", \\\"{x:537,y:693,t:1527030406716};\\\", \\\"{x:539,y:693,t:1527030406733};\\\", \\\"{x:540,y:693,t:1527030406750};\\\", \\\"{x:541,y:693,t:1527030407250};\\\", \\\"{x:542,y:696,t:1527030407268};\\\", \\\"{x:544,y:697,t:1527030407284};\\\", \\\"{x:551,y:700,t:1527030407300};\\\", \\\"{x:557,y:701,t:1527030407319};\\\", \\\"{x:565,y:702,t:1527030407334};\\\", \\\"{x:571,y:703,t:1527030407350};\\\", \\\"{x:575,y:704,t:1527030407367};\\\", \\\"{x:581,y:705,t:1527030407383};\\\", \\\"{x:588,y:705,t:1527030407400};\\\", \\\"{x:605,y:708,t:1527030407417};\\\", \\\"{x:619,y:710,t:1527030407433};\\\", \\\"{x:635,y:712,t:1527030407450};\\\", \\\"{x:650,y:715,t:1527030407467};\\\", \\\"{x:668,y:718,t:1527030407483};\\\", \\\"{x:686,y:720,t:1527030407500};\\\", \\\"{x:708,y:723,t:1527030407517};\\\", \\\"{x:734,y:727,t:1527030407533};\\\", \\\"{x:763,y:731,t:1527030407550};\\\", \\\"{x:799,y:739,t:1527030407568};\\\", \\\"{x:832,y:748,t:1527030407583};\\\", \\\"{x:865,y:755,t:1527030407600};\\\", \\\"{x:939,y:772,t:1527030407617};\\\", \\\"{x:984,y:786,t:1527030407634};\\\", \\\"{x:1032,y:801,t:1527030407650};\\\", \\\"{x:1068,y:811,t:1527030407667};\\\", \\\"{x:1110,y:822,t:1527030407684};\\\", \\\"{x:1157,y:836,t:1527030407700};\\\", \\\"{x:1195,y:844,t:1527030407717};\\\", \\\"{x:1227,y:853,t:1527030407735};\\\", \\\"{x:1251,y:860,t:1527030407751};\\\", \\\"{x:1270,y:867,t:1527030407767};\\\", \\\"{x:1280,y:868,t:1527030407784};\\\", \\\"{x:1285,y:871,t:1527030407801};\\\", \\\"{x:1291,y:872,t:1527030407817};\\\", \\\"{x:1289,y:872,t:1527030407906};\\\", \\\"{x:1287,y:872,t:1527030407917};\\\", \\\"{x:1283,y:870,t:1527030407935};\\\", \\\"{x:1280,y:870,t:1527030407951};\\\", \\\"{x:1273,y:866,t:1527030407968};\\\", \\\"{x:1267,y:864,t:1527030407985};\\\", \\\"{x:1261,y:863,t:1527030408001};\\\", \\\"{x:1255,y:862,t:1527030408017};\\\", \\\"{x:1251,y:860,t:1527030408034};\\\", \\\"{x:1249,y:859,t:1527030408051};\\\", \\\"{x:1247,y:859,t:1527030408068};\\\", \\\"{x:1246,y:859,t:1527030408090};\\\", \\\"{x:1245,y:859,t:1527030408106};\\\", \\\"{x:1244,y:858,t:1527030408122};\\\", \\\"{x:1243,y:858,t:1527030408210};\\\", \\\"{x:1243,y:857,t:1527030408226};\\\", \\\"{x:1243,y:856,t:1527030408235};\\\", \\\"{x:1243,y:853,t:1527030408252};\\\", \\\"{x:1244,y:850,t:1527030408268};\\\", \\\"{x:1250,y:844,t:1527030408284};\\\", \\\"{x:1258,y:840,t:1527030408301};\\\", \\\"{x:1268,y:834,t:1527030408317};\\\", \\\"{x:1276,y:829,t:1527030408337};\\\", \\\"{x:1283,y:827,t:1527030408351};\\\", \\\"{x:1292,y:825,t:1527030408367};\\\", \\\"{x:1298,y:823,t:1527030408384};\\\", \\\"{x:1306,y:819,t:1527030408401};\\\", \\\"{x:1312,y:817,t:1527030408417};\\\", \\\"{x:1314,y:816,t:1527030408434};\\\", \\\"{x:1314,y:815,t:1527030408553};\\\", \\\"{x:1313,y:815,t:1527030408618};\\\", \\\"{x:1311,y:815,t:1527030408666};\\\", \\\"{x:1310,y:815,t:1527030408682};\\\", \\\"{x:1309,y:816,t:1527030408714};\\\", \\\"{x:1308,y:816,t:1527030408763};\\\", \\\"{x:1308,y:817,t:1527030408819};\\\", \\\"{x:1307,y:818,t:1527030408834};\\\", \\\"{x:1305,y:818,t:1527030408880};\\\", \\\"{x:1304,y:818,t:1527030408905};\\\", \\\"{x:1303,y:818,t:1527030408929};\\\", \\\"{x:1302,y:819,t:1527030408945};\\\", \\\"{x:1302,y:820,t:1527030408953};\\\", \\\"{x:1301,y:820,t:1527030408968};\\\", \\\"{x:1300,y:820,t:1527030408984};\\\", \\\"{x:1299,y:822,t:1527030409001};\\\", \\\"{x:1298,y:823,t:1527030409018};\\\", \\\"{x:1298,y:824,t:1527030409411};\\\", \\\"{x:1298,y:825,t:1527030409426};\\\", \\\"{x:1299,y:825,t:1527030409436};\\\", \\\"{x:1305,y:827,t:1527030409452};\\\", \\\"{x:1310,y:827,t:1527030409469};\\\", \\\"{x:1323,y:829,t:1527030409486};\\\", \\\"{x:1333,y:830,t:1527030409502};\\\", \\\"{x:1345,y:830,t:1527030409519};\\\", \\\"{x:1355,y:832,t:1527030409536};\\\", \\\"{x:1363,y:832,t:1527030409551};\\\", \\\"{x:1367,y:833,t:1527030409568};\\\", \\\"{x:1368,y:833,t:1527030409585};\\\", \\\"{x:1367,y:833,t:1527030409962};\\\", \\\"{x:1366,y:833,t:1527030409993};\\\", \\\"{x:1364,y:833,t:1527030410906};\\\", \\\"{x:1364,y:835,t:1527030410938};\\\", \\\"{x:1363,y:837,t:1527030410954};\\\", \\\"{x:1362,y:839,t:1527030410970};\\\", \\\"{x:1361,y:843,t:1527030410985};\\\", \\\"{x:1360,y:847,t:1527030411003};\\\", \\\"{x:1359,y:851,t:1527030411020};\\\", \\\"{x:1358,y:856,t:1527030411036};\\\", \\\"{x:1357,y:859,t:1527030411052};\\\", \\\"{x:1356,y:864,t:1527030411070};\\\", \\\"{x:1356,y:867,t:1527030411087};\\\", \\\"{x:1356,y:871,t:1527030411103};\\\", \\\"{x:1354,y:874,t:1527030411120};\\\", \\\"{x:1354,y:875,t:1527030411136};\\\", \\\"{x:1354,y:877,t:1527030411153};\\\", \\\"{x:1354,y:880,t:1527030411169};\\\", \\\"{x:1354,y:882,t:1527030411186};\\\", \\\"{x:1353,y:884,t:1527030411202};\\\", \\\"{x:1353,y:888,t:1527030411220};\\\", \\\"{x:1353,y:889,t:1527030411237};\\\", \\\"{x:1352,y:892,t:1527030411253};\\\", \\\"{x:1351,y:893,t:1527030411271};\\\", \\\"{x:1351,y:894,t:1527030411302};\\\", \\\"{x:1350,y:894,t:1527030411450};\\\", \\\"{x:1346,y:893,t:1527030411457};\\\", \\\"{x:1337,y:890,t:1527030411471};\\\", \\\"{x:1322,y:884,t:1527030411487};\\\", \\\"{x:1312,y:882,t:1527030411502};\\\", \\\"{x:1307,y:879,t:1527030411519};\\\", \\\"{x:1298,y:877,t:1527030411536};\\\", \\\"{x:1291,y:875,t:1527030411553};\\\", \\\"{x:1286,y:872,t:1527030411569};\\\", \\\"{x:1284,y:871,t:1527030411586};\\\", \\\"{x:1281,y:870,t:1527030411603};\\\", \\\"{x:1278,y:868,t:1527030411619};\\\", \\\"{x:1276,y:868,t:1527030411637};\\\", \\\"{x:1273,y:866,t:1527030411652};\\\", \\\"{x:1272,y:865,t:1527030411669};\\\", \\\"{x:1270,y:864,t:1527030411687};\\\", \\\"{x:1269,y:862,t:1527030411702};\\\", \\\"{x:1268,y:862,t:1527030411719};\\\", \\\"{x:1267,y:862,t:1527030411736};\\\", \\\"{x:1267,y:860,t:1527030411753};\\\", \\\"{x:1267,y:859,t:1527030411769};\\\", \\\"{x:1267,y:856,t:1527030411786};\\\", \\\"{x:1268,y:852,t:1527030411803};\\\", \\\"{x:1269,y:848,t:1527030411820};\\\", \\\"{x:1272,y:844,t:1527030411836};\\\", \\\"{x:1274,y:839,t:1527030411853};\\\", \\\"{x:1276,y:836,t:1527030411869};\\\", \\\"{x:1278,y:833,t:1527030411887};\\\", \\\"{x:1279,y:832,t:1527030411903};\\\", \\\"{x:1279,y:831,t:1527030411921};\\\", \\\"{x:1281,y:831,t:1527030418058};\\\", \\\"{x:1286,y:831,t:1527030418073};\\\", \\\"{x:1290,y:831,t:1527030418092};\\\", \\\"{x:1297,y:831,t:1527030418107};\\\", \\\"{x:1302,y:831,t:1527030418125};\\\", \\\"{x:1309,y:831,t:1527030418142};\\\", \\\"{x:1316,y:831,t:1527030418158};\\\", \\\"{x:1325,y:831,t:1527030418175};\\\", \\\"{x:1332,y:831,t:1527030418192};\\\", \\\"{x:1338,y:831,t:1527030418207};\\\", \\\"{x:1345,y:831,t:1527030418224};\\\", \\\"{x:1349,y:831,t:1527030418241};\\\", \\\"{x:1352,y:831,t:1527030418257};\\\", \\\"{x:1353,y:831,t:1527030418274};\\\", \\\"{x:1353,y:834,t:1527030419442};\\\", \\\"{x:1353,y:837,t:1527030419458};\\\", \\\"{x:1352,y:838,t:1527030419474};\\\", \\\"{x:1352,y:840,t:1527030419491};\\\", \\\"{x:1352,y:841,t:1527030419537};\\\", \\\"{x:1351,y:843,t:1527030419577};\\\", \\\"{x:1351,y:844,t:1527030419609};\\\", \\\"{x:1351,y:846,t:1527030419625};\\\", \\\"{x:1351,y:850,t:1527030419640};\\\", \\\"{x:1351,y:852,t:1527030419658};\\\", \\\"{x:1349,y:856,t:1527030419674};\\\", \\\"{x:1349,y:860,t:1527030419691};\\\", \\\"{x:1348,y:864,t:1527030419708};\\\", \\\"{x:1348,y:867,t:1527030419725};\\\", \\\"{x:1348,y:872,t:1527030419741};\\\", \\\"{x:1348,y:874,t:1527030419758};\\\", \\\"{x:1347,y:877,t:1527030419775};\\\", \\\"{x:1346,y:880,t:1527030419792};\\\", \\\"{x:1346,y:882,t:1527030419807};\\\", \\\"{x:1346,y:885,t:1527030419825};\\\", \\\"{x:1345,y:887,t:1527030419841};\\\", \\\"{x:1345,y:889,t:1527030419858};\\\", \\\"{x:1345,y:891,t:1527030419875};\\\", \\\"{x:1345,y:892,t:1527030419892};\\\", \\\"{x:1345,y:894,t:1527030419907};\\\", \\\"{x:1345,y:897,t:1527030419925};\\\", \\\"{x:1345,y:899,t:1527030419942};\\\", \\\"{x:1345,y:904,t:1527030419959};\\\", \\\"{x:1345,y:907,t:1527030419975};\\\", \\\"{x:1345,y:910,t:1527030419992};\\\", \\\"{x:1345,y:913,t:1527030420008};\\\", \\\"{x:1345,y:919,t:1527030420025};\\\", \\\"{x:1345,y:922,t:1527030420041};\\\", \\\"{x:1345,y:925,t:1527030420058};\\\", \\\"{x:1345,y:928,t:1527030420075};\\\", \\\"{x:1345,y:930,t:1527030420092};\\\", \\\"{x:1345,y:932,t:1527030420109};\\\", \\\"{x:1345,y:935,t:1527030420125};\\\", \\\"{x:1345,y:937,t:1527030420142};\\\", \\\"{x:1345,y:939,t:1527030420158};\\\", \\\"{x:1345,y:942,t:1527030420175};\\\", \\\"{x:1344,y:943,t:1527030420192};\\\", \\\"{x:1344,y:945,t:1527030420208};\\\", \\\"{x:1344,y:947,t:1527030420226};\\\", \\\"{x:1344,y:948,t:1527030420242};\\\", \\\"{x:1344,y:949,t:1527030420258};\\\", \\\"{x:1344,y:951,t:1527030420275};\\\", \\\"{x:1344,y:952,t:1527030420297};\\\", \\\"{x:1344,y:953,t:1527030420308};\\\", \\\"{x:1344,y:954,t:1527030420325};\\\", \\\"{x:1344,y:955,t:1527030420342};\\\", \\\"{x:1344,y:956,t:1527030420358};\\\", \\\"{x:1344,y:957,t:1527030420375};\\\", \\\"{x:1344,y:959,t:1527030420392};\\\", \\\"{x:1344,y:962,t:1527030420409};\\\", \\\"{x:1345,y:964,t:1527030420425};\\\", \\\"{x:1345,y:965,t:1527030420442};\\\", \\\"{x:1345,y:967,t:1527030420459};\\\", \\\"{x:1345,y:969,t:1527030420475};\\\", \\\"{x:1345,y:970,t:1527030420530};\\\", \\\"{x:1345,y:969,t:1527030420626};\\\", \\\"{x:1345,y:962,t:1527030420643};\\\", \\\"{x:1345,y:954,t:1527030420660};\\\", \\\"{x:1345,y:946,t:1527030420675};\\\", \\\"{x:1345,y:940,t:1527030420693};\\\", \\\"{x:1345,y:932,t:1527030420709};\\\", \\\"{x:1345,y:929,t:1527030420725};\\\", \\\"{x:1345,y:923,t:1527030420742};\\\", \\\"{x:1345,y:919,t:1527030420759};\\\", \\\"{x:1345,y:917,t:1527030420775};\\\", \\\"{x:1345,y:914,t:1527030420792};\\\", \\\"{x:1345,y:911,t:1527030420810};\\\", \\\"{x:1345,y:910,t:1527030420825};\\\", \\\"{x:1345,y:909,t:1527030420842};\\\", \\\"{x:1345,y:908,t:1527030420882};\\\", \\\"{x:1345,y:907,t:1527030420892};\\\", \\\"{x:1345,y:906,t:1527030420910};\\\", \\\"{x:1345,y:904,t:1527030420926};\\\", \\\"{x:1345,y:902,t:1527030420942};\\\", \\\"{x:1345,y:899,t:1527030420959};\\\", \\\"{x:1345,y:896,t:1527030420975};\\\", \\\"{x:1345,y:893,t:1527030420991};\\\", \\\"{x:1345,y:889,t:1527030421009};\\\", \\\"{x:1345,y:886,t:1527030421025};\\\", \\\"{x:1346,y:885,t:1527030421041};\\\", \\\"{x:1346,y:884,t:1527030421059};\\\", \\\"{x:1346,y:883,t:1527030421076};\\\", \\\"{x:1346,y:881,t:1527030421091};\\\", \\\"{x:1346,y:880,t:1527030421108};\\\", \\\"{x:1346,y:879,t:1527030421126};\\\", \\\"{x:1346,y:878,t:1527030421142};\\\", \\\"{x:1346,y:877,t:1527030421169};\\\", \\\"{x:1345,y:875,t:1527030421185};\\\", \\\"{x:1345,y:874,t:1527030421193};\\\", \\\"{x:1345,y:871,t:1527030421209};\\\", \\\"{x:1345,y:867,t:1527030421225};\\\", \\\"{x:1345,y:863,t:1527030421242};\\\", \\\"{x:1345,y:857,t:1527030421259};\\\", \\\"{x:1345,y:854,t:1527030421276};\\\", \\\"{x:1345,y:849,t:1527030421292};\\\", \\\"{x:1345,y:842,t:1527030421309};\\\", \\\"{x:1345,y:837,t:1527030421326};\\\", \\\"{x:1345,y:833,t:1527030421342};\\\", \\\"{x:1345,y:829,t:1527030421359};\\\", \\\"{x:1345,y:827,t:1527030421376};\\\", \\\"{x:1344,y:825,t:1527030421392};\\\", \\\"{x:1344,y:824,t:1527030421409};\\\", \\\"{x:1344,y:823,t:1527030421490};\\\", \\\"{x:1344,y:825,t:1527030421617};\\\", \\\"{x:1344,y:827,t:1527030421626};\\\", \\\"{x:1344,y:834,t:1527030421643};\\\", \\\"{x:1344,y:840,t:1527030421658};\\\", \\\"{x:1344,y:844,t:1527030421675};\\\", \\\"{x:1344,y:847,t:1527030421693};\\\", \\\"{x:1344,y:851,t:1527030421709};\\\", \\\"{x:1342,y:855,t:1527030421726};\\\", \\\"{x:1341,y:861,t:1527030421743};\\\", \\\"{x:1340,y:868,t:1527030421759};\\\", \\\"{x:1340,y:874,t:1527030421776};\\\", \\\"{x:1338,y:885,t:1527030421794};\\\", \\\"{x:1337,y:888,t:1527030421809};\\\", \\\"{x:1337,y:891,t:1527030421826};\\\", \\\"{x:1337,y:892,t:1527030421843};\\\", \\\"{x:1337,y:895,t:1527030421859};\\\", \\\"{x:1337,y:900,t:1527030421875};\\\", \\\"{x:1337,y:907,t:1527030421893};\\\", \\\"{x:1337,y:911,t:1527030421909};\\\", \\\"{x:1337,y:917,t:1527030421926};\\\", \\\"{x:1337,y:921,t:1527030421943};\\\", \\\"{x:1337,y:925,t:1527030421959};\\\", \\\"{x:1337,y:930,t:1527030421976};\\\", \\\"{x:1337,y:935,t:1527030421993};\\\", \\\"{x:1337,y:938,t:1527030422009};\\\", \\\"{x:1337,y:941,t:1527030422026};\\\", \\\"{x:1337,y:945,t:1527030422043};\\\", \\\"{x:1336,y:948,t:1527030422060};\\\", \\\"{x:1336,y:952,t:1527030422076};\\\", \\\"{x:1336,y:954,t:1527030422093};\\\", \\\"{x:1336,y:957,t:1527030422109};\\\", \\\"{x:1336,y:959,t:1527030422126};\\\", \\\"{x:1336,y:960,t:1527030422143};\\\", \\\"{x:1336,y:963,t:1527030422160};\\\", \\\"{x:1336,y:966,t:1527030422177};\\\", \\\"{x:1336,y:970,t:1527030422194};\\\", \\\"{x:1336,y:972,t:1527030422210};\\\", \\\"{x:1336,y:974,t:1527030422226};\\\", \\\"{x:1336,y:975,t:1527030422242};\\\", \\\"{x:1336,y:976,t:1527030422344};\\\", \\\"{x:1337,y:976,t:1527030422360};\\\", \\\"{x:1339,y:971,t:1527030422376};\\\", \\\"{x:1342,y:958,t:1527030422392};\\\", \\\"{x:1347,y:942,t:1527030422410};\\\", \\\"{x:1348,y:923,t:1527030422425};\\\", \\\"{x:1352,y:905,t:1527030422442};\\\", \\\"{x:1352,y:892,t:1527030422459};\\\", \\\"{x:1353,y:880,t:1527030422475};\\\", \\\"{x:1353,y:867,t:1527030422492};\\\", \\\"{x:1353,y:860,t:1527030422510};\\\", \\\"{x:1353,y:854,t:1527030422525};\\\", \\\"{x:1353,y:848,t:1527030422543};\\\", \\\"{x:1352,y:841,t:1527030422559};\\\", \\\"{x:1351,y:836,t:1527030422575};\\\", \\\"{x:1348,y:831,t:1527030422593};\\\", \\\"{x:1347,y:829,t:1527030422609};\\\", \\\"{x:1344,y:826,t:1527030422625};\\\", \\\"{x:1343,y:825,t:1527030422642};\\\", \\\"{x:1342,y:824,t:1527030422660};\\\", \\\"{x:1339,y:821,t:1527030422677};\\\", \\\"{x:1335,y:817,t:1527030422693};\\\", \\\"{x:1331,y:814,t:1527030422709};\\\", \\\"{x:1328,y:813,t:1527030422726};\\\", \\\"{x:1317,y:808,t:1527030422743};\\\", \\\"{x:1308,y:804,t:1527030422760};\\\", \\\"{x:1290,y:799,t:1527030422777};\\\", \\\"{x:1275,y:794,t:1527030422793};\\\", \\\"{x:1259,y:789,t:1527030422810};\\\", \\\"{x:1242,y:786,t:1527030422826};\\\", \\\"{x:1228,y:786,t:1527030422842};\\\", \\\"{x:1222,y:786,t:1527030422860};\\\", \\\"{x:1218,y:786,t:1527030422877};\\\", \\\"{x:1215,y:786,t:1527030422893};\\\", \\\"{x:1211,y:787,t:1527030422910};\\\", \\\"{x:1207,y:789,t:1527030422926};\\\", \\\"{x:1197,y:790,t:1527030422943};\\\", \\\"{x:1186,y:790,t:1527030422960};\\\", \\\"{x:1155,y:790,t:1527030422977};\\\", \\\"{x:1124,y:789,t:1527030422993};\\\", \\\"{x:1067,y:779,t:1527030423010};\\\", \\\"{x:992,y:757,t:1527030423027};\\\", \\\"{x:903,y:730,t:1527030423042};\\\", \\\"{x:809,y:700,t:1527030423060};\\\", \\\"{x:725,y:676,t:1527030423077};\\\", \\\"{x:664,y:659,t:1527030423093};\\\", \\\"{x:605,y:640,t:1527030423111};\\\", \\\"{x:568,y:626,t:1527030423127};\\\", \\\"{x:548,y:620,t:1527030423143};\\\", \\\"{x:545,y:620,t:1527030423162};\\\", \\\"{x:544,y:619,t:1527030423266};\\\", \\\"{x:551,y:619,t:1527030424906};\\\", \\\"{x:569,y:626,t:1527030424915};\\\", \\\"{x:589,y:631,t:1527030424925};\\\", \\\"{x:642,y:638,t:1527030424948};\\\", \\\"{x:676,y:638,t:1527030424965};\\\", \\\"{x:705,y:638,t:1527030424981};\\\", \\\"{x:726,y:638,t:1527030424997};\\\", \\\"{x:738,y:638,t:1527030425014};\\\", \\\"{x:742,y:637,t:1527030425031};\\\", \\\"{x:743,y:637,t:1527030425047};\\\", \\\"{x:744,y:637,t:1527030425065};\\\", \\\"{x:744,y:636,t:1527030425120};\\\", \\\"{x:741,y:636,t:1527030425131};\\\", \\\"{x:736,y:636,t:1527030425148};\\\", \\\"{x:724,y:636,t:1527030425165};\\\", \\\"{x:709,y:636,t:1527030425182};\\\", \\\"{x:692,y:636,t:1527030425197};\\\", \\\"{x:676,y:636,t:1527030425214};\\\", \\\"{x:663,y:636,t:1527030425230};\\\", \\\"{x:655,y:636,t:1527030425248};\\\", \\\"{x:647,y:636,t:1527030425264};\\\", \\\"{x:643,y:636,t:1527030425281};\\\", \\\"{x:638,y:637,t:1527030425298};\\\", \\\"{x:633,y:637,t:1527030425315};\\\", \\\"{x:627,y:637,t:1527030425332};\\\", \\\"{x:620,y:638,t:1527030425347};\\\", \\\"{x:613,y:638,t:1527030425364};\\\", \\\"{x:598,y:638,t:1527030425382};\\\", \\\"{x:583,y:638,t:1527030425398};\\\", \\\"{x:568,y:638,t:1527030425415};\\\", \\\"{x:550,y:638,t:1527030425432};\\\", \\\"{x:533,y:638,t:1527030425447};\\\", \\\"{x:508,y:638,t:1527030425464};\\\", \\\"{x:496,y:638,t:1527030425483};\\\", \\\"{x:488,y:638,t:1527030425497};\\\", \\\"{x:482,y:639,t:1527030425514};\\\", \\\"{x:475,y:641,t:1527030425532};\\\", \\\"{x:468,y:642,t:1527030425548};\\\", \\\"{x:463,y:642,t:1527030425564};\\\", \\\"{x:456,y:643,t:1527030425581};\\\", \\\"{x:449,y:645,t:1527030425598};\\\", \\\"{x:442,y:645,t:1527030425614};\\\", \\\"{x:435,y:645,t:1527030425632};\\\", \\\"{x:425,y:645,t:1527030425648};\\\", \\\"{x:401,y:643,t:1527030425665};\\\", \\\"{x:387,y:640,t:1527030425682};\\\", \\\"{x:377,y:638,t:1527030425699};\\\", \\\"{x:375,y:634,t:1527030425714};\\\", \\\"{x:373,y:634,t:1527030425732};\\\", \\\"{x:367,y:634,t:1527030426066};\\\", \\\"{x:354,y:624,t:1527030426081};\\\", \\\"{x:333,y:620,t:1527030426099};\\\", \\\"{x:316,y:613,t:1527030426115};\\\", \\\"{x:302,y:611,t:1527030426132};\\\", \\\"{x:290,y:609,t:1527030426149};\\\", \\\"{x:282,y:608,t:1527030426165};\\\", \\\"{x:275,y:607,t:1527030426182};\\\", \\\"{x:270,y:606,t:1527030426199};\\\", \\\"{x:262,y:605,t:1527030426215};\\\", \\\"{x:257,y:605,t:1527030426232};\\\", \\\"{x:246,y:605,t:1527030426249};\\\", \\\"{x:238,y:605,t:1527030426265};\\\", \\\"{x:228,y:605,t:1527030426282};\\\", \\\"{x:217,y:605,t:1527030426299};\\\", \\\"{x:204,y:605,t:1527030426315};\\\", \\\"{x:190,y:602,t:1527030426332};\\\", \\\"{x:180,y:602,t:1527030426349};\\\", \\\"{x:171,y:602,t:1527030426366};\\\", \\\"{x:168,y:602,t:1527030426383};\\\", \\\"{x:166,y:602,t:1527030426399};\\\", \\\"{x:165,y:601,t:1527030426456};\\\", \\\"{x:165,y:599,t:1527030426481};\\\", \\\"{x:164,y:598,t:1527030426504};\\\", \\\"{x:163,y:595,t:1527030426516};\\\", \\\"{x:163,y:593,t:1527030426532};\\\", \\\"{x:162,y:591,t:1527030426549};\\\", \\\"{x:162,y:586,t:1527030426566};\\\", \\\"{x:162,y:584,t:1527030426583};\\\", \\\"{x:162,y:580,t:1527030426599};\\\", \\\"{x:162,y:577,t:1527030426616};\\\", \\\"{x:162,y:574,t:1527030426633};\\\", \\\"{x:161,y:572,t:1527030426649};\\\", \\\"{x:161,y:571,t:1527030426666};\\\", \\\"{x:161,y:569,t:1527030426682};\\\", \\\"{x:161,y:568,t:1527030426704};\\\", \\\"{x:161,y:566,t:1527030426745};\\\", \\\"{x:160,y:566,t:1527030426752};\\\", \\\"{x:160,y:565,t:1527030426766};\\\", \\\"{x:160,y:564,t:1527030427000};\\\", \\\"{x:167,y:566,t:1527030427016};\\\", \\\"{x:229,y:602,t:1527030427033};\\\", \\\"{x:312,y:636,t:1527030427050};\\\", \\\"{x:403,y:676,t:1527030427066};\\\", \\\"{x:496,y:716,t:1527030427083};\\\", \\\"{x:579,y:748,t:1527030427100};\\\", \\\"{x:638,y:771,t:1527030427115};\\\", \\\"{x:666,y:784,t:1527030427133};\\\", \\\"{x:671,y:786,t:1527030427150};\\\", \\\"{x:669,y:786,t:1527030427176};\\\", \\\"{x:668,y:786,t:1527030427185};\\\", \\\"{x:665,y:786,t:1527030427200};\\\", \\\"{x:660,y:786,t:1527030427216};\\\", \\\"{x:657,y:785,t:1527030427232};\\\", \\\"{x:655,y:784,t:1527030427249};\\\", \\\"{x:654,y:782,t:1527030427266};\\\", \\\"{x:650,y:779,t:1527030427283};\\\", \\\"{x:641,y:775,t:1527030427299};\\\", \\\"{x:629,y:770,t:1527030427316};\\\", \\\"{x:617,y:764,t:1527030427333};\\\", \\\"{x:604,y:759,t:1527030427349};\\\", \\\"{x:591,y:752,t:1527030427366};\\\", \\\"{x:578,y:747,t:1527030427382};\\\", \\\"{x:566,y:742,t:1527030427399};\\\", \\\"{x:551,y:737,t:1527030427416};\\\", \\\"{x:531,y:731,t:1527030427433};\\\", \\\"{x:520,y:727,t:1527030427449};\\\", \\\"{x:514,y:726,t:1527030427466};\\\", \\\"{x:512,y:724,t:1527030427482};\\\", \\\"{x:512,y:722,t:1527030427978};\\\", \\\"{x:512,y:721,t:1527030427985};\\\", \\\"{x:512,y:718,t:1527030428000};\\\", \\\"{x:518,y:707,t:1527030428017};\\\", \\\"{x:525,y:699,t:1527030428033};\\\", \\\"{x:529,y:693,t:1527030428050};\\\", \\\"{x:534,y:687,t:1527030428068};\\\", \\\"{x:541,y:681,t:1527030428083};\\\", \\\"{x:550,y:676,t:1527030428100};\\\", \\\"{x:558,y:669,t:1527030428117};\\\", \\\"{x:569,y:663,t:1527030428134};\\\", \\\"{x:581,y:658,t:1527030428150};\\\", \\\"{x:595,y:654,t:1527030428167};\\\", \\\"{x:609,y:652,t:1527030428184};\\\", \\\"{x:618,y:651,t:1527030428200};\\\", \\\"{x:630,y:651,t:1527030428217};\\\", \\\"{x:634,y:651,t:1527030428234};\\\", \\\"{x:638,y:651,t:1527030428250};\\\", \\\"{x:644,y:653,t:1527030428267};\\\", \\\"{x:650,y:655,t:1527030428283};\\\", \\\"{x:657,y:657,t:1527030428300};\\\", \\\"{x:661,y:659,t:1527030428317};\\\", \\\"{x:665,y:661,t:1527030428334};\\\", \\\"{x:666,y:661,t:1527030428350};\\\", \\\"{x:666,y:662,t:1527030428367};\\\", \\\"{x:666,y:663,t:1527030428409};\\\", \\\"{x:667,y:664,t:1527030428417};\\\", \\\"{x:667,y:665,t:1527030428433};\\\", \\\"{x:667,y:667,t:1527030428450};\\\", \\\"{x:667,y:669,t:1527030428467};\\\", \\\"{x:668,y:675,t:1527030428484};\\\", \\\"{x:669,y:680,t:1527030428501};\\\", \\\"{x:670,y:688,t:1527030428517};\\\", \\\"{x:673,y:697,t:1527030428534};\\\", \\\"{x:674,y:703,t:1527030428551};\\\", \\\"{x:675,y:707,t:1527030428568};\\\", \\\"{x:676,y:709,t:1527030428584};\\\", \\\"{x:676,y:710,t:1527030428601};\\\", \\\"{x:677,y:711,t:1527030428617};\\\", \\\"{x:677,y:714,t:1527030428653};\\\", \\\"{x:677,y:716,t:1527030428667};\\\", \\\"{x:677,y:717,t:1527030428684};\\\", \\\"{x:677,y:718,t:1527030428700};\\\", \\\"{x:677,y:719,t:1527030428717};\\\", \\\"{x:677,y:720,t:1527030428733};\\\" ] }, { \\\"rt\\\": 19254, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 8, \\\"time_elapsed\\\": 231831, \\\"internal_node_id\\\": \\\"0.0-5.0-3.0\\\", \\\"subject\\\": \\\"Q0QHK\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"juliet\\\", \\\"condition\\\": \\\"115\\\", \\\"scenario\\\": \\\"acme\\\", \\\"question\\\": \\\"endtime\\\", \\\"q\\\": 4, \\\"clicks\\\": 1, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XFull-YFull\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 1, \\\"answer\\\": [ \\\"U\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"X \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"U \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-02 PM-03 PM-04 PM-04 PM-O -O -03 PM-04 PM-U \\\", \\\"block\\\": \\\"triangular_scaffolded\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:670,y:743,t:1527030428941};\\\", \\\"{x:666,y:752,t:1527030428951};\\\", \\\"{x:658,y:772,t:1527030428968};\\\", \\\"{x:650,y:786,t:1527030428984};\\\", \\\"{x:643,y:796,t:1527030429000};\\\", \\\"{x:641,y:798,t:1527030429026};\\\", \\\"{x:642,y:803,t:1527030431946};\\\", \\\"{x:646,y:812,t:1527030431961};\\\", \\\"{x:648,y:816,t:1527030431970};\\\", \\\"{x:650,y:819,t:1527030431986};\\\", \\\"{x:651,y:821,t:1527030432003};\\\", \\\"{x:651,y:822,t:1527030432020};\\\", \\\"{x:651,y:823,t:1527030432036};\\\", \\\"{x:651,y:824,t:1527030432056};\\\", \\\"{x:651,y:825,t:1527030432070};\\\", \\\"{x:651,y:827,t:1527030432086};\\\", \\\"{x:652,y:828,t:1527030432121};\\\", \\\"{x:652,y:830,t:1527030432137};\\\", \\\"{x:652,y:832,t:1527030432154};\\\", \\\"{x:653,y:833,t:1527030432170};\\\", \\\"{x:655,y:835,t:1527030432187};\\\", \\\"{x:655,y:837,t:1527030432203};\\\", \\\"{x:655,y:838,t:1527030432221};\\\", \\\"{x:657,y:839,t:1527030432237};\\\", \\\"{x:658,y:840,t:1527030432253};\\\", \\\"{x:658,y:842,t:1527030432270};\\\", \\\"{x:660,y:843,t:1527030432287};\\\", \\\"{x:661,y:845,t:1527030432303};\\\", \\\"{x:662,y:845,t:1527030432320};\\\", \\\"{x:663,y:846,t:1527030432337};\\\", \\\"{x:663,y:847,t:1527030432361};\\\", \\\"{x:664,y:847,t:1527030432376};\\\", \\\"{x:665,y:848,t:1527030432393};\\\", \\\"{x:666,y:849,t:1527030432404};\\\", \\\"{x:667,y:850,t:1527030432420};\\\", \\\"{x:668,y:851,t:1527030432441};\\\", \\\"{x:669,y:852,t:1527030432453};\\\", \\\"{x:669,y:853,t:1527030432514};\\\", \\\"{x:669,y:854,t:1527030432521};\\\", \\\"{x:669,y:855,t:1527030432545};\\\", \\\"{x:670,y:855,t:1527030432706};\\\", \\\"{x:671,y:854,t:1527030432729};\\\", \\\"{x:672,y:854,t:1527030432737};\\\", \\\"{x:675,y:852,t:1527030432754};\\\", \\\"{x:680,y:852,t:1527030432771};\\\", \\\"{x:691,y:852,t:1527030432788};\\\", \\\"{x:711,y:852,t:1527030432804};\\\", \\\"{x:745,y:852,t:1527030432821};\\\", \\\"{x:803,y:859,t:1527030432838};\\\", \\\"{x:884,y:870,t:1527030432855};\\\", \\\"{x:981,y:883,t:1527030432871};\\\", \\\"{x:1081,y:899,t:1527030432888};\\\", \\\"{x:1182,y:917,t:1527030432905};\\\", \\\"{x:1277,y:932,t:1527030432920};\\\", \\\"{x:1368,y:945,t:1527030432938};\\\", \\\"{x:1408,y:952,t:1527030432954};\\\", \\\"{x:1436,y:957,t:1527030432971};\\\", \\\"{x:1456,y:963,t:1527030432988};\\\", \\\"{x:1471,y:968,t:1527030433005};\\\", \\\"{x:1478,y:969,t:1527030433020};\\\", \\\"{x:1487,y:972,t:1527030433038};\\\", \\\"{x:1496,y:975,t:1527030433055};\\\", \\\"{x:1506,y:978,t:1527030433072};\\\", \\\"{x:1515,y:979,t:1527030433087};\\\", \\\"{x:1524,y:980,t:1527030433104};\\\", \\\"{x:1530,y:980,t:1527030433121};\\\", \\\"{x:1532,y:980,t:1527030433137};\\\", \\\"{x:1533,y:980,t:1527030433154};\\\", \\\"{x:1535,y:980,t:1527030433172};\\\", \\\"{x:1542,y:980,t:1527030433187};\\\", \\\"{x:1554,y:980,t:1527030433205};\\\", \\\"{x:1571,y:980,t:1527030433222};\\\", \\\"{x:1587,y:980,t:1527030433238};\\\", \\\"{x:1603,y:980,t:1527030433256};\\\", \\\"{x:1616,y:980,t:1527030433271};\\\", \\\"{x:1625,y:980,t:1527030433287};\\\", \\\"{x:1629,y:978,t:1527030433304};\\\", \\\"{x:1632,y:977,t:1527030433321};\\\", \\\"{x:1633,y:977,t:1527030433337};\\\", \\\"{x:1634,y:976,t:1527030433354};\\\", \\\"{x:1635,y:975,t:1527030433372};\\\", \\\"{x:1635,y:974,t:1527030433393};\\\", \\\"{x:1635,y:973,t:1527030433418};\\\", \\\"{x:1635,y:972,t:1527030433425};\\\", \\\"{x:1635,y:971,t:1527030433438};\\\", \\\"{x:1635,y:970,t:1527030433457};\\\", \\\"{x:1635,y:969,t:1527030433473};\\\", \\\"{x:1635,y:968,t:1527030433489};\\\", \\\"{x:1635,y:966,t:1527030433505};\\\", \\\"{x:1635,y:964,t:1527030433522};\\\", \\\"{x:1634,y:964,t:1527030433538};\\\", \\\"{x:1634,y:963,t:1527030433554};\\\", \\\"{x:1632,y:962,t:1527030433572};\\\", \\\"{x:1631,y:962,t:1527030433602};\\\", \\\"{x:1630,y:962,t:1527030433617};\\\", \\\"{x:1629,y:962,t:1527030433626};\\\", \\\"{x:1628,y:962,t:1527030433642};\\\", \\\"{x:1626,y:961,t:1527030433655};\\\", \\\"{x:1624,y:961,t:1527030433671};\\\", \\\"{x:1622,y:961,t:1527030433689};\\\", \\\"{x:1618,y:960,t:1527030433705};\\\", \\\"{x:1617,y:959,t:1527030433906};\\\", \\\"{x:1614,y:961,t:1527030433921};\\\", \\\"{x:1611,y:966,t:1527030433938};\\\", \\\"{x:1610,y:967,t:1527030433955};\\\", \\\"{x:1609,y:970,t:1527030433972};\\\", \\\"{x:1608,y:970,t:1527030433988};\\\", \\\"{x:1608,y:971,t:1527030435442};\\\", \\\"{x:1607,y:971,t:1527030435465};\\\", \\\"{x:1607,y:970,t:1527030435481};\\\", \\\"{x:1607,y:969,t:1527030435513};\\\", \\\"{x:1606,y:967,t:1527030435674};\\\", \\\"{x:1606,y:966,t:1527030435737};\\\", \\\"{x:1605,y:965,t:1527030435769};\\\", \\\"{x:1605,y:964,t:1527030435818};\\\", \\\"{x:1604,y:962,t:1527030435866};\\\", \\\"{x:1604,y:961,t:1527030435905};\\\", \\\"{x:1604,y:960,t:1527030435937};\\\", \\\"{x:1604,y:959,t:1527030435946};\\\", \\\"{x:1604,y:958,t:1527030435969};\\\", \\\"{x:1603,y:956,t:1527030435985};\\\", \\\"{x:1603,y:955,t:1527030435993};\\\", \\\"{x:1603,y:952,t:1527030436006};\\\", \\\"{x:1602,y:946,t:1527030436024};\\\", \\\"{x:1601,y:935,t:1527030436040};\\\", \\\"{x:1599,y:925,t:1527030436057};\\\", \\\"{x:1598,y:909,t:1527030436073};\\\", \\\"{x:1597,y:894,t:1527030436090};\\\", \\\"{x:1596,y:878,t:1527030436107};\\\", \\\"{x:1596,y:863,t:1527030436124};\\\", \\\"{x:1595,y:842,t:1527030436140};\\\", \\\"{x:1591,y:790,t:1527030436157};\\\", \\\"{x:1585,y:752,t:1527030436174};\\\", \\\"{x:1584,y:736,t:1527030436190};\\\", \\\"{x:1584,y:721,t:1527030436207};\\\", \\\"{x:1584,y:713,t:1527030436224};\\\", \\\"{x:1584,y:710,t:1527030436240};\\\", \\\"{x:1584,y:707,t:1527030436257};\\\", \\\"{x:1584,y:704,t:1527030436273};\\\", \\\"{x:1584,y:703,t:1527030436290};\\\", \\\"{x:1584,y:705,t:1527030436410};\\\", \\\"{x:1584,y:711,t:1527030436424};\\\", \\\"{x:1584,y:729,t:1527030436441};\\\", \\\"{x:1586,y:768,t:1527030436457};\\\", \\\"{x:1588,y:802,t:1527030436474};\\\", \\\"{x:1591,y:827,t:1527030436491};\\\", \\\"{x:1593,y:846,t:1527030436507};\\\", \\\"{x:1593,y:857,t:1527030436523};\\\", \\\"{x:1593,y:863,t:1527030436540};\\\", \\\"{x:1593,y:867,t:1527030436556};\\\", \\\"{x:1593,y:870,t:1527030436573};\\\", \\\"{x:1593,y:874,t:1527030436590};\\\", \\\"{x:1593,y:878,t:1527030436606};\\\", \\\"{x:1593,y:882,t:1527030436623};\\\", \\\"{x:1593,y:890,t:1527030436640};\\\", \\\"{x:1593,y:896,t:1527030436657};\\\", \\\"{x:1593,y:900,t:1527030436674};\\\", \\\"{x:1593,y:903,t:1527030436690};\\\", \\\"{x:1594,y:908,t:1527030436706};\\\", \\\"{x:1595,y:911,t:1527030436724};\\\", \\\"{x:1596,y:919,t:1527030436740};\\\", \\\"{x:1598,y:929,t:1527030436756};\\\", \\\"{x:1600,y:939,t:1527030436774};\\\", \\\"{x:1601,y:951,t:1527030436791};\\\", \\\"{x:1605,y:960,t:1527030436807};\\\", \\\"{x:1608,y:965,t:1527030436824};\\\", \\\"{x:1610,y:967,t:1527030436841};\\\", \\\"{x:1610,y:966,t:1527030437906};\\\", \\\"{x:1610,y:965,t:1527030438002};\\\", \\\"{x:1610,y:964,t:1527030438082};\\\", \\\"{x:1610,y:962,t:1527030438098};\\\", \\\"{x:1610,y:959,t:1527030438114};\\\", \\\"{x:1608,y:957,t:1527030438125};\\\", \\\"{x:1603,y:948,t:1527030438142};\\\", \\\"{x:1584,y:928,t:1527030438158};\\\", \\\"{x:1546,y:890,t:1527030438175};\\\", \\\"{x:1494,y:845,t:1527030438192};\\\", \\\"{x:1443,y:807,t:1527030438208};\\\", \\\"{x:1364,y:749,t:1527030438225};\\\", \\\"{x:1324,y:718,t:1527030438241};\\\", \\\"{x:1289,y:677,t:1527030438258};\\\", \\\"{x:1270,y:653,t:1527030438275};\\\", \\\"{x:1264,y:644,t:1527030438292};\\\", \\\"{x:1263,y:642,t:1527030438308};\\\", \\\"{x:1262,y:641,t:1527030438325};\\\", \\\"{x:1262,y:640,t:1527030438342};\\\", \\\"{x:1262,y:639,t:1527030438442};\\\", \\\"{x:1262,y:638,t:1527030438459};\\\", \\\"{x:1265,y:638,t:1527030438475};\\\", \\\"{x:1269,y:638,t:1527030438492};\\\", \\\"{x:1279,y:635,t:1527030438509};\\\", \\\"{x:1285,y:635,t:1527030438525};\\\", \\\"{x:1291,y:635,t:1527030438542};\\\", \\\"{x:1297,y:635,t:1527030438559};\\\", \\\"{x:1302,y:635,t:1527030438575};\\\", \\\"{x:1305,y:635,t:1527030438592};\\\", \\\"{x:1309,y:635,t:1527030438609};\\\", \\\"{x:1315,y:635,t:1527030438628};\\\", \\\"{x:1318,y:634,t:1527030438641};\\\", \\\"{x:1319,y:634,t:1527030438658};\\\", \\\"{x:1320,y:634,t:1527030438675};\\\", \\\"{x:1321,y:634,t:1527030438897};\\\", \\\"{x:1322,y:633,t:1527030438912};\\\", \\\"{x:1321,y:633,t:1527030440074};\\\", \\\"{x:1320,y:632,t:1527030440138};\\\", \\\"{x:1320,y:631,t:1527030440218};\\\", \\\"{x:1319,y:629,t:1527030440249};\\\", \\\"{x:1318,y:629,t:1527030442210};\\\", \\\"{x:1321,y:632,t:1527030442226};\\\", \\\"{x:1327,y:638,t:1527030442233};\\\", \\\"{x:1333,y:644,t:1527030442245};\\\", \\\"{x:1355,y:659,t:1527030442262};\\\", \\\"{x:1375,y:674,t:1527030442278};\\\", \\\"{x:1407,y:697,t:1527030442296};\\\", \\\"{x:1428,y:715,t:1527030442311};\\\", \\\"{x:1448,y:731,t:1527030442328};\\\", \\\"{x:1471,y:750,t:1527030442345};\\\", \\\"{x:1481,y:758,t:1527030442361};\\\", \\\"{x:1489,y:767,t:1527030442378};\\\", \\\"{x:1495,y:775,t:1527030442395};\\\", \\\"{x:1502,y:783,t:1527030442411};\\\", \\\"{x:1503,y:785,t:1527030442428};\\\", \\\"{x:1503,y:786,t:1527030442445};\\\", \\\"{x:1503,y:787,t:1527030442482};\\\", \\\"{x:1503,y:788,t:1527030442495};\\\", \\\"{x:1503,y:791,t:1527030442512};\\\", \\\"{x:1504,y:794,t:1527030442528};\\\", \\\"{x:1505,y:798,t:1527030442545};\\\", \\\"{x:1505,y:801,t:1527030442562};\\\", \\\"{x:1505,y:806,t:1527030442578};\\\", \\\"{x:1505,y:813,t:1527030442595};\\\", \\\"{x:1505,y:822,t:1527030442612};\\\", \\\"{x:1505,y:829,t:1527030442628};\\\", \\\"{x:1505,y:834,t:1527030442645};\\\", \\\"{x:1505,y:835,t:1527030442662};\\\", \\\"{x:1505,y:836,t:1527030442678};\\\", \\\"{x:1505,y:837,t:1527030442694};\\\", \\\"{x:1504,y:838,t:1527030442720};\\\", \\\"{x:1503,y:838,t:1527030442729};\\\", \\\"{x:1502,y:839,t:1527030442744};\\\", \\\"{x:1502,y:840,t:1527030442761};\\\", \\\"{x:1502,y:842,t:1527030442778};\\\", \\\"{x:1502,y:845,t:1527030442795};\\\", \\\"{x:1502,y:852,t:1527030442811};\\\", \\\"{x:1503,y:864,t:1527030442828};\\\", \\\"{x:1509,y:879,t:1527030442845};\\\", \\\"{x:1515,y:890,t:1527030442862};\\\", \\\"{x:1520,y:898,t:1527030442878};\\\", \\\"{x:1524,y:905,t:1527030442895};\\\", \\\"{x:1527,y:911,t:1527030442911};\\\", \\\"{x:1532,y:919,t:1527030442928};\\\", \\\"{x:1542,y:934,t:1527030442945};\\\", \\\"{x:1546,y:940,t:1527030442962};\\\", \\\"{x:1549,y:946,t:1527030442978};\\\", \\\"{x:1551,y:948,t:1527030442994};\\\", \\\"{x:1554,y:953,t:1527030443012};\\\", \\\"{x:1556,y:958,t:1527030443028};\\\", \\\"{x:1557,y:960,t:1527030443045};\\\", \\\"{x:1558,y:961,t:1527030443062};\\\", \\\"{x:1558,y:962,t:1527030443079};\\\", \\\"{x:1559,y:964,t:1527030443097};\\\", \\\"{x:1559,y:965,t:1527030443112};\\\", \\\"{x:1560,y:967,t:1527030443129};\\\", \\\"{x:1561,y:968,t:1527030443145};\\\", \\\"{x:1562,y:969,t:1527030443162};\\\", \\\"{x:1565,y:969,t:1527030443178};\\\", \\\"{x:1567,y:969,t:1527030443194};\\\", \\\"{x:1572,y:971,t:1527030443213};\\\", \\\"{x:1581,y:972,t:1527030443229};\\\", \\\"{x:1584,y:972,t:1527030443245};\\\", \\\"{x:1588,y:972,t:1527030443262};\\\", \\\"{x:1590,y:972,t:1527030443279};\\\", \\\"{x:1591,y:972,t:1527030443295};\\\", \\\"{x:1593,y:972,t:1527030443312};\\\", \\\"{x:1594,y:972,t:1527030443346};\\\", \\\"{x:1597,y:972,t:1527030443362};\\\", \\\"{x:1602,y:972,t:1527030443380};\\\", \\\"{x:1604,y:972,t:1527030443395};\\\", \\\"{x:1605,y:972,t:1527030443412};\\\", \\\"{x:1606,y:972,t:1527030443434};\\\", \\\"{x:1607,y:972,t:1527030443449};\\\", \\\"{x:1608,y:972,t:1527030443465};\\\", \\\"{x:1609,y:971,t:1527030443481};\\\", \\\"{x:1610,y:971,t:1527030443497};\\\", \\\"{x:1611,y:970,t:1527030443521};\\\", \\\"{x:1612,y:969,t:1527030443537};\\\", \\\"{x:1613,y:968,t:1527030443553};\\\", \\\"{x:1613,y:967,t:1527030443570};\\\", \\\"{x:1614,y:967,t:1527030443579};\\\", \\\"{x:1614,y:966,t:1527030443596};\\\", \\\"{x:1614,y:965,t:1527030443850};\\\", \\\"{x:1614,y:964,t:1527030443865};\\\", \\\"{x:1614,y:963,t:1527030443880};\\\", \\\"{x:1614,y:961,t:1527030443896};\\\", \\\"{x:1613,y:961,t:1527030443912};\\\", \\\"{x:1601,y:954,t:1527030443928};\\\", \\\"{x:1585,y:945,t:1527030443946};\\\", \\\"{x:1557,y:929,t:1527030443962};\\\", \\\"{x:1513,y:902,t:1527030443979};\\\", \\\"{x:1462,y:876,t:1527030443996};\\\", \\\"{x:1437,y:864,t:1527030444011};\\\", \\\"{x:1425,y:857,t:1527030444028};\\\", \\\"{x:1424,y:855,t:1527030444046};\\\", \\\"{x:1424,y:853,t:1527030444063};\\\", \\\"{x:1425,y:851,t:1527030444079};\\\", \\\"{x:1427,y:849,t:1527030444096};\\\", \\\"{x:1430,y:845,t:1527030444113};\\\", \\\"{x:1430,y:844,t:1527030444129};\\\", \\\"{x:1433,y:842,t:1527030444146};\\\", \\\"{x:1434,y:841,t:1527030444163};\\\", \\\"{x:1436,y:839,t:1527030444179};\\\", \\\"{x:1439,y:838,t:1527030444196};\\\", \\\"{x:1446,y:836,t:1527030444212};\\\", \\\"{x:1455,y:834,t:1527030444229};\\\", \\\"{x:1461,y:833,t:1527030444246};\\\", \\\"{x:1464,y:832,t:1527030444263};\\\", \\\"{x:1467,y:831,t:1527030444278};\\\", \\\"{x:1468,y:830,t:1527030444305};\\\", \\\"{x:1469,y:830,t:1527030444522};\\\", \\\"{x:1470,y:830,t:1527030444538};\\\", \\\"{x:1471,y:830,t:1527030444546};\\\", \\\"{x:1473,y:831,t:1527030444563};\\\", \\\"{x:1474,y:831,t:1527030444581};\\\", \\\"{x:1475,y:831,t:1527030444596};\\\", \\\"{x:1476,y:831,t:1527030445034};\\\", \\\"{x:1477,y:831,t:1527030445081};\\\", \\\"{x:1478,y:831,t:1527030445202};\\\", \\\"{x:1479,y:831,t:1527030445213};\\\", \\\"{x:1480,y:830,t:1527030445266};\\\", \\\"{x:1482,y:830,t:1527030445281};\\\", \\\"{x:1484,y:830,t:1527030445297};\\\", \\\"{x:1489,y:830,t:1527030445314};\\\", \\\"{x:1492,y:830,t:1527030445330};\\\", \\\"{x:1497,y:830,t:1527030445348};\\\", \\\"{x:1501,y:830,t:1527030445363};\\\", \\\"{x:1506,y:830,t:1527030445380};\\\", \\\"{x:1511,y:830,t:1527030445397};\\\", \\\"{x:1515,y:830,t:1527030445413};\\\", \\\"{x:1521,y:829,t:1527030445431};\\\", \\\"{x:1527,y:827,t:1527030445448};\\\", \\\"{x:1533,y:826,t:1527030445463};\\\", \\\"{x:1540,y:826,t:1527030445481};\\\", \\\"{x:1549,y:825,t:1527030445497};\\\", \\\"{x:1551,y:823,t:1527030445515};\\\", \\\"{x:1552,y:823,t:1527030445537};\\\", \\\"{x:1553,y:823,t:1527030445658};\\\", \\\"{x:1554,y:823,t:1527030445680};\\\", \\\"{x:1555,y:823,t:1527030445696};\\\", \\\"{x:1556,y:823,t:1527030445714};\\\", \\\"{x:1559,y:823,t:1527030445730};\\\", \\\"{x:1561,y:823,t:1527030445746};\\\", \\\"{x:1565,y:823,t:1527030445764};\\\", \\\"{x:1569,y:823,t:1527030445779};\\\", \\\"{x:1573,y:824,t:1527030445796};\\\", \\\"{x:1578,y:827,t:1527030445814};\\\", \\\"{x:1586,y:828,t:1527030445830};\\\", \\\"{x:1593,y:828,t:1527030445847};\\\", \\\"{x:1602,y:832,t:1527030445864};\\\", \\\"{x:1611,y:833,t:1527030445880};\\\", \\\"{x:1616,y:833,t:1527030445897};\\\", \\\"{x:1618,y:833,t:1527030445914};\\\", \\\"{x:1618,y:834,t:1527030445930};\\\", \\\"{x:1619,y:834,t:1527030446034};\\\", \\\"{x:1620,y:834,t:1527030446073};\\\", \\\"{x:1621,y:834,t:1527030446218};\\\", \\\"{x:1622,y:834,t:1527030446241};\\\", \\\"{x:1620,y:834,t:1527030446458};\\\", \\\"{x:1615,y:835,t:1527030446466};\\\", \\\"{x:1594,y:837,t:1527030446481};\\\", \\\"{x:1559,y:841,t:1527030446498};\\\", \\\"{x:1498,y:841,t:1527030446514};\\\", \\\"{x:1420,y:841,t:1527030446532};\\\", \\\"{x:1337,y:841,t:1527030446548};\\\", \\\"{x:1248,y:841,t:1527030446563};\\\", \\\"{x:1165,y:841,t:1527030446581};\\\", \\\"{x:1095,y:841,t:1527030446598};\\\", \\\"{x:1026,y:841,t:1527030446614};\\\", \\\"{x:970,y:841,t:1527030446631};\\\", \\\"{x:925,y:841,t:1527030446648};\\\", \\\"{x:886,y:841,t:1527030446664};\\\", \\\"{x:827,y:841,t:1527030446680};\\\", \\\"{x:785,y:838,t:1527030446698};\\\", \\\"{x:759,y:833,t:1527030446714};\\\", \\\"{x:729,y:828,t:1527030446731};\\\", \\\"{x:707,y:826,t:1527030446748};\\\", \\\"{x:689,y:822,t:1527030446763};\\\", \\\"{x:669,y:814,t:1527030446781};\\\", \\\"{x:657,y:806,t:1527030446798};\\\", \\\"{x:647,y:799,t:1527030446813};\\\", \\\"{x:641,y:792,t:1527030446831};\\\", \\\"{x:637,y:783,t:1527030446848};\\\", \\\"{x:633,y:770,t:1527030446864};\\\", \\\"{x:632,y:754,t:1527030446880};\\\", \\\"{x:636,y:737,t:1527030446898};\\\", \\\"{x:648,y:698,t:1527030446914};\\\", \\\"{x:659,y:651,t:1527030446932};\\\", \\\"{x:669,y:622,t:1527030446949};\\\", \\\"{x:676,y:606,t:1527030446965};\\\", \\\"{x:684,y:596,t:1527030446980};\\\", \\\"{x:690,y:586,t:1527030446992};\\\", \\\"{x:694,y:577,t:1527030447009};\\\", \\\"{x:697,y:565,t:1527030447026};\\\", \\\"{x:697,y:557,t:1527030447043};\\\", \\\"{x:697,y:552,t:1527030447065};\\\", \\\"{x:697,y:551,t:1527030447083};\\\", \\\"{x:695,y:551,t:1527030447104};\\\", \\\"{x:694,y:551,t:1527030447115};\\\", \\\"{x:687,y:555,t:1527030447133};\\\", \\\"{x:681,y:560,t:1527030447149};\\\", \\\"{x:676,y:570,t:1527030447165};\\\", \\\"{x:669,y:584,t:1527030447184};\\\", \\\"{x:664,y:590,t:1527030447199};\\\", \\\"{x:661,y:594,t:1527030447216};\\\", \\\"{x:656,y:597,t:1527030447232};\\\", \\\"{x:653,y:600,t:1527030447249};\\\", \\\"{x:651,y:600,t:1527030447266};\\\", \\\"{x:649,y:601,t:1527030447283};\\\", \\\"{x:646,y:601,t:1527030447299};\\\", \\\"{x:644,y:601,t:1527030447321};\\\", \\\"{x:643,y:602,t:1527030447337};\\\", \\\"{x:642,y:602,t:1527030447349};\\\", \\\"{x:641,y:602,t:1527030447366};\\\", \\\"{x:640,y:603,t:1527030447382};\\\", \\\"{x:637,y:604,t:1527030447400};\\\", \\\"{x:634,y:604,t:1527030447415};\\\", \\\"{x:632,y:607,t:1527030447688};\\\", \\\"{x:627,y:615,t:1527030447701};\\\", \\\"{x:618,y:630,t:1527030447716};\\\", \\\"{x:610,y:644,t:1527030447733};\\\", \\\"{x:601,y:661,t:1527030447750};\\\", \\\"{x:592,y:675,t:1527030447766};\\\", \\\"{x:581,y:697,t:1527030447782};\\\", \\\"{x:574,y:708,t:1527030447799};\\\", \\\"{x:568,y:717,t:1527030447816};\\\", \\\"{x:558,y:728,t:1527030447833};\\\", \\\"{x:554,y:731,t:1527030447849};\\\", \\\"{x:549,y:732,t:1527030447866};\\\", \\\"{x:546,y:732,t:1527030447883};\\\", \\\"{x:545,y:732,t:1527030447900};\\\", \\\"{x:544,y:732,t:1527030447916};\\\", \\\"{x:543,y:732,t:1527030447932};\\\", \\\"{x:542,y:732,t:1527030447952};\\\", \\\"{x:542,y:731,t:1527030447966};\\\", \\\"{x:540,y:730,t:1527030447983};\\\", \\\"{x:540,y:728,t:1527030448000};\\\", \\\"{x:539,y:727,t:1527030448017};\\\", \\\"{x:537,y:726,t:1527030448033};\\\", \\\"{x:537,y:725,t:1527030448050};\\\", \\\"{x:537,y:724,t:1527030449074};\\\", \\\"{x:537,y:723,t:1527030449146};\\\", \\\"{x:538,y:723,t:1527030449228};\\\", \\\"{x:539,y:722,t:1527030449234};\\\", \\\"{x:540,y:721,t:1527030449296};\\\" ] }, { \\\"rt\\\": 85875, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 9, \\\"time_elapsed\\\": 318973, \\\"internal_node_id\\\": \\\"0.0-5.0-4.0\\\", \\\"subject\\\": \\\"Q0QHK\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"juliet\\\", \\\"condition\\\": \\\"115\\\", \\\"scenario\\\": \\\"acme\\\", \\\"question\\\": \\\"midpoint\\\", \\\"q\\\": 5, \\\"clicks\\\": 1, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XFull-YFull\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 1, \\\"answer\\\": [ \\\"U\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"X \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"U \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-03 PM-H -K -U \\\", \\\"block\\\": \\\"triangular_scaffolded\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:542,y:721,t:1527030449460};\\\", \\\"{x:544,y:718,t:1527030451617};\\\", \\\"{x:546,y:718,t:1527030451624};\\\", \\\"{x:546,y:717,t:1527030451648};\\\", \\\"{x:547,y:717,t:1527030451657};\\\", \\\"{x:548,y:716,t:1527030451986};\\\", \\\"{x:549,y:715,t:1527030452003};\\\", \\\"{x:550,y:715,t:1527030453777};\\\", \\\"{x:551,y:714,t:1527030453803};\\\", \\\"{x:552,y:714,t:1527030453937};\\\", \\\"{x:553,y:713,t:1527030454081};\\\", \\\"{x:553,y:712,t:1527030454137};\\\", \\\"{x:554,y:712,t:1527030454155};\\\", \\\"{x:555,y:712,t:1527030454172};\\\", \\\"{x:556,y:711,t:1527030454193};\\\", \\\"{x:556,y:710,t:1527030454242};\\\", \\\"{x:558,y:709,t:1527030464291};\\\", \\\"{x:559,y:710,t:1527030464693};\\\", \\\"{x:567,y:711,t:1527030464700};\\\", \\\"{x:574,y:712,t:1527030464714};\\\", \\\"{x:611,y:721,t:1527030464732};\\\", \\\"{x:617,y:722,t:1527030464748};\\\", \\\"{x:635,y:725,t:1527030464764};\\\", \\\"{x:649,y:727,t:1527030464781};\\\", \\\"{x:655,y:727,t:1527030464797};\\\", \\\"{x:661,y:727,t:1527030464814};\\\", \\\"{x:666,y:727,t:1527030464832};\\\", \\\"{x:672,y:727,t:1527030464847};\\\", \\\"{x:683,y:727,t:1527030464864};\\\", \\\"{x:698,y:729,t:1527030464881};\\\", \\\"{x:722,y:733,t:1527030464898};\\\", \\\"{x:751,y:736,t:1527030464915};\\\", \\\"{x:790,y:743,t:1527030464931};\\\", \\\"{x:829,y:749,t:1527030464948};\\\", \\\"{x:892,y:757,t:1527030464964};\\\", \\\"{x:937,y:763,t:1527030464981};\\\", \\\"{x:977,y:770,t:1527030464998};\\\", \\\"{x:1013,y:772,t:1527030465015};\\\", \\\"{x:1042,y:778,t:1527030465032};\\\", \\\"{x:1077,y:783,t:1527030465049};\\\", \\\"{x:1107,y:788,t:1527030465064};\\\", \\\"{x:1139,y:791,t:1527030465081};\\\", \\\"{x:1169,y:796,t:1527030465099};\\\", \\\"{x:1200,y:801,t:1527030465115};\\\", \\\"{x:1229,y:803,t:1527030465132};\\\", \\\"{x:1259,y:803,t:1527030465148};\\\", \\\"{x:1306,y:803,t:1527030465165};\\\", \\\"{x:1334,y:803,t:1527030465182};\\\", \\\"{x:1357,y:803,t:1527030465199};\\\", \\\"{x:1374,y:801,t:1527030465215};\\\", \\\"{x:1383,y:800,t:1527030465232};\\\", \\\"{x:1387,y:800,t:1527030465249};\\\", \\\"{x:1388,y:800,t:1527030465293};\\\", \\\"{x:1391,y:799,t:1527030466005};\\\", \\\"{x:1400,y:797,t:1527030466015};\\\", \\\"{x:1413,y:789,t:1527030466032};\\\", \\\"{x:1420,y:785,t:1527030466048};\\\", \\\"{x:1427,y:781,t:1527030466065};\\\", \\\"{x:1433,y:776,t:1527030466082};\\\", \\\"{x:1441,y:771,t:1527030466099};\\\", \\\"{x:1450,y:761,t:1527030466116};\\\", \\\"{x:1458,y:749,t:1527030466132};\\\", \\\"{x:1472,y:720,t:1527030466148};\\\", \\\"{x:1483,y:697,t:1527030466166};\\\", \\\"{x:1488,y:675,t:1527030466183};\\\", \\\"{x:1492,y:649,t:1527030466199};\\\", \\\"{x:1494,y:630,t:1527030466215};\\\", \\\"{x:1489,y:609,t:1527030466233};\\\", \\\"{x:1482,y:586,t:1527030466248};\\\", \\\"{x:1475,y:563,t:1527030466266};\\\", \\\"{x:1458,y:524,t:1527030466283};\\\", \\\"{x:1447,y:507,t:1527030466298};\\\", \\\"{x:1438,y:496,t:1527030466316};\\\", \\\"{x:1428,y:487,t:1527030466333};\\\", \\\"{x:1423,y:485,t:1527030466348};\\\", \\\"{x:1417,y:483,t:1527030466365};\\\", \\\"{x:1413,y:483,t:1527030466382};\\\", \\\"{x:1408,y:483,t:1527030466399};\\\", \\\"{x:1401,y:483,t:1527030466415};\\\", \\\"{x:1394,y:483,t:1527030466434};\\\", \\\"{x:1386,y:487,t:1527030466449};\\\", \\\"{x:1375,y:494,t:1527030466466};\\\", \\\"{x:1361,y:502,t:1527030466482};\\\", \\\"{x:1350,y:507,t:1527030466498};\\\", \\\"{x:1341,y:511,t:1527030466515};\\\", \\\"{x:1334,y:513,t:1527030466532};\\\", \\\"{x:1332,y:514,t:1527030466549};\\\", \\\"{x:1330,y:514,t:1527030466565};\\\", \\\"{x:1329,y:514,t:1527030466582};\\\", \\\"{x:1327,y:514,t:1527030466598};\\\", \\\"{x:1325,y:514,t:1527030466614};\\\", \\\"{x:1323,y:514,t:1527030466632};\\\", \\\"{x:1322,y:514,t:1527030466648};\\\", \\\"{x:1321,y:514,t:1527030466665};\\\", \\\"{x:1320,y:514,t:1527030466683};\\\", \\\"{x:1319,y:514,t:1527030466723};\\\", \\\"{x:1318,y:514,t:1527030466732};\\\", \\\"{x:1317,y:512,t:1527030466748};\\\", \\\"{x:1314,y:509,t:1527030466765};\\\", \\\"{x:1312,y:507,t:1527030466782};\\\", \\\"{x:1310,y:506,t:1527030466799};\\\", \\\"{x:1310,y:505,t:1527030466981};\\\", \\\"{x:1310,y:503,t:1527030467037};\\\", \\\"{x:1311,y:503,t:1527030474533};\\\", \\\"{x:1317,y:502,t:1527030474540};\\\", \\\"{x:1326,y:501,t:1527030474554};\\\", \\\"{x:1346,y:501,t:1527030474571};\\\", \\\"{x:1366,y:501,t:1527030474587};\\\", \\\"{x:1392,y:501,t:1527030474604};\\\", \\\"{x:1402,y:500,t:1527030474620};\\\", \\\"{x:1406,y:499,t:1527030474636};\\\", \\\"{x:1407,y:498,t:1527030474654};\\\", \\\"{x:1408,y:498,t:1527030474877};\\\", \\\"{x:1409,y:498,t:1527030474892};\\\", \\\"{x:1410,y:498,t:1527030474904};\\\", \\\"{x:1412,y:498,t:1527030474921};\\\", \\\"{x:1417,y:495,t:1527030474938};\\\", \\\"{x:1422,y:494,t:1527030474954};\\\", \\\"{x:1431,y:493,t:1527030474971};\\\", \\\"{x:1445,y:491,t:1527030474988};\\\", \\\"{x:1453,y:491,t:1527030475005};\\\", \\\"{x:1459,y:491,t:1527030475021};\\\", \\\"{x:1461,y:491,t:1527030475038};\\\", \\\"{x:1463,y:491,t:1527030475053};\\\", \\\"{x:1464,y:491,t:1527030475071};\\\", \\\"{x:1465,y:491,t:1527030475237};\\\", \\\"{x:1470,y:491,t:1527030475254};\\\", \\\"{x:1478,y:491,t:1527030475271};\\\", \\\"{x:1489,y:492,t:1527030475288};\\\", \\\"{x:1502,y:495,t:1527030475304};\\\", \\\"{x:1509,y:495,t:1527030475321};\\\", \\\"{x:1515,y:496,t:1527030475338};\\\", \\\"{x:1518,y:496,t:1527030475355};\\\", \\\"{x:1519,y:496,t:1527030475371};\\\", \\\"{x:1520,y:496,t:1527030475388};\\\", \\\"{x:1520,y:497,t:1527030482006};\\\", \\\"{x:1519,y:498,t:1527030482013};\\\", \\\"{x:1518,y:499,t:1527030482025};\\\", \\\"{x:1514,y:500,t:1527030482042};\\\", \\\"{x:1511,y:502,t:1527030482057};\\\", \\\"{x:1508,y:503,t:1527030482075};\\\", \\\"{x:1505,y:504,t:1527030482091};\\\", \\\"{x:1501,y:506,t:1527030482107};\\\", \\\"{x:1497,y:507,t:1527030482125};\\\", \\\"{x:1490,y:509,t:1527030482141};\\\", \\\"{x:1484,y:510,t:1527030482158};\\\", \\\"{x:1473,y:511,t:1527030482174};\\\", \\\"{x:1462,y:511,t:1527030482192};\\\", \\\"{x:1447,y:511,t:1527030482208};\\\", \\\"{x:1430,y:511,t:1527030482225};\\\", \\\"{x:1417,y:511,t:1527030482242};\\\", \\\"{x:1402,y:509,t:1527030482258};\\\", \\\"{x:1391,y:508,t:1527030482275};\\\", \\\"{x:1375,y:504,t:1527030482292};\\\", \\\"{x:1370,y:503,t:1527030482309};\\\", \\\"{x:1366,y:503,t:1527030482325};\\\", \\\"{x:1366,y:502,t:1527030482341};\\\", \\\"{x:1366,y:501,t:1527030482484};\\\", \\\"{x:1367,y:501,t:1527030482492};\\\", \\\"{x:1372,y:501,t:1527030482508};\\\", \\\"{x:1378,y:501,t:1527030482524};\\\", \\\"{x:1385,y:501,t:1527030482541};\\\", \\\"{x:1396,y:501,t:1527030482559};\\\", \\\"{x:1409,y:501,t:1527030482574};\\\", \\\"{x:1420,y:501,t:1527030482591};\\\", \\\"{x:1427,y:501,t:1527030482609};\\\", \\\"{x:1431,y:501,t:1527030482625};\\\", \\\"{x:1432,y:501,t:1527030482641};\\\", \\\"{x:1433,y:501,t:1527030482659};\\\", \\\"{x:1434,y:501,t:1527030482675};\\\", \\\"{x:1434,y:500,t:1527030482692};\\\", \\\"{x:1435,y:500,t:1527030482716};\\\", \\\"{x:1436,y:500,t:1527030482740};\\\", \\\"{x:1437,y:500,t:1527030482820};\\\", \\\"{x:1438,y:498,t:1527030482845};\\\", \\\"{x:1439,y:498,t:1527030482885};\\\", \\\"{x:1440,y:498,t:1527030482892};\\\", \\\"{x:1439,y:498,t:1527030483053};\\\", \\\"{x:1438,y:499,t:1527030483060};\\\", \\\"{x:1435,y:499,t:1527030483076};\\\", \\\"{x:1433,y:501,t:1527030483092};\\\", \\\"{x:1431,y:502,t:1527030483109};\\\", \\\"{x:1428,y:502,t:1527030483126};\\\", \\\"{x:1423,y:502,t:1527030483142};\\\", \\\"{x:1417,y:502,t:1527030483159};\\\", \\\"{x:1407,y:502,t:1527030483176};\\\", \\\"{x:1396,y:502,t:1527030483192};\\\", \\\"{x:1388,y:502,t:1527030483209};\\\", \\\"{x:1380,y:502,t:1527030483226};\\\", \\\"{x:1375,y:502,t:1527030483242};\\\", \\\"{x:1372,y:502,t:1527030483259};\\\", \\\"{x:1369,y:502,t:1527030484036};\\\", \\\"{x:1368,y:502,t:1527030484044};\\\", \\\"{x:1363,y:503,t:1527030484060};\\\", \\\"{x:1353,y:506,t:1527030484076};\\\", \\\"{x:1343,y:510,t:1527030484093};\\\", \\\"{x:1334,y:512,t:1527030484110};\\\", \\\"{x:1330,y:513,t:1527030484126};\\\", \\\"{x:1324,y:513,t:1527030484143};\\\", \\\"{x:1319,y:514,t:1527030484160};\\\", \\\"{x:1313,y:515,t:1527030484176};\\\", \\\"{x:1306,y:515,t:1527030484193};\\\", \\\"{x:1303,y:515,t:1527030484210};\\\", \\\"{x:1300,y:515,t:1527030484226};\\\", \\\"{x:1299,y:515,t:1527030484243};\\\", \\\"{x:1298,y:515,t:1527030484284};\\\", \\\"{x:1298,y:514,t:1527030484307};\\\", \\\"{x:1298,y:512,t:1527030484315};\\\", \\\"{x:1298,y:511,t:1527030484326};\\\", \\\"{x:1298,y:508,t:1527030484343};\\\", \\\"{x:1300,y:502,t:1527030484360};\\\", \\\"{x:1304,y:497,t:1527030484375};\\\", \\\"{x:1305,y:496,t:1527030484393};\\\", \\\"{x:1305,y:495,t:1527030484410};\\\", \\\"{x:1305,y:494,t:1527030484426};\\\", \\\"{x:1306,y:493,t:1527030484443};\\\", \\\"{x:1307,y:492,t:1527030484484};\\\", \\\"{x:1308,y:492,t:1527030484596};\\\", \\\"{x:1308,y:494,t:1527030484610};\\\", \\\"{x:1308,y:501,t:1527030484627};\\\", \\\"{x:1308,y:508,t:1527030484644};\\\", \\\"{x:1308,y:518,t:1527030484661};\\\", \\\"{x:1308,y:524,t:1527030484677};\\\", \\\"{x:1308,y:529,t:1527030484694};\\\", \\\"{x:1309,y:536,t:1527030484710};\\\", \\\"{x:1309,y:539,t:1527030484727};\\\", \\\"{x:1309,y:543,t:1527030484744};\\\", \\\"{x:1309,y:547,t:1527030484760};\\\", \\\"{x:1309,y:552,t:1527030484777};\\\", \\\"{x:1309,y:555,t:1527030484793};\\\", \\\"{x:1309,y:560,t:1527030484810};\\\", \\\"{x:1309,y:567,t:1527030484827};\\\", \\\"{x:1309,y:574,t:1527030484844};\\\", \\\"{x:1309,y:589,t:1527030484860};\\\", \\\"{x:1309,y:603,t:1527030484877};\\\", \\\"{x:1309,y:618,t:1527030484893};\\\", \\\"{x:1309,y:636,t:1527030484910};\\\", \\\"{x:1309,y:655,t:1527030484927};\\\", \\\"{x:1309,y:673,t:1527030484944};\\\", \\\"{x:1305,y:686,t:1527030484961};\\\", \\\"{x:1304,y:697,t:1527030484977};\\\", \\\"{x:1302,y:709,t:1527030484993};\\\", \\\"{x:1301,y:719,t:1527030485010};\\\", \\\"{x:1299,y:731,t:1527030485027};\\\", \\\"{x:1298,y:737,t:1527030485043};\\\", \\\"{x:1297,y:743,t:1527030485060};\\\", \\\"{x:1297,y:748,t:1527030485078};\\\", \\\"{x:1297,y:756,t:1527030485093};\\\", \\\"{x:1297,y:765,t:1527030485110};\\\", \\\"{x:1297,y:777,t:1527030485127};\\\", \\\"{x:1297,y:787,t:1527030485144};\\\", \\\"{x:1298,y:796,t:1527030485160};\\\", \\\"{x:1299,y:805,t:1527030485178};\\\", \\\"{x:1302,y:814,t:1527030485194};\\\", \\\"{x:1304,y:821,t:1527030485211};\\\", \\\"{x:1307,y:829,t:1527030485228};\\\", \\\"{x:1308,y:837,t:1527030485244};\\\", \\\"{x:1310,y:840,t:1527030485261};\\\", \\\"{x:1310,y:842,t:1527030485277};\\\", \\\"{x:1311,y:845,t:1527030485294};\\\", \\\"{x:1311,y:847,t:1527030485311};\\\", \\\"{x:1312,y:851,t:1527030485327};\\\", \\\"{x:1312,y:853,t:1527030485344};\\\", \\\"{x:1313,y:856,t:1527030485360};\\\", \\\"{x:1313,y:857,t:1527030485377};\\\", \\\"{x:1313,y:860,t:1527030485394};\\\", \\\"{x:1313,y:861,t:1527030485410};\\\", \\\"{x:1314,y:864,t:1527030485427};\\\", \\\"{x:1314,y:868,t:1527030485443};\\\", \\\"{x:1315,y:875,t:1527030485459};\\\", \\\"{x:1315,y:880,t:1527030485477};\\\", \\\"{x:1315,y:886,t:1527030485494};\\\", \\\"{x:1315,y:891,t:1527030485510};\\\", \\\"{x:1315,y:895,t:1527030485527};\\\", \\\"{x:1315,y:902,t:1527030485544};\\\", \\\"{x:1315,y:909,t:1527030485560};\\\", \\\"{x:1317,y:916,t:1527030485577};\\\", \\\"{x:1317,y:919,t:1527030485594};\\\", \\\"{x:1317,y:922,t:1527030485610};\\\", \\\"{x:1317,y:925,t:1527030485627};\\\", \\\"{x:1318,y:932,t:1527030485643};\\\", \\\"{x:1318,y:935,t:1527030485660};\\\", \\\"{x:1318,y:938,t:1527030485677};\\\", \\\"{x:1318,y:939,t:1527030485694};\\\", \\\"{x:1319,y:941,t:1527030485710};\\\", \\\"{x:1320,y:945,t:1527030485727};\\\", \\\"{x:1320,y:946,t:1527030485744};\\\", \\\"{x:1320,y:947,t:1527030485760};\\\", \\\"{x:1320,y:948,t:1527030485777};\\\", \\\"{x:1320,y:949,t:1527030485794};\\\", \\\"{x:1320,y:950,t:1527030485811};\\\", \\\"{x:1320,y:951,t:1527030485828};\\\", \\\"{x:1320,y:952,t:1527030485884};\\\", \\\"{x:1320,y:953,t:1527030485924};\\\", \\\"{x:1320,y:954,t:1527030485932};\\\", \\\"{x:1320,y:955,t:1527030485964};\\\", \\\"{x:1320,y:956,t:1527030485989};\\\", \\\"{x:1320,y:957,t:1527030486005};\\\", \\\"{x:1320,y:958,t:1527030486036};\\\", \\\"{x:1320,y:959,t:1527030486076};\\\", \\\"{x:1321,y:960,t:1527030486181};\\\", \\\"{x:1323,y:960,t:1527030486204};\\\", \\\"{x:1326,y:960,t:1527030486212};\\\", \\\"{x:1328,y:960,t:1527030486228};\\\", \\\"{x:1336,y:962,t:1527030486244};\\\", \\\"{x:1344,y:964,t:1527030486262};\\\", \\\"{x:1349,y:966,t:1527030486278};\\\", \\\"{x:1357,y:968,t:1527030486295};\\\", \\\"{x:1360,y:968,t:1527030486312};\\\", \\\"{x:1366,y:968,t:1527030486327};\\\", \\\"{x:1368,y:968,t:1527030486345};\\\", \\\"{x:1369,y:968,t:1527030486361};\\\", \\\"{x:1371,y:968,t:1527030486378};\\\", \\\"{x:1372,y:968,t:1527030486395};\\\", \\\"{x:1373,y:968,t:1527030486411};\\\", \\\"{x:1375,y:968,t:1527030486428};\\\", \\\"{x:1376,y:968,t:1527030486444};\\\", \\\"{x:1377,y:968,t:1527030486476};\\\", \\\"{x:1378,y:968,t:1527030486748};\\\", \\\"{x:1379,y:968,t:1527030486764};\\\", \\\"{x:1381,y:968,t:1527030486778};\\\", \\\"{x:1384,y:968,t:1527030486795};\\\", \\\"{x:1391,y:968,t:1527030486812};\\\", \\\"{x:1402,y:968,t:1527030486828};\\\", \\\"{x:1415,y:968,t:1527030486844};\\\", \\\"{x:1424,y:968,t:1527030486861};\\\", \\\"{x:1432,y:968,t:1527030486878};\\\", \\\"{x:1437,y:968,t:1527030486895};\\\", \\\"{x:1440,y:968,t:1527030486911};\\\", \\\"{x:1442,y:968,t:1527030486928};\\\", \\\"{x:1443,y:967,t:1527030486945};\\\", \\\"{x:1446,y:967,t:1527030486961};\\\", \\\"{x:1450,y:965,t:1527030486978};\\\", \\\"{x:1452,y:965,t:1527030486995};\\\", \\\"{x:1456,y:965,t:1527030487011};\\\", \\\"{x:1461,y:965,t:1527030487029};\\\", \\\"{x:1463,y:965,t:1527030487045};\\\", \\\"{x:1465,y:964,t:1527030487062};\\\", \\\"{x:1465,y:963,t:1527030487092};\\\", \\\"{x:1464,y:963,t:1527030487460};\\\", \\\"{x:1463,y:964,t:1527030487484};\\\", \\\"{x:1462,y:965,t:1527030487508};\\\", \\\"{x:1461,y:965,t:1527030487524};\\\", \\\"{x:1462,y:965,t:1527030487788};\\\", \\\"{x:1463,y:965,t:1527030487804};\\\", \\\"{x:1464,y:965,t:1527030487813};\\\", \\\"{x:1467,y:965,t:1527030487829};\\\", \\\"{x:1472,y:965,t:1527030487845};\\\", \\\"{x:1478,y:965,t:1527030487862};\\\", \\\"{x:1483,y:965,t:1527030487879};\\\", \\\"{x:1491,y:966,t:1527030487895};\\\", \\\"{x:1498,y:968,t:1527030487912};\\\", \\\"{x:1502,y:968,t:1527030487929};\\\", \\\"{x:1506,y:969,t:1527030487946};\\\", \\\"{x:1507,y:969,t:1527030487962};\\\", \\\"{x:1509,y:969,t:1527030487978};\\\", \\\"{x:1512,y:969,t:1527030487996};\\\", \\\"{x:1515,y:969,t:1527030488012};\\\", \\\"{x:1516,y:969,t:1527030488029};\\\", \\\"{x:1519,y:969,t:1527030488046};\\\", \\\"{x:1520,y:969,t:1527030488076};\\\", \\\"{x:1522,y:968,t:1527030488437};\\\", \\\"{x:1524,y:968,t:1527030488452};\\\", \\\"{x:1525,y:968,t:1527030488462};\\\", \\\"{x:1529,y:967,t:1527030488480};\\\", \\\"{x:1533,y:966,t:1527030488496};\\\", \\\"{x:1537,y:966,t:1527030488512};\\\", \\\"{x:1541,y:966,t:1527030488530};\\\", \\\"{x:1543,y:966,t:1527030488545};\\\", \\\"{x:1544,y:966,t:1527030488563};\\\", \\\"{x:1545,y:966,t:1527030488579};\\\", \\\"{x:1546,y:965,t:1527030489285};\\\", \\\"{x:1546,y:963,t:1527030489316};\\\", \\\"{x:1546,y:962,t:1527030489332};\\\", \\\"{x:1546,y:959,t:1527030489348};\\\", \\\"{x:1546,y:956,t:1527030489363};\\\", \\\"{x:1546,y:951,t:1527030489379};\\\", \\\"{x:1546,y:947,t:1527030489396};\\\", \\\"{x:1546,y:944,t:1527030489412};\\\", \\\"{x:1546,y:940,t:1527030489429};\\\", \\\"{x:1546,y:935,t:1527030489446};\\\", \\\"{x:1546,y:933,t:1527030489463};\\\", \\\"{x:1546,y:930,t:1527030489479};\\\", \\\"{x:1546,y:927,t:1527030489496};\\\", \\\"{x:1546,y:925,t:1527030489513};\\\", \\\"{x:1546,y:923,t:1527030489529};\\\", \\\"{x:1546,y:922,t:1527030489546};\\\", \\\"{x:1546,y:920,t:1527030489563};\\\", \\\"{x:1546,y:918,t:1527030489579};\\\", \\\"{x:1546,y:917,t:1527030489596};\\\", \\\"{x:1546,y:914,t:1527030489613};\\\", \\\"{x:1546,y:912,t:1527030489629};\\\", \\\"{x:1546,y:911,t:1527030489646};\\\", \\\"{x:1546,y:907,t:1527030489664};\\\", \\\"{x:1546,y:902,t:1527030489679};\\\", \\\"{x:1546,y:896,t:1527030489697};\\\", \\\"{x:1546,y:886,t:1527030489713};\\\", \\\"{x:1546,y:872,t:1527030489729};\\\", \\\"{x:1546,y:847,t:1527030489746};\\\", \\\"{x:1546,y:814,t:1527030489763};\\\", \\\"{x:1546,y:783,t:1527030489780};\\\", \\\"{x:1549,y:766,t:1527030489796};\\\", \\\"{x:1553,y:752,t:1527030489814};\\\", \\\"{x:1556,y:738,t:1527030489831};\\\", \\\"{x:1557,y:728,t:1527030489846};\\\", \\\"{x:1559,y:715,t:1527030489862};\\\", \\\"{x:1561,y:703,t:1527030489880};\\\", \\\"{x:1562,y:689,t:1527030489896};\\\", \\\"{x:1562,y:677,t:1527030489913};\\\", \\\"{x:1562,y:661,t:1527030489930};\\\", \\\"{x:1562,y:643,t:1527030489946};\\\", \\\"{x:1562,y:613,t:1527030489963};\\\", \\\"{x:1562,y:596,t:1527030489979};\\\", \\\"{x:1560,y:576,t:1527030489996};\\\", \\\"{x:1556,y:555,t:1527030490014};\\\", \\\"{x:1550,y:534,t:1527030490030};\\\", \\\"{x:1544,y:513,t:1527030490046};\\\", \\\"{x:1534,y:493,t:1527030490064};\\\", \\\"{x:1525,y:475,t:1527030490080};\\\", \\\"{x:1515,y:458,t:1527030490097};\\\", \\\"{x:1510,y:451,t:1527030490113};\\\", \\\"{x:1506,y:445,t:1527030490130};\\\", \\\"{x:1499,y:437,t:1527030490146};\\\", \\\"{x:1491,y:429,t:1527030490164};\\\", \\\"{x:1476,y:422,t:1527030490180};\\\", \\\"{x:1461,y:422,t:1527030490197};\\\", \\\"{x:1443,y:423,t:1527030490213};\\\", \\\"{x:1424,y:432,t:1527030490230};\\\", \\\"{x:1411,y:444,t:1527030490246};\\\", \\\"{x:1407,y:463,t:1527030490263};\\\", \\\"{x:1405,y:475,t:1527030490280};\\\", \\\"{x:1404,y:482,t:1527030490296};\\\", \\\"{x:1404,y:487,t:1527030490313};\\\", \\\"{x:1404,y:491,t:1527030490330};\\\", \\\"{x:1404,y:494,t:1527030490346};\\\", \\\"{x:1402,y:497,t:1527030490364};\\\", \\\"{x:1402,y:499,t:1527030490381};\\\", \\\"{x:1401,y:502,t:1527030490398};\\\", \\\"{x:1400,y:504,t:1527030490414};\\\", \\\"{x:1398,y:505,t:1527030490431};\\\", \\\"{x:1397,y:506,t:1527030490448};\\\", \\\"{x:1396,y:506,t:1527030490463};\\\", \\\"{x:1394,y:506,t:1527030490480};\\\", \\\"{x:1393,y:506,t:1527030490496};\\\", \\\"{x:1391,y:506,t:1527030490516};\\\", \\\"{x:1390,y:506,t:1527030490531};\\\", \\\"{x:1390,y:504,t:1527030490581};\\\", \\\"{x:1394,y:502,t:1527030490598};\\\", \\\"{x:1398,y:500,t:1527030490614};\\\", \\\"{x:1407,y:499,t:1527030490631};\\\", \\\"{x:1418,y:497,t:1527030490647};\\\", \\\"{x:1425,y:496,t:1527030490664};\\\", \\\"{x:1429,y:495,t:1527030490681};\\\", \\\"{x:1431,y:494,t:1527030490697};\\\", \\\"{x:1431,y:493,t:1527030490732};\\\", \\\"{x:1433,y:492,t:1527030490821};\\\", \\\"{x:1434,y:492,t:1527030490837};\\\", \\\"{x:1435,y:492,t:1527030490847};\\\", \\\"{x:1439,y:492,t:1527030490864};\\\", \\\"{x:1446,y:493,t:1527030490880};\\\", \\\"{x:1454,y:495,t:1527030490898};\\\", \\\"{x:1461,y:497,t:1527030490914};\\\", \\\"{x:1467,y:500,t:1527030490931};\\\", \\\"{x:1470,y:500,t:1527030490947};\\\", \\\"{x:1470,y:499,t:1527030491204};\\\", \\\"{x:1470,y:498,t:1527030491220};\\\", \\\"{x:1469,y:498,t:1527030491236};\\\", \\\"{x:1469,y:496,t:1527030492421};\\\", \\\"{x:1470,y:496,t:1527030492431};\\\", \\\"{x:1474,y:496,t:1527030492449};\\\", \\\"{x:1477,y:496,t:1527030492465};\\\", \\\"{x:1479,y:496,t:1527030492482};\\\", \\\"{x:1481,y:496,t:1527030492498};\\\", \\\"{x:1484,y:496,t:1527030492515};\\\", \\\"{x:1490,y:496,t:1527030492531};\\\", \\\"{x:1494,y:496,t:1527030492548};\\\", \\\"{x:1499,y:497,t:1527030492565};\\\", \\\"{x:1502,y:497,t:1527030492582};\\\", \\\"{x:1505,y:497,t:1527030492599};\\\", \\\"{x:1509,y:498,t:1527030492615};\\\", \\\"{x:1515,y:498,t:1527030492632};\\\", \\\"{x:1516,y:499,t:1527030492648};\\\", \\\"{x:1520,y:499,t:1527030492665};\\\", \\\"{x:1522,y:499,t:1527030492682};\\\", \\\"{x:1523,y:499,t:1527030492908};\\\", \\\"{x:1525,y:499,t:1527030492916};\\\", \\\"{x:1528,y:499,t:1527030492932};\\\", \\\"{x:1534,y:500,t:1527030492948};\\\", \\\"{x:1537,y:500,t:1527030492966};\\\", \\\"{x:1541,y:500,t:1527030492982};\\\", \\\"{x:1544,y:501,t:1527030492998};\\\", \\\"{x:1546,y:501,t:1527030493015};\\\", \\\"{x:1547,y:501,t:1527030493059};\\\", \\\"{x:1548,y:502,t:1527030493525};\\\", \\\"{x:1548,y:503,t:1527030493532};\\\", \\\"{x:1548,y:507,t:1527030493549};\\\", \\\"{x:1548,y:512,t:1527030493566};\\\", \\\"{x:1548,y:519,t:1527030493583};\\\", \\\"{x:1548,y:522,t:1527030493598};\\\", \\\"{x:1548,y:526,t:1527030493616};\\\", \\\"{x:1548,y:530,t:1527030493634};\\\", \\\"{x:1548,y:536,t:1527030493649};\\\", \\\"{x:1548,y:540,t:1527030493665};\\\", \\\"{x:1548,y:543,t:1527030493682};\\\", \\\"{x:1548,y:547,t:1527030493699};\\\", \\\"{x:1548,y:554,t:1527030493715};\\\", \\\"{x:1548,y:559,t:1527030493732};\\\", \\\"{x:1548,y:564,t:1527030493749};\\\", \\\"{x:1548,y:569,t:1527030493765};\\\", \\\"{x:1548,y:574,t:1527030493782};\\\", \\\"{x:1547,y:575,t:1527030493798};\\\", \\\"{x:1547,y:577,t:1527030493815};\\\", \\\"{x:1547,y:578,t:1527030493843};\\\", \\\"{x:1547,y:579,t:1527030493859};\\\", \\\"{x:1546,y:580,t:1527030493875};\\\", \\\"{x:1546,y:581,t:1527030493899};\\\", \\\"{x:1546,y:582,t:1527030493955};\\\", \\\"{x:1546,y:583,t:1527030493965};\\\", \\\"{x:1545,y:585,t:1527030493982};\\\", \\\"{x:1545,y:586,t:1527030493999};\\\", \\\"{x:1545,y:589,t:1527030494015};\\\", \\\"{x:1544,y:592,t:1527030494032};\\\", \\\"{x:1544,y:596,t:1527030494049};\\\", \\\"{x:1543,y:600,t:1527030494065};\\\", \\\"{x:1542,y:604,t:1527030494082};\\\", \\\"{x:1541,y:615,t:1527030494098};\\\", \\\"{x:1538,y:622,t:1527030494115};\\\", \\\"{x:1535,y:631,t:1527030494132};\\\", \\\"{x:1534,y:644,t:1527030494149};\\\", \\\"{x:1533,y:654,t:1527030494164};\\\", \\\"{x:1533,y:663,t:1527030494182};\\\", \\\"{x:1533,y:672,t:1527030494198};\\\", \\\"{x:1533,y:679,t:1527030494215};\\\", \\\"{x:1533,y:686,t:1527030494232};\\\", \\\"{x:1533,y:692,t:1527030494249};\\\", \\\"{x:1533,y:698,t:1527030494265};\\\", \\\"{x:1533,y:701,t:1527030494282};\\\", \\\"{x:1533,y:704,t:1527030494299};\\\", \\\"{x:1533,y:706,t:1527030494315};\\\", \\\"{x:1533,y:707,t:1527030494332};\\\", \\\"{x:1533,y:708,t:1527030494349};\\\", \\\"{x:1534,y:711,t:1527030494365};\\\", \\\"{x:1535,y:712,t:1527030494382};\\\", \\\"{x:1535,y:714,t:1527030494399};\\\", \\\"{x:1535,y:715,t:1527030494427};\\\", \\\"{x:1535,y:716,t:1527030494524};\\\", \\\"{x:1535,y:717,t:1527030494532};\\\", \\\"{x:1535,y:718,t:1527030494555};\\\", \\\"{x:1537,y:719,t:1527030494566};\\\", \\\"{x:1537,y:721,t:1527030494583};\\\", \\\"{x:1537,y:722,t:1527030494599};\\\", \\\"{x:1537,y:724,t:1527030494617};\\\", \\\"{x:1538,y:726,t:1527030494633};\\\", \\\"{x:1539,y:729,t:1527030494649};\\\", \\\"{x:1541,y:733,t:1527030494667};\\\", \\\"{x:1542,y:738,t:1527030494683};\\\", \\\"{x:1544,y:746,t:1527030494700};\\\", \\\"{x:1544,y:748,t:1527030494716};\\\", \\\"{x:1545,y:752,t:1527030494732};\\\", \\\"{x:1546,y:755,t:1527030494750};\\\", \\\"{x:1546,y:758,t:1527030494767};\\\", \\\"{x:1548,y:760,t:1527030494783};\\\", \\\"{x:1548,y:763,t:1527030494799};\\\", \\\"{x:1549,y:768,t:1527030494816};\\\", \\\"{x:1550,y:771,t:1527030494833};\\\", \\\"{x:1550,y:775,t:1527030494849};\\\", \\\"{x:1551,y:780,t:1527030494866};\\\", \\\"{x:1551,y:783,t:1527030494882};\\\", \\\"{x:1552,y:787,t:1527030494899};\\\", \\\"{x:1553,y:790,t:1527030494916};\\\", \\\"{x:1553,y:792,t:1527030494947};\\\", \\\"{x:1553,y:793,t:1527030494955};\\\", \\\"{x:1553,y:794,t:1527030494966};\\\", \\\"{x:1553,y:798,t:1527030494982};\\\", \\\"{x:1553,y:805,t:1527030495000};\\\", \\\"{x:1553,y:813,t:1527030495016};\\\", \\\"{x:1553,y:820,t:1527030495033};\\\", \\\"{x:1553,y:825,t:1527030495049};\\\", \\\"{x:1553,y:829,t:1527030495067};\\\", \\\"{x:1553,y:833,t:1527030495084};\\\", \\\"{x:1553,y:835,t:1527030495099};\\\", \\\"{x:1553,y:838,t:1527030495116};\\\", \\\"{x:1553,y:841,t:1527030495133};\\\", \\\"{x:1553,y:843,t:1527030495150};\\\", \\\"{x:1553,y:845,t:1527030495166};\\\", \\\"{x:1553,y:846,t:1527030495183};\\\", \\\"{x:1553,y:849,t:1527030495199};\\\", \\\"{x:1553,y:851,t:1527030495216};\\\", \\\"{x:1553,y:852,t:1527030495234};\\\", \\\"{x:1553,y:854,t:1527030495249};\\\", \\\"{x:1553,y:857,t:1527030495267};\\\", \\\"{x:1553,y:861,t:1527030495283};\\\", \\\"{x:1555,y:863,t:1527030495300};\\\", \\\"{x:1555,y:867,t:1527030495316};\\\", \\\"{x:1555,y:871,t:1527030495333};\\\", \\\"{x:1556,y:876,t:1527030495350};\\\", \\\"{x:1556,y:880,t:1527030495367};\\\", \\\"{x:1556,y:883,t:1527030495384};\\\", \\\"{x:1556,y:889,t:1527030495400};\\\", \\\"{x:1556,y:893,t:1527030495416};\\\", \\\"{x:1556,y:897,t:1527030495433};\\\", \\\"{x:1556,y:904,t:1527030495449};\\\", \\\"{x:1557,y:912,t:1527030495466};\\\", \\\"{x:1557,y:918,t:1527030495483};\\\", \\\"{x:1557,y:923,t:1527030495500};\\\", \\\"{x:1557,y:926,t:1527030495516};\\\", \\\"{x:1557,y:930,t:1527030495533};\\\", \\\"{x:1557,y:931,t:1527030495549};\\\", \\\"{x:1557,y:933,t:1527030495566};\\\", \\\"{x:1557,y:935,t:1527030495588};\\\", \\\"{x:1557,y:936,t:1527030495603};\\\", \\\"{x:1557,y:937,t:1527030495620};\\\", \\\"{x:1557,y:938,t:1527030495633};\\\", \\\"{x:1557,y:939,t:1527030495651};\\\", \\\"{x:1557,y:942,t:1527030495666};\\\", \\\"{x:1557,y:944,t:1527030495683};\\\", \\\"{x:1556,y:947,t:1527030495701};\\\", \\\"{x:1556,y:948,t:1527030495717};\\\", \\\"{x:1555,y:950,t:1527030495733};\\\", \\\"{x:1555,y:952,t:1527030495751};\\\", \\\"{x:1555,y:955,t:1527030495766};\\\", \\\"{x:1555,y:958,t:1527030495784};\\\", \\\"{x:1555,y:963,t:1527030495801};\\\", \\\"{x:1555,y:964,t:1527030495816};\\\", \\\"{x:1555,y:965,t:1527030495833};\\\", \\\"{x:1555,y:966,t:1527030495851};\\\", \\\"{x:1555,y:967,t:1527030495892};\\\", \\\"{x:1555,y:968,t:1527030495940};\\\", \\\"{x:1554,y:969,t:1527030496109};\\\", \\\"{x:1553,y:969,t:1527030497397};\\\", \\\"{x:1553,y:967,t:1527030497413};\\\", \\\"{x:1553,y:964,t:1527030497420};\\\", \\\"{x:1553,y:962,t:1527030497435};\\\", \\\"{x:1553,y:951,t:1527030497452};\\\", \\\"{x:1553,y:936,t:1527030497468};\\\", \\\"{x:1553,y:914,t:1527030497485};\\\", \\\"{x:1553,y:891,t:1527030497502};\\\", \\\"{x:1554,y:865,t:1527030497518};\\\", \\\"{x:1558,y:840,t:1527030497535};\\\", \\\"{x:1560,y:816,t:1527030497552};\\\", \\\"{x:1560,y:790,t:1527030497568};\\\", \\\"{x:1560,y:760,t:1527030497585};\\\", \\\"{x:1560,y:725,t:1527030497602};\\\", \\\"{x:1559,y:696,t:1527030497618};\\\", \\\"{x:1555,y:672,t:1527030497636};\\\", \\\"{x:1551,y:642,t:1527030497651};\\\", \\\"{x:1548,y:625,t:1527030497668};\\\", \\\"{x:1547,y:615,t:1527030497685};\\\", \\\"{x:1547,y:608,t:1527030497701};\\\", \\\"{x:1547,y:603,t:1527030497718};\\\", \\\"{x:1547,y:598,t:1527030497735};\\\", \\\"{x:1547,y:594,t:1527030497752};\\\", \\\"{x:1547,y:588,t:1527030497768};\\\", \\\"{x:1547,y:582,t:1527030497785};\\\", \\\"{x:1547,y:578,t:1527030497802};\\\", \\\"{x:1547,y:575,t:1527030497818};\\\", \\\"{x:1547,y:574,t:1527030497835};\\\", \\\"{x:1547,y:572,t:1527030497852};\\\", \\\"{x:1547,y:571,t:1527030497868};\\\", \\\"{x:1547,y:568,t:1527030497885};\\\", \\\"{x:1547,y:566,t:1527030497902};\\\", \\\"{x:1547,y:565,t:1527030497919};\\\", \\\"{x:1547,y:562,t:1527030497935};\\\", \\\"{x:1548,y:561,t:1527030497953};\\\", \\\"{x:1548,y:560,t:1527030497969};\\\", \\\"{x:1548,y:559,t:1527030498037};\\\", \\\"{x:1548,y:558,t:1527030503437};\\\", \\\"{x:1544,y:558,t:1527030503444};\\\", \\\"{x:1538,y:558,t:1527030503455};\\\", \\\"{x:1523,y:558,t:1527030503472};\\\", \\\"{x:1505,y:558,t:1527030503488};\\\", \\\"{x:1489,y:558,t:1527030503505};\\\", \\\"{x:1480,y:558,t:1527030503522};\\\", \\\"{x:1476,y:558,t:1527030503538};\\\", \\\"{x:1475,y:558,t:1527030503555};\\\", \\\"{x:1473,y:558,t:1527030503572};\\\", \\\"{x:1472,y:559,t:1527030503588};\\\", \\\"{x:1471,y:559,t:1527030503605};\\\", \\\"{x:1467,y:559,t:1527030503622};\\\", \\\"{x:1463,y:560,t:1527030503638};\\\", \\\"{x:1459,y:560,t:1527030503655};\\\", \\\"{x:1455,y:561,t:1527030503672};\\\", \\\"{x:1451,y:562,t:1527030503688};\\\", \\\"{x:1448,y:562,t:1527030503705};\\\", \\\"{x:1445,y:563,t:1527030503722};\\\", \\\"{x:1441,y:563,t:1527030503739};\\\", \\\"{x:1438,y:564,t:1527030503756};\\\", \\\"{x:1431,y:565,t:1527030503772};\\\", \\\"{x:1426,y:565,t:1527030503789};\\\", \\\"{x:1422,y:566,t:1527030503805};\\\", \\\"{x:1420,y:566,t:1527030503822};\\\", \\\"{x:1417,y:566,t:1527030503841};\\\", \\\"{x:1416,y:566,t:1527030503855};\\\", \\\"{x:1415,y:566,t:1527030503871};\\\", \\\"{x:1414,y:566,t:1527030503888};\\\", \\\"{x:1413,y:567,t:1527030503923};\\\", \\\"{x:1412,y:567,t:1527030509139};\\\", \\\"{x:1412,y:566,t:1527030509147};\\\", \\\"{x:1411,y:566,t:1527030509158};\\\", \\\"{x:1411,y:565,t:1527030509175};\\\", \\\"{x:1410,y:565,t:1527030509212};\\\", \\\"{x:1410,y:564,t:1527030509227};\\\", \\\"{x:1410,y:563,t:1527030509267};\\\", \\\"{x:1410,y:562,t:1527030509282};\\\", \\\"{x:1410,y:566,t:1527030509796};\\\", \\\"{x:1410,y:573,t:1527030509811};\\\", \\\"{x:1411,y:588,t:1527030509825};\\\", \\\"{x:1413,y:605,t:1527030509842};\\\", \\\"{x:1417,y:633,t:1527030509858};\\\", \\\"{x:1417,y:649,t:1527030509874};\\\", \\\"{x:1418,y:667,t:1527030509891};\\\", \\\"{x:1419,y:685,t:1527030509909};\\\", \\\"{x:1419,y:703,t:1527030509925};\\\", \\\"{x:1419,y:717,t:1527030509942};\\\", \\\"{x:1419,y:736,t:1527030509959};\\\", \\\"{x:1422,y:755,t:1527030509975};\\\", \\\"{x:1425,y:774,t:1527030509992};\\\", \\\"{x:1425,y:790,t:1527030510009};\\\", \\\"{x:1427,y:800,t:1527030510025};\\\", \\\"{x:1427,y:807,t:1527030510042};\\\", \\\"{x:1427,y:813,t:1527030510059};\\\", \\\"{x:1427,y:815,t:1527030510075};\\\", \\\"{x:1427,y:821,t:1527030510092};\\\", \\\"{x:1427,y:826,t:1527030510109};\\\", \\\"{x:1425,y:835,t:1527030510126};\\\", \\\"{x:1422,y:844,t:1527030510142};\\\", \\\"{x:1421,y:852,t:1527030510160};\\\", \\\"{x:1418,y:861,t:1527030510177};\\\", \\\"{x:1416,y:870,t:1527030510192};\\\", \\\"{x:1413,y:879,t:1527030510209};\\\", \\\"{x:1411,y:889,t:1527030510226};\\\", \\\"{x:1407,y:901,t:1527030510242};\\\", \\\"{x:1404,y:914,t:1527030510260};\\\", \\\"{x:1402,y:922,t:1527030510275};\\\", \\\"{x:1399,y:930,t:1527030510293};\\\", \\\"{x:1398,y:938,t:1527030510309};\\\", \\\"{x:1395,y:947,t:1527030510326};\\\", \\\"{x:1393,y:953,t:1527030510342};\\\", \\\"{x:1391,y:957,t:1527030510359};\\\", \\\"{x:1391,y:958,t:1527030510376};\\\", \\\"{x:1390,y:959,t:1527030510404};\\\", \\\"{x:1390,y:958,t:1527030510557};\\\", \\\"{x:1390,y:956,t:1527030510571};\\\", \\\"{x:1390,y:954,t:1527030510580};\\\", \\\"{x:1390,y:952,t:1527030510594};\\\", \\\"{x:1390,y:950,t:1527030510610};\\\", \\\"{x:1390,y:948,t:1527030510626};\\\", \\\"{x:1390,y:947,t:1527030510643};\\\", \\\"{x:1390,y:945,t:1527030510660};\\\", \\\"{x:1390,y:944,t:1527030510676};\\\", \\\"{x:1391,y:943,t:1527030510693};\\\", \\\"{x:1391,y:942,t:1527030510709};\\\", \\\"{x:1391,y:939,t:1527030510726};\\\", \\\"{x:1391,y:937,t:1527030510743};\\\", \\\"{x:1391,y:933,t:1527030510760};\\\", \\\"{x:1391,y:929,t:1527030510776};\\\", \\\"{x:1391,y:924,t:1527030510794};\\\", \\\"{x:1391,y:918,t:1527030510809};\\\", \\\"{x:1391,y:913,t:1527030510827};\\\", \\\"{x:1391,y:903,t:1527030510844};\\\", \\\"{x:1391,y:895,t:1527030510859};\\\", \\\"{x:1391,y:888,t:1527030510875};\\\", \\\"{x:1392,y:877,t:1527030510893};\\\", \\\"{x:1392,y:869,t:1527030510909};\\\", \\\"{x:1393,y:862,t:1527030510926};\\\", \\\"{x:1395,y:855,t:1527030510943};\\\", \\\"{x:1397,y:843,t:1527030510959};\\\", \\\"{x:1399,y:829,t:1527030510976};\\\", \\\"{x:1401,y:815,t:1527030510993};\\\", \\\"{x:1403,y:803,t:1527030511009};\\\", \\\"{x:1403,y:798,t:1527030511026};\\\", \\\"{x:1404,y:794,t:1527030511043};\\\", \\\"{x:1404,y:793,t:1527030511059};\\\", \\\"{x:1404,y:791,t:1527030511076};\\\", \\\"{x:1404,y:790,t:1527030511100};\\\", \\\"{x:1404,y:789,t:1527030511109};\\\", \\\"{x:1404,y:788,t:1527030511132};\\\", \\\"{x:1404,y:787,t:1527030511180};\\\", \\\"{x:1404,y:786,t:1527030511193};\\\", \\\"{x:1404,y:785,t:1527030511209};\\\", \\\"{x:1404,y:784,t:1527030511227};\\\", \\\"{x:1402,y:782,t:1527030511242};\\\", \\\"{x:1401,y:780,t:1527030511260};\\\", \\\"{x:1399,y:779,t:1527030511275};\\\", \\\"{x:1398,y:778,t:1527030511293};\\\", \\\"{x:1397,y:777,t:1527030511309};\\\", \\\"{x:1396,y:774,t:1527030511326};\\\", \\\"{x:1395,y:774,t:1527030511347};\\\", \\\"{x:1395,y:773,t:1527030511371};\\\", \\\"{x:1394,y:772,t:1527030511596};\\\", \\\"{x:1394,y:771,t:1527030511610};\\\", \\\"{x:1392,y:770,t:1527030511652};\\\", \\\"{x:1391,y:769,t:1527030511828};\\\", \\\"{x:1391,y:768,t:1527030512916};\\\", \\\"{x:1392,y:768,t:1527030512928};\\\", \\\"{x:1393,y:766,t:1527030512944};\\\", \\\"{x:1398,y:765,t:1527030512961};\\\", \\\"{x:1400,y:765,t:1527030512978};\\\", \\\"{x:1403,y:765,t:1527030512995};\\\", \\\"{x:1411,y:765,t:1527030513012};\\\", \\\"{x:1417,y:764,t:1527030513028};\\\", \\\"{x:1422,y:762,t:1527030513045};\\\", \\\"{x:1429,y:762,t:1527030513062};\\\", \\\"{x:1433,y:762,t:1527030513077};\\\", \\\"{x:1436,y:762,t:1527030513095};\\\", \\\"{x:1437,y:762,t:1527030513140};\\\", \\\"{x:1439,y:762,t:1527030513164};\\\", \\\"{x:1440,y:762,t:1527030513177};\\\", \\\"{x:1442,y:761,t:1527030513194};\\\", \\\"{x:1446,y:761,t:1527030513212};\\\", \\\"{x:1447,y:761,t:1527030513228};\\\", \\\"{x:1450,y:759,t:1527030513885};\\\", \\\"{x:1451,y:759,t:1527030513895};\\\", \\\"{x:1454,y:759,t:1527030513911};\\\", \\\"{x:1461,y:759,t:1527030513929};\\\", \\\"{x:1468,y:759,t:1527030513945};\\\", \\\"{x:1475,y:759,t:1527030513962};\\\", \\\"{x:1480,y:758,t:1527030513979};\\\", \\\"{x:1484,y:758,t:1527030513995};\\\", \\\"{x:1488,y:758,t:1527030514011};\\\", \\\"{x:1491,y:758,t:1527030514029};\\\", \\\"{x:1492,y:758,t:1527030514052};\\\", \\\"{x:1493,y:758,t:1527030514062};\\\", \\\"{x:1494,y:758,t:1527030514099};\\\", \\\"{x:1495,y:758,t:1527030514111};\\\", \\\"{x:1496,y:758,t:1527030514128};\\\", \\\"{x:1493,y:758,t:1527030514348};\\\", \\\"{x:1492,y:759,t:1527030514372};\\\", \\\"{x:1491,y:759,t:1527030514388};\\\", \\\"{x:1490,y:759,t:1527030514396};\\\", \\\"{x:1489,y:759,t:1527030514595};\\\", \\\"{x:1488,y:759,t:1527030514612};\\\", \\\"{x:1487,y:759,t:1527030515715};\\\", \\\"{x:1487,y:758,t:1527030515732};\\\", \\\"{x:1487,y:757,t:1527030515745};\\\", \\\"{x:1487,y:753,t:1527030515762};\\\", \\\"{x:1487,y:748,t:1527030515780};\\\", \\\"{x:1487,y:744,t:1527030515796};\\\", \\\"{x:1487,y:740,t:1527030515812};\\\", \\\"{x:1487,y:734,t:1527030515829};\\\", \\\"{x:1487,y:729,t:1527030515847};\\\", \\\"{x:1487,y:724,t:1527030515862};\\\", \\\"{x:1487,y:722,t:1527030515879};\\\", \\\"{x:1487,y:720,t:1527030515896};\\\", \\\"{x:1487,y:719,t:1527030515913};\\\", \\\"{x:1487,y:717,t:1527030515930};\\\", \\\"{x:1487,y:716,t:1527030516012};\\\", \\\"{x:1489,y:713,t:1527030518278};\\\", \\\"{x:1491,y:709,t:1527030518286};\\\", \\\"{x:1492,y:706,t:1527030518300};\\\", \\\"{x:1495,y:701,t:1527030518318};\\\", \\\"{x:1497,y:697,t:1527030518333};\\\", \\\"{x:1498,y:693,t:1527030518350};\\\", \\\"{x:1499,y:691,t:1527030518367};\\\", \\\"{x:1499,y:690,t:1527030518384};\\\", \\\"{x:1499,y:686,t:1527030518401};\\\", \\\"{x:1500,y:680,t:1527030518417};\\\", \\\"{x:1500,y:678,t:1527030518433};\\\", \\\"{x:1502,y:674,t:1527030518450};\\\", \\\"{x:1502,y:670,t:1527030518467};\\\", \\\"{x:1504,y:662,t:1527030518483};\\\", \\\"{x:1507,y:655,t:1527030518500};\\\", \\\"{x:1508,y:649,t:1527030518518};\\\", \\\"{x:1512,y:643,t:1527030518533};\\\", \\\"{x:1516,y:631,t:1527030518550};\\\", \\\"{x:1520,y:623,t:1527030518568};\\\", \\\"{x:1522,y:617,t:1527030518584};\\\", \\\"{x:1524,y:612,t:1527030518600};\\\", \\\"{x:1525,y:609,t:1527030518617};\\\", \\\"{x:1526,y:607,t:1527030518634};\\\", \\\"{x:1525,y:607,t:1527030518918};\\\", \\\"{x:1524,y:607,t:1527030518934};\\\", \\\"{x:1523,y:608,t:1527030519014};\\\", \\\"{x:1522,y:610,t:1527030519672};\\\", \\\"{x:1522,y:611,t:1527030519687};\\\", \\\"{x:1521,y:611,t:1527030519703};\\\", \\\"{x:1521,y:612,t:1527030519760};\\\", \\\"{x:1521,y:619,t:1527030522767};\\\", \\\"{x:1521,y:630,t:1527030522775};\\\", \\\"{x:1521,y:643,t:1527030522787};\\\", \\\"{x:1521,y:669,t:1527030522804};\\\", \\\"{x:1521,y:696,t:1527030522819};\\\", \\\"{x:1521,y:724,t:1527030522837};\\\", \\\"{x:1521,y:753,t:1527030522854};\\\", \\\"{x:1522,y:803,t:1527030522869};\\\", \\\"{x:1522,y:830,t:1527030522887};\\\", \\\"{x:1522,y:852,t:1527030522904};\\\", \\\"{x:1520,y:868,t:1527030522919};\\\", \\\"{x:1515,y:883,t:1527030522936};\\\", \\\"{x:1511,y:896,t:1527030522954};\\\", \\\"{x:1507,y:903,t:1527030522970};\\\", \\\"{x:1507,y:904,t:1527030522998};\\\", \\\"{x:1507,y:905,t:1527030523014};\\\", \\\"{x:1506,y:905,t:1527030523022};\\\", \\\"{x:1505,y:905,t:1527030523038};\\\", \\\"{x:1504,y:905,t:1527030523054};\\\", \\\"{x:1500,y:904,t:1527030523070};\\\", \\\"{x:1494,y:897,t:1527030523087};\\\", \\\"{x:1490,y:890,t:1527030523104};\\\", \\\"{x:1487,y:882,t:1527030523119};\\\", \\\"{x:1483,y:871,t:1527030523136};\\\", \\\"{x:1481,y:859,t:1527030523154};\\\", \\\"{x:1477,y:848,t:1527030523170};\\\", \\\"{x:1475,y:843,t:1527030523186};\\\", \\\"{x:1474,y:839,t:1527030523203};\\\", \\\"{x:1472,y:836,t:1527030523221};\\\", \\\"{x:1472,y:835,t:1527030523262};\\\", \\\"{x:1472,y:833,t:1527030523270};\\\", \\\"{x:1471,y:832,t:1527030523287};\\\", \\\"{x:1471,y:831,t:1527030523407};\\\", \\\"{x:1471,y:830,t:1527030523431};\\\", \\\"{x:1471,y:829,t:1527030523447};\\\", \\\"{x:1471,y:828,t:1527030523470};\\\", \\\"{x:1471,y:827,t:1527030523494};\\\", \\\"{x:1471,y:826,t:1527030523510};\\\", \\\"{x:1471,y:825,t:1527030524294};\\\", \\\"{x:1474,y:825,t:1527030524310};\\\", \\\"{x:1477,y:825,t:1527030524321};\\\", \\\"{x:1481,y:825,t:1527030524338};\\\", \\\"{x:1485,y:825,t:1527030524355};\\\", \\\"{x:1487,y:825,t:1527030524371};\\\", \\\"{x:1488,y:825,t:1527030524388};\\\", \\\"{x:1489,y:825,t:1527030524404};\\\", \\\"{x:1492,y:825,t:1527030524421};\\\", \\\"{x:1494,y:825,t:1527030524438};\\\", \\\"{x:1495,y:825,t:1527030524454};\\\", \\\"{x:1499,y:825,t:1527030524471};\\\", \\\"{x:1502,y:825,t:1527030524488};\\\", \\\"{x:1506,y:825,t:1527030524505};\\\", \\\"{x:1512,y:825,t:1527030524521};\\\", \\\"{x:1516,y:825,t:1527030524538};\\\", \\\"{x:1521,y:825,t:1527030524555};\\\", \\\"{x:1526,y:825,t:1527030524571};\\\", \\\"{x:1531,y:825,t:1527030524589};\\\", \\\"{x:1534,y:825,t:1527030524605};\\\", \\\"{x:1535,y:825,t:1527030524621};\\\", \\\"{x:1537,y:825,t:1527030524638};\\\", \\\"{x:1538,y:825,t:1527030524655};\\\", \\\"{x:1539,y:825,t:1527030524671};\\\", \\\"{x:1541,y:825,t:1527030524689};\\\", \\\"{x:1543,y:826,t:1527030524706};\\\", \\\"{x:1544,y:826,t:1527030524823};\\\", \\\"{x:1546,y:826,t:1527030524944};\\\", \\\"{x:1547,y:826,t:1527030524955};\\\", \\\"{x:1548,y:826,t:1527030524973};\\\", \\\"{x:1549,y:826,t:1527030524989};\\\", \\\"{x:1550,y:827,t:1527030525559};\\\", \\\"{x:1550,y:828,t:1527030525583};\\\", \\\"{x:1549,y:829,t:1527030525606};\\\", \\\"{x:1549,y:830,t:1527030526040};\\\", \\\"{x:1549,y:829,t:1527030528206};\\\", \\\"{x:1546,y:826,t:1527030528222};\\\", \\\"{x:1543,y:824,t:1527030528240};\\\", \\\"{x:1542,y:823,t:1527030528257};\\\", \\\"{x:1541,y:822,t:1527030529008};\\\", \\\"{x:1540,y:821,t:1527030529024};\\\", \\\"{x:1540,y:820,t:1527030530072};\\\", \\\"{x:1540,y:821,t:1527030530327};\\\", \\\"{x:1540,y:822,t:1527030530342};\\\", \\\"{x:1540,y:823,t:1527030530359};\\\", \\\"{x:1541,y:824,t:1527030530376};\\\", \\\"{x:1541,y:825,t:1527030530399};\\\", \\\"{x:1541,y:826,t:1527030530409};\\\", \\\"{x:1541,y:827,t:1527030530431};\\\", \\\"{x:1541,y:828,t:1527030530442};\\\", \\\"{x:1541,y:829,t:1527030530459};\\\", \\\"{x:1542,y:830,t:1527030530476};\\\", \\\"{x:1542,y:832,t:1527030530492};\\\", \\\"{x:1542,y:833,t:1527030530509};\\\", \\\"{x:1542,y:834,t:1527030530526};\\\", \\\"{x:1543,y:836,t:1527030530542};\\\", \\\"{x:1544,y:836,t:1527030530655};\\\", \\\"{x:1545,y:836,t:1527030530863};\\\", \\\"{x:1546,y:836,t:1527030530880};\\\", \\\"{x:1547,y:836,t:1527030530911};\\\", \\\"{x:1546,y:837,t:1527030532416};\\\", \\\"{x:1544,y:839,t:1527030532427};\\\", \\\"{x:1538,y:841,t:1527030532443};\\\", \\\"{x:1529,y:844,t:1527030532459};\\\", \\\"{x:1525,y:845,t:1527030532476};\\\", \\\"{x:1520,y:845,t:1527030532493};\\\", \\\"{x:1517,y:845,t:1527030532509};\\\", \\\"{x:1513,y:845,t:1527030532525};\\\", \\\"{x:1511,y:846,t:1527030532543};\\\", \\\"{x:1509,y:846,t:1527030532559};\\\", \\\"{x:1508,y:847,t:1527030532582};\\\", \\\"{x:1506,y:847,t:1527030532678};\\\", \\\"{x:1505,y:847,t:1527030532694};\\\", \\\"{x:1502,y:847,t:1527030532710};\\\", \\\"{x:1497,y:847,t:1527030532726};\\\", \\\"{x:1490,y:847,t:1527030532743};\\\", \\\"{x:1482,y:847,t:1527030532760};\\\", \\\"{x:1476,y:847,t:1527030532777};\\\", \\\"{x:1472,y:848,t:1527030532793};\\\", \\\"{x:1466,y:851,t:1527030532809};\\\", \\\"{x:1460,y:853,t:1527030532827};\\\", \\\"{x:1453,y:858,t:1527030532843};\\\", \\\"{x:1445,y:864,t:1527030532860};\\\", \\\"{x:1434,y:871,t:1527030532877};\\\", \\\"{x:1418,y:881,t:1527030532894};\\\", \\\"{x:1396,y:892,t:1527030532909};\\\", \\\"{x:1350,y:918,t:1527030532927};\\\", \\\"{x:1294,y:942,t:1527030532943};\\\", \\\"{x:1229,y:968,t:1527030532959};\\\", \\\"{x:1160,y:997,t:1527030532977};\\\", \\\"{x:1087,y:1033,t:1527030532993};\\\", \\\"{x:1011,y:1073,t:1527030533009};\\\", \\\"{x:943,y:1111,t:1527030533026};\\\", \\\"{x:868,y:1151,t:1527030533043};\\\", \\\"{x:812,y:1178,t:1527030533059};\\\", \\\"{x:771,y:1194,t:1527030533076};\\\", \\\"{x:730,y:1199,t:1527030533093};\\\", \\\"{x:704,y:1199,t:1527030533108};\\\", \\\"{x:684,y:1199,t:1527030533126};\\\", \\\"{x:669,y:1199,t:1527030533141};\\\", \\\"{x:657,y:1199,t:1527030533158};\\\", \\\"{x:654,y:1198,t:1527030533176};\\\", \\\"{x:650,y:1191,t:1527030533191};\\\", \\\"{x:643,y:1180,t:1527030533208};\\\", \\\"{x:629,y:1161,t:1527030533225};\\\", \\\"{x:604,y:1129,t:1527030533242};\\\", \\\"{x:565,y:1083,t:1527030533259};\\\", \\\"{x:528,y:1032,t:1527030533275};\\\", \\\"{x:506,y:985,t:1527030533293};\\\", \\\"{x:496,y:943,t:1527030533309};\\\", \\\"{x:492,y:905,t:1527030533325};\\\", \\\"{x:495,y:865,t:1527030533342};\\\", \\\"{x:505,y:844,t:1527030533360};\\\", \\\"{x:517,y:829,t:1527030533376};\\\", \\\"{x:532,y:814,t:1527030533392};\\\", \\\"{x:548,y:801,t:1527030533409};\\\", \\\"{x:555,y:790,t:1527030533426};\\\", \\\"{x:558,y:783,t:1527030533443};\\\", \\\"{x:559,y:778,t:1527030533459};\\\", \\\"{x:559,y:774,t:1527030533475};\\\", \\\"{x:559,y:768,t:1527030533492};\\\", \\\"{x:559,y:763,t:1527030533509};\\\", \\\"{x:556,y:756,t:1527030533525};\\\", \\\"{x:553,y:740,t:1527030533542};\\\", \\\"{x:553,y:721,t:1527030533559};\\\", \\\"{x:558,y:697,t:1527030533575};\\\", \\\"{x:576,y:653,t:1527030533593};\\\", \\\"{x:600,y:602,t:1527030533610};\\\", \\\"{x:613,y:576,t:1527030533627};\\\", \\\"{x:623,y:565,t:1527030533642};\\\", \\\"{x:628,y:559,t:1527030533659};\\\", \\\"{x:629,y:558,t:1527030533676};\\\", \\\"{x:627,y:559,t:1527030533774};\\\", \\\"{x:626,y:560,t:1527030533782};\\\", \\\"{x:625,y:561,t:1527030533792};\\\", \\\"{x:624,y:566,t:1527030533809};\\\", \\\"{x:624,y:573,t:1527030533826};\\\", \\\"{x:624,y:578,t:1527030533842};\\\", \\\"{x:624,y:585,t:1527030533860};\\\", \\\"{x:624,y:589,t:1527030533877};\\\", \\\"{x:623,y:595,t:1527030533892};\\\", \\\"{x:622,y:601,t:1527030533909};\\\", \\\"{x:619,y:607,t:1527030533926};\\\", \\\"{x:618,y:609,t:1527030533942};\\\", \\\"{x:618,y:610,t:1527030533959};\\\", \\\"{x:617,y:611,t:1527030533976};\\\", \\\"{x:616,y:612,t:1527030534302};\\\", \\\"{x:614,y:616,t:1527030534310};\\\", \\\"{x:609,y:632,t:1527030534326};\\\", \\\"{x:602,y:658,t:1527030534344};\\\", \\\"{x:596,y:687,t:1527030534361};\\\", \\\"{x:588,y:717,t:1527030534376};\\\", \\\"{x:584,y:741,t:1527030534393};\\\", \\\"{x:579,y:758,t:1527030534410};\\\", \\\"{x:576,y:765,t:1527030534426};\\\", \\\"{x:575,y:768,t:1527030534443};\\\", \\\"{x:575,y:769,t:1527030534463};\\\", \\\"{x:574,y:770,t:1527030534477};\\\", \\\"{x:573,y:771,t:1527030534494};\\\", \\\"{x:572,y:771,t:1527030534639};\\\", \\\"{x:571,y:771,t:1527030534647};\\\", \\\"{x:571,y:770,t:1527030534660};\\\", \\\"{x:569,y:769,t:1527030534676};\\\", \\\"{x:566,y:765,t:1527030534694};\\\", \\\"{x:562,y:760,t:1527030534711};\\\", \\\"{x:558,y:756,t:1527030534726};\\\", \\\"{x:553,y:750,t:1527030534743};\\\", \\\"{x:549,y:745,t:1527030534762};\\\", \\\"{x:546,y:743,t:1527030534777};\\\", \\\"{x:546,y:742,t:1527030536303};\\\", \\\"{x:546,y:740,t:1527030536319};\\\", \\\"{x:547,y:738,t:1527030536334};\\\", \\\"{x:548,y:737,t:1527030536374};\\\", \\\"{x:548,y:736,t:1527030536607};\\\", \\\"{x:550,y:735,t:1527030536622};\\\" ] }, { \\\"rt\\\": 11106, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 10, \\\"time_elapsed\\\": 331604, \\\"internal_node_id\\\": \\\"0.0-6.0-0.0\\\", \\\"subject\\\": \\\"Q0QHK\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"juliet\\\", \\\"condition\\\": \\\"115\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"duration\\\", \\\"q\\\": 6, \\\"clicks\\\": 2, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XFull-YFull\\\", \\\"correct\\\": 1, \\\"orth_correct\\\": 1, \\\"answer\\\": [ \\\"E\\\", \\\"G\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-E \\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:550,y:734,t:1527030540326};\\\", \\\"{x:551,y:734,t:1527030540334};\\\", \\\"{x:552,y:732,t:1527030540350};\\\", \\\"{x:552,y:730,t:1527030540366};\\\", \\\"{x:553,y:730,t:1527030540382};\\\", \\\"{x:553,y:729,t:1527030540447};\\\", \\\"{x:553,y:728,t:1527030540465};\\\", \\\"{x:554,y:726,t:1527030540482};\\\", \\\"{x:555,y:725,t:1527030540518};\\\", \\\"{x:555,y:724,t:1527030540542};\\\", \\\"{x:556,y:723,t:1527030540558};\\\", \\\"{x:557,y:723,t:1527030540599};\\\", \\\"{x:557,y:722,t:1527030540894};\\\", \\\"{x:557,y:721,t:1527030540925};\\\", \\\"{x:561,y:719,t:1527030540934};\\\", \\\"{x:566,y:716,t:1527030540949};\\\", \\\"{x:580,y:711,t:1527030540965};\\\", \\\"{x:597,y:706,t:1527030540979};\\\", \\\"{x:618,y:704,t:1527030540996};\\\", \\\"{x:640,y:700,t:1527030541013};\\\", \\\"{x:667,y:694,t:1527030541029};\\\", \\\"{x:684,y:689,t:1527030541046};\\\", \\\"{x:701,y:685,t:1527030541063};\\\", \\\"{x:721,y:684,t:1527030541080};\\\", \\\"{x:744,y:684,t:1527030541097};\\\", \\\"{x:769,y:684,t:1527030541113};\\\", \\\"{x:792,y:684,t:1527030541129};\\\", \\\"{x:821,y:684,t:1527030541146};\\\", \\\"{x:863,y:688,t:1527030541163};\\\", \\\"{x:921,y:696,t:1527030541180};\\\", \\\"{x:999,y:705,t:1527030541196};\\\", \\\"{x:1086,y:720,t:1527030541212};\\\", \\\"{x:1180,y:734,t:1527030541230};\\\", \\\"{x:1319,y:749,t:1527030541246};\\\", \\\"{x:1410,y:759,t:1527030541263};\\\", \\\"{x:1482,y:768,t:1527030541280};\\\", \\\"{x:1528,y:771,t:1527030541297};\\\", \\\"{x:1559,y:774,t:1527030541312};\\\", \\\"{x:1577,y:775,t:1527030541330};\\\", \\\"{x:1584,y:778,t:1527030541346};\\\", \\\"{x:1584,y:777,t:1527030542358};\\\", \\\"{x:1578,y:774,t:1527030542366};\\\", \\\"{x:1567,y:768,t:1527030542379};\\\", \\\"{x:1539,y:756,t:1527030542396};\\\", \\\"{x:1496,y:738,t:1527030542414};\\\", \\\"{x:1471,y:729,t:1527030542429};\\\", \\\"{x:1456,y:723,t:1527030542446};\\\", \\\"{x:1451,y:718,t:1527030542463};\\\", \\\"{x:1449,y:716,t:1527030542479};\\\", \\\"{x:1448,y:714,t:1527030542497};\\\", \\\"{x:1447,y:713,t:1527030542514};\\\", \\\"{x:1446,y:711,t:1527030542529};\\\", \\\"{x:1446,y:710,t:1527030542546};\\\", \\\"{x:1444,y:707,t:1527030542563};\\\", \\\"{x:1441,y:704,t:1527030542580};\\\", \\\"{x:1436,y:696,t:1527030542596};\\\", \\\"{x:1426,y:682,t:1527030542613};\\\", \\\"{x:1419,y:673,t:1527030542629};\\\", \\\"{x:1409,y:659,t:1527030542647};\\\", \\\"{x:1398,y:643,t:1527030542664};\\\", \\\"{x:1390,y:628,t:1527030542679};\\\", \\\"{x:1380,y:610,t:1527030542696};\\\", \\\"{x:1374,y:599,t:1527030542714};\\\", \\\"{x:1371,y:594,t:1527030542729};\\\", \\\"{x:1367,y:587,t:1527030542747};\\\", \\\"{x:1363,y:581,t:1527030542763};\\\", \\\"{x:1362,y:578,t:1527030542779};\\\", \\\"{x:1358,y:571,t:1527030542797};\\\", \\\"{x:1355,y:568,t:1527030542813};\\\", \\\"{x:1354,y:566,t:1527030542838};\\\", \\\"{x:1352,y:566,t:1527030542861};\\\", \\\"{x:1352,y:565,t:1527030542869};\\\", \\\"{x:1350,y:565,t:1527030542894};\\\", \\\"{x:1349,y:564,t:1527030542901};\\\", \\\"{x:1347,y:564,t:1527030542933};\\\", \\\"{x:1346,y:564,t:1527030542966};\\\", \\\"{x:1344,y:564,t:1527030542989};\\\", \\\"{x:1343,y:564,t:1527030542997};\\\", \\\"{x:1340,y:564,t:1527030543014};\\\", \\\"{x:1335,y:564,t:1527030543029};\\\", \\\"{x:1325,y:566,t:1527030543046};\\\", \\\"{x:1315,y:566,t:1527030543064};\\\", \\\"{x:1304,y:566,t:1527030543080};\\\", \\\"{x:1293,y:566,t:1527030543097};\\\", \\\"{x:1287,y:567,t:1527030543113};\\\", \\\"{x:1285,y:567,t:1527030543130};\\\", \\\"{x:1283,y:568,t:1527030543147};\\\", \\\"{x:1281,y:569,t:1527030543163};\\\", \\\"{x:1283,y:569,t:1527030543582};\\\", \\\"{x:1284,y:569,t:1527030543597};\\\", \\\"{x:1294,y:571,t:1527030543614};\\\", \\\"{x:1300,y:573,t:1527030543629};\\\", \\\"{x:1315,y:577,t:1527030543646};\\\", \\\"{x:1330,y:581,t:1527030543663};\\\", \\\"{x:1346,y:582,t:1527030543679};\\\", \\\"{x:1361,y:582,t:1527030543697};\\\", \\\"{x:1372,y:582,t:1527030543714};\\\", \\\"{x:1380,y:582,t:1527030543730};\\\", \\\"{x:1384,y:582,t:1527030543746};\\\", \\\"{x:1386,y:582,t:1527030543763};\\\", \\\"{x:1387,y:582,t:1527030543782};\\\", \\\"{x:1388,y:581,t:1527030543797};\\\", \\\"{x:1389,y:581,t:1527030543814};\\\", \\\"{x:1390,y:581,t:1527030543830};\\\", \\\"{x:1393,y:581,t:1527030543846};\\\", \\\"{x:1398,y:579,t:1527030543864};\\\", \\\"{x:1400,y:579,t:1527030543879};\\\", \\\"{x:1404,y:578,t:1527030543896};\\\", \\\"{x:1407,y:578,t:1527030543914};\\\", \\\"{x:1409,y:577,t:1527030543930};\\\", \\\"{x:1410,y:577,t:1527030543982};\\\", \\\"{x:1411,y:577,t:1527030544030};\\\", \\\"{x:1413,y:576,t:1527030544046};\\\", \\\"{x:1414,y:575,t:1527030544070};\\\", \\\"{x:1415,y:574,t:1527030544093};\\\", \\\"{x:1416,y:574,t:1527030544110};\\\", \\\"{x:1417,y:574,t:1527030544125};\\\", \\\"{x:1418,y:573,t:1527030544149};\\\", \\\"{x:1419,y:572,t:1527030544166};\\\", \\\"{x:1419,y:573,t:1527030544927};\\\", \\\"{x:1413,y:577,t:1527030544935};\\\", \\\"{x:1404,y:579,t:1527030544947};\\\", \\\"{x:1381,y:583,t:1527030544964};\\\", \\\"{x:1343,y:587,t:1527030544980};\\\", \\\"{x:1287,y:587,t:1527030544997};\\\", \\\"{x:1187,y:587,t:1527030545013};\\\", \\\"{x:1104,y:587,t:1527030545030};\\\", \\\"{x:999,y:587,t:1527030545046};\\\", \\\"{x:902,y:579,t:1527030545064};\\\", \\\"{x:822,y:568,t:1527030545080};\\\", \\\"{x:763,y:561,t:1527030545097};\\\", \\\"{x:705,y:561,t:1527030545119};\\\", \\\"{x:682,y:561,t:1527030545134};\\\", \\\"{x:667,y:562,t:1527030545152};\\\", \\\"{x:659,y:566,t:1527030545170};\\\", \\\"{x:655,y:569,t:1527030545185};\\\", \\\"{x:654,y:573,t:1527030545202};\\\", \\\"{x:651,y:581,t:1527030545219};\\\", \\\"{x:646,y:588,t:1527030545235};\\\", \\\"{x:637,y:596,t:1527030545252};\\\", \\\"{x:625,y:602,t:1527030545269};\\\", \\\"{x:602,y:612,t:1527030545286};\\\", \\\"{x:583,y:619,t:1527030545302};\\\", \\\"{x:562,y:626,t:1527030545319};\\\", \\\"{x:540,y:628,t:1527030545334};\\\", \\\"{x:516,y:628,t:1527030545352};\\\", \\\"{x:489,y:624,t:1527030545369};\\\", \\\"{x:455,y:614,t:1527030545386};\\\", \\\"{x:407,y:598,t:1527030545402};\\\", \\\"{x:366,y:588,t:1527030545419};\\\", \\\"{x:335,y:578,t:1527030545435};\\\", \\\"{x:319,y:576,t:1527030545451};\\\", \\\"{x:317,y:574,t:1527030545469};\\\", \\\"{x:316,y:574,t:1527030545485};\\\", \\\"{x:316,y:573,t:1527030545502};\\\", \\\"{x:319,y:570,t:1527030545518};\\\", \\\"{x:324,y:569,t:1527030545536};\\\", \\\"{x:328,y:566,t:1527030545552};\\\", \\\"{x:331,y:565,t:1527030545568};\\\", \\\"{x:333,y:563,t:1527030545586};\\\", \\\"{x:336,y:561,t:1527030545603};\\\", \\\"{x:338,y:559,t:1527030545618};\\\", \\\"{x:342,y:557,t:1527030545636};\\\", \\\"{x:344,y:555,t:1527030545654};\\\", \\\"{x:349,y:553,t:1527030545668};\\\", \\\"{x:366,y:548,t:1527030545685};\\\", \\\"{x:382,y:547,t:1527030545702};\\\", \\\"{x:404,y:544,t:1527030545719};\\\", \\\"{x:428,y:544,t:1527030545736};\\\", \\\"{x:455,y:544,t:1527030545753};\\\", \\\"{x:484,y:544,t:1527030545768};\\\", \\\"{x:515,y:544,t:1527030545786};\\\", \\\"{x:542,y:544,t:1527030545803};\\\", \\\"{x:563,y:544,t:1527030545819};\\\", \\\"{x:578,y:544,t:1527030545835};\\\", \\\"{x:593,y:544,t:1527030545853};\\\", \\\"{x:603,y:541,t:1527030545869};\\\", \\\"{x:622,y:534,t:1527030545886};\\\", \\\"{x:630,y:527,t:1527030545902};\\\", \\\"{x:633,y:525,t:1527030545918};\\\", \\\"{x:633,y:524,t:1527030545936};\\\", \\\"{x:634,y:523,t:1527030545953};\\\", \\\"{x:634,y:522,t:1527030545998};\\\", \\\"{x:634,y:521,t:1527030546014};\\\", \\\"{x:633,y:520,t:1527030546021};\\\", \\\"{x:632,y:518,t:1527030546036};\\\", \\\"{x:630,y:517,t:1527030546054};\\\", \\\"{x:627,y:515,t:1527030546070};\\\", \\\"{x:625,y:513,t:1527030546086};\\\", \\\"{x:624,y:511,t:1527030546103};\\\", \\\"{x:623,y:506,t:1527030546119};\\\", \\\"{x:620,y:501,t:1527030546135};\\\", \\\"{x:619,y:498,t:1527030546153};\\\", \\\"{x:617,y:495,t:1527030546169};\\\", \\\"{x:614,y:493,t:1527030546186};\\\", \\\"{x:613,y:492,t:1527030546203};\\\", \\\"{x:613,y:491,t:1527030546477};\\\", \\\"{x:618,y:492,t:1527030546486};\\\", \\\"{x:634,y:498,t:1527030546503};\\\", \\\"{x:658,y:509,t:1527030546520};\\\", \\\"{x:691,y:516,t:1527030546537};\\\", \\\"{x:733,y:528,t:1527030546554};\\\", \\\"{x:771,y:534,t:1527030546569};\\\", \\\"{x:795,y:539,t:1527030546586};\\\", \\\"{x:813,y:540,t:1527030546602};\\\", \\\"{x:822,y:540,t:1527030546620};\\\", \\\"{x:825,y:540,t:1527030546637};\\\", \\\"{x:826,y:540,t:1527030546653};\\\", \\\"{x:827,y:540,t:1527030546694};\\\", \\\"{x:828,y:539,t:1527030546718};\\\", \\\"{x:828,y:538,t:1527030546734};\\\", \\\"{x:830,y:537,t:1527030546750};\\\", \\\"{x:831,y:537,t:1527030546831};\\\", \\\"{x:834,y:536,t:1527030546838};\\\", \\\"{x:837,y:536,t:1527030546854};\\\", \\\"{x:842,y:536,t:1527030546869};\\\", \\\"{x:848,y:536,t:1527030546887};\\\", \\\"{x:852,y:536,t:1527030546902};\\\", \\\"{x:854,y:536,t:1527030546920};\\\", \\\"{x:856,y:536,t:1527030547019};\\\", \\\"{x:857,y:536,t:1527030547037};\\\", \\\"{x:857,y:536,t:1527030547090};\\\", \\\"{x:856,y:536,t:1527030547230};\\\", \\\"{x:855,y:537,t:1527030547254};\\\", \\\"{x:853,y:537,t:1527030547294};\\\", \\\"{x:852,y:537,t:1527030547335};\\\", \\\"{x:852,y:538,t:1527030547342};\\\", \\\"{x:850,y:538,t:1527030547354};\\\", \\\"{x:841,y:541,t:1527030547370};\\\", \\\"{x:822,y:547,t:1527030547388};\\\", \\\"{x:794,y:554,t:1527030547404};\\\", \\\"{x:746,y:569,t:1527030547421};\\\", \\\"{x:668,y:593,t:1527030547437};\\\", \\\"{x:534,y:650,t:1527030547454};\\\", \\\"{x:466,y:677,t:1527030547469};\\\", \\\"{x:428,y:694,t:1527030547487};\\\", \\\"{x:416,y:698,t:1527030547503};\\\", \\\"{x:416,y:699,t:1527030547520};\\\", \\\"{x:416,y:700,t:1527030547582};\\\", \\\"{x:416,y:701,t:1527030547597};\\\", \\\"{x:416,y:704,t:1527030547606};\\\", \\\"{x:418,y:705,t:1527030547620};\\\", \\\"{x:421,y:710,t:1527030547637};\\\", \\\"{x:427,y:716,t:1527030547654};\\\", \\\"{x:434,y:719,t:1527030547670};\\\", \\\"{x:439,y:721,t:1527030547687};\\\", \\\"{x:447,y:722,t:1527030547705};\\\", \\\"{x:455,y:722,t:1527030547721};\\\", \\\"{x:467,y:725,t:1527030547737};\\\", \\\"{x:475,y:726,t:1527030547754};\\\", \\\"{x:482,y:727,t:1527030547771};\\\", \\\"{x:487,y:727,t:1527030547787};\\\", \\\"{x:488,y:728,t:1527030547804};\\\", \\\"{x:489,y:728,t:1527030547918};\\\", \\\"{x:489,y:728,t:1527030547981};\\\", \\\"{x:490,y:728,t:1527030548342};\\\", \\\"{x:491,y:728,t:1527030548494};\\\" ] }, { \\\"rt\\\": 32651, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 11, \\\"time_elapsed\\\": 365463, \\\"internal_node_id\\\": \\\"0.0-6.0-1.0\\\", \\\"subject\\\": \\\"Q0QHK\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"juliet\\\", \\\"condition\\\": \\\"115\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"duration+starts\\\", \\\"q\\\": 7, \\\"clicks\\\": 2.5, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XFull-YFull\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 1, \\\"answer\\\": [ \\\"F\\\", \\\"B\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-J -C -F -F -F -F -B -B -M -M -B -B -F -F -F -8\\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:491,y:726,t:1527030549674};\\\", \\\"{x:491,y:725,t:1527030549742};\\\", \\\"{x:492,y:724,t:1527030549774};\\\", \\\"{x:492,y:723,t:1527030555087};\\\", \\\"{x:499,y:723,t:1527030555096};\\\", \\\"{x:526,y:723,t:1527030555112};\\\", \\\"{x:570,y:723,t:1527030555131};\\\", \\\"{x:639,y:733,t:1527030555145};\\\", \\\"{x:709,y:742,t:1527030555162};\\\", \\\"{x:787,y:754,t:1527030555176};\\\", \\\"{x:875,y:764,t:1527030555193};\\\", \\\"{x:970,y:777,t:1527030555210};\\\", \\\"{x:1037,y:788,t:1527030555228};\\\", \\\"{x:1120,y:801,t:1527030555243};\\\", \\\"{x:1176,y:809,t:1527030555261};\\\", \\\"{x:1200,y:811,t:1527030555277};\\\", \\\"{x:1210,y:811,t:1527030555293};\\\", \\\"{x:1211,y:811,t:1527030555310};\\\", \\\"{x:1211,y:812,t:1527030555639};\\\", \\\"{x:1212,y:812,t:1527030555646};\\\", \\\"{x:1210,y:812,t:1527030555782};\\\", \\\"{x:1208,y:810,t:1527030555796};\\\", \\\"{x:1203,y:804,t:1527030555812};\\\", \\\"{x:1191,y:794,t:1527030555827};\\\", \\\"{x:1175,y:785,t:1527030555845};\\\", \\\"{x:1150,y:770,t:1527030555862};\\\", \\\"{x:1114,y:750,t:1527030555878};\\\", \\\"{x:1027,y:711,t:1527030555894};\\\", \\\"{x:952,y:677,t:1527030555912};\\\", \\\"{x:870,y:645,t:1527030555927};\\\", \\\"{x:785,y:612,t:1527030555946};\\\", \\\"{x:713,y:583,t:1527030555962};\\\", \\\"{x:653,y:557,t:1527030555977};\\\", \\\"{x:612,y:541,t:1527030555994};\\\", \\\"{x:583,y:527,t:1527030556010};\\\", \\\"{x:565,y:522,t:1527030556027};\\\", \\\"{x:553,y:517,t:1527030556044};\\\", \\\"{x:551,y:514,t:1527030556060};\\\", \\\"{x:550,y:514,t:1527030556077};\\\", \\\"{x:549,y:514,t:1527030558301};\\\", \\\"{x:548,y:514,t:1527030558312};\\\", \\\"{x:546,y:516,t:1527030558328};\\\", \\\"{x:543,y:518,t:1527030558347};\\\", \\\"{x:541,y:519,t:1527030558362};\\\", \\\"{x:540,y:519,t:1527030558379};\\\", \\\"{x:539,y:521,t:1527030558396};\\\", \\\"{x:536,y:523,t:1527030558412};\\\", \\\"{x:535,y:525,t:1527030558429};\\\", \\\"{x:529,y:528,t:1527030558464};\\\", \\\"{x:528,y:529,t:1527030558479};\\\", \\\"{x:528,y:531,t:1527030558558};\\\", \\\"{x:528,y:533,t:1527030558573};\\\", \\\"{x:528,y:534,t:1527030558581};\\\", \\\"{x:526,y:536,t:1527030558596};\\\", \\\"{x:526,y:538,t:1527030558612};\\\", \\\"{x:526,y:543,t:1527030558629};\\\", \\\"{x:545,y:559,t:1527030558646};\\\", \\\"{x:579,y:578,t:1527030558663};\\\", \\\"{x:651,y:607,t:1527030558681};\\\", \\\"{x:765,y:644,t:1527030558697};\\\", \\\"{x:889,y:678,t:1527030558712};\\\", \\\"{x:1014,y:716,t:1527030558730};\\\", \\\"{x:1141,y:748,t:1527030558747};\\\", \\\"{x:1243,y:774,t:1527030558763};\\\", \\\"{x:1315,y:798,t:1527030558779};\\\", \\\"{x:1361,y:815,t:1527030558796};\\\", \\\"{x:1391,y:827,t:1527030558813};\\\", \\\"{x:1407,y:837,t:1527030558829};\\\", \\\"{x:1418,y:845,t:1527030558846};\\\", \\\"{x:1421,y:848,t:1527030558863};\\\", \\\"{x:1421,y:849,t:1527030558880};\\\", \\\"{x:1422,y:850,t:1527030558896};\\\", \\\"{x:1422,y:851,t:1527030558926};\\\", \\\"{x:1423,y:852,t:1527030558950};\\\", \\\"{x:1423,y:853,t:1527030558974};\\\", \\\"{x:1423,y:854,t:1527030558983};\\\", \\\"{x:1423,y:855,t:1527030558996};\\\", \\\"{x:1423,y:856,t:1527030559013};\\\", \\\"{x:1423,y:857,t:1527030559029};\\\", \\\"{x:1423,y:858,t:1527030559047};\\\", \\\"{x:1423,y:859,t:1527030559078};\\\", \\\"{x:1421,y:858,t:1527030559351};\\\", \\\"{x:1419,y:855,t:1527030559367};\\\", \\\"{x:1419,y:854,t:1527030559381};\\\", \\\"{x:1416,y:851,t:1527030559397};\\\", \\\"{x:1415,y:851,t:1527030559414};\\\", \\\"{x:1414,y:850,t:1527030559431};\\\", \\\"{x:1413,y:850,t:1527030559559};\\\", \\\"{x:1413,y:849,t:1527030559567};\\\", \\\"{x:1412,y:848,t:1527030559581};\\\", \\\"{x:1411,y:847,t:1527030559597};\\\", \\\"{x:1410,y:846,t:1527030559614};\\\", \\\"{x:1409,y:842,t:1527030559631};\\\", \\\"{x:1408,y:841,t:1527030559647};\\\", \\\"{x:1406,y:838,t:1527030559664};\\\", \\\"{x:1406,y:836,t:1527030559681};\\\", \\\"{x:1404,y:835,t:1527030559697};\\\", \\\"{x:1403,y:832,t:1527030559713};\\\", \\\"{x:1401,y:827,t:1527030559731};\\\", \\\"{x:1399,y:824,t:1527030559748};\\\", \\\"{x:1396,y:817,t:1527030559763};\\\", \\\"{x:1393,y:810,t:1527030559781};\\\", \\\"{x:1392,y:804,t:1527030559798};\\\", \\\"{x:1391,y:800,t:1527030559814};\\\", \\\"{x:1388,y:792,t:1527030559830};\\\", \\\"{x:1384,y:783,t:1527030559848};\\\", \\\"{x:1381,y:775,t:1527030559864};\\\", \\\"{x:1378,y:764,t:1527030559881};\\\", \\\"{x:1375,y:751,t:1527030559898};\\\", \\\"{x:1371,y:738,t:1527030559915};\\\", \\\"{x:1368,y:729,t:1527030559931};\\\", \\\"{x:1367,y:723,t:1527030559948};\\\", \\\"{x:1365,y:714,t:1527030559964};\\\", \\\"{x:1365,y:706,t:1527030559981};\\\", \\\"{x:1365,y:701,t:1527030559998};\\\", \\\"{x:1375,y:675,t:1527030560015};\\\", \\\"{x:1381,y:665,t:1527030560030};\\\", \\\"{x:1386,y:659,t:1527030560047};\\\", \\\"{x:1395,y:653,t:1527030560064};\\\", \\\"{x:1404,y:648,t:1527030560080};\\\", \\\"{x:1411,y:645,t:1527030560097};\\\", \\\"{x:1417,y:643,t:1527030560114};\\\", \\\"{x:1425,y:641,t:1527030560131};\\\", \\\"{x:1434,y:638,t:1527030560147};\\\", \\\"{x:1442,y:635,t:1527030560165};\\\", \\\"{x:1446,y:634,t:1527030560182};\\\", \\\"{x:1450,y:633,t:1527030560198};\\\", \\\"{x:1452,y:633,t:1527030560214};\\\", \\\"{x:1449,y:633,t:1527030564719};\\\", \\\"{x:1440,y:636,t:1527030564736};\\\", \\\"{x:1435,y:638,t:1527030564752};\\\", \\\"{x:1428,y:640,t:1527030564768};\\\", \\\"{x:1426,y:642,t:1527030564785};\\\", \\\"{x:1425,y:642,t:1527030564802};\\\", \\\"{x:1424,y:643,t:1527030564819};\\\", \\\"{x:1422,y:645,t:1527030564835};\\\", \\\"{x:1421,y:646,t:1527030564852};\\\", \\\"{x:1418,y:647,t:1527030564869};\\\", \\\"{x:1416,y:647,t:1527030564885};\\\", \\\"{x:1411,y:651,t:1527030564903};\\\", \\\"{x:1408,y:653,t:1527030564919};\\\", \\\"{x:1404,y:656,t:1527030564935};\\\", \\\"{x:1402,y:659,t:1527030564952};\\\", \\\"{x:1400,y:662,t:1527030564969};\\\", \\\"{x:1398,y:665,t:1527030564986};\\\", \\\"{x:1394,y:671,t:1527030565002};\\\", \\\"{x:1390,y:675,t:1527030565019};\\\", \\\"{x:1387,y:680,t:1527030565035};\\\", \\\"{x:1385,y:683,t:1527030565053};\\\", \\\"{x:1383,y:688,t:1527030565070};\\\", \\\"{x:1381,y:692,t:1527030565086};\\\", \\\"{x:1377,y:699,t:1527030565102};\\\", \\\"{x:1376,y:702,t:1527030565118};\\\", \\\"{x:1374,y:707,t:1527030565135};\\\", \\\"{x:1373,y:710,t:1527030565152};\\\", \\\"{x:1372,y:713,t:1527030565169};\\\", \\\"{x:1370,y:716,t:1527030565185};\\\", \\\"{x:1370,y:717,t:1527030565202};\\\", \\\"{x:1368,y:720,t:1527030565219};\\\", \\\"{x:1366,y:722,t:1527030565235};\\\", \\\"{x:1366,y:724,t:1527030565252};\\\", \\\"{x:1364,y:725,t:1527030565269};\\\", \\\"{x:1363,y:727,t:1527030565286};\\\", \\\"{x:1362,y:727,t:1527030565302};\\\", \\\"{x:1360,y:727,t:1527030565414};\\\", \\\"{x:1358,y:726,t:1527030565422};\\\", \\\"{x:1356,y:725,t:1527030565437};\\\", \\\"{x:1352,y:722,t:1527030565452};\\\", \\\"{x:1350,y:718,t:1527030565470};\\\", \\\"{x:1347,y:715,t:1527030565486};\\\", \\\"{x:1346,y:713,t:1527030565502};\\\", \\\"{x:1346,y:712,t:1527030565519};\\\", \\\"{x:1346,y:710,t:1527030565536};\\\", \\\"{x:1345,y:709,t:1527030565552};\\\", \\\"{x:1345,y:707,t:1527030565569};\\\", \\\"{x:1344,y:706,t:1527030565587};\\\", \\\"{x:1344,y:703,t:1527030565602};\\\", \\\"{x:1343,y:702,t:1527030565619};\\\", \\\"{x:1342,y:700,t:1527030565636};\\\", \\\"{x:1342,y:699,t:1527030565653};\\\", \\\"{x:1342,y:698,t:1527030565670};\\\", \\\"{x:1341,y:696,t:1527030565687};\\\", \\\"{x:1341,y:699,t:1527030565815};\\\", \\\"{x:1341,y:705,t:1527030565823};\\\", \\\"{x:1341,y:713,t:1527030565836};\\\", \\\"{x:1341,y:731,t:1527030565854};\\\", \\\"{x:1341,y:747,t:1527030565869};\\\", \\\"{x:1345,y:770,t:1527030565886};\\\", \\\"{x:1349,y:782,t:1527030565903};\\\", \\\"{x:1351,y:788,t:1527030565919};\\\", \\\"{x:1352,y:792,t:1527030565936};\\\", \\\"{x:1352,y:793,t:1527030565953};\\\", \\\"{x:1353,y:788,t:1527030566079};\\\", \\\"{x:1355,y:782,t:1527030566086};\\\", \\\"{x:1360,y:764,t:1527030566103};\\\", \\\"{x:1365,y:745,t:1527030566120};\\\", \\\"{x:1372,y:724,t:1527030566136};\\\", \\\"{x:1376,y:707,t:1527030566153};\\\", \\\"{x:1378,y:691,t:1527030566170};\\\", \\\"{x:1381,y:672,t:1527030566186};\\\", \\\"{x:1382,y:656,t:1527030566203};\\\", \\\"{x:1386,y:639,t:1527030566220};\\\", \\\"{x:1386,y:629,t:1527030566236};\\\", \\\"{x:1387,y:617,t:1527030566254};\\\", \\\"{x:1387,y:610,t:1527030566270};\\\", \\\"{x:1387,y:606,t:1527030566286};\\\", \\\"{x:1387,y:601,t:1527030566303};\\\", \\\"{x:1387,y:598,t:1527030566319};\\\", \\\"{x:1387,y:595,t:1527030566335};\\\", \\\"{x:1387,y:592,t:1527030566353};\\\", \\\"{x:1386,y:588,t:1527030566369};\\\", \\\"{x:1386,y:586,t:1527030566385};\\\", \\\"{x:1386,y:584,t:1527030566402};\\\", \\\"{x:1386,y:582,t:1527030566420};\\\", \\\"{x:1386,y:580,t:1527030566436};\\\", \\\"{x:1386,y:579,t:1527030566453};\\\", \\\"{x:1387,y:576,t:1527030566470};\\\", \\\"{x:1388,y:574,t:1527030566485};\\\", \\\"{x:1389,y:574,t:1527030566503};\\\", \\\"{x:1390,y:573,t:1527030566520};\\\", \\\"{x:1391,y:572,t:1527030566542};\\\", \\\"{x:1392,y:571,t:1527030566558};\\\", \\\"{x:1393,y:571,t:1527030567031};\\\", \\\"{x:1393,y:573,t:1527030567038};\\\", \\\"{x:1393,y:580,t:1527030567055};\\\", \\\"{x:1394,y:585,t:1527030567070};\\\", \\\"{x:1395,y:588,t:1527030567087};\\\", \\\"{x:1396,y:592,t:1527030567104};\\\", \\\"{x:1396,y:595,t:1527030567119};\\\", \\\"{x:1399,y:600,t:1527030567137};\\\", \\\"{x:1401,y:604,t:1527030567154};\\\", \\\"{x:1402,y:606,t:1527030567170};\\\", \\\"{x:1403,y:607,t:1527030567186};\\\", \\\"{x:1403,y:608,t:1527030567254};\\\", \\\"{x:1404,y:609,t:1527030567270};\\\", \\\"{x:1405,y:611,t:1527030567287};\\\", \\\"{x:1408,y:612,t:1527030567304};\\\", \\\"{x:1410,y:614,t:1527030567320};\\\", \\\"{x:1415,y:617,t:1527030567337};\\\", \\\"{x:1419,y:619,t:1527030567354};\\\", \\\"{x:1423,y:621,t:1527030567371};\\\", \\\"{x:1426,y:624,t:1527030567387};\\\", \\\"{x:1429,y:626,t:1527030567405};\\\", \\\"{x:1433,y:628,t:1527030567421};\\\", \\\"{x:1434,y:629,t:1527030567438};\\\", \\\"{x:1434,y:631,t:1527030567608};\\\", \\\"{x:1433,y:631,t:1527030567621};\\\", \\\"{x:1429,y:631,t:1527030567637};\\\", \\\"{x:1423,y:632,t:1527030567654};\\\", \\\"{x:1419,y:632,t:1527030567671};\\\", \\\"{x:1415,y:632,t:1527030567687};\\\", \\\"{x:1409,y:632,t:1527030567704};\\\", \\\"{x:1406,y:632,t:1527030567721};\\\", \\\"{x:1401,y:632,t:1527030567737};\\\", \\\"{x:1397,y:632,t:1527030567754};\\\", \\\"{x:1396,y:632,t:1527030567771};\\\", \\\"{x:1394,y:632,t:1527030567789};\\\", \\\"{x:1393,y:632,t:1527030567806};\\\", \\\"{x:1391,y:632,t:1527030567821};\\\", \\\"{x:1388,y:633,t:1527030567838};\\\", \\\"{x:1384,y:633,t:1527030567855};\\\", \\\"{x:1383,y:634,t:1527030567872};\\\", \\\"{x:1380,y:635,t:1527030567889};\\\", \\\"{x:1376,y:635,t:1527030567904};\\\", \\\"{x:1373,y:636,t:1527030567921};\\\", \\\"{x:1370,y:636,t:1527030567938};\\\", \\\"{x:1369,y:636,t:1527030567954};\\\", \\\"{x:1367,y:637,t:1527030568319};\\\", \\\"{x:1367,y:638,t:1527030568326};\\\", \\\"{x:1365,y:640,t:1527030568338};\\\", \\\"{x:1361,y:643,t:1527030568355};\\\", \\\"{x:1358,y:647,t:1527030568372};\\\", \\\"{x:1357,y:650,t:1527030568388};\\\", \\\"{x:1355,y:652,t:1527030568405};\\\", \\\"{x:1354,y:653,t:1527030568421};\\\", \\\"{x:1352,y:656,t:1527030568439};\\\", \\\"{x:1351,y:660,t:1527030568455};\\\", \\\"{x:1349,y:665,t:1527030568472};\\\", \\\"{x:1349,y:671,t:1527030568488};\\\", \\\"{x:1349,y:677,t:1527030568505};\\\", \\\"{x:1349,y:680,t:1527030568521};\\\", \\\"{x:1349,y:683,t:1527030568538};\\\", \\\"{x:1349,y:686,t:1527030568555};\\\", \\\"{x:1350,y:693,t:1527030568571};\\\", \\\"{x:1352,y:697,t:1527030568588};\\\", \\\"{x:1353,y:700,t:1527030568606};\\\", \\\"{x:1354,y:705,t:1527030568622};\\\", \\\"{x:1354,y:706,t:1527030568638};\\\", \\\"{x:1354,y:708,t:1527030568655};\\\", \\\"{x:1354,y:709,t:1527030568672};\\\", \\\"{x:1355,y:711,t:1527030568688};\\\", \\\"{x:1355,y:713,t:1527030568706};\\\", \\\"{x:1355,y:715,t:1527030568722};\\\", \\\"{x:1355,y:716,t:1527030568738};\\\", \\\"{x:1356,y:718,t:1527030568755};\\\", \\\"{x:1356,y:722,t:1527030568773};\\\", \\\"{x:1356,y:725,t:1527030568788};\\\", \\\"{x:1357,y:729,t:1527030568806};\\\", \\\"{x:1358,y:737,t:1527030568823};\\\", \\\"{x:1358,y:743,t:1527030568839};\\\", \\\"{x:1359,y:749,t:1527030568855};\\\", \\\"{x:1360,y:751,t:1527030568872};\\\", \\\"{x:1360,y:755,t:1527030568888};\\\", \\\"{x:1360,y:757,t:1527030568905};\\\", \\\"{x:1360,y:759,t:1527030568922};\\\", \\\"{x:1360,y:762,t:1527030568939};\\\", \\\"{x:1360,y:765,t:1527030568955};\\\", \\\"{x:1360,y:766,t:1527030568972};\\\", \\\"{x:1360,y:765,t:1527030569174};\\\", \\\"{x:1360,y:760,t:1527030569189};\\\", \\\"{x:1357,y:748,t:1527030569205};\\\", \\\"{x:1351,y:732,t:1527030569222};\\\", \\\"{x:1346,y:721,t:1527030569239};\\\", \\\"{x:1344,y:716,t:1527030569254};\\\", \\\"{x:1342,y:712,t:1527030569272};\\\", \\\"{x:1341,y:710,t:1527030569289};\\\", \\\"{x:1341,y:708,t:1527030569305};\\\", \\\"{x:1340,y:707,t:1527030569334};\\\", \\\"{x:1340,y:706,t:1527030569350};\\\", \\\"{x:1340,y:705,t:1527030569366};\\\", \\\"{x:1340,y:704,t:1527030569390};\\\", \\\"{x:1340,y:703,t:1527030569406};\\\", \\\"{x:1340,y:702,t:1527030569423};\\\", \\\"{x:1340,y:701,t:1527030569439};\\\", \\\"{x:1340,y:699,t:1527030569456};\\\", \\\"{x:1340,y:698,t:1527030569478};\\\", \\\"{x:1340,y:697,t:1527030569489};\\\", \\\"{x:1340,y:695,t:1527030569506};\\\", \\\"{x:1340,y:693,t:1527030569521};\\\", \\\"{x:1340,y:691,t:1527030569539};\\\", \\\"{x:1340,y:690,t:1527030569555};\\\", \\\"{x:1340,y:689,t:1527030569646};\\\", \\\"{x:1341,y:689,t:1527030569656};\\\", \\\"{x:1342,y:694,t:1527030569671};\\\", \\\"{x:1343,y:700,t:1527030569689};\\\", \\\"{x:1345,y:707,t:1527030569707};\\\", \\\"{x:1346,y:714,t:1527030569722};\\\", \\\"{x:1346,y:720,t:1527030569739};\\\", \\\"{x:1346,y:727,t:1527030569756};\\\", \\\"{x:1347,y:733,t:1527030569772};\\\", \\\"{x:1347,y:736,t:1527030569789};\\\", \\\"{x:1349,y:742,t:1527030569806};\\\", \\\"{x:1349,y:744,t:1527030569822};\\\", \\\"{x:1349,y:747,t:1527030569839};\\\", \\\"{x:1350,y:749,t:1527030569856};\\\", \\\"{x:1350,y:751,t:1527030569873};\\\", \\\"{x:1350,y:754,t:1527030569890};\\\", \\\"{x:1351,y:758,t:1527030569907};\\\", \\\"{x:1352,y:762,t:1527030569923};\\\", \\\"{x:1352,y:765,t:1527030569939};\\\", \\\"{x:1354,y:771,t:1527030569957};\\\", \\\"{x:1356,y:778,t:1527030569973};\\\", \\\"{x:1358,y:785,t:1527030569990};\\\", \\\"{x:1362,y:799,t:1527030570006};\\\", \\\"{x:1366,y:811,t:1527030570023};\\\", \\\"{x:1369,y:822,t:1527030570039};\\\", \\\"{x:1371,y:832,t:1527030570056};\\\", \\\"{x:1372,y:838,t:1527030570074};\\\", \\\"{x:1375,y:843,t:1527030570089};\\\", \\\"{x:1376,y:846,t:1527030570106};\\\", \\\"{x:1377,y:850,t:1527030570123};\\\", \\\"{x:1378,y:854,t:1527030570139};\\\", \\\"{x:1379,y:858,t:1527030570156};\\\", \\\"{x:1379,y:862,t:1527030570173};\\\", \\\"{x:1380,y:870,t:1527030570190};\\\", \\\"{x:1380,y:873,t:1527030570206};\\\", \\\"{x:1382,y:879,t:1527030570225};\\\", \\\"{x:1383,y:883,t:1527030570239};\\\", \\\"{x:1383,y:888,t:1527030570256};\\\", \\\"{x:1384,y:891,t:1527030570272};\\\", \\\"{x:1386,y:896,t:1527030570290};\\\", \\\"{x:1386,y:898,t:1527030570306};\\\", \\\"{x:1386,y:900,t:1527030570323};\\\", \\\"{x:1387,y:902,t:1527030570339};\\\", \\\"{x:1387,y:905,t:1527030570355};\\\", \\\"{x:1388,y:908,t:1527030570373};\\\", \\\"{x:1390,y:913,t:1527030570389};\\\", \\\"{x:1390,y:915,t:1527030570406};\\\", \\\"{x:1390,y:918,t:1527030570423};\\\", \\\"{x:1391,y:919,t:1527030570440};\\\", \\\"{x:1391,y:921,t:1527030570456};\\\", \\\"{x:1391,y:920,t:1527030570654};\\\", \\\"{x:1391,y:918,t:1527030570661};\\\", \\\"{x:1391,y:916,t:1527030570673};\\\", \\\"{x:1390,y:912,t:1527030570690};\\\", \\\"{x:1390,y:908,t:1527030570706};\\\", \\\"{x:1390,y:903,t:1527030570723};\\\", \\\"{x:1389,y:897,t:1527030570739};\\\", \\\"{x:1388,y:887,t:1527030570757};\\\", \\\"{x:1386,y:876,t:1527030570773};\\\", \\\"{x:1384,y:858,t:1527030570790};\\\", \\\"{x:1381,y:848,t:1527030570807};\\\", \\\"{x:1379,y:839,t:1527030570823};\\\", \\\"{x:1378,y:826,t:1527030570840};\\\", \\\"{x:1374,y:813,t:1527030570857};\\\", \\\"{x:1370,y:801,t:1527030570873};\\\", \\\"{x:1366,y:789,t:1527030570890};\\\", \\\"{x:1360,y:777,t:1527030570907};\\\", \\\"{x:1356,y:770,t:1527030570923};\\\", \\\"{x:1353,y:764,t:1527030570941};\\\", \\\"{x:1352,y:760,t:1527030570957};\\\", \\\"{x:1351,y:757,t:1527030570974};\\\", \\\"{x:1349,y:749,t:1527030570990};\\\", \\\"{x:1348,y:745,t:1527030571007};\\\", \\\"{x:1348,y:737,t:1527030571023};\\\", \\\"{x:1347,y:728,t:1527030571039};\\\", \\\"{x:1345,y:716,t:1527030571057};\\\", \\\"{x:1344,y:708,t:1527030571074};\\\", \\\"{x:1344,y:702,t:1527030571090};\\\", \\\"{x:1344,y:698,t:1527030571107};\\\", \\\"{x:1344,y:696,t:1527030571124};\\\", \\\"{x:1344,y:694,t:1527030571140};\\\", \\\"{x:1344,y:692,t:1527030571157};\\\", \\\"{x:1344,y:687,t:1527030571174};\\\", \\\"{x:1345,y:682,t:1527030571190};\\\", \\\"{x:1349,y:677,t:1527030571207};\\\", \\\"{x:1349,y:679,t:1527030571319};\\\", \\\"{x:1351,y:682,t:1527030571326};\\\", \\\"{x:1351,y:683,t:1527030571340};\\\", \\\"{x:1352,y:689,t:1527030571356};\\\", \\\"{x:1352,y:701,t:1527030571373};\\\", \\\"{x:1353,y:710,t:1527030571391};\\\", \\\"{x:1355,y:718,t:1527030571407};\\\", \\\"{x:1355,y:726,t:1527030571424};\\\", \\\"{x:1355,y:734,t:1527030571441};\\\", \\\"{x:1355,y:743,t:1527030571457};\\\", \\\"{x:1355,y:751,t:1527030571474};\\\", \\\"{x:1355,y:758,t:1527030571491};\\\", \\\"{x:1355,y:763,t:1527030571507};\\\", \\\"{x:1355,y:766,t:1527030571524};\\\", \\\"{x:1355,y:770,t:1527030571541};\\\", \\\"{x:1355,y:774,t:1527030571557};\\\", \\\"{x:1354,y:776,t:1527030571575};\\\", \\\"{x:1353,y:777,t:1527030571591};\\\", \\\"{x:1352,y:778,t:1527030571607};\\\", \\\"{x:1345,y:778,t:1527030571624};\\\", \\\"{x:1329,y:781,t:1527030571641};\\\", \\\"{x:1302,y:781,t:1527030571658};\\\", \\\"{x:1251,y:781,t:1527030571674};\\\", \\\"{x:1176,y:781,t:1527030571691};\\\", \\\"{x:1097,y:776,t:1527030571707};\\\", \\\"{x:1026,y:771,t:1527030571724};\\\", \\\"{x:984,y:765,t:1527030571741};\\\", \\\"{x:962,y:765,t:1527030571758};\\\", \\\"{x:953,y:765,t:1527030571774};\\\", \\\"{x:952,y:765,t:1527030571806};\\\", \\\"{x:950,y:765,t:1527030571862};\\\", \\\"{x:947,y:764,t:1527030571874};\\\", \\\"{x:933,y:760,t:1527030571892};\\\", \\\"{x:913,y:754,t:1527030571908};\\\", \\\"{x:878,y:745,t:1527030571924};\\\", \\\"{x:825,y:729,t:1527030571942};\\\", \\\"{x:720,y:703,t:1527030571958};\\\", \\\"{x:637,y:678,t:1527030571974};\\\", \\\"{x:559,y:656,t:1527030571991};\\\", \\\"{x:479,y:633,t:1527030572008};\\\", \\\"{x:416,y:621,t:1527030572024};\\\", \\\"{x:374,y:614,t:1527030572040};\\\", \\\"{x:352,y:614,t:1527030572058};\\\", \\\"{x:340,y:614,t:1527030572072};\\\", \\\"{x:334,y:615,t:1527030572088};\\\", \\\"{x:332,y:615,t:1527030572105};\\\", \\\"{x:332,y:618,t:1527030572122};\\\", \\\"{x:332,y:620,t:1527030572138};\\\", \\\"{x:334,y:625,t:1527030572154};\\\", \\\"{x:336,y:631,t:1527030572172};\\\", \\\"{x:337,y:636,t:1527030572190};\\\", \\\"{x:337,y:640,t:1527030572205};\\\", \\\"{x:337,y:641,t:1527030572238};\\\", \\\"{x:336,y:641,t:1527030572253};\\\", \\\"{x:333,y:641,t:1527030572262};\\\", \\\"{x:329,y:641,t:1527030572274};\\\", \\\"{x:314,y:638,t:1527030572291};\\\", \\\"{x:296,y:633,t:1527030572307};\\\", \\\"{x:280,y:632,t:1527030572324};\\\", \\\"{x:266,y:629,t:1527030572341};\\\", \\\"{x:259,y:627,t:1527030572357};\\\", \\\"{x:258,y:626,t:1527030572374};\\\", \\\"{x:261,y:625,t:1527030572391};\\\", \\\"{x:280,y:625,t:1527030572407};\\\", \\\"{x:306,y:625,t:1527030572424};\\\", \\\"{x:334,y:625,t:1527030572441};\\\", \\\"{x:357,y:625,t:1527030572457};\\\", \\\"{x:370,y:623,t:1527030572474};\\\", \\\"{x:376,y:622,t:1527030572493};\\\", \\\"{x:376,y:621,t:1527030572509};\\\", \\\"{x:376,y:618,t:1527030572524};\\\", \\\"{x:372,y:609,t:1527030572541};\\\", \\\"{x:368,y:604,t:1527030572557};\\\", \\\"{x:365,y:601,t:1527030572574};\\\", \\\"{x:365,y:600,t:1527030572591};\\\", \\\"{x:364,y:599,t:1527030572608};\\\", \\\"{x:363,y:597,t:1527030572624};\\\", \\\"{x:361,y:597,t:1527030572645};\\\", \\\"{x:360,y:595,t:1527030572661};\\\", \\\"{x:358,y:595,t:1527030572674};\\\", \\\"{x:355,y:595,t:1527030572691};\\\", \\\"{x:349,y:595,t:1527030572707};\\\", \\\"{x:343,y:595,t:1527030572724};\\\", \\\"{x:337,y:595,t:1527030572741};\\\", \\\"{x:331,y:595,t:1527030572757};\\\", \\\"{x:323,y:599,t:1527030572773};\\\", \\\"{x:319,y:604,t:1527030572792};\\\", \\\"{x:317,y:608,t:1527030572807};\\\", \\\"{x:314,y:614,t:1527030572824};\\\", \\\"{x:314,y:619,t:1527030572841};\\\", \\\"{x:313,y:623,t:1527030572857};\\\", \\\"{x:313,y:626,t:1527030572875};\\\", \\\"{x:313,y:629,t:1527030572891};\\\", \\\"{x:313,y:631,t:1527030572908};\\\", \\\"{x:313,y:633,t:1527030572925};\\\", \\\"{x:314,y:634,t:1527030572940};\\\", \\\"{x:314,y:635,t:1527030572958};\\\", \\\"{x:315,y:635,t:1527030572989};\\\", \\\"{x:316,y:635,t:1527030573006};\\\", \\\"{x:317,y:635,t:1527030573021};\\\", \\\"{x:319,y:634,t:1527030573029};\\\", \\\"{x:320,y:633,t:1527030573045};\\\", \\\"{x:322,y:630,t:1527030573058};\\\", \\\"{x:323,y:627,t:1527030573074};\\\", \\\"{x:325,y:623,t:1527030573091};\\\", \\\"{x:328,y:615,t:1527030573108};\\\", \\\"{x:333,y:605,t:1527030573124};\\\", \\\"{x:338,y:593,t:1527030573143};\\\", \\\"{x:348,y:574,t:1527030573157};\\\", \\\"{x:353,y:566,t:1527030573174};\\\", \\\"{x:354,y:556,t:1527030573191};\\\", \\\"{x:357,y:547,t:1527030573209};\\\", \\\"{x:358,y:541,t:1527030573225};\\\", \\\"{x:360,y:535,t:1527030573241};\\\", \\\"{x:361,y:532,t:1527030573258};\\\", \\\"{x:363,y:529,t:1527030573275};\\\", \\\"{x:365,y:525,t:1527030573291};\\\", \\\"{x:369,y:523,t:1527030573309};\\\", \\\"{x:372,y:521,t:1527030573325};\\\", \\\"{x:385,y:516,t:1527030573342};\\\", \\\"{x:394,y:512,t:1527030573358};\\\", \\\"{x:402,y:510,t:1527030573375};\\\", \\\"{x:413,y:508,t:1527030573390};\\\", \\\"{x:427,y:507,t:1527030573408};\\\", \\\"{x:443,y:504,t:1527030573425};\\\", \\\"{x:464,y:501,t:1527030573441};\\\", \\\"{x:485,y:497,t:1527030573457};\\\", \\\"{x:507,y:494,t:1527030573475};\\\", \\\"{x:530,y:493,t:1527030573491};\\\", \\\"{x:556,y:490,t:1527030573508};\\\", \\\"{x:581,y:488,t:1527030573524};\\\", \\\"{x:606,y:485,t:1527030573541};\\\", \\\"{x:640,y:480,t:1527030573557};\\\", \\\"{x:659,y:479,t:1527030573575};\\\", \\\"{x:676,y:479,t:1527030573591};\\\", \\\"{x:696,y:477,t:1527030573607};\\\", \\\"{x:711,y:477,t:1527030573625};\\\", \\\"{x:728,y:477,t:1527030573642};\\\", \\\"{x:747,y:478,t:1527030573658};\\\", \\\"{x:765,y:481,t:1527030573675};\\\", \\\"{x:786,y:485,t:1527030573692};\\\", \\\"{x:802,y:489,t:1527030573710};\\\", \\\"{x:816,y:494,t:1527030573725};\\\", \\\"{x:824,y:497,t:1527030573741};\\\", \\\"{x:826,y:499,t:1527030573759};\\\", \\\"{x:826,y:503,t:1527030573775};\\\", \\\"{x:828,y:509,t:1527030573792};\\\", \\\"{x:828,y:520,t:1527030573809};\\\", \\\"{x:828,y:530,t:1527030573825};\\\", \\\"{x:828,y:540,t:1527030573842};\\\", \\\"{x:828,y:552,t:1527030573858};\\\", \\\"{x:828,y:562,t:1527030573875};\\\", \\\"{x:830,y:569,t:1527030573893};\\\", \\\"{x:832,y:577,t:1527030573908};\\\", \\\"{x:834,y:582,t:1527030573925};\\\", \\\"{x:834,y:585,t:1527030573941};\\\", \\\"{x:835,y:586,t:1527030573958};\\\", \\\"{x:836,y:586,t:1527030573974};\\\", \\\"{x:836,y:587,t:1527030573997};\\\", \\\"{x:836,y:589,t:1527030574013};\\\", \\\"{x:837,y:591,t:1527030574029};\\\", \\\"{x:837,y:592,t:1527030574042};\\\", \\\"{x:837,y:596,t:1527030574059};\\\", \\\"{x:837,y:600,t:1527030574075};\\\", \\\"{x:837,y:606,t:1527030574092};\\\", \\\"{x:834,y:612,t:1527030574109};\\\", \\\"{x:829,y:618,t:1527030574125};\\\", \\\"{x:816,y:630,t:1527030574142};\\\", \\\"{x:800,y:636,t:1527030574160};\\\", \\\"{x:780,y:642,t:1527030574175};\\\", \\\"{x:757,y:647,t:1527030574192};\\\", \\\"{x:729,y:653,t:1527030574209};\\\", \\\"{x:705,y:653,t:1527030574225};\\\", \\\"{x:678,y:653,t:1527030574241};\\\", \\\"{x:649,y:653,t:1527030574259};\\\", \\\"{x:626,y:653,t:1527030574275};\\\", \\\"{x:600,y:653,t:1527030574292};\\\", \\\"{x:577,y:653,t:1527030574309};\\\", \\\"{x:562,y:653,t:1527030574325};\\\", \\\"{x:545,y:657,t:1527030574342};\\\", \\\"{x:538,y:660,t:1527030574359};\\\", \\\"{x:533,y:663,t:1527030574375};\\\", \\\"{x:526,y:666,t:1527030574392};\\\", \\\"{x:516,y:671,t:1527030574409};\\\", \\\"{x:507,y:674,t:1527030574425};\\\", \\\"{x:496,y:675,t:1527030574442};\\\", \\\"{x:485,y:675,t:1527030574459};\\\", \\\"{x:468,y:675,t:1527030574476};\\\", \\\"{x:446,y:674,t:1527030574492};\\\", \\\"{x:409,y:666,t:1527030574510};\\\", \\\"{x:318,y:641,t:1527030574525};\\\", \\\"{x:243,y:621,t:1527030574543};\\\", \\\"{x:182,y:612,t:1527030574559};\\\", \\\"{x:142,y:612,t:1527030574576};\\\", \\\"{x:115,y:611,t:1527030574592};\\\", \\\"{x:98,y:611,t:1527030574609};\\\", \\\"{x:92,y:611,t:1527030574626};\\\", \\\"{x:91,y:611,t:1527030574641};\\\", \\\"{x:91,y:612,t:1527030574659};\\\", \\\"{x:91,y:615,t:1527030574676};\\\", \\\"{x:91,y:618,t:1527030574692};\\\", \\\"{x:91,y:620,t:1527030574708};\\\", \\\"{x:91,y:622,t:1527030574726};\\\", \\\"{x:91,y:624,t:1527030574742};\\\", \\\"{x:91,y:625,t:1527030574759};\\\", \\\"{x:93,y:628,t:1527030574776};\\\", \\\"{x:98,y:629,t:1527030574792};\\\", \\\"{x:107,y:631,t:1527030574809};\\\", \\\"{x:116,y:631,t:1527030574825};\\\", \\\"{x:124,y:631,t:1527030574841};\\\", \\\"{x:131,y:631,t:1527030574859};\\\", \\\"{x:135,y:628,t:1527030574876};\\\", \\\"{x:137,y:621,t:1527030574892};\\\", \\\"{x:137,y:607,t:1527030574909};\\\", \\\"{x:136,y:592,t:1527030574926};\\\", \\\"{x:133,y:584,t:1527030574942};\\\", \\\"{x:129,y:579,t:1527030574959};\\\", \\\"{x:127,y:575,t:1527030574975};\\\", \\\"{x:127,y:570,t:1527030574992};\\\", \\\"{x:127,y:563,t:1527030575009};\\\", \\\"{x:127,y:554,t:1527030575026};\\\", \\\"{x:127,y:549,t:1527030575042};\\\", \\\"{x:128,y:547,t:1527030575058};\\\", \\\"{x:129,y:546,t:1527030575076};\\\", \\\"{x:130,y:544,t:1527030575092};\\\", \\\"{x:133,y:544,t:1527030575109};\\\", \\\"{x:135,y:542,t:1527030575126};\\\", \\\"{x:138,y:541,t:1527030575143};\\\", \\\"{x:140,y:541,t:1527030575159};\\\", \\\"{x:141,y:541,t:1527030575182};\\\", \\\"{x:142,y:539,t:1527030575193};\\\", \\\"{x:143,y:539,t:1527030575210};\\\", \\\"{x:144,y:539,t:1527030575230};\\\", \\\"{x:146,y:539,t:1527030575687};\\\", \\\"{x:148,y:539,t:1527030575694};\\\", \\\"{x:155,y:539,t:1527030575711};\\\", \\\"{x:169,y:539,t:1527030575726};\\\", \\\"{x:178,y:539,t:1527030575743};\\\", \\\"{x:186,y:539,t:1527030575760};\\\", \\\"{x:190,y:539,t:1527030575775};\\\", \\\"{x:192,y:539,t:1527030575793};\\\", \\\"{x:194,y:539,t:1527030575918};\\\", \\\"{x:196,y:539,t:1527030575927};\\\", \\\"{x:205,y:539,t:1527030575943};\\\", \\\"{x:220,y:539,t:1527030575960};\\\", \\\"{x:239,y:539,t:1527030575977};\\\", \\\"{x:257,y:540,t:1527030575993};\\\", \\\"{x:272,y:542,t:1527030576010};\\\", \\\"{x:278,y:543,t:1527030576029};\\\", \\\"{x:279,y:543,t:1527030576047};\\\", \\\"{x:279,y:544,t:1527030576138};\\\", \\\"{x:278,y:545,t:1527030576146};\\\", \\\"{x:273,y:545,t:1527030576164};\\\", \\\"{x:268,y:545,t:1527030576182};\\\", \\\"{x:264,y:545,t:1527030576197};\\\", \\\"{x:268,y:545,t:1527030576241};\\\", \\\"{x:283,y:545,t:1527030576251};\\\", \\\"{x:305,y:545,t:1527030576264};\\\", \\\"{x:378,y:545,t:1527030576282};\\\", \\\"{x:525,y:545,t:1527030576298};\\\", \\\"{x:619,y:545,t:1527030576314};\\\", \\\"{x:680,y:538,t:1527030576332};\\\", \\\"{x:689,y:537,t:1527030576348};\\\", \\\"{x:684,y:537,t:1527030576369};\\\", \\\"{x:670,y:537,t:1527030576381};\\\", \\\"{x:618,y:537,t:1527030576399};\\\", \\\"{x:535,y:537,t:1527030576415};\\\", \\\"{x:441,y:537,t:1527030576431};\\\", \\\"{x:346,y:537,t:1527030576448};\\\", \\\"{x:274,y:537,t:1527030576464};\\\", \\\"{x:224,y:537,t:1527030576481};\\\", \\\"{x:187,y:534,t:1527030576497};\\\", \\\"{x:173,y:533,t:1527030576513};\\\", \\\"{x:167,y:531,t:1527030576531};\\\", \\\"{x:164,y:530,t:1527030576549};\\\", \\\"{x:161,y:529,t:1527030576565};\\\", \\\"{x:157,y:529,t:1527030576581};\\\", \\\"{x:153,y:529,t:1527030576598};\\\", \\\"{x:151,y:529,t:1527030576615};\\\", \\\"{x:153,y:530,t:1527030576706};\\\", \\\"{x:154,y:531,t:1527030576715};\\\", \\\"{x:157,y:531,t:1527030576731};\\\", \\\"{x:161,y:532,t:1527030576748};\\\", \\\"{x:161,y:533,t:1527030576765};\\\", \\\"{x:162,y:533,t:1527030576843};\\\", \\\"{x:163,y:533,t:1527030576866};\\\", \\\"{x:163,y:533,t:1527030576937};\\\", \\\"{x:164,y:533,t:1527030576969};\\\", \\\"{x:166,y:532,t:1527030576981};\\\", \\\"{x:169,y:530,t:1527030576998};\\\", \\\"{x:175,y:528,t:1527030577015};\\\", \\\"{x:186,y:525,t:1527030577031};\\\", \\\"{x:212,y:523,t:1527030577048};\\\", \\\"{x:270,y:519,t:1527030577065};\\\", \\\"{x:426,y:515,t:1527030577082};\\\", \\\"{x:558,y:498,t:1527030577099};\\\", \\\"{x:694,y:479,t:1527030577115};\\\", \\\"{x:813,y:462,t:1527030577131};\\\", \\\"{x:908,y:447,t:1527030577148};\\\", \\\"{x:989,y:436,t:1527030577165};\\\", \\\"{x:1031,y:434,t:1527030577182};\\\", \\\"{x:1061,y:434,t:1527030577198};\\\", \\\"{x:1082,y:434,t:1527030577216};\\\", \\\"{x:1101,y:434,t:1527030577232};\\\", \\\"{x:1118,y:434,t:1527030577248};\\\", \\\"{x:1130,y:434,t:1527030577265};\\\", \\\"{x:1136,y:434,t:1527030577282};\\\", \\\"{x:1136,y:435,t:1527030577330};\\\", \\\"{x:1135,y:437,t:1527030577338};\\\", \\\"{x:1132,y:437,t:1527030577348};\\\", \\\"{x:1128,y:441,t:1527030577365};\\\", \\\"{x:1126,y:445,t:1527030577383};\\\", \\\"{x:1123,y:448,t:1527030577398};\\\", \\\"{x:1116,y:455,t:1527030577415};\\\", \\\"{x:1104,y:461,t:1527030577433};\\\", \\\"{x:1088,y:464,t:1527030577449};\\\", \\\"{x:1059,y:469,t:1527030577466};\\\", \\\"{x:991,y:473,t:1527030577482};\\\", \\\"{x:959,y:477,t:1527030577498};\\\", \\\"{x:919,y:483,t:1527030577515};\\\", \\\"{x:896,y:487,t:1527030577533};\\\", \\\"{x:882,y:489,t:1527030577549};\\\", \\\"{x:879,y:489,t:1527030577564};\\\", \\\"{x:877,y:490,t:1527030577582};\\\", \\\"{x:877,y:492,t:1527030577642};\\\", \\\"{x:877,y:494,t:1527030577649};\\\", \\\"{x:875,y:499,t:1527030577665};\\\", \\\"{x:874,y:502,t:1527030577683};\\\", \\\"{x:871,y:506,t:1527030577699};\\\", \\\"{x:869,y:509,t:1527030577717};\\\", \\\"{x:864,y:510,t:1527030577734};\\\", \\\"{x:861,y:511,t:1527030577749};\\\", \\\"{x:856,y:511,t:1527030577765};\\\", \\\"{x:852,y:511,t:1527030577782};\\\", \\\"{x:848,y:511,t:1527030577799};\\\", \\\"{x:845,y:511,t:1527030577815};\\\", \\\"{x:844,y:511,t:1527030577832};\\\", \\\"{x:843,y:511,t:1527030577882};\\\", \\\"{x:842,y:510,t:1527030577930};\\\", \\\"{x:842,y:509,t:1527030578017};\\\", \\\"{x:842,y:509,t:1527030578069};\\\", \\\"{x:842,y:513,t:1527030578234};\\\", \\\"{x:837,y:526,t:1527030578251};\\\", \\\"{x:825,y:547,t:1527030578265};\\\", \\\"{x:791,y:596,t:1527030578283};\\\", \\\"{x:745,y:658,t:1527030578299};\\\", \\\"{x:702,y:710,t:1527030578316};\\\", \\\"{x:660,y:750,t:1527030578332};\\\", \\\"{x:617,y:780,t:1527030578349};\\\", \\\"{x:597,y:793,t:1527030578366};\\\", \\\"{x:585,y:798,t:1527030578382};\\\", \\\"{x:576,y:800,t:1527030578399};\\\", \\\"{x:569,y:802,t:1527030578416};\\\", \\\"{x:563,y:802,t:1527030578432};\\\", \\\"{x:549,y:799,t:1527030578449};\\\", \\\"{x:538,y:796,t:1527030578465};\\\", \\\"{x:527,y:793,t:1527030578483};\\\", \\\"{x:516,y:788,t:1527030578499};\\\", \\\"{x:508,y:784,t:1527030578516};\\\", \\\"{x:506,y:783,t:1527030578534};\\\", \\\"{x:505,y:782,t:1527030578550};\\\", \\\"{x:504,y:780,t:1527030578567};\\\", \\\"{x:504,y:773,t:1527030578584};\\\", \\\"{x:502,y:766,t:1527030578599};\\\", \\\"{x:501,y:758,t:1527030578616};\\\", \\\"{x:500,y:753,t:1527030578634};\\\", \\\"{x:500,y:748,t:1527030578650};\\\", \\\"{x:500,y:746,t:1527030578666};\\\", \\\"{x:499,y:745,t:1527030578684};\\\", \\\"{x:498,y:744,t:1527030578699};\\\", \\\"{x:498,y:743,t:1527030581745};\\\", \\\"{x:498,y:743,t:1527030581846};\\\", \\\"{x:499,y:741,t:1527030582050};\\\", \\\"{x:505,y:739,t:1527030582058};\\\", \\\"{x:511,y:739,t:1527030582070};\\\", \\\"{x:522,y:738,t:1527030582085};\\\", \\\"{x:543,y:738,t:1527030582102};\\\", \\\"{x:574,y:738,t:1527030582119};\\\", \\\"{x:626,y:742,t:1527030582135};\\\", \\\"{x:721,y:756,t:1527030582152};\\\", \\\"{x:884,y:782,t:1527030582169};\\\", \\\"{x:1013,y:796,t:1527030582185};\\\", \\\"{x:1149,y:796,t:1527030582202};\\\", \\\"{x:1265,y:796,t:1527030582219};\\\", \\\"{x:1370,y:796,t:1527030582235};\\\", \\\"{x:1443,y:796,t:1527030582252};\\\", \\\"{x:1491,y:790,t:1527030582269};\\\", \\\"{x:1507,y:782,t:1527030582285};\\\", \\\"{x:1511,y:777,t:1527030582302};\\\", \\\"{x:1512,y:763,t:1527030582319};\\\", \\\"{x:1517,y:730,t:1527030582336};\\\", \\\"{x:1523,y:685,t:1527030582352};\\\", \\\"{x:1526,y:643,t:1527030582369};\\\", \\\"{x:1526,y:630,t:1527030582386};\\\", \\\"{x:1526,y:623,t:1527030582402};\\\", \\\"{x:1526,y:621,t:1527030582419};\\\", \\\"{x:1525,y:621,t:1527030582437};\\\", \\\"{x:1523,y:621,t:1527030582458};\\\", \\\"{x:1521,y:621,t:1527030582470};\\\", \\\"{x:1516,y:622,t:1527030582487};\\\", \\\"{x:1507,y:628,t:1527030582503};\\\", \\\"{x:1499,y:633,t:1527030582519};\\\", \\\"{x:1490,y:641,t:1527030582537};\\\", \\\"{x:1485,y:644,t:1527030582552};\\\", \\\"{x:1482,y:646,t:1527030582569};\\\", \\\"{x:1481,y:647,t:1527030582586};\\\" ] }, { \\\"rt\\\": 136934, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 12, \\\"time_elapsed\\\": 503816, \\\"internal_node_id\\\": \\\"0.0-6.0-2.0\\\", \\\"subject\\\": \\\"Q0QHK\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"juliet\\\", \\\"condition\\\": \\\"115\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"duration+contained\\\", \\\"q\\\": 8, \\\"clicks\\\": 1, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XFull-YFull\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 0, \\\"answer\\\": [ \\\"H\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-B -B -Z -Z -Z -Z -C -C -H \\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:1480,y:646,t:1527030591187};\\\", \\\"{x:1480,y:645,t:1527030591194};\\\", \\\"{x:1480,y:644,t:1527030591210};\\\", \\\"{x:1479,y:641,t:1527030591226};\\\", \\\"{x:1478,y:638,t:1527030591243};\\\", \\\"{x:1478,y:637,t:1527030591307};\\\", \\\"{x:1478,y:636,t:1527030591362};\\\", \\\"{x:1476,y:637,t:1527030603650};\\\", \\\"{x:1474,y:639,t:1527030603668};\\\", \\\"{x:1472,y:640,t:1527030603686};\\\", \\\"{x:1471,y:642,t:1527030603701};\\\", \\\"{x:1469,y:645,t:1527030603719};\\\", \\\"{x:1468,y:647,t:1527030603736};\\\", \\\"{x:1467,y:648,t:1527030603752};\\\", \\\"{x:1466,y:649,t:1527030603769};\\\", \\\"{x:1466,y:650,t:1527030603786};\\\", \\\"{x:1465,y:653,t:1527030603802};\\\", \\\"{x:1465,y:654,t:1527030603819};\\\", \\\"{x:1465,y:656,t:1527030603835};\\\", \\\"{x:1462,y:660,t:1527030603853};\\\", \\\"{x:1461,y:666,t:1527030603869};\\\", \\\"{x:1460,y:670,t:1527030603886};\\\", \\\"{x:1459,y:674,t:1527030603903};\\\", \\\"{x:1459,y:676,t:1527030603922};\\\", \\\"{x:1458,y:676,t:1527030603935};\\\", \\\"{x:1458,y:677,t:1527030604058};\\\", \\\"{x:1458,y:678,t:1527030606267};\\\", \\\"{x:1458,y:679,t:1527030606306};\\\", \\\"{x:1459,y:680,t:1527030606378};\\\", \\\"{x:1459,y:679,t:1527030606603};\\\", \\\"{x:1459,y:677,t:1527030606610};\\\", \\\"{x:1459,y:676,t:1527030606621};\\\", \\\"{x:1459,y:673,t:1527030606638};\\\", \\\"{x:1459,y:671,t:1527030606655};\\\", \\\"{x:1459,y:670,t:1527030606671};\\\", \\\"{x:1459,y:669,t:1527030606761};\\\", \\\"{x:1458,y:669,t:1527030606770};\\\", \\\"{x:1448,y:666,t:1527030606788};\\\", \\\"{x:1433,y:665,t:1527030606805};\\\", \\\"{x:1420,y:664,t:1527030606821};\\\", \\\"{x:1409,y:664,t:1527030606837};\\\", \\\"{x:1403,y:664,t:1527030606855};\\\", \\\"{x:1400,y:664,t:1527030606871};\\\", \\\"{x:1399,y:665,t:1527030606887};\\\", \\\"{x:1398,y:666,t:1527030606904};\\\", \\\"{x:1397,y:666,t:1527030606921};\\\", \\\"{x:1395,y:667,t:1527030606937};\\\", \\\"{x:1393,y:673,t:1527030606955};\\\", \\\"{x:1390,y:681,t:1527030606971};\\\", \\\"{x:1387,y:689,t:1527030606988};\\\", \\\"{x:1387,y:699,t:1527030607005};\\\", \\\"{x:1386,y:707,t:1527030607020};\\\", \\\"{x:1384,y:714,t:1527030607037};\\\", \\\"{x:1382,y:719,t:1527030607055};\\\", \\\"{x:1380,y:724,t:1527030607070};\\\", \\\"{x:1375,y:728,t:1527030607088};\\\", \\\"{x:1369,y:732,t:1527030607105};\\\", \\\"{x:1359,y:737,t:1527030607122};\\\", \\\"{x:1354,y:741,t:1527030607138};\\\", \\\"{x:1352,y:742,t:1527030607155};\\\", \\\"{x:1351,y:744,t:1527030607172};\\\", \\\"{x:1351,y:746,t:1527030607188};\\\", \\\"{x:1350,y:748,t:1527030607205};\\\", \\\"{x:1350,y:749,t:1527030607222};\\\", \\\"{x:1349,y:750,t:1527030607238};\\\", \\\"{x:1348,y:751,t:1527030607255};\\\", \\\"{x:1348,y:752,t:1527030607273};\\\", \\\"{x:1348,y:753,t:1527030607297};\\\", \\\"{x:1348,y:757,t:1527030614922};\\\", \\\"{x:1350,y:760,t:1527030614933};\\\", \\\"{x:1351,y:763,t:1527030614943};\\\", \\\"{x:1353,y:765,t:1527030614959};\\\", \\\"{x:1354,y:766,t:1527030614977};\\\", \\\"{x:1354,y:768,t:1527030614993};\\\", \\\"{x:1355,y:768,t:1527030615017};\\\", \\\"{x:1356,y:769,t:1527030615027};\\\", \\\"{x:1356,y:770,t:1527030615044};\\\", \\\"{x:1357,y:771,t:1527030615060};\\\", \\\"{x:1360,y:774,t:1527030615077};\\\", \\\"{x:1362,y:778,t:1527030615094};\\\", \\\"{x:1366,y:782,t:1527030615109};\\\", \\\"{x:1373,y:786,t:1527030615127};\\\", \\\"{x:1380,y:790,t:1527030615144};\\\", \\\"{x:1390,y:795,t:1527030615160};\\\", \\\"{x:1402,y:802,t:1527030615177};\\\", \\\"{x:1412,y:806,t:1527030615194};\\\", \\\"{x:1418,y:809,t:1527030615211};\\\", \\\"{x:1425,y:812,t:1527030615227};\\\", \\\"{x:1435,y:817,t:1527030615244};\\\", \\\"{x:1443,y:821,t:1527030615261};\\\", \\\"{x:1452,y:823,t:1527030615277};\\\", \\\"{x:1460,y:827,t:1527030615294};\\\", \\\"{x:1465,y:830,t:1527030615310};\\\", \\\"{x:1474,y:834,t:1527030615328};\\\", \\\"{x:1477,y:835,t:1527030615344};\\\", \\\"{x:1480,y:836,t:1527030615361};\\\", \\\"{x:1481,y:836,t:1527030615378};\\\", \\\"{x:1482,y:836,t:1527030615594};\\\", \\\"{x:1482,y:837,t:1527030615626};\\\", \\\"{x:1483,y:837,t:1527030615634};\\\", \\\"{x:1486,y:837,t:1527030615644};\\\", \\\"{x:1488,y:838,t:1527030615661};\\\", \\\"{x:1493,y:839,t:1527030615678};\\\", \\\"{x:1496,y:840,t:1527030615695};\\\", \\\"{x:1498,y:841,t:1527030615711};\\\", \\\"{x:1501,y:841,t:1527030615728};\\\", \\\"{x:1503,y:841,t:1527030615745};\\\", \\\"{x:1504,y:841,t:1527030615762};\\\", \\\"{x:1506,y:842,t:1527030615777};\\\", \\\"{x:1507,y:842,t:1527030615794};\\\", \\\"{x:1509,y:842,t:1527030615811};\\\", \\\"{x:1511,y:842,t:1527030615828};\\\", \\\"{x:1516,y:842,t:1527030615844};\\\", \\\"{x:1520,y:842,t:1527030615861};\\\", \\\"{x:1525,y:842,t:1527030615879};\\\", \\\"{x:1532,y:842,t:1527030615894};\\\", \\\"{x:1536,y:842,t:1527030615910};\\\", \\\"{x:1539,y:842,t:1527030615927};\\\", \\\"{x:1542,y:842,t:1527030615944};\\\", \\\"{x:1543,y:842,t:1527030615961};\\\", \\\"{x:1544,y:842,t:1527030615977};\\\", \\\"{x:1545,y:842,t:1527030615994};\\\", \\\"{x:1546,y:842,t:1527030616011};\\\", \\\"{x:1546,y:841,t:1527030616028};\\\", \\\"{x:1547,y:841,t:1527030616044};\\\", \\\"{x:1547,y:840,t:1527030616061};\\\", \\\"{x:1548,y:840,t:1527030616078};\\\", \\\"{x:1549,y:839,t:1527030616094};\\\", \\\"{x:1550,y:838,t:1527030616194};\\\", \\\"{x:1550,y:837,t:1527030616218};\\\", \\\"{x:1551,y:836,t:1527030616229};\\\", \\\"{x:1552,y:836,t:1527030616246};\\\", \\\"{x:1553,y:835,t:1527030616262};\\\", \\\"{x:1555,y:834,t:1527030616279};\\\", \\\"{x:1556,y:834,t:1527030616298};\\\", \\\"{x:1557,y:834,t:1527030616311};\\\", \\\"{x:1560,y:833,t:1527030616329};\\\", \\\"{x:1564,y:832,t:1527030616346};\\\", \\\"{x:1566,y:832,t:1527030616362};\\\", \\\"{x:1568,y:832,t:1527030616378};\\\", \\\"{x:1573,y:831,t:1527030616396};\\\", \\\"{x:1579,y:831,t:1527030616411};\\\", \\\"{x:1585,y:831,t:1527030616428};\\\", \\\"{x:1590,y:830,t:1527030616446};\\\", \\\"{x:1596,y:828,t:1527030616461};\\\", \\\"{x:1598,y:828,t:1527030616479};\\\", \\\"{x:1600,y:828,t:1527030616496};\\\", \\\"{x:1601,y:828,t:1527030616511};\\\", \\\"{x:1601,y:827,t:1527030616529};\\\", \\\"{x:1604,y:826,t:1527030616545};\\\", \\\"{x:1606,y:826,t:1527030616562};\\\", \\\"{x:1608,y:825,t:1527030616586};\\\", \\\"{x:1609,y:825,t:1527030616794};\\\", \\\"{x:1610,y:824,t:1527030616812};\\\", \\\"{x:1611,y:823,t:1527030616922};\\\", \\\"{x:1611,y:822,t:1527030616946};\\\", \\\"{x:1611,y:821,t:1527030617026};\\\", \\\"{x:1611,y:820,t:1527030617034};\\\", \\\"{x:1612,y:819,t:1527030617045};\\\", \\\"{x:1612,y:818,t:1527030617089};\\\", \\\"{x:1612,y:817,t:1527030617097};\\\", \\\"{x:1612,y:816,t:1527030617113};\\\", \\\"{x:1612,y:812,t:1527030617129};\\\", \\\"{x:1612,y:809,t:1527030617145};\\\", \\\"{x:1611,y:805,t:1527030617162};\\\", \\\"{x:1611,y:803,t:1527030617179};\\\", \\\"{x:1611,y:801,t:1527030617195};\\\", \\\"{x:1611,y:800,t:1527030617212};\\\", \\\"{x:1611,y:798,t:1527030617233};\\\", \\\"{x:1610,y:798,t:1527030617245};\\\", \\\"{x:1610,y:797,t:1527030617262};\\\", \\\"{x:1610,y:796,t:1527030617279};\\\", \\\"{x:1610,y:794,t:1527030617295};\\\", \\\"{x:1610,y:793,t:1527030617313};\\\", \\\"{x:1610,y:787,t:1527030617330};\\\", \\\"{x:1609,y:781,t:1527030617345};\\\", \\\"{x:1609,y:775,t:1527030617363};\\\", \\\"{x:1608,y:769,t:1527030617380};\\\", \\\"{x:1608,y:763,t:1527030617395};\\\", \\\"{x:1608,y:760,t:1527030617413};\\\", \\\"{x:1608,y:756,t:1527030617430};\\\", \\\"{x:1608,y:754,t:1527030617445};\\\", \\\"{x:1608,y:753,t:1527030617462};\\\", \\\"{x:1608,y:752,t:1527030617490};\\\", \\\"{x:1608,y:751,t:1527030617570};\\\", \\\"{x:1608,y:750,t:1527030617580};\\\", \\\"{x:1608,y:749,t:1527030617610};\\\", \\\"{x:1608,y:748,t:1527030617626};\\\", \\\"{x:1608,y:747,t:1527030617649};\\\", \\\"{x:1608,y:745,t:1527030617666};\\\", \\\"{x:1608,y:744,t:1527030617679};\\\", \\\"{x:1608,y:741,t:1527030617696};\\\", \\\"{x:1606,y:738,t:1527030617713};\\\", \\\"{x:1606,y:732,t:1527030617729};\\\", \\\"{x:1606,y:729,t:1527030617746};\\\", \\\"{x:1606,y:728,t:1527030617762};\\\", \\\"{x:1606,y:727,t:1527030617780};\\\", \\\"{x:1606,y:726,t:1527030617797};\\\", \\\"{x:1606,y:725,t:1527030617833};\\\", \\\"{x:1606,y:724,t:1527030617850};\\\", \\\"{x:1606,y:723,t:1527030617865};\\\", \\\"{x:1606,y:722,t:1527030617890};\\\", \\\"{x:1606,y:720,t:1527030617905};\\\", \\\"{x:1606,y:718,t:1527030617922};\\\", \\\"{x:1606,y:717,t:1527030617930};\\\", \\\"{x:1606,y:715,t:1527030617954};\\\", \\\"{x:1606,y:714,t:1527030617962};\\\", \\\"{x:1606,y:713,t:1527030617979};\\\", \\\"{x:1607,y:711,t:1527030617997};\\\", \\\"{x:1607,y:709,t:1527030618013};\\\", \\\"{x:1608,y:707,t:1527030618030};\\\", \\\"{x:1609,y:705,t:1527030618047};\\\", \\\"{x:1609,y:702,t:1527030618063};\\\", \\\"{x:1609,y:699,t:1527030618080};\\\", \\\"{x:1610,y:697,t:1527030618096};\\\", \\\"{x:1610,y:694,t:1527030618112};\\\", \\\"{x:1610,y:693,t:1527030618129};\\\", \\\"{x:1611,y:691,t:1527030618146};\\\", \\\"{x:1611,y:689,t:1527030618169};\\\", \\\"{x:1611,y:688,t:1527030618193};\\\", \\\"{x:1611,y:686,t:1527030618216};\\\", \\\"{x:1612,y:685,t:1527030618233};\\\", \\\"{x:1612,y:683,t:1527030618246};\\\", \\\"{x:1612,y:681,t:1527030618263};\\\", \\\"{x:1612,y:678,t:1527030618278};\\\", \\\"{x:1612,y:673,t:1527030618297};\\\", \\\"{x:1612,y:668,t:1527030618313};\\\", \\\"{x:1612,y:666,t:1527030618329};\\\", \\\"{x:1612,y:665,t:1527030618347};\\\", \\\"{x:1612,y:662,t:1527030618363};\\\", \\\"{x:1612,y:661,t:1527030618379};\\\", \\\"{x:1612,y:659,t:1527030618396};\\\", \\\"{x:1612,y:657,t:1527030618413};\\\", \\\"{x:1612,y:655,t:1527030618430};\\\", \\\"{x:1612,y:653,t:1527030618446};\\\", \\\"{x:1612,y:651,t:1527030618463};\\\", \\\"{x:1613,y:646,t:1527030618479};\\\", \\\"{x:1613,y:639,t:1527030618496};\\\", \\\"{x:1615,y:620,t:1527030618512};\\\", \\\"{x:1618,y:607,t:1527030618529};\\\", \\\"{x:1619,y:598,t:1527030618546};\\\", \\\"{x:1620,y:591,t:1527030618563};\\\", \\\"{x:1620,y:587,t:1527030618579};\\\", \\\"{x:1620,y:583,t:1527030618596};\\\", \\\"{x:1620,y:582,t:1527030618613};\\\", \\\"{x:1620,y:580,t:1527030618630};\\\", \\\"{x:1620,y:579,t:1527030618649};\\\", \\\"{x:1620,y:580,t:1527030619186};\\\", \\\"{x:1620,y:584,t:1527030619197};\\\", \\\"{x:1621,y:592,t:1527030619214};\\\", \\\"{x:1621,y:598,t:1527030619230};\\\", \\\"{x:1621,y:607,t:1527030619247};\\\", \\\"{x:1622,y:618,t:1527030619263};\\\", \\\"{x:1624,y:635,t:1527030619280};\\\", \\\"{x:1627,y:654,t:1527030619297};\\\", \\\"{x:1629,y:668,t:1527030619313};\\\", \\\"{x:1632,y:683,t:1527030619330};\\\", \\\"{x:1632,y:693,t:1527030619346};\\\", \\\"{x:1634,y:705,t:1527030619362};\\\", \\\"{x:1636,y:715,t:1527030619380};\\\", \\\"{x:1637,y:723,t:1527030619397};\\\", \\\"{x:1638,y:728,t:1527030619413};\\\", \\\"{x:1639,y:733,t:1527030619430};\\\", \\\"{x:1640,y:739,t:1527030619447};\\\", \\\"{x:1640,y:744,t:1527030619463};\\\", \\\"{x:1641,y:747,t:1527030619480};\\\", \\\"{x:1641,y:750,t:1527030619497};\\\", \\\"{x:1641,y:751,t:1527030619538};\\\", \\\"{x:1641,y:752,t:1527030619547};\\\", \\\"{x:1641,y:754,t:1527030619564};\\\", \\\"{x:1641,y:757,t:1527030619581};\\\", \\\"{x:1641,y:764,t:1527030619597};\\\", \\\"{x:1640,y:769,t:1527030619614};\\\", \\\"{x:1637,y:777,t:1527030619630};\\\", \\\"{x:1636,y:784,t:1527030619648};\\\", \\\"{x:1636,y:791,t:1527030619664};\\\", \\\"{x:1635,y:797,t:1527030619680};\\\", \\\"{x:1635,y:803,t:1527030619697};\\\", \\\"{x:1635,y:804,t:1527030619713};\\\", \\\"{x:1635,y:806,t:1527030619730};\\\", \\\"{x:1635,y:807,t:1527030619747};\\\", \\\"{x:1635,y:809,t:1527030619765};\\\", \\\"{x:1635,y:810,t:1527030619785};\\\", \\\"{x:1635,y:811,t:1527030619797};\\\", \\\"{x:1635,y:813,t:1527030619814};\\\", \\\"{x:1635,y:814,t:1527030619830};\\\", \\\"{x:1635,y:815,t:1527030619847};\\\", \\\"{x:1635,y:816,t:1527030619865};\\\", \\\"{x:1633,y:817,t:1527030619880};\\\", \\\"{x:1632,y:818,t:1527030619906};\\\", \\\"{x:1632,y:819,t:1527030619930};\\\", \\\"{x:1632,y:820,t:1527030619938};\\\", \\\"{x:1630,y:821,t:1527030619948};\\\", \\\"{x:1630,y:822,t:1527030619965};\\\", \\\"{x:1629,y:823,t:1527030619994};\\\", \\\"{x:1629,y:824,t:1527030620034};\\\", \\\"{x:1629,y:825,t:1527030620058};\\\", \\\"{x:1629,y:826,t:1527030620082};\\\", \\\"{x:1629,y:827,t:1527030620097};\\\", \\\"{x:1628,y:828,t:1527030620114};\\\", \\\"{x:1627,y:829,t:1527030620193};\\\", \\\"{x:1626,y:829,t:1527030620322};\\\", \\\"{x:1625,y:828,t:1527030620346};\\\", \\\"{x:1625,y:827,t:1527030620369};\\\", \\\"{x:1625,y:826,t:1527030620538};\\\", \\\"{x:1625,y:825,t:1527030620562};\\\", \\\"{x:1625,y:824,t:1527030620578};\\\", \\\"{x:1625,y:823,t:1527030620586};\\\", \\\"{x:1625,y:822,t:1527030620610};\\\", \\\"{x:1625,y:820,t:1527030620618};\\\", \\\"{x:1625,y:819,t:1527030620632};\\\", \\\"{x:1625,y:814,t:1527030620648};\\\", \\\"{x:1627,y:808,t:1527030620665};\\\", \\\"{x:1627,y:801,t:1527030620682};\\\", \\\"{x:1627,y:795,t:1527030620698};\\\", \\\"{x:1627,y:788,t:1527030620714};\\\", \\\"{x:1627,y:784,t:1527030620731};\\\", \\\"{x:1627,y:777,t:1527030620748};\\\", \\\"{x:1627,y:771,t:1527030620764};\\\", \\\"{x:1627,y:764,t:1527030620781};\\\", \\\"{x:1627,y:757,t:1527030620798};\\\", \\\"{x:1627,y:749,t:1527030620814};\\\", \\\"{x:1627,y:741,t:1527030620831};\\\", \\\"{x:1626,y:734,t:1527030620848};\\\", \\\"{x:1625,y:728,t:1527030620864};\\\", \\\"{x:1622,y:718,t:1527030620881};\\\", \\\"{x:1621,y:714,t:1527030620899};\\\", \\\"{x:1619,y:710,t:1527030620914};\\\", \\\"{x:1618,y:706,t:1527030620932};\\\", \\\"{x:1617,y:701,t:1527030620949};\\\", \\\"{x:1615,y:695,t:1527030620966};\\\", \\\"{x:1614,y:690,t:1527030620982};\\\", \\\"{x:1611,y:683,t:1527030620998};\\\", \\\"{x:1610,y:679,t:1527030621015};\\\", \\\"{x:1609,y:676,t:1527030621031};\\\", \\\"{x:1608,y:673,t:1527030621048};\\\", \\\"{x:1607,y:669,t:1527030621065};\\\", \\\"{x:1607,y:666,t:1527030621081};\\\", \\\"{x:1607,y:664,t:1527030621098};\\\", \\\"{x:1607,y:659,t:1527030621116};\\\", \\\"{x:1607,y:653,t:1527030621131};\\\", \\\"{x:1607,y:645,t:1527030621148};\\\", \\\"{x:1607,y:635,t:1527030621165};\\\", \\\"{x:1607,y:627,t:1527030621181};\\\", \\\"{x:1607,y:617,t:1527030621198};\\\", \\\"{x:1607,y:606,t:1527030621215};\\\", \\\"{x:1607,y:596,t:1527030621231};\\\", \\\"{x:1607,y:588,t:1527030621248};\\\", \\\"{x:1606,y:580,t:1527030621266};\\\", \\\"{x:1606,y:576,t:1527030621282};\\\", \\\"{x:1604,y:574,t:1527030621298};\\\", \\\"{x:1604,y:571,t:1527030621316};\\\", \\\"{x:1604,y:570,t:1527030621332};\\\", \\\"{x:1604,y:569,t:1527030621349};\\\", \\\"{x:1604,y:568,t:1527030621365};\\\", \\\"{x:1604,y:567,t:1527030621381};\\\", \\\"{x:1604,y:566,t:1527030621434};\\\", \\\"{x:1604,y:565,t:1527030621458};\\\", \\\"{x:1604,y:564,t:1527030621481};\\\", \\\"{x:1604,y:563,t:1527030621506};\\\", \\\"{x:1604,y:562,t:1527030621522};\\\", \\\"{x:1604,y:561,t:1527030621554};\\\", \\\"{x:1604,y:560,t:1527030621642};\\\", \\\"{x:1604,y:559,t:1527030621666};\\\", \\\"{x:1604,y:558,t:1527030621698};\\\", \\\"{x:1604,y:557,t:1527030625387};\\\", \\\"{x:1604,y:551,t:1527030625402};\\\", \\\"{x:1604,y:548,t:1527030625418};\\\", \\\"{x:1604,y:545,t:1527030625434};\\\", \\\"{x:1604,y:543,t:1527030625451};\\\", \\\"{x:1604,y:542,t:1527030625468};\\\", \\\"{x:1604,y:541,t:1527030625485};\\\", \\\"{x:1603,y:539,t:1527030625501};\\\", \\\"{x:1603,y:538,t:1527030625518};\\\", \\\"{x:1603,y:535,t:1527030625534};\\\", \\\"{x:1602,y:534,t:1527030625551};\\\", \\\"{x:1602,y:533,t:1527030625568};\\\", \\\"{x:1602,y:532,t:1527030625584};\\\", \\\"{x:1601,y:529,t:1527030625601};\\\", \\\"{x:1600,y:527,t:1527030625618};\\\", \\\"{x:1600,y:521,t:1527030625635};\\\", \\\"{x:1599,y:517,t:1527030625651};\\\", \\\"{x:1599,y:516,t:1527030625673};\\\", \\\"{x:1599,y:515,t:1527030625689};\\\", \\\"{x:1599,y:514,t:1527030625794};\\\", \\\"{x:1598,y:512,t:1527030625954};\\\", \\\"{x:1598,y:511,t:1527030625969};\\\", \\\"{x:1597,y:509,t:1527030626002};\\\", \\\"{x:1597,y:508,t:1527030626049};\\\", \\\"{x:1596,y:508,t:1527030626065};\\\", \\\"{x:1596,y:506,t:1527030626106};\\\", \\\"{x:1596,y:505,t:1527030626210};\\\", \\\"{x:1595,y:505,t:1527030626233};\\\", \\\"{x:1595,y:504,t:1527030626258};\\\", \\\"{x:1594,y:502,t:1527030626602};\\\", \\\"{x:1594,y:498,t:1527030641077};\\\", \\\"{x:1600,y:492,t:1527030641084};\\\", \\\"{x:1608,y:486,t:1527030641099};\\\", \\\"{x:1616,y:482,t:1527030641115};\\\", \\\"{x:1617,y:482,t:1527030641133};\\\", \\\"{x:1619,y:482,t:1527030641220};\\\", \\\"{x:1619,y:481,t:1527030641233};\\\", \\\"{x:1621,y:481,t:1527030641252};\\\", \\\"{x:1622,y:481,t:1527030641276};\\\", \\\"{x:1621,y:481,t:1527030641613};\\\", \\\"{x:1621,y:482,t:1527030641621};\\\", \\\"{x:1620,y:484,t:1527030641634};\\\", \\\"{x:1618,y:486,t:1527030641650};\\\", \\\"{x:1618,y:487,t:1527030641667};\\\", \\\"{x:1618,y:488,t:1527030641684};\\\", \\\"{x:1618,y:489,t:1527030641908};\\\", \\\"{x:1618,y:490,t:1527030641916};\\\", \\\"{x:1618,y:493,t:1527030641933};\\\", \\\"{x:1617,y:495,t:1527030641950};\\\", \\\"{x:1616,y:499,t:1527030641968};\\\", \\\"{x:1616,y:500,t:1527030641983};\\\", \\\"{x:1616,y:501,t:1527030642000};\\\", \\\"{x:1615,y:502,t:1527030642017};\\\", \\\"{x:1615,y:505,t:1527030642885};\\\", \\\"{x:1615,y:509,t:1527030642899};\\\", \\\"{x:1615,y:510,t:1527030642917};\\\", \\\"{x:1615,y:511,t:1527030642934};\\\", \\\"{x:1615,y:510,t:1527030643205};\\\", \\\"{x:1615,y:509,t:1527030643218};\\\", \\\"{x:1616,y:506,t:1527030643234};\\\", \\\"{x:1616,y:502,t:1527030643252};\\\", \\\"{x:1616,y:500,t:1527030643268};\\\", \\\"{x:1616,y:499,t:1527030643597};\\\", \\\"{x:1616,y:496,t:1527030643605};\\\", \\\"{x:1616,y:494,t:1527030643620};\\\", \\\"{x:1616,y:493,t:1527030643646};\\\", \\\"{x:1616,y:492,t:1527030643677};\\\", \\\"{x:1614,y:492,t:1527030702539};\\\", \\\"{x:1610,y:492,t:1527030702552};\\\", \\\"{x:1598,y:495,t:1527030702569};\\\", \\\"{x:1587,y:503,t:1527030702584};\\\", \\\"{x:1578,y:515,t:1527030702602};\\\", \\\"{x:1570,y:539,t:1527030702618};\\\", \\\"{x:1569,y:559,t:1527030702635};\\\", \\\"{x:1566,y:577,t:1527030702651};\\\", \\\"{x:1564,y:595,t:1527030702669};\\\", \\\"{x:1564,y:616,t:1527030702685};\\\", \\\"{x:1564,y:644,t:1527030702702};\\\", \\\"{x:1564,y:674,t:1527030702718};\\\", \\\"{x:1563,y:698,t:1527030702736};\\\", \\\"{x:1558,y:718,t:1527030702751};\\\", \\\"{x:1558,y:720,t:1527030702769};\\\", \\\"{x:1556,y:718,t:1527030702810};\\\", \\\"{x:1556,y:713,t:1527030702819};\\\", \\\"{x:1555,y:706,t:1527030702836};\\\", \\\"{x:1554,y:695,t:1527030702851};\\\", \\\"{x:1554,y:680,t:1527030702869};\\\", \\\"{x:1554,y:667,t:1527030702885};\\\", \\\"{x:1554,y:658,t:1527030702903};\\\", \\\"{x:1554,y:652,t:1527030702918};\\\", \\\"{x:1554,y:646,t:1527030702934};\\\", \\\"{x:1554,y:642,t:1527030702951};\\\", \\\"{x:1554,y:637,t:1527030702968};\\\", \\\"{x:1552,y:632,t:1527030702985};\\\", \\\"{x:1552,y:633,t:1527030703131};\\\", \\\"{x:1552,y:634,t:1527030703138};\\\", \\\"{x:1552,y:635,t:1527030703153};\\\", \\\"{x:1552,y:638,t:1527030703169};\\\", \\\"{x:1552,y:640,t:1527030703185};\\\", \\\"{x:1550,y:644,t:1527030703202};\\\", \\\"{x:1542,y:651,t:1527030703218};\\\", \\\"{x:1528,y:657,t:1527030703236};\\\", \\\"{x:1512,y:662,t:1527030703253};\\\", \\\"{x:1506,y:662,t:1527030703268};\\\", \\\"{x:1504,y:662,t:1527030703286};\\\", \\\"{x:1504,y:661,t:1527030703330};\\\", \\\"{x:1504,y:659,t:1527030703338};\\\", \\\"{x:1504,y:658,t:1527030703353};\\\", \\\"{x:1506,y:656,t:1527030703369};\\\", \\\"{x:1506,y:655,t:1527030703386};\\\", \\\"{x:1507,y:654,t:1527030703403};\\\", \\\"{x:1507,y:653,t:1527030703538};\\\", \\\"{x:1508,y:651,t:1527030703578};\\\", \\\"{x:1509,y:651,t:1527030703602};\\\", \\\"{x:1509,y:650,t:1527030703634};\\\", \\\"{x:1510,y:650,t:1527030703850};\\\", \\\"{x:1511,y:649,t:1527030703858};\\\", \\\"{x:1512,y:648,t:1527030703881};\\\", \\\"{x:1513,y:647,t:1527030703905};\\\", \\\"{x:1514,y:647,t:1527030703929};\\\", \\\"{x:1515,y:647,t:1527030703945};\\\", \\\"{x:1516,y:645,t:1527030703953};\\\", \\\"{x:1517,y:645,t:1527030703969};\\\", \\\"{x:1520,y:645,t:1527030703985};\\\", \\\"{x:1522,y:644,t:1527030704003};\\\", \\\"{x:1527,y:643,t:1527030704019};\\\", \\\"{x:1530,y:643,t:1527030704036};\\\", \\\"{x:1534,y:642,t:1527030704052};\\\", \\\"{x:1537,y:641,t:1527030704069};\\\", \\\"{x:1539,y:640,t:1527030704086};\\\", \\\"{x:1540,y:640,t:1527030704102};\\\", \\\"{x:1542,y:640,t:1527030704119};\\\", \\\"{x:1543,y:640,t:1527030704136};\\\", \\\"{x:1544,y:640,t:1527030704152};\\\", \\\"{x:1543,y:640,t:1527030704265};\\\", \\\"{x:1542,y:640,t:1527030704273};\\\", \\\"{x:1540,y:640,t:1527030704297};\\\", \\\"{x:1539,y:640,t:1527030704305};\\\", \\\"{x:1537,y:641,t:1527030704319};\\\", \\\"{x:1530,y:643,t:1527030704336};\\\", \\\"{x:1524,y:643,t:1527030704352};\\\", \\\"{x:1506,y:646,t:1527030704369};\\\", \\\"{x:1486,y:647,t:1527030704386};\\\", \\\"{x:1469,y:647,t:1527030704402};\\\", \\\"{x:1449,y:647,t:1527030704419};\\\", \\\"{x:1433,y:647,t:1527030704436};\\\", \\\"{x:1417,y:645,t:1527030704452};\\\", \\\"{x:1404,y:642,t:1527030704469};\\\", \\\"{x:1397,y:641,t:1527030704486};\\\", \\\"{x:1396,y:640,t:1527030704502};\\\", \\\"{x:1395,y:640,t:1527030704519};\\\", \\\"{x:1395,y:638,t:1527030704537};\\\", \\\"{x:1396,y:638,t:1527030704553};\\\", \\\"{x:1396,y:637,t:1527030704570};\\\", \\\"{x:1397,y:637,t:1527030704586};\\\", \\\"{x:1399,y:635,t:1527030704604};\\\", \\\"{x:1406,y:635,t:1527030704620};\\\", \\\"{x:1414,y:634,t:1527030704636};\\\", \\\"{x:1424,y:634,t:1527030704654};\\\", \\\"{x:1436,y:634,t:1527030704670};\\\", \\\"{x:1445,y:634,t:1527030704687};\\\", \\\"{x:1450,y:634,t:1527030704703};\\\", \\\"{x:1453,y:634,t:1527030704720};\\\", \\\"{x:1454,y:633,t:1527030704842};\\\", \\\"{x:1454,y:632,t:1527030704867};\\\", \\\"{x:1454,y:631,t:1527030704907};\\\", \\\"{x:1453,y:631,t:1527030704922};\\\", \\\"{x:1451,y:630,t:1527030704953};\\\", \\\"{x:1451,y:629,t:1527030704970};\\\", \\\"{x:1450,y:629,t:1527030704986};\\\", \\\"{x:1450,y:628,t:1527030705003};\\\", \\\"{x:1449,y:628,t:1527030705242};\\\", \\\"{x:1448,y:628,t:1527030705253};\\\", \\\"{x:1446,y:632,t:1527030705271};\\\", \\\"{x:1444,y:637,t:1527030705287};\\\", \\\"{x:1442,y:645,t:1527030705304};\\\", \\\"{x:1440,y:655,t:1527030705321};\\\", \\\"{x:1437,y:667,t:1527030705337};\\\", \\\"{x:1434,y:680,t:1527030705354};\\\", \\\"{x:1433,y:689,t:1527030705370};\\\", \\\"{x:1433,y:700,t:1527030705386};\\\", \\\"{x:1432,y:707,t:1527030705403};\\\", \\\"{x:1429,y:715,t:1527030705421};\\\", \\\"{x:1429,y:721,t:1527030705437};\\\", \\\"{x:1428,y:731,t:1527030705453};\\\", \\\"{x:1428,y:743,t:1527030705470};\\\", \\\"{x:1428,y:753,t:1527030705487};\\\", \\\"{x:1428,y:764,t:1527030705503};\\\", \\\"{x:1428,y:775,t:1527030705520};\\\", \\\"{x:1428,y:796,t:1527030705537};\\\", \\\"{x:1428,y:807,t:1527030705553};\\\", \\\"{x:1428,y:817,t:1527030705571};\\\", \\\"{x:1428,y:827,t:1527030705587};\\\", \\\"{x:1428,y:839,t:1527030705603};\\\", \\\"{x:1428,y:852,t:1527030705620};\\\", \\\"{x:1431,y:867,t:1527030705637};\\\", \\\"{x:1433,y:880,t:1527030705653};\\\", \\\"{x:1435,y:888,t:1527030705670};\\\", \\\"{x:1435,y:892,t:1527030705687};\\\", \\\"{x:1436,y:902,t:1527030705704};\\\", \\\"{x:1437,y:916,t:1527030705720};\\\", \\\"{x:1440,y:929,t:1527030705738};\\\", \\\"{x:1440,y:933,t:1527030705754};\\\", \\\"{x:1440,y:935,t:1527030705771};\\\", \\\"{x:1441,y:938,t:1527030705787};\\\", \\\"{x:1441,y:939,t:1527030705803};\\\", \\\"{x:1441,y:940,t:1527030705821};\\\", \\\"{x:1441,y:942,t:1527030705838};\\\", \\\"{x:1441,y:943,t:1527030705854};\\\", \\\"{x:1441,y:945,t:1527030705871};\\\", \\\"{x:1441,y:946,t:1527030705888};\\\", \\\"{x:1441,y:948,t:1527030705904};\\\", \\\"{x:1441,y:949,t:1527030705920};\\\", \\\"{x:1441,y:950,t:1527030705978};\\\", \\\"{x:1441,y:952,t:1527030706090};\\\", \\\"{x:1442,y:953,t:1527030706290};\\\", \\\"{x:1443,y:953,t:1527030707538};\\\", \\\"{x:1443,y:950,t:1527030707556};\\\", \\\"{x:1443,y:948,t:1527030707571};\\\", \\\"{x:1443,y:946,t:1527030707589};\\\", \\\"{x:1443,y:942,t:1527030707606};\\\", \\\"{x:1443,y:941,t:1527030707626};\\\", \\\"{x:1443,y:940,t:1527030707642};\\\", \\\"{x:1443,y:939,t:1527030707698};\\\", \\\"{x:1443,y:938,t:1527030707722};\\\", \\\"{x:1443,y:937,t:1527030707739};\\\", \\\"{x:1443,y:936,t:1527030707794};\\\", \\\"{x:1443,y:935,t:1527030708106};\\\", \\\"{x:1443,y:936,t:1527030709226};\\\", \\\"{x:1443,y:939,t:1527030709239};\\\", \\\"{x:1442,y:942,t:1527030709257};\\\", \\\"{x:1442,y:944,t:1527030709273};\\\", \\\"{x:1442,y:943,t:1527030709986};\\\", \\\"{x:1442,y:942,t:1527030710001};\\\", \\\"{x:1442,y:941,t:1527030710009};\\\", \\\"{x:1442,y:939,t:1527030710090};\\\", \\\"{x:1442,y:936,t:1527030710107};\\\", \\\"{x:1442,y:930,t:1527030710124};\\\", \\\"{x:1449,y:915,t:1527030710140};\\\", \\\"{x:1468,y:896,t:1527030710158};\\\", \\\"{x:1505,y:868,t:1527030710174};\\\", \\\"{x:1557,y:826,t:1527030710190};\\\", \\\"{x:1619,y:779,t:1527030710207};\\\", \\\"{x:1679,y:732,t:1527030710224};\\\", \\\"{x:1726,y:692,t:1527030710241};\\\", \\\"{x:1766,y:652,t:1527030710258};\\\", \\\"{x:1773,y:635,t:1527030710274};\\\", \\\"{x:1776,y:620,t:1527030710290};\\\", \\\"{x:1777,y:612,t:1527030710308};\\\", \\\"{x:1777,y:606,t:1527030710323};\\\", \\\"{x:1776,y:602,t:1527030710341};\\\", \\\"{x:1773,y:599,t:1527030710357};\\\", \\\"{x:1769,y:596,t:1527030710374};\\\", \\\"{x:1762,y:594,t:1527030710390};\\\", \\\"{x:1753,y:591,t:1527030710407};\\\", \\\"{x:1743,y:591,t:1527030710423};\\\", \\\"{x:1732,y:590,t:1527030710440};\\\", \\\"{x:1709,y:588,t:1527030710456};\\\", \\\"{x:1693,y:588,t:1527030710473};\\\", \\\"{x:1671,y:588,t:1527030710491};\\\", \\\"{x:1653,y:588,t:1527030710507};\\\", \\\"{x:1625,y:596,t:1527030710523};\\\", \\\"{x:1599,y:604,t:1527030710540};\\\", \\\"{x:1572,y:611,t:1527030710557};\\\", \\\"{x:1547,y:617,t:1527030710573};\\\", \\\"{x:1524,y:619,t:1527030710591};\\\", \\\"{x:1506,y:621,t:1527030710607};\\\", \\\"{x:1496,y:622,t:1527030710624};\\\", \\\"{x:1491,y:623,t:1527030710640};\\\", \\\"{x:1489,y:624,t:1527030710658};\\\", \\\"{x:1487,y:624,t:1527030710673};\\\", \\\"{x:1485,y:625,t:1527030710690};\\\", \\\"{x:1484,y:625,t:1527030710708};\\\", \\\"{x:1483,y:625,t:1527030710724};\\\", \\\"{x:1482,y:625,t:1527030710741};\\\", \\\"{x:1480,y:626,t:1527030710762};\\\", \\\"{x:1482,y:626,t:1527030710835};\\\", \\\"{x:1484,y:627,t:1527030710850};\\\", \\\"{x:1487,y:629,t:1527030710858};\\\", \\\"{x:1491,y:629,t:1527030710874};\\\", \\\"{x:1495,y:630,t:1527030710891};\\\", \\\"{x:1501,y:630,t:1527030710908};\\\", \\\"{x:1504,y:631,t:1527030710925};\\\", \\\"{x:1507,y:631,t:1527030710941};\\\", \\\"{x:1508,y:631,t:1527030710958};\\\", \\\"{x:1509,y:631,t:1527030710986};\\\", \\\"{x:1510,y:631,t:1527030711002};\\\", \\\"{x:1511,y:631,t:1527030711010};\\\", \\\"{x:1512,y:631,t:1527030711218};\\\", \\\"{x:1514,y:631,t:1527030711226};\\\", \\\"{x:1517,y:631,t:1527030711241};\\\", \\\"{x:1531,y:631,t:1527030711258};\\\", \\\"{x:1545,y:631,t:1527030711275};\\\", \\\"{x:1560,y:631,t:1527030711292};\\\", \\\"{x:1570,y:631,t:1527030711308};\\\", \\\"{x:1578,y:631,t:1527030711325};\\\", \\\"{x:1585,y:631,t:1527030711341};\\\", \\\"{x:1590,y:631,t:1527030711359};\\\", \\\"{x:1591,y:631,t:1527030711374};\\\", \\\"{x:1592,y:631,t:1527030711392};\\\", \\\"{x:1591,y:631,t:1527030711546};\\\", \\\"{x:1590,y:631,t:1527030711562};\\\", \\\"{x:1588,y:631,t:1527030711575};\\\", \\\"{x:1587,y:631,t:1527030711594};\\\", \\\"{x:1588,y:631,t:1527030711714};\\\", \\\"{x:1592,y:631,t:1527030711725};\\\", \\\"{x:1599,y:631,t:1527030711742};\\\", \\\"{x:1611,y:631,t:1527030711759};\\\", \\\"{x:1624,y:631,t:1527030711774};\\\", \\\"{x:1636,y:631,t:1527030711792};\\\", \\\"{x:1646,y:633,t:1527030711810};\\\", \\\"{x:1650,y:633,t:1527030711824};\\\", \\\"{x:1652,y:634,t:1527030711842};\\\", \\\"{x:1653,y:634,t:1527030712138};\\\", \\\"{x:1654,y:634,t:1527030712146};\\\", \\\"{x:1655,y:634,t:1527030712159};\\\", \\\"{x:1657,y:633,t:1527030712175};\\\", \\\"{x:1663,y:630,t:1527030712192};\\\", \\\"{x:1666,y:629,t:1527030712210};\\\", \\\"{x:1672,y:628,t:1527030712226};\\\", \\\"{x:1676,y:626,t:1527030712241};\\\", \\\"{x:1678,y:626,t:1527030712258};\\\", \\\"{x:1681,y:626,t:1527030712275};\\\", \\\"{x:1683,y:626,t:1527030712292};\\\", \\\"{x:1688,y:625,t:1527030712308};\\\", \\\"{x:1691,y:625,t:1527030712325};\\\", \\\"{x:1694,y:625,t:1527030712341};\\\", \\\"{x:1695,y:624,t:1527030712358};\\\", \\\"{x:1697,y:623,t:1527030712376};\\\", \\\"{x:1698,y:623,t:1527030712393};\\\", \\\"{x:1699,y:622,t:1527030712408};\\\", \\\"{x:1700,y:622,t:1527030712449};\\\", \\\"{x:1701,y:622,t:1527030712466};\\\", \\\"{x:1702,y:622,t:1527030712505};\\\", \\\"{x:1703,y:622,t:1527030712513};\\\", \\\"{x:1704,y:622,t:1527030712526};\\\", \\\"{x:1706,y:622,t:1527030712541};\\\", \\\"{x:1711,y:622,t:1527030712559};\\\", \\\"{x:1712,y:622,t:1527030712576};\\\", \\\"{x:1713,y:622,t:1527030713001};\\\", \\\"{x:1716,y:622,t:1527030713009};\\\", \\\"{x:1729,y:623,t:1527030713025};\\\", \\\"{x:1746,y:625,t:1527030713042};\\\", \\\"{x:1764,y:628,t:1527030713059};\\\", \\\"{x:1779,y:628,t:1527030713076};\\\", \\\"{x:1785,y:628,t:1527030713093};\\\", \\\"{x:1791,y:628,t:1527030713108};\\\", \\\"{x:1792,y:628,t:1527030713162};\\\", \\\"{x:1794,y:628,t:1527030713178};\\\", \\\"{x:1795,y:628,t:1527030713193};\\\", \\\"{x:1800,y:628,t:1527030713210};\\\", \\\"{x:1802,y:628,t:1527030713226};\\\", \\\"{x:1804,y:628,t:1527030713243};\\\", \\\"{x:1804,y:629,t:1527030713354};\\\", \\\"{x:1803,y:629,t:1527030713370};\\\", \\\"{x:1802,y:629,t:1527030713377};\\\", \\\"{x:1801,y:630,t:1527030713402};\\\", \\\"{x:1800,y:631,t:1527030713418};\\\", \\\"{x:1799,y:631,t:1527030713474};\\\", \\\"{x:1797,y:632,t:1527030713674};\\\", \\\"{x:1796,y:632,t:1527030713706};\\\", \\\"{x:1795,y:632,t:1527030714979};\\\", \\\"{x:1788,y:632,t:1527030714994};\\\", \\\"{x:1780,y:632,t:1527030715011};\\\", \\\"{x:1765,y:632,t:1527030715028};\\\", \\\"{x:1748,y:632,t:1527030715044};\\\", \\\"{x:1730,y:632,t:1527030715061};\\\", \\\"{x:1714,y:632,t:1527030715078};\\\", \\\"{x:1698,y:632,t:1527030715094};\\\", \\\"{x:1686,y:632,t:1527030715111};\\\", \\\"{x:1677,y:632,t:1527030715128};\\\", \\\"{x:1673,y:632,t:1527030715144};\\\", \\\"{x:1670,y:632,t:1527030715161};\\\", \\\"{x:1666,y:632,t:1527030715178};\\\", \\\"{x:1664,y:634,t:1527030715194};\\\", \\\"{x:1661,y:634,t:1527030715211};\\\", \\\"{x:1659,y:634,t:1527030715228};\\\", \\\"{x:1658,y:635,t:1527030715244};\\\", \\\"{x:1656,y:635,t:1527030715434};\\\", \\\"{x:1655,y:636,t:1527030715444};\\\", \\\"{x:1652,y:636,t:1527030715461};\\\", \\\"{x:1649,y:636,t:1527030715478};\\\", \\\"{x:1647,y:636,t:1527030715495};\\\", \\\"{x:1645,y:636,t:1527030715512};\\\", \\\"{x:1643,y:636,t:1527030715528};\\\", \\\"{x:1644,y:636,t:1527030715747};\\\", \\\"{x:1645,y:636,t:1527030715761};\\\", \\\"{x:1652,y:636,t:1527030715778};\\\", \\\"{x:1661,y:636,t:1527030715795};\\\", \\\"{x:1671,y:636,t:1527030715811};\\\", \\\"{x:1681,y:636,t:1527030715828};\\\", \\\"{x:1693,y:636,t:1527030715845};\\\", \\\"{x:1704,y:636,t:1527030715861};\\\", \\\"{x:1712,y:634,t:1527030715878};\\\", \\\"{x:1716,y:633,t:1527030715895};\\\", \\\"{x:1718,y:633,t:1527030715912};\\\", \\\"{x:1720,y:633,t:1527030715930};\\\", \\\"{x:1720,y:632,t:1527030716186};\\\", \\\"{x:1720,y:630,t:1527030716386};\\\", \\\"{x:1721,y:630,t:1527030716410};\\\", \\\"{x:1722,y:630,t:1527030716418};\\\", \\\"{x:1723,y:629,t:1527030716428};\\\", \\\"{x:1727,y:628,t:1527030716445};\\\", \\\"{x:1733,y:628,t:1527030716463};\\\", \\\"{x:1743,y:628,t:1527030716479};\\\", \\\"{x:1753,y:628,t:1527030716495};\\\", \\\"{x:1761,y:628,t:1527030716511};\\\", \\\"{x:1768,y:628,t:1527030716528};\\\", \\\"{x:1772,y:628,t:1527030716544};\\\", \\\"{x:1774,y:628,t:1527030716561};\\\", \\\"{x:1775,y:628,t:1527030716585};\\\", \\\"{x:1776,y:627,t:1527030716609};\\\", \\\"{x:1777,y:627,t:1527030716810};\\\", \\\"{x:1779,y:627,t:1527030716818};\\\", \\\"{x:1782,y:627,t:1527030716829};\\\", \\\"{x:1791,y:627,t:1527030716844};\\\", \\\"{x:1802,y:627,t:1527030716861};\\\", \\\"{x:1811,y:627,t:1527030716878};\\\", \\\"{x:1816,y:627,t:1527030716895};\\\", \\\"{x:1817,y:627,t:1527030716912};\\\", \\\"{x:1818,y:627,t:1527030716928};\\\", \\\"{x:1819,y:627,t:1527030716945};\\\", \\\"{x:1820,y:627,t:1527030716962};\\\", \\\"{x:1825,y:627,t:1527030716978};\\\", \\\"{x:1829,y:627,t:1527030716996};\\\", \\\"{x:1835,y:627,t:1527030717011};\\\", \\\"{x:1838,y:627,t:1527030717028};\\\", \\\"{x:1841,y:627,t:1527030717046};\\\", \\\"{x:1843,y:627,t:1527030717066};\\\", \\\"{x:1844,y:627,t:1527030717106};\\\", \\\"{x:1846,y:627,t:1527030717113};\\\", \\\"{x:1847,y:627,t:1527030717129};\\\", \\\"{x:1855,y:627,t:1527030717145};\\\", \\\"{x:1864,y:629,t:1527030717162};\\\", \\\"{x:1875,y:630,t:1527030717179};\\\", \\\"{x:1885,y:631,t:1527030717197};\\\", \\\"{x:1893,y:632,t:1527030717212};\\\", \\\"{x:1898,y:632,t:1527030717229};\\\", \\\"{x:1901,y:632,t:1527030717246};\\\", \\\"{x:1901,y:633,t:1527030717262};\\\", \\\"{x:1897,y:633,t:1527030717346};\\\", \\\"{x:1867,y:631,t:1527030717362};\\\", \\\"{x:1792,y:620,t:1527030717379};\\\", \\\"{x:1671,y:608,t:1527030717396};\\\", \\\"{x:1526,y:599,t:1527030717412};\\\", \\\"{x:1357,y:599,t:1527030717430};\\\", \\\"{x:1186,y:599,t:1527030717446};\\\", \\\"{x:1045,y:599,t:1527030717463};\\\", \\\"{x:937,y:599,t:1527030717479};\\\", \\\"{x:867,y:599,t:1527030717496};\\\", \\\"{x:840,y:600,t:1527030717513};\\\", \\\"{x:831,y:605,t:1527030717531};\\\", \\\"{x:822,y:617,t:1527030717546};\\\", \\\"{x:816,y:631,t:1527030717562};\\\", \\\"{x:813,y:641,t:1527030717572};\\\", \\\"{x:806,y:655,t:1527030717587};\\\", \\\"{x:796,y:670,t:1527030717604};\\\", \\\"{x:787,y:679,t:1527030717621};\\\", \\\"{x:780,y:683,t:1527030717638};\\\", \\\"{x:772,y:685,t:1527030717654};\\\", \\\"{x:764,y:685,t:1527030717671};\\\", \\\"{x:746,y:685,t:1527030717688};\\\", \\\"{x:742,y:685,t:1527030717704};\\\", \\\"{x:728,y:685,t:1527030717722};\\\", \\\"{x:723,y:684,t:1527030717738};\\\", \\\"{x:721,y:682,t:1527030717755};\\\", \\\"{x:721,y:680,t:1527030717772};\\\", \\\"{x:721,y:676,t:1527030717788};\\\", \\\"{x:725,y:670,t:1527030717804};\\\", \\\"{x:744,y:663,t:1527030717821};\\\", \\\"{x:774,y:657,t:1527030717839};\\\", \\\"{x:831,y:652,t:1527030717855};\\\", \\\"{x:912,y:652,t:1527030717872};\\\", \\\"{x:1003,y:652,t:1527030717889};\\\", \\\"{x:1095,y:652,t:1527030717904};\\\", \\\"{x:1229,y:650,t:1527030717921};\\\", \\\"{x:1308,y:645,t:1527030717939};\\\", \\\"{x:1385,y:645,t:1527030717956};\\\", \\\"{x:1458,y:645,t:1527030717972};\\\", \\\"{x:1529,y:640,t:1527030717989};\\\", \\\"{x:1571,y:640,t:1527030718005};\\\", \\\"{x:1602,y:640,t:1527030718021};\\\", \\\"{x:1624,y:640,t:1527030718039};\\\", \\\"{x:1641,y:640,t:1527030718055};\\\", \\\"{x:1653,y:640,t:1527030718072};\\\", \\\"{x:1659,y:640,t:1527030718089};\\\", \\\"{x:1662,y:640,t:1527030718105};\\\", \\\"{x:1658,y:640,t:1527030718210};\\\", \\\"{x:1648,y:641,t:1527030718222};\\\", \\\"{x:1625,y:642,t:1527030718239};\\\", \\\"{x:1581,y:650,t:1527030718256};\\\", \\\"{x:1521,y:656,t:1527030718272};\\\", \\\"{x:1440,y:665,t:1527030718290};\\\", \\\"{x:1309,y:667,t:1527030718305};\\\", \\\"{x:1207,y:667,t:1527030718323};\\\", \\\"{x:1110,y:667,t:1527030718339};\\\", \\\"{x:1029,y:667,t:1527030718356};\\\", \\\"{x:971,y:667,t:1527030718373};\\\", \\\"{x:926,y:667,t:1527030718389};\\\", \\\"{x:899,y:665,t:1527030718405};\\\", \\\"{x:891,y:661,t:1527030718423};\\\", \\\"{x:889,y:661,t:1527030718439};\\\", \\\"{x:888,y:662,t:1527030718530};\\\", \\\"{x:886,y:663,t:1527030718539};\\\", \\\"{x:877,y:666,t:1527030718555};\\\", \\\"{x:863,y:667,t:1527030718573};\\\", \\\"{x:839,y:669,t:1527030718588};\\\", \\\"{x:802,y:669,t:1527030718606};\\\", \\\"{x:756,y:669,t:1527030718623};\\\", \\\"{x:703,y:661,t:1527030718640};\\\", \\\"{x:655,y:654,t:1527030718656};\\\", \\\"{x:619,y:644,t:1527030718673};\\\", \\\"{x:586,y:634,t:1527030718690};\\\", \\\"{x:575,y:629,t:1527030718707};\\\", \\\"{x:569,y:627,t:1527030718722};\\\", \\\"{x:567,y:626,t:1527030718739};\\\", \\\"{x:566,y:625,t:1527030718768};\\\", \\\"{x:565,y:624,t:1527030718785};\\\", \\\"{x:565,y:623,t:1527030718801};\\\", \\\"{x:565,y:621,t:1527030718817};\\\", \\\"{x:565,y:620,t:1527030718825};\\\", \\\"{x:568,y:619,t:1527030718838};\\\", \\\"{x:578,y:616,t:1527030718855};\\\", \\\"{x:594,y:612,t:1527030718872};\\\", \\\"{x:618,y:606,t:1527030718889};\\\", \\\"{x:627,y:605,t:1527030718905};\\\", \\\"{x:628,y:605,t:1527030718922};\\\", \\\"{x:629,y:604,t:1527030718945};\\\", \\\"{x:628,y:604,t:1527030719146};\\\", \\\"{x:628,y:605,t:1527030719156};\\\", \\\"{x:627,y:607,t:1527030719173};\\\", \\\"{x:625,y:609,t:1527030719190};\\\", \\\"{x:623,y:611,t:1527030719205};\\\", \\\"{x:620,y:612,t:1527030719223};\\\", \\\"{x:619,y:612,t:1527030719240};\\\", \\\"{x:615,y:615,t:1527030719457};\\\", \\\"{x:613,y:634,t:1527030719473};\\\", \\\"{x:610,y:667,t:1527030719489};\\\", \\\"{x:607,y:698,t:1527030719506};\\\", \\\"{x:606,y:719,t:1527030719523};\\\", \\\"{x:602,y:733,t:1527030719539};\\\", \\\"{x:600,y:738,t:1527030719557};\\\", \\\"{x:598,y:739,t:1527030719573};\\\", \\\"{x:597,y:739,t:1527030719634};\\\", \\\"{x:594,y:739,t:1527030719641};\\\", \\\"{x:592,y:738,t:1527030719657};\\\", \\\"{x:583,y:737,t:1527030719673};\\\", \\\"{x:566,y:732,t:1527030719689};\\\", \\\"{x:550,y:726,t:1527030719708};\\\", \\\"{x:536,y:722,t:1527030719723};\\\", \\\"{x:525,y:718,t:1527030719740};\\\", \\\"{x:516,y:717,t:1527030719756};\\\", \\\"{x:513,y:717,t:1527030719773};\\\", \\\"{x:512,y:717,t:1527030719817};\\\", \\\"{x:511,y:718,t:1527030719978};\\\", \\\"{x:511,y:719,t:1527030719990};\\\", \\\"{x:510,y:725,t:1527030720008};\\\", \\\"{x:510,y:730,t:1527030720024};\\\", \\\"{x:510,y:735,t:1527030720039};\\\", \\\"{x:511,y:737,t:1527030720057};\\\", \\\"{x:512,y:737,t:1527030720074};\\\", \\\"{x:512,y:738,t:1527030720497};\\\", \\\"{x:512,y:740,t:1527030720529};\\\", \\\"{x:513,y:740,t:1527030720545};\\\", \\\"{x:514,y:740,t:1527030720561};\\\", \\\"{x:514,y:741,t:1527030720633};\\\", \\\"{x:515,y:742,t:1527030720674};\\\", \\\"{x:516,y:742,t:1527030721002};\\\", \\\"{x:517,y:742,t:1527030721009};\\\", \\\"{x:518,y:742,t:1527030721025};\\\", \\\"{x:520,y:742,t:1527030721042};\\\", \\\"{x:521,y:741,t:1527030721057};\\\", \\\"{x:522,y:741,t:1527030721074};\\\", \\\"{x:523,y:741,t:1527030721091};\\\", \\\"{x:524,y:740,t:1527030721108};\\\", \\\"{x:525,y:740,t:1527030721123};\\\", \\\"{x:526,y:740,t:1527030721141};\\\", \\\"{x:530,y:739,t:1527030721158};\\\", \\\"{x:533,y:738,t:1527030721174};\\\", \\\"{x:542,y:736,t:1527030721237};\\\", \\\"{x:545,y:735,t:1527030721261};\\\", \\\"{x:548,y:733,t:1527030721274};\\\", \\\"{x:552,y:732,t:1527030721290};\\\", \\\"{x:553,y:731,t:1527030721308};\\\", \\\"{x:555,y:731,t:1527030721325};\\\", \\\"{x:555,y:730,t:1527030721341};\\\", \\\"{x:557,y:729,t:1527030721358};\\\", \\\"{x:558,y:728,t:1527030721374};\\\", \\\"{x:559,y:727,t:1527030721401};\\\", \\\"{x:560,y:727,t:1527030721441};\\\", \\\"{x:561,y:726,t:1527030721465};\\\", \\\"{x:562,y:726,t:1527030721474};\\\", \\\"{x:563,y:725,t:1527030721491};\\\", \\\"{x:565,y:723,t:1527030721508};\\\", \\\"{x:566,y:721,t:1527030721525};\\\", \\\"{x:570,y:717,t:1527030721541};\\\", \\\"{x:574,y:713,t:1527030721558};\\\" ] }, { \\\"rt\\\": 50819, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 13, \\\"time_elapsed\\\": 556208, \\\"internal_node_id\\\": \\\"0.0-6.0-3.0\\\", \\\"subject\\\": \\\"Q0QHK\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"juliet\\\", \\\"condition\\\": \\\"115\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"starttime+before+endtime+during\\\", \\\"q\\\": 9, \\\"clicks\\\": 1, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XFull-YFull\\\", \\\"correct\\\": 1, \\\"orth_correct\\\": 1, \\\"answer\\\": [ \\\"I\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-B -J -J -B -M -M -B -O -O -B -4\\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:583,y:706,t:1527030721745};\\\", \\\"{x:586,y:704,t:1527030721918};\\\", \\\"{x:587,y:702,t:1527030721924};\\\", \\\"{x:587,y:700,t:1527030721941};\\\", \\\"{x:590,y:699,t:1527030721958};\\\", \\\"{x:590,y:697,t:1527030721975};\\\", \\\"{x:591,y:696,t:1527030722001};\\\", \\\"{x:592,y:696,t:1527030724906};\\\", \\\"{x:593,y:696,t:1527030725241};\\\", \\\"{x:595,y:696,t:1527030726593};\\\", \\\"{x:596,y:697,t:1527030727192};\\\", \\\"{x:596,y:698,t:1527030727201};\\\", \\\"{x:596,y:699,t:1527030728169};\\\", \\\"{x:595,y:700,t:1527030728209};\\\", \\\"{x:593,y:701,t:1527030728249};\\\", \\\"{x:597,y:701,t:1527030729808};\\\", \\\"{x:612,y:701,t:1527030729817};\\\", \\\"{x:639,y:701,t:1527030729831};\\\", \\\"{x:721,y:697,t:1527030729847};\\\", \\\"{x:831,y:689,t:1527030729864};\\\", \\\"{x:1052,y:689,t:1527030729881};\\\", \\\"{x:1216,y:697,t:1527030729897};\\\", \\\"{x:1379,y:719,t:1527030729914};\\\", \\\"{x:1523,y:738,t:1527030729931};\\\", \\\"{x:1642,y:752,t:1527030729947};\\\", \\\"{x:1726,y:767,t:1527030729964};\\\", \\\"{x:1776,y:775,t:1527030729981};\\\", \\\"{x:1813,y:780,t:1527030729997};\\\", \\\"{x:1834,y:782,t:1527030730014};\\\", \\\"{x:1841,y:783,t:1527030730031};\\\", \\\"{x:1844,y:785,t:1527030730048};\\\", \\\"{x:1844,y:786,t:1527030730209};\\\", \\\"{x:1843,y:786,t:1527030730217};\\\", \\\"{x:1842,y:787,t:1527030730231};\\\", \\\"{x:1840,y:787,t:1527030730249};\\\", \\\"{x:1839,y:788,t:1527030730264};\\\", \\\"{x:1837,y:788,t:1527030730361};\\\", \\\"{x:1836,y:789,t:1527030730449};\\\", \\\"{x:1835,y:789,t:1527030730529};\\\", \\\"{x:1833,y:790,t:1527030731481};\\\", \\\"{x:1832,y:792,t:1527030731489};\\\", \\\"{x:1830,y:793,t:1527030731504};\\\", \\\"{x:1828,y:793,t:1527030731515};\\\", \\\"{x:1825,y:793,t:1527030731532};\\\", \\\"{x:1823,y:795,t:1527030731548};\\\", \\\"{x:1820,y:795,t:1527030731565};\\\", \\\"{x:1819,y:796,t:1527030731582};\\\", \\\"{x:1817,y:796,t:1527030731601};\\\", \\\"{x:1816,y:796,t:1527030731713};\\\", \\\"{x:1814,y:798,t:1527030731720};\\\", \\\"{x:1813,y:798,t:1527030731732};\\\", \\\"{x:1799,y:799,t:1527030731749};\\\", \\\"{x:1768,y:799,t:1527030731765};\\\", \\\"{x:1715,y:799,t:1527030731782};\\\", \\\"{x:1636,y:794,t:1527030731799};\\\", \\\"{x:1562,y:789,t:1527030731815};\\\", \\\"{x:1494,y:786,t:1527030731832};\\\", \\\"{x:1409,y:773,t:1527030731849};\\\", \\\"{x:1377,y:769,t:1527030731865};\\\", \\\"{x:1348,y:767,t:1527030731882};\\\", \\\"{x:1324,y:772,t:1527030731899};\\\", \\\"{x:1312,y:774,t:1527030731915};\\\", \\\"{x:1310,y:775,t:1527030731932};\\\", \\\"{x:1309,y:776,t:1527030731949};\\\", \\\"{x:1307,y:778,t:1527030731968};\\\", \\\"{x:1304,y:780,t:1527030731982};\\\", \\\"{x:1295,y:784,t:1527030731999};\\\", \\\"{x:1283,y:789,t:1527030732015};\\\", \\\"{x:1273,y:794,t:1527030732032};\\\", \\\"{x:1256,y:803,t:1527030732048};\\\", \\\"{x:1249,y:809,t:1527030732065};\\\", \\\"{x:1241,y:814,t:1527030732082};\\\", \\\"{x:1233,y:819,t:1527030732099};\\\", \\\"{x:1226,y:822,t:1527030732115};\\\", \\\"{x:1220,y:824,t:1527030732132};\\\", \\\"{x:1213,y:827,t:1527030732149};\\\", \\\"{x:1209,y:829,t:1527030732166};\\\", \\\"{x:1204,y:830,t:1527030732183};\\\", \\\"{x:1200,y:830,t:1527030732199};\\\", \\\"{x:1199,y:831,t:1527030732657};\\\", \\\"{x:1199,y:832,t:1527030732681};\\\", \\\"{x:1199,y:833,t:1527030732697};\\\", \\\"{x:1199,y:834,t:1527030732713};\\\", \\\"{x:1200,y:835,t:1527030732720};\\\", \\\"{x:1201,y:836,t:1527030732737};\\\", \\\"{x:1202,y:836,t:1527030732760};\\\", \\\"{x:1203,y:836,t:1527030732777};\\\", \\\"{x:1204,y:836,t:1527030732849};\\\", \\\"{x:1205,y:836,t:1527030732920};\\\", \\\"{x:1207,y:836,t:1527030732937};\\\", \\\"{x:1208,y:835,t:1527030732977};\\\", \\\"{x:1209,y:835,t:1527030732993};\\\", \\\"{x:1210,y:835,t:1527030733009};\\\", \\\"{x:1210,y:834,t:1527030733017};\\\", \\\"{x:1212,y:834,t:1527030733049};\\\", \\\"{x:1213,y:833,t:1527030733067};\\\", \\\"{x:1213,y:832,t:1527030733161};\\\", \\\"{x:1213,y:829,t:1527030747346};\\\", \\\"{x:1213,y:826,t:1527030747360};\\\", \\\"{x:1217,y:820,t:1527030747378};\\\", \\\"{x:1218,y:817,t:1527030747395};\\\", \\\"{x:1220,y:813,t:1527030747411};\\\", \\\"{x:1222,y:811,t:1527030747427};\\\", \\\"{x:1222,y:809,t:1527030747444};\\\", \\\"{x:1222,y:806,t:1527030747461};\\\", \\\"{x:1224,y:804,t:1527030747477};\\\", \\\"{x:1224,y:800,t:1527030747494};\\\", \\\"{x:1224,y:799,t:1527030747513};\\\", \\\"{x:1225,y:796,t:1527030747528};\\\", \\\"{x:1227,y:791,t:1527030747545};\\\", \\\"{x:1228,y:785,t:1527030747561};\\\", \\\"{x:1231,y:779,t:1527030747578};\\\", \\\"{x:1232,y:776,t:1527030747594};\\\", \\\"{x:1233,y:771,t:1527030747611};\\\", \\\"{x:1233,y:769,t:1527030747633};\\\", \\\"{x:1233,y:767,t:1527030747644};\\\", \\\"{x:1233,y:765,t:1527030747688};\\\", \\\"{x:1233,y:764,t:1527030747728};\\\", \\\"{x:1233,y:762,t:1527030747761};\\\", \\\"{x:1235,y:760,t:1527030747776};\\\", \\\"{x:1235,y:759,t:1527030747794};\\\", \\\"{x:1235,y:758,t:1527030747811};\\\", \\\"{x:1235,y:757,t:1527030747827};\\\", \\\"{x:1235,y:756,t:1527030747844};\\\", \\\"{x:1235,y:755,t:1527030747861};\\\", \\\"{x:1235,y:754,t:1527030747882};\\\", \\\"{x:1235,y:753,t:1527030747895};\\\", \\\"{x:1235,y:752,t:1527030747930};\\\", \\\"{x:1235,y:751,t:1527030747945};\\\", \\\"{x:1235,y:750,t:1527030747962};\\\", \\\"{x:1235,y:749,t:1527030747979};\\\", \\\"{x:1235,y:748,t:1527030747994};\\\", \\\"{x:1235,y:747,t:1527030748011};\\\", \\\"{x:1235,y:746,t:1527030748057};\\\", \\\"{x:1235,y:745,t:1527030748074};\\\", \\\"{x:1235,y:744,t:1527030748097};\\\", \\\"{x:1235,y:743,t:1527030748137};\\\", \\\"{x:1235,y:742,t:1527030748153};\\\", \\\"{x:1235,y:741,t:1527030748250};\\\", \\\"{x:1236,y:739,t:1527030748262};\\\", \\\"{x:1237,y:741,t:1527030748858};\\\", \\\"{x:1238,y:743,t:1527030748865};\\\", \\\"{x:1239,y:744,t:1527030748879};\\\", \\\"{x:1242,y:748,t:1527030748896};\\\", \\\"{x:1244,y:752,t:1527030748912};\\\", \\\"{x:1246,y:753,t:1527030748929};\\\", \\\"{x:1247,y:753,t:1527030748945};\\\", \\\"{x:1249,y:754,t:1527030749289};\\\", \\\"{x:1250,y:757,t:1527030749297};\\\", \\\"{x:1253,y:757,t:1527030749312};\\\", \\\"{x:1255,y:758,t:1527030749329};\\\", \\\"{x:1258,y:758,t:1527030749345};\\\", \\\"{x:1263,y:759,t:1527030749363};\\\", \\\"{x:1267,y:759,t:1527030749379};\\\", \\\"{x:1272,y:759,t:1527030749396};\\\", \\\"{x:1277,y:761,t:1527030749412};\\\", \\\"{x:1279,y:761,t:1527030749429};\\\", \\\"{x:1283,y:762,t:1527030749445};\\\", \\\"{x:1285,y:762,t:1527030749462};\\\", \\\"{x:1287,y:762,t:1527030749479};\\\", \\\"{x:1288,y:762,t:1527030749496};\\\", \\\"{x:1290,y:762,t:1527030749513};\\\", \\\"{x:1291,y:762,t:1527030749529};\\\", \\\"{x:1295,y:762,t:1527030749546};\\\", \\\"{x:1298,y:763,t:1527030749563};\\\", \\\"{x:1303,y:763,t:1527030749579};\\\", \\\"{x:1308,y:765,t:1527030749595};\\\", \\\"{x:1310,y:765,t:1527030749613};\\\", \\\"{x:1313,y:765,t:1527030749629};\\\", \\\"{x:1316,y:765,t:1527030749645};\\\", \\\"{x:1319,y:766,t:1527030749662};\\\", \\\"{x:1320,y:766,t:1527030749679};\\\", \\\"{x:1322,y:766,t:1527030749695};\\\", \\\"{x:1325,y:766,t:1527030749712};\\\", \\\"{x:1327,y:766,t:1527030749729};\\\", \\\"{x:1329,y:766,t:1527030749745};\\\", \\\"{x:1330,y:766,t:1527030749776};\\\", \\\"{x:1331,y:766,t:1527030749784};\\\", \\\"{x:1332,y:766,t:1527030749801};\\\", \\\"{x:1334,y:766,t:1527030749833};\\\", \\\"{x:1335,y:766,t:1527030749846};\\\", \\\"{x:1339,y:766,t:1527030749862};\\\", \\\"{x:1341,y:766,t:1527030749879};\\\", \\\"{x:1342,y:766,t:1527030749897};\\\", \\\"{x:1344,y:766,t:1527030749912};\\\", \\\"{x:1345,y:768,t:1527030750210};\\\", \\\"{x:1345,y:769,t:1527030750218};\\\", \\\"{x:1345,y:771,t:1527030750230};\\\", \\\"{x:1345,y:775,t:1527030750246};\\\", \\\"{x:1345,y:778,t:1527030750263};\\\", \\\"{x:1345,y:783,t:1527030750279};\\\", \\\"{x:1344,y:787,t:1527030750296};\\\", \\\"{x:1344,y:800,t:1527030750313};\\\", \\\"{x:1344,y:815,t:1527030750330};\\\", \\\"{x:1344,y:830,t:1527030750347};\\\", \\\"{x:1344,y:844,t:1527030750364};\\\", \\\"{x:1347,y:858,t:1527030750380};\\\", \\\"{x:1350,y:874,t:1527030750396};\\\", \\\"{x:1352,y:890,t:1527030750414};\\\", \\\"{x:1355,y:906,t:1527030750429};\\\", \\\"{x:1356,y:924,t:1527030750447};\\\", \\\"{x:1357,y:939,t:1527030750464};\\\", \\\"{x:1357,y:953,t:1527030750479};\\\", \\\"{x:1360,y:967,t:1527030750496};\\\", \\\"{x:1362,y:985,t:1527030750513};\\\", \\\"{x:1362,y:996,t:1527030750529};\\\", \\\"{x:1364,y:1008,t:1527030750546};\\\", \\\"{x:1364,y:1014,t:1527030750564};\\\", \\\"{x:1364,y:1018,t:1527030750580};\\\", \\\"{x:1364,y:1020,t:1527030750597};\\\", \\\"{x:1364,y:1021,t:1527030750634};\\\", \\\"{x:1364,y:1020,t:1527030750752};\\\", \\\"{x:1363,y:1019,t:1527030750763};\\\", \\\"{x:1363,y:1018,t:1527030750780};\\\", \\\"{x:1363,y:1017,t:1527030750796};\\\", \\\"{x:1363,y:1015,t:1527030750813};\\\", \\\"{x:1363,y:1014,t:1527030750840};\\\", \\\"{x:1363,y:1012,t:1527030750938};\\\", \\\"{x:1363,y:1011,t:1527030750962};\\\", \\\"{x:1363,y:1009,t:1527030750986};\\\", \\\"{x:1363,y:1007,t:1527030751001};\\\", \\\"{x:1364,y:1007,t:1527030751013};\\\", \\\"{x:1365,y:1006,t:1527030751031};\\\", \\\"{x:1366,y:1004,t:1527030751046};\\\", \\\"{x:1368,y:1004,t:1527030751063};\\\", \\\"{x:1368,y:1003,t:1527030751097};\\\", \\\"{x:1369,y:1002,t:1527030751113};\\\", \\\"{x:1370,y:1001,t:1527030751138};\\\", \\\"{x:1371,y:999,t:1527030751202};\\\", \\\"{x:1371,y:997,t:1527030751233};\\\", \\\"{x:1371,y:996,t:1527030751246};\\\", \\\"{x:1372,y:992,t:1527030751263};\\\", \\\"{x:1375,y:983,t:1527030751280};\\\", \\\"{x:1375,y:962,t:1527030751296};\\\", \\\"{x:1375,y:943,t:1527030751313};\\\", \\\"{x:1375,y:927,t:1527030751330};\\\", \\\"{x:1376,y:911,t:1527030751347};\\\", \\\"{x:1376,y:899,t:1527030751363};\\\", \\\"{x:1379,y:883,t:1527030751381};\\\", \\\"{x:1380,y:867,t:1527030751397};\\\", \\\"{x:1380,y:852,t:1527030751413};\\\", \\\"{x:1380,y:837,t:1527030751430};\\\", \\\"{x:1380,y:825,t:1527030751448};\\\", \\\"{x:1379,y:814,t:1527030751463};\\\", \\\"{x:1378,y:809,t:1527030751480};\\\", \\\"{x:1373,y:796,t:1527030751497};\\\", \\\"{x:1371,y:792,t:1527030751513};\\\", \\\"{x:1370,y:790,t:1527030751530};\\\", \\\"{x:1368,y:786,t:1527030751547};\\\", \\\"{x:1366,y:782,t:1527030751563};\\\", \\\"{x:1363,y:778,t:1527030751580};\\\", \\\"{x:1361,y:775,t:1527030751597};\\\", \\\"{x:1359,y:770,t:1527030751613};\\\", \\\"{x:1357,y:769,t:1527030751630};\\\", \\\"{x:1357,y:768,t:1527030751647};\\\", \\\"{x:1356,y:768,t:1527030751663};\\\", \\\"{x:1355,y:767,t:1527030751680};\\\", \\\"{x:1354,y:766,t:1527030751698};\\\", \\\"{x:1353,y:764,t:1527030751714};\\\", \\\"{x:1352,y:763,t:1527030751730};\\\", \\\"{x:1350,y:763,t:1527030751748};\\\", \\\"{x:1349,y:762,t:1527030751765};\\\", \\\"{x:1348,y:761,t:1527030751833};\\\", \\\"{x:1348,y:762,t:1527030751848};\\\", \\\"{x:1347,y:776,t:1527030751864};\\\", \\\"{x:1347,y:795,t:1527030751880};\\\", \\\"{x:1346,y:821,t:1527030751897};\\\", \\\"{x:1346,y:835,t:1527030751914};\\\", \\\"{x:1346,y:848,t:1527030751930};\\\", \\\"{x:1346,y:860,t:1527030751947};\\\", \\\"{x:1346,y:865,t:1527030751964};\\\", \\\"{x:1346,y:867,t:1527030751980};\\\", \\\"{x:1346,y:866,t:1527030752057};\\\", \\\"{x:1348,y:862,t:1527030752065};\\\", \\\"{x:1351,y:852,t:1527030752080};\\\", \\\"{x:1362,y:823,t:1527030752096};\\\", \\\"{x:1367,y:809,t:1527030752114};\\\", \\\"{x:1371,y:799,t:1527030752130};\\\", \\\"{x:1372,y:793,t:1527030752147};\\\", \\\"{x:1372,y:790,t:1527030752165};\\\", \\\"{x:1372,y:789,t:1527030752181};\\\", \\\"{x:1372,y:786,t:1527030752197};\\\", \\\"{x:1372,y:784,t:1527030752215};\\\", \\\"{x:1373,y:782,t:1527030752231};\\\", \\\"{x:1374,y:782,t:1527030752247};\\\", \\\"{x:1374,y:781,t:1527030752264};\\\", \\\"{x:1376,y:779,t:1527030752280};\\\", \\\"{x:1377,y:779,t:1527030752297};\\\", \\\"{x:1379,y:778,t:1527030752314};\\\", \\\"{x:1382,y:776,t:1527030752331};\\\", \\\"{x:1386,y:776,t:1527030752347};\\\", \\\"{x:1391,y:774,t:1527030752364};\\\", \\\"{x:1395,y:772,t:1527030752381};\\\", \\\"{x:1399,y:771,t:1527030752397};\\\", \\\"{x:1402,y:770,t:1527030752414};\\\", \\\"{x:1404,y:769,t:1527030752431};\\\", \\\"{x:1405,y:769,t:1527030752449};\\\", \\\"{x:1406,y:769,t:1527030752473};\\\", \\\"{x:1407,y:768,t:1527030752481};\\\", \\\"{x:1409,y:767,t:1527030752497};\\\", \\\"{x:1411,y:766,t:1527030752514};\\\", \\\"{x:1413,y:765,t:1527030752532};\\\", \\\"{x:1414,y:765,t:1527030752548};\\\", \\\"{x:1415,y:764,t:1527030752564};\\\", \\\"{x:1417,y:764,t:1527030752650};\\\", \\\"{x:1418,y:764,t:1527030752665};\\\", \\\"{x:1425,y:764,t:1527030752681};\\\", \\\"{x:1435,y:764,t:1527030752698};\\\", \\\"{x:1453,y:764,t:1527030752714};\\\", \\\"{x:1472,y:764,t:1527030752731};\\\", \\\"{x:1491,y:764,t:1527030752748};\\\", \\\"{x:1505,y:764,t:1527030752765};\\\", \\\"{x:1512,y:764,t:1527030752782};\\\", \\\"{x:1514,y:764,t:1527030752798};\\\", \\\"{x:1512,y:764,t:1527030752944};\\\", \\\"{x:1511,y:764,t:1527030752952};\\\", \\\"{x:1509,y:764,t:1527030752969};\\\", \\\"{x:1507,y:766,t:1527030752982};\\\", \\\"{x:1504,y:766,t:1527030752998};\\\", \\\"{x:1501,y:766,t:1527030753014};\\\", \\\"{x:1499,y:766,t:1527030753031};\\\", \\\"{x:1497,y:766,t:1527030753048};\\\", \\\"{x:1495,y:766,t:1527030753064};\\\", \\\"{x:1492,y:766,t:1527030753080};\\\", \\\"{x:1491,y:766,t:1527030753098};\\\", \\\"{x:1490,y:766,t:1527030753114};\\\", \\\"{x:1489,y:765,t:1527030753258};\\\", \\\"{x:1491,y:765,t:1527030753434};\\\", \\\"{x:1492,y:765,t:1527030753449};\\\", \\\"{x:1499,y:764,t:1527030753464};\\\", \\\"{x:1506,y:764,t:1527030753481};\\\", \\\"{x:1514,y:764,t:1527030753498};\\\", \\\"{x:1525,y:764,t:1527030753515};\\\", \\\"{x:1538,y:764,t:1527030753530};\\\", \\\"{x:1544,y:764,t:1527030753548};\\\", \\\"{x:1548,y:764,t:1527030753565};\\\", \\\"{x:1549,y:764,t:1527030753581};\\\", \\\"{x:1550,y:764,t:1527030753598};\\\", \\\"{x:1551,y:764,t:1527030753641};\\\", \\\"{x:1552,y:764,t:1527030753673};\\\", \\\"{x:1553,y:764,t:1527030753834};\\\", \\\"{x:1550,y:764,t:1527030755466};\\\", \\\"{x:1540,y:766,t:1527030755484};\\\", \\\"{x:1526,y:767,t:1527030755500};\\\", \\\"{x:1508,y:769,t:1527030755517};\\\", \\\"{x:1492,y:772,t:1527030755533};\\\", \\\"{x:1480,y:772,t:1527030755551};\\\", \\\"{x:1470,y:772,t:1527030755567};\\\", \\\"{x:1464,y:772,t:1527030755584};\\\", \\\"{x:1458,y:772,t:1527030755601};\\\", \\\"{x:1452,y:772,t:1527030755617};\\\", \\\"{x:1440,y:772,t:1527030755634};\\\", \\\"{x:1435,y:772,t:1527030755651};\\\", \\\"{x:1429,y:772,t:1527030755667};\\\", \\\"{x:1427,y:772,t:1527030755683};\\\", \\\"{x:1424,y:772,t:1527030755701};\\\", \\\"{x:1421,y:772,t:1527030755716};\\\", \\\"{x:1420,y:772,t:1527030755733};\\\", \\\"{x:1418,y:772,t:1527030755751};\\\", \\\"{x:1417,y:772,t:1527030755769};\\\", \\\"{x:1416,y:771,t:1527030755809};\\\", \\\"{x:1415,y:771,t:1527030755898};\\\", \\\"{x:1415,y:769,t:1527030755922};\\\", \\\"{x:1416,y:769,t:1527030755937};\\\", \\\"{x:1418,y:768,t:1527030755953};\\\", \\\"{x:1419,y:767,t:1527030755977};\\\", \\\"{x:1420,y:766,t:1527030755985};\\\", \\\"{x:1421,y:766,t:1527030756001};\\\", \\\"{x:1423,y:766,t:1527030756017};\\\", \\\"{x:1425,y:765,t:1527030756034};\\\", \\\"{x:1427,y:764,t:1527030756051};\\\", \\\"{x:1431,y:762,t:1527030756068};\\\", \\\"{x:1435,y:762,t:1527030756084};\\\", \\\"{x:1441,y:759,t:1527030756101};\\\", \\\"{x:1446,y:759,t:1527030756127};\\\", \\\"{x:1451,y:758,t:1527030756144};\\\", \\\"{x:1455,y:758,t:1527030756161};\\\", \\\"{x:1458,y:758,t:1527030756178};\\\", \\\"{x:1459,y:758,t:1527030756194};\\\", \\\"{x:1460,y:758,t:1527030756211};\\\", \\\"{x:1461,y:758,t:1527030756227};\\\", \\\"{x:1462,y:758,t:1527030756251};\\\", \\\"{x:1463,y:758,t:1527030756267};\\\", \\\"{x:1464,y:758,t:1527030756277};\\\", \\\"{x:1465,y:758,t:1527030756298};\\\", \\\"{x:1466,y:758,t:1527030756310};\\\", \\\"{x:1468,y:758,t:1527030756327};\\\", \\\"{x:1470,y:758,t:1527030756343};\\\", \\\"{x:1474,y:758,t:1527030756360};\\\", \\\"{x:1477,y:758,t:1527030756377};\\\", \\\"{x:1479,y:759,t:1527030756393};\\\", \\\"{x:1481,y:759,t:1527030757003};\\\", \\\"{x:1484,y:759,t:1527030757011};\\\", \\\"{x:1492,y:762,t:1527030757028};\\\", \\\"{x:1507,y:764,t:1527030757045};\\\", \\\"{x:1520,y:765,t:1527030757061};\\\", \\\"{x:1530,y:765,t:1527030757078};\\\", \\\"{x:1536,y:767,t:1527030757094};\\\", \\\"{x:1537,y:767,t:1527030757112};\\\", \\\"{x:1538,y:767,t:1527030757127};\\\", \\\"{x:1539,y:767,t:1527030757195};\\\", \\\"{x:1540,y:767,t:1527030757212};\\\", \\\"{x:1541,y:767,t:1527030757228};\\\", \\\"{x:1542,y:767,t:1527030757307};\\\", \\\"{x:1543,y:767,t:1527030757323};\\\", \\\"{x:1544,y:767,t:1527030757331};\\\", \\\"{x:1545,y:767,t:1527030757363};\\\", \\\"{x:1546,y:766,t:1527030757395};\\\", \\\"{x:1547,y:766,t:1527030757411};\\\", \\\"{x:1543,y:767,t:1527030763827};\\\", \\\"{x:1534,y:770,t:1527030763836};\\\", \\\"{x:1527,y:771,t:1527030763850};\\\", \\\"{x:1504,y:774,t:1527030763866};\\\", \\\"{x:1462,y:774,t:1527030763882};\\\", \\\"{x:1429,y:774,t:1527030763899};\\\", \\\"{x:1385,y:774,t:1527030763916};\\\", \\\"{x:1340,y:774,t:1527030763933};\\\", \\\"{x:1306,y:770,t:1527030763950};\\\", \\\"{x:1276,y:765,t:1527030763966};\\\", \\\"{x:1254,y:762,t:1527030763983};\\\", \\\"{x:1240,y:761,t:1527030763999};\\\", \\\"{x:1235,y:761,t:1527030764015};\\\", \\\"{x:1234,y:761,t:1527030764032};\\\", \\\"{x:1234,y:760,t:1527030764282};\\\", \\\"{x:1235,y:758,t:1527030764299};\\\", \\\"{x:1240,y:757,t:1527030764316};\\\", \\\"{x:1246,y:757,t:1527030764332};\\\", \\\"{x:1251,y:757,t:1527030764349};\\\", \\\"{x:1258,y:757,t:1527030764366};\\\", \\\"{x:1265,y:757,t:1527030764382};\\\", \\\"{x:1271,y:757,t:1527030764399};\\\", \\\"{x:1277,y:757,t:1527030764416};\\\", \\\"{x:1281,y:757,t:1527030764433};\\\", \\\"{x:1285,y:757,t:1527030764449};\\\", \\\"{x:1291,y:757,t:1527030764466};\\\", \\\"{x:1293,y:757,t:1527030764482};\\\", \\\"{x:1296,y:757,t:1527030764499};\\\", \\\"{x:1299,y:757,t:1527030764516};\\\", \\\"{x:1302,y:757,t:1527030764532};\\\", \\\"{x:1304,y:757,t:1527030764549};\\\", \\\"{x:1306,y:757,t:1527030764567};\\\", \\\"{x:1309,y:757,t:1527030764582};\\\", \\\"{x:1312,y:757,t:1527030764599};\\\", \\\"{x:1315,y:757,t:1527030764616};\\\", \\\"{x:1318,y:757,t:1527030764632};\\\", \\\"{x:1321,y:757,t:1527030764650};\\\", \\\"{x:1324,y:757,t:1527030764667};\\\", \\\"{x:1325,y:757,t:1527030764683};\\\", \\\"{x:1327,y:756,t:1527030764931};\\\", \\\"{x:1329,y:756,t:1527030764939};\\\", \\\"{x:1333,y:756,t:1527030764950};\\\", \\\"{x:1341,y:756,t:1527030764967};\\\", \\\"{x:1351,y:756,t:1527030764984};\\\", \\\"{x:1363,y:758,t:1527030765000};\\\", \\\"{x:1372,y:759,t:1527030765017};\\\", \\\"{x:1379,y:760,t:1527030765034};\\\", \\\"{x:1381,y:760,t:1527030765050};\\\", \\\"{x:1382,y:760,t:1527030765067};\\\", \\\"{x:1383,y:760,t:1527030765083};\\\", \\\"{x:1384,y:760,t:1527030765115};\\\", \\\"{x:1385,y:760,t:1527030765131};\\\", \\\"{x:1386,y:760,t:1527030765139};\\\", \\\"{x:1387,y:760,t:1527030765151};\\\", \\\"{x:1387,y:762,t:1527030767811};\\\", \\\"{x:1386,y:762,t:1527030767819};\\\", \\\"{x:1380,y:762,t:1527030767836};\\\", \\\"{x:1370,y:764,t:1527030767852};\\\", \\\"{x:1358,y:764,t:1527030767869};\\\", \\\"{x:1349,y:764,t:1527030767887};\\\", \\\"{x:1343,y:764,t:1527030767902};\\\", \\\"{x:1335,y:764,t:1527030767920};\\\", \\\"{x:1326,y:764,t:1527030767936};\\\", \\\"{x:1318,y:764,t:1527030767952};\\\", \\\"{x:1310,y:764,t:1527030767969};\\\", \\\"{x:1294,y:764,t:1527030767986};\\\", \\\"{x:1268,y:764,t:1527030768002};\\\", \\\"{x:1246,y:756,t:1527030768018};\\\", \\\"{x:1221,y:749,t:1527030768036};\\\", \\\"{x:1196,y:743,t:1527030768053};\\\", \\\"{x:1167,y:732,t:1527030768069};\\\", \\\"{x:1139,y:725,t:1527030768086};\\\", \\\"{x:1112,y:717,t:1527030768104};\\\", \\\"{x:1085,y:708,t:1527030768119};\\\", \\\"{x:1060,y:702,t:1527030768136};\\\", \\\"{x:1033,y:692,t:1527030768154};\\\", \\\"{x:1010,y:686,t:1527030768170};\\\", \\\"{x:987,y:679,t:1527030768187};\\\", \\\"{x:954,y:669,t:1527030768203};\\\", \\\"{x:939,y:665,t:1527030768219};\\\", \\\"{x:926,y:659,t:1527030768236};\\\", \\\"{x:909,y:652,t:1527030768253};\\\", \\\"{x:890,y:643,t:1527030768269};\\\", \\\"{x:869,y:637,t:1527030768286};\\\", \\\"{x:844,y:629,t:1527030768305};\\\", \\\"{x:815,y:620,t:1527030768318};\\\", \\\"{x:782,y:611,t:1527030768336};\\\", \\\"{x:718,y:600,t:1527030768356};\\\", \\\"{x:670,y:592,t:1527030768373};\\\", \\\"{x:634,y:588,t:1527030768389};\\\", \\\"{x:599,y:584,t:1527030768406};\\\", \\\"{x:570,y:582,t:1527030768423};\\\", \\\"{x:546,y:580,t:1527030768438};\\\", \\\"{x:521,y:580,t:1527030768455};\\\", \\\"{x:498,y:580,t:1527030768473};\\\", \\\"{x:473,y:580,t:1527030768490};\\\", \\\"{x:441,y:578,t:1527030768505};\\\", \\\"{x:368,y:565,t:1527030768522};\\\", \\\"{x:328,y:561,t:1527030768540};\\\", \\\"{x:285,y:557,t:1527030768555};\\\", \\\"{x:254,y:555,t:1527030768573};\\\", \\\"{x:225,y:551,t:1527030768590};\\\", \\\"{x:207,y:550,t:1527030768605};\\\", \\\"{x:199,y:549,t:1527030768622};\\\", \\\"{x:195,y:549,t:1527030768640};\\\", \\\"{x:192,y:549,t:1527030768655};\\\", \\\"{x:191,y:549,t:1527030768673};\\\", \\\"{x:189,y:549,t:1527030768690};\\\", \\\"{x:187,y:550,t:1527030768705};\\\", \\\"{x:185,y:553,t:1527030768722};\\\", \\\"{x:183,y:555,t:1527030768739};\\\", \\\"{x:182,y:559,t:1527030768756};\\\", \\\"{x:181,y:563,t:1527030768773};\\\", \\\"{x:181,y:566,t:1527030768790};\\\", \\\"{x:181,y:568,t:1527030768805};\\\", \\\"{x:181,y:570,t:1527030768823};\\\", \\\"{x:181,y:568,t:1527030768954};\\\", \\\"{x:181,y:567,t:1527030768963};\\\", \\\"{x:181,y:565,t:1527030768973};\\\", \\\"{x:180,y:560,t:1527030768990};\\\", \\\"{x:178,y:557,t:1527030769005};\\\", \\\"{x:177,y:551,t:1527030769022};\\\", \\\"{x:175,y:547,t:1527030769039};\\\", \\\"{x:173,y:541,t:1527030769056};\\\", \\\"{x:172,y:536,t:1527030769072};\\\", \\\"{x:170,y:531,t:1527030769089};\\\", \\\"{x:168,y:520,t:1527030769107};\\\", \\\"{x:166,y:514,t:1527030769123};\\\", \\\"{x:165,y:509,t:1527030769140};\\\", \\\"{x:163,y:505,t:1527030769156};\\\", \\\"{x:163,y:503,t:1527030769172};\\\", \\\"{x:162,y:502,t:1527030769189};\\\", \\\"{x:162,y:500,t:1527030769207};\\\", \\\"{x:162,y:499,t:1527030769290};\\\", \\\"{x:162,y:498,t:1527030769440};\\\", \\\"{x:165,y:496,t:1527030769456};\\\", \\\"{x:166,y:496,t:1527030769634};\\\", \\\"{x:167,y:497,t:1527030769643};\\\", \\\"{x:170,y:500,t:1527030769657};\\\", \\\"{x:180,y:511,t:1527030769674};\\\", \\\"{x:193,y:523,t:1527030769690};\\\", \\\"{x:223,y:544,t:1527030769707};\\\", \\\"{x:252,y:562,t:1527030769724};\\\", \\\"{x:287,y:582,t:1527030769739};\\\", \\\"{x:319,y:599,t:1527030769757};\\\", \\\"{x:356,y:619,t:1527030769774};\\\", \\\"{x:389,y:638,t:1527030769791};\\\", \\\"{x:424,y:668,t:1527030769808};\\\", \\\"{x:454,y:691,t:1527030769824};\\\", \\\"{x:477,y:708,t:1527030769840};\\\", \\\"{x:500,y:723,t:1527030769858};\\\", \\\"{x:517,y:734,t:1527030769874};\\\", \\\"{x:536,y:745,t:1527030769890};\\\", \\\"{x:545,y:751,t:1527030769906};\\\", \\\"{x:548,y:754,t:1527030769924};\\\", \\\"{x:549,y:754,t:1527030770987};\\\", \\\"{x:549,y:753,t:1527030771067};\\\", \\\"{x:549,y:752,t:1527030771083};\\\", \\\"{x:549,y:751,t:1527030771115};\\\", \\\"{x:549,y:750,t:1527030771155};\\\", \\\"{x:549,y:749,t:1527030771195};\\\", \\\"{x:549,y:748,t:1527030771227};\\\", \\\"{x:549,y:747,t:1527030771331};\\\" ] }, { \\\"rt\\\": 75265, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 14, \\\"time_elapsed\\\": 632675, \\\"internal_node_id\\\": \\\"0.0-6.0-4.0\\\", \\\"subject\\\": \\\"Q0QHK\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"juliet\\\", \\\"condition\\\": \\\"115\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"ends\\\", \\\"q\\\": 10, \\\"clicks\\\": 1, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XFull-YFull\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 1, \\\"answer\\\": [ \\\"X\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-B -B -02 PM-03 PM-04 PM-04 PM-10 AM-O -O -O -Z -Z -B -B -F -G \\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:550,y:746,t:1527030777547};\\\", \\\"{x:553,y:745,t:1527030777567};\\\", \\\"{x:555,y:744,t:1527030777580};\\\", \\\"{x:557,y:744,t:1527030777597};\\\", \\\"{x:557,y:743,t:1527030777634};\\\", \\\"{x:558,y:743,t:1527030777646};\\\", \\\"{x:559,y:743,t:1527030777673};\\\", \\\"{x:559,y:742,t:1527030777682};\\\", \\\"{x:560,y:742,t:1527030777698};\\\", \\\"{x:561,y:741,t:1527030777713};\\\", \\\"{x:564,y:741,t:1527030777730};\\\", \\\"{x:568,y:740,t:1527030777748};\\\", \\\"{x:572,y:738,t:1527030777762};\\\", \\\"{x:579,y:737,t:1527030777779};\\\", \\\"{x:586,y:737,t:1527030777795};\\\", \\\"{x:592,y:737,t:1527030777812};\\\", \\\"{x:597,y:737,t:1527030777829};\\\", \\\"{x:603,y:737,t:1527030777845};\\\", \\\"{x:608,y:737,t:1527030777861};\\\", \\\"{x:614,y:737,t:1527030777878};\\\", \\\"{x:618,y:737,t:1527030777895};\\\", \\\"{x:622,y:737,t:1527030777911};\\\", \\\"{x:626,y:737,t:1527030777929};\\\", \\\"{x:637,y:737,t:1527030777946};\\\", \\\"{x:647,y:737,t:1527030777962};\\\", \\\"{x:662,y:737,t:1527030777979};\\\", \\\"{x:680,y:737,t:1527030777996};\\\", \\\"{x:699,y:737,t:1527030778012};\\\", \\\"{x:720,y:739,t:1527030778029};\\\", \\\"{x:740,y:741,t:1527030778046};\\\", \\\"{x:764,y:744,t:1527030778062};\\\", \\\"{x:787,y:749,t:1527030778080};\\\", \\\"{x:811,y:755,t:1527030778096};\\\", \\\"{x:838,y:761,t:1527030778112};\\\", \\\"{x:868,y:769,t:1527030778129};\\\", \\\"{x:934,y:783,t:1527030778147};\\\", \\\"{x:978,y:795,t:1527030778162};\\\", \\\"{x:1017,y:808,t:1527030778179};\\\", \\\"{x:1078,y:825,t:1527030778197};\\\", \\\"{x:1150,y:845,t:1527030778214};\\\", \\\"{x:1235,y:866,t:1527030778229};\\\", \\\"{x:1304,y:880,t:1527030778246};\\\", \\\"{x:1365,y:888,t:1527030778263};\\\", \\\"{x:1409,y:892,t:1527030778280};\\\", \\\"{x:1436,y:892,t:1527030778297};\\\", \\\"{x:1451,y:892,t:1527030778313};\\\", \\\"{x:1458,y:892,t:1527030778330};\\\", \\\"{x:1459,y:892,t:1527030778346};\\\", \\\"{x:1462,y:890,t:1527030778363};\\\", \\\"{x:1463,y:887,t:1527030778380};\\\", \\\"{x:1466,y:874,t:1527030778396};\\\", \\\"{x:1466,y:863,t:1527030778414};\\\", \\\"{x:1466,y:852,t:1527030778430};\\\", \\\"{x:1466,y:842,t:1527030778447};\\\", \\\"{x:1466,y:834,t:1527030778464};\\\", \\\"{x:1462,y:821,t:1527030778480};\\\", \\\"{x:1456,y:807,t:1527030778496};\\\", \\\"{x:1456,y:776,t:1527030778514};\\\", \\\"{x:1450,y:752,t:1527030778530};\\\", \\\"{x:1444,y:737,t:1527030778546};\\\", \\\"{x:1439,y:731,t:1527030778563};\\\", \\\"{x:1435,y:727,t:1527030778580};\\\", \\\"{x:1432,y:724,t:1527030778597};\\\", \\\"{x:1430,y:721,t:1527030778614};\\\", \\\"{x:1429,y:720,t:1527030778629};\\\", \\\"{x:1426,y:719,t:1527030778647};\\\", \\\"{x:1420,y:717,t:1527030778664};\\\", \\\"{x:1416,y:715,t:1527030778680};\\\", \\\"{x:1407,y:715,t:1527030778697};\\\", \\\"{x:1399,y:713,t:1527030778713};\\\", \\\"{x:1392,y:712,t:1527030778729};\\\", \\\"{x:1386,y:711,t:1527030778747};\\\", \\\"{x:1384,y:711,t:1527030778763};\\\", \\\"{x:1383,y:711,t:1527030778786};\\\", \\\"{x:1381,y:711,t:1527030778803};\\\", \\\"{x:1380,y:711,t:1527030778814};\\\", \\\"{x:1378,y:711,t:1527030778830};\\\", \\\"{x:1374,y:711,t:1527030778847};\\\", \\\"{x:1373,y:711,t:1527030778864};\\\", \\\"{x:1369,y:712,t:1527030778880};\\\", \\\"{x:1364,y:712,t:1527030778897};\\\", \\\"{x:1358,y:712,t:1527030778914};\\\", \\\"{x:1343,y:712,t:1527030778931};\\\", \\\"{x:1337,y:711,t:1527030778946};\\\", \\\"{x:1333,y:709,t:1527030778963};\\\", \\\"{x:1332,y:709,t:1527030779043};\\\", \\\"{x:1332,y:708,t:1527030779051};\\\", \\\"{x:1332,y:707,t:1527030779064};\\\", \\\"{x:1332,y:706,t:1527030779081};\\\", \\\"{x:1332,y:704,t:1527030779097};\\\", \\\"{x:1332,y:703,t:1527030779114};\\\", \\\"{x:1332,y:701,t:1527030779131};\\\", \\\"{x:1332,y:700,t:1527030779155};\\\", \\\"{x:1332,y:699,t:1527030779203};\\\", \\\"{x:1333,y:698,t:1527030779235};\\\", \\\"{x:1334,y:698,t:1527030779259};\\\", \\\"{x:1335,y:697,t:1527030779275};\\\", \\\"{x:1336,y:697,t:1527030779348};\\\", \\\"{x:1338,y:697,t:1527030779707};\\\", \\\"{x:1338,y:701,t:1527030779714};\\\", \\\"{x:1338,y:708,t:1527030779730};\\\", \\\"{x:1338,y:718,t:1527030779747};\\\", \\\"{x:1340,y:727,t:1527030779764};\\\", \\\"{x:1341,y:737,t:1527030779781};\\\", \\\"{x:1343,y:750,t:1527030779798};\\\", \\\"{x:1344,y:761,t:1527030779817};\\\", \\\"{x:1347,y:776,t:1527030779830};\\\", \\\"{x:1348,y:793,t:1527030779847};\\\", \\\"{x:1351,y:810,t:1527030779863};\\\", \\\"{x:1353,y:823,t:1527030779880};\\\", \\\"{x:1356,y:839,t:1527030779897};\\\", \\\"{x:1358,y:854,t:1527030779913};\\\", \\\"{x:1360,y:867,t:1527030779930};\\\", \\\"{x:1361,y:875,t:1527030779947};\\\", \\\"{x:1362,y:884,t:1527030779963};\\\", \\\"{x:1362,y:890,t:1527030779980};\\\", \\\"{x:1362,y:893,t:1527030779997};\\\", \\\"{x:1362,y:896,t:1527030780013};\\\", \\\"{x:1362,y:898,t:1527030780030};\\\", \\\"{x:1362,y:901,t:1527030780047};\\\", \\\"{x:1362,y:904,t:1527030780064};\\\", \\\"{x:1362,y:906,t:1527030780080};\\\", \\\"{x:1361,y:907,t:1527030780097};\\\", \\\"{x:1361,y:908,t:1527030780115};\\\", \\\"{x:1361,y:909,t:1527030780130};\\\", \\\"{x:1360,y:912,t:1527030780147};\\\", \\\"{x:1360,y:917,t:1527030780165};\\\", \\\"{x:1360,y:922,t:1527030780180};\\\", \\\"{x:1360,y:928,t:1527030780198};\\\", \\\"{x:1361,y:934,t:1527030780214};\\\", \\\"{x:1365,y:942,t:1527030780230};\\\", \\\"{x:1373,y:950,t:1527030780247};\\\", \\\"{x:1385,y:957,t:1527030780265};\\\", \\\"{x:1401,y:963,t:1527030780280};\\\", \\\"{x:1422,y:968,t:1527030780298};\\\", \\\"{x:1465,y:974,t:1527030780314};\\\", \\\"{x:1494,y:975,t:1527030780331};\\\", \\\"{x:1525,y:979,t:1527030780349};\\\", \\\"{x:1553,y:982,t:1527030780365};\\\", \\\"{x:1578,y:985,t:1527030780380};\\\", \\\"{x:1596,y:987,t:1527030780397};\\\", \\\"{x:1613,y:991,t:1527030780414};\\\", \\\"{x:1626,y:995,t:1527030780430};\\\", \\\"{x:1633,y:997,t:1527030780447};\\\", \\\"{x:1635,y:998,t:1527030780464};\\\", \\\"{x:1636,y:998,t:1527030780531};\\\", \\\"{x:1636,y:997,t:1527030780563};\\\", \\\"{x:1636,y:996,t:1527030780571};\\\", \\\"{x:1636,y:995,t:1527030780581};\\\", \\\"{x:1635,y:991,t:1527030780598};\\\", \\\"{x:1631,y:987,t:1527030780614};\\\", \\\"{x:1627,y:984,t:1527030780630};\\\", \\\"{x:1621,y:980,t:1527030780647};\\\", \\\"{x:1618,y:976,t:1527030780664};\\\", \\\"{x:1617,y:973,t:1527030780680};\\\", \\\"{x:1617,y:970,t:1527030780697};\\\", \\\"{x:1615,y:964,t:1527030780714};\\\", \\\"{x:1615,y:962,t:1527030780731};\\\", \\\"{x:1615,y:961,t:1527030780747};\\\", \\\"{x:1615,y:960,t:1527030780764};\\\", \\\"{x:1615,y:959,t:1527030780781};\\\", \\\"{x:1614,y:958,t:1527030780797};\\\", \\\"{x:1614,y:957,t:1527030780818};\\\", \\\"{x:1614,y:956,t:1527030780842};\\\", \\\"{x:1614,y:955,t:1527030780851};\\\", \\\"{x:1614,y:954,t:1527030780865};\\\", \\\"{x:1613,y:952,t:1527030780882};\\\", \\\"{x:1613,y:950,t:1527030780898};\\\", \\\"{x:1612,y:943,t:1527030780914};\\\", \\\"{x:1611,y:936,t:1527030780931};\\\", \\\"{x:1610,y:928,t:1527030780948};\\\", \\\"{x:1609,y:917,t:1527030780965};\\\", \\\"{x:1606,y:906,t:1527030780981};\\\", \\\"{x:1606,y:897,t:1527030780998};\\\", \\\"{x:1605,y:891,t:1527030781014};\\\", \\\"{x:1605,y:887,t:1527030781031};\\\", \\\"{x:1603,y:884,t:1527030781048};\\\", \\\"{x:1603,y:883,t:1527030781064};\\\", \\\"{x:1603,y:882,t:1527030781082};\\\", \\\"{x:1603,y:881,t:1527030781098};\\\", \\\"{x:1603,y:880,t:1527030781115};\\\", \\\"{x:1603,y:879,t:1527030781132};\\\", \\\"{x:1603,y:878,t:1527030781148};\\\", \\\"{x:1603,y:877,t:1527030781187};\\\", \\\"{x:1603,y:878,t:1527030781378};\\\", \\\"{x:1603,y:881,t:1527030781387};\\\", \\\"{x:1603,y:884,t:1527030781398};\\\", \\\"{x:1603,y:890,t:1527030781414};\\\", \\\"{x:1603,y:899,t:1527030781431};\\\", \\\"{x:1604,y:909,t:1527030781449};\\\", \\\"{x:1605,y:917,t:1527030781465};\\\", \\\"{x:1607,y:924,t:1527030781481};\\\", \\\"{x:1608,y:930,t:1527030781499};\\\", \\\"{x:1608,y:933,t:1527030781515};\\\", \\\"{x:1608,y:934,t:1527030781532};\\\", \\\"{x:1608,y:935,t:1527030781555};\\\", \\\"{x:1608,y:936,t:1527030781565};\\\", \\\"{x:1608,y:937,t:1527030781581};\\\", \\\"{x:1608,y:938,t:1527030781611};\\\", \\\"{x:1608,y:939,t:1527030781635};\\\", \\\"{x:1608,y:940,t:1527030781667};\\\", \\\"{x:1608,y:941,t:1527030781690};\\\", \\\"{x:1608,y:942,t:1527030781707};\\\", \\\"{x:1608,y:943,t:1527030781723};\\\", \\\"{x:1608,y:944,t:1527030781747};\\\", \\\"{x:1609,y:946,t:1527030781755};\\\", \\\"{x:1610,y:948,t:1527030781771};\\\", \\\"{x:1610,y:949,t:1527030781781};\\\", \\\"{x:1611,y:951,t:1527030781800};\\\", \\\"{x:1611,y:953,t:1527030781815};\\\", \\\"{x:1611,y:955,t:1527030781832};\\\", \\\"{x:1612,y:956,t:1527030781849};\\\", \\\"{x:1612,y:959,t:1527030781865};\\\", \\\"{x:1613,y:961,t:1527030781882};\\\", \\\"{x:1613,y:962,t:1527030781898};\\\", \\\"{x:1613,y:963,t:1527030781914};\\\", \\\"{x:1613,y:962,t:1527030782163};\\\", \\\"{x:1613,y:960,t:1527030782170};\\\", \\\"{x:1613,y:956,t:1527030782182};\\\", \\\"{x:1610,y:945,t:1527030782200};\\\", \\\"{x:1609,y:945,t:1527030782215};\\\", \\\"{x:1609,y:943,t:1527030782231};\\\", \\\"{x:1609,y:942,t:1527030782248};\\\", \\\"{x:1609,y:940,t:1527030782266};\\\", \\\"{x:1609,y:939,t:1527030782281};\\\", \\\"{x:1608,y:937,t:1527030782299};\\\", \\\"{x:1608,y:934,t:1527030782315};\\\", \\\"{x:1608,y:929,t:1527030782332};\\\", \\\"{x:1608,y:925,t:1527030782348};\\\", \\\"{x:1611,y:914,t:1527030782370};\\\", \\\"{x:1620,y:891,t:1527030782409};\\\", \\\"{x:1621,y:887,t:1527030782415};\\\", \\\"{x:1622,y:876,t:1527030782430};\\\", \\\"{x:1625,y:863,t:1527030782447};\\\", \\\"{x:1625,y:844,t:1527030782465};\\\", \\\"{x:1625,y:827,t:1527030782481};\\\", \\\"{x:1625,y:811,t:1527030782497};\\\", \\\"{x:1624,y:799,t:1527030782515};\\\", \\\"{x:1623,y:786,t:1527030782531};\\\", \\\"{x:1622,y:774,t:1527030782548};\\\", \\\"{x:1621,y:767,t:1527030782565};\\\", \\\"{x:1620,y:763,t:1527030782581};\\\", \\\"{x:1620,y:758,t:1527030782599};\\\", \\\"{x:1618,y:755,t:1527030782615};\\\", \\\"{x:1617,y:747,t:1527030782631};\\\", \\\"{x:1616,y:743,t:1527030782648};\\\", \\\"{x:1615,y:739,t:1527030782665};\\\", \\\"{x:1612,y:727,t:1527030782683};\\\", \\\"{x:1610,y:721,t:1527030782699};\\\", \\\"{x:1608,y:717,t:1527030782716};\\\", \\\"{x:1607,y:713,t:1527030782732};\\\", \\\"{x:1606,y:709,t:1527030782748};\\\", \\\"{x:1605,y:705,t:1527030782766};\\\", \\\"{x:1604,y:702,t:1527030782783};\\\", \\\"{x:1603,y:701,t:1527030782800};\\\", \\\"{x:1603,y:700,t:1527030782816};\\\", \\\"{x:1603,y:698,t:1527030782833};\\\", \\\"{x:1603,y:696,t:1527030782939};\\\", \\\"{x:1603,y:695,t:1527030783138};\\\", \\\"{x:1605,y:694,t:1527030783186};\\\", \\\"{x:1605,y:696,t:1527030785963};\\\", \\\"{x:1605,y:698,t:1527030785971};\\\", \\\"{x:1605,y:700,t:1527030785984};\\\", \\\"{x:1605,y:706,t:1527030786001};\\\", \\\"{x:1604,y:712,t:1527030786018};\\\", \\\"{x:1603,y:717,t:1527030786034};\\\", \\\"{x:1603,y:721,t:1527030786050};\\\", \\\"{x:1603,y:725,t:1527030786067};\\\", \\\"{x:1603,y:728,t:1527030786083};\\\", \\\"{x:1603,y:731,t:1527030786100};\\\", \\\"{x:1602,y:733,t:1527030786117};\\\", \\\"{x:1602,y:736,t:1527030786133};\\\", \\\"{x:1602,y:741,t:1527030786150};\\\", \\\"{x:1602,y:746,t:1527030786167};\\\", \\\"{x:1602,y:753,t:1527030786183};\\\", \\\"{x:1602,y:758,t:1527030786200};\\\", \\\"{x:1602,y:764,t:1527030786218};\\\", \\\"{x:1602,y:771,t:1527030786233};\\\", \\\"{x:1602,y:786,t:1527030786250};\\\", \\\"{x:1602,y:798,t:1527030786267};\\\", \\\"{x:1602,y:811,t:1527030786284};\\\", \\\"{x:1602,y:827,t:1527030786301};\\\", \\\"{x:1602,y:842,t:1527030786318};\\\", \\\"{x:1602,y:852,t:1527030786334};\\\", \\\"{x:1602,y:860,t:1527030786351};\\\", \\\"{x:1602,y:862,t:1527030786368};\\\", \\\"{x:1602,y:865,t:1527030786384};\\\", \\\"{x:1602,y:866,t:1527030786400};\\\", \\\"{x:1602,y:867,t:1527030786418};\\\", \\\"{x:1602,y:868,t:1527030786435};\\\", \\\"{x:1602,y:869,t:1527030786459};\\\", \\\"{x:1602,y:867,t:1527030786587};\\\", \\\"{x:1602,y:863,t:1527030786601};\\\", \\\"{x:1604,y:852,t:1527030786618};\\\", \\\"{x:1606,y:839,t:1527030786633};\\\", \\\"{x:1606,y:835,t:1527030786650};\\\", \\\"{x:1606,y:831,t:1527030786667};\\\", \\\"{x:1608,y:829,t:1527030786684};\\\", \\\"{x:1608,y:828,t:1527030786701};\\\", \\\"{x:1608,y:826,t:1527030786718};\\\", \\\"{x:1608,y:825,t:1527030786734};\\\", \\\"{x:1609,y:823,t:1527030786751};\\\", \\\"{x:1610,y:822,t:1527030786767};\\\", \\\"{x:1611,y:820,t:1527030786786};\\\", \\\"{x:1611,y:821,t:1527030786979};\\\", \\\"{x:1611,y:822,t:1527030786987};\\\", \\\"{x:1611,y:823,t:1527030787010};\\\", \\\"{x:1611,y:824,t:1527030787035};\\\", \\\"{x:1611,y:825,t:1527030787699};\\\", \\\"{x:1612,y:826,t:1527030787706};\\\", \\\"{x:1612,y:828,t:1527030787722};\\\", \\\"{x:1612,y:829,t:1527030787739};\\\", \\\"{x:1612,y:831,t:1527030787751};\\\", \\\"{x:1613,y:832,t:1527030787768};\\\", \\\"{x:1613,y:834,t:1527030787785};\\\", \\\"{x:1613,y:835,t:1527030787802};\\\", \\\"{x:1613,y:837,t:1527030787817};\\\", \\\"{x:1613,y:838,t:1527030787835};\\\", \\\"{x:1613,y:840,t:1527030787852};\\\", \\\"{x:1613,y:842,t:1527030787868};\\\", \\\"{x:1614,y:845,t:1527030787885};\\\", \\\"{x:1614,y:847,t:1527030787901};\\\", \\\"{x:1615,y:850,t:1527030787919};\\\", \\\"{x:1615,y:854,t:1527030787935};\\\", \\\"{x:1616,y:856,t:1527030787952};\\\", \\\"{x:1616,y:859,t:1527030787969};\\\", \\\"{x:1616,y:861,t:1527030787985};\\\", \\\"{x:1616,y:863,t:1527030788001};\\\", \\\"{x:1618,y:869,t:1527030788019};\\\", \\\"{x:1619,y:876,t:1527030788035};\\\", \\\"{x:1619,y:884,t:1527030788052};\\\", \\\"{x:1622,y:893,t:1527030788069};\\\", \\\"{x:1623,y:904,t:1527030788085};\\\", \\\"{x:1625,y:916,t:1527030788102};\\\", \\\"{x:1627,y:926,t:1527030788119};\\\", \\\"{x:1628,y:937,t:1527030788134};\\\", \\\"{x:1628,y:948,t:1527030788152};\\\", \\\"{x:1628,y:957,t:1527030788169};\\\", \\\"{x:1628,y:962,t:1527030788185};\\\", \\\"{x:1627,y:968,t:1527030788202};\\\", \\\"{x:1616,y:978,t:1527030788219};\\\", \\\"{x:1605,y:983,t:1527030788235};\\\", \\\"{x:1581,y:987,t:1527030788252};\\\", \\\"{x:1540,y:989,t:1527030788269};\\\", \\\"{x:1459,y:989,t:1527030788285};\\\", \\\"{x:1351,y:988,t:1527030788302};\\\", \\\"{x:1213,y:973,t:1527030788319};\\\", \\\"{x:1078,y:959,t:1527030788335};\\\", \\\"{x:967,y:942,t:1527030788352};\\\", \\\"{x:889,y:918,t:1527030788369};\\\", \\\"{x:835,y:900,t:1527030788385};\\\", \\\"{x:802,y:882,t:1527030788401};\\\", \\\"{x:780,y:860,t:1527030788418};\\\", \\\"{x:771,y:847,t:1527030788435};\\\", \\\"{x:762,y:834,t:1527030788451};\\\", \\\"{x:754,y:823,t:1527030788469};\\\", \\\"{x:747,y:814,t:1527030788486};\\\", \\\"{x:734,y:799,t:1527030788502};\\\", \\\"{x:724,y:785,t:1527030788519};\\\", \\\"{x:716,y:772,t:1527030788535};\\\", \\\"{x:710,y:761,t:1527030788552};\\\", \\\"{x:706,y:750,t:1527030788568};\\\", \\\"{x:702,y:736,t:1527030788586};\\\", \\\"{x:697,y:720,t:1527030788601};\\\", \\\"{x:680,y:687,t:1527030788619};\\\", \\\"{x:666,y:666,t:1527030788636};\\\", \\\"{x:655,y:649,t:1527030788651};\\\", \\\"{x:646,y:638,t:1527030788669};\\\", \\\"{x:640,y:630,t:1527030788687};\\\", \\\"{x:632,y:622,t:1527030788702};\\\", \\\"{x:628,y:613,t:1527030788718};\\\", \\\"{x:621,y:600,t:1527030788739};\\\", \\\"{x:619,y:598,t:1527030788755};\\\", \\\"{x:617,y:595,t:1527030788771};\\\", \\\"{x:616,y:592,t:1527030788789};\\\", \\\"{x:615,y:591,t:1527030788805};\\\", \\\"{x:615,y:590,t:1527030788826};\\\", \\\"{x:615,y:589,t:1527030788838};\\\", \\\"{x:615,y:587,t:1527030788858};\\\", \\\"{x:615,y:586,t:1527030788874};\\\", \\\"{x:615,y:585,t:1527030788889};\\\", \\\"{x:615,y:584,t:1527030788906};\\\", \\\"{x:615,y:581,t:1527030788921};\\\", \\\"{x:616,y:581,t:1527030789298};\\\", \\\"{x:617,y:581,t:1527030789306};\\\", \\\"{x:622,y:581,t:1527030789322};\\\", \\\"{x:634,y:583,t:1527030789339};\\\", \\\"{x:655,y:589,t:1527030789356};\\\", \\\"{x:678,y:595,t:1527030789372};\\\", \\\"{x:704,y:603,t:1527030789389};\\\", \\\"{x:737,y:613,t:1527030789406};\\\", \\\"{x:777,y:626,t:1527030789422};\\\", \\\"{x:832,y:649,t:1527030789440};\\\", \\\"{x:895,y:672,t:1527030789457};\\\", \\\"{x:973,y:698,t:1527030789472};\\\", \\\"{x:1057,y:724,t:1527030789489};\\\", \\\"{x:1204,y:766,t:1527030789506};\\\", \\\"{x:1320,y:799,t:1527030789522};\\\", \\\"{x:1420,y:833,t:1527030789540};\\\", \\\"{x:1509,y:858,t:1527030789556};\\\", \\\"{x:1595,y:883,t:1527030789572};\\\", \\\"{x:1659,y:902,t:1527030789589};\\\", \\\"{x:1697,y:916,t:1527030789606};\\\", \\\"{x:1723,y:927,t:1527030789622};\\\", \\\"{x:1737,y:933,t:1527030789640};\\\", \\\"{x:1745,y:939,t:1527030789656};\\\", \\\"{x:1747,y:941,t:1527030789672};\\\", \\\"{x:1747,y:942,t:1527030789723};\\\", \\\"{x:1747,y:943,t:1527030789740};\\\", \\\"{x:1746,y:945,t:1527030789757};\\\", \\\"{x:1743,y:945,t:1527030789773};\\\", \\\"{x:1736,y:945,t:1527030789790};\\\", \\\"{x:1727,y:945,t:1527030789807};\\\", \\\"{x:1718,y:945,t:1527030789823};\\\", \\\"{x:1708,y:945,t:1527030789839};\\\", \\\"{x:1699,y:945,t:1527030789857};\\\", \\\"{x:1692,y:945,t:1527030789874};\\\", \\\"{x:1689,y:945,t:1527030789890};\\\", \\\"{x:1688,y:947,t:1527030789907};\\\", \\\"{x:1686,y:948,t:1527030789923};\\\", \\\"{x:1685,y:949,t:1527030789954};\\\", \\\"{x:1683,y:949,t:1527030790003};\\\", \\\"{x:1682,y:949,t:1527030790018};\\\", \\\"{x:1682,y:950,t:1527030790027};\\\", \\\"{x:1680,y:951,t:1527030790042};\\\", \\\"{x:1679,y:951,t:1527030790155};\\\", \\\"{x:1677,y:951,t:1527030790275};\\\", \\\"{x:1677,y:952,t:1527030790290};\\\", \\\"{x:1675,y:953,t:1527030790355};\\\", \\\"{x:1674,y:953,t:1527030790379};\\\", \\\"{x:1673,y:954,t:1527030790392};\\\", \\\"{x:1671,y:954,t:1527030790407};\\\", \\\"{x:1670,y:954,t:1527030790424};\\\", \\\"{x:1667,y:954,t:1527030790441};\\\", \\\"{x:1665,y:954,t:1527030790457};\\\", \\\"{x:1663,y:955,t:1527030790474};\\\", \\\"{x:1658,y:955,t:1527030790491};\\\", \\\"{x:1656,y:955,t:1527030790507};\\\", \\\"{x:1653,y:955,t:1527030790524};\\\", \\\"{x:1649,y:955,t:1527030790541};\\\", \\\"{x:1645,y:954,t:1527030790557};\\\", \\\"{x:1644,y:953,t:1527030790574};\\\", \\\"{x:1642,y:953,t:1527030790591};\\\", \\\"{x:1640,y:952,t:1527030790607};\\\", \\\"{x:1637,y:950,t:1527030790623};\\\", \\\"{x:1634,y:948,t:1527030790640};\\\", \\\"{x:1628,y:944,t:1527030790657};\\\", \\\"{x:1623,y:940,t:1527030790674};\\\", \\\"{x:1617,y:937,t:1527030790690};\\\", \\\"{x:1612,y:933,t:1527030790707};\\\", \\\"{x:1608,y:928,t:1527030790723};\\\", \\\"{x:1607,y:923,t:1527030790741};\\\", \\\"{x:1603,y:915,t:1527030790758};\\\", \\\"{x:1601,y:904,t:1527030790773};\\\", \\\"{x:1598,y:895,t:1527030790791};\\\", \\\"{x:1594,y:883,t:1527030790808};\\\", \\\"{x:1591,y:874,t:1527030790823};\\\", \\\"{x:1590,y:868,t:1527030790840};\\\", \\\"{x:1589,y:860,t:1527030790858};\\\", \\\"{x:1587,y:851,t:1527030790873};\\\", \\\"{x:1584,y:831,t:1527030790890};\\\", \\\"{x:1582,y:812,t:1527030790908};\\\", \\\"{x:1579,y:792,t:1527030790924};\\\", \\\"{x:1576,y:779,t:1527030790941};\\\", \\\"{x:1575,y:769,t:1527030790957};\\\", \\\"{x:1574,y:760,t:1527030790974};\\\", \\\"{x:1572,y:750,t:1527030790990};\\\", \\\"{x:1571,y:744,t:1527030791008};\\\", \\\"{x:1571,y:740,t:1527030791024};\\\", \\\"{x:1570,y:736,t:1527030791041};\\\", \\\"{x:1570,y:733,t:1527030791058};\\\", \\\"{x:1570,y:734,t:1527030791443};\\\", \\\"{x:1572,y:739,t:1527030791458};\\\", \\\"{x:1573,y:742,t:1527030791475};\\\", \\\"{x:1575,y:744,t:1527030791493};\\\", \\\"{x:1576,y:746,t:1527030791508};\\\", \\\"{x:1577,y:747,t:1527030791525};\\\", \\\"{x:1578,y:748,t:1527030791546};\\\", \\\"{x:1577,y:748,t:1527030792667};\\\", \\\"{x:1571,y:748,t:1527030792676};\\\", \\\"{x:1557,y:754,t:1527030792693};\\\", \\\"{x:1538,y:758,t:1527030792709};\\\", \\\"{x:1523,y:763,t:1527030792727};\\\", \\\"{x:1511,y:763,t:1527030792744};\\\", \\\"{x:1504,y:764,t:1527030792760};\\\", \\\"{x:1499,y:766,t:1527030792775};\\\", \\\"{x:1494,y:767,t:1527030792793};\\\", \\\"{x:1489,y:768,t:1527030792809};\\\", \\\"{x:1480,y:771,t:1527030792827};\\\", \\\"{x:1474,y:771,t:1527030792843};\\\", \\\"{x:1470,y:772,t:1527030792859};\\\", \\\"{x:1465,y:774,t:1527030792876};\\\", \\\"{x:1461,y:775,t:1527030792893};\\\", \\\"{x:1452,y:775,t:1527030792909};\\\", \\\"{x:1445,y:775,t:1527030792926};\\\", \\\"{x:1432,y:778,t:1527030792943};\\\", \\\"{x:1420,y:778,t:1527030792959};\\\", \\\"{x:1407,y:778,t:1527030792976};\\\", \\\"{x:1396,y:779,t:1527030792993};\\\", \\\"{x:1383,y:779,t:1527030793009};\\\", \\\"{x:1369,y:779,t:1527030793026};\\\", \\\"{x:1362,y:779,t:1527030793042};\\\", \\\"{x:1358,y:779,t:1527030793059};\\\", \\\"{x:1355,y:779,t:1527030793076};\\\", \\\"{x:1354,y:779,t:1527030793094};\\\", \\\"{x:1353,y:779,t:1527030793131};\\\", \\\"{x:1352,y:779,t:1527030793147};\\\", \\\"{x:1351,y:779,t:1527030793163};\\\", \\\"{x:1350,y:779,t:1527030793176};\\\", \\\"{x:1349,y:779,t:1527030793195};\\\", \\\"{x:1349,y:777,t:1527030793251};\\\", \\\"{x:1349,y:776,t:1527030793267};\\\", \\\"{x:1349,y:773,t:1527030793276};\\\", \\\"{x:1350,y:773,t:1527030793293};\\\", \\\"{x:1353,y:771,t:1527030793310};\\\", \\\"{x:1358,y:770,t:1527030793326};\\\", \\\"{x:1363,y:770,t:1527030793343};\\\", \\\"{x:1368,y:770,t:1527030793360};\\\", \\\"{x:1373,y:769,t:1527030793376};\\\", \\\"{x:1378,y:769,t:1527030793393};\\\", \\\"{x:1385,y:768,t:1527030793410};\\\", \\\"{x:1386,y:768,t:1527030793426};\\\", \\\"{x:1388,y:768,t:1527030793443};\\\", \\\"{x:1390,y:768,t:1527030793460};\\\", \\\"{x:1394,y:767,t:1527030793476};\\\", \\\"{x:1396,y:766,t:1527030793493};\\\", \\\"{x:1400,y:766,t:1527030793510};\\\", \\\"{x:1403,y:765,t:1527030793527};\\\", \\\"{x:1405,y:765,t:1527030793543};\\\", \\\"{x:1408,y:764,t:1527030793560};\\\", \\\"{x:1409,y:764,t:1527030793577};\\\", \\\"{x:1411,y:764,t:1527030793593};\\\", \\\"{x:1412,y:764,t:1527030793609};\\\", \\\"{x:1414,y:763,t:1527030793722};\\\", \\\"{x:1416,y:763,t:1527030793730};\\\", \\\"{x:1418,y:763,t:1527030793742};\\\", \\\"{x:1424,y:763,t:1527030793760};\\\", \\\"{x:1437,y:763,t:1527030793776};\\\", \\\"{x:1452,y:763,t:1527030793792};\\\", \\\"{x:1471,y:763,t:1527030793810};\\\", \\\"{x:1481,y:763,t:1527030793826};\\\", \\\"{x:1489,y:763,t:1527030793843};\\\", \\\"{x:1494,y:763,t:1527030793859};\\\", \\\"{x:1497,y:762,t:1527030793877};\\\", \\\"{x:1499,y:762,t:1527030793894};\\\", \\\"{x:1500,y:762,t:1527030793910};\\\", \\\"{x:1499,y:762,t:1527030794099};\\\", \\\"{x:1497,y:762,t:1527030794110};\\\", \\\"{x:1496,y:762,t:1527030794126};\\\", \\\"{x:1497,y:762,t:1527030794467};\\\", \\\"{x:1499,y:762,t:1527030794477};\\\", \\\"{x:1504,y:762,t:1527030794494};\\\", \\\"{x:1511,y:762,t:1527030794512};\\\", \\\"{x:1517,y:762,t:1527030794527};\\\", \\\"{x:1525,y:762,t:1527030794546};\\\", \\\"{x:1532,y:763,t:1527030794562};\\\", \\\"{x:1537,y:763,t:1527030794577};\\\", \\\"{x:1542,y:763,t:1527030794594};\\\", \\\"{x:1544,y:763,t:1527030795859};\\\", \\\"{x:1545,y:763,t:1527030795866};\\\", \\\"{x:1547,y:763,t:1527030795877};\\\", \\\"{x:1548,y:763,t:1527030795895};\\\", \\\"{x:1550,y:763,t:1527030795912};\\\", \\\"{x:1544,y:764,t:1527030800108};\\\", \\\"{x:1534,y:764,t:1527030800116};\\\", \\\"{x:1519,y:764,t:1527030800133};\\\", \\\"{x:1502,y:764,t:1527030800150};\\\", \\\"{x:1483,y:764,t:1527030800165};\\\", \\\"{x:1472,y:763,t:1527030800183};\\\", \\\"{x:1465,y:760,t:1527030800200};\\\", \\\"{x:1460,y:759,t:1527030800215};\\\", \\\"{x:1458,y:758,t:1527030800232};\\\", \\\"{x:1453,y:757,t:1527030800249};\\\", \\\"{x:1447,y:755,t:1527030800265};\\\", \\\"{x:1435,y:751,t:1527030800282};\\\", \\\"{x:1429,y:748,t:1527030800299};\\\", \\\"{x:1419,y:742,t:1527030800316};\\\", \\\"{x:1412,y:738,t:1527030800332};\\\", \\\"{x:1404,y:732,t:1527030800349};\\\", \\\"{x:1399,y:728,t:1527030800365};\\\", \\\"{x:1395,y:724,t:1527030800383};\\\", \\\"{x:1391,y:720,t:1527030800400};\\\", \\\"{x:1386,y:714,t:1527030800415};\\\", \\\"{x:1381,y:708,t:1527030800432};\\\", \\\"{x:1377,y:704,t:1527030800450};\\\", \\\"{x:1373,y:700,t:1527030800466};\\\", \\\"{x:1370,y:699,t:1527030800483};\\\", \\\"{x:1367,y:698,t:1527030800500};\\\", \\\"{x:1367,y:697,t:1527030800517};\\\", \\\"{x:1366,y:696,t:1527030800533};\\\", \\\"{x:1366,y:695,t:1527030800549};\\\", \\\"{x:1366,y:694,t:1527030800566};\\\", \\\"{x:1366,y:693,t:1527030800587};\\\", \\\"{x:1366,y:692,t:1527030800599};\\\", \\\"{x:1366,y:691,t:1527030800616};\\\", \\\"{x:1366,y:690,t:1527030800651};\\\", \\\"{x:1366,y:689,t:1527030800666};\\\", \\\"{x:1367,y:689,t:1527030800714};\\\", \\\"{x:1369,y:689,t:1527030800723};\\\", \\\"{x:1370,y:689,t:1527030800732};\\\", \\\"{x:1374,y:689,t:1527030800749};\\\", \\\"{x:1381,y:691,t:1527030800766};\\\", \\\"{x:1389,y:693,t:1527030800782};\\\", \\\"{x:1398,y:695,t:1527030800800};\\\", \\\"{x:1404,y:696,t:1527030800816};\\\", \\\"{x:1411,y:697,t:1527030800833};\\\", \\\"{x:1416,y:698,t:1527030800850};\\\", \\\"{x:1418,y:698,t:1527030800866};\\\", \\\"{x:1420,y:698,t:1527030801274};\\\", \\\"{x:1421,y:698,t:1527030801283};\\\", \\\"{x:1424,y:698,t:1527030801300};\\\", \\\"{x:1429,y:698,t:1527030801317};\\\", \\\"{x:1436,y:698,t:1527030801333};\\\", \\\"{x:1443,y:698,t:1527030801351};\\\", \\\"{x:1453,y:698,t:1527030801367};\\\", \\\"{x:1463,y:698,t:1527030801384};\\\", \\\"{x:1475,y:698,t:1527030801400};\\\", \\\"{x:1481,y:698,t:1527030801416};\\\", \\\"{x:1489,y:695,t:1527030801434};\\\", \\\"{x:1491,y:695,t:1527030801450};\\\", \\\"{x:1492,y:695,t:1527030801467};\\\", \\\"{x:1491,y:695,t:1527030801802};\\\", \\\"{x:1492,y:695,t:1527030803075};\\\", \\\"{x:1495,y:695,t:1527030803084};\\\", \\\"{x:1500,y:696,t:1527030803101};\\\", \\\"{x:1506,y:697,t:1527030803118};\\\", \\\"{x:1511,y:697,t:1527030803135};\\\", \\\"{x:1515,y:697,t:1527030803151};\\\", \\\"{x:1520,y:699,t:1527030803168};\\\", \\\"{x:1525,y:699,t:1527030803185};\\\", \\\"{x:1531,y:699,t:1527030803201};\\\", \\\"{x:1538,y:700,t:1527030803218};\\\", \\\"{x:1541,y:700,t:1527030803234};\\\", \\\"{x:1543,y:700,t:1527030803251};\\\", \\\"{x:1544,y:700,t:1527030803268};\\\", \\\"{x:1545,y:700,t:1527030803347};\\\", \\\"{x:1546,y:700,t:1527030803363};\\\", \\\"{x:1547,y:700,t:1527030803371};\\\", \\\"{x:1548,y:700,t:1527030803395};\\\", \\\"{x:1549,y:700,t:1527030803402};\\\", \\\"{x:1551,y:700,t:1527030803419};\\\", \\\"{x:1554,y:700,t:1527030803435};\\\", \\\"{x:1557,y:700,t:1527030803451};\\\", \\\"{x:1559,y:700,t:1527030803468};\\\", \\\"{x:1560,y:700,t:1527030803490};\\\", \\\"{x:1562,y:700,t:1527030803522};\\\", \\\"{x:1563,y:700,t:1527030803538};\\\", \\\"{x:1562,y:700,t:1527030803874};\\\", \\\"{x:1561,y:700,t:1527030803886};\\\", \\\"{x:1559,y:700,t:1527030803902};\\\", \\\"{x:1558,y:700,t:1527030803918};\\\", \\\"{x:1557,y:700,t:1527030803987};\\\", \\\"{x:1556,y:700,t:1527030804043};\\\", \\\"{x:1555,y:700,t:1527030804052};\\\", \\\"{x:1554,y:699,t:1527030804075};\\\", \\\"{x:1556,y:699,t:1527030804419};\\\", \\\"{x:1560,y:699,t:1527030804436};\\\", \\\"{x:1563,y:699,t:1527030804452};\\\", \\\"{x:1568,y:699,t:1527030804470};\\\", \\\"{x:1571,y:699,t:1527030804485};\\\", \\\"{x:1575,y:699,t:1527030804502};\\\", \\\"{x:1577,y:699,t:1527030804520};\\\", \\\"{x:1581,y:699,t:1527030804537};\\\", \\\"{x:1584,y:699,t:1527030804553};\\\", \\\"{x:1589,y:699,t:1527030804570};\\\", \\\"{x:1593,y:699,t:1527030804586};\\\", \\\"{x:1594,y:699,t:1527030804602};\\\", \\\"{x:1595,y:699,t:1527030804619};\\\", \\\"{x:1596,y:699,t:1527030804636};\\\", \\\"{x:1597,y:699,t:1527030804652};\\\", \\\"{x:1599,y:699,t:1527030804669};\\\", \\\"{x:1602,y:699,t:1527030804686};\\\", \\\"{x:1603,y:699,t:1527030804702};\\\", \\\"{x:1605,y:699,t:1527030804719};\\\", \\\"{x:1606,y:699,t:1527030804736};\\\", \\\"{x:1607,y:699,t:1527030804931};\\\", \\\"{x:1608,y:699,t:1527030804938};\\\", \\\"{x:1609,y:699,t:1527030804963};\\\", \\\"{x:1611,y:699,t:1527030804987};\\\", \\\"{x:1613,y:699,t:1527030805010};\\\", \\\"{x:1613,y:698,t:1527030805042};\\\", \\\"{x:1613,y:699,t:1527030809786};\\\", \\\"{x:1608,y:704,t:1527030809795};\\\", \\\"{x:1596,y:710,t:1527030809807};\\\", \\\"{x:1578,y:718,t:1527030809823};\\\", \\\"{x:1563,y:724,t:1527030809840};\\\", \\\"{x:1540,y:728,t:1527030809857};\\\", \\\"{x:1522,y:729,t:1527030809873};\\\", \\\"{x:1503,y:729,t:1527030809890};\\\", \\\"{x:1486,y:729,t:1527030809907};\\\", \\\"{x:1469,y:729,t:1527030809923};\\\", \\\"{x:1453,y:729,t:1527030809940};\\\", \\\"{x:1434,y:726,t:1527030809957};\\\", \\\"{x:1419,y:726,t:1527030809973};\\\", \\\"{x:1407,y:726,t:1527030809990};\\\", \\\"{x:1400,y:726,t:1527030810008};\\\", \\\"{x:1395,y:725,t:1527030810024};\\\", \\\"{x:1390,y:724,t:1527030810040};\\\", \\\"{x:1386,y:722,t:1527030810057};\\\", \\\"{x:1385,y:722,t:1527030810089};\\\", \\\"{x:1385,y:721,t:1527030810129};\\\", \\\"{x:1386,y:719,t:1527030810140};\\\", \\\"{x:1392,y:716,t:1527030810158};\\\", \\\"{x:1404,y:710,t:1527030810174};\\\", \\\"{x:1424,y:702,t:1527030810190};\\\", \\\"{x:1446,y:695,t:1527030810208};\\\", \\\"{x:1468,y:688,t:1527030810224};\\\", \\\"{x:1483,y:687,t:1527030810241};\\\", \\\"{x:1489,y:686,t:1527030810258};\\\", \\\"{x:1490,y:686,t:1527030810315};\\\", \\\"{x:1491,y:686,t:1527030810330};\\\", \\\"{x:1492,y:686,t:1527030810347};\\\", \\\"{x:1493,y:686,t:1527030810358};\\\", \\\"{x:1494,y:686,t:1527030810378};\\\", \\\"{x:1495,y:686,t:1527030810418};\\\", \\\"{x:1496,y:686,t:1527030810426};\\\", \\\"{x:1499,y:686,t:1527030810442};\\\", \\\"{x:1505,y:693,t:1527030810458};\\\", \\\"{x:1509,y:697,t:1527030810475};\\\", \\\"{x:1516,y:700,t:1527030810491};\\\", \\\"{x:1520,y:702,t:1527030810508};\\\", \\\"{x:1522,y:702,t:1527030810524};\\\", \\\"{x:1523,y:702,t:1527030810541};\\\", \\\"{x:1525,y:702,t:1527030810558};\\\", \\\"{x:1527,y:702,t:1527030810575};\\\", \\\"{x:1531,y:702,t:1527030810591};\\\", \\\"{x:1534,y:700,t:1527030810608};\\\", \\\"{x:1539,y:698,t:1527030810625};\\\", \\\"{x:1541,y:697,t:1527030810641};\\\", \\\"{x:1543,y:697,t:1527030810658};\\\", \\\"{x:1544,y:697,t:1527030810698};\\\", \\\"{x:1545,y:697,t:1527030810714};\\\", \\\"{x:1547,y:696,t:1527030810730};\\\", \\\"{x:1549,y:696,t:1527030810747};\\\", \\\"{x:1551,y:695,t:1527030810758};\\\", \\\"{x:1557,y:694,t:1527030810775};\\\", \\\"{x:1561,y:693,t:1527030810791};\\\", \\\"{x:1566,y:693,t:1527030810808};\\\", \\\"{x:1570,y:692,t:1527030810825};\\\", \\\"{x:1583,y:690,t:1527030810843};\\\", \\\"{x:1589,y:690,t:1527030810858};\\\", \\\"{x:1593,y:690,t:1527030810875};\\\", \\\"{x:1598,y:690,t:1527030810892};\\\", \\\"{x:1604,y:689,t:1527030810908};\\\", \\\"{x:1609,y:688,t:1527030810924};\\\", \\\"{x:1612,y:688,t:1527030810942};\\\", \\\"{x:1614,y:688,t:1527030810957};\\\", \\\"{x:1615,y:688,t:1527030810975};\\\", \\\"{x:1617,y:688,t:1527030811292};\\\", \\\"{x:1618,y:688,t:1527030811309};\\\", \\\"{x:1619,y:689,t:1527030811325};\\\", \\\"{x:1620,y:691,t:1527030811342};\\\", \\\"{x:1621,y:693,t:1527030811359};\\\", \\\"{x:1622,y:694,t:1527030811375};\\\", \\\"{x:1622,y:695,t:1527030811418};\\\", \\\"{x:1625,y:696,t:1527030815803};\\\", \\\"{x:1627,y:696,t:1527030815812};\\\", \\\"{x:1628,y:696,t:1527030815829};\\\", \\\"{x:1629,y:696,t:1527030815846};\\\", \\\"{x:1629,y:698,t:1527030816003};\\\", \\\"{x:1628,y:699,t:1527030816026};\\\", \\\"{x:1628,y:700,t:1527030816058};\\\", \\\"{x:1627,y:700,t:1527030816074};\\\", \\\"{x:1627,y:701,t:1527030820724};\\\", \\\"{x:1627,y:702,t:1527030820756};\\\", \\\"{x:1624,y:702,t:1527030827764};\\\", \\\"{x:1597,y:702,t:1527030827771};\\\", \\\"{x:1534,y:690,t:1527030827782};\\\", \\\"{x:1341,y:638,t:1527030827799};\\\", \\\"{x:1108,y:593,t:1527030827816};\\\", \\\"{x:874,y:567,t:1527030827833};\\\", \\\"{x:658,y:560,t:1527030827850};\\\", \\\"{x:506,y:560,t:1527030827865};\\\", \\\"{x:411,y:563,t:1527030827879};\\\", \\\"{x:397,y:563,t:1527030827896};\\\", \\\"{x:403,y:564,t:1527030827946};\\\", \\\"{x:410,y:564,t:1527030827962};\\\", \\\"{x:417,y:566,t:1527030827979};\\\", \\\"{x:427,y:568,t:1527030827996};\\\", \\\"{x:445,y:569,t:1527030828013};\\\", \\\"{x:473,y:574,t:1527030828029};\\\", \\\"{x:501,y:578,t:1527030828046};\\\", \\\"{x:540,y:588,t:1527030828062};\\\", \\\"{x:582,y:601,t:1527030828079};\\\", \\\"{x:625,y:614,t:1527030828096};\\\", \\\"{x:683,y:633,t:1527030828113};\\\", \\\"{x:759,y:657,t:1527030828129};\\\", \\\"{x:878,y:704,t:1527030828146};\\\", \\\"{x:970,y:735,t:1527030828163};\\\", \\\"{x:1070,y:765,t:1527030828180};\\\", \\\"{x:1159,y:792,t:1527030828196};\\\", \\\"{x:1250,y:816,t:1527030828214};\\\", \\\"{x:1330,y:836,t:1527030828229};\\\", \\\"{x:1391,y:843,t:1527030828246};\\\", \\\"{x:1428,y:848,t:1527030828263};\\\", \\\"{x:1449,y:848,t:1527030828280};\\\", \\\"{x:1465,y:847,t:1527030828296};\\\", \\\"{x:1481,y:841,t:1527030828313};\\\", \\\"{x:1503,y:829,t:1527030828330};\\\", \\\"{x:1508,y:825,t:1527030828347};\\\", \\\"{x:1528,y:812,t:1527030828363};\\\", \\\"{x:1539,y:803,t:1527030828380};\\\", \\\"{x:1554,y:794,t:1527030828397};\\\", \\\"{x:1567,y:786,t:1527030828413};\\\", \\\"{x:1578,y:779,t:1527030828431};\\\", \\\"{x:1585,y:773,t:1527030828446};\\\", \\\"{x:1590,y:769,t:1527030828463};\\\", \\\"{x:1592,y:767,t:1527030828480};\\\", \\\"{x:1593,y:767,t:1527030828496};\\\", \\\"{x:1593,y:770,t:1527030828604};\\\", \\\"{x:1590,y:776,t:1527030828613};\\\", \\\"{x:1586,y:785,t:1527030828630};\\\", \\\"{x:1579,y:795,t:1527030828646};\\\", \\\"{x:1577,y:797,t:1527030828663};\\\", \\\"{x:1575,y:799,t:1527030828680};\\\", \\\"{x:1574,y:799,t:1527030828696};\\\", \\\"{x:1573,y:801,t:1527030828971};\\\", \\\"{x:1571,y:801,t:1527030828981};\\\", \\\"{x:1569,y:803,t:1527030828998};\\\", \\\"{x:1563,y:807,t:1527030829013};\\\", \\\"{x:1554,y:812,t:1527030829030};\\\", \\\"{x:1541,y:819,t:1527030829047};\\\", \\\"{x:1529,y:824,t:1527030829063};\\\", \\\"{x:1517,y:829,t:1527030829080};\\\", \\\"{x:1507,y:834,t:1527030829097};\\\", \\\"{x:1495,y:839,t:1527030829113};\\\", \\\"{x:1474,y:849,t:1527030829130};\\\", \\\"{x:1455,y:861,t:1527030829147};\\\", \\\"{x:1438,y:872,t:1527030829163};\\\", \\\"{x:1417,y:884,t:1527030829180};\\\", \\\"{x:1396,y:895,t:1527030829197};\\\", \\\"{x:1381,y:907,t:1527030829213};\\\", \\\"{x:1368,y:916,t:1527030829230};\\\", \\\"{x:1362,y:922,t:1527030829247};\\\", \\\"{x:1357,y:928,t:1527030829264};\\\", \\\"{x:1355,y:932,t:1527030829281};\\\", \\\"{x:1355,y:934,t:1527030829297};\\\", \\\"{x:1355,y:935,t:1527030829315};\\\", \\\"{x:1355,y:934,t:1527030829451};\\\", \\\"{x:1355,y:933,t:1527030829465};\\\", \\\"{x:1356,y:927,t:1527030829481};\\\", \\\"{x:1356,y:923,t:1527030829497};\\\", \\\"{x:1357,y:909,t:1527030829515};\\\", \\\"{x:1357,y:897,t:1527030829531};\\\", \\\"{x:1357,y:883,t:1527030829547};\\\", \\\"{x:1357,y:869,t:1527030829565};\\\", \\\"{x:1357,y:859,t:1527030829581};\\\", \\\"{x:1357,y:847,t:1527030829597};\\\", \\\"{x:1355,y:833,t:1527030829614};\\\", \\\"{x:1354,y:820,t:1527030829631};\\\", \\\"{x:1352,y:805,t:1527030829647};\\\", \\\"{x:1352,y:792,t:1527030829664};\\\", \\\"{x:1350,y:781,t:1527030829680};\\\", \\\"{x:1350,y:773,t:1527030829697};\\\", \\\"{x:1350,y:761,t:1527030829715};\\\", \\\"{x:1350,y:752,t:1527030829731};\\\", \\\"{x:1350,y:748,t:1527030829747};\\\", \\\"{x:1350,y:742,t:1527030829765};\\\", \\\"{x:1350,y:738,t:1527030829781};\\\", \\\"{x:1350,y:735,t:1527030829797};\\\", \\\"{x:1350,y:733,t:1527030829814};\\\", \\\"{x:1350,y:731,t:1527030829831};\\\", \\\"{x:1350,y:730,t:1527030829848};\\\", \\\"{x:1350,y:728,t:1527030830443};\\\", \\\"{x:1350,y:727,t:1527030830451};\\\", \\\"{x:1350,y:725,t:1527030830465};\\\", \\\"{x:1350,y:721,t:1527030830481};\\\", \\\"{x:1350,y:716,t:1527030830499};\\\", \\\"{x:1349,y:712,t:1527030830515};\\\", \\\"{x:1348,y:709,t:1527030830531};\\\", \\\"{x:1348,y:708,t:1527030830549};\\\", \\\"{x:1348,y:707,t:1527030830565};\\\", \\\"{x:1348,y:706,t:1527030830915};\\\", \\\"{x:1347,y:703,t:1527030830932};\\\", \\\"{x:1346,y:702,t:1527030830949};\\\", \\\"{x:1343,y:702,t:1527030842973};\\\", \\\"{x:1321,y:702,t:1527030842991};\\\", \\\"{x:1305,y:699,t:1527030843009};\\\", \\\"{x:1295,y:697,t:1527030843023};\\\", \\\"{x:1291,y:695,t:1527030843040};\\\", \\\"{x:1290,y:694,t:1527030843083};\\\", \\\"{x:1290,y:692,t:1527030843091};\\\", \\\"{x:1304,y:678,t:1527030843107};\\\", \\\"{x:1321,y:665,t:1527030843123};\\\", \\\"{x:1340,y:644,t:1527030843140};\\\", \\\"{x:1364,y:617,t:1527030843157};\\\", \\\"{x:1383,y:588,t:1527030843172};\\\", \\\"{x:1393,y:574,t:1527030843189};\\\", \\\"{x:1395,y:568,t:1527030843206};\\\", \\\"{x:1397,y:563,t:1527030843224};\\\", \\\"{x:1397,y:561,t:1527030843239};\\\", \\\"{x:1396,y:555,t:1527030843257};\\\", \\\"{x:1394,y:550,t:1527030843274};\\\", \\\"{x:1393,y:550,t:1527030843290};\\\", \\\"{x:1393,y:548,t:1527030843307};\\\", \\\"{x:1392,y:547,t:1527030843323};\\\", \\\"{x:1391,y:547,t:1527030843353};\\\", \\\"{x:1390,y:547,t:1527030843362};\\\", \\\"{x:1388,y:547,t:1527030843374};\\\", \\\"{x:1385,y:547,t:1527030843390};\\\", \\\"{x:1381,y:549,t:1527030843408};\\\", \\\"{x:1377,y:550,t:1527030843424};\\\", \\\"{x:1376,y:551,t:1527030843439};\\\", \\\"{x:1372,y:553,t:1527030843457};\\\", \\\"{x:1371,y:555,t:1527030843473};\\\", \\\"{x:1369,y:556,t:1527030843490};\\\", \\\"{x:1369,y:557,t:1527030843506};\\\", \\\"{x:1369,y:558,t:1527030843524};\\\", \\\"{x:1370,y:558,t:1527030843636};\\\", \\\"{x:1374,y:558,t:1527030843643};\\\", \\\"{x:1377,y:558,t:1527030843657};\\\", \\\"{x:1380,y:558,t:1527030843674};\\\", \\\"{x:1384,y:558,t:1527030843690};\\\", \\\"{x:1389,y:558,t:1527030843707};\\\", \\\"{x:1390,y:558,t:1527030843724};\\\", \\\"{x:1391,y:558,t:1527030843741};\\\", \\\"{x:1392,y:558,t:1527030843757};\\\", \\\"{x:1393,y:558,t:1527030843795};\\\", \\\"{x:1394,y:558,t:1527030843810};\\\", \\\"{x:1395,y:558,t:1527030843825};\\\", \\\"{x:1397,y:558,t:1527030843841};\\\", \\\"{x:1399,y:559,t:1527030843858};\\\", \\\"{x:1401,y:559,t:1527030843874};\\\", \\\"{x:1403,y:561,t:1527030843892};\\\", \\\"{x:1406,y:562,t:1527030843907};\\\", \\\"{x:1408,y:563,t:1527030843930};\\\", \\\"{x:1410,y:563,t:1527030843941};\\\", \\\"{x:1413,y:564,t:1527030843956};\\\", \\\"{x:1415,y:564,t:1527030843974};\\\", \\\"{x:1417,y:564,t:1527030844147};\\\", \\\"{x:1421,y:564,t:1527030844158};\\\", \\\"{x:1434,y:564,t:1527030844174};\\\", \\\"{x:1450,y:564,t:1527030844191};\\\", \\\"{x:1462,y:564,t:1527030844208};\\\", \\\"{x:1469,y:564,t:1527030844224};\\\", \\\"{x:1472,y:565,t:1527030844241};\\\", \\\"{x:1473,y:565,t:1527030844291};\\\", \\\"{x:1476,y:565,t:1527030844308};\\\", \\\"{x:1479,y:565,t:1527030844325};\\\", \\\"{x:1483,y:565,t:1527030844341};\\\", \\\"{x:1485,y:565,t:1527030844358};\\\", \\\"{x:1486,y:565,t:1527030844379};\\\", \\\"{x:1488,y:565,t:1527030844595};\\\", \\\"{x:1491,y:565,t:1527030844610};\\\", \\\"{x:1500,y:565,t:1527030844625};\\\", \\\"{x:1510,y:565,t:1527030844641};\\\", \\\"{x:1522,y:565,t:1527030844659};\\\", \\\"{x:1525,y:565,t:1527030844674};\\\", \\\"{x:1527,y:565,t:1527030844691};\\\", \\\"{x:1528,y:565,t:1527030844731};\\\", \\\"{x:1529,y:564,t:1527030844747};\\\", \\\"{x:1530,y:564,t:1527030844758};\\\", \\\"{x:1531,y:564,t:1527030844775};\\\", \\\"{x:1532,y:564,t:1527030844791};\\\", \\\"{x:1533,y:563,t:1527030844809};\\\", \\\"{x:1534,y:563,t:1527030845131};\\\", \\\"{x:1535,y:561,t:1527030845142};\\\", \\\"{x:1536,y:561,t:1527030845158};\\\", \\\"{x:1538,y:561,t:1527030845176};\\\", \\\"{x:1540,y:560,t:1527030845191};\\\", \\\"{x:1546,y:560,t:1527030846483};\\\", \\\"{x:1554,y:560,t:1527030846493};\\\", \\\"{x:1570,y:560,t:1527030846510};\\\", \\\"{x:1589,y:560,t:1527030846527};\\\", \\\"{x:1606,y:560,t:1527030846543};\\\", \\\"{x:1614,y:560,t:1527030846559};\\\", \\\"{x:1619,y:560,t:1527030846576};\\\", \\\"{x:1620,y:560,t:1527030846659};\\\", \\\"{x:1621,y:560,t:1527030846677};\\\", \\\"{x:1622,y:560,t:1527030846693};\\\", \\\"{x:1624,y:559,t:1527030846796};\\\", \\\"{x:1625,y:559,t:1527030846810};\\\", \\\"{x:1634,y:558,t:1527030846827};\\\", \\\"{x:1645,y:558,t:1527030846843};\\\", \\\"{x:1658,y:558,t:1527030846859};\\\", \\\"{x:1676,y:558,t:1527030846876};\\\", \\\"{x:1691,y:558,t:1527030846892};\\\", \\\"{x:1698,y:558,t:1527030846910};\\\", \\\"{x:1699,y:558,t:1527030846927};\\\", \\\"{x:1697,y:558,t:1527030847571};\\\", \\\"{x:1693,y:558,t:1527030847578};\\\", \\\"{x:1689,y:558,t:1527030847594};\\\", \\\"{x:1668,y:562,t:1527030847610};\\\", \\\"{x:1648,y:564,t:1527030847627};\\\", \\\"{x:1629,y:570,t:1527030847643};\\\", \\\"{x:1601,y:579,t:1527030847661};\\\", \\\"{x:1572,y:586,t:1527030847677};\\\", \\\"{x:1547,y:591,t:1527030847693};\\\", \\\"{x:1508,y:601,t:1527030847711};\\\", \\\"{x:1469,y:612,t:1527030847726};\\\", \\\"{x:1433,y:621,t:1527030847743};\\\", \\\"{x:1392,y:631,t:1527030847760};\\\", \\\"{x:1344,y:639,t:1527030847776};\\\", \\\"{x:1297,y:643,t:1527030847793};\\\", \\\"{x:1225,y:655,t:1527030847811};\\\", \\\"{x:1171,y:665,t:1527030847826};\\\", \\\"{x:1131,y:677,t:1527030847843};\\\", \\\"{x:1096,y:685,t:1527030847859};\\\", \\\"{x:1072,y:692,t:1527030847876};\\\", \\\"{x:1053,y:698,t:1527030847893};\\\", \\\"{x:1041,y:701,t:1527030847910};\\\", \\\"{x:1034,y:702,t:1527030847926};\\\", \\\"{x:1031,y:702,t:1527030847943};\\\", \\\"{x:1025,y:704,t:1527030847960};\\\", \\\"{x:1018,y:704,t:1527030847976};\\\", \\\"{x:1003,y:704,t:1527030847993};\\\", \\\"{x:970,y:704,t:1527030848011};\\\", \\\"{x:947,y:699,t:1527030848026};\\\", \\\"{x:923,y:697,t:1527030848043};\\\", \\\"{x:903,y:694,t:1527030848060};\\\", \\\"{x:882,y:694,t:1527030848076};\\\", \\\"{x:863,y:694,t:1527030848093};\\\", \\\"{x:845,y:694,t:1527030848110};\\\", \\\"{x:830,y:694,t:1527030848127};\\\", \\\"{x:820,y:694,t:1527030848143};\\\", \\\"{x:802,y:694,t:1527030848160};\\\", \\\"{x:786,y:696,t:1527030848177};\\\", \\\"{x:771,y:701,t:1527030848194};\\\", \\\"{x:745,y:706,t:1527030848211};\\\", \\\"{x:721,y:710,t:1527030848226};\\\", \\\"{x:699,y:717,t:1527030848243};\\\", \\\"{x:683,y:720,t:1527030848260};\\\", \\\"{x:666,y:725,t:1527030848277};\\\", \\\"{x:648,y:731,t:1527030848293};\\\", \\\"{x:631,y:734,t:1527030848311};\\\", \\\"{x:615,y:739,t:1527030848327};\\\", \\\"{x:602,y:743,t:1527030848344};\\\", \\\"{x:590,y:747,t:1527030848361};\\\", \\\"{x:582,y:751,t:1527030848378};\\\", \\\"{x:575,y:754,t:1527030848393};\\\", \\\"{x:571,y:758,t:1527030848410};\\\", \\\"{x:569,y:759,t:1527030848427};\\\", \\\"{x:568,y:760,t:1527030848443};\\\", \\\"{x:567,y:761,t:1527030848460};\\\", \\\"{x:566,y:762,t:1527030848477};\\\", \\\"{x:565,y:762,t:1527030848548};\\\", \\\"{x:565,y:761,t:1527030848561};\\\", \\\"{x:565,y:757,t:1527030848578};\\\", \\\"{x:565,y:751,t:1527030848594};\\\", \\\"{x:566,y:745,t:1527030848611};\\\", \\\"{x:566,y:740,t:1527030848627};\\\", \\\"{x:567,y:738,t:1527030848643};\\\", \\\"{x:567,y:737,t:1527030848661};\\\", \\\"{x:567,y:736,t:1527030848787};\\\", \\\"{x:566,y:736,t:1527030848795};\\\", \\\"{x:564,y:736,t:1527030848812};\\\", \\\"{x:560,y:737,t:1527030848827};\\\", \\\"{x:558,y:738,t:1527030848844};\\\", \\\"{x:556,y:738,t:1527030848859};\\\", \\\"{x:553,y:738,t:1527030848875};\\\", \\\"{x:551,y:740,t:1527030848893};\\\", \\\"{x:550,y:740,t:1527030848909};\\\", \\\"{x:549,y:740,t:1527030849058};\\\" ] }, { \\\"rt\\\": 9727, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 15, \\\"time_elapsed\\\": 643962, \\\"internal_node_id\\\": \\\"0.0-6.0-5.0\\\", \\\"subject\\\": \\\"Q0QHK\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"juliet\\\", \\\"condition\\\": \\\"115\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"starttime\\\", \\\"q\\\": 11, \\\"clicks\\\": 2, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XFull-YFull\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 1, \\\"answer\\\": [ \\\"F\\\", \\\"B\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-B \\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:555,y:742,t:1527030852859};\\\", \\\"{x:565,y:745,t:1527030852868};\\\", \\\"{x:575,y:748,t:1527030852879};\\\", \\\"{x:596,y:752,t:1527030852895};\\\", \\\"{x:621,y:758,t:1527030852916};\\\", \\\"{x:632,y:761,t:1527030852933};\\\", \\\"{x:638,y:762,t:1527030852949};\\\", \\\"{x:645,y:763,t:1527030852966};\\\", \\\"{x:650,y:764,t:1527030852983};\\\", \\\"{x:657,y:765,t:1527030852999};\\\", \\\"{x:668,y:767,t:1527030853016};\\\", \\\"{x:683,y:770,t:1527030853033};\\\", \\\"{x:709,y:772,t:1527030853050};\\\", \\\"{x:731,y:776,t:1527030853066};\\\", \\\"{x:754,y:781,t:1527030853083};\\\", \\\"{x:776,y:786,t:1527030853100};\\\", \\\"{x:797,y:791,t:1527030853116};\\\", \\\"{x:819,y:796,t:1527030853134};\\\", \\\"{x:840,y:800,t:1527030853150};\\\", \\\"{x:860,y:805,t:1527030853166};\\\", \\\"{x:881,y:810,t:1527030853183};\\\", \\\"{x:902,y:815,t:1527030853200};\\\", \\\"{x:924,y:822,t:1527030853216};\\\", \\\"{x:947,y:825,t:1527030853234};\\\", \\\"{x:978,y:830,t:1527030853250};\\\", \\\"{x:995,y:833,t:1527030853267};\\\", \\\"{x:1012,y:836,t:1527030853284};\\\", \\\"{x:1030,y:840,t:1527030853300};\\\", \\\"{x:1048,y:842,t:1527030853317};\\\", \\\"{x:1069,y:846,t:1527030853333};\\\", \\\"{x:1087,y:848,t:1527030853351};\\\", \\\"{x:1101,y:849,t:1527030853367};\\\", \\\"{x:1114,y:852,t:1527030853383};\\\", \\\"{x:1124,y:853,t:1527030853401};\\\", \\\"{x:1131,y:854,t:1527030853417};\\\", \\\"{x:1133,y:854,t:1527030853434};\\\", \\\"{x:1134,y:854,t:1527030853451};\\\", \\\"{x:1135,y:854,t:1527030853532};\\\", \\\"{x:1136,y:854,t:1527030853547};\\\", \\\"{x:1137,y:854,t:1527030853555};\\\", \\\"{x:1139,y:854,t:1527030853568};\\\", \\\"{x:1145,y:854,t:1527030853584};\\\", \\\"{x:1151,y:854,t:1527030853601};\\\", \\\"{x:1156,y:854,t:1527030853618};\\\", \\\"{x:1161,y:856,t:1527030853634};\\\", \\\"{x:1166,y:857,t:1527030853651};\\\", \\\"{x:1169,y:858,t:1527030853667};\\\", \\\"{x:1171,y:859,t:1527030853684};\\\", \\\"{x:1175,y:860,t:1527030853700};\\\", \\\"{x:1177,y:862,t:1527030853718};\\\", \\\"{x:1181,y:863,t:1527030853734};\\\", \\\"{x:1182,y:864,t:1527030853750};\\\", \\\"{x:1183,y:865,t:1527030853767};\\\", \\\"{x:1185,y:866,t:1527030853783};\\\", \\\"{x:1186,y:867,t:1527030853801};\\\", \\\"{x:1189,y:869,t:1527030853818};\\\", \\\"{x:1191,y:870,t:1527030853834};\\\", \\\"{x:1196,y:875,t:1527030853851};\\\", \\\"{x:1203,y:879,t:1527030853868};\\\", \\\"{x:1213,y:886,t:1527030853884};\\\", \\\"{x:1229,y:894,t:1527030853901};\\\", \\\"{x:1240,y:901,t:1527030853918};\\\", \\\"{x:1256,y:908,t:1527030853935};\\\", \\\"{x:1273,y:915,t:1527030853950};\\\", \\\"{x:1292,y:924,t:1527030853967};\\\", \\\"{x:1309,y:931,t:1527030853984};\\\", \\\"{x:1325,y:936,t:1527030854001};\\\", \\\"{x:1340,y:941,t:1527030854018};\\\", \\\"{x:1358,y:946,t:1527030854034};\\\", \\\"{x:1367,y:949,t:1527030854051};\\\", \\\"{x:1373,y:950,t:1527030854068};\\\", \\\"{x:1377,y:952,t:1527030854085};\\\", \\\"{x:1378,y:953,t:1527030854101};\\\", \\\"{x:1380,y:954,t:1527030854118};\\\", \\\"{x:1381,y:954,t:1527030854235};\\\", \\\"{x:1381,y:955,t:1527030854251};\\\", \\\"{x:1381,y:956,t:1527030854267};\\\", \\\"{x:1380,y:957,t:1527030854291};\\\", \\\"{x:1378,y:958,t:1527030854315};\\\", \\\"{x:1377,y:959,t:1527030854323};\\\", \\\"{x:1375,y:959,t:1527030854335};\\\", \\\"{x:1373,y:960,t:1527030854352};\\\", \\\"{x:1372,y:960,t:1527030854368};\\\", \\\"{x:1371,y:960,t:1527030854385};\\\", \\\"{x:1370,y:960,t:1527030854402};\\\", \\\"{x:1370,y:959,t:1527030854523};\\\", \\\"{x:1370,y:956,t:1527030854534};\\\", \\\"{x:1370,y:951,t:1527030854551};\\\", \\\"{x:1371,y:943,t:1527030854567};\\\", \\\"{x:1372,y:930,t:1527030854585};\\\", \\\"{x:1374,y:912,t:1527030854602};\\\", \\\"{x:1374,y:891,t:1527030854618};\\\", \\\"{x:1374,y:857,t:1527030854635};\\\", \\\"{x:1374,y:842,t:1527030854652};\\\", \\\"{x:1374,y:834,t:1527030854668};\\\", \\\"{x:1374,y:827,t:1527030854685};\\\", \\\"{x:1374,y:822,t:1527030854702};\\\", \\\"{x:1374,y:820,t:1527030854717};\\\", \\\"{x:1374,y:818,t:1527030854735};\\\", \\\"{x:1374,y:816,t:1527030854752};\\\", \\\"{x:1374,y:813,t:1527030854768};\\\", \\\"{x:1374,y:809,t:1527030854784};\\\", \\\"{x:1374,y:804,t:1527030854802};\\\", \\\"{x:1374,y:795,t:1527030854819};\\\", \\\"{x:1374,y:791,t:1527030854835};\\\", \\\"{x:1374,y:788,t:1527030854851};\\\", \\\"{x:1374,y:783,t:1527030854869};\\\", \\\"{x:1374,y:780,t:1527030854885};\\\", \\\"{x:1374,y:776,t:1527030854902};\\\", \\\"{x:1374,y:773,t:1527030854919};\\\", \\\"{x:1374,y:767,t:1527030854934};\\\", \\\"{x:1374,y:764,t:1527030854951};\\\", \\\"{x:1373,y:762,t:1527030854968};\\\", \\\"{x:1372,y:757,t:1527030854984};\\\", \\\"{x:1371,y:754,t:1527030855001};\\\", \\\"{x:1369,y:750,t:1527030855018};\\\", \\\"{x:1369,y:748,t:1527030855034};\\\", \\\"{x:1368,y:745,t:1527030855051};\\\", \\\"{x:1367,y:742,t:1527030855068};\\\", \\\"{x:1366,y:738,t:1527030855084};\\\", \\\"{x:1366,y:737,t:1527030855106};\\\", \\\"{x:1366,y:736,t:1527030855122};\\\", \\\"{x:1365,y:734,t:1527030855138};\\\", \\\"{x:1364,y:732,t:1527030855151};\\\", \\\"{x:1364,y:731,t:1527030855170};\\\", \\\"{x:1364,y:729,t:1527030855184};\\\", \\\"{x:1364,y:725,t:1527030855202};\\\", \\\"{x:1361,y:717,t:1527030855219};\\\", \\\"{x:1360,y:710,t:1527030855235};\\\", \\\"{x:1360,y:705,t:1527030855252};\\\", \\\"{x:1360,y:699,t:1527030855268};\\\", \\\"{x:1358,y:694,t:1527030855286};\\\", \\\"{x:1357,y:692,t:1527030855302};\\\", \\\"{x:1357,y:691,t:1527030855319};\\\", \\\"{x:1357,y:689,t:1527030855336};\\\", \\\"{x:1357,y:688,t:1527030855352};\\\", \\\"{x:1355,y:691,t:1527030855507};\\\", \\\"{x:1354,y:696,t:1527030855519};\\\", \\\"{x:1352,y:702,t:1527030855536};\\\", \\\"{x:1349,y:708,t:1527030855552};\\\", \\\"{x:1348,y:711,t:1527030855569};\\\", \\\"{x:1346,y:714,t:1527030855586};\\\", \\\"{x:1345,y:717,t:1527030855602};\\\", \\\"{x:1345,y:719,t:1527030855619};\\\", \\\"{x:1345,y:720,t:1527030855636};\\\", \\\"{x:1343,y:722,t:1527030855652};\\\", \\\"{x:1343,y:723,t:1527030855668};\\\", \\\"{x:1343,y:724,t:1527030855686};\\\", \\\"{x:1343,y:727,t:1527030855702};\\\", \\\"{x:1343,y:728,t:1527030855718};\\\", \\\"{x:1343,y:731,t:1527030855736};\\\", \\\"{x:1343,y:734,t:1527030855753};\\\", \\\"{x:1343,y:740,t:1527030855768};\\\", \\\"{x:1343,y:744,t:1527030855787};\\\", \\\"{x:1342,y:753,t:1527030855804};\\\", \\\"{x:1341,y:757,t:1527030855819};\\\", \\\"{x:1338,y:761,t:1527030855836};\\\", \\\"{x:1334,y:765,t:1527030855852};\\\", \\\"{x:1325,y:769,t:1527030855869};\\\", \\\"{x:1307,y:772,t:1527030855886};\\\", \\\"{x:1277,y:773,t:1527030855903};\\\", \\\"{x:1220,y:771,t:1527030855918};\\\", \\\"{x:1135,y:750,t:1527030855935};\\\", \\\"{x:1036,y:729,t:1527030855952};\\\", \\\"{x:950,y:716,t:1527030855968};\\\", \\\"{x:883,y:707,t:1527030855985};\\\", \\\"{x:831,y:697,t:1527030856001};\\\", \\\"{x:814,y:692,t:1527030856018};\\\", \\\"{x:810,y:690,t:1527030856035};\\\", \\\"{x:807,y:689,t:1527030856114};\\\", \\\"{x:803,y:688,t:1527030856130};\\\", \\\"{x:801,y:686,t:1527030856139};\\\", \\\"{x:797,y:685,t:1527030856153};\\\", \\\"{x:790,y:677,t:1527030856170};\\\", \\\"{x:781,y:665,t:1527030856186};\\\", \\\"{x:762,y:640,t:1527030856203};\\\", \\\"{x:743,y:621,t:1527030856220};\\\", \\\"{x:716,y:600,t:1527030856235};\\\", \\\"{x:686,y:581,t:1527030856252};\\\", \\\"{x:654,y:564,t:1527030856269};\\\", \\\"{x:626,y:553,t:1527030856285};\\\", \\\"{x:609,y:549,t:1527030856302};\\\", \\\"{x:595,y:547,t:1527030856319};\\\", \\\"{x:586,y:546,t:1527030856335};\\\", \\\"{x:580,y:546,t:1527030856352};\\\", \\\"{x:575,y:546,t:1527030856369};\\\", \\\"{x:569,y:546,t:1527030856386};\\\", \\\"{x:559,y:546,t:1527030856401};\\\", \\\"{x:550,y:546,t:1527030856419};\\\", \\\"{x:539,y:546,t:1527030856435};\\\", \\\"{x:521,y:546,t:1527030856452};\\\", \\\"{x:502,y:546,t:1527030856469};\\\", \\\"{x:483,y:546,t:1527030856486};\\\", \\\"{x:467,y:546,t:1527030856503};\\\", \\\"{x:454,y:546,t:1527030856519};\\\", \\\"{x:446,y:546,t:1527030856536};\\\", \\\"{x:439,y:545,t:1527030856552};\\\", \\\"{x:434,y:544,t:1527030856569};\\\", \\\"{x:430,y:542,t:1527030856587};\\\", \\\"{x:427,y:541,t:1527030856603};\\\", \\\"{x:422,y:539,t:1527030856619};\\\", \\\"{x:414,y:539,t:1527030856638};\\\", \\\"{x:403,y:539,t:1527030856652};\\\", \\\"{x:395,y:539,t:1527030856669};\\\", \\\"{x:389,y:539,t:1527030856687};\\\", \\\"{x:385,y:539,t:1527030856703};\\\", \\\"{x:382,y:539,t:1527030856720};\\\", \\\"{x:379,y:539,t:1527030856736};\\\", \\\"{x:374,y:539,t:1527030856753};\\\", \\\"{x:361,y:539,t:1527030856770};\\\", \\\"{x:329,y:539,t:1527030856785};\\\", \\\"{x:304,y:539,t:1527030856803};\\\", \\\"{x:278,y:539,t:1527030856819};\\\", \\\"{x:251,y:539,t:1527030856837};\\\", \\\"{x:224,y:539,t:1527030856853};\\\", \\\"{x:197,y:539,t:1527030856869};\\\", \\\"{x:176,y:539,t:1527030856887};\\\", \\\"{x:162,y:539,t:1527030856903};\\\", \\\"{x:157,y:539,t:1527030856919};\\\", \\\"{x:156,y:539,t:1527030857075};\\\", \\\"{x:156,y:543,t:1527030857378};\\\", \\\"{x:161,y:551,t:1527030857387};\\\", \\\"{x:173,y:569,t:1527030857404};\\\", \\\"{x:181,y:581,t:1527030857420};\\\", \\\"{x:187,y:589,t:1527030857436};\\\", \\\"{x:190,y:593,t:1527030857453};\\\", \\\"{x:192,y:596,t:1527030857471};\\\", \\\"{x:192,y:597,t:1527030857486};\\\", \\\"{x:192,y:598,t:1527030857505};\\\", \\\"{x:192,y:599,t:1527030857520};\\\", \\\"{x:192,y:600,t:1527030857536};\\\", \\\"{x:191,y:602,t:1527030857554};\\\", \\\"{x:187,y:604,t:1527030857570};\\\", \\\"{x:180,y:612,t:1527030857587};\\\", \\\"{x:176,y:614,t:1527030857603};\\\", \\\"{x:173,y:616,t:1527030857620};\\\", \\\"{x:171,y:618,t:1527030857637};\\\", \\\"{x:171,y:619,t:1527030857653};\\\", \\\"{x:169,y:625,t:1527030857671};\\\", \\\"{x:169,y:632,t:1527030857688};\\\", \\\"{x:169,y:638,t:1527030857703};\\\", \\\"{x:183,y:648,t:1527030857722};\\\", \\\"{x:203,y:652,t:1527030857737};\\\", \\\"{x:227,y:654,t:1527030857753};\\\", \\\"{x:269,y:655,t:1527030857770};\\\", \\\"{x:301,y:655,t:1527030857787};\\\", \\\"{x:340,y:638,t:1527030857803};\\\", \\\"{x:372,y:620,t:1527030857820};\\\", \\\"{x:397,y:605,t:1527030857837};\\\", \\\"{x:417,y:591,t:1527030857854};\\\", \\\"{x:426,y:582,t:1527030857870};\\\", \\\"{x:430,y:577,t:1527030857887};\\\", \\\"{x:430,y:576,t:1527030857903};\\\", \\\"{x:430,y:575,t:1527030857945};\\\", \\\"{x:430,y:574,t:1527030857954};\\\", \\\"{x:430,y:573,t:1527030857970};\\\", \\\"{x:430,y:569,t:1527030857987};\\\", \\\"{x:430,y:565,t:1527030858005};\\\", \\\"{x:430,y:561,t:1527030858023};\\\", \\\"{x:430,y:558,t:1527030858037};\\\", \\\"{x:430,y:554,t:1527030858054};\\\", \\\"{x:430,y:550,t:1527030858069};\\\", \\\"{x:430,y:545,t:1527030858087};\\\", \\\"{x:433,y:538,t:1527030858103};\\\", \\\"{x:439,y:532,t:1527030858120};\\\", \\\"{x:454,y:527,t:1527030858138};\\\", \\\"{x:486,y:519,t:1527030858154};\\\", \\\"{x:510,y:519,t:1527030858170};\\\", \\\"{x:532,y:519,t:1527030858188};\\\", \\\"{x:553,y:519,t:1527030858203};\\\", \\\"{x:565,y:519,t:1527030858220};\\\", \\\"{x:567,y:518,t:1527030858237};\\\", \\\"{x:568,y:518,t:1527030858253};\\\", \\\"{x:570,y:517,t:1527030858300};\\\", \\\"{x:573,y:515,t:1527030858320};\\\", \\\"{x:577,y:515,t:1527030858337};\\\", \\\"{x:588,y:512,t:1527030858354};\\\", \\\"{x:598,y:510,t:1527030858370};\\\", \\\"{x:614,y:505,t:1527030858387};\\\", \\\"{x:629,y:501,t:1527030858405};\\\", \\\"{x:635,y:500,t:1527030858420};\\\", \\\"{x:640,y:498,t:1527030858438};\\\", \\\"{x:645,y:497,t:1527030858455};\\\", \\\"{x:648,y:496,t:1527030858470};\\\", \\\"{x:653,y:495,t:1527030858487};\\\", \\\"{x:664,y:493,t:1527030858504};\\\", \\\"{x:685,y:490,t:1527030858520};\\\", \\\"{x:711,y:487,t:1527030858537};\\\", \\\"{x:752,y:481,t:1527030858554};\\\", \\\"{x:777,y:477,t:1527030858570};\\\", \\\"{x:795,y:475,t:1527030858587};\\\", \\\"{x:804,y:473,t:1527030858604};\\\", \\\"{x:807,y:473,t:1527030858621};\\\", \\\"{x:810,y:473,t:1527030858658};\\\", \\\"{x:811,y:473,t:1527030858671};\\\", \\\"{x:815,y:477,t:1527030858687};\\\", \\\"{x:819,y:480,t:1527030858704};\\\", \\\"{x:823,y:481,t:1527030858721};\\\", \\\"{x:823,y:482,t:1527030858737};\\\", \\\"{x:823,y:483,t:1527030858755};\\\", \\\"{x:825,y:485,t:1527030858771};\\\", \\\"{x:826,y:488,t:1527030858788};\\\", \\\"{x:828,y:493,t:1527030858805};\\\", \\\"{x:832,y:498,t:1527030858821};\\\", \\\"{x:838,y:504,t:1527030858837};\\\", \\\"{x:842,y:509,t:1527030858854};\\\", \\\"{x:844,y:511,t:1527030858871};\\\", \\\"{x:844,y:512,t:1527030859088};\\\", \\\"{x:842,y:513,t:1527030859162};\\\", \\\"{x:837,y:514,t:1527030859171};\\\", \\\"{x:814,y:525,t:1527030859189};\\\", \\\"{x:782,y:543,t:1527030859204};\\\", \\\"{x:733,y:584,t:1527030859222};\\\", \\\"{x:673,y:645,t:1527030859238};\\\", \\\"{x:624,y:696,t:1527030859255};\\\", \\\"{x:568,y:748,t:1527030859271};\\\", \\\"{x:531,y:784,t:1527030859288};\\\", \\\"{x:510,y:799,t:1527030859305};\\\", \\\"{x:499,y:806,t:1527030859322};\\\", \\\"{x:491,y:809,t:1527030859338};\\\", \\\"{x:490,y:810,t:1527030859355};\\\", \\\"{x:489,y:810,t:1527030859386};\\\", \\\"{x:488,y:810,t:1527030859402};\\\", \\\"{x:488,y:809,t:1527030859451};\\\", \\\"{x:488,y:807,t:1527030859514};\\\", \\\"{x:488,y:805,t:1527030859522};\\\", \\\"{x:492,y:790,t:1527030859538};\\\", \\\"{x:495,y:759,t:1527030859555};\\\", \\\"{x:498,y:724,t:1527030859571};\\\", \\\"{x:500,y:707,t:1527030859588};\\\", \\\"{x:502,y:703,t:1527030859606};\\\", \\\"{x:502,y:705,t:1527030859883};\\\", \\\"{x:503,y:709,t:1527030859890};\\\", \\\"{x:503,y:710,t:1527030859905};\\\", \\\"{x:503,y:713,t:1527030859922};\\\", \\\"{x:504,y:715,t:1527030859938};\\\", \\\"{x:504,y:716,t:1527030860115};\\\", \\\"{x:504,y:717,t:1527030860122};\\\", \\\"{x:504,y:724,t:1527030860140};\\\", \\\"{x:508,y:732,t:1527030860154};\\\", \\\"{x:510,y:740,t:1527030860172};\\\", \\\"{x:510,y:741,t:1527030860298};\\\", \\\"{x:510,y:742,t:1527030860322};\\\", \\\"{x:510,y:742,t:1527030860340};\\\", \\\"{x:510,y:743,t:1527030860355};\\\", \\\"{x:510,y:744,t:1527030860627};\\\", \\\"{x:510,y:745,t:1527030860642};\\\", \\\"{x:510,y:746,t:1527030860658};\\\" ] }, { \\\"rt\\\": 8864, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 16, \\\"time_elapsed\\\": 654039, \\\"internal_node_id\\\": \\\"0.0-6.0-6.0\\\", \\\"subject\\\": \\\"Q0QHK\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"juliet\\\", \\\"condition\\\": \\\"115\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"starts\\\", \\\"q\\\": 12, \\\"clicks\\\": 1, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XFull-YFull\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 1, \\\"answer\\\": [ \\\"B\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"\\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:511,y:747,t:1527030863731};\\\", \\\"{x:516,y:746,t:1527030863744};\\\", \\\"{x:538,y:736,t:1527030863759};\\\", \\\"{x:568,y:722,t:1527030863779};\\\", \\\"{x:647,y:700,t:1527030863794};\\\", \\\"{x:689,y:687,t:1527030863809};\\\", \\\"{x:733,y:675,t:1527030863826};\\\", \\\"{x:782,y:664,t:1527030863841};\\\", \\\"{x:827,y:656,t:1527030863857};\\\", \\\"{x:859,y:654,t:1527030863874};\\\", \\\"{x:892,y:653,t:1527030863891};\\\", \\\"{x:924,y:653,t:1527030863907};\\\", \\\"{x:952,y:653,t:1527030863924};\\\", \\\"{x:979,y:653,t:1527030863942};\\\", \\\"{x:1006,y:653,t:1527030863958};\\\", \\\"{x:1035,y:653,t:1527030863975};\\\", \\\"{x:1062,y:653,t:1527030863991};\\\", \\\"{x:1090,y:653,t:1527030864007};\\\", \\\"{x:1115,y:653,t:1527030864025};\\\", \\\"{x:1143,y:653,t:1527030864042};\\\", \\\"{x:1182,y:653,t:1527030864058};\\\", \\\"{x:1208,y:656,t:1527030864075};\\\", \\\"{x:1231,y:661,t:1527030864092};\\\", \\\"{x:1251,y:663,t:1527030864108};\\\", \\\"{x:1270,y:666,t:1527030864125};\\\", \\\"{x:1284,y:669,t:1527030864142};\\\", \\\"{x:1299,y:672,t:1527030864159};\\\", \\\"{x:1311,y:676,t:1527030864175};\\\", \\\"{x:1324,y:679,t:1527030864192};\\\", \\\"{x:1340,y:685,t:1527030864209};\\\", \\\"{x:1355,y:692,t:1527030864226};\\\", \\\"{x:1368,y:697,t:1527030864242};\\\", \\\"{x:1379,y:702,t:1527030864259};\\\", \\\"{x:1390,y:707,t:1527030864275};\\\", \\\"{x:1398,y:710,t:1527030864292};\\\", \\\"{x:1400,y:712,t:1527030864309};\\\", \\\"{x:1401,y:713,t:1527030864325};\\\", \\\"{x:1402,y:713,t:1527030864347};\\\", \\\"{x:1403,y:714,t:1527030864403};\\\", \\\"{x:1404,y:715,t:1527030864539};\\\", \\\"{x:1403,y:716,t:1527030864587};\\\", \\\"{x:1403,y:717,t:1527030864595};\\\", \\\"{x:1401,y:716,t:1527030864843};\\\", \\\"{x:1400,y:715,t:1527030864899};\\\", \\\"{x:1399,y:714,t:1527030865115};\\\", \\\"{x:1397,y:714,t:1527030865126};\\\", \\\"{x:1391,y:712,t:1527030865142};\\\", \\\"{x:1380,y:712,t:1527030865160};\\\", \\\"{x:1361,y:710,t:1527030865176};\\\", \\\"{x:1346,y:710,t:1527030865192};\\\", \\\"{x:1334,y:708,t:1527030865210};\\\", \\\"{x:1316,y:708,t:1527030865226};\\\", \\\"{x:1301,y:707,t:1527030865242};\\\", \\\"{x:1285,y:704,t:1527030865259};\\\", \\\"{x:1270,y:702,t:1527030865277};\\\", \\\"{x:1257,y:699,t:1527030865293};\\\", \\\"{x:1247,y:698,t:1527030865309};\\\", \\\"{x:1238,y:697,t:1527030865327};\\\", \\\"{x:1234,y:695,t:1527030865343};\\\", \\\"{x:1231,y:695,t:1527030865359};\\\", \\\"{x:1230,y:695,t:1527030865376};\\\", \\\"{x:1228,y:695,t:1527030865393};\\\", \\\"{x:1226,y:695,t:1527030865410};\\\", \\\"{x:1215,y:694,t:1527030865427};\\\", \\\"{x:1199,y:693,t:1527030865443};\\\", \\\"{x:1170,y:688,t:1527030865460};\\\", \\\"{x:1103,y:678,t:1527030865476};\\\", \\\"{x:989,y:662,t:1527030865493};\\\", \\\"{x:831,y:640,t:1527030865509};\\\", \\\"{x:644,y:617,t:1527030865527};\\\", \\\"{x:460,y:603,t:1527030865543};\\\", \\\"{x:302,y:597,t:1527030865559};\\\", \\\"{x:210,y:597,t:1527030865577};\\\", \\\"{x:164,y:597,t:1527030865592};\\\", \\\"{x:159,y:597,t:1527030865609};\\\", \\\"{x:160,y:597,t:1527030865633};\\\", \\\"{x:167,y:597,t:1527030865644};\\\", \\\"{x:185,y:597,t:1527030865660};\\\", \\\"{x:198,y:597,t:1527030865676};\\\", \\\"{x:202,y:598,t:1527030865694};\\\", \\\"{x:204,y:598,t:1527030865710};\\\", \\\"{x:205,y:598,t:1527030865727};\\\", \\\"{x:206,y:598,t:1527030865754};\\\", \\\"{x:207,y:598,t:1527030865762};\\\", \\\"{x:208,y:598,t:1527030865786};\\\", \\\"{x:209,y:597,t:1527030865794};\\\", \\\"{x:210,y:592,t:1527030865811};\\\", \\\"{x:211,y:579,t:1527030865826};\\\", \\\"{x:208,y:562,t:1527030865843};\\\", \\\"{x:202,y:550,t:1527030865860};\\\", \\\"{x:197,y:543,t:1527030865876};\\\", \\\"{x:191,y:540,t:1527030865894};\\\", \\\"{x:187,y:539,t:1527030865909};\\\", \\\"{x:183,y:538,t:1527030865926};\\\", \\\"{x:181,y:536,t:1527030865943};\\\", \\\"{x:179,y:535,t:1527030865960};\\\", \\\"{x:176,y:535,t:1527030865977};\\\", \\\"{x:171,y:533,t:1527030865993};\\\", \\\"{x:166,y:532,t:1527030866011};\\\", \\\"{x:164,y:532,t:1527030866026};\\\", \\\"{x:162,y:532,t:1527030866044};\\\", \\\"{x:161,y:532,t:1527030866115};\\\", \\\"{x:160,y:532,t:1527030866138};\\\", \\\"{x:159,y:532,t:1527030866313};\\\", \\\"{x:160,y:532,t:1527030866450};\\\", \\\"{x:170,y:536,t:1527030866461};\\\", \\\"{x:194,y:546,t:1527030866477};\\\", \\\"{x:232,y:560,t:1527030866495};\\\", \\\"{x:273,y:577,t:1527030866512};\\\", \\\"{x:320,y:596,t:1527030866528};\\\", \\\"{x:363,y:613,t:1527030866545};\\\", \\\"{x:392,y:628,t:1527030866560};\\\", \\\"{x:430,y:647,t:1527030866578};\\\", \\\"{x:453,y:658,t:1527030866593};\\\", \\\"{x:464,y:662,t:1527030866610};\\\", \\\"{x:469,y:665,t:1527030866627};\\\", \\\"{x:471,y:665,t:1527030866643};\\\", \\\"{x:472,y:667,t:1527030866714};\\\", \\\"{x:473,y:667,t:1527030866730};\\\", \\\"{x:474,y:668,t:1527030866743};\\\", \\\"{x:474,y:669,t:1527030866761};\\\", \\\"{x:481,y:676,t:1527030866779};\\\", \\\"{x:485,y:682,t:1527030866795};\\\", \\\"{x:491,y:693,t:1527030866811};\\\", \\\"{x:493,y:699,t:1527030866828};\\\", \\\"{x:493,y:704,t:1527030866844};\\\", \\\"{x:494,y:710,t:1527030866861};\\\", \\\"{x:494,y:714,t:1527030866878};\\\", \\\"{x:494,y:718,t:1527030866894};\\\", \\\"{x:494,y:721,t:1527030866912};\\\", \\\"{x:494,y:723,t:1527030866928};\\\", \\\"{x:494,y:725,t:1527030866945};\\\", \\\"{x:494,y:726,t:1527030866961};\\\", \\\"{x:493,y:728,t:1527030866977};\\\", \\\"{x:493,y:731,t:1527030866994};\\\" ] }, { \\\"rt\\\": 15463, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 17, \\\"time_elapsed\\\": 670776, \\\"internal_node_id\\\": \\\"0.0-6.0-7.0\\\", \\\"subject\\\": \\\"Q0QHK\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"juliet\\\", \\\"condition\\\": \\\"115\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"meets\\\", \\\"q\\\": 13, \\\"clicks\\\": 2.5, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XFull-YFull\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 1, \\\"answer\\\": [ \\\"F\\\", \\\"X\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-Z \\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:494,y:731,t:1527030873635};\\\", \\\"{x:495,y:730,t:1527030873650};\\\", \\\"{x:495,y:728,t:1527030873674};\\\", \\\"{x:497,y:727,t:1527030873698};\\\", \\\"{x:498,y:725,t:1527030873716};\\\", \\\"{x:498,y:724,t:1527030874355};\\\", \\\"{x:500,y:724,t:1527030874367};\\\", \\\"{x:514,y:723,t:1527030874384};\\\", \\\"{x:533,y:723,t:1527030874399};\\\", \\\"{x:558,y:723,t:1527030874416};\\\", \\\"{x:589,y:726,t:1527030874434};\\\", \\\"{x:629,y:733,t:1527030874449};\\\", \\\"{x:714,y:744,t:1527030874465};\\\", \\\"{x:789,y:753,t:1527030874483};\\\", \\\"{x:861,y:762,t:1527030874500};\\\", \\\"{x:926,y:772,t:1527030874517};\\\", \\\"{x:995,y:781,t:1527030874533};\\\", \\\"{x:1060,y:792,t:1527030874550};\\\", \\\"{x:1132,y:801,t:1527030874567};\\\", \\\"{x:1224,y:815,t:1527030874583};\\\", \\\"{x:1311,y:830,t:1527030874600};\\\", \\\"{x:1416,y:844,t:1527030874617};\\\", \\\"{x:1575,y:866,t:1527030874634};\\\", \\\"{x:1681,y:882,t:1527030874651};\\\", \\\"{x:1778,y:895,t:1527030874667};\\\", \\\"{x:1863,y:914,t:1527030874684};\\\", \\\"{x:1919,y:922,t:1527030874701};\\\", \\\"{x:1919,y:926,t:1527030874717};\\\", \\\"{x:1919,y:928,t:1527030874734};\\\", \\\"{x:1918,y:928,t:1527030875019};\\\", \\\"{x:1916,y:928,t:1527030875034};\\\", \\\"{x:1914,y:926,t:1527030875052};\\\", \\\"{x:1909,y:924,t:1527030875068};\\\", \\\"{x:1907,y:922,t:1527030875084};\\\", \\\"{x:1904,y:922,t:1527030875101};\\\", \\\"{x:1902,y:921,t:1527030875118};\\\", \\\"{x:1901,y:920,t:1527030875203};\\\", \\\"{x:1901,y:919,t:1527030875217};\\\", \\\"{x:1894,y:906,t:1527030875234};\\\", \\\"{x:1887,y:894,t:1527030875252};\\\", \\\"{x:1871,y:870,t:1527030875269};\\\", \\\"{x:1854,y:842,t:1527030875284};\\\", \\\"{x:1836,y:788,t:1527030875302};\\\", \\\"{x:1808,y:737,t:1527030875319};\\\", \\\"{x:1783,y:708,t:1527030875334};\\\", \\\"{x:1765,y:693,t:1527030875351};\\\", \\\"{x:1746,y:679,t:1527030875368};\\\", \\\"{x:1731,y:669,t:1527030875385};\\\", \\\"{x:1720,y:663,t:1527030875402};\\\", \\\"{x:1703,y:656,t:1527030875419};\\\", \\\"{x:1695,y:652,t:1527030875435};\\\", \\\"{x:1686,y:650,t:1527030875452};\\\", \\\"{x:1679,y:648,t:1527030875469};\\\", \\\"{x:1674,y:648,t:1527030875485};\\\", \\\"{x:1670,y:648,t:1527030875501};\\\", \\\"{x:1667,y:648,t:1527030875518};\\\", \\\"{x:1660,y:650,t:1527030875536};\\\", \\\"{x:1655,y:657,t:1527030875551};\\\", \\\"{x:1646,y:667,t:1527030875569};\\\", \\\"{x:1640,y:673,t:1527030875585};\\\", \\\"{x:1637,y:676,t:1527030875602};\\\", \\\"{x:1634,y:679,t:1527030875618};\\\", \\\"{x:1633,y:680,t:1527030875667};\\\", \\\"{x:1633,y:681,t:1527030875690};\\\", \\\"{x:1632,y:681,t:1527030875702};\\\", \\\"{x:1631,y:683,t:1527030875719};\\\", \\\"{x:1629,y:683,t:1527030875735};\\\", \\\"{x:1627,y:684,t:1527030875753};\\\", \\\"{x:1625,y:685,t:1527030875867};\\\", \\\"{x:1625,y:686,t:1527030875874};\\\", \\\"{x:1624,y:686,t:1527030875885};\\\", \\\"{x:1624,y:687,t:1527030875903};\\\", \\\"{x:1623,y:687,t:1527030875919};\\\", \\\"{x:1622,y:689,t:1527030875936};\\\", \\\"{x:1621,y:690,t:1527030876123};\\\", \\\"{x:1621,y:691,t:1527030876136};\\\", \\\"{x:1621,y:692,t:1527030876153};\\\", \\\"{x:1620,y:692,t:1527030876178};\\\", \\\"{x:1620,y:693,t:1527030876229};\\\", \\\"{x:1615,y:696,t:1527030882743};\\\", \\\"{x:1602,y:702,t:1527030882753};\\\", \\\"{x:1557,y:715,t:1527030882769};\\\", \\\"{x:1472,y:734,t:1527030882785};\\\", \\\"{x:1383,y:745,t:1527030882802};\\\", \\\"{x:1260,y:748,t:1527030882819};\\\", \\\"{x:1189,y:754,t:1527030882835};\\\", \\\"{x:1108,y:765,t:1527030882852};\\\", \\\"{x:1025,y:774,t:1527030882869};\\\", \\\"{x:945,y:774,t:1527030882885};\\\", \\\"{x:881,y:774,t:1527030882902};\\\", \\\"{x:825,y:774,t:1527030882919};\\\", \\\"{x:772,y:774,t:1527030882935};\\\", \\\"{x:732,y:768,t:1527030882952};\\\", \\\"{x:696,y:759,t:1527030882970};\\\", \\\"{x:670,y:752,t:1527030882985};\\\", \\\"{x:646,y:744,t:1527030883002};\\\", \\\"{x:614,y:734,t:1527030883020};\\\", \\\"{x:594,y:728,t:1527030883035};\\\", \\\"{x:573,y:723,t:1527030883052};\\\", \\\"{x:552,y:715,t:1527030883070};\\\", \\\"{x:533,y:706,t:1527030883086};\\\", \\\"{x:518,y:698,t:1527030883103};\\\", \\\"{x:508,y:689,t:1527030883119};\\\", \\\"{x:503,y:675,t:1527030883137};\\\", \\\"{x:503,y:656,t:1527030883153};\\\", \\\"{x:503,y:639,t:1527030883170};\\\", \\\"{x:511,y:621,t:1527030883189};\\\", \\\"{x:522,y:605,t:1527030883202};\\\", \\\"{x:530,y:592,t:1527030883219};\\\", \\\"{x:532,y:588,t:1527030883234};\\\", \\\"{x:532,y:586,t:1527030883250};\\\", \\\"{x:534,y:585,t:1527030883267};\\\", \\\"{x:535,y:584,t:1527030883285};\\\", \\\"{x:536,y:582,t:1527030883300};\\\", \\\"{x:537,y:582,t:1527030883323};\\\", \\\"{x:538,y:582,t:1527030883334};\\\", \\\"{x:541,y:582,t:1527030883350};\\\", \\\"{x:548,y:582,t:1527030883367};\\\", \\\"{x:556,y:582,t:1527030883384};\\\", \\\"{x:565,y:582,t:1527030883400};\\\", \\\"{x:570,y:582,t:1527030883417};\\\", \\\"{x:574,y:581,t:1527030883435};\\\", \\\"{x:579,y:580,t:1527030883451};\\\", \\\"{x:585,y:577,t:1527030883467};\\\", \\\"{x:589,y:574,t:1527030883485};\\\", \\\"{x:592,y:573,t:1527030883502};\\\", \\\"{x:594,y:572,t:1527030883518};\\\", \\\"{x:595,y:571,t:1527030883534};\\\", \\\"{x:598,y:570,t:1527030883828};\\\", \\\"{x:602,y:570,t:1527030883836};\\\", \\\"{x:608,y:570,t:1527030883851};\\\", \\\"{x:617,y:571,t:1527030883867};\\\", \\\"{x:624,y:571,t:1527030883884};\\\", \\\"{x:625,y:572,t:1527030884068};\\\", \\\"{x:625,y:573,t:1527030884083};\\\", \\\"{x:625,y:575,t:1527030884100};\\\", \\\"{x:623,y:575,t:1527030884118};\\\", \\\"{x:622,y:576,t:1527030884135};\\\", \\\"{x:621,y:576,t:1527030884151};\\\", \\\"{x:620,y:576,t:1527030884168};\\\", \\\"{x:621,y:577,t:1527030884635};\\\", \\\"{x:626,y:577,t:1527030884650};\\\", \\\"{x:655,y:584,t:1527030884667};\\\", \\\"{x:676,y:588,t:1527030884684};\\\", \\\"{x:688,y:589,t:1527030884702};\\\", \\\"{x:689,y:590,t:1527030884731};\\\", \\\"{x:687,y:590,t:1527030884748};\\\", \\\"{x:682,y:590,t:1527030884755};\\\", \\\"{x:674,y:590,t:1527030884768};\\\", \\\"{x:657,y:590,t:1527030884785};\\\", \\\"{x:638,y:590,t:1527030884801};\\\", \\\"{x:620,y:590,t:1527030884819};\\\", \\\"{x:604,y:588,t:1527030884849};\\\", \\\"{x:603,y:588,t:1527030884851};\\\", \\\"{x:602,y:586,t:1527030885052};\\\", \\\"{x:602,y:585,t:1527030885068};\\\", \\\"{x:602,y:584,t:1527030885092};\\\", \\\"{x:602,y:583,t:1527030885107};\\\", \\\"{x:603,y:582,t:1527030885118};\\\", \\\"{x:604,y:581,t:1527030885147};\\\", \\\"{x:603,y:581,t:1527030885420};\\\", \\\"{x:594,y:584,t:1527030885435};\\\", \\\"{x:581,y:590,t:1527030885452};\\\", \\\"{x:568,y:595,t:1527030885469};\\\", \\\"{x:555,y:599,t:1527030885486};\\\", \\\"{x:543,y:602,t:1527030885503};\\\", \\\"{x:532,y:602,t:1527030885520};\\\", \\\"{x:522,y:602,t:1527030885535};\\\", \\\"{x:514,y:602,t:1527030885552};\\\", \\\"{x:505,y:602,t:1527030885569};\\\", \\\"{x:497,y:602,t:1527030885586};\\\", \\\"{x:492,y:602,t:1527030885602};\\\", \\\"{x:489,y:602,t:1527030885619};\\\", \\\"{x:490,y:599,t:1527030885676};\\\", \\\"{x:497,y:595,t:1527030885686};\\\", \\\"{x:516,y:588,t:1527030885702};\\\", \\\"{x:541,y:578,t:1527030885719};\\\", \\\"{x:590,y:570,t:1527030885736};\\\", \\\"{x:642,y:566,t:1527030885752};\\\", \\\"{x:692,y:558,t:1527030885769};\\\", \\\"{x:740,y:552,t:1527030885787};\\\", \\\"{x:775,y:545,t:1527030885802};\\\", \\\"{x:811,y:538,t:1527030885819};\\\", \\\"{x:824,y:536,t:1527030885837};\\\", \\\"{x:834,y:532,t:1527030885852};\\\", \\\"{x:836,y:530,t:1527030885869};\\\", \\\"{x:838,y:530,t:1527030885886};\\\", \\\"{x:840,y:528,t:1527030885903};\\\", \\\"{x:842,y:527,t:1527030885920};\\\", \\\"{x:845,y:525,t:1527030885936};\\\", \\\"{x:848,y:524,t:1527030885953};\\\", \\\"{x:851,y:522,t:1527030885969};\\\", \\\"{x:852,y:521,t:1527030885986};\\\", \\\"{x:854,y:517,t:1527030886004};\\\", \\\"{x:855,y:514,t:1527030886019};\\\", \\\"{x:855,y:511,t:1527030886036};\\\", \\\"{x:855,y:510,t:1527030886053};\\\", \\\"{x:855,y:509,t:1527030886069};\\\", \\\"{x:855,y:508,t:1527030886087};\\\", \\\"{x:855,y:507,t:1527030886220};\\\", \\\"{x:855,y:505,t:1527030886237};\\\", \\\"{x:854,y:504,t:1527030886253};\\\", \\\"{x:853,y:503,t:1527030886276};\\\", \\\"{x:852,y:503,t:1527030886291};\\\", \\\"{x:851,y:503,t:1527030886302};\\\", \\\"{x:850,y:501,t:1527030886319};\\\", \\\"{x:850,y:502,t:1527030886507};\\\", \\\"{x:850,y:504,t:1527030886520};\\\", \\\"{x:850,y:505,t:1527030886536};\\\", \\\"{x:847,y:508,t:1527030886553};\\\", \\\"{x:837,y:513,t:1527030886570};\\\", \\\"{x:818,y:523,t:1527030886586};\\\", \\\"{x:787,y:544,t:1527030886603};\\\", \\\"{x:765,y:562,t:1527030886620};\\\", \\\"{x:747,y:580,t:1527030886637};\\\", \\\"{x:734,y:595,t:1527030886654};\\\", \\\"{x:721,y:614,t:1527030886671};\\\", \\\"{x:710,y:628,t:1527030886686};\\\", \\\"{x:699,y:641,t:1527030886703};\\\", \\\"{x:689,y:649,t:1527030886720};\\\", \\\"{x:677,y:659,t:1527030886736};\\\", \\\"{x:663,y:667,t:1527030886754};\\\", \\\"{x:644,y:678,t:1527030886769};\\\", \\\"{x:623,y:691,t:1527030886787};\\\", \\\"{x:596,y:709,t:1527030886803};\\\", \\\"{x:586,y:714,t:1527030886820};\\\", \\\"{x:582,y:716,t:1527030886836};\\\", \\\"{x:579,y:718,t:1527030886854};\\\", \\\"{x:577,y:719,t:1527030886869};\\\", \\\"{x:576,y:721,t:1527030886886};\\\", \\\"{x:573,y:726,t:1527030886903};\\\", \\\"{x:569,y:730,t:1527030886920};\\\", \\\"{x:563,y:736,t:1527030886937};\\\", \\\"{x:556,y:742,t:1527030886953};\\\", \\\"{x:552,y:743,t:1527030886971};\\\", \\\"{x:550,y:744,t:1527030886987};\\\" ] }, { \\\"rt\\\": 28480, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 18, \\\"time_elapsed\\\": 700459, \\\"internal_node_id\\\": \\\"0.0-6.0-8.0\\\", \\\"subject\\\": \\\"Q0QHK\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"juliet\\\", \\\"condition\\\": \\\"115\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"endtime\\\", \\\"q\\\": 14, \\\"clicks\\\": 1.5, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XFull-YFull\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 1, \\\"answer\\\": [ \\\"B\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-03 PM-B -O -B -B -B \\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:552,y:745,t:1527030889955};\\\", \\\"{x:582,y:753,t:1527030889970};\\\", \\\"{x:690,y:783,t:1527030889985};\\\", \\\"{x:903,y:844,t:1527030890006};\\\", \\\"{x:1079,y:885,t:1527030890023};\\\", \\\"{x:1239,y:929,t:1527030890040};\\\", \\\"{x:1366,y:963,t:1527030890056};\\\", \\\"{x:1457,y:988,t:1527030890073};\\\", \\\"{x:1496,y:999,t:1527030890090};\\\", \\\"{x:1513,y:1005,t:1527030890107};\\\", \\\"{x:1518,y:1006,t:1527030890123};\\\", \\\"{x:1520,y:1007,t:1527030890139};\\\", \\\"{x:1523,y:1007,t:1527030890157};\\\", \\\"{x:1532,y:1009,t:1527030890174};\\\", \\\"{x:1541,y:1011,t:1527030890190};\\\", \\\"{x:1555,y:1016,t:1527030890206};\\\", \\\"{x:1572,y:1022,t:1527030890224};\\\", \\\"{x:1588,y:1028,t:1527030890240};\\\", \\\"{x:1599,y:1032,t:1527030890257};\\\", \\\"{x:1604,y:1035,t:1527030890274};\\\", \\\"{x:1615,y:1037,t:1527030890290};\\\", \\\"{x:1616,y:1037,t:1527030890307};\\\", \\\"{x:1618,y:1036,t:1527030890323};\\\", \\\"{x:1618,y:1034,t:1527030890356};\\\", \\\"{x:1618,y:1033,t:1527030890364};\\\", \\\"{x:1617,y:1029,t:1527030890374};\\\", \\\"{x:1613,y:1025,t:1527030890390};\\\", \\\"{x:1608,y:1017,t:1527030890407};\\\", \\\"{x:1604,y:1011,t:1527030890424};\\\", \\\"{x:1600,y:1007,t:1527030890441};\\\", \\\"{x:1597,y:1002,t:1527030890457};\\\", \\\"{x:1593,y:998,t:1527030890474};\\\", \\\"{x:1589,y:994,t:1527030890491};\\\", \\\"{x:1586,y:991,t:1527030890507};\\\", \\\"{x:1580,y:989,t:1527030890524};\\\", \\\"{x:1577,y:986,t:1527030890541};\\\", \\\"{x:1574,y:985,t:1527030890557};\\\", \\\"{x:1571,y:983,t:1527030890574};\\\", \\\"{x:1569,y:982,t:1527030890591};\\\", \\\"{x:1566,y:980,t:1527030890608};\\\", \\\"{x:1564,y:979,t:1527030890624};\\\", \\\"{x:1562,y:978,t:1527030890641};\\\", \\\"{x:1559,y:976,t:1527030890658};\\\", \\\"{x:1553,y:973,t:1527030890674};\\\", \\\"{x:1549,y:970,t:1527030890691};\\\", \\\"{x:1546,y:968,t:1527030890709};\\\", \\\"{x:1544,y:967,t:1527030890724};\\\", \\\"{x:1543,y:967,t:1527030890741};\\\", \\\"{x:1542,y:967,t:1527030890758};\\\", \\\"{x:1541,y:966,t:1527030890804};\\\", \\\"{x:1541,y:965,t:1527030890893};\\\", \\\"{x:1538,y:966,t:1527030890908};\\\", \\\"{x:1536,y:966,t:1527030890925};\\\", \\\"{x:1536,y:959,t:1527030891117};\\\", \\\"{x:1539,y:949,t:1527030891125};\\\", \\\"{x:1543,y:929,t:1527030891142};\\\", \\\"{x:1553,y:897,t:1527030891158};\\\", \\\"{x:1563,y:866,t:1527030891175};\\\", \\\"{x:1567,y:843,t:1527030891192};\\\", \\\"{x:1569,y:816,t:1527030891208};\\\", \\\"{x:1569,y:790,t:1527030891225};\\\", \\\"{x:1569,y:767,t:1527030891242};\\\", \\\"{x:1569,y:749,t:1527030891259};\\\", \\\"{x:1569,y:734,t:1527030891275};\\\", \\\"{x:1569,y:720,t:1527030891292};\\\", \\\"{x:1569,y:709,t:1527030891308};\\\", \\\"{x:1569,y:702,t:1527030891325};\\\", \\\"{x:1569,y:696,t:1527030891342};\\\", \\\"{x:1569,y:691,t:1527030891359};\\\", \\\"{x:1567,y:685,t:1527030891374};\\\", \\\"{x:1566,y:684,t:1527030891391};\\\", \\\"{x:1566,y:683,t:1527030891611};\\\", \\\"{x:1565,y:683,t:1527030891635};\\\", \\\"{x:1563,y:684,t:1527030891813};\\\", \\\"{x:1563,y:685,t:1527030891826};\\\", \\\"{x:1561,y:686,t:1527030891843};\\\", \\\"{x:1560,y:686,t:1527030891860};\\\", \\\"{x:1559,y:687,t:1527030891877};\\\", \\\"{x:1558,y:688,t:1527030891901};\\\", \\\"{x:1557,y:688,t:1527030898157};\\\", \\\"{x:1555,y:688,t:1527030898187};\\\", \\\"{x:1554,y:688,t:1527030900883};\\\", \\\"{x:1553,y:689,t:1527030900891};\\\", \\\"{x:1552,y:689,t:1527030900915};\\\", \\\"{x:1551,y:690,t:1527030900939};\\\", \\\"{x:1550,y:690,t:1527030900956};\\\", \\\"{x:1548,y:691,t:1527030903164};\\\", \\\"{x:1546,y:691,t:1527030903176};\\\", \\\"{x:1537,y:695,t:1527030903193};\\\", \\\"{x:1525,y:696,t:1527030903209};\\\", \\\"{x:1507,y:699,t:1527030903226};\\\", \\\"{x:1487,y:699,t:1527030903243};\\\", \\\"{x:1479,y:699,t:1527030903259};\\\", \\\"{x:1472,y:699,t:1527030903276};\\\", \\\"{x:1466,y:699,t:1527030903293};\\\", \\\"{x:1462,y:699,t:1527030903310};\\\", \\\"{x:1458,y:699,t:1527030903326};\\\", \\\"{x:1451,y:699,t:1527030903343};\\\", \\\"{x:1443,y:699,t:1527030903359};\\\", \\\"{x:1433,y:699,t:1527030903376};\\\", \\\"{x:1424,y:699,t:1527030903392};\\\", \\\"{x:1411,y:699,t:1527030903410};\\\", \\\"{x:1400,y:699,t:1527030903426};\\\", \\\"{x:1385,y:699,t:1527030903442};\\\", \\\"{x:1376,y:699,t:1527030903459};\\\", \\\"{x:1370,y:699,t:1527030903476};\\\", \\\"{x:1367,y:699,t:1527030903493};\\\", \\\"{x:1366,y:700,t:1527030903595};\\\", \\\"{x:1369,y:703,t:1527030903619};\\\", \\\"{x:1374,y:704,t:1527030903627};\\\", \\\"{x:1387,y:705,t:1527030903643};\\\", \\\"{x:1405,y:707,t:1527030903660};\\\", \\\"{x:1423,y:709,t:1527030903678};\\\", \\\"{x:1440,y:709,t:1527030903693};\\\", \\\"{x:1455,y:709,t:1527030903711};\\\", \\\"{x:1463,y:709,t:1527030903727};\\\", \\\"{x:1466,y:709,t:1527030903744};\\\", \\\"{x:1469,y:708,t:1527030903761};\\\", \\\"{x:1470,y:707,t:1527030903777};\\\", \\\"{x:1472,y:706,t:1527030903795};\\\", \\\"{x:1472,y:705,t:1527030903811};\\\", \\\"{x:1473,y:705,t:1527030903900};\\\", \\\"{x:1473,y:704,t:1527030903916};\\\", \\\"{x:1475,y:702,t:1527030903927};\\\", \\\"{x:1477,y:702,t:1527030903945};\\\", \\\"{x:1480,y:700,t:1527030903961};\\\", \\\"{x:1484,y:698,t:1527030903978};\\\", \\\"{x:1490,y:697,t:1527030903995};\\\", \\\"{x:1500,y:695,t:1527030904012};\\\", \\\"{x:1509,y:695,t:1527030904028};\\\", \\\"{x:1516,y:695,t:1527030904045};\\\", \\\"{x:1523,y:695,t:1527030904062};\\\", \\\"{x:1526,y:695,t:1527030904077};\\\", \\\"{x:1528,y:695,t:1527030904095};\\\", \\\"{x:1529,y:695,t:1527030904112};\\\", \\\"{x:1530,y:695,t:1527030904128};\\\", \\\"{x:1532,y:695,t:1527030904144};\\\", \\\"{x:1534,y:695,t:1527030904161};\\\", \\\"{x:1536,y:695,t:1527030904178};\\\", \\\"{x:1539,y:694,t:1527030904194};\\\", \\\"{x:1535,y:695,t:1527030904300};\\\", \\\"{x:1531,y:696,t:1527030904312};\\\", \\\"{x:1517,y:705,t:1527030904330};\\\", \\\"{x:1500,y:711,t:1527030904344};\\\", \\\"{x:1478,y:720,t:1527030904361};\\\", \\\"{x:1458,y:729,t:1527030904379};\\\", \\\"{x:1438,y:739,t:1527030904394};\\\", \\\"{x:1416,y:750,t:1527030904412};\\\", \\\"{x:1404,y:757,t:1527030904429};\\\", \\\"{x:1397,y:760,t:1527030904446};\\\", \\\"{x:1394,y:763,t:1527030904462};\\\", \\\"{x:1389,y:766,t:1527030904479};\\\", \\\"{x:1386,y:771,t:1527030904495};\\\", \\\"{x:1385,y:771,t:1527030904512};\\\", \\\"{x:1383,y:773,t:1527030904528};\\\", \\\"{x:1383,y:774,t:1527030904611};\\\", \\\"{x:1382,y:774,t:1527030904691};\\\", \\\"{x:1381,y:774,t:1527030904698};\\\", \\\"{x:1380,y:774,t:1527030904712};\\\", \\\"{x:1379,y:774,t:1527030904729};\\\", \\\"{x:1376,y:774,t:1527030904745};\\\", \\\"{x:1375,y:774,t:1527030904762};\\\", \\\"{x:1371,y:774,t:1527030904778};\\\", \\\"{x:1366,y:773,t:1527030904795};\\\", \\\"{x:1362,y:772,t:1527030904812};\\\", \\\"{x:1359,y:771,t:1527030904828};\\\", \\\"{x:1358,y:770,t:1527030904845};\\\", \\\"{x:1356,y:769,t:1527030904863};\\\", \\\"{x:1355,y:769,t:1527030904979};\\\", \\\"{x:1354,y:769,t:1527030904995};\\\", \\\"{x:1353,y:768,t:1527030905013};\\\", \\\"{x:1352,y:768,t:1527030905030};\\\", \\\"{x:1352,y:767,t:1527030905271};\\\", \\\"{x:1352,y:766,t:1527030905307};\\\", \\\"{x:1351,y:766,t:1527030905323};\\\", \\\"{x:1351,y:765,t:1527030905339};\\\", \\\"{x:1350,y:765,t:1527030905363};\\\", \\\"{x:1349,y:764,t:1527030905548};\\\", \\\"{x:1349,y:763,t:1527030905579};\\\", \\\"{x:1349,y:762,t:1527030905988};\\\", \\\"{x:1349,y:761,t:1527030906004};\\\", \\\"{x:1350,y:761,t:1527030906036};\\\", \\\"{x:1351,y:761,t:1527030906284};\\\", \\\"{x:1353,y:761,t:1527030906298};\\\", \\\"{x:1356,y:761,t:1527030906317};\\\", \\\"{x:1364,y:761,t:1527030906331};\\\", \\\"{x:1367,y:761,t:1527030906347};\\\", \\\"{x:1372,y:761,t:1527030906364};\\\", \\\"{x:1376,y:761,t:1527030906381};\\\", \\\"{x:1384,y:761,t:1527030906397};\\\", \\\"{x:1394,y:761,t:1527030906415};\\\", \\\"{x:1404,y:761,t:1527030906432};\\\", \\\"{x:1414,y:761,t:1527030906448};\\\", \\\"{x:1421,y:761,t:1527030906465};\\\", \\\"{x:1424,y:761,t:1527030906482};\\\", \\\"{x:1425,y:761,t:1527030906498};\\\", \\\"{x:1426,y:760,t:1527030906988};\\\", \\\"{x:1428,y:759,t:1527030906999};\\\", \\\"{x:1432,y:759,t:1527030907016};\\\", \\\"{x:1436,y:759,t:1527030907032};\\\", \\\"{x:1440,y:759,t:1527030907048};\\\", \\\"{x:1447,y:759,t:1527030907065};\\\", \\\"{x:1452,y:759,t:1527030907082};\\\", \\\"{x:1458,y:759,t:1527030907098};\\\", \\\"{x:1465,y:759,t:1527030907115};\\\", \\\"{x:1468,y:759,t:1527030907133};\\\", \\\"{x:1472,y:759,t:1527030907149};\\\", \\\"{x:1477,y:759,t:1527030907165};\\\", \\\"{x:1480,y:759,t:1527030907183};\\\", \\\"{x:1484,y:759,t:1527030907200};\\\", \\\"{x:1487,y:759,t:1527030907215};\\\", \\\"{x:1489,y:759,t:1527030907232};\\\", \\\"{x:1490,y:759,t:1527030907250};\\\", \\\"{x:1491,y:759,t:1527030907516};\\\", \\\"{x:1496,y:759,t:1527030907533};\\\", \\\"{x:1505,y:759,t:1527030907550};\\\", \\\"{x:1515,y:759,t:1527030907567};\\\", \\\"{x:1525,y:759,t:1527030907585};\\\", \\\"{x:1532,y:759,t:1527030907600};\\\", \\\"{x:1539,y:759,t:1527030907617};\\\", \\\"{x:1543,y:759,t:1527030907633};\\\", \\\"{x:1546,y:759,t:1527030907649};\\\", \\\"{x:1547,y:759,t:1527030907667};\\\", \\\"{x:1549,y:759,t:1527030907683};\\\", \\\"{x:1550,y:759,t:1527030907699};\\\", \\\"{x:1552,y:759,t:1527030907717};\\\", \\\"{x:1555,y:759,t:1527030907733};\\\", \\\"{x:1556,y:759,t:1527030907750};\\\", \\\"{x:1552,y:759,t:1527030908812};\\\", \\\"{x:1545,y:760,t:1527030908820};\\\", \\\"{x:1534,y:763,t:1527030908835};\\\", \\\"{x:1489,y:763,t:1527030908852};\\\", \\\"{x:1453,y:763,t:1527030908869};\\\", \\\"{x:1411,y:763,t:1527030908885};\\\", \\\"{x:1358,y:763,t:1527030908901};\\\", \\\"{x:1300,y:759,t:1527030908919};\\\", \\\"{x:1216,y:746,t:1527030908935};\\\", \\\"{x:1125,y:732,t:1527030908952};\\\", \\\"{x:1036,y:721,t:1527030908969};\\\", \\\"{x:952,y:708,t:1527030908986};\\\", \\\"{x:888,y:698,t:1527030909002};\\\", \\\"{x:849,y:693,t:1527030909019};\\\", \\\"{x:823,y:687,t:1527030909036};\\\", \\\"{x:819,y:686,t:1527030909051};\\\", \\\"{x:818,y:685,t:1527030909069};\\\", \\\"{x:818,y:681,t:1527030909086};\\\", \\\"{x:818,y:675,t:1527030909102};\\\", \\\"{x:818,y:662,t:1527030909118};\\\", \\\"{x:817,y:638,t:1527030909136};\\\", \\\"{x:815,y:620,t:1527030909153};\\\", \\\"{x:813,y:607,t:1527030909168};\\\", \\\"{x:809,y:599,t:1527030909186};\\\", \\\"{x:804,y:591,t:1527030909205};\\\", \\\"{x:799,y:586,t:1527030909221};\\\", \\\"{x:783,y:581,t:1527030909238};\\\", \\\"{x:760,y:575,t:1527030909255};\\\", \\\"{x:727,y:570,t:1527030909271};\\\", \\\"{x:692,y:565,t:1527030909289};\\\", \\\"{x:664,y:563,t:1527030909305};\\\", \\\"{x:637,y:562,t:1527030909321};\\\", \\\"{x:616,y:562,t:1527030909338};\\\", \\\"{x:601,y:562,t:1527030909355};\\\", \\\"{x:590,y:562,t:1527030909371};\\\", \\\"{x:578,y:559,t:1527030909388};\\\", \\\"{x:566,y:558,t:1527030909405};\\\", \\\"{x:546,y:554,t:1527030909422};\\\", \\\"{x:519,y:549,t:1527030909438};\\\", \\\"{x:494,y:545,t:1527030909456};\\\", \\\"{x:471,y:542,t:1527030909471};\\\", \\\"{x:450,y:540,t:1527030909488};\\\", \\\"{x:436,y:537,t:1527030909505};\\\", \\\"{x:428,y:537,t:1527030909521};\\\", \\\"{x:423,y:537,t:1527030909538};\\\", \\\"{x:421,y:537,t:1527030909555};\\\", \\\"{x:419,y:537,t:1527030909572};\\\", \\\"{x:418,y:538,t:1527030909588};\\\", \\\"{x:417,y:539,t:1527030909606};\\\", \\\"{x:412,y:541,t:1527030909621};\\\", \\\"{x:406,y:543,t:1527030909639};\\\", \\\"{x:393,y:545,t:1527030909656};\\\", \\\"{x:379,y:545,t:1527030909671};\\\", \\\"{x:363,y:545,t:1527030909689};\\\", \\\"{x:341,y:545,t:1527030909705};\\\", \\\"{x:317,y:545,t:1527030909722};\\\", \\\"{x:288,y:545,t:1527030909738};\\\", \\\"{x:241,y:545,t:1527030909757};\\\", \\\"{x:215,y:546,t:1527030909772};\\\", \\\"{x:197,y:548,t:1527030909788};\\\", \\\"{x:187,y:550,t:1527030909806};\\\", \\\"{x:186,y:551,t:1527030909822};\\\", \\\"{x:185,y:551,t:1527030909838};\\\", \\\"{x:184,y:552,t:1527030909859};\\\", \\\"{x:183,y:552,t:1527030909899};\\\", \\\"{x:182,y:551,t:1527030910636};\\\", \\\"{x:180,y:551,t:1527030910652};\\\", \\\"{x:178,y:551,t:1527030910660};\\\", \\\"{x:175,y:551,t:1527030910674};\\\", \\\"{x:170,y:548,t:1527030910692};\\\", \\\"{x:167,y:548,t:1527030910706};\\\", \\\"{x:169,y:544,t:1527030911276};\\\", \\\"{x:178,y:541,t:1527030911290};\\\", \\\"{x:200,y:536,t:1527030911307};\\\", \\\"{x:306,y:534,t:1527030911324};\\\", \\\"{x:428,y:534,t:1527030911340};\\\", \\\"{x:579,y:546,t:1527030911357};\\\", \\\"{x:753,y:573,t:1527030911373};\\\", \\\"{x:936,y:628,t:1527030911391};\\\", \\\"{x:1116,y:682,t:1527030911407};\\\", \\\"{x:1272,y:740,t:1527030911423};\\\", \\\"{x:1374,y:785,t:1527030911440};\\\", \\\"{x:1414,y:809,t:1527030911456};\\\", \\\"{x:1420,y:820,t:1527030911473};\\\", \\\"{x:1420,y:831,t:1527030911491};\\\", \\\"{x:1420,y:858,t:1527030911506};\\\", \\\"{x:1420,y:883,t:1527030911523};\\\", \\\"{x:1421,y:906,t:1527030911540};\\\", \\\"{x:1429,y:936,t:1527030911557};\\\", \\\"{x:1446,y:953,t:1527030911573};\\\", \\\"{x:1468,y:952,t:1527030911591};\\\", \\\"{x:1493,y:936,t:1527030911607};\\\", \\\"{x:1511,y:921,t:1527030911625};\\\", \\\"{x:1520,y:902,t:1527030911641};\\\", \\\"{x:1523,y:885,t:1527030911658};\\\", \\\"{x:1525,y:872,t:1527030911675};\\\", \\\"{x:1525,y:869,t:1527030911691};\\\", \\\"{x:1525,y:868,t:1527030911732};\\\", \\\"{x:1523,y:868,t:1527030911742};\\\", \\\"{x:1515,y:867,t:1527030911758};\\\", \\\"{x:1501,y:866,t:1527030911775};\\\", \\\"{x:1481,y:859,t:1527030911792};\\\", \\\"{x:1460,y:853,t:1527030911809};\\\", \\\"{x:1439,y:845,t:1527030911825};\\\", \\\"{x:1418,y:836,t:1527030911842};\\\", \\\"{x:1397,y:826,t:1527030911859};\\\", \\\"{x:1380,y:814,t:1527030911875};\\\", \\\"{x:1358,y:792,t:1527030911892};\\\", \\\"{x:1351,y:780,t:1527030911909};\\\", \\\"{x:1348,y:771,t:1527030911926};\\\", \\\"{x:1347,y:760,t:1527030911943};\\\", \\\"{x:1347,y:751,t:1527030911959};\\\", \\\"{x:1347,y:745,t:1527030911976};\\\", \\\"{x:1347,y:740,t:1527030911993};\\\", \\\"{x:1347,y:736,t:1527030912009};\\\", \\\"{x:1347,y:733,t:1527030912026};\\\", \\\"{x:1346,y:731,t:1527030912043};\\\", \\\"{x:1346,y:729,t:1527030912058};\\\", \\\"{x:1346,y:726,t:1527030912075};\\\", \\\"{x:1346,y:725,t:1527030912092};\\\", \\\"{x:1346,y:723,t:1527030912109};\\\", \\\"{x:1346,y:722,t:1527030912131};\\\", \\\"{x:1345,y:721,t:1527030912524};\\\", \\\"{x:1342,y:724,t:1527030912540};\\\", \\\"{x:1341,y:726,t:1527030912556};\\\", \\\"{x:1340,y:727,t:1527030912563};\\\", \\\"{x:1339,y:730,t:1527030912577};\\\", \\\"{x:1337,y:733,t:1527030912593};\\\", \\\"{x:1335,y:738,t:1527030912610};\\\", \\\"{x:1325,y:753,t:1527030912627};\\\", \\\"{x:1315,y:763,t:1527030912645};\\\", \\\"{x:1304,y:771,t:1527030912660};\\\", \\\"{x:1297,y:778,t:1527030912678};\\\", \\\"{x:1288,y:783,t:1527030912694};\\\", \\\"{x:1275,y:790,t:1527030912712};\\\", \\\"{x:1267,y:793,t:1527030912728};\\\", \\\"{x:1258,y:797,t:1527030912745};\\\", \\\"{x:1249,y:798,t:1527030912762};\\\", \\\"{x:1241,y:800,t:1527030912777};\\\", \\\"{x:1235,y:801,t:1527030912794};\\\", \\\"{x:1225,y:802,t:1527030912811};\\\", \\\"{x:1220,y:802,t:1527030912829};\\\", \\\"{x:1218,y:802,t:1527030912844};\\\", \\\"{x:1214,y:802,t:1527030912862};\\\", \\\"{x:1213,y:802,t:1527030912879};\\\", \\\"{x:1212,y:802,t:1527030912895};\\\", \\\"{x:1211,y:802,t:1527030912912};\\\", \\\"{x:1211,y:801,t:1527030913292};\\\", \\\"{x:1211,y:800,t:1527030913300};\\\", \\\"{x:1211,y:797,t:1527030913313};\\\", \\\"{x:1212,y:795,t:1527030913330};\\\", \\\"{x:1213,y:794,t:1527030913347};\\\", \\\"{x:1214,y:793,t:1527030913364};\\\", \\\"{x:1215,y:791,t:1527030913379};\\\", \\\"{x:1220,y:788,t:1527030913397};\\\", \\\"{x:1223,y:787,t:1527030913414};\\\", \\\"{x:1224,y:786,t:1527030913431};\\\", \\\"{x:1226,y:785,t:1527030913447};\\\", \\\"{x:1228,y:784,t:1527030913463};\\\", \\\"{x:1234,y:782,t:1527030913481};\\\", \\\"{x:1240,y:782,t:1527030913497};\\\", \\\"{x:1248,y:782,t:1527030913514};\\\", \\\"{x:1257,y:779,t:1527030913531};\\\", \\\"{x:1276,y:775,t:1527030913548};\\\", \\\"{x:1292,y:772,t:1527030913564};\\\", \\\"{x:1308,y:764,t:1527030913581};\\\", \\\"{x:1325,y:758,t:1527030913598};\\\", \\\"{x:1344,y:748,t:1527030913614};\\\", \\\"{x:1361,y:740,t:1527030913631};\\\", \\\"{x:1380,y:730,t:1527030913648};\\\", \\\"{x:1399,y:719,t:1527030913665};\\\", \\\"{x:1414,y:711,t:1527030913681};\\\", \\\"{x:1425,y:703,t:1527030913699};\\\", \\\"{x:1439,y:688,t:1527030913716};\\\", \\\"{x:1448,y:672,t:1527030913732};\\\", \\\"{x:1455,y:656,t:1527030913748};\\\", \\\"{x:1463,y:636,t:1527030913765};\\\", \\\"{x:1466,y:615,t:1527030913782};\\\", \\\"{x:1470,y:594,t:1527030913798};\\\", \\\"{x:1472,y:578,t:1527030913816};\\\", \\\"{x:1475,y:565,t:1527030913833};\\\", \\\"{x:1477,y:551,t:1527030913849};\\\", \\\"{x:1477,y:542,t:1527030913866};\\\", \\\"{x:1478,y:537,t:1527030913882};\\\", \\\"{x:1478,y:535,t:1527030913898};\\\", \\\"{x:1478,y:532,t:1527030913914};\\\", \\\"{x:1475,y:536,t:1527030914172};\\\", \\\"{x:1471,y:541,t:1527030914183};\\\", \\\"{x:1465,y:550,t:1527030914200};\\\", \\\"{x:1457,y:564,t:1527030914216};\\\", \\\"{x:1449,y:582,t:1527030914233};\\\", \\\"{x:1442,y:599,t:1527030914250};\\\", \\\"{x:1433,y:616,t:1527030914267};\\\", \\\"{x:1424,y:639,t:1527030914283};\\\", \\\"{x:1413,y:675,t:1527030914300};\\\", \\\"{x:1403,y:699,t:1527030914317};\\\", \\\"{x:1391,y:723,t:1527030914333};\\\", \\\"{x:1385,y:738,t:1527030914350};\\\", \\\"{x:1380,y:748,t:1527030914367};\\\", \\\"{x:1377,y:753,t:1527030914384};\\\", \\\"{x:1373,y:759,t:1527030914400};\\\", \\\"{x:1368,y:764,t:1527030914417};\\\", \\\"{x:1362,y:766,t:1527030914435};\\\", \\\"{x:1355,y:769,t:1527030914450};\\\", \\\"{x:1350,y:770,t:1527030914467};\\\", \\\"{x:1335,y:773,t:1527030914484};\\\", \\\"{x:1327,y:773,t:1527030914501};\\\", \\\"{x:1314,y:773,t:1527030914517};\\\", \\\"{x:1305,y:773,t:1527030914534};\\\", \\\"{x:1291,y:773,t:1527030914551};\\\", \\\"{x:1280,y:773,t:1527030914568};\\\", \\\"{x:1266,y:773,t:1527030914584};\\\", \\\"{x:1259,y:774,t:1527030914601};\\\", \\\"{x:1250,y:776,t:1527030914618};\\\", \\\"{x:1239,y:778,t:1527030914635};\\\", \\\"{x:1226,y:783,t:1527030914651};\\\", \\\"{x:1217,y:788,t:1527030914668};\\\", \\\"{x:1211,y:791,t:1527030914685};\\\", \\\"{x:1209,y:792,t:1527030914701};\\\", \\\"{x:1208,y:792,t:1527030914780};\\\", \\\"{x:1207,y:792,t:1527030914788};\\\", \\\"{x:1206,y:792,t:1527030914802};\\\", \\\"{x:1205,y:792,t:1527030914844};\\\", \\\"{x:1204,y:792,t:1527030914851};\\\", \\\"{x:1203,y:792,t:1527030914869};\\\", \\\"{x:1202,y:791,t:1527030914885};\\\", \\\"{x:1201,y:790,t:1527030914903};\\\", \\\"{x:1197,y:787,t:1527030914920};\\\", \\\"{x:1192,y:785,t:1527030914935};\\\", \\\"{x:1188,y:783,t:1527030914952};\\\", \\\"{x:1180,y:778,t:1527030914971};\\\", \\\"{x:1174,y:774,t:1527030914986};\\\", \\\"{x:1169,y:772,t:1527030915002};\\\", \\\"{x:1165,y:770,t:1527030915019};\\\", \\\"{x:1164,y:770,t:1527030915037};\\\", \\\"{x:1166,y:770,t:1527030915580};\\\", \\\"{x:1169,y:770,t:1527030915588};\\\", \\\"{x:1169,y:768,t:1527030915604};\\\", \\\"{x:1167,y:766,t:1527030916004};\\\", \\\"{x:1155,y:764,t:1527030916012};\\\", \\\"{x:1140,y:763,t:1527030916023};\\\", \\\"{x:1099,y:756,t:1527030916039};\\\", \\\"{x:1030,y:747,t:1527030916056};\\\", \\\"{x:938,y:734,t:1527030916073};\\\", \\\"{x:818,y:715,t:1527030916089};\\\", \\\"{x:708,y:703,t:1527030916106};\\\", \\\"{x:618,y:698,t:1527030916124};\\\", \\\"{x:597,y:698,t:1527030916140};\\\", \\\"{x:593,y:698,t:1527030916155};\\\", \\\"{x:593,y:699,t:1527030916179};\\\", \\\"{x:593,y:701,t:1527030916190};\\\", \\\"{x:593,y:708,t:1527030916206};\\\", \\\"{x:592,y:713,t:1527030916223};\\\", \\\"{x:590,y:721,t:1527030916240};\\\", \\\"{x:583,y:730,t:1527030916256};\\\", \\\"{x:579,y:735,t:1527030916273};\\\", \\\"{x:574,y:736,t:1527030916290};\\\", \\\"{x:569,y:740,t:1527030916308};\\\", \\\"{x:564,y:743,t:1527030916325};\\\", \\\"{x:559,y:746,t:1527030916340};\\\", \\\"{x:552,y:750,t:1527030916356};\\\", \\\"{x:546,y:754,t:1527030916377};\\\", \\\"{x:541,y:756,t:1527030916394};\\\", \\\"{x:537,y:756,t:1527030916411};\\\", \\\"{x:536,y:756,t:1527030916428};\\\", \\\"{x:535,y:756,t:1527030916612};\\\", \\\"{x:534,y:752,t:1527030916629};\\\", \\\"{x:533,y:748,t:1527030916645};\\\", \\\"{x:530,y:744,t:1527030916660};\\\", \\\"{x:530,y:743,t:1527030916678};\\\", \\\"{x:529,y:741,t:1527030916694};\\\" ] }, { \\\"rt\\\": 101912, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 19, \\\"time_elapsed\\\": 803584, \\\"internal_node_id\\\": \\\"0.0-6.0-9.0\\\", \\\"subject\\\": \\\"Q0QHK\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"juliet\\\", \\\"condition\\\": \\\"115\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"midpoint\\\", \\\"q\\\": 15, \\\"clicks\\\": 2, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XFull-YFull\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 0, \\\"answer\\\": [ \\\"F\\\", \\\"B\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-X -X -X -X -X -C -C -X -X -X -C -C -G -B \\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:529,y:740,t:1527030922564};\\\", \\\"{x:531,y:738,t:1527030922581};\\\", \\\"{x:534,y:736,t:1527030922597};\\\", \\\"{x:535,y:734,t:1527030922614};\\\", \\\"{x:537,y:733,t:1527030922633};\\\", \\\"{x:538,y:733,t:1527030922648};\\\", \\\"{x:540,y:731,t:1527030922663};\\\", \\\"{x:542,y:729,t:1527030922682};\\\", \\\"{x:545,y:727,t:1527030922698};\\\", \\\"{x:547,y:725,t:1527030922716};\\\", \\\"{x:550,y:723,t:1527030922732};\\\", \\\"{x:552,y:722,t:1527030922748};\\\", \\\"{x:558,y:719,t:1527030922766};\\\", \\\"{x:569,y:716,t:1527030922782};\\\", \\\"{x:587,y:714,t:1527030922799};\\\", \\\"{x:610,y:712,t:1527030922816};\\\", \\\"{x:628,y:710,t:1527030922832};\\\", \\\"{x:642,y:707,t:1527030922849};\\\", \\\"{x:644,y:706,t:1527030922866};\\\", \\\"{x:646,y:706,t:1527030923380};\\\", \\\"{x:650,y:707,t:1527030923388};\\\", \\\"{x:656,y:708,t:1527030923401};\\\", \\\"{x:669,y:712,t:1527030923416};\\\", \\\"{x:685,y:715,t:1527030923433};\\\", \\\"{x:701,y:722,t:1527030923450};\\\", \\\"{x:724,y:732,t:1527030923466};\\\", \\\"{x:773,y:754,t:1527030923483};\\\", \\\"{x:815,y:772,t:1527030923499};\\\", \\\"{x:871,y:790,t:1527030923517};\\\", \\\"{x:933,y:811,t:1527030923533};\\\", \\\"{x:1016,y:834,t:1527030923551};\\\", \\\"{x:1110,y:861,t:1527030923567};\\\", \\\"{x:1209,y:881,t:1527030923584};\\\", \\\"{x:1303,y:892,t:1527030923600};\\\", \\\"{x:1386,y:905,t:1527030923617};\\\", \\\"{x:1446,y:917,t:1527030923634};\\\", \\\"{x:1483,y:928,t:1527030923651};\\\", \\\"{x:1507,y:936,t:1527030923666};\\\", \\\"{x:1523,y:943,t:1527030923684};\\\", \\\"{x:1534,y:949,t:1527030923701};\\\", \\\"{x:1541,y:956,t:1527030923717};\\\", \\\"{x:1545,y:958,t:1527030923734};\\\", \\\"{x:1546,y:959,t:1527030923751};\\\", \\\"{x:1550,y:961,t:1527030923767};\\\", \\\"{x:1553,y:962,t:1527030923783};\\\", \\\"{x:1556,y:963,t:1527030923801};\\\", \\\"{x:1558,y:964,t:1527030923818};\\\", \\\"{x:1561,y:965,t:1527030923834};\\\", \\\"{x:1562,y:965,t:1527030923884};\\\", \\\"{x:1561,y:964,t:1527030923996};\\\", \\\"{x:1558,y:963,t:1527030924011};\\\", \\\"{x:1557,y:963,t:1527030924019};\\\", \\\"{x:1556,y:963,t:1527030924033};\\\", \\\"{x:1552,y:961,t:1527030924051};\\\", \\\"{x:1543,y:960,t:1527030924068};\\\", \\\"{x:1535,y:960,t:1527030924084};\\\", \\\"{x:1528,y:960,t:1527030924101};\\\", \\\"{x:1520,y:960,t:1527030924117};\\\", \\\"{x:1514,y:960,t:1527030924133};\\\", \\\"{x:1510,y:960,t:1527030924151};\\\", \\\"{x:1507,y:960,t:1527030924167};\\\", \\\"{x:1507,y:959,t:1527030924184};\\\", \\\"{x:1505,y:959,t:1527030924364};\\\", \\\"{x:1504,y:959,t:1527030924388};\\\", \\\"{x:1503,y:959,t:1527030924403};\\\", \\\"{x:1502,y:959,t:1527030924628};\\\", \\\"{x:1501,y:959,t:1527030924635};\\\", \\\"{x:1499,y:959,t:1527030924651};\\\", \\\"{x:1495,y:959,t:1527030924667};\\\", \\\"{x:1491,y:959,t:1527030924685};\\\", \\\"{x:1487,y:959,t:1527030924701};\\\", \\\"{x:1483,y:959,t:1527030924718};\\\", \\\"{x:1481,y:959,t:1527030924735};\\\", \\\"{x:1477,y:959,t:1527030924751};\\\", \\\"{x:1475,y:957,t:1527030924768};\\\", \\\"{x:1474,y:957,t:1527030924784};\\\", \\\"{x:1472,y:957,t:1527030924803};\\\", \\\"{x:1471,y:957,t:1527030924924};\\\", \\\"{x:1469,y:957,t:1527030924948};\\\", \\\"{x:1468,y:957,t:1527030924964};\\\", \\\"{x:1467,y:957,t:1527030924971};\\\", \\\"{x:1466,y:957,t:1527030925028};\\\", \\\"{x:1466,y:956,t:1527030925108};\\\", \\\"{x:1466,y:955,t:1527030925117};\\\", \\\"{x:1467,y:953,t:1527030925134};\\\", \\\"{x:1469,y:950,t:1527030925151};\\\", \\\"{x:1469,y:948,t:1527030925169};\\\", \\\"{x:1469,y:947,t:1527030925184};\\\", \\\"{x:1469,y:945,t:1527030925202};\\\", \\\"{x:1469,y:944,t:1527030925260};\\\", \\\"{x:1469,y:943,t:1527030925276};\\\", \\\"{x:1469,y:942,t:1527030925285};\\\", \\\"{x:1469,y:941,t:1527030925308};\\\", \\\"{x:1469,y:940,t:1527030925318};\\\", \\\"{x:1469,y:938,t:1527030925335};\\\", \\\"{x:1469,y:937,t:1527030925352};\\\", \\\"{x:1469,y:932,t:1527030925369};\\\", \\\"{x:1469,y:927,t:1527030925385};\\\", \\\"{x:1470,y:919,t:1527030925402};\\\", \\\"{x:1472,y:911,t:1527030925419};\\\", \\\"{x:1473,y:897,t:1527030925435};\\\", \\\"{x:1480,y:881,t:1527030925451};\\\", \\\"{x:1482,y:878,t:1527030925469};\\\", \\\"{x:1482,y:877,t:1527030925485};\\\", \\\"{x:1483,y:874,t:1527030925502};\\\", \\\"{x:1483,y:872,t:1527030925518};\\\", \\\"{x:1483,y:871,t:1527030925535};\\\", \\\"{x:1483,y:869,t:1527030925552};\\\", \\\"{x:1484,y:868,t:1527030925572};\\\", \\\"{x:1484,y:867,t:1527030925585};\\\", \\\"{x:1484,y:866,t:1527030925602};\\\", \\\"{x:1484,y:865,t:1527030925619};\\\", \\\"{x:1485,y:863,t:1527030925636};\\\", \\\"{x:1485,y:862,t:1527030925652};\\\", \\\"{x:1485,y:861,t:1527030925668};\\\", \\\"{x:1485,y:860,t:1527030925685};\\\", \\\"{x:1485,y:859,t:1527030925702};\\\", \\\"{x:1485,y:858,t:1527030925719};\\\", \\\"{x:1485,y:857,t:1527030925735};\\\", \\\"{x:1485,y:856,t:1527030925752};\\\", \\\"{x:1485,y:855,t:1527030925769};\\\", \\\"{x:1485,y:854,t:1527030925786};\\\", \\\"{x:1485,y:853,t:1527030925811};\\\", \\\"{x:1485,y:852,t:1527030925836};\\\", \\\"{x:1485,y:851,t:1527030925852};\\\", \\\"{x:1485,y:850,t:1527030925883};\\\", \\\"{x:1485,y:849,t:1527030925891};\\\", \\\"{x:1485,y:848,t:1527030925907};\\\", \\\"{x:1485,y:847,t:1527030925931};\\\", \\\"{x:1485,y:846,t:1527030925940};\\\", \\\"{x:1484,y:845,t:1527030925955};\\\", \\\"{x:1484,y:844,t:1527030925980};\\\", \\\"{x:1484,y:843,t:1527030925996};\\\", \\\"{x:1484,y:841,t:1527030926003};\\\", \\\"{x:1483,y:840,t:1527030926035};\\\", \\\"{x:1482,y:839,t:1527030926060};\\\", \\\"{x:1482,y:838,t:1527030926084};\\\", \\\"{x:1482,y:837,t:1527030926108};\\\", \\\"{x:1482,y:836,t:1527030926147};\\\", \\\"{x:1482,y:835,t:1527030926158};\\\", \\\"{x:1481,y:834,t:1527030926185};\\\", \\\"{x:1481,y:833,t:1527030926211};\\\", \\\"{x:1481,y:832,t:1527030926347};\\\", \\\"{x:1480,y:831,t:1527030926364};\\\", \\\"{x:1480,y:830,t:1527030926436};\\\", \\\"{x:1480,y:827,t:1527030929428};\\\", \\\"{x:1480,y:824,t:1527030929439};\\\", \\\"{x:1480,y:821,t:1527030929454};\\\", \\\"{x:1480,y:818,t:1527030929471};\\\", \\\"{x:1480,y:815,t:1527030929487};\\\", \\\"{x:1480,y:812,t:1527030929504};\\\", \\\"{x:1480,y:809,t:1527030929521};\\\", \\\"{x:1480,y:805,t:1527030929537};\\\", \\\"{x:1480,y:803,t:1527030929554};\\\", \\\"{x:1480,y:798,t:1527030929571};\\\", \\\"{x:1480,y:795,t:1527030929587};\\\", \\\"{x:1480,y:793,t:1527030929604};\\\", \\\"{x:1480,y:790,t:1527030929622};\\\", \\\"{x:1480,y:787,t:1527030929637};\\\", \\\"{x:1479,y:786,t:1527030929654};\\\", \\\"{x:1479,y:785,t:1527030929672};\\\", \\\"{x:1479,y:784,t:1527030929691};\\\", \\\"{x:1479,y:783,t:1527030929707};\\\", \\\"{x:1479,y:782,t:1527030929722};\\\", \\\"{x:1479,y:781,t:1527030929738};\\\", \\\"{x:1479,y:778,t:1527030929755};\\\", \\\"{x:1479,y:773,t:1527030929771};\\\", \\\"{x:1479,y:771,t:1527030929788};\\\", \\\"{x:1479,y:770,t:1527030929804};\\\", \\\"{x:1479,y:768,t:1527030929821};\\\", \\\"{x:1479,y:767,t:1527030929838};\\\", \\\"{x:1479,y:765,t:1527030929855};\\\", \\\"{x:1479,y:764,t:1527030929872};\\\", \\\"{x:1479,y:763,t:1527030929889};\\\", \\\"{x:1479,y:765,t:1527030933354};\\\", \\\"{x:1478,y:767,t:1527030933362};\\\", \\\"{x:1477,y:769,t:1527030933373};\\\", \\\"{x:1476,y:774,t:1527030933390};\\\", \\\"{x:1476,y:777,t:1527030933407};\\\", \\\"{x:1476,y:779,t:1527030933424};\\\", \\\"{x:1476,y:780,t:1527030933440};\\\", \\\"{x:1476,y:782,t:1527030933457};\\\", \\\"{x:1476,y:783,t:1527030933473};\\\", \\\"{x:1476,y:786,t:1527030933491};\\\", \\\"{x:1476,y:787,t:1527030933507};\\\", \\\"{x:1476,y:790,t:1527030933523};\\\", \\\"{x:1477,y:794,t:1527030933541};\\\", \\\"{x:1478,y:797,t:1527030933558};\\\", \\\"{x:1478,y:800,t:1527030933574};\\\", \\\"{x:1479,y:802,t:1527030933591};\\\", \\\"{x:1479,y:806,t:1527030933607};\\\", \\\"{x:1479,y:810,t:1527030933624};\\\", \\\"{x:1480,y:814,t:1527030933641};\\\", \\\"{x:1480,y:817,t:1527030933658};\\\", \\\"{x:1480,y:821,t:1527030933674};\\\", \\\"{x:1480,y:824,t:1527030933691};\\\", \\\"{x:1480,y:828,t:1527030933708};\\\", \\\"{x:1480,y:830,t:1527030933723};\\\", \\\"{x:1480,y:831,t:1527030933747};\\\", \\\"{x:1480,y:830,t:1527030933924};\\\", \\\"{x:1480,y:818,t:1527030933942};\\\", \\\"{x:1477,y:804,t:1527030933959};\\\", \\\"{x:1476,y:795,t:1527030933975};\\\", \\\"{x:1475,y:788,t:1527030933991};\\\", \\\"{x:1474,y:782,t:1527030934008};\\\", \\\"{x:1473,y:776,t:1527030934025};\\\", \\\"{x:1472,y:771,t:1527030934041};\\\", \\\"{x:1472,y:769,t:1527030934058};\\\", \\\"{x:1471,y:766,t:1527030934075};\\\", \\\"{x:1471,y:765,t:1527030934091};\\\", \\\"{x:1471,y:763,t:1527030934108};\\\", \\\"{x:1471,y:762,t:1527030934126};\\\", \\\"{x:1471,y:761,t:1527030934141};\\\", \\\"{x:1471,y:760,t:1527030934158};\\\", \\\"{x:1470,y:760,t:1527030934484};\\\", \\\"{x:1468,y:760,t:1527030934491};\\\", \\\"{x:1462,y:764,t:1527030934508};\\\", \\\"{x:1459,y:766,t:1527030934525};\\\", \\\"{x:1455,y:768,t:1527030934542};\\\", \\\"{x:1452,y:769,t:1527030934558};\\\", \\\"{x:1450,y:769,t:1527030934575};\\\", \\\"{x:1449,y:770,t:1527030934592};\\\", \\\"{x:1445,y:771,t:1527030934608};\\\", \\\"{x:1442,y:772,t:1527030934625};\\\", \\\"{x:1440,y:772,t:1527030934642};\\\", \\\"{x:1434,y:773,t:1527030934658};\\\", \\\"{x:1422,y:773,t:1527030934675};\\\", \\\"{x:1417,y:773,t:1527030934691};\\\", \\\"{x:1412,y:773,t:1527030934708};\\\", \\\"{x:1407,y:773,t:1527030934725};\\\", \\\"{x:1403,y:773,t:1527030934742};\\\", \\\"{x:1400,y:772,t:1527030934759};\\\", \\\"{x:1399,y:772,t:1527030934775};\\\", \\\"{x:1397,y:771,t:1527030934792};\\\", \\\"{x:1396,y:770,t:1527030934844};\\\", \\\"{x:1395,y:769,t:1527030934860};\\\", \\\"{x:1395,y:768,t:1527030934892};\\\", \\\"{x:1395,y:767,t:1527030934915};\\\", \\\"{x:1395,y:766,t:1527030934940};\\\", \\\"{x:1395,y:765,t:1527030935027};\\\", \\\"{x:1395,y:764,t:1527030935043};\\\", \\\"{x:1397,y:763,t:1527030935060};\\\", \\\"{x:1402,y:761,t:1527030935075};\\\", \\\"{x:1408,y:759,t:1527030935091};\\\", \\\"{x:1416,y:759,t:1527030935109};\\\", \\\"{x:1422,y:758,t:1527030935125};\\\", \\\"{x:1429,y:757,t:1527030935142};\\\", \\\"{x:1434,y:757,t:1527030935159};\\\", \\\"{x:1437,y:757,t:1527030935175};\\\", \\\"{x:1438,y:757,t:1527030935276};\\\", \\\"{x:1440,y:757,t:1527030935292};\\\", \\\"{x:1443,y:757,t:1527030935310};\\\", \\\"{x:1447,y:758,t:1527030935326};\\\", \\\"{x:1451,y:759,t:1527030935343};\\\", \\\"{x:1459,y:759,t:1527030935359};\\\", \\\"{x:1465,y:759,t:1527030935376};\\\", \\\"{x:1470,y:759,t:1527030935392};\\\", \\\"{x:1476,y:759,t:1527030935409};\\\", \\\"{x:1481,y:759,t:1527030935426};\\\", \\\"{x:1483,y:758,t:1527030935442};\\\", \\\"{x:1487,y:758,t:1527030935459};\\\", \\\"{x:1490,y:758,t:1527030935476};\\\", \\\"{x:1491,y:758,t:1527030935493};\\\", \\\"{x:1493,y:758,t:1527030935509};\\\", \\\"{x:1494,y:758,t:1527030935526};\\\", \\\"{x:1494,y:759,t:1527030935542};\\\", \\\"{x:1494,y:760,t:1527030935596};\\\", \\\"{x:1494,y:761,t:1527030935609};\\\", \\\"{x:1494,y:762,t:1527030935626};\\\", \\\"{x:1493,y:765,t:1527030935643};\\\", \\\"{x:1492,y:766,t:1527030935659};\\\", \\\"{x:1491,y:766,t:1527030935684};\\\", \\\"{x:1490,y:766,t:1527030935859};\\\", \\\"{x:1489,y:766,t:1527030935875};\\\", \\\"{x:1488,y:765,t:1527030935893};\\\", \\\"{x:1487,y:762,t:1527030935909};\\\", \\\"{x:1487,y:761,t:1527030935931};\\\", \\\"{x:1486,y:760,t:1527030936036};\\\", \\\"{x:1485,y:760,t:1527030936068};\\\", \\\"{x:1485,y:761,t:1527030936076};\\\", \\\"{x:1483,y:764,t:1527030936093};\\\", \\\"{x:1481,y:767,t:1527030936110};\\\", \\\"{x:1478,y:769,t:1527030936126};\\\", \\\"{x:1476,y:770,t:1527030936143};\\\", \\\"{x:1475,y:770,t:1527030936160};\\\", \\\"{x:1474,y:770,t:1527030936176};\\\", \\\"{x:1473,y:770,t:1527030936193};\\\", \\\"{x:1472,y:770,t:1527030936209};\\\", \\\"{x:1471,y:769,t:1527030936226};\\\", \\\"{x:1471,y:760,t:1527030936252};\\\", \\\"{x:1471,y:755,t:1527030936268};\\\", \\\"{x:1474,y:753,t:1527030936284};\\\", \\\"{x:1475,y:752,t:1527030936302};\\\", \\\"{x:1476,y:752,t:1527030936333};\\\", \\\"{x:1477,y:751,t:1527030936381};\\\", \\\"{x:1478,y:751,t:1527030936389};\\\", \\\"{x:1478,y:753,t:1527030936402};\\\", \\\"{x:1478,y:757,t:1527030936420};\\\", \\\"{x:1478,y:762,t:1527030936435};\\\", \\\"{x:1474,y:769,t:1527030936453};\\\", \\\"{x:1473,y:771,t:1527030936469};\\\", \\\"{x:1471,y:773,t:1527030936485};\\\", \\\"{x:1469,y:773,t:1527030936503};\\\", \\\"{x:1468,y:773,t:1527030936519};\\\", \\\"{x:1467,y:773,t:1527030936541};\\\", \\\"{x:1466,y:771,t:1527030936557};\\\", \\\"{x:1466,y:769,t:1527030936569};\\\", \\\"{x:1466,y:767,t:1527030936585};\\\", \\\"{x:1466,y:764,t:1527030936603};\\\", \\\"{x:1466,y:762,t:1527030936620};\\\", \\\"{x:1469,y:761,t:1527030936636};\\\", \\\"{x:1472,y:760,t:1527030936653};\\\", \\\"{x:1474,y:760,t:1527030936677};\\\", \\\"{x:1475,y:760,t:1527030936686};\\\", \\\"{x:1477,y:763,t:1527030936702};\\\", \\\"{x:1480,y:767,t:1527030936720};\\\", \\\"{x:1482,y:773,t:1527030936737};\\\", \\\"{x:1482,y:775,t:1527030936753};\\\", \\\"{x:1482,y:777,t:1527030936769};\\\", \\\"{x:1482,y:778,t:1527030936786};\\\", \\\"{x:1481,y:779,t:1527030936803};\\\", \\\"{x:1480,y:779,t:1527030936837};\\\", \\\"{x:1479,y:778,t:1527030936861};\\\", \\\"{x:1478,y:775,t:1527030936869};\\\", \\\"{x:1476,y:768,t:1527030936887};\\\", \\\"{x:1476,y:765,t:1527030936902};\\\", \\\"{x:1476,y:763,t:1527030936920};\\\", \\\"{x:1476,y:762,t:1527030936937};\\\", \\\"{x:1476,y:761,t:1527030936956};\\\", \\\"{x:1478,y:761,t:1527030937059};\\\", \\\"{x:1478,y:762,t:1527030937813};\\\", \\\"{x:1478,y:763,t:1527030937884};\\\", \\\"{x:1479,y:764,t:1527030951477};\\\", \\\"{x:1480,y:763,t:1527030951501};\\\", \\\"{x:1481,y:762,t:1527030951515};\\\", \\\"{x:1482,y:761,t:1527030951533};\\\", \\\"{x:1483,y:760,t:1527030956053};\\\", \\\"{x:1484,y:760,t:1527030956066};\\\", \\\"{x:1485,y:759,t:1527030956172};\\\", \\\"{x:1485,y:757,t:1527030956212};\\\", \\\"{x:1485,y:756,t:1527030956244};\\\", \\\"{x:1485,y:754,t:1527030956293};\\\", \\\"{x:1485,y:753,t:1527030956757};\\\", \\\"{x:1485,y:751,t:1527030956788};\\\", \\\"{x:1486,y:751,t:1527030956801};\\\", \\\"{x:1486,y:750,t:1527030956837};\\\", \\\"{x:1486,y:748,t:1527030956869};\\\", \\\"{x:1486,y:747,t:1527030956908};\\\", \\\"{x:1486,y:745,t:1527030956931};\\\", \\\"{x:1487,y:744,t:1527030956947};\\\", \\\"{x:1487,y:742,t:1527030956980};\\\", \\\"{x:1487,y:741,t:1527030957003};\\\", \\\"{x:1487,y:739,t:1527030957020};\\\", \\\"{x:1487,y:738,t:1527030957044};\\\", \\\"{x:1487,y:736,t:1527030957076};\\\", \\\"{x:1487,y:735,t:1527030957108};\\\", \\\"{x:1488,y:734,t:1527030957132};\\\", \\\"{x:1488,y:733,t:1527030957140};\\\", \\\"{x:1488,y:732,t:1527030957173};\\\", \\\"{x:1488,y:730,t:1527030957197};\\\", \\\"{x:1488,y:729,t:1527030957229};\\\", \\\"{x:1488,y:727,t:1527030957244};\\\", \\\"{x:1488,y:726,t:1527030957269};\\\", \\\"{x:1488,y:724,t:1527030957308};\\\", \\\"{x:1488,y:723,t:1527030957356};\\\", \\\"{x:1488,y:722,t:1527030957397};\\\", \\\"{x:1488,y:721,t:1527030957580};\\\", \\\"{x:1488,y:720,t:1527030957604};\\\", \\\"{x:1488,y:718,t:1527030957635};\\\", \\\"{x:1488,y:717,t:1527030957699};\\\", \\\"{x:1488,y:718,t:1527030958300};\\\", \\\"{x:1488,y:722,t:1527030958319};\\\", \\\"{x:1487,y:727,t:1527030958335};\\\", \\\"{x:1486,y:729,t:1527030958352};\\\", \\\"{x:1486,y:731,t:1527030958369};\\\", \\\"{x:1486,y:734,t:1527030958385};\\\", \\\"{x:1486,y:735,t:1527030958402};\\\", \\\"{x:1486,y:736,t:1527030958418};\\\", \\\"{x:1486,y:735,t:1527030958644};\\\", \\\"{x:1486,y:734,t:1527030958652};\\\", \\\"{x:1484,y:730,t:1527030958669};\\\", \\\"{x:1484,y:726,t:1527030958685};\\\", \\\"{x:1483,y:721,t:1527030958702};\\\", \\\"{x:1483,y:717,t:1527030958719};\\\", \\\"{x:1483,y:712,t:1527030958735};\\\", \\\"{x:1482,y:710,t:1527030958752};\\\", \\\"{x:1482,y:706,t:1527030958770};\\\", \\\"{x:1481,y:703,t:1527030958785};\\\", \\\"{x:1481,y:702,t:1527030958802};\\\", \\\"{x:1481,y:700,t:1527030958836};\\\", \\\"{x:1480,y:700,t:1527030958852};\\\", \\\"{x:1478,y:700,t:1527030975285};\\\", \\\"{x:1477,y:700,t:1527030975298};\\\", \\\"{x:1472,y:701,t:1527030975314};\\\", \\\"{x:1467,y:703,t:1527030975331};\\\", \\\"{x:1465,y:704,t:1527030975348};\\\", \\\"{x:1462,y:706,t:1527030975364};\\\", \\\"{x:1461,y:707,t:1527030975388};\\\", \\\"{x:1460,y:707,t:1527030975398};\\\", \\\"{x:1458,y:707,t:1527030975415};\\\", \\\"{x:1456,y:708,t:1527030975431};\\\", \\\"{x:1454,y:709,t:1527030975448};\\\", \\\"{x:1453,y:710,t:1527030975464};\\\", \\\"{x:1449,y:710,t:1527030975480};\\\", \\\"{x:1447,y:710,t:1527030975497};\\\", \\\"{x:1443,y:710,t:1527030975514};\\\", \\\"{x:1439,y:710,t:1527030975530};\\\", \\\"{x:1428,y:710,t:1527030975547};\\\", \\\"{x:1424,y:710,t:1527030975564};\\\", \\\"{x:1421,y:710,t:1527030975580};\\\", \\\"{x:1420,y:710,t:1527030975597};\\\", \\\"{x:1418,y:710,t:1527030975643};\\\", \\\"{x:1417,y:710,t:1527030975675};\\\", \\\"{x:1415,y:710,t:1527030975692};\\\", \\\"{x:1414,y:710,t:1527030975716};\\\", \\\"{x:1413,y:710,t:1527030975731};\\\", \\\"{x:1412,y:710,t:1527030975765};\\\", \\\"{x:1411,y:709,t:1527030975797};\\\", \\\"{x:1410,y:708,t:1527030975820};\\\", \\\"{x:1409,y:708,t:1527030975853};\\\", \\\"{x:1409,y:707,t:1527030976669};\\\", \\\"{x:1409,y:708,t:1527030977420};\\\", \\\"{x:1409,y:711,t:1527030977433};\\\", \\\"{x:1408,y:717,t:1527030977449};\\\", \\\"{x:1407,y:727,t:1527030977466};\\\", \\\"{x:1405,y:734,t:1527030977483};\\\", \\\"{x:1405,y:738,t:1527030977499};\\\", \\\"{x:1405,y:741,t:1527030977516};\\\", \\\"{x:1405,y:745,t:1527030977533};\\\", \\\"{x:1404,y:746,t:1527030977549};\\\", \\\"{x:1404,y:748,t:1527030977566};\\\", \\\"{x:1403,y:751,t:1527030977583};\\\", \\\"{x:1403,y:752,t:1527030977599};\\\", \\\"{x:1403,y:754,t:1527030977616};\\\", \\\"{x:1401,y:757,t:1527030977633};\\\", \\\"{x:1401,y:758,t:1527030977649};\\\", \\\"{x:1400,y:760,t:1527030977684};\\\", \\\"{x:1398,y:761,t:1527030977724};\\\", \\\"{x:1398,y:762,t:1527030977756};\\\", \\\"{x:1398,y:763,t:1527030977805};\\\", \\\"{x:1398,y:765,t:1527030977947};\\\", \\\"{x:1398,y:766,t:1527030978116};\\\", \\\"{x:1400,y:766,t:1527030978156};\\\", \\\"{x:1401,y:767,t:1527030978172};\\\", \\\"{x:1402,y:767,t:1527030978212};\\\", \\\"{x:1403,y:767,t:1527030978277};\\\", \\\"{x:1405,y:767,t:1527030978380};\\\", \\\"{x:1406,y:767,t:1527030978396};\\\", \\\"{x:1407,y:767,t:1527030978412};\\\", \\\"{x:1408,y:766,t:1527030978693};\\\", \\\"{x:1409,y:765,t:1527030978700};\\\", \\\"{x:1411,y:764,t:1527030978717};\\\", \\\"{x:1414,y:763,t:1527030978734};\\\", \\\"{x:1418,y:763,t:1527030978750};\\\", \\\"{x:1425,y:761,t:1527030978768};\\\", \\\"{x:1430,y:760,t:1527030978784};\\\", \\\"{x:1435,y:760,t:1527030978800};\\\", \\\"{x:1439,y:760,t:1527030978817};\\\", \\\"{x:1443,y:759,t:1527030978834};\\\", \\\"{x:1445,y:758,t:1527030978851};\\\", \\\"{x:1447,y:757,t:1527030978868};\\\", \\\"{x:1448,y:757,t:1527030978884};\\\", \\\"{x:1449,y:757,t:1527030978900};\\\", \\\"{x:1450,y:756,t:1527030978924};\\\", \\\"{x:1452,y:756,t:1527030978940};\\\", \\\"{x:1453,y:756,t:1527030978956};\\\", \\\"{x:1454,y:756,t:1527030978989};\\\", \\\"{x:1453,y:756,t:1527030979155};\\\", \\\"{x:1452,y:756,t:1527030979167};\\\", \\\"{x:1451,y:757,t:1527030979196};\\\", \\\"{x:1450,y:757,t:1527030979941};\\\", \\\"{x:1451,y:754,t:1527030979951};\\\", \\\"{x:1454,y:749,t:1527030979968};\\\", \\\"{x:1455,y:742,t:1527030979984};\\\", \\\"{x:1456,y:738,t:1527030980001};\\\", \\\"{x:1456,y:730,t:1527030980018};\\\", \\\"{x:1456,y:721,t:1527030980034};\\\", \\\"{x:1456,y:714,t:1527030980051};\\\", \\\"{x:1456,y:704,t:1527030980068};\\\", \\\"{x:1456,y:701,t:1527030980084};\\\", \\\"{x:1456,y:698,t:1527030980101};\\\", \\\"{x:1456,y:695,t:1527030980118};\\\", \\\"{x:1456,y:691,t:1527030980135};\\\", \\\"{x:1454,y:688,t:1527030980151};\\\", \\\"{x:1454,y:686,t:1527030980168};\\\", \\\"{x:1454,y:683,t:1527030980185};\\\", \\\"{x:1454,y:681,t:1527030980202};\\\", \\\"{x:1454,y:685,t:1527030980340};\\\", \\\"{x:1456,y:690,t:1527030980351};\\\", \\\"{x:1458,y:694,t:1527030980368};\\\", \\\"{x:1459,y:698,t:1527030980385};\\\", \\\"{x:1459,y:700,t:1527030980401};\\\", \\\"{x:1460,y:703,t:1527030980418};\\\", \\\"{x:1460,y:701,t:1527030980725};\\\", \\\"{x:1460,y:700,t:1527030980747};\\\", \\\"{x:1460,y:698,t:1527030985900};\\\", \\\"{x:1461,y:696,t:1527030985908};\\\", \\\"{x:1461,y:693,t:1527030985923};\\\", \\\"{x:1462,y:687,t:1527030985939};\\\", \\\"{x:1463,y:682,t:1527030985956};\\\", \\\"{x:1463,y:674,t:1527030985972};\\\", \\\"{x:1463,y:669,t:1527030985990};\\\", \\\"{x:1463,y:665,t:1527030986006};\\\", \\\"{x:1463,y:661,t:1527030986023};\\\", \\\"{x:1463,y:657,t:1527030986040};\\\", \\\"{x:1463,y:653,t:1527030986055};\\\", \\\"{x:1463,y:648,t:1527030986072};\\\", \\\"{x:1463,y:644,t:1527030986089};\\\", \\\"{x:1463,y:642,t:1527030986105};\\\", \\\"{x:1463,y:640,t:1527030986123};\\\", \\\"{x:1463,y:638,t:1527030986140};\\\", \\\"{x:1463,y:636,t:1527030986155};\\\", \\\"{x:1461,y:633,t:1527030986172};\\\", \\\"{x:1461,y:632,t:1527030986204};\\\", \\\"{x:1460,y:632,t:1527030986222};\\\", \\\"{x:1460,y:631,t:1527030986239};\\\", \\\"{x:1459,y:630,t:1527030986256};\\\", \\\"{x:1458,y:630,t:1527030986272};\\\", \\\"{x:1457,y:629,t:1527030986289};\\\", \\\"{x:1456,y:629,t:1527030986306};\\\", \\\"{x:1453,y:629,t:1527030986322};\\\", \\\"{x:1452,y:629,t:1527030986339};\\\", \\\"{x:1450,y:629,t:1527030986356};\\\", \\\"{x:1449,y:629,t:1527030986388};\\\", \\\"{x:1448,y:629,t:1527030986428};\\\", \\\"{x:1447,y:629,t:1527030986444};\\\", \\\"{x:1446,y:629,t:1527030986492};\\\", \\\"{x:1446,y:628,t:1527030986668};\\\", \\\"{x:1446,y:627,t:1527030986675};\\\", \\\"{x:1446,y:626,t:1527030986688};\\\", \\\"{x:1446,y:623,t:1527030986706};\\\", \\\"{x:1446,y:620,t:1527030986721};\\\", \\\"{x:1446,y:615,t:1527030986739};\\\", \\\"{x:1446,y:608,t:1527030986756};\\\", \\\"{x:1446,y:596,t:1527030986773};\\\", \\\"{x:1446,y:575,t:1527030986789};\\\", \\\"{x:1446,y:560,t:1527030986806};\\\", \\\"{x:1446,y:548,t:1527030986822};\\\", \\\"{x:1444,y:536,t:1527030986839};\\\", \\\"{x:1443,y:532,t:1527030986856};\\\", \\\"{x:1443,y:530,t:1527030986873};\\\", \\\"{x:1444,y:531,t:1527030987004};\\\", \\\"{x:1447,y:537,t:1527030987012};\\\", \\\"{x:1450,y:547,t:1527030987023};\\\", \\\"{x:1461,y:574,t:1527030987040};\\\", \\\"{x:1467,y:598,t:1527030987056};\\\", \\\"{x:1473,y:616,t:1527030987074};\\\", \\\"{x:1476,y:630,t:1527030987089};\\\", \\\"{x:1477,y:638,t:1527030987106};\\\", \\\"{x:1477,y:641,t:1527030987123};\\\", \\\"{x:1477,y:642,t:1527030987332};\\\", \\\"{x:1477,y:644,t:1527030987348};\\\", \\\"{x:1477,y:645,t:1527030987356};\\\", \\\"{x:1477,y:648,t:1527030987373};\\\", \\\"{x:1477,y:651,t:1527030987390};\\\", \\\"{x:1476,y:654,t:1527030987406};\\\", \\\"{x:1476,y:656,t:1527030987424};\\\", \\\"{x:1476,y:661,t:1527030987440};\\\", \\\"{x:1476,y:666,t:1527030987457};\\\", \\\"{x:1476,y:675,t:1527030987473};\\\", \\\"{x:1476,y:683,t:1527030987491};\\\", \\\"{x:1476,y:692,t:1527030987506};\\\", \\\"{x:1476,y:706,t:1527030987524};\\\", \\\"{x:1476,y:718,t:1527030987540};\\\", \\\"{x:1476,y:726,t:1527030987556};\\\", \\\"{x:1476,y:736,t:1527030987574};\\\", \\\"{x:1476,y:747,t:1527030987590};\\\", \\\"{x:1476,y:760,t:1527030987606};\\\", \\\"{x:1476,y:770,t:1527030987624};\\\", \\\"{x:1476,y:785,t:1527030987640};\\\", \\\"{x:1476,y:804,t:1527030987656};\\\", \\\"{x:1476,y:820,t:1527030987673};\\\", \\\"{x:1476,y:834,t:1527030987691};\\\", \\\"{x:1476,y:841,t:1527030987706};\\\", \\\"{x:1476,y:850,t:1527030987724};\\\", \\\"{x:1476,y:857,t:1527030987740};\\\", \\\"{x:1476,y:867,t:1527030987758};\\\", \\\"{x:1476,y:874,t:1527030987773};\\\", \\\"{x:1476,y:875,t:1527030987791};\\\", \\\"{x:1475,y:878,t:1527030987808};\\\", \\\"{x:1475,y:882,t:1527030987823};\\\", \\\"{x:1475,y:890,t:1527030987840};\\\", \\\"{x:1475,y:897,t:1527030987857};\\\", \\\"{x:1475,y:910,t:1527030987873};\\\", \\\"{x:1475,y:916,t:1527030987890};\\\", \\\"{x:1475,y:924,t:1527030987907};\\\", \\\"{x:1475,y:927,t:1527030987923};\\\", \\\"{x:1475,y:930,t:1527030987940};\\\", \\\"{x:1475,y:936,t:1527030987957};\\\", \\\"{x:1475,y:938,t:1527030987973};\\\", \\\"{x:1475,y:939,t:1527030987995};\\\", \\\"{x:1475,y:940,t:1527030988011};\\\", \\\"{x:1475,y:941,t:1527030988027};\\\", \\\"{x:1475,y:938,t:1527030988139};\\\", \\\"{x:1475,y:934,t:1527030988147};\\\", \\\"{x:1475,y:930,t:1527030988157};\\\", \\\"{x:1475,y:921,t:1527030988172};\\\", \\\"{x:1475,y:915,t:1527030988190};\\\", \\\"{x:1476,y:907,t:1527030988207};\\\", \\\"{x:1476,y:900,t:1527030988223};\\\", \\\"{x:1476,y:890,t:1527030988239};\\\", \\\"{x:1476,y:879,t:1527030988257};\\\", \\\"{x:1476,y:867,t:1527030988274};\\\", \\\"{x:1476,y:858,t:1527030988291};\\\", \\\"{x:1476,y:847,t:1527030988307};\\\", \\\"{x:1476,y:842,t:1527030988323};\\\", \\\"{x:1476,y:835,t:1527030988340};\\\", \\\"{x:1476,y:830,t:1527030988357};\\\", \\\"{x:1476,y:826,t:1527030988374};\\\", \\\"{x:1476,y:823,t:1527030988390};\\\", \\\"{x:1476,y:819,t:1527030988407};\\\", \\\"{x:1476,y:817,t:1527030988424};\\\", \\\"{x:1476,y:815,t:1527030988440};\\\", \\\"{x:1476,y:811,t:1527030988457};\\\", \\\"{x:1476,y:806,t:1527030988474};\\\", \\\"{x:1476,y:799,t:1527030988490};\\\", \\\"{x:1476,y:785,t:1527030988508};\\\", \\\"{x:1476,y:779,t:1527030988524};\\\", \\\"{x:1476,y:775,t:1527030988540};\\\", \\\"{x:1476,y:771,t:1527030988557};\\\", \\\"{x:1476,y:766,t:1527030988575};\\\", \\\"{x:1476,y:758,t:1527030988590};\\\", \\\"{x:1476,y:751,t:1527030988607};\\\", \\\"{x:1476,y:741,t:1527030988624};\\\", \\\"{x:1476,y:730,t:1527030988640};\\\", \\\"{x:1476,y:722,t:1527030988657};\\\", \\\"{x:1477,y:715,t:1527030988674};\\\", \\\"{x:1478,y:707,t:1527030988690};\\\", \\\"{x:1481,y:690,t:1527030988708};\\\", \\\"{x:1481,y:680,t:1527030988724};\\\", \\\"{x:1482,y:671,t:1527030988741};\\\", \\\"{x:1482,y:659,t:1527030988758};\\\", \\\"{x:1482,y:647,t:1527030988774};\\\", \\\"{x:1482,y:639,t:1527030988791};\\\", \\\"{x:1481,y:629,t:1527030988807};\\\", \\\"{x:1480,y:618,t:1527030988824};\\\", \\\"{x:1478,y:606,t:1527030988841};\\\", \\\"{x:1475,y:591,t:1527030988857};\\\", \\\"{x:1474,y:582,t:1527030988875};\\\", \\\"{x:1473,y:570,t:1527030988892};\\\", \\\"{x:1473,y:565,t:1527030988908};\\\", \\\"{x:1473,y:553,t:1527030988924};\\\", \\\"{x:1473,y:543,t:1527030988941};\\\", \\\"{x:1473,y:533,t:1527030988958};\\\", \\\"{x:1473,y:519,t:1527030988975};\\\", \\\"{x:1473,y:504,t:1527030988992};\\\", \\\"{x:1471,y:487,t:1527030989008};\\\", \\\"{x:1469,y:472,t:1527030989024};\\\", \\\"{x:1467,y:458,t:1527030989041};\\\", \\\"{x:1465,y:450,t:1527030989058};\\\", \\\"{x:1464,y:444,t:1527030989075};\\\", \\\"{x:1464,y:435,t:1527030989092};\\\", \\\"{x:1462,y:432,t:1527030989108};\\\", \\\"{x:1461,y:429,t:1527030989124};\\\", \\\"{x:1461,y:428,t:1527030989141};\\\", \\\"{x:1461,y:427,t:1527030989157};\\\", \\\"{x:1461,y:426,t:1527030989174};\\\", \\\"{x:1461,y:425,t:1527030989192};\\\", \\\"{x:1461,y:424,t:1527030989208};\\\", \\\"{x:1461,y:423,t:1527030989229};\\\", \\\"{x:1461,y:422,t:1527030989244};\\\", \\\"{x:1461,y:421,t:1527030989268};\\\", \\\"{x:1461,y:422,t:1527030989684};\\\", \\\"{x:1462,y:426,t:1527030989691};\\\", \\\"{x:1464,y:436,t:1527030989708};\\\", \\\"{x:1467,y:445,t:1527030989726};\\\", \\\"{x:1467,y:450,t:1527030989742};\\\", \\\"{x:1467,y:452,t:1527030989758};\\\", \\\"{x:1467,y:455,t:1527030989775};\\\", \\\"{x:1467,y:457,t:1527030989804};\\\", \\\"{x:1467,y:458,t:1527030989828};\\\", \\\"{x:1467,y:460,t:1527030989844};\\\", \\\"{x:1467,y:461,t:1527030989859};\\\", \\\"{x:1467,y:467,t:1527030989875};\\\", \\\"{x:1467,y:471,t:1527030989891};\\\", \\\"{x:1467,y:476,t:1527030989908};\\\", \\\"{x:1467,y:484,t:1527030989924};\\\", \\\"{x:1467,y:492,t:1527030989941};\\\", \\\"{x:1467,y:499,t:1527030989958};\\\", \\\"{x:1467,y:507,t:1527030989974};\\\", \\\"{x:1467,y:515,t:1527030989991};\\\", \\\"{x:1467,y:526,t:1527030990008};\\\", \\\"{x:1467,y:536,t:1527030990025};\\\", \\\"{x:1467,y:547,t:1527030990041};\\\", \\\"{x:1467,y:553,t:1527030990058};\\\", \\\"{x:1467,y:565,t:1527030990075};\\\", \\\"{x:1467,y:572,t:1527030990091};\\\", \\\"{x:1467,y:577,t:1527030990108};\\\", \\\"{x:1467,y:582,t:1527030990125};\\\", \\\"{x:1467,y:588,t:1527030990142};\\\", \\\"{x:1467,y:592,t:1527030990158};\\\", \\\"{x:1467,y:598,t:1527030990176};\\\", \\\"{x:1467,y:604,t:1527030990192};\\\", \\\"{x:1467,y:613,t:1527030990209};\\\", \\\"{x:1467,y:623,t:1527030990225};\\\", \\\"{x:1467,y:632,t:1527030990242};\\\", \\\"{x:1467,y:643,t:1527030990258};\\\", \\\"{x:1467,y:660,t:1527030990275};\\\", \\\"{x:1467,y:670,t:1527030990291};\\\", \\\"{x:1467,y:678,t:1527030990308};\\\", \\\"{x:1467,y:684,t:1527030990325};\\\", \\\"{x:1467,y:690,t:1527030990343};\\\", \\\"{x:1467,y:697,t:1527030990358};\\\", \\\"{x:1468,y:706,t:1527030990375};\\\", \\\"{x:1468,y:713,t:1527030990392};\\\", \\\"{x:1468,y:719,t:1527030990408};\\\", \\\"{x:1470,y:725,t:1527030990426};\\\", \\\"{x:1470,y:729,t:1527030990442};\\\", \\\"{x:1470,y:733,t:1527030990458};\\\", \\\"{x:1471,y:737,t:1527030990475};\\\", \\\"{x:1471,y:743,t:1527030990491};\\\", \\\"{x:1471,y:746,t:1527030990508};\\\", \\\"{x:1471,y:751,t:1527030990525};\\\", \\\"{x:1471,y:753,t:1527030990542};\\\", \\\"{x:1471,y:754,t:1527030990559};\\\", \\\"{x:1471,y:755,t:1527030990575};\\\", \\\"{x:1471,y:757,t:1527030990593};\\\", \\\"{x:1471,y:758,t:1527030990608};\\\", \\\"{x:1471,y:760,t:1527030990625};\\\", \\\"{x:1472,y:763,t:1527030990643};\\\", \\\"{x:1472,y:766,t:1527030990659};\\\", \\\"{x:1472,y:769,t:1527030990676};\\\", \\\"{x:1472,y:770,t:1527030990692};\\\", \\\"{x:1472,y:772,t:1527030990710};\\\", \\\"{x:1473,y:777,t:1527030990726};\\\", \\\"{x:1473,y:778,t:1527030990742};\\\", \\\"{x:1474,y:780,t:1527030990759};\\\", \\\"{x:1474,y:782,t:1527030990776};\\\", \\\"{x:1474,y:783,t:1527030990792};\\\", \\\"{x:1474,y:786,t:1527030990810};\\\", \\\"{x:1475,y:787,t:1527030990828};\\\", \\\"{x:1475,y:788,t:1527030990844};\\\", \\\"{x:1475,y:789,t:1527030990860};\\\", \\\"{x:1475,y:790,t:1527030990892};\\\", \\\"{x:1475,y:791,t:1527030990910};\\\", \\\"{x:1476,y:791,t:1527030991028};\\\", \\\"{x:1477,y:789,t:1527030991042};\\\", \\\"{x:1477,y:781,t:1527030991059};\\\", \\\"{x:1477,y:776,t:1527030991076};\\\", \\\"{x:1477,y:771,t:1527030991092};\\\", \\\"{x:1477,y:769,t:1527030991110};\\\", \\\"{x:1477,y:766,t:1527030991126};\\\", \\\"{x:1477,y:761,t:1527030991143};\\\", \\\"{x:1477,y:755,t:1527030991160};\\\", \\\"{x:1476,y:747,t:1527030991176};\\\", \\\"{x:1475,y:737,t:1527030991193};\\\", \\\"{x:1474,y:728,t:1527030991209};\\\", \\\"{x:1472,y:722,t:1527030991226};\\\", \\\"{x:1472,y:718,t:1527030991242};\\\", \\\"{x:1471,y:711,t:1527030991259};\\\", \\\"{x:1471,y:706,t:1527030991276};\\\", \\\"{x:1470,y:700,t:1527030991292};\\\", \\\"{x:1469,y:694,t:1527030991309};\\\", \\\"{x:1469,y:691,t:1527030991327};\\\", \\\"{x:1469,y:689,t:1527030991342};\\\", \\\"{x:1468,y:684,t:1527030991360};\\\", \\\"{x:1467,y:680,t:1527030991377};\\\", \\\"{x:1466,y:675,t:1527030991393};\\\", \\\"{x:1466,y:669,t:1527030991409};\\\", \\\"{x:1465,y:665,t:1527030991427};\\\", \\\"{x:1464,y:661,t:1527030991443};\\\", \\\"{x:1463,y:659,t:1527030991460};\\\", \\\"{x:1463,y:656,t:1527030991477};\\\", \\\"{x:1463,y:653,t:1527030991492};\\\", \\\"{x:1461,y:651,t:1527030991509};\\\", \\\"{x:1459,y:647,t:1527030991527};\\\", \\\"{x:1458,y:644,t:1527030991542};\\\", \\\"{x:1457,y:641,t:1527030991559};\\\", \\\"{x:1456,y:638,t:1527030991576};\\\", \\\"{x:1454,y:635,t:1527030991594};\\\", \\\"{x:1454,y:633,t:1527030991610};\\\", \\\"{x:1452,y:631,t:1527030991627};\\\", \\\"{x:1451,y:629,t:1527030991644};\\\", \\\"{x:1451,y:627,t:1527030992548};\\\", \\\"{x:1450,y:624,t:1527030992561};\\\", \\\"{x:1449,y:620,t:1527030992577};\\\", \\\"{x:1447,y:615,t:1527030992593};\\\", \\\"{x:1445,y:612,t:1527030992611};\\\", \\\"{x:1440,y:605,t:1527030992628};\\\", \\\"{x:1435,y:600,t:1527030992644};\\\", \\\"{x:1430,y:597,t:1527030992661};\\\", \\\"{x:1425,y:593,t:1527030992678};\\\", \\\"{x:1423,y:592,t:1527030992694};\\\", \\\"{x:1420,y:589,t:1527030992711};\\\", \\\"{x:1417,y:586,t:1527030992727};\\\", \\\"{x:1414,y:582,t:1527030992744};\\\", \\\"{x:1412,y:579,t:1527030992760};\\\", \\\"{x:1410,y:577,t:1527030992778};\\\", \\\"{x:1410,y:576,t:1527030992794};\\\", \\\"{x:1410,y:574,t:1527030992810};\\\", \\\"{x:1408,y:572,t:1527030992828};\\\", \\\"{x:1408,y:570,t:1527030992843};\\\", \\\"{x:1408,y:569,t:1527030992861};\\\", \\\"{x:1408,y:567,t:1527030992877};\\\", \\\"{x:1408,y:566,t:1527030992893};\\\", \\\"{x:1408,y:564,t:1527030992923};\\\", \\\"{x:1408,y:563,t:1527030992979};\\\", \\\"{x:1406,y:563,t:1527030993925};\\\", \\\"{x:1401,y:563,t:1527030993932};\\\", \\\"{x:1393,y:563,t:1527030993945};\\\", \\\"{x:1370,y:563,t:1527030993962};\\\", \\\"{x:1343,y:563,t:1527030993978};\\\", \\\"{x:1321,y:563,t:1527030993995};\\\", \\\"{x:1304,y:563,t:1527030994012};\\\", \\\"{x:1302,y:563,t:1527030994028};\\\", \\\"{x:1301,y:563,t:1527030994092};\\\", \\\"{x:1300,y:563,t:1527030994107};\\\", \\\"{x:1299,y:564,t:1527030994132};\\\", \\\"{x:1298,y:565,t:1527030994244};\\\", \\\"{x:1297,y:565,t:1527030994262};\\\", \\\"{x:1295,y:565,t:1527030994279};\\\", \\\"{x:1294,y:566,t:1527030994294};\\\", \\\"{x:1293,y:566,t:1527030994312};\\\", \\\"{x:1292,y:566,t:1527030994340};\\\", \\\"{x:1291,y:566,t:1527030994355};\\\", \\\"{x:1290,y:567,t:1527030994364};\\\", \\\"{x:1289,y:568,t:1527030994380};\\\", \\\"{x:1288,y:568,t:1527030994395};\\\", \\\"{x:1289,y:568,t:1527030995300};\\\", \\\"{x:1290,y:568,t:1527030995313};\\\", \\\"{x:1293,y:568,t:1527030995329};\\\", \\\"{x:1297,y:566,t:1527030995345};\\\", \\\"{x:1301,y:566,t:1527030995363};\\\", \\\"{x:1307,y:566,t:1527030995379};\\\", \\\"{x:1315,y:566,t:1527030995395};\\\", \\\"{x:1319,y:566,t:1527030995413};\\\", \\\"{x:1324,y:566,t:1527030995430};\\\", \\\"{x:1330,y:566,t:1527030995446};\\\", \\\"{x:1333,y:566,t:1527030995465};\\\", \\\"{x:1337,y:565,t:1527030995479};\\\", \\\"{x:1339,y:565,t:1527030995496};\\\", \\\"{x:1342,y:564,t:1527030995513};\\\", \\\"{x:1344,y:564,t:1527030995530};\\\", \\\"{x:1345,y:564,t:1527030995545};\\\", \\\"{x:1346,y:564,t:1527030995563};\\\", \\\"{x:1348,y:563,t:1527030995580};\\\", \\\"{x:1351,y:563,t:1527030995596};\\\", \\\"{x:1351,y:562,t:1527030995613};\\\", \\\"{x:1353,y:562,t:1527030995630};\\\", \\\"{x:1354,y:562,t:1527030995764};\\\", \\\"{x:1362,y:562,t:1527030995780};\\\", \\\"{x:1371,y:562,t:1527030995796};\\\", \\\"{x:1386,y:562,t:1527030995813};\\\", \\\"{x:1400,y:562,t:1527030995830};\\\", \\\"{x:1415,y:562,t:1527030995846};\\\", \\\"{x:1429,y:562,t:1527030995863};\\\", \\\"{x:1435,y:562,t:1527030995880};\\\", \\\"{x:1436,y:562,t:1527030995896};\\\", \\\"{x:1435,y:562,t:1527030996267};\\\", \\\"{x:1434,y:563,t:1527030996340};\\\", \\\"{x:1433,y:563,t:1527030996371};\\\", \\\"{x:1431,y:564,t:1527030996388};\\\", \\\"{x:1430,y:564,t:1527030996404};\\\", \\\"{x:1429,y:565,t:1527030996421};\\\", \\\"{x:1428,y:566,t:1527030996437};\\\", \\\"{x:1426,y:567,t:1527030996454};\\\", \\\"{x:1423,y:568,t:1527030996471};\\\", \\\"{x:1422,y:569,t:1527030998412};\\\", \\\"{x:1422,y:573,t:1527030998422};\\\", \\\"{x:1422,y:589,t:1527030998439};\\\", \\\"{x:1422,y:610,t:1527030998455};\\\", \\\"{x:1422,y:632,t:1527030998472};\\\", \\\"{x:1424,y:658,t:1527030998490};\\\", \\\"{x:1429,y:686,t:1527030998505};\\\", \\\"{x:1433,y:709,t:1527030998523};\\\", \\\"{x:1439,y:730,t:1527030998538};\\\", \\\"{x:1449,y:760,t:1527030998555};\\\", \\\"{x:1452,y:782,t:1527030998572};\\\", \\\"{x:1455,y:803,t:1527030998590};\\\", \\\"{x:1456,y:814,t:1527030998605};\\\", \\\"{x:1457,y:821,t:1527030998622};\\\", \\\"{x:1459,y:824,t:1527030998639};\\\", \\\"{x:1460,y:827,t:1527030998655};\\\", \\\"{x:1460,y:828,t:1527030998672};\\\", \\\"{x:1461,y:829,t:1527030998689};\\\", \\\"{x:1462,y:831,t:1527030998705};\\\", \\\"{x:1463,y:836,t:1527030998722};\\\", \\\"{x:1464,y:845,t:1527030998739};\\\", \\\"{x:1464,y:850,t:1527030998756};\\\", \\\"{x:1466,y:855,t:1527030998772};\\\", \\\"{x:1466,y:857,t:1527030998789};\\\", \\\"{x:1467,y:857,t:1527030998954};\\\", \\\"{x:1467,y:856,t:1527030999002};\\\", \\\"{x:1467,y:855,t:1527030999018};\\\", \\\"{x:1467,y:854,t:1527030999067};\\\", \\\"{x:1467,y:853,t:1527030999074};\\\", \\\"{x:1467,y:852,t:1527030999089};\\\", \\\"{x:1467,y:851,t:1527030999106};\\\", \\\"{x:1467,y:850,t:1527030999122};\\\", \\\"{x:1468,y:848,t:1527030999139};\\\", \\\"{x:1468,y:846,t:1527030999156};\\\", \\\"{x:1469,y:845,t:1527030999172};\\\", \\\"{x:1469,y:843,t:1527030999211};\\\", \\\"{x:1469,y:842,t:1527030999235};\\\", \\\"{x:1469,y:840,t:1527030999259};\\\", \\\"{x:1469,y:839,t:1527030999308};\\\", \\\"{x:1469,y:838,t:1527030999331};\\\", \\\"{x:1469,y:837,t:1527030999411};\\\", \\\"{x:1469,y:836,t:1527030999467};\\\", \\\"{x:1468,y:834,t:1527030999482};\\\", \\\"{x:1465,y:834,t:1527030999490};\\\", \\\"{x:1456,y:833,t:1527030999506};\\\", \\\"{x:1399,y:826,t:1527030999521};\\\", \\\"{x:1316,y:814,t:1527030999539};\\\", \\\"{x:1193,y:796,t:1527030999556};\\\", \\\"{x:1053,y:763,t:1527030999573};\\\", \\\"{x:918,y:744,t:1527030999589};\\\", \\\"{x:821,y:731,t:1527030999605};\\\", \\\"{x:778,y:725,t:1527030999622};\\\", \\\"{x:760,y:721,t:1527030999639};\\\", \\\"{x:757,y:720,t:1527030999656};\\\", \\\"{x:757,y:719,t:1527030999672};\\\", \\\"{x:759,y:719,t:1527030999690};\\\", \\\"{x:761,y:719,t:1527030999706};\\\", \\\"{x:761,y:718,t:1527030999755};\\\", \\\"{x:761,y:717,t:1527030999773};\\\", \\\"{x:758,y:713,t:1527030999790};\\\", \\\"{x:752,y:709,t:1527030999805};\\\", \\\"{x:737,y:701,t:1527030999823};\\\", \\\"{x:716,y:692,t:1527030999840};\\\", \\\"{x:691,y:681,t:1527030999856};\\\", \\\"{x:649,y:666,t:1527030999873};\\\", \\\"{x:599,y:652,t:1527030999890};\\\", \\\"{x:544,y:637,t:1527030999908};\\\", \\\"{x:459,y:626,t:1527030999923};\\\", \\\"{x:415,y:623,t:1527030999939};\\\", \\\"{x:383,y:623,t:1527030999959};\\\", \\\"{x:359,y:624,t:1527030999975};\\\", \\\"{x:339,y:629,t:1527030999992};\\\", \\\"{x:338,y:629,t:1527031000427};\\\", \\\"{x:336,y:629,t:1527031000467};\\\", \\\"{x:335,y:629,t:1527031000477};\\\", \\\"{x:333,y:629,t:1527031000494};\\\", \\\"{x:330,y:629,t:1527031000509};\\\", \\\"{x:326,y:630,t:1527031000527};\\\", \\\"{x:320,y:632,t:1527031000543};\\\", \\\"{x:310,y:637,t:1527031000560};\\\", \\\"{x:301,y:642,t:1527031000577};\\\", \\\"{x:289,y:648,t:1527031000595};\\\", \\\"{x:281,y:652,t:1527031000610};\\\", \\\"{x:270,y:655,t:1527031000629};\\\", \\\"{x:265,y:655,t:1527031000645};\\\", \\\"{x:260,y:655,t:1527031000662};\\\", \\\"{x:256,y:655,t:1527031000678};\\\", \\\"{x:253,y:656,t:1527031000695};\\\", \\\"{x:250,y:656,t:1527031000711};\\\", \\\"{x:247,y:658,t:1527031000729};\\\", \\\"{x:245,y:660,t:1527031000745};\\\", \\\"{x:240,y:663,t:1527031000761};\\\", \\\"{x:230,y:668,t:1527031000778};\\\", \\\"{x:219,y:672,t:1527031000796};\\\", \\\"{x:208,y:674,t:1527031000811};\\\", \\\"{x:199,y:677,t:1527031000829};\\\", \\\"{x:193,y:681,t:1527031000846};\\\", \\\"{x:191,y:681,t:1527031000862};\\\", \\\"{x:190,y:682,t:1527031000878};\\\", \\\"{x:194,y:682,t:1527031000923};\\\", \\\"{x:202,y:682,t:1527031000931};\\\", \\\"{x:217,y:682,t:1527031000946};\\\", \\\"{x:258,y:682,t:1527031000962};\\\", \\\"{x:403,y:682,t:1527031000981};\\\", \\\"{x:524,y:682,t:1527031000996};\\\", \\\"{x:640,y:671,t:1527031001013};\\\", \\\"{x:719,y:654,t:1527031001029};\\\", \\\"{x:759,y:641,t:1527031001045};\\\", \\\"{x:770,y:639,t:1527031001062};\\\", \\\"{x:770,y:638,t:1527031001078};\\\", \\\"{x:768,y:637,t:1527031001098};\\\", \\\"{x:761,y:636,t:1527031001112};\\\", \\\"{x:748,y:634,t:1527031001128};\\\", \\\"{x:736,y:633,t:1527031001146};\\\", \\\"{x:718,y:633,t:1527031001163};\\\", \\\"{x:708,y:633,t:1527031001179};\\\", \\\"{x:698,y:633,t:1527031001195};\\\", \\\"{x:689,y:634,t:1527031001213};\\\", \\\"{x:680,y:635,t:1527031001229};\\\", \\\"{x:670,y:639,t:1527031001245};\\\", \\\"{x:664,y:639,t:1527031001262};\\\", \\\"{x:655,y:643,t:1527031001278};\\\", \\\"{x:649,y:643,t:1527031001295};\\\", \\\"{x:644,y:645,t:1527031001313};\\\", \\\"{x:641,y:646,t:1527031001329};\\\", \\\"{x:639,y:646,t:1527031001345};\\\", \\\"{x:637,y:646,t:1527031001386};\\\", \\\"{x:637,y:645,t:1527031001436};\\\", \\\"{x:637,y:644,t:1527031001446};\\\", \\\"{x:637,y:643,t:1527031001462};\\\", \\\"{x:638,y:639,t:1527031001480};\\\", \\\"{x:640,y:635,t:1527031001495};\\\", \\\"{x:645,y:627,t:1527031001513};\\\", \\\"{x:652,y:614,t:1527031001530};\\\", \\\"{x:665,y:596,t:1527031001546};\\\", \\\"{x:693,y:576,t:1527031001563};\\\", \\\"{x:718,y:564,t:1527031001580};\\\", \\\"{x:745,y:556,t:1527031001596};\\\", \\\"{x:773,y:548,t:1527031001612};\\\", \\\"{x:797,y:539,t:1527031001630};\\\", \\\"{x:819,y:530,t:1527031001646};\\\", \\\"{x:832,y:521,t:1527031001663};\\\", \\\"{x:839,y:516,t:1527031001679};\\\", \\\"{x:841,y:514,t:1527031001695};\\\", \\\"{x:842,y:513,t:1527031001713};\\\", \\\"{x:841,y:513,t:1527031001836};\\\", \\\"{x:843,y:519,t:1527031013067};\\\", \\\"{x:852,y:528,t:1527031013076};\\\", \\\"{x:864,y:540,t:1527031013088};\\\", \\\"{x:886,y:560,t:1527031013104};\\\", \\\"{x:907,y:573,t:1527031013120};\\\", \\\"{x:927,y:587,t:1527031013137};\\\", \\\"{x:942,y:597,t:1527031013151};\\\", \\\"{x:961,y:610,t:1527031013172};\\\", \\\"{x:973,y:615,t:1527031013188};\\\", \\\"{x:983,y:621,t:1527031013205};\\\", \\\"{x:999,y:627,t:1527031013222};\\\", \\\"{x:1015,y:636,t:1527031013239};\\\", \\\"{x:1037,y:644,t:1527031013255};\\\", \\\"{x:1059,y:654,t:1527031013272};\\\", \\\"{x:1083,y:664,t:1527031013289};\\\", \\\"{x:1110,y:676,t:1527031013305};\\\", \\\"{x:1158,y:700,t:1527031013321};\\\", \\\"{x:1182,y:715,t:1527031013339};\\\", \\\"{x:1228,y:738,t:1527031013355};\\\", \\\"{x:1289,y:766,t:1527031013373};\\\", \\\"{x:1351,y:802,t:1527031013389};\\\", \\\"{x:1396,y:831,t:1527031013405};\\\", \\\"{x:1436,y:853,t:1527031013422};\\\", \\\"{x:1461,y:867,t:1527031013439};\\\", \\\"{x:1482,y:878,t:1527031013456};\\\", \\\"{x:1498,y:883,t:1527031013472};\\\", \\\"{x:1507,y:885,t:1527031013490};\\\", \\\"{x:1508,y:885,t:1527031013506};\\\", \\\"{x:1508,y:882,t:1527031013522};\\\", \\\"{x:1504,y:876,t:1527031013540};\\\", \\\"{x:1497,y:867,t:1527031013556};\\\", \\\"{x:1488,y:860,t:1527031013572};\\\", \\\"{x:1478,y:853,t:1527031013589};\\\", \\\"{x:1471,y:844,t:1527031013607};\\\", \\\"{x:1461,y:833,t:1527031013623};\\\", \\\"{x:1452,y:825,t:1527031013639};\\\", \\\"{x:1440,y:815,t:1527031013657};\\\", \\\"{x:1429,y:815,t:1527031013673};\\\", \\\"{x:1417,y:810,t:1527031013690};\\\", \\\"{x:1403,y:804,t:1527031013707};\\\", \\\"{x:1390,y:800,t:1527031013723};\\\", \\\"{x:1379,y:795,t:1527031013739};\\\", \\\"{x:1366,y:791,t:1527031013757};\\\", \\\"{x:1354,y:787,t:1527031013773};\\\", \\\"{x:1344,y:784,t:1527031013790};\\\", \\\"{x:1337,y:780,t:1527031013807};\\\", \\\"{x:1335,y:779,t:1527031013823};\\\", \\\"{x:1334,y:778,t:1527031013839};\\\", \\\"{x:1333,y:777,t:1527031013856};\\\", \\\"{x:1333,y:776,t:1527031013874};\\\", \\\"{x:1333,y:775,t:1527031013891};\\\", \\\"{x:1333,y:774,t:1527031013914};\\\", \\\"{x:1333,y:773,t:1527031013931};\\\", \\\"{x:1333,y:771,t:1527031013971};\\\", \\\"{x:1334,y:771,t:1527031014067};\\\", \\\"{x:1335,y:770,t:1527031014075};\\\", \\\"{x:1337,y:770,t:1527031014114};\\\", \\\"{x:1337,y:769,t:1527031014691};\\\", \\\"{x:1338,y:768,t:1527031014708};\\\", \\\"{x:1339,y:768,t:1527031014754};\\\", \\\"{x:1340,y:767,t:1527031014779};\\\", \\\"{x:1341,y:766,t:1527031014924};\\\", \\\"{x:1342,y:766,t:1527031015243};\\\", \\\"{x:1343,y:765,t:1527031015259};\\\", \\\"{x:1344,y:765,t:1527031015491};\\\", \\\"{x:1345,y:764,t:1527031015811};\\\", \\\"{x:1346,y:764,t:1527031015825};\\\", \\\"{x:1347,y:763,t:1527031015842};\\\", \\\"{x:1348,y:762,t:1527031015858};\\\", \\\"{x:1349,y:762,t:1527031015876};\\\", \\\"{x:1351,y:762,t:1527031015892};\\\", \\\"{x:1352,y:762,t:1527031015915};\\\", \\\"{x:1354,y:762,t:1527031015980};\\\", \\\"{x:1354,y:761,t:1527031016131};\\\", \\\"{x:1356,y:760,t:1527031016203};\\\", \\\"{x:1357,y:760,t:1527031016227};\\\", \\\"{x:1359,y:760,t:1527031016242};\\\", \\\"{x:1362,y:760,t:1527031016259};\\\", \\\"{x:1367,y:760,t:1527031016276};\\\", \\\"{x:1374,y:760,t:1527031016293};\\\", \\\"{x:1381,y:760,t:1527031016309};\\\", \\\"{x:1389,y:760,t:1527031016326};\\\", \\\"{x:1398,y:760,t:1527031016343};\\\", \\\"{x:1406,y:760,t:1527031016359};\\\", \\\"{x:1411,y:760,t:1527031016376};\\\", \\\"{x:1417,y:760,t:1527031016393};\\\", \\\"{x:1418,y:760,t:1527031016409};\\\", \\\"{x:1419,y:760,t:1527031016425};\\\", \\\"{x:1417,y:760,t:1527031017891};\\\", \\\"{x:1414,y:761,t:1527031017907};\\\", \\\"{x:1412,y:762,t:1527031017914};\\\", \\\"{x:1408,y:762,t:1527031017928};\\\", \\\"{x:1391,y:763,t:1527031017944};\\\", \\\"{x:1367,y:763,t:1527031017961};\\\", \\\"{x:1331,y:763,t:1527031017978};\\\", \\\"{x:1244,y:751,t:1527031017994};\\\", \\\"{x:1094,y:723,t:1527031018011};\\\", \\\"{x:986,y:707,t:1527031018028};\\\", \\\"{x:889,y:694,t:1527031018044};\\\", \\\"{x:827,y:684,t:1527031018060};\\\", \\\"{x:786,y:674,t:1527031018077};\\\", \\\"{x:770,y:669,t:1527031018093};\\\", \\\"{x:764,y:665,t:1527031018111};\\\", \\\"{x:762,y:663,t:1527031018130};\\\", \\\"{x:761,y:663,t:1527031018185};\\\", \\\"{x:760,y:662,t:1527031018193};\\\", \\\"{x:757,y:660,t:1527031018210};\\\", \\\"{x:752,y:659,t:1527031018227};\\\", \\\"{x:748,y:656,t:1527031018244};\\\", \\\"{x:747,y:656,t:1527031018261};\\\", \\\"{x:746,y:654,t:1527031018277};\\\", \\\"{x:742,y:648,t:1527031018295};\\\", \\\"{x:737,y:641,t:1527031018311};\\\", \\\"{x:725,y:630,t:1527031018328};\\\", \\\"{x:702,y:616,t:1527031018344};\\\", \\\"{x:671,y:602,t:1527031018358};\\\", \\\"{x:632,y:591,t:1527031018375};\\\", \\\"{x:586,y:575,t:1527031018394};\\\", \\\"{x:552,y:569,t:1527031018409};\\\", \\\"{x:512,y:564,t:1527031018426};\\\", \\\"{x:490,y:561,t:1527031018444};\\\", \\\"{x:470,y:558,t:1527031018459};\\\", \\\"{x:455,y:558,t:1527031018476};\\\", \\\"{x:444,y:558,t:1527031018492};\\\", \\\"{x:432,y:558,t:1527031018509};\\\", \\\"{x:418,y:558,t:1527031018527};\\\", \\\"{x:404,y:558,t:1527031018542};\\\", \\\"{x:393,y:558,t:1527031018560};\\\", \\\"{x:382,y:558,t:1527031018577};\\\", \\\"{x:369,y:558,t:1527031018593};\\\", \\\"{x:350,y:559,t:1527031018610};\\\", \\\"{x:329,y:559,t:1527031018627};\\\", \\\"{x:301,y:559,t:1527031018643};\\\", \\\"{x:271,y:559,t:1527031018661};\\\", \\\"{x:246,y:561,t:1527031018676};\\\", \\\"{x:225,y:565,t:1527031018693};\\\", \\\"{x:209,y:567,t:1527031018709};\\\", \\\"{x:195,y:570,t:1527031018727};\\\", \\\"{x:181,y:571,t:1527031018743};\\\", \\\"{x:171,y:572,t:1527031018759};\\\", \\\"{x:162,y:573,t:1527031018776};\\\", \\\"{x:158,y:574,t:1527031018793};\\\", \\\"{x:157,y:574,t:1527031018834};\\\", \\\"{x:156,y:573,t:1527031018891};\\\", \\\"{x:155,y:573,t:1527031018906};\\\", \\\"{x:154,y:571,t:1527031018923};\\\", \\\"{x:152,y:571,t:1527031018938};\\\", \\\"{x:150,y:570,t:1527031018963};\\\", \\\"{x:149,y:570,t:1527031018976};\\\", \\\"{x:148,y:570,t:1527031018994};\\\", \\\"{x:146,y:570,t:1527031019011};\\\", \\\"{x:145,y:569,t:1527031019028};\\\", \\\"{x:145,y:568,t:1527031019043};\\\", \\\"{x:145,y:567,t:1527031019060};\\\", \\\"{x:147,y:564,t:1527031019078};\\\", \\\"{x:152,y:560,t:1527031019093};\\\", \\\"{x:156,y:559,t:1527031019110};\\\", \\\"{x:158,y:557,t:1527031019126};\\\", \\\"{x:161,y:555,t:1527031019143};\\\", \\\"{x:162,y:554,t:1527031019377};\\\", \\\"{x:164,y:553,t:1527031019393};\\\", \\\"{x:183,y:553,t:1527031019411};\\\", \\\"{x:207,y:562,t:1527031019427};\\\", \\\"{x:248,y:583,t:1527031019444};\\\", \\\"{x:309,y:614,t:1527031019460};\\\", \\\"{x:388,y:658,t:1527031019478};\\\", \\\"{x:460,y:703,t:1527031019494};\\\", \\\"{x:523,y:731,t:1527031019510};\\\", \\\"{x:563,y:751,t:1527031019528};\\\", \\\"{x:581,y:757,t:1527031019544};\\\", \\\"{x:583,y:759,t:1527031019560};\\\", \\\"{x:584,y:759,t:1527031019577};\\\", \\\"{x:584,y:760,t:1527031019698};\\\", \\\"{x:582,y:760,t:1527031019711};\\\", \\\"{x:576,y:757,t:1527031019728};\\\", \\\"{x:566,y:755,t:1527031019745};\\\", \\\"{x:552,y:751,t:1527031019762};\\\", \\\"{x:540,y:749,t:1527031019778};\\\", \\\"{x:527,y:747,t:1527031019793};\\\", \\\"{x:527,y:746,t:1527031019811};\\\", \\\"{x:523,y:746,t:1527031019963};\\\", \\\"{x:522,y:747,t:1527031020619};\\\", \\\"{x:522,y:748,t:1527031020642};\\\", \\\"{x:522,y:749,t:1527031020674};\\\", \\\"{x:522,y:750,t:1527031020706};\\\", \\\"{x:522,y:751,t:1527031020883};\\\", \\\"{x:522,y:752,t:1527031020922};\\\", \\\"{x:523,y:753,t:1527031021015};\\\" ] }, { \\\"rt\\\": 33814, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 20, \\\"time_elapsed\\\": 838941, \\\"internal_node_id\\\": \\\"0.0-7.0-0.0\\\", \\\"subject\\\": \\\"Q0QHK\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"juliet\\\", \\\"condition\\\": \\\"115\\\", \\\"q\\\": 16, \\\"answer\\\": \\\"look at the x axes, which points is on the 12 pm label position \\\", \\\"block\\\": \\\"triangular_testing\\\" }, { \\\"rt\\\": 8923, \\\"responses\\\": \\\"{\\\\\\\"Q0\\\\\\\":\\\\\\\"21\\\\\\\",\\\\\\\"Q1\\\\\\\":\\\\\\\"china\\\\\\\"}\\\", \\\"block\\\": \\\"demo-1\\\", \\\"trial_type\\\": \\\"survey-text\\\", \\\"trial_index\\\": 21, \\\"time_elapsed\\\": 848872, \\\"internal_node_id\\\": \\\"0.0-8.0\\\", \\\"subject\\\": \\\"Q0QHK\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"juliet\\\", \\\"condition\\\": \\\"115\\\" }, { \\\"rt\\\": 12533, \\\"responses\\\": \\\"{\\\\\\\"Q0\\\\\\\":\\\\\\\"Mandarin or Cantonese\\\\\\\",\\\\\\\"Q1\\\\\\\":\\\\\\\"Third\\\\\\\",\\\\\\\"Q2\\\\\\\":\\\\\\\"Social Sciences (incl. CogSci)\\\\\\\",\\\\\\\"Q3\\\\\\\":\\\\\\\"Female\\\\\\\"}\\\", \\\"block\\\": \\\"demo-2\\\", \\\"trial_type\\\": \\\"survey-multi-choice\\\", \\\"trial_index\\\": 22, \\\"time_elapsed\\\": 862427, \\\"internal_node_id\\\": \\\"0.0-9.0\\\", \\\"subject\\\": \\\"Q0QHK\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"juliet\\\", \\\"condition\\\": \\\"115\\\" }, { \\\"rt\\\": 33615, \\\"url\\\": \\\"../views/src/external/debrief.html\\\", \\\"block\\\": \\\"debrief\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 23, \\\"time_elapsed\\\": 897127, \\\"internal_node_id\\\": \\\"0.0-10.0\\\", \\\"subject\\\": \\\"Q0QHK\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"juliet\\\", \\\"condition\\\": \\\"115\\\" } ]\",\"parentNode\":{\"id\":2765}}],[],[]]}"
    }
  ],
  "initialDom": "{\"f\":\"initialize\",\"args\":[1,[{\"nodeType\":10,\"id\":2,\"name\":\"html\",\"publicId\":\"\",\"systemId\":\"\"},{\"nodeType\":1,\"id\":3,\"tagName\":\"HTML\",\"attributes\":{\"class\":\"fa-events-icons-ready\"},\"childNodes\":[{\"nodeType\":1,\"id\":4,\"tagName\":\"HEAD\",\"attributes\":{},\"childNodes\":[{\"nodeType\":3,\"id\":5,\"textContent\":\" \"},{\"nodeType\":1,\"id\":6,\"tagName\":\"TITLE\",\"attributes\":{},\"childNodes\":[{\"nodeType\":3,\"id\":7,\"textContent\":\"FOX2YP\"}]},{\"nodeType\":3,\"id\":8,\"textContent\":\" \"},{\"nodeType\":8,\"id\":9},{\"nodeType\":3,\"id\":10,\"textContent\":\" \"},{\"nodeType\":1,\"id\":11,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":12,\"textContent\":\" \"},{\"nodeType\":1,\"id\":13,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":14,\"textContent\":\" \"},{\"nodeType\":1,\"id\":15,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":16,\"textContent\":\" \"},{\"nodeType\":1,\"id\":17,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":18,\"textContent\":\" \"},{\"nodeType\":1,\"id\":19,\"tagName\":\"SCRIPT\"},{\"nodeType\":1,\"id\":20,\"tagName\":\"LINK\",\"attributes\":{\"href\":\"https://use.fontawesome.com/945539d961.css\",\"media\":\"all\",\"rel\":\"stylesheet\"}},{\"nodeType\":3,\"id\":21,\"textContent\":\" \"},{\"nodeType\":8,\"id\":22},{\"nodeType\":3,\"id\":23,\"textContent\":\" \"},{\"nodeType\":1,\"id\":24,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":25,\"textContent\":\" \"},{\"nodeType\":1,\"id\":26,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":27,\"textContent\":\" \"},{\"nodeType\":1,\"id\":28,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":29,\"textContent\":\" \"},{\"nodeType\":1,\"id\":30,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":31,\"textContent\":\" \"},{\"nodeType\":1,\"id\":32,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":33,\"textContent\":\" \"},{\"nodeType\":1,\"id\":34,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":35,\"textContent\":\" \"},{\"nodeType\":1,\"id\":36,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":37,\"textContent\":\" \"},{\"nodeType\":8,\"id\":38},{\"nodeType\":3,\"id\":39,\"textContent\":\" \"},{\"nodeType\":1,\"id\":40,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":41,\"textContent\":\" \"},{\"nodeType\":8,\"id\":42},{\"nodeType\":3,\"id\":43,\"textContent\":\" \"},{\"nodeType\":8,\"id\":44},{\"nodeType\":3,\"id\":45,\"textContent\":\" \"},{\"nodeType\":1,\"id\":46,\"tagName\":\"LINK\",\"attributes\":{\"href\":\"../views/jsPsych/css/jspsych.css\",\"rel\":\"stylesheet\",\"type\":\"text/css\"}},{\"nodeType\":3,\"id\":47,\"textContent\":\" \"},{\"nodeType\":1,\"id\":48,\"tagName\":\"LINK\",\"attributes\":{\"href\":\"../css/styles.css\",\"rel\":\"stylesheet\",\"type\":\"text/css\"}},{\"nodeType\":3,\"id\":49,\"textContent\":\" \"},{\"nodeType\":1,\"id\":50,\"tagName\":\"SCRIPT\"},{\"nodeType\":1,\"id\":51,\"tagName\":\"SCRIPT\"}]},{\"nodeType\":3,\"id\":52,\"textContent\":\" \"},{\"nodeType\":8,\"id\":53},{\"nodeType\":3,\"id\":54,\"textContent\":\" \"},{\"nodeType\":1,\"id\":55,\"tagName\":\"BODY\",\"attributes\":{\"class\":\"jspsych-display-element\"},\"childNodes\":[{\"nodeType\":3,\"id\":56,\"textContent\":\" \"},{\"nodeType\":1,\"id\":57,\"tagName\":\"META\",\"attributes\":{\"charset\":\"utf-8\"}},{\"nodeType\":3,\"id\":58,\"textContent\":\" \"},{\"nodeType\":8,\"id\":59},{\"nodeType\":3,\"id\":60,\"textContent\":\" \"},{\"nodeType\":1,\"id\":61,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":62,\"textContent\":\" \"},{\"nodeType\":1,\"id\":63,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":64,\"textContent\":\" \"},{\"nodeType\":1,\"id\":65,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":66,\"textContent\":\" \"},{\"nodeType\":1,\"id\":67,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":68,\"textContent\":\" \"},{\"nodeType\":1,\"id\":69,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":70,\"textContent\":\" \"},{\"nodeType\":1,\"id\":71,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":72,\"textContent\":\" \"},{\"nodeType\":1,\"id\":73,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"stimulus\"},\"childNodes\":[{\"nodeType\":3,\"id\":74,\"textContent\":\" \"},{\"nodeType\":1,\"id\":75,\"tagName\":\"P\",\"attributes\":{\"class\":\"userid\",\"id\":\"userid\"},\"childNodes\":[{\"nodeType\":3,\"id\":76,\"textContent\":\"Q0QHK\"}]},{\"nodeType\":3,\"id\":77,\"textContent\":\" \"},{\"nodeType\":1,\"id\":78,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"userinput\"},\"childNodes\":[{\"nodeType\":3,\"id\":79,\"textContent\":\" \"},{\"nodeType\":8,\"id\":80},{\"nodeType\":3,\"id\":81,\"textContent\":\" \"},{\"nodeType\":1,\"id\":82,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"legend\",\"id\":\"hint-interactive\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":83,\"textContent\":\" \"},{\"nodeType\":1,\"id\":84,\"tagName\":\"P\",\"attributes\":{},\"childNodes\":[{\"nodeType\":3,\"id\":85,\"textContent\":\"Hint: Hover your mouse over the data points in the graph\"}]},{\"nodeType\":3,\"id\":86,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":87,\"textContent\":\" \"},{\"nodeType\":8,\"id\":88},{\"nodeType\":3,\"id\":89,\"textContent\":\" \"},{\"nodeType\":8,\"id\":90},{\"nodeType\":3,\"id\":91,\"textContent\":\" \"},{\"nodeType\":1,\"id\":92,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"test\"},\"childNodes\":[{\"nodeType\":3,\"id\":93,\"textContent\":\" \"},{\"nodeType\":1,\"id\":94,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"acme\",\"id\":\"acme.starttime\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":95,\"textContent\":\" \"},{\"nodeType\":1,\"id\":96,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":97,\"textContent\":\"Which shift(s) start at 11 am? \"}]},{\"nodeType\":3,\"id\":98,\"textContent\":\" \"},{\"nodeType\":1,\"id\":99,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":100,\"textContent\":\" \"},{\"nodeType\":1,\"id\":101,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":102,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":103,\"textContent\":\" \"},{\"nodeType\":1,\"id\":104,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":105,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":106,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":107,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":108,\"textContent\":\" \"},{\"nodeType\":1,\"id\":109,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":110,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":111,\"textContent\":\" \"},{\"nodeType\":1,\"id\":112,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":113,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":114,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":115,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":116,\"textContent\":\" \"},{\"nodeType\":1,\"id\":117,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":118,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":119,\"textContent\":\" \"},{\"nodeType\":1,\"id\":120,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":121,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":122,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":123,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":124,\"textContent\":\" \"},{\"nodeType\":1,\"id\":125,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":126,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":127,\"textContent\":\" \"},{\"nodeType\":1,\"id\":128,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":129,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":130,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":131,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":132,\"textContent\":\" \"},{\"nodeType\":1,\"id\":133,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":134,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":135,\"textContent\":\" \"},{\"nodeType\":1,\"id\":136,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":137,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":138,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":139,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":140,\"textContent\":\" \"},{\"nodeType\":1,\"id\":141,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":142,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":143,\"textContent\":\" \"},{\"nodeType\":1,\"id\":144,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":145,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":146,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":147,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":148,\"textContent\":\" \"},{\"nodeType\":1,\"id\":149,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":150,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":151,\"textContent\":\" \"},{\"nodeType\":1,\"id\":152,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":153,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":154,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":155,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":156,\"textContent\":\" \"},{\"nodeType\":1,\"id\":157,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":158,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":159,\"textContent\":\" \"},{\"nodeType\":1,\"id\":160,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":161,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":162,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":163,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":164,\"textContent\":\" \"},{\"nodeType\":1,\"id\":165,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":166,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":167,\"textContent\":\" \"},{\"nodeType\":1,\"id\":168,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":169,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":170,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":171,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":172,\"textContent\":\" \"},{\"nodeType\":1,\"id\":173,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":174,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":175,\"textContent\":\" \"},{\"nodeType\":1,\"id\":176,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":177,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":178,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":179,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":180,\"textContent\":\" \"},{\"nodeType\":1,\"id\":181,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":182,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":183,\"textContent\":\" \"},{\"nodeType\":1,\"id\":184,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"U\",\"value\":\"\"}},{\"nodeType\":3,\"id\":185,\"textContent\":\"U \"},{\"nodeType\":1,\"id\":186,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":187,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":188,\"textContent\":\" \"},{\"nodeType\":1,\"id\":189,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":190,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":191,\"textContent\":\" \"},{\"nodeType\":1,\"id\":192,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":193,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":194,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":195,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":196,\"textContent\":\" \"},{\"nodeType\":1,\"id\":197,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":198,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":199,\"textContent\":\" \"},{\"nodeType\":1,\"id\":200,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":201,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":202,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":203,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":204,\"textContent\":\" \"},{\"nodeType\":1,\"id\":205,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":206,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":207,\"textContent\":\" \"},{\"nodeType\":1,\"id\":208,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":209,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":210,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":211,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":212,\"textContent\":\" \"},{\"nodeType\":1,\"id\":213,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":214,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":215,\"textContent\":\" \"},{\"nodeType\":1,\"id\":216,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":217,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":218,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":219,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":220,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":221,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":222,\"textContent\":\" \"},{\"nodeType\":1,\"id\":223,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"acme\",\"id\":\"acme.starts\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":224,\"textContent\":\" \"},{\"nodeType\":1,\"id\":225,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":226,\"textContent\":\"Which shift(s) start at the same time as D?\"}]},{\"nodeType\":3,\"id\":227,\"textContent\":\" \"},{\"nodeType\":1,\"id\":228,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":229,\"textContent\":\" \"},{\"nodeType\":1,\"id\":230,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":231,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":232,\"textContent\":\" \"},{\"nodeType\":1,\"id\":233,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":234,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":235,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":236,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":237,\"textContent\":\" \"},{\"nodeType\":1,\"id\":238,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":239,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":240,\"textContent\":\" \"},{\"nodeType\":1,\"id\":241,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":242,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":243,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":244,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":245,\"textContent\":\" \"},{\"nodeType\":1,\"id\":246,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":247,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":248,\"textContent\":\" \"},{\"nodeType\":1,\"id\":249,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":250,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":251,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":252,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":253,\"textContent\":\" \"},{\"nodeType\":1,\"id\":254,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":255,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":256,\"textContent\":\" \"},{\"nodeType\":1,\"id\":257,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":258,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":259,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":260,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":261,\"textContent\":\" \"},{\"nodeType\":1,\"id\":262,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":263,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":264,\"textContent\":\" \"},{\"nodeType\":1,\"id\":265,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":266,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":267,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":268,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":269,\"textContent\":\" \"},{\"nodeType\":1,\"id\":270,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":271,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":272,\"textContent\":\" \"},{\"nodeType\":1,\"id\":273,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":274,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":275,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":276,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":277,\"textContent\":\" \"},{\"nodeType\":1,\"id\":278,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":279,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":280,\"textContent\":\" \"},{\"nodeType\":1,\"id\":281,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":282,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":283,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":284,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":285,\"textContent\":\" \"},{\"nodeType\":1,\"id\":286,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":287,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":288,\"textContent\":\" \"},{\"nodeType\":1,\"id\":289,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":290,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":291,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":292,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":293,\"textContent\":\" \"},{\"nodeType\":1,\"id\":294,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":295,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":296,\"textContent\":\" \"},{\"nodeType\":1,\"id\":297,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":298,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":299,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":300,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":301,\"textContent\":\" \"},{\"nodeType\":1,\"id\":302,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":303,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":304,\"textContent\":\" \"},{\"nodeType\":1,\"id\":305,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":306,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":307,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":308,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":309,\"textContent\":\" \"},{\"nodeType\":1,\"id\":310,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":311,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":312,\"textContent\":\" \"},{\"nodeType\":1,\"id\":313,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"U\",\"value\":\"\"}},{\"nodeType\":3,\"id\":314,\"textContent\":\"U \"},{\"nodeType\":1,\"id\":315,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":316,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":317,\"textContent\":\" \"},{\"nodeType\":1,\"id\":318,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":319,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":320,\"textContent\":\" \"},{\"nodeType\":1,\"id\":321,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":322,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":323,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":324,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":325,\"textContent\":\" \"},{\"nodeType\":1,\"id\":326,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":327,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":328,\"textContent\":\" \"},{\"nodeType\":1,\"id\":329,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":330,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":331,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":332,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":333,\"textContent\":\" \"},{\"nodeType\":1,\"id\":334,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":335,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":336,\"textContent\":\" \"},{\"nodeType\":1,\"id\":337,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":338,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":339,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":340,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":341,\"textContent\":\" \"},{\"nodeType\":1,\"id\":342,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":343,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":344,\"textContent\":\" \"},{\"nodeType\":1,\"id\":345,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":346,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":347,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":348,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":349,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":350,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":351,\"textContent\":\" \"},{\"nodeType\":1,\"id\":352,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"acme\",\"id\":\"acme.meets\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":353,\"textContent\":\" \"},{\"nodeType\":1,\"id\":354,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":355,\"textContent\":\"Which shift(s) begin when C ends?\"}]},{\"nodeType\":3,\"id\":356,\"textContent\":\" \"},{\"nodeType\":1,\"id\":357,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":358,\"textContent\":\" \"},{\"nodeType\":1,\"id\":359,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":360,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":361,\"textContent\":\" \"},{\"nodeType\":1,\"id\":362,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":363,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":364,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":365,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":366,\"textContent\":\" \"},{\"nodeType\":1,\"id\":367,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":368,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":369,\"textContent\":\" \"},{\"nodeType\":1,\"id\":370,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":371,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":372,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":373,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":374,\"textContent\":\" \"},{\"nodeType\":1,\"id\":375,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":376,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":377,\"textContent\":\" \"},{\"nodeType\":1,\"id\":378,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":379,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":380,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":381,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":382,\"textContent\":\" \"},{\"nodeType\":1,\"id\":383,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":384,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":385,\"textContent\":\" \"},{\"nodeType\":1,\"id\":386,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":387,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":388,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":389,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":390,\"textContent\":\" \"},{\"nodeType\":1,\"id\":391,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":392,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":393,\"textContent\":\" \"},{\"nodeType\":1,\"id\":394,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":395,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":396,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":397,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":398,\"textContent\":\" \"},{\"nodeType\":1,\"id\":399,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":400,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":401,\"textContent\":\" \"},{\"nodeType\":1,\"id\":402,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":403,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":404,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":405,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":406,\"textContent\":\" \"},{\"nodeType\":1,\"id\":407,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":408,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":409,\"textContent\":\" \"},{\"nodeType\":1,\"id\":410,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":411,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":412,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":413,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":414,\"textContent\":\" \"},{\"nodeType\":1,\"id\":415,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":416,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":417,\"textContent\":\" \"},{\"nodeType\":1,\"id\":418,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":419,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":420,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":421,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":422,\"textContent\":\" \"},{\"nodeType\":1,\"id\":423,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":424,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":425,\"textContent\":\" \"},{\"nodeType\":1,\"id\":426,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":427,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":428,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":429,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":430,\"textContent\":\" \"},{\"nodeType\":1,\"id\":431,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":432,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":433,\"textContent\":\" \"},{\"nodeType\":1,\"id\":434,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":435,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":436,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":437,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":438,\"textContent\":\" \"},{\"nodeType\":1,\"id\":439,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":440,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":441,\"textContent\":\" \"},{\"nodeType\":1,\"id\":442,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"U\",\"value\":\"\"}},{\"nodeType\":3,\"id\":443,\"textContent\":\"U \"},{\"nodeType\":1,\"id\":444,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":445,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":446,\"textContent\":\" \"},{\"nodeType\":1,\"id\":447,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":448,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":449,\"textContent\":\" \"},{\"nodeType\":1,\"id\":450,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":451,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":452,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":453,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":454,\"textContent\":\" \"},{\"nodeType\":1,\"id\":455,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":456,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":457,\"textContent\":\" \"},{\"nodeType\":1,\"id\":458,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":459,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":460,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":461,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":462,\"textContent\":\" \"},{\"nodeType\":1,\"id\":463,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":464,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":465,\"textContent\":\" \"},{\"nodeType\":1,\"id\":466,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":467,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":468,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":469,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":470,\"textContent\":\" \"},{\"nodeType\":1,\"id\":471,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":472,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":473,\"textContent\":\" \"},{\"nodeType\":1,\"id\":474,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":475,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":476,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":477,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":478,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":479,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":480,\"textContent\":\" \"},{\"nodeType\":1,\"id\":481,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"acme\",\"id\":\"acme.endtime\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":482,\"textContent\":\" \"},{\"nodeType\":1,\"id\":483,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":484,\"textContent\":\" Which shift(s) end at 4 pm?\"}]},{\"nodeType\":3,\"id\":485,\"textContent\":\" \"},{\"nodeType\":1,\"id\":486,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":487,\"textContent\":\" \"},{\"nodeType\":1,\"id\":488,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":489,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":490,\"textContent\":\" \"},{\"nodeType\":1,\"id\":491,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":492,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":493,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":494,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":495,\"textContent\":\" \"},{\"nodeType\":1,\"id\":496,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":497,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":498,\"textContent\":\" \"},{\"nodeType\":1,\"id\":499,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":500,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":501,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":502,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":503,\"textContent\":\" \"},{\"nodeType\":1,\"id\":504,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":505,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":506,\"textContent\":\" \"},{\"nodeType\":1,\"id\":507,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":508,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":509,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":510,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":511,\"textContent\":\" \"},{\"nodeType\":1,\"id\":512,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":513,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":514,\"textContent\":\" \"},{\"nodeType\":1,\"id\":515,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":516,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":517,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":518,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":519,\"textContent\":\" \"},{\"nodeType\":1,\"id\":520,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":521,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":522,\"textContent\":\" \"},{\"nodeType\":1,\"id\":523,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":524,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":525,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":526,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":527,\"textContent\":\" \"},{\"nodeType\":1,\"id\":528,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":529,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":530,\"textContent\":\" \"},{\"nodeType\":1,\"id\":531,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":532,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":533,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":534,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":535,\"textContent\":\" \"},{\"nodeType\":1,\"id\":536,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":537,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":538,\"textContent\":\" \"},{\"nodeType\":1,\"id\":539,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":540,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":541,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":542,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":543,\"textContent\":\" \"},{\"nodeType\":1,\"id\":544,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":545,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":546,\"textContent\":\" \"},{\"nodeType\":1,\"id\":547,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":548,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":549,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":550,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":551,\"textContent\":\" \"},{\"nodeType\":1,\"id\":552,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":553,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":554,\"textContent\":\" \"},{\"nodeType\":1,\"id\":555,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":556,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":557,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":558,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":559,\"textContent\":\" \"},{\"nodeType\":1,\"id\":560,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":561,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":562,\"textContent\":\" \"},{\"nodeType\":1,\"id\":563,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":564,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":565,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":566,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":567,\"textContent\":\" \"},{\"nodeType\":1,\"id\":568,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":569,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":570,\"textContent\":\" \"},{\"nodeType\":1,\"id\":571,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"U\",\"value\":\"\"}},{\"nodeType\":3,\"id\":572,\"textContent\":\"U \"},{\"nodeType\":1,\"id\":573,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":574,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":575,\"textContent\":\" \"},{\"nodeType\":1,\"id\":576,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":577,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":578,\"textContent\":\" \"},{\"nodeType\":1,\"id\":579,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":580,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":581,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":582,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":583,\"textContent\":\" \"},{\"nodeType\":1,\"id\":584,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":585,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":586,\"textContent\":\" \"},{\"nodeType\":1,\"id\":587,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":588,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":589,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":590,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":591,\"textContent\":\" \"},{\"nodeType\":1,\"id\":592,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":593,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":594,\"textContent\":\" \"},{\"nodeType\":1,\"id\":595,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":596,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":597,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":598,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":599,\"textContent\":\" \"},{\"nodeType\":1,\"id\":600,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":601,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":602,\"textContent\":\" \"},{\"nodeType\":1,\"id\":603,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":604,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":605,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":606,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":607,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":608,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":609,\"textContent\":\" \"},{\"nodeType\":1,\"id\":610,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"acme\",\"id\":\"acme.midpoint\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":611,\"textContent\":\" \"},{\"nodeType\":1,\"id\":612,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":613,\"textContent\":\"Coffee breaks happen halfway through a shift.\"},{\"nodeType\":1,\"id\":614,\"tagName\":\"BR\",\"attributes\":{}},{\"nodeType\":3,\"id\":615,\"textContent\":\" Which shift(s) share a break with I?\"}]},{\"nodeType\":3,\"id\":616,\"textContent\":\" \"},{\"nodeType\":1,\"id\":617,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":618,\"textContent\":\" \"},{\"nodeType\":1,\"id\":619,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":620,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":621,\"textContent\":\" \"},{\"nodeType\":1,\"id\":622,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":623,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":624,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":625,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":626,\"textContent\":\" \"},{\"nodeType\":1,\"id\":627,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":628,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":629,\"textContent\":\" \"},{\"nodeType\":1,\"id\":630,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":631,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":632,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":633,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":634,\"textContent\":\" \"},{\"nodeType\":1,\"id\":635,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":636,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":637,\"textContent\":\" \"},{\"nodeType\":1,\"id\":638,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":639,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":640,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":641,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":642,\"textContent\":\" \"},{\"nodeType\":1,\"id\":643,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":644,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":645,\"textContent\":\" \"},{\"nodeType\":1,\"id\":646,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":647,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":648,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":649,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":650,\"textContent\":\" \"},{\"nodeType\":1,\"id\":651,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":652,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":653,\"textContent\":\" \"},{\"nodeType\":1,\"id\":654,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":655,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":656,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":657,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":658,\"textContent\":\" \"},{\"nodeType\":1,\"id\":659,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":660,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":661,\"textContent\":\" \"},{\"nodeType\":1,\"id\":662,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":663,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":664,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":665,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":666,\"textContent\":\" \"},{\"nodeType\":1,\"id\":667,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":668,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":669,\"textContent\":\" \"},{\"nodeType\":1,\"id\":670,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":671,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":672,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":673,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":674,\"textContent\":\" \"},{\"nodeType\":1,\"id\":675,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":676,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":677,\"textContent\":\" \"},{\"nodeType\":1,\"id\":678,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":679,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":680,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":681,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":682,\"textContent\":\" \"},{\"nodeType\":1,\"id\":683,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":684,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":685,\"textContent\":\" \"},{\"nodeType\":1,\"id\":686,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":687,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":688,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":689,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":690,\"textContent\":\" \"},{\"nodeType\":1,\"id\":691,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":692,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":693,\"textContent\":\" \"},{\"nodeType\":1,\"id\":694,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":695,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":696,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":697,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":698,\"textContent\":\" \"},{\"nodeType\":1,\"id\":699,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":700,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":701,\"textContent\":\" \"},{\"nodeType\":1,\"id\":702,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"U\",\"value\":\"\"}},{\"nodeType\":3,\"id\":703,\"textContent\":\"U \"},{\"nodeType\":1,\"id\":704,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":705,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":706,\"textContent\":\" \"},{\"nodeType\":1,\"id\":707,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":708,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":709,\"textContent\":\" \"},{\"nodeType\":1,\"id\":710,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":711,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":712,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":713,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":714,\"textContent\":\" \"},{\"nodeType\":1,\"id\":715,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":716,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":717,\"textContent\":\" \"},{\"nodeType\":1,\"id\":718,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":719,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":720,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":721,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":722,\"textContent\":\" \"},{\"nodeType\":1,\"id\":723,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":724,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":725,\"textContent\":\" \"},{\"nodeType\":1,\"id\":726,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":727,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":728,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":729,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":730,\"textContent\":\" \"},{\"nodeType\":1,\"id\":731,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":732,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":733,\"textContent\":\" \"},{\"nodeType\":1,\"id\":734,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":735,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":736,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":737,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":738,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":739,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":740,\"textContent\":\" \"},{\"nodeType\":1,\"id\":741,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.duration\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":742,\"textContent\":\" \"},{\"nodeType\":1,\"id\":743,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":744,\"textContent\":\"Which shift(s) are six hours long?\"}]},{\"nodeType\":3,\"id\":745,\"textContent\":\" \"},{\"nodeType\":1,\"id\":746,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":747,\"textContent\":\" \"},{\"nodeType\":1,\"id\":748,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":749,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":750,\"textContent\":\" \"},{\"nodeType\":1,\"id\":751,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":752,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":753,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":754,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":755,\"textContent\":\" \"},{\"nodeType\":1,\"id\":756,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":757,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":758,\"textContent\":\" \"},{\"nodeType\":1,\"id\":759,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":760,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":761,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":762,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":763,\"textContent\":\" \"},{\"nodeType\":1,\"id\":764,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":765,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":766,\"textContent\":\" \"},{\"nodeType\":1,\"id\":767,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":768,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":769,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":770,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":771,\"textContent\":\" \"},{\"nodeType\":1,\"id\":772,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":773,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":774,\"textContent\":\" \"},{\"nodeType\":1,\"id\":775,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":776,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":777,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":778,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":779,\"textContent\":\" \"},{\"nodeType\":1,\"id\":780,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":781,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":782,\"textContent\":\" \"},{\"nodeType\":1,\"id\":783,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":784,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":785,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":786,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":787,\"textContent\":\" \"},{\"nodeType\":1,\"id\":788,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":789,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":790,\"textContent\":\" \"},{\"nodeType\":1,\"id\":791,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":792,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":793,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":794,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":795,\"textContent\":\" \"},{\"nodeType\":1,\"id\":796,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":797,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":798,\"textContent\":\" \"},{\"nodeType\":1,\"id\":799,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":800,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":801,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":802,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":803,\"textContent\":\" \"},{\"nodeType\":1,\"id\":804,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":805,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":806,\"textContent\":\" \"},{\"nodeType\":1,\"id\":807,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":808,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":809,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":810,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":811,\"textContent\":\" \"},{\"nodeType\":1,\"id\":812,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":813,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":814,\"textContent\":\" \"},{\"nodeType\":1,\"id\":815,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":816,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":817,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":818,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":819,\"textContent\":\" \"},{\"nodeType\":1,\"id\":820,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":821,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":822,\"textContent\":\" \"},{\"nodeType\":1,\"id\":823,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":824,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":825,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":826,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":827,\"textContent\":\" \"},{\"nodeType\":1,\"id\":828,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":829,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":830,\"textContent\":\" \"},{\"nodeType\":1,\"id\":831,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":832,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":833,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":834,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":835,\"textContent\":\" \"},{\"nodeType\":1,\"id\":836,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":837,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":838,\"textContent\":\" \"},{\"nodeType\":1,\"id\":839,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":840,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":841,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":842,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":843,\"textContent\":\" \"},{\"nodeType\":1,\"id\":844,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":845,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":846,\"textContent\":\" \"},{\"nodeType\":1,\"id\":847,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":848,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":849,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":850,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":851,\"textContent\":\" \"},{\"nodeType\":1,\"id\":852,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":853,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":854,\"textContent\":\" \"},{\"nodeType\":1,\"id\":855,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":856,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":857,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":858,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":859,\"textContent\":\" \"},{\"nodeType\":1,\"id\":860,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":861,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":862,\"textContent\":\" \"},{\"nodeType\":1,\"id\":863,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":864,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":865,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":866,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":867,\"textContent\":\" \"},{\"nodeType\":1,\"id\":868,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":869,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":870,\"textContent\":\" \"},{\"nodeType\":1,\"id\":871,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":872,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":873,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":874,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":875,\"textContent\":\" \"},{\"nodeType\":1,\"id\":876,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":877,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":878,\"textContent\":\" \"},{\"nodeType\":1,\"id\":879,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":880,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":881,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":882,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":883,\"textContent\":\" \"},{\"nodeType\":1,\"id\":884,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":885,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":886,\"textContent\":\" \"},{\"nodeType\":1,\"id\":887,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":888,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":889,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":890,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":891,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":892,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":893,\"textContent\":\" \"},{\"nodeType\":1,\"id\":894,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.duration+starts\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":895,\"textContent\":\" \"},{\"nodeType\":1,\"id\":896,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":897,\"textContent\":\"Which 2 shifts less than 5 hours long start at the same time?\"}]},{\"nodeType\":3,\"id\":898,\"textContent\":\" \"},{\"nodeType\":1,\"id\":899,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":900,\"textContent\":\" \"},{\"nodeType\":1,\"id\":901,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":902,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":903,\"textContent\":\" \"},{\"nodeType\":1,\"id\":904,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":905,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":906,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":907,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":908,\"textContent\":\" \"},{\"nodeType\":1,\"id\":909,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":910,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":911,\"textContent\":\" \"},{\"nodeType\":1,\"id\":912,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":913,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":914,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":915,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":916,\"textContent\":\" \"},{\"nodeType\":1,\"id\":917,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":918,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":919,\"textContent\":\" \"},{\"nodeType\":1,\"id\":920,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":921,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":922,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":923,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":924,\"textContent\":\" \"},{\"nodeType\":1,\"id\":925,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":926,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":927,\"textContent\":\" \"},{\"nodeType\":1,\"id\":928,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":929,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":930,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":931,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":932,\"textContent\":\" \"},{\"nodeType\":1,\"id\":933,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":934,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":935,\"textContent\":\" \"},{\"nodeType\":1,\"id\":936,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":937,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":938,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":939,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":940,\"textContent\":\" \"},{\"nodeType\":1,\"id\":941,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":942,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":943,\"textContent\":\" \"},{\"nodeType\":1,\"id\":944,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":945,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":946,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":947,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":948,\"textContent\":\" \"},{\"nodeType\":1,\"id\":949,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":950,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":951,\"textContent\":\" \"},{\"nodeType\":1,\"id\":952,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":953,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":954,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":955,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":956,\"textContent\":\" \"},{\"nodeType\":1,\"id\":957,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":958,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":959,\"textContent\":\" \"},{\"nodeType\":1,\"id\":960,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":961,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":962,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":963,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":964,\"textContent\":\" \"},{\"nodeType\":1,\"id\":965,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":966,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":967,\"textContent\":\" \"},{\"nodeType\":1,\"id\":968,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":969,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":970,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":971,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":972,\"textContent\":\" \"},{\"nodeType\":1,\"id\":973,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":974,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":975,\"textContent\":\" \"},{\"nodeType\":1,\"id\":976,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":977,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":978,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":979,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":980,\"textContent\":\" \"},{\"nodeType\":1,\"id\":981,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":982,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":983,\"textContent\":\" \"},{\"nodeType\":1,\"id\":984,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":985,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":986,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":987,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":988,\"textContent\":\" \"},{\"nodeType\":1,\"id\":989,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":990,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":991,\"textContent\":\" \"},{\"nodeType\":1,\"id\":992,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":993,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":994,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":995,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":996,\"textContent\":\" \"},{\"nodeType\":1,\"id\":997,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":998,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":999,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1000,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1001,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":1002,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1003,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1004,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1005,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1006,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1007,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1008,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1009,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":1010,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1011,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1012,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1013,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1014,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1015,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1016,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1017,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":1018,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1019,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1020,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1021,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1022,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1023,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1024,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1025,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":1026,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1027,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1028,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1029,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1030,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1031,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1032,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1033,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":1034,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1035,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1036,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1037,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1038,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1039,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1040,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1041,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":1042,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1043,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1044,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1045,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1046,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1047,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.duration+contained\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":1048,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1049,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":1050,\"textContent\":\"Which shift(s) under 7 hours long starts before B starts, and ends after X ends?\"}]},{\"nodeType\":3,\"id\":1051,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1052,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":1053,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1054,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1055,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1056,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1057,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1058,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":1059,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1060,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1061,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1062,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1063,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1064,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1065,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1066,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":1067,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1068,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1069,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1070,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1071,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1072,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1073,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1074,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":1075,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1076,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1077,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1078,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1079,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1080,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1081,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1082,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":1083,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1084,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1085,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1086,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1087,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1088,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1089,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1090,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":1091,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1092,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1093,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1094,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1095,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1096,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1097,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1098,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":1099,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1100,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1101,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1102,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1103,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1104,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1105,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1106,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":1107,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1108,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1109,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1110,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1111,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1112,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1113,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1114,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":1115,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1116,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1117,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1118,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1119,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1120,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1121,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1122,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":1123,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1124,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1125,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1126,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1127,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1128,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1129,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1130,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":1131,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1132,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1133,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1134,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1135,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1136,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1137,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1138,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":1139,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1140,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1141,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1142,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1143,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1144,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1145,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1146,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":1147,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1148,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1149,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1150,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1151,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1152,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1153,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1154,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":1155,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1156,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1157,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1158,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1159,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1160,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1161,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1162,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":1163,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1164,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1165,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1166,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1167,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1168,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1169,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1170,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":1171,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1172,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1173,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1174,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1175,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1176,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1177,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1178,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":1179,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1180,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1181,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1182,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1183,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1184,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1185,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1186,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":1187,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1188,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1189,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1190,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1191,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1192,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1193,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1194,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":1195,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1196,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1197,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1198,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1199,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1200,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.starttime+before+endtime+during\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":1201,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1202,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":1203,\"textContent\":\"Which shift(s) begins before J begins and ends during B?\"}]},{\"nodeType\":3,\"id\":1204,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1205,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":1206,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1207,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1208,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1209,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1210,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1211,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":1212,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1213,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1214,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1215,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1216,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1217,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1218,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1219,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":1220,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1221,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1222,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1223,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1224,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1225,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1226,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1227,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":1228,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1229,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1230,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1231,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1232,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1233,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1234,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1235,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":1236,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1237,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1238,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1239,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1240,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1241,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1242,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1243,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":1244,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1245,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1246,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1247,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1248,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1249,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1250,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1251,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":1252,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1253,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1254,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1255,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1256,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1257,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1258,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1259,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":1260,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1261,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1262,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1263,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1264,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1265,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1266,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1267,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":1268,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1269,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1270,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1271,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1272,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1273,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1274,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1275,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":1276,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1277,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1278,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1279,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1280,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1281,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1282,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1283,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":1284,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1285,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1286,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1287,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1288,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1289,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1290,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1291,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":1292,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1293,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1294,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1295,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1296,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1297,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1298,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1299,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":1300,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1301,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1302,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1303,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1304,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1305,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1306,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1307,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":1308,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1309,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1310,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1311,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1312,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1313,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1314,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1315,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":1316,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1317,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1318,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1319,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1320,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1321,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1322,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1323,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":1324,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1325,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1326,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1327,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1328,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1329,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1330,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1331,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":1332,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1333,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1334,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1335,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1336,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1337,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1338,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1339,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":1340,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1341,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1342,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1343,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1344,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1345,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1346,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1347,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":1348,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1349,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1350,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1351,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1352,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1353,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.ends\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":1354,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1355,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":1356,\"textContent\":\"Which shift(s) end at the same time as F?\"}]},{\"nodeType\":3,\"id\":1357,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1358,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":1359,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1360,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1361,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1362,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1363,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1364,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":1365,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1366,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1367,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1368,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1369,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1370,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1371,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1372,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":1373,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1374,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1375,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1376,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1377,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1378,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1379,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1380,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":1381,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1382,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1383,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1384,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1385,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1386,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1387,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1388,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":1389,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1390,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1391,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1392,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1393,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1394,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1395,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1396,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":1397,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1398,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1399,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1400,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1401,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1402,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1403,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1404,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":1405,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1406,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1407,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1408,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1409,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1410,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1411,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1412,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":1413,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1414,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1415,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1416,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1417,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1418,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1419,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1420,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":1421,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1422,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1423,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1424,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1425,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1426,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1427,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1428,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":1429,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1430,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1431,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1432,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1433,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1434,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1435,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1436,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":1437,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1438,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1439,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1440,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1441,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1442,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1443,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1444,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":1445,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1446,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1447,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1448,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1449,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1450,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1451,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1452,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":1453,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1454,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1455,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1456,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1457,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1458,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1459,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1460,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":1461,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1462,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1463,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1464,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1465,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1466,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1467,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1468,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":1469,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1470,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1471,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1472,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1473,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1474,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1475,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1476,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":1477,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1478,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1479,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1480,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1481,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1482,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1483,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1484,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":1485,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1486,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1487,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1488,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1489,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1490,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1491,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1492,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":1493,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1494,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1495,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1496,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1497,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1498,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1499,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1500,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":1501,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1502,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1503,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1504,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1505,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1506,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.starttime\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":1507,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1508,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":1509,\"textContent\":\"Which shift(s) start at 12pm?\"}]},{\"nodeType\":3,\"id\":1510,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1511,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":1512,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1513,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1514,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1515,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1516,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1517,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":1518,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1519,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1520,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1521,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1522,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1523,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1524,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1525,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":1526,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1527,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1528,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1529,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1530,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1531,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1532,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1533,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":1534,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1535,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1536,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1537,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1538,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1539,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1540,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1541,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":1542,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1543,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1544,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1545,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1546,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1547,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1548,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1549,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":1550,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1551,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1552,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1553,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1554,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1555,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1556,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1557,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":1558,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1559,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1560,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1561,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1562,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1563,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1564,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1565,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":1566,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1567,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1568,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1569,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1570,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1571,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1572,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1573,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":1574,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1575,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1576,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1577,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1578,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1579,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1580,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1581,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":1582,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1583,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1584,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1585,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1586,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1587,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1588,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1589,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":1590,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1591,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1592,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1593,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1594,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1595,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1596,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1597,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":1598,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1599,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1600,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1601,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1602,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1603,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1604,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1605,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":1606,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1607,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1608,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1609,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1610,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1611,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1612,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1613,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":1614,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1615,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1616,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1617,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1618,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1619,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1620,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1621,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":1622,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1623,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1624,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1625,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1626,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1627,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1628,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1629,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":1630,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1631,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1632,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1633,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1634,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1635,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1636,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1637,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":1638,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1639,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1640,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1641,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1642,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1643,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1644,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1645,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":1646,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1647,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1648,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1649,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1650,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1651,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1652,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1653,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":1654,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1655,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1656,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1657,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1658,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1659,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.starts\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":1660,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1661,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":1662,\"textContent\":\"Which shift(s) start at the same time as F?\"}]},{\"nodeType\":3,\"id\":1663,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1664,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":1665,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1666,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1667,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1668,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1669,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1670,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":1671,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1672,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1673,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1674,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1675,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1676,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1677,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1678,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":1679,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1680,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1681,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1682,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1683,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1684,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1685,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1686,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":1687,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1688,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1689,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1690,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1691,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1692,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1693,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1694,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":1695,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1696,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1697,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1698,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1699,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1700,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1701,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1702,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":1703,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1704,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1705,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1706,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1707,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1708,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1709,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1710,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":1711,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1712,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1713,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1714,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1715,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1716,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1717,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1718,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":1719,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1720,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1721,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1722,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1723,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1724,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1725,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1726,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":1727,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1728,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1729,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1730,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1731,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1732,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1733,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1734,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":1735,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1736,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1737,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1738,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1739,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1740,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1741,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1742,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":1743,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1744,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1745,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1746,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1747,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1748,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1749,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1750,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":1751,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1752,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1753,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1754,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1755,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1756,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1757,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1758,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":1759,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1760,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1761,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1762,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1763,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1764,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1765,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1766,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":1767,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1768,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1769,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1770,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1771,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1772,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1773,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1774,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":1775,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1776,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1777,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1778,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1779,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1780,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1781,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1782,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":1783,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1784,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1785,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1786,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1787,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1788,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1789,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1790,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":1791,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1792,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1793,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1794,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1795,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1796,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1797,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1798,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":1799,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1800,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1801,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1802,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1803,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1804,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1805,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1806,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":1807,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1808,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1809,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1810,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1811,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1812,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.meets\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":1813,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1814,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":1815,\"textContent\":\"Which 2 shifts end when Z begins?\"}]},{\"nodeType\":3,\"id\":1816,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1817,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":1818,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1819,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1820,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1821,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1822,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1823,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":1824,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1825,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1826,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1827,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1828,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1829,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1830,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1831,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":1832,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1833,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1834,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1835,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1836,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1837,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1838,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1839,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":1840,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1841,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1842,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1843,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1844,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1845,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1846,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1847,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":1848,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1849,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1850,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1851,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1852,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1853,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1854,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1855,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":1856,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1857,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1858,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1859,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1860,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1861,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1862,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1863,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":1864,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1865,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1866,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1867,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1868,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1869,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1870,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1871,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":1872,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1873,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1874,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1875,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1876,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1877,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1878,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1879,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":1880,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1881,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1882,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1883,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1884,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1885,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1886,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1887,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":1888,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1889,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1890,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1891,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1892,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1893,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1894,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1895,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":1896,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1897,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1898,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1899,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1900,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1901,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1902,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1903,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":1904,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1905,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1906,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1907,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1908,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1909,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1910,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1911,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":1912,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1913,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1914,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1915,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1916,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1917,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1918,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1919,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":1920,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1921,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1922,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1923,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1924,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1925,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1926,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1927,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":1928,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1929,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1930,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1931,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1932,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1933,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1934,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1935,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":1936,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1937,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1938,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1939,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1940,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1941,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1942,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1943,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":1944,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1945,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1946,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1947,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1948,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1949,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1950,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1951,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":1952,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1953,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1954,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1955,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1956,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1957,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1958,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1959,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":1960,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1961,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1962,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1963,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1964,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1965,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.endtime\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":1966,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1967,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":1968,\"textContent\":\"Which shift(s) end at 3pm?\"}]},{\"nodeType\":3,\"id\":1969,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1970,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":1971,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1972,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1973,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1974,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1975,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1976,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":1977,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1978,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1979,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1980,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1981,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1982,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1983,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1984,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":1985,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1986,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1987,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1988,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1989,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1990,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1991,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1992,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":1993,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1994,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1995,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1996,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1997,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1998,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1999,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2000,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":2001,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2002,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2003,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2004,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2005,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2006,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2007,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2008,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":2009,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2010,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2011,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2012,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2013,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2014,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2015,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2016,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":2017,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2018,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2019,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2020,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2021,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2022,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2023,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2024,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":2025,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2026,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2027,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2028,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2029,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2030,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2031,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2032,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":2033,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2034,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2035,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2036,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2037,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2038,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2039,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2040,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":2041,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2042,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2043,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2044,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2045,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2046,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2047,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2048,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":2049,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2050,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2051,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2052,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2053,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2054,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2055,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2056,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":2057,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2058,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2059,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2060,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2061,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2062,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2063,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2064,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":2065,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2066,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2067,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2068,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2069,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2070,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2071,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2072,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":2073,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2074,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2075,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2076,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2077,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2078,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2079,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2080,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":2081,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2082,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2083,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2084,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2085,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2086,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2087,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2088,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":2089,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2090,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2091,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2092,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2093,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2094,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2095,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2096,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":2097,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2098,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2099,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2100,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2101,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2102,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2103,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2104,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":2105,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2106,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2107,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2108,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2109,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2110,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2111,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2112,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":2113,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2114,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2115,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2116,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2117,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2118,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.midpoint\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":2119,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2120,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":2121,\"textContent\":\"Coffee breaks happen halfway through a shift. \"},{\"nodeType\":1,\"id\":2122,\"tagName\":\"BR\",\"attributes\":{}},{\"nodeType\":3,\"id\":2123,\"textContent\":\"Which shifts share a break at 2pm?\"}]},{\"nodeType\":3,\"id\":2124,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2125,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":2126,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2127,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2128,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2129,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2130,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2131,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":2132,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2133,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2134,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2135,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2136,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2137,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2138,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2139,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":2140,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2141,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2142,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2143,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2144,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2145,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2146,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2147,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":2148,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2149,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2150,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2151,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2152,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2153,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2154,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2155,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":2156,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2157,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2158,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2159,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2160,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2161,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2162,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2163,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":2164,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2165,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2166,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2167,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2168,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2169,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2170,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2171,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":2172,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2173,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2174,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2175,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2176,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2177,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2178,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2179,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":2180,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2181,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2182,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2183,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2184,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2185,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2186,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2187,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":2188,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2189,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2190,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2191,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2192,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2193,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2194,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2195,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":2196,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2197,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2198,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2199,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2200,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2201,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2202,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2203,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":2204,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2205,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2206,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2207,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2208,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2209,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2210,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2211,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":2212,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2213,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2214,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2215,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2216,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2217,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2218,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2219,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":2220,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2221,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2222,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2223,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2224,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2225,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2226,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2227,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":2228,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2229,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2230,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2231,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2232,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2233,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2234,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2235,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":2236,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2237,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2238,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2239,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2240,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2241,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2242,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2243,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":2244,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2245,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2246,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2247,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2248,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2249,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2250,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2251,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":2252,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2253,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2254,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2255,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2256,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2257,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2258,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2259,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":2260,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2261,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2262,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2263,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2264,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2265,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2266,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2267,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":2268,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2269,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2270,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2271,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2272,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2273,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\".strategy\",\"style\":\"display: block;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2274,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2275,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":2276,\"textContent\":\"Please describe how to determine what event(s) start at 12pm?\"}]},{\"nodeType\":3,\"id\":2277,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2278,\"tagName\":\"TEXTAREA\",\"attributes\":{\"id\":\"strategyAnswer\",\"rows\":\"5\",\"cols\":\"80\"}},{\"nodeType\":3,\"id\":2279,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2280,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2281,\"textContent\":\" \"},{\"nodeType\":8,\"id\":2282},{\"nodeType\":3,\"id\":2283,\"textContent\":\" \"},{\"nodeType\":8,\"id\":2284},{\"nodeType\":3,\"id\":2285,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2286,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"fixbottom\"},\"childNodes\":[{\"nodeType\":3,\"id\":2287,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2288,\"tagName\":\"BUTTON\",\"attributes\":{\"type\":\"button\",\"id\":\"testingButton\",\"style\":\"display:none;\",\"class\":\"btn\"},\"childNodes\":[{\"nodeType\":3,\"id\":2289,\"textContent\":\"SUBMIT\"}]},{\"nodeType\":3,\"id\":2290,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2291,\"tagName\":\"BUTTON\",\"attributes\":{\"type\":\"button\",\"id\":\"strategyButton\",\"style\":\"display: block;\",\"class\":\"btn\"},\"childNodes\":[{\"nodeType\":3,\"id\":2292,\"textContent\":\"SUBMIT\"}]},{\"nodeType\":3,\"id\":2293,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2294,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2295,\"textContent\":\" \"},{\"nodeType\":8,\"id\":2296},{\"nodeType\":3,\"id\":2297,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2298,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"d3container\"},\"childNodes\":[{\"nodeType\":1,\"id\":2299,\"tagName\":\"svg\",\"attributes\":{\"width\":\"930\",\"height\":\"915\"},\"childNodes\":[{\"nodeType\":1,\"id\":2300,\"tagName\":\"g\",\"attributes\":{\"transform\":\"translate(100,25)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2301,\"tagName\":\"g\",\"attributes\":{\"class\":\"leaders\"}},{\"nodeType\":1,\"id\":2302,\"tagName\":\"g\",\"attributes\":{\"class\":\"static-scaffold\"}}]}]}]},{\"nodeType\":3,\"id\":2303,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2304,\"textContent\":\" \"},{\"nodeType\":8,\"id\":2305},{\"nodeType\":3,\"id\":2306,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2307,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":2308,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2309,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":2310,\"textContent\":\" \"}]}]}]]}",
  "useCssProxy": true,
  "loadTimes": "es: 365, dom: 1290, initialDom: 1356",
  "javascriptErrors": []
}