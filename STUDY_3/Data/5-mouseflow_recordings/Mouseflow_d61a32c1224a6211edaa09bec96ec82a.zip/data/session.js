var MF = MF || {};MF.RecordingData = MF.RecordingData || {};MF.RecordingData["session"] = {
  "id": "d61a32c1224a6211edaa09bec96ec82a",
  "created": "2018-05-22T15:08:29.0673801-07:00",
  "lastActivity": "2018-05-22T15:09:20.5826319-07:00",
  "pageViews": [
    {
      "id": "05222943ebfb395ff9e8db728bb97534ced31ba3",
      "startTime": "2018-05-22T15:08:29.1726319-07:00",
      "endTime": "2018-05-22T15:09:20.5826319-07:00",
      "title": "FOX2YP",
      "uri": "https://warm-citadel-75324.herokuapp.com/",
      "websitePage": "/4",
      "visitTime": 51410,
      "engagementTime": 41612,
      "scroll": 100.0,
      "tags": [
        "form-interact"
      ],
      "friction": 0,
      "annotations": []
    }
  ],
  "duration": 51410,
  "engagementTime": 41612,
  "totalFriction": 0,
  "country": "us",
  "region": "CA",
  "city": "La Jolla",
  "isp": "University of California, San Diego",
  "ip": "128.54.68.23",
  "lang": "en-US",
  "userAgent": "Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/66.0.3359.181 Safari/537.36",
  "browser": "Chrome",
  "browserVersion": "66.0.3359.181",
  "os": "Windows",
  "osVersion": "7",
  "device": "Desktop",
  "referrer": "",
  "referrerType": "",
  "screenRes": "1920x1200",
  "tags": [
    "form-interact"
  ],
  "variables": [
    "SID=Q3JLW",
    "CONDITION=115",
    "ORTH_CORRECT=1"
  ],
  "watched": false,
  "starred": false,
  "lng": -117.2359,
  "lat": 32.8807,
  "visitorId": "35c6870d53546a694a14f58d2e33be09",
  "gdpr": false
}