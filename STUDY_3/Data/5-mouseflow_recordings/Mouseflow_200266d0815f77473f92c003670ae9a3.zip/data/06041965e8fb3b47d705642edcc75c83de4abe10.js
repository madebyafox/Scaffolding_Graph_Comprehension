var MF = MF || {};MF.RecordingData = MF.RecordingData || {};MF.RecordingData["06041965e8fb3b47d705642edcc75c83de4abe10"] = {
  "startTime": "2018-06-04T20:06:19.6982326Z",
  "websitePageUrl": "/",
  "visitTime": 39748,
  "engagementTime": 38051,
  "pageTitle": "FOX2YP",
  "url": "https://warm-citadel-75324.herokuapp.com/",
  "viewportWidth": 929,
  "viewportHeight": 1047,
  "tags": [],
  "session": {
    "id": "200266d0815f77473f92c003670ae9a3",
    "created": "2018-06-04T20:06:19.3662604+00:00",
    "lastActivity": "0001-01-01T00:00:00+00:00",
    "pages": 1,
    "duration": 0,
    "engagementTime": 0,
    "totalFriction": 0,
    "country": "us",
    "region": "CA",
    "city": "La Jolla",
    "isp": "University of California, San Diego",
    "ip": "###.###.###.###",
    "lang": "en-US",
    "userAgent": "Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/66.0.3359.181 Safari/537.36",
    "browser": "Chrome",
    "browserVersion": "66.0.3359.181",
    "os": "Windows",
    "osVersion": "7",
    "device": "Desktop",
    "referrer": "",
    "referrerType": "",
    "screenRes": "1920x1200",
    "entryPage": "/",
    "tags": [],
    "variables": [],
    "watched": false,
    "starred": false,
    "lng": 32.8807,
    "lat": 32.8807,
    "visitorId": "6ecc3b08b20ef4dcaf045e0fffcc3310",
    "gdpr": false,
    "visitorName": null,
    "playbackUrl": "https://us.mouseflow.com/websites/e0c9ff05-6fcb-4c4a-8173-e5a0724987b1/recordings/200266d0815f77473f92c003670ae9a3/play"
  },
  "events": [
    {
      "t": 101,
      "e": 101,
      "ty": 0,
      "x": 929,
      "y": 1047
    },
    {
      "t": 360,
      "e": 360,
      "ty": 14,
      "x": 0,
      "y": 1046
    },
    {
      "t": 1200,
      "e": 1200,
      "ty": 2,
      "x": 549,
      "y": 38
    },
    {
      "t": 1253,
      "e": 1253,
      "ty": 41,
      "x": 41723,
      "y": 245,
      "ta": "#jspsych-single-stim-stimulus"
    },
    {
      "t": 1300,
      "e": 1300,
      "ty": 2,
      "x": 672,
      "y": 154
    },
    {
      "t": 1401,
      "e": 1401,
      "ty": 2,
      "x": 702,
      "y": 164
    },
    {
      "t": 1500,
      "e": 1500,
      "ty": 2,
      "x": 771,
      "y": 215
    },
    {
      "t": 1500,
      "e": 1500,
      "ty": 41,
      "x": 49533,
      "y": 7536,
      "ta": "#jspsych-single-stim-stimulus"
    },
    {
      "t": 1601,
      "e": 1601,
      "ty": 2,
      "x": 855,
      "y": 273
    },
    {
      "t": 1701,
      "e": 1701,
      "ty": 2,
      "x": 867,
      "y": 288
    },
    {
      "t": 1751,
      "e": 1751,
      "ty": 41,
      "x": 55049,
      "y": 14171,
      "ta": "#jspsych-single-stim-stimulus"
    },
    {
      "t": 1800,
      "e": 1800,
      "ty": 2,
      "x": 882,
      "y": 303
    },
    {
      "t": 1900,
      "e": 1900,
      "ty": 2,
      "x": 893,
      "y": 308
    },
    {
      "t": 2001,
      "e": 2001,
      "ty": 2,
      "x": 903,
      "y": 313
    },
    {
      "t": 2001,
      "e": 2001,
      "ty": 41,
      "x": 56742,
      "y": 15564,
      "ta": "#jspsych-single-stim-stimulus"
    },
    {
      "t": 2100,
      "e": 2100,
      "ty": 2,
      "x": 920,
      "y": 319
    },
    {
      "t": 2201,
      "e": 2201,
      "ty": 2,
      "x": 927,
      "y": 321
    },
    {
      "t": 2263,
      "e": 2263,
      "ty": 40,
      "x": 0,
      "y": 0
    },
    {
      "t": 2300,
      "e": 2300,
      "ty": 2,
      "x": 928,
      "y": 321
    },
    {
      "t": 4401,
      "e": 4401,
      "ty": 2,
      "x": 925,
      "y": 321
    },
    {
      "t": 4900,
      "e": 4900,
      "ty": 2,
      "x": 927,
      "y": 321
    },
    {
      "t": 5015,
      "e": 5015,
      "ty": 40,
      "x": 0,
      "y": 0
    },
    {
      "t": 5700,
      "e": 5700,
      "ty": 2,
      "x": 928,
      "y": 322
    },
    {
      "t": 6103,
      "e": 6103,
      "ty": 40,
      "x": 0,
      "y": 0
    },
    {
      "t": 7600,
      "e": 7600,
      "ty": 2,
      "x": 928,
      "y": 166
    },
    {
      "t": 7701,
      "e": 7701,
      "ty": 2,
      "x": 917,
      "y": 171
    },
    {
      "t": 7901,
      "e": 7901,
      "ty": 2,
      "x": 925,
      "y": 174
    },
    {
      "t": 7911,
      "e": 7911,
      "ty": 40,
      "x": 0,
      "y": 0
    },
    {
      "t": 8000,
      "e": 8000,
      "ty": 2,
      "x": 928,
      "y": 176
    },
    {
      "t": 9201,
      "e": 9201,
      "ty": 2,
      "x": 912,
      "y": 167
    },
    {
      "t": 9251,
      "e": 9251,
      "ty": 41,
      "x": 63810,
      "y": 6808,
      "ta": "html > body"
    },
    {
      "t": 9301,
      "e": 9301,
      "ty": 2,
      "x": 875,
      "y": 13
    },
    {
      "t": 9303,
      "e": 9303,
      "ty": 40,
      "x": 0,
      "y": 0
    },
    {
      "t": 9400,
      "e": 9400,
      "ty": 2,
      "x": 873,
      "y": 3
    },
    {
      "t": 9501,
      "e": 9501,
      "ty": 41,
      "x": 62732,
      "y": 190,
      "ta": "html"
    },
    {
      "t": 9901,
      "e": 9901,
      "ty": 2,
      "x": 890,
      "y": 1
    },
    {
      "t": 10001,
      "e": 10001,
      "ty": 2,
      "x": 904,
      "y": 8
    },
    {
      "t": 10001,
      "e": 10001,
      "ty": 41,
      "x": 64385,
      "y": 0,
      "ta": "html > body"
    },
    {
      "t": 10002,
      "e": 10002,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 10070,
      "e": 10070,
      "ty": 40,
      "x": 0,
      "y": 0
    },
    {
      "t": 10101,
      "e": 10101,
      "ty": 2,
      "x": 928,
      "y": 9
    },
    {
      "t": 11601,
      "e": 11601,
      "ty": 2,
      "x": 921,
      "y": 7
    },
    {
      "t": 11701,
      "e": 11701,
      "ty": 2,
      "x": 547,
      "y": 427
    },
    {
      "t": 11751,
      "e": 11751,
      "ty": 41,
      "x": 32221,
      "y": 30391,
      "ta": "#jspsych-single-stim-stimulus"
    },
    {
      "t": 11801,
      "e": 11801,
      "ty": 2,
      "x": 453,
      "y": 501
    },
    {
      "t": 11801,
      "e": 11801,
      "ty": 1,
      "x": 0,
      "y": 4
    },
    {
      "t": 11901,
      "e": 11901,
      "ty": 2,
      "x": 447,
      "y": 507
    },
    {
      "t": 11901,
      "e": 11901,
      "ty": 1,
      "x": 0,
      "y": 15
    },
    {
      "t": 12001,
      "e": 12001,
      "ty": 1,
      "x": 0,
      "y": 16
    },
    {
      "t": 12001,
      "e": 12001,
      "ty": 41,
      "x": 31839,
      "y": 31456,
      "ta": "#jspsych-single-stim-stimulus"
    },
    {
      "t": 12201,
      "e": 12201,
      "ty": 2,
      "x": 676,
      "y": 537
    },
    {
      "t": 12252,
      "e": 12252,
      "ty": 41,
      "x": 56414,
      "y": 36535,
      "ta": "#jspsych-single-stim-stimulus"
    },
    {
      "t": 12301,
      "e": 12301,
      "ty": 2,
      "x": 897,
      "y": 569
    },
    {
      "t": 12501,
      "e": 12501,
      "ty": 2,
      "x": 926,
      "y": 685
    },
    {
      "t": 12601,
      "e": 12601,
      "ty": 2,
      "x": 450,
      "y": 640
    },
    {
      "t": 12601,
      "e": 12601,
      "ty": 1,
      "x": 0,
      "y": 8
    },
    {
      "t": 12701,
      "e": 12701,
      "ty": 2,
      "x": 355,
      "y": 617
    },
    {
      "t": 12701,
      "e": 12701,
      "ty": 1,
      "x": 0,
      "y": 0
    },
    {
      "t": 12750,
      "e": 12750,
      "ty": 41,
      "x": 26814,
      "y": 40467,
      "ta": "#jspsych-single-stim-stimulus"
    },
    {
      "t": 12800,
      "e": 12800,
      "ty": 2,
      "x": 324,
      "y": 689
    },
    {
      "t": 12800,
      "e": 12800,
      "ty": 1,
      "x": 0,
      "y": 6
    },
    {
      "t": 12901,
      "e": 12901,
      "ty": 2,
      "x": 267,
      "y": 896
    },
    {
      "t": 12901,
      "e": 12901,
      "ty": 1,
      "x": 0,
      "y": 16
    },
    {
      "t": 13000,
      "e": 13000,
      "ty": 2,
      "x": 267,
      "y": 900
    },
    {
      "t": 13002,
      "e": 13002,
      "ty": 41,
      "x": 22008,
      "y": 63650,
      "ta": "#jspsych-single-stim-stimulus"
    },
    {
      "t": 13101,
      "e": 13101,
      "ty": 2,
      "x": 277,
      "y": 875
    },
    {
      "t": 13200,
      "e": 13200,
      "ty": 2,
      "x": 402,
      "y": 417
    },
    {
      "t": 13239,
      "e": 13239,
      "ty": 40,
      "x": 0,
      "y": 0
    },
    {
      "t": 13252,
      "e": 13252,
      "ty": 41,
      "x": 31402,
      "y": 2099,
      "ta": "html > body"
    },
    {
      "t": 13301,
      "e": 13301,
      "ty": 2,
      "x": 445,
      "y": 41
    },
    {
      "t": 14700,
      "e": 14700,
      "ty": 2,
      "x": 733,
      "y": 124
    },
    {
      "t": 14750,
      "e": 14750,
      "ty": 41,
      "x": 50461,
      "y": 3358,
      "ta": "#jspsych-single-stim-stimulus"
    },
    {
      "t": 14800,
      "e": 14800,
      "ty": 2,
      "x": 807,
      "y": 186
    },
    {
      "t": 14900,
      "e": 14900,
      "ty": 2,
      "x": 882,
      "y": 232
    },
    {
      "t": 15000,
      "e": 15000,
      "ty": 2,
      "x": 918,
      "y": 248
    },
    {
      "t": 17768,
      "e": 17768,
      "ty": 40,
      "x": 0,
      "y": 0
    },
    {
      "t": 19100,
      "e": 19100,
      "ty": 0,
      "x": 947,
      "y": 1047
    },
    {
      "t": 19200,
      "e": 19200,
      "ty": 0,
      "x": 981,
      "y": 1047
    },
    {
      "t": 19400,
      "e": 19400,
      "ty": 0,
      "x": 1014,
      "y": 1047
    },
    {
      "t": 19500,
      "e": 19500,
      "ty": 0,
      "x": 1105,
      "y": 1047
    },
    {
      "t": 19700,
      "e": 19700,
      "ty": 0,
      "x": 1184,
      "y": 1047
    },
    {
      "t": 19800,
      "e": 19800,
      "ty": 0,
      "x": 1434,
      "y": 1047
    },
    {
      "t": 19900,
      "e": 19900,
      "ty": 0,
      "x": 1437,
      "y": 1047
    },
    {
      "t": 20000,
      "e": 20000,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 20100,
      "e": 24900,
      "ty": 0,
      "x": 1435,
      "y": 1047
    },
    {
      "t": 20200,
      "e": 25000,
      "ty": 0,
      "x": 1431,
      "y": 1047
    },
    {
      "t": 20300,
      "e": 25100,
      "ty": 0,
      "x": 1267,
      "y": 1047
    },
    {
      "t": 20401,
      "e": 25201,
      "ty": 0,
      "x": 859,
      "y": 1047
    },
    {
      "t": 20501,
      "e": 25301,
      "ty": 0,
      "x": 817,
      "y": 1047
    },
    {
      "t": 20801,
      "e": 25601,
      "ty": 0,
      "x": 820,
      "y": 1047
    },
    {
      "t": 20901,
      "e": 25701,
      "ty": 0,
      "x": 910,
      "y": 1047
    },
    {
      "t": 21000,
      "e": 25800,
      "ty": 0,
      "x": 1020,
      "y": 1047
    },
    {
      "t": 21100,
      "e": 25900,
      "ty": 0,
      "x": 1053,
      "y": 1047
    },
    {
      "t": 21200,
      "e": 26000,
      "ty": 0,
      "x": 1063,
      "y": 1047
    },
    {
      "t": 21301,
      "e": 26101,
      "ty": 0,
      "x": 1068,
      "y": 1047
    },
    {
      "t": 21400,
      "e": 26200,
      "ty": 2,
      "x": 1050,
      "y": 326
    },
    {
      "t": 21501,
      "e": 26301,
      "ty": 2,
      "x": 752,
      "y": 586
    },
    {
      "t": 21501,
      "e": 26301,
      "ty": 41,
      "x": 44700,
      "y": 37928,
      "ta": "#jspsych-single-stim-stimulus"
    },
    {
      "t": 21601,
      "e": 26401,
      "ty": 2,
      "x": 653,
      "y": 732
    },
    {
      "t": 21701,
      "e": 26501,
      "ty": 2,
      "x": 649,
      "y": 744
    },
    {
      "t": 21751,
      "e": 26551,
      "ty": 41,
      "x": 39075,
      "y": 50871,
      "ta": "#jspsych-single-stim-stimulus"
    },
    {
      "t": 21900,
      "e": 26700,
      "ty": 2,
      "x": 649,
      "y": 756
    },
    {
      "t": 22000,
      "e": 26800,
      "ty": 2,
      "x": 649,
      "y": 763
    },
    {
      "t": 22001,
      "e": 26801,
      "ty": 41,
      "x": 39075,
      "y": 52428,
      "ta": "#jspsych-single-stim-stimulus"
    },
    {
      "t": 22201,
      "e": 27001,
      "ty": 2,
      "x": 645,
      "y": 776
    },
    {
      "t": 22250,
      "e": 27050,
      "ty": 41,
      "x": 38747,
      "y": 53738,
      "ta": "#jspsych-single-stim-stimulus"
    },
    {
      "t": 22300,
      "e": 27100,
      "ty": 2,
      "x": 639,
      "y": 783
    },
    {
      "t": 22400,
      "e": 27200,
      "ty": 2,
      "x": 636,
      "y": 786
    },
    {
      "t": 22501,
      "e": 27301,
      "ty": 41,
      "x": 38365,
      "y": 54312,
      "ta": "#jspsych-single-stim-stimulus"
    },
    {
      "t": 22700,
      "e": 27500,
      "ty": 2,
      "x": 415,
      "y": 673
    },
    {
      "t": 22751,
      "e": 27551,
      "ty": 41,
      "x": 11495,
      "y": 35716,
      "ta": "#jspsych-single-stim-stimulus"
    },
    {
      "t": 22800,
      "e": 27600,
      "ty": 2,
      "x": 16,
      "y": 490
    },
    {
      "t": 22900,
      "e": 27700,
      "ty": 2,
      "x": 6,
      "y": 484
    },
    {
      "t": 23000,
      "e": 27800,
      "ty": 2,
      "x": 12,
      "y": 442
    },
    {
      "t": 23000,
      "e": 27800,
      "ty": 41,
      "x": 4287,
      "y": 26132,
      "ta": "#jspsych-single-stim-stimulus"
    },
    {
      "t": 23101,
      "e": 27901,
      "ty": 2,
      "x": 110,
      "y": 291
    },
    {
      "t": 23200,
      "e": 28000,
      "ty": 2,
      "x": 176,
      "y": 244
    },
    {
      "t": 23251,
      "e": 28051,
      "ty": 41,
      "x": 13352,
      "y": 9912,
      "ta": "#jspsych-single-stim-stimulus"
    },
    {
      "t": 23301,
      "e": 28101,
      "ty": 2,
      "x": 178,
      "y": 244
    },
    {
      "t": 27701,
      "e": 32501,
      "ty": 2,
      "x": 179,
      "y": 233
    },
    {
      "t": 27751,
      "e": 32551,
      "ty": 41,
      "x": 13461,
      "y": 3194,
      "ta": "#jspsych-single-stim-stimulus"
    },
    {
      "t": 27800,
      "e": 32600,
      "ty": 2,
      "x": 181,
      "y": 103
    },
    {
      "t": 27900,
      "e": 32700,
      "ty": 2,
      "x": 172,
      "y": 56
    },
    {
      "t": 28001,
      "e": 32801,
      "ty": 2,
      "x": 160,
      "y": 31
    },
    {
      "t": 28001,
      "e": 32801,
      "ty": 41,
      "x": 9477,
      "y": 1463,
      "ta": "html > body"
    },
    {
      "t": 28030,
      "e": 32830,
      "ty": 40,
      "x": 0,
      "y": 0
    },
    {
      "t": 28101,
      "e": 32901,
      "ty": 2,
      "x": 155,
      "y": 17
    },
    {
      "t": 28251,
      "e": 33051,
      "ty": 41,
      "x": 9166,
      "y": 572,
      "ta": "html > body"
    },
    {
      "t": 30089,
      "e": 34889,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 39748,
      "e": 38051,
      "ty": 20,
      "x": 0,
      "y": 0
    }
  ],
  "domMutations": [],
  "initialDom": "{\"f\":\"initialize\",\"args\":[1,[{\"nodeType\":10,\"id\":2,\"name\":\"html\",\"publicId\":\"\",\"systemId\":\"\"},{\"nodeType\":1,\"id\":3,\"tagName\":\"HTML\",\"attributes\":{\"class\":\"fa-events-icons-ready\"},\"childNodes\":[{\"nodeType\":1,\"id\":4,\"tagName\":\"HEAD\",\"attributes\":{},\"childNodes\":[{\"nodeType\":3,\"id\":5,\"textContent\":\" \"},{\"nodeType\":1,\"id\":6,\"tagName\":\"TITLE\",\"attributes\":{},\"childNodes\":[{\"nodeType\":3,\"id\":7,\"textContent\":\"FOX2YP\"}]},{\"nodeType\":3,\"id\":8,\"textContent\":\" \"},{\"nodeType\":8,\"id\":9},{\"nodeType\":3,\"id\":10,\"textContent\":\" \"},{\"nodeType\":1,\"id\":11,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":12,\"textContent\":\" \"},{\"nodeType\":1,\"id\":13,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":14,\"textContent\":\" \"},{\"nodeType\":1,\"id\":15,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":16,\"textContent\":\" \"},{\"nodeType\":1,\"id\":17,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":18,\"textContent\":\" \"},{\"nodeType\":1,\"id\":19,\"tagName\":\"SCRIPT\"},{\"nodeType\":1,\"id\":20,\"tagName\":\"LINK\",\"attributes\":{\"href\":\"https://use.fontawesome.com/945539d961.css\",\"media\":\"all\",\"rel\":\"stylesheet\"}},{\"nodeType\":3,\"id\":21,\"textContent\":\" \"},{\"nodeType\":8,\"id\":22},{\"nodeType\":3,\"id\":23,\"textContent\":\" \"},{\"nodeType\":1,\"id\":24,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":25,\"textContent\":\" \"},{\"nodeType\":1,\"id\":26,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":27,\"textContent\":\" \"},{\"nodeType\":1,\"id\":28,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":29,\"textContent\":\" \"},{\"nodeType\":1,\"id\":30,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":31,\"textContent\":\" \"},{\"nodeType\":1,\"id\":32,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":33,\"textContent\":\" \"},{\"nodeType\":1,\"id\":34,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":35,\"textContent\":\" \"},{\"nodeType\":1,\"id\":36,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":37,\"textContent\":\" \"},{\"nodeType\":8,\"id\":38},{\"nodeType\":3,\"id\":39,\"textContent\":\" \"},{\"nodeType\":1,\"id\":40,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":41,\"textContent\":\" \"},{\"nodeType\":8,\"id\":42},{\"nodeType\":3,\"id\":43,\"textContent\":\" \"},{\"nodeType\":8,\"id\":44},{\"nodeType\":3,\"id\":45,\"textContent\":\" \"},{\"nodeType\":1,\"id\":46,\"tagName\":\"LINK\",\"attributes\":{\"href\":\"../views/jsPsych/css/jspsych.css\",\"rel\":\"stylesheet\",\"type\":\"text/css\"}},{\"nodeType\":3,\"id\":47,\"textContent\":\" \"},{\"nodeType\":1,\"id\":48,\"tagName\":\"LINK\",\"attributes\":{\"href\":\"../css/styles.css\",\"rel\":\"stylesheet\",\"type\":\"text/css\"}},{\"nodeType\":3,\"id\":49,\"textContent\":\" \"},{\"nodeType\":1,\"id\":50,\"tagName\":\"SCRIPT\"},{\"nodeType\":1,\"id\":51,\"tagName\":\"SCRIPT\"}]},{\"nodeType\":3,\"id\":52,\"textContent\":\" \"},{\"nodeType\":8,\"id\":53},{\"nodeType\":3,\"id\":54,\"textContent\":\" \"},{\"nodeType\":1,\"id\":55,\"tagName\":\"BODY\",\"attributes\":{\"class\":\"jspsych-display-element\"},\"childNodes\":[{\"nodeType\":3,\"id\":56,\"textContent\":\" \"},{\"nodeType\":1,\"id\":57,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":58,\"textContent\":\" \"},{\"nodeType\":1,\"id\":59,\"tagName\":\"IMG\",\"attributes\":{\"src\":\"img/phone.png\",\"id\":\"jspsych-single-stim-stimulus\"}}]}]}]]}",
  "useCssProxy": true,
  "loadTimes": "es: 142, dom: 142, initialDom: 146",
  "javascriptErrors": []
}