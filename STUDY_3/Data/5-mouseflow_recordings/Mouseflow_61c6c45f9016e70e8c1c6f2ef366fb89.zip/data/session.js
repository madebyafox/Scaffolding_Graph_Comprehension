var MF = MF || {};MF.RecordingData = MF.RecordingData || {};MF.RecordingData["session"] = {
  "id": "61c6c45f9016e70e8c1c6f2ef366fb89",
  "created": "2018-05-15T17:05:13.0633047-07:00",
  "lastActivity": "2018-05-15T17:05:47.5614763-07:00",
  "pageViews": [
    {
      "id": "05151336b23b630d8231d0e92d569444cc323c66",
      "startTime": "2018-05-15T17:05:13.0633047-07:00",
      "endTime": "2018-05-15T17:05:47.5614763-07:00",
      "title": "FOX2YP",
      "uri": "https://warm-citadel-75324.herokuapp.com/",
      "websitePage": "/7",
      "visitTime": 34607,
      "engagementTime": 29109,
      "scroll": 100.0,
      "tags": [
        "form-interact"
      ],
      "friction": 0,
      "annotations": []
    }
  ],
  "duration": 34607,
  "engagementTime": 29109,
  "totalFriction": 0,
  "country": "us",
  "region": "CA",
  "city": "La Jolla",
  "isp": "University of California, San Diego",
  "ip": "128.54.68.32",
  "lang": "en-US",
  "userAgent": "Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/66.0.3359.181 Safari/537.36",
  "browser": "Chrome",
  "browserVersion": "66.0.3359.181",
  "os": "Windows",
  "osVersion": "7",
  "device": "Desktop",
  "referrer": "",
  "referrerType": "",
  "screenRes": "1920x1200",
  "tags": [
    "form-interact"
  ],
  "variables": [
    "SID=J2MPW",
    "CONDITION=121",
    "TRI_CORRECT=1"
  ],
  "watched": false,
  "starred": false,
  "lng": -117.2359,
  "lat": 32.8807,
  "visitorId": "db51ba816f562f06b18521977fd0aa7c",
  "gdpr": false
}