var MF = MF || {};MF.RecordingData = MF.RecordingData || {};MF.RecordingData["052555054d02acfab84f09432fde742e15d6fb4a"] = {
  "startTime": "2018-05-25T16:15:55.4507626Z",
  "websitePageUrl": "/16",
  "visitTime": 280962,
  "engagementTime": 206939,
  "pageTitle": "FOX2YP",
  "url": "https://warm-citadel-75324.herokuapp.com/",
  "viewportWidth": 1920,
  "viewportHeight": 1200,
  "tags": [
    "form-interact",
    "submit"
  ],
  "session": {
    "id": "9f0ee61a220d004aaf5d2185e53b7104",
    "created": "2018-05-25T16:15:55.4192765+00:00",
    "lastActivity": "0001-01-01T00:00:00+00:00",
    "pages": 1,
    "duration": 0,
    "engagementTime": 0,
    "totalFriction": 0,
    "country": "us",
    "region": "CA",
    "city": "La Jolla",
    "isp": "University of California, San Diego",
    "ip": "###.###.###.###",
    "lang": "en-US",
    "userAgent": "Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/66.0.3359.181 Safari/537.36",
    "browser": "Chrome",
    "browserVersion": "66.0.3359.181",
    "os": "Windows",
    "osVersion": "7",
    "device": "Desktop",
    "referrer": "",
    "referrerType": "",
    "screenRes": "1920x1200",
    "entryPage": "/16",
    "tags": [
      "form-interact",
      "submit"
    ],
    "variables": [
      "SID=RV9F6",
      "CONDITION=115"
    ],
    "watched": false,
    "starred": false,
    "lng": 32.8807,
    "lat": 32.8807,
    "visitorId": "c2e0e3b5fc0815f70bdaea71c577d49d",
    "gdpr": false,
    "visitorName": null,
    "playbackUrl": "https://us.mouseflow.com/websites/e0c9ff05-6fcb-4c4a-8173-e5a0724987b1/recordings/9f0ee61a220d004aaf5d2185e53b7104/play"
  },
  "events": [
    {
      "t": 1,
      "e": 1,
      "ty": 14,
      "x": 0,
      "y": 1199
    },
    {
      "t": 225,
      "e": 225,
      "ty": 0,
      "x": 1920,
      "y": 1200
    },
    {
      "t": 6404,
      "e": 5225,
      "ty": 2,
      "x": 544,
      "y": 713
    },
    {
      "t": 6505,
      "e": 5326,
      "ty": 2,
      "x": 538,
      "y": 655
    },
    {
      "t": 6505,
      "e": 5326,
      "ty": 41,
      "x": 49562,
      "y": 35842,
      "ta": "> div.stimulus > div"
    },
    {
      "t": 6604,
      "e": 5425,
      "ty": 2,
      "x": 537,
      "y": 641
    },
    {
      "t": 6704,
      "e": 5525,
      "ty": 2,
      "x": 536,
      "y": 637
    },
    {
      "t": 6755,
      "e": 5576,
      "ty": 41,
      "x": 49337,
      "y": 34844,
      "ta": "> div.stimulus > div"
    },
    {
      "t": 8405,
      "e": 7226,
      "ty": 2,
      "x": 536,
      "y": 636
    },
    {
      "t": 8505,
      "e": 7326,
      "ty": 41,
      "x": 49337,
      "y": 34789,
      "ta": "> div.stimulus > div"
    },
    {
      "t": 10004,
      "e": 8825,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 13190,
      "e": 12011,
      "ty": 6,
      "x": 525,
      "y": 603,
      "ta": "#strategyAnswer"
    },
    {
      "t": 13204,
      "e": 12025,
      "ty": 2,
      "x": 525,
      "y": 603
    },
    {
      "t": 13255,
      "e": 12076,
      "ty": 41,
      "x": 47651,
      "y": 58468,
      "ta": "#strategyAnswer"
    },
    {
      "t": 13304,
      "e": 12125,
      "ty": 2,
      "x": 520,
      "y": 589
    },
    {
      "t": 13405,
      "e": 12226,
      "ty": 2,
      "x": 509,
      "y": 541
    },
    {
      "t": 13505,
      "e": 12326,
      "ty": 2,
      "x": 506,
      "y": 527
    },
    {
      "t": 13505,
      "e": 12326,
      "ty": 41,
      "x": 45965,
      "y": 3451,
      "ta": "#strategyAnswer"
    },
    {
      "t": 13524,
      "e": 12345,
      "ty": 7,
      "x": 506,
      "y": 520,
      "ta": "#strategyAnswer"
    },
    {
      "t": 13605,
      "e": 12426,
      "ty": 2,
      "x": 506,
      "y": 501
    },
    {
      "t": 13755,
      "e": 12576,
      "ty": 41,
      "x": 45965,
      "y": 14664,
      "ta": "#.strategy > p"
    },
    {
      "t": 13804,
      "e": 12625,
      "ty": 2,
      "x": 505,
      "y": 501
    },
    {
      "t": 13841,
      "e": 12662,
      "ty": 6,
      "x": 490,
      "y": 529,
      "ta": "#strategyAnswer"
    },
    {
      "t": 13905,
      "e": 12726,
      "ty": 2,
      "x": 474,
      "y": 577
    },
    {
      "t": 14005,
      "e": 12826,
      "ty": 2,
      "x": 472,
      "y": 578
    },
    {
      "t": 14005,
      "e": 12826,
      "ty": 41,
      "x": 42143,
      "y": 44713,
      "ta": "#strategyAnswer"
    },
    {
      "t": 14105,
      "e": 12926,
      "ty": 2,
      "x": 478,
      "y": 575
    },
    {
      "t": 14190,
      "e": 13011,
      "ty": 7,
      "x": 526,
      "y": 520,
      "ta": "#strategyAnswer"
    },
    {
      "t": 14205,
      "e": 13026,
      "ty": 2,
      "x": 526,
      "y": 520
    },
    {
      "t": 14255,
      "e": 13076,
      "ty": 41,
      "x": 48213,
      "y": 59135,
      "ta": "#.strategy > p"
    },
    {
      "t": 14274,
      "e": 13095,
      "ty": 3,
      "x": 526,
      "y": 520,
      "ta": "#.strategy > p"
    },
    {
      "t": 14379,
      "e": 13200,
      "ty": 4,
      "x": 48213,
      "y": 59135,
      "ta": "#.strategy > p"
    },
    {
      "t": 14379,
      "e": 13200,
      "ty": 5,
      "x": 526,
      "y": 520,
      "ta": "#.strategy > p"
    },
    {
      "t": 14892,
      "e": 13713,
      "ty": 6,
      "x": 526,
      "y": 522,
      "ta": "#strategyAnswer"
    },
    {
      "t": 14904,
      "e": 13725,
      "ty": 2,
      "x": 526,
      "y": 522
    },
    {
      "t": 15005,
      "e": 13826,
      "ty": 2,
      "x": 524,
      "y": 531
    },
    {
      "t": 15005,
      "e": 13826,
      "ty": 41,
      "x": 47988,
      "y": 6687,
      "ta": "#strategyAnswer"
    },
    {
      "t": 15105,
      "e": 13926,
      "ty": 2,
      "x": 523,
      "y": 532
    },
    {
      "t": 15107,
      "e": 13928,
      "ty": 3,
      "x": 523,
      "y": 532,
      "ta": "#strategyAnswer"
    },
    {
      "t": 15109,
      "e": 13930,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 15186,
      "e": 14007,
      "ty": 4,
      "x": 47876,
      "y": 7496,
      "ta": "#strategyAnswer"
    },
    {
      "t": 15186,
      "e": 14007,
      "ty": 5,
      "x": 523,
      "y": 532,
      "ta": "#strategyAnswer"
    },
    {
      "t": 15255,
      "e": 14076,
      "ty": 41,
      "x": 47876,
      "y": 7496,
      "ta": "#strategyAnswer"
    },
    {
      "t": 17959,
      "e": 16780,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "16"
    },
    {
      "t": 18134,
      "e": 16955,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 18136,
      "e": 16957,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 18253,
      "e": 17074,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "79"
    },
    {
      "t": 18254,
      "e": 17075,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 18262,
      "e": 17083,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "TO"
    },
    {
      "t": 18277,
      "e": 17098,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "TO"
    },
    {
      "t": 18342,
      "e": 17163,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 18342,
      "e": 17163,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 18453,
      "e": 17274,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "TO "
    },
    {
      "t": 18518,
      "e": 17339,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "TO "
    },
    {
      "t": 18598,
      "e": 17419,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "68"
    },
    {
      "t": 18598,
      "e": 17419,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 18694,
      "e": 17515,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "TO d"
    },
    {
      "t": 18782,
      "e": 17603,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 18782,
      "e": 17603,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 18934,
      "e": 17755,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 18934,
      "e": 17755,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 18998,
      "e": 17819,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||et"
    },
    {
      "t": 19079,
      "e": 17900,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 19207,
      "e": 18028,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 19262,
      "e": 18083,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "TO de"
    },
    {
      "t": 19350,
      "e": 18171,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 19382,
      "e": 18203,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "TO d"
    },
    {
      "t": 19463,
      "e": 18284,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 19510,
      "e": 18331,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "TO "
    },
    {
      "t": 19606,
      "e": 18427,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 19630,
      "e": 18451,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "TO"
    },
    {
      "t": 19727,
      "e": 18548,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 19773,
      "e": 18594,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "T"
    },
    {
      "t": 20005,
      "e": 18826,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 20014,
      "e": 18835,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "79"
    },
    {
      "t": 20014,
      "e": 18835,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 20134,
      "e": 18955,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 20134,
      "e": 18955,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 20214,
      "e": 19035,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "To "
    },
    {
      "t": 20246,
      "e": 19067,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "To "
    },
    {
      "t": 20486,
      "e": 19307,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "68"
    },
    {
      "t": 20487,
      "e": 19308,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 20582,
      "e": 19403,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "To d"
    },
    {
      "t": 20678,
      "e": 19499,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 20679,
      "e": 19500,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 20805,
      "e": 19626,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "To de"
    },
    {
      "t": 20830,
      "e": 19651,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 20830,
      "e": 19651,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 20854,
      "e": 19675,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||et"
    },
    {
      "t": 20935,
      "e": 19756,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 21007,
      "e": 19828,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 21008,
      "e": 19829,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 21086,
      "e": 19907,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "82"
    },
    {
      "t": 21086,
      "e": 19907,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 21166,
      "e": 19987,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||er"
    },
    {
      "t": 21262,
      "e": 20083,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 21271,
      "e": 20092,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "77"
    },
    {
      "t": 21271,
      "e": 20092,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 21406,
      "e": 20227,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "To determ"
    },
    {
      "t": 21414,
      "e": 20235,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "73"
    },
    {
      "t": 21414,
      "e": 20235,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 21462,
      "e": 20283,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||mi"
    },
    {
      "t": 21582,
      "e": 20403,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "78"
    },
    {
      "t": 21582,
      "e": 20403,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 21614,
      "e": 20435,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||n"
    },
    {
      "t": 21662,
      "e": 20483,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 21662,
      "e": 20483,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 21694,
      "e": 20515,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||e"
    },
    {
      "t": 21807,
      "e": 20628,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "To determine"
    },
    {
      "t": 21814,
      "e": 20635,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 21863,
      "e": 20684,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 21865,
      "e": 20686,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 22006,
      "e": 20827,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "To determine "
    },
    {
      "t": 22007,
      "e": 20828,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 22095,
      "e": 20916,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 22095,
      "e": 20916,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 22205,
      "e": 21026,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "To determine t"
    },
    {
      "t": 22206,
      "e": 21027,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "72"
    },
    {
      "t": 22206,
      "e": 21027,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 22238,
      "e": 21059,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 22238,
      "e": 21059,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 22245,
      "e": 21066,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||the"
    },
    {
      "t": 22302,
      "e": 21123,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 22303,
      "e": 21124,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 22358,
      "e": 21179,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 22398,
      "e": 21219,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 22438,
      "e": 21259,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 22927,
      "e": 21748,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 22927,
      "e": 21748,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 23054,
      "e": 21875,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||e"
    },
    {
      "t": 23207,
      "e": 22028,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "86"
    },
    {
      "t": 23208,
      "e": 22029,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 23286,
      "e": 22107,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||v"
    },
    {
      "t": 23382,
      "e": 22203,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 23382,
      "e": 22203,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 23511,
      "e": 22332,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "78"
    },
    {
      "t": 23511,
      "e": 22332,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 23566,
      "e": 22387,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 23566,
      "e": 22387,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 23590,
      "e": 22411,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||ent"
    },
    {
      "t": 23621,
      "e": 22442,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 23710,
      "e": 22531,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 24343,
      "e": 23164,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "16"
    },
    {
      "t": 24439,
      "e": 23260,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "57"
    },
    {
      "t": 24439,
      "e": 23260,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 24502,
      "e": 23323,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||("
    },
    {
      "t": 24566,
      "e": 23387,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 24566,
      "e": 23387,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "83"
    },
    {
      "t": 24566,
      "e": 23387,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 24686,
      "e": 23507,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "16"
    },
    {
      "t": 24695,
      "e": 23516,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||s"
    },
    {
      "t": 24759,
      "e": 23580,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "48"
    },
    {
      "t": 24760,
      "e": 23581,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 24813,
      "e": 23634,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||)"
    },
    {
      "t": 24926,
      "e": 23747,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 25135,
      "e": 23956,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 25135,
      "e": 23956,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 25245,
      "e": 24066,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 25342,
      "e": 24163,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 25343,
      "e": 24164,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 25405,
      "e": 24226,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "72"
    },
    {
      "t": 25406,
      "e": 24227,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 25469,
      "e": 24290,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||th"
    },
    {
      "t": 25470,
      "e": 24291,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 25471,
      "e": 24292,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 25542,
      "e": 24363,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 25542,
      "e": 24363,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 25550,
      "e": 24371,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||at"
    },
    {
      "t": 25566,
      "e": 24387,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 25566,
      "e": 24387,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 25607,
      "e": 24428,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 25686,
      "e": 24507,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 25727,
      "e": 24548,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 25735,
      "e": 24556,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "83"
    },
    {
      "t": 25735,
      "e": 24556,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 25910,
      "e": 24731,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 25910,
      "e": 24731,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 25998,
      "e": 24819,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||st"
    },
    {
      "t": 26079,
      "e": 24900,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 26111,
      "e": 24932,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 26112,
      "e": 24933,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 26230,
      "e": 25051,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "82"
    },
    {
      "t": 26230,
      "e": 25051,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 26278,
      "e": 25099,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||ar"
    },
    {
      "t": 26399,
      "e": 25220,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 27246,
      "e": 26067,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 27248,
      "e": 26069,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 27390,
      "e": 26211,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 27853,
      "e": 26674,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 27854,
      "e": 26675,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 27950,
      "e": 26771,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 28030,
      "e": 26851,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 28031,
      "e": 26852,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 28126,
      "e": 26947,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 28126,
      "e": 26947,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 28181,
      "e": 27002,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||at"
    },
    {
      "t": 28238,
      "e": 27059,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 28239,
      "e": 27060,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 28261,
      "e": 27082,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 28334,
      "e": 27155,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 30004,
      "e": 28825,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 30053,
      "e": 28874,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 30206,
      "e": 29027,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "To determine the event(s) that start at"
    },
    {
      "t": 30554,
      "e": 29375,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 30586,
      "e": 29407,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 30619,
      "e": 29440,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 30652,
      "e": 29473,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 30685,
      "e": 29506,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 30718,
      "e": 29539,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 30750,
      "e": 29571,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 30784,
      "e": 29605,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 30817,
      "e": 29638,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 30850,
      "e": 29671,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 30882,
      "e": 29703,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 30916,
      "e": 29737,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 30948,
      "e": 29769,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 30982,
      "e": 29803,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 31015,
      "e": 29836,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 31048,
      "e": 29869,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 31081,
      "e": 29902,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 31086,
      "e": 29907,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "To determine the event"
    },
    {
      "t": 31207,
      "e": 30028,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "To determine the event"
    },
    {
      "t": 31550,
      "e": 30371,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 31661,
      "e": 30482,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "To determine the even"
    },
    {
      "t": 32183,
      "e": 31004,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 32183,
      "e": 31004,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 32293,
      "e": 31114,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "83"
    },
    {
      "t": 32293,
      "e": 31114,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 32366,
      "e": 31187,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||ts"
    },
    {
      "t": 32446,
      "e": 31267,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 32455,
      "e": 31276,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 32455,
      "e": 31276,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 32566,
      "e": 31387,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 32589,
      "e": 31410,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "83"
    },
    {
      "t": 32590,
      "e": 31411,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 32774,
      "e": 31595,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 32776,
      "e": 31597,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 32942,
      "e": 31763,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||st"
    },
    {
      "t": 32957,
      "e": 31778,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 33110,
      "e": 31931,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 33166,
      "e": 31987,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "To determine the events s"
    },
    {
      "t": 33238,
      "e": 32059,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 33326,
      "e": 32147,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "To determine the events "
    },
    {
      "t": 33350,
      "e": 32171,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 33350,
      "e": 32171,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 33446,
      "e": 32267,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "72"
    },
    {
      "t": 33447,
      "e": 32268,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 33461,
      "e": 32282,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||th"
    },
    {
      "t": 33510,
      "e": 32331,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 33510,
      "e": 32331,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 33565,
      "e": 32386,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||a"
    },
    {
      "t": 33565,
      "e": 32386,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 33565,
      "e": 32386,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 33614,
      "e": 32435,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 33614,
      "e": 32435,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 33629,
      "e": 32450,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t "
    },
    {
      "t": 33701,
      "e": 32522,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 33742,
      "e": 32563,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 33766,
      "e": 32587,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "83"
    },
    {
      "t": 33767,
      "e": 32588,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 33861,
      "e": 32682,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 33861,
      "e": 32682,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 33918,
      "e": 32739,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||st"
    },
    {
      "t": 33983,
      "e": 32804,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 33998,
      "e": 32819,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 34000,
      "e": 32821,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 34110,
      "e": 32931,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "82"
    },
    {
      "t": 34110,
      "e": 32931,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 34157,
      "e": 32978,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||ar"
    },
    {
      "t": 34229,
      "e": 33050,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 34310,
      "e": 33131,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 34310,
      "e": 33131,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 34414,
      "e": 33235,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 34461,
      "e": 33282,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 34462,
      "e": 33283,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 34550,
      "e": 33371,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 34581,
      "e": 33402,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 34582,
      "e": 33403,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 34686,
      "e": 33507,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 34687,
      "e": 33508,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 34741,
      "e": 33562,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||at"
    },
    {
      "t": 34798,
      "e": 33619,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 34798,
      "e": 33619,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 34837,
      "e": 33658,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 34894,
      "e": 33715,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 35431,
      "e": 34252,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "49"
    },
    {
      "t": 35431,
      "e": 34252,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 35558,
      "e": 34379,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||1"
    },
    {
      "t": 35623,
      "e": 34444,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "50"
    },
    {
      "t": 35623,
      "e": 34444,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 35726,
      "e": 34547,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||2"
    },
    {
      "t": 35757,
      "e": 34578,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 35758,
      "e": 34579,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 35902,
      "e": 34723,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 35975,
      "e": 34796,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "80"
    },
    {
      "t": 35975,
      "e": 34796,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 36110,
      "e": 34931,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "77"
    },
    {
      "t": 36110,
      "e": 34931,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 36173,
      "e": 34994,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||pm"
    },
    {
      "t": 36214,
      "e": 35035,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 36374,
      "e": 35195,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "188"
    },
    {
      "t": 36375,
      "e": 35196,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 36469,
      "e": 35290,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 36470,
      "e": 35291,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 36518,
      "e": 35339,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||, "
    },
    {
      "t": 36590,
      "e": 35411,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 39254,
      "e": 38075,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "89"
    },
    {
      "t": 39256,
      "e": 38077,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 39334,
      "e": 38155,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||y"
    },
    {
      "t": 39413,
      "e": 38234,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "79"
    },
    {
      "t": 39414,
      "e": 38235,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 39494,
      "e": 38315,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "85"
    },
    {
      "t": 39495,
      "e": 38316,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 39597,
      "e": 38418,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 39598,
      "e": 38419,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 39606,
      "e": 38420,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||ou "
    },
    {
      "t": 39663,
      "e": 38477,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 39742,
      "e": 38556,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 39749,
      "e": 38563,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "78"
    },
    {
      "t": 39750,
      "e": 38564,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 39879,
      "e": 38693,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||n"
    },
    {
      "t": 39894,
      "e": 38708,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 39895,
      "e": 38709,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 40007,
      "e": 38821,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "To determine the events that start at 12 pm, you ne"
    },
    {
      "t": 40094,
      "e": 38908,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||e"
    },
    {
      "t": 40445,
      "e": 39259,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 40493,
      "e": 39307,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "To determine the events that start at 12 pm, you n"
    },
    {
      "t": 40606,
      "e": 39420,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 40653,
      "e": 39467,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "To determine the events that start at 12 pm, you "
    },
    {
      "t": 40734,
      "e": 39548,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 40790,
      "e": 39604,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "To determine the events that start at 12 pm, you"
    },
    {
      "t": 40879,
      "e": 39693,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 40933,
      "e": 39747,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "To determine the events that start at 12 pm, yo"
    },
    {
      "t": 41021,
      "e": 39835,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 41078,
      "e": 39892,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "To determine the events that start at 12 pm, y"
    },
    {
      "t": 41166,
      "e": 39980,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 41230,
      "e": 40044,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "To determine the events that start at 12 pm, "
    },
    {
      "t": 42654,
      "e": 41468,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "79"
    },
    {
      "t": 42654,
      "e": 41468,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 42807,
      "e": 41621,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "To determine the events that start at 12 pm, o"
    },
    {
      "t": 42814,
      "e": 41628,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||o"
    },
    {
      "t": 43094,
      "e": 41908,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 43173,
      "e": 41987,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "To determine the events that start at 12 pm, "
    },
    {
      "t": 44088,
      "e": 42902,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "89"
    },
    {
      "t": 44089,
      "e": 42903,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 44165,
      "e": 42979,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||y"
    },
    {
      "t": 44302,
      "e": 43116,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "79"
    },
    {
      "t": 44303,
      "e": 43117,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 44366,
      "e": 43180,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "85"
    },
    {
      "t": 44366,
      "e": 43180,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 44445,
      "e": 43259,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 44445,
      "e": 43259,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 44453,
      "e": 43267,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||ou "
    },
    {
      "t": 44525,
      "e": 43339,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 44582,
      "e": 43396,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 44671,
      "e": 43485,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "77"
    },
    {
      "t": 44671,
      "e": 43485,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 44781,
      "e": 43595,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||m"
    },
    {
      "t": 44878,
      "e": 43692,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "85"
    },
    {
      "t": 44879,
      "e": 43693,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 44965,
      "e": 43779,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "83"
    },
    {
      "t": 44966,
      "e": 43780,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 44981,
      "e": 43795,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||us"
    },
    {
      "t": 45037,
      "e": 43851,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 45038,
      "e": 43852,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 45085,
      "e": 43899,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 45110,
      "e": 43924,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 45110,
      "e": 43924,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 45149,
      "e": 43963,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 45205,
      "e": 44019,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 45262,
      "e": 44076,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "70"
    },
    {
      "t": 45262,
      "e": 44076,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 45374,
      "e": 44188,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||f"
    },
    {
      "t": 45382,
      "e": 44196,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "73"
    },
    {
      "t": 45383,
      "e": 44197,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 45493,
      "e": 44307,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||i"
    },
    {
      "t": 45517,
      "e": 44331,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "82"
    },
    {
      "t": 45519,
      "e": 44333,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 45662,
      "e": 44476,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||r"
    },
    {
      "t": 45710,
      "e": 44524,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "83"
    },
    {
      "t": 45711,
      "e": 44525,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 45773,
      "e": 44587,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 45773,
      "e": 44587,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 45829,
      "e": 44643,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 45829,
      "e": 44643,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 45837,
      "e": 44651,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||st "
    },
    {
      "t": 45909,
      "e": 44723,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 45933,
      "e": 44747,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 45934,
      "e": 44748,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "76"
    },
    {
      "t": 45934,
      "e": 44748,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 46037,
      "e": 44851,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||l"
    },
    {
      "t": 46141,
      "e": 44955,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "79"
    },
    {
      "t": 46146,
      "e": 44958,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 46205,
      "e": 45017,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "67"
    },
    {
      "t": 46205,
      "e": 45017,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 46326,
      "e": 45138,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||oc"
    },
    {
      "t": 46333,
      "e": 45145,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 46333,
      "e": 45145,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 46341,
      "e": 45153,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||a"
    },
    {
      "t": 46517,
      "e": 45329,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 46517,
      "e": 45329,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 46525,
      "e": 45337,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 46686,
      "e": 45498,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 46686,
      "e": 45498,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 46718,
      "e": 45530,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||e"
    },
    {
      "t": 46839,
      "e": 45651,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 46958,
      "e": 45770,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 46959,
      "e": 45771,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 47061,
      "e": 45873,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 49230,
      "e": 48042,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "49"
    },
    {
      "t": 49231,
      "e": 48043,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 49365,
      "e": 48177,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||1"
    },
    {
      "t": 50590,
      "e": 49402,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "50"
    },
    {
      "t": 50590,
      "e": 49402,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 50710,
      "e": 49522,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||2"
    },
    {
      "t": 50822,
      "e": 49634,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 50823,
      "e": 49635,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 50981,
      "e": 49793,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "80"
    },
    {
      "t": 50982,
      "e": 49794,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 50989,
      "e": 49801,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| p"
    },
    {
      "t": 51062,
      "e": 49874,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "77"
    },
    {
      "t": 51062,
      "e": 49874,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 51133,
      "e": 49945,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||m"
    },
    {
      "t": 51157,
      "e": 49969,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 51157,
      "e": 49969,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 51205,
      "e": 50017,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 51318,
      "e": 50130,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "79"
    },
    {
      "t": 51319,
      "e": 50131,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 51326,
      "e": 50138,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||o"
    },
    {
      "t": 51381,
      "e": 50193,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "78"
    },
    {
      "t": 51381,
      "e": 50193,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 51445,
      "e": 50257,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||n"
    },
    {
      "t": 51469,
      "e": 50281,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 51469,
      "e": 50281,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 51526,
      "e": 50338,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 51565,
      "e": 50377,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 51566,
      "e": 50378,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 51573,
      "e": 50385,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 51686,
      "e": 50498,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "72"
    },
    {
      "t": 51687,
      "e": 50499,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 51693,
      "e": 50505,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||h"
    },
    {
      "t": 51701,
      "e": 50513,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 51702,
      "e": 50514,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 51733,
      "e": 50545,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 51734,
      "e": 50546,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 51782,
      "e": 50594,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||e "
    },
    {
      "t": 51783,
      "e": 50595,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 51870,
      "e": 50682,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 52878,
      "e": 51690,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "88"
    },
    {
      "t": 52879,
      "e": 51691,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 52974,
      "e": 51786,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||x"
    },
    {
      "t": 53045,
      "e": 51857,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 53045,
      "e": 51857,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 53142,
      "e": 51954,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 53542,
      "e": 52354,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 53645,
      "e": 52457,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "To determine the events that start at 12 pm, you must first locate 12 pm on the x"
    },
    {
      "t": 53685,
      "e": 52497,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "189"
    },
    {
      "t": 53686,
      "e": 52498,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 53797,
      "e": 52609,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||-"
    },
    {
      "t": 54062,
      "e": 52874,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 54063,
      "e": 52875,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 54173,
      "e": 52985,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||a"
    },
    {
      "t": 54759,
      "e": 53571,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "67"
    },
    {
      "t": 54759,
      "e": 53571,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 54829,
      "e": 53641,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||c"
    },
    {
      "t": 55070,
      "e": 53882,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 55125,
      "e": 53937,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "To determine the events that start at 12 pm, you must first locate 12 pm on the x-a"
    },
    {
      "t": 55165,
      "e": 53977,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "88"
    },
    {
      "t": 55166,
      "e": 53978,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 55253,
      "e": 54065,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||x"
    },
    {
      "t": 55277,
      "e": 54089,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "73"
    },
    {
      "t": 55278,
      "e": 54090,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 55382,
      "e": 54194,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||i"
    },
    {
      "t": 55421,
      "e": 54233,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "83"
    },
    {
      "t": 55421,
      "e": 54233,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 55541,
      "e": 54353,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||s"
    },
    {
      "t": 55677,
      "e": 54489,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "190"
    },
    {
      "t": 55678,
      "e": 54490,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 55782,
      "e": 54594,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||."
    },
    {
      "t": 55933,
      "e": 54745,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 55934,
      "e": 54746,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 56150,
      "e": 54962,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "16"
    },
    {
      "t": 56174,
      "e": 54986,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "79"
    },
    {
      "t": 56175,
      "e": 54987,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 56181,
      "e": 54993,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| O"
    },
    {
      "t": 56261,
      "e": 55073,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 56422,
      "e": 55234,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "78"
    },
    {
      "t": 56423,
      "e": 55235,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 56462,
      "e": 55274,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||n"
    },
    {
      "t": 56542,
      "e": 55354,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "67"
    },
    {
      "t": 56543,
      "e": 55355,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 56581,
      "e": 55393,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||c"
    },
    {
      "t": 56677,
      "e": 55489,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 56677,
      "e": 55489,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 56725,
      "e": 55537,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||e"
    },
    {
      "t": 56749,
      "e": 55561,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 56750,
      "e": 55562,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 56797,
      "e": 55609,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 56877,
      "e": 55689,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 57013,
      "e": 55825,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "89"
    },
    {
      "t": 57015,
      "e": 55827,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 57100,
      "e": 55912,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||y"
    },
    {
      "t": 57190,
      "e": 55913,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "79"
    },
    {
      "t": 57191,
      "e": 55914,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 57278,
      "e": 56001,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "85"
    },
    {
      "t": 57278,
      "e": 56001,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 57341,
      "e": 56064,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||ou"
    },
    {
      "t": 57349,
      "e": 56072,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 57349,
      "e": 56072,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 57421,
      "e": 56144,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 57526,
      "e": 56249,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 57576,
      "e": 56299,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "70"
    },
    {
      "t": 57576,
      "e": 56299,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 57685,
      "e": 56408,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||f"
    },
    {
      "t": 57726,
      "e": 56449,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "73"
    },
    {
      "t": 57726,
      "e": 56449,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 57789,
      "e": 56512,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "78"
    },
    {
      "t": 57790,
      "e": 56513,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 57829,
      "e": 56552,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||in"
    },
    {
      "t": 57950,
      "e": 56673,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "68"
    },
    {
      "t": 57951,
      "e": 56674,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 57981,
      "e": 56704,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 57981,
      "e": 56704,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 58045,
      "e": 56768,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||d "
    },
    {
      "t": 58053,
      "e": 56776,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 58101,
      "e": 56824,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 58206,
      "e": 56929,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 58206,
      "e": 56929,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 58285,
      "e": 57008,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "72"
    },
    {
      "t": 58285,
      "e": 57008,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 58309,
      "e": 57032,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 58309,
      "e": 57032,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 58325,
      "e": 57048,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||the"
    },
    {
      "t": 58373,
      "e": 57096,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 58374,
      "e": 57097,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 58430,
      "e": 57153,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 58430,
      "e": 57153,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 58525,
      "e": 57248,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 65986,
      "e": 62248,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "76"
    },
    {
      "t": 65987,
      "e": 62249,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 66121,
      "e": 62383,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||l"
    },
    {
      "t": 66378,
      "e": 62640,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "79"
    },
    {
      "t": 66378,
      "e": 62640,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 66488,
      "e": 62750,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||o"
    },
    {
      "t": 66521,
      "e": 62783,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "67"
    },
    {
      "t": 66521,
      "e": 62783,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 66641,
      "e": 62903,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||c"
    },
    {
      "t": 66642,
      "e": 62904,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 66643,
      "e": 62905,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 66745,
      "e": 63007,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||a"
    },
    {
      "t": 66849,
      "e": 63111,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 66850,
      "e": 63112,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 66896,
      "e": 63158,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "73"
    },
    {
      "t": 66896,
      "e": 63158,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 66944,
      "e": 63206,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "79"
    },
    {
      "t": 66944,
      "e": 63206,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 66985,
      "e": 63247,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||tio"
    },
    {
      "t": 67065,
      "e": 63327,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "78"
    },
    {
      "t": 67065,
      "e": 63327,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 67137,
      "e": 63399,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||n"
    },
    {
      "t": 67154,
      "e": 63416,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 67154,
      "e": 63416,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 67185,
      "e": 63447,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 67273,
      "e": 63535,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 67273,
      "e": 63535,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "79"
    },
    {
      "t": 67273,
      "e": 63535,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 67305,
      "e": 63567,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||o"
    },
    {
      "t": 67376,
      "e": 63638,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "70"
    },
    {
      "t": 67377,
      "e": 63639,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 67385,
      "e": 63647,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 67385,
      "e": 63647,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 67441,
      "e": 63703,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||f "
    },
    {
      "t": 67472,
      "e": 63734,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 67497,
      "e": 63759,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 68265,
      "e": 64527,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "49"
    },
    {
      "t": 68266,
      "e": 64528,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 68329,
      "e": 64591,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "50"
    },
    {
      "t": 68330,
      "e": 64592,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 68408,
      "e": 64670,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||12"
    },
    {
      "t": 68464,
      "e": 64726,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 68504,
      "e": 64766,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 68506,
      "e": 64768,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 68611,
      "e": 64873,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "To determine the events that start at 12 pm, you must first locate 12 pm on the x-axis. Once you find the location of 12 "
    },
    {
      "t": 68641,
      "e": 64903,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 68721,
      "e": 64983,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "80"
    },
    {
      "t": 68722,
      "e": 64984,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 68848,
      "e": 65110,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "77"
    },
    {
      "t": 68849,
      "e": 65111,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 68904,
      "e": 65166,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||pm"
    },
    {
      "t": 68961,
      "e": 65223,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 68963,
      "e": 65225,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 69000,
      "e": 65262,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 69073,
      "e": 65335,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 69105,
      "e": 65367,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "79"
    },
    {
      "t": 69105,
      "e": 65367,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 69185,
      "e": 65447,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "78"
    },
    {
      "t": 69186,
      "e": 65448,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 69264,
      "e": 65526,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 69265,
      "e": 65527,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 69272,
      "e": 65534,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||on "
    },
    {
      "t": 69344,
      "e": 65606,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 69352,
      "e": 65614,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 69474,
      "e": 65736,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 69474,
      "e": 65736,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 69568,
      "e": 65830,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "72"
    },
    {
      "t": 69568,
      "e": 65830,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 69633,
      "e": 65895,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 69633,
      "e": 65895,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 69640,
      "e": 65902,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 69640,
      "e": 65902,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 69648,
      "e": 65910,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||the "
    },
    {
      "t": 69736,
      "e": 65998,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 69752,
      "e": 66014,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 69760,
      "e": 66022,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 70009,
      "e": 66271,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 70297,
      "e": 66559,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 70298,
      "e": 66560,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 70385,
      "e": 66647,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||e"
    },
    {
      "t": 70649,
      "e": 66911,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 70729,
      "e": 66991,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "To determine the events that start at 12 pm, you must first locate 12 pm on the x-axis. Once you find the location of 12 pm on the "
    },
    {
      "t": 70737,
      "e": 66999,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "88"
    },
    {
      "t": 70738,
      "e": 67000,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 70816,
      "e": 67078,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||x"
    },
    {
      "t": 70985,
      "e": 67247,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "189"
    },
    {
      "t": 70986,
      "e": 67248,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 71113,
      "e": 67375,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||-"
    },
    {
      "t": 71345,
      "e": 67607,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 71346,
      "e": 67608,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 71456,
      "e": 67718,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||a"
    },
    {
      "t": 71665,
      "e": 67927,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "88"
    },
    {
      "t": 71666,
      "e": 67928,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 71737,
      "e": 67999,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||x"
    },
    {
      "t": 71800,
      "e": 68062,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "73"
    },
    {
      "t": 71801,
      "e": 68063,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 71913,
      "e": 68175,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "83"
    },
    {
      "t": 71914,
      "e": 68176,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 71920,
      "e": 68182,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||is"
    },
    {
      "t": 72017,
      "e": 68279,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 72129,
      "e": 68391,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "188"
    },
    {
      "t": 72130,
      "e": 68392,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 72233,
      "e": 68495,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 72233,
      "e": 68495,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 72280,
      "e": 68542,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||, "
    },
    {
      "t": 72361,
      "e": 68623,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 73025,
      "e": 69287,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "89"
    },
    {
      "t": 73026,
      "e": 69288,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 73145,
      "e": 69407,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||y"
    },
    {
      "t": 73225,
      "e": 69487,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "79"
    },
    {
      "t": 73225,
      "e": 69487,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 73313,
      "e": 69575,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "85"
    },
    {
      "t": 73314,
      "e": 69576,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 73368,
      "e": 69630,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 73368,
      "e": 69630,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 73392,
      "e": 69654,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||ou "
    },
    {
      "t": 73464,
      "e": 69726,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 73505,
      "e": 69767,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 73729,
      "e": 69991,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "78"
    },
    {
      "t": 73730,
      "e": 69992,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 73824,
      "e": 70086,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||n"
    },
    {
      "t": 73840,
      "e": 70102,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 73841,
      "e": 70103,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 73880,
      "e": 70142,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||e"
    },
    {
      "t": 73937,
      "e": 70199,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 73937,
      "e": 70199,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 74017,
      "e": 70279,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||e"
    },
    {
      "t": 74385,
      "e": 70647,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 74433,
      "e": 70695,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "To determine the events that start at 12 pm, you must first locate 12 pm on the x-axis. Once you find the location of 12 pm on the x-axis, you ne"
    },
    {
      "t": 74521,
      "e": 70783,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 74584,
      "e": 70846,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "To determine the events that start at 12 pm, you must first locate 12 pm on the x-axis. Once you find the location of 12 pm on the x-axis, you n"
    },
    {
      "t": 74656,
      "e": 70918,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 74713,
      "e": 70975,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "To determine the events that start at 12 pm, you must first locate 12 pm on the x-axis. Once you find the location of 12 pm on the x-axis, you "
    },
    {
      "t": 74794,
      "e": 71056,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 74857,
      "e": 71057,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "To determine the events that start at 12 pm, you must first locate 12 pm on the x-axis. Once you find the location of 12 pm on the x-axis, you"
    },
    {
      "t": 74929,
      "e": 71129,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 75000,
      "e": 71200,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "To determine the events that start at 12 pm, you must first locate 12 pm on the x-axis. Once you find the location of 12 pm on the x-axis, yo"
    },
    {
      "t": 75065,
      "e": 71265,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 75137,
      "e": 71337,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "To determine the events that start at 12 pm, you must first locate 12 pm on the x-axis. Once you find the location of 12 pm on the x-axis, y"
    },
    {
      "t": 75225,
      "e": 71425,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 75321,
      "e": 71521,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "To determine the events that start at 12 pm, you must first locate 12 pm on the x-axis. Once you find the location of 12 pm on the x-axis, "
    },
    {
      "t": 75570,
      "e": 71770,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "76"
    },
    {
      "t": 75570,
      "e": 71770,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 75665,
      "e": 71865,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||l"
    },
    {
      "t": 75793,
      "e": 71993,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "79"
    },
    {
      "t": 75794,
      "e": 71994,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 75833,
      "e": 72033,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||o"
    },
    {
      "t": 75912,
      "e": 72112,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "79"
    },
    {
      "t": 75912,
      "e": 72112,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 75977,
      "e": 72177,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||o"
    },
    {
      "t": 76105,
      "e": 72305,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "75"
    },
    {
      "t": 76106,
      "e": 72306,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 76193,
      "e": 72393,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 76193,
      "e": 72393,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 76208,
      "e": 72408,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 76209,
      "e": 72409,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 76224,
      "e": 72424,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||k a"
    },
    {
      "t": 76265,
      "e": 72465,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 76289,
      "e": 72489,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 76289,
      "e": 72489,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 76328,
      "e": 72528,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 76385,
      "e": 72585,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 76481,
      "e": 72681,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 76482,
      "e": 72682,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 76561,
      "e": 72761,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 77153,
      "e": 73353,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 77176,
      "e": 73376,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "To determine the events that start at 12 pm, you must first locate 12 pm on the x-axis. Once you find the location of 12 pm on the x-axis, look at"
    },
    {
      "t": 77601,
      "e": 73801,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 77648,
      "e": 73801,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "To determine the events that start at 12 pm, you must first locate 12 pm on the x-axis. Once you find the location of 12 pm on the x-axis, look a"
    },
    {
      "t": 77842,
      "e": 73995,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 77920,
      "e": 74073,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "To determine the events that start at 12 pm, you must first locate 12 pm on the x-axis. Once you find the location of 12 pm on the x-axis, look "
    },
    {
      "t": 78129,
      "e": 74282,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "70"
    },
    {
      "t": 78129,
      "e": 74282,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 78184,
      "e": 74337,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "79"
    },
    {
      "t": 78185,
      "e": 74338,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 78240,
      "e": 74393,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||fo"
    },
    {
      "t": 78265,
      "e": 74418,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 78401,
      "e": 74554,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "76"
    },
    {
      "t": 78401,
      "e": 74554,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 78457,
      "e": 74610,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||l"
    },
    {
      "t": 78521,
      "e": 74674,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "76"
    },
    {
      "t": 78521,
      "e": 74674,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 78585,
      "e": 74738,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||l"
    },
    {
      "t": 78697,
      "e": 74850,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "79"
    },
    {
      "t": 78698,
      "e": 74851,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 78768,
      "e": 74921,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "87"
    },
    {
      "t": 78768,
      "e": 74921,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 78857,
      "e": 75010,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||ow"
    },
    {
      "t": 78872,
      "e": 75025,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 78913,
      "e": 75066,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 78913,
      "e": 75066,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 79033,
      "e": 75186,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 79097,
      "e": 75250,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 79098,
      "e": 75251,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 79168,
      "e": 75321,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "72"
    },
    {
      "t": 79168,
      "e": 75321,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 79200,
      "e": 75353,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||th"
    },
    {
      "t": 79265,
      "e": 75418,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 79265,
      "e": 75418,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 79272,
      "e": 75425,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 79272,
      "e": 75425,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 79337,
      "e": 75490,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||e "
    },
    {
      "t": 79368,
      "e": 75521,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 79401,
      "e": 75554,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 84185,
      "e": 80338,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "76"
    },
    {
      "t": 84186,
      "e": 80339,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 84344,
      "e": 80497,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "73"
    },
    {
      "t": 84345,
      "e": 80498,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 84368,
      "e": 80521,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||li"
    },
    {
      "t": 84457,
      "e": 80610,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "78"
    },
    {
      "t": 84458,
      "e": 80611,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 84512,
      "e": 80665,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||n"
    },
    {
      "t": 84536,
      "e": 80689,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 84536,
      "e": 80689,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 84625,
      "e": 80778,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||e"
    },
    {
      "t": 84640,
      "e": 80793,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 84641,
      "e": 80794,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 84648,
      "e": 80801,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 84793,
      "e": 80946,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 84841,
      "e": 80994,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "87"
    },
    {
      "t": 84842,
      "e": 80995,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 84928,
      "e": 81081,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "73"
    },
    {
      "t": 84928,
      "e": 81081,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 84976,
      "e": 81129,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||wi"
    },
    {
      "t": 85097,
      "e": 81250,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 85098,
      "e": 81251,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 85128,
      "e": 81281,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 85176,
      "e": 81329,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "72"
    },
    {
      "t": 85177,
      "e": 81330,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 85200,
      "e": 81353,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||h"
    },
    {
      "t": 85240,
      "e": 81393,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 85240,
      "e": 81393,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 85321,
      "e": 81474,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 85401,
      "e": 81554,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 85896,
      "e": 82049,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 85896,
      "e": 82049,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 85960,
      "e": 82113,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "72"
    },
    {
      "t": 85961,
      "e": 82114,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 86008,
      "e": 82161,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 86008,
      "e": 82161,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 86104,
      "e": 82257,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||the"
    },
    {
      "t": 86112,
      "e": 82265,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 86112,
      "e": 82265,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 86168,
      "e": 82321,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 86224,
      "e": 82377,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 86297,
      "e": 82450,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 86345,
      "e": 82498,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "80"
    },
    {
      "t": 86346,
      "e": 82499,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 86408,
      "e": 82561,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "79"
    },
    {
      "t": 86408,
      "e": 82561,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 86480,
      "e": 82633,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||po"
    },
    {
      "t": 86488,
      "e": 82641,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "83"
    },
    {
      "t": 86488,
      "e": 82641,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 86528,
      "e": 82681,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||s"
    },
    {
      "t": 86585,
      "e": 82738,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 86585,
      "e": 82738,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 86632,
      "e": 82785,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 86640,
      "e": 82793,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "73"
    },
    {
      "t": 86640,
      "e": 82793,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 86680,
      "e": 82833,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||i"
    },
    {
      "t": 86696,
      "e": 82849,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 86813,
      "e": 82851,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "To determine the events that start at 12 pm, you must first locate 12 pm on the x-axis. Once you find the location of 12 pm on the x-axis, look follow the line with the posti"
    },
    {
      "t": 86817,
      "e": 82855,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "73"
    },
    {
      "t": 86817,
      "e": 82855,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 86896,
      "e": 82934,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||i"
    },
    {
      "t": 87010,
      "e": 83048,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "To determine the events that start at 12 pm, you must first locate 12 pm on the x-axis. Once you find the location of 12 pm on the x-axis, look follow the line with the postii"
    },
    {
      "t": 87313,
      "e": 83351,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 87368,
      "e": 83406,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "To determine the events that start at 12 pm, you must first locate 12 pm on the x-axis. Once you find the location of 12 pm on the x-axis, look follow the line with the posti"
    },
    {
      "t": 87416,
      "e": 83454,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 87417,
      "e": 83455,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 87505,
      "e": 83543,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "73"
    },
    {
      "t": 87505,
      "e": 83543,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 87512,
      "e": 83550,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||ti"
    },
    {
      "t": 87617,
      "e": 83655,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 87625,
      "e": 83663,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "86"
    },
    {
      "t": 87626,
      "e": 83664,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 87696,
      "e": 83734,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||v"
    },
    {
      "t": 87792,
      "e": 83830,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 87793,
      "e": 83831,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 87872,
      "e": 83910,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||e"
    },
    {
      "t": 87880,
      "e": 83918,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 87880,
      "e": 83918,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 88010,
      "e": 84048,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "To determine the events that start at 12 pm, you must first locate 12 pm on the x-axis. Once you find the location of 12 pm on the x-axis, look follow the line with the postitive "
    },
    {
      "t": 88041,
      "e": 84079,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "83"
    },
    {
      "t": 88041,
      "e": 84079,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 88048,
      "e": 84086,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| s"
    },
    {
      "t": 88120,
      "e": 84158,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "76"
    },
    {
      "t": 88120,
      "e": 84158,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 88128,
      "e": 84166,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||l"
    },
    {
      "t": 88209,
      "e": 84247,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 88346,
      "e": 84384,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "79"
    },
    {
      "t": 88347,
      "e": 84385,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 88416,
      "e": 84454,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||o"
    },
    {
      "t": 88641,
      "e": 84679,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 88811,
      "e": 84680,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "To determine the events that start at 12 pm, you must first locate 12 pm on the x-axis. Once you find the location of 12 pm on the x-axis, look follow the line with the postitive sl"
    },
    {
      "t": 88937,
      "e": 84806,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "To determine the events that start at 12 pm, you must first locate 12 pm on the x-axis. Once you find the location of 12 pm on the x-axis, look follow the line with the postitive sl"
    },
    {
      "t": 89568,
      "e": 85437,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 90069,
      "e": 85938,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 90100,
      "e": 85969,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 90135,
      "e": 86004,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 90167,
      "e": 86036,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 90199,
      "e": 86068,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 90232,
      "e": 86101,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "To determine the events that start at 12 pm, you must first locate 12 pm on the x-axis. Once you find the location of 12 pm on the x-axis, look follow the line with the postit"
    },
    {
      "t": 90352,
      "e": 86221,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 90424,
      "e": 86293,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "To determine the events that start at 12 pm, you must first locate 12 pm on the x-axis. Once you find the location of 12 pm on the x-axis, look follow the line with the posti"
    },
    {
      "t": 90512,
      "e": 86381,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 90576,
      "e": 86445,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "To determine the events that start at 12 pm, you must first locate 12 pm on the x-axis. Once you find the location of 12 pm on the x-axis, look follow the line with the post"
    },
    {
      "t": 90649,
      "e": 86518,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 90744,
      "e": 86519,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "To determine the events that start at 12 pm, you must first locate 12 pm on the x-axis. Once you find the location of 12 pm on the x-axis, look follow the line with the pos"
    },
    {
      "t": 90984,
      "e": 86759,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "73"
    },
    {
      "t": 90985,
      "e": 86760,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 91064,
      "e": 86839,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||i"
    },
    {
      "t": 91088,
      "e": 86863,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 91088,
      "e": 86863,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 91161,
      "e": 86936,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "73"
    },
    {
      "t": 91161,
      "e": 86936,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 91176,
      "e": 86951,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||ti"
    },
    {
      "t": 91256,
      "e": 87031,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 91312,
      "e": 87087,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "86"
    },
    {
      "t": 91313,
      "e": 87088,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 91401,
      "e": 87176,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||v"
    },
    {
      "t": 91496,
      "e": 87271,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 91497,
      "e": 87272,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 91544,
      "e": 87319,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||e"
    },
    {
      "t": 91888,
      "e": 87663,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 91889,
      "e": 87664,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 91985,
      "e": 87760,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 92081,
      "e": 87856,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "83"
    },
    {
      "t": 92081,
      "e": 87856,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 92201,
      "e": 87976,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "76"
    },
    {
      "t": 92202,
      "e": 87977,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 92224,
      "e": 87999,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||sl"
    },
    {
      "t": 92272,
      "e": 88047,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 92408,
      "e": 88183,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "79"
    },
    {
      "t": 92409,
      "e": 88184,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 92480,
      "e": 88255,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||o"
    },
    {
      "t": 92584,
      "e": 88359,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "80"
    },
    {
      "t": 92585,
      "e": 88360,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 92664,
      "e": 88439,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 92664,
      "e": 88439,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 92712,
      "e": 88487,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||p "
    },
    {
      "t": 92768,
      "e": 88543,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 92873,
      "e": 88648,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 92874,
      "e": 88649,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 92952,
      "e": 88727,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "72"
    },
    {
      "t": 92952,
      "e": 88727,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 92976,
      "e": 88751,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||th"
    },
    {
      "t": 93000,
      "e": 88775,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 93000,
      "e": 88775,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 93072,
      "e": 88847,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 93073,
      "e": 88848,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 93088,
      "e": 88863,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||at"
    },
    {
      "t": 93104,
      "e": 88879,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 93104,
      "e": 88879,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 93144,
      "e": 88919,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 93217,
      "e": 88992,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 93224,
      "e": 88999,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 93889,
      "e": 89664,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 93936,
      "e": 89711,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "To determine the events that start at 12 pm, you must first locate 12 pm on the x-axis. Once you find the location of 12 pm on the x-axis, look follow the line with the positive slop that"
    },
    {
      "t": 94008,
      "e": 89783,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 94080,
      "e": 89855,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "To determine the events that start at 12 pm, you must first locate 12 pm on the x-axis. Once you find the location of 12 pm on the x-axis, look follow the line with the positive slop tha"
    },
    {
      "t": 94152,
      "e": 89927,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 94225,
      "e": 89927,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "To determine the events that start at 12 pm, you must first locate 12 pm on the x-axis. Once you find the location of 12 pm on the x-axis, look follow the line with the positive slop th"
    },
    {
      "t": 94288,
      "e": 89990,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 94376,
      "e": 90078,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "To determine the events that start at 12 pm, you must first locate 12 pm on the x-axis. Once you find the location of 12 pm on the x-axis, look follow the line with the positive slop t"
    },
    {
      "t": 94416,
      "e": 90118,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 94504,
      "e": 90206,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "To determine the events that start at 12 pm, you must first locate 12 pm on the x-axis. Once you find the location of 12 pm on the x-axis, look follow the line with the positive slop "
    },
    {
      "t": 94600,
      "e": 90302,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 94776,
      "e": 90478,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "To determine the events that start at 12 pm, you must first locate 12 pm on the x-axis. Once you find the location of 12 pm on the x-axis, look follow the line with the positive slop"
    },
    {
      "t": 94849,
      "e": 90551,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 94850,
      "e": 90552,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 94944,
      "e": 90646,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||e"
    },
    {
      "t": 94959,
      "e": 90661,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 94960,
      "e": 90662,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 95016,
      "e": 90718,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 95424,
      "e": 91126,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 95425,
      "e": 91127,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 95520,
      "e": 91222,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 95560,
      "e": 91262,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 95560,
      "e": 91262,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 95568,
      "e": 91270,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "72"
    },
    {
      "t": 95568,
      "e": 91270,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 95673,
      "e": 91375,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 95674,
      "e": 91376,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 95687,
      "e": 91389,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||aht"
    },
    {
      "t": 95704,
      "e": 91406,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 95704,
      "e": 91406,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 95711,
      "e": 91413,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 95792,
      "e": 91494,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 95816,
      "e": 91518,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 95904,
      "e": 91606,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "83"
    },
    {
      "t": 95905,
      "e": 91607,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 96010,
      "e": 91607,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "To determine the events that start at 12 pm, you must first locate 12 pm on the x-axis. Once you find the location of 12 pm on the x-axis, look follow the line with the positive slope taht s"
    },
    {
      "t": 96040,
      "e": 91637,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||s"
    },
    {
      "t": 96201,
      "e": 91798,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 96216,
      "e": 91813,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "To determine the events that start at 12 pm, you must first locate 12 pm on the x-axis. Once you find the location of 12 pm on the x-axis, look follow the line with the positive slope taht "
    },
    {
      "t": 96312,
      "e": 91909,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 96368,
      "e": 91965,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "To determine the events that start at 12 pm, you must first locate 12 pm on the x-axis. Once you find the location of 12 pm on the x-axis, look follow the line with the positive slope taht"
    },
    {
      "t": 96440,
      "e": 92037,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 96512,
      "e": 92109,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "To determine the events that start at 12 pm, you must first locate 12 pm on the x-axis. Once you find the location of 12 pm on the x-axis, look follow the line with the positive slope tah"
    },
    {
      "t": 96576,
      "e": 92173,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 96641,
      "e": 92174,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "To determine the events that start at 12 pm, you must first locate 12 pm on the x-axis. Once you find the location of 12 pm on the x-axis, look follow the line with the positive slope ta"
    },
    {
      "t": 96729,
      "e": 92262,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 96776,
      "e": 92309,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "To determine the events that start at 12 pm, you must first locate 12 pm on the x-axis. Once you find the location of 12 pm on the x-axis, look follow the line with the positive slope t"
    },
    {
      "t": 96928,
      "e": 92461,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "72"
    },
    {
      "t": 96928,
      "e": 92461,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 96993,
      "e": 92526,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 96993,
      "e": 92526,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 97063,
      "e": 92596,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 97064,
      "e": 92597,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 97071,
      "e": 92604,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||hat"
    },
    {
      "t": 97096,
      "e": 92629,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 97136,
      "e": 92669,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 97136,
      "e": 92669,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 97176,
      "e": 92709,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 97256,
      "e": 92789,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 97401,
      "e": 92934,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "83"
    },
    {
      "t": 97401,
      "e": 92934,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 97560,
      "e": 93093,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||s"
    },
    {
      "t": 97728,
      "e": 93261,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 97730,
      "e": 93263,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 97840,
      "e": 93373,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 97840,
      "e": 93373,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 97856,
      "e": 93389,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||te"
    },
    {
      "t": 97961,
      "e": 93494,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 97969,
      "e": 93502,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "77"
    },
    {
      "t": 97969,
      "e": 93502,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 98072,
      "e": 93605,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "83"
    },
    {
      "t": 98076,
      "e": 93609,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 98104,
      "e": 93637,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||ms"
    },
    {
      "t": 98168,
      "e": 93701,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 98168,
      "e": 93701,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 98175,
      "e": 93708,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 98312,
      "e": 93845,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 98328,
      "e": 93861,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "79"
    },
    {
      "t": 98329,
      "e": 93862,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 98409,
      "e": 93942,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "78"
    },
    {
      "t": 98409,
      "e": 93942,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 98480,
      "e": 94013,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 98480,
      "e": 94013,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 98512,
      "e": 94045,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||on "
    },
    {
      "t": 98576,
      "e": 94109,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 98615,
      "e": 94148,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 98848,
      "e": 94381,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 98888,
      "e": 94421,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "To determine the events that start at 12 pm, you must first locate 12 pm on the x-axis. Once you find the location of 12 pm on the x-axis, look follow the line with the positive slope that stems on"
    },
    {
      "t": 98984,
      "e": 94517,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 99066,
      "e": 94519,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "To determine the events that start at 12 pm, you must first locate 12 pm on the x-axis. Once you find the location of 12 pm on the x-axis, look follow the line with the positive slope that stems o"
    },
    {
      "t": 99224,
      "e": 94677,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "85"
    },
    {
      "t": 99224,
      "e": 94677,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 99305,
      "e": 94758,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 99305,
      "e": 94758,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 99360,
      "e": 94813,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 99360,
      "e": 94813,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 99367,
      "e": 94820,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||ut "
    },
    {
      "t": 99392,
      "e": 94845,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 99480,
      "e": 94933,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 99536,
      "e": 94989,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "70"
    },
    {
      "t": 99537,
      "e": 94990,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 99592,
      "e": 95045,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||f"
    },
    {
      "t": 99680,
      "e": 95133,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "82"
    },
    {
      "t": 99680,
      "e": 95133,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 99752,
      "e": 95205,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "79"
    },
    {
      "t": 99753,
      "e": 95206,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 99775,
      "e": 95228,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||ro"
    },
    {
      "t": 99807,
      "e": 95260,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "77"
    },
    {
      "t": 99808,
      "e": 95261,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 99912,
      "e": 95365,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 99912,
      "e": 95365,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 99920,
      "e": 95373,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||m "
    },
    {
      "t": 99968,
      "e": 95421,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 100009,
      "e": 95462,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 101040,
      "e": 96493,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 101040,
      "e": 96493,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 101145,
      "e": 96598,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 101161,
      "e": 96614,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "72"
    },
    {
      "t": 101162,
      "e": 96615,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 101225,
      "e": 96678,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 101225,
      "e": 96678,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 101288,
      "e": 96741,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 101288,
      "e": 96741,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 101296,
      "e": 96749,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||he "
    },
    {
      "t": 101328,
      "e": 96781,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 101441,
      "e": 96894,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 101513,
      "e": 96966,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "49"
    },
    {
      "t": 101513,
      "e": 96966,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 101608,
      "e": 97061,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "50"
    },
    {
      "t": 101608,
      "e": 97061,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 101704,
      "e": 97157,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||12"
    },
    {
      "t": 101728,
      "e": 97181,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 101928,
      "e": 97381,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "80"
    },
    {
      "t": 101929,
      "e": 97382,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 102064,
      "e": 97517,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||p"
    },
    {
      "t": 102664,
      "e": 98117,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 102768,
      "e": 98221,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "To determine the events that start at 12 pm, you must first locate 12 pm on the x-axis. Once you find the location of 12 pm on the x-axis, look follow the line with the positive slope that stems out from the 12"
    },
    {
      "t": 102968,
      "e": 98421,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 102969,
      "e": 98422,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 103128,
      "e": 98581,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "79"
    },
    {
      "t": 103128,
      "e": 98581,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 103135,
      "e": 98588,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| o"
    },
    {
      "t": 103152,
      "e": 98605,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "80"
    },
    {
      "t": 103153,
      "e": 98606,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 103216,
      "e": 98669,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "77"
    },
    {
      "t": 103216,
      "e": 98669,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 103232,
      "e": 98685,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||pm"
    },
    {
      "t": 103255,
      "e": 98708,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 103376,
      "e": 98829,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 103377,
      "e": 98830,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 103448,
      "e": 98901,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 103456,
      "e": 98909,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 103633,
      "e": 99086,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 103681,
      "e": 99087,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "To determine the events that start at 12 pm, you must first locate 12 pm on the x-axis. Once you find the location of 12 pm on the x-axis, look follow the line with the positive slope that stems out from the 12 opm"
    },
    {
      "t": 103752,
      "e": 99158,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 103815,
      "e": 99221,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "To determine the events that start at 12 pm, you must first locate 12 pm on the x-axis. Once you find the location of 12 pm on the x-axis, look follow the line with the positive slope that stems out from the 12 op"
    },
    {
      "t": 103888,
      "e": 99294,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 103960,
      "e": 99366,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "To determine the events that start at 12 pm, you must first locate 12 pm on the x-axis. Once you find the location of 12 pm on the x-axis, look follow the line with the positive slope that stems out from the 12 o"
    },
    {
      "t": 104176,
      "e": 99582,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "80"
    },
    {
      "t": 104178,
      "e": 99584,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 104264,
      "e": 99670,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||p"
    },
    {
      "t": 104409,
      "e": 99815,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 104464,
      "e": 99870,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "To determine the events that start at 12 pm, you must first locate 12 pm on the x-axis. Once you find the location of 12 pm on the x-axis, look follow the line with the positive slope that stems out from the 12 o"
    },
    {
      "t": 104544,
      "e": 99950,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 104618,
      "e": 99952,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "To determine the events that start at 12 pm, you must first locate 12 pm on the x-axis. Once you find the location of 12 pm on the x-axis, look follow the line with the positive slope that stems out from the 12 "
    },
    {
      "t": 104705,
      "e": 100039,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "80"
    },
    {
      "t": 104705,
      "e": 100039,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 104783,
      "e": 100117,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||p"
    },
    {
      "t": 104839,
      "e": 100173,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "77"
    },
    {
      "t": 104839,
      "e": 100173,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 104976,
      "e": 100310,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 104977,
      "e": 100311,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 105032,
      "e": 100366,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||m "
    },
    {
      "t": 105127,
      "e": 100461,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 105144,
      "e": 100478,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "77"
    },
    {
      "t": 105144,
      "e": 100478,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 105248,
      "e": 100582,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||m"
    },
    {
      "t": 105264,
      "e": 100598,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 105265,
      "e": 100599,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 105344,
      "e": 100678,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "82"
    },
    {
      "t": 105344,
      "e": 100678,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 105384,
      "e": 100718,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||ar"
    },
    {
      "t": 105432,
      "e": 100766,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "75"
    },
    {
      "t": 105432,
      "e": 100766,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 105472,
      "e": 100806,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||k"
    },
    {
      "t": 105544,
      "e": 100878,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 105729,
      "e": 101063,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "190"
    },
    {
      "t": 105729,
      "e": 101063,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 105800,
      "e": 101134,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||."
    },
    {
      "t": 106009,
      "e": 101343,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "188"
    },
    {
      "t": 106009,
      "e": 101343,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 106055,
      "e": 101389,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||,"
    },
    {
      "t": 106513,
      "e": 101847,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 106568,
      "e": 101902,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "To determine the events that start at 12 pm, you must first locate 12 pm on the x-axis. Once you find the location of 12 pm on the x-axis, look follow the line with the positive slope that stems out from the 12 pm mark."
    },
    {
      "t": 106648,
      "e": 101982,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 106648,
      "e": 101982,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 106752,
      "e": 102086,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 110008,
      "e": 105342,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 110417,
      "e": 105751,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "16"
    },
    {
      "t": 110505,
      "e": 105839,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 110505,
      "e": 105839,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 110607,
      "e": 105941,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||E"
    },
    {
      "t": 110616,
      "e": 105950,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 110864,
      "e": 106198,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "86"
    },
    {
      "t": 110865,
      "e": 106199,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 110960,
      "e": 106294,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||v"
    },
    {
      "t": 111057,
      "e": 106391,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 111057,
      "e": 106391,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 111210,
      "e": 106544,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "To determine the events that start at 12 pm, you must first locate 12 pm on the x-axis. Once you find the location of 12 pm on the x-axis, look follow the line with the positive slope that stems out from the 12 pm mark. Eve"
    },
    {
      "t": 111240,
      "e": 106574,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "82"
    },
    {
      "t": 111240,
      "e": 106574,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 111304,
      "e": 106638,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||er"
    },
    {
      "t": 111352,
      "e": 106686,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 111441,
      "e": 106775,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "89"
    },
    {
      "t": 111441,
      "e": 106775,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 111551,
      "e": 106885,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||y"
    },
    {
      "t": 111968,
      "e": 107302,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 111969,
      "e": 107303,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 112080,
      "e": 107414,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 112184,
      "e": 107518,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "83"
    },
    {
      "t": 112185,
      "e": 107519,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 112288,
      "e": 107622,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "72"
    },
    {
      "t": 112289,
      "e": 107623,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 112320,
      "e": 107654,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||sh"
    },
    {
      "t": 112384,
      "e": 107718,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "73"
    },
    {
      "t": 112385,
      "e": 107719,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 112464,
      "e": 107798,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||i"
    },
    {
      "t": 112464,
      "e": 107798,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "70"
    },
    {
      "t": 112464,
      "e": 107798,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 112535,
      "e": 107869,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||f"
    },
    {
      "t": 112544,
      "e": 107878,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 112648,
      "e": 107982,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 112649,
      "e": 107983,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 112768,
      "e": 108102,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 112769,
      "e": 108103,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 112784,
      "e": 108118,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t "
    },
    {
      "t": 112873,
      "e": 108207,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 114416,
      "e": 109750,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 114418,
      "e": 109752,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 114569,
      "e": 109903,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 114728,
      "e": 110062,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "72"
    },
    {
      "t": 114729,
      "e": 110063,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 114791,
      "e": 110125,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 114791,
      "e": 110125,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 114824,
      "e": 110158,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||ha"
    },
    {
      "t": 114856,
      "e": 110190,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 114856,
      "e": 110190,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 114944,
      "e": 110278,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 114976,
      "e": 110310,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 114976,
      "e": 110310,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 114999,
      "e": 110333,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 115111,
      "e": 110445,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 115192,
      "e": 110526,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "73"
    },
    {
      "t": 115193,
      "e": 110527,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 115231,
      "e": 110565,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "83"
    },
    {
      "t": 115231,
      "e": 110565,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 115303,
      "e": 110637,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 115303,
      "e": 110637,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 115312,
      "e": 110646,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||is "
    },
    {
      "t": 115320,
      "e": 110654,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 115392,
      "e": 110726,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 115392,
      "e": 110726,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 115416,
      "e": 110750,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||a"
    },
    {
      "t": 115512,
      "e": 110846,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 115520,
      "e": 110854,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "76"
    },
    {
      "t": 115521,
      "e": 110855,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 115607,
      "e": 110941,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||l"
    },
    {
      "t": 115719,
      "e": 111053,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "79"
    },
    {
      "t": 115719,
      "e": 111053,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 115792,
      "e": 111126,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "78"
    },
    {
      "t": 115792,
      "e": 111126,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 115872,
      "e": 111206,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "71"
    },
    {
      "t": 115872,
      "e": 111206,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 115880,
      "e": 111214,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||ong"
    },
    {
      "t": 115935,
      "e": 111269,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 115935,
      "e": 111269,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 115943,
      "e": 111277,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 115976,
      "e": 111310,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 116047,
      "e": 111381,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 116055,
      "e": 111389,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 116056,
      "e": 111390,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 116145,
      "e": 111479,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "72"
    },
    {
      "t": 116145,
      "e": 111479,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 116168,
      "e": 111502,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||th"
    },
    {
      "t": 116192,
      "e": 111526,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 116192,
      "e": 111526,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 116256,
      "e": 111590,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 116256,
      "e": 111590,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 116272,
      "e": 111606,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 116272,
      "e": 111606,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 116336,
      "e": 111670,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||a t"
    },
    {
      "t": 116344,
      "e": 111678,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 116384,
      "e": 111718,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 116392,
      "e": 111726,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 116432,
      "e": 111766,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "76"
    },
    {
      "t": 116432,
      "e": 111766,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 116520,
      "e": 111854,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "73"
    },
    {
      "t": 116520,
      "e": 111854,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 116616,
      "e": 111950,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "78"
    },
    {
      "t": 116616,
      "e": 111950,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 116639,
      "e": 111973,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||lin"
    },
    {
      "t": 116687,
      "e": 112021,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 116735,
      "e": 112069,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 116898,
      "e": 112071,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 116944,
      "e": 112117,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "To determine the events that start at 12 pm, you must first locate 12 pm on the x-axis. Once you find the location of 12 pm on the x-axis, look follow the line with the positive slope that stems out from the 12 pm mark. Every shift that is along tha tli"
    },
    {
      "t": 117031,
      "e": 112204,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 117080,
      "e": 112253,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "To determine the events that start at 12 pm, you must first locate 12 pm on the x-axis. Once you find the location of 12 pm on the x-axis, look follow the line with the positive slope that stems out from the 12 pm mark. Every shift that is along tha tl"
    },
    {
      "t": 117161,
      "e": 112334,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 117215,
      "e": 112388,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "To determine the events that start at 12 pm, you must first locate 12 pm on the x-axis. Once you find the location of 12 pm on the x-axis, look follow the line with the positive slope that stems out from the 12 pm mark. Every shift that is along tha t"
    },
    {
      "t": 117288,
      "e": 112461,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 117359,
      "e": 112461,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "To determine the events that start at 12 pm, you must first locate 12 pm on the x-axis. Once you find the location of 12 pm on the x-axis, look follow the line with the positive slope that stems out from the 12 pm mark. Every shift that is along tha "
    },
    {
      "t": 117423,
      "e": 112525,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 117504,
      "e": 112606,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "To determine the events that start at 12 pm, you must first locate 12 pm on the x-axis. Once you find the location of 12 pm on the x-axis, look follow the line with the positive slope that stems out from the 12 pm mark. Every shift that is along tha"
    },
    {
      "t": 117612,
      "e": 112714,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "To determine the events that start at 12 pm, you must first locate 12 pm on the x-axis. Once you find the location of 12 pm on the x-axis, look follow the line with the positive slope that stems out from the 12 pm mark. Every shift that is along tha"
    },
    {
      "t": 117648,
      "e": 112750,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 117649,
      "e": 112751,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 117759,
      "e": 112861,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 117760,
      "e": 112862,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 117799,
      "e": 112901,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t "
    },
    {
      "t": 117928,
      "e": 113030,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 117952,
      "e": 113054,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 117953,
      "e": 113055,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 117960,
      "e": 113062,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "76"
    },
    {
      "t": 117960,
      "e": 113062,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 118000,
      "e": 113102,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| l"
    },
    {
      "t": 118055,
      "e": 113157,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "73"
    },
    {
      "t": 118056,
      "e": 113158,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 118184,
      "e": 113286,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||i"
    },
    {
      "t": 118200,
      "e": 113302,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "78"
    },
    {
      "t": 118201,
      "e": 113303,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 118287,
      "e": 113389,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 118288,
      "e": 113390,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 118304,
      "e": 113406,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||n "
    },
    {
      "t": 118328,
      "e": 113430,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 118423,
      "e": 113525,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 118648,
      "e": 113750,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 118695,
      "e": 113797,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 118696,
      "e": 113798,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 118720,
      "e": 113798,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "To determine the events that start at 12 pm, you must first locate 12 pm on the x-axis. Once you find the location of 12 pm on the x-axis, look follow the line with the positive slope that stems out from the 12 pm mark. Every shift that is along that  line"
    },
    {
      "t": 118767,
      "e": 113845,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 118767,
      "e": 113845,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 118808,
      "e": 113886,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 118896,
      "e": 113974,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 119048,
      "e": 114126,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 119103,
      "e": 114181,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "To determine the events that start at 12 pm, you must first locate 12 pm on the x-axis. Once you find the location of 12 pm on the x-axis, look follow the line with the positive slope that stems out from the 12 pm mark. Every shift that is along that  line"
    },
    {
      "t": 119191,
      "e": 114269,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 119239,
      "e": 114317,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "To determine the events that start at 12 pm, you must first locate 12 pm on the x-axis. Once you find the location of 12 pm on the x-axis, look follow the line with the positive slope that stems out from the 12 pm mark. Every shift that is along that  lin"
    },
    {
      "t": 119321,
      "e": 114399,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 119392,
      "e": 114399,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "To determine the events that start at 12 pm, you must first locate 12 pm on the x-axis. Once you find the location of 12 pm on the x-axis, look follow the line with the positive slope that stems out from the 12 pm mark. Every shift that is along that  li"
    },
    {
      "t": 119440,
      "e": 114447,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 119520,
      "e": 114527,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "To determine the events that start at 12 pm, you must first locate 12 pm on the x-axis. Once you find the location of 12 pm on the x-axis, look follow the line with the positive slope that stems out from the 12 pm mark. Every shift that is along that  l"
    },
    {
      "t": 119600,
      "e": 114607,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 119671,
      "e": 114678,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "To determine the events that start at 12 pm, you must first locate 12 pm on the x-axis. Once you find the location of 12 pm on the x-axis, look follow the line with the positive slope that stems out from the 12 pm mark. Every shift that is along that  "
    },
    {
      "t": 119744,
      "e": 114751,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 119833,
      "e": 114752,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "To determine the events that start at 12 pm, you must first locate 12 pm on the x-axis. Once you find the location of 12 pm on the x-axis, look follow the line with the positive slope that stems out from the 12 pm mark. Every shift that is along that "
    },
    {
      "t": 120080,
      "e": 114999,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "76"
    },
    {
      "t": 120080,
      "e": 114999,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 120175,
      "e": 115094,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "73"
    },
    {
      "t": 120175,
      "e": 115094,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 120272,
      "e": 115191,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "78"
    },
    {
      "t": 120272,
      "e": 115191,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 120296,
      "e": 115215,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||lin"
    },
    {
      "t": 120336,
      "e": 115255,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 120352,
      "e": 115271,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 120353,
      "e": 115272,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 120420,
      "e": 115339,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 120420,
      "e": 115339,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 120444,
      "e": 115363,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||e "
    },
    {
      "t": 120452,
      "e": 115371,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 120589,
      "e": 115508,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "87"
    },
    {
      "t": 120589,
      "e": 115508,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 120596,
      "e": 115515,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "73"
    },
    {
      "t": 120596,
      "e": 115515,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 120620,
      "e": 115539,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||wi"
    },
    {
      "t": 120659,
      "e": 115578,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 120748,
      "e": 115667,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 120948,
      "e": 115867,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "76"
    },
    {
      "t": 120948,
      "e": 115867,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 121020,
      "e": 115939,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||l"
    },
    {
      "t": 121076,
      "e": 115995,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "76"
    },
    {
      "t": 121076,
      "e": 115995,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 121165,
      "e": 116084,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 121166,
      "e": 116085,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 121220,
      "e": 116139,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||l "
    },
    {
      "t": 121268,
      "e": 116187,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "83"
    },
    {
      "t": 121268,
      "e": 116187,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 121292,
      "e": 116211,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||s"
    },
    {
      "t": 121372,
      "e": 116291,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 121373,
      "e": 116292,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 121404,
      "e": 116323,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 121476,
      "e": 116395,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 121476,
      "e": 116395,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 121484,
      "e": 116403,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||a"
    },
    {
      "t": 121572,
      "e": 116491,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "82"
    },
    {
      "t": 121572,
      "e": 116491,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 121637,
      "e": 116556,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||r"
    },
    {
      "t": 121668,
      "e": 116587,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 121716,
      "e": 116635,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 121717,
      "e": 116636,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 121876,
      "e": 116795,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 121876,
      "e": 116795,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 121884,
      "e": 116803,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t "
    },
    {
      "t": 121956,
      "e": 116875,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 121957,
      "e": 116876,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 121972,
      "e": 116891,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||a"
    },
    {
      "t": 122028,
      "e": 116947,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 122029,
      "e": 116948,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 122101,
      "e": 117020,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 122133,
      "e": 117052,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 122133,
      "e": 117052,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 122172,
      "e": 117091,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 122212,
      "e": 117131,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 122381,
      "e": 117300,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "49"
    },
    {
      "t": 122381,
      "e": 117300,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 122516,
      "e": 117435,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "50"
    },
    {
      "t": 122516,
      "e": 117435,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 122564,
      "e": 117483,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||12"
    },
    {
      "t": 122661,
      "e": 117580,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 122837,
      "e": 117756,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 122837,
      "e": 117756,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 122948,
      "e": 117867,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "80"
    },
    {
      "t": 122948,
      "e": 117867,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 123028,
      "e": 117947,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| p"
    },
    {
      "t": 123069,
      "e": 117988,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "77"
    },
    {
      "t": 123069,
      "e": 117988,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 123164,
      "e": 118083,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||m"
    },
    {
      "t": 123204,
      "e": 118123,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 123372,
      "e": 118291,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "190"
    },
    {
      "t": 123373,
      "e": 118292,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 123444,
      "e": 118363,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 123444,
      "e": 118363,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 123476,
      "e": 118395,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||. "
    },
    {
      "t": 123580,
      "e": 118499,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 123852,
      "e": 118771,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "16"
    },
    {
      "t": 124020,
      "e": 118939,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "73"
    },
    {
      "t": 124020,
      "e": 118939,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 124108,
      "e": 119027,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||I"
    },
    {
      "t": 124124,
      "e": 119043,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "78"
    },
    {
      "t": 124124,
      "e": 119043,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 124188,
      "e": 119107,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 124188,
      "e": 119107,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 124213,
      "e": 119132,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||n "
    },
    {
      "t": 124284,
      "e": 119203,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 124316,
      "e": 119235,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 124317,
      "e": 119236,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 124324,
      "e": 119243,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 124420,
      "e": 119339,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "72"
    },
    {
      "t": 124420,
      "e": 119339,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 124428,
      "e": 119347,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||h"
    },
    {
      "t": 124565,
      "e": 119484,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "73"
    },
    {
      "t": 124565,
      "e": 119484,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 124684,
      "e": 119603,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||i"
    },
    {
      "t": 124700,
      "e": 119619,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "83"
    },
    {
      "t": 124701,
      "e": 119620,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 124703,
      "e": 119622,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 124704,
      "e": 119622,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 124732,
      "e": 119650,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||s "
    },
    {
      "t": 124796,
      "e": 119714,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 124877,
      "e": 119795,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 124908,
      "e": 119826,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "67"
    },
    {
      "t": 124908,
      "e": 119826,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 124997,
      "e": 119915,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 124997,
      "e": 119915,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 125028,
      "e": 119946,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||ca"
    },
    {
      "t": 125092,
      "e": 120010,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "83"
    },
    {
      "t": 125092,
      "e": 120010,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 125172,
      "e": 120090,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||s"
    },
    {
      "t": 125196,
      "e": 120114,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 125197,
      "e": 120115,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 125228,
      "e": 120146,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||e"
    },
    {
      "t": 125284,
      "e": 120202,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "188"
    },
    {
      "t": 125284,
      "e": 120202,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 125307,
      "e": 120225,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||,"
    },
    {
      "t": 125356,
      "e": 120274,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 125357,
      "e": 120275,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 125404,
      "e": 120322,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 125492,
      "e": 120410,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 126741,
      "e": 121659,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "16"
    },
    {
      "t": 126853,
      "e": 121771,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "77"
    },
    {
      "t": 126853,
      "e": 121771,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 126932,
      "e": 121850,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||M"
    },
    {
      "t": 126996,
      "e": 121914,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 127829,
      "e": 122747,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 127829,
      "e": 122747,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 127932,
      "e": 122850,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 127932,
      "e": 122850,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 127964,
      "e": 122882,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| a"
    },
    {
      "t": 128004,
      "e": 122922,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "78"
    },
    {
      "t": 128004,
      "e": 122922,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 128052,
      "e": 122970,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "68"
    },
    {
      "t": 128053,
      "e": 122971,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 128060,
      "e": 122978,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||nd"
    },
    {
      "t": 128107,
      "e": 123025,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 128108,
      "e": 123026,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 128172,
      "e": 123090,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 128188,
      "e": 123106,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 128244,
      "e": 123162,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 128453,
      "e": 123371,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 128615,
      "e": 123533,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "To determine the events that start at 12 pm, you must first locate 12 pm on the x-axis. Once you find the location of 12 pm on the x-axis, look follow the line with the positive slope that stems out from the 12 pm mark. Every shift that is along that line will start at 12 pm. In this case, M and"
    },
    {
      "t": 128748,
      "e": 123666,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "To determine the events that start at 12 pm, you must first locate 12 pm on the x-axis. Once you find the location of 12 pm on the x-axis, look follow the line with the positive slope that stems out from the 12 pm mark. Every shift that is along that line will start at 12 pm. In this case, M and"
    },
    {
      "t": 128845,
      "e": 123763,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 128908,
      "e": 123763,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "To determine the events that start at 12 pm, you must first locate 12 pm on the x-axis. Once you find the location of 12 pm on the x-axis, look follow the line with the positive slope that stems out from the 12 pm mark. Every shift that is along that line will start at 12 pm. In this case, M an"
    },
    {
      "t": 128980,
      "e": 123835,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 129060,
      "e": 123915,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "To determine the events that start at 12 pm, you must first locate 12 pm on the x-axis. Once you find the location of 12 pm on the x-axis, look follow the line with the positive slope that stems out from the 12 pm mark. Every shift that is along that line will start at 12 pm. In this case, M a"
    },
    {
      "t": 129100,
      "e": 123955,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 129196,
      "e": 124051,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "To determine the events that start at 12 pm, you must first locate 12 pm on the x-axis. Once you find the location of 12 pm on the x-axis, look follow the line with the positive slope that stems out from the 12 pm mark. Every shift that is along that line will start at 12 pm. In this case, M "
    },
    {
      "t": 129276,
      "e": 124131,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 129350,
      "e": 124132,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "To determine the events that start at 12 pm, you must first locate 12 pm on the x-axis. Once you find the location of 12 pm on the x-axis, look follow the line with the positive slope that stems out from the 12 pm mark. Every shift that is along that line will start at 12 pm. In this case, M"
    },
    {
      "t": 129420,
      "e": 124202,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 129508,
      "e": 124290,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "To determine the events that start at 12 pm, you must first locate 12 pm on the x-axis. Once you find the location of 12 pm on the x-axis, look follow the line with the positive slope that stems out from the 12 pm mark. Every shift that is along that line will start at 12 pm. In this case, "
    },
    {
      "t": 129616,
      "e": 124398,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "To determine the events that start at 12 pm, you must first locate 12 pm on the x-axis. Once you find the location of 12 pm on the x-axis, look follow the line with the positive slope that stems out from the 12 pm mark. Every shift that is along that line will start at 12 pm. In this case, "
    },
    {
      "t": 129644,
      "e": 124426,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "83"
    },
    {
      "t": 129645,
      "e": 124427,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 129732,
      "e": 124514,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "72"
    },
    {
      "t": 129732,
      "e": 124514,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 129756,
      "e": 124538,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||sh"
    },
    {
      "t": 129844,
      "e": 124626,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "73"
    },
    {
      "t": 129844,
      "e": 124626,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 129916,
      "e": 124698,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "70"
    },
    {
      "t": 129917,
      "e": 124699,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 129923,
      "e": 124705,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||if"
    },
    {
      "t": 129955,
      "e": 124737,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 130012,
      "e": 124794,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 130173,
      "e": 124955,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 130174,
      "e": 124956,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 130277,
      "e": 124957,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "83"
    },
    {
      "t": 130278,
      "e": 124958,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 130348,
      "e": 125028,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||ts"
    },
    {
      "t": 130420,
      "e": 125100,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 130421,
      "e": 125101,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 130436,
      "e": 125116,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 130556,
      "e": 125236,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 130837,
      "e": 125517,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "16"
    },
    {
      "t": 130900,
      "e": 125580,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "77"
    },
    {
      "t": 130901,
      "e": 125581,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 130932,
      "e": 125612,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||M"
    },
    {
      "t": 130979,
      "e": 125659,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 131068,
      "e": 125748,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 131068,
      "e": 125748,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 131165,
      "e": 125845,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 131165,
      "e": 125845,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 131180,
      "e": 125860,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| a"
    },
    {
      "t": 131244,
      "e": 125924,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "78"
    },
    {
      "t": 131244,
      "e": 125924,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 131276,
      "e": 125956,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||n"
    },
    {
      "t": 131283,
      "e": 125963,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "68"
    },
    {
      "t": 131284,
      "e": 125964,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 131372,
      "e": 126052,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 131372,
      "e": 126052,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 131396,
      "e": 126076,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||d "
    },
    {
      "t": 131412,
      "e": 126092,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 131500,
      "e": 126180,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "16"
    },
    {
      "t": 131589,
      "e": 126269,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 131621,
      "e": 126301,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "76"
    },
    {
      "t": 131621,
      "e": 126301,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 131700,
      "e": 126380,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||L"
    },
    {
      "t": 131732,
      "e": 126412,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 131804,
      "e": 126484,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "79"
    },
    {
      "t": 131804,
      "e": 126484,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 131829,
      "e": 126509,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||o"
    },
    {
      "t": 132093,
      "e": 126773,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 132189,
      "e": 126869,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "To determine the events that start at 12 pm, you must first locate 12 pm on the x-axis. Once you find the location of 12 pm on the x-axis, look follow the line with the positive slope that stems out from the 12 pm mark. Every shift that is along that line will start at 12 pm. In this case, shifts M and L"
    },
    {
      "t": 132196,
      "e": 126876,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 132197,
      "e": 126877,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 132291,
      "e": 126971,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 132300,
      "e": 126980,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 132300,
      "e": 126980,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 132416,
      "e": 127096,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "To determine the events that start at 12 pm, you must first locate 12 pm on the x-axis. Once you find the location of 12 pm on the x-axis, look follow the line with the positive slope that stems out from the 12 pm mark. Every shift that is along that line will start at 12 pm. In this case, shifts M and L a"
    },
    {
      "t": 132420,
      "e": 127100,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "82"
    },
    {
      "t": 132420,
      "e": 127100,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 132444,
      "e": 127124,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||ar"
    },
    {
      "t": 132500,
      "e": 127180,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 132500,
      "e": 127180,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 132548,
      "e": 127228,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 132548,
      "e": 127228,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 132556,
      "e": 127236,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||e "
    },
    {
      "t": 132604,
      "e": 127236,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 132684,
      "e": 127316,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "70"
    },
    {
      "t": 132684,
      "e": 127316,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 132764,
      "e": 127396,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||f"
    },
    {
      "t": 132812,
      "e": 127444,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 132820,
      "e": 127452,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "79"
    },
    {
      "t": 132820,
      "e": 127452,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 132908,
      "e": 127540,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "85"
    },
    {
      "t": 132909,
      "e": 127541,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 133015,
      "e": 127647,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "To determine the events that start at 12 pm, you must first locate 12 pm on the x-axis. Once you find the location of 12 pm on the x-axis, look follow the line with the positive slope that stems out from the 12 pm mark. Every shift that is along that line will start at 12 pm. In this case, shifts M and L are fou"
    },
    {
      "t": 133044,
      "e": 127676,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||ou"
    },
    {
      "t": 133044,
      "e": 127676,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "78"
    },
    {
      "t": 133045,
      "e": 127677,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 133084,
      "e": 127716,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||n"
    },
    {
      "t": 133092,
      "e": 127724,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "68"
    },
    {
      "t": 133093,
      "e": 127725,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 133140,
      "e": 127772,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 133140,
      "e": 127772,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 133179,
      "e": 127811,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||d "
    },
    {
      "t": 133196,
      "e": 127828,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 133220,
      "e": 127852,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "79"
    },
    {
      "t": 133220,
      "e": 127852,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 133268,
      "e": 127900,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||o"
    },
    {
      "t": 133307,
      "e": 127939,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "78"
    },
    {
      "t": 133307,
      "e": 127939,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 133372,
      "e": 128004,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 133372,
      "e": 128004,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 133420,
      "e": 128052,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||n "
    },
    {
      "t": 133508,
      "e": 128140,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 133524,
      "e": 128156,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 134084,
      "e": 128716,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 134085,
      "e": 128717,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 134171,
      "e": 128803,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "72"
    },
    {
      "t": 134172,
      "e": 128804,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 134188,
      "e": 128820,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||th"
    },
    {
      "t": 134211,
      "e": 128843,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 134211,
      "e": 128843,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 134284,
      "e": 128916,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 134284,
      "e": 128916,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 134348,
      "e": 128980,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 134348,
      "e": 128980,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 134356,
      "e": 128988,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||at "
    },
    {
      "t": 134372,
      "e": 129004,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 134412,
      "e": 129044,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 134484,
      "e": 129116,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "76"
    },
    {
      "t": 134485,
      "e": 129117,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 134507,
      "e": 129139,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||l"
    },
    {
      "t": 134588,
      "e": 129220,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "73"
    },
    {
      "t": 134588,
      "e": 129220,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 134692,
      "e": 129324,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "78"
    },
    {
      "t": 134692,
      "e": 129324,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 134716,
      "e": 129348,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||in"
    },
    {
      "t": 134732,
      "e": 129364,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 134732,
      "e": 129364,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 134739,
      "e": 129371,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||e"
    },
    {
      "t": 134796,
      "e": 129428,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 134867,
      "e": 129499,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 134964,
      "e": 129596,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "188"
    },
    {
      "t": 134965,
      "e": 129597,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 135011,
      "e": 129643,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 135012,
      "e": 129644,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 135044,
      "e": 129676,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||, "
    },
    {
      "t": 135196,
      "e": 129828,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 135213,
      "e": 129845,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "77"
    },
    {
      "t": 135213,
      "e": 129845,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 135308,
      "e": 129940,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 135309,
      "e": 129941,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 135316,
      "e": 129948,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||me"
    },
    {
      "t": 135387,
      "e": 130019,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 135387,
      "e": 130019,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 135444,
      "e": 130076,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||a"
    },
    {
      "t": 135532,
      "e": 130164,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 135540,
      "e": 130172,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "78"
    },
    {
      "t": 135541,
      "e": 130173,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 135587,
      "e": 130219,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "73"
    },
    {
      "t": 135588,
      "e": 130220,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 135612,
      "e": 130244,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||ni"
    },
    {
      "t": 135700,
      "e": 130332,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "78"
    },
    {
      "t": 135701,
      "e": 130333,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 135756,
      "e": 130388,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||n"
    },
    {
      "t": 135780,
      "e": 130412,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "71"
    },
    {
      "t": 135781,
      "e": 130413,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 135844,
      "e": 130476,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 135844,
      "e": 130476,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 135900,
      "e": 130532,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||g "
    },
    {
      "t": 135907,
      "e": 130539,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 135996,
      "e": 130628,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 135996,
      "e": 130628,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 136004,
      "e": 130636,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 136076,
      "e": 130708,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "72"
    },
    {
      "t": 136077,
      "e": 130709,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 136091,
      "e": 130723,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||h"
    },
    {
      "t": 136124,
      "e": 130756,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 136124,
      "e": 130756,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 136195,
      "e": 130827,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 136195,
      "e": 130827,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 136220,
      "e": 130852,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||at"
    },
    {
      "t": 136228,
      "e": 130860,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 136228,
      "e": 130860,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 136276,
      "e": 130908,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 136283,
      "e": 130915,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 136372,
      "e": 131004,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 136373,
      "e": 131005,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 136444,
      "e": 131076,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 136451,
      "e": 131083,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "72"
    },
    {
      "t": 136451,
      "e": 131083,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 136484,
      "e": 131116,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||h"
    },
    {
      "t": 136556,
      "e": 131188,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 136797,
      "e": 131429,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 136797,
      "e": 131429,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 136876,
      "e": 131508,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "89"
    },
    {
      "t": 136876,
      "e": 131508,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 136899,
      "e": 131531,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||ey"
    },
    {
      "t": 136972,
      "e": 131604,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 136972,
      "e": 131604,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 137036,
      "e": 131668,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 137100,
      "e": 131732,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 137101,
      "e": 131733,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "87"
    },
    {
      "t": 137101,
      "e": 131733,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 137214,
      "e": 131846,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "To determine the events that start at 12 pm, you must first locate 12 pm on the x-axis. Once you find the location of 12 pm on the x-axis, look follow the line with the positive slope that stems out from the 12 pm mark. Every shift that is along that line will start at 12 pm. In this case, shifts M and L are found on that line, meaning that they w"
    },
    {
      "t": 137227,
      "e": 131859,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||w"
    },
    {
      "t": 137452,
      "e": 132084,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "73"
    },
    {
      "t": 137454,
      "e": 132086,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 137539,
      "e": 132171,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||i"
    },
    {
      "t": 137612,
      "e": 132244,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "76"
    },
    {
      "t": 137612,
      "e": 132244,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 137684,
      "e": 132316,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||l"
    },
    {
      "t": 137756,
      "e": 132388,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "76"
    },
    {
      "t": 137757,
      "e": 132389,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 137852,
      "e": 132484,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 137852,
      "e": 132484,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 137867,
      "e": 132499,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||l "
    },
    {
      "t": 137940,
      "e": 132572,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "66"
    },
    {
      "t": 137940,
      "e": 132572,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 138020,
      "e": 132652,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||b"
    },
    {
      "t": 138028,
      "e": 132660,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "79"
    },
    {
      "t": 138028,
      "e": 132660,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 138052,
      "e": 132684,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||o"
    },
    {
      "t": 138156,
      "e": 132788,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 138157,
      "e": 132789,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 138235,
      "e": 132867,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "72"
    },
    {
      "t": 138236,
      "e": 132868,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 138276,
      "e": 132908,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||th"
    },
    {
      "t": 138300,
      "e": 132932,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 138332,
      "e": 132964,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 138332,
      "e": 132964,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 138420,
      "e": 133052,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 138476,
      "e": 133108,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 138772,
      "e": 133404,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "83"
    },
    {
      "t": 138773,
      "e": 133405,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 138891,
      "e": 133523,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 138892,
      "e": 133524,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 138916,
      "e": 133548,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||st"
    },
    {
      "t": 138972,
      "e": 133604,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 138980,
      "e": 133612,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 138980,
      "e": 133612,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 139068,
      "e": 133700,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "82"
    },
    {
      "t": 139069,
      "e": 133701,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 139116,
      "e": 133748,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||ar"
    },
    {
      "t": 139156,
      "e": 133788,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 139245,
      "e": 133877,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 139245,
      "e": 133877,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 139356,
      "e": 133988,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 139356,
      "e": 133988,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 139364,
      "e": 133996,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 139364,
      "e": 133996,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 139372,
      "e": 134004,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||ta "
    },
    {
      "t": 139468,
      "e": 134100,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 139484,
      "e": 134116,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 139484,
      "e": 134116,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 139532,
      "e": 134164,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 139611,
      "e": 134243,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 139844,
      "e": 134476,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 139900,
      "e": 134477,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "To determine the events that start at 12 pm, you must first locate 12 pm on the x-axis. Once you find the location of 12 pm on the x-axis, look follow the line with the positive slope that stems out from the 12 pm mark. Every shift that is along that line will start at 12 pm. In this case, shifts M and L are found on that line, meaning that they will both starta "
    },
    {
      "t": 139972,
      "e": 134549,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 140027,
      "e": 134604,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "To determine the events that start at 12 pm, you must first locate 12 pm on the x-axis. Once you find the location of 12 pm on the x-axis, look follow the line with the positive slope that stems out from the 12 pm mark. Every shift that is along that line will start at 12 pm. In this case, shifts M and L are found on that line, meaning that they will both starta"
    },
    {
      "t": 140100,
      "e": 134677,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 140165,
      "e": 134678,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "To determine the events that start at 12 pm, you must first locate 12 pm on the x-axis. Once you find the location of 12 pm on the x-axis, look follow the line with the positive slope that stems out from the 12 pm mark. Every shift that is along that line will start at 12 pm. In this case, shifts M and L are found on that line, meaning that they will both start"
    },
    {
      "t": 140252,
      "e": 134765,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 140323,
      "e": 134836,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "To determine the events that start at 12 pm, you must first locate 12 pm on the x-axis. Once you find the location of 12 pm on the x-axis, look follow the line with the positive slope that stems out from the 12 pm mark. Every shift that is along that line will start at 12 pm. In this case, shifts M and L are found on that line, meaning that they will both star"
    },
    {
      "t": 140700,
      "e": 135213,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 140701,
      "e": 135214,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 140787,
      "e": 135300,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 140787,
      "e": 135300,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 140803,
      "e": 135316,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t "
    },
    {
      "t": 140868,
      "e": 135381,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 140884,
      "e": 135397,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 140885,
      "e": 135398,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 140964,
      "e": 135477,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 140964,
      "e": 135477,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 141012,
      "e": 135525,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||at"
    },
    {
      "t": 141036,
      "e": 135549,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 141037,
      "e": 135550,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 141076,
      "e": 135589,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 141147,
      "e": 135660,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 141341,
      "e": 135854,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "49"
    },
    {
      "t": 141341,
      "e": 135854,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 141460,
      "e": 135973,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "50"
    },
    {
      "t": 141460,
      "e": 135973,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 141508,
      "e": 136021,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||12"
    },
    {
      "t": 141580,
      "e": 136093,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 141596,
      "e": 136109,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 141597,
      "e": 136110,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 141796,
      "e": 136309,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "80"
    },
    {
      "t": 141797,
      "e": 136310,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 141804,
      "e": 136317,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| p"
    },
    {
      "t": 141908,
      "e": 136421,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "77"
    },
    {
      "t": 141909,
      "e": 136422,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 141979,
      "e": 136492,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||m"
    },
    {
      "t": 142028,
      "e": 136541,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 142229,
      "e": 136742,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "190"
    },
    {
      "t": 142229,
      "e": 136742,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 142324,
      "e": 136837,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||."
    },
    {
      "t": 150013,
      "e": 141837,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 151312,
      "e": 141837,
      "ty": 2,
      "x": 520,
      "y": 547
    },
    {
      "t": 151413,
      "e": 141938,
      "ty": 2,
      "x": 523,
      "y": 585
    },
    {
      "t": 151513,
      "e": 142038,
      "ty": 2,
      "x": 528,
      "y": 597
    },
    {
      "t": 151513,
      "e": 142038,
      "ty": 41,
      "x": 48438,
      "y": 60086,
      "ta": "#strategyAnswer"
    },
    {
      "t": 151713,
      "e": 142238,
      "ty": 2,
      "x": 528,
      "y": 598
    },
    {
      "t": 151763,
      "e": 142288,
      "ty": 41,
      "x": 48438,
      "y": 60895,
      "ta": "#strategyAnswer"
    },
    {
      "t": 153078,
      "e": 143603,
      "ty": 7,
      "x": 572,
      "y": 609,
      "ta": "#strategyAnswer"
    },
    {
      "t": 153113,
      "e": 143638,
      "ty": 2,
      "x": 646,
      "y": 628
    },
    {
      "t": 153213,
      "e": 143738,
      "ty": 2,
      "x": 780,
      "y": 665
    },
    {
      "t": 153263,
      "e": 143788,
      "ty": 41,
      "x": 5734,
      "y": 37418,
      "ta": "> div.stimulus > div:[2]"
    },
    {
      "t": 153613,
      "e": 144138,
      "ty": 2,
      "x": 816,
      "y": 701
    },
    {
      "t": 153713,
      "e": 144238,
      "ty": 2,
      "x": 862,
      "y": 714
    },
    {
      "t": 153763,
      "e": 144288,
      "ty": 41,
      "x": 26496,
      "y": 45194,
      "ta": "> div.stimulus > div:[2] > svg"
    },
    {
      "t": 153813,
      "e": 144338,
      "ty": 2,
      "x": 1563,
      "y": 844
    },
    {
      "t": 153913,
      "e": 144438,
      "ty": 2,
      "x": 1919,
      "y": 992
    },
    {
      "t": 154013,
      "e": 144538,
      "ty": 2,
      "x": 1919,
      "y": 1015
    },
    {
      "t": 154113,
      "e": 144638,
      "ty": 2,
      "x": 1907,
      "y": 1018
    },
    {
      "t": 154213,
      "e": 144738,
      "ty": 2,
      "x": 1844,
      "y": 1024
    },
    {
      "t": 154263,
      "e": 144788,
      "ty": 41,
      "x": 62883,
      "y": 56283,
      "ta": "> div.stimulus"
    },
    {
      "t": 154313,
      "e": 144838,
      "ty": 2,
      "x": 1834,
      "y": 1024
    },
    {
      "t": 156713,
      "e": 147238,
      "ty": 2,
      "x": 1778,
      "y": 977
    },
    {
      "t": 156763,
      "e": 147288,
      "ty": 41,
      "x": 60180,
      "y": 53430,
      "ta": "> div.stimulus > div:[2] > svg"
    },
    {
      "t": 156813,
      "e": 147338,
      "ty": 2,
      "x": 1398,
      "y": 755
    },
    {
      "t": 156913,
      "e": 147438,
      "ty": 2,
      "x": 1197,
      "y": 616
    },
    {
      "t": 157013,
      "e": 147538,
      "ty": 2,
      "x": 1079,
      "y": 603
    },
    {
      "t": 157013,
      "e": 147538,
      "ty": 41,
      "x": 20648,
      "y": 33304,
      "ta": "> div.stimulus > div:[2] > svg"
    },
    {
      "t": 157113,
      "e": 147638,
      "ty": 2,
      "x": 846,
      "y": 578
    },
    {
      "t": 157213,
      "e": 147738,
      "ty": 2,
      "x": 736,
      "y": 573
    },
    {
      "t": 157263,
      "e": 147788,
      "ty": 41,
      "x": 2118,
      "y": 30885,
      "ta": "> div.stimulus > div:[2]"
    },
    {
      "t": 157313,
      "e": 147838,
      "ty": 2,
      "x": 712,
      "y": 570
    },
    {
      "t": 157413,
      "e": 147938,
      "ty": 2,
      "x": 702,
      "y": 561
    },
    {
      "t": 157464,
      "e": 147989,
      "ty": 6,
      "x": 671,
      "y": 543,
      "ta": "#strategyAnswer"
    },
    {
      "t": 157513,
      "e": 148038,
      "ty": 2,
      "x": 640,
      "y": 538
    },
    {
      "t": 157513,
      "e": 148038,
      "ty": 41,
      "x": 61028,
      "y": 12351,
      "ta": "#strategyAnswer"
    },
    {
      "t": 157614,
      "e": 148139,
      "ty": 2,
      "x": 606,
      "y": 526
    },
    {
      "t": 157713,
      "e": 148238,
      "ty": 2,
      "x": 604,
      "y": 528
    },
    {
      "t": 157764,
      "e": 148289,
      "ty": 41,
      "x": 56419,
      "y": 13160,
      "ta": "#strategyAnswer"
    },
    {
      "t": 157813,
      "e": 148338,
      "ty": 2,
      "x": 595,
      "y": 547
    },
    {
      "t": 157913,
      "e": 148438,
      "ty": 2,
      "x": 595,
      "y": 548
    },
    {
      "t": 158013,
      "e": 148538,
      "ty": 41,
      "x": 55969,
      "y": 20441,
      "ta": "#strategyAnswer"
    },
    {
      "t": 158764,
      "e": 149289,
      "ty": 41,
      "x": 56419,
      "y": 19632,
      "ta": "#strategyAnswer"
    },
    {
      "t": 158814,
      "e": 149339,
      "ty": 2,
      "x": 599,
      "y": 547
    },
    {
      "t": 159177,
      "e": 149702,
      "ty": 3,
      "x": 599,
      "y": 547,
      "ta": "#strategyAnswer"
    },
    {
      "t": 159613,
      "e": 150138,
      "ty": 2,
      "x": 586,
      "y": 549
    },
    {
      "t": 159714,
      "e": 150239,
      "ty": 2,
      "x": 574,
      "y": 553
    },
    {
      "t": 159763,
      "e": 150288,
      "ty": 41,
      "x": 53609,
      "y": 24487,
      "ta": "#strategyAnswer"
    },
    {
      "t": 159813,
      "e": 150338,
      "ty": 2,
      "x": 573,
      "y": 553
    },
    {
      "t": 159913,
      "e": 150438,
      "ty": 2,
      "x": 565,
      "y": 557
    },
    {
      "t": 160013,
      "e": 150538,
      "ty": 2,
      "x": 562,
      "y": 558
    },
    {
      "t": 160013,
      "e": 150538,
      "ty": 41,
      "x": 52260,
      "y": 28532,
      "ta": "#strategyAnswer"
    },
    {
      "t": 160013,
      "e": 150538,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 160114,
      "e": 150639,
      "ty": 2,
      "x": 561,
      "y": 558
    },
    {
      "t": 160263,
      "e": 150788,
      "ty": 41,
      "x": 52147,
      "y": 28532,
      "ta": "#strategyAnswer"
    },
    {
      "t": 160414,
      "e": 150939,
      "ty": 2,
      "x": 560,
      "y": 554
    },
    {
      "t": 160514,
      "e": 151039,
      "ty": 2,
      "x": 560,
      "y": 553
    },
    {
      "t": 160514,
      "e": 151039,
      "ty": 41,
      "x": 52035,
      "y": 24487,
      "ta": "#strategyAnswer"
    },
    {
      "t": 160744,
      "e": 151269,
      "ty": 4,
      "x": 52035,
      "y": 24487,
      "ta": "#strategyAnswer"
    },
    {
      "t": 160745,
      "e": 151270,
      "ty": 5,
      "x": 560,
      "y": 553,
      "ta": "#strategyAnswer"
    },
    {
      "t": 161348,
      "e": 151873,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 161419,
      "e": 151944,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "To determine the events that start at 12 pm, you must first locate 12 pm on the x-axis. Once you find the location of 12 pm on the x-axis, follow the line with the positive slope that stems out from the 12 pm mark. Every shift that is along that line will start at 12 pm. In this case, shifts M and L are found on that line, meaning that they will both start at 12 pm."
    },
    {
      "t": 162413,
      "e": 152938,
      "ty": 2,
      "x": 567,
      "y": 547
    },
    {
      "t": 162513,
      "e": 153038,
      "ty": 41,
      "x": 52822,
      "y": 19632,
      "ta": "#strategyAnswer"
    },
    {
      "t": 162764,
      "e": 153289,
      "ty": 41,
      "x": 52822,
      "y": 18823,
      "ta": "#strategyAnswer"
    },
    {
      "t": 162813,
      "e": 153338,
      "ty": 2,
      "x": 573,
      "y": 557
    },
    {
      "t": 162914,
      "e": 153439,
      "ty": 2,
      "x": 580,
      "y": 567
    },
    {
      "t": 163013,
      "e": 153538,
      "ty": 2,
      "x": 582,
      "y": 576
    },
    {
      "t": 163014,
      "e": 153539,
      "ty": 41,
      "x": 54508,
      "y": 43095,
      "ta": "#strategyAnswer"
    },
    {
      "t": 163113,
      "e": 153638,
      "ty": 2,
      "x": 581,
      "y": 587
    },
    {
      "t": 163213,
      "e": 153738,
      "ty": 2,
      "x": 577,
      "y": 594
    },
    {
      "t": 163264,
      "e": 153789,
      "ty": 41,
      "x": 53946,
      "y": 57659,
      "ta": "#strategyAnswer"
    },
    {
      "t": 163613,
      "e": 154138,
      "ty": 2,
      "x": 577,
      "y": 597
    },
    {
      "t": 163763,
      "e": 154288,
      "ty": 41,
      "x": 53946,
      "y": 60086,
      "ta": "#strategyAnswer"
    },
    {
      "t": 163816,
      "e": 154341,
      "ty": 3,
      "x": 577,
      "y": 597,
      "ta": "#strategyAnswer"
    },
    {
      "t": 163911,
      "e": 154436,
      "ty": 4,
      "x": 53946,
      "y": 60086,
      "ta": "#strategyAnswer"
    },
    {
      "t": 163912,
      "e": 154437,
      "ty": 5,
      "x": 577,
      "y": 597,
      "ta": "#strategyAnswer"
    },
    {
      "t": 170012,
      "e": 159437,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 171263,
      "e": 159437,
      "ty": 41,
      "x": 53946,
      "y": 60895,
      "ta": "#strategyAnswer"
    },
    {
      "t": 171312,
      "e": 159486,
      "ty": 2,
      "x": 577,
      "y": 598
    },
    {
      "t": 172763,
      "e": 160937,
      "ty": 41,
      "x": 55182,
      "y": 56850,
      "ta": "#strategyAnswer"
    },
    {
      "t": 172813,
      "e": 160987,
      "ty": 2,
      "x": 639,
      "y": 591
    },
    {
      "t": 172826,
      "e": 161000,
      "ty": 7,
      "x": 733,
      "y": 603,
      "ta": "#strategyAnswer"
    },
    {
      "t": 172913,
      "e": 161087,
      "ty": 2,
      "x": 1052,
      "y": 693
    },
    {
      "t": 173012,
      "e": 161186,
      "ty": 2,
      "x": 1076,
      "y": 708
    },
    {
      "t": 173013,
      "e": 161187,
      "ty": 41,
      "x": 20436,
      "y": 40825,
      "ta": "> div.stimulus > div:[2] > svg"
    },
    {
      "t": 173113,
      "e": 161287,
      "ty": 2,
      "x": 1198,
      "y": 806
    },
    {
      "t": 173213,
      "e": 161387,
      "ty": 2,
      "x": 1287,
      "y": 911
    },
    {
      "t": 173263,
      "e": 161437,
      "ty": 41,
      "x": 34882,
      "y": 56224,
      "ta": "> div.stimulus > div:[2] > svg"
    },
    {
      "t": 173312,
      "e": 161486,
      "ty": 2,
      "x": 1271,
      "y": 940
    },
    {
      "t": 173413,
      "e": 161587,
      "ty": 2,
      "x": 1263,
      "y": 949
    },
    {
      "t": 173513,
      "e": 161687,
      "ty": 2,
      "x": 1212,
      "y": 969
    },
    {
      "t": 173514,
      "e": 161688,
      "ty": 41,
      "x": 20089,
      "y": 255,
      "ta": "> div.stimulus > div:[2] > svg > g > g:[3] > g:[11] > text"
    },
    {
      "t": 173613,
      "e": 161787,
      "ty": 2,
      "x": 1183,
      "y": 979
    },
    {
      "t": 173713,
      "e": 161887,
      "ty": 2,
      "x": 1170,
      "y": 959
    },
    {
      "t": 173763,
      "e": 161937,
      "ty": 41,
      "x": 26849,
      "y": 58157,
      "ta": "> div.stimulus > div:[2] > svg"
    },
    {
      "t": 173813,
      "e": 161987,
      "ty": 2,
      "x": 1166,
      "y": 949
    },
    {
      "t": 174012,
      "e": 162186,
      "ty": 2,
      "x": 1171,
      "y": 937
    },
    {
      "t": 174013,
      "e": 162187,
      "ty": 41,
      "x": 27131,
      "y": 57226,
      "ta": "> div.stimulus > div:[2] > svg"
    },
    {
      "t": 174112,
      "e": 162286,
      "ty": 2,
      "x": 1175,
      "y": 927
    },
    {
      "t": 174213,
      "e": 162387,
      "ty": 2,
      "x": 1178,
      "y": 922
    },
    {
      "t": 174263,
      "e": 162437,
      "ty": 41,
      "x": 27694,
      "y": 56009,
      "ta": "> div.stimulus > div:[2] > svg"
    },
    {
      "t": 174312,
      "e": 162486,
      "ty": 2,
      "x": 1181,
      "y": 915
    },
    {
      "t": 174413,
      "e": 162587,
      "ty": 2,
      "x": 1185,
      "y": 908
    },
    {
      "t": 174513,
      "e": 162687,
      "ty": 41,
      "x": 28117,
      "y": 55149,
      "ta": "> div.stimulus > div:[2] > svg"
    },
    {
      "t": 174612,
      "e": 162786,
      "ty": 2,
      "x": 1191,
      "y": 895
    },
    {
      "t": 174713,
      "e": 162887,
      "ty": 2,
      "x": 1199,
      "y": 879
    },
    {
      "t": 174763,
      "e": 162937,
      "ty": 41,
      "x": 29104,
      "y": 53072,
      "ta": "> div.stimulus > div:[2] > svg"
    },
    {
      "t": 174912,
      "e": 163086,
      "ty": 2,
      "x": 1197,
      "y": 876
    },
    {
      "t": 175012,
      "e": 163186,
      "ty": 41,
      "x": 28963,
      "y": 52857,
      "ta": "> div.stimulus > div:[2] > svg"
    },
    {
      "t": 175413,
      "e": 163587,
      "ty": 2,
      "x": 1108,
      "y": 826
    },
    {
      "t": 175512,
      "e": 163686,
      "ty": 2,
      "x": 662,
      "y": 621
    },
    {
      "t": 175512,
      "e": 163686,
      "ty": 41,
      "x": 63501,
      "y": 65201,
      "ta": "> div.stimulus > div > div:[2]"
    },
    {
      "t": 175546,
      "e": 163720,
      "ty": 6,
      "x": 609,
      "y": 597,
      "ta": "#strategyAnswer"
    },
    {
      "t": 175613,
      "e": 163787,
      "ty": 2,
      "x": 578,
      "y": 581
    },
    {
      "t": 175763,
      "e": 163937,
      "ty": 41,
      "x": 54058,
      "y": 47141,
      "ta": "#strategyAnswer"
    },
    {
      "t": 175913,
      "e": 164087,
      "ty": 2,
      "x": 575,
      "y": 582
    },
    {
      "t": 176012,
      "e": 164186,
      "ty": 2,
      "x": 575,
      "y": 583
    },
    {
      "t": 176012,
      "e": 164186,
      "ty": 41,
      "x": 53721,
      "y": 48759,
      "ta": "#strategyAnswer"
    },
    {
      "t": 176113,
      "e": 164287,
      "ty": 2,
      "x": 574,
      "y": 587
    },
    {
      "t": 176213,
      "e": 164387,
      "ty": 2,
      "x": 574,
      "y": 588
    },
    {
      "t": 176263,
      "e": 164437,
      "ty": 41,
      "x": 53609,
      "y": 52804,
      "ta": "#strategyAnswer"
    },
    {
      "t": 176713,
      "e": 164887,
      "ty": 2,
      "x": 574,
      "y": 590
    },
    {
      "t": 176763,
      "e": 164937,
      "ty": 41,
      "x": 53609,
      "y": 54422,
      "ta": "#strategyAnswer"
    },
    {
      "t": 177313,
      "e": 165487,
      "ty": 2,
      "x": 575,
      "y": 601
    },
    {
      "t": 177314,
      "e": 165488,
      "ty": 7,
      "x": 576,
      "y": 604,
      "ta": "#strategyAnswer"
    },
    {
      "t": 177413,
      "e": 165587,
      "ty": 2,
      "x": 576,
      "y": 610
    },
    {
      "t": 177512,
      "e": 165686,
      "ty": 2,
      "x": 550,
      "y": 633
    },
    {
      "t": 177513,
      "e": 165687,
      "ty": 41,
      "x": 50911,
      "y": 34623,
      "ta": "> div.stimulus > div"
    },
    {
      "t": 177712,
      "e": 165886,
      "ty": 2,
      "x": 543,
      "y": 633
    },
    {
      "t": 177763,
      "e": 165937,
      "ty": 41,
      "x": 49899,
      "y": 34623,
      "ta": "> div.stimulus > div"
    },
    {
      "t": 177812,
      "e": 165986,
      "ty": 2,
      "x": 519,
      "y": 637
    },
    {
      "t": 177913,
      "e": 166087,
      "ty": 2,
      "x": 492,
      "y": 658
    },
    {
      "t": 177964,
      "e": 166138,
      "ty": 6,
      "x": 455,
      "y": 675,
      "ta": "#strategyButton"
    },
    {
      "t": 178013,
      "e": 166187,
      "ty": 2,
      "x": 454,
      "y": 677
    },
    {
      "t": 178013,
      "e": 166187,
      "ty": 41,
      "x": 63026,
      "y": 42916,
      "ta": "#strategyButton"
    },
    {
      "t": 178113,
      "e": 166287,
      "ty": 2,
      "x": 449,
      "y": 680
    },
    {
      "t": 178200,
      "e": 166374,
      "ty": 3,
      "x": 449,
      "y": 680,
      "ta": "#strategyButton"
    },
    {
      "t": 178200,
      "e": 166374,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "To determine the events that start at 12 pm, you must first locate 12 pm on the x-axis. Once you find the location of 12 pm on the x-axis, follow the line with the positive slope that stems out from the 12 pm mark. Every shift that is along that line will start at 12 pm. In this case, shifts M and L are found on that line, meaning that they will both start at 12 pm."
    },
    {
      "t": 178200,
      "e": 166374,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 178200,
      "e": 166374,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#strategyButton"
    },
    {
      "t": 178263,
      "e": 166437,
      "ty": 41,
      "x": 60295,
      "y": 48699,
      "ta": "#strategyButton"
    },
    {
      "t": 178295,
      "e": 166469,
      "ty": 4,
      "x": 60295,
      "y": 48699,
      "ta": "#strategyButton"
    },
    {
      "t": 178310,
      "e": 166484,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#strategyButton"
    },
    {
      "t": 178312,
      "e": 166486,
      "ty": 5,
      "x": 449,
      "y": 680,
      "ta": "#strategyButton"
    },
    {
      "t": 178317,
      "e": 166491,
      "ty": 38,
      "x": 1,
      "y": 0
    },
    {
      "t": 179212,
      "e": 167386,
      "ty": 2,
      "x": 448,
      "y": 680
    },
    {
      "t": 179263,
      "e": 167437,
      "ty": 41,
      "x": 15152,
      "y": 37226,
      "ta": "html > body"
    },
    {
      "t": 179317,
      "e": 167491,
      "ty": 38,
      "x": 2,
      "y": 0
    },
    {
      "t": 180013,
      "e": 168187,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 180213,
      "e": 168387,
      "ty": 2,
      "x": 459,
      "y": 677
    },
    {
      "t": 180264,
      "e": 168438,
      "ty": 41,
      "x": 16392,
      "y": 36673,
      "ta": "html > body"
    },
    {
      "t": 180313,
      "e": 168487,
      "ty": 2,
      "x": 568,
      "y": 641
    },
    {
      "t": 180413,
      "e": 168587,
      "ty": 2,
      "x": 731,
      "y": 600
    },
    {
      "t": 180517,
      "e": 168691,
      "ty": 2,
      "x": 771,
      "y": 585
    },
    {
      "t": 180517,
      "e": 168691,
      "ty": 41,
      "x": 26275,
      "y": 31964,
      "ta": "html > body"
    },
    {
      "t": 180603,
      "e": 168777,
      "ty": 6,
      "x": 826,
      "y": 568,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 180616,
      "e": 168790,
      "ty": 2,
      "x": 826,
      "y": 568
    },
    {
      "t": 180716,
      "e": 168890,
      "ty": 2,
      "x": 838,
      "y": 563
    },
    {
      "t": 180766,
      "e": 168940,
      "ty": 41,
      "x": 6488,
      "y": 28086,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 180947,
      "e": 169121,
      "ty": 3,
      "x": 838,
      "y": 563,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 180948,
      "e": 169122,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 181050,
      "e": 169224,
      "ty": 4,
      "x": 6488,
      "y": 28086,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 181050,
      "e": 169224,
      "ty": 5,
      "x": 838,
      "y": 563,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 183135,
      "e": 171309,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "49"
    },
    {
      "t": 183135,
      "e": 171309,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 183262,
      "e": 171436,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "1"
    },
    {
      "t": 183310,
      "e": 171484,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "56"
    },
    {
      "t": 183310,
      "e": 171484,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 183398,
      "e": 171572,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "18"
    },
    {
      "t": 183997,
      "e": 172171,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "8"
    },
    {
      "t": 184110,
      "e": 172284,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "1"
    },
    {
      "t": 184511,
      "e": 172685,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "57"
    },
    {
      "t": 184511,
      "e": 172685,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 184606,
      "e": 172780,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "19"
    },
    {
      "t": 184854,
      "e": 173028,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "9"
    },
    {
      "t": 184855,
      "e": 173029,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "19"
    },
    {
      "t": 184856,
      "e": 173030,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 184857,
      "e": 173031,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 184966,
      "e": 173140,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": ""
    },
    {
      "t": 186110,
      "e": 174284,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "16"
    },
    {
      "t": 186263,
      "e": 174437,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "85"
    },
    {
      "t": 186263,
      "e": 174437,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 186358,
      "e": 174532,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "U"
    },
    {
      "t": 186422,
      "e": 174596,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "U"
    },
    {
      "t": 186462,
      "e": 174636,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "78"
    },
    {
      "t": 186464,
      "e": 174638,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 186574,
      "e": 174748,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "73"
    },
    {
      "t": 186574,
      "e": 174748,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 186711,
      "e": 174885,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "Uni"
    },
    {
      "t": 186734,
      "e": 174908,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "Uni"
    },
    {
      "t": 186966,
      "e": 175140,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "84"
    },
    {
      "t": 186967,
      "e": 175141,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 187086,
      "e": 175260,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "69"
    },
    {
      "t": 187086,
      "e": 175260,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 187109,
      "e": 175283,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "Unite"
    },
    {
      "t": 187198,
      "e": 175372,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "+||"
    },
    {
      "t": 187302,
      "e": 175476,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "68"
    },
    {
      "t": 187304,
      "e": 175478,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 187382,
      "e": 175556,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "+||d"
    },
    {
      "t": 187421,
      "e": 175595,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "32"
    },
    {
      "t": 187422,
      "e": 175596,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 187559,
      "e": 175733,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "+|| "
    },
    {
      "t": 187759,
      "e": 175933,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "16"
    },
    {
      "t": 187863,
      "e": 176037,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "83"
    },
    {
      "t": 187863,
      "e": 176037,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 187957,
      "e": 176131,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "+||S"
    },
    {
      "t": 188070,
      "e": 176244,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "+||"
    },
    {
      "t": 188095,
      "e": 176269,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "84"
    },
    {
      "t": 188095,
      "e": 176269,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 188158,
      "e": 176332,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "65"
    },
    {
      "t": 188158,
      "e": 176332,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 188206,
      "e": 176380,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "+||ta"
    },
    {
      "t": 188398,
      "e": 176572,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "+||"
    },
    {
      "t": 188487,
      "e": 176661,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "84"
    },
    {
      "t": 188488,
      "e": 176662,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 188590,
      "e": 176764,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "69"
    },
    {
      "t": 188590,
      "e": 176764,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 188645,
      "e": 176819,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "+||te"
    },
    {
      "t": 188703,
      "e": 176877,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "83"
    },
    {
      "t": 188703,
      "e": 176877,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 188734,
      "e": 176908,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "+||s"
    },
    {
      "t": 188838,
      "e": 177012,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "32"
    },
    {
      "t": 188839,
      "e": 177013,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 188862,
      "e": 177036,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "+|| "
    },
    {
      "t": 188974,
      "e": 177148,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "+||"
    },
    {
      "t": 189039,
      "e": 177213,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "79"
    },
    {
      "t": 189039,
      "e": 177213,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 189069,
      "e": 177243,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "70"
    },
    {
      "t": 189069,
      "e": 177243,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 189133,
      "e": 177307,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "32"
    },
    {
      "t": 189133,
      "e": 177307,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 189165,
      "e": 177339,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "+||of "
    },
    {
      "t": 189198,
      "e": 177372,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "+||"
    },
    {
      "t": 189294,
      "e": 177468,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "+||"
    },
    {
      "t": 189359,
      "e": 177533,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "16"
    },
    {
      "t": 189431,
      "e": 177605,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "65"
    },
    {
      "t": 189432,
      "e": 177606,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 189525,
      "e": 177699,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "+||A"
    },
    {
      "t": 189550,
      "e": 177724,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "+||"
    },
    {
      "t": 189582,
      "e": 177756,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "77"
    },
    {
      "t": 189582,
      "e": 177756,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 189630,
      "e": 177804,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "69"
    },
    {
      "t": 189630,
      "e": 177804,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 189654,
      "e": 177828,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "+||me"
    },
    {
      "t": 189718,
      "e": 177892,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "82"
    },
    {
      "t": 189720,
      "e": 177894,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 189782,
      "e": 177956,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "+||r"
    },
    {
      "t": 189782,
      "e": 177956,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "73"
    },
    {
      "t": 189782,
      "e": 177956,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 189790,
      "e": 177964,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "+||i"
    },
    {
      "t": 189902,
      "e": 178076,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "+||"
    },
    {
      "t": 189949,
      "e": 178123,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "67"
    },
    {
      "t": 189950,
      "e": 178124,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 189957,
      "e": 178131,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "65"
    },
    {
      "t": 189958,
      "e": 178132,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 189990,
      "e": 178164,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "+||ca"
    },
    {
      "t": 190016,
      "e": 178190,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 190069,
      "e": 178243,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "+||"
    },
    {
      "t": 190534,
      "e": 178708,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "13"
    },
    {
      "t": 190535,
      "e": 178709,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 190638,
      "e": 178812,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "+||\n"
    },
    {
      "t": 191382,
      "e": 179556,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "8"
    },
    {
      "t": 191470,
      "e": 179644,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "United States of America"
    },
    {
      "t": 192415,
      "e": 180589,
      "ty": 2,
      "x": 852,
      "y": 562
    },
    {
      "t": 192479,
      "e": 180653,
      "ty": 7,
      "x": 875,
      "y": 577,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 192516,
      "e": 180690,
      "ty": 2,
      "x": 881,
      "y": 581
    },
    {
      "t": 192516,
      "e": 180690,
      "ty": 41,
      "x": 15788,
      "y": 64125,
      "ta": "#jspsych-survey-text-0"
    },
    {
      "t": 192615,
      "e": 180789,
      "ty": 2,
      "x": 901,
      "y": 618
    },
    {
      "t": 192679,
      "e": 180853,
      "ty": 6,
      "x": 910,
      "y": 647,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 192716,
      "e": 180890,
      "ty": 2,
      "x": 916,
      "y": 662
    },
    {
      "t": 192730,
      "e": 180904,
      "ty": 7,
      "x": 919,
      "y": 670,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 192746,
      "e": 180920,
      "ty": 6,
      "x": 923,
      "y": 679,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 192766,
      "e": 180940,
      "ty": 41,
      "x": 17563,
      "y": 41704,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 192816,
      "e": 180990,
      "ty": 2,
      "x": 934,
      "y": 706
    },
    {
      "t": 193016,
      "e": 181190,
      "ty": 41,
      "x": 19625,
      "y": 59577,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 193315,
      "e": 181489,
      "ty": 3,
      "x": 934,
      "y": 706,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 193316,
      "e": 181490,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "United States of America"
    },
    {
      "t": 193317,
      "e": 181491,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 193318,
      "e": 181492,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 193386,
      "e": 181560,
      "ty": 4,
      "x": 19625,
      "y": 59577,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 193386,
      "e": 181560,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 193387,
      "e": 181561,
      "ty": 5,
      "x": 934,
      "y": 706,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 193387,
      "e": 181561,
      "ty": 38,
      "x": 3,
      "y": 0
    },
    {
      "t": 194402,
      "e": 182576,
      "ty": 38,
      "x": 4,
      "y": 0
    },
    {
      "t": 195616,
      "e": 183790,
      "ty": 2,
      "x": 935,
      "y": 706
    },
    {
      "t": 195766,
      "e": 183940,
      "ty": 41,
      "x": 28619,
      "y": 42597,
      "ta": "#jspsych-survey-multi-choice-option-2-1 > label"
    },
    {
      "t": 195915,
      "e": 184089,
      "ty": 2,
      "x": 928,
      "y": 694
    },
    {
      "t": 196016,
      "e": 184190,
      "ty": 2,
      "x": 852,
      "y": 505
    },
    {
      "t": 196016,
      "e": 184190,
      "ty": 41,
      "x": 27445,
      "y": 52428,
      "ta": "#jspsych-survey-multi-choice-option-1-3 > label"
    },
    {
      "t": 196115,
      "e": 184289,
      "ty": 2,
      "x": 742,
      "y": 52
    },
    {
      "t": 196216,
      "e": 184390,
      "ty": 2,
      "x": 739,
      "y": 0
    },
    {
      "t": 196266,
      "e": 184440,
      "ty": 41,
      "x": 25449,
      "y": 0,
      "ta": "html"
    },
    {
      "t": 196316,
      "e": 184490,
      "ty": 2,
      "x": 756,
      "y": 29
    },
    {
      "t": 196415,
      "e": 184589,
      "ty": 2,
      "x": 809,
      "y": 135
    },
    {
      "t": 196516,
      "e": 184690,
      "ty": 2,
      "x": 841,
      "y": 196
    },
    {
      "t": 196517,
      "e": 184691,
      "ty": 41,
      "x": 4646,
      "y": 39789,
      "ta": "#jspsych-survey-multi-choice-0 > p"
    },
    {
      "t": 196616,
      "e": 184790,
      "ty": 2,
      "x": 853,
      "y": 227
    },
    {
      "t": 196715,
      "e": 184889,
      "ty": 2,
      "x": 856,
      "y": 247
    },
    {
      "t": 196765,
      "e": 184939,
      "ty": 41,
      "x": 8206,
      "y": 60853,
      "ta": "#jspsych-survey-multi-choice-option-0-0"
    },
    {
      "t": 196815,
      "e": 184989,
      "ty": 2,
      "x": 856,
      "y": 252
    },
    {
      "t": 197016,
      "e": 185190,
      "ty": 41,
      "x": 8206,
      "y": 63194,
      "ta": "#jspsych-survey-multi-choice-option-0-0"
    },
    {
      "t": 197116,
      "e": 185290,
      "ty": 2,
      "x": 847,
      "y": 250
    },
    {
      "t": 197216,
      "e": 185390,
      "ty": 2,
      "x": 841,
      "y": 246
    },
    {
      "t": 197266,
      "e": 185440,
      "ty": 6,
      "x": 839,
      "y": 244,
      "ta": "jspsych-survey-multi-choice-response-0[0]_mf"
    },
    {
      "t": 197267,
      "e": 185441,
      "ty": 41,
      "x": 63408,
      "y": 60493,
      "ta": "jspsych-survey-multi-choice-response-0[0]_mf"
    },
    {
      "t": 197316,
      "e": 185490,
      "ty": 2,
      "x": 838,
      "y": 244
    },
    {
      "t": 197416,
      "e": 185590,
      "ty": 2,
      "x": 837,
      "y": 242
    },
    {
      "t": 197491,
      "e": 185665,
      "ty": 3,
      "x": 836,
      "y": 241,
      "ta": "jspsych-survey-multi-choice-response-0[0]_mf"
    },
    {
      "t": 197491,
      "e": 185665,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-0[0]_mf"
    },
    {
      "t": 197515,
      "e": 185689,
      "ty": 2,
      "x": 836,
      "y": 241
    },
    {
      "t": 197515,
      "e": 185689,
      "ty": 41,
      "x": 48284,
      "y": 45370,
      "ta": "jspsych-survey-multi-choice-response-0[0]_mf"
    },
    {
      "t": 197569,
      "e": 185743,
      "ty": 4,
      "x": 48284,
      "y": 45370,
      "ta": "jspsych-survey-multi-choice-response-0[0]_mf"
    },
    {
      "t": 197570,
      "e": 185744,
      "ty": 5,
      "x": 836,
      "y": 241,
      "ta": "jspsych-survey-multi-choice-response-0[0]_mf"
    },
    {
      "t": 197570,
      "e": 185744,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-0[0]_mf",
      "v": "English"
    },
    {
      "t": 197938,
      "e": 186112,
      "ty": 7,
      "x": 836,
      "y": 248,
      "ta": "jspsych-survey-multi-choice-response-0[0]_mf"
    },
    {
      "t": 198015,
      "e": 186189,
      "ty": 2,
      "x": 844,
      "y": 275
    },
    {
      "t": 198016,
      "e": 186190,
      "ty": 41,
      "x": 17195,
      "y": 58981,
      "ta": "#jspsych-survey-multi-choice-option-0-1 > label"
    },
    {
      "t": 198116,
      "e": 186290,
      "ty": 2,
      "x": 872,
      "y": 345
    },
    {
      "t": 198215,
      "e": 186389,
      "ty": 2,
      "x": 882,
      "y": 398
    },
    {
      "t": 198265,
      "e": 186439,
      "ty": 41,
      "x": 14376,
      "y": 30426,
      "ta": "#jspsych-survey-multi-choice-option-1-0"
    },
    {
      "t": 198316,
      "e": 186490,
      "ty": 2,
      "x": 880,
      "y": 422
    },
    {
      "t": 198416,
      "e": 186590,
      "ty": 2,
      "x": 876,
      "y": 428
    },
    {
      "t": 198515,
      "e": 186689,
      "ty": 2,
      "x": 874,
      "y": 430
    },
    {
      "t": 198516,
      "e": 186689,
      "ty": 41,
      "x": 12478,
      "y": 2340,
      "ta": "#jspsych-survey-multi-choice-option-1-1"
    },
    {
      "t": 198616,
      "e": 186789,
      "ty": 2,
      "x": 862,
      "y": 430
    },
    {
      "t": 198681,
      "e": 186854,
      "ty": 6,
      "x": 836,
      "y": 420,
      "ta": "jspsych-survey-multi-choice-response-1[0]_mf"
    },
    {
      "t": 198715,
      "e": 186888,
      "ty": 2,
      "x": 828,
      "y": 416
    },
    {
      "t": 198766,
      "e": 186939,
      "ty": 41,
      "x": 7955,
      "y": 40329,
      "ta": "jspsych-survey-multi-choice-response-1[0]_mf"
    },
    {
      "t": 198916,
      "e": 187089,
      "ty": 2,
      "x": 827,
      "y": 413
    },
    {
      "t": 199016,
      "e": 187189,
      "ty": 2,
      "x": 828,
      "y": 409
    },
    {
      "t": 199016,
      "e": 187189,
      "ty": 41,
      "x": 7955,
      "y": 5041,
      "ta": "jspsych-survey-multi-choice-response-1[0]_mf"
    },
    {
      "t": 201004,
      "e": 189177,
      "ty": 3,
      "x": 828,
      "y": 409,
      "ta": "jspsych-survey-multi-choice-response-1[0]_mf"
    },
    {
      "t": 201005,
      "e": 189178,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-0[0]_mf"
    },
    {
      "t": 201006,
      "e": 189179,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-1[0]_mf"
    },
    {
      "t": 201082,
      "e": 189255,
      "ty": 4,
      "x": 7955,
      "y": 5041,
      "ta": "jspsych-survey-multi-choice-response-1[0]_mf"
    },
    {
      "t": 201082,
      "e": 189255,
      "ty": 5,
      "x": 828,
      "y": 409,
      "ta": "jspsych-survey-multi-choice-response-1[0]_mf"
    },
    {
      "t": 201083,
      "e": 189256,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-1[0]_mf",
      "v": "First"
    },
    {
      "t": 201434,
      "e": 189607,
      "ty": 7,
      "x": 840,
      "y": 426,
      "ta": "jspsych-survey-multi-choice-response-1[0]_mf"
    },
    {
      "t": 201516,
      "e": 189689,
      "ty": 2,
      "x": 893,
      "y": 483
    },
    {
      "t": 201517,
      "e": 189690,
      "ty": 41,
      "x": 16987,
      "y": 60853,
      "ta": "#jspsych-survey-multi-choice-option-1-2"
    },
    {
      "t": 201766,
      "e": 189939,
      "ty": 41,
      "x": 16987,
      "y": 4681,
      "ta": "#jspsych-survey-multi-choice-option-1-3"
    },
    {
      "t": 201816,
      "e": 189989,
      "ty": 2,
      "x": 895,
      "y": 522
    },
    {
      "t": 201915,
      "e": 190088,
      "ty": 2,
      "x": 885,
      "y": 570
    },
    {
      "t": 202016,
      "e": 190189,
      "ty": 2,
      "x": 868,
      "y": 647
    },
    {
      "t": 202016,
      "e": 190189,
      "ty": 41,
      "x": 11054,
      "y": 8665,
      "ta": "#jspsych-survey-multi-choice-2"
    },
    {
      "t": 202116,
      "e": 190289,
      "ty": 2,
      "x": 887,
      "y": 706
    },
    {
      "t": 202266,
      "e": 190439,
      "ty": 41,
      "x": 16524,
      "y": 42597,
      "ta": "#jspsych-survey-multi-choice-option-2-1 > label"
    },
    {
      "t": 202716,
      "e": 190889,
      "ty": 2,
      "x": 885,
      "y": 709
    },
    {
      "t": 202767,
      "e": 190940,
      "ty": 41,
      "x": 16020,
      "y": 52428,
      "ta": "#jspsych-survey-multi-choice-option-2-1 > label"
    },
    {
      "t": 202816,
      "e": 190989,
      "ty": 2,
      "x": 885,
      "y": 710
    },
    {
      "t": 202916,
      "e": 191089,
      "ty": 2,
      "x": 885,
      "y": 711
    },
    {
      "t": 203017,
      "e": 191190,
      "ty": 41,
      "x": 16020,
      "y": 58981,
      "ta": "#jspsych-survey-multi-choice-option-2-1 > label"
    },
    {
      "t": 204316,
      "e": 192489,
      "ty": 2,
      "x": 878,
      "y": 711
    },
    {
      "t": 204416,
      "e": 192589,
      "ty": 2,
      "x": 847,
      "y": 711
    },
    {
      "t": 204516,
      "e": 192689,
      "ty": 2,
      "x": 846,
      "y": 711
    },
    {
      "t": 204516,
      "e": 192689,
      "ty": 41,
      "x": 6193,
      "y": 58981,
      "ta": "#jspsych-survey-multi-choice-option-2-1 > label"
    },
    {
      "t": 204766,
      "e": 192939,
      "ty": 41,
      "x": 5185,
      "y": 58981,
      "ta": "#jspsych-survey-multi-choice-option-2-1 > label"
    },
    {
      "t": 204816,
      "e": 192989,
      "ty": 2,
      "x": 841,
      "y": 711
    },
    {
      "t": 204916,
      "e": 193089,
      "ty": 2,
      "x": 837,
      "y": 709
    },
    {
      "t": 204995,
      "e": 193168,
      "ty": 6,
      "x": 836,
      "y": 708,
      "ta": "jspsych-survey-multi-choice-response-2[1]_mf"
    },
    {
      "t": 205016,
      "e": 193189,
      "ty": 2,
      "x": 836,
      "y": 708
    },
    {
      "t": 205017,
      "e": 193190,
      "ty": 41,
      "x": 48284,
      "y": 60493,
      "ta": "jspsych-survey-multi-choice-response-2[1]_mf"
    },
    {
      "t": 205116,
      "e": 193289,
      "ty": 2,
      "x": 836,
      "y": 706
    },
    {
      "t": 205195,
      "e": 193368,
      "ty": 3,
      "x": 836,
      "y": 706,
      "ta": "jspsych-survey-multi-choice-response-2[1]_mf"
    },
    {
      "t": 205196,
      "e": 193369,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-1[0]_mf"
    },
    {
      "t": 205196,
      "e": 193369,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-2[1]_mf"
    },
    {
      "t": 205266,
      "e": 193439,
      "ty": 41,
      "x": 48284,
      "y": 50411,
      "ta": "jspsych-survey-multi-choice-response-2[1]_mf"
    },
    {
      "t": 205290,
      "e": 193463,
      "ty": 4,
      "x": 48284,
      "y": 50411,
      "ta": "jspsych-survey-multi-choice-response-2[1]_mf"
    },
    {
      "t": 205290,
      "e": 193463,
      "ty": 5,
      "x": 836,
      "y": 706,
      "ta": "jspsych-survey-multi-choice-response-2[1]_mf"
    },
    {
      "t": 205290,
      "e": 193463,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-2[1]_mf",
      "v": "Social Sciences (incl. CogSci)"
    },
    {
      "t": 205658,
      "e": 193831,
      "ty": 7,
      "x": 839,
      "y": 709,
      "ta": "jspsych-survey-multi-choice-response-2[1]_mf"
    },
    {
      "t": 205715,
      "e": 193888,
      "ty": 2,
      "x": 859,
      "y": 737
    },
    {
      "t": 205767,
      "e": 193940,
      "ty": 41,
      "x": 13664,
      "y": 56172,
      "ta": "#jspsych-survey-multi-choice-option-2-3"
    },
    {
      "t": 205816,
      "e": 193989,
      "ty": 2,
      "x": 884,
      "y": 787
    },
    {
      "t": 205915,
      "e": 194088,
      "ty": 2,
      "x": 892,
      "y": 828
    },
    {
      "t": 206016,
      "e": 194189,
      "ty": 2,
      "x": 891,
      "y": 898
    },
    {
      "t": 206016,
      "e": 194189,
      "ty": 41,
      "x": 16512,
      "y": 53832,
      "ta": "#jspsych-survey-multi-choice-3 > p"
    },
    {
      "t": 206116,
      "e": 194289,
      "ty": 2,
      "x": 883,
      "y": 921
    },
    {
      "t": 206266,
      "e": 194439,
      "ty": 41,
      "x": 14614,
      "y": 0,
      "ta": "#jspsych-survey-multi-choice-option-3-0"
    },
    {
      "t": 206516,
      "e": 194689,
      "ty": 2,
      "x": 882,
      "y": 922
    },
    {
      "t": 206516,
      "e": 194689,
      "ty": 41,
      "x": 14376,
      "y": 2340,
      "ta": "#jspsych-survey-multi-choice-option-3-0"
    },
    {
      "t": 206616,
      "e": 194789,
      "ty": 2,
      "x": 858,
      "y": 932
    },
    {
      "t": 206716,
      "e": 194889,
      "ty": 2,
      "x": 842,
      "y": 934
    },
    {
      "t": 206759,
      "e": 194932,
      "ty": 6,
      "x": 839,
      "y": 934,
      "ta": "jspsych-survey-multi-choice-response-3[0]_mf"
    },
    {
      "t": 206766,
      "e": 194939,
      "ty": 41,
      "x": 63408,
      "y": 30246,
      "ta": "jspsych-survey-multi-choice-response-3[0]_mf"
    },
    {
      "t": 206816,
      "e": 194989,
      "ty": 2,
      "x": 838,
      "y": 934
    },
    {
      "t": 206916,
      "e": 195089,
      "ty": 2,
      "x": 837,
      "y": 934
    },
    {
      "t": 206987,
      "e": 195160,
      "ty": 3,
      "x": 837,
      "y": 934,
      "ta": "jspsych-survey-multi-choice-response-3[0]_mf"
    },
    {
      "t": 206988,
      "e": 195161,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-2[1]_mf"
    },
    {
      "t": 206988,
      "e": 195161,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-3[0]_mf"
    },
    {
      "t": 207016,
      "e": 195189,
      "ty": 41,
      "x": 53325,
      "y": 30246,
      "ta": "jspsych-survey-multi-choice-response-3[0]_mf"
    },
    {
      "t": 207065,
      "e": 195238,
      "ty": 4,
      "x": 53325,
      "y": 30246,
      "ta": "jspsych-survey-multi-choice-response-3[0]_mf"
    },
    {
      "t": 207066,
      "e": 195239,
      "ty": 5,
      "x": 837,
      "y": 934,
      "ta": "jspsych-survey-multi-choice-response-3[0]_mf"
    },
    {
      "t": 207066,
      "e": 195239,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-3[0]_mf",
      "v": "Male"
    },
    {
      "t": 207208,
      "e": 195381,
      "ty": 7,
      "x": 837,
      "y": 942,
      "ta": "jspsych-survey-multi-choice-response-3[0]_mf"
    },
    {
      "t": 207216,
      "e": 195381,
      "ty": 2,
      "x": 837,
      "y": 942
    },
    {
      "t": 207266,
      "e": 195431,
      "ty": 41,
      "x": 26353,
      "y": 49151,
      "ta": "#jspsych-survey-multi-choice-option-3-1 > label"
    },
    {
      "t": 207316,
      "e": 195481,
      "ty": 2,
      "x": 863,
      "y": 995
    },
    {
      "t": 207374,
      "e": 195539,
      "ty": 6,
      "x": 866,
      "y": 1007,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 207416,
      "e": 195581,
      "ty": 2,
      "x": 867,
      "y": 1017
    },
    {
      "t": 207514,
      "e": 195679,
      "ty": 7,
      "x": 875,
      "y": 1038,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 207515,
      "e": 195680,
      "ty": 2,
      "x": 875,
      "y": 1038
    },
    {
      "t": 207516,
      "e": 195681,
      "ty": 41,
      "x": 29857,
      "y": 57059,
      "ta": "html > body"
    },
    {
      "t": 207716,
      "e": 195881,
      "ty": 2,
      "x": 876,
      "y": 1038
    },
    {
      "t": 207741,
      "e": 195906,
      "ty": 6,
      "x": 877,
      "y": 1037,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 207766,
      "e": 195931,
      "ty": 41,
      "x": 24521,
      "y": 61563,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 207816,
      "e": 195981,
      "ty": 2,
      "x": 880,
      "y": 1032
    },
    {
      "t": 207916,
      "e": 196081,
      "ty": 2,
      "x": 882,
      "y": 1029
    },
    {
      "t": 208016,
      "e": 196181,
      "ty": 2,
      "x": 887,
      "y": 1022
    },
    {
      "t": 208016,
      "e": 196181,
      "ty": 41,
      "x": 29675,
      "y": 33760,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 208132,
      "e": 196297,
      "ty": 3,
      "x": 887,
      "y": 1022,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 208133,
      "e": 196298,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-3[0]_mf"
    },
    {
      "t": 208134,
      "e": 196299,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 208218,
      "e": 196383,
      "ty": 4,
      "x": 29675,
      "y": 33760,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 208218,
      "e": 196383,
      "ty": 5,
      "x": 887,
      "y": 1022,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 208220,
      "e": 196385,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 208220,
      "e": 196385,
      "ty": 13,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-multi-choice-form"
    },
    {
      "t": 208221,
      "e": 196386,
      "ty": 38,
      "x": 5,
      "y": 0
    },
    {
      "t": 209571,
      "e": 197736,
      "ty": 38,
      "x": 6,
      "y": 0
    },
    {
      "t": 210717,
      "e": 198882,
      "ty": 2,
      "x": 888,
      "y": 1022
    },
    {
      "t": 210766,
      "e": 198931,
      "ty": 41,
      "x": 29249,
      "y": 62025,
      "ta": "> div.masterdiv > div:[2]"
    },
    {
      "t": 210817,
      "e": 198982,
      "ty": 2,
      "x": 895,
      "y": 1029
    },
    {
      "t": 210916,
      "e": 199081,
      "ty": 2,
      "x": 913,
      "y": 1044
    },
    {
      "t": 211016,
      "e": 199181,
      "ty": 2,
      "x": 925,
      "y": 1064
    },
    {
      "t": 211016,
      "e": 199181,
      "ty": 41,
      "x": 31070,
      "y": 64933,
      "ta": "> div.masterdiv > div:[2]"
    },
    {
      "t": 211059,
      "e": 199224,
      "ty": 6,
      "x": 930,
      "y": 1074,
      "ta": "#start"
    },
    {
      "t": 211116,
      "e": 199281,
      "ty": 2,
      "x": 937,
      "y": 1085
    },
    {
      "t": 211216,
      "e": 199381,
      "ty": 2,
      "x": 939,
      "y": 1088
    },
    {
      "t": 211267,
      "e": 199432,
      "ty": 41,
      "x": 16110,
      "y": 29514,
      "ta": "#start"
    },
    {
      "t": 220015,
      "e": 204432,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 278455,
      "e": 204432,
      "ty": 3,
      "x": 939,
      "y": 1088,
      "ta": "#start"
    },
    {
      "t": 278456,
      "e": 204433,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#start"
    },
    {
      "t": 278540,
      "e": 204517,
      "ty": 4,
      "x": 16110,
      "y": 29514,
      "ta": "#start"
    },
    {
      "t": 278540,
      "e": 204517,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#start"
    },
    {
      "t": 278542,
      "e": 204519,
      "ty": 5,
      "x": 939,
      "y": 1088,
      "ta": "#start"
    },
    {
      "t": 278542,
      "e": 204519,
      "ty": 38,
      "x": 7,
      "y": 0
    },
    {
      "t": 279568,
      "e": 205545,
      "ty": 38,
      "x": 8,
      "y": 0
    },
    {
      "t": 280962,
      "e": 206939,
      "ty": 20,
      "x": 0,
      "y": 0
    }
  ],
  "domMutations": [
    {
      "sequence": 1,
      "data": "{\"f\":\"applyChanged\",\"args\":[[{\"id\":56},{\"id\":57},{\"id\":58},{\"id\":59},{\"id\":60},{\"id\":61},{\"id\":62},{\"id\":63},{\"id\":64},{\"id\":65},{\"id\":66},{\"id\":67},{\"id\":68},{\"id\":69},{\"id\":70},{\"id\":71},{\"id\":72},{\"id\":73},{\"id\":74},{\"id\":75},{\"id\":76},{\"id\":77},{\"id\":78},{\"id\":79},{\"id\":80},{\"id\":81},{\"id\":82},{\"id\":83},{\"id\":84},{\"id\":85},{\"id\":86},{\"id\":87},{\"id\":88},{\"id\":89},{\"id\":90},{\"id\":91},{\"id\":92},{\"id\":93},{\"id\":94},{\"id\":95},{\"id\":96},{\"id\":97},{\"id\":98},{\"id\":99},{\"id\":100},{\"id\":101},{\"id\":102},{\"id\":103},{\"id\":104},{\"id\":105},{\"id\":106},{\"id\":107},{\"id\":108},{\"id\":109},{\"id\":110},{\"id\":111},{\"id\":112},{\"id\":113},{\"id\":114},{\"id\":115},{\"id\":116},{\"id\":117},{\"id\":118},{\"id\":119},{\"id\":120},{\"id\":121},{\"id\":122},{\"id\":123},{\"id\":124},{\"id\":125},{\"id\":126},{\"id\":127},{\"id\":128},{\"id\":129},{\"id\":130},{\"id\":131},{\"id\":132},{\"id\":133},{\"id\":134},{\"id\":135},{\"id\":136},{\"id\":137},{\"id\":138},{\"id\":139},{\"id\":140},{\"id\":141},{\"id\":142},{\"id\":143},{\"id\":144},{\"id\":145},{\"id\":146},{\"id\":147},{\"id\":148},{\"id\":149},{\"id\":150},{\"id\":151},{\"id\":152},{\"id\":153},{\"id\":154},{\"id\":155},{\"id\":156},{\"id\":157},{\"id\":158},{\"id\":159},{\"id\":160},{\"id\":161},{\"id\":162},{\"id\":163},{\"id\":164},{\"id\":165},{\"id\":166},{\"id\":167},{\"id\":168},{\"id\":169},{\"id\":170},{\"id\":171},{\"id\":172},{\"id\":173},{\"id\":174},{\"id\":175},{\"id\":176},{\"id\":177},{\"id\":178},{\"id\":179},{\"id\":180},{\"id\":181},{\"id\":182},{\"id\":183},{\"id\":184},{\"id\":185},{\"id\":186},{\"id\":187},{\"id\":188},{\"id\":189},{\"id\":190},{\"id\":191},{\"id\":192},{\"id\":193},{\"id\":194},{\"id\":195},{\"id\":196},{\"id\":197},{\"id\":198},{\"id\":199},{\"id\":200},{\"id\":201},{\"id\":202},{\"id\":203},{\"id\":204},{\"id\":205},{\"id\":206},{\"id\":207},{\"id\":208},{\"id\":209},{\"id\":210},{\"id\":211},{\"id\":212},{\"id\":213},{\"id\":214},{\"id\":215},{\"id\":216},{\"id\":217},{\"id\":218},{\"id\":219},{\"id\":220},{\"id\":221},{\"id\":222},{\"id\":223},{\"id\":224},{\"id\":225},{\"id\":226},{\"id\":227},{\"id\":228},{\"id\":229},{\"id\":230},{\"id\":231},{\"id\":232},{\"id\":233},{\"id\":234},{\"id\":235},{\"id\":236},{\"id\":237},{\"id\":238},{\"id\":239},{\"id\":240},{\"id\":241},{\"id\":242},{\"id\":243},{\"id\":244},{\"id\":245},{\"id\":246},{\"id\":247},{\"id\":248},{\"id\":249},{\"id\":250},{\"id\":251},{\"id\":252},{\"id\":253},{\"id\":254},{\"id\":255},{\"id\":256},{\"id\":257},{\"id\":258},{\"id\":259},{\"id\":260},{\"id\":261},{\"id\":262},{\"id\":263},{\"id\":264},{\"id\":265},{\"id\":266},{\"id\":267},{\"id\":268},{\"id\":269},{\"id\":270},{\"id\":271},{\"id\":272},{\"id\":273},{\"id\":274},{\"id\":275},{\"id\":276},{\"id\":277},{\"id\":278},{\"id\":279},{\"id\":280},{\"id\":281},{\"id\":282},{\"id\":283},{\"id\":284},{\"id\":285},{\"id\":286},{\"id\":287},{\"id\":288},{\"id\":289},{\"id\":290},{\"id\":291},{\"id\":292},{\"id\":293},{\"id\":294},{\"id\":295},{\"id\":296},{\"id\":297},{\"id\":298},{\"id\":299},{\"id\":300},{\"id\":301},{\"id\":302},{\"id\":303},{\"id\":304},{\"id\":305},{\"id\":306},{\"id\":307},{\"id\":308},{\"id\":309},{\"id\":310},{\"id\":311},{\"id\":312},{\"id\":313},{\"id\":314},{\"id\":315},{\"id\":316},{\"id\":317},{\"id\":318},{\"id\":319},{\"id\":320},{\"id\":321},{\"id\":322},{\"id\":323},{\"id\":324},{\"id\":325},{\"id\":326},{\"id\":327},{\"id\":328},{\"id\":329},{\"id\":330},{\"id\":331},{\"id\":332},{\"id\":333},{\"id\":334},{\"id\":335},{\"id\":336},{\"id\":337},{\"id\":338},{\"id\":339},{\"id\":340},{\"id\":341},{\"id\":342},{\"id\":343},{\"id\":344},{\"id\":345},{\"id\":346},{\"id\":347},{\"id\":348},{\"id\":349},{\"id\":350},{\"id\":351},{\"id\":352},{\"id\":353},{\"id\":354},{\"id\":355},{\"id\":356},{\"id\":357},{\"id\":358},{\"id\":359},{\"id\":360},{\"id\":361},{\"id\":362},{\"id\":363},{\"id\":364},{\"id\":365},{\"id\":366},{\"id\":367},{\"id\":368},{\"id\":369},{\"id\":370},{\"id\":371},{\"id\":372},{\"id\":373},{\"id\":374},{\"id\":375},{\"id\":376},{\"id\":377},{\"id\":378},{\"id\":379},{\"id\":380},{\"id\":381},{\"id\":382},{\"id\":383},{\"id\":384},{\"id\":385},{\"id\":386},{\"id\":387},{\"id\":388},{\"id\":389},{\"id\":390},{\"id\":391},{\"id\":392},{\"id\":393},{\"id\":394},{\"id\":395},{\"id\":396},{\"id\":397},{\"id\":398},{\"id\":399},{\"id\":400},{\"id\":401},{\"id\":402},{\"id\":403},{\"id\":404},{\"id\":405},{\"id\":406},{\"id\":407},{\"id\":408},{\"id\":409},{\"id\":410},{\"id\":411},{\"id\":412},{\"id\":413},{\"id\":414},{\"id\":415},{\"id\":416},{\"id\":417},{\"id\":418},{\"id\":419},{\"id\":420},{\"id\":421},{\"id\":422},{\"id\":423},{\"id\":424},{\"id\":425},{\"id\":426},{\"id\":427},{\"id\":428},{\"id\":429},{\"id\":430},{\"id\":431},{\"id\":432},{\"id\":433},{\"id\":434},{\"id\":435},{\"id\":436},{\"id\":437},{\"id\":438},{\"id\":439},{\"id\":440},{\"id\":441},{\"id\":442},{\"id\":443},{\"id\":444},{\"id\":445},{\"id\":446},{\"id\":447},{\"id\":448},{\"id\":449},{\"id\":450},{\"id\":451},{\"id\":452},{\"id\":453},{\"id\":454},{\"id\":455},{\"id\":456},{\"id\":457},{\"id\":458},{\"id\":459},{\"id\":460},{\"id\":461},{\"id\":462},{\"id\":463},{\"id\":464},{\"id\":465},{\"id\":466},{\"id\":467},{\"id\":468},{\"id\":469},{\"id\":470},{\"id\":471},{\"id\":472},{\"id\":473},{\"id\":474},{\"id\":475},{\"id\":476},{\"id\":477},{\"id\":478},{\"id\":479},{\"id\":480},{\"id\":481},{\"id\":482},{\"id\":483},{\"id\":484},{\"id\":485},{\"id\":486},{\"id\":487},{\"id\":488},{\"id\":489},{\"id\":490},{\"id\":491},{\"id\":492},{\"id\":493},{\"id\":494},{\"id\":495},{\"id\":496},{\"id\":497},{\"id\":498},{\"id\":499},{\"id\":500},{\"id\":501},{\"id\":502},{\"id\":503},{\"id\":504},{\"id\":505},{\"id\":506},{\"id\":507},{\"id\":508},{\"id\":509},{\"id\":510},{\"id\":511},{\"id\":512},{\"id\":513},{\"id\":514},{\"id\":515},{\"id\":516},{\"id\":517},{\"id\":518},{\"id\":519},{\"id\":520},{\"id\":521},{\"id\":522},{\"id\":523},{\"id\":524},{\"id\":525},{\"id\":526},{\"id\":527},{\"id\":528},{\"id\":529},{\"id\":530},{\"id\":531},{\"id\":532},{\"id\":533},{\"id\":534},{\"id\":535},{\"id\":536},{\"id\":537},{\"id\":538},{\"id\":539},{\"id\":540},{\"id\":541},{\"id\":542},{\"id\":543},{\"id\":544},{\"id\":545},{\"id\":546},{\"id\":547},{\"id\":548},{\"id\":549},{\"id\":550},{\"id\":551},{\"id\":552},{\"id\":553},{\"id\":554},{\"id\":555},{\"id\":556},{\"id\":557},{\"id\":558},{\"id\":559},{\"id\":560},{\"id\":561},{\"id\":562},{\"id\":563},{\"id\":564},{\"id\":565},{\"id\":566},{\"id\":567},{\"id\":568},{\"id\":569},{\"id\":570},{\"id\":571},{\"id\":572},{\"id\":573},{\"id\":574},{\"id\":575},{\"id\":576},{\"id\":577},{\"id\":578},{\"id\":579},{\"id\":580},{\"id\":581},{\"id\":582},{\"id\":583},{\"id\":584},{\"id\":585},{\"id\":586},{\"id\":587},{\"id\":588},{\"id\":589},{\"id\":590},{\"id\":591},{\"id\":592},{\"id\":593},{\"id\":594},{\"id\":595},{\"id\":596},{\"id\":597},{\"id\":598},{\"id\":599},{\"id\":600},{\"id\":601},{\"id\":602},{\"id\":603},{\"id\":604},{\"id\":605},{\"id\":606},{\"id\":607},{\"id\":608},{\"id\":609},{\"id\":610},{\"id\":611},{\"id\":612},{\"id\":613},{\"id\":614},{\"id\":615},{\"id\":616},{\"id\":617},{\"id\":618},{\"id\":619},{\"id\":620},{\"id\":621},{\"id\":622},{\"id\":623},{\"id\":624},{\"id\":625},{\"id\":626},{\"id\":627},{\"id\":628},{\"id\":629},{\"id\":630},{\"id\":631},{\"id\":632},{\"id\":633},{\"id\":634},{\"id\":635},{\"id\":636},{\"id\":637},{\"id\":638},{\"id\":639},{\"id\":640},{\"id\":641},{\"id\":642},{\"id\":643},{\"id\":644},{\"id\":645},{\"id\":646},{\"id\":647},{\"id\":648},{\"id\":649},{\"id\":650},{\"id\":651},{\"id\":652},{\"id\":653},{\"id\":654},{\"id\":655},{\"id\":656},{\"id\":657},{\"id\":658},{\"id\":659},{\"id\":660},{\"id\":661},{\"id\":662},{\"id\":663},{\"id\":664},{\"id\":665},{\"id\":666},{\"id\":667},{\"id\":668},{\"id\":669},{\"id\":670},{\"id\":671},{\"id\":672},{\"id\":673},{\"id\":674},{\"id\":675},{\"id\":676},{\"id\":677},{\"id\":678},{\"id\":679},{\"id\":680},{\"id\":681},{\"id\":682},{\"id\":683},{\"id\":684},{\"id\":685},{\"id\":686},{\"id\":687},{\"id\":688},{\"id\":689},{\"id\":690},{\"id\":691},{\"id\":692},{\"id\":693},{\"id\":694},{\"id\":695},{\"id\":696},{\"id\":697},{\"id\":698},{\"id\":699},{\"id\":700},{\"id\":701},{\"id\":702},{\"id\":703},{\"id\":704},{\"id\":705},{\"id\":706},{\"id\":707},{\"id\":708},{\"id\":709},{\"id\":710},{\"id\":711},{\"id\":712},{\"id\":713},{\"id\":714},{\"id\":715},{\"id\":716},{\"id\":717},{\"id\":718},{\"id\":719},{\"id\":720},{\"id\":721},{\"id\":722},{\"id\":723},{\"id\":724},{\"id\":725},{\"id\":726},{\"id\":727},{\"id\":728},{\"id\":729},{\"id\":730},{\"id\":731},{\"id\":732},{\"id\":733},{\"id\":734},{\"id\":735},{\"id\":736},{\"id\":737},{\"id\":738},{\"id\":739},{\"id\":740},{\"id\":741},{\"id\":742},{\"id\":743},{\"id\":744},{\"id\":745},{\"id\":746},{\"id\":747},{\"id\":748},{\"id\":749},{\"id\":750},{\"id\":751},{\"id\":752},{\"id\":753},{\"id\":754},{\"id\":755},{\"id\":756},{\"id\":757},{\"id\":758},{\"id\":759},{\"id\":760},{\"id\":761},{\"id\":762},{\"id\":763},{\"id\":764},{\"id\":765},{\"id\":766},{\"id\":767},{\"id\":768},{\"id\":769},{\"id\":770},{\"id\":771},{\"id\":772},{\"id\":773},{\"id\":774},{\"id\":775},{\"id\":776},{\"id\":777},{\"id\":778},{\"id\":779},{\"id\":780},{\"id\":781},{\"id\":782},{\"id\":783},{\"id\":784},{\"id\":785},{\"id\":786},{\"id\":787},{\"id\":788},{\"id\":789},{\"id\":790},{\"id\":791},{\"id\":792},{\"id\":793},{\"id\":794},{\"id\":795},{\"id\":796},{\"id\":797},{\"id\":798},{\"id\":799},{\"id\":800},{\"id\":801},{\"id\":802},{\"id\":803},{\"id\":804},{\"id\":805},{\"id\":806},{\"id\":807},{\"id\":808},{\"id\":809},{\"id\":810},{\"id\":811},{\"id\":812},{\"id\":813},{\"id\":814},{\"id\":815},{\"id\":816},{\"id\":817},{\"id\":818},{\"id\":819},{\"id\":820},{\"id\":821},{\"id\":822},{\"id\":823},{\"id\":824},{\"id\":825},{\"id\":826},{\"id\":827},{\"id\":828},{\"id\":829},{\"id\":830},{\"id\":831},{\"id\":832},{\"id\":833},{\"id\":834},{\"id\":835},{\"id\":836},{\"id\":837},{\"id\":838},{\"id\":839},{\"id\":840},{\"id\":841},{\"id\":842},{\"id\":843},{\"id\":844},{\"id\":845},{\"id\":846},{\"id\":847},{\"id\":848},{\"id\":849},{\"id\":850},{\"id\":851},{\"id\":852},{\"id\":853},{\"id\":854},{\"id\":855},{\"id\":856},{\"id\":857},{\"id\":858},{\"id\":859},{\"id\":860},{\"id\":861},{\"id\":862},{\"id\":863},{\"id\":864},{\"id\":865},{\"id\":866},{\"id\":867},{\"id\":868},{\"id\":869},{\"id\":870},{\"id\":871},{\"id\":872},{\"id\":873},{\"id\":874},{\"id\":875},{\"id\":876},{\"id\":877},{\"id\":878},{\"id\":879},{\"id\":880},{\"id\":881},{\"id\":882},{\"id\":883},{\"id\":884},{\"id\":885},{\"id\":886},{\"id\":887},{\"id\":888},{\"id\":889},{\"id\":890},{\"id\":891},{\"id\":892},{\"id\":893},{\"id\":894},{\"id\":895},{\"id\":896},{\"id\":897},{\"id\":898},{\"id\":899},{\"id\":900},{\"id\":901},{\"id\":902},{\"id\":903},{\"id\":904},{\"id\":905},{\"id\":906},{\"id\":907},{\"id\":908},{\"id\":909},{\"id\":910},{\"id\":911},{\"id\":912},{\"id\":913},{\"id\":914},{\"id\":915},{\"id\":916},{\"id\":917},{\"id\":918},{\"id\":919},{\"id\":920},{\"id\":921},{\"id\":922},{\"id\":923},{\"id\":924},{\"id\":925},{\"id\":926},{\"id\":927},{\"id\":928},{\"id\":929},{\"id\":930},{\"id\":931},{\"id\":932},{\"id\":933},{\"id\":934},{\"id\":935},{\"id\":936},{\"id\":937},{\"id\":938},{\"id\":939},{\"id\":940},{\"id\":941},{\"id\":942},{\"id\":943},{\"id\":944},{\"id\":945},{\"id\":946},{\"id\":947},{\"id\":948},{\"id\":949},{\"id\":950},{\"id\":951},{\"id\":952},{\"id\":953},{\"id\":954},{\"id\":955},{\"id\":956},{\"id\":957},{\"id\":958},{\"id\":959},{\"id\":960},{\"id\":961},{\"id\":962},{\"id\":963},{\"id\":964},{\"id\":965},{\"id\":966},{\"id\":967},{\"id\":968},{\"id\":969},{\"id\":970},{\"id\":971},{\"id\":972},{\"id\":973},{\"id\":974},{\"id\":975},{\"id\":976},{\"id\":977},{\"id\":978},{\"id\":979},{\"id\":980},{\"id\":981},{\"id\":982},{\"id\":983},{\"id\":984},{\"id\":985},{\"id\":986},{\"id\":987},{\"id\":988},{\"id\":989},{\"id\":990},{\"id\":991},{\"id\":992},{\"id\":993},{\"id\":994},{\"id\":995},{\"id\":996},{\"id\":997},{\"id\":998},{\"id\":999},{\"id\":1000},{\"id\":1001},{\"id\":1002},{\"id\":1003},{\"id\":1004},{\"id\":1005},{\"id\":1006},{\"id\":1007},{\"id\":1008},{\"id\":1009},{\"id\":1010},{\"id\":1011},{\"id\":1012},{\"id\":1013},{\"id\":1014},{\"id\":1015},{\"id\":1016},{\"id\":1017},{\"id\":1018},{\"id\":1019},{\"id\":1020},{\"id\":1021},{\"id\":1022},{\"id\":1023},{\"id\":1024},{\"id\":1025},{\"id\":1026},{\"id\":1027},{\"id\":1028},{\"id\":1029},{\"id\":1030},{\"id\":1031},{\"id\":1032},{\"id\":1033},{\"id\":1034},{\"id\":1035},{\"id\":1036},{\"id\":1037},{\"id\":1038},{\"id\":1039},{\"id\":1040},{\"id\":1041},{\"id\":1042},{\"id\":1043},{\"id\":1044},{\"id\":1045},{\"id\":1046},{\"id\":1047},{\"id\":1048},{\"id\":1049},{\"id\":1050},{\"id\":1051},{\"id\":1052},{\"id\":1053},{\"id\":1054},{\"id\":1055},{\"id\":1056},{\"id\":1057},{\"id\":1058},{\"id\":1059},{\"id\":1060},{\"id\":1061},{\"id\":1062},{\"id\":1063},{\"id\":1064},{\"id\":1065},{\"id\":1066},{\"id\":1067},{\"id\":1068},{\"id\":1069},{\"id\":1070},{\"id\":1071},{\"id\":1072},{\"id\":1073},{\"id\":1074},{\"id\":1075},{\"id\":1076},{\"id\":1077},{\"id\":1078},{\"id\":1079},{\"id\":1080},{\"id\":1081},{\"id\":1082},{\"id\":1083},{\"id\":1084},{\"id\":1085},{\"id\":1086},{\"id\":1087},{\"id\":1088},{\"id\":1089},{\"id\":1090},{\"id\":1091},{\"id\":1092},{\"id\":1093},{\"id\":1094},{\"id\":1095},{\"id\":1096},{\"id\":1097},{\"id\":1098},{\"id\":1099},{\"id\":1100},{\"id\":1101},{\"id\":1102},{\"id\":1103},{\"id\":1104},{\"id\":1105},{\"id\":1106},{\"id\":1107},{\"id\":1108},{\"id\":1109},{\"id\":1110},{\"id\":1111},{\"id\":1112},{\"id\":1113},{\"id\":1114},{\"id\":1115},{\"id\":1116},{\"id\":1117},{\"id\":1118},{\"id\":1119},{\"id\":1120},{\"id\":1121},{\"id\":1122},{\"id\":1123},{\"id\":1124},{\"id\":1125},{\"id\":1126},{\"id\":1127},{\"id\":1128},{\"id\":1129},{\"id\":1130},{\"id\":1131},{\"id\":1132},{\"id\":1133},{\"id\":1134},{\"id\":1135},{\"id\":1136},{\"id\":1137},{\"id\":1138},{\"id\":1139},{\"id\":1140},{\"id\":1141},{\"id\":1142},{\"id\":1143},{\"id\":1144},{\"id\":1145},{\"id\":1146},{\"id\":1147},{\"id\":1148},{\"id\":1149},{\"id\":1150},{\"id\":1151},{\"id\":1152},{\"id\":1153},{\"id\":1154},{\"id\":1155},{\"id\":1156},{\"id\":1157},{\"id\":1158},{\"id\":1159},{\"id\":1160},{\"id\":1161},{\"id\":1162},{\"id\":1163},{\"id\":1164},{\"id\":1165},{\"id\":1166},{\"id\":1167},{\"id\":1168},{\"id\":1169},{\"id\":1170},{\"id\":1171},{\"id\":1172},{\"id\":1173},{\"id\":1174},{\"id\":1175},{\"id\":1176},{\"id\":1177},{\"id\":1178},{\"id\":1179},{\"id\":1180},{\"id\":1181},{\"id\":1182},{\"id\":1183},{\"id\":1184},{\"id\":1185},{\"id\":1186},{\"id\":1187},{\"id\":1188},{\"id\":1189},{\"id\":1190},{\"id\":1191},{\"id\":1192},{\"id\":1193},{\"id\":1194},{\"id\":1195},{\"id\":1196},{\"id\":1197},{\"id\":1198},{\"id\":1199},{\"id\":1200},{\"id\":1201},{\"id\":1202},{\"id\":1203},{\"id\":1204},{\"id\":1205},{\"id\":1206},{\"id\":1207},{\"id\":1208},{\"id\":1209},{\"id\":1210},{\"id\":1211},{\"id\":1212},{\"id\":1213},{\"id\":1214},{\"id\":1215},{\"id\":1216},{\"id\":1217},{\"id\":1218},{\"id\":1219},{\"id\":1220},{\"id\":1221},{\"id\":1222},{\"id\":1223},{\"id\":1224},{\"id\":1225},{\"id\":1226},{\"id\":1227},{\"id\":1228},{\"id\":1229},{\"id\":1230},{\"id\":1231},{\"id\":1232},{\"id\":1233},{\"id\":1234},{\"id\":1235},{\"id\":1236},{\"id\":1237},{\"id\":1238},{\"id\":1239},{\"id\":1240},{\"id\":1241},{\"id\":1242},{\"id\":1243},{\"id\":1244},{\"id\":1245},{\"id\":1246},{\"id\":1247},{\"id\":1248},{\"id\":1249},{\"id\":1250},{\"id\":1251},{\"id\":1252},{\"id\":1253},{\"id\":1254},{\"id\":1255},{\"id\":1256},{\"id\":1257},{\"id\":1258},{\"id\":1259},{\"id\":1260},{\"id\":1261},{\"id\":1262},{\"id\":1263},{\"id\":1264},{\"id\":1265},{\"id\":1266},{\"id\":1267},{\"id\":1268},{\"id\":1269},{\"id\":1270},{\"id\":1271},{\"id\":1272},{\"id\":1273},{\"id\":1274},{\"id\":1275},{\"id\":1276},{\"id\":1277},{\"id\":1278},{\"id\":1279},{\"id\":1280},{\"id\":1281},{\"id\":1282},{\"id\":1283},{\"id\":1284},{\"id\":1285},{\"id\":1286},{\"id\":1287},{\"id\":1288},{\"id\":1289},{\"id\":1290},{\"id\":1291},{\"id\":1292},{\"id\":1293},{\"id\":1294},{\"id\":1295},{\"id\":1296},{\"id\":1297},{\"id\":1298},{\"id\":1299},{\"id\":1300},{\"id\":1301},{\"id\":1302},{\"id\":1303},{\"id\":1304},{\"id\":1305},{\"id\":1306},{\"id\":1307},{\"id\":1308},{\"id\":1309},{\"id\":1310},{\"id\":1311},{\"id\":1312},{\"id\":1313},{\"id\":1314},{\"id\":1315},{\"id\":1316},{\"id\":1317},{\"id\":1318},{\"id\":1319},{\"id\":1320},{\"id\":1321},{\"id\":1322},{\"id\":1323},{\"id\":1324},{\"id\":1325},{\"id\":1326},{\"id\":1327},{\"id\":1328},{\"id\":1329},{\"id\":1330},{\"id\":1331},{\"id\":1332},{\"id\":1333},{\"id\":1334},{\"id\":1335},{\"id\":1336},{\"id\":1337},{\"id\":1338},{\"id\":1339},{\"id\":1340},{\"id\":1341},{\"id\":1342},{\"id\":1343},{\"id\":1344},{\"id\":1345},{\"id\":1346},{\"id\":1347},{\"id\":1348},{\"id\":1349},{\"id\":1350},{\"id\":1351},{\"id\":1352},{\"id\":1353},{\"id\":1354},{\"id\":1355},{\"id\":1356},{\"id\":1357},{\"id\":1358},{\"id\":1359},{\"id\":1360},{\"id\":1361},{\"id\":1362},{\"id\":1363},{\"id\":1364},{\"id\":1365},{\"id\":1366},{\"id\":1367},{\"id\":1368},{\"id\":1369},{\"id\":1370},{\"id\":1371},{\"id\":1372},{\"id\":1373},{\"id\":1374},{\"id\":1375},{\"id\":1376},{\"id\":1377},{\"id\":1378},{\"id\":1379},{\"id\":1380},{\"id\":1381},{\"id\":1382},{\"id\":1383},{\"id\":1384},{\"id\":1385},{\"id\":1386},{\"id\":1387},{\"id\":1388},{\"id\":1389},{\"id\":1390},{\"id\":1391},{\"id\":1392},{\"id\":1393},{\"id\":1394},{\"id\":1395},{\"id\":1396},{\"id\":1397},{\"id\":1398},{\"id\":1399},{\"id\":1400},{\"id\":1401},{\"id\":1402},{\"id\":1403},{\"id\":1404},{\"id\":1405},{\"id\":1406},{\"id\":1407},{\"id\":1408},{\"id\":1409},{\"id\":1410},{\"id\":1411},{\"id\":1412},{\"id\":1413},{\"id\":1414},{\"id\":1415},{\"id\":1416},{\"id\":1417},{\"id\":1418},{\"id\":1419},{\"id\":1420},{\"id\":1421},{\"id\":1422},{\"id\":1423},{\"id\":1424},{\"id\":1425},{\"id\":1426},{\"id\":1427},{\"id\":1428},{\"id\":1429},{\"id\":1430},{\"id\":1431},{\"id\":1432},{\"id\":1433},{\"id\":1434},{\"id\":1435},{\"id\":1436},{\"id\":1437},{\"id\":1438},{\"id\":1439},{\"id\":1440},{\"id\":1441},{\"id\":1442},{\"id\":1443},{\"id\":1444},{\"id\":1445},{\"id\":1446},{\"id\":1447},{\"id\":1448},{\"id\":1449},{\"id\":1450},{\"id\":1451},{\"id\":1452},{\"id\":1453},{\"id\":1454},{\"id\":1455},{\"id\":1456},{\"id\":1457},{\"id\":1458},{\"id\":1459},{\"id\":1460},{\"id\":1461},{\"id\":1462},{\"id\":1463},{\"id\":1464},{\"id\":1465},{\"id\":1466},{\"id\":1467},{\"id\":1468},{\"id\":1469},{\"id\":1470},{\"id\":1471},{\"id\":1472},{\"id\":1473},{\"id\":1474},{\"id\":1475},{\"id\":1476},{\"id\":1477},{\"id\":1478},{\"id\":1479},{\"id\":1480},{\"id\":1481},{\"id\":1482},{\"id\":1483},{\"id\":1484},{\"id\":1485},{\"id\":1486},{\"id\":1487},{\"id\":1488},{\"id\":1489},{\"id\":1490},{\"id\":1491},{\"id\":1492},{\"id\":1493},{\"id\":1494},{\"id\":1495},{\"id\":1496},{\"id\":1497},{\"id\":1498},{\"id\":1499},{\"id\":1500},{\"id\":1501},{\"id\":1502},{\"id\":1503},{\"id\":1504},{\"id\":1505},{\"id\":1506},{\"id\":1507},{\"id\":1508},{\"id\":1509},{\"id\":1510},{\"id\":1511},{\"id\":1512},{\"id\":1513},{\"id\":1514},{\"id\":1515},{\"id\":1516},{\"id\":1517},{\"id\":1518},{\"id\":1519},{\"id\":1520},{\"id\":1521},{\"id\":1522},{\"id\":1523},{\"id\":1524},{\"id\":1525},{\"id\":1526},{\"id\":1527},{\"id\":1528},{\"id\":1529},{\"id\":1530},{\"id\":1531},{\"id\":1532},{\"id\":1533},{\"id\":1534},{\"id\":1535},{\"id\":1536},{\"id\":1537},{\"id\":1538},{\"id\":1539},{\"id\":1540},{\"id\":1541},{\"id\":1542},{\"id\":1543},{\"id\":1544},{\"id\":1545},{\"id\":1546},{\"id\":1547},{\"id\":1548},{\"id\":1549},{\"id\":1550},{\"id\":1551},{\"id\":1552},{\"id\":1553},{\"id\":1554},{\"id\":1555},{\"id\":1556},{\"id\":1557},{\"id\":1558},{\"id\":1559},{\"id\":1560},{\"id\":1561},{\"id\":1562},{\"id\":1563},{\"id\":1564},{\"id\":1565},{\"id\":1566},{\"id\":1567},{\"id\":1568},{\"id\":1569},{\"id\":1570},{\"id\":1571},{\"id\":1572},{\"id\":1573},{\"id\":1574},{\"id\":1575},{\"id\":1576},{\"id\":1577},{\"id\":1578},{\"id\":1579},{\"id\":1580},{\"id\":1581},{\"id\":1582},{\"id\":1583},{\"id\":1584},{\"id\":1585},{\"id\":1586},{\"id\":1587},{\"id\":1588},{\"id\":1589},{\"id\":1590},{\"id\":1591},{\"id\":1592},{\"id\":1593},{\"id\":1594},{\"id\":1595},{\"id\":1596},{\"id\":1597},{\"id\":1598},{\"id\":1599},{\"id\":1600},{\"id\":1601},{\"id\":1602},{\"id\":1603},{\"id\":1604},{\"id\":1605},{\"id\":1606},{\"id\":1607},{\"id\":1608},{\"id\":1609},{\"id\":1610},{\"id\":1611},{\"id\":1612},{\"id\":1613},{\"id\":1614},{\"id\":1615},{\"id\":1616},{\"id\":1617},{\"id\":1618},{\"id\":1619},{\"id\":1620},{\"id\":1621},{\"id\":1622},{\"id\":1623},{\"id\":1624},{\"id\":1625},{\"id\":1626},{\"id\":1627},{\"id\":1628},{\"id\":1629},{\"id\":1630},{\"id\":1631},{\"id\":1632},{\"id\":1633},{\"id\":1634},{\"id\":1635},{\"id\":1636},{\"id\":1637},{\"id\":1638},{\"id\":1639},{\"id\":1640},{\"id\":1641},{\"id\":1642},{\"id\":1643},{\"id\":1644},{\"id\":1645},{\"id\":1646},{\"id\":1647},{\"id\":1648},{\"id\":1649},{\"id\":1650},{\"id\":1651},{\"id\":1652},{\"id\":1653},{\"id\":1654},{\"id\":1655},{\"id\":1656},{\"id\":1657},{\"id\":1658},{\"id\":1659},{\"id\":1660},{\"id\":1661},{\"id\":1662},{\"id\":1663},{\"id\":1664},{\"id\":1665},{\"id\":1666},{\"id\":1667},{\"id\":1668},{\"id\":1669},{\"id\":1670},{\"id\":1671},{\"id\":1672},{\"id\":1673},{\"id\":1674},{\"id\":1675},{\"id\":1676},{\"id\":1677},{\"id\":1678},{\"id\":1679},{\"id\":1680},{\"id\":1681},{\"id\":1682},{\"id\":1683},{\"id\":1684},{\"id\":1685},{\"id\":1686},{\"id\":1687},{\"id\":1688},{\"id\":1689},{\"id\":1690},{\"id\":1691},{\"id\":1692},{\"id\":1693},{\"id\":1694},{\"id\":1695},{\"id\":1696},{\"id\":1697},{\"id\":1698},{\"id\":1699},{\"id\":1700},{\"id\":1701},{\"id\":1702},{\"id\":1703},{\"id\":1704},{\"id\":1705},{\"id\":1706},{\"id\":1707},{\"id\":1708},{\"id\":1709},{\"id\":1710},{\"id\":1711},{\"id\":1712},{\"id\":1713},{\"id\":1714},{\"id\":1715},{\"id\":1716},{\"id\":1717},{\"id\":1718},{\"id\":1719},{\"id\":1720},{\"id\":1721},{\"id\":1722},{\"id\":1723},{\"id\":1724},{\"id\":1725},{\"id\":1726},{\"id\":1727},{\"id\":1728},{\"id\":1729},{\"id\":1730},{\"id\":1731},{\"id\":1732},{\"id\":1733},{\"id\":1734},{\"id\":1735},{\"id\":1736},{\"id\":1737},{\"id\":1738},{\"id\":1739},{\"id\":1740},{\"id\":1741},{\"id\":1742},{\"id\":1743},{\"id\":1744},{\"id\":1745},{\"id\":1746},{\"id\":1747},{\"id\":1748},{\"id\":1749},{\"id\":1750},{\"id\":1751},{\"id\":1752},{\"id\":1753},{\"id\":1754},{\"id\":1755},{\"id\":1756},{\"id\":1757},{\"id\":1758},{\"id\":1759},{\"id\":1760},{\"id\":1761},{\"id\":1762},{\"id\":1763},{\"id\":1764},{\"id\":1765},{\"id\":1766},{\"id\":1767},{\"id\":1768},{\"id\":1769},{\"id\":1770},{\"id\":1771},{\"id\":1772},{\"id\":1773},{\"id\":1774},{\"id\":1775},{\"id\":1776},{\"id\":1777},{\"id\":1778},{\"id\":1779},{\"id\":1780},{\"id\":1781},{\"id\":1782},{\"id\":1783},{\"id\":1784},{\"id\":1785},{\"id\":1786},{\"id\":1787},{\"id\":1788},{\"id\":1789},{\"id\":1790},{\"id\":1791},{\"id\":1792},{\"id\":1793},{\"id\":1794},{\"id\":1795},{\"id\":1796},{\"id\":1797},{\"id\":1798},{\"id\":1799},{\"id\":1800},{\"id\":1801},{\"id\":1802},{\"id\":1803},{\"id\":1804},{\"id\":1805},{\"id\":1806},{\"id\":1807},{\"id\":1808},{\"id\":1809},{\"id\":1810},{\"id\":1811},{\"id\":1812},{\"id\":1813},{\"id\":1814},{\"id\":1815},{\"id\":1816},{\"id\":1817},{\"id\":1818},{\"id\":1819},{\"id\":1820},{\"id\":1821},{\"id\":1822},{\"id\":1823},{\"id\":1824},{\"id\":1825},{\"id\":1826},{\"id\":1827},{\"id\":1828},{\"id\":1829},{\"id\":1830},{\"id\":1831},{\"id\":1832},{\"id\":1833},{\"id\":1834},{\"id\":1835},{\"id\":1836},{\"id\":1837},{\"id\":1838},{\"id\":1839},{\"id\":1840},{\"id\":1841},{\"id\":1842},{\"id\":1843},{\"id\":1844},{\"id\":1845},{\"id\":1846},{\"id\":1847},{\"id\":1848},{\"id\":1849},{\"id\":1850},{\"id\":1851},{\"id\":1852},{\"id\":1853},{\"id\":1854},{\"id\":1855},{\"id\":1856},{\"id\":1857},{\"id\":1858},{\"id\":1859},{\"id\":1860},{\"id\":1861},{\"id\":1862},{\"id\":1863},{\"id\":1864},{\"id\":1865},{\"id\":1866},{\"id\":1867},{\"id\":1868},{\"id\":1869},{\"id\":1870},{\"id\":1871},{\"id\":1872},{\"id\":1873},{\"id\":1874},{\"id\":1875},{\"id\":1876},{\"id\":1877},{\"id\":1878},{\"id\":1879},{\"id\":1880},{\"id\":1881},{\"id\":1882},{\"id\":1883},{\"id\":1884},{\"id\":1885},{\"id\":1886},{\"id\":1887},{\"id\":1888},{\"id\":1889},{\"id\":1890},{\"id\":1891},{\"id\":1892},{\"id\":1893},{\"id\":1894},{\"id\":1895},{\"id\":1896},{\"id\":1897},{\"id\":1898},{\"id\":1899},{\"id\":1900},{\"id\":1901},{\"id\":1902},{\"id\":1903},{\"id\":1904},{\"id\":1905},{\"id\":1906},{\"id\":1907},{\"id\":1908},{\"id\":1909},{\"id\":1910},{\"id\":1911},{\"id\":1912},{\"id\":1913},{\"id\":1914},{\"id\":1915},{\"id\":1916},{\"id\":1917},{\"id\":1918},{\"id\":1919},{\"id\":1920},{\"id\":1921},{\"id\":1922},{\"id\":1923},{\"id\":1924},{\"id\":1925},{\"id\":1926},{\"id\":1927},{\"id\":1928},{\"id\":1929},{\"id\":1930},{\"id\":1931},{\"id\":1932},{\"id\":1933},{\"id\":1934},{\"id\":1935},{\"id\":1936},{\"id\":1937},{\"id\":1938},{\"id\":1939},{\"id\":1940},{\"id\":1941},{\"id\":1942},{\"id\":1943},{\"id\":1944},{\"id\":1945},{\"id\":1946},{\"id\":1947},{\"id\":1948},{\"id\":1949},{\"id\":1950},{\"id\":1951},{\"id\":1952},{\"id\":1953},{\"id\":1954},{\"id\":1955},{\"id\":1956},{\"id\":1957},{\"id\":1958},{\"id\":1959},{\"id\":1960},{\"id\":1961},{\"id\":1962},{\"id\":1963},{\"id\":1964},{\"id\":1965},{\"id\":1966},{\"id\":1967},{\"id\":1968},{\"id\":1969},{\"id\":1970},{\"id\":1971},{\"id\":1972},{\"id\":1973},{\"id\":1974},{\"id\":1975},{\"id\":1976},{\"id\":1977},{\"id\":1978},{\"id\":1979},{\"id\":1980},{\"id\":1981},{\"id\":1982},{\"id\":1983},{\"id\":1984},{\"id\":1985},{\"id\":1986},{\"id\":1987},{\"id\":1988},{\"id\":1989},{\"id\":1990},{\"id\":1991},{\"id\":1992},{\"id\":1993},{\"id\":1994},{\"id\":1995},{\"id\":1996},{\"id\":1997},{\"id\":1998},{\"id\":1999},{\"id\":2000},{\"id\":2001},{\"id\":2002},{\"id\":2003},{\"id\":2004},{\"id\":2005},{\"id\":2006},{\"id\":2007},{\"id\":2008},{\"id\":2009},{\"id\":2010},{\"id\":2011},{\"id\":2012},{\"id\":2013},{\"id\":2014},{\"id\":2015},{\"id\":2016},{\"id\":2017},{\"id\":2018},{\"id\":2019},{\"id\":2020},{\"id\":2021},{\"id\":2022},{\"id\":2023},{\"id\":2024},{\"id\":2025},{\"id\":2026},{\"id\":2027},{\"id\":2028},{\"id\":2029},{\"id\":2030},{\"id\":2031},{\"id\":2032},{\"id\":2033},{\"id\":2034},{\"id\":2035},{\"id\":2036},{\"id\":2037},{\"id\":2038},{\"id\":2039},{\"id\":2040},{\"id\":2041},{\"id\":2042},{\"id\":2043},{\"id\":2044},{\"id\":2045},{\"id\":2046},{\"id\":2047},{\"id\":2048},{\"id\":2049},{\"id\":2050},{\"id\":2051},{\"id\":2052},{\"id\":2053},{\"id\":2054},{\"id\":2055},{\"id\":2056},{\"id\":2057},{\"id\":2058},{\"id\":2059},{\"id\":2060},{\"id\":2061},{\"id\":2062},{\"id\":2063},{\"id\":2064},{\"id\":2065},{\"id\":2066},{\"id\":2067},{\"id\":2068},{\"id\":2069},{\"id\":2070},{\"id\":2071},{\"id\":2072},{\"id\":2073},{\"id\":2074},{\"id\":2075},{\"id\":2076},{\"id\":2077},{\"id\":2078},{\"id\":2079},{\"id\":2080},{\"id\":2081},{\"id\":2082},{\"id\":2083},{\"id\":2084},{\"id\":2085},{\"id\":2086},{\"id\":2087},{\"id\":2088},{\"id\":2089},{\"id\":2090},{\"id\":2091},{\"id\":2092},{\"id\":2093},{\"id\":2094},{\"id\":2095},{\"id\":2096},{\"id\":2097},{\"id\":2098},{\"id\":2099},{\"id\":2100},{\"id\":2101},{\"id\":2102},{\"id\":2103},{\"id\":2104},{\"id\":2105},{\"id\":2106},{\"id\":2107},{\"id\":2108},{\"id\":2109},{\"id\":2110},{\"id\":2111},{\"id\":2112},{\"id\":2113},{\"id\":2114},{\"id\":2115},{\"id\":2116},{\"id\":2117},{\"id\":2118},{\"id\":2119},{\"id\":2120},{\"id\":2121},{\"id\":2122},{\"id\":2123},{\"id\":2124},{\"id\":2125},{\"id\":2126},{\"id\":2127},{\"id\":2128},{\"id\":2129},{\"id\":2130},{\"id\":2131},{\"id\":2132},{\"id\":2133},{\"id\":2134},{\"id\":2135},{\"id\":2136},{\"id\":2137},{\"id\":2138},{\"id\":2139},{\"id\":2140},{\"id\":2141},{\"id\":2142},{\"id\":2143},{\"id\":2144},{\"id\":2145},{\"id\":2146},{\"id\":2147},{\"id\":2148},{\"id\":2149},{\"id\":2150},{\"id\":2151},{\"id\":2152},{\"id\":2153},{\"id\":2154},{\"id\":2155},{\"id\":2156},{\"id\":2157},{\"id\":2158},{\"id\":2159},{\"id\":2160},{\"id\":2161},{\"id\":2162},{\"id\":2163},{\"id\":2164},{\"id\":2165},{\"id\":2166},{\"id\":2167},{\"id\":2168},{\"id\":2169},{\"id\":2170},{\"id\":2171},{\"id\":2172},{\"id\":2173},{\"id\":2174},{\"id\":2175},{\"id\":2176},{\"id\":2177},{\"id\":2178},{\"id\":2179},{\"id\":2180},{\"id\":2181},{\"id\":2182},{\"id\":2183},{\"id\":2184},{\"id\":2185},{\"id\":2186},{\"id\":2187},{\"id\":2188},{\"id\":2189},{\"id\":2190},{\"id\":2191},{\"id\":2192},{\"id\":2193},{\"id\":2194},{\"id\":2195},{\"id\":2196},{\"id\":2197},{\"id\":2198},{\"id\":2199},{\"id\":2200},{\"id\":2201},{\"id\":2202},{\"id\":2203},{\"id\":2204},{\"id\":2205},{\"id\":2206},{\"id\":2207},{\"id\":2208},{\"id\":2209},{\"id\":2210},{\"id\":2211},{\"id\":2212},{\"id\":2213},{\"id\":2214},{\"id\":2215},{\"id\":2216},{\"id\":2217},{\"id\":2218},{\"id\":2219},{\"id\":2220},{\"id\":2221},{\"id\":2222},{\"id\":2223},{\"id\":2224},{\"id\":2225},{\"id\":2226},{\"id\":2227},{\"id\":2228},{\"id\":2229},{\"id\":2230},{\"id\":2231},{\"id\":2232},{\"id\":2233},{\"id\":2234},{\"id\":2235},{\"id\":2236},{\"id\":2237},{\"id\":2238},{\"id\":2239},{\"id\":2240},{\"id\":2241},{\"id\":2242},{\"id\":2243},{\"id\":2244},{\"id\":2245},{\"id\":2246},{\"id\":2247},{\"id\":2248},{\"id\":2249},{\"id\":2250},{\"id\":2251},{\"id\":2252},{\"id\":2253},{\"id\":2254},{\"id\":2255},{\"id\":2256},{\"id\":2257},{\"id\":2258},{\"id\":2259},{\"id\":2260},{\"id\":2261},{\"id\":2262},{\"id\":2263},{\"id\":2264},{\"id\":2265},{\"id\":2266},{\"id\":2267},{\"id\":2268},{\"id\":2269},{\"id\":2270},{\"id\":2271},{\"id\":2272},{\"id\":2273},{\"id\":2274},{\"id\":2275},{\"id\":2276},{\"id\":2277},{\"id\":2278},{\"id\":2279},{\"id\":2280},{\"id\":2281},{\"id\":2282},{\"id\":2283},{\"id\":2284},{\"id\":2285},{\"id\":2286},{\"id\":2287},{\"id\":2288},{\"id\":2289},{\"id\":2290},{\"id\":2291},{\"id\":2292},{\"id\":2293},{\"id\":2294},{\"id\":2295},{\"id\":2296},{\"id\":2297},{\"id\":2298},{\"id\":2299},{\"id\":2300},{\"id\":2301},{\"id\":2302},{\"id\":2303},{\"id\":2304},{\"id\":2305},{\"id\":2306},{\"id\":2307},{\"id\":2308},{\"id\":2309},{\"id\":2310},{\"id\":2311},{\"id\":2312},{\"id\":2313},{\"id\":2314},{\"id\":2315},{\"id\":2316},{\"id\":2317},{\"id\":2318},{\"id\":2319},{\"id\":2320},{\"id\":2321},{\"id\":2322},{\"id\":2323},{\"id\":2324},{\"id\":2325},{\"id\":2326},{\"id\":2327},{\"id\":2328},{\"id\":2329},{\"id\":2330},{\"id\":2331},{\"id\":2332},{\"id\":2333},{\"id\":2334},{\"id\":2335},{\"id\":2336},{\"id\":2337},{\"id\":2338},{\"id\":2339},{\"id\":2340},{\"id\":2341},{\"id\":2342},{\"id\":2343},{\"id\":2344},{\"id\":2345},{\"id\":2346},{\"id\":2347},{\"id\":2348},{\"id\":2349},{\"id\":2350},{\"id\":2351},{\"id\":2352},{\"id\":2353},{\"id\":2354},{\"id\":2355},{\"id\":2356},{\"id\":2357},{\"id\":2358},{\"id\":2359},{\"id\":2360},{\"id\":2361},{\"id\":2362},{\"id\":2363},{\"id\":2364},{\"id\":2365},{\"id\":2366},{\"id\":2367},{\"id\":2368},{\"id\":2369},{\"id\":2370},{\"id\":2371},{\"id\":2372},{\"id\":2373},{\"id\":2374},{\"id\":2375},{\"id\":2376},{\"id\":2377},{\"id\":2378},{\"id\":2379},{\"id\":2380},{\"id\":2381},{\"id\":2382},{\"id\":2383},{\"id\":2384},{\"id\":2385},{\"id\":2386},{\"id\":2387},{\"id\":2388},{\"id\":2389},{\"id\":2390},{\"id\":2391},{\"id\":2392},{\"id\":2393},{\"id\":2394},{\"id\":2395},{\"id\":2396},{\"id\":2397},{\"id\":2398},{\"id\":2399},{\"id\":2400},{\"id\":2401},{\"id\":2402},{\"id\":2403},{\"id\":2404},{\"id\":2405},{\"id\":2406},{\"id\":2407},{\"id\":2408},{\"id\":2409},{\"id\":2410},{\"id\":2411},{\"id\":2412},{\"id\":2413},{\"id\":2414},{\"id\":2415},{\"id\":2416},{\"id\":2417},{\"id\":2418},{\"id\":2419},{\"id\":2420},{\"id\":2421},{\"id\":2422},{\"id\":2423},{\"id\":2424},{\"id\":2425},{\"id\":2426},{\"id\":2427},{\"id\":2428},{\"id\":2429},{\"id\":2430},{\"id\":2431},{\"id\":2432},{\"id\":2433},{\"id\":2434},{\"id\":2435},{\"id\":2436},{\"id\":2437},{\"id\":2438},{\"id\":2439},{\"id\":2440},{\"id\":2441},{\"id\":2442},{\"id\":2443},{\"id\":2444},{\"id\":2445},{\"id\":2446},{\"id\":2447},{\"id\":2448},{\"id\":2449},{\"id\":2450},{\"id\":2451},{\"id\":2452},{\"id\":2453},{\"id\":2454},{\"id\":2455},{\"id\":2456},{\"id\":2457},{\"id\":2458},{\"id\":2459},{\"id\":2460},{\"id\":2461},{\"id\":2462},{\"id\":2463},{\"id\":2464},{\"id\":2465},{\"id\":2466},{\"id\":2467},{\"id\":2468},{\"id\":2469},{\"id\":2470},{\"id\":2471},{\"id\":2472},{\"id\":2473},{\"id\":2474},{\"id\":2475},{\"id\":2476},{\"id\":2477},{\"id\":2478},{\"id\":2479},{\"id\":2480},{\"id\":2481},{\"id\":2482},{\"id\":2483},{\"id\":2484},{\"id\":2485},{\"id\":2486},{\"id\":2487},{\"id\":2488},{\"id\":2489},{\"id\":2490},{\"id\":2491},{\"id\":2492},{\"id\":2493},{\"id\":2494},{\"id\":2495},{\"id\":2496},{\"id\":2497},{\"id\":2498},{\"id\":2499},{\"id\":2500},{\"id\":2501},{\"id\":2502},{\"id\":2503},{\"id\":2504},{\"id\":2505},{\"id\":2506},{\"id\":2507},{\"id\":2508},{\"id\":2509},{\"id\":2510},{\"id\":2511},{\"id\":2512},{\"id\":2513},{\"id\":2514},{\"id\":2515},{\"id\":2516},{\"id\":2517},{\"id\":2518},{\"id\":2519},{\"id\":2520},{\"id\":2521},{\"id\":2522},{\"id\":2523},{\"id\":2524},{\"id\":2525},{\"id\":2526},{\"id\":2527},{\"id\":2528},{\"id\":2529},{\"id\":2530},{\"id\":2531},{\"id\":2532},{\"id\":2533},{\"id\":2534},{\"id\":2535},{\"id\":2536},{\"id\":2537},{\"id\":2538},{\"id\":2539},{\"id\":2540},{\"id\":2541},{\"id\":2542},{\"id\":2543},{\"id\":2544},{\"id\":2545},{\"id\":2546},{\"id\":2547},{\"id\":2548},{\"id\":2549},{\"id\":2550},{\"id\":2551},{\"id\":2552},{\"id\":2553},{\"id\":2554},{\"id\":2555},{\"id\":2556},{\"id\":2557},{\"id\":2558},{\"id\":2559},{\"id\":2560},{\"id\":2561},{\"id\":2562},{\"id\":2563},{\"id\":2564},{\"id\":2565},{\"id\":2566},{\"id\":2567},{\"id\":2568},{\"id\":2569},{\"id\":2570},{\"id\":2571},{\"id\":2572},{\"id\":2573},{\"id\":2574},{\"id\":2575},{\"id\":2576},{\"id\":2577},{\"id\":2578},{\"id\":2579},{\"id\":2580},{\"id\":2581},{\"id\":2582},{\"id\":2583},{\"id\":2584},{\"id\":2585},{\"id\":2586},{\"id\":2587},{\"id\":2588},{\"id\":2589},{\"id\":2590},{\"id\":2591},{\"id\":2592},{\"nodeType\":3,\"id\":2596,\"textContent\":\" // Track clicks on page $(document).ready(function() { $(\\\".control\\\").click(function(e) { e.stopImmediatePropagation(); clicks = clicks + 1; console.log(clicks); }); }); $('.userid').html(sid); // console.log(\\\"start of clicked array: \\\"+clicked); // console.log(\\\"start of hovered string: \\\"+hovered); //set correct answers for each question var triangular_answers = { \\\"acme.starttime.1\\\" : [\\\"F\\\"], \\\"acme.starts.1\\\" : [\\\"K\\\"], \\\"acme.meets.1\\\" : [\\\"F\\\"], \\\"acme.endtime.1\\\" : [\\\"H\\\"], \\\"acme.midpoint.1\\\" : [\\\"O\\\"], \\\"acme.starttime.2\\\" : [\\\"F\\\"], \\\"acme.starts.2\\\" : [\\\"K\\\"], \\\"acme.meets.2\\\" : [\\\"F\\\"], \\\"acme.endtime.2\\\" : [\\\"H\\\"], \\\"acme.midpoint.2\\\" : [\\\"A\\\"], \\\"bigset.duration.1\\\" : [\\\"E\\\",\\\"G\\\"], \\\"bigset.duration+starts.1\\\" : [\\\"X\\\",\\\"O\\\"], \\\"bigset.duration+contained.1\\\" : [\\\"G\\\"], \\\"bigset.starttime+before+endtime+during.1\\\": [\\\"I\\\"], \\\"bigset.ends.1\\\" : [\\\"E\\\"], \\\"bigset.duration.2\\\" : [\\\"E\\\",\\\"G\\\"], \\\"bigset.duration+starts.2\\\" : [\\\"X\\\",\\\"O\\\"], \\\"bigset.duration+contained.2\\\" : [\\\"G\\\"], \\\"bigset.starttime+before+endtime+during.2\\\":[\\\"I\\\"], \\\"bigset.ends.2\\\" : [\\\"E\\\"], \\\"bigset.starttime.1\\\" : [\\\"M\\\",\\\"L\\\"], \\\"bigset.starts.1\\\" : [\\\"G\\\"], \\\"bigset.meets.1\\\" : [\\\"E\\\",\\\"F\\\"], \\\"bigset.endtime.1\\\" : [\\\"X\\\"], \\\"bigset.midpoint.1\\\" : [\\\"K\\\",\\\"X\\\"], \\\"bigset.starttime.2\\\" : [\\\"M\\\",\\\"L\\\"], \\\"bigset.starts.2\\\" : [\\\"G\\\"], \\\"bigset.meets.2\\\" : [\\\"E\\\",\\\"F\\\"], \\\"bigset.endtime.2\\\" : [\\\"X\\\"], \\\"bigset.midpoint.2\\\" : [\\\"K\\\",\\\"X\\\"] } var orthogonal_answers = { \\\"acme.starttime.1\\\" : [\\\"A\\\"], \\\"acme.starts.1\\\" : [\\\"E\\\"], \\\"acme.meets.1\\\" : [\\\"Z\\\"], \\\"acme.endtime.1\\\" : [\\\"U\\\"], \\\"acme.midpoint.1\\\" : [\\\"U\\\"], \\\"acme.starttime.2\\\" : [\\\"0\\\"], \\\"acme.starts.2\\\" : [\\\"0\\\"], \\\"acme.meets.2\\\" : [\\\"0\\\"], \\\"acme.endtime.2\\\" : [\\\"0\\\"], \\\"acme.midpoint.2\\\" : [\\\"0\\\"], \\\"bigset.duration.1\\\" : [\\\"E\\\",\\\"G\\\"], \\\"bigset.duration+starts.1\\\" : [\\\"F\\\",\\\"B\\\"], \\\"bigset.duration+contained.1\\\" : [\\\"E\\\"], \\\"bigset.starttime+before+endtime+during.1\\\": [\\\"I\\\"], \\\"bigset.ends.1\\\" : [\\\"X\\\"], \\\"bigset.duration.2\\\" : [\\\"E\\\",\\\"G\\\"], \\\"bigset.duration+starts.2\\\" : [\\\"F\\\",\\\"B\\\"], \\\"bigset.duration+contained.2\\\" : [\\\"E\\\"], \\\"bigset.starttime+before+endtime+during.2\\\":[\\\"I\\\"], \\\"bigset.ends.2\\\" : [\\\"X\\\"], \\\"bigset.starttime.1\\\" : [\\\"F\\\",\\\"B\\\"], \\\"bigset.starts.1\\\" : [\\\"B\\\"], \\\"bigset.meets.1\\\" : [\\\"F\\\",\\\"X\\\"], \\\"bigset.endtime.1\\\" : [\\\"B\\\"], \\\"bigset.midpoint.1\\\" : [\\\"E\\\",\\\"F\\\"], \\\"bigset.starttime.2\\\" : [\\\"F\\\",\\\"B\\\"], \\\"bigset.starts.2\\\" : [\\\"B\\\"], \\\"bigset.meets.2\\\" : [\\\"F\\\",\\\"X\\\"], \\\"bigset.endtime.2\\\" : [\\\"B\\\"], \\\"bigset.midpoint.2\\\" : [\\\"E\\\",\\\"F\\\"] } //display the question and answer buttons based on input values from jsPsych document.getElementById(scenario+\\\".\\\"+question).style.display = \\\"block\\\"; if (question == \\\"strategy\\\") {document.getElementById(\\\"strategyButton\\\").style.display = \\\"block\\\";} else {document.getElementById(\\\"testingButton\\\").style.display = \\\"block\\\";} //---------SET PROPERTIES OF THE GRAPH -------------// // set the dimensions and margins of the graph var margin = {top: 25, right: 30, bottom: 90, left: 100}, width = 800, height = 800; var intersects = false; //default value for intersects scaffold var xAxisTitle, yAxisTitle; var datafile =\\\"\\\"; // SET AXIS VALUES if (axis == 1){ axis = \\\"Orthogonal-XInside-YFull\\\"; } else if (axis == 2){ axis = \\\"Orthogonal-XInside-YPartial\\\"; } else if (axis ==3){ axis = \\\"Triangular-XInside-YInside\\\"; } else if (axis ==4){ axis = \\\"Orthogonal-XInside-YInside\\\"; } else if (axis ==5){ axis = \\\"Orthogonal-XFull-YFull\\\"; } // SET EXPLICIT SCAFFOLD FEATURES if (explicit ==2 && axis != \\\"diagonal\\\"){ scaffold = 2; intersects = false; } else if (explicit == 2 && axis == \\\"diagonal\\\"){ scaffold = 2; intersects = false; } //TODO: not sure if above two lines are still valid since leaders are now generated on the fly else if (explicit == 3){ $('#hint-interactive').css(\\\"display\\\",\\\"block\\\"); //display textimage scaffold intersects = true; } //SET DATA FILE FOR IMPLICIT SCAFFOLD if (impasse == 1){ datafile = \\\"../views/src/data/acme_nonimpasse.csv\\\"; } else if (impasse == 2){ datafile = \\\"../views/src/data/acme_impasse.csv\\\"; } //OVERRIDE DATA FILE FOR NON-SCAFFOLD QUESTIONS if (q > 5) { //override data file if q# is greater than 5 datafile = \\\"../views/src/data/bigset.csv\\\"; console.log(\\\"override data file\\\"); $('#orthogonal-image').css(\\\"display\\\",\\\"none\\\"); //display textimage scaffold $('#diagonal-image').css(\\\"display\\\",\\\"none\\\"); //display textimage scaffold $('#hint-interactive').css(\\\"display\\\",\\\"none\\\"); //display textimage scaffold intersects = false; } // //---------CREATE THE SVG ------------------------// var svg = d3.select(\\\".d3container\\\").append(\\\"svg\\\") .attr(\\\"width\\\", width + margin.left + margin.right) .attr(\\\"height\\\", height + margin.top + margin.bottom) .append(\\\"g\\\") .attr(\\\"transform\\\", \\\"translate(\\\" + margin.left + \\\",\\\" + margin.top + \\\")\\\"); //---------DRAW THE GRAPH ------------------------// xAxisTitle = \\\"START & END TIME (time of day)\\\"; yAxisTitle = \\\"DURATION (in hours)\\\"; drawTriangleModel(datafile,intersects,axis,scaffold,q); \"},{\"id\":2593},{\"id\":2594},{\"nodeType\":3,\"id\":2597,\"textContent\":\" //MOUSE LOGGING SCRIPT var mouseLog = [] var xwidth = $(document).width(); var xheight = $(document).width(); mouseLog.push(\\\"{x:\\\"+xwidth+\\\",y:\\\"+xheight+\\\",t:\\\"+\\\"0};\\\") document.onmousemove = function(e){ var pageCoords = \\\"{x:\\\" + e.pageX + \\\",y:\\\"+ e.pageY +\\\",t:\\\"+ Date.now()+ \\\"};\\\" ; mouseLog.push(pageCoords); // console.log(pageCoords); }; \"},{\"id\":2595}],[],[],[]]}"
    },
    {
      "sequence": 2,
      "data": "{\"f\":\"applyChanged\",\"args\":[[],[{\"nodeType\":1,\"id\":2598,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-text-preamble\",\"class\":\"jspsych-survey-text-preamble\"},\"parentNode\":{\"id\":55}},{\"nodeType\":1,\"id\":2599,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-text-0\",\"class\":\"jspsych-survey-text-question\"},\"previousSibling\":{\"id\":2598},\"parentNode\":{\"id\":55}},{\"nodeType\":1,\"id\":2600,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-text-1\",\"class\":\"jspsych-survey-text-question\"},\"previousSibling\":{\"id\":2599},\"parentNode\":{\"id\":55}},{\"nodeType\":1,\"id\":2601,\"tagName\":\"BUTTON\",\"attributes\":{\"id\":\"jspsych-survey-text-next\",\"class\":\"jspsych-btn jspsych-survey-text\"},\"previousSibling\":{\"id\":2600},\"parentNode\":{\"id\":55}},{\"nodeType\":1,\"id\":2602,\"tagName\":\"P\",\"attributes\":{\"class\":\"jspsych-survey-text\"},\"parentNode\":{\"id\":2599}},{\"nodeType\":1,\"id\":2603,\"tagName\":\"TEXTAREA\",\"attributes\":{\"name\":\"#jspsych-survey-text-response-0\",\"cols\":\"40\",\"rows\":\"1\"},\"previousSibling\":{\"id\":2602},\"parentNode\":{\"id\":2599}},{\"nodeType\":3,\"id\":2604,\"textContent\":\"What is your age?\",\"parentNode\":{\"id\":2602}},{\"nodeType\":1,\"id\":2605,\"tagName\":\"P\",\"attributes\":{\"class\":\"jspsych-survey-text\"},\"parentNode\":{\"id\":2600}},{\"nodeType\":1,\"id\":2606,\"tagName\":\"TEXTAREA\",\"attributes\":{\"name\":\"#jspsych-survey-text-response-1\",\"cols\":\"40\",\"rows\":\"1\"},\"previousSibling\":{\"id\":2605},\"parentNode\":{\"id\":2600}},{\"nodeType\":3,\"id\":2607,\"textContent\":\"In what country were you born?\",\"parentNode\":{\"id\":2605}},{\"nodeType\":3,\"id\":2608,\"textContent\":\"Submit Answers\",\"parentNode\":{\"id\":2601}}],[],[]]}"
    },
    {
      "sequence": 3,
      "data": "{\"f\":\"applyChanged\",\"args\":[[{\"id\":2598},{\"id\":2599},{\"id\":2602},{\"id\":2604},{\"id\":2603},{\"id\":2600},{\"id\":2605},{\"id\":2607},{\"id\":2606},{\"id\":2601},{\"id\":2608}],[],[],[]]}"
    },
    {
      "sequence": 4,
      "data": "{\"f\":\"applyChanged\",\"args\":[[],[{\"nodeType\":1,\"id\":2609,\"tagName\":\"FORM\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-form\"},\"parentNode\":{\"id\":55}},{\"nodeType\":1,\"id\":2610,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-preamble\",\"class\":\"jspsych-survey-multi-choice-preamble\"},\"parentNode\":{\"id\":2609}},{\"nodeType\":1,\"id\":2611,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-0\",\"class\":\"jspsych-survey-multi-choice-question jspsych-survey-multi-choice-horizontal\"},\"previousSibling\":{\"id\":2610},\"parentNode\":{\"id\":2609}},{\"nodeType\":1,\"id\":2612,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-1\",\"class\":\"jspsych-survey-multi-choice-question jspsych-survey-multi-choice-horizontal\"},\"previousSibling\":{\"id\":2611},\"parentNode\":{\"id\":2609}},{\"nodeType\":1,\"id\":2613,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-2\",\"class\":\"jspsych-survey-multi-choice-question jspsych-survey-multi-choice-horizontal\"},\"previousSibling\":{\"id\":2612},\"parentNode\":{\"id\":2609}},{\"nodeType\":1,\"id\":2614,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-3\",\"class\":\"jspsych-survey-multi-choice-question jspsych-survey-multi-choice-horizontal\"},\"previousSibling\":{\"id\":2613},\"parentNode\":{\"id\":2609}},{\"nodeType\":1,\"id\":2615,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"submit\",\"id\":\"jspsych-survey-multi-choice-next\",\"class\":\"jspsych-survey-multi-choice jspsych-btn\",\"value\":\"Submit Answers\"},\"previousSibling\":{\"id\":2614},\"parentNode\":{\"id\":2609}},{\"nodeType\":1,\"id\":2616,\"tagName\":\"P\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text survey-multi-choice\"},\"parentNode\":{\"id\":2611}},{\"nodeType\":1,\"id\":2617,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-0-0\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2616},\"parentNode\":{\"id\":2611}},{\"nodeType\":1,\"id\":2618,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-0-1\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2617},\"parentNode\":{\"id\":2611}},{\"nodeType\":1,\"id\":2619,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-0-2\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2618},\"parentNode\":{\"id\":2611}},{\"nodeType\":1,\"id\":2620,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-0-3\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2619},\"parentNode\":{\"id\":2611}},{\"nodeType\":3,\"id\":2621,\"textContent\":\"What is your first language?\",\"parentNode\":{\"id\":2616}},{\"nodeType\":1,\"id\":2622,\"tagName\":\"SPAN\",\"attributes\":{\"class\":\"required\"},\"previousSibling\":{\"id\":2621},\"parentNode\":{\"id\":2616}},{\"nodeType\":1,\"id\":2623,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2617}},{\"nodeType\":1,\"id\":2624,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-0\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2623}},{\"nodeType\":3,\"id\":2625,\"textContent\":\"English\",\"previousSibling\":{\"id\":2624},\"parentNode\":{\"id\":2623}},{\"nodeType\":1,\"id\":2626,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2618}},{\"nodeType\":1,\"id\":2627,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-0\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2626}},{\"nodeType\":3,\"id\":2628,\"textContent\":\"Spanish\",\"previousSibling\":{\"id\":2627},\"parentNode\":{\"id\":2626}},{\"nodeType\":1,\"id\":2629,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2619}},{\"nodeType\":1,\"id\":2630,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-0\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2629}},{\"nodeType\":3,\"id\":2631,\"textContent\":\"Mandarin or Cantonese\",\"previousSibling\":{\"id\":2630},\"parentNode\":{\"id\":2629}},{\"nodeType\":1,\"id\":2632,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2620}},{\"nodeType\":1,\"id\":2633,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-0\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2632}},{\"nodeType\":3,\"id\":2634,\"textContent\":\"Other\",\"previousSibling\":{\"id\":2633},\"parentNode\":{\"id\":2632}},{\"nodeType\":3,\"id\":2635,\"textContent\":\"*\",\"parentNode\":{\"id\":2622}},{\"nodeType\":1,\"id\":2636,\"tagName\":\"P\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text survey-multi-choice\"},\"parentNode\":{\"id\":2612}},{\"nodeType\":1,\"id\":2637,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-1-0\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2636},\"parentNode\":{\"id\":2612}},{\"nodeType\":1,\"id\":2638,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-1-1\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2637},\"parentNode\":{\"id\":2612}},{\"nodeType\":1,\"id\":2639,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-1-2\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2638},\"parentNode\":{\"id\":2612}},{\"nodeType\":1,\"id\":2640,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-1-3\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2639},\"parentNode\":{\"id\":2612}},{\"nodeType\":1,\"id\":2641,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-1-4\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2640},\"parentNode\":{\"id\":2612}},{\"nodeType\":1,\"id\":2642,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-1-5\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2641},\"parentNode\":{\"id\":2612}},{\"nodeType\":1,\"id\":2643,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-1-6\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2642},\"parentNode\":{\"id\":2612}},{\"nodeType\":3,\"id\":2644,\"textContent\":\"What is your year in school?\",\"parentNode\":{\"id\":2636}},{\"nodeType\":1,\"id\":2645,\"tagName\":\"SPAN\",\"attributes\":{\"class\":\"required\"},\"previousSibling\":{\"id\":2644},\"parentNode\":{\"id\":2636}},{\"nodeType\":1,\"id\":2646,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2637}},{\"nodeType\":1,\"id\":2647,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-1\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2646}},{\"nodeType\":3,\"id\":2648,\"textContent\":\"First\",\"previousSibling\":{\"id\":2647},\"parentNode\":{\"id\":2646}},{\"nodeType\":1,\"id\":2649,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2638}},{\"nodeType\":1,\"id\":2650,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-1\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2649}},{\"nodeType\":3,\"id\":2651,\"textContent\":\"Second\",\"previousSibling\":{\"id\":2650},\"parentNode\":{\"id\":2649}},{\"nodeType\":1,\"id\":2652,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2639}},{\"nodeType\":1,\"id\":2653,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-1\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2652}},{\"nodeType\":3,\"id\":2654,\"textContent\":\"Third\",\"previousSibling\":{\"id\":2653},\"parentNode\":{\"id\":2652}},{\"nodeType\":1,\"id\":2655,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2640}},{\"nodeType\":1,\"id\":2656,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-1\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2655}},{\"nodeType\":3,\"id\":2657,\"textContent\":\"Fourth\",\"previousSibling\":{\"id\":2656},\"parentNode\":{\"id\":2655}},{\"nodeType\":1,\"id\":2658,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2641}},{\"nodeType\":1,\"id\":2659,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-1\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2658}},{\"nodeType\":3,\"id\":2660,\"textContent\":\"Fifth\",\"previousSibling\":{\"id\":2659},\"parentNode\":{\"id\":2658}},{\"nodeType\":1,\"id\":2661,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2642}},{\"nodeType\":1,\"id\":2662,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-1\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2661}},{\"nodeType\":3,\"id\":2663,\"textContent\":\"Graduate\",\"previousSibling\":{\"id\":2662},\"parentNode\":{\"id\":2661}},{\"nodeType\":1,\"id\":2664,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2643}},{\"nodeType\":1,\"id\":2665,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-1\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2664}},{\"nodeType\":3,\"id\":2666,\"textContent\":\"Other\",\"previousSibling\":{\"id\":2665},\"parentNode\":{\"id\":2664}},{\"nodeType\":3,\"id\":2667,\"textContent\":\"*\",\"parentNode\":{\"id\":2645}},{\"nodeType\":1,\"id\":2668,\"tagName\":\"P\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text survey-multi-choice\"},\"parentNode\":{\"id\":2613}},{\"nodeType\":1,\"id\":2669,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-2-0\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2668},\"parentNode\":{\"id\":2613}},{\"nodeType\":1,\"id\":2670,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-2-1\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2669},\"parentNode\":{\"id\":2613}},{\"nodeType\":1,\"id\":2671,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-2-2\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2670},\"parentNode\":{\"id\":2613}},{\"nodeType\":1,\"id\":2672,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-2-3\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2671},\"parentNode\":{\"id\":2613}},{\"nodeType\":1,\"id\":2673,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-2-4\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2672},\"parentNode\":{\"id\":2613}},{\"nodeType\":1,\"id\":2674,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-2-5\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2673},\"parentNode\":{\"id\":2613}},{\"nodeType\":1,\"id\":2675,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-2-6\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2674},\"parentNode\":{\"id\":2613}},{\"nodeType\":3,\"id\":2676,\"textContent\":\"What is your major area of study?\",\"parentNode\":{\"id\":2668}},{\"nodeType\":1,\"id\":2677,\"tagName\":\"SPAN\",\"attributes\":{\"class\":\"required\"},\"previousSibling\":{\"id\":2676},\"parentNode\":{\"id\":2668}},{\"nodeType\":1,\"id\":2678,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2669}},{\"nodeType\":1,\"id\":2679,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-2\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2678}},{\"nodeType\":3,\"id\":2680,\"textContent\":\"Math or Computer Sciences\",\"previousSibling\":{\"id\":2679},\"parentNode\":{\"id\":2678}},{\"nodeType\":1,\"id\":2681,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2670}},{\"nodeType\":1,\"id\":2682,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-2\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2681}},{\"nodeType\":3,\"id\":2683,\"textContent\":\"Social Sciences (incl. CogSci)\",\"previousSibling\":{\"id\":2682},\"parentNode\":{\"id\":2681}},{\"nodeType\":1,\"id\":2684,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2671}},{\"nodeType\":1,\"id\":2685,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-2\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2684}},{\"nodeType\":3,\"id\":2686,\"textContent\":\"Biomedical & Health Sciences\",\"previousSibling\":{\"id\":2685},\"parentNode\":{\"id\":2684}},{\"nodeType\":1,\"id\":2687,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2672}},{\"nodeType\":1,\"id\":2688,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-2\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2687}},{\"nodeType\":3,\"id\":2689,\"textContent\":\"Natural Sciences\",\"previousSibling\":{\"id\":2688},\"parentNode\":{\"id\":2687}},{\"nodeType\":1,\"id\":2690,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2673}},{\"nodeType\":1,\"id\":2691,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-2\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2690}},{\"nodeType\":3,\"id\":2692,\"textContent\":\"Engineering\",\"previousSibling\":{\"id\":2691},\"parentNode\":{\"id\":2690}},{\"nodeType\":1,\"id\":2693,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2674}},{\"nodeType\":1,\"id\":2694,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-2\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2693}},{\"nodeType\":3,\"id\":2695,\"textContent\":\"Humanities\",\"previousSibling\":{\"id\":2694},\"parentNode\":{\"id\":2693}},{\"nodeType\":1,\"id\":2696,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2675}},{\"nodeType\":1,\"id\":2697,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-2\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2696}},{\"nodeType\":3,\"id\":2698,\"textContent\":\"Fine Arts\",\"previousSibling\":{\"id\":2697},\"parentNode\":{\"id\":2696}},{\"nodeType\":3,\"id\":2699,\"textContent\":\"*\",\"parentNode\":{\"id\":2677}},{\"nodeType\":1,\"id\":2700,\"tagName\":\"P\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text survey-multi-choice\"},\"parentNode\":{\"id\":2614}},{\"nodeType\":1,\"id\":2701,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-3-0\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2700},\"parentNode\":{\"id\":2614}},{\"nodeType\":1,\"id\":2702,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-3-1\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2701},\"parentNode\":{\"id\":2614}},{\"nodeType\":1,\"id\":2703,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-3-2\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2702},\"parentNode\":{\"id\":2614}},{\"nodeType\":3,\"id\":2704,\"textContent\":\"What is your gender?\",\"parentNode\":{\"id\":2700}},{\"nodeType\":1,\"id\":2705,\"tagName\":\"SPAN\",\"attributes\":{\"class\":\"required\"},\"previousSibling\":{\"id\":2704},\"parentNode\":{\"id\":2700}},{\"nodeType\":1,\"id\":2706,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2701}},{\"nodeType\":1,\"id\":2707,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-3\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2706}},{\"nodeType\":3,\"id\":2708,\"textContent\":\"Male\",\"previousSibling\":{\"id\":2707},\"parentNode\":{\"id\":2706}},{\"nodeType\":1,\"id\":2709,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2702}},{\"nodeType\":1,\"id\":2710,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-3\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2709}},{\"nodeType\":3,\"id\":2711,\"textContent\":\"Female\",\"previousSibling\":{\"id\":2710},\"parentNode\":{\"id\":2709}},{\"nodeType\":1,\"id\":2712,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2703}},{\"nodeType\":1,\"id\":2713,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-3\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2712}},{\"nodeType\":3,\"id\":2714,\"textContent\":\"Other\",\"previousSibling\":{\"id\":2713},\"parentNode\":{\"id\":2712}},{\"nodeType\":3,\"id\":2715,\"textContent\":\"*\",\"parentNode\":{\"id\":2705}}],[],[]]}"
    },
    {
      "sequence": 5,
      "data": "{\"f\":\"applyChanged\",\"args\":[[{\"id\":2609},{\"id\":2610},{\"id\":2611},{\"id\":2616},{\"id\":2621},{\"id\":2622},{\"id\":2635},{\"id\":2617},{\"id\":2623},{\"id\":2624},{\"id\":2625},{\"id\":2618},{\"id\":2626},{\"id\":2627},{\"id\":2628},{\"id\":2619},{\"id\":2629},{\"id\":2630},{\"id\":2631},{\"id\":2620},{\"id\":2632},{\"id\":2633},{\"id\":2634},{\"id\":2612},{\"id\":2636},{\"id\":2644},{\"id\":2645},{\"id\":2667},{\"id\":2637},{\"id\":2646},{\"id\":2647},{\"id\":2648},{\"id\":2638},{\"id\":2649},{\"id\":2650},{\"id\":2651},{\"id\":2639},{\"id\":2652},{\"id\":2653},{\"id\":2654},{\"id\":2640},{\"id\":2655},{\"id\":2656},{\"id\":2657},{\"id\":2641},{\"id\":2658},{\"id\":2659},{\"id\":2660},{\"id\":2642},{\"id\":2661},{\"id\":2662},{\"id\":2663},{\"id\":2643},{\"id\":2664},{\"id\":2665},{\"id\":2666},{\"id\":2613},{\"id\":2668},{\"id\":2676},{\"id\":2677},{\"id\":2699},{\"id\":2669},{\"id\":2678},{\"id\":2679},{\"id\":2680},{\"id\":2670},{\"id\":2681},{\"id\":2682},{\"id\":2683},{\"id\":2671},{\"id\":2684},{\"id\":2685},{\"id\":2686},{\"id\":2672},{\"id\":2687},{\"id\":2688},{\"id\":2689},{\"id\":2673},{\"id\":2690},{\"id\":2691},{\"id\":2692},{\"id\":2674},{\"id\":2693},{\"id\":2694},{\"id\":2695},{\"id\":2675},{\"id\":2696},{\"id\":2697},{\"id\":2698},{\"id\":2614},{\"id\":2700},{\"id\":2704},{\"id\":2705},{\"id\":2715},{\"id\":2701},{\"id\":2706},{\"id\":2707},{\"id\":2708},{\"id\":2702},{\"id\":2709},{\"id\":2710},{\"id\":2711},{\"id\":2703},{\"id\":2712},{\"id\":2713},{\"id\":2714},{\"id\":2615}],[],[],[]]}"
    },
    {
      "sequence": 6,
      "data": "{\"f\":\"applyChanged\",\"args\":[[],[{\"nodeType\":1,\"id\":2716,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"masterdiv\"},\"parentNode\":{\"id\":55}},{\"nodeType\":3,\"id\":2717,\"textContent\":\" \",\"previousSibling\":{\"id\":2716},\"parentNode\":{\"id\":55}},{\"nodeType\":3,\"id\":2718,\"textContent\":\" \",\"parentNode\":{\"id\":2716}},{\"nodeType\":1,\"id\":2719,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"top\"},\"previousSibling\":{\"id\":2718},\"parentNode\":{\"id\":2716}},{\"nodeType\":3,\"id\":2720,\"textContent\":\" \",\"previousSibling\":{\"id\":2719},\"parentNode\":{\"id\":2716}},{\"nodeType\":1,\"id\":2721,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"instructions\"},\"previousSibling\":{\"id\":2720},\"parentNode\":{\"id\":2716}},{\"nodeType\":3,\"id\":2722,\"textContent\":\" \",\"previousSibling\":{\"id\":2721},\"parentNode\":{\"id\":2716}},{\"nodeType\":1,\"id\":2723,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bottom\"},\"previousSibling\":{\"id\":2722},\"parentNode\":{\"id\":2716}},{\"nodeType\":3,\"id\":2724,\"textContent\":\" \",\"previousSibling\":{\"id\":2723},\"parentNode\":{\"id\":2716}},{\"nodeType\":3,\"id\":2725,\"textContent\":\" \",\"parentNode\":{\"id\":2719}},{\"nodeType\":1,\"id\":2726,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bcent\"},\"previousSibling\":{\"id\":2725},\"parentNode\":{\"id\":2719}},{\"nodeType\":3,\"id\":2727,\"textContent\":\" \",\"previousSibling\":{\"id\":2726},\"parentNode\":{\"id\":2719}},{\"nodeType\":3,\"id\":2728,\"textContent\":\" \",\"parentNode\":{\"id\":2726}},{\"nodeType\":1,\"id\":2729,\"tagName\":\"H3\",\"attributes\":{},\"previousSibling\":{\"id\":2728},\"parentNode\":{\"id\":2726}},{\"nodeType\":3,\"id\":2730,\"textContent\":\" \",\"previousSibling\":{\"id\":2729},\"parentNode\":{\"id\":2726}},{\"nodeType\":3,\"id\":2731,\"textContent\":\"DEBRIEFING\",\"parentNode\":{\"id\":2729}},{\"nodeType\":3,\"id\":2732,\"textContent\":\" \",\"parentNode\":{\"id\":2721}},{\"nodeType\":1,\"id\":2733,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"vcent\"},\"previousSibling\":{\"id\":2732},\"parentNode\":{\"id\":2721}},{\"nodeType\":3,\"id\":2734,\"textContent\":\" \",\"previousSibling\":{\"id\":2733},\"parentNode\":{\"id\":2721}},{\"nodeType\":3,\"id\":2735,\"textContent\":\" \",\"parentNode\":{\"id\":2733}},{\"nodeType\":1,\"id\":2736,\"tagName\":\"P\",\"attributes\":{\"style\":\"font-style:italic\"},\"previousSibling\":{\"id\":2735},\"parentNode\":{\"id\":2733}},{\"nodeType\":1,\"id\":2737,\"tagName\":\"P\",\"attributes\":{},\"previousSibling\":{\"id\":2736},\"parentNode\":{\"id\":2733}},{\"nodeType\":3,\"id\":2738,\"textContent\":\" \",\"previousSibling\":{\"id\":2737},\"parentNode\":{\"id\":2733}},{\"nodeType\":1,\"id\":2739,\"tagName\":\"P\",\"attributes\":{},\"previousSibling\":{\"id\":2738},\"parentNode\":{\"id\":2733}},{\"nodeType\":3,\"id\":2740,\"textContent\":\" \",\"previousSibling\":{\"id\":2739},\"parentNode\":{\"id\":2733}},{\"nodeType\":1,\"id\":2741,\"tagName\":\"P\",\"attributes\":{},\"previousSibling\":{\"id\":2740},\"parentNode\":{\"id\":2733}},{\"nodeType\":3,\"id\":2742,\"textContent\":\" \",\"previousSibling\":{\"id\":2741},\"parentNode\":{\"id\":2733}},{\"nodeType\":1,\"id\":2743,\"tagName\":\"P\",\"attributes\":{\"style\":\"font-style:bold;\"},\"previousSibling\":{\"id\":2742},\"parentNode\":{\"id\":2733}},{\"nodeType\":3,\"id\":2744,\"textContent\":\" \",\"previousSibling\":{\"id\":2743},\"parentNode\":{\"id\":2733}},{\"nodeType\":1,\"id\":2745,\"tagName\":\"P\",\"attributes\":{\"style\":\"font-style:italic;\"},\"previousSibling\":{\"id\":2744},\"parentNode\":{\"id\":2733}},{\"nodeType\":3,\"id\":2746,\"textContent\":\" \",\"previousSibling\":{\"id\":2745},\"parentNode\":{\"id\":2733}},{\"nodeType\":3,\"id\":2747,\"textContent\":\"Thank you very much for your participation! This debriefing will tell you more about the study, what you did, and why. \",\"parentNode\":{\"id\":2736}},{\"nodeType\":3,\"id\":2748,\"textContent\":\" \",\"parentNode\":{\"id\":2737}},{\"nodeType\":1,\"id\":2749,\"tagName\":\"B\",\"attributes\":{},\"previousSibling\":{\"id\":2748},\"parentNode\":{\"id\":2737}},{\"nodeType\":3,\"id\":2750,\"textContent\":\" You have just used a series of pictures (charts, graphs and diagrams) accompanied by different types of instructions to answer a series of problem solving questions. While you were using the pictures, we measured where you clicked, scrolled and pointed with the computer mouse. We also measured the accuracy of your responses and the time it took to complete each question.\",\"previousSibling\":{\"id\":2749},\"parentNode\":{\"id\":2737}},{\"nodeType\":3,\"id\":2751,\"textContent\":\"What did you just do?\",\"parentNode\":{\"id\":2749}},{\"nodeType\":3,\"id\":2752,\"textContent\":\" \",\"parentNode\":{\"id\":2739}},{\"nodeType\":1,\"id\":2753,\"tagName\":\"B\",\"attributes\":{},\"previousSibling\":{\"id\":2752},\"parentNode\":{\"id\":2739}},{\"nodeType\":3,\"id\":2754,\"textContent\":\" Researchers of learning and cognition have long been interested in how graphic displays of information can be used to communicate, solve problems, and generate insights. As powerful as graphics may be in their communicative efficiency, they're not always immediately intuitive to understand. In short, we know a great deal more about learning with representations than we do about the learning of representations. In this project we are building upon previous research on reading and graph comprehension to explore how readers make sense of unfamiliar representations. The instructions you saw for each type of graph are known as “scaffolding techniques”, and we will compare your performance with the scaffolding techniques you saw with the performance of other participants to determine which types of instructions are most effective in helping humans to make sense of unfamiliar graphs. \",\"previousSibling\":{\"id\":2753},\"parentNode\":{\"id\":2739}},{\"nodeType\":3,\"id\":2755,\"textContent\":\"Why did we have you do it?\",\"parentNode\":{\"id\":2753}},{\"nodeType\":1,\"id\":2756,\"tagName\":\"B\",\"attributes\":{},\"parentNode\":{\"id\":2741}},{\"nodeType\":3,\"id\":2757,\"textContent\":\" We expect that you will have found some of the graphics more difficult to use than others. We also expect that with the assistance of the instructions, after solving several problems you will learn to use the difficult graphics so that you can answer the questions even more quickly than without. If you would like to receive a copy of the results of the study, or have any further questions, please contact the researchers Primary Researcher: Amy Fox : a2fox@ucsd.edu Faculty Advisor : Dr. Jim Hollan : hollan@ucsd.edu \",\"previousSibling\":{\"id\":2756},\"parentNode\":{\"id\":2741}},{\"nodeType\":3,\"id\":2758,\"textContent\":\"What do we expect to find?\",\"parentNode\":{\"id\":2756}},{\"nodeType\":3,\"id\":2759,\"textContent\":\"It is important that you do not discuss this experiment with other students who might participate after you. They must participate in the same way as you did, without any knowledge of what the experiment entails, or the reasoning behind it.\",\"parentNode\":{\"id\":2743}},{\"nodeType\":3,\"id\":2760,\"textContent\":\"Thank you for your time! We hope you enjoyed participating in this study as much as we enjoyed designing it.\",\"parentNode\":{\"id\":2745}},{\"nodeType\":3,\"id\":2761,\"textContent\":\" \",\"parentNode\":{\"id\":2723}},{\"nodeType\":1,\"id\":2762,\"tagName\":\"BUTTON\",\"attributes\":{\"class\":\"btn\",\"type\":\"button\",\"id\":\"start\"},\"previousSibling\":{\"id\":2761},\"parentNode\":{\"id\":2723}},{\"nodeType\":3,\"id\":2763,\"textContent\":\" \",\"previousSibling\":{\"id\":2762},\"parentNode\":{\"id\":2723}},{\"nodeType\":3,\"id\":2764,\"textContent\":\"FINISH\",\"parentNode\":{\"id\":2762}}],[],[]]}"
    },
    {
      "sequence": 7,
      "data": "{\"f\":\"applyChanged\",\"args\":[[{\"id\":2716},{\"id\":2718},{\"id\":2719},{\"id\":2725},{\"id\":2726},{\"id\":2728},{\"id\":2729},{\"id\":2731},{\"id\":2730},{\"id\":2727},{\"id\":2720},{\"id\":2721},{\"id\":2732},{\"id\":2733},{\"id\":2735},{\"id\":2736},{\"id\":2747},{\"id\":2737},{\"id\":2748},{\"id\":2749},{\"id\":2751},{\"id\":2750},{\"id\":2738},{\"id\":2739},{\"id\":2752},{\"id\":2753},{\"id\":2755},{\"id\":2754},{\"id\":2740},{\"id\":2741},{\"id\":2756},{\"id\":2758},{\"id\":2757},{\"id\":2742},{\"id\":2743},{\"id\":2759},{\"id\":2744},{\"id\":2745},{\"id\":2760},{\"id\":2746},{\"id\":2734},{\"id\":2722},{\"id\":2723},{\"id\":2761},{\"id\":2762},{\"id\":2764},{\"id\":2763},{\"id\":2724},{\"id\":2717}],[],[],[]]}"
    },
    {
      "sequence": 8,
      "data": "{\"f\":\"applyChanged\",\"args\":[[],[{\"nodeType\":1,\"id\":2765,\"tagName\":\"PRE\",\"attributes\":{\"id\":\"jspsych-data-display\"},\"parentNode\":{\"id\":55}},{\"nodeType\":3,\"id\":2766,\"textContent\":\"[ { \\\"rt\\\": 81672, \\\"stimulus\\\": \\\"img/phone.png\\\", \\\"key_press\\\": 13, \\\"block\\\": \\\"phone\\\", \\\"trial_type\\\": \\\"single-stim\\\", \\\"trial_index\\\": 0, \\\"time_elapsed\\\": 81674, \\\"internal_node_id\\\": \\\"0.0-0.0\\\", \\\"subject\\\": \\\"RV9F6\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"lima\\\", \\\"condition\\\": \\\"115\\\" }, { \\\"rt\\\": 9131, \\\"url\\\": \\\"../views/src/external/consent.html\\\", \\\"block\\\": \\\"consent\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 1, \\\"time_elapsed\\\": 92134, \\\"internal_node_id\\\": \\\"0.0-1.0\\\", \\\"subject\\\": \\\"RV9F6\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"lima\\\", \\\"condition\\\": \\\"115\\\" }, { \\\"rt\\\": 15306, \\\"responses\\\": \\\"{\\\\\\\"Q0\\\\\\\":\\\\\\\"LIMA\\\\\\\",\\\\\\\"Q1\\\\\\\":\\\\\\\"115\\\\\\\"}\\\", \\\"block\\\": \\\"codes\\\", \\\"trial_type\\\": \\\"survey-text\\\", \\\"trial_index\\\": 2, \\\"time_elapsed\\\": 108446, \\\"internal_node_id\\\": \\\"0.0-2.0\\\", \\\"subject\\\": \\\"RV9F6\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"lima\\\", \\\"condition\\\": \\\"115\\\" }, { \\\"rt\\\": 21920, \\\"url\\\": \\\"../views/src/external/instructions_lab.html\\\", \\\"block\\\": \\\"instructions_lab\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 3, \\\"time_elapsed\\\": 131459, \\\"internal_node_id\\\": \\\"0.0-3.0\\\", \\\"subject\\\": \\\"RV9F6\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"lima\\\", \\\"condition\\\": \\\"115\\\" }, { \\\"rt\\\": 12063, \\\"stimulus\\\": \\\"img/acme.png\\\", \\\"key_press\\\": 13, \\\"block\\\": \\\"scenario\\\", \\\"trial_type\\\": \\\"single-stim\\\", \\\"trial_index\\\": 4, \\\"time_elapsed\\\": 144525, \\\"internal_node_id\\\": \\\"0.0-4.0\\\", \\\"subject\\\": \\\"RV9F6\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"lima\\\", \\\"condition\\\": \\\"115\\\" }, { \\\"rt\\\": 50771, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 5, \\\"time_elapsed\\\": 196666, \\\"internal_node_id\\\": \\\"0.0-5.0-0.0\\\", \\\"subject\\\": \\\"RV9F6\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"lima\\\", \\\"condition\\\": \\\"115\\\", \\\"scenario\\\": \\\"acme\\\", \\\"question\\\": \\\"starttime\\\", \\\"q\\\": 1, \\\"clicks\\\": 1, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XFull-YFull\\\", \\\"correct\\\": 1, \\\"orth_correct\\\": 0, \\\"answer\\\": [ \\\"F\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"X \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"U \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-02 PM-A -A -Z -F -01 PM-Z -Z -12 PM-A -A -06 PM-B -B -G -B -B -C \\\", \\\"block\\\": \\\"triangular_scaffolded\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:1502,y:992,t:1527264564919};\\\", \\\"{x:1508,y:997,t:1527264564929};\\\", \\\"{x:1508,y:998,t:1527264564999};\\\", \\\"{x:1505,y:998,t:1527264566511};\\\", \\\"{x:1502,y:994,t:1527264566519};\\\", \\\"{x:1493,y:985,t:1527264566530};\\\", \\\"{x:1478,y:974,t:1527264566547};\\\", \\\"{x:1478,y:969,t:1527264566564};\\\", \\\"{x:1462,y:953,t:1527264566580};\\\", \\\"{x:1440,y:927,t:1527264566596};\\\", \\\"{x:1420,y:910,t:1527264566614};\\\", \\\"{x:1401,y:893,t:1527264566630};\\\", \\\"{x:1364,y:863,t:1527264566647};\\\", \\\"{x:1333,y:833,t:1527264566663};\\\", \\\"{x:1274,y:793,t:1527264566679};\\\", \\\"{x:1240,y:765,t:1527264566697};\\\", \\\"{x:1222,y:755,t:1527264566714};\\\", \\\"{x:1197,y:731,t:1527264566731};\\\", \\\"{x:1161,y:705,t:1527264566747};\\\", \\\"{x:1146,y:688,t:1527264566763};\\\", \\\"{x:1135,y:680,t:1527264566780};\\\", \\\"{x:1131,y:674,t:1527264566796};\\\", \\\"{x:1130,y:674,t:1527264566814};\\\", \\\"{x:1129,y:674,t:1527264566959};\\\", \\\"{x:1129,y:675,t:1527264566967};\\\", \\\"{x:1137,y:680,t:1527264566980};\\\", \\\"{x:1147,y:689,t:1527264566997};\\\", \\\"{x:1168,y:702,t:1527264567016};\\\", \\\"{x:1177,y:710,t:1527264567029};\\\", \\\"{x:1195,y:718,t:1527264567046};\\\", \\\"{x:1205,y:728,t:1527264567063};\\\", \\\"{x:1219,y:736,t:1527264567080};\\\", \\\"{x:1235,y:741,t:1527264567096};\\\", \\\"{x:1248,y:747,t:1527264567113};\\\", \\\"{x:1258,y:753,t:1527264567130};\\\", \\\"{x:1265,y:757,t:1527264567146};\\\", \\\"{x:1269,y:759,t:1527264567163};\\\", \\\"{x:1270,y:760,t:1527264567180};\\\", \\\"{x:1270,y:761,t:1527264567197};\\\", \\\"{x:1270,y:763,t:1527264567213};\\\", \\\"{x:1272,y:765,t:1527264567230};\\\", \\\"{x:1272,y:767,t:1527264567247};\\\", \\\"{x:1273,y:768,t:1527264567270};\\\", \\\"{x:1273,y:769,t:1527264567280};\\\", \\\"{x:1273,y:770,t:1527264567297};\\\", \\\"{x:1273,y:774,t:1527264567314};\\\", \\\"{x:1274,y:779,t:1527264567330};\\\", \\\"{x:1275,y:784,t:1527264567347};\\\", \\\"{x:1275,y:789,t:1527264567364};\\\", \\\"{x:1275,y:795,t:1527264567380};\\\", \\\"{x:1275,y:799,t:1527264567397};\\\", \\\"{x:1275,y:807,t:1527264567413};\\\", \\\"{x:1275,y:813,t:1527264567430};\\\", \\\"{x:1275,y:814,t:1527264567448};\\\", \\\"{x:1274,y:815,t:1527264567463};\\\", \\\"{x:1273,y:816,t:1527264567480};\\\", \\\"{x:1273,y:821,t:1527264567497};\\\", \\\"{x:1273,y:823,t:1527264567514};\\\", \\\"{x:1273,y:824,t:1527264567550};\\\", \\\"{x:1273,y:825,t:1527264567564};\\\", \\\"{x:1274,y:829,t:1527264567580};\\\", \\\"{x:1276,y:831,t:1527264567600};\\\", \\\"{x:1276,y:834,t:1527264567614};\\\", \\\"{x:1279,y:837,t:1527264568655};\\\", \\\"{x:1285,y:842,t:1527264568665};\\\", \\\"{x:1288,y:845,t:1527264568682};\\\", \\\"{x:1290,y:847,t:1527264568699};\\\", \\\"{x:1292,y:848,t:1527264568715};\\\", \\\"{x:1291,y:848,t:1527264569062};\\\", \\\"{x:1289,y:847,t:1527264569070};\\\", \\\"{x:1287,y:845,t:1527264569082};\\\", \\\"{x:1282,y:842,t:1527264569098};\\\", \\\"{x:1282,y:841,t:1527264569115};\\\", \\\"{x:1281,y:840,t:1527264569131};\\\", \\\"{x:1281,y:839,t:1527264570702};\\\", \\\"{x:1281,y:838,t:1527264570717};\\\", \\\"{x:1281,y:837,t:1527264570733};\\\", \\\"{x:1282,y:836,t:1527264570750};\\\", \\\"{x:1283,y:835,t:1527264570766};\\\", \\\"{x:1283,y:833,t:1527264570815};\\\", \\\"{x:1285,y:833,t:1527264570822};\\\", \\\"{x:1285,y:832,t:1527264570833};\\\", \\\"{x:1285,y:831,t:1527264571254};\\\", \\\"{x:1285,y:830,t:1527264571374};\\\", \\\"{x:1285,y:829,t:1527264574774};\\\", \\\"{x:1285,y:830,t:1527264576926};\\\", \\\"{x:1289,y:833,t:1527264576938};\\\", \\\"{x:1290,y:833,t:1527264577101};\\\", \\\"{x:1291,y:834,t:1527264577109};\\\", \\\"{x:1292,y:834,t:1527264577125};\\\", \\\"{x:1292,y:835,t:1527264577137};\\\", \\\"{x:1293,y:835,t:1527264577158};\\\", \\\"{x:1293,y:836,t:1527264577170};\\\", \\\"{x:1294,y:837,t:1527264577286};\\\", \\\"{x:1295,y:837,t:1527264577302};\\\", \\\"{x:1295,y:838,t:1527264577342};\\\", \\\"{x:1296,y:838,t:1527264577398};\\\", \\\"{x:1296,y:839,t:1527264577406};\\\", \\\"{x:1296,y:840,t:1527264577430};\\\", \\\"{x:1296,y:841,t:1527264577438};\\\", \\\"{x:1296,y:842,t:1527264577454};\\\", \\\"{x:1296,y:844,t:1527264577470};\\\", \\\"{x:1296,y:847,t:1527264577487};\\\", \\\"{x:1296,y:850,t:1527264577504};\\\", \\\"{x:1298,y:854,t:1527264577521};\\\", \\\"{x:1302,y:862,t:1527264577537};\\\", \\\"{x:1304,y:868,t:1527264577554};\\\", \\\"{x:1305,y:871,t:1527264577571};\\\", \\\"{x:1307,y:875,t:1527264577590};\\\", \\\"{x:1307,y:878,t:1527264577604};\\\", \\\"{x:1308,y:883,t:1527264577621};\\\", \\\"{x:1309,y:889,t:1527264577638};\\\", \\\"{x:1310,y:895,t:1527264577654};\\\", \\\"{x:1311,y:901,t:1527264577672};\\\", \\\"{x:1313,y:910,t:1527264577688};\\\", \\\"{x:1319,y:915,t:1527264577704};\\\", \\\"{x:1320,y:918,t:1527264577722};\\\", \\\"{x:1320,y:924,t:1527264577737};\\\", \\\"{x:1320,y:926,t:1527264577754};\\\", \\\"{x:1320,y:928,t:1527264577774};\\\", \\\"{x:1320,y:929,t:1527264577787};\\\", \\\"{x:1319,y:931,t:1527264577805};\\\", \\\"{x:1317,y:935,t:1527264577821};\\\", \\\"{x:1315,y:937,t:1527264577837};\\\", \\\"{x:1312,y:941,t:1527264577855};\\\", \\\"{x:1310,y:943,t:1527264577872};\\\", \\\"{x:1308,y:944,t:1527264577888};\\\", \\\"{x:1307,y:944,t:1527264577966};\\\", \\\"{x:1306,y:945,t:1527264577973};\\\", \\\"{x:1305,y:947,t:1527264577989};\\\", \\\"{x:1304,y:947,t:1527264578614};\\\", \\\"{x:1304,y:943,t:1527264579006};\\\", \\\"{x:1306,y:938,t:1527264579022};\\\", \\\"{x:1311,y:933,t:1527264579039};\\\", \\\"{x:1320,y:925,t:1527264579056};\\\", \\\"{x:1325,y:916,t:1527264579073};\\\", \\\"{x:1329,y:910,t:1527264579089};\\\", \\\"{x:1334,y:899,t:1527264579106};\\\", \\\"{x:1340,y:889,t:1527264579123};\\\", \\\"{x:1345,y:880,t:1527264579138};\\\", \\\"{x:1349,y:867,t:1527264579155};\\\", \\\"{x:1354,y:851,t:1527264579172};\\\", \\\"{x:1359,y:833,t:1527264579189};\\\", \\\"{x:1370,y:805,t:1527264579205};\\\", \\\"{x:1378,y:788,t:1527264579222};\\\", \\\"{x:1386,y:776,t:1527264579238};\\\", \\\"{x:1391,y:765,t:1527264579256};\\\", \\\"{x:1394,y:758,t:1527264579272};\\\", \\\"{x:1399,y:750,t:1527264579288};\\\", \\\"{x:1400,y:748,t:1527264579305};\\\", \\\"{x:1400,y:747,t:1527264579323};\\\", \\\"{x:1401,y:746,t:1527264579357};\\\", \\\"{x:1398,y:746,t:1527264579581};\\\", \\\"{x:1396,y:746,t:1527264579589};\\\", \\\"{x:1396,y:747,t:1527264579606};\\\", \\\"{x:1394,y:747,t:1527264579622};\\\", \\\"{x:1393,y:747,t:1527264579672};\\\", \\\"{x:1392,y:749,t:1527264579814};\\\", \\\"{x:1392,y:751,t:1527264579829};\\\", \\\"{x:1391,y:751,t:1527264579839};\\\", \\\"{x:1390,y:754,t:1527264579855};\\\", \\\"{x:1387,y:756,t:1527264579872};\\\", \\\"{x:1386,y:757,t:1527264579889};\\\", \\\"{x:1385,y:757,t:1527264579909};\\\", \\\"{x:1383,y:759,t:1527264579933};\\\", \\\"{x:1381,y:761,t:1527264580221};\\\", \\\"{x:1380,y:761,t:1527264580237};\\\", \\\"{x:1379,y:762,t:1527264580246};\\\", \\\"{x:1379,y:764,t:1527264580261};\\\", \\\"{x:1379,y:765,t:1527264580822};\\\", \\\"{x:1379,y:766,t:1527264580829};\\\", \\\"{x:1379,y:768,t:1527264580839};\\\", \\\"{x:1379,y:769,t:1527264580857};\\\", \\\"{x:1379,y:770,t:1527264580893};\\\", \\\"{x:1376,y:773,t:1527264589031};\\\", \\\"{x:1353,y:776,t:1527264589046};\\\", \\\"{x:1341,y:763,t:1527264589064};\\\", \\\"{x:1284,y:742,t:1527264589081};\\\", \\\"{x:1231,y:726,t:1527264589096};\\\", \\\"{x:1167,y:705,t:1527264589114};\\\", \\\"{x:1153,y:701,t:1527264589130};\\\", \\\"{x:1141,y:692,t:1527264589147};\\\", \\\"{x:1126,y:682,t:1527264589164};\\\", \\\"{x:1119,y:671,t:1527264589181};\\\", \\\"{x:1110,y:665,t:1527264589196};\\\", \\\"{x:1102,y:659,t:1527264589213};\\\", \\\"{x:1089,y:654,t:1527264589229};\\\", \\\"{x:1086,y:653,t:1527264589246};\\\", \\\"{x:1085,y:653,t:1527264589263};\\\", \\\"{x:1084,y:653,t:1527264589334};\\\", \\\"{x:1082,y:653,t:1527264589447};\\\", \\\"{x:1068,y:651,t:1527264589464};\\\", \\\"{x:1043,y:647,t:1527264589480};\\\", \\\"{x:1017,y:642,t:1527264589497};\\\", \\\"{x:987,y:636,t:1527264589514};\\\", \\\"{x:938,y:624,t:1527264589530};\\\", \\\"{x:859,y:607,t:1527264589549};\\\", \\\"{x:771,y:586,t:1527264589563};\\\", \\\"{x:690,y:560,t:1527264589581};\\\", \\\"{x:650,y:537,t:1527264589598};\\\", \\\"{x:626,y:524,t:1527264589615};\\\", \\\"{x:616,y:518,t:1527264589632};\\\", \\\"{x:598,y:506,t:1527264589648};\\\", \\\"{x:583,y:495,t:1527264589665};\\\", \\\"{x:573,y:486,t:1527264589682};\\\", \\\"{x:558,y:481,t:1527264589698};\\\", \\\"{x:555,y:480,t:1527264589714};\\\", \\\"{x:554,y:480,t:1527264589732};\\\", \\\"{x:553,y:480,t:1527264589749};\\\", \\\"{x:552,y:480,t:1527264589764};\\\", \\\"{x:552,y:481,t:1527264589813};\\\", \\\"{x:558,y:490,t:1527264589822};\\\", \\\"{x:558,y:492,t:1527264589832};\\\", \\\"{x:571,y:507,t:1527264589849};\\\", \\\"{x:580,y:515,t:1527264589865};\\\", \\\"{x:604,y:529,t:1527264589882};\\\", \\\"{x:613,y:536,t:1527264589899};\\\", \\\"{x:614,y:537,t:1527264589915};\\\", \\\"{x:614,y:538,t:1527264589982};\\\", \\\"{x:613,y:538,t:1527264589999};\\\", \\\"{x:610,y:538,t:1527264590015};\\\", \\\"{x:595,y:538,t:1527264590032};\\\", \\\"{x:582,y:538,t:1527264590049};\\\", \\\"{x:571,y:539,t:1527264590064};\\\", \\\"{x:560,y:539,t:1527264590082};\\\", \\\"{x:559,y:539,t:1527264590098};\\\", \\\"{x:553,y:539,t:1527264590114};\\\", \\\"{x:549,y:539,t:1527264590131};\\\", \\\"{x:539,y:540,t:1527264590148};\\\", \\\"{x:528,y:540,t:1527264590164};\\\", \\\"{x:520,y:541,t:1527264590181};\\\", \\\"{x:515,y:541,t:1527264590277};\\\", \\\"{x:513,y:543,t:1527264590285};\\\", \\\"{x:512,y:543,t:1527264590495};\\\", \\\"{x:509,y:544,t:1527264590568};\\\", \\\"{x:508,y:544,t:1527264590614};\\\", \\\"{x:507,y:544,t:1527264590645};\\\", \\\"{x:506,y:544,t:1527264590654};\\\", \\\"{x:504,y:544,t:1527264590665};\\\", \\\"{x:502,y:544,t:1527264590682};\\\", \\\"{x:497,y:545,t:1527264590699};\\\", \\\"{x:495,y:546,t:1527264590715};\\\", \\\"{x:488,y:547,t:1527264590732};\\\", \\\"{x:486,y:547,t:1527264590749};\\\", \\\"{x:467,y:551,t:1527264590766};\\\", \\\"{x:458,y:557,t:1527264590783};\\\", \\\"{x:447,y:558,t:1527264590799};\\\", \\\"{x:430,y:558,t:1527264590816};\\\", \\\"{x:429,y:558,t:1527264590834};\\\", \\\"{x:411,y:558,t:1527264590850};\\\", \\\"{x:407,y:558,t:1527264590866};\\\", \\\"{x:402,y:560,t:1527264590883};\\\", \\\"{x:401,y:560,t:1527264590910};\\\", \\\"{x:400,y:560,t:1527264591111};\\\", \\\"{x:397,y:558,t:1527264591126};\\\", \\\"{x:396,y:558,t:1527264591142};\\\", \\\"{x:394,y:558,t:1527264591150};\\\", \\\"{x:393,y:558,t:1527264591166};\\\", \\\"{x:395,y:558,t:1527264591862};\\\", \\\"{x:417,y:560,t:1527264591870};\\\", \\\"{x:460,y:566,t:1527264591882};\\\", \\\"{x:566,y:582,t:1527264591901};\\\", \\\"{x:674,y:598,t:1527264591917};\\\", \\\"{x:867,y:630,t:1527264591934};\\\", \\\"{x:1006,y:651,t:1527264591950};\\\", \\\"{x:1126,y:674,t:1527264591967};\\\", \\\"{x:1265,y:702,t:1527264591983};\\\", \\\"{x:1394,y:727,t:1527264592000};\\\", \\\"{x:1524,y:746,t:1527264592017};\\\", \\\"{x:1628,y:763,t:1527264592033};\\\", \\\"{x:1665,y:770,t:1527264592050};\\\", \\\"{x:1688,y:774,t:1527264592067};\\\", \\\"{x:1715,y:774,t:1527264592083};\\\", \\\"{x:1741,y:774,t:1527264592100};\\\", \\\"{x:1756,y:771,t:1527264592117};\\\", \\\"{x:1761,y:770,t:1527264592134};\\\", \\\"{x:1764,y:770,t:1527264592150};\\\", \\\"{x:1766,y:769,t:1527264592167};\\\", \\\"{x:1767,y:768,t:1527264592183};\\\", \\\"{x:1766,y:767,t:1527264592327};\\\", \\\"{x:1763,y:768,t:1527264592334};\\\", \\\"{x:1757,y:769,t:1527264592350};\\\", \\\"{x:1744,y:775,t:1527264592367};\\\", \\\"{x:1734,y:778,t:1527264592384};\\\", \\\"{x:1726,y:780,t:1527264592401};\\\", \\\"{x:1716,y:784,t:1527264592417};\\\", \\\"{x:1704,y:788,t:1527264592433};\\\", \\\"{x:1687,y:795,t:1527264592450};\\\", \\\"{x:1684,y:796,t:1527264592466};\\\", \\\"{x:1663,y:799,t:1527264592483};\\\", \\\"{x:1644,y:806,t:1527264592500};\\\", \\\"{x:1637,y:808,t:1527264592516};\\\", \\\"{x:1619,y:814,t:1527264592533};\\\", \\\"{x:1611,y:817,t:1527264592550};\\\", \\\"{x:1601,y:822,t:1527264592566};\\\", \\\"{x:1590,y:827,t:1527264592583};\\\", \\\"{x:1577,y:835,t:1527264592600};\\\", \\\"{x:1569,y:842,t:1527264592616};\\\", \\\"{x:1558,y:854,t:1527264592634};\\\", \\\"{x:1545,y:868,t:1527264592649};\\\", \\\"{x:1540,y:875,t:1527264592667};\\\", \\\"{x:1531,y:884,t:1527264592683};\\\", \\\"{x:1526,y:887,t:1527264592699};\\\", \\\"{x:1522,y:891,t:1527264592716};\\\", \\\"{x:1519,y:894,t:1527264592734};\\\", \\\"{x:1515,y:896,t:1527264592750};\\\", \\\"{x:1511,y:900,t:1527264592766};\\\", \\\"{x:1508,y:906,t:1527264592784};\\\", \\\"{x:1504,y:911,t:1527264592799};\\\", \\\"{x:1499,y:916,t:1527264592816};\\\", \\\"{x:1496,y:918,t:1527264592834};\\\", \\\"{x:1487,y:927,t:1527264592849};\\\", \\\"{x:1484,y:929,t:1527264592867};\\\", \\\"{x:1480,y:933,t:1527264592884};\\\", \\\"{x:1474,y:938,t:1527264592899};\\\", \\\"{x:1469,y:942,t:1527264592916};\\\", \\\"{x:1465,y:944,t:1527264592934};\\\", \\\"{x:1454,y:951,t:1527264592950};\\\", \\\"{x:1449,y:956,t:1527264592966};\\\", \\\"{x:1442,y:960,t:1527264592984};\\\", \\\"{x:1436,y:965,t:1527264592999};\\\", \\\"{x:1433,y:968,t:1527264593017};\\\", \\\"{x:1430,y:972,t:1527264593033};\\\", \\\"{x:1429,y:972,t:1527264593055};\\\", \\\"{x:1427,y:973,t:1527264593067};\\\", \\\"{x:1422,y:975,t:1527264593082};\\\", \\\"{x:1422,y:976,t:1527264593099};\\\", \\\"{x:1420,y:976,t:1527264593150};\\\", \\\"{x:1415,y:976,t:1527264593166};\\\", \\\"{x:1413,y:976,t:1527264593182};\\\", \\\"{x:1412,y:976,t:1527264593221};\\\", \\\"{x:1409,y:975,t:1527264593232};\\\", \\\"{x:1400,y:971,t:1527264593249};\\\", \\\"{x:1392,y:970,t:1527264593266};\\\", \\\"{x:1391,y:970,t:1527264593282};\\\", \\\"{x:1390,y:969,t:1527264593299};\\\", \\\"{x:1385,y:967,t:1527264593317};\\\", \\\"{x:1381,y:967,t:1527264593333};\\\", \\\"{x:1376,y:965,t:1527264593350};\\\", \\\"{x:1374,y:965,t:1527264593366};\\\", \\\"{x:1373,y:965,t:1527264593487};\\\", \\\"{x:1371,y:965,t:1527264593499};\\\", \\\"{x:1369,y:965,t:1527264593516};\\\", \\\"{x:1367,y:965,t:1527264593533};\\\", \\\"{x:1362,y:964,t:1527264593550};\\\", \\\"{x:1355,y:964,t:1527264593565};\\\", \\\"{x:1344,y:961,t:1527264593583};\\\", \\\"{x:1341,y:959,t:1527264593600};\\\", \\\"{x:1339,y:959,t:1527264593616};\\\", \\\"{x:1338,y:958,t:1527264593751};\\\", \\\"{x:1338,y:957,t:1527264593846};\\\", \\\"{x:1338,y:956,t:1527264593870};\\\", \\\"{x:1337,y:955,t:1527264593883};\\\", \\\"{x:1337,y:953,t:1527264593902};\\\", \\\"{x:1336,y:952,t:1527264593916};\\\", \\\"{x:1335,y:952,t:1527264593934};\\\", \\\"{x:1334,y:951,t:1527264594239};\\\", \\\"{x:1334,y:950,t:1527264594249};\\\", \\\"{x:1334,y:949,t:1527264594266};\\\", \\\"{x:1334,y:946,t:1527264594282};\\\", \\\"{x:1334,y:945,t:1527264594302};\\\", \\\"{x:1334,y:943,t:1527264594315};\\\", \\\"{x:1334,y:941,t:1527264594331};\\\", \\\"{x:1334,y:937,t:1527264594348};\\\", \\\"{x:1333,y:934,t:1527264594365};\\\", \\\"{x:1333,y:932,t:1527264594421};\\\", \\\"{x:1333,y:930,t:1527264594437};\\\", \\\"{x:1333,y:929,t:1527264594448};\\\", \\\"{x:1333,y:927,t:1527264594470};\\\", \\\"{x:1333,y:926,t:1527264594486};\\\", \\\"{x:1332,y:923,t:1527264594502};\\\", \\\"{x:1332,y:922,t:1527264594526};\\\", \\\"{x:1332,y:921,t:1527264594542};\\\", \\\"{x:1332,y:920,t:1527264594550};\\\", \\\"{x:1333,y:918,t:1527264594566};\\\", \\\"{x:1333,y:917,t:1527264594581};\\\", \\\"{x:1334,y:916,t:1527264594606};\\\", \\\"{x:1336,y:915,t:1527264594615};\\\", \\\"{x:1339,y:911,t:1527264594632};\\\", \\\"{x:1345,y:906,t:1527264594649};\\\", \\\"{x:1349,y:903,t:1527264594664};\\\", \\\"{x:1352,y:900,t:1527264594682};\\\", \\\"{x:1359,y:897,t:1527264594699};\\\", \\\"{x:1360,y:896,t:1527264594715};\\\", \\\"{x:1362,y:895,t:1527264594732};\\\", \\\"{x:1363,y:894,t:1527264594750};\\\", \\\"{x:1362,y:894,t:1527264595175};\\\", \\\"{x:1359,y:894,t:1527264595190};\\\", \\\"{x:1356,y:894,t:1527264595198};\\\", \\\"{x:1353,y:895,t:1527264595215};\\\", \\\"{x:1351,y:896,t:1527264595232};\\\", \\\"{x:1350,y:896,t:1527264595254};\\\", \\\"{x:1350,y:897,t:1527264596298};\\\", \\\"{x:1350,y:899,t:1527264596305};\\\", \\\"{x:1348,y:900,t:1527264596317};\\\", \\\"{x:1347,y:904,t:1527264596335};\\\", \\\"{x:1344,y:908,t:1527264596350};\\\", \\\"{x:1342,y:910,t:1527264596367};\\\", \\\"{x:1341,y:912,t:1527264596384};\\\", \\\"{x:1340,y:914,t:1527264596401};\\\", \\\"{x:1339,y:915,t:1527264596417};\\\", \\\"{x:1338,y:915,t:1527264597298};\\\", \\\"{x:1331,y:915,t:1527264598993};\\\", \\\"{x:1317,y:915,t:1527264599001};\\\", \\\"{x:1313,y:915,t:1527264599015};\\\", \\\"{x:1257,y:911,t:1527264599030};\\\", \\\"{x:1072,y:913,t:1527264599048};\\\", \\\"{x:619,y:902,t:1527264599064};\\\", \\\"{x:256,y:877,t:1527264599081};\\\", \\\"{x:0,y:862,t:1527264599098};\\\", \\\"{x:0,y:850,t:1527264599115};\\\", \\\"{x:0,y:845,t:1527264599131};\\\", \\\"{x:0,y:840,t:1527264599148};\\\", \\\"{x:0,y:857,t:1527264599165};\\\", \\\"{x:0,y:858,t:1527264599181};\\\", \\\"{x:0,y:859,t:1527264599198};\\\", \\\"{x:0,y:863,t:1527264599322};\\\", \\\"{x:77,y:867,t:1527264599331};\\\", \\\"{x:254,y:867,t:1527264599348};\\\", \\\"{x:396,y:866,t:1527264599364};\\\", \\\"{x:488,y:864,t:1527264599381};\\\", \\\"{x:504,y:863,t:1527264599398};\\\", \\\"{x:515,y:860,t:1527264599415};\\\", \\\"{x:515,y:856,t:1527264599490};\\\", \\\"{x:511,y:851,t:1527264599498};\\\", \\\"{x:501,y:841,t:1527264599514};\\\", \\\"{x:492,y:837,t:1527264599531};\\\", \\\"{x:483,y:833,t:1527264599548};\\\", \\\"{x:475,y:831,t:1527264599564};\\\", \\\"{x:464,y:825,t:1527264599580};\\\", \\\"{x:458,y:821,t:1527264599598};\\\", \\\"{x:453,y:819,t:1527264599614};\\\", \\\"{x:452,y:818,t:1527264599631};\\\", \\\"{x:451,y:818,t:1527264599649};\\\", \\\"{x:458,y:812,t:1527264599665};\\\", \\\"{x:509,y:773,t:1527264599681};\\\", \\\"{x:599,y:723,t:1527264599697};\\\", \\\"{x:645,y:692,t:1527264599714};\\\", \\\"{x:700,y:673,t:1527264599731};\\\", \\\"{x:828,y:624,t:1527264599747};\\\", \\\"{x:948,y:588,t:1527264599765};\\\", \\\"{x:1097,y:540,t:1527264599781};\\\", \\\"{x:1217,y:502,t:1527264599797};\\\", \\\"{x:1297,y:482,t:1527264599805};\\\", \\\"{x:1436,y:437,t:1527264599822};\\\", \\\"{x:1577,y:398,t:1527264599838};\\\", \\\"{x:1691,y:358,t:1527264599856};\\\", \\\"{x:1808,y:307,t:1527264599873};\\\", \\\"{x:1856,y:286,t:1527264599889};\\\", \\\"{x:1869,y:274,t:1527264599905};\\\", \\\"{x:1877,y:268,t:1527264599922};\\\", \\\"{x:1880,y:265,t:1527264599939};\\\", \\\"{x:1880,y:264,t:1527264599955};\\\", \\\"{x:1879,y:264,t:1527264600154};\\\", \\\"{x:1877,y:264,t:1527264600162};\\\", \\\"{x:1873,y:264,t:1527264600173};\\\", \\\"{x:1868,y:265,t:1527264600190};\\\", \\\"{x:1866,y:266,t:1527264600207};\\\", \\\"{x:1860,y:266,t:1527264600225};\\\", \\\"{x:1851,y:266,t:1527264600239};\\\", \\\"{x:1834,y:267,t:1527264600256};\\\", \\\"{x:1826,y:270,t:1527264600274};\\\", \\\"{x:1819,y:271,t:1527264600289};\\\", \\\"{x:1814,y:275,t:1527264600307};\\\", \\\"{x:1811,y:276,t:1527264600324};\\\", \\\"{x:1806,y:278,t:1527264600340};\\\", \\\"{x:1799,y:284,t:1527264600356};\\\", \\\"{x:1795,y:289,t:1527264600373};\\\", \\\"{x:1782,y:301,t:1527264600391};\\\", \\\"{x:1769,y:316,t:1527264600407};\\\", \\\"{x:1760,y:330,t:1527264600424};\\\", \\\"{x:1746,y:355,t:1527264600441};\\\", \\\"{x:1740,y:368,t:1527264600458};\\\", \\\"{x:1734,y:379,t:1527264600474};\\\", \\\"{x:1732,y:389,t:1527264600491};\\\", \\\"{x:1728,y:399,t:1527264600508};\\\", \\\"{x:1724,y:412,t:1527264600524};\\\", \\\"{x:1718,y:424,t:1527264600540};\\\", \\\"{x:1712,y:436,t:1527264600558};\\\", \\\"{x:1706,y:455,t:1527264600574};\\\", \\\"{x:1696,y:480,t:1527264600591};\\\", \\\"{x:1688,y:504,t:1527264600608};\\\", \\\"{x:1671,y:550,t:1527264600624};\\\", \\\"{x:1657,y:586,t:1527264600641};\\\", \\\"{x:1645,y:613,t:1527264600657};\\\", \\\"{x:1633,y:643,t:1527264600674};\\\", \\\"{x:1623,y:659,t:1527264600691};\\\", \\\"{x:1621,y:672,t:1527264600708};\\\", \\\"{x:1619,y:675,t:1527264600725};\\\", \\\"{x:1617,y:677,t:1527264600741};\\\", \\\"{x:1617,y:678,t:1527264600758};\\\", \\\"{x:1616,y:679,t:1527264600775};\\\", \\\"{x:1615,y:679,t:1527264600858};\\\", \\\"{x:1612,y:680,t:1527264600874};\\\", \\\"{x:1603,y:684,t:1527264600891};\\\", \\\"{x:1586,y:690,t:1527264600908};\\\", \\\"{x:1571,y:697,t:1527264600924};\\\", \\\"{x:1555,y:703,t:1527264600942};\\\", \\\"{x:1546,y:710,t:1527264600958};\\\", \\\"{x:1543,y:711,t:1527264600976};\\\", \\\"{x:1542,y:711,t:1527264600991};\\\", \\\"{x:1540,y:713,t:1527264601009};\\\", \\\"{x:1536,y:714,t:1527264601025};\\\", \\\"{x:1535,y:715,t:1527264601042};\\\", \\\"{x:1533,y:717,t:1527264601058};\\\", \\\"{x:1530,y:719,t:1527264601075};\\\", \\\"{x:1528,y:721,t:1527264601092};\\\", \\\"{x:1524,y:723,t:1527264601109};\\\", \\\"{x:1520,y:727,t:1527264601126};\\\", \\\"{x:1517,y:729,t:1527264601142};\\\", \\\"{x:1514,y:731,t:1527264601159};\\\", \\\"{x:1512,y:733,t:1527264601176};\\\", \\\"{x:1507,y:735,t:1527264601193};\\\", \\\"{x:1506,y:736,t:1527264601209};\\\", \\\"{x:1505,y:737,t:1527264601241};\\\", \\\"{x:1504,y:737,t:1527264601489};\\\", \\\"{x:1504,y:735,t:1527264601522};\\\", \\\"{x:1504,y:732,t:1527264601530};\\\", \\\"{x:1505,y:731,t:1527264601543};\\\", \\\"{x:1506,y:727,t:1527264601561};\\\", \\\"{x:1508,y:723,t:1527264601577};\\\", \\\"{x:1509,y:720,t:1527264601593};\\\", \\\"{x:1510,y:718,t:1527264601611};\\\", \\\"{x:1511,y:716,t:1527264601627};\\\", \\\"{x:1512,y:714,t:1527264601645};\\\", \\\"{x:1512,y:713,t:1527264601660};\\\", \\\"{x:1512,y:711,t:1527264601698};\\\", \\\"{x:1512,y:710,t:1527264601729};\\\", \\\"{x:1514,y:707,t:1527264601905};\\\", \\\"{x:1514,y:703,t:1527264601912};\\\", \\\"{x:1515,y:699,t:1527264601928};\\\", \\\"{x:1518,y:687,t:1527264601944};\\\", \\\"{x:1518,y:683,t:1527264601961};\\\", \\\"{x:1519,y:681,t:1527264601978};\\\", \\\"{x:1522,y:672,t:1527264601994};\\\", \\\"{x:1523,y:670,t:1527264602011};\\\", \\\"{x:1524,y:668,t:1527264602028};\\\", \\\"{x:1521,y:669,t:1527264602217};\\\", \\\"{x:1517,y:673,t:1527264602228};\\\", \\\"{x:1512,y:680,t:1527264602246};\\\", \\\"{x:1503,y:690,t:1527264602263};\\\", \\\"{x:1496,y:699,t:1527264602279};\\\", \\\"{x:1488,y:706,t:1527264602296};\\\", \\\"{x:1480,y:716,t:1527264602313};\\\", \\\"{x:1472,y:726,t:1527264602330};\\\", \\\"{x:1467,y:738,t:1527264602346};\\\", \\\"{x:1460,y:751,t:1527264602362};\\\", \\\"{x:1452,y:765,t:1527264602379};\\\", \\\"{x:1446,y:776,t:1527264602395};\\\", \\\"{x:1441,y:786,t:1527264602412};\\\", \\\"{x:1437,y:794,t:1527264602429};\\\", \\\"{x:1435,y:798,t:1527264602445};\\\", \\\"{x:1432,y:806,t:1527264602462};\\\", \\\"{x:1431,y:810,t:1527264602478};\\\", \\\"{x:1428,y:818,t:1527264602496};\\\", \\\"{x:1424,y:827,t:1527264602512};\\\", \\\"{x:1424,y:831,t:1527264602528};\\\", \\\"{x:1421,y:837,t:1527264602545};\\\", \\\"{x:1419,y:845,t:1527264602562};\\\", \\\"{x:1418,y:857,t:1527264602579};\\\", \\\"{x:1414,y:866,t:1527264602596};\\\", \\\"{x:1411,y:872,t:1527264602613};\\\", \\\"{x:1407,y:878,t:1527264602628};\\\", \\\"{x:1405,y:884,t:1527264602646};\\\", \\\"{x:1402,y:890,t:1527264602663};\\\", \\\"{x:1398,y:897,t:1527264602678};\\\", \\\"{x:1398,y:899,t:1527264602696};\\\", \\\"{x:1395,y:903,t:1527264602713};\\\", \\\"{x:1394,y:907,t:1527264602729};\\\", \\\"{x:1393,y:907,t:1527264602746};\\\", \\\"{x:1392,y:911,t:1527264602763};\\\", \\\"{x:1390,y:913,t:1527264602780};\\\", \\\"{x:1388,y:918,t:1527264602796};\\\", \\\"{x:1386,y:921,t:1527264602813};\\\", \\\"{x:1384,y:924,t:1527264602829};\\\", \\\"{x:1382,y:929,t:1527264602846};\\\", \\\"{x:1378,y:933,t:1527264602863};\\\", \\\"{x:1377,y:933,t:1527264602880};\\\", \\\"{x:1374,y:937,t:1527264602896};\\\", \\\"{x:1370,y:940,t:1527264602913};\\\", \\\"{x:1366,y:944,t:1527264602930};\\\", \\\"{x:1363,y:946,t:1527264602948};\\\", \\\"{x:1360,y:948,t:1527264602963};\\\", \\\"{x:1357,y:951,t:1527264602980};\\\", \\\"{x:1353,y:954,t:1527264602997};\\\", \\\"{x:1350,y:957,t:1527264603014};\\\", \\\"{x:1347,y:959,t:1527264603030};\\\", \\\"{x:1345,y:962,t:1527264603047};\\\", \\\"{x:1344,y:962,t:1527264603064};\\\", \\\"{x:1340,y:966,t:1527264603080};\\\", \\\"{x:1336,y:969,t:1527264603097};\\\", \\\"{x:1335,y:969,t:1527264603114};\\\", \\\"{x:1334,y:970,t:1527264603130};\\\", \\\"{x:1333,y:972,t:1527264603147};\\\", \\\"{x:1331,y:972,t:1527264603164};\\\", \\\"{x:1330,y:973,t:1527264603180};\\\", \\\"{x:1330,y:974,t:1527264603361};\\\", \\\"{x:1327,y:973,t:1527264603370};\\\", \\\"{x:1324,y:971,t:1527264603381};\\\", \\\"{x:1322,y:967,t:1527264603398};\\\", \\\"{x:1319,y:965,t:1527264603415};\\\", \\\"{x:1317,y:963,t:1527264603432};\\\", \\\"{x:1313,y:961,t:1527264603448};\\\", \\\"{x:1304,y:957,t:1527264603464};\\\", \\\"{x:1287,y:950,t:1527264603481};\\\", \\\"{x:1275,y:944,t:1527264603499};\\\", \\\"{x:1269,y:938,t:1527264603515};\\\", \\\"{x:1254,y:930,t:1527264603531};\\\", \\\"{x:1240,y:924,t:1527264603548};\\\", \\\"{x:1233,y:919,t:1527264603566};\\\", \\\"{x:1233,y:916,t:1527264603581};\\\", \\\"{x:1230,y:913,t:1527264603598};\\\", \\\"{x:1229,y:912,t:1527264603615};\\\", \\\"{x:1229,y:911,t:1527264603666};\\\", \\\"{x:1229,y:910,t:1527264603683};\\\", \\\"{x:1229,y:907,t:1527264603698};\\\", \\\"{x:1229,y:906,t:1527264603715};\\\", \\\"{x:1229,y:905,t:1527264603733};\\\", \\\"{x:1229,y:903,t:1527264603748};\\\", \\\"{x:1229,y:902,t:1527264603765};\\\", \\\"{x:1229,y:899,t:1527264603783};\\\", \\\"{x:1230,y:897,t:1527264603800};\\\", \\\"{x:1233,y:894,t:1527264603817};\\\", \\\"{x:1234,y:894,t:1527264603833};\\\", \\\"{x:1236,y:891,t:1527264603850};\\\", \\\"{x:1237,y:890,t:1527264603865};\\\", \\\"{x:1238,y:888,t:1527264603882};\\\", \\\"{x:1240,y:885,t:1527264603900};\\\", \\\"{x:1241,y:883,t:1527264603917};\\\", \\\"{x:1244,y:879,t:1527264603933};\\\", \\\"{x:1246,y:875,t:1527264603949};\\\", \\\"{x:1248,y:870,t:1527264603967};\\\", \\\"{x:1251,y:865,t:1527264603982};\\\", \\\"{x:1254,y:861,t:1527264604000};\\\", \\\"{x:1256,y:859,t:1527264604016};\\\", \\\"{x:1258,y:857,t:1527264604032};\\\", \\\"{x:1262,y:853,t:1527264604050};\\\", \\\"{x:1264,y:850,t:1527264604066};\\\", \\\"{x:1265,y:847,t:1527264604083};\\\", \\\"{x:1267,y:843,t:1527264604100};\\\", \\\"{x:1268,y:841,t:1527264604116};\\\", \\\"{x:1272,y:835,t:1527264604134};\\\", \\\"{x:1278,y:827,t:1527264604149};\\\", \\\"{x:1283,y:821,t:1527264604167};\\\", \\\"{x:1287,y:815,t:1527264604184};\\\", \\\"{x:1291,y:803,t:1527264604199};\\\", \\\"{x:1297,y:794,t:1527264604216};\\\", \\\"{x:1308,y:779,t:1527264604233};\\\", \\\"{x:1317,y:769,t:1527264604250};\\\", \\\"{x:1324,y:759,t:1527264604267};\\\", \\\"{x:1330,y:749,t:1527264604284};\\\", \\\"{x:1335,y:742,t:1527264604301};\\\", \\\"{x:1342,y:731,t:1527264604317};\\\", \\\"{x:1350,y:721,t:1527264604334};\\\", \\\"{x:1361,y:708,t:1527264604350};\\\", \\\"{x:1372,y:694,t:1527264604367};\\\", \\\"{x:1383,y:677,t:1527264604384};\\\", \\\"{x:1391,y:663,t:1527264604401};\\\", \\\"{x:1403,y:647,t:1527264604417};\\\", \\\"{x:1409,y:636,t:1527264604433};\\\", \\\"{x:1415,y:624,t:1527264604450};\\\", \\\"{x:1419,y:617,t:1527264604467};\\\", \\\"{x:1423,y:611,t:1527264604483};\\\", \\\"{x:1428,y:598,t:1527264604499};\\\", \\\"{x:1432,y:590,t:1527264604517};\\\", \\\"{x:1434,y:585,t:1527264604534};\\\", \\\"{x:1438,y:574,t:1527264604550};\\\", \\\"{x:1442,y:560,t:1527264604567};\\\", \\\"{x:1445,y:546,t:1527264604584};\\\", \\\"{x:1448,y:536,t:1527264604600};\\\", \\\"{x:1455,y:513,t:1527264604617};\\\", \\\"{x:1458,y:497,t:1527264604634};\\\", \\\"{x:1463,y:485,t:1527264604651};\\\", \\\"{x:1463,y:481,t:1527264604667};\\\", \\\"{x:1465,y:474,t:1527264604684};\\\", \\\"{x:1468,y:464,t:1527264604701};\\\", \\\"{x:1471,y:453,t:1527264604717};\\\", \\\"{x:1472,y:442,t:1527264604734};\\\", \\\"{x:1476,y:430,t:1527264604751};\\\", \\\"{x:1477,y:422,t:1527264604767};\\\", \\\"{x:1478,y:415,t:1527264604784};\\\", \\\"{x:1479,y:406,t:1527264604801};\\\", \\\"{x:1479,y:405,t:1527264604818};\\\", \\\"{x:1479,y:403,t:1527264604834};\\\", \\\"{x:1479,y:400,t:1527264604851};\\\", \\\"{x:1479,y:395,t:1527264604868};\\\", \\\"{x:1479,y:391,t:1527264604884};\\\", \\\"{x:1479,y:388,t:1527264604901};\\\", \\\"{x:1476,y:382,t:1527264604918};\\\", \\\"{x:1470,y:375,t:1527264604935};\\\", \\\"{x:1464,y:363,t:1527264604952};\\\", \\\"{x:1462,y:356,t:1527264604969};\\\", \\\"{x:1455,y:348,t:1527264604986};\\\", \\\"{x:1446,y:339,t:1527264605002};\\\", \\\"{x:1439,y:333,t:1527264605018};\\\", \\\"{x:1433,y:328,t:1527264605035};\\\", \\\"{x:1432,y:326,t:1527264605051};\\\", \\\"{x:1430,y:324,t:1527264605068};\\\", \\\"{x:1428,y:322,t:1527264605085};\\\", \\\"{x:1427,y:322,t:1527264605102};\\\", \\\"{x:1427,y:321,t:1527264605118};\\\", \\\"{x:1426,y:321,t:1527264605250};\\\", \\\"{x:1425,y:321,t:1527264605257};\\\", \\\"{x:1423,y:321,t:1527264605269};\\\", \\\"{x:1419,y:324,t:1527264605285};\\\", \\\"{x:1416,y:327,t:1527264605302};\\\", \\\"{x:1415,y:330,t:1527264605319};\\\", \\\"{x:1412,y:336,t:1527264605336};\\\", \\\"{x:1408,y:343,t:1527264605352};\\\", \\\"{x:1404,y:352,t:1527264605369};\\\", \\\"{x:1403,y:354,t:1527264605385};\\\", \\\"{x:1400,y:358,t:1527264605403};\\\", \\\"{x:1398,y:363,t:1527264605420};\\\", \\\"{x:1398,y:366,t:1527264605436};\\\", \\\"{x:1396,y:372,t:1527264605452};\\\", \\\"{x:1396,y:377,t:1527264605469};\\\", \\\"{x:1395,y:381,t:1527264605486};\\\", \\\"{x:1395,y:383,t:1527264605503};\\\", \\\"{x:1395,y:387,t:1527264605519};\\\", \\\"{x:1394,y:392,t:1527264605537};\\\", \\\"{x:1394,y:403,t:1527264605553};\\\", \\\"{x:1394,y:410,t:1527264605569};\\\", \\\"{x:1393,y:417,t:1527264605587};\\\", \\\"{x:1392,y:423,t:1527264605604};\\\", \\\"{x:1391,y:430,t:1527264605619};\\\", \\\"{x:1390,y:433,t:1527264605641};\\\", \\\"{x:1390,y:436,t:1527264605653};\\\", \\\"{x:1389,y:441,t:1527264605670};\\\", \\\"{x:1388,y:444,t:1527264605687};\\\", \\\"{x:1387,y:445,t:1527264605704};\\\", \\\"{x:1387,y:447,t:1527264605721};\\\", \\\"{x:1390,y:454,t:1527264606266};\\\", \\\"{x:1401,y:460,t:1527264606273};\\\", \\\"{x:1408,y:465,t:1527264606289};\\\", \\\"{x:1421,y:475,t:1527264606304};\\\", \\\"{x:1446,y:492,t:1527264606321};\\\", \\\"{x:1468,y:504,t:1527264606338};\\\", \\\"{x:1471,y:512,t:1527264606355};\\\", \\\"{x:1494,y:527,t:1527264606372};\\\", \\\"{x:1513,y:542,t:1527264606389};\\\", \\\"{x:1531,y:556,t:1527264606405};\\\", \\\"{x:1531,y:564,t:1527264606422};\\\", \\\"{x:1533,y:569,t:1527264606438};\\\", \\\"{x:1542,y:577,t:1527264606456};\\\", \\\"{x:1550,y:587,t:1527264606472};\\\", \\\"{x:1555,y:592,t:1527264606488};\\\", \\\"{x:1558,y:596,t:1527264606505};\\\", \\\"{x:1560,y:603,t:1527264606522};\\\", \\\"{x:1564,y:609,t:1527264606538};\\\", \\\"{x:1566,y:615,t:1527264606555};\\\", \\\"{x:1573,y:628,t:1527264606573};\\\", \\\"{x:1574,y:632,t:1527264606589};\\\", \\\"{x:1584,y:645,t:1527264606605};\\\", \\\"{x:1596,y:661,t:1527264606623};\\\", \\\"{x:1606,y:677,t:1527264606639};\\\", \\\"{x:1612,y:689,t:1527264606656};\\\", \\\"{x:1618,y:702,t:1527264606672};\\\", \\\"{x:1631,y:719,t:1527264606689};\\\", \\\"{x:1641,y:735,t:1527264606705};\\\", \\\"{x:1656,y:758,t:1527264606723};\\\", \\\"{x:1670,y:781,t:1527264606739};\\\", \\\"{x:1684,y:797,t:1527264606756};\\\", \\\"{x:1694,y:812,t:1527264606773};\\\", \\\"{x:1700,y:820,t:1527264606790};\\\", \\\"{x:1704,y:831,t:1527264606807};\\\", \\\"{x:1708,y:838,t:1527264606823};\\\", \\\"{x:1711,y:843,t:1527264606841};\\\", \\\"{x:1711,y:845,t:1527264606856};\\\", \\\"{x:1713,y:854,t:1527264606872};\\\", \\\"{x:1717,y:869,t:1527264606889};\\\", \\\"{x:1721,y:880,t:1527264606907};\\\", \\\"{x:1722,y:886,t:1527264606922};\\\", \\\"{x:1722,y:892,t:1527264606939};\\\", \\\"{x:1722,y:894,t:1527264606956};\\\", \\\"{x:1724,y:905,t:1527264606973};\\\", \\\"{x:1730,y:921,t:1527264606990};\\\", \\\"{x:1733,y:931,t:1527264607007};\\\", \\\"{x:1734,y:940,t:1527264607023};\\\", \\\"{x:1736,y:945,t:1527264607039};\\\", \\\"{x:1737,y:949,t:1527264607057};\\\", \\\"{x:1739,y:951,t:1527264607073};\\\", \\\"{x:1739,y:952,t:1527264607090};\\\", \\\"{x:1739,y:954,t:1527264607107};\\\", \\\"{x:1740,y:955,t:1527264607123};\\\", \\\"{x:1741,y:956,t:1527264607141};\\\", \\\"{x:1743,y:961,t:1527264607156};\\\", \\\"{x:1747,y:969,t:1527264607174};\\\", \\\"{x:1748,y:972,t:1527264607191};\\\", \\\"{x:1748,y:974,t:1527264607206};\\\", \\\"{x:1749,y:974,t:1527264607362};\\\", \\\"{x:1748,y:967,t:1527264607375};\\\", \\\"{x:1742,y:949,t:1527264607391};\\\", \\\"{x:1737,y:936,t:1527264607408};\\\", \\\"{x:1732,y:927,t:1527264607425};\\\", \\\"{x:1724,y:916,t:1527264607441};\\\", \\\"{x:1717,y:910,t:1527264607457};\\\", \\\"{x:1717,y:907,t:1527264607474};\\\", \\\"{x:1716,y:904,t:1527264607490};\\\", \\\"{x:1716,y:903,t:1527264607507};\\\", \\\"{x:1715,y:902,t:1527264607525};\\\", \\\"{x:1715,y:900,t:1527264607542};\\\", \\\"{x:1715,y:899,t:1527264607577};\\\", \\\"{x:1716,y:897,t:1527264607592};\\\", \\\"{x:1716,y:896,t:1527264607610};\\\", \\\"{x:1716,y:895,t:1527264607624};\\\", \\\"{x:1716,y:891,t:1527264607641};\\\", \\\"{x:1716,y:888,t:1527264607658};\\\", \\\"{x:1716,y:886,t:1527264607673};\\\", \\\"{x:1716,y:883,t:1527264607690};\\\", \\\"{x:1715,y:879,t:1527264607708};\\\", \\\"{x:1714,y:874,t:1527264607724};\\\", \\\"{x:1712,y:872,t:1527264607741};\\\", \\\"{x:1712,y:870,t:1527264607758};\\\", \\\"{x:1711,y:866,t:1527264607774};\\\", \\\"{x:1710,y:864,t:1527264607791};\\\", \\\"{x:1708,y:861,t:1527264607808};\\\", \\\"{x:1704,y:857,t:1527264607824};\\\", \\\"{x:1702,y:849,t:1527264607841};\\\", \\\"{x:1701,y:848,t:1527264607864};\\\", \\\"{x:1701,y:847,t:1527264607889};\\\", \\\"{x:1701,y:846,t:1527264607938};\\\", \\\"{x:1700,y:844,t:1527264607945};\\\", \\\"{x:1699,y:843,t:1527264607985};\\\", \\\"{x:1697,y:842,t:1527264607994};\\\", \\\"{x:1695,y:838,t:1527264608009};\\\", \\\"{x:1686,y:831,t:1527264608026};\\\", \\\"{x:1684,y:828,t:1527264608042};\\\", \\\"{x:1684,y:825,t:1527264608058};\\\", \\\"{x:1683,y:825,t:1527264608074};\\\", \\\"{x:1682,y:825,t:1527264608092};\\\", \\\"{x:1680,y:823,t:1527264608112};\\\", \\\"{x:1679,y:822,t:1527264608128};\\\", \\\"{x:1679,y:821,t:1527264608142};\\\", \\\"{x:1678,y:818,t:1527264608159};\\\", \\\"{x:1677,y:818,t:1527264608175};\\\", \\\"{x:1677,y:817,t:1527264608192};\\\", \\\"{x:1676,y:815,t:1527264608208};\\\", \\\"{x:1675,y:813,t:1527264608227};\\\", \\\"{x:1673,y:811,t:1527264608242};\\\", \\\"{x:1672,y:809,t:1527264608259};\\\", \\\"{x:1672,y:806,t:1527264608276};\\\", \\\"{x:1669,y:802,t:1527264608292};\\\", \\\"{x:1668,y:800,t:1527264608309};\\\", \\\"{x:1666,y:797,t:1527264608326};\\\", \\\"{x:1665,y:795,t:1527264608342};\\\", \\\"{x:1663,y:793,t:1527264608359};\\\", \\\"{x:1661,y:788,t:1527264608376};\\\", \\\"{x:1659,y:787,t:1527264608393};\\\", \\\"{x:1659,y:785,t:1527264608409};\\\", \\\"{x:1659,y:784,t:1527264608466};\\\", \\\"{x:1659,y:782,t:1527264608481};\\\", \\\"{x:1659,y:781,t:1527264608493};\\\", \\\"{x:1659,y:778,t:1527264608509};\\\", \\\"{x:1657,y:775,t:1527264608527};\\\", \\\"{x:1656,y:773,t:1527264608544};\\\", \\\"{x:1652,y:769,t:1527264608560};\\\", \\\"{x:1646,y:765,t:1527264608577};\\\", \\\"{x:1643,y:762,t:1527264608593};\\\", \\\"{x:1641,y:760,t:1527264608611};\\\", \\\"{x:1640,y:759,t:1527264608626};\\\", \\\"{x:1640,y:760,t:1527264608962};\\\", \\\"{x:1640,y:764,t:1527264608978};\\\", \\\"{x:1641,y:768,t:1527264608995};\\\", \\\"{x:1641,y:769,t:1527264609011};\\\", \\\"{x:1641,y:770,t:1527264609028};\\\", \\\"{x:1641,y:771,t:1527264609045};\\\", \\\"{x:1641,y:772,t:1527264609090};\\\", \\\"{x:1641,y:773,t:1527264609097};\\\", \\\"{x:1642,y:774,t:1527264609111};\\\", \\\"{x:1644,y:777,t:1527264609129};\\\", \\\"{x:1645,y:777,t:1527264609145};\\\", \\\"{x:1647,y:779,t:1527264609202};\\\", \\\"{x:1651,y:784,t:1527264609211};\\\", \\\"{x:1657,y:791,t:1527264609229};\\\", \\\"{x:1663,y:797,t:1527264609246};\\\", \\\"{x:1667,y:801,t:1527264609261};\\\", \\\"{x:1669,y:803,t:1527264609279};\\\", \\\"{x:1670,y:805,t:1527264609296};\\\", \\\"{x:1672,y:806,t:1527264609313};\\\", \\\"{x:1672,y:807,t:1527264609329};\\\", \\\"{x:1673,y:810,t:1527264609345};\\\", \\\"{x:1676,y:812,t:1527264609362};\\\", \\\"{x:1676,y:813,t:1527264609385};\\\", \\\"{x:1677,y:815,t:1527264609426};\\\", \\\"{x:1679,y:818,t:1527264609449};\\\", \\\"{x:1679,y:819,t:1527264609466};\\\", \\\"{x:1679,y:820,t:1527264609478};\\\", \\\"{x:1679,y:821,t:1527264609506};\\\", \\\"{x:1680,y:823,t:1527264609529};\\\", \\\"{x:1682,y:826,t:1527264609546};\\\", \\\"{x:1683,y:829,t:1527264609564};\\\", \\\"{x:1683,y:834,t:1527264609580};\\\", \\\"{x:1686,y:840,t:1527264609596};\\\", \\\"{x:1688,y:850,t:1527264609613};\\\", \\\"{x:1694,y:863,t:1527264609629};\\\", \\\"{x:1698,y:871,t:1527264609645};\\\", \\\"{x:1701,y:884,t:1527264609662};\\\", \\\"{x:1702,y:898,t:1527264609679};\\\", \\\"{x:1704,y:915,t:1527264609696};\\\", \\\"{x:1708,y:933,t:1527264609712};\\\", \\\"{x:1713,y:957,t:1527264609729};\\\", \\\"{x:1715,y:960,t:1527264609746};\\\", \\\"{x:1716,y:966,t:1527264609762};\\\", \\\"{x:1715,y:966,t:1527264609779};\\\", \\\"{x:1715,y:967,t:1527264609873};\\\", \\\"{x:1713,y:967,t:1527264609881};\\\", \\\"{x:1711,y:967,t:1527264609905};\\\", \\\"{x:1710,y:967,t:1527264609921};\\\", \\\"{x:1709,y:967,t:1527264609946};\\\", \\\"{x:1708,y:967,t:1527264609961};\\\", \\\"{x:1707,y:967,t:1527264609993};\\\", \\\"{x:1707,y:966,t:1527264610025};\\\", \\\"{x:1706,y:965,t:1527264610033};\\\", \\\"{x:1705,y:964,t:1527264610046};\\\", \\\"{x:1704,y:964,t:1527264610063};\\\", \\\"{x:1704,y:963,t:1527264610081};\\\", \\\"{x:1703,y:962,t:1527264610097};\\\", \\\"{x:1703,y:961,t:1527264610170};\\\", \\\"{x:1703,y:960,t:1527264610193};\\\", \\\"{x:1703,y:958,t:1527264610218};\\\", \\\"{x:1702,y:958,t:1527264610231};\\\", \\\"{x:1701,y:956,t:1527264610247};\\\", \\\"{x:1700,y:954,t:1527264610265};\\\", \\\"{x:1699,y:953,t:1527264610281};\\\", \\\"{x:1698,y:951,t:1527264610305};\\\", \\\"{x:1697,y:951,t:1527264610314};\\\", \\\"{x:1695,y:949,t:1527264610330};\\\", \\\"{x:1689,y:947,t:1527264610347};\\\", \\\"{x:1684,y:943,t:1527264610365};\\\", \\\"{x:1680,y:939,t:1527264610381};\\\", \\\"{x:1672,y:931,t:1527264610398};\\\", \\\"{x:1664,y:923,t:1527264610415};\\\", \\\"{x:1652,y:915,t:1527264610432};\\\", \\\"{x:1632,y:903,t:1527264610448};\\\", \\\"{x:1621,y:894,t:1527264610465};\\\", \\\"{x:1581,y:871,t:1527264610482};\\\", \\\"{x:1553,y:854,t:1527264610498};\\\", \\\"{x:1516,y:833,t:1527264610515};\\\", \\\"{x:1494,y:812,t:1527264610532};\\\", \\\"{x:1483,y:800,t:1527264610549};\\\", \\\"{x:1462,y:785,t:1527264610565};\\\", \\\"{x:1437,y:773,t:1527264610582};\\\", \\\"{x:1426,y:762,t:1527264610599};\\\", \\\"{x:1390,y:750,t:1527264610616};\\\", \\\"{x:1380,y:740,t:1527264610631};\\\", \\\"{x:1359,y:724,t:1527264610648};\\\", \\\"{x:1338,y:717,t:1527264610664};\\\", \\\"{x:1327,y:711,t:1527264610681};\\\", \\\"{x:1314,y:705,t:1527264610698};\\\", \\\"{x:1294,y:699,t:1527264610715};\\\", \\\"{x:1271,y:693,t:1527264610731};\\\", \\\"{x:1255,y:682,t:1527264610748};\\\", \\\"{x:1231,y:674,t:1527264610765};\\\", \\\"{x:1219,y:665,t:1527264610781};\\\", \\\"{x:1211,y:657,t:1527264610798};\\\", \\\"{x:1201,y:655,t:1527264610815};\\\", \\\"{x:1200,y:649,t:1527264610833};\\\", \\\"{x:1189,y:648,t:1527264610849};\\\", \\\"{x:1187,y:648,t:1527264610865};\\\", \\\"{x:1186,y:648,t:1527264610961};\\\", \\\"{x:1186,y:649,t:1527264610986};\\\", \\\"{x:1187,y:650,t:1527264611160};\\\", \\\"{x:1188,y:650,t:1527264611168};\\\", \\\"{x:1190,y:651,t:1527264611182};\\\", \\\"{x:1192,y:656,t:1527264611199};\\\", \\\"{x:1219,y:672,t:1527264611217};\\\", \\\"{x:1249,y:693,t:1527264611232};\\\", \\\"{x:1275,y:706,t:1527264611249};\\\", \\\"{x:1316,y:729,t:1527264611267};\\\", \\\"{x:1373,y:750,t:1527264611283};\\\", \\\"{x:1428,y:779,t:1527264611299};\\\", \\\"{x:1467,y:798,t:1527264611316};\\\", \\\"{x:1475,y:812,t:1527264611333};\\\", \\\"{x:1488,y:823,t:1527264611350};\\\", \\\"{x:1494,y:829,t:1527264611366};\\\", \\\"{x:1497,y:837,t:1527264611383};\\\", \\\"{x:1498,y:845,t:1527264611400};\\\", \\\"{x:1499,y:859,t:1527264611417};\\\", \\\"{x:1502,y:879,t:1527264611433};\\\", \\\"{x:1502,y:885,t:1527264611451};\\\", \\\"{x:1502,y:887,t:1527264611466};\\\", \\\"{x:1502,y:890,t:1527264611483};\\\", \\\"{x:1501,y:892,t:1527264611501};\\\", \\\"{x:1499,y:894,t:1527264611517};\\\", \\\"{x:1496,y:897,t:1527264611533};\\\", \\\"{x:1491,y:897,t:1527264611937};\\\", \\\"{x:1480,y:896,t:1527264611951};\\\", \\\"{x:1359,y:868,t:1527264611968};\\\", \\\"{x:1274,y:847,t:1527264611984};\\\", \\\"{x:1213,y:830,t:1527264612001};\\\", \\\"{x:1164,y:810,t:1527264612019};\\\", \\\"{x:1089,y:790,t:1527264612034};\\\", \\\"{x:993,y:764,t:1527264612051};\\\", \\\"{x:890,y:736,t:1527264612072};\\\", \\\"{x:831,y:721,t:1527264612085};\\\", \\\"{x:750,y:690,t:1527264612101};\\\", \\\"{x:704,y:666,t:1527264612118};\\\", \\\"{x:670,y:654,t:1527264612135};\\\", \\\"{x:621,y:635,t:1527264612152};\\\", \\\"{x:538,y:611,t:1527264612168};\\\", \\\"{x:514,y:603,t:1527264612185};\\\", \\\"{x:495,y:599,t:1527264612198};\\\", \\\"{x:471,y:596,t:1527264612215};\\\", \\\"{x:452,y:592,t:1527264612231};\\\", \\\"{x:436,y:589,t:1527264612248};\\\", \\\"{x:433,y:589,t:1527264612265};\\\", \\\"{x:431,y:589,t:1527264612280};\\\", \\\"{x:429,y:591,t:1527264612297};\\\", \\\"{x:429,y:596,t:1527264612315};\\\", \\\"{x:428,y:602,t:1527264612332};\\\", \\\"{x:428,y:609,t:1527264612348};\\\", \\\"{x:428,y:614,t:1527264612366};\\\", \\\"{x:428,y:630,t:1527264612382};\\\", \\\"{x:439,y:664,t:1527264612404};\\\", \\\"{x:439,y:668,t:1527264612420};\\\", \\\"{x:449,y:684,t:1527264612437};\\\", \\\"{x:453,y:691,t:1527264612453};\\\", \\\"{x:459,y:693,t:1527264612470};\\\", \\\"{x:460,y:698,t:1527264612487};\\\", \\\"{x:465,y:701,t:1527264612503};\\\", \\\"{x:467,y:703,t:1527264612520};\\\", \\\"{x:468,y:704,t:1527264612552};\\\", \\\"{x:469,y:704,t:1527264612690};\\\", \\\"{x:470,y:707,t:1527264613032};\\\", \\\"{x:471,y:708,t:1527264613040};\\\", \\\"{x:471,y:709,t:1527264613054};\\\", \\\"{x:474,y:713,t:1527264613070};\\\", \\\"{x:476,y:716,t:1527264613087};\\\", \\\"{x:477,y:718,t:1527264613104};\\\", \\\"{x:478,y:719,t:1527264613121};\\\", \\\"{x:481,y:719,t:1527264613417};\\\", \\\"{x:490,y:719,t:1527264613425};\\\", \\\"{x:496,y:713,t:1527264613438};\\\", \\\"{x:523,y:702,t:1527264613454};\\\", \\\"{x:545,y:697,t:1527264613471};\\\", \\\"{x:551,y:696,t:1527264613487};\\\", \\\"{x:568,y:691,t:1527264613505};\\\", \\\"{x:589,y:679,t:1527264613521};\\\", \\\"{x:612,y:667,t:1527264613538};\\\", \\\"{x:640,y:652,t:1527264613554};\\\", \\\"{x:665,y:640,t:1527264613571};\\\", \\\"{x:673,y:636,t:1527264613588};\\\", \\\"{x:689,y:629,t:1527264613604};\\\", \\\"{x:710,y:623,t:1527264613621};\\\", \\\"{x:732,y:616,t:1527264613638};\\\", \\\"{x:745,y:610,t:1527264613654};\\\", \\\"{x:757,y:605,t:1527264613671};\\\", \\\"{x:769,y:598,t:1527264613689};\\\", \\\"{x:771,y:597,t:1527264613704};\\\", \\\"{x:777,y:594,t:1527264613722};\\\" ] }, { \\\"rt\\\": 13809, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 6, \\\"time_elapsed\\\": 211716, \\\"internal_node_id\\\": \\\"0.0-5.0-1.0\\\", \\\"subject\\\": \\\"RV9F6\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"lima\\\", \\\"condition\\\": \\\"115\\\", \\\"scenario\\\": \\\"acme\\\", \\\"question\\\": \\\"starts\\\", \\\"q\\\": 2, \\\"clicks\\\": 1, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XFull-YFull\\\", \\\"correct\\\": 1, \\\"orth_correct\\\": 0, \\\"answer\\\": [ \\\"K\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"X \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"U \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-D \\\", \\\"block\\\": \\\"triangular_scaffolded\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:780,y:592,t:1527264615290};\\\", \\\"{x:782,y:592,t:1527264615304};\\\", \\\"{x:786,y:592,t:1527264615312};\\\", \\\"{x:790,y:592,t:1527264615325};\\\", \\\"{x:809,y:595,t:1527264615342};\\\", \\\"{x:822,y:598,t:1527264615359};\\\", \\\"{x:824,y:598,t:1527264615375};\\\", \\\"{x:825,y:598,t:1527264615393};\\\", \\\"{x:830,y:598,t:1527264615409};\\\", \\\"{x:834,y:600,t:1527264615422};\\\", \\\"{x:842,y:601,t:1527264615439};\\\", \\\"{x:843,y:607,t:1527264615455};\\\", \\\"{x:859,y:609,t:1527264615472};\\\", \\\"{x:873,y:615,t:1527264615490};\\\", \\\"{x:889,y:623,t:1527264615506};\\\", \\\"{x:906,y:626,t:1527264615522};\\\", \\\"{x:920,y:633,t:1527264615539};\\\", \\\"{x:932,y:639,t:1527264615556};\\\", \\\"{x:947,y:648,t:1527264615572};\\\", \\\"{x:979,y:654,t:1527264615589};\\\", \\\"{x:1014,y:661,t:1527264615606};\\\", \\\"{x:1062,y:669,t:1527264615622};\\\", \\\"{x:1091,y:680,t:1527264615639};\\\", \\\"{x:1203,y:693,t:1527264615656};\\\", \\\"{x:1256,y:698,t:1527264615673};\\\", \\\"{x:1282,y:705,t:1527264615689};\\\", \\\"{x:1339,y:710,t:1527264615706};\\\", \\\"{x:1402,y:722,t:1527264615722};\\\", \\\"{x:1488,y:737,t:1527264615739};\\\", \\\"{x:1555,y:745,t:1527264615756};\\\", \\\"{x:1575,y:751,t:1527264615772};\\\", \\\"{x:1590,y:749,t:1527264615790};\\\", \\\"{x:1590,y:748,t:1527264615806};\\\", \\\"{x:1598,y:748,t:1527264615822};\\\", \\\"{x:1608,y:750,t:1527264615839};\\\", \\\"{x:1613,y:750,t:1527264615856};\\\", \\\"{x:1614,y:750,t:1527264615873};\\\", \\\"{x:1612,y:750,t:1527264616761};\\\", \\\"{x:1610,y:751,t:1527264616774};\\\", \\\"{x:1604,y:753,t:1527264616791};\\\", \\\"{x:1600,y:756,t:1527264616807};\\\", \\\"{x:1597,y:756,t:1527264616824};\\\", \\\"{x:1595,y:757,t:1527264616873};\\\", \\\"{x:1591,y:758,t:1527264616891};\\\", \\\"{x:1590,y:758,t:1527264616907};\\\", \\\"{x:1588,y:759,t:1527264616923};\\\", \\\"{x:1586,y:759,t:1527264616940};\\\", \\\"{x:1585,y:759,t:1527264616957};\\\", \\\"{x:1584,y:759,t:1527264616973};\\\", \\\"{x:1582,y:759,t:1527264619113};\\\", \\\"{x:1579,y:754,t:1527264619125};\\\", \\\"{x:1576,y:749,t:1527264619142};\\\", \\\"{x:1575,y:747,t:1527264619159};\\\", \\\"{x:1573,y:744,t:1527264619176};\\\", \\\"{x:1573,y:742,t:1527264619192};\\\", \\\"{x:1571,y:738,t:1527264619209};\\\", \\\"{x:1571,y:735,t:1527264619226};\\\", \\\"{x:1570,y:730,t:1527264619243};\\\", \\\"{x:1568,y:725,t:1527264619259};\\\", \\\"{x:1567,y:721,t:1527264619276};\\\", \\\"{x:1567,y:718,t:1527264619293};\\\", \\\"{x:1565,y:714,t:1527264619309};\\\", \\\"{x:1563,y:709,t:1527264619326};\\\", \\\"{x:1561,y:706,t:1527264619342};\\\", \\\"{x:1557,y:698,t:1527264619359};\\\", \\\"{x:1553,y:692,t:1527264619376};\\\", \\\"{x:1545,y:678,t:1527264619393};\\\", \\\"{x:1544,y:677,t:1527264619425};\\\", \\\"{x:1533,y:670,t:1527264619443};\\\", \\\"{x:1526,y:666,t:1527264619459};\\\", \\\"{x:1519,y:662,t:1527264619476};\\\", \\\"{x:1507,y:652,t:1527264619493};\\\", \\\"{x:1458,y:645,t:1527264619509};\\\", \\\"{x:1370,y:626,t:1527264619525};\\\", \\\"{x:1326,y:608,t:1527264619543};\\\", \\\"{x:1291,y:599,t:1527264619559};\\\", \\\"{x:1260,y:582,t:1527264619576};\\\", \\\"{x:1104,y:552,t:1527264619593};\\\", \\\"{x:1027,y:534,t:1527264619609};\\\", \\\"{x:998,y:522,t:1527264619626};\\\", \\\"{x:987,y:521,t:1527264619642};\\\", \\\"{x:987,y:520,t:1527264619713};\\\", \\\"{x:987,y:519,t:1527264619729};\\\", \\\"{x:988,y:518,t:1527264619743};\\\", \\\"{x:996,y:520,t:1527264619759};\\\", \\\"{x:998,y:522,t:1527264619784};\\\", \\\"{x:1004,y:526,t:1527264619793};\\\", \\\"{x:1027,y:532,t:1527264619809};\\\", \\\"{x:1066,y:540,t:1527264619826};\\\", \\\"{x:1139,y:550,t:1527264619843};\\\", \\\"{x:1198,y:566,t:1527264619860};\\\", \\\"{x:1272,y:573,t:1527264619876};\\\", \\\"{x:1352,y:580,t:1527264619893};\\\", \\\"{x:1404,y:585,t:1527264619910};\\\", \\\"{x:1422,y:587,t:1527264619926};\\\", \\\"{x:1434,y:590,t:1527264619943};\\\", \\\"{x:1445,y:590,t:1527264619960};\\\", \\\"{x:1456,y:590,t:1527264619976};\\\", \\\"{x:1462,y:588,t:1527264619993};\\\", \\\"{x:1465,y:588,t:1527264620010};\\\", \\\"{x:1470,y:583,t:1527264620025};\\\", \\\"{x:1472,y:579,t:1527264620043};\\\", \\\"{x:1473,y:576,t:1527264620059};\\\", \\\"{x:1477,y:568,t:1527264620076};\\\", \\\"{x:1480,y:564,t:1527264620093};\\\", \\\"{x:1482,y:556,t:1527264620110};\\\", \\\"{x:1485,y:549,t:1527264620126};\\\", \\\"{x:1487,y:543,t:1527264620143};\\\", \\\"{x:1488,y:537,t:1527264620160};\\\", \\\"{x:1492,y:528,t:1527264620177};\\\", \\\"{x:1495,y:523,t:1527264620192};\\\", \\\"{x:1497,y:519,t:1527264620209};\\\", \\\"{x:1500,y:517,t:1527264620226};\\\", \\\"{x:1501,y:516,t:1527264620242};\\\", \\\"{x:1504,y:515,t:1527264620259};\\\", \\\"{x:1509,y:512,t:1527264620276};\\\", \\\"{x:1510,y:511,t:1527264620292};\\\", \\\"{x:1512,y:510,t:1527264620309};\\\", \\\"{x:1517,y:506,t:1527264620326};\\\", \\\"{x:1526,y:506,t:1527264620343};\\\", \\\"{x:1536,y:501,t:1527264620359};\\\", \\\"{x:1547,y:495,t:1527264620376};\\\", \\\"{x:1556,y:491,t:1527264620392};\\\", \\\"{x:1563,y:487,t:1527264620409};\\\", \\\"{x:1570,y:484,t:1527264620427};\\\", \\\"{x:1576,y:479,t:1527264620443};\\\", \\\"{x:1582,y:475,t:1527264620459};\\\", \\\"{x:1584,y:473,t:1527264620477};\\\", \\\"{x:1586,y:471,t:1527264620493};\\\", \\\"{x:1587,y:470,t:1527264620510};\\\", \\\"{x:1587,y:468,t:1527264620609};\\\", \\\"{x:1587,y:465,t:1527264620626};\\\", \\\"{x:1587,y:462,t:1527264620644};\\\", \\\"{x:1588,y:460,t:1527264620673};\\\", \\\"{x:1589,y:458,t:1527264620681};\\\", \\\"{x:1591,y:457,t:1527264620694};\\\", \\\"{x:1591,y:456,t:1527264620713};\\\", \\\"{x:1592,y:454,t:1527264620727};\\\", \\\"{x:1595,y:451,t:1527264620744};\\\", \\\"{x:1599,y:447,t:1527264620760};\\\", \\\"{x:1601,y:446,t:1527264620777};\\\", \\\"{x:1602,y:444,t:1527264620794};\\\", \\\"{x:1603,y:443,t:1527264620810};\\\", \\\"{x:1604,y:442,t:1527264620833};\\\", \\\"{x:1605,y:442,t:1527264620857};\\\", \\\"{x:1606,y:440,t:1527264620873};\\\", \\\"{x:1607,y:439,t:1527264620897};\\\", \\\"{x:1608,y:437,t:1527264620913};\\\", \\\"{x:1609,y:436,t:1527264620969};\\\", \\\"{x:1610,y:435,t:1527264620985};\\\", \\\"{x:1611,y:434,t:1527264620995};\\\", \\\"{x:1612,y:434,t:1527264621009};\\\", \\\"{x:1607,y:434,t:1527264624555};\\\", \\\"{x:1594,y:437,t:1527264624563};\\\", \\\"{x:1513,y:461,t:1527264624580};\\\", \\\"{x:1381,y:496,t:1527264624596};\\\", \\\"{x:1290,y:531,t:1527264624613};\\\", \\\"{x:1126,y:567,t:1527264624630};\\\", \\\"{x:1106,y:571,t:1527264624646};\\\", \\\"{x:990,y:576,t:1527264624662};\\\", \\\"{x:842,y:577,t:1527264624680};\\\", \\\"{x:719,y:567,t:1527264624696};\\\", \\\"{x:556,y:543,t:1527264624713};\\\", \\\"{x:464,y:528,t:1527264624730};\\\", \\\"{x:433,y:518,t:1527264624739};\\\", \\\"{x:412,y:510,t:1527264624755};\\\", \\\"{x:404,y:506,t:1527264624772};\\\", \\\"{x:404,y:505,t:1527264624913};\\\", \\\"{x:405,y:502,t:1527264624930};\\\", \\\"{x:407,y:501,t:1527264624946};\\\", \\\"{x:419,y:498,t:1527264624963};\\\", \\\"{x:423,y:496,t:1527264624980};\\\", \\\"{x:425,y:496,t:1527264624997};\\\", \\\"{x:426,y:497,t:1527264625014};\\\", \\\"{x:430,y:501,t:1527264625030};\\\", \\\"{x:431,y:502,t:1527264625047};\\\", \\\"{x:433,y:506,t:1527264625064};\\\", \\\"{x:433,y:516,t:1527264625080};\\\", \\\"{x:427,y:528,t:1527264625096};\\\", \\\"{x:419,y:540,t:1527264625114};\\\", \\\"{x:415,y:545,t:1527264625131};\\\", \\\"{x:411,y:549,t:1527264625147};\\\", \\\"{x:408,y:552,t:1527264625163};\\\", \\\"{x:407,y:554,t:1527264625181};\\\", \\\"{x:405,y:557,t:1527264625197};\\\", \\\"{x:402,y:562,t:1527264625214};\\\", \\\"{x:400,y:565,t:1527264625231};\\\", \\\"{x:395,y:569,t:1527264625247};\\\", \\\"{x:392,y:576,t:1527264625264};\\\", \\\"{x:389,y:584,t:1527264625280};\\\", \\\"{x:388,y:592,t:1527264625298};\\\", \\\"{x:385,y:597,t:1527264625314};\\\", \\\"{x:385,y:598,t:1527264625330};\\\", \\\"{x:385,y:599,t:1527264625473};\\\", \\\"{x:389,y:600,t:1527264625776};\\\", \\\"{x:395,y:604,t:1527264625784};\\\", \\\"{x:401,y:610,t:1527264625797};\\\", \\\"{x:410,y:615,t:1527264625814};\\\", \\\"{x:417,y:623,t:1527264625832};\\\", \\\"{x:425,y:628,t:1527264625848};\\\", \\\"{x:427,y:631,t:1527264625863};\\\", \\\"{x:431,y:637,t:1527264625880};\\\", \\\"{x:438,y:648,t:1527264625897};\\\", \\\"{x:444,y:660,t:1527264625914};\\\", \\\"{x:448,y:670,t:1527264625930};\\\", \\\"{x:451,y:678,t:1527264625947};\\\", \\\"{x:453,y:686,t:1527264625964};\\\", \\\"{x:453,y:691,t:1527264625982};\\\", \\\"{x:455,y:694,t:1527264625997};\\\", \\\"{x:455,y:696,t:1527264626014};\\\", \\\"{x:456,y:700,t:1527264626031};\\\", \\\"{x:458,y:702,t:1527264626259};\\\", \\\"{x:459,y:704,t:1527264626280};\\\", \\\"{x:460,y:705,t:1527264626287};\\\", \\\"{x:460,y:707,t:1527264626368};\\\", \\\"{x:460,y:710,t:1527264626424};\\\", \\\"{x:462,y:711,t:1527264626456};\\\", \\\"{x:462,y:712,t:1527264626464};\\\", \\\"{x:463,y:713,t:1527264626497};\\\", \\\"{x:464,y:715,t:1527264626515};\\\", \\\"{x:465,y:716,t:1527264626537};\\\", \\\"{x:465,y:717,t:1527264626548};\\\", \\\"{x:466,y:717,t:1527264626565};\\\" ] }, { \\\"rt\\\": 18917, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 7, \\\"time_elapsed\\\": 231860, \\\"internal_node_id\\\": \\\"0.0-5.0-2.0\\\", \\\"subject\\\": \\\"RV9F6\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"lima\\\", \\\"condition\\\": \\\"115\\\", \\\"scenario\\\": \\\"acme\\\", \\\"question\\\": \\\"meets\\\", \\\"q\\\": 3, \\\"clicks\\\": 1, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XFull-YFull\\\", \\\"correct\\\": 1, \\\"orth_correct\\\": 0, \\\"answer\\\": [ \\\"F\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"X \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"U \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-11 AM-11 AM-C -11 AM-F \\\", \\\"block\\\": \\\"triangular_scaffolded\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:468,y:717,t:1527264630489};\\\", \\\"{x:477,y:715,t:1527264630505};\\\", \\\"{x:481,y:713,t:1527264630522};\\\", \\\"{x:490,y:707,t:1527264630538};\\\", \\\"{x:497,y:703,t:1527264630555};\\\", \\\"{x:507,y:697,t:1527264630574};\\\", \\\"{x:512,y:695,t:1527264630587};\\\", \\\"{x:514,y:694,t:1527264630849};\\\", \\\"{x:521,y:690,t:1527264630856};\\\", \\\"{x:526,y:686,t:1527264630868};\\\", \\\"{x:533,y:683,t:1527264630884};\\\", \\\"{x:534,y:682,t:1527264630901};\\\", \\\"{x:535,y:682,t:1527264630920};\\\", \\\"{x:539,y:680,t:1527264630934};\\\", \\\"{x:543,y:678,t:1527264630951};\\\", \\\"{x:555,y:674,t:1527264630968};\\\", \\\"{x:559,y:673,t:1527264630984};\\\", \\\"{x:562,y:674,t:1527264631001};\\\", \\\"{x:563,y:674,t:1527264631018};\\\", \\\"{x:569,y:674,t:1527264631881};\\\", \\\"{x:580,y:674,t:1527264631889};\\\", \\\"{x:583,y:674,t:1527264631902};\\\", \\\"{x:591,y:674,t:1527264631918};\\\", \\\"{x:599,y:675,t:1527264631935};\\\", \\\"{x:611,y:675,t:1527264631952};\\\", \\\"{x:615,y:675,t:1527264633568};\\\", \\\"{x:625,y:674,t:1527264633586};\\\", \\\"{x:632,y:672,t:1527264633602};\\\", \\\"{x:638,y:670,t:1527264633620};\\\", \\\"{x:657,y:670,t:1527264633636};\\\", \\\"{x:669,y:670,t:1527264633652};\\\", \\\"{x:685,y:670,t:1527264633669};\\\", \\\"{x:705,y:670,t:1527264633686};\\\", \\\"{x:727,y:673,t:1527264633702};\\\", \\\"{x:770,y:683,t:1527264633719};\\\", \\\"{x:846,y:685,t:1527264633736};\\\", \\\"{x:940,y:685,t:1527264633752};\\\", \\\"{x:1040,y:687,t:1527264633770};\\\", \\\"{x:1129,y:687,t:1527264633786};\\\", \\\"{x:1223,y:687,t:1527264633802};\\\", \\\"{x:1301,y:687,t:1527264633819};\\\", \\\"{x:1336,y:691,t:1527264633836};\\\", \\\"{x:1369,y:690,t:1527264633852};\\\", \\\"{x:1397,y:692,t:1527264633869};\\\", \\\"{x:1416,y:692,t:1527264633887};\\\", \\\"{x:1482,y:693,t:1527264633903};\\\", \\\"{x:1517,y:690,t:1527264633920};\\\", \\\"{x:1548,y:690,t:1527264633937};\\\", \\\"{x:1565,y:690,t:1527264633953};\\\", \\\"{x:1573,y:690,t:1527264633969};\\\", \\\"{x:1589,y:690,t:1527264633986};\\\", \\\"{x:1601,y:690,t:1527264634002};\\\", \\\"{x:1609,y:690,t:1527264634020};\\\", \\\"{x:1617,y:689,t:1527264634036};\\\", \\\"{x:1623,y:687,t:1527264634053};\\\", \\\"{x:1623,y:686,t:1527264634625};\\\", \\\"{x:1623,y:685,t:1527264635016};\\\", \\\"{x:1623,y:684,t:1527264635025};\\\", \\\"{x:1621,y:684,t:1527264635037};\\\", \\\"{x:1615,y:684,t:1527264635054};\\\", \\\"{x:1613,y:684,t:1527264635069};\\\", \\\"{x:1612,y:684,t:1527264635086};\\\", \\\"{x:1610,y:684,t:1527264635103};\\\", \\\"{x:1608,y:684,t:1527264635120};\\\", \\\"{x:1607,y:684,t:1527264635561};\\\", \\\"{x:1604,y:685,t:1527264635633};\\\", \\\"{x:1602,y:688,t:1527264635640};\\\", \\\"{x:1600,y:692,t:1527264635654};\\\", \\\"{x:1600,y:705,t:1527264635670};\\\", \\\"{x:1598,y:717,t:1527264635686};\\\", \\\"{x:1598,y:726,t:1527264635703};\\\", \\\"{x:1598,y:732,t:1527264635720};\\\", \\\"{x:1598,y:740,t:1527264635736};\\\", \\\"{x:1598,y:753,t:1527264635754};\\\", \\\"{x:1596,y:767,t:1527264635771};\\\", \\\"{x:1595,y:783,t:1527264635786};\\\", \\\"{x:1594,y:796,t:1527264635804};\\\", \\\"{x:1591,y:813,t:1527264635820};\\\", \\\"{x:1588,y:834,t:1527264635836};\\\", \\\"{x:1584,y:846,t:1527264635853};\\\", \\\"{x:1578,y:859,t:1527264635870};\\\", \\\"{x:1567,y:873,t:1527264635886};\\\", \\\"{x:1553,y:883,t:1527264635903};\\\", \\\"{x:1546,y:889,t:1527264635920};\\\", \\\"{x:1543,y:889,t:1527264635937};\\\", \\\"{x:1540,y:890,t:1527264635952};\\\", \\\"{x:1538,y:890,t:1527264635969};\\\", \\\"{x:1537,y:890,t:1527264636113};\\\", \\\"{x:1537,y:889,t:1527264636120};\\\", \\\"{x:1535,y:885,t:1527264636137};\\\", \\\"{x:1533,y:882,t:1527264636153};\\\", \\\"{x:1533,y:879,t:1527264636170};\\\", \\\"{x:1530,y:878,t:1527264636187};\\\", \\\"{x:1529,y:877,t:1527264636203};\\\", \\\"{x:1527,y:875,t:1527264636222};\\\", \\\"{x:1524,y:872,t:1527264636240};\\\", \\\"{x:1524,y:871,t:1527264636253};\\\", \\\"{x:1518,y:870,t:1527264636271};\\\", \\\"{x:1511,y:867,t:1527264636287};\\\", \\\"{x:1505,y:867,t:1527264636303};\\\", \\\"{x:1491,y:866,t:1527264636320};\\\", \\\"{x:1477,y:865,t:1527264636337};\\\", \\\"{x:1470,y:864,t:1527264636353};\\\", \\\"{x:1467,y:864,t:1527264636370};\\\", \\\"{x:1450,y:866,t:1527264636387};\\\", \\\"{x:1444,y:866,t:1527264636403};\\\", \\\"{x:1429,y:866,t:1527264636422};\\\", \\\"{x:1414,y:866,t:1527264636437};\\\", \\\"{x:1400,y:866,t:1527264636453};\\\", \\\"{x:1399,y:866,t:1527264636470};\\\", \\\"{x:1387,y:864,t:1527264636487};\\\", \\\"{x:1383,y:863,t:1527264636503};\\\", \\\"{x:1382,y:863,t:1527264636521};\\\", \\\"{x:1381,y:862,t:1527264636569};\\\", \\\"{x:1381,y:861,t:1527264636584};\\\", \\\"{x:1381,y:860,t:1527264636592};\\\", \\\"{x:1381,y:859,t:1527264636604};\\\", \\\"{x:1381,y:856,t:1527264636622};\\\", \\\"{x:1380,y:853,t:1527264636636};\\\", \\\"{x:1368,y:845,t:1527264636652};\\\", \\\"{x:1357,y:838,t:1527264636670};\\\", \\\"{x:1340,y:831,t:1527264636686};\\\", \\\"{x:1333,y:824,t:1527264636703};\\\", \\\"{x:1293,y:812,t:1527264636720};\\\", \\\"{x:1270,y:799,t:1527264636737};\\\", \\\"{x:1244,y:794,t:1527264636754};\\\", \\\"{x:1233,y:791,t:1527264636770};\\\", \\\"{x:1227,y:788,t:1527264636787};\\\", \\\"{x:1224,y:786,t:1527264636808};\\\", \\\"{x:1223,y:786,t:1527264636820};\\\", \\\"{x:1220,y:785,t:1527264636837};\\\", \\\"{x:1219,y:785,t:1527264637017};\\\", \\\"{x:1219,y:787,t:1527264637025};\\\", \\\"{x:1219,y:791,t:1527264637037};\\\", \\\"{x:1219,y:795,t:1527264637054};\\\", \\\"{x:1219,y:798,t:1527264637070};\\\", \\\"{x:1219,y:804,t:1527264637087};\\\", \\\"{x:1219,y:809,t:1527264637105};\\\", \\\"{x:1219,y:814,t:1527264637121};\\\", \\\"{x:1219,y:815,t:1527264637168};\\\", \\\"{x:1219,y:816,t:1527264637200};\\\", \\\"{x:1219,y:818,t:1527264637208};\\\", \\\"{x:1219,y:819,t:1527264637241};\\\", \\\"{x:1219,y:820,t:1527264637281};\\\", \\\"{x:1219,y:821,t:1527264637361};\\\", \\\"{x:1219,y:822,t:1527264637393};\\\", \\\"{x:1220,y:825,t:1527264637409};\\\", \\\"{x:1220,y:827,t:1527264637424};\\\", \\\"{x:1221,y:828,t:1527264637438};\\\", \\\"{x:1223,y:832,t:1527264637455};\\\", \\\"{x:1223,y:835,t:1527264637470};\\\", \\\"{x:1223,y:836,t:1527264637487};\\\", \\\"{x:1224,y:837,t:1527264637504};\\\", \\\"{x:1224,y:838,t:1527264637528};\\\", \\\"{x:1224,y:839,t:1527264637545};\\\", \\\"{x:1224,y:841,t:1527264637554};\\\", \\\"{x:1225,y:842,t:1527264637570};\\\", \\\"{x:1228,y:847,t:1527264637588};\\\", \\\"{x:1228,y:850,t:1527264637605};\\\", \\\"{x:1228,y:853,t:1527264637622};\\\", \\\"{x:1230,y:857,t:1527264637638};\\\", \\\"{x:1231,y:859,t:1527264637655};\\\", \\\"{x:1232,y:864,t:1527264637673};\\\", \\\"{x:1235,y:867,t:1527264637688};\\\", \\\"{x:1238,y:874,t:1527264637704};\\\", \\\"{x:1238,y:876,t:1527264637720};\\\", \\\"{x:1240,y:880,t:1527264637738};\\\", \\\"{x:1242,y:887,t:1527264637754};\\\", \\\"{x:1244,y:892,t:1527264637771};\\\", \\\"{x:1245,y:896,t:1527264637788};\\\", \\\"{x:1246,y:901,t:1527264637805};\\\", \\\"{x:1248,y:906,t:1527264637821};\\\", \\\"{x:1253,y:918,t:1527264637838};\\\", \\\"{x:1255,y:926,t:1527264637854};\\\", \\\"{x:1257,y:928,t:1527264637871};\\\", \\\"{x:1257,y:931,t:1527264637887};\\\", \\\"{x:1259,y:936,t:1527264637904};\\\", \\\"{x:1263,y:944,t:1527264637921};\\\", \\\"{x:1268,y:954,t:1527264637937};\\\", \\\"{x:1271,y:963,t:1527264637954};\\\", \\\"{x:1274,y:973,t:1527264637972};\\\", \\\"{x:1277,y:980,t:1527264637988};\\\", \\\"{x:1278,y:986,t:1527264638005};\\\", \\\"{x:1279,y:992,t:1527264638022};\\\", \\\"{x:1281,y:997,t:1527264638037};\\\", \\\"{x:1281,y:999,t:1527264638055};\\\", \\\"{x:1281,y:1001,t:1527264638072};\\\", \\\"{x:1281,y:1002,t:1527264638088};\\\", \\\"{x:1281,y:1001,t:1527264638192};\\\", \\\"{x:1281,y:1000,t:1527264638205};\\\", \\\"{x:1281,y:999,t:1527264638222};\\\", \\\"{x:1281,y:996,t:1527264638238};\\\", \\\"{x:1281,y:989,t:1527264638254};\\\", \\\"{x:1279,y:982,t:1527264638271};\\\", \\\"{x:1277,y:976,t:1527264638287};\\\", \\\"{x:1273,y:963,t:1527264638303};\\\", \\\"{x:1273,y:959,t:1527264638321};\\\", \\\"{x:1273,y:957,t:1527264638336};\\\", \\\"{x:1273,y:954,t:1527264638354};\\\", \\\"{x:1273,y:951,t:1527264638371};\\\", \\\"{x:1272,y:947,t:1527264638388};\\\", \\\"{x:1272,y:944,t:1527264638404};\\\", \\\"{x:1270,y:942,t:1527264638421};\\\", \\\"{x:1270,y:940,t:1527264638436};\\\", \\\"{x:1269,y:938,t:1527264638453};\\\", \\\"{x:1268,y:936,t:1527264638470};\\\", \\\"{x:1266,y:931,t:1527264638487};\\\", \\\"{x:1263,y:923,t:1527264638504};\\\", \\\"{x:1261,y:921,t:1527264638521};\\\", \\\"{x:1261,y:920,t:1527264638538};\\\", \\\"{x:1260,y:917,t:1527264638554};\\\", \\\"{x:1258,y:915,t:1527264638571};\\\", \\\"{x:1257,y:911,t:1527264638588};\\\", \\\"{x:1254,y:908,t:1527264638604};\\\", \\\"{x:1254,y:907,t:1527264638621};\\\", \\\"{x:1253,y:907,t:1527264638657};\\\", \\\"{x:1252,y:906,t:1527264638671};\\\", \\\"{x:1248,y:900,t:1527264638688};\\\", \\\"{x:1246,y:896,t:1527264638704};\\\", \\\"{x:1244,y:893,t:1527264638722};\\\", \\\"{x:1243,y:890,t:1527264638738};\\\", \\\"{x:1243,y:888,t:1527264638754};\\\", \\\"{x:1242,y:885,t:1527264638771};\\\", \\\"{x:1240,y:882,t:1527264638788};\\\", \\\"{x:1238,y:877,t:1527264638804};\\\", \\\"{x:1238,y:874,t:1527264638821};\\\", \\\"{x:1237,y:871,t:1527264638838};\\\", \\\"{x:1236,y:870,t:1527264638854};\\\", \\\"{x:1236,y:869,t:1527264638871};\\\", \\\"{x:1236,y:868,t:1527264638888};\\\", \\\"{x:1235,y:864,t:1527264638904};\\\", \\\"{x:1235,y:863,t:1527264638928};\\\", \\\"{x:1235,y:862,t:1527264638945};\\\", \\\"{x:1235,y:861,t:1527264638977};\\\", \\\"{x:1235,y:859,t:1527264638989};\\\", \\\"{x:1235,y:858,t:1527264639004};\\\", \\\"{x:1235,y:855,t:1527264639025};\\\", \\\"{x:1233,y:853,t:1527264639040};\\\", \\\"{x:1233,y:851,t:1527264639063};\\\", \\\"{x:1232,y:851,t:1527264639072};\\\", \\\"{x:1232,y:850,t:1527264639087};\\\", \\\"{x:1230,y:847,t:1527264639104};\\\", \\\"{x:1228,y:844,t:1527264639120};\\\", \\\"{x:1226,y:841,t:1527264639138};\\\", \\\"{x:1224,y:839,t:1527264639154};\\\", \\\"{x:1222,y:838,t:1527264639171};\\\", \\\"{x:1222,y:837,t:1527264639225};\\\", \\\"{x:1222,y:836,t:1527264639249};\\\", \\\"{x:1222,y:834,t:1527264639345};\\\", \\\"{x:1221,y:834,t:1527264639424};\\\", \\\"{x:1221,y:833,t:1527264639448};\\\", \\\"{x:1219,y:832,t:1527264639459};\\\", \\\"{x:1219,y:831,t:1527264639471};\\\", \\\"{x:1218,y:831,t:1527264639488};\\\", \\\"{x:1216,y:829,t:1527264639568};\\\", \\\"{x:1216,y:831,t:1527264640001};\\\", \\\"{x:1216,y:832,t:1527264640016};\\\", \\\"{x:1216,y:833,t:1527264640057};\\\", \\\"{x:1217,y:834,t:1527264640072};\\\", \\\"{x:1217,y:836,t:1527264640089};\\\", \\\"{x:1219,y:838,t:1527264640106};\\\", \\\"{x:1219,y:840,t:1527264640122};\\\", \\\"{x:1221,y:842,t:1527264640138};\\\", \\\"{x:1224,y:847,t:1527264640155};\\\", \\\"{x:1226,y:852,t:1527264640173};\\\", \\\"{x:1227,y:853,t:1527264640188};\\\", \\\"{x:1227,y:854,t:1527264640206};\\\", \\\"{x:1230,y:857,t:1527264640223};\\\", \\\"{x:1231,y:859,t:1527264640239};\\\", \\\"{x:1233,y:863,t:1527264640256};\\\", \\\"{x:1234,y:864,t:1527264640273};\\\", \\\"{x:1235,y:868,t:1527264640289};\\\", \\\"{x:1235,y:869,t:1527264640305};\\\", \\\"{x:1237,y:872,t:1527264640329};\\\", \\\"{x:1241,y:875,t:1527264640339};\\\", \\\"{x:1246,y:879,t:1527264640356};\\\", \\\"{x:1249,y:882,t:1527264640373};\\\", \\\"{x:1254,y:887,t:1527264640388};\\\", \\\"{x:1258,y:892,t:1527264640405};\\\", \\\"{x:1261,y:896,t:1527264640423};\\\", \\\"{x:1262,y:898,t:1527264640439};\\\", \\\"{x:1264,y:901,t:1527264640455};\\\", \\\"{x:1266,y:907,t:1527264640472};\\\", \\\"{x:1267,y:907,t:1527264640488};\\\", \\\"{x:1268,y:909,t:1527264640506};\\\", \\\"{x:1272,y:916,t:1527264640523};\\\", \\\"{x:1274,y:921,t:1527264640539};\\\", \\\"{x:1276,y:924,t:1527264640556};\\\", \\\"{x:1277,y:924,t:1527264640573};\\\", \\\"{x:1277,y:925,t:1527264640592};\\\", \\\"{x:1278,y:926,t:1527264640608};\\\", \\\"{x:1278,y:927,t:1527264640632};\\\", \\\"{x:1278,y:928,t:1527264640640};\\\", \\\"{x:1279,y:928,t:1527264640655};\\\", \\\"{x:1280,y:932,t:1527264640672};\\\", \\\"{x:1280,y:933,t:1527264640705};\\\", \\\"{x:1281,y:934,t:1527264640722};\\\", \\\"{x:1283,y:934,t:1527264640738};\\\", \\\"{x:1284,y:936,t:1527264640756};\\\", \\\"{x:1285,y:937,t:1527264640773};\\\", \\\"{x:1285,y:938,t:1527264640800};\\\", \\\"{x:1285,y:939,t:1527264640808};\\\", \\\"{x:1285,y:941,t:1527264640833};\\\", \\\"{x:1286,y:943,t:1527264640841};\\\", \\\"{x:1286,y:945,t:1527264640920};\\\", \\\"{x:1286,y:946,t:1527264640936};\\\", \\\"{x:1286,y:947,t:1527264640944};\\\", \\\"{x:1286,y:948,t:1527264640984};\\\", \\\"{x:1286,y:950,t:1527264641025};\\\", \\\"{x:1286,y:952,t:1527264641040};\\\", \\\"{x:1286,y:953,t:1527264641121};\\\", \\\"{x:1286,y:954,t:1527264641337};\\\", \\\"{x:1286,y:955,t:1527264641344};\\\", \\\"{x:1286,y:956,t:1527264641361};\\\", \\\"{x:1286,y:957,t:1527264641372};\\\", \\\"{x:1285,y:959,t:1527264641392};\\\", \\\"{x:1284,y:962,t:1527264641416};\\\", \\\"{x:1283,y:963,t:1527264641905};\\\", \\\"{x:1283,y:965,t:1527264641953};\\\", \\\"{x:1283,y:966,t:1527264641968};\\\", \\\"{x:1282,y:966,t:1527264641977};\\\", \\\"{x:1282,y:968,t:1527264642017};\\\", \\\"{x:1282,y:969,t:1527264642033};\\\", \\\"{x:1283,y:968,t:1527264642345};\\\", \\\"{x:1283,y:967,t:1527264642360};\\\", \\\"{x:1284,y:967,t:1527264642376};\\\", \\\"{x:1285,y:966,t:1527264642593};\\\", \\\"{x:1286,y:965,t:1527264642656};\\\", \\\"{x:1287,y:964,t:1527264642688};\\\", \\\"{x:1288,y:964,t:1527264642706};\\\", \\\"{x:1288,y:963,t:1527264642723};\\\", \\\"{x:1289,y:962,t:1527264642740};\\\", \\\"{x:1289,y:960,t:1527264642756};\\\", \\\"{x:1290,y:959,t:1527264642774};\\\", \\\"{x:1291,y:958,t:1527264642789};\\\", \\\"{x:1292,y:957,t:1527264642816};\\\", \\\"{x:1292,y:956,t:1527264642848};\\\", \\\"{x:1294,y:954,t:1527264642857};\\\", \\\"{x:1295,y:953,t:1527264642873};\\\", \\\"{x:1296,y:951,t:1527264642890};\\\", \\\"{x:1297,y:950,t:1527264642907};\\\", \\\"{x:1298,y:949,t:1527264642923};\\\", \\\"{x:1298,y:948,t:1527264642993};\\\", \\\"{x:1299,y:947,t:1527264643007};\\\", \\\"{x:1300,y:947,t:1527264643024};\\\", \\\"{x:1301,y:946,t:1527264643040};\\\", \\\"{x:1303,y:944,t:1527264643057};\\\", \\\"{x:1304,y:944,t:1527264643088};\\\", \\\"{x:1304,y:943,t:1527264643106};\\\", \\\"{x:1305,y:942,t:1527264643124};\\\", \\\"{x:1306,y:941,t:1527264643139};\\\", \\\"{x:1308,y:939,t:1527264643156};\\\", \\\"{x:1308,y:938,t:1527264643174};\\\", \\\"{x:1308,y:937,t:1527264643192};\\\", \\\"{x:1309,y:936,t:1527264643206};\\\", \\\"{x:1311,y:935,t:1527264643224};\\\", \\\"{x:1311,y:934,t:1527264643240};\\\", \\\"{x:1311,y:933,t:1527264643256};\\\", \\\"{x:1312,y:931,t:1527264643273};\\\", \\\"{x:1313,y:929,t:1527264643290};\\\", \\\"{x:1314,y:927,t:1527264643306};\\\", \\\"{x:1315,y:924,t:1527264643323};\\\", \\\"{x:1317,y:921,t:1527264643340};\\\", \\\"{x:1318,y:918,t:1527264643357};\\\", \\\"{x:1320,y:915,t:1527264643374};\\\", \\\"{x:1324,y:909,t:1527264643391};\\\", \\\"{x:1324,y:906,t:1527264643407};\\\", \\\"{x:1326,y:898,t:1527264643424};\\\", \\\"{x:1329,y:890,t:1527264643440};\\\", \\\"{x:1333,y:883,t:1527264643456};\\\", \\\"{x:1333,y:881,t:1527264643473};\\\", \\\"{x:1335,y:878,t:1527264643490};\\\", \\\"{x:1337,y:874,t:1527264643506};\\\", \\\"{x:1340,y:869,t:1527264643524};\\\", \\\"{x:1340,y:867,t:1527264643540};\\\", \\\"{x:1343,y:863,t:1527264643557};\\\", \\\"{x:1344,y:859,t:1527264643573};\\\", \\\"{x:1346,y:856,t:1527264643591};\\\", \\\"{x:1348,y:851,t:1527264643607};\\\", \\\"{x:1351,y:847,t:1527264643624};\\\", \\\"{x:1356,y:837,t:1527264643640};\\\", \\\"{x:1363,y:827,t:1527264643657};\\\", \\\"{x:1368,y:822,t:1527264643674};\\\", \\\"{x:1373,y:817,t:1527264643690};\\\", \\\"{x:1377,y:812,t:1527264643707};\\\", \\\"{x:1380,y:809,t:1527264643724};\\\", \\\"{x:1382,y:807,t:1527264643741};\\\", \\\"{x:1384,y:805,t:1527264643756};\\\", \\\"{x:1384,y:802,t:1527264643773};\\\", \\\"{x:1387,y:800,t:1527264643790};\\\", \\\"{x:1390,y:794,t:1527264643806};\\\", \\\"{x:1391,y:793,t:1527264643823};\\\", \\\"{x:1393,y:789,t:1527264643840};\\\", \\\"{x:1394,y:786,t:1527264643857};\\\", \\\"{x:1395,y:784,t:1527264643873};\\\", \\\"{x:1395,y:780,t:1527264643890};\\\", \\\"{x:1398,y:776,t:1527264643907};\\\", \\\"{x:1398,y:775,t:1527264643924};\\\", \\\"{x:1399,y:773,t:1527264643940};\\\", \\\"{x:1399,y:771,t:1527264643956};\\\", \\\"{x:1401,y:767,t:1527264643974};\\\", \\\"{x:1401,y:764,t:1527264643991};\\\", \\\"{x:1402,y:763,t:1527264644007};\\\", \\\"{x:1401,y:763,t:1527264644385};\\\", \\\"{x:1400,y:763,t:1527264644392};\\\", \\\"{x:1399,y:763,t:1527264644432};\\\", \\\"{x:1398,y:763,t:1527264644600};\\\", \\\"{x:1395,y:763,t:1527264644608};\\\", \\\"{x:1392,y:763,t:1527264644624};\\\", \\\"{x:1378,y:763,t:1527264644641};\\\", \\\"{x:1370,y:763,t:1527264644659};\\\", \\\"{x:1358,y:759,t:1527264644674};\\\", \\\"{x:1341,y:755,t:1527264644691};\\\", \\\"{x:1322,y:745,t:1527264644708};\\\", \\\"{x:1320,y:736,t:1527264644724};\\\", \\\"{x:1268,y:713,t:1527264644741};\\\", \\\"{x:1171,y:671,t:1527264644757};\\\", \\\"{x:1139,y:643,t:1527264644774};\\\", \\\"{x:1040,y:599,t:1527264644791};\\\", \\\"{x:938,y:556,t:1527264644809};\\\", \\\"{x:866,y:523,t:1527264644824};\\\", \\\"{x:844,y:509,t:1527264644840};\\\", \\\"{x:821,y:494,t:1527264644862};\\\", \\\"{x:784,y:475,t:1527264644880};\\\", \\\"{x:772,y:465,t:1527264644895};\\\", \\\"{x:763,y:465,t:1527264644912};\\\", \\\"{x:751,y:464,t:1527264644929};\\\", \\\"{x:742,y:460,t:1527264644946};\\\", \\\"{x:736,y:457,t:1527264644962};\\\", \\\"{x:734,y:457,t:1527264644979};\\\", \\\"{x:730,y:458,t:1527264644996};\\\", \\\"{x:729,y:458,t:1527264645011};\\\", \\\"{x:722,y:460,t:1527264645031};\\\", \\\"{x:716,y:465,t:1527264645045};\\\", \\\"{x:713,y:465,t:1527264645063};\\\", \\\"{x:705,y:470,t:1527264645078};\\\", \\\"{x:698,y:473,t:1527264645095};\\\", \\\"{x:697,y:473,t:1527264645377};\\\", \\\"{x:688,y:473,t:1527264645384};\\\", \\\"{x:675,y:474,t:1527264645396};\\\", \\\"{x:656,y:474,t:1527264645413};\\\", \\\"{x:639,y:474,t:1527264645430};\\\", \\\"{x:638,y:474,t:1527264645446};\\\", \\\"{x:636,y:474,t:1527264645463};\\\", \\\"{x:616,y:480,t:1527264645480};\\\", \\\"{x:597,y:481,t:1527264645497};\\\", \\\"{x:585,y:485,t:1527264645513};\\\", \\\"{x:567,y:490,t:1527264645531};\\\", \\\"{x:548,y:497,t:1527264645546};\\\", \\\"{x:543,y:500,t:1527264645563};\\\", \\\"{x:530,y:504,t:1527264645581};\\\", \\\"{x:523,y:506,t:1527264645599};\\\", \\\"{x:520,y:508,t:1527264645645};\\\", \\\"{x:519,y:510,t:1527264645662};\\\", \\\"{x:519,y:514,t:1527264645677};\\\", \\\"{x:517,y:516,t:1527264645695};\\\", \\\"{x:515,y:519,t:1527264645711};\\\", \\\"{x:514,y:525,t:1527264645727};\\\", \\\"{x:509,y:529,t:1527264645745};\\\", \\\"{x:502,y:536,t:1527264645761};\\\", \\\"{x:498,y:539,t:1527264645779};\\\", \\\"{x:491,y:543,t:1527264645794};\\\", \\\"{x:480,y:547,t:1527264645815};\\\", \\\"{x:477,y:548,t:1527264645830};\\\", \\\"{x:476,y:548,t:1527264645846};\\\", \\\"{x:466,y:552,t:1527264645863};\\\", \\\"{x:459,y:554,t:1527264645880};\\\", \\\"{x:458,y:554,t:1527264645903};\\\", \\\"{x:456,y:554,t:1527264645920};\\\", \\\"{x:455,y:554,t:1527264645930};\\\", \\\"{x:453,y:554,t:1527264645947};\\\", \\\"{x:452,y:554,t:1527264645963};\\\", \\\"{x:450,y:555,t:1527264645980};\\\", \\\"{x:449,y:556,t:1527264645997};\\\", \\\"{x:447,y:556,t:1527264646015};\\\", \\\"{x:446,y:556,t:1527264646031};\\\", \\\"{x:443,y:557,t:1527264646047};\\\", \\\"{x:436,y:558,t:1527264646063};\\\", \\\"{x:430,y:559,t:1527264646081};\\\", \\\"{x:427,y:559,t:1527264646097};\\\", \\\"{x:418,y:560,t:1527264646113};\\\", \\\"{x:414,y:560,t:1527264646130};\\\", \\\"{x:408,y:560,t:1527264646147};\\\", \\\"{x:407,y:560,t:1527264646163};\\\", \\\"{x:406,y:561,t:1527264646472};\\\", \\\"{x:406,y:562,t:1527264646480};\\\", \\\"{x:415,y:572,t:1527264646497};\\\", \\\"{x:423,y:581,t:1527264646514};\\\", \\\"{x:426,y:584,t:1527264646532};\\\", \\\"{x:440,y:602,t:1527264646547};\\\", \\\"{x:451,y:618,t:1527264646564};\\\", \\\"{x:462,y:632,t:1527264646581};\\\", \\\"{x:466,y:638,t:1527264646597};\\\", \\\"{x:470,y:646,t:1527264646614};\\\", \\\"{x:479,y:654,t:1527264646630};\\\", \\\"{x:487,y:662,t:1527264646647};\\\", \\\"{x:488,y:667,t:1527264646664};\\\", \\\"{x:489,y:671,t:1527264646681};\\\", \\\"{x:492,y:680,t:1527264646697};\\\", \\\"{x:493,y:687,t:1527264646714};\\\", \\\"{x:495,y:693,t:1527264646730};\\\", \\\"{x:495,y:701,t:1527264646747};\\\", \\\"{x:497,y:705,t:1527264646764};\\\", \\\"{x:499,y:709,t:1527264646780};\\\", \\\"{x:499,y:710,t:1527264646797};\\\", \\\"{x:500,y:714,t:1527264646814};\\\", \\\"{x:502,y:719,t:1527264646830};\\\", \\\"{x:503,y:722,t:1527264646848};\\\", \\\"{x:503,y:725,t:1527264646863};\\\", \\\"{x:503,y:726,t:1527264646880};\\\", \\\"{x:503,y:727,t:1527264647073};\\\", \\\"{x:504,y:727,t:1527264648609};\\\", \\\"{x:505,y:727,t:1527264648624};\\\", \\\"{x:506,y:727,t:1527264648632};\\\", \\\"{x:508,y:727,t:1527264648649};\\\", \\\"{x:509,y:724,t:1527264648666};\\\", \\\"{x:511,y:721,t:1527264648683};\\\", \\\"{x:514,y:718,t:1527264648699};\\\", \\\"{x:518,y:717,t:1527264648716};\\\", \\\"{x:523,y:714,t:1527264648733};\\\", \\\"{x:530,y:714,t:1527264648750};\\\", \\\"{x:534,y:713,t:1527264648766};\\\", \\\"{x:543,y:710,t:1527264648783};\\\", \\\"{x:550,y:706,t:1527264648800};\\\" ] }, { \\\"rt\\\": 20357, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 8, \\\"time_elapsed\\\": 253447, \\\"internal_node_id\\\": \\\"0.0-5.0-3.0\\\", \\\"subject\\\": \\\"RV9F6\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"lima\\\", \\\"condition\\\": \\\"115\\\", \\\"scenario\\\": \\\"acme\\\", \\\"question\\\": \\\"endtime\\\", \\\"q\\\": 4, \\\"clicks\\\": 1, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XFull-YFull\\\", \\\"correct\\\": 1, \\\"orth_correct\\\": 0, \\\"answer\\\": [ \\\"H\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"X \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"U \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-U -U -04 PM-04 PM\\\", \\\"block\\\": \\\"triangular_scaffolded\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:557,y:705,t:1527264650343};\\\", \\\"{x:565,y:703,t:1527264650351};\\\", \\\"{x:576,y:701,t:1527264650368};\\\", \\\"{x:585,y:700,t:1527264650391};\\\", \\\"{x:610,y:697,t:1527264650400};\\\", \\\"{x:691,y:686,t:1527264650417};\\\", \\\"{x:784,y:678,t:1527264650434};\\\", \\\"{x:890,y:676,t:1527264650450};\\\", \\\"{x:946,y:666,t:1527264650468};\\\", \\\"{x:1043,y:666,t:1527264650484};\\\", \\\"{x:1099,y:666,t:1527264650500};\\\", \\\"{x:1181,y:661,t:1527264650517};\\\", \\\"{x:1224,y:656,t:1527264650533};\\\", \\\"{x:1283,y:644,t:1527264650551};\\\", \\\"{x:1410,y:627,t:1527264650568};\\\", \\\"{x:1478,y:621,t:1527264650584};\\\", \\\"{x:1577,y:598,t:1527264650601};\\\", \\\"{x:1630,y:593,t:1527264650618};\\\", \\\"{x:1646,y:586,t:1527264650634};\\\", \\\"{x:1715,y:573,t:1527264650651};\\\", \\\"{x:1758,y:565,t:1527264650667};\\\", \\\"{x:1764,y:565,t:1527264650684};\\\", \\\"{x:1765,y:565,t:1527264650701};\\\", \\\"{x:1765,y:566,t:1527264654464};\\\", \\\"{x:1765,y:568,t:1527264654472};\\\", \\\"{x:1764,y:574,t:1527264654487};\\\", \\\"{x:1760,y:595,t:1527264654505};\\\", \\\"{x:1757,y:610,t:1527264654521};\\\", \\\"{x:1755,y:622,t:1527264654537};\\\", \\\"{x:1752,y:642,t:1527264654555};\\\", \\\"{x:1748,y:667,t:1527264654571};\\\", \\\"{x:1742,y:698,t:1527264654587};\\\", \\\"{x:1738,y:719,t:1527264654604};\\\", \\\"{x:1732,y:739,t:1527264654621};\\\", \\\"{x:1724,y:761,t:1527264654637};\\\", \\\"{x:1718,y:780,t:1527264654654};\\\", \\\"{x:1708,y:801,t:1527264654671};\\\", \\\"{x:1697,y:818,t:1527264654687};\\\", \\\"{x:1681,y:836,t:1527264654704};\\\", \\\"{x:1678,y:841,t:1527264654720};\\\", \\\"{x:1677,y:841,t:1527264654737};\\\", \\\"{x:1675,y:843,t:1527264654754};\\\", \\\"{x:1666,y:846,t:1527264654770};\\\", \\\"{x:1662,y:847,t:1527264654787};\\\", \\\"{x:1653,y:850,t:1527264654804};\\\", \\\"{x:1646,y:851,t:1527264654821};\\\", \\\"{x:1638,y:851,t:1527264654837};\\\", \\\"{x:1634,y:851,t:1527264654854};\\\", \\\"{x:1628,y:849,t:1527264654872};\\\", \\\"{x:1627,y:849,t:1527264654888};\\\", \\\"{x:1622,y:846,t:1527264654905};\\\", \\\"{x:1620,y:846,t:1527264654921};\\\", \\\"{x:1619,y:846,t:1527264654937};\\\", \\\"{x:1614,y:844,t:1527264654955};\\\", \\\"{x:1612,y:842,t:1527264654972};\\\", \\\"{x:1612,y:841,t:1527264654989};\\\", \\\"{x:1610,y:840,t:1527264655005};\\\", \\\"{x:1606,y:838,t:1527264655021};\\\", \\\"{x:1605,y:835,t:1527264655037};\\\", \\\"{x:1601,y:828,t:1527264655054};\\\", \\\"{x:1592,y:816,t:1527264655071};\\\", \\\"{x:1579,y:805,t:1527264655088};\\\", \\\"{x:1571,y:797,t:1527264655104};\\\", \\\"{x:1564,y:787,t:1527264655121};\\\", \\\"{x:1563,y:782,t:1527264655138};\\\", \\\"{x:1561,y:780,t:1527264655154};\\\", \\\"{x:1560,y:779,t:1527264655601};\\\", \\\"{x:1559,y:780,t:1527264655609};\\\", \\\"{x:1558,y:783,t:1527264655626};\\\", \\\"{x:1557,y:787,t:1527264655645};\\\", \\\"{x:1557,y:788,t:1527264655660};\\\", \\\"{x:1557,y:795,t:1527264655676};\\\", \\\"{x:1557,y:799,t:1527264655693};\\\", \\\"{x:1557,y:809,t:1527264655710};\\\", \\\"{x:1556,y:820,t:1527264655725};\\\", \\\"{x:1553,y:827,t:1527264655743};\\\", \\\"{x:1551,y:830,t:1527264655760};\\\", \\\"{x:1547,y:843,t:1527264655776};\\\", \\\"{x:1543,y:853,t:1527264655792};\\\", \\\"{x:1537,y:860,t:1527264655809};\\\", \\\"{x:1533,y:867,t:1527264655825};\\\", \\\"{x:1529,y:871,t:1527264655842};\\\", \\\"{x:1526,y:874,t:1527264655859};\\\", \\\"{x:1521,y:879,t:1527264655876};\\\", \\\"{x:1513,y:885,t:1527264655892};\\\", \\\"{x:1509,y:887,t:1527264655910};\\\", \\\"{x:1503,y:889,t:1527264655927};\\\", \\\"{x:1499,y:890,t:1527264655943};\\\", \\\"{x:1496,y:892,t:1527264655960};\\\", \\\"{x:1493,y:894,t:1527264655976};\\\", \\\"{x:1492,y:895,t:1527264655996};\\\", \\\"{x:1490,y:895,t:1527264656010};\\\", \\\"{x:1489,y:895,t:1527264656026};\\\", \\\"{x:1488,y:895,t:1527264656044};\\\", \\\"{x:1486,y:896,t:1527264656149};\\\", \\\"{x:1485,y:896,t:1527264656159};\\\", \\\"{x:1481,y:897,t:1527264656176};\\\", \\\"{x:1480,y:898,t:1527264656192};\\\", \\\"{x:1475,y:899,t:1527264656209};\\\", \\\"{x:1467,y:899,t:1527264656226};\\\", \\\"{x:1466,y:899,t:1527264656242};\\\", \\\"{x:1465,y:899,t:1527264657621};\\\", \\\"{x:1463,y:899,t:1527264657637};\\\", \\\"{x:1462,y:899,t:1527264657652};\\\", \\\"{x:1461,y:898,t:1527264657660};\\\", \\\"{x:1460,y:898,t:1527264657678};\\\", \\\"{x:1459,y:894,t:1527264659324};\\\", \\\"{x:1459,y:891,t:1527264659332};\\\", \\\"{x:1459,y:887,t:1527264659345};\\\", \\\"{x:1459,y:881,t:1527264659362};\\\", \\\"{x:1461,y:873,t:1527264659378};\\\", \\\"{x:1463,y:867,t:1527264659395};\\\", \\\"{x:1464,y:864,t:1527264659412};\\\", \\\"{x:1468,y:857,t:1527264659428};\\\", \\\"{x:1468,y:850,t:1527264659445};\\\", \\\"{x:1469,y:847,t:1527264659461};\\\", \\\"{x:1470,y:842,t:1527264659478};\\\", \\\"{x:1474,y:835,t:1527264659496};\\\", \\\"{x:1478,y:828,t:1527264659513};\\\", \\\"{x:1481,y:825,t:1527264659528};\\\", \\\"{x:1481,y:824,t:1527264659546};\\\", \\\"{x:1483,y:824,t:1527264659562};\\\", \\\"{x:1484,y:824,t:1527264659605};\\\", \\\"{x:1487,y:823,t:1527264659613};\\\", \\\"{x:1505,y:823,t:1527264659629};\\\", \\\"{x:1513,y:823,t:1527264659646};\\\", \\\"{x:1525,y:825,t:1527264659662};\\\", \\\"{x:1536,y:833,t:1527264659678};\\\", \\\"{x:1546,y:844,t:1527264659695};\\\", \\\"{x:1551,y:857,t:1527264659712};\\\", \\\"{x:1566,y:871,t:1527264659728};\\\", \\\"{x:1577,y:887,t:1527264659746};\\\", \\\"{x:1585,y:902,t:1527264659763};\\\", \\\"{x:1595,y:914,t:1527264659779};\\\", \\\"{x:1603,y:934,t:1527264659795};\\\", \\\"{x:1609,y:958,t:1527264659812};\\\", \\\"{x:1610,y:964,t:1527264659828};\\\", \\\"{x:1610,y:967,t:1527264659846};\\\", \\\"{x:1609,y:976,t:1527264659863};\\\", \\\"{x:1606,y:995,t:1527264659880};\\\", \\\"{x:1605,y:1005,t:1527264659895};\\\", \\\"{x:1604,y:1017,t:1527264659913};\\\", \\\"{x:1604,y:1022,t:1527264659928};\\\", \\\"{x:1603,y:1024,t:1527264659945};\\\", \\\"{x:1603,y:1023,t:1527264660021};\\\", \\\"{x:1603,y:1018,t:1527264660029};\\\", \\\"{x:1604,y:1006,t:1527264660046};\\\", \\\"{x:1607,y:996,t:1527264660062};\\\", \\\"{x:1607,y:987,t:1527264660079};\\\", \\\"{x:1607,y:979,t:1527264660096};\\\", \\\"{x:1610,y:969,t:1527264660112};\\\", \\\"{x:1610,y:965,t:1527264660129};\\\", \\\"{x:1610,y:964,t:1527264660146};\\\", \\\"{x:1610,y:963,t:1527264660162};\\\", \\\"{x:1612,y:961,t:1527264660324};\\\", \\\"{x:1612,y:958,t:1527264660597};\\\", \\\"{x:1610,y:954,t:1527264660612};\\\", \\\"{x:1606,y:950,t:1527264660630};\\\", \\\"{x:1604,y:947,t:1527264660647};\\\", \\\"{x:1604,y:946,t:1527264660662};\\\", \\\"{x:1604,y:945,t:1527264660684};\\\", \\\"{x:1603,y:945,t:1527264660697};\\\", \\\"{x:1602,y:945,t:1527264660724};\\\", \\\"{x:1601,y:944,t:1527264660732};\\\", \\\"{x:1601,y:943,t:1527264660748};\\\", \\\"{x:1600,y:941,t:1527264660763};\\\", \\\"{x:1599,y:940,t:1527264660780};\\\", \\\"{x:1599,y:938,t:1527264660797};\\\", \\\"{x:1598,y:937,t:1527264660812};\\\", \\\"{x:1597,y:935,t:1527264660830};\\\", \\\"{x:1596,y:934,t:1527264660846};\\\", \\\"{x:1596,y:933,t:1527264660863};\\\", \\\"{x:1596,y:932,t:1527264660892};\\\", \\\"{x:1595,y:932,t:1527264660900};\\\", \\\"{x:1594,y:931,t:1527264660913};\\\", \\\"{x:1592,y:930,t:1527264660930};\\\", \\\"{x:1591,y:928,t:1527264660947};\\\", \\\"{x:1589,y:927,t:1527264661013};\\\", \\\"{x:1586,y:924,t:1527264661030};\\\", \\\"{x:1585,y:923,t:1527264661047};\\\", \\\"{x:1581,y:920,t:1527264661062};\\\", \\\"{x:1580,y:919,t:1527264661115};\\\", \\\"{x:1579,y:918,t:1527264661131};\\\", \\\"{x:1578,y:917,t:1527264661146};\\\", \\\"{x:1577,y:916,t:1527264661172};\\\", \\\"{x:1577,y:915,t:1527264661179};\\\", \\\"{x:1575,y:914,t:1527264661196};\\\", \\\"{x:1573,y:914,t:1527264661213};\\\", \\\"{x:1573,y:912,t:1527264661229};\\\", \\\"{x:1572,y:910,t:1527264661247};\\\", \\\"{x:1567,y:906,t:1527264661263};\\\", \\\"{x:1558,y:899,t:1527264661279};\\\", \\\"{x:1555,y:897,t:1527264661296};\\\", \\\"{x:1551,y:890,t:1527264661313};\\\", \\\"{x:1550,y:884,t:1527264661330};\\\", \\\"{x:1525,y:873,t:1527264661347};\\\", \\\"{x:1448,y:839,t:1527264661363};\\\", \\\"{x:1343,y:796,t:1527264661380};\\\", \\\"{x:1191,y:737,t:1527264661396};\\\", \\\"{x:1073,y:686,t:1527264661413};\\\", \\\"{x:950,y:639,t:1527264661429};\\\", \\\"{x:846,y:603,t:1527264661448};\\\", \\\"{x:735,y:566,t:1527264661464};\\\", \\\"{x:656,y:538,t:1527264661479};\\\", \\\"{x:595,y:514,t:1527264661498};\\\", \\\"{x:576,y:509,t:1527264661513};\\\", \\\"{x:570,y:506,t:1527264661530};\\\", \\\"{x:569,y:506,t:1527264661547};\\\", \\\"{x:568,y:506,t:1527264661563};\\\", \\\"{x:568,y:510,t:1527264661740};\\\", \\\"{x:570,y:513,t:1527264661748};\\\", \\\"{x:570,y:515,t:1527264662037};\\\", \\\"{x:571,y:517,t:1527264662048};\\\", \\\"{x:572,y:517,t:1527264662065};\\\", \\\"{x:573,y:517,t:1527264662204};\\\", \\\"{x:573,y:519,t:1527264662214};\\\", \\\"{x:573,y:520,t:1527264662231};\\\", \\\"{x:573,y:523,t:1527264662268};\\\", \\\"{x:575,y:525,t:1527264662281};\\\", \\\"{x:578,y:532,t:1527264662298};\\\", \\\"{x:581,y:539,t:1527264662315};\\\", \\\"{x:583,y:544,t:1527264662333};\\\", \\\"{x:587,y:550,t:1527264662347};\\\", \\\"{x:587,y:551,t:1527264662364};\\\", \\\"{x:587,y:553,t:1527264662411};\\\", \\\"{x:589,y:555,t:1527264662420};\\\", \\\"{x:590,y:558,t:1527264662431};\\\", \\\"{x:592,y:562,t:1527264662448};\\\", \\\"{x:595,y:565,t:1527264662464};\\\", \\\"{x:596,y:566,t:1527264662499};\\\", \\\"{x:597,y:566,t:1527264662620};\\\", \\\"{x:598,y:566,t:1527264662632};\\\", \\\"{x:599,y:566,t:1527264662669};\\\", \\\"{x:600,y:566,t:1527264662707};\\\", \\\"{x:601,y:566,t:1527264662731};\\\", \\\"{x:601,y:565,t:1527264662756};\\\", \\\"{x:602,y:573,t:1527264667549};\\\", \\\"{x:602,y:599,t:1527264667569};\\\", \\\"{x:600,y:619,t:1527264667584};\\\", \\\"{x:593,y:631,t:1527264667602};\\\", \\\"{x:588,y:645,t:1527264667618};\\\", \\\"{x:578,y:667,t:1527264667636};\\\", \\\"{x:567,y:686,t:1527264667651};\\\", \\\"{x:561,y:700,t:1527264667668};\\\", \\\"{x:553,y:715,t:1527264667686};\\\", \\\"{x:546,y:725,t:1527264667702};\\\", \\\"{x:542,y:733,t:1527264667719};\\\", \\\"{x:537,y:741,t:1527264667736};\\\", \\\"{x:534,y:746,t:1527264667752};\\\", \\\"{x:533,y:751,t:1527264667768};\\\", \\\"{x:532,y:752,t:1527264667786};\\\", \\\"{x:531,y:753,t:1527264667802};\\\", \\\"{x:530,y:754,t:1527264667819};\\\", \\\"{x:530,y:752,t:1527264667988};\\\", \\\"{x:530,y:749,t:1527264668003};\\\", \\\"{x:532,y:744,t:1527264668019};\\\", \\\"{x:533,y:742,t:1527264668036};\\\", \\\"{x:533,y:740,t:1527264668052};\\\", \\\"{x:533,y:738,t:1527264668149};\\\", \\\"{x:534,y:737,t:1527264668189};\\\", \\\"{x:535,y:735,t:1527264668204};\\\", \\\"{x:537,y:731,t:1527264668219};\\\", \\\"{x:540,y:727,t:1527264668235};\\\", \\\"{x:540,y:723,t:1527264668252};\\\", \\\"{x:541,y:721,t:1527264668270};\\\", \\\"{x:542,y:719,t:1527264668285};\\\", \\\"{x:544,y:717,t:1527264668302};\\\", \\\"{x:544,y:715,t:1527264668319};\\\", \\\"{x:544,y:714,t:1527264668335};\\\", \\\"{x:545,y:713,t:1527264670572};\\\", \\\"{x:557,y:700,t:1527264670587};\\\", \\\"{x:562,y:691,t:1527264670604};\\\", \\\"{x:562,y:690,t:1527264670621};\\\", \\\"{x:567,y:685,t:1527264670643};\\\" ] }, { \\\"rt\\\": 25802, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 9, \\\"time_elapsed\\\": 280531, \\\"internal_node_id\\\": \\\"0.0-5.0-4.0\\\", \\\"subject\\\": \\\"RV9F6\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"lima\\\", \\\"condition\\\": \\\"115\\\", \\\"scenario\\\": \\\"acme\\\", \\\"question\\\": \\\"midpoint\\\", \\\"q\\\": 5, \\\"clicks\\\": 1.5, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XFull-YFull\\\", \\\"correct\\\": 1, \\\"orth_correct\\\": 0, \\\"answer\\\": [ \\\"O\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"X \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"U \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-O -O -11 AM\\\", \\\"block\\\": \\\"triangular_scaffolded\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:567,y:683,t:1527264672381};\\\", \\\"{x:567,y:682,t:1527264672390};\\\", \\\"{x:567,y:680,t:1527264672405};\\\", \\\"{x:574,y:680,t:1527264685269};\\\", \\\"{x:609,y:680,t:1527264685283};\\\", \\\"{x:708,y:676,t:1527264685300};\\\", \\\"{x:779,y:671,t:1527264685316};\\\", \\\"{x:824,y:671,t:1527264685332};\\\", \\\"{x:835,y:665,t:1527264685349};\\\", \\\"{x:879,y:665,t:1527264685365};\\\", \\\"{x:917,y:664,t:1527264685381};\\\", \\\"{x:926,y:664,t:1527264685399};\\\", \\\"{x:927,y:664,t:1527264685414};\\\", \\\"{x:927,y:662,t:1527264685684};\\\", \\\"{x:939,y:655,t:1527264685700};\\\", \\\"{x:961,y:645,t:1527264685716};\\\", \\\"{x:1021,y:628,t:1527264685733};\\\", \\\"{x:1051,y:614,t:1527264685749};\\\", \\\"{x:1053,y:614,t:1527264685766};\\\", \\\"{x:1066,y:607,t:1527264685782};\\\", \\\"{x:1079,y:601,t:1527264685799};\\\", \\\"{x:1095,y:595,t:1527264685816};\\\", \\\"{x:1108,y:589,t:1527264685832};\\\", \\\"{x:1109,y:588,t:1527264685875};\\\", \\\"{x:1111,y:586,t:1527264685883};\\\", \\\"{x:1113,y:582,t:1527264685899};\\\", \\\"{x:1116,y:575,t:1527264685916};\\\", \\\"{x:1119,y:571,t:1527264685932};\\\", \\\"{x:1122,y:565,t:1527264685949};\\\", \\\"{x:1122,y:564,t:1527264685966};\\\", \\\"{x:1123,y:562,t:1527264685982};\\\", \\\"{x:1125,y:559,t:1527264685999};\\\", \\\"{x:1126,y:557,t:1527264686016};\\\", \\\"{x:1129,y:554,t:1527264686032};\\\", \\\"{x:1146,y:543,t:1527264686050};\\\", \\\"{x:1167,y:535,t:1527264686067};\\\", \\\"{x:1168,y:535,t:1527264686083};\\\", \\\"{x:1169,y:535,t:1527264686132};\\\", \\\"{x:1176,y:534,t:1527264686149};\\\", \\\"{x:1191,y:527,t:1527264686166};\\\", \\\"{x:1196,y:525,t:1527264686183};\\\", \\\"{x:1198,y:524,t:1527264686199};\\\", \\\"{x:1201,y:521,t:1527264686216};\\\", \\\"{x:1203,y:520,t:1527264686300};\\\", \\\"{x:1208,y:517,t:1527264686316};\\\", \\\"{x:1217,y:513,t:1527264686334};\\\", \\\"{x:1226,y:511,t:1527264686349};\\\", \\\"{x:1227,y:510,t:1527264686367};\\\", \\\"{x:1228,y:509,t:1527264686384};\\\", \\\"{x:1230,y:509,t:1527264686404};\\\", \\\"{x:1232,y:508,t:1527264686421};\\\", \\\"{x:1238,y:505,t:1527264686436};\\\", \\\"{x:1242,y:504,t:1527264686452};\\\", \\\"{x:1246,y:502,t:1527264686467};\\\", \\\"{x:1249,y:502,t:1527264686484};\\\", \\\"{x:1250,y:501,t:1527264686500};\\\", \\\"{x:1252,y:500,t:1527264686517};\\\", \\\"{x:1253,y:500,t:1527264686534};\\\", \\\"{x:1257,y:499,t:1527264686550};\\\", \\\"{x:1260,y:499,t:1527264686567};\\\", \\\"{x:1265,y:499,t:1527264686584};\\\", \\\"{x:1274,y:499,t:1527264686600};\\\", \\\"{x:1286,y:499,t:1527264686617};\\\", \\\"{x:1293,y:499,t:1527264686633};\\\", \\\"{x:1296,y:499,t:1527264686649};\\\", \\\"{x:1298,y:500,t:1527264686666};\\\", \\\"{x:1301,y:501,t:1527264686684};\\\", \\\"{x:1303,y:502,t:1527264686700};\\\", \\\"{x:1304,y:502,t:1527264688660};\\\", \\\"{x:1305,y:502,t:1527264688668};\\\", \\\"{x:1306,y:502,t:1527264688684};\\\", \\\"{x:1307,y:502,t:1527264688893};\\\", \\\"{x:1308,y:501,t:1527264689244};\\\", \\\"{x:1310,y:501,t:1527264689268};\\\", \\\"{x:1311,y:503,t:1527264691773};\\\", \\\"{x:1311,y:506,t:1527264691787};\\\", \\\"{x:1312,y:519,t:1527264691804};\\\", \\\"{x:1312,y:524,t:1527264691821};\\\", \\\"{x:1312,y:531,t:1527264691837};\\\", \\\"{x:1312,y:538,t:1527264691853};\\\", \\\"{x:1312,y:551,t:1527264691871};\\\", \\\"{x:1312,y:560,t:1527264691888};\\\", \\\"{x:1314,y:568,t:1527264691904};\\\", \\\"{x:1315,y:577,t:1527264691921};\\\", \\\"{x:1315,y:583,t:1527264691938};\\\", \\\"{x:1316,y:584,t:1527264691954};\\\", \\\"{x:1316,y:588,t:1527264691971};\\\", \\\"{x:1314,y:594,t:1527264691988};\\\", \\\"{x:1313,y:599,t:1527264692004};\\\", \\\"{x:1311,y:604,t:1527264692020};\\\", \\\"{x:1310,y:606,t:1527264692038};\\\", \\\"{x:1310,y:608,t:1527264692054};\\\", \\\"{x:1310,y:610,t:1527264692071};\\\", \\\"{x:1310,y:611,t:1527264692088};\\\", \\\"{x:1310,y:615,t:1527264692104};\\\", \\\"{x:1310,y:619,t:1527264692121};\\\", \\\"{x:1310,y:622,t:1527264692138};\\\", \\\"{x:1310,y:625,t:1527264692155};\\\", \\\"{x:1309,y:628,t:1527264692174};\\\", \\\"{x:1308,y:631,t:1527264692187};\\\", \\\"{x:1308,y:632,t:1527264692203};\\\", \\\"{x:1307,y:635,t:1527264692220};\\\", \\\"{x:1307,y:640,t:1527264692237};\\\", \\\"{x:1307,y:643,t:1527264692253};\\\", \\\"{x:1307,y:648,t:1527264692270};\\\", \\\"{x:1307,y:652,t:1527264692287};\\\", \\\"{x:1307,y:653,t:1527264692304};\\\", \\\"{x:1307,y:659,t:1527264692320};\\\", \\\"{x:1307,y:663,t:1527264692337};\\\", \\\"{x:1307,y:668,t:1527264692354};\\\", \\\"{x:1307,y:674,t:1527264692370};\\\", \\\"{x:1308,y:684,t:1527264692387};\\\", \\\"{x:1308,y:691,t:1527264692404};\\\", \\\"{x:1308,y:703,t:1527264692421};\\\", \\\"{x:1308,y:714,t:1527264692437};\\\", \\\"{x:1309,y:731,t:1527264692455};\\\", \\\"{x:1311,y:734,t:1527264692470};\\\", \\\"{x:1312,y:749,t:1527264692488};\\\", \\\"{x:1311,y:764,t:1527264692505};\\\", \\\"{x:1311,y:776,t:1527264692520};\\\", \\\"{x:1311,y:791,t:1527264692537};\\\", \\\"{x:1311,y:804,t:1527264692555};\\\", \\\"{x:1311,y:818,t:1527264692571};\\\", \\\"{x:1311,y:836,t:1527264692587};\\\", \\\"{x:1311,y:838,t:1527264692605};\\\", \\\"{x:1311,y:851,t:1527264692621};\\\", \\\"{x:1311,y:866,t:1527264692637};\\\", \\\"{x:1311,y:879,t:1527264692655};\\\", \\\"{x:1313,y:889,t:1527264692671};\\\", \\\"{x:1313,y:900,t:1527264692688};\\\", \\\"{x:1312,y:908,t:1527264692705};\\\", \\\"{x:1311,y:915,t:1527264692721};\\\", \\\"{x:1309,y:919,t:1527264692737};\\\", \\\"{x:1308,y:923,t:1527264692755};\\\", \\\"{x:1306,y:933,t:1527264692771};\\\", \\\"{x:1306,y:950,t:1527264692788};\\\", \\\"{x:1306,y:954,t:1527264692805};\\\", \\\"{x:1306,y:957,t:1527264692821};\\\", \\\"{x:1306,y:961,t:1527264692838};\\\", \\\"{x:1306,y:964,t:1527264692855};\\\", \\\"{x:1304,y:966,t:1527264692872};\\\", \\\"{x:1304,y:968,t:1527264692888};\\\", \\\"{x:1304,y:970,t:1527264692905};\\\", \\\"{x:1303,y:971,t:1527264693116};\\\", \\\"{x:1302,y:971,t:1527264693124};\\\", \\\"{x:1299,y:970,t:1527264693140};\\\", \\\"{x:1297,y:965,t:1527264693156};\\\", \\\"{x:1284,y:955,t:1527264693172};\\\", \\\"{x:1278,y:952,t:1527264693188};\\\", \\\"{x:1218,y:921,t:1527264693205};\\\", \\\"{x:1134,y:877,t:1527264693222};\\\", \\\"{x:1027,y:816,t:1527264693237};\\\", \\\"{x:916,y:761,t:1527264693255};\\\", \\\"{x:835,y:721,t:1527264693271};\\\", \\\"{x:737,y:667,t:1527264693288};\\\", \\\"{x:630,y:600,t:1527264693306};\\\", \\\"{x:528,y:536,t:1527264693322};\\\", \\\"{x:483,y:494,t:1527264693339};\\\", \\\"{x:446,y:461,t:1527264693356};\\\", \\\"{x:417,y:435,t:1527264693372};\\\", \\\"{x:411,y:424,t:1527264693389};\\\", \\\"{x:410,y:418,t:1527264693405};\\\", \\\"{x:407,y:412,t:1527264693422};\\\", \\\"{x:402,y:404,t:1527264693439};\\\", \\\"{x:401,y:402,t:1527264693456};\\\", \\\"{x:401,y:401,t:1527264693472};\\\", \\\"{x:402,y:400,t:1527264693489};\\\", \\\"{x:402,y:399,t:1527264693596};\\\", \\\"{x:421,y:409,t:1527264693628};\\\", \\\"{x:472,y:434,t:1527264693640};\\\", \\\"{x:593,y:482,t:1527264693657};\\\", \\\"{x:614,y:503,t:1527264693673};\\\", \\\"{x:713,y:550,t:1527264693691};\\\", \\\"{x:799,y:587,t:1527264693708};\\\", \\\"{x:855,y:606,t:1527264693724};\\\", \\\"{x:867,y:609,t:1527264693739};\\\", \\\"{x:870,y:609,t:1527264693757};\\\", \\\"{x:871,y:609,t:1527264693773};\\\", \\\"{x:872,y:609,t:1527264693795};\\\", \\\"{x:868,y:605,t:1527264693836};\\\", \\\"{x:855,y:596,t:1527264693856};\\\", \\\"{x:833,y:581,t:1527264693873};\\\", \\\"{x:809,y:562,t:1527264693889};\\\", \\\"{x:787,y:547,t:1527264693907};\\\", \\\"{x:764,y:533,t:1527264693923};\\\", \\\"{x:761,y:532,t:1527264693939};\\\", \\\"{x:761,y:530,t:1527264693956};\\\", \\\"{x:761,y:528,t:1527264693979};\\\", \\\"{x:761,y:527,t:1527264693989};\\\", \\\"{x:761,y:526,t:1527264694006};\\\", \\\"{x:762,y:525,t:1527264694023};\\\", \\\"{x:762,y:524,t:1527264694067};\\\", \\\"{x:763,y:524,t:1527264694075};\\\", \\\"{x:765,y:524,t:1527264694089};\\\", \\\"{x:768,y:524,t:1527264694107};\\\", \\\"{x:776,y:525,t:1527264694123};\\\", \\\"{x:781,y:529,t:1527264694140};\\\", \\\"{x:783,y:531,t:1527264694157};\\\", \\\"{x:788,y:536,t:1527264694173};\\\", \\\"{x:796,y:543,t:1527264694190};\\\", \\\"{x:804,y:551,t:1527264694208};\\\", \\\"{x:813,y:559,t:1527264694224};\\\", \\\"{x:818,y:565,t:1527264694240};\\\", \\\"{x:822,y:567,t:1527264694256};\\\", \\\"{x:823,y:569,t:1527264694273};\\\", \\\"{x:824,y:569,t:1527264694290};\\\", \\\"{x:825,y:570,t:1527264694307};\\\", \\\"{x:826,y:570,t:1527264694323};\\\", \\\"{x:827,y:570,t:1527264694341};\\\", \\\"{x:830,y:566,t:1527264694357};\\\", \\\"{x:833,y:561,t:1527264694374};\\\", \\\"{x:834,y:557,t:1527264694390};\\\", \\\"{x:834,y:556,t:1527264694419};\\\", \\\"{x:834,y:555,t:1527264694427};\\\", \\\"{x:835,y:554,t:1527264694441};\\\", \\\"{x:836,y:553,t:1527264694456};\\\", \\\"{x:836,y:552,t:1527264694473};\\\", \\\"{x:837,y:551,t:1527264694490};\\\", \\\"{x:837,y:550,t:1527264694507};\\\", \\\"{x:837,y:549,t:1527264694539};\\\", \\\"{x:835,y:553,t:1527264694925};\\\", \\\"{x:822,y:573,t:1527264694941};\\\", \\\"{x:796,y:599,t:1527264694958};\\\", \\\"{x:778,y:618,t:1527264694973};\\\", \\\"{x:762,y:630,t:1527264694990};\\\", \\\"{x:757,y:634,t:1527264695008};\\\", \\\"{x:746,y:640,t:1527264695023};\\\", \\\"{x:744,y:642,t:1527264695040};\\\", \\\"{x:743,y:642,t:1527264695057};\\\", \\\"{x:745,y:640,t:1527264695132};\\\", \\\"{x:745,y:638,t:1527264695142};\\\", \\\"{x:751,y:630,t:1527264695158};\\\", \\\"{x:762,y:618,t:1527264695175};\\\", \\\"{x:779,y:600,t:1527264695190};\\\", \\\"{x:793,y:583,t:1527264695208};\\\", \\\"{x:814,y:565,t:1527264695223};\\\", \\\"{x:832,y:554,t:1527264695241};\\\", \\\"{x:842,y:545,t:1527264695258};\\\", \\\"{x:850,y:540,t:1527264695274};\\\", \\\"{x:852,y:539,t:1527264695290};\\\", \\\"{x:854,y:536,t:1527264695307};\\\", \\\"{x:855,y:534,t:1527264695324};\\\", \\\"{x:857,y:534,t:1527264695379};\\\", \\\"{x:858,y:532,t:1527264695391};\\\", \\\"{x:859,y:532,t:1527264695500};\\\", \\\"{x:859,y:533,t:1527264695523};\\\", \\\"{x:852,y:539,t:1527264696116};\\\", \\\"{x:842,y:548,t:1527264696125};\\\", \\\"{x:807,y:582,t:1527264696142};\\\", \\\"{x:768,y:616,t:1527264696159};\\\", \\\"{x:734,y:642,t:1527264696175};\\\", \\\"{x:725,y:651,t:1527264696192};\\\", \\\"{x:698,y:665,t:1527264696209};\\\", \\\"{x:666,y:678,t:1527264696225};\\\", \\\"{x:654,y:687,t:1527264696242};\\\", \\\"{x:641,y:693,t:1527264696259};\\\", \\\"{x:624,y:704,t:1527264696275};\\\", \\\"{x:618,y:708,t:1527264696291};\\\", \\\"{x:600,y:712,t:1527264696309};\\\", \\\"{x:590,y:713,t:1527264696325};\\\", \\\"{x:576,y:714,t:1527264696342};\\\", \\\"{x:567,y:714,t:1527264696359};\\\", \\\"{x:560,y:714,t:1527264696376};\\\", \\\"{x:558,y:714,t:1527264696392};\\\", \\\"{x:557,y:714,t:1527264696508};\\\", \\\"{x:556,y:715,t:1527264696518};\\\", \\\"{x:555,y:720,t:1527264696526};\\\", \\\"{x:552,y:723,t:1527264696541};\\\", \\\"{x:549,y:732,t:1527264696559};\\\", \\\"{x:547,y:737,t:1527264696575};\\\", \\\"{x:543,y:742,t:1527264696591};\\\", \\\"{x:539,y:745,t:1527264696609};\\\" ] }, { \\\"rt\\\": 22138, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 10, \\\"time_elapsed\\\": 303970, \\\"internal_node_id\\\": \\\"0.0-6.0-0.0\\\", \\\"subject\\\": \\\"RV9F6\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"lima\\\", \\\"condition\\\": \\\"115\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"duration\\\", \\\"q\\\": 6, \\\"clicks\\\": 2.5, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XFull-YFull\\\", \\\"correct\\\": 1, \\\"orth_correct\\\": 1, \\\"answer\\\": [ \\\"E\\\", \\\"G\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-G \\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:540,y:745,t:1527264702188};\\\", \\\"{x:540,y:744,t:1527264702242};\\\", \\\"{x:541,y:743,t:1527264702251};\\\", \\\"{x:541,y:742,t:1527264702283};\\\", \\\"{x:542,y:741,t:1527264702315};\\\", \\\"{x:543,y:740,t:1527264702756};\\\", \\\"{x:545,y:738,t:1527264702908};\\\", \\\"{x:546,y:737,t:1527264703276};\\\", \\\"{x:547,y:736,t:1527264703388};\\\", \\\"{x:548,y:735,t:1527264703420};\\\", \\\"{x:549,y:734,t:1527264703508};\\\", \\\"{x:549,y:733,t:1527264703524};\\\", \\\"{x:550,y:733,t:1527264703796};\\\", \\\"{x:551,y:732,t:1527264703836};\\\", \\\"{x:552,y:731,t:1527264703851};\\\", \\\"{x:553,y:730,t:1527264703876};\\\", \\\"{x:556,y:727,t:1527264710228};\\\", \\\"{x:559,y:725,t:1527264710235};\\\", \\\"{x:562,y:722,t:1527264710251};\\\", \\\"{x:564,y:720,t:1527264710269};\\\", \\\"{x:571,y:714,t:1527264710284};\\\", \\\"{x:588,y:709,t:1527264710301};\\\", \\\"{x:602,y:708,t:1527264710317};\\\", \\\"{x:612,y:713,t:1527264710336};\\\", \\\"{x:627,y:715,t:1527264710352};\\\", \\\"{x:639,y:714,t:1527264710369};\\\", \\\"{x:666,y:716,t:1527264710386};\\\", \\\"{x:742,y:723,t:1527264710402};\\\", \\\"{x:818,y:727,t:1527264710419};\\\", \\\"{x:946,y:726,t:1527264710436};\\\", \\\"{x:1098,y:723,t:1527264710452};\\\", \\\"{x:1191,y:716,t:1527264710470};\\\", \\\"{x:1331,y:711,t:1527264710487};\\\", \\\"{x:1479,y:704,t:1527264710503};\\\", \\\"{x:1618,y:710,t:1527264710519};\\\", \\\"{x:1729,y:710,t:1527264710537};\\\", \\\"{x:1772,y:710,t:1527264710553};\\\", \\\"{x:1796,y:713,t:1527264710570};\\\", \\\"{x:1796,y:714,t:1527264710587};\\\", \\\"{x:1795,y:713,t:1527264710668};\\\", \\\"{x:1788,y:711,t:1527264710675};\\\", \\\"{x:1783,y:707,t:1527264710687};\\\", \\\"{x:1778,y:705,t:1527264710703};\\\", \\\"{x:1775,y:703,t:1527264710720};\\\", \\\"{x:1773,y:702,t:1527264710772};\\\", \\\"{x:1759,y:690,t:1527264710787};\\\", \\\"{x:1758,y:685,t:1527264710804};\\\", \\\"{x:1756,y:685,t:1527264711436};\\\", \\\"{x:1753,y:685,t:1527264711444};\\\", \\\"{x:1752,y:685,t:1527264711468};\\\", \\\"{x:1744,y:685,t:1527264711476};\\\", \\\"{x:1733,y:685,t:1527264711489};\\\", \\\"{x:1714,y:685,t:1527264711504};\\\", \\\"{x:1702,y:686,t:1527264711521};\\\", \\\"{x:1687,y:686,t:1527264711538};\\\", \\\"{x:1659,y:685,t:1527264711555};\\\", \\\"{x:1609,y:675,t:1527264711571};\\\", \\\"{x:1546,y:659,t:1527264711588};\\\", \\\"{x:1479,y:638,t:1527264711605};\\\", \\\"{x:1394,y:610,t:1527264711621};\\\", \\\"{x:1333,y:586,t:1527264711639};\\\", \\\"{x:1296,y:569,t:1527264711655};\\\", \\\"{x:1246,y:556,t:1527264711672};\\\", \\\"{x:1232,y:543,t:1527264711689};\\\", \\\"{x:1213,y:536,t:1527264711705};\\\", \\\"{x:1202,y:535,t:1527264711722};\\\", \\\"{x:1194,y:533,t:1527264711739};\\\", \\\"{x:1189,y:531,t:1527264711756};\\\", \\\"{x:1188,y:530,t:1527264711771};\\\", \\\"{x:1187,y:529,t:1527264711788};\\\", \\\"{x:1185,y:527,t:1527264711806};\\\", \\\"{x:1184,y:527,t:1527264711822};\\\", \\\"{x:1183,y:527,t:1527264711996};\\\", \\\"{x:1183,y:528,t:1527264712006};\\\", \\\"{x:1196,y:539,t:1527264712022};\\\", \\\"{x:1214,y:553,t:1527264712038};\\\", \\\"{x:1244,y:572,t:1527264712056};\\\", \\\"{x:1261,y:583,t:1527264712073};\\\", \\\"{x:1278,y:594,t:1527264712089};\\\", \\\"{x:1300,y:607,t:1527264712105};\\\", \\\"{x:1317,y:619,t:1527264712123};\\\", \\\"{x:1329,y:633,t:1527264712140};\\\", \\\"{x:1334,y:643,t:1527264712155};\\\", \\\"{x:1343,y:646,t:1527264712173};\\\", \\\"{x:1342,y:645,t:1527264712324};\\\", \\\"{x:1328,y:635,t:1527264712339};\\\", \\\"{x:1326,y:632,t:1527264712356};\\\", \\\"{x:1319,y:627,t:1527264712373};\\\", \\\"{x:1315,y:623,t:1527264712390};\\\", \\\"{x:1311,y:618,t:1527264712407};\\\", \\\"{x:1305,y:612,t:1527264712423};\\\", \\\"{x:1301,y:607,t:1527264712440};\\\", \\\"{x:1295,y:596,t:1527264712457};\\\", \\\"{x:1294,y:594,t:1527264712473};\\\", \\\"{x:1291,y:589,t:1527264712490};\\\", \\\"{x:1288,y:584,t:1527264712506};\\\", \\\"{x:1285,y:581,t:1527264712523};\\\", \\\"{x:1281,y:576,t:1527264712540};\\\", \\\"{x:1281,y:575,t:1527264712628};\\\", \\\"{x:1281,y:572,t:1527264712643};\\\", \\\"{x:1282,y:571,t:1527264712660};\\\", \\\"{x:1285,y:570,t:1527264712674};\\\", \\\"{x:1288,y:569,t:1527264712690};\\\", \\\"{x:1297,y:569,t:1527264712706};\\\", \\\"{x:1311,y:569,t:1527264712723};\\\", \\\"{x:1329,y:569,t:1527264712740};\\\", \\\"{x:1344,y:569,t:1527264712756};\\\", \\\"{x:1360,y:569,t:1527264712773};\\\", \\\"{x:1372,y:568,t:1527264712789};\\\", \\\"{x:1373,y:568,t:1527264712806};\\\", \\\"{x:1374,y:568,t:1527264712824};\\\", \\\"{x:1375,y:568,t:1527264712931};\\\", \\\"{x:1378,y:568,t:1527264712940};\\\", \\\"{x:1390,y:563,t:1527264712957};\\\", \\\"{x:1394,y:561,t:1527264712974};\\\", \\\"{x:1395,y:561,t:1527264713131};\\\", \\\"{x:1396,y:562,t:1527264713140};\\\", \\\"{x:1401,y:564,t:1527264713157};\\\", \\\"{x:1404,y:564,t:1527264713173};\\\", \\\"{x:1405,y:564,t:1527264713191};\\\", \\\"{x:1405,y:565,t:1527264713208};\\\", \\\"{x:1406,y:565,t:1527264713224};\\\", \\\"{x:1406,y:566,t:1527264713240};\\\", \\\"{x:1407,y:567,t:1527264713267};\\\", \\\"{x:1410,y:567,t:1527264713278};\\\", \\\"{x:1410,y:569,t:1527264714757};\\\", \\\"{x:1410,y:570,t:1527264714763};\\\", \\\"{x:1404,y:575,t:1527264714776};\\\", \\\"{x:1373,y:595,t:1527264714793};\\\", \\\"{x:1357,y:604,t:1527264714810};\\\", \\\"{x:1290,y:622,t:1527264714826};\\\", \\\"{x:1218,y:631,t:1527264714843};\\\", \\\"{x:1078,y:633,t:1527264714860};\\\", \\\"{x:979,y:624,t:1527264714875};\\\", \\\"{x:869,y:612,t:1527264714893};\\\", \\\"{x:761,y:594,t:1527264714909};\\\", \\\"{x:689,y:576,t:1527264714926};\\\", \\\"{x:589,y:560,t:1527264714941};\\\", \\\"{x:490,y:536,t:1527264714957};\\\", \\\"{x:415,y:518,t:1527264714974};\\\", \\\"{x:362,y:502,t:1527264714991};\\\", \\\"{x:352,y:498,t:1527264715007};\\\", \\\"{x:356,y:495,t:1527264715083};\\\", \\\"{x:359,y:492,t:1527264715090};\\\", \\\"{x:366,y:486,t:1527264715106};\\\", \\\"{x:367,y:484,t:1527264715123};\\\", \\\"{x:384,y:479,t:1527264715140};\\\", \\\"{x:400,y:471,t:1527264715157};\\\", \\\"{x:417,y:468,t:1527264715173};\\\", \\\"{x:432,y:468,t:1527264715190};\\\", \\\"{x:456,y:468,t:1527264715208};\\\", \\\"{x:468,y:468,t:1527264715223};\\\", \\\"{x:481,y:468,t:1527264715240};\\\", \\\"{x:491,y:468,t:1527264715257};\\\", \\\"{x:514,y:474,t:1527264715273};\\\", \\\"{x:520,y:474,t:1527264715290};\\\", \\\"{x:525,y:476,t:1527264715307};\\\", \\\"{x:529,y:480,t:1527264715323};\\\", \\\"{x:534,y:481,t:1527264715341};\\\", \\\"{x:537,y:483,t:1527264715357};\\\", \\\"{x:539,y:483,t:1527264715373};\\\", \\\"{x:545,y:485,t:1527264715390};\\\", \\\"{x:552,y:486,t:1527264715408};\\\", \\\"{x:561,y:487,t:1527264715424};\\\", \\\"{x:570,y:488,t:1527264715440};\\\", \\\"{x:582,y:493,t:1527264715457};\\\", \\\"{x:585,y:495,t:1527264715473};\\\", \\\"{x:589,y:497,t:1527264715490};\\\", \\\"{x:590,y:497,t:1527264715507};\\\", \\\"{x:591,y:497,t:1527264715524};\\\", \\\"{x:594,y:497,t:1527264715540};\\\", \\\"{x:595,y:497,t:1527264715557};\\\", \\\"{x:596,y:497,t:1527264715575};\\\", \\\"{x:598,y:497,t:1527264715631};\\\", \\\"{x:599,y:497,t:1527264715654};\\\", \\\"{x:601,y:497,t:1527264715864};\\\", \\\"{x:606,y:497,t:1527264715878};\\\", \\\"{x:635,y:513,t:1527264715894};\\\", \\\"{x:710,y:539,t:1527264715911};\\\", \\\"{x:812,y:580,t:1527264715928};\\\", \\\"{x:906,y:607,t:1527264715944};\\\", \\\"{x:981,y:633,t:1527264715960};\\\", \\\"{x:1004,y:642,t:1527264715977};\\\", \\\"{x:1010,y:646,t:1527264715995};\\\", \\\"{x:1011,y:649,t:1527264716010};\\\", \\\"{x:1008,y:644,t:1527264716126};\\\", \\\"{x:1002,y:637,t:1527264716134};\\\", \\\"{x:1000,y:631,t:1527264716144};\\\", \\\"{x:996,y:623,t:1527264716161};\\\", \\\"{x:991,y:616,t:1527264716178};\\\", \\\"{x:987,y:612,t:1527264716195};\\\", \\\"{x:978,y:605,t:1527264716212};\\\", \\\"{x:960,y:590,t:1527264716227};\\\", \\\"{x:945,y:580,t:1527264716245};\\\", \\\"{x:915,y:566,t:1527264716261};\\\", \\\"{x:904,y:558,t:1527264716279};\\\", \\\"{x:890,y:546,t:1527264716294};\\\", \\\"{x:873,y:540,t:1527264716310};\\\", \\\"{x:861,y:537,t:1527264716327};\\\", \\\"{x:840,y:531,t:1527264716345};\\\", \\\"{x:816,y:524,t:1527264716362};\\\", \\\"{x:797,y:521,t:1527264716377};\\\", \\\"{x:778,y:519,t:1527264716394};\\\", \\\"{x:762,y:511,t:1527264716411};\\\", \\\"{x:749,y:509,t:1527264716427};\\\", \\\"{x:736,y:505,t:1527264716445};\\\", \\\"{x:726,y:505,t:1527264716461};\\\", \\\"{x:722,y:505,t:1527264716478};\\\", \\\"{x:710,y:505,t:1527264716494};\\\", \\\"{x:703,y:505,t:1527264716511};\\\", \\\"{x:692,y:505,t:1527264716527};\\\", \\\"{x:689,y:505,t:1527264716545};\\\", \\\"{x:685,y:504,t:1527264716561};\\\", \\\"{x:683,y:504,t:1527264716577};\\\", \\\"{x:681,y:504,t:1527264716594};\\\", \\\"{x:672,y:502,t:1527264716612};\\\", \\\"{x:670,y:502,t:1527264716628};\\\", \\\"{x:666,y:502,t:1527264716645};\\\", \\\"{x:658,y:501,t:1527264716662};\\\", \\\"{x:654,y:501,t:1527264716678};\\\", \\\"{x:650,y:501,t:1527264716694};\\\", \\\"{x:647,y:501,t:1527264716712};\\\", \\\"{x:640,y:501,t:1527264716728};\\\", \\\"{x:637,y:501,t:1527264716744};\\\", \\\"{x:632,y:501,t:1527264716762};\\\", \\\"{x:627,y:501,t:1527264716779};\\\", \\\"{x:624,y:502,t:1527264716794};\\\", \\\"{x:622,y:502,t:1527264717230};\\\", \\\"{x:623,y:502,t:1527264717245};\\\", \\\"{x:655,y:507,t:1527264717262};\\\", \\\"{x:676,y:509,t:1527264717278};\\\", \\\"{x:701,y:521,t:1527264717296};\\\", \\\"{x:724,y:530,t:1527264717312};\\\", \\\"{x:741,y:531,t:1527264717328};\\\", \\\"{x:745,y:536,t:1527264717345};\\\", \\\"{x:757,y:540,t:1527264717361};\\\", \\\"{x:765,y:540,t:1527264717378};\\\", \\\"{x:767,y:540,t:1527264717395};\\\", \\\"{x:768,y:540,t:1527264717412};\\\", \\\"{x:770,y:540,t:1527264717447};\\\", \\\"{x:771,y:540,t:1527264717487};\\\", \\\"{x:772,y:539,t:1527264717495};\\\", \\\"{x:774,y:539,t:1527264717511};\\\", \\\"{x:777,y:536,t:1527264717534};\\\", \\\"{x:778,y:536,t:1527264717546};\\\", \\\"{x:781,y:536,t:1527264717562};\\\", \\\"{x:786,y:534,t:1527264717579};\\\", \\\"{x:797,y:532,t:1527264717595};\\\", \\\"{x:802,y:531,t:1527264717612};\\\", \\\"{x:806,y:531,t:1527264717628};\\\", \\\"{x:815,y:531,t:1527264717645};\\\", \\\"{x:823,y:531,t:1527264717662};\\\", \\\"{x:826,y:531,t:1527264717680};\\\", \\\"{x:829,y:531,t:1527264717726};\\\", \\\"{x:831,y:531,t:1527264717774};\\\", \\\"{x:831,y:532,t:1527264718286};\\\", \\\"{x:831,y:536,t:1527264718296};\\\", \\\"{x:829,y:543,t:1527264718312};\\\", \\\"{x:827,y:554,t:1527264718330};\\\", \\\"{x:821,y:559,t:1527264718346};\\\", \\\"{x:816,y:575,t:1527264718363};\\\", \\\"{x:807,y:589,t:1527264718379};\\\", \\\"{x:802,y:599,t:1527264718396};\\\", \\\"{x:799,y:604,t:1527264718413};\\\", \\\"{x:799,y:605,t:1527264718437};\\\", \\\"{x:795,y:610,t:1527264718446};\\\", \\\"{x:789,y:621,t:1527264718462};\\\", \\\"{x:779,y:633,t:1527264718481};\\\", \\\"{x:768,y:645,t:1527264718495};\\\", \\\"{x:750,y:661,t:1527264718513};\\\", \\\"{x:730,y:672,t:1527264718529};\\\", \\\"{x:719,y:680,t:1527264718546};\\\", \\\"{x:702,y:688,t:1527264718562};\\\", \\\"{x:686,y:698,t:1527264718580};\\\", \\\"{x:670,y:710,t:1527264718596};\\\", \\\"{x:656,y:719,t:1527264718613};\\\", \\\"{x:636,y:728,t:1527264718630};\\\", \\\"{x:634,y:730,t:1527264718646};\\\", \\\"{x:622,y:733,t:1527264718663};\\\", \\\"{x:606,y:737,t:1527264718679};\\\", \\\"{x:598,y:742,t:1527264718696};\\\", \\\"{x:597,y:742,t:1527264718713};\\\", \\\"{x:596,y:742,t:1527264718729};\\\", \\\"{x:594,y:742,t:1527264718747};\\\", \\\"{x:592,y:742,t:1527264718763};\\\", \\\"{x:590,y:742,t:1527264718780};\\\", \\\"{x:589,y:742,t:1527264718796};\\\", \\\"{x:587,y:742,t:1527264718814};\\\", \\\"{x:587,y:741,t:1527264718830};\\\", \\\"{x:585,y:741,t:1527264718846};\\\", \\\"{x:583,y:739,t:1527264718878};\\\", \\\"{x:581,y:739,t:1527264719070};\\\", \\\"{x:578,y:739,t:1527264719080};\\\", \\\"{x:574,y:739,t:1527264719287};\\\", \\\"{x:573,y:739,t:1527264719297};\\\", \\\"{x:570,y:739,t:1527264719318};\\\", \\\"{x:568,y:739,t:1527264719330};\\\", \\\"{x:562,y:739,t:1527264719348};\\\", \\\"{x:560,y:739,t:1527264719364};\\\", \\\"{x:558,y:739,t:1527264719380};\\\", \\\"{x:553,y:739,t:1527264719397};\\\", \\\"{x:548,y:740,t:1527264719414};\\\", \\\"{x:543,y:740,t:1527264719431};\\\", \\\"{x:537,y:741,t:1527264719447};\\\", \\\"{x:535,y:741,t:1527264719464};\\\", \\\"{x:534,y:741,t:1527264719480};\\\", \\\"{x:533,y:741,t:1527264719497};\\\", \\\"{x:537,y:741,t:1527264720830};\\\", \\\"{x:545,y:741,t:1527264720838};\\\", \\\"{x:546,y:741,t:1527264720902};\\\" ] }, { \\\"rt\\\": 40857, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 11, \\\"time_elapsed\\\": 346113, \\\"internal_node_id\\\": \\\"0.0-6.0-1.0\\\", \\\"subject\\\": \\\"RV9F6\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"lima\\\", \\\"condition\\\": \\\"115\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"duration+starts\\\", \\\"q\\\": 7, \\\"clicks\\\": 2.5, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XFull-YFull\\\", \\\"correct\\\": 1, \\\"orth_correct\\\": 0, \\\"answer\\\": [ \\\"X\\\", \\\"O\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-C -O -F -O -X -X -O -X \\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:548,y:740,t:1527264729622};\\\", \\\"{x:555,y:739,t:1527264729638};\\\", \\\"{x:565,y:738,t:1527264729648};\\\", \\\"{x:573,y:734,t:1527264729661};\\\", \\\"{x:580,y:730,t:1527264729676};\\\", \\\"{x:593,y:727,t:1527264729688};\\\", \\\"{x:612,y:723,t:1527264729705};\\\", \\\"{x:632,y:723,t:1527264729722};\\\", \\\"{x:653,y:719,t:1527264729738};\\\", \\\"{x:682,y:717,t:1527264729755};\\\", \\\"{x:718,y:716,t:1527264729771};\\\", \\\"{x:736,y:711,t:1527264729788};\\\", \\\"{x:752,y:703,t:1527264729805};\\\", \\\"{x:796,y:700,t:1527264729821};\\\", \\\"{x:820,y:699,t:1527264729839};\\\", \\\"{x:825,y:699,t:1527264729855};\\\", \\\"{x:829,y:702,t:1527264729872};\\\", \\\"{x:848,y:702,t:1527264729889};\\\", \\\"{x:850,y:702,t:1527264729904};\\\", \\\"{x:873,y:696,t:1527264729921};\\\", \\\"{x:907,y:689,t:1527264729938};\\\", \\\"{x:952,y:688,t:1527264729954};\\\", \\\"{x:999,y:683,t:1527264729972};\\\", \\\"{x:1041,y:675,t:1527264729989};\\\", \\\"{x:1066,y:669,t:1527264730005};\\\", \\\"{x:1095,y:655,t:1527264730022};\\\", \\\"{x:1114,y:654,t:1527264730039};\\\", \\\"{x:1122,y:654,t:1527264730055};\\\", \\\"{x:1138,y:652,t:1527264730072};\\\", \\\"{x:1160,y:652,t:1527264730089};\\\", \\\"{x:1205,y:644,t:1527264730106};\\\", \\\"{x:1235,y:637,t:1527264730122};\\\", \\\"{x:1270,y:631,t:1527264730139};\\\", \\\"{x:1324,y:629,t:1527264730156};\\\", \\\"{x:1368,y:626,t:1527264730173};\\\", \\\"{x:1450,y:630,t:1527264730191};\\\", \\\"{x:1583,y:657,t:1527264730206};\\\", \\\"{x:1641,y:670,t:1527264730222};\\\", \\\"{x:1662,y:677,t:1527264730239};\\\", \\\"{x:1667,y:687,t:1527264730256};\\\", \\\"{x:1671,y:690,t:1527264730277};\\\", \\\"{x:1673,y:692,t:1527264730294};\\\", \\\"{x:1674,y:693,t:1527264730318};\\\", \\\"{x:1675,y:695,t:1527264730326};\\\", \\\"{x:1675,y:697,t:1527264730340};\\\", \\\"{x:1675,y:700,t:1527264730357};\\\", \\\"{x:1673,y:706,t:1527264730374};\\\", \\\"{x:1667,y:719,t:1527264730389};\\\", \\\"{x:1658,y:736,t:1527264730406};\\\", \\\"{x:1652,y:744,t:1527264730423};\\\", \\\"{x:1644,y:754,t:1527264730440};\\\", \\\"{x:1641,y:760,t:1527264730456};\\\", \\\"{x:1636,y:766,t:1527264730473};\\\", \\\"{x:1633,y:768,t:1527264730489};\\\", \\\"{x:1631,y:768,t:1527264730506};\\\", \\\"{x:1631,y:769,t:1527264730523};\\\", \\\"{x:1630,y:770,t:1527264730539};\\\", \\\"{x:1626,y:770,t:1527264730556};\\\", \\\"{x:1622,y:770,t:1527264730573};\\\", \\\"{x:1613,y:770,t:1527264730589};\\\", \\\"{x:1593,y:763,t:1527264730606};\\\", \\\"{x:1580,y:759,t:1527264730623};\\\", \\\"{x:1569,y:755,t:1527264730639};\\\", \\\"{x:1559,y:752,t:1527264730656};\\\", \\\"{x:1555,y:751,t:1527264730673};\\\", \\\"{x:1544,y:748,t:1527264730689};\\\", \\\"{x:1537,y:744,t:1527264730706};\\\", \\\"{x:1533,y:742,t:1527264730723};\\\", \\\"{x:1529,y:741,t:1527264730740};\\\", \\\"{x:1528,y:741,t:1527264730756};\\\", \\\"{x:1527,y:741,t:1527264730773};\\\", \\\"{x:1526,y:741,t:1527264731063};\\\", \\\"{x:1525,y:741,t:1527264731102};\\\", \\\"{x:1524,y:741,t:1527264736021};\\\", \\\"{x:1523,y:742,t:1527264736037};\\\", \\\"{x:1522,y:742,t:1527264736077};\\\", \\\"{x:1522,y:744,t:1527264736109};\\\", \\\"{x:1521,y:746,t:1527264736134};\\\", \\\"{x:1519,y:746,t:1527264736145};\\\", \\\"{x:1513,y:746,t:1527264736162};\\\", \\\"{x:1509,y:746,t:1527264736178};\\\", \\\"{x:1505,y:746,t:1527264736195};\\\", \\\"{x:1498,y:746,t:1527264736212};\\\", \\\"{x:1485,y:744,t:1527264736228};\\\", \\\"{x:1473,y:739,t:1527264736245};\\\", \\\"{x:1466,y:738,t:1527264736262};\\\", \\\"{x:1456,y:738,t:1527264736278};\\\", \\\"{x:1450,y:736,t:1527264736295};\\\", \\\"{x:1444,y:734,t:1527264736312};\\\", \\\"{x:1436,y:731,t:1527264736328};\\\", \\\"{x:1428,y:730,t:1527264736345};\\\", \\\"{x:1427,y:730,t:1527264736362};\\\", \\\"{x:1425,y:730,t:1527264736381};\\\", \\\"{x:1422,y:730,t:1527264736558};\\\", \\\"{x:1419,y:730,t:1527264736565};\\\", \\\"{x:1415,y:728,t:1527264736579};\\\", \\\"{x:1410,y:728,t:1527264736595};\\\", \\\"{x:1399,y:725,t:1527264736612};\\\", \\\"{x:1388,y:722,t:1527264736630};\\\", \\\"{x:1387,y:722,t:1527264736645};\\\", \\\"{x:1386,y:721,t:1527264736662};\\\", \\\"{x:1385,y:721,t:1527264736933};\\\", \\\"{x:1384,y:721,t:1527264737086};\\\", \\\"{x:1382,y:721,t:1527264737117};\\\", \\\"{x:1380,y:722,t:1527264737173};\\\", \\\"{x:1378,y:720,t:1527264737205};\\\", \\\"{x:1378,y:719,t:1527264737213};\\\", \\\"{x:1378,y:715,t:1527264737229};\\\", \\\"{x:1378,y:712,t:1527264737246};\\\", \\\"{x:1378,y:711,t:1527264737263};\\\", \\\"{x:1377,y:710,t:1527264737279};\\\", \\\"{x:1374,y:709,t:1527264737397};\\\", \\\"{x:1367,y:707,t:1527264737413};\\\", \\\"{x:1364,y:707,t:1527264737429};\\\", \\\"{x:1358,y:706,t:1527264737446};\\\", \\\"{x:1355,y:705,t:1527264737463};\\\", \\\"{x:1346,y:703,t:1527264737480};\\\", \\\"{x:1336,y:700,t:1527264737496};\\\", \\\"{x:1328,y:698,t:1527264737513};\\\", \\\"{x:1325,y:696,t:1527264737530};\\\", \\\"{x:1324,y:696,t:1527264737638};\\\", \\\"{x:1323,y:696,t:1527264737646};\\\", \\\"{x:1322,y:696,t:1527264738029};\\\", \\\"{x:1325,y:696,t:1527264738485};\\\", \\\"{x:1329,y:696,t:1527264738497};\\\", \\\"{x:1330,y:696,t:1527264738514};\\\", \\\"{x:1332,y:696,t:1527264738531};\\\", \\\"{x:1334,y:694,t:1527264738547};\\\", \\\"{x:1335,y:694,t:1527264738564};\\\", \\\"{x:1338,y:697,t:1527264739566};\\\", \\\"{x:1340,y:702,t:1527264739582};\\\", \\\"{x:1341,y:704,t:1527264739598};\\\", \\\"{x:1341,y:705,t:1527264739637};\\\", \\\"{x:1341,y:704,t:1527264739894};\\\", \\\"{x:1342,y:703,t:1527264739901};\\\", \\\"{x:1343,y:702,t:1527264739915};\\\", \\\"{x:1344,y:700,t:1527264739932};\\\", \\\"{x:1345,y:700,t:1527264741015};\\\", \\\"{x:1347,y:701,t:1527264741022};\\\", \\\"{x:1356,y:703,t:1527264741035};\\\", \\\"{x:1366,y:707,t:1527264741050};\\\", \\\"{x:1378,y:709,t:1527264741067};\\\", \\\"{x:1391,y:712,t:1527264741083};\\\", \\\"{x:1410,y:718,t:1527264741101};\\\", \\\"{x:1429,y:726,t:1527264741117};\\\", \\\"{x:1438,y:728,t:1527264741134};\\\", \\\"{x:1447,y:731,t:1527264741151};\\\", \\\"{x:1449,y:732,t:1527264741167};\\\", \\\"{x:1451,y:732,t:1527264741183};\\\", \\\"{x:1453,y:732,t:1527264741200};\\\", \\\"{x:1459,y:732,t:1527264741217};\\\", \\\"{x:1467,y:732,t:1527264741234};\\\", \\\"{x:1473,y:734,t:1527264741250};\\\", \\\"{x:1477,y:734,t:1527264741267};\\\", \\\"{x:1483,y:734,t:1527264741283};\\\", \\\"{x:1490,y:733,t:1527264741300};\\\", \\\"{x:1501,y:732,t:1527264741317};\\\", \\\"{x:1507,y:731,t:1527264741334};\\\", \\\"{x:1508,y:731,t:1527264741350};\\\", \\\"{x:1509,y:730,t:1527264741366};\\\", \\\"{x:1511,y:729,t:1527264741384};\\\", \\\"{x:1512,y:727,t:1527264741429};\\\", \\\"{x:1513,y:727,t:1527264741621};\\\", \\\"{x:1513,y:728,t:1527264741634};\\\", \\\"{x:1514,y:731,t:1527264741650};\\\", \\\"{x:1516,y:734,t:1527264741667};\\\", \\\"{x:1516,y:735,t:1527264741709};\\\", \\\"{x:1516,y:736,t:1527264741789};\\\", \\\"{x:1516,y:737,t:1527264741805};\\\", \\\"{x:1516,y:741,t:1527264741829};\\\", \\\"{x:1515,y:741,t:1527264741837};\\\", \\\"{x:1515,y:742,t:1527264741853};\\\", \\\"{x:1513,y:743,t:1527264741867};\\\", \\\"{x:1511,y:745,t:1527264741884};\\\", \\\"{x:1508,y:748,t:1527264741902};\\\", \\\"{x:1506,y:750,t:1527264741918};\\\", \\\"{x:1505,y:750,t:1527264741934};\\\", \\\"{x:1504,y:752,t:1527264741951};\\\", \\\"{x:1502,y:754,t:1527264741968};\\\", \\\"{x:1501,y:756,t:1527264741984};\\\", \\\"{x:1501,y:757,t:1527264742001};\\\", \\\"{x:1500,y:759,t:1527264742018};\\\", \\\"{x:1498,y:761,t:1527264742034};\\\", \\\"{x:1498,y:763,t:1527264742051};\\\", \\\"{x:1497,y:765,t:1527264742068};\\\", \\\"{x:1496,y:767,t:1527264742084};\\\", \\\"{x:1494,y:770,t:1527264742101};\\\", \\\"{x:1492,y:774,t:1527264742118};\\\", \\\"{x:1490,y:778,t:1527264742133};\\\", \\\"{x:1487,y:784,t:1527264742151};\\\", \\\"{x:1485,y:790,t:1527264742168};\\\", \\\"{x:1482,y:797,t:1527264742184};\\\", \\\"{x:1480,y:800,t:1527264742201};\\\", \\\"{x:1478,y:805,t:1527264742218};\\\", \\\"{x:1478,y:808,t:1527264742234};\\\", \\\"{x:1475,y:812,t:1527264742251};\\\", \\\"{x:1473,y:815,t:1527264742268};\\\", \\\"{x:1472,y:820,t:1527264742284};\\\", \\\"{x:1471,y:830,t:1527264742301};\\\", \\\"{x:1469,y:833,t:1527264742319};\\\", \\\"{x:1469,y:835,t:1527264742334};\\\", \\\"{x:1469,y:837,t:1527264742351};\\\", \\\"{x:1468,y:838,t:1527264742368};\\\", \\\"{x:1468,y:840,t:1527264742386};\\\", \\\"{x:1468,y:841,t:1527264742402};\\\", \\\"{x:1468,y:843,t:1527264742418};\\\", \\\"{x:1468,y:845,t:1527264742435};\\\", \\\"{x:1467,y:845,t:1527264742452};\\\", \\\"{x:1466,y:847,t:1527264742468};\\\", \\\"{x:1466,y:848,t:1527264742485};\\\", \\\"{x:1466,y:850,t:1527264742502};\\\", \\\"{x:1466,y:848,t:1527264742701};\\\", \\\"{x:1467,y:845,t:1527264742718};\\\", \\\"{x:1470,y:842,t:1527264742735};\\\", \\\"{x:1470,y:841,t:1527264742752};\\\", \\\"{x:1471,y:840,t:1527264742781};\\\", \\\"{x:1471,y:839,t:1527264742797};\\\", \\\"{x:1472,y:838,t:1527264742846};\\\", \\\"{x:1473,y:836,t:1527264742853};\\\", \\\"{x:1473,y:835,t:1527264742869};\\\", \\\"{x:1474,y:832,t:1527264742885};\\\", \\\"{x:1476,y:831,t:1527264742902};\\\", \\\"{x:1478,y:827,t:1527264742918};\\\", \\\"{x:1479,y:826,t:1527264742935};\\\", \\\"{x:1482,y:823,t:1527264742952};\\\", \\\"{x:1484,y:821,t:1527264742969};\\\", \\\"{x:1489,y:815,t:1527264742985};\\\", \\\"{x:1492,y:812,t:1527264743002};\\\", \\\"{x:1494,y:810,t:1527264743020};\\\", \\\"{x:1495,y:808,t:1527264743035};\\\", \\\"{x:1496,y:806,t:1527264743101};\\\", \\\"{x:1498,y:804,t:1527264743109};\\\", \\\"{x:1499,y:801,t:1527264743119};\\\", \\\"{x:1502,y:797,t:1527264743135};\\\", \\\"{x:1504,y:794,t:1527264743152};\\\", \\\"{x:1506,y:791,t:1527264743170};\\\", \\\"{x:1507,y:790,t:1527264743188};\\\", \\\"{x:1508,y:789,t:1527264743202};\\\", \\\"{x:1509,y:788,t:1527264743219};\\\", \\\"{x:1512,y:784,t:1527264743235};\\\", \\\"{x:1513,y:783,t:1527264743253};\\\", \\\"{x:1513,y:782,t:1527264743269};\\\", \\\"{x:1515,y:781,t:1527264743309};\\\", \\\"{x:1515,y:780,t:1527264743319};\\\", \\\"{x:1516,y:780,t:1527264743335};\\\", \\\"{x:1516,y:779,t:1527264743352};\\\", \\\"{x:1518,y:776,t:1527264743370};\\\", \\\"{x:1519,y:775,t:1527264743386};\\\", \\\"{x:1519,y:773,t:1527264743402};\\\", \\\"{x:1522,y:769,t:1527264743419};\\\", \\\"{x:1525,y:765,t:1527264743436};\\\", \\\"{x:1529,y:758,t:1527264743452};\\\", \\\"{x:1533,y:751,t:1527264743468};\\\", \\\"{x:1533,y:750,t:1527264743486};\\\", \\\"{x:1535,y:748,t:1527264743502};\\\", \\\"{x:1536,y:747,t:1527264743525};\\\", \\\"{x:1535,y:747,t:1527264743677};\\\", \\\"{x:1533,y:748,t:1527264743686};\\\", \\\"{x:1527,y:752,t:1527264743703};\\\", \\\"{x:1521,y:757,t:1527264743719};\\\", \\\"{x:1519,y:759,t:1527264743736};\\\", \\\"{x:1518,y:763,t:1527264743753};\\\", \\\"{x:1517,y:764,t:1527264743769};\\\", \\\"{x:1517,y:765,t:1527264743786};\\\", \\\"{x:1515,y:768,t:1527264743861};\\\", \\\"{x:1515,y:769,t:1527264743869};\\\", \\\"{x:1513,y:777,t:1527264743886};\\\", \\\"{x:1510,y:784,t:1527264743903};\\\", \\\"{x:1509,y:789,t:1527264743919};\\\", \\\"{x:1505,y:803,t:1527264743936};\\\", \\\"{x:1504,y:813,t:1527264743953};\\\", \\\"{x:1501,y:823,t:1527264743969};\\\", \\\"{x:1499,y:829,t:1527264743986};\\\", \\\"{x:1498,y:831,t:1527264744003};\\\", \\\"{x:1496,y:833,t:1527264744021};\\\", \\\"{x:1496,y:834,t:1527264744037};\\\", \\\"{x:1495,y:835,t:1527264744069};\\\", \\\"{x:1494,y:838,t:1527264744133};\\\", \\\"{x:1493,y:838,t:1527264744149};\\\", \\\"{x:1492,y:839,t:1527264744237};\\\", \\\"{x:1491,y:841,t:1527264744405};\\\", \\\"{x:1491,y:842,t:1527264744420};\\\", \\\"{x:1490,y:843,t:1527264744437};\\\", \\\"{x:1488,y:844,t:1527264744501};\\\", \\\"{x:1488,y:842,t:1527264745173};\\\", \\\"{x:1487,y:842,t:1527264745733};\\\", \\\"{x:1481,y:839,t:1527264745741};\\\", \\\"{x:1478,y:832,t:1527264745755};\\\", \\\"{x:1442,y:815,t:1527264745772};\\\", \\\"{x:1395,y:794,t:1527264745788};\\\", \\\"{x:1214,y:715,t:1527264745805};\\\", \\\"{x:1088,y:664,t:1527264745822};\\\", \\\"{x:953,y:610,t:1527264745838};\\\", \\\"{x:827,y:558,t:1527264745855};\\\", \\\"{x:729,y:524,t:1527264745871};\\\", \\\"{x:683,y:503,t:1527264745889};\\\", \\\"{x:677,y:490,t:1527264745905};\\\", \\\"{x:673,y:487,t:1527264745921};\\\", \\\"{x:673,y:488,t:1527264746133};\\\", \\\"{x:680,y:496,t:1527264746141};\\\", \\\"{x:696,y:508,t:1527264746151};\\\", \\\"{x:733,y:536,t:1527264746169};\\\", \\\"{x:755,y:554,t:1527264746185};\\\", \\\"{x:776,y:570,t:1527264746202};\\\", \\\"{x:799,y:584,t:1527264746218};\\\", \\\"{x:815,y:593,t:1527264746235};\\\", \\\"{x:827,y:598,t:1527264746252};\\\", \\\"{x:832,y:599,t:1527264746268};\\\", \\\"{x:833,y:599,t:1527264746389};\\\", \\\"{x:833,y:598,t:1527264746404};\\\", \\\"{x:833,y:597,t:1527264746418};\\\", \\\"{x:827,y:594,t:1527264746434};\\\", \\\"{x:817,y:589,t:1527264746451};\\\", \\\"{x:810,y:585,t:1527264746468};\\\", \\\"{x:774,y:581,t:1527264746485};\\\", \\\"{x:759,y:575,t:1527264746502};\\\", \\\"{x:741,y:573,t:1527264746518};\\\", \\\"{x:730,y:571,t:1527264746535};\\\", \\\"{x:725,y:569,t:1527264746552};\\\", \\\"{x:721,y:569,t:1527264746568};\\\", \\\"{x:720,y:569,t:1527264746621};\\\", \\\"{x:717,y:569,t:1527264746637};\\\", \\\"{x:717,y:570,t:1527264747326};\\\", \\\"{x:722,y:572,t:1527264747336};\\\", \\\"{x:731,y:576,t:1527264747354};\\\", \\\"{x:735,y:576,t:1527264747370};\\\", \\\"{x:747,y:580,t:1527264747385};\\\", \\\"{x:751,y:580,t:1527264747403};\\\", \\\"{x:752,y:580,t:1527264747420};\\\", \\\"{x:750,y:580,t:1527264747558};\\\", \\\"{x:743,y:580,t:1527264747569};\\\", \\\"{x:719,y:580,t:1527264747588};\\\", \\\"{x:695,y:579,t:1527264747602};\\\", \\\"{x:679,y:579,t:1527264747620};\\\", \\\"{x:664,y:579,t:1527264747636};\\\", \\\"{x:655,y:579,t:1527264747652};\\\", \\\"{x:644,y:579,t:1527264747669};\\\", \\\"{x:643,y:579,t:1527264747687};\\\", \\\"{x:639,y:579,t:1527264747703};\\\", \\\"{x:637,y:580,t:1527264747719};\\\", \\\"{x:635,y:580,t:1527264747741};\\\", \\\"{x:635,y:581,t:1527264747797};\\\", \\\"{x:636,y:579,t:1527264748069};\\\", \\\"{x:640,y:579,t:1527264748086};\\\", \\\"{x:652,y:584,t:1527264748104};\\\", \\\"{x:660,y:586,t:1527264748119};\\\", \\\"{x:678,y:589,t:1527264748136};\\\", \\\"{x:695,y:591,t:1527264748154};\\\", \\\"{x:712,y:592,t:1527264748170};\\\", \\\"{x:719,y:595,t:1527264748187};\\\", \\\"{x:733,y:595,t:1527264748203};\\\", \\\"{x:744,y:596,t:1527264748219};\\\", \\\"{x:753,y:597,t:1527264748237};\\\", \\\"{x:766,y:597,t:1527264748253};\\\", \\\"{x:772,y:597,t:1527264748270};\\\", \\\"{x:774,y:597,t:1527264748287};\\\", \\\"{x:780,y:597,t:1527264748304};\\\", \\\"{x:784,y:596,t:1527264748320};\\\", \\\"{x:787,y:595,t:1527264748337};\\\", \\\"{x:790,y:594,t:1527264748357};\\\", \\\"{x:790,y:593,t:1527264748370};\\\", \\\"{x:792,y:592,t:1527264748386};\\\", \\\"{x:794,y:590,t:1527264748421};\\\", \\\"{x:796,y:588,t:1527264748437};\\\", \\\"{x:807,y:581,t:1527264748453};\\\", \\\"{x:812,y:577,t:1527264748470};\\\", \\\"{x:816,y:574,t:1527264748486};\\\", \\\"{x:820,y:571,t:1527264748504};\\\", \\\"{x:822,y:570,t:1527264748520};\\\", \\\"{x:828,y:567,t:1527264748538};\\\", \\\"{x:831,y:567,t:1527264748554};\\\", \\\"{x:833,y:567,t:1527264748570};\\\", \\\"{x:847,y:567,t:1527264749142};\\\", \\\"{x:890,y:571,t:1527264749155};\\\", \\\"{x:1031,y:591,t:1527264749171};\\\", \\\"{x:1165,y:616,t:1527264749188};\\\", \\\"{x:1266,y:653,t:1527264749205};\\\", \\\"{x:1355,y:680,t:1527264749221};\\\", \\\"{x:1468,y:727,t:1527264749237};\\\", \\\"{x:1581,y:771,t:1527264749255};\\\", \\\"{x:1697,y:822,t:1527264749270};\\\", \\\"{x:1804,y:865,t:1527264749288};\\\", \\\"{x:1876,y:900,t:1527264749305};\\\", \\\"{x:1908,y:921,t:1527264749321};\\\", \\\"{x:1919,y:934,t:1527264749337};\\\", \\\"{x:1919,y:942,t:1527264749353};\\\", \\\"{x:1919,y:944,t:1527264749370};\\\", \\\"{x:1917,y:944,t:1527264749598};\\\", \\\"{x:1911,y:942,t:1527264749606};\\\", \\\"{x:1903,y:941,t:1527264749621};\\\", \\\"{x:1873,y:926,t:1527264749638};\\\", \\\"{x:1853,y:920,t:1527264749655};\\\", \\\"{x:1837,y:910,t:1527264749671};\\\", \\\"{x:1816,y:902,t:1527264749688};\\\", \\\"{x:1798,y:893,t:1527264749704};\\\", \\\"{x:1776,y:891,t:1527264749721};\\\", \\\"{x:1766,y:887,t:1527264749737};\\\", \\\"{x:1764,y:884,t:1527264749754};\\\", \\\"{x:1764,y:883,t:1527264749771};\\\", \\\"{x:1761,y:883,t:1527264749788};\\\", \\\"{x:1756,y:881,t:1527264749805};\\\", \\\"{x:1753,y:881,t:1527264749820};\\\", \\\"{x:1750,y:880,t:1527264749838};\\\", \\\"{x:1749,y:880,t:1527264753078};\\\", \\\"{x:1745,y:880,t:1527264753096};\\\", \\\"{x:1743,y:880,t:1527264753107};\\\", \\\"{x:1741,y:880,t:1527264753133};\\\", \\\"{x:1740,y:880,t:1527264753158};\\\", \\\"{x:1739,y:880,t:1527264753174};\\\", \\\"{x:1738,y:880,t:1527264760862};\\\", \\\"{x:1732,y:881,t:1527264760878};\\\", \\\"{x:1731,y:881,t:1527264760895};\\\", \\\"{x:1730,y:882,t:1527264760912};\\\", \\\"{x:1729,y:882,t:1527264760966};\\\", \\\"{x:1726,y:882,t:1527264760978};\\\", \\\"{x:1719,y:884,t:1527264760995};\\\", \\\"{x:1711,y:885,t:1527264761012};\\\", \\\"{x:1704,y:885,t:1527264761028};\\\", \\\"{x:1688,y:885,t:1527264761046};\\\", \\\"{x:1677,y:885,t:1527264761062};\\\", \\\"{x:1663,y:885,t:1527264761079};\\\", \\\"{x:1652,y:880,t:1527264761096};\\\", \\\"{x:1645,y:878,t:1527264761112};\\\", \\\"{x:1643,y:870,t:1527264761128};\\\", \\\"{x:1634,y:866,t:1527264761145};\\\", \\\"{x:1629,y:865,t:1527264761161};\\\", \\\"{x:1624,y:860,t:1527264761179};\\\", \\\"{x:1611,y:853,t:1527264761195};\\\", \\\"{x:1592,y:848,t:1527264761211};\\\", \\\"{x:1565,y:839,t:1527264761228};\\\", \\\"{x:1522,y:827,t:1527264761244};\\\", \\\"{x:1485,y:819,t:1527264761262};\\\", \\\"{x:1414,y:803,t:1527264761278};\\\", \\\"{x:1326,y:784,t:1527264761295};\\\", \\\"{x:1223,y:764,t:1527264761312};\\\", \\\"{x:1114,y:748,t:1527264761328};\\\", \\\"{x:1002,y:738,t:1527264761345};\\\", \\\"{x:906,y:730,t:1527264761362};\\\", \\\"{x:881,y:724,t:1527264761378};\\\", \\\"{x:825,y:724,t:1527264761395};\\\", \\\"{x:801,y:724,t:1527264761412};\\\", \\\"{x:767,y:724,t:1527264761428};\\\", \\\"{x:734,y:724,t:1527264761445};\\\", \\\"{x:713,y:724,t:1527264761462};\\\", \\\"{x:703,y:724,t:1527264761478};\\\", \\\"{x:686,y:723,t:1527264761495};\\\", \\\"{x:681,y:721,t:1527264761512};\\\", \\\"{x:679,y:721,t:1527264761528};\\\", \\\"{x:674,y:721,t:1527264761545};\\\", \\\"{x:665,y:721,t:1527264761562};\\\", \\\"{x:650,y:730,t:1527264761578};\\\", \\\"{x:641,y:732,t:1527264761605};\\\", \\\"{x:631,y:734,t:1527264761613};\\\", \\\"{x:627,y:734,t:1527264761628};\\\", \\\"{x:613,y:734,t:1527264761646};\\\", \\\"{x:609,y:734,t:1527264761662};\\\", \\\"{x:607,y:734,t:1527264761678};\\\", \\\"{x:601,y:734,t:1527264761695};\\\", \\\"{x:598,y:734,t:1527264761712};\\\", \\\"{x:597,y:733,t:1527264761734};\\\", \\\"{x:595,y:733,t:1527264761745};\\\", \\\"{x:593,y:731,t:1527264761762};\\\", \\\"{x:591,y:730,t:1527264761845};\\\", \\\"{x:586,y:730,t:1527264761863};\\\", \\\"{x:579,y:729,t:1527264761879};\\\", \\\"{x:577,y:729,t:1527264761895};\\\", \\\"{x:573,y:729,t:1527264761912};\\\", \\\"{x:571,y:729,t:1527264761958};\\\", \\\"{x:570,y:729,t:1527264761973};\\\", \\\"{x:568,y:729,t:1527264761982};\\\", \\\"{x:565,y:729,t:1527264761996};\\\", \\\"{x:564,y:730,t:1527264762014};\\\", \\\"{x:556,y:733,t:1527264762029};\\\", \\\"{x:552,y:734,t:1527264762045};\\\" ] }, { \\\"rt\\\": 55077, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 12, \\\"time_elapsed\\\": 402405, \\\"internal_node_id\\\": \\\"0.0-6.0-2.0\\\", \\\"subject\\\": \\\"RV9F6\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"lima\\\", \\\"condition\\\": \\\"115\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"duration+contained\\\", \\\"q\\\": 8, \\\"clicks\\\": 1, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XFull-YFull\\\", \\\"correct\\\": 1, \\\"orth_correct\\\": 0, \\\"answer\\\": [ \\\"G\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-4-B -11 AM-X -B -X -X -J -J -J -G -B -B -6\\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:553,y:734,t:1527264768334};\\\", \\\"{x:555,y:734,t:1527264768341};\\\", \\\"{x:556,y:734,t:1527264768356};\\\", \\\"{x:561,y:734,t:1527264768381};\\\", \\\"{x:571,y:734,t:1527264768392};\\\", \\\"{x:587,y:734,t:1527264768406};\\\", \\\"{x:613,y:734,t:1527264768423};\\\", \\\"{x:624,y:734,t:1527264768436};\\\", \\\"{x:722,y:738,t:1527264768453};\\\", \\\"{x:755,y:741,t:1527264768469};\\\", \\\"{x:770,y:742,t:1527264768486};\\\", \\\"{x:799,y:742,t:1527264768503};\\\", \\\"{x:877,y:731,t:1527264768519};\\\", \\\"{x:979,y:717,t:1527264768536};\\\", \\\"{x:1059,y:695,t:1527264768553};\\\", \\\"{x:1117,y:684,t:1527264768570};\\\", \\\"{x:1184,y:664,t:1527264768586};\\\", \\\"{x:1227,y:648,t:1527264768603};\\\", \\\"{x:1303,y:626,t:1527264768619};\\\", \\\"{x:1329,y:618,t:1527264768637};\\\", \\\"{x:1403,y:589,t:1527264768653};\\\", \\\"{x:1428,y:577,t:1527264768671};\\\", \\\"{x:1443,y:573,t:1527264768687};\\\", \\\"{x:1459,y:564,t:1527264768704};\\\", \\\"{x:1486,y:552,t:1527264768720};\\\", \\\"{x:1516,y:540,t:1527264768737};\\\", \\\"{x:1566,y:523,t:1527264768753};\\\", \\\"{x:1599,y:503,t:1527264768770};\\\", \\\"{x:1624,y:481,t:1527264768787};\\\", \\\"{x:1647,y:461,t:1527264768803};\\\", \\\"{x:1659,y:447,t:1527264768821};\\\", \\\"{x:1664,y:434,t:1527264768837};\\\", \\\"{x:1665,y:433,t:1527264768974};\\\", \\\"{x:1662,y:433,t:1527264768990};\\\", \\\"{x:1657,y:436,t:1527264769004};\\\", \\\"{x:1647,y:438,t:1527264769021};\\\", \\\"{x:1635,y:443,t:1527264769037};\\\", \\\"{x:1618,y:453,t:1527264769053};\\\", \\\"{x:1598,y:459,t:1527264769071};\\\", \\\"{x:1593,y:463,t:1527264769088};\\\", \\\"{x:1571,y:475,t:1527264769104};\\\", \\\"{x:1556,y:485,t:1527264769121};\\\", \\\"{x:1544,y:491,t:1527264769137};\\\", \\\"{x:1527,y:503,t:1527264769154};\\\", \\\"{x:1511,y:514,t:1527264769171};\\\", \\\"{x:1507,y:517,t:1527264769188};\\\", \\\"{x:1499,y:520,t:1527264769203};\\\", \\\"{x:1490,y:524,t:1527264769221};\\\", \\\"{x:1489,y:525,t:1527264769238};\\\", \\\"{x:1483,y:528,t:1527264769254};\\\", \\\"{x:1481,y:528,t:1527264769271};\\\", \\\"{x:1481,y:529,t:1527264773310};\\\", \\\"{x:1481,y:537,t:1527264773325};\\\", \\\"{x:1488,y:552,t:1527264773342};\\\", \\\"{x:1496,y:568,t:1527264773359};\\\", \\\"{x:1500,y:578,t:1527264773375};\\\", \\\"{x:1503,y:585,t:1527264773392};\\\", \\\"{x:1505,y:591,t:1527264773409};\\\", \\\"{x:1508,y:595,t:1527264773425};\\\", \\\"{x:1511,y:598,t:1527264773441};\\\", \\\"{x:1522,y:605,t:1527264773458};\\\", \\\"{x:1526,y:608,t:1527264773476};\\\", \\\"{x:1533,y:613,t:1527264773491};\\\", \\\"{x:1538,y:615,t:1527264773509};\\\", \\\"{x:1538,y:616,t:1527264773686};\\\", \\\"{x:1538,y:617,t:1527264773693};\\\", \\\"{x:1537,y:620,t:1527264773709};\\\", \\\"{x:1534,y:627,t:1527264774207};\\\", \\\"{x:1534,y:630,t:1527264774214};\\\", \\\"{x:1532,y:637,t:1527264774226};\\\", \\\"{x:1528,y:647,t:1527264774242};\\\", \\\"{x:1521,y:662,t:1527264774259};\\\", \\\"{x:1510,y:676,t:1527264774275};\\\", \\\"{x:1486,y:707,t:1527264774292};\\\", \\\"{x:1465,y:732,t:1527264774309};\\\", \\\"{x:1448,y:748,t:1527264774325};\\\", \\\"{x:1447,y:751,t:1527264774342};\\\", \\\"{x:1429,y:768,t:1527264774360};\\\", \\\"{x:1412,y:781,t:1527264774377};\\\", \\\"{x:1405,y:785,t:1527264774393};\\\", \\\"{x:1397,y:787,t:1527264774409};\\\", \\\"{x:1385,y:788,t:1527264774427};\\\", \\\"{x:1378,y:790,t:1527264774443};\\\", \\\"{x:1373,y:792,t:1527264774459};\\\", \\\"{x:1371,y:792,t:1527264774476};\\\", \\\"{x:1371,y:791,t:1527264774558};\\\", \\\"{x:1371,y:789,t:1527264774565};\\\", \\\"{x:1371,y:786,t:1527264774577};\\\", \\\"{x:1371,y:784,t:1527264774594};\\\", \\\"{x:1371,y:783,t:1527264774609};\\\", \\\"{x:1371,y:782,t:1527264774774};\\\", \\\"{x:1371,y:781,t:1527264774790};\\\", \\\"{x:1371,y:779,t:1527264774807};\\\", \\\"{x:1371,y:778,t:1527264774821};\\\", \\\"{x:1370,y:777,t:1527264774829};\\\", \\\"{x:1368,y:777,t:1527264774853};\\\", \\\"{x:1366,y:775,t:1527264774878};\\\", \\\"{x:1362,y:775,t:1527264774893};\\\", \\\"{x:1358,y:772,t:1527264774910};\\\", \\\"{x:1356,y:771,t:1527264774941};\\\", \\\"{x:1355,y:771,t:1527264774949};\\\", \\\"{x:1353,y:770,t:1527264774965};\\\", \\\"{x:1352,y:769,t:1527264774990};\\\", \\\"{x:1350,y:768,t:1527264774999};\\\", \\\"{x:1349,y:768,t:1527264775009};\\\", \\\"{x:1347,y:767,t:1527264775027};\\\", \\\"{x:1346,y:767,t:1527264775043};\\\", \\\"{x:1346,y:766,t:1527264775076};\\\", \\\"{x:1345,y:766,t:1527264775093};\\\", \\\"{x:1345,y:765,t:1527264775413};\\\", \\\"{x:1344,y:765,t:1527264775429};\\\", \\\"{x:1342,y:767,t:1527264775444};\\\", \\\"{x:1339,y:773,t:1527264775461};\\\", \\\"{x:1337,y:779,t:1527264775477};\\\", \\\"{x:1330,y:791,t:1527264775493};\\\", \\\"{x:1324,y:801,t:1527264775511};\\\", \\\"{x:1317,y:810,t:1527264775527};\\\", \\\"{x:1314,y:816,t:1527264775543};\\\", \\\"{x:1311,y:822,t:1527264775561};\\\", \\\"{x:1309,y:830,t:1527264775578};\\\", \\\"{x:1301,y:843,t:1527264775594};\\\", \\\"{x:1299,y:851,t:1527264775611};\\\", \\\"{x:1292,y:866,t:1527264775628};\\\", \\\"{x:1285,y:886,t:1527264775649};\\\", \\\"{x:1281,y:900,t:1527264775664};\\\", \\\"{x:1278,y:909,t:1527264775681};\\\", \\\"{x:1276,y:911,t:1527264775698};\\\", \\\"{x:1275,y:916,t:1527264775715};\\\", \\\"{x:1275,y:927,t:1527264775731};\\\", \\\"{x:1273,y:934,t:1527264775749};\\\", \\\"{x:1272,y:945,t:1527264775765};\\\", \\\"{x:1269,y:952,t:1527264775782};\\\", \\\"{x:1268,y:958,t:1527264775799};\\\", \\\"{x:1267,y:967,t:1527264775814};\\\", \\\"{x:1265,y:971,t:1527264775833};\\\", \\\"{x:1264,y:973,t:1527264775849};\\\", \\\"{x:1263,y:974,t:1527264775865};\\\", \\\"{x:1263,y:976,t:1527264775882};\\\", \\\"{x:1261,y:978,t:1527264775900};\\\", \\\"{x:1259,y:979,t:1527264775915};\\\", \\\"{x:1258,y:980,t:1527264775931};\\\", \\\"{x:1256,y:980,t:1527264775949};\\\", \\\"{x:1254,y:981,t:1527264775965};\\\", \\\"{x:1252,y:982,t:1527264775982};\\\", \\\"{x:1251,y:982,t:1527264776073};\\\", \\\"{x:1249,y:982,t:1527264776082};\\\", \\\"{x:1246,y:982,t:1527264776098};\\\", \\\"{x:1246,y:981,t:1527264776241};\\\", \\\"{x:1246,y:980,t:1527264776248};\\\", \\\"{x:1246,y:979,t:1527264776265};\\\", \\\"{x:1246,y:978,t:1527264776282};\\\", \\\"{x:1246,y:977,t:1527264776298};\\\", \\\"{x:1246,y:976,t:1527264776315};\\\", \\\"{x:1250,y:973,t:1527264779970};\\\", \\\"{x:1251,y:972,t:1527264779993};\\\", \\\"{x:1254,y:970,t:1527264780003};\\\", \\\"{x:1264,y:965,t:1527264780020};\\\", \\\"{x:1276,y:960,t:1527264780037};\\\", \\\"{x:1282,y:957,t:1527264780052};\\\", \\\"{x:1286,y:954,t:1527264780069};\\\", \\\"{x:1290,y:950,t:1527264780087};\\\", \\\"{x:1303,y:944,t:1527264780103};\\\", \\\"{x:1321,y:935,t:1527264780119};\\\", \\\"{x:1358,y:922,t:1527264780137};\\\", \\\"{x:1376,y:917,t:1527264780153};\\\", \\\"{x:1391,y:911,t:1527264780170};\\\", \\\"{x:1401,y:909,t:1527264780187};\\\", \\\"{x:1414,y:902,t:1527264780203};\\\", \\\"{x:1419,y:896,t:1527264780220};\\\", \\\"{x:1426,y:891,t:1527264780237};\\\", \\\"{x:1440,y:884,t:1527264780253};\\\", \\\"{x:1453,y:877,t:1527264780270};\\\", \\\"{x:1464,y:867,t:1527264780287};\\\", \\\"{x:1473,y:862,t:1527264780303};\\\", \\\"{x:1481,y:857,t:1527264780320};\\\", \\\"{x:1486,y:852,t:1527264780337};\\\", \\\"{x:1487,y:851,t:1527264780354};\\\", \\\"{x:1489,y:850,t:1527264780370};\\\", \\\"{x:1490,y:849,t:1527264780401};\\\", \\\"{x:1490,y:847,t:1527264780424};\\\", \\\"{x:1491,y:848,t:1527264780561};\\\", \\\"{x:1491,y:852,t:1527264780570};\\\", \\\"{x:1491,y:855,t:1527264780587};\\\", \\\"{x:1491,y:860,t:1527264780603};\\\", \\\"{x:1491,y:867,t:1527264780620};\\\", \\\"{x:1491,y:870,t:1527264780637};\\\", \\\"{x:1493,y:874,t:1527264780654};\\\", \\\"{x:1496,y:878,t:1527264780670};\\\", \\\"{x:1497,y:882,t:1527264780687};\\\", \\\"{x:1498,y:885,t:1527264780704};\\\", \\\"{x:1498,y:888,t:1527264780721};\\\", \\\"{x:1499,y:892,t:1527264780737};\\\", \\\"{x:1500,y:894,t:1527264780754};\\\", \\\"{x:1500,y:895,t:1527264780771};\\\", \\\"{x:1502,y:898,t:1527264780787};\\\", \\\"{x:1504,y:900,t:1527264780810};\\\", \\\"{x:1507,y:904,t:1527264780821};\\\", \\\"{x:1509,y:910,t:1527264780837};\\\", \\\"{x:1516,y:916,t:1527264780853};\\\", \\\"{x:1517,y:920,t:1527264780870};\\\", \\\"{x:1519,y:922,t:1527264780887};\\\", \\\"{x:1520,y:923,t:1527264780904};\\\", \\\"{x:1522,y:926,t:1527264780921};\\\", \\\"{x:1526,y:930,t:1527264780937};\\\", \\\"{x:1531,y:935,t:1527264780954};\\\", \\\"{x:1533,y:941,t:1527264780971};\\\", \\\"{x:1536,y:945,t:1527264780988};\\\", \\\"{x:1538,y:949,t:1527264781004};\\\", \\\"{x:1539,y:951,t:1527264781021};\\\", \\\"{x:1540,y:952,t:1527264781153};\\\", \\\"{x:1541,y:952,t:1527264781457};\\\", \\\"{x:1542,y:952,t:1527264781698};\\\", \\\"{x:1544,y:952,t:1527264781705};\\\", \\\"{x:1546,y:951,t:1527264781723};\\\", \\\"{x:1548,y:950,t:1527264781738};\\\", \\\"{x:1549,y:950,t:1527264781756};\\\", \\\"{x:1550,y:949,t:1527264782018};\\\", \\\"{x:1550,y:948,t:1527264782066};\\\", \\\"{x:1550,y:944,t:1527264782073};\\\", \\\"{x:1548,y:939,t:1527264782089};\\\", \\\"{x:1548,y:933,t:1527264782105};\\\", \\\"{x:1546,y:928,t:1527264782122};\\\", \\\"{x:1544,y:924,t:1527264782139};\\\", \\\"{x:1540,y:920,t:1527264782155};\\\", \\\"{x:1538,y:919,t:1527264782177};\\\", \\\"{x:1536,y:918,t:1527264782189};\\\", \\\"{x:1533,y:914,t:1527264782207};\\\", \\\"{x:1531,y:909,t:1527264782223};\\\", \\\"{x:1529,y:909,t:1527264782239};\\\", \\\"{x:1524,y:902,t:1527264782256};\\\", \\\"{x:1520,y:892,t:1527264782272};\\\", \\\"{x:1509,y:872,t:1527264782289};\\\", \\\"{x:1502,y:859,t:1527264782306};\\\", \\\"{x:1492,y:846,t:1527264782323};\\\", \\\"{x:1487,y:834,t:1527264782339};\\\", \\\"{x:1480,y:814,t:1527264782356};\\\", \\\"{x:1474,y:805,t:1527264782372};\\\", \\\"{x:1471,y:798,t:1527264782389};\\\", \\\"{x:1466,y:791,t:1527264782405};\\\", \\\"{x:1462,y:785,t:1527264782421};\\\", \\\"{x:1458,y:779,t:1527264782438};\\\", \\\"{x:1456,y:778,t:1527264782456};\\\", \\\"{x:1455,y:776,t:1527264782472};\\\", \\\"{x:1455,y:774,t:1527264782496};\\\", \\\"{x:1455,y:775,t:1527264782674};\\\", \\\"{x:1455,y:786,t:1527264782689};\\\", \\\"{x:1457,y:799,t:1527264782705};\\\", \\\"{x:1462,y:813,t:1527264782723};\\\", \\\"{x:1469,y:825,t:1527264782739};\\\", \\\"{x:1476,y:840,t:1527264782756};\\\", \\\"{x:1482,y:851,t:1527264782773};\\\", \\\"{x:1482,y:854,t:1527264782789};\\\", \\\"{x:1482,y:855,t:1527264782806};\\\", \\\"{x:1483,y:857,t:1527264782823};\\\", \\\"{x:1483,y:860,t:1527264782840};\\\", \\\"{x:1483,y:861,t:1527264782881};\\\", \\\"{x:1485,y:861,t:1527264783018};\\\", \\\"{x:1487,y:861,t:1527264783033};\\\", \\\"{x:1487,y:860,t:1527264783041};\\\", \\\"{x:1487,y:857,t:1527264783056};\\\", \\\"{x:1487,y:854,t:1527264783073};\\\", \\\"{x:1486,y:850,t:1527264783090};\\\", \\\"{x:1484,y:847,t:1527264783113};\\\", \\\"{x:1479,y:842,t:1527264783123};\\\", \\\"{x:1470,y:832,t:1527264783140};\\\", \\\"{x:1456,y:820,t:1527264783157};\\\", \\\"{x:1453,y:815,t:1527264783172};\\\", \\\"{x:1440,y:805,t:1527264783190};\\\", \\\"{x:1429,y:799,t:1527264783208};\\\", \\\"{x:1422,y:795,t:1527264783223};\\\", \\\"{x:1421,y:794,t:1527264783240};\\\", \\\"{x:1416,y:791,t:1527264783257};\\\", \\\"{x:1414,y:791,t:1527264783274};\\\", \\\"{x:1412,y:791,t:1527264783290};\\\", \\\"{x:1410,y:789,t:1527264783307};\\\", \\\"{x:1408,y:788,t:1527264783568};\\\", \\\"{x:1403,y:786,t:1527264783576};\\\", \\\"{x:1400,y:786,t:1527264783589};\\\", \\\"{x:1388,y:784,t:1527264783606};\\\", \\\"{x:1375,y:782,t:1527264783623};\\\", \\\"{x:1364,y:780,t:1527264783639};\\\", \\\"{x:1351,y:775,t:1527264783656};\\\", \\\"{x:1347,y:774,t:1527264783673};\\\", \\\"{x:1344,y:773,t:1527264783690};\\\", \\\"{x:1342,y:771,t:1527264783707};\\\", \\\"{x:1340,y:771,t:1527264783723};\\\", \\\"{x:1338,y:770,t:1527264783740};\\\", \\\"{x:1338,y:769,t:1527264783800};\\\", \\\"{x:1338,y:768,t:1527264783816};\\\", \\\"{x:1339,y:767,t:1527264783831};\\\", \\\"{x:1339,y:765,t:1527264783848};\\\", \\\"{x:1339,y:763,t:1527264783856};\\\", \\\"{x:1342,y:759,t:1527264783874};\\\", \\\"{x:1346,y:754,t:1527264783891};\\\", \\\"{x:1350,y:749,t:1527264783906};\\\", \\\"{x:1351,y:746,t:1527264783924};\\\", \\\"{x:1353,y:742,t:1527264783940};\\\", \\\"{x:1355,y:739,t:1527264783957};\\\", \\\"{x:1356,y:736,t:1527264783973};\\\", \\\"{x:1357,y:734,t:1527264783991};\\\", \\\"{x:1359,y:732,t:1527264784006};\\\", \\\"{x:1360,y:730,t:1527264784024};\\\", \\\"{x:1362,y:727,t:1527264784040};\\\", \\\"{x:1362,y:726,t:1527264784064};\\\", \\\"{x:1364,y:724,t:1527264784074};\\\", \\\"{x:1365,y:721,t:1527264784091};\\\", \\\"{x:1366,y:719,t:1527264784108};\\\", \\\"{x:1369,y:716,t:1527264784123};\\\", \\\"{x:1370,y:713,t:1527264784141};\\\", \\\"{x:1371,y:712,t:1527264784218};\\\", \\\"{x:1372,y:711,t:1527264784224};\\\", \\\"{x:1373,y:709,t:1527264784240};\\\", \\\"{x:1374,y:709,t:1527264784257};\\\", \\\"{x:1374,y:707,t:1527264784274};\\\", \\\"{x:1376,y:705,t:1527264784291};\\\", \\\"{x:1378,y:703,t:1527264784308};\\\", \\\"{x:1380,y:699,t:1527264784324};\\\", \\\"{x:1383,y:697,t:1527264784341};\\\", \\\"{x:1385,y:694,t:1527264784357};\\\", \\\"{x:1388,y:690,t:1527264784375};\\\", \\\"{x:1390,y:687,t:1527264784391};\\\", \\\"{x:1393,y:682,t:1527264784408};\\\", \\\"{x:1396,y:680,t:1527264784424};\\\", \\\"{x:1398,y:676,t:1527264784441};\\\", \\\"{x:1400,y:675,t:1527264784458};\\\", \\\"{x:1401,y:673,t:1527264784497};\\\", \\\"{x:1402,y:672,t:1527264784508};\\\", \\\"{x:1403,y:671,t:1527264784525};\\\", \\\"{x:1403,y:669,t:1527264784542};\\\", \\\"{x:1403,y:668,t:1527264784560};\\\", \\\"{x:1405,y:666,t:1527264784633};\\\", \\\"{x:1405,y:665,t:1527264784641};\\\", \\\"{x:1405,y:664,t:1527264784658};\\\", \\\"{x:1407,y:661,t:1527264784675};\\\", \\\"{x:1407,y:660,t:1527264784692};\\\", \\\"{x:1408,y:659,t:1527264784707};\\\", \\\"{x:1409,y:659,t:1527264785522};\\\", \\\"{x:1410,y:660,t:1527264785529};\\\", \\\"{x:1410,y:661,t:1527264785569};\\\", \\\"{x:1410,y:664,t:1527264785576};\\\", \\\"{x:1411,y:667,t:1527264785593};\\\", \\\"{x:1412,y:671,t:1527264785609};\\\", \\\"{x:1413,y:673,t:1527264785626};\\\", \\\"{x:1413,y:676,t:1527264785642};\\\", \\\"{x:1414,y:677,t:1527264785659};\\\", \\\"{x:1415,y:677,t:1527264785721};\\\", \\\"{x:1416,y:677,t:1527264785728};\\\", \\\"{x:1417,y:679,t:1527264785743};\\\", \\\"{x:1418,y:680,t:1527264785759};\\\", \\\"{x:1418,y:681,t:1527264785775};\\\", \\\"{x:1419,y:683,t:1527264785792};\\\", \\\"{x:1420,y:686,t:1527264785810};\\\", \\\"{x:1421,y:689,t:1527264785826};\\\", \\\"{x:1422,y:689,t:1527264785843};\\\", \\\"{x:1422,y:691,t:1527264785859};\\\", \\\"{x:1422,y:696,t:1527264785876};\\\", \\\"{x:1423,y:701,t:1527264785894};\\\", \\\"{x:1426,y:708,t:1527264785909};\\\", \\\"{x:1427,y:712,t:1527264785926};\\\", \\\"{x:1429,y:716,t:1527264785943};\\\", \\\"{x:1429,y:719,t:1527264785959};\\\", \\\"{x:1430,y:727,t:1527264785976};\\\", \\\"{x:1435,y:739,t:1527264785994};\\\", \\\"{x:1437,y:748,t:1527264786010};\\\", \\\"{x:1441,y:757,t:1527264786027};\\\", \\\"{x:1441,y:760,t:1527264786043};\\\", \\\"{x:1442,y:761,t:1527264786061};\\\", \\\"{x:1444,y:762,t:1527264786081};\\\", \\\"{x:1445,y:763,t:1527264786093};\\\", \\\"{x:1445,y:764,t:1527264786111};\\\", \\\"{x:1445,y:765,t:1527264786129};\\\", \\\"{x:1445,y:768,t:1527264786144};\\\", \\\"{x:1446,y:774,t:1527264786161};\\\", \\\"{x:1447,y:779,t:1527264786176};\\\", \\\"{x:1449,y:784,t:1527264786193};\\\", \\\"{x:1449,y:786,t:1527264786211};\\\", \\\"{x:1450,y:788,t:1527264786226};\\\", \\\"{x:1451,y:790,t:1527264786242};\\\", \\\"{x:1452,y:791,t:1527264786259};\\\", \\\"{x:1453,y:794,t:1527264786280};\\\", \\\"{x:1454,y:796,t:1527264786304};\\\", \\\"{x:1456,y:797,t:1527264786312};\\\", \\\"{x:1456,y:798,t:1527264786327};\\\", \\\"{x:1457,y:799,t:1527264786342};\\\", \\\"{x:1458,y:800,t:1527264786360};\\\", \\\"{x:1459,y:800,t:1527264786376};\\\", \\\"{x:1460,y:801,t:1527264786393};\\\", \\\"{x:1463,y:802,t:1527264786410};\\\", \\\"{x:1466,y:804,t:1527264786427};\\\", \\\"{x:1469,y:807,t:1527264786443};\\\", \\\"{x:1471,y:808,t:1527264786460};\\\", \\\"{x:1474,y:809,t:1527264786477};\\\", \\\"{x:1475,y:810,t:1527264786493};\\\", \\\"{x:1475,y:811,t:1527264786510};\\\", \\\"{x:1475,y:812,t:1527264786537};\\\", \\\"{x:1476,y:812,t:1527264786585};\\\", \\\"{x:1476,y:813,t:1527264786601};\\\", \\\"{x:1477,y:814,t:1527264786617};\\\", \\\"{x:1477,y:816,t:1527264786657};\\\", \\\"{x:1478,y:817,t:1527264786817};\\\", \\\"{x:1479,y:817,t:1527264786840};\\\", \\\"{x:1479,y:818,t:1527264786849};\\\", \\\"{x:1479,y:819,t:1527264790665};\\\", \\\"{x:1479,y:821,t:1527264790696};\\\", \\\"{x:1479,y:823,t:1527264790817};\\\", \\\"{x:1479,y:825,t:1527264790841};\\\", \\\"{x:1479,y:826,t:1527264790848};\\\", \\\"{x:1475,y:829,t:1527264790865};\\\", \\\"{x:1472,y:830,t:1527264790881};\\\", \\\"{x:1465,y:833,t:1527264790899};\\\", \\\"{x:1460,y:834,t:1527264790915};\\\", \\\"{x:1451,y:835,t:1527264790932};\\\", \\\"{x:1440,y:837,t:1527264790948};\\\", \\\"{x:1432,y:837,t:1527264790965};\\\", \\\"{x:1427,y:837,t:1527264790982};\\\", \\\"{x:1418,y:838,t:1527264790999};\\\", \\\"{x:1405,y:839,t:1527264791016};\\\", \\\"{x:1394,y:840,t:1527264791032};\\\", \\\"{x:1379,y:841,t:1527264791049};\\\", \\\"{x:1378,y:841,t:1527264791065};\\\", \\\"{x:1376,y:841,t:1527264791083};\\\", \\\"{x:1371,y:842,t:1527264791098};\\\", \\\"{x:1370,y:843,t:1527264791121};\\\", \\\"{x:1368,y:843,t:1527264791133};\\\", \\\"{x:1366,y:843,t:1527264791152};\\\", \\\"{x:1364,y:843,t:1527264791177};\\\", \\\"{x:1357,y:842,t:1527264791185};\\\", \\\"{x:1353,y:842,t:1527264791210};\\\", \\\"{x:1350,y:842,t:1527264791217};\\\", \\\"{x:1346,y:841,t:1527264791231};\\\", \\\"{x:1344,y:841,t:1527264791248};\\\", \\\"{x:1339,y:841,t:1527264791265};\\\", \\\"{x:1337,y:841,t:1527264791281};\\\", \\\"{x:1336,y:841,t:1527264791299};\\\", \\\"{x:1335,y:841,t:1527264791315};\\\", \\\"{x:1334,y:840,t:1527264791344};\\\", \\\"{x:1330,y:838,t:1527264791352};\\\", \\\"{x:1324,y:838,t:1527264791365};\\\", \\\"{x:1316,y:837,t:1527264791382};\\\", \\\"{x:1311,y:837,t:1527264791399};\\\", \\\"{x:1298,y:835,t:1527264791415};\\\", \\\"{x:1275,y:831,t:1527264791432};\\\", \\\"{x:1261,y:830,t:1527264791448};\\\", \\\"{x:1250,y:827,t:1527264791465};\\\", \\\"{x:1245,y:822,t:1527264791482};\\\", \\\"{x:1232,y:820,t:1527264791499};\\\", \\\"{x:1222,y:819,t:1527264791515};\\\", \\\"{x:1219,y:816,t:1527264791532};\\\", \\\"{x:1211,y:815,t:1527264791549};\\\", \\\"{x:1209,y:813,t:1527264791565};\\\", \\\"{x:1208,y:812,t:1527264791582};\\\", \\\"{x:1205,y:811,t:1527264791599};\\\", \\\"{x:1201,y:810,t:1527264791616};\\\", \\\"{x:1199,y:810,t:1527264791633};\\\", \\\"{x:1195,y:809,t:1527264791649};\\\", \\\"{x:1194,y:809,t:1527264791833};\\\", \\\"{x:1193,y:809,t:1527264791865};\\\", \\\"{x:1193,y:810,t:1527264791889};\\\", \\\"{x:1193,y:811,t:1527264791900};\\\", \\\"{x:1194,y:812,t:1527264791916};\\\", \\\"{x:1194,y:813,t:1527264791933};\\\", \\\"{x:1195,y:813,t:1527264791949};\\\", \\\"{x:1195,y:814,t:1527264791966};\\\", \\\"{x:1195,y:815,t:1527264791985};\\\", \\\"{x:1195,y:816,t:1527264792011};\\\", \\\"{x:1197,y:819,t:1527264792024};\\\", \\\"{x:1199,y:819,t:1527264792049};\\\", \\\"{x:1202,y:823,t:1527264792066};\\\", \\\"{x:1204,y:826,t:1527264792084};\\\", \\\"{x:1207,y:827,t:1527264792100};\\\", \\\"{x:1209,y:829,t:1527264792117};\\\", \\\"{x:1211,y:830,t:1527264792133};\\\", \\\"{x:1213,y:831,t:1527264792149};\\\", \\\"{x:1213,y:832,t:1527264792281};\\\", \\\"{x:1214,y:832,t:1527264792337};\\\", \\\"{x:1215,y:832,t:1527264792417};\\\", \\\"{x:1216,y:832,t:1527264792561};\\\", \\\"{x:1216,y:830,t:1527264792569};\\\", \\\"{x:1216,y:826,t:1527264792583};\\\", \\\"{x:1213,y:813,t:1527264792600};\\\", \\\"{x:1210,y:805,t:1527264792616};\\\", \\\"{x:1209,y:801,t:1527264792633};\\\", \\\"{x:1208,y:796,t:1527264792650};\\\", \\\"{x:1206,y:791,t:1527264792667};\\\", \\\"{x:1206,y:786,t:1527264792683};\\\", \\\"{x:1205,y:783,t:1527264792700};\\\", \\\"{x:1205,y:781,t:1527264792717};\\\", \\\"{x:1204,y:778,t:1527264792732};\\\", \\\"{x:1202,y:776,t:1527264792750};\\\", \\\"{x:1201,y:775,t:1527264792767};\\\", \\\"{x:1198,y:774,t:1527264792783};\\\", \\\"{x:1192,y:771,t:1527264792799};\\\", \\\"{x:1191,y:769,t:1527264792816};\\\", \\\"{x:1190,y:768,t:1527264792833};\\\", \\\"{x:1190,y:764,t:1527264792849};\\\", \\\"{x:1190,y:762,t:1527264792867};\\\", \\\"{x:1190,y:759,t:1527264792912};\\\", \\\"{x:1193,y:755,t:1527264792920};\\\", \\\"{x:1196,y:750,t:1527264792934};\\\", \\\"{x:1205,y:743,t:1527264792951};\\\", \\\"{x:1209,y:736,t:1527264792967};\\\", \\\"{x:1218,y:724,t:1527264792984};\\\", \\\"{x:1222,y:720,t:1527264793000};\\\", \\\"{x:1229,y:713,t:1527264793017};\\\", \\\"{x:1233,y:707,t:1527264793034};\\\", \\\"{x:1242,y:698,t:1527264793050};\\\", \\\"{x:1256,y:687,t:1527264793067};\\\", \\\"{x:1270,y:675,t:1527264793084};\\\", \\\"{x:1280,y:665,t:1527264793100};\\\", \\\"{x:1294,y:655,t:1527264793117};\\\", \\\"{x:1305,y:646,t:1527264793135};\\\", \\\"{x:1311,y:642,t:1527264793150};\\\", \\\"{x:1316,y:637,t:1527264793167};\\\", \\\"{x:1327,y:628,t:1527264793184};\\\", \\\"{x:1333,y:622,t:1527264793200};\\\", \\\"{x:1338,y:619,t:1527264793217};\\\", \\\"{x:1340,y:618,t:1527264793234};\\\", \\\"{x:1342,y:616,t:1527264793251};\\\", \\\"{x:1349,y:611,t:1527264793267};\\\", \\\"{x:1357,y:604,t:1527264793284};\\\", \\\"{x:1363,y:598,t:1527264793301};\\\", \\\"{x:1372,y:591,t:1527264793318};\\\", \\\"{x:1378,y:585,t:1527264793334};\\\", \\\"{x:1385,y:577,t:1527264793351};\\\", \\\"{x:1391,y:571,t:1527264793367};\\\", \\\"{x:1402,y:562,t:1527264793385};\\\", \\\"{x:1408,y:557,t:1527264793401};\\\", \\\"{x:1411,y:554,t:1527264793417};\\\", \\\"{x:1418,y:549,t:1527264793434};\\\", \\\"{x:1428,y:546,t:1527264793451};\\\", \\\"{x:1433,y:545,t:1527264793467};\\\", \\\"{x:1434,y:545,t:1527264793484};\\\", \\\"{x:1434,y:549,t:1527264793945};\\\", \\\"{x:1434,y:551,t:1527264793953};\\\", \\\"{x:1430,y:559,t:1527264793968};\\\", \\\"{x:1429,y:560,t:1527264793986};\\\", \\\"{x:1423,y:567,t:1527264794002};\\\", \\\"{x:1418,y:573,t:1527264794018};\\\", \\\"{x:1414,y:576,t:1527264794036};\\\", \\\"{x:1412,y:577,t:1527264794052};\\\", \\\"{x:1411,y:579,t:1527264794068};\\\", \\\"{x:1411,y:585,t:1527264794410};\\\", \\\"{x:1411,y:593,t:1527264794419};\\\", \\\"{x:1411,y:616,t:1527264794435};\\\", \\\"{x:1410,y:637,t:1527264794452};\\\", \\\"{x:1410,y:655,t:1527264794469};\\\", \\\"{x:1409,y:675,t:1527264794485};\\\", \\\"{x:1409,y:688,t:1527264794502};\\\", \\\"{x:1409,y:691,t:1527264794519};\\\", \\\"{x:1409,y:693,t:1527264794535};\\\", \\\"{x:1407,y:696,t:1527264794552};\\\", \\\"{x:1405,y:698,t:1527264794793};\\\", \\\"{x:1404,y:699,t:1527264794803};\\\", \\\"{x:1400,y:705,t:1527264794820};\\\", \\\"{x:1394,y:713,t:1527264794836};\\\", \\\"{x:1384,y:723,t:1527264794853};\\\", \\\"{x:1375,y:732,t:1527264794870};\\\", \\\"{x:1363,y:745,t:1527264794887};\\\", \\\"{x:1351,y:756,t:1527264794903};\\\", \\\"{x:1344,y:762,t:1527264794920};\\\", \\\"{x:1338,y:766,t:1527264794938};\\\", \\\"{x:1337,y:767,t:1527264794961};\\\", \\\"{x:1337,y:765,t:1527264795096};\\\", \\\"{x:1337,y:762,t:1527264795104};\\\", \\\"{x:1340,y:757,t:1527264795118};\\\", \\\"{x:1343,y:750,t:1527264795135};\\\", \\\"{x:1345,y:746,t:1527264795153};\\\", \\\"{x:1347,y:743,t:1527264795169};\\\", \\\"{x:1348,y:742,t:1527264795186};\\\", \\\"{x:1349,y:740,t:1527264795203};\\\", \\\"{x:1349,y:739,t:1527264795219};\\\", \\\"{x:1349,y:737,t:1527264795236};\\\", \\\"{x:1349,y:736,t:1527264795253};\\\", \\\"{x:1349,y:735,t:1527264795377};\\\", \\\"{x:1351,y:733,t:1527264795387};\\\", \\\"{x:1351,y:731,t:1527264795404};\\\", \\\"{x:1352,y:725,t:1527264795420};\\\", \\\"{x:1353,y:719,t:1527264795436};\\\", \\\"{x:1356,y:714,t:1527264795453};\\\", \\\"{x:1357,y:708,t:1527264795470};\\\", \\\"{x:1357,y:703,t:1527264795486};\\\", \\\"{x:1359,y:701,t:1527264795503};\\\", \\\"{x:1360,y:699,t:1527264795520};\\\", \\\"{x:1361,y:699,t:1527264795568};\\\", \\\"{x:1361,y:698,t:1527264795576};\\\", \\\"{x:1361,y:697,t:1527264795592};\\\", \\\"{x:1362,y:697,t:1527264795825};\\\", \\\"{x:1363,y:699,t:1527264795837};\\\", \\\"{x:1365,y:703,t:1527264795854};\\\", \\\"{x:1367,y:712,t:1527264795871};\\\", \\\"{x:1370,y:721,t:1527264795887};\\\", \\\"{x:1371,y:726,t:1527264795904};\\\", \\\"{x:1373,y:730,t:1527264795920};\\\", \\\"{x:1372,y:730,t:1527264796233};\\\", \\\"{x:1371,y:730,t:1527264796256};\\\", \\\"{x:1370,y:730,t:1527264796320};\\\", \\\"{x:1368,y:730,t:1527264796344};\\\", \\\"{x:1367,y:730,t:1527264796360};\\\", \\\"{x:1366,y:730,t:1527264796371};\\\", \\\"{x:1359,y:728,t:1527264796387};\\\", \\\"{x:1357,y:728,t:1527264796404};\\\", \\\"{x:1357,y:725,t:1527264796729};\\\", \\\"{x:1357,y:724,t:1527264796739};\\\", \\\"{x:1357,y:718,t:1527264796755};\\\", \\\"{x:1357,y:708,t:1527264796771};\\\", \\\"{x:1357,y:701,t:1527264796788};\\\", \\\"{x:1359,y:694,t:1527264796805};\\\", \\\"{x:1363,y:687,t:1527264796822};\\\", \\\"{x:1365,y:681,t:1527264796839};\\\", \\\"{x:1370,y:674,t:1527264796855};\\\", \\\"{x:1373,y:667,t:1527264796872};\\\", \\\"{x:1379,y:658,t:1527264796888};\\\", \\\"{x:1383,y:653,t:1527264796904};\\\", \\\"{x:1388,y:642,t:1527264796922};\\\", \\\"{x:1393,y:634,t:1527264796939};\\\", \\\"{x:1397,y:628,t:1527264796956};\\\", \\\"{x:1402,y:620,t:1527264796971};\\\", \\\"{x:1406,y:612,t:1527264796988};\\\", \\\"{x:1410,y:605,t:1527264797005};\\\", \\\"{x:1414,y:597,t:1527264797021};\\\", \\\"{x:1416,y:590,t:1527264797038};\\\", \\\"{x:1422,y:579,t:1527264797055};\\\", \\\"{x:1423,y:574,t:1527264797071};\\\", \\\"{x:1424,y:572,t:1527264797088};\\\", \\\"{x:1424,y:571,t:1527264797112};\\\", \\\"{x:1424,y:570,t:1527264797121};\\\", \\\"{x:1423,y:570,t:1527264798249};\\\", \\\"{x:1422,y:570,t:1527264798281};\\\", \\\"{x:1420,y:571,t:1527264798289};\\\", \\\"{x:1418,y:572,t:1527264798307};\\\", \\\"{x:1417,y:573,t:1527264798324};\\\", \\\"{x:1415,y:574,t:1527264798340};\\\", \\\"{x:1413,y:575,t:1527264798473};\\\", \\\"{x:1410,y:576,t:1527264798489};\\\", \\\"{x:1408,y:577,t:1527264798507};\\\", \\\"{x:1406,y:579,t:1527264798524};\\\", \\\"{x:1396,y:579,t:1527264798541};\\\", \\\"{x:1354,y:582,t:1527264798557};\\\", \\\"{x:1296,y:576,t:1527264798574};\\\", \\\"{x:1249,y:566,t:1527264798591};\\\", \\\"{x:1144,y:550,t:1527264798606};\\\", \\\"{x:1045,y:524,t:1527264798624};\\\", \\\"{x:925,y:486,t:1527264798641};\\\", \\\"{x:859,y:465,t:1527264798657};\\\", \\\"{x:820,y:458,t:1527264798674};\\\", \\\"{x:819,y:457,t:1527264798691};\\\", \\\"{x:810,y:456,t:1527264798707};\\\", \\\"{x:799,y:456,t:1527264798723};\\\", \\\"{x:797,y:456,t:1527264798740};\\\", \\\"{x:792,y:456,t:1527264798756};\\\", \\\"{x:785,y:457,t:1527264798773};\\\", \\\"{x:784,y:458,t:1527264798790};\\\", \\\"{x:775,y:459,t:1527264798807};\\\", \\\"{x:770,y:464,t:1527264798823};\\\", \\\"{x:763,y:470,t:1527264798840};\\\", \\\"{x:757,y:475,t:1527264798864};\\\", \\\"{x:751,y:476,t:1527264798873};\\\", \\\"{x:743,y:479,t:1527264798890};\\\", \\\"{x:742,y:483,t:1527264798907};\\\", \\\"{x:737,y:484,t:1527264798923};\\\", \\\"{x:735,y:486,t:1527264798940};\\\", \\\"{x:735,y:489,t:1527264799651};\\\", \\\"{x:745,y:499,t:1527264799674};\\\", \\\"{x:774,y:515,t:1527264799698};\\\", \\\"{x:828,y:532,t:1527264799715};\\\", \\\"{x:937,y:552,t:1527264799731};\\\", \\\"{x:1063,y:562,t:1527264799749};\\\", \\\"{x:1167,y:572,t:1527264799765};\\\", \\\"{x:1273,y:574,t:1527264799781};\\\", \\\"{x:1318,y:573,t:1527264799798};\\\", \\\"{x:1335,y:571,t:1527264799815};\\\", \\\"{x:1344,y:566,t:1527264799832};\\\", \\\"{x:1344,y:563,t:1527264799896};\\\", \\\"{x:1338,y:560,t:1527264799904};\\\", \\\"{x:1338,y:558,t:1527264799915};\\\", \\\"{x:1324,y:553,t:1527264799932};\\\", \\\"{x:1313,y:550,t:1527264799948};\\\", \\\"{x:1296,y:545,t:1527264799966};\\\", \\\"{x:1277,y:543,t:1527264799983};\\\", \\\"{x:1260,y:541,t:1527264799998};\\\", \\\"{x:1246,y:540,t:1527264800015};\\\", \\\"{x:1209,y:540,t:1527264800032};\\\", \\\"{x:1185,y:540,t:1527264800049};\\\", \\\"{x:1177,y:540,t:1527264800065};\\\", \\\"{x:1166,y:538,t:1527264800083};\\\", \\\"{x:1143,y:538,t:1527264800098};\\\", \\\"{x:1128,y:536,t:1527264800115};\\\", \\\"{x:1106,y:527,t:1527264800132};\\\", \\\"{x:1087,y:525,t:1527264800149};\\\", \\\"{x:1061,y:521,t:1527264800165};\\\", \\\"{x:1043,y:514,t:1527264800183};\\\", \\\"{x:1021,y:514,t:1527264800198};\\\", \\\"{x:1007,y:514,t:1527264800215};\\\", \\\"{x:974,y:511,t:1527264800233};\\\", \\\"{x:958,y:510,t:1527264800249};\\\", \\\"{x:938,y:506,t:1527264800266};\\\", \\\"{x:933,y:506,t:1527264800282};\\\", \\\"{x:927,y:506,t:1527264800298};\\\", \\\"{x:924,y:508,t:1527264800314};\\\", \\\"{x:921,y:513,t:1527264800331};\\\", \\\"{x:917,y:519,t:1527264800348};\\\", \\\"{x:914,y:526,t:1527264800364};\\\", \\\"{x:908,y:532,t:1527264800382};\\\", \\\"{x:897,y:539,t:1527264800399};\\\", \\\"{x:890,y:547,t:1527264800415};\\\", \\\"{x:873,y:550,t:1527264800431};\\\", \\\"{x:866,y:551,t:1527264800449};\\\", \\\"{x:858,y:552,t:1527264800465};\\\", \\\"{x:855,y:552,t:1527264800482};\\\", \\\"{x:853,y:552,t:1527264800499};\\\", \\\"{x:851,y:552,t:1527264800520};\\\", \\\"{x:850,y:552,t:1527264800536};\\\", \\\"{x:849,y:552,t:1527264800552};\\\", \\\"{x:849,y:551,t:1527264800566};\\\", \\\"{x:849,y:550,t:1527264800584};\\\", \\\"{x:849,y:549,t:1527264800601};\\\", \\\"{x:849,y:548,t:1527264800615};\\\", \\\"{x:849,y:546,t:1527264800632};\\\", \\\"{x:849,y:545,t:1527264800649};\\\", \\\"{x:850,y:543,t:1527264801072};\\\", \\\"{x:850,y:542,t:1527264801083};\\\", \\\"{x:856,y:542,t:1527264801099};\\\", \\\"{x:879,y:542,t:1527264801117};\\\", \\\"{x:882,y:542,t:1527264801134};\\\", \\\"{x:893,y:545,t:1527264801149};\\\", \\\"{x:908,y:550,t:1527264801166};\\\", \\\"{x:919,y:550,t:1527264801183};\\\", \\\"{x:937,y:561,t:1527264801200};\\\", \\\"{x:1024,y:573,t:1527264801216};\\\", \\\"{x:1065,y:575,t:1527264801234};\\\", \\\"{x:1110,y:575,t:1527264801250};\\\", \\\"{x:1137,y:575,t:1527264801267};\\\", \\\"{x:1154,y:575,t:1527264801283};\\\", \\\"{x:1164,y:575,t:1527264801299};\\\", \\\"{x:1172,y:575,t:1527264801316};\\\", \\\"{x:1179,y:575,t:1527264801333};\\\", \\\"{x:1180,y:575,t:1527264801350};\\\", \\\"{x:1181,y:575,t:1527264801367};\\\", \\\"{x:1186,y:575,t:1527264801384};\\\", \\\"{x:1190,y:575,t:1527264801399};\\\", \\\"{x:1202,y:574,t:1527264801417};\\\", \\\"{x:1213,y:574,t:1527264801434};\\\", \\\"{x:1232,y:574,t:1527264801449};\\\", \\\"{x:1245,y:574,t:1527264801466};\\\", \\\"{x:1260,y:574,t:1527264801483};\\\", \\\"{x:1264,y:574,t:1527264801499};\\\", \\\"{x:1289,y:572,t:1527264801516};\\\", \\\"{x:1313,y:571,t:1527264801533};\\\", \\\"{x:1345,y:568,t:1527264801550};\\\", \\\"{x:1346,y:568,t:1527264801567};\\\", \\\"{x:1345,y:568,t:1527264801584};\\\", \\\"{x:1349,y:565,t:1527264801600};\\\", \\\"{x:1353,y:564,t:1527264801617};\\\", \\\"{x:1355,y:564,t:1527264801633};\\\", \\\"{x:1356,y:564,t:1527264802513};\\\", \\\"{x:1359,y:563,t:1527264802521};\\\", \\\"{x:1363,y:562,t:1527264802561};\\\", \\\"{x:1367,y:562,t:1527264802568};\\\", \\\"{x:1383,y:564,t:1527264802585};\\\", \\\"{x:1391,y:567,t:1527264802601};\\\", \\\"{x:1400,y:569,t:1527264802617};\\\", \\\"{x:1404,y:571,t:1527264802635};\\\", \\\"{x:1405,y:571,t:1527264802920};\\\", \\\"{x:1406,y:571,t:1527264802934};\\\", \\\"{x:1407,y:571,t:1527264802952};\\\", \\\"{x:1406,y:571,t:1527264817425};\\\", \\\"{x:1399,y:571,t:1527264817433};\\\", \\\"{x:1395,y:571,t:1527264817446};\\\", \\\"{x:1385,y:571,t:1527264817462};\\\", \\\"{x:1382,y:571,t:1527264817479};\\\", \\\"{x:1365,y:571,t:1527264817496};\\\", \\\"{x:1306,y:568,t:1527264817512};\\\", \\\"{x:1247,y:568,t:1527264817529};\\\", \\\"{x:1188,y:568,t:1527264817546};\\\", \\\"{x:1113,y:568,t:1527264817562};\\\", \\\"{x:1076,y:568,t:1527264817578};\\\", \\\"{x:1052,y:571,t:1527264817596};\\\", \\\"{x:1019,y:576,t:1527264817613};\\\", \\\"{x:997,y:582,t:1527264817628};\\\", \\\"{x:993,y:585,t:1527264817646};\\\", \\\"{x:989,y:586,t:1527264817663};\\\", \\\"{x:940,y:601,t:1527264817681};\\\", \\\"{x:902,y:618,t:1527264817695};\\\", \\\"{x:830,y:642,t:1527264817712};\\\", \\\"{x:790,y:663,t:1527264817730};\\\", \\\"{x:775,y:675,t:1527264817745};\\\", \\\"{x:764,y:688,t:1527264817762};\\\", \\\"{x:756,y:701,t:1527264817780};\\\", \\\"{x:749,y:713,t:1527264817795};\\\", \\\"{x:740,y:726,t:1527264817813};\\\", \\\"{x:727,y:740,t:1527264817830};\\\", \\\"{x:720,y:747,t:1527264817846};\\\", \\\"{x:702,y:758,t:1527264817863};\\\", \\\"{x:675,y:777,t:1527264817879};\\\", \\\"{x:654,y:787,t:1527264817895};\\\", \\\"{x:635,y:796,t:1527264817913};\\\", \\\"{x:621,y:799,t:1527264817929};\\\", \\\"{x:607,y:802,t:1527264817946};\\\", \\\"{x:600,y:802,t:1527264817963};\\\", \\\"{x:597,y:802,t:1527264817980};\\\", \\\"{x:595,y:801,t:1527264818040};\\\", \\\"{x:591,y:799,t:1527264818048};\\\", \\\"{x:588,y:797,t:1527264818063};\\\", \\\"{x:584,y:791,t:1527264818080};\\\", \\\"{x:574,y:786,t:1527264818097};\\\", \\\"{x:568,y:781,t:1527264818113};\\\", \\\"{x:555,y:776,t:1527264818130};\\\", \\\"{x:546,y:770,t:1527264818147};\\\", \\\"{x:532,y:761,t:1527264818163};\\\", \\\"{x:521,y:756,t:1527264818180};\\\", \\\"{x:519,y:750,t:1527264818197};\\\", \\\"{x:513,y:750,t:1527264818212};\\\", \\\"{x:505,y:746,t:1527264818229};\\\", \\\"{x:504,y:745,t:1527264818247};\\\", \\\"{x:503,y:745,t:1527264818320};\\\", \\\"{x:501,y:742,t:1527264818330};\\\", \\\"{x:501,y:739,t:1527264818347};\\\", \\\"{x:502,y:737,t:1527264818364};\\\" ] }, { \\\"rt\\\": 42751, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 13, \\\"time_elapsed\\\": 446467, \\\"internal_node_id\\\": \\\"0.0-6.0-3.0\\\", \\\"subject\\\": \\\"RV9F6\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"lima\\\", \\\"condition\\\": \\\"115\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"starttime+before+endtime+during\\\", \\\"q\\\": 9, \\\"clicks\\\": 3, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XFull-YFull\\\", \\\"correct\\\": 1, \\\"orth_correct\\\": 1, \\\"answer\\\": [ \\\"I\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"\\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:503,y:736,t:1527264820592};\\\", \\\"{x:506,y:735,t:1527264823199};\\\", \\\"{x:508,y:735,t:1527264823208};\\\", \\\"{x:509,y:735,t:1527264823217};\\\", \\\"{x:523,y:732,t:1527264823233};\\\", \\\"{x:526,y:730,t:1527264823251};\\\", \\\"{x:538,y:727,t:1527264823267};\\\", \\\"{x:558,y:727,t:1527264823284};\\\", \\\"{x:580,y:726,t:1527264823301};\\\", \\\"{x:595,y:726,t:1527264823316};\\\", \\\"{x:613,y:726,t:1527264823333};\\\", \\\"{x:626,y:726,t:1527264823350};\\\", \\\"{x:631,y:726,t:1527264823367};\\\", \\\"{x:632,y:726,t:1527264823407};\\\", \\\"{x:634,y:726,t:1527264826585};\\\", \\\"{x:638,y:726,t:1527264826600};\\\", \\\"{x:639,y:724,t:1527264826608};\\\", \\\"{x:641,y:723,t:1527264826620};\\\", \\\"{x:643,y:722,t:1527264826637};\\\", \\\"{x:646,y:719,t:1527264826653};\\\", \\\"{x:658,y:714,t:1527264826670};\\\", \\\"{x:670,y:710,t:1527264826686};\\\", \\\"{x:678,y:709,t:1527264826704};\\\", \\\"{x:679,y:709,t:1527264826783};\\\", \\\"{x:679,y:707,t:1527264827689};\\\", \\\"{x:679,y:706,t:1527264827704};\\\", \\\"{x:679,y:705,t:1527264827721};\\\", \\\"{x:678,y:703,t:1527264827737};\\\", \\\"{x:678,y:701,t:1527264827848};\\\", \\\"{x:675,y:698,t:1527264827856};\\\", \\\"{x:668,y:693,t:1527264827871};\\\", \\\"{x:644,y:668,t:1527264827888};\\\", \\\"{x:633,y:652,t:1527264827903};\\\", \\\"{x:622,y:644,t:1527264827920};\\\", \\\"{x:613,y:637,t:1527264827937};\\\", \\\"{x:605,y:631,t:1527264827956};\\\", \\\"{x:584,y:619,t:1527264827970};\\\", \\\"{x:546,y:592,t:1527264827987};\\\", \\\"{x:480,y:552,t:1527264828005};\\\", \\\"{x:455,y:539,t:1527264828021};\\\", \\\"{x:436,y:523,t:1527264828037};\\\", \\\"{x:417,y:510,t:1527264828054};\\\", \\\"{x:416,y:507,t:1527264828071};\\\", \\\"{x:415,y:506,t:1527264828111};\\\", \\\"{x:414,y:504,t:1527264828121};\\\", \\\"{x:412,y:503,t:1527264828137};\\\", \\\"{x:411,y:502,t:1527264828154};\\\", \\\"{x:410,y:502,t:1527264828248};\\\", \\\"{x:409,y:502,t:1527264828263};\\\", \\\"{x:408,y:503,t:1527264828296};\\\", \\\"{x:407,y:504,t:1527264828312};\\\", \\\"{x:418,y:505,t:1527264834850};\\\", \\\"{x:435,y:506,t:1527264834860};\\\", \\\"{x:462,y:508,t:1527264834876};\\\", \\\"{x:524,y:516,t:1527264834894};\\\", \\\"{x:605,y:518,t:1527264834910};\\\", \\\"{x:674,y:525,t:1527264834927};\\\", \\\"{x:764,y:535,t:1527264834943};\\\", \\\"{x:818,y:536,t:1527264834960};\\\", \\\"{x:898,y:545,t:1527264834976};\\\", \\\"{x:984,y:561,t:1527264834994};\\\", \\\"{x:1048,y:571,t:1527264835010};\\\", \\\"{x:1123,y:588,t:1527264835026};\\\", \\\"{x:1175,y:599,t:1527264835043};\\\", \\\"{x:1256,y:614,t:1527264835060};\\\", \\\"{x:1337,y:627,t:1527264835076};\\\", \\\"{x:1377,y:636,t:1527264835093};\\\", \\\"{x:1416,y:647,t:1527264835111};\\\", \\\"{x:1451,y:656,t:1527264835126};\\\", \\\"{x:1486,y:668,t:1527264835143};\\\", \\\"{x:1511,y:676,t:1527264835160};\\\", \\\"{x:1522,y:682,t:1527264835176};\\\", \\\"{x:1528,y:685,t:1527264835193};\\\", \\\"{x:1535,y:687,t:1527264835210};\\\", \\\"{x:1545,y:691,t:1527264835228};\\\", \\\"{x:1546,y:692,t:1527264835243};\\\", \\\"{x:1551,y:695,t:1527264835260};\\\", \\\"{x:1554,y:697,t:1527264835278};\\\", \\\"{x:1556,y:698,t:1527264835294};\\\", \\\"{x:1556,y:699,t:1527264835326};\\\", \\\"{x:1557,y:699,t:1527264836140};\\\", \\\"{x:1557,y:700,t:1527264836212};\\\", \\\"{x:1557,y:701,t:1527264836220};\\\", \\\"{x:1557,y:702,t:1527264836276};\\\", \\\"{x:1557,y:703,t:1527264836291};\\\", \\\"{x:1557,y:704,t:1527264836299};\\\", \\\"{x:1557,y:705,t:1527264836315};\\\", \\\"{x:1557,y:706,t:1527264836355};\\\", \\\"{x:1557,y:707,t:1527264836365};\\\", \\\"{x:1558,y:708,t:1527264836383};\\\", \\\"{x:1558,y:709,t:1527264836399};\\\", \\\"{x:1558,y:713,t:1527264836416};\\\", \\\"{x:1558,y:715,t:1527264836451};\\\", \\\"{x:1558,y:716,t:1527264846060};\\\", \\\"{x:1558,y:717,t:1527264846140};\\\", \\\"{x:1558,y:714,t:1527264852213};\\\", \\\"{x:1558,y:707,t:1527264852220};\\\", \\\"{x:1551,y:690,t:1527264852237};\\\", \\\"{x:1548,y:678,t:1527264852254};\\\", \\\"{x:1544,y:671,t:1527264852270};\\\", \\\"{x:1544,y:665,t:1527264852286};\\\", \\\"{x:1544,y:663,t:1527264852304};\\\", \\\"{x:1544,y:661,t:1527264852320};\\\", \\\"{x:1546,y:660,t:1527264852337};\\\", \\\"{x:1555,y:655,t:1527264852354};\\\", \\\"{x:1567,y:652,t:1527264852370};\\\", \\\"{x:1579,y:652,t:1527264852387};\\\", \\\"{x:1585,y:652,t:1527264852404};\\\", \\\"{x:1589,y:656,t:1527264852419};\\\", \\\"{x:1593,y:659,t:1527264852437};\\\", \\\"{x:1594,y:664,t:1527264852453};\\\", \\\"{x:1593,y:669,t:1527264852471};\\\", \\\"{x:1589,y:672,t:1527264852486};\\\", \\\"{x:1580,y:676,t:1527264852504};\\\", \\\"{x:1575,y:679,t:1527264852521};\\\", \\\"{x:1565,y:681,t:1527264852537};\\\", \\\"{x:1563,y:681,t:1527264852554};\\\", \\\"{x:1531,y:676,t:1527264852571};\\\", \\\"{x:1464,y:668,t:1527264852587};\\\", \\\"{x:1315,y:642,t:1527264852603};\\\", \\\"{x:1195,y:626,t:1527264852620};\\\", \\\"{x:1112,y:612,t:1527264852636};\\\", \\\"{x:995,y:592,t:1527264852653};\\\", \\\"{x:917,y:581,t:1527264852672};\\\", \\\"{x:863,y:569,t:1527264852688};\\\", \\\"{x:813,y:557,t:1527264852704};\\\", \\\"{x:624,y:533,t:1527264852729};\\\", \\\"{x:550,y:519,t:1527264852746};\\\", \\\"{x:530,y:513,t:1527264852761};\\\", \\\"{x:520,y:510,t:1527264852778};\\\", \\\"{x:519,y:510,t:1527264852795};\\\", \\\"{x:519,y:509,t:1527264852818};\\\", \\\"{x:517,y:509,t:1527264853004};\\\", \\\"{x:515,y:509,t:1527264853068};\\\", \\\"{x:515,y:510,t:1527264853080};\\\", \\\"{x:513,y:510,t:1527264853096};\\\", \\\"{x:512,y:510,t:1527264853112};\\\", \\\"{x:508,y:513,t:1527264853129};\\\", \\\"{x:507,y:514,t:1527264853146};\\\", \\\"{x:506,y:514,t:1527264853162};\\\", \\\"{x:504,y:516,t:1527264853180};\\\", \\\"{x:501,y:516,t:1527264853196};\\\", \\\"{x:496,y:516,t:1527264853213};\\\", \\\"{x:493,y:516,t:1527264853229};\\\", \\\"{x:487,y:516,t:1527264853245};\\\", \\\"{x:482,y:516,t:1527264853261};\\\", \\\"{x:472,y:516,t:1527264853278};\\\", \\\"{x:469,y:515,t:1527264853295};\\\", \\\"{x:464,y:515,t:1527264853311};\\\", \\\"{x:463,y:515,t:1527264853328};\\\", \\\"{x:462,y:514,t:1527264853345};\\\", \\\"{x:461,y:513,t:1527264853468};\\\", \\\"{x:456,y:513,t:1527264853499};\\\", \\\"{x:450,y:513,t:1527264853512};\\\", \\\"{x:445,y:513,t:1527264853529};\\\", \\\"{x:431,y:512,t:1527264853546};\\\", \\\"{x:418,y:512,t:1527264853562};\\\", \\\"{x:417,y:511,t:1527264853587};\\\", \\\"{x:417,y:510,t:1527264853595};\\\", \\\"{x:417,y:509,t:1527264853611};\\\", \\\"{x:416,y:508,t:1527264853629};\\\", \\\"{x:415,y:506,t:1527264853660};\\\", \\\"{x:413,y:505,t:1527264853820};\\\", \\\"{x:412,y:505,t:1527264853835};\\\", \\\"{x:411,y:504,t:1527264853846};\\\", \\\"{x:410,y:504,t:1527264853863};\\\", \\\"{x:408,y:503,t:1527264853879};\\\", \\\"{x:406,y:503,t:1527264854043};\\\", \\\"{x:405,y:503,t:1527264854051};\\\", \\\"{x:404,y:504,t:1527264854062};\\\", \\\"{x:401,y:507,t:1527264854080};\\\", \\\"{x:398,y:509,t:1527264854096};\\\", \\\"{x:396,y:509,t:1527264854113};\\\", \\\"{x:395,y:510,t:1527264854130};\\\", \\\"{x:394,y:510,t:1527264854348};\\\", \\\"{x:392,y:510,t:1527264854364};\\\", \\\"{x:390,y:512,t:1527264854683};\\\", \\\"{x:388,y:513,t:1527264854696};\\\", \\\"{x:383,y:513,t:1527264854713};\\\", \\\"{x:361,y:513,t:1527264854731};\\\", \\\"{x:334,y:513,t:1527264854746};\\\", \\\"{x:324,y:513,t:1527264854762};\\\", \\\"{x:322,y:506,t:1527264854780};\\\", \\\"{x:322,y:503,t:1527264854796};\\\", \\\"{x:322,y:500,t:1527264854813};\\\", \\\"{x:320,y:499,t:1527264854830};\\\", \\\"{x:319,y:499,t:1527264854846};\\\", \\\"{x:319,y:498,t:1527264854948};\\\", \\\"{x:317,y:496,t:1527264854964};\\\", \\\"{x:310,y:490,t:1527264854980};\\\", \\\"{x:300,y:490,t:1527264854997};\\\", \\\"{x:279,y:489,t:1527264855014};\\\", \\\"{x:279,y:488,t:1527264855030};\\\", \\\"{x:278,y:487,t:1527264855276};\\\", \\\"{x:276,y:487,t:1527264855284};\\\", \\\"{x:272,y:488,t:1527264855300};\\\", \\\"{x:267,y:489,t:1527264855313};\\\", \\\"{x:259,y:493,t:1527264855331};\\\", \\\"{x:243,y:494,t:1527264855347};\\\", \\\"{x:232,y:494,t:1527264855363};\\\", \\\"{x:225,y:494,t:1527264855379};\\\", \\\"{x:213,y:494,t:1527264855397};\\\", \\\"{x:198,y:494,t:1527264855413};\\\", \\\"{x:192,y:494,t:1527264855430};\\\", \\\"{x:180,y:494,t:1527264855448};\\\", \\\"{x:175,y:493,t:1527264855464};\\\", \\\"{x:173,y:493,t:1527264855481};\\\", \\\"{x:170,y:493,t:1527264855497};\\\", \\\"{x:169,y:493,t:1527264855595};\\\", \\\"{x:169,y:494,t:1527264855627};\\\", \\\"{x:168,y:494,t:1527264855635};\\\", \\\"{x:168,y:495,t:1527264858818};\\\", \\\"{x:168,y:500,t:1527264858833};\\\", \\\"{x:172,y:509,t:1527264858849};\\\", \\\"{x:183,y:524,t:1527264858867};\\\", \\\"{x:186,y:528,t:1527264858884};\\\", \\\"{x:196,y:538,t:1527264858900};\\\", \\\"{x:203,y:544,t:1527264858916};\\\", \\\"{x:204,y:544,t:1527264858932};\\\", \\\"{x:207,y:544,t:1527264858949};\\\", \\\"{x:211,y:544,t:1527264858966};\\\", \\\"{x:213,y:546,t:1527264858982};\\\", \\\"{x:223,y:553,t:1527264858999};\\\", \\\"{x:229,y:558,t:1527264859017};\\\", \\\"{x:238,y:563,t:1527264859033};\\\", \\\"{x:238,y:566,t:1527264859051};\\\", \\\"{x:239,y:567,t:1527264859066};\\\", \\\"{x:260,y:575,t:1527264859083};\\\", \\\"{x:260,y:576,t:1527264859100};\\\", \\\"{x:269,y:579,t:1527264859116};\\\", \\\"{x:282,y:585,t:1527264859133};\\\", \\\"{x:291,y:595,t:1527264859151};\\\", \\\"{x:306,y:607,t:1527264859168};\\\", \\\"{x:313,y:616,t:1527264859183};\\\", \\\"{x:323,y:624,t:1527264859200};\\\", \\\"{x:330,y:630,t:1527264859217};\\\", \\\"{x:343,y:641,t:1527264859233};\\\", \\\"{x:362,y:657,t:1527264859250};\\\", \\\"{x:372,y:666,t:1527264859266};\\\", \\\"{x:377,y:671,t:1527264859283};\\\", \\\"{x:378,y:672,t:1527264859314};\\\", \\\"{x:380,y:674,t:1527264859322};\\\", \\\"{x:382,y:676,t:1527264859333};\\\", \\\"{x:382,y:677,t:1527264859354};\\\", \\\"{x:384,y:679,t:1527264859367};\\\", \\\"{x:387,y:685,t:1527264859384};\\\", \\\"{x:389,y:686,t:1527264859401};\\\", \\\"{x:390,y:687,t:1527264859418};\\\", \\\"{x:394,y:690,t:1527264859433};\\\", \\\"{x:412,y:706,t:1527264859450};\\\", \\\"{x:421,y:712,t:1527264859467};\\\", \\\"{x:431,y:719,t:1527264859483};\\\", \\\"{x:441,y:725,t:1527264859500};\\\", \\\"{x:455,y:731,t:1527264859518};\\\", \\\"{x:464,y:735,t:1527264859533};\\\", \\\"{x:465,y:738,t:1527264859550};\\\", \\\"{x:469,y:740,t:1527264859567};\\\" ] }, { \\\"rt\\\": 10814, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 14, \\\"time_elapsed\\\": 458589, \\\"internal_node_id\\\": \\\"0.0-6.0-4.0\\\", \\\"subject\\\": \\\"RV9F6\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"lima\\\", \\\"condition\\\": \\\"115\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"ends\\\", \\\"q\\\": 10, \\\"clicks\\\": 1, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XFull-YFull\\\", \\\"correct\\\": 1, \\\"orth_correct\\\": 0, \\\"answer\\\": [ \\\"E\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"\\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:470,y:740,t:1527264868994};\\\", \\\"{x:471,y:739,t:1527264869009};\\\", \\\"{x:475,y:737,t:1527264869025};\\\", \\\"{x:476,y:735,t:1527264869041};\\\", \\\"{x:482,y:731,t:1527264869059};\\\", \\\"{x:486,y:730,t:1527264869074};\\\", \\\"{x:489,y:728,t:1527264869092};\\\", \\\"{x:490,y:727,t:1527264869130};\\\", \\\"{x:490,y:725,t:1527264869276};\\\", \\\"{x:490,y:724,t:1527264869292};\\\", \\\"{x:493,y:721,t:1527264869309};\\\", \\\"{x:495,y:721,t:1527264869325};\\\", \\\"{x:497,y:720,t:1527264869342};\\\", \\\"{x:505,y:712,t:1527264869360};\\\", \\\"{x:515,y:700,t:1527264869375};\\\", \\\"{x:521,y:690,t:1527264869392};\\\", \\\"{x:524,y:687,t:1527264869407};\\\", \\\"{x:528,y:680,t:1527264869425};\\\", \\\"{x:536,y:663,t:1527264869442};\\\", \\\"{x:540,y:652,t:1527264869457};\\\", \\\"{x:548,y:641,t:1527264869474};\\\", \\\"{x:554,y:631,t:1527264869492};\\\", \\\"{x:558,y:621,t:1527264869508};\\\", \\\"{x:562,y:608,t:1527264869525};\\\", \\\"{x:566,y:593,t:1527264869543};\\\", \\\"{x:574,y:575,t:1527264869559};\\\", \\\"{x:581,y:554,t:1527264869575};\\\", \\\"{x:590,y:534,t:1527264869591};\\\", \\\"{x:602,y:513,t:1527264869609};\\\", \\\"{x:621,y:493,t:1527264869625};\\\", \\\"{x:630,y:486,t:1527264869642};\\\", \\\"{x:655,y:460,t:1527264869658};\\\", \\\"{x:660,y:453,t:1527264869675};\\\", \\\"{x:661,y:453,t:1527264869691};\\\", \\\"{x:660,y:454,t:1527264869860};\\\", \\\"{x:655,y:461,t:1527264869875};\\\", \\\"{x:640,y:471,t:1527264869893};\\\", \\\"{x:632,y:476,t:1527264869909};\\\", \\\"{x:629,y:478,t:1527264869926};\\\", \\\"{x:624,y:481,t:1527264869942};\\\", \\\"{x:621,y:484,t:1527264869959};\\\", \\\"{x:619,y:485,t:1527264869976};\\\", \\\"{x:617,y:486,t:1527264869995};\\\", \\\"{x:617,y:487,t:1527264870011};\\\", \\\"{x:616,y:490,t:1527264870026};\\\", \\\"{x:614,y:492,t:1527264870042};\\\", \\\"{x:612,y:494,t:1527264870057};\\\", \\\"{x:612,y:495,t:1527264870162};\\\", \\\"{x:610,y:497,t:1527264870175};\\\", \\\"{x:609,y:499,t:1527264870191};\\\", \\\"{x:607,y:502,t:1527264870207};\\\", \\\"{x:607,y:503,t:1527264870225};\\\", \\\"{x:607,y:504,t:1527264870418};\\\", \\\"{x:607,y:504,t:1527264870505};\\\", \\\"{x:606,y:505,t:1527264873156};\\\", \\\"{x:605,y:507,t:1527264873660};\\\", \\\"{x:603,y:509,t:1527264873667};\\\", \\\"{x:599,y:512,t:1527264873681};\\\", \\\"{x:599,y:515,t:1527264873694};\\\", \\\"{x:593,y:533,t:1527264873712};\\\", \\\"{x:588,y:551,t:1527264873727};\\\", \\\"{x:585,y:561,t:1527264873745};\\\", \\\"{x:583,y:572,t:1527264873761};\\\", \\\"{x:580,y:582,t:1527264873777};\\\", \\\"{x:578,y:588,t:1527264873795};\\\", \\\"{x:576,y:596,t:1527264873812};\\\", \\\"{x:574,y:600,t:1527264873829};\\\", \\\"{x:572,y:603,t:1527264873846};\\\", \\\"{x:571,y:603,t:1527264873874};\\\", \\\"{x:571,y:606,t:1527264873882};\\\", \\\"{x:571,y:607,t:1527264873895};\\\", \\\"{x:564,y:618,t:1527264873911};\\\", \\\"{x:562,y:623,t:1527264873929};\\\", \\\"{x:557,y:640,t:1527264873945};\\\", \\\"{x:552,y:652,t:1527264873962};\\\", \\\"{x:549,y:660,t:1527264873978};\\\", \\\"{x:548,y:666,t:1527264873995};\\\", \\\"{x:548,y:670,t:1527264874011};\\\", \\\"{x:546,y:671,t:1527264874029};\\\", \\\"{x:544,y:674,t:1527264874045};\\\", \\\"{x:540,y:681,t:1527264874062};\\\", \\\"{x:535,y:687,t:1527264874079};\\\", \\\"{x:531,y:692,t:1527264874095};\\\", \\\"{x:531,y:696,t:1527264874112};\\\", \\\"{x:528,y:700,t:1527264874129};\\\", \\\"{x:526,y:703,t:1527264874145};\\\", \\\"{x:526,y:706,t:1527264874162};\\\", \\\"{x:526,y:712,t:1527264874179};\\\", \\\"{x:526,y:713,t:1527264874243};\\\", \\\"{x:526,y:715,t:1527264874251};\\\", \\\"{x:526,y:716,t:1527264874262};\\\", \\\"{x:525,y:718,t:1527264874280};\\\", \\\"{x:524,y:719,t:1527264874540};\\\", \\\"{x:522,y:721,t:1527264874556};\\\", \\\"{x:522,y:724,t:1527264874563};\\\", \\\"{x:520,y:726,t:1527264874579};\\\", \\\"{x:519,y:728,t:1527264874602};\\\", \\\"{x:518,y:729,t:1527264874666};\\\" ] }, { \\\"rt\\\": 13615, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 15, \\\"time_elapsed\\\": 473419, \\\"internal_node_id\\\": \\\"0.0-6.0-5.0\\\", \\\"subject\\\": \\\"RV9F6\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"lima\\\", \\\"condition\\\": \\\"115\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"starttime\\\", \\\"q\\\": 11, \\\"clicks\\\": 2, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XFull-YFull\\\", \\\"correct\\\": 1, \\\"orth_correct\\\": 0, \\\"answer\\\": [ \\\"M\\\", \\\"L\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-M \\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:520,y:728,t:1527264877579};\\\", \\\"{x:525,y:725,t:1527264877609};\\\", \\\"{x:526,y:723,t:1527264877615};\\\", \\\"{x:527,y:722,t:1527264877631};\\\", \\\"{x:531,y:717,t:1527264877648};\\\", \\\"{x:532,y:716,t:1527264877665};\\\", \\\"{x:537,y:711,t:1527264877682};\\\", \\\"{x:543,y:704,t:1527264877698};\\\", \\\"{x:548,y:700,t:1527264877715};\\\", \\\"{x:552,y:695,t:1527264877731};\\\", \\\"{x:557,y:692,t:1527264877748};\\\", \\\"{x:566,y:685,t:1527264877765};\\\", \\\"{x:574,y:679,t:1527264877782};\\\", \\\"{x:587,y:669,t:1527264877798};\\\", \\\"{x:598,y:662,t:1527264877815};\\\", \\\"{x:615,y:650,t:1527264877832};\\\", \\\"{x:633,y:639,t:1527264877848};\\\", \\\"{x:650,y:625,t:1527264877866};\\\", \\\"{x:660,y:616,t:1527264877882};\\\", \\\"{x:676,y:608,t:1527264877898};\\\", \\\"{x:690,y:599,t:1527264877915};\\\", \\\"{x:711,y:592,t:1527264877932};\\\", \\\"{x:729,y:587,t:1527264877949};\\\", \\\"{x:741,y:585,t:1527264877965};\\\", \\\"{x:786,y:581,t:1527264877982};\\\", \\\"{x:877,y:586,t:1527264877999};\\\", \\\"{x:986,y:592,t:1527264878016};\\\", \\\"{x:1052,y:592,t:1527264878032};\\\", \\\"{x:1145,y:600,t:1527264878049};\\\", \\\"{x:1165,y:600,t:1527264878065};\\\", \\\"{x:1254,y:598,t:1527264878082};\\\", \\\"{x:1359,y:598,t:1527264878099};\\\", \\\"{x:1453,y:598,t:1527264878115};\\\", \\\"{x:1526,y:597,t:1527264878132};\\\", \\\"{x:1556,y:597,t:1527264878149};\\\", \\\"{x:1560,y:595,t:1527264878165};\\\", \\\"{x:1561,y:595,t:1527264878182};\\\", \\\"{x:1558,y:600,t:1527264879932};\\\", \\\"{x:1554,y:606,t:1527264879939};\\\", \\\"{x:1553,y:615,t:1527264879951};\\\", \\\"{x:1545,y:631,t:1527264879967};\\\", \\\"{x:1538,y:641,t:1527264879983};\\\", \\\"{x:1520,y:664,t:1527264880001};\\\", \\\"{x:1504,y:681,t:1527264880017};\\\", \\\"{x:1487,y:698,t:1527264880033};\\\", \\\"{x:1473,y:713,t:1527264880051};\\\", \\\"{x:1465,y:722,t:1527264880067};\\\", \\\"{x:1461,y:728,t:1527264880083};\\\", \\\"{x:1455,y:740,t:1527264880101};\\\", \\\"{x:1446,y:750,t:1527264880117};\\\", \\\"{x:1443,y:759,t:1527264880133};\\\", \\\"{x:1439,y:772,t:1527264880151};\\\", \\\"{x:1433,y:781,t:1527264880167};\\\", \\\"{x:1428,y:790,t:1527264880184};\\\", \\\"{x:1426,y:794,t:1527264880201};\\\", \\\"{x:1419,y:805,t:1527264880217};\\\", \\\"{x:1406,y:825,t:1527264880234};\\\", \\\"{x:1398,y:836,t:1527264880250};\\\", \\\"{x:1393,y:844,t:1527264880267};\\\", \\\"{x:1388,y:849,t:1527264880284};\\\", \\\"{x:1387,y:855,t:1527264880300};\\\", \\\"{x:1382,y:859,t:1527264880317};\\\", \\\"{x:1382,y:860,t:1527264880334};\\\", \\\"{x:1382,y:861,t:1527264880875};\\\", \\\"{x:1381,y:863,t:1527264880885};\\\", \\\"{x:1381,y:864,t:1527264880901};\\\", \\\"{x:1380,y:864,t:1527264880917};\\\", \\\"{x:1379,y:867,t:1527264881483};\\\", \\\"{x:1379,y:872,t:1527264881491};\\\", \\\"{x:1377,y:876,t:1527264881501};\\\", \\\"{x:1376,y:881,t:1527264881519};\\\", \\\"{x:1376,y:884,t:1527264881535};\\\", \\\"{x:1376,y:887,t:1527264881551};\\\", \\\"{x:1376,y:889,t:1527264881568};\\\", \\\"{x:1375,y:891,t:1527264881586};\\\", \\\"{x:1375,y:893,t:1527264881602};\\\", \\\"{x:1374,y:894,t:1527264881618};\\\", \\\"{x:1357,y:884,t:1527264884091};\\\", \\\"{x:1287,y:853,t:1527264884104};\\\", \\\"{x:1134,y:775,t:1527264884119};\\\", \\\"{x:1019,y:706,t:1527264884137};\\\", \\\"{x:892,y:625,t:1527264884154};\\\", \\\"{x:669,y:518,t:1527264884171};\\\", \\\"{x:550,y:460,t:1527264884186};\\\", \\\"{x:527,y:453,t:1527264884200};\\\", \\\"{x:502,y:437,t:1527264884217};\\\", \\\"{x:492,y:424,t:1527264884233};\\\", \\\"{x:485,y:419,t:1527264884251};\\\", \\\"{x:485,y:417,t:1527264884306};\\\", \\\"{x:485,y:420,t:1527264884427};\\\", \\\"{x:490,y:430,t:1527264884434};\\\", \\\"{x:509,y:449,t:1527264884451};\\\", \\\"{x:524,y:462,t:1527264884467};\\\", \\\"{x:537,y:476,t:1527264884484};\\\", \\\"{x:541,y:483,t:1527264884501};\\\", \\\"{x:541,y:484,t:1527264884987};\\\", \\\"{x:540,y:489,t:1527264885002};\\\", \\\"{x:531,y:497,t:1527264885016};\\\", \\\"{x:517,y:511,t:1527264885037};\\\", \\\"{x:511,y:516,t:1527264885054};\\\", \\\"{x:508,y:517,t:1527264885071};\\\", \\\"{x:503,y:526,t:1527264885087};\\\", \\\"{x:490,y:537,t:1527264885105};\\\", \\\"{x:477,y:547,t:1527264885121};\\\", \\\"{x:469,y:554,t:1527264885137};\\\", \\\"{x:457,y:564,t:1527264885155};\\\", \\\"{x:456,y:565,t:1527264885298};\\\", \\\"{x:451,y:565,t:1527264885306};\\\", \\\"{x:448,y:565,t:1527264885322};\\\", \\\"{x:446,y:564,t:1527264885346};\\\", \\\"{x:443,y:563,t:1527264885354};\\\", \\\"{x:442,y:562,t:1527264885371};\\\", \\\"{x:441,y:562,t:1527264885421};\\\", \\\"{x:440,y:562,t:1527264885438};\\\", \\\"{x:440,y:561,t:1527264885454};\\\", \\\"{x:440,y:560,t:1527264885472};\\\", \\\"{x:440,y:559,t:1527264885488};\\\", \\\"{x:439,y:556,t:1527264885595};\\\", \\\"{x:438,y:555,t:1527264885605};\\\", \\\"{x:436,y:552,t:1527264885621};\\\", \\\"{x:436,y:551,t:1527264885650};\\\", \\\"{x:436,y:549,t:1527264885658};\\\", \\\"{x:436,y:548,t:1527264885671};\\\", \\\"{x:431,y:545,t:1527264885688};\\\", \\\"{x:431,y:544,t:1527264885705};\\\", \\\"{x:431,y:542,t:1527264885721};\\\", \\\"{x:426,y:539,t:1527264885738};\\\", \\\"{x:423,y:536,t:1527264885754};\\\", \\\"{x:421,y:535,t:1527264885771};\\\", \\\"{x:420,y:535,t:1527264885789};\\\", \\\"{x:419,y:535,t:1527264885810};\\\", \\\"{x:418,y:534,t:1527264885822};\\\", \\\"{x:417,y:534,t:1527264885839};\\\", \\\"{x:415,y:534,t:1527264885858};\\\", \\\"{x:413,y:534,t:1527264885874};\\\", \\\"{x:411,y:534,t:1527264885888};\\\", \\\"{x:405,y:534,t:1527264885905};\\\", \\\"{x:400,y:534,t:1527264885921};\\\", \\\"{x:388,y:534,t:1527264885938};\\\", \\\"{x:385,y:534,t:1527264885955};\\\", \\\"{x:383,y:534,t:1527264885971};\\\", \\\"{x:382,y:536,t:1527264886290};\\\", \\\"{x:382,y:538,t:1527264886306};\\\", \\\"{x:382,y:552,t:1527264886323};\\\", \\\"{x:382,y:560,t:1527264886338};\\\", \\\"{x:382,y:565,t:1527264886356};\\\", \\\"{x:382,y:570,t:1527264886372};\\\", \\\"{x:382,y:574,t:1527264886388};\\\", \\\"{x:382,y:578,t:1527264886405};\\\", \\\"{x:383,y:582,t:1527264886423};\\\", \\\"{x:385,y:585,t:1527264886438};\\\", \\\"{x:385,y:589,t:1527264886455};\\\", \\\"{x:388,y:593,t:1527264886472};\\\", \\\"{x:389,y:596,t:1527264886489};\\\", \\\"{x:389,y:597,t:1527264886506};\\\", \\\"{x:389,y:599,t:1527264886522};\\\", \\\"{x:389,y:601,t:1527264886539};\\\", \\\"{x:389,y:603,t:1527264886556};\\\", \\\"{x:389,y:604,t:1527264886724};\\\", \\\"{x:390,y:605,t:1527264887475};\\\", \\\"{x:391,y:605,t:1527264887490};\\\", \\\"{x:395,y:601,t:1527264887507};\\\", \\\"{x:407,y:596,t:1527264887522};\\\", \\\"{x:412,y:591,t:1527264887539};\\\", \\\"{x:418,y:591,t:1527264887556};\\\", \\\"{x:422,y:594,t:1527264887573};\\\", \\\"{x:422,y:596,t:1527264887590};\\\", \\\"{x:424,y:599,t:1527264887606};\\\", \\\"{x:426,y:599,t:1527264887622};\\\", \\\"{x:427,y:601,t:1527264887639};\\\", \\\"{x:432,y:604,t:1527264887656};\\\", \\\"{x:434,y:605,t:1527264887673};\\\", \\\"{x:436,y:610,t:1527264887689};\\\", \\\"{x:446,y:617,t:1527264887706};\\\", \\\"{x:449,y:623,t:1527264887723};\\\", \\\"{x:454,y:632,t:1527264887740};\\\", \\\"{x:454,y:633,t:1527264887756};\\\", \\\"{x:455,y:636,t:1527264887773};\\\", \\\"{x:461,y:653,t:1527264887791};\\\", \\\"{x:471,y:664,t:1527264887806};\\\", \\\"{x:477,y:674,t:1527264887823};\\\", \\\"{x:478,y:678,t:1527264887839};\\\", \\\"{x:479,y:680,t:1527264887856};\\\", \\\"{x:480,y:681,t:1527264887873};\\\", \\\"{x:481,y:682,t:1527264887890};\\\", \\\"{x:481,y:684,t:1527264889011};\\\", \\\"{x:485,y:687,t:1527264889025};\\\", \\\"{x:488,y:692,t:1527264889041};\\\", \\\"{x:491,y:700,t:1527264889058};\\\", \\\"{x:499,y:711,t:1527264889074};\\\", \\\"{x:502,y:718,t:1527264889091};\\\", \\\"{x:503,y:721,t:1527264889109};\\\", \\\"{x:505,y:726,t:1527264889124};\\\", \\\"{x:506,y:731,t:1527264889140};\\\", \\\"{x:507,y:739,t:1527264889157};\\\", \\\"{x:508,y:743,t:1527264889174};\\\", \\\"{x:508,y:746,t:1527264889190};\\\", \\\"{x:509,y:749,t:1527264889208};\\\", \\\"{x:511,y:749,t:1527264889355};\\\", \\\"{x:512,y:749,t:1527264889363};\\\", \\\"{x:512,y:747,t:1527264889374};\\\", \\\"{x:514,y:744,t:1527264889391};\\\", \\\"{x:515,y:743,t:1527264889408};\\\" ] }, { \\\"rt\\\": 17212, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 16, \\\"time_elapsed\\\": 491889, \\\"internal_node_id\\\": \\\"0.0-6.0-6.0\\\", \\\"subject\\\": \\\"RV9F6\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"lima\\\", \\\"condition\\\": \\\"115\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"starts\\\", \\\"q\\\": 12, \\\"clicks\\\": 1, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XFull-YFull\\\", \\\"correct\\\": 1, \\\"orth_correct\\\": 0, \\\"answer\\\": [ \\\"G\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"\\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:516,y:742,t:1527264896502};\\\", \\\"{x:517,y:742,t:1527264896774};\\\", \\\"{x:518,y:741,t:1527264896783};\\\", \\\"{x:520,y:740,t:1527264896800};\\\", \\\"{x:521,y:739,t:1527264896816};\\\", \\\"{x:522,y:739,t:1527264896833};\\\", \\\"{x:523,y:739,t:1527264896850};\\\", \\\"{x:526,y:739,t:1527264896935};\\\", \\\"{x:531,y:738,t:1527264896950};\\\", \\\"{x:534,y:737,t:1527264896967};\\\", \\\"{x:539,y:737,t:1527264896984};\\\", \\\"{x:553,y:737,t:1527264897000};\\\", \\\"{x:556,y:737,t:1527264897017};\\\", \\\"{x:575,y:737,t:1527264897035};\\\", \\\"{x:577,y:737,t:1527264897051};\\\", \\\"{x:589,y:737,t:1527264897066};\\\", \\\"{x:601,y:734,t:1527264897084};\\\", \\\"{x:614,y:728,t:1527264897100};\\\", \\\"{x:652,y:717,t:1527264897117};\\\", \\\"{x:681,y:711,t:1527264897134};\\\", \\\"{x:708,y:703,t:1527264897151};\\\", \\\"{x:764,y:692,t:1527264897168};\\\", \\\"{x:831,y:682,t:1527264897184};\\\", \\\"{x:878,y:674,t:1527264897201};\\\", \\\"{x:978,y:674,t:1527264897218};\\\", \\\"{x:1086,y:674,t:1527264897235};\\\", \\\"{x:1189,y:679,t:1527264897251};\\\", \\\"{x:1291,y:689,t:1527264897267};\\\", \\\"{x:1408,y:705,t:1527264897284};\\\", \\\"{x:1538,y:713,t:1527264897302};\\\", \\\"{x:1635,y:713,t:1527264897318};\\\", \\\"{x:1730,y:713,t:1527264897335};\\\", \\\"{x:1745,y:716,t:1527264897352};\\\", \\\"{x:1784,y:717,t:1527264897368};\\\", \\\"{x:1806,y:717,t:1527264897385};\\\", \\\"{x:1820,y:717,t:1527264897402};\\\", \\\"{x:1828,y:717,t:1527264897417};\\\", \\\"{x:1833,y:716,t:1527264897435};\\\", \\\"{x:1841,y:716,t:1527264897452};\\\", \\\"{x:1842,y:716,t:1527264897468};\\\", \\\"{x:1842,y:715,t:1527264898031};\\\", \\\"{x:1839,y:715,t:1527264898047};\\\", \\\"{x:1838,y:714,t:1527264898070};\\\", \\\"{x:1837,y:713,t:1527264898085};\\\", \\\"{x:1836,y:712,t:1527264898102};\\\", \\\"{x:1834,y:712,t:1527264898135};\\\", \\\"{x:1834,y:711,t:1527264898142};\\\", \\\"{x:1833,y:710,t:1527264898152};\\\", \\\"{x:1830,y:709,t:1527264898169};\\\", \\\"{x:1825,y:708,t:1527264898186};\\\", \\\"{x:1820,y:707,t:1527264898202};\\\", \\\"{x:1815,y:706,t:1527264898219};\\\", \\\"{x:1807,y:704,t:1527264898235};\\\", \\\"{x:1805,y:702,t:1527264898252};\\\", \\\"{x:1800,y:699,t:1527264898269};\\\", \\\"{x:1795,y:698,t:1527264898286};\\\", \\\"{x:1791,y:696,t:1527264898303};\\\", \\\"{x:1789,y:695,t:1527264898319};\\\", \\\"{x:1785,y:694,t:1527264898336};\\\", \\\"{x:1782,y:692,t:1527264898352};\\\", \\\"{x:1781,y:692,t:1527264898369};\\\", \\\"{x:1780,y:692,t:1527264898423};\\\", \\\"{x:1779,y:691,t:1527264898438};\\\", \\\"{x:1777,y:690,t:1527264898453};\\\", \\\"{x:1775,y:690,t:1527264898469};\\\", \\\"{x:1769,y:688,t:1527264898486};\\\", \\\"{x:1768,y:687,t:1527264898502};\\\", \\\"{x:1767,y:687,t:1527264898542};\\\", \\\"{x:1764,y:685,t:1527264898583};\\\", \\\"{x:1763,y:685,t:1527264898590};\\\", \\\"{x:1762,y:685,t:1527264898602};\\\", \\\"{x:1759,y:684,t:1527264898619};\\\", \\\"{x:1750,y:683,t:1527264898636};\\\", \\\"{x:1736,y:680,t:1527264898653};\\\", \\\"{x:1725,y:678,t:1527264898669};\\\", \\\"{x:1711,y:673,t:1527264898686};\\\", \\\"{x:1706,y:671,t:1527264898703};\\\", \\\"{x:1696,y:670,t:1527264898719};\\\", \\\"{x:1687,y:669,t:1527264898737};\\\", \\\"{x:1686,y:666,t:1527264898753};\\\", \\\"{x:1675,y:663,t:1527264898769};\\\", \\\"{x:1663,y:663,t:1527264898786};\\\", \\\"{x:1652,y:663,t:1527264898804};\\\", \\\"{x:1643,y:663,t:1527264898820};\\\", \\\"{x:1637,y:663,t:1527264898836};\\\", \\\"{x:1628,y:665,t:1527264898853};\\\", \\\"{x:1619,y:668,t:1527264898869};\\\", \\\"{x:1599,y:677,t:1527264898887};\\\", \\\"{x:1584,y:684,t:1527264898902};\\\", \\\"{x:1578,y:690,t:1527264898920};\\\", \\\"{x:1575,y:691,t:1527264898936};\\\", \\\"{x:1570,y:693,t:1527264898953};\\\", \\\"{x:1561,y:697,t:1527264898969};\\\", \\\"{x:1542,y:701,t:1527264898986};\\\", \\\"{x:1531,y:703,t:1527264899003};\\\", \\\"{x:1527,y:705,t:1527264899018};\\\", \\\"{x:1515,y:710,t:1527264899036};\\\", \\\"{x:1509,y:710,t:1527264899053};\\\", \\\"{x:1500,y:711,t:1527264899068};\\\", \\\"{x:1482,y:711,t:1527264899085};\\\", \\\"{x:1478,y:711,t:1527264899102};\\\", \\\"{x:1475,y:710,t:1527264899120};\\\", \\\"{x:1464,y:707,t:1527264899136};\\\", \\\"{x:1449,y:706,t:1527264899152};\\\", \\\"{x:1441,y:702,t:1527264899170};\\\", \\\"{x:1434,y:701,t:1527264899185};\\\", \\\"{x:1427,y:701,t:1527264899202};\\\", \\\"{x:1422,y:701,t:1527264899220};\\\", \\\"{x:1421,y:701,t:1527264899311};\\\", \\\"{x:1420,y:701,t:1527264899326};\\\", \\\"{x:1418,y:701,t:1527264899336};\\\", \\\"{x:1412,y:697,t:1527264899353};\\\", \\\"{x:1411,y:697,t:1527264899371};\\\", \\\"{x:1410,y:697,t:1527264899390};\\\", \\\"{x:1408,y:694,t:1527264899402};\\\", \\\"{x:1405,y:693,t:1527264899419};\\\", \\\"{x:1402,y:691,t:1527264899436};\\\", \\\"{x:1399,y:690,t:1527264899453};\\\", \\\"{x:1395,y:689,t:1527264899470};\\\", \\\"{x:1393,y:688,t:1527264899486};\\\", \\\"{x:1391,y:687,t:1527264899503};\\\", \\\"{x:1388,y:687,t:1527264899520};\\\", \\\"{x:1387,y:686,t:1527264899711};\\\", \\\"{x:1381,y:684,t:1527264899721};\\\", \\\"{x:1375,y:679,t:1527264899737};\\\", \\\"{x:1364,y:669,t:1527264899753};\\\", \\\"{x:1360,y:669,t:1527264899770};\\\", \\\"{x:1340,y:653,t:1527264899787};\\\", \\\"{x:1315,y:638,t:1527264899802};\\\", \\\"{x:1283,y:625,t:1527264899820};\\\", \\\"{x:1270,y:614,t:1527264899837};\\\", \\\"{x:1238,y:598,t:1527264899853};\\\", \\\"{x:1187,y:577,t:1527264899869};\\\", \\\"{x:1175,y:563,t:1527264899887};\\\", \\\"{x:1170,y:553,t:1527264899903};\\\", \\\"{x:1150,y:542,t:1527264899919};\\\", \\\"{x:1140,y:538,t:1527264899937};\\\", \\\"{x:1128,y:535,t:1527264899953};\\\", \\\"{x:1121,y:535,t:1527264899969};\\\", \\\"{x:1102,y:531,t:1527264899987};\\\", \\\"{x:1090,y:528,t:1527264900003};\\\", \\\"{x:1067,y:526,t:1527264900020};\\\", \\\"{x:1051,y:523,t:1527264900036};\\\", \\\"{x:1041,y:518,t:1527264900053};\\\", \\\"{x:1034,y:518,t:1527264900070};\\\", \\\"{x:1016,y:518,t:1527264900087};\\\", \\\"{x:979,y:518,t:1527264900104};\\\", \\\"{x:950,y:519,t:1527264900120};\\\", \\\"{x:943,y:519,t:1527264900137};\\\", \\\"{x:924,y:515,t:1527264900155};\\\", \\\"{x:900,y:515,t:1527264900170};\\\", \\\"{x:893,y:515,t:1527264900186};\\\", \\\"{x:880,y:515,t:1527264900203};\\\", \\\"{x:875,y:515,t:1527264900220};\\\", \\\"{x:871,y:515,t:1527264900237};\\\", \\\"{x:856,y:515,t:1527264900253};\\\", \\\"{x:841,y:515,t:1527264900270};\\\", \\\"{x:829,y:515,t:1527264900286};\\\", \\\"{x:824,y:514,t:1527264900304};\\\", \\\"{x:816,y:514,t:1527264900320};\\\", \\\"{x:813,y:514,t:1527264900336};\\\", \\\"{x:806,y:514,t:1527264900354};\\\", \\\"{x:801,y:514,t:1527264900370};\\\", \\\"{x:798,y:514,t:1527264900387};\\\", \\\"{x:778,y:514,t:1527264900404};\\\", \\\"{x:756,y:513,t:1527264900421};\\\", \\\"{x:753,y:513,t:1527264900436};\\\", \\\"{x:730,y:513,t:1527264900454};\\\", \\\"{x:723,y:513,t:1527264900472};\\\", \\\"{x:722,y:513,t:1527264900487};\\\", \\\"{x:716,y:513,t:1527264900504};\\\", \\\"{x:709,y:513,t:1527264900520};\\\", \\\"{x:706,y:513,t:1527264900537};\\\", \\\"{x:705,y:513,t:1527264902806};\\\", \\\"{x:701,y:511,t:1527264905062};\\\", \\\"{x:693,y:503,t:1527264905074};\\\", \\\"{x:674,y:492,t:1527264905091};\\\", \\\"{x:661,y:483,t:1527264905108};\\\", \\\"{x:641,y:476,t:1527264905123};\\\", \\\"{x:635,y:471,t:1527264905140};\\\", \\\"{x:626,y:462,t:1527264905157};\\\", \\\"{x:624,y:462,t:1527264905173};\\\", \\\"{x:621,y:462,t:1527264905190};\\\", \\\"{x:616,y:456,t:1527264905208};\\\", \\\"{x:614,y:454,t:1527264905223};\\\", \\\"{x:613,y:452,t:1527264905241};\\\", \\\"{x:614,y:451,t:1527264905887};\\\", \\\"{x:621,y:452,t:1527264905894};\\\", \\\"{x:622,y:452,t:1527264905909};\\\", \\\"{x:626,y:453,t:1527264905925};\\\", \\\"{x:627,y:455,t:1527264905942};\\\", \\\"{x:639,y:456,t:1527264905958};\\\", \\\"{x:650,y:456,t:1527264905975};\\\", \\\"{x:664,y:456,t:1527264905992};\\\", \\\"{x:674,y:456,t:1527264906008};\\\", \\\"{x:689,y:456,t:1527264906025};\\\", \\\"{x:707,y:456,t:1527264906042};\\\", \\\"{x:712,y:456,t:1527264906058};\\\", \\\"{x:718,y:457,t:1527264906075};\\\", \\\"{x:736,y:457,t:1527264906092};\\\", \\\"{x:747,y:457,t:1527264906108};\\\", \\\"{x:749,y:457,t:1527264906125};\\\", \\\"{x:764,y:459,t:1527264906142};\\\", \\\"{x:773,y:461,t:1527264906157};\\\", \\\"{x:786,y:467,t:1527264906175};\\\", \\\"{x:794,y:471,t:1527264906192};\\\", \\\"{x:801,y:476,t:1527264906207};\\\", \\\"{x:810,y:484,t:1527264906224};\\\", \\\"{x:814,y:488,t:1527264906242};\\\", \\\"{x:818,y:501,t:1527264906259};\\\", \\\"{x:819,y:505,t:1527264906275};\\\", \\\"{x:822,y:509,t:1527264906291};\\\", \\\"{x:827,y:521,t:1527264906308};\\\", \\\"{x:828,y:529,t:1527264906325};\\\", \\\"{x:835,y:541,t:1527264906342};\\\", \\\"{x:835,y:542,t:1527264906358};\\\", \\\"{x:835,y:543,t:1527264906742};\\\", \\\"{x:827,y:549,t:1527264906759};\\\", \\\"{x:816,y:554,t:1527264906776};\\\", \\\"{x:803,y:560,t:1527264906792};\\\", \\\"{x:796,y:566,t:1527264906809};\\\", \\\"{x:787,y:573,t:1527264906826};\\\", \\\"{x:780,y:580,t:1527264906841};\\\", \\\"{x:756,y:596,t:1527264906860};\\\", \\\"{x:725,y:614,t:1527264906876};\\\", \\\"{x:724,y:615,t:1527264906891};\\\", \\\"{x:701,y:630,t:1527264906910};\\\", \\\"{x:673,y:649,t:1527264906926};\\\", \\\"{x:659,y:660,t:1527264906942};\\\", \\\"{x:647,y:669,t:1527264906958};\\\", \\\"{x:640,y:673,t:1527264906976};\\\", \\\"{x:626,y:685,t:1527264906992};\\\", \\\"{x:614,y:694,t:1527264907009};\\\", \\\"{x:600,y:707,t:1527264907026};\\\", \\\"{x:585,y:717,t:1527264907043};\\\", \\\"{x:568,y:728,t:1527264907059};\\\", \\\"{x:558,y:736,t:1527264907077};\\\", \\\"{x:548,y:746,t:1527264907093};\\\", \\\"{x:540,y:749,t:1527264907109};\\\", \\\"{x:526,y:756,t:1527264907126};\\\", \\\"{x:524,y:756,t:1527264907143};\\\", \\\"{x:522,y:756,t:1527264907158};\\\", \\\"{x:521,y:756,t:1527264907287};\\\", \\\"{x:520,y:756,t:1527264907342};\\\", \\\"{x:518,y:754,t:1527264907360};\\\", \\\"{x:518,y:751,t:1527264907376};\\\", \\\"{x:518,y:749,t:1527264907392};\\\", \\\"{x:518,y:748,t:1527264907409};\\\", \\\"{x:518,y:747,t:1527264907426};\\\", \\\"{x:518,y:746,t:1527264907442};\\\", \\\"{x:518,y:745,t:1527264907542};\\\", \\\"{x:518,y:744,t:1527264907566};\\\", \\\"{x:518,y:743,t:1527264907581};\\\" ] }, { \\\"rt\\\": 24170, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 17, \\\"time_elapsed\\\": 517282, \\\"internal_node_id\\\": \\\"0.0-6.0-7.0\\\", \\\"subject\\\": \\\"RV9F6\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"lima\\\", \\\"condition\\\": \\\"115\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"meets\\\", \\\"q\\\": 13, \\\"clicks\\\": 2, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XFull-YFull\\\", \\\"correct\\\": 1, \\\"orth_correct\\\": 0, \\\"answer\\\": [ \\\"E\\\", \\\"F\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-08 PM\\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:518,y:740,t:1527264912639};\\\", \\\"{x:519,y:737,t:1527264912654};\\\", \\\"{x:523,y:734,t:1527264912670};\\\", \\\"{x:528,y:730,t:1527264912687};\\\", \\\"{x:532,y:726,t:1527264912704};\\\", \\\"{x:538,y:721,t:1527264912721};\\\", \\\"{x:549,y:717,t:1527264912738};\\\", \\\"{x:562,y:711,t:1527264912754};\\\", \\\"{x:577,y:706,t:1527264912771};\\\", \\\"{x:579,y:704,t:1527264912780};\\\", \\\"{x:606,y:700,t:1527264912797};\\\", \\\"{x:613,y:700,t:1527264912813};\\\", \\\"{x:623,y:699,t:1527264912830};\\\", \\\"{x:631,y:699,t:1527264912847};\\\", \\\"{x:649,y:697,t:1527264912863};\\\", \\\"{x:655,y:697,t:1527264912880};\\\", \\\"{x:661,y:697,t:1527264912897};\\\", \\\"{x:672,y:697,t:1527264912914};\\\", \\\"{x:685,y:697,t:1527264912930};\\\", \\\"{x:698,y:697,t:1527264912947};\\\", \\\"{x:705,y:697,t:1527264912964};\\\", \\\"{x:713,y:697,t:1527264912980};\\\", \\\"{x:724,y:698,t:1527264912997};\\\", \\\"{x:727,y:698,t:1527264913013};\\\", \\\"{x:729,y:697,t:1527264913030};\\\", \\\"{x:731,y:697,t:1527264913047};\\\", \\\"{x:735,y:697,t:1527264913064};\\\", \\\"{x:740,y:697,t:1527264913081};\\\", \\\"{x:747,y:697,t:1527264913097};\\\", \\\"{x:748,y:697,t:1527264913114};\\\", \\\"{x:750,y:698,t:1527264913130};\\\", \\\"{x:754,y:699,t:1527264913148};\\\", \\\"{x:756,y:699,t:1527264913165};\\\", \\\"{x:757,y:699,t:1527264913494};\\\", \\\"{x:760,y:699,t:1527264913502};\\\", \\\"{x:764,y:699,t:1527264913514};\\\", \\\"{x:771,y:699,t:1527264913531};\\\", \\\"{x:782,y:699,t:1527264913547};\\\", \\\"{x:789,y:700,t:1527264913564};\\\", \\\"{x:796,y:701,t:1527264913581};\\\", \\\"{x:798,y:703,t:1527264913597};\\\", \\\"{x:817,y:707,t:1527264913614};\\\", \\\"{x:828,y:713,t:1527264913631};\\\", \\\"{x:839,y:715,t:1527264913647};\\\", \\\"{x:846,y:718,t:1527264913664};\\\", \\\"{x:867,y:721,t:1527264913681};\\\", \\\"{x:880,y:731,t:1527264913698};\\\", \\\"{x:893,y:731,t:1527264913714};\\\", \\\"{x:894,y:735,t:1527264913731};\\\", \\\"{x:905,y:741,t:1527264913748};\\\", \\\"{x:915,y:748,t:1527264913765};\\\", \\\"{x:953,y:757,t:1527264913782};\\\", \\\"{x:975,y:762,t:1527264913798};\\\", \\\"{x:976,y:771,t:1527264913815};\\\", \\\"{x:981,y:780,t:1527264913832};\\\", \\\"{x:990,y:780,t:1527264913848};\\\", \\\"{x:993,y:780,t:1527264913864};\\\", \\\"{x:1005,y:791,t:1527264913882};\\\", \\\"{x:1021,y:796,t:1527264913899};\\\", \\\"{x:1049,y:803,t:1527264913915};\\\", \\\"{x:1066,y:810,t:1527264913931};\\\", \\\"{x:1083,y:822,t:1527264913949};\\\", \\\"{x:1094,y:831,t:1527264913964};\\\", \\\"{x:1114,y:847,t:1527264913982};\\\", \\\"{x:1143,y:860,t:1527264913999};\\\", \\\"{x:1194,y:874,t:1527264914014};\\\", \\\"{x:1262,y:884,t:1527264914032};\\\", \\\"{x:1296,y:895,t:1527264914049};\\\", \\\"{x:1336,y:906,t:1527264914064};\\\", \\\"{x:1415,y:918,t:1527264914081};\\\", \\\"{x:1447,y:928,t:1527264914099};\\\", \\\"{x:1468,y:938,t:1527264914114};\\\", \\\"{x:1561,y:951,t:1527264914132};\\\", \\\"{x:1658,y:966,t:1527264914149};\\\", \\\"{x:1769,y:981,t:1527264914164};\\\", \\\"{x:1909,y:998,t:1527264914183};\\\", \\\"{x:1919,y:1003,t:1527264914198};\\\", \\\"{x:1919,y:1001,t:1527264914237};\\\", \\\"{x:1919,y:1000,t:1527264914248};\\\", \\\"{x:1919,y:999,t:1527264914265};\\\", \\\"{x:1919,y:997,t:1527264914281};\\\", \\\"{x:1919,y:994,t:1527264914298};\\\", \\\"{x:1917,y:988,t:1527264914315};\\\", \\\"{x:1907,y:982,t:1527264914331};\\\", \\\"{x:1900,y:978,t:1527264914349};\\\", \\\"{x:1894,y:972,t:1527264914365};\\\", \\\"{x:1889,y:969,t:1527264914382};\\\", \\\"{x:1883,y:964,t:1527264914399};\\\", \\\"{x:1882,y:962,t:1527264914415};\\\", \\\"{x:1879,y:961,t:1527264914431};\\\", \\\"{x:1876,y:958,t:1527264914448};\\\", \\\"{x:1864,y:944,t:1527264914465};\\\", \\\"{x:1857,y:939,t:1527264914481};\\\", \\\"{x:1838,y:927,t:1527264914498};\\\", \\\"{x:1802,y:907,t:1527264914516};\\\", \\\"{x:1776,y:895,t:1527264914531};\\\", \\\"{x:1759,y:883,t:1527264914549};\\\", \\\"{x:1745,y:872,t:1527264914566};\\\", \\\"{x:1734,y:870,t:1527264914582};\\\", \\\"{x:1729,y:870,t:1527264914598};\\\", \\\"{x:1727,y:869,t:1527264914615};\\\", \\\"{x:1724,y:869,t:1527264914632};\\\", \\\"{x:1724,y:868,t:1527264914649};\\\", \\\"{x:1723,y:868,t:1527264917375};\\\", \\\"{x:1719,y:866,t:1527264917384};\\\", \\\"{x:1716,y:862,t:1527264917401};\\\", \\\"{x:1716,y:860,t:1527264917418};\\\", \\\"{x:1713,y:858,t:1527264917433};\\\", \\\"{x:1711,y:855,t:1527264917451};\\\", \\\"{x:1710,y:853,t:1527264917468};\\\", \\\"{x:1709,y:853,t:1527264917485};\\\", \\\"{x:1709,y:852,t:1527264920183};\\\", \\\"{x:1708,y:852,t:1527264921271};\\\", \\\"{x:1707,y:852,t:1527264921302};\\\", \\\"{x:1706,y:852,t:1527264921318};\\\", \\\"{x:1706,y:851,t:1527264921326};\\\", \\\"{x:1706,y:850,t:1527264921342};\\\", \\\"{x:1705,y:850,t:1527264921374};\\\", \\\"{x:1702,y:848,t:1527264921494};\\\", \\\"{x:1699,y:846,t:1527264921504};\\\", \\\"{x:1693,y:843,t:1527264921521};\\\", \\\"{x:1687,y:841,t:1527264921537};\\\", \\\"{x:1682,y:837,t:1527264921554};\\\", \\\"{x:1679,y:836,t:1527264921571};\\\", \\\"{x:1676,y:834,t:1527264921587};\\\", \\\"{x:1673,y:833,t:1527264921604};\\\", \\\"{x:1671,y:831,t:1527264921791};\\\", \\\"{x:1670,y:825,t:1527264921804};\\\", \\\"{x:1666,y:817,t:1527264921821};\\\", \\\"{x:1666,y:806,t:1527264921838};\\\", \\\"{x:1666,y:804,t:1527264921854};\\\", \\\"{x:1663,y:797,t:1527264921871};\\\", \\\"{x:1663,y:795,t:1527264921888};\\\", \\\"{x:1663,y:793,t:1527264921904};\\\", \\\"{x:1663,y:785,t:1527264921922};\\\", \\\"{x:1659,y:773,t:1527264921938};\\\", \\\"{x:1653,y:761,t:1527264921954};\\\", \\\"{x:1649,y:750,t:1527264921971};\\\", \\\"{x:1645,y:740,t:1527264921988};\\\", \\\"{x:1644,y:737,t:1527264922004};\\\", \\\"{x:1644,y:734,t:1527264922021};\\\", \\\"{x:1644,y:733,t:1527264922038};\\\", \\\"{x:1643,y:733,t:1527264922062};\\\", \\\"{x:1643,y:732,t:1527264922071};\\\", \\\"{x:1642,y:731,t:1527264922088};\\\", \\\"{x:1642,y:730,t:1527264922104};\\\", \\\"{x:1641,y:730,t:1527264922121};\\\", \\\"{x:1641,y:729,t:1527264922142};\\\", \\\"{x:1640,y:728,t:1527264922184};\\\", \\\"{x:1639,y:728,t:1527264922199};\\\", \\\"{x:1638,y:727,t:1527264922206};\\\", \\\"{x:1637,y:726,t:1527264922222};\\\", \\\"{x:1636,y:725,t:1527264922238};\\\", \\\"{x:1632,y:725,t:1527264922303};\\\", \\\"{x:1631,y:725,t:1527264922310};\\\", \\\"{x:1630,y:725,t:1527264922321};\\\", \\\"{x:1628,y:724,t:1527264922338};\\\", \\\"{x:1624,y:722,t:1527264922355};\\\", \\\"{x:1622,y:721,t:1527264922371};\\\", \\\"{x:1620,y:718,t:1527264922388};\\\", \\\"{x:1619,y:718,t:1527264922405};\\\", \\\"{x:1618,y:718,t:1527264922422};\\\", \\\"{x:1618,y:717,t:1527264922686};\\\", \\\"{x:1618,y:716,t:1527264923127};\\\", \\\"{x:1617,y:715,t:1527264923138};\\\", \\\"{x:1617,y:714,t:1527264923155};\\\", \\\"{x:1617,y:711,t:1527264923172};\\\", \\\"{x:1617,y:710,t:1527264923189};\\\", \\\"{x:1618,y:709,t:1527264923214};\\\", \\\"{x:1619,y:708,t:1527264923407};\\\", \\\"{x:1620,y:706,t:1527264923446};\\\", \\\"{x:1622,y:705,t:1527264923599};\\\", \\\"{x:1620,y:705,t:1527264926118};\\\", \\\"{x:1619,y:705,t:1527264926126};\\\", \\\"{x:1618,y:705,t:1527264926158};\\\", \\\"{x:1615,y:705,t:1527264927213};\\\", \\\"{x:1607,y:706,t:1527264927224};\\\", \\\"{x:1592,y:706,t:1527264927240};\\\", \\\"{x:1581,y:706,t:1527264927258};\\\", \\\"{x:1534,y:701,t:1527264927275};\\\", \\\"{x:1472,y:679,t:1527264927290};\\\", \\\"{x:1408,y:661,t:1527264927308};\\\", \\\"{x:1357,y:645,t:1527264927325};\\\", \\\"{x:1322,y:636,t:1527264927340};\\\", \\\"{x:1240,y:624,t:1527264927358};\\\", \\\"{x:1208,y:619,t:1527264927375};\\\", \\\"{x:1181,y:617,t:1527264927391};\\\", \\\"{x:1149,y:611,t:1527264927408};\\\", \\\"{x:1131,y:607,t:1527264927425};\\\", \\\"{x:1113,y:602,t:1527264927442};\\\", \\\"{x:1097,y:600,t:1527264927458};\\\", \\\"{x:1086,y:596,t:1527264927475};\\\", \\\"{x:1079,y:591,t:1527264927491};\\\", \\\"{x:1058,y:586,t:1527264927508};\\\", \\\"{x:1045,y:579,t:1527264927525};\\\", \\\"{x:1009,y:574,t:1527264927542};\\\", \\\"{x:994,y:572,t:1527264927558};\\\", \\\"{x:982,y:570,t:1527264927575};\\\", \\\"{x:973,y:569,t:1527264927592};\\\", \\\"{x:972,y:569,t:1527264927608};\\\", \\\"{x:971,y:568,t:1527264927822};\\\", \\\"{x:969,y:564,t:1527264927838};\\\", \\\"{x:961,y:561,t:1527264927846};\\\", \\\"{x:952,y:558,t:1527264927858};\\\", \\\"{x:938,y:552,t:1527264927877};\\\", \\\"{x:924,y:545,t:1527264927892};\\\", \\\"{x:915,y:543,t:1527264927909};\\\", \\\"{x:915,y:536,t:1527264927925};\\\", \\\"{x:914,y:536,t:1527264928126};\\\", \\\"{x:909,y:533,t:1527264928214};\\\", \\\"{x:905,y:531,t:1527264928226};\\\", \\\"{x:903,y:530,t:1527264928243};\\\", \\\"{x:901,y:527,t:1527264928260};\\\", \\\"{x:898,y:526,t:1527264928276};\\\", \\\"{x:895,y:526,t:1527264928293};\\\", \\\"{x:889,y:524,t:1527264928310};\\\", \\\"{x:887,y:523,t:1527264928326};\\\", \\\"{x:879,y:521,t:1527264928342};\\\", \\\"{x:879,y:519,t:1527264928360};\\\", \\\"{x:876,y:513,t:1527264928376};\\\", \\\"{x:867,y:512,t:1527264928392};\\\", \\\"{x:847,y:506,t:1527264928409};\\\", \\\"{x:841,y:499,t:1527264928426};\\\", \\\"{x:831,y:493,t:1527264928442};\\\", \\\"{x:818,y:489,t:1527264928460};\\\", \\\"{x:805,y:484,t:1527264928476};\\\", \\\"{x:781,y:474,t:1527264928493};\\\", \\\"{x:770,y:467,t:1527264928509};\\\", \\\"{x:755,y:462,t:1527264928527};\\\", \\\"{x:753,y:462,t:1527264928542};\\\", \\\"{x:749,y:462,t:1527264928559};\\\", \\\"{x:746,y:459,t:1527264928576};\\\", \\\"{x:744,y:459,t:1527264928593};\\\", \\\"{x:743,y:459,t:1527264928629};\\\", \\\"{x:742,y:459,t:1527264928642};\\\", \\\"{x:740,y:461,t:1527264928660};\\\", \\\"{x:734,y:466,t:1527264928677};\\\", \\\"{x:732,y:469,t:1527264928693};\\\", \\\"{x:727,y:472,t:1527264928710};\\\", \\\"{x:724,y:472,t:1527264928727};\\\", \\\"{x:722,y:474,t:1527264928743};\\\", \\\"{x:719,y:477,t:1527264928760};\\\", \\\"{x:714,y:479,t:1527264928777};\\\", \\\"{x:707,y:483,t:1527264928793};\\\", \\\"{x:696,y:490,t:1527264928811};\\\", \\\"{x:689,y:498,t:1527264928827};\\\", \\\"{x:682,y:501,t:1527264928842};\\\", \\\"{x:679,y:503,t:1527264928858};\\\", \\\"{x:672,y:509,t:1527264928876};\\\", \\\"{x:663,y:511,t:1527264928892};\\\", \\\"{x:658,y:513,t:1527264928909};\\\", \\\"{x:654,y:515,t:1527264928926};\\\", \\\"{x:653,y:515,t:1527264929183};\\\", \\\"{x:652,y:515,t:1527264929229};\\\", \\\"{x:651,y:515,t:1527264929241};\\\", \\\"{x:650,y:514,t:1527264929268};\\\", \\\"{x:649,y:512,t:1527264929277};\\\", \\\"{x:648,y:511,t:1527264929291};\\\", \\\"{x:646,y:510,t:1527264929308};\\\", \\\"{x:646,y:509,t:1527264929349};\\\", \\\"{x:646,y:508,t:1527264929398};\\\", \\\"{x:646,y:507,t:1527264929413};\\\", \\\"{x:644,y:506,t:1527264929453};\\\", \\\"{x:643,y:506,t:1527264929461};\\\", \\\"{x:642,y:506,t:1527264929474};\\\", \\\"{x:640,y:506,t:1527264929490};\\\", \\\"{x:639,y:506,t:1527264929510};\\\", \\\"{x:636,y:506,t:1527264929526};\\\", \\\"{x:632,y:506,t:1527264929544};\\\", \\\"{x:630,y:506,t:1527264929561};\\\", \\\"{x:630,y:505,t:1527264929582};\\\", \\\"{x:629,y:505,t:1527264929594};\\\", \\\"{x:628,y:503,t:1527264929611};\\\", \\\"{x:625,y:503,t:1527264929627};\\\", \\\"{x:624,y:503,t:1527264929645};\\\", \\\"{x:623,y:503,t:1527264929660};\\\", \\\"{x:621,y:503,t:1527264929677};\\\", \\\"{x:617,y:503,t:1527264929694};\\\", \\\"{x:614,y:503,t:1527264929710};\\\", \\\"{x:612,y:503,t:1527264929726};\\\", \\\"{x:611,y:503,t:1527264930774};\\\", \\\"{x:611,y:502,t:1527264930790};\\\", \\\"{x:611,y:500,t:1527264930798};\\\", \\\"{x:613,y:499,t:1527264930812};\\\", \\\"{x:625,y:499,t:1527264930829};\\\", \\\"{x:645,y:497,t:1527264930846};\\\", \\\"{x:679,y:495,t:1527264930860};\\\", \\\"{x:691,y:495,t:1527264930877};\\\", \\\"{x:709,y:495,t:1527264930895};\\\", \\\"{x:725,y:495,t:1527264930912};\\\", \\\"{x:732,y:495,t:1527264930928};\\\", \\\"{x:736,y:495,t:1527264930944};\\\", \\\"{x:741,y:495,t:1527264930961};\\\", \\\"{x:744,y:495,t:1527264930977};\\\", \\\"{x:746,y:494,t:1527264931061};\\\", \\\"{x:747,y:494,t:1527264931079};\\\", \\\"{x:748,y:494,t:1527264931101};\\\", \\\"{x:750,y:495,t:1527264931112};\\\", \\\"{x:758,y:499,t:1527264931128};\\\", \\\"{x:767,y:503,t:1527264931145};\\\", \\\"{x:776,y:506,t:1527264931162};\\\", \\\"{x:783,y:509,t:1527264931179};\\\", \\\"{x:788,y:510,t:1527264931195};\\\", \\\"{x:792,y:510,t:1527264931212};\\\", \\\"{x:806,y:511,t:1527264931230};\\\", \\\"{x:811,y:511,t:1527264931246};\\\", \\\"{x:814,y:513,t:1527264931262};\\\", \\\"{x:818,y:513,t:1527264931279};\\\", \\\"{x:823,y:513,t:1527264931295};\\\", \\\"{x:825,y:513,t:1527264931405};\\\", \\\"{x:826,y:513,t:1527264931413};\\\", \\\"{x:830,y:512,t:1527264931429};\\\", \\\"{x:833,y:509,t:1527264931445};\\\", \\\"{x:835,y:508,t:1527264931462};\\\", \\\"{x:832,y:515,t:1527264931999};\\\", \\\"{x:826,y:531,t:1527264932013};\\\", \\\"{x:815,y:549,t:1527264932029};\\\", \\\"{x:801,y:566,t:1527264932046};\\\", \\\"{x:781,y:583,t:1527264932063};\\\", \\\"{x:757,y:598,t:1527264932079};\\\", \\\"{x:733,y:610,t:1527264932096};\\\", \\\"{x:710,y:615,t:1527264932113};\\\", \\\"{x:698,y:617,t:1527264932130};\\\", \\\"{x:686,y:622,t:1527264932146};\\\", \\\"{x:671,y:626,t:1527264932163};\\\", \\\"{x:641,y:635,t:1527264932179};\\\", \\\"{x:593,y:650,t:1527264932196};\\\", \\\"{x:526,y:670,t:1527264932213};\\\", \\\"{x:522,y:670,t:1527264932228};\\\", \\\"{x:506,y:675,t:1527264932245};\\\", \\\"{x:501,y:676,t:1527264932263};\\\", \\\"{x:499,y:678,t:1527264932279};\\\", \\\"{x:498,y:679,t:1527264932296};\\\", \\\"{x:498,y:680,t:1527264932349};\\\", \\\"{x:498,y:682,t:1527264932363};\\\", \\\"{x:500,y:690,t:1527264932379};\\\", \\\"{x:503,y:699,t:1527264932396};\\\", \\\"{x:506,y:705,t:1527264932413};\\\", \\\"{x:508,y:709,t:1527264932429};\\\", \\\"{x:513,y:714,t:1527264932446};\\\", \\\"{x:518,y:718,t:1527264932464};\\\", \\\"{x:518,y:725,t:1527264932481};\\\", \\\"{x:519,y:727,t:1527264932495};\\\", \\\"{x:521,y:733,t:1527264932513};\\\", \\\"{x:521,y:736,t:1527264932530};\\\", \\\"{x:521,y:737,t:1527264932546};\\\", \\\"{x:522,y:738,t:1527264932563};\\\", \\\"{x:523,y:740,t:1527264932579};\\\", \\\"{x:524,y:740,t:1527264932596};\\\", \\\"{x:524,y:741,t:1527264932612};\\\", \\\"{x:524,y:742,t:1527264932630};\\\" ] }, { \\\"rt\\\": 7312, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 18, \\\"time_elapsed\\\": 525818, \\\"internal_node_id\\\": \\\"0.0-6.0-8.0\\\", \\\"subject\\\": \\\"RV9F6\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"lima\\\", \\\"condition\\\": \\\"115\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"endtime\\\", \\\"q\\\": 14, \\\"clicks\\\": 1, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XFull-YFull\\\", \\\"correct\\\": 1, \\\"orth_correct\\\": 0, \\\"answer\\\": [ \\\"X\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"\\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:524,y:743,t:1527264940542};\\\", \\\"{x:527,y:746,t:1527264940549};\\\", \\\"{x:528,y:746,t:1527264940565};\\\", \\\"{x:529,y:746,t:1527264940581};\\\", \\\"{x:531,y:746,t:1527264940613};\\\", \\\"{x:534,y:746,t:1527264940621};\\\", \\\"{x:539,y:743,t:1527264940632};\\\", \\\"{x:544,y:738,t:1527264940648};\\\", \\\"{x:558,y:732,t:1527264940665};\\\", \\\"{x:567,y:722,t:1527264940682};\\\", \\\"{x:569,y:719,t:1527264940699};\\\", \\\"{x:569,y:715,t:1527264940715};\\\", \\\"{x:559,y:700,t:1527264940736};\\\", \\\"{x:557,y:698,t:1527264940753};\\\", \\\"{x:548,y:690,t:1527264940768};\\\", \\\"{x:533,y:678,t:1527264940786};\\\", \\\"{x:500,y:663,t:1527264940803};\\\", \\\"{x:478,y:654,t:1527264940819};\\\", \\\"{x:467,y:646,t:1527264940836};\\\", \\\"{x:464,y:643,t:1527264940853};\\\", \\\"{x:464,y:640,t:1527264940868};\\\", \\\"{x:471,y:631,t:1527264940886};\\\", \\\"{x:481,y:622,t:1527264940903};\\\", \\\"{x:489,y:618,t:1527264940919};\\\", \\\"{x:499,y:609,t:1527264940937};\\\", \\\"{x:512,y:599,t:1527264940953};\\\", \\\"{x:529,y:589,t:1527264940970};\\\", \\\"{x:543,y:580,t:1527264940986};\\\", \\\"{x:560,y:573,t:1527264941003};\\\", \\\"{x:571,y:569,t:1527264941019};\\\", \\\"{x:576,y:567,t:1527264941036};\\\", \\\"{x:593,y:558,t:1527264941054};\\\", \\\"{x:597,y:555,t:1527264941069};\\\", \\\"{x:598,y:555,t:1527264941181};\\\", \\\"{x:602,y:557,t:1527264941189};\\\", \\\"{x:605,y:560,t:1527264941203};\\\", \\\"{x:610,y:565,t:1527264941221};\\\", \\\"{x:612,y:571,t:1527264941237};\\\", \\\"{x:616,y:577,t:1527264941253};\\\", \\\"{x:618,y:580,t:1527264941270};\\\", \\\"{x:618,y:585,t:1527264941557};\\\", \\\"{x:619,y:596,t:1527264941570};\\\", \\\"{x:619,y:620,t:1527264941588};\\\", \\\"{x:619,y:648,t:1527264941604};\\\", \\\"{x:618,y:662,t:1527264941620};\\\", \\\"{x:606,y:694,t:1527264941637};\\\", \\\"{x:600,y:708,t:1527264941653};\\\", \\\"{x:597,y:712,t:1527264941670};\\\", \\\"{x:597,y:713,t:1527264941687};\\\", \\\"{x:596,y:715,t:1527264941703};\\\", \\\"{x:594,y:717,t:1527264941720};\\\", \\\"{x:592,y:722,t:1527264941737};\\\", \\\"{x:591,y:723,t:1527264941753};\\\", \\\"{x:584,y:726,t:1527264941770};\\\", \\\"{x:580,y:727,t:1527264941787};\\\", \\\"{x:575,y:730,t:1527264941803};\\\", \\\"{x:570,y:730,t:1527264941820};\\\", \\\"{x:557,y:730,t:1527264941838};\\\", \\\"{x:550,y:729,t:1527264941853};\\\", \\\"{x:547,y:729,t:1527264941870};\\\", \\\"{x:546,y:729,t:1527264941893};\\\", \\\"{x:545,y:727,t:1527264941917};\\\", \\\"{x:545,y:726,t:1527264942806};\\\", \\\"{x:549,y:722,t:1527264942820};\\\", \\\"{x:561,y:719,t:1527264942838};\\\", \\\"{x:582,y:718,t:1527264942854};\\\", \\\"{x:593,y:712,t:1527264942870};\\\", \\\"{x:628,y:707,t:1527264942887};\\\", \\\"{x:675,y:707,t:1527264942904};\\\", \\\"{x:726,y:707,t:1527264942920};\\\", \\\"{x:751,y:707,t:1527264942938};\\\", \\\"{x:760,y:705,t:1527264942955};\\\", \\\"{x:765,y:705,t:1527264942970};\\\", \\\"{x:768,y:705,t:1527264942988};\\\", \\\"{x:769,y:705,t:1527264943005};\\\" ] }, { \\\"rt\\\": 11276, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 19, \\\"time_elapsed\\\": 538315, \\\"internal_node_id\\\": \\\"0.0-6.0-9.0\\\", \\\"subject\\\": \\\"RV9F6\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"lima\\\", \\\"condition\\\": \\\"115\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"midpoint\\\", \\\"q\\\": 15, \\\"clicks\\\": 2.5, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XFull-YFull\\\", \\\"correct\\\": 1, \\\"orth_correct\\\": 0, \\\"answer\\\": [ \\\"K\\\", \\\"X\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"\\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:778,y:705,t:1527264947830};\\\", \\\"{x:780,y:705,t:1527264947842};\\\", \\\"{x:853,y:721,t:1527264947858};\\\", \\\"{x:910,y:741,t:1527264947875};\\\", \\\"{x:1014,y:765,t:1527264947892};\\\", \\\"{x:1186,y:795,t:1527264947909};\\\", \\\"{x:1308,y:814,t:1527264947925};\\\", \\\"{x:1433,y:839,t:1527264947942};\\\", \\\"{x:1554,y:864,t:1527264947958};\\\", \\\"{x:1649,y:880,t:1527264947976};\\\", \\\"{x:1717,y:899,t:1527264947992};\\\", \\\"{x:1755,y:907,t:1527264948009};\\\", \\\"{x:1817,y:921,t:1527264948026};\\\", \\\"{x:1841,y:924,t:1527264948042};\\\", \\\"{x:1858,y:927,t:1527264948059};\\\", \\\"{x:1865,y:932,t:1527264948076};\\\", \\\"{x:1880,y:933,t:1527264948093};\\\", \\\"{x:1898,y:940,t:1527264948109};\\\", \\\"{x:1911,y:951,t:1527264948126};\\\", \\\"{x:1915,y:952,t:1527264948142};\\\", \\\"{x:1915,y:955,t:1527264948174};\\\", \\\"{x:1915,y:959,t:1527264948181};\\\", \\\"{x:1913,y:960,t:1527264948192};\\\", \\\"{x:1913,y:962,t:1527264948208};\\\", \\\"{x:1906,y:962,t:1527264948365};\\\", \\\"{x:1891,y:962,t:1527264948376};\\\", \\\"{x:1865,y:960,t:1527264948392};\\\", \\\"{x:1859,y:954,t:1527264948408};\\\", \\\"{x:1849,y:951,t:1527264948425};\\\", \\\"{x:1836,y:948,t:1527264948442};\\\", \\\"{x:1834,y:945,t:1527264948458};\\\", \\\"{x:1834,y:944,t:1527264948476};\\\", \\\"{x:1833,y:943,t:1527264948534};\\\", \\\"{x:1831,y:943,t:1527264948543};\\\", \\\"{x:1820,y:943,t:1527264948560};\\\", \\\"{x:1803,y:947,t:1527264948576};\\\", \\\"{x:1787,y:947,t:1527264948592};\\\", \\\"{x:1770,y:948,t:1527264948610};\\\", \\\"{x:1757,y:948,t:1527264948625};\\\", \\\"{x:1751,y:948,t:1527264948642};\\\", \\\"{x:1744,y:948,t:1527264948659};\\\", \\\"{x:1742,y:948,t:1527264948676};\\\", \\\"{x:1734,y:948,t:1527264948692};\\\", \\\"{x:1727,y:948,t:1527264948709};\\\", \\\"{x:1722,y:948,t:1527264948726};\\\", \\\"{x:1718,y:948,t:1527264948743};\\\", \\\"{x:1712,y:948,t:1527264948759};\\\", \\\"{x:1706,y:948,t:1527264948775};\\\", \\\"{x:1699,y:948,t:1527264948793};\\\", \\\"{x:1697,y:948,t:1527264948810};\\\", \\\"{x:1695,y:948,t:1527264948826};\\\", \\\"{x:1694,y:948,t:1527264948843};\\\", \\\"{x:1693,y:948,t:1527264948950};\\\", \\\"{x:1692,y:948,t:1527264950102};\\\", \\\"{x:1688,y:947,t:1527264950117};\\\", \\\"{x:1688,y:946,t:1527264950127};\\\", \\\"{x:1661,y:936,t:1527264950144};\\\", \\\"{x:1611,y:924,t:1527264950161};\\\", \\\"{x:1560,y:912,t:1527264950177};\\\", \\\"{x:1438,y:893,t:1527264950194};\\\", \\\"{x:1285,y:864,t:1527264950211};\\\", \\\"{x:1086,y:834,t:1527264950227};\\\", \\\"{x:876,y:767,t:1527264950245};\\\", \\\"{x:608,y:666,t:1527264950261};\\\", \\\"{x:475,y:621,t:1527264950279};\\\", \\\"{x:371,y:580,t:1527264950294};\\\", \\\"{x:339,y:556,t:1527264950328};\\\", \\\"{x:337,y:555,t:1527264950343};\\\", \\\"{x:338,y:553,t:1527264950412};\\\", \\\"{x:340,y:553,t:1527264950427};\\\", \\\"{x:345,y:549,t:1527264950444};\\\", \\\"{x:346,y:549,t:1527264950460};\\\", \\\"{x:348,y:547,t:1527264950501};\\\", \\\"{x:352,y:547,t:1527264950510};\\\", \\\"{x:370,y:544,t:1527264950528};\\\", \\\"{x:391,y:545,t:1527264950544};\\\", \\\"{x:418,y:547,t:1527264950561};\\\", \\\"{x:430,y:550,t:1527264950577};\\\", \\\"{x:449,y:553,t:1527264950594};\\\", \\\"{x:463,y:557,t:1527264950610};\\\", \\\"{x:478,y:560,t:1527264950627};\\\", \\\"{x:486,y:562,t:1527264950644};\\\", \\\"{x:498,y:566,t:1527264950660};\\\", \\\"{x:499,y:570,t:1527264950678};\\\", \\\"{x:508,y:571,t:1527264950694};\\\", \\\"{x:520,y:575,t:1527264950711};\\\", \\\"{x:538,y:579,t:1527264950728};\\\", \\\"{x:548,y:580,t:1527264950744};\\\", \\\"{x:560,y:583,t:1527264950760};\\\", \\\"{x:567,y:585,t:1527264950777};\\\", \\\"{x:573,y:589,t:1527264950794};\\\", \\\"{x:581,y:591,t:1527264950810};\\\", \\\"{x:584,y:593,t:1527264950828};\\\", \\\"{x:586,y:593,t:1527264950844};\\\", \\\"{x:587,y:593,t:1527264950860};\\\", \\\"{x:589,y:593,t:1527264950878};\\\", \\\"{x:590,y:593,t:1527264950894};\\\", \\\"{x:593,y:593,t:1527264950910};\\\", \\\"{x:594,y:592,t:1527264951485};\\\", \\\"{x:597,y:590,t:1527264951494};\\\", \\\"{x:599,y:589,t:1527264951511};\\\", \\\"{x:601,y:589,t:1527264951527};\\\", \\\"{x:604,y:589,t:1527264951544};\\\", \\\"{x:605,y:588,t:1527264951561};\\\", \\\"{x:606,y:588,t:1527264951578};\\\", \\\"{x:607,y:587,t:1527264951594};\\\", \\\"{x:605,y:588,t:1527264951748};\\\", \\\"{x:602,y:589,t:1527264951761};\\\", \\\"{x:594,y:590,t:1527264951779};\\\", \\\"{x:581,y:590,t:1527264951794};\\\", \\\"{x:564,y:590,t:1527264951811};\\\", \\\"{x:544,y:590,t:1527264951828};\\\", \\\"{x:534,y:590,t:1527264951844};\\\", \\\"{x:522,y:590,t:1527264951862};\\\", \\\"{x:513,y:590,t:1527264951878};\\\", \\\"{x:508,y:590,t:1527264951894};\\\", \\\"{x:489,y:590,t:1527264951913};\\\", \\\"{x:474,y:590,t:1527264951929};\\\", \\\"{x:468,y:590,t:1527264951945};\\\", \\\"{x:467,y:590,t:1527264951961};\\\", \\\"{x:462,y:590,t:1527264951979};\\\", \\\"{x:456,y:590,t:1527264951995};\\\", \\\"{x:450,y:592,t:1527264952011};\\\", \\\"{x:445,y:594,t:1527264952028};\\\", \\\"{x:443,y:594,t:1527264952045};\\\", \\\"{x:436,y:594,t:1527264952062};\\\", \\\"{x:424,y:596,t:1527264952078};\\\", \\\"{x:410,y:596,t:1527264952097};\\\", \\\"{x:396,y:596,t:1527264952111};\\\", \\\"{x:382,y:596,t:1527264952128};\\\", \\\"{x:376,y:596,t:1527264952146};\\\", \\\"{x:375,y:596,t:1527264952161};\\\", \\\"{x:377,y:596,t:1527264952492};\\\", \\\"{x:378,y:596,t:1527264952501};\\\", \\\"{x:383,y:596,t:1527264952513};\\\", \\\"{x:394,y:607,t:1527264952529};\\\", \\\"{x:404,y:615,t:1527264952546};\\\", \\\"{x:425,y:630,t:1527264952562};\\\", \\\"{x:436,y:645,t:1527264952579};\\\", \\\"{x:455,y:662,t:1527264952596};\\\", \\\"{x:474,y:679,t:1527264952612};\\\", \\\"{x:482,y:688,t:1527264952629};\\\", \\\"{x:484,y:689,t:1527264952646};\\\", \\\"{x:485,y:692,t:1527264952663};\\\", \\\"{x:487,y:695,t:1527264952679};\\\", \\\"{x:487,y:696,t:1527264952701};\\\", \\\"{x:488,y:696,t:1527264952717};\\\", \\\"{x:489,y:696,t:1527264952749};\\\", \\\"{x:489,y:697,t:1527264952763};\\\", \\\"{x:489,y:698,t:1527264952779};\\\", \\\"{x:489,y:700,t:1527264953398};\\\", \\\"{x:494,y:704,t:1527264953413};\\\", \\\"{x:495,y:706,t:1527264953429};\\\", \\\"{x:496,y:710,t:1527264953446};\\\", \\\"{x:502,y:713,t:1527264953463};\\\", \\\"{x:510,y:716,t:1527264953478};\\\", \\\"{x:511,y:717,t:1527264953496};\\\", \\\"{x:517,y:721,t:1527264953513};\\\", \\\"{x:526,y:727,t:1527264953529};\\\", \\\"{x:541,y:736,t:1527264953547};\\\", \\\"{x:549,y:742,t:1527264953562};\\\", \\\"{x:560,y:750,t:1527264953580};\\\", \\\"{x:562,y:752,t:1527264953597};\\\", \\\"{x:563,y:754,t:1527264953613};\\\", \\\"{x:564,y:756,t:1527264953630};\\\", \\\"{x:564,y:757,t:1527264953653};\\\", \\\"{x:564,y:759,t:1527264953669};\\\", \\\"{x:565,y:760,t:1527264953681};\\\", \\\"{x:565,y:763,t:1527264953696};\\\", \\\"{x:566,y:767,t:1527264953713};\\\", \\\"{x:566,y:770,t:1527264953729};\\\", \\\"{x:566,y:771,t:1527264953748};\\\", \\\"{x:566,y:772,t:1527264953763};\\\", \\\"{x:566,y:773,t:1527264953779};\\\", \\\"{x:566,y:774,t:1527264954189};\\\", \\\"{x:565,y:774,t:1527264954198};\\\", \\\"{x:562,y:769,t:1527264954214};\\\", \\\"{x:555,y:764,t:1527264954232};\\\", \\\"{x:548,y:759,t:1527264954246};\\\", \\\"{x:545,y:757,t:1527264954263};\\\", \\\"{x:544,y:756,t:1527264954280};\\\", \\\"{x:543,y:756,t:1527264954381};\\\" ] }, { \\\"rt\\\": 178074, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 20, \\\"time_elapsed\\\": 717646, \\\"internal_node_id\\\": \\\"0.0-7.0-0.0\\\", \\\"subject\\\": \\\"RV9F6\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"lima\\\", \\\"condition\\\": \\\"115\\\", \\\"q\\\": 16, \\\"answer\\\": \\\"To determine the events that start at 12 pm, you must first locate 12 pm on the x-axis. Once you find the location of 12 pm on the x-axis, follow the line with the positive slope that stems out from the 12 pm mark. Every shift that is along that line will start at 12 pm. In this case, shifts M and L are found on that line, meaning that they will both start at 12 pm.\\\", \\\"block\\\": \\\"triangular_testing\\\" }, { \\\"rt\\\": 14070, \\\"responses\\\": \\\"{\\\\\\\"Q0\\\\\\\":\\\\\\\"19\\\\\\\",\\\\\\\"Q1\\\\\\\":\\\\\\\"United States of America\\\\\\\"}\\\", \\\"block\\\": \\\"demo-1\\\", \\\"trial_type\\\": \\\"survey-text\\\", \\\"trial_index\\\": 21, \\\"time_elapsed\\\": 732721, \\\"internal_node_id\\\": \\\"0.0-8.0\\\", \\\"subject\\\": \\\"RV9F6\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"lima\\\", \\\"condition\\\": \\\"115\\\" }, { \\\"rt\\\": 13820, \\\"responses\\\": \\\"{\\\\\\\"Q0\\\\\\\":\\\\\\\"English\\\\\\\",\\\\\\\"Q1\\\\\\\":\\\\\\\"First\\\\\\\",\\\\\\\"Q2\\\\\\\":\\\\\\\"Social Sciences (incl. CogSci)\\\\\\\",\\\\\\\"Q3\\\\\\\":\\\\\\\"Male\\\\\\\"}\\\", \\\"block\\\": \\\"demo-2\\\", \\\"trial_type\\\": \\\"survey-multi-choice\\\", \\\"trial_index\\\": 22, \\\"time_elapsed\\\": 747555, \\\"internal_node_id\\\": \\\"0.0-9.0\\\", \\\"subject\\\": \\\"RV9F6\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"lima\\\", \\\"condition\\\": \\\"115\\\" }, { \\\"rt\\\": 68976, \\\"url\\\": \\\"../views/src/external/debrief.html\\\", \\\"block\\\": \\\"debrief\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 23, \\\"time_elapsed\\\": 817876, \\\"internal_node_id\\\": \\\"0.0-10.0\\\", \\\"subject\\\": \\\"RV9F6\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"lima\\\", \\\"condition\\\": \\\"115\\\" } ]\",\"parentNode\":{\"id\":2765}}],[],[]]}"
    }
  ],
  "initialDom": "{\"f\":\"initialize\",\"args\":[1,[{\"nodeType\":10,\"id\":2,\"name\":\"html\",\"publicId\":\"\",\"systemId\":\"\"},{\"nodeType\":1,\"id\":3,\"tagName\":\"HTML\",\"attributes\":{\"class\":\"fa-events-icons-ready\"},\"childNodes\":[{\"nodeType\":1,\"id\":4,\"tagName\":\"HEAD\",\"attributes\":{},\"childNodes\":[{\"nodeType\":3,\"id\":5,\"textContent\":\" \"},{\"nodeType\":1,\"id\":6,\"tagName\":\"TITLE\",\"attributes\":{},\"childNodes\":[{\"nodeType\":3,\"id\":7,\"textContent\":\"FOX2YP\"}]},{\"nodeType\":3,\"id\":8,\"textContent\":\" \"},{\"nodeType\":8,\"id\":9},{\"nodeType\":3,\"id\":10,\"textContent\":\" \"},{\"nodeType\":1,\"id\":11,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":12,\"textContent\":\" \"},{\"nodeType\":1,\"id\":13,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":14,\"textContent\":\" \"},{\"nodeType\":1,\"id\":15,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":16,\"textContent\":\" \"},{\"nodeType\":1,\"id\":17,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":18,\"textContent\":\" \"},{\"nodeType\":1,\"id\":19,\"tagName\":\"SCRIPT\"},{\"nodeType\":1,\"id\":20,\"tagName\":\"LINK\",\"attributes\":{\"href\":\"https://use.fontawesome.com/945539d961.css\",\"media\":\"all\",\"rel\":\"stylesheet\"}},{\"nodeType\":3,\"id\":21,\"textContent\":\" \"},{\"nodeType\":8,\"id\":22},{\"nodeType\":3,\"id\":23,\"textContent\":\" \"},{\"nodeType\":1,\"id\":24,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":25,\"textContent\":\" \"},{\"nodeType\":1,\"id\":26,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":27,\"textContent\":\" \"},{\"nodeType\":1,\"id\":28,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":29,\"textContent\":\" \"},{\"nodeType\":1,\"id\":30,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":31,\"textContent\":\" \"},{\"nodeType\":1,\"id\":32,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":33,\"textContent\":\" \"},{\"nodeType\":1,\"id\":34,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":35,\"textContent\":\" \"},{\"nodeType\":1,\"id\":36,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":37,\"textContent\":\" \"},{\"nodeType\":8,\"id\":38},{\"nodeType\":3,\"id\":39,\"textContent\":\" \"},{\"nodeType\":1,\"id\":40,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":41,\"textContent\":\" \"},{\"nodeType\":8,\"id\":42},{\"nodeType\":3,\"id\":43,\"textContent\":\" \"},{\"nodeType\":8,\"id\":44},{\"nodeType\":3,\"id\":45,\"textContent\":\" \"},{\"nodeType\":1,\"id\":46,\"tagName\":\"LINK\",\"attributes\":{\"href\":\"../views/jsPsych/css/jspsych.css\",\"rel\":\"stylesheet\",\"type\":\"text/css\"}},{\"nodeType\":3,\"id\":47,\"textContent\":\" \"},{\"nodeType\":1,\"id\":48,\"tagName\":\"LINK\",\"attributes\":{\"href\":\"../css/styles.css\",\"rel\":\"stylesheet\",\"type\":\"text/css\"}},{\"nodeType\":3,\"id\":49,\"textContent\":\" \"},{\"nodeType\":1,\"id\":50,\"tagName\":\"SCRIPT\"},{\"nodeType\":1,\"id\":51,\"tagName\":\"SCRIPT\"}]},{\"nodeType\":3,\"id\":52,\"textContent\":\" \"},{\"nodeType\":8,\"id\":53},{\"nodeType\":3,\"id\":54,\"textContent\":\" \"},{\"nodeType\":1,\"id\":55,\"tagName\":\"BODY\",\"attributes\":{\"class\":\"jspsych-display-element\"},\"childNodes\":[{\"nodeType\":3,\"id\":56,\"textContent\":\" \"},{\"nodeType\":1,\"id\":57,\"tagName\":\"META\",\"attributes\":{\"charset\":\"utf-8\"}},{\"nodeType\":3,\"id\":58,\"textContent\":\" \"},{\"nodeType\":8,\"id\":59},{\"nodeType\":3,\"id\":60,\"textContent\":\" \"},{\"nodeType\":1,\"id\":61,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":62,\"textContent\":\" \"},{\"nodeType\":1,\"id\":63,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":64,\"textContent\":\" \"},{\"nodeType\":1,\"id\":65,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":66,\"textContent\":\" \"},{\"nodeType\":1,\"id\":67,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":68,\"textContent\":\" \"},{\"nodeType\":1,\"id\":69,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":70,\"textContent\":\" \"},{\"nodeType\":1,\"id\":71,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":72,\"textContent\":\" \"},{\"nodeType\":1,\"id\":73,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"stimulus\"},\"childNodes\":[{\"nodeType\":3,\"id\":74,\"textContent\":\" \"},{\"nodeType\":1,\"id\":75,\"tagName\":\"P\",\"attributes\":{\"class\":\"userid\",\"id\":\"userid\"},\"childNodes\":[{\"nodeType\":3,\"id\":76,\"textContent\":\"RV9F6\"}]},{\"nodeType\":3,\"id\":77,\"textContent\":\" \"},{\"nodeType\":1,\"id\":78,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"userinput\"},\"childNodes\":[{\"nodeType\":3,\"id\":79,\"textContent\":\" \"},{\"nodeType\":8,\"id\":80},{\"nodeType\":3,\"id\":81,\"textContent\":\" \"},{\"nodeType\":1,\"id\":82,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"legend\",\"id\":\"hint-interactive\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":83,\"textContent\":\" \"},{\"nodeType\":1,\"id\":84,\"tagName\":\"P\",\"attributes\":{},\"childNodes\":[{\"nodeType\":3,\"id\":85,\"textContent\":\"Hint: Hover your mouse over the data points in the graph\"}]},{\"nodeType\":3,\"id\":86,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":87,\"textContent\":\" \"},{\"nodeType\":8,\"id\":88},{\"nodeType\":3,\"id\":89,\"textContent\":\" \"},{\"nodeType\":8,\"id\":90},{\"nodeType\":3,\"id\":91,\"textContent\":\" \"},{\"nodeType\":1,\"id\":92,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"test\"},\"childNodes\":[{\"nodeType\":3,\"id\":93,\"textContent\":\" \"},{\"nodeType\":1,\"id\":94,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"acme\",\"id\":\"acme.starttime\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":95,\"textContent\":\" \"},{\"nodeType\":1,\"id\":96,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":97,\"textContent\":\"Which shift(s) start at 11 am? \"}]},{\"nodeType\":3,\"id\":98,\"textContent\":\" \"},{\"nodeType\":1,\"id\":99,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":100,\"textContent\":\" \"},{\"nodeType\":1,\"id\":101,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":102,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":103,\"textContent\":\" \"},{\"nodeType\":1,\"id\":104,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":105,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":106,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":107,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":108,\"textContent\":\" \"},{\"nodeType\":1,\"id\":109,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":110,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":111,\"textContent\":\" \"},{\"nodeType\":1,\"id\":112,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":113,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":114,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":115,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":116,\"textContent\":\" \"},{\"nodeType\":1,\"id\":117,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":118,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":119,\"textContent\":\" \"},{\"nodeType\":1,\"id\":120,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":121,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":122,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":123,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":124,\"textContent\":\" \"},{\"nodeType\":1,\"id\":125,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":126,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":127,\"textContent\":\" \"},{\"nodeType\":1,\"id\":128,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":129,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":130,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":131,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":132,\"textContent\":\" \"},{\"nodeType\":1,\"id\":133,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":134,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":135,\"textContent\":\" \"},{\"nodeType\":1,\"id\":136,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":137,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":138,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":139,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":140,\"textContent\":\" \"},{\"nodeType\":1,\"id\":141,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":142,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":143,\"textContent\":\" \"},{\"nodeType\":1,\"id\":144,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":145,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":146,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":147,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":148,\"textContent\":\" \"},{\"nodeType\":1,\"id\":149,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":150,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":151,\"textContent\":\" \"},{\"nodeType\":1,\"id\":152,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":153,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":154,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":155,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":156,\"textContent\":\" \"},{\"nodeType\":1,\"id\":157,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":158,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":159,\"textContent\":\" \"},{\"nodeType\":1,\"id\":160,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":161,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":162,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":163,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":164,\"textContent\":\" \"},{\"nodeType\":1,\"id\":165,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":166,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":167,\"textContent\":\" \"},{\"nodeType\":1,\"id\":168,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":169,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":170,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":171,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":172,\"textContent\":\" \"},{\"nodeType\":1,\"id\":173,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":174,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":175,\"textContent\":\" \"},{\"nodeType\":1,\"id\":176,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":177,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":178,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":179,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":180,\"textContent\":\" \"},{\"nodeType\":1,\"id\":181,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":182,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":183,\"textContent\":\" \"},{\"nodeType\":1,\"id\":184,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"U\",\"value\":\"\"}},{\"nodeType\":3,\"id\":185,\"textContent\":\"U \"},{\"nodeType\":1,\"id\":186,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":187,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":188,\"textContent\":\" \"},{\"nodeType\":1,\"id\":189,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":190,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":191,\"textContent\":\" \"},{\"nodeType\":1,\"id\":192,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":193,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":194,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":195,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":196,\"textContent\":\" \"},{\"nodeType\":1,\"id\":197,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":198,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":199,\"textContent\":\" \"},{\"nodeType\":1,\"id\":200,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":201,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":202,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":203,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":204,\"textContent\":\" \"},{\"nodeType\":1,\"id\":205,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":206,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":207,\"textContent\":\" \"},{\"nodeType\":1,\"id\":208,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":209,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":210,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":211,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":212,\"textContent\":\" \"},{\"nodeType\":1,\"id\":213,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":214,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":215,\"textContent\":\" \"},{\"nodeType\":1,\"id\":216,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":217,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":218,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":219,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":220,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":221,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":222,\"textContent\":\" \"},{\"nodeType\":1,\"id\":223,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"acme\",\"id\":\"acme.starts\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":224,\"textContent\":\" \"},{\"nodeType\":1,\"id\":225,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":226,\"textContent\":\"Which shift(s) start at the same time as D?\"}]},{\"nodeType\":3,\"id\":227,\"textContent\":\" \"},{\"nodeType\":1,\"id\":228,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":229,\"textContent\":\" \"},{\"nodeType\":1,\"id\":230,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":231,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":232,\"textContent\":\" \"},{\"nodeType\":1,\"id\":233,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":234,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":235,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":236,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":237,\"textContent\":\" \"},{\"nodeType\":1,\"id\":238,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":239,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":240,\"textContent\":\" \"},{\"nodeType\":1,\"id\":241,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":242,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":243,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":244,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":245,\"textContent\":\" \"},{\"nodeType\":1,\"id\":246,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":247,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":248,\"textContent\":\" \"},{\"nodeType\":1,\"id\":249,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":250,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":251,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":252,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":253,\"textContent\":\" \"},{\"nodeType\":1,\"id\":254,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":255,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":256,\"textContent\":\" \"},{\"nodeType\":1,\"id\":257,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":258,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":259,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":260,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":261,\"textContent\":\" \"},{\"nodeType\":1,\"id\":262,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":263,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":264,\"textContent\":\" \"},{\"nodeType\":1,\"id\":265,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":266,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":267,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":268,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":269,\"textContent\":\" \"},{\"nodeType\":1,\"id\":270,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":271,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":272,\"textContent\":\" \"},{\"nodeType\":1,\"id\":273,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":274,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":275,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":276,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":277,\"textContent\":\" \"},{\"nodeType\":1,\"id\":278,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":279,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":280,\"textContent\":\" \"},{\"nodeType\":1,\"id\":281,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":282,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":283,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":284,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":285,\"textContent\":\" \"},{\"nodeType\":1,\"id\":286,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":287,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":288,\"textContent\":\" \"},{\"nodeType\":1,\"id\":289,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":290,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":291,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":292,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":293,\"textContent\":\" \"},{\"nodeType\":1,\"id\":294,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":295,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":296,\"textContent\":\" \"},{\"nodeType\":1,\"id\":297,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":298,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":299,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":300,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":301,\"textContent\":\" \"},{\"nodeType\":1,\"id\":302,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":303,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":304,\"textContent\":\" \"},{\"nodeType\":1,\"id\":305,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":306,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":307,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":308,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":309,\"textContent\":\" \"},{\"nodeType\":1,\"id\":310,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":311,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":312,\"textContent\":\" \"},{\"nodeType\":1,\"id\":313,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"U\",\"value\":\"\"}},{\"nodeType\":3,\"id\":314,\"textContent\":\"U \"},{\"nodeType\":1,\"id\":315,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":316,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":317,\"textContent\":\" \"},{\"nodeType\":1,\"id\":318,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":319,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":320,\"textContent\":\" \"},{\"nodeType\":1,\"id\":321,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":322,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":323,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":324,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":325,\"textContent\":\" \"},{\"nodeType\":1,\"id\":326,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":327,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":328,\"textContent\":\" \"},{\"nodeType\":1,\"id\":329,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":330,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":331,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":332,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":333,\"textContent\":\" \"},{\"nodeType\":1,\"id\":334,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":335,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":336,\"textContent\":\" \"},{\"nodeType\":1,\"id\":337,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":338,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":339,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":340,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":341,\"textContent\":\" \"},{\"nodeType\":1,\"id\":342,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":343,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":344,\"textContent\":\" \"},{\"nodeType\":1,\"id\":345,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":346,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":347,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":348,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":349,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":350,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":351,\"textContent\":\" \"},{\"nodeType\":1,\"id\":352,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"acme\",\"id\":\"acme.meets\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":353,\"textContent\":\" \"},{\"nodeType\":1,\"id\":354,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":355,\"textContent\":\"Which shift(s) begin when C ends?\"}]},{\"nodeType\":3,\"id\":356,\"textContent\":\" \"},{\"nodeType\":1,\"id\":357,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":358,\"textContent\":\" \"},{\"nodeType\":1,\"id\":359,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":360,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":361,\"textContent\":\" \"},{\"nodeType\":1,\"id\":362,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":363,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":364,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":365,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":366,\"textContent\":\" \"},{\"nodeType\":1,\"id\":367,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":368,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":369,\"textContent\":\" \"},{\"nodeType\":1,\"id\":370,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":371,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":372,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":373,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":374,\"textContent\":\" \"},{\"nodeType\":1,\"id\":375,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":376,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":377,\"textContent\":\" \"},{\"nodeType\":1,\"id\":378,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":379,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":380,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":381,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":382,\"textContent\":\" \"},{\"nodeType\":1,\"id\":383,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":384,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":385,\"textContent\":\" \"},{\"nodeType\":1,\"id\":386,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":387,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":388,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":389,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":390,\"textContent\":\" \"},{\"nodeType\":1,\"id\":391,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":392,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":393,\"textContent\":\" \"},{\"nodeType\":1,\"id\":394,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":395,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":396,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":397,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":398,\"textContent\":\" \"},{\"nodeType\":1,\"id\":399,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":400,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":401,\"textContent\":\" \"},{\"nodeType\":1,\"id\":402,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":403,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":404,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":405,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":406,\"textContent\":\" \"},{\"nodeType\":1,\"id\":407,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":408,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":409,\"textContent\":\" \"},{\"nodeType\":1,\"id\":410,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":411,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":412,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":413,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":414,\"textContent\":\" \"},{\"nodeType\":1,\"id\":415,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":416,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":417,\"textContent\":\" \"},{\"nodeType\":1,\"id\":418,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":419,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":420,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":421,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":422,\"textContent\":\" \"},{\"nodeType\":1,\"id\":423,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":424,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":425,\"textContent\":\" \"},{\"nodeType\":1,\"id\":426,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":427,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":428,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":429,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":430,\"textContent\":\" \"},{\"nodeType\":1,\"id\":431,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":432,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":433,\"textContent\":\" \"},{\"nodeType\":1,\"id\":434,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":435,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":436,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":437,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":438,\"textContent\":\" \"},{\"nodeType\":1,\"id\":439,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":440,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":441,\"textContent\":\" \"},{\"nodeType\":1,\"id\":442,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"U\",\"value\":\"\"}},{\"nodeType\":3,\"id\":443,\"textContent\":\"U \"},{\"nodeType\":1,\"id\":444,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":445,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":446,\"textContent\":\" \"},{\"nodeType\":1,\"id\":447,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":448,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":449,\"textContent\":\" \"},{\"nodeType\":1,\"id\":450,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":451,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":452,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":453,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":454,\"textContent\":\" \"},{\"nodeType\":1,\"id\":455,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":456,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":457,\"textContent\":\" \"},{\"nodeType\":1,\"id\":458,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":459,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":460,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":461,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":462,\"textContent\":\" \"},{\"nodeType\":1,\"id\":463,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":464,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":465,\"textContent\":\" \"},{\"nodeType\":1,\"id\":466,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":467,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":468,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":469,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":470,\"textContent\":\" \"},{\"nodeType\":1,\"id\":471,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":472,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":473,\"textContent\":\" \"},{\"nodeType\":1,\"id\":474,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":475,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":476,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":477,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":478,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":479,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":480,\"textContent\":\" \"},{\"nodeType\":1,\"id\":481,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"acme\",\"id\":\"acme.endtime\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":482,\"textContent\":\" \"},{\"nodeType\":1,\"id\":483,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":484,\"textContent\":\" Which shift(s) end at 4 pm?\"}]},{\"nodeType\":3,\"id\":485,\"textContent\":\" \"},{\"nodeType\":1,\"id\":486,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":487,\"textContent\":\" \"},{\"nodeType\":1,\"id\":488,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":489,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":490,\"textContent\":\" \"},{\"nodeType\":1,\"id\":491,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":492,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":493,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":494,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":495,\"textContent\":\" \"},{\"nodeType\":1,\"id\":496,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":497,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":498,\"textContent\":\" \"},{\"nodeType\":1,\"id\":499,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":500,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":501,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":502,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":503,\"textContent\":\" \"},{\"nodeType\":1,\"id\":504,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":505,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":506,\"textContent\":\" \"},{\"nodeType\":1,\"id\":507,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":508,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":509,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":510,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":511,\"textContent\":\" \"},{\"nodeType\":1,\"id\":512,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":513,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":514,\"textContent\":\" \"},{\"nodeType\":1,\"id\":515,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":516,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":517,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":518,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":519,\"textContent\":\" \"},{\"nodeType\":1,\"id\":520,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":521,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":522,\"textContent\":\" \"},{\"nodeType\":1,\"id\":523,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":524,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":525,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":526,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":527,\"textContent\":\" \"},{\"nodeType\":1,\"id\":528,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":529,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":530,\"textContent\":\" \"},{\"nodeType\":1,\"id\":531,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":532,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":533,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":534,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":535,\"textContent\":\" \"},{\"nodeType\":1,\"id\":536,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":537,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":538,\"textContent\":\" \"},{\"nodeType\":1,\"id\":539,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":540,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":541,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":542,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":543,\"textContent\":\" \"},{\"nodeType\":1,\"id\":544,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":545,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":546,\"textContent\":\" \"},{\"nodeType\":1,\"id\":547,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":548,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":549,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":550,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":551,\"textContent\":\" \"},{\"nodeType\":1,\"id\":552,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":553,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":554,\"textContent\":\" \"},{\"nodeType\":1,\"id\":555,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":556,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":557,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":558,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":559,\"textContent\":\" \"},{\"nodeType\":1,\"id\":560,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":561,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":562,\"textContent\":\" \"},{\"nodeType\":1,\"id\":563,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":564,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":565,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":566,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":567,\"textContent\":\" \"},{\"nodeType\":1,\"id\":568,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":569,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":570,\"textContent\":\" \"},{\"nodeType\":1,\"id\":571,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"U\",\"value\":\"\"}},{\"nodeType\":3,\"id\":572,\"textContent\":\"U \"},{\"nodeType\":1,\"id\":573,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":574,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":575,\"textContent\":\" \"},{\"nodeType\":1,\"id\":576,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":577,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":578,\"textContent\":\" \"},{\"nodeType\":1,\"id\":579,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":580,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":581,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":582,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":583,\"textContent\":\" \"},{\"nodeType\":1,\"id\":584,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":585,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":586,\"textContent\":\" \"},{\"nodeType\":1,\"id\":587,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":588,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":589,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":590,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":591,\"textContent\":\" \"},{\"nodeType\":1,\"id\":592,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":593,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":594,\"textContent\":\" \"},{\"nodeType\":1,\"id\":595,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":596,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":597,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":598,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":599,\"textContent\":\" \"},{\"nodeType\":1,\"id\":600,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":601,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":602,\"textContent\":\" \"},{\"nodeType\":1,\"id\":603,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":604,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":605,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":606,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":607,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":608,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":609,\"textContent\":\" \"},{\"nodeType\":1,\"id\":610,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"acme\",\"id\":\"acme.midpoint\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":611,\"textContent\":\" \"},{\"nodeType\":1,\"id\":612,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":613,\"textContent\":\"Coffee breaks happen halfway through a shift.\"},{\"nodeType\":1,\"id\":614,\"tagName\":\"BR\",\"attributes\":{}},{\"nodeType\":3,\"id\":615,\"textContent\":\" Which shift(s) share a break with I?\"}]},{\"nodeType\":3,\"id\":616,\"textContent\":\" \"},{\"nodeType\":1,\"id\":617,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":618,\"textContent\":\" \"},{\"nodeType\":1,\"id\":619,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":620,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":621,\"textContent\":\" \"},{\"nodeType\":1,\"id\":622,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":623,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":624,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":625,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":626,\"textContent\":\" \"},{\"nodeType\":1,\"id\":627,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":628,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":629,\"textContent\":\" \"},{\"nodeType\":1,\"id\":630,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":631,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":632,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":633,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":634,\"textContent\":\" \"},{\"nodeType\":1,\"id\":635,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":636,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":637,\"textContent\":\" \"},{\"nodeType\":1,\"id\":638,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":639,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":640,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":641,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":642,\"textContent\":\" \"},{\"nodeType\":1,\"id\":643,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":644,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":645,\"textContent\":\" \"},{\"nodeType\":1,\"id\":646,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":647,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":648,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":649,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":650,\"textContent\":\" \"},{\"nodeType\":1,\"id\":651,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":652,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":653,\"textContent\":\" \"},{\"nodeType\":1,\"id\":654,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":655,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":656,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":657,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":658,\"textContent\":\" \"},{\"nodeType\":1,\"id\":659,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":660,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":661,\"textContent\":\" \"},{\"nodeType\":1,\"id\":662,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":663,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":664,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":665,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":666,\"textContent\":\" \"},{\"nodeType\":1,\"id\":667,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":668,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":669,\"textContent\":\" \"},{\"nodeType\":1,\"id\":670,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":671,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":672,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":673,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":674,\"textContent\":\" \"},{\"nodeType\":1,\"id\":675,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":676,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":677,\"textContent\":\" \"},{\"nodeType\":1,\"id\":678,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":679,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":680,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":681,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":682,\"textContent\":\" \"},{\"nodeType\":1,\"id\":683,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":684,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":685,\"textContent\":\" \"},{\"nodeType\":1,\"id\":686,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":687,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":688,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":689,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":690,\"textContent\":\" \"},{\"nodeType\":1,\"id\":691,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":692,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":693,\"textContent\":\" \"},{\"nodeType\":1,\"id\":694,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":695,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":696,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":697,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":698,\"textContent\":\" \"},{\"nodeType\":1,\"id\":699,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":700,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":701,\"textContent\":\" \"},{\"nodeType\":1,\"id\":702,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"U\",\"value\":\"\"}},{\"nodeType\":3,\"id\":703,\"textContent\":\"U \"},{\"nodeType\":1,\"id\":704,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":705,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":706,\"textContent\":\" \"},{\"nodeType\":1,\"id\":707,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":708,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":709,\"textContent\":\" \"},{\"nodeType\":1,\"id\":710,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":711,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":712,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":713,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":714,\"textContent\":\" \"},{\"nodeType\":1,\"id\":715,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":716,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":717,\"textContent\":\" \"},{\"nodeType\":1,\"id\":718,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":719,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":720,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":721,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":722,\"textContent\":\" \"},{\"nodeType\":1,\"id\":723,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":724,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":725,\"textContent\":\" \"},{\"nodeType\":1,\"id\":726,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":727,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":728,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":729,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":730,\"textContent\":\" \"},{\"nodeType\":1,\"id\":731,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":732,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":733,\"textContent\":\" \"},{\"nodeType\":1,\"id\":734,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":735,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":736,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":737,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":738,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":739,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":740,\"textContent\":\" \"},{\"nodeType\":1,\"id\":741,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.duration\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":742,\"textContent\":\" \"},{\"nodeType\":1,\"id\":743,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":744,\"textContent\":\"Which shift(s) are six hours long?\"}]},{\"nodeType\":3,\"id\":745,\"textContent\":\" \"},{\"nodeType\":1,\"id\":746,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":747,\"textContent\":\" \"},{\"nodeType\":1,\"id\":748,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":749,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":750,\"textContent\":\" \"},{\"nodeType\":1,\"id\":751,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":752,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":753,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":754,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":755,\"textContent\":\" \"},{\"nodeType\":1,\"id\":756,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":757,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":758,\"textContent\":\" \"},{\"nodeType\":1,\"id\":759,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":760,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":761,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":762,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":763,\"textContent\":\" \"},{\"nodeType\":1,\"id\":764,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":765,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":766,\"textContent\":\" \"},{\"nodeType\":1,\"id\":767,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":768,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":769,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":770,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":771,\"textContent\":\" \"},{\"nodeType\":1,\"id\":772,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":773,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":774,\"textContent\":\" \"},{\"nodeType\":1,\"id\":775,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":776,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":777,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":778,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":779,\"textContent\":\" \"},{\"nodeType\":1,\"id\":780,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":781,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":782,\"textContent\":\" \"},{\"nodeType\":1,\"id\":783,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":784,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":785,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":786,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":787,\"textContent\":\" \"},{\"nodeType\":1,\"id\":788,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":789,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":790,\"textContent\":\" \"},{\"nodeType\":1,\"id\":791,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":792,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":793,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":794,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":795,\"textContent\":\" \"},{\"nodeType\":1,\"id\":796,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":797,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":798,\"textContent\":\" \"},{\"nodeType\":1,\"id\":799,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":800,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":801,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":802,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":803,\"textContent\":\" \"},{\"nodeType\":1,\"id\":804,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":805,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":806,\"textContent\":\" \"},{\"nodeType\":1,\"id\":807,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":808,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":809,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":810,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":811,\"textContent\":\" \"},{\"nodeType\":1,\"id\":812,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":813,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":814,\"textContent\":\" \"},{\"nodeType\":1,\"id\":815,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":816,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":817,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":818,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":819,\"textContent\":\" \"},{\"nodeType\":1,\"id\":820,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":821,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":822,\"textContent\":\" \"},{\"nodeType\":1,\"id\":823,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":824,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":825,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":826,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":827,\"textContent\":\" \"},{\"nodeType\":1,\"id\":828,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":829,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":830,\"textContent\":\" \"},{\"nodeType\":1,\"id\":831,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":832,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":833,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":834,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":835,\"textContent\":\" \"},{\"nodeType\":1,\"id\":836,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":837,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":838,\"textContent\":\" \"},{\"nodeType\":1,\"id\":839,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":840,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":841,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":842,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":843,\"textContent\":\" \"},{\"nodeType\":1,\"id\":844,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":845,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":846,\"textContent\":\" \"},{\"nodeType\":1,\"id\":847,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":848,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":849,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":850,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":851,\"textContent\":\" \"},{\"nodeType\":1,\"id\":852,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":853,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":854,\"textContent\":\" \"},{\"nodeType\":1,\"id\":855,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":856,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":857,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":858,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":859,\"textContent\":\" \"},{\"nodeType\":1,\"id\":860,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":861,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":862,\"textContent\":\" \"},{\"nodeType\":1,\"id\":863,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":864,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":865,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":866,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":867,\"textContent\":\" \"},{\"nodeType\":1,\"id\":868,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":869,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":870,\"textContent\":\" \"},{\"nodeType\":1,\"id\":871,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":872,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":873,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":874,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":875,\"textContent\":\" \"},{\"nodeType\":1,\"id\":876,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":877,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":878,\"textContent\":\" \"},{\"nodeType\":1,\"id\":879,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":880,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":881,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":882,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":883,\"textContent\":\" \"},{\"nodeType\":1,\"id\":884,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":885,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":886,\"textContent\":\" \"},{\"nodeType\":1,\"id\":887,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":888,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":889,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":890,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":891,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":892,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":893,\"textContent\":\" \"},{\"nodeType\":1,\"id\":894,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.duration+starts\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":895,\"textContent\":\" \"},{\"nodeType\":1,\"id\":896,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":897,\"textContent\":\"Which 2 shifts less than 5 hours long start at the same time?\"}]},{\"nodeType\":3,\"id\":898,\"textContent\":\" \"},{\"nodeType\":1,\"id\":899,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":900,\"textContent\":\" \"},{\"nodeType\":1,\"id\":901,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":902,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":903,\"textContent\":\" \"},{\"nodeType\":1,\"id\":904,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":905,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":906,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":907,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":908,\"textContent\":\" \"},{\"nodeType\":1,\"id\":909,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":910,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":911,\"textContent\":\" \"},{\"nodeType\":1,\"id\":912,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":913,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":914,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":915,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":916,\"textContent\":\" \"},{\"nodeType\":1,\"id\":917,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":918,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":919,\"textContent\":\" \"},{\"nodeType\":1,\"id\":920,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":921,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":922,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":923,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":924,\"textContent\":\" \"},{\"nodeType\":1,\"id\":925,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":926,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":927,\"textContent\":\" \"},{\"nodeType\":1,\"id\":928,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":929,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":930,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":931,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":932,\"textContent\":\" \"},{\"nodeType\":1,\"id\":933,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":934,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":935,\"textContent\":\" \"},{\"nodeType\":1,\"id\":936,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":937,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":938,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":939,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":940,\"textContent\":\" \"},{\"nodeType\":1,\"id\":941,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":942,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":943,\"textContent\":\" \"},{\"nodeType\":1,\"id\":944,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":945,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":946,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":947,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":948,\"textContent\":\" \"},{\"nodeType\":1,\"id\":949,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":950,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":951,\"textContent\":\" \"},{\"nodeType\":1,\"id\":952,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":953,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":954,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":955,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":956,\"textContent\":\" \"},{\"nodeType\":1,\"id\":957,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":958,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":959,\"textContent\":\" \"},{\"nodeType\":1,\"id\":960,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":961,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":962,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":963,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":964,\"textContent\":\" \"},{\"nodeType\":1,\"id\":965,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":966,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":967,\"textContent\":\" \"},{\"nodeType\":1,\"id\":968,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":969,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":970,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":971,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":972,\"textContent\":\" \"},{\"nodeType\":1,\"id\":973,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":974,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":975,\"textContent\":\" \"},{\"nodeType\":1,\"id\":976,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":977,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":978,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":979,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":980,\"textContent\":\" \"},{\"nodeType\":1,\"id\":981,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":982,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":983,\"textContent\":\" \"},{\"nodeType\":1,\"id\":984,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":985,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":986,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":987,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":988,\"textContent\":\" \"},{\"nodeType\":1,\"id\":989,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":990,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":991,\"textContent\":\" \"},{\"nodeType\":1,\"id\":992,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":993,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":994,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":995,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":996,\"textContent\":\" \"},{\"nodeType\":1,\"id\":997,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":998,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":999,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1000,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1001,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":1002,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1003,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1004,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1005,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1006,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1007,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1008,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1009,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":1010,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1011,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1012,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1013,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1014,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1015,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1016,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1017,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":1018,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1019,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1020,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1021,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1022,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1023,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1024,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1025,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":1026,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1027,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1028,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1029,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1030,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1031,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1032,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1033,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":1034,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1035,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1036,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1037,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1038,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1039,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1040,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1041,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":1042,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1043,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1044,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1045,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1046,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1047,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.duration+contained\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":1048,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1049,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":1050,\"textContent\":\"Which shift(s) under 7 hours long starts before B starts, and ends after X ends?\"}]},{\"nodeType\":3,\"id\":1051,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1052,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":1053,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1054,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1055,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1056,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1057,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1058,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":1059,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1060,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1061,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1062,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1063,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1064,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1065,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1066,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":1067,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1068,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1069,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1070,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1071,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1072,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1073,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1074,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":1075,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1076,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1077,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1078,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1079,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1080,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1081,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1082,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":1083,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1084,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1085,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1086,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1087,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1088,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1089,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1090,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":1091,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1092,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1093,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1094,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1095,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1096,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1097,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1098,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":1099,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1100,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1101,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1102,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1103,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1104,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1105,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1106,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":1107,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1108,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1109,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1110,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1111,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1112,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1113,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1114,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":1115,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1116,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1117,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1118,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1119,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1120,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1121,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1122,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":1123,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1124,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1125,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1126,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1127,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1128,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1129,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1130,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":1131,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1132,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1133,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1134,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1135,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1136,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1137,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1138,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":1139,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1140,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1141,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1142,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1143,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1144,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1145,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1146,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":1147,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1148,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1149,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1150,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1151,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1152,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1153,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1154,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":1155,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1156,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1157,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1158,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1159,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1160,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1161,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1162,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":1163,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1164,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1165,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1166,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1167,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1168,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1169,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1170,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":1171,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1172,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1173,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1174,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1175,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1176,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1177,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1178,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":1179,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1180,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1181,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1182,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1183,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1184,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1185,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1186,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":1187,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1188,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1189,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1190,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1191,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1192,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1193,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1194,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":1195,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1196,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1197,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1198,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1199,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1200,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.starttime+before+endtime+during\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":1201,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1202,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":1203,\"textContent\":\"Which shift(s) begins before J begins and ends during B?\"}]},{\"nodeType\":3,\"id\":1204,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1205,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":1206,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1207,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1208,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1209,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1210,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1211,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":1212,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1213,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1214,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1215,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1216,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1217,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1218,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1219,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":1220,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1221,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1222,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1223,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1224,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1225,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1226,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1227,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":1228,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1229,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1230,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1231,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1232,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1233,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1234,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1235,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":1236,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1237,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1238,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1239,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1240,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1241,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1242,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1243,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":1244,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1245,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1246,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1247,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1248,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1249,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1250,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1251,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":1252,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1253,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1254,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1255,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1256,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1257,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1258,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1259,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":1260,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1261,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1262,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1263,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1264,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1265,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1266,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1267,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":1268,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1269,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1270,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1271,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1272,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1273,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1274,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1275,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":1276,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1277,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1278,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1279,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1280,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1281,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1282,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1283,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":1284,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1285,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1286,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1287,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1288,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1289,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1290,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1291,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":1292,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1293,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1294,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1295,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1296,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1297,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1298,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1299,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":1300,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1301,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1302,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1303,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1304,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1305,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1306,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1307,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":1308,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1309,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1310,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1311,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1312,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1313,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1314,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1315,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":1316,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1317,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1318,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1319,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1320,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1321,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1322,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1323,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":1324,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1325,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1326,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1327,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1328,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1329,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1330,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1331,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":1332,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1333,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1334,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1335,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1336,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1337,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1338,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1339,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":1340,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1341,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1342,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1343,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1344,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1345,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1346,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1347,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":1348,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1349,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1350,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1351,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1352,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1353,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.ends\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":1354,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1355,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":1356,\"textContent\":\"Which shift(s) end at the same time as F?\"}]},{\"nodeType\":3,\"id\":1357,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1358,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":1359,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1360,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1361,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1362,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1363,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1364,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":1365,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1366,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1367,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1368,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1369,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1370,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1371,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1372,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":1373,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1374,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1375,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1376,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1377,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1378,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1379,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1380,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":1381,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1382,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1383,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1384,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1385,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1386,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1387,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1388,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":1389,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1390,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1391,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1392,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1393,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1394,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1395,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1396,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":1397,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1398,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1399,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1400,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1401,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1402,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1403,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1404,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":1405,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1406,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1407,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1408,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1409,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1410,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1411,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1412,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":1413,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1414,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1415,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1416,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1417,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1418,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1419,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1420,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":1421,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1422,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1423,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1424,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1425,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1426,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1427,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1428,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":1429,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1430,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1431,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1432,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1433,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1434,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1435,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1436,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":1437,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1438,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1439,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1440,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1441,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1442,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1443,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1444,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":1445,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1446,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1447,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1448,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1449,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1450,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1451,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1452,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":1453,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1454,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1455,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1456,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1457,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1458,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1459,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1460,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":1461,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1462,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1463,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1464,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1465,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1466,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1467,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1468,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":1469,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1470,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1471,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1472,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1473,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1474,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1475,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1476,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":1477,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1478,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1479,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1480,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1481,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1482,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1483,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1484,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":1485,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1486,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1487,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1488,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1489,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1490,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1491,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1492,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":1493,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1494,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1495,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1496,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1497,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1498,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1499,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1500,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":1501,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1502,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1503,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1504,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1505,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1506,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.starttime\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":1507,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1508,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":1509,\"textContent\":\"Which shift(s) start at 12pm?\"}]},{\"nodeType\":3,\"id\":1510,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1511,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":1512,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1513,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1514,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1515,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1516,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1517,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":1518,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1519,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1520,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1521,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1522,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1523,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1524,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1525,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":1526,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1527,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1528,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1529,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1530,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1531,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1532,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1533,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":1534,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1535,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1536,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1537,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1538,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1539,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1540,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1541,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":1542,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1543,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1544,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1545,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1546,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1547,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1548,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1549,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":1550,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1551,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1552,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1553,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1554,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1555,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1556,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1557,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":1558,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1559,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1560,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1561,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1562,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1563,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1564,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1565,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":1566,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1567,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1568,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1569,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1570,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1571,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1572,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1573,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":1574,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1575,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1576,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1577,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1578,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1579,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1580,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1581,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":1582,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1583,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1584,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1585,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1586,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1587,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1588,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1589,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":1590,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1591,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1592,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1593,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1594,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1595,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1596,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1597,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":1598,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1599,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1600,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1601,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1602,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1603,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1604,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1605,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":1606,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1607,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1608,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1609,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1610,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1611,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1612,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1613,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":1614,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1615,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1616,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1617,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1618,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1619,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1620,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1621,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":1622,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1623,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1624,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1625,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1626,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1627,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1628,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1629,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":1630,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1631,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1632,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1633,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1634,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1635,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1636,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1637,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":1638,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1639,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1640,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1641,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1642,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1643,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1644,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1645,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":1646,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1647,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1648,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1649,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1650,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1651,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1652,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1653,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":1654,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1655,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1656,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1657,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1658,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1659,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.starts\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":1660,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1661,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":1662,\"textContent\":\"Which shift(s) start at the same time as F?\"}]},{\"nodeType\":3,\"id\":1663,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1664,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":1665,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1666,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1667,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1668,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1669,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1670,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":1671,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1672,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1673,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1674,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1675,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1676,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1677,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1678,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":1679,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1680,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1681,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1682,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1683,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1684,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1685,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1686,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":1687,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1688,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1689,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1690,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1691,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1692,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1693,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1694,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":1695,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1696,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1697,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1698,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1699,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1700,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1701,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1702,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":1703,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1704,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1705,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1706,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1707,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1708,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1709,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1710,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":1711,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1712,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1713,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1714,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1715,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1716,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1717,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1718,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":1719,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1720,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1721,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1722,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1723,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1724,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1725,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1726,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":1727,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1728,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1729,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1730,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1731,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1732,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1733,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1734,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":1735,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1736,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1737,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1738,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1739,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1740,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1741,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1742,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":1743,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1744,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1745,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1746,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1747,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1748,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1749,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1750,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":1751,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1752,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1753,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1754,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1755,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1756,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1757,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1758,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":1759,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1760,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1761,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1762,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1763,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1764,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1765,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1766,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":1767,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1768,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1769,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1770,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1771,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1772,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1773,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1774,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":1775,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1776,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1777,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1778,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1779,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1780,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1781,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1782,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":1783,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1784,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1785,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1786,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1787,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1788,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1789,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1790,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":1791,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1792,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1793,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1794,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1795,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1796,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1797,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1798,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":1799,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1800,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1801,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1802,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1803,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1804,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1805,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1806,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":1807,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1808,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1809,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1810,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1811,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1812,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.meets\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":1813,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1814,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":1815,\"textContent\":\"Which 2 shifts end when Z begins?\"}]},{\"nodeType\":3,\"id\":1816,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1817,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":1818,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1819,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1820,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1821,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1822,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1823,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":1824,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1825,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1826,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1827,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1828,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1829,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1830,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1831,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":1832,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1833,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1834,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1835,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1836,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1837,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1838,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1839,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":1840,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1841,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1842,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1843,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1844,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1845,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1846,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1847,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":1848,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1849,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1850,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1851,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1852,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1853,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1854,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1855,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":1856,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1857,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1858,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1859,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1860,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1861,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1862,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1863,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":1864,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1865,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1866,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1867,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1868,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1869,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1870,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1871,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":1872,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1873,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1874,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1875,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1876,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1877,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1878,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1879,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":1880,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1881,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1882,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1883,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1884,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1885,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1886,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1887,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":1888,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1889,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1890,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1891,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1892,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1893,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1894,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1895,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":1896,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1897,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1898,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1899,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1900,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1901,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1902,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1903,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":1904,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1905,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1906,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1907,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1908,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1909,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1910,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1911,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":1912,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1913,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1914,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1915,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1916,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1917,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1918,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1919,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":1920,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1921,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1922,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1923,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1924,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1925,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1926,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1927,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":1928,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1929,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1930,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1931,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1932,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1933,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1934,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1935,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":1936,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1937,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1938,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1939,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1940,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1941,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1942,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1943,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":1944,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1945,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1946,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1947,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1948,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1949,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1950,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1951,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":1952,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1953,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1954,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1955,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1956,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1957,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1958,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1959,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":1960,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1961,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1962,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1963,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1964,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1965,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.endtime\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":1966,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1967,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":1968,\"textContent\":\"Which shift(s) end at 3pm?\"}]},{\"nodeType\":3,\"id\":1969,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1970,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":1971,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1972,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1973,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1974,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1975,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1976,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":1977,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1978,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1979,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1980,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1981,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1982,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1983,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1984,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":1985,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1986,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1987,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1988,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1989,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1990,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1991,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1992,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":1993,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1994,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1995,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1996,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1997,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1998,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1999,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2000,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":2001,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2002,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2003,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2004,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2005,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2006,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2007,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2008,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":2009,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2010,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2011,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2012,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2013,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2014,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2015,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2016,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":2017,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2018,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2019,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2020,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2021,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2022,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2023,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2024,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":2025,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2026,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2027,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2028,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2029,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2030,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2031,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2032,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":2033,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2034,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2035,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2036,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2037,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2038,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2039,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2040,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":2041,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2042,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2043,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2044,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2045,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2046,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2047,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2048,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":2049,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2050,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2051,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2052,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2053,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2054,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2055,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2056,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":2057,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2058,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2059,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2060,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2061,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2062,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2063,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2064,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":2065,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2066,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2067,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2068,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2069,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2070,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2071,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2072,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":2073,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2074,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2075,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2076,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2077,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2078,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2079,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2080,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":2081,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2082,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2083,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2084,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2085,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2086,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2087,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2088,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":2089,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2090,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2091,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2092,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2093,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2094,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2095,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2096,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":2097,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2098,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2099,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2100,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2101,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2102,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2103,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2104,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":2105,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2106,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2107,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2108,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2109,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2110,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2111,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2112,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":2113,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2114,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2115,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2116,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2117,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2118,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.midpoint\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":2119,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2120,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":2121,\"textContent\":\"Coffee breaks happen halfway through a shift. \"},{\"nodeType\":1,\"id\":2122,\"tagName\":\"BR\",\"attributes\":{}},{\"nodeType\":3,\"id\":2123,\"textContent\":\"Which shifts share a break at 2pm?\"}]},{\"nodeType\":3,\"id\":2124,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2125,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":2126,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2127,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2128,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2129,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2130,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2131,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":2132,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2133,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2134,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2135,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2136,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2137,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2138,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2139,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":2140,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2141,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2142,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2143,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2144,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2145,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2146,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2147,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":2148,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2149,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2150,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2151,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2152,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2153,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2154,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2155,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":2156,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2157,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2158,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2159,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2160,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2161,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2162,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2163,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":2164,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2165,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2166,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2167,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2168,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2169,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2170,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2171,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":2172,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2173,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2174,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2175,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2176,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2177,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2178,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2179,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":2180,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2181,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2182,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2183,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2184,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2185,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2186,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2187,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":2188,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2189,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2190,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2191,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2192,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2193,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2194,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2195,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":2196,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2197,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2198,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2199,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2200,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2201,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2202,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2203,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":2204,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2205,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2206,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2207,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2208,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2209,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2210,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2211,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":2212,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2213,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2214,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2215,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2216,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2217,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2218,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2219,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":2220,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2221,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2222,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2223,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2224,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2225,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2226,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2227,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":2228,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2229,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2230,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2231,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2232,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2233,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2234,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2235,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":2236,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2237,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2238,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2239,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2240,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2241,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2242,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2243,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":2244,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2245,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2246,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2247,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2248,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2249,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2250,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2251,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":2252,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2253,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2254,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2255,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2256,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2257,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2258,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2259,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":2260,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2261,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2262,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2263,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2264,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2265,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2266,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2267,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":2268,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2269,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2270,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2271,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2272,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2273,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\".strategy\",\"style\":\"display: block;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2274,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2275,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":2276,\"textContent\":\"Please describe how to determine what event(s) start at 12pm?\"}]},{\"nodeType\":3,\"id\":2277,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2278,\"tagName\":\"TEXTAREA\",\"attributes\":{\"id\":\"strategyAnswer\",\"rows\":\"5\",\"cols\":\"80\"}},{\"nodeType\":3,\"id\":2279,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2280,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2281,\"textContent\":\" \"},{\"nodeType\":8,\"id\":2282},{\"nodeType\":3,\"id\":2283,\"textContent\":\" \"},{\"nodeType\":8,\"id\":2284},{\"nodeType\":3,\"id\":2285,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2286,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"fixbottom\"},\"childNodes\":[{\"nodeType\":3,\"id\":2287,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2288,\"tagName\":\"BUTTON\",\"attributes\":{\"type\":\"button\",\"id\":\"testingButton\",\"style\":\"display:none;\",\"class\":\"btn\"},\"childNodes\":[{\"nodeType\":3,\"id\":2289,\"textContent\":\"SUBMIT\"}]},{\"nodeType\":3,\"id\":2290,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2291,\"tagName\":\"BUTTON\",\"attributes\":{\"type\":\"button\",\"id\":\"strategyButton\",\"style\":\"display: block;\",\"class\":\"btn\"},\"childNodes\":[{\"nodeType\":3,\"id\":2292,\"textContent\":\"SUBMIT\"}]},{\"nodeType\":3,\"id\":2293,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2294,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2295,\"textContent\":\" \"},{\"nodeType\":8,\"id\":2296},{\"nodeType\":3,\"id\":2297,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2298,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"d3container\"},\"childNodes\":[{\"nodeType\":1,\"id\":2299,\"tagName\":\"svg\",\"attributes\":{\"width\":\"930\",\"height\":\"915\"},\"childNodes\":[{\"nodeType\":1,\"id\":2300,\"tagName\":\"g\",\"attributes\":{\"transform\":\"translate(100,25)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2301,\"tagName\":\"g\",\"attributes\":{\"class\":\"leaders\"}},{\"nodeType\":1,\"id\":2302,\"tagName\":\"g\",\"attributes\":{\"class\":\"static-scaffold\"}},{\"nodeType\":1,\"id\":2303,\"tagName\":\"g\",\"attributes\":{\"class\":\"xaxis\",\"transform\":\"translate(0,800)\",\"fill\":\"none\",\"font-size\":\"10\",\"font-family\":\"sans-serif\",\"text-anchor\":\"middle\"},\"childNodes\":[{\"nodeType\":1,\"id\":2304,\"tagName\":\"path\",\"attributes\":{\"class\":\"domain\",\"stroke\":\"#000\",\"d\":\"M0.5,6V0.5H800.5V6\"}},{\"nodeType\":1,\"id\":2305,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0.5,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2306,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2307,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2308,\"textContent\":\"08 AM\"}]}]},{\"nodeType\":1,\"id\":2309,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(33.83333333333333,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2310,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2311,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2312,\"textContent\":\"08:30\"}]}]},{\"nodeType\":1,\"id\":2313,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(67.16666666666666,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2314,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2315,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2316,\"textContent\":\"09 AM\"}]}]},{\"nodeType\":1,\"id\":2317,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(100.5,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2318,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2319,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2320,\"textContent\":\"09:30\"}]}]},{\"nodeType\":1,\"id\":2321,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(133.83333333333331,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2322,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2323,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2324,\"textContent\":\"10 AM\"}]}]},{\"nodeType\":1,\"id\":2325,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(167.16666666666669,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2326,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2327,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2328,\"textContent\":\"10:30\"}]}]},{\"nodeType\":1,\"id\":2329,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(200.5,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2330,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2331,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2332,\"textContent\":\"11 AM\"}]}]},{\"nodeType\":1,\"id\":2333,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(233.83333333333334,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2334,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2335,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2336,\"textContent\":\"11:30\"}]}]},{\"nodeType\":1,\"id\":2337,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(267.16666666666663,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2338,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2339,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2340,\"textContent\":\"12 PM\"}]}]},{\"nodeType\":1,\"id\":2341,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(300.5,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2342,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2343,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2344,\"textContent\":\"12:30\"}]}]},{\"nodeType\":1,\"id\":2345,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(333.83333333333337,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2346,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2347,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2348,\"textContent\":\"01 PM\"}]}]},{\"nodeType\":1,\"id\":2349,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(367.16666666666663,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2350,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2351,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2352,\"textContent\":\"01:30\"}]}]},{\"nodeType\":1,\"id\":2353,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(400.5,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2354,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2355,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2356,\"textContent\":\"02 PM\"}]}]},{\"nodeType\":1,\"id\":2357,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(433.8333333333333,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2358,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2359,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2360,\"textContent\":\"02:30\"}]}]},{\"nodeType\":1,\"id\":2361,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(467.1666666666667,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2362,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2363,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2364,\"textContent\":\"03 PM\"}]}]},{\"nodeType\":1,\"id\":2365,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(500.5,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2366,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2367,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2368,\"textContent\":\"03:30\"}]}]},{\"nodeType\":1,\"id\":2369,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(533.8333333333333,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2370,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2371,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2372,\"textContent\":\"04 PM\"}]}]},{\"nodeType\":1,\"id\":2373,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(567.1666666666667,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2374,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2375,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2376,\"textContent\":\"04:30\"}]}]},{\"nodeType\":1,\"id\":2377,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(600.5,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2378,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2379,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2380,\"textContent\":\"05 PM\"}]}]},{\"nodeType\":1,\"id\":2381,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(633.8333333333333,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2382,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2383,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2384,\"textContent\":\"05:30\"}]}]},{\"nodeType\":1,\"id\":2385,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(667.1666666666667,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2386,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2387,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2388,\"textContent\":\"06 PM\"}]}]},{\"nodeType\":1,\"id\":2389,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(700.5,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2390,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2391,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2392,\"textContent\":\"06:30\"}]}]},{\"nodeType\":1,\"id\":2393,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(733.8333333333333,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2394,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2395,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2396,\"textContent\":\"07 PM\"}]}]},{\"nodeType\":1,\"id\":2397,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(767.1666666666667,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2398,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2399,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2400,\"textContent\":\"07:30\"}]}]},{\"nodeType\":1,\"id\":2401,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(800.5,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2402,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2403,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2404,\"textContent\":\"08 PM\"}]}]},{\"nodeType\":1,\"id\":2405,\"tagName\":\"g\",\"attributes\":{\"class\":\"axisTitle\"},\"childNodes\":[{\"nodeType\":1,\"id\":2406,\"tagName\":\"text\",\"attributes\":{\"x\":\"533.3333333333334\",\"y\":\"80\",\"style\":\"text-anchor: end;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2407,\"textContent\":\"START & END TIME (time of day)\"}]}]}]},{\"nodeType\":1,\"id\":2408,\"tagName\":\"g\",\"attributes\":{\"class\":\"yaxis\",\"fill\":\"none\",\"font-size\":\"10\",\"font-family\":\"sans-serif\",\"text-anchor\":\"end\"},\"childNodes\":[{\"nodeType\":1,\"id\":2409,\"tagName\":\"path\",\"attributes\":{\"class\":\"domain\",\"stroke\":\"#000\",\"d\":\"M-15,800.5H0.5V0.5H-15\"}},{\"nodeType\":1,\"id\":2410,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,800.5)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2411,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2412,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2413,\"textContent\":\"0\"}]}]},{\"nodeType\":1,\"id\":2414,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,733.8333333333334)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2415,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2416,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2417,\"textContent\":\"1\"}]}]},{\"nodeType\":1,\"id\":2418,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,667.1666666666667)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2419,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2420,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2421,\"textContent\":\"2\"}]}]},{\"nodeType\":1,\"id\":2422,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,600.5)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2423,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2424,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2425,\"textContent\":\"3\"}]}]},{\"nodeType\":1,\"id\":2426,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,533.8333333333334)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2427,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2428,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2429,\"textContent\":\"4\"}]}]},{\"nodeType\":1,\"id\":2430,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,467.16666666666663)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2431,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2432,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2433,\"textContent\":\"5\"}]}]},{\"nodeType\":1,\"id\":2434,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,400.5)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2435,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2436,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2437,\"textContent\":\"6\"}]}]},{\"nodeType\":1,\"id\":2438,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,333.8333333333333)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2439,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2440,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2441,\"textContent\":\"7\"}]}]},{\"nodeType\":1,\"id\":2442,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,267.16666666666674)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2443,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2444,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2445,\"textContent\":\"8\"}]}]},{\"nodeType\":1,\"id\":2446,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,200.5)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2447,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2448,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2449,\"textContent\":\"9\"}]}]},{\"nodeType\":1,\"id\":2450,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,133.83333333333326)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2451,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2452,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2453,\"textContent\":\"10\"}]}]},{\"nodeType\":1,\"id\":2454,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,67.16666666666674)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2455,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2456,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2457,\"textContent\":\"11\"}]}]},{\"nodeType\":1,\"id\":2458,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,0.5)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2459,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2460,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2461,\"textContent\":\"12\"}]}]},{\"nodeType\":1,\"id\":2462,\"tagName\":\"g\",\"attributes\":{\"class\":\"axisTitle\"},\"childNodes\":[{\"nodeType\":1,\"id\":2463,\"tagName\":\"text\",\"attributes\":{\"transform\":\"rotate(-90)\",\"x\":\"-350\",\"y\":\"-60\",\"style\":\"text-anchor: end;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2464,\"textContent\":\"DURATION (in hours)\"}]}]}]},{\"nodeType\":1,\"id\":2465,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2466,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2467,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"733.3333333333334\",\"y2\":\"733.3333333333334\"}}]},{\"nodeType\":1,\"id\":2468,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2469,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"666.6666666666667\",\"y2\":\"666.6666666666667\"}}]},{\"nodeType\":1,\"id\":2470,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2471,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"600\",\"y2\":\"600\"}}]},{\"nodeType\":1,\"id\":2472,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2473,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"533.3333333333334\",\"y2\":\"533.3333333333334\"}}]},{\"nodeType\":1,\"id\":2474,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2475,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"466.66666666666663\",\"y2\":\"466.66666666666663\"}}]},{\"nodeType\":1,\"id\":2476,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2477,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"400\",\"y2\":\"400\"}}]},{\"nodeType\":1,\"id\":2478,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2479,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"333.3333333333333\",\"y2\":\"333.3333333333333\"}}]},{\"nodeType\":1,\"id\":2480,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2481,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"266.66666666666674\",\"y2\":\"266.66666666666674\"}}]},{\"nodeType\":1,\"id\":2482,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2483,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"200\",\"y2\":\"200\"}}]},{\"nodeType\":1,\"id\":2484,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2485,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"133.33333333333326\",\"y2\":\"133.33333333333326\"}}]},{\"nodeType\":1,\"id\":2486,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2487,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"66.66666666666674\",\"y2\":\"66.66666666666674\"}}]},{\"nodeType\":1,\"id\":2488,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2489,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"0\",\"y2\":\"0\"}}]}]},{\"nodeType\":1,\"id\":2490,\"tagName\":\"g\",\"attributes\":{\"class\":\"xgrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2491,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"0\",\"y1\":\"800\",\"x2\":\"400\",\"y2\":\"0\"}},{\"nodeType\":1,\"id\":2492,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"800\",\"y1\":\"800\",\"x2\":\"400\",\"y2\":\"0\"}},{\"nodeType\":1,\"id\":2493,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"66.66666666666666\",\"y1\":\"800\",\"x2\":\"466.6666666666667\",\"y2\":\"0\"}},{\"nodeType\":1,\"id\":2494,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"733.3333333333333\",\"y1\":\"800\",\"x2\":\"333.33333333333337\",\"y2\":\"0\"}},{\"nodeType\":1,\"id\":2495,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"133.33333333333331\",\"y1\":\"800\",\"x2\":\"533.3333333333333\",\"y2\":\"0\"}},{\"nodeType\":1,\"id\":2496,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"666.6666666666667\",\"y1\":\"800\",\"x2\":\"266.66666666666663\",\"y2\":\"0\"}},{\"nodeType\":1,\"id\":2497,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"200\",\"y1\":\"800\",\"x2\":\"600\",\"y2\":\"0\"}},{\"nodeType\":1,\"id\":2498,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"600\",\"y1\":\"800\",\"x2\":\"200\",\"y2\":\"0\"}},{\"nodeType\":1,\"id\":2499,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"266.66666666666663\",\"y1\":\"800\",\"x2\":\"666.6666666666667\",\"y2\":\"0\"}},{\"nodeType\":1,\"id\":2500,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"533.3333333333333\",\"y1\":\"800\",\"x2\":\"133.33333333333331\",\"y2\":\"0\"}},{\"nodeType\":1,\"id\":2501,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"333.33333333333337\",\"y1\":\"800\",\"x2\":\"733.3333333333333\",\"y2\":\"0\"}},{\"nodeType\":1,\"id\":2502,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"466.6666666666667\",\"y1\":\"800\",\"x2\":\"66.66666666666666\",\"y2\":\"0\"}},{\"nodeType\":1,\"id\":2503,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"400\",\"y1\":\"800\",\"x2\":\"800\",\"y2\":\"0\"}},{\"nodeType\":1,\"id\":2504,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"400\",\"y1\":\"800\",\"x2\":\"0\",\"y2\":\"0\"}},{\"nodeType\":1,\"id\":2505,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"466.6666666666667\",\"y1\":\"800\",\"x2\":\"800\",\"y2\":\"133.33333333333326\"}},{\"nodeType\":1,\"id\":2506,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"333.33333333333337\",\"y1\":\"800\",\"x2\":\"0\",\"y2\":\"133.33333333333326\"}},{\"nodeType\":1,\"id\":2507,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"533.3333333333333\",\"y1\":\"800\",\"x2\":\"800\",\"y2\":\"266.66666666666674\"}},{\"nodeType\":1,\"id\":2508,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"266.66666666666663\",\"y1\":\"800\",\"x2\":\"0\",\"y2\":\"266.66666666666674\"}},{\"nodeType\":1,\"id\":2509,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"600\",\"y1\":\"800\",\"x2\":\"800\",\"y2\":\"400\"}},{\"nodeType\":1,\"id\":2510,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"200\",\"y1\":\"800\",\"x2\":\"0\",\"y2\":\"400\"}},{\"nodeType\":1,\"id\":2511,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"666.6666666666667\",\"y1\":\"800\",\"x2\":\"800\",\"y2\":\"533.3333333333334\"}},{\"nodeType\":1,\"id\":2512,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"133.33333333333331\",\"y1\":\"800\",\"x2\":\"0\",\"y2\":\"533.3333333333334\"}},{\"nodeType\":1,\"id\":2513,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"733.3333333333333\",\"y1\":\"800\",\"x2\":\"800\",\"y2\":\"666.6666666666667\"}},{\"nodeType\":1,\"id\":2514,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"66.66666666666666\",\"y1\":\"800\",\"x2\":\"0\",\"y2\":\"666.6666666666667\"}}]},{\"nodeType\":1,\"id\":2515,\"tagName\":\"g\",\"attributes\":{\"class\":\"data\"},\"childNodes\":[{\"nodeType\":1,\"id\":2516,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2517,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"333.33333333333337\",\"cy\":\"266.66666666666674\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2518,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"328.33333333333337\",\"y\":\"258.66666666666674\"},\"childNodes\":[{\"nodeType\":3,\"id\":2519,\"textContent\":\"A \"}]}]},{\"nodeType\":1,\"id\":2520,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2521,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"266.66666666666663\",\"cy\":\"600\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2522,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"261.66666666666663\",\"y\":\"592\"},\"childNodes\":[{\"nodeType\":3,\"id\":2523,\"textContent\":\"B \"}]}]},{\"nodeType\":1,\"id\":2524,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2525,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"366.66666666666663\",\"cy\":\"466.66666666666663\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2526,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"361.66666666666663\",\"y\":\"458.66666666666663\"},\"childNodes\":[{\"nodeType\":3,\"id\":2527,\"textContent\":\"C \"}]}]},{\"nodeType\":1,\"id\":2528,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2529,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"666.6666666666667\",\"cy\":\"666.6666666666667\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2530,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"661.6666666666667\",\"y\":\"658.6666666666667\"},\"childNodes\":[{\"nodeType\":3,\"id\":2531,\"textContent\":\"D \"}]}]},{\"nodeType\":1,\"id\":2532,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2533,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"200\",\"cy\":\"400\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2534,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"195\",\"y\":\"392\"},\"childNodes\":[{\"nodeType\":3,\"id\":2535,\"textContent\":\"E \"}]}]},{\"nodeType\":1,\"id\":2536,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2537,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"266.66666666666663\",\"cy\":\"533.3333333333334\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2538,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"261.66666666666663\",\"y\":\"525.3333333333334\"},\"childNodes\":[{\"nodeType\":3,\"id\":2539,\"textContent\":\"F \"}]}]},{\"nodeType\":1,\"id\":2540,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2541,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"333.33333333333337\",\"cy\":\"400\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2542,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"328.33333333333337\",\"y\":\"392\"},\"childNodes\":[{\"nodeType\":3,\"id\":2543,\"textContent\":\"G \"}]}]},{\"nodeType\":1,\"id\":2544,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2545,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"500\",\"cy\":\"466.66666666666663\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2546,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"495\",\"y\":\"458.66666666666663\"},\"childNodes\":[{\"nodeType\":3,\"id\":2547,\"textContent\":\"H \"}]}]},{\"nodeType\":1,\"id\":2548,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2549,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"100\",\"cy\":\"600\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2550,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"95\",\"y\":\"592\"},\"childNodes\":[{\"nodeType\":3,\"id\":2551,\"textContent\":\"I \"}]}]},{\"nodeType\":1,\"id\":2552,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2553,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"133.33333333333331\",\"cy\":\"666.6666666666667\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2554,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"128.33333333333331\",\"y\":\"658.6666666666667\"},\"childNodes\":[{\"nodeType\":3,\"id\":2555,\"textContent\":\"J \"}]}]},{\"nodeType\":1,\"id\":2556,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2557,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"400\",\"cy\":\"133.33333333333326\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2558,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"395\",\"y\":\"125.33333333333326\"},\"childNodes\":[{\"nodeType\":3,\"id\":2559,\"textContent\":\"K \"}]}]},{\"nodeType\":1,\"id\":2560,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2561,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"500\",\"cy\":\"333.3333333333333\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2562,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"495\",\"y\":\"325.3333333333333\"},\"childNodes\":[{\"nodeType\":3,\"id\":2563,\"textContent\":\"L \"}]}]},{\"nodeType\":1,\"id\":2564,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2565,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"300\",\"cy\":\"733.3333333333334\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2566,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"295\",\"y\":\"725.3333333333334\"},\"childNodes\":[{\"nodeType\":3,\"id\":2567,\"textContent\":\"M \"}]}]},{\"nodeType\":1,\"id\":2568,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2569,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"600\",\"cy\":\"666.6666666666667\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2570,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"595\",\"y\":\"658.6666666666667\"},\"childNodes\":[{\"nodeType\":3,\"id\":2571,\"textContent\":\"N \"}]}]},{\"nodeType\":1,\"id\":2572,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2573,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"433.3333333333333\",\"cy\":\"600\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2574,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"428.3333333333333\",\"y\":\"592\"},\"childNodes\":[{\"nodeType\":3,\"id\":2575,\"textContent\":\"O \"}]}]},{\"nodeType\":1,\"id\":2576,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2577,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"500\",\"cy\":\"200\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2578,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"495\",\"y\":\"192\"},\"childNodes\":[{\"nodeType\":3,\"id\":2579,\"textContent\":\"P \"}]}]},{\"nodeType\":1,\"id\":2580,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2581,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"533.3333333333333\",\"cy\":\"533.3333333333334\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2582,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"528.3333333333333\",\"y\":\"525.3333333333334\"},\"childNodes\":[{\"nodeType\":3,\"id\":2583,\"textContent\":\"Z \"}]}]},{\"nodeType\":1,\"id\":2584,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2585,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"400\",\"cy\":\"666.6666666666667\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2586,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"395\",\"y\":\"658.6666666666667\"},\"childNodes\":[{\"nodeType\":3,\"id\":2587,\"textContent\":\"X \"}]}]}]}]}]}]},{\"nodeType\":3,\"id\":2588,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2589,\"textContent\":\" \"},{\"nodeType\":8,\"id\":2590},{\"nodeType\":3,\"id\":2591,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2592,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":2593,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2594,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":2595,\"textContent\":\" \"}]}]}]]}",
  "useCssProxy": true,
  "loadTimes": "es: 418, dom: 2117, initialDom: 3738",
  "javascriptErrors": []
}