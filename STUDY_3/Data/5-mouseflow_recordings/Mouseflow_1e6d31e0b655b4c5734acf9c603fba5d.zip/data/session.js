var MF = MF || {};MF.RecordingData = MF.RecordingData || {};MF.RecordingData["session"] = {
  "id": "1e6d31e0b655b4c5734acf9c603fba5d",
  "created": "2018-06-04T13:17:58.4994481-07:00",
  "lastActivity": "2018-06-04T13:18:34.7318916-07:00",
  "pageViews": [
    {
      "id": "06045850d69bc8baecc877ad29da43fe3b067246",
      "startTime": "2018-06-04T13:17:58.4994481-07:00",
      "endTime": "2018-06-04T13:18:34.7318916-07:00",
      "title": "FOX2YP",
      "uri": "https://warm-citadel-75324.herokuapp.com/",
      "websitePage": "/",
      "visitTime": 36637,
      "engagementTime": 36637,
      "scroll": 100.0,
      "tags": [
        "form-interact"
      ],
      "friction": 0,
      "annotations": []
    }
  ],
  "duration": 36637,
  "engagementTime": 36637,
  "totalFriction": 0,
  "country": "us",
  "region": "CA",
  "city": "La Jolla",
  "isp": "University of California, San Diego",
  "ip": "128.54.68.28",
  "lang": "en-US",
  "userAgent": "Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/66.0.3359.181 Safari/537.36",
  "browser": "Chrome",
  "browserVersion": "66.0.3359.181",
  "os": "Windows",
  "osVersion": "7",
  "device": "Desktop",
  "referrer": "",
  "referrerType": "",
  "screenRes": "1920x1200",
  "tags": [
    "form-interact"
  ],
  "variables": [],
  "watched": false,
  "starred": false,
  "lng": -117.2359,
  "lat": 32.8807,
  "visitorId": "1b813f0c672f9082976b7bda36ed2080",
  "gdpr": false
}