var MF = MF || {};MF.RecordingData = MF.RecordingData || {};MF.RecordingData["session"] = {
  "id": "d5c33daf3205606da2d5c0ad06e9754d",
  "created": "2018-05-31T12:07:40.1938572-07:00",
  "lastActivity": "2018-05-31T12:07:57.2788572-07:00",
  "pageViews": [
    {
      "id": "05314061f812f836ba751642f373d4f09f41fdbf",
      "startTime": "2018-05-31T12:07:40.1938572-07:00",
      "endTime": "2018-05-31T12:07:57.2788572-07:00",
      "title": "FOX2YP",
      "uri": "https://warm-citadel-75324.herokuapp.com/",
      "websitePage": "/2",
      "visitTime": 17085,
      "engagementTime": 16218,
      "scroll": 100.0,
      "tags": [
        "form-interact"
      ],
      "friction": 0,
      "annotations": []
    }
  ],
  "duration": 17085,
  "engagementTime": 16218,
  "totalFriction": 0,
  "country": "us",
  "region": "CA",
  "city": "La Jolla",
  "isp": "University of California, San Diego",
  "ip": "128.54.68.30",
  "lang": "en-US",
  "userAgent": "Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/67.0.3396.62 Safari/537.36",
  "browser": "Chrome",
  "browserVersion": "67.0.3396.62",
  "os": "Windows",
  "osVersion": "7",
  "device": "Desktop",
  "referrer": "",
  "referrerType": "",
  "screenRes": "1920x1200",
  "tags": [
    "form-interact"
  ],
  "variables": [
    "SID=03QKB",
    "CONDITION=115",
    "ORTH_CORRECT=1"
  ],
  "watched": false,
  "starred": false,
  "lng": -117.2359,
  "lat": 32.8807,
  "visitorId": "6a3e6d1f62e9cca3a15ece726a860074",
  "gdpr": false
}