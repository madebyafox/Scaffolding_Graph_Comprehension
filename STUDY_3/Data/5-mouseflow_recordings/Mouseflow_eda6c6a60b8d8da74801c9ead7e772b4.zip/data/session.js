var MF = MF || {};MF.RecordingData = MF.RecordingData || {};MF.RecordingData["session"] = {
  "id": "eda6c6a60b8d8da74801c9ead7e772b4",
  "created": "2018-05-29T14:06:15.0831064-07:00",
  "lastActivity": "2018-05-29T14:06:25.4031064-07:00",
  "pageViews": [
    {
      "id": "05291528d434a2b98aa02e863f1c4153cef5b874",
      "startTime": "2018-05-29T14:06:15.0831064-07:00",
      "endTime": "2018-05-29T14:06:25.4031064-07:00",
      "title": "FOX2YP",
      "uri": "https://warm-citadel-75324.herokuapp.com/",
      "websitePage": "/4",
      "visitTime": 10320,
      "engagementTime": 10320,
      "scroll": 100.0,
      "tags": [
        "form-interact"
      ],
      "friction": 0,
      "annotations": []
    }
  ],
  "duration": 10320,
  "engagementTime": 10320,
  "totalFriction": 0,
  "country": "us",
  "region": "CA",
  "city": "La Jolla",
  "isp": "University of California, San Diego",
  "ip": "128.54.68.26",
  "lang": "en-US",
  "userAgent": "Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/66.0.3359.181 Safari/537.36",
  "browser": "Chrome",
  "browserVersion": "66.0.3359.181",
  "os": "Windows",
  "osVersion": "7",
  "device": "Desktop",
  "referrer": "",
  "referrerType": "",
  "screenRes": "1920x1200",
  "tags": [
    "form-interact"
  ],
  "variables": [
    "SID=F92ER",
    "CONDITION=115",
    "ORTH_CORRECT=1"
  ],
  "watched": false,
  "starred": false,
  "lng": -117.2359,
  "lat": 32.8807,
  "visitorId": "ac1558dbc0163425ef82a036eee90466",
  "gdpr": false
}