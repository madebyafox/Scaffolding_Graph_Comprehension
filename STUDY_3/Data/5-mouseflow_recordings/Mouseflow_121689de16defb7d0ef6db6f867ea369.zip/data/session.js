var MF = MF || {};MF.RecordingData = MF.RecordingData || {};MF.RecordingData["session"] = {
  "id": "121689de16defb7d0ef6db6f867ea369",
  "created": "2018-05-22T16:08:02.4131486-07:00",
  "lastActivity": "2018-05-22T16:08:12.4281486-07:00",
  "pageViews": [
    {
      "id": "05220228976164b686ce5ae6098b440e68b05371",
      "startTime": "2018-05-22T16:08:02.4131486-07:00",
      "endTime": "2018-05-22T16:08:12.4281486-07:00",
      "title": "FOX2YP",
      "uri": "https://warm-citadel-75324.herokuapp.com/",
      "websitePage": "/6",
      "visitTime": 10015,
      "engagementTime": 10015,
      "scroll": 100.0,
      "tags": [
        "form-interact"
      ],
      "friction": 0,
      "annotations": []
    }
  ],
  "duration": 10015,
  "engagementTime": 10015,
  "totalFriction": 0,
  "country": "us",
  "region": "CA",
  "city": "La Jolla",
  "isp": "University of California, San Diego",
  "ip": "128.54.68.36",
  "lang": "en-US",
  "userAgent": "Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/66.0.3359.181 Safari/537.36",
  "browser": "Chrome",
  "browserVersion": "66.0.3359.181",
  "os": "Windows",
  "osVersion": "7",
  "device": "Desktop",
  "referrer": "",
  "referrerType": "",
  "screenRes": "1920x1200",
  "tags": [
    "form-interact"
  ],
  "variables": [
    "SID=2KONX",
    "CONDITION=115",
    "TRI_CORRECT=1",
    "ORTH_CORRECT=1"
  ],
  "watched": false,
  "starred": false,
  "lng": -117.2359,
  "lat": 32.8807,
  "visitorId": "d157bbb509b2e453ac96269563fd38ce",
  "gdpr": false
}