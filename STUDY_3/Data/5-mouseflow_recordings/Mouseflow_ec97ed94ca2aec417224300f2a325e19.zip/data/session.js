var MF = MF || {};MF.RecordingData = MF.RecordingData || {};MF.RecordingData["session"] = {
  "id": "ec97ed94ca2aec417224300f2a325e19",
  "created": "2018-05-19T12:57:15.4205869-07:00",
  "lastActivity": "2018-05-19T12:57:44.5158738-07:00",
  "pageViews": [
    {
      "id": "051915563cf848e2209f9e7f66db51dc420d6269",
      "startTime": "2018-05-19T12:57:15.4748505-07:00",
      "endTime": "2018-05-19T12:57:44.5158738-07:00",
      "title": "FOX2YP",
      "uri": "https://warm-citadel-75324.herokuapp.com/",
      "websitePage": "/2",
      "visitTime": 29084,
      "engagementTime": 27844,
      "scroll": 100.0,
      "tags": [
        "form-interact"
      ],
      "friction": 0,
      "annotations": []
    }
  ],
  "duration": 29084,
  "engagementTime": 27844,
  "totalFriction": 0,
  "country": "us",
  "region": "CA",
  "city": "La Jolla",
  "isp": "University of California, San Diego",
  "ip": "128.54.68.22",
  "lang": "en-US",
  "userAgent": "Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:59.0) Gecko/20100101 Firefox/59.0",
  "browser": "Firefox",
  "browserVersion": "59.0",
  "os": "Windows",
  "osVersion": "7",
  "device": "Desktop",
  "referrer": "",
  "referrerType": "",
  "screenRes": "1920x1200",
  "tags": [
    "form-interact"
  ],
  "variables": [
    "SID=93YLJ",
    "CONDITION=113",
    "TRI_CORRECT=1"
  ],
  "watched": false,
  "starred": true,
  "lng": -117.2359,
  "lat": 32.8807,
  "visitorId": "3fa4d8c5c0a982cecb1f6ef4c25e9410",
  "gdpr": false
}