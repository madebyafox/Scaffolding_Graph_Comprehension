var MF = MF || {};MF.RecordingData = MF.RecordingData || {};MF.RecordingData["0529499014fb83fbc4cb1bb18bfd248c939b0d2f"] = {
  "startTime": "2018-05-29T17:21:49.0526696Z",
  "websitePageUrl": "/16",
  "visitTime": 135753,
  "engagementTime": 95967,
  "pageTitle": "FOX2YP",
  "url": "https://warm-citadel-75324.herokuapp.com/",
  "viewportWidth": 1920,
  "viewportHeight": 1200,
  "tags": [
    "form-interact",
    "submit"
  ],
  "session": {
    "id": "c5e7f58c98ef70919aea03d62163a152",
    "created": "2018-05-29T17:21:49.0526696+00:00",
    "lastActivity": "0001-01-01T00:00:00+00:00",
    "pages": 1,
    "duration": 0,
    "engagementTime": 0,
    "totalFriction": 0,
    "country": "us",
    "region": "CA",
    "city": "La Jolla",
    "isp": "University of California, San Diego",
    "ip": "###.###.###.###",
    "lang": "en-US",
    "userAgent": "Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/66.0.3359.181 Safari/537.36",
    "browser": "Chrome",
    "browserVersion": "66.0.3359.181",
    "os": "Windows",
    "osVersion": "7",
    "device": "Desktop",
    "referrer": "",
    "referrerType": "",
    "screenRes": "1920x1200",
    "entryPage": "/16",
    "tags": [
      "form-interact",
      "submit"
    ],
    "variables": [
      "SID=TGOML",
      "CONDITION=114"
    ],
    "watched": false,
    "starred": false,
    "lng": 32.8807,
    "lat": 32.8807,
    "visitorId": "5e5d5af1d063a74691b0e524c552988d",
    "gdpr": false,
    "visitorName": null,
    "playbackUrl": "https://us.mouseflow.com/websites/e0c9ff05-6fcb-4c4a-8173-e5a0724987b1/recordings/c5e7f58c98ef70919aea03d62163a152/play"
  },
  "events": [
    {
      "t": 2,
      "e": 2,
      "ty": 14,
      "x": 0,
      "y": 1199
    },
    {
      "t": 101,
      "e": 101,
      "ty": 0,
      "x": 1920,
      "y": 1200
    },
    {
      "t": 301,
      "e": 301,
      "ty": 2,
      "x": 529,
      "y": 738
    },
    {
      "t": 496,
      "e": 496,
      "ty": 2,
      "x": 527,
      "y": 736
    },
    {
      "t": 502,
      "e": 502,
      "ty": 41,
      "x": 48325,
      "y": 40329,
      "ta": "> div.stimulus > div"
    },
    {
      "t": 649,
      "e": 649,
      "ty": 38,
      "x": 1,
      "y": 0
    },
    {
      "t": 701,
      "e": 701,
      "ty": 2,
      "x": 526,
      "y": 733
    },
    {
      "t": 751,
      "e": 751,
      "ty": 41,
      "x": 48213,
      "y": 40052,
      "ta": "> div.stimulus > div"
    },
    {
      "t": 801,
      "e": 801,
      "ty": 2,
      "x": 525,
      "y": 730
    },
    {
      "t": 901,
      "e": 901,
      "ty": 2,
      "x": 525,
      "y": 727
    },
    {
      "t": 1001,
      "e": 1001,
      "ty": 2,
      "x": 525,
      "y": 725
    },
    {
      "t": 1002,
      "e": 1002,
      "ty": 41,
      "x": 48100,
      "y": 39719,
      "ta": "> div.stimulus > div"
    },
    {
      "t": 1101,
      "e": 1101,
      "ty": 2,
      "x": 524,
      "y": 724
    },
    {
      "t": 1252,
      "e": 1252,
      "ty": 41,
      "x": 47988,
      "y": 39498,
      "ta": "> div.stimulus > div"
    },
    {
      "t": 1301,
      "e": 1301,
      "ty": 2,
      "x": 523,
      "y": 721
    },
    {
      "t": 1401,
      "e": 1401,
      "ty": 2,
      "x": 523,
      "y": 718
    },
    {
      "t": 1501,
      "e": 1501,
      "ty": 2,
      "x": 522,
      "y": 715
    },
    {
      "t": 1502,
      "e": 1502,
      "ty": 41,
      "x": 47763,
      "y": 39165,
      "ta": "> div.stimulus > div"
    },
    {
      "t": 1601,
      "e": 1601,
      "ty": 2,
      "x": 521,
      "y": 706
    },
    {
      "t": 1701,
      "e": 1701,
      "ty": 2,
      "x": 521,
      "y": 698
    },
    {
      "t": 1752,
      "e": 1752,
      "ty": 41,
      "x": 47651,
      "y": 37947,
      "ta": "> div.stimulus > div"
    },
    {
      "t": 1801,
      "e": 1801,
      "ty": 2,
      "x": 521,
      "y": 688
    },
    {
      "t": 1901,
      "e": 1901,
      "ty": 2,
      "x": 521,
      "y": 684
    },
    {
      "t": 2001,
      "e": 2001,
      "ty": 2,
      "x": 521,
      "y": 680
    },
    {
      "t": 2002,
      "e": 2002,
      "ty": 41,
      "x": 47651,
      "y": 37226,
      "ta": "> div.stimulus > div"
    },
    {
      "t": 2101,
      "e": 2101,
      "ty": 2,
      "x": 514,
      "y": 659
    },
    {
      "t": 2201,
      "e": 2201,
      "ty": 2,
      "x": 510,
      "y": 647
    },
    {
      "t": 2252,
      "e": 2252,
      "ty": 41,
      "x": 45965,
      "y": 34844,
      "ta": "> div.stimulus > div"
    },
    {
      "t": 2301,
      "e": 2301,
      "ty": 2,
      "x": 503,
      "y": 628
    },
    {
      "t": 2401,
      "e": 2401,
      "ty": 2,
      "x": 505,
      "y": 604
    },
    {
      "t": 2413,
      "e": 2413,
      "ty": 6,
      "x": 506,
      "y": 603,
      "ta": "#strategyAnswer"
    },
    {
      "t": 2502,
      "e": 2502,
      "ty": 2,
      "x": 512,
      "y": 590
    },
    {
      "t": 2502,
      "e": 2502,
      "ty": 41,
      "x": 46639,
      "y": 54422,
      "ta": "#strategyAnswer"
    },
    {
      "t": 2601,
      "e": 2601,
      "ty": 2,
      "x": 517,
      "y": 585
    },
    {
      "t": 2751,
      "e": 2751,
      "ty": 41,
      "x": 47201,
      "y": 50377,
      "ta": "#strategyAnswer"
    },
    {
      "t": 2903,
      "e": 2903,
      "ty": 3,
      "x": 517,
      "y": 585,
      "ta": "#strategyAnswer"
    },
    {
      "t": 2904,
      "e": 2904,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 3038,
      "e": 3038,
      "ty": 4,
      "x": 47201,
      "y": 50377,
      "ta": "#strategyAnswer"
    },
    {
      "t": 3038,
      "e": 3038,
      "ty": 5,
      "x": 517,
      "y": 585,
      "ta": "#strategyAnswer"
    },
    {
      "t": 7839,
      "e": 7839,
      "ty": 7,
      "x": 522,
      "y": 607,
      "ta": "#strategyAnswer"
    },
    {
      "t": 7900,
      "e": 7900,
      "ty": 2,
      "x": 697,
      "y": 731
    },
    {
      "t": 8001,
      "e": 8001,
      "ty": 2,
      "x": 1023,
      "y": 820
    },
    {
      "t": 8001,
      "e": 8001,
      "ty": 41,
      "x": 16701,
      "y": 48846,
      "ta": "> div.stimulus > div:[2] > svg"
    },
    {
      "t": 8101,
      "e": 8101,
      "ty": 2,
      "x": 1093,
      "y": 832
    },
    {
      "t": 8202,
      "e": 8202,
      "ty": 2,
      "x": 1107,
      "y": 831
    },
    {
      "t": 8252,
      "e": 8252,
      "ty": 41,
      "x": 24876,
      "y": 52428,
      "ta": "> div.stimulus > div:[2] > svg"
    },
    {
      "t": 8300,
      "e": 8300,
      "ty": 2,
      "x": 1165,
      "y": 907
    },
    {
      "t": 8401,
      "e": 8401,
      "ty": 2,
      "x": 1179,
      "y": 934
    },
    {
      "t": 8502,
      "e": 8502,
      "ty": 2,
      "x": 1163,
      "y": 899
    },
    {
      "t": 8502,
      "e": 8502,
      "ty": 41,
      "x": 26567,
      "y": 54505,
      "ta": "> div.stimulus > div:[2] > svg"
    },
    {
      "t": 8601,
      "e": 8601,
      "ty": 2,
      "x": 1106,
      "y": 766
    },
    {
      "t": 8701,
      "e": 8701,
      "ty": 2,
      "x": 1106,
      "y": 738
    },
    {
      "t": 8753,
      "e": 8753,
      "ty": 41,
      "x": 23325,
      "y": 42329,
      "ta": "> div.stimulus > div:[2] > svg"
    },
    {
      "t": 8801,
      "e": 8801,
      "ty": 2,
      "x": 1120,
      "y": 727
    },
    {
      "t": 8901,
      "e": 8901,
      "ty": 2,
      "x": 1124,
      "y": 724
    },
    {
      "t": 9002,
      "e": 9002,
      "ty": 2,
      "x": 1133,
      "y": 713
    },
    {
      "t": 9002,
      "e": 9002,
      "ty": 41,
      "x": 24453,
      "y": 41183,
      "ta": "> div.stimulus > div:[2] > svg"
    },
    {
      "t": 9101,
      "e": 9101,
      "ty": 2,
      "x": 1137,
      "y": 707
    },
    {
      "t": 9252,
      "e": 9252,
      "ty": 41,
      "x": 24735,
      "y": 40753,
      "ta": "> div.stimulus > div:[2] > svg"
    },
    {
      "t": 10002,
      "e": 10002,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 41524,
      "e": 14252,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 41665,
      "e": 14393,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": ""
    },
    {
      "t": 42234,
      "e": 14962,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "16"
    },
    {
      "t": 42733,
      "e": 15461,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "16"
    },
    {
      "t": 42767,
      "e": 15495,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "16"
    },
    {
      "t": 42800,
      "e": 15528,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "16"
    },
    {
      "t": 42833,
      "e": 15561,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "16"
    },
    {
      "t": 42865,
      "e": 15593,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "16"
    },
    {
      "t": 42899,
      "e": 15627,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "16"
    },
    {
      "t": 42932,
      "e": 15660,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "16"
    },
    {
      "t": 42964,
      "e": 15692,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "16"
    },
    {
      "t": 42997,
      "e": 15725,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "16"
    },
    {
      "t": 43030,
      "e": 15758,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "16"
    },
    {
      "t": 43063,
      "e": 15791,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "16"
    },
    {
      "t": 43097,
      "e": 15825,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "16"
    },
    {
      "t": 43130,
      "e": 15858,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "16"
    },
    {
      "t": 43146,
      "e": 15874,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "87"
    },
    {
      "t": 43147,
      "e": 15875,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 43274,
      "e": 16002,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "W"
    },
    {
      "t": 43393,
      "e": 16121,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "W"
    },
    {
      "t": 44602,
      "e": 17330,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "72"
    },
    {
      "t": 44602,
      "e": 17330,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 44777,
      "e": 17505,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "73"
    },
    {
      "t": 44777,
      "e": 17505,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 44794,
      "e": 17522,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Whi"
    },
    {
      "t": 44906,
      "e": 17634,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Whi"
    },
    {
      "t": 44986,
      "e": 17714,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "67"
    },
    {
      "t": 44987,
      "e": 17715,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 45105,
      "e": 17833,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Whic"
    },
    {
      "t": 45121,
      "e": 17849,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "72"
    },
    {
      "t": 45122,
      "e": 17850,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 45242,
      "e": 17970,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||h"
    },
    {
      "t": 45274,
      "e": 18002,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 45275,
      "e": 18003,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 45403,
      "e": 18131,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Which "
    },
    {
      "t": 45408,
      "e": 18136,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 45658,
      "e": 18386,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 45658,
      "e": 18386,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 45785,
      "e": 18513,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||e"
    },
    {
      "t": 45793,
      "e": 18521,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "86"
    },
    {
      "t": 45793,
      "e": 18521,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 45897,
      "e": 18625,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||v"
    },
    {
      "t": 45906,
      "e": 18634,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 45907,
      "e": 18635,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 46009,
      "e": 18737,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "82"
    },
    {
      "t": 46009,
      "e": 18737,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 46065,
      "e": 18793,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||er"
    },
    {
      "t": 46145,
      "e": 18873,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 46145,
      "e": 18873,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 46161,
      "e": 18889,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 46249,
      "e": 18977,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 46849,
      "e": 19577,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "68"
    },
    {
      "t": 46850,
      "e": 19578,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 46969,
      "e": 19697,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||d"
    },
    {
      "t": 46977,
      "e": 19705,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "79"
    },
    {
      "t": 46978,
      "e": 19706,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 47074,
      "e": 19802,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||o"
    },
    {
      "t": 47145,
      "e": 19873,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 47146,
      "e": 19874,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 47256,
      "e": 19984,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 47754,
      "e": 20482,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "83"
    },
    {
      "t": 47755,
      "e": 20483,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 47874,
      "e": 20602,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||s"
    },
    {
      "t": 47906,
      "e": 20634,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 47906,
      "e": 20634,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 47986,
      "e": 20714,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 48049,
      "e": 20777,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 48051,
      "e": 20779,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 48203,
      "e": 20931,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Which ever dots a"
    },
    {
      "t": 48217,
      "e": 20945,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||a"
    },
    {
      "t": 48225,
      "e": 20953,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "82"
    },
    {
      "t": 48226,
      "e": 20954,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 48322,
      "e": 21050,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 48323,
      "e": 21051,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 48401,
      "e": 21129,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||re"
    },
    {
      "t": 48489,
      "e": 21217,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 48490,
      "e": 21218,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 48537,
      "e": 21265,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 48626,
      "e": 21354,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 49154,
      "e": 21882,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 49155,
      "e": 21883,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 49257,
      "e": 21985,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||a"
    },
    {
      "t": 49490,
      "e": 22218,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "76"
    },
    {
      "t": 49491,
      "e": 22219,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 49585,
      "e": 22313,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||l"
    },
    {
      "t": 49769,
      "e": 22497,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "73"
    },
    {
      "t": 49771,
      "e": 22499,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 49897,
      "e": 22625,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||i"
    },
    {
      "t": 49929,
      "e": 22657,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "71"
    },
    {
      "t": 49929,
      "e": 22657,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 50002,
      "e": 22730,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 50034,
      "e": 22762,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||g"
    },
    {
      "t": 50083,
      "e": 22811,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "78"
    },
    {
      "t": 50083,
      "e": 22811,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 50203,
      "e": 22931,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Which ever dots are align"
    },
    {
      "t": 50210,
      "e": 22938,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||n"
    },
    {
      "t": 50234,
      "e": 22962,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 50234,
      "e": 22962,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 50337,
      "e": 23065,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||e"
    },
    {
      "t": 50474,
      "e": 23202,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "68"
    },
    {
      "t": 50475,
      "e": 23203,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 50561,
      "e": 23289,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 50561,
      "e": 23289,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 50569,
      "e": 23297,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||d "
    },
    {
      "t": 50705,
      "e": 23433,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 53353,
      "e": 26081,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 53354,
      "e": 26082,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 53473,
      "e": 26201,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "82"
    },
    {
      "t": 53474,
      "e": 26202,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 53521,
      "e": 26249,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||er"
    },
    {
      "t": 53577,
      "e": 26305,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 53673,
      "e": 26401,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 53674,
      "e": 26402,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 53744,
      "e": 26472,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "73"
    },
    {
      "t": 53745,
      "e": 26473,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 53776,
      "e": 26504,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||ti"
    },
    {
      "t": 53849,
      "e": 26577,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 54281,
      "e": 27009,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 54353,
      "e": 27081,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Which ever dots are aligned ert"
    },
    {
      "t": 54434,
      "e": 27162,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 54488,
      "e": 27216,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Which ever dots are aligned er"
    },
    {
      "t": 54593,
      "e": 27321,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 54641,
      "e": 27369,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Which ever dots are aligned e"
    },
    {
      "t": 54729,
      "e": 27457,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 54785,
      "e": 27513,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Which ever dots are aligned "
    },
    {
      "t": 55481,
      "e": 28209,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "86"
    },
    {
      "t": 55481,
      "e": 28209,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 55601,
      "e": 28329,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||v"
    },
    {
      "t": 55665,
      "e": 28393,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 55666,
      "e": 28394,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 55785,
      "e": 28513,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "82"
    },
    {
      "t": 55786,
      "e": 28514,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 55833,
      "e": 28561,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||er"
    },
    {
      "t": 55896,
      "e": 28624,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 56010,
      "e": 28738,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 56011,
      "e": 28739,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 56089,
      "e": 28817,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 56097,
      "e": 28825,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "73"
    },
    {
      "t": 56097,
      "e": 28825,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 56201,
      "e": 28929,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||i"
    },
    {
      "t": 56338,
      "e": 29066,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "67"
    },
    {
      "t": 56338,
      "e": 29066,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 56498,
      "e": 29226,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 56498,
      "e": 29226,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 56505,
      "e": 29233,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||ca"
    },
    {
      "t": 56649,
      "e": 29377,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "76"
    },
    {
      "t": 56649,
      "e": 29377,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 56657,
      "e": 29385,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||l"
    },
    {
      "t": 56721,
      "e": 29449,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 56818,
      "e": 29546,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "76"
    },
    {
      "t": 56819,
      "e": 29547,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 56905,
      "e": 29633,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||l"
    },
    {
      "t": 57146,
      "e": 29874,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "89"
    },
    {
      "t": 57146,
      "e": 29874,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 57258,
      "e": 29986,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||y"
    },
    {
      "t": 57322,
      "e": 30050,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 57322,
      "e": 30050,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 57417,
      "e": 30145,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 57585,
      "e": 30313,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "87"
    },
    {
      "t": 57586,
      "e": 30314,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 57688,
      "e": 30416,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||w"
    },
    {
      "t": 57713,
      "e": 30441,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "73"
    },
    {
      "t": 57713,
      "e": 30441,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 57825,
      "e": 30553,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||i"
    },
    {
      "t": 57889,
      "e": 30617,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 57890,
      "e": 30618,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 57984,
      "e": 30712,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 57985,
      "e": 30713,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "72"
    },
    {
      "t": 57985,
      "e": 30713,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 58065,
      "e": 30793,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||h"
    },
    {
      "t": 58090,
      "e": 30818,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 58091,
      "e": 30819,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 58190,
      "e": 30918,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 58191,
      "e": 30919,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 58221,
      "e": 30949,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| t"
    },
    {
      "t": 58309,
      "e": 31037,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 58358,
      "e": 31086,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "72"
    },
    {
      "t": 58358,
      "e": 31086,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 58470,
      "e": 31198,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||h"
    },
    {
      "t": 58582,
      "e": 31310,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 58583,
      "e": 31311,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 58693,
      "e": 31421,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||e"
    },
    {
      "t": 58838,
      "e": 31566,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 58838,
      "e": 31566,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 58901,
      "e": 31629,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 59007,
      "e": 31735,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Which ever dots are aligned vertically with the "
    },
    {
      "t": 60005,
      "e": 32733,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 60165,
      "e": 32893,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "49"
    },
    {
      "t": 60166,
      "e": 32894,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 60278,
      "e": 33006,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "50"
    },
    {
      "t": 60279,
      "e": 33007,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 60341,
      "e": 33069,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||12"
    },
    {
      "t": 60438,
      "e": 33166,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 60815,
      "e": 33543,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "80"
    },
    {
      "t": 60815,
      "e": 33543,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 60997,
      "e": 33725,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "77"
    },
    {
      "t": 60997,
      "e": 33725,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 60999,
      "e": 33727,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "74"
    },
    {
      "t": 60999,
      "e": 33727,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 61013,
      "e": 33741,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||pmj"
    },
    {
      "t": 61053,
      "e": 33781,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 61093,
      "e": 33821,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 61093,
      "e": 33821,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 61157,
      "e": 33885,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 61245,
      "e": 33973,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 61534,
      "e": 34262,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 61621,
      "e": 34349,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Which ever dots are aligned vertically with the 12pmj"
    },
    {
      "t": 61870,
      "e": 34598,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 61957,
      "e": 34685,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Which ever dots are aligned vertically with the 12pm"
    },
    {
      "t": 62094,
      "e": 34822,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 62094,
      "e": 34822,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 62197,
      "e": 34925,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 62806,
      "e": 35534,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "77"
    },
    {
      "t": 62807,
      "e": 35535,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 62894,
      "e": 35622,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||m"
    },
    {
      "t": 62902,
      "e": 35630,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 62902,
      "e": 35630,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 63005,
      "e": 35733,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||a"
    },
    {
      "t": 63150,
      "e": 35878,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "82"
    },
    {
      "t": 63151,
      "e": 35879,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 63214,
      "e": 35942,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||r"
    },
    {
      "t": 63535,
      "e": 36263,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "75"
    },
    {
      "t": 63536,
      "e": 36264,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 63646,
      "e": 36374,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 63646,
      "e": 36374,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 63670,
      "e": 36398,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||ke"
    },
    {
      "t": 63782,
      "e": 36510,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "82"
    },
    {
      "t": 63782,
      "e": 36510,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 63837,
      "e": 36565,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||r"
    },
    {
      "t": 63925,
      "e": 36653,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 63933,
      "e": 36661,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 63933,
      "e": 36661,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 64064,
      "e": 36792,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 64189,
      "e": 36917,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "79"
    },
    {
      "t": 64190,
      "e": 36918,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 64262,
      "e": 36990,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||o"
    },
    {
      "t": 64406,
      "e": 37134,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "78"
    },
    {
      "t": 64407,
      "e": 37135,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 64509,
      "e": 37237,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||n"
    },
    {
      "t": 64533,
      "e": 37261,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 64533,
      "e": 37261,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 64630,
      "e": 37358,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 64686,
      "e": 37414,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 64687,
      "e": 37415,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 64798,
      "e": 37526,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 64829,
      "e": 37557,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "72"
    },
    {
      "t": 64829,
      "e": 37557,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 64926,
      "e": 37654,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 64927,
      "e": 37655,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 64934,
      "e": 37662,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||he"
    },
    {
      "t": 65029,
      "e": 37757,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 65030,
      "e": 37758,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 65054,
      "e": 37782,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 65149,
      "e": 37877,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 70006,
      "e": 42734,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 74686,
      "e": 42877,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "72"
    },
    {
      "t": 74687,
      "e": 42878,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 74789,
      "e": 42980,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "79"
    },
    {
      "t": 74789,
      "e": 42980,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 74853,
      "e": 43044,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||ho"
    },
    {
      "t": 74917,
      "e": 43108,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 74933,
      "e": 43124,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "82"
    },
    {
      "t": 74935,
      "e": 43126,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 75045,
      "e": 43236,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||r"
    },
    {
      "t": 75095,
      "e": 43286,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "73"
    },
    {
      "t": 75095,
      "e": 43286,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 75208,
      "e": 43399,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Which ever dots are aligned vertically with the 12pm marker on the hori"
    },
    {
      "t": 75213,
      "e": 43404,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||i"
    },
    {
      "t": 75725,
      "e": 43916,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "90"
    },
    {
      "t": 75726,
      "e": 43917,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 75853,
      "e": 44044,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||z"
    },
    {
      "t": 75860,
      "e": 44051,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "79"
    },
    {
      "t": 75862,
      "e": 44053,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 76008,
      "e": 44199,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Which ever dots are aligned vertically with the 12pm marker on the horizo"
    },
    {
      "t": 76030,
      "e": 44221,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "78"
    },
    {
      "t": 76030,
      "e": 44221,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 76061,
      "e": 44252,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||on"
    },
    {
      "t": 76156,
      "e": 44347,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 76325,
      "e": 44516,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 76326,
      "e": 44517,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 76444,
      "e": 44635,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 76573,
      "e": 44764,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 76574,
      "e": 44765,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 76686,
      "e": 44877,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "76"
    },
    {
      "t": 76686,
      "e": 44877,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 76709,
      "e": 44900,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||al"
    },
    {
      "t": 76805,
      "e": 44996,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 76805,
      "e": 44996,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 76820,
      "e": 45011,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 76901,
      "e": 45092,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 76990,
      "e": 45181,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 76990,
      "e": 45181,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 77093,
      "e": 45284,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||a"
    },
    {
      "t": 77462,
      "e": 45653,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "88"
    },
    {
      "t": 77462,
      "e": 45653,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 77524,
      "e": 45715,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||x"
    },
    {
      "t": 77573,
      "e": 45764,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "73"
    },
    {
      "t": 77573,
      "e": 45764,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 77677,
      "e": 45868,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||i"
    },
    {
      "t": 77901,
      "e": 46092,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "83"
    },
    {
      "t": 77902,
      "e": 46093,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 77997,
      "e": 46188,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||s"
    },
    {
      "t": 78004,
      "e": 46195,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "13"
    },
    {
      "t": 78005,
      "e": 46196,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 78101,
      "e": 46292,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||\n"
    },
    {
      "t": 79406,
      "e": 47597,
      "ty": 2,
      "x": 1137,
      "y": 730
    },
    {
      "t": 79506,
      "e": 47697,
      "ty": 2,
      "x": 1148,
      "y": 831
    },
    {
      "t": 79507,
      "e": 47698,
      "ty": 41,
      "x": 25510,
      "y": 49634,
      "ta": "> div.stimulus > div:[2] > svg"
    },
    {
      "t": 79606,
      "e": 47797,
      "ty": 2,
      "x": 1174,
      "y": 897
    },
    {
      "t": 79698,
      "e": 47889,
      "ty": 6,
      "x": 231,
      "y": 553,
      "ta": "#strategyAnswer"
    },
    {
      "t": 79707,
      "e": 47898,
      "ty": 2,
      "x": 231,
      "y": 553
    },
    {
      "t": 79713,
      "e": 47904,
      "ty": 7,
      "x": 0,
      "y": 477,
      "ta": "#strategyAnswer"
    },
    {
      "t": 79756,
      "e": 47947,
      "ty": 41,
      "x": 0,
      "y": 25205,
      "ta": "html"
    },
    {
      "t": 79807,
      "e": 47998,
      "ty": 2,
      "x": 49,
      "y": 474
    },
    {
      "t": 79863,
      "e": 48054,
      "ty": 6,
      "x": 240,
      "y": 529,
      "ta": "#strategyAnswer"
    },
    {
      "t": 79906,
      "e": 48097,
      "ty": 2,
      "x": 322,
      "y": 536
    },
    {
      "t": 80006,
      "e": 48197,
      "ty": 2,
      "x": 305,
      "y": 560
    },
    {
      "t": 80007,
      "e": 48198,
      "ty": 41,
      "x": 23370,
      "y": 30150,
      "ta": "#strategyAnswer"
    },
    {
      "t": 80007,
      "e": 48198,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 80065,
      "e": 48256,
      "ty": 7,
      "x": 314,
      "y": 620,
      "ta": "#strategyAnswer"
    },
    {
      "t": 80106,
      "e": 48297,
      "ty": 2,
      "x": 407,
      "y": 724
    },
    {
      "t": 80206,
      "e": 48397,
      "ty": 2,
      "x": 480,
      "y": 736
    },
    {
      "t": 80256,
      "e": 48447,
      "ty": 41,
      "x": 43042,
      "y": 40218,
      "ta": "> div.stimulus > div"
    },
    {
      "t": 80307,
      "e": 48498,
      "ty": 2,
      "x": 475,
      "y": 730
    },
    {
      "t": 80406,
      "e": 48597,
      "ty": 2,
      "x": 433,
      "y": 704
    },
    {
      "t": 80465,
      "e": 48656,
      "ty": 6,
      "x": 414,
      "y": 688,
      "ta": "#strategyButton"
    },
    {
      "t": 80507,
      "e": 48698,
      "ty": 2,
      "x": 414,
      "y": 688
    },
    {
      "t": 80507,
      "e": 48698,
      "ty": 41,
      "x": 41181,
      "y": 64119,
      "ta": "#strategyButton"
    },
    {
      "t": 80706,
      "e": 48897,
      "ty": 2,
      "x": 421,
      "y": 680
    },
    {
      "t": 80757,
      "e": 48948,
      "ty": 41,
      "x": 47188,
      "y": 44844,
      "ta": "#strategyButton"
    },
    {
      "t": 80801,
      "e": 48992,
      "ty": 3,
      "x": 425,
      "y": 678,
      "ta": "#strategyButton"
    },
    {
      "t": 80802,
      "e": 48993,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Which ever dots are aligned vertically with the 12pm marker on the horizontal axis\n"
    },
    {
      "t": 80802,
      "e": 48993,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 80802,
      "e": 48993,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#strategyButton"
    },
    {
      "t": 80805,
      "e": 48996,
      "ty": 2,
      "x": 425,
      "y": 678
    },
    {
      "t": 80898,
      "e": 49089,
      "ty": 4,
      "x": 47188,
      "y": 44844,
      "ta": "#strategyButton"
    },
    {
      "t": 80916,
      "e": 49107,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#strategyButton"
    },
    {
      "t": 80917,
      "e": 49108,
      "ty": 5,
      "x": 425,
      "y": 678,
      "ta": "#strategyButton"
    },
    {
      "t": 80922,
      "e": 49113,
      "ty": 38,
      "x": 2,
      "y": 0
    },
    {
      "t": 81924,
      "e": 50115,
      "ty": 38,
      "x": 3,
      "y": 0
    },
    {
      "t": 82756,
      "e": 50947,
      "ty": 41,
      "x": 18320,
      "y": 34789,
      "ta": "html > body"
    },
    {
      "t": 82805,
      "e": 50996,
      "ty": 2,
      "x": 675,
      "y": 612
    },
    {
      "t": 82906,
      "e": 51097,
      "ty": 2,
      "x": 740,
      "y": 602
    },
    {
      "t": 83006,
      "e": 51197,
      "ty": 2,
      "x": 770,
      "y": 596
    },
    {
      "t": 83006,
      "e": 51197,
      "ty": 41,
      "x": 26241,
      "y": 32573,
      "ta": "html > body"
    },
    {
      "t": 83051,
      "e": 51242,
      "ty": 6,
      "x": 847,
      "y": 570,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 83105,
      "e": 51296,
      "ty": 2,
      "x": 849,
      "y": 569
    },
    {
      "t": 83255,
      "e": 51446,
      "ty": 41,
      "x": 8867,
      "y": 46810,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 83298,
      "e": 51489,
      "ty": 3,
      "x": 849,
      "y": 569,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 83299,
      "e": 51490,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 83424,
      "e": 51615,
      "ty": 4,
      "x": 8867,
      "y": 46810,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 83425,
      "e": 51616,
      "ty": 5,
      "x": 849,
      "y": 569,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 84685,
      "e": 52876,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "50"
    },
    {
      "t": 84686,
      "e": 52877,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 84806,
      "e": 52997,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "2"
    },
    {
      "t": 84813,
      "e": 53004,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "48"
    },
    {
      "t": 84813,
      "e": 53004,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 84820,
      "e": 53011,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "20"
    },
    {
      "t": 84941,
      "e": 53132,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "20"
    },
    {
      "t": 85157,
      "e": 53348,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "192"
    },
    {
      "t": 85158,
      "e": 53349,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 85292,
      "e": 53483,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "20`"
    },
    {
      "t": 85909,
      "e": 54100,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "8"
    },
    {
      "t": 86157,
      "e": 54348,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "20"
    },
    {
      "t": 86685,
      "e": 54876,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "9"
    },
    {
      "t": 86686,
      "e": 54877,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "20"
    },
    {
      "t": 86687,
      "e": 54878,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 86688,
      "e": 54879,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 86877,
      "e": 55068,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": ""
    },
    {
      "t": 87533,
      "e": 55724,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "16"
    },
    {
      "t": 87774,
      "e": 55965,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "85"
    },
    {
      "t": 87774,
      "e": 55965,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 87893,
      "e": 56084,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "U"
    },
    {
      "t": 87940,
      "e": 56131,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "U"
    },
    {
      "t": 88060,
      "e": 56251,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "78"
    },
    {
      "t": 88060,
      "e": 56251,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 88207,
      "e": 56398,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "Un"
    },
    {
      "t": 88245,
      "e": 56436,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "73"
    },
    {
      "t": 88246,
      "e": 56437,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 88284,
      "e": 56475,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "Uni"
    },
    {
      "t": 88356,
      "e": 56547,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "84"
    },
    {
      "t": 88356,
      "e": 56547,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 88397,
      "e": 56588,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "Unit"
    },
    {
      "t": 88517,
      "e": 56708,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "+||"
    },
    {
      "t": 88581,
      "e": 56772,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "69"
    },
    {
      "t": 88590,
      "e": 56781,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 88740,
      "e": 56931,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "+||e"
    },
    {
      "t": 88837,
      "e": 57028,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "68"
    },
    {
      "t": 88838,
      "e": 57029,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 88972,
      "e": 57163,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "+||d"
    },
    {
      "t": 89045,
      "e": 57236,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "32"
    },
    {
      "t": 89046,
      "e": 57237,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 89165,
      "e": 57356,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "+|| "
    },
    {
      "t": 89180,
      "e": 57371,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "16"
    },
    {
      "t": 89334,
      "e": 57525,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "83"
    },
    {
      "t": 89334,
      "e": 57525,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 89429,
      "e": 57620,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "+||S"
    },
    {
      "t": 89517,
      "e": 57708,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "+||"
    },
    {
      "t": 90006,
      "e": 58197,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 90453,
      "e": 58644,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "84"
    },
    {
      "t": 90454,
      "e": 58645,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 90565,
      "e": 58756,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "+||t"
    },
    {
      "t": 90636,
      "e": 58827,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "65"
    },
    {
      "t": 90638,
      "e": 58829,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 90774,
      "e": 58965,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "+||a"
    },
    {
      "t": 90781,
      "e": 58972,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "84"
    },
    {
      "t": 90781,
      "e": 58972,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 90909,
      "e": 59100,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "+||t"
    },
    {
      "t": 91021,
      "e": 59212,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "69"
    },
    {
      "t": 91022,
      "e": 59213,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 91157,
      "e": 59348,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "+||e"
    },
    {
      "t": 91277,
      "e": 59468,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "83"
    },
    {
      "t": 91278,
      "e": 59469,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 91406,
      "e": 59597,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "United States"
    },
    {
      "t": 91421,
      "e": 59612,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "+||s"
    },
    {
      "t": 91428,
      "e": 59619,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "13"
    },
    {
      "t": 91428,
      "e": 59619,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 91557,
      "e": 59748,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "+||\n"
    },
    {
      "t": 92255,
      "e": 60446,
      "ty": 41,
      "x": 9949,
      "y": 46810,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 92305,
      "e": 60496,
      "ty": 2,
      "x": 866,
      "y": 563
    },
    {
      "t": 92375,
      "e": 60566,
      "ty": 7,
      "x": 866,
      "y": 548,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 92406,
      "e": 60597,
      "ty": 2,
      "x": 854,
      "y": 537
    },
    {
      "t": 92506,
      "e": 60697,
      "ty": 2,
      "x": 848,
      "y": 533
    },
    {
      "t": 92506,
      "e": 60697,
      "ty": 41,
      "x": 8651,
      "y": 58513,
      "ta": "#jspsych-survey-text-0 > p"
    },
    {
      "t": 92958,
      "e": 61149,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "8"
    },
    {
      "t": 93029,
      "e": 61220,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "United States"
    },
    {
      "t": 93625,
      "e": 61816,
      "ty": 6,
      "x": 858,
      "y": 558,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 93641,
      "e": 61832,
      "ty": 7,
      "x": 885,
      "y": 607,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 93675,
      "e": 61866,
      "ty": 6,
      "x": 912,
      "y": 667,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 93692,
      "e": 61883,
      "ty": 7,
      "x": 917,
      "y": 685,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 93692,
      "e": 61883,
      "ty": 6,
      "x": 917,
      "y": 685,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 93706,
      "e": 61897,
      "ty": 2,
      "x": 917,
      "y": 685
    },
    {
      "t": 93725,
      "e": 61916,
      "ty": 7,
      "x": 928,
      "y": 712,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 93756,
      "e": 61947,
      "ty": 41,
      "x": 31958,
      "y": 39775,
      "ta": "html > body"
    },
    {
      "t": 93806,
      "e": 61997,
      "ty": 2,
      "x": 950,
      "y": 743
    },
    {
      "t": 93906,
      "e": 62097,
      "ty": 2,
      "x": 951,
      "y": 733
    },
    {
      "t": 94005,
      "e": 62196,
      "ty": 2,
      "x": 958,
      "y": 712
    },
    {
      "t": 94006,
      "e": 62197,
      "ty": 41,
      "x": 32715,
      "y": 38999,
      "ta": "html > body"
    },
    {
      "t": 94062,
      "e": 62253,
      "ty": 6,
      "x": 960,
      "y": 706,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 94105,
      "e": 62296,
      "ty": 2,
      "x": 963,
      "y": 699
    },
    {
      "t": 94256,
      "e": 62447,
      "ty": 41,
      "x": 34571,
      "y": 43690,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 94305,
      "e": 62496,
      "ty": 2,
      "x": 964,
      "y": 698
    },
    {
      "t": 94338,
      "e": 62529,
      "ty": 3,
      "x": 964,
      "y": 698,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 94338,
      "e": 62529,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "United States"
    },
    {
      "t": 94339,
      "e": 62530,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 94340,
      "e": 62531,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 94497,
      "e": 62688,
      "ty": 4,
      "x": 35086,
      "y": 43690,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 94498,
      "e": 62689,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 94498,
      "e": 62689,
      "ty": 5,
      "x": 964,
      "y": 698,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 94498,
      "e": 62689,
      "ty": 38,
      "x": 4,
      "y": 0
    },
    {
      "t": 94505,
      "e": 62696,
      "ty": 41,
      "x": 32922,
      "y": 38224,
      "ta": "html > body"
    },
    {
      "t": 95515,
      "e": 63706,
      "ty": 38,
      "x": 5,
      "y": 0
    },
    {
      "t": 96205,
      "e": 64396,
      "ty": 2,
      "x": 976,
      "y": 732
    },
    {
      "t": 96256,
      "e": 64447,
      "ty": 41,
      "x": 57807,
      "y": 28086,
      "ta": "#jspsych-survey-multi-choice-option-3-0"
    },
    {
      "t": 96305,
      "e": 64496,
      "ty": 2,
      "x": 1079,
      "y": 1000
    },
    {
      "t": 96506,
      "e": 64697,
      "ty": 41,
      "x": 61129,
      "y": 53832,
      "ta": "#jspsych-survey-multi-choice-option-3-2"
    },
    {
      "t": 96606,
      "e": 64797,
      "ty": 2,
      "x": 1070,
      "y": 998
    },
    {
      "t": 96706,
      "e": 64897,
      "ty": 2,
      "x": 986,
      "y": 638
    },
    {
      "t": 96756,
      "e": 64947,
      "ty": 41,
      "x": 65059,
      "y": 3276,
      "ta": "#jspsych-survey-multi-choice-option-1-0 > label"
    },
    {
      "t": 96805,
      "e": 64996,
      "ty": 2,
      "x": 852,
      "y": 370
    },
    {
      "t": 96906,
      "e": 65097,
      "ty": 2,
      "x": 792,
      "y": 303
    },
    {
      "t": 97005,
      "e": 65196,
      "ty": 2,
      "x": 825,
      "y": 255
    },
    {
      "t": 97006,
      "e": 65197,
      "ty": 41,
      "x": 849,
      "y": 4681,
      "ta": "#jspsych-survey-multi-choice-option-0-1"
    },
    {
      "t": 97106,
      "e": 65297,
      "ty": 2,
      "x": 854,
      "y": 235
    },
    {
      "t": 97206,
      "e": 65397,
      "ty": 2,
      "x": 856,
      "y": 233
    },
    {
      "t": 97256,
      "e": 65447,
      "ty": 41,
      "x": 22582,
      "y": 19660,
      "ta": "#jspsych-survey-multi-choice-option-0-0 > label"
    },
    {
      "t": 97306,
      "e": 65497,
      "ty": 2,
      "x": 840,
      "y": 238
    },
    {
      "t": 97314,
      "e": 65505,
      "ty": 6,
      "x": 838,
      "y": 239,
      "ta": "jspsych-survey-multi-choice-response-0[0]_mf"
    },
    {
      "t": 97405,
      "e": 65596,
      "ty": 2,
      "x": 838,
      "y": 239
    },
    {
      "t": 97506,
      "e": 65697,
      "ty": 41,
      "x": 58367,
      "y": 35288,
      "ta": "jspsych-survey-multi-choice-response-0[0]_mf"
    },
    {
      "t": 97806,
      "e": 65997,
      "ty": 2,
      "x": 835,
      "y": 240
    },
    {
      "t": 97905,
      "e": 66096,
      "ty": 2,
      "x": 833,
      "y": 241
    },
    {
      "t": 98006,
      "e": 66197,
      "ty": 41,
      "x": 33161,
      "y": 45370,
      "ta": "jspsych-survey-multi-choice-response-0[0]_mf"
    },
    {
      "t": 98106,
      "e": 66297,
      "ty": 2,
      "x": 832,
      "y": 241
    },
    {
      "t": 98194,
      "e": 66385,
      "ty": 3,
      "x": 832,
      "y": 241,
      "ta": "jspsych-survey-multi-choice-response-0[0]_mf"
    },
    {
      "t": 98195,
      "e": 66386,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-0[0]_mf"
    },
    {
      "t": 98255,
      "e": 66446,
      "ty": 41,
      "x": 28120,
      "y": 45370,
      "ta": "jspsych-survey-multi-choice-response-0[0]_mf"
    },
    {
      "t": 98320,
      "e": 66511,
      "ty": 4,
      "x": 28120,
      "y": 45370,
      "ta": "jspsych-survey-multi-choice-response-0[0]_mf"
    },
    {
      "t": 98320,
      "e": 66511,
      "ty": 5,
      "x": 832,
      "y": 241,
      "ta": "jspsych-survey-multi-choice-response-0[0]_mf"
    },
    {
      "t": 98322,
      "e": 66512,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-0[0]_mf",
      "v": "English"
    },
    {
      "t": 101256,
      "e": 69446,
      "ty": 41,
      "x": 12996,
      "y": 50411,
      "ta": "jspsych-survey-multi-choice-response-0[0]_mf"
    },
    {
      "t": 101281,
      "e": 69471,
      "ty": 7,
      "x": 829,
      "y": 247,
      "ta": "jspsych-survey-multi-choice-response-0[0]_mf"
    },
    {
      "t": 101306,
      "e": 69496,
      "ty": 2,
      "x": 828,
      "y": 253
    },
    {
      "t": 101331,
      "e": 69521,
      "ty": 6,
      "x": 827,
      "y": 266,
      "ta": "jspsych-survey-multi-choice-response-0[1]_mf"
    },
    {
      "t": 101348,
      "e": 69538,
      "ty": 7,
      "x": 827,
      "y": 276,
      "ta": "jspsych-survey-multi-choice-response-0[1]_mf"
    },
    {
      "t": 101381,
      "e": 69571,
      "ty": 6,
      "x": 827,
      "y": 288,
      "ta": "jspsych-survey-multi-choice-response-0[2]_mf"
    },
    {
      "t": 101406,
      "e": 69596,
      "ty": 2,
      "x": 829,
      "y": 298
    },
    {
      "t": 101415,
      "e": 69605,
      "ty": 7,
      "x": 833,
      "y": 310,
      "ta": "jspsych-survey-multi-choice-response-0[2]_mf"
    },
    {
      "t": 101431,
      "e": 69621,
      "ty": 6,
      "x": 838,
      "y": 327,
      "ta": "jspsych-survey-multi-choice-response-0[3]_mf"
    },
    {
      "t": 101448,
      "e": 69638,
      "ty": 7,
      "x": 847,
      "y": 354,
      "ta": "jspsych-survey-multi-choice-response-0[3]_mf"
    },
    {
      "t": 101506,
      "e": 69696,
      "ty": 2,
      "x": 858,
      "y": 376
    },
    {
      "t": 101506,
      "e": 69696,
      "ty": 41,
      "x": 8680,
      "y": 49151,
      "ta": "#jspsych-survey-multi-choice-1 > p"
    },
    {
      "t": 101605,
      "e": 69795,
      "ty": 2,
      "x": 884,
      "y": 443
    },
    {
      "t": 101706,
      "e": 69896,
      "ty": 2,
      "x": 884,
      "y": 463
    },
    {
      "t": 101756,
      "e": 69946,
      "ty": 41,
      "x": 64032,
      "y": 9830,
      "ta": "#jspsych-survey-multi-choice-option-1-2 > label"
    },
    {
      "t": 101806,
      "e": 69996,
      "ty": 2,
      "x": 868,
      "y": 464
    },
    {
      "t": 101906,
      "e": 70096,
      "ty": 2,
      "x": 857,
      "y": 464
    },
    {
      "t": 102005,
      "e": 70195,
      "ty": 2,
      "x": 847,
      "y": 460
    },
    {
      "t": 102007,
      "e": 70197,
      "ty": 41,
      "x": 6070,
      "y": 7021,
      "ta": "#jspsych-survey-multi-choice-option-1-2"
    },
    {
      "t": 102106,
      "e": 70296,
      "ty": 2,
      "x": 839,
      "y": 457
    },
    {
      "t": 102150,
      "e": 70340,
      "ty": 6,
      "x": 826,
      "y": 448,
      "ta": "jspsych-survey-multi-choice-response-1[1]_mf"
    },
    {
      "t": 102170,
      "e": 70360,
      "ty": 7,
      "x": 825,
      "y": 447,
      "ta": "jspsych-survey-multi-choice-response-1[1]_mf"
    },
    {
      "t": 102206,
      "e": 70396,
      "ty": 2,
      "x": 825,
      "y": 447
    },
    {
      "t": 102256,
      "e": 70446,
      "ty": 41,
      "x": 2858,
      "y": 45874,
      "ta": "#jspsych-survey-multi-choice-option-1-1 > label"
    },
    {
      "t": 102306,
      "e": 70496,
      "ty": 2,
      "x": 825,
      "y": 443
    },
    {
      "t": 102349,
      "e": 70539,
      "ty": 6,
      "x": 827,
      "y": 438,
      "ta": "jspsych-survey-multi-choice-response-1[1]_mf"
    },
    {
      "t": 102406,
      "e": 70596,
      "ty": 2,
      "x": 830,
      "y": 438
    },
    {
      "t": 102506,
      "e": 70696,
      "ty": 2,
      "x": 832,
      "y": 437
    },
    {
      "t": 102506,
      "e": 70696,
      "ty": 41,
      "x": 28120,
      "y": 5041,
      "ta": "jspsych-survey-multi-choice-response-1[1]_mf"
    },
    {
      "t": 102538,
      "e": 70728,
      "ty": 3,
      "x": 832,
      "y": 437,
      "ta": "jspsych-survey-multi-choice-response-1[1]_mf"
    },
    {
      "t": 102538,
      "e": 70728,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-0[0]_mf"
    },
    {
      "t": 102539,
      "e": 70729,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-1[1]_mf"
    },
    {
      "t": 102689,
      "e": 70879,
      "ty": 4,
      "x": 28120,
      "y": 5041,
      "ta": "jspsych-survey-multi-choice-response-1[1]_mf"
    },
    {
      "t": 102689,
      "e": 70879,
      "ty": 5,
      "x": 832,
      "y": 437,
      "ta": "jspsych-survey-multi-choice-response-1[1]_mf"
    },
    {
      "t": 102690,
      "e": 70880,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-1[1]_mf",
      "v": "Second"
    },
    {
      "t": 104184,
      "e": 72374,
      "ty": 7,
      "x": 836,
      "y": 433,
      "ta": "jspsych-survey-multi-choice-response-1[1]_mf"
    },
    {
      "t": 104206,
      "e": 72396,
      "ty": 2,
      "x": 836,
      "y": 433
    },
    {
      "t": 104256,
      "e": 72446,
      "ty": 41,
      "x": 11644,
      "y": 0,
      "ta": "#jspsych-survey-multi-choice-option-1-1 > label"
    },
    {
      "t": 104506,
      "e": 72696,
      "ty": 2,
      "x": 834,
      "y": 433
    },
    {
      "t": 104506,
      "e": 72696,
      "ty": 41,
      "x": 10046,
      "y": 0,
      "ta": "#jspsych-survey-multi-choice-option-1-1 > label"
    },
    {
      "t": 104584,
      "e": 72774,
      "ty": 6,
      "x": 833,
      "y": 436,
      "ta": "jspsych-survey-multi-choice-response-1[1]_mf"
    },
    {
      "t": 104606,
      "e": 72796,
      "ty": 2,
      "x": 833,
      "y": 436
    },
    {
      "t": 104651,
      "e": 72841,
      "ty": 7,
      "x": 830,
      "y": 449,
      "ta": "jspsych-survey-multi-choice-response-1[1]_mf"
    },
    {
      "t": 104685,
      "e": 72875,
      "ty": 6,
      "x": 830,
      "y": 466,
      "ta": "jspsych-survey-multi-choice-response-1[2]_mf"
    },
    {
      "t": 104706,
      "e": 72896,
      "ty": 2,
      "x": 831,
      "y": 471
    },
    {
      "t": 104735,
      "e": 72925,
      "ty": 7,
      "x": 831,
      "y": 480,
      "ta": "jspsych-survey-multi-choice-response-1[2]_mf"
    },
    {
      "t": 104756,
      "e": 72925,
      "ty": 41,
      "x": 2510,
      "y": 0,
      "ta": "#jspsych-survey-multi-choice-option-1-3"
    },
    {
      "t": 104768,
      "e": 72937,
      "ty": 6,
      "x": 832,
      "y": 495,
      "ta": "jspsych-survey-multi-choice-response-1[3]_mf"
    },
    {
      "t": 104784,
      "e": 72953,
      "ty": 7,
      "x": 832,
      "y": 514,
      "ta": "jspsych-survey-multi-choice-response-1[3]_mf"
    },
    {
      "t": 104802,
      "e": 72971,
      "ty": 6,
      "x": 833,
      "y": 531,
      "ta": "jspsych-survey-multi-choice-response-1[4]_mf"
    },
    {
      "t": 104805,
      "e": 72974,
      "ty": 2,
      "x": 833,
      "y": 531
    },
    {
      "t": 104817,
      "e": 72986,
      "ty": 7,
      "x": 836,
      "y": 549,
      "ta": "jspsych-survey-multi-choice-response-1[4]_mf"
    },
    {
      "t": 104817,
      "e": 72986,
      "ty": 6,
      "x": 836,
      "y": 549,
      "ta": "jspsych-survey-multi-choice-response-1[5]_mf"
    },
    {
      "t": 104834,
      "e": 73003,
      "ty": 7,
      "x": 841,
      "y": 567,
      "ta": "jspsych-survey-multi-choice-response-1[5]_mf"
    },
    {
      "t": 104906,
      "e": 73075,
      "ty": 2,
      "x": 847,
      "y": 667
    },
    {
      "t": 105006,
      "e": 73175,
      "ty": 2,
      "x": 867,
      "y": 716
    },
    {
      "t": 105006,
      "e": 73175,
      "ty": 41,
      "x": 10816,
      "y": 63194,
      "ta": "#jspsych-survey-multi-choice-option-2-1"
    },
    {
      "t": 105106,
      "e": 73275,
      "ty": 2,
      "x": 861,
      "y": 719
    },
    {
      "t": 105206,
      "e": 73375,
      "ty": 2,
      "x": 846,
      "y": 719
    },
    {
      "t": 105256,
      "e": 73425,
      "ty": 41,
      "x": 4171,
      "y": 0,
      "ta": "#jspsych-survey-multi-choice-option-2-2"
    },
    {
      "t": 105306,
      "e": 73475,
      "ty": 2,
      "x": 839,
      "y": 717
    },
    {
      "t": 105406,
      "e": 73575,
      "ty": 2,
      "x": 838,
      "y": 715
    },
    {
      "t": 105452,
      "e": 73621,
      "ty": 6,
      "x": 834,
      "y": 704,
      "ta": "jspsych-survey-multi-choice-response-2[1]_mf"
    },
    {
      "t": 105486,
      "e": 73655,
      "ty": 7,
      "x": 828,
      "y": 693,
      "ta": "jspsych-survey-multi-choice-response-2[1]_mf"
    },
    {
      "t": 105506,
      "e": 73675,
      "ty": 2,
      "x": 828,
      "y": 692
    },
    {
      "t": 105506,
      "e": 73675,
      "ty": 41,
      "x": 1561,
      "y": 7021,
      "ta": "#jspsych-survey-multi-choice-option-2-1"
    },
    {
      "t": 105606,
      "e": 73775,
      "ty": 2,
      "x": 827,
      "y": 692
    },
    {
      "t": 105685,
      "e": 73854,
      "ty": 6,
      "x": 827,
      "y": 698,
      "ta": "jspsych-survey-multi-choice-response-2[1]_mf"
    },
    {
      "t": 105706,
      "e": 73875,
      "ty": 2,
      "x": 827,
      "y": 701
    },
    {
      "t": 105756,
      "e": 73925,
      "ty": 41,
      "x": 2914,
      "y": 50411,
      "ta": "jspsych-survey-multi-choice-response-2[1]_mf"
    },
    {
      "t": 105806,
      "e": 73975,
      "ty": 2,
      "x": 827,
      "y": 706
    },
    {
      "t": 105946,
      "e": 74115,
      "ty": 3,
      "x": 827,
      "y": 706,
      "ta": "jspsych-survey-multi-choice-response-2[1]_mf"
    },
    {
      "t": 105947,
      "e": 74116,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-1[1]_mf"
    },
    {
      "t": 105948,
      "e": 74117,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-2[1]_mf"
    },
    {
      "t": 106072,
      "e": 74241,
      "ty": 4,
      "x": 2914,
      "y": 50411,
      "ta": "jspsych-survey-multi-choice-response-2[1]_mf"
    },
    {
      "t": 106072,
      "e": 74241,
      "ty": 5,
      "x": 827,
      "y": 706,
      "ta": "jspsych-survey-multi-choice-response-2[1]_mf"
    },
    {
      "t": 106073,
      "e": 74242,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-2[1]_mf",
      "v": "Social Sciences (incl. CogSci)"
    },
    {
      "t": 108972,
      "e": 77141,
      "ty": 7,
      "x": 826,
      "y": 712,
      "ta": "jspsych-survey-multi-choice-response-2[1]_mf"
    },
    {
      "t": 109005,
      "e": 77174,
      "ty": 2,
      "x": 830,
      "y": 772
    },
    {
      "t": 109006,
      "e": 77175,
      "ty": 41,
      "x": 2035,
      "y": 63194,
      "ta": "#jspsych-survey-multi-choice-option-2-3"
    },
    {
      "t": 109106,
      "e": 77275,
      "ty": 2,
      "x": 868,
      "y": 899
    },
    {
      "t": 109206,
      "e": 77375,
      "ty": 2,
      "x": 879,
      "y": 941
    },
    {
      "t": 109256,
      "e": 77425,
      "ty": 41,
      "x": 36868,
      "y": 6553,
      "ta": "#jspsych-survey-multi-choice-option-3-1 > label"
    },
    {
      "t": 109306,
      "e": 77475,
      "ty": 2,
      "x": 853,
      "y": 961
    },
    {
      "t": 109388,
      "e": 77557,
      "ty": 6,
      "x": 839,
      "y": 961,
      "ta": "jspsych-survey-multi-choice-response-3[1]_mf"
    },
    {
      "t": 109406,
      "e": 77575,
      "ty": 2,
      "x": 838,
      "y": 961
    },
    {
      "t": 109507,
      "e": 77676,
      "ty": 41,
      "x": 58367,
      "y": 25205,
      "ta": "jspsych-survey-multi-choice-response-3[1]_mf"
    },
    {
      "t": 109545,
      "e": 77714,
      "ty": 7,
      "x": 835,
      "y": 953,
      "ta": "jspsych-survey-multi-choice-response-3[1]_mf"
    },
    {
      "t": 109606,
      "e": 77775,
      "ty": 2,
      "x": 835,
      "y": 948
    },
    {
      "t": 109757,
      "e": 77775,
      "ty": 41,
      "x": 3222,
      "y": 0,
      "ta": "#jspsych-survey-multi-choice-option-3-1"
    },
    {
      "t": 109806,
      "e": 77824,
      "ty": 2,
      "x": 835,
      "y": 949
    },
    {
      "t": 110006,
      "e": 78024,
      "ty": 2,
      "x": 833,
      "y": 952
    },
    {
      "t": 110006,
      "e": 78024,
      "ty": 41,
      "x": 2747,
      "y": 7021,
      "ta": "#jspsych-survey-multi-choice-option-3-1"
    },
    {
      "t": 110139,
      "e": 78157,
      "ty": 6,
      "x": 836,
      "y": 957,
      "ta": "jspsych-survey-multi-choice-response-3[1]_mf"
    },
    {
      "t": 110206,
      "e": 78224,
      "ty": 2,
      "x": 839,
      "y": 961
    },
    {
      "t": 110242,
      "e": 78260,
      "ty": 3,
      "x": 839,
      "y": 961,
      "ta": "jspsych-survey-multi-choice-response-3[1]_mf"
    },
    {
      "t": 110243,
      "e": 78261,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-2[1]_mf"
    },
    {
      "t": 110243,
      "e": 78261,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-3[1]_mf"
    },
    {
      "t": 110256,
      "e": 78274,
      "ty": 41,
      "x": 63408,
      "y": 25205,
      "ta": "jspsych-survey-multi-choice-response-3[1]_mf"
    },
    {
      "t": 110377,
      "e": 78395,
      "ty": 4,
      "x": 63408,
      "y": 25205,
      "ta": "jspsych-survey-multi-choice-response-3[1]_mf"
    },
    {
      "t": 110377,
      "e": 78395,
      "ty": 5,
      "x": 839,
      "y": 961,
      "ta": "jspsych-survey-multi-choice-response-3[1]_mf"
    },
    {
      "t": 110377,
      "e": 78395,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-3[1]_mf",
      "v": "Female"
    },
    {
      "t": 110554,
      "e": 78572,
      "ty": 7,
      "x": 840,
      "y": 963,
      "ta": "jspsych-survey-multi-choice-response-3[1]_mf"
    },
    {
      "t": 110606,
      "e": 78624,
      "ty": 2,
      "x": 842,
      "y": 969
    },
    {
      "t": 110706,
      "e": 78724,
      "ty": 2,
      "x": 848,
      "y": 996
    },
    {
      "t": 110740,
      "e": 78758,
      "ty": 6,
      "x": 853,
      "y": 1013,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 110755,
      "e": 78773,
      "ty": 41,
      "x": 13698,
      "y": 33760,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 110789,
      "e": 78807,
      "ty": 7,
      "x": 870,
      "y": 1040,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 110806,
      "e": 78824,
      "ty": 2,
      "x": 877,
      "y": 1042
    },
    {
      "t": 110906,
      "e": 78924,
      "ty": 2,
      "x": 878,
      "y": 1042
    },
    {
      "t": 110941,
      "e": 78959,
      "ty": 6,
      "x": 882,
      "y": 1037,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 111007,
      "e": 79025,
      "ty": 2,
      "x": 891,
      "y": 1025
    },
    {
      "t": 111007,
      "e": 79025,
      "ty": 41,
      "x": 31736,
      "y": 39718,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 111106,
      "e": 79124,
      "ty": 2,
      "x": 892,
      "y": 1022
    },
    {
      "t": 111137,
      "e": 79155,
      "ty": 3,
      "x": 892,
      "y": 1022,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 111139,
      "e": 79157,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-3[1]_mf"
    },
    {
      "t": 111139,
      "e": 79157,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 111256,
      "e": 79274,
      "ty": 41,
      "x": 32252,
      "y": 33760,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 111280,
      "e": 79298,
      "ty": 4,
      "x": 32252,
      "y": 33760,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 111280,
      "e": 79298,
      "ty": 5,
      "x": 892,
      "y": 1022,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 111283,
      "e": 79301,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 111284,
      "e": 79302,
      "ty": 13,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-multi-choice-form"
    },
    {
      "t": 111285,
      "e": 79303,
      "ty": 38,
      "x": 6,
      "y": 0
    },
    {
      "t": 112636,
      "e": 80654,
      "ty": 38,
      "x": 7,
      "y": 0
    },
    {
      "t": 113406,
      "e": 81424,
      "ty": 2,
      "x": 892,
      "y": 1021
    },
    {
      "t": 113505,
      "e": 81523,
      "ty": 2,
      "x": 892,
      "y": 1020
    },
    {
      "t": 113506,
      "e": 81524,
      "ty": 41,
      "x": 29446,
      "y": 61886,
      "ta": "> div.masterdiv > div:[2]"
    },
    {
      "t": 120010,
      "e": 86524,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 126310,
      "e": 86524,
      "ty": 2,
      "x": 892,
      "y": 1019
    },
    {
      "t": 126510,
      "e": 86724,
      "ty": 41,
      "x": 29446,
      "y": 61817,
      "ta": "> div.masterdiv > div:[2]"
    },
    {
      "t": 127609,
      "e": 87823,
      "ty": 2,
      "x": 947,
      "y": 1019
    },
    {
      "t": 127710,
      "e": 87924,
      "ty": 2,
      "x": 957,
      "y": 1021
    },
    {
      "t": 127760,
      "e": 87974,
      "ty": 41,
      "x": 32644,
      "y": 61955,
      "ta": "> div.masterdiv > div:[2]"
    },
    {
      "t": 127910,
      "e": 88124,
      "ty": 2,
      "x": 972,
      "y": 1049
    },
    {
      "t": 127958,
      "e": 88172,
      "ty": 6,
      "x": 979,
      "y": 1073,
      "ta": "#start"
    },
    {
      "t": 128010,
      "e": 88224,
      "ty": 2,
      "x": 980,
      "y": 1082
    },
    {
      "t": 128010,
      "e": 88224,
      "ty": 41,
      "x": 38501,
      "y": 17949,
      "ta": "#start"
    },
    {
      "t": 128109,
      "e": 88323,
      "ty": 2,
      "x": 980,
      "y": 1085
    },
    {
      "t": 128174,
      "e": 88388,
      "ty": 7,
      "x": 992,
      "y": 1111,
      "ta": "#start"
    },
    {
      "t": 128209,
      "e": 88423,
      "ty": 2,
      "x": 993,
      "y": 1114
    },
    {
      "t": 128260,
      "e": 88474,
      "ty": 41,
      "x": 48449,
      "y": 22886,
      "ta": "> div.masterdiv > div:[3]"
    },
    {
      "t": 128410,
      "e": 88624,
      "ty": 2,
      "x": 988,
      "y": 1113
    },
    {
      "t": 128441,
      "e": 88655,
      "ty": 6,
      "x": 979,
      "y": 1106,
      "ta": "#start"
    },
    {
      "t": 128510,
      "e": 88724,
      "ty": 2,
      "x": 969,
      "y": 1099
    },
    {
      "t": 128510,
      "e": 88724,
      "ty": 41,
      "x": 32494,
      "y": 50717,
      "ta": "#start"
    },
    {
      "t": 128760,
      "e": 88974,
      "ty": 41,
      "x": 31948,
      "y": 48789,
      "ta": "#start"
    },
    {
      "t": 128810,
      "e": 89024,
      "ty": 2,
      "x": 968,
      "y": 1097
    },
    {
      "t": 129010,
      "e": 89224,
      "ty": 41,
      "x": 31948,
      "y": 46862,
      "ta": "#start"
    },
    {
      "t": 133326,
      "e": 93540,
      "ty": 3,
      "x": 968,
      "y": 1097,
      "ta": "#start"
    },
    {
      "t": 133326,
      "e": 93540,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#start"
    },
    {
      "t": 133492,
      "e": 93706,
      "ty": 4,
      "x": 31948,
      "y": 46862,
      "ta": "#start"
    },
    {
      "t": 133492,
      "e": 93706,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#start"
    },
    {
      "t": 133493,
      "e": 93707,
      "ty": 5,
      "x": 968,
      "y": 1097,
      "ta": "#start"
    },
    {
      "t": 133494,
      "e": 93708,
      "ty": 38,
      "x": 8,
      "y": 0
    },
    {
      "t": 134530,
      "e": 94744,
      "ty": 38,
      "x": 9,
      "y": 0
    },
    {
      "t": 135753,
      "e": 95967,
      "ty": 20,
      "x": 0,
      "y": 0
    }
  ],
  "domMutations": [
    {
      "sequence": 1,
      "data": "{\"f\":\"applyChanged\",\"args\":[[],[{\"nodeType\":1,\"id\":2311,\"tagName\":\"g\",\"attributes\":{\"class\":\"xaxis\",\"transform\":\"translate(0,800)\",\"fill\":\"none\",\"font-size\":\"10\",\"font-family\":\"sans-serif\",\"text-anchor\":\"middle\"},\"previousSibling\":{\"id\":2302},\"parentNode\":{\"id\":2300}},{\"nodeType\":1,\"id\":2312,\"tagName\":\"g\",\"attributes\":{\"class\":\"yaxis\",\"fill\":\"none\",\"font-size\":\"10\",\"font-family\":\"sans-serif\",\"text-anchor\":\"end\"},\"previousSibling\":{\"id\":2311},\"parentNode\":{\"id\":2300}},{\"nodeType\":1,\"id\":2313,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"previousSibling\":{\"id\":2312},\"parentNode\":{\"id\":2300}},{\"nodeType\":1,\"id\":2314,\"tagName\":\"g\",\"attributes\":{\"class\":\"xgrid\"},\"previousSibling\":{\"id\":2313},\"parentNode\":{\"id\":2300}},{\"nodeType\":1,\"id\":2315,\"tagName\":\"g\",\"attributes\":{\"class\":\"data\"},\"previousSibling\":{\"id\":2314},\"parentNode\":{\"id\":2300}},{\"nodeType\":1,\"id\":2316,\"tagName\":\"path\",\"attributes\":{\"class\":\"domain\",\"stroke\":\"#000\",\"d\":\"M0.5,6V0.5H800.5V6\"},\"parentNode\":{\"id\":2311}},{\"nodeType\":1,\"id\":2317,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0.5,0)\"},\"previousSibling\":{\"id\":2316},\"parentNode\":{\"id\":2311}},{\"nodeType\":1,\"id\":2318,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(33.83333333333333,0)\"},\"previousSibling\":{\"id\":2317},\"parentNode\":{\"id\":2311}},{\"nodeType\":1,\"id\":2319,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(67.16666666666666,0)\"},\"previousSibling\":{\"id\":2318},\"parentNode\":{\"id\":2311}},{\"nodeType\":1,\"id\":2320,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(100.5,0)\"},\"previousSibling\":{\"id\":2319},\"parentNode\":{\"id\":2311}},{\"nodeType\":1,\"id\":2321,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(133.83333333333331,0)\"},\"previousSibling\":{\"id\":2320},\"parentNode\":{\"id\":2311}},{\"nodeType\":1,\"id\":2322,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(167.16666666666669,0)\"},\"previousSibling\":{\"id\":2321},\"parentNode\":{\"id\":2311}},{\"nodeType\":1,\"id\":2323,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(200.5,0)\"},\"previousSibling\":{\"id\":2322},\"parentNode\":{\"id\":2311}},{\"nodeType\":1,\"id\":2324,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(233.83333333333334,0)\"},\"previousSibling\":{\"id\":2323},\"parentNode\":{\"id\":2311}},{\"nodeType\":1,\"id\":2325,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(267.16666666666663,0)\"},\"previousSibling\":{\"id\":2324},\"parentNode\":{\"id\":2311}},{\"nodeType\":1,\"id\":2326,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(300.5,0)\"},\"previousSibling\":{\"id\":2325},\"parentNode\":{\"id\":2311}},{\"nodeType\":1,\"id\":2327,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(333.83333333333337,0)\"},\"previousSibling\":{\"id\":2326},\"parentNode\":{\"id\":2311}},{\"nodeType\":1,\"id\":2328,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(367.16666666666663,0)\"},\"previousSibling\":{\"id\":2327},\"parentNode\":{\"id\":2311}},{\"nodeType\":1,\"id\":2329,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(400.5,0)\"},\"previousSibling\":{\"id\":2328},\"parentNode\":{\"id\":2311}},{\"nodeType\":1,\"id\":2330,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(433.8333333333333,0)\"},\"previousSibling\":{\"id\":2329},\"parentNode\":{\"id\":2311}},{\"nodeType\":1,\"id\":2331,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(467.1666666666667,0)\"},\"previousSibling\":{\"id\":2330},\"parentNode\":{\"id\":2311}},{\"nodeType\":1,\"id\":2332,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(500.5,0)\"},\"previousSibling\":{\"id\":2331},\"parentNode\":{\"id\":2311}},{\"nodeType\":1,\"id\":2333,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(533.8333333333333,0)\"},\"previousSibling\":{\"id\":2332},\"parentNode\":{\"id\":2311}},{\"nodeType\":1,\"id\":2334,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(567.1666666666667,0)\"},\"previousSibling\":{\"id\":2333},\"parentNode\":{\"id\":2311}},{\"nodeType\":1,\"id\":2335,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(600.5,0)\"},\"previousSibling\":{\"id\":2334},\"parentNode\":{\"id\":2311}},{\"nodeType\":1,\"id\":2336,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(633.8333333333333,0)\"},\"previousSibling\":{\"id\":2335},\"parentNode\":{\"id\":2311}},{\"nodeType\":1,\"id\":2337,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(667.1666666666667,0)\"},\"previousSibling\":{\"id\":2336},\"parentNode\":{\"id\":2311}},{\"nodeType\":1,\"id\":2338,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(700.5,0)\"},\"previousSibling\":{\"id\":2337},\"parentNode\":{\"id\":2311}},{\"nodeType\":1,\"id\":2339,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(733.8333333333333,0)\"},\"previousSibling\":{\"id\":2338},\"parentNode\":{\"id\":2311}},{\"nodeType\":1,\"id\":2340,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(767.1666666666667,0)\"},\"previousSibling\":{\"id\":2339},\"parentNode\":{\"id\":2311}},{\"nodeType\":1,\"id\":2341,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(800.5,0)\"},\"previousSibling\":{\"id\":2340},\"parentNode\":{\"id\":2311}},{\"nodeType\":1,\"id\":2342,\"tagName\":\"g\",\"attributes\":{\"class\":\"axisTitle\"},\"previousSibling\":{\"id\":2341},\"parentNode\":{\"id\":2311}},{\"nodeType\":1,\"id\":2343,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"},\"parentNode\":{\"id\":2317}},{\"nodeType\":1,\"id\":2344,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"previousSibling\":{\"id\":2343},\"parentNode\":{\"id\":2317}},{\"nodeType\":1,\"id\":2345,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"},\"parentNode\":{\"id\":2318}},{\"nodeType\":1,\"id\":2346,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"previousSibling\":{\"id\":2345},\"parentNode\":{\"id\":2318}},{\"nodeType\":1,\"id\":2347,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"},\"parentNode\":{\"id\":2319}},{\"nodeType\":1,\"id\":2348,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"previousSibling\":{\"id\":2347},\"parentNode\":{\"id\":2319}},{\"nodeType\":1,\"id\":2349,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"},\"parentNode\":{\"id\":2320}},{\"nodeType\":1,\"id\":2350,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"previousSibling\":{\"id\":2349},\"parentNode\":{\"id\":2320}},{\"nodeType\":1,\"id\":2351,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"},\"parentNode\":{\"id\":2321}},{\"nodeType\":1,\"id\":2352,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"previousSibling\":{\"id\":2351},\"parentNode\":{\"id\":2321}},{\"nodeType\":1,\"id\":2353,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"},\"parentNode\":{\"id\":2322}},{\"nodeType\":1,\"id\":2354,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"previousSibling\":{\"id\":2353},\"parentNode\":{\"id\":2322}},{\"nodeType\":1,\"id\":2355,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"},\"parentNode\":{\"id\":2323}},{\"nodeType\":1,\"id\":2356,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"previousSibling\":{\"id\":2355},\"parentNode\":{\"id\":2323}},{\"nodeType\":1,\"id\":2357,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"},\"parentNode\":{\"id\":2324}},{\"nodeType\":1,\"id\":2358,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"previousSibling\":{\"id\":2357},\"parentNode\":{\"id\":2324}},{\"nodeType\":1,\"id\":2359,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"},\"parentNode\":{\"id\":2325}},{\"nodeType\":1,\"id\":2360,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"previousSibling\":{\"id\":2359},\"parentNode\":{\"id\":2325}},{\"nodeType\":1,\"id\":2361,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"},\"parentNode\":{\"id\":2326}},{\"nodeType\":1,\"id\":2362,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"previousSibling\":{\"id\":2361},\"parentNode\":{\"id\":2326}},{\"nodeType\":1,\"id\":2363,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"},\"parentNode\":{\"id\":2327}},{\"nodeType\":1,\"id\":2364,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"previousSibling\":{\"id\":2363},\"parentNode\":{\"id\":2327}},{\"nodeType\":1,\"id\":2365,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"},\"parentNode\":{\"id\":2328}},{\"nodeType\":1,\"id\":2366,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"previousSibling\":{\"id\":2365},\"parentNode\":{\"id\":2328}},{\"nodeType\":1,\"id\":2367,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"},\"parentNode\":{\"id\":2329}},{\"nodeType\":1,\"id\":2368,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"previousSibling\":{\"id\":2367},\"parentNode\":{\"id\":2329}},{\"nodeType\":1,\"id\":2369,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"},\"parentNode\":{\"id\":2330}},{\"nodeType\":1,\"id\":2370,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"previousSibling\":{\"id\":2369},\"parentNode\":{\"id\":2330}},{\"nodeType\":1,\"id\":2371,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"},\"parentNode\":{\"id\":2331}},{\"nodeType\":1,\"id\":2372,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"previousSibling\":{\"id\":2371},\"parentNode\":{\"id\":2331}},{\"nodeType\":1,\"id\":2373,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"},\"parentNode\":{\"id\":2332}},{\"nodeType\":1,\"id\":2374,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"previousSibling\":{\"id\":2373},\"parentNode\":{\"id\":2332}},{\"nodeType\":1,\"id\":2375,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"},\"parentNode\":{\"id\":2333}},{\"nodeType\":1,\"id\":2376,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"previousSibling\":{\"id\":2375},\"parentNode\":{\"id\":2333}},{\"nodeType\":1,\"id\":2377,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"},\"parentNode\":{\"id\":2334}},{\"nodeType\":1,\"id\":2378,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"previousSibling\":{\"id\":2377},\"parentNode\":{\"id\":2334}},{\"nodeType\":1,\"id\":2379,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"},\"parentNode\":{\"id\":2335}},{\"nodeType\":1,\"id\":2380,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"previousSibling\":{\"id\":2379},\"parentNode\":{\"id\":2335}},{\"nodeType\":1,\"id\":2381,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"},\"parentNode\":{\"id\":2336}},{\"nodeType\":1,\"id\":2382,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"previousSibling\":{\"id\":2381},\"parentNode\":{\"id\":2336}},{\"nodeType\":1,\"id\":2383,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"},\"parentNode\":{\"id\":2337}},{\"nodeType\":1,\"id\":2384,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"previousSibling\":{\"id\":2383},\"parentNode\":{\"id\":2337}},{\"nodeType\":1,\"id\":2385,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"},\"parentNode\":{\"id\":2338}},{\"nodeType\":1,\"id\":2386,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"previousSibling\":{\"id\":2385},\"parentNode\":{\"id\":2338}},{\"nodeType\":1,\"id\":2387,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"},\"parentNode\":{\"id\":2339}},{\"nodeType\":1,\"id\":2388,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"previousSibling\":{\"id\":2387},\"parentNode\":{\"id\":2339}},{\"nodeType\":1,\"id\":2389,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"},\"parentNode\":{\"id\":2340}},{\"nodeType\":1,\"id\":2390,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"previousSibling\":{\"id\":2389},\"parentNode\":{\"id\":2340}},{\"nodeType\":1,\"id\":2391,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"},\"parentNode\":{\"id\":2341}},{\"nodeType\":1,\"id\":2392,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"previousSibling\":{\"id\":2391},\"parentNode\":{\"id\":2341}},{\"nodeType\":3,\"id\":2393,\"textContent\":\"08 AM\",\"parentNode\":{\"id\":2344}},{\"nodeType\":3,\"id\":2394,\"textContent\":\"08:30\",\"parentNode\":{\"id\":2346}},{\"nodeType\":3,\"id\":2395,\"textContent\":\"09 AM\",\"parentNode\":{\"id\":2348}},{\"nodeType\":3,\"id\":2396,\"textContent\":\"09:30\",\"parentNode\":{\"id\":2350}},{\"nodeType\":3,\"id\":2397,\"textContent\":\"10 AM\",\"parentNode\":{\"id\":2352}},{\"nodeType\":3,\"id\":2398,\"textContent\":\"10:30\",\"parentNode\":{\"id\":2354}},{\"nodeType\":3,\"id\":2399,\"textContent\":\"11 AM\",\"parentNode\":{\"id\":2356}},{\"nodeType\":3,\"id\":2400,\"textContent\":\"11:30\",\"parentNode\":{\"id\":2358}},{\"nodeType\":3,\"id\":2401,\"textContent\":\"12 PM\",\"parentNode\":{\"id\":2360}},{\"nodeType\":3,\"id\":2402,\"textContent\":\"12:30\",\"parentNode\":{\"id\":2362}},{\"nodeType\":3,\"id\":2403,\"textContent\":\"01 PM\",\"parentNode\":{\"id\":2364}},{\"nodeType\":3,\"id\":2404,\"textContent\":\"01:30\",\"parentNode\":{\"id\":2366}},{\"nodeType\":3,\"id\":2405,\"textContent\":\"02 PM\",\"parentNode\":{\"id\":2368}},{\"nodeType\":3,\"id\":2406,\"textContent\":\"02:30\",\"parentNode\":{\"id\":2370}},{\"nodeType\":3,\"id\":2407,\"textContent\":\"03 PM\",\"parentNode\":{\"id\":2372}},{\"nodeType\":3,\"id\":2408,\"textContent\":\"03:30\",\"parentNode\":{\"id\":2374}},{\"nodeType\":3,\"id\":2409,\"textContent\":\"04 PM\",\"parentNode\":{\"id\":2376}},{\"nodeType\":3,\"id\":2410,\"textContent\":\"04:30\",\"parentNode\":{\"id\":2378}},{\"nodeType\":3,\"id\":2411,\"textContent\":\"05 PM\",\"parentNode\":{\"id\":2380}},{\"nodeType\":3,\"id\":2412,\"textContent\":\"05:30\",\"parentNode\":{\"id\":2382}},{\"nodeType\":3,\"id\":2413,\"textContent\":\"06 PM\",\"parentNode\":{\"id\":2384}},{\"nodeType\":3,\"id\":2414,\"textContent\":\"06:30\",\"parentNode\":{\"id\":2386}},{\"nodeType\":3,\"id\":2415,\"textContent\":\"07 PM\",\"parentNode\":{\"id\":2388}},{\"nodeType\":3,\"id\":2416,\"textContent\":\"07:30\",\"parentNode\":{\"id\":2390}},{\"nodeType\":3,\"id\":2417,\"textContent\":\"08 PM\",\"parentNode\":{\"id\":2392}},{\"nodeType\":1,\"id\":2418,\"tagName\":\"text\",\"attributes\":{\"x\":\"533.3333333333334\",\"y\":\"80\",\"style\":\"text-anchor: end;\"},\"parentNode\":{\"id\":2342}},{\"nodeType\":3,\"id\":2419,\"textContent\":\"START & END TIME (time of day)\",\"parentNode\":{\"id\":2418}},{\"nodeType\":1,\"id\":2420,\"tagName\":\"path\",\"attributes\":{\"class\":\"domain\",\"stroke\":\"#000\",\"d\":\"M-15,800.5H0.5V0.5H-15\"},\"parentNode\":{\"id\":2312}},{\"nodeType\":1,\"id\":2421,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,800.5)\"},\"previousSibling\":{\"id\":2420},\"parentNode\":{\"id\":2312}},{\"nodeType\":1,\"id\":2422,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,733.8333333333334)\"},\"previousSibling\":{\"id\":2421},\"parentNode\":{\"id\":2312}},{\"nodeType\":1,\"id\":2423,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,667.1666666666667)\"},\"previousSibling\":{\"id\":2422},\"parentNode\":{\"id\":2312}},{\"nodeType\":1,\"id\":2424,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,600.5)\"},\"previousSibling\":{\"id\":2423},\"parentNode\":{\"id\":2312}},{\"nodeType\":1,\"id\":2425,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,533.8333333333334)\"},\"previousSibling\":{\"id\":2424},\"parentNode\":{\"id\":2312}},{\"nodeType\":1,\"id\":2426,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,467.16666666666663)\"},\"previousSibling\":{\"id\":2425},\"parentNode\":{\"id\":2312}},{\"nodeType\":1,\"id\":2427,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,400.5)\"},\"previousSibling\":{\"id\":2426},\"parentNode\":{\"id\":2312}},{\"nodeType\":1,\"id\":2428,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,333.8333333333333)\"},\"previousSibling\":{\"id\":2427},\"parentNode\":{\"id\":2312}},{\"nodeType\":1,\"id\":2429,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,267.16666666666674)\"},\"previousSibling\":{\"id\":2428},\"parentNode\":{\"id\":2312}},{\"nodeType\":1,\"id\":2430,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,200.5)\"},\"previousSibling\":{\"id\":2429},\"parentNode\":{\"id\":2312}},{\"nodeType\":1,\"id\":2431,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,133.83333333333326)\"},\"previousSibling\":{\"id\":2430},\"parentNode\":{\"id\":2312}},{\"nodeType\":1,\"id\":2432,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,67.16666666666674)\"},\"previousSibling\":{\"id\":2431},\"parentNode\":{\"id\":2312}},{\"nodeType\":1,\"id\":2433,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,0.5)\"},\"previousSibling\":{\"id\":2432},\"parentNode\":{\"id\":2312}},{\"nodeType\":1,\"id\":2434,\"tagName\":\"g\",\"attributes\":{\"class\":\"axisTitle\"},\"previousSibling\":{\"id\":2433},\"parentNode\":{\"id\":2312}},{\"nodeType\":1,\"id\":2435,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"},\"parentNode\":{\"id\":2421}},{\"nodeType\":1,\"id\":2436,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"previousSibling\":{\"id\":2435},\"parentNode\":{\"id\":2421}},{\"nodeType\":1,\"id\":2437,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"},\"parentNode\":{\"id\":2422}},{\"nodeType\":1,\"id\":2438,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"previousSibling\":{\"id\":2437},\"parentNode\":{\"id\":2422}},{\"nodeType\":1,\"id\":2439,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"},\"parentNode\":{\"id\":2423}},{\"nodeType\":1,\"id\":2440,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"previousSibling\":{\"id\":2439},\"parentNode\":{\"id\":2423}},{\"nodeType\":1,\"id\":2441,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"},\"parentNode\":{\"id\":2424}},{\"nodeType\":1,\"id\":2442,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"previousSibling\":{\"id\":2441},\"parentNode\":{\"id\":2424}},{\"nodeType\":1,\"id\":2443,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"},\"parentNode\":{\"id\":2425}},{\"nodeType\":1,\"id\":2444,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"previousSibling\":{\"id\":2443},\"parentNode\":{\"id\":2425}},{\"nodeType\":1,\"id\":2445,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"},\"parentNode\":{\"id\":2426}},{\"nodeType\":1,\"id\":2446,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"previousSibling\":{\"id\":2445},\"parentNode\":{\"id\":2426}},{\"nodeType\":1,\"id\":2447,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"},\"parentNode\":{\"id\":2427}},{\"nodeType\":1,\"id\":2448,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"previousSibling\":{\"id\":2447},\"parentNode\":{\"id\":2427}},{\"nodeType\":1,\"id\":2449,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"},\"parentNode\":{\"id\":2428}},{\"nodeType\":1,\"id\":2450,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"previousSibling\":{\"id\":2449},\"parentNode\":{\"id\":2428}},{\"nodeType\":1,\"id\":2451,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"},\"parentNode\":{\"id\":2429}},{\"nodeType\":1,\"id\":2452,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"previousSibling\":{\"id\":2451},\"parentNode\":{\"id\":2429}},{\"nodeType\":1,\"id\":2453,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"},\"parentNode\":{\"id\":2430}},{\"nodeType\":1,\"id\":2454,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"previousSibling\":{\"id\":2453},\"parentNode\":{\"id\":2430}},{\"nodeType\":1,\"id\":2455,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"},\"parentNode\":{\"id\":2431}},{\"nodeType\":1,\"id\":2456,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"previousSibling\":{\"id\":2455},\"parentNode\":{\"id\":2431}},{\"nodeType\":1,\"id\":2457,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"},\"parentNode\":{\"id\":2432}},{\"nodeType\":1,\"id\":2458,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"previousSibling\":{\"id\":2457},\"parentNode\":{\"id\":2432}},{\"nodeType\":1,\"id\":2459,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"},\"parentNode\":{\"id\":2433}},{\"nodeType\":1,\"id\":2460,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"previousSibling\":{\"id\":2459},\"parentNode\":{\"id\":2433}},{\"nodeType\":3,\"id\":2461,\"textContent\":\"0\",\"parentNode\":{\"id\":2436}},{\"nodeType\":3,\"id\":2462,\"textContent\":\"1\",\"parentNode\":{\"id\":2438}},{\"nodeType\":3,\"id\":2463,\"textContent\":\"2\",\"parentNode\":{\"id\":2440}},{\"nodeType\":3,\"id\":2464,\"textContent\":\"3\",\"parentNode\":{\"id\":2442}},{\"nodeType\":3,\"id\":2465,\"textContent\":\"4\",\"parentNode\":{\"id\":2444}},{\"nodeType\":3,\"id\":2466,\"textContent\":\"5\",\"parentNode\":{\"id\":2446}},{\"nodeType\":3,\"id\":2467,\"textContent\":\"6\",\"parentNode\":{\"id\":2448}},{\"nodeType\":3,\"id\":2468,\"textContent\":\"7\",\"parentNode\":{\"id\":2450}},{\"nodeType\":3,\"id\":2469,\"textContent\":\"8\",\"parentNode\":{\"id\":2452}},{\"nodeType\":3,\"id\":2470,\"textContent\":\"9\",\"parentNode\":{\"id\":2454}},{\"nodeType\":3,\"id\":2471,\"textContent\":\"10\",\"parentNode\":{\"id\":2456}},{\"nodeType\":3,\"id\":2472,\"textContent\":\"11\",\"parentNode\":{\"id\":2458}},{\"nodeType\":3,\"id\":2473,\"textContent\":\"12\",\"parentNode\":{\"id\":2460}},{\"nodeType\":1,\"id\":2474,\"tagName\":\"text\",\"attributes\":{\"transform\":\"rotate(-90)\",\"x\":\"-350\",\"y\":\"-60\",\"style\":\"text-anchor: end;\"},\"parentNode\":{\"id\":2434}},{\"nodeType\":3,\"id\":2475,\"textContent\":\"DURATION (in hours)\",\"parentNode\":{\"id\":2474}},{\"nodeType\":1,\"id\":2476,\"tagName\":\"g\",\"attributes\":{\"class\":\"grid\"},\"parentNode\":{\"id\":2313}},{\"nodeType\":1,\"id\":2477,\"tagName\":\"g\",\"attributes\":{\"class\":\"grid\"},\"previousSibling\":{\"id\":2476},\"parentNode\":{\"id\":2313}},{\"nodeType\":1,\"id\":2478,\"tagName\":\"g\",\"attributes\":{\"class\":\"grid\"},\"previousSibling\":{\"id\":2477},\"parentNode\":{\"id\":2313}},{\"nodeType\":1,\"id\":2479,\"tagName\":\"g\",\"attributes\":{\"class\":\"grid\"},\"previousSibling\":{\"id\":2478},\"parentNode\":{\"id\":2313}},{\"nodeType\":1,\"id\":2480,\"tagName\":\"g\",\"attributes\":{\"class\":\"grid\"},\"previousSibling\":{\"id\":2479},\"parentNode\":{\"id\":2313}},{\"nodeType\":1,\"id\":2481,\"tagName\":\"g\",\"attributes\":{\"class\":\"grid\"},\"previousSibling\":{\"id\":2480},\"parentNode\":{\"id\":2313}},{\"nodeType\":1,\"id\":2482,\"tagName\":\"g\",\"attributes\":{\"class\":\"grid\"},\"previousSibling\":{\"id\":2481},\"parentNode\":{\"id\":2313}},{\"nodeType\":1,\"id\":2483,\"tagName\":\"g\",\"attributes\":{\"class\":\"grid\"},\"previousSibling\":{\"id\":2482},\"parentNode\":{\"id\":2313}},{\"nodeType\":1,\"id\":2484,\"tagName\":\"g\",\"attributes\":{\"class\":\"grid\"},\"previousSibling\":{\"id\":2483},\"parentNode\":{\"id\":2313}},{\"nodeType\":1,\"id\":2485,\"tagName\":\"g\",\"attributes\":{\"class\":\"grid\"},\"previousSibling\":{\"id\":2484},\"parentNode\":{\"id\":2313}},{\"nodeType\":1,\"id\":2486,\"tagName\":\"g\",\"attributes\":{\"class\":\"grid\"},\"previousSibling\":{\"id\":2485},\"parentNode\":{\"id\":2313}},{\"nodeType\":1,\"id\":2487,\"tagName\":\"g\",\"attributes\":{\"class\":\"grid\"},\"previousSibling\":{\"id\":2486},\"parentNode\":{\"id\":2313}},{\"nodeType\":1,\"id\":2488,\"tagName\":\"line\",\"attributes\":{\"x1\":\"13.333333333333329\",\"x2\":\"766.6666666666667\",\"y1\":\"733.3333333333334\",\"y2\":\"733.3333333333334\"},\"parentNode\":{\"id\":2476}},{\"nodeType\":1,\"id\":2489,\"tagName\":\"line\",\"attributes\":{\"x1\":\"46.66666666666666\",\"x2\":\"733.3333333333333\",\"y1\":\"666.6666666666667\",\"y2\":\"666.6666666666667\"},\"parentNode\":{\"id\":2477}},{\"nodeType\":1,\"id\":2490,\"tagName\":\"line\",\"attributes\":{\"x1\":\"80\",\"x2\":\"700\",\"y1\":\"600\",\"y2\":\"600\"},\"parentNode\":{\"id\":2478}},{\"nodeType\":1,\"id\":2491,\"tagName\":\"line\",\"attributes\":{\"x1\":\"113.33333333333331\",\"x2\":\"666.6666666666667\",\"y1\":\"533.3333333333334\",\"y2\":\"533.3333333333334\"},\"parentNode\":{\"id\":2479}},{\"nodeType\":1,\"id\":2492,\"tagName\":\"line\",\"attributes\":{\"x1\":\"146.66666666666669\",\"x2\":\"633.3333333333333\",\"y1\":\"466.66666666666663\",\"y2\":\"466.66666666666663\"},\"parentNode\":{\"id\":2480}},{\"nodeType\":1,\"id\":2493,\"tagName\":\"line\",\"attributes\":{\"x1\":\"180\",\"x2\":\"600\",\"y1\":\"400\",\"y2\":\"400\"},\"parentNode\":{\"id\":2481}},{\"nodeType\":1,\"id\":2494,\"tagName\":\"line\",\"attributes\":{\"x1\":\"213.33333333333334\",\"x2\":\"566.6666666666667\",\"y1\":\"333.3333333333333\",\"y2\":\"333.3333333333333\"},\"parentNode\":{\"id\":2482}},{\"nodeType\":1,\"id\":2495,\"tagName\":\"line\",\"attributes\":{\"x1\":\"246.66666666666663\",\"x2\":\"533.3333333333333\",\"y1\":\"266.66666666666674\",\"y2\":\"266.66666666666674\"},\"parentNode\":{\"id\":2483}},{\"nodeType\":1,\"id\":2496,\"tagName\":\"line\",\"attributes\":{\"x1\":\"280\",\"x2\":\"500\",\"y1\":\"200\",\"y2\":\"200\"},\"parentNode\":{\"id\":2484}},{\"nodeType\":1,\"id\":2497,\"tagName\":\"line\",\"attributes\":{\"x1\":\"313.33333333333337\",\"x2\":\"466.6666666666667\",\"y1\":\"133.33333333333326\",\"y2\":\"133.33333333333326\"},\"parentNode\":{\"id\":2485}},{\"nodeType\":1,\"id\":2498,\"tagName\":\"line\",\"attributes\":{\"x1\":\"346.66666666666663\",\"x2\":\"433.3333333333333\",\"y1\":\"66.66666666666674\",\"y2\":\"66.66666666666674\"},\"parentNode\":{\"id\":2486}},{\"nodeType\":1,\"id\":2499,\"tagName\":\"line\",\"attributes\":{\"x1\":\"380\",\"x2\":\"400\",\"y1\":\"0\",\"y2\":\"0\"},\"parentNode\":{\"id\":2487}},{\"nodeType\":1,\"id\":2500,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"0\",\"y1\":\"800\",\"x2\":\"400\",\"y2\":\"0\"},\"parentNode\":{\"id\":2314}},{\"nodeType\":1,\"id\":2501,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"800\",\"y1\":\"800\",\"x2\":\"400\",\"y2\":\"0\"},\"previousSibling\":{\"id\":2500},\"parentNode\":{\"id\":2314}},{\"nodeType\":1,\"id\":2502,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"66.66666666666666\",\"y1\":\"800\",\"x2\":\"433.3333333333333\",\"y2\":\"66.66666666666674\"},\"previousSibling\":{\"id\":2501},\"parentNode\":{\"id\":2314}},{\"nodeType\":1,\"id\":2503,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"733.3333333333333\",\"y1\":\"800\",\"x2\":\"366.66666666666663\",\"y2\":\"66.66666666666674\"},\"previousSibling\":{\"id\":2502},\"parentNode\":{\"id\":2314}},{\"nodeType\":1,\"id\":2504,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"133.33333333333331\",\"y1\":\"800\",\"x2\":\"466.6666666666667\",\"y2\":\"133.33333333333326\"},\"previousSibling\":{\"id\":2503},\"parentNode\":{\"id\":2314}},{\"nodeType\":1,\"id\":2505,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"666.6666666666667\",\"y1\":\"800\",\"x2\":\"333.33333333333337\",\"y2\":\"133.33333333333326\"},\"previousSibling\":{\"id\":2504},\"parentNode\":{\"id\":2314}},{\"nodeType\":1,\"id\":2506,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"200\",\"y1\":\"800\",\"x2\":\"500\",\"y2\":\"200\"},\"previousSibling\":{\"id\":2505},\"parentNode\":{\"id\":2314}},{\"nodeType\":1,\"id\":2507,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"600\",\"y1\":\"800\",\"x2\":\"300\",\"y2\":\"200\"},\"previousSibling\":{\"id\":2506},\"parentNode\":{\"id\":2314}},{\"nodeType\":1,\"id\":2508,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"266.66666666666663\",\"y1\":\"800\",\"x2\":\"533.3333333333333\",\"y2\":\"266.66666666666674\"},\"previousSibling\":{\"id\":2507},\"parentNode\":{\"id\":2314}},{\"nodeType\":1,\"id\":2509,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"533.3333333333333\",\"y1\":\"800\",\"x2\":\"266.66666666666663\",\"y2\":\"266.66666666666674\"},\"previousSibling\":{\"id\":2508},\"parentNode\":{\"id\":2314}},{\"nodeType\":1,\"id\":2510,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"333.33333333333337\",\"y1\":\"800\",\"x2\":\"566.6666666666667\",\"y2\":\"333.3333333333333\"},\"previousSibling\":{\"id\":2509},\"parentNode\":{\"id\":2314}},{\"nodeType\":1,\"id\":2511,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"466.6666666666667\",\"y1\":\"800\",\"x2\":\"233.33333333333334\",\"y2\":\"333.3333333333333\"},\"previousSibling\":{\"id\":2510},\"parentNode\":{\"id\":2314}},{\"nodeType\":1,\"id\":2512,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"400\",\"y1\":\"800\",\"x2\":\"600\",\"y2\":\"400\"},\"previousSibling\":{\"id\":2511},\"parentNode\":{\"id\":2314}},{\"nodeType\":1,\"id\":2513,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"400\",\"y1\":\"800\",\"x2\":\"200\",\"y2\":\"400\"},\"previousSibling\":{\"id\":2512},\"parentNode\":{\"id\":2314}},{\"nodeType\":1,\"id\":2514,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"466.6666666666667\",\"y1\":\"800\",\"x2\":\"633.3333333333333\",\"y2\":\"466.66666666666663\"},\"previousSibling\":{\"id\":2513},\"parentNode\":{\"id\":2314}},{\"nodeType\":1,\"id\":2515,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"333.33333333333337\",\"y1\":\"800\",\"x2\":\"166.66666666666669\",\"y2\":\"466.66666666666663\"},\"previousSibling\":{\"id\":2514},\"parentNode\":{\"id\":2314}},{\"nodeType\":1,\"id\":2516,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"533.3333333333333\",\"y1\":\"800\",\"x2\":\"666.6666666666667\",\"y2\":\"533.3333333333334\"},\"previousSibling\":{\"id\":2515},\"parentNode\":{\"id\":2314}},{\"nodeType\":1,\"id\":2517,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"266.66666666666663\",\"y1\":\"800\",\"x2\":\"133.33333333333331\",\"y2\":\"533.3333333333334\"},\"previousSibling\":{\"id\":2516},\"parentNode\":{\"id\":2314}},{\"nodeType\":1,\"id\":2518,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"600\",\"y1\":\"800\",\"x2\":\"700\",\"y2\":\"600\"},\"previousSibling\":{\"id\":2517},\"parentNode\":{\"id\":2314}},{\"nodeType\":1,\"id\":2519,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"200\",\"y1\":\"800\",\"x2\":\"100\",\"y2\":\"600\"},\"previousSibling\":{\"id\":2518},\"parentNode\":{\"id\":2314}},{\"nodeType\":1,\"id\":2520,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"666.6666666666667\",\"y1\":\"800\",\"x2\":\"733.3333333333333\",\"y2\":\"666.6666666666667\"},\"previousSibling\":{\"id\":2519},\"parentNode\":{\"id\":2314}},{\"nodeType\":1,\"id\":2521,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"133.33333333333331\",\"y1\":\"800\",\"x2\":\"66.66666666666666\",\"y2\":\"666.6666666666667\"},\"previousSibling\":{\"id\":2520},\"parentNode\":{\"id\":2314}},{\"nodeType\":1,\"id\":2522,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"733.3333333333333\",\"y1\":\"800\",\"x2\":\"766.6666666666667\",\"y2\":\"733.3333333333334\"},\"previousSibling\":{\"id\":2521},\"parentNode\":{\"id\":2314}},{\"nodeType\":1,\"id\":2523,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"66.66666666666666\",\"y1\":\"800\",\"x2\":\"33.33333333333333\",\"y2\":\"733.3333333333334\"},\"previousSibling\":{\"id\":2522},\"parentNode\":{\"id\":2314}},{\"nodeType\":1,\"id\":2524,\"tagName\":\"g\",\"attributes\":{},\"parentNode\":{\"id\":2315}},{\"nodeType\":1,\"id\":2525,\"tagName\":\"g\",\"attributes\":{},\"previousSibling\":{\"id\":2524},\"parentNode\":{\"id\":2315}},{\"nodeType\":1,\"id\":2526,\"tagName\":\"g\",\"attributes\":{},\"previousSibling\":{\"id\":2525},\"parentNode\":{\"id\":2315}},{\"nodeType\":1,\"id\":2527,\"tagName\":\"g\",\"attributes\":{},\"previousSibling\":{\"id\":2526},\"parentNode\":{\"id\":2315}},{\"nodeType\":1,\"id\":2528,\"tagName\":\"g\",\"attributes\":{},\"previousSibling\":{\"id\":2527},\"parentNode\":{\"id\":2315}},{\"nodeType\":1,\"id\":2529,\"tagName\":\"g\",\"attributes\":{},\"previousSibling\":{\"id\":2528},\"parentNode\":{\"id\":2315}},{\"nodeType\":1,\"id\":2530,\"tagName\":\"g\",\"attributes\":{},\"previousSibling\":{\"id\":2529},\"parentNode\":{\"id\":2315}},{\"nodeType\":1,\"id\":2531,\"tagName\":\"g\",\"attributes\":{},\"previousSibling\":{\"id\":2530},\"parentNode\":{\"id\":2315}},{\"nodeType\":1,\"id\":2532,\"tagName\":\"g\",\"attributes\":{},\"previousSibling\":{\"id\":2531},\"parentNode\":{\"id\":2315}},{\"nodeType\":1,\"id\":2533,\"tagName\":\"g\",\"attributes\":{},\"previousSibling\":{\"id\":2532},\"parentNode\":{\"id\":2315}},{\"nodeType\":1,\"id\":2534,\"tagName\":\"g\",\"attributes\":{},\"previousSibling\":{\"id\":2533},\"parentNode\":{\"id\":2315}},{\"nodeType\":1,\"id\":2535,\"tagName\":\"g\",\"attributes\":{},\"previousSibling\":{\"id\":2534},\"parentNode\":{\"id\":2315}},{\"nodeType\":1,\"id\":2536,\"tagName\":\"g\",\"attributes\":{},\"previousSibling\":{\"id\":2535},\"parentNode\":{\"id\":2315}},{\"nodeType\":1,\"id\":2537,\"tagName\":\"g\",\"attributes\":{},\"previousSibling\":{\"id\":2536},\"parentNode\":{\"id\":2315}},{\"nodeType\":1,\"id\":2538,\"tagName\":\"g\",\"attributes\":{},\"previousSibling\":{\"id\":2537},\"parentNode\":{\"id\":2315}},{\"nodeType\":1,\"id\":2539,\"tagName\":\"g\",\"attributes\":{},\"previousSibling\":{\"id\":2538},\"parentNode\":{\"id\":2315}},{\"nodeType\":1,\"id\":2540,\"tagName\":\"g\",\"attributes\":{},\"previousSibling\":{\"id\":2539},\"parentNode\":{\"id\":2315}},{\"nodeType\":1,\"id\":2541,\"tagName\":\"g\",\"attributes\":{},\"previousSibling\":{\"id\":2540},\"parentNode\":{\"id\":2315}},{\"nodeType\":1,\"id\":2542,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"333.33333333333337\",\"cy\":\"266.66666666666674\",\"r\":\"6\",\"selected\":\"false\"},\"parentNode\":{\"id\":2524}},{\"nodeType\":1,\"id\":2543,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"328.33333333333337\",\"y\":\"258.66666666666674\"},\"previousSibling\":{\"id\":2542},\"parentNode\":{\"id\":2524}},{\"nodeType\":1,\"id\":2544,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"266.66666666666663\",\"cy\":\"600\",\"r\":\"6\",\"selected\":\"false\"},\"parentNode\":{\"id\":2525}},{\"nodeType\":1,\"id\":2545,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"261.66666666666663\",\"y\":\"592\"},\"previousSibling\":{\"id\":2544},\"parentNode\":{\"id\":2525}},{\"nodeType\":1,\"id\":2546,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"366.66666666666663\",\"cy\":\"466.66666666666663\",\"r\":\"6\",\"selected\":\"false\"},\"parentNode\":{\"id\":2526}},{\"nodeType\":1,\"id\":2547,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"361.66666666666663\",\"y\":\"458.66666666666663\"},\"previousSibling\":{\"id\":2546},\"parentNode\":{\"id\":2526}},{\"nodeType\":1,\"id\":2548,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"666.6666666666667\",\"cy\":\"666.6666666666667\",\"r\":\"6\",\"selected\":\"false\"},\"parentNode\":{\"id\":2527}},{\"nodeType\":1,\"id\":2549,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"661.6666666666667\",\"y\":\"658.6666666666667\"},\"previousSibling\":{\"id\":2548},\"parentNode\":{\"id\":2527}},{\"nodeType\":1,\"id\":2550,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"200\",\"cy\":\"400\",\"r\":\"6\",\"selected\":\"false\"},\"parentNode\":{\"id\":2528}},{\"nodeType\":1,\"id\":2551,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"195\",\"y\":\"392\"},\"previousSibling\":{\"id\":2550},\"parentNode\":{\"id\":2528}},{\"nodeType\":1,\"id\":2552,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"266.66666666666663\",\"cy\":\"533.3333333333334\",\"r\":\"6\",\"selected\":\"false\"},\"parentNode\":{\"id\":2529}},{\"nodeType\":1,\"id\":2553,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"261.66666666666663\",\"y\":\"525.3333333333334\"},\"previousSibling\":{\"id\":2552},\"parentNode\":{\"id\":2529}},{\"nodeType\":1,\"id\":2554,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"333.33333333333337\",\"cy\":\"400\",\"r\":\"6\",\"selected\":\"false\"},\"parentNode\":{\"id\":2530}},{\"nodeType\":1,\"id\":2555,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"328.33333333333337\",\"y\":\"392\"},\"previousSibling\":{\"id\":2554},\"parentNode\":{\"id\":2530}},{\"nodeType\":1,\"id\":2556,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"500\",\"cy\":\"466.66666666666663\",\"r\":\"6\",\"selected\":\"false\"},\"parentNode\":{\"id\":2531}},{\"nodeType\":1,\"id\":2557,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"495\",\"y\":\"458.66666666666663\"},\"previousSibling\":{\"id\":2556},\"parentNode\":{\"id\":2531}},{\"nodeType\":1,\"id\":2558,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"100\",\"cy\":\"600\",\"r\":\"6\",\"selected\":\"false\"},\"parentNode\":{\"id\":2532}},{\"nodeType\":1,\"id\":2559,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"95\",\"y\":\"592\"},\"previousSibling\":{\"id\":2558},\"parentNode\":{\"id\":2532}},{\"nodeType\":1,\"id\":2560,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"133.33333333333331\",\"cy\":\"666.6666666666667\",\"r\":\"6\",\"selected\":\"false\"},\"parentNode\":{\"id\":2533}},{\"nodeType\":1,\"id\":2561,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"128.33333333333331\",\"y\":\"658.6666666666667\"},\"previousSibling\":{\"id\":2560},\"parentNode\":{\"id\":2533}},{\"nodeType\":1,\"id\":2562,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"400\",\"cy\":\"133.33333333333326\",\"r\":\"6\",\"selected\":\"false\"},\"parentNode\":{\"id\":2534}},{\"nodeType\":1,\"id\":2563,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"395\",\"y\":\"125.33333333333326\"},\"previousSibling\":{\"id\":2562},\"parentNode\":{\"id\":2534}},{\"nodeType\":1,\"id\":2564,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"500\",\"cy\":\"333.3333333333333\",\"r\":\"6\",\"selected\":\"false\"},\"parentNode\":{\"id\":2535}},{\"nodeType\":1,\"id\":2565,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"495\",\"y\":\"325.3333333333333\"},\"previousSibling\":{\"id\":2564},\"parentNode\":{\"id\":2535}},{\"nodeType\":1,\"id\":2566,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"300\",\"cy\":\"733.3333333333334\",\"r\":\"6\",\"selected\":\"false\"},\"parentNode\":{\"id\":2536}},{\"nodeType\":1,\"id\":2567,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"295\",\"y\":\"725.3333333333334\"},\"previousSibling\":{\"id\":2566},\"parentNode\":{\"id\":2536}},{\"nodeType\":1,\"id\":2568,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"600\",\"cy\":\"666.6666666666667\",\"r\":\"6\",\"selected\":\"false\"},\"parentNode\":{\"id\":2537}},{\"nodeType\":1,\"id\":2569,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"595\",\"y\":\"658.6666666666667\"},\"previousSibling\":{\"id\":2568},\"parentNode\":{\"id\":2537}},{\"nodeType\":1,\"id\":2570,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"433.3333333333333\",\"cy\":\"600\",\"r\":\"6\",\"selected\":\"false\"},\"parentNode\":{\"id\":2538}},{\"nodeType\":1,\"id\":2571,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"428.3333333333333\",\"y\":\"592\"},\"previousSibling\":{\"id\":2570},\"parentNode\":{\"id\":2538}},{\"nodeType\":1,\"id\":2572,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"500\",\"cy\":\"200\",\"r\":\"6\",\"selected\":\"false\"},\"parentNode\":{\"id\":2539}},{\"nodeType\":1,\"id\":2573,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"495\",\"y\":\"192\"},\"previousSibling\":{\"id\":2572},\"parentNode\":{\"id\":2539}},{\"nodeType\":1,\"id\":2574,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"533.3333333333333\",\"cy\":\"533.3333333333334\",\"r\":\"6\",\"selected\":\"false\"},\"parentNode\":{\"id\":2540}},{\"nodeType\":1,\"id\":2575,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"528.3333333333333\",\"y\":\"525.3333333333334\"},\"previousSibling\":{\"id\":2574},\"parentNode\":{\"id\":2540}},{\"nodeType\":1,\"id\":2576,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"400\",\"cy\":\"666.6666666666667\",\"r\":\"6\",\"selected\":\"false\"},\"parentNode\":{\"id\":2541}},{\"nodeType\":1,\"id\":2577,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"395\",\"y\":\"658.6666666666667\"},\"previousSibling\":{\"id\":2576},\"parentNode\":{\"id\":2541}},{\"nodeType\":3,\"id\":2578,\"textContent\":\"A \",\"parentNode\":{\"id\":2543}},{\"nodeType\":3,\"id\":2579,\"textContent\":\"B \",\"parentNode\":{\"id\":2545}},{\"nodeType\":3,\"id\":2580,\"textContent\":\"C \",\"parentNode\":{\"id\":2547}},{\"nodeType\":3,\"id\":2581,\"textContent\":\"D \",\"parentNode\":{\"id\":2549}},{\"nodeType\":3,\"id\":2582,\"textContent\":\"E \",\"parentNode\":{\"id\":2551}},{\"nodeType\":3,\"id\":2583,\"textContent\":\"F \",\"parentNode\":{\"id\":2553}},{\"nodeType\":3,\"id\":2584,\"textContent\":\"G \",\"parentNode\":{\"id\":2555}},{\"nodeType\":3,\"id\":2585,\"textContent\":\"H \",\"parentNode\":{\"id\":2557}},{\"nodeType\":3,\"id\":2586,\"textContent\":\"I \",\"parentNode\":{\"id\":2559}},{\"nodeType\":3,\"id\":2587,\"textContent\":\"J \",\"parentNode\":{\"id\":2561}},{\"nodeType\":3,\"id\":2588,\"textContent\":\"K \",\"parentNode\":{\"id\":2563}},{\"nodeType\":3,\"id\":2589,\"textContent\":\"L \",\"parentNode\":{\"id\":2565}},{\"nodeType\":3,\"id\":2590,\"textContent\":\"M \",\"parentNode\":{\"id\":2567}},{\"nodeType\":3,\"id\":2591,\"textContent\":\"N \",\"parentNode\":{\"id\":2569}},{\"nodeType\":3,\"id\":2592,\"textContent\":\"O \",\"parentNode\":{\"id\":2571}},{\"nodeType\":3,\"id\":2593,\"textContent\":\"P \",\"parentNode\":{\"id\":2573}},{\"nodeType\":3,\"id\":2594,\"textContent\":\"Z \",\"parentNode\":{\"id\":2575}},{\"nodeType\":3,\"id\":2595,\"textContent\":\"X \",\"parentNode\":{\"id\":2577}}],[],[]]}"
    },
    {
      "sequence": 2,
      "data": "{\"f\":\"applyChanged\",\"args\":[[{\"id\":56},{\"id\":57},{\"id\":58},{\"id\":59},{\"id\":60},{\"id\":61},{\"id\":62},{\"id\":63},{\"id\":64},{\"id\":65},{\"id\":66},{\"id\":67},{\"id\":68},{\"id\":69},{\"id\":70},{\"id\":71},{\"id\":72},{\"id\":73},{\"id\":74},{\"id\":75},{\"id\":76},{\"id\":77},{\"id\":78},{\"id\":79},{\"id\":80},{\"id\":81},{\"id\":82},{\"id\":83},{\"id\":84},{\"id\":85},{\"id\":86},{\"id\":87},{\"id\":88},{\"id\":89},{\"id\":90},{\"id\":91},{\"id\":92},{\"id\":93},{\"id\":94},{\"id\":95},{\"id\":96},{\"id\":97},{\"id\":98},{\"id\":99},{\"id\":100},{\"id\":101},{\"id\":102},{\"id\":103},{\"id\":104},{\"id\":105},{\"id\":106},{\"id\":107},{\"id\":108},{\"id\":109},{\"id\":110},{\"id\":111},{\"id\":112},{\"id\":113},{\"id\":114},{\"id\":115},{\"id\":116},{\"id\":117},{\"id\":118},{\"id\":119},{\"id\":120},{\"id\":121},{\"id\":122},{\"id\":123},{\"id\":124},{\"id\":125},{\"id\":126},{\"id\":127},{\"id\":128},{\"id\":129},{\"id\":130},{\"id\":131},{\"id\":132},{\"id\":133},{\"id\":134},{\"id\":135},{\"id\":136},{\"id\":137},{\"id\":138},{\"id\":139},{\"id\":140},{\"id\":141},{\"id\":142},{\"id\":143},{\"id\":144},{\"id\":145},{\"id\":146},{\"id\":147},{\"id\":148},{\"id\":149},{\"id\":150},{\"id\":151},{\"id\":152},{\"id\":153},{\"id\":154},{\"id\":155},{\"id\":156},{\"id\":157},{\"id\":158},{\"id\":159},{\"id\":160},{\"id\":161},{\"id\":162},{\"id\":163},{\"id\":164},{\"id\":165},{\"id\":166},{\"id\":167},{\"id\":168},{\"id\":169},{\"id\":170},{\"id\":171},{\"id\":172},{\"id\":173},{\"id\":174},{\"id\":175},{\"id\":176},{\"id\":177},{\"id\":178},{\"id\":179},{\"id\":180},{\"id\":181},{\"id\":182},{\"id\":183},{\"id\":184},{\"id\":185},{\"id\":186},{\"id\":187},{\"id\":188},{\"id\":189},{\"id\":190},{\"id\":191},{\"id\":192},{\"id\":193},{\"id\":194},{\"id\":195},{\"id\":196},{\"id\":197},{\"id\":198},{\"id\":199},{\"id\":200},{\"id\":201},{\"id\":202},{\"id\":203},{\"id\":204},{\"id\":205},{\"id\":206},{\"id\":207},{\"id\":208},{\"id\":209},{\"id\":210},{\"id\":211},{\"id\":212},{\"id\":213},{\"id\":214},{\"id\":215},{\"id\":216},{\"id\":217},{\"id\":218},{\"id\":219},{\"id\":220},{\"id\":221},{\"id\":222},{\"id\":223},{\"id\":224},{\"id\":225},{\"id\":226},{\"id\":227},{\"id\":228},{\"id\":229},{\"id\":230},{\"id\":231},{\"id\":232},{\"id\":233},{\"id\":234},{\"id\":235},{\"id\":236},{\"id\":237},{\"id\":238},{\"id\":239},{\"id\":240},{\"id\":241},{\"id\":242},{\"id\":243},{\"id\":244},{\"id\":245},{\"id\":246},{\"id\":247},{\"id\":248},{\"id\":249},{\"id\":250},{\"id\":251},{\"id\":252},{\"id\":253},{\"id\":254},{\"id\":255},{\"id\":256},{\"id\":257},{\"id\":258},{\"id\":259},{\"id\":260},{\"id\":261},{\"id\":262},{\"id\":263},{\"id\":264},{\"id\":265},{\"id\":266},{\"id\":267},{\"id\":268},{\"id\":269},{\"id\":270},{\"id\":271},{\"id\":272},{\"id\":273},{\"id\":274},{\"id\":275},{\"id\":276},{\"id\":277},{\"id\":278},{\"id\":279},{\"id\":280},{\"id\":281},{\"id\":282},{\"id\":283},{\"id\":284},{\"id\":285},{\"id\":286},{\"id\":287},{\"id\":288},{\"id\":289},{\"id\":290},{\"id\":291},{\"id\":292},{\"id\":293},{\"id\":294},{\"id\":295},{\"id\":296},{\"id\":297},{\"id\":298},{\"id\":299},{\"id\":300},{\"id\":301},{\"id\":302},{\"id\":303},{\"id\":304},{\"id\":305},{\"id\":306},{\"id\":307},{\"id\":308},{\"id\":309},{\"id\":310},{\"id\":311},{\"id\":312},{\"id\":313},{\"id\":314},{\"id\":315},{\"id\":316},{\"id\":317},{\"id\":318},{\"id\":319},{\"id\":320},{\"id\":321},{\"id\":322},{\"id\":323},{\"id\":324},{\"id\":325},{\"id\":326},{\"id\":327},{\"id\":328},{\"id\":329},{\"id\":330},{\"id\":331},{\"id\":332},{\"id\":333},{\"id\":334},{\"id\":335},{\"id\":336},{\"id\":337},{\"id\":338},{\"id\":339},{\"id\":340},{\"id\":341},{\"id\":342},{\"id\":343},{\"id\":344},{\"id\":345},{\"id\":346},{\"id\":347},{\"id\":348},{\"id\":349},{\"id\":350},{\"id\":351},{\"id\":352},{\"id\":353},{\"id\":354},{\"id\":355},{\"id\":356},{\"id\":357},{\"id\":358},{\"id\":359},{\"id\":360},{\"id\":361},{\"id\":362},{\"id\":363},{\"id\":364},{\"id\":365},{\"id\":366},{\"id\":367},{\"id\":368},{\"id\":369},{\"id\":370},{\"id\":371},{\"id\":372},{\"id\":373},{\"id\":374},{\"id\":375},{\"id\":376},{\"id\":377},{\"id\":378},{\"id\":379},{\"id\":380},{\"id\":381},{\"id\":382},{\"id\":383},{\"id\":384},{\"id\":385},{\"id\":386},{\"id\":387},{\"id\":388},{\"id\":389},{\"id\":390},{\"id\":391},{\"id\":392},{\"id\":393},{\"id\":394},{\"id\":395},{\"id\":396},{\"id\":397},{\"id\":398},{\"id\":399},{\"id\":400},{\"id\":401},{\"id\":402},{\"id\":403},{\"id\":404},{\"id\":405},{\"id\":406},{\"id\":407},{\"id\":408},{\"id\":409},{\"id\":410},{\"id\":411},{\"id\":412},{\"id\":413},{\"id\":414},{\"id\":415},{\"id\":416},{\"id\":417},{\"id\":418},{\"id\":419},{\"id\":420},{\"id\":421},{\"id\":422},{\"id\":423},{\"id\":424},{\"id\":425},{\"id\":426},{\"id\":427},{\"id\":428},{\"id\":429},{\"id\":430},{\"id\":431},{\"id\":432},{\"id\":433},{\"id\":434},{\"id\":435},{\"id\":436},{\"id\":437},{\"id\":438},{\"id\":439},{\"id\":440},{\"id\":441},{\"id\":442},{\"id\":443},{\"id\":444},{\"id\":445},{\"id\":446},{\"id\":447},{\"id\":448},{\"id\":449},{\"id\":450},{\"id\":451},{\"id\":452},{\"id\":453},{\"id\":454},{\"id\":455},{\"id\":456},{\"id\":457},{\"id\":458},{\"id\":459},{\"id\":460},{\"id\":461},{\"id\":462},{\"id\":463},{\"id\":464},{\"id\":465},{\"id\":466},{\"id\":467},{\"id\":468},{\"id\":469},{\"id\":470},{\"id\":471},{\"id\":472},{\"id\":473},{\"id\":474},{\"id\":475},{\"id\":476},{\"id\":477},{\"id\":478},{\"id\":479},{\"id\":480},{\"id\":481},{\"id\":482},{\"id\":483},{\"id\":484},{\"id\":485},{\"id\":486},{\"id\":487},{\"id\":488},{\"id\":489},{\"id\":490},{\"id\":491},{\"id\":492},{\"id\":493},{\"id\":494},{\"id\":495},{\"id\":496},{\"id\":497},{\"id\":498},{\"id\":499},{\"id\":500},{\"id\":501},{\"id\":502},{\"id\":503},{\"id\":504},{\"id\":505},{\"id\":506},{\"id\":507},{\"id\":508},{\"id\":509},{\"id\":510},{\"id\":511},{\"id\":512},{\"id\":513},{\"id\":514},{\"id\":515},{\"id\":516},{\"id\":517},{\"id\":518},{\"id\":519},{\"id\":520},{\"id\":521},{\"id\":522},{\"id\":523},{\"id\":524},{\"id\":525},{\"id\":526},{\"id\":527},{\"id\":528},{\"id\":529},{\"id\":530},{\"id\":531},{\"id\":532},{\"id\":533},{\"id\":534},{\"id\":535},{\"id\":536},{\"id\":537},{\"id\":538},{\"id\":539},{\"id\":540},{\"id\":541},{\"id\":542},{\"id\":543},{\"id\":544},{\"id\":545},{\"id\":546},{\"id\":547},{\"id\":548},{\"id\":549},{\"id\":550},{\"id\":551},{\"id\":552},{\"id\":553},{\"id\":554},{\"id\":555},{\"id\":556},{\"id\":557},{\"id\":558},{\"id\":559},{\"id\":560},{\"id\":561},{\"id\":562},{\"id\":563},{\"id\":564},{\"id\":565},{\"id\":566},{\"id\":567},{\"id\":568},{\"id\":569},{\"id\":570},{\"id\":571},{\"id\":572},{\"id\":573},{\"id\":574},{\"id\":575},{\"id\":576},{\"id\":577},{\"id\":578},{\"id\":579},{\"id\":580},{\"id\":581},{\"id\":582},{\"id\":583},{\"id\":584},{\"id\":585},{\"id\":586},{\"id\":587},{\"id\":588},{\"id\":589},{\"id\":590},{\"id\":591},{\"id\":592},{\"id\":593},{\"id\":594},{\"id\":595},{\"id\":596},{\"id\":597},{\"id\":598},{\"id\":599},{\"id\":600},{\"id\":601},{\"id\":602},{\"id\":603},{\"id\":604},{\"id\":605},{\"id\":606},{\"id\":607},{\"id\":608},{\"id\":609},{\"id\":610},{\"id\":611},{\"id\":612},{\"id\":613},{\"id\":614},{\"id\":615},{\"id\":616},{\"id\":617},{\"id\":618},{\"id\":619},{\"id\":620},{\"id\":621},{\"id\":622},{\"id\":623},{\"id\":624},{\"id\":625},{\"id\":626},{\"id\":627},{\"id\":628},{\"id\":629},{\"id\":630},{\"id\":631},{\"id\":632},{\"id\":633},{\"id\":634},{\"id\":635},{\"id\":636},{\"id\":637},{\"id\":638},{\"id\":639},{\"id\":640},{\"id\":641},{\"id\":642},{\"id\":643},{\"id\":644},{\"id\":645},{\"id\":646},{\"id\":647},{\"id\":648},{\"id\":649},{\"id\":650},{\"id\":651},{\"id\":652},{\"id\":653},{\"id\":654},{\"id\":655},{\"id\":656},{\"id\":657},{\"id\":658},{\"id\":659},{\"id\":660},{\"id\":661},{\"id\":662},{\"id\":663},{\"id\":664},{\"id\":665},{\"id\":666},{\"id\":667},{\"id\":668},{\"id\":669},{\"id\":670},{\"id\":671},{\"id\":672},{\"id\":673},{\"id\":674},{\"id\":675},{\"id\":676},{\"id\":677},{\"id\":678},{\"id\":679},{\"id\":680},{\"id\":681},{\"id\":682},{\"id\":683},{\"id\":684},{\"id\":685},{\"id\":686},{\"id\":687},{\"id\":688},{\"id\":689},{\"id\":690},{\"id\":691},{\"id\":692},{\"id\":693},{\"id\":694},{\"id\":695},{\"id\":696},{\"id\":697},{\"id\":698},{\"id\":699},{\"id\":700},{\"id\":701},{\"id\":702},{\"id\":703},{\"id\":704},{\"id\":705},{\"id\":706},{\"id\":707},{\"id\":708},{\"id\":709},{\"id\":710},{\"id\":711},{\"id\":712},{\"id\":713},{\"id\":714},{\"id\":715},{\"id\":716},{\"id\":717},{\"id\":718},{\"id\":719},{\"id\":720},{\"id\":721},{\"id\":722},{\"id\":723},{\"id\":724},{\"id\":725},{\"id\":726},{\"id\":727},{\"id\":728},{\"id\":729},{\"id\":730},{\"id\":731},{\"id\":732},{\"id\":733},{\"id\":734},{\"id\":735},{\"id\":736},{\"id\":737},{\"id\":738},{\"id\":739},{\"id\":740},{\"id\":741},{\"id\":742},{\"id\":743},{\"id\":744},{\"id\":745},{\"id\":746},{\"id\":747},{\"id\":748},{\"id\":749},{\"id\":750},{\"id\":751},{\"id\":752},{\"id\":753},{\"id\":754},{\"id\":755},{\"id\":756},{\"id\":757},{\"id\":758},{\"id\":759},{\"id\":760},{\"id\":761},{\"id\":762},{\"id\":763},{\"id\":764},{\"id\":765},{\"id\":766},{\"id\":767},{\"id\":768},{\"id\":769},{\"id\":770},{\"id\":771},{\"id\":772},{\"id\":773},{\"id\":774},{\"id\":775},{\"id\":776},{\"id\":777},{\"id\":778},{\"id\":779},{\"id\":780},{\"id\":781},{\"id\":782},{\"id\":783},{\"id\":784},{\"id\":785},{\"id\":786},{\"id\":787},{\"id\":788},{\"id\":789},{\"id\":790},{\"id\":791},{\"id\":792},{\"id\":793},{\"id\":794},{\"id\":795},{\"id\":796},{\"id\":797},{\"id\":798},{\"id\":799},{\"id\":800},{\"id\":801},{\"id\":802},{\"id\":803},{\"id\":804},{\"id\":805},{\"id\":806},{\"id\":807},{\"id\":808},{\"id\":809},{\"id\":810},{\"id\":811},{\"id\":812},{\"id\":813},{\"id\":814},{\"id\":815},{\"id\":816},{\"id\":817},{\"id\":818},{\"id\":819},{\"id\":820},{\"id\":821},{\"id\":822},{\"id\":823},{\"id\":824},{\"id\":825},{\"id\":826},{\"id\":827},{\"id\":828},{\"id\":829},{\"id\":830},{\"id\":831},{\"id\":832},{\"id\":833},{\"id\":834},{\"id\":835},{\"id\":836},{\"id\":837},{\"id\":838},{\"id\":839},{\"id\":840},{\"id\":841},{\"id\":842},{\"id\":843},{\"id\":844},{\"id\":845},{\"id\":846},{\"id\":847},{\"id\":848},{\"id\":849},{\"id\":850},{\"id\":851},{\"id\":852},{\"id\":853},{\"id\":854},{\"id\":855},{\"id\":856},{\"id\":857},{\"id\":858},{\"id\":859},{\"id\":860},{\"id\":861},{\"id\":862},{\"id\":863},{\"id\":864},{\"id\":865},{\"id\":866},{\"id\":867},{\"id\":868},{\"id\":869},{\"id\":870},{\"id\":871},{\"id\":872},{\"id\":873},{\"id\":874},{\"id\":875},{\"id\":876},{\"id\":877},{\"id\":878},{\"id\":879},{\"id\":880},{\"id\":881},{\"id\":882},{\"id\":883},{\"id\":884},{\"id\":885},{\"id\":886},{\"id\":887},{\"id\":888},{\"id\":889},{\"id\":890},{\"id\":891},{\"id\":892},{\"id\":893},{\"id\":894},{\"id\":895},{\"id\":896},{\"id\":897},{\"id\":898},{\"id\":899},{\"id\":900},{\"id\":901},{\"id\":902},{\"id\":903},{\"id\":904},{\"id\":905},{\"id\":906},{\"id\":907},{\"id\":908},{\"id\":909},{\"id\":910},{\"id\":911},{\"id\":912},{\"id\":913},{\"id\":914},{\"id\":915},{\"id\":916},{\"id\":917},{\"id\":918},{\"id\":919},{\"id\":920},{\"id\":921},{\"id\":922},{\"id\":923},{\"id\":924},{\"id\":925},{\"id\":926},{\"id\":927},{\"id\":928},{\"id\":929},{\"id\":930},{\"id\":931},{\"id\":932},{\"id\":933},{\"id\":934},{\"id\":935},{\"id\":936},{\"id\":937},{\"id\":938},{\"id\":939},{\"id\":940},{\"id\":941},{\"id\":942},{\"id\":943},{\"id\":944},{\"id\":945},{\"id\":946},{\"id\":947},{\"id\":948},{\"id\":949},{\"id\":950},{\"id\":951},{\"id\":952},{\"id\":953},{\"id\":954},{\"id\":955},{\"id\":956},{\"id\":957},{\"id\":958},{\"id\":959},{\"id\":960},{\"id\":961},{\"id\":962},{\"id\":963},{\"id\":964},{\"id\":965},{\"id\":966},{\"id\":967},{\"id\":968},{\"id\":969},{\"id\":970},{\"id\":971},{\"id\":972},{\"id\":973},{\"id\":974},{\"id\":975},{\"id\":976},{\"id\":977},{\"id\":978},{\"id\":979},{\"id\":980},{\"id\":981},{\"id\":982},{\"id\":983},{\"id\":984},{\"id\":985},{\"id\":986},{\"id\":987},{\"id\":988},{\"id\":989},{\"id\":990},{\"id\":991},{\"id\":992},{\"id\":993},{\"id\":994},{\"id\":995},{\"id\":996},{\"id\":997},{\"id\":998},{\"id\":999},{\"id\":1000},{\"id\":1001},{\"id\":1002},{\"id\":1003},{\"id\":1004},{\"id\":1005},{\"id\":1006},{\"id\":1007},{\"id\":1008},{\"id\":1009},{\"id\":1010},{\"id\":1011},{\"id\":1012},{\"id\":1013},{\"id\":1014},{\"id\":1015},{\"id\":1016},{\"id\":1017},{\"id\":1018},{\"id\":1019},{\"id\":1020},{\"id\":1021},{\"id\":1022},{\"id\":1023},{\"id\":1024},{\"id\":1025},{\"id\":1026},{\"id\":1027},{\"id\":1028},{\"id\":1029},{\"id\":1030},{\"id\":1031},{\"id\":1032},{\"id\":1033},{\"id\":1034},{\"id\":1035},{\"id\":1036},{\"id\":1037},{\"id\":1038},{\"id\":1039},{\"id\":1040},{\"id\":1041},{\"id\":1042},{\"id\":1043},{\"id\":1044},{\"id\":1045},{\"id\":1046},{\"id\":1047},{\"id\":1048},{\"id\":1049},{\"id\":1050},{\"id\":1051},{\"id\":1052},{\"id\":1053},{\"id\":1054},{\"id\":1055},{\"id\":1056},{\"id\":1057},{\"id\":1058},{\"id\":1059},{\"id\":1060},{\"id\":1061},{\"id\":1062},{\"id\":1063},{\"id\":1064},{\"id\":1065},{\"id\":1066},{\"id\":1067},{\"id\":1068},{\"id\":1069},{\"id\":1070},{\"id\":1071},{\"id\":1072},{\"id\":1073},{\"id\":1074},{\"id\":1075},{\"id\":1076},{\"id\":1077},{\"id\":1078},{\"id\":1079},{\"id\":1080},{\"id\":1081},{\"id\":1082},{\"id\":1083},{\"id\":1084},{\"id\":1085},{\"id\":1086},{\"id\":1087},{\"id\":1088},{\"id\":1089},{\"id\":1090},{\"id\":1091},{\"id\":1092},{\"id\":1093},{\"id\":1094},{\"id\":1095},{\"id\":1096},{\"id\":1097},{\"id\":1098},{\"id\":1099},{\"id\":1100},{\"id\":1101},{\"id\":1102},{\"id\":1103},{\"id\":1104},{\"id\":1105},{\"id\":1106},{\"id\":1107},{\"id\":1108},{\"id\":1109},{\"id\":1110},{\"id\":1111},{\"id\":1112},{\"id\":1113},{\"id\":1114},{\"id\":1115},{\"id\":1116},{\"id\":1117},{\"id\":1118},{\"id\":1119},{\"id\":1120},{\"id\":1121},{\"id\":1122},{\"id\":1123},{\"id\":1124},{\"id\":1125},{\"id\":1126},{\"id\":1127},{\"id\":1128},{\"id\":1129},{\"id\":1130},{\"id\":1131},{\"id\":1132},{\"id\":1133},{\"id\":1134},{\"id\":1135},{\"id\":1136},{\"id\":1137},{\"id\":1138},{\"id\":1139},{\"id\":1140},{\"id\":1141},{\"id\":1142},{\"id\":1143},{\"id\":1144},{\"id\":1145},{\"id\":1146},{\"id\":1147},{\"id\":1148},{\"id\":1149},{\"id\":1150},{\"id\":1151},{\"id\":1152},{\"id\":1153},{\"id\":1154},{\"id\":1155},{\"id\":1156},{\"id\":1157},{\"id\":1158},{\"id\":1159},{\"id\":1160},{\"id\":1161},{\"id\":1162},{\"id\":1163},{\"id\":1164},{\"id\":1165},{\"id\":1166},{\"id\":1167},{\"id\":1168},{\"id\":1169},{\"id\":1170},{\"id\":1171},{\"id\":1172},{\"id\":1173},{\"id\":1174},{\"id\":1175},{\"id\":1176},{\"id\":1177},{\"id\":1178},{\"id\":1179},{\"id\":1180},{\"id\":1181},{\"id\":1182},{\"id\":1183},{\"id\":1184},{\"id\":1185},{\"id\":1186},{\"id\":1187},{\"id\":1188},{\"id\":1189},{\"id\":1190},{\"id\":1191},{\"id\":1192},{\"id\":1193},{\"id\":1194},{\"id\":1195},{\"id\":1196},{\"id\":1197},{\"id\":1198},{\"id\":1199},{\"id\":1200},{\"id\":1201},{\"id\":1202},{\"id\":1203},{\"id\":1204},{\"id\":1205},{\"id\":1206},{\"id\":1207},{\"id\":1208},{\"id\":1209},{\"id\":1210},{\"id\":1211},{\"id\":1212},{\"id\":1213},{\"id\":1214},{\"id\":1215},{\"id\":1216},{\"id\":1217},{\"id\":1218},{\"id\":1219},{\"id\":1220},{\"id\":1221},{\"id\":1222},{\"id\":1223},{\"id\":1224},{\"id\":1225},{\"id\":1226},{\"id\":1227},{\"id\":1228},{\"id\":1229},{\"id\":1230},{\"id\":1231},{\"id\":1232},{\"id\":1233},{\"id\":1234},{\"id\":1235},{\"id\":1236},{\"id\":1237},{\"id\":1238},{\"id\":1239},{\"id\":1240},{\"id\":1241},{\"id\":1242},{\"id\":1243},{\"id\":1244},{\"id\":1245},{\"id\":1246},{\"id\":1247},{\"id\":1248},{\"id\":1249},{\"id\":1250},{\"id\":1251},{\"id\":1252},{\"id\":1253},{\"id\":1254},{\"id\":1255},{\"id\":1256},{\"id\":1257},{\"id\":1258},{\"id\":1259},{\"id\":1260},{\"id\":1261},{\"id\":1262},{\"id\":1263},{\"id\":1264},{\"id\":1265},{\"id\":1266},{\"id\":1267},{\"id\":1268},{\"id\":1269},{\"id\":1270},{\"id\":1271},{\"id\":1272},{\"id\":1273},{\"id\":1274},{\"id\":1275},{\"id\":1276},{\"id\":1277},{\"id\":1278},{\"id\":1279},{\"id\":1280},{\"id\":1281},{\"id\":1282},{\"id\":1283},{\"id\":1284},{\"id\":1285},{\"id\":1286},{\"id\":1287},{\"id\":1288},{\"id\":1289},{\"id\":1290},{\"id\":1291},{\"id\":1292},{\"id\":1293},{\"id\":1294},{\"id\":1295},{\"id\":1296},{\"id\":1297},{\"id\":1298},{\"id\":1299},{\"id\":1300},{\"id\":1301},{\"id\":1302},{\"id\":1303},{\"id\":1304},{\"id\":1305},{\"id\":1306},{\"id\":1307},{\"id\":1308},{\"id\":1309},{\"id\":1310},{\"id\":1311},{\"id\":1312},{\"id\":1313},{\"id\":1314},{\"id\":1315},{\"id\":1316},{\"id\":1317},{\"id\":1318},{\"id\":1319},{\"id\":1320},{\"id\":1321},{\"id\":1322},{\"id\":1323},{\"id\":1324},{\"id\":1325},{\"id\":1326},{\"id\":1327},{\"id\":1328},{\"id\":1329},{\"id\":1330},{\"id\":1331},{\"id\":1332},{\"id\":1333},{\"id\":1334},{\"id\":1335},{\"id\":1336},{\"id\":1337},{\"id\":1338},{\"id\":1339},{\"id\":1340},{\"id\":1341},{\"id\":1342},{\"id\":1343},{\"id\":1344},{\"id\":1345},{\"id\":1346},{\"id\":1347},{\"id\":1348},{\"id\":1349},{\"id\":1350},{\"id\":1351},{\"id\":1352},{\"id\":1353},{\"id\":1354},{\"id\":1355},{\"id\":1356},{\"id\":1357},{\"id\":1358},{\"id\":1359},{\"id\":1360},{\"id\":1361},{\"id\":1362},{\"id\":1363},{\"id\":1364},{\"id\":1365},{\"id\":1366},{\"id\":1367},{\"id\":1368},{\"id\":1369},{\"id\":1370},{\"id\":1371},{\"id\":1372},{\"id\":1373},{\"id\":1374},{\"id\":1375},{\"id\":1376},{\"id\":1377},{\"id\":1378},{\"id\":1379},{\"id\":1380},{\"id\":1381},{\"id\":1382},{\"id\":1383},{\"id\":1384},{\"id\":1385},{\"id\":1386},{\"id\":1387},{\"id\":1388},{\"id\":1389},{\"id\":1390},{\"id\":1391},{\"id\":1392},{\"id\":1393},{\"id\":1394},{\"id\":1395},{\"id\":1396},{\"id\":1397},{\"id\":1398},{\"id\":1399},{\"id\":1400},{\"id\":1401},{\"id\":1402},{\"id\":1403},{\"id\":1404},{\"id\":1405},{\"id\":1406},{\"id\":1407},{\"id\":1408},{\"id\":1409},{\"id\":1410},{\"id\":1411},{\"id\":1412},{\"id\":1413},{\"id\":1414},{\"id\":1415},{\"id\":1416},{\"id\":1417},{\"id\":1418},{\"id\":1419},{\"id\":1420},{\"id\":1421},{\"id\":1422},{\"id\":1423},{\"id\":1424},{\"id\":1425},{\"id\":1426},{\"id\":1427},{\"id\":1428},{\"id\":1429},{\"id\":1430},{\"id\":1431},{\"id\":1432},{\"id\":1433},{\"id\":1434},{\"id\":1435},{\"id\":1436},{\"id\":1437},{\"id\":1438},{\"id\":1439},{\"id\":1440},{\"id\":1441},{\"id\":1442},{\"id\":1443},{\"id\":1444},{\"id\":1445},{\"id\":1446},{\"id\":1447},{\"id\":1448},{\"id\":1449},{\"id\":1450},{\"id\":1451},{\"id\":1452},{\"id\":1453},{\"id\":1454},{\"id\":1455},{\"id\":1456},{\"id\":1457},{\"id\":1458},{\"id\":1459},{\"id\":1460},{\"id\":1461},{\"id\":1462},{\"id\":1463},{\"id\":1464},{\"id\":1465},{\"id\":1466},{\"id\":1467},{\"id\":1468},{\"id\":1469},{\"id\":1470},{\"id\":1471},{\"id\":1472},{\"id\":1473},{\"id\":1474},{\"id\":1475},{\"id\":1476},{\"id\":1477},{\"id\":1478},{\"id\":1479},{\"id\":1480},{\"id\":1481},{\"id\":1482},{\"id\":1483},{\"id\":1484},{\"id\":1485},{\"id\":1486},{\"id\":1487},{\"id\":1488},{\"id\":1489},{\"id\":1490},{\"id\":1491},{\"id\":1492},{\"id\":1493},{\"id\":1494},{\"id\":1495},{\"id\":1496},{\"id\":1497},{\"id\":1498},{\"id\":1499},{\"id\":1500},{\"id\":1501},{\"id\":1502},{\"id\":1503},{\"id\":1504},{\"id\":1505},{\"id\":1506},{\"id\":1507},{\"id\":1508},{\"id\":1509},{\"id\":1510},{\"id\":1511},{\"id\":1512},{\"id\":1513},{\"id\":1514},{\"id\":1515},{\"id\":1516},{\"id\":1517},{\"id\":1518},{\"id\":1519},{\"id\":1520},{\"id\":1521},{\"id\":1522},{\"id\":1523},{\"id\":1524},{\"id\":1525},{\"id\":1526},{\"id\":1527},{\"id\":1528},{\"id\":1529},{\"id\":1530},{\"id\":1531},{\"id\":1532},{\"id\":1533},{\"id\":1534},{\"id\":1535},{\"id\":1536},{\"id\":1537},{\"id\":1538},{\"id\":1539},{\"id\":1540},{\"id\":1541},{\"id\":1542},{\"id\":1543},{\"id\":1544},{\"id\":1545},{\"id\":1546},{\"id\":1547},{\"id\":1548},{\"id\":1549},{\"id\":1550},{\"id\":1551},{\"id\":1552},{\"id\":1553},{\"id\":1554},{\"id\":1555},{\"id\":1556},{\"id\":1557},{\"id\":1558},{\"id\":1559},{\"id\":1560},{\"id\":1561},{\"id\":1562},{\"id\":1563},{\"id\":1564},{\"id\":1565},{\"id\":1566},{\"id\":1567},{\"id\":1568},{\"id\":1569},{\"id\":1570},{\"id\":1571},{\"id\":1572},{\"id\":1573},{\"id\":1574},{\"id\":1575},{\"id\":1576},{\"id\":1577},{\"id\":1578},{\"id\":1579},{\"id\":1580},{\"id\":1581},{\"id\":1582},{\"id\":1583},{\"id\":1584},{\"id\":1585},{\"id\":1586},{\"id\":1587},{\"id\":1588},{\"id\":1589},{\"id\":1590},{\"id\":1591},{\"id\":1592},{\"id\":1593},{\"id\":1594},{\"id\":1595},{\"id\":1596},{\"id\":1597},{\"id\":1598},{\"id\":1599},{\"id\":1600},{\"id\":1601},{\"id\":1602},{\"id\":1603},{\"id\":1604},{\"id\":1605},{\"id\":1606},{\"id\":1607},{\"id\":1608},{\"id\":1609},{\"id\":1610},{\"id\":1611},{\"id\":1612},{\"id\":1613},{\"id\":1614},{\"id\":1615},{\"id\":1616},{\"id\":1617},{\"id\":1618},{\"id\":1619},{\"id\":1620},{\"id\":1621},{\"id\":1622},{\"id\":1623},{\"id\":1624},{\"id\":1625},{\"id\":1626},{\"id\":1627},{\"id\":1628},{\"id\":1629},{\"id\":1630},{\"id\":1631},{\"id\":1632},{\"id\":1633},{\"id\":1634},{\"id\":1635},{\"id\":1636},{\"id\":1637},{\"id\":1638},{\"id\":1639},{\"id\":1640},{\"id\":1641},{\"id\":1642},{\"id\":1643},{\"id\":1644},{\"id\":1645},{\"id\":1646},{\"id\":1647},{\"id\":1648},{\"id\":1649},{\"id\":1650},{\"id\":1651},{\"id\":1652},{\"id\":1653},{\"id\":1654},{\"id\":1655},{\"id\":1656},{\"id\":1657},{\"id\":1658},{\"id\":1659},{\"id\":1660},{\"id\":1661},{\"id\":1662},{\"id\":1663},{\"id\":1664},{\"id\":1665},{\"id\":1666},{\"id\":1667},{\"id\":1668},{\"id\":1669},{\"id\":1670},{\"id\":1671},{\"id\":1672},{\"id\":1673},{\"id\":1674},{\"id\":1675},{\"id\":1676},{\"id\":1677},{\"id\":1678},{\"id\":1679},{\"id\":1680},{\"id\":1681},{\"id\":1682},{\"id\":1683},{\"id\":1684},{\"id\":1685},{\"id\":1686},{\"id\":1687},{\"id\":1688},{\"id\":1689},{\"id\":1690},{\"id\":1691},{\"id\":1692},{\"id\":1693},{\"id\":1694},{\"id\":1695},{\"id\":1696},{\"id\":1697},{\"id\":1698},{\"id\":1699},{\"id\":1700},{\"id\":1701},{\"id\":1702},{\"id\":1703},{\"id\":1704},{\"id\":1705},{\"id\":1706},{\"id\":1707},{\"id\":1708},{\"id\":1709},{\"id\":1710},{\"id\":1711},{\"id\":1712},{\"id\":1713},{\"id\":1714},{\"id\":1715},{\"id\":1716},{\"id\":1717},{\"id\":1718},{\"id\":1719},{\"id\":1720},{\"id\":1721},{\"id\":1722},{\"id\":1723},{\"id\":1724},{\"id\":1725},{\"id\":1726},{\"id\":1727},{\"id\":1728},{\"id\":1729},{\"id\":1730},{\"id\":1731},{\"id\":1732},{\"id\":1733},{\"id\":1734},{\"id\":1735},{\"id\":1736},{\"id\":1737},{\"id\":1738},{\"id\":1739},{\"id\":1740},{\"id\":1741},{\"id\":1742},{\"id\":1743},{\"id\":1744},{\"id\":1745},{\"id\":1746},{\"id\":1747},{\"id\":1748},{\"id\":1749},{\"id\":1750},{\"id\":1751},{\"id\":1752},{\"id\":1753},{\"id\":1754},{\"id\":1755},{\"id\":1756},{\"id\":1757},{\"id\":1758},{\"id\":1759},{\"id\":1760},{\"id\":1761},{\"id\":1762},{\"id\":1763},{\"id\":1764},{\"id\":1765},{\"id\":1766},{\"id\":1767},{\"id\":1768},{\"id\":1769},{\"id\":1770},{\"id\":1771},{\"id\":1772},{\"id\":1773},{\"id\":1774},{\"id\":1775},{\"id\":1776},{\"id\":1777},{\"id\":1778},{\"id\":1779},{\"id\":1780},{\"id\":1781},{\"id\":1782},{\"id\":1783},{\"id\":1784},{\"id\":1785},{\"id\":1786},{\"id\":1787},{\"id\":1788},{\"id\":1789},{\"id\":1790},{\"id\":1791},{\"id\":1792},{\"id\":1793},{\"id\":1794},{\"id\":1795},{\"id\":1796},{\"id\":1797},{\"id\":1798},{\"id\":1799},{\"id\":1800},{\"id\":1801},{\"id\":1802},{\"id\":1803},{\"id\":1804},{\"id\":1805},{\"id\":1806},{\"id\":1807},{\"id\":1808},{\"id\":1809},{\"id\":1810},{\"id\":1811},{\"id\":1812},{\"id\":1813},{\"id\":1814},{\"id\":1815},{\"id\":1816},{\"id\":1817},{\"id\":1818},{\"id\":1819},{\"id\":1820},{\"id\":1821},{\"id\":1822},{\"id\":1823},{\"id\":1824},{\"id\":1825},{\"id\":1826},{\"id\":1827},{\"id\":1828},{\"id\":1829},{\"id\":1830},{\"id\":1831},{\"id\":1832},{\"id\":1833},{\"id\":1834},{\"id\":1835},{\"id\":1836},{\"id\":1837},{\"id\":1838},{\"id\":1839},{\"id\":1840},{\"id\":1841},{\"id\":1842},{\"id\":1843},{\"id\":1844},{\"id\":1845},{\"id\":1846},{\"id\":1847},{\"id\":1848},{\"id\":1849},{\"id\":1850},{\"id\":1851},{\"id\":1852},{\"id\":1853},{\"id\":1854},{\"id\":1855},{\"id\":1856},{\"id\":1857},{\"id\":1858},{\"id\":1859},{\"id\":1860},{\"id\":1861},{\"id\":1862},{\"id\":1863},{\"id\":1864},{\"id\":1865},{\"id\":1866},{\"id\":1867},{\"id\":1868},{\"id\":1869},{\"id\":1870},{\"id\":1871},{\"id\":1872},{\"id\":1873},{\"id\":1874},{\"id\":1875},{\"id\":1876},{\"id\":1877},{\"id\":1878},{\"id\":1879},{\"id\":1880},{\"id\":1881},{\"id\":1882},{\"id\":1883},{\"id\":1884},{\"id\":1885},{\"id\":1886},{\"id\":1887},{\"id\":1888},{\"id\":1889},{\"id\":1890},{\"id\":1891},{\"id\":1892},{\"id\":1893},{\"id\":1894},{\"id\":1895},{\"id\":1896},{\"id\":1897},{\"id\":1898},{\"id\":1899},{\"id\":1900},{\"id\":1901},{\"id\":1902},{\"id\":1903},{\"id\":1904},{\"id\":1905},{\"id\":1906},{\"id\":1907},{\"id\":1908},{\"id\":1909},{\"id\":1910},{\"id\":1911},{\"id\":1912},{\"id\":1913},{\"id\":1914},{\"id\":1915},{\"id\":1916},{\"id\":1917},{\"id\":1918},{\"id\":1919},{\"id\":1920},{\"id\":1921},{\"id\":1922},{\"id\":1923},{\"id\":1924},{\"id\":1925},{\"id\":1926},{\"id\":1927},{\"id\":1928},{\"id\":1929},{\"id\":1930},{\"id\":1931},{\"id\":1932},{\"id\":1933},{\"id\":1934},{\"id\":1935},{\"id\":1936},{\"id\":1937},{\"id\":1938},{\"id\":1939},{\"id\":1940},{\"id\":1941},{\"id\":1942},{\"id\":1943},{\"id\":1944},{\"id\":1945},{\"id\":1946},{\"id\":1947},{\"id\":1948},{\"id\":1949},{\"id\":1950},{\"id\":1951},{\"id\":1952},{\"id\":1953},{\"id\":1954},{\"id\":1955},{\"id\":1956},{\"id\":1957},{\"id\":1958},{\"id\":1959},{\"id\":1960},{\"id\":1961},{\"id\":1962},{\"id\":1963},{\"id\":1964},{\"id\":1965},{\"id\":1966},{\"id\":1967},{\"id\":1968},{\"id\":1969},{\"id\":1970},{\"id\":1971},{\"id\":1972},{\"id\":1973},{\"id\":1974},{\"id\":1975},{\"id\":1976},{\"id\":1977},{\"id\":1978},{\"id\":1979},{\"id\":1980},{\"id\":1981},{\"id\":1982},{\"id\":1983},{\"id\":1984},{\"id\":1985},{\"id\":1986},{\"id\":1987},{\"id\":1988},{\"id\":1989},{\"id\":1990},{\"id\":1991},{\"id\":1992},{\"id\":1993},{\"id\":1994},{\"id\":1995},{\"id\":1996},{\"id\":1997},{\"id\":1998},{\"id\":1999},{\"id\":2000},{\"id\":2001},{\"id\":2002},{\"id\":2003},{\"id\":2004},{\"id\":2005},{\"id\":2006},{\"id\":2007},{\"id\":2008},{\"id\":2009},{\"id\":2010},{\"id\":2011},{\"id\":2012},{\"id\":2013},{\"id\":2014},{\"id\":2015},{\"id\":2016},{\"id\":2017},{\"id\":2018},{\"id\":2019},{\"id\":2020},{\"id\":2021},{\"id\":2022},{\"id\":2023},{\"id\":2024},{\"id\":2025},{\"id\":2026},{\"id\":2027},{\"id\":2028},{\"id\":2029},{\"id\":2030},{\"id\":2031},{\"id\":2032},{\"id\":2033},{\"id\":2034},{\"id\":2035},{\"id\":2036},{\"id\":2037},{\"id\":2038},{\"id\":2039},{\"id\":2040},{\"id\":2041},{\"id\":2042},{\"id\":2043},{\"id\":2044},{\"id\":2045},{\"id\":2046},{\"id\":2047},{\"id\":2048},{\"id\":2049},{\"id\":2050},{\"id\":2051},{\"id\":2052},{\"id\":2053},{\"id\":2054},{\"id\":2055},{\"id\":2056},{\"id\":2057},{\"id\":2058},{\"id\":2059},{\"id\":2060},{\"id\":2061},{\"id\":2062},{\"id\":2063},{\"id\":2064},{\"id\":2065},{\"id\":2066},{\"id\":2067},{\"id\":2068},{\"id\":2069},{\"id\":2070},{\"id\":2071},{\"id\":2072},{\"id\":2073},{\"id\":2074},{\"id\":2075},{\"id\":2076},{\"id\":2077},{\"id\":2078},{\"id\":2079},{\"id\":2080},{\"id\":2081},{\"id\":2082},{\"id\":2083},{\"id\":2084},{\"id\":2085},{\"id\":2086},{\"id\":2087},{\"id\":2088},{\"id\":2089},{\"id\":2090},{\"id\":2091},{\"id\":2092},{\"id\":2093},{\"id\":2094},{\"id\":2095},{\"id\":2096},{\"id\":2097},{\"id\":2098},{\"id\":2099},{\"id\":2100},{\"id\":2101},{\"id\":2102},{\"id\":2103},{\"id\":2104},{\"id\":2105},{\"id\":2106},{\"id\":2107},{\"id\":2108},{\"id\":2109},{\"id\":2110},{\"id\":2111},{\"id\":2112},{\"id\":2113},{\"id\":2114},{\"id\":2115},{\"id\":2116},{\"id\":2117},{\"id\":2118},{\"id\":2119},{\"id\":2120},{\"id\":2121},{\"id\":2122},{\"id\":2123},{\"id\":2124},{\"id\":2125},{\"id\":2126},{\"id\":2127},{\"id\":2128},{\"id\":2129},{\"id\":2130},{\"id\":2131},{\"id\":2132},{\"id\":2133},{\"id\":2134},{\"id\":2135},{\"id\":2136},{\"id\":2137},{\"id\":2138},{\"id\":2139},{\"id\":2140},{\"id\":2141},{\"id\":2142},{\"id\":2143},{\"id\":2144},{\"id\":2145},{\"id\":2146},{\"id\":2147},{\"id\":2148},{\"id\":2149},{\"id\":2150},{\"id\":2151},{\"id\":2152},{\"id\":2153},{\"id\":2154},{\"id\":2155},{\"id\":2156},{\"id\":2157},{\"id\":2158},{\"id\":2159},{\"id\":2160},{\"id\":2161},{\"id\":2162},{\"id\":2163},{\"id\":2164},{\"id\":2165},{\"id\":2166},{\"id\":2167},{\"id\":2168},{\"id\":2169},{\"id\":2170},{\"id\":2171},{\"id\":2172},{\"id\":2173},{\"id\":2174},{\"id\":2175},{\"id\":2176},{\"id\":2177},{\"id\":2178},{\"id\":2179},{\"id\":2180},{\"id\":2181},{\"id\":2182},{\"id\":2183},{\"id\":2184},{\"id\":2185},{\"id\":2186},{\"id\":2187},{\"id\":2188},{\"id\":2189},{\"id\":2190},{\"id\":2191},{\"id\":2192},{\"id\":2193},{\"id\":2194},{\"id\":2195},{\"id\":2196},{\"id\":2197},{\"id\":2198},{\"id\":2199},{\"id\":2200},{\"id\":2201},{\"id\":2202},{\"id\":2203},{\"id\":2204},{\"id\":2205},{\"id\":2206},{\"id\":2207},{\"id\":2208},{\"id\":2209},{\"id\":2210},{\"id\":2211},{\"id\":2212},{\"id\":2213},{\"id\":2214},{\"id\":2215},{\"id\":2216},{\"id\":2217},{\"id\":2218},{\"id\":2219},{\"id\":2220},{\"id\":2221},{\"id\":2222},{\"id\":2223},{\"id\":2224},{\"id\":2225},{\"id\":2226},{\"id\":2227},{\"id\":2228},{\"id\":2229},{\"id\":2230},{\"id\":2231},{\"id\":2232},{\"id\":2233},{\"id\":2234},{\"id\":2235},{\"id\":2236},{\"id\":2237},{\"id\":2238},{\"id\":2239},{\"id\":2240},{\"id\":2241},{\"id\":2242},{\"id\":2243},{\"id\":2244},{\"id\":2245},{\"id\":2246},{\"id\":2247},{\"id\":2248},{\"id\":2249},{\"id\":2250},{\"id\":2251},{\"id\":2252},{\"id\":2253},{\"id\":2254},{\"id\":2255},{\"id\":2256},{\"id\":2257},{\"id\":2258},{\"id\":2259},{\"id\":2260},{\"id\":2261},{\"id\":2262},{\"id\":2263},{\"id\":2264},{\"id\":2265},{\"id\":2266},{\"id\":2267},{\"id\":2268},{\"id\":2269},{\"id\":2270},{\"id\":2271},{\"id\":2272},{\"id\":2273},{\"id\":2274},{\"id\":2275},{\"id\":2276},{\"id\":2277},{\"id\":2278},{\"id\":2279},{\"id\":2280},{\"id\":2281},{\"id\":2282},{\"id\":2283},{\"id\":2284},{\"id\":2285},{\"id\":2286},{\"id\":2287},{\"id\":2288},{\"id\":2289},{\"id\":2290},{\"id\":2291},{\"id\":2292},{\"id\":2293},{\"id\":2294},{\"id\":2295},{\"id\":2296},{\"id\":2297},{\"id\":2298},{\"id\":2299},{\"id\":2300},{\"id\":2301},{\"id\":2302},{\"id\":2311},{\"id\":2316},{\"id\":2317},{\"id\":2343},{\"id\":2344},{\"id\":2393},{\"id\":2318},{\"id\":2345},{\"id\":2346},{\"id\":2394},{\"id\":2319},{\"id\":2347},{\"id\":2348},{\"id\":2395},{\"id\":2320},{\"id\":2349},{\"id\":2350},{\"id\":2396},{\"id\":2321},{\"id\":2351},{\"id\":2352},{\"id\":2397},{\"id\":2322},{\"id\":2353},{\"id\":2354},{\"id\":2398},{\"id\":2323},{\"id\":2355},{\"id\":2356},{\"id\":2399},{\"id\":2324},{\"id\":2357},{\"id\":2358},{\"id\":2400},{\"id\":2325},{\"id\":2359},{\"id\":2360},{\"id\":2401},{\"id\":2326},{\"id\":2361},{\"id\":2362},{\"id\":2402},{\"id\":2327},{\"id\":2363},{\"id\":2364},{\"id\":2403},{\"id\":2328},{\"id\":2365},{\"id\":2366},{\"id\":2404},{\"id\":2329},{\"id\":2367},{\"id\":2368},{\"id\":2405},{\"id\":2330},{\"id\":2369},{\"id\":2370},{\"id\":2406},{\"id\":2331},{\"id\":2371},{\"id\":2372},{\"id\":2407},{\"id\":2332},{\"id\":2373},{\"id\":2374},{\"id\":2408},{\"id\":2333},{\"id\":2375},{\"id\":2376},{\"id\":2409},{\"id\":2334},{\"id\":2377},{\"id\":2378},{\"id\":2410},{\"id\":2335},{\"id\":2379},{\"id\":2380},{\"id\":2411},{\"id\":2336},{\"id\":2381},{\"id\":2382},{\"id\":2412},{\"id\":2337},{\"id\":2383},{\"id\":2384},{\"id\":2413},{\"id\":2338},{\"id\":2385},{\"id\":2386},{\"id\":2414},{\"id\":2339},{\"id\":2387},{\"id\":2388},{\"id\":2415},{\"id\":2340},{\"id\":2389},{\"id\":2390},{\"id\":2416},{\"id\":2341},{\"id\":2391},{\"id\":2392},{\"id\":2417},{\"id\":2342},{\"id\":2418},{\"id\":2419},{\"id\":2312},{\"id\":2420},{\"id\":2421},{\"id\":2435},{\"id\":2436},{\"id\":2461},{\"id\":2422},{\"id\":2437},{\"id\":2438},{\"id\":2462},{\"id\":2423},{\"id\":2439},{\"id\":2440},{\"id\":2463},{\"id\":2424},{\"id\":2441},{\"id\":2442},{\"id\":2464},{\"id\":2425},{\"id\":2443},{\"id\":2444},{\"id\":2465},{\"id\":2426},{\"id\":2445},{\"id\":2446},{\"id\":2466},{\"id\":2427},{\"id\":2447},{\"id\":2448},{\"id\":2467},{\"id\":2428},{\"id\":2449},{\"id\":2450},{\"id\":2468},{\"id\":2429},{\"id\":2451},{\"id\":2452},{\"id\":2469},{\"id\":2430},{\"id\":2453},{\"id\":2454},{\"id\":2470},{\"id\":2431},{\"id\":2455},{\"id\":2456},{\"id\":2471},{\"id\":2432},{\"id\":2457},{\"id\":2458},{\"id\":2472},{\"id\":2433},{\"id\":2459},{\"id\":2460},{\"id\":2473},{\"id\":2434},{\"id\":2474},{\"id\":2475},{\"id\":2313},{\"id\":2476},{\"id\":2488},{\"id\":2477},{\"id\":2489},{\"id\":2478},{\"id\":2490},{\"id\":2479},{\"id\":2491},{\"id\":2480},{\"id\":2492},{\"id\":2481},{\"id\":2493},{\"id\":2482},{\"id\":2494},{\"id\":2483},{\"id\":2495},{\"id\":2484},{\"id\":2496},{\"id\":2485},{\"id\":2497},{\"id\":2486},{\"id\":2498},{\"id\":2487},{\"id\":2499},{\"id\":2314},{\"id\":2500},{\"id\":2501},{\"id\":2502},{\"id\":2503},{\"id\":2504},{\"id\":2505},{\"id\":2506},{\"id\":2507},{\"id\":2508},{\"id\":2509},{\"id\":2510},{\"id\":2511},{\"id\":2512},{\"id\":2513},{\"id\":2514},{\"id\":2515},{\"id\":2516},{\"id\":2517},{\"id\":2518},{\"id\":2519},{\"id\":2520},{\"id\":2521},{\"id\":2522},{\"id\":2523},{\"id\":2315},{\"id\":2524},{\"id\":2542},{\"id\":2543},{\"id\":2578},{\"id\":2525},{\"id\":2544},{\"id\":2545},{\"id\":2579},{\"id\":2526},{\"id\":2546},{\"id\":2547},{\"id\":2580},{\"id\":2527},{\"id\":2548},{\"id\":2549},{\"id\":2581},{\"id\":2528},{\"id\":2550},{\"id\":2551},{\"id\":2582},{\"id\":2529},{\"id\":2552},{\"id\":2553},{\"id\":2583},{\"id\":2530},{\"id\":2554},{\"id\":2555},{\"id\":2584},{\"id\":2531},{\"id\":2556},{\"id\":2557},{\"id\":2585},{\"id\":2532},{\"id\":2558},{\"id\":2559},{\"id\":2586},{\"id\":2533},{\"id\":2560},{\"id\":2561},{\"id\":2587},{\"id\":2534},{\"id\":2562},{\"id\":2563},{\"id\":2588},{\"id\":2535},{\"id\":2564},{\"id\":2565},{\"id\":2589},{\"id\":2536},{\"id\":2566},{\"id\":2567},{\"id\":2590},{\"id\":2537},{\"id\":2568},{\"id\":2569},{\"id\":2591},{\"id\":2538},{\"id\":2570},{\"id\":2571},{\"id\":2592},{\"id\":2539},{\"id\":2572},{\"id\":2573},{\"id\":2593},{\"id\":2540},{\"id\":2574},{\"id\":2575},{\"id\":2594},{\"id\":2541},{\"id\":2576},{\"id\":2577},{\"id\":2595},{\"id\":2303},{\"id\":2304},{\"id\":2305},{\"id\":2306},{\"id\":2307},{\"nodeType\":3,\"id\":2596,\"textContent\":\" // Track clicks on page $(document).ready(function() { $(\\\".control\\\").click(function(e) { e.stopImmediatePropagation(); clicks = clicks + 1; console.log(clicks); }); }); $('.userid').html(sid); // console.log(\\\"start of clicked array: \\\"+clicked); // console.log(\\\"start of hovered string: \\\"+hovered); //set correct answers for each question var triangular_answers = { \\\"acme.starttime.1\\\" : [\\\"F\\\"], \\\"acme.starts.1\\\" : [\\\"K\\\"], \\\"acme.meets.1\\\" : [\\\"F\\\"], \\\"acme.endtime.1\\\" : [\\\"H\\\"], \\\"acme.midpoint.1\\\" : [\\\"O\\\"], \\\"acme.starttime.2\\\" : [\\\"F\\\"], \\\"acme.starts.2\\\" : [\\\"K\\\"], \\\"acme.meets.2\\\" : [\\\"F\\\"], \\\"acme.endtime.2\\\" : [\\\"H\\\"], \\\"acme.midpoint.2\\\" : [\\\"A\\\"], \\\"bigset.duration.1\\\" : [\\\"E\\\",\\\"G\\\"], \\\"bigset.duration+starts.1\\\" : [\\\"X\\\",\\\"O\\\"], \\\"bigset.duration+contained.1\\\" : [\\\"G\\\"], \\\"bigset.starttime+before+endtime+during.1\\\": [\\\"I\\\"], \\\"bigset.ends.1\\\" : [\\\"E\\\"], \\\"bigset.duration.2\\\" : [\\\"E\\\",\\\"G\\\"], \\\"bigset.duration+starts.2\\\" : [\\\"X\\\",\\\"O\\\"], \\\"bigset.duration+contained.2\\\" : [\\\"G\\\"], \\\"bigset.starttime+before+endtime+during.2\\\":[\\\"I\\\"], \\\"bigset.ends.2\\\" : [\\\"E\\\"], \\\"bigset.starttime.1\\\" : [\\\"M\\\",\\\"L\\\"], \\\"bigset.starts.1\\\" : [\\\"G\\\"], \\\"bigset.meets.1\\\" : [\\\"E\\\",\\\"F\\\"], \\\"bigset.endtime.1\\\" : [\\\"X\\\"], \\\"bigset.midpoint.1\\\" : [\\\"K\\\",\\\"X\\\"], \\\"bigset.starttime.2\\\" : [\\\"M\\\",\\\"L\\\"], \\\"bigset.starts.2\\\" : [\\\"G\\\"], \\\"bigset.meets.2\\\" : [\\\"E\\\",\\\"F\\\"], \\\"bigset.endtime.2\\\" : [\\\"X\\\"], \\\"bigset.midpoint.2\\\" : [\\\"K\\\",\\\"X\\\"] } var orthogonal_answers = { \\\"acme.starttime.1\\\" : [\\\"A\\\"], \\\"acme.starts.1\\\" : [\\\"E\\\"], \\\"acme.meets.1\\\" : [\\\"Z\\\"], \\\"acme.endtime.1\\\" : [\\\"U\\\"], \\\"acme.midpoint.1\\\" : [\\\"U\\\"], \\\"acme.starttime.2\\\" : [\\\"0\\\"], \\\"acme.starts.2\\\" : [\\\"0\\\"], \\\"acme.meets.2\\\" : [\\\"0\\\"], \\\"acme.endtime.2\\\" : [\\\"0\\\"], \\\"acme.midpoint.2\\\" : [\\\"0\\\"], \\\"bigset.duration.1\\\" : [\\\"E\\\",\\\"G\\\"], \\\"bigset.duration+starts.1\\\" : [\\\"F\\\",\\\"B\\\"], \\\"bigset.duration+contained.1\\\" : [\\\"E\\\"], \\\"bigset.starttime+before+endtime+during.1\\\": [\\\"I\\\"], \\\"bigset.ends.1\\\" : [\\\"X\\\"], \\\"bigset.duration.2\\\" : [\\\"E\\\",\\\"G\\\"], \\\"bigset.duration+starts.2\\\" : [\\\"F\\\",\\\"B\\\"], \\\"bigset.duration+contained.2\\\" : [\\\"E\\\"], \\\"bigset.starttime+before+endtime+during.2\\\":[\\\"I\\\"], \\\"bigset.ends.2\\\" : [\\\"X\\\"], \\\"bigset.starttime.1\\\" : [\\\"F\\\",\\\"B\\\"], \\\"bigset.starts.1\\\" : [\\\"B\\\"], \\\"bigset.meets.1\\\" : [\\\"F\\\",\\\"X\\\"], \\\"bigset.endtime.1\\\" : [\\\"B\\\"], \\\"bigset.midpoint.1\\\" : [\\\"E\\\",\\\"F\\\"], \\\"bigset.starttime.2\\\" : [\\\"F\\\",\\\"B\\\"], \\\"bigset.starts.2\\\" : [\\\"B\\\"], \\\"bigset.meets.2\\\" : [\\\"F\\\",\\\"X\\\"], \\\"bigset.endtime.2\\\" : [\\\"B\\\"], \\\"bigset.midpoint.2\\\" : [\\\"E\\\",\\\"F\\\"] } //display the question and answer buttons based on input values from jsPsych document.getElementById(scenario+\\\".\\\"+question).style.display = \\\"block\\\"; if (question == \\\"strategy\\\") {document.getElementById(\\\"strategyButton\\\").style.display = \\\"block\\\";} else {document.getElementById(\\\"testingButton\\\").style.display = \\\"block\\\";} //---------SET PROPERTIES OF THE GRAPH -------------// // set the dimensions and margins of the graph var margin = {top: 25, right: 30, bottom: 90, left: 100}, width = 800, height = 800; var intersects = false; //default value for intersects scaffold var xAxisTitle, yAxisTitle; var datafile =\\\"\\\"; // SET AXIS VALUES if (axis == 1){ axis = \\\"Orthogonal-XInside-YFull\\\"; } else if (axis == 2){ axis = \\\"Orthogonal-XInside-YPartial\\\"; } else if (axis ==3){ axis = \\\"Triangular-XInside-YInside\\\"; } else if (axis ==4){ axis = \\\"Orthogonal-XInside-YInside\\\"; } else if (axis ==5){ axis = \\\"Orthogonal-XFull-YFull\\\"; } // SET EXPLICIT SCAFFOLD FEATURES if (explicit ==2 && axis != \\\"diagonal\\\"){ scaffold = 2; intersects = false; } else if (explicit == 2 && axis == \\\"diagonal\\\"){ scaffold = 2; intersects = false; } //TODO: not sure if above two lines are still valid since leaders are now generated on the fly else if (explicit == 3){ $('#hint-interactive').css(\\\"display\\\",\\\"block\\\"); //display textimage scaffold intersects = true; } //SET DATA FILE FOR IMPLICIT SCAFFOLD if (impasse == 1){ datafile = \\\"../views/src/data/acme_nonimpasse.csv\\\"; } else if (impasse == 2){ datafile = \\\"../views/src/data/acme_impasse.csv\\\"; } //OVERRIDE DATA FILE FOR NON-SCAFFOLD QUESTIONS if (q > 5) { //override data file if q# is greater than 5 datafile = \\\"../views/src/data/bigset.csv\\\"; console.log(\\\"override data file\\\"); $('#orthogonal-image').css(\\\"display\\\",\\\"none\\\"); //display textimage scaffold $('#diagonal-image').css(\\\"display\\\",\\\"none\\\"); //display textimage scaffold $('#hint-interactive').css(\\\"display\\\",\\\"none\\\"); //display textimage scaffold intersects = false; } // //---------CREATE THE SVG ------------------------// var svg = d3.select(\\\".d3container\\\").append(\\\"svg\\\") .attr(\\\"width\\\", width + margin.left + margin.right) .attr(\\\"height\\\", height + margin.top + margin.bottom) .append(\\\"g\\\") .attr(\\\"transform\\\", \\\"translate(\\\" + margin.left + \\\",\\\" + margin.top + \\\")\\\"); //---------DRAW THE GRAPH ------------------------// xAxisTitle = \\\"START & END TIME (time of day)\\\"; yAxisTitle = \\\"DURATION (in hours)\\\"; drawTriangleModel(datafile,intersects,axis,scaffold,q); \"},{\"id\":2308},{\"id\":2309},{\"nodeType\":3,\"id\":2597,\"textContent\":\" //MOUSE LOGGING SCRIPT var mouseLog = [] var xwidth = $(document).width(); var xheight = $(document).width(); mouseLog.push(\\\"{x:\\\"+xwidth+\\\",y:\\\"+xheight+\\\",t:\\\"+\\\"0};\\\") document.onmousemove = function(e){ var pageCoords = \\\"{x:\\\" + e.pageX + \\\",y:\\\"+ e.pageY +\\\",t:\\\"+ Date.now()+ \\\"};\\\" ; mouseLog.push(pageCoords); // console.log(pageCoords); }; \"},{\"id\":2310}],[],[],[]]}"
    },
    {
      "sequence": 3,
      "data": "{\"f\":\"applyChanged\",\"args\":[[],[{\"nodeType\":1,\"id\":2598,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-text-preamble\",\"class\":\"jspsych-survey-text-preamble\"},\"parentNode\":{\"id\":55}},{\"nodeType\":1,\"id\":2599,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-text-0\",\"class\":\"jspsych-survey-text-question\"},\"previousSibling\":{\"id\":2598},\"parentNode\":{\"id\":55}},{\"nodeType\":1,\"id\":2600,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-text-1\",\"class\":\"jspsych-survey-text-question\"},\"previousSibling\":{\"id\":2599},\"parentNode\":{\"id\":55}},{\"nodeType\":1,\"id\":2601,\"tagName\":\"BUTTON\",\"attributes\":{\"id\":\"jspsych-survey-text-next\",\"class\":\"jspsych-btn jspsych-survey-text\"},\"previousSibling\":{\"id\":2600},\"parentNode\":{\"id\":55}},{\"nodeType\":1,\"id\":2602,\"tagName\":\"P\",\"attributes\":{\"class\":\"jspsych-survey-text\"},\"parentNode\":{\"id\":2599}},{\"nodeType\":1,\"id\":2603,\"tagName\":\"TEXTAREA\",\"attributes\":{\"name\":\"#jspsych-survey-text-response-0\",\"cols\":\"40\",\"rows\":\"1\"},\"previousSibling\":{\"id\":2602},\"parentNode\":{\"id\":2599}},{\"nodeType\":3,\"id\":2604,\"textContent\":\"What is your age?\",\"parentNode\":{\"id\":2602}},{\"nodeType\":1,\"id\":2605,\"tagName\":\"P\",\"attributes\":{\"class\":\"jspsych-survey-text\"},\"parentNode\":{\"id\":2600}},{\"nodeType\":1,\"id\":2606,\"tagName\":\"TEXTAREA\",\"attributes\":{\"name\":\"#jspsych-survey-text-response-1\",\"cols\":\"40\",\"rows\":\"1\"},\"previousSibling\":{\"id\":2605},\"parentNode\":{\"id\":2600}},{\"nodeType\":3,\"id\":2607,\"textContent\":\"In what country were you born?\",\"parentNode\":{\"id\":2605}},{\"nodeType\":3,\"id\":2608,\"textContent\":\"Submit Answers\",\"parentNode\":{\"id\":2601}}],[],[]]}"
    },
    {
      "sequence": 4,
      "data": "{\"f\":\"applyChanged\",\"args\":[[{\"id\":2598},{\"id\":2599},{\"id\":2602},{\"id\":2604},{\"id\":2603},{\"id\":2600},{\"id\":2605},{\"id\":2607},{\"id\":2606},{\"id\":2601},{\"id\":2608}],[],[],[]]}"
    },
    {
      "sequence": 5,
      "data": "{\"f\":\"applyChanged\",\"args\":[[],[{\"nodeType\":1,\"id\":2609,\"tagName\":\"FORM\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-form\"},\"parentNode\":{\"id\":55}},{\"nodeType\":1,\"id\":2610,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-preamble\",\"class\":\"jspsych-survey-multi-choice-preamble\"},\"parentNode\":{\"id\":2609}},{\"nodeType\":1,\"id\":2611,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-0\",\"class\":\"jspsych-survey-multi-choice-question jspsych-survey-multi-choice-horizontal\"},\"previousSibling\":{\"id\":2610},\"parentNode\":{\"id\":2609}},{\"nodeType\":1,\"id\":2612,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-1\",\"class\":\"jspsych-survey-multi-choice-question jspsych-survey-multi-choice-horizontal\"},\"previousSibling\":{\"id\":2611},\"parentNode\":{\"id\":2609}},{\"nodeType\":1,\"id\":2613,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-2\",\"class\":\"jspsych-survey-multi-choice-question jspsych-survey-multi-choice-horizontal\"},\"previousSibling\":{\"id\":2612},\"parentNode\":{\"id\":2609}},{\"nodeType\":1,\"id\":2614,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-3\",\"class\":\"jspsych-survey-multi-choice-question jspsych-survey-multi-choice-horizontal\"},\"previousSibling\":{\"id\":2613},\"parentNode\":{\"id\":2609}},{\"nodeType\":1,\"id\":2615,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"submit\",\"id\":\"jspsych-survey-multi-choice-next\",\"class\":\"jspsych-survey-multi-choice jspsych-btn\",\"value\":\"Submit Answers\"},\"previousSibling\":{\"id\":2614},\"parentNode\":{\"id\":2609}},{\"nodeType\":1,\"id\":2616,\"tagName\":\"P\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text survey-multi-choice\"},\"parentNode\":{\"id\":2611}},{\"nodeType\":1,\"id\":2617,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-0-0\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2616},\"parentNode\":{\"id\":2611}},{\"nodeType\":1,\"id\":2618,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-0-1\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2617},\"parentNode\":{\"id\":2611}},{\"nodeType\":1,\"id\":2619,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-0-2\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2618},\"parentNode\":{\"id\":2611}},{\"nodeType\":1,\"id\":2620,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-0-3\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2619},\"parentNode\":{\"id\":2611}},{\"nodeType\":3,\"id\":2621,\"textContent\":\"What is your first language?\",\"parentNode\":{\"id\":2616}},{\"nodeType\":1,\"id\":2622,\"tagName\":\"SPAN\",\"attributes\":{\"class\":\"required\"},\"previousSibling\":{\"id\":2621},\"parentNode\":{\"id\":2616}},{\"nodeType\":1,\"id\":2623,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2617}},{\"nodeType\":1,\"id\":2624,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-0\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2623}},{\"nodeType\":3,\"id\":2625,\"textContent\":\"English\",\"previousSibling\":{\"id\":2624},\"parentNode\":{\"id\":2623}},{\"nodeType\":1,\"id\":2626,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2618}},{\"nodeType\":1,\"id\":2627,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-0\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2626}},{\"nodeType\":3,\"id\":2628,\"textContent\":\"Spanish\",\"previousSibling\":{\"id\":2627},\"parentNode\":{\"id\":2626}},{\"nodeType\":1,\"id\":2629,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2619}},{\"nodeType\":1,\"id\":2630,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-0\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2629}},{\"nodeType\":3,\"id\":2631,\"textContent\":\"Mandarin or Cantonese\",\"previousSibling\":{\"id\":2630},\"parentNode\":{\"id\":2629}},{\"nodeType\":1,\"id\":2632,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2620}},{\"nodeType\":1,\"id\":2633,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-0\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2632}},{\"nodeType\":3,\"id\":2634,\"textContent\":\"Other\",\"previousSibling\":{\"id\":2633},\"parentNode\":{\"id\":2632}},{\"nodeType\":3,\"id\":2635,\"textContent\":\"*\",\"parentNode\":{\"id\":2622}},{\"nodeType\":1,\"id\":2636,\"tagName\":\"P\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text survey-multi-choice\"},\"parentNode\":{\"id\":2612}},{\"nodeType\":1,\"id\":2637,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-1-0\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2636},\"parentNode\":{\"id\":2612}},{\"nodeType\":1,\"id\":2638,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-1-1\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2637},\"parentNode\":{\"id\":2612}},{\"nodeType\":1,\"id\":2639,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-1-2\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2638},\"parentNode\":{\"id\":2612}},{\"nodeType\":1,\"id\":2640,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-1-3\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2639},\"parentNode\":{\"id\":2612}},{\"nodeType\":1,\"id\":2641,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-1-4\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2640},\"parentNode\":{\"id\":2612}},{\"nodeType\":1,\"id\":2642,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-1-5\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2641},\"parentNode\":{\"id\":2612}},{\"nodeType\":1,\"id\":2643,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-1-6\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2642},\"parentNode\":{\"id\":2612}},{\"nodeType\":3,\"id\":2644,\"textContent\":\"What is your year in school?\",\"parentNode\":{\"id\":2636}},{\"nodeType\":1,\"id\":2645,\"tagName\":\"SPAN\",\"attributes\":{\"class\":\"required\"},\"previousSibling\":{\"id\":2644},\"parentNode\":{\"id\":2636}},{\"nodeType\":1,\"id\":2646,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2637}},{\"nodeType\":1,\"id\":2647,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-1\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2646}},{\"nodeType\":3,\"id\":2648,\"textContent\":\"First\",\"previousSibling\":{\"id\":2647},\"parentNode\":{\"id\":2646}},{\"nodeType\":1,\"id\":2649,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2638}},{\"nodeType\":1,\"id\":2650,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-1\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2649}},{\"nodeType\":3,\"id\":2651,\"textContent\":\"Second\",\"previousSibling\":{\"id\":2650},\"parentNode\":{\"id\":2649}},{\"nodeType\":1,\"id\":2652,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2639}},{\"nodeType\":1,\"id\":2653,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-1\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2652}},{\"nodeType\":3,\"id\":2654,\"textContent\":\"Third\",\"previousSibling\":{\"id\":2653},\"parentNode\":{\"id\":2652}},{\"nodeType\":1,\"id\":2655,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2640}},{\"nodeType\":1,\"id\":2656,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-1\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2655}},{\"nodeType\":3,\"id\":2657,\"textContent\":\"Fourth\",\"previousSibling\":{\"id\":2656},\"parentNode\":{\"id\":2655}},{\"nodeType\":1,\"id\":2658,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2641}},{\"nodeType\":1,\"id\":2659,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-1\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2658}},{\"nodeType\":3,\"id\":2660,\"textContent\":\"Fifth\",\"previousSibling\":{\"id\":2659},\"parentNode\":{\"id\":2658}},{\"nodeType\":1,\"id\":2661,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2642}},{\"nodeType\":1,\"id\":2662,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-1\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2661}},{\"nodeType\":3,\"id\":2663,\"textContent\":\"Graduate\",\"previousSibling\":{\"id\":2662},\"parentNode\":{\"id\":2661}},{\"nodeType\":1,\"id\":2664,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2643}},{\"nodeType\":1,\"id\":2665,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-1\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2664}},{\"nodeType\":3,\"id\":2666,\"textContent\":\"Other\",\"previousSibling\":{\"id\":2665},\"parentNode\":{\"id\":2664}},{\"nodeType\":3,\"id\":2667,\"textContent\":\"*\",\"parentNode\":{\"id\":2645}},{\"nodeType\":1,\"id\":2668,\"tagName\":\"P\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text survey-multi-choice\"},\"parentNode\":{\"id\":2613}},{\"nodeType\":1,\"id\":2669,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-2-0\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2668},\"parentNode\":{\"id\":2613}},{\"nodeType\":1,\"id\":2670,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-2-1\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2669},\"parentNode\":{\"id\":2613}},{\"nodeType\":1,\"id\":2671,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-2-2\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2670},\"parentNode\":{\"id\":2613}},{\"nodeType\":1,\"id\":2672,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-2-3\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2671},\"parentNode\":{\"id\":2613}},{\"nodeType\":1,\"id\":2673,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-2-4\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2672},\"parentNode\":{\"id\":2613}},{\"nodeType\":1,\"id\":2674,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-2-5\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2673},\"parentNode\":{\"id\":2613}},{\"nodeType\":1,\"id\":2675,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-2-6\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2674},\"parentNode\":{\"id\":2613}},{\"nodeType\":3,\"id\":2676,\"textContent\":\"What is your major area of study?\",\"parentNode\":{\"id\":2668}},{\"nodeType\":1,\"id\":2677,\"tagName\":\"SPAN\",\"attributes\":{\"class\":\"required\"},\"previousSibling\":{\"id\":2676},\"parentNode\":{\"id\":2668}},{\"nodeType\":1,\"id\":2678,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2669}},{\"nodeType\":1,\"id\":2679,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-2\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2678}},{\"nodeType\":3,\"id\":2680,\"textContent\":\"Math or Computer Sciences\",\"previousSibling\":{\"id\":2679},\"parentNode\":{\"id\":2678}},{\"nodeType\":1,\"id\":2681,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2670}},{\"nodeType\":1,\"id\":2682,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-2\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2681}},{\"nodeType\":3,\"id\":2683,\"textContent\":\"Social Sciences (incl. CogSci)\",\"previousSibling\":{\"id\":2682},\"parentNode\":{\"id\":2681}},{\"nodeType\":1,\"id\":2684,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2671}},{\"nodeType\":1,\"id\":2685,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-2\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2684}},{\"nodeType\":3,\"id\":2686,\"textContent\":\"Biomedical & Health Sciences\",\"previousSibling\":{\"id\":2685},\"parentNode\":{\"id\":2684}},{\"nodeType\":1,\"id\":2687,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2672}},{\"nodeType\":1,\"id\":2688,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-2\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2687}},{\"nodeType\":3,\"id\":2689,\"textContent\":\"Natural Sciences\",\"previousSibling\":{\"id\":2688},\"parentNode\":{\"id\":2687}},{\"nodeType\":1,\"id\":2690,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2673}},{\"nodeType\":1,\"id\":2691,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-2\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2690}},{\"nodeType\":3,\"id\":2692,\"textContent\":\"Engineering\",\"previousSibling\":{\"id\":2691},\"parentNode\":{\"id\":2690}},{\"nodeType\":1,\"id\":2693,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2674}},{\"nodeType\":1,\"id\":2694,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-2\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2693}},{\"nodeType\":3,\"id\":2695,\"textContent\":\"Humanities\",\"previousSibling\":{\"id\":2694},\"parentNode\":{\"id\":2693}},{\"nodeType\":1,\"id\":2696,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2675}},{\"nodeType\":1,\"id\":2697,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-2\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2696}},{\"nodeType\":3,\"id\":2698,\"textContent\":\"Fine Arts\",\"previousSibling\":{\"id\":2697},\"parentNode\":{\"id\":2696}},{\"nodeType\":3,\"id\":2699,\"textContent\":\"*\",\"parentNode\":{\"id\":2677}},{\"nodeType\":1,\"id\":2700,\"tagName\":\"P\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text survey-multi-choice\"},\"parentNode\":{\"id\":2614}},{\"nodeType\":1,\"id\":2701,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-3-0\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2700},\"parentNode\":{\"id\":2614}},{\"nodeType\":1,\"id\":2702,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-3-1\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2701},\"parentNode\":{\"id\":2614}},{\"nodeType\":1,\"id\":2703,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-3-2\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2702},\"parentNode\":{\"id\":2614}},{\"nodeType\":3,\"id\":2704,\"textContent\":\"What is your gender?\",\"parentNode\":{\"id\":2700}},{\"nodeType\":1,\"id\":2705,\"tagName\":\"SPAN\",\"attributes\":{\"class\":\"required\"},\"previousSibling\":{\"id\":2704},\"parentNode\":{\"id\":2700}},{\"nodeType\":1,\"id\":2706,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2701}},{\"nodeType\":1,\"id\":2707,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-3\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2706}},{\"nodeType\":3,\"id\":2708,\"textContent\":\"Male\",\"previousSibling\":{\"id\":2707},\"parentNode\":{\"id\":2706}},{\"nodeType\":1,\"id\":2709,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2702}},{\"nodeType\":1,\"id\":2710,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-3\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2709}},{\"nodeType\":3,\"id\":2711,\"textContent\":\"Female\",\"previousSibling\":{\"id\":2710},\"parentNode\":{\"id\":2709}},{\"nodeType\":1,\"id\":2712,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2703}},{\"nodeType\":1,\"id\":2713,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-3\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2712}},{\"nodeType\":3,\"id\":2714,\"textContent\":\"Other\",\"previousSibling\":{\"id\":2713},\"parentNode\":{\"id\":2712}},{\"nodeType\":3,\"id\":2715,\"textContent\":\"*\",\"parentNode\":{\"id\":2705}}],[],[]]}"
    },
    {
      "sequence": 6,
      "data": "{\"f\":\"applyChanged\",\"args\":[[{\"id\":2609},{\"id\":2610},{\"id\":2611},{\"id\":2616},{\"id\":2621},{\"id\":2622},{\"id\":2635},{\"id\":2617},{\"id\":2623},{\"id\":2624},{\"id\":2625},{\"id\":2618},{\"id\":2626},{\"id\":2627},{\"id\":2628},{\"id\":2619},{\"id\":2629},{\"id\":2630},{\"id\":2631},{\"id\":2620},{\"id\":2632},{\"id\":2633},{\"id\":2634},{\"id\":2612},{\"id\":2636},{\"id\":2644},{\"id\":2645},{\"id\":2667},{\"id\":2637},{\"id\":2646},{\"id\":2647},{\"id\":2648},{\"id\":2638},{\"id\":2649},{\"id\":2650},{\"id\":2651},{\"id\":2639},{\"id\":2652},{\"id\":2653},{\"id\":2654},{\"id\":2640},{\"id\":2655},{\"id\":2656},{\"id\":2657},{\"id\":2641},{\"id\":2658},{\"id\":2659},{\"id\":2660},{\"id\":2642},{\"id\":2661},{\"id\":2662},{\"id\":2663},{\"id\":2643},{\"id\":2664},{\"id\":2665},{\"id\":2666},{\"id\":2613},{\"id\":2668},{\"id\":2676},{\"id\":2677},{\"id\":2699},{\"id\":2669},{\"id\":2678},{\"id\":2679},{\"id\":2680},{\"id\":2670},{\"id\":2681},{\"id\":2682},{\"id\":2683},{\"id\":2671},{\"id\":2684},{\"id\":2685},{\"id\":2686},{\"id\":2672},{\"id\":2687},{\"id\":2688},{\"id\":2689},{\"id\":2673},{\"id\":2690},{\"id\":2691},{\"id\":2692},{\"id\":2674},{\"id\":2693},{\"id\":2694},{\"id\":2695},{\"id\":2675},{\"id\":2696},{\"id\":2697},{\"id\":2698},{\"id\":2614},{\"id\":2700},{\"id\":2704},{\"id\":2705},{\"id\":2715},{\"id\":2701},{\"id\":2706},{\"id\":2707},{\"id\":2708},{\"id\":2702},{\"id\":2709},{\"id\":2710},{\"id\":2711},{\"id\":2703},{\"id\":2712},{\"id\":2713},{\"id\":2714},{\"id\":2615}],[],[],[]]}"
    },
    {
      "sequence": 7,
      "data": "{\"f\":\"applyChanged\",\"args\":[[],[{\"nodeType\":1,\"id\":2716,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"masterdiv\"},\"parentNode\":{\"id\":55}},{\"nodeType\":3,\"id\":2717,\"textContent\":\" \",\"previousSibling\":{\"id\":2716},\"parentNode\":{\"id\":55}},{\"nodeType\":3,\"id\":2718,\"textContent\":\" \",\"parentNode\":{\"id\":2716}},{\"nodeType\":1,\"id\":2719,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"top\"},\"previousSibling\":{\"id\":2718},\"parentNode\":{\"id\":2716}},{\"nodeType\":3,\"id\":2720,\"textContent\":\" \",\"previousSibling\":{\"id\":2719},\"parentNode\":{\"id\":2716}},{\"nodeType\":1,\"id\":2721,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"instructions\"},\"previousSibling\":{\"id\":2720},\"parentNode\":{\"id\":2716}},{\"nodeType\":3,\"id\":2722,\"textContent\":\" \",\"previousSibling\":{\"id\":2721},\"parentNode\":{\"id\":2716}},{\"nodeType\":1,\"id\":2723,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bottom\"},\"previousSibling\":{\"id\":2722},\"parentNode\":{\"id\":2716}},{\"nodeType\":3,\"id\":2724,\"textContent\":\" \",\"previousSibling\":{\"id\":2723},\"parentNode\":{\"id\":2716}},{\"nodeType\":3,\"id\":2725,\"textContent\":\" \",\"parentNode\":{\"id\":2719}},{\"nodeType\":1,\"id\":2726,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bcent\"},\"previousSibling\":{\"id\":2725},\"parentNode\":{\"id\":2719}},{\"nodeType\":3,\"id\":2727,\"textContent\":\" \",\"previousSibling\":{\"id\":2726},\"parentNode\":{\"id\":2719}},{\"nodeType\":3,\"id\":2728,\"textContent\":\" \",\"parentNode\":{\"id\":2726}},{\"nodeType\":1,\"id\":2729,\"tagName\":\"H3\",\"attributes\":{},\"previousSibling\":{\"id\":2728},\"parentNode\":{\"id\":2726}},{\"nodeType\":3,\"id\":2730,\"textContent\":\" \",\"previousSibling\":{\"id\":2729},\"parentNode\":{\"id\":2726}},{\"nodeType\":3,\"id\":2731,\"textContent\":\"DEBRIEFING\",\"parentNode\":{\"id\":2729}},{\"nodeType\":3,\"id\":2732,\"textContent\":\" \",\"parentNode\":{\"id\":2721}},{\"nodeType\":1,\"id\":2733,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"vcent\"},\"previousSibling\":{\"id\":2732},\"parentNode\":{\"id\":2721}},{\"nodeType\":3,\"id\":2734,\"textContent\":\" \",\"previousSibling\":{\"id\":2733},\"parentNode\":{\"id\":2721}},{\"nodeType\":3,\"id\":2735,\"textContent\":\" \",\"parentNode\":{\"id\":2733}},{\"nodeType\":1,\"id\":2736,\"tagName\":\"P\",\"attributes\":{\"style\":\"font-style:italic\"},\"previousSibling\":{\"id\":2735},\"parentNode\":{\"id\":2733}},{\"nodeType\":1,\"id\":2737,\"tagName\":\"P\",\"attributes\":{},\"previousSibling\":{\"id\":2736},\"parentNode\":{\"id\":2733}},{\"nodeType\":3,\"id\":2738,\"textContent\":\" \",\"previousSibling\":{\"id\":2737},\"parentNode\":{\"id\":2733}},{\"nodeType\":1,\"id\":2739,\"tagName\":\"P\",\"attributes\":{},\"previousSibling\":{\"id\":2738},\"parentNode\":{\"id\":2733}},{\"nodeType\":3,\"id\":2740,\"textContent\":\" \",\"previousSibling\":{\"id\":2739},\"parentNode\":{\"id\":2733}},{\"nodeType\":1,\"id\":2741,\"tagName\":\"P\",\"attributes\":{},\"previousSibling\":{\"id\":2740},\"parentNode\":{\"id\":2733}},{\"nodeType\":3,\"id\":2742,\"textContent\":\" \",\"previousSibling\":{\"id\":2741},\"parentNode\":{\"id\":2733}},{\"nodeType\":1,\"id\":2743,\"tagName\":\"P\",\"attributes\":{\"style\":\"font-style:bold;\"},\"previousSibling\":{\"id\":2742},\"parentNode\":{\"id\":2733}},{\"nodeType\":3,\"id\":2744,\"textContent\":\" \",\"previousSibling\":{\"id\":2743},\"parentNode\":{\"id\":2733}},{\"nodeType\":1,\"id\":2745,\"tagName\":\"P\",\"attributes\":{\"style\":\"font-style:italic;\"},\"previousSibling\":{\"id\":2744},\"parentNode\":{\"id\":2733}},{\"nodeType\":3,\"id\":2746,\"textContent\":\" \",\"previousSibling\":{\"id\":2745},\"parentNode\":{\"id\":2733}},{\"nodeType\":3,\"id\":2747,\"textContent\":\"Thank you very much for your participation! This debriefing will tell you more about the study, what you did, and why. \",\"parentNode\":{\"id\":2736}},{\"nodeType\":3,\"id\":2748,\"textContent\":\" \",\"parentNode\":{\"id\":2737}},{\"nodeType\":1,\"id\":2749,\"tagName\":\"B\",\"attributes\":{},\"previousSibling\":{\"id\":2748},\"parentNode\":{\"id\":2737}},{\"nodeType\":3,\"id\":2750,\"textContent\":\" You have just used a series of pictures (charts, graphs and diagrams) accompanied by different types of instructions to answer a series of problem solving questions. While you were using the pictures, we measured where you clicked, scrolled and pointed with the computer mouse. We also measured the accuracy of your responses and the time it took to complete each question.\",\"previousSibling\":{\"id\":2749},\"parentNode\":{\"id\":2737}},{\"nodeType\":3,\"id\":2751,\"textContent\":\"What did you just do?\",\"parentNode\":{\"id\":2749}},{\"nodeType\":3,\"id\":2752,\"textContent\":\" \",\"parentNode\":{\"id\":2739}},{\"nodeType\":1,\"id\":2753,\"tagName\":\"B\",\"attributes\":{},\"previousSibling\":{\"id\":2752},\"parentNode\":{\"id\":2739}},{\"nodeType\":3,\"id\":2754,\"textContent\":\" Researchers of learning and cognition have long been interested in how graphic displays of information can be used to communicate, solve problems, and generate insights. As powerful as graphics may be in their communicative efficiency, they're not always immediately intuitive to understand. In short, we know a great deal more about learning with representations than we do about the learning of representations. In this project we are building upon previous research on reading and graph comprehension to explore how readers make sense of unfamiliar representations. The instructions you saw for each type of graph are known as “scaffolding techniques”, and we will compare your performance with the scaffolding techniques you saw with the performance of other participants to determine which types of instructions are most effective in helping humans to make sense of unfamiliar graphs. \",\"previousSibling\":{\"id\":2753},\"parentNode\":{\"id\":2739}},{\"nodeType\":3,\"id\":2755,\"textContent\":\"Why did we have you do it?\",\"parentNode\":{\"id\":2753}},{\"nodeType\":1,\"id\":2756,\"tagName\":\"B\",\"attributes\":{},\"parentNode\":{\"id\":2741}},{\"nodeType\":3,\"id\":2757,\"textContent\":\" We expect that you will have found some of the graphics more difficult to use than others. We also expect that with the assistance of the instructions, after solving several problems you will learn to use the difficult graphics so that you can answer the questions even more quickly than without. If you would like to receive a copy of the results of the study, or have any further questions, please contact the researchers Primary Researcher: Amy Fox : a2fox@ucsd.edu Faculty Advisor : Dr. Jim Hollan : hollan@ucsd.edu \",\"previousSibling\":{\"id\":2756},\"parentNode\":{\"id\":2741}},{\"nodeType\":3,\"id\":2758,\"textContent\":\"What do we expect to find?\",\"parentNode\":{\"id\":2756}},{\"nodeType\":3,\"id\":2759,\"textContent\":\"It is important that you do not discuss this experiment with other students who might participate after you. They must participate in the same way as you did, without any knowledge of what the experiment entails, or the reasoning behind it.\",\"parentNode\":{\"id\":2743}},{\"nodeType\":3,\"id\":2760,\"textContent\":\"Thank you for your time! We hope you enjoyed participating in this study as much as we enjoyed designing it.\",\"parentNode\":{\"id\":2745}},{\"nodeType\":3,\"id\":2761,\"textContent\":\" \",\"parentNode\":{\"id\":2723}},{\"nodeType\":1,\"id\":2762,\"tagName\":\"BUTTON\",\"attributes\":{\"class\":\"btn\",\"type\":\"button\",\"id\":\"start\"},\"previousSibling\":{\"id\":2761},\"parentNode\":{\"id\":2723}},{\"nodeType\":3,\"id\":2763,\"textContent\":\" \",\"previousSibling\":{\"id\":2762},\"parentNode\":{\"id\":2723}},{\"nodeType\":3,\"id\":2764,\"textContent\":\"FINISH\",\"parentNode\":{\"id\":2762}}],[],[]]}"
    },
    {
      "sequence": 8,
      "data": "{\"f\":\"applyChanged\",\"args\":[[{\"id\":2716},{\"id\":2718},{\"id\":2719},{\"id\":2725},{\"id\":2726},{\"id\":2728},{\"id\":2729},{\"id\":2731},{\"id\":2730},{\"id\":2727},{\"id\":2720},{\"id\":2721},{\"id\":2732},{\"id\":2733},{\"id\":2735},{\"id\":2736},{\"id\":2747},{\"id\":2737},{\"id\":2748},{\"id\":2749},{\"id\":2751},{\"id\":2750},{\"id\":2738},{\"id\":2739},{\"id\":2752},{\"id\":2753},{\"id\":2755},{\"id\":2754},{\"id\":2740},{\"id\":2741},{\"id\":2756},{\"id\":2758},{\"id\":2757},{\"id\":2742},{\"id\":2743},{\"id\":2759},{\"id\":2744},{\"id\":2745},{\"id\":2760},{\"id\":2746},{\"id\":2734},{\"id\":2722},{\"id\":2723},{\"id\":2761},{\"id\":2762},{\"id\":2764},{\"id\":2763},{\"id\":2724},{\"id\":2717}],[],[],[]]}"
    },
    {
      "sequence": 9,
      "data": "{\"f\":\"applyChanged\",\"args\":[[],[{\"nodeType\":1,\"id\":2765,\"tagName\":\"PRE\",\"attributes\":{\"id\":\"jspsych-data-display\"},\"parentNode\":{\"id\":55}},{\"nodeType\":3,\"id\":2766,\"textContent\":\"[ { \\\"rt\\\": 27638, \\\"stimulus\\\": \\\"img/phone.png\\\", \\\"key_press\\\": 13, \\\"block\\\": \\\"phone\\\", \\\"trial_type\\\": \\\"single-stim\\\", \\\"trial_index\\\": 0, \\\"time_elapsed\\\": 27641, \\\"internal_node_id\\\": \\\"0.0-0.0\\\", \\\"subject\\\": \\\"TGOML\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"oscar\\\", \\\"condition\\\": \\\"114\\\" }, { \\\"rt\\\": 9829, \\\"url\\\": \\\"../views/src/external/consent.html\\\", \\\"block\\\": \\\"consent\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 1, \\\"time_elapsed\\\": 38559, \\\"internal_node_id\\\": \\\"0.0-1.0\\\", \\\"subject\\\": \\\"TGOML\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"oscar\\\", \\\"condition\\\": \\\"114\\\" }, { \\\"rt\\\": 14795, \\\"responses\\\": \\\"{\\\\\\\"Q0\\\\\\\":\\\\\\\"Oscar\\\\\\\",\\\\\\\"Q1\\\\\\\":\\\\\\\"114\\\\\\\"}\\\", \\\"block\\\": \\\"codes\\\", \\\"trial_type\\\": \\\"survey-text\\\", \\\"trial_index\\\": 2, \\\"time_elapsed\\\": 54358, \\\"internal_node_id\\\": \\\"0.0-2.0\\\", \\\"subject\\\": \\\"TGOML\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"oscar\\\", \\\"condition\\\": \\\"114\\\" }, { \\\"rt\\\": 11241, \\\"url\\\": \\\"../views/src/external/instructions_lab.html\\\", \\\"block\\\": \\\"instructions_lab\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 3, \\\"time_elapsed\\\": 66683, \\\"internal_node_id\\\": \\\"0.0-3.0\\\", \\\"subject\\\": \\\"TGOML\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"oscar\\\", \\\"condition\\\": \\\"114\\\" }, { \\\"rt\\\": 9350, \\\"stimulus\\\": \\\"img/acme.png\\\", \\\"key_press\\\": 13, \\\"block\\\": \\\"scenario\\\", \\\"trial_type\\\": \\\"single-stim\\\", \\\"trial_index\\\": 4, \\\"time_elapsed\\\": 77037, \\\"internal_node_id\\\": \\\"0.0-4.0\\\", \\\"subject\\\": \\\"TGOML\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"oscar\\\", \\\"condition\\\": \\\"114\\\" }, { \\\"rt\\\": 39809, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 5, \\\"time_elapsed\\\": 118053, \\\"internal_node_id\\\": \\\"0.0-5.0-0.0\\\", \\\"subject\\\": \\\"TGOML\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"oscar\\\", \\\"condition\\\": \\\"114\\\", \\\"scenario\\\": \\\"acme\\\", \\\"question\\\": \\\"starttime\\\", \\\"q\\\": 1, \\\"clicks\\\": 1.5, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XInside-YInside\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 1, \\\"answer\\\": [ \\\"A\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"X \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"U \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-10 AM-11 AM-10 AM-09 AM\\\", \\\"block\\\": \\\"triangular_scaffolded\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:959,y:1023,t:1527613751145};\\\", \\\"{x:969,y:1023,t:1527613751153};\\\", \\\"{x:994,y:1022,t:1527613751170};\\\", \\\"{x:1019,y:1016,t:1527613751186};\\\", \\\"{x:1030,y:1016,t:1527613751204};\\\", \\\"{x:1036,y:1015,t:1527613751220};\\\", \\\"{x:1039,y:1015,t:1527613751236};\\\", \\\"{x:1040,y:1015,t:1527613751254};\\\", \\\"{x:1042,y:1015,t:1527613751271};\\\", \\\"{x:1045,y:1015,t:1527613751287};\\\", \\\"{x:1051,y:1015,t:1527613751304};\\\", \\\"{x:1060,y:1015,t:1527613751320};\\\", \\\"{x:1070,y:1015,t:1527613751336};\\\", \\\"{x:1086,y:1015,t:1527613751353};\\\", \\\"{x:1093,y:1015,t:1527613751371};\\\", \\\"{x:1098,y:1015,t:1527613751386};\\\", \\\"{x:1100,y:1015,t:1527613751403};\\\", \\\"{x:1102,y:1015,t:1527613751421};\\\", \\\"{x:1104,y:1015,t:1527613751437};\\\", \\\"{x:1108,y:1015,t:1527613751454};\\\", \\\"{x:1115,y:1014,t:1527613751471};\\\", \\\"{x:1119,y:1013,t:1527613751487};\\\", \\\"{x:1125,y:1012,t:1527613751503};\\\", \\\"{x:1131,y:1011,t:1527613751521};\\\", \\\"{x:1138,y:1009,t:1527613751537};\\\", \\\"{x:1151,y:1008,t:1527613751554};\\\", \\\"{x:1165,y:1006,t:1527613751571};\\\", \\\"{x:1185,y:1001,t:1527613751587};\\\", \\\"{x:1202,y:997,t:1527613751604};\\\", \\\"{x:1217,y:993,t:1527613751621};\\\", \\\"{x:1223,y:991,t:1527613751638};\\\", \\\"{x:1224,y:991,t:1527613752234};\\\", \\\"{x:1224,y:990,t:1527613752241};\\\", \\\"{x:1220,y:987,t:1527613752254};\\\", \\\"{x:1214,y:985,t:1527613752270};\\\", \\\"{x:1207,y:983,t:1527613752288};\\\", \\\"{x:1205,y:981,t:1527613752305};\\\", \\\"{x:1204,y:981,t:1527613752320};\\\", \\\"{x:1200,y:980,t:1527613752337};\\\", \\\"{x:1202,y:978,t:1527613752450};\\\", \\\"{x:1208,y:976,t:1527613752458};\\\", \\\"{x:1212,y:974,t:1527613752471};\\\", \\\"{x:1223,y:971,t:1527613752488};\\\", \\\"{x:1228,y:971,t:1527613752504};\\\", \\\"{x:1232,y:971,t:1527613752521};\\\", \\\"{x:1233,y:971,t:1527613752537};\\\", \\\"{x:1234,y:971,t:1527613752555};\\\", \\\"{x:1236,y:971,t:1527613752573};\\\", \\\"{x:1238,y:971,t:1527613752588};\\\", \\\"{x:1241,y:971,t:1527613752605};\\\", \\\"{x:1247,y:971,t:1527613752622};\\\", \\\"{x:1253,y:971,t:1527613752638};\\\", \\\"{x:1265,y:969,t:1527613752655};\\\", \\\"{x:1270,y:968,t:1527613752673};\\\", \\\"{x:1273,y:968,t:1527613752688};\\\", \\\"{x:1274,y:968,t:1527613752705};\\\", \\\"{x:1274,y:966,t:1527613753241};\\\", \\\"{x:1275,y:965,t:1527613753265};\\\", \\\"{x:1275,y:964,t:1527613753290};\\\", \\\"{x:1277,y:964,t:1527613753321};\\\", \\\"{x:1277,y:963,t:1527613753346};\\\", \\\"{x:1278,y:963,t:1527613753370};\\\", \\\"{x:1278,y:962,t:1527613753386};\\\", \\\"{x:1279,y:962,t:1527613753474};\\\", \\\"{x:1280,y:961,t:1527613753489};\\\", \\\"{x:1274,y:961,t:1527613759979};\\\", \\\"{x:1247,y:965,t:1527613759995};\\\", \\\"{x:1222,y:968,t:1527613760011};\\\", \\\"{x:1196,y:971,t:1527613760028};\\\", \\\"{x:1168,y:975,t:1527613760044};\\\", \\\"{x:1143,y:979,t:1527613760061};\\\", \\\"{x:1114,y:983,t:1527613760078};\\\", \\\"{x:1079,y:987,t:1527613760094};\\\", \\\"{x:1049,y:987,t:1527613760112};\\\", \\\"{x:1020,y:987,t:1527613760127};\\\", \\\"{x:991,y:987,t:1527613760145};\\\", \\\"{x:951,y:987,t:1527613760162};\\\", \\\"{x:934,y:986,t:1527613760177};\\\", \\\"{x:881,y:978,t:1527613760195};\\\", \\\"{x:862,y:975,t:1527613760212};\\\", \\\"{x:846,y:972,t:1527613760227};\\\", \\\"{x:834,y:967,t:1527613760244};\\\", \\\"{x:826,y:962,t:1527613760261};\\\", \\\"{x:822,y:960,t:1527613760278};\\\", \\\"{x:816,y:955,t:1527613760294};\\\", \\\"{x:805,y:947,t:1527613760311};\\\", \\\"{x:787,y:938,t:1527613760328};\\\", \\\"{x:762,y:929,t:1527613760344};\\\", \\\"{x:680,y:916,t:1527613760360};\\\", \\\"{x:621,y:912,t:1527613760377};\\\", \\\"{x:570,y:912,t:1527613760394};\\\", \\\"{x:520,y:906,t:1527613760411};\\\", \\\"{x:476,y:896,t:1527613760428};\\\", \\\"{x:439,y:884,t:1527613760444};\\\", \\\"{x:417,y:869,t:1527613760461};\\\", \\\"{x:414,y:852,t:1527613760478};\\\", \\\"{x:414,y:815,t:1527613760494};\\\", \\\"{x:414,y:767,t:1527613760511};\\\", \\\"{x:414,y:725,t:1527613760527};\\\", \\\"{x:414,y:702,t:1527613760543};\\\", \\\"{x:421,y:680,t:1527613760560};\\\", \\\"{x:428,y:666,t:1527613760577};\\\", \\\"{x:430,y:655,t:1527613760594};\\\", \\\"{x:432,y:647,t:1527613760611};\\\", \\\"{x:432,y:639,t:1527613760628};\\\", \\\"{x:432,y:635,t:1527613760643};\\\", \\\"{x:430,y:631,t:1527613760661};\\\", \\\"{x:427,y:628,t:1527613760678};\\\", \\\"{x:426,y:627,t:1527613760694};\\\", \\\"{x:419,y:623,t:1527613760710};\\\", \\\"{x:412,y:620,t:1527613760727};\\\", \\\"{x:389,y:615,t:1527613760746};\\\", \\\"{x:370,y:613,t:1527613760761};\\\", \\\"{x:354,y:610,t:1527613760778};\\\", \\\"{x:333,y:604,t:1527613760795};\\\", \\\"{x:311,y:598,t:1527613760812};\\\", \\\"{x:292,y:592,t:1527613760828};\\\", \\\"{x:273,y:588,t:1527613760845};\\\", \\\"{x:257,y:587,t:1527613760863};\\\", \\\"{x:251,y:586,t:1527613760877};\\\", \\\"{x:247,y:586,t:1527613760894};\\\", \\\"{x:245,y:586,t:1527613760911};\\\", \\\"{x:245,y:585,t:1527613760927};\\\", \\\"{x:244,y:583,t:1527613760962};\\\", \\\"{x:248,y:576,t:1527613760980};\\\", \\\"{x:263,y:565,t:1527613760995};\\\", \\\"{x:282,y:554,t:1527613761012};\\\", \\\"{x:298,y:546,t:1527613761028};\\\", \\\"{x:310,y:540,t:1527613761045};\\\", \\\"{x:313,y:538,t:1527613761061};\\\", \\\"{x:316,y:537,t:1527613761077};\\\", \\\"{x:319,y:537,t:1527613761095};\\\", \\\"{x:321,y:535,t:1527613761112};\\\", \\\"{x:323,y:535,t:1527613761127};\\\", \\\"{x:330,y:533,t:1527613761145};\\\", \\\"{x:335,y:531,t:1527613761161};\\\", \\\"{x:337,y:531,t:1527613761179};\\\", \\\"{x:338,y:530,t:1527613761241};\\\", \\\"{x:339,y:530,t:1527613761249};\\\", \\\"{x:340,y:530,t:1527613761262};\\\", \\\"{x:344,y:528,t:1527613761279};\\\", \\\"{x:348,y:527,t:1527613761295};\\\", \\\"{x:349,y:527,t:1527613761312};\\\", \\\"{x:352,y:526,t:1527613761329};\\\", \\\"{x:355,y:526,t:1527613761345};\\\", \\\"{x:356,y:525,t:1527613761362};\\\", \\\"{x:358,y:524,t:1527613761379};\\\", \\\"{x:360,y:524,t:1527613761395};\\\", \\\"{x:363,y:522,t:1527613761412};\\\", \\\"{x:364,y:521,t:1527613761554};\\\", \\\"{x:365,y:520,t:1527613761594};\\\", \\\"{x:368,y:520,t:1527613762162};\\\", \\\"{x:380,y:531,t:1527613762180};\\\", \\\"{x:393,y:550,t:1527613762196};\\\", \\\"{x:409,y:568,t:1527613762213};\\\", \\\"{x:424,y:585,t:1527613762229};\\\", \\\"{x:436,y:600,t:1527613762246};\\\", \\\"{x:448,y:611,t:1527613762263};\\\", \\\"{x:459,y:623,t:1527613762280};\\\", \\\"{x:470,y:631,t:1527613762296};\\\", \\\"{x:486,y:640,t:1527613762313};\\\", \\\"{x:487,y:640,t:1527613762329};\\\", \\\"{x:488,y:640,t:1527613762346};\\\", \\\"{x:488,y:633,t:1527613762393};\\\", \\\"{x:482,y:625,t:1527613762401};\\\", \\\"{x:472,y:615,t:1527613762413};\\\", \\\"{x:427,y:591,t:1527613762430};\\\", \\\"{x:364,y:565,t:1527613762447};\\\", \\\"{x:304,y:543,t:1527613762463};\\\", \\\"{x:273,y:529,t:1527613762480};\\\", \\\"{x:263,y:522,t:1527613762497};\\\", \\\"{x:262,y:518,t:1527613762512};\\\", \\\"{x:262,y:514,t:1527613762529};\\\", \\\"{x:268,y:510,t:1527613762546};\\\", \\\"{x:276,y:506,t:1527613762564};\\\", \\\"{x:281,y:503,t:1527613762580};\\\", \\\"{x:284,y:501,t:1527613762596};\\\", \\\"{x:288,y:501,t:1527613762612};\\\", \\\"{x:296,y:498,t:1527613762629};\\\", \\\"{x:306,y:497,t:1527613762646};\\\", \\\"{x:323,y:494,t:1527613762662};\\\", \\\"{x:334,y:493,t:1527613762679};\\\", \\\"{x:339,y:492,t:1527613762696};\\\", \\\"{x:342,y:491,t:1527613762713};\\\", \\\"{x:343,y:491,t:1527613762770};\\\", \\\"{x:344,y:491,t:1527613762779};\\\", \\\"{x:345,y:492,t:1527613762796};\\\", \\\"{x:347,y:495,t:1527613762812};\\\", \\\"{x:349,y:497,t:1527613762829};\\\", \\\"{x:353,y:501,t:1527613762847};\\\", \\\"{x:358,y:504,t:1527613762862};\\\", \\\"{x:362,y:512,t:1527613762881};\\\", \\\"{x:366,y:517,t:1527613762896};\\\", \\\"{x:371,y:523,t:1527613762912};\\\", \\\"{x:372,y:525,t:1527613762929};\\\", \\\"{x:373,y:526,t:1527613762946};\\\", \\\"{x:374,y:527,t:1527613763003};\\\", \\\"{x:374,y:525,t:1527613763097};\\\", \\\"{x:374,y:524,t:1527613763121};\\\", \\\"{x:374,y:523,t:1527613763242};\\\", \\\"{x:371,y:526,t:1527613764689};\\\", \\\"{x:364,y:534,t:1527613764698};\\\", \\\"{x:355,y:545,t:1527613764715};\\\", \\\"{x:349,y:556,t:1527613764731};\\\", \\\"{x:345,y:569,t:1527613764748};\\\", \\\"{x:345,y:576,t:1527613764765};\\\", \\\"{x:345,y:583,t:1527613764781};\\\", \\\"{x:346,y:597,t:1527613764798};\\\", \\\"{x:359,y:620,t:1527613764815};\\\", \\\"{x:384,y:650,t:1527613764830};\\\", \\\"{x:422,y:680,t:1527613764848};\\\", \\\"{x:476,y:718,t:1527613764865};\\\", \\\"{x:514,y:742,t:1527613764882};\\\", \\\"{x:557,y:765,t:1527613764898};\\\", \\\"{x:601,y:789,t:1527613764915};\\\", \\\"{x:634,y:810,t:1527613764930};\\\", \\\"{x:655,y:826,t:1527613764948};\\\", \\\"{x:668,y:834,t:1527613764965};\\\", \\\"{x:669,y:837,t:1527613764981};\\\", \\\"{x:670,y:837,t:1527613776882};\\\", \\\"{x:670,y:835,t:1527613776890};\\\", \\\"{x:670,y:832,t:1527613776902};\\\", \\\"{x:670,y:826,t:1527613776920};\\\", \\\"{x:668,y:821,t:1527613776937};\\\", \\\"{x:667,y:818,t:1527613776953};\\\", \\\"{x:666,y:813,t:1527613776969};\\\", \\\"{x:663,y:808,t:1527613776987};\\\", \\\"{x:652,y:797,t:1527613777003};\\\", \\\"{x:636,y:788,t:1527613777019};\\\", \\\"{x:615,y:778,t:1527613777036};\\\", \\\"{x:592,y:769,t:1527613777053};\\\", \\\"{x:568,y:761,t:1527613777070};\\\", \\\"{x:544,y:752,t:1527613777086};\\\", \\\"{x:526,y:749,t:1527613777102};\\\", \\\"{x:510,y:743,t:1527613777120};\\\", \\\"{x:502,y:740,t:1527613777136};\\\", \\\"{x:500,y:738,t:1527613777153};\\\", \\\"{x:495,y:736,t:1527613777169};\\\", \\\"{x:495,y:735,t:1527613777187};\\\", \\\"{x:495,y:734,t:1527613777242};\\\", \\\"{x:495,y:732,t:1527613777259};\\\", \\\"{x:495,y:730,t:1527613777275};\\\", \\\"{x:495,y:727,t:1527613777291};\\\", \\\"{x:496,y:724,t:1527613777308};\\\", \\\"{x:499,y:722,t:1527613777325};\\\", \\\"{x:500,y:721,t:1527613777342};\\\", \\\"{x:501,y:721,t:1527613777384};\\\" ] }, { \\\"rt\\\": 15064, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 6, \\\"time_elapsed\\\": 134374, \\\"internal_node_id\\\": \\\"0.0-5.0-1.0\\\", \\\"subject\\\": \\\"TGOML\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"oscar\\\", \\\"condition\\\": \\\"114\\\", \\\"scenario\\\": \\\"acme\\\", \\\"question\\\": \\\"starts\\\", \\\"q\\\": 2, \\\"clicks\\\": 1, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XInside-YInside\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 1, \\\"answer\\\": [ \\\"E\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"X \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"U \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-D \\\", \\\"block\\\": \\\"triangular_scaffolded\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:502,y:719,t:1527613797021};\\\", \\\"{x:504,y:716,t:1527613797038};\\\", \\\"{x:505,y:713,t:1527613797044};\\\", \\\"{x:509,y:705,t:1527613797060};\\\", \\\"{x:510,y:698,t:1527613797078};\\\", \\\"{x:511,y:693,t:1527613797093};\\\", \\\"{x:513,y:688,t:1527613797109};\\\", \\\"{x:515,y:684,t:1527613797126};\\\", \\\"{x:515,y:682,t:1527613797142};\\\", \\\"{x:516,y:682,t:1527613797159};\\\", \\\"{x:516,y:681,t:1527613797292};\\\", \\\"{x:519,y:678,t:1527613797309};\\\", \\\"{x:527,y:674,t:1527613797326};\\\", \\\"{x:534,y:670,t:1527613797342};\\\", \\\"{x:547,y:659,t:1527613797359};\\\", \\\"{x:569,y:645,t:1527613797377};\\\", \\\"{x:597,y:622,t:1527613797392};\\\", \\\"{x:701,y:569,t:1527613797414};\\\", \\\"{x:814,y:539,t:1527613797429};\\\", \\\"{x:927,y:505,t:1527613797446};\\\", \\\"{x:1011,y:481,t:1527613797463};\\\", \\\"{x:1057,y:464,t:1527613797479};\\\", \\\"{x:1078,y:453,t:1527613797496};\\\", \\\"{x:1089,y:443,t:1527613797512};\\\", \\\"{x:1097,y:437,t:1527613797529};\\\", \\\"{x:1103,y:427,t:1527613797546};\\\", \\\"{x:1108,y:418,t:1527613797562};\\\", \\\"{x:1116,y:406,t:1527613797579};\\\", \\\"{x:1142,y:386,t:1527613797597};\\\", \\\"{x:1167,y:377,t:1527613797612};\\\", \\\"{x:1205,y:375,t:1527613797629};\\\", \\\"{x:1271,y:375,t:1527613797646};\\\", \\\"{x:1338,y:375,t:1527613797662};\\\", \\\"{x:1391,y:368,t:1527613797679};\\\", \\\"{x:1424,y:360,t:1527613797696};\\\", \\\"{x:1457,y:347,t:1527613797712};\\\", \\\"{x:1484,y:340,t:1527613797729};\\\", \\\"{x:1509,y:335,t:1527613797747};\\\", \\\"{x:1532,y:330,t:1527613797762};\\\", \\\"{x:1542,y:330,t:1527613797780};\\\", \\\"{x:1545,y:330,t:1527613797796};\\\", \\\"{x:1550,y:332,t:1527613797813};\\\", \\\"{x:1557,y:338,t:1527613797830};\\\", \\\"{x:1566,y:342,t:1527613797846};\\\", \\\"{x:1571,y:346,t:1527613797863};\\\", \\\"{x:1577,y:353,t:1527613797880};\\\", \\\"{x:1581,y:357,t:1527613797896};\\\", \\\"{x:1589,y:368,t:1527613797913};\\\", \\\"{x:1596,y:378,t:1527613797930};\\\", \\\"{x:1604,y:386,t:1527613797947};\\\", \\\"{x:1605,y:389,t:1527613797963};\\\", \\\"{x:1607,y:394,t:1527613797980};\\\", \\\"{x:1612,y:414,t:1527613797997};\\\", \\\"{x:1620,y:433,t:1527613798014};\\\", \\\"{x:1631,y:456,t:1527613798029};\\\", \\\"{x:1646,y:474,t:1527613798047};\\\", \\\"{x:1656,y:487,t:1527613798063};\\\", \\\"{x:1661,y:495,t:1527613798079};\\\", \\\"{x:1662,y:499,t:1527613798097};\\\", \\\"{x:1662,y:502,t:1527613798113};\\\", \\\"{x:1662,y:508,t:1527613798130};\\\", \\\"{x:1662,y:514,t:1527613798146};\\\", \\\"{x:1660,y:521,t:1527613798164};\\\", \\\"{x:1659,y:533,t:1527613798181};\\\", \\\"{x:1657,y:542,t:1527613798197};\\\", \\\"{x:1657,y:550,t:1527613798213};\\\", \\\"{x:1657,y:559,t:1527613798230};\\\", \\\"{x:1657,y:569,t:1527613798247};\\\", \\\"{x:1657,y:577,t:1527613798264};\\\", \\\"{x:1656,y:585,t:1527613798280};\\\", \\\"{x:1656,y:590,t:1527613798297};\\\", \\\"{x:1656,y:594,t:1527613798314};\\\", \\\"{x:1656,y:598,t:1527613798331};\\\", \\\"{x:1656,y:601,t:1527613798347};\\\", \\\"{x:1656,y:607,t:1527613798363};\\\", \\\"{x:1652,y:618,t:1527613798381};\\\", \\\"{x:1651,y:625,t:1527613798397};\\\", \\\"{x:1649,y:632,t:1527613798414};\\\", \\\"{x:1648,y:638,t:1527613798431};\\\", \\\"{x:1647,y:645,t:1527613798446};\\\", \\\"{x:1646,y:654,t:1527613798463};\\\", \\\"{x:1643,y:664,t:1527613798481};\\\", \\\"{x:1639,y:672,t:1527613798497};\\\", \\\"{x:1638,y:679,t:1527613798514};\\\", \\\"{x:1635,y:684,t:1527613798530};\\\", \\\"{x:1633,y:689,t:1527613798547};\\\", \\\"{x:1632,y:693,t:1527613798563};\\\", \\\"{x:1630,y:700,t:1527613798580};\\\", \\\"{x:1629,y:705,t:1527613798597};\\\", \\\"{x:1628,y:711,t:1527613798613};\\\", \\\"{x:1627,y:715,t:1527613798630};\\\", \\\"{x:1625,y:723,t:1527613798647};\\\", \\\"{x:1625,y:731,t:1527613798663};\\\", \\\"{x:1625,y:739,t:1527613798680};\\\", \\\"{x:1625,y:747,t:1527613798697};\\\", \\\"{x:1623,y:754,t:1527613798713};\\\", \\\"{x:1623,y:764,t:1527613798731};\\\", \\\"{x:1621,y:793,t:1527613798748};\\\", \\\"{x:1620,y:807,t:1527613798764};\\\", \\\"{x:1620,y:841,t:1527613798781};\\\", \\\"{x:1620,y:857,t:1527613798797};\\\", \\\"{x:1620,y:873,t:1527613798813};\\\", \\\"{x:1620,y:881,t:1527613798830};\\\", \\\"{x:1618,y:886,t:1527613798847};\\\", \\\"{x:1616,y:893,t:1527613798865};\\\", \\\"{x:1612,y:903,t:1527613798880};\\\", \\\"{x:1610,y:910,t:1527613798897};\\\", \\\"{x:1607,y:917,t:1527613798914};\\\", \\\"{x:1600,y:925,t:1527613798930};\\\", \\\"{x:1580,y:935,t:1527613798948};\\\", \\\"{x:1556,y:942,t:1527613798964};\\\", \\\"{x:1529,y:946,t:1527613798980};\\\", \\\"{x:1482,y:945,t:1527613798997};\\\", \\\"{x:1437,y:937,t:1527613799014};\\\", \\\"{x:1401,y:934,t:1527613799031};\\\", \\\"{x:1372,y:929,t:1527613799048};\\\", \\\"{x:1337,y:925,t:1527613799064};\\\", \\\"{x:1292,y:918,t:1527613799081};\\\", \\\"{x:1232,y:904,t:1527613799098};\\\", \\\"{x:1174,y:889,t:1527613799114};\\\", \\\"{x:1127,y:877,t:1527613799130};\\\", \\\"{x:1066,y:861,t:1527613799148};\\\", \\\"{x:1021,y:848,t:1527613799164};\\\", \\\"{x:963,y:831,t:1527613799181};\\\", \\\"{x:890,y:808,t:1527613799197};\\\", \\\"{x:829,y:782,t:1527613799214};\\\", \\\"{x:779,y:757,t:1527613799232};\\\", \\\"{x:736,y:732,t:1527613799247};\\\", \\\"{x:694,y:706,t:1527613799265};\\\", \\\"{x:664,y:688,t:1527613799281};\\\", \\\"{x:638,y:674,t:1527613799297};\\\", \\\"{x:625,y:665,t:1527613799315};\\\", \\\"{x:617,y:658,t:1527613799332};\\\", \\\"{x:608,y:647,t:1527613799350};\\\", \\\"{x:600,y:634,t:1527613799365};\\\", \\\"{x:595,y:632,t:1527613799381};\\\", \\\"{x:593,y:631,t:1527613799396};\\\", \\\"{x:592,y:631,t:1527613799413};\\\", \\\"{x:589,y:631,t:1527613799429};\\\", \\\"{x:586,y:631,t:1527613799447};\\\", \\\"{x:579,y:628,t:1527613799464};\\\", \\\"{x:572,y:627,t:1527613799480};\\\", \\\"{x:567,y:626,t:1527613799497};\\\", \\\"{x:559,y:623,t:1527613799514};\\\", \\\"{x:536,y:619,t:1527613799530};\\\", \\\"{x:501,y:615,t:1527613799547};\\\", \\\"{x:462,y:606,t:1527613799564};\\\", \\\"{x:451,y:605,t:1527613799582};\\\", \\\"{x:448,y:604,t:1527613799597};\\\", \\\"{x:450,y:602,t:1527613799717};\\\", \\\"{x:452,y:601,t:1527613799731};\\\", \\\"{x:456,y:596,t:1527613799748};\\\", \\\"{x:456,y:595,t:1527613799764};\\\", \\\"{x:456,y:593,t:1527613799781};\\\", \\\"{x:456,y:592,t:1527613799813};\\\", \\\"{x:455,y:592,t:1527613799837};\\\", \\\"{x:452,y:592,t:1527613799848};\\\", \\\"{x:443,y:591,t:1527613799865};\\\", \\\"{x:435,y:591,t:1527613799882};\\\", \\\"{x:430,y:591,t:1527613799898};\\\", \\\"{x:427,y:591,t:1527613799914};\\\", \\\"{x:423,y:591,t:1527613799932};\\\", \\\"{x:421,y:591,t:1527613799950};\\\", \\\"{x:419,y:592,t:1527613799981};\\\", \\\"{x:420,y:593,t:1527613800012};\\\", \\\"{x:423,y:593,t:1527613800020};\\\", \\\"{x:426,y:593,t:1527613800031};\\\", \\\"{x:436,y:595,t:1527613800049};\\\", \\\"{x:452,y:595,t:1527613800064};\\\", \\\"{x:474,y:595,t:1527613800081};\\\", \\\"{x:497,y:595,t:1527613800099};\\\", \\\"{x:524,y:595,t:1527613800117};\\\", \\\"{x:553,y:595,t:1527613800131};\\\", \\\"{x:574,y:595,t:1527613800147};\\\", \\\"{x:576,y:594,t:1527613800164};\\\", \\\"{x:572,y:593,t:1527613800220};\\\", \\\"{x:567,y:591,t:1527613800231};\\\", \\\"{x:551,y:585,t:1527613800248};\\\", \\\"{x:524,y:583,t:1527613800264};\\\", \\\"{x:486,y:579,t:1527613800282};\\\", \\\"{x:431,y:572,t:1527613800299};\\\", \\\"{x:355,y:570,t:1527613800314};\\\", \\\"{x:273,y:563,t:1527613800331};\\\", \\\"{x:163,y:557,t:1527613800349};\\\", \\\"{x:110,y:557,t:1527613800364};\\\", \\\"{x:74,y:557,t:1527613800381};\\\", \\\"{x:55,y:557,t:1527613800398};\\\", \\\"{x:50,y:559,t:1527613800415};\\\", \\\"{x:49,y:560,t:1527613800436};\\\", \\\"{x:49,y:562,t:1527613800448};\\\", \\\"{x:49,y:565,t:1527613800466};\\\", \\\"{x:49,y:572,t:1527613800481};\\\", \\\"{x:54,y:584,t:1527613800499};\\\", \\\"{x:63,y:602,t:1527613800515};\\\", \\\"{x:74,y:615,t:1527613800531};\\\", \\\"{x:93,y:631,t:1527613800548};\\\", \\\"{x:110,y:640,t:1527613800565};\\\", \\\"{x:129,y:649,t:1527613800581};\\\", \\\"{x:140,y:650,t:1527613800598};\\\", \\\"{x:143,y:653,t:1527613800616};\\\", \\\"{x:144,y:653,t:1527613800631};\\\", \\\"{x:146,y:653,t:1527613800733};\\\", \\\"{x:146,y:650,t:1527613800749};\\\", \\\"{x:149,y:646,t:1527613800766};\\\", \\\"{x:150,y:642,t:1527613800781};\\\", \\\"{x:150,y:639,t:1527613800798};\\\", \\\"{x:151,y:638,t:1527613800815};\\\", \\\"{x:152,y:638,t:1527613801132};\\\", \\\"{x:167,y:637,t:1527613801148};\\\", \\\"{x:196,y:637,t:1527613801166};\\\", \\\"{x:249,y:637,t:1527613801182};\\\", \\\"{x:307,y:637,t:1527613801200};\\\", \\\"{x:362,y:640,t:1527613801216};\\\", \\\"{x:400,y:648,t:1527613801232};\\\", \\\"{x:428,y:653,t:1527613801249};\\\", \\\"{x:445,y:655,t:1527613801265};\\\", \\\"{x:451,y:656,t:1527613801282};\\\", \\\"{x:451,y:657,t:1527613801429};\\\", \\\"{x:451,y:659,t:1527613801437};\\\", \\\"{x:451,y:663,t:1527613801449};\\\", \\\"{x:451,y:670,t:1527613801466};\\\", \\\"{x:453,y:676,t:1527613801482};\\\", \\\"{x:457,y:683,t:1527613801500};\\\", \\\"{x:462,y:690,t:1527613801515};\\\", \\\"{x:472,y:694,t:1527613801532};\\\", \\\"{x:481,y:696,t:1527613801549};\\\", \\\"{x:488,y:699,t:1527613801565};\\\", \\\"{x:492,y:700,t:1527613801582};\\\", \\\"{x:495,y:701,t:1527613801600};\\\", \\\"{x:497,y:702,t:1527613801615};\\\", \\\"{x:498,y:702,t:1527613801678};\\\", \\\"{x:499,y:703,t:1527613801684};\\\", \\\"{x:501,y:704,t:1527613801699};\\\", \\\"{x:501,y:706,t:1527613801716};\\\", \\\"{x:503,y:709,t:1527613801733};\\\", \\\"{x:502,y:709,t:1527613802405};\\\", \\\"{x:501,y:708,t:1527613802417};\\\", \\\"{x:501,y:707,t:1527613802434};\\\", \\\"{x:500,y:706,t:1527613802450};\\\", \\\"{x:499,y:705,t:1527613802468};\\\", \\\"{x:499,y:704,t:1527613802492};\\\", \\\"{x:498,y:704,t:1527613802533};\\\", \\\"{x:498,y:703,t:1527613802637};\\\", \\\"{x:498,y:702,t:1527613802684};\\\", \\\"{x:498,y:701,t:1527613802700};\\\", \\\"{x:497,y:700,t:1527613802732};\\\", \\\"{x:497,y:699,t:1527613802837};\\\", \\\"{x:496,y:699,t:1527613802885};\\\", \\\"{x:496,y:698,t:1527613802949};\\\", \\\"{x:496,y:697,t:1527613803005};\\\", \\\"{x:495,y:696,t:1527613803065};\\\", \\\"{x:495,y:695,t:1527613803092};\\\" ] }, { \\\"rt\\\": 14174, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 7, \\\"time_elapsed\\\": 149807, \\\"internal_node_id\\\": \\\"0.0-5.0-2.0\\\", \\\"subject\\\": \\\"TGOML\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"oscar\\\", \\\"condition\\\": \\\"114\\\", \\\"scenario\\\": \\\"acme\\\", \\\"question\\\": \\\"meets\\\", \\\"q\\\": 3, \\\"clicks\\\": 1, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XInside-YInside\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 1, \\\"answer\\\": [ \\\"Z\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"X \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"U \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-4-C -C -C -Z -Z -Z \\\", \\\"block\\\": \\\"triangular_scaffolded\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:495,y:694,t:1527613803255};\\\", \\\"{x:495,y:693,t:1527613803267};\\\", \\\"{x:494,y:691,t:1527613803396};\\\", \\\"{x:492,y:691,t:1527613803932};\\\", \\\"{x:492,y:689,t:1527613803948};\\\", \\\"{x:492,y:687,t:1527613803973};\\\", \\\"{x:491,y:687,t:1527613804029};\\\", \\\"{x:491,y:686,t:1527613804044};\\\", \\\"{x:490,y:685,t:1527613804069};\\\", \\\"{x:490,y:684,t:1527613804084};\\\", \\\"{x:489,y:684,t:1527613804125};\\\", \\\"{x:489,y:683,t:1527613804135};\\\", \\\"{x:489,y:682,t:1527613804165};\\\", \\\"{x:489,y:679,t:1527613804180};\\\", \\\"{x:488,y:678,t:1527613804189};\\\", \\\"{x:487,y:678,t:1527613804202};\\\", \\\"{x:485,y:674,t:1527613804217};\\\", \\\"{x:483,y:670,t:1527613804234};\\\", \\\"{x:481,y:662,t:1527613804252};\\\", \\\"{x:481,y:660,t:1527613804268};\\\", \\\"{x:481,y:659,t:1527613804789};\\\", \\\"{x:482,y:659,t:1527613804837};\\\", \\\"{x:483,y:659,t:1527613804851};\\\", \\\"{x:485,y:659,t:1527613804869};\\\", \\\"{x:486,y:659,t:1527613804908};\\\", \\\"{x:486,y:658,t:1527613805037};\\\", \\\"{x:487,y:656,t:1527613805381};\\\", \\\"{x:487,y:654,t:1527613805388};\\\", \\\"{x:488,y:651,t:1527613805403};\\\", \\\"{x:489,y:650,t:1527613805420};\\\", \\\"{x:489,y:649,t:1527613805435};\\\", \\\"{x:489,y:647,t:1527613805452};\\\", \\\"{x:490,y:646,t:1527613806797};\\\", \\\"{x:496,y:646,t:1527613806805};\\\", \\\"{x:525,y:646,t:1527613806822};\\\", \\\"{x:562,y:646,t:1527613806836};\\\", \\\"{x:604,y:646,t:1527613806853};\\\", \\\"{x:643,y:646,t:1527613806870};\\\", \\\"{x:699,y:651,t:1527613806887};\\\", \\\"{x:757,y:660,t:1527613806903};\\\", \\\"{x:835,y:669,t:1527613806920};\\\", \\\"{x:892,y:673,t:1527613806936};\\\", \\\"{x:944,y:678,t:1527613806953};\\\", \\\"{x:977,y:681,t:1527613806970};\\\", \\\"{x:998,y:682,t:1527613806987};\\\", \\\"{x:1008,y:683,t:1527613807003};\\\", \\\"{x:1010,y:683,t:1527613807020};\\\", \\\"{x:1013,y:683,t:1527613807037};\\\", \\\"{x:1017,y:683,t:1527613807054};\\\", \\\"{x:1027,y:686,t:1527613807071};\\\", \\\"{x:1036,y:687,t:1527613807086};\\\", \\\"{x:1042,y:690,t:1527613807104};\\\", \\\"{x:1044,y:691,t:1527613807121};\\\", \\\"{x:1046,y:692,t:1527613807137};\\\", \\\"{x:1048,y:694,t:1527613807154};\\\", \\\"{x:1054,y:699,t:1527613807171};\\\", \\\"{x:1061,y:704,t:1527613807187};\\\", \\\"{x:1069,y:707,t:1527613807204};\\\", \\\"{x:1079,y:711,t:1527613807221};\\\", \\\"{x:1085,y:714,t:1527613807237};\\\", \\\"{x:1096,y:722,t:1527613807254};\\\", \\\"{x:1117,y:737,t:1527613807271};\\\", \\\"{x:1142,y:752,t:1527613807287};\\\", \\\"{x:1165,y:766,t:1527613807304};\\\", \\\"{x:1187,y:779,t:1527613807320};\\\", \\\"{x:1203,y:792,t:1527613807337};\\\", \\\"{x:1214,y:804,t:1527613807353};\\\", \\\"{x:1221,y:817,t:1527613807370};\\\", \\\"{x:1228,y:828,t:1527613807388};\\\", \\\"{x:1231,y:836,t:1527613807404};\\\", \\\"{x:1233,y:839,t:1527613807420};\\\", \\\"{x:1233,y:841,t:1527613807438};\\\", \\\"{x:1233,y:842,t:1527613807454};\\\", \\\"{x:1233,y:845,t:1527613807470};\\\", \\\"{x:1233,y:849,t:1527613807487};\\\", \\\"{x:1233,y:850,t:1527613807504};\\\", \\\"{x:1231,y:852,t:1527613807521};\\\", \\\"{x:1229,y:852,t:1527613807538};\\\", \\\"{x:1229,y:853,t:1527613807573};\\\", \\\"{x:1228,y:852,t:1527613807716};\\\", \\\"{x:1228,y:847,t:1527613807724};\\\", \\\"{x:1225,y:842,t:1527613807737};\\\", \\\"{x:1220,y:831,t:1527613807756};\\\", \\\"{x:1216,y:824,t:1527613807771};\\\", \\\"{x:1213,y:821,t:1527613807787};\\\", \\\"{x:1212,y:819,t:1527613807804};\\\", \\\"{x:1211,y:819,t:1527613807957};\\\", \\\"{x:1210,y:819,t:1527613807971};\\\", \\\"{x:1209,y:819,t:1527613807989};\\\", \\\"{x:1209,y:821,t:1527613808021};\\\", \\\"{x:1209,y:822,t:1527613808045};\\\", \\\"{x:1209,y:823,t:1527613808056};\\\", \\\"{x:1210,y:824,t:1527613808381};\\\", \\\"{x:1211,y:824,t:1527613808396};\\\", \\\"{x:1213,y:824,t:1527613808413};\\\", \\\"{x:1215,y:824,t:1527613808733};\\\", \\\"{x:1217,y:824,t:1527613808741};\\\", \\\"{x:1221,y:824,t:1527613808756};\\\", \\\"{x:1227,y:822,t:1527613808772};\\\", \\\"{x:1234,y:821,t:1527613808789};\\\", \\\"{x:1242,y:821,t:1527613808805};\\\", \\\"{x:1252,y:821,t:1527613808822};\\\", \\\"{x:1266,y:821,t:1527613808839};\\\", \\\"{x:1285,y:824,t:1527613808855};\\\", \\\"{x:1304,y:826,t:1527613808872};\\\", \\\"{x:1321,y:830,t:1527613808889};\\\", \\\"{x:1327,y:830,t:1527613808905};\\\", \\\"{x:1329,y:830,t:1527613808921};\\\", \\\"{x:1329,y:831,t:1527613808939};\\\", \\\"{x:1330,y:832,t:1527613808955};\\\", \\\"{x:1331,y:835,t:1527613808972};\\\", \\\"{x:1331,y:841,t:1527613808988};\\\", \\\"{x:1331,y:847,t:1527613809005};\\\", \\\"{x:1334,y:857,t:1527613809022};\\\", \\\"{x:1336,y:865,t:1527613809039};\\\", \\\"{x:1337,y:870,t:1527613809056};\\\", \\\"{x:1338,y:872,t:1527613809071};\\\", \\\"{x:1338,y:873,t:1527613809133};\\\", \\\"{x:1340,y:874,t:1527613809285};\\\", \\\"{x:1341,y:875,t:1527613809293};\\\", \\\"{x:1342,y:877,t:1527613809308};\\\", \\\"{x:1343,y:877,t:1527613809322};\\\", \\\"{x:1344,y:878,t:1527613809339};\\\", \\\"{x:1345,y:879,t:1527613809356};\\\", \\\"{x:1346,y:879,t:1527613809372};\\\", \\\"{x:1348,y:880,t:1527613809389};\\\", \\\"{x:1348,y:881,t:1527613809405};\\\", \\\"{x:1349,y:881,t:1527613809422};\\\", \\\"{x:1350,y:882,t:1527613809478};\\\", \\\"{x:1350,y:883,t:1527613809493};\\\", \\\"{x:1351,y:883,t:1527613809506};\\\", \\\"{x:1353,y:884,t:1527613809523};\\\", \\\"{x:1354,y:886,t:1527613809539};\\\", \\\"{x:1355,y:886,t:1527613809565};\\\", \\\"{x:1355,y:887,t:1527613809572};\\\", \\\"{x:1356,y:888,t:1527613809589};\\\", \\\"{x:1356,y:889,t:1527613809606};\\\", \\\"{x:1357,y:889,t:1527613809637};\\\", \\\"{x:1358,y:890,t:1527613809653};\\\", \\\"{x:1359,y:892,t:1527613809669};\\\", \\\"{x:1360,y:892,t:1527613809676};\\\", \\\"{x:1360,y:893,t:1527613809689};\\\", \\\"{x:1361,y:894,t:1527613809706};\\\", \\\"{x:1362,y:895,t:1527613810101};\\\", \\\"{x:1363,y:895,t:1527613810117};\\\", \\\"{x:1362,y:895,t:1527613810389};\\\", \\\"{x:1361,y:895,t:1527613810413};\\\", \\\"{x:1360,y:895,t:1527613810429};\\\", \\\"{x:1359,y:894,t:1527613810440};\\\", \\\"{x:1357,y:894,t:1527613810457};\\\", \\\"{x:1353,y:893,t:1527613810473};\\\", \\\"{x:1349,y:893,t:1527613810490};\\\", \\\"{x:1347,y:893,t:1527613810507};\\\", \\\"{x:1346,y:893,t:1527613810523};\\\", \\\"{x:1345,y:892,t:1527613812485};\\\", \\\"{x:1345,y:891,t:1527613812493};\\\", \\\"{x:1345,y:890,t:1527613812508};\\\", \\\"{x:1345,y:884,t:1527613812524};\\\", \\\"{x:1345,y:881,t:1527613812542};\\\", \\\"{x:1345,y:880,t:1527613812558};\\\", \\\"{x:1345,y:879,t:1527613812574};\\\", \\\"{x:1345,y:878,t:1527613812592};\\\", \\\"{x:1345,y:877,t:1527613812608};\\\", \\\"{x:1345,y:876,t:1527613812625};\\\", \\\"{x:1345,y:875,t:1527613812642};\\\", \\\"{x:1345,y:874,t:1527613812661};\\\", \\\"{x:1345,y:873,t:1527613812676};\\\", \\\"{x:1345,y:872,t:1527613812709};\\\", \\\"{x:1345,y:871,t:1527613812749};\\\", \\\"{x:1345,y:870,t:1527613812781};\\\", \\\"{x:1345,y:869,t:1527613812797};\\\", \\\"{x:1345,y:868,t:1527613812808};\\\", \\\"{x:1345,y:867,t:1527613812825};\\\", \\\"{x:1345,y:864,t:1527613812842};\\\", \\\"{x:1345,y:863,t:1527613812858};\\\", \\\"{x:1345,y:861,t:1527613812876};\\\", \\\"{x:1345,y:858,t:1527613812892};\\\", \\\"{x:1345,y:853,t:1527613812908};\\\", \\\"{x:1345,y:848,t:1527613812925};\\\", \\\"{x:1345,y:843,t:1527613812942};\\\", \\\"{x:1345,y:841,t:1527613812959};\\\", \\\"{x:1345,y:840,t:1527613812975};\\\", \\\"{x:1345,y:839,t:1527613812997};\\\", \\\"{x:1345,y:838,t:1527613813013};\\\", \\\"{x:1345,y:837,t:1527613813025};\\\", \\\"{x:1345,y:835,t:1527613813043};\\\", \\\"{x:1343,y:832,t:1527613813059};\\\", \\\"{x:1343,y:824,t:1527613813074};\\\", \\\"{x:1342,y:812,t:1527613813091};\\\", \\\"{x:1339,y:802,t:1527613813108};\\\", \\\"{x:1338,y:800,t:1527613813124};\\\", \\\"{x:1336,y:791,t:1527613813142};\\\", \\\"{x:1334,y:782,t:1527613813159};\\\", \\\"{x:1330,y:773,t:1527613813174};\\\", \\\"{x:1329,y:765,t:1527613813191};\\\", \\\"{x:1329,y:760,t:1527613813209};\\\", \\\"{x:1329,y:755,t:1527613813225};\\\", \\\"{x:1329,y:748,t:1527613813242};\\\", \\\"{x:1329,y:739,t:1527613813258};\\\", \\\"{x:1329,y:731,t:1527613813275};\\\", \\\"{x:1329,y:722,t:1527613813292};\\\", \\\"{x:1329,y:715,t:1527613813309};\\\", \\\"{x:1329,y:712,t:1527613813325};\\\", \\\"{x:1329,y:709,t:1527613813342};\\\", \\\"{x:1331,y:705,t:1527613813359};\\\", \\\"{x:1334,y:698,t:1527613813376};\\\", \\\"{x:1337,y:692,t:1527613813392};\\\", \\\"{x:1337,y:686,t:1527613813409};\\\", \\\"{x:1338,y:683,t:1527613813425};\\\", \\\"{x:1338,y:679,t:1527613813442};\\\", \\\"{x:1339,y:674,t:1527613813458};\\\", \\\"{x:1339,y:663,t:1527613813476};\\\", \\\"{x:1339,y:659,t:1527613813492};\\\", \\\"{x:1339,y:647,t:1527613813509};\\\", \\\"{x:1339,y:643,t:1527613813526};\\\", \\\"{x:1340,y:637,t:1527613813542};\\\", \\\"{x:1341,y:633,t:1527613813559};\\\", \\\"{x:1343,y:628,t:1527613813576};\\\", \\\"{x:1343,y:626,t:1527613813592};\\\", \\\"{x:1344,y:625,t:1527613813609};\\\", \\\"{x:1345,y:623,t:1527613813626};\\\", \\\"{x:1346,y:623,t:1527613813644};\\\", \\\"{x:1347,y:622,t:1527613813677};\\\", \\\"{x:1339,y:627,t:1527613814413};\\\", \\\"{x:1326,y:633,t:1527613814426};\\\", \\\"{x:1299,y:645,t:1527613814443};\\\", \\\"{x:1248,y:667,t:1527613814460};\\\", \\\"{x:1221,y:677,t:1527613814477};\\\", \\\"{x:1182,y:701,t:1527613814493};\\\", \\\"{x:1128,y:729,t:1527613814510};\\\", \\\"{x:1060,y:754,t:1527613814527};\\\", \\\"{x:990,y:769,t:1527613814543};\\\", \\\"{x:940,y:773,t:1527613814560};\\\", \\\"{x:900,y:776,t:1527613814576};\\\", \\\"{x:865,y:781,t:1527613814593};\\\", \\\"{x:833,y:786,t:1527613814610};\\\", \\\"{x:797,y:787,t:1527613814626};\\\", \\\"{x:769,y:785,t:1527613814643};\\\", \\\"{x:728,y:771,t:1527613814660};\\\", \\\"{x:710,y:761,t:1527613814676};\\\", \\\"{x:700,y:755,t:1527613814693};\\\", \\\"{x:698,y:752,t:1527613814710};\\\", \\\"{x:696,y:752,t:1527613814732};\\\", \\\"{x:695,y:752,t:1527613814743};\\\", \\\"{x:691,y:752,t:1527613814760};\\\", \\\"{x:687,y:751,t:1527613814777};\\\", \\\"{x:684,y:749,t:1527613814793};\\\", \\\"{x:680,y:747,t:1527613814810};\\\", \\\"{x:662,y:741,t:1527613814827};\\\", \\\"{x:640,y:734,t:1527613814843};\\\", \\\"{x:600,y:720,t:1527613814860};\\\", \\\"{x:529,y:693,t:1527613814877};\\\", \\\"{x:484,y:680,t:1527613814893};\\\", \\\"{x:457,y:674,t:1527613814910};\\\", \\\"{x:444,y:671,t:1527613814927};\\\", \\\"{x:443,y:670,t:1527613814943};\\\", \\\"{x:444,y:670,t:1527613815037};\\\", \\\"{x:445,y:669,t:1527613815044};\\\", \\\"{x:448,y:668,t:1527613815060};\\\", \\\"{x:450,y:668,t:1527613815140};\\\", \\\"{x:452,y:667,t:1527613815149};\\\", \\\"{x:454,y:665,t:1527613815160};\\\", \\\"{x:451,y:665,t:1527613815301};\\\", \\\"{x:446,y:665,t:1527613815310};\\\", \\\"{x:439,y:665,t:1527613815327};\\\", \\\"{x:436,y:665,t:1527613815344};\\\", \\\"{x:435,y:665,t:1527613815389};\\\", \\\"{x:433,y:665,t:1527613815397};\\\", \\\"{x:430,y:665,t:1527613815410};\\\", \\\"{x:420,y:665,t:1527613815427};\\\", \\\"{x:395,y:665,t:1527613815444};\\\", \\\"{x:379,y:665,t:1527613815461};\\\", \\\"{x:371,y:665,t:1527613815477};\\\", \\\"{x:365,y:663,t:1527613815494};\\\", \\\"{x:359,y:661,t:1527613815511};\\\", \\\"{x:353,y:658,t:1527613815526};\\\", \\\"{x:343,y:654,t:1527613815543};\\\", \\\"{x:326,y:651,t:1527613815560};\\\", \\\"{x:308,y:647,t:1527613815577};\\\", \\\"{x:298,y:644,t:1527613815593};\\\", \\\"{x:293,y:642,t:1527613815610};\\\", \\\"{x:292,y:642,t:1527613815626};\\\", \\\"{x:288,y:641,t:1527613815644};\\\", \\\"{x:280,y:639,t:1527613815661};\\\", \\\"{x:270,y:635,t:1527613815677};\\\", \\\"{x:261,y:633,t:1527613815694};\\\", \\\"{x:252,y:629,t:1527613815710};\\\", \\\"{x:244,y:626,t:1527613815727};\\\", \\\"{x:237,y:624,t:1527613815743};\\\", \\\"{x:225,y:621,t:1527613815760};\\\", \\\"{x:207,y:619,t:1527613815778};\\\", \\\"{x:193,y:618,t:1527613815793};\\\", \\\"{x:186,y:616,t:1527613815811};\\\", \\\"{x:183,y:614,t:1527613815827};\\\", \\\"{x:183,y:613,t:1527613815843};\\\", \\\"{x:183,y:610,t:1527613815862};\\\", \\\"{x:183,y:608,t:1527613815878};\\\", \\\"{x:183,y:602,t:1527613815894};\\\", \\\"{x:181,y:599,t:1527613815910};\\\", \\\"{x:180,y:596,t:1527613815928};\\\", \\\"{x:178,y:591,t:1527613815944};\\\", \\\"{x:177,y:589,t:1527613815961};\\\", \\\"{x:176,y:585,t:1527613815978};\\\", \\\"{x:174,y:582,t:1527613815997};\\\", \\\"{x:173,y:578,t:1527613816011};\\\", \\\"{x:171,y:574,t:1527613816028};\\\", \\\"{x:169,y:570,t:1527613816044};\\\", \\\"{x:166,y:568,t:1527613816061};\\\", \\\"{x:165,y:564,t:1527613816078};\\\", \\\"{x:163,y:562,t:1527613816094};\\\", \\\"{x:162,y:560,t:1527613816111};\\\", \\\"{x:161,y:559,t:1527613816127};\\\", \\\"{x:161,y:557,t:1527613816180};\\\", \\\"{x:162,y:556,t:1527613816483};\\\", \\\"{x:168,y:556,t:1527613816495};\\\", \\\"{x:181,y:556,t:1527613816511};\\\", \\\"{x:202,y:556,t:1527613816528};\\\", \\\"{x:224,y:563,t:1527613816545};\\\", \\\"{x:242,y:571,t:1527613816562};\\\", \\\"{x:257,y:576,t:1527613816578};\\\", \\\"{x:275,y:582,t:1527613816596};\\\", \\\"{x:299,y:590,t:1527613816611};\\\", \\\"{x:321,y:594,t:1527613816628};\\\", \\\"{x:341,y:599,t:1527613816645};\\\", \\\"{x:355,y:605,t:1527613816662};\\\", \\\"{x:362,y:607,t:1527613816678};\\\", \\\"{x:365,y:609,t:1527613816695};\\\", \\\"{x:369,y:613,t:1527613816713};\\\", \\\"{x:375,y:619,t:1527613816727};\\\", \\\"{x:380,y:625,t:1527613816746};\\\", \\\"{x:384,y:630,t:1527613816762};\\\", \\\"{x:389,y:636,t:1527613816777};\\\", \\\"{x:395,y:643,t:1527613816795};\\\", \\\"{x:413,y:658,t:1527613816812};\\\", \\\"{x:429,y:668,t:1527613816828};\\\", \\\"{x:453,y:677,t:1527613816845};\\\", \\\"{x:479,y:687,t:1527613816861};\\\", \\\"{x:502,y:693,t:1527613816877};\\\", \\\"{x:519,y:698,t:1527613816894};\\\", \\\"{x:526,y:699,t:1527613816912};\\\", \\\"{x:529,y:701,t:1527613816929};\\\", \\\"{x:530,y:702,t:1527613817132};\\\", \\\"{x:530,y:704,t:1527613817145};\\\", \\\"{x:530,y:707,t:1527613817162};\\\", \\\"{x:530,y:708,t:1527613817179};\\\", \\\"{x:530,y:709,t:1527613817195};\\\" ] }, { \\\"rt\\\": 97317, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 8, \\\"time_elapsed\\\": 248363, \\\"internal_node_id\\\": \\\"0.0-5.0-3.0\\\", \\\"subject\\\": \\\"TGOML\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"oscar\\\", \\\"condition\\\": \\\"114\\\", \\\"scenario\\\": \\\"acme\\\", \\\"question\\\": \\\"endtime\\\", \\\"q\\\": 4, \\\"clicks\\\": 1, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XInside-YInside\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 1, \\\"answer\\\": [ \\\"U\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"X \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"U \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-11 AM-12 PM-12 PM-Z -Z -F -F -F -O \\\", \\\"block\\\": \\\"triangular_scaffolded\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:535,y:709,t:1527613820717};\\\", \\\"{x:557,y:707,t:1527613820734};\\\", \\\"{x:577,y:707,t:1527613820750};\\\", \\\"{x:588,y:707,t:1527613820766};\\\", \\\"{x:602,y:707,t:1527613820784};\\\", \\\"{x:615,y:708,t:1527613820797};\\\", \\\"{x:628,y:710,t:1527613820813};\\\", \\\"{x:643,y:712,t:1527613820831};\\\", \\\"{x:662,y:714,t:1527613820846};\\\", \\\"{x:681,y:718,t:1527613820864};\\\", \\\"{x:703,y:722,t:1527613820881};\\\", \\\"{x:723,y:725,t:1527613820897};\\\", \\\"{x:747,y:729,t:1527613820914};\\\", \\\"{x:778,y:734,t:1527613820931};\\\", \\\"{x:811,y:739,t:1527613820947};\\\", \\\"{x:864,y:752,t:1527613820964};\\\", \\\"{x:890,y:760,t:1527613820981};\\\", \\\"{x:915,y:770,t:1527613820997};\\\", \\\"{x:948,y:780,t:1527613821014};\\\", \\\"{x:975,y:789,t:1527613821031};\\\", \\\"{x:998,y:797,t:1527613821047};\\\", \\\"{x:1013,y:802,t:1527613821065};\\\", \\\"{x:1025,y:808,t:1527613821081};\\\", \\\"{x:1035,y:811,t:1527613821097};\\\", \\\"{x:1043,y:815,t:1527613821114};\\\", \\\"{x:1053,y:821,t:1527613821131};\\\", \\\"{x:1069,y:828,t:1527613821148};\\\", \\\"{x:1076,y:832,t:1527613821164};\\\", \\\"{x:1085,y:837,t:1527613821181};\\\", \\\"{x:1096,y:844,t:1527613821198};\\\", \\\"{x:1112,y:854,t:1527613821214};\\\", \\\"{x:1131,y:864,t:1527613821231};\\\", \\\"{x:1149,y:873,t:1527613821248};\\\", \\\"{x:1168,y:884,t:1527613821265};\\\", \\\"{x:1184,y:892,t:1527613821282};\\\", \\\"{x:1199,y:901,t:1527613821298};\\\", \\\"{x:1209,y:909,t:1527613821314};\\\", \\\"{x:1223,y:918,t:1527613821331};\\\", \\\"{x:1240,y:933,t:1527613821348};\\\", \\\"{x:1257,y:945,t:1527613821364};\\\", \\\"{x:1271,y:955,t:1527613821381};\\\", \\\"{x:1284,y:968,t:1527613821398};\\\", \\\"{x:1293,y:976,t:1527613821414};\\\", \\\"{x:1301,y:983,t:1527613821432};\\\", \\\"{x:1305,y:988,t:1527613821449};\\\", \\\"{x:1307,y:989,t:1527613821465};\\\", \\\"{x:1309,y:989,t:1527613828165};\\\", \\\"{x:1314,y:987,t:1527613828172};\\\", \\\"{x:1323,y:984,t:1527613828183};\\\", \\\"{x:1334,y:981,t:1527613828201};\\\", \\\"{x:1345,y:978,t:1527613828218};\\\", \\\"{x:1353,y:974,t:1527613828233};\\\", \\\"{x:1356,y:974,t:1527613828250};\\\", \\\"{x:1360,y:973,t:1527613828267};\\\", \\\"{x:1370,y:972,t:1527613828283};\\\", \\\"{x:1403,y:967,t:1527613828300};\\\", \\\"{x:1424,y:963,t:1527613828317};\\\", \\\"{x:1446,y:958,t:1527613828333};\\\", \\\"{x:1465,y:956,t:1527613828350};\\\", \\\"{x:1478,y:953,t:1527613828367};\\\", \\\"{x:1492,y:950,t:1527613828383};\\\", \\\"{x:1503,y:948,t:1527613828400};\\\", \\\"{x:1513,y:947,t:1527613828417};\\\", \\\"{x:1521,y:946,t:1527613828434};\\\", \\\"{x:1527,y:944,t:1527613828450};\\\", \\\"{x:1532,y:944,t:1527613828467};\\\", \\\"{x:1538,y:944,t:1527613828483};\\\", \\\"{x:1548,y:944,t:1527613828500};\\\", \\\"{x:1552,y:944,t:1527613828517};\\\", \\\"{x:1556,y:944,t:1527613828533};\\\", \\\"{x:1559,y:944,t:1527613828550};\\\", \\\"{x:1560,y:943,t:1527613828567};\\\", \\\"{x:1562,y:943,t:1527613828583};\\\", \\\"{x:1563,y:943,t:1527613828644};\\\", \\\"{x:1564,y:943,t:1527613828652};\\\", \\\"{x:1565,y:943,t:1527613828667};\\\", \\\"{x:1571,y:945,t:1527613828684};\\\", \\\"{x:1576,y:946,t:1527613828701};\\\", \\\"{x:1578,y:947,t:1527613828718};\\\", \\\"{x:1580,y:948,t:1527613828733};\\\", \\\"{x:1581,y:949,t:1527613828750};\\\", \\\"{x:1582,y:949,t:1527613828767};\\\", \\\"{x:1583,y:950,t:1527613828783};\\\", \\\"{x:1584,y:950,t:1527613828801};\\\", \\\"{x:1585,y:950,t:1527613828828};\\\", \\\"{x:1587,y:950,t:1527613828876};\\\", \\\"{x:1588,y:951,t:1527613828884};\\\", \\\"{x:1592,y:951,t:1527613828900};\\\", \\\"{x:1596,y:952,t:1527613828918};\\\", \\\"{x:1601,y:954,t:1527613828934};\\\", \\\"{x:1604,y:955,t:1527613828951};\\\", \\\"{x:1606,y:956,t:1527613828967};\\\", \\\"{x:1607,y:957,t:1527613828985};\\\", \\\"{x:1608,y:957,t:1527613829001};\\\", \\\"{x:1608,y:958,t:1527613829017};\\\", \\\"{x:1609,y:958,t:1527613829061};\\\", \\\"{x:1609,y:959,t:1527613829068};\\\", \\\"{x:1610,y:959,t:1527613829101};\\\", \\\"{x:1611,y:959,t:1527613829197};\\\", \\\"{x:1611,y:960,t:1527613829309};\\\", \\\"{x:1612,y:960,t:1527613829333};\\\", \\\"{x:1613,y:960,t:1527613829469};\\\", \\\"{x:1615,y:960,t:1527613829485};\\\", \\\"{x:1615,y:959,t:1527613829644};\\\", \\\"{x:1606,y:959,t:1527613839596};\\\", \\\"{x:1589,y:958,t:1527613839605};\\\", \\\"{x:1542,y:952,t:1527613839623};\\\", \\\"{x:1473,y:945,t:1527613839639};\\\", \\\"{x:1390,y:932,t:1527613839655};\\\", \\\"{x:1320,y:923,t:1527613839672};\\\", \\\"{x:1280,y:916,t:1527613839688};\\\", \\\"{x:1264,y:913,t:1527613839705};\\\", \\\"{x:1261,y:913,t:1527613839722};\\\", \\\"{x:1261,y:915,t:1527613839797};\\\", \\\"{x:1263,y:919,t:1527613839805};\\\", \\\"{x:1273,y:929,t:1527613839822};\\\", \\\"{x:1288,y:941,t:1527613839838};\\\", \\\"{x:1301,y:951,t:1527613839855};\\\", \\\"{x:1315,y:957,t:1527613839872};\\\", \\\"{x:1320,y:959,t:1527613839888};\\\", \\\"{x:1325,y:961,t:1527613839904};\\\", \\\"{x:1326,y:962,t:1527613839921};\\\", \\\"{x:1328,y:962,t:1527613839938};\\\", \\\"{x:1331,y:964,t:1527613839955};\\\", \\\"{x:1339,y:966,t:1527613839971};\\\", \\\"{x:1345,y:969,t:1527613839987};\\\", \\\"{x:1349,y:970,t:1527613840005};\\\", \\\"{x:1352,y:970,t:1527613840022};\\\", \\\"{x:1351,y:970,t:1527613840333};\\\", \\\"{x:1351,y:969,t:1527613840484};\\\", \\\"{x:1351,y:968,t:1527613840500};\\\", \\\"{x:1351,y:967,t:1527613840508};\\\", \\\"{x:1351,y:966,t:1527613840522};\\\", \\\"{x:1351,y:965,t:1527613840539};\\\", \\\"{x:1351,y:964,t:1527613840556};\\\", \\\"{x:1351,y:963,t:1527613840580};\\\", \\\"{x:1350,y:963,t:1527613840620};\\\", \\\"{x:1350,y:961,t:1527613840757};\\\", \\\"{x:1350,y:960,t:1527613840772};\\\", \\\"{x:1350,y:957,t:1527613840789};\\\", \\\"{x:1350,y:955,t:1527613840805};\\\", \\\"{x:1350,y:954,t:1527613840822};\\\", \\\"{x:1350,y:952,t:1527613840839};\\\", \\\"{x:1351,y:949,t:1527613840855};\\\", \\\"{x:1352,y:947,t:1527613840873};\\\", \\\"{x:1354,y:943,t:1527613840889};\\\", \\\"{x:1357,y:938,t:1527613840905};\\\", \\\"{x:1360,y:931,t:1527613840922};\\\", \\\"{x:1362,y:928,t:1527613840939};\\\", \\\"{x:1364,y:924,t:1527613840956};\\\", \\\"{x:1364,y:920,t:1527613840972};\\\", \\\"{x:1364,y:917,t:1527613840989};\\\", \\\"{x:1364,y:913,t:1527613841005};\\\", \\\"{x:1364,y:910,t:1527613841023};\\\", \\\"{x:1364,y:906,t:1527613841039};\\\", \\\"{x:1363,y:901,t:1527613841055};\\\", \\\"{x:1363,y:900,t:1527613841072};\\\", \\\"{x:1362,y:899,t:1527613841089};\\\", \\\"{x:1361,y:896,t:1527613841105};\\\", \\\"{x:1359,y:894,t:1527613841123};\\\", \\\"{x:1357,y:892,t:1527613841139};\\\", \\\"{x:1356,y:890,t:1527613841155};\\\", \\\"{x:1356,y:887,t:1527613841172};\\\", \\\"{x:1356,y:886,t:1527613841196};\\\", \\\"{x:1355,y:884,t:1527613841212};\\\", \\\"{x:1355,y:883,t:1527613841223};\\\", \\\"{x:1354,y:879,t:1527613841239};\\\", \\\"{x:1352,y:874,t:1527613841255};\\\", \\\"{x:1350,y:869,t:1527613841272};\\\", \\\"{x:1349,y:868,t:1527613841289};\\\", \\\"{x:1349,y:867,t:1527613841305};\\\", \\\"{x:1349,y:866,t:1527613841321};\\\", \\\"{x:1348,y:865,t:1527613841460};\\\", \\\"{x:1347,y:865,t:1527613841471};\\\", \\\"{x:1342,y:867,t:1527613841489};\\\", \\\"{x:1341,y:871,t:1527613841506};\\\", \\\"{x:1341,y:876,t:1527613841522};\\\", \\\"{x:1341,y:881,t:1527613841538};\\\", \\\"{x:1341,y:887,t:1527613841555};\\\", \\\"{x:1341,y:891,t:1527613841571};\\\", \\\"{x:1341,y:895,t:1527613841589};\\\", \\\"{x:1341,y:899,t:1527613841605};\\\", \\\"{x:1341,y:901,t:1527613841622};\\\", \\\"{x:1341,y:905,t:1527613841638};\\\", \\\"{x:1341,y:907,t:1527613841655};\\\", \\\"{x:1341,y:908,t:1527613841671};\\\", \\\"{x:1342,y:904,t:1527613841797};\\\", \\\"{x:1342,y:903,t:1527613841806};\\\", \\\"{x:1342,y:900,t:1527613841822};\\\", \\\"{x:1342,y:896,t:1527613841839};\\\", \\\"{x:1342,y:891,t:1527613841857};\\\", \\\"{x:1344,y:887,t:1527613841871};\\\", \\\"{x:1345,y:884,t:1527613841889};\\\", \\\"{x:1345,y:883,t:1527613841906};\\\", \\\"{x:1345,y:881,t:1527613841921};\\\", \\\"{x:1345,y:880,t:1527613841938};\\\", \\\"{x:1345,y:876,t:1527613841956};\\\", \\\"{x:1345,y:873,t:1527613841972};\\\", \\\"{x:1345,y:871,t:1527613841989};\\\", \\\"{x:1345,y:868,t:1527613842006};\\\", \\\"{x:1345,y:866,t:1527613842022};\\\", \\\"{x:1345,y:863,t:1527613842039};\\\", \\\"{x:1345,y:858,t:1527613842056};\\\", \\\"{x:1343,y:853,t:1527613842072};\\\", \\\"{x:1343,y:848,t:1527613842089};\\\", \\\"{x:1342,y:843,t:1527613842106};\\\", \\\"{x:1341,y:838,t:1527613842122};\\\", \\\"{x:1340,y:833,t:1527613842139};\\\", \\\"{x:1338,y:827,t:1527613842156};\\\", \\\"{x:1337,y:824,t:1527613842172};\\\", \\\"{x:1337,y:822,t:1527613842189};\\\", \\\"{x:1337,y:820,t:1527613842206};\\\", \\\"{x:1337,y:816,t:1527613842222};\\\", \\\"{x:1335,y:812,t:1527613842238};\\\", \\\"{x:1334,y:806,t:1527613842256};\\\", \\\"{x:1333,y:803,t:1527613842272};\\\", \\\"{x:1333,y:801,t:1527613842289};\\\", \\\"{x:1331,y:799,t:1527613842306};\\\", \\\"{x:1331,y:798,t:1527613842322};\\\", \\\"{x:1331,y:796,t:1527613842340};\\\", \\\"{x:1331,y:792,t:1527613842357};\\\", \\\"{x:1331,y:788,t:1527613842373};\\\", \\\"{x:1331,y:785,t:1527613842390};\\\", \\\"{x:1331,y:783,t:1527613842406};\\\", \\\"{x:1331,y:780,t:1527613842423};\\\", \\\"{x:1331,y:778,t:1527613842439};\\\", \\\"{x:1331,y:775,t:1527613842456};\\\", \\\"{x:1331,y:772,t:1527613842473};\\\", \\\"{x:1331,y:768,t:1527613842489};\\\", \\\"{x:1331,y:765,t:1527613842506};\\\", \\\"{x:1331,y:761,t:1527613842523};\\\", \\\"{x:1331,y:758,t:1527613842539};\\\", \\\"{x:1331,y:755,t:1527613842556};\\\", \\\"{x:1331,y:752,t:1527613842573};\\\", \\\"{x:1331,y:749,t:1527613842589};\\\", \\\"{x:1331,y:746,t:1527613842606};\\\", \\\"{x:1331,y:742,t:1527613842624};\\\", \\\"{x:1331,y:737,t:1527613842638};\\\", \\\"{x:1331,y:735,t:1527613842656};\\\", \\\"{x:1331,y:732,t:1527613842673};\\\", \\\"{x:1331,y:728,t:1527613842689};\\\", \\\"{x:1332,y:726,t:1527613842706};\\\", \\\"{x:1333,y:724,t:1527613842723};\\\", \\\"{x:1335,y:721,t:1527613842739};\\\", \\\"{x:1335,y:719,t:1527613842756};\\\", \\\"{x:1336,y:717,t:1527613842774};\\\", \\\"{x:1337,y:715,t:1527613842789};\\\", \\\"{x:1338,y:714,t:1527613842812};\\\", \\\"{x:1338,y:713,t:1527613842827};\\\", \\\"{x:1338,y:712,t:1527613842839};\\\", \\\"{x:1339,y:711,t:1527613842860};\\\", \\\"{x:1340,y:710,t:1527613842900};\\\", \\\"{x:1340,y:709,t:1527613842989};\\\", \\\"{x:1341,y:709,t:1527613843006};\\\", \\\"{x:1341,y:706,t:1527613843024};\\\", \\\"{x:1341,y:705,t:1527613843044};\\\", \\\"{x:1342,y:705,t:1527613843056};\\\", \\\"{x:1342,y:704,t:1527613843073};\\\", \\\"{x:1342,y:703,t:1527613843089};\\\", \\\"{x:1342,y:702,t:1527613843106};\\\", \\\"{x:1342,y:701,t:1527613843124};\\\", \\\"{x:1342,y:700,t:1527613843147};\\\", \\\"{x:1342,y:699,t:1527613843172};\\\", \\\"{x:1342,y:698,t:1527613843189};\\\", \\\"{x:1343,y:697,t:1527613843206};\\\", \\\"{x:1343,y:696,t:1527613843224};\\\", \\\"{x:1344,y:695,t:1527613843240};\\\", \\\"{x:1344,y:694,t:1527613843268};\\\", \\\"{x:1344,y:693,t:1527613843291};\\\", \\\"{x:1344,y:692,t:1527613843661};\\\", \\\"{x:1345,y:692,t:1527613843675};\\\", \\\"{x:1346,y:693,t:1527613843691};\\\", \\\"{x:1346,y:694,t:1527613843705};\\\", \\\"{x:1348,y:698,t:1527613849791};\\\", \\\"{x:1352,y:704,t:1527613849799};\\\", \\\"{x:1353,y:707,t:1527613849812};\\\", \\\"{x:1358,y:715,t:1527613849829};\\\", \\\"{x:1361,y:721,t:1527613849846};\\\", \\\"{x:1365,y:727,t:1527613849862};\\\", \\\"{x:1366,y:730,t:1527613849880};\\\", \\\"{x:1368,y:732,t:1527613849895};\\\", \\\"{x:1368,y:733,t:1527613849912};\\\", \\\"{x:1369,y:734,t:1527613849929};\\\", \\\"{x:1369,y:735,t:1527613849946};\\\", \\\"{x:1370,y:737,t:1527613849962};\\\", \\\"{x:1371,y:738,t:1527613849979};\\\", \\\"{x:1372,y:739,t:1527613849996};\\\", \\\"{x:1372,y:741,t:1527613850013};\\\", \\\"{x:1373,y:745,t:1527613850029};\\\", \\\"{x:1374,y:746,t:1527613850046};\\\", \\\"{x:1374,y:748,t:1527613850063};\\\", \\\"{x:1375,y:749,t:1527613850079};\\\", \\\"{x:1377,y:752,t:1527613850096};\\\", \\\"{x:1377,y:753,t:1527613850112};\\\", \\\"{x:1378,y:754,t:1527613850150};\\\", \\\"{x:1378,y:755,t:1527613850174};\\\", \\\"{x:1379,y:756,t:1527613850182};\\\", \\\"{x:1379,y:757,t:1527613850195};\\\", \\\"{x:1381,y:759,t:1527613850212};\\\", \\\"{x:1380,y:759,t:1527613859023};\\\", \\\"{x:1377,y:757,t:1527613859033};\\\", \\\"{x:1374,y:752,t:1527613859050};\\\", \\\"{x:1372,y:749,t:1527613859066};\\\", \\\"{x:1370,y:744,t:1527613859082};\\\", \\\"{x:1368,y:741,t:1527613859100};\\\", \\\"{x:1367,y:738,t:1527613859116};\\\", \\\"{x:1366,y:736,t:1527613859132};\\\", \\\"{x:1365,y:734,t:1527613859149};\\\", \\\"{x:1365,y:733,t:1527613859166};\\\", \\\"{x:1365,y:732,t:1527613859182};\\\", \\\"{x:1365,y:728,t:1527613859199};\\\", \\\"{x:1363,y:724,t:1527613859217};\\\", \\\"{x:1362,y:721,t:1527613859232};\\\", \\\"{x:1362,y:719,t:1527613859249};\\\", \\\"{x:1362,y:718,t:1527613859266};\\\", \\\"{x:1362,y:716,t:1527613859343};\\\", \\\"{x:1362,y:715,t:1527613859367};\\\", \\\"{x:1361,y:715,t:1527613859382};\\\", \\\"{x:1361,y:713,t:1527613859414};\\\", \\\"{x:1360,y:712,t:1527613859422};\\\", \\\"{x:1360,y:711,t:1527613859432};\\\", \\\"{x:1359,y:711,t:1527613859448};\\\", \\\"{x:1358,y:710,t:1527613859466};\\\", \\\"{x:1358,y:708,t:1527613859486};\\\", \\\"{x:1358,y:707,t:1527613859499};\\\", \\\"{x:1358,y:706,t:1527613859516};\\\", \\\"{x:1356,y:704,t:1527613859532};\\\", \\\"{x:1355,y:702,t:1527613859549};\\\", \\\"{x:1353,y:699,t:1527613859566};\\\", \\\"{x:1351,y:697,t:1527613859583};\\\", \\\"{x:1349,y:696,t:1527613859599};\\\", \\\"{x:1348,y:696,t:1527613859615};\\\", \\\"{x:1348,y:694,t:1527613859639};\\\", \\\"{x:1347,y:693,t:1527613859649};\\\", \\\"{x:1346,y:691,t:1527613859666};\\\", \\\"{x:1345,y:691,t:1527613859682};\\\", \\\"{x:1342,y:687,t:1527613859699};\\\", \\\"{x:1342,y:686,t:1527613859716};\\\", \\\"{x:1340,y:685,t:1527613859733};\\\", \\\"{x:1339,y:685,t:1527613859749};\\\", \\\"{x:1339,y:684,t:1527613859765};\\\", \\\"{x:1336,y:682,t:1527613859782};\\\", \\\"{x:1334,y:680,t:1527613859799};\\\", \\\"{x:1333,y:677,t:1527613859815};\\\", \\\"{x:1330,y:673,t:1527613859833};\\\", \\\"{x:1329,y:670,t:1527613859848};\\\", \\\"{x:1328,y:667,t:1527613859865};\\\", \\\"{x:1326,y:663,t:1527613859883};\\\", \\\"{x:1325,y:661,t:1527613859899};\\\", \\\"{x:1325,y:658,t:1527613859916};\\\", \\\"{x:1324,y:655,t:1527613859932};\\\", \\\"{x:1323,y:653,t:1527613859949};\\\", \\\"{x:1322,y:649,t:1527613859967};\\\", \\\"{x:1319,y:643,t:1527613859982};\\\", \\\"{x:1318,y:641,t:1527613859999};\\\", \\\"{x:1316,y:638,t:1527613860016};\\\", \\\"{x:1316,y:637,t:1527613860039};\\\", \\\"{x:1316,y:636,t:1527613860055};\\\", \\\"{x:1315,y:635,t:1527613860079};\\\", \\\"{x:1314,y:634,t:1527613860098};\\\", \\\"{x:1314,y:633,t:1527613860116};\\\", \\\"{x:1313,y:632,t:1527613860133};\\\", \\\"{x:1313,y:631,t:1527613905503};\\\", \\\"{x:1306,y:631,t:1527613905517};\\\", \\\"{x:1278,y:631,t:1527613905534};\\\", \\\"{x:1260,y:631,t:1527613905550};\\\", \\\"{x:1243,y:631,t:1527613905567};\\\", \\\"{x:1230,y:631,t:1527613905584};\\\", \\\"{x:1216,y:631,t:1527613905600};\\\", \\\"{x:1202,y:631,t:1527613905617};\\\", \\\"{x:1187,y:631,t:1527613905634};\\\", \\\"{x:1175,y:633,t:1527613905649};\\\", \\\"{x:1161,y:634,t:1527613905666};\\\", \\\"{x:1149,y:635,t:1527613905684};\\\", \\\"{x:1139,y:638,t:1527613905699};\\\", \\\"{x:1123,y:640,t:1527613905717};\\\", \\\"{x:1083,y:640,t:1527613905734};\\\", \\\"{x:1037,y:644,t:1527613905750};\\\", \\\"{x:989,y:645,t:1527613905767};\\\", \\\"{x:953,y:645,t:1527613905784};\\\", \\\"{x:916,y:645,t:1527613905799};\\\", \\\"{x:879,y:645,t:1527613905817};\\\", \\\"{x:848,y:645,t:1527613905833};\\\", \\\"{x:818,y:645,t:1527613905851};\\\", \\\"{x:791,y:645,t:1527613905867};\\\", \\\"{x:769,y:645,t:1527613905883};\\\", \\\"{x:748,y:645,t:1527613905901};\\\", \\\"{x:724,y:645,t:1527613905918};\\\", \\\"{x:654,y:645,t:1527613905933};\\\", \\\"{x:599,y:645,t:1527613905950};\\\", \\\"{x:543,y:645,t:1527613905970};\\\", \\\"{x:508,y:645,t:1527613905987};\\\", \\\"{x:481,y:645,t:1527613906004};\\\", \\\"{x:454,y:645,t:1527613906020};\\\", \\\"{x:406,y:645,t:1527613906038};\\\", \\\"{x:379,y:645,t:1527613906055};\\\", \\\"{x:361,y:645,t:1527613906072};\\\", \\\"{x:351,y:645,t:1527613906088};\\\", \\\"{x:349,y:645,t:1527613906105};\\\", \\\"{x:348,y:645,t:1527613906142};\\\", \\\"{x:347,y:644,t:1527613906310};\\\", \\\"{x:347,y:643,t:1527613906326};\\\", \\\"{x:348,y:641,t:1527613906341};\\\", \\\"{x:352,y:638,t:1527613906356};\\\", \\\"{x:362,y:632,t:1527613906373};\\\", \\\"{x:373,y:626,t:1527613906389};\\\", \\\"{x:406,y:609,t:1527613906405};\\\", \\\"{x:433,y:595,t:1527613906423};\\\", \\\"{x:451,y:587,t:1527613906438};\\\", \\\"{x:466,y:579,t:1527613906455};\\\", \\\"{x:477,y:573,t:1527613906472};\\\", \\\"{x:481,y:572,t:1527613906489};\\\", \\\"{x:485,y:571,t:1527613906505};\\\", \\\"{x:490,y:568,t:1527613906522};\\\", \\\"{x:503,y:564,t:1527613906540};\\\", \\\"{x:522,y:558,t:1527613906555};\\\", \\\"{x:551,y:551,t:1527613906572};\\\", \\\"{x:596,y:543,t:1527613906589};\\\", \\\"{x:658,y:538,t:1527613906605};\\\", \\\"{x:698,y:537,t:1527613906622};\\\", \\\"{x:722,y:534,t:1527613906639};\\\", \\\"{x:729,y:533,t:1527613906656};\\\", \\\"{x:730,y:533,t:1527613906685};\\\", \\\"{x:729,y:533,t:1527613906734};\\\", \\\"{x:729,y:534,t:1527613906741};\\\", \\\"{x:727,y:534,t:1527613906756};\\\", \\\"{x:729,y:534,t:1527613906838};\\\", \\\"{x:731,y:534,t:1527613906854};\\\", \\\"{x:732,y:534,t:1527613906861};\\\", \\\"{x:734,y:534,t:1527613906876};\\\", \\\"{x:735,y:534,t:1527613906894};\\\", \\\"{x:739,y:534,t:1527613906910};\\\", \\\"{x:741,y:534,t:1527613906927};\\\", \\\"{x:741,y:535,t:1527613906986};\\\", \\\"{x:738,y:537,t:1527613906995};\\\", \\\"{x:729,y:543,t:1527613907010};\\\", \\\"{x:719,y:549,t:1527613907029};\\\", \\\"{x:707,y:556,t:1527613907043};\\\", \\\"{x:689,y:566,t:1527613907061};\\\", \\\"{x:671,y:578,t:1527613907076};\\\", \\\"{x:659,y:586,t:1527613907094};\\\", \\\"{x:651,y:594,t:1527613907110};\\\", \\\"{x:646,y:597,t:1527613907127};\\\", \\\"{x:644,y:597,t:1527613907282};\\\", \\\"{x:643,y:597,t:1527613907293};\\\", \\\"{x:635,y:597,t:1527613907310};\\\", \\\"{x:627,y:598,t:1527613907326};\\\", \\\"{x:623,y:598,t:1527613907344};\\\", \\\"{x:622,y:598,t:1527613907360};\\\", \\\"{x:621,y:598,t:1527613907377};\\\", \\\"{x:617,y:598,t:1527613907394};\\\", \\\"{x:612,y:598,t:1527613907411};\\\", \\\"{x:606,y:598,t:1527613907427};\\\", \\\"{x:604,y:598,t:1527613907444};\\\", \\\"{x:603,y:599,t:1527613914682};\\\", \\\"{x:599,y:602,t:1527613914699};\\\", \\\"{x:596,y:605,t:1527613914717};\\\", \\\"{x:594,y:607,t:1527613914733};\\\", \\\"{x:593,y:609,t:1527613914748};\\\", \\\"{x:591,y:610,t:1527613914769};\\\", \\\"{x:590,y:611,t:1527613914793};\\\", \\\"{x:588,y:612,t:1527613914801};\\\", \\\"{x:587,y:612,t:1527613914816};\\\", \\\"{x:581,y:616,t:1527613914834};\\\", \\\"{x:578,y:618,t:1527613914849};\\\", \\\"{x:575,y:619,t:1527613914865};\\\", \\\"{x:573,y:621,t:1527613914882};\\\", \\\"{x:569,y:625,t:1527613914899};\\\", \\\"{x:566,y:629,t:1527613914917};\\\", \\\"{x:562,y:635,t:1527613914932};\\\", \\\"{x:559,y:638,t:1527613914950};\\\", \\\"{x:558,y:640,t:1527613914966};\\\", \\\"{x:558,y:641,t:1527613914986};\\\", \\\"{x:558,y:642,t:1527613915000};\\\", \\\"{x:557,y:644,t:1527613915017};\\\", \\\"{x:555,y:648,t:1527613915033};\\\", \\\"{x:554,y:653,t:1527613915051};\\\", \\\"{x:554,y:655,t:1527613915067};\\\", \\\"{x:554,y:656,t:1527613915083};\\\", \\\"{x:554,y:659,t:1527613915122};\\\", \\\"{x:554,y:661,t:1527613915133};\\\", \\\"{x:554,y:665,t:1527613915150};\\\", \\\"{x:554,y:668,t:1527613915168};\\\", \\\"{x:554,y:670,t:1527613915183};\\\", \\\"{x:554,y:671,t:1527613915200};\\\", \\\"{x:554,y:672,t:1527613915217};\\\", \\\"{x:557,y:679,t:1527613915234};\\\", \\\"{x:559,y:686,t:1527613915250};\\\", \\\"{x:560,y:694,t:1527613915267};\\\", \\\"{x:560,y:702,t:1527613915285};\\\", \\\"{x:560,y:707,t:1527613915299};\\\", \\\"{x:559,y:714,t:1527613915317};\\\", \\\"{x:558,y:714,t:1527613915333};\\\", \\\"{x:558,y:717,t:1527613915351};\\\", \\\"{x:555,y:723,t:1527613915366};\\\", \\\"{x:548,y:736,t:1527613915384};\\\", \\\"{x:541,y:750,t:1527613915400};\\\", \\\"{x:537,y:757,t:1527613915416};\\\", \\\"{x:536,y:761,t:1527613915434};\\\", \\\"{x:535,y:762,t:1527613915457};\\\", \\\"{x:534,y:761,t:1527613915467};\\\", \\\"{x:534,y:756,t:1527613915484};\\\", \\\"{x:534,y:748,t:1527613915500};\\\", \\\"{x:534,y:742,t:1527613915517};\\\", \\\"{x:534,y:736,t:1527613915534};\\\", \\\"{x:534,y:733,t:1527613915551};\\\", \\\"{x:535,y:730,t:1527613915567};\\\", \\\"{x:536,y:727,t:1527613915583};\\\", \\\"{x:536,y:724,t:1527613915601};\\\", \\\"{x:538,y:723,t:1527613915618};\\\", \\\"{x:538,y:722,t:1527613915634};\\\", \\\"{x:538,y:721,t:1527613915699};\\\", \\\"{x:539,y:719,t:1527613915706};\\\", \\\"{x:542,y:716,t:1527613915721};\\\", \\\"{x:542,y:715,t:1527613915735};\\\", \\\"{x:543,y:715,t:1527613915751};\\\", \\\"{x:545,y:714,t:1527613915767};\\\", \\\"{x:545,y:713,t:1527613915793};\\\" ] }, { \\\"rt\\\": 203468, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 9, \\\"time_elapsed\\\": 453411, \\\"internal_node_id\\\": \\\"0.0-5.0-4.0\\\", \\\"subject\\\": \\\"TGOML\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"oscar\\\", \\\"condition\\\": \\\"114\\\", \\\"scenario\\\": \\\"acme\\\", \\\"question\\\": \\\"midpoint\\\", \\\"q\\\": 5, \\\"clicks\\\": 2, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XInside-YInside\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 0, \\\"answer\\\": [ \\\"F\\\", \\\"U\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"X \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"U \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-I -I -O -H -01 PM-F -F -F -I -O -O -I -O -O -12 PM-6\\\", \\\"block\\\": \\\"triangular_scaffolded\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:551,y:712,t:1527613952282};\\\", \\\"{x:584,y:698,t:1527613952294};\\\", \\\"{x:718,y:653,t:1527613952313};\\\", \\\"{x:875,y:608,t:1527613952329};\\\", \\\"{x:1045,y:577,t:1527613952344};\\\", \\\"{x:1187,y:568,t:1527613952360};\\\", \\\"{x:1345,y:568,t:1527613952377};\\\", \\\"{x:1439,y:568,t:1527613952394};\\\", \\\"{x:1511,y:568,t:1527613952410};\\\", \\\"{x:1562,y:568,t:1527613952427};\\\", \\\"{x:1586,y:566,t:1527613952444};\\\", \\\"{x:1591,y:565,t:1527613952460};\\\", \\\"{x:1592,y:565,t:1527613952477};\\\", \\\"{x:1593,y:564,t:1527613952504};\\\", \\\"{x:1595,y:563,t:1527613952521};\\\", \\\"{x:1596,y:561,t:1527613952529};\\\", \\\"{x:1599,y:557,t:1527613952545};\\\", \\\"{x:1599,y:553,t:1527613952560};\\\", \\\"{x:1594,y:543,t:1527613952577};\\\", \\\"{x:1564,y:532,t:1527613952594};\\\", \\\"{x:1498,y:515,t:1527613952611};\\\", \\\"{x:1408,y:497,t:1527613952627};\\\", \\\"{x:1346,y:489,t:1527613952644};\\\", \\\"{x:1312,y:483,t:1527613952661};\\\", \\\"{x:1302,y:482,t:1527613952677};\\\", \\\"{x:1301,y:482,t:1527613952826};\\\", \\\"{x:1300,y:484,t:1527613952840};\\\", \\\"{x:1300,y:486,t:1527613952848};\\\", \\\"{x:1300,y:489,t:1527613952861};\\\", \\\"{x:1300,y:494,t:1527613952877};\\\", \\\"{x:1301,y:498,t:1527613952894};\\\", \\\"{x:1303,y:499,t:1527613952911};\\\", \\\"{x:1303,y:500,t:1527613952928};\\\", \\\"{x:1305,y:501,t:1527613952944};\\\", \\\"{x:1308,y:503,t:1527613952961};\\\", \\\"{x:1312,y:504,t:1527613952978};\\\", \\\"{x:1314,y:504,t:1527613952995};\\\", \\\"{x:1319,y:504,t:1527613953011};\\\", \\\"{x:1320,y:504,t:1527613953028};\\\", \\\"{x:1322,y:504,t:1527613953044};\\\", \\\"{x:1324,y:504,t:1527613953061};\\\", \\\"{x:1325,y:504,t:1527613953078};\\\", \\\"{x:1325,y:502,t:1527613953289};\\\", \\\"{x:1324,y:502,t:1527613953313};\\\", \\\"{x:1323,y:501,t:1527613953329};\\\", \\\"{x:1322,y:501,t:1527613953346};\\\", \\\"{x:1321,y:500,t:1527613953361};\\\", \\\"{x:1319,y:500,t:1527613953380};\\\", \\\"{x:1319,y:499,t:1527613953395};\\\", \\\"{x:1318,y:499,t:1527613953457};\\\", \\\"{x:1317,y:498,t:1527613953489};\\\", \\\"{x:1317,y:497,t:1527613953521};\\\", \\\"{x:1316,y:497,t:1527613953537};\\\", \\\"{x:1315,y:496,t:1527613953577};\\\", \\\"{x:1314,y:496,t:1527613953922};\\\", \\\"{x:1311,y:496,t:1527613962857};\\\", \\\"{x:1285,y:506,t:1527613962872};\\\", \\\"{x:1265,y:522,t:1527613962890};\\\", \\\"{x:1252,y:530,t:1527613962905};\\\", \\\"{x:1249,y:533,t:1527613962923};\\\", \\\"{x:1243,y:538,t:1527613962939};\\\", \\\"{x:1225,y:552,t:1527613962956};\\\", \\\"{x:1201,y:572,t:1527613962973};\\\", \\\"{x:1173,y:596,t:1527613962989};\\\", \\\"{x:1160,y:611,t:1527613963006};\\\", \\\"{x:1153,y:622,t:1527613963023};\\\", \\\"{x:1147,y:629,t:1527613963040};\\\", \\\"{x:1135,y:648,t:1527613963056};\\\", \\\"{x:1123,y:669,t:1527613963072};\\\", \\\"{x:1113,y:685,t:1527613963090};\\\", \\\"{x:1106,y:698,t:1527613963107};\\\", \\\"{x:1102,y:706,t:1527613963123};\\\", \\\"{x:1099,y:712,t:1527613963140};\\\", \\\"{x:1098,y:721,t:1527613963157};\\\", \\\"{x:1096,y:730,t:1527613963173};\\\", \\\"{x:1094,y:737,t:1527613963190};\\\", \\\"{x:1092,y:741,t:1527613963207};\\\", \\\"{x:1090,y:743,t:1527613963223};\\\", \\\"{x:1086,y:748,t:1527613963239};\\\", \\\"{x:1083,y:752,t:1527613963257};\\\", \\\"{x:1082,y:753,t:1527613963274};\\\", \\\"{x:1080,y:753,t:1527613963353};\\\", \\\"{x:1079,y:750,t:1527613963361};\\\", \\\"{x:1079,y:748,t:1527613963374};\\\", \\\"{x:1079,y:741,t:1527613963390};\\\", \\\"{x:1077,y:737,t:1527613963407};\\\", \\\"{x:1077,y:736,t:1527613963425};\\\", \\\"{x:1077,y:735,t:1527613963456};\\\", \\\"{x:1077,y:734,t:1527613963473};\\\", \\\"{x:1077,y:733,t:1527613963577};\\\", \\\"{x:1078,y:733,t:1527613963591};\\\", \\\"{x:1080,y:732,t:1527613963606};\\\", \\\"{x:1082,y:731,t:1527613963625};\\\", \\\"{x:1088,y:729,t:1527613963641};\\\", \\\"{x:1090,y:729,t:1527613963657};\\\", \\\"{x:1096,y:727,t:1527613963674};\\\", \\\"{x:1101,y:727,t:1527613963691};\\\", \\\"{x:1109,y:727,t:1527613963707};\\\", \\\"{x:1123,y:727,t:1527613963724};\\\", \\\"{x:1138,y:727,t:1527613963741};\\\", \\\"{x:1149,y:727,t:1527613963757};\\\", \\\"{x:1162,y:729,t:1527613963774};\\\", \\\"{x:1167,y:730,t:1527613963791};\\\", \\\"{x:1173,y:732,t:1527613963808};\\\", \\\"{x:1180,y:734,t:1527613963824};\\\", \\\"{x:1192,y:737,t:1527613963840};\\\", \\\"{x:1202,y:738,t:1527613963857};\\\", \\\"{x:1214,y:739,t:1527613963874};\\\", \\\"{x:1222,y:739,t:1527613963891};\\\", \\\"{x:1227,y:740,t:1527613963907};\\\", \\\"{x:1230,y:741,t:1527613963923};\\\", \\\"{x:1233,y:741,t:1527613963941};\\\", \\\"{x:1234,y:741,t:1527613963958};\\\", \\\"{x:1236,y:741,t:1527613963974};\\\", \\\"{x:1237,y:741,t:1527613963993};\\\", \\\"{x:1238,y:741,t:1527613964009};\\\", \\\"{x:1240,y:741,t:1527613964024};\\\", \\\"{x:1241,y:741,t:1527613964105};\\\", \\\"{x:1243,y:741,t:1527613964121};\\\", \\\"{x:1244,y:741,t:1527613964129};\\\", \\\"{x:1246,y:741,t:1527613964141};\\\", \\\"{x:1247,y:741,t:1527613964158};\\\", \\\"{x:1249,y:741,t:1527613964175};\\\", \\\"{x:1250,y:741,t:1527613964191};\\\", \\\"{x:1252,y:741,t:1527613964209};\\\", \\\"{x:1254,y:741,t:1527613964225};\\\", \\\"{x:1256,y:741,t:1527613964241};\\\", \\\"{x:1261,y:741,t:1527613964257};\\\", \\\"{x:1264,y:741,t:1527613964275};\\\", \\\"{x:1266,y:741,t:1527613964290};\\\", \\\"{x:1267,y:740,t:1527613964307};\\\", \\\"{x:1268,y:740,t:1527613964352};\\\", \\\"{x:1269,y:740,t:1527613964368};\\\", \\\"{x:1270,y:740,t:1527613964376};\\\", \\\"{x:1271,y:740,t:1527613964392};\\\", \\\"{x:1272,y:740,t:1527613964407};\\\", \\\"{x:1273,y:740,t:1527613964425};\\\", \\\"{x:1278,y:740,t:1527613964441};\\\", \\\"{x:1282,y:740,t:1527613964458};\\\", \\\"{x:1288,y:740,t:1527613964475};\\\", \\\"{x:1296,y:738,t:1527613964492};\\\", \\\"{x:1302,y:738,t:1527613964508};\\\", \\\"{x:1307,y:738,t:1527613964525};\\\", \\\"{x:1311,y:737,t:1527613964542};\\\", \\\"{x:1314,y:737,t:1527613964558};\\\", \\\"{x:1316,y:737,t:1527613964593};\\\", \\\"{x:1318,y:736,t:1527613964617};\\\", \\\"{x:1319,y:736,t:1527613964632};\\\", \\\"{x:1320,y:736,t:1527613964641};\\\", \\\"{x:1322,y:736,t:1527613964658};\\\", \\\"{x:1323,y:735,t:1527613964675};\\\", \\\"{x:1324,y:734,t:1527613964705};\\\", \\\"{x:1325,y:734,t:1527613964713};\\\", \\\"{x:1326,y:734,t:1527613964725};\\\", \\\"{x:1327,y:734,t:1527613964742};\\\", \\\"{x:1330,y:734,t:1527613964758};\\\", \\\"{x:1331,y:734,t:1527613964775};\\\", \\\"{x:1332,y:734,t:1527613964792};\\\", \\\"{x:1333,y:734,t:1527613964809};\\\", \\\"{x:1334,y:734,t:1527613964825};\\\", \\\"{x:1335,y:734,t:1527613964842};\\\", \\\"{x:1336,y:734,t:1527613964859};\\\", \\\"{x:1337,y:733,t:1527613964875};\\\", \\\"{x:1338,y:733,t:1527613964892};\\\", \\\"{x:1339,y:733,t:1527613964909};\\\", \\\"{x:1340,y:733,t:1527613964936};\\\", \\\"{x:1341,y:733,t:1527613964945};\\\", \\\"{x:1342,y:732,t:1527613964959};\\\", \\\"{x:1341,y:731,t:1527613973875};\\\", \\\"{x:1333,y:731,t:1527613973890};\\\", \\\"{x:1322,y:731,t:1527613973906};\\\", \\\"{x:1313,y:731,t:1527613973923};\\\", \\\"{x:1302,y:731,t:1527613973940};\\\", \\\"{x:1297,y:731,t:1527613973956};\\\", \\\"{x:1295,y:730,t:1527613973972};\\\", \\\"{x:1294,y:730,t:1527613974028};\\\", \\\"{x:1293,y:730,t:1527613974925};\\\", \\\"{x:1291,y:730,t:1527613979365};\\\", \\\"{x:1289,y:730,t:1527613979379};\\\", \\\"{x:1289,y:731,t:1527613979421};\\\", \\\"{x:1289,y:732,t:1527613982245};\\\", \\\"{x:1290,y:732,t:1527613982260};\\\", \\\"{x:1290,y:734,t:1527613982269};\\\", \\\"{x:1291,y:734,t:1527613982283};\\\", \\\"{x:1293,y:735,t:1527613982300};\\\", \\\"{x:1294,y:736,t:1527613982325};\\\", \\\"{x:1295,y:736,t:1527613982381};\\\", \\\"{x:1296,y:737,t:1527613982397};\\\", \\\"{x:1297,y:737,t:1527613982437};\\\", \\\"{x:1297,y:735,t:1527613983437};\\\", \\\"{x:1297,y:734,t:1527613983452};\\\", \\\"{x:1297,y:733,t:1527613983467};\\\", \\\"{x:1297,y:732,t:1527613983485};\\\", \\\"{x:1297,y:731,t:1527613983669};\\\", \\\"{x:1298,y:730,t:1527613983781};\\\", \\\"{x:1300,y:730,t:1527613984198};\\\", \\\"{x:1302,y:727,t:1527613984204};\\\", \\\"{x:1304,y:727,t:1527613984219};\\\", \\\"{x:1307,y:724,t:1527613984235};\\\", \\\"{x:1317,y:717,t:1527613984252};\\\", \\\"{x:1329,y:698,t:1527613984269};\\\", \\\"{x:1339,y:682,t:1527613984286};\\\", \\\"{x:1344,y:668,t:1527613984301};\\\", \\\"{x:1351,y:652,t:1527613984319};\\\", \\\"{x:1354,y:633,t:1527613984335};\\\", \\\"{x:1354,y:612,t:1527613984352};\\\", \\\"{x:1354,y:597,t:1527613984369};\\\", \\\"{x:1354,y:575,t:1527613984385};\\\", \\\"{x:1352,y:561,t:1527613984403};\\\", \\\"{x:1350,y:549,t:1527613984419};\\\", \\\"{x:1349,y:541,t:1527613984436};\\\", \\\"{x:1347,y:539,t:1527613984451};\\\", \\\"{x:1347,y:538,t:1527613984469};\\\", \\\"{x:1346,y:537,t:1527613984508};\\\", \\\"{x:1345,y:536,t:1527613984525};\\\", \\\"{x:1343,y:535,t:1527613984536};\\\", \\\"{x:1341,y:531,t:1527613984552};\\\", \\\"{x:1339,y:530,t:1527613984568};\\\", \\\"{x:1337,y:528,t:1527613984586};\\\", \\\"{x:1335,y:527,t:1527613984602};\\\", \\\"{x:1333,y:526,t:1527613984618};\\\", \\\"{x:1330,y:524,t:1527613984636};\\\", \\\"{x:1326,y:521,t:1527613984653};\\\", \\\"{x:1324,y:519,t:1527613984668};\\\", \\\"{x:1321,y:518,t:1527613984686};\\\", \\\"{x:1319,y:515,t:1527613984703};\\\", \\\"{x:1317,y:513,t:1527613984719};\\\", \\\"{x:1315,y:511,t:1527613984736};\\\", \\\"{x:1312,y:507,t:1527613984753};\\\", \\\"{x:1311,y:506,t:1527613984769};\\\", \\\"{x:1309,y:503,t:1527613984786};\\\", \\\"{x:1309,y:501,t:1527613984803};\\\", \\\"{x:1309,y:500,t:1527613984819};\\\", \\\"{x:1308,y:499,t:1527613984836};\\\", \\\"{x:1308,y:498,t:1527613984909};\\\", \\\"{x:1307,y:497,t:1527613984989};\\\", \\\"{x:1307,y:503,t:1527613986981};\\\", \\\"{x:1307,y:515,t:1527613986988};\\\", \\\"{x:1307,y:541,t:1527613987004};\\\", \\\"{x:1307,y:564,t:1527613987024};\\\", \\\"{x:1307,y:587,t:1527613987038};\\\", \\\"{x:1310,y:616,t:1527613987054};\\\", \\\"{x:1311,y:649,t:1527613987071};\\\", \\\"{x:1311,y:677,t:1527613987088};\\\", \\\"{x:1308,y:700,t:1527613987104};\\\", \\\"{x:1302,y:716,t:1527613987121};\\\", \\\"{x:1294,y:726,t:1527613987138};\\\", \\\"{x:1288,y:736,t:1527613987154};\\\", \\\"{x:1281,y:743,t:1527613987171};\\\", \\\"{x:1256,y:751,t:1527613987188};\\\", \\\"{x:1246,y:751,t:1527613987205};\\\", \\\"{x:1228,y:751,t:1527613987221};\\\", \\\"{x:1215,y:751,t:1527613987238};\\\", \\\"{x:1206,y:753,t:1527613987254};\\\", \\\"{x:1199,y:755,t:1527613987271};\\\", \\\"{x:1189,y:756,t:1527613987289};\\\", \\\"{x:1173,y:757,t:1527613987305};\\\", \\\"{x:1152,y:761,t:1527613987322};\\\", \\\"{x:1135,y:769,t:1527613987338};\\\", \\\"{x:1123,y:778,t:1527613987356};\\\", \\\"{x:1116,y:782,t:1527613987371};\\\", \\\"{x:1112,y:782,t:1527613987388};\\\", \\\"{x:1110,y:782,t:1527613987405};\\\", \\\"{x:1107,y:782,t:1527613987477};\\\", \\\"{x:1105,y:782,t:1527613987488};\\\", \\\"{x:1099,y:782,t:1527613987505};\\\", \\\"{x:1091,y:780,t:1527613987522};\\\", \\\"{x:1086,y:780,t:1527613987539};\\\", \\\"{x:1077,y:778,t:1527613987556};\\\", \\\"{x:1069,y:777,t:1527613987572};\\\", \\\"{x:1066,y:776,t:1527613987589};\\\", \\\"{x:1065,y:776,t:1527613987669};\\\", \\\"{x:1065,y:775,t:1527613987693};\\\", \\\"{x:1065,y:774,t:1527613987708};\\\", \\\"{x:1065,y:773,t:1527613987732};\\\", \\\"{x:1066,y:773,t:1527613987797};\\\", \\\"{x:1066,y:772,t:1527613987813};\\\", \\\"{x:1067,y:771,t:1527613987824};\\\", \\\"{x:1068,y:771,t:1527613987844};\\\", \\\"{x:1069,y:770,t:1527613987876};\\\", \\\"{x:1071,y:770,t:1527613987899};\\\", \\\"{x:1073,y:768,t:1527613987923};\\\", \\\"{x:1074,y:767,t:1527613987948};\\\", \\\"{x:1074,y:766,t:1527613987964};\\\", \\\"{x:1076,y:765,t:1527613987971};\\\", \\\"{x:1078,y:764,t:1527613987996};\\\", \\\"{x:1078,y:763,t:1527613988005};\\\", \\\"{x:1080,y:761,t:1527613988023};\\\", \\\"{x:1082,y:760,t:1527613988040};\\\", \\\"{x:1083,y:759,t:1527613988056};\\\", \\\"{x:1084,y:756,t:1527613988072};\\\", \\\"{x:1085,y:755,t:1527613988090};\\\", \\\"{x:1085,y:753,t:1527613988106};\\\", \\\"{x:1085,y:752,t:1527613988123};\\\", \\\"{x:1086,y:750,t:1527613988139};\\\", \\\"{x:1086,y:748,t:1527613988156};\\\", \\\"{x:1086,y:747,t:1527613988173};\\\", \\\"{x:1086,y:745,t:1527613988190};\\\", \\\"{x:1087,y:744,t:1527613988207};\\\", \\\"{x:1087,y:743,t:1527613988224};\\\", \\\"{x:1087,y:742,t:1527613988240};\\\", \\\"{x:1087,y:741,t:1527613988257};\\\", \\\"{x:1087,y:740,t:1527613988292};\\\", \\\"{x:1087,y:739,t:1527613988332};\\\", \\\"{x:1087,y:738,t:1527613988348};\\\", \\\"{x:1087,y:737,t:1527613988380};\\\", \\\"{x:1087,y:736,t:1527613988390};\\\", \\\"{x:1087,y:735,t:1527613988407};\\\", \\\"{x:1087,y:734,t:1527613988424};\\\", \\\"{x:1086,y:734,t:1527613988440};\\\", \\\"{x:1086,y:732,t:1527613988461};\\\", \\\"{x:1085,y:731,t:1527613988484};\\\", \\\"{x:1084,y:730,t:1527613988524};\\\", \\\"{x:1084,y:729,t:1527613988669};\\\", \\\"{x:1084,y:728,t:1527613988813};\\\", \\\"{x:1084,y:727,t:1527613988835};\\\", \\\"{x:1086,y:725,t:1527613988852};\\\", \\\"{x:1087,y:725,t:1527613988861};\\\", \\\"{x:1088,y:725,t:1527613988873};\\\", \\\"{x:1091,y:725,t:1527613988891};\\\", \\\"{x:1093,y:724,t:1527613988907};\\\", \\\"{x:1095,y:723,t:1527613988924};\\\", \\\"{x:1097,y:723,t:1527613988941};\\\", \\\"{x:1101,y:723,t:1527613988956};\\\", \\\"{x:1105,y:723,t:1527613988974};\\\", \\\"{x:1111,y:723,t:1527613988991};\\\", \\\"{x:1118,y:723,t:1527613989007};\\\", \\\"{x:1128,y:723,t:1527613989024};\\\", \\\"{x:1137,y:725,t:1527613989041};\\\", \\\"{x:1143,y:726,t:1527613989058};\\\", \\\"{x:1146,y:726,t:1527613989074};\\\", \\\"{x:1148,y:726,t:1527613989091};\\\", \\\"{x:1149,y:726,t:1527613989108};\\\", \\\"{x:1151,y:726,t:1527613989124};\\\", \\\"{x:1158,y:727,t:1527613989140};\\\", \\\"{x:1162,y:727,t:1527613989158};\\\", \\\"{x:1164,y:727,t:1527613989174};\\\", \\\"{x:1165,y:727,t:1527613989191};\\\", \\\"{x:1166,y:727,t:1527613989208};\\\", \\\"{x:1170,y:727,t:1527613989224};\\\", \\\"{x:1173,y:727,t:1527613989240};\\\", \\\"{x:1179,y:727,t:1527613989258};\\\", \\\"{x:1184,y:727,t:1527613989274};\\\", \\\"{x:1186,y:727,t:1527613989291};\\\", \\\"{x:1190,y:727,t:1527613989308};\\\", \\\"{x:1191,y:727,t:1527613989325};\\\", \\\"{x:1195,y:727,t:1527613989341};\\\", \\\"{x:1200,y:727,t:1527613989358};\\\", \\\"{x:1205,y:727,t:1527613989375};\\\", \\\"{x:1212,y:727,t:1527613989391};\\\", \\\"{x:1217,y:727,t:1527613989408};\\\", \\\"{x:1221,y:727,t:1527613989425};\\\", \\\"{x:1224,y:727,t:1527613989441};\\\", \\\"{x:1226,y:727,t:1527613989458};\\\", \\\"{x:1227,y:727,t:1527613989477};\\\", \\\"{x:1229,y:727,t:1527613989501};\\\", \\\"{x:1231,y:727,t:1527613989508};\\\", \\\"{x:1234,y:727,t:1527613989525};\\\", \\\"{x:1237,y:727,t:1527613989541};\\\", \\\"{x:1239,y:727,t:1527613989558};\\\", \\\"{x:1240,y:727,t:1527613989575};\\\", \\\"{x:1242,y:727,t:1527613989591};\\\", \\\"{x:1245,y:727,t:1527613989608};\\\", \\\"{x:1250,y:727,t:1527613989625};\\\", \\\"{x:1258,y:727,t:1527613989642};\\\", \\\"{x:1267,y:727,t:1527613989657};\\\", \\\"{x:1272,y:727,t:1527613989674};\\\", \\\"{x:1277,y:727,t:1527613989692};\\\", \\\"{x:1279,y:727,t:1527613989707};\\\", \\\"{x:1281,y:727,t:1527613989725};\\\", \\\"{x:1283,y:727,t:1527613989742};\\\", \\\"{x:1284,y:727,t:1527613989758};\\\", \\\"{x:1285,y:727,t:1527613989796};\\\", \\\"{x:1286,y:727,t:1527613989821};\\\", \\\"{x:1287,y:727,t:1527613989836};\\\", \\\"{x:1289,y:727,t:1527613989901};\\\", \\\"{x:1290,y:727,t:1527613989909};\\\", \\\"{x:1291,y:727,t:1527613989924};\\\", \\\"{x:1294,y:727,t:1527613989942};\\\", \\\"{x:1297,y:729,t:1527613989959};\\\", \\\"{x:1299,y:729,t:1527613989976};\\\", \\\"{x:1301,y:729,t:1527613989992};\\\", \\\"{x:1303,y:729,t:1527613990009};\\\", \\\"{x:1304,y:729,t:1527613990025};\\\", \\\"{x:1307,y:730,t:1527613990041};\\\", \\\"{x:1310,y:730,t:1527613990059};\\\", \\\"{x:1311,y:730,t:1527613990075};\\\", \\\"{x:1313,y:731,t:1527613990092};\\\", \\\"{x:1314,y:731,t:1527613990109};\\\", \\\"{x:1315,y:731,t:1527613990140};\\\", \\\"{x:1316,y:731,t:1527613990156};\\\", \\\"{x:1317,y:731,t:1527613990181};\\\", \\\"{x:1318,y:731,t:1527613990245};\\\", \\\"{x:1319,y:731,t:1527613990293};\\\", \\\"{x:1320,y:731,t:1527613990317};\\\", \\\"{x:1321,y:731,t:1527613990389};\\\", \\\"{x:1323,y:731,t:1527613991813};\\\", \\\"{x:1324,y:730,t:1527613991827};\\\", \\\"{x:1328,y:729,t:1527613991844};\\\", \\\"{x:1330,y:728,t:1527613991861};\\\", \\\"{x:1332,y:728,t:1527613991877};\\\", \\\"{x:1335,y:728,t:1527613991894};\\\", \\\"{x:1338,y:728,t:1527613991911};\\\", \\\"{x:1339,y:728,t:1527613991927};\\\", \\\"{x:1341,y:728,t:1527613991944};\\\", \\\"{x:1342,y:728,t:1527613991961};\\\", \\\"{x:1343,y:727,t:1527613991981};\\\", \\\"{x:1343,y:726,t:1527613991996};\\\", \\\"{x:1345,y:726,t:1527613992012};\\\", \\\"{x:1347,y:726,t:1527613992028};\\\", \\\"{x:1349,y:726,t:1527613992045};\\\", \\\"{x:1353,y:726,t:1527613992061};\\\", \\\"{x:1354,y:726,t:1527613992085};\\\", \\\"{x:1355,y:726,t:1527613992101};\\\", \\\"{x:1356,y:726,t:1527613992111};\\\", \\\"{x:1362,y:727,t:1527613992128};\\\", \\\"{x:1373,y:728,t:1527613992144};\\\", \\\"{x:1385,y:732,t:1527613992161};\\\", \\\"{x:1396,y:736,t:1527613992178};\\\", \\\"{x:1401,y:736,t:1527613992194};\\\", \\\"{x:1403,y:736,t:1527613992210};\\\", \\\"{x:1404,y:736,t:1527613992253};\\\", \\\"{x:1405,y:736,t:1527613992292};\\\", \\\"{x:1406,y:736,t:1527613992309};\\\", \\\"{x:1407,y:736,t:1527613992340};\\\", \\\"{x:1408,y:736,t:1527613992428};\\\", \\\"{x:1409,y:736,t:1527613992508};\\\", \\\"{x:1410,y:736,t:1527613992516};\\\", \\\"{x:1411,y:736,t:1527613992531};\\\", \\\"{x:1413,y:736,t:1527613992548};\\\", \\\"{x:1414,y:736,t:1527613992564};\\\", \\\"{x:1415,y:736,t:1527613992637};\\\", \\\"{x:1416,y:736,t:1527613992645};\\\", \\\"{x:1417,y:736,t:1527613992669};\\\", \\\"{x:1418,y:736,t:1527613992685};\\\", \\\"{x:1418,y:735,t:1527613996141};\\\", \\\"{x:1418,y:733,t:1527614006309};\\\", \\\"{x:1418,y:732,t:1527614006324};\\\", \\\"{x:1418,y:731,t:1527614006340};\\\", \\\"{x:1417,y:730,t:1527614006348};\\\", \\\"{x:1416,y:729,t:1527614006360};\\\", \\\"{x:1416,y:727,t:1527614006388};\\\", \\\"{x:1415,y:727,t:1527614006412};\\\", \\\"{x:1415,y:726,t:1527614006444};\\\", \\\"{x:1415,y:724,t:1527614006532};\\\", \\\"{x:1415,y:723,t:1527614006556};\\\", \\\"{x:1414,y:722,t:1527614006564};\\\", \\\"{x:1414,y:721,t:1527614006636};\\\", \\\"{x:1418,y:713,t:1527614023036};\\\", \\\"{x:1430,y:695,t:1527614023047};\\\", \\\"{x:1459,y:648,t:1527614023063};\\\", \\\"{x:1481,y:588,t:1527614023080};\\\", \\\"{x:1488,y:539,t:1527614023097};\\\", \\\"{x:1489,y:527,t:1527614023113};\\\", \\\"{x:1489,y:525,t:1527614023130};\\\", \\\"{x:1489,y:524,t:1527614023147};\\\", \\\"{x:1487,y:524,t:1527614023483};\\\", \\\"{x:1479,y:529,t:1527614023496};\\\", \\\"{x:1464,y:541,t:1527614023514};\\\", \\\"{x:1456,y:548,t:1527614023530};\\\", \\\"{x:1449,y:554,t:1527614023547};\\\", \\\"{x:1445,y:556,t:1527614023564};\\\", \\\"{x:1443,y:557,t:1527614023580};\\\", \\\"{x:1443,y:558,t:1527614023597};\\\", \\\"{x:1440,y:559,t:1527614023614};\\\", \\\"{x:1435,y:562,t:1527614023631};\\\", \\\"{x:1431,y:565,t:1527614023648};\\\", \\\"{x:1428,y:566,t:1527614023664};\\\", \\\"{x:1427,y:567,t:1527614023681};\\\", \\\"{x:1425,y:568,t:1527614023740};\\\", \\\"{x:1423,y:569,t:1527614023746};\\\", \\\"{x:1421,y:570,t:1527614023763};\\\", \\\"{x:1419,y:570,t:1527614023780};\\\", \\\"{x:1418,y:572,t:1527614023798};\\\", \\\"{x:1417,y:572,t:1527614023842};\\\", \\\"{x:1416,y:572,t:1527614023899};\\\", \\\"{x:1415,y:572,t:1527614024268};\\\", \\\"{x:1415,y:571,t:1527614024284};\\\", \\\"{x:1414,y:571,t:1527614024298};\\\", \\\"{x:1414,y:570,t:1527614024339};\\\", \\\"{x:1414,y:569,t:1527614024564};\\\", \\\"{x:1414,y:567,t:1527614024583};\\\", \\\"{x:1414,y:566,t:1527614024599};\\\", \\\"{x:1414,y:565,t:1527614024615};\\\", \\\"{x:1414,y:564,t:1527614024632};\\\", \\\"{x:1408,y:563,t:1527614033007};\\\", \\\"{x:1402,y:561,t:1527614033013};\\\", \\\"{x:1397,y:560,t:1527614033028};\\\", \\\"{x:1389,y:556,t:1527614033044};\\\", \\\"{x:1384,y:554,t:1527614033061};\\\", \\\"{x:1381,y:553,t:1527614033078};\\\", \\\"{x:1380,y:553,t:1527614033095};\\\", \\\"{x:1380,y:552,t:1527614033111};\\\", \\\"{x:1379,y:551,t:1527614033128};\\\", \\\"{x:1378,y:550,t:1527614033145};\\\", \\\"{x:1376,y:549,t:1527614033161};\\\", \\\"{x:1375,y:547,t:1527614033179};\\\", \\\"{x:1373,y:546,t:1527614033195};\\\", \\\"{x:1372,y:545,t:1527614033211};\\\", \\\"{x:1370,y:544,t:1527614033229};\\\", \\\"{x:1368,y:543,t:1527614033245};\\\", \\\"{x:1367,y:541,t:1527614033261};\\\", \\\"{x:1361,y:539,t:1527614033278};\\\", \\\"{x:1355,y:536,t:1527614033296};\\\", \\\"{x:1344,y:531,t:1527614033311};\\\", \\\"{x:1335,y:528,t:1527614033328};\\\", \\\"{x:1323,y:524,t:1527614033346};\\\", \\\"{x:1319,y:522,t:1527614033362};\\\", \\\"{x:1315,y:520,t:1527614033379};\\\", \\\"{x:1314,y:519,t:1527614033396};\\\", \\\"{x:1311,y:517,t:1527614033411};\\\", \\\"{x:1309,y:515,t:1527614033429};\\\", \\\"{x:1307,y:513,t:1527614033446};\\\", \\\"{x:1305,y:510,t:1527614033463};\\\", \\\"{x:1304,y:509,t:1527614033478};\\\", \\\"{x:1303,y:508,t:1527614033495};\\\", \\\"{x:1303,y:507,t:1527614033513};\\\", \\\"{x:1303,y:506,t:1527614033529};\\\", \\\"{x:1303,y:505,t:1527614033546};\\\", \\\"{x:1303,y:504,t:1527614033562};\\\", \\\"{x:1302,y:502,t:1527614033578};\\\", \\\"{x:1302,y:501,t:1527614033596};\\\", \\\"{x:1304,y:504,t:1527614033759};\\\", \\\"{x:1304,y:507,t:1527614033767};\\\", \\\"{x:1305,y:509,t:1527614033779};\\\", \\\"{x:1306,y:515,t:1527614033796};\\\", \\\"{x:1306,y:517,t:1527614033813};\\\", \\\"{x:1306,y:520,t:1527614033830};\\\", \\\"{x:1306,y:527,t:1527614033846};\\\", \\\"{x:1306,y:545,t:1527614033863};\\\", \\\"{x:1310,y:560,t:1527614033880};\\\", \\\"{x:1311,y:570,t:1527614033896};\\\", \\\"{x:1313,y:576,t:1527614033912};\\\", \\\"{x:1313,y:581,t:1527614033929};\\\", \\\"{x:1315,y:586,t:1527614033947};\\\", \\\"{x:1318,y:594,t:1527614033962};\\\", \\\"{x:1319,y:602,t:1527614033979};\\\", \\\"{x:1320,y:610,t:1527614033997};\\\", \\\"{x:1322,y:617,t:1527614034013};\\\", \\\"{x:1322,y:622,t:1527614034029};\\\", \\\"{x:1324,y:632,t:1527614034046};\\\", \\\"{x:1327,y:641,t:1527614034062};\\\", \\\"{x:1328,y:650,t:1527614034080};\\\", \\\"{x:1329,y:658,t:1527614034097};\\\", \\\"{x:1329,y:663,t:1527614034113};\\\", \\\"{x:1329,y:668,t:1527614034130};\\\", \\\"{x:1329,y:672,t:1527614034146};\\\", \\\"{x:1327,y:676,t:1527614034162};\\\", \\\"{x:1326,y:681,t:1527614034179};\\\", \\\"{x:1322,y:689,t:1527614034196};\\\", \\\"{x:1317,y:697,t:1527614034212};\\\", \\\"{x:1314,y:706,t:1527614034230};\\\", \\\"{x:1310,y:715,t:1527614034246};\\\", \\\"{x:1308,y:720,t:1527614034262};\\\", \\\"{x:1306,y:725,t:1527614034280};\\\", \\\"{x:1304,y:731,t:1527614034297};\\\", \\\"{x:1303,y:735,t:1527614034312};\\\", \\\"{x:1302,y:738,t:1527614034329};\\\", \\\"{x:1301,y:743,t:1527614034347};\\\", \\\"{x:1299,y:746,t:1527614034364};\\\", \\\"{x:1298,y:750,t:1527614034379};\\\", \\\"{x:1297,y:754,t:1527614034397};\\\", \\\"{x:1297,y:757,t:1527614034414};\\\", \\\"{x:1295,y:761,t:1527614034429};\\\", \\\"{x:1295,y:765,t:1527614034447};\\\", \\\"{x:1295,y:769,t:1527614034463};\\\", \\\"{x:1295,y:772,t:1527614034479};\\\", \\\"{x:1296,y:778,t:1527614034496};\\\", \\\"{x:1298,y:786,t:1527614034514};\\\", \\\"{x:1300,y:796,t:1527614034530};\\\", \\\"{x:1304,y:805,t:1527614034547};\\\", \\\"{x:1305,y:808,t:1527614034563};\\\", \\\"{x:1306,y:812,t:1527614034580};\\\", \\\"{x:1306,y:815,t:1527614034597};\\\", \\\"{x:1306,y:818,t:1527614034614};\\\", \\\"{x:1306,y:822,t:1527614034630};\\\", \\\"{x:1308,y:831,t:1527614034646};\\\", \\\"{x:1312,y:840,t:1527614034664};\\\", \\\"{x:1313,y:844,t:1527614034681};\\\", \\\"{x:1314,y:847,t:1527614034697};\\\", \\\"{x:1315,y:848,t:1527614034714};\\\", \\\"{x:1316,y:850,t:1527614034731};\\\", \\\"{x:1316,y:854,t:1527614034747};\\\", \\\"{x:1317,y:857,t:1527614034764};\\\", \\\"{x:1317,y:861,t:1527614034781};\\\", \\\"{x:1319,y:864,t:1527614034797};\\\", \\\"{x:1319,y:867,t:1527614034814};\\\", \\\"{x:1321,y:872,t:1527614034831};\\\", \\\"{x:1321,y:875,t:1527614034847};\\\", \\\"{x:1321,y:877,t:1527614034864};\\\", \\\"{x:1321,y:881,t:1527614034881};\\\", \\\"{x:1322,y:884,t:1527614034898};\\\", \\\"{x:1323,y:888,t:1527614034914};\\\", \\\"{x:1323,y:892,t:1527614034931};\\\", \\\"{x:1323,y:895,t:1527614034948};\\\", \\\"{x:1323,y:898,t:1527614034964};\\\", \\\"{x:1324,y:900,t:1527614034981};\\\", \\\"{x:1325,y:902,t:1527614034998};\\\", \\\"{x:1326,y:905,t:1527614035023};\\\", \\\"{x:1326,y:907,t:1527614035031};\\\", \\\"{x:1326,y:908,t:1527614035048};\\\", \\\"{x:1326,y:909,t:1527614035064};\\\", \\\"{x:1341,y:892,t:1527614035823};\\\", \\\"{x:1362,y:864,t:1527614035832};\\\", \\\"{x:1402,y:786,t:1527614035849};\\\", \\\"{x:1434,y:711,t:1527614035865};\\\", \\\"{x:1458,y:654,t:1527614035882};\\\", \\\"{x:1475,y:608,t:1527614035899};\\\", \\\"{x:1498,y:565,t:1527614035915};\\\", \\\"{x:1516,y:528,t:1527614035932};\\\", \\\"{x:1529,y:506,t:1527614035949};\\\", \\\"{x:1533,y:493,t:1527614035965};\\\", \\\"{x:1534,y:482,t:1527614035982};\\\", \\\"{x:1534,y:469,t:1527614035999};\\\", \\\"{x:1532,y:463,t:1527614036015};\\\", \\\"{x:1529,y:458,t:1527614036032};\\\", \\\"{x:1521,y:455,t:1527614036049};\\\", \\\"{x:1509,y:455,t:1527614036065};\\\", \\\"{x:1492,y:460,t:1527614036082};\\\", \\\"{x:1477,y:469,t:1527614036099};\\\", \\\"{x:1467,y:483,t:1527614036116};\\\", \\\"{x:1462,y:497,t:1527614036132};\\\", \\\"{x:1457,y:513,t:1527614036149};\\\", \\\"{x:1455,y:530,t:1527614036166};\\\", \\\"{x:1452,y:549,t:1527614036182};\\\", \\\"{x:1451,y:577,t:1527614036199};\\\", \\\"{x:1450,y:595,t:1527614036216};\\\", \\\"{x:1450,y:608,t:1527614036232};\\\", \\\"{x:1449,y:617,t:1527614036249};\\\", \\\"{x:1449,y:621,t:1527614036266};\\\", \\\"{x:1448,y:621,t:1527614036282};\\\", \\\"{x:1447,y:624,t:1527614036299};\\\", \\\"{x:1446,y:627,t:1527614036316};\\\", \\\"{x:1444,y:632,t:1527614036332};\\\", \\\"{x:1443,y:638,t:1527614036349};\\\", \\\"{x:1440,y:646,t:1527614036366};\\\", \\\"{x:1438,y:653,t:1527614036383};\\\", \\\"{x:1436,y:666,t:1527614036399};\\\", \\\"{x:1433,y:674,t:1527614036416};\\\", \\\"{x:1429,y:683,t:1527614036433};\\\", \\\"{x:1427,y:692,t:1527614036449};\\\", \\\"{x:1426,y:696,t:1527614036466};\\\", \\\"{x:1425,y:699,t:1527614036483};\\\", \\\"{x:1425,y:701,t:1527614036499};\\\", \\\"{x:1422,y:708,t:1527614036516};\\\", \\\"{x:1421,y:714,t:1527614036533};\\\", \\\"{x:1419,y:722,t:1527614036549};\\\", \\\"{x:1417,y:726,t:1527614036566};\\\", \\\"{x:1417,y:730,t:1527614036583};\\\", \\\"{x:1415,y:734,t:1527614036598};\\\", \\\"{x:1415,y:741,t:1527614036617};\\\", \\\"{x:1414,y:749,t:1527614036633};\\\", \\\"{x:1413,y:755,t:1527614036649};\\\", \\\"{x:1412,y:760,t:1527614036666};\\\", \\\"{x:1412,y:762,t:1527614036683};\\\", \\\"{x:1412,y:766,t:1527614036700};\\\", \\\"{x:1412,y:774,t:1527614036716};\\\", \\\"{x:1410,y:788,t:1527614036734};\\\", \\\"{x:1410,y:803,t:1527614036750};\\\", \\\"{x:1410,y:812,t:1527614036766};\\\", \\\"{x:1410,y:817,t:1527614036783};\\\", \\\"{x:1410,y:822,t:1527614036800};\\\", \\\"{x:1410,y:830,t:1527614036816};\\\", \\\"{x:1410,y:845,t:1527614036834};\\\", \\\"{x:1410,y:863,t:1527614036850};\\\", \\\"{x:1410,y:874,t:1527614036866};\\\", \\\"{x:1409,y:882,t:1527614036883};\\\", \\\"{x:1408,y:890,t:1527614036900};\\\", \\\"{x:1406,y:902,t:1527614036916};\\\", \\\"{x:1405,y:913,t:1527614036933};\\\", \\\"{x:1405,y:928,t:1527614036950};\\\", \\\"{x:1405,y:944,t:1527614036967};\\\", \\\"{x:1406,y:947,t:1527614036983};\\\", \\\"{x:1406,y:948,t:1527614037000};\\\", \\\"{x:1407,y:948,t:1527614037018};\\\", \\\"{x:1407,y:949,t:1527614037033};\\\", \\\"{x:1410,y:953,t:1527614037049};\\\", \\\"{x:1413,y:957,t:1527614037067};\\\", \\\"{x:1414,y:960,t:1527614037083};\\\", \\\"{x:1415,y:963,t:1527614037100};\\\", \\\"{x:1416,y:963,t:1527614037116};\\\", \\\"{x:1417,y:964,t:1527614037182};\\\", \\\"{x:1417,y:965,t:1527614037223};\\\", \\\"{x:1417,y:966,t:1527614037238};\\\", \\\"{x:1417,y:967,t:1527614037279};\\\", \\\"{x:1417,y:968,t:1527614037287};\\\", \\\"{x:1418,y:969,t:1527614037300};\\\", \\\"{x:1420,y:971,t:1527614037335};\\\", \\\"{x:1421,y:971,t:1527614038094};\\\", \\\"{x:1421,y:970,t:1527614038494};\\\", \\\"{x:1421,y:969,t:1527614039167};\\\", \\\"{x:1420,y:968,t:1527614039327};\\\", \\\"{x:1420,y:967,t:1527614039343};\\\", \\\"{x:1418,y:966,t:1527614040775};\\\", \\\"{x:1417,y:964,t:1527614040788};\\\", \\\"{x:1415,y:960,t:1527614040804};\\\", \\\"{x:1415,y:958,t:1527614040821};\\\", \\\"{x:1413,y:952,t:1527614040838};\\\", \\\"{x:1412,y:951,t:1527614040854};\\\", \\\"{x:1411,y:947,t:1527614040871};\\\", \\\"{x:1410,y:944,t:1527614040888};\\\", \\\"{x:1409,y:942,t:1527614040904};\\\", \\\"{x:1409,y:940,t:1527614040921};\\\", \\\"{x:1409,y:939,t:1527614040938};\\\", \\\"{x:1408,y:937,t:1527614040953};\\\", \\\"{x:1408,y:936,t:1527614040971};\\\", \\\"{x:1408,y:935,t:1527614041005};\\\", \\\"{x:1408,y:932,t:1527614041215};\\\", \\\"{x:1408,y:928,t:1527614041223};\\\", \\\"{x:1406,y:923,t:1527614041239};\\\", \\\"{x:1404,y:902,t:1527614041254};\\\", \\\"{x:1401,y:884,t:1527614041271};\\\", \\\"{x:1398,y:866,t:1527614041288};\\\", \\\"{x:1393,y:846,t:1527614041305};\\\", \\\"{x:1389,y:826,t:1527614041321};\\\", \\\"{x:1385,y:815,t:1527614041338};\\\", \\\"{x:1383,y:809,t:1527614041355};\\\", \\\"{x:1383,y:807,t:1527614041371};\\\", \\\"{x:1382,y:802,t:1527614041387};\\\", \\\"{x:1381,y:799,t:1527614041405};\\\", \\\"{x:1379,y:794,t:1527614041421};\\\", \\\"{x:1377,y:790,t:1527614041438};\\\", \\\"{x:1376,y:788,t:1527614041455};\\\", \\\"{x:1376,y:787,t:1527614041472};\\\", \\\"{x:1376,y:786,t:1527614041559};\\\", \\\"{x:1376,y:785,t:1527614041572};\\\", \\\"{x:1374,y:783,t:1527614041588};\\\", \\\"{x:1373,y:776,t:1527614041605};\\\", \\\"{x:1372,y:765,t:1527614041622};\\\", \\\"{x:1368,y:754,t:1527614041638};\\\", \\\"{x:1368,y:749,t:1527614041654};\\\", \\\"{x:1366,y:745,t:1527614041672};\\\", \\\"{x:1366,y:744,t:1527614041688};\\\", \\\"{x:1366,y:743,t:1527614041705};\\\", \\\"{x:1365,y:743,t:1527614041751};\\\", \\\"{x:1365,y:747,t:1527614041855};\\\", \\\"{x:1374,y:770,t:1527614041872};\\\", \\\"{x:1384,y:789,t:1527614041888};\\\", \\\"{x:1395,y:801,t:1527614041904};\\\", \\\"{x:1403,y:806,t:1527614041921};\\\", \\\"{x:1405,y:806,t:1527614041939};\\\", \\\"{x:1406,y:806,t:1527614041954};\\\", \\\"{x:1407,y:806,t:1527614041971};\\\", \\\"{x:1407,y:804,t:1527614041989};\\\", \\\"{x:1409,y:797,t:1527614042005};\\\", \\\"{x:1411,y:793,t:1527614042022};\\\", \\\"{x:1414,y:786,t:1527614042039};\\\", \\\"{x:1415,y:783,t:1527614042055};\\\", \\\"{x:1415,y:779,t:1527614042072};\\\", \\\"{x:1415,y:777,t:1527614042089};\\\", \\\"{x:1415,y:776,t:1527614042105};\\\", \\\"{x:1415,y:775,t:1527614042121};\\\", \\\"{x:1415,y:774,t:1527614042138};\\\", \\\"{x:1415,y:773,t:1527614042158};\\\", \\\"{x:1415,y:772,t:1527614042174};\\\", \\\"{x:1414,y:772,t:1527614042189};\\\", \\\"{x:1409,y:771,t:1527614042206};\\\", \\\"{x:1402,y:770,t:1527614042222};\\\", \\\"{x:1394,y:768,t:1527614042239};\\\", \\\"{x:1389,y:766,t:1527614042256};\\\", \\\"{x:1386,y:766,t:1527614042272};\\\", \\\"{x:1383,y:766,t:1527614042289};\\\", \\\"{x:1382,y:766,t:1527614042327};\\\", \\\"{x:1382,y:765,t:1527614042735};\\\", \\\"{x:1381,y:763,t:1527614042767};\\\", \\\"{x:1381,y:762,t:1527614042990};\\\", \\\"{x:1381,y:761,t:1527614043006};\\\", \\\"{x:1381,y:760,t:1527614043029};\\\", \\\"{x:1381,y:766,t:1527614043375};\\\", \\\"{x:1381,y:778,t:1527614043391};\\\", \\\"{x:1381,y:816,t:1527614043407};\\\", \\\"{x:1381,y:842,t:1527614043424};\\\", \\\"{x:1381,y:868,t:1527614043441};\\\", \\\"{x:1382,y:890,t:1527614043457};\\\", \\\"{x:1383,y:906,t:1527614043474};\\\", \\\"{x:1383,y:921,t:1527614043489};\\\", \\\"{x:1383,y:935,t:1527614043507};\\\", \\\"{x:1383,y:946,t:1527614043524};\\\", \\\"{x:1385,y:958,t:1527614043541};\\\", \\\"{x:1385,y:963,t:1527614043557};\\\", \\\"{x:1385,y:965,t:1527614043575};\\\", \\\"{x:1385,y:966,t:1527614043623};\\\", \\\"{x:1386,y:967,t:1527614043631};\\\", \\\"{x:1386,y:968,t:1527614043641};\\\", \\\"{x:1386,y:969,t:1527614043657};\\\", \\\"{x:1386,y:968,t:1527614043815};\\\", \\\"{x:1386,y:966,t:1527614043824};\\\", \\\"{x:1386,y:964,t:1527614043841};\\\", \\\"{x:1386,y:962,t:1527614043857};\\\", \\\"{x:1386,y:959,t:1527614043873};\\\", \\\"{x:1386,y:956,t:1527614043894};\\\", \\\"{x:1386,y:953,t:1527614043910};\\\", \\\"{x:1386,y:952,t:1527614043924};\\\", \\\"{x:1386,y:946,t:1527614043941};\\\", \\\"{x:1386,y:936,t:1527614043957};\\\", \\\"{x:1386,y:929,t:1527614043974};\\\", \\\"{x:1386,y:924,t:1527614043991};\\\", \\\"{x:1387,y:917,t:1527614044008};\\\", \\\"{x:1387,y:914,t:1527614044024};\\\", \\\"{x:1389,y:906,t:1527614044041};\\\", \\\"{x:1390,y:897,t:1527614044059};\\\", \\\"{x:1392,y:883,t:1527614044074};\\\", \\\"{x:1392,y:872,t:1527614044091};\\\", \\\"{x:1392,y:864,t:1527614044108};\\\", \\\"{x:1392,y:855,t:1527614044125};\\\", \\\"{x:1392,y:850,t:1527614044141};\\\", \\\"{x:1392,y:845,t:1527614044159};\\\", \\\"{x:1394,y:842,t:1527614044175};\\\", \\\"{x:1394,y:839,t:1527614044192};\\\", \\\"{x:1394,y:834,t:1527614044208};\\\", \\\"{x:1394,y:830,t:1527614044225};\\\", \\\"{x:1394,y:824,t:1527614044242};\\\", \\\"{x:1394,y:818,t:1527614044258};\\\", \\\"{x:1394,y:812,t:1527614044275};\\\", \\\"{x:1394,y:804,t:1527614044291};\\\", \\\"{x:1394,y:793,t:1527614044308};\\\", \\\"{x:1393,y:779,t:1527614044325};\\\", \\\"{x:1391,y:770,t:1527614044341};\\\", \\\"{x:1390,y:762,t:1527614044359};\\\", \\\"{x:1389,y:758,t:1527614044375};\\\", \\\"{x:1389,y:757,t:1527614044431};\\\", \\\"{x:1389,y:756,t:1527614044442};\\\", \\\"{x:1389,y:755,t:1527614044459};\\\", \\\"{x:1389,y:753,t:1527614044476};\\\", \\\"{x:1389,y:752,t:1527614044495};\\\", \\\"{x:1388,y:752,t:1527614044527};\\\", \\\"{x:1388,y:751,t:1527614044542};\\\", \\\"{x:1388,y:748,t:1527614044559};\\\", \\\"{x:1388,y:746,t:1527614044575};\\\", \\\"{x:1386,y:745,t:1527614044592};\\\", \\\"{x:1386,y:743,t:1527614044623};\\\", \\\"{x:1385,y:745,t:1527614045311};\\\", \\\"{x:1384,y:748,t:1527614045327};\\\", \\\"{x:1383,y:752,t:1527614045343};\\\", \\\"{x:1383,y:753,t:1527614045359};\\\", \\\"{x:1382,y:754,t:1527614045376};\\\", \\\"{x:1382,y:756,t:1527614045550};\\\", \\\"{x:1382,y:757,t:1527614045630};\\\", \\\"{x:1382,y:758,t:1527614045643};\\\", \\\"{x:1382,y:761,t:1527614045659};\\\", \\\"{x:1382,y:762,t:1527614045676};\\\", \\\"{x:1382,y:763,t:1527614045806};\\\", \\\"{x:1382,y:764,t:1527614045814};\\\", \\\"{x:1382,y:767,t:1527614046919};\\\", \\\"{x:1382,y:772,t:1527614046930};\\\", \\\"{x:1381,y:773,t:1527614046944};\\\", \\\"{x:1381,y:774,t:1527614046961};\\\", \\\"{x:1381,y:776,t:1527614047086};\\\", \\\"{x:1381,y:780,t:1527614047094};\\\", \\\"{x:1381,y:785,t:1527614047110};\\\", \\\"{x:1381,y:792,t:1527614047128};\\\", \\\"{x:1381,y:799,t:1527614047145};\\\", \\\"{x:1381,y:803,t:1527614047161};\\\", \\\"{x:1381,y:807,t:1527614047177};\\\", \\\"{x:1381,y:812,t:1527614047195};\\\", \\\"{x:1381,y:814,t:1527614047211};\\\", \\\"{x:1381,y:817,t:1527614047228};\\\", \\\"{x:1381,y:820,t:1527614047245};\\\", \\\"{x:1381,y:821,t:1527614047261};\\\", \\\"{x:1381,y:822,t:1527614047278};\\\", \\\"{x:1381,y:823,t:1527614047367};\\\", \\\"{x:1381,y:824,t:1527614047382};\\\", \\\"{x:1381,y:826,t:1527614047415};\\\", \\\"{x:1381,y:827,t:1527614047428};\\\", \\\"{x:1382,y:828,t:1527614047445};\\\", \\\"{x:1382,y:829,t:1527614047463};\\\", \\\"{x:1382,y:832,t:1527614047847};\\\", \\\"{x:1382,y:834,t:1527614047863};\\\", \\\"{x:1382,y:837,t:1527614047879};\\\", \\\"{x:1382,y:839,t:1527614047895};\\\", \\\"{x:1382,y:842,t:1527614047912};\\\", \\\"{x:1382,y:844,t:1527614047930};\\\", \\\"{x:1382,y:846,t:1527614047947};\\\", \\\"{x:1382,y:848,t:1527614047962};\\\", \\\"{x:1382,y:849,t:1527614047980};\\\", \\\"{x:1382,y:852,t:1527614047997};\\\", \\\"{x:1382,y:856,t:1527614048012};\\\", \\\"{x:1383,y:860,t:1527614048030};\\\", \\\"{x:1383,y:864,t:1527614048046};\\\", \\\"{x:1383,y:863,t:1527614048463};\\\", \\\"{x:1383,y:862,t:1527614048487};\\\", \\\"{x:1383,y:861,t:1527614050199};\\\", \\\"{x:1383,y:857,t:1527614050215};\\\", \\\"{x:1383,y:855,t:1527614050231};\\\", \\\"{x:1383,y:854,t:1527614050248};\\\", \\\"{x:1382,y:854,t:1527614050503};\\\", \\\"{x:1381,y:854,t:1527614050526};\\\", \\\"{x:1381,y:855,t:1527614050535};\\\", \\\"{x:1381,y:856,t:1527614050549};\\\", \\\"{x:1381,y:857,t:1527614050726};\\\", \\\"{x:1382,y:857,t:1527614050742};\\\", \\\"{x:1384,y:858,t:1527614050831};\\\", \\\"{x:1384,y:859,t:1527614050879};\\\", \\\"{x:1385,y:859,t:1527614050975};\\\", \\\"{x:1386,y:859,t:1527614051135};\\\", \\\"{x:1386,y:858,t:1527614052007};\\\", \\\"{x:1386,y:857,t:1527614052023};\\\", \\\"{x:1386,y:856,t:1527614052038};\\\", \\\"{x:1385,y:856,t:1527614052050};\\\", \\\"{x:1384,y:855,t:1527614054319};\\\", \\\"{x:1382,y:856,t:1527614054336};\\\", \\\"{x:1381,y:856,t:1527614054353};\\\", \\\"{x:1380,y:856,t:1527614054369};\\\", \\\"{x:1379,y:856,t:1527614075510};\\\", \\\"{x:1378,y:851,t:1527614075550};\\\", \\\"{x:1378,y:841,t:1527614075561};\\\", \\\"{x:1380,y:828,t:1527614075578};\\\", \\\"{x:1381,y:817,t:1527614075595};\\\", \\\"{x:1382,y:807,t:1527614075611};\\\", \\\"{x:1384,y:794,t:1527614075629};\\\", \\\"{x:1389,y:773,t:1527614075645};\\\", \\\"{x:1388,y:718,t:1527614075662};\\\", \\\"{x:1378,y:677,t:1527614075678};\\\", \\\"{x:1371,y:652,t:1527614075694};\\\", \\\"{x:1367,y:636,t:1527614075711};\\\", \\\"{x:1363,y:611,t:1527614075729};\\\", \\\"{x:1357,y:594,t:1527614075745};\\\", \\\"{x:1351,y:581,t:1527614075762};\\\", \\\"{x:1343,y:567,t:1527614075779};\\\", \\\"{x:1332,y:555,t:1527614075795};\\\", \\\"{x:1326,y:545,t:1527614075811};\\\", \\\"{x:1319,y:536,t:1527614075827};\\\", \\\"{x:1314,y:527,t:1527614075845};\\\", \\\"{x:1313,y:525,t:1527614075861};\\\", \\\"{x:1313,y:523,t:1527614075878};\\\", \\\"{x:1313,y:522,t:1527614075901};\\\", \\\"{x:1313,y:520,t:1527614075925};\\\", \\\"{x:1313,y:518,t:1527614075933};\\\", \\\"{x:1313,y:516,t:1527614075945};\\\", \\\"{x:1312,y:513,t:1527614075960};\\\", \\\"{x:1312,y:511,t:1527614075977};\\\", \\\"{x:1312,y:510,t:1527614075995};\\\", \\\"{x:1312,y:509,t:1527614076021};\\\", \\\"{x:1312,y:508,t:1527614076030};\\\", \\\"{x:1312,y:506,t:1527614076045};\\\", \\\"{x:1314,y:505,t:1527614076061};\\\", \\\"{x:1315,y:503,t:1527614076078};\\\", \\\"{x:1316,y:499,t:1527614076095};\\\", \\\"{x:1317,y:499,t:1527614076112};\\\", \\\"{x:1317,y:497,t:1527614076128};\\\", \\\"{x:1317,y:496,t:1527614076144};\\\", \\\"{x:1317,y:495,t:1527614076162};\\\", \\\"{x:1318,y:494,t:1527614076177};\\\", \\\"{x:1318,y:495,t:1527614076606};\\\", \\\"{x:1318,y:496,t:1527614076614};\\\", \\\"{x:1318,y:498,t:1527614076629};\\\", \\\"{x:1317,y:501,t:1527614076645};\\\", \\\"{x:1316,y:504,t:1527614076663};\\\", \\\"{x:1315,y:508,t:1527614076680};\\\", \\\"{x:1313,y:513,t:1527614076696};\\\", \\\"{x:1313,y:518,t:1527614076712};\\\", \\\"{x:1312,y:521,t:1527614076729};\\\", \\\"{x:1311,y:526,t:1527614076747};\\\", \\\"{x:1311,y:528,t:1527614076762};\\\", \\\"{x:1311,y:531,t:1527614076779};\\\", \\\"{x:1311,y:533,t:1527614076797};\\\", \\\"{x:1309,y:538,t:1527614076812};\\\", \\\"{x:1309,y:543,t:1527614076829};\\\", \\\"{x:1308,y:550,t:1527614076846};\\\", \\\"{x:1308,y:554,t:1527614076862};\\\", \\\"{x:1308,y:556,t:1527614076879};\\\", \\\"{x:1308,y:562,t:1527614076896};\\\", \\\"{x:1308,y:568,t:1527614076912};\\\", \\\"{x:1308,y:573,t:1527614076929};\\\", \\\"{x:1308,y:577,t:1527614076946};\\\", \\\"{x:1308,y:581,t:1527614076964};\\\", \\\"{x:1308,y:584,t:1527614076980};\\\", \\\"{x:1308,y:588,t:1527614076997};\\\", \\\"{x:1309,y:592,t:1527614077013};\\\", \\\"{x:1310,y:595,t:1527614077029};\\\", \\\"{x:1313,y:602,t:1527614077045};\\\", \\\"{x:1314,y:605,t:1527614077064};\\\", \\\"{x:1315,y:608,t:1527614077079};\\\", \\\"{x:1315,y:609,t:1527614077096};\\\", \\\"{x:1316,y:610,t:1527614077113};\\\", \\\"{x:1317,y:612,t:1527614077130};\\\", \\\"{x:1317,y:613,t:1527614077146};\\\", \\\"{x:1317,y:614,t:1527614077164};\\\", \\\"{x:1317,y:615,t:1527614077179};\\\", \\\"{x:1318,y:616,t:1527614077196};\\\", \\\"{x:1318,y:617,t:1527614077213};\\\", \\\"{x:1318,y:618,t:1527614077358};\\\", \\\"{x:1318,y:619,t:1527614077430};\\\", \\\"{x:1318,y:620,t:1527614077461};\\\", \\\"{x:1318,y:621,t:1527614077469};\\\", \\\"{x:1318,y:622,t:1527614077486};\\\", \\\"{x:1318,y:623,t:1527614077501};\\\", \\\"{x:1318,y:624,t:1527614077526};\\\", \\\"{x:1318,y:625,t:1527614077542};\\\", \\\"{x:1318,y:626,t:1527614077563};\\\", \\\"{x:1318,y:627,t:1527614077580};\\\", \\\"{x:1318,y:629,t:1527614077597};\\\", \\\"{x:1316,y:630,t:1527614077614};\\\", \\\"{x:1316,y:631,t:1527614077637};\\\", \\\"{x:1316,y:632,t:1527614077648};\\\", \\\"{x:1316,y:633,t:1527614077670};\\\", \\\"{x:1315,y:635,t:1527614077680};\\\", \\\"{x:1315,y:636,t:1527614077702};\\\", \\\"{x:1315,y:637,t:1527614077726};\\\", \\\"{x:1315,y:638,t:1527614077734};\\\", \\\"{x:1315,y:639,t:1527614077747};\\\", \\\"{x:1315,y:640,t:1527614077766};\\\", \\\"{x:1315,y:641,t:1527614077780};\\\", \\\"{x:1315,y:643,t:1527614077797};\\\", \\\"{x:1315,y:648,t:1527614077814};\\\", \\\"{x:1312,y:653,t:1527614077830};\\\", \\\"{x:1312,y:658,t:1527614077846};\\\", \\\"{x:1312,y:664,t:1527614077864};\\\", \\\"{x:1312,y:671,t:1527614077880};\\\", \\\"{x:1312,y:676,t:1527614077897};\\\", \\\"{x:1312,y:681,t:1527614077913};\\\", \\\"{x:1312,y:685,t:1527614077930};\\\", \\\"{x:1312,y:689,t:1527614077947};\\\", \\\"{x:1312,y:692,t:1527614077964};\\\", \\\"{x:1312,y:693,t:1527614077980};\\\", \\\"{x:1312,y:697,t:1527614077997};\\\", \\\"{x:1312,y:698,t:1527614078013};\\\", \\\"{x:1312,y:700,t:1527614078030};\\\", \\\"{x:1312,y:701,t:1527614078047};\\\", \\\"{x:1312,y:703,t:1527614078064};\\\", \\\"{x:1312,y:704,t:1527614078080};\\\", \\\"{x:1312,y:706,t:1527614078109};\\\", \\\"{x:1312,y:708,t:1527614078118};\\\", \\\"{x:1312,y:710,t:1527614078133};\\\", \\\"{x:1312,y:713,t:1527614078147};\\\", \\\"{x:1313,y:715,t:1527614078164};\\\", \\\"{x:1314,y:719,t:1527614078181};\\\", \\\"{x:1314,y:721,t:1527614078198};\\\", \\\"{x:1314,y:723,t:1527614078214};\\\", \\\"{x:1314,y:724,t:1527614078231};\\\", \\\"{x:1315,y:726,t:1527614078247};\\\", \\\"{x:1315,y:728,t:1527614078264};\\\", \\\"{x:1316,y:730,t:1527614078281};\\\", \\\"{x:1316,y:731,t:1527614078297};\\\", \\\"{x:1316,y:722,t:1527614080517};\\\", \\\"{x:1325,y:673,t:1527614080533};\\\", \\\"{x:1340,y:592,t:1527614080550};\\\", \\\"{x:1351,y:500,t:1527614080567};\\\", \\\"{x:1351,y:447,t:1527614080583};\\\", \\\"{x:1349,y:421,t:1527614080601};\\\", \\\"{x:1346,y:405,t:1527614080617};\\\", \\\"{x:1343,y:395,t:1527614080633};\\\", \\\"{x:1343,y:392,t:1527614080650};\\\", \\\"{x:1342,y:391,t:1527614080686};\\\", \\\"{x:1339,y:399,t:1527614080766};\\\", \\\"{x:1334,y:430,t:1527614080784};\\\", \\\"{x:1328,y:461,t:1527614080800};\\\", \\\"{x:1325,y:486,t:1527614080817};\\\", \\\"{x:1322,y:501,t:1527614080834};\\\", \\\"{x:1322,y:508,t:1527614080851};\\\", \\\"{x:1320,y:510,t:1527614080867};\\\", \\\"{x:1320,y:509,t:1527614081086};\\\", \\\"{x:1320,y:507,t:1527614081100};\\\", \\\"{x:1320,y:506,t:1527614081118};\\\", \\\"{x:1320,y:505,t:1527614081454};\\\", \\\"{x:1320,y:504,t:1527614081469};\\\", \\\"{x:1320,y:502,t:1527614081485};\\\", \\\"{x:1320,y:500,t:1527614081501};\\\", \\\"{x:1319,y:499,t:1527614081630};\\\", \\\"{x:1319,y:500,t:1527614081798};\\\", \\\"{x:1319,y:502,t:1527614081806};\\\", \\\"{x:1319,y:504,t:1527614081818};\\\", \\\"{x:1319,y:507,t:1527614081835};\\\", \\\"{x:1318,y:508,t:1527614081851};\\\", \\\"{x:1318,y:510,t:1527614081868};\\\", \\\"{x:1318,y:514,t:1527614081886};\\\", \\\"{x:1318,y:517,t:1527614081902};\\\", \\\"{x:1318,y:521,t:1527614081919};\\\", \\\"{x:1318,y:525,t:1527614081935};\\\", \\\"{x:1318,y:528,t:1527614081952};\\\", \\\"{x:1318,y:529,t:1527614081969};\\\", \\\"{x:1318,y:532,t:1527614081986};\\\", \\\"{x:1318,y:534,t:1527614082002};\\\", \\\"{x:1318,y:538,t:1527614082018};\\\", \\\"{x:1318,y:542,t:1527614082035};\\\", \\\"{x:1318,y:550,t:1527614082053};\\\", \\\"{x:1318,y:559,t:1527614082069};\\\", \\\"{x:1318,y:566,t:1527614082085};\\\", \\\"{x:1318,y:568,t:1527614082102};\\\", \\\"{x:1318,y:569,t:1527614082119};\\\", \\\"{x:1318,y:571,t:1527614082136};\\\", \\\"{x:1318,y:574,t:1527614082152};\\\", \\\"{x:1318,y:580,t:1527614082169};\\\", \\\"{x:1318,y:587,t:1527614082186};\\\", \\\"{x:1318,y:594,t:1527614082203};\\\", \\\"{x:1318,y:598,t:1527614082218};\\\", \\\"{x:1318,y:600,t:1527614082236};\\\", \\\"{x:1318,y:603,t:1527614082252};\\\", \\\"{x:1318,y:606,t:1527614082269};\\\", \\\"{x:1316,y:619,t:1527614082285};\\\", \\\"{x:1315,y:628,t:1527614082303};\\\", \\\"{x:1314,y:634,t:1527614082319};\\\", \\\"{x:1312,y:639,t:1527614082336};\\\", \\\"{x:1311,y:641,t:1527614082352};\\\", \\\"{x:1309,y:643,t:1527614082370};\\\", \\\"{x:1308,y:646,t:1527614082386};\\\", \\\"{x:1303,y:655,t:1527614082403};\\\", \\\"{x:1301,y:666,t:1527614082419};\\\", \\\"{x:1300,y:673,t:1527614082435};\\\", \\\"{x:1299,y:678,t:1527614082453};\\\", \\\"{x:1298,y:682,t:1527614082469};\\\", \\\"{x:1298,y:683,t:1527614082485};\\\", \\\"{x:1298,y:686,t:1527614082502};\\\", \\\"{x:1298,y:690,t:1527614082520};\\\", \\\"{x:1298,y:695,t:1527614082535};\\\", \\\"{x:1298,y:699,t:1527614082553};\\\", \\\"{x:1298,y:702,t:1527614082569};\\\", \\\"{x:1298,y:704,t:1527614082587};\\\", \\\"{x:1298,y:705,t:1527614082602};\\\", \\\"{x:1299,y:707,t:1527614082619};\\\", \\\"{x:1301,y:712,t:1527614082636};\\\", \\\"{x:1301,y:714,t:1527614082653};\\\", \\\"{x:1302,y:715,t:1527614082670};\\\", \\\"{x:1302,y:716,t:1527614082687};\\\", \\\"{x:1303,y:720,t:1527614082702};\\\", \\\"{x:1307,y:730,t:1527614082720};\\\", \\\"{x:1311,y:747,t:1527614082736};\\\", \\\"{x:1313,y:760,t:1527614082752};\\\", \\\"{x:1314,y:763,t:1527614082769};\\\", \\\"{x:1314,y:764,t:1527614082786};\\\", \\\"{x:1314,y:766,t:1527614082813};\\\", \\\"{x:1314,y:768,t:1527614082821};\\\", \\\"{x:1314,y:770,t:1527614082836};\\\", \\\"{x:1314,y:775,t:1527614082852};\\\", \\\"{x:1314,y:780,t:1527614082869};\\\", \\\"{x:1314,y:781,t:1527614082886};\\\", \\\"{x:1314,y:782,t:1527614082903};\\\", \\\"{x:1314,y:784,t:1527614082919};\\\", \\\"{x:1314,y:786,t:1527614082936};\\\", \\\"{x:1314,y:788,t:1527614082954};\\\", \\\"{x:1314,y:791,t:1527614082969};\\\", \\\"{x:1314,y:793,t:1527614082986};\\\", \\\"{x:1313,y:796,t:1527614083003};\\\", \\\"{x:1312,y:798,t:1527614083019};\\\", \\\"{x:1310,y:801,t:1527614083036};\\\", \\\"{x:1310,y:808,t:1527614083053};\\\", \\\"{x:1310,y:816,t:1527614083069};\\\", \\\"{x:1310,y:824,t:1527614083087};\\\", \\\"{x:1310,y:829,t:1527614083104};\\\", \\\"{x:1309,y:835,t:1527614083120};\\\", \\\"{x:1305,y:841,t:1527614083136};\\\", \\\"{x:1304,y:847,t:1527614083153};\\\", \\\"{x:1302,y:853,t:1527614083171};\\\", \\\"{x:1302,y:859,t:1527614083186};\\\", \\\"{x:1302,y:864,t:1527614083203};\\\", \\\"{x:1303,y:873,t:1527614083221};\\\", \\\"{x:1304,y:879,t:1527614083236};\\\", \\\"{x:1304,y:883,t:1527614083254};\\\", \\\"{x:1304,y:884,t:1527614083269};\\\", \\\"{x:1304,y:886,t:1527614083286};\\\", \\\"{x:1305,y:889,t:1527614083303};\\\", \\\"{x:1306,y:894,t:1527614083320};\\\", \\\"{x:1307,y:898,t:1527614083336};\\\", \\\"{x:1307,y:902,t:1527614083354};\\\", \\\"{x:1309,y:903,t:1527614083370};\\\", \\\"{x:1309,y:905,t:1527614083398};\\\", \\\"{x:1310,y:907,t:1527614083406};\\\", \\\"{x:1311,y:911,t:1527614083421};\\\", \\\"{x:1315,y:920,t:1527614083436};\\\", \\\"{x:1319,y:935,t:1527614083453};\\\", \\\"{x:1320,y:940,t:1527614083471};\\\", \\\"{x:1322,y:942,t:1527614083487};\\\", \\\"{x:1322,y:943,t:1527614083503};\\\", \\\"{x:1323,y:944,t:1527614083542};\\\", \\\"{x:1323,y:945,t:1527614083566};\\\", \\\"{x:1325,y:947,t:1527614083574};\\\", \\\"{x:1326,y:950,t:1527614083590};\\\", \\\"{x:1326,y:952,t:1527614083605};\\\", \\\"{x:1326,y:954,t:1527614083646};\\\", \\\"{x:1326,y:956,t:1527614083661};\\\", \\\"{x:1326,y:958,t:1527614083670};\\\", \\\"{x:1327,y:961,t:1527614083688};\\\", \\\"{x:1328,y:962,t:1527614083703};\\\", \\\"{x:1329,y:963,t:1527614083766};\\\", \\\"{x:1329,y:964,t:1527614083773};\\\", \\\"{x:1329,y:966,t:1527614083788};\\\", \\\"{x:1329,y:968,t:1527614083804};\\\", \\\"{x:1329,y:970,t:1527614083821};\\\", \\\"{x:1329,y:971,t:1527614084149};\\\", \\\"{x:1328,y:971,t:1527614084205};\\\", \\\"{x:1326,y:971,t:1527614084221};\\\", \\\"{x:1325,y:970,t:1527614084253};\\\", \\\"{x:1324,y:969,t:1527614084277};\\\", \\\"{x:1322,y:969,t:1527614084301};\\\", \\\"{x:1322,y:967,t:1527614084309};\\\", \\\"{x:1321,y:967,t:1527614084328};\\\", \\\"{x:1320,y:966,t:1527614084341};\\\", \\\"{x:1319,y:965,t:1527614084518};\\\", \\\"{x:1319,y:964,t:1527614085013};\\\", \\\"{x:1319,y:963,t:1527614085277};\\\", \\\"{x:1319,y:962,t:1527614085289};\\\", \\\"{x:1319,y:961,t:1527614085305};\\\", \\\"{x:1319,y:960,t:1527614085341};\\\", \\\"{x:1319,y:959,t:1527614086334};\\\", \\\"{x:1319,y:958,t:1527614086342};\\\", \\\"{x:1318,y:958,t:1527614086357};\\\", \\\"{x:1315,y:954,t:1527614086374};\\\", \\\"{x:1313,y:954,t:1527614086414};\\\", \\\"{x:1312,y:954,t:1527614086686};\\\", \\\"{x:1310,y:955,t:1527614086694};\\\", \\\"{x:1310,y:956,t:1527614086708};\\\", \\\"{x:1309,y:957,t:1527614086725};\\\", \\\"{x:1308,y:959,t:1527614086741};\\\", \\\"{x:1308,y:961,t:1527614086757};\\\", \\\"{x:1308,y:962,t:1527614086774};\\\", \\\"{x:1308,y:963,t:1527614086838};\\\", \\\"{x:1308,y:964,t:1527614086862};\\\", \\\"{x:1307,y:966,t:1527614086875};\\\", \\\"{x:1307,y:968,t:1527614086891};\\\", \\\"{x:1307,y:970,t:1527614086908};\\\", \\\"{x:1307,y:971,t:1527614086950};\\\", \\\"{x:1307,y:972,t:1527614086966};\\\", \\\"{x:1307,y:973,t:1527614086975};\\\", \\\"{x:1307,y:975,t:1527614086990};\\\", \\\"{x:1308,y:976,t:1527614087007};\\\", \\\"{x:1308,y:977,t:1527614087023};\\\", \\\"{x:1309,y:977,t:1527614087050};\\\", \\\"{x:1310,y:977,t:1527614087298};\\\", \\\"{x:1310,y:976,t:1527614087313};\\\", \\\"{x:1311,y:972,t:1527614087328};\\\", \\\"{x:1312,y:969,t:1527614087345};\\\", \\\"{x:1313,y:968,t:1527614087363};\\\", \\\"{x:1314,y:966,t:1527614087379};\\\", \\\"{x:1314,y:964,t:1527614087401};\\\", \\\"{x:1314,y:963,t:1527614087413};\\\", \\\"{x:1314,y:962,t:1527614087429};\\\", \\\"{x:1314,y:961,t:1527614087445};\\\", \\\"{x:1314,y:960,t:1527614087462};\\\", \\\"{x:1315,y:959,t:1527614087478};\\\", \\\"{x:1315,y:958,t:1527614087546};\\\", \\\"{x:1315,y:957,t:1527614087586};\\\", \\\"{x:1315,y:956,t:1527614087609};\\\", \\\"{x:1315,y:955,t:1527614087633};\\\", \\\"{x:1315,y:954,t:1527614087649};\\\", \\\"{x:1315,y:953,t:1527614087662};\\\", \\\"{x:1315,y:952,t:1527614087681};\\\", \\\"{x:1315,y:951,t:1527614087722};\\\", \\\"{x:1315,y:950,t:1527614087737};\\\", \\\"{x:1315,y:949,t:1527614087817};\\\", \\\"{x:1315,y:948,t:1527614087842};\\\", \\\"{x:1315,y:947,t:1527614087865};\\\", \\\"{x:1315,y:946,t:1527614087881};\\\", \\\"{x:1315,y:945,t:1527614087905};\\\", \\\"{x:1315,y:944,t:1527614087946};\\\", \\\"{x:1315,y:943,t:1527614087961};\\\", \\\"{x:1315,y:942,t:1527614087969};\\\", \\\"{x:1315,y:941,t:1527614088410};\\\", \\\"{x:1315,y:940,t:1527614088441};\\\", \\\"{x:1315,y:939,t:1527614088482};\\\", \\\"{x:1314,y:939,t:1527614088497};\\\", \\\"{x:1313,y:938,t:1527614088514};\\\", \\\"{x:1313,y:937,t:1527614088705};\\\", \\\"{x:1313,y:935,t:1527614088714};\\\", \\\"{x:1312,y:934,t:1527614088730};\\\", \\\"{x:1312,y:933,t:1527614088761};\\\", \\\"{x:1312,y:932,t:1527614088785};\\\", \\\"{x:1312,y:931,t:1527614088809};\\\", \\\"{x:1312,y:929,t:1527614088817};\\\", \\\"{x:1312,y:926,t:1527614088830};\\\", \\\"{x:1312,y:915,t:1527614088848};\\\", \\\"{x:1312,y:897,t:1527614088864};\\\", \\\"{x:1316,y:875,t:1527614088881};\\\", \\\"{x:1325,y:846,t:1527614088897};\\\", \\\"{x:1329,y:827,t:1527614088914};\\\", \\\"{x:1333,y:814,t:1527614088930};\\\", \\\"{x:1337,y:801,t:1527614088947};\\\", \\\"{x:1338,y:798,t:1527614088964};\\\", \\\"{x:1339,y:795,t:1527614088981};\\\", \\\"{x:1340,y:793,t:1527614088998};\\\", \\\"{x:1340,y:792,t:1527614089026};\\\", \\\"{x:1340,y:791,t:1527614089033};\\\", \\\"{x:1340,y:790,t:1527614089049};\\\", \\\"{x:1341,y:789,t:1527614089065};\\\", \\\"{x:1341,y:787,t:1527614089080};\\\", \\\"{x:1343,y:786,t:1527614089097};\\\", \\\"{x:1344,y:785,t:1527614089114};\\\", \\\"{x:1345,y:785,t:1527614089169};\\\", \\\"{x:1345,y:784,t:1527614089180};\\\", \\\"{x:1347,y:783,t:1527614089197};\\\", \\\"{x:1348,y:783,t:1527614089225};\\\", \\\"{x:1349,y:783,t:1527614089250};\\\", \\\"{x:1350,y:783,t:1527614089273};\\\", \\\"{x:1351,y:783,t:1527614089282};\\\", \\\"{x:1352,y:783,t:1527614089297};\\\", \\\"{x:1352,y:782,t:1527614089314};\\\", \\\"{x:1354,y:781,t:1527614089331};\\\", \\\"{x:1356,y:780,t:1527614089348};\\\", \\\"{x:1359,y:779,t:1527614089364};\\\", \\\"{x:1362,y:778,t:1527614089381};\\\", \\\"{x:1364,y:777,t:1527614089398};\\\", \\\"{x:1366,y:777,t:1527614089415};\\\", \\\"{x:1368,y:776,t:1527614089431};\\\", \\\"{x:1369,y:776,t:1527614089449};\\\", \\\"{x:1371,y:776,t:1527614089545};\\\", \\\"{x:1372,y:777,t:1527614089649};\\\", \\\"{x:1372,y:783,t:1527614089665};\\\", \\\"{x:1372,y:801,t:1527614089682};\\\", \\\"{x:1372,y:808,t:1527614089699};\\\", \\\"{x:1373,y:811,t:1527614089714};\\\", \\\"{x:1373,y:813,t:1527614089731};\\\", \\\"{x:1373,y:815,t:1527614089748};\\\", \\\"{x:1373,y:817,t:1527614089764};\\\", \\\"{x:1373,y:819,t:1527614089782};\\\", \\\"{x:1372,y:821,t:1527614089799};\\\", \\\"{x:1372,y:822,t:1527614089817};\\\", \\\"{x:1372,y:824,t:1527614089832};\\\", \\\"{x:1372,y:826,t:1527614089849};\\\", \\\"{x:1372,y:827,t:1527614089865};\\\", \\\"{x:1372,y:828,t:1527614089882};\\\", \\\"{x:1373,y:831,t:1527614089899};\\\", \\\"{x:1374,y:837,t:1527614089915};\\\", \\\"{x:1378,y:847,t:1527614089932};\\\", \\\"{x:1382,y:855,t:1527614089949};\\\", \\\"{x:1383,y:859,t:1527614089965};\\\", \\\"{x:1384,y:861,t:1527614089982};\\\", \\\"{x:1384,y:862,t:1527614089999};\\\", \\\"{x:1384,y:861,t:1527614091715};\\\", \\\"{x:1384,y:858,t:1527614091722};\\\", \\\"{x:1384,y:857,t:1527614091734};\\\", \\\"{x:1381,y:853,t:1527614092986};\\\", \\\"{x:1374,y:844,t:1527614093002};\\\", \\\"{x:1366,y:835,t:1527614093019};\\\", \\\"{x:1359,y:827,t:1527614093036};\\\", \\\"{x:1344,y:815,t:1527614093052};\\\", \\\"{x:1321,y:805,t:1527614093069};\\\", \\\"{x:1300,y:797,t:1527614093086};\\\", \\\"{x:1272,y:791,t:1527614093102};\\\", \\\"{x:1255,y:789,t:1527614093119};\\\", \\\"{x:1237,y:785,t:1527614093137};\\\", \\\"{x:1216,y:779,t:1527614093153};\\\", \\\"{x:1194,y:775,t:1527614093169};\\\", \\\"{x:1149,y:761,t:1527614093186};\\\", \\\"{x:1110,y:750,t:1527614093203};\\\", \\\"{x:1068,y:739,t:1527614093219};\\\", \\\"{x:1034,y:728,t:1527614093236};\\\", \\\"{x:986,y:714,t:1527614093252};\\\", \\\"{x:950,y:705,t:1527614093269};\\\", \\\"{x:919,y:695,t:1527614093286};\\\", \\\"{x:902,y:691,t:1527614093303};\\\", \\\"{x:892,y:687,t:1527614093319};\\\", \\\"{x:888,y:684,t:1527614093336};\\\", \\\"{x:880,y:680,t:1527614093354};\\\", \\\"{x:865,y:670,t:1527614093370};\\\", \\\"{x:831,y:657,t:1527614093385};\\\", \\\"{x:800,y:647,t:1527614093403};\\\", \\\"{x:778,y:640,t:1527614093420};\\\", \\\"{x:766,y:636,t:1527614093436};\\\", \\\"{x:759,y:635,t:1527614093453};\\\", \\\"{x:756,y:634,t:1527614093469};\\\", \\\"{x:755,y:634,t:1527614093486};\\\", \\\"{x:751,y:634,t:1527614093503};\\\", \\\"{x:743,y:634,t:1527614093520};\\\", \\\"{x:736,y:634,t:1527614093537};\\\", \\\"{x:729,y:634,t:1527614093553};\\\", \\\"{x:716,y:634,t:1527614093571};\\\", \\\"{x:706,y:636,t:1527614093586};\\\", \\\"{x:688,y:638,t:1527614093603};\\\", \\\"{x:653,y:644,t:1527614093625};\\\", \\\"{x:627,y:647,t:1527614093642};\\\", \\\"{x:597,y:648,t:1527614093659};\\\", \\\"{x:561,y:648,t:1527614093676};\\\", \\\"{x:524,y:648,t:1527614093692};\\\", \\\"{x:494,y:648,t:1527614093709};\\\", \\\"{x:475,y:648,t:1527614093725};\\\", \\\"{x:468,y:648,t:1527614093742};\\\", \\\"{x:467,y:648,t:1527614093759};\\\", \\\"{x:466,y:648,t:1527614093809};\\\", \\\"{x:465,y:648,t:1527614093825};\\\", \\\"{x:459,y:648,t:1527614093843};\\\", \\\"{x:450,y:648,t:1527614093859};\\\", \\\"{x:428,y:647,t:1527614093876};\\\", \\\"{x:401,y:643,t:1527614093894};\\\", \\\"{x:377,y:639,t:1527614093910};\\\", \\\"{x:368,y:636,t:1527614093926};\\\", \\\"{x:367,y:636,t:1527614093942};\\\", \\\"{x:366,y:635,t:1527614093958};\\\", \\\"{x:365,y:635,t:1527614093986};\\\", \\\"{x:363,y:635,t:1527614093993};\\\", \\\"{x:362,y:635,t:1527614094009};\\\", \\\"{x:354,y:635,t:1527614094026};\\\", \\\"{x:342,y:637,t:1527614094042};\\\", \\\"{x:328,y:637,t:1527614094058};\\\", \\\"{x:315,y:637,t:1527614094075};\\\", \\\"{x:294,y:637,t:1527614094093};\\\", \\\"{x:272,y:637,t:1527614094109};\\\", \\\"{x:252,y:637,t:1527614094126};\\\", \\\"{x:236,y:635,t:1527614094143};\\\", \\\"{x:225,y:633,t:1527614094159};\\\", \\\"{x:222,y:632,t:1527614094176};\\\", \\\"{x:221,y:632,t:1527614094192};\\\", \\\"{x:221,y:631,t:1527614094208};\\\", \\\"{x:221,y:630,t:1527614094226};\\\", \\\"{x:221,y:629,t:1527614094243};\\\", \\\"{x:221,y:627,t:1527614094258};\\\", \\\"{x:221,y:625,t:1527614094277};\\\", \\\"{x:225,y:619,t:1527614094293};\\\", \\\"{x:235,y:612,t:1527614094309};\\\", \\\"{x:248,y:604,t:1527614094326};\\\", \\\"{x:265,y:595,t:1527614094344};\\\", \\\"{x:278,y:587,t:1527614094361};\\\", \\\"{x:293,y:581,t:1527614094376};\\\", \\\"{x:308,y:572,t:1527614094393};\\\", \\\"{x:327,y:562,t:1527614094409};\\\", \\\"{x:335,y:558,t:1527614094426};\\\", \\\"{x:340,y:556,t:1527614094444};\\\", \\\"{x:344,y:556,t:1527614094460};\\\", \\\"{x:346,y:556,t:1527614094476};\\\", \\\"{x:348,y:555,t:1527614094522};\\\", \\\"{x:350,y:553,t:1527614094531};\\\", \\\"{x:352,y:552,t:1527614094543};\\\", \\\"{x:356,y:550,t:1527614094562};\\\", \\\"{x:357,y:550,t:1527614094586};\\\", \\\"{x:357,y:552,t:1527614094636};\\\", \\\"{x:357,y:553,t:1527614094657};\\\", \\\"{x:357,y:555,t:1527614094673};\\\", \\\"{x:357,y:556,t:1527614094689};\\\", \\\"{x:358,y:556,t:1527614094697};\\\", \\\"{x:358,y:558,t:1527614094714};\\\", \\\"{x:359,y:559,t:1527614094726};\\\", \\\"{x:361,y:561,t:1527614094743};\\\", \\\"{x:363,y:563,t:1527614094760};\\\", \\\"{x:364,y:563,t:1527614094776};\\\", \\\"{x:368,y:567,t:1527614094793};\\\", \\\"{x:370,y:569,t:1527614094809};\\\", \\\"{x:372,y:570,t:1527614094826};\\\", \\\"{x:374,y:572,t:1527614094843};\\\", \\\"{x:375,y:573,t:1527614094860};\\\", \\\"{x:376,y:573,t:1527614094881};\\\", \\\"{x:377,y:574,t:1527614094897};\\\", \\\"{x:377,y:575,t:1527614094937};\\\", \\\"{x:378,y:575,t:1527614094954};\\\", \\\"{x:379,y:575,t:1527614094961};\\\", \\\"{x:380,y:575,t:1527614094977};\\\", \\\"{x:382,y:575,t:1527614094993};\\\", \\\"{x:383,y:574,t:1527614095010};\\\", \\\"{x:384,y:574,t:1527614095265};\\\", \\\"{x:385,y:572,t:1527614095276};\\\", \\\"{x:394,y:568,t:1527614095294};\\\", \\\"{x:407,y:566,t:1527614095310};\\\", \\\"{x:428,y:566,t:1527614095327};\\\", \\\"{x:456,y:566,t:1527614095344};\\\", \\\"{x:479,y:566,t:1527614095360};\\\", \\\"{x:499,y:568,t:1527614095378};\\\", \\\"{x:533,y:574,t:1527614095394};\\\", \\\"{x:557,y:576,t:1527614095410};\\\", \\\"{x:579,y:576,t:1527614095427};\\\", \\\"{x:593,y:576,t:1527614095444};\\\", \\\"{x:599,y:576,t:1527614095462};\\\", \\\"{x:600,y:576,t:1527614095477};\\\", \\\"{x:600,y:578,t:1527614095562};\\\", \\\"{x:600,y:579,t:1527614095577};\\\", \\\"{x:589,y:583,t:1527614095595};\\\", \\\"{x:577,y:588,t:1527614095610};\\\", \\\"{x:570,y:591,t:1527614095627};\\\", \\\"{x:568,y:591,t:1527614095644};\\\", \\\"{x:566,y:592,t:1527614095661};\\\", \\\"{x:568,y:593,t:1527614095738};\\\", \\\"{x:574,y:596,t:1527614095746};\\\", \\\"{x:583,y:597,t:1527614095761};\\\", \\\"{x:601,y:602,t:1527614095778};\\\", \\\"{x:625,y:610,t:1527614095793};\\\", \\\"{x:638,y:613,t:1527614095810};\\\", \\\"{x:647,y:616,t:1527614095827};\\\", \\\"{x:652,y:618,t:1527614095844};\\\", \\\"{x:653,y:618,t:1527614095963};\\\", \\\"{x:653,y:620,t:1527614095978};\\\", \\\"{x:643,y:624,t:1527614095994};\\\", \\\"{x:639,y:624,t:1527614096010};\\\", \\\"{x:638,y:625,t:1527614096027};\\\", \\\"{x:636,y:625,t:1527614096050};\\\", \\\"{x:634,y:624,t:1527614096065};\\\", \\\"{x:633,y:623,t:1527614096077};\\\", \\\"{x:626,y:622,t:1527614096094};\\\", \\\"{x:621,y:619,t:1527614096111};\\\", \\\"{x:615,y:616,t:1527614096128};\\\", \\\"{x:614,y:616,t:1527614096144};\\\", \\\"{x:613,y:616,t:1527614096170};\\\", \\\"{x:612,y:615,t:1527614096178};\\\", \\\"{x:612,y:614,t:1527614096210};\\\", \\\"{x:612,y:613,t:1527614096218};\\\", \\\"{x:612,y:612,t:1527614096723};\\\", \\\"{x:612,y:609,t:1527614096729};\\\", \\\"{x:619,y:606,t:1527614096745};\\\", \\\"{x:622,y:604,t:1527614096762};\\\", \\\"{x:630,y:599,t:1527614096778};\\\", \\\"{x:636,y:596,t:1527614096796};\\\", \\\"{x:639,y:595,t:1527614096812};\\\", \\\"{x:642,y:593,t:1527614096827};\\\", \\\"{x:643,y:592,t:1527614096845};\\\", \\\"{x:647,y:590,t:1527614096861};\\\", \\\"{x:650,y:589,t:1527614096878};\\\", \\\"{x:650,y:588,t:1527614096896};\\\", \\\"{x:651,y:588,t:1527614096911};\\\", \\\"{x:652,y:587,t:1527614096928};\\\", \\\"{x:653,y:587,t:1527614096946};\\\", \\\"{x:653,y:586,t:1527614097042};\\\", \\\"{x:648,y:583,t:1527614097050};\\\", \\\"{x:638,y:578,t:1527614097063};\\\", \\\"{x:615,y:570,t:1527614097079};\\\", \\\"{x:608,y:570,t:1527614097095};\\\", \\\"{x:605,y:570,t:1527614097113};\\\", \\\"{x:602,y:568,t:1527614097128};\\\", \\\"{x:594,y:566,t:1527614097146};\\\", \\\"{x:590,y:564,t:1527614097162};\\\", \\\"{x:587,y:562,t:1527614097178};\\\", \\\"{x:588,y:562,t:1527614097273};\\\", \\\"{x:589,y:562,t:1527614097282};\\\", \\\"{x:590,y:562,t:1527614097898};\\\", \\\"{x:610,y:562,t:1527614097913};\\\", \\\"{x:708,y:562,t:1527614097929};\\\", \\\"{x:794,y:562,t:1527614097946};\\\", \\\"{x:883,y:562,t:1527614097962};\\\", \\\"{x:941,y:562,t:1527614097979};\\\", \\\"{x:986,y:562,t:1527614097997};\\\", \\\"{x:1025,y:562,t:1527614098012};\\\", \\\"{x:1062,y:562,t:1527614098029};\\\", \\\"{x:1086,y:562,t:1527614098046};\\\", \\\"{x:1100,y:562,t:1527614098062};\\\", \\\"{x:1103,y:560,t:1527614098079};\\\", \\\"{x:1106,y:560,t:1527614098242};\\\", \\\"{x:1110,y:561,t:1527614098250};\\\", \\\"{x:1117,y:565,t:1527614098264};\\\", \\\"{x:1135,y:572,t:1527614098280};\\\", \\\"{x:1160,y:576,t:1527614098297};\\\", \\\"{x:1207,y:589,t:1527614098314};\\\", \\\"{x:1218,y:590,t:1527614098329};\\\", \\\"{x:1251,y:594,t:1527614098346};\\\", \\\"{x:1266,y:595,t:1527614098364};\\\", \\\"{x:1275,y:596,t:1527614098380};\\\", \\\"{x:1281,y:598,t:1527614098396};\\\", \\\"{x:1285,y:599,t:1527614098414};\\\", \\\"{x:1290,y:600,t:1527614098429};\\\", \\\"{x:1293,y:602,t:1527614098447};\\\", \\\"{x:1294,y:606,t:1527614098507};\\\", \\\"{x:1297,y:613,t:1527614098514};\\\", \\\"{x:1306,y:637,t:1527614098529};\\\", \\\"{x:1313,y:657,t:1527614098546};\\\", \\\"{x:1320,y:669,t:1527614098563};\\\", \\\"{x:1322,y:671,t:1527614098580};\\\", \\\"{x:1322,y:672,t:1527614098596};\\\", \\\"{x:1322,y:673,t:1527614098617};\\\", \\\"{x:1324,y:675,t:1527614098630};\\\", \\\"{x:1326,y:681,t:1527614098646};\\\", \\\"{x:1330,y:690,t:1527614098663};\\\", \\\"{x:1336,y:700,t:1527614098681};\\\", \\\"{x:1339,y:708,t:1527614098697};\\\", \\\"{x:1340,y:713,t:1527614098713};\\\", \\\"{x:1340,y:721,t:1527614098729};\\\", \\\"{x:1340,y:731,t:1527614098747};\\\", \\\"{x:1335,y:740,t:1527614098763};\\\", \\\"{x:1329,y:749,t:1527614098781};\\\", \\\"{x:1326,y:752,t:1527614098797};\\\", \\\"{x:1325,y:752,t:1527614098842};\\\", \\\"{x:1324,y:754,t:1527614098850};\\\", \\\"{x:1323,y:755,t:1527614098863};\\\", \\\"{x:1321,y:761,t:1527614098880};\\\", \\\"{x:1320,y:763,t:1527614098897};\\\", \\\"{x:1318,y:767,t:1527614098914};\\\", \\\"{x:1318,y:766,t:1527614099058};\\\", \\\"{x:1317,y:763,t:1527614099066};\\\", \\\"{x:1316,y:762,t:1527614099082};\\\", \\\"{x:1315,y:760,t:1527614099099};\\\", \\\"{x:1315,y:759,t:1527614100194};\\\", \\\"{x:1315,y:758,t:1527614100210};\\\", \\\"{x:1315,y:757,t:1527614100218};\\\", \\\"{x:1315,y:756,t:1527614100250};\\\", \\\"{x:1315,y:758,t:1527614102835};\\\", \\\"{x:1315,y:763,t:1527614102851};\\\", \\\"{x:1315,y:765,t:1527614102867};\\\", \\\"{x:1315,y:767,t:1527614102884};\\\", \\\"{x:1316,y:767,t:1527614102901};\\\", \\\"{x:1316,y:769,t:1527614102918};\\\", \\\"{x:1316,y:771,t:1527614102934};\\\", \\\"{x:1317,y:774,t:1527614102951};\\\", \\\"{x:1317,y:777,t:1527614102968};\\\", \\\"{x:1317,y:780,t:1527614102984};\\\", \\\"{x:1317,y:782,t:1527614103001};\\\", \\\"{x:1318,y:787,t:1527614103017};\\\", \\\"{x:1319,y:791,t:1527614103034};\\\", \\\"{x:1319,y:794,t:1527614103050};\\\", \\\"{x:1319,y:795,t:1527614103067};\\\", \\\"{x:1320,y:797,t:1527614103083};\\\", \\\"{x:1320,y:800,t:1527614103101};\\\", \\\"{x:1320,y:801,t:1527614103118};\\\", \\\"{x:1321,y:804,t:1527614103133};\\\", \\\"{x:1321,y:805,t:1527614103150};\\\", \\\"{x:1321,y:806,t:1527614103168};\\\", \\\"{x:1322,y:806,t:1527614106586};\\\", \\\"{x:1324,y:804,t:1527614106604};\\\", \\\"{x:1326,y:802,t:1527614106621};\\\", \\\"{x:1326,y:801,t:1527614106658};\\\", \\\"{x:1327,y:800,t:1527614106690};\\\", \\\"{x:1327,y:798,t:1527614108394};\\\", \\\"{x:1328,y:793,t:1527614108405};\\\", \\\"{x:1330,y:784,t:1527614108422};\\\", \\\"{x:1334,y:772,t:1527614108439};\\\", \\\"{x:1338,y:760,t:1527614108455};\\\", \\\"{x:1342,y:747,t:1527614108472};\\\", \\\"{x:1348,y:734,t:1527614108489};\\\", \\\"{x:1354,y:719,t:1527614108505};\\\", \\\"{x:1360,y:700,t:1527614108522};\\\", \\\"{x:1366,y:688,t:1527614108539};\\\", \\\"{x:1369,y:682,t:1527614108554};\\\", \\\"{x:1371,y:678,t:1527614108571};\\\", \\\"{x:1373,y:675,t:1527614108588};\\\", \\\"{x:1377,y:669,t:1527614108604};\\\", \\\"{x:1381,y:665,t:1527614108622};\\\", \\\"{x:1388,y:656,t:1527614108639};\\\", \\\"{x:1390,y:652,t:1527614108655};\\\", \\\"{x:1391,y:648,t:1527614108672};\\\", \\\"{x:1394,y:642,t:1527614108689};\\\", \\\"{x:1398,y:633,t:1527614108705};\\\", \\\"{x:1402,y:623,t:1527614108722};\\\", \\\"{x:1405,y:611,t:1527614108738};\\\", \\\"{x:1407,y:601,t:1527614108756};\\\", \\\"{x:1409,y:589,t:1527614108772};\\\", \\\"{x:1410,y:582,t:1527614108789};\\\", \\\"{x:1410,y:576,t:1527614108805};\\\", \\\"{x:1410,y:574,t:1527614108822};\\\", \\\"{x:1410,y:573,t:1527614108839};\\\", \\\"{x:1411,y:572,t:1527614108946};\\\", \\\"{x:1412,y:572,t:1527614108969};\\\", \\\"{x:1414,y:572,t:1527614108986};\\\", \\\"{x:1414,y:575,t:1527614108994};\\\", \\\"{x:1414,y:580,t:1527614109006};\\\", \\\"{x:1414,y:584,t:1527614109022};\\\", \\\"{x:1415,y:587,t:1527614109039};\\\", \\\"{x:1416,y:590,t:1527614109056};\\\", \\\"{x:1417,y:591,t:1527614109114};\\\", \\\"{x:1417,y:592,t:1527614109123};\\\", \\\"{x:1417,y:597,t:1527614109139};\\\", \\\"{x:1417,y:600,t:1527614109157};\\\", \\\"{x:1418,y:604,t:1527614109173};\\\", \\\"{x:1418,y:605,t:1527614109189};\\\", \\\"{x:1418,y:607,t:1527614109206};\\\", \\\"{x:1418,y:610,t:1527614109223};\\\", \\\"{x:1418,y:615,t:1527614109239};\\\", \\\"{x:1418,y:622,t:1527614109256};\\\", \\\"{x:1418,y:633,t:1527614109273};\\\", \\\"{x:1419,y:649,t:1527614109289};\\\", \\\"{x:1419,y:667,t:1527614109306};\\\", \\\"{x:1419,y:673,t:1527614109323};\\\", \\\"{x:1419,y:678,t:1527614109340};\\\", \\\"{x:1419,y:686,t:1527614109357};\\\", \\\"{x:1419,y:692,t:1527614109373};\\\", \\\"{x:1419,y:698,t:1527614109389};\\\", \\\"{x:1419,y:706,t:1527614109406};\\\", \\\"{x:1419,y:715,t:1527614109424};\\\", \\\"{x:1419,y:723,t:1527614109439};\\\", \\\"{x:1419,y:730,t:1527614109456};\\\", \\\"{x:1419,y:737,t:1527614109473};\\\", \\\"{x:1419,y:743,t:1527614109490};\\\", \\\"{x:1419,y:748,t:1527614109506};\\\", \\\"{x:1419,y:753,t:1527614109523};\\\", \\\"{x:1420,y:757,t:1527614109540};\\\", \\\"{x:1420,y:761,t:1527614109556};\\\", \\\"{x:1420,y:764,t:1527614109573};\\\", \\\"{x:1420,y:765,t:1527614109590};\\\", \\\"{x:1421,y:767,t:1527614109606};\\\", \\\"{x:1421,y:768,t:1527614109623};\\\", \\\"{x:1422,y:768,t:1527614110130};\\\", \\\"{x:1422,y:767,t:1527614110145};\\\", \\\"{x:1422,y:765,t:1527614110157};\\\", \\\"{x:1424,y:762,t:1527614110173};\\\", \\\"{x:1424,y:761,t:1527614110191};\\\", \\\"{x:1424,y:760,t:1527614110207};\\\", \\\"{x:1424,y:759,t:1527614110610};\\\", \\\"{x:1422,y:759,t:1527614110770};\\\", \\\"{x:1421,y:760,t:1527614110778};\\\", \\\"{x:1420,y:760,t:1527614110791};\\\", \\\"{x:1419,y:760,t:1527614110807};\\\", \\\"{x:1418,y:760,t:1527614110825};\\\", \\\"{x:1415,y:762,t:1527614115083};\\\", \\\"{x:1413,y:764,t:1527614115094};\\\", \\\"{x:1409,y:768,t:1527614115111};\\\", \\\"{x:1409,y:769,t:1527614115426};\\\", \\\"{x:1408,y:769,t:1527614117986};\\\", \\\"{x:1408,y:770,t:1527614117997};\\\", \\\"{x:1403,y:771,t:1527614120146};\\\", \\\"{x:1382,y:771,t:1527614120153};\\\", \\\"{x:1352,y:771,t:1527614120165};\\\", \\\"{x:1288,y:763,t:1527614120182};\\\", \\\"{x:1220,y:751,t:1527614120199};\\\", \\\"{x:1131,y:736,t:1527614120215};\\\", \\\"{x:1039,y:724,t:1527614120233};\\\", \\\"{x:942,y:711,t:1527614120248};\\\", \\\"{x:773,y:693,t:1527614120265};\\\", \\\"{x:676,y:681,t:1527614120282};\\\", \\\"{x:615,y:672,t:1527614120298};\\\", \\\"{x:577,y:666,t:1527614120315};\\\", \\\"{x:547,y:662,t:1527614120334};\\\", \\\"{x:527,y:662,t:1527614120348};\\\", \\\"{x:507,y:662,t:1527614120365};\\\", \\\"{x:492,y:662,t:1527614120381};\\\", \\\"{x:481,y:664,t:1527614120398};\\\", \\\"{x:473,y:667,t:1527614120414};\\\", \\\"{x:467,y:668,t:1527614120432};\\\", \\\"{x:462,y:672,t:1527614120447};\\\", \\\"{x:457,y:674,t:1527614120463};\\\", \\\"{x:455,y:685,t:1527614120481};\\\", \\\"{x:455,y:704,t:1527614120497};\\\", \\\"{x:455,y:727,t:1527614120515};\\\", \\\"{x:466,y:749,t:1527614120531};\\\", \\\"{x:475,y:760,t:1527614120548};\\\", \\\"{x:478,y:762,t:1527614120563};\\\", \\\"{x:479,y:763,t:1527614120581};\\\", \\\"{x:480,y:763,t:1527614120601};\\\", \\\"{x:481,y:763,t:1527614120614};\\\", \\\"{x:489,y:762,t:1527614120632};\\\", \\\"{x:498,y:755,t:1527614120648};\\\", \\\"{x:504,y:750,t:1527614120664};\\\", \\\"{x:504,y:747,t:1527614120682};\\\", \\\"{x:507,y:744,t:1527614120698};\\\", \\\"{x:507,y:743,t:1527614120715};\\\", \\\"{x:507,y:741,t:1527614120737};\\\", \\\"{x:507,y:740,t:1527614120754};\\\", \\\"{x:507,y:739,t:1527614120766};\\\", \\\"{x:508,y:736,t:1527614120781};\\\", \\\"{x:509,y:734,t:1527614120798};\\\", \\\"{x:509,y:733,t:1527614120815};\\\", \\\"{x:510,y:732,t:1527614120832};\\\", \\\"{x:510,y:731,t:1527614120848};\\\" ] }, { \\\"rt\\\": 9525, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 10, \\\"time_elapsed\\\": 464551, \\\"internal_node_id\\\": \\\"0.0-6.0-0.0\\\", \\\"subject\\\": \\\"TGOML\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"oscar\\\", \\\"condition\\\": \\\"114\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"duration\\\", \\\"q\\\": 6, \\\"clicks\\\": 2, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XInside-YInside\\\", \\\"correct\\\": 1, \\\"orth_correct\\\": 1, \\\"answer\\\": [ \\\"E\\\", \\\"G\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-E \\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:510,y:730,t:1527614123105};\\\", \\\"{x:510,y:729,t:1527614126666};\\\", \\\"{x:515,y:726,t:1527614126673};\\\", \\\"{x:521,y:722,t:1527614126683};\\\", \\\"{x:529,y:717,t:1527614126701};\\\", \\\"{x:535,y:714,t:1527614126717};\\\", \\\"{x:541,y:711,t:1527614126734};\\\", \\\"{x:572,y:694,t:1527614126753};\\\", \\\"{x:615,y:673,t:1527614126770};\\\", \\\"{x:639,y:662,t:1527614126786};\\\", \\\"{x:689,y:643,t:1527614126803};\\\", \\\"{x:727,y:630,t:1527614126820};\\\", \\\"{x:772,y:611,t:1527614126835};\\\", \\\"{x:817,y:596,t:1527614126854};\\\", \\\"{x:877,y:585,t:1527614126869};\\\", \\\"{x:930,y:577,t:1527614126886};\\\", \\\"{x:973,y:568,t:1527614126903};\\\", \\\"{x:1015,y:557,t:1527614126920};\\\", \\\"{x:1043,y:549,t:1527614126936};\\\", \\\"{x:1064,y:542,t:1527614126953};\\\", \\\"{x:1067,y:541,t:1527614126970};\\\", \\\"{x:1069,y:541,t:1527614126986};\\\", \\\"{x:1075,y:540,t:1527614127003};\\\", \\\"{x:1085,y:540,t:1527614127021};\\\", \\\"{x:1104,y:540,t:1527614127036};\\\", \\\"{x:1126,y:540,t:1527614127054};\\\", \\\"{x:1157,y:540,t:1527614127070};\\\", \\\"{x:1194,y:540,t:1527614127087};\\\", \\\"{x:1236,y:540,t:1527614127104};\\\", \\\"{x:1281,y:546,t:1527614127121};\\\", \\\"{x:1343,y:555,t:1527614127137};\\\", \\\"{x:1426,y:569,t:1527614127153};\\\", \\\"{x:1468,y:575,t:1527614127170};\\\", \\\"{x:1500,y:578,t:1527614127188};\\\", \\\"{x:1519,y:582,t:1527614127204};\\\", \\\"{x:1537,y:582,t:1527614127221};\\\", \\\"{x:1551,y:582,t:1527614127237};\\\", \\\"{x:1565,y:582,t:1527614127254};\\\", \\\"{x:1573,y:582,t:1527614127270};\\\", \\\"{x:1577,y:582,t:1527614127287};\\\", \\\"{x:1578,y:582,t:1527614127303};\\\", \\\"{x:1577,y:582,t:1527614127473};\\\", \\\"{x:1575,y:582,t:1527614127489};\\\", \\\"{x:1572,y:582,t:1527614127504};\\\", \\\"{x:1563,y:582,t:1527614127520};\\\", \\\"{x:1508,y:585,t:1527614127537};\\\", \\\"{x:1424,y:590,t:1527614127555};\\\", \\\"{x:1315,y:590,t:1527614127571};\\\", \\\"{x:1169,y:590,t:1527614127588};\\\", \\\"{x:1028,y:590,t:1527614127604};\\\", \\\"{x:878,y:585,t:1527614127622};\\\", \\\"{x:712,y:567,t:1527614127637};\\\", \\\"{x:540,y:561,t:1527614127654};\\\", \\\"{x:369,y:561,t:1527614127670};\\\", \\\"{x:236,y:561,t:1527614127687};\\\", \\\"{x:144,y:561,t:1527614127703};\\\", \\\"{x:82,y:559,t:1527614127720};\\\", \\\"{x:37,y:555,t:1527614127737};\\\", \\\"{x:20,y:555,t:1527614127753};\\\", \\\"{x:9,y:555,t:1527614127770};\\\", \\\"{x:3,y:555,t:1527614127787};\\\", \\\"{x:0,y:552,t:1527614127804};\\\", \\\"{x:0,y:549,t:1527614127820};\\\", \\\"{x:1,y:549,t:1527614128962};\\\", \\\"{x:2,y:549,t:1527614128994};\\\", \\\"{x:5,y:549,t:1527614129004};\\\", \\\"{x:10,y:549,t:1527614129021};\\\", \\\"{x:21,y:549,t:1527614129038};\\\", \\\"{x:36,y:547,t:1527614129054};\\\", \\\"{x:54,y:544,t:1527614129073};\\\", \\\"{x:70,y:543,t:1527614129088};\\\", \\\"{x:89,y:541,t:1527614129104};\\\", \\\"{x:115,y:539,t:1527614129121};\\\", \\\"{x:135,y:536,t:1527614129138};\\\", \\\"{x:172,y:525,t:1527614129155};\\\", \\\"{x:213,y:515,t:1527614129172};\\\", \\\"{x:261,y:499,t:1527614129188};\\\", \\\"{x:308,y:486,t:1527614129206};\\\", \\\"{x:345,y:475,t:1527614129221};\\\", \\\"{x:365,y:468,t:1527614129238};\\\", \\\"{x:375,y:466,t:1527614129255};\\\", \\\"{x:378,y:465,t:1527614129272};\\\", \\\"{x:375,y:468,t:1527614129369};\\\", \\\"{x:371,y:473,t:1527614129378};\\\", \\\"{x:367,y:477,t:1527614129388};\\\", \\\"{x:363,y:485,t:1527614129405};\\\", \\\"{x:362,y:489,t:1527614129423};\\\", \\\"{x:362,y:491,t:1527614129439};\\\", \\\"{x:363,y:494,t:1527614129456};\\\", \\\"{x:378,y:498,t:1527614129473};\\\", \\\"{x:404,y:499,t:1527614129489};\\\", \\\"{x:471,y:499,t:1527614129506};\\\", \\\"{x:522,y:499,t:1527614129522};\\\", \\\"{x:564,y:499,t:1527614129538};\\\", \\\"{x:600,y:499,t:1527614129555};\\\", \\\"{x:617,y:499,t:1527614129572};\\\", \\\"{x:621,y:499,t:1527614129588};\\\", \\\"{x:622,y:499,t:1527614129605};\\\", \\\"{x:621,y:499,t:1527614129842};\\\", \\\"{x:618,y:499,t:1527614129856};\\\", \\\"{x:617,y:499,t:1527614129872};\\\", \\\"{x:618,y:499,t:1527614130368};\\\", \\\"{x:621,y:499,t:1527614130377};\\\", \\\"{x:626,y:500,t:1527614130389};\\\", \\\"{x:635,y:502,t:1527614130406};\\\", \\\"{x:650,y:505,t:1527614130423};\\\", \\\"{x:670,y:508,t:1527614130439};\\\", \\\"{x:697,y:512,t:1527614130456};\\\", \\\"{x:737,y:518,t:1527614130473};\\\", \\\"{x:800,y:528,t:1527614130490};\\\", \\\"{x:829,y:528,t:1527614130506};\\\", \\\"{x:847,y:528,t:1527614130522};\\\", \\\"{x:851,y:528,t:1527614130539};\\\", \\\"{x:851,y:529,t:1527614130721};\\\", \\\"{x:851,y:530,t:1527614130729};\\\", \\\"{x:852,y:531,t:1527614130739};\\\", \\\"{x:852,y:532,t:1527614130757};\\\", \\\"{x:852,y:533,t:1527614130773};\\\", \\\"{x:852,y:534,t:1527614130793};\\\", \\\"{x:852,y:535,t:1527614130833};\\\", \\\"{x:852,y:536,t:1527614130841};\\\", \\\"{x:850,y:536,t:1527614130856};\\\", \\\"{x:849,y:536,t:1527614130873};\\\", \\\"{x:848,y:536,t:1527614130889};\\\", \\\"{x:847,y:536,t:1527614130906};\\\", \\\"{x:846,y:536,t:1527614130924};\\\", \\\"{x:845,y:536,t:1527614130953};\\\", \\\"{x:839,y:536,t:1527614131248};\\\", \\\"{x:830,y:540,t:1527614131257};\\\", \\\"{x:804,y:553,t:1527614131273};\\\", \\\"{x:766,y:574,t:1527614131290};\\\", \\\"{x:732,y:595,t:1527614131307};\\\", \\\"{x:689,y:621,t:1527614131323};\\\", \\\"{x:660,y:638,t:1527614131340};\\\", \\\"{x:629,y:656,t:1527614131356};\\\", \\\"{x:607,y:671,t:1527614131373};\\\", \\\"{x:593,y:685,t:1527614131390};\\\", \\\"{x:588,y:693,t:1527614131406};\\\", \\\"{x:587,y:701,t:1527614131424};\\\", \\\"{x:586,y:708,t:1527614131440};\\\", \\\"{x:585,y:724,t:1527614131457};\\\", \\\"{x:583,y:738,t:1527614131473};\\\", \\\"{x:580,y:752,t:1527614131490};\\\", \\\"{x:578,y:764,t:1527614131507};\\\", \\\"{x:578,y:769,t:1527614131524};\\\", \\\"{x:577,y:772,t:1527614131541};\\\", \\\"{x:576,y:772,t:1527614131557};\\\", \\\"{x:575,y:774,t:1527614131573};\\\", \\\"{x:572,y:777,t:1527614131590};\\\", \\\"{x:569,y:779,t:1527614131607};\\\", \\\"{x:568,y:780,t:1527614131624};\\\", \\\"{x:567,y:780,t:1527614131641};\\\", \\\"{x:566,y:780,t:1527614131690};\\\", \\\"{x:558,y:770,t:1527614131717};\\\", \\\"{x:557,y:766,t:1527614131724};\\\", \\\"{x:551,y:756,t:1527614131740};\\\", \\\"{x:546,y:750,t:1527614131758};\\\", \\\"{x:543,y:747,t:1527614131774};\\\" ] }, { \\\"rt\\\": 21921, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 11, \\\"time_elapsed\\\": 487742, \\\"internal_node_id\\\": \\\"0.0-6.0-1.0\\\", \\\"subject\\\": \\\"TGOML\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"oscar\\\", \\\"condition\\\": \\\"114\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"duration+starts\\\", \\\"q\\\": 7, \\\"clicks\\\": 2, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XInside-YInside\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 1, \\\"answer\\\": [ \\\"F\\\", \\\"B\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-H -H \\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:543,y:746,t:1527614140778};\\\", \\\"{x:548,y:744,t:1527614142377};\\\", \\\"{x:555,y:741,t:1527614142385};\\\", \\\"{x:565,y:739,t:1527614142402};\\\", \\\"{x:585,y:730,t:1527614142416};\\\", \\\"{x:594,y:724,t:1527614142434};\\\", \\\"{x:604,y:718,t:1527614142448};\\\", \\\"{x:613,y:712,t:1527614142465};\\\", \\\"{x:629,y:704,t:1527614142482};\\\", \\\"{x:651,y:695,t:1527614142498};\\\", \\\"{x:675,y:686,t:1527614142515};\\\", \\\"{x:697,y:678,t:1527614142533};\\\", \\\"{x:719,y:673,t:1527614142549};\\\", \\\"{x:745,y:668,t:1527614142566};\\\", \\\"{x:784,y:663,t:1527614142583};\\\", \\\"{x:847,y:658,t:1527614142598};\\\", \\\"{x:929,y:654,t:1527614142616};\\\", \\\"{x:1028,y:647,t:1527614142633};\\\", \\\"{x:1082,y:647,t:1527614142649};\\\", \\\"{x:1117,y:647,t:1527614142666};\\\", \\\"{x:1153,y:646,t:1527614142683};\\\", \\\"{x:1179,y:646,t:1527614142701};\\\", \\\"{x:1197,y:646,t:1527614142716};\\\", \\\"{x:1206,y:643,t:1527614142733};\\\", \\\"{x:1208,y:643,t:1527614142750};\\\", \\\"{x:1208,y:642,t:1527614142766};\\\", \\\"{x:1211,y:640,t:1527614142783};\\\", \\\"{x:1216,y:639,t:1527614142800};\\\", \\\"{x:1226,y:636,t:1527614142816};\\\", \\\"{x:1243,y:632,t:1527614142833};\\\", \\\"{x:1253,y:630,t:1527614142850};\\\", \\\"{x:1263,y:627,t:1527614142866};\\\", \\\"{x:1276,y:626,t:1527614142883};\\\", \\\"{x:1296,y:626,t:1527614142900};\\\", \\\"{x:1325,y:626,t:1527614142916};\\\", \\\"{x:1363,y:626,t:1527614142933};\\\", \\\"{x:1397,y:626,t:1527614142950};\\\", \\\"{x:1431,y:626,t:1527614142966};\\\", \\\"{x:1457,y:626,t:1527614142983};\\\", \\\"{x:1478,y:626,t:1527614143000};\\\", \\\"{x:1490,y:625,t:1527614143016};\\\", \\\"{x:1495,y:624,t:1527614143033};\\\", \\\"{x:1495,y:623,t:1527614143057};\\\", \\\"{x:1496,y:622,t:1527614143073};\\\", \\\"{x:1497,y:622,t:1527614143089};\\\", \\\"{x:1498,y:622,t:1527614143100};\\\", \\\"{x:1499,y:621,t:1527614143116};\\\", \\\"{x:1500,y:621,t:1527614143133};\\\", \\\"{x:1500,y:620,t:1527614143368};\\\", \\\"{x:1501,y:620,t:1527614143382};\\\", \\\"{x:1502,y:620,t:1527614143400};\\\", \\\"{x:1503,y:620,t:1527614143416};\\\", \\\"{x:1504,y:620,t:1527614143432};\\\", \\\"{x:1506,y:620,t:1527614143449};\\\", \\\"{x:1511,y:620,t:1527614143467};\\\", \\\"{x:1518,y:620,t:1527614143482};\\\", \\\"{x:1529,y:620,t:1527614143500};\\\", \\\"{x:1544,y:620,t:1527614143516};\\\", \\\"{x:1556,y:620,t:1527614143533};\\\", \\\"{x:1562,y:620,t:1527614143550};\\\", \\\"{x:1565,y:620,t:1527614143567};\\\", \\\"{x:1567,y:620,t:1527614143584};\\\", \\\"{x:1568,y:620,t:1527614143600};\\\", \\\"{x:1570,y:620,t:1527614143617};\\\", \\\"{x:1571,y:620,t:1527614143634};\\\", \\\"{x:1573,y:620,t:1527614143650};\\\", \\\"{x:1574,y:620,t:1527614143667};\\\", \\\"{x:1575,y:619,t:1527614143684};\\\", \\\"{x:1577,y:619,t:1527614143700};\\\", \\\"{x:1580,y:619,t:1527614143717};\\\", \\\"{x:1581,y:619,t:1527614143734};\\\", \\\"{x:1583,y:619,t:1527614143749};\\\", \\\"{x:1585,y:619,t:1527614143768};\\\", \\\"{x:1586,y:619,t:1527614143784};\\\", \\\"{x:1587,y:619,t:1527614143834};\\\", \\\"{x:1589,y:619,t:1527614143993};\\\", \\\"{x:1589,y:620,t:1527614144033};\\\", \\\"{x:1589,y:621,t:1527614144065};\\\", \\\"{x:1589,y:622,t:1527614144090};\\\", \\\"{x:1589,y:623,t:1527614144105};\\\", \\\"{x:1588,y:623,t:1527614144117};\\\", \\\"{x:1587,y:624,t:1527614144134};\\\", \\\"{x:1586,y:624,t:1527614144151};\\\", \\\"{x:1586,y:625,t:1527614144168};\\\", \\\"{x:1585,y:626,t:1527614144187};\\\", \\\"{x:1584,y:626,t:1527614144256};\\\", \\\"{x:1581,y:626,t:1527614150573};\\\", \\\"{x:1571,y:627,t:1527614150582};\\\", \\\"{x:1556,y:630,t:1527614150594};\\\", \\\"{x:1497,y:631,t:1527614150611};\\\", \\\"{x:1420,y:638,t:1527614150626};\\\", \\\"{x:1331,y:638,t:1527614150643};\\\", \\\"{x:1245,y:638,t:1527614150661};\\\", \\\"{x:1104,y:638,t:1527614150677};\\\", \\\"{x:998,y:638,t:1527614150693};\\\", \\\"{x:896,y:638,t:1527614150710};\\\", \\\"{x:807,y:638,t:1527614150727};\\\", \\\"{x:735,y:638,t:1527614150743};\\\", \\\"{x:692,y:638,t:1527614150760};\\\", \\\"{x:663,y:638,t:1527614150776};\\\", \\\"{x:643,y:638,t:1527614150793};\\\", \\\"{x:625,y:638,t:1527614150810};\\\", \\\"{x:609,y:644,t:1527614150827};\\\", \\\"{x:595,y:647,t:1527614150843};\\\", \\\"{x:573,y:654,t:1527614150861};\\\", \\\"{x:554,y:659,t:1527614150877};\\\", \\\"{x:527,y:665,t:1527614150893};\\\", \\\"{x:500,y:672,t:1527614150911};\\\", \\\"{x:474,y:674,t:1527614150927};\\\", \\\"{x:456,y:674,t:1527614150944};\\\", \\\"{x:448,y:674,t:1527614150960};\\\", \\\"{x:444,y:674,t:1527614150977};\\\", \\\"{x:443,y:674,t:1527614150993};\\\", \\\"{x:442,y:674,t:1527614151021};\\\", \\\"{x:442,y:673,t:1527614151028};\\\", \\\"{x:441,y:670,t:1527614151043};\\\", \\\"{x:437,y:661,t:1527614151061};\\\", \\\"{x:435,y:650,t:1527614151077};\\\", \\\"{x:433,y:643,t:1527614151093};\\\", \\\"{x:432,y:639,t:1527614151109};\\\", \\\"{x:432,y:636,t:1527614151127};\\\", \\\"{x:432,y:634,t:1527614151143};\\\", \\\"{x:436,y:629,t:1527614151160};\\\", \\\"{x:442,y:626,t:1527614151177};\\\", \\\"{x:450,y:622,t:1527614151194};\\\", \\\"{x:458,y:618,t:1527614151210};\\\", \\\"{x:463,y:616,t:1527614151227};\\\", \\\"{x:464,y:615,t:1527614151243};\\\", \\\"{x:466,y:615,t:1527614151259};\\\", \\\"{x:467,y:614,t:1527614151277};\\\", \\\"{x:467,y:613,t:1527614151428};\\\", \\\"{x:472,y:609,t:1527614151445};\\\", \\\"{x:479,y:604,t:1527614151460};\\\", \\\"{x:493,y:597,t:1527614151478};\\\", \\\"{x:509,y:587,t:1527614151496};\\\", \\\"{x:524,y:582,t:1527614151510};\\\", \\\"{x:536,y:576,t:1527614151526};\\\", \\\"{x:541,y:572,t:1527614151543};\\\", \\\"{x:544,y:570,t:1527614151560};\\\", \\\"{x:547,y:567,t:1527614151577};\\\", \\\"{x:553,y:564,t:1527614151594};\\\", \\\"{x:558,y:561,t:1527614151611};\\\", \\\"{x:563,y:558,t:1527614151627};\\\", \\\"{x:567,y:554,t:1527614151644};\\\", \\\"{x:569,y:553,t:1527614151661};\\\", \\\"{x:571,y:551,t:1527614151677};\\\", \\\"{x:574,y:549,t:1527614151693};\\\", \\\"{x:576,y:547,t:1527614151711};\\\", \\\"{x:579,y:544,t:1527614151727};\\\", \\\"{x:581,y:541,t:1527614151744};\\\", \\\"{x:582,y:539,t:1527614151760};\\\", \\\"{x:583,y:538,t:1527614151777};\\\", \\\"{x:584,y:536,t:1527614151794};\\\", \\\"{x:585,y:534,t:1527614151811};\\\", \\\"{x:587,y:532,t:1527614151827};\\\", \\\"{x:587,y:531,t:1527614151845};\\\", \\\"{x:588,y:529,t:1527614151860};\\\", \\\"{x:589,y:529,t:1527614151884};\\\", \\\"{x:589,y:528,t:1527614151941};\\\", \\\"{x:591,y:528,t:1527614152021};\\\", \\\"{x:592,y:528,t:1527614152029};\\\", \\\"{x:593,y:528,t:1527614152044};\\\", \\\"{x:609,y:533,t:1527614152061};\\\", \\\"{x:626,y:536,t:1527614152078};\\\", \\\"{x:646,y:539,t:1527614152094};\\\", \\\"{x:661,y:541,t:1527614152110};\\\", \\\"{x:674,y:541,t:1527614152127};\\\", \\\"{x:682,y:541,t:1527614152144};\\\", \\\"{x:691,y:542,t:1527614152161};\\\", \\\"{x:697,y:542,t:1527614152178};\\\", \\\"{x:705,y:542,t:1527614152194};\\\", \\\"{x:714,y:542,t:1527614152211};\\\", \\\"{x:729,y:542,t:1527614152229};\\\", \\\"{x:742,y:542,t:1527614152244};\\\", \\\"{x:757,y:542,t:1527614152260};\\\", \\\"{x:773,y:542,t:1527614152278};\\\", \\\"{x:788,y:542,t:1527614152295};\\\", \\\"{x:802,y:542,t:1527614152310};\\\", \\\"{x:808,y:544,t:1527614152328};\\\", \\\"{x:814,y:546,t:1527614152345};\\\", \\\"{x:817,y:546,t:1527614152361};\\\", \\\"{x:819,y:546,t:1527614152378};\\\", \\\"{x:824,y:546,t:1527614152395};\\\", \\\"{x:829,y:548,t:1527614152410};\\\", \\\"{x:841,y:550,t:1527614152428};\\\", \\\"{x:845,y:550,t:1527614152445};\\\", \\\"{x:846,y:550,t:1527614152485};\\\", \\\"{x:845,y:550,t:1527614152645};\\\", \\\"{x:845,y:549,t:1527614152662};\\\", \\\"{x:844,y:546,t:1527614152677};\\\", \\\"{x:844,y:540,t:1527614152695};\\\", \\\"{x:844,y:535,t:1527614152711};\\\", \\\"{x:844,y:531,t:1527614152728};\\\", \\\"{x:844,y:527,t:1527614152745};\\\", \\\"{x:844,y:525,t:1527614152762};\\\", \\\"{x:844,y:524,t:1527614152779};\\\", \\\"{x:844,y:523,t:1527614152804};\\\", \\\"{x:844,y:522,t:1527614152820};\\\", \\\"{x:844,y:521,t:1527614152828};\\\", \\\"{x:843,y:519,t:1527614152845};\\\", \\\"{x:843,y:518,t:1527614152862};\\\", \\\"{x:842,y:515,t:1527614152879};\\\", \\\"{x:842,y:514,t:1527614152895};\\\", \\\"{x:842,y:513,t:1527614152912};\\\", \\\"{x:841,y:512,t:1527614152928};\\\", \\\"{x:841,y:511,t:1527614152972};\\\", \\\"{x:841,y:510,t:1527614152996};\\\", \\\"{x:839,y:510,t:1527614153236};\\\", \\\"{x:829,y:510,t:1527614153245};\\\", \\\"{x:793,y:513,t:1527614153263};\\\", \\\"{x:716,y:529,t:1527614153279};\\\", \\\"{x:642,y:549,t:1527614153295};\\\", \\\"{x:561,y:572,t:1527614153312};\\\", \\\"{x:480,y:600,t:1527614153329};\\\", \\\"{x:380,y:630,t:1527614153345};\\\", \\\"{x:272,y:661,t:1527614153362};\\\", \\\"{x:183,y:674,t:1527614153379};\\\", \\\"{x:105,y:685,t:1527614153395};\\\", \\\"{x:66,y:691,t:1527614153412};\\\", \\\"{x:62,y:693,t:1527614153428};\\\", \\\"{x:61,y:691,t:1527614153525};\\\", \\\"{x:61,y:685,t:1527614153533};\\\", \\\"{x:61,y:681,t:1527614153545};\\\", \\\"{x:64,y:672,t:1527614153562};\\\", \\\"{x:72,y:663,t:1527614153580};\\\", \\\"{x:91,y:652,t:1527614153596};\\\", \\\"{x:111,y:646,t:1527614153612};\\\", \\\"{x:132,y:640,t:1527614153629};\\\", \\\"{x:149,y:632,t:1527614153647};\\\", \\\"{x:157,y:628,t:1527614153663};\\\", \\\"{x:159,y:626,t:1527614153680};\\\", \\\"{x:163,y:623,t:1527614153696};\\\", \\\"{x:167,y:621,t:1527614153712};\\\", \\\"{x:176,y:614,t:1527614153729};\\\", \\\"{x:186,y:606,t:1527614153746};\\\", \\\"{x:192,y:599,t:1527614153763};\\\", \\\"{x:195,y:594,t:1527614153779};\\\", \\\"{x:196,y:589,t:1527614153797};\\\", \\\"{x:196,y:586,t:1527614153813};\\\", \\\"{x:194,y:583,t:1527614153829};\\\", \\\"{x:190,y:581,t:1527614153848};\\\", \\\"{x:189,y:580,t:1527614153862};\\\", \\\"{x:188,y:580,t:1527614153879};\\\", \\\"{x:187,y:579,t:1527614153896};\\\", \\\"{x:187,y:578,t:1527614153912};\\\", \\\"{x:187,y:576,t:1527614153929};\\\", \\\"{x:186,y:574,t:1527614153946};\\\", \\\"{x:185,y:572,t:1527614153962};\\\", \\\"{x:185,y:570,t:1527614153978};\\\", \\\"{x:185,y:568,t:1527614153996};\\\", \\\"{x:185,y:567,t:1527614154012};\\\", \\\"{x:184,y:566,t:1527614154028};\\\", \\\"{x:183,y:565,t:1527614154047};\\\", \\\"{x:183,y:562,t:1527614154063};\\\", \\\"{x:181,y:561,t:1527614154079};\\\", \\\"{x:181,y:559,t:1527614154096};\\\", \\\"{x:179,y:558,t:1527614154113};\\\", \\\"{x:178,y:556,t:1527614154129};\\\", \\\"{x:177,y:555,t:1527614154146};\\\", \\\"{x:175,y:555,t:1527614154163};\\\", \\\"{x:174,y:554,t:1527614154179};\\\", \\\"{x:173,y:553,t:1527614154196};\\\", \\\"{x:172,y:552,t:1527614154227};\\\", \\\"{x:171,y:552,t:1527614154235};\\\", \\\"{x:170,y:552,t:1527614154251};\\\", \\\"{x:169,y:550,t:1527614154263};\\\", \\\"{x:167,y:550,t:1527614154278};\\\", \\\"{x:164,y:548,t:1527614154296};\\\", \\\"{x:163,y:548,t:1527614154316};\\\", \\\"{x:162,y:547,t:1527614154348};\\\", \\\"{x:161,y:547,t:1527614154372};\\\", \\\"{x:160,y:546,t:1527614154380};\\\", \\\"{x:159,y:545,t:1527614154395};\\\", \\\"{x:159,y:544,t:1527614154413};\\\", \\\"{x:173,y:551,t:1527614154669};\\\", \\\"{x:197,y:564,t:1527614154681};\\\", \\\"{x:262,y:598,t:1527614154696};\\\", \\\"{x:339,y:632,t:1527614154713};\\\", \\\"{x:393,y:652,t:1527614154730};\\\", \\\"{x:426,y:662,t:1527614154747};\\\", \\\"{x:442,y:668,t:1527614154763};\\\", \\\"{x:450,y:676,t:1527614154780};\\\", \\\"{x:451,y:679,t:1527614154797};\\\", \\\"{x:452,y:681,t:1527614154813};\\\", \\\"{x:453,y:683,t:1527614154830};\\\", \\\"{x:454,y:685,t:1527614154848};\\\", \\\"{x:454,y:686,t:1527614154863};\\\", \\\"{x:455,y:687,t:1527614154880};\\\", \\\"{x:456,y:689,t:1527614154897};\\\", \\\"{x:457,y:691,t:1527614154913};\\\", \\\"{x:458,y:694,t:1527614154930};\\\", \\\"{x:460,y:701,t:1527614154947};\\\", \\\"{x:462,y:707,t:1527614154964};\\\", \\\"{x:469,y:723,t:1527614154982};\\\", \\\"{x:472,y:729,t:1527614154997};\\\", \\\"{x:473,y:731,t:1527614155013};\\\", \\\"{x:474,y:731,t:1527614155221};\\\", \\\"{x:475,y:731,t:1527614155237};\\\", \\\"{x:476,y:731,t:1527614155268};\\\" ] }, { \\\"rt\\\": 39241, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 12, \\\"time_elapsed\\\": 528225, \\\"internal_node_id\\\": \\\"0.0-6.0-2.0\\\", \\\"subject\\\": \\\"TGOML\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"oscar\\\", \\\"condition\\\": \\\"114\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"duration+contained\\\", \\\"q\\\": 8, \\\"clicks\\\": 1, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XInside-YInside\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 1, \\\"answer\\\": [ \\\"E\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-L -L -J -E \\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:480,y:728,t:1527614159774};\\\", \\\"{x:501,y:719,t:1527614159788};\\\", \\\"{x:576,y:698,t:1527614159803};\\\", \\\"{x:739,y:651,t:1527614159820};\\\", \\\"{x:806,y:629,t:1527614159835};\\\", \\\"{x:950,y:590,t:1527614159852};\\\", \\\"{x:1115,y:548,t:1527614159867};\\\", \\\"{x:1382,y:507,t:1527614159883};\\\", \\\"{x:1567,y:485,t:1527614159900};\\\", \\\"{x:1744,y:483,t:1527614159917};\\\", \\\"{x:1874,y:480,t:1527614159934};\\\", \\\"{x:1919,y:470,t:1527614159950};\\\", \\\"{x:1917,y:470,t:1527614161373};\\\", \\\"{x:1916,y:470,t:1527614161396};\\\", \\\"{x:1914,y:470,t:1527614161412};\\\", \\\"{x:1913,y:470,t:1527614161423};\\\", \\\"{x:1909,y:470,t:1527614161440};\\\", \\\"{x:1905,y:470,t:1527614161456};\\\", \\\"{x:1900,y:468,t:1527614161474};\\\", \\\"{x:1896,y:468,t:1527614161489};\\\", \\\"{x:1895,y:468,t:1527614161502};\\\", \\\"{x:1894,y:468,t:1527614161573};\\\", \\\"{x:1893,y:468,t:1527614161586};\\\", \\\"{x:1892,y:467,t:1527614171653};\\\", \\\"{x:1883,y:467,t:1527614171853};\\\", \\\"{x:1868,y:467,t:1527614171864};\\\", \\\"{x:1837,y:468,t:1527614171879};\\\", \\\"{x:1804,y:468,t:1527614171896};\\\", \\\"{x:1766,y:468,t:1527614171913};\\\", \\\"{x:1707,y:470,t:1527614171929};\\\", \\\"{x:1651,y:472,t:1527614171946};\\\", \\\"{x:1603,y:473,t:1527614171963};\\\", \\\"{x:1552,y:473,t:1527614171979};\\\", \\\"{x:1512,y:473,t:1527614171996};\\\", \\\"{x:1489,y:473,t:1527614172013};\\\", \\\"{x:1469,y:475,t:1527614172030};\\\", \\\"{x:1457,y:477,t:1527614172047};\\\", \\\"{x:1448,y:480,t:1527614172064};\\\", \\\"{x:1441,y:481,t:1527614172080};\\\", \\\"{x:1436,y:482,t:1527614172096};\\\", \\\"{x:1418,y:485,t:1527614172114};\\\", \\\"{x:1390,y:487,t:1527614172130};\\\", \\\"{x:1356,y:487,t:1527614172146};\\\", \\\"{x:1314,y:487,t:1527614172163};\\\", \\\"{x:1257,y:487,t:1527614172180};\\\", \\\"{x:1230,y:487,t:1527614172196};\\\", \\\"{x:1200,y:487,t:1527614172213};\\\", \\\"{x:1174,y:487,t:1527614172230};\\\", \\\"{x:1147,y:487,t:1527614172246};\\\", \\\"{x:1129,y:487,t:1527614172264};\\\", \\\"{x:1122,y:487,t:1527614172280};\\\", \\\"{x:1120,y:487,t:1527614172296};\\\", \\\"{x:1119,y:487,t:1527614172333};\\\", \\\"{x:1119,y:488,t:1527614172469};\\\", \\\"{x:1122,y:488,t:1527614172480};\\\", \\\"{x:1136,y:488,t:1527614172497};\\\", \\\"{x:1152,y:488,t:1527614172513};\\\", \\\"{x:1173,y:487,t:1527614172530};\\\", \\\"{x:1197,y:487,t:1527614172548};\\\", \\\"{x:1225,y:487,t:1527614172563};\\\", \\\"{x:1272,y:487,t:1527614172581};\\\", \\\"{x:1299,y:487,t:1527614172597};\\\", \\\"{x:1322,y:487,t:1527614172613};\\\", \\\"{x:1340,y:487,t:1527614172630};\\\", \\\"{x:1352,y:487,t:1527614172648};\\\", \\\"{x:1361,y:487,t:1527614172663};\\\", \\\"{x:1372,y:487,t:1527614172680};\\\", \\\"{x:1380,y:487,t:1527614172697};\\\", \\\"{x:1388,y:486,t:1527614172714};\\\", \\\"{x:1392,y:485,t:1527614172731};\\\", \\\"{x:1394,y:484,t:1527614172747};\\\", \\\"{x:1404,y:484,t:1527614172765};\\\", \\\"{x:1417,y:484,t:1527614172780};\\\", \\\"{x:1436,y:484,t:1527614172797};\\\", \\\"{x:1458,y:484,t:1527614172814};\\\", \\\"{x:1477,y:484,t:1527614172830};\\\", \\\"{x:1488,y:484,t:1527614172847};\\\", \\\"{x:1497,y:484,t:1527614172864};\\\", \\\"{x:1505,y:484,t:1527614172880};\\\", \\\"{x:1514,y:484,t:1527614172898};\\\", \\\"{x:1521,y:484,t:1527614172914};\\\", \\\"{x:1524,y:484,t:1527614172930};\\\", \\\"{x:1525,y:484,t:1527614172948};\\\", \\\"{x:1529,y:484,t:1527614172964};\\\", \\\"{x:1536,y:484,t:1527614172981};\\\", \\\"{x:1546,y:484,t:1527614172997};\\\", \\\"{x:1553,y:484,t:1527614173014};\\\", \\\"{x:1556,y:484,t:1527614173030};\\\", \\\"{x:1557,y:484,t:1527614173047};\\\", \\\"{x:1558,y:484,t:1527614173093};\\\", \\\"{x:1559,y:484,t:1527614173133};\\\", \\\"{x:1560,y:484,t:1527614173147};\\\", \\\"{x:1565,y:485,t:1527614173164};\\\", \\\"{x:1566,y:486,t:1527614173181};\\\", \\\"{x:1568,y:487,t:1527614173198};\\\", \\\"{x:1569,y:487,t:1527614173244};\\\", \\\"{x:1569,y:488,t:1527614173252};\\\", \\\"{x:1571,y:489,t:1527614173264};\\\", \\\"{x:1572,y:489,t:1527614173282};\\\", \\\"{x:1573,y:489,t:1527614173373};\\\", \\\"{x:1573,y:490,t:1527614173381};\\\", \\\"{x:1574,y:490,t:1527614173397};\\\", \\\"{x:1575,y:490,t:1527614173429};\\\", \\\"{x:1576,y:491,t:1527614173509};\\\", \\\"{x:1576,y:492,t:1527614173518};\\\", \\\"{x:1577,y:492,t:1527614173535};\\\", \\\"{x:1578,y:492,t:1527614173548};\\\", \\\"{x:1580,y:493,t:1527614173643};\\\", \\\"{x:1581,y:493,t:1527614173668};\\\", \\\"{x:1582,y:493,t:1527614174236};\\\", \\\"{x:1581,y:493,t:1527614181949};\\\", \\\"{x:1580,y:493,t:1527614182124};\\\", \\\"{x:1580,y:492,t:1527614182732};\\\", \\\"{x:1570,y:494,t:1527614183271};\\\", \\\"{x:1559,y:497,t:1527614183276};\\\", \\\"{x:1543,y:502,t:1527614183291};\\\", \\\"{x:1525,y:505,t:1527614183307};\\\", \\\"{x:1499,y:513,t:1527614183324};\\\", \\\"{x:1484,y:516,t:1527614183340};\\\", \\\"{x:1468,y:521,t:1527614183357};\\\", \\\"{x:1450,y:530,t:1527614183374};\\\", \\\"{x:1431,y:542,t:1527614183390};\\\", \\\"{x:1411,y:558,t:1527614183407};\\\", \\\"{x:1392,y:575,t:1527614183425};\\\", \\\"{x:1375,y:593,t:1527614183441};\\\", \\\"{x:1352,y:618,t:1527614183458};\\\", \\\"{x:1331,y:638,t:1527614183474};\\\", \\\"{x:1308,y:658,t:1527614183490};\\\", \\\"{x:1288,y:675,t:1527614183507};\\\", \\\"{x:1259,y:699,t:1527614183524};\\\", \\\"{x:1247,y:709,t:1527614183541};\\\", \\\"{x:1237,y:722,t:1527614183557};\\\", \\\"{x:1227,y:734,t:1527614183574};\\\", \\\"{x:1222,y:743,t:1527614183590};\\\", \\\"{x:1219,y:746,t:1527614183607};\\\", \\\"{x:1217,y:748,t:1527614183623};\\\", \\\"{x:1215,y:750,t:1527614183641};\\\", \\\"{x:1215,y:751,t:1527614183656};\\\", \\\"{x:1213,y:759,t:1527614183673};\\\", \\\"{x:1210,y:768,t:1527614183691};\\\", \\\"{x:1208,y:776,t:1527614183706};\\\", \\\"{x:1207,y:782,t:1527614183724};\\\", \\\"{x:1205,y:784,t:1527614183741};\\\", \\\"{x:1204,y:787,t:1527614183757};\\\", \\\"{x:1202,y:793,t:1527614183774};\\\", \\\"{x:1198,y:802,t:1527614183791};\\\", \\\"{x:1197,y:809,t:1527614183807};\\\", \\\"{x:1194,y:813,t:1527614183824};\\\", \\\"{x:1194,y:815,t:1527614183841};\\\", \\\"{x:1194,y:816,t:1527614184045};\\\", \\\"{x:1195,y:816,t:1527614184057};\\\", \\\"{x:1198,y:818,t:1527614184075};\\\", \\\"{x:1201,y:819,t:1527614184092};\\\", \\\"{x:1206,y:823,t:1527614184108};\\\", \\\"{x:1209,y:824,t:1527614184125};\\\", \\\"{x:1211,y:826,t:1527614184142};\\\", \\\"{x:1213,y:827,t:1527614184159};\\\", \\\"{x:1215,y:828,t:1527614184174};\\\", \\\"{x:1217,y:829,t:1527614184191};\\\", \\\"{x:1219,y:831,t:1527614184208};\\\", \\\"{x:1221,y:832,t:1527614184225};\\\", \\\"{x:1223,y:832,t:1527614184309};\\\", \\\"{x:1226,y:827,t:1527614184324};\\\", \\\"{x:1230,y:820,t:1527614184341};\\\", \\\"{x:1235,y:809,t:1527614184359};\\\", \\\"{x:1238,y:796,t:1527614184376};\\\", \\\"{x:1239,y:786,t:1527614184391};\\\", \\\"{x:1239,y:776,t:1527614184408};\\\", \\\"{x:1239,y:770,t:1527614184426};\\\", \\\"{x:1238,y:768,t:1527614184441};\\\", \\\"{x:1237,y:766,t:1527614184459};\\\", \\\"{x:1233,y:763,t:1527614184475};\\\", \\\"{x:1224,y:760,t:1527614184492};\\\", \\\"{x:1197,y:746,t:1527614184508};\\\", \\\"{x:1178,y:736,t:1527614184525};\\\", \\\"{x:1162,y:730,t:1527614184541};\\\", \\\"{x:1151,y:725,t:1527614184559};\\\", \\\"{x:1147,y:723,t:1527614184576};\\\", \\\"{x:1145,y:722,t:1527614184592};\\\", \\\"{x:1144,y:722,t:1527614184685};\\\", \\\"{x:1143,y:727,t:1527614184692};\\\", \\\"{x:1142,y:745,t:1527614184708};\\\", \\\"{x:1142,y:764,t:1527614184726};\\\", \\\"{x:1144,y:782,t:1527614184743};\\\", \\\"{x:1152,y:800,t:1527614184758};\\\", \\\"{x:1157,y:812,t:1527614184776};\\\", \\\"{x:1163,y:820,t:1527614184793};\\\", \\\"{x:1166,y:827,t:1527614184808};\\\", \\\"{x:1168,y:831,t:1527614184825};\\\", \\\"{x:1169,y:835,t:1527614184843};\\\", \\\"{x:1169,y:836,t:1527614184859};\\\", \\\"{x:1169,y:838,t:1527614184876};\\\", \\\"{x:1171,y:841,t:1527614184893};\\\", \\\"{x:1172,y:845,t:1527614184908};\\\", \\\"{x:1174,y:848,t:1527614184926};\\\", \\\"{x:1175,y:850,t:1527614184943};\\\", \\\"{x:1179,y:853,t:1527614184958};\\\", \\\"{x:1183,y:856,t:1527614184976};\\\", \\\"{x:1190,y:860,t:1527614184993};\\\", \\\"{x:1195,y:862,t:1527614185008};\\\", \\\"{x:1202,y:863,t:1527614185026};\\\", \\\"{x:1206,y:864,t:1527614185043};\\\", \\\"{x:1210,y:864,t:1527614185060};\\\", \\\"{x:1213,y:862,t:1527614185076};\\\", \\\"{x:1217,y:854,t:1527614185092};\\\", \\\"{x:1219,y:851,t:1527614185109};\\\", \\\"{x:1220,y:847,t:1527614185125};\\\", \\\"{x:1222,y:844,t:1527614185143};\\\", \\\"{x:1224,y:841,t:1527614185160};\\\", \\\"{x:1226,y:837,t:1527614185176};\\\", \\\"{x:1228,y:832,t:1527614185192};\\\", \\\"{x:1229,y:828,t:1527614185209};\\\", \\\"{x:1230,y:821,t:1527614185225};\\\", \\\"{x:1230,y:814,t:1527614185242};\\\", \\\"{x:1229,y:810,t:1527614185260};\\\", \\\"{x:1228,y:802,t:1527614185275};\\\", \\\"{x:1223,y:788,t:1527614185293};\\\", \\\"{x:1220,y:782,t:1527614185310};\\\", \\\"{x:1218,y:776,t:1527614185325};\\\", \\\"{x:1215,y:771,t:1527614185343};\\\", \\\"{x:1212,y:767,t:1527614185360};\\\", \\\"{x:1209,y:763,t:1527614185376};\\\", \\\"{x:1205,y:758,t:1527614185392};\\\", \\\"{x:1203,y:755,t:1527614185409};\\\", \\\"{x:1200,y:753,t:1527614185426};\\\", \\\"{x:1197,y:751,t:1527614185442};\\\", \\\"{x:1189,y:748,t:1527614185459};\\\", \\\"{x:1182,y:748,t:1527614185475};\\\", \\\"{x:1171,y:745,t:1527614185492};\\\", \\\"{x:1159,y:744,t:1527614185509};\\\", \\\"{x:1150,y:743,t:1527614185526};\\\", \\\"{x:1145,y:742,t:1527614185542};\\\", \\\"{x:1141,y:742,t:1527614185559};\\\", \\\"{x:1139,y:742,t:1527614185576};\\\", \\\"{x:1136,y:742,t:1527614185593};\\\", \\\"{x:1131,y:749,t:1527614185609};\\\", \\\"{x:1129,y:755,t:1527614185626};\\\", \\\"{x:1129,y:763,t:1527614185642};\\\", \\\"{x:1129,y:770,t:1527614185659};\\\", \\\"{x:1129,y:781,t:1527614185676};\\\", \\\"{x:1131,y:787,t:1527614185692};\\\", \\\"{x:1133,y:794,t:1527614185710};\\\", \\\"{x:1135,y:797,t:1527614185727};\\\", \\\"{x:1138,y:801,t:1527614185744};\\\", \\\"{x:1139,y:803,t:1527614185760};\\\", \\\"{x:1140,y:805,t:1527614185777};\\\", \\\"{x:1141,y:808,t:1527614185793};\\\", \\\"{x:1142,y:811,t:1527614185809};\\\", \\\"{x:1146,y:816,t:1527614185826};\\\", \\\"{x:1149,y:820,t:1527614185843};\\\", \\\"{x:1151,y:823,t:1527614185860};\\\", \\\"{x:1157,y:829,t:1527614185877};\\\", \\\"{x:1163,y:834,t:1527614185894};\\\", \\\"{x:1171,y:839,t:1527614185909};\\\", \\\"{x:1182,y:845,t:1527614185927};\\\", \\\"{x:1193,y:849,t:1527614185944};\\\", \\\"{x:1205,y:852,t:1527614185959};\\\", \\\"{x:1213,y:853,t:1527614185977};\\\", \\\"{x:1217,y:855,t:1527614185994};\\\", \\\"{x:1221,y:853,t:1527614186053};\\\", \\\"{x:1223,y:851,t:1527614186060};\\\", \\\"{x:1228,y:845,t:1527614186077};\\\", \\\"{x:1230,y:842,t:1527614186094};\\\", \\\"{x:1232,y:841,t:1527614186110};\\\", \\\"{x:1233,y:841,t:1527614186126};\\\", \\\"{x:1233,y:839,t:1527614186144};\\\", \\\"{x:1233,y:836,t:1527614186160};\\\", \\\"{x:1233,y:834,t:1527614186176};\\\", \\\"{x:1233,y:831,t:1527614186194};\\\", \\\"{x:1233,y:827,t:1527614186210};\\\", \\\"{x:1233,y:824,t:1527614186227};\\\", \\\"{x:1233,y:819,t:1527614186243};\\\", \\\"{x:1233,y:814,t:1527614186259};\\\", \\\"{x:1233,y:809,t:1527614186276};\\\", \\\"{x:1231,y:797,t:1527614186293};\\\", \\\"{x:1227,y:784,t:1527614186310};\\\", \\\"{x:1224,y:777,t:1527614186326};\\\", \\\"{x:1220,y:772,t:1527614186343};\\\", \\\"{x:1217,y:770,t:1527614186360};\\\", \\\"{x:1216,y:768,t:1527614186376};\\\", \\\"{x:1215,y:766,t:1527614186394};\\\", \\\"{x:1213,y:762,t:1527614186410};\\\", \\\"{x:1210,y:759,t:1527614186426};\\\", \\\"{x:1206,y:754,t:1527614186444};\\\", \\\"{x:1203,y:753,t:1527614186460};\\\", \\\"{x:1202,y:752,t:1527614186477};\\\", \\\"{x:1201,y:752,t:1527614186494};\\\", \\\"{x:1200,y:751,t:1527614186510};\\\", \\\"{x:1198,y:750,t:1527614186527};\\\", \\\"{x:1194,y:749,t:1527614186543};\\\", \\\"{x:1189,y:748,t:1527614186560};\\\", \\\"{x:1182,y:748,t:1527614186577};\\\", \\\"{x:1175,y:748,t:1527614186593};\\\", \\\"{x:1170,y:748,t:1527614186610};\\\", \\\"{x:1166,y:748,t:1527614186627};\\\", \\\"{x:1163,y:749,t:1527614186643};\\\", \\\"{x:1159,y:750,t:1527614186660};\\\", \\\"{x:1156,y:753,t:1527614186678};\\\", \\\"{x:1153,y:756,t:1527614186693};\\\", \\\"{x:1152,y:757,t:1527614186711};\\\", \\\"{x:1152,y:759,t:1527614186727};\\\", \\\"{x:1150,y:765,t:1527614186744};\\\", \\\"{x:1150,y:770,t:1527614186761};\\\", \\\"{x:1150,y:779,t:1527614186777};\\\", \\\"{x:1150,y:789,t:1527614186793};\\\", \\\"{x:1151,y:797,t:1527614186810};\\\", \\\"{x:1156,y:806,t:1527614186827};\\\", \\\"{x:1161,y:813,t:1527614186844};\\\", \\\"{x:1164,y:818,t:1527614186860};\\\", \\\"{x:1168,y:823,t:1527614186878};\\\", \\\"{x:1172,y:827,t:1527614186894};\\\", \\\"{x:1175,y:830,t:1527614186911};\\\", \\\"{x:1177,y:832,t:1527614186928};\\\", \\\"{x:1179,y:833,t:1527614186944};\\\", \\\"{x:1181,y:835,t:1527614186961};\\\", \\\"{x:1183,y:836,t:1527614186978};\\\", \\\"{x:1186,y:836,t:1527614186995};\\\", \\\"{x:1188,y:837,t:1527614187011};\\\", \\\"{x:1192,y:839,t:1527614187028};\\\", \\\"{x:1193,y:839,t:1527614187140};\\\", \\\"{x:1194,y:840,t:1527614187156};\\\", \\\"{x:1196,y:840,t:1527614187164};\\\", \\\"{x:1199,y:840,t:1527614187178};\\\", \\\"{x:1201,y:841,t:1527614187194};\\\", \\\"{x:1206,y:843,t:1527614187212};\\\", \\\"{x:1207,y:843,t:1527614187236};\\\", \\\"{x:1208,y:843,t:1527614187244};\\\", \\\"{x:1209,y:843,t:1527614187262};\\\", \\\"{x:1210,y:843,t:1527614187277};\\\", \\\"{x:1212,y:843,t:1527614187295};\\\", \\\"{x:1213,y:843,t:1527614187325};\\\", \\\"{x:1215,y:843,t:1527614187356};\\\", \\\"{x:1217,y:843,t:1527614187380};\\\", \\\"{x:1218,y:843,t:1527614187396};\\\", \\\"{x:1219,y:843,t:1527614187420};\\\", \\\"{x:1220,y:843,t:1527614187444};\\\", \\\"{x:1221,y:843,t:1527614187461};\\\", \\\"{x:1221,y:842,t:1527614190516};\\\", \\\"{x:1221,y:841,t:1527614191148};\\\", \\\"{x:1221,y:840,t:1527614191165};\\\", \\\"{x:1221,y:839,t:1527614191181};\\\", \\\"{x:1221,y:837,t:1527614191199};\\\", \\\"{x:1221,y:827,t:1527614191214};\\\", \\\"{x:1228,y:812,t:1527614191232};\\\", \\\"{x:1235,y:796,t:1527614191249};\\\", \\\"{x:1241,y:774,t:1527614191265};\\\", \\\"{x:1246,y:747,t:1527614191281};\\\", \\\"{x:1249,y:719,t:1527614191299};\\\", \\\"{x:1253,y:694,t:1527614191315};\\\", \\\"{x:1258,y:672,t:1527614191332};\\\", \\\"{x:1260,y:662,t:1527614191348};\\\", \\\"{x:1262,y:654,t:1527614191365};\\\", \\\"{x:1262,y:650,t:1527614191381};\\\", \\\"{x:1262,y:643,t:1527614191398};\\\", \\\"{x:1264,y:639,t:1527614191416};\\\", \\\"{x:1265,y:634,t:1527614191431};\\\", \\\"{x:1266,y:624,t:1527614191448};\\\", \\\"{x:1267,y:617,t:1527614191465};\\\", \\\"{x:1269,y:609,t:1527614191481};\\\", \\\"{x:1270,y:606,t:1527614191498};\\\", \\\"{x:1271,y:604,t:1527614191515};\\\", \\\"{x:1273,y:602,t:1527614191531};\\\", \\\"{x:1275,y:598,t:1527614191548};\\\", \\\"{x:1280,y:593,t:1527614191565};\\\", \\\"{x:1284,y:588,t:1527614191581};\\\", \\\"{x:1286,y:583,t:1527614191599};\\\", \\\"{x:1288,y:577,t:1527614191616};\\\", \\\"{x:1290,y:573,t:1527614191631};\\\", \\\"{x:1291,y:570,t:1527614191648};\\\", \\\"{x:1292,y:568,t:1527614191665};\\\", \\\"{x:1292,y:563,t:1527614191681};\\\", \\\"{x:1293,y:561,t:1527614191698};\\\", \\\"{x:1295,y:557,t:1527614191716};\\\", \\\"{x:1295,y:554,t:1527614191731};\\\", \\\"{x:1295,y:553,t:1527614191756};\\\", \\\"{x:1296,y:552,t:1527614191772};\\\", \\\"{x:1294,y:552,t:1527614192860};\\\", \\\"{x:1289,y:552,t:1527614192867};\\\", \\\"{x:1284,y:552,t:1527614192883};\\\", \\\"{x:1279,y:553,t:1527614192900};\\\", \\\"{x:1275,y:554,t:1527614192917};\\\", \\\"{x:1271,y:555,t:1527614192933};\\\", \\\"{x:1269,y:555,t:1527614192950};\\\", \\\"{x:1267,y:555,t:1527614192967};\\\", \\\"{x:1267,y:556,t:1527614193468};\\\", \\\"{x:1267,y:559,t:1527614193483};\\\", \\\"{x:1269,y:564,t:1527614193501};\\\", \\\"{x:1272,y:568,t:1527614193518};\\\", \\\"{x:1274,y:570,t:1527614193534};\\\", \\\"{x:1271,y:570,t:1527614193668};\\\", \\\"{x:1257,y:577,t:1527614193684};\\\", \\\"{x:1232,y:585,t:1527614193701};\\\", \\\"{x:1186,y:592,t:1527614193717};\\\", \\\"{x:1080,y:596,t:1527614193734};\\\", \\\"{x:941,y:598,t:1527614193751};\\\", \\\"{x:767,y:598,t:1527614193768};\\\", \\\"{x:612,y:598,t:1527614193784};\\\", \\\"{x:479,y:598,t:1527614193801};\\\", \\\"{x:402,y:598,t:1527614193818};\\\", \\\"{x:370,y:598,t:1527614193834};\\\", \\\"{x:359,y:598,t:1527614193851};\\\", \\\"{x:362,y:599,t:1527614193924};\\\", \\\"{x:364,y:600,t:1527614193934};\\\", \\\"{x:369,y:600,t:1527614193950};\\\", \\\"{x:383,y:601,t:1527614193969};\\\", \\\"{x:407,y:597,t:1527614193985};\\\", \\\"{x:444,y:584,t:1527614194000};\\\", \\\"{x:535,y:567,t:1527614194029};\\\", \\\"{x:547,y:565,t:1527614194045};\\\", \\\"{x:549,y:565,t:1527614194062};\\\", \\\"{x:551,y:565,t:1527614194123};\\\", \\\"{x:552,y:564,t:1527614194131};\\\", \\\"{x:556,y:561,t:1527614194146};\\\", \\\"{x:565,y:556,t:1527614194162};\\\", \\\"{x:577,y:545,t:1527614194179};\\\", \\\"{x:605,y:522,t:1527614194195};\\\", \\\"{x:613,y:516,t:1527614194213};\\\", \\\"{x:614,y:514,t:1527614194229};\\\", \\\"{x:615,y:514,t:1527614194245};\\\", \\\"{x:615,y:512,t:1527614194276};\\\", \\\"{x:615,y:511,t:1527614194295};\\\", \\\"{x:616,y:509,t:1527614194313};\\\", \\\"{x:616,y:508,t:1527614194347};\\\", \\\"{x:616,y:506,t:1527614194380};\\\", \\\"{x:618,y:504,t:1527614194396};\\\", \\\"{x:618,y:501,t:1527614194414};\\\", \\\"{x:619,y:498,t:1527614194429};\\\", \\\"{x:619,y:505,t:1527614194779};\\\", \\\"{x:619,y:542,t:1527614194797};\\\", \\\"{x:623,y:605,t:1527614194814};\\\", \\\"{x:641,y:677,t:1527614194830};\\\", \\\"{x:657,y:728,t:1527614194847};\\\", \\\"{x:665,y:756,t:1527614194862};\\\", \\\"{x:670,y:771,t:1527614194879};\\\", \\\"{x:672,y:779,t:1527614194896};\\\", \\\"{x:673,y:784,t:1527614194914};\\\", \\\"{x:673,y:791,t:1527614194929};\\\", \\\"{x:673,y:799,t:1527614194946};\\\", \\\"{x:671,y:806,t:1527614194963};\\\", \\\"{x:669,y:815,t:1527614194979};\\\", \\\"{x:665,y:821,t:1527614194997};\\\", \\\"{x:660,y:826,t:1527614195013};\\\", \\\"{x:657,y:829,t:1527614195030};\\\", \\\"{x:655,y:830,t:1527614195047};\\\", \\\"{x:653,y:830,t:1527614195063};\\\", \\\"{x:649,y:832,t:1527614195080};\\\", \\\"{x:642,y:832,t:1527614195096};\\\", \\\"{x:627,y:832,t:1527614195114};\\\", \\\"{x:605,y:827,t:1527614195130};\\\", \\\"{x:580,y:820,t:1527614195147};\\\", \\\"{x:553,y:808,t:1527614195164};\\\", \\\"{x:543,y:804,t:1527614195179};\\\", \\\"{x:539,y:801,t:1527614195197};\\\", \\\"{x:538,y:798,t:1527614195213};\\\", \\\"{x:536,y:795,t:1527614195230};\\\", \\\"{x:536,y:791,t:1527614195247};\\\", \\\"{x:536,y:785,t:1527614195264};\\\", \\\"{x:536,y:778,t:1527614195279};\\\", \\\"{x:536,y:771,t:1527614195296};\\\", \\\"{x:536,y:766,t:1527614195314};\\\", \\\"{x:536,y:763,t:1527614195330};\\\", \\\"{x:536,y:761,t:1527614195346};\\\", \\\"{x:537,y:758,t:1527614195363};\\\", \\\"{x:537,y:757,t:1527614195381};\\\", \\\"{x:539,y:753,t:1527614195398};\\\", \\\"{x:540,y:752,t:1527614195414};\\\", \\\"{x:541,y:749,t:1527614195429};\\\", \\\"{x:542,y:747,t:1527614195446};\\\", \\\"{x:543,y:745,t:1527614195463};\\\", \\\"{x:543,y:744,t:1527614195483};\\\", \\\"{x:544,y:743,t:1527614195496};\\\", \\\"{x:545,y:740,t:1527614195513};\\\", \\\"{x:547,y:737,t:1527614195530};\\\", \\\"{x:550,y:734,t:1527614195546};\\\", \\\"{x:550,y:731,t:1527614195563};\\\" ] }, { \\\"rt\\\": 62687, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 13, \\\"time_elapsed\\\": 592223, \\\"internal_node_id\\\": \\\"0.0-6.0-3.0\\\", \\\"subject\\\": \\\"TGOML\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"oscar\\\", \\\"condition\\\": \\\"114\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"starttime+before+endtime+during\\\", \\\"q\\\": 9, \\\"clicks\\\": 2, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XInside-YInside\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 0, \\\"answer\\\": [], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-I -I -E -B -I -I -B -B -B -B -B \\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:550,y:730,t:1527614197540};\\\", \\\"{x:551,y:730,t:1527614205092};\\\", \\\"{x:556,y:730,t:1527614205099};\\\", \\\"{x:559,y:729,t:1527614205112};\\\", \\\"{x:561,y:728,t:1527614205129};\\\", \\\"{x:562,y:727,t:1527614205146};\\\", \\\"{x:563,y:727,t:1527614205162};\\\", \\\"{x:566,y:727,t:1527614205181};\\\", \\\"{x:569,y:726,t:1527614205196};\\\", \\\"{x:578,y:725,t:1527614205211};\\\", \\\"{x:591,y:725,t:1527614205233};\\\", \\\"{x:617,y:728,t:1527614205249};\\\", \\\"{x:637,y:730,t:1527614205266};\\\", \\\"{x:659,y:735,t:1527614205282};\\\", \\\"{x:673,y:737,t:1527614205299};\\\", \\\"{x:695,y:737,t:1527614205316};\\\", \\\"{x:719,y:737,t:1527614205332};\\\", \\\"{x:734,y:737,t:1527614205348};\\\", \\\"{x:747,y:737,t:1527614205365};\\\", \\\"{x:760,y:737,t:1527614205382};\\\", \\\"{x:777,y:737,t:1527614205398};\\\", \\\"{x:796,y:737,t:1527614205416};\\\", \\\"{x:815,y:736,t:1527614205432};\\\", \\\"{x:836,y:735,t:1527614205448};\\\", \\\"{x:855,y:735,t:1527614205465};\\\", \\\"{x:886,y:735,t:1527614205483};\\\", \\\"{x:912,y:735,t:1527614205499};\\\", \\\"{x:954,y:735,t:1527614205515};\\\", \\\"{x:1004,y:738,t:1527614205533};\\\", \\\"{x:1049,y:740,t:1527614205549};\\\", \\\"{x:1091,y:740,t:1527614205566};\\\", \\\"{x:1122,y:741,t:1527614205582};\\\", \\\"{x:1146,y:742,t:1527614205599};\\\", \\\"{x:1158,y:742,t:1527614205616};\\\", \\\"{x:1161,y:742,t:1527614205633};\\\", \\\"{x:1161,y:743,t:1527614205650};\\\", \\\"{x:1162,y:743,t:1527614205692};\\\", \\\"{x:1164,y:743,t:1527614205708};\\\", \\\"{x:1166,y:743,t:1527614205724};\\\", \\\"{x:1167,y:743,t:1527614205733};\\\", \\\"{x:1168,y:743,t:1527614205749};\\\", \\\"{x:1171,y:743,t:1527614205766};\\\", \\\"{x:1175,y:748,t:1527614205783};\\\", \\\"{x:1181,y:756,t:1527614205799};\\\", \\\"{x:1186,y:763,t:1527614205819};\\\", \\\"{x:1189,y:767,t:1527614205833};\\\", \\\"{x:1189,y:768,t:1527614205849};\\\", \\\"{x:1189,y:769,t:1527614205876};\\\", \\\"{x:1189,y:770,t:1527614205916};\\\", \\\"{x:1189,y:771,t:1527614205933};\\\", \\\"{x:1187,y:772,t:1527614205972};\\\", \\\"{x:1186,y:772,t:1527614205996};\\\", \\\"{x:1185,y:773,t:1527614206004};\\\", \\\"{x:1184,y:773,t:1527614206076};\\\", \\\"{x:1183,y:773,t:1527614206116};\\\", \\\"{x:1182,y:773,t:1527614206147};\\\", \\\"{x:1182,y:772,t:1527614206340};\\\", \\\"{x:1182,y:771,t:1527614206349};\\\", \\\"{x:1182,y:769,t:1527614206366};\\\", \\\"{x:1182,y:768,t:1527614206384};\\\", \\\"{x:1182,y:767,t:1527614206399};\\\", \\\"{x:1181,y:766,t:1527614221791};\\\", \\\"{x:1172,y:766,t:1527614222000};\\\", \\\"{x:1145,y:766,t:1527614222006};\\\", \\\"{x:1114,y:766,t:1527614222021};\\\", \\\"{x:1052,y:756,t:1527614222037};\\\", \\\"{x:957,y:746,t:1527614222055};\\\", \\\"{x:894,y:740,t:1527614222071};\\\", \\\"{x:838,y:732,t:1527614222087};\\\", \\\"{x:798,y:725,t:1527614222104};\\\", \\\"{x:776,y:723,t:1527614222121};\\\", \\\"{x:762,y:718,t:1527614222137};\\\", \\\"{x:752,y:715,t:1527614222154};\\\", \\\"{x:743,y:711,t:1527614222171};\\\", \\\"{x:734,y:709,t:1527614222187};\\\", \\\"{x:725,y:707,t:1527614222204};\\\", \\\"{x:718,y:702,t:1527614222221};\\\", \\\"{x:708,y:699,t:1527614222237};\\\", \\\"{x:690,y:690,t:1527614222254};\\\", \\\"{x:677,y:685,t:1527614222270};\\\", \\\"{x:657,y:676,t:1527614222287};\\\", \\\"{x:643,y:670,t:1527614222304};\\\", \\\"{x:639,y:667,t:1527614222321};\\\", \\\"{x:633,y:660,t:1527614222337};\\\", \\\"{x:625,y:647,t:1527614222354};\\\", \\\"{x:619,y:624,t:1527614222373};\\\", \\\"{x:606,y:599,t:1527614222387};\\\", \\\"{x:596,y:577,t:1527614222404};\\\", \\\"{x:541,y:504,t:1527614222422};\\\", \\\"{x:499,y:464,t:1527614222439};\\\", \\\"{x:490,y:456,t:1527614222456};\\\", \\\"{x:487,y:454,t:1527614222472};\\\", \\\"{x:486,y:453,t:1527614222488};\\\", \\\"{x:485,y:452,t:1527614222506};\\\", \\\"{x:484,y:450,t:1527614222523};\\\", \\\"{x:483,y:450,t:1527614222540};\\\", \\\"{x:483,y:449,t:1527614222606};\\\", \\\"{x:482,y:449,t:1527614222638};\\\", \\\"{x:481,y:449,t:1527614222646};\\\", \\\"{x:480,y:449,t:1527614222657};\\\", \\\"{x:480,y:460,t:1527614222673};\\\", \\\"{x:480,y:479,t:1527614222690};\\\", \\\"{x:480,y:497,t:1527614222708};\\\", \\\"{x:479,y:512,t:1527614222723};\\\", \\\"{x:479,y:521,t:1527614222740};\\\", \\\"{x:479,y:526,t:1527614222756};\\\", \\\"{x:479,y:530,t:1527614222773};\\\", \\\"{x:477,y:538,t:1527614222789};\\\", \\\"{x:471,y:546,t:1527614222805};\\\", \\\"{x:466,y:549,t:1527614222822};\\\", \\\"{x:461,y:550,t:1527614222840};\\\", \\\"{x:451,y:551,t:1527614222856};\\\", \\\"{x:433,y:554,t:1527614222873};\\\", \\\"{x:406,y:556,t:1527614222889};\\\", \\\"{x:372,y:556,t:1527614222906};\\\", \\\"{x:336,y:556,t:1527614222923};\\\", \\\"{x:307,y:555,t:1527614222940};\\\", \\\"{x:288,y:548,t:1527614222955};\\\", \\\"{x:280,y:544,t:1527614222973};\\\", \\\"{x:279,y:543,t:1527614222990};\\\", \\\"{x:279,y:540,t:1527614223014};\\\", \\\"{x:283,y:536,t:1527614223023};\\\", \\\"{x:297,y:525,t:1527614223040};\\\", \\\"{x:307,y:517,t:1527614223058};\\\", \\\"{x:315,y:511,t:1527614223073};\\\", \\\"{x:319,y:508,t:1527614223090};\\\", \\\"{x:320,y:507,t:1527614223106};\\\", \\\"{x:320,y:506,t:1527614223123};\\\", \\\"{x:321,y:504,t:1527614223140};\\\", \\\"{x:322,y:504,t:1527614223156};\\\", \\\"{x:321,y:500,t:1527614223173};\\\", \\\"{x:300,y:495,t:1527614223190};\\\", \\\"{x:288,y:495,t:1527614223206};\\\", \\\"{x:247,y:495,t:1527614223225};\\\", \\\"{x:222,y:495,t:1527614223239};\\\", \\\"{x:196,y:495,t:1527614223256};\\\", \\\"{x:180,y:495,t:1527614223273};\\\", \\\"{x:170,y:495,t:1527614223290};\\\", \\\"{x:167,y:495,t:1527614223306};\\\", \\\"{x:166,y:495,t:1527614224159};\\\", \\\"{x:165,y:494,t:1527614224455};\\\", \\\"{x:163,y:492,t:1527614225047};\\\", \\\"{x:163,y:491,t:1527614225062};\\\", \\\"{x:163,y:490,t:1527614225074};\\\", \\\"{x:162,y:488,t:1527614225092};\\\", \\\"{x:162,y:487,t:1527614225108};\\\", \\\"{x:162,y:486,t:1527614225124};\\\", \\\"{x:161,y:485,t:1527614225142};\\\", \\\"{x:161,y:484,t:1527614225158};\\\", \\\"{x:161,y:483,t:1527614225174};\\\", \\\"{x:161,y:482,t:1527614225238};\\\", \\\"{x:161,y:481,t:1527614225254};\\\", \\\"{x:161,y:480,t:1527614225270};\\\", \\\"{x:161,y:479,t:1527614225286};\\\", \\\"{x:161,y:478,t:1527614225302};\\\", \\\"{x:161,y:477,t:1527614225318};\\\", \\\"{x:161,y:480,t:1527614226303};\\\", \\\"{x:160,y:485,t:1527614226311};\\\", \\\"{x:160,y:488,t:1527614226326};\\\", \\\"{x:160,y:493,t:1527614226343};\\\", \\\"{x:160,y:494,t:1527614226422};\\\", \\\"{x:160,y:491,t:1527614226639};\\\", \\\"{x:159,y:488,t:1527614226647};\\\", \\\"{x:159,y:486,t:1527614226659};\\\", \\\"{x:158,y:485,t:1527614226675};\\\", \\\"{x:157,y:483,t:1527614226692};\\\", \\\"{x:159,y:484,t:1527614226911};\\\", \\\"{x:160,y:486,t:1527614226925};\\\", \\\"{x:163,y:490,t:1527614226943};\\\", \\\"{x:164,y:492,t:1527614226959};\\\", \\\"{x:164,y:494,t:1527614226976};\\\", \\\"{x:165,y:495,t:1527614227276};\\\", \\\"{x:171,y:494,t:1527614227293};\\\", \\\"{x:182,y:488,t:1527614227310};\\\", \\\"{x:197,y:481,t:1527614227326};\\\", \\\"{x:216,y:470,t:1527614227342};\\\", \\\"{x:238,y:461,t:1527614227360};\\\", \\\"{x:260,y:446,t:1527614227376};\\\", \\\"{x:274,y:438,t:1527614227393};\\\", \\\"{x:283,y:431,t:1527614227410};\\\", \\\"{x:287,y:427,t:1527614227425};\\\", \\\"{x:289,y:425,t:1527614227443};\\\", \\\"{x:290,y:424,t:1527614227460};\\\", \\\"{x:290,y:422,t:1527614227476};\\\", \\\"{x:290,y:421,t:1527614227493};\\\", \\\"{x:290,y:420,t:1527614227910};\\\", \\\"{x:288,y:412,t:1527614227927};\\\", \\\"{x:287,y:406,t:1527614227944};\\\", \\\"{x:285,y:400,t:1527614227960};\\\", \\\"{x:284,y:397,t:1527614227977};\\\", \\\"{x:284,y:396,t:1527614228503};\\\", \\\"{x:286,y:397,t:1527614228918};\\\", \\\"{x:294,y:401,t:1527614228927};\\\", \\\"{x:312,y:410,t:1527614228944};\\\", \\\"{x:379,y:428,t:1527614228961};\\\", \\\"{x:496,y:449,t:1527614228978};\\\", \\\"{x:630,y:474,t:1527614228994};\\\", \\\"{x:773,y:491,t:1527614229012};\\\", \\\"{x:923,y:513,t:1527614229027};\\\", \\\"{x:1045,y:532,t:1527614229044};\\\", \\\"{x:1156,y:550,t:1527614229061};\\\", \\\"{x:1283,y:566,t:1527614229077};\\\", \\\"{x:1329,y:570,t:1527614229094};\\\", \\\"{x:1348,y:573,t:1527614229111};\\\", \\\"{x:1356,y:574,t:1527614229128};\\\", \\\"{x:1360,y:574,t:1527614229144};\\\", \\\"{x:1363,y:576,t:1527614229161};\\\", \\\"{x:1367,y:578,t:1527614229177};\\\", \\\"{x:1373,y:581,t:1527614229194};\\\", \\\"{x:1379,y:584,t:1527614229211};\\\", \\\"{x:1385,y:592,t:1527614229228};\\\", \\\"{x:1395,y:608,t:1527614229244};\\\", \\\"{x:1405,y:629,t:1527614229261};\\\", \\\"{x:1412,y:663,t:1527614229278};\\\", \\\"{x:1412,y:678,t:1527614229295};\\\", \\\"{x:1406,y:697,t:1527614229311};\\\", \\\"{x:1389,y:716,t:1527614229328};\\\", \\\"{x:1368,y:728,t:1527614229345};\\\", \\\"{x:1331,y:742,t:1527614229361};\\\", \\\"{x:1299,y:748,t:1527614229379};\\\", \\\"{x:1260,y:755,t:1527614229395};\\\", \\\"{x:1228,y:760,t:1527614229411};\\\", \\\"{x:1204,y:766,t:1527614229428};\\\", \\\"{x:1183,y:772,t:1527614229445};\\\", \\\"{x:1169,y:776,t:1527614229461};\\\", \\\"{x:1161,y:778,t:1527614229478};\\\", \\\"{x:1157,y:778,t:1527614229495};\\\", \\\"{x:1154,y:779,t:1527614229511};\\\", \\\"{x:1150,y:779,t:1527614229528};\\\", \\\"{x:1145,y:779,t:1527614229545};\\\", \\\"{x:1138,y:780,t:1527614229561};\\\", \\\"{x:1133,y:781,t:1527614229578};\\\", \\\"{x:1128,y:782,t:1527614229595};\\\", \\\"{x:1122,y:783,t:1527614229611};\\\", \\\"{x:1116,y:783,t:1527614229628};\\\", \\\"{x:1110,y:784,t:1527614229646};\\\", \\\"{x:1107,y:786,t:1527614229661};\\\", \\\"{x:1106,y:786,t:1527614229694};\\\", \\\"{x:1107,y:784,t:1527614229783};\\\", \\\"{x:1110,y:783,t:1527614229796};\\\", \\\"{x:1115,y:779,t:1527614229813};\\\", \\\"{x:1122,y:776,t:1527614229829};\\\", \\\"{x:1126,y:772,t:1527614229845};\\\", \\\"{x:1134,y:768,t:1527614229862};\\\", \\\"{x:1142,y:764,t:1527614229878};\\\", \\\"{x:1147,y:762,t:1527614229895};\\\", \\\"{x:1152,y:759,t:1527614229912};\\\", \\\"{x:1157,y:755,t:1527614229928};\\\", \\\"{x:1163,y:752,t:1527614229945};\\\", \\\"{x:1166,y:750,t:1527614229962};\\\", \\\"{x:1169,y:747,t:1527614229978};\\\", \\\"{x:1170,y:746,t:1527614229996};\\\", \\\"{x:1171,y:746,t:1527614230031};\\\", \\\"{x:1173,y:747,t:1527614230446};\\\", \\\"{x:1173,y:752,t:1527614230462};\\\", \\\"{x:1173,y:755,t:1527614230479};\\\", \\\"{x:1173,y:756,t:1527614230495};\\\", \\\"{x:1173,y:758,t:1527614230512};\\\", \\\"{x:1173,y:759,t:1527614230529};\\\", \\\"{x:1174,y:760,t:1527614230544};\\\", \\\"{x:1174,y:761,t:1527614230562};\\\", \\\"{x:1174,y:762,t:1527614230579};\\\", \\\"{x:1174,y:764,t:1527614230595};\\\", \\\"{x:1174,y:767,t:1527614230612};\\\", \\\"{x:1174,y:770,t:1527614230629};\\\", \\\"{x:1176,y:781,t:1527614230646};\\\", \\\"{x:1178,y:795,t:1527614230662};\\\", \\\"{x:1180,y:816,t:1527614230679};\\\", \\\"{x:1185,y:836,t:1527614230696};\\\", \\\"{x:1186,y:854,t:1527614230712};\\\", \\\"{x:1189,y:866,t:1527614230729};\\\", \\\"{x:1189,y:877,t:1527614230746};\\\", \\\"{x:1189,y:885,t:1527614230762};\\\", \\\"{x:1189,y:896,t:1527614230779};\\\", \\\"{x:1189,y:911,t:1527614230796};\\\", \\\"{x:1189,y:925,t:1527614230813};\\\", \\\"{x:1188,y:932,t:1527614230830};\\\", \\\"{x:1188,y:933,t:1527614230846};\\\", \\\"{x:1188,y:936,t:1527614230935};\\\", \\\"{x:1188,y:937,t:1527614230947};\\\", \\\"{x:1187,y:941,t:1527614230962};\\\", \\\"{x:1184,y:945,t:1527614230979};\\\", \\\"{x:1180,y:948,t:1527614230997};\\\", \\\"{x:1177,y:950,t:1527614231013};\\\", \\\"{x:1176,y:953,t:1527614231028};\\\", \\\"{x:1176,y:954,t:1527614231046};\\\", \\\"{x:1176,y:955,t:1527614231063};\\\", \\\"{x:1176,y:956,t:1527614231078};\\\", \\\"{x:1176,y:957,t:1527614231095};\\\", \\\"{x:1176,y:958,t:1527614231117};\\\", \\\"{x:1176,y:959,t:1527614231142};\\\", \\\"{x:1176,y:960,t:1527614231150};\\\", \\\"{x:1176,y:961,t:1527614231182};\\\", \\\"{x:1177,y:961,t:1527614235485};\\\", \\\"{x:1187,y:958,t:1527614235499};\\\", \\\"{x:1217,y:938,t:1527614235516};\\\", \\\"{x:1247,y:918,t:1527614235533};\\\", \\\"{x:1275,y:901,t:1527614235549};\\\", \\\"{x:1308,y:881,t:1527614235566};\\\", \\\"{x:1326,y:872,t:1527614235583};\\\", \\\"{x:1341,y:865,t:1527614235599};\\\", \\\"{x:1356,y:856,t:1527614235616};\\\", \\\"{x:1366,y:851,t:1527614235633};\\\", \\\"{x:1372,y:846,t:1527614235649};\\\", \\\"{x:1374,y:844,t:1527614235666};\\\", \\\"{x:1375,y:844,t:1527614235702};\\\", \\\"{x:1375,y:843,t:1527614235716};\\\", \\\"{x:1376,y:842,t:1527614235742};\\\", \\\"{x:1376,y:841,t:1527614235758};\\\", \\\"{x:1377,y:838,t:1527614235766};\\\", \\\"{x:1377,y:836,t:1527614235783};\\\", \\\"{x:1376,y:831,t:1527614235800};\\\", \\\"{x:1373,y:827,t:1527614235816};\\\", \\\"{x:1371,y:823,t:1527614235833};\\\", \\\"{x:1368,y:813,t:1527614235850};\\\", \\\"{x:1366,y:808,t:1527614235866};\\\", \\\"{x:1365,y:802,t:1527614235883};\\\", \\\"{x:1363,y:797,t:1527614235900};\\\", \\\"{x:1359,y:789,t:1527614235916};\\\", \\\"{x:1358,y:782,t:1527614235933};\\\", \\\"{x:1354,y:774,t:1527614235949};\\\", \\\"{x:1354,y:772,t:1527614235966};\\\", \\\"{x:1354,y:771,t:1527614235983};\\\", \\\"{x:1354,y:770,t:1527614236001};\\\", \\\"{x:1354,y:769,t:1527614236017};\\\", \\\"{x:1354,y:768,t:1527614236037};\\\", \\\"{x:1354,y:767,t:1527614236054};\\\", \\\"{x:1354,y:766,t:1527614236066};\\\", \\\"{x:1354,y:765,t:1527614236094};\\\", \\\"{x:1354,y:764,t:1527614236118};\\\", \\\"{x:1354,y:763,t:1527614236166};\\\", \\\"{x:1354,y:762,t:1527614236726};\\\", \\\"{x:1353,y:762,t:1527614241117};\\\", \\\"{x:1329,y:768,t:1527614241138};\\\", \\\"{x:1299,y:776,t:1527614241154};\\\", \\\"{x:1267,y:780,t:1527614241170};\\\", \\\"{x:1241,y:782,t:1527614241187};\\\", \\\"{x:1223,y:782,t:1527614241204};\\\", \\\"{x:1217,y:782,t:1527614241220};\\\", \\\"{x:1215,y:782,t:1527614241237};\\\", \\\"{x:1214,y:782,t:1527614241277};\\\", \\\"{x:1212,y:782,t:1527614241301};\\\", \\\"{x:1211,y:782,t:1527614241309};\\\", \\\"{x:1210,y:782,t:1527614241325};\\\", \\\"{x:1209,y:782,t:1527614241389};\\\", \\\"{x:1208,y:782,t:1527614241461};\\\", \\\"{x:1205,y:782,t:1527614241477};\\\", \\\"{x:1204,y:782,t:1527614241487};\\\", \\\"{x:1199,y:782,t:1527614241504};\\\", \\\"{x:1194,y:782,t:1527614241521};\\\", \\\"{x:1190,y:782,t:1527614241537};\\\", \\\"{x:1188,y:781,t:1527614241554};\\\", \\\"{x:1187,y:781,t:1527614241571};\\\", \\\"{x:1184,y:779,t:1527614241588};\\\", \\\"{x:1181,y:775,t:1527614241604};\\\", \\\"{x:1179,y:771,t:1527614241621};\\\", \\\"{x:1177,y:768,t:1527614241637};\\\", \\\"{x:1177,y:766,t:1527614241661};\\\", \\\"{x:1177,y:765,t:1527614241693};\\\", \\\"{x:1177,y:764,t:1527614241709};\\\", \\\"{x:1177,y:762,t:1527614241721};\\\", \\\"{x:1180,y:761,t:1527614241737};\\\", \\\"{x:1181,y:761,t:1527614242134};\\\", \\\"{x:1181,y:771,t:1527614242150};\\\", \\\"{x:1181,y:786,t:1527614242157};\\\", \\\"{x:1185,y:802,t:1527614242171};\\\", \\\"{x:1193,y:833,t:1527614242188};\\\", \\\"{x:1196,y:849,t:1527614242204};\\\", \\\"{x:1197,y:862,t:1527614242221};\\\", \\\"{x:1198,y:866,t:1527614242238};\\\", \\\"{x:1198,y:872,t:1527614242256};\\\", \\\"{x:1198,y:879,t:1527614242271};\\\", \\\"{x:1198,y:884,t:1527614242289};\\\", \\\"{x:1198,y:888,t:1527614242305};\\\", \\\"{x:1198,y:893,t:1527614242321};\\\", \\\"{x:1198,y:902,t:1527614242338};\\\", \\\"{x:1199,y:909,t:1527614242356};\\\", \\\"{x:1200,y:916,t:1527614242371};\\\", \\\"{x:1201,y:920,t:1527614242388};\\\", \\\"{x:1201,y:928,t:1527614242405};\\\", \\\"{x:1200,y:932,t:1527614242421};\\\", \\\"{x:1198,y:937,t:1527614242438};\\\", \\\"{x:1198,y:942,t:1527614242455};\\\", \\\"{x:1195,y:948,t:1527614242472};\\\", \\\"{x:1193,y:953,t:1527614242488};\\\", \\\"{x:1191,y:957,t:1527614242505};\\\", \\\"{x:1189,y:959,t:1527614242521};\\\", \\\"{x:1189,y:960,t:1527614242539};\\\", \\\"{x:1187,y:960,t:1527614242574};\\\", \\\"{x:1186,y:960,t:1527614242605};\\\", \\\"{x:1185,y:960,t:1527614242693};\\\", \\\"{x:1185,y:959,t:1527614242706};\\\", \\\"{x:1183,y:952,t:1527614242721};\\\", \\\"{x:1179,y:945,t:1527614242739};\\\", \\\"{x:1175,y:932,t:1527614242756};\\\", \\\"{x:1174,y:925,t:1527614242772};\\\", \\\"{x:1174,y:920,t:1527614242789};\\\", \\\"{x:1174,y:907,t:1527614242806};\\\", \\\"{x:1174,y:899,t:1527614242822};\\\", \\\"{x:1174,y:890,t:1527614242838};\\\", \\\"{x:1175,y:883,t:1527614242855};\\\", \\\"{x:1176,y:875,t:1527614242872};\\\", \\\"{x:1176,y:869,t:1527614242888};\\\", \\\"{x:1178,y:863,t:1527614242905};\\\", \\\"{x:1179,y:860,t:1527614242922};\\\", \\\"{x:1182,y:854,t:1527614242939};\\\", \\\"{x:1183,y:849,t:1527614242955};\\\", \\\"{x:1185,y:844,t:1527614242972};\\\", \\\"{x:1187,y:839,t:1527614242988};\\\", \\\"{x:1188,y:832,t:1527614243005};\\\", \\\"{x:1188,y:828,t:1527614243022};\\\", \\\"{x:1189,y:824,t:1527614243038};\\\", \\\"{x:1190,y:818,t:1527614243055};\\\", \\\"{x:1190,y:814,t:1527614243072};\\\", \\\"{x:1191,y:807,t:1527614243088};\\\", \\\"{x:1191,y:801,t:1527614243106};\\\", \\\"{x:1191,y:797,t:1527614243122};\\\", \\\"{x:1191,y:795,t:1527614243138};\\\", \\\"{x:1191,y:794,t:1527614243155};\\\", \\\"{x:1191,y:791,t:1527614243173};\\\", \\\"{x:1189,y:788,t:1527614243190};\\\", \\\"{x:1189,y:785,t:1527614243205};\\\", \\\"{x:1189,y:784,t:1527614243222};\\\", \\\"{x:1188,y:782,t:1527614243239};\\\", \\\"{x:1187,y:780,t:1527614243255};\\\", \\\"{x:1186,y:779,t:1527614243272};\\\", \\\"{x:1186,y:778,t:1527614243290};\\\", \\\"{x:1185,y:775,t:1527614243305};\\\", \\\"{x:1183,y:772,t:1527614243322};\\\", \\\"{x:1182,y:771,t:1527614243339};\\\", \\\"{x:1182,y:770,t:1527614243356};\\\", \\\"{x:1182,y:769,t:1527614243372};\\\", \\\"{x:1182,y:768,t:1527614243430};\\\", \\\"{x:1182,y:767,t:1527614243439};\\\", \\\"{x:1182,y:766,t:1527614243455};\\\", \\\"{x:1184,y:766,t:1527614244278};\\\", \\\"{x:1187,y:765,t:1527614244290};\\\", \\\"{x:1192,y:764,t:1527614244307};\\\", \\\"{x:1195,y:763,t:1527614244324};\\\", \\\"{x:1195,y:762,t:1527614244339};\\\", \\\"{x:1197,y:762,t:1527614244357};\\\", \\\"{x:1200,y:761,t:1527614244373};\\\", \\\"{x:1204,y:759,t:1527614244389};\\\", \\\"{x:1208,y:759,t:1527614244406};\\\", \\\"{x:1211,y:758,t:1527614244423};\\\", \\\"{x:1212,y:758,t:1527614244439};\\\", \\\"{x:1214,y:757,t:1527614244457};\\\", \\\"{x:1215,y:757,t:1527614244473};\\\", \\\"{x:1217,y:756,t:1527614244490};\\\", \\\"{x:1219,y:756,t:1527614244506};\\\", \\\"{x:1223,y:756,t:1527614244523};\\\", \\\"{x:1228,y:757,t:1527614244541};\\\", \\\"{x:1233,y:757,t:1527614244556};\\\", \\\"{x:1240,y:760,t:1527614244574};\\\", \\\"{x:1242,y:760,t:1527614244591};\\\", \\\"{x:1243,y:760,t:1527614244645};\\\", \\\"{x:1245,y:760,t:1527614244657};\\\", \\\"{x:1246,y:761,t:1527614244674};\\\", \\\"{x:1248,y:761,t:1527614244690};\\\", \\\"{x:1249,y:761,t:1527614244706};\\\", \\\"{x:1251,y:761,t:1527614245485};\\\", \\\"{x:1252,y:761,t:1527614245493};\\\", \\\"{x:1255,y:761,t:1527614245507};\\\", \\\"{x:1261,y:761,t:1527614245525};\\\", \\\"{x:1268,y:761,t:1527614245541};\\\", \\\"{x:1278,y:761,t:1527614245558};\\\", \\\"{x:1284,y:761,t:1527614245575};\\\", \\\"{x:1288,y:761,t:1527614245591};\\\", \\\"{x:1290,y:761,t:1527614245608};\\\", \\\"{x:1291,y:761,t:1527614245625};\\\", \\\"{x:1293,y:761,t:1527614245646};\\\", \\\"{x:1294,y:761,t:1527614245658};\\\", \\\"{x:1296,y:761,t:1527614245675};\\\", \\\"{x:1299,y:761,t:1527614245691};\\\", \\\"{x:1301,y:761,t:1527614245710};\\\", \\\"{x:1303,y:761,t:1527614245726};\\\", \\\"{x:1304,y:761,t:1527614245741};\\\", \\\"{x:1309,y:761,t:1527614245758};\\\", \\\"{x:1312,y:761,t:1527614245775};\\\", \\\"{x:1314,y:761,t:1527614245792};\\\", \\\"{x:1315,y:761,t:1527614246239};\\\", \\\"{x:1318,y:761,t:1527614246246};\\\", \\\"{x:1322,y:761,t:1527614246259};\\\", \\\"{x:1336,y:762,t:1527614246275};\\\", \\\"{x:1351,y:764,t:1527614246292};\\\", \\\"{x:1368,y:765,t:1527614246310};\\\", \\\"{x:1380,y:765,t:1527614246325};\\\", \\\"{x:1389,y:765,t:1527614246343};\\\", \\\"{x:1390,y:765,t:1527614246358};\\\", \\\"{x:1388,y:764,t:1527614246614};\\\", \\\"{x:1386,y:763,t:1527614246630};\\\", \\\"{x:1385,y:763,t:1527614246751};\\\", \\\"{x:1383,y:763,t:1527614246941};\\\", \\\"{x:1379,y:763,t:1527614252567};\\\", \\\"{x:1367,y:763,t:1527614252580};\\\", \\\"{x:1344,y:763,t:1527614252597};\\\", \\\"{x:1327,y:763,t:1527614252614};\\\", \\\"{x:1317,y:763,t:1527614252630};\\\", \\\"{x:1316,y:763,t:1527614252648};\\\", \\\"{x:1316,y:761,t:1527614252847};\\\", \\\"{x:1321,y:761,t:1527614252864};\\\", \\\"{x:1324,y:761,t:1527614252880};\\\", \\\"{x:1328,y:759,t:1527614252950};\\\", \\\"{x:1334,y:757,t:1527614252964};\\\", \\\"{x:1339,y:756,t:1527614252981};\\\", \\\"{x:1341,y:756,t:1527614252997};\\\", \\\"{x:1342,y:756,t:1527614253014};\\\", \\\"{x:1343,y:756,t:1527614253551};\\\", \\\"{x:1344,y:756,t:1527614253718};\\\", \\\"{x:1346,y:757,t:1527614253732};\\\", \\\"{x:1348,y:758,t:1527614253749};\\\", \\\"{x:1350,y:759,t:1527614253765};\\\", \\\"{x:1351,y:759,t:1527614254286};\\\", \\\"{x:1351,y:757,t:1527614258767};\\\", \\\"{x:1345,y:755,t:1527614258786};\\\", \\\"{x:1323,y:750,t:1527614258802};\\\", \\\"{x:1268,y:750,t:1527614258819};\\\", \\\"{x:1166,y:750,t:1527614258836};\\\", \\\"{x:1027,y:748,t:1527614258853};\\\", \\\"{x:885,y:742,t:1527614258869};\\\", \\\"{x:638,y:737,t:1527614258885};\\\", \\\"{x:497,y:737,t:1527614258903};\\\", \\\"{x:362,y:737,t:1527614258918};\\\", \\\"{x:245,y:737,t:1527614258935};\\\", \\\"{x:165,y:737,t:1527614258952};\\\", \\\"{x:133,y:737,t:1527614258969};\\\", \\\"{x:125,y:737,t:1527614258985};\\\", \\\"{x:128,y:737,t:1527614259214};\\\", \\\"{x:133,y:735,t:1527614259222};\\\", \\\"{x:139,y:734,t:1527614259235};\\\", \\\"{x:157,y:731,t:1527614259252};\\\", \\\"{x:178,y:729,t:1527614259269};\\\", \\\"{x:192,y:729,t:1527614259286};\\\", \\\"{x:207,y:729,t:1527614259302};\\\", \\\"{x:225,y:729,t:1527614259319};\\\", \\\"{x:252,y:729,t:1527614259335};\\\", \\\"{x:280,y:729,t:1527614259352};\\\", \\\"{x:305,y:729,t:1527614259369};\\\", \\\"{x:317,y:729,t:1527614259385};\\\", \\\"{x:320,y:729,t:1527614259402};\\\", \\\"{x:322,y:729,t:1527614259418};\\\", \\\"{x:324,y:729,t:1527614259436};\\\", \\\"{x:327,y:729,t:1527614259452};\\\", \\\"{x:332,y:729,t:1527614259468};\\\", \\\"{x:345,y:729,t:1527614259485};\\\", \\\"{x:359,y:729,t:1527614259501};\\\", \\\"{x:390,y:729,t:1527614259518};\\\", \\\"{x:440,y:734,t:1527614259535};\\\", \\\"{x:499,y:743,t:1527614259553};\\\", \\\"{x:534,y:749,t:1527614259568};\\\", \\\"{x:551,y:750,t:1527614259586};\\\", \\\"{x:554,y:750,t:1527614259603};\\\", \\\"{x:555,y:750,t:1527614261142};\\\" ] }, { \\\"rt\\\": 73630, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 14, \\\"time_elapsed\\\": 667404, \\\"internal_node_id\\\": \\\"0.0-6.0-4.0\\\", \\\"subject\\\": \\\"TGOML\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"oscar\\\", \\\"condition\\\": \\\"114\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"ends\\\", \\\"q\\\": 10, \\\"clicks\\\": 1, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XInside-YInside\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 1, \\\"answer\\\": [ \\\"X\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-F -F -F -Z -4\\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:570,y:747,t:1527614264512};\\\", \\\"{x:631,y:747,t:1527614264524};\\\", \\\"{x:731,y:747,t:1527614264542};\\\", \\\"{x:856,y:747,t:1527614264557};\\\", \\\"{x:994,y:747,t:1527614264573};\\\", \\\"{x:1144,y:747,t:1527614264590};\\\", \\\"{x:1287,y:747,t:1527614264607};\\\", \\\"{x:1404,y:747,t:1527614264623};\\\", \\\"{x:1495,y:747,t:1527614264640};\\\", \\\"{x:1538,y:746,t:1527614264657};\\\", \\\"{x:1562,y:742,t:1527614264673};\\\", \\\"{x:1570,y:741,t:1527614264690};\\\", \\\"{x:1571,y:740,t:1527614264707};\\\", \\\"{x:1572,y:739,t:1527614264741};\\\", \\\"{x:1570,y:736,t:1527614264758};\\\", \\\"{x:1568,y:735,t:1527614264773};\\\", \\\"{x:1568,y:734,t:1527614264838};\\\", \\\"{x:1567,y:733,t:1527614264845};\\\", \\\"{x:1564,y:731,t:1527614264857};\\\", \\\"{x:1548,y:723,t:1527614264874};\\\", \\\"{x:1535,y:719,t:1527614264890};\\\", \\\"{x:1526,y:715,t:1527614264907};\\\", \\\"{x:1521,y:714,t:1527614264925};\\\", \\\"{x:1516,y:714,t:1527614264940};\\\", \\\"{x:1506,y:712,t:1527614264957};\\\", \\\"{x:1497,y:712,t:1527614264974};\\\", \\\"{x:1479,y:712,t:1527614264991};\\\", \\\"{x:1456,y:712,t:1527614265007};\\\", \\\"{x:1437,y:712,t:1527614265024};\\\", \\\"{x:1427,y:712,t:1527614265040};\\\", \\\"{x:1420,y:713,t:1527614265057};\\\", \\\"{x:1416,y:714,t:1527614265074};\\\", \\\"{x:1414,y:714,t:1527614265090};\\\", \\\"{x:1411,y:716,t:1527614265108};\\\", \\\"{x:1405,y:718,t:1527614265125};\\\", \\\"{x:1400,y:721,t:1527614265140};\\\", \\\"{x:1395,y:721,t:1527614265157};\\\", \\\"{x:1394,y:722,t:1527614265175};\\\", \\\"{x:1393,y:723,t:1527614265230};\\\", \\\"{x:1391,y:722,t:1527614265241};\\\", \\\"{x:1379,y:715,t:1527614265257};\\\", \\\"{x:1364,y:704,t:1527614265275};\\\", \\\"{x:1357,y:698,t:1527614265292};\\\", \\\"{x:1353,y:695,t:1527614265310};\\\", \\\"{x:1350,y:692,t:1527614265324};\\\", \\\"{x:1346,y:688,t:1527614265341};\\\", \\\"{x:1342,y:684,t:1527614265357};\\\", \\\"{x:1340,y:682,t:1527614265374};\\\", \\\"{x:1339,y:681,t:1527614265391};\\\", \\\"{x:1339,y:680,t:1527614265420};\\\", \\\"{x:1338,y:681,t:1527614265534};\\\", \\\"{x:1338,y:684,t:1527614265541};\\\", \\\"{x:1338,y:689,t:1527614265558};\\\", \\\"{x:1338,y:692,t:1527614265575};\\\", \\\"{x:1339,y:694,t:1527614265591};\\\", \\\"{x:1339,y:695,t:1527614265607};\\\", \\\"{x:1339,y:697,t:1527614265630};\\\", \\\"{x:1340,y:698,t:1527614265742};\\\", \\\"{x:1341,y:698,t:1527614265790};\\\", \\\"{x:1343,y:698,t:1527614265798};\\\", \\\"{x:1344,y:698,t:1527614265809};\\\", \\\"{x:1345,y:698,t:1527614265825};\\\", \\\"{x:1346,y:698,t:1527614265841};\\\", \\\"{x:1347,y:698,t:1527614265859};\\\", \\\"{x:1348,y:698,t:1527614273210};\\\", \\\"{x:1348,y:701,t:1527614273697};\\\", \\\"{x:1349,y:703,t:1527614273715};\\\", \\\"{x:1350,y:703,t:1527614273914};\\\", \\\"{x:1351,y:703,t:1527614273921};\\\", \\\"{x:1352,y:703,t:1527614273944};\\\", \\\"{x:1353,y:703,t:1527614273952};\\\", \\\"{x:1356,y:703,t:1527614273969};\\\", \\\"{x:1361,y:700,t:1527614273986};\\\", \\\"{x:1366,y:699,t:1527614274002};\\\", \\\"{x:1370,y:697,t:1527614274018};\\\", \\\"{x:1371,y:697,t:1527614274035};\\\", \\\"{x:1372,y:697,t:1527614274052};\\\", \\\"{x:1374,y:696,t:1527614274073};\\\", \\\"{x:1375,y:696,t:1527614274086};\\\", \\\"{x:1378,y:696,t:1527614274102};\\\", \\\"{x:1381,y:695,t:1527614274119};\\\", \\\"{x:1383,y:695,t:1527614274136};\\\", \\\"{x:1385,y:694,t:1527614274151};\\\", \\\"{x:1387,y:693,t:1527614274168};\\\", \\\"{x:1395,y:692,t:1527614274185};\\\", \\\"{x:1401,y:692,t:1527614274202};\\\", \\\"{x:1413,y:692,t:1527614274219};\\\", \\\"{x:1421,y:692,t:1527614274236};\\\", \\\"{x:1436,y:692,t:1527614274252};\\\", \\\"{x:1454,y:692,t:1527614274268};\\\", \\\"{x:1466,y:692,t:1527614274285};\\\", \\\"{x:1470,y:692,t:1527614274301};\\\", \\\"{x:1469,y:692,t:1527614274362};\\\", \\\"{x:1468,y:692,t:1527614274377};\\\", \\\"{x:1466,y:692,t:1527614274386};\\\", \\\"{x:1455,y:694,t:1527614274402};\\\", \\\"{x:1437,y:696,t:1527614274419};\\\", \\\"{x:1426,y:698,t:1527614274435};\\\", \\\"{x:1425,y:698,t:1527614274453};\\\", \\\"{x:1422,y:698,t:1527614274673};\\\", \\\"{x:1418,y:698,t:1527614274686};\\\", \\\"{x:1405,y:698,t:1527614274702};\\\", \\\"{x:1398,y:698,t:1527614274718};\\\", \\\"{x:1395,y:698,t:1527614274736};\\\", \\\"{x:1394,y:698,t:1527614274752};\\\", \\\"{x:1395,y:698,t:1527614274889};\\\", \\\"{x:1396,y:697,t:1527614274903};\\\", \\\"{x:1398,y:697,t:1527614274921};\\\", \\\"{x:1399,y:696,t:1527614274944};\\\", \\\"{x:1401,y:696,t:1527614274961};\\\", \\\"{x:1402,y:695,t:1527614274969};\\\", \\\"{x:1404,y:694,t:1527614274985};\\\", \\\"{x:1409,y:694,t:1527614275003};\\\", \\\"{x:1412,y:692,t:1527614275020};\\\", \\\"{x:1413,y:692,t:1527614275036};\\\", \\\"{x:1414,y:692,t:1527614275053};\\\", \\\"{x:1415,y:692,t:1527614275322};\\\", \\\"{x:1418,y:692,t:1527614275336};\\\", \\\"{x:1424,y:692,t:1527614275353};\\\", \\\"{x:1434,y:693,t:1527614275370};\\\", \\\"{x:1443,y:696,t:1527614275387};\\\", \\\"{x:1449,y:698,t:1527614275403};\\\", \\\"{x:1454,y:699,t:1527614275420};\\\", \\\"{x:1457,y:700,t:1527614275436};\\\", \\\"{x:1458,y:700,t:1527614275452};\\\", \\\"{x:1461,y:700,t:1527614275470};\\\", \\\"{x:1463,y:700,t:1527614275487};\\\", \\\"{x:1464,y:700,t:1527614275504};\\\", \\\"{x:1466,y:700,t:1527614275538};\\\", \\\"{x:1467,y:700,t:1527614275553};\\\", \\\"{x:1469,y:700,t:1527614275570};\\\", \\\"{x:1470,y:700,t:1527614275587};\\\", \\\"{x:1472,y:700,t:1527614275603};\\\", \\\"{x:1473,y:699,t:1527614275620};\\\", \\\"{x:1475,y:698,t:1527614275637};\\\", \\\"{x:1475,y:697,t:1527614275666};\\\", \\\"{x:1476,y:697,t:1527614276122};\\\", \\\"{x:1477,y:697,t:1527614276137};\\\", \\\"{x:1480,y:697,t:1527614276154};\\\", \\\"{x:1486,y:698,t:1527614276171};\\\", \\\"{x:1494,y:699,t:1527614276187};\\\", \\\"{x:1507,y:701,t:1527614276204};\\\", \\\"{x:1522,y:703,t:1527614276221};\\\", \\\"{x:1535,y:704,t:1527614276238};\\\", \\\"{x:1542,y:704,t:1527614276255};\\\", \\\"{x:1544,y:704,t:1527614276271};\\\", \\\"{x:1546,y:704,t:1527614276288};\\\", \\\"{x:1547,y:704,t:1527614276304};\\\", \\\"{x:1550,y:703,t:1527614276322};\\\", \\\"{x:1550,y:702,t:1527614276368};\\\", \\\"{x:1550,y:701,t:1527614276384};\\\", \\\"{x:1550,y:700,t:1527614276409};\\\", \\\"{x:1550,y:699,t:1527614276425};\\\", \\\"{x:1549,y:697,t:1527614276489};\\\", \\\"{x:1549,y:696,t:1527614276625};\\\", \\\"{x:1550,y:697,t:1527614276754};\\\", \\\"{x:1553,y:699,t:1527614276770};\\\", \\\"{x:1556,y:702,t:1527614276788};\\\", \\\"{x:1559,y:704,t:1527614276804};\\\", \\\"{x:1564,y:705,t:1527614276820};\\\", \\\"{x:1573,y:705,t:1527614276838};\\\", \\\"{x:1582,y:706,t:1527614276854};\\\", \\\"{x:1591,y:706,t:1527614276871};\\\", \\\"{x:1604,y:706,t:1527614276888};\\\", \\\"{x:1618,y:706,t:1527614276904};\\\", \\\"{x:1627,y:706,t:1527614276921};\\\", \\\"{x:1630,y:706,t:1527614276938};\\\", \\\"{x:1630,y:705,t:1527614276994};\\\", \\\"{x:1630,y:704,t:1527614277005};\\\", \\\"{x:1631,y:703,t:1527614277021};\\\", \\\"{x:1631,y:702,t:1527614277039};\\\", \\\"{x:1631,y:701,t:1527614277055};\\\", \\\"{x:1631,y:700,t:1527614277081};\\\", \\\"{x:1631,y:699,t:1527614277097};\\\", \\\"{x:1630,y:698,t:1527614277113};\\\", \\\"{x:1630,y:697,t:1527614277130};\\\", \\\"{x:1629,y:697,t:1527614277138};\\\", \\\"{x:1626,y:697,t:1527614277155};\\\", \\\"{x:1623,y:695,t:1527614277171};\\\", \\\"{x:1622,y:695,t:1527614277188};\\\", \\\"{x:1621,y:695,t:1527614277418};\\\", \\\"{x:1620,y:695,t:1527614277434};\\\", \\\"{x:1619,y:695,t:1527614277455};\\\", \\\"{x:1618,y:695,t:1527614277809};\\\", \\\"{x:1617,y:694,t:1527614277873};\\\", \\\"{x:1616,y:694,t:1527614278168};\\\", \\\"{x:1615,y:694,t:1527614278176};\\\", \\\"{x:1614,y:694,t:1527614278257};\\\", \\\"{x:1613,y:693,t:1527614279658};\\\", \\\"{x:1613,y:694,t:1527614292889};\\\", \\\"{x:1613,y:695,t:1527614292901};\\\", \\\"{x:1613,y:696,t:1527614292921};\\\", \\\"{x:1613,y:698,t:1527614292933};\\\", \\\"{x:1613,y:701,t:1527614292950};\\\", \\\"{x:1613,y:705,t:1527614292968};\\\", \\\"{x:1613,y:710,t:1527614292984};\\\", \\\"{x:1613,y:718,t:1527614293001};\\\", \\\"{x:1613,y:724,t:1527614293017};\\\", \\\"{x:1614,y:727,t:1527614293034};\\\", \\\"{x:1615,y:733,t:1527614293050};\\\", \\\"{x:1615,y:735,t:1527614293068};\\\", \\\"{x:1615,y:737,t:1527614293085};\\\", \\\"{x:1615,y:738,t:1527614293100};\\\", \\\"{x:1615,y:739,t:1527614293185};\\\", \\\"{x:1615,y:742,t:1527614293201};\\\", \\\"{x:1615,y:746,t:1527614293217};\\\", \\\"{x:1614,y:752,t:1527614293235};\\\", \\\"{x:1612,y:762,t:1527614293251};\\\", \\\"{x:1608,y:773,t:1527614293267};\\\", \\\"{x:1608,y:785,t:1527614293284};\\\", \\\"{x:1608,y:795,t:1527614293300};\\\", \\\"{x:1608,y:801,t:1527614293317};\\\", \\\"{x:1608,y:803,t:1527614293334};\\\", \\\"{x:1608,y:807,t:1527614293351};\\\", \\\"{x:1609,y:809,t:1527614293369};\\\", \\\"{x:1609,y:810,t:1527614293385};\\\", \\\"{x:1610,y:812,t:1527614293401};\\\", \\\"{x:1610,y:814,t:1527614293418};\\\", \\\"{x:1611,y:816,t:1527614293434};\\\", \\\"{x:1612,y:822,t:1527614293450};\\\", \\\"{x:1612,y:824,t:1527614293468};\\\", \\\"{x:1613,y:826,t:1527614293484};\\\", \\\"{x:1612,y:825,t:1527614293697};\\\", \\\"{x:1611,y:824,t:1527614293713};\\\", \\\"{x:1612,y:824,t:1527614294962};\\\", \\\"{x:1613,y:826,t:1527614294969};\\\", \\\"{x:1613,y:827,t:1527614294986};\\\", \\\"{x:1614,y:827,t:1527614295003};\\\", \\\"{x:1614,y:828,t:1527614295019};\\\", \\\"{x:1615,y:828,t:1527614295041};\\\", \\\"{x:1614,y:828,t:1527614299281};\\\", \\\"{x:1612,y:828,t:1527614299498};\\\", \\\"{x:1613,y:828,t:1527614301529};\\\", \\\"{x:1614,y:828,t:1527614301553};\\\", \\\"{x:1615,y:828,t:1527614301577};\\\", \\\"{x:1615,y:829,t:1527614301590};\\\", \\\"{x:1616,y:829,t:1527614301666};\\\", \\\"{x:1617,y:830,t:1527614301681};\\\", \\\"{x:1618,y:830,t:1527614301777};\\\", \\\"{x:1617,y:829,t:1527614306345};\\\", \\\"{x:1615,y:827,t:1527614306360};\\\", \\\"{x:1614,y:827,t:1527614306378};\\\", \\\"{x:1613,y:827,t:1527614306401};\\\", \\\"{x:1613,y:826,t:1527614330868};\\\", \\\"{x:1610,y:828,t:1527614330885};\\\", \\\"{x:1610,y:829,t:1527614330902};\\\", \\\"{x:1609,y:829,t:1527614331524};\\\", \\\"{x:1608,y:829,t:1527614331536};\\\", \\\"{x:1603,y:827,t:1527614332716};\\\", \\\"{x:1593,y:826,t:1527614332724};\\\", \\\"{x:1577,y:826,t:1527614332737};\\\", \\\"{x:1561,y:826,t:1527614332754};\\\", \\\"{x:1554,y:824,t:1527614332770};\\\", \\\"{x:1543,y:820,t:1527614332787};\\\", \\\"{x:1528,y:818,t:1527614332804};\\\", \\\"{x:1467,y:806,t:1527614332820};\\\", \\\"{x:1383,y:789,t:1527614332836};\\\", \\\"{x:1291,y:764,t:1527614332853};\\\", \\\"{x:1178,y:733,t:1527614332870};\\\", \\\"{x:1062,y:697,t:1527614332887};\\\", \\\"{x:940,y:664,t:1527614332903};\\\", \\\"{x:813,y:628,t:1527614332923};\\\", \\\"{x:676,y:598,t:1527614332937};\\\", \\\"{x:543,y:581,t:1527614332952};\\\", \\\"{x:420,y:571,t:1527614332971};\\\", \\\"{x:286,y:569,t:1527614332987};\\\", \\\"{x:235,y:561,t:1527614333005};\\\", \\\"{x:210,y:561,t:1527614333021};\\\", \\\"{x:185,y:561,t:1527614333037};\\\", \\\"{x:159,y:561,t:1527614333054};\\\", \\\"{x:139,y:561,t:1527614333071};\\\", \\\"{x:125,y:561,t:1527614333088};\\\", \\\"{x:120,y:562,t:1527614333104};\\\", \\\"{x:119,y:562,t:1527614333121};\\\", \\\"{x:119,y:563,t:1527614333164};\\\", \\\"{x:121,y:566,t:1527614333180};\\\", \\\"{x:129,y:570,t:1527614333188};\\\", \\\"{x:150,y:574,t:1527614333205};\\\", \\\"{x:177,y:583,t:1527614333222};\\\", \\\"{x:200,y:585,t:1527614333238};\\\", \\\"{x:215,y:585,t:1527614333255};\\\", \\\"{x:222,y:585,t:1527614333272};\\\", \\\"{x:225,y:585,t:1527614333288};\\\", \\\"{x:229,y:581,t:1527614333305};\\\", \\\"{x:233,y:577,t:1527614333322};\\\", \\\"{x:237,y:574,t:1527614333339};\\\", \\\"{x:239,y:572,t:1527614333354};\\\", \\\"{x:244,y:569,t:1527614333371};\\\", \\\"{x:250,y:565,t:1527614333388};\\\", \\\"{x:261,y:560,t:1527614333405};\\\", \\\"{x:274,y:555,t:1527614333422};\\\", \\\"{x:282,y:548,t:1527614333439};\\\", \\\"{x:291,y:545,t:1527614333455};\\\", \\\"{x:303,y:540,t:1527614333471};\\\", \\\"{x:312,y:538,t:1527614333488};\\\", \\\"{x:330,y:536,t:1527614333504};\\\", \\\"{x:349,y:533,t:1527614333522};\\\", \\\"{x:372,y:533,t:1527614333538};\\\", \\\"{x:398,y:533,t:1527614333554};\\\", \\\"{x:453,y:536,t:1527614333571};\\\", \\\"{x:510,y:547,t:1527614333589};\\\", \\\"{x:577,y:556,t:1527614333606};\\\", \\\"{x:632,y:562,t:1527614333622};\\\", \\\"{x:680,y:562,t:1527614333639};\\\", \\\"{x:706,y:567,t:1527614333655};\\\", \\\"{x:723,y:569,t:1527614333671};\\\", \\\"{x:733,y:570,t:1527614333689};\\\", \\\"{x:734,y:572,t:1527614333704};\\\", \\\"{x:735,y:572,t:1527614333721};\\\", \\\"{x:736,y:572,t:1527614333771};\\\", \\\"{x:737,y:572,t:1527614333804};\\\", \\\"{x:737,y:573,t:1527614333836};\\\", \\\"{x:736,y:573,t:1527614333844};\\\", \\\"{x:732,y:575,t:1527614333855};\\\", \\\"{x:723,y:575,t:1527614333873};\\\", \\\"{x:705,y:578,t:1527614333888};\\\", \\\"{x:682,y:580,t:1527614333905};\\\", \\\"{x:650,y:582,t:1527614333921};\\\", \\\"{x:622,y:587,t:1527614333938};\\\", \\\"{x:599,y:589,t:1527614333955};\\\", \\\"{x:591,y:591,t:1527614333971};\\\", \\\"{x:590,y:591,t:1527614333988};\\\", \\\"{x:590,y:588,t:1527614334083};\\\", \\\"{x:590,y:585,t:1527614334100};\\\", \\\"{x:591,y:584,t:1527614334107};\\\", \\\"{x:593,y:584,t:1527614334121};\\\", \\\"{x:596,y:581,t:1527614334138};\\\", \\\"{x:598,y:581,t:1527614334155};\\\", \\\"{x:600,y:581,t:1527614334172};\\\", \\\"{x:602,y:580,t:1527614334188};\\\", \\\"{x:604,y:580,t:1527614334206};\\\", \\\"{x:607,y:580,t:1527614334223};\\\", \\\"{x:610,y:580,t:1527614334240};\\\", \\\"{x:611,y:580,t:1527614334276};\\\", \\\"{x:613,y:580,t:1527614334315};\\\", \\\"{x:614,y:580,t:1527614334339};\\\", \\\"{x:614,y:580,t:1527614334416};\\\", \\\"{x:613,y:583,t:1527614334467};\\\", \\\"{x:608,y:590,t:1527614334475};\\\", \\\"{x:605,y:603,t:1527614334489};\\\", \\\"{x:596,y:634,t:1527614334505};\\\", \\\"{x:584,y:668,t:1527614334523};\\\", \\\"{x:577,y:700,t:1527614334538};\\\", \\\"{x:566,y:732,t:1527614334555};\\\", \\\"{x:561,y:740,t:1527614334573};\\\", \\\"{x:559,y:745,t:1527614334589};\\\", \\\"{x:557,y:748,t:1527614334605};\\\", \\\"{x:555,y:748,t:1527614334788};\\\", \\\"{x:555,y:747,t:1527614334795};\\\", \\\"{x:554,y:745,t:1527614334805};\\\", \\\"{x:551,y:742,t:1527614334822};\\\", \\\"{x:549,y:737,t:1527614334840};\\\", \\\"{x:548,y:735,t:1527614334856};\\\", \\\"{x:548,y:734,t:1527614335067};\\\" ] }, { \\\"rt\\\": 15204, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 15, \\\"time_elapsed\\\": 684174, \\\"internal_node_id\\\": \\\"0.0-6.0-5.0\\\", \\\"subject\\\": \\\"TGOML\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"oscar\\\", \\\"condition\\\": \\\"114\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"starttime\\\", \\\"q\\\": 11, \\\"clicks\\\": 2, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XInside-YInside\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 1, \\\"answer\\\": [ \\\"F\\\", \\\"B\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"\\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:548,y:733,t:1527614344580};\\\", \\\"{x:539,y:733,t:1527614344591};\\\", \\\"{x:516,y:730,t:1527614344606};\\\", \\\"{x:499,y:728,t:1527614344623};\\\", \\\"{x:490,y:727,t:1527614344641};\\\", \\\"{x:485,y:726,t:1527614344656};\\\", \\\"{x:481,y:720,t:1527614344812};\\\", \\\"{x:477,y:717,t:1527614344825};\\\", \\\"{x:464,y:703,t:1527614344840};\\\", \\\"{x:446,y:687,t:1527614344856};\\\", \\\"{x:414,y:662,t:1527614344876};\\\", \\\"{x:399,y:651,t:1527614344892};\\\", \\\"{x:392,y:646,t:1527614344909};\\\", \\\"{x:389,y:644,t:1527614344924};\\\", \\\"{x:386,y:641,t:1527614344942};\\\", \\\"{x:385,y:640,t:1527614344959};\\\", \\\"{x:385,y:639,t:1527614344981};\\\", \\\"{x:384,y:638,t:1527614344999};\\\", \\\"{x:383,y:638,t:1527614345019};\\\", \\\"{x:383,y:637,t:1527614345059};\\\", \\\"{x:384,y:636,t:1527614345075};\\\", \\\"{x:384,y:635,t:1527614345083};\\\", \\\"{x:385,y:634,t:1527614345098};\\\", \\\"{x:388,y:633,t:1527614345115};\\\", \\\"{x:391,y:632,t:1527614345131};\\\", \\\"{x:392,y:631,t:1527614345149};\\\", \\\"{x:393,y:631,t:1527614345171};\\\", \\\"{x:394,y:630,t:1527614345186};\\\", \\\"{x:395,y:629,t:1527614345203};\\\", \\\"{x:396,y:629,t:1527614345219};\\\", \\\"{x:397,y:628,t:1527614345231};\\\", \\\"{x:398,y:628,t:1527614345275};\\\", \\\"{x:400,y:627,t:1527614345283};\\\", \\\"{x:401,y:625,t:1527614345316};\\\", \\\"{x:401,y:624,t:1527614345435};\\\", \\\"{x:401,y:621,t:1527614345448};\\\", \\\"{x:401,y:617,t:1527614345466};\\\", \\\"{x:400,y:613,t:1527614345481};\\\", \\\"{x:399,y:610,t:1527614345498};\\\", \\\"{x:396,y:607,t:1527614345515};\\\", \\\"{x:395,y:604,t:1527614345532};\\\", \\\"{x:391,y:601,t:1527614345549};\\\", \\\"{x:382,y:595,t:1527614345566};\\\", \\\"{x:370,y:592,t:1527614345581};\\\", \\\"{x:353,y:588,t:1527614345598};\\\", \\\"{x:335,y:582,t:1527614345615};\\\", \\\"{x:313,y:578,t:1527614345632};\\\", \\\"{x:293,y:573,t:1527614345648};\\\", \\\"{x:283,y:572,t:1527614345665};\\\", \\\"{x:276,y:570,t:1527614345681};\\\", \\\"{x:272,y:570,t:1527614345698};\\\", \\\"{x:269,y:569,t:1527614345715};\\\", \\\"{x:263,y:569,t:1527614345731};\\\", \\\"{x:261,y:569,t:1527614345747};\\\", \\\"{x:258,y:569,t:1527614345765};\\\", \\\"{x:256,y:568,t:1527614345782};\\\", \\\"{x:252,y:568,t:1527614345798};\\\", \\\"{x:244,y:568,t:1527614345815};\\\", \\\"{x:233,y:568,t:1527614345832};\\\", \\\"{x:215,y:568,t:1527614345848};\\\", \\\"{x:203,y:568,t:1527614345865};\\\", \\\"{x:192,y:568,t:1527614345882};\\\", \\\"{x:190,y:568,t:1527614345898};\\\", \\\"{x:188,y:568,t:1527614345915};\\\", \\\"{x:187,y:568,t:1527614345964};\\\", \\\"{x:185,y:569,t:1527614345972};\\\", \\\"{x:185,y:570,t:1527614345983};\\\", \\\"{x:183,y:572,t:1527614345998};\\\", \\\"{x:180,y:576,t:1527614346015};\\\", \\\"{x:179,y:581,t:1527614346032};\\\", \\\"{x:176,y:588,t:1527614346049};\\\", \\\"{x:176,y:593,t:1527614346065};\\\", \\\"{x:175,y:596,t:1527614346082};\\\", \\\"{x:174,y:599,t:1527614346098};\\\", \\\"{x:173,y:602,t:1527614346115};\\\", \\\"{x:172,y:603,t:1527614346131};\\\", \\\"{x:172,y:605,t:1527614346149};\\\", \\\"{x:172,y:606,t:1527614346164};\\\", \\\"{x:172,y:608,t:1527614346181};\\\", \\\"{x:172,y:609,t:1527614346198};\\\", \\\"{x:170,y:612,t:1527614346215};\\\", \\\"{x:170,y:615,t:1527614346231};\\\", \\\"{x:170,y:618,t:1527614346249};\\\", \\\"{x:169,y:622,t:1527614346265};\\\", \\\"{x:168,y:625,t:1527614346281};\\\", \\\"{x:168,y:626,t:1527614346299};\\\", \\\"{x:168,y:627,t:1527614346315};\\\", \\\"{x:168,y:628,t:1527614346333};\\\", \\\"{x:168,y:630,t:1527614346348};\\\", \\\"{x:168,y:632,t:1527614346365};\\\", \\\"{x:169,y:634,t:1527614346382};\\\", \\\"{x:174,y:635,t:1527614346399};\\\", \\\"{x:184,y:636,t:1527614346415};\\\", \\\"{x:200,y:636,t:1527614346431};\\\", \\\"{x:223,y:636,t:1527614346448};\\\", \\\"{x:248,y:636,t:1527614346466};\\\", \\\"{x:268,y:636,t:1527614346482};\\\", \\\"{x:290,y:630,t:1527614346499};\\\", \\\"{x:297,y:628,t:1527614346516};\\\", \\\"{x:303,y:627,t:1527614346532};\\\", \\\"{x:309,y:625,t:1527614346548};\\\", \\\"{x:310,y:624,t:1527614346566};\\\", \\\"{x:312,y:624,t:1527614346582};\\\", \\\"{x:315,y:623,t:1527614346599};\\\", \\\"{x:320,y:621,t:1527614346616};\\\", \\\"{x:328,y:617,t:1527614346632};\\\", \\\"{x:333,y:615,t:1527614346649};\\\", \\\"{x:341,y:610,t:1527614346666};\\\", \\\"{x:345,y:609,t:1527614346682};\\\", \\\"{x:351,y:603,t:1527614346699};\\\", \\\"{x:353,y:600,t:1527614346717};\\\", \\\"{x:360,y:595,t:1527614346731};\\\", \\\"{x:366,y:589,t:1527614346749};\\\", \\\"{x:371,y:584,t:1527614346766};\\\", \\\"{x:374,y:580,t:1527614346783};\\\", \\\"{x:374,y:578,t:1527614346799};\\\", \\\"{x:374,y:575,t:1527614346816};\\\", \\\"{x:374,y:573,t:1527614346833};\\\", \\\"{x:374,y:572,t:1527614346849};\\\", \\\"{x:375,y:570,t:1527614346865};\\\", \\\"{x:377,y:565,t:1527614346883};\\\", \\\"{x:378,y:563,t:1527614346899};\\\", \\\"{x:379,y:561,t:1527614346916};\\\", \\\"{x:381,y:558,t:1527614346933};\\\", \\\"{x:382,y:556,t:1527614346954};\\\", \\\"{x:383,y:555,t:1527614346967};\\\", \\\"{x:385,y:554,t:1527614346982};\\\", \\\"{x:389,y:548,t:1527614347000};\\\", \\\"{x:395,y:543,t:1527614347016};\\\", \\\"{x:403,y:539,t:1527614347033};\\\", \\\"{x:413,y:534,t:1527614347049};\\\", \\\"{x:425,y:529,t:1527614347067};\\\", \\\"{x:446,y:522,t:1527614347084};\\\", \\\"{x:467,y:516,t:1527614347100};\\\", \\\"{x:478,y:511,t:1527614347116};\\\", \\\"{x:482,y:509,t:1527614347133};\\\", \\\"{x:484,y:509,t:1527614347149};\\\", \\\"{x:487,y:508,t:1527614347203};\\\", \\\"{x:489,y:506,t:1527614347215};\\\", \\\"{x:495,y:505,t:1527614347232};\\\", \\\"{x:508,y:502,t:1527614347250};\\\", \\\"{x:521,y:499,t:1527614347266};\\\", \\\"{x:541,y:496,t:1527614347283};\\\", \\\"{x:563,y:496,t:1527614347299};\\\", \\\"{x:588,y:496,t:1527614347316};\\\", \\\"{x:613,y:496,t:1527614347333};\\\", \\\"{x:633,y:496,t:1527614347350};\\\", \\\"{x:643,y:496,t:1527614347367};\\\", \\\"{x:647,y:495,t:1527614347382};\\\", \\\"{x:650,y:495,t:1527614347419};\\\", \\\"{x:654,y:495,t:1527614347433};\\\", \\\"{x:671,y:495,t:1527614347450};\\\", \\\"{x:696,y:495,t:1527614347466};\\\", \\\"{x:743,y:495,t:1527614347485};\\\", \\\"{x:773,y:495,t:1527614347500};\\\", \\\"{x:794,y:495,t:1527614347516};\\\", \\\"{x:799,y:495,t:1527614347532};\\\", \\\"{x:800,y:494,t:1527614347550};\\\", \\\"{x:801,y:494,t:1527614347675};\\\", \\\"{x:805,y:494,t:1527614347683};\\\", \\\"{x:819,y:496,t:1527614347700};\\\", \\\"{x:829,y:496,t:1527614347716};\\\", \\\"{x:835,y:496,t:1527614347732};\\\", \\\"{x:837,y:496,t:1527614347750};\\\", \\\"{x:838,y:497,t:1527614347859};\\\", \\\"{x:839,y:498,t:1527614347883};\\\", \\\"{x:840,y:498,t:1527614347933};\\\", \\\"{x:840,y:498,t:1527614348043};\\\", \\\"{x:840,y:501,t:1527614348123};\\\", \\\"{x:834,y:506,t:1527614348133};\\\", \\\"{x:821,y:517,t:1527614348150};\\\", \\\"{x:807,y:530,t:1527614348167};\\\", \\\"{x:791,y:544,t:1527614348183};\\\", \\\"{x:776,y:552,t:1527614348200};\\\", \\\"{x:764,y:559,t:1527614348218};\\\", \\\"{x:754,y:565,t:1527614348234};\\\", \\\"{x:746,y:570,t:1527614348249};\\\", \\\"{x:729,y:580,t:1527614348266};\\\", \\\"{x:713,y:588,t:1527614348285};\\\", \\\"{x:694,y:594,t:1527614348302};\\\", \\\"{x:682,y:595,t:1527614348316};\\\", \\\"{x:669,y:598,t:1527614348334};\\\", \\\"{x:658,y:599,t:1527614348350};\\\", \\\"{x:643,y:600,t:1527614348367};\\\", \\\"{x:619,y:605,t:1527614348385};\\\", \\\"{x:589,y:606,t:1527614348400};\\\", \\\"{x:557,y:606,t:1527614348417};\\\", \\\"{x:534,y:606,t:1527614348434};\\\", \\\"{x:513,y:607,t:1527614348451};\\\", \\\"{x:506,y:607,t:1527614348467};\\\", \\\"{x:503,y:609,t:1527614348484};\\\", \\\"{x:497,y:610,t:1527614348502};\\\", \\\"{x:486,y:613,t:1527614348516};\\\", \\\"{x:471,y:613,t:1527614348534};\\\", \\\"{x:455,y:615,t:1527614348551};\\\", \\\"{x:443,y:616,t:1527614348567};\\\", \\\"{x:433,y:618,t:1527614348584};\\\", \\\"{x:425,y:620,t:1527614348602};\\\", \\\"{x:411,y:624,t:1527614348618};\\\", \\\"{x:389,y:626,t:1527614348635};\\\", \\\"{x:362,y:633,t:1527614348652};\\\", \\\"{x:348,y:637,t:1527614348668};\\\", \\\"{x:338,y:639,t:1527614348685};\\\", \\\"{x:336,y:639,t:1527614348701};\\\", \\\"{x:335,y:639,t:1527614348717};\\\", \\\"{x:333,y:639,t:1527614348734};\\\", \\\"{x:327,y:639,t:1527614348752};\\\", \\\"{x:318,y:639,t:1527614348767};\\\", \\\"{x:295,y:632,t:1527614348786};\\\", \\\"{x:270,y:622,t:1527614348801};\\\", \\\"{x:247,y:609,t:1527614348817};\\\", \\\"{x:229,y:599,t:1527614348834};\\\", \\\"{x:220,y:593,t:1527614348851};\\\", \\\"{x:218,y:591,t:1527614348867};\\\", \\\"{x:217,y:590,t:1527614348884};\\\", \\\"{x:213,y:587,t:1527614348900};\\\", \\\"{x:210,y:584,t:1527614348916};\\\", \\\"{x:206,y:583,t:1527614348934};\\\", \\\"{x:205,y:583,t:1527614348951};\\\", \\\"{x:203,y:583,t:1527614348968};\\\", \\\"{x:202,y:583,t:1527614348983};\\\", \\\"{x:198,y:582,t:1527614349001};\\\", \\\"{x:191,y:580,t:1527614349018};\\\", \\\"{x:179,y:579,t:1527614349034};\\\", \\\"{x:161,y:575,t:1527614349052};\\\", \\\"{x:150,y:568,t:1527614349068};\\\", \\\"{x:144,y:564,t:1527614349085};\\\", \\\"{x:140,y:558,t:1527614349102};\\\", \\\"{x:138,y:552,t:1527614349120};\\\", \\\"{x:138,y:550,t:1527614349134};\\\", \\\"{x:138,y:547,t:1527614349151};\\\", \\\"{x:138,y:546,t:1527614349187};\\\", \\\"{x:138,y:544,t:1527614349227};\\\", \\\"{x:139,y:543,t:1527614349235};\\\", \\\"{x:140,y:543,t:1527614349251};\\\", \\\"{x:143,y:541,t:1527614349267};\\\", \\\"{x:144,y:540,t:1527614349284};\\\", \\\"{x:146,y:540,t:1527614349301};\\\", \\\"{x:148,y:540,t:1527614349372};\\\", \\\"{x:150,y:539,t:1527614349385};\\\", \\\"{x:153,y:539,t:1527614349400};\\\", \\\"{x:154,y:539,t:1527614349418};\\\", \\\"{x:155,y:539,t:1527614349435};\\\", \\\"{x:158,y:540,t:1527614349924};\\\", \\\"{x:162,y:543,t:1527614349936};\\\", \\\"{x:172,y:551,t:1527614349953};\\\", \\\"{x:182,y:560,t:1527614349968};\\\", \\\"{x:196,y:568,t:1527614349985};\\\", \\\"{x:211,y:578,t:1527614350002};\\\", \\\"{x:230,y:591,t:1527614350018};\\\", \\\"{x:257,y:614,t:1527614350036};\\\", \\\"{x:275,y:633,t:1527614350052};\\\", \\\"{x:298,y:655,t:1527614350068};\\\", \\\"{x:304,y:659,t:1527614350085};\\\", \\\"{x:307,y:663,t:1527614350102};\\\", \\\"{x:314,y:666,t:1527614350460};\\\", \\\"{x:321,y:667,t:1527614350469};\\\", \\\"{x:338,y:673,t:1527614350486};\\\", \\\"{x:352,y:677,t:1527614350502};\\\", \\\"{x:368,y:684,t:1527614350519};\\\", \\\"{x:387,y:692,t:1527614350535};\\\", \\\"{x:407,y:698,t:1527614350552};\\\", \\\"{x:427,y:705,t:1527614350569};\\\", \\\"{x:445,y:711,t:1527614350585};\\\", \\\"{x:462,y:720,t:1527614350603};\\\", \\\"{x:499,y:740,t:1527614350618};\\\", \\\"{x:523,y:756,t:1527614350636};\\\", \\\"{x:541,y:766,t:1527614350652};\\\", \\\"{x:553,y:771,t:1527614350669};\\\", \\\"{x:556,y:771,t:1527614350685};\\\", \\\"{x:557,y:771,t:1527614350755};\\\", \\\"{x:558,y:771,t:1527614350812};\\\", \\\"{x:559,y:771,t:1527614350852};\\\", \\\"{x:560,y:771,t:1527614350875};\\\", \\\"{x:560,y:772,t:1527614350886};\\\", \\\"{x:560,y:775,t:1527614350902};\\\", \\\"{x:559,y:779,t:1527614350920};\\\", \\\"{x:557,y:782,t:1527614350937};\\\", \\\"{x:553,y:789,t:1527614350953};\\\", \\\"{x:549,y:793,t:1527614350969};\\\", \\\"{x:547,y:798,t:1527614350986};\\\", \\\"{x:543,y:802,t:1527614351002};\\\", \\\"{x:540,y:808,t:1527614351020};\\\", \\\"{x:539,y:810,t:1527614351036};\\\", \\\"{x:538,y:812,t:1527614351052};\\\", \\\"{x:538,y:813,t:1527614351092};\\\", \\\"{x:538,y:814,t:1527614351106};\\\", \\\"{x:535,y:815,t:1527614351203};\\\", \\\"{x:534,y:814,t:1527614351219};\\\", \\\"{x:533,y:809,t:1527614351236};\\\", \\\"{x:533,y:805,t:1527614351252};\\\", \\\"{x:533,y:801,t:1527614351269};\\\", \\\"{x:533,y:800,t:1527614351287};\\\", \\\"{x:533,y:798,t:1527614351302};\\\", \\\"{x:533,y:797,t:1527614351323};\\\", \\\"{x:533,y:795,t:1527614351336};\\\", \\\"{x:533,y:793,t:1527614351353};\\\", \\\"{x:534,y:790,t:1527614351369};\\\", \\\"{x:536,y:783,t:1527614351386};\\\", \\\"{x:538,y:776,t:1527614351403};\\\", \\\"{x:538,y:773,t:1527614351420};\\\", \\\"{x:540,y:770,t:1527614351436};\\\", \\\"{x:540,y:768,t:1527614351453};\\\", \\\"{x:541,y:765,t:1527614351470};\\\", \\\"{x:543,y:757,t:1527614351486};\\\", \\\"{x:543,y:753,t:1527614351505};\\\", \\\"{x:543,y:747,t:1527614351519};\\\", \\\"{x:543,y:746,t:1527614351536};\\\", \\\"{x:543,y:744,t:1527614351604};\\\", \\\"{x:543,y:743,t:1527614351619};\\\" ] }, { \\\"rt\\\": 10501, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 16, \\\"time_elapsed\\\": 695893, \\\"internal_node_id\\\": \\\"0.0-6.0-6.0\\\", \\\"subject\\\": \\\"TGOML\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"oscar\\\", \\\"condition\\\": \\\"114\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"starts\\\", \\\"q\\\": 12, \\\"clicks\\\": 1, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XInside-YInside\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 1, \\\"answer\\\": [ \\\"B\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"\\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:540,y:735,t:1527614361452};\\\", \\\"{x:479,y:704,t:1527614361486};\\\", \\\"{x:459,y:697,t:1527614361491};\\\", \\\"{x:432,y:689,t:1527614361508};\\\", \\\"{x:411,y:680,t:1527614361529};\\\", \\\"{x:397,y:674,t:1527614361544};\\\", \\\"{x:391,y:671,t:1527614361561};\\\", \\\"{x:388,y:669,t:1527614361578};\\\", \\\"{x:384,y:666,t:1527614361594};\\\", \\\"{x:382,y:665,t:1527614361611};\\\", \\\"{x:376,y:660,t:1527614361628};\\\", \\\"{x:370,y:652,t:1527614361644};\\\", \\\"{x:368,y:646,t:1527614361661};\\\", \\\"{x:367,y:643,t:1527614361678};\\\", \\\"{x:366,y:637,t:1527614361695};\\\", \\\"{x:360,y:630,t:1527614361712};\\\", \\\"{x:354,y:623,t:1527614361727};\\\", \\\"{x:345,y:616,t:1527614361744};\\\", \\\"{x:337,y:610,t:1527614361761};\\\", \\\"{x:331,y:607,t:1527614361777};\\\", \\\"{x:327,y:603,t:1527614361794};\\\", \\\"{x:323,y:601,t:1527614361811};\\\", \\\"{x:318,y:599,t:1527614361828};\\\", \\\"{x:310,y:598,t:1527614361845};\\\", \\\"{x:298,y:595,t:1527614361861};\\\", \\\"{x:289,y:594,t:1527614361878};\\\", \\\"{x:281,y:594,t:1527614361895};\\\", \\\"{x:275,y:593,t:1527614361912};\\\", \\\"{x:271,y:591,t:1527614361929};\\\", \\\"{x:265,y:591,t:1527614361944};\\\", \\\"{x:255,y:591,t:1527614361961};\\\", \\\"{x:242,y:591,t:1527614361978};\\\", \\\"{x:228,y:591,t:1527614361995};\\\", \\\"{x:221,y:591,t:1527614362011};\\\", \\\"{x:216,y:591,t:1527614362028};\\\", \\\"{x:211,y:591,t:1527614362044};\\\", \\\"{x:203,y:591,t:1527614362061};\\\", \\\"{x:192,y:591,t:1527614362078};\\\", \\\"{x:182,y:591,t:1527614362095};\\\", \\\"{x:177,y:591,t:1527614362111};\\\", \\\"{x:175,y:591,t:1527614362128};\\\", \\\"{x:174,y:591,t:1527614362172};\\\", \\\"{x:174,y:590,t:1527614362179};\\\", \\\"{x:174,y:588,t:1527614362196};\\\", \\\"{x:173,y:584,t:1527614362213};\\\", \\\"{x:170,y:579,t:1527614362228};\\\", \\\"{x:169,y:575,t:1527614362245};\\\", \\\"{x:167,y:572,t:1527614362262};\\\", \\\"{x:167,y:569,t:1527614362278};\\\", \\\"{x:167,y:566,t:1527614362296};\\\", \\\"{x:167,y:564,t:1527614362311};\\\", \\\"{x:167,y:560,t:1527614362329};\\\", \\\"{x:166,y:557,t:1527614362345};\\\", \\\"{x:165,y:555,t:1527614362362};\\\", \\\"{x:164,y:553,t:1527614362379};\\\", \\\"{x:164,y:552,t:1527614362402};\\\", \\\"{x:164,y:551,t:1527614362419};\\\", \\\"{x:164,y:550,t:1527614362435};\\\", \\\"{x:164,y:549,t:1527614362466};\\\", \\\"{x:164,y:548,t:1527614362479};\\\", \\\"{x:163,y:547,t:1527614362514};\\\", \\\"{x:164,y:548,t:1527614362834};\\\", \\\"{x:171,y:557,t:1527614362845};\\\", \\\"{x:195,y:591,t:1527614362862};\\\", \\\"{x:231,y:632,t:1527614362880};\\\", \\\"{x:283,y:676,t:1527614362895};\\\", \\\"{x:361,y:713,t:1527614362912};\\\", \\\"{x:428,y:731,t:1527614362929};\\\", \\\"{x:497,y:749,t:1527614362946};\\\", \\\"{x:537,y:761,t:1527614362962};\\\", \\\"{x:555,y:765,t:1527614362979};\\\", \\\"{x:572,y:770,t:1527614362995};\\\", \\\"{x:581,y:772,t:1527614363012};\\\", \\\"{x:588,y:775,t:1527614363029};\\\", \\\"{x:589,y:775,t:1527614363046};\\\", \\\"{x:590,y:775,t:1527614363091};\\\", \\\"{x:590,y:771,t:1527614363099};\\\", \\\"{x:590,y:769,t:1527614363113};\\\", \\\"{x:590,y:764,t:1527614363130};\\\", \\\"{x:590,y:760,t:1527614363145};\\\", \\\"{x:590,y:757,t:1527614363163};\\\", \\\"{x:590,y:755,t:1527614363187};\\\", \\\"{x:588,y:754,t:1527614363195};\\\", \\\"{x:575,y:749,t:1527614363212};\\\", \\\"{x:558,y:744,t:1527614363230};\\\", \\\"{x:543,y:742,t:1527614363245};\\\", \\\"{x:531,y:739,t:1527614363262};\\\", \\\"{x:523,y:737,t:1527614363279};\\\", \\\"{x:520,y:735,t:1527614363296};\\\" ] }, { \\\"rt\\\": 18713, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 17, \\\"time_elapsed\\\": 715827, \\\"internal_node_id\\\": \\\"0.0-6.0-7.0\\\", \\\"subject\\\": \\\"TGOML\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"oscar\\\", \\\"condition\\\": \\\"114\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"meets\\\", \\\"q\\\": 13, \\\"clicks\\\": 2, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XInside-YInside\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 1, \\\"answer\\\": [ \\\"F\\\", \\\"X\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-Z \\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:523,y:735,t:1527614368612};\\\", \\\"{x:532,y:735,t:1527614368622};\\\", \\\"{x:548,y:734,t:1527614368638};\\\", \\\"{x:571,y:733,t:1527614368656};\\\", \\\"{x:597,y:733,t:1527614368672};\\\", \\\"{x:633,y:733,t:1527614368688};\\\", \\\"{x:699,y:733,t:1527614368700};\\\", \\\"{x:799,y:733,t:1527614368717};\\\", \\\"{x:915,y:733,t:1527614368734};\\\", \\\"{x:1035,y:733,t:1527614368750};\\\", \\\"{x:1137,y:733,t:1527614368768};\\\", \\\"{x:1220,y:733,t:1527614368783};\\\", \\\"{x:1293,y:733,t:1527614368800};\\\", \\\"{x:1343,y:727,t:1527614368818};\\\", \\\"{x:1385,y:727,t:1527614368833};\\\", \\\"{x:1424,y:725,t:1527614368850};\\\", \\\"{x:1434,y:723,t:1527614368867};\\\", \\\"{x:1440,y:723,t:1527614368884};\\\", \\\"{x:1449,y:723,t:1527614368901};\\\", \\\"{x:1466,y:719,t:1527614368917};\\\", \\\"{x:1490,y:715,t:1527614368934};\\\", \\\"{x:1512,y:714,t:1527614368952};\\\", \\\"{x:1532,y:714,t:1527614368968};\\\", \\\"{x:1543,y:714,t:1527614368984};\\\", \\\"{x:1546,y:714,t:1527614369000};\\\", \\\"{x:1547,y:714,t:1527614369018};\\\", \\\"{x:1548,y:714,t:1527614369070};\\\", \\\"{x:1549,y:714,t:1527614369099};\\\", \\\"{x:1551,y:714,t:1527614369106};\\\", \\\"{x:1552,y:712,t:1527614369162};\\\", \\\"{x:1553,y:712,t:1527614369171};\\\", \\\"{x:1555,y:712,t:1527614369184};\\\", \\\"{x:1562,y:708,t:1527614369201};\\\", \\\"{x:1566,y:707,t:1527614369217};\\\", \\\"{x:1570,y:706,t:1527614369234};\\\", \\\"{x:1573,y:706,t:1527614369250};\\\", \\\"{x:1573,y:705,t:1527614369268};\\\", \\\"{x:1576,y:704,t:1527614369299};\\\", \\\"{x:1579,y:704,t:1527614369307};\\\", \\\"{x:1583,y:704,t:1527614369318};\\\", \\\"{x:1596,y:699,t:1527614369335};\\\", \\\"{x:1604,y:698,t:1527614369352};\\\", \\\"{x:1609,y:695,t:1527614369370};\\\", \\\"{x:1610,y:695,t:1527614369385};\\\", \\\"{x:1611,y:695,t:1527614369459};\\\", \\\"{x:1612,y:695,t:1527614369468};\\\", \\\"{x:1614,y:695,t:1527614369491};\\\", \\\"{x:1615,y:695,t:1527614369502};\\\", \\\"{x:1615,y:694,t:1527614369523};\\\", \\\"{x:1614,y:694,t:1527614369804};\\\", \\\"{x:1613,y:693,t:1527614369819};\\\", \\\"{x:1612,y:693,t:1527614369835};\\\", \\\"{x:1611,y:693,t:1527614369867};\\\", \\\"{x:1610,y:693,t:1527614369900};\\\", \\\"{x:1609,y:693,t:1527614376101};\\\", \\\"{x:1601,y:693,t:1527614376109};\\\", \\\"{x:1584,y:693,t:1527614376126};\\\", \\\"{x:1571,y:693,t:1527614376142};\\\", \\\"{x:1559,y:693,t:1527614376159};\\\", \\\"{x:1545,y:694,t:1527614376176};\\\", \\\"{x:1531,y:695,t:1527614376193};\\\", \\\"{x:1520,y:695,t:1527614376209};\\\", \\\"{x:1505,y:695,t:1527614376227};\\\", \\\"{x:1490,y:695,t:1527614376243};\\\", \\\"{x:1470,y:698,t:1527614376259};\\\", \\\"{x:1452,y:699,t:1527614376276};\\\", \\\"{x:1431,y:699,t:1527614376293};\\\", \\\"{x:1408,y:704,t:1527614376309};\\\", \\\"{x:1386,y:706,t:1527614376326};\\\", \\\"{x:1367,y:710,t:1527614376344};\\\", \\\"{x:1348,y:711,t:1527614376359};\\\", \\\"{x:1326,y:713,t:1527614376377};\\\", \\\"{x:1309,y:717,t:1527614376394};\\\", \\\"{x:1291,y:719,t:1527614376409};\\\", \\\"{x:1278,y:720,t:1527614376426};\\\", \\\"{x:1255,y:722,t:1527614376443};\\\", \\\"{x:1238,y:726,t:1527614376460};\\\", \\\"{x:1223,y:729,t:1527614376476};\\\", \\\"{x:1208,y:731,t:1527614376493};\\\", \\\"{x:1189,y:732,t:1527614376510};\\\", \\\"{x:1165,y:734,t:1527614376526};\\\", \\\"{x:1141,y:734,t:1527614376544};\\\", \\\"{x:1113,y:734,t:1527614376560};\\\", \\\"{x:1085,y:736,t:1527614376576};\\\", \\\"{x:1061,y:736,t:1527614376593};\\\", \\\"{x:1033,y:736,t:1527614376610};\\\", \\\"{x:1001,y:738,t:1527614376627};\\\", \\\"{x:952,y:742,t:1527614376643};\\\", \\\"{x:925,y:742,t:1527614376660};\\\", \\\"{x:899,y:743,t:1527614376677};\\\", \\\"{x:875,y:749,t:1527614376694};\\\", \\\"{x:852,y:753,t:1527614376710};\\\", \\\"{x:831,y:760,t:1527614376727};\\\", \\\"{x:814,y:764,t:1527614376743};\\\", \\\"{x:800,y:768,t:1527614376760};\\\", \\\"{x:792,y:769,t:1527614376777};\\\", \\\"{x:787,y:771,t:1527614376794};\\\", \\\"{x:778,y:774,t:1527614376811};\\\", \\\"{x:764,y:778,t:1527614376827};\\\", \\\"{x:744,y:784,t:1527614376844};\\\", \\\"{x:721,y:788,t:1527614376860};\\\", \\\"{x:709,y:788,t:1527614376877};\\\", \\\"{x:708,y:788,t:1527614377796};\\\", \\\"{x:704,y:788,t:1527614377811};\\\", \\\"{x:703,y:788,t:1527614377829};\\\", \\\"{x:700,y:788,t:1527614377845};\\\", \\\"{x:700,y:786,t:1527614377861};\\\", \\\"{x:699,y:785,t:1527614377878};\\\", \\\"{x:699,y:781,t:1527614377894};\\\", \\\"{x:697,y:778,t:1527614377911};\\\", \\\"{x:694,y:775,t:1527614377928};\\\", \\\"{x:677,y:769,t:1527614377946};\\\", \\\"{x:669,y:768,t:1527614377962};\\\", \\\"{x:645,y:762,t:1527614377979};\\\", \\\"{x:594,y:752,t:1527614377995};\\\", \\\"{x:550,y:741,t:1527614378013};\\\", \\\"{x:497,y:734,t:1527614378028};\\\", \\\"{x:441,y:726,t:1527614378045};\\\", \\\"{x:395,y:715,t:1527614378058};\\\", \\\"{x:372,y:707,t:1527614378074};\\\", \\\"{x:358,y:703,t:1527614378091};\\\", \\\"{x:355,y:702,t:1527614378108};\\\", \\\"{x:353,y:700,t:1527614378125};\\\", \\\"{x:349,y:697,t:1527614378141};\\\", \\\"{x:343,y:692,t:1527614378158};\\\", \\\"{x:334,y:687,t:1527614378175};\\\", \\\"{x:326,y:682,t:1527614378191};\\\", \\\"{x:318,y:677,t:1527614378207};\\\", \\\"{x:303,y:670,t:1527614378225};\\\", \\\"{x:283,y:662,t:1527614378242};\\\", \\\"{x:261,y:657,t:1527614378259};\\\", \\\"{x:250,y:653,t:1527614378274};\\\", \\\"{x:238,y:648,t:1527614378291};\\\", \\\"{x:234,y:647,t:1527614378308};\\\", \\\"{x:232,y:646,t:1527614378324};\\\", \\\"{x:229,y:641,t:1527614378341};\\\", \\\"{x:224,y:629,t:1527614378359};\\\", \\\"{x:219,y:617,t:1527614378373};\\\", \\\"{x:215,y:609,t:1527614378392};\\\", \\\"{x:214,y:606,t:1527614378408};\\\", \\\"{x:213,y:604,t:1527614378426};\\\", \\\"{x:212,y:602,t:1527614378442};\\\", \\\"{x:211,y:602,t:1527614378458};\\\", \\\"{x:209,y:599,t:1527614378475};\\\", \\\"{x:208,y:599,t:1527614378492};\\\", \\\"{x:205,y:597,t:1527614378508};\\\", \\\"{x:201,y:596,t:1527614378525};\\\", \\\"{x:189,y:596,t:1527614378542};\\\", \\\"{x:167,y:596,t:1527614378558};\\\", \\\"{x:145,y:596,t:1527614378574};\\\", \\\"{x:123,y:596,t:1527614378591};\\\", \\\"{x:108,y:596,t:1527614378608};\\\", \\\"{x:103,y:596,t:1527614378625};\\\", \\\"{x:102,y:596,t:1527614378650};\\\", \\\"{x:100,y:598,t:1527614378659};\\\", \\\"{x:100,y:604,t:1527614378676};\\\", \\\"{x:100,y:612,t:1527614378692};\\\", \\\"{x:103,y:619,t:1527614378709};\\\", \\\"{x:106,y:624,t:1527614378725};\\\", \\\"{x:109,y:627,t:1527614378742};\\\", \\\"{x:112,y:630,t:1527614378759};\\\", \\\"{x:116,y:633,t:1527614378777};\\\", \\\"{x:117,y:634,t:1527614378792};\\\", \\\"{x:119,y:634,t:1527614378809};\\\", \\\"{x:124,y:635,t:1527614378825};\\\", \\\"{x:134,y:635,t:1527614378842};\\\", \\\"{x:162,y:625,t:1527614378860};\\\", \\\"{x:185,y:614,t:1527614378874};\\\", \\\"{x:208,y:605,t:1527614378892};\\\", \\\"{x:230,y:597,t:1527614378909};\\\", \\\"{x:250,y:591,t:1527614378926};\\\", \\\"{x:264,y:588,t:1527614378942};\\\", \\\"{x:272,y:587,t:1527614378959};\\\", \\\"{x:274,y:587,t:1527614379003};\\\", \\\"{x:275,y:587,t:1527614379009};\\\", \\\"{x:277,y:587,t:1527614379042};\\\", \\\"{x:278,y:588,t:1527614379082};\\\", \\\"{x:283,y:591,t:1527614379092};\\\", \\\"{x:292,y:597,t:1527614379110};\\\", \\\"{x:303,y:604,t:1527614379126};\\\", \\\"{x:319,y:609,t:1527614379141};\\\", \\\"{x:337,y:611,t:1527614379158};\\\", \\\"{x:352,y:612,t:1527614379176};\\\", \\\"{x:365,y:615,t:1527614379192};\\\", \\\"{x:372,y:615,t:1527614379209};\\\", \\\"{x:379,y:615,t:1527614379226};\\\", \\\"{x:383,y:615,t:1527614379242};\\\", \\\"{x:398,y:609,t:1527614379259};\\\", \\\"{x:414,y:603,t:1527614379276};\\\", \\\"{x:434,y:598,t:1527614379293};\\\", \\\"{x:453,y:595,t:1527614379309};\\\", \\\"{x:471,y:592,t:1527614379326};\\\", \\\"{x:483,y:588,t:1527614379342};\\\", \\\"{x:490,y:586,t:1527614379359};\\\", \\\"{x:496,y:584,t:1527614379376};\\\", \\\"{x:511,y:582,t:1527614379395};\\\", \\\"{x:532,y:579,t:1527614379409};\\\", \\\"{x:553,y:575,t:1527614379426};\\\", \\\"{x:580,y:572,t:1527614379443};\\\", \\\"{x:593,y:572,t:1527614379459};\\\", \\\"{x:603,y:570,t:1527614379477};\\\", \\\"{x:608,y:568,t:1527614379493};\\\", \\\"{x:611,y:568,t:1527614379509};\\\", \\\"{x:615,y:568,t:1527614379526};\\\", \\\"{x:626,y:568,t:1527614379543};\\\", \\\"{x:638,y:568,t:1527614379558};\\\", \\\"{x:653,y:568,t:1527614379577};\\\", \\\"{x:669,y:568,t:1527614379593};\\\", \\\"{x:674,y:567,t:1527614379608};\\\", \\\"{x:676,y:566,t:1527614379626};\\\", \\\"{x:676,y:565,t:1527614379651};\\\", \\\"{x:676,y:563,t:1527614379666};\\\", \\\"{x:676,y:562,t:1527614379708};\\\", \\\"{x:674,y:562,t:1527614379726};\\\", \\\"{x:669,y:559,t:1527614379743};\\\", \\\"{x:660,y:558,t:1527614379760};\\\", \\\"{x:645,y:558,t:1527614379776};\\\", \\\"{x:631,y:558,t:1527614379793};\\\", \\\"{x:612,y:564,t:1527614379810};\\\", \\\"{x:606,y:565,t:1527614379826};\\\", \\\"{x:604,y:565,t:1527614379843};\\\", \\\"{x:603,y:566,t:1527614379874};\\\", \\\"{x:603,y:567,t:1527614379955};\\\", \\\"{x:603,y:568,t:1527614379962};\\\", \\\"{x:603,y:570,t:1527614380028};\\\", \\\"{x:604,y:571,t:1527614380043};\\\", \\\"{x:605,y:572,t:1527614380060};\\\", \\\"{x:606,y:572,t:1527614380106};\\\", \\\"{x:605,y:572,t:1527614380426};\\\", \\\"{x:593,y:574,t:1527614380443};\\\", \\\"{x:579,y:576,t:1527614380460};\\\", \\\"{x:565,y:581,t:1527614380477};\\\", \\\"{x:543,y:585,t:1527614380492};\\\", \\\"{x:518,y:587,t:1527614380510};\\\", \\\"{x:489,y:587,t:1527614380528};\\\", \\\"{x:456,y:587,t:1527614380543};\\\", \\\"{x:421,y:587,t:1527614380560};\\\", \\\"{x:390,y:587,t:1527614380577};\\\", \\\"{x:372,y:587,t:1527614380594};\\\", \\\"{x:360,y:587,t:1527614380610};\\\", \\\"{x:359,y:587,t:1527614380691};\\\", \\\"{x:357,y:587,t:1527614380698};\\\", \\\"{x:353,y:587,t:1527614380714};\\\", \\\"{x:350,y:587,t:1527614380727};\\\", \\\"{x:339,y:587,t:1527614380744};\\\", \\\"{x:323,y:587,t:1527614380760};\\\", \\\"{x:308,y:587,t:1527614380777};\\\", \\\"{x:283,y:587,t:1527614380794};\\\", \\\"{x:273,y:587,t:1527614380810};\\\", \\\"{x:259,y:587,t:1527614380828};\\\", \\\"{x:254,y:587,t:1527614380844};\\\", \\\"{x:252,y:587,t:1527614380860};\\\", \\\"{x:251,y:587,t:1527614380877};\\\", \\\"{x:249,y:587,t:1527614380894};\\\", \\\"{x:247,y:588,t:1527614380910};\\\", \\\"{x:242,y:591,t:1527614380927};\\\", \\\"{x:238,y:594,t:1527614380944};\\\", \\\"{x:236,y:596,t:1527614380960};\\\", \\\"{x:234,y:602,t:1527614380978};\\\", \\\"{x:233,y:615,t:1527614380994};\\\", \\\"{x:233,y:623,t:1527614381010};\\\", \\\"{x:236,y:632,t:1527614381028};\\\", \\\"{x:245,y:641,t:1527614381045};\\\", \\\"{x:253,y:650,t:1527614381060};\\\", \\\"{x:263,y:656,t:1527614381077};\\\", \\\"{x:268,y:659,t:1527614381094};\\\", \\\"{x:270,y:660,t:1527614381110};\\\", \\\"{x:272,y:660,t:1527614381131};\\\", \\\"{x:273,y:660,t:1527614381145};\\\", \\\"{x:283,y:661,t:1527614381161};\\\", \\\"{x:302,y:664,t:1527614381177};\\\", \\\"{x:346,y:666,t:1527614381194};\\\", \\\"{x:376,y:666,t:1527614381210};\\\", \\\"{x:403,y:666,t:1527614381227};\\\", \\\"{x:425,y:662,t:1527614381244};\\\", \\\"{x:450,y:656,t:1527614381261};\\\", \\\"{x:480,y:650,t:1527614381277};\\\", \\\"{x:527,y:640,t:1527614381296};\\\", \\\"{x:570,y:629,t:1527614381311};\\\", \\\"{x:604,y:620,t:1527614381327};\\\", \\\"{x:627,y:614,t:1527614381344};\\\", \\\"{x:648,y:609,t:1527614381361};\\\", \\\"{x:666,y:606,t:1527614381377};\\\", \\\"{x:691,y:604,t:1527614381394};\\\", \\\"{x:703,y:600,t:1527614381411};\\\", \\\"{x:713,y:597,t:1527614381428};\\\", \\\"{x:719,y:596,t:1527614381443};\\\", \\\"{x:724,y:593,t:1527614381461};\\\", \\\"{x:728,y:592,t:1527614381477};\\\", \\\"{x:732,y:591,t:1527614381494};\\\", \\\"{x:735,y:590,t:1527614381510};\\\", \\\"{x:739,y:588,t:1527614381528};\\\", \\\"{x:741,y:585,t:1527614381544};\\\", \\\"{x:743,y:584,t:1527614381561};\\\", \\\"{x:750,y:577,t:1527614381578};\\\", \\\"{x:751,y:574,t:1527614381594};\\\", \\\"{x:758,y:562,t:1527614381612};\\\", \\\"{x:764,y:554,t:1527614381628};\\\", \\\"{x:769,y:548,t:1527614381643};\\\", \\\"{x:779,y:538,t:1527614381661};\\\", \\\"{x:789,y:530,t:1527614381678};\\\", \\\"{x:799,y:519,t:1527614381694};\\\", \\\"{x:806,y:511,t:1527614381712};\\\", \\\"{x:811,y:503,t:1527614381728};\\\", \\\"{x:813,y:499,t:1527614381744};\\\", \\\"{x:814,y:498,t:1527614381761};\\\", \\\"{x:816,y:496,t:1527614381778};\\\", \\\"{x:817,y:495,t:1527614381794};\\\", \\\"{x:818,y:495,t:1527614381915};\\\", \\\"{x:820,y:495,t:1527614381929};\\\", \\\"{x:825,y:496,t:1527614381945};\\\", \\\"{x:832,y:497,t:1527614381962};\\\", \\\"{x:849,y:498,t:1527614381978};\\\", \\\"{x:856,y:498,t:1527614381994};\\\", \\\"{x:857,y:498,t:1527614382011};\\\", \\\"{x:858,y:498,t:1527614382028};\\\", \\\"{x:857,y:498,t:1527614382122};\\\", \\\"{x:855,y:498,t:1527614382131};\\\", \\\"{x:852,y:498,t:1527614382148};\\\", \\\"{x:849,y:498,t:1527614382161};\\\", \\\"{x:846,y:498,t:1527614382179};\\\", \\\"{x:845,y:498,t:1527614382195};\\\", \\\"{x:842,y:501,t:1527614382498};\\\", \\\"{x:838,y:506,t:1527614382511};\\\", \\\"{x:822,y:525,t:1527614382528};\\\", \\\"{x:801,y:555,t:1527614382545};\\\", \\\"{x:761,y:609,t:1527614382562};\\\", \\\"{x:735,y:640,t:1527614382578};\\\", \\\"{x:705,y:662,t:1527614382595};\\\", \\\"{x:671,y:685,t:1527614382612};\\\", \\\"{x:634,y:705,t:1527614382628};\\\", \\\"{x:608,y:717,t:1527614382645};\\\", \\\"{x:589,y:726,t:1527614382662};\\\", \\\"{x:580,y:732,t:1527614382679};\\\", \\\"{x:578,y:733,t:1527614382695};\\\", \\\"{x:577,y:733,t:1527614382771};\\\", \\\"{x:576,y:733,t:1527614382778};\\\", \\\"{x:567,y:724,t:1527614382796};\\\", \\\"{x:562,y:715,t:1527614382813};\\\", \\\"{x:558,y:712,t:1527614382830};\\\", \\\"{x:556,y:711,t:1527614382846};\\\", \\\"{x:554,y:711,t:1527614382971};\\\", \\\"{x:554,y:714,t:1527614382979};\\\", \\\"{x:552,y:722,t:1527614382997};\\\", \\\"{x:551,y:728,t:1527614383012};\\\", \\\"{x:550,y:732,t:1527614383029};\\\", \\\"{x:550,y:734,t:1527614383045};\\\", \\\"{x:549,y:736,t:1527614383062};\\\", \\\"{x:548,y:737,t:1527614383078};\\\", \\\"{x:547,y:738,t:1527614383122};\\\", \\\"{x:547,y:739,t:1527614383163};\\\", \\\"{x:545,y:741,t:1527614383179};\\\", \\\"{x:544,y:743,t:1527614383226};\\\", \\\"{x:543,y:745,t:1527614383258};\\\", \\\"{x:542,y:745,t:1527614383283};\\\" ] }, { \\\"rt\\\": 48926, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 18, \\\"time_elapsed\\\": 765970, \\\"internal_node_id\\\": \\\"0.0-6.0-8.0\\\", \\\"subject\\\": \\\"TGOML\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"oscar\\\", \\\"condition\\\": \\\"114\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"endtime\\\", \\\"q\\\": 14, \\\"clicks\\\": 1, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XInside-YInside\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 1, \\\"answer\\\": [ \\\"B\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-4-O -03 PM-O \\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:544,y:745,t:1527614387391};\\\", \\\"{x:548,y:744,t:1527614387404};\\\", \\\"{x:555,y:742,t:1527614387420};\\\", \\\"{x:558,y:742,t:1527614387437};\\\", \\\"{x:561,y:740,t:1527614387454};\\\", \\\"{x:569,y:739,t:1527614387472};\\\", \\\"{x:608,y:738,t:1527614387486};\\\", \\\"{x:671,y:730,t:1527614387509};\\\", \\\"{x:757,y:719,t:1527614387521};\\\", \\\"{x:846,y:706,t:1527614387536};\\\", \\\"{x:923,y:701,t:1527614387553};\\\", \\\"{x:1000,y:694,t:1527614387571};\\\", \\\"{x:1059,y:692,t:1527614387586};\\\", \\\"{x:1123,y:692,t:1527614387604};\\\", \\\"{x:1170,y:692,t:1527614387621};\\\", \\\"{x:1210,y:692,t:1527614387636};\\\", \\\"{x:1240,y:692,t:1527614387653};\\\", \\\"{x:1293,y:692,t:1527614387670};\\\", \\\"{x:1332,y:692,t:1527614387687};\\\", \\\"{x:1375,y:692,t:1527614387704};\\\", \\\"{x:1419,y:697,t:1527614387721};\\\", \\\"{x:1462,y:704,t:1527614387736};\\\", \\\"{x:1486,y:714,t:1527614387754};\\\", \\\"{x:1501,y:717,t:1527614387771};\\\", \\\"{x:1510,y:725,t:1527614387787};\\\", \\\"{x:1511,y:728,t:1527614388103};\\\", \\\"{x:1512,y:733,t:1527614388121};\\\", \\\"{x:1516,y:747,t:1527614388138};\\\", \\\"{x:1526,y:767,t:1527614388155};\\\", \\\"{x:1543,y:789,t:1527614388171};\\\", \\\"{x:1551,y:810,t:1527614388188};\\\", \\\"{x:1560,y:821,t:1527614388204};\\\", \\\"{x:1564,y:829,t:1527614388221};\\\", \\\"{x:1565,y:833,t:1527614388238};\\\", \\\"{x:1566,y:835,t:1527614388254};\\\", \\\"{x:1567,y:836,t:1527614388271};\\\", \\\"{x:1569,y:840,t:1527614388288};\\\", \\\"{x:1576,y:846,t:1527614388305};\\\", \\\"{x:1580,y:857,t:1527614388321};\\\", \\\"{x:1580,y:858,t:1527614388338};\\\", \\\"{x:1581,y:859,t:1527614388355};\\\", \\\"{x:1581,y:860,t:1527614388375};\\\", \\\"{x:1581,y:865,t:1527614388407};\\\", \\\"{x:1579,y:871,t:1527614388421};\\\", \\\"{x:1573,y:884,t:1527614388438};\\\", \\\"{x:1561,y:907,t:1527614388455};\\\", \\\"{x:1556,y:916,t:1527614388471};\\\", \\\"{x:1553,y:925,t:1527614388488};\\\", \\\"{x:1548,y:933,t:1527614388505};\\\", \\\"{x:1547,y:937,t:1527614388521};\\\", \\\"{x:1545,y:940,t:1527614388538};\\\", \\\"{x:1545,y:944,t:1527614388555};\\\", \\\"{x:1545,y:950,t:1527614388571};\\\", \\\"{x:1545,y:957,t:1527614388589};\\\", \\\"{x:1545,y:964,t:1527614388606};\\\", \\\"{x:1545,y:968,t:1527614388621};\\\", \\\"{x:1546,y:969,t:1527614388680};\\\", \\\"{x:1547,y:969,t:1527614388792};\\\", \\\"{x:1548,y:969,t:1527614388807};\\\", \\\"{x:1549,y:967,t:1527614388824};\\\", \\\"{x:1549,y:966,t:1527614388838};\\\", \\\"{x:1549,y:961,t:1527614388855};\\\", \\\"{x:1549,y:955,t:1527614388872};\\\", \\\"{x:1548,y:950,t:1527614388888};\\\", \\\"{x:1548,y:942,t:1527614388905};\\\", \\\"{x:1548,y:935,t:1527614388922};\\\", \\\"{x:1548,y:931,t:1527614388938};\\\", \\\"{x:1547,y:924,t:1527614388955};\\\", \\\"{x:1547,y:915,t:1527614388972};\\\", \\\"{x:1547,y:908,t:1527614388988};\\\", \\\"{x:1547,y:902,t:1527614389005};\\\", \\\"{x:1547,y:896,t:1527614389023};\\\", \\\"{x:1547,y:893,t:1527614389039};\\\", \\\"{x:1545,y:889,t:1527614389055};\\\", \\\"{x:1544,y:884,t:1527614389072};\\\", \\\"{x:1544,y:880,t:1527614389088};\\\", \\\"{x:1544,y:874,t:1527614389105};\\\", \\\"{x:1543,y:869,t:1527614389121};\\\", \\\"{x:1541,y:864,t:1527614389138};\\\", \\\"{x:1541,y:862,t:1527614389155};\\\", \\\"{x:1541,y:859,t:1527614389171};\\\", \\\"{x:1541,y:854,t:1527614389188};\\\", \\\"{x:1540,y:846,t:1527614389205};\\\", \\\"{x:1539,y:838,t:1527614389221};\\\", \\\"{x:1539,y:829,t:1527614389238};\\\", \\\"{x:1537,y:823,t:1527614389255};\\\", \\\"{x:1537,y:821,t:1527614389272};\\\", \\\"{x:1537,y:818,t:1527614389288};\\\", \\\"{x:1537,y:812,t:1527614389304};\\\", \\\"{x:1537,y:805,t:1527614389322};\\\", \\\"{x:1537,y:796,t:1527614389338};\\\", \\\"{x:1537,y:790,t:1527614389355};\\\", \\\"{x:1537,y:786,t:1527614389371};\\\", \\\"{x:1537,y:783,t:1527614389388};\\\", \\\"{x:1537,y:779,t:1527614389405};\\\", \\\"{x:1536,y:775,t:1527614389422};\\\", \\\"{x:1536,y:770,t:1527614389439};\\\", \\\"{x:1536,y:767,t:1527614389455};\\\", \\\"{x:1536,y:766,t:1527614389472};\\\", \\\"{x:1535,y:766,t:1527614389489};\\\", \\\"{x:1535,y:765,t:1527614389536};\\\", \\\"{x:1535,y:764,t:1527614389559};\\\", \\\"{x:1535,y:763,t:1527614389572};\\\", \\\"{x:1535,y:762,t:1527614389589};\\\", \\\"{x:1537,y:760,t:1527614389606};\\\", \\\"{x:1538,y:759,t:1527614389623};\\\", \\\"{x:1540,y:758,t:1527614389639};\\\", \\\"{x:1542,y:757,t:1527614389656};\\\", \\\"{x:1543,y:757,t:1527614389672};\\\", \\\"{x:1545,y:757,t:1527614389743};\\\", \\\"{x:1546,y:757,t:1527614389775};\\\", \\\"{x:1547,y:757,t:1527614389830};\\\", \\\"{x:1548,y:757,t:1527614389838};\\\", \\\"{x:1549,y:757,t:1527614389855};\\\", \\\"{x:1550,y:758,t:1527614390031};\\\", \\\"{x:1550,y:759,t:1527614390054};\\\", \\\"{x:1550,y:760,t:1527614390150};\\\", \\\"{x:1550,y:762,t:1527614390239};\\\", \\\"{x:1550,y:764,t:1527614390256};\\\", \\\"{x:1550,y:765,t:1527614390273};\\\", \\\"{x:1550,y:766,t:1527614390294};\\\", \\\"{x:1550,y:768,t:1527614390390};\\\", \\\"{x:1551,y:769,t:1527614390430};\\\", \\\"{x:1551,y:768,t:1527614391030};\\\", \\\"{x:1551,y:767,t:1527614391046};\\\", \\\"{x:1551,y:766,t:1527614391062};\\\", \\\"{x:1551,y:764,t:1527614391590};\\\", \\\"{x:1550,y:763,t:1527614391631};\\\", \\\"{x:1550,y:762,t:1527614391654};\\\", \\\"{x:1549,y:762,t:1527614391718};\\\", \\\"{x:1548,y:761,t:1527614391726};\\\", \\\"{x:1549,y:761,t:1527614394622};\\\", \\\"{x:1547,y:762,t:1527614396454};\\\", \\\"{x:1538,y:765,t:1527614396462};\\\", \\\"{x:1529,y:766,t:1527614396476};\\\", \\\"{x:1502,y:771,t:1527614396494};\\\", \\\"{x:1492,y:773,t:1527614396510};\\\", \\\"{x:1489,y:773,t:1527614396527};\\\", \\\"{x:1488,y:773,t:1527614396543};\\\", \\\"{x:1486,y:773,t:1527614396582};\\\", \\\"{x:1485,y:773,t:1527614396594};\\\", \\\"{x:1475,y:772,t:1527614396610};\\\", \\\"{x:1463,y:770,t:1527614396627};\\\", \\\"{x:1460,y:769,t:1527614396643};\\\", \\\"{x:1459,y:768,t:1527614396694};\\\", \\\"{x:1458,y:768,t:1527614396711};\\\", \\\"{x:1456,y:768,t:1527614396733};\\\", \\\"{x:1455,y:768,t:1527614396744};\\\", \\\"{x:1453,y:768,t:1527614396766};\\\", \\\"{x:1453,y:767,t:1527614396814};\\\", \\\"{x:1452,y:767,t:1527614396830};\\\", \\\"{x:1450,y:767,t:1527614396844};\\\", \\\"{x:1446,y:767,t:1527614396860};\\\", \\\"{x:1439,y:767,t:1527614396878};\\\", \\\"{x:1437,y:766,t:1527614396893};\\\", \\\"{x:1435,y:766,t:1527614396910};\\\", \\\"{x:1434,y:765,t:1527614396933};\\\", \\\"{x:1433,y:765,t:1527614396943};\\\", \\\"{x:1430,y:765,t:1527614396961};\\\", \\\"{x:1423,y:764,t:1527614396978};\\\", \\\"{x:1417,y:764,t:1527614396995};\\\", \\\"{x:1414,y:762,t:1527614397011};\\\", \\\"{x:1413,y:762,t:1527614397028};\\\", \\\"{x:1412,y:762,t:1527614397086};\\\", \\\"{x:1411,y:762,t:1527614397110};\\\", \\\"{x:1410,y:761,t:1527614397142};\\\", \\\"{x:1410,y:760,t:1527614397182};\\\", \\\"{x:1410,y:759,t:1527614397198};\\\", \\\"{x:1411,y:759,t:1527614397782};\\\", \\\"{x:1412,y:760,t:1527614397798};\\\", \\\"{x:1413,y:762,t:1527614398110};\\\", \\\"{x:1414,y:764,t:1527614398118};\\\", \\\"{x:1415,y:765,t:1527614398129};\\\", \\\"{x:1416,y:769,t:1527614398144};\\\", \\\"{x:1417,y:772,t:1527614398162};\\\", \\\"{x:1420,y:776,t:1527614398179};\\\", \\\"{x:1421,y:778,t:1527614398195};\\\", \\\"{x:1423,y:781,t:1527614398212};\\\", \\\"{x:1424,y:781,t:1527614398229};\\\", \\\"{x:1426,y:782,t:1527614398244};\\\", \\\"{x:1429,y:783,t:1527614398261};\\\", \\\"{x:1436,y:783,t:1527614398278};\\\", \\\"{x:1446,y:785,t:1527614398296};\\\", \\\"{x:1457,y:786,t:1527614398312};\\\", \\\"{x:1470,y:788,t:1527614398329};\\\", \\\"{x:1479,y:788,t:1527614398345};\\\", \\\"{x:1483,y:788,t:1527614398362};\\\", \\\"{x:1485,y:788,t:1527614398381};\\\", \\\"{x:1486,y:787,t:1527614398397};\\\", \\\"{x:1486,y:785,t:1527614398411};\\\", \\\"{x:1488,y:783,t:1527614398428};\\\", \\\"{x:1490,y:780,t:1527614398446};\\\", \\\"{x:1490,y:779,t:1527614398461};\\\", \\\"{x:1490,y:778,t:1527614398502};\\\", \\\"{x:1490,y:777,t:1527614398512};\\\", \\\"{x:1490,y:776,t:1527614398528};\\\", \\\"{x:1490,y:774,t:1527614398546};\\\", \\\"{x:1490,y:773,t:1527614398561};\\\", \\\"{x:1490,y:772,t:1527614398578};\\\", \\\"{x:1489,y:770,t:1527614398596};\\\", \\\"{x:1489,y:769,t:1527614398612};\\\", \\\"{x:1488,y:767,t:1527614398629};\\\", \\\"{x:1486,y:765,t:1527614398646};\\\", \\\"{x:1485,y:763,t:1527614398662};\\\", \\\"{x:1484,y:762,t:1527614398694};\\\", \\\"{x:1483,y:760,t:1527614398710};\\\", \\\"{x:1482,y:760,t:1527614398734};\\\", \\\"{x:1482,y:759,t:1527614398750};\\\", \\\"{x:1482,y:758,t:1527614398774};\\\", \\\"{x:1481,y:757,t:1527614398798};\\\", \\\"{x:1482,y:761,t:1527614398926};\\\", \\\"{x:1484,y:763,t:1527614398934};\\\", \\\"{x:1484,y:764,t:1527614398946};\\\", \\\"{x:1486,y:766,t:1527614398962};\\\", \\\"{x:1487,y:768,t:1527614398979};\\\", \\\"{x:1487,y:769,t:1527614398995};\\\", \\\"{x:1489,y:771,t:1527614399013};\\\", \\\"{x:1494,y:772,t:1527614399028};\\\", \\\"{x:1502,y:774,t:1527614399046};\\\", \\\"{x:1507,y:774,t:1527614399063};\\\", \\\"{x:1512,y:775,t:1527614399079};\\\", \\\"{x:1516,y:775,t:1527614399096};\\\", \\\"{x:1520,y:775,t:1527614399113};\\\", \\\"{x:1524,y:775,t:1527614399130};\\\", \\\"{x:1527,y:775,t:1527614399146};\\\", \\\"{x:1530,y:775,t:1527614399163};\\\", \\\"{x:1532,y:774,t:1527614399180};\\\", \\\"{x:1537,y:772,t:1527614399195};\\\", \\\"{x:1540,y:770,t:1527614399213};\\\", \\\"{x:1542,y:768,t:1527614399230};\\\", \\\"{x:1543,y:768,t:1527614399245};\\\", \\\"{x:1544,y:766,t:1527614399263};\\\", \\\"{x:1546,y:763,t:1527614399286};\\\", \\\"{x:1547,y:760,t:1527614399302};\\\", \\\"{x:1548,y:759,t:1527614399312};\\\", \\\"{x:1549,y:759,t:1527614399750};\\\", \\\"{x:1550,y:759,t:1527614399782};\\\", \\\"{x:1546,y:759,t:1527614400478};\\\", \\\"{x:1533,y:761,t:1527614400486};\\\", \\\"{x:1519,y:764,t:1527614400498};\\\", \\\"{x:1487,y:772,t:1527614400514};\\\", \\\"{x:1439,y:781,t:1527614400531};\\\", \\\"{x:1377,y:789,t:1527614400547};\\\", \\\"{x:1278,y:789,t:1527614400564};\\\", \\\"{x:1153,y:789,t:1527614400581};\\\", \\\"{x:1004,y:789,t:1527614400597};\\\", \\\"{x:768,y:784,t:1527614400615};\\\", \\\"{x:643,y:784,t:1527614400630};\\\", \\\"{x:537,y:768,t:1527614400647};\\\", \\\"{x:462,y:757,t:1527614400664};\\\", \\\"{x:422,y:745,t:1527614400682};\\\", \\\"{x:404,y:738,t:1527614400698};\\\", \\\"{x:398,y:734,t:1527614400714};\\\", \\\"{x:396,y:731,t:1527614400731};\\\", \\\"{x:396,y:729,t:1527614400748};\\\", \\\"{x:395,y:724,t:1527614400764};\\\", \\\"{x:392,y:720,t:1527614400781};\\\", \\\"{x:391,y:716,t:1527614400798};\\\", \\\"{x:388,y:707,t:1527614400814};\\\", \\\"{x:382,y:692,t:1527614400831};\\\", \\\"{x:376,y:681,t:1527614400847};\\\", \\\"{x:371,y:673,t:1527614400864};\\\", \\\"{x:362,y:662,t:1527614400882};\\\", \\\"{x:357,y:657,t:1527614400897};\\\", \\\"{x:355,y:652,t:1527614400914};\\\", \\\"{x:351,y:643,t:1527614400930};\\\", \\\"{x:346,y:633,t:1527614400948};\\\", \\\"{x:333,y:620,t:1527614400964};\\\", \\\"{x:314,y:610,t:1527614400980};\\\", \\\"{x:294,y:601,t:1527614400997};\\\", \\\"{x:288,y:600,t:1527614401014};\\\", \\\"{x:283,y:598,t:1527614401031};\\\", \\\"{x:281,y:598,t:1527614401239};\\\", \\\"{x:275,y:597,t:1527614401248};\\\", \\\"{x:258,y:595,t:1527614401265};\\\", \\\"{x:244,y:591,t:1527614401282};\\\", \\\"{x:233,y:586,t:1527614401298};\\\", \\\"{x:225,y:580,t:1527614401314};\\\", \\\"{x:220,y:576,t:1527614401331};\\\", \\\"{x:217,y:573,t:1527614401348};\\\", \\\"{x:215,y:571,t:1527614401364};\\\", \\\"{x:213,y:570,t:1527614401381};\\\", \\\"{x:212,y:569,t:1527614401397};\\\", \\\"{x:209,y:568,t:1527614401415};\\\", \\\"{x:208,y:567,t:1527614401431};\\\", \\\"{x:203,y:563,t:1527614401447};\\\", \\\"{x:195,y:558,t:1527614401466};\\\", \\\"{x:182,y:550,t:1527614401483};\\\", \\\"{x:171,y:545,t:1527614401498};\\\", \\\"{x:164,y:543,t:1527614401515};\\\", \\\"{x:160,y:541,t:1527614401532};\\\", \\\"{x:158,y:541,t:1527614401548};\\\", \\\"{x:157,y:541,t:1527614401565};\\\", \\\"{x:159,y:541,t:1527614402030};\\\", \\\"{x:164,y:541,t:1527614402038};\\\", \\\"{x:167,y:541,t:1527614402049};\\\", \\\"{x:180,y:541,t:1527614402065};\\\", \\\"{x:197,y:541,t:1527614402083};\\\", \\\"{x:232,y:541,t:1527614402099};\\\", \\\"{x:280,y:541,t:1527614402116};\\\", \\\"{x:338,y:541,t:1527614402131};\\\", \\\"{x:436,y:541,t:1527614402149};\\\", \\\"{x:552,y:541,t:1527614402167};\\\", \\\"{x:738,y:544,t:1527614402184};\\\", \\\"{x:845,y:554,t:1527614402199};\\\", \\\"{x:929,y:565,t:1527614402215};\\\", \\\"{x:1010,y:580,t:1527614402233};\\\", \\\"{x:1088,y:592,t:1527614402249};\\\", \\\"{x:1160,y:612,t:1527614402265};\\\", \\\"{x:1238,y:634,t:1527614402282};\\\", \\\"{x:1283,y:658,t:1527614402299};\\\", \\\"{x:1321,y:678,t:1527614402316};\\\", \\\"{x:1341,y:691,t:1527614402332};\\\", \\\"{x:1357,y:701,t:1527614402349};\\\", \\\"{x:1371,y:712,t:1527614402366};\\\", \\\"{x:1375,y:716,t:1527614402382};\\\", \\\"{x:1378,y:722,t:1527614402399};\\\", \\\"{x:1386,y:738,t:1527614402416};\\\", \\\"{x:1395,y:752,t:1527614402432};\\\", \\\"{x:1404,y:767,t:1527614402449};\\\", \\\"{x:1410,y:775,t:1527614402466};\\\", \\\"{x:1414,y:781,t:1527614402482};\\\", \\\"{x:1417,y:785,t:1527614402499};\\\", \\\"{x:1422,y:790,t:1527614402516};\\\", \\\"{x:1429,y:794,t:1527614402532};\\\", \\\"{x:1435,y:797,t:1527614402549};\\\", \\\"{x:1445,y:798,t:1527614402565};\\\", \\\"{x:1450,y:798,t:1527614402582};\\\", \\\"{x:1462,y:798,t:1527614402599};\\\", \\\"{x:1479,y:793,t:1527614402616};\\\", \\\"{x:1497,y:782,t:1527614402632};\\\", \\\"{x:1513,y:774,t:1527614402649};\\\", \\\"{x:1525,y:767,t:1527614402667};\\\", \\\"{x:1535,y:759,t:1527614402682};\\\", \\\"{x:1541,y:756,t:1527614402699};\\\", \\\"{x:1549,y:753,t:1527614402716};\\\", \\\"{x:1554,y:751,t:1527614402732};\\\", \\\"{x:1557,y:749,t:1527614402749};\\\", \\\"{x:1561,y:748,t:1527614402767};\\\", \\\"{x:1564,y:748,t:1527614402783};\\\", \\\"{x:1567,y:748,t:1527614402799};\\\", \\\"{x:1570,y:748,t:1527614402816};\\\", \\\"{x:1572,y:748,t:1527614402832};\\\", \\\"{x:1574,y:748,t:1527614402850};\\\", \\\"{x:1578,y:750,t:1527614402866};\\\", \\\"{x:1580,y:751,t:1527614402882};\\\", \\\"{x:1582,y:752,t:1527614402899};\\\", \\\"{x:1582,y:753,t:1527614402916};\\\", \\\"{x:1584,y:753,t:1527614402932};\\\", \\\"{x:1583,y:754,t:1527614402991};\\\", \\\"{x:1581,y:755,t:1527614403007};\\\", \\\"{x:1579,y:755,t:1527614403017};\\\", \\\"{x:1577,y:756,t:1527614403033};\\\", \\\"{x:1573,y:757,t:1527614403050};\\\", \\\"{x:1569,y:758,t:1527614403066};\\\", \\\"{x:1558,y:758,t:1527614403084};\\\", \\\"{x:1544,y:758,t:1527614403100};\\\", \\\"{x:1536,y:758,t:1527614403117};\\\", \\\"{x:1534,y:758,t:1527614403134};\\\", \\\"{x:1533,y:758,t:1527614403439};\\\", \\\"{x:1533,y:759,t:1527614403479};\\\", \\\"{x:1533,y:760,t:1527614403535};\\\", \\\"{x:1534,y:760,t:1527614403599};\\\", \\\"{x:1540,y:760,t:1527614403616};\\\", \\\"{x:1544,y:760,t:1527614403634};\\\", \\\"{x:1547,y:760,t:1527614403650};\\\", \\\"{x:1548,y:760,t:1527614407735};\\\", \\\"{x:1548,y:761,t:1527614410367};\\\", \\\"{x:1548,y:762,t:1527614410375};\\\", \\\"{x:1548,y:763,t:1527614410386};\\\", \\\"{x:1548,y:764,t:1527614410407};\\\", \\\"{x:1548,y:765,t:1527614412407};\\\", \\\"{x:1547,y:765,t:1527614412471};\\\", \\\"{x:1547,y:762,t:1527614412487};\\\", \\\"{x:1546,y:762,t:1527614412504};\\\", \\\"{x:1546,y:761,t:1527614412521};\\\", \\\"{x:1546,y:759,t:1527614414118};\\\", \\\"{x:1545,y:759,t:1527614415351};\\\", \\\"{x:1545,y:758,t:1527614415358};\\\", \\\"{x:1545,y:757,t:1527614415375};\\\", \\\"{x:1547,y:758,t:1527614415607};\\\", \\\"{x:1548,y:758,t:1527614415663};\\\", \\\"{x:1549,y:758,t:1527614415743};\\\", \\\"{x:1550,y:758,t:1527614415783};\\\", \\\"{x:1551,y:759,t:1527614415815};\\\", \\\"{x:1552,y:760,t:1527614415831};\\\", \\\"{x:1553,y:760,t:1527614415854};\\\", \\\"{x:1554,y:760,t:1527614415943};\\\", \\\"{x:1555,y:759,t:1527614416150};\\\", \\\"{x:1555,y:757,t:1527614418279};\\\", \\\"{x:1555,y:756,t:1527614423926};\\\", \\\"{x:1554,y:756,t:1527614427783};\\\", \\\"{x:1553,y:756,t:1527614431726};\\\", \\\"{x:1553,y:757,t:1527614431734};\\\", \\\"{x:1553,y:758,t:1527614431746};\\\", \\\"{x:1553,y:759,t:1527614431762};\\\", \\\"{x:1553,y:760,t:1527614431780};\\\", \\\"{x:1546,y:761,t:1527614432206};\\\", \\\"{x:1529,y:761,t:1527614432215};\\\", \\\"{x:1490,y:761,t:1527614432230};\\\", \\\"{x:1470,y:761,t:1527614432246};\\\", \\\"{x:1375,y:761,t:1527614432262};\\\", \\\"{x:1295,y:761,t:1527614432279};\\\", \\\"{x:1222,y:758,t:1527614432295};\\\", \\\"{x:1132,y:753,t:1527614432313};\\\", \\\"{x:1039,y:747,t:1527614432330};\\\", \\\"{x:944,y:747,t:1527614432346};\\\", \\\"{x:849,y:743,t:1527614432362};\\\", \\\"{x:773,y:738,t:1527614432379};\\\", \\\"{x:711,y:738,t:1527614432395};\\\", \\\"{x:661,y:738,t:1527614432412};\\\", \\\"{x:622,y:738,t:1527614432429};\\\", \\\"{x:578,y:738,t:1527614432446};\\\", \\\"{x:551,y:738,t:1527614432464};\\\", \\\"{x:523,y:738,t:1527614432478};\\\", \\\"{x:494,y:737,t:1527614432494};\\\", \\\"{x:480,y:736,t:1527614432507};\\\", \\\"{x:452,y:731,t:1527614432523};\\\", \\\"{x:429,y:728,t:1527614432540};\\\", \\\"{x:404,y:728,t:1527614432557};\\\", \\\"{x:400,y:728,t:1527614432574};\\\", \\\"{x:399,y:728,t:1527614432597};\\\", \\\"{x:399,y:727,t:1527614432607};\\\", \\\"{x:400,y:722,t:1527614432623};\\\", \\\"{x:410,y:717,t:1527614432640};\\\", \\\"{x:418,y:710,t:1527614432657};\\\", \\\"{x:419,y:710,t:1527614432673};\\\", \\\"{x:420,y:710,t:1527614432690};\\\", \\\"{x:421,y:710,t:1527614432767};\\\", \\\"{x:422,y:710,t:1527614432773};\\\", \\\"{x:428,y:710,t:1527614432790};\\\", \\\"{x:438,y:710,t:1527614432806};\\\", \\\"{x:445,y:710,t:1527614432823};\\\", \\\"{x:450,y:710,t:1527614432840};\\\", \\\"{x:453,y:711,t:1527614432856};\\\", \\\"{x:458,y:712,t:1527614432873};\\\", \\\"{x:462,y:714,t:1527614432889};\\\", \\\"{x:465,y:715,t:1527614432907};\\\", \\\"{x:468,y:715,t:1527614432923};\\\", \\\"{x:469,y:715,t:1527614432942};\\\", \\\"{x:469,y:716,t:1527614432956};\\\", \\\"{x:470,y:717,t:1527614432973};\\\", \\\"{x:471,y:717,t:1527614433014};\\\", \\\"{x:472,y:717,t:1527614433038};\\\", \\\"{x:472,y:717,t:1527614433158};\\\", \\\"{x:472,y:718,t:1527614433309};\\\", \\\"{x:472,y:721,t:1527614433324};\\\", \\\"{x:475,y:733,t:1527614433341};\\\", \\\"{x:475,y:735,t:1527614433357};\\\", \\\"{x:476,y:736,t:1527614433374};\\\", \\\"{x:477,y:736,t:1527614433474};\\\", \\\"{x:477,y:736,t:1527614433611};\\\" ] }, { \\\"rt\\\": 73457, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 19, \\\"time_elapsed\\\": 840636, \\\"internal_node_id\\\": \\\"0.0-6.0-9.0\\\", \\\"subject\\\": \\\"TGOML\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"oscar\\\", \\\"condition\\\": \\\"114\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"midpoint\\\", \\\"q\\\": 15, \\\"clicks\\\": 3, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XInside-YInside\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 1, \\\"answer\\\": [ \\\"E\\\", \\\"F\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-X -X -X -X -X -X -X -C \\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:477,y:734,t:1527614439878};\\\", \\\"{x:476,y:731,t:1527614439887};\\\", \\\"{x:476,y:730,t:1527614439896};\\\", \\\"{x:475,y:728,t:1527614439913};\\\", \\\"{x:475,y:727,t:1527614439933};\\\", \\\"{x:474,y:726,t:1527614439982};\\\", \\\"{x:474,y:725,t:1527614440310};\\\", \\\"{x:476,y:724,t:1527614440318};\\\", \\\"{x:477,y:723,t:1527614441310};\\\", \\\"{x:478,y:723,t:1527614443598};\\\", \\\"{x:486,y:723,t:1527614443614};\\\", \\\"{x:489,y:723,t:1527614443631};\\\", \\\"{x:493,y:722,t:1527614443647};\\\", \\\"{x:509,y:720,t:1527614443664};\\\", \\\"{x:559,y:722,t:1527614443681};\\\", \\\"{x:658,y:734,t:1527614443697};\\\", \\\"{x:780,y:753,t:1527614443714};\\\", \\\"{x:902,y:771,t:1527614443731};\\\", \\\"{x:1021,y:786,t:1527614443747};\\\", \\\"{x:1160,y:807,t:1527614443763};\\\", \\\"{x:1312,y:829,t:1527614443781};\\\", \\\"{x:1459,y:848,t:1527614443797};\\\", \\\"{x:1618,y:870,t:1527614443814};\\\", \\\"{x:1677,y:880,t:1527614443831};\\\", \\\"{x:1706,y:884,t:1527614443847};\\\", \\\"{x:1725,y:888,t:1527614443864};\\\", \\\"{x:1736,y:890,t:1527614443880};\\\", \\\"{x:1746,y:895,t:1527614443898};\\\", \\\"{x:1752,y:898,t:1527614443914};\\\", \\\"{x:1757,y:899,t:1527614443931};\\\", \\\"{x:1758,y:899,t:1527614443958};\\\", \\\"{x:1758,y:898,t:1527614443989};\\\", \\\"{x:1758,y:897,t:1527614444014};\\\", \\\"{x:1757,y:895,t:1527614444030};\\\", \\\"{x:1756,y:894,t:1527614444048};\\\", \\\"{x:1754,y:893,t:1527614444064};\\\", \\\"{x:1752,y:893,t:1527614444080};\\\", \\\"{x:1746,y:890,t:1527614444934};\\\", \\\"{x:1732,y:885,t:1527614444948};\\\", \\\"{x:1694,y:878,t:1527614444965};\\\", \\\"{x:1653,y:874,t:1527614444981};\\\", \\\"{x:1600,y:869,t:1527614444998};\\\", \\\"{x:1572,y:867,t:1527614445015};\\\", \\\"{x:1552,y:865,t:1527614445030};\\\", \\\"{x:1540,y:861,t:1527614445048};\\\", \\\"{x:1533,y:861,t:1527614445065};\\\", \\\"{x:1526,y:861,t:1527614445081};\\\", \\\"{x:1521,y:861,t:1527614445098};\\\", \\\"{x:1517,y:861,t:1527614445115};\\\", \\\"{x:1514,y:861,t:1527614445131};\\\", \\\"{x:1513,y:861,t:1527614445246};\\\", \\\"{x:1510,y:858,t:1527614445254};\\\", \\\"{x:1508,y:856,t:1527614445264};\\\", \\\"{x:1501,y:848,t:1527614445281};\\\", \\\"{x:1496,y:842,t:1527614445298};\\\", \\\"{x:1494,y:841,t:1527614445315};\\\", \\\"{x:1493,y:840,t:1527614445332};\\\", \\\"{x:1493,y:839,t:1527614445348};\\\", \\\"{x:1493,y:841,t:1527614446854};\\\", \\\"{x:1493,y:842,t:1527614446878};\\\", \\\"{x:1492,y:841,t:1527614450405};\\\", \\\"{x:1492,y:840,t:1527614450417};\\\", \\\"{x:1491,y:840,t:1527614450433};\\\", \\\"{x:1491,y:839,t:1527614450450};\\\", \\\"{x:1490,y:838,t:1527614450773};\\\", \\\"{x:1490,y:837,t:1527614450783};\\\", \\\"{x:1488,y:836,t:1527614450800};\\\", \\\"{x:1488,y:835,t:1527614450829};\\\", \\\"{x:1487,y:834,t:1527614450860};\\\", \\\"{x:1486,y:833,t:1527614450917};\\\", \\\"{x:1485,y:831,t:1527614451224};\\\", \\\"{x:1483,y:831,t:1527614451250};\\\", \\\"{x:1482,y:830,t:1527614451266};\\\", \\\"{x:1481,y:829,t:1527614451282};\\\", \\\"{x:1480,y:828,t:1527614451299};\\\", \\\"{x:1478,y:827,t:1527614451316};\\\", \\\"{x:1477,y:826,t:1527614451339};\\\", \\\"{x:1476,y:826,t:1527614451380};\\\", \\\"{x:1474,y:826,t:1527614451701};\\\", \\\"{x:1473,y:826,t:1527614451725};\\\", \\\"{x:1474,y:827,t:1527614451933};\\\", \\\"{x:1475,y:828,t:1527614451951};\\\", \\\"{x:1476,y:828,t:1527614451973};\\\", \\\"{x:1476,y:829,t:1527614451984};\\\", \\\"{x:1477,y:829,t:1527614452004};\\\", \\\"{x:1479,y:829,t:1527614452020};\\\", \\\"{x:1480,y:831,t:1527614452036};\\\", \\\"{x:1481,y:831,t:1527614452050};\\\", \\\"{x:1482,y:831,t:1527614452067};\\\", \\\"{x:1483,y:831,t:1527614452133};\\\", \\\"{x:1483,y:828,t:1527614453301};\\\", \\\"{x:1483,y:824,t:1527614453319};\\\", \\\"{x:1484,y:821,t:1527614453334};\\\", \\\"{x:1484,y:819,t:1527614453351};\\\", \\\"{x:1484,y:818,t:1527614453368};\\\", \\\"{x:1484,y:815,t:1527614453384};\\\", \\\"{x:1485,y:811,t:1527614453402};\\\", \\\"{x:1485,y:808,t:1527614453418};\\\", \\\"{x:1486,y:806,t:1527614453434};\\\", \\\"{x:1486,y:804,t:1527614453451};\\\", \\\"{x:1486,y:801,t:1527614453468};\\\", \\\"{x:1486,y:798,t:1527614453484};\\\", \\\"{x:1486,y:796,t:1527614453501};\\\", \\\"{x:1486,y:794,t:1527614453518};\\\", \\\"{x:1486,y:792,t:1527614453534};\\\", \\\"{x:1486,y:789,t:1527614453551};\\\", \\\"{x:1486,y:787,t:1527614453568};\\\", \\\"{x:1486,y:785,t:1527614453583};\\\", \\\"{x:1486,y:784,t:1527614453603};\\\", \\\"{x:1485,y:782,t:1527614453617};\\\", \\\"{x:1485,y:780,t:1527614453636};\\\", \\\"{x:1484,y:779,t:1527614453651};\\\", \\\"{x:1482,y:771,t:1527614453667};\\\", \\\"{x:1480,y:768,t:1527614453684};\\\", \\\"{x:1480,y:765,t:1527614453701};\\\", \\\"{x:1480,y:761,t:1527614453717};\\\", \\\"{x:1478,y:758,t:1527614453734};\\\", \\\"{x:1477,y:753,t:1527614453751};\\\", \\\"{x:1476,y:749,t:1527614453768};\\\", \\\"{x:1474,y:743,t:1527614453784};\\\", \\\"{x:1473,y:741,t:1527614453801};\\\", \\\"{x:1472,y:739,t:1527614453818};\\\", \\\"{x:1472,y:738,t:1527614453834};\\\", \\\"{x:1471,y:738,t:1527614453851};\\\", \\\"{x:1471,y:737,t:1527614453868};\\\", \\\"{x:1471,y:736,t:1527614453900};\\\", \\\"{x:1471,y:735,t:1527614454069};\\\", \\\"{x:1471,y:733,t:1527614454085};\\\", \\\"{x:1472,y:729,t:1527614454101};\\\", \\\"{x:1474,y:726,t:1527614454118};\\\", \\\"{x:1474,y:722,t:1527614454136};\\\", \\\"{x:1474,y:720,t:1527614454151};\\\", \\\"{x:1476,y:717,t:1527614454168};\\\", \\\"{x:1476,y:716,t:1527614454185};\\\", \\\"{x:1476,y:713,t:1527614454201};\\\", \\\"{x:1476,y:712,t:1527614454218};\\\", \\\"{x:1476,y:709,t:1527614454235};\\\", \\\"{x:1476,y:707,t:1527614454251};\\\", \\\"{x:1476,y:706,t:1527614454269};\\\", \\\"{x:1476,y:704,t:1527614454286};\\\", \\\"{x:1476,y:702,t:1527614454301};\\\", \\\"{x:1476,y:700,t:1527614454318};\\\", \\\"{x:1476,y:698,t:1527614454335};\\\", \\\"{x:1476,y:696,t:1527614454351};\\\", \\\"{x:1476,y:694,t:1527614454368};\\\", \\\"{x:1477,y:692,t:1527614454385};\\\", \\\"{x:1477,y:691,t:1527614454401};\\\", \\\"{x:1478,y:682,t:1527614454418};\\\", \\\"{x:1479,y:670,t:1527614454436};\\\", \\\"{x:1480,y:657,t:1527614454451};\\\", \\\"{x:1480,y:645,t:1527614454469};\\\", \\\"{x:1480,y:643,t:1527614454485};\\\", \\\"{x:1481,y:642,t:1527614454948};\\\", \\\"{x:1482,y:641,t:1527614454955};\\\", \\\"{x:1482,y:640,t:1527614454980};\\\", \\\"{x:1482,y:638,t:1527614454987};\\\", \\\"{x:1482,y:636,t:1527614455002};\\\", \\\"{x:1482,y:632,t:1527614455017};\\\", \\\"{x:1482,y:629,t:1527614455034};\\\", \\\"{x:1482,y:626,t:1527614455051};\\\", \\\"{x:1482,y:622,t:1527614455067};\\\", \\\"{x:1482,y:619,t:1527614455085};\\\", \\\"{x:1482,y:614,t:1527614455102};\\\", \\\"{x:1482,y:610,t:1527614455118};\\\", \\\"{x:1481,y:607,t:1527614455134};\\\", \\\"{x:1481,y:605,t:1527614455151};\\\", \\\"{x:1481,y:604,t:1527614455168};\\\", \\\"{x:1481,y:602,t:1527614455184};\\\", \\\"{x:1482,y:600,t:1527614455202};\\\", \\\"{x:1482,y:597,t:1527614455218};\\\", \\\"{x:1483,y:595,t:1527614455235};\\\", \\\"{x:1484,y:591,t:1527614455252};\\\", \\\"{x:1484,y:590,t:1527614455268};\\\", \\\"{x:1485,y:588,t:1527614455285};\\\", \\\"{x:1485,y:587,t:1527614455302};\\\", \\\"{x:1486,y:585,t:1527614455318};\\\", \\\"{x:1486,y:584,t:1527614455340};\\\", \\\"{x:1486,y:582,t:1527614455355};\\\", \\\"{x:1486,y:581,t:1527614455372};\\\", \\\"{x:1486,y:579,t:1527614455404};\\\", \\\"{x:1486,y:578,t:1527614455428};\\\", \\\"{x:1486,y:576,t:1527614455461};\\\", \\\"{x:1486,y:575,t:1527614455484};\\\", \\\"{x:1486,y:573,t:1527614455517};\\\", \\\"{x:1486,y:572,t:1527614455540};\\\", \\\"{x:1485,y:569,t:1527614455556};\\\", \\\"{x:1485,y:567,t:1527614455569};\\\", \\\"{x:1484,y:563,t:1527614455585};\\\", \\\"{x:1483,y:559,t:1527614455602};\\\", \\\"{x:1482,y:557,t:1527614455619};\\\", \\\"{x:1480,y:555,t:1527614455634};\\\", \\\"{x:1478,y:554,t:1527614455652};\\\", \\\"{x:1478,y:555,t:1527614455868};\\\", \\\"{x:1478,y:557,t:1527614455933};\\\", \\\"{x:1478,y:558,t:1527614455949};\\\", \\\"{x:1478,y:560,t:1527614456005};\\\", \\\"{x:1479,y:560,t:1527614456019};\\\", \\\"{x:1479,y:562,t:1527614456037};\\\", \\\"{x:1474,y:563,t:1527614463997};\\\", \\\"{x:1461,y:567,t:1527614464007};\\\", \\\"{x:1414,y:577,t:1527614464023};\\\", \\\"{x:1353,y:585,t:1527614464039};\\\", \\\"{x:1297,y:593,t:1527614464057};\\\", \\\"{x:1256,y:597,t:1527614464073};\\\", \\\"{x:1227,y:597,t:1527614464089};\\\", \\\"{x:1195,y:600,t:1527614464106};\\\", \\\"{x:1152,y:601,t:1527614464123};\\\", \\\"{x:1113,y:601,t:1527614464139};\\\", \\\"{x:1064,y:601,t:1527614464156};\\\", \\\"{x:1039,y:601,t:1527614464173};\\\", \\\"{x:1014,y:601,t:1527614464190};\\\", \\\"{x:995,y:601,t:1527614464207};\\\", \\\"{x:971,y:601,t:1527614464223};\\\", \\\"{x:946,y:601,t:1527614464241};\\\", \\\"{x:907,y:601,t:1527614464255};\\\", \\\"{x:854,y:601,t:1527614464272};\\\", \\\"{x:823,y:601,t:1527614464282};\\\", \\\"{x:765,y:601,t:1527614464298};\\\", \\\"{x:720,y:601,t:1527614464316};\\\", \\\"{x:673,y:601,t:1527614464332};\\\", \\\"{x:656,y:601,t:1527614464348};\\\", \\\"{x:644,y:600,t:1527614464365};\\\", \\\"{x:634,y:598,t:1527614464382};\\\", \\\"{x:626,y:596,t:1527614464399};\\\", \\\"{x:622,y:596,t:1527614464416};\\\", \\\"{x:621,y:596,t:1527614464432};\\\", \\\"{x:620,y:595,t:1527614464449};\\\", \\\"{x:619,y:594,t:1527614464466};\\\", \\\"{x:617,y:592,t:1527614464482};\\\", \\\"{x:617,y:588,t:1527614464499};\\\", \\\"{x:622,y:577,t:1527614464516};\\\", \\\"{x:623,y:573,t:1527614464532};\\\", \\\"{x:624,y:570,t:1527614464549};\\\", \\\"{x:625,y:568,t:1527614464567};\\\", \\\"{x:625,y:566,t:1527614464582};\\\", \\\"{x:623,y:562,t:1527614464600};\\\", \\\"{x:620,y:558,t:1527614464617};\\\", \\\"{x:618,y:553,t:1527614464632};\\\", \\\"{x:617,y:549,t:1527614464649};\\\", \\\"{x:617,y:545,t:1527614464666};\\\", \\\"{x:617,y:541,t:1527614464682};\\\", \\\"{x:617,y:537,t:1527614464700};\\\", \\\"{x:619,y:529,t:1527614464715};\\\", \\\"{x:622,y:525,t:1527614464733};\\\", \\\"{x:626,y:521,t:1527614464749};\\\", \\\"{x:627,y:520,t:1527614464765};\\\", \\\"{x:626,y:519,t:1527614464907};\\\", \\\"{x:621,y:519,t:1527614464917};\\\", \\\"{x:609,y:519,t:1527614464933};\\\", \\\"{x:598,y:519,t:1527614464950};\\\", \\\"{x:591,y:519,t:1527614464967};\\\", \\\"{x:589,y:519,t:1527614464983};\\\", \\\"{x:588,y:519,t:1527614465000};\\\", \\\"{x:589,y:519,t:1527614465301};\\\", \\\"{x:598,y:519,t:1527614465317};\\\", \\\"{x:609,y:519,t:1527614465336};\\\", \\\"{x:628,y:519,t:1527614465349};\\\", \\\"{x:645,y:519,t:1527614465366};\\\", \\\"{x:682,y:519,t:1527614465383};\\\", \\\"{x:746,y:519,t:1527614465400};\\\", \\\"{x:832,y:520,t:1527614465417};\\\", \\\"{x:913,y:520,t:1527614465433};\\\", \\\"{x:985,y:520,t:1527614465451};\\\", \\\"{x:1074,y:522,t:1527614465466};\\\", \\\"{x:1175,y:528,t:1527614465483};\\\", \\\"{x:1311,y:528,t:1527614465499};\\\", \\\"{x:1375,y:528,t:1527614465516};\\\", \\\"{x:1400,y:533,t:1527614465533};\\\", \\\"{x:1414,y:534,t:1527614465550};\\\", \\\"{x:1422,y:534,t:1527614465566};\\\", \\\"{x:1427,y:534,t:1527614465583};\\\", \\\"{x:1434,y:534,t:1527614465600};\\\", \\\"{x:1438,y:534,t:1527614465616};\\\", \\\"{x:1442,y:533,t:1527614465633};\\\", \\\"{x:1445,y:532,t:1527614465650};\\\", \\\"{x:1450,y:531,t:1527614465666};\\\", \\\"{x:1458,y:531,t:1527614465683};\\\", \\\"{x:1488,y:524,t:1527614465700};\\\", \\\"{x:1511,y:517,t:1527614465717};\\\", \\\"{x:1523,y:513,t:1527614465733};\\\", \\\"{x:1526,y:513,t:1527614465750};\\\", \\\"{x:1527,y:513,t:1527614465788};\\\", \\\"{x:1528,y:513,t:1527614465800};\\\", \\\"{x:1531,y:513,t:1527614465817};\\\", \\\"{x:1542,y:521,t:1527614465833};\\\", \\\"{x:1554,y:533,t:1527614465850};\\\", \\\"{x:1558,y:540,t:1527614465867};\\\", \\\"{x:1558,y:544,t:1527614465884};\\\", \\\"{x:1555,y:548,t:1527614465901};\\\", \\\"{x:1544,y:552,t:1527614465918};\\\", \\\"{x:1533,y:556,t:1527614465934};\\\", \\\"{x:1529,y:556,t:1527614465950};\\\", \\\"{x:1523,y:557,t:1527614465967};\\\", \\\"{x:1518,y:557,t:1527614465983};\\\", \\\"{x:1510,y:557,t:1527614466001};\\\", \\\"{x:1497,y:557,t:1527614466017};\\\", \\\"{x:1489,y:557,t:1527614466033};\\\", \\\"{x:1483,y:555,t:1527614466051};\\\", \\\"{x:1481,y:555,t:1527614466068};\\\", \\\"{x:1480,y:554,t:1527614466083};\\\", \\\"{x:1481,y:555,t:1527614466412};\\\", \\\"{x:1481,y:556,t:1527614466421};\\\", \\\"{x:1483,y:557,t:1527614466436};\\\", \\\"{x:1483,y:558,t:1527614466452};\\\", \\\"{x:1483,y:559,t:1527614466475};\\\", \\\"{x:1478,y:560,t:1527614471189};\\\", \\\"{x:1465,y:564,t:1527614471204};\\\", \\\"{x:1459,y:567,t:1527614471221};\\\", \\\"{x:1457,y:567,t:1527614471237};\\\", \\\"{x:1456,y:567,t:1527614471254};\\\", \\\"{x:1454,y:567,t:1527614471270};\\\", \\\"{x:1450,y:567,t:1527614471288};\\\", \\\"{x:1436,y:571,t:1527614471305};\\\", \\\"{x:1414,y:577,t:1527614471321};\\\", \\\"{x:1390,y:584,t:1527614471338};\\\", \\\"{x:1364,y:589,t:1527614471355};\\\", \\\"{x:1310,y:596,t:1527614471372};\\\", \\\"{x:1263,y:599,t:1527614471388};\\\", \\\"{x:1214,y:604,t:1527614471405};\\\", \\\"{x:1167,y:604,t:1527614471422};\\\", \\\"{x:1135,y:604,t:1527614471438};\\\", \\\"{x:1109,y:608,t:1527614471455};\\\", \\\"{x:1086,y:612,t:1527614471471};\\\", \\\"{x:1057,y:618,t:1527614471488};\\\", \\\"{x:1019,y:628,t:1527614471505};\\\", \\\"{x:975,y:639,t:1527614471522};\\\", \\\"{x:933,y:646,t:1527614471537};\\\", \\\"{x:896,y:651,t:1527614471554};\\\", \\\"{x:852,y:657,t:1527614471572};\\\", \\\"{x:830,y:658,t:1527614471587};\\\", \\\"{x:812,y:660,t:1527614471604};\\\", \\\"{x:801,y:660,t:1527614471621};\\\", \\\"{x:793,y:660,t:1527614471637};\\\", \\\"{x:785,y:660,t:1527614471654};\\\", \\\"{x:780,y:660,t:1527614471671};\\\", \\\"{x:772,y:660,t:1527614471687};\\\", \\\"{x:761,y:660,t:1527614471705};\\\", \\\"{x:750,y:660,t:1527614471722};\\\", \\\"{x:740,y:659,t:1527614471737};\\\", \\\"{x:725,y:655,t:1527614471754};\\\", \\\"{x:706,y:649,t:1527614471771};\\\", \\\"{x:692,y:645,t:1527614471788};\\\", \\\"{x:674,y:643,t:1527614471804};\\\", \\\"{x:652,y:640,t:1527614471821};\\\", \\\"{x:624,y:634,t:1527614471838};\\\", \\\"{x:594,y:627,t:1527614471856};\\\", \\\"{x:566,y:621,t:1527614471872};\\\", \\\"{x:539,y:617,t:1527614471888};\\\", \\\"{x:511,y:617,t:1527614471905};\\\", \\\"{x:487,y:617,t:1527614471922};\\\", \\\"{x:464,y:616,t:1527614471938};\\\", \\\"{x:444,y:611,t:1527614471955};\\\", \\\"{x:437,y:608,t:1527614471971};\\\", \\\"{x:435,y:606,t:1527614471988};\\\", \\\"{x:433,y:604,t:1527614472005};\\\", \\\"{x:432,y:604,t:1527614472022};\\\", \\\"{x:431,y:604,t:1527614472038};\\\", \\\"{x:429,y:603,t:1527614472056};\\\", \\\"{x:426,y:601,t:1527614472072};\\\", \\\"{x:418,y:598,t:1527614472088};\\\", \\\"{x:401,y:596,t:1527614472106};\\\", \\\"{x:384,y:595,t:1527614472122};\\\", \\\"{x:368,y:595,t:1527614472139};\\\", \\\"{x:354,y:595,t:1527614472155};\\\", \\\"{x:351,y:595,t:1527614472171};\\\", \\\"{x:349,y:595,t:1527614472195};\\\", \\\"{x:349,y:594,t:1527614472476};\\\", \\\"{x:353,y:590,t:1527614472489};\\\", \\\"{x:376,y:575,t:1527614472506};\\\", \\\"{x:408,y:554,t:1527614472523};\\\", \\\"{x:435,y:538,t:1527614472539};\\\", \\\"{x:454,y:526,t:1527614472556};\\\", \\\"{x:456,y:526,t:1527614472572};\\\", \\\"{x:457,y:525,t:1527614472589};\\\", \\\"{x:457,y:524,t:1527614472605};\\\", \\\"{x:459,y:522,t:1527614472622};\\\", \\\"{x:463,y:520,t:1527614472639};\\\", \\\"{x:467,y:520,t:1527614472656};\\\", \\\"{x:471,y:520,t:1527614472672};\\\", \\\"{x:477,y:520,t:1527614472689};\\\", \\\"{x:484,y:520,t:1527614472707};\\\", \\\"{x:503,y:520,t:1527614472723};\\\", \\\"{x:547,y:522,t:1527614472739};\\\", \\\"{x:583,y:527,t:1527614472755};\\\", \\\"{x:635,y:530,t:1527614472772};\\\", \\\"{x:676,y:534,t:1527614472788};\\\", \\\"{x:693,y:534,t:1527614472805};\\\", \\\"{x:692,y:534,t:1527614472876};\\\", \\\"{x:690,y:534,t:1527614472889};\\\", \\\"{x:682,y:532,t:1527614472907};\\\", \\\"{x:676,y:530,t:1527614472924};\\\", \\\"{x:668,y:525,t:1527614472939};\\\", \\\"{x:662,y:525,t:1527614472956};\\\", \\\"{x:658,y:525,t:1527614472972};\\\", \\\"{x:652,y:524,t:1527614472989};\\\", \\\"{x:645,y:524,t:1527614473006};\\\", \\\"{x:638,y:524,t:1527614473023};\\\", \\\"{x:633,y:524,t:1527614473039};\\\", \\\"{x:630,y:524,t:1527614473056};\\\", \\\"{x:626,y:522,t:1527614473236};\\\", \\\"{x:623,y:522,t:1527614473244};\\\", \\\"{x:618,y:522,t:1527614473257};\\\", \\\"{x:609,y:522,t:1527614473273};\\\", \\\"{x:601,y:522,t:1527614473290};\\\", \\\"{x:599,y:522,t:1527614473308};\\\", \\\"{x:598,y:522,t:1527614473355};\\\", \\\"{x:601,y:520,t:1527614473533};\\\", \\\"{x:606,y:518,t:1527614473539};\\\", \\\"{x:610,y:516,t:1527614473556};\\\", \\\"{x:613,y:514,t:1527614473573};\\\", \\\"{x:622,y:510,t:1527614473590};\\\", \\\"{x:634,y:505,t:1527614473606};\\\", \\\"{x:653,y:496,t:1527614473624};\\\", \\\"{x:682,y:490,t:1527614473640};\\\", \\\"{x:704,y:487,t:1527614473656};\\\", \\\"{x:716,y:487,t:1527614473673};\\\", \\\"{x:719,y:487,t:1527614473690};\\\", \\\"{x:720,y:487,t:1527614473723};\\\", \\\"{x:721,y:487,t:1527614473755};\\\", \\\"{x:720,y:488,t:1527614473820};\\\", \\\"{x:719,y:489,t:1527614473828};\\\", \\\"{x:718,y:489,t:1527614473840};\\\", \\\"{x:718,y:490,t:1527614473856};\\\", \\\"{x:718,y:491,t:1527614473873};\\\", \\\"{x:718,y:494,t:1527614473940};\\\", \\\"{x:712,y:504,t:1527614473956};\\\", \\\"{x:693,y:521,t:1527614473973};\\\", \\\"{x:656,y:536,t:1527614473991};\\\", \\\"{x:598,y:551,t:1527614474008};\\\", \\\"{x:559,y:555,t:1527614474023};\\\", \\\"{x:541,y:555,t:1527614474040};\\\", \\\"{x:538,y:555,t:1527614474057};\\\", \\\"{x:537,y:555,t:1527614474084};\\\", \\\"{x:537,y:552,t:1527614474100};\\\", \\\"{x:538,y:551,t:1527614474107};\\\", \\\"{x:544,y:547,t:1527614474123};\\\", \\\"{x:551,y:542,t:1527614474140};\\\", \\\"{x:554,y:540,t:1527614474158};\\\", \\\"{x:556,y:539,t:1527614474173};\\\", \\\"{x:559,y:537,t:1527614474191};\\\", \\\"{x:561,y:536,t:1527614474207};\\\", \\\"{x:565,y:534,t:1527614474224};\\\", \\\"{x:573,y:529,t:1527614474241};\\\", \\\"{x:578,y:528,t:1527614474256};\\\", \\\"{x:580,y:527,t:1527614474273};\\\", \\\"{x:582,y:526,t:1527614474290};\\\", \\\"{x:584,y:525,t:1527614474307};\\\", \\\"{x:585,y:525,t:1527614474323};\\\", \\\"{x:590,y:522,t:1527614474340};\\\", \\\"{x:593,y:521,t:1527614474357};\\\", \\\"{x:596,y:520,t:1527614474373};\\\", \\\"{x:597,y:520,t:1527614474395};\\\", \\\"{x:597,y:519,t:1527614474411};\\\", \\\"{x:598,y:519,t:1527614474492};\\\", \\\"{x:599,y:518,t:1527614474508};\\\", \\\"{x:601,y:518,t:1527614474525};\\\", \\\"{x:602,y:518,t:1527614474595};\\\", \\\"{x:603,y:518,t:1527614474652};\\\", \\\"{x:603,y:518,t:1527614474671};\\\", \\\"{x:604,y:518,t:1527614474706};\\\", \\\"{x:610,y:518,t:1527614474724};\\\", \\\"{x:628,y:513,t:1527614474740};\\\", \\\"{x:668,y:510,t:1527614474757};\\\", \\\"{x:725,y:507,t:1527614474774};\\\", \\\"{x:765,y:504,t:1527614474790};\\\", \\\"{x:792,y:504,t:1527614474807};\\\", \\\"{x:803,y:504,t:1527614474824};\\\", \\\"{x:805,y:504,t:1527614474840};\\\", \\\"{x:804,y:504,t:1527614474972};\\\", \\\"{x:803,y:504,t:1527614474979};\\\", \\\"{x:802,y:504,t:1527614474991};\\\", \\\"{x:802,y:505,t:1527614475007};\\\", \\\"{x:802,y:506,t:1527614475108};\\\", \\\"{x:808,y:509,t:1527614475125};\\\", \\\"{x:821,y:513,t:1527614475142};\\\", \\\"{x:827,y:514,t:1527614475158};\\\", \\\"{x:831,y:515,t:1527614475175};\\\", \\\"{x:833,y:515,t:1527614475203};\\\", \\\"{x:834,y:516,t:1527614475267};\\\", \\\"{x:835,y:517,t:1527614475275};\\\", \\\"{x:837,y:517,t:1527614475587};\\\", \\\"{x:841,y:517,t:1527614475595};\\\", \\\"{x:843,y:517,t:1527614475608};\\\", \\\"{x:855,y:512,t:1527614475625};\\\", \\\"{x:889,y:512,t:1527614475641};\\\", \\\"{x:961,y:512,t:1527614475659};\\\", \\\"{x:1056,y:512,t:1527614475674};\\\", \\\"{x:1211,y:512,t:1527614475691};\\\", \\\"{x:1300,y:512,t:1527614475708};\\\", \\\"{x:1364,y:512,t:1527614475724};\\\", \\\"{x:1409,y:512,t:1527614475742};\\\", \\\"{x:1432,y:512,t:1527614475758};\\\", \\\"{x:1447,y:512,t:1527614475775};\\\", \\\"{x:1451,y:512,t:1527614475791};\\\", \\\"{x:1452,y:512,t:1527614475809};\\\", \\\"{x:1454,y:512,t:1527614475827};\\\", \\\"{x:1456,y:513,t:1527614475844};\\\", \\\"{x:1461,y:515,t:1527614475859};\\\", \\\"{x:1483,y:527,t:1527614475876};\\\", \\\"{x:1502,y:537,t:1527614475892};\\\", \\\"{x:1511,y:544,t:1527614475909};\\\", \\\"{x:1518,y:548,t:1527614475926};\\\", \\\"{x:1519,y:551,t:1527614475941};\\\", \\\"{x:1520,y:556,t:1527614475958};\\\", \\\"{x:1521,y:567,t:1527614475976};\\\", \\\"{x:1524,y:581,t:1527614475991};\\\", \\\"{x:1526,y:592,t:1527614476009};\\\", \\\"{x:1527,y:595,t:1527614476026};\\\", \\\"{x:1527,y:598,t:1527614476042};\\\", \\\"{x:1527,y:599,t:1527614476059};\\\", \\\"{x:1527,y:602,t:1527614476076};\\\", \\\"{x:1527,y:606,t:1527614476092};\\\", \\\"{x:1527,y:611,t:1527614476109};\\\", \\\"{x:1527,y:613,t:1527614476126};\\\", \\\"{x:1527,y:616,t:1527614476142};\\\", \\\"{x:1527,y:618,t:1527614476158};\\\", \\\"{x:1527,y:622,t:1527614476175};\\\", \\\"{x:1526,y:625,t:1527614476191};\\\", \\\"{x:1526,y:628,t:1527614476209};\\\", \\\"{x:1525,y:630,t:1527614476226};\\\", \\\"{x:1524,y:630,t:1527614476428};\\\", \\\"{x:1523,y:629,t:1527614476443};\\\", \\\"{x:1520,y:623,t:1527614476459};\\\", \\\"{x:1516,y:616,t:1527614476476};\\\", \\\"{x:1515,y:611,t:1527614476492};\\\", \\\"{x:1513,y:607,t:1527614476509};\\\", \\\"{x:1512,y:603,t:1527614476526};\\\", \\\"{x:1509,y:597,t:1527614476543};\\\", \\\"{x:1509,y:596,t:1527614476559};\\\", \\\"{x:1509,y:594,t:1527614476576};\\\", \\\"{x:1508,y:592,t:1527614476593};\\\", \\\"{x:1508,y:589,t:1527614476609};\\\", \\\"{x:1507,y:585,t:1527614476626};\\\", \\\"{x:1507,y:579,t:1527614476643};\\\", \\\"{x:1507,y:574,t:1527614476659};\\\", \\\"{x:1507,y:566,t:1527614476676};\\\", \\\"{x:1507,y:564,t:1527614476693};\\\", \\\"{x:1507,y:561,t:1527614476709};\\\", \\\"{x:1507,y:560,t:1527614476726};\\\", \\\"{x:1507,y:557,t:1527614476743};\\\", \\\"{x:1507,y:556,t:1527614476760};\\\", \\\"{x:1507,y:555,t:1527614476775};\\\", \\\"{x:1507,y:553,t:1527614476793};\\\", \\\"{x:1507,y:554,t:1527614476909};\\\", \\\"{x:1507,y:556,t:1527614476915};\\\", \\\"{x:1509,y:558,t:1527614476926};\\\", \\\"{x:1509,y:561,t:1527614476943};\\\", \\\"{x:1509,y:562,t:1527614476960};\\\", \\\"{x:1510,y:564,t:1527614476976};\\\", \\\"{x:1510,y:565,t:1527614476996};\\\", \\\"{x:1510,y:566,t:1527614477012};\\\", \\\"{x:1508,y:566,t:1527614477220};\\\", \\\"{x:1505,y:566,t:1527614477228};\\\", \\\"{x:1501,y:566,t:1527614477243};\\\", \\\"{x:1497,y:566,t:1527614477260};\\\", \\\"{x:1495,y:566,t:1527614477349};\\\", \\\"{x:1492,y:566,t:1527614477364};\\\", \\\"{x:1488,y:566,t:1527614477376};\\\", \\\"{x:1482,y:566,t:1527614477393};\\\", \\\"{x:1471,y:566,t:1527614477410};\\\", \\\"{x:1467,y:566,t:1527614477427};\\\", \\\"{x:1466,y:566,t:1527614477443};\\\", \\\"{x:1465,y:566,t:1527614477540};\\\", \\\"{x:1465,y:564,t:1527614477548};\\\", \\\"{x:1466,y:563,t:1527614477564};\\\", \\\"{x:1466,y:561,t:1527614477577};\\\", \\\"{x:1467,y:560,t:1527614477594};\\\", \\\"{x:1469,y:558,t:1527614477610};\\\", \\\"{x:1470,y:557,t:1527614477627};\\\", \\\"{x:1472,y:557,t:1527614477644};\\\", \\\"{x:1473,y:556,t:1527614477660};\\\", \\\"{x:1474,y:556,t:1527614477677};\\\", \\\"{x:1475,y:554,t:1527614477694};\\\", \\\"{x:1476,y:554,t:1527614477732};\\\", \\\"{x:1475,y:554,t:1527614477900};\\\", \\\"{x:1475,y:555,t:1527614477910};\\\", \\\"{x:1475,y:556,t:1527614477940};\\\", \\\"{x:1475,y:557,t:1527614477948};\\\", \\\"{x:1475,y:558,t:1527614477964};\\\", \\\"{x:1475,y:559,t:1527614477996};\\\", \\\"{x:1475,y:560,t:1527614478012};\\\", \\\"{x:1475,y:561,t:1527614478027};\\\", \\\"{x:1476,y:561,t:1527614478044};\\\", \\\"{x:1476,y:562,t:1527614478060};\\\", \\\"{x:1478,y:562,t:1527614478252};\\\", \\\"{x:1479,y:562,t:1527614478276};\\\", \\\"{x:1480,y:562,t:1527614483044};\\\", \\\"{x:1480,y:561,t:1527614488307};\\\", \\\"{x:1481,y:561,t:1527614488318};\\\", \\\"{x:1482,y:568,t:1527614488335};\\\", \\\"{x:1482,y:571,t:1527614488352};\\\", \\\"{x:1482,y:572,t:1527614488367};\\\", \\\"{x:1482,y:573,t:1527614488385};\\\", \\\"{x:1482,y:575,t:1527614488401};\\\", \\\"{x:1482,y:576,t:1527614488418};\\\", \\\"{x:1482,y:578,t:1527614488435};\\\", \\\"{x:1482,y:579,t:1527614488572};\\\", \\\"{x:1482,y:580,t:1527614488586};\\\", \\\"{x:1482,y:581,t:1527614488603};\\\", \\\"{x:1482,y:582,t:1527614488643};\\\", \\\"{x:1482,y:583,t:1527614488660};\\\", \\\"{x:1482,y:584,t:1527614488683};\\\", \\\"{x:1482,y:585,t:1527614488692};\\\", \\\"{x:1482,y:586,t:1527614488715};\\\", \\\"{x:1481,y:588,t:1527614488723};\\\", \\\"{x:1481,y:589,t:1527614488735};\\\", \\\"{x:1481,y:592,t:1527614488753};\\\", \\\"{x:1480,y:594,t:1527614488769};\\\", \\\"{x:1480,y:596,t:1527614488785};\\\", \\\"{x:1480,y:598,t:1527614488802};\\\", \\\"{x:1479,y:600,t:1527614488820};\\\", \\\"{x:1479,y:602,t:1527614488836};\\\", \\\"{x:1478,y:605,t:1527614488853};\\\", \\\"{x:1478,y:607,t:1527614488869};\\\", \\\"{x:1478,y:609,t:1527614488885};\\\", \\\"{x:1478,y:611,t:1527614488903};\\\", \\\"{x:1478,y:612,t:1527614488919};\\\", \\\"{x:1478,y:614,t:1527614488937};\\\", \\\"{x:1478,y:615,t:1527614488952};\\\", \\\"{x:1477,y:617,t:1527614488970};\\\", \\\"{x:1477,y:619,t:1527614488986};\\\", \\\"{x:1476,y:622,t:1527614489003};\\\", \\\"{x:1475,y:624,t:1527614489019};\\\", \\\"{x:1475,y:625,t:1527614489044};\\\", \\\"{x:1475,y:627,t:1527614489092};\\\", \\\"{x:1475,y:628,t:1527614489116};\\\", \\\"{x:1475,y:630,t:1527614489132};\\\", \\\"{x:1475,y:631,t:1527614489148};\\\", \\\"{x:1475,y:632,t:1527614489404};\\\", \\\"{x:1476,y:632,t:1527614489419};\\\", \\\"{x:1478,y:631,t:1527614489436};\\\", \\\"{x:1480,y:630,t:1527614489454};\\\", \\\"{x:1481,y:629,t:1527614489469};\\\", \\\"{x:1482,y:628,t:1527614489487};\\\", \\\"{x:1482,y:629,t:1527614490212};\\\", \\\"{x:1482,y:631,t:1527614490220};\\\", \\\"{x:1482,y:634,t:1527614490237};\\\", \\\"{x:1482,y:638,t:1527614490253};\\\", \\\"{x:1482,y:642,t:1527614490270};\\\", \\\"{x:1482,y:644,t:1527614490286};\\\", \\\"{x:1482,y:646,t:1527614490303};\\\", \\\"{x:1482,y:649,t:1527614490319};\\\", \\\"{x:1482,y:651,t:1527614490337};\\\", \\\"{x:1482,y:655,t:1527614490353};\\\", \\\"{x:1484,y:657,t:1527614490369};\\\", \\\"{x:1484,y:659,t:1527614490386};\\\", \\\"{x:1484,y:660,t:1527614490403};\\\", \\\"{x:1484,y:661,t:1527614490420};\\\", \\\"{x:1484,y:662,t:1527614490437};\\\", \\\"{x:1485,y:662,t:1527614490453};\\\", \\\"{x:1485,y:664,t:1527614490471};\\\", \\\"{x:1485,y:667,t:1527614490487};\\\", \\\"{x:1485,y:668,t:1527614490503};\\\", \\\"{x:1485,y:671,t:1527614490521};\\\", \\\"{x:1485,y:672,t:1527614490538};\\\", \\\"{x:1485,y:674,t:1527614490553};\\\", \\\"{x:1484,y:675,t:1527614490572};\\\", \\\"{x:1484,y:677,t:1527614490588};\\\", \\\"{x:1484,y:679,t:1527614490604};\\\", \\\"{x:1484,y:680,t:1527614490621};\\\", \\\"{x:1483,y:682,t:1527614490644};\\\", \\\"{x:1483,y:683,t:1527614490676};\\\", \\\"{x:1483,y:684,t:1527614490692};\\\", \\\"{x:1483,y:685,t:1527614490708};\\\", \\\"{x:1482,y:686,t:1527614490720};\\\", \\\"{x:1482,y:687,t:1527614490772};\\\", \\\"{x:1482,y:688,t:1527614490795};\\\", \\\"{x:1482,y:689,t:1527614490804};\\\", \\\"{x:1482,y:690,t:1527614490835};\\\", \\\"{x:1482,y:691,t:1527614490851};\\\", \\\"{x:1482,y:692,t:1527614490860};\\\", \\\"{x:1482,y:693,t:1527614490900};\\\", \\\"{x:1481,y:696,t:1527614491821};\\\", \\\"{x:1480,y:698,t:1527614491838};\\\", \\\"{x:1478,y:701,t:1527614491855};\\\", \\\"{x:1478,y:702,t:1527614492060};\\\", \\\"{x:1478,y:703,t:1527614492075};\\\", \\\"{x:1478,y:705,t:1527614492164};\\\", \\\"{x:1477,y:705,t:1527614492172};\\\", \\\"{x:1477,y:706,t:1527614492189};\\\", \\\"{x:1477,y:708,t:1527614492205};\\\", \\\"{x:1476,y:708,t:1527614492276};\\\", \\\"{x:1475,y:709,t:1527614492308};\\\", \\\"{x:1474,y:710,t:1527614492323};\\\", \\\"{x:1474,y:711,t:1527614492339};\\\", \\\"{x:1473,y:712,t:1527614492372};\\\", \\\"{x:1472,y:713,t:1527614492389};\\\", \\\"{x:1472,y:715,t:1527614492406};\\\", \\\"{x:1472,y:717,t:1527614492423};\\\", \\\"{x:1472,y:720,t:1527614492438};\\\", \\\"{x:1472,y:721,t:1527614492455};\\\", \\\"{x:1472,y:723,t:1527614492472};\\\", \\\"{x:1472,y:724,t:1527614492491};\\\", \\\"{x:1472,y:726,t:1527614492505};\\\", \\\"{x:1472,y:729,t:1527614492522};\\\", \\\"{x:1472,y:731,t:1527614492539};\\\", \\\"{x:1472,y:734,t:1527614492555};\\\", \\\"{x:1473,y:736,t:1527614492572};\\\", \\\"{x:1473,y:737,t:1527614492589};\\\", \\\"{x:1474,y:739,t:1527614492606};\\\", \\\"{x:1476,y:740,t:1527614492623};\\\", \\\"{x:1476,y:742,t:1527614492638};\\\", \\\"{x:1478,y:744,t:1527614492654};\\\", \\\"{x:1479,y:746,t:1527614492675};\\\", \\\"{x:1479,y:748,t:1527614492691};\\\", \\\"{x:1479,y:749,t:1527614492705};\\\", \\\"{x:1481,y:751,t:1527614492722};\\\", \\\"{x:1481,y:753,t:1527614492738};\\\", \\\"{x:1482,y:755,t:1527614492755};\\\", \\\"{x:1483,y:757,t:1527614492772};\\\", \\\"{x:1483,y:758,t:1527614492900};\\\", \\\"{x:1484,y:759,t:1527614492908};\\\", \\\"{x:1486,y:760,t:1527614493028};\\\", \\\"{x:1488,y:761,t:1527614493039};\\\", \\\"{x:1490,y:761,t:1527614493056};\\\", \\\"{x:1490,y:762,t:1527614493073};\\\", \\\"{x:1491,y:762,t:1527614493090};\\\", \\\"{x:1491,y:763,t:1527614493346};\\\", \\\"{x:1490,y:763,t:1527614493394};\\\", \\\"{x:1489,y:763,t:1527614493411};\\\", \\\"{x:1488,y:763,t:1527614493426};\\\", \\\"{x:1487,y:763,t:1527614493955};\\\", \\\"{x:1486,y:763,t:1527614494044};\\\", \\\"{x:1485,y:763,t:1527614494148};\\\", \\\"{x:1484,y:763,t:1527614494157};\\\", \\\"{x:1484,y:762,t:1527614494174};\\\", \\\"{x:1483,y:764,t:1527614498020};\\\", \\\"{x:1482,y:766,t:1527614498051};\\\", \\\"{x:1482,y:767,t:1527614498076};\\\", \\\"{x:1482,y:769,t:1527614498094};\\\", \\\"{x:1482,y:771,t:1527614498109};\\\", \\\"{x:1482,y:775,t:1527614498127};\\\", \\\"{x:1481,y:778,t:1527614498144};\\\", \\\"{x:1481,y:781,t:1527614498160};\\\", \\\"{x:1481,y:782,t:1527614498176};\\\", \\\"{x:1481,y:785,t:1527614498194};\\\", \\\"{x:1481,y:788,t:1527614498210};\\\", \\\"{x:1481,y:790,t:1527614498228};\\\", \\\"{x:1481,y:791,t:1527614498244};\\\", \\\"{x:1481,y:793,t:1527614498259};\\\", \\\"{x:1481,y:794,t:1527614498276};\\\", \\\"{x:1481,y:795,t:1527614498293};\\\", \\\"{x:1481,y:796,t:1527614498315};\\\", \\\"{x:1481,y:797,t:1527614498327};\\\", \\\"{x:1481,y:799,t:1527614498356};\\\", \\\"{x:1481,y:800,t:1527614498364};\\\", \\\"{x:1481,y:801,t:1527614498377};\\\", \\\"{x:1482,y:803,t:1527614498394};\\\", \\\"{x:1482,y:804,t:1527614498412};\\\", \\\"{x:1482,y:806,t:1527614498436};\\\", \\\"{x:1482,y:807,t:1527614498452};\\\", \\\"{x:1482,y:809,t:1527614498475};\\\", \\\"{x:1482,y:810,t:1527614498493};\\\", \\\"{x:1482,y:812,t:1527614498524};\\\", \\\"{x:1482,y:813,t:1527614498563};\\\", \\\"{x:1482,y:815,t:1527614498603};\\\", \\\"{x:1482,y:816,t:1527614498668};\\\", \\\"{x:1483,y:818,t:1527614498716};\\\", \\\"{x:1483,y:819,t:1527614498740};\\\", \\\"{x:1483,y:821,t:1527614498763};\\\", \\\"{x:1484,y:822,t:1527614498779};\\\", \\\"{x:1485,y:823,t:1527614498796};\\\", \\\"{x:1485,y:824,t:1527614498811};\\\", \\\"{x:1485,y:825,t:1527614498835};\\\", \\\"{x:1485,y:826,t:1527614498901};\\\", \\\"{x:1485,y:827,t:1527614498927};\\\", \\\"{x:1485,y:828,t:1527614498947};\\\", \\\"{x:1485,y:829,t:1527614499715};\\\", \\\"{x:1483,y:829,t:1527614499747};\\\", \\\"{x:1483,y:828,t:1527614500291};\\\", \\\"{x:1482,y:828,t:1527614500347};\\\", \\\"{x:1481,y:828,t:1527614500395};\\\", \\\"{x:1480,y:828,t:1527614500435};\\\", \\\"{x:1479,y:828,t:1527614500771};\\\", \\\"{x:1479,y:829,t:1527614500787};\\\", \\\"{x:1479,y:830,t:1527614500795};\\\", \\\"{x:1479,y:832,t:1527614500811};\\\", \\\"{x:1480,y:834,t:1527614500828};\\\", \\\"{x:1480,y:836,t:1527614500847};\\\", \\\"{x:1482,y:839,t:1527614500862};\\\", \\\"{x:1482,y:841,t:1527614500879};\\\", \\\"{x:1483,y:844,t:1527614500896};\\\", \\\"{x:1483,y:845,t:1527614500912};\\\", \\\"{x:1484,y:846,t:1527614500929};\\\", \\\"{x:1484,y:847,t:1527614500946};\\\", \\\"{x:1484,y:848,t:1527614500962};\\\", \\\"{x:1484,y:851,t:1527614500979};\\\", \\\"{x:1485,y:853,t:1527614500996};\\\", \\\"{x:1485,y:856,t:1527614501012};\\\", \\\"{x:1486,y:858,t:1527614501028};\\\", \\\"{x:1486,y:859,t:1527614501046};\\\", \\\"{x:1486,y:860,t:1527614501063};\\\", \\\"{x:1486,y:861,t:1527614501078};\\\", \\\"{x:1486,y:862,t:1527614501095};\\\", \\\"{x:1486,y:864,t:1527614501113};\\\", \\\"{x:1486,y:866,t:1527614501128};\\\", \\\"{x:1487,y:867,t:1527614501146};\\\", \\\"{x:1487,y:869,t:1527614501163};\\\", \\\"{x:1487,y:870,t:1527614501179};\\\", \\\"{x:1487,y:872,t:1527614501196};\\\", \\\"{x:1487,y:873,t:1527614501213};\\\", \\\"{x:1487,y:875,t:1527614501229};\\\", \\\"{x:1487,y:876,t:1527614501251};\\\", \\\"{x:1488,y:876,t:1527614501300};\\\", \\\"{x:1488,y:877,t:1527614501323};\\\", \\\"{x:1488,y:878,t:1527614501340};\\\", \\\"{x:1488,y:879,t:1527614501356};\\\", \\\"{x:1488,y:880,t:1527614501363};\\\", \\\"{x:1488,y:881,t:1527614501378};\\\", \\\"{x:1488,y:883,t:1527614501396};\\\", \\\"{x:1488,y:884,t:1527614501413};\\\", \\\"{x:1488,y:885,t:1527614501452};\\\", \\\"{x:1488,y:886,t:1527614501468};\\\", \\\"{x:1488,y:887,t:1527614501484};\\\", \\\"{x:1488,y:888,t:1527614501499};\\\", \\\"{x:1488,y:889,t:1527614501512};\\\", \\\"{x:1488,y:890,t:1527614501532};\\\", \\\"{x:1488,y:891,t:1527614501556};\\\", \\\"{x:1488,y:892,t:1527614501588};\\\", \\\"{x:1488,y:893,t:1527614501604};\\\", \\\"{x:1488,y:894,t:1527614501988};\\\", \\\"{x:1487,y:894,t:1527614506860};\\\", \\\"{x:1487,y:893,t:1527614506867};\\\", \\\"{x:1486,y:890,t:1527614506883};\\\", \\\"{x:1486,y:889,t:1527614506900};\\\", \\\"{x:1485,y:888,t:1527614506917};\\\", \\\"{x:1485,y:887,t:1527614506934};\\\", \\\"{x:1485,y:885,t:1527614506950};\\\", \\\"{x:1485,y:883,t:1527614506967};\\\", \\\"{x:1484,y:880,t:1527614506984};\\\", \\\"{x:1484,y:874,t:1527614506999};\\\", \\\"{x:1482,y:868,t:1527614507017};\\\", \\\"{x:1482,y:860,t:1527614507033};\\\", \\\"{x:1482,y:856,t:1527614507049};\\\", \\\"{x:1482,y:847,t:1527614507066};\\\", \\\"{x:1482,y:840,t:1527614507083};\\\", \\\"{x:1482,y:829,t:1527614507101};\\\", \\\"{x:1482,y:814,t:1527614507116};\\\", \\\"{x:1482,y:805,t:1527614507134};\\\", \\\"{x:1482,y:792,t:1527614507151};\\\", \\\"{x:1477,y:773,t:1527614507166};\\\", \\\"{x:1476,y:765,t:1527614507184};\\\", \\\"{x:1475,y:752,t:1527614507200};\\\", \\\"{x:1472,y:737,t:1527614507216};\\\", \\\"{x:1470,y:725,t:1527614507234};\\\", \\\"{x:1467,y:707,t:1527614507251};\\\", \\\"{x:1464,y:696,t:1527614507266};\\\", \\\"{x:1460,y:684,t:1527614507283};\\\", \\\"{x:1458,y:677,t:1527614507301};\\\", \\\"{x:1456,y:670,t:1527614507317};\\\", \\\"{x:1455,y:665,t:1527614507333};\\\", \\\"{x:1453,y:658,t:1527614507351};\\\", \\\"{x:1451,y:651,t:1527614507367};\\\", \\\"{x:1448,y:643,t:1527614507384};\\\", \\\"{x:1448,y:640,t:1527614507400};\\\", \\\"{x:1446,y:636,t:1527614507415};\\\", \\\"{x:1445,y:634,t:1527614507431};\\\", \\\"{x:1413,y:633,t:1527614507450};\\\", \\\"{x:1352,y:643,t:1527614507464};\\\", \\\"{x:1258,y:654,t:1527614507482};\\\", \\\"{x:1160,y:656,t:1527614507499};\\\", \\\"{x:1065,y:658,t:1527614507514};\\\", \\\"{x:976,y:658,t:1527614507532};\\\", \\\"{x:868,y:658,t:1527614507549};\\\", \\\"{x:769,y:658,t:1527614507565};\\\", \\\"{x:674,y:658,t:1527614507582};\\\", \\\"{x:608,y:662,t:1527614507598};\\\", \\\"{x:571,y:667,t:1527614507616};\\\", \\\"{x:545,y:673,t:1527614507632};\\\", \\\"{x:511,y:684,t:1527614507649};\\\", \\\"{x:488,y:696,t:1527614507665};\\\", \\\"{x:471,y:703,t:1527614507682};\\\", \\\"{x:453,y:710,t:1527614507699};\\\", \\\"{x:442,y:713,t:1527614507716};\\\", \\\"{x:427,y:717,t:1527614507732};\\\", \\\"{x:414,y:720,t:1527614507749};\\\", \\\"{x:403,y:724,t:1527614507766};\\\", \\\"{x:401,y:727,t:1527614507782};\\\", \\\"{x:401,y:728,t:1527614507850};\\\", \\\"{x:420,y:730,t:1527614507865};\\\", \\\"{x:451,y:736,t:1527614507883};\\\", \\\"{x:483,y:740,t:1527614507898};\\\", \\\"{x:517,y:749,t:1527614507915};\\\", \\\"{x:525,y:750,t:1527614507932};\\\", \\\"{x:528,y:751,t:1527614507950};\\\", \\\"{x:529,y:751,t:1527614508032};\\\", \\\"{x:530,y:751,t:1527614508049};\\\", \\\"{x:531,y:751,t:1527614508066};\\\", \\\"{x:532,y:751,t:1527614508082};\\\", \\\"{x:532,y:746,t:1527614508279};\\\", \\\"{x:532,y:745,t:1527614508283};\\\", \\\"{x:532,y:744,t:1527614508299};\\\", \\\"{x:531,y:743,t:1527614508977};\\\", \\\"{x:530,y:742,t:1527614509049};\\\", \\\"{x:529,y:741,t:1527614509081};\\\", \\\"{x:529,y:739,t:1527614509545};\\\", \\\"{x:529,y:738,t:1527614509568};\\\", \\\"{x:528,y:737,t:1527614509592};\\\" ] }, { \\\"rt\\\": 80406, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 20, \\\"time_elapsed\\\": 922573, \\\"internal_node_id\\\": \\\"0.0-7.0-0.0\\\", \\\"subject\\\": \\\"TGOML\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"oscar\\\", \\\"condition\\\": \\\"114\\\", \\\"q\\\": 16, \\\"answer\\\": \\\"Which ever dots are aligned vertically with the 12pm marker on the horizontal axis\\\\n\\\", \\\"block\\\": \\\"triangular_testing\\\" }, { \\\"rt\\\": 12576, \\\"responses\\\": \\\"{\\\\\\\"Q0\\\\\\\":\\\\\\\"20\\\\\\\",\\\\\\\"Q1\\\\\\\":\\\\\\\"United States\\\\\\\"}\\\", \\\"block\\\": \\\"demo-1\\\", \\\"trial_type\\\": \\\"survey-text\\\", \\\"trial_index\\\": 21, \\\"time_elapsed\\\": 936154, \\\"internal_node_id\\\": \\\"0.0-8.0\\\", \\\"subject\\\": \\\"TGOML\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"oscar\\\", \\\"condition\\\": \\\"114\\\" }, { \\\"rt\\\": 15770, \\\"responses\\\": \\\"{\\\\\\\"Q0\\\\\\\":\\\\\\\"English\\\\\\\",\\\\\\\"Q1\\\\\\\":\\\\\\\"Second\\\\\\\",\\\\\\\"Q2\\\\\\\":\\\\\\\"Social Sciences (incl. CogSci)\\\\\\\",\\\\\\\"Q3\\\\\\\":\\\\\\\"Female\\\\\\\"}\\\", \\\"block\\\": \\\"demo-2\\\", \\\"trial_type\\\": \\\"survey-multi-choice\\\", \\\"trial_index\\\": 22, \\\"time_elapsed\\\": 952940, \\\"internal_node_id\\\": \\\"0.0-9.0\\\", \\\"subject\\\": \\\"TGOML\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"oscar\\\", \\\"condition\\\": \\\"114\\\" }, { \\\"rt\\\": 20860, \\\"url\\\": \\\"../views/src/external/debrief.html\\\", \\\"block\\\": \\\"debrief\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 23, \\\"time_elapsed\\\": 975149, \\\"internal_node_id\\\": \\\"0.0-10.0\\\", \\\"subject\\\": \\\"TGOML\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"oscar\\\", \\\"condition\\\": \\\"114\\\" } ]\",\"parentNode\":{\"id\":2765}}],[],[]]}"
    }
  ],
  "initialDom": "{\"f\":\"initialize\",\"args\":[1,[{\"nodeType\":10,\"id\":2,\"name\":\"html\",\"publicId\":\"\",\"systemId\":\"\"},{\"nodeType\":1,\"id\":3,\"tagName\":\"HTML\",\"attributes\":{\"class\":\"fa-events-icons-ready\"},\"childNodes\":[{\"nodeType\":1,\"id\":4,\"tagName\":\"HEAD\",\"attributes\":{},\"childNodes\":[{\"nodeType\":3,\"id\":5,\"textContent\":\" \"},{\"nodeType\":1,\"id\":6,\"tagName\":\"TITLE\",\"attributes\":{},\"childNodes\":[{\"nodeType\":3,\"id\":7,\"textContent\":\"FOX2YP\"}]},{\"nodeType\":3,\"id\":8,\"textContent\":\" \"},{\"nodeType\":8,\"id\":9},{\"nodeType\":3,\"id\":10,\"textContent\":\" \"},{\"nodeType\":1,\"id\":11,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":12,\"textContent\":\" \"},{\"nodeType\":1,\"id\":13,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":14,\"textContent\":\" \"},{\"nodeType\":1,\"id\":15,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":16,\"textContent\":\" \"},{\"nodeType\":1,\"id\":17,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":18,\"textContent\":\" \"},{\"nodeType\":1,\"id\":19,\"tagName\":\"SCRIPT\"},{\"nodeType\":1,\"id\":20,\"tagName\":\"LINK\",\"attributes\":{\"href\":\"https://use.fontawesome.com/945539d961.css\",\"media\":\"all\",\"rel\":\"stylesheet\"}},{\"nodeType\":3,\"id\":21,\"textContent\":\" \"},{\"nodeType\":8,\"id\":22},{\"nodeType\":3,\"id\":23,\"textContent\":\" \"},{\"nodeType\":1,\"id\":24,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":25,\"textContent\":\" \"},{\"nodeType\":1,\"id\":26,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":27,\"textContent\":\" \"},{\"nodeType\":1,\"id\":28,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":29,\"textContent\":\" \"},{\"nodeType\":1,\"id\":30,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":31,\"textContent\":\" \"},{\"nodeType\":1,\"id\":32,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":33,\"textContent\":\" \"},{\"nodeType\":1,\"id\":34,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":35,\"textContent\":\" \"},{\"nodeType\":1,\"id\":36,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":37,\"textContent\":\" \"},{\"nodeType\":8,\"id\":38},{\"nodeType\":3,\"id\":39,\"textContent\":\" \"},{\"nodeType\":1,\"id\":40,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":41,\"textContent\":\" \"},{\"nodeType\":8,\"id\":42},{\"nodeType\":3,\"id\":43,\"textContent\":\" \"},{\"nodeType\":8,\"id\":44},{\"nodeType\":3,\"id\":45,\"textContent\":\" \"},{\"nodeType\":1,\"id\":46,\"tagName\":\"LINK\",\"attributes\":{\"href\":\"../views/jsPsych/css/jspsych.css\",\"rel\":\"stylesheet\",\"type\":\"text/css\"}},{\"nodeType\":3,\"id\":47,\"textContent\":\" \"},{\"nodeType\":1,\"id\":48,\"tagName\":\"LINK\",\"attributes\":{\"href\":\"../css/styles.css\",\"rel\":\"stylesheet\",\"type\":\"text/css\"}},{\"nodeType\":3,\"id\":49,\"textContent\":\" \"},{\"nodeType\":1,\"id\":50,\"tagName\":\"SCRIPT\"},{\"nodeType\":1,\"id\":51,\"tagName\":\"SCRIPT\"}]},{\"nodeType\":3,\"id\":52,\"textContent\":\" \"},{\"nodeType\":8,\"id\":53},{\"nodeType\":3,\"id\":54,\"textContent\":\" \"},{\"nodeType\":1,\"id\":55,\"tagName\":\"BODY\",\"attributes\":{\"class\":\"jspsych-display-element\"},\"childNodes\":[{\"nodeType\":3,\"id\":56,\"textContent\":\" \"},{\"nodeType\":1,\"id\":57,\"tagName\":\"META\",\"attributes\":{\"charset\":\"utf-8\"}},{\"nodeType\":3,\"id\":58,\"textContent\":\" \"},{\"nodeType\":8,\"id\":59},{\"nodeType\":3,\"id\":60,\"textContent\":\" \"},{\"nodeType\":1,\"id\":61,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":62,\"textContent\":\" \"},{\"nodeType\":1,\"id\":63,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":64,\"textContent\":\" \"},{\"nodeType\":1,\"id\":65,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":66,\"textContent\":\" \"},{\"nodeType\":1,\"id\":67,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":68,\"textContent\":\" \"},{\"nodeType\":1,\"id\":69,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":70,\"textContent\":\" \"},{\"nodeType\":1,\"id\":71,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":72,\"textContent\":\" \"},{\"nodeType\":1,\"id\":73,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"stimulus\"},\"childNodes\":[{\"nodeType\":3,\"id\":74,\"textContent\":\" \"},{\"nodeType\":1,\"id\":75,\"tagName\":\"P\",\"attributes\":{\"class\":\"userid\",\"id\":\"userid\"},\"childNodes\":[{\"nodeType\":3,\"id\":76,\"textContent\":\"TGOML\"}]},{\"nodeType\":3,\"id\":77,\"textContent\":\" \"},{\"nodeType\":1,\"id\":78,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"userinput\"},\"childNodes\":[{\"nodeType\":3,\"id\":79,\"textContent\":\" \"},{\"nodeType\":8,\"id\":80},{\"nodeType\":3,\"id\":81,\"textContent\":\" \"},{\"nodeType\":1,\"id\":82,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"legend\",\"id\":\"hint-interactive\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":83,\"textContent\":\" \"},{\"nodeType\":1,\"id\":84,\"tagName\":\"P\",\"attributes\":{},\"childNodes\":[{\"nodeType\":3,\"id\":85,\"textContent\":\"Hint: Hover your mouse over the data points in the graph\"}]},{\"nodeType\":3,\"id\":86,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":87,\"textContent\":\" \"},{\"nodeType\":8,\"id\":88},{\"nodeType\":3,\"id\":89,\"textContent\":\" \"},{\"nodeType\":8,\"id\":90},{\"nodeType\":3,\"id\":91,\"textContent\":\" \"},{\"nodeType\":1,\"id\":92,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"test\"},\"childNodes\":[{\"nodeType\":3,\"id\":93,\"textContent\":\" \"},{\"nodeType\":1,\"id\":94,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"acme\",\"id\":\"acme.starttime\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":95,\"textContent\":\" \"},{\"nodeType\":1,\"id\":96,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":97,\"textContent\":\"Which shift(s) start at 11 am? \"}]},{\"nodeType\":3,\"id\":98,\"textContent\":\" \"},{\"nodeType\":1,\"id\":99,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":100,\"textContent\":\" \"},{\"nodeType\":1,\"id\":101,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":102,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":103,\"textContent\":\" \"},{\"nodeType\":1,\"id\":104,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":105,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":106,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":107,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":108,\"textContent\":\" \"},{\"nodeType\":1,\"id\":109,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":110,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":111,\"textContent\":\" \"},{\"nodeType\":1,\"id\":112,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":113,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":114,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":115,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":116,\"textContent\":\" \"},{\"nodeType\":1,\"id\":117,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":118,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":119,\"textContent\":\" \"},{\"nodeType\":1,\"id\":120,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":121,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":122,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":123,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":124,\"textContent\":\" \"},{\"nodeType\":1,\"id\":125,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":126,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":127,\"textContent\":\" \"},{\"nodeType\":1,\"id\":128,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":129,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":130,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":131,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":132,\"textContent\":\" \"},{\"nodeType\":1,\"id\":133,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":134,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":135,\"textContent\":\" \"},{\"nodeType\":1,\"id\":136,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":137,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":138,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":139,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":140,\"textContent\":\" \"},{\"nodeType\":1,\"id\":141,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":142,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":143,\"textContent\":\" \"},{\"nodeType\":1,\"id\":144,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":145,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":146,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":147,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":148,\"textContent\":\" \"},{\"nodeType\":1,\"id\":149,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":150,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":151,\"textContent\":\" \"},{\"nodeType\":1,\"id\":152,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":153,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":154,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":155,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":156,\"textContent\":\" \"},{\"nodeType\":1,\"id\":157,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":158,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":159,\"textContent\":\" \"},{\"nodeType\":1,\"id\":160,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":161,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":162,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":163,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":164,\"textContent\":\" \"},{\"nodeType\":1,\"id\":165,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":166,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":167,\"textContent\":\" \"},{\"nodeType\":1,\"id\":168,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":169,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":170,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":171,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":172,\"textContent\":\" \"},{\"nodeType\":1,\"id\":173,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":174,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":175,\"textContent\":\" \"},{\"nodeType\":1,\"id\":176,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":177,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":178,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":179,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":180,\"textContent\":\" \"},{\"nodeType\":1,\"id\":181,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":182,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":183,\"textContent\":\" \"},{\"nodeType\":1,\"id\":184,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"U\",\"value\":\"\"}},{\"nodeType\":3,\"id\":185,\"textContent\":\"U \"},{\"nodeType\":1,\"id\":186,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":187,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":188,\"textContent\":\" \"},{\"nodeType\":1,\"id\":189,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":190,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":191,\"textContent\":\" \"},{\"nodeType\":1,\"id\":192,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":193,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":194,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":195,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":196,\"textContent\":\" \"},{\"nodeType\":1,\"id\":197,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":198,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":199,\"textContent\":\" \"},{\"nodeType\":1,\"id\":200,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":201,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":202,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":203,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":204,\"textContent\":\" \"},{\"nodeType\":1,\"id\":205,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":206,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":207,\"textContent\":\" \"},{\"nodeType\":1,\"id\":208,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":209,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":210,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":211,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":212,\"textContent\":\" \"},{\"nodeType\":1,\"id\":213,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":214,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":215,\"textContent\":\" \"},{\"nodeType\":1,\"id\":216,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":217,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":218,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":219,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":220,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":221,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":222,\"textContent\":\" \"},{\"nodeType\":1,\"id\":223,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"acme\",\"id\":\"acme.starts\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":224,\"textContent\":\" \"},{\"nodeType\":1,\"id\":225,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":226,\"textContent\":\"Which shift(s) start at the same time as D?\"}]},{\"nodeType\":3,\"id\":227,\"textContent\":\" \"},{\"nodeType\":1,\"id\":228,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":229,\"textContent\":\" \"},{\"nodeType\":1,\"id\":230,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":231,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":232,\"textContent\":\" \"},{\"nodeType\":1,\"id\":233,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":234,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":235,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":236,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":237,\"textContent\":\" \"},{\"nodeType\":1,\"id\":238,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":239,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":240,\"textContent\":\" \"},{\"nodeType\":1,\"id\":241,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":242,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":243,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":244,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":245,\"textContent\":\" \"},{\"nodeType\":1,\"id\":246,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":247,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":248,\"textContent\":\" \"},{\"nodeType\":1,\"id\":249,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":250,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":251,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":252,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":253,\"textContent\":\" \"},{\"nodeType\":1,\"id\":254,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":255,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":256,\"textContent\":\" \"},{\"nodeType\":1,\"id\":257,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":258,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":259,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":260,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":261,\"textContent\":\" \"},{\"nodeType\":1,\"id\":262,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":263,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":264,\"textContent\":\" \"},{\"nodeType\":1,\"id\":265,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":266,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":267,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":268,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":269,\"textContent\":\" \"},{\"nodeType\":1,\"id\":270,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":271,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":272,\"textContent\":\" \"},{\"nodeType\":1,\"id\":273,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":274,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":275,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":276,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":277,\"textContent\":\" \"},{\"nodeType\":1,\"id\":278,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":279,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":280,\"textContent\":\" \"},{\"nodeType\":1,\"id\":281,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":282,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":283,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":284,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":285,\"textContent\":\" \"},{\"nodeType\":1,\"id\":286,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":287,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":288,\"textContent\":\" \"},{\"nodeType\":1,\"id\":289,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":290,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":291,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":292,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":293,\"textContent\":\" \"},{\"nodeType\":1,\"id\":294,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":295,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":296,\"textContent\":\" \"},{\"nodeType\":1,\"id\":297,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":298,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":299,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":300,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":301,\"textContent\":\" \"},{\"nodeType\":1,\"id\":302,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":303,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":304,\"textContent\":\" \"},{\"nodeType\":1,\"id\":305,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":306,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":307,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":308,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":309,\"textContent\":\" \"},{\"nodeType\":1,\"id\":310,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":311,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":312,\"textContent\":\" \"},{\"nodeType\":1,\"id\":313,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"U\",\"value\":\"\"}},{\"nodeType\":3,\"id\":314,\"textContent\":\"U \"},{\"nodeType\":1,\"id\":315,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":316,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":317,\"textContent\":\" \"},{\"nodeType\":1,\"id\":318,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":319,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":320,\"textContent\":\" \"},{\"nodeType\":1,\"id\":321,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":322,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":323,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":324,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":325,\"textContent\":\" \"},{\"nodeType\":1,\"id\":326,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":327,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":328,\"textContent\":\" \"},{\"nodeType\":1,\"id\":329,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":330,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":331,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":332,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":333,\"textContent\":\" \"},{\"nodeType\":1,\"id\":334,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":335,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":336,\"textContent\":\" \"},{\"nodeType\":1,\"id\":337,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":338,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":339,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":340,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":341,\"textContent\":\" \"},{\"nodeType\":1,\"id\":342,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":343,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":344,\"textContent\":\" \"},{\"nodeType\":1,\"id\":345,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":346,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":347,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":348,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":349,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":350,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":351,\"textContent\":\" \"},{\"nodeType\":1,\"id\":352,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"acme\",\"id\":\"acme.meets\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":353,\"textContent\":\" \"},{\"nodeType\":1,\"id\":354,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":355,\"textContent\":\"Which shift(s) begin when C ends?\"}]},{\"nodeType\":3,\"id\":356,\"textContent\":\" \"},{\"nodeType\":1,\"id\":357,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":358,\"textContent\":\" \"},{\"nodeType\":1,\"id\":359,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":360,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":361,\"textContent\":\" \"},{\"nodeType\":1,\"id\":362,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":363,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":364,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":365,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":366,\"textContent\":\" \"},{\"nodeType\":1,\"id\":367,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":368,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":369,\"textContent\":\" \"},{\"nodeType\":1,\"id\":370,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":371,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":372,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":373,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":374,\"textContent\":\" \"},{\"nodeType\":1,\"id\":375,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":376,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":377,\"textContent\":\" \"},{\"nodeType\":1,\"id\":378,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":379,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":380,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":381,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":382,\"textContent\":\" \"},{\"nodeType\":1,\"id\":383,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":384,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":385,\"textContent\":\" \"},{\"nodeType\":1,\"id\":386,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":387,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":388,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":389,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":390,\"textContent\":\" \"},{\"nodeType\":1,\"id\":391,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":392,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":393,\"textContent\":\" \"},{\"nodeType\":1,\"id\":394,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":395,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":396,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":397,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":398,\"textContent\":\" \"},{\"nodeType\":1,\"id\":399,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":400,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":401,\"textContent\":\" \"},{\"nodeType\":1,\"id\":402,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":403,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":404,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":405,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":406,\"textContent\":\" \"},{\"nodeType\":1,\"id\":407,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":408,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":409,\"textContent\":\" \"},{\"nodeType\":1,\"id\":410,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":411,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":412,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":413,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":414,\"textContent\":\" \"},{\"nodeType\":1,\"id\":415,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":416,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":417,\"textContent\":\" \"},{\"nodeType\":1,\"id\":418,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":419,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":420,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":421,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":422,\"textContent\":\" \"},{\"nodeType\":1,\"id\":423,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":424,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":425,\"textContent\":\" \"},{\"nodeType\":1,\"id\":426,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":427,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":428,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":429,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":430,\"textContent\":\" \"},{\"nodeType\":1,\"id\":431,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":432,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":433,\"textContent\":\" \"},{\"nodeType\":1,\"id\":434,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":435,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":436,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":437,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":438,\"textContent\":\" \"},{\"nodeType\":1,\"id\":439,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":440,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":441,\"textContent\":\" \"},{\"nodeType\":1,\"id\":442,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"U\",\"value\":\"\"}},{\"nodeType\":3,\"id\":443,\"textContent\":\"U \"},{\"nodeType\":1,\"id\":444,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":445,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":446,\"textContent\":\" \"},{\"nodeType\":1,\"id\":447,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":448,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":449,\"textContent\":\" \"},{\"nodeType\":1,\"id\":450,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":451,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":452,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":453,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":454,\"textContent\":\" \"},{\"nodeType\":1,\"id\":455,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":456,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":457,\"textContent\":\" \"},{\"nodeType\":1,\"id\":458,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":459,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":460,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":461,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":462,\"textContent\":\" \"},{\"nodeType\":1,\"id\":463,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":464,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":465,\"textContent\":\" \"},{\"nodeType\":1,\"id\":466,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":467,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":468,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":469,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":470,\"textContent\":\" \"},{\"nodeType\":1,\"id\":471,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":472,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":473,\"textContent\":\" \"},{\"nodeType\":1,\"id\":474,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":475,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":476,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":477,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":478,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":479,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":480,\"textContent\":\" \"},{\"nodeType\":1,\"id\":481,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"acme\",\"id\":\"acme.endtime\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":482,\"textContent\":\" \"},{\"nodeType\":1,\"id\":483,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":484,\"textContent\":\" Which shift(s) end at 4 pm?\"}]},{\"nodeType\":3,\"id\":485,\"textContent\":\" \"},{\"nodeType\":1,\"id\":486,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":487,\"textContent\":\" \"},{\"nodeType\":1,\"id\":488,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":489,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":490,\"textContent\":\" \"},{\"nodeType\":1,\"id\":491,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":492,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":493,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":494,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":495,\"textContent\":\" \"},{\"nodeType\":1,\"id\":496,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":497,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":498,\"textContent\":\" \"},{\"nodeType\":1,\"id\":499,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":500,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":501,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":502,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":503,\"textContent\":\" \"},{\"nodeType\":1,\"id\":504,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":505,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":506,\"textContent\":\" \"},{\"nodeType\":1,\"id\":507,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":508,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":509,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":510,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":511,\"textContent\":\" \"},{\"nodeType\":1,\"id\":512,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":513,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":514,\"textContent\":\" \"},{\"nodeType\":1,\"id\":515,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":516,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":517,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":518,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":519,\"textContent\":\" \"},{\"nodeType\":1,\"id\":520,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":521,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":522,\"textContent\":\" \"},{\"nodeType\":1,\"id\":523,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":524,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":525,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":526,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":527,\"textContent\":\" \"},{\"nodeType\":1,\"id\":528,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":529,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":530,\"textContent\":\" \"},{\"nodeType\":1,\"id\":531,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":532,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":533,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":534,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":535,\"textContent\":\" \"},{\"nodeType\":1,\"id\":536,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":537,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":538,\"textContent\":\" \"},{\"nodeType\":1,\"id\":539,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":540,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":541,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":542,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":543,\"textContent\":\" \"},{\"nodeType\":1,\"id\":544,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":545,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":546,\"textContent\":\" \"},{\"nodeType\":1,\"id\":547,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":548,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":549,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":550,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":551,\"textContent\":\" \"},{\"nodeType\":1,\"id\":552,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":553,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":554,\"textContent\":\" \"},{\"nodeType\":1,\"id\":555,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":556,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":557,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":558,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":559,\"textContent\":\" \"},{\"nodeType\":1,\"id\":560,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":561,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":562,\"textContent\":\" \"},{\"nodeType\":1,\"id\":563,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":564,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":565,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":566,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":567,\"textContent\":\" \"},{\"nodeType\":1,\"id\":568,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":569,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":570,\"textContent\":\" \"},{\"nodeType\":1,\"id\":571,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"U\",\"value\":\"\"}},{\"nodeType\":3,\"id\":572,\"textContent\":\"U \"},{\"nodeType\":1,\"id\":573,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":574,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":575,\"textContent\":\" \"},{\"nodeType\":1,\"id\":576,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":577,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":578,\"textContent\":\" \"},{\"nodeType\":1,\"id\":579,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":580,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":581,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":582,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":583,\"textContent\":\" \"},{\"nodeType\":1,\"id\":584,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":585,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":586,\"textContent\":\" \"},{\"nodeType\":1,\"id\":587,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":588,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":589,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":590,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":591,\"textContent\":\" \"},{\"nodeType\":1,\"id\":592,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":593,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":594,\"textContent\":\" \"},{\"nodeType\":1,\"id\":595,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":596,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":597,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":598,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":599,\"textContent\":\" \"},{\"nodeType\":1,\"id\":600,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":601,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":602,\"textContent\":\" \"},{\"nodeType\":1,\"id\":603,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":604,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":605,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":606,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":607,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":608,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":609,\"textContent\":\" \"},{\"nodeType\":1,\"id\":610,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"acme\",\"id\":\"acme.midpoint\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":611,\"textContent\":\" \"},{\"nodeType\":1,\"id\":612,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":613,\"textContent\":\"Coffee breaks happen halfway through a shift.\"},{\"nodeType\":1,\"id\":614,\"tagName\":\"BR\",\"attributes\":{}},{\"nodeType\":3,\"id\":615,\"textContent\":\" Which shift(s) share a break with I?\"}]},{\"nodeType\":3,\"id\":616,\"textContent\":\" \"},{\"nodeType\":1,\"id\":617,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":618,\"textContent\":\" \"},{\"nodeType\":1,\"id\":619,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":620,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":621,\"textContent\":\" \"},{\"nodeType\":1,\"id\":622,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":623,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":624,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":625,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":626,\"textContent\":\" \"},{\"nodeType\":1,\"id\":627,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":628,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":629,\"textContent\":\" \"},{\"nodeType\":1,\"id\":630,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":631,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":632,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":633,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":634,\"textContent\":\" \"},{\"nodeType\":1,\"id\":635,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":636,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":637,\"textContent\":\" \"},{\"nodeType\":1,\"id\":638,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":639,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":640,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":641,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":642,\"textContent\":\" \"},{\"nodeType\":1,\"id\":643,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":644,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":645,\"textContent\":\" \"},{\"nodeType\":1,\"id\":646,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":647,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":648,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":649,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":650,\"textContent\":\" \"},{\"nodeType\":1,\"id\":651,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":652,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":653,\"textContent\":\" \"},{\"nodeType\":1,\"id\":654,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":655,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":656,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":657,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":658,\"textContent\":\" \"},{\"nodeType\":1,\"id\":659,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":660,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":661,\"textContent\":\" \"},{\"nodeType\":1,\"id\":662,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":663,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":664,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":665,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":666,\"textContent\":\" \"},{\"nodeType\":1,\"id\":667,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":668,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":669,\"textContent\":\" \"},{\"nodeType\":1,\"id\":670,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":671,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":672,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":673,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":674,\"textContent\":\" \"},{\"nodeType\":1,\"id\":675,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":676,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":677,\"textContent\":\" \"},{\"nodeType\":1,\"id\":678,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":679,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":680,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":681,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":682,\"textContent\":\" \"},{\"nodeType\":1,\"id\":683,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":684,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":685,\"textContent\":\" \"},{\"nodeType\":1,\"id\":686,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":687,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":688,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":689,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":690,\"textContent\":\" \"},{\"nodeType\":1,\"id\":691,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":692,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":693,\"textContent\":\" \"},{\"nodeType\":1,\"id\":694,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":695,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":696,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":697,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":698,\"textContent\":\" \"},{\"nodeType\":1,\"id\":699,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":700,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":701,\"textContent\":\" \"},{\"nodeType\":1,\"id\":702,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"U\",\"value\":\"\"}},{\"nodeType\":3,\"id\":703,\"textContent\":\"U \"},{\"nodeType\":1,\"id\":704,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":705,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":706,\"textContent\":\" \"},{\"nodeType\":1,\"id\":707,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":708,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":709,\"textContent\":\" \"},{\"nodeType\":1,\"id\":710,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":711,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":712,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":713,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":714,\"textContent\":\" \"},{\"nodeType\":1,\"id\":715,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":716,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":717,\"textContent\":\" \"},{\"nodeType\":1,\"id\":718,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":719,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":720,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":721,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":722,\"textContent\":\" \"},{\"nodeType\":1,\"id\":723,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":724,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":725,\"textContent\":\" \"},{\"nodeType\":1,\"id\":726,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":727,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":728,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":729,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":730,\"textContent\":\" \"},{\"nodeType\":1,\"id\":731,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":732,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":733,\"textContent\":\" \"},{\"nodeType\":1,\"id\":734,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":735,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":736,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":737,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":738,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":739,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":740,\"textContent\":\" \"},{\"nodeType\":1,\"id\":741,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.duration\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":742,\"textContent\":\" \"},{\"nodeType\":1,\"id\":743,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":744,\"textContent\":\"Which shift(s) are six hours long?\"}]},{\"nodeType\":3,\"id\":745,\"textContent\":\" \"},{\"nodeType\":1,\"id\":746,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":747,\"textContent\":\" \"},{\"nodeType\":1,\"id\":748,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":749,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":750,\"textContent\":\" \"},{\"nodeType\":1,\"id\":751,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":752,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":753,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":754,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":755,\"textContent\":\" \"},{\"nodeType\":1,\"id\":756,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":757,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":758,\"textContent\":\" \"},{\"nodeType\":1,\"id\":759,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":760,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":761,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":762,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":763,\"textContent\":\" \"},{\"nodeType\":1,\"id\":764,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":765,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":766,\"textContent\":\" \"},{\"nodeType\":1,\"id\":767,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":768,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":769,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":770,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":771,\"textContent\":\" \"},{\"nodeType\":1,\"id\":772,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":773,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":774,\"textContent\":\" \"},{\"nodeType\":1,\"id\":775,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":776,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":777,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":778,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":779,\"textContent\":\" \"},{\"nodeType\":1,\"id\":780,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":781,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":782,\"textContent\":\" \"},{\"nodeType\":1,\"id\":783,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":784,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":785,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":786,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":787,\"textContent\":\" \"},{\"nodeType\":1,\"id\":788,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":789,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":790,\"textContent\":\" \"},{\"nodeType\":1,\"id\":791,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":792,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":793,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":794,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":795,\"textContent\":\" \"},{\"nodeType\":1,\"id\":796,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":797,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":798,\"textContent\":\" \"},{\"nodeType\":1,\"id\":799,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":800,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":801,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":802,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":803,\"textContent\":\" \"},{\"nodeType\":1,\"id\":804,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":805,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":806,\"textContent\":\" \"},{\"nodeType\":1,\"id\":807,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":808,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":809,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":810,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":811,\"textContent\":\" \"},{\"nodeType\":1,\"id\":812,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":813,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":814,\"textContent\":\" \"},{\"nodeType\":1,\"id\":815,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":816,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":817,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":818,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":819,\"textContent\":\" \"},{\"nodeType\":1,\"id\":820,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":821,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":822,\"textContent\":\" \"},{\"nodeType\":1,\"id\":823,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":824,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":825,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":826,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":827,\"textContent\":\" \"},{\"nodeType\":1,\"id\":828,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":829,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":830,\"textContent\":\" \"},{\"nodeType\":1,\"id\":831,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":832,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":833,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":834,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":835,\"textContent\":\" \"},{\"nodeType\":1,\"id\":836,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":837,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":838,\"textContent\":\" \"},{\"nodeType\":1,\"id\":839,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":840,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":841,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":842,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":843,\"textContent\":\" \"},{\"nodeType\":1,\"id\":844,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":845,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":846,\"textContent\":\" \"},{\"nodeType\":1,\"id\":847,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":848,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":849,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":850,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":851,\"textContent\":\" \"},{\"nodeType\":1,\"id\":852,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":853,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":854,\"textContent\":\" \"},{\"nodeType\":1,\"id\":855,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":856,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":857,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":858,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":859,\"textContent\":\" \"},{\"nodeType\":1,\"id\":860,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":861,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":862,\"textContent\":\" \"},{\"nodeType\":1,\"id\":863,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":864,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":865,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":866,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":867,\"textContent\":\" \"},{\"nodeType\":1,\"id\":868,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":869,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":870,\"textContent\":\" \"},{\"nodeType\":1,\"id\":871,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":872,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":873,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":874,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":875,\"textContent\":\" \"},{\"nodeType\":1,\"id\":876,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":877,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":878,\"textContent\":\" \"},{\"nodeType\":1,\"id\":879,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":880,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":881,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":882,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":883,\"textContent\":\" \"},{\"nodeType\":1,\"id\":884,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":885,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":886,\"textContent\":\" \"},{\"nodeType\":1,\"id\":887,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":888,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":889,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":890,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":891,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":892,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":893,\"textContent\":\" \"},{\"nodeType\":1,\"id\":894,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.duration+starts\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":895,\"textContent\":\" \"},{\"nodeType\":1,\"id\":896,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":897,\"textContent\":\"Which 2 shifts less than 5 hours long start at the same time?\"}]},{\"nodeType\":3,\"id\":898,\"textContent\":\" \"},{\"nodeType\":1,\"id\":899,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":900,\"textContent\":\" \"},{\"nodeType\":1,\"id\":901,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":902,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":903,\"textContent\":\" \"},{\"nodeType\":1,\"id\":904,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":905,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":906,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":907,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":908,\"textContent\":\" \"},{\"nodeType\":1,\"id\":909,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":910,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":911,\"textContent\":\" \"},{\"nodeType\":1,\"id\":912,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":913,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":914,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":915,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":916,\"textContent\":\" \"},{\"nodeType\":1,\"id\":917,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":918,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":919,\"textContent\":\" \"},{\"nodeType\":1,\"id\":920,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":921,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":922,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":923,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":924,\"textContent\":\" \"},{\"nodeType\":1,\"id\":925,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":926,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":927,\"textContent\":\" \"},{\"nodeType\":1,\"id\":928,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":929,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":930,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":931,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":932,\"textContent\":\" \"},{\"nodeType\":1,\"id\":933,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":934,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":935,\"textContent\":\" \"},{\"nodeType\":1,\"id\":936,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":937,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":938,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":939,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":940,\"textContent\":\" \"},{\"nodeType\":1,\"id\":941,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":942,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":943,\"textContent\":\" \"},{\"nodeType\":1,\"id\":944,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":945,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":946,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":947,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":948,\"textContent\":\" \"},{\"nodeType\":1,\"id\":949,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":950,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":951,\"textContent\":\" \"},{\"nodeType\":1,\"id\":952,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":953,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":954,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":955,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":956,\"textContent\":\" \"},{\"nodeType\":1,\"id\":957,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":958,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":959,\"textContent\":\" \"},{\"nodeType\":1,\"id\":960,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":961,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":962,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":963,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":964,\"textContent\":\" \"},{\"nodeType\":1,\"id\":965,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":966,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":967,\"textContent\":\" \"},{\"nodeType\":1,\"id\":968,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":969,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":970,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":971,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":972,\"textContent\":\" \"},{\"nodeType\":1,\"id\":973,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":974,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":975,\"textContent\":\" \"},{\"nodeType\":1,\"id\":976,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":977,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":978,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":979,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":980,\"textContent\":\" \"},{\"nodeType\":1,\"id\":981,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":982,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":983,\"textContent\":\" \"},{\"nodeType\":1,\"id\":984,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":985,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":986,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":987,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":988,\"textContent\":\" \"},{\"nodeType\":1,\"id\":989,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":990,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":991,\"textContent\":\" \"},{\"nodeType\":1,\"id\":992,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":993,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":994,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":995,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":996,\"textContent\":\" \"},{\"nodeType\":1,\"id\":997,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":998,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":999,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1000,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1001,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":1002,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1003,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1004,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1005,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1006,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1007,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1008,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1009,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":1010,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1011,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1012,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1013,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1014,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1015,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1016,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1017,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":1018,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1019,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1020,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1021,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1022,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1023,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1024,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1025,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":1026,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1027,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1028,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1029,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1030,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1031,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1032,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1033,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":1034,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1035,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1036,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1037,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1038,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1039,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1040,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1041,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":1042,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1043,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1044,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1045,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1046,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1047,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.duration+contained\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":1048,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1049,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":1050,\"textContent\":\"Which shift(s) under 7 hours long starts before B starts, and ends after X ends?\"}]},{\"nodeType\":3,\"id\":1051,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1052,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":1053,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1054,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1055,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1056,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1057,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1058,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":1059,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1060,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1061,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1062,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1063,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1064,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1065,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1066,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":1067,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1068,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1069,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1070,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1071,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1072,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1073,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1074,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":1075,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1076,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1077,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1078,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1079,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1080,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1081,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1082,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":1083,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1084,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1085,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1086,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1087,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1088,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1089,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1090,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":1091,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1092,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1093,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1094,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1095,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1096,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1097,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1098,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":1099,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1100,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1101,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1102,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1103,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1104,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1105,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1106,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":1107,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1108,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1109,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1110,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1111,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1112,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1113,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1114,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":1115,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1116,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1117,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1118,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1119,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1120,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1121,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1122,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":1123,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1124,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1125,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1126,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1127,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1128,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1129,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1130,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":1131,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1132,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1133,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1134,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1135,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1136,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1137,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1138,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":1139,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1140,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1141,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1142,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1143,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1144,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1145,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1146,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":1147,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1148,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1149,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1150,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1151,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1152,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1153,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1154,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":1155,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1156,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1157,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1158,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1159,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1160,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1161,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1162,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":1163,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1164,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1165,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1166,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1167,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1168,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1169,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1170,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":1171,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1172,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1173,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1174,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1175,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1176,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1177,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1178,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":1179,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1180,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1181,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1182,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1183,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1184,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1185,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1186,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":1187,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1188,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1189,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1190,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1191,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1192,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1193,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1194,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":1195,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1196,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1197,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1198,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1199,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1200,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.starttime+before+endtime+during\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":1201,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1202,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":1203,\"textContent\":\"Which shift(s) begins before J begins and ends during B?\"}]},{\"nodeType\":3,\"id\":1204,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1205,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":1206,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1207,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1208,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1209,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1210,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1211,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":1212,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1213,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1214,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1215,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1216,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1217,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1218,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1219,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":1220,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1221,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1222,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1223,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1224,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1225,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1226,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1227,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":1228,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1229,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1230,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1231,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1232,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1233,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1234,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1235,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":1236,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1237,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1238,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1239,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1240,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1241,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1242,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1243,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":1244,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1245,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1246,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1247,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1248,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1249,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1250,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1251,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":1252,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1253,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1254,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1255,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1256,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1257,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1258,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1259,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":1260,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1261,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1262,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1263,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1264,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1265,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1266,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1267,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":1268,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1269,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1270,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1271,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1272,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1273,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1274,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1275,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":1276,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1277,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1278,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1279,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1280,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1281,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1282,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1283,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":1284,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1285,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1286,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1287,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1288,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1289,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1290,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1291,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":1292,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1293,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1294,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1295,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1296,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1297,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1298,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1299,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":1300,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1301,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1302,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1303,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1304,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1305,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1306,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1307,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":1308,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1309,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1310,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1311,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1312,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1313,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1314,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1315,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":1316,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1317,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1318,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1319,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1320,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1321,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1322,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1323,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":1324,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1325,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1326,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1327,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1328,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1329,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1330,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1331,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":1332,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1333,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1334,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1335,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1336,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1337,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1338,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1339,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":1340,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1341,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1342,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1343,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1344,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1345,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1346,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1347,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":1348,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1349,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1350,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1351,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1352,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1353,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.ends\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":1354,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1355,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":1356,\"textContent\":\"Which shift(s) end at the same time as F?\"}]},{\"nodeType\":3,\"id\":1357,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1358,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":1359,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1360,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1361,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1362,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1363,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1364,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":1365,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1366,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1367,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1368,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1369,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1370,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1371,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1372,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":1373,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1374,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1375,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1376,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1377,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1378,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1379,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1380,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":1381,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1382,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1383,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1384,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1385,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1386,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1387,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1388,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":1389,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1390,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1391,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1392,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1393,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1394,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1395,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1396,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":1397,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1398,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1399,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1400,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1401,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1402,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1403,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1404,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":1405,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1406,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1407,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1408,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1409,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1410,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1411,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1412,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":1413,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1414,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1415,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1416,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1417,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1418,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1419,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1420,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":1421,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1422,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1423,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1424,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1425,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1426,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1427,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1428,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":1429,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1430,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1431,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1432,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1433,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1434,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1435,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1436,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":1437,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1438,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1439,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1440,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1441,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1442,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1443,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1444,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":1445,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1446,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1447,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1448,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1449,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1450,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1451,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1452,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":1453,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1454,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1455,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1456,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1457,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1458,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1459,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1460,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":1461,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1462,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1463,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1464,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1465,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1466,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1467,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1468,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":1469,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1470,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1471,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1472,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1473,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1474,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1475,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1476,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":1477,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1478,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1479,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1480,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1481,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1482,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1483,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1484,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":1485,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1486,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1487,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1488,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1489,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1490,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1491,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1492,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":1493,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1494,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1495,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1496,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1497,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1498,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1499,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1500,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":1501,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1502,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1503,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1504,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1505,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1506,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.starttime\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":1507,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1508,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":1509,\"textContent\":\"Which shift(s) start at 12pm?\"}]},{\"nodeType\":3,\"id\":1510,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1511,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":1512,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1513,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1514,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1515,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1516,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1517,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":1518,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1519,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1520,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1521,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1522,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1523,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1524,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1525,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":1526,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1527,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1528,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1529,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1530,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1531,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1532,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1533,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":1534,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1535,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1536,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1537,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1538,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1539,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1540,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1541,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":1542,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1543,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1544,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1545,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1546,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1547,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1548,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1549,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":1550,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1551,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1552,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1553,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1554,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1555,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1556,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1557,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":1558,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1559,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1560,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1561,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1562,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1563,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1564,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1565,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":1566,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1567,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1568,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1569,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1570,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1571,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1572,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1573,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":1574,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1575,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1576,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1577,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1578,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1579,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1580,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1581,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":1582,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1583,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1584,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1585,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1586,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1587,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1588,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1589,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":1590,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1591,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1592,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1593,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1594,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1595,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1596,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1597,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":1598,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1599,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1600,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1601,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1602,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1603,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1604,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1605,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":1606,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1607,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1608,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1609,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1610,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1611,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1612,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1613,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":1614,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1615,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1616,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1617,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1618,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1619,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1620,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1621,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":1622,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1623,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1624,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1625,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1626,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1627,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1628,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1629,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":1630,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1631,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1632,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1633,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1634,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1635,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1636,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1637,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":1638,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1639,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1640,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1641,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1642,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1643,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1644,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1645,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":1646,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1647,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1648,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1649,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1650,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1651,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1652,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1653,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":1654,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1655,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1656,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1657,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1658,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1659,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.starts\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":1660,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1661,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":1662,\"textContent\":\"Which shift(s) start at the same time as F?\"}]},{\"nodeType\":3,\"id\":1663,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1664,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":1665,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1666,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1667,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1668,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1669,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1670,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":1671,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1672,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1673,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1674,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1675,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1676,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1677,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1678,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":1679,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1680,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1681,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1682,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1683,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1684,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1685,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1686,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":1687,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1688,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1689,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1690,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1691,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1692,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1693,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1694,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":1695,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1696,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1697,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1698,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1699,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1700,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1701,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1702,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":1703,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1704,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1705,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1706,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1707,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1708,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1709,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1710,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":1711,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1712,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1713,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1714,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1715,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1716,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1717,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1718,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":1719,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1720,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1721,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1722,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1723,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1724,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1725,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1726,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":1727,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1728,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1729,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1730,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1731,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1732,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1733,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1734,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":1735,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1736,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1737,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1738,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1739,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1740,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1741,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1742,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":1743,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1744,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1745,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1746,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1747,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1748,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1749,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1750,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":1751,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1752,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1753,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1754,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1755,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1756,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1757,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1758,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":1759,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1760,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1761,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1762,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1763,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1764,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1765,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1766,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":1767,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1768,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1769,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1770,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1771,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1772,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1773,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1774,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":1775,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1776,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1777,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1778,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1779,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1780,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1781,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1782,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":1783,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1784,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1785,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1786,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1787,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1788,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1789,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1790,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":1791,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1792,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1793,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1794,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1795,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1796,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1797,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1798,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":1799,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1800,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1801,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1802,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1803,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1804,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1805,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1806,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":1807,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1808,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1809,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1810,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1811,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1812,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.meets\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":1813,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1814,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":1815,\"textContent\":\"Which 2 shifts end when Z begins?\"}]},{\"nodeType\":3,\"id\":1816,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1817,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":1818,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1819,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1820,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1821,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1822,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1823,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":1824,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1825,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1826,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1827,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1828,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1829,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1830,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1831,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":1832,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1833,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1834,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1835,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1836,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1837,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1838,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1839,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":1840,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1841,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1842,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1843,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1844,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1845,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1846,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1847,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":1848,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1849,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1850,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1851,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1852,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1853,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1854,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1855,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":1856,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1857,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1858,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1859,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1860,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1861,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1862,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1863,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":1864,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1865,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1866,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1867,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1868,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1869,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1870,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1871,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":1872,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1873,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1874,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1875,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1876,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1877,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1878,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1879,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":1880,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1881,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1882,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1883,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1884,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1885,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1886,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1887,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":1888,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1889,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1890,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1891,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1892,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1893,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1894,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1895,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":1896,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1897,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1898,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1899,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1900,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1901,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1902,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1903,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":1904,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1905,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1906,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1907,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1908,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1909,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1910,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1911,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":1912,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1913,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1914,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1915,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1916,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1917,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1918,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1919,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":1920,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1921,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1922,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1923,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1924,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1925,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1926,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1927,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":1928,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1929,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1930,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1931,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1932,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1933,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1934,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1935,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":1936,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1937,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1938,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1939,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1940,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1941,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1942,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1943,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":1944,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1945,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1946,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1947,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1948,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1949,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1950,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1951,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":1952,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1953,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1954,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1955,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1956,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1957,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1958,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1959,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":1960,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1961,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1962,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1963,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1964,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1965,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.endtime\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":1966,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1967,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":1968,\"textContent\":\"Which shift(s) end at 3pm?\"}]},{\"nodeType\":3,\"id\":1969,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1970,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":1971,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1972,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1973,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1974,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1975,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1976,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":1977,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1978,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1979,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1980,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1981,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1982,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1983,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1984,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":1985,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1986,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1987,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1988,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1989,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1990,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1991,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1992,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":1993,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1994,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1995,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1996,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1997,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1998,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1999,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2000,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":2001,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2002,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2003,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2004,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2005,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2006,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2007,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2008,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":2009,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2010,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2011,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2012,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2013,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2014,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2015,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2016,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":2017,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2018,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2019,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2020,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2021,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2022,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2023,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2024,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":2025,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2026,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2027,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2028,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2029,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2030,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2031,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2032,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":2033,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2034,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2035,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2036,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2037,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2038,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2039,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2040,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":2041,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2042,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2043,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2044,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2045,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2046,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2047,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2048,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":2049,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2050,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2051,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2052,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2053,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2054,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2055,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2056,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":2057,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2058,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2059,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2060,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2061,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2062,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2063,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2064,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":2065,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2066,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2067,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2068,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2069,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2070,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2071,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2072,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":2073,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2074,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2075,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2076,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2077,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2078,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2079,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2080,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":2081,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2082,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2083,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2084,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2085,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2086,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2087,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2088,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":2089,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2090,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2091,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2092,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2093,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2094,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2095,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2096,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":2097,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2098,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2099,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2100,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2101,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2102,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2103,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2104,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":2105,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2106,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2107,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2108,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2109,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2110,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2111,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2112,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":2113,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2114,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2115,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2116,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2117,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2118,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.midpoint\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":2119,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2120,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":2121,\"textContent\":\"Coffee breaks happen halfway through a shift. \"},{\"nodeType\":1,\"id\":2122,\"tagName\":\"BR\",\"attributes\":{}},{\"nodeType\":3,\"id\":2123,\"textContent\":\"Which shifts share a break at 2pm?\"}]},{\"nodeType\":3,\"id\":2124,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2125,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":2126,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2127,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2128,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2129,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2130,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2131,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":2132,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2133,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2134,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2135,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2136,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2137,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2138,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2139,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":2140,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2141,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2142,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2143,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2144,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2145,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2146,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2147,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":2148,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2149,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2150,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2151,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2152,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2153,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2154,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2155,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":2156,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2157,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2158,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2159,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2160,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2161,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2162,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2163,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":2164,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2165,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2166,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2167,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2168,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2169,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2170,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2171,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":2172,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2173,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2174,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2175,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2176,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2177,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2178,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2179,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":2180,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2181,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2182,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2183,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2184,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2185,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2186,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2187,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":2188,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2189,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2190,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2191,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2192,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2193,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2194,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2195,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":2196,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2197,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2198,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2199,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2200,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2201,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2202,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2203,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":2204,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2205,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2206,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2207,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2208,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2209,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2210,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2211,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":2212,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2213,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2214,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2215,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2216,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2217,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2218,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2219,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":2220,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2221,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2222,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2223,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2224,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2225,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2226,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2227,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":2228,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2229,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2230,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2231,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2232,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2233,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2234,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2235,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":2236,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2237,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2238,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2239,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2240,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2241,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2242,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2243,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":2244,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2245,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2246,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2247,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2248,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2249,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2250,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2251,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":2252,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2253,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2254,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2255,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2256,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2257,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2258,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2259,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":2260,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2261,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2262,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2263,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2264,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2265,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2266,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2267,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":2268,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2269,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2270,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2271,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2272,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2273,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\".strategy\",\"style\":\"display: block;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2274,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2275,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":2276,\"textContent\":\"Please describe how to determine what event(s) start at 12pm?\"}]},{\"nodeType\":3,\"id\":2277,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2278,\"tagName\":\"TEXTAREA\",\"attributes\":{\"id\":\"strategyAnswer\",\"rows\":\"5\",\"cols\":\"80\"}},{\"nodeType\":3,\"id\":2279,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2280,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2281,\"textContent\":\" \"},{\"nodeType\":8,\"id\":2282},{\"nodeType\":3,\"id\":2283,\"textContent\":\" \"},{\"nodeType\":8,\"id\":2284},{\"nodeType\":3,\"id\":2285,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2286,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"fixbottom\"},\"childNodes\":[{\"nodeType\":3,\"id\":2287,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2288,\"tagName\":\"BUTTON\",\"attributes\":{\"type\":\"button\",\"id\":\"testingButton\",\"style\":\"display:none;\",\"class\":\"btn\"},\"childNodes\":[{\"nodeType\":3,\"id\":2289,\"textContent\":\"SUBMIT\"}]},{\"nodeType\":3,\"id\":2290,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2291,\"tagName\":\"BUTTON\",\"attributes\":{\"type\":\"button\",\"id\":\"strategyButton\",\"style\":\"display: block;\",\"class\":\"btn\"},\"childNodes\":[{\"nodeType\":3,\"id\":2292,\"textContent\":\"SUBMIT\"}]},{\"nodeType\":3,\"id\":2293,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2294,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2295,\"textContent\":\" \"},{\"nodeType\":8,\"id\":2296},{\"nodeType\":3,\"id\":2297,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2298,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"d3container\"},\"childNodes\":[{\"nodeType\":1,\"id\":2299,\"tagName\":\"svg\",\"attributes\":{\"width\":\"930\",\"height\":\"915\"},\"childNodes\":[{\"nodeType\":1,\"id\":2300,\"tagName\":\"g\",\"attributes\":{\"transform\":\"translate(100,25)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2301,\"tagName\":\"g\",\"attributes\":{\"class\":\"leaders\"}},{\"nodeType\":1,\"id\":2302,\"tagName\":\"g\",\"attributes\":{\"class\":\"static-scaffold\"}}]}]}]},{\"nodeType\":3,\"id\":2303,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2304,\"textContent\":\" \"},{\"nodeType\":8,\"id\":2305},{\"nodeType\":3,\"id\":2306,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2307,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":2308,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2309,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":2310,\"textContent\":\" \"}]}]}]]}",
  "useCssProxy": true,
  "loadTimes": "es: 129, dom: 775, initialDom: 861",
  "javascriptErrors": []
}