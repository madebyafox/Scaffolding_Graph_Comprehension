var MF = MF || {};MF.RecordingData = MF.RecordingData || {};MF.RecordingData["session"] = {
  "id": "8e3ea14334c1878cd6fdacc0454f203a",
  "created": "2018-06-01T10:17:55.9217692-07:00",
  "lastActivity": "2018-06-01T10:18:45.3427692-07:00",
  "pageViews": [
    {
      "id": "060156498ccbca26dd6ebb1180d05f63c566469e",
      "startTime": "2018-06-01T10:17:55.9217692-07:00",
      "endTime": "2018-06-01T10:18:45.3427692-07:00",
      "title": "FOX2YP",
      "uri": "https://warm-citadel-75324.herokuapp.com/",
      "websitePage": "/10",
      "visitTime": 49421,
      "engagementTime": 32716,
      "scroll": 100.0,
      "tags": [
        "form-interact"
      ],
      "friction": 0,
      "annotations": []
    }
  ],
  "duration": 49421,
  "engagementTime": 32716,
  "totalFriction": 0,
  "country": "us",
  "region": "CA",
  "city": "La Jolla",
  "isp": "University of California, San Diego",
  "ip": "128.54.68.36",
  "lang": "en-US",
  "userAgent": "Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/66.0.3359.181 Safari/537.36",
  "browser": "Chrome",
  "browserVersion": "66.0.3359.181",
  "os": "Windows",
  "osVersion": "7",
  "device": "Desktop",
  "referrer": "",
  "referrerType": "",
  "screenRes": "1920x1200",
  "tags": [
    "form-interact"
  ],
  "variables": [
    "SID=9BS72",
    "CONDITION=115"
  ],
  "watched": false,
  "starred": false,
  "lng": -117.2359,
  "lat": 32.8807,
  "visitorId": "283a9d087bee9d21262b076462f9a864",
  "gdpr": false
}